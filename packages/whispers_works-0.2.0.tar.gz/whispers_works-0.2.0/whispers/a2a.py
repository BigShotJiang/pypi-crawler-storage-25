"""A2A Protocol Integration for Whispers.

Implements the Agent-to-Agent (A2A) v1.0 protocol surface:
- Agent Card discovery at /.well-known/agent-card.json
- Per-agent cards at /agents/{callsign}/.well-known/agent-card.json
- JSON-RPC 2.0 gateway at /a2a/v1
- Task lifecycle mapping (Whispers messages → A2A Tasks)
- SSE streaming via message/stream (real-time task state updates)
- Outbound A2AClient for sending tasks to external A2A agents

A2A is the wire protocol. Whispers is the social layer on top.
External agents see standard A2A. Internal agents use Whispers natively.
The gateway translates.

Spec reference: .planning/research/a2a-spec-compliance.md
"""

import asyncio
import json
import logging
import os
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid
from datetime import datetime, timezone
from typing import Any, Dict, Generator, List, Optional, Tuple

from fastapi import APIRouter, HTTPException, Request
from sse_starlette.sse import EventSourceResponse
from starlette.responses import JSONResponse

from .twoack import (
    PreflightPolicy,
    check_reply_schema_constraint,
    derive_text_fallback,
    evaluate_preflight,
    extract_a2a_binding,
    validate_authority_claim,
    validate_message,
)

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

WHISPERS_VERSION = "0.2.0"
A2A_PROTOCOL_VERSION = "1.0"
A2A_SUPPORTED_VERSIONS = ["1.0"]
A2A_MAX_REQUEST_BYTES = int(
    os.environ.get(
        "WHISPERS_A2A_MAX_REQUEST_BYTES",
        os.environ.get("WHISPERS_MAX_INLINE_PAYLOAD", "32000"),
    )
)

# JSON-RPC 2.0 error codes
JSONRPC_PARSE_ERROR = -32700
JSONRPC_INVALID_REQUEST = -32600
JSONRPC_METHOD_NOT_FOUND = -32601
JSONRPC_INVALID_PARAMS = -32602
JSONRPC_INTERNAL_ERROR = -32603

# A2A application-level error codes
# Convention: 4xxNN where 4xx mirrors HTTP semantics, NN is a sub-code.
#   400xx = validation errors
#   401xx = authentication errors
#   403xx = authorization/scope errors
#   404xx = not found
#   409xx = conflict/state errors
#   429xx = rate limiting
A2A_AUTH_REQUIRED = 40100
A2A_AUTH_INVALID = 40101
A2A_SCOPE_INSUFFICIENT = 40300
A2A_TASK_NOT_FOUND = 40401
A2A_AGENT_NOT_FOUND = 40402
A2A_TASK_NOT_CANCELABLE = 40900
A2A_RATE_LIMITED = 42900

# Solution-Aware Error Responses (SAER) spec version
SAER_VERSION = "0.1"

# A2A Task States (v1.0 SCREAMING_SNAKE_CASE)
TASK_SUBMITTED = "TASK_STATE_SUBMITTED"
TASK_WORKING = "TASK_STATE_WORKING"
TASK_INPUT_REQUIRED = "TASK_STATE_INPUT_REQUIRED"
TASK_COMPLETED = "TASK_STATE_COMPLETED"
TASK_FAILED = "TASK_STATE_FAILED"
TASK_CANCELED = "TASK_STATE_CANCELED"
TASK_REJECTED = "TASK_STATE_REJECTED"

# Whispers token scope vocabulary (mirrors WhispersDB.VALID_SCOPES)
WHISPERS_SCOPES = [
    "messages:send",
    "messages:read",
    "messages:stream",
    "presence:read",
    "agents:read",
    "agents:write",
    "tokens:manage",
    "admin:*",
    "*",
]

# Token profiles for A2A Agent Card discovery
WHISPERS_TOKEN_PROFILES = {
    "external-agent": {
        "description": "Standard external agent — messaging + read-only presence/agents",
        "scopes": ["messages:send", "messages:read", "presence:read", "agents:read"],
    },
    "full-agent": {
        "description": "Full agent — messaging + streaming + presence/agents",
        "scopes": ["messages:send", "messages:read", "messages:stream", "presence:read", "agents:read"],
    },
    "read-only": {
        "description": "Read-only — no sending, no mutations",
        "scopes": ["messages:read", "presence:read", "agents:read"],
    },
}


# ---------------------------------------------------------------------------
# Agent Card Generation
# ---------------------------------------------------------------------------

def generate_server_card(server_url: str) -> Dict[str, Any]:
    """Generate the Whispers server's own A2A Agent Card.

    This is the card served at /.well-known/agent-card.json.
    It describes the Whispers hub itself, not individual agents.
    """
    return {
        "name": "Whispers Hub",
        "description": (
            "A social coordination layer for AI agents. "
            "Provides presence, signal modes, trust tiers, and message routing "
            "on top of the A2A protocol."
        ),
        "version": WHISPERS_VERSION,
        "url": f"{server_url}/a2a/v1",
        "protocolVersions": A2A_SUPPORTED_VERSIONS,
        "capabilities": {
            "streaming": True,
            "pushNotifications": False,
            "stateTransitionHistory": True,
        },
        "defaultInputModes": ["text/plain", "application/json"],
        "defaultOutputModes": ["text/plain", "application/json"],
        "skills": [
            {
                "id": "message-routing",
                "name": "Message Routing",
                "description": "Route messages between agents with presence-aware delivery",
                "inputModes": ["text/plain", "application/json"],
                "outputModes": ["application/json"],
            },
            {
                "id": "agent-discovery",
                "name": "Agent Discovery",
                "description": "Discover registered agents with live presence and signal mode info",
                "inputModes": ["text/plain"],
                "outputModes": ["application/json"],
            },
        ],
        "supportedInterfaces": [
            {"protocol": "JSONRPC", "url": f"{server_url}/a2a/v1"},
        ],
        # A2A v1.0 security (OpenAPI-style)
        "securitySchemes": {
            "bearerToken": {
                "type": "http",
                "scheme": "bearer",
                "description": (
                    "Whispers API token obtained via /connect or /token:create. "
                    "Tokens support fine-grained scopes."
                ),
            },
        },
        "securityRequirements": [{"bearerToken": []}],
        "provider": {
            "organization": "Whispers",
            "url": "https://whispers.works",
        },
        # Whispers extensions in metadata (namespaced with whispers: prefix)
        "metadata": {
            "whispers:type": "hub",
            "whispers:features": [
                "presence",
                "signal_modes",
                "trust_tiers",
                "cognitive_heartbeat",
                "operator_controls",
                "conversational_trace",
                "scoped_tokens",
            ],
            "whispers:tokenEndpoint": f"{server_url}/connect",
            "whispers:availableScopes": sorted(WHISPERS_SCOPES),
            "whispers:tokenProfiles": WHISPERS_TOKEN_PROFILES,
        },
    }


def generate_agent_card(
    agent: Dict[str, Any],
    server_url: str,
    presence: Optional[Dict[str, Any]] = None,
    runtime_state: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """Generate an A2A Agent Card for a registered Whispers agent.

    Maps Whispers agent registration data to A2A Agent Card format.
    Whispers-specific extensions (presence, signal mode, trust tier)
    are placed in metadata with the whispers: prefix.
    """
    callsign = agent["callsign"]
    description = agent.get("description") or f"Whispers agent: {callsign}"
    display_name = agent.get("display_name") or callsign
    model_id = agent.get("model_id")
    from .client import _decode_json_list_field, _participant_kind_for_record, _participant_profiles_from_tags

    # Parse capabilities and tools from JSON strings
    capabilities_raw = agent.get("capabilities")
    if isinstance(capabilities_raw, str):
        try:
            capabilities_raw = json.loads(capabilities_raw)
        except (json.JSONDecodeError, TypeError):
            capabilities_raw = []
    elif capabilities_raw is None:
        capabilities_raw = []

    tools_raw = agent.get("tools")
    if isinstance(tools_raw, str):
        try:
            tools_raw = json.loads(tools_raw)
        except (json.JSONDecodeError, TypeError):
            tools_raw = []
    elif tools_raw is None:
        tools_raw = []

    participant_kind = _participant_kind_for_record(agent)
    participant_profiles = _participant_profiles_from_tags(agent.get("tags"))

    # Build A2A skills from Whispers capabilities
    skills = []
    if capabilities_raw and isinstance(capabilities_raw, list):
        for cap in capabilities_raw:
            if isinstance(cap, str):
                skills.append({
                    "id": cap.lower().replace(" ", "-"),
                    "name": cap,
                    "description": f"Agent capability: {cap}",
                })
            elif isinstance(cap, dict):
                skills.append({
                    "id": cap.get("id", cap.get("name", "unknown")).lower().replace(" ", "-"),
                    "name": cap.get("name", "Unknown"),
                    "description": cap.get("description", ""),
                })

    # Build the core A2A card
    card: Dict[str, Any] = {
        "name": display_name,
        "description": description,
        "version": model_id or "1.0.0",
        "url": f"{server_url}/a2a/v1",
        "protocolVersions": A2A_SUPPORTED_VERSIONS,
        "capabilities": {
            "streaming": True,
            "pushNotifications": False,
            "stateTransitionHistory": True,
        },
        "defaultInputModes": ["text/plain", "application/json"],
        "defaultOutputModes": ["text/plain", "application/json"],
        "supportedInterfaces": [
            {"protocol": "JSONRPC", "url": f"{server_url}/a2a/v1"},
        ],
        # A2A v1.0 security — scoped Bearer tokens
        "securitySchemes": {
            "bearerToken": {
                "type": "http",
                "scheme": "bearer",
                "description": (
                    "Scoped Whispers token. Obtain via /connect or /token:create. "
                    "Minimum scopes for messaging: messages:send, messages:read."
                ),
            },
        },
        "securityRequirements": [{"bearerToken": []}],
    }

    if skills:
        card["skills"] = skills

    # Whispers extensions in metadata
    whispers_meta: Dict[str, Any] = {
        "whispers:callsign": callsign,
        "whispers:agentType": agent.get("agent_type", "unknown"),
        "whispers:participantKind": participant_kind,
        "whispers:isPrimaryParticipant": participant_kind in {"agent", "service"},
        "whispers:trustTier": agent.get("trust_tier", 1),
        "whispers:tokenEndpoint": f"{server_url}/connect",
        "whispers:requiredScopes": ["messages:send", "messages:read"],
    }
    if participant_profiles:
        whispers_meta["whispers:participantProfiles"] = participant_profiles
    normalized_tags = _decode_json_list_field(agent.get("tags"))
    if normalized_tags:
        whispers_meta["whispers:tags"] = normalized_tags

    # Add live presence data if available
    if presence:
        whispers_meta["whispers:presence"] = presence.get("status", "offline")
        whispers_meta["whispers:lastActive"] = presence.get("last_active")
        whispers_meta["whispers:signalMode"] = presence.get("reception_mode", "open")
        if presence.get("mode_filter"):
            whispers_meta["whispers:modeFilter"] = presence["mode_filter"]
        if presence.get("cognitive_state"):
            whispers_meta["whispers:wag"] = {
                "state": presence["cognitive_state"],
                "confidence": presence.get("state_confidence"),
                "intent": presence.get("intent_broadcast"),
            }

    # Add runtime state if available
    if runtime_state:
        whispers_meta["whispers:readiness"] = runtime_state.get("readiness", "ready")
        whispers_meta["whispers:interruptibility"] = runtime_state.get("interruptibility")
        if runtime_state.get("current_task"):
            whispers_meta["whispers:currentTask"] = runtime_state["current_task"]

    card["metadata"] = whispers_meta
    return card


# ---------------------------------------------------------------------------
# JSON-RPC 2.0 Helpers
# ---------------------------------------------------------------------------

def _jsonrpc_response(result: Any, request_id: Any) -> Dict[str, Any]:
    """Build a JSON-RPC 2.0 success response."""
    return {
        "jsonrpc": "2.0",
        "id": request_id,
        "result": result,
    }


def _jsonrpc_error(code: int, message: str, request_id: Any = None, data: Any = None) -> Dict[str, Any]:
    """Build a JSON-RPC 2.0 error response."""
    error: Dict[str, Any] = {"code": code, "message": message}
    if data is not None:
        error["data"] = data
    return {
        "jsonrpc": "2.0",
        "id": request_id,
        "error": error,
    }


def _solution_aware_error(
    code: int,
    message: str,
    request_id: Any = None,
    *,
    reason: Optional[str] = None,
    resolution: Optional[str] = None,
    see: Optional[str] = None,
    context: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """Build a JSON-RPC 2.0 error with SAER diagnostic data.

    Solution-Aware Error Responses (SAER v0.1) add structured
    remediation fields to standard JSON-RPC errors:
      - reason: why the error occurred
      - resolution: what the agent should do
      - see: relative endpoint for more info
      - context: additional structured data

    See: A2A SAER Spec v0.1
    """
    error: Dict[str, Any] = {"code": code, "message": message}
    data: Dict[str, Any] = {"saer": SAER_VERSION}
    if reason:
        data["reason"] = reason
    if resolution:
        data["resolution"] = resolution
    if see:
        data["see"] = see
    if context:
        data.update(context)
    error["data"] = data
    return {
        "jsonrpc": "2.0",
        "id": request_id,
        "error": error,
    }


def _iso_now() -> str:
    """ISO 8601 timestamp with millisecond precision (A2A v1.0 requirement)."""
    now = datetime.now(timezone.utc)
    return now.strftime("%Y-%m-%dT%H:%M:%S.") + f"{now.microsecond // 1000:03d}Z"


# ---------------------------------------------------------------------------
# Task State Mapping
# ---------------------------------------------------------------------------

def _whispers_to_a2a_state(delivery_status: str, message_status: str = "new") -> str:
    """Map Whispers message states to A2A TaskState.

    Whispers delivery_status: queued, delivered, dead_lettered
    Whispers message status: new, read, replied
    """
    mapping = {
        ("queued", "new"): TASK_SUBMITTED,
        ("delivered", "new"): TASK_SUBMITTED,
        ("delivered", "read"): TASK_WORKING,
        ("delivered", "replied"): TASK_COMPLETED,
        ("dead_lettered", "new"): TASK_FAILED,
    }
    return mapping.get((delivery_status, message_status), TASK_SUBMITTED)


def _message_to_task(message: Dict[str, Any], task_id: Optional[str] = None) -> Dict[str, Any]:
    """Convert a Whispers message to an A2A Task object."""
    msg_uuid = message.get("uuid", str(uuid.uuid4()))
    delivery_status = message.get("delivery_status", "queued")
    message_status = message.get("status", "new")

    task = {
        "id": task_id or msg_uuid,
        "contextId": message.get("context_id") or message.get("trace_id") or msg_uuid,
        "status": {
            "state": _whispers_to_a2a_state(delivery_status, message_status),
            "timestamp": _iso_now(),
        },
        "artifacts": [],
        "metadata": {
            "whispers:messageId": msg_uuid,
            "whispers:sender": message.get("from_agent"),
            "whispers:recipient": message.get("to_agent"),
            "whispers:priority": message.get("priority", "routine"),
            "whispers:deliveryStatus": delivery_status,
        },
    }

    message_metadata = message.get("metadata")
    if isinstance(message_metadata, dict):
        for key in (
            "whispers:a2aMessageId",
            "whispers:a2aContextId",
            "whispers:schema",
            "whispers:wireMode",
            "whispers:signalClass",
            "whispers:2ackMirrorConflicts",
            "whispers:dispatchRejectReason",
        ):
            value = message_metadata.get(key)
            if value is not None:
                task["metadata"][key] = value

    # If there's a body, add it as an artifact
    body = message.get("body")
    if body:
        task["artifacts"].append({
            "artifactId": f"body-{msg_uuid[:8]}",
            "name": message.get("subject", "Message"),
            "parts": [{"text": body}],
        })

    # If there's a structured payload, add as data artifact
    payload = message.get("payload")
    if payload:
        try:
            payload_data = json.loads(payload) if isinstance(payload, str) else payload
            task["artifacts"].append({
                "artifactId": f"payload-{msg_uuid[:8]}",
                "name": "Structured Payload",
                "parts": [{"data": payload_data}],
            })
        except (json.JSONDecodeError, TypeError) as exc:
            logger.debug("Failed to parse payload for task artifact: %s", exc)

    return task


def _derive_twoack_subject(envelope: Dict[str, Any]) -> str:
    """Choose a human-useful subject for a validated 2ack envelope."""
    summary = envelope.get("summary")
    if isinstance(summary, dict):
        headline = summary.get("headline")
        if isinstance(headline, str) and headline.strip():
            return headline
    schema_id = envelope.get("schema")
    if isinstance(schema_id, str) and schema_id:
        return schema_id
    return "A2A Task"


# ---------------------------------------------------------------------------
# A2A Router Factory
# ---------------------------------------------------------------------------

def create_a2a_router(db, registry, dispatcher, server_url_fn) -> APIRouter:
    """Create the A2A FastAPI router.

    Args:
        db: WhispersDB instance
        registry: AgentRegistry instance
        dispatcher: Message dispatcher
        server_url_fn: Callable that returns the current server URL
    """
    router = APIRouter()

    # -----------------------------------------------------------------------
    # Agent Card Discovery
    # -----------------------------------------------------------------------

    @router.get("/.well-known/agent-card.json")
    def well_known_agent_card():
        """Serve the Whispers hub Agent Card (RFC 8615 discovery)."""
        return JSONResponse(
            content=generate_server_card(server_url_fn()),
            media_type="application/json",
        )

    @router.get("/agents/{callsign}/.well-known/agent-card.json")
    def agent_card(callsign: str):
        """Serve an individual agent's A2A Agent Card."""
        agent = registry.get_agent_by_callsign(callsign)
        if not agent:
            raise HTTPException(status_code=404, detail=f"Agent '{callsign}' not found")

        # Fetch live presence
        presence = None
        try:
            with db.get_connection() as conn:
                row = conn.execute(
                    "SELECT * FROM presence WHERE agent_name = ?", (callsign,)
                ).fetchone()
                if row:
                    presence = dict(row)
        except Exception as exc:
            logger.debug("Failed to fetch presence for agent card '%s': %s", callsign, exc)

        # Fetch runtime state
        runtime_state = None
        try:
            with db.get_connection() as conn:
                row = conn.execute(
                    "SELECT * FROM agent_runtime_state WHERE agent_name = ? ORDER BY updated_at DESC LIMIT 1",
                    (callsign,),
                ).fetchone()
                if row:
                    runtime_state = dict(row)
        except Exception as exc:
            logger.debug("Failed to fetch runtime state for agent card '%s': %s", callsign, exc)

        return JSONResponse(
            content=generate_agent_card(agent, server_url_fn(), presence, runtime_state),
            media_type="application/json",
        )

    @router.get("/a2a/agents")
    def list_agent_cards():
        """List all registered agents with their A2A Agent Cards.

        This is a Whispers extension endpoint — not part of the A2A spec,
        but useful for discovery across a hub with many agents.
        """
        try:
            with db.get_connection() as conn:
                agents = conn.execute(
                    "SELECT * FROM agent_cards WHERE deregistered_at IS NULL"
                ).fetchall()
                agents = [dict(a) for a in agents]
        except Exception as e:
            raise HTTPException(status_code=500, detail=str(e))

        cards = []
        for agent in agents:
            try:
                card = generate_agent_card(agent, server_url_fn())
                cards.append(card)
            except Exception:
                continue

        return JSONResponse(content={"agents": cards, "count": len(cards)})

    # -----------------------------------------------------------------------
    # JSON-RPC 2.0 Gateway
    # -----------------------------------------------------------------------

    # Map JSON-RPC methods to required Whispers scopes
    _METHOD_SCOPES = {
        "message/send": ["messages:send"],
        "message/stream": ["messages:send", "messages:stream"],
        "tasks/get": ["messages:read"],
        "tasks/cancel": ["messages:send"],
    }

    def _a2a_authenticate(request: Request, method: str, request_id: Any = None):
        """Validate Bearer token for A2A gateway requests.

        Returns (agent_name, token_row) on success.
        Returns a JSON-RPC error response dict on failure, or None if
        no auth is required for this deployment mode.
        """
        server_url = server_url_fn()
        auth_header = request.headers.get("authorization", "")
        if not auth_header.startswith("Bearer "):
            # No token — check if this is a deployment that requires auth
            # For now, allow unauthenticated access (the sender identity
            # comes from message metadata). This matches the initial
            # open-admission A2A interop posture.
            return None, None

        raw_token = auth_header[7:]
        token_row = db.get_api_token(raw_token)
        if not token_row:
            return None, _solution_aware_error(
                A2A_AUTH_INVALID,
                "Invalid or expired token",
                request_id,
                reason="The provided Bearer token is not recognized or has been revoked",
                resolution=(
                    "Request a new token via the /connect endpoint "
                    "or ask the hub operator to issue one via 'whispers token issue'"
                ),
                see="/.well-known/agent-card.json",
                context={
                    "auth_methods": ["bearer"],
                    "token_endpoint": "/connect",
                },
            )

        # Check scopes for this method
        import json as _json
        required = _METHOD_SCOPES.get(method, [])
        if required:
            scopes_raw = token_row.get("scopes")
            if scopes_raw is None:
                token_scopes = ["*"]
            elif isinstance(scopes_raw, str):
                try:
                    token_scopes = _json.loads(scopes_raw)
                except (ValueError, TypeError):
                    token_scopes = ["*"]
            else:
                token_scopes = scopes_raw

            # Wildcard checks
            has_wildcard = "*" in token_scopes or "admin:*" in token_scopes
            if not has_wildcard:
                for req_scope in required:
                    resource = req_scope.split(":")[0] if ":" in req_scope else req_scope
                    resource_wildcard = f"{resource}:*"
                    if req_scope not in token_scopes and resource_wildcard not in token_scopes:
                        return None, _solution_aware_error(
                            A2A_SCOPE_INSUFFICIENT,
                            f"Insufficient scope for method '{method}'",
                            request_id,
                            reason="Your token does not include the required scope for this method",
                            resolution=(
                                "Request a token with the required scopes from the hub operator"
                            ),
                            context={
                                "required_scopes": required,
                                "granted_scopes": token_scopes,
                                "method": method,
                                "whispers:suggested_profile": "external-agent",
                            },
                        )

        return token_row.get("agent_name"), token_row

    @router.post("/a2a/v1")
    async def a2a_gateway(request: Request):
        """A2A JSON-RPC 2.0 gateway endpoint.

        Dispatches JSON-RPC methods:
        - message/send: Send a message to a Whispers agent
        - tasks/get: Get task status by ID
        - tasks/cancel: Cancel a pending task
        """
        _SUPPORTED_METHODS = ["message/send", "message/stream", "tasks/get", "tasks/cancel"]

        content_length = request.headers.get("content-length")
        if content_length is not None:
            with_context = {"limit": A2A_MAX_REQUEST_BYTES, "limit_type": "max_a2a_request_bytes"}
            try:
                declared_size = int(content_length)
            except ValueError:
                declared_size = None
            if declared_size is not None and declared_size > A2A_MAX_REQUEST_BYTES:
                return JSONResponse(
                    content=_solution_aware_error(
                        JSONRPC_INVALID_REQUEST,
                        "Request body too large",
                        reason=(
                            f"Request body exceeds the maximum A2A request size of "
                            f"{A2A_MAX_REQUEST_BYTES} bytes."
                        ),
                        resolution="Send a smaller A2A request body or move large content to an artifact reference.",
                        context={**with_context, "attempted": declared_size},
                    ),
                    status_code=200,
                )

        try:
            raw_body = bytearray()
            async for chunk in request.stream():
                raw_body.extend(chunk)
                if len(raw_body) > A2A_MAX_REQUEST_BYTES:
                    return JSONResponse(
                        content=_solution_aware_error(
                            JSONRPC_INVALID_REQUEST,
                            "Request body too large",
                            reason=(
                                f"Request body exceeds the maximum A2A request size of "
                                f"{A2A_MAX_REQUEST_BYTES} bytes."
                            ),
                            resolution="Send a smaller A2A request body or move large content to an artifact reference.",
                            context={
                                "limit": A2A_MAX_REQUEST_BYTES,
                                "limit_type": "max_a2a_request_bytes",
                            },
                        ),
                        status_code=200,
                    )
            body = json.loads(raw_body)
        except Exception:
            return JSONResponse(
                content=_solution_aware_error(
                    JSONRPC_PARSE_ERROR,
                    "Parse error",
                    reason="Request body is not valid JSON",
                    resolution="Send a valid JSON-RPC 2.0 request body",
                ),
                status_code=200,  # JSON-RPC always returns 200
            )

        # Validate JSON-RPC 2.0 envelope
        if not isinstance(body, dict):
            return JSONResponse(
                content=_solution_aware_error(
                    JSONRPC_INVALID_REQUEST,
                    "Invalid Request",
                    reason="Request body must be a JSON object",
                    resolution="Send a JSON object with jsonrpc, method, params, and id fields",
                ),
                status_code=200,
            )

        jsonrpc = body.get("jsonrpc")
        method = body.get("method")
        params = body.get("params", {})
        request_id = body.get("id")
        request.state.jsonrpc_id = request_id

        if jsonrpc != "2.0":
            return JSONResponse(
                content=_solution_aware_error(
                    JSONRPC_INVALID_REQUEST,
                    "Invalid JSON-RPC version",
                    request_id,
                    reason="The 'jsonrpc' field must be exactly '2.0'",
                    resolution="Set the 'jsonrpc' field to '2.0' in your request",
                    context={
                        "example": {
                            "jsonrpc": "2.0",
                            "method": "message/send",
                            "params": {},
                            "id": "1",
                        },
                    },
                ),
                status_code=200,
            )

        if not method or not isinstance(method, str):
            return JSONResponse(
                content=_solution_aware_error(
                    JSONRPC_INVALID_REQUEST,
                    "Missing or invalid method",
                    request_id,
                    reason="The 'method' field must be a non-empty string",
                    resolution="Set the 'method' field to one of the supported methods",
                    context={"supported_methods": _SUPPORTED_METHODS},
                ),
                status_code=200,
            )

        # Authenticate if Bearer token is present
        auth_agent, auth_result = _a2a_authenticate(request, method, request_id)
        if isinstance(auth_result, dict) and "error" in auth_result:
            return JSONResponse(content=auth_result, status_code=200)

        # Dispatch to handler
        handlers = {
            "message/send": _handle_message_send,
            "message/stream": _handle_message_stream,
            "tasks/get": _handle_tasks_get,
            "tasks/cancel": _handle_tasks_cancel,
        }

        handler = handlers.get(method)
        if not handler:
            return JSONResponse(
                content=_solution_aware_error(
                    JSONRPC_METHOD_NOT_FOUND,
                    f"Method not found: '{method}'",
                    request_id,
                    reason="This A2A endpoint does not support the requested method",
                    resolution="Use one of the supported methods",
                    context={
                        "supported_methods": _SUPPORTED_METHODS,
                        "requested_method": method,
                    },
                ),
                status_code=200,
            )

        # SSE streaming methods return EventSourceResponse directly
        if method == "message/stream":
            try:
                return handler(params, request, request_id)
            except HTTPException as e:
                if isinstance(e.detail, dict) and e.detail.get("jsonrpc") == "2.0" and "error" in e.detail:
                    return JSONResponse(content=e.detail, status_code=200)
                return JSONResponse(
                    content=_jsonrpc_error(e.status_code, e.detail, request_id),
                    status_code=200,
                )
            except Exception as e:
                logger.exception("A2A gateway error (stream): %s", e)
                return JSONResponse(
                    content=_jsonrpc_error(JSONRPC_INTERNAL_ERROR, "Internal error", request_id),
                    status_code=200,
                )

        try:
            result = handler(params, request)
            return JSONResponse(
                content=_jsonrpc_response(result, request_id),
                status_code=200,
            )
        except HTTPException as e:
            if isinstance(e.detail, dict) and e.detail.get("jsonrpc") == "2.0" and "error" in e.detail:
                return JSONResponse(content=e.detail, status_code=200)
            return JSONResponse(
                content=_jsonrpc_error(
                    e.status_code,
                    e.detail,
                    request_id,
                ),
                status_code=200,
            )
        except Exception as e:
            logger.exception("A2A gateway error: %s", e)
            return JSONResponse(
                content=_jsonrpc_error(
                    JSONRPC_INTERNAL_ERROR,
                    "Internal error",
                    request_id,
                ),
                status_code=200,
            )

    # -----------------------------------------------------------------------
    # Shared A2A Message Extraction & Routing
    # -----------------------------------------------------------------------

    def _extract_and_route_message(
        params: Dict[str, Any],
        request_id: Any = None,
    ) -> Tuple[Optional[Dict[str, Any]], Dict[str, Any]]:
        """Parse A2A message params, resolve recipient, dispatch via Whispers.

        Returns (whispers_msg_dict, parsed_fields) on success, where
        parsed_fields contains task_id and context_id.

        Returns (None, error_response_dict) on failure — the caller
        returns the error dict directly as a JSONResponse.
        """
        message = params.get("message")
        if not message or not isinstance(message, dict):
            return None, _solution_aware_error(
                JSONRPC_INVALID_PARAMS,
                "Missing or invalid message",
                request_id,
                reason="The 'params.message' field must be a JSON object with 'parts' and optional metadata",
                resolution="Include a 'message' object in params with 'role', 'parts', and 'metadata' fields",
                context={
                    "example": {
                        "message": {
                            "role": "user",
                            "parts": [{"text": "hello"}],
                            "metadata": {"whispers:recipient": "agent-name"},
                        }
                    },
                },
            )

        parts = message.get("parts", [])
        context_id = message.get("contextId")
        task_id = message.get("taskId")

        # Extract text and structured data from A2A parts
        text_parts = [p["text"] for p in parts if "text" in p]
        data_parts = [p["data"] for p in parts if "data" in p]
        body = "\n".join(text_parts) if text_parts else None
        binding = extract_a2a_binding(message)

        # 2ack preflight runs BEFORE recipient resolution — the spec requires
        # that expired, hop-limited, or otherwise rejectable signals are caught
        # before any deeper processing (Section 6.2).
        if binding.envelope is not None:
            preflight = evaluate_preflight(binding.envelope, now=_iso_now())
            if preflight.rejected or preflight.deferred:
                status_phrase = "deferred" if preflight.deferred else "rejected"
                # 2ack P1: log protocol-level rejections as security events
                try:
                    db.record_security_event(
                        f"2ack_preflight_{status_phrase}",
                        status_phrase,
                        actor_agent=metadata.get("whispers:sender", "a2a-external") if "metadata" in dir() else "a2a-external",
                        endpoint="/a2a/v1",
                        detail={
                            "preflight_code": preflight.code,
                            "schema": preflight.surface.schema,
                            "message_id": preflight.surface.message_id,
                            "reason": preflight.reason,
                        },
                    )
                except Exception:
                    pass  # Don't block rejection on logging failure
                return None, _solution_aware_error(
                    JSONRPC_INVALID_PARAMS,
                    f"2ack preflight {status_phrase}",
                    request_id,
                    reason=preflight.reason or "The 2ack envelope failed preflight checks.",
                    resolution=(
                        "Fix the envelope's preflight fields before retrying."
                        if preflight.rejected
                        else "Wait for operator approval or route through an operator-capable path."
                    ),
                    context={
                        "protocol": "2ack",
                        "preflight_action": preflight.action,
                        "preflight_code": preflight.code,
                        "schema": preflight.surface.schema,
                        "message_id": preflight.surface.message_id,
                        "conflicts": list(binding.conflicts),
                    },
                )

        # Resolve recipient: metadata > @-prefix in body
        metadata = message.get("metadata", {})
        recipient = metadata.get("whispers:recipient")

        if not recipient and body and body.startswith("@"):
            at_split = body.split(":", 1)
            if len(at_split) == 2:
                recipient = at_split[0][1:].strip()
                body = at_split[1].strip()

        if not recipient:
            return None, _solution_aware_error(
                JSONRPC_INVALID_PARAMS,
                "Cannot determine message recipient",
                request_id,
                reason="No recipient specified in metadata or message body",
                resolution="Specify the recipient agent",
                see="/.well-known/agent-card.json",
                context={
                    "addressing_methods": [
                        {"method": "metadata", "field": "message.metadata.whispers:recipient", "value": "agent-callsign"},
                        {"method": "body_prefix", "format": "@agent-callsign: your message here"},
                    ],
                },
            )

        agent = registry.get_agent_by_callsign(recipient)
        if not agent:
            return None, _solution_aware_error(
                A2A_AGENT_NOT_FOUND,
                f"Agent not found: '{recipient}'",
                request_id,
                reason=f"No agent with callsign '{recipient}' is registered on this hub",
                resolution="Verify the callsign spelling. List registered agents at the discovery endpoint.",
                see="/.well-known/agent-card.json",
                context={"requested_agent": recipient},
            )

        sender = metadata.get("whispers:sender", "a2a-external")
        priority = metadata.get("whispers:priority", "routine")
        msg_type = metadata.get("whispers:type", "request")
        structured_payload: Any = None
        trace_id: Optional[str] = None
        reply_to: Optional[str] = None
        outbound_metadata = dict(metadata) if isinstance(metadata, dict) else {}

        if binding.envelope is not None:
            # Trust tier enforcement (2ack P1): now that we know the recipient,
            # check whether their trust tier satisfies the signal's tier_required.
            recipient_tier = agent.get("trust_tier", 1) if isinstance(agent, dict) else 1
            trust_policy = PreflightPolicy(receiver_trust_tier=recipient_tier)
            trust_check = evaluate_preflight(binding.envelope, now=_iso_now(), policy=trust_policy)
            if trust_check.rejected and trust_check.code == "ERR_TRUST_INSUFFICIENT":
                try:
                    db.record_security_event(
                        "2ack_trust_insufficient",
                        "rejected",
                        actor_agent=sender,
                        target_agent=recipient,
                        endpoint="/a2a/v1",
                        detail={
                            "preflight_code": trust_check.code,
                            "tier_required": trust_check.surface.tier_required,
                            "receiver_tier": recipient_tier,
                            "schema": trust_check.surface.schema,
                            "message_id": trust_check.surface.message_id,
                        },
                    )
                except Exception:
                    pass
                return None, _solution_aware_error(
                    JSONRPC_INVALID_PARAMS,
                    "2ack preflight rejected",
                    request_id,
                    reason=trust_check.reason or "Receiver trust tier insufficient.",
                    resolution="Route to a higher-trust agent or escalate to an operator.",
                    context={
                        "protocol": "2ack",
                        "preflight_action": "reject",
                        "preflight_code": trust_check.code,
                        "schema": trust_check.surface.schema,
                        "message_id": trust_check.surface.message_id,
                        "tier_required": trust_check.surface.tier_required,
                        "receiver_tier": recipient_tier,
                    },
                )

            # Preflight already ran structural checks above — skip to validation
            validation = validate_message(binding.envelope)
            if not validation.valid:
                return None, _solution_aware_error(
                    JSONRPC_INVALID_PARAMS,
                    "Invalid 2ack envelope",
                    request_id,
                    reason="The A2A DataPart claims to be a 2ack envelope but failed protocol validation.",
                    resolution="Fix the 2ack envelope fields or send generic structured JSON that does not claim 2ack.",
                    context={
                        "protocol": "2ack",
                        "errors": [
                            {"code": error.code, "path": error.path, "message": error.message}
                            for error in validation.errors
                        ],
                        "conflicts": list(binding.conflicts),
                    },
                )

            auth_err = validate_authority_claim(binding.envelope)
            if auth_err:
                try:
                    db.record_security_event(
                        "2ack_authority_failed",
                        "rejected",
                        actor_agent=sender,
                        target_agent=recipient,
                        endpoint="/a2a/v1",
                        detail={
                            "reason": auth_err,
                            "schema": binding.envelope.get("schema"),
                            "message_id": binding.envelope.get("trace", {}).get("message_id"),
                            "principal": (binding.envelope.get("authority") or {}).get("principal"),
                        },
                    )
                except Exception:
                    pass
                return None, _solution_aware_error(
                    JSONRPC_INVALID_PARAMS,
                    "Invalid authority claim",
                    request_id,
                    reason=auth_err,
                    resolution="Provide a valid authority proof when declaring a principal.",
                    context={"protocol": "2ack", "preflight_code": "ERR_DELEGATION_PROOF_REQUIRED"},
                )

            # 2ack P1: schemas that carry elevated risk require authority.
            # external_action_request.v1 with risk_level elevated/critical must
            # have an authority claim — you can't request dangerous actions anonymously.
            _AUTHORITY_REQUIRED_SCHEMAS = {
                "external_action_request.v1",
            }
            schema_id = binding.envelope.get("schema")
            payload_data = binding.envelope.get("payload", {})
            risk_level = payload_data.get("risk_level") if isinstance(payload_data, dict) else None

            if (
                schema_id in _AUTHORITY_REQUIRED_SCHEMAS
                and risk_level in ("elevated", "critical")
                and not isinstance(binding.envelope.get("authority"), dict)
            ):
                proof_err = (
                    f"Schema '{schema_id}' with risk_level '{risk_level}' requires "
                    f"an authority claim. Add authority.principal and authority_proof."
                )
                try:
                    db.record_security_event(
                        "2ack_authority_required",
                        "rejected",
                        actor_agent=sender,
                        target_agent=recipient,
                        endpoint="/a2a/v1",
                        detail={
                            "schema": schema_id,
                            "risk_level": risk_level,
                            "reason": proof_err,
                        },
                    )
                except Exception:
                    pass
                return None, _solution_aware_error(
                    JSONRPC_INVALID_PARAMS,
                    "Authority required for high-risk action",
                    request_id,
                    reason=proof_err,
                    resolution="Add authority.principal and authority_proof to the 2ack envelope.",
                    context={"protocol": "2ack", "preflight_code": "ERR_DELEGATION_PROOF_REQUIRED"},
                )

            structured_payload = binding.envelope
            body = body or binding.fallback_text or derive_text_fallback(binding.envelope)
            trace = binding.envelope.get("trace", {})
            if isinstance(trace, dict):
                trace_id = trace.get("trace_id")
                reply_to = trace.get("in_reply_to")
                context_id = context_id or trace.get("thread_id") or trace.get("trace_id")

                if reply_to:
                    try:
                        with db.get_connection() as conn:
                            row = conn.execute(
                                "SELECT * FROM messages WHERE uuid = ?", (reply_to,)
                            ).fetchone()
                            if row:
                                original_msg = dict(row)
                                if original_msg.get("payload"):
                                    schema_err = check_reply_schema_constraint(
                                        original_msg["payload"], binding.envelope
                                    )
                                    if schema_err:
                                        return None, _solution_aware_error(
                                            JSONRPC_INVALID_PARAMS,
                                            "Reply schema rejected by original sender",
                                            request_id,
                                            reason=schema_err,
                                            resolution="Use one of the schemas permitted by the original message's accept_schemas constraint.",
                                            context={"reply_schema": binding.envelope.get("schema")},
                                        )
                    except Exception as exc:
                        logger.warning("Failed to check reply schema constraint: %s", exc)

            outbound_metadata["whispers:a2aMessageId"] = message.get("messageId")
            if context_id:
                outbound_metadata["whispers:a2aContextId"] = context_id
            outbound_metadata["whispers:schema"] = binding.envelope.get("schema")
            if binding.envelope.get("mode") is not None:
                outbound_metadata["whispers:wireMode"] = binding.envelope.get("mode")
            if binding.envelope.get("signal_class") is not None:
                outbound_metadata["whispers:signalClass"] = binding.envelope.get("signal_class")
            if binding.conflicts:
                outbound_metadata["whispers:2ackMirrorConflicts"] = list(binding.conflicts)

            subject = metadata.get("whispers:subject") or _derive_twoack_subject(binding.envelope)
        else:
            if data_parts:
                structured_payload = data_parts[0] if len(data_parts) == 1 else {"a2a_data_parts": data_parts}
                outbound_metadata["whispers:a2aMessageId"] = message.get("messageId")
                if context_id:
                    outbound_metadata["whispers:a2aContextId"] = context_id

            subject = metadata.get("whispers:subject", "A2A Task")

        # Dispatch through Whispers
        from .client import WhispersClient, WhispersException

        client = WhispersClient(
            sender,
            db_path=db.db_path,
            read_only=True,
            agent_type="a2a_client",
        )
        client.dispatcher = dispatcher

        try:
            result = client.send(
                to=recipient,
                subject=subject,
                body=body,
                priority=priority,
                msg_type=msg_type,
                payload=structured_payload,
                trace_id=trace_id,
                context_id=context_id,
                reply_to=reply_to,
                metadata=outbound_metadata or None,
            )
        except WhispersException as exc:
            return None, _solution_aware_error(
                JSONRPC_INVALID_PARAMS,
                "Invalid Whispers message",
                request_id,
                reason=str(exc),
                resolution="Fix the 2ack envelope or routing fields and retry.",
                context={"protocol": "2ack"},
            )

        delivery_status = result.get("delivery_status") or result.get("status", "queued")
        whispers_msg = {
            "uuid": result.get("id", str(uuid.uuid4())),
            "from_agent": sender,
            "to_agent": recipient,
            "subject": subject,
            "body": body,
            "priority": priority,
            "delivery_status": delivery_status,
            "status": "new",
            "context_id": context_id,
            "trace_id": trace_id or result.get("trace_id"),
            "payload": structured_payload,
            "metadata": outbound_metadata or None,
        }
        if result.get("reason"):
            whispers_msg.setdefault("metadata", {})["whispers:dispatchRejectReason"] = result["reason"]

        parsed = {"task_id": task_id, "context_id": context_id}
        return whispers_msg, parsed

    # -----------------------------------------------------------------------
    # JSON-RPC Method Handlers
    # -----------------------------------------------------------------------

    def _handle_message_send(params: Dict[str, Any], request: Request) -> Dict[str, Any]:
        """Handle A2A message/send — route a message to a Whispers agent.

        Accepts A2A Message format, translates to Whispers message,
        routes through the social layer, returns an A2A Task.

        Includes SAER blind-send hint when message is queued
        (recipient offline).
        """
        request_id = getattr(request.state, 'jsonrpc_id', None)
        whispers_msg, parsed = _extract_and_route_message(params, request_id=request_id)
        # Error return — _extract_and_route_message returned (None, error_dict)
        if whispers_msg is None:
            raise HTTPException(status_code=400, detail=parsed)
        task_id = parsed["task_id"] or whispers_msg["uuid"]
        task = _message_to_task(whispers_msg, task_id=task_id)

        # SAER blind-send hint: when message queues because recipient
        # is offline, include an actionable hint in the response metadata.
        # This is a compiler-warning pattern — doesn't block, just helps.
        if whispers_msg.get("delivery_status") == "queued":
            task.setdefault("metadata", {})["whispers:hint"] = (
                "Message queued — recipient is offline. "
                "Consider retry with delay, or check agent availability "
                "before sending to avoid queued delivery."
            )

        return task

    def _handle_message_stream(
        params: Dict[str, Any], request: Request, request_id: Any
    ):
        """Handle A2A message/stream — SSE stream of task state updates.

        Per A2A spec: sends the message, then returns an SSE stream where
        each event's ``data`` field is a complete JSON-RPC 2.0 response
        containing the current Task object.  The stream closes once the
        task reaches a terminal state.
        """
        whispers_msg, parsed = _extract_and_route_message(params, request_id=request_id)
        # Error return
        if whispers_msg is None:
            raise HTTPException(status_code=400, detail=parsed)
        task_id = parsed["task_id"] or whispers_msg["uuid"]
        context_id = parsed["context_id"]
        msg_uuid = whispers_msg["uuid"]

        # Terminal A2A states — SSE stream closes on any of these
        _terminal = {TASK_COMPLETED, TASK_FAILED, TASK_CANCELED, TASK_REJECTED}

        async def _sse_generator():
            """Yield JSON-RPC responses as SSE events until terminal state."""
            # Emit initial state immediately
            initial_task = _message_to_task(whispers_msg, task_id=task_id)
            yield {
                "event": "message",
                "data": json.dumps(_jsonrpc_response(initial_task, request_id)),
            }

            if initial_task["status"]["state"] in _terminal:
                return

            # Poll for state transitions with adaptive interval:
            #   starts at 500ms, ramps to 2s — balances latency vs DB load
            poll_interval = 0.5
            max_duration_seconds = 300  # 5 minute ceiling
            elapsed = 0.0
            last_state = initial_task["status"]["state"]

            while elapsed < max_duration_seconds:
                await asyncio.sleep(poll_interval)
                elapsed += poll_interval

                # Re-read message from DB for state changes
                try:
                    with db.get_connection() as conn:
                        row = conn.execute(
                            "SELECT * FROM messages WHERE uuid = ?", (msg_uuid,)
                        ).fetchone()
                        if not row:
                            # Message vanished — emit FAILED and close stream
                            err_task = {
                                "id": task_id,
                                "contextId": context_id or msg_uuid,
                                "status": {
                                    "state": TASK_FAILED,
                                    "timestamp": _iso_now(),
                                    "message": {
                                        "role": "agent",
                                        "parts": [{"text": "Task message not found"}],
                                        "messageId": str(uuid.uuid4()),
                                    },
                                },
                                "artifacts": [],
                                "metadata": {},
                            }
                            yield {
                                "event": "message",
                                "data": json.dumps(
                                    _jsonrpc_response(err_task, request_id)
                                ),
                            }
                            return

                        current_msg = dict(row)
                except Exception as exc:
                    logger.warning("A2A SSE poll error: %s", exc)
                    continue

                current_task = _message_to_task(current_msg, task_id=task_id)
                current_state = current_task["status"]["state"]

                # Only emit on state change — no noisy duplicates
                if current_state != last_state:
                    yield {
                        "event": "message",
                        "data": json.dumps(
                            _jsonrpc_response(current_task, request_id)
                        ),
                    }
                    last_state = current_state

                    if current_state in _terminal:
                        return

                # Adaptive backoff — fast at first, relaxes over time
                if poll_interval < 2.0:
                    poll_interval = min(poll_interval * 1.5, 2.0)

        return EventSourceResponse(_sse_generator())

    def _handle_tasks_get(params: Dict[str, Any], request: Request) -> Dict[str, Any]:
        """Handle A2A tasks/get — fetch task status by ID.

        Since A2A tasks map to Whispers messages, we look up by message UUID.
        """
        task_id = params.get("taskId") or params.get("id")
        if not task_id:
            raise HTTPException(
                status_code=400,
                detail=_solution_aware_error(
                    JSONRPC_INVALID_PARAMS,
                    "Missing taskId",
                    reason="The 'taskId' (or 'id') parameter is required for tasks/get",
                    resolution="Include 'taskId' in the params object",
                    context={"example": {"taskId": "<uuid-from-message/send-result>"}},
                ),
            )

        # Look up the Whispers message by UUID
        try:
            with db.get_connection() as conn:
                row = conn.execute(
                    "SELECT * FROM messages WHERE uuid = ?", (task_id,)
                ).fetchone()
                if not row:
                    return _solution_aware_error(
                        A2A_TASK_NOT_FOUND,
                        f"Task not found: '{task_id}'",
                        reason="No task (message) with this ID exists on the hub",
                        resolution=(
                            "Verify the task ID. Task IDs are returned in the result "
                            "of message/send. Messages older than the retention window "
                            "may have been removed."
                        ),
                        context={"requested_id": task_id},
                    )
                message = dict(row)
        except Exception as e:
            raise HTTPException(status_code=500, detail=str(e))

        return _message_to_task(message, task_id=task_id)

    def _handle_tasks_cancel(params: Dict[str, Any], request: Request) -> Dict[str, Any]:
        """Handle A2A tasks/cancel — cancel a pending task.

        Only tasks in non-terminal states can be canceled.
        """
        task_id = params.get("taskId") or params.get("id")
        if not task_id:
            raise HTTPException(
                status_code=400,
                detail=_solution_aware_error(
                    JSONRPC_INVALID_PARAMS,
                    "Missing taskId",
                    reason="The 'taskId' (or 'id') parameter is required for tasks/cancel",
                    resolution="Include 'taskId' in the params object",
                    context={"example": {"taskId": "<uuid-from-message/send-result>"}},
                ),
            )

        _cancelable = {TASK_SUBMITTED, TASK_WORKING, TASK_INPUT_REQUIRED}

        try:
            with db.get_connection() as conn:
                row = conn.execute(
                    "SELECT * FROM messages WHERE uuid = ?", (task_id,)
                ).fetchone()
                if not row:
                    return _solution_aware_error(
                        A2A_TASK_NOT_FOUND,
                        f"Task not found: '{task_id}'",
                        reason="No task (message) with this ID exists on the hub",
                        resolution="Verify the task ID",
                        context={"requested_id": task_id},
                    )

                message = dict(row)
                current_state = _whispers_to_a2a_state(
                    message.get("delivery_status", "queued"),
                    message.get("status", "new"),
                )

                # Check if task is in a terminal state
                terminal_states = {TASK_COMPLETED, TASK_FAILED, TASK_CANCELED, TASK_REJECTED}
                if current_state in terminal_states:
                    return _solution_aware_error(
                        A2A_TASK_NOT_CANCELABLE,
                        "Task cannot be canceled",
                        reason=f"Task is in terminal state '{current_state}' and cannot be modified",
                        resolution="Only tasks in non-terminal states can be canceled",
                        context={
                            "current_state": current_state,
                            "cancelable_states": sorted(_cancelable),
                            "task_id": task_id,
                        },
                    )

                # Cancel by dead-lettering the message
                conn.execute(
                    "UPDATE messages SET delivery_status = 'dead_lettered' WHERE uuid = ?",
                    (task_id,),
                )
                conn.commit()

                message["delivery_status"] = "dead_lettered"
                task = _message_to_task(message, task_id=task_id)
                task["status"]["state"] = TASK_CANCELED
                return task

        except Exception as e:
            raise HTTPException(status_code=500, detail=str(e))

    return router


# ---------------------------------------------------------------------------
# Outbound A2A Client
# ---------------------------------------------------------------------------

class A2AClient:
    """Send tasks TO external A2A agents.

    Whispers agents call this to interact with any A2A-compliant endpoint.
    Fetches Agent Cards for discovery, supports message/send and message/stream.
    """

    def __init__(self, endpoint_url: str, *, timeout: float = 30.0):
        self.endpoint_url = endpoint_url.rstrip("/")
        self.timeout = timeout
        self._agent_card: Optional[Dict[str, Any]] = None

    # ------------------------------------------------------------------
    # Agent Card discovery
    # ------------------------------------------------------------------

    def discover(self) -> Dict[str, Any]:
        """Fetch the remote agent's Agent Card from well-known URI."""
        # Derive base URL from endpoint (strip /a2a/v1 etc.)
        base = self.endpoint_url
        for suffix in ("/a2a/v1", "/a2a"):
            if base.endswith(suffix):
                base = base[: -len(suffix)]
                break

        card_url = f"{base}/.well-known/agent-card.json"
        req = urllib.request.Request(card_url, method="GET")
        req.add_header("Accept", "application/json")
        req.add_header("User-Agent", f"whispers/{WHISPERS_VERSION}")

        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                self._agent_card = json.loads(resp.read())
        except (urllib.error.URLError, urllib.error.HTTPError) as exc:
            raise ConnectionError(f"Failed to fetch Agent Card from {card_url}: {exc}") from exc

        return self._agent_card

    @property
    def agent_card(self) -> Optional[Dict[str, Any]]:
        return self._agent_card

    # ------------------------------------------------------------------
    # JSON-RPC helper
    # ------------------------------------------------------------------

    def _rpc_request(
        self,
        method: str,
        params: Dict[str, Any],
        *,
        request_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Send a JSON-RPC 2.0 request and return the parsed response."""
        rpc_id = request_id or str(uuid.uuid4())
        payload = {
            "jsonrpc": "2.0",
            "method": method,
            "params": params,
            "id": rpc_id,
        }

        data = json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(
            self.endpoint_url,
            data=data,
            method="POST",
        )
        req.add_header("Content-Type", "application/json")
        req.add_header("Accept", "application/json")
        req.add_header("User-Agent", f"whispers/{WHISPERS_VERSION}")

        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                response = json.loads(resp.read())
        except urllib.error.HTTPError as exc:
            body = exc.read().decode("utf-8", errors="replace")
            raise ConnectionError(
                f"A2A RPC {method} failed ({exc.code}): {body}"
            ) from exc
        except urllib.error.URLError as exc:
            raise ConnectionError(
                f"A2A RPC {method} failed: {exc.reason}"
            ) from exc

        if "error" in response:
            err = response["error"]
            raise RuntimeError(
                f"A2A RPC error {err.get('code')}: {err.get('message')}"
            )

        return response

    # ------------------------------------------------------------------
    # message/send
    # ------------------------------------------------------------------

    def send(
        self,
        text: str,
        *,
        metadata: Optional[Dict[str, Any]] = None,
        task_id: Optional[str] = None,
        context_id: Optional[str] = None,
        request_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Send a message/send request. Returns the Task result."""
        message: Dict[str, Any] = {
            "role": "user",
            "parts": [{"text": text}],
            "messageId": str(uuid.uuid4()),
        }
        if metadata:
            message["metadata"] = metadata
        if task_id:
            message["taskId"] = task_id
        if context_id:
            message["contextId"] = context_id

        response = self._rpc_request(
            "message/send",
            {"message": message},
            request_id=request_id,
        )
        return response.get("result", response)

    # ------------------------------------------------------------------
    # message/stream (SSE)
    # ------------------------------------------------------------------

    def stream(
        self,
        text: str,
        *,
        metadata: Optional[Dict[str, Any]] = None,
        task_id: Optional[str] = None,
        context_id: Optional[str] = None,
        request_id: Optional[str] = None,
    ) -> Generator[Dict[str, Any], None, None]:
        """Send a message/stream request.  Yields Task updates from the SSE stream."""
        rpc_id = request_id or str(uuid.uuid4())
        message: Dict[str, Any] = {
            "role": "user",
            "parts": [{"text": text}],
            "messageId": str(uuid.uuid4()),
        }
        if metadata:
            message["metadata"] = metadata
        if task_id:
            message["taskId"] = task_id
        if context_id:
            message["contextId"] = context_id

        payload = {
            "jsonrpc": "2.0",
            "method": "message/stream",
            "params": {"message": message},
            "id": rpc_id,
        }

        data = json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(
            self.endpoint_url,
            data=data,
            method="POST",
        )
        req.add_header("Content-Type", "application/json")
        req.add_header("Accept", "text/event-stream")
        req.add_header("User-Agent", f"whispers/{WHISPERS_VERSION}")

        try:
            resp = urllib.request.urlopen(req, timeout=self.timeout)
        except urllib.error.HTTPError as exc:
            body = exc.read().decode("utf-8", errors="replace")
            raise ConnectionError(
                f"A2A stream failed ({exc.code}): {body}"
            ) from exc
        except urllib.error.URLError as exc:
            raise ConnectionError(
                f"A2A stream failed: {exc.reason}"
            ) from exc

        # Parse SSE: look for lines starting with "data: "
        try:
            for raw_line in resp:
                line = raw_line.decode("utf-8", errors="replace").rstrip("\r\n")
                if line.startswith("data:"):
                    json_str = line[5:].strip()
                    if not json_str:
                        continue
                    try:
                        event_data = json.loads(json_str)
                        task = event_data.get("result", event_data)
                        yield task

                        # Stop on terminal state
                        state = ""
                        if isinstance(task, dict):
                            status = task.get("status", {})
                            if isinstance(status, dict):
                                state = status.get("state", "")
                        if state in {
                            TASK_COMPLETED,
                            TASK_FAILED,
                            TASK_CANCELED,
                            TASK_REJECTED,
                        }:
                            return
                    except json.JSONDecodeError:
                        continue
        finally:
            resp.close()
