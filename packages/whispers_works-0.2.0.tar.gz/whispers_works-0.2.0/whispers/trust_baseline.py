from __future__ import annotations

from typing import Optional


_BASELINE_TRUST_TIERS = {
    "whispers-server": 5,
    "whispers-console": 5,
    "codex": 5,
    "claude-code": 5,
    "antigravity": 5,
    "cursor": 3,
    "vscode": 3,
    "windsurf": 3,
    "claude": 3,
    "gemini": 3,
}


def baseline_trust_tier(
    callsign: str,
    *,
    agent_type: Optional[str] = None,
    display_name: Optional[str] = None,
) -> Optional[int]:
    normalized = str(callsign or "").strip().lower()
    if not normalized:
        return None

    override = _BASELINE_TRUST_TIERS.get(normalized)
    if override is not None:
        return override

    normalized_agent_type = str(agent_type or "").strip().lower()
    normalized_display_name = str(display_name or "").strip().lower()
    if normalized in {"whispers-server", "whispers-console"}:
        return 5
    if normalized_agent_type == "infrastructure" and normalized.startswith("whispers-"):
        return 5
    if "whispers console" in normalized_display_name:
        return 5
    return None
