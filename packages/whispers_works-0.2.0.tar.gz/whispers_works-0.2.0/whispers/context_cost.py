"""
Context-cost estimation substrate.

This module provides a conservative first-pass answer to:
how expensive is a message for a specific recipient right now, and what
delivery depth should the runtime recommend before spending a full model turn?

The estimator is intentionally lightweight:
- heuristic token estimation instead of provider-specific tokenizers
- explicit recipient overrides when known
- conservative recommendations when a recipient is already heavily loaded
"""

from __future__ import annotations

from dataclasses import dataclass, field
import json
import math
from typing import Any, Literal


ContextDeliveryRecommendation = Literal["full", "summarize", "headline_only", "defer"]
MessageSizeTier = Literal["signal", "message", "document", "artifact", "bulk"]
SuggestedTransport = Literal["direct_send", "layered_send", "artifact_reference", "defer"]


def _clamp_float(value: float, low: float, high: float) -> float:
    return max(low, min(high, value))


def infer_context_window_tokens(model_id: str | None) -> int:
    """
    Return a conservative context-window estimate for a model family.

    The values are heuristics for routing and pacing, not provider guarantees.
    Callers can always override with an explicit `context_window_tokens`.
    """

    normalized = str(model_id or "").strip().lower()
    if not normalized:
        return 128_000
    if "gemini" in normalized:
        return 1_000_000
    if "claude" in normalized:
        return 200_000
    if "gpt" in normalized or "o3" in normalized or "o4" in normalized:
        return 128_000
    return 128_000


def estimate_text_tokens(text: str) -> int:
    """
    Approximate token count without a model-specific tokenizer.

    We intentionally bias slightly high so routing is conservative.
    """

    if not text:
        return 0
    stripped = text.strip()
    if not stripped:
        return 0
    char_estimate = math.ceil(len(stripped) / 4)
    word_estimate = math.ceil(len(stripped.split()) * 1.35)
    line_break_penalty = stripped.count("\n")
    return max(char_estimate, word_estimate) + line_break_penalty


def estimate_message_tokens(
    *,
    subject: str | None = None,
    body: str | None = None,
    payload: Any | None = None,
) -> int:
    payload_text = ""
    if payload is not None:
        if isinstance(payload, str):
            payload_text = payload
        else:
            payload_text = json.dumps(payload, sort_keys=True, separators=(",", ":"))
    combined = "\n".join(
        part for part in (subject or "", body or "", payload_text) if part
    )
    return estimate_text_tokens(combined)


def classify_message_size_tier(estimated_tokens: int) -> MessageSizeTier:
    if estimated_tokens < 256:
        return "signal"
    if estimated_tokens < 8_000:
        return "message"
    if estimated_tokens < 128_000:
        return "document"
    if estimated_tokens < 2_500_000:
        return "artifact"
    return "bulk"


@dataclass(frozen=True)
class ContextCostRecipient:
    callsign: str
    model_id: str | None = None
    context_load: float = 0.0
    context_window_tokens: int | None = None
    interruptibility: str | None = None
    max_receive_rate: int | None = None

    def effective_context_window(self) -> int:
        if self.context_window_tokens and self.context_window_tokens > 0:
            return int(self.context_window_tokens)
        return infer_context_window_tokens(self.model_id)


@dataclass(frozen=True)
class ContextCostEstimate:
    recipient: str
    model_id: str | None
    estimated_tokens: int
    message_size_tier: MessageSizeTier
    context_window_tokens: int
    current_load: float
    current_tokens_used: int
    remaining_tokens_estimate: int
    projected_load: float
    recommendation: ContextDeliveryRecommendation
    reasons: list[str] = field(default_factory=list)


@dataclass(frozen=True)
class ContextBudgetStatus:
    recipient: str
    model_id: str | None
    context_window_tokens: int
    current_load: float
    current_tokens_used: int
    remaining_tokens_estimate: int
    default_delivery_depth: ContextDeliveryRecommendation
    reasons: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "recipient": self.recipient,
            "model_id": self.model_id,
            "context_window_tokens": self.context_window_tokens,
            "current_load": self.current_load,
            "current_tokens_used": self.current_tokens_used,
            "remaining_tokens_estimate": self.remaining_tokens_estimate,
            "default_delivery_depth": self.default_delivery_depth,
            "reasons": list(self.reasons),
        }


@dataclass(frozen=True)
class MessageSizeCheck:
    recipient: str
    model_id: str | None
    interruptibility: str | None
    estimated_tokens: int
    message_size_tier: MessageSizeTier
    context_window_tokens: int
    current_load: float
    projected_load: float
    remaining_tokens_estimate: int
    recommended_delivery_depth: ContextDeliveryRecommendation
    suggested_transport: SuggestedTransport
    available_layers: list[str] = field(default_factory=list)
    missing_layers: list[str] = field(default_factory=list)
    reasons: list[str] = field(default_factory=list)
    max_receive_rate: int | None = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "recipient": self.recipient,
            "model_id": self.model_id,
            "interruptibility": self.interruptibility,
            "estimated_tokens": self.estimated_tokens,
            "message_size_tier": self.message_size_tier,
            "context_window_tokens": self.context_window_tokens,
            "current_load": self.current_load,
            "projected_load": self.projected_load,
            "remaining_tokens_estimate": self.remaining_tokens_estimate,
            "recommended_delivery_depth": self.recommended_delivery_depth,
            "suggested_transport": self.suggested_transport,
            "available_layers": list(self.available_layers),
            "missing_layers": list(self.missing_layers),
            "reasons": list(self.reasons),
            "max_receive_rate": self.max_receive_rate,
        }


_DELIVERY_DEPTH_ORDER: dict[ContextDeliveryRecommendation, int] = {
    "full": 0,
    "summarize": 1,
    "headline_only": 2,
    "defer": 3,
}


def _disclosure_level_to_recommendation(level: str) -> ContextDeliveryRecommendation:
    if level == "headline":
        return "headline_only"
    if level == "summary":
        return "summarize"
    return "full"


def _more_conservative_delivery(
    left: ContextDeliveryRecommendation,
    right: ContextDeliveryRecommendation,
) -> ContextDeliveryRecommendation:
    if _DELIVERY_DEPTH_ORDER[left] >= _DELIVERY_DEPTH_ORDER[right]:
        return left
    return right


def _infer_suggested_transport(
    recommendation: ContextDeliveryRecommendation,
    message_size_tier: MessageSizeTier,
) -> SuggestedTransport:
    if recommendation == "defer":
        return "defer"
    if message_size_tier in ("artifact", "bulk"):
        return "artifact_reference"
    if recommendation in ("summarize", "headline_only"):
        return "layered_send"
    return "direct_send"


def summarize_context_budget(recipient: ContextCostRecipient) -> ContextBudgetStatus:
    """
    Summarize the recipient's current context headroom without assuming a message.

    This is the lightweight substrate for startup/operator surfaces that need to
    know whether full packets are fine right now or whether summaries/headlines
    should be preferred until load drops.
    """

    window_tokens = recipient.effective_context_window()
    current_load = _clamp_float(float(recipient.context_load or 0.0), 0.0, 1.0)
    current_tokens_used = int(window_tokens * current_load)
    remaining_tokens = max(window_tokens - current_tokens_used, 0)

    reasons: list[str] = []
    default_delivery_depth: ContextDeliveryRecommendation = "full"
    if current_load >= 0.95:
        default_delivery_depth = "defer"
        reasons.append("recipient is already effectively saturated")
    elif current_load >= 0.85:
        default_delivery_depth = "headline_only"
        reasons.append("only headline delivery is safe until load drops")
    elif current_load >= 0.65:
        default_delivery_depth = "summarize"
        reasons.append("prefer summary delivery while load remains elevated")
    else:
        reasons.append("recipient has enough headroom for normal delivery")

    return ContextBudgetStatus(
        recipient=recipient.callsign,
        model_id=recipient.model_id,
        context_window_tokens=window_tokens,
        current_load=current_load,
        current_tokens_used=current_tokens_used,
        remaining_tokens_estimate=remaining_tokens,
        default_delivery_depth=default_delivery_depth,
        reasons=reasons,
    )


def estimate_context_cost(
    recipient: ContextCostRecipient,
    *,
    subject: str | None = None,
    body: str | None = None,
    payload: Any | None = None,
) -> ContextCostEstimate:
    window_tokens = recipient.effective_context_window()
    current_load = _clamp_float(float(recipient.context_load or 0.0), 0.0, 1.0)
    estimated_tokens = estimate_message_tokens(subject=subject, body=body, payload=payload)
    current_tokens_used = int(window_tokens * current_load)
    remaining_tokens = max(window_tokens - current_tokens_used, 0)
    projected_tokens = current_tokens_used + estimated_tokens
    projected_load = _clamp_float(projected_tokens / max(window_tokens, 1), 0.0, 1.0)
    message_size_tier = classify_message_size_tier(estimated_tokens)

    reasons: list[str] = []
    recommendation: ContextDeliveryRecommendation = "full"

    if current_load >= 0.95:
        recommendation = "defer"
        reasons.append("recipient already effectively saturated")
    elif estimated_tokens > remaining_tokens:
        recommendation = "defer"
        reasons.append("message exceeds estimated remaining context budget")
    elif current_load >= 0.85 or projected_load >= 0.95:
        recommendation = "headline_only"
        reasons.append("recipient is near overload; only minimal delivery is safe")
    elif (
        projected_load >= 0.8
        or estimated_tokens >= max(remaining_tokens // 2, 4_000)
        or (current_load >= 0.5 and estimated_tokens >= 8_000)
    ):
        recommendation = "summarize"
        reasons.append("message would consume a large share of remaining context")
    else:
        reasons.append("message fits within current context budget")

    if message_size_tier in ("artifact", "bulk"):
        if recommendation == "full":
            recommendation = "summarize"
        reasons.append("large payload should prefer reference-style or layered delivery")

    return ContextCostEstimate(
        recipient=recipient.callsign,
        model_id=recipient.model_id,
        estimated_tokens=estimated_tokens,
        message_size_tier=message_size_tier,
        context_window_tokens=window_tokens,
        current_load=current_load,
        current_tokens_used=current_tokens_used,
        remaining_tokens_estimate=remaining_tokens,
        projected_load=projected_load,
        recommendation=recommendation,
        reasons=reasons,
    )


def negotiate_message_size(
    recipient: ContextCostRecipient,
    *,
    subject: str | None = None,
    body: str | None = None,
    payload: Any | None = None,
    priority: str = "routine",
    headline: str | None = None,
    summary: str | None = None,
) -> MessageSizeCheck:
    """
    Produce a pre-send delivery recommendation for the specific recipient.

    This is advisory only. It does not mutate or block the actual send path.
    """

    from .progressive_disclosure import select_disclosure_level

    estimate = estimate_context_cost(
        recipient,
        subject=subject,
        body=body,
        payload=payload,
    )
    disclosure_level = select_disclosure_level(
        context_load=recipient.context_load,
        interruptibility=recipient.interruptibility,
        priority=priority,
    )
    disclosure_recommendation = _disclosure_level_to_recommendation(disclosure_level)
    recommended_delivery_depth = _more_conservative_delivery(
        estimate.recommendation,
        disclosure_recommendation,
    )
    suggested_transport = _infer_suggested_transport(
        recommended_delivery_depth,
        estimate.message_size_tier,
    )

    reasons = list(estimate.reasons)
    if _DELIVERY_DEPTH_ORDER[disclosure_recommendation] > _DELIVERY_DEPTH_ORDER[estimate.recommendation]:
        if recipient.interruptibility == "do_not_interrupt":
            reasons.append("recipient interruptibility requires minimal delivery")
        elif recipient.interruptibility == "urgent_only":
            reasons.append("recipient interruptibility favors summarized delivery")

    available_layers: list[str] = []
    if headline:
        available_layers.append("headline")
    if summary:
        available_layers.append("summary")
    if body or payload is not None:
        available_layers.append("full")

    missing_layers: list[str] = []
    if recommended_delivery_depth == "headline_only" and "headline" not in available_layers:
        missing_layers.append("headline")
    elif recommended_delivery_depth == "summarize" and "summary" not in available_layers:
        missing_layers.append("summary")

    if suggested_transport == "artifact_reference" and "summary" not in available_layers:
        if "summary" not in missing_layers:
            missing_layers.append("summary")
        reasons.append("large payload should ship as an artifact reference plus summary")

    if missing_layers:
        reasons.append(f"sender has not provided: {', '.join(missing_layers)}")

    return MessageSizeCheck(
        recipient=estimate.recipient,
        model_id=estimate.model_id,
        interruptibility=recipient.interruptibility,
        estimated_tokens=estimate.estimated_tokens,
        message_size_tier=estimate.message_size_tier,
        context_window_tokens=estimate.context_window_tokens,
        current_load=estimate.current_load,
        projected_load=estimate.projected_load,
        remaining_tokens_estimate=estimate.remaining_tokens_estimate,
        recommended_delivery_depth=recommended_delivery_depth,
        suggested_transport=suggested_transport,
        available_layers=available_layers,
        missing_layers=missing_layers,
        reasons=reasons,
        max_receive_rate=recipient.max_receive_rate,
    )
