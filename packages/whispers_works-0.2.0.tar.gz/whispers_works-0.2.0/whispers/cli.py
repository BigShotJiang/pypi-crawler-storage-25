import difflib
import os
import contextlib
import json
import logging
import sqlite3
import shutil
import socket
import signal
import subprocess
import sys
import time
import uuid
import urllib.request
import urllib.error
import urllib.parse

import click

from .client import WhispersClient, _attach_status_story
from .envelope import AcknowledgmentState, MsgType, classify_queue_class
from .identity import normalize_callsign_part, suggest_callsign, suggest_display_name
from .path_utils import abbreviate_home, resolve_path, whispers_path
from .process_utils import read_pid_file as _read_server_pid, is_pid_alive as _is_pid_alive
from .time_utils import format_local_timestamp, local_timezone_label, utc_now_iso

_LISTENER_POLICY_MODES = {
    "listen_only": {"mode": "listen_only", "auto_ack_state": None, "checkpoint_on_wake": False},
    "auto_ack_processed": {"mode": "auto_ack_processed", "auto_ack_state": "processed", "checkpoint_on_wake": False},
    "auto_ack_processed_checkpoint": {
        "mode": "auto_ack_processed_checkpoint",
        "auto_ack_state": "processed",
        "checkpoint_on_wake": True,
    },
    "auto_ack_insufficient_context": {
        "mode": "auto_ack_insufficient_context",
        "auto_ack_state": "insufficient_context",
        "checkpoint_on_wake": False,
    },
}
_VALID_MSG_TYPES = tuple(msg.value for msg in MsgType)


@click.group()
def cli():
    """Whispers CLI for Ops and Debugging."""
    pass


# Captures the most recent MCP probe so startup diagnostics can distinguish
# server warmup, token rejection, and endpoint problems.
_LAST_MCP_HANDSHAKE = None
_LAST_LOCAL_SERVER_PROBE_ISSUE = None


def _display_timestamp(value, *, fallback: str = "-") -> str:
    return format_local_timestamp(value) or (str(value) if value else fallback)


def _build_status_startup_capsule(client: WhispersClient, status_snapshot: dict) -> dict:
    """Build the briefing capsule used to project startup truth onto CLI status."""
    try:
        from .connection_story import build_briefing_capsule

        story = client.get_connection_story(status_snapshot=dict(status_snapshot))
        story.local_client_auth_healthy = status_snapshot.get("local_client_auth_healthy")
        story.local_client_token_source = status_snapshot.get("local_client_token_source")
        story.local_client_auth_issue = status_snapshot.get("local_client_auth_issue")
        return build_briefing_capsule(story)
    except Exception:
        return {}


def _extract_status_follow_through_lines(capsule: dict) -> list[str]:
    interesting_prefixes = (
        "Since last session:",
        "Resume focus:",
        "Huddle nearby:",
        "Captain alert:",
        "Team alert:",
        "Coordination:",
        "Coordination now:",
        "BATON state:",
        "Blocking now:",
        "Hot reply:",
        "Hot thread:",
        "Jolt:",
        "Suggested next action:",
    )
    lines: list[str] = []
    seen: set[str] = set()
    detail_block = str(capsule.get("detail_block") or "")
    status_line = str(capsule.get("status_line") or "")
    for raw in detail_block.splitlines():
        line = raw.rstrip()
        stripped = line.strip()
        if not stripped or stripped == status_line:
            continue
        if (
            stripped.startswith("Local time:")
            or stripped.startswith("Deployment:")
            or stripped.startswith("Peers online:")
            or stripped.startswith("Unread by priority:")
            or stripped.startswith("Startup/client auth:")
            or stripped.startswith("Startup rule:")
        ):
            continue
        if (
            any(stripped.startswith(prefix) for prefix in interesting_prefixes)
            or line.startswith("  \u2190")
            or line.startswith("  \u2192")
            or line.startswith("  \u2194")
        ):
            if line not in seen:
                lines.append(line)
                seen.add(line)
    return lines


def _status_follow_through_lines(client: WhispersClient, status_snapshot: dict) -> list[str]:
    """Surface the most actionable startup-truth lines on direct status surfaces."""
    return _extract_status_follow_through_lines(
        _build_status_startup_capsule(client, status_snapshot)
    )


def _build_outbox_snapshot(agent_name: str, messages: list[dict]) -> dict:
    return {
        "agent_name": agent_name,
        "state": "messages" if messages else "empty",
        "message_count": len(messages),
        "messages": messages,
    }


def _format_send_receipt(result: dict, *, recipient: str) -> str:
    status = str(result.get("status") or "").strip().lower()
    delivery_status = str(
        result.get("delivery_status")
        or ("dead_lettered" if status == "dead_lettered" else "queued")
    ).strip().lower()

    return f"Message {delivery_status}. ID: {result['id']}"


def _normalize_cli_msg_type(value: str) -> str:
    normalized = str(value or "").strip().lower()
    if normalized in _VALID_MSG_TYPES:
        return normalized
    if normalized == "reply":
        raise click.ClickException(
            "Invalid --msg-type 'reply'. In Whispers, replies use --reply-to plus a normal "
            "message type such as inform, accept, reject, or checkpoint."
        )
    suggestion = difflib.get_close_matches(normalized, _VALID_MSG_TYPES, n=1, cutoff=0.6)
    if suggestion:
        raise click.ClickException(
            f"Invalid --msg-type '{value}'. Did you mean '{suggestion[0]}'?"
        )
    raise click.ClickException(
        f"Invalid --msg-type '{value}'. Valid values: {', '.join(_VALID_MSG_TYPES)}."
    )


def _wake_model_label(value) -> str | None:
    normalized = str(value or "").strip().lower()
    if normalized == "listener_backed":
        return "SELF-WAKING"
    if normalized == "manual_wake":
        return "MANUAL-WAKE"
    if normalized == "operator_console":
        return "CONSOLE"
    if normalized == "mixed":
        return "MIXED"
    return None


def _manual_wake_has_jolt_path(payload) -> bool:
    if not isinstance(payload, dict):
        return False
    if str(payload.get("wake_model") or "").strip().lower() != "manual_wake":
        return False
    host_capabilities = payload.get("jolt_host_capabilities")
    if not isinstance(host_capabilities, dict):
        return False
    return bool(
        host_capabilities.get("can_stage_context")
        or host_capabilities.get("can_trigger_inference")
    )


def _wake_display(payload) -> str:
    label = _wake_model_label((payload or {}).get("wake_model"))
    if not label:
        return ""
    if _manual_wake_has_jolt_path(payload):
        return " [MANUAL-WAKE+JOLT]"
    return f" [{label}]"


def _basis_label(agent_record) -> str:
    """Return a short basis tag like [declared] or [observed] for operator display."""
    basis = str(agent_record.get("basis") or "").strip().lower()
    if basis in ("declared", "observed", "derived", "attested"):
        return basis
    return ""


def _freshness_label(agent_record) -> str:
    """Calculate freshness from runtime_updated_at or heartbeat_at. Returns e.g. '2m ago' or 'stale 15m'."""
    from datetime import datetime, timezone
    updated = agent_record.get("runtime_updated_at") or agent_record.get("heartbeat_at")
    if not updated:
        return ""
    try:
        if isinstance(updated, str):
            # Handle both UTC and local timestamps
            for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%dT%H:%M:%S.%f", "%Y-%m-%dT%H:%M:%S.%f%z", "%Y-%m-%dT%H:%M:%S%z"):
                try:
                    dt = datetime.strptime(updated, fmt)
                    break
                except ValueError:
                    continue
            else:
                return ""
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)
        else:
            return ""
        age_seconds = (datetime.now(timezone.utc) - dt).total_seconds()
        if age_seconds < 0:
            age_seconds = 0
        if age_seconds < 60:
            return f"{int(age_seconds)}s"
        minutes = int(age_seconds / 60)
        if minutes < 60:
            return f"{minutes}m"
        hours = int(minutes / 60)
        return f"{hours}h"
    except Exception:
        return ""


def _format_jolt_adapter_line(payload) -> str | None:
    if not isinstance(payload, dict):
        return None

    actions = []
    action_labels = {
        "notify": "notify",
        "stage_context": "stage context",
        "infer": "infer",
    }
    for action in payload.get("supported_actions") or []:
        label = action_labels.get(str(action).strip().lower())
        if label:
            actions.append(label)
    if not actions:
        return None

    host_kind = str(payload.get("host_kind") or "host").strip()
    adapter_kind = str(payload.get("adapter_kind") or "adapter").strip()
    state = str(payload.get("state") or "").strip().lower()
    fallback = action_labels.get(str(payload.get("fallback_action") or "").strip().lower())
    detail = str(payload.get("detail") or "").strip()

    parts = [f"{host_kind} via {adapter_kind}", ", ".join(actions)]
    if state and state != "supported":
        parts.append(state)
    if fallback:
        parts.append(f"fallback {fallback}")
    if detail:
        parts.append(detail)
    return f"  Jolt Adapter: {' | '.join(parts)}"


_JOLT_ACTION_TEXT = {
    "notify": "notify",
    "stage_context": "stage context",
    "infer": "run inference",
}


def _current_jolt_packet_from_status(payload) -> dict | None:
    if not isinstance(payload, dict):
        return None
    packet = payload.get("jolt_packet")
    return dict(packet) if isinstance(packet, dict) else None


def _jolt_packet_signature(packet) -> tuple | None:
    if not isinstance(packet, dict):
        return None

    adapter = packet.get("adapter") if isinstance(packet.get("adapter"), dict) else {}
    reasons = tuple(
        str(reason).strip()
        for reason in (packet.get("reasons") or [])
        if str(reason).strip()
    )
    supported_actions = tuple(
        str(action).strip().lower()
        for action in (adapter.get("supported_actions") or [])
        if str(action).strip()
    )
    return (
        str(packet.get("action") or "").strip().lower(),
        str(packet.get("trigger") or "").strip().lower(),
        str(packet.get("headline") or "").strip(),
        str(packet.get("priority") or "").strip().lower(),
        str(packet.get("recommended_action") or "").strip(),
        str(packet.get("freshness") or "").strip().lower(),
        int(packet.get("stale_after_seconds") or 0),
        str(packet.get("source_stage") or "").strip().lower(),
        reasons,
        str(adapter.get("adapter_kind") or "").strip().lower(),
        supported_actions,
        bool(packet.get("budget_limited")),
        bool(packet.get("fallback_used")),
    )


def _format_jolt_duration(seconds) -> str | None:
    try:
        total_seconds = max(0, int(seconds))
    except (TypeError, ValueError):
        return None

    if total_seconds >= 86_400:
        return f"{total_seconds / 86_400:.1f}d"
    if total_seconds >= 3_600:
        return f"{total_seconds / 3_600:.1f}h"
    if total_seconds >= 60:
        return f"{total_seconds // 60}m"
    return f"{total_seconds}s"


def _build_jolt_notification(packet, *, agent_name: str) -> tuple[str, str] | None:
    if not isinstance(packet, dict):
        return None

    action = str(packet.get("action") or "notify").strip().lower()
    action_text = _JOLT_ACTION_TEXT.get(action, action.replace("_", " "))
    headline = str(packet.get("headline") or "").strip() or f"Jolt for {agent_name}"
    recommended_action = str(packet.get("recommended_action") or "").strip()
    trigger = str(packet.get("trigger") or "").strip().replace("_", " ")
    freshness = str(packet.get("freshness") or "").strip().lower()
    age_label = str(packet.get("age_label") or "").strip()
    source_stage = str(packet.get("source_stage") or "").strip().replace("_", " ")
    stale_after_label = _format_jolt_duration(packet.get("stale_after_seconds"))
    reasons = [
        str(reason).strip()
        for reason in (packet.get("reasons") or [])
        if str(reason).strip()
    ]

    lines = []
    if recommended_action:
        lines.append(recommended_action)
    elif trigger:
        lines.append(f"Trigger: {trigger}")
    if freshness == "stale":
        stale_parts = []
        if source_stage:
            stale_parts.append(source_stage)
        if age_label:
            stale_parts.append(f"{age_label} old")
        if stale_after_label:
            stale_parts.append(f"target <= {stale_after_label}")
        stale_detail = f" ({', '.join(stale_parts)})" if stale_parts else ""
        lines.append(f"Wake freshness: stale{stale_detail}")
    if reasons:
        lines.append(f"Why: {reasons[0]}")
    if action != "notify":
        lines.append(f"Requested action: {action_text}")

    body = " | ".join(lines).strip() or "Open Whispers for details."
    return headline, body


def _should_emit_jolt_notification(packet) -> bool:
    if not isinstance(packet, dict):
        return False
    freshness = str(packet.get("freshness") or "").strip().lower()
    trigger = str(packet.get("trigger") or "").strip().lower()
    return not (freshness == "stale" and trigger == "hot_thread")


def _overlay_local_sidecar_unread_truth(
    client: WhispersClient,
    status_snapshot: dict,
    *,
    agent_name: str,
    limit: int = 50,
) -> dict:
    """Rebuild Jolt/status truth from local server unread state when the shell
    is forced onto the readonly local-sidecar path.

    The shell can still probe `/inbox` with the MCP-sidecar token even when the
    writable local DB/client path is unavailable. Use that live unread truth to
    refresh the connection story and Jolt packet instead of trusting the stale
    readonly snapshot alone.
    """
    try:
        unread_messages = _read_inbox_via_local_server(
            agent_name=agent_name,
            limit=limit,
            mark_seen=False,
        )
    except Exception:
        return status_snapshot

    enriched = dict(status_snapshot or {})
    pending_by_priority: dict[str, int] = {}
    pending_by_class: dict[str, int] = {}
    unread_previews: list[dict] = []
    for message in unread_messages:
        if not isinstance(message, dict):
            continue
        priority = str(message.get("priority") or "routine").strip().lower() or "routine"
        pending_by_priority[priority] = pending_by_priority.get(priority, 0) + 1

        queue_class_raw = (
            message.get("queue_class")
            or classify_queue_class(
                str(message.get("msg_type") or "inform"),
                priority,
                str(message.get("from_agent") or message.get("sender") or ""),
                schema=message.get("schema_uri") or message.get("schema"),
            )
        )
        queue_class = str(getattr(queue_class_raw, "value", queue_class_raw)).strip().lower() or "conversation"
        pending_by_class[queue_class] = pending_by_class.get(queue_class, 0) + 1

        unread_previews.append(
            {
                "uuid": message.get("uuid"),
                "created_at": message.get("created_at"),
                "from_agent": message.get("from_agent") or message.get("sender"),
                "subject": message.get("subject"),
                "priority": priority,
                "msg_type": message.get("msg_type"),
                "reply_to": message.get("reply_to"),
            }
        )

    enriched["pending_messages"] = len(unread_previews)
    enriched["pending_by_priority"] = pending_by_priority
    enriched["pending_by_class"] = pending_by_class
    enriched["unread_previews"] = unread_previews
    for key in (
        "startup",
        "connection_story",
        "jolt_packet",
        "jolt_adapter",
        "jolt_host_capabilities",
        "jolt_budget",
        "jolt",
    ):
        enriched.pop(key, None)
    return _attach_status_story(client, enriched)


def _build_sidecar_jolt_client(
    *,
    agent_name: str,
    server_url: str,
    token: str,
    profile_name: str | None,
    host_kind: str,
    adapter_kind: str,
    can_notify: bool,
    can_stage_context: bool = False,
    can_trigger_inference: bool = False,
):
    if _uses_local_operator_sidecar_token(server_url, token):
        return (
            WhispersClient(
                agent_name,
                read_only=True,
                assume_http_server_reachable=True,
            ),
            True,
        )
    try:
        return (
            WhispersClient(
                agent_name,
                server=server_url,
                token=token,
                profile=profile_name,
                session_kind="remote_http",
                jolt_host_kind=host_kind,
                jolt_adapter_kind=adapter_kind,
                jolt_can_notify=can_notify,
                jolt_can_stage_context=can_stage_context,
                jolt_can_trigger_inference=can_trigger_inference,
                assume_http_server_reachable=True,
            ),
            False,
        )
    except Exception:
        return (
            WhispersClient(
                agent_name,
                server=server_url,
                token=token,
                profile=profile_name,
                read_only=True,
                assume_http_server_reachable=True,
            ),
            True,
        )


def _build_notify_jolt_client(*, agent_name: str, server_url: str, token: str, profile_name: str | None):
    return _build_sidecar_jolt_client(
        agent_name=agent_name,
        server_url=server_url,
        token=token,
        profile_name=profile_name,
        host_kind="local_client",
        adapter_kind="notify_only",
        can_notify=True,
    )


def _infer_terminal_jolt_host_kind(agent_name: str) -> str:
    normalized = str(agent_name or "").strip().lower().replace("-", "_")
    if normalized in {"claude", "claude_code", "claude_cli"}:
        return "claude_code"
    if normalized in {"codex", "codex_cli"}:
        return "codex_cli"
    return "plain_terminal"


def _build_terminal_jolt_client(
    *,
    agent_name: str,
    server_url: str,
    token: str,
    profile_name: str | None,
    host_kind: str | None = None,
):
    return _build_sidecar_jolt_client(
        agent_name=agent_name,
        server_url=server_url,
        token=token,
        profile_name=profile_name,
        host_kind=host_kind or _infer_terminal_jolt_host_kind(agent_name),
        adapter_kind="managed_pty",
        can_notify=True,
        can_stage_context=True,
    )


def _build_terminal_stage_context_lines(status_snapshot) -> list[str]:
    if not isinstance(status_snapshot, dict):
        return []

    story = status_snapshot.get("connection_story")
    if not isinstance(story, dict):
        story = {}

    mode = str(
        story.get("signal_mode")
        or status_snapshot.get("my_mode")
        or ""
    ).strip()
    readiness = str(
        story.get("readiness")
        or status_snapshot.get("readiness")
        or ""
    ).strip()
    pending_messages = story.get("pending_messages")
    if pending_messages is None:
        pending_messages = status_snapshot.get("pending_messages")
    pending_assignments = story.get("pending_assignments")
    if pending_assignments is None:
        pending_assignments = status_snapshot.get("pending_assignments")
    pending_reviews = story.get("pending_review_requests")
    if pending_reviews is None:
        pending_reviews = status_snapshot.get("pending_review_requests")
    blocking_reviews = story.get("blocking_review_requests")
    if blocking_reviews is None:
        blocking_reviews = status_snapshot.get("blocking_review_requests")

    summary_parts = []
    if mode:
        summary_parts.append(f"mode {mode}")
    if readiness:
        summary_parts.append(f"readiness {readiness}")
    if pending_messages is not None:
        summary_parts.append(f"{int(pending_messages)} pending messages")
    if pending_assignments is not None:
        summary_parts.append(f"{int(pending_assignments)} assignments")
    if pending_reviews is not None:
        summary_parts.append(f"{int(pending_reviews)} reviews")
    if blocking_reviews is not None and int(blocking_reviews) > 0:
        summary_parts.append(f"{int(blocking_reviews)} blocking")

    lines: list[str] = []
    if summary_parts:
        lines.append(f"Context: {' | '.join(summary_parts)}")

    huddle_peers = story.get("huddle_peers")
    if isinstance(huddle_peers, list) and huddle_peers:
        peer_parts = []
        for peer in huddle_peers[:3]:
            if not isinstance(peer, dict):
                continue
            callsign = str(peer.get("callsign") or peer.get("agent_name") or "").strip()
            if not callsign:
                continue
            reason = None
            reasons = peer.get("reasons")
            if isinstance(reasons, list):
                for item in reasons:
                    text = str(item or "").strip()
                    if text:
                        reason = text
                        break
            if not reason:
                reason = str(peer.get("working_on") or "").strip() or None
            peer_parts.append(f"{callsign} ({reason})" if reason else callsign)
        if peer_parts:
            lines.append(f"Peers: {'; '.join(peer_parts)}")

    recommended = str(story.get("recommended_action") or "").strip()
    if recommended:
        lines.append(f"Story: {recommended}")
    return lines


def _build_terminal_jolt_lines(packet, *, status_snapshot, agent_name: str) -> list[str]:
    if not isinstance(packet, dict):
        return []

    action = str(packet.get("action") or "notify").strip().lower()
    action_text = _JOLT_ACTION_TEXT.get(action, action.replace("_", " "))
    headline = str(packet.get("headline") or "").strip() or f"Jolt for {agent_name}"
    trigger = str(packet.get("trigger") or "").strip().replace("_", " ")
    freshness = str(packet.get("freshness") or "").strip().lower()
    age_label = str(packet.get("age_label") or "").strip()
    priority = str(packet.get("priority") or "").strip().lower()
    recommended_action = str(packet.get("recommended_action") or "").strip()
    reasons = [
        str(reason).strip()
        for reason in (packet.get("reasons") or [])
        if str(reason).strip()
    ]

    lines = [f"JOLT {action_text.upper()} | {headline}"]

    meta_parts = []
    if trigger:
        meta_parts.append(f"trigger {trigger}")
    if priority:
        meta_parts.append(f"priority {priority}")
    if freshness == "stale":
        stale_detail = "stale"
        if age_label:
            stale_detail = f"{stale_detail} ({age_label} old)"
        meta_parts.append(stale_detail)
    elif freshness:
        meta_parts.append(freshness)
    if meta_parts:
        lines.append("Signal: " + " | ".join(meta_parts))

    if recommended_action:
        lines.append(f"Next: {recommended_action}")
    if reasons:
        lines.append(f"Why: {reasons[0]}")
    if action == "stage_context":
        lines.extend(_build_terminal_stage_context_lines(status_snapshot))
    return lines


def _emit_terminal_jolt(packet, *, status_snapshot, agent_name: str, bell: bool, json_output: bool) -> bool:
    lines = _build_terminal_jolt_lines(packet, status_snapshot=status_snapshot, agent_name=agent_name)
    if not lines:
        return False

    if json_output:
        click.echo(
            json.dumps(
                {
                    "agent_name": agent_name,
                    "jolt_packet": packet,
                    "terminal_lines": lines,
                },
                indent=2,
            )
        )
        return True

    if bell:
        click.echo("\a", nl=False)
    click.secho("=" * 72, fg="cyan")
    click.secho(lines[0], fg="cyan", bold=True)
    for line in lines[1:]:
        click.echo(line)
    click.secho("=" * 72, fg="cyan")
    return True


def remote_options(f):
    f = click.option('--server', default=None, help="Remote Whispers server URL")(f)
    f = click.option('--profile', 'profile_name', default=None, help="Stored connection profile to use for remote auth")(f)
    f = click.option('--token', 'token_override', default=None, help="Bearer token override for remote auth")(f)
    return f

def _make_client(
    command_desc: str,
    *,
    server: str | None = None,
    profile_name: str | None = None,
    agent_name: str | None = None,
    token: str | None = None,
    fallback_agent: str = "cli-user",
    read_only: bool = False,
    session_kind: str | None = None,
) -> WhispersClient | None:
    if server or profile_name:
        remote = _resolve_remote_profile(
            server=server,
            profile_name=profile_name,
            agent_name=agent_name or fallback_agent,
            token=token,
        )
        return WhispersClient(
            remote["agent_name"] or fallback_agent,
            server=remote["server"],
            token=remote["token"],
            profile=profile_name,
            read_only=read_only,
        )

    if not agent_name:
        raise click.ClickException(f"Local {command_desc} requires --agent-name.")
    
    kwargs = {"read_only": read_only}
    if session_kind is not None:
        kwargs["session_kind"] = session_kind
    return WhispersClient(agent_name, **kwargs)


def _display_time_of_day(value, *, fallback: str = "-") -> str:
    rendered = format_local_timestamp(value)
    if not rendered:
        return str(value) if value else fallback
    parts = rendered.split(" ")
    if len(parts) >= 4:
        return " ".join(parts[1:4])
    return rendered


def _emit_json(payload) -> None:
    click.echo(json.dumps(payload, indent=2))


def _listener_should_send_checkpoint(message: dict) -> bool:
    if not isinstance(message, dict):
        return False
    sender = message.get("from_agent") or message.get("sender")
    if not sender:
        return False
    return str(message.get("msg_type") or "") != "checkpoint"


def _listener_checkpoint_subject(message: dict) -> str:
    subject = str(message.get("subject") or "listener pickup").strip()
    return f"Checkpoint: {subject}"


def _listener_send_checkpoint(client: WhispersClient, message: dict, *, detail: str = "") -> dict | None:
    if not _listener_should_send_checkpoint(message):
        return None

    sender = message.get("from_agent") or message.get("sender")
    body = detail or "Starting now"
    return client.send(
        sender,
        _listener_checkpoint_subject(message),
        body=body,
        priority="priority",
        msg_type="checkpoint",
        reply_to=message.get("uuid") or message.get("id"),
        context_id=message.get("context_id"),
    )


def _listener_process_message(
    client: WhispersClient,
    message: dict,
    *,
    auto_ack_state: str | None,
    auto_ack_detail: str,
    checkpoint_on_wake: bool,
) -> dict:
    rendered = message
    if auto_ack_state:
        rendered = client.acknowledge_message(
            message.get("uuid") or message.get("id"),
            auto_ack_state,
            detail=auto_ack_detail or "",
        )
    if checkpoint_on_wake:
        checkpoint = _listener_send_checkpoint(client, rendered, detail=auto_ack_detail or "")
        if checkpoint:
            rendered = dict(rendered)
            rendered["listener_checkpoint_id"] = checkpoint.get("id")
            rendered["listener_checkpoint_status"] = checkpoint.get("status")
            rendered["listener_checkpoint_subject"] = _listener_checkpoint_subject(rendered)
    return rendered


@cli.command()
@click.option('--to', required=True, help="Recipient agent name")
@click.option('--subject', required=True, help="Subject line")
@click.option('--priority', default="routine", help="routine, priority, flash, system")
@click.option(
    '--msg-type',
    default="inform",
    help="Whispers message type. Replies use --reply-to plus a regular type such as inform or accept.",
)
@click.option('--visibility', default="normal", help="quiet, normal, announce, broadcast, ceremony")
@click.option('--memory-mode', default="thread", help="ephemeral, thread, pin, ledger, engram")
@click.option('--audience', default=None, help="Override inferred audience: direct, room, team, swarm")
@click.option('--body', default="", help="Message body")
@click.option('--from-agent', default="cli-user", help="Sender agent name")
@click.option('--reply-to', default=None, help="Reply to an existing message UUID")
@click.option('--context-id', default=None, help="Thread/context ID to attach to the message")
def send(to, subject, priority, msg_type, visibility, memory_mode, audience, body, from_agent, reply_to, context_id):
    """Send a message directly into the Swarm bus."""
    msg_type = _normalize_cli_msg_type(msg_type)
    fallback = _readonly_local_db_fallback_context()
    if fallback is not None:
        health = fallback["health"]
        local_db_path = fallback["local_db_path"]
        server_db_path = fallback["server_db_path"]
        if not health:
            click.secho(
                "Send failed: local Whispers DB is read-only and no writable local server is running.",
                fg="red",
            )
            return
        if server_db_path and _normalize_path(server_db_path) != _normalize_path(local_db_path):
            click.secho(
                "Send failed: local Whispers DB is read-only and the running server is using a different database.",
                fg="red",
            )
            click.echo(f"  Local DB:  {local_db_path}")
            click.echo(f"  Server DB: {resolve_path(server_db_path)}")
            return
        try:
            resp = _send_via_local_server(
                {
                    "sender": from_agent,
                    "to": to,
                    "subject": subject,
                    "body": body,
                    "priority": priority,
                    "msg_type": msg_type,
                    "audience_scope": audience,
                    "visibility_mode": visibility,
                    "memory_mode": memory_mode,
                    "reply_to": reply_to,
                    "context_id": context_id,
                }
            )
        except Exception as server_error:
            click.secho(
                f"Send failed: local Whispers DB is read-only and server fallback failed: {server_error}",
                fg="red",
            )
            return
        click.echo(_format_send_receipt(resp, recipient=to))
        return

    try:
        client = WhispersClient(from_agent)
        resp = client.send(
            to=to,
            subject=subject,
            priority=priority,
            msg_type=msg_type,
            body=body,
            audience_scope=audience,
            visibility_mode=visibility,
            memory_mode=memory_mode,
            reply_to=reply_to,
            context_id=context_id,
        )
    except Exception as e:
        if _is_readonly_db_error(e):
            health = _check_server_health()
            local_db_path = _expected_db_path()
            server_db_path = health.get("db_path") if isinstance(health, dict) else None
            if not health:
                click.secho(
                    "Send failed: local Whispers DB is read-only and no writable local server is running.",
                    fg="red",
                )
                return
            if server_db_path and _normalize_path(server_db_path) != _normalize_path(local_db_path):
                click.secho(
                    "Send failed: local Whispers DB is read-only and the running server is using a different database.",
                    fg="red",
                )
                click.echo(f"  Local DB:  {local_db_path}")
                click.echo(f"  Server DB: {resolve_path(server_db_path)}")
                return
            try:
                resp = _send_via_local_server(
                    {
                        "sender": from_agent,
                        "to": to,
                        "subject": subject,
                        "body": body,
                        "priority": priority,
                        "msg_type": msg_type,
                        "audience_scope": audience,
                        "visibility_mode": visibility,
                        "memory_mode": memory_mode,
                    }
                )
            except Exception as server_error:
                click.secho(
                    f"Send failed: local Whispers DB is read-only and server fallback failed: {server_error}",
                    fg="red",
                )
                return
        else:
            click.secho(f"Send failed: {e}", fg="red")
            return
    click.echo(_format_send_receipt(resp, recipient=to))


@cli.command()
@click.argument('agent_name')
@click.option('--limit', default=10, help="Max messages to fetch")
@click.option('--peek/--claim', default=False, help="Peek without marking messages seen. Default claims messages.")
def inbox(agent_name, limit, peek):
    """Check the unread inbox for a specific agent."""
    if not peek:
        fallback = _readonly_local_db_fallback_context()
        if fallback is not None:
            health = fallback["health"]
            local_db_path = fallback["local_db_path"]
            server_db_path = fallback["server_db_path"]
            if not health:
                click.secho(
                    "Inbox claim failed: local Whispers DB is read-only and no writable local server is running.",
                    fg="red",
                )
                return
            if server_db_path and _normalize_path(server_db_path) != _normalize_path(local_db_path):
                click.secho(
                    "Inbox claim failed: local Whispers DB is read-only and the running server is using a different database.",
                    fg="red",
                )
                click.echo(f"  Local DB:  {local_db_path}")
                click.echo(f"  Server DB: {resolve_path(server_db_path)}")
                return
            try:
                messages = _read_inbox_via_local_server(
                    agent_name=agent_name,
                    limit=limit,
                    mark_seen=True,
                )
            except Exception as server_error:
                if _is_remote_client_auth_error(server_error):
                    click.secho(
                        _remote_client_auth_hint(agent_name, surface="Inbox claim"),
                        fg="red",
                    )
                    return
                click.secho(
                    f"Inbox claim failed: local Whispers DB is read-only and server fallback failed: {server_error}",
                    fg="red",
                )
                return
            if not messages:
                click.echo(f"No new messages for {agent_name}.")
            for m in messages:
                click.echo(json.dumps({
                    "id": m['uuid'],
                    "from": m['from_agent'],
                    "priority": m['priority'],
                    "visibility_mode": m.get('visibility_mode'),
                    "memory_mode": m.get('memory_mode'),
                    "audience_scope": m.get('audience_scope'),
                    "subject": m['subject'],
                    "created_at": m['created_at'],
                    "created_at_local": m.get('created_at_local') or _display_timestamp(m.get('created_at')),
                    "display_timezone": local_timezone_label(),
                }, indent=2))
            return

    client = WhispersClient(agent_name, read_only=True)
    if not peek:
        client._allow_readonly_mark_seen = True
    try:
        messages = client.check_inbox(limit=limit, mark_seen=not peek)
    except Exception as e:
        if not peek and _is_readonly_db_error(e):
            health = _check_server_health()
            local_db_path = _expected_db_path()
            server_db_path = health.get("db_path") if isinstance(health, dict) else None
            if not health:
                click.secho(
                    "Inbox claim failed: local Whispers DB is read-only and no writable local server is running.",
                    fg="red",
                )
                return
            if server_db_path and _normalize_path(server_db_path) != _normalize_path(local_db_path):
                click.secho(
                    "Inbox claim failed: local Whispers DB is read-only and the running server is using a different database.",
                    fg="red",
                )
                click.echo(f"  Local DB:  {local_db_path}")
                click.echo(f"  Server DB: {resolve_path(server_db_path)}")
                return
            try:
                messages = _read_inbox_via_local_server(
                    agent_name=agent_name,
                    limit=limit,
                    mark_seen=True,
                )
            except Exception as server_error:
                if _is_remote_client_auth_error(server_error):
                    click.secho(
                        _remote_client_auth_hint(agent_name, surface="Inbox claim"),
                        fg="red",
                    )
                    return
                click.secho(
                    f"Inbox claim failed: local Whispers DB is read-only and server fallback failed: {server_error}",
                    fg="red",
                )
                return
        else:
            click.secho(f"Inbox check failed: {e}", fg="red")
            return
    if not messages:
        click.echo(f"No new messages for {agent_name}.")
    for m in messages:
        click.echo(json.dumps({
            "id": m['uuid'],
            "from": m['from_agent'],
            "priority": m['priority'],
            "visibility_mode": m.get('visibility_mode'),
            "memory_mode": m.get('memory_mode'),
            "audience_scope": m.get('audience_scope'),
            "subject": m['subject'],
            "created_at": m['created_at'],
            "created_at_local": m.get('created_at_local') or _display_timestamp(m.get('created_at')),
            "display_timezone": local_timezone_label(),
        }, indent=2))


@cli.command()
@click.argument('callsign')
@click.option('--limit', default=20, help="Max messages to show")
@click.option('--from-agent', default="cli-user", help="Your agent name")
def trace(callsign, limit, from_agent):
    """Show full conversation between you and another agent."""
    client = WhispersClient(from_agent, read_only=True)
    messages = client.trace(callsign, limit=limit)
    if not messages:
        click.echo(f"No conversation history with {callsign}.")
        return
    for m in messages:
        direction = "->" if m['from_agent'] == from_agent else "<-"
        status = m.get('delivery_status', '?')
        read = " [read]" if m.get('read_at') else ""
        ack = ""
        if m.get('ack_state'):
            acked_at = m.get('acked_at_local') or _display_timestamp(m.get('acked_at'))
            ack = f" | {m['ack_state']} {acked_at}"
        ts = m.get('created_at_local') or _display_timestamp(m.get('created_at'))
        policy = f" [{m.get('visibility_mode', 'normal')}/{m.get('memory_mode', 'thread')}]"
        click.echo(f"[{ts}] {m['from_agent']} {direction} {m['to_agent']} | {m['subject']}{policy}{read} ({status}){ack}")
        if m.get('body'):
            # Indent body for readability
            for line in m['body'].split('\n')[:3]:
                click.echo(f"  {line}")
            if m['body'].count('\n') > 3:
                click.echo(f"  ... ({m['body'].count(chr(10)) - 3} more lines)")


@cli.command()
@click.option('--limit', default=10, help="Max messages to show")
@click.option('--from-agent', default="cli-user", help="Your agent name")
@click.option('--json-output', is_flag=True, help="Emit machine-readable JSON")
def outbox(limit, from_agent, json_output):
    """Show messages you sent with delivery status."""
    client = WhispersClient(from_agent, read_only=True)
    messages = client.outbox(limit=limit)
    if json_output:
        click.echo(json.dumps(_build_outbox_snapshot(from_agent, messages), indent=2, default=str))
        return
    if not messages:
        click.echo("Outbox empty.")
        return
    for m in messages:
        status = m.get('delivery_status', '?')
        read_marker = ""
        if m.get('ack_state'):
            acked_at = m.get('acked_at_local') or _display_timestamp(m.get('acked_at'))
            read_marker = f" | {m['ack_state']} {acked_at}"
        elif m.get('read_at'):
            read_marker = f" | read {m.get('read_at_local') or _display_timestamp(m.get('read_at'))}"
        elif m.get('delivered_at'):
            dt = m.get('delivered_at_local') or _display_timestamp(m.get('delivered_at'))
            read_marker = f" | delivered {dt}"
        policy = f" [{m.get('visibility_mode', 'normal')}/{m.get('memory_mode', 'thread')}]"
        click.echo(f"[{m.get('created_at_local') or _display_timestamp(m.get('created_at'))}] -> {m['to_agent']} | {m['subject']}{policy} ({status}){read_marker}")


@cli.command("workspaces")
@click.option("--agent-name", default="whispers-console", show_default=True, help="Operator/agent identity to use for local reads")
@click.option("--status", type=click.Choice(["active", "closed", "all"]), default="active", show_default=True, help="Workspace status filter")
@click.option("--limit", default=20, type=int, show_default=True, help="Maximum workspaces to show")
@click.option("--json-output", is_flag=True, help="Emit raw JSON")
@remote_options
def workspaces_list(agent_name, status, limit, json_output, server, profile_name, token_override):
    """List shared workspaces with member counts and activity pulse."""
    client = _make_client(
        "workspace listing",
        server=server,
        profile_name=profile_name,
        token=token_override,
        agent_name=agent_name,
        fallback_agent="whispers-console",
        read_only=True,
    )
    rows = client.list_workspaces(status=status, limit=limit)
    if json_output:
        _emit_json(rows)
        return
    if not rows:
        click.echo("No workspaces found.")
        return
    for workspace in rows:
        title = workspace.get("name") or workspace.get("purpose") or workspace["workspace_id"]
        last_activity = workspace.get("last_activity_at_local") or _display_timestamp(
            workspace.get("last_activity_at") or workspace.get("last_delta_at")
        )
        click.echo(
            f"{workspace['workspace_id']} | {title} | "
            f"members={workspace.get('member_count', 0)} observers={workspace.get('observer_count', 0)} "
            f"seq={workspace.get('current_sequence', workspace.get('last_sequence', 0))} "
            f"status={workspace.get('status', '?')} last={last_activity}"
        )


@cli.command("workspace")
@click.argument("workspace_id")
@click.option("--agent-name", default="whispers-console", show_default=True, help="Operator/agent identity to use for local reads")
@click.option("--since-sequence", default=None, type=int, help="Return deltas after this sequence")
@click.option("--json-output", is_flag=True, help="Emit raw JSON")
@remote_options
def workspace_show(workspace_id, agent_name, since_sequence, json_output, server, profile_name, token_override):
    """Show workspace detail including membership and recent deltas."""
    client = _make_client(
        "workspace detail",
        server=server,
        profile_name=profile_name,
        token=token_override,
        agent_name=agent_name,
        fallback_agent="whispers-console",
        read_only=True,
    )
    state = client.workspace_state(workspace_id, since_sequence=since_sequence)
    if json_output:
        _emit_json(state)
        return

    workspace = state["workspace"]
    click.echo(f"{workspace['workspace_id']} | {workspace.get('name') or workspace.get('purpose') or workspace['workspace_id']}")
    click.echo(f"  Purpose: {workspace.get('purpose') or '-'}")
    click.echo(f"  Status: {workspace.get('status', '?')}")
    click.echo(f"  Join Policy: {workspace.get('join_policy', '?')}")
    click.echo(f"  Sequence: {state.get('current_sequence', workspace.get('last_sequence', 0))}")
    click.echo(f"  Last Activity: {workspace.get('last_activity_at_local') or _display_timestamp(workspace.get('last_delta_at'))}")

    members = state.get("members") or []
    click.echo("  Members:")
    if not members:
        click.echo("    - none")
    for member in members:
        joined = member.get("joined_at_local") or _display_timestamp(member.get("joined_at"))
        click.echo(
            f"    - {member.get('agent_name')} | role={member.get('membership_role', 'member')} "
            f"state={member.get('membership_state', '?')} joined={joined}"
        )

    deltas = state.get("deltas") or []
    click.echo("  Recent Deltas:")
    if not deltas:
        click.echo("    - none")
    for delta in deltas[:10]:
        timestamp = delta.get("created_at_local") or _display_timestamp(delta.get("created_at"))
        text = delta.get("text") or f"{delta.get('actor') or 'system'} updated the workspace."
        click.echo(
            f"    - [{timestamp}] {delta.get('delta_kind', '?')} by {delta.get('actor') or 'system'} | {text}"
        )


@cli.command("handoffs")
@click.option("--agent-name", default="whispers-console", show_default=True, help="Operator/agent identity to use for local reads")
@click.option("--limit", default=20, type=int, show_default=True, help="Maximum handoffs to show")
@click.option("--workspace-id", default=None, help="Optional workspace filter")
@click.option("--unacknowledged-only", is_flag=True, help="Show only handoffs without an acknowledgment state")
@click.option("--json-output", is_flag=True, help="Emit raw JSON")
@remote_options
def handoffs_list(agent_name, limit, workspace_id, unacknowledged_only, json_output, server, profile_name, token_override):
    """List recent structured handoffs with next actions and ack state."""
    client = _make_client(
        "handoff listing",
        server=server,
        profile_name=profile_name,
        token=token_override,
        agent_name=agent_name,
        fallback_agent="whispers-console",
        read_only=True,
    )
    rows = client.list_handoffs(limit=limit, workspace_id=workspace_id, unacknowledged_only=unacknowledged_only)
    if json_output:
        _emit_json(rows)
        return
    if not rows:
        click.echo("No handoffs found.")
        return
    for handoff in rows:
        sender = handoff.get("from_agent") or "?"
        receiver = handoff.get("recipient_callsign") or handoff.get("to_agent") or "?"
        timestamp = handoff.get("created_at_local") or _display_timestamp(handoff.get("created_at"))
        ack_state = handoff.get("ack_state") or "pending"
        summary = handoff.get("summary_human") or handoff.get("next_action") or handoff.get("subject") or "-"
        workspace_note = handoff.get("workspace_id") or "-"
        click.echo(
            f"[{timestamp}] {sender} -> {receiver} | {summary} | ack={ack_state} | workspace={workspace_note}"
        )


@cli.command("activity")
@click.option("--agent-name", default="whispers-console", show_default=True, help="Operator/agent identity to use for local reads")
@click.option("--limit", default=50, type=int, show_default=True, help="Maximum events to show")
@click.option("--workspace-id", default=None, help="Optional workspace filter")
@click.option("--agent", default=None, help="Optional agent filter")
@click.option("--kind", "kinds", multiple=True, help="Delta kind filter. Repeat to include multiple kinds.")
@click.option("--json-output", is_flag=True, help="Emit raw JSON")
@remote_options
def activity_list(agent_name, limit, workspace_id, agent, kinds, json_output, server, profile_name, token_override):
    """Show the chronological collaboration feed across workspaces."""
    client = _make_client(
        "activity listing",
        server=server,
        profile_name=profile_name,
        token=token_override,
        agent_name=agent_name,
        fallback_agent="whispers-console",
        read_only=True,
    )
    rows = client.list_activity(limit=limit, workspace_id=workspace_id, agent=agent, kinds=list(kinds) or None)
    if json_output:
        _emit_json(rows)
        return
    if not rows:
        click.echo("No activity found.")
        return
    for event in rows:
        timestamp = event.get("created_at_local") or _display_timestamp(event.get("at") or event.get("created_at"))
        workspace_label = event.get("workspace_name") or event.get("workspace_id") or "-"
        if event.get("type") == "handoff":
            route = f"{event.get('sender') or '?'} -> {event.get('receiver') or '?'}"
            click.echo(f"[{timestamp}] {workspace_label} | handoff | {route} | {event.get('summary') or '-'}")
            continue
        click.echo(
            f"[{timestamp}] {workspace_label} | {event.get('delta_kind') or event.get('type') or '?'} "
            f"| {event.get('actor') or 'system'} | {event.get('summary') or event.get('text') or '-'}"
        )


@cli.command("ack")
@click.argument("message_id")
@click.option("--agent-name", required=True, help="Recipient agent acknowledging the message")
@click.option(
    "--state",
    type=click.Choice([state.value for state in AcknowledgmentState]),
    required=True,
    help="Post-read acknowledgment state to record",
)
@click.option("--detail", default="", help="Optional machine-readable or human detail")
@click.option('--server', default=None, help="Remote Whispers server URL")
@click.option('--profile', 'profile_name', default=None, help="Stored connection profile to use for remote auth")
@click.option('--token', 'token_override', default=None, help="Bearer token override for remote auth")
def ack(message_id, agent_name, state, detail, server, profile_name, token_override):
    """Record a comprehension acknowledgment for a delivered message."""
    if server or profile_name:
        remote = _resolve_remote_profile(
            server=server,
            profile_name=profile_name,
            token=token_override,
            agent_name=agent_name,
        )
        client = WhispersClient(
            remote["agent_name"] or agent_name,
            server=remote["server"],
            token=remote["token"],
            profile=profile_name,
        )
        result = client.acknowledge_message(message_id, state, detail=detail)
        click.echo(json.dumps(result, indent=2))
        return

    fallback = _readonly_local_db_fallback_context()
    if fallback is not None:
        health = fallback["health"]
        local_db_path = fallback["local_db_path"]
        server_db_path = fallback["server_db_path"]
        if not health:
            click.secho(
                "Ack failed: local Whispers DB is not writable for CLI use and no writable local server is running.",
                fg="red",
            )
            return
        if server_db_path and _normalize_path(server_db_path) != _normalize_path(local_db_path):
            click.secho(
                "Ack failed: local Whispers DB is not writable for CLI use and the running server is using a different database.",
                fg="red",
            )
            click.echo(f"  Local DB:  {local_db_path}")
            click.echo(f"  Server DB: {resolve_path(server_db_path)}")
            return
        try:
            result = _ack_via_local_server(
                agent_name=agent_name,
                message_id=message_id,
                state=state,
                detail=detail,
            )
        except Exception as server_error:
            if _is_remote_client_auth_error(server_error):
                click.secho(
                    _remote_client_auth_hint(agent_name, surface="Ack"),
                    fg="red",
                )
                return
            click.secho(
                f"Ack failed: local Whispers DB is not writable for CLI use and server fallback failed: {server_error}",
                fg="red",
            )
            return
        click.echo(json.dumps(result, indent=2))
        return

    try:
        client = WhispersClient(agent_name, session_kind="local_listener")
        result = client.acknowledge_message(message_id, state, detail=detail)
    except Exception as e:
        if _is_readonly_db_error(e):
            health = _check_server_health()
            local_db_path = _expected_db_path()
            server_db_path = health.get("db_path") if isinstance(health, dict) else None
            if not health:
                click.secho(
                    "Ack failed: local Whispers DB is not writable for CLI use and no writable local server is running.",
                    fg="red",
                )
                return
            if server_db_path and _normalize_path(server_db_path) != _normalize_path(local_db_path):
                click.secho(
                    "Ack failed: local Whispers DB is not writable for CLI use and the running server is using a different database.",
                    fg="red",
                )
                click.echo(f"  Local DB:  {local_db_path}")
                click.echo(f"  Server DB: {resolve_path(server_db_path)}")
                return
            try:
                result = _ack_via_local_server(
                    agent_name=agent_name,
                    message_id=message_id,
                    state=state,
                    detail=detail,
                )
            except Exception as server_error:
                if _is_remote_client_auth_error(server_error):
                    click.secho(
                        _remote_client_auth_hint(agent_name, surface="Ack"),
                        fg="red",
                    )
                    return
                click.secho(
                    f"Ack failed: local Whispers DB is not writable for CLI use and server fallback failed: {server_error}",
                    fg="red",
                )
                return
        else:
            click.secho(f"Ack failed: {e}", fg="red")
            return
    click.echo(json.dumps(result, indent=2))


@cli.group()
def listener():
    """Manage persistent-listener policy for remote profiles and autonomous daemons."""
    pass


@listener.command("show")
@click.option('--profile', 'profile_name', required=True, help="Stored connection profile to inspect")
def listener_show(profile_name):
    """Show the stored listener policy for a remote profile."""
    click.echo(json.dumps(_load_listener_policy(profile_name), indent=2))


@listener.command("set")
@click.option('--profile', 'profile_name', required=True, help="Stored connection profile to update")
@click.option(
    '--mode',
    type=click.Choice(sorted(_LISTENER_POLICY_MODES.keys())),
    required=True,
    help="Listener policy mode to persist on the profile",
)
@click.option('--detail', default="", help="Optional detail attached to automatic acknowledgments")
def listener_set(profile_name, mode, detail):
    """Persist a listener policy on a remote profile."""
    policy = _update_profile_listener_policy(profile_name, mode=mode, auto_ack_detail=detail)
    click.echo(json.dumps(policy, indent=2))


@listener.command("status")
@click.option('--profile', 'profile_name', default=None, help="Stored connection profile to inspect")
@click.option('--agent-name', default=None, help="Local agent listener to inspect")
def listener_status(profile_name, agent_name):
    """Show runtime state for a background listener process."""
    if not profile_name and not agent_name:
        raise click.ClickException("Provide --profile or --agent-name.")
    state = _load_listener_runtime_state(profile_name=profile_name, agent_name=agent_name) or {}
    pid = state.get("pid")
    running = _listener_process_running(pid)
    payload = dict(state)
    payload.setdefault("profile_name", profile_name)
    payload.setdefault("agent_name", agent_name)
    payload["running"] = running
    click.echo(json.dumps(payload, indent=2))


@listener.command("daemon")
@click.argument('agent_name')
@click.option('--server', default=None, help="Remote Whispers server URL")
@click.option('--db-path', default=None, help="Path to local Whispers database")
@click.option('--log-dir', default="~/.whispers/logs", help="Directory for autonomous sidecar logging")
def listener_daemon(agent_name, server, db_path, log_dir):
    """Run an autonomous background daemon listener.
    Starts the AutonomousDaemon with safety guardrails attached.
    """
    from whispers.listeners import AutonomousDaemon
    
    def _echo_handler(message: dict):
        click.echo(f"Daemon [{agent_name}] handled message: {message.get('sender')} -> {message.get('subject')}")

    daemon = AutonomousDaemon(
        agent_name=agent_name,
        handler_callback=_echo_handler,
        server_url=server,
        db_path=db_path,
        log_dir=resolve_path(log_dir),
    )
    daemon.run_forever()


@listener.command("start")
@click.option('--profile', 'profile_name', default=None, help="Stored connection profile to run in the background")
@click.option('--agent-name', default=None, help="Local agent listener to run in the background")
@click.option('--server', default=None, help="Remote Whispers server URL override")
@click.option('--token', 'token_override', default=None, help="Bearer token override for remote auth")
@click.option('--poll-interval', default=1.0, type=float, show_default=True, help="Local poll interval / remote reconnect floor")
@click.option('--auto-ack-state', type=click.Choice([state.value for state in AcknowledgmentState]), default=None, help="Override the listener policy and auto-ack every message with this state")
@click.option('--auto-ack-detail', default=None, help="Detail to attach to automatic acknowledgments")
@click.option(
    '--checkpoint-on-wake/--no-checkpoint-on-wake',
    default=None,
    help="Emit a checkpoint pulse back to the sender when the listener picks up work",
)
@click.option('--profile-policy/--ignore-profile-policy', default=True, show_default=True, help="Use stored profile listener policy when available")
def listener_start(profile_name, agent_name, server, token_override, poll_interval, auto_ack_state, auto_ack_detail, checkpoint_on_wake, profile_policy):
    """Launch a detached listener process with the current policy."""
    resolved_agent = agent_name
    if profile_name:
        remote = _resolve_remote_profile(
            server=server,
            profile_name=profile_name,
            token=token_override,
            agent_name=agent_name,
        )
        resolved_agent = remote["agent_name"] or resolved_agent
        server = remote["server"]
        token_override = None

    if not resolved_agent:
        raise click.ClickException("Provide --agent-name or a profile with a stored agent identity.")

    existing = _load_listener_runtime_state(profile_name=profile_name, agent_name=resolved_agent) or {}
    if _listener_process_running(existing.get("pid")):
        click.echo(json.dumps({**existing, "running": True}, indent=2))
        return

    command = [sys.executable, "-m", "whispers.cli", "listen", resolved_agent, "--poll-interval", str(poll_interval), "--json-output"]
    if profile_name:
        command.extend(["--profile", profile_name])
    elif server:
        command.extend(["--server", server])
    if token_override:
        command.extend(["--token", token_override])
    if auto_ack_state:
        command.extend(["--auto-ack-state", auto_ack_state])
    if auto_ack_detail:
        command.extend(["--auto-ack-detail", auto_ack_detail])
    if checkpoint_on_wake is True:
        command.append("--checkpoint-on-wake")
    elif checkpoint_on_wake is False:
        command.append("--no-checkpoint-on-wake")
    if not profile_policy:
        command.append("--ignore-profile-policy")

    log_path = _listener_log_path(profile_name=profile_name, agent_name=resolved_agent)
    os.makedirs(os.path.dirname(log_path), exist_ok=True)
    log_handle = open(log_path, "a", encoding="utf-8")

    creation_flags = 0
    if sys.platform == "win32":
        creation_flags = subprocess.CREATE_NEW_PROCESS_GROUP | subprocess.DETACHED_PROCESS
        if hasattr(subprocess, "CREATE_BREAKAWAY_FROM_JOB"):
            creation_flags |= subprocess.CREATE_BREAKAWAY_FROM_JOB

    proc = subprocess.Popen(
        command,
        stdout=log_handle,
        stderr=log_handle,
        creationflags=creation_flags,
    )
    log_handle.close()

    state = {
        "agent_name": resolved_agent,
        "profile_name": profile_name,
        "server": server,
        "pid": proc.pid,
        "running": True,
        "started_at": utc_now_iso(),
        "log_path": log_path,
        "command": command,
        "policy": _normalize_listener_policy({
            "mode": "listen_only",
            "auto_ack_state": auto_ack_state,
            "auto_ack_detail": auto_ack_detail,
            "checkpoint_on_wake": checkpoint_on_wake,
        }) if (auto_ack_state or checkpoint_on_wake is not None) else _load_listener_policy(profile_name),
    }
    state_path = _write_listener_runtime_state(state, profile_name=profile_name, agent_name=resolved_agent)
    click.echo(json.dumps({**state, "state_path": state_path}, indent=2))


@listener.command("stop")
@click.option('--profile', 'profile_name', default=None, help="Stored connection profile to stop")
@click.option('--agent-name', default=None, help="Local agent listener to stop")
def listener_stop(profile_name, agent_name):
    """Stop a detached listener process and keep the last runtime record."""
    if not profile_name and not agent_name:
        raise click.ClickException("Provide --profile or --agent-name.")
    state = _load_listener_runtime_state(profile_name=profile_name, agent_name=agent_name)
    if not state:
        raise click.ClickException("Listener is not registered.")

    pid = state.get("pid")
    if pid and _listener_process_running(pid):
        with contextlib.suppress(OSError):
            os.kill(int(pid), signal.SIGTERM)

    resolved_profile = profile_name or state.get("profile_name")
    resolved_agent = agent_name or state.get("agent_name")
    resolved_server = state.get("server")
    if resolved_profile and resolved_server:
        with contextlib.suppress(Exception):
            remote = _resolve_remote_profile(
                server=resolved_server,
                profile_name=resolved_profile,
                agent_name=resolved_agent,
            )
            if remote.get("token"):
                _server_request(
                    remote["server"],
                    "/disconnect",
                    method="POST",
                    payload={},
                    token=remote["token"],
                )
    elif resolved_agent and pid:
        with contextlib.suppress(Exception):
            from .storage.db import WhispersDB

            db = WhispersDB(_expected_db_path())
            db.revoke_agent_sessions(resolved_agent, session_kind="local_listener", process_id=int(pid))

    updated = dict(state)
    updated["running"] = False
    updated["stopped_at"] = utc_now_iso()
    updated["pid"] = None
    state_path = _write_listener_runtime_state(
        updated,
        profile_name=profile_name or state.get("profile_name"),
        agent_name=agent_name or state.get("agent_name"),
    )
    click.echo(json.dumps({**updated, "state_path": state_path}, indent=2))


@cli.command()
@click.argument("agent_name")
@click.option('--server', default=None, help="Remote Whispers server URL")
@click.option('--profile', 'profile_name', default=None, help="Stored connection profile to use for remote listen")
@click.option('--token', 'token_override', default=None, help="Bearer token override for remote auth")
@click.option('--poll-interval', default=1.0, type=float, show_default=True, help="Local poll interval / remote reconnect floor in seconds")
@click.option('--max-messages', default=0, type=int, show_default=True, help="Stop after this many messages (0 = run forever)")
@click.option(
    '--auto-ack-state',
    type=click.Choice([state.value for state in AcknowledgmentState]),
    default=None,
    help="Explicitly acknowledge each received message with this state",
)
@click.option('--auto-ack-detail', default=None, help="Detail to attach to automatic acknowledgments")
@click.option(
    '--checkpoint-on-wake/--no-checkpoint-on-wake',
    default=None,
    help="Emit a checkpoint pulse back to the sender when the listener picks up work",
)
@click.option(
    '--profile-policy/--ignore-profile-policy',
    default=True,
    show_default=True,
    help="Use any stored listener policy from the selected profile",
)
@click.option('--json-output', is_flag=True, help="Emit each message as JSON instead of compact prose")
def listen(agent_name, server, profile_name, token_override, poll_interval, max_messages, auto_ack_state, auto_ack_detail, checkpoint_on_wake, profile_policy, json_output):
    """Run a persistent listener loop for one agent."""
    remote = None
    if server or profile_name:
        remote = _resolve_remote_profile(
            server=server,
            profile_name=profile_name,
            token=token_override,
            agent_name=agent_name,
        )
        client = WhispersClient(
            remote["agent_name"] or agent_name,
            server=remote["server"],
            token=remote["token"],
            profile=profile_name,
        )
    else:
        client = WhispersClient(agent_name)

    try:
        client.wag("listening", intent="persistent listener")
    except Exception:
        pass

    active_policy = _load_listener_policy(profile_name) if (profile_name and profile_policy) else _normalize_listener_policy(None)
    effective_auto_ack_state = auto_ack_state or active_policy.get("auto_ack_state")
    if auto_ack_detail is None:
        effective_auto_ack_detail = active_policy.get("auto_ack_detail", "")
    else:
        effective_auto_ack_detail = auto_ack_detail
    if checkpoint_on_wake is None:
        effective_checkpoint_on_wake = bool(active_policy.get("checkpoint_on_wake"))
    else:
        effective_checkpoint_on_wake = bool(checkpoint_on_wake)

    limit = max_messages or None
    effective_policy = _normalize_listener_policy({
        "mode": active_policy.get("mode") or "listen_only",
        "auto_ack_state": effective_auto_ack_state,
        "auto_ack_detail": effective_auto_ack_detail or "",
        "checkpoint_on_wake": effective_checkpoint_on_wake,
    })
    runtime_agent = client.agent_name
    runtime_server = (remote or {}).get("server") or server
    existing_runtime_state = _load_listener_runtime_state(profile_name=profile_name, agent_name=runtime_agent) or {}
    runtime_state = _update_listener_runtime_state(
        {
            "agent_name": runtime_agent,
            "profile_name": profile_name,
            "server": runtime_server,
            "running": True,
            "started_at": existing_runtime_state.get("started_at") or utc_now_iso(),
            "last_started_at": utc_now_iso(),
            "last_exit_reason": None,
            "last_error": None,
            "policy": effective_policy,
            "processed_count": int(existing_runtime_state.get("processed_count") or 0),
            **({"pid": existing_runtime_state["pid"]} if existing_runtime_state.get("pid") else {}),
        },
        profile_name=profile_name,
        agent_name=runtime_agent,
    )

    if not json_output:
        click.secho(f"[*] Listening for {client.agent_name}... ", fg="green", err=True)

    def handle_disconnect(exc, backoff):
        _update_listener_runtime_state(
            {
                "agent_name": runtime_agent,
                "profile_name": profile_name,
                "server": runtime_server,
                "running": True,
                "last_disconnect_at": utc_now_iso(),
                "last_disconnect_error": str(exc),
                "reconnect_backoff_seconds": backoff,
            },
            profile_name=profile_name,
            agent_name=runtime_agent,
        )
        if not json_output:
            click.secho(f"[!] Connection failed ({exc}). Reconnecting in {backoff:.1f}s...", fg="yellow", err=True)

    def handle_restored():
        _update_listener_runtime_state(
            {
                "agent_name": runtime_agent,
                "profile_name": profile_name,
                "server": runtime_server,
                "running": True,
                "last_restored_at": utc_now_iso(),
                "last_disconnect_error": None,
                "reconnect_backoff_seconds": 0,
            },
            profile_name=profile_name,
            agent_name=runtime_agent,
        )
        if not json_output:
            click.secho(f"[*] Connection restored. Resuming listen...", fg="green", err=True)

    exit_reason = "completed"
    exit_error = None

    try:
        for message in client.listen(
            poll_interval=poll_interval,
            max_messages=limit,
            reconnect_delay=poll_interval,
            on_disconnect=handle_disconnect,
            on_restored=handle_restored,
        ):
            rendered = _listener_process_message(
                client,
                message,
                auto_ack_state=effective_auto_ack_state,
                auto_ack_detail=effective_auto_ack_detail or "",
                checkpoint_on_wake=effective_checkpoint_on_wake,
            )
            activity_at = utc_now_iso()
            processed_count = int(runtime_state.get("processed_count") or 0) + 1
            runtime_state = _update_listener_runtime_state(
                {
                    "agent_name": runtime_agent,
                    "profile_name": profile_name,
                    "server": runtime_server,
                    "running": True,
                    "last_activity_at": activity_at,
                    "last_wake_at": activity_at,
                    "last_message_id": rendered.get("uuid") or rendered.get("id"),
                    "last_message_subject": rendered.get("subject"),
                    "last_message_from": rendered.get("from_agent") or rendered.get("sender"),
                    "last_ack_state": rendered.get("ack_state"),
                    "last_ack_detail": rendered.get("ack_detail"),
                    "last_checkpoint_id": rendered.get("listener_checkpoint_id"),
                    "last_checkpoint_status": rendered.get("listener_checkpoint_status"),
                    "last_checkpoint_subject": rendered.get("listener_checkpoint_subject"),
                    "processed_count": processed_count,
                    "policy": effective_policy,
                },
                profile_name=profile_name,
                agent_name=runtime_agent,
            )
            if json_output:
                click.echo(json.dumps(rendered, indent=2))
                continue
            ts = rendered.get('created_at_local') or _display_timestamp(rendered.get('created_at'))
            policy = f"[{rendered.get('visibility_mode', 'normal')}/{rendered.get('memory_mode', 'thread')}]"
            ack = f" | {rendered.get('ack_state')}" if rendered.get("ack_state") else ""
            click.echo(f"[{ts}] {rendered.get('from_agent') or rendered.get('sender')} -> {rendered.get('to_agent') or rendered.get('recipient')} | {rendered.get('subject')} {policy}{ack}")
    except KeyboardInterrupt:
        exit_reason = "interrupted"
        raise
    except Exception as exc:
        exit_reason = "error"
        exit_error = str(exc)
        raise
    finally:
        _update_listener_runtime_state(
            {
                "agent_name": runtime_agent,
                "profile_name": profile_name,
                "server": runtime_server,
                "running": False,
                "stopped_at": utc_now_iso(),
                "last_exit_reason": exit_reason,
                "last_error": exit_error,
            },
            profile_name=profile_name,
            agent_name=runtime_agent,
        )


def _run_server_supervisor(start_server, host: str, port: int, *, restart_on_crash: bool, max_restarts: int, restart_delay: float):
    attempts = 0
    while True:
        try:
            start_server(host, port=port)
            return
        except KeyboardInterrupt:
            raise
        except Exception as exc:
            attempts += 1
            click.secho(f"[!] Whispers server crashed: {exc}", fg="red")
            if not restart_on_crash:
                raise
            if max_restarts > 0 and attempts > max_restarts:
                raise click.ClickException(
                    f"Whispers server exceeded the restart budget ({max_restarts}) after repeated crashes."
                ) from exc
            click.secho(f"[*] Restarting Whispers in {restart_delay:.1f}s (attempt {attempts}/{max_restarts or 'unbounded'})", fg="yellow")
            time.sleep(max(0.0, restart_delay))


@cli.command()
@click.option('--port', default=8752, type=int)
@click.option('--feed/--no-feed', default=True, help="Show live scrolling feed")
@click.option(
    '--admission',
    type=click.Choice(['trusted_team', 'open']),
    default='trusted_team',
    show_default=True,
    help="Remote admission policy for /connect.",
)
@click.option(
    '--allow-agent',
    'allowed_agents',
    multiple=True,
    help="Callsign(s) allowed to bootstrap in trusted-team mode. Repeat as needed.",
)
@click.option(
    '--privacy-mode',
    type=click.Choice(['metadata', 'full']),
    default='metadata',
    show_default=True,
    help="Operator observability mode for the console tap.",
)
@click.option(
    '--restart-on-crash/--no-restart-on-crash',
    default=True,
    show_default=True,
    help="Restart the local server if it exits unexpectedly.",
)
@click.option(
    '--restart-delay',
    default=2.0,
    type=float,
    show_default=True,
    help="Delay before restarting the local server after a crash.",
)
@click.option(
    '--max-restarts',
    default=5,
    type=int,
    show_default=True,
    help="Maximum automatic restarts before serve exits. Use 0 for unbounded restarts.",
)
def serve(port, feed, admission, allowed_agents, privacy_mode, restart_on_crash, restart_delay, max_restarts):
    """Start the Whispers Server and open the Operator Dashboard."""
    import threading
    from .server import start as start_server

    allowlist = {"whispers-console"}
    allowlist.update(agent.strip() for agent in allowed_agents if agent and agent.strip())
    os.environ["WHISPERS_REMOTE_ADMISSION_MODE"] = admission
    os.environ["WHISPERS_REMOTE_ALLOWED_AGENTS"] = ",".join(sorted(allowlist))
    os.environ["WHISPERS_OBSERVABILITY_MODE"] = privacy_mode

    click.secho(f"[*] Whispers HTTP API listening on 127.0.0.1:{port}", fg="green")
    click.echo(f"  Admission: {admission}")
    click.echo(f"  Allowlist: {', '.join(sorted(allowlist))}")
    click.echo(f"  Observability: {privacy_mode}")
    click.echo(f"  Auto-restart: {'on' if restart_on_crash else 'off'}")

    if not feed:
        _run_server_supervisor(
            start_server,
            "127.0.0.1",
            port,
            restart_on_crash=restart_on_crash,
            max_restarts=max_restarts,
            restart_delay=restart_delay,
        )
        return

    server_failed = threading.Event()
    server_error = {"message": None}

    def run_fastapi():
        try:
            _run_server_supervisor(
                start_server,
                "127.0.0.1",
                port,
                restart_on_crash=restart_on_crash,
                max_restarts=max_restarts,
                restart_delay=restart_delay,
            )
        except Exception as exc:
            server_error["message"] = str(exc)
            server_failed.set()

    t = threading.Thread(target=run_fastapi, daemon=True)
    t.start()

    click.secho("[*] Opening Operator Live Feed. Press Ctrl+C to stop.", fg="cyan")
    click.echo("-" * 80)

    from .storage.db import WhispersDB
    db = WhispersDB(read_only=True)
    last_rowid = 0
    poll_interval = 1.0

    try:
        import contextlib
        while True:
            with contextlib.closing(db.get_readonly_connection()) as conn:
                cursor = conn.cursor()
                if last_rowid == 0:
                    cursor.execute("SELECT MAX(rowid) FROM messages")
                    row = cursor.fetchone()
                    last_rowid = row[0] if row and row[0] else 0

                cursor.execute(
                    "SELECT rowid, from_agent, priority, msg_type, subject, created_at FROM messages WHERE rowid > ? ORDER BY rowid ASC",
                    (last_rowid,)
                )
                new_msgs = cursor.fetchall()

                if new_msgs:
                    poll_interval = 1.0
                else:
                    poll_interval = min(10.0, poll_interval * 2)

                for m in new_msgs:
                    m = dict(m)
                    last_rowid = m["rowid"]

                    cursor.execute("SELECT recipient_callsign FROM message_recipients WHERE message_uuid = (SELECT uuid FROM messages WHERE rowid=?)", (last_rowid,))
                    recips = [r[0] for r in cursor.fetchall()]
                    to_str = ", ".join(recips) if recips else "[ORPHAN]"

                    pri_color = {
                        "system": "red",
                        "flash": "magenta",
                        "priority": "yellow",
                        "routine": "green"
                    }.get(str(m["priority"]).lower(), "white")

                    time_str = _display_time_of_day(m.get("created_at"))

                    click.echo(f"[{time_str}] ", nl=False)
                    click.secho(f"[{str(m['priority']).upper()}] ", fg=pri_color, bold=True, nl=False)
                    click.echo(f"[{m['from_agent']} -> {to_str}] ", nl=False)
                    click.secho(f"'{m['subject']}' ", fg="cyan", nl=False)
                    click.echo(f"({m['msg_type']})")

            if server_failed.is_set():
                raise click.ClickException(server_error["message"] or "Whispers server exited unexpectedly.")

            import random
            time.sleep(poll_interval * random.uniform(0.8, 1.2))
    except KeyboardInterrupt:
        click.secho("\n[*] Shutting down Operator Dashboard.", fg="yellow")


@cli.group()
def runtime():
    """Inspect or update the live server runtime profile."""
    pass


@runtime.command("show")
@click.option('--server', default="http://127.0.0.1:8752", show_default=True, help="Whispers server URL")
@click.option('--token', 'token_override', default=None, help="Operator token override. Defaults to local WHISPERS_MCP_TOKEN.")
def runtime_show(server, token_override):
    """Show the live runtime profile for the current server."""
    token = token_override or _get_mcp_token()
    if not token:
        raise click.ClickException("Runtime inspection requires WHISPERS_MCP_TOKEN or --token.")

    snapshot = _server_request(server, "/runtime", method="GET", token=token) or {}
    click.echo(f"Profile: {snapshot.get('runtime_profile', '?')}")
    click.echo(f"Admission: {snapshot.get('remote_admission_mode', '?')}")
    click.echo(f"Observability: {snapshot.get('observability_mode', '?')}")
    allowed_agents = snapshot.get("allowed_agents") or []
    click.echo(f"Allowlist: {', '.join(allowed_agents) if allowed_agents else '-'}")


@runtime.command("set")
@click.option('--server', default="http://127.0.0.1:8752", show_default=True, help="Whispers server URL")
@click.option('--profile', type=click.Choice(['dev', 'trusted_team']), default=None, help="Named runtime profile.")
@click.option('--admission', type=click.Choice(['open', 'trusted_team']), default=None, help="Override the remote admission mode.")
@click.option('--privacy-mode', type=click.Choice(['metadata', 'full']), default=None, help="Override the observability mode.")
@click.option('--allow-agent', 'allowed_agents', multiple=True, help="Replace the trusted-team allowlist. Repeat as needed.")
@click.option('--token', 'token_override', default=None, help="Operator token override. Defaults to local WHISPERS_MCP_TOKEN.")
def runtime_set(server, profile, admission, privacy_mode, allowed_agents, token_override):
    """Update the live runtime profile without restarting the server."""
    if not any([profile, admission, privacy_mode, allowed_agents]):
        raise click.ClickException("Specify at least one runtime change.")

    token = token_override or _get_mcp_token()
    if not token:
        raise click.ClickException("Runtime updates require WHISPERS_MCP_TOKEN or --token.")

    payload = {}
    if profile:
        payload["profile"] = profile
    if admission:
        payload["admission"] = admission
    if privacy_mode:
        payload["privacy_mode"] = privacy_mode
    if allowed_agents:
        payload["allow_agents"] = list(allowed_agents)

    snapshot = _server_request(server, "/runtime", method="POST", payload=payload, token=token) or {}
    click.secho("Updated live runtime profile.", fg="green")
    click.echo(f"  Profile: {snapshot.get('runtime_profile', '?')}")
    click.echo(f"  Admission: {snapshot.get('remote_admission_mode', '?')}")
    click.echo(f"  Observability: {snapshot.get('observability_mode', '?')}")
    allowed = snapshot.get("allowed_agents") or []
    click.echo(f"  Allowlist: {', '.join(allowed) if allowed else '-'}")


@cli.group()
def handle():
    """Inspect callsign availability and ownership state."""
    pass


@handle.command("show")
@click.argument("callsign")
@click.option('--server', default=None, help="Remote Whispers server URL")
@click.option('--profile', 'profile_name', default=None, help="Stored connection profile to use for remote lookup")
@click.option('--json-output', is_flag=True, help="Emit raw JSON")
def handle_show(callsign, server, profile_name, json_output):
    """Show whether a handle is available, claimed, active, or invalid."""
    if server or profile_name:
        remote = _resolve_remote_profile(server=server, profile_name=profile_name)
        payload = _server_request(
            remote["server"],
            f"/handle/{urllib.parse.quote(callsign)}",
            method="GET",
            token=remote["token"],
        ) or {}
    else:
        payload = WhispersClient("cli-user", read_only=True).handle_status(callsign)

    if json_output:
        click.echo(json.dumps(payload, indent=2))
        return

    click.echo(f"Callsign: {payload.get('callsign', callsign)}")
    click.echo(f"  State: {payload.get('state', '?')}")
    click.echo(f"  Available: {'yes' if payload.get('available') else 'no'}")
    click.echo(f"  Active: {'yes' if payload.get('active') else 'no'}")
    click.echo(f"  Public Key Bound: {'yes' if payload.get('public_key_bound') else 'no'}")
    if payload.get("public_key_fingerprint"):
        click.echo(f"  Public Key Fingerprint: {payload['public_key_fingerprint']}")
    if payload.get("existing_callsign_policy"):
        click.echo(f"  Existing-Handle Policy: {payload['existing_callsign_policy']}")
    click.echo(f"  Detail: {payload.get('detail', '-')}")


@handle.command("suggest")
@click.option('--owner-slug', required=True, help="Stable owner identity, e.g. z4rivers")
@click.option('--surface', required=True, help="Worksurface or agent suffix, e.g. codex")
@click.option('--json-output', is_flag=True, help="Emit raw JSON")
def handle_suggest(owner_slug, surface, json_output):
    """Suggest a default owner-prefixed handle and matching display name."""
    payload = {
        "owner_slug": owner_slug,
        "surface": surface,
        "callsign": suggest_callsign(owner_slug, surface),
        "display_name": suggest_display_name(surface),
    }
    if json_output:
        click.echo(json.dumps(payload, indent=2))
        return

    click.echo(f"Suggested Callsign: {payload['callsign']}")
    click.echo(f"Suggested Display Name: {payload['display_name']}")



@cli.command()
@click.option('--agent-name', default=None, help="Local agent identity to inspect pending messages for")
@click.option('--json-output', is_flag=True, help="Emit machine-readable JSON with startup context")
def status(agent_name, json_output):
    """Show Whispers system status — mode, agents, pending messages."""
    resolved_agent_name = _resolve_local_status_agent_name(agent_name)
    client = WhispersClient(resolved_agent_name, read_only=True)
    s = client.status()

    if not s["healthy"]:
        if json_output:
            click.echo(json.dumps(s, indent=2, default=str))
            return
        click.secho("Whispers: OFFLINE", fg="red", bold=True)
        return

    health = _check_server_health()
    local_auth_probe = None
    server_db_path = health.get("db_path") if isinstance(health, dict) else None
    if server_db_path and _normalize_path(server_db_path) == _normalize_path(_expected_db_path()):
        local_auth_probe = _probe_local_client_auth(resolved_agent_name)
        s["local_client_auth_healthy"] = local_auth_probe.get("ok")
        s["local_client_token_source"] = local_auth_probe.get("source")
        s["local_client_auth_issue"] = local_auth_probe.get("issue")

    startup_capsule = _build_status_startup_capsule(client, s)
    if json_output:
        payload = dict(s)
        if startup_capsule:
            payload["startup"] = startup_capsule
            payload["status_follow_through_lines"] = _extract_status_follow_through_lines(startup_capsule)
        click.echo(json.dumps(payload, indent=2, default=str))
        return

    mode_color = {"OPEN": "green", "FOCUSED": "yellow", "QUIET": "red"}.get(s["my_mode"], "white")
    deploy_label = {"standalone": "Standalone Server", "embedded": "Embedded Library"}.get(
        s["deployment_mode"], s["deployment_mode"].title()
    )
    click.secho(f"Whispers: ON ({deploy_label})", fg="green", bold=True)
    click.echo(f"  Local Time: {_display_timestamp(s.get('now_utc') or s.get('now_local'))}")
    click.echo(f"  Display TZ: {s.get('display_timezone', local_timezone_label())}")
    click.echo(f"  Signal Mode: ", nl=False)
    click.secho(s["my_mode"], fg=mode_color, bold=True)
    click.echo(f"  Schema Version: {s.get('schema_version', '?')}")
    jolt_adapter_line = _format_jolt_adapter_line(s.get("jolt_adapter"))
    if jolt_adapter_line:
        click.echo(jolt_adapter_line)
    if s.get("local_client_auth_healthy") is False:
        source = s.get("local_client_token_source") or "unknown"
        click.secho(f"  Startup/Client Auth: DEGRADED ({source})", fg="yellow")
        issue = s.get("local_client_auth_issue") or "Unknown client-auth problem."
        click.echo(f"    {issue}")
    primary_registered = int(
        s.get("primary_participants_registered")
        or s.get("first_class_participants_registered")
        or 0
    )
    secondary_registered = int(
        s.get("secondary_participants_registered")
        or s.get("other_participants_registered")
        or 0
    )
    participant_counts = s.get("participant_counts") or {}
    if primary_registered or secondary_registered:
        click.echo(f"  Primary Participants: {primary_registered}")
        if secondary_registered:
            aux_parts = []
            automata = int((participant_counts.get("automaton") or {}).get("registered", 0))
            ephemeral = int((participant_counts.get("ephemeral") or {}).get("registered", 0))
            if automata:
                aux_parts.append(f"automata {automata}")
            if ephemeral:
                aux_parts.append(f"ephemeral {ephemeral}")
            suffix = f" ({', '.join(aux_parts)})" if aux_parts else ""
            click.echo(f"  Secondary Tracked Participants: {secondary_registered}{suffix}")
    else:
        click.echo(f"  Registered Agents: {s['agents_registered']}")

    primary_online = [
        a for a in s["agents_online"]
        if a.get("is_primary_participant", a.get("is_first_class_participant", True))
    ]
    secondary_online = [
        a for a in s["agents_online"]
        if not a.get("is_primary_participant", a.get("is_first_class_participant", True))
    ]

    if primary_online:
        click.echo(f"  Primary Online ({len(primary_online)}):")
        for a in primary_online:
            working = f" — {a['working_on']}" if a.get("working_on") else ""
            mode = f" [{a['reception_mode'].upper()}]" if a.get("reception_mode", "open") != "open" else ""
            wake = _wake_display(a)
            active_mode = a.get('derived_active_mode', a.get('status', 'offline'))
            basis = _basis_label(a)
            basis_tag = f" [{basis}]" if basis else ""
            freshness = _freshness_label(a)
            fresh_tag = f" ({freshness})" if freshness else ""
            click.echo(f"    {a['agent_name']}: {active_mode}{wake}{mode}{basis_tag}{fresh_tag}{working}")
    else:
        click.echo("  Primary Online: none")

    if secondary_online:
        click.echo(f"  Secondary Tracked Online: {len(secondary_online)}")

    if s["pending_messages"]:
        click.secho(f"  Pending Messages: {s['pending_messages']}", fg="yellow")
        for pri, cnt in sorted(s["pending_by_priority"].items()):
            click.echo(f"    {pri}: {cnt}")
    else:
        click.echo("  Pending Messages: 0")

    coordination_parts = []
    if s.get("pending_assignments"):
        coordination_parts.append(f"assignments {s['pending_assignments']}")
    if s.get("pending_review_requests"):
        coordination_parts.append(f"review requests {s['pending_review_requests']}")
    if s.get("blocking_review_requests"):
        coordination_parts.append(f"blocking reviews {s['blocking_review_requests']}")
    if s.get("blocked_waiting_for_review"):
        coordination_parts.append(f"waiting on review {s['blocked_waiting_for_review']}")
    if coordination_parts:
        click.secho(f"  Coordination: {', '.join(coordination_parts)}", fg="cyan")

    follow_through_lines = (
        _extract_status_follow_through_lines(startup_capsule)
        if startup_capsule
        else _status_follow_through_lines(client, s)
    )
    for line in follow_through_lines:
        if line.startswith("  "):
            click.echo(line)
        else:
            click.echo(f"  {line}")


@cli.command()
@click.option('--online-only', is_flag=True, help="Only show currently online agents")
@click.option('--json-output', is_flag=True, help="Output as JSON")
def who(online_only, json_output):
    """Show all registered agents with their current status."""
    client = WhispersClient("cli-user", read_only=True)
    agents = client.list_agents()

    if online_only:
        agents = [a for a in agents if a.get("is_online")]

    if json_output:
        import json as _json
        click.echo(_json.dumps(agents, indent=2, default=str))
        return

    if not agents:
        click.echo("No registered agents.")
        return

    primary_agents = [a for a in agents if a.get("is_primary_participant", a.get("is_first_class_participant", True))]
    secondary_agents = [a for a in agents if not a.get("is_primary_participant", a.get("is_first_class_participant", True))]
    online = [a for a in primary_agents if a.get("is_online")]
    offline = [a for a in primary_agents if not a.get("is_online")]
    other_online = [a for a in secondary_agents if a.get("is_online")]
    other_offline = [a for a in secondary_agents if not a.get("is_online")]

    def _agent_line(a):
        name = a["callsign"]
        display = f" ({a['display_name']})" if a.get("display_name") else ""
        agent_type = a.get("agent_type", "unknown")
        participant_kind = a.get("participant_kind")
        kind = (
            f" <{participant_kind}>"
            if participant_kind in ("service", "automaton", "ephemeral")
            else ""
        )
        wake = _wake_display(a)
        mode = f" [{a['reception_mode'].upper()}]" if a.get("reception_mode") and a["reception_mode"] != "open" else ""
        working = f" — {a['working_on']}" if a.get("working_on") else ""
        task = f" — {a['current_task']}" if a.get("current_task") and not working else ""
        active_mode = a.get("derived_active_mode", "")
        readiness = a.get("readiness", "")
        status_parts = []
        if active_mode and active_mode not in ("offline", "ready"):
            status_parts.append(active_mode)
        elif readiness and readiness != "ready":
            status_parts.append(readiness)
        status_str = f" ({', '.join(status_parts)})" if status_parts else ""
        basis = _basis_label(a)
        basis_tag = f" [{basis}]" if basis else ""
        freshness = _freshness_label(a)
        fresh_tag = f" ({freshness})" if freshness else ""
        last_seen = ""
        seen_ts = a.get("session_last_seen") or a.get("last_active") or a.get("last_seen")
        if seen_ts and not a.get("is_online"):
            last_seen = f" last seen {_display_timestamp(seen_ts)}"
        return f"    {name}{display} [{agent_type}]{kind}{wake}{mode}{basis_tag}{fresh_tag}{status_str}{working}{task}{last_seen}"

    if online:
        click.secho(f"Online ({len(online)}):", fg="green", bold=True)
        for a in online:
            click.echo(_agent_line(a))

    if offline and not online_only:
        click.secho(f"Offline ({len(offline)}):", fg="white", dim=True)
        for a in offline:
            click.echo(_agent_line(a))

    if not online_only and (other_online or other_offline):
        click.secho(f"Secondary tracked participants ({len(secondary_agents)}):", fg="white", dim=True)
        for a in other_online:
            click.echo(_agent_line(a))
        for a in other_offline:
            click.echo(_agent_line(a))

    click.echo(f"\n  {len(online)} online / {len(primary_agents)} primary / {len(secondary_agents)} secondary tracked")


@cli.command()
@click.option('--server', default=None, help="Remote Whispers server URL")
@click.option('--profile', 'profile_name', default=None, help="Stored connection profile to use for remote auth")
@click.option('--token', 'token_override', default=None, help="Bearer token override for remote auth")
@click.option('--agent-name', default=None, help="Local agent name when inspecting an embedded/local identity")
@click.option('--json-output', is_flag=True, help="Emit raw JSON")
def card(server, profile_name, token_override, agent_name, json_output):
    """Show the authenticated or local agent card."""
    if server or profile_name:
        remote = _resolve_remote_profile(
            server=server,
            profile_name=profile_name,
            token=token_override,
            agent_name=agent_name,
        )
        client = WhispersClient(
            remote["agent_name"] or "cli-user",
            server=remote["server"],
            token=remote["token"],
            profile=profile_name,
        )
    else:
        if not agent_name:
            raise click.ClickException("Local card lookup requires --agent-name.")
        client = WhispersClient(agent_name, read_only=True)

    payload = client.whoami()
    if not payload:
        target = agent_name or "authenticated agent"
        raise click.ClickException(f"No agent card found for {target}.")

    if json_output:
        click.echo(json.dumps(payload, indent=2, default=str))
        return

    click.echo(f"Callsign: {payload.get('callsign', payload.get('agent_name', '-'))}")
    if payload.get("display_name"):
        click.echo(f"  Display Name: {payload['display_name']}")
    click.echo(f"  Agent ID: {payload.get('agent_id', '-')}")
    click.echo(f"  Type: {payload.get('agent_type', '-')}")
    if payload.get("participant_kind"):
        click.echo(f"  Participant Kind: {payload['participant_kind']}")
    if payload.get("participant_profiles"):
        click.echo(f"  Participant Profiles: {', '.join(str(item) for item in payload['participant_profiles'])}")
    if payload.get("agent_tier"):
        click.echo(f"  Agent Tier: {payload['agent_tier']}")
    click.echo(f"  Trust Tier: {payload.get('trust_tier', '-')}")
    if payload.get("max_receive_rate") is not None:
        click.echo(f"  Max Receive Rate: {payload['max_receive_rate']}")
    if payload.get("model_id"):
        click.echo(f"  Model: {payload['model_id']}")
    if payload.get("description"):
        click.echo(f"  Description: {payload['description']}")
    if payload.get("registered_at"):
        click.echo(f"  Registered: {_display_timestamp(payload.get('registered_at'))}")
    if payload.get("last_seen"):
        click.echo(f"  Last Seen: {_display_timestamp(payload.get('last_seen'))}")


@cli.command()
@click.option('--server', required=True, help="Remote Whispers server URL")
@click.option('--profile', 'profile_name', default='default', show_default=True, help="Local connection profile name")
@click.option('--agent-name', default=None, help="Remote agent identity to create or resume")
@click.option('--owner-slug', default=None, help="Stable owner identity used to derive a default handle")
@click.option('--surface', default=None, help="Worksurface suffix used with --owner-slug, e.g. codex")
@click.option('--display-name', default=None, help="Friendly display name stored alongside the durable callsign")
def connect(server, profile_name, agent_name, owner_slug, surface, display_name):
    """Create or resume a remote Whispers connection profile."""
    server = server.rstrip("/")

    # Step 0: Verify server is reachable before attempting connect.
    preflight_health = _remote_server_health(server)
    if not preflight_health:
        raise click.ClickException(
            f"Cannot reach Whispers server at {server}. "
            "Verify the URL and that the server is running."
        )

    profiles = _load_profiles()
    credentials = _load_credentials()
    existing_profile = profiles.get("profiles", {}).get(profile_name, {})
    existing_credential = credentials.get("profiles", {}).get(profile_name, {})

    if not agent_name:
        agent_name = existing_credential.get("agent_name") or existing_profile.get("agent_name")
    owner_slug = owner_slug or existing_profile.get("owner_slug") or os.getenv("WHISPERS_OWNER_SLUG")
    if not surface:
        surface = existing_profile.get("surface")
    if not display_name:
        display_name = existing_profile.get("display_name")
    if not agent_name:
        if owner_slug:
            inferred_surface = surface or (profile_name if profile_name != "default" else "cli")
            surface = inferred_surface
            agent_name = suggest_callsign(owner_slug, inferred_surface)
            if not display_name:
                display_name = suggest_display_name(inferred_surface)
        else:
            agent_name = click.prompt("Agent name")

    payload = {
        "agent_name": agent_name,
        "token": existing_credential.get("token"),
        "display_name": display_name,
        "client": {"name": "whispers-cli", "version": "1.0"},
        "capabilities": {
            "transport": "http",
            "profiles": True,
            "lease_renewal": True,
        },
    }

    result = _server_connect(server, payload)

    # Step 2: Verify the returned token works (handshake).
    returned_token = result.get("token")
    if not returned_token:
        raise click.ClickException(
            "Server returned no auth token. Connection rejected — the server may be "
            "misconfigured or running in a restricted admission mode."
        )
    try:
        whoami = _server_request(server, "/whoami", method="GET", token=returned_token, timeout=5)
        if not isinstance(whoami, dict) or not whoami.get("agent_name"):
            raise click.ClickException(
                "Token verification failed: /whoami returned an unexpected response. "
                "The session may not be active on the server. Profile was NOT saved."
            )
        # Verify the token belongs to the correct agent — not just any agent.
        expected_name = result.get("agent_name") or ""
        verified_name = whoami.get("agent_name") or ""
        if verified_name != expected_name:
            raise click.ClickException(
                f"Token verification failed: /whoami returned agent '{verified_name}' "
                f"but expected '{expected_name}'. "
                "Profile was NOT saved — the server may have issued the wrong token."
            )
    except click.ClickException:
        raise
    except Exception as exc:
        raise click.ClickException(
            f"Token verification failed after connecting: {exc}. "
            "Profile was NOT saved — retry connect once the server is stable."
        ) from exc

    profiles_path, credentials_path = _persist_connection_profile(
        profile_name,
        server,
        result,
        owner_slug=owner_slug,
        surface=surface,
        display_name=display_name,
    )

    peers_online = result.get("status", {}).get("peers_online_count")
    if peers_online is None:
        peers_online = preflight_health.get("peers_online_count", "?")

    click.secho(
        f"Connected to {server} as {result['agent_name']} ({result.get('token_status', 'ok')}).",
        fg="green",
    )
    click.echo(f"  Profile: {profile_name}")
    click.echo(f"  Profiles: {profiles_path}")
    click.echo(f"  Credentials: {credentials_path}")
    click.echo(f"  Session: {result['session']['session_id']}")
    click.echo(f"  Lease expires: {_display_timestamp(result['session']['lease_expires_at'])}")
    if display_name:
        click.echo(f"  Display Name: {display_name}")
    click.echo(f"  Peers online: {peers_online}")
    click.echo(f"  Pending messages: {result.get('status', {}).get('pending_messages', 0)}")
    click.secho(f"  Token verified via /whoami — session active.", fg="green")


@cli.command()
@click.option('--new-callsign', required=True, help="New durable callsign to claim")
@click.option('--display-name', default=None, help="Optional updated display name")
@click.option('--server', default=None, help="Remote Whispers server URL")
@click.option('--profile', 'profile_name', default=None, help="Stored connection profile to use for remote rename")
@click.option('--token', 'token_override', default=None, help="Bearer token override for remote auth")
@click.option('--agent-name', default=None, help="Local agent name when renaming an embedded/local identity")
def rename(new_callsign, display_name, server, profile_name, token_override, agent_name):
    """Rename a durable callsign while preserving tokens, sessions, and pending inbox state."""
    if server or profile_name:
        remote = _resolve_remote_profile(
            server=server,
            profile_name=profile_name,
            token=token_override,
            agent_name=agent_name,
        )
        client = WhispersClient(
            remote["agent_name"] or "cli-user",
            server=remote["server"],
            token=remote["token"],
            profile=profile_name,
        )
        result = client.rename(new_callsign, display_name=display_name)
        if profile_name:
            _update_profile_identity(
                profile_name,
                agent_name=result.get("agent_name"),
                display_name=result.get("display_name") or display_name,
                session=result.get("session"),
            )
        click.secho(
            f"Renamed {result.get('old_callsign', remote['agent_name'])} -> {result.get('new_callsign', new_callsign)}.",
            fg="green",
        )
        click.echo(f"  Pending recipients moved: {result.get('moved_pending_recipients', 0)}")
        if result.get("display_name"):
            click.echo(f"  Display Name: {result['display_name']}")
        if result.get("stream_restart_required"):
            click.echo("  Stream Restart: required")
        return

    if not agent_name:
        raise click.ClickException("Local rename requires --agent-name.")
    client = WhispersClient(agent_name)
    result = client.rename(new_callsign, display_name=display_name)
    click.secho(f"Renamed {result.get('old_callsign', agent_name)} -> {result.get('new_callsign', new_callsign)}.", fg="green")
    click.echo(f"  Pending recipients moved: {result.get('moved_pending_recipients', 0)}")
    if result.get("display_name"):
        click.echo(f"  Display Name: {result['display_name']}")


@cli.command()
@click.option('--agent-name', default=None, help="Agent identity to remove locally or disconnect remotely")
@click.option('--server', default=None, help="Remote Whispers server URL")
@click.option('--profile', 'profile_name', default=None, help="Stored connection profile to use for remote auth")
@click.option('--token', 'token_override', default=None, help="Bearer token override for remote auth")
@click.option('--yes', is_flag=True, help="Confirm the action without prompting")
@click.option('--json-output', is_flag=True, help="Emit raw JSON")
def deregister(agent_name, server, profile_name, token_override, yes, json_output):
    """Deregister a local agent or disconnect the current remote session."""
    if not yes:
        raise click.ClickException("Pass --yes to confirm deregistration or remote disconnect.")

    if server or profile_name:
        remote = _resolve_remote_profile(
            server=server,
            profile_name=profile_name,
            token=token_override,
            agent_name=agent_name,
        )
        client = WhispersClient(
            remote["agent_name"] or "cli-user",
            server=remote["server"],
            token=remote["token"],
            profile=profile_name,
        )
        result = client.deregister()
        if json_output:
            click.echo(json.dumps(result, indent=2, default=str))
            return
        click.secho(f"Disconnected remote session for {result.get('agent_name', remote.get('agent_name') or 'agent')}.", fg="green")
        return

    if not agent_name:
        raise click.ClickException("Local deregistration requires --agent-name.")

    client = WhispersClient(agent_name)
    result = client.deregister()
    if json_output:
        click.echo(json.dumps(result, indent=2, default=str))
        return

    if result.get("status") == "not_found":
        click.echo(f"Agent {agent_name} was not registered.")
        return

    cleanup = result.get("cleanup") or {}
    click.secho(f"Deregistered {result.get('agent_name', agent_name)}.", fg="green")
    click.echo(f"  Pending inbound recipients cleaned up: {cleanup.get('inbound_recipients', 0)}")
    click.echo(f"  Pending outbound recipients cleaned up: {cleanup.get('outbound_recipients', 0)}")
    click.echo(f"  Dead letters created: {cleanup.get('dead_letters_created', 0)}")


@cli.group()
def narrator():
    """Manage the narrator agent designation."""
    pass


@narrator.command("set")
@click.argument("callsign")
def narrator_set(callsign):
    """Designate an agent as the narrator."""
    from .server import runtime_settings
    runtime_settings.update(narrator_agent=callsign)
    click.secho(f"Narrator designated: {callsign}", fg="green")
    status = runtime_settings.narrator_status()
    click.echo(f"  Status: {status}")


@narrator.command("clear")
def narrator_clear():
    """Remove the narrator designation (return to floor mode)."""
    from .server import runtime_settings
    runtime_settings.update(narrator_agent=None)
    click.secho("Narrator cleared. Floor mode (typed signals only).", fg="yellow")


@narrator.command("status")
def narrator_status_cmd():
    """Show current narrator designation and activation state."""
    from .server import runtime_settings
    agent = runtime_settings.narrator_agent()
    status = runtime_settings.narrator_status()
    if not agent:
        click.echo("Narrator: not designated (floor mode)")
        click.echo("  Typed coordination signals are emitted normally.")
        click.echo("  Designate a narrator with: whispers narrator set <callsign>")
        return
    click.echo(f"Narrator agent: {agent}")
    click.echo(f"  Status: {status}")
    if status == "designated":
        click.echo("  The narrator agent is not currently online.")
    elif status == "active":
        click.secho("  Narrator is active and connected.", fg="green")
    elif status == "degraded":
        click.secho("  Narrator was active but lost connection.", fg="yellow")


@cli.group()
def identity():
    """Inspect or manage authenticated identity properties."""
    pass


@identity.group("key")
def identity_key():
    """Inspect or bind the current handle's public key."""
    pass


@identity_key.command("show")
@click.option('--server', default=None, help="Remote Whispers server URL")
@click.option('--profile', 'profile_name', default=None, help="Stored connection profile to use for remote lookup")
@click.option('--token', 'token_override', default=None, help="Bearer token override for remote auth")
@click.option('--agent-name', default=None, help="Local agent name when inspecting an embedded/local identity")
@click.option('--json-output', is_flag=True, help="Emit raw JSON")
def identity_key_show(server, profile_name, token_override, agent_name, json_output):
    """Show the authenticated agent's bound public key, if any."""
    if server or profile_name:
        remote = _resolve_remote_profile(
            server=server,
            profile_name=profile_name,
            token=token_override,
            agent_name=agent_name,
        )
        client = WhispersClient(
            remote["agent_name"] or "cli-user",
            server=remote["server"],
            token=remote["token"],
            profile=profile_name,
        )
    else:
        if not agent_name:
            raise click.ClickException("Local identity key lookup requires --agent-name.")
        client = WhispersClient(agent_name, read_only=True)

    payload = client.identity_key()
    if json_output:
        click.echo(json.dumps(payload, indent=2))
        return

    click.echo(f"Agent: {payload.get('agent_name', agent_name or '-')}")
    click.echo(f"  Public Key Bound: {'yes' if payload.get('public_key_bound') else 'no'}")
    if payload.get("public_key_fingerprint"):
        click.echo(f"  Public Key Fingerprint: {payload['public_key_fingerprint']}")
    click.echo(f"  Public Key Present: {'yes' if payload.get('public_key') else 'no'}")


@identity_key.command("bind")
@click.option('--public-key', default=None, help="Public key value to bind")
@click.option('--public-key-file', default=None, type=click.Path(exists=True, dir_okay=False, path_type=str), help="Read the public key from a file")
@click.option('--replace', is_flag=True, help="Replace an existing bound key")
@click.option('--server', default=None, help="Remote Whispers server URL")
@click.option('--profile', 'profile_name', default=None, help="Stored connection profile to use for remote auth")
@click.option('--token', 'token_override', default=None, help="Bearer token override for remote auth")
@click.option('--agent-name', default=None, help="Local agent name when binding an embedded/local identity")
def identity_key_bind(public_key, public_key_file, replace, server, profile_name, token_override, agent_name):
    """Bind a public key to the current authenticated handle."""
    key_value = _load_public_key_input(public_key, public_key_file)
    if server or profile_name:
        remote = _resolve_remote_profile(
            server=server,
            profile_name=profile_name,
            token=token_override,
            agent_name=agent_name,
        )
        client = WhispersClient(
            remote["agent_name"] or "cli-user",
            server=remote["server"],
            token=remote["token"],
            profile=profile_name,
        )
    else:
        if not agent_name:
            raise click.ClickException("Local identity key binding requires --agent-name.")
        client = WhispersClient(agent_name)

    payload = client.bind_identity_key(key_value, replace=replace)
    outcome = payload.get("binding_outcome", "bound")
    click.secho(f"{outcome.capitalize()} public key for {payload.get('agent_name', agent_name)}.", fg="green")
    if payload.get("public_key_fingerprint"):
        click.echo(f"  Public Key Fingerprint: {payload['public_key_fingerprint']}")


@cli.group()
def token():
    """Manage Whispers API tokens."""
    pass


@token.command("create")
@click.option('--agent-name', default=None, help="Local agent name when minting a token directly from the DB")
@click.option('--description', default='cli_token', show_default=True, help="Token description")
@click.option(
    '--scopes',
    default=None,
    help="Comma-separated scopes (e.g. messages:send,presence:read). Overrides --scope-profile.",
)
@click.option(
    '--scope-profile',
    type=click.Choice(['external-agent', 'full-agent', 'operator', 'read-only']),
    default=None,
    help="Preset scope profile. Ignored if --scopes is provided.",
)
@click.option('--server', default=None, help="Remote Whispers server URL")
@click.option('--profile', 'profile_name', default=None, help="Stored connection profile to use for remote auth")
@click.option('--token', 'token_override', default=None, help="Bearer token override for remote auth")
def token_create(agent_name, description, scopes, scope_profile, server, profile_name, token_override):
    """Create a new API token locally or against a remote server."""
    if server or profile_name:
        remote = _resolve_remote_profile(server=server, profile_name=profile_name, token=token_override, agent_name=agent_name)
        if not remote["token"]:
            raise click.ClickException("Remote token creation requires an authenticated token or profile.")
        result = _server_request(
            remote["server"],
            "/token:create",
            payload={"description": description},
            method="POST",
            token=remote["token"],
        )
        click.echo(json.dumps(result, indent=2))
        return

    if not agent_name:
        raise click.ClickException("Local token creation requires --agent-name.")
    from .storage.db import WhispersDB, WhispersDBError
    db = WhispersDB()
    scope_list = [s.strip() for s in scopes.split(",")] if scopes else None
    try:
        raw_token = db.issue_api_token(
            agent_name,
            description=description,
            scopes=scope_list,
            profile=scope_profile,
        )
    except WhispersDBError as exc:
        raise click.ClickException(str(exc))
    token_row = db.get_api_token(raw_token) or {}
    token_scopes = json.loads(token_row.get("scopes", '["*"]'))
    click.secho(f"Token created for {agent_name}", fg="green")
    click.echo(f"  Token: {raw_token}")
    click.echo(f"  Token ID: {token_row.get('token_id', '?')}")
    click.echo(f"  Scopes: {', '.join(token_scopes)}")
    click.echo(f"  Description: {description}")
    click.secho("  ⚠ Save this token — it cannot be retrieved later.", fg="yellow")


@token.command("revoke")
@click.option('--token-value', default=None, help="Raw token value to revoke. Defaults to the current profile token for remote use.")
@click.option('--server', default=None, help="Remote Whispers server URL")
@click.option('--profile', 'profile_name', default=None, help="Stored connection profile to use for remote auth")
@click.option('--token', 'token_override', default=None, help="Bearer token override for remote auth")
def token_revoke(token_value, server, profile_name, token_override):
    """Revoke a token locally or against a remote server."""
    if server or profile_name:
        remote = _resolve_remote_profile(server=server, profile_name=profile_name, token=token_override)
        if not remote["token"]:
            raise click.ClickException("Remote token revocation requires an authenticated token or profile.")
        target_token = token_value or remote["token"]
        result = _server_request(
            remote["server"],
            "/token:revoke",
            payload={"token": target_token},
            method="POST",
            token=remote["token"],
        )
        if profile_name and target_token == remote["token"]:
            _update_profile_credentials(profile_name, token="")
        click.echo(json.dumps(result, indent=2))
        return

    if not token_value:
        raise click.ClickException("Local token revocation requires --token-value.")
    from .storage.db import WhispersDB
    db = WhispersDB()
    token_row = db.revoke_api_token(token_value)
    if not token_row:
        raise click.ClickException("Token not found.")
    click.echo(json.dumps({"ok": True, "token_id": token_row["token_id"], "agent_name": token_row["agent_name"]}, indent=2))


@token.command("rotate")
@click.option('--token-value', default=None, help="Raw token value to rotate locally.")
@click.option('--description', default='rotated_cli_token', show_default=True, help="Token description")
@click.option('--server', default=None, help="Remote Whispers server URL")
@click.option('--profile', 'profile_name', default=None, help="Stored connection profile to use for remote auth")
@click.option('--token', 'token_override', default=None, help="Bearer token override for remote auth")
def token_rotate(token_value, description, server, profile_name, token_override):
    """Rotate a token locally or against a remote server."""
    if server or profile_name:
        remote = _resolve_remote_profile(server=server, profile_name=profile_name, token=token_override)
        if not remote["token"]:
            raise click.ClickException("Remote token rotation requires an authenticated token or profile.")
        result = _server_request(
            remote["server"],
            "/token:rotate",
            payload={"description": description},
            method="POST",
            token=remote["token"],
        )
        if not isinstance(result, dict):
            raise click.ClickException("Remote token rotation returned a non-object payload.")
        if profile_name:
            _update_profile_credentials(profile_name, token=result.get("token"), session=result.get("session"))
        click.echo(json.dumps(result, indent=2))
        return

    if not token_value:
        raise click.ClickException("Local token rotation requires --token-value.")
    from .storage.db import WhispersDB
    db = WhispersDB()
    token_row = db.get_api_token_any(token_value)
    if not token_row:
        raise click.ClickException("Token not found.")
    new_token = db.issue_api_token(token_row["agent_name"], description=description)
    db.revoke_api_token(token_value)
    new_token_row = db.get_api_token(new_token) or {}
    click.echo(json.dumps({
        "agent_name": token_row["agent_name"],
        "token": new_token,
        "token_id": new_token_row.get("token_id"),
        "description": description,
    }, indent=2))


@token.command("list")
@click.argument("agent_name")
@click.option("--include-revoked", is_flag=True, help="Include revoked tokens")
@click.option("--json-output", is_flag=True, help="Emit raw JSON")
def token_list(agent_name, include_revoked, json_output):
    """List all tokens for an agent."""
    from .storage.db import WhispersDB

    db = WhispersDB()
    tokens = db.list_api_tokens(agent_name, include_revoked=include_revoked)

    if json_output:
        click.echo(json.dumps(tokens, indent=2, default=str))
        return

    if not tokens:
        click.echo(f"No tokens for {agent_name}.")
        return

    for t in tokens:
        status = "REVOKED" if t.get("revoked_at") else "ACTIVE"
        scopes = t.get("scopes", ["*"])
        if isinstance(scopes, str):
            scopes = json.loads(scopes)
        scope_str = ", ".join(scopes) if scopes else "*"
        color = "red" if status == "REVOKED" else "green"
        click.secho(f"  [{status}] ", fg=color, nl=False)
        click.echo(f"{t['token_id'][:12]}… | {t.get('description', '-')} | scopes: {scope_str}")
        click.echo(f"    Created: {_display_timestamp(t.get('created_at'))}")
        if t.get("last_used_at"):
            click.echo(f"    Last used: {_display_timestamp(t['last_used_at'])}")



@cli.command()
@click.option('--port', default=8752, type=int)
@click.option('--agent', default='whispers-console', help="Agent identity whose Jolt wake packet should be monitored")
@click.option('--profile', 'profile_name', default='default', show_default=True, help="Connection profile to source the SSE token from")
@click.option('--token', default=None, help="Bearer token override for the SSE stream")
def notify(port, agent, profile_name, token):
    """Run a background OS notification daemon for Jolt wake packets."""
    import urllib.request
    import json
    import subprocess
    import platform
    import base64
    import time

    click.secho(f"[*] Starting Jolt Notification Daemon for: {agent}", fg="cyan")
    system = platform.system()
    if not token:
        token = _local_server_auth_token(agent, profile_name=profile_name)
    if not token:
        raise click.ClickException(
            "SSE streaming now requires auth. Connect first or pass --token/--profile."
        )
    server_url = f"http://127.0.0.1:{port}"
    local_sidecar_status = _uses_local_operator_sidecar_token(server_url, token)
    url = f"{server_url}/message:stream/{agent}?token={urllib.parse.quote(token)}"
    try:
        jolt_client, degraded = _build_notify_jolt_client(
            agent_name=agent,
            server_url=server_url,
            token=token,
            profile_name=profile_name,
        )
    except Exception as exc:
        if _is_remote_client_auth_error(exc):
            raise click.ClickException(_remote_client_auth_hint(agent, surface="Jolt sidecar")) from exc
        raise
    if degraded:
        click.secho(
            "[!] Running in degraded read-only mode. Jolt adapter capability could not be registered.",
            fg="yellow",
        )

    def pop_toast(title, text):
        try:
            if system == "Windows":
                ps_script = f"""
[Windows.UI.Notifications.ToastNotificationManager, Windows.UI.Notifications, ContentType = WindowsRuntime] | Out-Null
[Windows.UI.Notifications.ToastNotification, Windows.UI.Notifications, ContentType = WindowsRuntime] | Out-Null
[Windows.Data.Xml.Dom.XmlDocument, Windows.Data.Xml.Dom.XmlDocument, ContentType = WindowsRuntime] | Out-Null
$template = [Windows.UI.Notifications.ToastNotificationManager]::GetTemplateContent([Windows.UI.Notifications.ToastTemplateType]::ToastText02)
$nodes = $template.GetElementsByTagName("text")
$nodes.Item(0).AppendChild($template.CreateTextNode("{title.replace('"', '""')}")) | Out-Null
$nodes.Item(1).AppendChild($template.CreateTextNode("{text.replace('"', '""')}")) | Out-Null
$toast = [Windows.UI.Notifications.ToastNotification]::new($template)
$notifier = [Windows.UI.Notifications.ToastNotificationManager]::CreateToastNotifier("Whispers")
$notifier.Show($toast)
"""
                b64 = base64.b64encode(ps_script.encode('utf-16le')).decode('utf-8')
                subprocess.run(["powershell", "-EncodedCommand", b64], capture_output=True)
            elif system == "Darwin":
                safe_text = text.replace('"', '\\"')
                safe_title = title.replace('"', '\\"')
                script = f'display notification "{safe_text}" with title "{safe_title}"'
                subprocess.run(["osascript", "-e", script], capture_output=True)
            elif system == "Linux":
                subprocess.run(["notify-send", title, text], capture_output=True)
        except Exception as e:
            click.secho(f"Failed to pop native alert: {e}", fg="red")

    last_signature = None
    last_refresh_at = 0.0
    refresh_interval_seconds = 15.0

    def refresh_jolt(*, force: bool = False):
        nonlocal last_signature, last_refresh_at
        last_refresh_at = time.monotonic()

        try:
            status = jolt_client.status()
        except Exception as exc:
            click.secho(f"Jolt refresh failed: {exc}", fg="yellow")
            return
        if degraded and local_sidecar_status:
            status = _overlay_local_sidecar_unread_truth(
                jolt_client,
                status,
                agent_name=agent,
            )

        packet = _current_jolt_packet_from_status(status)
        signature = _jolt_packet_signature(packet)
        if signature is None:
            last_signature = None
            return
        if not force and signature == last_signature:
            return

        notification = _build_jolt_notification(packet, agent_name=agent)
        if notification is None:
            last_signature = signature
            return

        title, body = notification
        if not _should_emit_jolt_notification(packet):
            click.secho(f"Skipping stale Jolt: {title}", fg="yellow")
            last_signature = signature
            return
        pop_toast(title, body)
        click.echo(f"Jolt alert: {title}")
        last_signature = signature

    refresh_jolt(force=True)

    while True:
        try:
            req = urllib.request.Request(url)
            with urllib.request.urlopen(req) as response:
                for line in response:
                    now = time.monotonic()
                    if now - last_refresh_at >= refresh_interval_seconds:
                        refresh_jolt()
                    line = line.decode('utf-8').strip()
                    if line.startswith("data: "):
                        data = line[6:].strip()
                        if data and data != "{}" and data != "keepalive":
                            try:
                                json.loads(data)
                                refresh_jolt()
                            except Exception:
                                pass
        except Exception as e:
            click.secho(f"Stream disconnected... retrying in 5s ({e})", fg="yellow")
            time.sleep(5)
            refresh_jolt()


@cli.command("jolt-terminal")
@click.option('--port', default=8752, type=int)
@click.option('--agent', required=True, help="Agent identity whose Jolt wake packet should be monitored")
@click.option('--profile', 'profile_name', default='default', show_default=True, help="Connection profile to source the SSE token from")
@click.option('--token', default=None, help="Bearer token override for the SSE stream")
@click.option(
    '--host-kind',
    type=click.Choice(["claude_code", "codex_cli", "plain_terminal"]),
    default=None,
    help="Override the terminal host kind advertised to Jolt.",
)
@click.option('--once', is_flag=True, help="Render the current Jolt packet once and exit")
@click.option('--bell/--no-bell', default=True, show_default=True, help="Emit a terminal bell for fresh packets")
@click.option('--json-output', is_flag=True, help="Emit structured JSON instead of ANSI text")
def jolt_terminal(port, agent, profile_name, token, host_kind, once, bell, json_output):
    """Run a managed terminal Jolt sidecar for CLI hosts."""
    import urllib.request
    import json
    import time

    if not token:
        token = _local_server_auth_token(agent, profile_name=profile_name)
    if not token:
        raise click.ClickException(
            "SSE streaming now requires auth. Connect first or pass --token/--profile."
        )

    effective_host_kind = host_kind or _infer_terminal_jolt_host_kind(agent)
    server_url = f"http://127.0.0.1:{port}"
    local_sidecar_status = _uses_local_operator_sidecar_token(server_url, token)
    url = f"{server_url}/message:stream/{agent}?token={urllib.parse.quote(token)}"
    try:
        jolt_client, degraded = _build_terminal_jolt_client(
            agent_name=agent,
            server_url=server_url,
            token=token,
            profile_name=profile_name,
            host_kind=effective_host_kind,
        )
    except Exception as exc:
        if _is_remote_client_auth_error(exc):
            raise click.ClickException(_remote_client_auth_hint(agent, surface="Jolt sidecar")) from exc
        raise

    if not json_output and not once:
        click.secho(
            f"[*] Starting Terminal Jolt Sidecar for: {agent} ({effective_host_kind})",
            fg="cyan",
        )
        if degraded:
            click.secho(
                "[!] Running in degraded read-only mode. Jolt adapter capability could not be registered.",
                fg="yellow",
            )

    last_signature = None
    last_refresh_at = 0.0
    refresh_interval_seconds = 15.0

    def refresh_jolt(*, force: bool = False) -> str:
        nonlocal last_signature, last_refresh_at
        last_refresh_at = time.monotonic()

        try:
            status = jolt_client.status()
        except Exception as exc:
            if not json_output:
                click.secho(f"Jolt refresh failed: {exc}", fg="yellow")
            return "error"
        if degraded and local_sidecar_status:
            status = _overlay_local_sidecar_unread_truth(
                jolt_client,
                status,
                agent_name=agent,
            )

        packet = _current_jolt_packet_from_status(status)
        signature = _jolt_packet_signature(packet)
        if signature is None:
            last_signature = None
            return "none"
        if not force and signature == last_signature:
            return "unchanged"
        last_signature = signature

        if not _should_emit_jolt_notification(packet):
            if json_output and force:
                click.echo(
                    json.dumps(
                        {
                            "agent_name": agent,
                            "suppressed": True,
                            "reason": "stale_hot_thread",
                            "jolt_packet": packet,
                        },
                        indent=2,
                    )
                )
            return "suppressed"

        emitted = _emit_terminal_jolt(
            packet,
            status_snapshot=status,
            agent_name=agent,
            bell=bell,
            json_output=json_output,
        )
        return "emitted" if emitted else "none"

    initial_state = refresh_jolt(force=True)
    if once:
        if initial_state == "none" and not json_output:
            click.echo(f"No current Jolt packet for {agent}.")
        elif initial_state == "suppressed" and not json_output:
            click.echo(f"Current Jolt packet for {agent} is stale and was suppressed.")
        return

    while True:
        try:
            req = urllib.request.Request(url)
            with urllib.request.urlopen(req) as response:
                for line in response:
                    now = time.monotonic()
                    if now - last_refresh_at >= refresh_interval_seconds:
                        refresh_jolt()
                    line = line.decode('utf-8').strip()
                    if line.startswith("data: "):
                        data = line[6:].strip()
                        if data and data != "{}" and data != "keepalive":
                            try:
                                json.loads(data)
                                refresh_jolt()
                            except Exception:
                                pass
        except Exception as e:
            if not json_output:
                click.secho(f"Stream disconnected... retrying in 5s ({e})", fg="yellow")
            time.sleep(5)
            refresh_jolt()


@cli.command()
def sweep():
    """Run the Garbage Collector to clean up expired TTL messages."""
    from .storage.gc import GarbageCollector
    from .storage.db import WhispersDB
    db = WhispersDB()
    gc = GarbageCollector(db)
    swept = gc.sweep()
    click.echo(f"Swept {swept} expired messages to the Dead Letter Queue.")


# ---------------------------------------------------------------------------
# Platform definitions — CORRECT config paths, HTTP-first
# ---------------------------------------------------------------------------

_PLATFORMS = {
    "claude": {
        "config": "~/.claude.json",
        "config_format": "json",
        "config_key": "mcpServers",
        "default_agent": "claude-code",
        "display_name": "Claude Code",
    },
    "gemini": {
        "config": "~/.gemini/settings.json",
        "config_format": "json",
        "config_key": "mcpServers",
        "default_agent": "gemini",
        "display_name": "Gemini CLI",
    },
    "codex": {
        "config": "~/.codex/config.toml",
        "config_format": "toml",
        "config_key": "mcp_servers",
        "default_agent": "codex",
        "display_name": "Codex CLI",
    },
    "cursor": {
        "config": "~/.cursor/mcp.json",
        "config_format": "json",
        "config_key": "mcpServers",
        "default_agent": "cursor",
        "display_name": "Cursor",
    },
    "vscode": {
        "config": "~/AppData/Roaming/Code/User/mcp.json",
        "config_format": "json",
        "config_key": "servers",
        "default_agent": "vscode",
        "display_name": "VS Code",
    },
    "antigravity": {
        "config": "~/.gemini/antigravity/mcp_config.json",
        "config_format": "json",
        "config_key": "mcpServers",
        "default_agent": "antigravity",
        "display_name": "Antigravity",
    },
    "cowork": {
        "config": ("~/Library/Application Support/Claude/claude_desktop_config.json"
                   if sys.platform == "darwin"
                   else "~/AppData/Roaming/Claude/claude_desktop_config.json"),
        "config_format": "json",
        "config_key": "mcpServers",
        "default_agent": "cowork",
        "display_name": "Cowork",
    },
}

_SERVER_PORT = int(os.getenv("WHISPERS_SERVER_PORT", "8752"))
_SERVER_URL = f"http://127.0.0.1:{_SERVER_PORT}"
_MCP_URL = f"{_SERVER_URL}/mcp/"
_INSTALL_STATE_VERSION = 1
_PROFILES_PATH_ENV = "WHISPERS_PROFILES_PATH"
_CREDENTIALS_PATH_ENV = "WHISPERS_CREDENTIALS_PATH"
_LISTENER_STATE_DIR_ENV = "WHISPERS_LISTENER_STATE_DIR"


def _mcp_url_for(agent_name: str, *, jolt: dict | None = None) -> str:
    """Return MCP URL with agent identity query param."""
    params = {"agent": agent_name}
    if isinstance(jolt, dict):
        for key in (
            "jolt_host_kind",
            "jolt_adapter_kind",
            "jolt_can_notify",
            "jolt_can_stage_context",
            "jolt_can_trigger_inference",
        ):
            value = jolt.get(key)
            if value is None:
                continue
            params[key] = str(value).lower() if isinstance(value, bool) else str(value)
    return f"{_SERVER_URL}/mcp/?{urllib.parse.urlencode(params)}"
_HEALTH_URL = f"{_SERVER_URL}/health"
_ENV_PATH = whispers_path(".env")


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _install_state_path() -> str:
    override = os.getenv("WHISPERS_INSTALL_STATE_PATH")
    if override:
        return resolve_path(override)
    return whispers_path("install-state.json")


def _profiles_path() -> str:
    override = os.getenv(_PROFILES_PATH_ENV)
    if override:
        return resolve_path(override)
    return whispers_path("profiles.json")


def _credentials_path() -> str:
    override = os.getenv(_CREDENTIALS_PATH_ENV)
    if override:
        return resolve_path(override)
    return whispers_path("credentials.json")


def _load_json_store(path: str) -> dict:
    if not os.path.exists(path):
        return {}
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
    if not isinstance(data, dict):
        raise ValueError(f"Expected JSON object at {path}")
    return data


def _write_json_store(path: str, payload: dict) -> str:
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2, sort_keys=True)
        f.write("\n")
    return path


def _load_profiles() -> dict:
    return _load_json_store(_profiles_path())


def _write_profiles(payload: dict) -> str:
    return _write_json_store(_profiles_path(), payload)


def _load_credentials() -> dict:
    return _load_json_store(_credentials_path())


def _write_credentials(payload: dict) -> str:
    return _write_json_store(_credentials_path(), payload)


def _normalize_listener_policy(policy: dict | None) -> dict:
    base = {
        "mode": "listen_only",
        "auto_ack_state": None,
        "auto_ack_detail": "",
        "checkpoint_on_wake": False,
    }
    if not isinstance(policy, dict):
        return base
    mode = str(policy.get("mode") or "listen_only")
    normalized = dict(base)
    normalized.update(_LISTENER_POLICY_MODES.get(mode, _LISTENER_POLICY_MODES["listen_only"]))
    detail = policy.get("auto_ack_detail")
    if detail:
        normalized["auto_ack_detail"] = str(detail)
    if isinstance(policy.get("checkpoint_on_wake"), bool):
        normalized["checkpoint_on_wake"] = bool(policy.get("checkpoint_on_wake"))
    override_state = policy.get("auto_ack_state")
    if override_state in {state.value for state in AcknowledgmentState}:
        normalized["auto_ack_state"] = override_state
        if override_state == "processed":
            normalized["mode"] = "auto_ack_processed_checkpoint" if normalized.get("checkpoint_on_wake") else "auto_ack_processed"
        elif override_state == "insufficient_context":
            normalized["mode"] = "auto_ack_insufficient_context"
    return normalized


def _load_listener_policy(profile_name: str | None) -> dict:
    if not profile_name:
        return _normalize_listener_policy(None)
    profiles = _load_profiles()
    profile_entry = profiles.get("profiles", {}).get(profile_name, {})
    return _normalize_listener_policy(profile_entry.get("listener_policy"))


def _update_profile_listener_policy(profile_name: str, *, mode: str, auto_ack_detail: str = "") -> dict:
    profiles = _load_profiles()
    profiles.setdefault("profiles", {})
    if profile_name not in profiles["profiles"]:
        raise click.ClickException(f"Profile '{profile_name}' does not exist.")
    profile_entry = profiles["profiles"].setdefault(profile_name, {})

    policy = _normalize_listener_policy({
        "mode": mode,
        "auto_ack_detail": auto_ack_detail,
    })
    profile_entry["listener_policy"] = policy
    profile_entry["updated_at"] = utc_now_iso()
    _write_profiles(profiles)
    return policy


def _listener_state_dir() -> str:
    override = os.getenv(_LISTENER_STATE_DIR_ENV)
    if override:
        return resolve_path(override)
    return whispers_path("listeners")


def _listener_state_key(*, profile_name: str | None = None, agent_name: str | None = None) -> str:
    if profile_name:
        return f"profile-{normalize_callsign_part(profile_name)}"
    if agent_name:
        return f"agent-{normalize_callsign_part(agent_name)}"
    raise click.ClickException("listener identity requires --profile or --agent-name")


def _listener_state_path(*, profile_name: str | None = None, agent_name: str | None = None) -> str:
    key = _listener_state_key(profile_name=profile_name, agent_name=agent_name)
    return os.path.join(_listener_state_dir(), f"{key}.json")


def _load_listener_runtime_state(*, profile_name: str | None = None, agent_name: str | None = None) -> dict | None:
    path = _listener_state_path(profile_name=profile_name, agent_name=agent_name)
    if not os.path.exists(path):
        return None
    with open(path, "r", encoding="utf-8") as f:
        payload = json.load(f)
    return payload if isinstance(payload, dict) else None


def _write_listener_runtime_state(payload: dict, *, profile_name: str | None = None, agent_name: str | None = None) -> str:
    path = _listener_state_path(profile_name=profile_name, agent_name=agent_name)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2, sort_keys=True)
        f.write("\n")
    return path


def _update_listener_runtime_state(
    updates: dict,
    *,
    profile_name: str | None = None,
    agent_name: str | None = None,
) -> dict:
    current = _load_listener_runtime_state(profile_name=profile_name, agent_name=agent_name) or {}
    merged = dict(current)
    merged.update(updates)
    _write_listener_runtime_state(merged, profile_name=profile_name, agent_name=agent_name)
    return merged


def _listener_log_path(*, profile_name: str | None = None, agent_name: str | None = None) -> str:
    key = _listener_state_key(profile_name=profile_name, agent_name=agent_name)
    return os.path.join(_listener_state_dir(), f"{key}.log")


def _listener_process_running(pid: int | None) -> bool:
    if not pid:
        return False
    if sys.platform == "win32":
        try:
            result = subprocess.run(
                ["tasklist", "/FI", f"PID eq {int(pid)}", "/FO", "CSV", "/NH"],
                capture_output=True,
                text=True,
                check=False,
            )
        except Exception:
            return False
        stdout = result.stdout.strip()
        if not stdout or "No tasks are running" in stdout:
            return False
        return f"\"{int(pid)}\"" in stdout
    try:
        os.kill(int(pid), 0)
        return True
    except OSError:
        return False


def _blank_install_state() -> dict:
    return {
        "version": _INSTALL_STATE_VERSION,
        "updated_at": utc_now_iso(),
        "init": None,
        "targets": {},
    }


def _load_install_state() -> dict | None:
    path = _install_state_path()
    if not os.path.exists(path):
        return None
    with open(path, "r", encoding="utf-8") as f:
        state = json.load(f)
    if not isinstance(state, dict):
        raise ValueError(f"Install state at {path} is not a JSON object")
    return state


def _resolve_local_status_agent_name(explicit_agent_name: str | None = None) -> str:
    explicit = str(explicit_agent_name or "").strip()
    if explicit:
        return explicit

    for env_name in ("WHISPERS_AGENT_NAME", "WHISPERS_CALLSIGN"):
        env_value = str(os.getenv(env_name) or "").strip()
        if env_value:
            return env_value

    codex_markers = (
        str(os.getenv("CODEX_THREAD_ID") or "").strip(),
        str(os.getenv("CODEX_INTERNAL_ORIGINATOR_OVERRIDE") or "").strip(),
    )
    if any(codex_markers):
        return "codex"

    try:
        state = _load_install_state()
    except Exception:
        state = None

    if isinstance(state, dict):
        init_state = state.get("init") or {}
        init_agent_name = str(init_state.get("agent_name") or "").strip()
        if init_agent_name:
            return init_agent_name

        targets = state.get("targets") or {}
        unique_default_agents: list[str] = []
        seen_default_agents: set[str] = set()
        for target in targets.values():
            if not isinstance(target, dict):
                continue
            default_agent = str(target.get("default_agent") or "").strip()
            if not default_agent or default_agent in seen_default_agents:
                continue
            seen_default_agents.add(default_agent)
            unique_default_agents.append(default_agent)
        if len(unique_default_agents) == 1:
            return unique_default_agents[0]

    return "cli-user"


def _load_install_state_report() -> dict:
    path = _install_state_path()
    report = {
        "path": path,
        "present": os.path.exists(path),
        "readable": False,
        "valid": False,
        "state": None,
        "error": None,
    }
    if not report["present"]:
        return report
    try:
        state = _load_install_state()
        report["readable"] = True
        report["valid"] = True
        report["state"] = state
    except Exception as e:
        report["error"] = str(e)
    return report


def _write_install_state(state: dict) -> str:
    path = _install_state_path()
    os.makedirs(os.path.dirname(path), exist_ok=True)
    payload = dict(state)
    payload["version"] = _INSTALL_STATE_VERSION
    payload["updated_at"] = utc_now_iso()
    with open(path, "w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2, sort_keys=True)
        f.write("\n")
    return path


def _entry_token_binding(entry: dict | None) -> str | None:
    if not isinstance(entry, dict):
        return None
    env_var = entry.get("bearer_token_env_var")
    if env_var:
        return f"env_var:{env_var}"
    headers = entry.get("headers", {})
    if isinstance(headers, dict) and headers.get("Authorization"):
        return "authorization_header"
    return None


def _entry_intent(entry: dict | None) -> dict | None:
    if not isinstance(entry, dict):
        return None
    transport = "http" if "url" in entry else "stdio"
    intent = {
        "transport": transport,
        "identity": _extract_identity_from_entry(entry),
        "token_binding": _entry_token_binding(entry),
    }
    if transport == "http":
        intent["url"] = entry.get("url")
    else:
        intent["command"] = entry.get("command")
        intent["args"] = entry.get("args")
    return intent


def _platform_jolt_descriptor(platform: dict) -> dict[str, str | bool]:
    default_agent = str(platform.get("default_agent") or "").strip().lower()
    if default_agent == "antigravity":
        return {
            "jolt_host_kind": "antigravity",
            "jolt_adapter_kind": "native_extension",
        }
    if default_agent == "cursor":
        return {
            "jolt_host_kind": "cursor",
            "jolt_adapter_kind": "native_extension",
        }
    if default_agent == "vscode":
        return {
            "jolt_host_kind": "vscode",
            "jolt_adapter_kind": "native_extension",
        }
    if default_agent == "claude-code":
        return {
            "jolt_host_kind": "claude_code",
            "jolt_adapter_kind": "managed_pty",
        }
    if default_agent == "codex":
        return {
            "jolt_host_kind": "codex_cli",
            "jolt_adapter_kind": "managed_pty",
        }
    if default_agent == "gemini":
        return {
            "jolt_host_kind": "plain_terminal",
            "jolt_adapter_kind": "managed_pty",
        }
    if default_agent == "cowork":
        return {
            "jolt_host_kind": "claude_app",
            "jolt_adapter_kind": "desktop_app",
        }
    return {}


def _effective_mcp_stdio(platform: dict, use_stdio: bool) -> bool:
    """Return the actual transport choice after host-specific resilience rules."""
    if use_stdio:
        return True

    default_agent = str(platform.get("default_agent") or "").strip().lower()
    # Local interactive hosts may prefer stdio for tighter crash-recovery loops,
    # but config repair/install flows must preserve an already-working transport
    # unless the operator explicitly requests a change.
    if default_agent in {"antigravity", "cowork"}:
        return True
    return False


def _build_mcp_entry(platform: dict, token: str, use_stdio: bool) -> dict:
    jolt_descriptor = _platform_jolt_descriptor(platform)

    if use_stdio:
        entry = {
            "command": "whispers-mcp",
            "args": ["--agent-name", platform["default_agent"]],
        }
        for key in (
            "jolt_host_kind",
            "jolt_adapter_kind",
            "jolt_can_notify",
            "jolt_can_stage_context",
            "jolt_can_trigger_inference",
        ):
            value = jolt_descriptor.get(key)
            if value is None:
                continue
            entry["args"].extend([f"--{key.replace('_', '-')}", str(value).lower() if isinstance(value, bool) else str(value)])
        # Claude Code expects "type": "stdio"; Cowork/Claude Desktop does NOT accept it
        if platform["config_format"] == "json" and platform["default_agent"] != "cowork":
            entry["type"] = "stdio"
        return entry

    if platform["config_format"] == "toml":
        return {
            "url": _mcp_url_for(platform["default_agent"], jolt=jolt_descriptor),
            "bearer_token_env_var": "WHISPERS_MCP_TOKEN",
        }

    return {
        "type": "http",
        "url": _mcp_url_for(platform["default_agent"], jolt=jolt_descriptor),
        "headers": {"Authorization": f"Bearer {token}"},
    }


def _desired_mcp_entry(platform: dict, token: str, use_stdio: bool) -> dict:
    return _build_mcp_entry(platform, token, _effective_mcp_stdio(platform, use_stdio))


def _resolved_stdio_choice(platform: dict, use_stdio: bool, existing_entry: dict | None = None) -> bool:
    """Preserve existing transport unless stdio was explicitly requested."""
    if use_stdio:
        return True
    if isinstance(existing_entry, dict):
        return "url" not in existing_entry
    return _effective_mcp_stdio(platform, False)


def _record_install_state(agent_name: str | None = None, db_path: str | None = None,
                          server_db_path: str | None = None, token_source: str | None = None,
                          target_results: dict | None = None) -> None:
    state = _load_install_state() or _blank_install_state()
    if agent_name or db_path or server_db_path or token_source:
        state["init"] = {
            "agent_name": agent_name,
            "db_path": db_path,
            "server_db_path": server_db_path,
            "server_port": _SERVER_PORT,
            "token_source": token_source,
            "recorded_at": utc_now_iso(),
        }

    if target_results:
        targets = state.setdefault("targets", {})
        for name, result in target_results.items():
            if result.get("status") != "configured":
                continue
            targets[name] = {
                "display_name": _PLATFORMS[name]["display_name"],
                "config_path": result.get("config_path"),
                "config_format": _PLATFORMS[name]["config_format"],
                "transport": result.get("transport"),
                "default_agent": _PLATFORMS[name]["default_agent"],
                "entry_intent": result.get("entry_intent"),
                "backup_path": result.get("backup_path"),
                "token_source": token_source,
                "installed_at": utc_now_iso(),
            }

    _write_install_state(state)


def _remove_targets_from_install_state(targets: list[str]) -> dict:
    report = _load_install_state_report()
    outcome = {"removed_targets": [], "deleted_manifest": False, "path": report["path"]}
    if not report["valid"]:
        return outcome

    state = report["state"]
    recorded_targets = state.get("targets", {})
    for target in targets:
        if target in recorded_targets:
            recorded_targets.pop(target, None)
            outcome["removed_targets"].append(target)

    if recorded_targets:
        _write_install_state(state)
    else:
        try:
            os.remove(report["path"])
            outcome["deleted_manifest"] = True
        except OSError:
            _write_install_state(state)

    return outcome


def _get_mcp_token_details() -> dict:
    """Read token from env or ~/.whispers/.env and report the source."""
    token = os.environ.get("WHISPERS_MCP_TOKEN", "").strip()
    if token:
        return {"token": token, "source": "env"}
    if os.path.exists(_ENV_PATH):
        with open(_ENV_PATH) as f:
            for line in f:
                line = line.strip()
                if line.startswith("WHISPERS_MCP_TOKEN="):
                    token = line.split("=", 1)[1].strip().strip('"').strip("'")
                    if token:
                        os.environ["WHISPERS_MCP_TOKEN"] = token
                        return {"token": token, "source": "env_file"}
    return {"token": "", "source": "missing"}


def _get_mcp_token() -> str:
    return _get_mcp_token_details()["token"]


def _expected_db_path() -> str:
    """Return the DB path this shell would use for local Whispers clients."""
    return resolve_path(os.getenv("WHISPERS_DB_PATH") or "~/.whispers/whispers.db")


def _normalize_path(path: str | None) -> str | None:
    """Normalize a path for equality checks across shells and platforms."""
    if not path:
        return None
    return os.path.normcase(resolve_path(path))


def _platform_targets(target: str) -> list[str]:
    return list(_PLATFORMS.keys()) if target == "all" else [target]


def _scan_conflict_paths(db_path: str) -> list[str]:
    found = []
    candidates = [
        whispers_path("whispers.db"),
        resolve_path("./whispers.db"),
    ]
    env_path = os.getenv("WHISPERS_DB_PATH")
    if env_path:
        candidates.insert(0, resolve_path(env_path))

    for path in candidates:
        if os.path.exists(path) and _normalize_path(path) != _normalize_path(db_path):
            found.append(path)
    return found


def _inspect_db_state(db_path: str) -> dict:
    from .storage.db import CURRENT_SCHEMA_VERSION

    result = {
        "db_exists": os.path.exists(db_path),
        "db_writable": False,
        "schema_version": None,
        "schema_current": False,
        "wal_mode": False,
        "legacy_schema_detected": False,
        "open_error": None,
        "write_error": None,
    }
    if not result["db_exists"]:
        return result

    conn = None
    try:
        conn = sqlite3.connect(db_path)
        tables = {
            row[0]
            for row in conn.execute("SELECT name FROM sqlite_master WHERE type = 'table'")
        }
        if "schema_version" in tables:
            row = conn.execute("SELECT MAX(version) FROM schema_version").fetchone()
            result["schema_version"] = row[0] if row else None
            result["schema_current"] = result["schema_version"] == CURRENT_SCHEMA_VERSION
        else:
            result["legacy_schema_detected"] = True

        journal_row = conn.execute("PRAGMA journal_mode").fetchone()
        result["wal_mode"] = bool(journal_row and str(journal_row[0]).lower() == "wal")

        try:
            conn.execute("BEGIN IMMEDIATE")
            conn.rollback()
            result["db_writable"] = True
        except sqlite3.Error as e:
            result["write_error"] = str(e)
    except sqlite3.Error as e:
        result["open_error"] = str(e)
    finally:
        if conn is not None:
            conn.close()

    return result


def _probe_local_writable_db_client_ready(db_path: str) -> tuple[bool, str | None]:
    """Return whether a normal writable WhispersDB open succeeds for this path."""
    from .storage.db import WhispersDB

    whispers_logger = logging.getLogger("whispers")
    previous_level = whispers_logger.level
    try:
        if previous_level == logging.NOTSET or previous_level < logging.ERROR:
            whispers_logger.setLevel(logging.ERROR)
        WhispersDB(db_path)
        return True, None
    except Exception as e:
        return False, str(e)
    finally:
        whispers_logger.setLevel(previous_level)


def _readonly_local_db_fallback_context() -> dict | None:
    local_db_path = _expected_db_path()
    db_state = _inspect_db_state(local_db_path)
    if not db_state.get("db_exists"):
        return None

    fallback_reason = None
    if not db_state.get("db_writable"):
        fallback_reason = db_state.get("write_error") or "local db is not writable"
    else:
        client_ready, client_error = _probe_local_writable_db_client_ready(local_db_path)
        if not client_ready:
            fallback_reason = client_error or "local writable client probe failed"

    if fallback_reason is None:
        return None

    health = _check_server_health()
    server_db_path = health.get("db_path") if isinstance(health, dict) else None
    return {
        "health": health,
        "local_db_path": local_db_path,
        "server_db_path": server_db_path,
        "reason": fallback_reason,
    }


def _check_server_health() -> dict | None:
    """Return the best available local server snapshot for CLI fallback decisions.

    `/readyz` is the fast source of truth for "is the loopback server up and can
    it write to its DB right now?" `/health` is richer, but much heavier. When
    the shell is falling back because the local DB/client path is unusable, we
    should not claim the server is unavailable merely because the heavier status
    endpoint timed out or failed while the lightweight readiness endpoint still
    works.
    """
    global _LAST_LOCAL_SERVER_PROBE_ISSUE
    _LAST_LOCAL_SERVER_PROBE_ISSUE = None
    ready_snapshot = None
    ready_error = None
    try:
        ready_snapshot = _server_request(_SERVER_URL, "/readyz", method="GET", timeout=3)
    except Exception as exc:
        ready_error = exc
        ready_snapshot = None

    health_snapshot = None
    health_error = None
    try:
        health_snapshot = _server_request(_SERVER_URL, "/health", method="GET", timeout=5)
    except Exception as exc:
        health_error = exc
        health_snapshot = None

    if isinstance(health_snapshot, dict):
        if isinstance(ready_snapshot, dict):
            health_snapshot.setdefault("http_server_reachable", True)
            for key in ("db_path", "schema_version", "wal_mode", "db_write_ready"):
                if health_snapshot.get(key) is None and ready_snapshot.get(key) is not None:
                    health_snapshot[key] = ready_snapshot.get(key)
        return health_snapshot

    if isinstance(ready_snapshot, dict):
        return {
            "healthy": bool(ready_snapshot.get("ok", False)),
            "http_server_reachable": True,
            **ready_snapshot,
        }

    probe_issue = None
    for exc, path, stage in (
        (ready_error, "/readyz", "readyz"),
        (health_error, "/health", "health"),
    ):
        if exc is None:
            continue
        candidate = _classify_local_probe_exception(exc, path=path, stage=stage)
        if candidate["status"] == "local_network_stack_error":
            probe_issue = candidate
            break
        probe_issue = probe_issue or candidate

    if probe_issue:
        _LAST_LOCAL_SERVER_PROBE_ISSUE = probe_issue
        pid = _read_server_pid()
        if pid and _is_pid_alive(pid):
            return {
                "healthy": None,
                "http_server_reachable": None,
                "server_process_alive": True,
                "server_pid": pid,
                "probe_issue": probe_issue["detail"],
                "probe_issue_status": probe_issue["status"],
            }

    return None


def _remote_server_health(server: str) -> dict | None:
    health_url = urllib.parse.urljoin(server.rstrip("/") + "/", "health")
    try:
        with urllib.request.urlopen(health_url, timeout=5) as resp:
            return json.loads(resp.read())
    except Exception:
        return None


def _is_readonly_db_error(exc: Exception) -> bool:
    return "readonly" in str(exc).lower()


def _is_remote_client_auth_error(exc: Exception) -> bool:
    text = str(exc)
    return any(
        marker in text
        for marker in (
            "Invalid or revoked token.",
            "Missing bearer token.",
            "Token does not belong to the requested agent.",
        )
    )


def _iter_probe_exception_chain(exc: BaseException):
    seen = set()
    queue = [exc]
    while queue:
        current = queue.pop(0)
        if current is None or id(current) in seen:
            continue
        seen.add(id(current))
        yield current
        reason = getattr(current, "reason", None)
        if isinstance(reason, BaseException):
            queue.append(reason)
        cause = getattr(current, "__cause__", None)
        if isinstance(cause, BaseException):
            queue.append(cause)
        context = getattr(current, "__context__", None)
        if isinstance(context, BaseException):
            queue.append(context)


def _probe_exception_detail(exc: BaseException) -> str:
    for current in _iter_probe_exception_chain(exc):
        text = str(current).strip()
        if text:
            return text
    return exc.__class__.__name__


def _classify_local_probe_exception(exc: BaseException, *, path: str, stage: str | None = None) -> dict:
    detail = _probe_exception_detail(exc)
    lowered = detail.lower()
    winerror = None
    for current in _iter_probe_exception_chain(exc):
        current_winerror = getattr(current, "winerror", None)
        if current_winerror is not None:
            winerror = current_winerror
            break

    status = "probe_error"
    if winerror == 10106 or "winerror 10106" in lowered or "requested service provider could not be loaded or initialized" in lowered:
        status = "local_network_stack_error"

    return {
        "status": status,
        "stage": stage or path.strip("/") or "probe",
        "path": path,
        "detail": detail,
        "winerror": winerror,
    }


def _remote_client_auth_hint(agent_name: str, *, surface: str) -> str:
    return (
        f"{surface} auth failed for {agent_name}. "
        "The available token is not a valid remote client token for /connect, /inbox, or /message:stream. "
        "Use the Whispers MCP startup path for live startup, or provision a real client token for this agent."
    )


def _server_request(
    server: str,
    path: str,
    *,
    payload: dict | None = None,
    query: dict | None = None,
    method: str = "GET",
    token: str | None = None,
    timeout: int = 10,
) -> dict | list | None:
    normalized_server = server.rstrip("/")
    if path.startswith("/"):
        url = f"{normalized_server}{path}"
    else:
        url = urllib.parse.urljoin(normalized_server + "/", path)
    if query:
        query_pairs = [(key, value) for key, value in query.items() if value is not None]
        if query_pairs:
            url = f"{url}?{urllib.parse.urlencode(query_pairs, doseq=True)}"
    headers = {"Content-Type": "application/json", "A2A-Version": "1.0"}
    if token:
        headers["Authorization"] = f"Bearer {token}"
    request = urllib.request.Request(
        url,
        data=json.dumps(payload).encode("utf-8") if payload is not None else None,
        headers=headers,
        method=method,
    )
    try:
        with urllib.request.urlopen(request, timeout=timeout) as resp:
            raw = resp.read()
            if not raw:
                return None
            return json.loads(raw)
    except urllib.error.HTTPError as e:
        detail = e.read().decode("utf-8", errors="replace")
        raise click.ClickException(f"Remote request failed ({e.code}) {path}: {detail}") from e
    except urllib.error.URLError as e:
        raise click.ClickException(f"Remote request failed {path}: {e.reason}") from e


def _resolve_remote_profile(
    *,
    server: str | None = None,
    profile_name: str | None = None,
    agent_name: str | None = None,
    token: str | None = None,
) -> dict:
    profiles = _load_profiles()
    credentials = _load_credentials()
    if profile_name:
        profile_entry = profiles.get("profiles", {}).get(profile_name, {})
        credential_entry = credentials.get("profiles", {}).get(profile_name, {})
        server = server or profile_entry.get("server")
        token = token or credential_entry.get("token")
        agent_name = agent_name or credential_entry.get("agent_name") or profile_entry.get("agent_name")
    if not server:
        raise click.ClickException("Remote server is required. Pass --server or --profile.")
    return {
        "server": server.rstrip("/"),
        "token": token,
        "agent_name": agent_name,
        "profile_name": profile_name,
    }


def _local_server_token_for_agent(agent_name: str | None) -> str | None:
    normalized_server = _SERVER_URL.rstrip("/")
    profiles = _load_profiles().get("profiles", {})
    credentials = _load_credentials().get("profiles", {})

    if agent_name:
        for profile_name, profile_entry in profiles.items():
            if str(profile_entry.get("server") or "").rstrip("/") != normalized_server:
                continue
            credential_entry = credentials.get(profile_name, {})
            profile_agent = credential_entry.get("agent_name") or profile_entry.get("agent_name")
            token = credential_entry.get("token")
            if profile_agent == agent_name and token:
                return token

    default_profile = credentials.get("default", {})
    if default_profile.get("agent_name") == agent_name and default_profile.get("token"):
        return default_profile["token"]

    return None


def _local_server_auth_token(agent_name: str | None, *, profile_name: str | None = None) -> str | None:
    token = _local_server_token_for_agent(agent_name) or _get_mcp_token()
    if token:
        return token
    if profile_name:
        return _load_credentials().get("profiles", {}).get(profile_name, {}).get("token")
    return None


def _uses_local_operator_sidecar_token(server_url: str | None, token: str | None) -> bool:
    if not server_url or not token:
        return False
    local_token = _get_mcp_token()
    if not local_token or token != local_token:
        return False
    parsed = urllib.parse.urlparse(server_url)
    return (parsed.hostname or "").lower() in {"127.0.0.1", "localhost", "::1"}


def _read_inbox_via_local_server(
    *,
    agent_name: str,
    limit: int,
    mark_seen: bool,
    pools: list[str] | None = None,
) -> list[dict]:
    token = _local_server_auth_token(agent_name)
    payload = _server_request(
        _SERVER_URL,
        "/inbox",
        query={
            "agent_name": agent_name,
            "limit": limit,
            "mark_seen": json.dumps(bool(mark_seen)),
            "pools": json.dumps(pools) if pools else None,
        },
        token=token,
    )
    if isinstance(payload, dict):
        messages = payload.get("messages", [])
    elif isinstance(payload, list):
        messages = payload
    else:
        messages = []
    return [dict(message) if isinstance(message, dict) else message for message in messages]


def _send_via_local_server(payload: dict) -> dict:
    sender = payload.get("sender") or payload.get("from_agent")
    token = _local_server_auth_token(sender)
    request = urllib.request.Request(
        f"{_SERVER_URL}/message:send",
        data=json.dumps(payload).encode("utf-8"),
        headers={
            "Content-Type": "application/json",
            "A2A-Version": "1.0",
            **({"Authorization": f"Bearer {token}"} if token else {}),
        },
        method="POST",
    )
    with urllib.request.urlopen(request, timeout=5) as resp:
        return json.loads(resp.read())


def _ack_via_local_server(*, agent_name: str, message_id: str, state: str, detail: str = "") -> dict:
    token = _local_server_auth_token(agent_name)
    payload = _server_request(
        _SERVER_URL,
        "/message:ack",
        method="POST",
        token=token,
        payload={
            "agent_name": agent_name,
            "message_id": message_id,
            "state": state,
            "detail": detail,
        },
    )
    message = payload.get("message") if isinstance(payload, dict) else None
    if not isinstance(message, dict):
        raise click.ClickException("Local server acknowledgment did not return a message record.")
    return dict(message)


def _probe_local_client_auth(agent_name: str) -> dict:
    agent_token = _local_server_token_for_agent(agent_name)
    mcp_token = _get_mcp_token()
    token = agent_token or mcp_token
    source = "agent_token" if agent_token else ("mcp_token" if mcp_token else "missing")
    if not token:
        return {
            "ok": False,
            "source": source,
            "issue": (
                f"No local client token is available for {agent_name}. "
                "Use the Whispers MCP startup path for live startup, or provision a real client token for this agent."
            ),
        }

    try:
        _server_request(
            _SERVER_URL,
            "/inbox",
            query={
                "agent_name": agent_name,
                "limit": 1,
                "mark_seen": json.dumps(False),
            },
            token=token,
            timeout=5,
        )
        return {"ok": True, "source": source}
    except click.ClickException as exc:
        if _is_remote_client_auth_error(exc):
            return {
                "ok": False,
                "source": source,
                "issue": _remote_client_auth_hint(agent_name, surface="Startup/client surfaces"),
            }
        return {
            "ok": False,
            "source": source,
            "issue": f"Startup/client surface probe failed for {agent_name}: {exc}",
        }


def _server_connect(server: str, payload: dict) -> dict:
    result = _server_request(server, "/connect", payload=payload, method="POST")
    if not isinstance(result, dict):
        raise click.ClickException("Remote connect returned a non-object payload.")
    return result


def _load_public_key_input(public_key: str | None, public_key_file: str | None) -> str:
    if public_key_file:
        with open(public_key_file, encoding="utf-8") as handle:
            value = handle.read()
    else:
        value = public_key
    if not value or not value.strip():
        raise click.ClickException("Provide --public-key or --public-key-file.")
    return value.strip()


def _persist_connection_profile(
    profile_name: str,
    server: str,
    result: dict,
    *,
    owner_slug: str | None = None,
    surface: str | None = None,
    display_name: str | None = None,
) -> tuple[str, str]:
    profiles = _load_profiles()
    credentials = _load_credentials()

    profiles.setdefault("profiles", {})
    credentials.setdefault("profiles", {})

    profiles["profiles"][profile_name] = {
        "server": server,
        "agent_name": result["agent_name"],
        "connected_at": utc_now_iso(),
        "capabilities": result.get("capabilities", {}),
        "policy": result.get("policy", {}),
        "session": result.get("session", {}),
    }
    if owner_slug:
        profiles["profiles"][profile_name]["owner_slug"] = owner_slug
    if surface:
        profiles["profiles"][profile_name]["surface"] = surface
    if display_name:
        profiles["profiles"][profile_name]["display_name"] = display_name
    credentials["profiles"][profile_name] = {
        "agent_name": result["agent_name"],
        "token": result["token"],
        "updated_at": utc_now_iso(),
    }

    profiles_path = _write_profiles(profiles)
    credentials_path = _write_credentials(credentials)
    return profiles_path, credentials_path


def _update_profile_credentials(profile_name: str, *, token: str | None = None, session: dict | None = None) -> None:
    profiles = _load_profiles()
    credentials = _load_credentials()
    profiles.setdefault("profiles", {})
    credentials.setdefault("profiles", {})
    profile_entry = profiles["profiles"].setdefault(profile_name, {})
    credential_entry = credentials["profiles"].setdefault(profile_name, {})

    if token is not None:
        credential_entry["token"] = token
        credential_entry["updated_at"] = utc_now_iso()
    if session is not None:
        profile_entry["session"] = session
        profile_entry["updated_at"] = utc_now_iso()

    _write_profiles(profiles)
    _write_credentials(credentials)


def _update_profile_identity(
    profile_name: str,
    *,
    agent_name: str | None = None,
    display_name: str | None = None,
    session: dict | None = None,
) -> None:
    profiles = _load_profiles()
    credentials = _load_credentials()
    profiles.setdefault("profiles", {})
    credentials.setdefault("profiles", {})
    profile_entry = profiles["profiles"].setdefault(profile_name, {})
    credential_entry = credentials["profiles"].setdefault(profile_name, {})

    if agent_name is not None:
        profile_entry["agent_name"] = agent_name
        credential_entry["agent_name"] = agent_name
    if display_name is not None:
        profile_entry["display_name"] = display_name
    if session is not None:
        profile_entry["session"] = session
    profile_entry["updated_at"] = utc_now_iso()
    credential_entry["updated_at"] = utc_now_iso()

    _write_profiles(profiles)
    _write_credentials(credentials)


def _mcp_probe_request(token: str, request_id: int, method: str, params: dict | None = None) -> dict:
    probe_url = _mcp_url_for("_probe")
    timeout_seconds = 30 if method == "tools/list" else 15
    body = json.dumps(
        {
            "jsonrpc": "2.0",
            "id": request_id,
            "method": method,
            "params": params or {},
        }
    ).encode("utf-8")
    req = urllib.request.Request(
        probe_url,
        data=body,
        method="POST",
        headers={
            "Content-Type": "application/json",
            "Accept": "text/event-stream, application/json",
            "Authorization": f"Bearer {token}",
        },
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout_seconds) as resp:
            raw = resp.read()
            http_status = getattr(resp, "status", 200)
    except urllib.error.HTTPError as e:
        raw = b""
        try:
            raw = e.read()
        except Exception:
            pass
        detail = f"HTTP {e.code}"
        if raw:
            try:
                payload = json.loads(raw)
                if isinstance(payload, dict):
                    error = payload.get("error")
                    if isinstance(error, dict):
                        message = error.get("message") or "JSON-RPC error"
                        code = error.get("code")
                        detail = (
                            f"HTTP {e.code} / JSON-RPC {code}: {message}"
                            if code is not None
                            else f"HTTP {e.code}: {message}"
                        )
                    elif payload.get("detail"):
                        detail = f"HTTP {e.code}: {payload['detail']}"
            except Exception:
                body_text = raw.decode("utf-8", errors="replace").strip()
                if body_text:
                    detail = f"HTTP {e.code}: {body_text[:160]}"
        status = "unauthorized" if e.code in (401, 403) else "endpoint_missing" if e.code == 404 else "http_error"
        return {
            "ok": False,
            "status": status,
            "stage": method,
            "detail": detail,
            "http_status": e.code,
        }
    except urllib.error.URLError as e:
        reason = getattr(e, "reason", e)
        status = "timeout" if isinstance(reason, (TimeoutError, socket.timeout)) else "not_ready"
        return {
            "ok": False,
            "status": status,
            "stage": method,
            "detail": str(reason) or str(e),
            "http_status": None,
        }
    except socket.timeout as e:
        return {
            "ok": False,
            "status": "timeout",
            "stage": method,
            "detail": str(e) or "timed out",
            "http_status": None,
        }
    except OSError as e:
        probe_issue = _classify_local_probe_exception(e, path="/mcp/", stage=method)
        return {
            "ok": False,
            "status": probe_issue["status"],
            "stage": method,
            "detail": probe_issue["detail"],
            "http_status": None,
        }
    except Exception as e:
        return {
            "ok": False,
            "status": "probe_error",
            "stage": method,
            "detail": str(e),
            "http_status": None,
        }

    if not raw:
        return {
            "ok": False,
            "status": "invalid_response",
            "stage": method,
            "detail": "empty response body",
            "http_status": http_status,
        }
    try:
        payload = json.loads(raw)
    except json.JSONDecodeError as e:
        return {
            "ok": False,
            "status": "invalid_response",
            "stage": method,
            "detail": f"invalid JSON response: {e.msg}",
            "http_status": http_status,
        }
    if not isinstance(payload, dict):
        return {
            "ok": False,
            "status": "invalid_response",
            "stage": method,
            "detail": "response was not a JSON object",
            "http_status": http_status,
        }
    error = payload.get("error")
    if isinstance(error, dict):
        message = error.get("message") or "JSON-RPC error"
        code = error.get("code")
        return {
            "ok": False,
            "status": "jsonrpc_error",
            "stage": method,
            "detail": f"JSON-RPC {code}: {message}" if code is not None else message,
            "http_status": http_status,
        }
    return {
        "ok": True,
        "status": "ok",
        "stage": method,
        "detail": None,
        "http_status": http_status,
        "payload": payload,
    }


def _synthesize_mcp_probe(tool_count: int | None) -> dict:
    probe = _LAST_MCP_HANDSHAKE if isinstance(_LAST_MCP_HANDSHAKE, dict) else None
    if probe is not None:
        return dict(probe)
    return {
        "ok": tool_count is not None,
        "status": "ok" if tool_count is not None else "unknown",
        "stage": None,
        "detail": None,
        "http_status": None,
        "tool_count": tool_count or 0,
    }


def _mcp_probe_failure_summary(probe: dict | None = None) -> str:
    probe = probe or _synthesize_mcp_probe(None)
    status = probe.get("status")
    stage = probe.get("stage")
    detail = probe.get("detail")

    if status == "unauthorized":
        return "MCP handshake failed — token was rejected by the running server"
    if status == "endpoint_missing":
        return "MCP handshake failed — the running server does not expose /mcp/"
    if status == "local_network_stack_error":
        extra = f" ({detail})" if detail else ""
        return f"MCP handshake could not run from this shell — local loopback networking failed before the probe completed{extra}"
    if status in {"not_ready", "timeout"}:
        extra = f" ({detail})" if detail else ""
        return f"MCP handshake failed — MCP endpoint is not ready yet or is restarting{extra}"
    if status == "invalid_response":
        return "MCP handshake failed — MCP endpoint returned an invalid response"
    if status == "jsonrpc_error" and detail:
        return f"MCP handshake failed during {stage or 'probe'} — {detail}"
    if detail:
        return f"MCP handshake failed during {stage or 'probe'} — {detail}"
    return "MCP handshake failed — server may be misconfigured"


def _mcp_probe_hints(probe: dict | None = None) -> list[str]:
    probe = probe or _synthesize_mcp_probe(None)
    status = probe.get("status")
    if status == "unauthorized":
        return [
            "Check WHISPERS_MCP_TOKEN is set and matches the running server.",
            "Re-run 'whispers mcp-install' if the token or config has drifted.",
        ]
    if status == "local_network_stack_error":
        return [
            "This shell cannot complete loopback HTTP probes because the local Windows socket stack failed before connect().",
            "Do not trust 'doctor --fix' auto-start decisions from this shell until that host networking issue is resolved.",
            "Retry from a healthy shell, or repair the host Winsock/service-provider stack before relying on MCP probe results.",
        ]
    if status in {"not_ready", "timeout", "invalid_response", "probe_error"}:
        return [
            "If the server just started, wait a few seconds and re-run 'whispers doctor'.",
            "Reload your MCP host after 'whispers mcp-install' so it reconnects with the new config.",
        ]
    if status == "endpoint_missing":
        return [
            "Restart the server so the /mcp/ endpoint is mounted from the current build.",
            "Re-run 'whispers doctor' after the restart completes.",
        ]
    return [
        "Run 'whispers doctor --fix' to attempt MCP config repair.",
        "Check WHISPERS_MCP_TOKEN is set and matches the running server.",
    ]


def _check_mcp_handshake(token: str) -> int | None:
    """Probe the MCP endpoint and return the live tool count, or None on failure.

    Uses ?agent=_probe to identify as a diagnostic probe, not a real agent.
    This avoids polluting agent registrations even if future MCP methods
    trigger _get_client().
    """
    global _LAST_MCP_HANDSHAKE
    _LAST_MCP_HANDSHAKE = None
    transient_statuses = {"not_ready", "timeout", "invalid_response", "probe_error"}
    last_failure = None

    for attempt in range(3):
        tools_probe = _mcp_probe_request(token, 1, "tools/list", {})
        if tools_probe["ok"]:
            tools = tools_probe.get("payload", {}).get("result", {}).get("tools", [])
            if isinstance(tools, list):
                tool_count = len(tools)
                _LAST_MCP_HANDSHAKE = {
                    "ok": True,
                    "status": "ok",
                    "stage": "tools/list",
                    "detail": f"MCP handshake OK — {tool_count} tools available",
                    "http_status": tools_probe.get("http_status"),
                    "tool_count": tool_count,
                }
                return tool_count
            last_failure = {
                "ok": False,
                "status": "invalid_response",
                "stage": "tools/list",
                "detail": "tools/list returned a non-list tools payload",
                "http_status": tools_probe.get("http_status"),
            }
        else:
            last_failure = tools_probe

        if attempt < 2 and last_failure and last_failure.get("status") in transient_statuses:
            time.sleep(0.5 * (attempt + 1))
            continue

    _LAST_MCP_HANDSHAKE = last_failure or {
        "ok": False,
        "status": "unknown",
        "stage": None,
        "detail": None,
        "http_status": None,
    }
    return None


# ---------------------------------------------------------------------------
# Recovery timeline helpers
# Persists auto-start events to the shared runtime-state.json so that
# both the CLI (doctor) and the server (/health) can surface them.
# ---------------------------------------------------------------------------

def _recovery_state_path() -> str:
    """Return the shared runtime-state.json path (same as server-side)."""
    override = os.environ.get("WHISPERS_RUNTIME_STATE_PATH", "").strip()
    if override:
        return resolve_path(override)
    return whispers_path("runtime-state.json")


def _read_recovery_timeline() -> dict:
    """Return the 'recovery_timeline' sub-dict from runtime-state.json, or {}."""
    path = _recovery_state_path()
    if not os.path.exists(path):
        return {}
    try:
        with open(path, "r", encoding="utf-8") as f:
            state = json.load(f)
        return state.get("recovery_timeline") or {} if isinstance(state, dict) else {}
    except Exception:
        return {}


def _write_recovery_timeline(updates: dict) -> None:
    """Merge 'updates' into recovery_timeline in the shared runtime-state.json.

    Reads the current file (if any), merges, and writes back atomically.
    Never raises — silently swallows errors so the operator path is non-fatal.
    """
    path = _recovery_state_path()
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        state: dict = {}
        if os.path.exists(path):
            try:
                with open(path, "r", encoding="utf-8") as f:
                    loaded = json.load(f)
                if isinstance(loaded, dict):
                    state = loaded
            except Exception:
                pass
        timeline = state.get("recovery_timeline") or {}
        timeline.update(updates)
        state["recovery_timeline"] = timeline
        with open(path, "w", encoding="utf-8") as f:
            json.dump(state, f, indent=2, sort_keys=True)
            f.write("\n")
    except Exception:
        pass  # Non-fatal — diagnostics should never block operator flow


# Maximum recovery events to retain (oldest trimmed from the front).
_RECOVERY_EVENT_CAP = 50


def _read_recovery_events() -> list:
    """Return the 'recovery_events' list from runtime-state.json, or []."""
    path = _recovery_state_path()
    if not os.path.exists(path):
        return []
    try:
        with open(path, "r", encoding="utf-8") as f:
            state = json.load(f)
        events = state.get("recovery_events") if isinstance(state, dict) else None
        return events if isinstance(events, list) else []
    except Exception:
        return []

def _read_message_events() -> list:
    """Return the 'message_events' list from runtime-state.json, or []."""
    path = _recovery_state_path()
    if not os.path.exists(path):
        return []
    try:
        with open(path, "r", encoding="utf-8") as f:
            state = json.load(f)
        events = state.get("message_events") if isinstance(state, dict) else None
        return events if isinstance(events, list) else []
    except Exception:
        return []

def _write_recovery_event(event_type: str, detail: str, severity: str = "info") -> None:
    """Append a structured recovery event to runtime-state.json.

    Event shape: {type, created_at, detail, severity}
    Valid severity values: "info" | "warning" | "error"
    The list is capped at _RECOVERY_EVENT_CAP entries; oldest are trimmed.
    Never raises — silently swallows IO errors.
    """
    path = _recovery_state_path()
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        state: dict = {}
        if os.path.exists(path):
            try:
                with open(path, "r", encoding="utf-8") as f:
                    loaded = json.load(f)
                if isinstance(loaded, dict):
                    state = loaded
            except Exception:
                pass
        events = state.get("recovery_events")
        if not isinstance(events, list):
            events = []
        events.append({
            "type": event_type,
            "created_at": utc_now_iso(),
            "detail": detail,
            "severity": severity,
        })
        # Trim to cap (keep most recent)
        if len(events) > _RECOVERY_EVENT_CAP:
            events = events[-_RECOVERY_EVENT_CAP:]
        state["recovery_events"] = events
        with open(path, "w", encoding="utf-8") as f:
            json.dump(state, f, indent=2, sort_keys=True)
            f.write("\n")
    except Exception:
        pass  # Non-fatal


def _ensure_server_running() -> bool:
    """Check if server is running, start it if not. Returns True if healthy."""
    health = _check_server_health()
    if health:
        return True

    click.echo("  Starting whispers server...")
    creation_flags = 0
    if sys.platform == "win32":
        creation_flags = subprocess.CREATE_NEW_PROCESS_GROUP | subprocess.DETACHED_PROCESS
    subprocess.Popen(
        [sys.executable, "-c", f"from whispers.server import start; start(port={_SERVER_PORT})"],
        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
        creationflags=creation_flags,
    )

    # Poll for health
    import time
    for _ in range(10):
        time.sleep(1)
        if _check_server_health():
            return True
    return False


def _remote_doctor_result(
    server: str,
    token: str | None = None,
    *,
    profile_name: str | None = None,
) -> dict:
    result = {
        "server": server,
        "reachable": False,
        "health": None,
        "ready": None,
        "authenticated": False,
        "status": None,
        "whoami": None,
        "connection_story": None,
        "issues": [],
        "warnings": [],
        "overall": "FAIL",
    }

    health = _remote_server_health(server)
    if not health:
        result["issues"].append("Remote health endpoint is unreachable.")
        return result

    result["reachable"] = True
    result["health"] = health

    try:
        ready = _server_request(server, "/readyz", method="GET", timeout=5)
        if isinstance(ready, dict):
            result["ready"] = ready
            if not ready.get("ok"):
                result["issues"].append("Remote readiness check is failing.")
    except click.ClickException as exc:
        result["warnings"].append(str(exc))

    if token:
        try:
            result["whoami"] = _server_request(server, "/whoami", method="GET", token=token, timeout=5)
            result["status"] = _server_request(server, "/status", method="GET", token=token, timeout=5)
            try:
                result["connection_story"] = _server_request(server, "/connection-story", method="GET", token=token, timeout=5)
            except click.ClickException as sub_exc:
                result["warnings"].append(f"Connection story unavailable: {sub_exc}")
            result["authenticated"] = True
        except click.ClickException as exc:
            msg = str(exc)
            if "(401)" in msg or "(403)" in msg:
                result["issues"].append(f"Authentication rejected: {msg}")
                result["issues"].append("Your token may have expired, been revoked, or is invalid.")
                if profile_name:
                    result["issues"].append(
                        f"Hint: Run 'whispers connect --server {server} --profile {profile_name}' "
                        "to refresh the remote profile credentials."
                    )
                else:
                    result["issues"].append(
                        f"Hint: Run 'whispers connect --server {server} --profile <name>' "
                        "to provision fresh remote credentials."
                    )
            else:
                result["issues"].append(msg)
    else:
        result["warnings"].append("No remote token available; authenticated checks were skipped.")
        if profile_name:
            result["issues"].append(
                f"Missing authentication token for remote profile '{profile_name}'. "
                f"Run 'whispers connect --server {server} --profile {profile_name}' to provision credentials."
            )
        else:
            result["issues"].append(
                f"Missing authentication token. Run 'whispers connect --server {server} --profile <name>' "
                "to provision credentials."
            )

    if not result["issues"]:
        result["overall"] = "PASS"
    return result


def _stop_local_server() -> dict:
    """Best-effort stop for the local Whispers server when fully uninstalling."""
    result = {
        "attempted": False,
        "stopped": False,
        "warnings": [],
    }
    if not _check_server_health():
        return result

    result["attempted"] = True
    try:
        if sys.platform == "win32":
            cmd = [
                "powershell",
                "-NoProfile",
                "-Command",
                (
                    f"$conn = Get-NetTCPConnection -LocalPort {_SERVER_PORT} -State Listen -ErrorAction SilentlyContinue | "
                    "Select-Object -First 1; "
                    "if ($conn) { Stop-Process -Id $conn.OwningProcess -Force -ErrorAction Stop }"
                ),
            ]
            subprocess.run(cmd, capture_output=True, text=True, timeout=10)
        else:
            subprocess.run(
                ["pkill", "-f", f"whispers.server:app|whispers.server import start|whispers-server"],
                capture_output=True,
                text=True,
                timeout=10,
            )
    except Exception as e:
        result["warnings"].append(f"Could not stop local server: {e}")
        return result

    import time
    for _ in range(10):
        time.sleep(0.5)
        if not _check_server_health():
            result["stopped"] = True
            return result

    result["warnings"].append("Local server still appears to be running after stop attempt.")
    return result


def _read_client_config(platform_name: str) -> tuple[str, dict | None]:
    """Read a client's config. Returns (config_path, config_dict_or_None)."""
    platform = _PLATFORMS[platform_name]
    config_path = resolve_path(platform["config"])
    if not os.path.exists(config_path):
        return config_path, None

    if platform["config_format"] == "json":
        try:
            with open(config_path, "r") as f:
                return config_path, json.load(f)
        except (json.JSONDecodeError, OSError):
            return config_path, None
    elif platform["config_format"] == "toml":
        try:
            import tomllib
            with open(config_path, "rb") as f:
                return config_path, tomllib.load(f)
        except Exception:
            return config_path, None
    return config_path, None


def _get_whispers_entry_from_config(config: dict, platform_name: str) -> dict | None:
    """Extract the whispers server entry from a parsed config."""
    key = _PLATFORMS[platform_name]["config_key"]
    servers = config.get(key, {})
    return servers.get("whispers")


def _existing_whispers_entry(platform_name: str) -> dict | None:
    """Return the currently configured whispers entry for a platform, if any."""
    _, config = _read_client_config(platform_name)
    if not isinstance(config, dict):
        return None
    return _get_whispers_entry_from_config(config, platform_name)


def _extract_identity_from_entry(entry: dict) -> str | None:
    """Extract the configured agent identity from an MCP config entry."""
    if not isinstance(entry, dict):
        return None

    url = entry.get("url")
    if isinstance(url, str):
        parsed = urllib.parse.urlparse(url)
        agent = urllib.parse.parse_qs(parsed.query).get("agent", [None])[0]
        return agent

    args = entry.get("args")
    if isinstance(args, (list, tuple)):
        for i, arg in enumerate(args):
            if arg == "--agent-name" and i + 1 < len(args):
                return str(args[i + 1])

    return None


# ---------------------------------------------------------------------------
# Inject MCP config — HTTP-first, format-aware
# ---------------------------------------------------------------------------

def _inject_mcp_config(target: str, token: str, use_stdio: bool = False, quiet: bool = False) -> dict:
    """Inject Whispers MCP config into a client's config file.

    Returns a structured result with status, config path, and entry intent.
    """
    platform = _PLATFORMS.get(target)
    if not platform:
        if not quiet:
            click.secho(f"  Unknown platform: {target}", fg="red")
        return {"status": "error", "target": target, "config_path": None}

    config_path = resolve_path(platform["config"])
    fmt = platform["config_format"]

    if fmt == "json":
        return _inject_json_config(config_path, platform, token, use_stdio, quiet)
    elif fmt == "toml":
        return _inject_toml_config(config_path, platform, token, use_stdio, quiet)
    return {"status": "error", "target": target, "config_path": config_path}


def _inject_json_config(config_path: str, platform: dict, token: str,
                        use_stdio: bool, quiet: bool) -> dict:
    """Write whispers entry to a JSON config file."""
    backup_path = None
    if os.path.exists(config_path):
        try:
            with open(config_path, "r") as f:
                config = json.load(f)
        except (json.JSONDecodeError, OSError) as e:
            if not quiet:
                click.secho(f"  ERROR reading {config_path}: {e}", fg="red")
            return {"status": "error", "config_path": config_path}
        try:
            backup_path = config_path + ".bak"
            shutil.copy2(config_path, backup_path)
        except (PermissionError, OSError):
            backup_path = None  # Best-effort backup — don't block config write
    else:
        os.makedirs(os.path.dirname(config_path), exist_ok=True)
        config = {}

    key = platform["config_key"]
    if key not in config:
        config[key] = {}

    existing_entry = config[key].get("whispers") if isinstance(config.get(key), dict) else None
    actual_stdio = _resolved_stdio_choice(platform, use_stdio, existing_entry)
    entry = _build_mcp_entry(platform, token, actual_stdio)
    config[key]["whispers"] = entry

    try:
        output = json.dumps(config, indent=2)
        json.loads(output)  # validate roundtrip
    except Exception as e:
        if not quiet:
            click.secho(f"  ERROR generating config: {e}", fg="red")
        return {"status": "error", "config_path": config_path}

    try:
        with open(config_path, "w") as f:
            f.write(output + "\n")
    except (PermissionError, OSError) as e:
        if not quiet:
            click.secho(f"  {platform['display_name']}: SKIPPED — file locked ({e})", fg="yellow")
        return {"status": "locked", "config_path": config_path}

    if not quiet:
        transport = "stdio" if actual_stdio else "HTTP"
        click.secho(f"  {platform['display_name']}: configured ({transport})", fg="green")
    return {
        "status": "configured",
        "config_path": config_path,
        "backup_path": backup_path,
        "transport": "stdio" if actual_stdio else "http",
        "entry_intent": _entry_intent(entry),
    }


def _inject_toml_config(config_path: str, platform: dict, token: str,
                        use_stdio: bool, quiet: bool) -> dict:
    """Write whispers entry to a TOML config file (Codex)."""
    # Read existing content as text
    existing_text = ""
    backup_path = None
    existing_entry = None
    if os.path.exists(config_path):
        try:
            backup_path = config_path + ".bak"
            shutil.copy2(config_path, backup_path)
        except (PermissionError, OSError):
            backup_path = None  # Best-effort backup — don't block config write
        with open(config_path, "r") as f:
            existing_text = f.read()
        try:
            import tomllib
            parsed = tomllib.loads(existing_text)
            servers = parsed.get(platform["config_key"], {})
            existing_entry = servers.get("whispers") if isinstance(servers, dict) else None
        except Exception:
            existing_entry = None

    # Remove any existing [mcp_servers.whispers] section
    import re
    existing_text = re.sub(
        r'\[mcp_servers\.whispers\][^\[]*', '', existing_text, flags=re.DOTALL
    ).rstrip() + "\n"

    # Build new section
    actual_stdio = _resolved_stdio_choice(platform, use_stdio, existing_entry)
    entry = _build_mcp_entry(platform, token, actual_stdio)
    if actual_stdio:
        new_section = (
            '\n[mcp_servers.whispers]\n'
            f'command = "{entry["command"]}"\n'
            f"args = {json.dumps(entry['args'])}\n"
        )
    else:
        new_section = (
            '\n[mcp_servers.whispers]\n'
            f'url = "{entry["url"]}"\n'
            'bearer_token_env_var = "WHISPERS_MCP_TOKEN"\n'
        )
        # Persist token so Codex can find it in any future terminal
        os.environ["WHISPERS_MCP_TOKEN"] = token
        if sys.platform == "win32":
            # Set as persistent user env var on Windows
            import subprocess
            subprocess.run(
                ["setx", "WHISPERS_MCP_TOKEN", token],
                capture_output=True,
            )
            if not quiet:
                click.echo("    Set WHISPERS_MCP_TOKEN as persistent user env var")
        else:
            # On Unix, append to ~/.whispers/.env (already done by server)
            # but also hint the user if their shell won't source it
            pass

    os.makedirs(os.path.dirname(config_path), exist_ok=True)
    try:
        with open(config_path, "w") as f:
            f.write(existing_text + new_section)
    except (PermissionError, OSError) as e:
        if not quiet:
            click.secho(f"  {platform['display_name']}: SKIPPED — file locked ({e})", fg="yellow")
        return {"status": "locked", "config_path": config_path}

    if not quiet:
        transport = "stdio" if actual_stdio else "HTTP"
        click.secho(f"  {platform['display_name']}: configured ({transport})", fg="green")
    return {
        "status": "configured",
        "config_path": config_path,
        "backup_path": backup_path,
        "transport": "stdio" if actual_stdio else "http",
        "entry_intent": _entry_intent(entry),
    }


def _remove_mcp_config(target: str, quiet: bool = False) -> dict:
    platform = _PLATFORMS[target]
    config_path = resolve_path(platform["config"])
    if platform["config_format"] == "json":
        return _remove_json_config(config_path, platform, quiet)
    return _remove_toml_config(config_path, platform, quiet)


def _remove_json_config(config_path: str, platform: dict, quiet: bool) -> dict:
    if not os.path.exists(config_path):
        return {"status": "not_installed", "config_path": config_path}

    try:
        with open(config_path, "r", encoding="utf-8") as f:
            config = json.load(f)
    except (json.JSONDecodeError, OSError) as e:
        if not quiet:
            click.secho(f"  ERROR reading {config_path}: {e}", fg="red")
        return {"status": "error", "config_path": config_path}

    key = platform["config_key"]
    servers = config.get(key, {})
    entry = servers.get("whispers") if isinstance(servers, dict) else None
    if not entry:
        return {"status": "absent", "config_path": config_path}

    backup_path = None
    try:
        backup_path = config_path + ".bak"
        shutil.copy2(config_path, backup_path)
    except (PermissionError, OSError):
        backup_path = None

    del servers["whispers"]
    try:
        with open(config_path, "w", encoding="utf-8") as f:
            json.dump(config, f, indent=2)
            f.write("\n")
    except (PermissionError, OSError) as e:
        if not quiet:
            click.secho(f"  {platform['display_name']}: SKIPPED — file locked ({e})", fg="yellow")
        return {"status": "locked", "config_path": config_path, "entry_intent": _entry_intent(entry)}

    if not quiet:
        click.secho(f"  {platform['display_name']}: removed", fg="green")
    return {
        "status": "removed",
        "config_path": config_path,
        "backup_path": backup_path,
        "entry_intent": _entry_intent(entry),
    }


def _remove_toml_config(config_path: str, platform: dict, quiet: bool) -> dict:
    if not os.path.exists(config_path):
        return {"status": "not_installed", "config_path": config_path}

    try:
        with open(config_path, "r", encoding="utf-8") as f:
            existing_text = f.read()
    except OSError as e:
        if not quiet:
            click.secho(f"  ERROR reading {config_path}: {e}", fg="red")
        return {"status": "error", "config_path": config_path}

    import re

    marker = re.compile(r'(\n)?\[mcp_servers\.whispers\][^\[]*', flags=re.DOTALL)
    match = marker.search(existing_text)
    if not match:
        return {"status": "absent", "config_path": config_path}

    backup_path = None
    try:
        backup_path = config_path + ".bak"
        shutil.copy2(config_path, backup_path)
    except (PermissionError, OSError):
        backup_path = None

    stripped = marker.sub("", existing_text).rstrip() + "\n"
    try:
        with open(config_path, "w", encoding="utf-8") as f:
            f.write(stripped)
    except (PermissionError, OSError) as e:
        if not quiet:
            click.secho(f"  {platform['display_name']}: SKIPPED — file locked ({e})", fg="yellow")
        return {
            "status": "locked",
            "config_path": config_path,
            "entry_intent": {
                "transport": "http" if 'url = "' in match.group(0) else "stdio",
                "identity": platform["default_agent"],
            },
        }

    if not quiet:
        click.secho(f"  {platform['display_name']}: removed", fg="green")
    return {
        "status": "removed",
        "config_path": config_path,
        "backup_path": backup_path,
        "entry_intent": {
            "transport": "http" if 'url = "' in match.group(0) else "stdio",
            "identity": platform["default_agent"],
        },
    }


def _remove_local_credentials() -> dict:
    result = {
        "process_env_removed": False,
        "env_file_updated": False,
        "user_env_removed": False,
        "warnings": [],
    }

    if os.environ.pop("WHISPERS_MCP_TOKEN", None):
        result["process_env_removed"] = True

    if os.path.exists(_ENV_PATH):
        try:
            with open(_ENV_PATH, "r", encoding="utf-8") as f:
                lines = f.readlines()
            filtered = [line for line in lines if not line.strip().startswith("WHISPERS_MCP_TOKEN=")]
            if filtered != lines:
                with open(_ENV_PATH, "w", encoding="utf-8") as f:
                    f.writelines(filtered)
                result["env_file_updated"] = True
        except OSError as e:
            result["warnings"].append(f"Could not update {_ENV_PATH}: {e}")

    if sys.platform == "win32":
        try:
            import winreg

            with winreg.OpenKey(winreg.HKEY_CURRENT_USER, "Environment", 0, winreg.KEY_SET_VALUE) as key:
                try:
                    winreg.DeleteValue(key, "WHISPERS_MCP_TOKEN")
                    result["user_env_removed"] = True
                except FileNotFoundError:
                    pass
        except Exception as e:
            result["warnings"].append(f"Could not remove persistent user env var: {e}")

    return result


def _remove_db_files(db_path: str) -> dict:
    result = {"removed": [], "missing": [], "errors": []}
    for suffix in ("", "-wal", "-shm"):
        path = db_path + suffix
        if not os.path.exists(path):
            result["missing"].append(path)
            continue
        try:
            os.remove(path)
            result["removed"].append(path)
        except OSError as e:
            result["errors"].append(f"{path}: {e}")
    return result


def _compare_manifest_target(managed_target: dict | None, live_entry: dict | None) -> list[str]:
    drift = []
    if not managed_target or not isinstance(managed_target, dict):
        return drift

    managed_intent = managed_target.get("entry_intent") or {}
    live_intent = _entry_intent(live_entry)
    if live_intent is None:
        drift.append("managed target missing from live config")
        return drift

    for key in ("transport", "identity", "url", "command", "args", "token_binding"):
        expected = managed_intent.get(key)
        actual = live_intent.get(key)
        if expected is None and actual is None:
            continue
        if expected != actual:
            drift.append(f"{key}: expected {expected!r}, found {actual!r}")
    return drift


def _resync_install_state_from_live_configs() -> dict:
    """Refresh manifest-managed target intents from current host config without rewriting hosts."""
    report = {
        "path": _install_state_path(),
        "updated": [],
        "skipped": [],
    }
    install_state = _load_install_state_report()
    if not install_state["valid"]:
        return report

    state = install_state["state"]
    targets = state.get("targets")
    if not isinstance(targets, dict):
        return report

    changed = False
    for name, managed_target in list(targets.items()):
        platform = _PLATFORMS.get(name)
        if not platform or not isinstance(managed_target, dict):
            continue

        config_path, config = _read_client_config(name)
        if not isinstance(config, dict):
            continue

        live_entry = _get_whispers_entry_from_config(config, name)
        live_intent = _entry_intent(live_entry)
        if live_intent is None:
            continue

        expected_identity = platform["default_agent"]
        live_identity = live_intent.get("identity")
        if live_identity is not None and live_identity != expected_identity:
            report["skipped"].append(
                {
                    "target": name,
                    "reason": "identity_mismatch",
                    "live_identity": live_identity,
                    "expected_identity": expected_identity,
                }
            )
            continue

        refreshed_target = dict(managed_target)
        refreshed_target.update(
            {
                "display_name": platform["display_name"],
                "config_path": config_path,
                "config_format": platform["config_format"],
                "transport": live_intent.get("transport"),
                "default_agent": expected_identity,
                "entry_intent": live_intent,
            }
        )
        if refreshed_target == managed_target:
            continue

        targets[name] = refreshed_target
        report["updated"].append(name)
        changed = True

    if changed:
        _write_install_state(state)
    return report


def _deregister_existing_agent(agent_name: str, db_path: str) -> dict:
    from .storage.db import WhispersDB

    result = {
        "agent_name": agent_name,
        "status": "not_found",
        "cleanup": {"inbound_recipients": 0, "outbound_recipients": 0, "dead_letters_created": 0},
    }
    db = WhispersDB(db_path)
    with db.get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute(
            "SELECT agent_id FROM agent_cards WHERE callsign = ? AND deregistered_at IS NULL",
            (agent_name,),
        )
        row = cursor.fetchone()
        if not row:
            return result

        cleanup = db.dead_letter_pending_for_agent(agent_name, reason="agent_deregistered")
        cursor.execute(
            "UPDATE agent_cards SET deregistered_at = CURRENT_TIMESTAMP WHERE agent_id = ?",
            (row["agent_id"],),
        )
        cursor.execute("DELETE FROM room_members WHERE agent_id = ?", (row["agent_id"],))
        cursor.execute(
            "UPDATE presence SET status = 'offline', session_id = NULL, working_on = NULL, last_active = CURRENT_TIMESTAMP WHERE agent_name = ?",
            (agent_name,),
        )
        conn.commit()

    result["status"] = "deregistered"
    result["cleanup"] = cleanup
    return result


# ---------------------------------------------------------------------------
# whispers doctor
# ---------------------------------------------------------------------------

@cli.command()
@click.option('--fix', is_flag=True, help="Auto-repair detected issues")
@click.option('--agent-name', default="cli-user", help="Agent to check")
@click.option('--server', default=None, help="Remote Whispers server URL for hosted diagnostics")
@click.option('--profile', 'profile_name', default=None, help="Stored connection profile to use for hosted diagnostics")
def doctor(fix, agent_name, server, profile_name):
    """Run diagnostics on Whispers installation. Returns structured JSON."""
    from .storage.db import WhispersDB, WhispersDBError

    if server or profile_name:
        remote = _resolve_remote_profile(server=server, profile_name=profile_name, agent_name=agent_name)
        result = _remote_doctor_result(
            remote["server"],
            token=remote.get("token"),
            profile_name=remote.get("profile_name"),
        )
        click.echo(json.dumps(result, indent=2))
        return

    result = {
        "db_path": None,
        "db_exists": False,
        "db_writable": False,
        "schema_version": None,
        "schema_current": False,
        "wal_mode": False,
        "legacy_schema_detected": False,
        "agent_registered": False,
        "agent_callsign": agent_name,
        "presence_healthy": False,
        "other_agents_online": 0,
        "pending_messages": 0,
        "server_running": False,
        "http_server_reachable": False,
        # server_state: up | degraded | recovering | down
        # up       = health OK, DB matches, MCP healthy
        # degraded = health OK but DB mismatch or MCP broken
        # recovering = fix was run and repairs were attempted
        # down     = health check failed
        "server_state": "down",
        "server_port": _SERVER_PORT,
        "server_db_path": None,
        "server_db_matches_local": None,
        "server_probe_issue": None,
        "mcp_healthy": False,
        "mcp_tools": 0,
        "mcp_probe": None,
        "token_present": False,
        "token_source": "missing",
        "local_client_auth_healthy": None,
        "local_client_token_source": "unknown",
        "local_client_auth_issue": None,
        "clients": {},
        "install_state": {},
        "conflicts_detected": False,
        "conflict_paths": [],
        "sandbox_warning": None,
        "overall": "FAIL",
        "issues": [],
        "fixes_applied": [],
        "warnings": [],
        # Populated at the end of the run after all checks are complete:
        "server_state_detail": None,
        "server_diagnostics": None,
        # Recovery timeline: sourced from the shared runtime-state.json.
        # Tracks auto-start activity for the Console and operator.
        "recovery_timeline": None,
        # Recovery events: bounded recent history, sourced from runtime-state.json.
        "recovery_events": None,
        # Message events: bounded recent history, authored by db lifecycle hooks.
        "message_events": None,
    }

    # --- Database checks ---
    db_path = _expected_db_path()
    result["db_path"] = db_path
    result["local_db_path"] = db_path  # explicit alias for diagnostics messages
    install_state = _load_install_state_report()
    result["install_state"] = {
        "path": install_state["path"],
        "present": install_state["present"],
        "readable": install_state["readable"],
        "valid": install_state["valid"],
        "error": install_state["error"],
    }
    if install_state["present"] and not install_state["valid"]:
        result["warnings"].append(
            f"Install manifest at {install_state['path']} is unreadable. "
            "Continuing from live inspection only."
        )

    db_state = _inspect_db_state(db_path)
    result["db_exists"] = db_state["db_exists"]
    result["db_writable"] = db_state["db_writable"]
    result["schema_version"] = db_state["schema_version"]
    result["schema_current"] = db_state["schema_current"]
    result["wal_mode"] = db_state["wal_mode"]
    result["legacy_schema_detected"] = db_state["legacy_schema_detected"]

    db = None
    if not result["db_exists"]:
        if fix:
            os.makedirs(os.path.dirname(db_path), exist_ok=True)
            db = WhispersDB(db_path, auto_repair=True)
            result["db_exists"] = True
            result["db_writable"] = True
            result["schema_version"] = db.get_schema_version()
            result["schema_current"] = True
            result["wal_mode"] = db.check_wal_mode()
            result["fixes_applied"].append("Created database")
        else:
            result["issues"].append(f"Database not found at {db_path}. Run 'whispers init'.")
    elif result["legacy_schema_detected"]:
        if fix:
            try:
                db = WhispersDB(db_path, auto_repair=True)
                result["db_writable"] = True
                result["schema_version"] = db.get_schema_version()
                result["schema_current"] = True
                result["wal_mode"] = db.check_wal_mode()
                result["legacy_schema_detected"] = False
                result["fixes_applied"].append("Archived legacy database and rebuilt schema")
            except WhispersDBError as e:
                result["issues"].append(str(e))
        else:
            result["issues"].append(
                f"Legacy or unknown schema detected at {db_path}. Run 'whispers doctor --fix' to archive and rebuild it."
            )
    elif db_state["open_error"]:
        result["issues"].append(f"Database open failed: {db_state['open_error']}")
    elif db_state["write_error"]:
        result["issues"].append(f"Database not writable: {db_state['write_error']}")

    if result["db_exists"] and db is None and not result["legacy_schema_detected"] and not db_state["open_error"]:
        open_read_only = not result["db_writable"]
        try:
            db = WhispersDB(db_path, read_only=open_read_only)
        except sqlite3.Error as e:
            if not open_read_only and _is_readonly_db_error(e):
                result["db_writable"] = False
                readonly_issue = f"Database not writable: {e}"
                if readonly_issue not in result["issues"]:
                    result["issues"].append(readonly_issue)
                try:
                    db = WhispersDB(db_path, read_only=True)
                except (WhispersDBError, sqlite3.Error) as retry_error:
                    retry_issue = str(retry_error)
                    if retry_issue not in result["issues"]:
                        result["issues"].append(retry_issue)
            else:
                issue = str(e)
                if issue not in result["issues"]:
                    result["issues"].append(issue)
        except WhispersDBError as e:
            issue = str(e)
            if issue not in result["issues"]:
                result["issues"].append(issue)

    if db is not None:
        if not result["wal_mode"]:
            if fix:
                if result["db_writable"]:
                    with db.get_connection() as conn:
                        conn.execute("PRAGMA journal_mode=WAL")
                    result["wal_mode"] = True
                    result["fixes_applied"].append("Enabled WAL mode")
                else:
                    result["issues"].append(
                        "WAL mode not enabled, but the database is read-only in this shell. "
                        "Run from a writable environment or align WHISPERS_DB_PATH before retrying --fix."
                    )
            else:
                result["issues"].append("WAL mode not enabled. Run with --fix.")

        client = WhispersClient(agent_name, db_path=db_path, read_only=True)
        agent = client.whoami()
        result["agent_registered"] = agent is not None
        if not result["agent_registered"]:
            result["issues"].append(f"Agent '{agent_name}' not registered.")

        with db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT status, session_id FROM presence WHERE agent_name = ?", (agent_name,))
            prow = cursor.fetchone()
            if prow:
                result["presence_healthy"] = prow["status"] == "online" and prow["session_id"] is not None
                if not result["presence_healthy"] and result["agent_registered"]:
                    status_val = prow["status"] if prow else "absent"
                    result["warnings"].append(
                        f"Agent '{agent_name}' is registered but not actively connected "
                        f"(presence status: {status_val}). This is normal for CLI identities "
                        f"that aren't long-running MCP sessions."
                    )
            elif result["agent_registered"]:
                result["warnings"].append(
                    f"Agent '{agent_name}' is registered but has no presence record. "
                    f"It may not have connected via MCP yet."
                )
            cursor.execute("SELECT COUNT(*) FROM presence WHERE status IN ('online','idle') AND agent_name != ?", (agent_name,))
            result["other_agents_online"] = cursor.fetchone()[0]
            cursor.execute("""
                SELECT COUNT(*) FROM messages m
                JOIN message_recipients r ON m.uuid = r.message_uuid
                WHERE r.recipient_callsign = ?
                  AND m.status = 'new'
                  AND r.delivery_status IN ('queued', 'unclaimed', 'delivered')
                  AND r.read_at IS NULL
                  AND r.archived_at IS NULL
                  AND (r.snoozed_until IS NULL OR r.snoozed_until <= CURRENT_TIMESTAMP)
            """, (agent_name,))
            result["pending_messages"] = cursor.fetchone()[0]

    # --- Server + MCP checks ---
    token_details = _get_mcp_token_details()
    result["token_present"] = bool(token_details["token"])
    result["token_source"] = token_details["source"]

    health = _check_server_health()
    result["server_running"] = health is not None
    if isinstance(health, dict):
        result["http_server_reachable"] = health.get("http_server_reachable")
        if health.get("probe_issue"):
            result["server_probe_issue"] = {
                "status": health.get("probe_issue_status"),
                "detail": health.get("probe_issue"),
                "server_pid": health.get("server_pid"),
            }
    elif isinstance(_LAST_LOCAL_SERVER_PROBE_ISSUE, dict):
        result["server_probe_issue"] = dict(_LAST_LOCAL_SERVER_PROBE_ISSUE)
    local_probe_broken = (
        isinstance(result["server_probe_issue"], dict)
        and result["server_probe_issue"].get("status") == "local_network_stack_error"
    )
    if local_probe_broken:
        detail = result["server_probe_issue"].get("detail")
        result["warnings"].append(
            "Local loopback probes failed in this shell before a connection attempt completed."
            + (f" Detail: {detail}" if detail else "")
        )
    if not result["server_running"]:
        result["server_state"] = "down"
        if fix and not local_probe_broken:
            attempt_at = utc_now_iso()
            _write_recovery_timeline({"last_auto_start_attempt": attempt_at})
            _write_recovery_event(
                "auto_start_attempted",
                f"doctor --fix triggered server auto-start on port {_SERVER_PORT}.",
                severity="info",
            )
            if _ensure_server_running():
                health = _check_server_health()
                result["server_running"] = health is not None
                if isinstance(health, dict):
                    result["http_server_reachable"] = health.get("http_server_reachable")
                    if health.get("probe_issue"):
                        result["server_probe_issue"] = {
                            "status": health.get("probe_issue_status"),
                            "detail": health.get("probe_issue"),
                            "server_pid": health.get("server_pid"),
                        }
                    else:
                        result["server_probe_issue"] = None
                if result["server_running"]:
                    recovered_at = utc_now_iso()
                    _write_recovery_timeline({"last_successful_recovery_at": recovered_at})
                    _write_recovery_event(
                        "auto_start_succeeded",
                        f"Server came up on port {_SERVER_PORT} after auto-start.",
                        severity="info",
                    )
                    result["server_state"] = "recovering"
                    result["fixes_applied"].append(f"Started server on port {_SERVER_PORT}")
                else:
                    _write_recovery_event(
                        "auto_start_failed",
                        f"Server did not respond on port {_SERVER_PORT} after auto-start attempt.",
                        severity="error",
                    )
                    result["issues"].append(
                        f"Server auto-start attempted but server still not reachable on port {_SERVER_PORT}."
                    )
            else:
                _write_recovery_event(
                    "auto_start_failed",
                    f"_ensure_server_running() returned False — process may not have launched on port {_SERVER_PORT}.",
                    severity="error",
                )
                result["issues"].append(
                    f"Server auto-start failed on port {_SERVER_PORT}. Try manually: whispers serve"
                )
        elif fix and local_probe_broken:
            result["issues"].append(
                "Skipped server auto-start because this shell cannot complete local loopback probes reliably."
            )
        else:
            if local_probe_broken:
                result["issues"].append(
                    "Could not verify whether the local server is reachable because this shell's loopback networking failed before connect()."
                )
            else:
                result["issues"].append(
                    f"Server not running on port {_SERVER_PORT}. Start with: whispers serve"
                )
    if result["server_running"]:
        server_db_path = health.get("db_path") if isinstance(health, dict) else None
        result["server_db_path"] = server_db_path
        result["server_db_matches_local"] = (
            _normalize_path(server_db_path) == _normalize_path(db_path)
            if server_db_path
            else None
        )
        if server_db_path and not result["server_db_matches_local"]:
            result["issues"].append(
                f"Server is using {server_db_path}, but this shell expects {db_path}. "
                "Stop the other server or align WHISPERS_DB_PATH before relying on this install."
            )
        token = token_details["token"]
        if not token:
            result["issues"].append("No MCP token found in ~/.whispers/.env")
        else:
            global _LAST_MCP_HANDSHAKE
            _LAST_MCP_HANDSHAKE = None
            tool_count = _check_mcp_handshake(token)
            probe = _synthesize_mcp_probe(tool_count)
            result["mcp_probe"] = probe
            if tool_count is not None:
                result["mcp_healthy"] = True
                result["mcp_tools"] = tool_count
            else:
                result["issues"].append(_mcp_probe_failure_summary(probe))

        if result["server_db_matches_local"] is not False and result["mcp_healthy"]:
            auth_probe = _probe_local_client_auth(agent_name)
            result["local_client_auth_healthy"] = auth_probe["ok"]
            result["local_client_token_source"] = auth_probe["source"]
            result["local_client_auth_issue"] = auth_probe.get("issue")
            if auth_probe.get("issue") and auth_probe["issue"] not in result["issues"]:
                result["issues"].append(auth_probe["issue"])

    # --- Manifest resync (--fix) ---
    # Refresh manifest-managed intents from live host config before any host rewrite logic.
    if fix and install_state["valid"]:
        manifest_resync = _resync_install_state_from_live_configs()
        if manifest_resync["updated"]:
            for name in manifest_resync["updated"]:
                platform = _PLATFORMS.get(name)
                display_name = platform["display_name"] if platform else name
                result["fixes_applied"].append(
                    f"Resynced install manifest for {display_name} from live MCP config"
                )
            install_state = _load_install_state_report()
            result["install_state"].update(
                {
                    "present": install_state["present"],
                    "readable": install_state["readable"],
                    "valid": install_state["valid"],
                    "error": install_state["error"],
                }
            )

    # --- Per-client config drift repair (--fix) ---
    # Must run before the per-client config checks so the check reflects the fixed state.
    if fix and result["server_running"]:
        token = token_details["token"]
        if token:
            for name in list(_PLATFORMS.keys()):
                config_path, config = _read_client_config(name)
                if config is None:
                    continue  # Platform not installed — skip
                entry = _get_whispers_entry_from_config(config, name)
                if entry is None:
                    continue  # Whispers not in this config — skip (don't inject uninvited)
                platform = _PLATFORMS[name]
                # Compare structurally first (transport, identity, url, etc.)
                live_intent = _entry_intent(entry)
                desired = _build_mcp_entry(
                    platform,
                    token,
                    bool(live_intent and live_intent.get("transport") == "stdio"),
                )
                desired_intent = _entry_intent(desired)
                drifted = live_intent != desired_intent
                # Also detect token-value drift for Authorization-header entries.
                # _entry_intent only compares the binding *type* ("authorization_header"),
                # not the actual token value.
                if not drifted and isinstance(entry, dict) and isinstance(desired, dict):
                    live_auth = entry.get("headers", {}).get("Authorization", "")
                    desired_auth = desired.get("headers", {}).get("Authorization", "")
                    if live_auth and desired_auth and live_auth != desired_auth:
                        drifted = True
                if drifted:
                    inject_result = _inject_mcp_config(name, token, quiet=True)
                    if inject_result.get("status") == "configured":
                        result["fixes_applied"].append(
                            f"Repaired MCP config for {platform['display_name']}"
                        )

    # --- Per-client config checks ---
    manifest_targets = install_state["state"].get("targets", {}) if install_state["valid"] else {}
    token = _get_mcp_token()
    for name, platform in _PLATFORMS.items():
        config_path, config = _read_client_config(name)
        managed_target = manifest_targets.get(name)
        if config is None:
            if os.path.exists(os.path.dirname(config_path)):
                result["clients"][name] = {
                    "configured": False,
                    "reason": "config missing or unreadable",
                    "manifest_managed": managed_target is not None,
                }
            else:
                result["clients"][name] = {
                    "configured": False,
                    "reason": "not installed",
                    "manifest_managed": managed_target is not None,
                }
            continue

        entry = _get_whispers_entry_from_config(config, name)
        if not entry:
            client_payload = {
                "configured": False,
                "reason": "whispers not in config",
                "manifest_managed": managed_target is not None,
            }
            drift = _compare_manifest_target(managed_target, None)
            if drift:
                client_payload["manifest_drift"] = drift
                result["warnings"].append(
                    f"{platform['display_name']} no longer matches the install manifest: {'; '.join(drift)}"
                )
            result["clients"][name] = client_payload
            continue

        transport = "http" if "url" in entry else "stdio"
        identity = _extract_identity_from_entry(entry)
        expected_identity = platform["default_agent"]
        identity_healthy = identity == expected_identity if identity is not None else False
        token_match = False
        if transport == "http" and token:
            entry_token = entry.get("headers", {}).get("Authorization", "")
            token_match = entry_token == f"Bearer {token}"
            if not token_match:
                # Codex uses bearer_token_env_var
                env_var = entry.get("bearer_token_env_var", "")
                if env_var and os.environ.get(env_var) == token:
                    token_match = True

        result["clients"][name] = {
            "configured": True,
            "transport": transport,
            "identity": identity,
            "expected_identity": expected_identity,
            "identity_healthy": identity_healthy,
            "token_match": token_match if transport == "http" else None,
            "config_path": config_path,
            "manifest_managed": managed_target is not None,
        }
        drift = _compare_manifest_target(managed_target, entry) if managed_target else []
        if drift:
            result["clients"][name]["manifest_drift"] = drift
            result["warnings"].append(
                f"{platform['display_name']} differs from the install manifest: {'; '.join(drift)}"
            )
        if identity is None:
            result["warnings"].append(
                f"{platform['display_name']} whispers config has no explicit identity configured."
            )
        elif identity != expected_identity:
            result["warnings"].append(
                f"{platform['display_name']} whispers config identity '{identity}' "
                f"does not match expected '{expected_identity}'."
            )

    if install_state["valid"]:
        init_state = install_state["state"].get("init") or {}
        result["install_state"]["managed_targets"] = sorted(manifest_targets.keys())
        result["install_state"]["init_agent_name"] = init_state.get("agent_name")
        result["install_state"]["init_db_path"] = init_state.get("db_path")
        result["install_state"]["init_db_matches_local"] = (
            _normalize_path(init_state.get("db_path")) == _normalize_path(db_path)
            if init_state.get("db_path")
            else None
        )
        result["install_state"]["server_db_matches_manifest"] = (
            _normalize_path(init_state.get("server_db_path")) == _normalize_path(result.get("server_db_path"))
            if init_state.get("server_db_path") and result.get("server_db_path")
            else None
        )
        if init_state.get("db_path") and not result["install_state"]["init_db_matches_local"]:
            result["warnings"].append(
                f"Install manifest expects DB {init_state['db_path']}, but this shell resolves to {db_path}."
            )

    # --- Conflict detection ---
    conflicts = _scan_conflict_paths(db_path)
    if conflicts:
        result["conflicts_detected"] = True
        result["conflict_paths"] = conflicts
        result["warnings"].append(f"Stray whispers.db files: {', '.join(conflicts)}")
        if fix:
            for stray in conflicts:
                renamed = stray + ".stale.bak"
                i = 1
                while os.path.exists(renamed):
                    renamed = stray + f".stale.{i}.bak"
                    i += 1
                try:
                    shutil.move(stray, renamed)
                    for suffix in ['-wal', '-shm']:
                        wal = stray + suffix
                        if os.path.exists(wal):
                            shutil.move(wal, renamed + suffix)
                    result["fixes_applied"].append(f"Renamed stray DB: {stray} -> {os.path.basename(renamed)}")
                except PermissionError:
                    result["warnings"].append(
                        f"Cannot rename stray DB {stray} — file is locked by another process. "
                        f"Close any tools using it, then re-run 'whispers doctor --fix'."
                    )

            # Cap stale backups at 5 — delete oldest beyond that to prevent unbounded accumulation
            stale_dir = os.path.dirname(db_path)
            stale_files = sorted(
                [os.path.join(stale_dir, f) for f in os.listdir(stale_dir) if '.stale.' in f and f.endswith('.bak')],
                key=lambda p: os.path.getmtime(p),
                reverse=True,
            )
            max_stale = 5
            if len(stale_files) > max_stale:
                for old_stale in stale_files[max_stale:]:
                    try:
                        os.remove(old_stale)
                        # Also remove WAL/SHM companions
                        for suffix in ['-wal', '-shm']:
                            companion = old_stale + suffix
                            if os.path.exists(companion):
                                os.remove(companion)
                    except OSError:
                        pass
                pruned = len(stale_files) - max_stale
                result["fixes_applied"].append(f"Pruned {pruned} old stale backup(s), kept newest {max_stale}")

    # --- Sandbox radar ---
    cwd = os.getcwd()
    temp_patterns = ["AppData", "Temp", ".gemini", "worktree", "sandbox"]
    if any(p.lower() in cwd.lower() for p in temp_patterns):
        result["sandbox_warning"] = f"Running from isolated directory: {cwd}"
        result["warnings"].append(result["sandbox_warning"])

    # --- server_state derivation + diagnostics ---
    # Finalize server_state, server_state_detail, and server_diagnostics after
    # all checks are complete so every field is available for evaluation.
    db_ok = result["server_db_matches_local"] is not False
    mcp_ok = result["mcp_healthy"]

    # Build the canonical diagnostics object regardless of state.
    # 'checks' gives the Console structured boolean data per dimension.
    # 'failing_checks' is the pre-filtered list so callers don't have to scan.
    # 'hints' are operator-useful next steps.
    server_reachable_check = result["http_server_reachable"]
    if result["server_running"] and server_reachable_check is None:
        server_reachable_check = True

    diag_checks = {
        "server_reachable": server_reachable_check if server_reachable_check is not False else False,
        "db_path_match": db_ok,
        "mcp_handshake": mcp_ok,
        "local_client_auth": result["local_client_auth_healthy"],
    }
    failing = [k for k, v in diag_checks.items() if v is False]
    hints: list[str] = []
    mcp_probe = result.get("mcp_probe") or _synthesize_mcp_probe(
        result["mcp_tools"] if result["mcp_healthy"] else None
    )

    if result["server_running"]:
        local_client_ok = result["local_client_auth_healthy"] is not False
        if db_ok and mcp_ok and local_client_ok:
            if result["server_state"] == "recovering":
                # Auto-start succeeded and all checks pass — keep recovering
                state_detail = (
                    "Server was restarted automatically and all systems are now operational."
                )
                hints.append("No further action needed. Monitor for stability.")
            else:
                result["server_state"] = "up"
                state_detail = "All systems operational."
        else:
            # Unhealthy even after a fix attempt → degraded wins over recovering
            result["server_state"] = "degraded"
            detail_parts: list[str] = []
            if isinstance(result["server_probe_issue"], dict) and result["server_probe_issue"].get("status") == "local_network_stack_error":
                detail_parts.append(
                    "Local loopback probes failed in this shell before connect(), so server liveness is inferred from the live PID rather than HTTP reachability"
                )
                hints.append("Avoid 'whispers doctor --fix' in this shell while the local socket stack is broken.")
            if not mcp_ok:
                detail_parts.append(_mcp_probe_failure_summary(mcp_probe))
                for hint in _mcp_probe_hints(mcp_probe):
                    if hint not in hints:
                        hints.append(hint)
            if not db_ok:
                detail_parts.append(
                    f"DB path mismatch — server uses '{result.get('server_db_path', '?')}' "
                    f"but local env resolves to '{result.get('local_db_path', '?')}'"
                )
                hints.append("Ensure WHISPERS_DB_PATH is consistent between CLI and server environments.")
                hints.append("Run 'whispers init' in the correct shell to pin the DB path.")
            if result["local_client_auth_healthy"] is False:
                detail_parts.append(
                    "Startup/client auth surfaces reject the available local token"
                )
                hints.append(
                    "Use the Whispers MCP startup path for live startup until a real client token exists for this agent."
                )
                hints.append(
                    "Provision a real client token for this agent if it needs /inbox, /connect, or /message:stream."
                )
            state_detail = "; ".join(detail_parts) or "One or more subsystems are unhealthy."
    else:
        result["server_state"] = "down"
        if isinstance(result["server_probe_issue"], dict) and result["server_probe_issue"].get("status") == "local_network_stack_error":
            state_detail = (
                "Local loopback probes failed in this shell before connect(), so server reachability could not be verified."
            )
            hints.append("Retry from a shell with a healthy Windows socket stack before trusting reachability results.")
            hints.append("Do not use 'whispers doctor --fix' here unless you have separately confirmed the server is down.")
        else:
            state_detail = f"Server is not running or not reachable on port {_SERVER_PORT}."
            hints.append(f"Start the server with: whispers serve")
            hints.append("Run 'whispers doctor --fix' to attempt automatic restart.")

    result["server_state_detail"] = state_detail
    result["server_diagnostics"] = {
        "checks": diag_checks,
        "failing_checks": failing,
        "hints": hints,
    }

    # Record state-change events so the Console has backend-authored history.
    # Only meaningful transitions are recorded — not routine healthy polls.
    final_state = result["server_state"]
    if final_state == "degraded":
        _write_recovery_event(
            "state_degraded",
            f"doctor detected degraded state: {state_detail}",
            severity="warning",
        )
    elif final_state == "up":
        # Record state_up_restored only when a prior auto-start attempt exists,
        # so we don't flood the history on routine healthy doctor runs.
        prior_timeline = _read_recovery_timeline()
        if prior_timeline.get("last_auto_start_attempt"):
            _write_recovery_event(
                "state_up_restored",
                "doctor confirmed server is up. All checks passing.",
                severity="info",
            )

    # Recovery timeline: read from shared runtime-state.json.
    # Includes timestamps from any prior auto-start attempt, plus whether
    # this run performed the restart (auto_started = True when fix was applied).
    timeline = _read_recovery_timeline()
    timeline["auto_started"] = result["server_state"] == "recovering"
    result["recovery_timeline"] = timeline

    # Recovery events: bounded recent history for Console display.
    result["recovery_events"] = _read_recovery_events()

    # Message events: bounded recent lifecycle history for Console display.
    result["message_events"] = _read_message_events()

    # Overall
    if not result["issues"]:
        result["overall"] = "PASS"

    click.echo(json.dumps(result, indent=2))



# ---------------------------------------------------------------------------
# whispers init
# ---------------------------------------------------------------------------

@cli.command()
@click.option('--agent-name', default=None, help="Agent callsign to register")
def init(agent_name):
    """Initialize Whispers from scratch — DB, server, MCP config, verification."""
    from .storage.db import WhispersDB, WhispersDBError

    if not agent_name:
        agent_name = "cli-user"
        click.echo("No --agent-name specified, using 'cli-user'.")

    db_path = _expected_db_path()
    os.makedirs(os.path.dirname(db_path), exist_ok=True)

    # Step 1: DB
    click.echo(f"1. Database at {db_path}...")
    try:
        db = WhispersDB(db_path)
    except WhispersDBError as e:
        click.secho("   FAILED: database state is ambiguous or legacy", fg="red")
        click.echo(f"   {e}")
        click.echo("   Run 'whispers doctor --fix' to archive and rebuild it safely.")
        return
    if not db.check_wal_mode():
        with db.get_connection() as conn:
            conn.execute("PRAGMA journal_mode=WAL")
            conn.execute("PRAGMA busy_timeout=5000")

    client = WhispersClient(agent_name, db_path=db_path)
    agent = client.whoami()
    click.secho(f"   Agent '{agent_name}' registered ({agent['agent_id'][:8]}...)", fg="green")

    # Step 2: Server
    click.echo("2. Ensuring server is running...")
    if _ensure_server_running():
        health = _check_server_health() or {}
        server_db_path = health.get("db_path") if isinstance(health, dict) else None
        if server_db_path and _normalize_path(server_db_path) != _normalize_path(db_path):
            click.secho("   FAILED: running server is using a different database", fg="red")
            click.echo(f"   Local DB:  {db_path}")
            click.echo(f"   Server DB: {resolve_path(server_db_path)}")
            click.echo("   Stop the existing server or align WHISPERS_DB_PATH, then retry.")
            return
        click.secho(f"   Server healthy on port {_SERVER_PORT}", fg="green")
    else:
        click.secho(f"   FAILED to start server on port {_SERVER_PORT}", fg="red")
        click.echo("   Try manually: whispers serve")
        return

    # Step 3: MCP install
    click.echo("3. Configuring MCP clients...")
    token_details = _get_mcp_token_details()
    token = token_details["token"]
    if not token:
        click.secho("   No token found — server may not have generated one yet", fg="red")
        return

    install_results = {}
    for name, platform in _PLATFORMS.items():
        config_path = resolve_path(platform["config"])
        config_dir = os.path.dirname(config_path)
        if os.path.isdir(config_dir) or os.path.exists(config_path):
            install_results[name] = _inject_mcp_config(name, token)
        else:
            install_results[name] = {"status": "skipped", "config_path": config_path}
            click.echo(f"   {platform['display_name']}: not installed, skipping")

    # Step 4: Verify
    click.echo("4. Verifying MCP connection...")
    global _LAST_MCP_HANDSHAKE
    _LAST_MCP_HANDSHAKE = None
    tool_count = _check_mcp_handshake(token)
    probe = _synthesize_mcp_probe(tool_count)
    if tool_count is not None:
        click.secho(f"   MCP handshake OK — {tool_count} tools available", fg="green")
    else:
        click.secho(f"   {_mcp_probe_failure_summary(probe)}", fg="yellow")
        for hint in _mcp_probe_hints(probe):
            click.echo(f"   {hint}")

    _record_install_state(
        agent_name=agent_name,
        db_path=db_path,
        server_db_path=server_db_path,
        token_source=token_details["source"],
        target_results=install_results,
    )

    click.echo("")
    click.secho("Done.", fg="green", bold=True)
    click.secho("IMPORTANT: Reload or restart your LLM host now to mount the new Whispers tools.", fg="yellow", bold=True)
    click.echo(f"  Server:  {_SERVER_URL}")
    click.echo(f"  MCP:     {_MCP_URL}")
    click.echo(f"  Token:   {token[:8]}...")


# ---------------------------------------------------------------------------
# whispers mcp-install
# ---------------------------------------------------------------------------

@cli.command('mcp-install')
@click.option('--target', type=click.Choice(['claude', 'gemini', 'codex', 'cursor', 'vscode', 'antigravity', 'cowork', 'all']),
              default='all', help="Target platform (default: all detected)")
@click.option('--stdio', 'use_stdio', is_flag=True, help="Use stdio transport instead of HTTP")
def mcp_install(target, use_stdio):
    """Configure MCP clients with host-appropriate Whispers transport defaults."""
    targets = _platform_targets(target)
    requires_http_preflight = any(
        not _resolved_stdio_choice(_PLATFORMS[t], use_stdio, _existing_whispers_entry(t))
        for t in targets
    )

    # Step 1: Ensure server is running (unless --stdio)
    if requires_http_preflight:
        click.echo("Checking server...")
        if not _ensure_server_running():
            click.secho(f"ERROR: Cannot start server on port {_SERVER_PORT}", fg="red")
            click.echo("Start manually with: whispers serve")
            return

        health = _check_server_health()
        click.secho(f"  Server healthy (port {_SERVER_PORT})", fg="green")
        server_db_path = health.get("db_path") if isinstance(health, dict) else None
        local_db_path = _expected_db_path()
        if server_db_path and _normalize_path(server_db_path) != _normalize_path(local_db_path):
            click.secho("  WARNING: running server is using a different database than this shell", fg="yellow")
            click.echo(f"    Local DB:  {local_db_path}")
            click.echo(f"    Server DB: {resolve_path(server_db_path)}")

    # Step 2: Get token
    token_details = _get_mcp_token_details()
    token = token_details["token"]
    if requires_http_preflight and not token:
        click.secho("ERROR: No MCP token. Server may not have started properly.", fg="red")
        return

    # Step 3: Verify MCP works (unless --stdio)
    if requires_http_preflight:
        global _LAST_MCP_HANDSHAKE
        _LAST_MCP_HANDSHAKE = None
        tool_count = _check_mcp_handshake(token)
        probe = _synthesize_mcp_probe(tool_count)
        if tool_count is not None:
            click.secho(f"  MCP handshake OK ({tool_count} tools)", fg="green")
        else:
            click.secho(f"WARNING: {_mcp_probe_failure_summary(probe)} — writing config anyway", fg="yellow")
            for hint in _mcp_probe_hints(probe):
                click.echo(f"  {hint}")

    # Step 4: Configure each platform
    click.echo("")
    results = {}

    for t in targets:
        platform = _PLATFORMS[t]
        config_path = resolve_path(platform["config"])
        config_dir = os.path.dirname(config_path)

        if target == "all" and not (os.path.isdir(config_dir) or os.path.exists(config_path)):
            results[t] = {"status": "skipped", "detail": "not installed", "config_path": config_path}
            continue

        inject_result = _inject_mcp_config(t, token, use_stdio=use_stdio)
        if inject_result["status"] == "configured":
            transport = str(inject_result.get("transport") or "http").upper()
            inject_result["detail"] = transport
            results[t] = inject_result
        elif inject_result["status"] == "locked":
            inject_result["detail"] = "file locked"
            results[t] = inject_result
        else:
            inject_result["detail"] = "config error"
            results[t] = inject_result

    _record_install_state(
        token_source=token_details["source"],
        target_results=results,
    )

    # Step 5: Summary
    click.echo("")
    click.echo("  Platform        Config                           Status")
    click.echo("  " + "-" * 65)
    for t in targets:
        platform = _PLATFORMS[t]
        name = platform["display_name"].ljust(15)
        config_path = resolve_path(platform["config"])
        path_display = abbreviate_home(config_path).ljust(32)
        status_code = results.get(t, {}).get("status", "skipped")
        detail = results.get(t, {}).get("detail", "not installed")
        if status_code == "configured":
            status = click.style(f"configured ({detail})", fg="green")
        elif status_code in {"skipped", "locked", "absent", "not_installed"}:
            status = click.style(f"skipped ({detail})", fg="white")
        else:
            status = click.style(f"FAILED ({detail})", fg="red")
        click.echo(f"  {name} {path_display} {status}")

    click.echo("")
    configured = [t for t in targets if results.get(t, {}).get("status") == "configured"]
    if configured:
        click.secho("Next steps — reload your host to activate Whispers tools:", fg="yellow", bold=True)
        reload_hints = {
            "claude": "  Claude Code:   Run /mcp in the CLI to reload MCP servers",
            "gemini": "  Gemini CLI:    Restart the Gemini CLI session",
            "codex":  "  Codex CLI:     Restart the Codex CLI session",
            "cursor": "  Cursor:        Cmd/Ctrl+Shift+P → 'MCP: Reload'",
            "vscode": "  VS Code:       Cmd/Ctrl+Shift+P → 'MCP: Reload'",
            "antigravity": "  Antigravity: Cmd/Ctrl+Shift+P → 'MCP: Reload'",
        }
        for t in configured:
            if t in reload_hints:
                click.echo(reload_hints[t])
        click.echo("")
        click.echo("  After reload, look for Whispers tools (message_send, presence_who, etc.).")
        click.echo("  Run 'whispers doctor' to verify everything is connected.")


@cli.command()
@click.option('--target', type=click.Choice(['claude', 'gemini', 'codex', 'cursor', 'vscode', 'antigravity', 'all']),
              default='all', help="Target platform to remove (default: all managed targets)")
@click.option('--yes', is_flag=True, help="Skip confirmation prompts")
@click.option('--remove-credentials/--keep-credentials', default=None,
              help="Remove local MCP token sources as part of uninstall")
@click.option('--remove-db/--keep-db', default=None,
              help="Remove the local Whispers database files")
@click.option('--deregister-managed-agents/--keep-registered', default=None,
              help="Deregister the platform identities tied to the selected targets")
def uninstall(target, yes, remove_credentials, remove_db, deregister_managed_agents):
    """Guided uninstall for managed Whispers host integration."""
    manifest_report = _load_install_state_report()
    manifest_targets = manifest_report["state"].get("targets", {}) if manifest_report["valid"] else {}
    db_path = _expected_db_path()
    db_state = _inspect_db_state(db_path)
    if target == "all" and manifest_targets:
        selected_targets = sorted(manifest_targets.keys())
    else:
        selected_targets = _platform_targets(target)

    click.echo("Uninstall preflight:")
    click.echo(f"  Install manifest: {manifest_report['path']}")
    if not manifest_report["present"]:
        click.echo("  Manifest status: missing (continuing from live inspection)")
    elif not manifest_report["valid"]:
        click.echo(f"  Manifest status: unreadable ({manifest_report['error']})")
    else:
        click.echo(f"  Manifest status: loaded ({len(manifest_targets)} managed target(s))")

    click.echo(f"  Local DB: {db_path}")
    click.echo(f"  DB present: {'yes' if db_state['db_exists'] else 'no'}")

    preflight = {}
    drift_warnings = []
    for name in selected_targets:
        config_path, config = _read_client_config(name)
        entry = _get_whispers_entry_from_config(config, name) if config else None
        manifest_target = manifest_targets.get(name)
        drift = _compare_manifest_target(manifest_target, entry) if manifest_target else []
        preflight[name] = {
            "config_path": config_path,
            "entry_present": entry is not None,
            "manifest_managed": manifest_target is not None,
            "drift": drift,
        }
        state_label = "present" if entry is not None else "absent"
        click.echo(f"  {name}: config {state_label} at {config_path}")
        if drift:
            drift_warnings.append((name, drift))
            click.echo(f"    Drift: {'; '.join(drift)}")

    if drift_warnings and not yes:
        proceed = click.confirm(
            "Some live configs no longer match the install manifest. Remove the Whispers entries anyway?",
            default=False,
        )
        if not proceed:
            click.echo("Aborted.")
            return

    if remove_credentials is None:
        remove_credentials = click.confirm(
            "Also remove local WHISPERS_MCP_TOKEN credentials?",
            default=False,
        ) if not yes else False
    if remove_db is None:
        remove_db = click.confirm(
            "Also remove the local Whispers DB and message history?",
            default=False,
        ) if not yes else False
    if deregister_managed_agents is None:
        deregister_managed_agents = click.confirm(
            "Also deregister the selected platform identities and sweep pending ghost-facing traffic?",
            default=False,
        ) if not yes else False

    if not yes:
        if not click.confirm("Proceed with uninstall?", default=True):
            click.echo("Aborted.")
            return

    removed = []
    preserved = []
    warnings = []
    host_results = {}

    for name in selected_targets:
        result = _remove_mcp_config(name)
        host_results[name] = result
        if result["status"] == "removed":
            removed.append(f"{name} host config")
        elif result["status"] in {"absent", "not_installed"}:
            preserved.append(f"{name} host config already absent")
        elif result["status"] == "locked":
            warnings.append(f"{name} host config locked at {result['config_path']}")
        else:
            warnings.append(f"{name} host config could not be updated")

    deregistration_results = []
    if deregister_managed_agents and db_state["db_exists"] and not db_state["legacy_schema_detected"]:
        for name in selected_targets:
            agent_name = _PLATFORMS[name]["default_agent"]
            result = _deregister_existing_agent(agent_name, db_path)
            deregistration_results.append(result)
            if result["status"] == "deregistered":
                removed.append(f"agent {agent_name} registration")
            else:
                preserved.append(f"agent {agent_name} registration not present")
    elif deregister_managed_agents and db_state["legacy_schema_detected"]:
        warnings.append("Skipped agent deregistration because the local DB schema is legacy or ambiguous.")

    credential_result = None
    if remove_credentials:
        credential_result = _remove_local_credentials()
        if credential_result["process_env_removed"] or credential_result["env_file_updated"] or credential_result["user_env_removed"]:
            removed.append("local MCP token credentials")
        else:
            preserved.append("local MCP token credentials")
        warnings.extend(credential_result["warnings"])
    else:
        preserved.append("local MCP token credentials")

    server_stop_result = None
    if target == "all":
        server_stop_result = _stop_local_server()
        if server_stop_result["stopped"]:
            removed.append("local whispers server process")
        elif server_stop_result["attempted"]:
            warnings.extend(server_stop_result["warnings"])

    db_remove_result = None
    if remove_db:
        if db_state["legacy_schema_detected"] and not yes:
            click.echo("Refusing to remove a legacy or ambiguous DB without explicit repair first.")
            warnings.append("DB removal skipped because the local DB schema is legacy or ambiguous.")
        else:
            db_remove_result = _remove_db_files(db_path)
            if db_remove_result["removed"]:
                removed.append("local Whispers DB files")
            else:
                preserved.append("local Whispers DB files")
            warnings.extend(db_remove_result["errors"])
    else:
        preserved.append("local Whispers DB files")

    manifest_update = _remove_targets_from_install_state(selected_targets)
    if manifest_update["removed_targets"]:
        removed.append("install manifest entries")
    elif manifest_report["present"]:
        preserved.append("install manifest entries")

    click.echo("")
    click.secho("Uninstall summary", fg="green", bold=True)
    click.echo("  Removed:")
    for item in removed or ["nothing"]:
        click.echo(f"    {item}")
    click.echo("  Preserved:")
    for item in preserved or ["nothing"]:
        click.echo(f"    {item}")
    if warnings:
        click.echo("  Warnings:")
        for item in warnings:
            click.echo(f"    {item}")

    restart_targets = [name for name, result in host_results.items() if result["status"] == "removed"]
    if restart_targets:
        click.echo("")
        click.secho(
            f"Restart the affected host(s) so they fully unload Whispers: {', '.join(restart_targets)}",
            fg="yellow",
        )


# ---------------------------------------------------------------------------
# whispers smoke
# ---------------------------------------------------------------------------

@cli.command()
@click.option('--quiet', is_flag=True, help="Machine-readable: print only PASS or FAIL")
def smoke(quiet):
    """Zero-friction smoke test. Verifies the full pipeline works end-to-end.

    Creates two ephemeral agents, sends a message between them, verifies
    delivery and inbox receipt, then reports the result. No server required —
    this tests the local SQLite path that agents actually use.

    Exit code 0 = PASS, 1 = FAIL.
    """
    from .storage.db import WhispersDB, WhispersDBError

    steps_passed = 0
    total_steps = 5
    issues = []

    def _step(n, label):
        if not quiet:
            click.echo(f"  {n}/{total_steps} {label}...", nl=False)

    def _ok(detail=""):
        nonlocal steps_passed
        steps_passed += 1
        if not quiet:
            click.secho(" OK", fg="green", nl=False)
            if detail:
                click.echo(f"  ({detail})")
            else:
                click.echo()

    def _fail(reason):
        issues.append(reason)
        if not quiet:
            click.secho(" FAIL", fg="red")
            click.echo(f"    → {reason}")

    if not quiet:
        click.echo()
        click.secho("  Whispers Smoke Test", bold=True)
        click.echo("  ───────────────────")

    # Step 1: Database access
    _step(1, "Database")
    db_path = _expected_db_path()
    try:
        os.makedirs(os.path.dirname(db_path), exist_ok=True)
        db = WhispersDB(db_path)
        schema_v = db.get_schema_version()
        _ok(f"v{schema_v} at {db_path}")
    except (WhispersDBError, Exception) as e:
        _fail(f"Cannot open database: {e}")
        _print_smoke_result(quiet, steps_passed, total_steps, issues)
        raise SystemExit(1)

    # Step 2: Agent registration
    _step(2, "Agent registration")
    smoke_id = uuid.uuid4().hex[:8]
    sender_name = f"_smoke-tx-{smoke_id}"
    receiver_name = f"_smoke-rx-{smoke_id}"
    try:
        sender = WhispersClient(sender_name, db_path=db_path)
        receiver = WhispersClient(receiver_name, db_path=db_path)
        s_info = sender.whoami()
        r_info = receiver.whoami()
        if s_info and r_info:
            _ok(f"{sender_name} ↔ {receiver_name}")
        else:
            _fail("Agent registration returned None")
            _print_smoke_result(quiet, steps_passed, total_steps, issues)
            raise SystemExit(1)
    except Exception as e:
        _fail(f"Registration failed: {e}")
        _print_smoke_result(quiet, steps_passed, total_steps, issues)
        raise SystemExit(1)

    # Step 3: Message send
    _step(3, "Send message")
    test_subject = f"smoke-test-{smoke_id}"
    try:
        result = sender.send(
            to=receiver_name,
            subject=test_subject,
            body="If you can read this, Whispers works.",
            priority="routine",
            msg_type="inform",
        )
        delivery = result.get("status", "unknown")
        msg_id = result.get("id", "?")
        if delivery in ("delivered", "queued"):
            _ok(f"{delivery}, id={msg_id[:12]}…")
        else:
            _fail(f"Unexpected delivery status: {delivery}")
    except Exception as e:
        _fail(f"Send failed: {e}")
        _print_smoke_result(quiet, steps_passed, total_steps, issues)
        raise SystemExit(1)

    # Step 4: Inbox receipt
    _step(4, "Inbox receipt")
    try:
        messages = receiver.check_inbox(limit=10, mark_seen=False)
        matching = [m for m in messages if m.get("subject") == test_subject]
        if matching:
            _ok(f"{len(matching)} message(s) received")
        else:
            _fail(f"Message not found in inbox ({len(messages)} total messages present)")
    except Exception as e:
        _fail(f"Inbox check failed: {e}")

    # Step 5: System status
    _step(5, "System status")
    try:
        s = sender.status()
        registered = s.get("agents_registered", 0)
        online = s.get("agents_online_count", 0)
        _ok(f"{registered} registered, {online} online")
    except Exception as e:
        _fail(f"Status check failed: {e}")

    # Cleanup: remove smoke test agents completely (best-effort)
    try:
        with db.get_connection() as conn:
            conn.execute(
                "DELETE FROM message_recipients WHERE message_uuid IN "
                "(SELECT uuid FROM messages WHERE subject = ?)",
                (test_subject,),
            )
            conn.execute("DELETE FROM messages WHERE subject = ?", (test_subject,))
            conn.execute("DELETE FROM presence WHERE agent_name IN (?, ?)", (sender_name, receiver_name))
            conn.execute("DELETE FROM agent_runtime_state WHERE agent_name IN (?, ?)", (sender_name, receiver_name))
            conn.execute("DELETE FROM agent_sessions WHERE agent_name IN (?, ?)", (sender_name, receiver_name))
            conn.execute(
                "UPDATE agent_cards SET deregistered_at = CURRENT_TIMESTAMP WHERE callsign IN (?, ?) AND deregistered_at IS NULL",
                (sender_name, receiver_name),
            )
    except Exception:
        pass  # Cleanup is best-effort

    # Result
    _print_smoke_result(quiet, steps_passed, total_steps, issues)
    if issues:
        raise SystemExit(1)


def _print_smoke_result(quiet, passed, total, issues):
    """Print the final smoke test verdict."""
    if quiet:
        click.echo("PASS" if passed == total else "FAIL")
        return

    click.echo()
    if passed == total:
        click.secho("  ✓ PASS", fg="green", bold=True)
        click.echo(f"    All {total} checks passed. Whispers is working.")
        click.echo()
        click.secho("  What's next?", bold=True)
        click.echo("    • whispers status          — see your agent team")
        click.echo("    • whispers doctor           — full diagnostic")
        click.echo("    • whispers mcp-install      — connect to Claude, Codex, etc.")
        click.echo("    • GETTING-STARTED.md        — full guide")
        click.echo()
    else:
        click.secho(f"  ✗ FAIL", fg="red", bold=True)
        click.echo(f"    {passed}/{total} checks passed.")
        click.echo()
        click.secho("  Try:", bold=True)
        click.echo("    • whispers init             — initialize from scratch")
        click.echo("    • whispers doctor --fix      — auto-repair common issues")
        click.echo()


def _peer_owned_branch_owner(branch_name: str) -> str | None:
    normalized = str(branch_name or "").strip().lower()
    if "/" not in normalized:
        return None
    owner = normalized.split("/", 1)[0]
    if owner in {"claude", "claude-code", "antigravity", "gemini"}:
        return owner
    return None


@cli.command("checkpoint")
@click.option("-m", "--message", help="Commit message for the checkpointed slice")
@click.option("--push/--no-push", default=True, help="Push after committing")
@click.option("--backup/--no-backup", default=True, help="Create a local E:\\WhispersBackups snapshot")
@click.option("--reason", default="checkpoint", help="Reason label recorded in the local backup")
@click.option(
    "--include-untracked/--tracked-only",
    default=False,
    help="Include untracked files when auto-staging the checkpoint slice",
)
def checkpoint_cmd(message, push, backup, reason, include_untracked):
    """Commit the current slice, create a local backup, and push the active branch."""

    def _run(args: list[str], *, cwd: str | None = None) -> subprocess.CompletedProcess:
        return subprocess.run(args, cwd=cwd, capture_output=True, text=True, check=False)

    def _require_ok(result: subprocess.CompletedProcess, *, action: str) -> subprocess.CompletedProcess:
        if result.returncode == 0:
            return result
        detail = (result.stderr or result.stdout or "").strip()
        if detail:
            raise click.ClickException(f"{action} failed: {detail}")
        raise click.ClickException(f"{action} failed with exit code {result.returncode}.")

    repo_root_result = _run(["git", "rev-parse", "--show-toplevel"])
    _require_ok(repo_root_result, action="Locate git repository")
    repo_root = repo_root_result.stdout.strip()

    branch_result = _run(["git", "rev-parse", "--abbrev-ref", "HEAD"], cwd=repo_root)
    _require_ok(branch_result, action="Resolve current branch")
    branch_name = branch_result.stdout.strip()

    owner = _peer_owned_branch_owner(branch_name)
    if owner:
        raise click.ClickException(
            f"Refusing to checkpoint on peer-owned branch '{branch_name}'. "
            "Switch to a Codex-owned branch first."
        )

    staged_result = _run(["git", "diff", "--cached", "--name-only"], cwd=repo_root)
    _require_ok(staged_result, action="Inspect staged changes")
    tracked_result = _run(["git", "diff", "--name-only"], cwd=repo_root)
    _require_ok(tracked_result, action="Inspect tracked changes")
    untracked_result = _run(["git", "ls-files", "--others", "--exclude-standard"], cwd=repo_root)
    _require_ok(untracked_result, action="Inspect untracked files")

    staged_paths = [line for line in staged_result.stdout.splitlines() if line.strip()]
    tracked_paths = [line for line in tracked_result.stdout.splitlines() if line.strip()]
    untracked_paths = [line for line in untracked_result.stdout.splitlines() if line.strip()]
    worktree_dirty = bool(staged_paths or tracked_paths or untracked_paths)

    if worktree_dirty and not message:
        raise click.ClickException("Dirty worktree requires -m/--message.")

    if not staged_paths and tracked_paths:
        _require_ok(_run(["git", "add", "-u"], cwd=repo_root), action="Stage tracked changes")
        staged_paths = tracked_paths[:]

    if include_untracked and untracked_paths:
        _require_ok(_run(["git", "add", "-A"], cwd=repo_root), action="Stage untracked changes")
        staged_paths.extend(untracked_paths)

    if worktree_dirty and not staged_paths and untracked_paths and not include_untracked:
        raise click.ClickException(
            "Only untracked files remain. Rerun with --include-untracked or stage the intended files first."
        )

    if staged_paths:
        commit_result = _run(["git", "commit", "-m", message], cwd=repo_root)
        _require_ok(commit_result, action="Commit checkpoint")
    else:
        click.echo("Worktree is clean. Nothing to commit.")

    head_result = _run(["git", "rev-parse", "--short", "HEAD"], cwd=repo_root)
    _require_ok(head_result, action="Resolve checkpoint commit")
    head = head_result.stdout.strip()

    backup_path = None
    if backup:
        backup_script = os.path.abspath(
            os.path.join(os.path.dirname(__file__), "..", "scripts", "create-local-backup.ps1")
        )
        backup_result = _run(
            [
                "C:\\Program Files\\PowerShell\\7\\pwsh.exe",
                "-NoLogo",
                "-NoProfile",
                "-File",
                backup_script,
                "-Reason",
                reason,
            ],
            cwd=repo_root,
        )
        _require_ok(backup_result, action="Create local backup")
        backup_lines = [line.strip() for line in backup_result.stdout.splitlines() if line.strip()]
        if backup_lines:
            backup_path = backup_lines[-1]

    if push:
        upstream_result = _run(
            ["git", "rev-parse", "--abbrev-ref", "--symbolic-full-name", "@{u}"],
            cwd=repo_root,
        )
        if upstream_result.returncode == 0 and upstream_result.stdout.strip():
            push_result = _run(["git", "push"], cwd=repo_root)
        else:
            if not branch_name or branch_name == "HEAD":
                raise click.ClickException("Cannot push from detached HEAD.")
            push_result = _run(["git", "push", "-u", "origin", branch_name], cwd=repo_root)
        _require_ok(push_result, action="Push checkpoint")

    click.secho("Checkpoint Complete", fg="green", bold=True)
    click.echo(f"Head:   {head} ({branch_name})")
    if backup_path:
        click.echo(f"Backup: {backup_path}")
    if untracked_paths and not include_untracked:
        click.echo(
            f"Untracked files left out: {len(untracked_paths)} "
            "(rerun with --include-untracked if they belong to this slice)."
        )


if __name__ == "__main__":
    cli()
