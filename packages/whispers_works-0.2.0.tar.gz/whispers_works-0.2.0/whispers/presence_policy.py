from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from .envelope import Priority

VALID_VISIBILITY_POSTURES = {
    "visible",
    "team_only",
    "direct_only",
    "hidden",
    "appear_offline",
}

VALID_STATE_DETAIL_VISIBILITY = {
    "full",
    "minimal",
    "none",
}

VALID_REACHABILITY = {
    "all",
    "trusted_only",
    "direct_only",
    "priority_only",
    "none",
}

VALID_NOTIFICATION_POLICIES = {
    "all",
    "direct_only",
    "trusted_or_priority",
    "mentions_only",
    "none",
}

VALID_IDLE_POLICY_MODES = {
    "stay_visible",
    "hide_after_timeout",
    "appear_offline_after_timeout",
}

_DEFAULT_IDLE_MODE = "stay_visible"
_DEFAULT_IDLE_TIMEOUT_SECONDS = None

_MINIMAL_DETAIL_FIELDS = {
    "working_on",
    "current_task",
    "interruptibility",
    "context_load",
    "quality_risk",
    "progress_summary",
    "last_progress_at",
    "attention_state",
    "attention_detail",
    "runtime_updated_at",
    "cognitive_state",
    "state_confidence",
    "intent_broadcast",
    "mode_filter",
    "mode_set_at",
}

_NONE_DETAIL_FIELDS = _MINIMAL_DETAIL_FIELDS | {
    "reception_mode",
    "readiness",
    "derived_active_mode",
}

_session_overrides: dict[str, dict[str, Any]] = {}

def set_session_override(agent_name: str, policy: dict[str, Any]) -> None:
    _session_overrides[agent_name] = policy

def get_session_override(agent_name: str) -> dict[str, Any] | None:
    return _session_overrides.get(agent_name)

def clear_session_override(agent_name: str) -> None:
    _session_overrides.pop(agent_name, None)


@dataclass(frozen=True)
class ReachabilityDecision:
    allowed: bool
    policy: str
    reason: str | None = None


def default_presence_policy(*, agent_name: str | None = None, updated_at: str | None = None) -> dict[str, Any]:
    return {
        "agent_name": agent_name,
        "visibility_posture": "visible",
        "state_detail_visibility": "full",
        "reachability": "all",
        "notification_policy": "all",
        "idle_policy": {
            "mode": _DEFAULT_IDLE_MODE,
            "timeout_seconds": _DEFAULT_IDLE_TIMEOUT_SECONDS,
        },
        "updated_at": updated_at,
    }


def normalize_presence_policy(
    policy: dict[str, Any] | None,
    *,
    base: dict[str, Any] | None = None,
    agent_name: str | None = None,
    updated_at: str | None = None,
) -> dict[str, Any]:
    merged = default_presence_policy(agent_name=agent_name, updated_at=updated_at)
    if base:
        merged.update({k: v for k, v in base.items() if k != "idle_policy"})
        base_idle = base.get("idle_policy")
        if isinstance(base_idle, dict):
            merged["idle_policy"].update(base_idle)

    if not policy:
        merged["agent_name"] = agent_name or merged.get("agent_name")
        merged["updated_at"] = updated_at or merged.get("updated_at")
        return merged

    if not isinstance(policy, dict):
        raise ValueError("presence policy must be an object")

    if "visibility_posture" in policy:
        value = str(policy["visibility_posture"]).strip().lower()
        if value not in VALID_VISIBILITY_POSTURES:
            raise ValueError(
                f"Invalid visibility_posture '{policy['visibility_posture']}'. "
                f"Expected one of: {', '.join(sorted(VALID_VISIBILITY_POSTURES))}."
            )
        merged["visibility_posture"] = value

    if "state_detail_visibility" in policy:
        value = str(policy["state_detail_visibility"]).strip().lower()
        if value not in VALID_STATE_DETAIL_VISIBILITY:
            raise ValueError(
                f"Invalid state_detail_visibility '{policy['state_detail_visibility']}'. "
                f"Expected one of: {', '.join(sorted(VALID_STATE_DETAIL_VISIBILITY))}."
            )
        merged["state_detail_visibility"] = value

    if "reachability" in policy:
        value = str(policy["reachability"]).strip().lower()
        if value not in VALID_REACHABILITY:
            raise ValueError(
                f"Invalid reachability '{policy['reachability']}'. "
                f"Expected one of: {', '.join(sorted(VALID_REACHABILITY))}."
            )
        merged["reachability"] = value

    if "notification_policy" in policy:
        value = str(policy["notification_policy"]).strip().lower()
        if value not in VALID_NOTIFICATION_POLICIES:
            raise ValueError(
                f"Invalid notification_policy '{policy['notification_policy']}'. "
                f"Expected one of: {', '.join(sorted(VALID_NOTIFICATION_POLICIES))}."
            )
        merged["notification_policy"] = value

    if "idle_policy" in policy:
        idle_policy = policy["idle_policy"]
        if idle_policy is None:
            idle_policy = {}
        if not isinstance(idle_policy, dict):
            raise ValueError("idle_policy must be an object when present")

        if "mode" in idle_policy:
            value = str(idle_policy["mode"]).strip().lower()
            if value not in VALID_IDLE_POLICY_MODES:
                raise ValueError(
                    f"Invalid idle_policy.mode '{idle_policy['mode']}'. "
                    f"Expected one of: {', '.join(sorted(VALID_IDLE_POLICY_MODES))}."
                )
            merged["idle_policy"]["mode"] = value

        if "timeout_seconds" in idle_policy:
            timeout = idle_policy["timeout_seconds"]
            if timeout in ("", None):
                merged["idle_policy"]["timeout_seconds"] = None
            elif not isinstance(timeout, int) or timeout < 0:
                raise ValueError("idle_policy.timeout_seconds must be a non-negative integer or null")
            else:
                merged["idle_policy"]["timeout_seconds"] = timeout

    merged["agent_name"] = agent_name or merged.get("agent_name")
    merged["updated_at"] = updated_at or merged.get("updated_at")
    return merged


def visibility_effect_for_viewer(
    policy: dict[str, Any],
    *,
    viewer_agent: str | None,
    viewer_tier: int = 1,
    target_agent: str,
) -> str:
    if viewer_agent == target_agent:
        return "show"
        
    if viewer_tier >= 5:
        return "show"

    posture = str(policy.get("visibility_posture") or "visible")
    if posture == "visible":
        return "show"
    if posture == "hidden":
        return "hide"
    if posture == "appear_offline":
        return "offline"
    if posture == "team_only" and viewer_tier >= 3:
        return "show"
        
    # Conservative default until team/direct audience relationships are explicit.
    return "hide"


def apply_presence_policy_to_record(
    record: dict[str, Any],
    policy: dict[str, Any],
    *,
    viewer_agent: str | None,
    viewer_tier: int = 1,
    target_agent: str,
) -> dict[str, Any] | None:
    row = dict(record)
    effect = visibility_effect_for_viewer(policy, viewer_agent=viewer_agent, viewer_tier=viewer_tier, target_agent=target_agent)
    
    idle_policy = policy.get("idle_policy", {})
    idle_mode = idle_policy.get("mode", "stay_visible")
    idle_timeout = idle_policy.get("timeout_seconds")
    
    if effect not in ("hide", "offline") and idle_mode != "stay_visible" and isinstance(idle_timeout, int):
        from whispers.time_utils import parse_timestamp, utc_now

        activity_candidates = []
        for field_name in ("last_active", "heartbeat_at", "runtime_updated_at", "session_last_seen"):
            raw_value = row.get(field_name)
            if not raw_value:
                continue
            parsed_value = parse_timestamp(raw_value)
            if parsed_value:
                activity_candidates.append(parsed_value)

        if activity_candidates:
            latest_activity = max(activity_candidates)
            delta_seconds = (utc_now() - latest_activity).total_seconds()
            if delta_seconds > idle_timeout:
                if idle_mode == "appear_offline_after_timeout":
                    effect = "offline"
                elif idle_mode == "hide_after_timeout":
                    effect = "hide"

    if effect == "hide":
        return None

    if effect == "offline":
        row["status"] = "offline"
        row["presence_status"] = "offline"
        row["is_online"] = 0
        row["active_session_count"] = 0
        row["derived_active_mode"] = "offline"
        row["presence_kind"] = "offline"
        for field_name in ("last_active", "heartbeat_at", "session_last_seen", "runtime_updated_at"):
            row.pop(field_name, None)

    if viewer_agent != target_agent:
        detail_level = str(policy.get("state_detail_visibility") or "full")
        if detail_level in {"minimal", "none"}:
            for field_name in _MINIMAL_DETAIL_FIELDS:
                row.pop(field_name, None)
        if detail_level == "none":
            for field_name in _NONE_DETAIL_FIELDS:
                row.pop(field_name, None)

    return row


def evaluate_reachability(
    policy: dict[str, Any],
    *,
    priority: Priority | str,
    is_direct: bool,
    sender_tier: int,
    recipient_tier: int,
    sender_agent: str | None = None,
    target_agent: str | None = None,
) -> ReachabilityDecision:
    route = str(policy.get("reachability") or "all")
    msg_priority = Priority(priority) if isinstance(priority, str) else priority

    if sender_agent and target_agent and sender_agent == target_agent:
        return ReachabilityDecision(True, route)

    # System traffic keeps the existing emergency/system path until operator
    # override semantics are made more explicit.
    if msg_priority == Priority.SYSTEM:
        return ReachabilityDecision(True, route)


    if route == "all":
        return ReachabilityDecision(True, route)

    if route == "trusted_only":
        if sender_tier > 0 and sender_tier >= max(1, recipient_tier):
            return ReachabilityDecision(True, route)
        return ReachabilityDecision(False, route, reason="sender_not_trusted")

    if route == "direct_only":
        if is_direct:
            return ReachabilityDecision(True, route)
        return ReachabilityDecision(False, route, reason="message_not_direct")

    if route == "priority_only":
        if msg_priority in {Priority.PRIORITY, Priority.FLASH, Priority.SYSTEM}:
            return ReachabilityDecision(True, route)
        return ReachabilityDecision(False, route, reason="priority_too_low")

    if route == "none":
        return ReachabilityDecision(False, route, reason="recipient_not_reachable")

    return ReachabilityDecision(True, route)
