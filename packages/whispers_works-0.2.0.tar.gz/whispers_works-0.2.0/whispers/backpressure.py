"""Backpressure signaling — capacity-aware routing.

Agents advertise their capacity (how much more work they can absorb)
as part of cognitive heartbeat. The system uses this to make routing
decisions: prefer agents with capacity, avoid overloaded ones.

Capacity is a simple 0.0-1.0 float:
- 1.0 = fully available, no active work
- 0.5 = half loaded
- 0.1 = nearly saturated
- 0.0 = at capacity, should not receive new work

Derived from: context_load (inverse), active baton count, readiness state.
"""
from __future__ import annotations

import logging
from typing import Any, Optional

logger = logging.getLogger("whispers")


def compute_capacity(
    *,
    context_load: float | None = None,
    readiness: str = "ready",
    active_baton_count: int = 0,
    quality_risk: str | None = None,
) -> float:
    """Compute an agent's current capacity score (0.0-1.0).

    Higher = more capacity for new work.
    """
    if readiness in ("blocked", "paused_by_operator", "degraded"):
        return 0.0

    if quality_risk == "high":
        return 0.0

    # Start with context-based capacity (inverse of load)
    base = 1.0 - (context_load if isinstance(context_load, (int, float)) else 0.0)
    base = max(0.0, min(1.0, base))

    # Reduce for active batons (each baton reduces capacity by 0.15)
    baton_penalty = min(active_baton_count * 0.15, 0.6)
    base = max(0.0, base - baton_penalty)

    # Reduce for busy readiness
    if readiness == "busy":
        base *= 0.5
    elif readiness == "warming":
        base *= 0.3

    return round(base, 2)


def get_agent_capacity(db: Any, agent_name: str) -> dict[str, Any]:
    """Get an agent's current capacity with breakdown."""
    try:
        runtime = db.get_runtime_state(agent_name)
    except Exception:
        return {"agent": agent_name, "capacity": 0.5, "source": "default"}

    context_load = runtime.get("context_load")
    readiness = runtime.get("readiness", "ready")
    quality_risk = runtime.get("quality_risk")

    # Count active batons
    active_batons = 0
    try:
        with db.get_readonly_connection() as conn:
            row = conn.execute(
                "SELECT COUNT(*) as c FROM baton_projections WHERE assignee_callsign = ? AND state IN ('accepted', 'in_progress', 'blocked', 'review_pending')",
                (agent_name,),
            ).fetchone()
            active_batons = row["c"] if row else 0
    except Exception:
        pass

    capacity = compute_capacity(
        context_load=context_load,
        readiness=readiness,
        active_baton_count=active_batons,
        quality_risk=quality_risk,
    )

    return {
        "agent": agent_name,
        "capacity": capacity,
        "context_load": context_load,
        "readiness": readiness,
        "active_batons": active_batons,
        "quality_risk": quality_risk,
    }


def rank_agents_by_capacity(db: Any, agent_names: list[str]) -> list[dict[str, Any]]:
    """Rank agents by available capacity, best first."""
    results = [get_agent_capacity(db, name) for name in agent_names]
    results.sort(key=lambda x: x["capacity"], reverse=True)
    return results
