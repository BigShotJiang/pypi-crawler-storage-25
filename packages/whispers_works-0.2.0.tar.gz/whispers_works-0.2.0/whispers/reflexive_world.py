"""World state builder for the Reflexive Coordination Engine.

Queries DB and runtime state to produce the world dict consumed by reflexes.
This keeps DB access out of reflex logic — reflexes are pure functions
over plain dicts, testable without a database.
"""

import logging
import time
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)

# Terminal baton states — these are done, don't include in active batons
_TERMINAL_STATES = {"completed", "merged", "blocked", "superseded", "expired", "rejected"}


def build_world_state(db, repo_coordinator=None) -> Dict[str, Any]:
    """Build the world state dict from current DB and runtime state.

    Returns:
        {
            "active_batons": [
                {
                    "baton_ref": str,
                    "owner": str,
                    "assignee": str,
                    "state": str,
                    "subject": str,
                    "version": int,
                    "created_epoch": float,
                    "updated_epoch": float,
                    "assignee_online": bool,
                },
                ...
            ],
            "agents": [
                {
                    "callsign": str,
                    "online": bool,
                    "readiness": str,
                    "attention_state": str | None,
                },
                ...
            ],
            "path_overlaps": [...],
            "built_at": float,
        }
    """
    world = {
        "active_batons": [],
        "agents": [],
        "path_overlaps": [],
        "built_at": time.time(),
    }

    try:
        world["active_batons"] = _query_active_batons(db)
    except Exception:
        logger.warning("Failed to query active batons for world state", exc_info=True)

    try:
        world["agents"] = _query_agents(db)
    except Exception:
        logger.warning("Failed to query agents for world state", exc_info=True)

    # Enrich batons with assignee online status
    online_agents = {a["callsign"] for a in world["agents"] if a.get("online")}
    for baton in world["active_batons"]:
        baton["assignee_online"] = baton.get("assignee", "") in online_agents

    try:
        lanes = _query_repo_lanes(db, repo_coordinator=repo_coordinator)
        world["path_overlaps"] = _compute_path_overlaps(lanes)
    except Exception:
        logger.warning("Failed to check path overlaps", exc_info=True)

    return world


def _query_active_batons(db) -> List[Dict[str, Any]]:
    """Query non-terminal baton projections with version and subject."""
    if hasattr(db, "get_reflexive_active_batons"):
        rows = db.get_reflexive_active_batons()
    else:
        terminal_placeholders = ",".join(f"'{s}'" for s in _TERMINAL_STATES)
        with db.get_connection() as conn:
            rows = conn.execute(f"""
                SELECT
                    bp.baton_ref,
                    bp.owner_callsign AS owner,
                    bp.assignee_callsign AS assignee,
                    bp.state,
                    bp.priority,
                    bp.created_at,
                    bp.updated_at,
                    bp.version,
                    bp.delineation_text,
                    m.subject
                FROM baton_projections bp
                LEFT JOIN messages m ON m.uuid = bp.baton_ref
                WHERE bp.state NOT IN ({terminal_placeholders})
                ORDER BY bp.created_at ASC
            """).fetchall()

    batons = []
    for row in rows:
        batons.append({
            "baton_ref": row["baton_ref"],
            "owner": row["owner"],
            "assignee": row["assignee"],
            "state": row["state"],
            "subject": row["subject"] or row["delineation_text"] or "handoff",
            "version": row["version"] if "version" in row.keys() else 1,
            "created_epoch": _sqlite_epoch(row["created_at"]),
            "updated_epoch": _sqlite_epoch(row["updated_at"]),
            "priority": row["priority"],
        })
    return batons


def _query_agents(db) -> List[Dict[str, Any]]:
    """Query all registered agents with presence, runtime state, heartbeat, and queue depth."""
    with db.get_connection() as conn:
        rows = conn.execute("""
            SELECT
                ac.callsign,
                p.status,
                COALESCE(ars.readiness, 'unknown') AS readiness,
                ars.attention_state,
                p.last_active
            FROM agent_cards ac
            LEFT JOIN presence p ON p.agent_name = ac.callsign
            LEFT JOIN agent_runtime_state ars ON ars.agent_name = ac.callsign
            WHERE ac.deregistered_at IS NULL
        """).fetchall()

        # Count actionable queue items per agent (for predictive escalation)
        actionable_counts: Dict[str, int] = {}
        try:
            count_rows = conn.execute("""
                SELECT r.recipient_callsign, COUNT(*) as cnt
                FROM messages m
                JOIN message_recipients r ON m.uuid = r.message_uuid
                WHERE m.status = 'new'
                  AND r.delivery_status IN ('queued', 'unclaimed', 'delivered')
                  AND r.read_at IS NULL
                  AND r.archived_at IS NULL
                  AND (r.snoozed_until IS NULL OR r.snoozed_until <= CURRENT_TIMESTAMP)
                  AND COALESCE(m.queue_class, 'conversation') = 'actionable'
                GROUP BY r.recipient_callsign
            """).fetchall()
            actionable_counts = {row[0]: row[1] for row in count_rows}
        except Exception:
            pass

    agents = []
    for row in rows:
        last_active_epoch = 0
        if row["last_active"]:
            try:
                last_active_epoch = _sqlite_epoch(row["last_active"])
            except Exception:
                pass
        agents.append({
            "agent_name": row["callsign"],
            "callsign": row["callsign"],
            "online": row["status"] == "online",
            "readiness": row["readiness"],
            "attention_state": row["attention_state"],
            "last_heartbeat_epoch": last_active_epoch,
            "actionable_count": actionable_counts.get(row["callsign"], 0),
        })
    return agents


def _query_repo_lanes(db, repo_coordinator=None) -> List[Any]:
    """Prefer DB-backed repo-lane truth, fall back to the process-local coordinator."""
    if hasattr(db, "list_repo_lanes"):
        try:
            return db.list_repo_lanes()
        except Exception:
            logger.warning("Failed to query DB-backed repo lanes for world state", exc_info=True)

    if repo_coordinator:
        return repo_coordinator.get_lanes()

    return []


def _compute_path_overlaps(lanes: List[Any]) -> List[Dict[str, Any]]:
    """Return overlap entries using the same exact-match and prefix rules as repo coordination."""
    overlaps: List[Dict[str, Any]] = []
    for i, lane_a in enumerate(lanes):
        if not getattr(lane_a, "claimed_paths", None):
            continue
        paths_a = _normalize_paths(lane_a.claimed_paths)
        for lane_b in lanes[i + 1:]:
            if not getattr(lane_b, "claimed_paths", None):
                continue
            paths_b = _normalize_paths(lane_b.claimed_paths)
            direct = paths_a & paths_b
            prefix = set()
            for path_a in paths_a:
                for path_b in paths_b:
                    if path_a.startswith(path_b + "/") or path_b.startswith(path_a + "/"):
                        prefix.add(min(path_a, path_b, key=len))
            overlapping = sorted(direct | prefix)
            if overlapping:
                overlaps.append(
                    {
                        "agent_a": lane_a.agent_name,
                        "agent_b": lane_b.agent_name,
                        "overlapping_paths": overlapping,
                    }
                )
    return overlaps


def _normalize_paths(paths: List[str]) -> set[str]:
    return {path.replace("\\", "/").rstrip("/") for path in paths}


def _sqlite_epoch(ts: Optional[str]) -> float:
    """Parse a SQLite timestamp string to epoch seconds."""
    if not ts:
        return 0.0
    for fmt in (
        "%Y-%m-%d %H:%M:%S",
        "%Y-%m-%dT%H:%M:%S",
        "%Y-%m-%dT%H:%M:%S.%f",
        "%Y-%m-%dT%H:%M:%S%z",
        "%Y-%m-%dT%H:%M:%S.%f%z",
    ):
        try:
            dt = datetime.strptime(ts, fmt)
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)
            return dt.timestamp()
        except ValueError:
            continue
    return 0.0
