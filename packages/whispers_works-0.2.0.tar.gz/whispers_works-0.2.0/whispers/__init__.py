"""
Whispers - A cognitive routing protocol for agent-to-agent communication.

Two deployment modes:
  - **Embedded**: Import WhispersClient directly into your process.
  - **Standalone**: Run ``whispers-server`` and hit the HTTP/SSE API.

Quick start::

    from whispers import WhispersClient

    client = WhispersClient("my-agent")
    client.send("other-agent", "Hello from Whispers")

    # System status (works in both modes)
    status = client.status()
"""

__version__ = "0.2.0"

SCHEMA_VERSION = 2


def skill_file_path() -> str:
    """Return the absolute path to the bundled WHISPERS-SKILL.md."""
    from pathlib import Path
    return str(Path(__file__).parent / "WHISPERS-SKILL.md")

from .envelope import Envelope, Priority, MsgType
from .identity import normalize_callsign_part, suggest_callsign, suggest_display_name, validate_remote_callsign
from .client import WhispersClient, MockWhispersClient
from .testing import WhispersTestClient, WhispersTestHarness
from .twoack import (
    A2ABinding,
    ConformanceObservation,
    PreflightSurface,
    ValidationIssue,
    ValidationResult,
    build_a2a_message,
    derive_text_fallback,
    evaluate_conformance_level,
    extract_a2a_binding,
    extract_preflight,
    round_trip,
    validate_envelope,
    validate_message,
    validate_schema,
)

__all__ = [
    "Envelope",
    "Priority",
    "MsgType",
    "WhispersClient",
    "MockWhispersClient",
    "WhispersTestClient",
    "WhispersTestHarness",
    "A2ABinding",
    "ConformanceObservation",
    "PreflightSurface",
    "ValidationIssue",
    "ValidationResult",
    "build_a2a_message",
    "derive_text_fallback",
    "evaluate_conformance_level",
    "extract_a2a_binding",
    "validate_envelope",
    "validate_schema",
    "validate_message",
    "extract_preflight",
    "round_trip",
    "normalize_callsign_part",
    "suggest_callsign",
    "suggest_display_name",
    "validate_remote_callsign",
]
