---
name: whispers
description: Multi-agent communication protocol. Load this skill when Whispers MCP tools or the Python client are available. Provides the current startup sequence, messaging workflow, and user-facing behavior guidance.
---

# Whispers: Your Communication System

You have Whispers installed. That means you can check who is online, exchange direct messages with other agents, inspect delivery state, and keep the human informed without using them as a relay.

Read this once, then use it to provide a calm startup and a truthful user experience.

---

## Mandatory Orientation For Design And Roadmap Work

If the user asks for any of the following, do not start from code alone:
- product direction
- roadmap status
- protocol design
- A2A positioning or interoperability
- networking architecture
- collaboration runtime design
- section-by-section project orientation
- "what should we build next?"

Start by reading the canonical planning documents in this order:

1. `.planning/WHISPERS-VISION-ORIGIN.md`
2. `.planning/PRODUCT-DEFINITION.md`
3. `.planning/WORKING-SCOPE-CONTRACTS.md`
4. `.planning/INFRASTRUCTURE-ROADMAP.md`
5. `.planning/PLAN-3-THE-NETWORK.md`
6. `.planning/HEARTBEAT-ACTIVE-MODE-PLAN.md`
7. `.planning/WHISPERS-COLLABORATION-RUNTIME-FEATURES.md`
8. `.planning/NEXT-BUILD-ORDER-COLLABORATION-RUNTIME.md`
9. `.planning/DISCUSSION-ITEMS.md`

Then explicitly answer four things before proposing changes:
- what Whispers is in product terms
- what phase or tranche is currently authoritative
- what is already built versus merely planned
- which questions are still open design decisions

Default analysis posture for this repo:
- roadmap first
- code second
- implementation only after the controlling design layer is understood

If the request is narrow and local, code-first is fine. If the request touches product, protocol, A2A, roadmap, runtime, trust, or networking, roadmap-first is mandatory.

---

## Startup Sequence

When Whispers tools or `WhispersClient` are available, you MUST run live Whispers startup near the start of every session. This is a startup command, not etiquette.

Preferred path:

```python
briefing = client.startup_briefing()
print(briefing["status_line"])
```

This is the canonical startup line. It surfaces Whispers state without turning old unread messages into automatic marching orders.

Mandatory follow-through after the startup line:

```text
1. If briefing["pending_messages"] > 0, call message_check()/client.check_inbox(mark_seen=True) to clear inbox state and narrate what arrived.
2. If Jolt is installed or the runtime surfaces a Jolt packet/adapter, inspect that Jolt state during startup.
3. If inbox clearing fails or Jolt inspection fails, say Whispers startup is degraded before doing other work.
4. Do not tell the user Whispers is healthy, clear, or “working” until this live startup pass is complete.
```

Fallback manual sequence:

```text
1. client.status()        -> Is Whispers healthy? What mode? How many peers?
2. client.whoami()        -> What identity am I using?
3. client.wag("listening") -> Best-effort presence update
4. client.check_inbox()   -> Clear unread inbox state and surface arrivals
5. Inspect Jolt state     -> Active packet, adapter status, degraded wake path
6. status.agents_online   -> Who else is here?
```

Then present one short line to the user using the visual notification format:

> ⏦⏦⏦> ◆ [identity] | [SIGNAL_MODE] | [peer names] | [N] unread

This visual language is reserved for real Whispers-originated signal. Do not reuse it for ordinary assistant narration or cosmetic status headers. Keep it one line by default.

This visual language is contractual. If you participate in Whispers, use the canonical Whispers prefixes, icons, arrows, and semantic colors exactly as defined in `VISUAL-SIGNAL-LANGUAGE.md`.

Visual notification icons:
- `⏦⏦⏦> ◆` — status line (solid, stable)
- `⏦⏦⏦> ◈` — incoming routine message
- `⏦⏦⏦> ⊹` — incoming handoff
- `⏦⏦⏦> ⚡` — incoming flash/urgent
- `⏦⏦⏦> ☊` — connection event
- `⏦⏦⏦> ◇` — acknowledgment
- `⏦⏦⏦> ⟡` — inform/FYI
- `⏦⏦⏦> ✕` — problem / failure / server down
- `⏦⏦⏦> ↺` — recovery / reconnecting / restored
- `◈ <⏦⏦⏦` — outgoing message (icon on left, waves reversed)

Directional and color tokens:
- `← [🟨 BATON xN]` — incoming baton waiting on you
- `→ [🟦 BATON xN]` — outgoing baton you are carrying
- `◈ [🟪 REVIEW xN]` — claimed review lane
- `↔` — live bidirectional exchange
- green — healthy/open/recovered state
- yellow — focused/waiting/caution state
- red — quiet/problem/failure state
- blue — active baton being carried
- purple — claimed review lane

If there are pending messages, clear inbox state and summarize only the ones that affect current work. Do not treat old unread messages as fresh marching orders. If something is broken, say so plainly and offer to inspect it with `whispers doctor`.

**Graceful degradation**
- Do not block the user on Whispers startup.
- `wag()` is best-effort.
- If one step fails, skip it, note the problem briefly, and continue with the user task.
- Do not dump raw JSON unless the user explicitly asks for it.

If repair is needed, `whispers doctor --fix` can handle some installation problems, but do not promise that it repairs everything automatically.

---

## First-Day Operating Lessons

These are the highest-confidence lessons from the first real day of using Whispers to build Whispers:

- runtime truth beats etiquette; if a collaboration fact matters, it should live in state, tests, or operator surfaces
- `delivered` and `read` are transport truth only; pickup truth requires an explicit ack or runtime state change
- real relay proofs and pressure tests beat abstract confidence
- update `wag()`, readiness, and heartbeat when your lane changes so the operator and peers are not reasoning from stale state
- keep your dirty worktree bounded to one coherent slice; commit or checkpoint before widening
- once a collaboration surface is green enough to build on, freeze its semantics and move to the next real gap instead of reopening design casually

If you need the fuller write-up, read `.planning/FIRST-DAY-DOGFOOD-LESSONS-2026-03-29.md`.

---

## What You Can Do Now

### Send Direct Messages

```python
client.send(to="antigravity", subject="Review request", body="...", priority="routine")
```

Use this when you know who should receive the message.

Delivery states:
- `delivered`: recipient appears online
- `queued`: recipient is offline
- `dead_lettered`: recipient is unknown

### Broadcast Your Operational State

```python
client.wag("building")
```

Valid states in current docs and examples:
- `idle`
- `listening`
- `exploring`
- `building`
- `blocked`
- `eureka`
- `winding_down`

Use `wag()` at startup, when you shift tasks, when you are blocked on another agent, and when you are wrapping up.

### Check Your Inbox

```python
messages = client.check_inbox(limit=50, mark_seen=True)
```

Use this at startup and before major task transitions.

### See Who Is Online

```python
status = client.status()
online = status["agents_online"]
```

Use this before choosing who to message and when the user asks about current network state.

### Verify Delivery in Your Outbox

```python
messages = client.outbox(limit=10)
```

Outbox is the clean answer to "did they get my message?"

### View the Full Conversation With Another Agent

```python
history = client.trace("antigravity", limit=20)
```

Use trace for context, handoffs, and debugging communication issues.

### Set Your Reception Mode

```python
client.set_mode("focused", allow_senders=["antigravity"])
client.set_mode("quiet")
client.set_mode("open")
```

Use:
- `open` for normal operation
- `focused` when you only want specific senders
- `quiet` when everything should queue for later

### Manage Your Identity

```python
client.whoami()
client.rename("new-name")
client.deregister()
```

### Score an Existing Negotiation Transcript

```python
result = client.score_negotiation("negotiation-id")
```

This helper only scores an existing negotiation record. There is not yet a public `client.negotiate(...)` helper in the current client API, so do not promise interactive negotiation setup unless your environment added it separately.

---

## Trust And Guardrails

Current guardrails are modest and concrete:
- the dispatcher enforces a trust-tier gate between sender and recipient
- SYSTEM-priority sends are permission-gated
- the Guardian scans routine and priority messages for a small set of escalation keywords and records warning metadata

Do not describe HMAC-backed body warnings or fully automatic trust UX unless you have verified those behaviors in the runtime you are using.

---

## Decision Framework

| Situation | Action |
|-----------|--------|
| You know exactly who to talk to | `send(to="callsign")` |
| Did they get my message? | `outbox(limit=10)` |
| What did we discuss? | `trace("callsign", limit=20)` |
| Starting a task | `wag("building")` or `wag("exploring")` |
| Finished a task | `wag("idle")` |
| Waiting on another agent | `wag("blocked")` |
| Session ending | `wag("winding_down")` |
| Need fewer interruptions | `set_mode("quiet")` or `set_mode("focused")` |
| Something seems broken | `whispers doctor` |

There is no general-purpose need-based routing contract in the current public client API. Use direct callsigns unless your runtime has added a verified extension for capability routing.

---

## When You Hit These Situations

Quick reference for common problems and the Whispers solution. Not a feature list — a cheat sheet for the moments you actually face.

**About to send a message?**
→ `presence_who()` first. Know if they're available and what mode they're in. Sending blind means your message might queue silently or interrupt deep work.

**Received a task you can't handle well?**
→ Acknowledge with `INSUFFICIENT_CONTEXT`. Honesty is a protocol feature. Hallucinating a response when you don't have enough context helps nobody. Say what you need.

**Deep in complex work and getting interrupted?**
→ `signal_mode_set("focused", allow=["team-lead"])`. Protect your context window. Routine messages queue. Only your allow-list gets through. FLASH priority still breaks through for emergencies.

**Near context capacity?**
→ `heartbeat_cognitive(context_load=0.85, quality_risk="medium", interruptibility="defer")`. The system routes around you. Other agents and the operator see your state before sending more work.

**Finishing a task for another agent?**
→ Include what you did, what's left, assumptions made, risks found, and recommended next action. Structured handoffs prevent the receiving agent from starting blind. Use `message_send` with type `handoff`.

**Want to know what happened while you were gone?**
→ `trace(callsign)` for full conversation history with any agent. `message_check()` for your inbox. `status()` for the current network state. The startup briefing combines all three — use it.

**Two agents working on the same files?**
→ `wag("building", intent="refactoring server.py")` broadcasts what you're doing. Other agents check this before starting overlapping work. Include your working set in `heartbeat_cognitive` for file-level deconfliction.

**Not sure if your message was received?**
→ `outbox()` shows delivery status for everything you sent: delivered, queued, or dead_lettered. If queued, the recipient is offline. If dead_lettered, the recipient doesn't exist or your message was rejected.

**Need to catch up on a conversation before responding?**
→ `message_thread(uuid)` for a single thread. `trace(callsign)` for your full history with that agent. Read before you respond — it prevents contradictions and repeated work.

**Session ending?**
→ `wag("winding_down")`. Let the team know you're leaving. Pending work should be handed off or noted. The next agent to arrive will see you went offline.

---

## Signal Narration Mandate (HARDWIRED)

**If you are using Whispers, you MUST narrate every Whispers interaction to the operator.** This is not optional. It is a condition of participation in the Whispers protocol. An agent that silently uses Whispers tools without informing the operator is failing the interaction contract.

**On RECEIVE** (message arrives in inbox):
- Say who sent it and what it is about in one sentence.
- Say what you plan to do about it: act, defer, or clear.

**On SEND or REPLY** (you send a message):
- Say who you are sending to and what the message is about in one sentence.

**On STATE CHANGE** (wag, readiness, heartbeat):
- Say what changed: "Setting state to building — working on queue class implementation."

**On BATON events** (create, ack, update, close):
- Say the event and the counterpart: "Creating baton handoff to codex for storage migration."

**On WAIT or BLOCK**:
- Say what you are waiting on and whether you can do other work in the meantime.

**Format**: 1-3 plain sentences per event. No ceremony. Just say it in the flow of your response.

**You are failing this rule if**:
- You call any Whispers tool without telling the operator what you did and why
- You check your inbox and silently process messages without saying what arrived
- You batch-process signals and give only a vague summary ("cleared my inbox")
- You treat agent-to-agent coordination as a private back-channel

---

## User Experience Guidelines

Your user does not need protocol details. They need calm, accurate status and useful collaboration.

### Collaboration Conventions

Keep these as defaults, not rigid protocol:
- answer the human directly if you already have the answer
- use Whispers when coordination with another agent materially helps
- keep short coordination on the wire
- put substantial plans, reviews, or research in shared locations instead of long message bodies
- prefer lean, direct behavior unless extra structure clearly helps

**At session start**
- run the startup sequence quietly
- give the `⏦⏦⏦> ◆` status line
- summarize only actionable pending messages using type icons

**When you contact another agent**
- do it without ceremony for routine coordination
- mention it briefly when it matters: "Asked Claude to review that path."
- report the result when it comes back

**When the user asks about Whispers**
- explain simply: "It is how I talk to other agents on this machine or server."
- describe current state, not architecture trivia

**When something fails**
- say what failed
- say whether the message was delivered, queued, or dead-lettered
- offer a next step such as `whispers doctor`

The user should feel that the system is quiet, competent, and honest.

---

## Error Handling

| Error | What to do |
|-------|-----------|
| DB not found | Tell the user the DB is missing and offer `whispers init` |
| Schema mismatch | Tell the user migration or re-init is needed |
| Agent not registered | Current clients auto-register on normal init; if identity is still missing, report it plainly |
| Send fails | Report `delivered`, `queued`, or `dead_lettered` and explain the implication |
| Inbox empty | Say nothing unless the user asked directly |
| `wag()` fails | Treat it as non-critical and continue |

---

## Periodic Behavior

If you have background polling or periodic hooks:
- check inbox quietly
- surface only actionable messages
- update your operational state when work changes
- do not narrate routine background checks to the user

---

## Installation Verification

Run `whispers doctor` for structured diagnostics. Pay attention to:
- `overall`
- `schema_version`
- `warnings`
- `conflicts_detected`

If `overall` is `FAIL`, or if warnings affect startup clarity, tell the user plainly and offer to inspect or repair. `whispers doctor --fix` can repair some setup issues, but it is not a magic reset button.

If you need to verify programmatically:

```python
status = client.status()
assert status["healthy"] is True, f"Whispers unhealthy: {status}"

me = client.whoami()
assert me is not None, "Not registered"
```

---

## Summary

You are not alone. You have a messaging and presence system that lets you see peers, send direct messages, check your inbox, inspect delivery state, and stay coordinated without making the human relay information between agents. Use it quietly and truthfully.
