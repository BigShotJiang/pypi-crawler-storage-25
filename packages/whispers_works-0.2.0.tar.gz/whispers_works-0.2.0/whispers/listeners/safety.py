import time
import logging
from typing import Dict, Any, List

logger = logging.getLogger(__name__)

class LoopDetected(Exception):
    """Raised when an autonomous agent enters an infinite loop with a peer."""
    pass

class RateLimitExceeded(Exception):
    """Raised when the agent exceeds autonomous response budgets."""
    pass

class SafetyGuardrails:
    """
    Enforces architectural boundaries outside the LLM context.
    Prevents prompt-amnesia from allowing an autonomous agent to burst
    thousands of messages or enter ping-pong loops with another bot.
    """

    def __init__(
        self,
        max_responses_per_hour: int = 20,
        max_responses_per_minute: int = 3,
        loop_detection_window: int = 10,
        loop_detection_threshold: int = 5,
        action_scope: str = "respond-only"
    ):
        self.max_responses_per_hour = max_responses_per_hour
        self.max_responses_per_minute = max_responses_per_minute
        self.loop_detection_window = loop_detection_window
        self.loop_detection_threshold = loop_detection_threshold
        self.action_scope = action_scope

        self._response_timestamps: List[float] = []
        self._recent_interactions: List[Dict[str, Any]] = []

    def log_interaction(self, sender: str, recipient: str, msg_type: str) -> None:
        """
        Record a sent autonomous message to enable loop detection.
        Called AFTER a successful response.
        """
        now = time.time()
        self._response_timestamps.append(now)
        self._recent_interactions.append({
            "ts": now,
            "sender": sender,
            "recipient": recipient,
            "type": msg_type
        })
        
        # Cleanup old interactions (keep trailing window + 10 for safety)
        if len(self._recent_interactions) > self.loop_detection_window * 2:
            self._recent_interactions = self._recent_interactions[-self.loop_detection_window * 2:]

    def verify(self, incoming_message: Dict[str, Any]) -> None:
        """
        Asserts that the system is safe to respond to the incoming message.
        Raises RateLimitExceeded or LoopDetected if unsafe.
        """
        now = time.time()

        # 1. Clean up old timestamps (sliding windows)
        one_hour_ago = now - 3600
        one_min_ago = now - 60

        self._response_timestamps = [ts for ts in self._response_timestamps if ts > one_hour_ago]

        # 2. Assert Hourly Limit
        if len(self._response_timestamps) >= self.max_responses_per_hour:
            logger.warning(f"Safety constraint triggered: exceeded {self.max_responses_per_hour}/hour limit.")
            raise RateLimitExceeded("Autonomous responder hourly budget exceeded. Dropping message.")

        # 3. Assert Minute Limit
        recent_minute = [ts for ts in self._response_timestamps if ts > one_min_ago]
        if len(recent_minute) >= self.max_responses_per_minute:
            logger.warning(f"Safety constraint burst triggered: {self.max_responses_per_minute}/minute limit.")
            raise RateLimitExceeded("Autonomous responder per-minute burst limit exceeded. Dropping message.")

        # 4. Loop Detection Check
        # Have we replied to this exact same sender 5+ times in our recent trailing window?
        sender = incoming_message.get("from_agent") or incoming_message.get("sender")
        if sender:
            # We look at messages we SENT to this `sender`
            responses_to_sender = [
                i for i in self._recent_interactions[-self.loop_detection_window:]
                if i["recipient"] == sender
            ]
            if len(responses_to_sender) >= self.loop_detection_threshold:
                logger.error(f"Safety loop detection triggered: Ping-ponging with {sender}.")
                raise LoopDetected(f"Infinite loop detected with peer {sender}. Aborting autonomous response.")
