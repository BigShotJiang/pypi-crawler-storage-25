import threading
import logging
import json
from typing import Optional, Callable, Dict, Any, List

from whispers.client import WhispersClient
from .safety import SafetyGuardrails, RateLimitExceeded, LoopDetected

logger = logging.getLogger(__name__)


class WakePolicy:
    """Base policy to filter inbound traffic before waking handlers."""
    def evaluate(self, message: Dict[str, Any]) -> bool:
        """Return True if the message should break the listener's idle state and trigger the handler."""
        return True


class ListenerEngine:
    """
    A pure transport/filter/dispatch primitive for pulling the Whispers SSE stream.
    
    This engine strictly wraps the canonical `client.listen()` generator. It does NOT invent
    an alternate consumer path, preserving all standard reconnect, backoff, and delivery semantics.
    It enforces pre-policy kill switches and robust architectural safety guardrails.
    """
    
    def __init__(
        self,
        server_url: Optional[str],
        agent_name: str,
        token: Optional[str],
        handler: Callable[[Dict[str, Any]], None],
        wake_policy: Optional[WakePolicy] = None,
        safety_guardrails: Optional[SafetyGuardrails] = None,
        db_path: Optional[str] = None,
    ):
        self.agent_name = agent_name
        self.handler = handler
        self.wake_policy = wake_policy or WakePolicy()
        self.safety = safety_guardrails
        
        # Instantiate a discrete, purpose-built client strictly for pulling the stream.
        # It handles its own lease/connection under the hood.
        self.client = WhispersClient(
            server=server_url,
            agent_name=agent_name,
            token=token,
            db_path=db_path,
            agent_type="infrastructure",
            session_kind="local_listener",
        )
        
        self._cancel_event = threading.Event()
        self._abort_funcs: List[Callable[[], None]] = []
        self._thread: Optional[threading.Thread] = None

    def start(self, **listen_kwargs: Any) -> None:
        """Spawn the asynchronous consumption thread."""
        if self._thread and self._thread.is_alive():
            raise RuntimeError("ListenerEngine already running.")
            
        self._cancel_event.clear()
        self._abort_funcs.clear()
        
        self._thread = threading.Thread(
            target=self._consume_loop,
            args=(listen_kwargs,),
            name=f"ListenerEngine_{self.agent_name}",
            daemon=True
        )
        self._thread.start()

    def _is_kill_switch(self, message: Dict[str, Any]) -> bool:
        """Identifies a SYSTEM-priority halt/stop control message."""
        priority = str(message.get("priority", "")).lower()
        msg_type = str(message.get("msg_type", "")).lower()
        body = str(message.get("body", "")).lower()
        
        if priority != "system":
            return False
            
        if msg_type in ("halt", "stop", "kill"):
            return True
            
        if body in ("halt", "stop", "kill"):
            return True
            
        return False

    def _consume_loop(self, listen_kwargs: Dict[str, Any]) -> None:
        """
        The strictly serialized transport/filter/dispatch loop (v2).
        Enforces Kill Switch -> Policy Evaluation -> Safety Guardrails -> LLM Handler.
        """
        try:
            for message in self.client.listen(
                cancel_event=self._cancel_event,
                abort_receiver=self._abort_funcs,
                **listen_kwargs
            ):
                if self._cancel_event.is_set():
                    break
                    
                # 1. HARDEST KILL SWITCH INTERCEPT (Pre-Policy)
                if self._is_kill_switch(message):
                    # Stop intent triggered. We drop out of the listen loop immediately.
                    self._cancel_event.set()
                    try:
                        logger.critical(f"FATAL: Received SYSTEM kill switch from {message.get('sender', 'unknown')}. Terminating listener.")
                    except Exception:
                        pass
                    break
                    
                # 2. EVALUATE WAKE POLICY
                if not self.wake_policy.evaluate(message):
                    continue

                # 3. APPLY SAFETY GUARDRAILS
                if self.safety:
                    try:
                        self.safety.verify(message)
                    except (RateLimitExceeded, LoopDetected) as e:
                        logger.warning(f"Safety guardrail blocked autonomous wake: {e}")
                        continue
                        
                # 4. INVOKE HANDLER
                try:
                    self.handler(message)
                except Exception as e:
                    logger.error(f"ListenerEngine handler error: {e}", exc_info=True)
                        
        except Exception as e:
            if not self._cancel_event.is_set():
                logger.error(f"ListenerEngine unexpectedly terminated: {e}", exc_info=True)

    def stop(self, timeout: float = 5.0) -> None:
        """
        Signal intent and forcefully break the underlying stream socket for instant return.
        Explicitly deregister the client to release the remote session and prevent ghost presence.
        """
        self._cancel_event.set()
        
        # Forcefully unblock the urllib socket read
        for fn in list(self._abort_funcs):
            try:
                fn()
            except Exception:
                pass
                
        if self._thread and self._thread.is_alive():
            self._thread.join(timeout=timeout)
            
        # Guarantee no ghost presence remains until lease expiry by dropping the session.
        try:
            if self.client.remote_server:
                self.client.deregister()
            elif self.client.session_id and getattr(self.client, "db", None):
                self.client.db.revoke_agent_session(self.client.session_id)
        except Exception as e:
            logger.debug(f"Error deregistering client on ListenerEngine stop: {e}")
