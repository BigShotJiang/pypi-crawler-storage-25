from typing import Dict, Any, Optional, List
from whispers.envelope import Envelope, Priority, MsgType
from .engine import WakePolicy

class CompoundWakePolicy(WakePolicy):
    """
    Evaluates incoming Whispers envelopes against compound criteria (priority,
    message type, sender trust tier, and the agent's current wag state).
    Replaces the default 'always wake' policy with intelligent filtering.
    """

    def __init__(
        self,
        min_priority: Priority = Priority.ROUTINE,
        always_wake_types: Optional[List[MsgType]] = None,
        always_wake_senders: Optional[List[str]] = None,
        never_wake_states: Optional[List[str]] = None,
        agent_state_provider: Optional[callable] = None
    ):
        self.min_priority = Priority(min_priority)
        self.always_wake_types = always_wake_types or [MsgType.REQUEST, MsgType.HANDOFF]
        self.always_wake_senders = always_wake_senders or []
        self.never_wake_states = never_wake_states or ["winding_down", "blocked"]
        
        # A callable that returns the agent's current wag state (e.g. "idle", "building")
        self.agent_state_provider = agent_state_provider or (lambda: "idle")

    def evaluate(self, message: Dict[str, Any]) -> bool:
        """
        Return True to break the listener's idle state and trigger the LLM handler.
        Return False to silently drop or queue the message.
        """
        try:
            env = Envelope.from_dict(message)
        except Exception:
            # If we literally cannot parse the envelope, wake up to allow the handler to error on it,
            # or we could drop it. For safety, let's drop unparseable garbage instead of wasting LLM tokens.
            return False

        current_state = self.agent_state_provider()

        # 1. Never wake states trump everything except SYSTEM
        if current_state in self.never_wake_states and env.priority != Priority.SYSTEM:
            return False

        # 2. SYSTEM priority always wakes
        if env.priority == Priority.SYSTEM:
            return True

        # 3. Always wake requested senders (e.g. operators)
        if env.sender in self.always_wake_senders:
            return True

        # 4. Agent is actively building (deep focus) -- only FLASH+ or explicit requests wake
        if current_state == "building":
            if env.priority in (Priority.FLASH, Priority.SYSTEM):
                return True
            if env.msg_type in self.always_wake_types:
                return True
            return False

        # 5. FLASH always wakes
        if env.priority == Priority.FLASH:
            return True

        # 6. Evaluate message type actionability
        if env.msg_type in self.always_wake_types:
            return True

        # 7. Routine vs min queue limits
        priority_levels = [Priority.ROUTINE, Priority.PRIORITY, Priority.FLASH, Priority.SYSTEM]
        try:
            env_level = priority_levels.index(env.priority)
            min_level = priority_levels.index(self.min_priority)
            if env_level >= min_level:
                return True
        except ValueError:
            pass

        # Default fallback: Queue (don't wake)
        return False
