import os
import sqlite3
import logging
import json
import time
from typing import Dict, Any, Callable, Optional

from whispers.envelope import Envelope, Priority
from .engine import ListenerEngine
from .policies import CompoundWakePolicy
from .safety import SafetyGuardrails

logger = logging.getLogger(__name__)

class AutonomousDaemon:
    """
    Wraps the ListenerEngine with concrete production guardrails, sidecar SQLite
    logging, and graceful Windows service interruption handling (Ctrl+C).
    Perfect for running under NSSM on Windows without mutating the core WhispersDB.
    """

    def __init__(
        self,
        agent_name: str,
        handler_callback: Callable[[Dict[str, Any]], None],
        server_url: Optional[str] = None,
        db_path: Optional[str] = None,
        log_dir: str = "~/.whispers/logs",
        wake_policy: Optional[CompoundWakePolicy] = None,
        safety_guardrails: Optional[SafetyGuardrails] = None,
    ):
        self.agent_name = agent_name
        self.handler_callback = handler_callback
        
        self.wake_policy = wake_policy or CompoundWakePolicy()
        self.safety = safety_guardrails or SafetyGuardrails()
        
        # Sidecar logging to keep wake-audit out of the core throughput DB schema
        expanded_log_dir = os.path.expanduser(log_dir)
        os.makedirs(expanded_log_dir, exist_ok=True)
        self.sidecar_db_path = os.path.join(expanded_log_dir, f"{self.agent_name}_autonomous_audit.sqlite")
        self._init_sidecar_db()

        # Build the engine, injecting the policy and the safety wrapper
        self.engine = ListenerEngine(
            server_url=server_url,
            agent_name=agent_name,
            token=None,  # Configured by cli or ENV
            handler=self._audited_handler,
            wake_policy=self.wake_policy,
            safety_guardrails=self.safety,
            db_path=db_path
        )

    def _init_sidecar_db(self) -> None:
        """Sets up the distinct autonomous_action_log table out-of-band."""
        try:
            with sqlite3.connect(self.sidecar_db_path) as conn:
                conn.execute("""
                    CREATE TABLE IF NOT EXISTS autonomous_action_log (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        timestamp REAL,
                        incoming_uuid TEXT,
                        sender TEXT,
                        msg_type TEXT,
                        priority TEXT,
                        wake_result TEXT,
                        safety_result TEXT,
                        handler_error TEXT
                    )
                """)
                conn.commit()
        except Exception as e:
            logger.error(f"Failed to init sidecar audit DB at {self.sidecar_db_path}: {e}")

    def _log_audit(self, incoming: Dict[str, Any], wake: str, safety: str, error: str = "") -> None:
        try:
            with sqlite3.connect(self.sidecar_db_path) as conn:
                conn.execute(
                    "INSERT INTO autonomous_action_log (timestamp, incoming_uuid, sender, msg_type, priority, wake_result, safety_result, handler_error) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                    (
                        time.time(),
                        incoming.get("uuid", incoming.get("id")),
                        incoming.get("from_agent", incoming.get("sender")),
                        incoming.get("msg_type"),
                        incoming.get("priority"),
                        wake,
                        safety,
                        error
                    )
                )
                conn.commit()
        except Exception as e:
            logger.debug(f"Audit log insertion failed: {e}")

    def _audited_handler(self, message: Dict[str, Any]) -> None:
        """
        Wrapper that sits around the raw LLM callback to register sidecar logging
        and feed the loop-detector interaction history.
        """
        sender = message.get("from_agent") or message.get("sender", "unknown")
        msg_type = message.get("msg_type", "inform")
        
        error_str = ""
        try:
            # We already passed Policy & Safety to get here
            self.handler_callback(message)
            
            # If the handler succeeded, register the interaction as a sent response
            # for loop-detection protection.
            self.safety.log_interaction(sender=self.agent_name, recipient=sender, msg_type="response")
            
        except Exception as e:
            error_str = str(e)
            logger.error(f"Daemon handler execution failed: {e}")
            raise e
        finally:
            self._log_audit(message, wake="WAKE", safety="PASS", error=error_str)

    def run_forever(self) -> None:
        """Blocks and consumes until KeyboardInterrupt (Ctrl+C => NSSM Shutdown)."""
        logger.info(f"Booting AutonomousDaemon for [{self.agent_name}]...")
        self.engine.start()
        
        try:
            while True:
                time.sleep(1.0)
        except KeyboardInterrupt:
            logger.info("Received KeyboardInterrupt / NSSM Stop. Shutting down daemon gracefully.")
            self.engine.stop()
            logger.info("Daemon cleanly terminated.")
