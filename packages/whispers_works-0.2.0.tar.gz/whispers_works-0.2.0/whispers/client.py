import contextlib
import json
import os
import re
import time
import urllib.error
import urllib.parse
import urllib.request
from typing import Optional, List, Dict, Any
from .envelope import AcknowledgmentState, Envelope, Priority, MsgType, hydrate_policy_fields
from .identity import fingerprint_public_key, normalize_public_key, validate_remote_callsign
from .path_utils import resolve_path, whispers_path
from .storage.db import (
    DEFAULT_READINESS_STATE,
    WhispersDB,
    WhispersDBError,
    WhispersIdentityConflictError,
    WhispersLeaseConflictError,
    WhispersRateLimitError,
)
from .modes import Mode, ModeFilter
from .dispatcher import Dispatcher
from .startup import (
    build_attention_treatment_summary,
    build_startup_briefing,
    normalize_pending_by_class_counts,
)
from .baton_enforcement import (
    YIELD_BLOCKING_READINESS_STATES,
    format_yield_blocked_message,
    yield_blocking_baton_obligations,
)
from .connection_story import (
    ActiveReplyAlert,
    ActiveThreadWatch,
    BatonDetail,
    ConnectionStory,
    HuddlePeer,
    PeerSnapshot,
    SinceLastSeen,
    build_jolt_packet,
    build_briefing_capsule,
    infer_jolt_decision,
    infer_recommended_action,
)
from .jolt import host_wake_capabilities_from_dict, jolt_adapter_from_dict, jolt_budget_from_dict
from .coordination_runtime import coordination_activity_event_from_record, coordination_state_from_dict
from .presence_policy import apply_presence_policy_to_record
from .time_utils import add_local_timestamp_fields, local_timezone_label, parse_timestamp, utc_now, utc_now_iso
from .twoack import (
    TERMINAL_BATON_STATES,
    ReceptionTruth,
    check_reply_schema_constraint,
    derive_text_fallback,
    validate_message,
    validate_schema,
)
from .twoack_schemas import (
    StatusUpdate,
    HandoffBaton,
    DecisionRequest,
    DecisionResponse,
    ExternalActionRequest,
    ExternalActionResult,
    BatonAck,
    BatonUpdate,
    BatonClose,
)
from .workspaces import WorkspaceManager

import uuid
import logging

logger = logging.getLogger("whispers")

_INSTALL_STATE_ENV = "WHISPERS_INSTALL_STATE_PATH"
_DEPLOYMENT_MODE_ENV = "WHISPERS_DEPLOYMENT_MODE"
_SERVER_PORT_ENV = "WHISPERS_SERVER_PORT"
_LOCAL_SERVER_PORT = int(os.getenv(_SERVER_PORT_ENV, "8752"))
_HEALTH_URL = f"http://127.0.0.1:{_LOCAL_SERVER_PORT}/health"
_LIVEZ_URL = f"http://127.0.0.1:{_LOCAL_SERVER_PORT}/livez"
_READYZ_URL = f"http://127.0.0.1:{_LOCAL_SERVER_PORT}/readyz"
_PROFILES_ENV = "WHISPERS_PROFILES_PATH"
_CREDENTIALS_ENV = "WHISPERS_CREDENTIALS_PATH"
_ACTIVE_HEARTBEAT_WINDOW_SECONDS = int(os.getenv("WHISPERS_ACTIVE_HEARTBEAT_WINDOW_SECONDS", "120"))
_ACTIVE_LAST_ACTIVE_WINDOW_SECONDS = int(os.getenv("WHISPERS_ACTIVE_LAST_ACTIVE_WINDOW_SECONDS", "600"))
_LOCAL_SESSION_LEASE_SECONDS = int(os.getenv("WHISPERS_LOCAL_SESSION_LEASE_SECONDS", "300"))
_MCP_SESSION_LEASE_SECONDS = int(os.getenv("WHISPERS_MCP_SESSION_LEASE_SECONDS", "1800"))
_PARTICIPANT_KINDS = ("agent", "service", "automaton", "ephemeral")
_PARTICIPANT_PROFILE_TAGS = frozenset(
    {
        "approval_surface",
        "status_source",
        "human_contact",
        "action_target",
        "sensor",
        "bridge_gateway",
    }
)
_FIRST_CLASS_SERVICE_CALLSIGNS = {"whispers-server", "whispers-console"}
_EXPLICIT_AUTOMATON_CALLSIGNS = {
    "brain-briefing",
    "game_orchestrator",
    "reactor-bot",
    "system_guardian",
    "ts-sdk-bot",
}
_EXPLICIT_EPHEMERAL_CALLSIGNS = {"cli-user"}
_EPHEMERAL_CALLSIGN_RE = re.compile(
    r"(^_|^test(?:$|[-_])|^probe(?:$|[-_])|probeperf|^debug(?:$|[-_])|^autostart(?:$|[-_]))"
)
_AUTOMATON_NAME_TOKENS = ("briefing", "guardian", "orchestrator", "reactor")
_LISTENER_BACKED_SESSION_KINDS = {"infrastructure", "local_listener"}
_MANUAL_WAKE_SESSION_KINDS = {"local_client", "mcp_bridge", "remote_http"}
_OPERATOR_CONSOLE_SESSION_KINDS = {"dashboard_console"}
_HOT_THREAD_DELIVERY_WINDOW_SECONDS = 5 * 60
_HOT_THREAD_READ_WINDOW_SECONDS = 5 * 60
_HOT_THREAD_REPLY_WINDOW_SECONDS = 15 * 60
_RUNTIME_STATE_PATH_ENV = "WHISPERS_RUNTIME_STATE_PATH"

class WhispersException(Exception):
    pass

class WhispersConflictError(WhispersException):
    pass

class PermissionDeniedError(WhispersException):
    pass

class AgentNotFoundError(WhispersException):
    pass


def _install_state_path() -> str:
    override = os.getenv(_INSTALL_STATE_ENV)
    if override:
        return resolve_path(override)
    return whispers_path("install-state.json")


def _profiles_path() -> str:
    override = os.getenv(_PROFILES_ENV)
    if override:
        return resolve_path(override)
    return whispers_path("profiles.json")


def _credentials_path() -> str:
    override = os.getenv(_CREDENTIALS_ENV)
    if override:
        return resolve_path(override)
    return whispers_path("credentials.json")


def _runtime_state_path() -> str:
    override = os.getenv(_RUNTIME_STATE_PATH_ENV)
    if override:
        return resolve_path(override)
    return whispers_path("runtime-state.json")


def _load_json_store(path: str) -> Dict[str, Any]:
    if not os.path.exists(path):
        return {}
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
    return data if isinstance(data, dict) else {}


def _write_json_store(path: str, payload: Dict[str, Any]) -> None:
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2, sort_keys=True)
        f.write("\n")


def _load_runtime_telemetry(agent_name: str) -> Dict[str, Any]:
    state = _load_json_store(_runtime_state_path())
    snapshots = state.get("agent_telemetry")
    if not isinstance(snapshots, dict):
        return {}
    snapshot = snapshots.get(agent_name)
    return snapshot if isinstance(snapshot, dict) else {}


def _persist_runtime_telemetry(agent_name: str, heartbeat: Dict[str, Any]) -> None:
    state = _load_json_store(_runtime_state_path())
    snapshots = state.get("agent_telemetry")
    if not isinstance(snapshots, dict):
        snapshots = {}
    snapshot = dict(snapshots.get(agent_name) or {})
    for key in (
        "context_load",
        "interruptibility",
        "quality_risk",
        "current_task",
        "progress_summary",
        "last_progress_at",
        "attention_state",
        "attention_detail",
    ):
        if key in heartbeat:
            snapshot[key] = heartbeat[key]
    snapshot["updated_at"] = utc_now_iso()
    snapshots[agent_name] = snapshot
    state["agent_telemetry"] = snapshots
    _write_json_store(_runtime_state_path(), state)


_MESSAGE_TIMESTAMP_FIELDS = ("created_at", "read_at", "delivered_at", "claimed_at", "seen_at", "acked_at")
_BATON_TIMESTAMP_FIELDS = ("created_at", "updated_at", "expires_at")
_CARD_TIMESTAMP_FIELDS = ("registered_at", "last_seen", "deregistered_at")
_PRESENCE_TIMESTAMP_FIELDS = ("last_active", "mode_set_at", "state_updated_at", "heartbeat_at")
_WORKSPACE_TIMESTAMP_FIELDS = ("created_at", "last_delta_at", "last_activity_at")
_WORKSPACE_MEMBER_TIMESTAMP_FIELDS = ("joined_at", "left_at")
_WORKSPACE_EVENT_TIMESTAMP_FIELDS = ("created_at",)
_RUNTIME_FIELD_UNSET = Ellipsis


def _localize_record(record: Optional[Dict[str, Any]], fields) -> Optional[Dict[str, Any]]:
    if not record:
        return record
    return add_local_timestamp_fields(hydrate_policy_fields(record), fields)


def _localize_baton_record(record: Optional[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
    if not record:
        return record
    localized = dict(record)
    artifact_refs = localized.get("artifact_refs")
    if isinstance(artifact_refs, str):
        try:
            localized["artifact_refs"] = json.loads(artifact_refs)
        except Exception:
            localized["artifact_refs"] = [artifact_refs] if artifact_refs else None
    return _localize_record(localized, _BATON_TIMESTAMP_FIELDS)


def _localize_status_payload(payload: Dict[str, Any]) -> Dict[str, Any]:
    localized = dict(payload)
    localized["display_timezone"] = local_timezone_label()
    localized["now_utc"] = localized.get("now_utc") or utc_now_iso()
    localized["now_local"] = localized.get("now_local") or add_local_timestamp_fields(
        {"now_utc": localized["now_utc"]},
        ("now_utc",),
    ).get("now_utc_local")

    for field in _PRESENCE_TIMESTAMP_FIELDS:
        if localized.get(field):
            localized[f"{field}_local"] = add_local_timestamp_fields(localized, (field,)).get(f"{field}_local")

    localized["peers_online"] = [
        _localize_record(peer, _PRESENCE_TIMESTAMP_FIELDS) for peer in localized.get("peers_online", [])
    ]
    localized["agents_online"] = [
        _localize_record(agent, _PRESENCE_TIMESTAMP_FIELDS) for agent in localized.get("agents_online", [])
    ]
    localized["background_agents"] = [
        _localize_record(agent, _PRESENCE_TIMESTAMP_FIELDS) for agent in localized.get("background_agents", [])
    ]
    localized["captain_action_alerts"] = [
        _localize_record(alert, ("created_at",))
        for alert in localized.get("captain_action_alerts", [])
        if isinstance(alert, dict)
    ]
    return localized


def _suppress_idle_current_task(record: Dict[str, Any]) -> None:
    """Hide obviously stale task strings from operator-facing presence surfaces.

    Runtime state may preserve the last structural task longer than the agent's
    live cognitive posture. If an agent is back to a ready/listening posture
    with no explicit working-on field, surfacing the old task is misleading.
    """
    current_task = record.get("current_task")
    if not current_task or record.get("working_on"):
        return

    readiness = str(record.get("readiness") or DEFAULT_READINESS_STATE).strip().lower()
    cognitive_state = str(record.get("cognitive_state") or "").strip().lower()
    derived_active_mode = str(record.get("derived_active_mode") or "").strip().lower()

    if readiness != DEFAULT_READINESS_STATE:
        return

    if cognitive_state and cognitive_state not in {"listening", "idle"}:
        return

    if derived_active_mode and derived_active_mode not in {"ready", "active", "warming"}:
        return

    record.pop("current_task", None)


def _peers_needing_assignment(peers: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    alerts: List[Dict[str, Any]] = []
    for peer in peers:
        if not isinstance(peer, dict):
            continue
        attention_state = str(peer.get("attention_state") or "").strip().lower()
        if attention_state != "needs_assignment":
            continue
        agent_name = str(peer.get("agent_name") or peer.get("callsign") or "").strip()
        if not agent_name:
            continue
        wake_model = str(peer.get("wake_model") or "").strip().lower() or None
        operator_nudge_required = _operator_nudge_required_for_peer(peer)
        alerts.append(
            {
                "agent_name": agent_name,
                "attention_state": attention_state,
                "attention_detail": (
                    str(
                        peer.get("attention_detail")
                        or peer.get("progress_summary")
                        or peer.get("current_task")
                        or ""
                    ).strip()
                    or None
                ),
                "readiness": str(peer.get("readiness") or DEFAULT_READINESS_STATE).strip().lower() or DEFAULT_READINESS_STATE,
                "trust_tier": int(peer.get("trust_tier") or 1),
                "wake_model": wake_model,
                "operator_nudge_required": operator_nudge_required,
            }
        )
    alerts.sort(
        key=lambda item: (
            -int(bool(item.get("operator_nudge_required"))),
            -int(item.get("trust_tier") or 1),
            str(item.get("agent_name") or ""),
        )
    )
    return alerts


def _first_summary_line(value: Any) -> Optional[str]:
    if value is None:
        return None
    text = str(value).strip()
    if not text:
        return None
    for raw_line in text.splitlines():
        line = raw_line.strip()
        if not line:
            continue
        line = re.sub(r"^[#>\-\*\d\.\)\s]+", "", line).strip()
        line = line.replace("**", "").replace("__", "").replace("`", "")
        if line:
            return line
    return None


def _captain_action_alert_from_record(record: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    if not isinstance(record, dict):
        return None

    sender = str(record.get("from_agent") or "").strip()
    if not sender:
        return None

    subject = str(record.get("subject") or "").strip()
    msg_type = str(record.get("msg_type") or "").strip().lower()
    subject_lower = subject.lower()

    has_completion = "completion" in subject_lower
    has_proposal = (
        msg_type == "propose"
        or "proposal" in subject_lower
        or "execution packet" in subject_lower
    )
    has_correction = subject_lower.startswith("correction")
    if has_completion and has_proposal:
        kind = "completion_proposal"
        label = "completion + proposal"
    elif has_completion:
        kind = "completion"
        label = "completion"
    elif has_proposal:
        kind = "proposal"
        label = "proposal"
    elif has_correction:
        kind = "correction"
        label = "correction"
    else:
        return None

    response_required = kind != "correction"
    detail = (
        _first_summary_line(record.get("body"))
        or _first_summary_line(record.get("payload"))
        or subject
        or None
    )
    created_at = str(record.get("created_at") or "").strip() or None
    age_seconds: Optional[float] = None
    if created_at:
        try:
            age_seconds = max(0.0, (utc_now() - parse_timestamp(created_at)).total_seconds())
        except Exception:
            age_seconds = None

    return {
        "message_id": str(record.get("uuid") or record.get("message_id") or "").strip() or None,
        "sender": sender,
        "kind": kind,
        "label": label,
        "subject": subject or None,
        "detail": detail,
        "priority": str(record.get("priority") or "routine").strip().lower() or "routine",
        "created_at": created_at,
        "age_seconds": age_seconds,
        "response_required": response_required,
    }


def _captain_action_sort_key(alert: Dict[str, Any]) -> tuple[int, int, float]:
    priority = str(alert.get("priority") or "routine").strip().lower()
    priority_rank = {
        "flash": 0,
        "system": 0,
        "priority": 1,
        "routine": 2,
    }.get(priority, 3)
    created_ts = 0.0
    created_at = str(alert.get("created_at") or "").strip()
    if created_at:
        try:
            created_ts = parse_timestamp(created_at).timestamp()
        except Exception:
            created_ts = 0.0
    return (
        0 if bool(alert.get("response_required", True)) else 1,
        priority_rank,
        -created_ts,
    )


def _captain_action_alerts(conn, viewer_agent: str, limit: int = 3) -> List[Dict[str, Any]]:
    viewer_aliases = _resolve_callsign_aliases(conn, viewer_agent)
    if not viewer_aliases:
        return []

    viewer_placeholders = ",".join("?" * len(viewer_aliases))
    query = f"""
        SELECT m.uuid, m.from_agent, m.subject, m.body, m.payload, m.msg_type, m.priority, m.created_at
        FROM messages m
        JOIN message_recipients r ON m.uuid = r.message_uuid
        WHERE r.recipient_callsign IN ({viewer_placeholders})
          AND m.status = 'new'
          AND r.delivery_status IN ('queued', 'unclaimed', 'delivered')
          AND r.read_at IS NULL
          AND m.from_agent NOT IN ({viewer_placeholders})
        ORDER BY
          CASE m.priority
            WHEN 'flash' THEN 0
            WHEN 'system' THEN 0
            WHEN 'priority' THEN 1
            ELSE 2
          END,
          m.created_at DESC
        LIMIT ?
    """
    rows = conn.execute(query, viewer_aliases + viewer_aliases + [max(limit * 12, 60)]).fetchall()

    best_by_sender: Dict[str, Dict[str, Any]] = {}
    for row in rows:
        alert = _captain_action_alert_from_record(dict(row))
        if not alert:
            continue
        sender = str(alert.get("sender") or "").strip()
        if not sender:
            continue
        existing = best_by_sender.get(sender)
        if existing is None or _captain_action_sort_key(alert) < _captain_action_sort_key(existing):
            best_by_sender[sender] = alert
    return sorted(best_by_sender.values(), key=_captain_action_sort_key)[:limit]


def _peer_has_pending_captain_action(peer: Dict[str, Any], captain_alerts: List[Dict[str, Any]]) -> bool:
    if not isinstance(peer, dict):
        return False

    attention_state = str(peer.get("attention_state") or "").strip().lower()
    if attention_state != "needs_assignment":
        return False

    peer_name = str(peer.get("agent_name") or peer.get("callsign") or "").strip()
    if not peer_name:
        return False

    updated_at = (
        str(
            peer.get("runtime_updated_at")
            or peer.get("state_updated_at")
            or ""
        ).strip()
        or None
    )
    updated_ts = None
    if updated_at:
        try:
            updated_ts = parse_timestamp(updated_at)
        except Exception:
            updated_ts = None

    for alert in captain_alerts:
        if str(alert.get("sender") or "").strip() != peer_name:
            continue
        if not bool(alert.get("response_required", True)):
            continue
        created_at = str(alert.get("created_at") or "").strip() or None
        if not created_at or updated_ts is None:
            return True
        try:
            if parse_timestamp(created_at) >= updated_ts:
                return True
        except Exception:
            return True
    return False


def _peer_assignment_request_answered(
    conn,
    peer: Dict[str, Any],
) -> bool:
    if not isinstance(peer, dict):
        return False

    attention_state = str(peer.get("attention_state") or "").strip().lower()
    if attention_state != "needs_assignment":
        return False

    peer_name = str(peer.get("agent_name") or peer.get("callsign") or "").strip()
    if not peer_name:
        return False

    peer_aliases = _resolve_callsign_aliases(conn, peer_name)
    if not peer_aliases:
        return False

    peer_placeholders = ",".join("?" * len(peer_aliases))
    updated_at = (
        str(
            peer.get("runtime_updated_at")
            or peer.get("state_updated_at")
            or ""
        ).strip()
        or None
    )

    query = f"""
        SELECT 1
        FROM messages m
        JOIN message_recipients r ON m.uuid = r.message_uuid
        WHERE m.from_agent NOT IN ({peer_placeholders})
          AND r.recipient_callsign IN ({peer_placeholders})
          AND (
              m.reply_to IS NOT NULL
              OR m.msg_type IN ('request', 'handoff')
              OR m.metadata LIKE '%whispers:coordination_kind%'
              OR m.payload LIKE '%"coordination"%'
          )
    """
    params: List[Any] = peer_aliases + peer_aliases
    if updated_at:
        query += " AND m.created_at >= ?"
        params.append(updated_at)
    query += " ORDER BY m.created_at DESC LIMIT 1"
    row = conn.execute(query, params).fetchone()
    return row is not None



def _participant_kind_for_record(record: Dict[str, Any]) -> str:
    callsign = str(record.get("callsign") or record.get("agent_name") or "").strip().lower()
    agent_type = str(record.get("agent_type") or "").strip().lower()
    display_name = str(record.get("display_name") or "").strip().lower()

    if not callsign:
        return "agent"

    if callsign in _FIRST_CLASS_SERVICE_CALLSIGNS or "whispers console" in display_name:
        return "service"

    if callsign in _EXPLICIT_EPHEMERAL_CALLSIGNS or _EPHEMERAL_CALLSIGN_RE.search(callsign):
        return "ephemeral"

    if callsign in _EXPLICIT_AUTOMATON_CALLSIGNS:
        return "automaton"

    if agent_type == "infrastructure":
        return "service" if callsign in _FIRST_CLASS_SERVICE_CALLSIGNS else "automaton"

    if "console" in callsign or "dashboard" in callsign:
        return "service"

    if any(token in callsign for token in _AUTOMATON_NAME_TOKENS):
        return "automaton"

    return "agent"


def _decode_json_list_field(raw_value: Any) -> list[Any]:
    if raw_value is None:
        return []
    if isinstance(raw_value, str):
        text = raw_value.strip()
        if not text:
            return []
        try:
            parsed = json.loads(text)
        except (json.JSONDecodeError, TypeError):
            return [text]
        if isinstance(parsed, list):
            return [item for item in parsed if item is not None]
        return [parsed]
    if isinstance(raw_value, list):
        return [item for item in raw_value if item is not None]
    if isinstance(raw_value, tuple):
        return [item for item in raw_value if item is not None]
    if isinstance(raw_value, set):
        return [item for item in raw_value if item is not None]
    return [raw_value]


def _participant_profiles_from_tags(raw_tags: Any) -> list[str]:
    explicit_profiles: list[str] = []
    seen = set()
    for item in _decode_json_list_field(raw_tags):
        text = str(item or "").strip()
        if not text:
            continue
        lowered = text.lower()
        if lowered.startswith("profile:"):
            lowered = lowered.split(":", 1)[1].strip()
        if lowered in _PARTICIPANT_PROFILE_TAGS and lowered not in seen:
            seen.add(lowered)
            explicit_profiles.append(lowered)
    return explicit_profiles


def _is_first_class_participant(kind: str) -> bool:
    return kind in {"agent", "service"}


def _annotate_participant_record(record: Dict[str, Any]) -> str:
    kind = _participant_kind_for_record(record)
    capabilities = _decode_json_list_field(record.get("capabilities"))
    tools = _decode_json_list_field(record.get("tools"))
    tags = _decode_json_list_field(record.get("tags"))
    record["participant_kind"] = kind
    record["is_primary_participant"] = _is_first_class_participant(kind)
    record["is_first_class_participant"] = record["is_primary_participant"]
    record["capabilities"] = capabilities
    record["tools"] = tools
    record["tags"] = tags
    record["participant_profiles"] = _participant_profiles_from_tags(tags)
    return kind


def _empty_participant_counts() -> Dict[str, Dict[str, int]]:
    return {kind: {"registered": 0, "online": 0} for kind in _PARTICIPANT_KINDS}


def _build_participant_summary(
    records: List[Dict[str, Any]],
    *,
    online_names: Optional[set[str]] = None,
) -> Dict[str, Any]:
    counts = _empty_participant_counts()
    online_names = online_names or set()

    for record in records:
        kind = str(record.get("participant_kind") or "").strip().lower()
        if kind not in counts:
            kind = _annotate_participant_record(record)
        callsign = str(record.get("callsign") or record.get("agent_name") or "").strip()
        is_online = callsign in online_names if online_names else bool(record.get("is_online"))
        counts[kind]["registered"] += 1
        if is_online:
            counts[kind]["online"] += 1

    first_class_registered = counts["agent"]["registered"] + counts["service"]["registered"]
    first_class_online = counts["agent"]["online"] + counts["service"]["online"]
    other_registered = counts["automaton"]["registered"] + counts["ephemeral"]["registered"]
    other_online = counts["automaton"]["online"] + counts["ephemeral"]["online"]
    return {
        "participant_counts": counts,
        "primary_participants_registered": first_class_registered,
        "primary_participants_online": first_class_online,
        "secondary_participants_registered": other_registered,
        "secondary_participants_online": other_online,
        "first_class_participants_registered": first_class_registered,
        "first_class_participants_online": first_class_online,
        "other_participants_registered": other_registered,
        "other_participants_online": other_online,
    }


def _normalize_session_kind_list(raw_value: Any) -> List[str]:
    if raw_value is None:
        return []
    if isinstance(raw_value, str):
        candidates = raw_value.split(",")
    elif isinstance(raw_value, (list, tuple, set)):
        candidates = list(raw_value)
    else:
        candidates = [raw_value]

    normalized: List[str] = []
    seen = set()
    for item in candidates:
        text = str(item or "").strip().lower()
        if not text or text in seen:
            continue
        seen.add(text)
        normalized.append(text)
    normalized.sort()
    return normalized


def _derive_wake_model(
    *,
    session_kinds: List[str],
    agent_type: Any = None,
    presence_kind: Any = None,
) -> Optional[str]:
    categories = set()
    kinds = set(session_kinds)
    if kinds & _LISTENER_BACKED_SESSION_KINDS:
        categories.add("listener_backed")
    if kinds & _MANUAL_WAKE_SESSION_KINDS:
        categories.add("manual_wake")
    if kinds & _OPERATOR_CONSOLE_SESSION_KINDS:
        categories.add("operator_console")
    if len(categories) > 1:
        return "mixed"
    if categories:
        return next(iter(categories))

    normalized_agent_type = str(agent_type or "").strip().lower()
    normalized_presence_kind = str(presence_kind or "").strip().lower()
    if normalized_agent_type == "infrastructure" or normalized_presence_kind == "system":
        return "listener_backed"
    return None


def _annotate_wake_model(record: Dict[str, Any]) -> Optional[str]:
    session_kinds = _normalize_session_kind_list(record.get("session_kinds"))
    if session_kinds:
        record["session_kinds"] = session_kinds
    elif "session_kinds" in record:
        record["session_kinds"] = []

    wake_model = _derive_wake_model(
        session_kinds=session_kinds,
        agent_type=record.get("agent_type"),
        presence_kind=record.get("presence_kind"),
    )
    if wake_model is not None:
        record["wake_model"] = wake_model
    elif "wake_model" in record:
        record["wake_model"] = None
    return wake_model


def _session_capabilities_from_metadata(raw_metadata: Any) -> Dict[str, Any]:
    metadata: Dict[str, Any] = {}
    if isinstance(raw_metadata, dict):
        metadata = raw_metadata
    elif raw_metadata:
        with contextlib.suppress(Exception):
            decoded = json.loads(raw_metadata)
            if isinstance(decoded, dict):
                metadata = decoded
    capabilities = metadata.get("capabilities")
    return capabilities if isinstance(capabilities, dict) else {}


def _session_contract_priority(contract: Dict[str, Any]) -> tuple[int, int, int, int]:
    host_capabilities = contract.get("jolt_host_capabilities")
    return (
        int(bool(host_capabilities and host_capabilities.can_trigger_inference)),
        int(bool(host_capabilities and host_capabilities.can_stage_context)),
        int(bool(host_capabilities and host_capabilities.can_notify)),
        int(contract.get("session_kind") in _LISTENER_BACKED_SESSION_KINDS),
    )


def _attach_active_session_wake_contract(record: Dict[str, Any], *, conn) -> None:
    agent_name = str(record.get("agent_name") or record.get("callsign") or "").strip()
    if not agent_name:
        return

    rows = conn.execute(
        """
        SELECT session_kind, metadata
        FROM agent_sessions
        WHERE agent_name = ?
          AND lease_expires_at >= CURRENT_TIMESTAMP
        ORDER BY last_seen_at DESC
        """,
        (agent_name,),
    ).fetchall()

    best_contract: Optional[Dict[str, Any]] = None
    for row in rows:
        session_kind = str(row["session_kind"] or "").strip().lower()
        if not session_kind:
            continue
        capabilities = _session_capabilities_from_metadata(row["metadata"])
        if not capabilities:
            continue
        session_wake_model = _derive_wake_model(
            session_kinds=_normalize_session_kind_list([session_kind]),
            agent_type=record.get("agent_type"),
            presence_kind=record.get("presence_kind"),
        )
        if not session_wake_model:
            continue
        contract = {
            "session_kind": session_kind,
            "jolt_host_capabilities": host_wake_capabilities_from_dict(session_wake_model, capabilities),
            "jolt_adapter": jolt_adapter_from_dict(session_wake_model, capabilities),
        }
        if best_contract is None or _session_contract_priority(contract) > _session_contract_priority(best_contract):
            best_contract = contract

    if best_contract is None:
        return
    record["jolt_host_capabilities"] = best_contract["jolt_host_capabilities"].to_dict()
    record["jolt_adapter"] = best_contract["jolt_adapter"].to_dict()


def _peer_has_active_host_path(peer: Dict[str, Any]) -> bool:
    wake_model = str(peer.get("wake_model") or "").strip().lower() or None
    if not wake_model:
        return False

    host_capabilities_payload = peer.get("jolt_host_capabilities")
    if isinstance(host_capabilities_payload, dict):
        host_capabilities = host_wake_capabilities_from_dict(wake_model, host_capabilities_payload)
        return bool(host_capabilities.can_stage_context or host_capabilities.can_trigger_inference)

    adapter_payload = peer.get("jolt_adapter")
    if isinstance(adapter_payload, dict):
        host_capabilities = host_wake_capabilities_from_dict(
            wake_model,
            {"jolt": {"adapter": adapter_payload}},
        )
        return bool(host_capabilities.can_stage_context or host_capabilities.can_trigger_inference)
    return False


def _operator_nudge_required_for_peer(peer: Dict[str, Any]) -> bool:
    wake_model = str(peer.get("wake_model") or "").strip().lower() or None
    if wake_model != "manual_wake":
        return False
    return not _peer_has_active_host_path(peer)


def _attach_status_story(
    client: "WhispersClient",
    payload: Dict[str, Any],
) -> Dict[str, Any]:
    """Attach canonical startup and connection-story views to a status payload."""
    enriched = dict(payload)
    if isinstance(enriched.get("startup"), dict) and isinstance(enriched.get("connection_story"), dict):
        return enriched
    try:
        story = client.get_connection_story(status_snapshot=enriched)
        enriched["connection_story"] = story.to_dict()
        enriched["startup"] = build_briefing_capsule(story)
        if story.jolt_packet is not None:
            enriched["jolt_packet"] = story.jolt_packet.to_dict()
        if story.jolt_adapter is not None:
            enriched["jolt_adapter"] = story.jolt_adapter.to_dict()
        if story.jolt_host_capabilities is not None:
            enriched["jolt_host_capabilities"] = story.jolt_host_capabilities.to_dict()
        if story.jolt_budget is not None:
            enriched["jolt_budget"] = story.jolt_budget.to_dict()
        if story.jolt_decision is not None:
            enriched["jolt"] = story.jolt_decision.to_dict()
    except Exception:
        # Preserve status availability even if the richer startup surface fails.
        enriched["startup"] = build_startup_briefing(enriched, agent_name=client.agent_name)
    return enriched


def _is_active_collaborator_reply(row: Dict[str, Any]) -> bool:
    msg_type = str(row.get("msg_type") or "").strip().lower()
    subject = str(row.get("subject") or "").strip().lower()
    return bool(row.get("reply_to")) or msg_type == "checkpoint" or subject.startswith("re:")


def _extract_active_reply_alerts(
    rows: List[Dict[str, Any]],
    *,
    agent_name: str | None = None,
    limit: int = 3,
) -> List[Dict[str, Any]]:
    alerts: List[Dict[str, Any]] = []
    self_name = str(agent_name or "").strip().lower()
    for row in rows:
        if not isinstance(row, dict) or not _is_active_collaborator_reply(row):
            continue
        counterpart = str(row.get("from_agent") or "").strip()
        subject = str(row.get("subject") or "").strip() or "(no subject)"
        message_id = str(row.get("uuid") or "").strip()
        if not counterpart or not message_id:
            continue
        if self_name and counterpart.lower() == self_name:
            continue
        alerts.append(
            {
                "message_id": message_id,
                "counterpart": counterpart,
                "subject": subject,
                "priority": str(row.get("priority") or "routine"),
                "msg_type": str(row.get("msg_type") or "inform"),
                "created_at": row.get("created_at"),
                "reply_to": row.get("reply_to"),
            }
        )
        if len(alerts) >= limit:
            break
    return alerts


def _is_active_thread_follow_up(row: Dict[str, Any]) -> bool:
    msg_type = str(row.get("msg_type") or "").strip().lower()
    subject = str(row.get("subject") or "").strip().lower()
    if msg_type == "accept":
        return False
    if msg_type == "inform" and (
        subject.startswith("baton update:") or subject.startswith("baton closed:")
    ):
        return False
    return bool(row.get("reply_to")) or msg_type == "checkpoint" or subject.startswith("re:")


def _format_hot_thread_age(value: Any) -> Optional[str]:
    ts = parse_timestamp(value)
    if ts is None:
        return None

    age_seconds = max(0.0, (utc_now() - ts).total_seconds())
    minutes = age_seconds / 60
    if minutes >= 60:
        hours = minutes / 60
        if hours >= 24:
            return f"{hours / 24:.1f}d"
        return f"{hours:.1f}h"
    if age_seconds >= 60:
        return f"{int(minutes)}m"
    return f"{int(age_seconds)}s"


def _extract_active_thread_watches(
    rows: List[Dict[str, Any]],
    *,
    agent_name: str | None = None,
    limit: int = 3,
) -> List[Dict[str, Any]]:
    watches: List[Dict[str, Any]] = []
    self_name = str(agent_name or "").strip().lower()
    for row in rows:
        if not isinstance(row, dict) or not _is_active_thread_follow_up(row):
            continue
        if row.get("has_reply") or row.get("replied_at") or row.get("ack_state"):
            continue

        message_id = str(row.get("uuid") or "").strip()
        counterpart = str(row.get("counterpart") or row.get("to_agent") or "").strip()
        subject = str(row.get("subject") or "").strip() or "(no subject)"
        delivery_status = str(row.get("delivery_status") or "").strip().lower()
        read_at = row.get("read_at")
        created_at = row.get("created_at")

        if not message_id or not counterpart or delivery_status == "dead_lettered":
            continue
        if self_name and counterpart.lower() == self_name:
            continue

        if delivery_status == "queued":
            stage = "awaiting_delivery"
            age_field = created_at
            stage_label = "sent"
            max_age = _HOT_THREAD_DELIVERY_WINDOW_SECONDS
        elif read_at:
            stage = "awaiting_reply"
            age_field = read_at
            stage_label = "read"
            max_age = _HOT_THREAD_REPLY_WINDOW_SECONDS
        else:
            stage = "awaiting_read"
            age_field = row.get("delivered_at") or row.get("claimed_at") or created_at
            stage_label = "delivered" if delivery_status == "delivered" else "sent"
            max_age = _HOT_THREAD_READ_WINDOW_SECONDS

        ts = parse_timestamp(age_field)
        if ts is None:
            continue
        age_seconds = max(0.0, (utc_now() - ts).total_seconds())
        if age_seconds > max_age:
            continue

        watch_record = {
            "message_id": message_id,
            "counterpart": counterpart,
            "subject": subject,
            "stage": stage,
            "priority": str(row.get("priority") or "routine"),
            "msg_type": str(row.get("msg_type") or "inform"),
            "created_at": created_at,
            "delivered_at": row.get("delivered_at"),
            "read_at": read_at,
            "stage_started_at": age_field,
            "stage_label": stage_label,
            "age_label": _format_hot_thread_age(age_field),
        }
        try:
            watch_record["reception_truth"] = ReceptionTruth.from_db_row(row).to_dict()
        except Exception:
            pass
        watches.append(watch_record)
        if len(watches) >= limit:
            break
    return watches


def _decode_jsonish(value: Any) -> Any:
    if isinstance(value, str):
        try:
            return json.loads(value)
        except Exception:
            return value
    return value


def _extract_handoff_view(record: Optional[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
    if not record:
        return None

    hydrated = dict(record)
    metadata = _decode_jsonish(hydrated.get("metadata"))
    payload = _decode_jsonish(hydrated.get("payload"))
    envelope = (
        payload
        if isinstance(payload, dict)
        and isinstance(payload.get("schema"), str)
        and isinstance(payload.get("trace"), dict)
        and isinstance(payload.get("payload"), dict)
        else None
    )

    schema = envelope.get("schema") if envelope else None
    if schema is None and isinstance(metadata, dict):
        schema = metadata.get("whispers:schema")

    baton_payload = envelope.get("payload") if envelope else {}
    trace = envelope.get("trace") if envelope else {}
    summary = envelope.get("summary") if envelope and isinstance(envelope.get("summary"), dict) else None

    if schema != "handoff_baton.v1":
        looks_like_legacy_handoff = hydrated.get("msg_type") == "handoff" or any(
            hydrated.get(field_name) is not None
            for field_name in (
                "baton_state",
                "baton_outcome",
                "baton_updated_at",
                "baton_delineation_text",
                "baton_linked_workspace_id",
                "baton_working_scope",
                "baton_artifact_refs",
                "baton_last_update_text",
                "baton_attested",
            )
        )
        if not looks_like_legacy_handoff:
            return None

        legacy_payload = payload if isinstance(payload, dict) else {}
        baton_payload = legacy_payload if isinstance(legacy_payload, dict) else {}
        trace = {}
        disclosure_headline = None
        disclosure_human = None
        if isinstance(legacy_payload, dict):
            disclosure_headline = legacy_payload.get("whispers:disclosure:headline")
            disclosure_human = legacy_payload.get("whispers:disclosure:summary")
        if disclosure_headline or disclosure_human:
            summary = {
                "headline": disclosure_headline or hydrated.get("subject"),
                "human": disclosure_human,
            }
        else:
            summary = None
        schema = schema or "handoff"

    hydrated["metadata"] = metadata if isinstance(metadata, dict) else hydrated.get("metadata")
    hydrated["payload"] = envelope if envelope is not None else payload
    hydrated["schema"] = schema
    hydrated["wire_mode"] = (
        envelope.get("mode") if envelope else None
    ) or (metadata.get("whispers:wireMode") if isinstance(metadata, dict) else None)
    hydrated["signal_class"] = (
        envelope.get("signal_class") if envelope else None
    ) or (metadata.get("whispers:signalClass") if isinstance(metadata, dict) else None)
    hydrated["summary"] = summary
    hydrated["summary_headline"] = summary.get("headline") if summary else None
    hydrated["summary_human"] = summary.get("human") if summary else None
    hydrated["message_id"] = (
        trace.get("message_id") if isinstance(trace, dict) else None
    ) or hydrated.get("uuid")
    hydrated["thread_id"] = trace.get("thread_id") if isinstance(trace, dict) else None
    hydrated["trace_id"] = hydrated.get("trace_id") or (trace.get("trace_id") if isinstance(trace, dict) else None)
    hydrated["workspace_id"] = (
        baton_payload.get("workspace_id")
        or hydrated.get("baton_linked_workspace_id")
        or (metadata.get("whispers:workspace_id") if isinstance(metadata, dict) else None)
    )
    hydrated["working_scope"] = baton_payload.get("working_scope") or hydrated.get("baton_working_scope") or (
        metadata.get("whispers:working_scope") if isinstance(metadata, dict) else None
    )
    hydrated["last_update_text"] = hydrated.get("baton_last_update_text")
    hydrated["outcome"] = hydrated.get("baton_outcome")
    hydrated["attested"] = hydrated.get("baton_attested")

    for field_name in (
        "objective",
        "deliverable",
        "completed",
        "remaining",
        "next_action",
        "repo_focus",
        "handoff_contract",
        "open_questions",
        "dead_ends",
        "decisions",
        "artifacts",
        "assumptions",
        "risks",
    ):
        hydrated[field_name] = baton_payload.get(field_name)

    # Ensure structural unpacking for JSONish projection fields if present
    if "baton_artifact_refs" in hydrated and isinstance(hydrated["baton_artifact_refs"], str):
        hydrated["baton_artifact_refs"] = _decode_jsonish(hydrated["baton_artifact_refs"])
    if hydrated.get("artifacts") is None and hydrated.get("baton_artifact_refs") is not None:
        hydrated["artifacts"] = hydrated.get("baton_artifact_refs")

    return hydrated


def _localize_workspace_state(payload: Optional[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
    if not payload:
        return payload

    localized = dict(payload)
    workspace = payload.get("workspace")
    if isinstance(workspace, dict):
        localized["workspace"] = _localize_record(dict(workspace), _WORKSPACE_TIMESTAMP_FIELDS)
    localized["members"] = [
        _localize_record(dict(member), _WORKSPACE_MEMBER_TIMESTAMP_FIELDS)
        for member in payload.get("members", [])
    ]
    localized["deltas"] = [
        _localize_record(dict(delta), _WORKSPACE_EVENT_TIMESTAMP_FIELDS)
        for delta in payload.get("deltas", [])
    ]
    return localized


def _extract_activity_view(record: Optional[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
    if not record:
        return None

    hydrated = dict(record)
    hydrated["refs"] = _decode_jsonish(hydrated.get("refs"))
    hydrated["artifacts"] = _decode_jsonish(hydrated.get("artifacts"))
    hydrated["state_patch"] = _decode_jsonish(hydrated.get("state_patch"))
    hydrated["workspace_name"] = hydrated.get("workspace_name") or hydrated.get("workspace_id")
    hydrated["at"] = hydrated.get("created_at")

    if hydrated.get("type") == "coordination":
        hydrated["summary"] = (
            hydrated.get("summary")
            or hydrated.get("text")
            or hydrated.get("requested_action")
            or hydrated.get("subject")
            or "Whispers reported coordination activity."
        )
        return hydrated

    state_patch = hydrated.get("state_patch") if isinstance(hydrated.get("state_patch"), dict) else {}
    delta_kind = hydrated.get("delta_kind")

    if delta_kind in {"handoff_in", "handoff_out"}:
        baton_payload = None
        handoff_summary = state_patch.get("handoff_summary") if isinstance(state_patch, dict) else None
        handoff_envelope = state_patch.get("handoff_envelope") if isinstance(state_patch, dict) else None
        if isinstance(handoff_envelope, dict):
            if isinstance(handoff_envelope.get("payload"), dict):
                baton_payload = handoff_envelope.get("payload")
            if not isinstance(handoff_summary, dict) and isinstance(handoff_envelope.get("summary"), dict):
                handoff_summary = handoff_envelope.get("summary")
            trace = handoff_envelope.get("trace")
            if isinstance(trace, dict) and trace.get("message_id"):
                hydrated["message_id"] = trace.get("message_id")
        elif isinstance(state_patch.get("handoff_payload"), dict):
            baton_payload = state_patch.get("handoff_payload")

        hydrated["type"] = "handoff"
        hydrated["sender"] = state_patch.get("handoff_sender") or hydrated.get("actor")
        hydrated["receiver"] = state_patch.get("handoff_recipient")
        if baton_payload:
            hydrated["next_action"] = baton_payload.get("next_action")
            hydrated["completed"] = baton_payload.get("completed")
        if isinstance(handoff_summary, dict):
            hydrated["summary_headline"] = handoff_summary.get("headline")
            hydrated["summary_human"] = handoff_summary.get("human")
        hydrated["summary"] = (
            hydrated.get("summary_human")
            or hydrated.get("text")
            or hydrated.get("summary_headline")
            or f"Handoff {hydrated.get('sender')} -> {hydrated.get('receiver')}"
        )
        return hydrated

    hydrated["type"] = "workspace_lifecycle" if delta_kind == "lifecycle" else "workspace_delta"
    hydrated["summary"] = hydrated.get("text") or f"{delta_kind} by {hydrated.get('actor')}"
    return hydrated


# ---------------------------------------------------------------------------
# Self-healing: HTTP server auto-start
# ---------------------------------------------------------------------------

_AUTOSTART_LOCK_PATH = whispers_path(".server-autostart-lock")
_AUTOSTART_COOLDOWN_SECONDS = 30
_PID_FILE_PATH = whispers_path("server.pid")
_AUTOSTART_WAIT_SECONDS = float(os.getenv("WHISPERS_AUTOSTART_WAIT_SECONDS", "20"))

from .process_utils import read_pid_file as _read_server_pid, is_pid_alive as _is_pid_alive


def _probe_http_server(url: str = _LIVEZ_URL, timeout: float = 1.0) -> bool:
    """Cheap liveness probe for the local HTTP server."""
    try:
        with urllib.request.urlopen(url, timeout=timeout) as resp:
            return resp.status == 200
    except Exception:
        return False


def _wait_for_http_server(wait_seconds: float = _AUTOSTART_WAIT_SECONDS) -> bool:
    """Poll the cheap liveness endpoint until the server becomes reachable."""
    deadline = time.time() + max(wait_seconds, 0)
    while time.time() < deadline:
        if _probe_http_server():
            return True
        time.sleep(0.5)
    return _probe_http_server()


def _server_process_is_booting() -> bool:
    """Return True when a live PID exists and is still within the boot grace window."""
    pid = _read_server_pid()
    if pid is None or not _is_pid_alive(pid):
        return False
    try:
        pid_file_age = time.time() - os.path.getmtime(_PID_FILE_PATH)
    except OSError:
        return False
    return pid_file_age < 30


def _kill_stale_server() -> bool:
    """Kill a server process that's alive but not responding to health checks.

    This is the fix for "old server had everything locked" — if the process
    exists but /health fails, it's hung (likely on DB locks or deadlock).
    Kill it and let auto-start spawn a fresh one.

    Safety: Only kills servers whose PID file is >30 seconds old. A freshly
    started server (still booting) gets the benefit of the doubt.
    """
    pid = _read_server_pid()
    if pid is None:
        return False
    if not _is_pid_alive(pid):
        # Process dead but PID file exists — clean up
        try:
            os.remove(_PID_FILE_PATH)
        except OSError:
            pass
        return False

    # Don't kill a server that's still booting — check PID file age
    try:
        pid_file_age = time.time() - os.path.getmtime(_PID_FILE_PATH)
        if pid_file_age < 30:
            logger.debug(
                "Server process pid=%d is young (%.0fs) — not killing, may still be booting",
                pid, pid_file_age,
            )
            return False
    except OSError:
        return False

    # Process is alive, PID file is old, but health check failed.
    # That means the server is hung. Kill it.
    logger.warning(
        "Killing hung server process (pid=%d, age=%.0fs) — health check failed but process alive",
        pid, pid_file_age,
    )
    import sys as _sys
    if _sys.platform == "win32":
        import subprocess
        try:
            subprocess.run(
                ["taskkill", "/PID", str(pid), "/F"],
                capture_output=True, timeout=5.0,
            )
        except Exception as exc:
            logger.warning("Failed to kill pid=%d: %s", pid, exc)
            return False
    else:
        import signal as _signal
        try:
            os.kill(pid, _signal.SIGTERM)
            time.sleep(2.0)
            if _is_pid_alive(pid):
                os.kill(pid, _signal.SIGKILL)
        except (OSError, ProcessLookupError):
            pass

    # Clean up PID file
    try:
        if os.path.exists(_PID_FILE_PATH):
            os.remove(_PID_FILE_PATH)
    except OSError:
        pass

    # Wait for port to free up
    time.sleep(1.0)
    return True


def _try_autostart_server() -> bool:
    """Attempt to start the Whispers HTTP server as a background process.

    Uses a file-based cooldown lock to prevent spawn storms — won't retry
    within AUTOSTART_COOLDOWN_SECONDS of the last attempt.

    If a PID file exists and the process is alive but not responding to
    health checks, the stale process is killed before starting a new one.

    Returns True if the server becomes reachable after startup, False otherwise.
    """
    import subprocess
    import sys

    # Cooldown: don't spam start attempts
    try:
        if os.path.exists(_AUTOSTART_LOCK_PATH):
            lock_age = time.time() - os.path.getmtime(_AUTOSTART_LOCK_PATH)
            if lock_age < _AUTOSTART_COOLDOWN_SECONDS:
                logger.debug(
                    "Server autostart skipped — last attempt %.0fs ago (cooldown %ds)",
                    lock_age, _AUTOSTART_COOLDOWN_SECONDS,
                )
                return False
    except OSError:
        pass

    # Server may already be back between the last failed probe and this call.
    if _probe_http_server():
        return True

    # Touch the lock file
    try:
        os.makedirs(os.path.dirname(_AUTOSTART_LOCK_PATH), exist_ok=True)
        with open(_AUTOSTART_LOCK_PATH, "w") as f:
            f.write(str(time.time()))
    except OSError:
        pass

    # If a live PID exists and is still booting, don't spawn over it.
    if _server_process_is_booting():
        logger.info(
            "Server PID exists and is still within the boot grace window — waiting up to %.0fs",
            _AUTOSTART_WAIT_SECONDS,
        )
        if _wait_for_http_server():
            logger.info("Existing HTTP server finished booting during grace wait")
            return True
        logger.warning(
            "Existing HTTP server process stayed unreachable after %.0fs grace wait",
            _AUTOSTART_WAIT_SECONDS,
        )
        return False

    # Kill hung server if PID file exists but the cheap probe already failed.
    _kill_stale_server()

    # Find the right way to start the server.
    # Priority: sys.executable (fastest cold-start) > whispers-server console script
    # The .EXE console script on Windows has a 10-15s cold-start penalty.
    server_cmd = None
    use_python_fallback = True

    python = sys.executable
    if python:
        server_cmd = [python, "-c", f"from whispers.server import start; start(port={_LOCAL_SERVER_PORT})"]
    else:
        # Fallback: console script (pip-installed)
        import shutil
        whispers_server_bin = shutil.which("whispers-server")
        if whispers_server_bin:
            server_cmd = [whispers_server_bin]
            use_python_fallback = False
        else:
            logger.warning("Server autostart failed — cannot determine how to start server")
            return False

    # Start as a background process, logging to ~/.whispers/server.log
    log_path = whispers_path("server.log")
    os.makedirs(os.path.dirname(log_path), exist_ok=True)
    logger.info("Auto-starting HTTP server: %s (log: %s)", " ".join(server_cmd), log_path)
    log_handle = None
    try:
        log_handle = open(log_path, "a", encoding="utf-8")
        if sys.platform == "win32":
            # DETACHED_PROCESS gives the child its own console-less session.
            # CREATE_NO_WINDOW alone wasn't sufficient — server crashed with DEVNULL.
            DETACHED_PROCESS = 0x00000008
            CREATE_NO_WINDOW = 0x08000000
            subprocess.Popen(
                server_cmd,
                stdin=subprocess.DEVNULL,
                stdout=log_handle,
                stderr=log_handle,
                creationflags=DETACHED_PROCESS | CREATE_NO_WINDOW,
            )
        else:
            subprocess.Popen(
                server_cmd,
                stdin=subprocess.DEVNULL,
                stdout=log_handle,
                stderr=log_handle,
                start_new_session=True,
            )
    except Exception as exc:
        logger.warning("Server autostart failed to spawn process: %s", exc)
        return False
    finally:
        # Close the parent's copy — the child inherited its own fd.
        # Not closing leaks a file handle and prevents log rotation on Windows.
        if log_handle is not None:
            log_handle.close()

    if _wait_for_http_server():
        logger.info("HTTP server auto-started successfully")
        return True

    logger.warning(
        "HTTP server auto-started but not yet reachable after %.0fs",
        _AUTOSTART_WAIT_SECONDS,
    )
    return False


from .storage.db import _resolve_callsign_aliases


def _load_install_state() -> Optional[Dict[str, Any]]:
    path = _install_state_path()
    if not os.path.exists(path):
        return None
    try:
        with open(path, "r", encoding="utf-8") as f:
            state = json.load(f)
    except Exception as exc:
        logger.debug("[Whispers] Ignoring unreadable install manifest at %s: %s", path, exc)
        return None
    return state if isinstance(state, dict) else None


def _deployment_mode_from_manifest(agent_name: str) -> Optional[str]:
    state = _load_install_state()
    if not state:
        return None

    for target in state.get("targets", {}).values():
        if not isinstance(target, dict):
            continue
        entry_intent = target.get("entry_intent") or {}
        configured_identity = entry_intent.get("identity") or target.get("default_agent")
        if configured_identity != agent_name:
            continue
        transport = entry_intent.get("transport") or target.get("transport")
        if transport == "http":
            return "standalone"
        if transport == "stdio":
            return "embedded"
    return None


def _runtime_deployment_mode() -> Optional[str]:
    mode = os.getenv(_DEPLOYMENT_MODE_ENV, "").strip().lower()
    if mode in {"standalone", "embedded"}:
        return mode
    return None


def _deployment_mode_from_server(db_path: str) -> Optional[str]:
    try:
        with urllib.request.urlopen(_READYZ_URL, timeout=1.0) as resp:
            payload = json.loads(resp.read())
    except Exception:
        return None

    if not isinstance(payload, dict):
        return None

    server_db_path = payload.get("db_path")
    if server_db_path and resolve_path(server_db_path) != resolve_path(db_path):
        return None

    mode = str(payload.get("deployment_mode") or "").lower()
    if mode in {"standalone", "embedded"}:
        return mode
    if payload:
        return "standalone"
    return None


class WhispersClient:
    """The main DX SDK for interacting with Whispers."""

    def __init__(self, agent_name: Optional[str], db_path: Optional[str] = None, read_only: bool = False,
                 agent_type: str = "script", model_id: Optional[str] = None,
                 display_name: Optional[str] = None, server: Optional[str] = None,
                 token: Optional[str] = None, profile: Optional[str] = None,
                 session_kind: Optional[str] = None, agent_tier: str = "full",
                 max_receive_rate: Optional[int] = None,
                 jolt_host_kind: Optional[str] = None,
                 jolt_adapter_kind: Optional[str] = None,
                 jolt_can_notify: Optional[bool] = None,
                 jolt_can_stage_context: Optional[bool] = None,
                 jolt_can_trigger_inference: Optional[bool] = None,
                 jolt_autonomous_inference_enabled: Optional[bool] = None,
                 jolt_max_inferences_per_hour: Optional[int] = None,
                 jolt_inferences_used_last_hour: Optional[int] = None,
                 jolt_cooldown_seconds: Optional[int] = None,
                 jolt_seconds_since_last_inference: Optional[int] = None,
                 assume_http_server_reachable: bool = False):
        self.remote_server: Optional[str] = None
        self.remote_token: Optional[str] = None
        self.remote_profile: Optional[str] = profile
        self.remote_session: Optional[Dict[str, Any]] = None
        self.remote_policy: Dict[str, Any] = {}
        self.remote_capabilities: Dict[str, Any] = {}

        if profile:
            profiles = _load_json_store(_profiles_path()).get("profiles", {})
            credentials = _load_json_store(_credentials_path()).get("profiles", {})
            profile_entry = profiles.get(profile, {})
            credential_entry = credentials.get(profile, {})
            if not server:
                server = profile_entry.get("server")
            if not token:
                token = credential_entry.get("token")
            if not agent_name:
                agent_name = credential_entry.get("agent_name") or profile_entry.get("agent_name")

        if not agent_name:
            raise ValueError("agent_name is required")

        self.agent_name = agent_name
        self.agent_type = agent_type
        self.agent_tier = agent_tier
        self.max_receive_rate = max_receive_rate
        self.jolt_host_kind = jolt_host_kind
        self.jolt_adapter_kind = jolt_adapter_kind
        self.jolt_can_notify = jolt_can_notify
        self.jolt_can_stage_context = jolt_can_stage_context
        self.jolt_can_trigger_inference = jolt_can_trigger_inference
        self.jolt_autonomous_inference_enabled = jolt_autonomous_inference_enabled
        self.jolt_max_inferences_per_hour = jolt_max_inferences_per_hour
        self.jolt_inferences_used_last_hour = jolt_inferences_used_last_hour
        self.jolt_cooldown_seconds = jolt_cooldown_seconds
        self.jolt_seconds_since_last_inference = jolt_seconds_since_last_inference
        self.read_only = read_only
        self.assume_http_server_reachable = assume_http_server_reachable
        self.process_id = os.getpid()
        self._session_kind_explicit = session_kind is not None
        self.session_kind = session_kind or (
            "infrastructure"
            if agent_type == "infrastructure"
            else "mcp_bridge"
            if agent_type == "mcp_server"
            else "local_listener"
            if agent_type == "script"
            else "local_client"
        )
        if server and session_kind is None:
            self.session_kind = "remote_http"
        # MCP server sessions are process-lifetime — use a long lease.
        # Scripts and other short-lived clients use a shorter lease.
        # The lease renews on every API call; ghost reaper handles crashed processes.
        self._lease_seconds = _MCP_SESSION_LEASE_SECONDS if agent_type == "mcp_server" else _LOCAL_SESSION_LEASE_SECONDS

        if server:
            self.remote_server = server.rstrip("/")
            self.remote_token = token
            self.db_path = None
            self.db = None
            self.dispatcher = None
            self.registry = None
            self.WhispersRateLimitError = WhispersRateLimitError
            self.WhispersDBError = WhispersDBError
            self.session_id = None
            self._session_started_at = utc_now()
            self._remote_connect(
                agent_type=agent_type,
                model_id=model_id,
                display_name=display_name,
                agent_tier=agent_tier,
                max_receive_rate=max_receive_rate,
            )
            return

        # DB path resolution: explicit > env > canonical. Never CWD.
        canonical = whispers_path("whispers.db")
        env_path = os.getenv("WHISPERS_DB_PATH")

        if db_path:
            self.db_path = db_path
        elif env_path:
            self.db_path = env_path
        else:
            os.makedirs(os.path.dirname(canonical), exist_ok=True)
            self.db_path = canonical

        self.db = WhispersDB(self.db_path, read_only=self.read_only)
        self.dispatcher = Dispatcher(self.db)

        from .registry import AgentRegistry
        self.registry = AgentRegistry(self.db)
        self.WhispersRateLimitError = WhispersRateLimitError
        self.WhispersDBError = WhispersDBError

        if read_only:
            # Read-only mode: no registration, no heartbeat, no mutation
            self.session_id = None
            self._session_started_at = utc_now()
            return

        # Auto-register on init if not exists, with real metadata
        if not self.registry.get_agent_by_callsign(self.agent_name):
            self.registry.register(self.agent_name, agent_type=agent_type,
                                   model_id=model_id, display_name=display_name,
                                   agent_tier=agent_tier, max_receive_rate=max_receive_rate)
        elif model_id or display_name or agent_tier != "full" or max_receive_rate is not None:
            # Update metadata on existing agent if new info provided
            self.registry.register(self.agent_name, agent_type=agent_type,
                                   model_id=model_id, display_name=display_name,
                                   agent_tier=agent_tier, max_receive_rate=max_receive_rate)

        # Fresh session ID invalidates any ghost presence from crashed sessions
        self.session_id = str(uuid.uuid4())
        self._session_started_at = utc_now()
        self._touch_heartbeat()
        if self.agent_type == "mcp_server":
            self._seed_mcp_startup_presence()

    def _session_capability_bundle(self) -> Dict[str, Any]:
        jolt_payload: Dict[str, Any] = {
            "host_kind": self.jolt_host_kind or self.session_kind,
        }
        if self.jolt_adapter_kind:
            jolt_payload["adapter"] = {"kind": self.jolt_adapter_kind}
        optional_jolt_fields = {
            "can_notify": self.jolt_can_notify,
            "can_stage_context": self.jolt_can_stage_context,
            "can_trigger_inference": self.jolt_can_trigger_inference,
            "autonomous_inference_enabled": self.jolt_autonomous_inference_enabled,
            "max_inferences_per_hour": self.jolt_max_inferences_per_hour,
            "inferences_used_last_hour": self.jolt_inferences_used_last_hour,
            "cooldown_seconds": self.jolt_cooldown_seconds,
            "seconds_since_last_inference": self.jolt_seconds_since_last_inference,
        }
        for key, value in optional_jolt_fields.items():
            if value is not None:
                jolt_payload[key] = value
        jolt_payload["adapter"] = jolt_adapter_from_dict(
            _derive_wake_model(
                session_kinds=_normalize_session_kind_list([self.session_kind]),
                agent_type=self.agent_type,
            ),
            {"jolt": jolt_payload},
        ).to_dict()
        return {"jolt": jolt_payload}

    def _current_jolt_host_capabilities(
        self,
        wake_model: str | None,
        session_capabilities: Optional[Dict[str, Any]] = None,
    ):
        return host_wake_capabilities_from_dict(wake_model, session_capabilities or self._session_capability_bundle())

    def _current_jolt_adapter(
        self,
        wake_model: str | None,
        session_capabilities: Optional[Dict[str, Any]] = None,
    ):
        return jolt_adapter_from_dict(wake_model, session_capabilities or self._session_capability_bundle())

    def _current_jolt_budget(self, session_capabilities: Optional[Dict[str, Any]] = None):
        return jolt_budget_from_dict(session_capabilities or self._session_capability_bundle())

    def _status_session_snapshot(
        self,
        *,
        conn=None,
    ) -> Dict[str, Any]:
        if self.session_id and not self.read_only:
            return {
                "session_id": self.session_id,
                "session_kind": self.session_kind,
                "capabilities": self._session_capability_bundle(),
            }

        owns_conn = conn is None
        active_conn = conn or self.db.get_connection()
        try:
            row = active_conn.execute(
                """
                SELECT session_id, session_kind, metadata
                FROM agent_sessions
                WHERE agent_name = ?
                  AND lease_expires_at >= CURRENT_TIMESTAMP
                ORDER BY
                    CASE WHEN session_id = ? THEN 0 ELSE 1 END,
                    last_seen_at DESC,
                    created_at DESC
                LIMIT 1
                """,
                (self.agent_name, self.session_id or ""),
            ).fetchone()
            if not row:
                return {}

            capabilities = _session_capabilities_from_metadata(row["metadata"])
            return {
                "session_id": row["session_id"],
                "session_kind": row["session_kind"],
                "capabilities": capabilities,
            }
        finally:
            if owns_conn:
                active_conn.close()

    def _persist_remote_profile(self) -> None:
        if not self.remote_profile or not self.remote_server or not self.remote_token:
            return

        profiles = _load_json_store(_profiles_path())
        credentials = _load_json_store(_credentials_path())
        profiles.setdefault("profiles", {})
        credentials.setdefault("profiles", {})

        profiles["profiles"][self.remote_profile] = {
            "server": self.remote_server,
            "agent_name": self.agent_name,
            "session": self.remote_session or {},
            "capabilities": self.remote_capabilities,
            "policy": self.remote_policy,
        }
        credentials["profiles"][self.remote_profile] = {
            "agent_name": self.agent_name,
            "token": self.remote_token,
        }
        _write_json_store(_profiles_path(), profiles)
        _write_json_store(_credentials_path(), credentials)

    def _clear_remote_profile_credentials(self) -> None:
        if not self.remote_profile:
            return

        profiles = _load_json_store(_profiles_path())
        credentials = _load_json_store(_credentials_path())
        profiles.setdefault("profiles", {})
        credentials.setdefault("profiles", {})

        existing_profile = profiles["profiles"].get(self.remote_profile, {})
        profiles["profiles"][self.remote_profile] = {
            "server": self.remote_server or existing_profile.get("server"),
            "agent_name": self.agent_name,
            "session": {},
            "capabilities": self.remote_capabilities,
            "policy": self.remote_policy,
        }
        credentials["profiles"][self.remote_profile] = {
            "agent_name": self.agent_name,
            "token": "",
        }
        _write_json_store(_profiles_path(), profiles)
        _write_json_store(_credentials_path(), credentials)

    def _invalidate_remote_auth_state(self) -> None:
        self.remote_token = None
        self.remote_session = None
        self.session_id = None
        self._clear_remote_profile_credentials()

    def _remote_request(
        self,
        path: str,
        method: str = "GET",
        payload: Optional[Dict[str, Any]] = None,
        query: Optional[Dict[str, Any]] = None,
        include_token: bool = True,
        retry_missing_session: bool = True,
    ) -> Any:
        if not self.remote_server:
            raise WhispersException("Remote server is not configured.")

        # Manually join to avoid urljoin parsing things like "message:send" as custom schemes
        url = self.remote_server.rstrip("/") + "/" + path.lstrip("/")
        if query:
            encoded = urllib.parse.urlencode(
                {k: v for k, v in query.items() if v is not None},
                doseq=True,
            )
            if encoded:
                url = f"{url}?{encoded}"

        headers = {"Content-Type": "application/json", "A2A-Version": "1.0"}
        if include_token and self.remote_token:
            headers["Authorization"] = f"Bearer {self.remote_token}"

        request = urllib.request.Request(
            url,
            data=json.dumps(payload).encode("utf-8") if payload is not None else None,
            headers=headers,
            method=method,
        )
        try:
            with urllib.request.urlopen(request, timeout=10) as resp:
                if resp.status == 204:
                    return None
                return json.loads(resp.read())
        except (TimeoutError, ConnectionError) as e:
            raise WhispersException(f"Remote request failed: {e}") from e
        except urllib.error.HTTPError as e:
            body = e.read().decode("utf-8", errors="replace")
            parsed = None
            try:
                parsed = json.loads(body)
            except Exception:
                parsed = None

            detail = parsed.get("detail", parsed) if isinstance(parsed, dict) else body
            if e.code == 429:
                if isinstance(detail, dict):
                    message = detail.get("message") or json.dumps(detail, sort_keys=True)
                else:
                    message = detail or "Remote rate limit exceeded."
                raise self.WhispersRateLimitError(message) from e

            if isinstance(detail, dict):
                detail_text = detail.get("message") or json.dumps(detail, sort_keys=True)
            else:
                detail_text = detail

            if (
                include_token
                and self.remote_token
                and e.code == 401
                and isinstance(detail_text, str)
                and detail_text in {"Invalid or revoked token.", "Missing bearer token."}
            ):
                self._invalidate_remote_auth_state()
                raise WhispersException(
                    f"Remote authentication failed for {path}: {detail_text} "
                    "Reconnect with /connect."
                ) from e

            if (
                retry_missing_session
                and include_token
                and self.remote_token
                and path != "/connect"
                and e.code == 409
                and isinstance(detail_text, str)
                and "No active remote session" in detail_text
            ):
                self.remote_session = None
                self.session_id = None
                self._remote_connect()
                return self._remote_request(
                    path,
                    method=method,
                    payload=payload,
                    query=query,
                    include_token=include_token,
                    retry_missing_session=False,
                )
            raise WhispersException(f"Remote {method} {path} failed ({e.code}): {detail_text}") from e
        except urllib.error.URLError as e:
            raise WhispersException(f"Remote {method} {path} failed: {e.reason}") from e

    def _remote_connect(
        self,
        agent_type: Optional[str] = None,
        model_id: Optional[str] = None,
        display_name: Optional[str] = None,
        agent_tier: Optional[str] = None,
        max_receive_rate: Optional[int] = None,
    ) -> None:
        effective_agent_type = agent_type or self.agent_type
        effective_agent_tier = agent_tier or self.agent_tier
        effective_max_receive_rate = (
            self.max_receive_rate if max_receive_rate is None else max_receive_rate
        )
        payload = {
            "agent_name": self.agent_name,
            "token": self.remote_token,
            "session_kind": self.session_kind,
            "agent_type": effective_agent_type,
            "agent_tier": effective_agent_tier,
            "max_receive_rate": effective_max_receive_rate,
            "display_name": display_name,
            "client": {"name": "whispers-client", "version": model_id or "1.0"},
            "capabilities": {
                "transport": "http",
                "lease_renewal": True,
                "status": True,
                "messaging": True,
                **self._session_capability_bundle(),
            },
        }
        result = self._remote_request("/connect", method="POST", payload=payload, include_token=False)
        self.remote_token = result["token"]
        self.remote_session = result.get("session") or {}
        self.remote_policy = result.get("policy") or {}
        self.remote_capabilities = result.get("capabilities") or {}
        self.session_id = self.remote_session.get("session_id")
        self._persist_remote_profile()

    def _renew_remote_lease(self) -> None:
        if not self.remote_session or not self.remote_session.get("session_id"):
            self._remote_connect()
            return
        result = self._remote_request(
            "/lease",
            method="POST",
            payload={"session_id": self.remote_session["session_id"]},
        )
        self.remote_session = result.get("session") or self.remote_session
        self.remote_policy = result.get("policy") or self.remote_policy
        self.session_id = self.remote_session.get("session_id")
        self._persist_remote_profile()

    def _ensure_remote_session(self) -> None:
        if not self.remote_server:
            return
        if not self.remote_token or not self.remote_session:
            self._remote_connect()
            return

        lease_expiry = parse_timestamp(self.remote_session.get("lease_expires_at"))
        if not lease_expiry:
            self._remote_connect()
            return

        now = utc_now()
        if lease_expiry <= now:
            self._remote_connect()
            return
        if (lease_expiry - now).total_seconds() <= 60:
            self._renew_remote_lease()

    # --- Item 5: Synchronous + action-triggered heartbeats ---
    # No background threads. Every API call updates heartbeat_at.
    # Silent failure counters: tracked so the Console can surface them
    # without changing the resilience model (still never crash the caller).
    _silent_failure_counts: dict = None  # lazy init to avoid __init__ changes

    def _record_silent_failure(self, op: str, exc: Exception) -> None:
        """Track fire-and-forget failures for health observability."""
        if self._silent_failure_counts is None:
            self._silent_failure_counts = {}
        self._silent_failure_counts[op] = self._silent_failure_counts.get(op, 0) + 1
        count = self._silent_failure_counts[op]
        # Log at debug normally, warning every 10th failure
        if count % 10 == 1:
            logger.warning("Silent %s failure #%d: %s", op, count, exc)
        else:
            logger.debug("Silent %s failure #%d: %s", op, count, exc)

    def _touch_session(self, substantive: bool = False):
        """Update presence session. No-op for remote or read_only clients.

        Args:
            substantive: True for actions that indicate real work (send, etc.),
                         False for passive probes (status, inbox check).
        """
        if self.remote_server or self.read_only:
            return
        try:
            self.db.upsert_agent_session(
                self.agent_name,
                self.session_id,
                session_kind=self.session_kind,
                lease_seconds=self._lease_seconds,
                process_id=self.process_id,
                host_id=os.getenv("COMPUTERNAME") or os.getenv("HOSTNAME") or "local",
                metadata={
                    "source": self.session_kind,
                    "capabilities": self._session_capability_bundle(),
                },
                substantive=substantive,
            )
        except Exception as exc:
            self._record_silent_failure("heartbeat" if not substantive else "activity", exc)

    def _touch_heartbeat(self):
        """Update presence heartbeat. Called on every client API call."""
        self._touch_session(substantive=False)

    def _touch_activity(self):
        """Mark substantive local work (sends, acks, etc.)."""
        if (
            not self.remote_server
            and not self.read_only
            and self.agent_type == "script"
            and self.session_kind == "local_listener"
            and not self._session_kind_explicit
        ):
            self.session_kind = "local_client"
        self._touch_session(substantive=True)

    def _seed_mcp_startup_presence(self) -> None:
        """Seed a truthful initial posture for a newly connected MCP bridge."""
        if self.remote_server or self.read_only or self.agent_type != "mcp_server" or not self.session_id:
            return
        try:
            with self.db.get_connection() as conn:
                self.db._ensure_runtime_state_row(conn, self.agent_name, self.session_id)
                conn.execute(
                    """
                    UPDATE presence
                    SET status = 'online',
                        session_id = ?,
                        heartbeat_at = CURRENT_TIMESTAMP,
                        last_active = CURRENT_TIMESTAMP,
                        cognitive_state = 'listening',
                        intent_broadcast = 'available via mcp',
                        state_updated_at = CURRENT_TIMESTAMP
                    WHERE agent_name = ?
                    """,
                    (self.session_id, self.agent_name),
                )
                conn.execute(
                    """
                    UPDATE agent_runtime_state
                    SET readiness = ?,
                        updated_at = CURRENT_TIMESTAMP
                    WHERE session_id = ? AND agent_name = ?
                    """,
                    (DEFAULT_READINESS_STATE, self.session_id, self.agent_name),
                )
                conn.commit()
        except Exception as exc:
            self._record_silent_failure("mcp_startup_presence", exc)

    def store_blob(
        self,
        data: bytes,
        *,
        media_type: str = "application/octet-stream",
        label: str | None = None,
        workspace_id: str | None = None,
    ) -> dict:
        """Store a blob in the content-addressed blob store.

        Returns an attachment reference dict suitable for inclusion in the
        `attachments` parameter of send(). For payloads larger than 32KB,
        store as a blob and pass the reference instead of inline content.

        If workspace_id is provided, the blob is scoped to that workspace
        and only members can fetch it (unless overridden).
        """
        from .storage.blobs import BlobStore
        store = BlobStore()
        ref = store.put(data, media_type=media_type, label=label)
        if self.db and not self.read_only:
            self.db.record_blob_provenance(ref["ref"], self.agent_name, workspace_id)
        return ref

    def fetch_blob(
        self,
        ref: str,
        *,
        current_scope: str | None = None,
        source_scope: str | None = None,
        delegated_capability: bool = False,
        operator_override: bool = False,
        baton_ref: str | None = None,
    ) -> bytes | None:
        """Fetch a blob by its ref string (e.g. 'sha256:abc...').

        Enforces workspace scope: if the blob belongs to a workspace and the
        requesting agent is not a member, the fetch is blocked unless
        operator_override or delegated_capability is set.
        """
        from .storage.blobs import BlobStore
        store = BlobStore()

        # --- Scope enforcement via provenance ---
        blocked = False
        if self.db and not self.read_only:
            provenance = self.db.get_blob_provenance(ref)

            # Determine effective source scope: provenance workspace > explicit > baton
            inferred_source_scope = source_scope
            if provenance and provenance.get("workspace_id"):
                inferred_source_scope = provenance["workspace_id"]
            elif inferred_source_scope is None and baton_ref:
                inferred_source_scope = self.db.get_baton_scope(baton_ref)

            normalized_current_scope = (current_scope or "").strip() or None
            normalized_source_scope = (inferred_source_scope or "").strip() or None

            if normalized_source_scope:
                is_member = self.db.is_agent_workspace_member(self.agent_name, normalized_source_scope)
                if is_member:
                    outcome = "same_scope"
                elif operator_override:
                    outcome = "cross_scope_override"
                elif delegated_capability:
                    outcome = "cross_scope_delegated"
                else:
                    blocked = True
                    outcome = "cross_scope_blocked"
            elif normalized_current_scope:
                # Agent declared a scope but blob has none — unscoped blob, allow
                outcome = "partial_scope"
            else:
                outcome = "unscoped"

            self.db.record_security_event(
                "artifact_fetch",
                outcome,
                actor_agent=self.agent_name,
                endpoint="client.fetch_blob",
                detail={
                    "artifact_ref": ref,
                    "baton_ref": baton_ref,
                    "source_scope": normalized_source_scope,
                    "target_scope": normalized_current_scope,
                    "delegated_capability": bool(delegated_capability),
                    "operator_override": bool(operator_override),
                    "provenance_stored_by": provenance.get("stored_by") if provenance else None,
                    "blocked": blocked,
                },
            )

        if blocked:
            return None

        return store.get(ref)

    # ------------------------------------------------------------------
    # Process Runs — shared task tracking
    # ------------------------------------------------------------------

    def create_process_run(
        self,
        name: str,
        purpose: Optional[str] = None,
        workspace_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Create a process run. If no workspace_id, creates one automatically."""
        if not self.db:
            raise RuntimeError("No database connection")
        if not workspace_id:
            from .workspaces import WorkspaceManager
            wm = WorkspaceManager(self.db)
            workspace_id = wm.create_workspace(
                purpose=purpose or name,
                created_by=self.agent_name,
                name=name,
            )
            wm.join_workspace(workspace_id, self.agent_name)
        run_id = self.db.create_process_run(name, self.agent_name, workspace_id, purpose)
        return {"run_id": run_id, "workspace_id": workspace_id, "name": name}

    def add_process_task(
        self,
        run_id: str,
        subject: str,
        description: Optional[str] = None,
        blocked_by: Optional[str] = None,
    ) -> str:
        """Add a task to a process run. Returns task_id."""
        if not self.db:
            raise RuntimeError("No database connection")
        return self.db.add_process_task(run_id, subject, description, blocked_by=blocked_by)

    def assign_task(self, task_id: str, agent_name: Optional[str] = None) -> bool:
        """Assign a task. Defaults to self if no agent specified."""
        if not self.db:
            raise RuntimeError("No database connection")
        return self.db.assign_task(task_id, agent_name or self.agent_name)

    def update_task_status(
        self,
        task_id: str,
        status: str,
        baton_ref: Optional[str] = None,
    ) -> bool:
        """Update task status. Posts workspace delta if linked."""
        if not self.db:
            raise RuntimeError("No database connection")
        result = self.db.update_task_status(task_id, status, baton_ref)
        # Post delta to linked workspace
        try:
            with self.db.get_readonly_connection() as conn:
                task = conn.execute(
                    "SELECT t.*, r.workspace_id FROM process_tasks t JOIN process_runs r ON r.run_id = t.run_id WHERE t.task_id = ?",
                    (task_id,),
                ).fetchone()
            if task and task["workspace_id"]:
                from .workspaces import WorkspaceManager
                wm = WorkspaceManager(self.db)
                wm.post_delta(
                    task["workspace_id"],
                    "task_update",
                    self.agent_name,
                    text=f"Task '{task['subject']}' → {status}" + (f" (assigned to {task['assigned_to']})" if task.get("assigned_to") else ""),
                )
        except Exception:
            pass  # Delta posting is best-effort
        return result

    def get_process_run(self, run_id: str) -> Optional[Dict[str, Any]]:
        if not self.db:
            raise RuntimeError("No database connection")
        return self.db.get_process_run(run_id)

    def list_process_runs(self, status: Optional[str] = None, limit: int = 20) -> List[Dict[str, Any]]:
        if not self.db:
            raise RuntimeError("No database connection")
        return self.db.list_process_runs(status, limit)

    def get_my_tasks(self, status: Optional[str] = None) -> List[Dict[str, Any]]:
        """Get tasks assigned to this agent."""
        if not self.db:
            raise RuntimeError("No database connection")
        return self.db.get_agent_tasks(self.agent_name, status)

    def file_lease(
        self,
        paths: List[str],
        *,
        ttl_seconds: int = 3600,
        workspace_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        if self.remote_server:
            self._ensure_remote_session()
            try:
                return self._remote_request(
                    "/file-leases:acquire",
                    method="POST",
                    payload={
                        "paths": paths,
                        "ttl_seconds": ttl_seconds,
                        "workspace_id": workspace_id,
                    },
                )
            except WhispersException as exc:
                if "409" in str(exc) or "File lease conflict" in str(exc):
                    raise WhispersConflictError(str(exc)) from exc
                raise

        if not self.db:
            raise RuntimeError("No database connection")
        self._touch_activity()
        try:
            leases = self.db.acquire_file_leases(
                self.agent_name,
                paths,
                ttl_seconds=ttl_seconds,
                workspace_id=workspace_id,
            )
        except WhispersLeaseConflictError as exc:
            raise WhispersConflictError(str(exc)) from exc
        return {"agent_name": self.agent_name, "leases": leases, "total": len(leases)}

    def file_release(self, paths: Optional[List[str]] = None) -> Dict[str, Any]:
        if self.remote_server:
            self._ensure_remote_session()
            return self._remote_request(
                "/file-leases:release",
                method="POST",
                payload={"paths": paths},
            )

        if not self.db:
            raise RuntimeError("No database connection")
        released = self.db.release_file_leases(self.agent_name, paths)
        return {"agent_name": self.agent_name, "released": released}

    def list_file_leases(self, agent_name: Optional[str] = None) -> List[Dict[str, Any]]:
        if self.remote_server:
            self._ensure_remote_session()
            query = {"agent_name": agent_name} if agent_name else None
            result = self._remote_request("/file-leases", method="GET", query=query)
            return result.get("leases", [])

        if not self.db:
            raise RuntimeError("No database connection")
        return self.db.list_active_file_leases(agent_name=agent_name)

    def publish_repo_state(
        self,
        *,
        branch: Optional[str] = None,
        head_commit: Optional[str] = None,
        base_commit: Optional[str] = None,
        dirty: bool = False,
        repo_path: Optional[str] = None,
        worktree_id: Optional[str] = None,
        lane_state: str = "active",
        claimed_paths: Optional[List[str]] = None,
        workspace_id: Optional[str] = None,
        ttl_seconds: int = 3600,
    ) -> Dict[str, Any]:
        payload = {
            "branch": branch,
            "head_commit": head_commit,
            "base_commit": base_commit,
            "dirty": dirty,
            "repo_path": repo_path,
            "worktree_id": worktree_id,
            "lane_state": lane_state,
            "claimed_paths": claimed_paths,
            "workspace_id": workspace_id,
            "ttl_seconds": ttl_seconds,
        }
        if self.remote_server:
            self._ensure_remote_session()
            try:
                return self._remote_request("/repo:publish", method="POST", payload=payload)
            except WhispersException as exc:
                if "409" in str(exc) or "File lease conflict" in str(exc):
                    raise WhispersConflictError(str(exc)) from exc
                raise

        if not self.db:
            raise RuntimeError("No database connection")

        from .repo_coordination import RepoState

        state = RepoState(
            agent_name=self.agent_name,
            branch=branch,
            head_commit=head_commit,
            base_commit=base_commit,
            dirty=dirty,
            repo_path=repo_path,
            worktree_id=worktree_id,
            lane_state=lane_state,
            claimed_paths=claimed_paths,
            workspace_id=workspace_id,
        )
        try:
            overlaps = self.db.publish_repo_state(
                state,
                enforce_file_leases=True,
                ttl_seconds=ttl_seconds,
            )
        except WhispersLeaseConflictError as exc:
            raise WhispersConflictError(str(exc)) from exc

        divergence_warnings = [
            warning
            for warning in self.db.check_repo_divergence()
            if state.agent_name in {warning.agent_a, warning.agent_b}
            and warning.reason != "overlapping_claims"
        ]
        result = {"published": state.to_dict()}
        if overlaps:
            result["path_overlaps"] = [warning.to_dict() for warning in overlaps]
        if divergence_warnings:
            result["divergence_warnings"] = [warning.to_dict() for warning in divergence_warnings]
        return result

    def send(self, to: str, subject: str, body: Optional[str] = None,
             priority: str = "routine", msg_type: str = "inform",
             trace_id: Optional[str] = None, audience_scope: Optional[str] = None,
             visibility_mode: str = "normal", memory_mode: str = "thread",
             ephemeral: bool = False,
             **kwargs) -> Dict[str, str]:
        """Send a message.

        Returns ``delivery_status``: ``delivered`` for online recipients,
        ``queued`` for offline, ``dead_lettered`` for rejected.
        Pickup / read truth lives in ``message_recipients`` and outbox()."""

        workspace_id = kwargs.pop("workspace_id", None)
        raw_metadata = kwargs.pop("metadata", None)
        metadata = dict(raw_metadata) if isinstance(raw_metadata, dict) else {}
        if workspace_id and "whispers:workspace_id" not in metadata:
            metadata["whispers:workspace_id"] = workspace_id

        if self.remote_server:
            self._ensure_remote_session()
            return self._remote_request(
                "/message:send",
                method="POST",
                payload={
                    "to": to,
                    "subject": subject,
                    "body": body,
                    "priority": priority,
                    "msg_type": msg_type,
                    "trace_id": trace_id,
                    "audience_scope": audience_scope,
                    "visibility_mode": visibility_mode,
                    "memory_mode": memory_mode,
                    "ephemeral": ephemeral,
                    "workspace_id": workspace_id,
                    "metadata": metadata or None,
                    **kwargs,
                },
            )

        self._touch_activity()

        p = Priority(priority)
        m = MsgType(msg_type)

        # RBAC Check locally before dispatch
        if p == Priority.SYSTEM and not self.registry.can_send_system(self.agent_name):
            raise PermissionDeniedError(f"Agent {self.agent_name} lacks SYSTEM priority permission.")

        if ephemeral and m != MsgType.INFORM:
            raise ValueError(f"Security Policy Violation: Ephemeral delivery is restricted to INFORM messages to preserve the audit log. Attempted to send '{m.value}' ephemerally.")

        env = Envelope(
            sender=self.agent_name,
            recipient=to,
            subject=subject,
            body=body,
            priority=p,
            msg_type=m,
            trace_id=trace_id,
            audience_scope=audience_scope,
            visibility_mode=visibility_mode,
            memory_mode=memory_mode,
            ephemeral=ephemeral,
            metadata=metadata or None,
            **kwargs
        )

        with self.db.get_connection() as conn:
            cursor = conn.cursor()

            if env.idempotency_key:
                existing = self.db.get_message_by_idempotency(self.agent_name, env.idempotency_key)
                if existing:
                    existing_status = existing.get("delivery_status", "queued")
                    return {
                        "status": existing_status,
                        "delivery_status": existing_status,
                        "id": existing["uuid"],
                    }

            max_sends_per_10s = int(os.getenv("WHISPERS_MAX_SENDS_PER_10S", "50"))
            if max_sends_per_10s > 0:
                # created_at stores ISO 8601 with T and timezone (e.g. 2026-03-23T12:00:00+00:00)
                # datetime('now') returns 'YYYY-MM-DD HH:MM:SS' — format mismatch breaks comparison.
                # Use strftime + replace to normalize both sides to comparable format.
                cursor.execute(
                    """
                    SELECT count(*)
                    FROM messages
                    WHERE from_agent = ?
                      AND REPLACE(created_at, 'T', ' ') > strftime('%Y-%m-%d %H:%M:%f', 'now', '-10 seconds')
                    """,
                    (self.agent_name,),
                )
                recent_count = cursor.fetchone()[0]
                if recent_count >= max_sends_per_10s:
                    raise self.WhispersRateLimitError(
                        f"Velocity circuit breaker tripped: {recent_count}/{max_sends_per_10s} sends in 10 seconds. "
                        f"Retry after a brief pause.",
                        retry_after=3,
                    )

            # Ping-Pong Death Loop Limiter
            if env.context_id:
                cursor.execute(
                    "SELECT count(*) FROM messages WHERE from_agent=? AND context_id=? AND created_at > datetime('now', '-10 seconds')",
                    (self.agent_name, env.context_id)
                )
                if cursor.fetchone()[0] >= 1:
                    raise self.WhispersRateLimitError("Rate limit exceeded: Max 1 message per agent per thread per 10 seconds.")

            # --- Item 3: Synchronous delivery status ---
            row = cursor.execute(
                "SELECT 1 FROM agent_cards WHERE callsign = ? AND deregistered_at IS NULL",
                (to,),
            ).fetchone()
            if not row:
                delivery_status = "dead_lettered"  # Agent never registered
            elif self.db.agent_has_active_session(to, conn=conn):
                delivery_status = "delivered"
            else:
                delivery_status = "queued"

            env.metadata = env.metadata or {}
            env.metadata["_initial_delivery_status"] = delivery_status

        original_payload = None
        # accept_schemas and reply-context enforcement: when replying, check
        # that the reply's schema is allowed and any reply-specific validation
        # has the original request context it needs.
        if env.reply_to and isinstance(env.payload, dict) and env.payload.get("schema"):
            original = self.db.get_message_by_uuid(env.reply_to)
            if original:
                original_payload = original.get("payload")
                if isinstance(original_payload, str):
                    try:
                        original_payload = json.loads(original_payload)
                    except Exception:
                        original_payload = None
                if isinstance(original_payload, dict):
                    violation = check_reply_schema_constraint(original_payload, env.payload)
                    if violation:
                        raise WhispersException(violation)

        # Validate full 2ack envelopes before dispatch. Non-2ack structured
        # payloads are left alone.
        if (
            isinstance(env.payload, dict)
            and env.payload.get("wire_v") is not None
            and isinstance(env.payload.get("schema"), str)
            and isinstance(env.payload.get("trace"), dict)
            and isinstance(env.payload.get("payload"), dict)
        ):
            validation_envelope = env.payload
            if (
                isinstance(original_payload, dict)
                and env.payload.get("schema") == "decision_response.v1"
            ):
                original_request_payload = original_payload.get("payload")
                if isinstance(original_request_payload, dict):
                    validation_envelope = dict(env.payload)
                    validation_envelope["request_payload"] = original_request_payload
                    request_options = original_request_payload.get("options")
                    if isinstance(request_options, list):
                        validation_envelope["request_options"] = request_options

                    decision_validation = validate_schema(
                        env.payload.get("schema"),
                        env.payload.get("payload"),
                        envelope=validation_envelope,
                    )
                    if not decision_validation.valid:
                        problems = "; ".join(
                            f"{error.path}: {error.message}" for error in decision_validation.errors
                        )
                        raise WhispersException(f"Invalid 2ack envelope: {problems}")

            validation = validate_message(validation_envelope)
            if not validation.valid:
                problems = "; ".join(
                    f"{error.path}: {error.message}" for error in validation.errors
                )
                raise WhispersException(f"Invalid 2ack envelope: {problems}")

        reject_reason = self.dispatcher.dispatch(env)

        if reject_reason:
            return {
                "status": "dead_lettered",
                "delivery_status": "dead_lettered",
                "reason": reject_reason,
                "id": env.id
            }

        return {
            "status": delivery_status,
            "delivery_status": delivery_status,
            "id": env.id
        }

    def _latest_heartbeat_telemetry(self, agent_name: str) -> Dict[str, Any]:
        if not self.db.agent_has_active_session(agent_name):
            return {}
        with self.db.get_connection() as conn:
            row = conn.execute(
                """
                SELECT payload
                FROM messages
                WHERE from_agent = ?
                  AND to_agent = 'whispers-console'
                  AND subject = 'telemetry:heartbeat'
                ORDER BY created_at DESC
                LIMIT 1
                """,
                (agent_name,),
            ).fetchone()
        if not row:
            return {}
        payload = row["payload"]
        if isinstance(payload, str):
            try:
                payload = json.loads(payload)
            except Exception:
                return {}
        return payload if isinstance(payload, dict) else {}

    def message_size_check(
        self,
        to: str,
        *,
        subject: Optional[str] = None,
        body: Optional[str] = None,
        payload: Any | None = None,
        priority: str = "routine",
        headline: Optional[str] = None,
        summary: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Recommend a safe delivery depth and transport for a pending send."""

        if self.remote_server:
            self._ensure_remote_session()
            return self._remote_request(
                "/message:size-check",
                method="POST",
                payload={
                    "to": to,
                    "subject": subject,
                    "body": body,
                    "payload": payload,
                    "priority": priority,
                    "headline": headline,
                    "summary": summary,
                },
            )

        self._touch_activity()

        recipient_card = self.db.get_agent_card(to)
        if not recipient_card:
            raise WhispersException(f"Recipient '{to}' not found.")
        recipient_runtime = self.db.get_runtime_state(to)
        runtime_telemetry = _load_runtime_telemetry(to)
        if runtime_telemetry.get("context_load") is not None:
            recipient_runtime["context_load"] = runtime_telemetry["context_load"]
        if runtime_telemetry.get("interruptibility"):
            recipient_runtime["interruptibility"] = runtime_telemetry["interruptibility"]
        telemetry = self._latest_heartbeat_telemetry(to)
        if telemetry.get("context_load") is not None:
            recipient_runtime["context_load"] = telemetry["context_load"]
        if telemetry.get("interruptibility"):
            recipient_runtime["interruptibility"] = telemetry["interruptibility"]

        from .context_cost import ContextCostRecipient, negotiate_message_size

        result = negotiate_message_size(
            ContextCostRecipient(
                callsign=to,
                model_id=recipient_card.get("model_id"),
                context_load=recipient_runtime.get("context_load") or 0.0,
                interruptibility=recipient_runtime.get("interruptibility"),
                max_receive_rate=recipient_card.get("max_receive_rate"),
            ),
            subject=subject,
            body=body,
            payload=payload,
            priority=priority,
            headline=headline,
            summary=summary,
        )
        return result.to_dict()

    def _build_2ack_envelope(
        self,
        schema: str,
        headline: str,
        payload: Dict[str, Any],
        *,
        human_summary: Optional[str] = None,
        trace_id: Optional[str] = None,
        context_id: Optional[str] = None,
        msg_id_prefix: str = "msg",
        authority_principal: Optional[str] = None,
    ) -> tuple[Dict[str, Any], str, str, Dict[str, Any]]:
        trace_identifier = trace_id or f"{msg_id_prefix}-{uuid.uuid4().hex[:12]}"
        
        envelope = {
            "wire_v": 1,
            "schema": schema,
            "mode": "bilingual",
            "signal_class": "whispers_internal",
            "trace": {
                "message_id": f"msg-{msg_id_prefix}-{uuid.uuid4().hex[:12]}",
                "trace_id": trace_identifier,
            },
            "summary": {
                "headline": headline,
                "human": human_summary,
            },
            "payload": payload,
        }
        
        if context_id:
            envelope["trace"]["thread_id"] = context_id

        if authority_principal:
            envelope["authority"] = {"principal": authority_principal}

        validation = validate_message(envelope)
        if not validation.valid:
            problems = "; ".join(f"{error.path}: {error.message}" for error in validation.errors)
            raise WhispersException(f"Invalid {schema} envelope: {problems}")

        body = human_summary or derive_text_fallback(envelope) or headline
        metadata = {
            "whispers:schema": schema,
            "whispers:wireMode": envelope["mode"],
            "whispers:signalClass": envelope["signal_class"],
        }
        
        return envelope, trace_identifier, body, metadata

    def send_assignment(
        self,
        to: str,
        *,
        objective: str,
        deliverable: str,
        requested_action: str,
        acceptance_bar: Optional[str] = None,
        backup_pull_order: Optional[List[str]] = None,
        workspace_id: Optional[str] = None,
        subject: Optional[str] = None,
        body: Optional[str] = None,
        artifacts: Optional[List[str]] = None,
        trace_id: Optional[str] = None,
        context_id: Optional[str] = None,
        reply_to: Optional[str] = None,
        priority: str = "priority",
    ) -> Dict[str, str]:
        trace_identifier = trace_id or f"assignment-{uuid.uuid4().hex[:12]}"
        headline = subject or f"Assignment: {deliverable}"
        coordination_payload: Dict[str, Any] = {
            "kind": "assignment",
            "objective": objective,
            "deliverable": deliverable,
            "requested_action": requested_action,
        }
        if acceptance_bar:
            coordination_payload["acceptance_bar"] = acceptance_bar
        if backup_pull_order:
            coordination_payload["backup_pull_order"] = backup_pull_order
        if workspace_id:
            coordination_payload["workspace_id"] = workspace_id
        if artifacts:
            coordination_payload["artifacts"] = artifacts

        if body:
            rendered_body = body
        else:
            lines = [
                f"Assignment objective: {objective}",
                f"Deliverable: {deliverable}",
                f"Requested action: {requested_action}",
            ]
            if acceptance_bar:
                lines.append(f"Acceptance bar: {acceptance_bar}")
            if backup_pull_order:
                lines.append("Backup pull order: " + "; ".join(str(item) for item in backup_pull_order))
            if artifacts:
                lines.append("Artifacts: " + ", ".join(str(item) for item in artifacts))
            rendered_body = "\n".join(lines)

        metadata = {
            "whispers:coordination_kind": "assignment",
            "whispers:coordination_summary": objective,
            "whispers:coordination_requested_action": requested_action,
        }
        if workspace_id:
            metadata["whispers:workspace_id"] = workspace_id

        return self.send(
            to=to,
            subject=headline,
            body=rendered_body,
            priority=priority,
            msg_type="request",
            trace_id=trace_identifier,
            payload={"coordination": coordination_payload},
            context_id=context_id,
            reply_to=reply_to,
            metadata=metadata,
        )

    def request_review(
        self,
        to: str,
        *,
        artifact: str,
        question: str,
        requested_action: Optional[str] = None,
        blocking: bool = False,
        workspace_id: Optional[str] = None,
        subject: Optional[str] = None,
        body: Optional[str] = None,
        trace_id: Optional[str] = None,
        context_id: Optional[str] = None,
        reply_to: Optional[str] = None,
        priority: Optional[str] = None,
    ) -> Dict[str, str]:
        trace_identifier = trace_id or f"review-{uuid.uuid4().hex[:12]}"
        headline = subject or f"Review request: {artifact}"
        action = requested_action or "Review and reply with approval, rejection, or redirect."
        coordination_payload: Dict[str, Any] = {
            "kind": "review_request",
            "artifact": artifact,
            "question": question,
            "requested_action": action,
            "blocking": blocking,
        }
        if workspace_id:
            coordination_payload["workspace_id"] = workspace_id

        if body:
            rendered_body = body
        else:
            lines = [
                f"Artifact: {artifact}",
                f"Review question: {question}",
                f"Requested action: {action}",
            ]
            if blocking:
                lines.append("This review request is blocking the current lane.")
            rendered_body = "\n".join(lines)

        metadata = {
            "whispers:coordination_kind": "review_request",
            "whispers:coordination_summary": artifact,
            "whispers:coordination_requested_action": action,
            "whispers:coordination_blocking": bool(blocking),
        }
        if workspace_id:
            metadata["whispers:workspace_id"] = workspace_id

        effective_priority = priority or ("priority" if blocking else "routine")
        return self.send(
            to=to,
            subject=headline,
            body=rendered_body,
            priority=effective_priority,
            msg_type="request",
            trace_id=trace_identifier,
            payload={"coordination": coordination_payload},
            context_id=context_id,
            reply_to=reply_to,
            metadata=metadata,
        )

    def send_status_update(
        self,
        to: str,
        update: StatusUpdate,
        *,
        subject: str | None = None,
        human_summary: str | None = None,
        trace_id: str | None = None,
        context_id: str | None = None,
        reply_to: str | None = None,
        priority: str = "routine",
    ) -> Dict[str, str]:
        headline = subject or f"Status Update"
        envelope, trace_identifier, body, metadata = self._build_2ack_envelope(
            schema="status_update.v1",
            headline=headline,
            payload=update.to_payload(),
            human_summary=human_summary,
            trace_id=trace_id,
            context_id=context_id,
            msg_id_prefix="status",
        )
        return self.send(
            to=to,
            subject=headline,
            body=body,
            priority=priority,
            msg_type="status_update",
            trace_id=trace_identifier,
            payload=envelope,
            context_id=context_id,
            reply_to=reply_to,
            metadata=metadata,
        )

    def send_handoff(
        self,
        to: str,
        subject: str | None = None,
        *,
        objective: str,
        deliverable: str,
        completed: str | None = None,
        remaining: str | None = None,
        next_action: str | None = None,
        decisions: Optional[List[str]] = None,
        assumptions: Optional[List[str]] = None,
        open_questions: Optional[List[str]] = None,
        dead_ends: Optional[List[str]] = None,
        artifacts: Optional[List[str]] = None,
        risks: Optional[List[str]] = None,
        workspace_id: str | None = None,
        repo_focus: str | None = None,
        working_scope: str | None = None,
        handoff_contract: str | None = None,
        target_files: Optional[List[str]] = None,
        proof_bar: str | None = None,
        blast_radius: str | None = None,
        human_summary: str | None = None,
        trace_id: str | None = None,
        context_id: str | None = None,
        reply_to: str | None = None,
        priority: str = "priority",
        **legacy_kwargs: Any,
    ) -> Dict[str, str]:
        # Preserve the older ergonomic client API while routing through the
        # canonical 2ACK baton surface.
        if "context" in legacy_kwargs and repo_focus is None:
            repo_focus = legacy_kwargs.pop("context")
        for ignored_field in ("lane_state", "confidence", "conditions", "tags"):
            legacy_kwargs.pop(ignored_field, None)
        if legacy_kwargs:
            unexpected = ", ".join(sorted(legacy_kwargs))
            raise TypeError(f"Unexpected send_handoff() keyword argument(s): {unexpected}")

        baton = HandoffBaton(
            objective=objective,
            deliverable=deliverable,
            workspace_id=workspace_id,
            repo_focus=repo_focus,
            working_scope=working_scope,
            handoff_contract=handoff_contract,
            completed=completed,
            remaining=remaining,
            next_action=next_action,
            decisions=tuple(decisions or ()),
            assumptions=tuple(assumptions or ()),
            open_questions=tuple(open_questions or ()),
            dead_ends=tuple(dead_ends or ()),
            artifacts=tuple(artifacts or ()),
            risks=tuple(risks or ()),
            target_files=tuple(target_files or ()),
            proof_bar=proof_bar,
            blast_radius=blast_radius,
        )
        return self.baton_create(
            to=to,
            baton=baton,
            subject=subject,
            human_summary=human_summary,
            trace_id=trace_id,
            context_id=context_id,
            reply_to=reply_to,
            priority=priority,
        )

    def baton_create(
        self,
        to: str,
        baton: HandoffBaton,
        *,
        subject: str | None = None,
        human_summary: str | None = None,
        trace_id: str | None = None,
        context_id: str | None = None,
        reply_to: str | None = None,
        priority: str = "priority",
    ) -> Dict[str, str]:
        if to == self.agent_name:
            raise ValueError("Cannot hand off baton to yourself. Handoffs transfer work to a different agent.")
        headline = subject or f"Handoff to {to}"
        envelope, trace_identifier, body, metadata = self._build_2ack_envelope(
            schema="handoff_baton.v1",
            headline=headline,
            payload=baton.to_payload(),
            human_summary=human_summary,
            trace_id=trace_id,
            context_id=context_id,
            msg_id_prefix="handoff",
        )
        if baton.working_scope:
            metadata["whispers:working_scope"] = baton.working_scope
        return self.send(
            to=to,
            subject=headline,
            body=body,
            priority=priority,
            msg_type="handoff",
            trace_id=trace_identifier,
            payload=envelope,
            context_id=context_id,
            reply_to=reply_to,
            metadata=metadata,
        )

    def send_decision_request(
        self,
        to: str,
        request: DecisionRequest,
        *,
        subject: str | None = None,
        human_summary: str | None = None,
        trace_id: str | None = None,
        context_id: str | None = None,
        reply_to: str | None = None,
        priority: str = "priority",
    ) -> Dict[str, str]:
        headline = subject or f"Decision Request: {request.question}"
        envelope, trace_identifier, body, metadata = self._build_2ack_envelope(
            schema="decision_request.v1",
            headline=headline,
            payload=request.to_payload(),
            human_summary=human_summary,
            trace_id=trace_id,
            context_id=context_id,
            msg_id_prefix="dreq",
        )
        return self.send(
            to=to,
            subject=headline,
            body=body,
            priority=priority,
            msg_type="decision_request",
            trace_id=trace_identifier,
            payload=envelope,
            context_id=context_id,
            reply_to=reply_to,
            metadata=metadata,
        )

    def send_decision_response(
        self,
        to: str,
        response: DecisionResponse,
        *,
        subject: str | None = None,
        human_summary: str | None = None,
        trace_id: str | None = None,
        context_id: str | None = None,
        reply_to: str | None = None,
        priority: str = "priority",
    ) -> Dict[str, str]:
        headline = subject or f"Decision Response: {response.decision}"
        envelope, trace_identifier, body, metadata = self._build_2ack_envelope(
            schema="decision_response.v1",
            headline=headline,
            payload=response.to_payload(),
            human_summary=human_summary,
            trace_id=trace_id,
            context_id=context_id,
            msg_id_prefix="dres",
        )
        return self.send(
            to=to,
            subject=headline,
            body=body,
            priority=priority,
            msg_type="decision_response",
            trace_id=trace_identifier,
            payload=envelope,
            context_id=context_id,
            reply_to=reply_to,
            metadata=metadata,
        )

    def send_external_action_request(
        self,
        to: str,
        request: ExternalActionRequest,
        *,
        subject: str | None = None,
        human_summary: str | None = None,
        trace_id: str | None = None,
        context_id: str | None = None,
        reply_to: str | None = None,
        priority: str = "priority",
        consequence_scope: str | None = None,
    ) -> Dict[str, str]:
        headline = subject or f"External Action: {request.action_class}"
        auth_principal = self.agent_name if request.risk_level in ("elevated", "critical") else None

        envelope, trace_identifier, body, metadata = self._build_2ack_envelope(
            schema="external_action_request.v1",
            headline=headline,
            payload=request.to_payload(),
            human_summary=human_summary,
            trace_id=trace_id,
            context_id=context_id,
            msg_id_prefix="extact",
            authority_principal=auth_principal,
        )
        # Consequence scope flows through the envelope for dispatcher routing
        if consequence_scope:
            envelope["consequence_scope"] = consequence_scope
        return self.send(
            to=to,
            subject=headline,
            body=body,
            priority=priority,
            msg_type="external_action",
            trace_id=trace_identifier,
            payload=envelope,
            context_id=context_id,
            reply_to=reply_to,
            metadata=metadata,
            consequence_scope=consequence_scope,
        )

    def send_external_action_result(
        self,
        to: str,
        result: ExternalActionResult,
        *,
        subject: str | None = None,
        human_summary: str | None = None,
        trace_id: str | None = None,
        context_id: str | None = None,
        reply_to: str | None = None,
        priority: str = "routine",
    ) -> Dict[str, str]:
        headline = subject or f"Action Result: {result.outcome}"

        envelope, trace_identifier, body, metadata = self._build_2ack_envelope(
            schema="external_action_result.v1",
            headline=headline,
            payload=result.to_payload(),
            human_summary=human_summary,
            trace_id=trace_id,
            context_id=context_id,
            msg_id_prefix="extact-res",
        )
        return self.send(
            to=to,
            subject=headline,
            body=body,
            priority=priority,
            msg_type="external_action_result",
            trace_id=trace_identifier,
            payload=envelope,
            context_id=context_id,
            reply_to=reply_to,
            metadata=metadata,
        )
    def _get_baton_context(self, baton_ref: str, *, allow_owner: bool = False) -> Dict[str, Any]:
        if not self.db:
            raise WhispersException("Baton state requires a local database context.")

        with self.db.get_connection() as conn:
            row = conn.execute(
                """
                SELECT bp.baton_ref, bp.owner_callsign, bp.assignee_callsign, bp.state,
                       bp.linked_workspace_id, bp.working_scope, m.trace_id, m.context_id
                FROM baton_projections bp
                LEFT JOIN messages m ON m.uuid = bp.baton_ref
                WHERE bp.baton_ref = ?
                """,
                (baton_ref,),
            ).fetchone()
            if not row:
                raise WhispersException(f"Baton {baton_ref} not found.")

            baton = dict(row)
            aliases = set(_resolve_callsign_aliases(conn, self.agent_name))

        assignee = str(baton.get("assignee_callsign") or "").strip()
        owner = str(baton.get("owner_callsign") or "").strip()
        normalized_aliases = {alias.lower() for alias in aliases}
        if assignee and assignee.lower() in normalized_aliases:
            return baton
        if allow_owner and owner and owner.lower() in normalized_aliases:
            return baton
        if allow_owner:
            raise PermissionDeniedError(
                f"Baton {baton_ref} belongs to {owner or 'unknown'} -> {assignee or 'unknown'}, not {self.agent_name}."
            )
        raise PermissionDeniedError(f"Baton {baton_ref} is assigned to {assignee}, not {self.agent_name}.")
        return baton

    def _check_expected_baton_version(self, baton_ref: str, expected_version: Optional[int]) -> None:
        if expected_version is None:
            return
        if not self.db:
            raise WhispersException("Baton version checks require a local database context.")
        try:
            expected = int(expected_version)
        except (TypeError, ValueError) as exc:
            raise WhispersException("expected_version must be an integer") from exc
        current = self.db.get_baton_version(baton_ref)
        if current is None:
            raise WhispersException(f"Baton {baton_ref} not found.")
        if current != expected:
            raise WhispersConflictError(
                f"Baton has been updated since your last read (expected version {expected}, current {current}). "
                "Re-read the baton state and retry."
            )

    def _check_not_terminal(self, baton: Dict[str, Any], operation: str) -> None:
        state = baton.get("state")
        if state in {"completed", "merged", "superseded", "rejected", "expired"}:
            raise WhispersConflictError(
                f"Cannot {operation} baton {baton['baton_ref']} because it is in terminal state '{state}'."
            )

    def _baton_counterpart(self, baton: Dict[str, Any]) -> str:
        owner = str(baton.get("owner_callsign") or "").strip()
        assignee = str(baton.get("assignee_callsign") or "").strip()
        aliases = {self.agent_name.lower()}
        if self.db:
            with self.db.get_connection() as conn:
                aliases = {alias.lower() for alias in _resolve_callsign_aliases(conn, self.agent_name)}
        if owner.lower() in aliases:
            return assignee or owner
        if assignee.lower() in aliases:
            return owner or assignee
        return assignee or owner

    def baton_ack(
        self,
        baton_ref: str,
        decision: str,
        *,
        conditions: Optional[str] = None,
        reason: Optional[str] = None,
        expected_version: Optional[int] = None,
    ) -> Dict[str, str]:
        if self.remote_server:
            self._ensure_remote_session()
            return self._remote_request(
                f"/batons/{urllib.parse.quote(baton_ref)}/ack",
                method="POST",
                payload={
                    "decision": decision,
                    "conditions": conditions,
                    "reason": reason,
                    "expected_version": expected_version,
                },
            )

        self._touch_activity()
        self._check_expected_baton_version(baton_ref, expected_version)
        baton = self._get_baton_context(baton_ref)
        self._check_not_terminal(baton, "ack")
        headline = f"Baton {decision}: {baton_ref[:8]}"

        ack_obj = BatonAck(
            baton_ref=baton_ref,
            decision=decision,
            conditions=conditions,
            reason=reason,
        )

        envelope, trace_identifier, body, metadata = self._build_2ack_envelope(
            schema="baton_ack.v1",
            headline=headline,
            payload=ack_obj.to_payload(),
            human_summary=reason or conditions,
            trace_id=baton.get("trace_id") or f"baton-{baton_ref[:12]}",
            context_id=baton.get("context_id"),
            msg_id_prefix="baton-ack",
        )

        if baton.get("linked_workspace_id"):
            metadata["whispers:workspace_id"] = baton["linked_workspace_id"]
        if baton.get("working_scope"):
            metadata["whispers:working_scope"] = baton["working_scope"]

        msg_type = "reject" if decision == "rejected" else "accept"
        return self.send(
            to=str(baton.get("owner_callsign") or ""),
            subject=headline,
            body=body,
            priority="priority",
            msg_type=msg_type,
            trace_id=trace_identifier,
            payload=envelope,
            context_id=baton.get("context_id"),
            reply_to=baton_ref,
            metadata=metadata,
        )

    def baton_update(
        self,
        baton_ref: str,
        state: str,
        *,
        progress: Optional[str] = None,
        artifact_refs: Optional[List[str]] = None,
        branch: Optional[str] = None,
        head_commit: Optional[str] = None,
        expected_version: Optional[int] = None,
    ) -> Dict[str, str]:
        if self.remote_server:
            self._ensure_remote_session()
            return self._remote_request(
                f"/batons/{urllib.parse.quote(baton_ref)}/update",
                method="POST",
                payload={
                    "state": state,
                    "progress": progress,
                    "artifact_refs": artifact_refs,
                    "branch": branch,
                    "head_commit": head_commit,
                    "expected_version": expected_version,
                },
            )

        self._touch_activity()
        self._check_expected_baton_version(baton_ref, expected_version)
        baton = self._get_baton_context(baton_ref, allow_owner=True)
        self._check_not_terminal(baton, "update")
        headline = f"Baton update: {baton_ref[:8]}"

        update_obj = BatonUpdate(
            baton_ref=baton_ref,
            state=state,
            progress=progress,
            artifact_refs=tuple(artifact_refs) if artifact_refs else (),
            branch=branch,
            head_commit=head_commit,
        )

        envelope, trace_identifier, body, metadata = self._build_2ack_envelope(
            schema="baton_update.v1",
            headline=headline,
            payload=update_obj.to_payload(),
            human_summary=progress,
            trace_id=baton.get("trace_id") or f"baton-{baton_ref[:12]}",
            context_id=baton.get("context_id"),
            msg_id_prefix="baton-update",
        )

        if baton.get("linked_workspace_id"):
            metadata["whispers:workspace_id"] = baton["linked_workspace_id"]
        if baton.get("working_scope"):
            metadata["whispers:working_scope"] = baton["working_scope"]

        return self.send(
            to=self._baton_counterpart(baton),
            subject=headline,
            body=body,
            priority="priority",
            msg_type="inform",
            trace_id=trace_identifier,
            payload=envelope,
            context_id=baton.get("context_id"),
            reply_to=baton_ref,
            metadata=metadata,
        )

    def baton_close(
        self,
        baton_ref: str,
        outcome: str,
        *,
        summary: Optional[str] = None,
        artifact_refs: Optional[List[str]] = None,
        branch: Optional[str] = None,
        head_commit: Optional[str] = None,
        expected_version: Optional[int] = None,
    ) -> Dict[str, str]:
        if self.remote_server:
            self._ensure_remote_session()
            return self._remote_request(
                f"/batons/{urllib.parse.quote(baton_ref)}/close",
                method="POST",
                payload={
                    "outcome": outcome,
                    "summary": summary,
                    "artifact_refs": artifact_refs,
                    "branch": branch,
                    "head_commit": head_commit,
                    "expected_version": expected_version,
                },
            )

        self._touch_activity()
        self._check_expected_baton_version(baton_ref, expected_version)
        baton = self._get_baton_context(baton_ref, allow_owner=True)
        self._check_not_terminal(baton, "close")
        headline = f"Baton closed: {baton_ref[:8]}"

        close_obj = BatonClose(
            baton_ref=baton_ref,
            outcome=outcome,
            summary=summary,
            head_commit=head_commit,
            branch=branch,
            artifact_refs=tuple(artifact_refs) if artifact_refs else (),
        )

        envelope, trace_identifier, body, metadata = self._build_2ack_envelope(
            schema="baton_close.v1",
            headline=headline,
            payload=close_obj.to_payload(),
            human_summary=summary,
            trace_id=baton.get("trace_id") or f"baton-{baton_ref[:12]}",
            context_id=baton.get("context_id"),
            msg_id_prefix="baton-close",
        )

        if baton.get("linked_workspace_id"):
            metadata["whispers:workspace_id"] = baton["linked_workspace_id"]
        if baton.get("working_scope"):
            metadata["whispers:working_scope"] = baton["working_scope"]

        return self.send(
            to=self._baton_counterpart(baton),
            subject=headline,
            body=body,
            priority="priority",
            msg_type="inform",
            trace_id=trace_identifier,
            payload=envelope,
            context_id=baton.get("context_id"),
            reply_to=baton_ref,
            metadata=metadata,
        )

    def whoami(self) -> Optional[Dict[str, Any]]:
        if self.remote_server:
            self._ensure_remote_session()
            record = _localize_record(self._remote_request("/whoami"), _CARD_TIMESTAMP_FIELDS)
            if isinstance(record, dict):
                _annotate_participant_record(record)
            return record
        self._touch_activity()
        record = _localize_record(self.registry.get_agent_by_callsign(self.agent_name), _CARD_TIMESTAMP_FIELDS)
        if isinstance(record, dict):
            _annotate_participant_record(record)
        return record

    def handle_status(self, callsign: str) -> Dict[str, Any]:
        if self.remote_server:
            return self._remote_request(f"/handle/{urllib.parse.quote(callsign)}")

        error = validate_remote_callsign(callsign)
        with self.db.get_connection() as conn:
            agent = conn.execute(
                """
                SELECT agent_id, public_key
                FROM agent_cards
                WHERE callsign = ? AND deregistered_at IS NULL
                """,
                (callsign,),
            ).fetchone()
            active_session = self.db.agent_has_active_session(callsign, conn=conn)

        if not agent:
            if error:
                return {
                    "callsign": callsign,
                    "state": "invalid",
                    "available": False,
                    "active": False,
                    "detail": error,
                    "existing_callsign_policy": "local_registry",
                    "public_key_bound": False,
                    "public_key_fingerprint": None,
                }
            return {
                "callsign": callsign,
                "state": "available",
                "available": True,
                "active": False,
                "detail": "Callsign is available.",
                "existing_callsign_policy": "local_registry",
                "public_key_bound": False,
                "public_key_fingerprint": None,
            }

        active = bool(active_session)
        public_key = agent["public_key"]
        return {
            "callsign": callsign,
            "state": "active" if active else "claimed",
            "available": False,
            "active": active,
            "detail": "Callsign is active." if active else "Callsign is already registered.",
            "existing_callsign_policy": "local_registry",
            "public_key_bound": bool(public_key),
            "public_key_fingerprint": fingerprint_public_key(public_key),
        }

    def identity_key(self) -> Dict[str, Any]:
        if self.remote_server:
            self._ensure_remote_session()
            return self._remote_request("/identity/key")

        self._touch_activity()
        public_key = self.db.get_agent_public_key(self.agent_name)
        return {
            "agent_name": self.agent_name,
            "public_key": public_key,
            "public_key_bound": bool(public_key),
            "public_key_fingerprint": fingerprint_public_key(public_key),
        }

    def bind_identity_key(self, public_key: str, *, replace: bool = False) -> Dict[str, Any]:
        normalized_key = normalize_public_key(public_key)
        if self.remote_server:
            self._ensure_remote_session()
            return self._remote_request(
                "/identity/key",
                method="POST",
                payload={"public_key": normalized_key, "replace": replace},
            )

        self._touch_activity()
        try:
            return self.db.bind_agent_public_key(self.agent_name, normalized_key, replace=replace)
        except WhispersIdentityConflictError as exc:
            raise WhispersConflictError(str(exc)) from exc

    def rename(self, new_callsign: str, *, display_name: Optional[str] = None) -> Dict[str, Any]:
        error = validate_remote_callsign(new_callsign, allow_internal=False)
        if error:
            raise WhispersException(error)

        if self.remote_server:
            self._ensure_remote_session()
            result = self._remote_request(
                "/rename",
                method="POST",
                payload={"new_callsign": new_callsign, "display_name": display_name},
            )
            self.agent_name = result.get("agent_name", new_callsign)
            self.remote_session = result.get("session") or self.remote_session
            self.session_id = self.remote_session.get("session_id") if self.remote_session else self.session_id
            self._persist_remote_profile()
            return result

        try:
            result = self.db.rename_agent_identity(
                self.agent_name,
                new_callsign,
                display_name=display_name,
            )
        except WhispersIdentityConflictError as exc:
            raise WhispersConflictError(str(exc)) from exc

        self.agent_name = new_callsign
        return result

    def deregister(self) -> Dict[str, Any]:
        if self.remote_server:
            self._ensure_remote_session()
            agent_name = self.agent_name
            response = self._remote_request("/disconnect", method="POST", payload={}) or {}
            self.remote_session = None
            self.session_id = None
            return {
                "agent_name": agent_name,
                "mode": "remote",
                "disconnected": bool(response.get("disconnected", True)),
            }
        agent = self.whoami()
        if not agent:
            return {
                "agent_name": self.agent_name,
                "mode": "local",
                "status": "not_found",
                "cleanup": {"inbound_recipients": 0, "outbound_recipients": 0, "dead_letters_created": 0},
            }
        cleanup = self.db.dead_letter_pending_for_agent(self.agent_name, reason="agent_deregistered")
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("UPDATE agent_cards SET deregistered_at = CURRENT_TIMESTAMP WHERE agent_id = ?", (agent['agent_id'],))
            cursor.execute("DELETE FROM room_members WHERE agent_id = ?", (agent['agent_id'],))
            cursor.execute("DELETE FROM agent_runtime_state WHERE agent_name = ?", (self.agent_name,))
            self.db.release_file_leases(self.agent_name, conn=conn)
            cursor.execute("DELETE FROM agent_sessions WHERE agent_name = ?", (self.agent_name,))
            cursor.execute(
                "UPDATE presence SET status = 'offline', session_id = NULL, working_on = NULL WHERE agent_name = ?",
                (self.agent_name,),
            )
            conn.commit()
        logger.info(
            "[Whispers] Deregistered %s and dead-lettered %d pending recipient rows",
            self.agent_name,
            cleanup["inbound_recipients"] + cleanup["outbound_recipients"],
        )
        return {
            "agent_name": self.agent_name,
            "mode": "local",
            "status": "deregistered",
            "cleanup": cleanup,
        }

    def token_create(
        self,
        description: str = "remote_token",
        *,
        scopes: Optional[List[str]] = None,
        profile: Optional[str] = None,
    ) -> Dict[str, Any]:
        if self.remote_server:
            self._ensure_remote_session()
            payload: Dict[str, Any] = {"description": description}
            if scopes is not None:
                payload["scopes"] = list(scopes)
            if profile is not None:
                payload["profile"] = profile
            return self._remote_request("/token:create", method="POST", payload=payload)

        self._touch_activity()
        raw_token = self.db.issue_api_token(
            self.agent_name,
            description=description,
            scopes=list(scopes) if scopes is not None else None,
            profile=profile,
        )
        token_row = self.db.get_api_token(raw_token) or {}
        token_scopes = json.loads(token_row.get("scopes") or '["*"]')
        return {
            "agent_name": self.agent_name,
            "token": raw_token,
            "token_id": token_row.get("token_id"),
            "description": description,
            "scopes": token_scopes,
        }

    def token_revoke(self, token_value: Optional[str] = None) -> Dict[str, Any]:
        if self.remote_server:
            self._ensure_remote_session()
            target_token = token_value or self.remote_token
            if not target_token:
                raise WhispersException("Remote token revocation requires an authenticated token.")
            result = self._remote_request(
                "/token:revoke",
                method="POST",
                payload={"token": target_token},
            )
            if target_token == self.remote_token:
                self.remote_token = None
                self.remote_session = None
                self.session_id = None
                self._clear_remote_profile_credentials()
            return result

        if not token_value:
            raise WhispersException("Local token revocation requires token_value.")

        self._touch_activity()
        token_row = self.db.revoke_api_token(token_value)
        if not token_row:
            raise WhispersException("Token not found.")
        return {
            "ok": True,
            "token_id": token_row["token_id"],
            "agent_name": token_row["agent_name"],
        }

    def token_rotate(
        self,
        *,
        description: str = "rotated_remote_token",
        token_value: Optional[str] = None,
        scopes: Optional[List[str]] = None,
    ) -> Dict[str, Any]:
        if self.remote_server:
            self._ensure_remote_session()
            payload: Dict[str, Any] = {"description": description}
            if scopes is not None:
                payload["scopes"] = list(scopes)
            result = self._remote_request("/token:rotate", method="POST", payload=payload)
            self.remote_token = result.get("token", self.remote_token)
            self.remote_session = result.get("session") or self.remote_session
            self.session_id = self.remote_session.get("session_id") if self.remote_session else None
            self._persist_remote_profile()
            return result

        if not token_value:
            raise WhispersException("Local token rotation requires token_value.")

        self._touch_activity()
        token_row = self.db.get_api_token_any(token_value)
        if not token_row:
            raise WhispersException("Token not found.")

        old_scopes = json.loads(token_row.get("scopes") or '["*"]')
        new_scopes = list(scopes) if scopes is not None else old_scopes
        new_token = self.db.issue_api_token(
            token_row["agent_name"],
            description=description,
            scopes=new_scopes,
        )
        self.db.revoke_api_token(token_value)
        new_token_row = self.db.get_api_token(new_token) or {}
        return {
            "agent_name": token_row["agent_name"],
            "token": new_token,
            "token_id": new_token_row.get("token_id"),
            "description": description,
            "scopes": new_scopes,
        }

    def list_agents(self, ephemeral_state: Optional[Dict[str, Dict[str, Any]]] = None) -> List[Dict[str, Any]]:
        """Return all registered agents with online/offline status and metadata.

        Unlike status() which only shows currently-online peers, this returns
        the full agent registry — every registered agent, whether online or not.
        Each entry includes: callsign, agent_type, trust_tier, online status,
        last_seen, reception_mode, readiness, and working_on.
        """
        if self.remote_server:
            return self._remote_request("/agents")

        with self.db.get_connection() as conn:
            cursor = conn.cursor()

            has_sessions = self.db.has_table("agent_sessions", conn=conn)
            has_runtime = self.db.has_table("agent_runtime_state", conn=conn)

            if has_sessions:
                cursor.execute(
                    "SELECT ac.callsign, ac.agent_type, ac.agent_tier, ac.max_receive_rate, ac.trust_tier, ac.registered_at, "
                    "       ac.last_seen, ac.display_name, ac.description, ac.model_id, "
                    "       p.reception_mode, p.working_on, p.status AS presence_status, "
                    "       p.last_active, p.heartbeat_at, p.cognitive_state, "
                    "       CASE WHEN s.active_count > 0 THEN 1 ELSE 0 END AS is_online, "
                    "       s.session_last_seen, s.session_kinds "
                    "FROM agent_cards ac "
                    "LEFT JOIN presence p ON p.agent_name = ac.callsign "
                    "LEFT JOIN ("
                    "    SELECT agent_name, COUNT(*) AS active_count, "
                    "           MAX(last_seen_at) AS session_last_seen, "
                    "           GROUP_CONCAT(DISTINCT session_kind) AS session_kinds "
                    "    FROM agent_sessions "
                    "    WHERE lease_expires_at >= CURRENT_TIMESTAMP "
                    "    GROUP BY agent_name"
                    ") s ON s.agent_name = ac.callsign "
                    "WHERE ac.deregistered_at IS NULL "
                    "ORDER BY COALESCE(s.session_last_seen, p.last_active, ac.last_seen) DESC"
                )
            else:
                cursor.execute(
                    "SELECT ac.callsign, ac.agent_type, ac.agent_tier, ac.max_receive_rate, ac.trust_tier, ac.registered_at, "
                    "       ac.last_seen, ac.display_name, ac.description, ac.model_id, "
                    "       p.reception_mode, p.working_on, p.status AS presence_status, "
                    "       p.last_active, p.heartbeat_at, p.cognitive_state, "
                    "       CASE WHEN p.status IN ('online', 'idle') THEN 1 ELSE 0 END AS is_online, "
                    "       NULL AS session_last_seen, NULL AS session_kinds "
                    "FROM agent_cards ac "
                    "LEFT JOIN presence p ON p.agent_name = ac.callsign "
                    "WHERE ac.deregistered_at IS NULL "
                    "ORDER BY COALESCE(p.last_active, ac.last_seen) DESC"
                )

            rows = [dict(row) for row in cursor.fetchall()]

            if has_runtime:
                for row in rows:
                    runtime = self.db.get_runtime_state(row["callsign"], conn=conn)
                    ephemeral = ephemeral_state.get(row["callsign"], {}) if ephemeral_state else {}
                    row["readiness"] = ephemeral.get("readiness") or runtime.get("readiness", DEFAULT_READINESS_STATE)
                    for key in [
                        "current_task",
                        "interruptibility",
                        "context_load",
                        "quality_risk",
                        "progress_summary",
                        "last_progress_at",
                        "attention_state",
                        "attention_detail",
                    ]:
                        val = ephemeral.get(key)
                        if val is None:
                            val = runtime.get(key)
                        row[key] = val
                    row["basis"] = ephemeral.get("basis") or runtime.get("basis")
                    if runtime.get("updated_at") is not None:
                        row["runtime_updated_at"] = runtime.get("updated_at")
                    row["derived_active_mode"] = self.db.get_derived_active_mode(
                        row["callsign"], conn=conn, ephemeral_state=ephemeral
                    )
                    _suppress_idle_current_task(row)
            else:
                for row in rows:
                    row["readiness"] = DEFAULT_READINESS_STATE
                    row["derived_active_mode"] = (
                        "offline" if not row.get("is_online") else "ready"
                    )
            for row in rows:
                _annotate_participant_record(row)
                _annotate_wake_model(row)
                # 2ACK P1.6: Attach presence truth label
                try:
                    from .twoack import ClaimLabel, NegativeState
                    basis = str(row.get("basis") or "declared")
                    updated = row.get("runtime_updated_at")
                    if basis not in ("attested", "observed", "derived", "declared"):
                        basis = "declared"
                    label = ClaimLabel(
                        basis=basis,
                        as_of=updated,
                        confidence=1.0 if basis == "attested" else 0.8 if basis == "observed" else 0.6,
                    )
                    if updated:
                        from .time_utils import parse_timestamp
                        ts = parse_timestamp(updated)
                        if ts:
                            age = (utc_now() - ts).total_seconds()
                            if age > 300:
                                label = label.with_negative(NegativeState(
                                    state="stale",
                                    reason=f"No update for {int(age)}s",
                                    detected_by="whispers-server",
                                ))
                    # Contradiction: claims ready but derived offline
                    readiness = str(row.get("readiness") or "ready").lower()
                    active_mode = str(row.get("derived_active_mode") or "").lower()
                    if readiness == "ready" and active_mode == "offline":
                        label = label.with_negative(NegativeState(
                            state="contradicted",
                            reason="Claims ready but derived active mode is offline",
                            detected_by="whispers-server",
                        ))
                    row["presence_label"] = label.to_dict()
                except Exception:
                    pass
            tier_cursor = conn.cursor()
            tier_cursor.execute("SELECT trust_tier FROM agent_cards WHERE callsign = ?", (self.agent_name,))
            tier_row = tier_cursor.fetchone()
            viewer_tier = tier_row["trust_tier"] if tier_row else 1
            
            filtered_rows = []
            for row in rows:
                policy = self.db.get_presence_policy(row["callsign"], conn=conn)
                visible_row = apply_presence_policy_to_record(
                    row,
                    policy,
                    viewer_agent=self.agent_name,
                    viewer_tier=viewer_tier,
                    target_agent=row["callsign"],
                )
                if visible_row is not None:
                    _annotate_participant_record(visible_row)
                    _annotate_wake_model(visible_row)
                    _attach_active_session_wake_contract(visible_row, conn=conn)
                    filtered_rows.append(visible_row)

            return filtered_rows

    def wag(self, cognitive_state: str, confidence: float = 1.0, intent: str = "") -> None:
        """Broadcast cognitive telemetry. Fire-and-forget — never blocks."""
        if self.remote_server:
            self._ensure_remote_session()
            self._remote_request(
                "/wag",
                method="POST",
                payload={"state": cognitive_state, "confidence": confidence, "intent": intent},
            )
            return
        self._touch_activity()

        try:
            self.send(
                to="whispers-console",
                subject="telemetry:wag",
                msg_type="inform",
                priority="routine",
                ephemeral=True,
                payload={"state": cognitive_state, "confidence": confidence, "intent": intent}
            )
        except Exception:
            pass

    def set_mode(self, mode: str, allow_senders: Optional[List[str]] = None) -> None:
        if self.remote_server:
            self._ensure_remote_session()
            self._remote_request(
                "/mode",
                method="POST",
                payload={"mode": mode, "allow_senders": allow_senders or []},
            )
            return
        self._touch_activity()
        m = Mode(mode)
        mf = ModeFilter(allow_senders=allow_senders)
        with self.db.get_connection() as conn:
            conn.execute(
                "UPDATE presence SET reception_mode = ?, mode_filter = ?, mode_set_at = CURRENT_TIMESTAMP WHERE agent_name = ?",
                (m.value, mf.to_json(), self.agent_name)
            )
            conn.commit()

    def get_mode(self, agent: Optional[str] = None) -> Dict[str, Any]:
        """Get an agent's current reception mode."""
        target = agent or self.agent_name
        if self.remote_server:
            self._ensure_remote_session()
            return self._remote_request(f"/mode/{urllib.parse.quote(target)}")
        self._touch_heartbeat()
        with self.db.get_connection() as conn:
            row = conn.execute(
                "SELECT reception_mode, mode_filter, mode_set_at FROM presence WHERE agent_name = ?",
                (target,),
            ).fetchone()
        if not row:
            raise WhispersException(f"Agent {target} not found.")
        return dict(row)

    def set_readiness(
        self,
        readiness: str,
        current_task: Optional[str] = None,
        *,
        attention_state: Any = _RUNTIME_FIELD_UNSET,
        attention_detail: Any = _RUNTIME_FIELD_UNSET,
        basis: Optional[str] = None,
        evidence_refs: Optional[list] = None,
    ) -> Dict[str, Any]:
        normalized_readiness = str(readiness or "").strip().lower()
        if self.remote_server:
            self._ensure_remote_session()
            payload = {"readiness": readiness, "current_task": current_task}
            if attention_state is not _RUNTIME_FIELD_UNSET:
                payload["attention_state"] = attention_state
            if attention_detail is not _RUNTIME_FIELD_UNSET:
                payload["attention_detail"] = attention_detail
            if basis is not None:
                payload["basis"] = basis
            if evidence_refs is not None:
                payload["evidence_refs"] = evidence_refs
            return self._remote_request(
                "/readiness",
                method="POST",
                payload=payload,
            )

        if self.read_only:
            raise WhispersException("Cannot update readiness in read-only mode.")

        if normalized_readiness in YIELD_BLOCKING_READINESS_STATES:
            obligations = self.db.get_unresolved_baton_obligations(self.agent_name)
            blockers = yield_blocking_baton_obligations(obligations)
            if blockers:
                raise WhispersException(format_yield_blocked_message(normalized_readiness, blockers))

        self._touch_activity()
        evidence_json = json.dumps(evidence_refs) if evidence_refs else None
        return self.db.set_readiness_state(
            self.agent_name,
            self.session_id,
            readiness=readiness,
            current_task=current_task,
            attention_state=attention_state,
            attention_detail=attention_detail,
            basis=basis,
            evidence_refs=evidence_json,
        )

    def announce_available(
        self,
        offer: Optional[str] = None,
        completed_task: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Announce availability at a clean task boundary.

        Combines readiness reset + wag state + optional open-offer broadcast.
        Use when finishing a task to explicitly reopen yourself to the team.
        """
        try:
            self.set_readiness(
                "ready",
                current_task=None,
                attention_state="needs_assignment",
                attention_detail=offer or "Available for work",
            )
        except WhispersException as exc:
            raise WhispersException(f"Cannot announce availability: {exc}") from exc
        self.wag("listening", confidence=1.0, intent=offer or "available")

        result = {"readiness": "ready", "state": "listening", "offer": offer}

        if offer or completed_task:
            try:
                body_parts = []
                if completed_task:
                    body_parts.append(f"Completed: {completed_task}")
                if offer:
                    body_parts.append(f"Available: {offer}")
                self.send(
                    to="whispers-console",
                    subject="availability:open",
                    body="\n".join(body_parts),
                    msg_type="inform",
                    priority="routine",
                    ephemeral=True,
                    payload={
                        "type": "cut_point_broadcast",
                        "agent": self.agent_name,
                        "completed_task": completed_task,
                        "offer": offer,
                    },
                )
            except Exception:
                pass
        return result

    def get_runtime_state(self, agent_name: Optional[str] = None) -> Dict[str, Any]:
        target = agent_name or self.agent_name
        if self.remote_server:
            self._ensure_remote_session()
            return _localize_record(
                self._remote_request(f"/readiness/{urllib.parse.quote(target)}"),
                _MESSAGE_TIMESTAMP_FIELDS,
            )
        return _localize_record(
            self.db.get_runtime_state(target, session_id=self.session_id if target == self.agent_name else None),
            _MESSAGE_TIMESTAMP_FIELDS,
        )

    def get_presence_policy(self, agent_name: Optional[str] = None) -> Dict[str, Any]:
        target = agent_name or self.agent_name
        if self.remote_server:
            self._ensure_remote_session()
            path = "/presence-policy" if target == self.agent_name else f"/presence-policy/{urllib.parse.quote(target)}"
            return self._remote_request(path)
        self._touch_activity()
        return self.db.get_presence_policy(target)

    def set_presence_policy(self, policy: Dict[str, Any]) -> Dict[str, Any]:
        if self.remote_server:
            self._ensure_remote_session()
            return self._remote_request(
                "/presence-policy",
                method="POST",
                payload=policy,
            )
        self._touch_activity()
        return self.db.set_presence_policy(self.agent_name, policy)

    def update_watchdog(self, state: str = "ok") -> Dict[str, Any]:
        """Report an operational heartbeat separate from cognitive state."""
        if self.remote_server:
            self._ensure_remote_session()
            return self._remote_request("/watchdog", method="POST", payload={"state": state})
        
        if self.read_only:
            return {}
        
        return self.db.update_watchdog_state(self.agent_name, self.session_id, state)

    def update_cognitive_heartbeat(self, heartbeat: Dict[str, Any]) -> Dict[str, Any]:
        if self.remote_server:
            self._ensure_remote_session()
            return _localize_record(
                self._remote_request("/heartbeat", method="POST", payload=heartbeat),
                _MESSAGE_TIMESTAMP_FIELDS,
            )

        if self.read_only:
            raise WhispersException("Cannot update cognitive heartbeat in read-only mode.")

        result = _localize_record(
            self.db.update_cognitive_heartbeat(self.agent_name, self.session_id, heartbeat),
            _MESSAGE_TIMESTAMP_FIELDS,
        )

        try:
            _persist_runtime_telemetry(self.agent_name, heartbeat)
        except Exception:
            logger.debug("Failed to persist runtime telemetry for %s", self.agent_name, exc_info=True)

        try:
            self.send(
                to="whispers-console",
                subject="telemetry:heartbeat",
                msg_type="inform",
                priority="routine",
                ephemeral=True,
                payload=heartbeat
            )
        except Exception:
            pass

        return result

    def get_derived_active_mode(self, agent_name: Optional[str] = None) -> str:
        target = agent_name or self.agent_name
        if self.remote_server:
            self._ensure_remote_session()
            payload = self._remote_request(f"/active-mode/{urllib.parse.quote(target)}")
            return payload.get("derived_active_mode", "offline")
        return self.db.get_derived_active_mode(target)

    def get_presence_posture(self, target_agent: Optional[str] = None) -> Dict[str, Any]:
        """Fetch the effective presence policy for an agent. Defaults to self."""
        target = target_agent or self.agent_name
        if self.remote_server:
            self._ensure_remote_session()
            path = "/presence-policy" if target == self.agent_name else f"/presence-policy/{urllib.parse.quote(target)}"
            return self._remote_request(path)
            
        return self.db.get_presence_policy(target)

    def set_presence_posture(
        self,
        *,
        preset: Optional[str] = None,
        visibility: Optional[str] = None,
        reachability: Optional[str] = None,
        state_detail: Optional[str] = None,
        notifications: Optional[str] = None,
        idle_mode: Optional[str] = None,
        idle_timeout: Optional[int] = None,
        scope: str = "profile",
    ) -> Dict[str, Any]:
        """Update presence posture. Use scope='session' for temporary overrides."""
        payload = {"scope": scope}
        
        # Expand semantic presets
        if preset == "ghost":
            payload.update({"visibility_posture": "appear_offline", "state_detail_visibility": "none", "reachability": "direct_only", "notification_policy": "direct_only"})
            payload["idle_policy"] = {"mode": "appear_offline_after_timeout"}
        elif preset == "deep_work":
            payload.update({"visibility_posture": "visible", "state_detail_visibility": "minimal", "reachability": "priority_only", "notification_policy": "mentions_only"})
            payload["idle_policy"] = {"mode": "hide_after_timeout"}
        elif preset == "support":
            payload.update({"visibility_posture": "visible", "state_detail_visibility": "full", "reachability": "all", "notification_policy": "all"})
            payload["idle_policy"] = {"mode": "stay_visible", "timeout_seconds": None}
            
        # Explicit kwargs override presets
        if visibility:
            payload["visibility_posture"] = visibility
        if reachability:
            payload["reachability"] = reachability
        if state_detail:
            payload["state_detail_visibility"] = state_detail
        if notifications:
            payload["notification_policy"] = notifications
        if idle_mode or idle_timeout is not None:
            if "idle_policy" not in payload:
                payload["idle_policy"] = {}
            if idle_mode:
                payload["idle_policy"]["mode"] = idle_mode
            if idle_timeout is not None:
                payload["idle_policy"]["timeout_seconds"] = idle_timeout
                
        if self.remote_server:
            self._ensure_remote_session()
            return self._remote_request(
                "/presence-policy",
                method="POST",
                payload=payload,
            )
            
        if scope == "session":
            from whispers import presence_policy
            current = self.db.get_presence_policy(self.agent_name)
            new_policy = presence_policy.normalize_presence_policy(payload, base=current, agent_name=self.agent_name)
            presence_policy.set_session_override(self.agent_name, new_policy)
            return new_policy
            
        return self.db.set_presence_policy(self.agent_name, payload)

    def check_inbox(self, limit: int = 50, mark_seen: bool = True, pools: Optional[List[str]] = None, queue_class: Optional[str] = None) -> List[Dict[str, Any]]:
        """Pull-based retrieval. mark_seen=True updates read_at for read receipts."""
        if self.remote_server:
            self._ensure_remote_session()
            if self.read_only and not getattr(self, "_allow_readonly_mark_seen", False):
                mark_seen = False
            payload = self._remote_request(
                "/inbox",
                query={
                    "limit": limit,
                    "mark_seen": json.dumps(bool(mark_seen)),
                    "pools": json.dumps(pools) if pools else None,
                },
            )
            return [_localize_record(message, _MESSAGE_TIMESTAMP_FIELDS) for message in payload.get("messages", [])]

        self._touch_activity()

        # Read-only inspection should not mutate delivery or maintenance state.
        if self.read_only:
            if not getattr(self, "_allow_readonly_mark_seen", False):
                mark_seen = False
        else:
            # Prune stale state before reading
            self.db.reap_ghosts()
            self.db.expire_stale_messages()
            self.db.sweep_dead_agents()

        if not mark_seen:
            rows = self.db.peek_inbox(self.agent_name, limit=limit, pools=pools, queue_class=queue_class)
        else:
            rows = self.db.read_inbox(self.agent_name, limit=limit, pools=pools, queue_class=queue_class)

        from whispers.scope_delivery import sanitize_message_record_for_workspace_recipient

        localized_messages = []
        for row in rows:
            message = dict(row) if not isinstance(row, dict) else dict(row)
            message, _ = sanitize_message_record_for_workspace_recipient(
                self.db,
                message,
                self.agent_name,
            )
            localized_messages.append(_localize_record(message, _MESSAGE_TIMESTAMP_FIELDS))
        return localized_messages

    def acknowledge_message(self, message_uuid: str, state: str, detail: str = "") -> Dict[str, Any]:
        """Record post-read message comprehension state for the current recipient."""
        ack_state = AcknowledgmentState(state).value
        if self.remote_server:
            self._ensure_remote_session()
            payload = self._remote_request(
                "/message:ack",
                method="POST",
                payload={
                    "message_id": message_uuid,
                    "state": ack_state,
                    "detail": detail,
                },
            )
            message = payload.get("message") if isinstance(payload, dict) else None
            if not message:
                raise WhispersException("Remote acknowledgment did not return a message record.")
            return _localize_record(message, _MESSAGE_TIMESTAMP_FIELDS)

        self._touch_activity()
        acknowledged = self.db.acknowledge_message(
            message_uuid,
            self.agent_name,
            ack_state,
            detail=detail,
            acked_by=self.agent_name,
        )
        if not acknowledged:
            raise WhispersException(f"Message {message_uuid} is not pending for {self.agent_name}.")
        return _localize_record(dict(acknowledged), _MESSAGE_TIMESTAMP_FIELDS)

    def mark_done(self, message_uuid: str) -> Dict[str, Any]:
        """Mark a message thread as resolved and clear working_on status.

        Marks the entire thread (by context_id) as 'done', not just the
        single message. Also clears the agent's working_on field in presence.

        Returns dict with 'updated' count of messages marked done.
        """
        if self.remote_server:
            self._ensure_remote_session()
            return self._remote_request("/message-done", method="POST",
                                         json={"message_uuid": message_uuid})

        self._touch_activity()
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            # Find the thread via context_id
            cursor.execute("SELECT context_id FROM messages WHERE uuid = ?", (message_uuid,))
            row = cursor.fetchone()
            if not row:
                raise WhispersException(f"Message {message_uuid} not found.")

            if row['context_id']:
                cursor.execute("UPDATE messages SET status = 'done' WHERE context_id = ?",
                               (row['context_id'],))
                # Mark all recipients in thread as closed
                cursor.execute(
                    "UPDATE message_recipients SET coordination_status = 'closed' WHERE message_uuid IN (SELECT uuid FROM messages WHERE context_id = ?)",
                    (row['context_id'],))
            else:
                cursor.execute("UPDATE messages SET status = 'done' WHERE uuid = ?",
                               (message_uuid,))
                cursor.execute(
                    "UPDATE message_recipients SET coordination_status = 'closed' WHERE message_uuid = ?",
                    (message_uuid,))
            updated = cursor.rowcount

            # Clear working_on
            cursor.execute(
                "UPDATE presence SET working_on = NULL, last_active = CURRENT_TIMESTAMP WHERE agent_name = ?",
                (self.agent_name,)
            )
            conn.commit()
        return {"updated": updated, "message_uuid": message_uuid}

    def presence_who(self) -> Dict[str, Any]:
        """Get a presence snapshot: online peers and background agents."""
        if self.remote_server:
            self._ensure_remote_session()
            return self._remote_request("/presence")
        # Local: extract from status payload
        status = self.status()
        return {
            "agents": status.get("peers_online", []),
            "background_agents": status.get("background_agents", []),
        }

    def catch_up(self, limit: int = 50) -> List[Dict[str, Any]]:
        """Pull recent historical/expired messages as read-only context."""
        if self.remote_server:
            self._ensure_remote_session()
            payload = self._remote_request("/catch-up", query={"limit": limit})
            return [_localize_record(m, _MESSAGE_TIMESTAMP_FIELDS) for m in payload.get("messages", [])]
        self._touch_activity()
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            aliases = _resolve_callsign_aliases(conn, self.agent_name)
            alias_placeholders = ",".join("?" * len(aliases))
            cursor.execute(
                f"""
                SELECT m.*
                FROM messages m
                JOIN message_recipients r ON m.uuid = r.message_uuid
                WHERE r.recipient_callsign IN ({alias_placeholders})
                ORDER BY m.created_at DESC
                LIMIT ?
                """,
                aliases + [limit]
            )
            rows = cursor.fetchall()
            return [_localize_record(dict(r), _MESSAGE_TIMESTAMP_FIELDS) for r in rows]

    def listen_stream(self, cancel_event=None, abort_receiver=None):
        """Yields messages in real-time from the SSE server. Blocks indefinitely."""
        if not self.remote_server:
            raise WhispersException("Streaming is only available for remote HTTP clients.")

        self._ensure_remote_session()

        url = self.remote_server.rstrip("/") + f"/message:stream/{self.agent_name}"
        headers = {
            "Accept": "text/event-stream",
            "A2A-Version": "1.0",
        }
        if self.remote_token:
            headers["Authorization"] = f"Bearer {self.remote_token}"

        request = urllib.request.Request(url, headers=headers, method="GET")

        try:
            with urllib.request.urlopen(request, timeout=25.0) as resp:
                if abort_receiver is not None:
                    abort_receiver.clear()
                    def _force_abort():
                        try:
                            resp.close()
                        except Exception: pass
                        try:
                            import socket
                            sock = getattr(getattr(resp.fp, "raw", None), "_sock", None)
                            if sock:
                                sock.shutdown(socket.SHUT_RDWR)
                        except Exception: pass
                    abort_receiver.append(_force_abort)
                
                current_event = "message"
                for line in resp:
                    if cancel_event and cancel_event.is_set():
                        return
                    line = line.decode("utf-8")
                    if line.startswith("event: "):
                        current_event = line[7:].strip()
                    elif line.startswith("data: "):
                        data_str = line[6:].strip()
                        if data_str and data_str != "{}":
                            try:
                                payload = json.loads(data_str)
                                if current_event == "error":
                                    if isinstance(payload, dict) and payload.get("detail") == "session_revoked":
                                        self._invalidate_remote_auth_state()
                                        raise WhispersException(
                                            "Remote stream authentication failed: session revoked. "
                                            "Reconnect with /connect."
                                        )
                                    logger.warning("SSE Error Event: %s", payload)
                                else:
                                    yield _localize_record(payload, _MESSAGE_TIMESTAMP_FIELDS)
                            except json.JSONDecodeError:
                                pass
                    elif not line.strip():
                        current_event = "message"
        except (TimeoutError, ConnectionError, ValueError) as e:
            if cancel_event and cancel_event.is_set():
                return
            raise WhispersException(f"SSE stream dropped (no keepalive received): {e}") from e
        except urllib.error.HTTPError as e:
            if cancel_event and cancel_event.is_set():
                return
            if e.code == 401:
                self._invalidate_remote_auth_state()
                raise WhispersException(
                    "Remote stream authentication failed: invalid or revoked token. "
                    "Reconnect with /connect."
                ) from e
            raise WhispersException(f"SSE stream failed ({e.code}): {e.reason}") from e
        except urllib.error.URLError as e:
            if cancel_event and cancel_event.is_set():
                return
            raise WhispersException(f"SSE stream failed: {e.reason}") from e
        except Exception as e:
            if cancel_event and cancel_event.is_set():
                return
            raise

    def listen(
        self,
        *,
        poll_interval: float = 1.0,
        batch_limit: int = 50,
        max_messages: Optional[int] = None,
        reconnect_delay: float = 1.0,
        max_reconnect_delay: float = 10.0,
        on_disconnect=None,
        on_restored=None,
        cancel_event=None,
        abort_receiver=None,
    ):
        """Continuously claim inbound traffic, locally or remotely, with reconnect/backoff."""
        import random
        emitted = 0

        def _sleep_interruptible(delay: float) -> bool:
            if cancel_event:
                return cancel_event.wait(delay)
            time.sleep(delay)
            return False

        if self.remote_server:
            backoff = max(0.5, reconnect_delay)
            was_disconnected = False
            while max_messages is None or emitted < max_messages:
                if cancel_event and cancel_event.is_set():
                    return
                try:
                    for message in self.listen_stream(cancel_event=cancel_event, abort_receiver=abort_receiver):
                        if cancel_event and cancel_event.is_set():
                            return
                        if was_disconnected and on_restored:
                            on_restored()
                        was_disconnected = False
                        emitted += 1
                        yield message
                        if max_messages is not None and emitted >= max_messages:
                            return
                    backoff = max(0.5, reconnect_delay)
                except WhispersException as exc:
                    if cancel_event and cancel_event.is_set():
                        return
                    if (
                        "session_revoked" in str(exc)
                        or "Remote stream authentication failed" in str(exc)
                    ):
                        if on_disconnect:
                            on_disconnect(exc, 0)
                        raise
                    was_disconnected = True
                    if on_disconnect:
                        on_disconnect(exc, backoff)
                    logger.warning("Listener stream dropped for %s: %s", self.agent_name, exc)
                    if _sleep_interruptible(backoff * random.uniform(0.8, 1.2)):
                        return
                    backoff = min(max_reconnect_delay, max(0.5, backoff * 2))
                except Exception:
                    if cancel_event and cancel_event.is_set():
                        return
                    raise
            return

        if self.read_only:
            raise WhispersException("Persistent local listening requires a writable client.")

        interval = max(0.1, poll_interval)
        idle_interval = interval
        max_idle_interval = max(interval, max_reconnect_delay)
        lease_refresh_interval = max(5.0, min(600.0, self._lease_seconds / 2))
        watchdog_refresh_interval = max(10.0, min(600.0, self._lease_seconds / 2))
        next_lease_refresh = 0.0
        next_watchdog_refresh = 0.0
        was_disconnected = False

        while max_messages is None or emitted < max_messages:
            if cancel_event and cancel_event.is_set():
                return
            try:
                now = time.monotonic()
                if now >= next_lease_refresh:
                    self._touch_heartbeat()
                    next_lease_refresh = now + lease_refresh_interval
                if now >= next_watchdog_refresh:
                    self.update_watchdog("ok")
                    next_watchdog_refresh = now + watchdog_refresh_interval
            except Exception as exc:
                logger.debug("Activity/Watchdog update failed: %s", exc)
                was_disconnected = True
                if on_disconnect:
                    on_disconnect(exc, interval)
                if _sleep_interruptible(interval * random.uniform(0.8, 1.2)):
                    return
                continue

            try:
                if not self.db.has_pending_messages(self.agent_name):
                    if _sleep_interruptible(idle_interval * random.uniform(0.8, 1.2)):
                        return
                    idle_interval = min(max_idle_interval, max(interval, idle_interval * 2))
                    continue

                rows = self.db.deliver_inbox(self.agent_name, limit=batch_limit)
                if rows:
                    if was_disconnected and on_restored:
                        on_restored()
                    was_disconnected = False
                    self._touch_activity()
                    self.update_watchdog("ok")
                    idle_interval = interval
                    for row in rows:
                        emitted += 1
                        yield _localize_record(dict(row) if not isinstance(row, dict) else row, _MESSAGE_TIMESTAMP_FIELDS)
                        if max_messages is not None and emitted >= max_messages:
                            return
                    continue
            except Exception as exc:
                logger.debug("Message delivery query failed: %s", exc)
                was_disconnected = True
                if on_disconnect:
                    on_disconnect(exc, interval)
                if _sleep_interruptible(interval * random.uniform(0.8, 1.2)):
                    return
                continue

            if _sleep_interruptible(idle_interval * random.uniform(0.8, 1.2)):
                return
            idle_interval = min(max_idle_interval, max(interval, idle_interval * 2))

    # --- Item 6: Outbox + delivery verification ---
    def outbox(self, limit: int = 20) -> List[Dict[str, Any]]:
        """Messages you sent, with delivery_status, delivered_at, and read_at."""
        if self.remote_server:
            self._ensure_remote_session()
            payload = self._remote_request("/outbox", query={"limit": limit})
            return [_localize_record(message, _MESSAGE_TIMESTAMP_FIELDS) for message in payload.get("messages", [])]
        self._touch_activity()
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            aliases = _resolve_callsign_aliases(conn, self.agent_name)
            alias_placeholders = ",".join("?" * len(aliases))
            cursor.execute(f"""
                SELECT m.uuid, m.to_agent, m.subject, m.body, m.priority, m.msg_type,
                       m.metadata, m.created_at, COALESCE(r.delivery_status, m.delivery_status) AS delivery_status,
                       r.delivered_at, r.claimed_at, r.read_at,
                       r.ack_state, r.ack_detail, r.acked_by, r.acked_at
                FROM messages m
                LEFT JOIN message_recipients r ON m.uuid = r.message_uuid
                WHERE m.from_agent IN ({alias_placeholders})
                ORDER BY m.created_at DESC
                LIMIT ?
            """, aliases + [limit])
            results = []
            for r in cursor.fetchall():
                record = _localize_record(dict(r), _MESSAGE_TIMESTAMP_FIELDS)
                try:
                    record["reception_truth"] = ReceptionTruth.from_db_row(record).to_dict()
                except Exception:
                    pass  # degrade gracefully — outbox works without truth labels
                results.append(record)
            return results

    def list_handoffs(
        self,
        *,
        limit: int = 20,
        workspace_id: Optional[str] = None,
        unacknowledged_only: bool = False,
        include_all: Optional[bool] = None,
    ) -> List[Dict[str, Any]]:
        if self.remote_server:
            self._ensure_remote_session()
            payload = self._remote_request(
                "/handoffs",
                query={
                    "limit": limit,
                    "workspace_id": workspace_id,
                    "unacknowledged_only": unacknowledged_only,
                },
            )
            return [_localize_record(handoff, _MESSAGE_TIMESTAMP_FIELDS) for handoff in payload.get("handoffs", [])]

        self._touch_activity()
        if include_all is None:
            include_all = self.agent_name == "whispers-console"

        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            history_params: List[Any] = []
            active_params: List[Any] = list(TERMINAL_BATON_STATES)
            history_where_clause = "1 = 1"
            terminal_placeholders = ",".join("?" * len(TERMINAL_BATON_STATES))
            active_where_clause = f"bp.state NOT IN ({terminal_placeholders})"
            if not include_all:
                aliases = _resolve_callsign_aliases(conn, self.agent_name)
                alias_placeholders = ",".join("?" * len(aliases))
                history_where_clause = (
                    f"(m.from_agent IN ({alias_placeholders}) "
                    f"OR m.to_agent IN ({alias_placeholders}) "
                    f"OR COALESCE(r.recipient_callsign, m.to_agent) IN ({alias_placeholders}))"
                )
                active_where_clause = (
                    f"{active_where_clause} AND "
                    f"(bp.owner_callsign IN ({alias_placeholders}) "
                    f"OR bp.assignee_callsign IN ({alias_placeholders}))"
                )
                history_params.extend(aliases)
                history_params.extend(aliases)
                history_params.extend(aliases)
                active_params.extend(aliases)
                active_params.extend(aliases)

            active_rows = cursor.execute(
                f"""
                SELECT m.uuid, m.from_agent, m.to_agent, m.subject, m.body, m.payload,
                       m.priority, m.msg_type, m.metadata, m.created_at, m.reply_to, m.trace_id,
                       r.recipient_callsign, r.delivery_status, r.claimed_at,
                       r.read_at, r.ack_state, r.ack_detail, r.acked_by, r.acked_at,
                       bp.state AS baton_state, bp.outcome AS baton_outcome,
                       bp.updated_at AS baton_updated_at, bp.delineation_text AS baton_delineation_text,
                       bp.linked_workspace_id AS baton_linked_workspace_id,
                       bp.working_scope AS baton_working_scope,
                       bp.artifact_refs AS baton_artifact_refs, bp.last_update_text AS baton_last_update_text,
                       bp.attested AS baton_attested
                FROM baton_projections bp
                LEFT JOIN messages m ON m.uuid = bp.baton_ref
                LEFT JOIN message_recipients r ON m.uuid = r.message_uuid
                WHERE {active_where_clause}
                ORDER BY
                    CASE bp.state
                        WHEN 'offered' THEN 0
                        WHEN 'review_pending' THEN 1
                        WHEN 'blocked' THEN 2
                        WHEN 'in_progress' THEN 3
                        WHEN 'accepted' THEN 4
                        WHEN 'conditionally_accepted' THEN 5
                        ELSE 6
                    END,
                    bp.updated_at DESC,
                    m.created_at DESC
                LIMIT ?
                """,
                active_params + [max(limit * 10, 100)],
            ).fetchall()

            history_rows = cursor.execute(
                f"""
                SELECT m.uuid, m.from_agent, m.to_agent, m.subject, m.body, m.payload,
                       m.priority, m.msg_type, m.metadata, m.created_at, m.reply_to, m.trace_id,
                       r.recipient_callsign, r.delivery_status, r.claimed_at,
                       r.read_at, r.ack_state, r.ack_detail, r.acked_by, r.acked_at,
                       bp.state AS baton_state, bp.outcome AS baton_outcome,
                       bp.updated_at AS baton_updated_at, bp.delineation_text AS baton_delineation_text,
                       bp.linked_workspace_id AS baton_linked_workspace_id,
                       bp.working_scope AS baton_working_scope,
                       bp.artifact_refs AS baton_artifact_refs, bp.last_update_text AS baton_last_update_text,
                       bp.attested AS baton_attested
                FROM messages m
                LEFT JOIN message_recipients r ON m.uuid = r.message_uuid
                LEFT JOIN baton_projections bp ON m.uuid = bp.baton_ref
                WHERE {history_where_clause}
                ORDER BY m.created_at DESC
                LIMIT ?
                """,
                history_params + [max(limit * 10, 100)],
            ).fetchall()

        rows = list(active_rows) + list(history_rows)
        handoffs: List[Dict[str, Any]] = []
        seen: set[tuple[str, str | None]] = set()
        for row in rows:
            handoff = _extract_handoff_view(dict(row))
            if not handoff:
                continue
            if workspace_id and handoff.get("workspace_id") != workspace_id:
                continue

            if unacknowledged_only:
                baton_state = handoff.get("baton_state")
                # If projection engine has advanced state past 'offered', hide it.
                if baton_state and baton_state != "offered":
                    continue
                # Fallback: if projection engine is lagging (still 'offered' or None), 
                # but the underlying message has an ack_state, hide it anyway.
                if handoff.get("ack_state"):
                    continue

            key = (handoff["uuid"], handoff.get("recipient_callsign") or handoff.get("to_agent"))
            if key in seen:
                continue
            seen.add(key)
            handoffs.append(_localize_record(handoff, _MESSAGE_TIMESTAMP_FIELDS))
            if len(handoffs) >= limit:
                break
        return handoffs

    def list_batons(
        self,
        *,
        limit: int = 50,
        state: Optional[str] = None,
        workspace_id: Optional[str] = None,
        role: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        if self.remote_server:
            self._ensure_remote_session()
            payload = self._remote_request(
                "/batons",
                query={
                    "limit": limit,
                    "state": state,
                    "workspace_id": workspace_id,
                    "role": role,
                },
            )
            return [_localize_baton_record(baton) for baton in payload.get("batons", [])]

        self._touch_activity()
        normalized_role = (role or "").strip().lower() or None
        if normalized_role not in {None, "owner", "assignee"}:
            raise ValueError("role must be 'owner', 'assignee', or omitted")

        with self.db.get_connection() as conn:
            aliases = _resolve_callsign_aliases(conn, self.agent_name)
            alias_placeholders = ",".join("?" * len(aliases))
            params: List[Any] = []

            if normalized_role == "owner":
                where = [f"owner_callsign IN ({alias_placeholders})"]
                params.extend(aliases)
            elif normalized_role == "assignee":
                where = [f"assignee_callsign IN ({alias_placeholders})"]
                params.extend(aliases)
            else:
                where = [f"(owner_callsign IN ({alias_placeholders}) OR assignee_callsign IN ({alias_placeholders}))"]
                params.extend(aliases)
                params.extend(aliases)

            if state:
                where.append("state = ?")
                params.append(state)
            if workspace_id:
                where.append("linked_workspace_id = ?")
                params.append(workspace_id)

            rows = conn.execute(
                f"""
                SELECT baton_ref, owner_callsign, assignee_callsign, state, priority,
                       created_at, updated_at, expires_at, delineation_text,
                       linked_workspace_id, working_scope, artifact_refs, last_update_text, outcome
                FROM baton_projections
                WHERE {' AND '.join(where)}
                ORDER BY updated_at DESC, created_at DESC
                LIMIT ?
                """,
                params + [limit],
            ).fetchall()

        return [_localize_baton_record(dict(row)) for row in rows]

    def _workspace_event_summary(
        self,
        *,
        workspace: Dict[str, Any],
        delta: Dict[str, Any],
    ) -> str:
        workspace_label = workspace.get("name") or workspace.get("workspace_id") or "workspace"
        actor = delta.get("actor") or "system"
        delta_kind = delta.get("delta_kind") or "update"
        text = (delta.get("text") or "").strip()

        if delta_kind == "lifecycle":
            if text.startswith("joined"):
                return f"{actor} joined {workspace_label}."
            if text.startswith("left"):
                return f"{actor} {text} {workspace_label}."
            if text.startswith("closed"):
                return f"{actor} {text} {workspace_label}."
            return f"{actor} changed the lifecycle of {workspace_label}: {text or 'updated'}."

        if text:
            return text
        return f"{actor} posted a {delta_kind} update in {workspace_label}."

    def _fanout_workspace_event(
        self,
        *,
        workspace: Dict[str, Any],
        members: List[Dict[str, Any]],
        delta: Optional[Dict[str, Any]],
        include_actor: bool = False,
    ) -> None:
        if not delta:
            return

        recipients = [
            member.get("agent_name")
            for member in members
            if member.get("membership_state") == "active"
            and member.get("agent_name")
            and (include_actor or member.get("agent_name") != delta.get("actor"))
        ]
        if not recipients:
            return

        with self.db.get_readonly_connection() as conn:
            qmarks = ",".join("?" for _ in recipients)
            rows = conn.execute(
                f"SELECT agent_name, reception_mode FROM presence WHERE agent_name IN ({qmarks})",
                tuple(recipients)
            ).fetchall()
        quiet_agents = {r["agent_name"] for r in rows if r["reception_mode"] == "quiet"}

        active_recipients = [r for r in recipients if r not in quiet_agents]
        if not active_recipients:
            return

        workspace_id = workspace.get("workspace_id")
        delta_kind = delta.get("delta_kind")
        summary_human = self._workspace_event_summary(workspace=workspace, delta=delta)
        headline = f"Workspace {delta_kind}: {workspace.get('name') or workspace_id}"
        signal = {
            "wire_v": 1,
            "schema": "workspace_delta.v1",
            "mode": "bilingual",
            "signal_class": "whispers_internal",
            "trace": {
                "message_id": f"msg-workspace-{uuid.uuid4().hex[:12]}",
                "trace_id": f"workspace-{workspace_id}",
            },
            "summary": {
                "headline": headline,
                "human": summary_human,
            },
            "accept_schemas": [],
            "payload": {
                "workspace_id": workspace_id,
                "delta_kind": delta_kind,
                "text": delta.get("text"),
                "refs": delta.get("refs"),
                "artifacts": delta.get("artifacts"),
                "related_message_id": delta.get("related_message_id"),
                # These fields help receivers distinguish real workspace fanout
                # from unrelated messages that happen to mention the workspace.
                "sequence": delta.get("sequence"),
                "actor": delta.get("actor"),
                "created_at": delta.get("created_at"),
            },
        }
        validation = validate_message(signal)
        if not validation.valid:
            problems = "; ".join(f"{error.path}: {error.message}" for error in validation.errors)
            raise WhispersException(f"Invalid workspace delta envelope: {problems}")

        metadata = {
            "whispers:schema": "workspace_delta.v1",
            "whispers:wireMode": signal["mode"],
            "whispers:signalClass": signal["signal_class"],
            "whispers:workspace_id": workspace_id,
            "whispers:workspace_sequence": str(delta.get("sequence") or ""),
            "whispers:delta_kind": delta_kind,
        }
        body = derive_text_fallback(signal) or summary_human or headline

        for recipient in active_recipients:
            env = Envelope(
                sender=self.agent_name,
                recipient=recipient,
                subject=headline,
                body=body,
                priority=Priority.ROUTINE,
                msg_type=MsgType.INFORM,
                trace_id=signal["trace"]["trace_id"],
                context_id=workspace_id,
                payload=signal,
                metadata=dict(metadata),
            )
            reject_reason = self.dispatcher.dispatch(env)
            if reject_reason:
                logger.warning(
                    "Workspace fanout for %s sequence %s to %s was rejected: %s",
                    workspace_id,
                    delta.get("sequence"),
                    recipient,
                    reject_reason,
                )

    def create_workspace(
        self,
        purpose: str,
        *,
        name: Optional[str] = None,
        join_policy: str = "invite",
        linked_traces: Optional[List[str]] = None,
        primary_trace_id: Optional[str] = None,
        members: Optional[List[str]] = None,
    ) -> Dict[str, Any]:
        if self.remote_server:
            self._ensure_remote_session()
            return _localize_workspace_state(
                self._remote_request(
                    "/workspace:create",
                    method="POST",
                    payload={
                        "purpose": purpose,
                        "name": name,
                        "join_policy": join_policy,
                        "linked_traces": linked_traces,
                        "primary_trace_id": primary_trace_id,
                        "members": members,
                    },
                )
            )

        self._touch_activity()
        manager = WorkspaceManager(self.db)
        workspace_id = manager.create_workspace(
            purpose=purpose,
            created_by=self.agent_name,
            name=name,
            join_policy=join_policy,
            linked_traces=linked_traces,
            primary_trace_id=primary_trace_id,
        )
        invited_members = sorted({member for member in (members or []) if member and member != self.agent_name})
        if invited_members:
            invited_at = utc_now_iso()
            with self.db._db_op("Create workspace invites") as conn:
                conn.executemany(
                    """
                    INSERT OR REPLACE INTO workspace_invites (
                        workspace_id, agent_name, invited_by, invited_at
                    ) VALUES (?, ?, ?, ?)
                    """,
                    [(workspace_id, member, self.agent_name, invited_at) for member in invited_members],
                )
                conn.commit()
        state = manager.get_state(workspace_id)
        response = {
            "workspace_id": workspace_id,
            "workspace": state["workspace"],
            "members": state["members"],
            "deltas": state["deltas"],
            "current_sequence": state["workspace"]["last_sequence"],
            "invited_members": invited_members,
        }
        return _localize_workspace_state(response)

    def join_workspace(self, workspace_id: str, membership_role: str = "member") -> Dict[str, Any]:
        if self.remote_server:
            self._ensure_remote_session()
            return _localize_workspace_state(
                self._remote_request(
                    "/workspace:join",
                    method="POST",
                    payload={"workspace_id": workspace_id, "membership_role": membership_role},
                )
            )

        self._touch_activity()
        with self.db.get_readonly_connection() as conn:
            workspace = conn.execute(
                "SELECT created_by, join_policy FROM workspaces WHERE workspace_id = ?",
                (workspace_id,),
            ).fetchone()
            invite = conn.execute(
                """
                SELECT 1
                FROM workspace_invites
                WHERE workspace_id = ? AND agent_name = ?
                """,
                (workspace_id, self.agent_name),
            ).fetchone()
        if not workspace:
            raise WhispersDBError(f"Workspace {workspace_id} not found.")
        if (
            workspace["join_policy"] == "invite"
            and self.agent_name not in {workspace["created_by"], "whispers-console"}
            and not invite
        ):
            raise PermissionDeniedError("Invite-only workspace: you are not on the invited member list.")

        manager = WorkspaceManager(self.db)
        sequence = manager.join_workspace(workspace_id, self.agent_name, membership_role=membership_role)
        state = manager.get_state(workspace_id)
        response = {
            "workspace_id": workspace_id,
            "sequence": sequence,
            "membership_role": membership_role,
            "workspace": state["workspace"],
            "members": state["members"],
            "deltas": state["deltas"][-1:],
            "current_sequence": state["workspace"]["last_sequence"],
        }
        self._fanout_workspace_event(
            workspace=response["workspace"],
            members=response["members"],
            delta=response["deltas"][0] if response["deltas"] else None,
        )
        return _localize_workspace_state(response)

    def leave_workspace(self, workspace_id: str, reason: Optional[str] = None) -> Dict[str, Any]:
        if self.remote_server:
            self._ensure_remote_session()
            return _localize_workspace_state(
                self._remote_request(
                    "/workspace:leave",
                    method="POST",
                    payload={"workspace_id": workspace_id, "reason": reason},
                )
            )

        self._touch_activity()
        manager = WorkspaceManager(self.db)
        sequence = manager.leave_workspace(workspace_id, self.agent_name, reason=reason)
        state = manager.get_state(workspace_id)
        response = {
            "workspace_id": workspace_id,
            "sequence": sequence,
            "reason": reason,
            "workspace": state["workspace"],
            "members": state["members"],
            "deltas": state["deltas"][-1:],
            "current_sequence": state["workspace"]["last_sequence"],
        }
        self._fanout_workspace_event(
            workspace=response["workspace"],
            members=response["members"],
            delta=response["deltas"][0] if response["deltas"] else None,
        )
        return _localize_workspace_state(response)

    def close_workspace(self, workspace_id: str, reason: Optional[str] = None) -> Dict[str, Any]:
        if self.remote_server:
            self._ensure_remote_session()
            return _localize_workspace_state(
                self._remote_request(
                    "/workspace:close",
                    method="POST",
                    payload={"workspace_id": workspace_id, "reason": reason},
                )
            )

        self._touch_activity()
        with self.db.get_readonly_connection() as conn:
            workspace = conn.execute(
                "SELECT created_by FROM workspaces WHERE workspace_id = ?",
                (workspace_id,),
            ).fetchone()
        if not workspace:
            raise WhispersDBError(f"Workspace {workspace_id} not found.")
        if self.agent_name not in {workspace["created_by"], "whispers-console"}:
            raise PermissionDeniedError("Only the workspace creator or operator can close a workspace.")

        manager = WorkspaceManager(self.db)
        sequence = manager.close_workspace(workspace_id, actor=self.agent_name, reason=reason)
        state = manager.get_state(workspace_id)
        response = {
            "workspace_id": workspace_id,
            "sequence": sequence,
            "reason": reason,
            "workspace": state["workspace"],
            "members": state["members"],
            "deltas": state["deltas"][-1:],
            "current_sequence": state["workspace"]["last_sequence"],
        }
        self._fanout_workspace_event(
            workspace=response["workspace"],
            members=response["members"],
            delta=response["deltas"][0] if response["deltas"] else None,
            include_actor=True,
        )
        return _localize_workspace_state(response)

    def send_workspace_delta(
        self,
        workspace_id: str,
        delta_kind: str,
        text: Optional[str] = None,
        *,
        refs: Optional[List[str]] = None,
        artifacts: Optional[List[str]] = None,
        state_patch: Optional[Dict[str, Any]] = None,
        related_message_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        if self.remote_server:
            self._ensure_remote_session()
            return _localize_workspace_state(
                self._remote_request(
                    "/workspace:delta",
                    method="POST",
                    payload={
                        "workspace_id": workspace_id,
                        "delta_kind": delta_kind,
                        "text": text,
                        "refs": refs,
                        "artifacts": artifacts,
                        "state_patch": state_patch,
                        "related_message_id": related_message_id,
                    },
                )
            )

        self._touch_activity()
        with self.db.get_readonly_connection() as conn:
            workspace = conn.execute(
                "SELECT created_by FROM workspaces WHERE workspace_id = ?",
                (workspace_id,),
            ).fetchone()
            membership = conn.execute(
                """
                SELECT membership_role, membership_state
                FROM workspace_members
                WHERE workspace_id = ? AND agent_name = ?
                """,
                (workspace_id, self.agent_name),
            ).fetchone()

        if not workspace:
            raise WhispersDBError(f"Workspace {workspace_id} not found.")
        if not membership or membership["membership_state"] != "active":
            raise PermissionDeniedError("Join the workspace before posting a delta.")
        if membership["membership_role"] != "member":
            raise PermissionDeniedError("Observers can read workspace state but cannot post deltas.")

        manager = WorkspaceManager(self.db)
        sequence = manager.post_delta(
            workspace_id=workspace_id,
            delta_kind=delta_kind,
            actor=self.agent_name,
            text=text,
            refs=refs,
            artifacts=artifacts,
            state_patch=state_patch,
            related_message_id=related_message_id,
        )
        state = manager.get_state(workspace_id, since_sequence=max(0, sequence - 1))
        response = {
            "workspace_id": workspace_id,
            "sequence": sequence,
            "delta_kind": delta_kind,
            "workspace": state["workspace"],
            "members": state["members"],
            "deltas": state["deltas"][-1:],
            "current_sequence": state["workspace"]["last_sequence"],
        }
        self._fanout_workspace_event(
            workspace=response["workspace"],
            members=response["members"],
            delta=response["deltas"][0] if response["deltas"] else None,
        )
        return _localize_workspace_state(response)

    def workspace_state(self, workspace_id: str, since_sequence: Optional[int] = None) -> Dict[str, Any]:
        if self.remote_server:
            self._ensure_remote_session()
            return _localize_workspace_state(
                self._remote_request(
                    f"/workspace:state/{urllib.parse.quote(workspace_id)}",
                    query={"since_sequence": since_sequence},
                )
            )

        self._touch_activity()
        with self.db.get_readonly_connection() as conn:
            workspace = conn.execute(
                "SELECT created_by FROM workspaces WHERE workspace_id = ?",
                (workspace_id,),
            ).fetchone()
            membership = conn.execute(
                """
                SELECT membership_state
                FROM workspace_members
                WHERE workspace_id = ? AND agent_name = ?
                """,
                (workspace_id, self.agent_name),
            ).fetchone()

        if not workspace:
            raise WhispersDBError(f"Workspace {workspace_id} not found.")
        if self.agent_name not in {workspace["created_by"], "whispers-console"} and (
            not membership or membership["membership_state"] != "active"
        ):
            raise PermissionDeniedError("Workspace state is only visible to active members, the creator, or the operator.")

        manager = WorkspaceManager(self.db)
        state = manager.get_state(workspace_id, since_sequence=since_sequence or 0)
        deltas = state.get("deltas", [])
        limit = 100 if since_sequence is not None else 10
        truncated = len(deltas) > limit
        if since_sequence is None:
            deltas = deltas[-limit:]
        else:
            deltas = deltas[:limit]
        response = {
            "workspace": state["workspace"],
            "members": state["members"],
            "deltas": deltas,
            "current_sequence": state["workspace"]["last_sequence"],
            "returned_delta_count": len(deltas),
            "truncated": truncated,
        }
        return _localize_workspace_state(response)

    def list_workspaces(self, status: Optional[str] = "active", limit: int = 20) -> List[Dict[str, Any]]:
        if self.remote_server:
            self._ensure_remote_session()
            payload = self._remote_request("/workspaces", query={"status": status, "limit": limit})
            return [_localize_record(workspace, _WORKSPACE_TIMESTAMP_FIELDS) for workspace in payload.get("workspaces", [])]

        self._touch_activity()
        with self.db.get_readonly_connection() as conn:
            query = """
                SELECT w.workspace_id, w.name, w.purpose, w.status, w.created_by, w.created_at,
                       w.join_policy, w.linked_traces, w.primary_trace_id, w.last_delta_at, w.last_sequence,
                       w.last_sequence AS current_sequence,
                       COALESCE(SUM(CASE WHEN wm.membership_state = 'active' THEN 1 ELSE 0 END), 0) AS member_count,
                       COALESCE(SUM(CASE WHEN wm.membership_state = 'active' AND wm.membership_role = 'observer' THEN 1 ELSE 0 END), 0) AS observer_count,
                       COALESCE(w.last_delta_at, w.created_at) AS last_activity_at
                FROM workspaces w
                LEFT JOIN workspace_members wm ON wm.workspace_id = w.workspace_id
            """
            params: List[Any] = []
            if status and status != "all":
                query += " WHERE w.status = ?"
                params.append(status)
            query += """
                GROUP BY w.workspace_id
                ORDER BY COALESCE(w.last_delta_at, w.created_at) DESC, w.created_at DESC
                LIMIT ?
            """
            rows = conn.execute(query, params + [limit]).fetchall()

        workspaces: List[Dict[str, Any]] = []
        for row in rows:
            workspace = dict(row)
            workspace["linked_traces"] = _decode_jsonish(workspace.get("linked_traces"))
            workspaces.append(_localize_record(workspace, _WORKSPACE_TIMESTAMP_FIELDS))
        return workspaces

    def list_activity(
        self,
        *,
        limit: int = 50,
        workspace_id: Optional[str] = None,
        agent: Optional[str] = None,
        kinds: Optional[List[str]] = None,
    ) -> List[Dict[str, Any]]:
        if self.remote_server:
            self._ensure_remote_session()
            payload = self._remote_request(
                "/activity",
                query={
                    "limit": limit,
                    "workspace_id": workspace_id,
                    "agent": agent,
                    "kinds": ",".join(kinds) if kinds else None,
                },
            )
            return [_localize_record(event, _WORKSPACE_EVENT_TIMESTAMP_FIELDS) for event in payload.get("events", [])]

        self._touch_activity()
        normalized_kinds = [kind for kind in (kinds or []) if kind]
        coordination_kinds = {"assignment", "review_request"}
        requested_coordination_kinds = [kind for kind in normalized_kinds if kind in coordination_kinds]
        requested_workspace_kinds = [kind for kind in normalized_kinds if kind not in coordination_kinds]
        include_workspace_events = not normalized_kinds or bool(requested_workspace_kinds)
        include_coordination_events = not normalized_kinds or bool(requested_coordination_kinds)

        with self.db.get_readonly_connection() as conn:
            workspace_rows: List[Any] = []
            if include_workspace_events:
                query = """
                    SELECT w.workspace_id,
                           COALESCE(w.name, w.workspace_id) AS workspace_name,
                           w.status AS workspace_status,
                           e.sequence,
                           e.delta_kind,
                           e.actor,
                           e.created_at,
                           e.text,
                           e.refs,
                           e.artifacts,
                           e.state_patch,
                           e.related_message_id
                    FROM workspace_events e
                    JOIN workspaces w ON w.workspace_id = e.workspace_id
                    WHERE 1 = 1
                """
                params: List[Any] = []
                if workspace_id:
                    query += " AND e.workspace_id = ?"
                    params.append(workspace_id)
                if agent:
                    query += " AND e.actor = ?"
                    params.append(agent)
                if requested_workspace_kinds:
                    placeholders = ",".join("?" * len(requested_workspace_kinds))
                    query += f" AND e.delta_kind IN ({placeholders})"
                    params.extend(requested_workspace_kinds)
                query += " ORDER BY e.created_at DESC, e.sequence DESC LIMIT ?"
                workspace_rows = conn.execute(query, params + [limit]).fetchall()

            coordination_rows: List[Any] = []
            if include_coordination_events:
                coordination_query = """
                    SELECT m.uuid,
                           m.from_agent,
                           m.to_agent,
                           m.subject,
                           m.body,
                           m.payload,
                           m.priority,
                           m.status,
                           m.metadata,
                           m.created_at,
                           r.recipient_callsign,
                           r.delivery_status,
                           r.read_at,
                           r.ack_state,
                           r.ack_detail,
                           r.acked_by,
                           r.acked_at,
                           r.coordination_status,
                           r.rowid AS recipient_row_id,
                           EXISTS(
                               SELECT 1
                               FROM messages mr
                               WHERE mr.reply_to = m.uuid
                           ) AS has_reply,
                           (
                               SELECT MAX(mr.created_at)
                               FROM messages mr
                               WHERE mr.reply_to = m.uuid
                           ) AS replied_at
                    FROM messages m
                    JOIN message_recipients r ON m.uuid = r.message_uuid
                    WHERE (
                        m.metadata LIKE '%whispers:coordination_kind%'
                        OR m.payload LIKE '%"coordination"%'
                    )
                      AND r.delivery_status IN ('queued', 'unclaimed', 'delivered')
                """
                coordination_params: List[Any] = []
                if agent:
                    coordination_query += " AND (m.from_agent = ? OR r.recipient_callsign = ?)"
                    coordination_params.extend([agent, agent])
                coordination_query += " ORDER BY COALESCE(r.acked_at, r.read_at, m.created_at) DESC, r.rowid DESC LIMIT ?"
                coordination_rows = conn.execute(
                    coordination_query,
                    coordination_params + [max(limit * 12, 100)],
                ).fetchall()

            coordination_events: List[Dict[str, Any]] = []
            coordination_workspace_ids: set[str] = set()
            for row in coordination_rows:
                event = coordination_activity_event_from_record(dict(row))
                if not event:
                    continue
                if workspace_id and event.get("workspace_id") != workspace_id:
                    continue
                if requested_coordination_kinds and event.get("delta_kind") not in requested_coordination_kinds:
                    continue
                coordination_events.append(event)
                event_workspace_id = str(event.get("workspace_id") or "").strip()
                if event_workspace_id and event_workspace_id != "__direct__":
                    coordination_workspace_ids.add(event_workspace_id)

            if coordination_workspace_ids:
                placeholders = ",".join("?" * len(coordination_workspace_ids))
                workspace_name_rows = conn.execute(
                    f"""
                    SELECT workspace_id, COALESCE(name, workspace_id) AS workspace_name
                    FROM workspaces
                    WHERE workspace_id IN ({placeholders})
                    """,
                    list(coordination_workspace_ids),
                ).fetchall()
                workspace_names = {
                    str(row["workspace_id"]): str(row["workspace_name"])
                    for row in workspace_name_rows
                }
                for event in coordination_events:
                    event_workspace_id = str(event.get("workspace_id") or "").strip()
                    if event_workspace_id in workspace_names:
                        event["workspace_name"] = workspace_names[event_workspace_id]

        events: List[Dict[str, Any]] = []
        for row in workspace_rows:
            events.append(_localize_record(_extract_activity_view(dict(row)), _WORKSPACE_EVENT_TIMESTAMP_FIELDS))
        for event in coordination_events:
            events.append(_localize_record(_extract_activity_view(event), _WORKSPACE_EVENT_TIMESTAMP_FIELDS))

        events.sort(
            key=lambda event: (
                str(event.get("created_at") or ""),
                int(event.get("sequence") or 0),
            ),
            reverse=True,
        )
        return events[:limit]

    # --- Item 7: Conversation trace ---
    def trace(self, callsign: str, limit: int = 20) -> List[Dict[str, Any]]:
        """Full conversation with an agent, both directions, chronological, with delivery status."""
        if self.remote_server:
            self._ensure_remote_session()
            payload = self._remote_request(f"/trace/{urllib.parse.quote(callsign)}", query={"limit": limit})
            return [_localize_record(message, _MESSAGE_TIMESTAMP_FIELDS) for message in payload.get("messages", [])]
        self._touch_activity()
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            self_aliases = _resolve_callsign_aliases(conn, self.agent_name)
            peer_aliases = _resolve_callsign_aliases(conn, callsign)
            self_placeholders = ",".join("?" * len(self_aliases))
            peer_placeholders = ",".join("?" * len(peer_aliases))
            cursor.execute(f"""
                SELECT *
                FROM (
                    SELECT m.uuid, m.from_agent, m.to_agent, m.subject, m.body,
                           m.priority, m.msg_type, m.metadata, m.created_at,
                           r.delivery_status, r.read_at, r.ack_state, r.ack_detail, r.acked_by, r.acked_at
                    FROM messages m
                    LEFT JOIN message_recipients r ON m.uuid = r.message_uuid
                    WHERE (m.from_agent IN ({self_placeholders}) AND m.to_agent IN ({peer_placeholders}))
                       OR (m.from_agent IN ({peer_placeholders}) AND m.to_agent IN ({self_placeholders}))
                    ORDER BY m.created_at DESC
                    LIMIT ?
                ) recent_conversation
                ORDER BY created_at ASC
            """, self_aliases + peer_aliases + peer_aliases + self_aliases + [limit])
            return [_localize_record(dict(r), _MESSAGE_TIMESTAMP_FIELDS) for r in cursor.fetchall()]

    def status(self, ephemeral_state: Optional[Dict[str, Dict[str, Any]]] = None) -> Dict[str, Any]:
        """Return Whispers system status: health, mode, online agents, pending messages."""
        if self.remote_server:
            self._ensure_remote_session()
            status_payload = _localize_status_payload(self._remote_request("/status"))
            return _attach_status_story(self, status_payload)
        self._touch_heartbeat()
        if not self.read_only:
            self.db.reap_expired_agent_sessions()
            self.db.reap_ghosts()

        with self.db.get_connection() as conn:
            cursor = conn.cursor()

            # My reception mode
            cursor.execute(
                "SELECT reception_mode, mode_filter, mode_set_at "
                "FROM presence WHERE agent_name = ?",
                (self.agent_name,)
            )
            my_presence = cursor.fetchone()
            my_mode = (dict(my_presence)["reception_mode"] or "open").upper() if my_presence else "OPEN"
            mode_filter = dict(my_presence).get("mode_filter", "{}") if my_presence else "{}"
            mode_set_at = dict(my_presence).get("mode_set_at") if my_presence else None

            # All agents with presence (join agent_cards for type filtering)
            cursor.execute(
                "WITH active_sessions AS ("
                "    SELECT agent_name, "
                "           COUNT(*) AS active_session_count, "
                "           MAX(last_seen_at) AS session_last_seen_at, "
                "           GROUP_CONCAT(DISTINCT session_kind) AS session_kinds, "
                "           MAX(CASE WHEN session_kind IN ('local_client', 'remote_http', 'mcp_bridge', 'dashboard_console') THEN 1 ELSE 0 END) AS has_interactive_session, "
                "           MAX(CASE WHEN session_kind IN ('local_listener', 'infrastructure') THEN 1 ELSE 0 END) AS has_background_session "
                "    FROM agent_sessions "
                "    WHERE lease_expires_at >= CURRENT_TIMESTAMP "
                "    GROUP BY agent_name"
                ") "
                "SELECT p.agent_name, "
                "       CASE WHEN COALESCE(s.active_session_count, 0) > 0 THEN COALESCE(p.status, 'online') ELSE 'offline' END AS status, "
                "       p.reception_mode, p.working_on, p.cognitive_state, p.last_active, p.heartbeat_at, "
                "       COALESCE(ac.agent_type, 'script') AS agent_type, "
                "       COALESCE(ac.trust_tier, 1) AS trust_tier, "
                "       COALESCE(s.active_session_count, 0) AS active_session_count, "
                "       s.session_kinds, "
                "       CASE "
                "         WHEN COALESCE(ac.agent_type, 'script') = 'infrastructure' THEN 'system' "
                "         WHEN COALESCE(s.active_session_count, 0) = 0 THEN 'offline' "
                "         WHEN COALESCE(s.has_interactive_session, 0) = 1 THEN 'interactive' "
                "         WHEN COALESCE(s.has_background_session, 0) = 1 THEN 'background' "
                f"         WHEN p.heartbeat_at IS NOT NULL AND (strftime('%s', 'now') - strftime('%s', p.heartbeat_at)) <= {_ACTIVE_HEARTBEAT_WINDOW_SECONDS} "
                "              AND ("
                f"                   (p.last_active IS NOT NULL AND (strftime('%s', 'now') - strftime('%s', p.last_active)) <= {_ACTIVE_LAST_ACTIVE_WINDOW_SECONDS}) "
                "                   OR "
                "                   (p.last_active IS NULL AND COALESCE(ac.agent_type, 'script') IN ('llm', 'remote_client'))"
                "              ) THEN 'interactive' "
                "         ELSE 'background' "
                "       END AS presence_kind "
                "FROM presence p "
                "LEFT JOIN agent_cards ac ON ac.callsign = p.agent_name AND ac.deregistered_at IS NULL "
                "LEFT JOIN active_sessions s ON s.agent_name = p.agent_name "
                "ORDER BY COALESCE(p.last_active, s.session_last_seen_at) DESC"
            )
            all_presence = [dict(row) for row in cursor.fetchall()]
            for presence_row in all_presence:
                runtime = self.db.get_runtime_state(presence_row["agent_name"], conn=conn)
                ephemeral = ephemeral_state.get(presence_row["agent_name"], {}) if ephemeral_state else {}

                if "cognitive_state" in ephemeral:
                    presence_row["cognitive_state"] = ephemeral["cognitive_state"]

                presence_row["readiness"] = ephemeral.get("readiness") or runtime.get("readiness", DEFAULT_READINESS_STATE)
                
                for key in [
                    "current_task",
                    "interruptibility",
                    "context_load",
                    "quality_risk",
                    "progress_summary",
                    "last_progress_at",
                    "attention_state",
                    "attention_detail",
                    "basis",
                    "evidence_refs",
                ]:
                    val = ephemeral.get(key)
                    if val is None:
                        val = runtime.get(key)
                    if val is not None:
                        presence_row[key] = val

                if runtime.get("updated_at") is not None:
                    presence_row["runtime_updated_at"] = runtime.get("updated_at")
                presence_row["derived_active_mode"] = self.db.get_derived_active_mode(
                    presence_row["agent_name"], conn=conn, ephemeral_state=ephemeral
                )
                _suppress_idle_current_task(presence_row)
                _annotate_participant_record(presence_row)
                _annotate_wake_model(presence_row)
            tier_cursor = conn.cursor()
            tier_cursor.execute("SELECT trust_tier FROM agent_cards WHERE callsign = ?", (self.agent_name,))
            tier_row = tier_cursor.fetchone()
            viewer_tier = tier_row["trust_tier"] if tier_row else 1

            filtered_presence = []
            for presence_row in all_presence:
                policy = self.db.get_presence_policy(presence_row["agent_name"], conn=conn)
                visible_row = apply_presence_policy_to_record(
                    presence_row,
                    policy,
                    viewer_agent=self.agent_name,
                    viewer_tier=viewer_tier,
                    target_agent=presence_row["agent_name"],
                )
                if visible_row is not None:
                    _annotate_participant_record(visible_row)
                    _annotate_wake_model(visible_row)
                    _attach_active_session_wake_contract(visible_row, conn=conn)
                    filtered_presence.append(visible_row)
            all_presence = filtered_presence
            online = [p for p in all_presence if p.get("status") in ("online", "idle")]

            # Separate self, peers, and infrastructure
            peers = []
            background_agents = []
            for p in online:
                if p["agent_name"] == self.agent_name:
                    continue
                elif p.get("presence_kind") == "system":
                    continue  # infrastructure participates in overall status, not peer/background lanes
                elif not p.get("is_primary_participant", True):
                    continue  # don't count infrastructure, ephemeral, or automaton agents as peers
                elif p.get("presence_kind") == "background":
                    background_agents.append(p)
                else:
                    peers.append(p)

            aliases = _resolve_callsign_aliases(conn, self.agent_name)
            alias_placeholders = ",".join("?" * len(aliases))

            # Pending messages for this agent
            cursor.execute(
                f"""
                SELECT count(m.rowid) as cnt FROM messages m
                JOIN message_recipients r ON m.uuid = r.message_uuid
                WHERE r.recipient_callsign IN ({alias_placeholders})
                  AND m.status = 'new'
                  AND r.delivery_status IN ('queued', 'unclaimed', 'delivered')
                  AND r.read_at IS NULL
                  AND r.archived_at IS NULL
                  AND (r.snoozed_until IS NULL OR r.snoozed_until <= CURRENT_TIMESTAMP)
                """,
                aliases,
            )
            pending_count = cursor.fetchone()[0]

            # Pending by priority breakdown (with signal decay applied)
            # Flash → priority after 15min, priority → routine after 1h
            from .priority_decay import FLASH_DECAY_SECONDS, PRIORITY_DECAY_SECONDS
            cursor.execute(
                f"""
                SELECT
                    CASE
                        WHEN m.priority = 'flash'
                             AND (julianday('now') - julianday(m.created_at)) * 86400 >= {FLASH_DECAY_SECONDS}
                            THEN 'priority'
                        WHEN m.priority = 'priority'
                             AND (julianday('now') - julianday(m.created_at)) * 86400 >= {PRIORITY_DECAY_SECONDS}
                            THEN 'routine'
                        ELSE m.priority
                    END AS effective_priority,
                    count(m.rowid) as cnt
                FROM messages m
                JOIN message_recipients r ON m.uuid = r.message_uuid
                WHERE r.recipient_callsign IN ({alias_placeholders})
                  AND m.status = 'new'
                  AND r.delivery_status IN ('queued', 'unclaimed', 'delivered')
                  AND r.read_at IS NULL
                  AND r.archived_at IS NULL
                  AND (r.snoozed_until IS NULL OR r.snoozed_until <= CURRENT_TIMESTAMP)
                GROUP BY effective_priority
                """,
                aliases,
            )
            pending_by_priority = {row[0]: row[1] for row in cursor.fetchall()}

            # Pending by queue class (attention rules)
            cursor.execute(
                f"""
                SELECT COALESCE(m.queue_class, 'conversation') as qc, count(m.rowid) as cnt
                FROM messages m
                JOIN message_recipients r ON m.uuid = r.message_uuid
                WHERE r.recipient_callsign IN ({alias_placeholders})
                  AND m.status = 'new'
                  AND r.delivery_status IN ('queued', 'unclaimed', 'delivered')
                  AND r.read_at IS NULL
                  AND r.archived_at IS NULL
                  AND (r.snoozed_until IS NULL OR r.snoozed_until <= CURRENT_TIMESTAMP)
                GROUP BY qc
                """,
                aliases,
            )
            pending_by_class = {row[0]: row[1] for row in cursor.fetchall()}

            cursor.execute(
                f"""
                SELECT m.uuid, m.created_at, m.from_agent, m.subject, m.priority, m.msg_type, m.reply_to
                FROM message_recipients r
                JOIN messages m ON m.uuid = r.message_uuid
                WHERE r.recipient_callsign IN ({alias_placeholders})
                  AND m.status = 'new'
                  AND r.delivery_status IN ('queued', 'unclaimed', 'delivered')
                  AND r.read_at IS NULL
                  AND r.archived_at IS NULL
                  AND (r.snoozed_until IS NULL OR r.snoozed_until <= CURRENT_TIMESTAMP)
                ORDER BY
                    CASE WHEN r.pinned_at IS NOT NULL THEN 0 ELSE 1 END,
                    r.pinned_at DESC,
                    m.priority DESC,
                    m.created_at DESC
                LIMIT 5
                """,
                aliases,
            )
            unread_previews = [dict(row) for row in cursor.fetchall()]
            # Attach reception truth to each unread preview
            for preview in unread_previews:
                try:
                    preview["reception_truth"] = ReceptionTruth.from_db_row(preview).to_dict()
                except Exception:
                    pass
            # Apply signal decay to unread previews
            try:
                from .priority_decay import apply_priority_decay_batch
                unread_previews = apply_priority_decay_batch(unread_previews)
            except Exception:
                pass
            active_reply_alerts = _extract_active_reply_alerts(unread_previews, agent_name=self.agent_name)

            cursor.execute(
                f"""
                SELECT m.uuid,
                       COALESCE(r.recipient_callsign, m.to_agent) AS counterpart,
                       m.to_agent,
                       m.subject,
                       m.priority,
                       m.msg_type,
                       m.created_at,
                       m.reply_to,
                       r.delivery_status,
                       r.claimed_at,
                       r.read_at,
                       r.ack_state,
                       EXISTS(
                           SELECT 1
                           FROM messages mr
                           WHERE mr.reply_to = m.uuid
                       ) AS has_reply,
                       (
                           SELECT MAX(mr.created_at)
                           FROM messages mr
                           WHERE mr.reply_to = m.uuid
                       ) AS replied_at
                FROM messages m
                JOIN message_recipients r ON m.uuid = r.message_uuid
                WHERE m.from_agent IN ({alias_placeholders})
                ORDER BY COALESCE(r.read_at, r.claimed_at, m.created_at) DESC
                LIMIT 12
                """,
                aliases,
            )
            recent_outbound_threads = [dict(row) for row in cursor.fetchall()]
            active_thread_watches = _extract_active_thread_watches(
                recent_outbound_threads,
                agent_name=self.agent_name,
            )

            # Total tracked participants, plus an operator-facing first-class split.
            cursor.execute(
                "SELECT callsign, agent_type, display_name FROM agent_cards WHERE deregistered_at IS NULL"
            )
            registry_rows = [dict(row) for row in cursor.fetchall()]
            for row in registry_rows:
                _annotate_participant_record(row)
            total_agents = len(registry_rows)
            participant_summary = _build_participant_summary(
                registry_rows,
                online_names={
                    str(row.get("agent_name") or "").strip()
                    for row in online
                    if str(row.get("agent_name") or "").strip()
                },
            )

            # Schema version
            schema_version = self.db.get_schema_version()

            baton_counts = self.db.get_baton_state_counts(self.agent_name, conn=conn)
            baton_details = self.db.get_active_baton_details(self.agent_name, conn=conn)
            coordination_state = self.db.get_coordination_state(self.agent_name, conn=conn)
            captain_action_alerts = _captain_action_alerts(conn, self.agent_name)
            huddle_adjacency = self.db.get_huddle_adjacency(
                self.agent_name,
                [peer.get("agent_name") for peer in peers],
                conn=conn,
            )
            peer_assignment_alerts = _peers_needing_assignment(
                [
                    peer
                    for peer in peers
                    if not _peer_assignment_request_answered(conn, peer)
                    and not _peer_has_pending_captain_action(peer, captain_action_alerts)
                ]
            )
            huddle_peers = []
            for peer in peers:
                peer_name = str(peer.get("agent_name") or "").strip()
                if not peer_name:
                    continue
                adjacency = huddle_adjacency.get(peer_name)
                if not adjacency:
                    continue
                huddle_peers.append(
                    {
                        "agent_name": peer_name,
                        "readiness": str(peer.get("readiness") or "ready"),
                        "derived_active_mode": str(peer.get("derived_active_mode") or "ready"),
                        "working_on": peer.get("working_on"),
                        "shared_workspaces": adjacency.get("shared_workspaces", []),
                        "incoming_baton_from_peer": bool(adjacency.get("incoming_baton_from_peer")),
                        "outgoing_baton_to_peer": bool(adjacency.get("outgoing_baton_to_peer")),
                        "incoming_baton_count": int(adjacency.get("incoming_baton_count", 0)),
                        "outgoing_baton_count": int(adjacency.get("outgoing_baton_count", 0)),
                        "huddle_reasons": adjacency.get("reasons", []),
                    }
                )

        deployment_mode = _runtime_deployment_mode()
        deployment_source = "runtime_hint" if deployment_mode else None

        if deployment_mode is None:
            deployment_mode = _deployment_mode_from_server(self.db_path)
            if deployment_mode is not None:
                deployment_source = "server_health"

        if deployment_mode is None:
            deployment_mode = _deployment_mode_from_manifest(self.agent_name)
            if deployment_mode is not None:
                deployment_source = "manifest_intent"

        if deployment_mode is None:
            deployment_mode = "embedded"
            deployment_source = "default_local"

        # Check HTTP server reachability so stdio-transport agents can detect
        # when HTTP-transport agents (like Claude) would be cut off.
        # Use the cheap liveness endpoint rather than the full diagnostic
        # /health payload so routine status checks do not amplify load.
        http_server_reachable = False
        if self.agent_type == "infrastructure" or self.assume_http_server_reachable:
            http_server_reachable = True  # We are the server
        else:
            http_server_reachable = _probe_http_server() and _probe_http_server(_READYZ_URL)

            # Self-healing: auto-start the HTTP server if it's unreachable.
            # We check if whispers-server is installed rather than checking
            # deployment_mode, because deployment_mode defaults to "embedded"
            # precisely when the server is down (chicken-and-egg).
            if not http_server_reachable:
                import shutil
                if shutil.which("whispers-server"):
                    http_server_reachable = _try_autostart_server()
                    if http_server_reachable and deployment_source == "default_local":
                        deployment_mode = "standalone"
                        deployment_source = "server_autostart"

        session_snapshot = self._status_session_snapshot(conn=conn)
        self_runtime = dict(
            self.db.get_runtime_state(
                self.agent_name,
                session_id=session_snapshot.get("session_id") or self.session_id,
                conn=conn,
            ) or {}
        )
        self_runtime.setdefault("interruptibility", "free")
        self_runtime.setdefault("agent_type", self.agent_type)
        fallback_session_kind = self.session_kind if self.session_id and not self.read_only else None
        session_kind = str(session_snapshot.get("session_kind") or fallback_session_kind or "").strip()
        if not self_runtime.get("session_kinds") and session_kind:
            self_runtime["session_kinds"] = [session_kind]
        self_wake_model = _annotate_wake_model(self_runtime)
        session_capabilities = session_snapshot.get("capabilities") or {}
        jolt_adapter = (
            self._current_jolt_adapter(self_wake_model, session_capabilities)
            if self_wake_model and session_capabilities
            else None
        )
        jolt_host_capabilities = (
            self._current_jolt_host_capabilities(self_wake_model, session_capabilities)
            if self_wake_model and session_capabilities
            else None
        )
        jolt_budget = (
            self._current_jolt_budget(session_capabilities) if self_wake_model and session_capabilities else None
        )

        status_payload = _localize_status_payload({
            "healthy": True,
            "deployment_mode": deployment_mode,
            "deployment_source": deployment_source,
            "http_server_reachable": http_server_reachable,
            "db_path": self.db_path,
            "schema_version": schema_version,
            "my_mode": my_mode,
            "mode_filter": mode_filter,
            "mode_set_at": mode_set_at,
            "self_agent": self.agent_name,
            "readiness": self_runtime.get("readiness", DEFAULT_READINESS_STATE),
            "interruptibility": self_runtime.get("interruptibility") or "free",
            "current_task": self_runtime.get("current_task"),
            "progress_summary": self_runtime.get("progress_summary"),
            "last_progress_at": self_runtime.get("last_progress_at"),
            "attention_state": self_runtime.get("attention_state"),
            "attention_detail": self_runtime.get("attention_detail"),
            "derived_active_mode": self.db.get_derived_active_mode(self.agent_name),
            "wake_model": self_wake_model,
            "jolt_adapter": jolt_adapter.to_dict() if jolt_adapter else None,
            "jolt_host_capabilities": jolt_host_capabilities.to_dict() if jolt_host_capabilities else None,
            "jolt_budget": jolt_budget.to_dict() if jolt_budget else None,
            "peers_online": peers,
            "huddle_peers": huddle_peers,
            "peers_online_count": len(peers),
            "background_agents": background_agents,
            "background_agents_count": len(background_agents),
            # Backward compat — includes all online (self + infra + peers)
            "agents_online": online,
            "agents_online_count": len(online),
            "agents_registered": total_agents,
            "agents_total_presence": len(all_presence),
            "participant_counts": participant_summary["participant_counts"],
            "primary_participants_registered": participant_summary["primary_participants_registered"],
            "primary_participants_online": participant_summary["primary_participants_online"],
            "secondary_participants_registered": participant_summary["secondary_participants_registered"],
            "secondary_participants_online": participant_summary["secondary_participants_online"],
            "first_class_participants_registered": participant_summary["first_class_participants_registered"],
            "first_class_participants_online": participant_summary["first_class_participants_online"],
            "other_participants_registered": participant_summary["other_participants_registered"],
            "other_participants_online": participant_summary["other_participants_online"],
            "pending_messages": pending_count,
            "pending_by_priority": pending_by_priority,
            "pending_by_class": pending_by_class,
            "unread_previews": unread_previews,
            "incoming_batons": int(baton_counts.get("incoming_batons", 0)),
            "carrying_batons": int(baton_counts.get("carrying_batons", 0)),
            "claimed_reviews": int(baton_counts.get("claimed_reviews", 0)),
            "coordination_state": coordination_state,
            "pending_assignments": int(coordination_state.get("pending_assignments", 0)),
            "pending_review_requests": int(coordination_state.get("pending_review_requests", 0)),
            "blocking_review_requests": int(coordination_state.get("blocking_review_requests", 0)),
            "blocked_waiting_for_review": int(coordination_state.get("blocked_waiting_for_review", 0)),
            "answered_waiting_to_close": int(coordination_state.get("answered_waiting_to_close", 0)),
            "captain_action_requests": len(captain_action_alerts),
            "captain_action_alerts": captain_action_alerts,
            "active_reply_requests": len(active_reply_alerts),
            "active_reply_alerts": active_reply_alerts,
            "active_thread_watch_count": len(active_thread_watches),
            "active_thread_watches": active_thread_watches,
            "peer_assignment_requests": len(peer_assignment_alerts),
            "peer_assignment_alerts": peer_assignment_alerts,
            "peer_nudge_requests": sum(1 for alert in peer_assignment_alerts if alert.get("operator_nudge_required")),
            "peer_nudge_alerts": [alert for alert in peer_assignment_alerts if alert.get("operator_nudge_required")],
            "baton_state": baton_counts,
            "baton_details": baton_details,
        })
        return _attach_status_story(self, status_payload)

    def startup_briefing(self) -> Dict[str, Any]:
        status = self.status()
        startup = status.get("startup")
        if isinstance(startup, dict):
            return startup
        return build_startup_briefing(status, agent_name=self.agent_name)

    def get_connection_story(self, status_snapshot: Optional[Dict[str, Any]] = None) -> ConnectionStory:
        """Assemble the canonical Connection Story for this agent.

        The Connection Story is the single source of truth for startup,
        status, doctor, onboarding UX, and dashboard views. It replaces
        the scattered assembly of startup truth from multiple calls.
        """
        status = status_snapshot or self.status()

        # Identity
        agent_name = str(status.get("self_agent") or self.agent_name)
        agent_type = "unknown"
        trust_tier = 1
        display_name = None
        if not self.remote_server and self.db:
            with self.db.get_connection() as conn:
                card = conn.execute(
                    "SELECT agent_type, trust_tier, display_name FROM agent_cards "
                    "WHERE callsign = ? AND deregistered_at IS NULL",
                    (agent_name,),
                ).fetchone()
                if card:
                    card = dict(card)
                    agent_type = card.get("agent_type") or "unknown"
                    trust_tier = card.get("trust_tier") or 1
                    display_name = card.get("display_name")

        # Peers
        peers_online = status.get("peers_online") or status.get("agents_online") or []
        active_assignment_alert_names = {
            str(alert.get("agent_name") or alert.get("callsign") or "").strip()
            for alert in (status.get("peer_assignment_alerts") or [])
            if isinstance(alert, dict)
        }
        def _parse_evidence_refs(val):
            if val is None:
                return None
            if isinstance(val, list):
                return val
            if isinstance(val, str):
                try:
                    parsed = json.loads(val)
                    return parsed if isinstance(parsed, list) else None
                except Exception:
                    return None
            return None

        # Compute actionable queue depth per peer for predictive escalation
        _peer_actionable: dict[str, int] = {}
        try:
            import contextlib
            with contextlib.closing(self.db.get_readonly_connection()) as _conn:
                _conn.row_factory = __import__("sqlite3").Row
                _act_rows = _conn.execute("""
                    SELECT r.recipient_callsign, COUNT(*) as cnt
                    FROM messages m
                    JOIN message_recipients r ON m.uuid = r.message_uuid
                    WHERE m.status = 'new'
                      AND r.delivery_status IN ('queued', 'unclaimed', 'delivered')
                      AND r.read_at IS NULL
                      AND r.archived_at IS NULL
                      AND (r.snoozed_until IS NULL OR r.snoozed_until <= CURRENT_TIMESTAMP)
                      AND COALESCE(m.queue_class, 'conversation') = 'actionable'
                    GROUP BY r.recipient_callsign
                """).fetchall()
                _peer_actionable = {row[0]: row[1] for row in _act_rows}
        except Exception:
            pass

        peers: list[PeerSnapshot] = []
        for p in peers_online:
            if not isinstance(p, dict):
                continue
            name = str(p.get("agent_name") or "").strip()
            if not name or name == agent_name:
                continue
            wake_model = str(p.get("wake_model") or "").strip().lower() or None
            attention_state = str(p.get("attention_state") or "").strip().lower() or None
            if (
                attention_state == "needs_assignment"
                and name not in active_assignment_alert_names
            ):
                attention_state = None
            peers.append(PeerSnapshot(
                callsign=name,
                agent_type=str(p.get("agent_type") or "unknown"),
                readiness=str(p.get("readiness") or "ready"),
                reception_mode=str(p.get("reception_mode") or "open"),
                working_on=p.get("working_on"),
                current_task=p.get("current_task"),
                attention_state=attention_state,
                attention_detail=p.get("attention_detail"),
                progress_summary=p.get("progress_summary"),
                trust_tier=int(p.get("trust_tier") or 1),
                derived_active_mode=str(p.get("derived_active_mode") or "ready"),
                wake_model=wake_model,
                operator_nudge_required=(
                    attention_state == "needs_assignment"
                    and _operator_nudge_required_for_peer(p)
                ) or None,
                basis=p.get("basis"),
                runtime_updated_at=p.get("runtime_updated_at"),
                freshness_posture=p.get("freshness_posture"),
                presence_kind=p.get("presence_kind"),
                evidence_refs=_parse_evidence_refs(p.get("evidence_refs")),
                actionable_count=_peer_actionable.get(name, 0),
            ))
        huddle_peers: list[HuddlePeer] = []
        for row in status.get("huddle_peers") or []:
            if not isinstance(row, dict):
                continue
            name = str(row.get("agent_name") or row.get("callsign") or "").strip()
            if not name or name == agent_name:
                continue
            huddle_peers.append(
                HuddlePeer(
                    callsign=name,
                    readiness=str(row.get("readiness") or "ready"),
                    derived_active_mode=str(row.get("derived_active_mode") or "ready"),
                    working_on=row.get("working_on"),
                    shared_workspaces=[
                        str(label).strip()
                        for label in (row.get("shared_workspaces") or [])
                        if str(label).strip()
                    ],
                    incoming_baton_from_them=bool(
                        row.get("incoming_baton_from_peer") or row.get("incoming_baton_from_them")
                    ),
                    outgoing_baton_to_them=bool(
                        row.get("outgoing_baton_to_peer") or row.get("outgoing_baton_to_them")
                    ),
                    incoming_baton_count=int(row.get("incoming_baton_count") or 0),
                    outgoing_baton_count=int(row.get("outgoing_baton_count") or 0),
                    reasons=[
                        str(reason).strip()
                        for reason in (row.get("huddle_reasons") or row.get("reasons") or [])
                        if str(reason).strip()
                    ],
                )
            )

        # Pending messages
        pending = int(status.get("pending_messages") or 0)
        pending_by_priority = status.get("pending_by_priority") or {}
        unread_flash = int(pending_by_priority.get("flash", 0)) + int(pending_by_priority.get("system", 0))
        incoming_batons = int(status.get("incoming_batons") or 0)
        carrying_batons = int(status.get("carrying_batons") or 0)
        claimed_reviews = int(status.get("claimed_reviews") or 0)
        baton_details = [
            BatonDetail(
                baton_ref=str(item.get("baton_ref") or ""),
                counterpart=str(item.get("counterpart") or "unknown"),
                direction=str(item.get("direction") or "incoming"),
                state=str(item.get("state") or "offered"),
                priority=str(item.get("priority") or "routine"),
                label=str(item.get("label") or ""),
                last_update=str(item.get("last_update") or "").strip() or None,
                created_at=item.get("created_at"),
                updated_at=item.get("updated_at"),
                workspace_id=item.get("workspace_id"),
                version=int(item.get("version") or 1),
            )
            for item in (status.get("baton_details") or [])
            if isinstance(item, dict) and str(item.get("baton_ref") or "").strip()
        ]
        coordination_state = coordination_state_from_dict(status.get("coordination_state"))
        captain_action_alerts = [
            dict(item)
            for item in (status.get("captain_action_alerts") or [])
            if isinstance(item, dict)
        ]
        active_reply_alerts = [
            ActiveReplyAlert(
                message_id=str(item.get("message_id") or ""),
                counterpart=str(item.get("counterpart") or item.get("from_agent") or "").strip() or "peer",
                subject=str(item.get("subject") or "").strip() or "(no subject)",
                priority=str(item.get("priority") or "routine"),
                msg_type=str(item.get("msg_type") or "inform"),
                created_at=item.get("created_at"),
                reply_to=str(item.get("reply_to") or "").strip() or None,
            )
            for item in (status.get("active_reply_alerts") or [])
            if isinstance(item, dict) and str(item.get("message_id") or "").strip()
        ]
        active_thread_watches = [
            ActiveThreadWatch(
                message_id=str(item.get("message_id") or ""),
                counterpart=str(item.get("counterpart") or item.get("to_agent") or "").strip() or "peer",
                subject=str(item.get("subject") or "").strip() or "(no subject)",
                stage=str(item.get("stage") or "awaiting_read"),
                priority=str(item.get("priority") or "routine"),
                msg_type=str(item.get("msg_type") or "inform"),
                created_at=item.get("created_at"),
                delivered_at=item.get("delivered_at"),
                read_at=item.get("read_at"),
                stage_started_at=item.get("stage_started_at"),
                stage_label=str(item.get("stage_label") or "").strip() or None,
                age_label=str(item.get("age_label") or "").strip() or None,
                reception_truth=item.get("reception_truth"),
            )
            for item in (status.get("active_thread_watches") or [])
            if isinstance(item, dict) and str(item.get("message_id") or "").strip()
        ]

        # Since-last-seen
        since_last_seen = self._build_since_last_seen(agent_name, [p.callsign for p in peers])

        pending_by_class = normalize_pending_by_class_counts(status.get("pending_by_class") or {})
        has_blocking_work = bool(
            incoming_batons
            or coordination_state.pending_assignments
            or coordination_state.pending_review_requests
            or coordination_state.blocking_review_requests
            or coordination_state.blocked_waiting_for_review
            or coordination_state.answered_waiting_to_close
        )
        attention_treatment = build_attention_treatment_summary(
            pending_by_class=pending_by_class,
            pending_by_priority=pending_by_priority,
            interruptibility=str(status.get("interruptibility") or "").strip().lower() or None,
            readiness=str(status.get("readiness") or "").strip().lower() or None,
            has_blocking_work=has_blocking_work,
        )

        # Assemble story
        story = ConnectionStory(
            agent_name=agent_name,
            agent_type=agent_type,
            trust_tier=trust_tier,
            display_name=display_name,
            deployment_mode=str(status.get("deployment_mode") or "standalone"),
            transport="http" if self.remote_server else "embedded",
            signal_mode=str(status.get("my_mode") or "OPEN").upper(),
            readiness=str(status.get("readiness") or "ready"),
            derived_active_mode=str(status.get("derived_active_mode") or "ready"),
            wake_model=str(status.get("wake_model") or "").strip().lower() or None,
            interruptibility=str(status.get("interruptibility") or "").strip().lower() or None,
            jolt_adapter=(
                jolt_adapter_from_dict(
                    status.get("wake_model"),
                    status.get("jolt_adapter") or status.get("jolt_host_capabilities"),
                )
                if status.get("jolt_adapter") or status.get("jolt_host_capabilities")
                else None
            ),
            jolt_host_capabilities=(
                host_wake_capabilities_from_dict(status.get("wake_model"), status.get("jolt_host_capabilities"))
                if status.get("jolt_host_capabilities")
                else None
            ),
            jolt_budget=(
                jolt_budget_from_dict(status.get("jolt_budget"))
                if status.get("jolt_budget")
                else None
            ),
            peers=peers,
            huddle_peers=huddle_peers,
            peers_online_count=len(peers),
            agents_registered=int(status.get("agents_registered") or 0),
            pending_messages=pending,
            pending_by_priority=pending_by_priority,
            pending_by_class=pending_by_class,
            attention_treatment=attention_treatment,
            unread_flash=unread_flash,
            incoming_batons=incoming_batons,
            carrying_batons=carrying_batons,
            claimed_reviews=claimed_reviews,
            baton_details=baton_details,
            pending_assignments=coordination_state.pending_assignments,
            pending_review_requests=coordination_state.pending_review_requests,
            blocking_review_requests=coordination_state.blocking_review_requests,
            blocked_waiting_for_review=coordination_state.blocked_waiting_for_review,
            answered_waiting_to_close=coordination_state.answered_waiting_to_close,
            coordination_highlights=coordination_state.highlights,
            captain_action_alerts=captain_action_alerts,
            active_reply_alerts=active_reply_alerts,
            active_thread_watches=active_thread_watches,
            unread_previews=status.get("unread_previews") or [],
            since_last_seen=since_last_seen,
            narrator_agent=status.get("narrator_agent"),
            narrator_status=str(status.get("narrator_status") or "disabled"),
            local_time=str(status.get("now_local") or "-"),
            http_server_reachable=status.get("http_server_reachable"),
        )

        # Machine courtesy: surface recent courtesy activity for operator visibility
        if self.dispatcher:
            try:
                story.courtesy_summary = self.dispatcher.get_courtesy_summary()
            except Exception:
                pass

        story.recommended_action = infer_recommended_action(story)
        story.jolt_decision = infer_jolt_decision(story)
        story.jolt_packet = build_jolt_packet(story)
        return story

    def get_briefing_capsule(self) -> Dict[str, Any]:
        """Return the Briefing Capsule — compact presentation of the Connection Story."""
        return build_briefing_capsule(self.get_connection_story())

    def get_jolt_packet(self, status_snapshot: Optional[Dict[str, Any]] = None) -> Optional[Dict[str, Any]]:
        story = self.get_connection_story(status_snapshot=status_snapshot)
        packet = story.jolt_packet or build_jolt_packet(story)
        return packet.to_dict() if packet is not None else None

    def _build_since_last_seen(
        self,
        agent_name: str,
        current_peer_names: list[str],
    ) -> SinceLastSeen:
        """Compute what changed since this agent's last session."""
        if self.remote_server:
            # Remote clients: server will provide this via endpoint
            return SinceLastSeen(is_first_session=True)

        if not self.db:
            return SinceLastSeen(is_first_session=True)

        last_end = self.db.get_last_session_end(agent_name)
        if not last_end:
            return SinceLastSeen(is_first_session=True)

        msg_info = self.db.get_messages_since(agent_name, last_end)
        peer_changes = self.db.get_peer_changes_since(last_end, current_peer_names)

        # Baton, workspace, and task deltas
        baton_changes = self.db.get_baton_changes_since(agent_name, last_end)
        ws_activity = self.db.get_workspace_activity_since(agent_name, last_end)
        task_state = self.db.get_task_state_since(agent_name, last_end)

        # Build resume hint
        resume_hint = self._compute_resume_hint(
            msg_info, baton_changes, task_state, ws_activity
        )

        return SinceLastSeen(
            last_session_ended=last_end,
            messages_arrived=msg_info["total"],
            messages_by_priority=msg_info["by_priority"],
            messages_by_class=msg_info.get("by_class", {}),
            messages_by_sender=msg_info.get("by_sender", {}),
            peers_joined=peer_changes["joined"],
            peers_departed=peer_changes["departed"],
            is_first_session=False,
            batons_received=baton_changes["received"],
            batons_completed=baton_changes["completed"],
            batons_expired=baton_changes["expired"],
            workspace_events=ws_activity["total"],
            active_workspaces=ws_activity["active_workspaces"],
            tasks_assigned=task_state["assigned"],
            tasks_completed_by_others=task_state["completed_by_others"],
            resume_hint=resume_hint,
        )

    @staticmethod
    def _compute_resume_hint(
        msg_info: dict,
        baton_changes: dict,
        task_state: dict,
        ws_activity: dict,
    ) -> Optional[str]:
        """Generate a concrete 'start here' suggestion based on what changed."""
        hints = []
        if baton_changes["received"] > 0:
            hints.append(f"{baton_changes['received']} handoff(s) waiting for your acknowledgment")
        if msg_info.get("by_priority", {}).get("flash", 0) > 0:
            hints.append(f"{msg_info['by_priority']['flash']} flash message(s) need attention")
        if task_state["assigned"] > 0:
            hints.append(f"{task_state['assigned']} task(s) assigned to you")
        if msg_info["total"] > 0 and not hints:
            hints.append(f"{msg_info['total']} message(s) arrived — check inbox")
        if ws_activity["total"] > 0 and not hints:
            hints.append(f"{ws_activity['total']} workspace event(s) across {len(ws_activity['active_workspaces'])} workspace(s)")
        if not hints:
            return None
        return "; ".join(hints)

    def score_negotiation(self, negotiation_id: str) -> Dict[str, Any]:
        """Detect if agents fabricated consensus without real adversarial debate."""
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT body FROM messages WHERE negotiation_id = ? ORDER BY created_at ASC", (negotiation_id,))
            rows = cursor.fetchall()

            transcript = " ".join([r['body'] for r in rows if r['body']]).lower()

            conflict_markers = ["however", "disagree", "alternative", "issue", "risk", "but", "flaw", "concern", "instead"]
            consensus_markers = ["agree", "exactly", "perfect", "unanimous", "good point", "makes sense", "proceed", "approve"]

            conflict_score = sum(transcript.count(m) for m in conflict_markers)
            consensus_score = sum(transcript.count(m) for m in consensus_markers)

            confidence = "high"
            if conflict_score == 0 and consensus_score >= 2:
                confidence = "low"
            elif conflict_score < 2 and consensus_score >= 4:
                confidence = "low"

            cursor.execute("UPDATE negotiations SET status = 'scored' WHERE session_id = ?", (negotiation_id,))

            warning_string = f"\n[TENSION HEURISTIC: confidence {confidence}]"
            cursor.execute(
                "UPDATE decisions SET rationale = rationale || ? WHERE negotiation_id = ?",
                (warning_string, negotiation_id)
            )
            conn.commit()

            return {
                "negotiation_id": negotiation_id,
                "turns": len(rows),
                "conflict_score": conflict_score,
                "consensus_score": consensus_score,
                "confidence": confidence,
            }


class MockWhispersClient(WhispersClient):
    """A developer tool for intercepting sent messages without a DB."""
    def __init__(self, agent_name: str):
        self.agent_name = agent_name
        self.sent_messages: List[Envelope] = []
        self._delivery_results: Dict[str, str] = {}  # message_id -> delivery_status

    def send(self, to: str, subject: str, body: Optional[str] = None,
             priority: str = "routine", msg_type: str = "inform",
             trace_id: Optional[str] = None, **kwargs) -> Dict[str, str]:

        env = Envelope(
            sender=self.agent_name,
            recipient=to,
            subject=subject,
            body=body,
            priority=Priority(priority),
            msg_type=MsgType(msg_type),
            trace_id=trace_id,
            **kwargs
        )
        self.sent_messages.append(env)
        self._delivery_results[env.id] = "delivered"
        return {"status": "delivered", "id": env.id}

    def _touch_heartbeat(self):
        pass

    def set_mode(self, mode: str, allow_senders: Optional[List[str]] = None) -> None:
        pass

    def get_mode(self, agent: Optional[str] = None) -> Dict[str, Any]:
        return {"reception_mode": "open", "mode_filter": "{}", "mode_set_at": None}

    def presence_who(self) -> Dict[str, Any]:
        return {"agents": [], "background_agents": []}

    def set_readiness(
        self,
        readiness: str,
        current_task: Optional[str] = None,
        *,
        attention_state: Any = _RUNTIME_FIELD_UNSET,
        attention_detail: Any = _RUNTIME_FIELD_UNSET,
        basis: Optional[str] = None,
        evidence_refs: Optional[list] = None,
    ) -> Dict[str, Any]:
        payload = {
            "agent_name": self.agent_name,
            "session_id": None,
            "readiness": readiness,
            "current_task": current_task,
        }
        if attention_state is not _RUNTIME_FIELD_UNSET:
            payload["attention_state"] = attention_state
        if attention_detail is not _RUNTIME_FIELD_UNSET:
            payload["attention_detail"] = attention_detail
        return payload

    def get_runtime_state(self, agent_name: Optional[str] = None) -> Dict[str, Any]:
        return {
            "agent_name": agent_name or self.agent_name,
            "session_id": None,
            "readiness": DEFAULT_READINESS_STATE,
        }

    def get_presence_policy(self, agent_name: Optional[str] = None) -> Dict[str, Any]:
        return {
            "agent_name": agent_name or self.agent_name,
            "visibility_posture": "visible",
            "state_detail_visibility": "full",
            "reachability": "all",
            "notification_policy": "all",
            "idle_policy": {"mode": "stay_visible", "timeout_seconds": None},
            "updated_at": None,
        }

    def set_presence_policy(self, policy: Dict[str, Any]) -> Dict[str, Any]:
        payload = self.get_presence_policy()
        payload.update({k: v for k, v in policy.items() if k != "idle_policy"})
        if isinstance(policy.get("idle_policy"), dict):
            payload["idle_policy"].update(policy["idle_policy"])
        return payload

    def update_cognitive_heartbeat(self, heartbeat: Dict[str, Any]) -> Dict[str, Any]:
        payload = self.get_runtime_state()
        payload.update(heartbeat)
        return payload

    def get_derived_active_mode(self, agent_name: Optional[str] = None) -> str:
        return "ready"

    def check_inbox(self, limit: int = 50, mark_seen: bool = True, pools: Optional[List[str]] = None) -> List[Dict[str, Any]]:
        return []

    def acknowledge_message(self, message_uuid: str, state: str, detail: str = "") -> Dict[str, Any]:
        return {
            "uuid": message_uuid,
            "ack_state": AcknowledgmentState(state).value,
            "ack_detail": detail or None,
            "acked_by": self.agent_name,
            "acked_at": utc_now_iso(),
        }

    def listen(
        self,
        *,
        poll_interval: float = 1.0,
        batch_limit: int = 50,
        max_messages: Optional[int] = None,
        reconnect_delay: float = 1.0,
        max_reconnect_delay: float = 10.0,
    ):
        return iter(())

    def outbox(self, limit: int = 20) -> List[Dict[str, Any]]:
        return []

    def list_handoffs(
        self,
        *,
        limit: int = 20,
        workspace_id: Optional[str] = None,
        unacknowledged_only: bool = False,
        include_all: Optional[bool] = None,
    ) -> List[Dict[str, Any]]:
        handoffs: List[Dict[str, Any]] = []
        for envelope in reversed(self.sent_messages):
            view = _extract_handoff_view(
                {
                    "uuid": envelope.id,
                    "from_agent": envelope.sender,
                    "to_agent": envelope.recipient,
                    "recipient_callsign": envelope.recipient,
                    "subject": envelope.subject,
                    "body": envelope.body,
                    "payload": envelope.payload,
                    "metadata": envelope.metadata,
                    "priority": envelope.priority.value,
                    "msg_type": envelope.msg_type.value,
                    "created_at": envelope.created_at.isoformat(),
                    "trace_id": envelope.trace_id,
                    "delivery_status": self._delivery_results.get(envelope.id, "delivered"),
                    "ack_state": None,
                    "ack_detail": None,
                    "acked_by": None,
                    "acked_at": None,
                }
            )
            if not view:
                continue
            if workspace_id and view.get("workspace_id") != workspace_id:
                continue
            if unacknowledged_only and view.get("ack_state"):
                continue
            handoffs.append(_localize_record(view, _MESSAGE_TIMESTAMP_FIELDS))
            if len(handoffs) >= limit:
                break
        return handoffs

    def list_activity(
        self,
        *,
        limit: int = 50,
        workspace_id: Optional[str] = None,
        agent: Optional[str] = None,
        kinds: Optional[List[str]] = None,
    ) -> List[Dict[str, Any]]:
        return []

    def trace(self, callsign: str, limit: int = 20) -> List[Dict[str, Any]]:
        return []

    def status(self) -> Dict[str, Any]:
        return {
            "healthy": True,
            "deployment_mode": "mock",
            "deployment_source": "mock",
            "display_timezone": local_timezone_label(),
            "now_utc": utc_now_iso(),
            "now_local": add_local_timestamp_fields({"now_utc": utc_now_iso()}, ("now_utc",)).get("now_utc_local"),
            "db_path": None,
            "schema_version": None,
            "my_mode": "OPEN",
            "mode_filter": "{}",
            "mode_set_at": None,
            "readiness": DEFAULT_READINESS_STATE,
            "derived_active_mode": "ready",
            "agents_online": [],
            "agents_online_count": 0,
            "agents_registered": 0,
            "agents_total_presence": 0,
            "participant_counts": _empty_participant_counts(),
            "primary_participants_registered": 0,
            "primary_participants_online": 0,
            "secondary_participants_registered": 0,
            "secondary_participants_online": 0,
            "first_class_participants_registered": 0,
            "first_class_participants_online": 0,
            "other_participants_registered": 0,
            "other_participants_online": 0,
            "huddle_peers": [],
            "pending_messages": 0,
            "pending_by_priority": {},
            "incoming_batons": 0,
            "carrying_batons": 0,
            "claimed_reviews": 0,
            "coordination_state": {
                "pending_assignments": 0,
                "pending_review_requests": 0,
                "blocking_review_requests": 0,
                "blocked_waiting_for_review": 0,
                "answered_waiting_to_close": 0,
                "highlights": [],
            },
            "pending_assignments": 0,
            "pending_review_requests": 0,
            "blocking_review_requests": 0,
            "blocked_waiting_for_review": 0,
            "answered_waiting_to_close": 0,
            "baton_state": {
                "incoming_batons": 0,
                "carrying_batons": 0,
                "claimed_reviews": 0,
            },
        }

    def handle_status(self, callsign: str) -> Dict[str, Any]:
        return {
            "callsign": callsign,
            "state": "available",
            "available": True,
            "active": False,
            "detail": "Mock client does not reserve handles.",
            "existing_callsign_policy": "mock",
            "public_key_bound": False,
            "public_key_fingerprint": None,
        }

    def identity_key(self) -> Dict[str, Any]:
        return {
            "agent_name": self.agent_name,
            "public_key": None,
            "public_key_bound": False,
            "public_key_fingerprint": None,
        }

    def bind_identity_key(self, public_key: str, *, replace: bool = False) -> Dict[str, Any]:
        return {
            "agent_name": self.agent_name,
            "public_key": public_key,
            "public_key_bound": True,
            "public_key_fingerprint": fingerprint_public_key(public_key),
            "binding_outcome": "bound",
        }

    def rename(self, new_callsign: str, *, display_name: Optional[str] = None) -> Dict[str, Any]:
        old_callsign = self.agent_name
        self.agent_name = new_callsign
        return {
            "old_callsign": old_callsign,
            "new_callsign": new_callsign,
            "agent_name": new_callsign,
            "display_name": display_name,
            "stream_restart_required": False,
        }


    # ---------------------------------------------------------------------------
    # Process Runs API (Substrate V1)
    # ---------------------------------------------------------------------------
    def create_process_run(self, name: str, purpose: Optional[str] = None) -> Dict[str, Any]:
        req = self._make_request(
            "POST",
            "/runs",
            json={"name": name, "purpose": purpose},
        )
        with urllib.request.urlopen(req) as resp:
            return json.loads(resp.read().decode("utf-8"))

    def get_process_run(self, run_id: str) -> Dict[str, Any]:
        req = self._make_request("GET", f"/runs/{run_id}")
        with urllib.request.urlopen(req) as resp:
            return json.loads(resp.read().decode("utf-8"))

    def list_process_runs(self) -> List[Dict[str, Any]]:
        req = self._make_request("GET", "/runs")
        with urllib.request.urlopen(req) as resp:
            return json.loads(resp.read().decode("utf-8"))

    def add_process_task(self, run_id: str, subject: str, description: Optional[str] = None, ordinal: Optional[int] = None, blocked_by: Optional[str] = None) -> str:
        payload = {"subject": subject}
        if description: payload["description"] = description
        if ordinal is not None: payload["ordinal"] = ordinal
        if blocked_by: payload["blocked_by"] = blocked_by
        req = self._make_request("POST", f"/runs/{run_id}/tasks", json=payload)
        with urllib.request.urlopen(req) as resp:
            return json.loads(resp.read().decode("utf-8"))["task_id"]

    def assign_task(self, task_id: str, agent_name: str) -> Dict[str, Any]:
        req = self._make_request("POST", f"/tasks/{task_id}/assign", json={"agent_name": agent_name})
        with urllib.request.urlopen(req) as resp:
            return json.loads(resp.read().decode("utf-8"))

    def update_task_status(self, task_id: str, status: str, baton_ref: Optional[str] = None) -> Dict[str, Any]:
        payload = {"status": status}
        if baton_ref: payload["baton_ref"] = baton_ref
        req = self._make_request("PATCH", f"/tasks/{task_id}", json=payload)
        with urllib.request.urlopen(req) as resp:
            return json.loads(resp.read().decode("utf-8"))

    def get_my_tasks(self) -> List[Dict[str, Any]]:
        req = self._make_request("GET", "/tasks")
        with urllib.request.urlopen(req) as resp:
            return json.loads(resp.read().decode("utf-8"))

