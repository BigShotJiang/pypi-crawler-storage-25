from enum import Enum
import json
from typing import Optional, List
from .envelope import Envelope

class Mode(str, Enum):
    OPEN = "open"
    FOCUSED = "focused"
    QUIET = "quiet"

class ModeFilter:
    """Evaluates predicate logic to determine if a message bypasses FOCUSED mode."""
    def __init__(self, allow_senders: Optional[List[str]] = None, allow_types: Optional[List[str]] = None):
        self.allow_senders = allow_senders or []
        self.allow_types = allow_types or []

    def to_json(self) -> str:
        return json.dumps({
            "allow_senders": self.allow_senders,
            "allow_types": self.allow_types
        })

    @classmethod
    def from_json(cls, data: str) -> "ModeFilter":
        if not data:
            return cls()
        parsed = json.loads(data)
        return cls(**parsed)

    def permits(self, envelope: Envelope) -> bool:
        if envelope.sender in self.allow_senders:
            return True
        if envelope.msg_type.value in self.allow_types:
            return True
        return False
