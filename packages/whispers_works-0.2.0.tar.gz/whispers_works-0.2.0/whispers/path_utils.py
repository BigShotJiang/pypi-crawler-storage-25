from __future__ import annotations

import os


def _raw_expanduser(path: str) -> str:
    return os.path.expanduser(path)


def _env_home_dir() -> str | None:
    for key in ("HOME", "USERPROFILE"):
        value = os.environ.get(key, "").strip()
        if value:
            return value

    drive = os.environ.get("HOMEDRIVE", "").strip()
    home_path = os.environ.get("HOMEPATH", "").strip()
    if drive and home_path:
        return f"{drive}{home_path}"
    return None


def _windows_profile_home_dir() -> str | None:
    try:
        import ctypes

        buffer = ctypes.create_unicode_buffer(32768)
        csidl_profile = 40
        if ctypes.windll.shell32.SHGetFolderPathW(None, csidl_profile, None, 0, buffer) == 0:
            value = buffer.value.strip()
            if value:
                return value
    except Exception:
        return None
    return None


def _platform_home_dir() -> str | None:
    if os.name == "nt":
        return _windows_profile_home_dir()
    try:
        import pwd

        return pwd.getpwuid(os.getuid()).pw_dir
    except Exception:
        return None


def user_home_dir() -> str:
    expanded = _raw_expanduser("~")
    if expanded and expanded != "~":
        return os.path.abspath(expanded)

    env_home = _env_home_dir()
    if env_home:
        return os.path.abspath(env_home)

    platform_home = _platform_home_dir()
    if platform_home:
        return os.path.abspath(platform_home)

    raise RuntimeError("Unable to resolve the current user's home directory.")


def expand_home(path: str | os.PathLike[str]) -> str:
    raw_path = os.fspath(path)
    expanded = _raw_expanduser(raw_path)
    if expanded != raw_path or not raw_path.startswith("~"):
        return expanded

    if raw_path == "~":
        return user_home_dir()
    if raw_path.startswith("~/") or raw_path.startswith("~\\"):
        suffix = raw_path[2:].replace("\\", os.sep).replace("/", os.sep)
        return os.path.join(user_home_dir(), suffix)
    return expanded


def resolve_path(path: str | os.PathLike[str]) -> str:
    return os.path.abspath(expand_home(path))


def whispers_path(*parts: str) -> str:
    return os.path.abspath(os.path.join(user_home_dir(), ".whispers", *parts))


def abbreviate_home(path: str | os.PathLike[str]) -> str:
    resolved = resolve_path(path)
    home = user_home_dir()
    normalized_resolved = os.path.normcase(resolved)
    normalized_home = os.path.normcase(os.path.abspath(home))

    if normalized_resolved == normalized_home:
        return "~"

    home_prefix = normalized_home.rstrip("\\/")
    if normalized_resolved.startswith(home_prefix + os.sep):
        relative = os.path.relpath(resolved, home)
        return os.path.join("~", relative)

    return resolved
