"""Metadata minimization for agent-facing message delivery.

Security item #9: Agents receive only the fields they need. Internal
routing state, DB row IDs, policy metadata, and delivery tracking
internals are stripped before messages reach agent context windows.

This reduces:
- Information leakage (agents don't see routing decisions about them)
- Context window waste (fewer tokens per message)
- Attack surface (less internal state to probe)
"""
from __future__ import annotations

import json
import logging
from typing import Any

logger = logging.getLogger("whispers")

# Fields that agents should never see — DB internals, routing state
_STRIP_FIELDS = frozenset({
    "recipient_row_id",       # DB internal row ID
    "claimed_by",             # Delivery routing internal
    "claimed_at",             # Delivery routing internal
    "negotiation_id",         # Protocol negotiation internal
    "turn_number",            # Negotiation phase tracking
    "turns_total",            # Negotiation phase tracking
    "idempotency_key",        # Dedup internal
    "seen_at",                # System tracking
    "ttl_seconds",            # Already applied by routing
    "acked_by",               # Ack system internal
    "acked_at",               # Ack system internal
    "ack_detail",             # Ack system internal
    "pinned_at",              # Inbox management (exposed via message_action)
    "snoozed_until",          # Inbox management (exposed via message_action)
    "archived_at",            # Inbox management (exposed via message_action)
    "content_type",           # Almost always "text/plain", noise
    "recipient_callsign",     # Redundant with to_agent
    "durable_at",             # System internal
})

# Metadata dict keys that are routing policy internals
_STRIP_METADATA_KEYS = frozenset({
    "whispers_audience_scope",
    "whispers_visibility_mode",
    "whispers_memory_mode",
})

# Metadata keys with this prefix are system internals UNLESS they're
# redaction flags (which agents should see so they know content was stripped)
_INTERNAL_PREFIX = "whispers:"
_KEEP_PREFIXED_KEYS = frozenset({
    "whispers:scope_redacted",
    "whispers:scope_redaction_reason",
    "whispers:scope_redaction_mode",
    "whispers:working_scope",
})


def sanitize_message(msg: dict[str, Any]) -> dict[str, Any]:
    """Strip internal fields from a message dict before agent delivery.

    Returns a new dict with only agent-relevant fields. The original
    dict is not modified.
    """
    result = {k: v for k, v in msg.items() if k not in _STRIP_FIELDS}

    # Clean the metadata dict if present
    raw_meta = result.get("metadata")
    if raw_meta:
        meta = raw_meta
        if isinstance(meta, str):
            try:
                meta = json.loads(meta)
            except (json.JSONDecodeError, TypeError):
                meta = None

        if isinstance(meta, dict):
            cleaned = {}
            for k, v in meta.items():
                if k in _STRIP_METADATA_KEYS:
                    continue
                if k.startswith(_INTERNAL_PREFIX) and k not in _KEEP_PREFIXED_KEYS:
                    continue
                cleaned[k] = v
            result["metadata"] = json.dumps(cleaned) if isinstance(raw_meta, str) else cleaned
        elif meta is None and isinstance(raw_meta, str):
            # Unparseable metadata — strip it entirely
            result["metadata"] = "{}" if isinstance(raw_meta, str) else {}

    return result


def sanitize_messages(messages: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Sanitize a list of messages for agent delivery."""
    return [sanitize_message(m) for m in messages]
