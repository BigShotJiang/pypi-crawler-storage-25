import hashlib
import random
import re


REMOTE_CALLSIGN_RE = re.compile(r"^[a-z][a-z0-9-]{1,30}[a-z0-9]$")

# Wordlists for auto-generated callsigns: {adjective}-{noun}-{suffix}
_ADJECTIVES = [
    "swift", "calm", "keen", "bold", "warm", "cool", "fast", "pure",
    "bright", "sharp", "quiet", "deep", "clear", "soft", "steady",
    "gentle", "vivid", "eager", "lucid", "nimble",
]
_NOUNS = [
    "river", "spark", "ember", "frost", "cedar", "coral", "flint",
    "maple", "stone", "cloud", "brook", "ridge", "grove", "lark",
    "crane", "raven", "otter", "birch", "sage", "delta",
]
_HANDLE_PART_RE = re.compile(r"[^a-z0-9]+")
RESERVED_CALLSIGNS = frozenset({
    "system",
    "broadcast",
    "all",
    "whispers",
    "admin",
    "root",
})
INTERNAL_IDENTITIES = frozenset({
    "_probe",
    "_health_check",
})
MAX_PUBLIC_KEY_LENGTH = 16384


def validate_remote_callsign(callsign: str, *, allow_internal: bool = True) -> str | None:
    """Validate a public/remote callsign. Returns an error string or None."""
    if allow_internal and callsign in INTERNAL_IDENTITIES:
        return None
    if callsign in RESERVED_CALLSIGNS:
        return f"Callsign '{callsign}' is reserved. Choose a different name."
    if not REMOTE_CALLSIGN_RE.match(callsign):
        return (
            f"Invalid callsign '{callsign}'. Must be 3-32 chars, lowercase letters, "
            f"digits, and hyphens. Must start with a letter and end with a letter or digit."
        )
    return None


def normalize_callsign_part(value: str, *, fallback: str = "agent") -> str:
    """Normalize a human label into a valid callsign fragment."""
    normalized = _HANDLE_PART_RE.sub("-", (value or "").strip().lower()).strip("-")
    if not normalized:
        normalized = fallback
    if not normalized[0].isalpha():
        normalized = f"a-{normalized}"
    normalized = normalized.strip("-")
    return normalized or fallback


def suggest_callsign(owner_slug: str, surface: str, *, max_length: int = 32) -> str:
    """Build a deterministic owner-prefixed callsign like `z4rivers-codex`."""
    owner = normalize_callsign_part(owner_slug, fallback="agent")
    surface_part = normalize_callsign_part(surface, fallback="agent")
    candidate = f"{owner}-{surface_part}"
    if len(candidate) <= max_length:
        return candidate

    max_owner = max(3, min(len(owner), max_length - 3))
    owner = owner[:max_owner].rstrip("-")
    remaining = max_length - len(owner) - 1
    surface_part = surface_part[:max(1, remaining)].rstrip("-")
    candidate = f"{owner}-{surface_part}".strip("-")

    if candidate and candidate[-1] == "-":
        candidate = candidate[:-1]
    if candidate and not candidate[-1].isalnum():
        candidate = candidate[:-1] + "x"
    if candidate and candidate[0].isdigit():
        candidate = f"a-{candidate}"[:max_length].rstrip("-")
    return candidate


def suggest_display_name(surface: str) -> str:
    label = normalize_callsign_part(surface, fallback="agent")
    return " ".join(part.capitalize() for part in label.split("-"))


def generate_callsign(*, prefix: str = "") -> str:
    """Generate a friendly random callsign like 'swift-cedar' or 'agent-keen-spark'.

    If prefix is provided, produces '{prefix}-{adjective}-{noun}'.
    Otherwise produces '{adjective}-{noun}'.
    """
    adj = random.choice(_ADJECTIVES)
    noun = random.choice(_NOUNS)
    if prefix:
        return f"{normalize_callsign_part(prefix)}-{adj}-{noun}"
    return f"{adj}-{noun}"


def normalize_public_key(public_key: str) -> str:
    normalized = (public_key or "").strip()
    if not normalized:
        raise ValueError("Missing public key.")
    if len(normalized) > MAX_PUBLIC_KEY_LENGTH:
        raise ValueError(f"Public key is too large. Limit is {MAX_PUBLIC_KEY_LENGTH} characters.")
    return normalized


def fingerprint_public_key(public_key: str | None) -> str | None:
    if not public_key:
        return None
    digest = hashlib.sha256(public_key.encode("utf-8")).hexdigest()
    return f"sha256:{digest[:16]}"
