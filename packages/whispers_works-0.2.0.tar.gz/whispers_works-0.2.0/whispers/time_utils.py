import os
from datetime import datetime, timezone
from typing import Any, Iterable
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError


def utc_now() -> datetime:
    return datetime.now(timezone.utc)


def utc_now_iso() -> str:
    return to_utc_iso(utc_now())


def to_utc_iso(value: datetime) -> str:
    dt = value.astimezone(timezone.utc) if value.tzinfo else value.replace(tzinfo=timezone.utc)
    return dt.replace(microsecond=0).isoformat().replace("+00:00", "Z")


def local_timezone():
    configured = os.getenv("WHISPERS_TIMEZONE") or os.getenv("TZ")
    if configured:
        try:
            return ZoneInfo(configured)
        except ZoneInfoNotFoundError:
            pass

    local_tz = datetime.now().astimezone().tzinfo
    return local_tz or timezone.utc


def local_timezone_label() -> str:
    tz = local_timezone()
    key = getattr(tz, "key", None)
    if key:
        return key
    return datetime.now(tz).tzname() or str(tz)


def parse_timestamp(value: Any) -> datetime | None:
    if value is None or value == "":
        return None

    if isinstance(value, datetime):
        dt = value
    else:
        raw = str(value).strip()
        if not raw:
            return None
        normalized = raw.replace("Z", "+00:00")
        try:
            dt = datetime.fromisoformat(normalized)
        except ValueError:
            try:
                dt = datetime.strptime(raw, "%Y-%m-%d %H:%M:%S")
            except ValueError:
                return None

    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(timezone.utc)


def format_local_timestamp(value: Any, *, include_utc: bool = False) -> str | None:
    dt = parse_timestamp(value)
    if dt is None:
        return None

    local_dt = dt.astimezone(local_timezone())
    rendered = local_dt.strftime("%Y-%m-%d %I:%M:%S %p %Z")
    rendered = rendered.replace(" 0", " ")
    if include_utc:
        rendered = f"{rendered} ({to_utc_iso(dt)})"
    return rendered


def add_local_timestamp_fields(record: dict[str, Any], keys: Iterable[str]) -> dict[str, Any]:
    enriched = dict(record)
    for key in keys:
        if key in enriched and enriched[key]:
            local_value = format_local_timestamp(enriched[key])
            if local_value:
                enriched[f"{key}_local"] = local_value
    return enriched
