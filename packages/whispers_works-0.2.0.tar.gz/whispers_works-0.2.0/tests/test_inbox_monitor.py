"""Tests for the InboxMonitor auto-receive notification system.

Tests all three notification channels:
  Channel A: MCP log notification (tested indirectly via state tracking)
  Channel B: MCP resource subscription (tested via resource read)
  Channel C: Tool response injection (tested via alert generation)
"""

import json
import time
from concurrent.futures import TimeoutError as FutureTimeoutError
from unittest.mock import patch
import pytest
from whispers.testing import WhispersTestClient, WhispersTestHarness
from whispers.mcp_server import (
    InboxMonitor,
    _drop_notification_target,
    _get_notification_target,
    _remember_notification_target,
    _render_jolt_packet_resource_json,
    _render_jolt_resource_text,
)


class TestInboxMonitorAlerts:
    """Test Channel C: tool response injection alerts."""

    def test_no_alert_when_inbox_empty(self):
        """No alert generated when agent has no unread messages."""
        with WhispersTestClient("monitor-test") as client:
            monitor = InboxMonitor(poll_interval=0.5)
            monitor._check_agent("monitor-test", client)
            alert = monitor.get_and_clear_alert("monitor-test")
            assert alert == ""

    def test_alert_generated_on_unread_message(self):
        """Alert generated when agent has unread messages."""
        with WhispersTestHarness() as harness:
            alice = harness.make_client("alice")
            bob = harness.make_client("bob")

            alice.send("bob", "Hello Bob!", body="Testing auto-receive")

            monitor = InboxMonitor(poll_interval=0.5)
            monitor._check_agent("bob", bob)
            alert = monitor.get_and_clear_alert("bob")
            assert "1 unread" in alert
            assert "alice" in alert
            assert "Hello Bob!" in alert

    def test_alert_cleared_after_retrieval(self):
        """Alert is cleared after get_and_clear_alert."""
        with WhispersTestHarness() as harness:
            alice = harness.make_client("alice")
            bob = harness.make_client("bob")

            alice.send("bob", "Test message")

            monitor = InboxMonitor(poll_interval=0.5)
            monitor._check_agent("bob", bob)
            first = monitor.get_and_clear_alert("bob")
            assert first != ""
            second = monitor.get_and_clear_alert("bob")
            assert second == ""

    def test_peek_alert_does_not_consume(self):
        """Status/resource reads should be able to inspect alerts without clearing them."""
        monitor = InboxMonitor(poll_interval=0.5)
        monitor._pending_alerts["codex"] = "test alert"
        assert monitor.peek_alert("codex") == "test alert"
        assert monitor.get_and_clear_alert("codex") == "test alert"

    def test_flash_priority_highlighted(self):
        """FLASH priority messages get special highlighting."""
        with WhispersTestHarness() as harness:
            alice = harness.make_client("alice")
            bob = harness.make_client("bob")

            alice.send("bob", "URGENT", priority="flash")

            monitor = InboxMonitor(poll_interval=0.5)
            monitor._check_agent("bob", bob)
            alert = monitor.get_and_clear_alert("bob")
            assert "FLASH" in alert
            assert "⚡" in alert  # yellow lightning emoji

    def test_multiple_messages_previewed(self):
        """Multiple unread messages show previews."""
        with WhispersTestHarness() as harness:
            alice = harness.make_client("alice")
            bob = harness.make_client("bob")

            alice.send("bob", "First message")
            alice.send("bob", "Second message")
            alice.send("bob", "Third message")

            monitor = InboxMonitor(poll_interval=0.5)
            monitor._check_agent("bob", bob)
            alert = monitor.get_and_clear_alert("bob")
            assert "3 unread" in alert
            assert "First message" in alert
            assert "Second message" in alert
            assert "Third message" in alert

    def test_alert_preview_surfaces_blob_label_when_attachment_present(self):
        """Unread previews should make blob-bearing messages visibly distinct."""
        alert = InboxMonitor._format_alert_text(
            1,
            0,
            [
                {
                    "from_agent": "antigravity",
                    "subject": "Schema draft",
                    "priority": "routine",
                    "msg_type": "inform",
                    "payload": {
                        "attachment": {
                            "ref": "sha256:abc123",
                            "label": "descriptor-spec",
                        }
                    },
                }
            ],
        )
        assert "Schema draft | blob: descriptor-spec" in alert

    def test_alert_cleared_when_messages_read(self):
        """Alert disappears once messages are read."""
        with WhispersTestHarness() as harness:
            alice = harness.make_client("alice")
            bob = harness.make_client("bob")

            alice.send("bob", "Read me")

            monitor = InboxMonitor(poll_interval=0.5)
            monitor._check_agent("bob", bob)
            assert monitor.get_and_clear_alert("bob") != ""

            # Bob reads messages
            bob.check_inbox()

            # Re-check — alert should clear
            monitor._check_agent("bob", bob)
            alert = monitor.get_and_clear_alert("bob")
            assert alert == ""

    def test_message_check_prompt(self):
        """Alert includes instruction to call message_check."""
        with WhispersTestHarness() as harness:
            alice = harness.make_client("alice")
            bob = harness.make_client("bob")

            alice.send("bob", "Check this")

            monitor = InboxMonitor(poll_interval=0.5)
            monitor._check_agent("bob", bob)
            alert = monitor.get_and_clear_alert("bob")
            assert "message_check" in alert

    def test_reply_like_messages_are_marked_as_active_collaborator_updates(self):
        """Reply/checkpoint traffic should stand out from generic unread backlog."""
        with WhispersTestHarness() as harness:
            alice = harness.make_client("alice")
            bob = harness.make_client("bob")

            original = alice.send("bob", "Initial request")
            bob.send(
                "alice",
                "Re: Initial request",
                msg_type="checkpoint",
                reply_to=original["id"],
            )

            monitor = InboxMonitor(poll_interval=0.5)
            monitor._check_agent("alice", alice)
            alert = monitor.get_and_clear_alert("alice")
            assert "active collaborator reply waiting" in alert
            assert "Re: Initial request" in alert

    def test_format_alert_text_marks_active_collaborator_reply_without_db(self):
        """Pure formatter test for collaborator replies, independent of DB setup."""
        alert = InboxMonitor._format_alert_text(
            1,
            0,
            [
                {
                    "from_agent": "antigravity",
                    "subject": "Re: Roadmap check",
                    "priority": "routine",
                    "msg_type": "checkpoint",
                    "reply_to": "msg-123",
                }
            ],
        )
        assert "active collaborator reply waiting" in alert
        assert "antigravity" in alert
        assert "Re: Roadmap check" in alert

    def test_format_alert_text_marks_hot_thread_reply_when_flagged(self):
        """Formatter should use stronger wording when the unread reply belongs to a watched thread."""
        alert = InboxMonitor._format_alert_text(
            1,
            0,
            [
                {
                    "from_agent": "claude-code",
                    "subject": "Re: Narrator contract",
                    "priority": "routine",
                    "msg_type": "inform",
                    "reply_to": "msg-hot-thread",
                    "is_hot_thread_reply": True,
                }
            ],
        )
        assert "hot thread reply from claude-code" in alert
        assert "[hot thread]" in alert

    def test_format_thread_watch_alert_text_surfaces_delivery_age(self):
        """Thread-watch alerts should say how long the message has been delivered and unread."""
        alert = InboxMonitor._format_thread_watch_alert_text(
            [
                {
                    "counterpart": "antigravity",
                    "subject": "Re: baton truth",
                    "stage": "awaiting_read",
                    "stage_label": "delivered",
                    "age_label": "2m",
                }
            ]
        )
        assert "waiting on antigravity to read" in alert
        assert "delivered 2m ago" in alert

    def test_format_thread_watch_alert_text_surfaces_sent_age_for_delivery_queue(self):
        """Queued thread-watch alerts should preserve how long the outbound follow-up has been waiting."""
        alert = InboxMonitor._format_thread_watch_alert_text(
            [
                {
                    "counterpart": "claude-code",
                    "subject": "Re: Narrator contract",
                    "stage": "awaiting_delivery",
                    "stage_label": "sent",
                    "age_label": "45s",
                }
            ]
        )
        assert "delivery pending to claude-code" in alert
        assert "sent 45s ago" in alert

    def test_format_thread_watch_alert_text_surfaces_read_age_for_reply_wait(self):
        """Reply-wait alerts should preserve how long ago the peer read the message."""
        alert = InboxMonitor._format_thread_watch_alert_text(
            [
                {
                    "counterpart": "claude-code",
                    "subject": "Re: Narrator contract",
                    "stage": "awaiting_reply",
                    "stage_label": "read",
                    "age_label": "45s",
                }
            ]
        )
        assert "claude-code read it" in alert
        assert "read 45s ago" in alert

    def test_active_collaborator_reply_classifier(self):
        """Reply/checkpoint metadata should trigger collaborator-reply classification."""
        assert InboxMonitor._is_active_collaborator_reply(
            [
                {
                    "from_agent": "antigravity",
                    "subject": "Roadmap check",
                    "priority": "routine",
                    "msg_type": "checkpoint",
                    "reply_to": None,
                }
            ]
        )
        assert not InboxMonitor._is_active_collaborator_reply(
            [
                {
                    "from_agent": "antigravity",
                    "subject": "FYI",
                    "priority": "routine",
                    "msg_type": "inform",
                    "reply_to": None,
                }
            ]
        )

    def test_active_collaborator_replies_get_warning_interrupt_weight(self):
        """Collaborator replies should be raised above ordinary info-level unread notices."""
        assert InboxMonitor._log_level_for_alert(1, flash_count=0, active_reply=True) == "warning"
        assert InboxMonitor._log_level_for_alert(1, flash_count=0, active_reply=False) == "info"

    def test_hot_thread_reply_classifier_requires_follow_up_parent(self):
        """A reply only counts as hot-thread-specific when it answers one of our follow-up thread messages."""
        assert InboxMonitor._is_hot_thread_reply(
            {
                "from_agent": "claude-code",
                "reply_to": "msg-reply",
                "reply_to_sender": "codex",
                "reply_to_recipient": "claude-code",
                "reply_to_subject": "Re: Narrator contract",
                "reply_to_msg_type": "inform",
                "reply_to_parent": "msg-earlier",
            },
            viewer_aliases={"codex"},
        )
        assert not InboxMonitor._is_hot_thread_reply(
            {
                "from_agent": "claude-code",
                "reply_to": "msg-reply",
                "reply_to_sender": "codex",
                "reply_to_recipient": "claude-code",
                "reply_to_subject": "Initial request",
                "reply_to_msg_type": "inform",
                "reply_to_parent": None,
            },
            viewer_aliases={"codex"},
        )

    def test_hot_thread_watch_alert_generated_without_unread_inbox(self):
        """A sender waiting on a live reply thread should get a status-side alert even with zero unread."""
        with WhispersTestHarness() as harness:
            alice = harness.make_client("alice")
            bob = harness.make_client("bob")

            original = bob.send("alice", "Question for Alice")
            alice.check_inbox(mark_seen=True)
            alice.send("bob", "Re: Question for Alice", reply_to=original["id"])

            monitor = InboxMonitor(poll_interval=0.5)
            monitor._check_agent("alice", alice)
            alert = monitor.get_and_clear_alert("alice")

            assert "hot thread update" in alert
            assert "Re: Question for Alice" in alert
            assert "bob" in alert
            assert ("waiting on bob to read" in alert) or ("delivery pending to bob" in alert)

    def test_watched_thread_reply_uses_thread_specific_wording(self):
        """A real reply to a watched thread should not collapse back to generic collaborator-reply wording."""
        with WhispersTestHarness() as harness:
            alice = harness.make_client("alice")
            bob = harness.make_client("bob")

            original = bob.send("alice", "Question for Alice")
            alice.check_inbox(mark_seen=True)
            follow_up = alice.send("bob", "Re: Question for Alice", reply_to=original["id"])
            bob.check_inbox(mark_seen=True)
            bob.send("alice", "Re: Question for Alice", reply_to=follow_up["id"])

            monitor = InboxMonitor(poll_interval=0.5)
            monitor._check_agent("alice", alice)
            alert = monitor.get_and_clear_alert("alice")

            assert "hot thread reply from bob" in alert
            assert "[hot thread]" in alert
            assert "active collaborator reply waiting" not in alert

    def test_hot_thread_stage_change_fires_status_update_without_new_unread(self):
        """When a watched thread advances from sent to read, the status resource should be pushed."""
        with WhispersTestHarness() as harness:
            alice = harness.make_client("alice")
            bob = harness.make_client("bob")

            original = bob.send("alice", "Question for Alice")
            alice.check_inbox(mark_seen=True)
            alice.send("bob", "Re: Question for Alice", reply_to=original["id"])

            monitor = InboxMonitor(poll_interval=0.5)
            resource_updates: list[tuple[str, str]] = []
            log_events: list[tuple[str, str, str]] = []
            monitor._fire_resource_update = lambda agent, uri: resource_updates.append((agent, uri))
            monitor._fire_log_notification = lambda agent, text, level: log_events.append((agent, text, level))

            monitor._check_agent("alice", alice)
            resource_updates.clear()
            log_events.clear()

            bob.check_inbox(mark_seen=True)
            monitor._check_agent("alice", alice)

            assert ("alice", "whispers://jolt") in resource_updates
            assert ("alice", "whispers://jolt-packet") in resource_updates
            assert ("alice", "whispers://status") in resource_updates
            assert any("hot thread update" in text for _, text, _ in log_events)
            assert any("read it" in text for _, text, _ in log_events)

    def test_routine_new_message_fires_jolt_resource_update(self):
        """A normal new assignment should still push the Jolt wake surface without requiring flash/reply semantics."""
        with WhispersTestHarness() as harness:
            alice = harness.make_client("alice")
            bob = harness.make_client("bob")

            alice.send("bob", "Assignment: wire Jolt")

            monitor = InboxMonitor(poll_interval=0.5)
            resource_updates: list[tuple[str, str]] = []
            monitor._fire_resource_update = lambda agent, uri: resource_updates.append((agent, uri))
            monitor._fire_log_notification = lambda agent, text, level: None

            monitor._check_agent("bob", bob)

            assert ("bob", "whispers://inbox") in resource_updates
            assert ("bob", "whispers://jolt") in resource_updates
            assert ("bob", "whispers://jolt-packet") in resource_updates
            assert ("bob", "whispers://status") not in resource_updates

    def test_clearing_unread_state_pushes_jolt_resource_update(self):
        """When the wake condition clears, Jolt subscribers should receive an update so the resource can go idle."""
        with WhispersTestHarness() as harness:
            alice = harness.make_client("alice")
            bob = harness.make_client("bob")

            alice.send("bob", "Assignment: wire Jolt")

            monitor = InboxMonitor(poll_interval=0.5)
            resource_updates: list[tuple[str, str]] = []
            monitor._fire_resource_update = lambda agent, uri: resource_updates.append((agent, uri))
            monitor._fire_log_notification = lambda agent, text, level: None

            monitor._check_agent("bob", bob)
            resource_updates.clear()

            bob.check_inbox(mark_seen=True)
            monitor._check_agent("bob", bob)

            assert ("bob", "whispers://jolt") in resource_updates
            assert ("bob", "whispers://jolt-packet") in resource_updates

    def test_render_jolt_resource_text_surfaces_live_packet(self):
        """The dedicated Jolt resource should expose the actionable wake packet, not just a generic status dump."""
        text = _render_jolt_resource_text(
            "codex",
            status_snapshot={
                "jolt_packet": {
                    "action": "stage_context",
                    "trigger": "direct_assignment",
                    "headline": "1 assignment waiting",
                    "priority": "priority",
                    "interruptibility": "defer",
                    "blocking": True,
                    "explicitly_addressed": True,
                    "recommended_action": "Start assignment from claude-code.",
                    "freshness": "stale",
                    "age_label": "6m",
                    "source_stage": "reply_ready",
                    "stale_after_seconds": 240,
                    "reasons": ["direct assignment waiting", "host can stage context"],
                    "adapter": {
                        "adapter_kind": "managed_pty",
                        "supported_actions": ["notify", "stage_context"],
                        "fallback_action": "notify",
                    },
                }
            },
        )

        assert "Jolt for codex: stage_context" in text
        assert "Headline: 1 assignment waiting" in text
        assert "Recommended action: Start assignment from claude-code." in text
        assert "Freshness: stale | reply ready | 6m old | target <= 4m" in text
        assert "Adapter: managed_pty | actions notify, stage_context | fallback notify" in text
        assert "whispers://jolt-packet" in text

    def test_render_jolt_packet_resource_json_surfaces_live_packet(self):
        payload = json.loads(
            _render_jolt_packet_resource_json(
                "codex",
                status_snapshot={
                    "jolt_packet": {
                        "action": "stage_context",
                        "trigger": "direct_assignment",
                        "headline": "1 assignment waiting",
                        "freshness": "fresh",
                    }
                },
            )
        )

        assert payload["agent_name"] == "codex"
        assert payload["resource"] == "whispers://jolt-packet"
        assert payload["state"] == "active"
        assert payload["jolt_packet"]["action"] == "stage_context"
        assert payload["jolt_packet"]["headline"] == "1 assignment waiting"

    def test_notification_targets_are_tracked_per_agent(self):
        """Background notifications should not collapse to one global last session."""
        session_a = object()
        session_b = object()
        loop_a = object()
        loop_b = object()

        _remember_notification_target("alice", session_a, loop_a)
        _remember_notification_target("bob", session_b, loop_b)

        assert _get_notification_target("alice") == (session_a, loop_a)
        assert _get_notification_target("bob") == (session_b, loop_b)

        _drop_notification_target("alice")
        _drop_notification_target("bob")

    def test_drop_notification_target_respects_session_identity(self):
        """Dropping one stale session should not clear a newer registration."""
        session_old = object()
        session_new = object()
        loop_old = object()
        loop_new = object()

        _remember_notification_target("codex", session_old, loop_old)
        _remember_notification_target("codex", session_new, loop_new)
        _drop_notification_target("codex", session=session_old)

        assert _get_notification_target("codex") == (session_new, loop_new)

        _drop_notification_target("codex")

    def test_log_notification_timeout_drops_stale_target(self):
        """A stalled session send should be bounded and evicted."""

        class _Loop:
            @staticmethod
            def is_running():
                return True

        class _Session:
            @staticmethod
            def send_log_message(**kwargs):
                return object()

        class _Future:
            def __init__(self):
                self.cancelled = False

            def result(self, timeout=None):
                raise FutureTimeoutError()

            def cancel(self):
                self.cancelled = True

        monitor = InboxMonitor(poll_interval=0.5)
        session = _Session()
        loop = _Loop()
        future = _Future()

        _remember_notification_target("codex", session, loop)

        with patch("whispers.mcp_server.asyncio.run_coroutine_threadsafe", return_value=future):
            monitor._fire_log_notification("codex", "stalled alert", "warning")

        assert future.cancelled is True
        assert _get_notification_target("codex") == (None, None)


class TestInboxMonitorNewArrival:
    """Test that channels A/B only fire on real NEW arrivals."""

    def test_no_refire_on_same_count(self):
        """Don't re-fire A/B notifications when unread count stays the same."""
        with WhispersTestHarness() as harness:
            alice = harness.make_client("alice")
            bob = harness.make_client("bob")

            alice.send("bob", "Test msg")

            monitor = InboxMonitor(poll_interval=0.5)

            # First check — sets baseline
            monitor._check_agent("bob", bob)
            assert monitor._last_unread["bob"] == 1

            # Second check — same count, no new arrival
            monitor._check_agent("bob", bob)
            # Alert should still be set (for Channel C)
            # but _last_unread shouldn't trigger A/B again
            assert monitor._last_unread["bob"] == 1

    def test_fires_on_count_increase(self):
        """Fire notifications when new messages arrive (count increases)."""
        with WhispersTestHarness() as harness:
            alice = harness.make_client("alice")
            bob = harness.make_client("bob")

            alice.send("bob", "First")

            monitor = InboxMonitor(poll_interval=0.5)

            monitor._check_agent("bob", bob)
            assert monitor._last_unread["bob"] == 1

            # New message arrives
            alice.send("bob", "Second")
            monitor._check_agent("bob", bob)
            assert monitor._last_unread["bob"] == 2

            alert = monitor.get_and_clear_alert("bob")
            assert "2 unread" in alert

    def test_detects_new_arrival_when_head_advances_with_flat_count(self):
        """A new reply should still count as new arrival if another unread was read."""
        previous_head = ("2026-03-26T10:00:00Z", "msg-old")
        current_head = ("2026-03-26T10:05:00Z", "msg-new")

        assert InboxMonitor._has_new_arrival(
            2,
            2,
            previous_head,
            current_head,
        )

    def test_ignores_older_head_when_count_drops(self):
        """Reading the newest unread should not masquerade as a new arrival."""
        previous_head = ("2026-03-26T10:05:00Z", "msg-new")
        current_head = ("2026-03-26T10:00:00Z", "msg-old")

        assert not InboxMonitor._has_new_arrival(
            2,
            1,
            previous_head,
            current_head,
        )


class TestInboxMonitorLifecycle:
    """Test monitor start/stop behavior."""

    def test_start_and_stop(self):
        """Monitor starts and stops cleanly."""
        monitor = InboxMonitor(poll_interval=0.5)
        monitor.start()
        assert monitor._thread is not None
        assert monitor._thread.is_alive()

        monitor.stop()
        assert not monitor._thread or not monitor._thread.is_alive()

    def test_double_start_is_safe(self):
        """Calling start twice doesn't create duplicate threads."""
        monitor = InboxMonitor(poll_interval=0.5)
        monitor.start()
        thread1 = monitor._thread
        monitor.start()
        thread2 = monitor._thread
        assert thread1 is thread2
        monitor.stop()

    def test_daemon_thread(self):
        """Monitor thread is a daemon (dies with main process)."""
        monitor = InboxMonitor(poll_interval=0.5)
        monitor.start()
        assert monitor._thread.daemon
        monitor.stop()

    def test_poll_interval_backs_off_when_idle_and_resets_on_change(self):
        """Idle polling should back off; new activity should reset to base interval."""
        monitor = InboxMonitor(poll_interval=1.0, max_poll_interval=8.0)

        assert monitor._current_interval == 1.0

        monitor._advance_poll_interval(changed=False)
        assert monitor._current_interval == 2.0

        monitor._advance_poll_interval(changed=False)
        assert monitor._current_interval == 4.0

        monitor._advance_poll_interval(changed=False)
        assert monitor._current_interval == 8.0

        monitor._advance_poll_interval(changed=False)
        assert monitor._current_interval == 8.0

        monitor._advance_poll_interval(changed=True)
        assert monitor._current_interval == 1.0


class TestInboxMonitorOverflow:
    """Test behavior with many messages."""

    def test_more_than_3_shows_overflow(self):
        """When more than 3 unread messages, shows overflow count."""
        with WhispersTestHarness() as harness:
            alice = harness.make_client("alice")
            bob = harness.make_client("bob")

            for i in range(5):
                alice.send("bob", f"Message {i+1}")

            monitor = InboxMonitor(poll_interval=0.5)
            monitor._check_agent("bob", bob)
            alert = monitor.get_and_clear_alert("bob")
            assert "5 unread" in alert
            assert "... and 2 more" in alert


class TestInboxMonitorConcurrency:
    """Test that InboxMonitor doesn't block concurrent DB access."""

    def test_monitor_does_not_block_writer(self):
        """InboxMonitor read-only polling must not prevent concurrent writes."""
        import sqlite3
        import threading

        with WhispersTestHarness() as harness:
            alice = harness.make_client("alice")
            bob = harness.make_client("bob")

            alice.send("bob", "Setup message")

            monitor = InboxMonitor(poll_interval=0.1)
            monitor.start()

            # Inject bob into the monitor's view
            from whispers.mcp_server import _clients as mcp_clients
            mcp_clients["bob"] = bob

            write_succeeded = threading.Event()
            write_error = []

            def concurrent_writer():
                """Try to write while the monitor is polling."""
                try:
                    for _ in range(5):
                        alice.send("bob", "Concurrent write")
                    write_succeeded.set()
                except Exception as e:
                    write_error.append(str(e))

            # Let monitor run a few poll cycles
            import time
            time.sleep(0.3)

            # Now try writing concurrently
            writer = threading.Thread(target=concurrent_writer)
            writer.start()
            writer.join(timeout=10.0)

            monitor.stop()
            mcp_clients.pop("bob", None)

            assert write_succeeded.is_set(), f"Write failed: {write_error}"

    def test_db_get_connection_has_busy_timeout(self):
        """Every connection from WhispersDB must have a busy_timeout set."""
        with WhispersTestClient("timeout-test") as client:
            conn = client.db.get_connection()
            try:
                row = conn.execute("PRAGMA busy_timeout").fetchone()
                timeout_ms = row[0]
                assert timeout_ms >= 5000, f"busy_timeout too low: {timeout_ms}ms"
            finally:
                conn.close()
