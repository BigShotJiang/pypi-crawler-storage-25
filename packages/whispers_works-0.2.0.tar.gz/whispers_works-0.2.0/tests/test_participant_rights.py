"""Tests for participant rights baseline (security item #10).

Covers:
- Self-disclosure returns agent card, trust tier, memberships, counts
- Challenge records security event for operator review
- Challenge rejected for events not involving the agent
- Challenge rejected for non-existent events
- Retention cleanup removes old security events
- Retention cleanup respects threshold boundaries
"""

import json
import uuid
import pytest
from whispers.participant_rights import get_self_disclosure, record_challenge, enforce_retention, RETENTION_POLICY


class TestParticipantRights:
    @pytest.fixture
    def setup(self, tmp_path):
        from whispers.storage.db import WhispersDB
        from whispers.client import WhispersClient

        db_path = str(tmp_path / "test_rights.db")
        db = WhispersDB(db_path=db_path)

        # Register an agent
        with db.get_connection() as conn:
            conn.execute(
                """INSERT INTO agent_cards (callsign, agent_type, trust_tier, registered_at)
                   VALUES (?, ?, ?, datetime('now'))""",
                ("alice", "llm", 2),
            )
            conn.execute(
                """INSERT INTO agent_cards (callsign, agent_type, trust_tier, registered_at)
                   VALUES (?, ?, ?, datetime('now'))""",
                ("bob", "remote_client", 1),
            )
            # Workspace and membership
            conn.execute(
                "INSERT INTO workspaces (workspace_id, purpose, status, created_by, created_at) VALUES (?, ?, ?, ?, datetime('now'))",
                ("ws_test", "Test workspace", "active", "operator"),
            )
            conn.execute(
                "INSERT INTO workspace_members (workspace_id, agent_name, membership_role, membership_state, joined_at) VALUES (?, ?, ?, ?, datetime('now'))",
                ("ws_test", "alice", "member", "active"),
            )
            conn.commit()

        alice = WhispersClient("alice", db_path=db_path)
        bob = WhispersClient("bob", db_path=db_path)
        return db, alice, bob

    # --- Disclosure tests ---

    def test_disclosure_includes_agent_card(self, setup):
        db, alice, bob = setup
        with db.get_readonly_connection() as conn:
            result = get_self_disclosure(conn, "alice")
        assert result["agent_name"] == "alice"
        assert result["agent_card"]["callsign"] == "alice"
        assert result["agent_card"]["agent_type"] == "llm"

    def test_disclosure_includes_trust_tier(self, setup):
        db, alice, bob = setup
        with db.get_readonly_connection() as conn:
            result = get_self_disclosure(conn, "alice")
        assert result["trust_tier"] == 2

    def test_disclosure_includes_workspace_memberships(self, setup):
        db, alice, bob = setup
        with db.get_readonly_connection() as conn:
            result = get_self_disclosure(conn, "alice")
        assert len(result["workspace_memberships"]) == 1
        assert result["workspace_memberships"][0]["workspace_id"] == "ws_test"

    def test_disclosure_includes_message_counts(self, setup):
        db, alice, bob = setup
        alice.send("bob", "test subject", body="hello")
        with db.get_readonly_connection() as conn:
            result = get_self_disclosure(conn, "alice")
        assert result["message_counts"]["sent"] >= 1

    def test_disclosure_includes_security_events(self, setup):
        db, alice, bob = setup
        db.record_security_event("test_event", "test_outcome", actor_agent="alice")
        with db.get_readonly_connection() as conn:
            result = get_self_disclosure(conn, "alice")
        assert len(result["recent_security_events"]) >= 1

    def test_disclosure_includes_blob_provenance(self, setup):
        db, alice, bob = setup
        alice.store_blob(b"test data", workspace_id="ws_test")
        with db.get_readonly_connection() as conn:
            result = get_self_disclosure(conn, "alice")
        assert len(result["blobs_stored"]) >= 1

    def test_disclosure_includes_retention_policy(self, setup):
        db, alice, bob = setup
        with db.get_readonly_connection() as conn:
            result = get_self_disclosure(conn, "alice")
        assert "retention_policy" in result
        assert "security_events" in result["retention_policy"]

    def test_disclosure_does_not_leak_private_keys(self, setup):
        db, alice, bob = setup
        with db.get_readonly_connection() as conn:
            result = get_self_disclosure(conn, "alice")
        card = result.get("agent_card", {})
        assert "public_key_pem" not in card
        assert "public_key_fingerprint" not in card

    def test_disclosure_for_nonexistent_agent(self, setup):
        db, alice, bob = setup
        with db.get_readonly_connection() as conn:
            result = get_self_disclosure(conn, "nobody")
        assert result["agent_name"] == "nobody"
        assert "agent_card" not in result
        assert result["trust_tier"] == 1  # default

    # --- Challenge tests ---

    def test_challenge_records_event(self, setup):
        db, alice, bob = setup
        event_id = db.record_security_event(
            "artifact_fetch", "cross_scope_blocked", actor_agent="alice"
        )
        with db.get_connection() as conn:
            result = record_challenge(conn, "alice", event_id, "I had delegation rights")
        assert "challenge_id" in result
        assert result["status"] == "pending_review"

    def test_challenge_creates_audit_trail(self, setup):
        db, alice, bob = setup
        event_id = db.record_security_event(
            "artifact_fetch", "cross_scope_blocked", actor_agent="alice"
        )
        with db.get_connection() as conn:
            result = record_challenge(conn, "alice", event_id, "Incorrect block")
        # Verify the challenge appears in security events
        with db.get_readonly_connection() as conn:
            row = conn.execute(
                "SELECT * FROM security_events WHERE event_id = ?",
                (result["challenge_id"],),
            ).fetchone()
        assert row is not None
        assert row["event_type"] == "participant_challenge"
        assert row["outcome"] == "pending_review"
        detail = json.loads(row["detail"])
        assert detail["challenged_event_id"] == event_id
        assert detail["challenge_reason"] == "Incorrect block"

    def test_challenge_rejected_for_uninvolved_agent(self, setup):
        db, alice, bob = setup
        event_id = db.record_security_event(
            "artifact_fetch", "cross_scope_blocked", actor_agent="alice"
        )
        with db.get_connection() as conn:
            result = record_challenge(conn, "bob", event_id, "I disagree")
        assert "error" in result
        assert "only challenge events that involved you" in result["error"]

    def test_challenge_rejected_for_nonexistent_event(self, setup):
        db, alice, bob = setup
        with db.get_connection() as conn:
            result = record_challenge(conn, "alice", "nonexistent-id", "Whatever")
        assert "error" in result
        assert "not found" in result["error"]

    def test_target_agent_can_challenge(self, setup):
        db, alice, bob = setup
        event_id = db.record_security_event(
            "scope_boundary", "blocked", actor_agent="alice", target_agent="bob"
        )
        with db.get_connection() as conn:
            result = record_challenge(conn, "bob", event_id, "I should have access")
        assert "challenge_id" in result

    # --- Retention tests ---

    def test_retention_cleans_old_security_events(self, setup):
        db, alice, bob = setup
        # Insert an old security event (older than 90 days)
        with db.get_connection() as conn:
            conn.execute(
                """INSERT INTO security_events
                   (event_id, event_type, outcome, actor_agent, created_at)
                   VALUES (?, ?, ?, ?, datetime('now', '-100 days'))""",
                (str(uuid.uuid4()), "old_event", "old_outcome", "alice"),
            )
            # Insert a recent one
            conn.execute(
                """INSERT INTO security_events
                   (event_id, event_type, outcome, actor_agent, created_at)
                   VALUES (?, ?, ?, ?, datetime('now'))""",
                (str(uuid.uuid4()), "new_event", "new_outcome", "alice"),
            )
            conn.commit()

        with db.get_connection() as conn:
            result = enforce_retention(conn)
        assert result["security_events"] >= 1

        # Verify old is gone, new is kept
        with db.get_readonly_connection() as conn:
            rows = conn.execute("SELECT event_type FROM security_events").fetchall()
        types = [r["event_type"] for r in rows]
        assert "old_event" not in types
        assert "new_event" in types

    def test_retention_cleans_old_blob_provenance(self, setup):
        db, alice, bob = setup
        with db.get_connection() as conn:
            conn.execute(
                "INSERT INTO blob_provenance (blob_ref, stored_by, created_at) VALUES (?, ?, datetime('now', '-200 days'))",
                ("sha256:oldblob", "alice"),
            )
            conn.execute(
                "INSERT INTO blob_provenance (blob_ref, stored_by, created_at) VALUES (?, ?, datetime('now'))",
                ("sha256:newblob", "alice"),
            )
            conn.commit()

        with db.get_connection() as conn:
            result = enforce_retention(conn)
        assert result["blob_provenance"] >= 1

        with db.get_readonly_connection() as conn:
            rows = conn.execute("SELECT blob_ref FROM blob_provenance").fetchall()
        refs = [r["blob_ref"] for r in rows]
        assert "sha256:oldblob" not in refs
        assert "sha256:newblob" in refs

    def test_retention_preserves_recent_data(self, setup):
        db, alice, bob = setup
        # Only recent data — nothing should be cleaned
        db.record_security_event("fresh_event", "fresh_outcome", actor_agent="alice")
        with db.get_connection() as conn:
            before = conn.execute("SELECT COUNT(*) as c FROM security_events").fetchone()["c"]
            result = enforce_retention(conn)
            after = conn.execute("SELECT COUNT(*) as c FROM security_events").fetchone()["c"]
        assert before == after
