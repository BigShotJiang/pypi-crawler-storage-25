"""Tests for cut-point availability broadcasts.

Covers:
- announce_available resets readiness to ready
- announce_available broadcasts listening state
- Open offer included in result
- Works without offer or completed_task
- Completed task context included
"""

import pytest


class TestCutPointBroadcast:
    @pytest.fixture
    def setup(self, tmp_path):
        from whispers.storage.db import WhispersDB
        from whispers.client import WhispersClient

        db_path = str(tmp_path / "test_cutpoint.db")
        db = WhispersDB(db_path=db_path)
        alice = WhispersClient("alice", db_path=db_path)
        return db, alice

    def test_resets_readiness(self, setup):
        db, alice = setup
        # Start busy
        alice.set_readiness("busy", current_task="Building feature")
        runtime = alice.get_runtime_state()
        assert runtime.get("readiness") == "busy"

        # Announce available
        alice.announce_available()
        runtime = alice.get_runtime_state()
        assert runtime.get("readiness") == "ready"

    def test_sets_attention_state(self, setup):
        db, alice = setup
        alice.announce_available(offer="free for review")
        runtime = alice.get_runtime_state()
        assert runtime.get("attention_state") == "needs_assignment"
        assert "free for review" in (runtime.get("attention_detail") or "")

    def test_result_includes_offer(self, setup):
        db, alice = setup
        result = alice.announce_available(offer="ready for next slice")
        assert result["readiness"] == "ready"
        assert result["state"] == "listening"
        assert result["offer"] == "ready for next slice"

    def test_works_without_params(self, setup):
        db, alice = setup
        result = alice.announce_available()
        assert result["readiness"] == "ready"
        assert result["offer"] is None

    def test_completed_task_context(self, setup):
        db, alice = setup
        result = alice.announce_available(
            completed_task="Security sprint item #7",
            offer="available for item #8",
        )
        assert result["readiness"] == "ready"
        assert result["offer"] == "available for item #8"
