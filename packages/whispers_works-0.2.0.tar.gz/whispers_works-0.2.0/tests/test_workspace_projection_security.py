import asyncio
import importlib
import json
import shutil
import sqlite3
import uuid
from pathlib import Path

import pytest
from fastapi.testclient import TestClient


def _make_case_dir() -> Path:
    root = Path(__file__).resolve().parents[1] / ".tmp"
    root.mkdir(parents=True, exist_ok=True)
    case_dir = root / f"workspace-projection-security-{uuid.uuid4().hex}"
    case_dir.mkdir(parents=True, exist_ok=False)
    return case_dir


def _connect_agent(api: TestClient, agent_name: str) -> dict[str, str]:
    response = api.post(
        "/connect",
        json={
            "agent_name": agent_name,
            "client": {"name": "pytest", "version": "1.0"},
            "capabilities": {"transport": "http"},
        },
    )
    assert response.status_code == 200
    token = response.json()["token"]
    return {"Authorization": f"Bearer {token}"}


def _send_headers(auth_headers: dict[str, str]) -> dict[str, str]:
    return {
        **auth_headers,
        "A2A-Version": "1.0",
    }


def _drain_events(queue: asyncio.Queue) -> list[dict]:
    items: list[dict] = []
    while True:
        try:
            items.append(queue.get_nowait())
        except asyncio.QueueEmpty:
            return items


def _latest_security_event(db_path: Path, outcome: str) -> sqlite3.Row | None:
    with sqlite3.connect(db_path) as conn:
        conn.row_factory = sqlite3.Row
        return conn.execute(
            """
            SELECT outcome, detail
            FROM security_events
            WHERE outcome = ?
            ORDER BY created_at DESC
            LIMIT 1
            """,
            (outcome,),
        ).fetchone()


def _load_server(monkeypatch: pytest.MonkeyPatch, case_dir: Path, db_path: Path):
    monkeypatch.setenv("WHISPERS_DB_PATH", str(db_path))
    monkeypatch.setenv("WHISPERS_REMOTE_ADMISSION_MODE", "open")
    monkeypatch.setenv("WHISPERS_RUNTIME_STATE_PATH", str(case_dir / "runtime-state.json"))

    import whispers.server as server_module

    return importlib.reload(server_module)


def test_observer_narrative_workspace_projection_is_blocked_and_audited(monkeypatch):
    case_dir = _make_case_dir()
    db_path = case_dir / "projection.db"

    try:
        server_module = _load_server(monkeypatch, case_dir, db_path)

        with TestClient(server_module.app) as api:
            alice_headers = _connect_agent(api, "alice")
            observer_headers = _connect_agent(api, "observer")

            listener = asyncio.Queue()
            server_module.operator_sse.add_listener("projection-security-test", listener)
            try:
                created = api.post(
                    "/workspace:create",
                    json={"purpose": "Narrative boundary", "join_policy": "open"},
                    headers=alice_headers,
                )
                assert created.status_code == 200
                workspace_id = created.json()["workspace_id"]

                joined = api.post(
                    "/workspace:join",
                    json={"workspace_id": workspace_id, "membership_role": "observer"},
                    headers=observer_headers,
                )
                assert joined.status_code == 200
                _drain_events(listener)

                published = api.post(
                    "/narrative",
                    json={
                        "stance": "annotation",
                        "narrative_text": "Observer should not inject room-visible narrative.",
                        "workspace_id": workspace_id,
                    },
                    headers=observer_headers,
                )
                assert published.status_code == 200

                events = _drain_events(listener)
                assert not any(
                    event.get("type") in {"workspace:delta", "workspace_delta"}
                    and isinstance(event.get("payload"), dict)
                    and event["payload"].get("workspace_id") == workspace_id
                    and event["payload"].get("delta_kind") == "narrative"
                    for event in events
                )
            finally:
                server_module.operator_sse.remove_listener("projection-security-test", listener)

        event = _latest_security_event(db_path, "workspace_narrative_projection_blocked_non_writer")
        assert event is not None
        detail = json.loads(event["detail"])
        assert detail["workspace_id"] == workspace_id
        assert detail["projection_kind"] == "narrative"
        assert detail["reason"] == "observer_projection"
        assert detail["projected"] is False
        assert "observers cannot inject room activity" in detail["explanation"]
    finally:
        shutil.rmtree(case_dir, ignore_errors=True)


def test_review_publish_non_member_stays_direct_and_records_scope_boundary(monkeypatch):
    case_dir = _make_case_dir()
    db_path = case_dir / "projection.db"

    try:
        server_module = _load_server(monkeypatch, case_dir, db_path)

        with TestClient(server_module.app) as api:
            alice_headers = _connect_agent(api, "alice")
            bob_headers = _connect_agent(api, "bob")
            charlie_headers = _connect_agent(api, "charlie")

            created = api.post(
                "/workspace:create",
                json={"purpose": "Review boundary", "join_policy": "open"},
                headers=alice_headers,
            )
            assert created.status_code == 200
            workspace_id = created.json()["workspace_id"]

            joined = api.post(
                "/workspace:join",
                json={"workspace_id": workspace_id},
                headers=bob_headers,
            )
            assert joined.status_code == 200

            sent = api.post(
                "/message:send",
                json={
                    "to": "bob",
                    "subject": "Review this change",
                    "body": "Direct review request.",
                    "msg_type": "propose",
                },
                headers=_send_headers(charlie_headers),
            )
            assert sent.status_code == 200
            signal_uuid = sent.json()["id"]

            publish = api.post(
                "/review/publish",
                json={
                    "signal_uuid": signal_uuid,
                    "topic": "Outsider review request",
                    "lens": "security",
                    "workspace_id": workspace_id,
                },
                headers=charlie_headers,
            )
            assert publish.status_code == 200

            state = api.get(
                f"/workspace:state/{workspace_id}",
                headers=alice_headers,
            )
            assert state.status_code == 200
            deltas = state.json()["deltas"]
            assert not any(delta["delta_kind"] == "review_published" for delta in deltas)

        event = _latest_security_event(db_path, "workspace_review_publish_projection_blocked_non_writer")
        assert event is not None
        detail = json.loads(event["detail"])
        assert detail["workspace_id"] == workspace_id
        assert detail["signal_uuid"] == signal_uuid
        assert detail["projection_kind"] == "review_publish"
        assert detail["reason"] == "non_member_projection"
        assert detail["projected"] is False
        assert "Review publish stayed direct" in detail["explanation"]
    finally:
        shutil.rmtree(case_dir, ignore_errors=True)


def test_review_claim_and_verdict_non_member_do_not_project_into_workspace(monkeypatch):
    case_dir = _make_case_dir()
    db_path = case_dir / "projection.db"

    try:
        server_module = _load_server(monkeypatch, case_dir, db_path)

        with TestClient(server_module.app) as api:
            alice_headers = _connect_agent(api, "alice")
            bob_headers = _connect_agent(api, "bob")
            charlie_headers = _connect_agent(api, "charlie")

            created = api.post(
                "/workspace:create",
                json={"purpose": "Review lifecycle boundary", "join_policy": "open"},
                headers=alice_headers,
            )
            assert created.status_code == 200
            workspace_id = created.json()["workspace_id"]

            joined = api.post(
                "/workspace:join",
                json={"workspace_id": workspace_id},
                headers=bob_headers,
            )
            assert joined.status_code == 200

            sent = api.post(
                "/message:send",
                json={
                    "to": "bob",
                    "subject": "Member review request",
                    "body": "This one is workspace-linked.",
                    "msg_type": "propose",
                },
                headers=_send_headers(alice_headers),
            )
            assert sent.status_code == 200
            signal_uuid = sent.json()["id"]

            publish = api.post(
                "/review/publish",
                json={
                    "signal_uuid": signal_uuid,
                    "topic": "Member review request",
                    "lens": "general",
                    "workspace_id": workspace_id,
                },
                headers=alice_headers,
            )
            assert publish.status_code == 200
            claim_id = publish.json()

            claim = api.post(
                "/review/claim",
                json={"claim_id": claim_id},
                headers=charlie_headers,
            )
            assert claim.status_code == 200

            verdict = api.post(
                "/review/verdict",
                json={
                    "claim_id": claim_id,
                    "verdict": "approve",
                    "summary": "Looks good from outside the room.",
                },
                headers=charlie_headers,
            )
            assert verdict.status_code == 200

            state = api.get(
                f"/workspace:state/{workspace_id}",
                headers=alice_headers,
            )
            assert state.status_code == 200
            deltas = state.json()["deltas"]

            assert any(delta["delta_kind"] == "review_published" for delta in deltas)
            assert not any(delta["delta_kind"] == "review_claimed" for delta in deltas)
            assert not any(delta["delta_kind"] == "review_verdict" for delta in deltas)

        claim_event = _latest_security_event(db_path, "workspace_review_claim_projection_blocked_non_writer")
        verdict_event = _latest_security_event(db_path, "workspace_review_verdict_projection_blocked_non_writer")

        assert claim_event is not None
        assert verdict_event is not None

        claim_detail = json.loads(claim_event["detail"])
        verdict_detail = json.loads(verdict_event["detail"])

        assert claim_detail["workspace_id"] == workspace_id
        assert claim_detail["claim_id"] == claim_id
        assert claim_detail["projection_kind"] == "review_claim"
        assert claim_detail["reason"] == "non_member_projection"
        assert "Review claim stayed direct" in claim_detail["explanation"]

        assert verdict_detail["workspace_id"] == workspace_id
        assert verdict_detail["claim_id"] == claim_id
        assert verdict_detail["projection_kind"] == "review_verdict"
        assert verdict_detail["reason"] == "non_member_projection"
        assert verdict_detail["verdict"] == "approve"
        assert "Review verdict stayed direct" in verdict_detail["explanation"]
    finally:
        shutil.rmtree(case_dir, ignore_errors=True)
