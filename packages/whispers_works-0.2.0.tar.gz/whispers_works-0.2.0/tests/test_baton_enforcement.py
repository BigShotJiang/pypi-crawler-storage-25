"""Baton-closure enforcement proof tests.

These tests use the real WhispersClient baton lifecycle instead of raw SQL
fixtures so they stay aligned with the current schema.
"""

import asyncio
from pathlib import Path
import shutil
import uuid

import pytest

import whispers.mcp_server as mcp_module
from whispers.client import WhispersClient, WhispersException


@pytest.fixture
def temp_db():
    root = Path(__file__).resolve().parents[1] / ".tmp"
    root.mkdir(parents=True, exist_ok=True)
    case_dir = root / f"baton-enforcement-{uuid.uuid4().hex}"
    case_dir.mkdir(parents=True, exist_ok=False)
    db_path = str(case_dir / "test_baton_enforcement.db")
    yield db_path
    shutil.rmtree(case_dir, ignore_errors=True)


def _setup_accepted_baton(temp_db: str):
    owner = WhispersClient("bob", db_path=temp_db)
    assignee = WhispersClient("alice", db_path=temp_db)

    sent = owner.send_handoff(
        "alice",
        objective="Fix the widget",
        deliverable="widget.py",
        completed="Investigation finished.",
        remaining="Apply the fix.",
        next_action="Patch widget.py.",
        human_summary="Fix the widget.",
    )
    assignee.baton_ack(sent["id"], "accepted", reason="Starting widget fix")
    return owner, assignee, sent["id"]


class TestGetUnresolvedBatonObligations:
    """Prove the obligation query returns correct data from the real baton lifecycle."""

    def test_assignee_sees_accepted_baton_as_obligation(self, temp_db):
        owner, assignee, baton_ref = _setup_accepted_baton(temp_db)

        obligations = assignee.db.get_unresolved_baton_obligations("alice")

        assert len(obligations) == 1
        assert obligations[0]["baton_ref"] == baton_ref
        assert obligations[0]["role"] == "carrying"
        assert obligations[0]["state"] == "accepted"
        assert obligations[0]["counterpart"] == owner.agent_name
        assert obligations[0]["label"]

    def test_owner_sees_baton_as_obligation(self, temp_db):
        owner, _assignee, baton_ref = _setup_accepted_baton(temp_db)

        obligations = owner.db.get_unresolved_baton_obligations("bob")

        assert len(obligations) == 1
        assert obligations[0]["baton_ref"] == baton_ref
        assert obligations[0]["role"] == "owns"
        assert obligations[0]["counterpart"] == "alice"

    def test_no_obligations_for_uninvolved_agent(self, temp_db):
        owner, _assignee, _baton_ref = _setup_accepted_baton(temp_db)
        outsider = WhispersClient("charlie", db_path=temp_db)

        obligations = owner.db.get_unresolved_baton_obligations(outsider.agent_name)

        assert obligations == []

    def test_terminal_baton_not_returned(self, temp_db):
        _owner, assignee, baton_ref = _setup_accepted_baton(temp_db)
        assignee.baton_close(baton_ref, "completed", summary="Widget shipped")

        obligations = assignee.db.get_unresolved_baton_obligations("alice")

        assert obligations == []

    def test_multiple_batons_all_returned(self, temp_db):
        owner, assignee, first_baton_ref = _setup_accepted_baton(temp_db)
        second = owner.send_handoff(
            "alice",
            objective="Review the PR",
            deliverable="review",
            completed="Context gathered.",
            remaining="Do the review.",
            next_action="Review the PR.",
            human_summary="Review the PR.",
        )
        assignee.baton_ack(second["id"], "accepted", reason="Picking up review")

        obligations = assignee.db.get_unresolved_baton_obligations("alice")

        assert {item["baton_ref"] for item in obligations} == {first_baton_ref, second["id"]}

    def test_offered_baton_shown_for_assignee(self, temp_db):
        owner = WhispersClient("bob", db_path=temp_db)
        assignee = WhispersClient("alice", db_path=temp_db)
        sent = owner.send_handoff(
            "alice",
            objective="Take the offered task",
            deliverable="task.txt",
            remaining="Accept or decline the handoff.",
            next_action="Review the offer.",
            human_summary="Offered task.",
        )

        obligations = assignee.db.get_unresolved_baton_obligations("alice")

        assert len(obligations) == 1
        assert obligations[0]["baton_ref"] == sent["id"]
        assert obligations[0]["state"] == "offered"
        assert obligations[0]["role"] == "carrying"

    def test_acknowledged_legacy_handoff_no_longer_counts_as_unresolved_obligation(self, temp_db):
        owner = WhispersClient("bob", db_path=temp_db)
        assignee = WhispersClient("alice", db_path=temp_db)

        sent = owner.send(
            "alice",
            "Legacy handoff",
            body="Pick this up from the older handoff path.",
            priority="priority",
            msg_type="handoff",
        )

        before = assignee.db.get_unresolved_baton_obligations("alice")
        assert [item["baton_ref"] for item in before] == [sent["id"]]

        assignee.acknowledge_message(sent["id"], "processed", detail="Reviewed and cleared")

        after = assignee.db.get_unresolved_baton_obligations("alice")
        assert after == []


class TestYieldBlocking:
    """Prove yield-like state transitions fail before runtime truth is mutated."""

    def test_set_readiness_blocks_ready_when_assignee_is_still_carrying_baton(self, temp_db):
        _owner, assignee, _baton_ref = _setup_accepted_baton(temp_db)
        assignee.set_readiness("busy", current_task="Finishing widget fix")

        with pytest.raises(WhispersException) as exc_info:
            assignee.set_readiness("ready", attention_state="needs_assignment")

        runtime = assignee.get_runtime_state()
        assert runtime["readiness"] == "busy"
        assert runtime["current_task"] == "Finishing widget fix"
        assert "baton_update" in str(exc_info.value)
        assert "baton_close" in str(exc_info.value)

    def test_announce_available_blocks_when_assignee_is_still_carrying_baton(self, temp_db):
        _owner, assignee, _baton_ref = _setup_accepted_baton(temp_db)
        assignee.set_readiness("busy", current_task="Finishing widget fix")

        with pytest.raises(WhispersException) as exc_info:
            assignee.announce_available(offer="Ready for the next slice")

        runtime = assignee.get_runtime_state()
        assert runtime["readiness"] == "busy"
        assert runtime["current_task"] == "Finishing widget fix"
        assert "Cannot announce availability" in str(exc_info.value)
        assert "baton_close" in str(exc_info.value)

    def test_owner_can_reopen_capacity_while_assignee_carries_baton(self, temp_db):
        owner, _assignee, _baton_ref = _setup_accepted_baton(temp_db)
        owner.set_readiness("busy", current_task="Routing the next slice")

        result = owner.announce_available(offer="Available for a new lane")

        runtime = owner.get_runtime_state()
        assert result["readiness"] == "ready"
        assert runtime["readiness"] == "ready"
        assert runtime["attention_state"] == "needs_assignment"


class TestMcpYieldBlocking:
    """Prove MCP tool surfaces expose the hard protocol failure clearly."""

    def test_set_readiness_tool_returns_explicit_yield_block_error(self, temp_db, monkeypatch):
        monkeypatch.setenv("WHISPERS_DB_PATH", temp_db)
        mcp_module._clients.clear()

        _owner, _assignee, _baton_ref = _setup_accepted_baton(temp_db)

        token = mcp_module.current_agent_name.set("alice")
        try:
            response = asyncio.run(mcp_module.handle_tool("set_readiness", {"readiness": "ready"}))
        finally:
            mcp_module.current_agent_name.reset(token)
            mcp_module._clients.clear()

        text = response[0].text
        assert "Failed to set readiness" in text
        assert "baton_update" in text
        assert "baton_close" in text

    def test_announce_available_tool_returns_explicit_yield_block_error(self, temp_db, monkeypatch):
        monkeypatch.setenv("WHISPERS_DB_PATH", temp_db)
        mcp_module._clients.clear()

        _owner, _assignee, _baton_ref = _setup_accepted_baton(temp_db)

        token = mcp_module.current_agent_name.set("alice")
        try:
            response = asyncio.run(
                mcp_module.handle_tool(
                    "announce_available",
                    {"offer": "Ready for the next slice"},
                )
            )
        finally:
            mcp_module.current_agent_name.reset(token)
            mcp_module._clients.clear()

        text = response[0].text
        assert "Failed to announce availability" in text
        assert "baton_update" in text
        assert "baton_close" in text


class TestHasBlockingObligations:
    """Prove that has_blocking_obligations includes incoming batons."""

    def test_incoming_baton_counts_as_blocking(self):
        from whispers.connection_story import ConnectionStory

        story = ConnectionStory(
            agent_name="alice",
            incoming_batons=1,
            carrying_batons=0,
            pending_assignments=0,
            claimed_reviews=0,
        )
        d = story.to_dict()
        assert d["has_blocking_obligations"] is True

    def test_carrying_baton_counts_as_blocking(self):
        from whispers.connection_story import ConnectionStory

        story = ConnectionStory(
            agent_name="alice",
            incoming_batons=0,
            carrying_batons=1,
            pending_assignments=0,
            claimed_reviews=0,
        )
        d = story.to_dict()
        assert d["has_blocking_obligations"] is True

    def test_no_obligations_means_not_blocking(self):
        from whispers.connection_story import ConnectionStory

        story = ConnectionStory(
            agent_name="alice",
            incoming_batons=0,
            carrying_batons=0,
            pending_assignments=0,
            claimed_reviews=0,
        )
        d = story.to_dict()
        assert d["has_blocking_obligations"] is False


class TestBlockingObligationBriefingSurface:
    """Prove incoming batons stay visible in the briefing capsule, not just the raw dict."""

    def test_briefing_capsule_marks_incoming_baton_as_blocking(self):
        from whispers.connection_story import ConnectionStory, build_briefing_capsule

        story = ConnectionStory(
            agent_name="alice",
            signal_mode="OPEN",
            local_time="-",
            incoming_batons=1,
            carrying_batons=0,
            pending_assignments=0,
            claimed_reviews=0,
        )

        capsule = build_briefing_capsule(story)
        assert capsule["has_blocking_obligations"] is True
        assert "incoming baton" in capsule["detail_block"]
