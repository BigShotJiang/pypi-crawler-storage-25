"""Tests for scope widening hard rejection.

An agent with scoped autonomy policies MUST declare working_scope on every
message. Sending without scope when policies exist is a scope widening
violation and gets hard-rejected.
"""

import shutil
import uuid
from pathlib import Path

import pytest

from whispers.client import WhispersClient


@pytest.fixture
def app_clients():
    root = Path(__file__).resolve().parents[1] / ".tmp"
    root.mkdir(parents=True, exist_ok=True)
    case_dir = root / f"whispers-test-{uuid.uuid4().hex}"
    case_dir.mkdir(parents=True, exist_ok=False)
    db_path = str(case_dir / "test_whispers.db")
    scoped_agent = WhispersClient("scoped-bot", db_path=db_path)
    unscoped_agent = WhispersClient("free-bot", db_path=db_path)
    receiver = WhispersClient("receiver", db_path=db_path)
    yield scoped_agent, unscoped_agent, receiver, db_path
    shutil.rmtree(case_dir, ignore_errors=True)


class TestScopeWideningRejection:
    def test_scoped_agent_without_scope_is_rejected(self, app_clients):
        """Agent with autonomy policy that sends without working_scope gets dead-lettered."""
        scoped, _, receiver, db_path = app_clients

        scoped.db.set_autonomy_policy(
            "scoped-bot", "project-alpha",
            {"can_reply": True, "can_summarize": False, "can_classify": False, "can_external_action": False},
        )

        result = scoped.send(
            to="receiver",
            subject="test no scope",
            body="this should be rejected",
        )
        assert result["status"] == "dead_lettered"
        assert result.get("reason") == "scope_widening:missing_scope"

    def test_scoped_agent_with_valid_scope_is_allowed(self, app_clients):
        """Agent with autonomy policy that declares valid working_scope passes."""
        scoped, _, receiver, db_path = app_clients

        scoped.db.set_autonomy_policy(
            "scoped-bot", "project-alpha",
            {"can_reply": True, "can_summarize": True, "can_classify": True, "can_external_action": True},
        )

        result = scoped.send(
            to="receiver",
            subject="test with scope",
            body="this should be allowed",
            metadata={"whispers:working_scope": "project-alpha"},
        )
        assert result["status"] != "dead_lettered", "Valid scope should not be rejected"

    def test_unscoped_agent_without_scope_is_allowed(self, app_clients):
        """Agent with NO autonomy policies can send without working_scope freely."""
        _, unscoped, receiver, db_path = app_clients

        result = unscoped.send(
            to="receiver",
            subject="test free agent",
            body="no policy, no restriction",
        )
        assert result["status"] != "dead_lettered" or result.get("reason") != "scope_widening:missing_scope"

    def test_scoped_agent_wrong_scope_is_rejected(self, app_clients):
        """Agent declaring a scope they don't have policy for gets rejected."""
        scoped, _, receiver, db_path = app_clients

        scoped.db.set_autonomy_policy(
            "scoped-bot", "project-alpha",
            {"can_reply": True, "can_summarize": True, "can_classify": True, "can_external_action": True},
        )

        result = scoped.send(
            to="receiver",
            subject="test wrong scope",
            body="this should be rejected",
            metadata={"whispers:working_scope": "project-beta"},
        )
        assert result["status"] == "dead_lettered"
        assert "unauthorized_scope" in (result.get("reason") or "")
