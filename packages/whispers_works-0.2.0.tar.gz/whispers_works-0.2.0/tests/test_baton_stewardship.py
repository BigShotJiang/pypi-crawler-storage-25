import pytest
from datetime import datetime
from whispers.client import WhispersClient
from whispers.storage.db import WhispersDB
from whispers.storage.gc import GarbageCollector
from whispers.twoack_schemas import HandoffBaton
import sqlite3

def test_offered_baton_expired(temp_db):
    """Test that a baton offered > 2 hours ago un-acked expires."""
    db = WhispersDB(temp_db)
    client_a = WhispersClient("agent_a", db_path=temp_db)
    
    # Send a baton
    baton = HandoffBaton(objective="test expiry", deliverable="A test")
    client_a.baton_create("agent_b", baton)
    
    # Backdate the baton offering to 3 hours ago
    with db.get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("UPDATE messages SET created_at = datetime('now', '-3 hours')")
        
        # Simulate delivery
        cursor.execute("UPDATE message_recipients SET delivery_status = 'delivered', ack_state = NULL")
        
        # Verify setup
        cursor.execute("SELECT COUNT(*) FROM message_recipients WHERE delivery_status = 'delivered' AND ack_state IS NULL")
        assert cursor.fetchone()[0] == 1
        conn.commit()
        
    gc = GarbageCollector(db)
    swept = gc.sweep_stale_batons()
    assert swept == 1
    
    with db.get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT ack_state FROM message_recipients")
        state = cursor.fetchone()[0]
        assert state == 'expired'

def test_idle_baton_expired(temp_db):
    """Test that an accepted baton idle > 12 hours expires."""
    db = WhispersDB(temp_db)
    client_a = WhispersClient("agent_a", db_path=temp_db)
    client_b = WhispersClient("agent_b", db_path=temp_db)
    
    # Send a baton
    baton = HandoffBaton(objective="test expiry", deliverable="A test")
    b_data = client_a.baton_create("agent_b", baton)
    baton_id = b_data.get('id', b_data.get('uuid'))
    
    # Accept the baton
    client_b.check_inbox()
    client_b.baton_ack(baton_id, "accepted")
    db.acknowledge_message(baton_id, "agent_b", "accepted")
    
    # Backdate the accept and offering to 13 hours ago
    with db.get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("UPDATE messages SET created_at = datetime('now', '-13 hours')")
        cursor.execute("UPDATE message_recipients SET acked_at = datetime('now', '-13 hours')")
        conn.commit()
        
    gc = GarbageCollector(db)
    swept = gc.sweep_stale_batons()
    assert swept == 1

def test_idle_baton_with_recent_update_not_expired(temp_db):
    """Test that an accepted baton with a recent progress update does NOT expire."""
    db = WhispersDB(temp_db)
    client_a = WhispersClient("agent_a", db_path=temp_db)
    client_b = WhispersClient("agent_b", db_path=temp_db)
    
    # Send a baton
    baton = HandoffBaton(objective="test expiry", deliverable="A test")
    b_data = client_a.baton_create("agent_b", baton)
    baton_id = b_data.get('id', b_data.get('uuid'))
    
    # Accept the baton
    client_b.check_inbox()
    client_b.baton_ack(baton_id, "accepted")
    db.acknowledge_message(baton_id, "agent_b", "accepted")
    
    # Update progress
    client_b.baton_update(baton_id, "in_progress", progress="Working on it")
    
    # Backdate the accept and offering to 13 hours ago, but leave the update as recent
    with db.get_connection() as conn:
        cursor = conn.cursor()
        # backdate original baton
        cursor.execute("UPDATE messages SET created_at = datetime('now', '-13 hours') WHERE uuid = ?", (baton_id,))
        cursor.execute("UPDATE message_recipients SET acked_at = datetime('now', '-13 hours') WHERE message_uuid = ?", (baton_id,))
        # Update message is recent, do not backdate it
        conn.commit()
        
    gc = GarbageCollector(db)
    swept = gc.sweep_stale_batons()
    assert swept == 0

def test_completed_baton_not_expired(temp_db):
    """Test that a completed/terminal baton is not touched by the idle sweeper."""
    db = WhispersDB(temp_db)
    client_a = WhispersClient("agent_a", db_path=temp_db)
    client_b = WhispersClient("agent_b", db_path=temp_db)
    
    baton = HandoffBaton(objective="test expiry", deliverable="A test")
    b_data = client_a.baton_create("agent_b", baton)
    baton_id = b_data.get('id', b_data.get('uuid'))
    
    client_b.check_inbox()
    client_b.baton_ack(baton_id, "accepted")
    db.acknowledge_message(baton_id, "agent_b", "accepted")
    client_b.baton_close(baton_id, "completed")
    
    # Backdate all messages and acks to 15 hours ago
    with db.get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("UPDATE messages SET created_at = datetime('now', '-15 hours')")
        cursor.execute("UPDATE message_recipients SET acked_at = datetime('now', '-15 hours')")
        conn.commit()
        
    gc = GarbageCollector(db)
    swept = gc.sweep_stale_batons()
    assert swept == 0
