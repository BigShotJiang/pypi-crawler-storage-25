"""Connection story pressure tests.

Exercises boundary conditions not covered by the existing 50 tests:
empty state, many peers, mixed coordination states, recommended action
priority ordering under unusual combinations.
"""

import pytest

from whispers.connection_story import (
    ConnectionStory,
    HuddlePeer,
    PeerSnapshot,
    SinceLastSeen,
    build_briefing_capsule,
    infer_recommended_action as _recommend_next_action,
)
from whispers.coordination_runtime import CoordinationItem
from whispers.testing import WhispersTestHarness


class TestEmptyState:
    """Connection story with absolutely nothing happening."""

    def test_zero_peers_zero_messages(self):
        story = ConnectionStory(
            agent_name="lonely",
            deployment_mode="standalone",
            peers=[],
            huddle_peers=[],
        )
        capsule = build_briefing_capsule(story)
        assert capsule["agent_name"] == "lonely"
        assert capsule["peers_online_count"] == 0
        assert capsule["pending_messages"] == 0

    def test_recommended_action_empty_state(self):
        story = ConnectionStory(
            agent_name="idle",
            deployment_mode="standalone",
            peers=[],
            huddle_peers=[],
        )
        action = _recommend_next_action(story)
        # Should produce some recommendation, not crash
        assert isinstance(action, str)
        assert len(action) > 0

    def test_zero_peers_with_unread_messages(self):
        story = ConnectionStory(
            agent_name="alone-with-mail",
            deployment_mode="standalone",
            peers=[],
            huddle_peers=[],
            pending_messages=3,
            pending_by_priority={"routine": 2, "priority": 1},
        )
        action = _recommend_next_action(story)
        assert "inbox" in action.lower() or "3" in action


class TestManyPeers:
    """Connection story with a large number of peers."""

    def test_many_peers_renders_without_error(self):
        peers = [
            PeerSnapshot(callsign=f"agent-{i}", readiness="ready")
            for i in range(20)
        ]
        story = ConnectionStory(
            agent_name="hub",
            deployment_mode="standalone",
            peers=peers,
            peers_online_count=20,
            huddle_peers=[],
        )
        capsule = build_briefing_capsule(story)
        assert capsule["peers_online_count"] == 20

    def test_many_huddle_peers(self):
        huddle = [
            HuddlePeer(
                callsign=f"huddle-{i}",
                readiness="ready",
                incoming_baton_from_them=(i % 3 == 0),
                incoming_baton_count=1 if i % 3 == 0 else 0,
            )
            for i in range(10)
        ]
        story = ConnectionStory(
            agent_name="hub",
            deployment_mode="standalone",
            peers=[],
            huddle_peers=huddle,
        )
        capsule = build_briefing_capsule(story)
        # Should render all huddle peers without truncation errors
        detail = capsule.get("detail_block", "")
        assert "huddle" in detail.lower() or len(detail) > 0


class TestRecommendedActionPriority:
    """Test the priority ordering of recommended actions under unusual combinations."""

    def test_flash_outranks_everything(self):
        story = ConnectionStory(
            agent_name="agent",
            deployment_mode="standalone",
            peers=[PeerSnapshot(callsign="peer", readiness="ready")],
            huddle_peers=[],
            pending_messages=5,
            pending_by_priority={"flash": 1, "routine": 4},
            incoming_batons=2,
            coordination_highlights=[
                CoordinationItem(
                    direction="incoming", kind="assignment",
                    message_id="a1", counterpart="lead", subject="Task",
                )
            ],
        )
        action = _recommend_next_action(story)
        assert "flash" in action.lower() or "immediately" in action.lower()

    def test_blocking_review_outranks_batons(self):
        story = ConnectionStory(
            agent_name="agent",
            deployment_mode="standalone",
            peers=[],
            huddle_peers=[],
            incoming_batons=3,
            coordination_highlights=[
                CoordinationItem(
                    direction="incoming", kind="review_request",
                    message_id="r1", counterpart="peer", subject="Review code",
                    blocking=True, age_seconds=600.0,
                )
            ],
        )
        action = _recommend_next_action(story)
        assert "review" in action.lower() or "blocking" in action.lower()

    def test_assignment_outranks_plain_messages(self):
        story = ConnectionStory(
            agent_name="agent",
            deployment_mode="standalone",
            peers=[],
            huddle_peers=[],
            pending_messages=10,
            pending_by_priority={"routine": 10},
            coordination_highlights=[
                CoordinationItem(
                    direction="incoming", kind="assignment",
                    message_id="a1", counterpart="lead", subject="Implement feature",
                    requested_action="implement the thing",
                )
            ],
        )
        action = _recommend_next_action(story)
        assert "assignment" in action.lower() or "implement" in action.lower()

    def test_claimed_reviews_surface(self):
        story = ConnectionStory(
            agent_name="reviewer",
            deployment_mode="standalone",
            peers=[],
            huddle_peers=[],
            claimed_reviews=2,
        )
        action = _recommend_next_action(story)
        assert "review" in action.lower() or "claimed" in action.lower()

    def test_carrying_batons_surface(self):
        story = ConnectionStory(
            agent_name="carrier",
            deployment_mode="standalone",
            peers=[],
            huddle_peers=[],
            carrying_batons=1,
        )
        action = _recommend_next_action(story)
        assert "baton" in action.lower()


class TestBlockingReviewAge:
    """Verify age surfaces correctly in connection story recommended actions."""

    def test_blocking_review_with_age_shows_wait_time(self):
        story = ConnectionStory(
            agent_name="agent",
            deployment_mode="standalone",
            peers=[],
            huddle_peers=[],
            coordination_highlights=[
                CoordinationItem(
                    direction="incoming", kind="review_request",
                    message_id="r1", counterpart="peer", subject="Review PR",
                    blocking=True, age_seconds=900.0,
                )
            ],
        )
        action = _recommend_next_action(story)
        assert "15m" in action or "waiting" in action

    def test_blocking_review_under_60s_no_age_shown(self):
        story = ConnectionStory(
            agent_name="agent",
            deployment_mode="standalone",
            peers=[],
            huddle_peers=[],
            coordination_highlights=[
                CoordinationItem(
                    direction="incoming", kind="review_request",
                    message_id="r1", counterpart="peer", subject="Quick review",
                    blocking=True, age_seconds=30.0,
                )
            ],
        )
        action = _recommend_next_action(story)
        # Under 60s should not show age (too noisy)
        assert "waiting" not in action


class TestConnectionStoryIntegrationPressure:
    """Integration tests using real WhispersTestHarness under pressure conditions."""

    def test_status_with_mixed_coordination(self):
        """Status with assignments, reviews, and batons all active simultaneously."""
        with WhispersTestHarness() as h:
            lead = h.make_client("lead")
            worker = h.make_client("worker")

            # Create an assignment
            lead.send_assignment(
                "worker",
                objective="Implement X",
                deliverable="feature",
                requested_action="implement",
            )

            # Create a review request
            lead.request_review(
                "worker",
                artifact="code.py",
                question="Is this correct?",
                blocking=True,
            )

            # Worker checks status — should see both
            worker.check_inbox(mark_seen=True)
            status = worker.status()

            coord = status.get("coordination_state", {})
            total_pending = coord.get("pending_assignments", 0) + coord.get("pending_review_requests", 0)
            assert total_pending >= 2

    def test_status_after_all_work_completed(self):
        """After completing all assignments and reviews, coordination should be clean."""
        with WhispersTestHarness() as h:
            lead = h.make_client("lead")
            worker = h.make_client("worker")

            lead.send_assignment(
                "worker",
                objective="Quick task",
                deliverable="done",
                requested_action="do it",
            )

            inbox = worker.check_inbox(mark_seen=True)
            for msg in inbox:
                worker.mark_done(msg["uuid"])

            status = worker.status()
            coord = status.get("coordination_state", {})
            assert coord.get("pending_assignments", 0) == 0
            assert coord.get("recently_completed", 0) >= 1
