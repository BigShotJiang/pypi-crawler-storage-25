from __future__ import annotations

import whispers.cli as cli_module
import whispers.client as client_module
import whispers.path_utils as path_utils
import whispers.registry as registry_module
import whispers.storage.db as db_module


def _force_profile_fallback(monkeypatch, profile_home):
    for key in ("HOME", "USERPROFILE", "HOMEDRIVE", "HOMEPATH"):
        monkeypatch.delenv(key, raising=False)
    monkeypatch.setattr(path_utils, "_raw_expanduser", lambda value: value)
    monkeypatch.setattr(path_utils, "_platform_home_dir", lambda: str(profile_home))


def test_resolve_path_expands_tilde_when_home_env_missing(monkeypatch, tmp_path):
    profile_home = tmp_path / "profile-home"
    _force_profile_fallback(monkeypatch, profile_home)

    resolved = path_utils.resolve_path("~/.whispers/whispers.db")

    assert resolved == str(profile_home / ".whispers" / "whispers.db")


def test_cli_expected_db_path_uses_profile_fallback_when_home_env_missing(monkeypatch, tmp_path):
    profile_home = tmp_path / "profile-home"
    _force_profile_fallback(monkeypatch, profile_home)
    monkeypatch.delenv("WHISPERS_DB_PATH", raising=False)

    expected = str(profile_home / ".whispers" / "whispers.db")

    assert cli_module._expected_db_path() == expected


def test_whispers_client_default_db_path_uses_profile_fallback(monkeypatch, tmp_path):
    profile_home = tmp_path / "profile-home"
    _force_profile_fallback(monkeypatch, profile_home)
    monkeypatch.delenv("WHISPERS_DB_PATH", raising=False)

    class DummyDB:
        def __init__(self, db_path, **kwargs):
            self.db_path = db_path

    class DummyDispatcher:
        def __init__(self, db):
            self.db = db

    class DummyRegistry:
        def __init__(self, db):
            self.db = db

    monkeypatch.setattr(client_module, "WhispersDB", DummyDB)
    monkeypatch.setattr(client_module, "Dispatcher", DummyDispatcher)
    monkeypatch.setattr(registry_module, "AgentRegistry", DummyRegistry)

    client = client_module.WhispersClient("codex", read_only=True)

    assert client.db_path == str(profile_home / ".whispers" / "whispers.db")


def test_whispers_db_default_path_uses_profile_fallback(monkeypatch, tmp_path):
    profile_home = tmp_path / "profile-home"
    _force_profile_fallback(monkeypatch, profile_home)
    monkeypatch.delenv("WHISPERS_DB_PATH", raising=False)
    monkeypatch.setattr(db_module.WhispersDB, "_ensure_current_schema", lambda self, auto_repair=False: None)
    monkeypatch.setattr(db_module.WhispersDB, "_init_schema", lambda self: None)

    db = db_module.WhispersDB(read_only=True)

    assert db.db_path == str(profile_home / ".whispers" / "whispers.db")
