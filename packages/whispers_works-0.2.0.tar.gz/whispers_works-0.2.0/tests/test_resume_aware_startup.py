"""Tests for resume-aware startup — since-last-session deltas.

Covers:
- SinceLastSeen enriched fields (batons, workspaces, tasks)
- DB methods for baton/workspace/task deltas
- Resume hint generation
- First session returns is_first_session=True
- to_dict drops empty fields
"""

import pytest
from whispers.connection_story import SinceLastSeen


class TestSinceLastSeenModel:
    def test_to_dict_drops_empty_fields(self):
        sls = SinceLastSeen(
            last_session_ended="2026-03-29T20:00:00Z",
            messages_arrived=3,
            is_first_session=False,
        )
        d = sls.to_dict()
        assert "messages_by_priority" not in d
        assert "peers_joined" not in d
        assert "batons_received" not in d
        assert "tasks_assigned" not in d
        assert "resume_hint" not in d
        assert d["messages_arrived"] == 3

    def test_to_dict_includes_nonzero_fields(self):
        sls = SinceLastSeen(
            last_session_ended="2026-03-29T20:00:00Z",
            messages_arrived=5,
            batons_received=2,
            tasks_assigned=3,
            workspace_events=10,
            active_workspaces=["Sprint"],
            resume_hint="2 handoff(s) waiting",
            is_first_session=False,
        )
        d = sls.to_dict()
        assert d["batons_received"] == 2
        assert d["tasks_assigned"] == 3
        assert d["workspace_events"] == 10
        assert d["active_workspaces"] == ["Sprint"]
        assert d["resume_hint"] == "2 handoff(s) waiting"


class TestDBDeltaMethods:
    @pytest.fixture
    def setup(self, tmp_path):
        from whispers.storage.db import WhispersDB
        from whispers.client import WhispersClient

        db_path = str(tmp_path / "test_resume.db")
        db = WhispersDB(db_path=db_path)

        # Register agents
        with db.get_connection() as conn:
            conn.execute(
                "INSERT INTO agent_cards (callsign, agent_type, trust_tier, registered_at) VALUES (?, ?, ?, datetime('now'))",
                ("alice", "llm", 2),
            )
            conn.execute(
                "INSERT INTO agent_cards (callsign, agent_type, trust_tier, registered_at) VALUES (?, ?, ?, datetime('now'))",
                ("bob", "remote_client", 1),
            )
            conn.commit()

        alice = WhispersClient("alice", db_path=db_path)
        bob = WhispersClient("bob", db_path=db_path)
        return db, alice, bob

    def test_baton_changes_since(self, setup):
        db, alice, bob = setup
        since = "2026-01-01T00:00:00Z"
        # Create a handoff
        alice.send_handoff(
            to="bob", subject="Test", objective="Do thing", deliverable="Result"
        )
        result = db.get_baton_changes_since("bob", since)
        assert result["received"] >= 1

    def test_workspace_activity_since(self, setup):
        db, alice, bob = setup
        since = "2026-01-01T00:00:00Z"
        # Create workspace and post delta
        run = alice.create_process_run("Test Sprint")
        alice.add_process_task(run["run_id"], "A task")
        result = db.get_workspace_activity_since("alice", since)
        assert result["total"] >= 1
        assert len(result["active_workspaces"]) >= 1

    def test_task_state_since(self, setup):
        db, alice, bob = setup
        since = "2026-01-01T00:00:00Z"
        run = alice.create_process_run("Sprint")
        t1 = alice.add_process_task(run["run_id"], "Alice task")
        t2 = alice.add_process_task(run["run_id"], "Bob task")
        alice.assign_task(t1, "alice")
        alice.assign_task(t2, "bob")
        bob.update_task_status(t2, "completed")

        alice_state = db.get_task_state_since("alice", since)
        assert alice_state["assigned"] == 1
        assert alice_state["completed_by_others"] >= 1

    def test_no_activity_returns_zeros(self, setup):
        db, alice, bob = setup
        since = "2026-01-01T00:00:00Z"
        result = db.get_baton_changes_since("alice", since)
        assert result == {"received": 0, "completed": 0, "expired": 0}
        ws = db.get_workspace_activity_since("alice", since)
        assert ws == {"total": 0, "active_workspaces": []}
        tasks = db.get_task_state_since("alice", since)
        assert tasks == {"assigned": 0, "completed_by_others": 0}


class TestResumeHint:
    def test_flash_messages_prioritized(self):
        from whispers.client import WhispersClient
        hint = WhispersClient._compute_resume_hint(
            {"total": 5, "by_priority": {"flash": 2, "routine": 3}},
            {"received": 0, "completed": 0, "expired": 0},
            {"assigned": 0, "completed_by_others": 0},
            {"total": 0, "active_workspaces": []},
        )
        assert "flash" in hint

    def test_handoffs_prioritized_over_messages(self):
        from whispers.client import WhispersClient
        hint = WhispersClient._compute_resume_hint(
            {"total": 5, "by_priority": {"routine": 5}},
            {"received": 2, "completed": 0, "expired": 0},
            {"assigned": 0, "completed_by_others": 0},
            {"total": 0, "active_workspaces": []},
        )
        assert "handoff" in hint

    def test_tasks_in_hint(self):
        from whispers.client import WhispersClient
        hint = WhispersClient._compute_resume_hint(
            {"total": 0, "by_priority": {}},
            {"received": 0, "completed": 0, "expired": 0},
            {"assigned": 3, "completed_by_others": 0},
            {"total": 0, "active_workspaces": []},
        )
        assert "3 task(s)" in hint

    def test_no_activity_returns_none(self):
        from whispers.client import WhispersClient
        hint = WhispersClient._compute_resume_hint(
            {"total": 0, "by_priority": {}},
            {"received": 0, "completed": 0, "expired": 0},
            {"assigned": 0, "completed_by_others": 0},
            {"total": 0, "active_workspaces": []},
        )
        assert hint is None

    def test_workspace_activity_as_fallback(self):
        from whispers.client import WhispersClient
        hint = WhispersClient._compute_resume_hint(
            {"total": 0, "by_priority": {}},
            {"received": 0, "completed": 0, "expired": 0},
            {"assigned": 0, "completed_by_others": 0},
            {"total": 15, "active_workspaces": ["Sprint", "Review"]},
        )
        assert "workspace" in hint
