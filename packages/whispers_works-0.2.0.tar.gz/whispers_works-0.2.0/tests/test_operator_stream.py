import importlib
import asyncio
from fastapi.testclient import TestClient

import whispers.server as server_module

def test_operator_stream_security(monkeypatch, temp_dir):
    case_dir = temp_dir
    db_path = case_dir / "network.db"

    monkeypatch.setenv("WHISPERS_DB_PATH", str(db_path))
    importlib.reload(server_module)

    # Override admission so test agents don't get rejected
    monkeypatch.setattr(server_module, "_admission_allowed", lambda agent_name: True)

    with TestClient(server_module.app) as client:
        alpha_res = client.post("/connect", json={"agent_name": "alpha"}).json()
        assert "token" in alpha_res, str(alpha_res)
        alpha_token = alpha_res["token"]

        denied = client.get("/operator:stream", headers={"Authorization": f"Bearer {alpha_token}"})
        assert denied.status_code == 403
        assert "restricted to the Console" in denied.json()["detail"]


def test_operator_stream_delivers_workspace_events(monkeypatch, temp_dir):
    case_dir = temp_dir
    db_path = case_dir / "network.db"

    monkeypatch.setenv("WHISPERS_DB_PATH", str(db_path))
    importlib.reload(server_module)

    # Override admission so test agents don't get rejected
    monkeypatch.setattr(server_module, "_admission_allowed", lambda agent_name: True)

    with TestClient(server_module.app) as client:
        console_res = client.post("/connect", json={"agent_name": "whispers-console"}).json()
        assert "token" in console_res, str(console_res)
        console_token = console_res["token"]

        alpha_res = client.post("/connect", json={"agent_name": "alpha"}).json()
        assert "token" in alpha_res, str(alpha_res)
        alpha_token = alpha_res["token"]

        import asyncio

        q = asyncio.Queue()
        server_module.operator_sse.add_listener("whispers-console", q)

        # 1. Alpha creates workspace
        ws_res = client.post(
            "/workspace:create",
            json={"purpose": "streaming test", "name": "Stream WS"},
            headers={"Authorization": f"Bearer {alpha_token}"}
        )
        assert ws_res.status_code == 200
        ws_id = ws_res.json()["workspace_id"]

        # 2. Check the queue (expecting delta from auto-join first, then created)
        event1 = q.get_nowait()
        event2 = q.get_nowait()
        events = [event1["type"], event2["type"]]
        assert "workspace_delta" in events
        assert "workspace_created" in events

        # extract the workspace_created event for validation
        event = event1 if event1["type"] == "workspace_created" else event2
        assert event["payload"]["workspace"]["workspace_id"] == ws_id

        # 3. Alpha joins workspace
        join_res = client.post(
            "/workspace:join",
            json={"workspace_id": ws_id},
            headers={"Authorization": f"Bearer {alpha_token}"}
        )
        assert join_res.status_code == 200

        delta_event = q.get_nowait()
        assert delta_event["type"] == "workspace_delta"
        assert delta_event["payload"]["delta"]["delta_kind"] == "lifecycle"
        assert delta_event["payload"]["workspace"]["workspace_id"] == ws_id

        server_module.operator_sse.remove_listener("whispers-console", q)


def test_repo_publish_surfaces_lane_events_and_board_counts(monkeypatch, temp_dir):
    case_dir = temp_dir
    db_path = case_dir / "network.db"

    monkeypatch.setenv("WHISPERS_DB_PATH", str(db_path))
    importlib.reload(server_module)

    monkeypatch.setattr(server_module, "_admission_allowed", lambda agent_name: True)

    with TestClient(server_module.app) as client:
        console_res = client.post("/connect", json={"agent_name": "whispers-console"}).json()
        alpha_res = client.post("/connect", json={"agent_name": "alpha"}).json()
        beta_res = client.post("/connect", json={"agent_name": "beta"}).json()

        q = asyncio.Queue()
        server_module.operator_sse.add_listener("whispers-console", q)

        first = client.post(
            "/repo:publish",
            json={"branch": "main", "head_commit": "1111111", "claimed_paths": ["whispers/server.py"]},
            headers={"Authorization": f"Bearer {alpha_res['token']}"},
        )
        second = client.post(
            "/repo:publish",
            json={"branch": "main", "head_commit": "2222222", "claimed_paths": ["whispers/client.py"]},
            headers={"Authorization": f"Bearer {beta_res['token']}"},
        )
        conflict = client.post(
            "/repo:publish",
            json={"branch": "main", "head_commit": "2222222", "claimed_paths": ["whispers/server.py"]},
            headers={"Authorization": f"Bearer {beta_res['token']}"},
        )

        assert first.status_code == 200
        assert second.status_code == 200
        assert {warning["reason"] for warning in second.json()["divergence_warnings"]} == {"same_branch_different_heads"}
        assert conflict.status_code == 409
        assert conflict.json()["detail"]["message"] == "File lease conflict."

        event_types = {q.get_nowait()["type"], q.get_nowait()["type"]}
        assert server_module.OperatorEventType.LANE_PATH_OVERLAP in event_types
        assert server_module.OperatorEventType.LANE_DIVERGENCE in event_types

        board = client.get(
            "/operator:board",
            headers={"Authorization": f"Bearer {console_res['token']}"},
        )
        assert board.status_code == 200
        snapshot = board.json()
        assert snapshot["system"]["lane_warnings_active"] == 1
        assert snapshot["agents"]["alpha"]["lane_warnings"] == 1
        assert snapshot["agents"]["beta"]["lane_warnings"] == 1

        server_module.operator_sse.remove_listener("whispers-console", q)
