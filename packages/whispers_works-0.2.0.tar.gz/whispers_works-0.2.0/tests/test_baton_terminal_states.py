"""Tests for baton terminal state boundaries.

Covers:
- Rejecting baton_ack after closure
- Rejecting baton_update after closure
- Rejecting baton_close after closure (terminal is permanent)
- Allowed transitions
"""

import pytest
from fastapi import HTTPException

def _send_test_handoff(sender, subject="test terminal state"):
    """Helper: send a handoff with all required fields."""
    return sender.send_handoff(
        to="bob",
        subject=subject,
        objective="test objective",
        deliverable="test deliverable",
        completed="done so far",
        remaining="what's left",
        next_action="do it",
    )

class TestBatonTerminalStates:
    @pytest.fixture
    def app_clients(self, tmp_path):
        from whispers.storage.db import WhispersDB
        from whispers.client import WhispersClient

        db_path = str(tmp_path / "test_terminal.db")
        db = WhispersDB(db_path=db_path)
        sender = WhispersClient("alice", db_path=db_path)
        receiver = WhispersClient("bob", db_path=db_path)
        
        return db, sender, receiver

    def test_update_rejected_after_close(self, app_clients):
        db, sender, receiver = app_clients
        result = _send_test_handoff(sender)
        baton_ref = result["id"]

        receiver.baton_ack(baton_ref, "accepted")
        receiver.baton_close(baton_ref, "completed", summary="all done")

        with pytest.raises(Exception) as exc_info:
            receiver.baton_update(baton_ref, "in_progress", progress="wait I forgot something")

    def test_ack_rejected_after_close(self, app_clients):
        db, sender, receiver = app_clients
        result = _send_test_handoff(sender)
        baton_ref = result["id"]

        receiver.baton_close(baton_ref, "superseded", summary="nevermind")

        with pytest.raises(Exception) as exc_info:
            receiver.baton_ack(baton_ref, "accepted")

    def test_close_rejected_after_already_closed(self, app_clients):
        db, sender, receiver = app_clients
        result = _send_test_handoff(sender)
        baton_ref = result["id"]

        receiver.baton_close(baton_ref, "completed", summary="done")

        # Trying to close a second time with a different outcome should fail
        with pytest.raises(Exception) as exc_info:
            receiver.baton_close(baton_ref, "blocked", summary="actually wait")

    def test_update_rejected_after_ack_reject(self, app_clients):
        db, sender, receiver = app_clients
        result = _send_test_handoff(sender)
        baton_ref = result["id"]

        receiver.baton_ack(baton_ref, "rejected", reason="no bandwidth")

        with pytest.raises(Exception):
            receiver.baton_update(baton_ref, "in_progress", progress="actually I can do it")
