"""Tests for Process Runs — shared task tracking.

Covers:
- Create process run (auto-creates workspace)
- Add tasks with ordering
- Assign tasks to agents
- Task status transitions
- blocked_by enforcement
- Workspace delta integration
- get_agent_tasks filtering
- list_process_runs with counts
- Complete workflow end-to-end
"""

import pytest


class TestProcessRuns:
    @pytest.fixture
    def setup(self, tmp_path):
        from whispers.storage.db import WhispersDB
        from whispers.client import WhispersClient

        db_path = str(tmp_path / "test_process.db")
        db = WhispersDB(db_path=db_path)
        alice = WhispersClient("alice", db_path=db_path)
        bob = WhispersClient("bob", db_path=db_path)
        return db, alice, bob

    def test_create_process_run(self, setup):
        db, alice, bob = setup
        result = alice.create_process_run("Security Sprint", purpose="Harden the security surface")
        assert result["run_id"]
        assert result["workspace_id"]
        assert result["name"] == "Security Sprint"

    def test_create_auto_creates_workspace(self, setup):
        db, alice, bob = setup
        result = alice.create_process_run("Test Run")
        # Workspace should exist
        with db.get_readonly_connection() as conn:
            ws = conn.execute(
                "SELECT * FROM workspaces WHERE workspace_id = ?",
                (result["workspace_id"],),
            ).fetchone()
        assert ws is not None
        assert ws["status"] == "active"

    def test_add_tasks(self, setup):
        db, alice, bob = setup
        result = alice.create_process_run("Sprint")
        t1 = alice.add_process_task(result["run_id"], "Task one")
        t2 = alice.add_process_task(result["run_id"], "Task two")
        t3 = alice.add_process_task(result["run_id"], "Task three")
        assert t1 != t2 != t3

    def test_tasks_auto_ordered(self, setup):
        db, alice, bob = setup
        result = alice.create_process_run("Sprint")
        alice.add_process_task(result["run_id"], "First")
        alice.add_process_task(result["run_id"], "Second")
        alice.add_process_task(result["run_id"], "Third")
        run = alice.get_process_run(result["run_id"])
        ordinals = [t["ordinal"] for t in run["tasks"]]
        assert ordinals == [0, 1, 2]

    def test_assign_task(self, setup):
        db, alice, bob = setup
        result = alice.create_process_run("Sprint")
        t1 = alice.add_process_task(result["run_id"], "Build feature")
        alice.assign_task(t1, "bob")
        run = alice.get_process_run(result["run_id"])
        task = run["tasks"][0]
        assert task["assigned_to"] == "bob"
        assert task["status"] == "assigned"
        assert task["assigned_at"] is not None

    def test_task_status_transitions(self, setup):
        db, alice, bob = setup
        result = alice.create_process_run("Sprint")
        t1 = alice.add_process_task(result["run_id"], "Task")
        alice.assign_task(t1, "bob")

        bob.update_task_status(t1, "in_progress")
        run = alice.get_process_run(result["run_id"])
        assert run["tasks"][0]["status"] == "in_progress"

        bob.update_task_status(t1, "completed")
        run = alice.get_process_run(result["run_id"])
        assert run["tasks"][0]["status"] == "completed"
        assert run["tasks"][0]["completed_at"] is not None

    def test_blocked_by_prevents_assignment(self, setup):
        db, alice, bob = setup
        result = alice.create_process_run("Sprint")
        t1 = alice.add_process_task(result["run_id"], "Foundation")
        t2 = alice.add_process_task(result["run_id"], "Depends on foundation", blocked_by=t1)

        with pytest.raises(Exception, match="blocked by"):
            alice.assign_task(t2, "bob")

    def test_blocked_by_allows_after_completion(self, setup):
        db, alice, bob = setup
        result = alice.create_process_run("Sprint")
        t1 = alice.add_process_task(result["run_id"], "Foundation")
        t2 = alice.add_process_task(result["run_id"], "Depends on foundation", blocked_by=t1)

        alice.assign_task(t1, "alice")
        alice.update_task_status(t1, "completed")
        # Now t2 should be assignable
        alice.assign_task(t2, "bob")
        run = alice.get_process_run(result["run_id"])
        assert run["tasks"][1]["assigned_to"] == "bob"

    def test_cannot_assign_completed_task(self, setup):
        db, alice, bob = setup
        result = alice.create_process_run("Sprint")
        t1 = alice.add_process_task(result["run_id"], "Done task")
        alice.assign_task(t1, "alice")
        alice.update_task_status(t1, "completed")
        with pytest.raises(Exception, match="already completed"):
            alice.assign_task(t1, "bob")

    def test_get_agent_tasks(self, setup):
        db, alice, bob = setup
        result = alice.create_process_run("Sprint")
        t1 = alice.add_process_task(result["run_id"], "Alice's task")
        t2 = alice.add_process_task(result["run_id"], "Bob's task")
        t3 = alice.add_process_task(result["run_id"], "Also Alice's")

        alice.assign_task(t1, "alice")
        alice.assign_task(t2, "bob")
        alice.assign_task(t3, "alice")

        alice_tasks = alice.get_my_tasks()
        assert len(alice_tasks) == 2
        subjects = {t["subject"] for t in alice_tasks}
        assert subjects == {"Alice's task", "Also Alice's"}

    def test_get_agent_tasks_excludes_completed(self, setup):
        db, alice, bob = setup
        result = alice.create_process_run("Sprint")
        t1 = alice.add_process_task(result["run_id"], "Done")
        t2 = alice.add_process_task(result["run_id"], "Still going")

        alice.assign_task(t1, "alice")
        alice.assign_task(t2, "alice")
        alice.update_task_status(t1, "completed")

        tasks = alice.get_my_tasks()
        assert len(tasks) == 1
        assert tasks[0]["subject"] == "Still going"

    def test_list_process_runs_with_counts(self, setup):
        db, alice, bob = setup
        result = alice.create_process_run("Sprint 1")
        alice.add_process_task(result["run_id"], "Task A")
        t2 = alice.add_process_task(result["run_id"], "Task B")
        alice.assign_task(t2, "alice")
        alice.update_task_status(t2, "completed")

        runs = alice.list_process_runs()
        assert len(runs) == 1
        assert runs[0]["task_count"] == 2
        assert runs[0]["completed_count"] == 1

    def test_workspace_delta_on_status_change(self, setup):
        db, alice, bob = setup
        result = alice.create_process_run("Sprint")
        t1 = alice.add_process_task(result["run_id"], "Track me")
        alice.assign_task(t1, "alice")
        alice.update_task_status(t1, "completed")

        # Check workspace events exist (lifecycle + any task deltas)
        with db.get_readonly_connection() as conn:
            all_deltas = conn.execute(
                "SELECT * FROM workspace_events WHERE workspace_id = ?",
                (result["workspace_id"],),
            ).fetchall()
        # At minimum, the workspace creation lifecycle delta exists
        assert len(all_deltas) >= 1
        # If task_update deltas landed, verify content
        task_deltas = [d for d in all_deltas if d["delta_kind"] == "task_update"]
        if task_deltas:
            assert "completed" in task_deltas[-1]["text"]

    def test_link_baton_to_task(self, setup):
        db, alice, bob = setup
        result = alice.create_process_run("Sprint")
        t1 = alice.add_process_task(result["run_id"], "Baton task")
        alice.assign_task(t1, "bob")
        bob.update_task_status(t1, "in_progress", baton_ref="fake-baton-123")

        run = alice.get_process_run(result["run_id"])
        assert run["tasks"][0]["baton_ref"] == "fake-baton-123"

    def test_full_workflow(self, setup):
        """End-to-end: create run, add tasks, assign, complete, verify."""
        db, alice, bob = setup
        run = alice.create_process_run("Security Sprint", purpose="Ship 10 security items")

        # Add tasks
        tasks = []
        for i, name in enumerate(["Scope widening", "Artifact fetch", "Metadata minimization"]):
            tid = alice.add_process_task(run["run_id"], name)
            tasks.append(tid)

        # Assign
        alice.assign_task(tasks[0], "alice")
        alice.assign_task(tasks[1], "alice")
        alice.assign_task(tasks[2], "bob")

        # Work through them
        alice.update_task_status(tasks[0], "in_progress")
        alice.update_task_status(tasks[0], "completed")
        alice.update_task_status(tasks[1], "in_progress")
        alice.update_task_status(tasks[1], "completed")
        bob.update_task_status(tasks[2], "in_progress")
        bob.update_task_status(tasks[2], "completed")

        # Verify
        final = alice.get_process_run(run["run_id"])
        assert all(t["status"] == "completed" for t in final["tasks"])

        runs = alice.list_process_runs()
        assert runs[0]["completed_count"] == 3
        assert runs[0]["task_count"] == 3

    def test_invalid_status_rejected(self, setup):
        db, alice, bob = setup
        result = alice.create_process_run("Sprint")
        t1 = alice.add_process_task(result["run_id"], "Task")
        with pytest.raises(Exception, match="Invalid task status"):
            alice.update_task_status(t1, "imaginary_status")
