"""Tests for in-progress message decay — hung messages revert after timeout.

Covers:
- Hung delivered-but-unread messages get dead-lettered
- Read messages are not affected
- Recent messages are not affected
- sweep_all runs all GC sweeps
"""

import pytest


class TestHungMessageDecay:
    @pytest.fixture
    def setup(self, tmp_path):
        from whispers.storage.db import WhispersDB
        from whispers.client import WhispersClient
        from whispers.storage.gc import GarbageCollector

        db_path = str(tmp_path / "test_hung.db")
        db = WhispersDB(db_path=db_path)
        gc = GarbageCollector(db)
        alice = WhispersClient("alice", db_path=db_path)
        bob = WhispersClient("bob", db_path=db_path)
        return db, gc, alice, bob

    def test_hung_message_dead_lettered(self, setup):
        db, gc, alice, bob = setup
        alice.send("bob", "Old message", body="Delivered but never read")
        # Backdate the message to 3 hours ago
        with db.get_connection() as conn:
            conn.execute(
                "UPDATE messages SET created_at = datetime('now', '-3 hours')"
            )
            conn.commit()

        swept = gc.sweep_hung_messages(max_age_hours=2)
        assert swept >= 1

        # Verify dead letter exists
        with db.get_readonly_connection() as conn:
            dl = conn.execute("SELECT * FROM dead_letters WHERE reason LIKE '%Hung message%'").fetchall()
        assert len(dl) >= 1

    def test_read_messages_not_affected(self, setup):
        db, gc, alice, bob = setup
        alice.send("bob", "Read message", body="This was read")
        # Bob reads the message
        bob.check_inbox(mark_seen=True)
        # Backdate
        with db.get_connection() as conn:
            conn.execute("UPDATE messages SET created_at = datetime('now', '-3 hours')")
            # Mark as read
            conn.execute("UPDATE message_recipients SET read_at = datetime('now', '-2 hours')")
            conn.commit()

        swept = gc.sweep_hung_messages(max_age_hours=2)
        assert swept == 0

    def test_recent_messages_not_affected(self, setup):
        db, gc, alice, bob = setup
        alice.send("bob", "Fresh message", body="Just sent")
        swept = gc.sweep_hung_messages(max_age_hours=2)
        assert swept == 0

    def test_sweep_all_runs_everything(self, setup):
        db, gc, alice, bob = setup
        results = gc.sweep_all()
        assert "ttl_expired" in results
        assert "stale_batons" in results
        assert "hung_messages" in results
        assert "expired_leases" in results
