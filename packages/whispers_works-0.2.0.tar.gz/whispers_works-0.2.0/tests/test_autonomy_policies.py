import pytest
from whispers.storage.db import WhispersDB
from whispers.dispatcher import Dispatcher
from whispers.envelope import Envelope, MsgType

@pytest.fixture
def db(tmp_path):
    db_path = str(tmp_path / "test_autonomy.db")
    db = WhispersDB(db_path)
    with db.get_connection() as conn:
        conn.execute("INSERT INTO agent_cards (agent_id, callsign, agent_type) VALUES ('test-id', 'test-agent', 'test')")
        conn.execute("INSERT INTO agent_cards (agent_id, callsign, agent_type) VALUES ('target-id', 'target-agent', 'test')")
        conn.commit()
    yield db

@pytest.fixture
def dispatcher(db):
    return Dispatcher(db)

def test_autonomy_policy_blocks_unauthorized_reply(db, dispatcher):
    db.set_autonomy_policy("test-agent", "scope1", {"can_reply": False})
    
    env = Envelope(
        sender="test-agent",
        recipient="target-agent",
        subject="re: test",
        msg_type=MsgType.INFORM,
        reply_to="some-uuid",
        metadata={"whispers:working_scope": "scope1"}
    )
    
    reason = dispatcher.dispatch(env)
    assert reason == "autonomy_policy_blocked:reply"

def test_autonomy_policy_allows_authorized_reply(db, dispatcher):
    db.set_autonomy_policy("test-agent", "scope1", {"can_reply": True})
    
    env = Envelope(
        sender="test-agent",
        recipient="target-agent",
        subject="re: test",
        msg_type=MsgType.INFORM,
        reply_to="some-uuid",
        metadata={"whispers:working_scope": "scope1"}
    )
    
    reason = dispatcher.dispatch(env)
    assert reason is None

def test_autonomy_policy_validates_external_actions(db, dispatcher):
    db.set_autonomy_policy("test-agent", "scope1", {"can_external_action": False})
    
    env = Envelope(
        sender="test-agent",
        recipient="target-agent",
        subject="test",
        msg_type=MsgType.REQUEST,
        metadata={"whispers:working_scope": "scope1", "whispers:signalClass": "external"}
    )
    
    # Must explicitly not be ephemeral to bypass the blanket ephemeral authority check
    env.ephemeral = False 
    reason = dispatcher.dispatch(env)
    assert reason == "autonomy_policy_blocked:external_action"

def test_unauthorized_scope_blocks_all(db, dispatcher):
    # No policy set for scope2
    env = Envelope(
        sender="test-agent",
        recipient="target-agent",
        subject="test",
        msg_type=MsgType.INFORM,
        metadata={"whispers:working_scope": "scope2"}
    )
    
    reason = dispatcher.dispatch(env)
    assert reason == "unauthorized_scope:scope2"

def test_autonomy_policy_shadow_mode_bypasses_block(db, dispatcher):
    db.set_autonomy_policy("test-agent", "scope1", {"can_reply": False, "shadow_mode": True})
    
    env = Envelope(
        sender="test-agent",
        recipient="target-agent",
        subject="re: shadow test",
        msg_type=MsgType.INFORM,
        reply_to="some-uuid",
        metadata={"whispers:working_scope": "scope1"}
    )
    
    reason = dispatcher.dispatch(env)
    assert reason is None

    # Verify telemetry was recorded
    with db.get_connection() as conn:
        events = conn.execute(
            "SELECT * FROM security_events WHERE event_type = ?", 
            ("autonomy_policy_blocked:reply:shadow",)
        ).fetchall()
        assert len(events) == 1
        assert events[0]["outcome"] == "shadow_filter"
