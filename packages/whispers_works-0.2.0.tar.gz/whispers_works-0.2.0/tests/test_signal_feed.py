"""Tests for the signal-feed contract (Slice 1 of Narrator spec).

Tests sequence monotonicity, gap detection on reconnect, subscription
filtering, and the extended event envelope fields (as_of, source_module,
workspace_id, agent).
"""

import asyncio
import time

import pytest

from whispers.transports.operator import (
    OperatorEventType,
    OperatorSSETransport,
    SignalFeedFilter,
    coalescing_event_reader,
)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def transport():
    return OperatorSSETransport()


@pytest.fixture
def queue():
    return asyncio.Queue()


# ---------------------------------------------------------------------------
# Sequence monotonicity
# ---------------------------------------------------------------------------

class TestSequenceMonotonicity:
    def test_sequence_starts_at_zero(self, transport):
        assert transport.sequence_id == 0

    def test_sequence_increments_on_push(self, transport, queue):
        transport.add_listener("test", queue)
        transport.push("agent:wag", {"agent": "claude-code"})
        assert transport.sequence_id == 1
        transport.push("agent:wag", {"agent": "claude-code"})
        assert transport.sequence_id == 2

    def test_sequence_in_event_matches_transport(self, transport, queue):
        transport.add_listener("test", queue)
        transport.push("agent:wag", {"agent": "claude-code"})
        event = queue.get_nowait()
        assert event["seq"] == 1
        assert event["seq"] == transport.sequence_id

    def test_sequence_strictly_monotonic_across_types(self, transport, queue):
        transport.add_listener("test", queue)
        transport.push(OperatorEventType.AGENT_WAG, {"agent": "a"})
        transport.push(OperatorEventType.HEALTH_RAISED, {"signal_id": "x"})
        transport.push(OperatorEventType.COORDINATION_REFLEX, {"reflex": "y"})

        seqs = []
        while not queue.empty():
            seqs.append(queue.get_nowait()["seq"])
        assert seqs == [1, 2, 3]


# ---------------------------------------------------------------------------
# Extended event envelope fields
# ---------------------------------------------------------------------------

class TestEventEnvelope:
    def test_as_of_defaults_to_now(self, transport, queue):
        transport.add_listener("test", queue)
        before = time.time()
        transport.push("agent:wag", {"agent": "a"})
        after = time.time()
        event = queue.get_nowait()
        assert before <= event["as_of"] <= after

    def test_as_of_can_be_explicit(self, transport, queue):
        transport.add_listener("test", queue)
        transport.push("agent:wag", {"agent": "a"}, as_of=1000.0)
        event = queue.get_nowait()
        assert event["as_of"] == 1000.0

    def test_source_module_included(self, transport, queue):
        transport.add_listener("test", queue)
        transport.push("agent:wag", {"agent": "a"}, source_module="reflexive_engine")
        event = queue.get_nowait()
        assert event["source_module"] == "reflexive_engine"

    def test_source_module_defaults_to_none(self, transport, queue):
        transport.add_listener("test", queue)
        transport.push("agent:wag", {"agent": "a"})
        event = queue.get_nowait()
        assert event["source_module"] is None

    def test_workspace_id_included(self, transport, queue):
        transport.add_listener("test", queue)
        transport.push("agent:wag", {"agent": "a"}, workspace_id="ws-123")
        event = queue.get_nowait()
        assert event["workspace_id"] == "ws-123"

    def test_agent_extracted_from_payload(self, transport, queue):
        transport.add_listener("test", queue)
        transport.push("agent:wag", {"agent": "claude-code"})
        event = queue.get_nowait()
        assert event["agent"] == "claude-code"

    def test_agent_explicit_overrides_payload(self, transport, queue):
        transport.add_listener("test", queue)
        transport.push("agent:wag", {"agent": "claude-code"}, agent="codex")
        event = queue.get_nowait()
        assert event["agent"] == "codex"


# ---------------------------------------------------------------------------
# Gap detection
# ---------------------------------------------------------------------------

class TestGapDetection:
    def test_no_gap_when_since_seq_is_none(self, transport):
        q = asyncio.Queue()
        transport.push("agent:wag", {"agent": "a"})  # seq=1
        transport.add_listener("test", q, since_seq=None)
        assert q.empty()

    def test_gap_detected_on_reconnect(self, transport):
        q_old = asyncio.Queue()
        transport.add_listener("old", q_old)
        transport.push("agent:wag", {"agent": "a"})  # seq=1
        transport.push("agent:wag", {"agent": "b"})  # seq=2
        transport.push("agent:wag", {"agent": "c"})  # seq=3

        q_new = asyncio.Queue()
        transport.add_listener("reconnect", q_new, since_seq=1)
        event = q_new.get_nowait()
        assert event["type"] == OperatorEventType.GAP_DETECTED
        assert event["payload"]["missed_from_sequence"] == 2
        assert event["payload"]["resumed_at_sequence"] == 3
        assert event["payload"]["missed_count"] == 2
        assert event["payload"]["continuity"] == "reconstructed"

    def test_no_gap_when_caught_up(self, transport):
        q = asyncio.Queue()
        transport.push("agent:wag", {"agent": "a"})  # seq=1
        transport.add_listener("test", q, since_seq=1)
        # since_seq=1, current=1 → no gap
        assert q.empty()

    def test_gap_detected_has_control_event_type(self, transport):
        transport.push("agent:wag", {"agent": "a"})  # seq=1
        q = asyncio.Queue()
        transport.add_listener("test", q, since_seq=0)
        event = q.get_nowait()
        assert event["type"] == "control:gap_detected"
        assert event["source_module"] == "signal_feed"


# ---------------------------------------------------------------------------
# Subscription filtering
# ---------------------------------------------------------------------------

class TestSubscriptionFiltering:
    def test_filter_by_event_type(self, transport):
        q = asyncio.Queue()
        feed_filter = SignalFeedFilter(event_types={"agent:wag"})
        transport.add_listener("test", q, feed_filter=feed_filter)

        transport.push(OperatorEventType.AGENT_WAG, {"agent": "a"})
        transport.push(OperatorEventType.AGENT_HEARTBEAT, {"agent": "a"})
        transport.push(OperatorEventType.HEALTH_RAISED, {"signal_id": "x"})

        events = []
        while not q.empty():
            events.append(q.get_nowait())
        assert len(events) == 1
        assert events[0]["type"] == "agent:wag"

    def test_filter_by_agent(self, transport):
        q = asyncio.Queue()
        feed_filter = SignalFeedFilter(agents={"codex"})
        transport.add_listener("test", q, feed_filter=feed_filter)

        transport.push(OperatorEventType.AGENT_WAG, {"agent": "codex"})
        transport.push(OperatorEventType.AGENT_WAG, {"agent": "claude-code"})

        events = []
        while not q.empty():
            events.append(q.get_nowait())
        assert len(events) == 1
        assert events[0]["agent"] == "codex"

    def test_filter_by_workspace(self, transport):
        q = asyncio.Queue()
        feed_filter = SignalFeedFilter(workspace_id="ws-abc")
        transport.add_listener("test", q, feed_filter=feed_filter)

        transport.push("agent:wag", {"agent": "a"}, workspace_id="ws-abc")
        transport.push("agent:wag", {"agent": "b"}, workspace_id="ws-xyz")
        transport.push("agent:wag", {"agent": "c"})  # no workspace — passes

        events = []
        while not q.empty():
            events.append(q.get_nowait())
        # ws-abc passes, ws-xyz blocked, no-workspace passes
        assert len(events) == 2

    def test_combined_filters_are_and_logic(self, transport):
        q = asyncio.Queue()
        feed_filter = SignalFeedFilter(
            agents={"codex"},
            event_types={"agent:wag"},
        )
        transport.add_listener("test", q, feed_filter=feed_filter)

        transport.push(OperatorEventType.AGENT_WAG, {"agent": "codex"})       # passes both
        transport.push(OperatorEventType.AGENT_WAG, {"agent": "claude-code"})  # fails agent
        transport.push(OperatorEventType.AGENT_HEARTBEAT, {"agent": "codex"})  # fails type

        events = []
        while not q.empty():
            events.append(q.get_nowait())
        assert len(events) == 1

    def test_no_filter_passes_everything(self, transport):
        q = asyncio.Queue()
        transport.add_listener("test", q)

        transport.push(OperatorEventType.AGENT_WAG, {"agent": "a"})
        transport.push(OperatorEventType.HEALTH_RAISED, {"signal_id": "x"})

        events = []
        while not q.empty():
            events.append(q.get_nowait())
        assert len(events) == 2

    def test_gap_detected_bypasses_event_type_filter(self, transport):
        """Control events like gap_detected always pass through filters."""
        transport.push("agent:wag", {"agent": "a"})  # seq=1

        q = asyncio.Queue()
        feed_filter = SignalFeedFilter(event_types={"agent:wag"})
        transport.add_listener("test", q, feed_filter=feed_filter, since_seq=0)

        # gap_detected should arrive even though it's not in the filter
        event = q.get_nowait()
        assert event["type"] == OperatorEventType.GAP_DETECTED


# ---------------------------------------------------------------------------
# SignalFeedFilter unit tests
# ---------------------------------------------------------------------------

class TestSignalFeedFilter:
    def test_empty_filter_matches_everything(self):
        f = SignalFeedFilter()
        assert f.matches({"type": "anything", "agent": "anyone"})

    def test_event_type_filter(self):
        f = SignalFeedFilter(event_types={"agent:wag"})
        assert f.matches({"type": "agent:wag"})
        assert not f.matches({"type": "agent:heartbeat"})

    def test_agent_filter(self):
        f = SignalFeedFilter(agents={"codex"})
        assert f.matches({"type": "x", "agent": "codex"})
        assert not f.matches({"type": "x", "agent": "claude-code"})
        # Events without agent field pass (can't filter on missing data)
        assert f.matches({"type": "x"})

    def test_workspace_filter(self):
        f = SignalFeedFilter(workspace_id="ws-1")
        assert f.matches({"type": "x", "workspace_id": "ws-1"})
        assert not f.matches({"type": "x", "workspace_id": "ws-2"})
        # Events without workspace pass
        assert f.matches({"type": "x"})

    def test_gap_detected_always_passes(self):
        f = SignalFeedFilter(event_types={"agent:wag"})
        assert f.matches({"type": "control:gap_detected"})


# ---------------------------------------------------------------------------
# Transport shutdown
# ---------------------------------------------------------------------------

class TestTransportShutdown:
    def test_shutdown_sends_none_sentinel(self, transport):
        q = asyncio.Queue()
        transport.add_listener("test", q)
        transport.shutdown()
        assert q.get_nowait() is None

    def test_shutdown_clears_listeners(self, transport):
        q = asyncio.Queue()
        transport.add_listener("test", q)
        transport.shutdown()
        assert len(transport._listeners) == 0
