"""Tests for execution packet quality — enriched baton payloads.

Covers:
- target_files, proof_bar, blast_radius in HandoffBaton
- Fields appear in serialized payload
- Empty execution fields are omitted
- Handoff round-trip preserves execution context
- Backward compatibility — old handoffs without execution fields still work
"""

import pytest
from whispers.twoack_schemas import HandoffBaton


class TestExecutionPackets:
    def test_execution_fields_in_payload(self):
        baton = HandoffBaton(
            objective="Implement scope-aware artifact fetch",
            deliverable="fetch_blob enforces workspace membership",
            target_files=("whispers/client.py", "whispers/storage/db.py", "whispers/mcp_server.py"),
            proof_bar="14 tests in test_artifact_scope.py all passing. py_compile clean on all touched files.",
            blast_radius="Existing fetch_blob callers get None instead of data when blocked. Check outbox and trace tools still work.",
        )
        payload = baton.to_payload()
        assert payload["target_files"] == ["whispers/client.py", "whispers/storage/db.py", "whispers/mcp_server.py"]
        assert payload["proof_bar"] == "14 tests in test_artifact_scope.py all passing. py_compile clean on all touched files."
        assert payload["blast_radius"] == "Existing fetch_blob callers get None instead of data when blocked. Check outbox and trace tools still work."

    def test_empty_execution_fields_omitted(self):
        baton = HandoffBaton(
            objective="Simple task",
            deliverable="A thing",
        )
        payload = baton.to_payload()
        assert "target_files" not in payload
        assert "proof_bar" not in payload
        assert "blast_radius" not in payload

    def test_partial_execution_fields(self):
        baton = HandoffBaton(
            objective="Review this",
            deliverable="Feedback",
            proof_bar="No regressions in test_whispers.py",
        )
        payload = baton.to_payload()
        assert "target_files" not in payload
        assert payload["proof_bar"] == "No regressions in test_whispers.py"
        assert "blast_radius" not in payload

    def test_execution_fields_ordering_in_payload(self):
        """Execution context appears after knowledge, before assets."""
        baton = HandoffBaton(
            objective="Build feature",
            deliverable="Working code",
            completed="Phase 1",
            remaining="Phase 2",
            target_files=("src/main.py",),
            proof_bar="Tests pass",
            risks=("Might break CI",),
        )
        payload = baton.to_payload()
        keys = list(payload.keys())
        # target_files should come before risks
        assert keys.index("target_files") < keys.index("risks")

    def test_backward_compat_old_handoff(self):
        """Handoffs created before execution fields still serialize correctly."""
        baton = HandoffBaton(
            objective="Legacy handoff",
            deliverable="Something",
            completed="Done stuff",
            remaining="More stuff",
            next_action="Do the thing",
            decisions=("Decision A",),
            artifacts=("artifact-ref-1",),
        )
        payload = baton.to_payload()
        assert payload["objective"] == "Legacy handoff"
        assert payload["decisions"] == ["Decision A"]
        assert "target_files" not in payload
        assert "proof_bar" not in payload

    def test_handoff_roundtrip_with_execution_context(self, tmp_path):
        """Send a handoff with execution fields and verify they survive."""
        from whispers.storage.db import WhispersDB
        from whispers.client import WhispersClient

        db_path = str(tmp_path / "test_exec.db")
        db = WhispersDB(db_path=db_path)
        sender = WhispersClient("alice", db_path=db_path)
        receiver = WhispersClient("bob", db_path=db_path)

        result = sender.send_handoff(
            to="bob",
            subject="Enriched handoff",
            objective="Build the thing",
            deliverable="Working implementation",
            target_files=["whispers/client.py", "tests/test_new.py"],
            proof_bar="pytest tests/test_new.py passes with 10+ tests",
            blast_radius="client.py send() method signature unchanged",
        )
        assert result["id"]

        # Receiver reads inbox
        messages = receiver.check_inbox()
        assert len(messages) >= 1
        msg = messages[0]
        import json
        payload = json.loads(msg["payload"]) if isinstance(msg["payload"], str) else msg["payload"]
        inner = payload.get("payload", payload)
        assert inner["target_files"] == ["whispers/client.py", "tests/test_new.py"]
        assert inner["proof_bar"] == "pytest tests/test_new.py passes with 10+ tests"
        assert inner["blast_radius"] == "client.py send() method signature unchanged"

    def test_handoff_without_execution_fields_still_works(self, tmp_path):
        """Existing handoff flow without new fields still works."""
        from whispers.storage.db import WhispersDB
        from whispers.client import WhispersClient

        db_path = str(tmp_path / "test_compat.db")
        db = WhispersDB(db_path=db_path)
        sender = WhispersClient("alice", db_path=db_path)

        result = sender.send_handoff(
            to="bob",
            subject="Basic handoff",
            objective="Do something",
            deliverable="A result",
        )
        assert result["id"]
