import importlib
import sys

import pytest
from fastapi.testclient import TestClient

from whispers.storage.db import WhispersDB


@pytest.fixture
def client(temp_db):
    """Provide a TestClient backed by an isolated temp database."""
    runtime_state_path = temp_db + "-runtime.json"
    original_module = sys.modules.get("whispers.server")
    original_db = getattr(original_module, "db", None) if original_module else None

    with pytest.MonkeyPatch.context() as mp:
        mp.setenv("WHISPERS_DB_PATH", temp_db)
        mp.setenv("WHISPERS_RUNTIME_STATE_PATH", runtime_state_path)

        import whispers.server as server_module

        server_module = importlib.reload(server_module)
        with TestClient(server_module.app) as test_client:
            yield test_client

    if original_db is not None:
        server_module.db = original_db


def test_agent_transitions_health_endpoint(client, temp_db):
    """The /health endpoint surfaces transition history recorded off the request path."""
    import whispers.server as server_module

    db = WhispersDB(temp_db)

    with db.get_connection() as conn:
        conn.execute(
            """
            INSERT INTO presence (agent_name, status, reception_mode, working_on, session_id)
            VALUES ('codex', 'online', 'open', 'idle', 'sess1')
            """
        )
        conn.execute(
            """
            INSERT INTO agent_runtime_state (session_id, agent_name, readiness, current_task)
            VALUES ('sess1', 'codex', 'ready', '')
            """
        )

    server_module._refresh_runtime_observability_artifacts()
    first = client.get("/health")
    assert first.status_code == 200
    assert first.json()["agent_events"] == []

    with db.get_connection() as conn:
        conn.execute("UPDATE agent_runtime_state SET readiness = 'busy'")

    server_module._refresh_runtime_observability_artifacts()
    second = client.get("/health")
    second_events = [
        event for event in second.json()["agent_events"]
        if event.get("agent_name") == "codex"
    ]
    assert len(second_events) == 1
    assert second_events[-1]["type"] == "readiness_changed"
    assert "busy" in second_events[-1]["detail"]

    with db.get_connection() as conn:
        conn.execute(
            """
            UPDATE agent_runtime_state
            SET current_task = 'refactoring db'
            WHERE agent_name = 'codex'
            """
        )

    server_module._refresh_runtime_observability_artifacts()
    third = client.get("/health")
    third_events = [
        event for event in third.json()["agent_events"]
        if event.get("agent_name") == "codex"
    ]
    assert len(third_events) == 2
    assert third_events[-1]["type"] == "working_on_changed"
    assert "refactoring db" in third_events[-1]["detail"]

    fourth = client.get("/health")
    fourth_events = [
        event for event in fourth.json()["agent_events"]
        if event.get("agent_name") == "codex"
    ]
    assert len(fourth_events) == 2
