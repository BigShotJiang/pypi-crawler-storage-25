import json
from datetime import datetime, timezone
from pathlib import Path

import pytest

from whispers.twoack import (
    ERR_EXPIRED,
    ERR_HOP_LIMIT_EXCEEDED,
    ERR_NEGOTIATION_FAILED,
    ERR_SCHEMA_INVALID,
    ERR_UNSUPPORTED_SCHEMA,
    PreflightPolicy,
    build_protocol_error,
    build_a2a_message,
    check_reply_schema_constraint,
    derive_text_fallback,
    evaluate_preflight,
    evaluate_conformance_level,
    extract_a2a_binding,
    extract_preflight,
    round_trip,
    validate_authority_claim,
    validate_envelope,
    validate_message,
    validate_schema,
)


def _load_envelope_cases():
    fixture_path = Path(__file__).resolve().parent / "fixtures" / "2ack" / "envelope_cases.json"
    return json.loads(fixture_path.read_text(encoding="utf-8"))


def _load_workspace_cases():
    fixture_path = Path(__file__).resolve().parent / "fixtures" / "2ack" / "workspace_and_error_cases.json"
    return json.loads(fixture_path.read_text(encoding="utf-8"))


_ENVELOPE_CASES = _load_envelope_cases()
_WORKSPACE_CASES = _load_workspace_cases()


@pytest.mark.parametrize("case", _ENVELOPE_CASES, ids=[case["description"] for case in _ENVELOPE_CASES])
def test_validate_envelope_cases(case):
    result = validate_envelope(case["input"])
    assert result.valid is case["expected_valid"]
    assert result.codes == case["expected_error_codes"]

    if case["expected_valid"]:
        assert round_trip(case["input"]) == case["input"]


def test_validate_message_accepts_spec_vectors():
    messages = [
        {
            "wire_v": 1,
            "schema": "status_update.v1",
            "trace": {"message_id": "msg-min-1"},
            "payload": {"state": "idle"},
        },
        {
            "wire_v": 1,
            "schema": "handoff_baton.v1",
            "mode": "bilingual",
            "signal_class": "whispers_internal",
            "source": "agent",
            "trace": {"message_id": "msg-0001", "trace_id": "flow-master"},
            "max_hops": 3,
            "summary": {
                "headline": "Passing auth routing to codex",
                "human": "Need Codex to resolve the JWT signature error.",
            },
            "payload": {
                "objective": "Resolve JWT signature validation in auth layer",
                "deliverable": "A passing test suite for auth",
                "dead_ends": ["Do not touch the database integration"],
                "artifacts": ["whispers://logs/jwt_fail_trace"],
            },
        },
        {
            "wire_v": 1,
            "schema": "external_action_request.v1",
            "mode": "bilingual",
            "signal_class": "external",
            "source": "human",
            "trace": {
                "message_id": "msg-0003",
                "trace_id": "deploy-approval-1",
                "in_reply_to": "msg-ask-approve-7",
            },
            "authority": {
                "principal": "zack",
                "scope": ["deploy:staging"],
                "expires_at": "2026-03-24T19:30:00Z",
            },
            "authority_proof": {
                "kind": "delegation_token",
                "ref": "whispers://proofs/deploy-approval-1",
            },
            "summary": {
                "headline": "Approve staging deploy",
                "human": "Zack approved the staging deploy from mobile.",
            },
            "payload": {
                "action_class": "deploy",
                "intent": "Ship the reviewed changes to staging",
                "target": "staging",
                "risk_level": "elevated",
                "audit_note": "Mobile approval while away from desk",
            },
        },
        {
            "wire_v": 1,
            "schema": "protocol_error.v1",
            "mode": "agent-native",
            "signal_class": "whispers_internal",
            "trace": {"message_id": "msg-proto-err-1", "trace_id": "flow-master"},
            "payload": {
                "error_code": "ERR_NEGOTIATION_FAILED",
                "rejected_message_id": "msg-0004",
                "rejected_schema": "decision_request.v1",
                "reason": "Receiver cannot produce the requested reply schema.",
                "offered_alternatives": ["status_update.v1"],
                "recoverable": True,
            },
        },
        {
            "wire_v": 1,
            "schema": "decision_request.v1",
            "mode": "agent-native",
            "trace": {"message_id": "msg-0004", "trace_id": "release-cut-9"},
            "policy_hint": {
                "reply_expected": True,
                "reply_by": "2026-03-24T20:00:00Z",
                "defer_ok": False,
            },
            "accept_schemas": ["decision_response.v1"],
            "payload": {
                "question": "Cut the release branch now?",
                "options": ["yes", "wait"],
                "recommended_option": "yes",
                "blocking": True,
                "risk_if_wrong": "Delaying will miss the test window.",
            },
        },
    ]

    for message in messages:
        result = validate_message(message)
        assert result.valid, result.errors


def test_validate_message_rejects_unknown_schema_vector():
    message = {
        "wire_v": 1,
        "schema": "decision_request.v2",
        "trace": {"message_id": "msg-0002"},
        "accept_schemas": ["decision_response.v1"],
        "payload": {
            "question": "Deploy to production?",
            "options": ["yes", "no"],
        },
    }

    result = validate_message(message)
    assert not result.valid
    assert result.codes == [ERR_UNSUPPORTED_SCHEMA]


def test_validate_envelope_rejects_excessive_depth():
    from whispers.twoack import MAX_ENVELOPE_DEPTH, ERR_MALFORMED_ENVELOPE
    
    # Build a compliant envelope but with a payload that is too deep
    envelope = {
        "wire_v": 1,
        "schema": "status_update.v1",
        "trace": {"message_id": "msg-depth-1"},
    }
    
    # Nesting exactly MAX_ENVELOPE_DEPTH should pass, but the envelope itself
    # adds 1 or 2 levels depending on how it's structured.
    # The depth check starts with current_depth=1 at the envelope root.
    # We will build something deeper than MAX_ENVELOPE_DEPTH just to be sure.
    deep_payload = {"value": "deep"}
    for _ in range(MAX_ENVELOPE_DEPTH + 2):
        deep_payload = {"nested": deep_payload}
        
    envelope["payload"] = deep_payload
    
    result = validate_envelope(envelope)
    assert not result.valid
    assert ERR_MALFORMED_ENVELOPE in result.codes
    # Verify the message specifically mentions depth
    assert any("recursive depth" in e.message for e in result.errors)


@pytest.mark.parametrize(
    ("schema_id", "payload", "expected_code"),
    [
        (
            "decision_request.v1",
            {"question": "Deploy?", "options": [], "recommended_option": "yes"},
            ERR_SCHEMA_INVALID,
        ),
        (
            "decision_request.v1",
            {"question": "Deploy?", "options": ["yes", "no"], "recommended_option": "maybe"},
            ERR_SCHEMA_INVALID,
        ),
        (
            "decision_response.v1",
            {"decision": "yes", "confidence": 1.5},
            ERR_SCHEMA_INVALID,
        ),
        (
            "external_action_request.v1",
            {"action_class": "deploy", "intent": "Ship it", "risk_level": "medium"},
            ERR_SCHEMA_INVALID,
        ),
    ],
)
def test_validate_schema_constraints(schema_id, payload, expected_code):
    result = validate_schema(schema_id, payload)
    assert not result.valid
    assert expected_code in result.codes


def test_extract_preflight_surface_and_expiry():
    envelope = {
        "wire_v": 1,
        "schema": "decision_request.v1",
        "signal_class": "external",
        "trust": {
            "tier_required": "operator",
            "requires_operator": True,
        },
        "expires_at": "2026-03-25T12:00:00Z",
        "max_hops": 2,
        "accept_schemas": ["decision_response.v1"],
        "trace": {"message_id": "msg-preflight-1"},
        "payload": {
            "question": "Deploy?",
            "options": ["yes", "no"],
        },
    }

    preflight = extract_preflight(envelope)
    assert preflight.wire_v == 1
    assert preflight.schema == "decision_request.v1"
    assert preflight.signal_class == "external"
    assert preflight.tier_required == "operator"
    assert preflight.requires_operator is True
    assert preflight.max_hops == 2
    assert preflight.accept_schemas == ("decision_response.v1",)
    assert preflight.message_id == "msg-preflight-1"
    assert preflight.is_expired(now=datetime(2026, 3, 25, 12, 1, tzinfo=timezone.utc)) is True
    assert preflight.is_expired(now=datetime(2026, 3, 25, 11, 59, tzinfo=timezone.utc)) is False


def test_evaluate_preflight_rejects_expired_signal():
    envelope = {
        "wire_v": 1,
        "schema": "status_update.v1",
        "expires_at": "2026-03-25T12:00:00Z",
        "trace": {"message_id": "msg-expired-1"},
        "payload": {"state": "idle"},
    }

    decision = evaluate_preflight(envelope, now="2026-03-25T12:01:00Z")
    assert decision.rejected is True
    assert decision.code == ERR_EXPIRED


def test_evaluate_preflight_rejects_exhausted_hops_when_forwarding():
    envelope = {
        "wire_v": 1,
        "schema": "status_update.v1",
        "max_hops": 0,
        "trace": {"message_id": "msg-hop-1"},
        "payload": {"state": "idle"},
    }

    decision = evaluate_preflight(envelope, require_forwardable=True)
    assert decision.rejected is True
    assert decision.code == ERR_HOP_LIMIT_EXCEEDED


def test_evaluate_preflight_rejects_reply_schema_outside_accept_schemas():
    envelope = {
        "wire_v": 1,
        "schema": "decision_request.v1",
        "accept_schemas": ["decision_response.v1"],
        "trace": {"message_id": "msg-negotiation-1"},
        "payload": {"question": "Deploy?", "options": ["yes", "no"]},
    }

    decision = evaluate_preflight(envelope, proposed_reply_schema="handoff_baton.v1")
    assert decision.rejected is True
    assert decision.code == ERR_NEGOTIATION_FAILED


def test_evaluate_preflight_includes_offered_alternatives_on_negotiation_reject():
    envelope = {
        "wire_v": 1,
        "schema": "decision_request.v1",
        "accept_schemas": ["decision_response.v1"],
        "trace": {"message_id": "msg-negotiation-2"},
        "payload": {"question": "Deploy?", "options": ["yes", "no"]},
    }

    decision = evaluate_preflight(
        envelope,
        proposed_reply_schema="handoff_baton.v1",
        available_reply_schemas=("status_update.v1", "decision_response.v1"),
    )
    assert decision.rejected is True
    assert decision.code == ERR_NEGOTIATION_FAILED
    assert decision.offered_alternatives == ("status_update.v1", "decision_response.v1")


def test_evaluate_preflight_defers_when_operator_is_required_but_unavailable():
    envelope = {
        "wire_v": 1,
        "schema": "decision_request.v1",
        "trust": {"requires_operator": True},
        "trace": {"message_id": "msg-operator-1"},
        "payload": {"question": "Deploy?", "options": ["yes", "no"]},
    }

    decision = evaluate_preflight(
        envelope,
        policy=PreflightPolicy(operator_available=False),
    )
    assert decision.deferred is True
    assert decision.reason == "Signal requires operator approval before action."


def test_round_trip_preserves_omission_semantics():
    envelope = {
        "wire_v": 1,
        "schema": "status_update.v1",
        "trace": {"message_id": "msg-omit-2"},
        "summary": None,
        "trust": {},
        "accept_schemas": [],
        "received_via": [],
        "payload": {"state": "idle"},
    }

    echoed = round_trip(envelope)
    assert "summary" in echoed and echoed["summary"] is None
    assert "trust" in echoed and echoed["trust"] == {}
    assert "accept_schemas" in echoed and echoed["accept_schemas"] == []
    assert "received_via" in echoed and echoed["received_via"] == []

def test_validate_message_bypasses_schema_when_encrypted():
    message = {
        "wire_v": 1,
        "schema": "decision_request.v1",
        "encryption": {"alg": "aes-256-gcm"},
        "trace": {"message_id": "msg-crypto-1"},
        "payload": "v2FzZGY="
    }
    result = validate_message(message)
    assert result.valid


@pytest.mark.parametrize("case", _WORKSPACE_CASES, ids=[case["description"] for case in _WORKSPACE_CASES])
def test_validate_message_accepts_workspace_vectors(case):
    result = validate_message(case["input"])
    assert result.valid is case["expected_valid"]
    assert result.codes == case["expected_error_codes"]


def test_validate_workspace_join_accepts_interest_and_receive_rate_fields():
    message = {
        "wire_v": 1,
        "schema": "workspace_join.v1",
        "trace": {"message_id": "msg-ws-join-traffic-1"},
        "payload": {
            "workspace_id": "ws_scale_test",
            "membership_role": "member",
            "interests": ["handoff_in", "decision", "lifecycle"],
            "max_receive_rate": 120,
        },
    }

    result = validate_message(message)
    assert result.valid


def test_validate_workspace_delta_accepts_traffic_shaping_fields():
    message = {
        "wire_v": 1,
        "schema": "workspace_delta.v1",
        "trace": {"message_id": "msg-ws-delta-traffic-1"},
        "payload": {
            "workspace_id": "ws_scale_test",
            "delta_kind": "telemetry",
            "text": "Queue depth increased on build agents",
            "priority": "background",
            "ttl": 30,
            "drop_policy": "drop_if_backed_up",
            "channel": "telemetry",
        },
    }

    result = validate_message(message)
    assert result.valid


def test_validate_workspace_delta_rejects_unknown_priority():
    message = {
        "wire_v": 1,
        "schema": "workspace_delta.v1",
        "trace": {"message_id": "msg-ws-delta-traffic-2"},
        "payload": {
            "workspace_id": "ws_scale_test",
            "delta_kind": "telemetry",
            "priority": "urgent",
        },
    }

    result = validate_message(message)
    assert result.valid is False
    assert result.codes == [ERR_SCHEMA_INVALID]

def test_validate_message_ignores_unknown_ext():
    message = {
        "wire_v": 1,
        "schema": "status_update.v1",
        "ext": {"whispers:experimental_feature": {"huge": "blob"}},
        "trace": {"message_id": "msg-ext-1"},
        "payload": {"state": "idle"}
    }
    result = validate_message(message)
    assert result.valid


def test_validate_handoff_baton_accepts_proof_milestone_extension_fields():
    message = {
        "wire_v": 1,
        "schema": "handoff_baton.v1",
        "trace": {"message_id": "msg-handoff-ext-1"},
        "payload": {
            "objective": "Finish the workspace API slice",
            "deliverable": "Runtime endpoints and tests",
            "completed": "DB methods and initial routes landed",
            "remaining": "Wire client wrappers and run E2E tests",
            "next_action": "Implement remote client calls for workspace state",
            "assumptions": ["WS0 keeps state query-based"],
            "risks": ["Endpoint shape could drift before Console catches up"],
            "workspace_id": "ws_1234abcd",
            "artifacts": ["whispers://docs/workspace-api"],
        },
    }

    result = validate_message(message)
    assert result.valid


def test_validate_baton_ack_rejects_decision_outside_allowed_values():
    message = {
        "wire_v": 1,
        "schema": "baton_ack.v1",
        "trace": {"message_id": "msg-baton-ack-invalid"},
        "payload": {
            "baton_ref": "baton-123",
            "decision": "maybe",
        },
    }

    result = validate_message(message)
    assert result.valid is False
    assert ERR_SCHEMA_INVALID in result.codes
    assert any(error.path == "payload.decision" for error in result.errors)


def test_validate_baton_ack_requires_conditions_when_conditionally_accepted():
    message = {
        "wire_v": 1,
        "schema": "baton_ack.v1",
        "trace": {"message_id": "msg-baton-ack-conditional"},
        "payload": {
            "baton_ref": "baton-124",
            "decision": "conditionally_accepted",
        },
    }

    result = validate_message(message)
    assert result.valid is False
    assert any(error.path == "payload.conditions" for error in result.errors)


def test_validate_baton_ack_requires_reason_when_rejected():
    message = {
        "wire_v": 1,
        "schema": "baton_ack.v1",
        "trace": {"message_id": "msg-baton-ack-rejected"},
        "payload": {
            "baton_ref": "baton-125",
            "decision": "rejected",
        },
    }

    result = validate_message(message)
    assert result.valid is False
    assert any(error.path == "payload.reason" for error in result.errors)


def test_validate_baton_update_rejects_state_outside_allowed_values():
    message = {
        "wire_v": 1,
        "schema": "baton_update.v1",
        "trace": {"message_id": "msg-baton-update-invalid"},
        "payload": {
            "baton_ref": "baton-126",
            "state": "drifting",
        },
    }

    result = validate_message(message)
    assert result.valid is False
    assert any(error.path == "payload.state" for error in result.errors)


def test_validate_baton_close_rejects_outcome_outside_allowed_values():
    message = {
        "wire_v": 1,
        "schema": "baton_close.v1",
        "trace": {"message_id": "msg-baton-close-invalid"},
        "payload": {
            "baton_ref": "baton-127",
            "outcome": "shrug",
        },
    }

    result = validate_message(message)
    assert result.valid is False
    assert any(error.path == "payload.outcome" for error in result.errors)


def test_validate_baton_ack_valid_accepted():
    message = {
        "wire_v": 1,
        "schema": "baton_ack.v1",
        "trace": {"message_id": "msg-baton-ack-accept"},
        "payload": {
            "baton_ref": "baton-200",
            "decision": "accepted",
        },
    }
    result = validate_message(message)
    assert result.valid is True


def test_validate_baton_ack_valid_conditionally_accepted_with_conditions():
    message = {
        "wire_v": 1,
        "schema": "baton_ack.v1",
        "trace": {"message_id": "msg-baton-ack-conditional-ok"},
        "payload": {
            "baton_ref": "baton-201",
            "decision": "conditionally_accepted",
            "conditions": ["Must pass integration tests first"],
        },
    }
    result = validate_message(message)
    assert result.valid is True


def test_validate_baton_ack_valid_rejected_with_reason():
    message = {
        "wire_v": 1,
        "schema": "baton_ack.v1",
        "trace": {"message_id": "msg-baton-ack-reject-ok"},
        "payload": {
            "baton_ref": "baton-202",
            "decision": "rejected",
            "reason": "Out of scope for my current lane",
        },
    }
    result = validate_message(message)
    assert result.valid is True


def test_validate_baton_update_valid():
    message = {
        "wire_v": 1,
        "schema": "baton_update.v1",
        "trace": {"message_id": "msg-baton-update-ok"},
        "payload": {
            "baton_ref": "baton-203",
            "state": "in_progress",
            "progress": "50% complete",
        },
    }
    result = validate_message(message)
    assert result.valid is True


def test_validate_baton_close_valid():
    message = {
        "wire_v": 1,
        "schema": "baton_close.v1",
        "trace": {"message_id": "msg-baton-close-ok"},
        "payload": {
            "baton_ref": "baton-204",
            "outcome": "completed",
            "summary": "All slices landed, 29 tests passing",
        },
    }
    result = validate_message(message)
    assert result.valid is True


def test_validate_baton_close_valid_all_outcomes():
    """All allowed outcomes should pass validation."""
    for outcome in ["completed", "merged", "blocked", "superseded", "expired"]:
        message = {
            "wire_v": 1,
            "schema": "baton_close.v1",
            "trace": {"message_id": f"msg-baton-close-{outcome}"},
            "payload": {
                "baton_ref": f"baton-{outcome}",
                "outcome": outcome,
            },
        }
        result = validate_message(message)
        assert result.valid is True, f"outcome '{outcome}' should be valid but got: {[e.message for e in result.errors]}"


def test_validate_baton_update_valid_all_states():
    """All allowed states should pass validation."""
    for state in ["in_progress", "blocked", "review_pending"]:
        message = {
            "wire_v": 1,
            "schema": "baton_update.v1",
            "trace": {"message_id": f"msg-baton-update-{state}"},
            "payload": {
                "baton_ref": f"baton-{state}",
                "state": state,
            },
        }
        result = validate_message(message)
        assert result.valid is True, f"state '{state}' should be valid but got: {[e.message for e in result.errors]}"


def test_build_protocol_error_creates_valid_protocol_error_envelope():
    envelope = build_protocol_error(
        message_id="msg-proto-err-2",
        rejected_message_id="msg-original-1",
        error_code="ERR_NEGOTIATION_FAILED",
        reason="Reply schema is not accepted.",
        trace_id="trace-1",
        thread_id="thread-1",
        rejected_schema="decision_request.v1",
        offered_alternatives=["status_update.v1"],
        recoverable=True,
    )

    assert envelope["schema"] == "protocol_error.v1"
    assert envelope["payload"]["rejected_message_id"] == "msg-original-1"
    assert envelope["payload"]["offered_alternatives"] == ["status_update.v1"]
    assert validate_message(envelope).valid


def test_build_a2a_message_places_twoack_in_data_and_aligns_message_id():
    envelope = {
        "wire_v": 1,
        "schema": "decision_request.v1",
        "mode": "bilingual",
        "signal_class": "external",
        "trace": {"message_id": "msg-a2a-1"},
        "summary": {
            "headline": "Deploy decision",
            "human": "Should we deploy now?",
        },
        "payload": {
            "question": "Deploy?",
            "options": ["yes", "no"],
        },
    }

    message = build_a2a_message(envelope, metadata={"whispers:recipient": "echo-agent"})
    assert message["messageId"] == "msg-a2a-1"
    assert message["parts"][0]["data"] == envelope
    assert message["parts"][1]["text"] == "Should we deploy now?"
    assert message["metadata"]["whispers:schema"] == "decision_request.v1"
    assert message["metadata"]["whispers:wireMode"] == "bilingual"
    assert message["metadata"]["whispers:signalClass"] == "external"


def test_derive_text_fallback_uses_progressive_disclosure_order():
    envelope = {
        "wire_v": 1,
        "schema": "status_update.v1",
        "trace": {"message_id": "msg-fallback-1"},
        "summary": {
            "headline": "Idle",
            "brief": "Agent is idle",
            "human": "Agent is idle and ready for work.",
        },
        "payload": {"state": "idle"},
    }

    assert derive_text_fallback(envelope) == "Agent is idle and ready for work."
    del envelope["summary"]["human"]
    assert derive_text_fallback(envelope) == "Agent is idle"
    del envelope["summary"]["brief"]
    assert derive_text_fallback(envelope) == "Idle"


def test_extract_a2a_binding_prefers_envelope_over_conflicting_mirrors():
    envelope = {
        "wire_v": 1,
        "schema": "status_update.v1",
        "mode": "agent-native",
        "signal_class": "internal",
        "trace": {"message_id": "msg-bind-1"},
        "payload": {"state": "idle"},
    }
    message = {
        "role": "user",
        "messageId": "outer-msg-mismatch",
        "parts": [
            {"text": "fallback text"},
            {"data": envelope},
        ],
        "metadata": {
            "whispers:schema": "decision_request.v1",
            "whispers:wireMode": "bilingual",
            "whispers:signalClass": "external",
        },
    }

    binding = extract_a2a_binding(message)
    assert binding.envelope == envelope
    assert binding.fallback_text == "fallback text"
    assert binding.conflicts == (
        "whispers:schema",
        "whispers:wireMode",
        "whispers:signalClass",
        "messageId",
    )


def test_evaluate_conformance_level_zero_uses_text_only():
    envelope = {
        "wire_v": 1,
        "schema": "status_update.v1",
        "trace": {"message_id": "msg-level-0"},
        "payload": {"state": "idle"},
    }
    message = {
        "role": "user",
        "messageId": "msg-level-0",
        "parts": [
            {"text": "Plain text fallback"},
            {"data": envelope},
        ],
    }

    observation = evaluate_conformance_level(message, 0)
    assert observation.fallback_text == "Plain text fallback"
    assert observation.preserved_envelope is None
    assert observation.can_execute is False
    assert observation.rejection_code is None


def test_evaluate_conformance_level_one_preserves_unknown_schema_without_execution():
    message = {
        "role": "user",
        "messageId": "msg-level-1",
        "parts": [
            {
                "data": {
                    "wire_v": 1,
                    "schema": "decision_request.v2",
                    "trace": {"message_id": "msg-level-1"},
                    "payload": {"question": "Deploy?", "options": ["yes", "no"]},
                }
            }
        ],
    }

    observation = evaluate_conformance_level(message, 1)
    assert observation.envelope_present is True
    assert observation.preserved_envelope["schema"] == "decision_request.v2"
    assert observation.can_execute is False
    assert observation.rejection_code is None


def test_evaluate_conformance_level_two_rejects_unknown_schema():
    message = {
        "role": "user",
        "messageId": "msg-level-2",
        "parts": [
            {
                "data": {
                    "wire_v": 1,
                    "schema": "decision_request.v2",
                    "trace": {"message_id": "msg-level-2"},
                    "payload": {"question": "Deploy?", "options": ["yes", "no"]},
                }
            }
        ],
    }

    observation = evaluate_conformance_level(message, 2)
    assert observation.can_execute is False
    assert observation.rejection_code == ERR_UNSUPPORTED_SCHEMA


def test_evaluate_conformance_level_two_executes_valid_known_schema():
    message = {
        "role": "user",
        "messageId": "msg-level-3",
        "parts": [
            {
                "data": {
                    "wire_v": 1,
                    "schema": "decision_request.v1",
                    "trace": {"message_id": "msg-level-3"},
                    "payload": {"question": "Deploy?", "options": ["yes", "no"]},
                }
            }
        ],
    }

    observation = evaluate_conformance_level(message, 2)
    assert observation.can_execute is True
    assert observation.rejection_code is None


# --- accept_schemas constraint tests ---


def test_check_reply_schema_allowed():
    """Reply schema in accept_schemas passes."""
    original = {
        "wire_v": 1,
        "schema": "decision_request.v1",
        "accept_schemas": ["decision_response.v1"],
        "trace": {"message_id": "msg-orig"},
        "payload": {"question": "Deploy?", "options": ["yes", "no"]},
    }
    reply = {
        "wire_v": 1,
        "schema": "decision_response.v1",
        "trace": {"message_id": "msg-reply"},
        "payload": {"decision": "yes"},
    }
    assert check_reply_schema_constraint(original, reply) is None


def test_check_reply_schema_rejected():
    """Reply schema NOT in accept_schemas is rejected."""
    original = {
        "wire_v": 1,
        "schema": "decision_request.v1",
        "accept_schemas": ["decision_response.v1"],
        "trace": {"message_id": "msg-orig"},
        "payload": {"question": "Deploy?", "options": ["yes", "no"]},
    }
    reply = {
        "wire_v": 1,
        "schema": "status_update.v1",
        "trace": {"message_id": "msg-reply"},
        "payload": {"state": "building"},
    }
    result = check_reply_schema_constraint(original, reply)
    assert result is not None
    assert "status_update.v1" in result
    assert "decision_response.v1" in result


def test_check_reply_schema_no_constraint():
    """No accept_schemas means any reply schema is fine."""
    original = {
        "wire_v": 1,
        "schema": "decision_request.v1",
        "trace": {"message_id": "msg-orig"},
        "payload": {"question": "Deploy?", "options": ["yes", "no"]},
    }
    reply = {
        "wire_v": 1,
        "schema": "status_update.v1",
        "trace": {"message_id": "msg-reply"},
        "payload": {"state": "building"},
    }
    assert check_reply_schema_constraint(original, reply) is None


def test_check_reply_schema_non_2ack_payloads():
    """Non-dict payloads are silently allowed (not 2ack)."""
    assert check_reply_schema_constraint("hello", {"schema": "x.v1"}) is None
    assert check_reply_schema_constraint({"accept_schemas": ["x.v1"]}, None) is None
    assert check_reply_schema_constraint(None, None) is None


def test_check_reply_schema_accepts_json_encoded_original_envelope():
    original = json.dumps({
        "wire_v": 1,
        "schema": "decision_request.v1",
        "accept_schemas": ["decision_response.v1"],
        "trace": {"message_id": "msg-orig"},
        "payload": {"question": "Deploy?", "options": ["yes", "no"]},
    })
    reply = {
        "wire_v": 1,
        "schema": "status_update.v1",
        "trace": {"message_id": "msg-reply"},
        "payload": {"state": "building"},
    }

    result = check_reply_schema_constraint(original, reply)
    assert result is not None
    assert "status_update.v1" in result


def test_check_reply_protocol_error_always_allowed():
    """protocol_error.v1 replies should be in accept_schemas or skip check."""
    original = {
        "wire_v": 1,
        "schema": "decision_request.v1",
        "accept_schemas": ["decision_response.v1"],
        "trace": {"message_id": "msg-orig"},
        "payload": {"question": "Deploy?", "options": ["yes", "no"]},
    }
    error_reply = {
        "wire_v": 1,
        "schema": "protocol_error.v1",
        "trace": {"message_id": "msg-err"},
        "payload": {
            "error_code": "ERR_NEGOTIATION_FAILED",
            "rejected_message_id": "msg-orig",
            "reason": "Cannot respond in any accepted schema",
        },
    }
    # protocol_error.v1 is exempt from accept_schemas — agents must always
    # be able to send typed rejections
    result = check_reply_schema_constraint(original, error_reply)
    assert result is None  # Exempt — always allowed


def test_validate_schema_decision_response_rejects_decision_outside_request_options():
    envelope = {
        "trace": {"in_reply_to": "msg-request-1"},
        "request_options": ["yes", "no"],
    }
    result = validate_schema(
        "decision_response.v1",
        {"decision": "maybe"},
        envelope=envelope,
    )
    assert not result.valid
    assert ERR_SCHEMA_INVALID in result.codes
    assert any(error.path == "payload.decision" for error in result.errors)


def test_validate_message_rejects_reply_schema_outside_original_accept_schemas():
    original = {
        "wire_v": 1,
        "schema": "decision_request.v1",
        "accept_schemas": ["decision_response.v1"],
        "trace": {"message_id": "msg-request-1"},
        "payload": {"question": "Deploy?", "options": ["yes", "no"]},
    }
    reply = {
        "wire_v": 1,
        "schema": "status_update.v1",
        "trace": {
            "message_id": "msg-reply-1",
            "in_reply_to": "msg-request-1",
        },
        "payload": {"state": "building"},
    }

    result = validate_message(reply, original_envelope=original)
    assert result.valid is False
    assert ERR_NEGOTIATION_FAILED in result.codes
    assert any(error.path == "schema" for error in result.errors)


def test_validate_message_accepts_reply_schema_allowed_by_original_accept_schemas():
    original = {
        "wire_v": 1,
        "schema": "decision_request.v1",
        "accept_schemas": ["decision_response.v1"],
        "trace": {"message_id": "msg-request-2"},
        "payload": {"question": "Deploy?", "options": ["yes", "no"]},
    }
    reply = {
        "wire_v": 1,
        "schema": "decision_response.v1",
        "trace": {
            "message_id": "msg-reply-2",
            "in_reply_to": "msg-request-2",
        },
        "payload": {"decision": "yes"},
    }

    result = validate_message(reply, original_envelope=original)
    assert result.valid


# --- authority proof validation tests ---


def test_authority_claim_no_authority():
    """No authority field means no validation needed."""
    envelope = {
        "wire_v": 1,
        "schema": "handoff_baton.v1",
        "trace": {"message_id": "msg-1"},
        "payload": {"objective": "test", "deliverable": "test"},
    }
    assert validate_authority_claim(envelope) is None


def test_authority_claim_missing_proof():
    """Authority without proof is an error."""
    envelope = {
        "wire_v": 1,
        "schema": "handoff_baton.v1",
        "trace": {"message_id": "msg-1"},
        "authority": {"principal": "zack", "scope": {"deploy": "staging"}},
        "payload": {"objective": "test", "deliverable": "test"},
    }
    result = validate_authority_claim(envelope)
    assert result is not None
    assert "authority_proof is required" in result


def test_authority_claim_server_nonce_structural():
    """Server nonce proof passes structural check (no verifier)."""
    envelope = {
        "wire_v": 1,
        "schema": "external_action_request.v1",
        "trace": {"message_id": "msg-1"},
        "authority": {"principal": "zack", "scope": {"deploy": "staging"}},
        "authority_proof": {"kind": "server_nonce", "nonce": "sn-abc123"},
        "payload": {"action_class": "deploy", "intent": "Ship to staging"},
    }
    assert validate_authority_claim(envelope) is None


def test_authority_claim_server_nonce_verified():
    """Server nonce passes when verifier returns True."""
    envelope = {
        "wire_v": 1,
        "schema": "external_action_request.v1",
        "trace": {"message_id": "msg-1"},
        "authority": {"principal": "zack", "scope": {"deploy": "staging"}},
        "authority_proof": {"kind": "server_nonce", "nonce": "sn-abc123"},
        "payload": {"action_class": "deploy", "intent": "Ship to staging"},
    }
    assert validate_authority_claim(envelope, verify_nonce=lambda n, s: True) is None


def test_authority_claim_server_nonce_rejected():
    """Server nonce fails when verifier returns False."""
    envelope = {
        "wire_v": 1,
        "schema": "external_action_request.v1",
        "trace": {"message_id": "msg-1"},
        "authority": {"principal": "zack", "scope": {"deploy": "staging"}},
        "authority_proof": {"kind": "server_nonce", "nonce": "sn-expired"},
        "payload": {"action_class": "deploy", "intent": "Ship to staging"},
    }
    result = validate_authority_claim(envelope, verify_nonce=lambda n, s: False)
    assert result is not None
    assert "verification failed" in result


def test_authority_claim_delegation_token():
    """Delegation token proof passes structural check."""
    envelope = {
        "wire_v": 1,
        "schema": "external_action_request.v1",
        "trace": {"message_id": "msg-1"},
        "authority": {"principal": "zack", "scope": ["deploy:staging"]},
        "authority_proof": {"kind": "delegation_token", "ref": "whispers://proofs/deploy-1"},
        "payload": {"action_class": "deploy", "intent": "Ship to staging"},
    }
    assert validate_authority_claim(envelope) is None


def test_authority_claim_missing_principal():
    """Authority without principal is an error."""
    envelope = {
        "wire_v": 1,
        "schema": "handoff_baton.v1",
        "trace": {"message_id": "msg-1"},
        "authority": {"scope": {"deploy": "staging"}},
        "authority_proof": {"kind": "server_nonce", "nonce": "sn-123"},
        "payload": {"objective": "test", "deliverable": "test"},
    }
    result = validate_authority_claim(envelope)
    assert result is not None
    assert "principal" in result
