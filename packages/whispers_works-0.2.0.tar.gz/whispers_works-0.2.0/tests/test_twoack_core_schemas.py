import pytest
from whispers.twoack_schemas import (
    StatusUpdate,
    HandoffBaton,
    DecisionRequest,
    DecisionResponse,
    ExternalActionRequest
)

def test_status_update_omission_semantics():
    # Only required fields provided
    su = StatusUpdate(state="idle", readiness="ready")
    payload = su.to_payload()
    
    assert "state" in payload
    assert "readiness" in payload
    assert payload["state"] == "idle"
    # Unprovided fields should be OMITTED entirely, not null
    assert "current_task" not in payload
    assert "interruptibility" not in payload
    assert "confidence" not in payload
    assert "working_set" not in payload

def test_status_update_explicit_null():
    # If explicitly set to None, it should be null in payload (if allowed by schema, but typically we just omit or null)
    # The to_payload logic currently omits None. Wait, twoack.py omission semantics say "absent fields = omitted, explicitly null = null for fields that allow it".
    # For StatusUpdate, our dataclass uses Optional mapping to omitted.
    su = StatusUpdate(state="building", readiness="busy", current_task=None)
    payload = su.to_payload()
    assert "current_task" not in payload

def test_handoff_baton_serialization():
    baton = HandoffBaton(
        objective="Deliver new UI",
        deliverable="PR with new UI",
        next_action="Review PR",
        open_questions=("How to handle error state?",)
    )
    payload = baton.to_payload()
    assert payload["objective"] == "Deliver new UI"
    assert payload["deliverable"] == "PR with new UI"
    assert payload["next_action"] == "Review PR"
    assert payload["open_questions"] == ["How to handle error state?"]
    # Unused fields omitted
    assert "repo_focus" not in payload
    assert "dead_ends" not in payload
    assert "completed" not in payload

def test_decision_request_serialization():
    req = DecisionRequest(
        question="Which DB?",
        options=("Postgres", "SQLite"),
        blocking=True
    )
    payload = req.to_payload()
    assert payload["question"] == "Which DB?"
    assert payload["options"] == ["Postgres", "SQLite"]
    assert payload["blocking"] is True
    assert "recommended_option" not in payload
    assert "deadline" not in payload

def test_decision_response_serialization():
    resp = DecisionResponse(
        decision="Postgres",
        confidence=0.9
    )
    payload = resp.to_payload()
    assert payload["decision"] == "Postgres"
    assert payload["confidence"] == 0.9
    assert "reason" not in payload
    assert "conditions" not in payload

def test_external_action_request_serialization():
    req = ExternalActionRequest(
        action_class="merge_pr",
        intent="Merge feature branch to main",
        risk_level="elevated"
    )
    payload = req.to_payload()
    assert payload["action_class"] == "merge_pr"
    assert payload["intent"] == "Merge feature branch to main"
    assert payload["risk_level"] == "elevated"
    assert "target" not in payload
