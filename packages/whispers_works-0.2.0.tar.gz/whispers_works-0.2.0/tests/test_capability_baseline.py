"""Tests for capability baseline vs operating state.

Covers:
- Baseline model class inference from model_id
- Performance assessment: titan degraded, titan at baseline
- Performance assessment: fast model at baseline
- Blocked/paused = degraded regardless of model
- High quality_risk = degraded regardless of model
- Operating assessment integrates baseline + runtime
- CapabilityBaseline serialization
"""

import pytest
from whispers.capability_baseline import (
    CapabilityBaseline,
    assess_performance,
    get_operating_assessment,
)


class TestAssessPerformance:
    def test_titan_at_baseline(self):
        baseline = CapabilityBaseline(model_class="titan")
        assert assess_performance(baseline, capacity=0.8, context_load=0.2) == "at_baseline"

    def test_titan_below_baseline_high_load(self):
        baseline = CapabilityBaseline(model_class="titan")
        assert assess_performance(baseline, context_load=0.85) == "below_baseline"

    def test_titan_below_baseline_medium_risk(self):
        baseline = CapabilityBaseline(model_class="titan")
        assert assess_performance(baseline, quality_risk="medium") == "below_baseline"

    def test_titan_degraded_high_risk(self):
        baseline = CapabilityBaseline(model_class="titan")
        assert assess_performance(baseline, quality_risk="high") == "degraded"

    def test_fast_at_baseline(self):
        baseline = CapabilityBaseline(model_class="fast")
        assert assess_performance(baseline, context_load=0.5) == "at_baseline"

    def test_fast_below_baseline_extreme_load(self):
        baseline = CapabilityBaseline(model_class="fast")
        assert assess_performance(baseline, context_load=0.95) == "below_baseline"

    def test_blocked_is_degraded(self):
        baseline = CapabilityBaseline(model_class="titan")
        assert assess_performance(baseline, readiness="blocked") == "degraded"

    def test_paused_is_degraded(self):
        baseline = CapabilityBaseline(model_class="fast")
        assert assess_performance(baseline, readiness="paused_by_operator") == "degraded"

    def test_unknown_model_at_baseline(self):
        baseline = CapabilityBaseline(model_class="unknown")
        assert assess_performance(baseline, context_load=0.3) == "at_baseline"


class TestCapabilityBaseline:
    def test_to_dict_drops_empty(self):
        b = CapabilityBaseline(model_class="titan", context_window=200000)
        d = b.to_dict()
        assert "strengths" not in d
        assert "limitations" not in d
        assert d["model_class"] == "titan"

    def test_to_dict_includes_strengths(self):
        b = CapabilityBaseline(
            model_class="titan",
            strengths=["architecture", "deep reasoning"],
        )
        d = b.to_dict()
        assert d["strengths"] == ["architecture", "deep reasoning"]


class TestGetOperatingAssessment:
    @pytest.fixture
    def setup(self, tmp_path):
        from whispers.storage.db import WhispersDB
        db_path = str(tmp_path / "test_capbl.db")
        db = WhispersDB(db_path=db_path)
        with db.get_connection() as conn:
            conn.execute(
                """INSERT INTO agent_cards (agent_id, callsign, agent_type, trust_tier, model_id, capabilities, registered_at)
                   VALUES (?, ?, ?, ?, ?, ?, datetime('now'))""",
                ("claude", "claude", "llm", 2, "claude-opus-4-6",
                 '{"strengths": ["architecture", "code review"], "max_concurrent_tasks": 3}'),
            )
            conn.execute(
                "INSERT INTO agent_sessions (session_id, agent_name, session_kind, lease_expires_at) VALUES (?, ?, ?, datetime('now', '+1 hour'))",
                ("sess-claude", "claude", "local_client"),
            )
            conn.execute(
                "INSERT INTO agent_runtime_state (session_id, agent_name, readiness, context_load) VALUES (?, ?, ?, ?)",
                ("sess-claude", "claude", "ready", 0.3),
            )
            conn.commit()
        return db

    def test_assessment_includes_baseline_and_runtime(self, setup):
        db = setup
        assessment = get_operating_assessment(db, "claude")
        assert assessment.agent == "claude"
        assert assessment.baseline.model_class == "titan"
        assert assessment.baseline.strengths == ["architecture", "code review"]
        assert assessment.performance == "at_baseline"
        assert assessment.current_capacity > 0

    def test_assessment_serializes(self, setup):
        db = setup
        assessment = get_operating_assessment(db, "claude")
        d = assessment.to_dict()
        assert d["model_class"] == "titan"
        assert d["performance"] == "at_baseline"
        assert d["strengths"] == ["architecture", "code review"]

    def test_unknown_agent_returns_defaults(self, setup):
        db = setup
        assessment = get_operating_assessment(db, "nobody")
        assert assessment.baseline.model_class == "unknown"
        assert assessment.performance in ("at_baseline", "below_baseline", "degraded")
