import pytest
from fastapi.testclient import TestClient
from datetime import datetime, timedelta, timezone

from whispers.server import app
from whispers.presence_policy import apply_presence_policy_to_record

@pytest.fixture
def client(temp_db, monkeypatch):
    """Provide a TestClient with a fresh temporary DB."""
    monkeypatch.setenv("WHISPERS_DB_PATH", temp_db)
    monkeypatch.setenv("WHISPERS_REMOTE_ADMISSION_MODE", "open")
    # Reload server to pick up new DB environment
    import importlib
    import whispers.server as server_module
    import whispers.storage as storage_module
    importlib.reload(storage_module)
    importlib.reload(server_module)
    return TestClient(server_module.app)


def test_session_override_vs_profile(client):
    """
    Test that scope='session' correctly overrides the persistent profile policy
    for roster visibility, and the override vanishes when we drop the session.
    """
    # 1. Connect agent1 to get an active session + token
    connect_resp = client.post("/connect", json={"agent_name": "agent1", "client": {}, "requested_scopes": ["presence:write", "presence:read"]})
    assert connect_resp.status_code == 200
    token1 = connect_resp.json()["token"]
    
    # Connect agent2 to observe agent1
    connect2_resp = client.post("/connect", json={"agent_name": "agent2", "client": {}, "requested_scopes": ["presence:read"]})
    token2 = connect2_resp.json()["token"]

    # 2. Set persistent profile default (visible) for agent1
    resp = client.post(
        "/presence-policy",
        json={"scope": "profile", "visibility_posture": "visible"},
        headers={"Authorization": f"Bearer {token1}"}
    )
    assert resp.status_code == 200
    assert resp.json()["visibility_posture"] == "visible"
    
    # Agent2 sees Agent1 in the roster
    status_resp = client.get("/agents", headers={"Authorization": f"Bearer {token2}"})
    roster = status_resp.json()["agents"]
    a1_in_roster = next((a for a in roster if a["callsign"] == "agent1"), None)
    assert a1_in_roster is not None
    assert a1_in_roster["presence_status"] == "online"
    
    # 3. Apply session override (hidden) for Agent1
    override_resp = client.post(
        "/presence-policy",
        json={"scope": "session", "visibility_posture": "hidden"},
        headers={"Authorization": f"Bearer {token1}"}
    )
    assert override_resp.status_code == 200
    assert override_resp.json()["visibility_posture"] == "hidden"
    
    # Agent2 NO LONGER sees Agent1 in the roster
    status_resp_hidden = client.get("/agents", headers={"Authorization": f"Bearer {token2}"})
    roster_hidden = status_resp_hidden.json()["agents"]
    a1_in_roster_hidden = next((a for a in roster_hidden if a["callsign"] == "agent1"), None)
    assert a1_in_roster_hidden is None
    
    # 4. Agent1 disconnects cleanly (dropping their session)
    client.post("/disconnect", headers={"Authorization": f"Bearer {token1}"})
    
    # 5. Agent1 reconnects (new session). The override should be GONE (reverted to "visible").
    connect3_resp = client.post("/connect", json={"agent_name": "agent1", "client": {}})
    token3 = connect3_resp.json()["token"]
    
    # Agent2 checks the roster again; Agent1 should be visible!
    status_resp_visible = client.get("/agents", headers={"Authorization": f"Bearer {token2}"})
    roster_visible = status_resp_visible.json()["agents"]
    a1_in_roster_visible = next((a for a in roster_visible if a["callsign"] == "agent1"), None)
    assert a1_in_roster_visible is not None


def test_idle_policy_evaluation(client):
    """
    Test that idle_policy timeouts correctly coerce an agent's visibility effect
    upon roster read.
    """
    import time
    
    # 1. Connect agent1 and agent2
    connect_resp = client.post("/connect", json={"agent_name": "agent-idle", "client": {}, "requested_scopes": ["presence:write", "presence:read"]})
    assert connect_resp.status_code == 200, connect_resp.text
    token_idle = connect_resp.json()["token"]
    
    connect_resp2 = client.post("/connect", json={"agent_name": "agent-viewer", "client": {}, "requested_scopes": ["presence:read"]})
    assert connect_resp2.status_code == 200, connect_resp2.text
    token_viewer = connect_resp2.json()["token"]
    
    # 2. Set an aggressive idle policy on agent_idle (1 second timeout -> hide)
    client.post(
        "/presence-policy",
        json={
            "scope": "profile",
            "visibility_posture": "visible",
            "idle_policy": {"mode": "hide_after_timeout", "timeout_seconds": 1}
        },
        headers={"Authorization": f"Bearer {token_idle}"}
    )
    
    # immediately check: should be visible
    roster_immediate = client.get("/agents", headers={"Authorization": f"Bearer {token_viewer}"}).json()["agents"]
    assert any(a["callsign"] == "agent-idle" for a in roster_immediate)
    
    # Wait for timeout to expire
    time.sleep(1.2)
    
    # Check again: should be hidden dynamically (without any explicit status update)
    roster_delayed = client.get("/agents", headers={"Authorization": f"Bearer {token_viewer}"}).json()["agents"]
    assert not any(a["callsign"] == "agent-idle" for a in roster_delayed)


def test_idle_policy_uses_latest_heartbeat_when_last_active_is_stale():
    now = datetime.now(timezone.utc)
    record = {
        "callsign": "agent-idle",
        "status": "online",
        "last_active": (now - timedelta(minutes=10)).isoformat(),
        "heartbeat_at": (now - timedelta(seconds=10)).isoformat(),
    }
    policy = {
        "visibility_posture": "visible",
        "state_detail_visibility": "full",
        "idle_policy": {"mode": "hide_after_timeout", "timeout_seconds": 60},
    }

    visible = apply_presence_policy_to_record(
        record,
        policy,
        viewer_agent="agent-viewer",
        target_agent="agent-idle",
    )

    assert visible is not None
    assert visible["status"] == "online"


def test_idle_policy_uses_runtime_timestamp_when_other_activity_is_stale():
    now = datetime.now(timezone.utc)
    stale = (now - timedelta(minutes=10)).isoformat()
    record = {
        "callsign": "agent-idle",
        "status": "online",
        "last_active": stale,
        "heartbeat_at": stale,
        "runtime_updated_at": (now - timedelta(seconds=10)).isoformat(),
    }
    policy = {
        "visibility_posture": "visible",
        "state_detail_visibility": "full",
        "idle_policy": {"mode": "appear_offline_after_timeout", "timeout_seconds": 60},
    }

    visible = apply_presence_policy_to_record(
        record,
        policy,
        viewer_agent="agent-viewer",
        target_agent="agent-idle",
    )

    assert visible is not None
    assert visible["status"] == "online"


def test_trust_tier_bypass(client, temp_db):
    """
    Test that Operator (Tier 5) and Team (Tier 3) bypass visibility routing when appropriate.
    """
    import sqlite3
    
    # 1. Connect agent (target) and operator (viewer)
    connect_resp = client.post("/connect", json={"agent_name": "agent-hidden", "client": {}, "requested_scopes": ["presence:write", "presence:read"]})
    token_hidden = connect_resp.json()["token"]
    
    connect_resp2 = client.post("/connect", json={"agent_name": "agent-op", "client": {}, "requested_scopes": ["presence:read"]})
    token_op = connect_resp2.json()["token"]
    
    # 2. Upgrade agent-op to Tier 5 (Operator)
    conn = sqlite3.connect(temp_db)
    conn.execute("UPDATE agent_cards SET trust_tier = 5 WHERE callsign = 'agent-op'")
    conn.commit()
    conn.close()
    
    # 3. Target sets an explicit 'hidden' posture
    client.post(
        "/presence-policy",
        json={"scope": "session", "visibility_posture": "hidden"},
        headers={"Authorization": f"Bearer {token_hidden}"}
    )
    
    # 4. Operator queries roster. Because they are Tier 5, 'hidden' is bypassed and they should see the agent.
    roster_op = client.get("/agents", headers={"Authorization": f"Bearer {token_op}"}).json()["agents"]
    assert any(a["callsign"] == "agent-hidden" for a in roster_op)
