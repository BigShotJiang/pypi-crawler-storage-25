from whispers.context_cost import (
    ContextCostRecipient,
    classify_message_size_tier,
    estimate_context_cost,
    estimate_message_tokens,
    infer_context_window_tokens,
    summarize_context_budget,
)


def test_model_family_inference_uses_conservative_defaults():
    assert infer_context_window_tokens(None) == 128_000
    assert infer_context_window_tokens("claude-sonnet") == 200_000
    assert infer_context_window_tokens("gpt-5") == 128_000
    assert infer_context_window_tokens("gemini-2.5-pro") == 1_000_000


def test_message_tokens_include_payload_structure():
    plain = estimate_message_tokens(subject="hello", body="small body")
    with_payload = estimate_message_tokens(
        subject="hello",
        body="small body",
        payload={"kind": "report", "items": ["a", "b", "c"]},
    )
    assert with_payload > plain


def test_classifies_small_message_as_signal():
    assert classify_message_size_tier(120) == "signal"


def test_recommends_full_for_small_message_on_low_load():
    estimate = estimate_context_cost(
        ContextCostRecipient("codex", model_id="gpt-5", context_load=0.2),
        subject="Need quick input",
        body="Can you review this in the next few minutes?",
    )
    assert estimate.recommendation == "full"
    assert estimate.projected_load < 0.8


def test_recommends_summarize_when_message_consumes_large_share_of_budget():
    body = "detail " * 10_000
    estimate = estimate_context_cost(
        ContextCostRecipient("claude-code", model_id="claude-sonnet", context_load=0.55),
        subject="Large design packet",
        body=body,
    )
    assert estimate.recommendation == "summarize"
    assert "large share of remaining context" in " ".join(estimate.reasons)


def test_recommends_headline_only_for_near_overloaded_recipient():
    estimate = estimate_context_cost(
        ContextCostRecipient("gemini", model_id="gemini-2.5-pro", context_load=0.9),
        subject="Need awareness",
        body="important " * 200,
    )
    assert estimate.recommendation == "headline_only"


def test_recommends_defer_when_message_exceeds_remaining_budget():
    estimate = estimate_context_cost(
        ContextCostRecipient(
            "worker",
            model_id="gpt-5",
            context_load=0.95,
            context_window_tokens=4_000,
        ),
        subject="Blocked",
        body="x " * 500,
    )
    assert estimate.recommendation == "defer"
    assert estimate.remaining_tokens_estimate < estimate.estimated_tokens


def test_explicit_context_window_override_beats_model_family_default():
    estimate = estimate_context_cost(
        ContextCostRecipient(
            "custom",
            model_id="claude-sonnet",
            context_load=0.5,
            context_window_tokens=16_000,
        ),
        body="payload " * 1_000,
    )
    assert estimate.context_window_tokens == 16_000


def test_budget_summary_prefers_summaries_when_load_is_elevated():
    summary = summarize_context_budget(
        ContextCostRecipient("claude-code", model_id="claude-sonnet", context_load=0.72)
    )
    assert summary.default_delivery_depth == "summarize"
    assert summary.remaining_tokens_estimate == 56_000


def test_budget_summary_prefers_headlines_when_near_saturated():
    summary = summarize_context_budget(
        ContextCostRecipient("gemini", model_id="gemini-2.5-pro", context_load=0.9)
    )
    assert summary.default_delivery_depth == "headline_only"
