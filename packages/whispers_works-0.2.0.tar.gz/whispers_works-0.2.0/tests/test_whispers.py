import json
import asyncio
import os
import sqlite3
import shutil
import uuid
from datetime import datetime, timedelta, timezone
from pathlib import Path
import pytest
from whispers.client import WhispersClient, MockWhispersClient, PermissionDeniedError, WhispersConflictError, WhispersException
from whispers.identity import generate_callsign, REMOTE_CALLSIGN_RE
import whispers.mcp_server as mcp_module
from whispers.envelope import Priority, MsgType
from whispers.modes import Mode
from whispers.storage.db import WhispersDB

@pytest.fixture
def temp_db():
    root = Path(__file__).resolve().parents[1] / ".tmp"
    root.mkdir(parents=True, exist_ok=True)
    case_dir = root / f"whispers-test-{uuid.uuid4().hex}"
    case_dir.mkdir(parents=True, exist_ok=False)
    db_path = str(case_dir / "test_whispers.db")
    yield db_path
    shutil.rmtree(case_dir, ignore_errors=True)


def _decode_payload(value):
    if isinstance(value, str):
        return json.loads(value)
    return value


def _find_workspace_signal(messages, workspace_id, *, sequence=None, delta_kind=None):
    for message in messages:
        payload = _decode_payload(message.get("payload"))
        if not isinstance(payload, dict):
            continue
        if payload.get("schema") != "workspace_delta.v1":
            continue
        inner = payload.get("payload")
        if not isinstance(inner, dict):
            continue
        if inner.get("workspace_id") != workspace_id:
            continue
        if sequence is not None and inner.get("sequence") != sequence:
            continue
        if delta_kind is not None and inner.get("delta_kind") != delta_kind:
            continue
        return message, payload
    raise AssertionError(f"No workspace_delta.v1 signal found for {workspace_id}.")

def test_mock_client():
    client = MockWhispersClient("agent_a")
    msg_resp = client.send("agent_b", "Hello World", priority="flash", trace_id="trace1")
    assert len(client.sent_messages) == 1
    assert client.sent_messages[0].id == msg_resp["id"]
    assert client.sent_messages[0].priority == Priority.FLASH
    assert client.sent_messages[0].trace_id == "trace1"

def test_real_client_init_and_register(temp_db):
    client = WhispersClient("agent_a", db_path=temp_db)
    
    # Registration is automatic on init
    agent = client.registry.get_agent_by_callsign("agent_a")
    assert agent is not None
    assert agent["callsign"] == "agent_a"
    assert agent["can_send_system"] == 0


def test_send_budget_window_ignores_old_same_day_messages(temp_db):
    sender = WhispersClient("codex", db_path=temp_db)
    receiver = WhispersClient("claude-code", db_path=temp_db)

    old_created_at = (datetime.now(timezone.utc) - timedelta(minutes=5)).isoformat()
    with sender.db.get_connection() as conn:
        conn.execute(
            """
            INSERT INTO messages (
                uuid, from_agent, to_agent, context_id, msg_type, content_type,
                subject, body, payload, priority, reply_to, trace_id,
                ttl_seconds, idempotency_key, metadata, created_at, delivery_status
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                str(uuid.uuid4()),
                "codex",
                "claude-code",
                None,
                "direct",
                "text/plain",
                "Earlier same-day analysis",
                "x" * 49_995,
                None,
                "priority",
                None,
                None,
                None,
                None,
                None,
                old_created_at,
                "queued",
            ),
        )
        conn.commit()

    result = sender.send("claude-code", "0123456789", priority="priority")

    assert result["status"] == "delivered"
    with sender.db.get_connection() as conn:
        stored = conn.execute(
            "SELECT COUNT(*) AS cnt FROM messages WHERE from_agent = ? AND subject = ?",
            ("codex", "0123456789"),
        ).fetchone()
    assert stored["cnt"] == 1


def test_local_identity_key_binding_surfaces_handle_state(temp_db):
    client = WhispersClient("agent_a", db_path=temp_db)

    initial = client.identity_key()
    assert initial["public_key_bound"] is False

    bound = client.bind_identity_key("ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIAgentA")
    handle = client.handle_status("agent_a")

    assert bound["public_key_bound"] is True
    assert bound["binding_outcome"] == "bound"
    assert handle["public_key_bound"] is True
    assert handle["public_key_fingerprint"] == bound["public_key_fingerprint"]

def test_rbac_system_priority(temp_db):
    client = WhispersClient("agent_a", db_path=temp_db)

    # Agent without system permission throws an exception
    with pytest.raises(PermissionDeniedError):
        client.send("orchestrator", "System alert", priority="system")

    # Manually grant the agent system priority
    client.registry.register("agent_a", can_send_system=True)

    # Sending system priority should now succeed
    msg_resp = client.send("orchestrator", "System alert", priority="system")
    assert msg_resp is not None
    assert "id" in msg_resp


def test_status_empty_system(temp_db):
    """Status on a fresh DB returns healthy with zero counts."""
    client = WhispersClient("agent_a", db_path=temp_db)
    s = client.status()

    assert s["healthy"] is True
    assert s["my_mode"] == "OPEN"
    assert s["agents_online_count"] == 1
    assert s["pending_messages"] == 0
    assert s["pending_by_priority"] == {}
    assert s["agents_registered"] == 1  # auto-registered on init
    assert "deployment_mode" in s


def test_status_includes_canonical_startup_and_connection_story(temp_db):
    client = WhispersClient("agent_a", db_path=temp_db)

    s = client.status()

    assert s["startup"]["resource_uri"] == "whispers://status"
    assert s["startup"]["pending_messages"] == s["pending_messages"]
    assert "Unread messages are inbox state only." in s["startup"]["detail_block"]
    assert s["connection_story"]["agent_name"] == "agent_a"
    assert s["connection_story"]["pending_messages"] == s["pending_messages"]


def test_status_uses_runtime_deployment_hint(temp_db, monkeypatch):
    monkeypatch.setenv("WHISPERS_DEPLOYMENT_MODE", "standalone")
    client = WhispersClient("agent_a", db_path=temp_db)

    s = client.status()

    assert s["deployment_mode"] == "standalone"
    assert s["deployment_source"] == "runtime_hint"


def test_status_falls_back_to_manifest_transport(temp_db, monkeypatch):
    case_dir = Path(temp_db).parent
    manifest_path = case_dir / ".whispers" / "install-state.json"
    manifest_path.parent.mkdir(parents=True, exist_ok=True)
    manifest_path.write_text(
        json.dumps(
            {
                "version": 1,
                "updated_at": "2026-03-20T00:00:00Z",
                "init": None,
                "targets": {
                    "cursor": {
                        "default_agent": "cursor",
                        "entry_intent": {
                            "transport": "http",
                            "identity": "cursor",
                        },
                    }
                },
            }
        ),
        encoding="utf-8",
    )
    monkeypatch.setenv("WHISPERS_INSTALL_STATE_PATH", str(manifest_path))
    monkeypatch.delenv("WHISPERS_DEPLOYMENT_MODE", raising=False)

    client = WhispersClient("cursor", db_path=temp_db)

    s = client.status()

    assert s["deployment_mode"] == "standalone"
    assert s["deployment_source"] == "manifest_intent"


def test_status_with_pending_messages(temp_db):
    """Status reflects pending messages and priority breakdown."""
    sender = WhispersClient("agent_a", db_path=temp_db)
    receiver = WhispersClient("agent_b", db_path=temp_db)

    sender.send("agent_b", "Hello", priority="routine")
    sender.send("agent_b", "Urgent", priority="flash")

    s = receiver.status()
    assert s["pending_messages"] == 2
    assert s["pending_by_priority"]["routine"] == 1
    assert s["pending_by_priority"]["flash"] == 1


def test_status_surfaces_coordination_state(temp_db):
    sender = WhispersClient("claude-code", db_path=temp_db)
    receiver = WhispersClient("codex", db_path=temp_db)

    sender.request_review(
        "codex",
        artifact="dissent implementation plan",
        question="Approve or redirect the plan.",
        blocking=True,
    )

    receiver_status = receiver.status()
    sender_status = sender.status()

    assert receiver_status["pending_review_requests"] == 1
    assert receiver_status["blocking_review_requests"] == 1
    assert receiver_status["coordination_state"]["highlights"][0]["kind"] == "review_request"
    assert sender_status["blocked_waiting_for_review"] == 1


def test_status_and_registry_surface_attention_state_and_progress(temp_db):
    codex = WhispersClient("codex", db_path=temp_db)
    operator = WhispersClient("whispers-console", db_path=temp_db)

    codex.set_readiness(
        "busy",
        current_task="Wiring operator pause visibility",
        attention_state="working",
        attention_detail="Quiet backend/runtime integration",
    )
    codex.update_cognitive_heartbeat(
        {
            "progress_summary": "Threaded attention state through status and registry.",
            "last_progress_at": "2026-03-28T16:00:00Z",
            "attention_state": "working",
            "attention_detail": "Quiet backend/runtime integration",
        }
    )

    status = operator.status()
    codex_peer = next(agent for agent in status["peers_online"] if agent["agent_name"] == "codex")
    assert codex_peer["attention_state"] == "working"
    assert codex_peer["attention_detail"] == "Quiet backend/runtime integration"
    assert codex_peer["progress_summary"] == "Threaded attention state through status and registry."
    assert codex_peer["last_progress_at"] == "2026-03-28T16:00:00Z"

    agents = operator.list_agents()
    codex_row = next(agent for agent in agents if agent["callsign"] == "codex")
    assert codex_row["attention_state"] == "working"
    assert codex_row["attention_detail"] == "Quiet backend/runtime integration"
    assert codex_row["progress_summary"] == "Threaded attention state through status and registry."
    assert codex_row["last_progress_at"] == "2026-03-28T16:00:00Z"


def test_status_connection_story_surfaces_peer_needing_assignment(temp_db):
    codex = WhispersClient("codex", db_path=temp_db)
    claude = WhispersClient("claude-code", db_path=temp_db)

    claude.set_readiness(
        "ready",
        attention_state="needs_assignment",
        attention_detail="Backup lane complete and ready for the next packet.",
    )

    status = codex.status()

    assert status["peer_assignment_requests"] == 1
    assert status["peer_assignment_alerts"][0]["agent_name"] == "claude-code"
    assert status["peer_assignment_alerts"][0]["operator_nudge_required"] is True
    assert status["peer_nudge_requests"] == 1
    assert status["peer_nudge_alerts"][0]["agent_name"] == "claude-code"
    assert "Route next work and nudge" in status["connection_story"]["recommended_action"]
    assert "claude-code" in status["connection_story"]["recommended_action"]
    assert "operator nudge required" in status["startup"]["detail_block"]


def test_status_suppresses_stale_peer_assignment_after_newer_captain_reply(temp_db):
    codex = WhispersClient("codex", db_path=temp_db)
    antigravity = WhispersClient("antigravity", db_path=temp_db)

    antigravity.set_readiness(
        "ready",
        attention_state="needs_assignment",
        attention_detail="Waiting on next lane assignment from Codex.",
    )
    request = antigravity.send(
        "codex",
        "Next tactical assignment?",
        body="Ready for the next backend tranche.",
        priority="priority",
        msg_type="request",
    )

    before = codex.status()
    assert before["peer_assignment_requests"] == 1
    assert before["peer_assignment_alerts"][0]["agent_name"] == "antigravity"

    codex.send(
        "antigravity",
        "Next lane",
        body="Own backend baton-lifecycle closure and focused tests.",
        priority="priority",
        msg_type="request",
        reply_to=request["id"],
    )

    after = codex.status()
    assert after["peer_assignment_requests"] == 0
    assert after["peer_assignment_alerts"] == []
    assert "antigravity needs assignment" not in after["startup"]["detail_block"]
    assert "nudge antigravity" not in after["connection_story"]["recommended_action"]


def test_status_surfaces_captain_action_alert_and_suppresses_stale_needs_assignment(temp_db):
    codex = WhispersClient("codex", db_path=temp_db)
    claude = WhispersClient("claude-code", db_path=temp_db)

    claude.set_readiness(
        "ready",
        attention_state="needs_assignment",
        attention_detail="Completed all 3 items in backup pull order. Ready for next slice.",
    )
    claude.send(
        "codex",
        "Execution Packet: connection story pressure testing",
        body="Bounded plan ready for captain review.",
        priority="priority",
        msg_type="propose",
    )

    status = codex.status()

    assert status["captain_action_requests"] == 1
    assert status["captain_action_alerts"][0]["sender"] == "claude-code"
    assert status["captain_action_alerts"][0]["label"] == "proposal"
    assert status["peer_assignment_requests"] == 0
    assert status["peer_assignment_alerts"] == []
    assert "Captain alert: claude-code proposal pending" in status["startup"]["detail_block"]
    assert "Review claude-code proposal" in status["connection_story"]["recommended_action"]


def test_list_activity_surfaces_coordination_runtime_events(temp_db):
    claude = WhispersClient("claude-code", db_path=temp_db)
    antigravity = WhispersClient("antigravity", db_path=temp_db)
    WhispersClient("codex", db_path=temp_db)  # register recipient
    operator = WhispersClient("whispers-console", db_path=temp_db)

    claude.send_assignment(
        "codex",
        objective="Own the proof packet tranche.",
        deliverable="proof packet",
        requested_action="Draft the proof packet and pressure-test edge cases.",
        workspace_id="ws_runtime_visibility",
    )
    antigravity.request_review(
        "codex",
        artifact="dissent implementation plan",
        question="Approve or redirect the plan.",
        blocking=True,
    )

    all_events = operator.list_activity(limit=10)
    coordination_events = [event for event in all_events if event.get("type") == "coordination"]

    assert any(
        event.get("delta_kind") == "assignment"
        and event.get("coordination_status") == "pending"
        and event.get("sender") == "claude-code"
        and event.get("receiver") == "codex"
        for event in coordination_events
    )
    assert any(
        event.get("delta_kind") == "review_request"
        and event.get("coordination_status") == "waiting"
        and event.get("sender") == "antigravity"
        and event.get("receiver") == "codex"
        and event.get("blocking") is True
        for event in coordination_events
    )

    assignment_events = operator.list_activity(limit=10, kinds=["assignment"])
    assert assignment_events
    assert {event["delta_kind"] for event in assignment_events} == {"assignment"}


def test_list_activity_updates_coordination_status_after_pickup_and_ack(temp_db):
    claude = WhispersClient("claude-code", db_path=temp_db)
    antigravity = WhispersClient("antigravity", db_path=temp_db)
    codex = WhispersClient("codex", db_path=temp_db)
    operator = WhispersClient("whispers-console", db_path=temp_db)

    assignment = claude.send_assignment(
        "codex",
        objective="Own the proof packet tranche.",
        deliverable="proof packet",
        requested_action="Draft the proof packet and pressure-test edge cases.",
    )
    codex.check_inbox(limit=10, mark_seen=True)

    review = antigravity.request_review(
        "codex",
        artifact="dissent implementation plan",
        question="Approve or redirect the plan.",
        blocking=True,
    )
    codex.acknowledge_message(review["id"], "processed", detail="Review picked up.")

    assignment_events = operator.list_activity(limit=10, kinds=["assignment"])
    assignment_event = next(event for event in assignment_events if event.get("message_id") == assignment["id"])
    assert assignment_event["coordination_status"] == "seen"

    review_events = operator.list_activity(limit=10, kinds=["review_request"])
    review_event = next(event for event in review_events if event.get("message_id") == review["id"])
    assert review_event["coordination_status"] == "acknowledged"
    assert review_event["summary"] == "Review picked up."


def test_status_keeps_blocking_review_wait_open_after_ack_until_reply(temp_db):
    sender = WhispersClient("antigravity", db_path=temp_db)
    reviewer = WhispersClient("codex", db_path=temp_db)

    review = sender.request_review(
        "codex",
        artifact="listener wake policy",
        question="Approve or redirect the wake policy change.",
        blocking=True,
    )

    reviewer.acknowledge_message(review["id"], "processed", detail="Review picked up.")

    sender_status = sender.status()
    assert sender_status["blocked_waiting_for_review"] == 1
    highlight = next(
        item
        for item in sender_status["coordination_state"]["highlights"]
        if item["message_id"] == review["id"]
    )
    assert highlight["coordination_status"] == "acknowledged"


def test_list_activity_marks_review_request_answered_after_reply(temp_db):
    antigravity = WhispersClient("antigravity", db_path=temp_db)
    codex = WhispersClient("codex", db_path=temp_db)
    operator = WhispersClient("whispers-console", db_path=temp_db)

    review = antigravity.request_review(
        "codex",
        artifact="listener wake policy plan",
        question="Approve or redirect the wake policy change.",
        blocking=True,
    )

    codex.send(
        "antigravity",
        "Re: listener wake policy plan",
        body="Approved. Proceed with the narrower wake-policy cut.",
        reply_to=review["id"],
    )

    review_events = operator.list_activity(limit=10, kinds=["review_request"])
    review_event = next(event for event in review_events if event.get("message_id") == review["id"])
    assert review_event["coordination_status"] == "answered"
    assert review_event["has_reply"] is True

    sender_status = antigravity.status()
    assert sender_status["answered_waiting_to_close"] == 1


def test_list_activity_includes_blocking_review_age(temp_db):
    antigravity = WhispersClient("antigravity", db_path=temp_db)
    WhispersClient("codex", db_path=temp_db)  # register recipient
    operator = WhispersClient("whispers-console", db_path=temp_db)

    review = antigravity.request_review(
        "codex",
        artifact="wake policy",
        question="Approve or redirect the wake policy change.",
        blocking=True,
    )

    with antigravity.db.get_connection() as conn:
        conn.execute(
            "UPDATE messages SET created_at = datetime('now', '-12 minutes') WHERE uuid = ?",
            (review["id"],),
        )
        conn.commit()

    review_events = operator.list_activity(limit=10, kinds=["review_request"])
    review_event = next(event for event in review_events if event.get("message_id") == review["id"])
    assert review_event["coordination_status"] == "waiting"
    assert review_event["age_label"] == "12m"
    assert review_event["age_seconds"] >= 12 * 60


def test_status_reflects_mode_change(temp_db):
    """Status reflects mode changes after set_mode."""
    client = WhispersClient("agent_a", db_path=temp_db)
    client.set_mode("focused", allow_senders=["orchestrator"])

    s = client.status()
    assert s["my_mode"] == "FOCUSED"


def test_structured_handoff_is_listed_and_ack_filtered(temp_db):
    claude = WhispersClient("claude-code", db_path=temp_db)
    codex = WhispersClient("codex", db_path=temp_db)

    sent = claude.send_handoff(
        "codex",
        objective="Design and implement notification model",
        deliverable="NOTIFICATION-SCHEMA-PACKET.md",
        completed="Notification model designed. Three-level awareness with push-with-filter delivery.",
        remaining="Turn the design into a concrete schema packet and runtime implementation plan.",
        next_action="Write NOTIFICATION-SCHEMA-PACKET.md following the WS0 schema packet pattern.",
        assumptions=["Push-with-filter chosen over pure broadcast"],
        risks=["Notification schema may conflict with workspace delta delivery path"],
        artifacts=[".planning/research/notification-models.md"],
        workspace_id="ws_notification_design",
        human_summary="Notification model designed. Codex should turn it into the schema packet.",
        trace_id="coordination-pass-7",
    )

    sender_handoffs = claude.list_handoffs(limit=10)
    recipient_handoffs = codex.list_handoffs(limit=10, unacknowledged_only=True)

    assert sent["status"] == "delivered"
    assert sender_handoffs[0]["schema"] == "handoff_baton.v1"
    assert sender_handoffs[0]["next_action"] == "Write NOTIFICATION-SCHEMA-PACKET.md following the WS0 schema packet pattern."
    assert sender_handoffs[0]["workspace_id"] == "ws_notification_design"
    assert sender_handoffs[0]["summary_human"] == "Notification model designed. Codex should turn it into the schema packet."
    assert sender_handoffs[0]["delivery_status"] == "delivered"
    assert [handoff["uuid"] for handoff in recipient_handoffs] == [sent["id"]]

    codex.acknowledge_message(sent["id"], "processed", detail="Schema packet started")

    refreshed = claude.list_handoffs(limit=10)

    assert refreshed[0]["ack_state"] == "processed"
    assert refreshed[0]["ack_detail"] == "Schema packet started"
    assert claude.list_handoffs(limit=10, unacknowledged_only=True) == []


def test_projection_backed_legacy_handoff_is_listed_and_ack_filtered(temp_db):
    claude = WhispersClient("claude-code", db_path=temp_db)
    codex = WhispersClient("codex", db_path=temp_db)

    sent = claude.send(
        "codex",
        subject="Legacy handoff",
        body="Pick this up from the older handoff path.",
        priority="priority",
        msg_type="handoff",
    )

    sender_handoffs = claude.list_handoffs(limit=10)
    recipient_handoffs = codex.list_handoffs(limit=10, unacknowledged_only=True)

    assert sent["status"] == "delivered"
    assert sender_handoffs[0]["uuid"] == sent["id"]
    assert sender_handoffs[0]["schema"] == "handoff"
    assert sender_handoffs[0]["subject"] == "Legacy handoff"
    assert sender_handoffs[0]["baton_state"] == "offered"
    assert sender_handoffs[0]["message_id"] == sent["id"]
    assert [handoff["uuid"] for handoff in recipient_handoffs] == [sent["id"]]

    codex.baton_ack(sent["id"], "accepted", reason="Legacy handoff picked up")

    refreshed = claude.list_handoffs(limit=10)

    assert refreshed[0]["baton_state"] == "accepted"
    assert refreshed[0]["last_update_text"] == "Legacy handoff picked up"
    assert codex.list_handoffs(limit=10, unacknowledged_only=True) == []


def test_active_incoming_handoff_survives_recent_message_noise(temp_db):
    claude = WhispersClient("claude-code", db_path=temp_db)
    codex = WhispersClient("codex", db_path=temp_db)
    antigravity = WhispersClient("antigravity", db_path=temp_db)

    sent = claude.send(
        "codex",
        subject="Older active handoff",
        body="This should stay visible despite newer noise.",
        priority="priority",
        msg_type="handoff",
    )

    for idx in range(101):
        antigravity.send(
            "codex",
            subject=f"Noise {idx}",
            body="Ignore this ordinary traffic.",
            priority="routine",
            msg_type="inform",
        )

    handoffs = codex.list_handoffs(limit=10)
    pending = codex.list_handoffs(limit=10, unacknowledged_only=True)

    assert sent["status"] == "delivered"
    assert any(handoff["uuid"] == sent["id"] for handoff in handoffs)
    assert [handoff["uuid"] for handoff in pending] == [sent["id"]]


def test_structured_baton_client_surface_tracks_lifecycle(temp_db):
    claude = WhispersClient("claude-code", db_path=temp_db)
    codex = WhispersClient("codex", db_path=temp_db)

    sent = claude.send_handoff(
        "codex",
        objective="Design and implement notification model",
        deliverable="NOTIFICATION-SCHEMA-PACKET.md",
        completed="Notification model designed.",
        remaining="Turn the design into the concrete schema packet.",
        next_action="Write NOTIFICATION-SCHEMA-PACKET.md.",
        workspace_id="ws_notification_design",
        human_summary="Turn the notification design into the schema packet.",
    )

    owner_view = claude.list_batons(limit=10)
    assignee_view = codex.list_batons(limit=10, role="assignee")

    assert owner_view[0]["baton_ref"] == sent["id"]
    assert owner_view[0]["state"] == "offered"
    assert owner_view[0]["linked_workspace_id"] == "ws_notification_design"
    assert [row["baton_ref"] for row in assignee_view] == [sent["id"]]

    acked = codex.baton_ack(sent["id"], "accepted", reason="Schema packet started")
    assert acked["status"] == "delivered"
    after_ack = claude.list_batons(limit=10)[0]
    assert after_ack["state"] == "accepted"
    assert after_ack["last_update_text"] == "Schema packet started"

    updated = codex.baton_update(
        sent["id"],
        "in_progress",
        progress="Drafting packet",
        artifact_refs=["NOTIFICATION-SCHEMA-PACKET.md"],
    )
    assert updated["status"] == "delivered"
    after_update = claude.list_batons(limit=10)[0]
    assert after_update["state"] == "in_progress"
    assert after_update["artifact_refs"] == ["NOTIFICATION-SCHEMA-PACKET.md"]
    assert after_update["last_update_text"] == "Drafting packet"

    closed = codex.baton_close(
        sent["id"],
        "completed",
        summary="Packet shipped",
        artifact_refs=["NOTIFICATION-SCHEMA-PACKET.md"],
    )
    assert closed["status"] == "delivered"
    after_close = claude.list_batons(limit=10, workspace_id="ws_notification_design")[0]
    assert after_close["state"] == "completed"
    assert after_close["outcome"] == "completed"
    assert after_close["artifact_refs"] == ["NOTIFICATION-SCHEMA-PACKET.md"]
    assert after_close["last_update_text"] == "Packet shipped"


def test_status_huddle_tracks_live_baton_projection_state(temp_db):
    claude = WhispersClient("claude-code", db_path=temp_db)
    codex = WhispersClient("codex", db_path=temp_db)

    sent = claude.send_handoff(
        "codex",
        objective="Turn the notification design into a schema packet",
        deliverable="NOTIFICATION-SCHEMA-PACKET.md",
        completed="Notification design drafted.",
        remaining="Write the schema packet.",
        next_action="Draft the schema packet.",
        human_summary="Turn the notification design into the schema packet.",
    )

    codex_status = codex.status()
    codex_peer = next(peer for peer in codex_status["huddle_peers"] if peer["agent_name"] == "claude-code")
    claude_adjacency = claude.db.get_huddle_adjacency("claude-code", ["codex"])
    claude_peer = claude_adjacency["codex"]

    assert codex_peer["incoming_baton_count"] == 1
    assert codex_peer["incoming_baton_from_peer"] is True
    assert claude_peer["outgoing_baton_count"] == 1
    assert claude_peer["outgoing_baton_to_peer"] is True

    codex.baton_ack(sent["id"], "accepted", reason="Schema packet started")

    accepted_codex_status = codex.status()
    accepted_codex_peer = next(peer for peer in accepted_codex_status["huddle_peers"] if peer["agent_name"] == "claude-code")
    accepted_claude_peer = claude.db.get_huddle_adjacency("claude-code", ["codex"])["codex"]

    assert accepted_codex_peer["incoming_baton_count"] == 1
    assert accepted_claude_peer["outgoing_baton_count"] == 1

    codex.baton_close(sent["id"], "completed", summary="Packet shipped")

    closed_codex_status = codex.status()
    closed_claude_adjacency = claude.db.get_huddle_adjacency("claude-code", ["codex"])

    assert all(peer["agent_name"] != "claude-code" for peer in closed_codex_status["huddle_peers"])
    assert "codex" not in closed_claude_adjacency


def test_owner_close_clears_outgoing_baton_from_status_surfaces(temp_db):
    claude = WhispersClient("claude-code", db_path=temp_db)
    codex = WhispersClient("codex", db_path=temp_db)

    sent = claude.send_handoff(
        "codex",
        objective="Turn the notification design into a schema packet",
        deliverable="NOTIFICATION-SCHEMA-PACKET.md",
        completed="Notification design drafted.",
        remaining="Write the schema packet.",
        next_action="Draft the schema packet.",
        human_summary="Turn the notification design into the schema packet.",
    )

    codex.baton_ack(sent["id"], "accepted", reason="Schema packet started")

    sender_before = claude.status()
    assert sender_before["carrying_batons"] == 1
    assert any(detail["baton_ref"] == sent["id"] for detail in sender_before["baton_details"])
    before_pending = sender_before["pending_messages"]
    before_reply_requests = sender_before["active_reply_requests"]
    assert all(alert["counterpart"] != "claude-code" for alert in sender_before["active_reply_alerts"])

    claude.baton_close(sent["id"], "superseded", summary="Operator rerouted this work")

    sender_after = claude.status()
    recipient_after = codex.status()

    assert sender_after["carrying_batons"] == 0
    assert sender_after["pending_messages"] == before_pending
    assert sender_after["active_reply_requests"] == before_reply_requests
    assert all(alert["counterpart"] != "claude-code" for alert in sender_after["active_reply_alerts"])
    assert recipient_after["incoming_batons"] == 0
    assert all(detail["baton_ref"] != sent["id"] for detail in sender_after["baton_details"])
    assert all(detail["baton_ref"] != sent["id"] for detail in recipient_after["baton_details"])


def test_surface_now_unread_outranks_carried_baton_in_status(temp_db):
    claude = WhispersClient("claude-code", db_path=temp_db)
    codex = WhispersClient("codex", db_path=temp_db)

    sent = claude.send_handoff(
        "codex",
        objective="Keep the briefing surface aligned",
        deliverable="briefing surface sync",
        completed="Baseline baton opened.",
        remaining="Track the live surface and respond to fresh signals.",
        next_action="Keep the lane warm while new signals arrive.",
        human_summary="Hold the briefing surface lane.",
    )
    codex.baton_ack(sent["id"], "accepted", reason="Holding the lane open")
    claude.check_inbox(mark_seen=True)

    codex.send(
        "claude-code",
        subject="Fresh actionable follow-up",
        body="New signal that should surface before the older carried baton.",
        priority="routine",
        msg_type="request",
    )

    status = claude.status()

    assert status["pending_messages"] >= 1
    assert status["connection_story"]["attention_treatment"]["counts"]["surface_now"] >= 1
    assert status["connection_story"]["recommended_action"].startswith("Check inbox -- ")


def test_status_clears_acknowledged_legacy_handoff_from_active_baton_surfaces(temp_db):
    antigravity = WhispersClient("antigravity", db_path=temp_db)
    codex = WhispersClient("codex", db_path=temp_db)

    sent = antigravity.send(
        "codex",
        subject="Legacy handoff",
        body="Pick this up from the older handoff path.",
        priority="priority",
        msg_type="handoff",
    )

    recipient_before = codex.status()
    sender_before = antigravity.status()

    recipient_peer = next(peer for peer in recipient_before["huddle_peers"] if peer["agent_name"] == "antigravity")

    assert recipient_before["incoming_batons"] == 1
    assert sender_before["carrying_batons"] == 1
    assert recipient_peer["incoming_baton_count"] == 1
    assert any(detail["baton_ref"] == sent["id"] for detail in recipient_before["baton_details"])
    assert any(detail["baton_ref"] == sent["id"] for detail in sender_before["baton_details"])

    codex.acknowledge_message(sent["id"], "processed", detail="Reviewed and cleared")

    recipient_after = codex.status()
    sender_after = antigravity.status()

    assert recipient_after["incoming_batons"] == 0
    assert sender_after["carrying_batons"] == 0
    assert all(detail["baton_ref"] != sent["id"] for detail in recipient_after["baton_details"])
    assert all(detail["baton_ref"] != sent["id"] for detail in sender_after["baton_details"])
    assert all(peer["agent_name"] != "antigravity" for peer in recipient_after["huddle_peers"])


def test_workspace_client_surface_covers_lifecycle_and_visibility(temp_db):
    claude = WhispersClient("claude-code", db_path=temp_db)
    codex = WhispersClient("codex", db_path=temp_db)
    antigravity = WhispersClient("antigravity", db_path=temp_db)

    created = claude.create_workspace(
        purpose="Coordinate the notification runtime follow-up",
        name="Notification follow-up",
        join_policy="invite",
        linked_traces=["coordination-pass-8"],
        members=["codex"],
    )
    workspace_id = created["workspace_id"]

    # Creator (claude) is auto-joined at seq 1
    joined_observer = codex.join_workspace(workspace_id, membership_role="observer")

    delta_one = claude.send_workspace_delta(
        workspace_id,
        "note",
        "Surveyed notification fanout options.",
        artifacts=[".planning/research/notification-models.md"],
    )
    delta_two = claude.send_workspace_delta(
        workspace_id,
        "decision",
        "Push-with-filter remains the preferred delivery model.",
    )

    state = codex.workspace_state(workspace_id, since_sequence=2)
    active = claude.list_workspaces()

    assert created["invited_members"] == ["codex"]
    assert joined_observer["sequence"] == 2
    assert delta_one["sequence"] == 3
    assert delta_two["sequence"] == 4
    assert [delta["sequence"] for delta in state["deltas"]] == [3, 4]
    assert state["members"][1]["membership_role"] == "observer"
    assert active[0]["workspace_id"] == workspace_id
    assert active[0]["member_count"] == 2

    with pytest.raises(PermissionDeniedError, match="Invite-only workspace"):
        antigravity.join_workspace(workspace_id)

    with pytest.raises(PermissionDeniedError, match="Observers can read workspace state but cannot post deltas"):
        codex.send_workspace_delta(workspace_id, "note", "Observer write should fail.")

    left = codex.leave_workspace(workspace_id, reason="Research handoff complete")
    closed = claude.close_workspace(workspace_id, reason="Execution tranche complete")

    assert left["sequence"] == 5
    assert closed["sequence"] == 6
    assert closed["workspace"]["status"] == "closed"
    assert claude.list_workspaces(status="closed")[0]["workspace_id"] == workspace_id


def test_workspace_activity_feed_shows_projected_handoff(temp_db):
    claude = WhispersClient("claude-code", db_path=temp_db)
    codex = WhispersClient("codex", db_path=temp_db)
    antigravity = WhispersClient("antigravity", db_path=temp_db)
    operator = WhispersClient("whispers-console", db_path=temp_db)

    created = claude.create_workspace(
        purpose="Coordinate the notification runtime follow-up",
        name="Notification follow-up",
        join_policy="invite",
        members=["codex", "antigravity"],
    )
    workspace_id = created["workspace_id"]

    # Creator (claude) auto-joined at seq 1
    codex.join_workspace(workspace_id)       # seq 2
    antigravity.join_workspace(workspace_id) # seq 3
    antigravity.send_workspace_delta(        # seq 4
        workspace_id,
        "note",
        "Surveyed notification fanout options.",
        artifacts=[".planning/research/notification-models.md"],
    )
    claude.send_handoff(
        "codex",
        objective="Design and implement notification model",
        deliverable="NOTIFICATION-SCHEMA-PACKET.md",
        completed="Notification model designed. Three-level awareness with push-with-filter delivery.",
        remaining="Turn the design into a concrete schema packet and runtime implementation plan.",
        next_action="Write NOTIFICATION-SCHEMA-PACKET.md following the WS0 schema packet pattern.",
        workspace_id=workspace_id,
        human_summary="Handed off notification model design to Codex for execution.",
        trace_id="coordination-pass-9",
    )

    handoff = operator.list_handoffs(limit=10, workspace_id=workspace_id)[0]
    catchup = antigravity.workspace_state(workspace_id, since_sequence=4)
    events = operator.list_activity(limit=10, workspace_id=workspace_id)

    assert catchup["deltas"][0]["delta_kind"] == "handoff_in"
    assert catchup["deltas"][0]["related_message_id"] == handoff["message_id"]
    assert events[0]["type"] == "handoff"
    assert events[0]["summary"] == "Handed off notification model design to Codex for execution."
    assert events[0]["related_message_id"] == handoff["message_id"]
    assert events[0]["workspace_id"] == workspace_id
    assert any(event["delta_kind"] == "lifecycle" for event in events)


def test_workspace_events_fan_out_as_structured_inbox_signals(temp_db):
    claude = WhispersClient("claude-code", db_path=temp_db)
    codex = WhispersClient("codex", db_path=temp_db)
    antigravity = WhispersClient("antigravity", db_path=temp_db)

    created = claude.create_workspace(
        purpose="Coordinate collaboration runtime proofing",
        name="Collaboration proof",
        join_policy="invite",
        members=["codex", "antigravity"],
    )
    workspace_id = created["workspace_id"]

    # Creator (claude) auto-joined
    codex.join_workspace(workspace_id)
    antigravity.join_workspace(workspace_id)

    # Drain the join lifecycle fanout so the delta assertion is isolated.
    claude.check_inbox(limit=20, mark_seen=True)
    codex.check_inbox(limit=20, mark_seen=True)
    antigravity.check_inbox(limit=20, mark_seen=True)

    posted = antigravity.send_workspace_delta(
        workspace_id,
        "note",
        "Research complete: push-with-filter is the right delivery model.",
        artifacts=[".planning/research/notification-models.md"],
    )

    claude_message, claude_signal = _find_workspace_signal(
        claude.check_inbox(limit=10, mark_seen=False),
        workspace_id,
        sequence=posted["sequence"],
        delta_kind="note",
    )
    codex_message, codex_signal = _find_workspace_signal(
        codex.check_inbox(limit=10, mark_seen=False),
        workspace_id,
        sequence=posted["sequence"],
        delta_kind="note",
    )

    assert antigravity.check_inbox(limit=10, mark_seen=False) == []
    assert claude_message["from_agent"] == "antigravity"
    assert claude_message["metadata"]["whispers:schema"] == "workspace_delta.v1"
    assert claude_message["metadata"]["whispers:workspace_id"] == workspace_id
    assert claude_signal["payload"]["workspace_id"] == workspace_id
    assert claude_signal["payload"]["sequence"] == posted["sequence"]
    assert claude_signal["payload"]["actor"] == "antigravity"
    assert claude_signal["payload"]["artifacts"] == [".planning/research/notification-models.md"]
    assert codex_signal["payload"]["workspace_id"] == workspace_id
    assert codex_signal["payload"]["sequence"] == posted["sequence"]

    claude.check_inbox(limit=20, mark_seen=True)
    codex.check_inbox(limit=20, mark_seen=True)
    antigravity.check_inbox(limit=20, mark_seen=True)

    closed = claude.close_workspace(workspace_id, reason="Proof run complete")
    lifecycle_message, lifecycle_signal = _find_workspace_signal(
        codex.check_inbox(limit=10, mark_seen=False),
        workspace_id,
        sequence=closed["sequence"],
        delta_kind="lifecycle",
    )
    self_close_message, self_close_signal = _find_workspace_signal(
        claude.check_inbox(limit=10, mark_seen=False),
        workspace_id,
        sequence=closed["sequence"],
        delta_kind="lifecycle",
    )

    assert lifecycle_message["metadata"]["whispers:delta_kind"] == "lifecycle"
    assert "closed" in (lifecycle_signal["payload"]["text"] or "")
    assert self_close_signal["payload"]["sequence"] == closed["sequence"]
    assert self_close_message["from_agent"] == "claude-code"


def test_mcp_workspace_tools_surface_operator_view(temp_db, monkeypatch):
    monkeypatch.setenv("WHISPERS_DB_PATH", temp_db)
    mcp_module._clients.clear()
    claude_client = WhispersClient("claude-code", db_path=temp_db)
    codex_client = WhispersClient("codex", db_path=temp_db)

    token = mcp_module.current_agent_name.set("claude-code")
    try:
        created = asyncio.run(
            mcp_module.handle_tool(
                "workspace_create",
                {
                    "purpose": "Coordinate schema packet implementation",
                    "name": "Schema packet",
                    "join_policy": "invite",
                    "members": ["codex"],
                },
            )
        )[0].text
        workspace_id = created.split(": ", 1)[1].split(" |", 1)[0]

        joined = asyncio.run(mcp_module.handle_tool("workspace_join", {"workspace_id": workspace_id}))[0].text
        codex_client.join_workspace(workspace_id)
        posted = asyncio.run(
            mcp_module.handle_tool(
                "workspace_delta",
                {
                    "workspace_id": workspace_id,
                    "delta_kind": "note",
                    "text": "Drafted the schema packet outline.",
                },
            )
        )[0].text
        claude_client.send_handoff(
            "codex",
            objective="Design and implement notification model",
            deliverable="NOTIFICATION-SCHEMA-PACKET.md",
            completed="Notification model designed. Three-level awareness with push-with-filter delivery.",
            remaining="Turn the design into a concrete schema packet and runtime implementation plan.",
            next_action="Write NOTIFICATION-SCHEMA-PACKET.md following the WS0 schema packet pattern.",
            workspace_id=workspace_id,
            human_summary="Handed off notification model design to Codex for execution.",
            trace_id="coordination-pass-10",
        )
        state = asyncio.run(mcp_module.handle_tool("workspace_state", {"workspace_id": workspace_id}))[0].text
        workspaces = asyncio.run(mcp_module.handle_tool("workspaces", {}))[0].text
        activity = asyncio.run(mcp_module.handle_tool("activity", {"workspace_id": workspace_id}))[0].text
    finally:
        mcp_module.current_agent_name.reset(token)
        mcp_module._clients.clear()

    assert "Workspace created" in created
    assert "Joined" in joined
    assert "Workspace delta recorded" in posted
    assert workspace_id in state
    assert "claude-code (member/active)" in state
    assert "Drafted the schema packet outline." in state
    assert workspace_id in workspaces
    assert "handoff" in activity
    assert "Handed off notification model design to Codex for execution." in activity


def test_runtime_state_write_warning_is_deduped_until_success(monkeypatch, temp_dir, caplog):
    import builtins
    runtime_state_path = temp_dir / "runtime-state.json"
    monkeypatch.setenv("WHISPERS_DB_PATH", str(temp_dir / "test_whispers.db"))
    monkeypatch.setenv("WHISPERS_RUNTIME_STATE_PATH", str(runtime_state_path))

    import whispers.server as server_module

    manager = server_module.RuntimeStateManager()
    manager._flush_interval = 60.0
    attempts = {"count": 0}
    real_open = builtins.open

    monkeypatch.setattr(server_module, "_runtime_state_path", lambda: str(runtime_state_path))

    def flaky_open(path, mode="r", *args, **kwargs):
        if os.fspath(path) == str(runtime_state_path) and "w" in mode:
            attempts["count"] += 1
            if attempts["count"] <= 2:
                raise PermissionError("denied")
        return real_open(path, mode, *args, **kwargs)

    monkeypatch.setattr(builtins, "open", flaky_open)

    with caplog.at_level("WARNING", logger="whispers.server"):
        manager.save({"runtime_profile": "dev"})
        manager.flush()
        manager.save({"runtime_profile": "trusted_team"})
        manager.flush()
        manager.save({"runtime_profile": "custom"})
        manager.flush()
        attempts["count"] = 0
        manager.save({"runtime_profile": "dev"})
        manager.flush()

    warnings = [
        record.message
        for record in caplog.records
        if f"Unable to write runtime state to {runtime_state_path}" in record.message
    ]

    assert warnings == [
        f"Unable to write runtime state to {runtime_state_path}: denied",
        f"Unable to write runtime state to {runtime_state_path}: denied",
    ]


def test_runtime_state_flush_uses_path_captured_at_save_time(monkeypatch):
    import whispers.server as server_module

    manager = server_module.RuntimeStateManager()
    manager._flush_interval = 60.0
    initial_path = server_module._runtime_state_path()
    redirected_path = str(Path(initial_path).with_name("runtime-state-redirected.json"))

    manager.save({"runtime_profile": "dev"})
    monkeypatch.setattr(server_module, "_runtime_state_path", lambda: redirected_path)
    manager.flush()

    with open(initial_path, "r", encoding="utf-8") as handle:
        payload = json.load(handle)

    assert payload["runtime_profile"] == "dev"
    assert not os.path.exists(redirected_path)


def test_local_rename_migrates_pending_recipients_and_remote_identity(temp_db):
    alpha = WhispersClient("agent-a", db_path=temp_db)
    beta = WhispersClient("agent-b", db_path=temp_db)

    sent = beta.send("agent-a", "Queued before rename")
    token = alpha.db.issue_api_token("agent-a", description="rename-test")
    session = alpha.db.create_remote_session("agent-a", token, lease_seconds=300)
    alpha.db.mark_agent_online("agent-a", session["session_id"])

    renamed = alpha.rename("z4rivers-alpha", display_name="Alpha")

    assert alpha.agent_name == "z4rivers-alpha"
    assert renamed["new_callsign"] == "z4rivers-alpha"

    inbox = alpha.check_inbox(limit=10, mark_seen=True)
    assert [message["subject"] for message in inbox] == ["Queued before rename"]

    with alpha.db.get_connection() as conn:
        card = conn.execute(
            "SELECT callsign, display_name FROM agent_cards WHERE agent_id = ?",
            (renamed["agent_id"],),
        ).fetchone()
        token_row = conn.execute(
            "SELECT agent_name FROM api_tokens WHERE description = 'rename-test'"
        ).fetchone()
        session_row = conn.execute(
            "SELECT agent_name FROM agent_sessions WHERE session_id = ? AND session_kind = 'remote_http'",
            (session["session_id"],),
        ).fetchone()
        presence = conn.execute(
            "SELECT status FROM presence WHERE agent_name = 'z4rivers-alpha'"
        ).fetchone()
        pending = conn.execute(
            "SELECT recipient_callsign FROM message_recipients WHERE message_uuid = ?",
            (sent["id"],),
        ).fetchone()

    assert card["callsign"] == "z4rivers-alpha"
    assert card["display_name"] == "Alpha"
    assert token_row["agent_name"] == "z4rivers-alpha"
    assert session_row["agent_name"] == "z4rivers-alpha"
    assert presence["status"] == "online"
    assert pending["recipient_callsign"] == "z4rivers-alpha"


def test_local_rename_rejects_claimed_callsign(temp_db):
    alpha = WhispersClient("agent-a", db_path=temp_db)
    WhispersClient("agent-b", db_path=temp_db)

    with pytest.raises(WhispersConflictError):
        alpha.rename("agent-b")


def test_status_ignores_sticky_presence_without_active_session(temp_db):
    alpha = WhispersClient("agent-a", db_path=temp_db, session_kind="local_listener")
    beta = WhispersClient("agent-b", db_path=temp_db)

    with beta.db.get_connection() as conn:
        session_id = conn.execute(
            "SELECT session_id FROM agent_sessions WHERE agent_name = 'agent-a' ORDER BY created_at DESC LIMIT 1"
        ).fetchone()["session_id"]
        conn.execute("DELETE FROM agent_sessions WHERE session_id = ?", (session_id,))
        conn.execute(
            """
            UPDATE presence
            SET status = 'online',
                session_id = ?,
                heartbeat_at = CURRENT_TIMESTAMP,
                last_active = CURRENT_TIMESTAMP
            WHERE agent_name = 'agent-a'
            """,
            (session_id,),
        )
        conn.commit()

    status = beta.status()

    assert all(agent["agent_name"] != "agent-a" for agent in status["peers_online"])
    assert all(agent["agent_name"] != "agent-a" for agent in status["background_agents"])
    assert beta.handle_status("agent-a")["active"] is False


def test_history_views_follow_self_alias_after_rename(temp_db):
    alpha = WhispersClient("agent-a", db_path=temp_db)
    beta = WhispersClient("agent-b", db_path=temp_db)

    alpha.send("agent-b", "Before rename")
    beta.send("agent-a", "Reply before rename")

    alpha.rename("z4rivers-alpha", display_name="Alpha")

    outbox = alpha.outbox(limit=10)
    trace = alpha.trace("agent-b", limit=10)

    assert [message["subject"] for message in outbox] == ["Before rename"]
    assert [message["subject"] for message in trace] == ["Before rename", "Reply before rename"]


def test_trace_follows_peer_alias_after_peer_rename(temp_db):
    alpha = WhispersClient("agent-a", db_path=temp_db)
    beta = WhispersClient("agent-b", db_path=temp_db)

    alpha.send("agent-b", "Before peer rename")
    beta.send("agent-a", "Peer reply")
    beta.rename("z4rivers-beta", display_name="Beta")

    trace = alpha.trace("z4rivers-beta", limit=10)

    assert [message["subject"] for message in trace] == ["Before peer rename", "Peer reply"]


def test_status_reports_local_time_context(temp_db, monkeypatch):
    monkeypatch.setenv("WHISPERS_TIMEZONE", "America/Los_Angeles")
    client = WhispersClient("agent_a", db_path=temp_db)
    client.set_mode("focused", allow_senders=["orchestrator"])

    status = client.status()

    assert status["display_timezone"] == "America/Los_Angeles"
    assert status["now_utc"].endswith("Z")
    assert status["now_local"].endswith(("PST", "PDT"))
    assert status["mode_set_at_local"].endswith(("PST", "PDT"))


def test_message_views_include_localized_timestamps(temp_db, monkeypatch):
    monkeypatch.setenv("WHISPERS_TIMEZONE", "America/Los_Angeles")
    sender = WhispersClient("agent_a", db_path=temp_db)
    receiver = WhispersClient("agent_b", db_path=temp_db)

    sender.send("agent_b", "Hello there")
    inbox = receiver.check_inbox(limit=10, mark_seen=True)
    outbox = sender.outbox(limit=10)
    trace = sender.trace("agent_b", limit=10)

    assert inbox[0]["created_at_local"].endswith(("PST", "PDT"))
    assert outbox[0]["created_at_local"].endswith(("PST", "PDT"))
    assert outbox[0]["read_at_local"].endswith(("PST", "PDT"))
    assert trace[0]["created_at_local"].endswith(("PST", "PDT"))


def test_peek_inbox_shows_delivered_unread_messages(temp_db):
    sender = WhispersClient("agent_a", db_path=temp_db)
    receiver = WhispersClient("agent_b", db_path=temp_db)

    sent = sender.send("agent_b", "Live delivery")

    # Under the new delivery truth, online recipients are already 'delivered'
    # at send time, but unread rows still remain visible in peek surfaces.
    peek = receiver.check_inbox(limit=10, mark_seen=False)

    assert [message["subject"] for message in peek] == ["Live delivery"]
    assert peek[0]["delivery_status"] == "delivered"
    assert peek[0]["read_at"] is None


def test_send_surfaces_queue_truth_for_online_recipient(temp_db):
    """Send receipt reflects synchronous delivery check: online recipient → delivered."""
    sender = WhispersClient("codex", db_path=temp_db)
    sender.registry.register("claude-code")

    token = sender.db.issue_api_token("claude-code", description="online-recipient-test")
    session = sender.db.create_remote_session("claude-code", token, lease_seconds=300)
    sender.db.mark_agent_online("claude-code", session["session_id"])

    sent = sender.send("claude-code", "Live recipient")

    assert sent["status"] == "delivered"
    assert sent["delivery_status"] == "delivered"


def test_listen_local_claims_message_without_marking_read(temp_db):
    sender = WhispersClient("agent_a", db_path=temp_db)
    listener = WhispersClient("agent_b", db_path=temp_db)

    sent = sender.send("agent_b", "Listener pickup")
    message = next(listener.listen(poll_interval=0.01, max_messages=1))

    assert message["subject"] == "Listener pickup"
    assert message["delivery_status"] == "delivered"

    with sqlite3.connect(temp_db) as conn:
        conn.row_factory = sqlite3.Row
        recipient = conn.execute(
            "SELECT delivery_status, claimed_by, read_at FROM message_recipients WHERE message_uuid = ?",
            (sent["id"],),
        ).fetchone()

    assert recipient["delivery_status"] == "delivered"
    assert recipient["claimed_by"] == "agent_b"
    assert recipient["read_at"] is None


def test_acknowledge_message_updates_outbox_and_trace(temp_db):
    sender = WhispersClient("agent_a", db_path=temp_db)
    receiver = WhispersClient("agent_b", db_path=temp_db)

    sent = sender.send("agent_b", "Needs processing")
    acknowledged = receiver.acknowledge_message(sent["id"], "processed", detail="done")

    outbox = sender.outbox(limit=10)
    trace = sender.trace("agent_b", limit=10)

    assert acknowledged["ack_state"] == "processed"
    assert acknowledged["ack_detail"] == "done"
    assert acknowledged["acked_by"] == "agent_b"
    assert acknowledged["acked_at"] is not None
    assert outbox[0]["ack_state"] == "processed"
    assert outbox[0]["ack_detail"] == "done"
    assert outbox[0]["acked_by"] == "agent_b"
    assert outbox[0]["acked_at"] is not None
    assert trace[0]["ack_state"] == "processed"
    assert trace[0]["ack_detail"] == "done"


def test_existing_v2_db_adds_ack_columns(temp_db):
    with sqlite3.connect(temp_db) as conn:
        conn.execute(
            """
            CREATE TABLE schema_version (
                version INTEGER NOT NULL,
                migrated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
            """
        )
        conn.execute("INSERT INTO schema_version (version) VALUES (2)")
        conn.execute(
            """
            CREATE TABLE message_recipients (
                rowid INTEGER PRIMARY KEY AUTOINCREMENT,
                message_uuid TEXT NOT NULL,
                recipient_callsign TEXT,
                room_id TEXT,
                delivery_status TEXT DEFAULT 'queued',
                claimed_by TEXT,
                claimed_at TIMESTAMP,
                read_at TIMESTAMP,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
            """
        )
        conn.commit()

    WhispersClient("agent_a", db_path=temp_db)

    with sqlite3.connect(temp_db) as conn:
        columns = {row[1] for row in conn.execute("PRAGMA table_info(message_recipients)").fetchall()}

    assert {"ack_state", "ack_detail", "acked_by", "acked_at"} <= columns


def test_existing_v2_db_adds_agent_card_traffic_columns(temp_db):
    with sqlite3.connect(temp_db) as conn:
        conn.execute(
            """
            CREATE TABLE schema_version (
                version INTEGER NOT NULL,
                migrated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
            """
        )
        conn.execute("INSERT INTO schema_version (version) VALUES (2)")
        conn.execute(
            """
            CREATE TABLE agent_cards (
                agent_id TEXT PRIMARY KEY,
                callsign TEXT UNIQUE NOT NULL,
                agent_type TEXT NOT NULL,
                trust_tier INTEGER DEFAULT 1,
                capabilities TEXT,
                capabilities_verified TEXT,
                tools TEXT,
                lifecycle TEXT DEFAULT 'persistent',
                ttl_seconds INTEGER,
                parent_id TEXT,
                can_send_system BOOLEAN DEFAULT FALSE,
                can_send_flash BOOLEAN DEFAULT TRUE,
                registered_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                last_seen TIMESTAMP,
                deregistered_at TIMESTAMP,
                realm TEXT NOT NULL DEFAULT 'local',
                model_id TEXT,
                display_name TEXT,
                description TEXT,
                tags TEXT,
                challenge_tendency TEXT,
                thinking_style TEXT,
                public_key TEXT,
                lineage_parent_id TEXT,
                pool BOOLEAN,
                pool_strategy TEXT
            )
            """
        )
        conn.commit()

    WhispersClient("agent_a", db_path=temp_db)

    with sqlite3.connect(temp_db) as conn:
        columns = {row[1] for row in conn.execute("PRAGMA table_info(agent_cards)").fetchall()}

    assert {"agent_tier", "max_receive_rate"} <= columns


def test_whoami_and_list_agents_surface_agent_tier_metadata(temp_db):
    client = WhispersClient(
        "agent_a",
        db_path=temp_db,
        agent_type="llm",
        agent_tier="light",
        max_receive_rate=42,
    )

    whoami = client.whoami()
    assert whoami["agent_tier"] == "light"
    assert whoami["max_receive_rate"] == 42

    agents = client.list_agents()
    agent = next(entry for entry in agents if entry["callsign"] == "agent_a")
    assert agent["agent_tier"] == "light"
    assert agent["max_receive_rate"] == 42


def test_whoami_normalizes_participant_kind_and_profile_tags(temp_db):
    client = WhispersClient("agent_a", db_path=temp_db, agent_type="llm")
    client.registry.register(
        "agent_a",
        agent_type="llm",
        capabilities=["search", {"name": "reasoning", "description": "Deep analysis"}],
        tools=["shell", "mcp"],
        tags=["profile:approval_surface", "status_source", "team:redwood"],
    )

    whoami = client.whoami()

    assert whoami["participant_kind"] == "agent"
    assert whoami["is_primary_participant"] is True
    assert whoami["is_first_class_participant"] is True
    assert whoami["capabilities"] == ["search", {"name": "reasoning", "description": "Deep analysis"}]
    assert whoami["tools"] == ["shell", "mcp"]
    assert whoami["tags"] == ["profile:approval_surface", "status_source", "team:redwood"]
    assert whoami["participant_profiles"] == ["approval_surface", "status_source"]


def test_send_returns_dead_lettered_for_trust_tier_violation(temp_db):
    sender = WhispersClient("agent_a", db_path=temp_db)
    sender.registry.register("secure-agent")

    with sender.db.get_connection() as conn:
        conn.execute(
            "UPDATE agent_cards SET trust_tier = 3 WHERE callsign = 'secure-agent'"
        )
        conn.commit()

    result = sender.send("secure-agent", "Blocked by trust tier")

    assert result["status"] == "dead_lettered"
    assert result["reason"] == "trust_tier_violation"

    with sender.db.get_connection() as conn:
        dead_letter = conn.execute(
            "SELECT reason FROM dead_letters WHERE uuid = ?",
            (result["id"],),
        ).fetchone()

    assert dead_letter["reason"] == "trust_tier_violation"


def test_send_rejects_high_risk_external_action_without_authority(temp_db):
    sender = WhispersClient("agent_a", db_path=temp_db)
    WhispersClient("agent_b", db_path=temp_db)

    with pytest.raises(WhispersException, match="authority.principal"):
        sender.send(
            "agent_b",
            "Dangerous action",
            payload={
                "wire_v": 1,
                "schema": "external_action_request.v1",
                "trace": {"message_id": "msg-danger-1"},
                "payload": {
                    "action_class": "deploy",
                    "intent": "Ship to production",
                    "risk_level": "critical",
                },
            },
        )


def test_send_rejects_decision_response_outside_original_request_options(temp_db):
    alice = WhispersClient("alice", db_path=temp_db)
    bob = WhispersClient("bob", db_path=temp_db)

    request = alice.send(
        "bob",
        "Decision needed",
        payload={
            "wire_v": 1,
            "schema": "decision_request.v1",
            "accept_schemas": ["decision_response.v1"],
            "trace": {"message_id": "msg-decision-request-1"},
            "payload": {
                "question": "Deploy now?",
                "options": ["yes", "no"],
            },
        },
    )

    with pytest.raises(WhispersException, match="payload.decision"):
        bob.send(
            "alice",
            "Decision response",
            reply_to=request["id"],
            payload={
                "wire_v": 1,
                "schema": "decision_response.v1",
                "trace": {
                    "message_id": "msg-decision-response-1",
                    "in_reply_to": request["id"],
                },
                "payload": {"decision": "later"},
            },
        )


def test_deregister_dead_letters_pending_traffic(temp_db):
    sender = WhispersClient("agent_a", db_path=temp_db)
    sender.registry.register("agent_b")
    sender.registry.register("agent_c")

    incoming = sender.send("agent_b", "Incoming for b")
    worker = WhispersClient("agent_b", db_path=temp_db)
    outgoing = worker.send("agent_c", "Outgoing from b")

    assert incoming["status"] == "queued"
    assert outgoing["status"] == "queued"

    worker.deregister()

    with worker.db.get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute(
            "SELECT delivery_status FROM message_recipients WHERE message_uuid IN (?, ?) ORDER BY message_uuid",
            (incoming["id"], outgoing["id"]),
        )
        statuses = [row[0] for row in cursor.fetchall()]
        cursor.execute("SELECT COUNT(*) FROM dead_letters")
        dead_letters = cursor.fetchone()[0]
        cursor.execute("SELECT status, session_id FROM presence WHERE agent_name = 'agent_b'")
        presence = cursor.fetchone()

    assert statuses == ["dead_lettered", "dead_lettered"]
    assert dead_letters == 2
    assert presence["status"] == "offline"
    assert presence["session_id"] is None


def test_read_only_check_inbox_skips_maintenance_and_read_receipts(temp_db, monkeypatch):
    sender = WhispersClient("agent_a", db_path=temp_db)
    sender.registry.register("agent_b")
    sent = sender.send("agent_b", "Queued for readonly")

    reader = WhispersClient("agent_b", db_path=temp_db, read_only=True)

    def _should_not_run(*args, **kwargs):
        raise AssertionError("maintenance should not run in read-only inbox inspection")

    monkeypatch.setattr(reader.db, "reap_ghosts", _should_not_run)
    monkeypatch.setattr(reader.db, "expire_stale_messages", _should_not_run)
    monkeypatch.setattr(reader.db, "sweep_dead_agents", _should_not_run)

    messages = reader.check_inbox(limit=10, mark_seen=True)

    assert [message["subject"] for message in messages] == ["Queued for readonly"]
    with reader.db.get_connection() as conn:
        status = conn.execute(
            "SELECT delivery_status FROM message_recipients WHERE message_uuid = ?",
            (sent["id"],),
        ).fetchone()[0]

    assert status == "queued"


def test_read_only_client_does_not_run_schema_init(temp_db, monkeypatch):
    WhispersClient("agent_a", db_path=temp_db)

    def _should_not_run(self):
        raise AssertionError("_init_schema should not run for read-only clients")

    monkeypatch.setattr("whispers.storage.db.WhispersDB._init_schema", _should_not_run)

    reader = WhispersClient("agent_a", db_path=temp_db, read_only=True)
    status = reader.status()

    assert status["healthy"] is True


def test_read_only_status_skips_maintenance_sweeps(temp_db, monkeypatch):
    WhispersClient("agent_a", db_path=temp_db)
    reader = WhispersClient("agent_a", db_path=temp_db, read_only=True)

    def _should_not_run(*args, **kwargs):
        raise AssertionError("status maintenance should not run for read-only clients")

    monkeypatch.setattr(reader.db, "reap_expired_agent_sessions", _should_not_run)
    monkeypatch.setattr(reader.db, "reap_ghosts", _should_not_run)

    status = reader.status()

    assert status["healthy"] is True


def test_trace_limit_returns_latest_messages_in_chronological_order(temp_db):
    codex = WhispersClient("codex", db_path=temp_db)
    codex.registry.register("antigravity")

    codex.send("antigravity", "Turn 1", "first")
    codex.send("antigravity", "Turn 2", "second")
    codex.send("antigravity", "Turn 3", "third")

    trace = codex.trace("antigravity", limit=2)

    assert [message["subject"] for message in trace] == ["Turn 2", "Turn 3"]


def test_mock_client_status():
    """MockWhispersClient.status() returns a safe default."""
    client = MockWhispersClient("agent_a")
    s = client.status()

    assert s["healthy"] is True
    assert s["deployment_mode"] == "mock"
    assert s["pending_messages"] == 0


def test_mcp_status_surfaces_local_time_context(temp_db, monkeypatch):
    monkeypatch.setenv("WHISPERS_DB_PATH", temp_db)
    monkeypatch.setenv("WHISPERS_TIMEZONE", "America/Los_Angeles")
    mcp_module._clients.clear()
    token = mcp_module.current_agent_name.set("agent_a")
    try:
        response = asyncio.run(mcp_module.handle_tool("status", {}))
    finally:
        mcp_module.current_agent_name.reset(token)
        mcp_module._clients.clear()

    text = response[0].text
    assert "Local time:" in text
    assert "America/Los_Angeles" in text
    assert "PDT" in text or "PST" in text

def test_mcp_message_check_partitions_backlog_vs_live(temp_db, monkeypatch):
    """Messages sent before an agent's MCP session appear under BACKLOG header."""
    monkeypatch.setenv("WHISPERS_DB_PATH", temp_db)

    # Step 1: Create sender and send a message BEFORE receiver's MCP session exists
    sender = WhispersClient("sender", db_path=temp_db)
    sender.registry.register("receiver")
    sender.send("receiver", "Pre-session message", "Hello from before")

    # Step 2: Now create the receiver's MCP session (simulating a fresh agent connecting)
    import time
    time.sleep(0.2)  # ensure timestamp separation (message stored at second precision)
    mcp_module._clients.clear()
    token = mcp_module.current_agent_name.set("receiver")
    try:
        response = asyncio.run(mcp_module.handle_tool("message_check", {}))
    finally:
        mcp_module.current_agent_name.reset(token)
        mcp_module._clients.clear()

    text = response[0].text
    assert "BACKLOG" in text, f"Expected BACKLOG header in output, got: {text}"
    assert "Pre-session message" in text
    assert "LIVE" not in text


def test_mcp_message_check_clears_stale_inbox_alert_after_read(temp_db, monkeypatch):
    """Reading the inbox should resync Channel C alerts so status can't append stale unread state."""
    monkeypatch.setenv("WHISPERS_DB_PATH", temp_db)

    sender = WhispersClient("sender", db_path=temp_db)
    sender.registry.register("receiver")
    sender.send("receiver", "Needs read", "Body")

    mcp_module._clients.clear()
    token = mcp_module.current_agent_name.set("receiver")
    original_monitor = mcp_module._inbox_monitor
    test_monitor = mcp_module.InboxMonitor(poll_interval=0.5)
    mcp_module._inbox_monitor = test_monitor
    try:
        client = mcp_module._get_client()
        test_monitor._check_agent("receiver", client)
        assert "1 unread" in test_monitor.peek_alert("receiver")

        response = asyncio.run(mcp_module.handle_tool("message_check", {}))

        assert "Needs read" in response[0].text
        assert test_monitor.peek_alert("receiver") == ""
    finally:
        mcp_module.current_agent_name.reset(token)
        mcp_module._clients.clear()
        mcp_module._inbox_monitor = original_monitor


def test_mcp_message_check_resync_preserves_remaining_unread_alerts(temp_db, monkeypatch):
    """Partial reads should leave a truthful pending alert for the unread remainder."""
    monkeypatch.setenv("WHISPERS_DB_PATH", temp_db)

    sender = WhispersClient("sender", db_path=temp_db)
    sender.registry.register("receiver")
    sender.send("receiver", "First")
    sender.send("receiver", "Second")

    mcp_module._clients.clear()
    token = mcp_module.current_agent_name.set("receiver")
    original_monitor = mcp_module._inbox_monitor
    test_monitor = mcp_module.InboxMonitor(poll_interval=0.5)
    mcp_module._inbox_monitor = test_monitor
    try:
        client = mcp_module._get_client()
        test_monitor._check_agent("receiver", client)
        assert "2 unread" in test_monitor.peek_alert("receiver")

        response = asyncio.run(mcp_module.handle_tool("message_check", {"limit": 1}))

        assert "First" in response[0].text or "Second" in response[0].text
        assert "You still have 1 more unread message(s) pending" in response[0].text
        remaining_alert = test_monitor.peek_alert("receiver")
        assert "1 unread" in remaining_alert
    finally:
        mcp_module.current_agent_name.reset(token)
        mcp_module._clients.clear()
        mcp_module._inbox_monitor = original_monitor


def test_mcp_message_check_surfaces_blob_attachment_details(temp_db, monkeypatch):
    """Blob-bearing messages should show their attachment ref and fetch hint when read."""
    monkeypatch.setenv("WHISPERS_DB_PATH", temp_db)

    sender = WhispersClient("sender", db_path=temp_db)
    sender.registry.register("receiver")
    sender.send(
        "receiver",
        "Descriptor draft",
        "Body preview",
        payload={
            "attachment": {
                "ref": "sha256:abc123",
                "label": "descriptor-spec",
                "media_type": "text/markdown",
            },
            "whispers:disclosure:headline": "Full schema attached",
            "whispers:disclosure:summary": "Use the blob ref to read the full draft.",
        },
    )

    mcp_module._clients.clear()
    token = mcp_module.current_agent_name.set("receiver")
    try:
        response = asyncio.run(mcp_module.handle_tool("message_check", {}))
    finally:
        mcp_module.current_agent_name.reset(token)
        mcp_module._clients.clear()

    text = response[0].text
    assert "Descriptor draft | Full schema attached" in text
    assert "Attachment: descriptor-spec [sha256:abc123]" in text
    assert "Use `fetch_blob` with the attachment ref" in text


def test_mcp_message_done_warns_on_backlog_message(temp_db, monkeypatch):
    """message_done on a backlog message returns a warning about acting on pre-session context."""
    monkeypatch.setenv("WHISPERS_DB_PATH", temp_db)

    # Send a message before the MCP session exists
    sender = WhispersClient("sender", db_path=temp_db)
    sender.registry.register("receiver")
    sent = sender.send("receiver", "Old context message")

    import time
    time.sleep(0.2)

    mcp_module._clients.clear()
    token = mcp_module.current_agent_name.set("receiver")
    try:
        # First read inbox to populate the client
        asyncio.run(mcp_module.handle_tool("message_check", {}))
        # Now try to mark the backlog message as done
        response = asyncio.run(mcp_module.handle_tool("message_done", {"id": sent["id"]}))
    finally:
        mcp_module.current_agent_name.reset(token)
        mcp_module._clients.clear()

    text = response[0].text
    assert "marked done" in text
    assert "BEFORE your current session" in text, f"Expected backlog warning, got: {text}"


def test_mcp_message_respond_uses_visual_signal_format(temp_db, monkeypatch):
    """message_respond output uses the outgoing visual signal format with recipient name.

    This ensures operator-visible parity: message_send already uses the visual
    format, message_respond must too so replies to active assignments are
    visually distinguishable from plain text.
    """
    monkeypatch.setenv("WHISPERS_DB_PATH", temp_db)

    # Set up sender and receiver, send a message to reply to
    sender = WhispersClient("codex", db_path=temp_db)
    sender.registry.register("claude-code")
    sent = sender.send("claude-code", "Assignment: startup lock-down", body="Do the thing")

    mcp_module._clients.clear()
    token = mcp_module.current_agent_name.set("claude-code")
    try:
        response = asyncio.run(mcp_module.handle_tool("message_respond", {
            "reply_to": sent["id"],
            "body": "Ack. Scope understood.",
            "type": "inform",
        }))
    finally:
        mcp_module.current_agent_name.reset(token)
        mcp_module._clients.clear()

    text = response[0].text
    # Must use outgoing signal prefix
    assert "<\u23e6\u23e6\u23e6" in text, f"Expected outgoing signal prefix, got: {text}"
    # Must include recipient name
    assert "codex" in text, f"Expected recipient 'codex' in reply output, got: {text}"
    # Must include delivery status
    assert "Reply delivered" in text or "Reply queued" in text, f"Expected delivery status, got: {text}"


def test_mcp_message_respond_accepts_priority(temp_db, monkeypatch):
    """message_respond passes priority to the underlying send call."""
    monkeypatch.setenv("WHISPERS_DB_PATH", temp_db)

    sender = WhispersClient("codex", db_path=temp_db)
    sender.registry.register("claude-code")
    sent = sender.send("claude-code", "Assignment: next slice", body="Pressure-test the thing")

    mcp_module._clients.clear()
    token = mcp_module.current_agent_name.set("claude-code")
    try:
        response = asyncio.run(mcp_module.handle_tool("message_respond", {
            "reply_to": sent["id"],
            "body": "Ack. Starting now.",
            "type": "inform",
            "priority": "priority",
        }))
    finally:
        mcp_module.current_agent_name.reset(token)
        mcp_module._clients.clear()

    text = response[0].text
    assert "<\u23e6\u23e6\u23e6" in text, f"Expected visual format, got: {text}"


def test_mcp_message_tools_share_friendly_message_type_aliases():
    """message_send and message_respond should advertise the same accepted type aliases."""
    message_send_tool = next(tool for tool in mcp_module.TOOLS if tool.name == "message_send")
    message_respond_tool = next(tool for tool in mcp_module.TOOLS if tool.name == "message_respond")

    send_enum = message_send_tool.inputSchema["properties"]["type"]["enum"]
    respond_enum = message_respond_tool.inputSchema["properties"]["type"]["enum"]

    assert respond_enum == send_enum
    assert "assignment" in respond_enum
    assert "collaboration" in respond_enum
    assert "note" in respond_enum


def test_mcp_message_respond_accepts_note_alias(temp_db, monkeypatch):
    """message_respond should accept the natural alias 'note' and normalize it to inform."""
    monkeypatch.setenv("WHISPERS_DB_PATH", temp_db)

    sender = WhispersClient("codex", db_path=temp_db)
    sender.registry.register("claude-code")
    sent = sender.send("claude-code", "Check the live thread", body="Respond when you have it.")

    mcp_module._clients.clear()
    token = mcp_module.current_agent_name.set("claude-code")
    try:
        response = asyncio.run(mcp_module.handle_tool("message_respond", {
            "reply_to": sent["id"],
            "body": "I have it.",
            "type": "note",
        }))
    finally:
        mcp_module.current_agent_name.reset(token)
        mcp_module._clients.clear()

    text = response[0].text
    assert "Reply delivered" in text or "Reply queued" in text

    inbox = sender.check_inbox(limit=10, mark_seen=False)
    assert inbox[0]["subject"] == "Re: Check the live thread"
    assert inbox[0]["msg_type"] == "inform"


def test_mcp_store_blob_returns_attachment_reference(temp_db, monkeypatch):
    """store_blob should use the module-level json import without tripping a local shadow."""
    monkeypatch.setenv("WHISPERS_DB_PATH", temp_db)
    import whispers.storage.blobs as blobs_module
    blob_root = Path(temp_db).parent / "blobs"
    monkeypatch.setattr(blobs_module, "_DEFAULT_BLOB_DIR", blob_root)

    mcp_module._clients.clear()
    token = mcp_module.current_agent_name.set("codex")
    try:
        response = asyncio.run(mcp_module.handle_tool("store_blob", {
            "content": "full tranche review packet",
            "media_type": "text/plain",
            "label": "review-packet",
        }))
    finally:
        mcp_module.current_agent_name.reset(token)
        mcp_module._clients.clear()

    text = response[0].text
    assert "Blob stored. Reference:" in text
    assert '"ref"' in text
    assert "Failed to store blob" not in text


def test_mcp_message_send_accepts_assignment_alias(temp_db, monkeypatch):
    """message_send should accept the natural alias 'assignment' and normalize it to request."""
    monkeypatch.setenv("WHISPERS_DB_PATH", temp_db)

    sender = WhispersClient("codex", db_path=temp_db)
    sender.registry.register("claude-code")

    message_send_tool = next(tool for tool in mcp_module.TOOLS if tool.name == "message_send")
    assert "assignment" in message_send_tool.inputSchema["properties"]["type"]["enum"]

    mcp_module._clients.clear()
    token = mcp_module.current_agent_name.set("codex")
    try:
        response = asyncio.run(mcp_module.handle_tool("message_send", {
            "to": "claude-code",
            "subject": "Take next slice",
            "body": "Own the continuity runtime seam.",
            "type": "assignment",
        }))
    finally:
        mcp_module.current_agent_name.reset(token)
        mcp_module._clients.clear()

    text = response[0].text
    assert "queued to claude-code" in text or "delivered to claude-code" in text

    receiver = WhispersClient("claude-code", db_path=temp_db)
    inbox = receiver.check_inbox(limit=10, mark_seen=False)
    assert inbox[0]["subject"] == "Take next slice"
    assert inbox[0]["msg_type"] == "request"


def test_mcp_message_send_accepts_collaboration_alias(temp_db, monkeypatch):
    """message_send should accept the natural alias 'collaboration' and normalize it to inform."""
    monkeypatch.setenv("WHISPERS_DB_PATH", temp_db)

    sender = WhispersClient("codex", db_path=temp_db)
    sender.registry.register("claude-code")

    message_send_tool = next(tool for tool in mcp_module.TOOLS if tool.name == "message_send")
    assert "collaboration" in message_send_tool.inputSchema["properties"]["type"]["enum"]

    mcp_module._clients.clear()
    token = mcp_module.current_agent_name.set("codex")
    try:
        response = asyncio.run(mcp_module.handle_tool("message_send", {
            "to": "claude-code",
            "subject": "Shared packet",
            "body": "Pressure-test this with me.",
            "type": "collaboration",
        }))
    finally:
        mcp_module.current_agent_name.reset(token)
        mcp_module._clients.clear()

    text = response[0].text
    assert "queued to claude-code" in text or "delivered to claude-code" in text

    receiver = WhispersClient("claude-code", db_path=temp_db)
    inbox = receiver.check_inbox(limit=10, mark_seen=False)
    assert inbox[0]["subject"] == "Shared packet"
    assert inbox[0]["msg_type"] == "inform"


def test_mcp_message_send_uses_queue_truth_for_online_recipient(temp_db, monkeypatch):
    """MCP send receipt reflects synchronous delivery check for online recipients."""
    monkeypatch.setenv("WHISPERS_DB_PATH", temp_db)

    sender = WhispersClient("codex", db_path=temp_db)
    sender.registry.register("claude-code")
    token = sender.db.issue_api_token("claude-code", description="online-recipient-test")
    session = sender.db.create_remote_session("claude-code", token, lease_seconds=300)
    sender.db.mark_agent_online("claude-code", session["session_id"])

    mcp_module._clients.clear()
    token_ctx = mcp_module.current_agent_name.set("codex")
    try:
        response = asyncio.run(mcp_module.handle_tool("message_send", {
            "to": "claude-code",
            "subject": "Live recipient truth",
            "body": "Queue truth should win over reachability hint.",
            "type": "collaboration",
        }))
    finally:
        mcp_module.current_agent_name.reset(token_ctx)
        mcp_module._clients.clear()

    text = response[0].text
    assert "delivered to claude-code" in text


def test_mcp_signal_mode_set_accepts_uppercase_names(temp_db, monkeypatch):
    """signal_mode_set should accept the human-facing uppercase mode names from the tool description."""
    monkeypatch.setenv("WHISPERS_DB_PATH", temp_db)

    signal_mode_tool = next(tool for tool in mcp_module.TOOLS if tool.name == "signal_mode_set")
    assert "OPEN" in signal_mode_tool.inputSchema["properties"]["mode"]["enum"]
    assert "FOCUSED" in signal_mode_tool.inputSchema["properties"]["mode"]["enum"]
    assert "QUIET" in signal_mode_tool.inputSchema["properties"]["mode"]["enum"]

    mcp_module._clients.clear()
    token = mcp_module.current_agent_name.set("codex")
    try:
        response = asyncio.run(mcp_module.handle_tool("signal_mode_set", {
            "mode": "FOCUSED",
            "allow_senders": "[\"claude-code\"]",
        }))
    finally:
        mcp_module.current_agent_name.reset(token)
        mcp_module._clients.clear()

    text = response[0].text
    assert "Mode set to FOCUSED." in text

    codex = WhispersClient("codex", db_path=temp_db)
    status = codex.status()
    assert status["my_mode"] == "FOCUSED"


def test_mcp_review_resolve_rejects_reviewing_and_allows_open_release(temp_db, monkeypatch):
    monkeypatch.setenv("WHISPERS_DB_PATH", temp_db)

    author = WhispersClient("claude-code", db_path=temp_db)
    author.registry.register("codex")
    signal = author.send(
        "codex",
        "Review dispatcher change",
        body="Please review this runtime slice.",
        msg_type="propose",
    )

    db = WhispersDB(temp_db)
    claim_id = db.create_signal_claim(
        signal_uuid=signal["id"],
        topic="Dispatcher review",
        lens="general",
    )
    assert db.claim_signal(claim_id, "codex") is True

    mcp_module._clients.clear()
    token = mcp_module.current_agent_name.set("codex")
    try:
        invalid = asyncio.run(
            mcp_module.handle_tool(
                "review_resolve",
                {"claim_id": claim_id, "state": "reviewing"},
            )
        )[0].text
        released = asyncio.run(
            mcp_module.handle_tool(
                "review_resolve",
                {"claim_id": claim_id, "state": "open"},
            )
        )[0].text
    finally:
        mcp_module.current_agent_name.reset(token)
        mcp_module._clients.clear()

    assert "invalid state 'reviewing'" in invalid
    assert released == f"Claim {claim_id} transitioned to 'open'."
    assert db.get_signal_claim(claim_id)["state"] == "open"


def test_client_tracks_session_started_at(temp_db):
    """WhispersClient records _session_started_at on init for backlog detection."""
    from datetime import datetime, timezone
    client = WhispersClient("agent_a", db_path=temp_db)
    assert hasattr(client, "_session_started_at")
    assert client._session_started_at is not None
    assert isinstance(client._session_started_at, datetime)
    assert client._session_started_at.tzinfo is not None


# --- list_agents / whispers who tests ---


def test_list_agents_returns_all_registered(temp_db):
    """list_agents returns every registered agent, not just online ones."""
    a = WhispersClient("agent_a", db_path=temp_db)
    b = WhispersClient("agent_b", db_path=temp_db)
    c = WhispersClient("agent_c", db_path=temp_db)

    agents = a.list_agents()
    callsigns = [ag["callsign"] for ag in agents]

    assert len(agents) == 3
    assert "agent_a" in callsigns
    assert "agent_b" in callsigns
    assert "agent_c" in callsigns


def test_list_agents_includes_agent_metadata(temp_db):
    """Each entry has the expected fields."""
    client = WhispersClient("agent_a", db_path=temp_db)

    agents = client.list_agents()
    assert len(agents) == 1
    agent = agents[0]

    assert agent["callsign"] == "agent_a"
    assert "agent_type" in agent
    assert "trust_tier" in agent
    assert "registered_at" in agent
    assert "is_online" in agent
    assert "readiness" in agent
    assert "derived_active_mode" in agent


def test_list_agents_shows_online_status(temp_db):
    """Agents with active presence show as online."""
    a = WhispersClient("agent_a", db_path=temp_db)
    b = WhispersClient("agent_b", db_path=temp_db)

    agents = a.list_agents()
    assert len(agents) == 2
    for ag in agents:
        assert "is_online" in ag


def test_list_agents_surfaces_operator_participant_buckets(temp_db):
    observer = WhispersClient("codex", db_path=temp_db, agent_type="remote_client")
    observer.registry.register("whispers-server", agent_type="infrastructure")
    observer.registry.register("whispers-console", agent_type="typescript_sdk")
    observer.registry.register("cursor", agent_type="mcp_server")
    observer.registry.register("game_orchestrator", agent_type="infrastructure")
    observer.registry.register("_probe", agent_type="mcp_server")
    observer.registry.register("test-agent", agent_type="script")

    agents = {agent["callsign"]: agent for agent in observer.list_agents()}

    assert agents["codex"]["participant_kind"] == "agent"
    assert agents["codex"]["is_primary_participant"] is True
    assert agents["codex"]["is_first_class_participant"] is True
    assert agents["whispers-server"]["participant_kind"] == "service"
    assert agents["whispers-server"]["is_primary_participant"] is True
    assert agents["whispers-console"]["participant_kind"] == "service"
    assert agents["cursor"]["participant_kind"] == "agent"
    assert agents["game_orchestrator"]["participant_kind"] == "automaton"
    assert agents["game_orchestrator"]["is_primary_participant"] is False
    assert agents["game_orchestrator"]["is_first_class_participant"] is False
    assert agents["_probe"]["participant_kind"] == "ephemeral"
    assert agents["test-agent"]["participant_kind"] == "ephemeral"


def test_list_agents_derives_wake_model_from_active_sessions(temp_db):
    observer = WhispersClient("codex", db_path=temp_db, agent_type="remote_client")
    WhispersClient("antigravity", db_path=temp_db, agent_type="mcp_server")
    observer.registry.register("listener-bot", agent_type="script")
    observer.registry.register("whispers-console", agent_type="typescript_sdk")

    observer.db.upsert_agent_session(
        "listener-bot",
        "listener-session",
        session_kind="local_listener",
        lease_seconds=300,
        substantive=True,
    )
    observer.db.upsert_agent_session(
        "antigravity",
        "listener-overlay",
        session_kind="local_listener",
        lease_seconds=300,
        substantive=True,
    )
    observer.db.upsert_agent_session(
        "whispers-console",
        "console-session",
        session_kind="dashboard_console",
        lease_seconds=300,
        substantive=True,
    )

    agents = {agent["callsign"]: agent for agent in observer.list_agents()}

    assert agents["codex"]["wake_model"] == "manual_wake"
    assert agents["codex"]["session_kinds"] == ["local_client"]
    assert agents["listener-bot"]["wake_model"] == "listener_backed"
    assert agents["listener-bot"]["session_kinds"] == ["local_listener"]
    assert agents["whispers-console"]["wake_model"] == "operator_console"
    assert agents["whispers-console"]["session_kinds"] == ["dashboard_console"]
    assert agents["antigravity"]["wake_model"] == "mixed"
    assert agents["antigravity"]["session_kinds"] == ["local_listener", "mcp_bridge"]


def test_list_agents_shows_reception_mode(temp_db):
    """Reception mode is included in list_agents output."""
    client = WhispersClient("agent_a", db_path=temp_db)
    client.set_mode("focused", allow_senders=["agent_b"])

    agents = client.list_agents()
    agent_a = next(ag for ag in agents if ag["callsign"] == "agent_a")
    assert agent_a["reception_mode"] == "focused"


def test_list_agents_omits_volatile_wag_state(temp_db):
    """Wag state is volatile (memory-only) and does not propagate to SQLite list_agents."""
    client = WhispersClient("agent_a", db_path=temp_db)
    client.wag("building", intent="writing tests")

    agents = client.list_agents()
    agent_a = next(ag for ag in agents if ag["callsign"] == "agent_a")
    assert agent_a.get("cognitive_state") is None


def test_status_hides_stale_current_task_when_agent_is_ready_and_listening(temp_db):
    """Operator-facing peer state should not advertise an old task once the agent is idle again."""
    agent_a = WhispersClient("agent_a", db_path=temp_db)
    observer = WhispersClient("agent_b", db_path=temp_db)

    agent_a.set_readiness("busy", current_task="deep focus")
    agent_a.set_readiness("ready")
    runtime = agent_a.get_runtime_state()
    assert runtime.get("current_task") is None
    with agent_a.db.get_connection() as conn:
        conn.execute(
            "UPDATE presence SET cognitive_state = 'listening', last_active = CURRENT_TIMESTAMP WHERE agent_name = ?",
            ("agent_a",),
        )
        conn.commit()

    status = observer.status()
    peer = next(agent for agent in status["peers_online"] if agent["agent_name"] == "agent_a")

    assert peer["readiness"] == "ready"
    assert peer["cognitive_state"] == "listening"
    assert not peer.get("current_task")


def test_ready_transition_clears_stale_working_attention_when_not_replaced(temp_db):
    agent = WhispersClient("agent_a", db_path=temp_db)

    agent.set_readiness(
        "busy",
        current_task="deep focus",
        attention_state="working",
        attention_detail="Writing the proof suite",
    )
    agent.set_readiness("ready")

    runtime = agent.get_runtime_state()
    assert runtime["readiness"] == "ready"
    assert runtime.get("current_task") is None
    assert runtime.get("attention_state") is None
    assert runtime.get("attention_detail") is None


def test_status_separates_first_class_participants_from_auxiliary_registry(temp_db):
    observer = WhispersClient("codex", db_path=temp_db, agent_type="remote_client")
    observer.registry.register("whispers-server", agent_type="infrastructure")
    observer.registry.register("cursor", agent_type="mcp_server")
    observer.registry.register("game_orchestrator", agent_type="infrastructure")
    observer.registry.register("_probe", agent_type="mcp_server")
    observer.registry.register("test-agent", agent_type="script")

    status = observer.status()

    assert status["agents_registered"] == 6
    assert status["primary_participants_registered"] == 3
    assert status["secondary_participants_registered"] == 3
    assert status["first_class_participants_registered"] == 3
    assert status["other_participants_registered"] == 3
    assert status["participant_counts"]["agent"]["registered"] == 2
    assert status["participant_counts"]["service"]["registered"] == 1
    assert status["participant_counts"]["automaton"]["registered"] == 1
    assert status["participant_counts"]["ephemeral"]["registered"] == 2


def test_status_surfaces_wake_model_for_manual_and_listener_backed_peers(temp_db):
    observer = WhispersClient("codex", db_path=temp_db, agent_type="remote_client")
    WhispersClient("antigravity", db_path=temp_db, agent_type="mcp_server")
    observer.registry.register("listener-bot", agent_type="script")
    observer.db.upsert_agent_session(
        "listener-bot",
        "listener-session",
        session_kind="local_listener",
        lease_seconds=300,
        substantive=True,
    )

    status = observer.status()

    prompt_bound_peer = next(agent for agent in status["peers_online"] if agent["agent_name"] == "antigravity")
    listener_peer = next(agent for agent in status["background_agents"] if agent["agent_name"] == "listener-bot")

    assert prompt_bound_peer["wake_model"] == "manual_wake"
    assert prompt_bound_peer["session_kinds"] == ["mcp_bridge"]
    assert listener_peer["wake_model"] == "listener_backed"
    assert listener_peer["session_kinds"] == ["local_listener"]


def test_status_surfaces_peer_jolt_contract_for_manual_wake_bridge_peer(temp_db):
    observer = WhispersClient("codex", db_path=temp_db, agent_type="remote_client")
    claude = WhispersClient(
        "claude-code",
        db_path=temp_db,
        agent_type="mcp_server",
        jolt_host_kind="claude_code",
        jolt_adapter_kind="managed_pty",
        jolt_can_stage_context=True,
        jolt_can_trigger_inference=True,
    )

    claude.set_readiness(
        "ready",
        attention_state="needs_assignment",
        attention_detail="Ready for the next slice.",
    )

    status = observer.status()
    peer = next(agent for agent in status["peers_online"] if agent["agent_name"] == "claude-code")
    alert = next(item for item in status["peer_assignment_alerts"] if item["agent_name"] == "claude-code")

    assert peer["wake_model"] == "manual_wake"
    assert peer["jolt_adapter"]["adapter_kind"] == "managed_pty"
    assert peer["jolt_adapter"]["supported_actions"] == ["notify", "stage_context", "infer"]
    assert peer["jolt_host_capabilities"]["can_stage_context"] is True
    assert peer["jolt_host_capabilities"]["can_trigger_inference"] is True
    assert alert["operator_nudge_required"] is False
    assert status["peer_nudge_requests"] == 0


def test_mcp_presence_who_shows_all_agents(temp_db, monkeypatch):
    """MCP presence_who now shows registered agents, not just online ones."""
    monkeypatch.setenv("WHISPERS_DB_PATH", temp_db)
    mcp_module._clients.clear()

    a = WhispersClient("agent_a", db_path=temp_db)
    b = WhispersClient("agent_b", db_path=temp_db)

    token = mcp_module.current_agent_name.set("agent_a")
    try:
        response = asyncio.run(mcp_module.handle_tool("presence_who", {}))
    finally:
        mcp_module.current_agent_name.reset(token)
        mcp_module._clients.clear()

    text = response[0].text
    assert "agent_a" in text
    assert "agent_b" in text
    assert "registered" in text


def test_mcp_presence_who_surfaces_carrying_baton(temp_db, monkeypatch):
    """Topology enrichment should show carrying_baton for an unacknowledged handoff sender."""
    monkeypatch.setenv("WHISPERS_DB_PATH", temp_db)
    mcp_module._clients.clear()

    sender = WhispersClient("agent_a", db_path=temp_db)
    recipient = WhispersClient("agent_b", db_path=temp_db)
    sender.send_handoff(
        "agent_b",
        objective="Design notification runtime",
        deliverable="NOTIFICATION-SCHEMA-PACKET.md",
        completed="Design packet drafted.",
        remaining="Turn the packet into an implementation-ready schema note.",
        next_action="Write NOTIFICATION-SCHEMA-PACKET.md",
        human_summary="Turn the design into the schema packet.",
    )

    token = mcp_module.current_agent_name.set("agent_a")
    try:
        response = asyncio.run(mcp_module.handle_tool("presence_who", {}))
    finally:
        mcp_module.current_agent_name.reset(token)
        mcp_module._clients.clear()

    text = response[0].text
    assert "agent_a" in text
    assert "carrying_baton" in text


# --- generate_callsign tests ---


def test_generate_callsign_format():
    """Generated callsigns match the callsign format regex."""
    for _ in range(20):
        callsign = generate_callsign()
        assert REMOTE_CALLSIGN_RE.match(callsign), f"Invalid callsign: {callsign}"


def test_generate_callsign_with_prefix():
    """Prefixed callsigns include the prefix."""
    callsign = generate_callsign(prefix="bot")
    assert callsign.startswith("bot-")
    assert REMOTE_CALLSIGN_RE.match(callsign)


def test_generate_callsign_uniqueness():
    """Generated callsigns have reasonable variety."""
    names = {generate_callsign() for _ in range(50)}
    assert len(names) > 10


def test_reachability_trusted_only_blocks_low_tier(temp_db):
    sender = WhispersClient("agent_a", db_path=temp_db)
    receiver = WhispersClient("agent_b", db_path=temp_db)

    with sender.db.get_connection() as conn:
        conn.execute("UPDATE agent_cards SET trust_tier = 0 WHERE callsign = 'agent_a'")
        conn.execute("UPDATE agent_cards SET trust_tier = 1 WHERE callsign = 'agent_b'")
        conn.commit()

    receiver.set_presence_policy({"reachability": "trusted_only"})

    resp = sender.send("agent_b", "hello")
    assert resp["status"] == "dead_lettered"
    assert resp["reason"] == "reachability_policy_blocked"


def test_reachability_trusted_only_allows_high_tier(temp_db):
    sender = WhispersClient("agent_a", db_path=temp_db)
    receiver = WhispersClient("agent_b", db_path=temp_db)

    with sender.db.get_connection() as conn:
        conn.execute("UPDATE agent_cards SET trust_tier = 1 WHERE callsign = 'agent_a'")
        conn.execute("UPDATE agent_cards SET trust_tier = 1 WHERE callsign = 'agent_b'")
        conn.commit()

    receiver.set_presence_policy({"reachability": "trusted_only"})

    resp = sender.send("agent_b", "hello")
    assert resp["status"] in ["queued", "delivered"]


def test_reachability_direct_only_blocks_new_thread(temp_db):
    sender = WhispersClient("agent_a", db_path=temp_db)
    receiver = WhispersClient("agent_b", db_path=temp_db)

    receiver.set_presence_policy({"reachability": "direct_only"})

    resp = sender.send("agent_b", "hello")
    assert resp["status"] == "dead_lettered"
    assert resp["reason"] == "reachability_policy_blocked"


def test_reachability_direct_only_allows_reply(temp_db):
    sender = WhispersClient("agent_a", db_path=temp_db)
    receiver = WhispersClient("agent_b", db_path=temp_db)

    receiver.set_presence_policy({"reachability": "direct_only"})

    msg1 = receiver.send("agent_a", "hello")
    resp = sender.send("agent_b", "hello", reply_to=msg1["id"])
    assert resp["status"] in ["queued", "delivered"]


def test_reachability_direct_only_allows_system_priority(temp_db):
    sender = WhispersClient("agent_a", db_path=temp_db)
    receiver = WhispersClient("agent_b", db_path=temp_db)

    sender.registry.register("agent_a", can_send_system=True)
    receiver.set_presence_policy({"reachability": "direct_only"})

    resp = sender.send("agent_b", "hello", priority="system")
    assert resp["status"] in ["queued", "delivered"]
