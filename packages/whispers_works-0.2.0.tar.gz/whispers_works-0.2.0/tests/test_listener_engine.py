import shutil
import time
import uuid
from pathlib import Path
from typing import Any, Dict

import pytest

from whispers.client import WhispersClient
from whispers.listeners.engine import ListenerEngine, WakePolicy


@pytest.fixture
def listener_db_path():
    root = Path(__file__).resolve().parents[1] / ".tmp"
    root.mkdir(parents=True, exist_ok=True)
    case_dir = root / f"listener-engine-{uuid.uuid4().hex}"
    case_dir.mkdir(parents=True, exist_ok=False)
    db_path = str(case_dir / "listener.db")
    yield db_path
    shutil.rmtree(case_dir, ignore_errors=True)


class MockWakePolicy(WakePolicy):
    def __init__(self, should_wake: bool = True):
        self.should_wake = should_wake

    def evaluate(self, message: Dict[str, Any]) -> bool:
        return self.should_wake


class MockSafetyGuardrails:
    def __init__(self, should_block: bool = False):
        self.should_block = should_block

    def verify(self, message: Dict[str, Any]) -> None:
        from whispers.listeners.safety import RateLimitExceeded

        if self.should_block:
            raise RateLimitExceeded("Simulated rate limit violation.")


def test_listener_engine_lifecycle_local(listener_db_path):
    """Test that the engine cleanly starts, dispatches, and stops locally."""
    db_path = listener_db_path

    client = WhispersClient(agent_name="test_sender", server=None, db_path=db_path)
    # Pre-register recipient so the message is queued, not dead-lettered
    client.registry.register("test_engine", agent_type="infrastructure")
    client.send("test_engine", "Test Subject", body="Hello Engine")

    received = []

    def handler(msg):
        received.append(msg)

    engine = ListenerEngine(
        server_url=None,
        agent_name="test_engine",
        token=None,
        handler=handler,
        wake_policy=MockWakePolicy(should_wake=True),
        db_path=db_path,
    )

    engine.start(poll_interval=0.1)

    start_time = time.monotonic()
    while not received and time.monotonic() - start_time < 5.0:
        time.sleep(0.05)

    assert len(received) == 1
    assert received[0]["subject"] == "Test Subject"

    engine.stop(timeout=1.0)
    assert engine.client.session_kind == "local_listener"
    with engine.client.db.get_connection() as conn:
        active = conn.execute(
            "SELECT 1 FROM agent_sessions WHERE agent_name = ?",
            ("test_engine",),
        ).fetchone()
    assert active is None
    assert engine._thread is None or not engine._thread.is_alive()


def test_listener_engine_wake_policy(listener_db_path):
    """Test that messages failing the wake policy are not dispatched."""
    db_path = listener_db_path

    client = WhispersClient(agent_name="test_sender", server=None, db_path=db_path)
    client.send("test_engine", "Should Ignore", body="Hello")

    received = []

    def handler(msg):
        received.append(msg)

    engine = ListenerEngine(
        server_url=None,
        agent_name="test_engine",
        token=None,
        handler=handler,
        wake_policy=MockWakePolicy(should_wake=False),
        db_path=db_path,
    )

    engine.start(poll_interval=0.1)
    time.sleep(0.5)

    assert len(received) == 0
    engine.stop(timeout=1.0)


def test_explicit_local_listener_session_kind_survives_activity(listener_db_path):
    client = WhispersClient(
        agent_name="listener-bot",
        server=None,
        db_path=listener_db_path,
        session_kind="local_listener",
    )

    client.check_inbox(limit=1, mark_seen=True)

    assert client.session_kind == "local_listener"


def test_default_script_client_demotes_to_local_client_on_activity(listener_db_path):
    client = WhispersClient(
        agent_name="script-bot",
        server=None,
        db_path=listener_db_path,
    )

    client.check_inbox(limit=1, mark_seen=True)

    assert client.session_kind == "local_client"


def test_listener_engine_system_kill_switch(listener_db_path):
    """SYSTEM-priority stop messages should kill the listener before handler dispatch."""
    db_path = listener_db_path

    client = WhispersClient(
        agent_name="test_sender",
        agent_type="infrastructure",
        server=None,
        db_path=db_path,
    )
    client.registry.register(
        callsign="test_sender",
        agent_type="infrastructure",
        can_send_system=True,
    )
    # Pre-register recipient so the message is queued, not dead-lettered
    client.registry.register("test_engine", agent_type="infrastructure")
    client.send(
        to="test_engine",
        subject="stop",
        body="halt",
        priority="system",
    )

    received = []

    def handler(msg):
        received.append(msg)

    engine = ListenerEngine(
        server_url=None,
        agent_name="test_engine",
        token=None,
        handler=handler,
        wake_policy=MockWakePolicy(should_wake=True),
        db_path=db_path,
    )

    engine.start(poll_interval=0.1)

    start_time = time.monotonic()
    while not engine._cancel_event.is_set() and time.monotonic() - start_time < 5.0:
        time.sleep(0.05)

    assert len(received) == 0
    assert engine._cancel_event.is_set()
    engine.stop(timeout=2.0)


def test_listener_engine_safety_guardrails(listener_db_path):
    """Messages blocked by guardrails should never reach the handler."""
    db_path = listener_db_path

    client = WhispersClient(agent_name="test_sender", server=None, db_path=db_path)
    client.send("test_engine", "Subject", body="Should be blocked by safety")

    received = []

    def handler(msg):
        received.append(msg)

    engine = ListenerEngine(
        server_url=None,
        agent_name="test_engine",
        token=None,
        handler=handler,
        wake_policy=MockWakePolicy(should_wake=True),
        safety_guardrails=MockSafetyGuardrails(should_block=True),
        db_path=db_path,
    )

    engine.start(poll_interval=0.1)
    time.sleep(0.5)

    assert len(received) == 0
    engine.stop(timeout=1.0)
