"""Tests for operator blindness detection in CollaborationHealthScanner.

Verifies that agents whose operator-visible state is uninformative
get flagged with blind_work, blind_wait, or stale_progress signals.
"""

import pytest

from whispers.collaboration_health import CollaborationHealthScanner, HealthSignal
from whispers.testing import WhispersTestHarness


class TestBlindWork:
    """Agent is busy but operator can't see what's being worked on."""

    def test_busy_with_no_current_task_flagged(self):
        with WhispersTestHarness() as h:
            agent = h.make_client("worker")
            agent.set_readiness("busy", attention_state="working")

            scanner = CollaborationHealthScanner(agent.db)
            signals = scanner.scan()

            blind = [s for s in signals if s.signal == "blind_work"]
            assert len(blind) == 1
            assert blind[0].details["agent"] == "worker"

    def test_busy_with_generic_task_flagged(self):
        with WhispersTestHarness() as h:
            agent = h.make_client("worker")
            agent.set_readiness("busy", current_task="building", attention_state="working")

            scanner = CollaborationHealthScanner(agent.db)
            signals = scanner.scan()

            blind = [s for s in signals if s.signal == "blind_work"]
            assert len(blind) == 1

    def test_busy_with_short_task_flagged(self):
        with WhispersTestHarness() as h:
            agent = h.make_client("worker")
            agent.set_readiness("busy", current_task="stuff", attention_state="working")

            scanner = CollaborationHealthScanner(agent.db)
            signals = scanner.scan()

            blind = [s for s in signals if s.signal == "blind_work"]
            assert len(blind) == 1

    def test_busy_with_concrete_task_not_flagged(self):
        with WhispersTestHarness() as h:
            agent = h.make_client("worker")
            agent.set_readiness("busy", current_task="Protocol safety: self-handoff prevention", attention_state="working")

            scanner = CollaborationHealthScanner(agent.db)
            signals = scanner.scan()

            blind = [s for s in signals if s.signal == "blind_work"]
            assert len(blind) == 0

    def test_ready_agent_not_flagged(self):
        with WhispersTestHarness() as h:
            agent = h.make_client("worker")
            agent.set_readiness("ready")

            scanner = CollaborationHealthScanner(agent.db)
            signals = scanner.scan()

            blind = [s for s in signals if s.signal == "blind_work"]
            assert len(blind) == 0


class TestBlindWait:
    """Agent is waiting but operator can't see what it's waiting on."""

    def test_waiting_on_peer_with_no_detail_flagged(self):
        with WhispersTestHarness() as h:
            agent = h.make_client("worker")
            agent.set_readiness("busy", attention_state="waiting_on_peer", attention_detail="")

            scanner = CollaborationHealthScanner(agent.db)
            signals = scanner.scan()

            blind = [s for s in signals if s.signal == "blind_wait"]
            assert len(blind) == 1
            assert blind[0].details["attention_state"] == "waiting_on_peer"

    def test_waiting_on_operator_with_no_detail_flagged(self):
        with WhispersTestHarness() as h:
            agent = h.make_client("worker")
            agent.set_readiness("busy", attention_state="waiting_on_operator", attention_detail="")

            scanner = CollaborationHealthScanner(agent.db)
            signals = scanner.scan()

            blind = [s for s in signals if s.signal == "blind_wait"]
            assert len(blind) == 1

    def test_waiting_with_detail_not_flagged(self):
        with WhispersTestHarness() as h:
            agent = h.make_client("worker")
            agent.set_readiness(
                "busy",
                attention_state="waiting_on_peer",
                attention_detail="Waiting on codex: review routing for Slice C",
            )

            scanner = CollaborationHealthScanner(agent.db)
            signals = scanner.scan()

            blind = [s for s in signals if s.signal == "blind_wait"]
            assert len(blind) == 0

    def test_blocked_external_with_no_detail_flagged(self):
        with WhispersTestHarness() as h:
            agent = h.make_client("worker")
            agent.set_readiness("blocked", attention_state="blocked_external", attention_detail="")

            scanner = CollaborationHealthScanner(agent.db)
            signals = scanner.scan()

            blind = [s for s in signals if s.signal == "blind_wait"]
            assert len(blind) == 1


class TestEdgeCaseBlindness:
    """Edge cases where agents appear active but operator surface is misleading."""

    def test_wag_building_with_no_task_is_blind(self):
        """Agent set cognitive_state=building via wag() but no current_task."""
        with WhispersTestHarness() as h:
            agent = h.make_client("worker")
            agent.wag("building")
            agent.set_readiness("busy", attention_state="working")

            scanner = CollaborationHealthScanner(agent.db)
            signals = scanner.scan()

            blind = [s for s in signals if s.signal == "blind_work"]
            assert len(blind) == 1

    def test_wag_building_with_concrete_task_is_not_blind(self):
        """Agent set cognitive_state=building AND current_task — properly visible."""
        with WhispersTestHarness() as h:
            agent = h.make_client("worker")
            agent.wag("building", intent="Self-handoff prevention implementation")
            agent.set_readiness("busy", current_task="Self-handoff prevention implementation", attention_state="working")

            scanner = CollaborationHealthScanner(agent.db)
            signals = scanner.scan()

            blind = [s for s in signals if s.signal == "blind_work"]
            assert len(blind) == 0

    def test_multiple_agents_both_blind_both_flagged(self):
        """Two agents with no current_task — both should get flagged independently."""
        with WhispersTestHarness() as h:
            a1 = h.make_client("alice")
            a2 = h.make_client("bob")
            a1.set_readiness("busy", attention_state="working")
            a2.set_readiness("busy", attention_state="working")

            scanner = CollaborationHealthScanner(a1.db)
            signals = scanner.scan()

            blind = [s for s in signals if s.signal == "blind_work"]
            agents = {s.details["agent"] for s in blind}
            assert "alice" in agents
            assert "bob" in agents

    def test_completed_but_still_busy_detected_as_stale(self):
        """Agent finished work but forgot to update readiness — stale detection catches it."""
        with WhispersTestHarness() as h:
            agent = h.make_client("worker")
            agent.set_readiness("busy", current_task="Feature X implementation", attention_state="working")

            # Simulate stale progress by directly manipulating the DB
            import sqlite3
            conn = sqlite3.connect(agent.db_path)
            conn.execute(
                "UPDATE agent_runtime_state SET last_progress_at = datetime('now', '-15 minutes') WHERE agent_name = ?",
                ("worker",),
            )
            conn.commit()
            conn.close()

            scanner = CollaborationHealthScanner(agent.db)
            signals = scanner.scan()

            stale = [s for s in signals if s.signal == "stale_progress"]
            assert len(stale) == 1
            assert stale[0].details["stale_minutes"] >= 14

    def test_busy_with_needs_assignment_is_contradictory_blind(self):
        """Agent says busy + needs_assignment — contradictory state, but not blind_work
        since attention_state is not 'working'."""
        with WhispersTestHarness() as h:
            agent = h.make_client("worker")
            agent.set_readiness("busy", attention_state="needs_assignment")

            scanner = CollaborationHealthScanner(agent.db)
            signals = scanner.scan()

            # This is odd but not blind_work (attention_state != working)
            blind_work = [s for s in signals if s.signal == "blind_work"]
            assert len(blind_work) == 0

    def test_all_fields_proper_no_signals(self):
        """Agent with all fields set properly should produce zero operator blindness signals."""
        with WhispersTestHarness() as h:
            agent = h.make_client("worker")
            agent.wag("building", intent="Implementing feature X")
            agent.set_readiness(
                "busy",
                current_task="Implementing feature X — writing tests",
                attention_state="working",
                attention_detail="Focused on test_dispatcher.py coverage",
            )

            scanner = CollaborationHealthScanner(agent.db)
            signals = scanner.scan()

            operator_signals = [s for s in signals if s.signal in ("blind_work", "blind_wait", "stale_progress")]
            assert len(operator_signals) == 0


class TestSignalDeduplication:
    """Verify operator blindness signals deduplicate correctly."""

    def test_same_agent_same_signal_deduplicates(self):
        with WhispersTestHarness() as h:
            agent = h.make_client("worker")
            agent.set_readiness("busy", attention_state="working")

            scanner = CollaborationHealthScanner(agent.db)
            scan1 = scanner.scan()
            scan2 = scanner.scan()

            blind1 = [s for s in scan1 if s.signal == "blind_work"]
            blind2 = [s for s in scan2 if s.signal == "blind_work"]
            # First scan returns the signal, second scan doesn't (unchanged)
            assert len(blind1) == 1
            assert len(blind2) == 0

    def test_signal_clears_when_task_set(self):
        with WhispersTestHarness() as h:
            agent = h.make_client("worker")
            agent.set_readiness("busy", attention_state="working")

            scanner = CollaborationHealthScanner(agent.db)
            scan1 = scanner.scan()
            assert any(s.signal == "blind_work" for s in scan1)

            # Fix the blindness
            agent.set_readiness("busy", current_task="Protocol safety hardening", attention_state="working")
            scan2 = scanner.scan()
            # Signal should be cleared from active signals
            active = scanner.get_active_signals()
            assert not any(s.signal == "blind_work" for s in active)
