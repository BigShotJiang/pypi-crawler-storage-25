"""Tests for peer reorientation support.

Covers:
- Concern recorded as security event
- Concern includes observer, target, severity
- History retrieval by target
- History retrieval for all agents
- Severity levels respected
"""

import json
import pytest
from whispers.peer_reorientation import raise_reorientation_concern, get_reorientation_history


class TestPeerReorientation:
    @pytest.fixture
    def setup(self, temp_db):
        from whispers.storage.db import WhispersDB
        db = WhispersDB(db_path=temp_db)
        return db

    def test_concern_recorded(self, setup):
        db = setup
        result = raise_reorientation_concern(
            db, "alice", "bob", "Looping on same error for 10 minutes"
        )
        assert result["event_id"]
        assert result["observer"] == "alice"
        assert result["target"] == "bob"
        assert result["severity"] == "advisory"

    def test_concern_with_suggested_action(self, setup):
        db = setup
        result = raise_reorientation_concern(
            db, "alice", "bob",
            "Output quality dropped significantly",
            suggested_action="Consider context refresh",
            severity="concern",
        )
        assert result["suggested_action"] == "Consider context refresh"
        assert result["severity"] == "concern"

    def test_security_event_created(self, setup):
        db = setup
        raise_reorientation_concern(db, "alice", "bob", "Seems stuck")
        with db.get_readonly_connection() as conn:
            events = conn.execute(
                "SELECT * FROM security_events WHERE event_type = 'peer_reorientation'"
            ).fetchall()
        assert len(events) >= 1
        assert events[0]["actor_agent"] == "alice"
        assert events[0]["target_agent"] == "bob"

    def test_history_by_target(self, setup):
        db = setup
        raise_reorientation_concern(db, "alice", "bob", "Concern 1")
        raise_reorientation_concern(db, "charlie", "bob", "Concern 2")
        raise_reorientation_concern(db, "alice", "dave", "Not about bob")

        history = get_reorientation_history(db, target="bob")
        assert len(history) == 2
        targets = {h["target"] for h in history}
        assert targets == {"bob"}

    def test_history_all(self, setup):
        db = setup
        raise_reorientation_concern(db, "alice", "bob", "C1")
        raise_reorientation_concern(db, "alice", "charlie", "C2")

        history = get_reorientation_history(db)
        assert len(history) == 2

    def test_urgent_severity(self, setup):
        db = setup
        result = raise_reorientation_concern(
            db, "alice", "bob", "Hallucinating badly",
            severity="urgent",
        )
        assert result["severity"] == "urgent"
        with db.get_readonly_connection() as conn:
            event = conn.execute(
                "SELECT outcome FROM security_events WHERE event_type = 'peer_reorientation'"
            ).fetchone()
        assert event["outcome"] == "urgent"
