"""Tests for narrator designation and activation rules (Slice 2 of Narrator spec).

Tests runtime settings integration, narrator status derivation,
connection story inclusion, and designation lifecycle.
"""

import pytest

from whispers.connection_story import ConnectionStory


# ---------------------------------------------------------------------------
# ConnectionStory narrator fields
# ---------------------------------------------------------------------------

class TestConnectionStoryNarrator:
    def test_narrator_fields_default(self):
        story = ConnectionStory(agent_name="test")
        assert story.narrator_agent is None
        assert story.narrator_status == "disabled"

    def test_narrator_fields_set(self):
        story = ConnectionStory(
            agent_name="test",
            narrator_agent="claude-code",
            narrator_status="active",
        )
        assert story.narrator_agent == "claude-code"
        assert story.narrator_status == "active"

    def test_narrator_in_to_dict(self):
        story = ConnectionStory(
            agent_name="test",
            narrator_agent="claude-code",
            narrator_status="designated",
        )
        d = story.to_dict()
        assert d["narrator_agent"] == "claude-code"
        assert d["narrator_status"] == "designated"

    def test_narrator_disabled_in_to_dict(self):
        story = ConnectionStory(agent_name="test")
        d = story.to_dict()
        assert d["narrator_agent"] is None
        assert d["narrator_status"] == "disabled"


# ---------------------------------------------------------------------------
# Runtime settings narrator integration (import-safe tests)
# ---------------------------------------------------------------------------

class TestNarratorSettingsShape:
    """Test the narrator settings shape without requiring a running server."""

    def test_narrator_agent_sentinel_default(self):
        """The ... sentinel means 'not provided' in update()."""
        # This tests the design — ... is used as default to distinguish
        # "not provided" from "explicitly set to None (clear)"
        assert ... is not None
        assert ... is not False

    def test_narrator_status_values(self):
        """Verify all valid narrator status values."""
        valid = {"disabled", "designated", "active", "degraded"}
        # These are the only valid states per the spec
        assert len(valid) == 4

    def test_connection_story_narrator_status_validation(self):
        """ConnectionStory accepts all valid narrator_status values."""
        for status in ("disabled", "designated", "active", "degraded"):
            story = ConnectionStory(
                agent_name="test",
                narrator_status=status,
            )
            assert story.narrator_status == status
