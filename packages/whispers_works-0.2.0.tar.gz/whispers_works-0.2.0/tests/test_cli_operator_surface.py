import json

from click.testing import CliRunner

import whispers.cli as cli_module
from whispers.client import WhispersClient


def test_cli_operator_surface_commands(temp_db, monkeypatch):
    monkeypatch.setenv("WHISPERS_DB_PATH", temp_db)

    claude = WhispersClient("claude-code", db_path=temp_db)
    codex = WhispersClient("codex", db_path=temp_db)
    antigravity = WhispersClient("antigravity", db_path=temp_db)

    created = claude.create_workspace(
        purpose="Coordinate workspace and 2ack next-step design",
        name="Layer A follow-up",
        members=["codex", "antigravity"],
    )
    workspace_id = created["workspace_id"]

    claude.join_workspace(workspace_id)
    codex.join_workspace(workspace_id)
    antigravity.join_workspace(workspace_id)

    antigravity.send_workspace_delta(
        workspace_id,
        "note",
        "Surveyed notification models. Push-with-filter scales best.",
    )
    claude.send_handoff(
        "codex",
        objective="Turn the design into a concrete schema packet.",
        deliverable="Implementation-ready notification schema packet",
        completed="Notification model designed. Three-level awareness with push-with-filter delivery.",
        remaining="Draft the schema packet and implementation plan.",
        next_action="Write NOTIFICATION-SCHEMA-PACKET.md following the WS0 schema packet pattern.",
        subject="Notification model ready for execution.",
        human_summary="Handed off notification model design to Codex for execution.",
        workspace_id=workspace_id,
    )

    runner = CliRunner()

    result = runner.invoke(cli_module.cli, ["workspaces", "--json-output"])
    assert result.exit_code == 0
    workspaces = json.loads(result.output)
    assert workspaces[0]["workspace_id"] == workspace_id
    assert workspaces[0]["member_count"] == 3

    result = runner.invoke(cli_module.cli, ["workspace", workspace_id, "--json-output"])
    assert result.exit_code == 0
    state = json.loads(result.output)
    assert state["workspace"]["workspace_id"] == workspace_id
    assert any(member["agent_name"] == "codex" for member in state["members"])
    assert any(delta["delta_kind"] == "handoff_in" for delta in state["deltas"])

    result = runner.invoke(cli_module.cli, ["handoffs", "--workspace-id", workspace_id, "--json-output"])
    assert result.exit_code == 0
    handoffs = json.loads(result.output)
    assert handoffs[0]["workspace_id"] == workspace_id
    assert handoffs[0]["next_action"] == "Write NOTIFICATION-SCHEMA-PACKET.md following the WS0 schema packet pattern."

    result = runner.invoke(cli_module.cli, ["activity", "--workspace-id", workspace_id, "--json-output"])
    assert result.exit_code == 0
    events = json.loads(result.output)
    assert any(event["type"] == "handoff" for event in events)
    assert any(event["delta_kind"] == "lifecycle" for event in events)
