"""Standalone proof for the collaboration runtime milestone.

Runs the canonical three-agent workflow over a real HTTP server:
workspace create -> joins -> parallel deltas -> structured handoff ->
execution update -> close -> operator catch-up checks.

Usage:
    python tests/proof_collaboration_runtime.py
"""
from __future__ import annotations

import json
import os
import secrets
import shutil
import socket
import subprocess
import sys
import time
import urllib.request
from pathlib import Path

from whispers.client import WhispersClient


ROOT = Path(__file__).resolve().parents[1]
ARTIFACT_DIR = ROOT / "tests" / ".artifacts" / "proof_collaboration_runtime"
DB_PATH = ARTIFACT_DIR / "proof_collaboration_runtime.db"
RUNTIME_STATE_PATH = ARTIFACT_DIR / "runtime-state.json"
PROOF_HOME = ARTIFACT_DIR / "home"
PROOF_MCP_TOKEN = secrets.token_urlsafe(24)


def reset_artifacts() -> None:
    if ARTIFACT_DIR.exists():
        shutil.rmtree(ARTIFACT_DIR, ignore_errors=True)
    ARTIFACT_DIR.mkdir(parents=True, exist_ok=True)


def require(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


def proof_env() -> dict[str, str]:
    env = os.environ.copy()
    env["HOME"] = str(PROOF_HOME)
    env["USERPROFILE"] = str(PROOF_HOME)
    env["WHISPERS_DB_PATH"] = str(DB_PATH)
    env["WHISPERS_RUNTIME_STATE_PATH"] = str(RUNTIME_STATE_PATH)
    env["WHISPERS_MCP_TOKEN"] = PROOF_MCP_TOKEN
    env["WHISPERS_REMOTE_ADMISSION_MODE"] = "open"
    return env


def get_mcp_token() -> str:
    token = os.environ.get("WHISPERS_MCP_TOKEN", "").strip()
    if token:
        return token
    env_path = Path.home() / ".whispers" / ".env"
    if env_path.exists():
        for line in env_path.read_text().splitlines():
            line = line.strip()
            if line.startswith("WHISPERS_MCP_TOKEN="):
                return line.split("=", 1)[1].strip().strip('"').strip("'")
    return PROOF_MCP_TOKEN


def find_free_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.bind(("127.0.0.1", 0))
        return int(sock.getsockname()[1])


def wait_for_health(port: int, timeout_seconds: float = 15.0) -> None:
    deadline = time.time() + timeout_seconds
    url = f"http://127.0.0.1:{port}/health"
    while time.time() < deadline:
        try:
            with urllib.request.urlopen(url, timeout=1.0) as resp:
                if resp.status == 200:
                    return
        except Exception:
            time.sleep(0.25)
    raise AssertionError(f"Server on port {port} did not become healthy")


def start_temp_server() -> tuple[subprocess.Popen[bytes], int]:
    port = find_free_port()
    token = get_mcp_token()
    require(bool(token), "No MCP token available for proof run.")

    env = proof_env()
    env["WHISPERS_MCP_TOKEN"] = token
    proc = subprocess.Popen(
        [sys.executable, "-c", f"from whispers.server import start; start(port={port})"],
        cwd=ROOT,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        env=env,
    )
    try:
        wait_for_health(port)
    except Exception:
        proc.terminate()
        raise
    return proc, port


def stop_temp_server(proc: subprocess.Popen[bytes]) -> None:
    if proc.poll() is not None:
        return
    proc.terminate()
    try:
        proc.wait(timeout=5)
    except subprocess.TimeoutExpired:
        proc.kill()
        proc.wait(timeout=5)


def decode_payload(value):
    if isinstance(value, str):
        return json.loads(value)
    return value


def find_workspace_signal(messages, workspace_id: str, *, sequence: int, delta_kind: str):
    for message in messages:
        payload = decode_payload(message.get("payload"))
        if not isinstance(payload, dict) or payload.get("schema") != "workspace_delta.v1":
            continue
        inner = payload.get("payload")
        if not isinstance(inner, dict):
            continue
        if inner.get("workspace_id") != workspace_id:
            continue
        if inner.get("sequence") != sequence:
            continue
        if inner.get("delta_kind") != delta_kind:
            continue
        return message, payload
    raise AssertionError(
        f"No workspace_delta.v1 signal found for {workspace_id} sequence={sequence} delta_kind={delta_kind}."
    )


def main() -> int:
    reset_artifacts()
    proc, port = start_temp_server()
    base = f"http://127.0.0.1:{port}"
    results: dict[str, object] = {"server": base}
    try:
        claude = WhispersClient("claude-code", server=base)
        codex = WhispersClient("codex", server=base)
        antigravity = WhispersClient("antigravity", server=base)
        operator = WhispersClient("whispers-console", server=base)

        created = claude.create_workspace(
            purpose="Design the workspace notification model",
            name="Notification Model Design",
            join_policy="invite",
            members=["codex", "antigravity"],
        )
        workspace_id = created["workspace_id"]
        results["workspace_id"] = workspace_id

        joined_claude = claude.join_workspace(workspace_id)
        joined_codex = codex.join_workspace(workspace_id)
        joined_antigravity = antigravity.join_workspace(workspace_id)
        results["join_sequences"] = [
            joined_claude["sequence"],
            joined_codex["sequence"],
            joined_antigravity["sequence"],
        ]

        # Drain lifecycle fanout before the work phase.
        claude.check_inbox(limit=20, mark_seen=True)
        codex.check_inbox(limit=20, mark_seen=True)
        antigravity.check_inbox(limit=20, mark_seen=True)

        research_one = antigravity.send_workspace_delta(
            workspace_id,
            "note",
            "Surveyed 5 notification models. Push-with-filter scales best for agent environments.",
            artifacts=[".planning/research/notification-models.md"],
        )
        research_two = claude.send_workspace_delta(
            workspace_id,
            "note",
            "Cross-referenced with CSCW awareness framework. Three-level progressive disclosure fits.",
            refs=[".planning/research/academic-coordination-taxonomies.md"],
        )

        claude_inbox = claude.check_inbox(limit=20, mark_seen=False)
        codex_inbox = codex.check_inbox(limit=20, mark_seen=False)
        antigravity_inbox = antigravity.check_inbox(limit=20, mark_seen=False)

        # False-positive guard FP1: these are structured workspace fanout signals,
        # not ordinary messages that happen to mention the workspace.
        signal_to_claude, payload_to_claude = find_workspace_signal(
            claude_inbox,
            workspace_id,
            sequence=research_one["sequence"],
            delta_kind="note",
        )
        signal_to_codex, payload_to_codex = find_workspace_signal(
            codex_inbox,
            workspace_id,
            sequence=research_one["sequence"],
            delta_kind="note",
        )
        signal_to_antigravity, payload_to_antigravity = find_workspace_signal(
            antigravity_inbox,
            workspace_id,
            sequence=research_two["sequence"],
            delta_kind="note",
        )
        require(
            signal_to_claude["metadata"]["whispers:workspace_id"] == workspace_id,
            "Workspace fanout to Claude missing structured workspace metadata.",
        )
        require(
            payload_to_codex["payload"]["workspace_id"] == workspace_id,
            "Workspace fanout to Codex missing payload.workspace_id.",
        )
        require(
            payload_to_antigravity["payload"]["sequence"] == research_two["sequence"],
            "Workspace fanout to Antigravity missing the persisted workspace sequence.",
        )

        claude.check_inbox(limit=20, mark_seen=True)
        codex.check_inbox(limit=20, mark_seen=True)
        antigravity.check_inbox(limit=20, mark_seen=True)

        sent_handoff = claude.send_handoff(
            "codex",
            objective="Design and implement notification model",
            deliverable="NOTIFICATION-SCHEMA-PACKET.md",
            completed="Notification model designed. Three-level awareness with push-with-filter delivery.",
            remaining="Turn the design into a concrete schema packet and runtime implementation plan.",
            next_action="Write NOTIFICATION-SCHEMA-PACKET.md following the WS0 schema packet pattern.",
            assumptions=[
                "Push-with-filter chosen over pure broadcast",
                "Cognitive load modulates delivery intensity",
            ],
            artifacts=[".planning/research/notification-models.md"],
            workspace_id=workspace_id,
            human_summary="Handed off notification model design to Codex for execution.",
            trace_id="proof-collaboration-runtime",
        )

        handoffs = operator.list_handoffs(limit=10, workspace_id=workspace_id)
        require(handoffs, "Operator handoff view is empty.")
        handoff = handoffs[0]

        # False-positive guard FP2: handoff must be structured, not just text.
        require(handoff.get("schema") == "handoff_baton.v1", "Handoff view did not preserve the structured schema.")
        require(bool(handoff.get("completed")), "Handoff view missing completed field.")
        require(bool(handoff.get("remaining")), "Handoff view missing remaining field.")
        require(bool(handoff.get("next_action")), "Handoff view missing next_action field.")
        require(handoff.get("uuid") == sent_handoff["id"], "Handoff view uuid does not match the sent handoff.")
        require(bool(handoff.get("message_id")), "Handoff view is missing the structured inner message_id.")

        execution = codex.send_workspace_delta(
            workspace_id,
            "update",
            "Schema packet drafted. Three schemas: notify_subscribe, notify_deliver, notify_ack.",
            artifacts=[".planning/NOTIFICATION-SCHEMA-PACKET.md"],
        )
        closed = claude.close_workspace(workspace_id, reason="Design complete. Notification model ready for implementation.")

        workspaces = operator.list_workspaces(status="closed")
        state_full = operator.workspace_state(workspace_id, since_sequence=0)
        state_catchup = operator.workspace_state(workspace_id, since_sequence=4)
        activity = operator.list_activity(limit=20, workspace_id=workspace_id)

        # False-positive guard FP3: operator views must be structured payloads.
        require(workspaces and isinstance(workspaces[0], dict), "Operator workspaces view did not return structured records.")
        require(workspaces[0]["workspace_id"] == workspace_id, "Operator workspace view lost workspace identity.")
        require(workspaces[0]["member_count"] == 3, "Operator workspace view reported the wrong member count.")
        require(state_full["workspace"]["status"] == "closed", "Operator workspace state did not reflect close.")

        actor_set = {delta["actor"] for delta in state_full["deltas"] if delta.get("actor")}
        # False-positive guard FP4: three distinct agents must have participated.
        require(
            {"claude-code", "codex", "antigravity"}.issubset(actor_set),
            f"Canonical workflow did not include all three agents in the workspace stream: {sorted(actor_set)}",
        )
        # False-positive guard FP5: since_sequence must narrow the catch-up window.
        require(
            len(state_catchup["deltas"]) < len(state_full["deltas"]),
            "since_sequence did not reduce the delta set for reconnecting agents.",
        )

        results["full_sequence"] = state_full["workspace"]["last_sequence"]
        results["catchup_returned"] = len(state_catchup["deltas"])
        results["activity_types"] = [event.get("type") for event in activity]
        results["actors"] = sorted(actor_set)
        results["execution_sequence"] = execution["sequence"]
        results["close_sequence"] = closed["sequence"]
        results["checks"] = {
            "workspace_fanout_structured": True,
            "handoff_structured": True,
            "operator_views_structured": True,
            "three_agent_participation": True,
            "reconnection_since_sequence": True,
        }

        print(json.dumps({"overall": "PASS", **results}, indent=2))
        return 0
    except AssertionError as exc:
        print(json.dumps({"overall": "FAIL", **results, "error": str(exc)}, indent=2))
        return 1
    finally:
        stop_temp_server(proc)


if __name__ == "__main__":
    raise SystemExit(main())
