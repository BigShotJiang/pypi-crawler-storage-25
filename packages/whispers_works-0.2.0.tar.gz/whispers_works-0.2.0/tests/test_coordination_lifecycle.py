"""Tests for coordination runtime request-lifecycle features.

Covers:
- Slice A: Expanded AcknowledgmentState (accepted/declined/deferred)
- Slice B: Blocking review age computation and formatting
- Slice C: Review verdict on coordination messages
- Slice D: coordination_status column on message_recipients
"""

import time

import pytest

from whispers.coordination_runtime import (
    CoordinationItem,
    _compute_age_seconds,
    _format_age,
    extract_coordination_item,
    format_coordination_item,
    summarize_coordination_state,
)
from whispers.envelope import AcknowledgmentState
from whispers.testing import WhispersTestHarness


# ---------------------------------------------------------------------------
# Slice A: AcknowledgmentState enum expansion
# ---------------------------------------------------------------------------


class TestAcknowledgmentStateEnum:
    """Verify the enum has all expected values."""

    def test_original_values_preserved(self):
        assert AcknowledgmentState.PROCESSED.value == "processed"
        assert AcknowledgmentState.INSUFFICIENT_CONTEXT.value == "insufficient_context"

    def test_new_values_exist(self):
        assert AcknowledgmentState.ACCEPTED.value == "accepted"
        assert AcknowledgmentState.DECLINED.value == "declined"
        assert AcknowledgmentState.DEFERRED.value == "deferred"

    def test_all_values_roundtrip(self):
        for state in AcknowledgmentState:
            assert AcknowledgmentState(state.value) == state


class TestAssignmentAckDerivation:
    """Verify coordination derivation handles new ack states for assignments."""

    def test_accepted_assignment(self):
        with WhispersTestHarness() as h:
            lead = h.make_client("lead")
            worker = h.make_client("worker")

            lead.send_assignment(
                "worker",
                objective="Implement feature X",
                deliverable="feature X",
                requested_action="implement",
            )
            inbox = worker.check_inbox(mark_seen=True)
            assert len(inbox) >= 1
            msg_uuid = inbox[0]["uuid"]

            worker.acknowledge_message(msg_uuid, "accepted")

            # Verify derivation
            item = _extract_assignment_item(lead, "worker")
            assert item is not None
            assert item.ack_state == "accepted"

    def test_declined_assignment(self):
        with WhispersTestHarness() as h:
            lead = h.make_client("lead")
            worker = h.make_client("worker")

            lead.send_assignment(
                "worker",
                objective="Implement feature Y",
                deliverable="feature Y",
                requested_action="implement",
            )
            inbox = worker.check_inbox(mark_seen=True)
            msg_uuid = inbox[0]["uuid"]

            worker.acknowledge_message(msg_uuid, "declined")

            # Declined assignments should NOT appear in pending counts
            state = _get_coordination_summary(lead)
            assert state["pending_assignments"] == 0

    def test_deferred_assignment(self):
        with WhispersTestHarness() as h:
            lead = h.make_client("lead")
            worker = h.make_client("worker")

            lead.send_assignment(
                "worker",
                objective="Implement feature Z",
                deliverable="feature Z",
                requested_action="implement",
            )
            inbox = worker.check_inbox(mark_seen=True)
            msg_uuid = inbox[0]["uuid"]

            worker.acknowledge_message(msg_uuid, "deferred")

            # Deferred assignments should NOT appear in pending counts
            state = _get_coordination_summary(lead)
            assert state["pending_assignments"] == 0


# ---------------------------------------------------------------------------
# Slice B: Blocking review age
# ---------------------------------------------------------------------------


class TestAgeComputation:
    """Verify age computation and formatting helpers."""

    def test_format_age_seconds(self):
        assert _format_age(30) == "30s"

    def test_format_age_minutes(self):
        assert _format_age(120) == "2m"
        assert _format_age(300) == "5m"

    def test_format_age_hours(self):
        assert _format_age(3600) == "1.0h"
        assert _format_age(5400) == "1.5h"

    def test_format_age_days(self):
        assert _format_age(86400) == "1.0d"
        assert _format_age(172800) == "2.0d"

    def test_compute_age_returns_positive(self):
        from datetime import datetime, timezone
        past = (datetime.now(timezone.utc).isoformat())
        age = _compute_age_seconds(past)
        assert age is not None
        assert age >= 0

    def test_compute_age_none_for_missing(self):
        assert _compute_age_seconds(None) is None
        assert _compute_age_seconds("") is None

    def test_coordination_item_age_in_dict(self):
        item = CoordinationItem(
            direction="outgoing",
            kind="review_request",
            message_id="test-123",
            counterpart="reviewer",
            subject="Review my PR",
            blocking=True,
            age_seconds=720.0,
        )
        d = item.to_dict()
        assert d["age_seconds"] == 720.0
        assert d["age_label"] == "12m"

    def test_format_blocking_review_with_age(self):
        item = CoordinationItem(
            direction="incoming",
            kind="review_request",
            message_id="test-456",
            counterpart="peer",
            subject="Review code",
            blocking=True,
            age_seconds=900.0,
        )
        formatted = format_coordination_item(item)
        assert "[blocking" in formatted
        assert "15m waiting" in formatted

    def test_format_outgoing_blocking_with_age(self):
        item = CoordinationItem(
            direction="outgoing",
            kind="review_request",
            message_id="test-789",
            counterpart="reviewer",
            subject="Review code",
            blocking=True,
            age_seconds=3600.0,
        )
        formatted = format_coordination_item(item)
        assert "1.0h waiting" in formatted

    def test_format_outgoing_blocking_review_shows_acknowledged_status(self):
        item = CoordinationItem(
            direction="outgoing",
            kind="review_request",
            message_id="test-790",
            counterpart="reviewer",
            subject="Review code",
            blocking=True,
            coordination_status="acknowledged",
            age_seconds=300.0,
        )
        formatted = format_coordination_item(item)
        assert "[acknowledged]" in formatted
        assert "5m waiting" in formatted

    def test_format_assignment_shows_seen_status_instead_of_active(self):
        item = CoordinationItem(
            direction="incoming",
            kind="assignment",
            message_id="test-791",
            counterpart="lead",
            subject="Implement feature X",
            coordination_status="seen",
        )
        formatted = format_coordination_item(item)
        assert "[seen]" in formatted


# ---------------------------------------------------------------------------
# Slice C: Review verdict on coordination messages
# ---------------------------------------------------------------------------


class TestReviewVerdict:
    """Verify structured verdicts surface in coordination derivation."""

    def test_verdict_approve_in_format(self):
        item = CoordinationItem(
            direction="incoming",
            kind="review_request",
            message_id="test-v1",
            counterpart="reviewer",
            subject="Review my changes",
            blocking=False,
            ack_state="processed",
            ack_detail="approve",
        )
        formatted = format_coordination_item(item)
        assert "[approve]" in formatted

    def test_verdict_reject_in_format(self):
        item = CoordinationItem(
            direction="incoming",
            kind="review_request",
            message_id="test-v2",
            counterpart="reviewer",
            subject="Review my changes",
            blocking=False,
            ack_state="processed",
            ack_detail="reject",
        )
        formatted = format_coordination_item(item)
        assert "[reject]" in formatted

    def test_verdict_request_changes_in_format(self):
        item = CoordinationItem(
            direction="incoming",
            kind="review_request",
            message_id="test-v3",
            counterpart="reviewer",
            subject="Review my changes",
            blocking=False,
            ack_state="processed",
            ack_detail="request_changes",
        )
        formatted = format_coordination_item(item)
        assert "[request changes]" in formatted

    def test_non_verdict_ack_detail_not_shown_as_verdict(self):
        item = CoordinationItem(
            direction="incoming",
            kind="review_request",
            message_id="test-v4",
            counterpart="reviewer",
            subject="Review my changes",
            blocking=False,
            ack_state="processed",
            ack_detail="looks good to me",
        )
        formatted = format_coordination_item(item)
        assert "[acknowledged]" in formatted

    def test_verdict_in_to_dict(self):
        item = CoordinationItem(
            direction="incoming",
            kind="review_request",
            message_id="test-v5",
            counterpart="reviewer",
            subject="Review my changes",
            ack_detail="approve",
        )
        d = item.to_dict()
        assert d.get("ack_detail") == "approve"


# ---------------------------------------------------------------------------
# Slice D: coordination_status column
# ---------------------------------------------------------------------------


class TestCoordinationStatusColumn:
    """Verify coordination_status is set on message_recipients at mutation points."""

    def test_seen_on_inbox_read(self):
        with WhispersTestHarness() as h:
            alice = h.make_client("alice")
            bob = h.make_client("bob")

            alice.send_assignment("bob", objective="Hello", deliverable="stuff", requested_action="do stuff")
            bob.check_inbox(mark_seen=True)

            row = _get_recipient_row(bob, "alice")
            assert row is not None
            assert row["coordination_status"] == "seen"

    def test_acknowledged_on_ack(self):
        with WhispersTestHarness() as h:
            alice = h.make_client("alice")
            bob = h.make_client("bob")

            alice.request_review("bob", artifact="code.py", question="Review this", requested_action="review")
            inbox = bob.check_inbox(mark_seen=True)
            msg_uuid = inbox[0]["uuid"]
            bob.acknowledge_message(msg_uuid, "processed")

            row = _get_recipient_row(bob, "alice")
            assert row is not None
            assert row["coordination_status"] == "acknowledged"

    def test_accepted_on_accept_ack(self):
        with WhispersTestHarness() as h:
            alice = h.make_client("alice")
            bob = h.make_client("bob")

            alice.send_assignment("bob", objective="Do this task", deliverable="task", requested_action="implement")
            inbox = bob.check_inbox(mark_seen=True)
            msg_uuid = inbox[0]["uuid"]
            bob.acknowledge_message(msg_uuid, "accepted")

            row = _get_recipient_row(bob, "alice")
            assert row is not None
            assert row["coordination_status"] == "accepted"

    def test_declined_on_decline_ack(self):
        with WhispersTestHarness() as h:
            alice = h.make_client("alice")
            bob = h.make_client("bob")

            alice.send_assignment("bob", objective="Do this task", deliverable="task", requested_action="implement")
            inbox = bob.check_inbox(mark_seen=True)
            msg_uuid = inbox[0]["uuid"]
            bob.acknowledge_message(msg_uuid, "declined")

            row = _get_recipient_row(bob, "alice")
            assert row is not None
            assert row["coordination_status"] == "declined"

    def test_closed_on_mark_done(self):
        with WhispersTestHarness() as h:
            alice = h.make_client("alice")
            bob = h.make_client("bob")

            alice.send_assignment("bob", objective="Task done?", deliverable="check", requested_action="check")
            inbox = bob.check_inbox(mark_seen=True)
            msg_uuid = inbox[0]["uuid"]
            bob.mark_done(msg_uuid)

            row = _get_recipient_row(bob, "alice")
            assert row is not None
            assert row["coordination_status"] == "closed"

    def test_recently_completed_count(self):
        """Completed coordination items show up in recently_completed count."""
        with WhispersTestHarness() as h:
            alice = h.make_client("alice")
            bob = h.make_client("bob")

            alice.send_assignment("bob", objective="Task 1", deliverable="t1", requested_action="do")
            alice.send_assignment("bob", objective="Task 2", deliverable="t2", requested_action="do")

            inbox = bob.check_inbox(mark_seen=True)
            for msg in inbox:
                bob.mark_done(msg["uuid"])

            status = bob.status()
            coord = status.get("coordination_state", {})
            assert coord.get("recently_completed", 0) >= 2

    def test_completed_items_appear_in_activity_feed(self):
        """Closed coordination items should appear in the activity feed with status 'closed'."""
        with WhispersTestHarness() as h:
            alice = h.make_client("alice")
            bob = h.make_client("bob")

            alice.send_assignment("bob", objective="Task for activity", deliverable="t1", requested_action="do")
            inbox = bob.check_inbox(mark_seen=True)
            bob.mark_done(inbox[0]["uuid"])

            activity = alice.list_activity(kinds=["assignment"])
            completed_events = [
                e for e in activity
                if e.get("coordination_status") == "closed"
            ]
            assert len(completed_events) >= 1

    def test_recently_completed_zero_when_nothing_done(self):
        """No completed items means recently_completed is 0."""
        with WhispersTestHarness() as h:
            alice = h.make_client("alice")
            bob = h.make_client("bob")

            alice.send_assignment("bob", objective="Task 1", deliverable="t1", requested_action="do")
            bob.check_inbox(mark_seen=True)

            status = bob.status()
            coord = status.get("coordination_state", {})
            assert coord.get("recently_completed", 0) == 0

    def test_seen_does_not_overwrite_higher_state(self):
        """COALESCE ensures seen doesn't overwrite acknowledged."""
        with WhispersTestHarness() as h:
            alice = h.make_client("alice")
            bob = h.make_client("bob")

            alice.request_review("bob", artifact="code.py", question="Review this", requested_action="review")
            inbox = bob.check_inbox(mark_seen=True)
            msg_uuid = inbox[0]["uuid"]
            bob.acknowledge_message(msg_uuid, "processed")

            # Read inbox again — should NOT overwrite "acknowledged" with "seen"
            bob.check_inbox(mark_seen=True)

            row = _get_recipient_row(bob, "alice")
            assert row["coordination_status"] == "acknowledged"


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _extract_assignment_item(sender_client, recipient_name):
    """Extract the first coordination recipient row from the database."""
    import sqlite3
    conn = sqlite3.connect(sender_client.db_path)
    conn.row_factory = sqlite3.Row
    try:
        row = conn.execute(
            """
            SELECT mr.ack_state, mr.ack_detail, mr.coordination_status, m.subject
            FROM message_recipients mr
            JOIN messages m ON m.uuid = mr.message_uuid
            WHERE m.from_agent = ? AND mr.recipient_callsign = ?
            ORDER BY mr.created_at DESC LIMIT 1
            """,
            (sender_client.agent_name, recipient_name),
        ).fetchone()
        if not row:
            return None
        return CoordinationItem(
            direction="outgoing",
            kind="assignment",
            message_id="db-lookup",
            counterpart=recipient_name,
            subject=row["subject"] or "",
            ack_state=row["ack_state"],
            ack_detail=row["ack_detail"],
        )
    finally:
        conn.close()


def _get_coordination_summary(client):
    """Get summarized coordination state from status."""
    status = client.status()
    return status.get("coordination_state", {})


def _get_recipient_row(recipient_client, sender_name):
    """Get the message_recipients row directly from the database."""
    import sqlite3
    conn = sqlite3.connect(recipient_client.db_path)
    conn.row_factory = sqlite3.Row
    try:
        row = conn.execute(
            """
            SELECT mr.* FROM message_recipients mr
            JOIN messages m ON m.uuid = mr.message_uuid
            WHERE m.from_agent = ? AND mr.recipient_callsign = ?
            ORDER BY mr.created_at DESC LIMIT 1
            """,
            (sender_name, recipient_client.agent_name),
        ).fetchone()
        return dict(row) if row else None
    finally:
        conn.close()
