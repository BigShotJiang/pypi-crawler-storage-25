import pytest
from whispers.storage.db import WhispersDB, WhispersDBError
from whispers.client import WhispersClient
from whispers.workspaces import WorkspaceManager

def test_proof_ws0_canonical_workflow(temp_db):
    """
    Simulates the canonical three-agent workflow defined in NEXT-PROOF-MILESTONE.md.
    """
    db = WhispersDB(temp_db)
    manager = WorkspaceManager(db)

    # Setup agents
    # Step 1: Claude creates a workspace
    ws_id = manager.create_workspace(
        purpose="Design the workspace notification model",
        join_policy="invite",
        created_by="claude-code"
    )

    # Creator is auto-joined at sequence 1. Other agents join explicitly.
    seq_codex = manager.join_workspace(ws_id, "codex")
    seq_antigravity = manager.join_workspace(ws_id, "antigravity")

    assert seq_codex == 2
    assert seq_antigravity == 3

    # Check state after joins
    state1 = manager.get_state(ws_id)
    assert state1["workspace"]["status"] == "active"
    assert len(state1["members"]) == 3
    assert len(state1["deltas"]) == 3  # three 'lifecycle' joins (creator auto + 2 explicit)

    # Step 2: Parallel Research Phase (antigravity and claude post notes)
    manager.post_delta(
        ws_id,
        delta_kind="note",
        actor="antigravity",
        text="Surveyed 5 notification models. Push-with-filter scales best.",
        artifacts=[".planning/research/notification-models.md"]
    )
    
    manager.post_delta(
        ws_id,
        delta_kind="note",
        actor="claude-code",
        text="Cross-referenced with CSCW awareness framework. Three-level model fits.",
        refs=[".planning/research/academic-coordination-taxonomies.md"]
    )

    # Step 3/4: Execution + Workspace Update (Handoff Projection)
    from whispers.envelope import Envelope, MsgType, Priority
    from datetime import datetime, timezone
    
    handoff_env = Envelope(
        sender="codex",
        recipient="antigravity",
        subject="Schema ready",
        msg_type=MsgType("handoff_baton.v1"),
        priority=Priority("routine"),
        payload={
            "objective": "Define notification models",
            "deliverable": "Schema definitions",
            "completed": "Schema packet drafted. Three schemas: notify_subscribe, notify_deliver, notify_ack.",
            "next_action": "Build endpoints",
            "artifacts": [".planning/NOTIFICATION-SCHEMA-PACKET.md"],
            "workspace_id": ws_id
        },
        created_at=datetime.now(timezone.utc)
    )
    db.store_message(handoff_env, allowed_recipients=["antigravity"])    # Step 5: Workspace Close
    manager.close_workspace(ws_id, actor="claude-code", reason="Design complete.")
    
    # Verify final state
    final_state = manager.get_state(ws_id)
    assert final_state["workspace"]["status"] == "closed"
    
    # 3 joins + 3 notes/updates + 1 close = 7 deltas
    deltas = final_state["deltas"]
    assert len(deltas) == 7
    assert deltas[0]["delta_kind"] == "lifecycle"  # claude join
    assert deltas[-1]["delta_kind"] == "lifecycle" # claude close

    # Verify since_sequence semantics
    # Fetch only the notes and the close operations (deltas after the joins)
    catchup_state = manager.get_state(ws_id, since_sequence=3)
    assert len(catchup_state["deltas"]) == 4
    assert catchup_state["deltas"][0]["delta_kind"] == "note"
    assert catchup_state["deltas"][0]["actor"] == "antigravity"

def test_list_workspaces(temp_db):
    db = WhispersDB(temp_db)
    manager = WorkspaceManager(db)
    
    manager.create_workspace(purpose="test 1", created_by="cli")
    manager.create_workspace(purpose="test 2", created_by="cli")
    ws3 = manager.create_workspace(purpose="test 3", created_by="cli")
    
    manager.close_workspace(ws3, actor="cli")
    
    active = manager.list_workspaces(status="active")
    assert len(active) == 2
    
    closed = manager.list_workspaces(status="closed")
    assert len(closed) == 1


def test_operator_views_surface_workspace_handoff_and_activity(temp_db):
    claude = WhispersClient("claude-code", db_path=temp_db)
    codex = WhispersClient("codex", db_path=temp_db)
    antigravity = WhispersClient("antigravity", db_path=temp_db)
    operator = WhispersClient("whispers-console", db_path=temp_db)

    created = claude.create_workspace(
        purpose="Design the workspace notification model",
        name="Notification model",
        join_policy="invite",
        members=["codex", "antigravity"],
    )
    workspace_id = created["workspace_id"]

    # Creator (claude) auto-joined
    codex.join_workspace(workspace_id)
    antigravity.join_workspace(workspace_id)
    antigravity.send_workspace_delta(
        workspace_id,
        "note",
        "Surveyed 5 notification models. Push-with-filter scales best.",
        artifacts=[".planning/research/notification-models.md"],
    )
    claude.send_handoff(
        "codex",
        objective="Design and implement notification model",
        deliverable="NOTIFICATION-SCHEMA-PACKET.md",
        completed="Notification model designed. Three-level awareness with push-with-filter delivery.",
        remaining="Turn the design into a concrete schema packet and runtime implementation plan.",
        next_action="Write NOTIFICATION-SCHEMA-PACKET.md following the WS0 schema packet pattern.",
        workspace_id=workspace_id,
        human_summary="Handed off notification model design to Codex for execution.",
        trace_id="coordination-pass-12",
    )
    codex.send_workspace_delta(
        workspace_id,
        "update",
        "Schema packet drafted. Three schemas: notify_subscribe, notify_deliver, notify_ack.",
        refs=[".planning/NOTIFICATION-SCHEMA-PACKET.md"],
    )
    claude.close_workspace(workspace_id, reason="Design complete.")

    workspaces = operator.list_workspaces(status="closed")
    state = operator.workspace_state(workspace_id, since_sequence=0)
    handoffs = operator.list_handoffs(limit=10, workspace_id=workspace_id)
    activity = operator.list_activity(limit=20, workspace_id=workspace_id)

    assert workspaces[0]["workspace_id"] == workspace_id
    assert workspaces[0]["member_count"] == 3
    assert handoffs[0]["workspace_id"] == workspace_id
    assert handoffs[0]["next_action"] == "Write NOTIFICATION-SCHEMA-PACKET.md following the WS0 schema packet pattern."
    assert state["workspace"]["status"] == "closed"
    assert any(delta["delta_kind"] == "handoff_in" for delta in state["deltas"])
    assert any(event["type"] == "handoff" for event in activity)
    assert any(event["delta_kind"] == "lifecycle" for event in activity)


def test_t8_canonical_three_agent_workflow_with_guards(temp_db):
    """
    T8: The canonical proof milestone test from PROOF-MILESTONE-DEMO-CONTRACT.md.
    Exercises the full 6-act scenario with 5 false-positive guards.
    """
    claude = WhispersClient("claude-code", db_path=temp_db)
    codex = WhispersClient("codex", db_path=temp_db)
    antigravity = WhispersClient("antigravity", db_path=temp_db)
    operator = WhispersClient("whispers-console", db_path=temp_db)

    # === Act 1: Workspace Creation ===
    created = claude.create_workspace(
        purpose="Design the workspace notification model",
        name="Notification Model Design",
        join_policy="invite",
        members=["codex", "antigravity"],
    )
    workspace_id = created["workspace_id"]
    assert created["workspace"]["status"] == "active"
    # Creator auto-joined
    assert any(m["agent_name"] == "claude-code" for m in created["members"])

    codex.join_workspace(workspace_id)
    antigravity.join_workspace(workspace_id)

    # === Act 2: Parallel Research ===
    delta_ag = antigravity.send_workspace_delta(
        workspace_id,
        "note",
        "Surveyed 5 notification models. Push-with-filter scales best.",
        artifacts=[".planning/research/notification-models.md"],
    )
    delta_cl = claude.send_workspace_delta(
        workspace_id,
        "note",
        "Cross-referenced with CSCW awareness framework. Three-level model fits.",
        refs=[".planning/research/academic-coordination-taxonomies.md"],
    )

    # === Act 3: Structured Handoff ===
    claude.send_handoff(
        "codex",
        objective="Design and implement notification model",
        deliverable="NOTIFICATION-SCHEMA-PACKET.md",
        completed="Notification model designed. Three-level awareness with push-with-filter delivery.",
        remaining="Turn the design into a concrete schema packet and runtime implementation plan.",
        next_action="Write NOTIFICATION-SCHEMA-PACKET.md following the WS0 schema packet pattern.",
        assumptions=["Push-with-filter chosen over pure broadcast"],
        artifacts=[".planning/research/notification-models.md"],
        workspace_id=workspace_id,
        human_summary="Handed off notification model design to Codex for execution.",
        trace_id="proof-milestone-demo",
    )

    # === Act 4: Execution ===
    delta_exec = codex.send_workspace_delta(
        workspace_id,
        "update",
        "Schema packet drafted. Three schemas: notify_subscribe, notify_deliver, notify_ack.",
        artifacts=[".planning/NOTIFICATION-SCHEMA-PACKET.md"],
    )

    # === Act 5: Close ===
    claude.close_workspace(workspace_id, reason="Design complete. Notification model ready for implementation.")

    # === Act 6: Reconnection Proof ===
    # Agent that missed events can catch up
    full_state = operator.workspace_state(workspace_id, since_sequence=0)
    partial_state = operator.workspace_state(workspace_id, since_sequence=5)

    # === Operator Views ===
    workspaces = operator.list_workspaces(status="closed")
    handoffs = operator.list_handoffs(limit=10, workspace_id=workspace_id)
    activity = operator.list_activity(limit=20, workspace_id=workspace_id)

    # === Core Assertions ===
    assert full_state["workspace"]["status"] == "closed"
    assert len(full_state["members"]) == 3
    assert workspaces[0]["workspace_id"] == workspace_id
    assert len(handoffs) >= 1
    assert handoffs[0]["next_action"] == "Write NOTIFICATION-SCHEMA-PACKET.md following the WS0 schema packet pattern."

    # === FALSE-POSITIVE GUARD 1: Workspace deltas go through workspace fanout ===
    # Deltas must have workspace_id in their signal payload, not just be regular messages
    workspace_deltas = [d for d in full_state["deltas"] if d["delta_kind"] in ("note", "update")]
    assert len(workspace_deltas) >= 3  # 2 research notes + 1 execution update
    # The workspace state query returns deltas from workspace_events table,
    # not from the regular message inbox — this IS workspace fanout.

    # === FALSE-POSITIVE GUARD 2: Handoff has structured fields ===
    handoff = handoffs[0]
    assert handoff.get("completed") is not None, "Handoff must have 'completed' field"
    assert handoff.get("remaining") is not None, "Handoff must have 'remaining' field"
    assert handoff.get("next_action") is not None, "Handoff must have 'next_action' field"
    assert handoff.get("objective") is not None, "Handoff must have 'objective' field"
    assert handoff.get("deliverable") is not None, "Handoff must have 'deliverable' field"

    # === FALSE-POSITIVE GUARD 3: Operator views return structured data ===
    assert isinstance(workspaces, list), "Workspaces must be a list"
    assert "workspace_id" in workspaces[0], "Workspace must have workspace_id"
    assert "member_count" in workspaces[0], "Workspace must have member_count"
    assert isinstance(activity, list), "Activity must be a list"
    assert "type" in activity[0], "Activity events must have type field"

    # === FALSE-POSITIVE GUARD 4: Three agents participated concurrently ===
    actors_in_deltas = set()
    for delta in full_state["deltas"]:
        if delta["delta_kind"] != "lifecycle":
            actors_in_deltas.add(delta["actor"])
    assert len(actors_in_deltas) >= 3, (
        f"Three distinct agents must contribute work deltas, got {actors_in_deltas}"
    )

    # === FALSE-POSITIVE GUARD 5: Reconnection via since_sequence ===
    assert len(partial_state["deltas"]) < len(full_state["deltas"]), (
        "since_sequence must return fewer deltas than full state"
    )
    # Both queries return the same workspace metadata
    assert partial_state["workspace"]["workspace_id"] == full_state["workspace"]["workspace_id"]
    assert partial_state["workspace"]["last_sequence"] == full_state["workspace"]["last_sequence"]

    # === Handoff appears in workspace stream ===
    handoff_deltas = [d for d in full_state["deltas"] if d["delta_kind"] == "handoff_in"]
    assert len(handoff_deltas) >= 1, "Handoff must project into workspace event stream"

    # === Activity feed has handoff event ===
    assert any(e["type"] == "handoff" for e in activity), "Activity feed must include handoff events"

    # === Lifecycle events present ===
    lifecycle_deltas = [d for d in full_state["deltas"] if d["delta_kind"] == "lifecycle"]
    assert len(lifecycle_deltas) >= 4, "At least 4 lifecycle events (3 joins + 1 close)"


def test_observer_cannot_post_delta(temp_db):
    """Observers can join a workspace but cannot post deltas (read-only)."""
    db = WhispersDB(temp_db)
    manager = WorkspaceManager(db)

    ws_id = manager.create_workspace(purpose="Observer guard test", created_by="claude-code")
    # Creator auto-joined as member. Add an observer.
    manager.join_workspace(ws_id, "watcher", membership_role="observer")

    # Member can post
    seq = manager.post_delta(ws_id, "note", "claude-code", text="Member note")
    assert seq > 0

    # Observer cannot post
    with pytest.raises(WhispersDBError, match="observer"):
        manager.post_delta(ws_id, "note", "watcher", text="Should fail")


def test_non_member_cannot_post_delta(temp_db):
    """An agent that hasn't joined cannot post deltas."""
    db = WhispersDB(temp_db)
    manager = WorkspaceManager(db)

    ws_id = manager.create_workspace(purpose="Membership guard test", created_by="claude-code")
    # Creator auto-joined. Outsider has not joined.

    with pytest.raises(WhispersDBError, match="not an active member"):
        manager.post_delta(ws_id, "note", "outsider", text="Should fail")


# --- Proof Milestone Acceptance Gap Closure ---
# These tests close specific gaps identified by auditing the spec
# (PROOF-MILESTONE-OPERATOR-SURFACE.md) against test coverage.


def test_handoff_acknowledgment_fields_surface_in_operator_view(temp_db):
    """Handoff list must expose ack_state and acked_at fields per spec View 3.

    The spec defines acknowledged/ack_at in the response shape. The operator
    must see whether a handoff was picked up and when.
    """
    claude = WhispersClient("claude-code", db_path=temp_db)
    codex = WhispersClient("codex", db_path=temp_db)
    operator = WhispersClient("whispers-console", db_path=temp_db)

    handoff_result = claude.send_handoff(
        "codex",
        objective="Lock down startup regression",
        deliverable="Regression test committed",
        completed="Diagnosed root cause of stdio MCP server kill cycle.",
        remaining="Write and commit regression test.",
        next_action="Write test_stdio_mcp_client_cannot_kill_http_server",
        human_summary="Startup regression lock-down assignment.",
    )

    # Before ack: handoff should show no ack_state
    handoffs_before = operator.list_handoffs(limit=10)
    assert len(handoffs_before) >= 1
    unacked = handoffs_before[0]
    assert unacked.get("ack_state") is None or unacked.get("ack_state") == "", (
        f"Unacknowledged handoff should have no ack_state, got: {unacked.get('ack_state')}"
    )

    # Codex acknowledges
    codex.acknowledge_message(handoff_result["id"], "processed", detail="Starting now")

    # After ack: handoff should show ack_state and acked_at
    handoffs_after = operator.list_handoffs(limit=10)
    acked = handoffs_after[0]
    assert acked["ack_state"] == "processed", f"Expected ack_state='processed', got: {acked.get('ack_state')}"
    assert acked.get("acked_at") is not None, "Acknowledged handoff must have acked_at timestamp"
    assert acked.get("acked_by") == "codex", f"Expected acked_by='codex', got: {acked.get('acked_by')}"


def test_workspace_list_includes_last_activity_timestamp(temp_db):
    """Workspace list must include last_activity_at for staleness detection per spec View 1.

    The spec requires: 'A workspace with no activity for 30+ minutes is visually
    distinguishable from an active one (stale indicator or timestamp is enough).'
    The timestamp is the mechanism.
    """
    claude = WhispersClient("claude-code", db_path=temp_db)
    operator = WhispersClient("whispers-console", db_path=temp_db)

    created = claude.create_workspace(
        purpose="Staleness indicator test",
        name="Stale test workspace",
    )
    workspace_id = created["workspace_id"]

    # Post a delta to create activity
    claude.send_workspace_delta(workspace_id, "note", "Activity for timestamp check")

    workspaces = operator.list_workspaces(status="active")
    ws = next(w for w in workspaces if w["workspace_id"] == workspace_id)

    # last_activity_at must be present and non-null — this is the staleness indicator
    assert ws.get("last_activity_at") is not None, (
        "Workspace must expose last_activity_at for staleness detection. "
        "Spec: 'workspace with no activity for 30+ min is visually distinguishable'."
    )


def test_activity_feed_filters_by_agent(temp_db):
    """Activity feed agent filter returns only events from the specified actor per spec View 4.

    The spec API surface includes an 'agent' query parameter. This test verifies
    it actually filters results.
    """
    claude = WhispersClient("claude-code", db_path=temp_db)
    codex = WhispersClient("codex", db_path=temp_db)
    operator = WhispersClient("whispers-console", db_path=temp_db)

    created = claude.create_workspace(
        purpose="Agent filter test",
        name="Agent filter workspace",
        members=["codex"],
    )
    workspace_id = created["workspace_id"]
    codex.join_workspace(workspace_id)

    # Both agents post deltas
    claude.send_workspace_delta(workspace_id, "note", "Claude's finding")
    codex.send_workspace_delta(workspace_id, "update", "Codex's progress")

    # Unfiltered: should see events from both agents
    all_events = operator.list_activity(workspace_id=workspace_id)
    actors = {e.get("actor") for e in all_events if e.get("delta_kind") not in ("lifecycle",)}
    assert "claude-code" in actors, "Unfiltered activity should include claude-code"
    assert "codex" in actors, "Unfiltered activity should include codex"

    # Filtered: only codex events
    codex_events = operator.list_activity(workspace_id=workspace_id, agent="codex")
    codex_actors = {e.get("actor") for e in codex_events}
    assert "codex" in codex_actors, "Codex-filtered activity should include codex"
    assert "claude-code" not in codex_actors, (
        "Codex-filtered activity should NOT include claude-code events"
    )


def test_handoff_mcp_tool_output_is_human_readable(temp_db, monkeypatch):
    """Handoff and activity MCP tool output must be human-readable, not raw JSON blobs.

    The spec explicitly states deltas must be 'human-readable (summary field or
    delta_kind + text, not raw JSON blobs)'.
    """
    import asyncio
    import whispers.mcp_server as mcp_module
    monkeypatch.setenv("WHISPERS_DB_PATH", temp_db)

    claude = WhispersClient("claude-code", db_path=temp_db)
    codex = WhispersClient("codex", db_path=temp_db)

    created = claude.create_workspace(
        purpose="Readability test",
        name="Human readable workspace",
        members=["codex"],
    )
    workspace_id = created["workspace_id"]
    codex.join_workspace(workspace_id)
    claude.send_workspace_delta(workspace_id, "note", "This should be readable text")
    claude.send_handoff(
        "codex",
        objective="Test readability",
        deliverable="Human-readable MCP output",
        completed="Workspace and delta created.",
        remaining="Verify output formatting.",
        next_action="Verify output is not JSON blobs",
        workspace_id=workspace_id,
        human_summary="Readability test handoff.",
    )

    mcp_module._clients.clear()
    token = mcp_module.current_agent_name.set("whispers-console")
    try:
        handoff_out = asyncio.run(mcp_module.handle_tool("handoffs", {"workspace_id": workspace_id}))
        activity_out = asyncio.run(mcp_module.handle_tool("activity", {"workspace_id": workspace_id}))
        state_out = asyncio.run(mcp_module.handle_tool("workspace_state", {"workspace_id": workspace_id}))
    finally:
        mcp_module.current_agent_name.reset(token)
        mcp_module._clients.clear()

    handoff_text = handoff_out[0].text
    activity_text = activity_out[0].text
    state_text = state_out[0].text

    # Output must NOT be raw JSON — but timestamps in brackets like [2026-03-26...] are fine
    import json as _json
    for label, text in [("handoffs", handoff_text), ("activity", activity_text), ("workspace_state", state_text)]:
        try:
            _json.loads(text.strip())
            raise AssertionError(
                f"{label} output is valid JSON — looks like a raw dump. "
                "Spec requires human-readable format, not parseable JSON."
            )
        except _json.JSONDecodeError:
            pass  # Good — not parseable as JSON means it's formatted for humans

    # Handoff output should contain readable fields
    assert "claude-code" in handoff_text, "Handoff output should show sender name"
    assert "codex" in handoff_text, "Handoff output should show receiver name"
    assert "Verify output is not JSON blobs" in handoff_text, (
        "Handoff output should show next_action in readable form"
    )

    # Activity output should have timestamps and actors, not just data
    assert "claude-code" in activity_text or "codex" in activity_text, (
        "Activity output should show actor names"
    )

    # Workspace state should show membership and deltas readably
    assert "member" in state_text, "Workspace state should show membership info"
    assert "This should be readable text" in state_text, (
        "Workspace state should show delta text content"
    )
