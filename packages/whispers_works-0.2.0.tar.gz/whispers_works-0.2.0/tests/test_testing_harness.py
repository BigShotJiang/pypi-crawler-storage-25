"""Tests for the Whispers test harness (whispers.testing)."""

import os
import pytest
from whispers.testing import WhispersTestClient, WhispersTestHarness


class TestWhispersTestClient:
    """WhispersTestClient: single-agent, auto-cleanup."""

    def test_context_manager_creates_and_cleans_db(self):
        with WhispersTestClient("agent-a") as client:
            db_path = client._test_db_path
            assert os.path.exists(db_path)
            status = client.status()
            assert status["healthy"] is True
        # DB directory should be gone after exit
        assert not os.path.exists(os.path.dirname(db_path))

    def test_send_and_inbox(self):
        db = WhispersTestClient.create_temp_db()
        try:
            sender = WhispersTestClient("alice", shared_db_path=db)
            receiver = WhispersTestClient("bob", shared_db_path=db)

            result = sender.send("bob", "Test message")
            assert result["status"] in ("delivered", "queued")

            inbox = receiver.check_inbox()
            assert len(inbox) == 1
            assert inbox[0]["subject"] == "Test message"
        finally:
            WhispersTestClient.cleanup_temp_db(db)

    def test_status_shows_registered_agents(self):
        db = WhispersTestClient.create_temp_db()
        try:
            a = WhispersTestClient("agent-a", shared_db_path=db)
            b = WhispersTestClient("agent-b", shared_db_path=db)

            status = a.status()
            assert status["agents_registered"] == 2
        finally:
            WhispersTestClient.cleanup_temp_db(db)

    def test_modes_work(self):
        with WhispersTestClient("agent-a") as client:
            client.set_mode("focused", allow_senders=["trusted-bot"])
            status = client.status()
            assert status["my_mode"] == "FOCUSED"

    def test_wag_and_heartbeat(self):
        with WhispersTestClient("agent-a") as client:
            client.wag("building", intent="writing tests")
            hb = client.update_cognitive_heartbeat({
                "context_load": 0.3,
                "interruptibility": "free",
                "quality_risk": "low",
            })
            assert hb is not None

    def test_deployment_mode_is_not_mock(self):
        """TestClient should report real deployment info, not 'mock'."""
        with WhispersTestClient("agent-a") as client:
            status = client.status()
            assert status["deployment_mode"] != "mock"


class TestWhispersTestHarness:
    """WhispersTestHarness: multi-agent with shared DB."""

    def test_make_client_creates_agents(self):
        with WhispersTestHarness() as harness:
            alice = harness.make_client("alice")
            bob = harness.make_client("bob")

            status = alice.status()
            assert status["agents_registered"] == 2

    def test_message_exchange(self):
        with WhispersTestHarness() as harness:
            sender = harness.make_client("sender")
            receiver = harness.make_client("receiver")

            sent = sender.send("receiver", "Hello from harness")
            inbox = receiver.check_inbox()

            assert len(inbox) == 1
            assert inbox[0]["subject"] == "Hello from harness"

    def test_outbox_and_trace(self):
        with WhispersTestHarness() as harness:
            a = harness.make_client("agent-a")
            b = harness.make_client("agent-b")

            a.send("agent-b", "First")
            b.send("agent-a", "Reply")

            outbox = a.outbox(limit=10)
            assert len(outbox) == 1
            assert outbox[0]["subject"] == "First"

            trace = a.trace("agent-b", limit=10)
            assert len(trace) == 2

    def test_presence(self):
        with WhispersTestHarness() as harness:
            a = harness.make_client("agent-a")
            b = harness.make_client("agent-b")

            who = a.presence_who()
            # Both agents should be visible
            all_names = [
                ag["agent_name"]
                for ag in who.get("agents", []) + who.get("background_agents", [])
            ]
            assert "agent-a" in all_names or "agent-b" in all_names

    def test_priority_messages(self):
        with WhispersTestHarness() as harness:
            sender = harness.make_client("sender")
            receiver = harness.make_client("receiver")

            sender.send("receiver", "Urgent", priority="flash")
            sender.send("receiver", "Normal", priority="routine")

            status = receiver.status()
            assert status["pending_messages"] == 2
            assert status["pending_by_priority"]["flash"] == 1
            assert status["pending_by_priority"]["routine"] == 1

    def test_cleanup_removes_files(self):
        harness = WhispersTestHarness()
        db_dir = os.path.dirname(harness.db_path)
        harness.make_client("test-agent")
        assert os.path.exists(harness.db_path)

        harness.close()
        assert not os.path.exists(db_dir)

    def test_threaded_replies(self):
        with WhispersTestHarness() as harness:
            a = harness.make_client("alice")
            b = harness.make_client("bob")

            original = a.send("bob", "Original question", body="What's the status?")
            reply = b.send(
                "alice",
                "Re: Original question",
                body="All good.",
                reply_to=original["id"],
            )

            inbox = a.check_inbox()
            assert len(inbox) == 1
            assert inbox[0]["reply_to"] == original["id"]

    def test_acknowledge_message(self):
        with WhispersTestHarness() as harness:
            sender = harness.make_client("sender")
            receiver = harness.make_client("receiver")

            sent = sender.send("receiver", "Process this")
            ack = receiver.acknowledge_message(sent["id"], "processed", detail="done")

            assert ack["ack_state"] == "processed"
            assert ack["ack_detail"] == "done"

            outbox = sender.outbox(limit=10)
            assert outbox[0]["ack_state"] == "processed"
