import random

import pytest

from whispers import client as client_module
from whispers.client import WhispersClient, WhispersException

def test_listen_reconnect_after_transient_failure(monkeypatch, temp_db):
    client = WhispersClient("test-agent", db_path=temp_db)
    client.remote_server = "http://fake"
    
    stream_calls = 0
    
    def fake_stream(**kwargs):
        nonlocal stream_calls
        stream_calls += 1
        if stream_calls == 1:
            yield {"uuid": "1", "body": "msg1"}
            raise WhispersException("Transient server drop")
        elif stream_calls == 2:
            yield {"uuid": "2", "body": "msg2"}
            return
            
    monkeypatch.setattr(client, "listen_stream", fake_stream)
    
    disconnects = []
    restores = []
    
    def on_disconnect(exc, backoff):
        disconnects.append((exc, backoff))
        
    def on_restored():
        restores.append(True)
        
    messages = list(client.listen(
        poll_interval=0.01,
        max_messages=2,
        reconnect_delay=0.01,
        max_reconnect_delay=0.1,
        on_disconnect=on_disconnect,
        on_restored=on_restored
    ))
    
    assert len(messages) == 2
    assert messages[0]["uuid"] == "1"
    assert messages[1]["uuid"] == "2"
    assert stream_calls == 2
    assert len(disconnects) == 1
    assert "Transient server drop" in str(disconnects[0][0])
    assert len(restores) == 1

def test_listen_local_reconnect_after_db_failure(monkeypatch, temp_db):
    client = WhispersClient("test-agent", db_path=temp_db)
    client.read_only = False
    
    calls = 0
    class FakeDB:
        def has_pending_messages(self, agent_name):
            return True

        def deliver_inbox(self, agent_name, limit):
            nonlocal calls
            calls += 1
            if calls == 1:
                return [{"uuid": "3", "body": "local_1"}]
            elif calls == 2:
                raise Exception("Database locked")
            elif calls == 3:
                return [{"uuid": "4", "body": "local_2"}]
            return []
            
    client.db = FakeDB()
    
    # Mock touch/heartbeat/watchdog so they don't break the simple test
    monkeypatch.setattr(client, "_touch_heartbeat", lambda *args, **kwargs: None)
    monkeypatch.setattr(client, "_touch_activity", lambda *args, **kwargs: None)
    monkeypatch.setattr(client, "update_watchdog", lambda *args, **kwargs: None)
    
    disconnects = []
    restores = []
    
    def on_disconnect(exc, backoff):
        disconnects.append((exc, backoff))
        
    def on_restored():
        restores.append(True)
        
    messages = list(client.listen(
        poll_interval=0.01,
        max_messages=2,
        on_disconnect=on_disconnect,
        on_restored=on_restored
    ))
    
    assert len(messages) == 2
    assert messages[0]["uuid"] == "3"
    assert messages[1]["uuid"] == "4"
    assert len(disconnects) == 1
    assert "Database locked" in str(disconnects[0][0])
    assert len(restores) == 1


def test_listen_local_backs_off_when_idle_without_activity_churn(monkeypatch, temp_db):
    client = WhispersClient("test-agent", db_path=temp_db)
    client.read_only = False

    calls = 0
    sleeps = []
    activity_calls = []
    heartbeat_calls = []
    watchdog_calls = []
    now = {"value": 0.0}

    class FakeDB:
        def has_pending_messages(self, agent_name):
            nonlocal calls
            calls += 1
            return calls >= 3
            
        def deliver_inbox(self, agent_name, limit):
            return [{"uuid": "5", "body": "local_backoff"}]

    def fake_sleep(seconds):
        sleeps.append(seconds)
        now["value"] += seconds

    client.db = FakeDB()

    monkeypatch.setattr(client_module.time, "sleep", fake_sleep)
    monkeypatch.setattr(client_module.time, "monotonic", lambda: now["value"])
    monkeypatch.setattr(random, "uniform", lambda a, b: 1.0)
    monkeypatch.setattr(client, "_touch_heartbeat", lambda *args, **kwargs: heartbeat_calls.append(now["value"]))
    monkeypatch.setattr(client, "_touch_activity", lambda *args, **kwargs: activity_calls.append(now["value"]))
    monkeypatch.setattr(client, "update_watchdog", lambda *args, **kwargs: watchdog_calls.append(now["value"]))

    messages = list(client.listen(
        poll_interval=0.5,
        max_messages=1,
        max_reconnect_delay=4.0,
    ))

    assert len(messages) == 1
    assert messages[0]["uuid"] == "5"
    assert sleeps == [0.5, 1.0]
    assert len(heartbeat_calls) == 1
    assert len(activity_calls) == 1
    assert len(watchdog_calls) == 2
