"""Tests for operational metrics.

Validates the minimal first build from CONSOLE-METRICS-PAGE-SPEC.md:
  - 4 numbers: messages today, delivery rate, agents online, active workspaces
  - Hourly throughput buckets
  - Scale-aware: meaningful at 3 agents, doesn't break at 300
"""

import sqlite3
from whispers.client import WhispersClient
from whispers.metrics import compute_summary, compute_hourly_throughput, MetricsSummary


def test_summary_with_no_messages(temp_db):
    """Empty system produces sensible defaults — not errors."""
    client = WhispersClient("operator", db_path=temp_db)
    with client.db.get_readonly_connection() as conn:
        summary = compute_summary(conn, agents_online=0, active_workspaces=0)

    assert summary.messages_today == 0
    assert summary.delivery_success_rate == 1.0  # no failures = 100%
    assert summary.agents_online == 0
    assert summary.active_workspaces == 0
    assert summary.handoffs_today == 0
    assert summary.handoff_ack_rate == 1.0


def test_summary_counts_messages_and_delivery(temp_db):
    """Summary reflects actual message traffic."""
    sender = WhispersClient("claude-code", db_path=temp_db)
    WhispersClient("codex", db_path=temp_db)

    sender.send("codex", "Test message 1", body="Hello")
    sender.send("codex", "Test message 2", body="World")

    with sender.db.get_readonly_connection() as conn:
        summary = compute_summary(conn, agents_online=2, active_workspaces=1)

    assert summary.messages_today == 2
    assert summary.agents_online == 2
    assert summary.active_workspaces == 1
    # Delivery rate should be > 0 (messages were delivered locally)
    assert summary.delivery_success_rate > 0


def test_summary_to_dict_has_all_fields(temp_db):
    """to_dict() includes both raw values and formatted percentages."""
    client = WhispersClient("operator", db_path=temp_db)
    with client.db.get_readonly_connection() as conn:
        summary = compute_summary(conn)

    d = summary.to_dict()
    required = {
        "messages_today", "delivery_success_rate", "delivery_success_pct",
        "agents_online", "active_workspaces", "handoffs_today",
        "handoff_ack_rate", "handoff_ack_pct", "period_start", "period_end",
    }
    assert required.issubset(d.keys()), f"Missing: {required - d.keys()}"
    assert d["delivery_success_pct"].endswith("%")


def test_hourly_throughput_returns_buckets(temp_db):
    """Hourly throughput produces time-bucketed data."""
    sender = WhispersClient("claude-code", db_path=temp_db)
    WhispersClient("codex", db_path=temp_db)

    sender.send("codex", "Throughput test", body="data")

    with sender.db.get_readonly_connection() as conn:
        buckets = compute_hourly_throughput(conn, hours=1)

    assert len(buckets) >= 1
    b = buckets[0]
    assert b.sent >= 1
    d = b.to_dict()
    assert "hour" in d
    assert "sent" in d
    assert "delivered" in d
    assert "failed" in d


def test_hourly_throughput_empty_is_empty(temp_db):
    """No messages = no buckets (not an error)."""
    client = WhispersClient("operator", db_path=temp_db)
    with client.db.get_readonly_connection() as conn:
        buckets = compute_hourly_throughput(conn, hours=1)

    assert buckets == []


def test_summary_counts_handoffs(temp_db):
    """Handoff metrics track handoff_baton.v1 messages specifically."""
    claude = WhispersClient("claude-code", db_path=temp_db)
    codex = WhispersClient("codex", db_path=temp_db)

    # Regular message (not a handoff)
    claude.send("codex", "Regular message")

    # Handoff
    claude.send_handoff(
        "codex",
        objective="Test handoff",
        deliverable="Test result",
        completed="Did some work",
        remaining="More to do",
        next_action="Continue",
        human_summary="Test handoff for metrics",
    )

    with claude.db.get_readonly_connection() as conn:
        summary = compute_summary(conn)

    assert summary.messages_today >= 2
    assert summary.handoffs_today >= 1
