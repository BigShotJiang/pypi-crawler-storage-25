import json
from pathlib import Path

CONFORMANCE_DIR = Path(__file__).resolve().parent / "conformance"
CONFORMANCE_DIR.mkdir(parents=True, exist_ok=True)

def make_fixture(cat, suffix, desc, input_data, valid=True, errors=None, preflight=None):
    if errors is None:
        errors = []
    if preflight is None:
        if cat == "A":
            wire_v = input_data.get("wire_v")
            schema = input_data.get("schema")
            preflight = "reject" if wire_v != 1 or not isinstance(schema, str) or not schema else "accept"
        elif cat == "C" and ("negotiation failure" in desc or "accept_schemas mismatch" in desc):
            preflight = "reject_negotiation"
        elif cat == "D" and ("tier_required not met" in desc or "trust tier insufficient" in desc):
            preflight = "reject_trust"
        else:
            preflight = "accept"

    return {
        "id": f"{cat}-{suffix}",
        "category": cat,
        "description": desc,
        "input": input_data,
        "expected": {
            "valid": valid,
            "error_codes": errors,
            "preflight_decision": preflight
        }
    }

cat_a = []
cat_a.append(make_fixture("A", "valid-minimal", "Valid minimal envelope", {"wire_v": 1, "schema": "status_update.v1", "trace": {"message_id": "msg-min-1"}, "payload": {"state": "idle"}}))
cat_a.append(make_fixture("A", "valid-full", "Valid full envelope", {
    "wire_v": 1, "schema": "status_update.v1", "mode": "bilingual", "signal_class": "whispers_internal",
    "source": "agent", "trace": {"message_id": "msg-full-1", "trace_id": "trace-1", "thread_id": "thread-1"},
    "expires_at": "2026-12-31T23:59:59Z", "max_hops": 3, "trust": {"tier_required": 1, "requires_operator": False},
    "accept_schemas": ["status_update.v1"], "summary": {"headline": "H", "human": "Hum"},
    "ext": {"x-custom:field": "value"}, "received_via": ["router-1", "router-2"], "payload": {"state": "idle"}
}))
cat_a.append(make_fixture("A", "invalid-no-wire", "missing wire_v", {"schema": "status_update.v1", "trace": {"message_id": "msg-bad-1"}, "payload": {"state": "idle"}}, False, ["ERR_MALFORMED_ENVELOPE"]))
cat_a.append(make_fixture("A", "invalid-no-schema", "missing schema", {"wire_v": 1, "trace": {"message_id": "msg-bad-2"}, "payload": {"state": "idle"}}, False, ["ERR_MALFORMED_ENVELOPE"]))
cat_a.append(make_fixture("A", "invalid-no-trace", "missing trace", {"wire_v": 1, "schema": "status_update.v1", "payload": {"state": "idle"}}, False, ["ERR_MALFORMED_ENVELOPE"]))
cat_a.append(make_fixture("A", "invalid-no-msgid", "missing trace.message_id", {"wire_v": 1, "schema": "status_update.v1", "trace": {}, "payload": {"state": "idle"}}, False, ["ERR_MALFORMED_ENVELOPE"]))
cat_a.append(make_fixture("A", "invalid-no-payload", "missing payload", {"wire_v": 1, "schema": "status_update.v1", "trace": {"message_id": "msg-bad-3"}}, False, ["ERR_MALFORMED_ENVELOPE"]))
cat_a.append(make_fixture("A", "invalid-bad-wire", "unsupported wire version", {"wire_v": 2, "schema": "status_update.v1", "trace": {"message_id": "msg-bad-4"}, "payload": {"state": "idle"}}, False, ["ERR_WIRE_VERSION"]))
cat_a.append(make_fixture("A", "invalid-trace-type", "malformed trace object (string)", {"wire_v": 1, "schema": "status_update.v1", "trace": "msg-bad-5", "payload": {"state": "idle"}}, False, ["ERR_MALFORMED_ENVELOPE"]))
cat_a.append(make_fixture("A", "invalid-ext-key", "invalid ext key format", {"wire_v": 1, "schema": "status_update.v1", "trace": {"message_id": "msg-bad-not-namespaced"}, "ext": {"custom_hint": "compact"}, "payload": {"state": "idle"}}, False, ["ERR_MALFORMED_ENVELOPE"]))
cat_a.append(make_fixture("A", "invalid-bad-msgid", "invalid message_id type", {"wire_v": 1, "schema": "status_update.v1", "trace": {"message_id": 123}, "payload": {"state": "idle"}}, False, ["ERR_MALFORMED_ENVELOPE"]))
cat_a.append(make_fixture("A", "summary-human-nonstring", "summary.human non-string currently tolerated", {"wire_v": 1, "schema": "status_update.v1", "trace": {"message_id": "m-1"}, "summary": {"human": []}, "payload": {"state": "idle"}}))
cat_a.append(make_fixture("A", "invalid-bad-mode", "unknown mode string", {"wire_v": 1, "schema": "status_update.v1", "mode": "magic", "trace": {"message_id": "m-1"}, "payload": {"state": "idle"}}, False, ["ERR_MALFORMED_ENVELOPE"]))
cat_a.append(make_fixture("A", "extra-fields", "unknown top level field preserved", {"wire_v": 1, "schema": "status_update.v1", "trace": {"message_id": "m-1"}, "future_optional_field": {"status": "preview"}, "payload": {"state": "idle"}}))


cat_b = []
cat_b.append(make_fixture("B", "valid-status", "Valid status_update.v1", {"wire_v": 1, "schema": "status_update.v1", "trace": {"message_id": "b-1"}, "payload": {"state": "building", "current_task": "task", "readiness": "busy", "working_set": []}}))
cat_b.append(make_fixture("B", "valid-handoff", "Valid handoff_baton.v1", {"wire_v": 1, "schema": "handoff_baton.v1", "trace": {"message_id": "b-2"}, "payload": {"objective": "obj", "deliverable": "del", "next_action": "act"}}))
cat_b.append(make_fixture("B", "valid-dec-req", "Valid decision_request.v1", {"wire_v": 1, "schema": "decision_request.v1", "trace": {"message_id": "b-3"}, "payload": {"question": "q?", "options": ["a", "b"], "priority": "priority"}}))
cat_b.append(make_fixture("B", "valid-dec-resp", "Valid decision_response.v1", {"wire_v": 1, "schema": "decision_response.v1", "trace": {"message_id": "b-4"}, "payload": {"decision": "a", "reply_to": "b-3"}}))
cat_b.append(make_fixture("B", "valid-ext-act", "Valid external_action_request.v1", {"wire_v": 1, "schema": "external_action_request.v1", "trace": {"message_id": "b-5"}, "authority": {"principal": "zack"}, "payload": {"action_class": "deploy", "intent": "int", "target": "prod", "risk_level": "elevated"}}))
cat_b.append(make_fixture("B", "valid-ws-create", "Valid workspace_create.v1", {"wire_v": 1, "schema": "workspace_create.v1", "trace": {"message_id": "b-6"}, "payload": {"purpose": "p", "join_policy": "invite"}}))
cat_b.append(make_fixture("B", "valid-ws-join", "Valid workspace_join.v1", {"wire_v": 1, "schema": "workspace_join.v1", "trace": {"message_id": "b-7"}, "payload": {"workspace_id": "ws-1", "membership_role": "member"}}))
cat_b.append(make_fixture("B", "valid-ws-leave", "Valid workspace_leave.v1", {"wire_v": 1, "schema": "workspace_leave.v1", "trace": {"message_id": "b-8"}, "payload": {"workspace_id": "ws-1"}}))
cat_b.append(make_fixture("B", "valid-ws-close", "Valid workspace_close.v1", {"wire_v": 1, "schema": "workspace_close.v1", "trace": {"message_id": "b-9"}, "payload": {"workspace_id": "ws-1", "reason": "done"}}))
cat_b.append(make_fixture("B", "valid-ws-delta-note", "Valid workspace_delta.v1 note", {"wire_v": 1, "schema": "workspace_delta.v1", "trace": {"message_id": "b-10"}, "payload": {"workspace_id": "ws-1", "delta_kind": "note", "text": "foo"}}))
cat_b.append(make_fixture("B", "valid-ws-delta-handoff_in", "Valid workspace_delta.v1 handoff_in", {"wire_v": 1, "schema": "workspace_delta.v1", "trace": {"message_id": "b-10-handoff"}, "payload": {"workspace_id": "ws-1", "delta_kind": "handoff_in", "related_message_id": "msg"}}))
cat_b.append(make_fixture("B", "valid-ws-state", "Valid workspace_state.v1", {"wire_v": 1, "schema": "workspace_state.v1", "trace": {"message_id": "b-11"}, "payload": {"workspace_id": "ws-1", "workspace": {"workspace_id": "ws", "name": "nm", "purpose": "p", "status": "active", "created_by": "us", "join_policy": "open", "last_sequence": 0, "last_delta_at": "t"}, "members": [], "deltas": []}}))
cat_b.append(make_fixture("B", "valid-err", "Valid protocol_error.v1", {"wire_v": 1, "schema": "protocol_error.v1", "trace": {"message_id": "b-12"}, "payload": {"error_code": "ERR_TRUST_TIER_INSUFFICIENT", "rejected_message_id": "msg", "reason": "rsn"}}))

cat_b.append(make_fixture("B", "invalid-ws-create", "workspace_create missing purpose", {"wire_v": 1, "schema": "workspace_create.v1", "trace": {"message_id": "b-bad-1"}, "payload": {"name": "test"}}, False, ["ERR_SCHEMA_INVALID"]))
cat_b.append(make_fixture("B", "valid-ws-join-default-role", "workspace_join without role is allowed", {"wire_v": 1, "schema": "workspace_join.v1", "trace": {"message_id": "b-bad-2"}, "payload": {"workspace_id": "ws-1"}}))
cat_b.append(make_fixture("B", "invalid-err-missing-code", "protocol_error missing error_code", {"wire_v": 1, "schema": "protocol_error.v1", "trace": {"message_id": "b-bad-3"}, "payload": {"rejected_message_id": "msg", "reason": "rsn"}}, False, ["ERR_SCHEMA_INVALID"]))
cat_b.append(make_fixture("B", "invalid-handoff-missing-obj", "handoff_baton missing objective", {"wire_v": 1, "schema": "handoff_baton.v1", "trace": {"message_id": "b-bad-4"}, "payload": {"deliverable": "doc.md"}}, False, ["ERR_SCHEMA_INVALID"]))
cat_b.append(make_fixture("B", "invalid-dec-req-missing-options", "decision_request missing options", {"wire_v": 1, "schema": "decision_request.v1", "trace": {"message_id": "b-bad-5"}, "payload": {"question": "q?"}}, False, ["ERR_SCHEMA_INVALID"]))
cat_b.append(make_fixture("B", "invalid-dec-resp-missing-decision", "decision_response missing decision", {"wire_v": 1, "schema": "decision_response.v1", "trace": {"message_id": "b-bad-6"}, "payload": {"reply_to": "req-1"}}, False, ["ERR_SCHEMA_INVALID"]))
cat_b.append(make_fixture("B", "valid-baton-ack", "Valid baton_ack.v1", {"wire_v": 1, "schema": "baton_ack.v1", "trace": {"message_id": "b-13"}, "payload": {"baton_ref": "b-2", "decision": "accepted"}}))
cat_b.append(make_fixture("B", "valid-baton-update", "Valid baton_update.v1", {"wire_v": 1, "schema": "baton_update.v1", "trace": {"message_id": "b-14"}, "payload": {"baton_ref": "b-2", "state": "in_progress"}}))
cat_b.append(make_fixture("B", "valid-baton-close", "Valid baton_close.v1", {"wire_v": 1, "schema": "baton_close.v1", "trace": {"message_id": "b-15"}, "payload": {"baton_ref": "b-2", "outcome": "completed"}}))


cat_c = []
cat_c.append(make_fixture("C", "match", "accept_schemas match", {"wire_v": 1, "schema": "status_update.v1", "trace": {"message_id": "c-1"}, "accept_schemas": ["status_update.v1"], "payload": {"state": "idle"}}))
cat_c.append(make_fixture("C", "mismatch", "accept_schemas mismatch", {"wire_v": 1, "schema": "decision_request.v1", "trace": {"message_id": "c-2"}, "accept_schemas": ["status_update.v1"], "payload": {"question": "q", "options": ["a", "b"]}}, True, [], "reject_negotiation"))
cat_c.append(make_fixture("C", "empty", "accept_schemas empty means terminal", {"wire_v": 1, "schema": "status_update.v1", "trace": {"message_id": "c-3"}, "accept_schemas": [], "payload": {"state": "idle"}}))
cat_c.append(make_fixture("C", "absent", "accept_schemas absent means no constraint", {"wire_v": 1, "schema": "status_update.v1", "trace": {"message_id": "c-4"}, "payload": {"state": "idle"}}))
cat_c.append(make_fixture("C", "match-multiple", "accept_schemas match with multiple options", {"wire_v": 1, "schema": "decision_response.v1", "trace": {"message_id": "c-5"}, "accept_schemas": ["status_update.v1", "decision_response.v1"], "payload": {"decision": "d", "reply_to": "req"}}))


cat_d = []
cat_d.append(make_fixture("D", "met", "tier_required met", {"wire_v": 1, "schema": "status_update.v1", "trace": {"message_id": "d-1"}, "trust": {"tier_required": 1}, "payload": {"state": "idle"}}))
cat_d.append(make_fixture("D", "operator-true", "requires_operator true", {"wire_v": 1, "schema": "status_update.v1", "trace": {"message_id": "d-2"}, "trust": {"requires_operator": True}, "payload": {"state": "idle"}}))
cat_d.append(make_fixture("D", "not-met", "tier_required not met", {"wire_v": 1, "schema": "status_update.v1", "trace": {"message_id": "d-3"}, "trust": {"tier_required": 3}, "payload": {"state": "idle"}}, True, [], "reject_trust"))
cat_d.append(make_fixture("D", "implicit-met", "tier_required missing implies tier 0 acceptable", {"wire_v": 1, "schema": "status_update.v1", "trace": {"message_id": "d-4"}, "payload": {"state": "idle"}}))


cat_e = []
cat_e.append(make_fixture("E", "omission-null", "omission semantics - explicitly null summary", {"wire_v": 1, "schema": "status_update.v1", "trace": {"message_id": "e-1"}, "summary": None, "payload": {"state": "idle"}}))
cat_e.append(make_fixture("E", "omission-empty-obj", "omission semantics - empty trust object", {"wire_v": 1, "schema": "status_update.v1", "trace": {"message_id": "e-2"}, "trust": {}, "payload": {"state": "idle"}}))
cat_e.append(make_fixture("E", "omission-empty-arr", "omission semantics - empty accept schemas array", {"wire_v": 1, "schema": "status_update.v1", "trace": {"message_id": "e-3"}, "accept_schemas": [], "payload": {"state": "idle"}}))
cat_e.append(make_fixture("E", "omission-null-obj", "omission semantics - trust is null", {"wire_v": 1, "schema": "status_update.v1", "trace": {"message_id": "e-4"}, "trust": None, "payload": {"state": "idle"}}))
cat_e.append(make_fixture("E", "omission-empty-summary", "omission semantics - empty summary", {"wire_v": 1, "schema": "status_update.v1", "trace": {"message_id": "e-5"}, "summary": {}, "payload": {"state": "idle"}}))

def write_cat(name, fixtures):
    with (CONFORMANCE_DIR / f"{name}.json").open("w", encoding="utf-8") as f:
        json.dump(fixtures, f, indent=2)

write_cat("A_envelope_validity", cat_a)
write_cat("B_schema_payloads", cat_b)
write_cat("C_negotiation_vectors", cat_c)
write_cat("D_trust_vectors", cat_d)
write_cat("E_omission_semantics", cat_e)

total = len(cat_a) + len(cat_b) + len(cat_c) + len(cat_d) + len(cat_e)
print(f"Generated {total} fixtures.")
