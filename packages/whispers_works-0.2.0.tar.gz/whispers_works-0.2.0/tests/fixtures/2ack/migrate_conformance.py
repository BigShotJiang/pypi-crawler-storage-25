import json
from pathlib import Path

SOURCE_DIR = Path(__file__).resolve().parent
CONFORMANCE_DIR = SOURCE_DIR / "conformance"
CONFORMANCE_DIR.mkdir(parents=True, exist_ok=True)

fixtures = []
fixture_counter = 1

def categorize(desc, input_data):
    schema = input_data.get("schema", "")
    if "omission semantics" in desc.lower():
        return "E_omission_semantics"
    elif "trust tier" in desc.lower() or "authority" in desc.lower():
        return "D_trust_vectors"
    elif schema in ["protocol_error.v1"] and "negotiation" in desc.lower():
        return "C_negotiation_vectors"
    elif not input_data.get("wire_v") or not input_data.get("schema") or "missing" in desc.lower() or "malformed" in desc.lower() or "invalid" in desc.lower():
        if "workspace" in schema or "protocol_error" in schema:
             return "B_schema_payloads" # schema specific error
        return "A_envelope_validity"
    elif schema:
        return "B_schema_payloads"
    return "A_envelope_validity"


def default_preflight_decision(category, case):
    expected_valid = case.get("expected_valid", True)
    if category == "A_envelope_validity":
        input_data = case["input"]
        wire_v = input_data.get("wire_v")
        schema = input_data.get("schema")
        if wire_v != 1 or not isinstance(schema, str) or not schema:
            return "reject"
        return "accept"
    if category == "C_negotiation_vectors":
        if "negotiation" in case["description"].lower():
            return "reject_negotiation"
        return "accept"
    if category == "D_trust_vectors":
        if "trust tier" in case["description"].lower() or "authority" in case["description"].lower():
            return "reject_trust"
        return "accept"
    return "accept"

# Process exiting files
for filename in ["envelope_cases.json", "workspace_and_error_cases.json"]:
    filepath = SOURCE_DIR / filename
    if not filepath.exists():
        continue
    with filepath.open("r", encoding="utf-8") as f:
        data = json.load(f)
        for case in data:
            cat = categorize(case["description"], case["input"])
            cat_prefix = cat.split("_")[0]
            
            fix = {
                "id": f"fix-{cat_prefix}-{fixture_counter:03d}",
                "category": cat.split("_", 1)[1],
                "description": case["description"],
                "input": case["input"],
                "expected": {
                    "valid": case.get("expected_valid", True),
                    "error_codes": case.get("expected_error_codes", []),
                    "preflight_decision": default_preflight_decision(cat, case),
                }
            }
            fixtures.append((cat, fix))
            fixture_counter += 1

# Group by category and save
categorized = {}
for cat, fix in fixtures:
    categorized.setdefault(cat, []).append(fix)

for cat, fixes in categorized.items():
    out_path = CONFORMANCE_DIR / f"{cat}.json"
    with out_path.open("w", encoding="utf-8") as f:
        json.dump(fixes, f, indent=2)

print(f"Migrated {len(fixtures)} fixtures across {len(categorized)} categories.")
