"""Tests for auth failure rate limiting — prevents auth storms from overwhelming the server."""
import time
import importlib

import whispers.server as server_module


def _get_tracker():
    """Access current module-level tracker (survives reloads by other tests)."""
    return server_module._AUTH_FAIL_TRACKER


def _get_blocked():
    """Access current module-level blocked dict (survives reloads by other tests)."""
    return server_module._AUTH_FAIL_BLOCKED


def _get_limit():
    return server_module._AUTH_FAIL_LIMIT


def _cleanup():
    """Reset rate limit state between tests."""
    _get_tracker().clear()
    _get_blocked().clear()


class TestAuthRateLimit:

    def setup_method(self):
        _cleanup()

    def teardown_method(self):
        _cleanup()

    def test_first_failure_not_blocked(self):
        server_module._record_auth_failure("10.0.0.1")
        assert not server_module._check_auth_rate_limit("10.0.0.1")

    def test_under_limit_not_blocked(self):
        for _ in range(_get_limit() - 1):
            server_module._record_auth_failure("10.0.0.1")
        assert not server_module._check_auth_rate_limit("10.0.0.1")

    def test_at_limit_gets_blocked(self):
        for _ in range(_get_limit()):
            server_module._record_auth_failure("10.0.0.1")
        assert server_module._check_auth_rate_limit("10.0.0.1")

    def test_different_ips_tracked_separately(self):
        for _ in range(_get_limit()):
            server_module._record_auth_failure("10.0.0.1")
        assert server_module._check_auth_rate_limit("10.0.0.1")
        assert not server_module._check_auth_rate_limit("10.0.0.2")

    def test_block_expires(self):
        for _ in range(_get_limit()):
            server_module._record_auth_failure("10.0.0.1")
        assert server_module._check_auth_rate_limit("10.0.0.1")

        # Simulate block expiry
        _get_blocked()["10.0.0.1"] = time.time() - 1
        assert not server_module._check_auth_rate_limit("10.0.0.1")

    def test_window_expiry_allows_retry(self):
        # Fill up failures
        for _ in range(_get_limit() - 1):
            server_module._record_auth_failure("10.0.0.1")

        # Expire the window by backdating all entries
        _get_tracker()["10.0.0.1"] = [
            time.time() - 120 for _ in _get_tracker()["10.0.0.1"]
        ]

        # New failure should not trigger block (old ones expired)
        server_module._record_auth_failure("10.0.0.1")
        assert not server_module._check_auth_rate_limit("10.0.0.1")
