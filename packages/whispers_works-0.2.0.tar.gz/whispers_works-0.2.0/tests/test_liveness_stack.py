"""
Acceptance tests for the Whispers liveness stack.

Tests are organized by the stages defined in HEARTBEAT-ACTIVE-MODE-PLAN.md:
  Stage 0: Lease-backed presence truth (DONE - tested here for regression)
  Stage 1: Transport/session normalization
  Stage 2: Readiness state layer
  Stage 3: Cognitive heartbeat
  Stage 4: Derived active mode

Tests marked @pytest.mark.future require Stage 2+ implementation.
Tests without that marker should pass against the current codebase.

Acceptance criteria from the plan:
  1. A live listener keeps its lease valid while idle SSE keepalives continue.
  2. A stopped listener disappears immediately on explicit revoke.
  3. A crashed listener disappears by lease expiry without a long ghost window.
  4. An agent can be online and paused_by_operator at the same time.
  5. interruptibility=do_not_interrupt changes delivery/routing without going offline.
  6. High context_load and quality_risk=high push agent into overloaded/degraded.
  7. Dashboard and CLI show the same derived active mode for the same agent.
"""
import os
import time
import uuid
import shutil
import sqlite3
from pathlib import Path

import pytest

from whispers.storage.db import WhispersDB


@pytest.fixture
def temp_db():
    root = Path(__file__).resolve().parents[1] / ".tmp"
    root.mkdir(parents=True, exist_ok=True)
    case_dir = root / f"liveness-test-{uuid.uuid4().hex}"
    case_dir.mkdir(parents=True, exist_ok=False)
    db_path = str(case_dir / "test_liveness.db")
    yield db_path
    shutil.rmtree(case_dir, ignore_errors=True)


@pytest.fixture
def db(temp_db):
    return WhispersDB(db_path=temp_db)


# ---------------------------------------------------------------------------
# Stage 0: Lease-Backed Presence Truth
# ---------------------------------------------------------------------------

class TestLeaseBackedPresence:
    """Presence truth comes from agent_sessions, not sticky status flags."""

    def test_session_creates_online_presence(self, db):
        """Creating a session makes the agent appear online."""
        db.upsert_agent_session(
            "agent-a",
            f"sess-{uuid.uuid4().hex[:8]}",
            session_kind="local_client",
            lease_seconds=30,
        )
        with db.get_connection() as conn:
            row = conn.execute(
                "SELECT status FROM presence WHERE agent_name = 'agent-a'"
            ).fetchone()
        assert row is not None
        assert row["status"] == "online"

    def test_revoke_makes_agent_offline(self, db):
        """Acceptance #2: A stopped listener disappears immediately on explicit revoke."""
        session_id = f"sess-{uuid.uuid4().hex[:8]}"
        db.upsert_agent_session(
            "agent-a",
            session_id,
            session_kind="local_client",
            lease_seconds=30,
        )
        # Verify online first
        with db.get_connection() as conn:
            assert conn.execute(
                "SELECT status FROM presence WHERE agent_name = 'agent-a'"
            ).fetchone()["status"] == "online"

        # Revoke
        revoked = db.revoke_agent_session(session_id)
        assert revoked == 1

        # Should be offline immediately
        with db.get_connection() as conn:
            row = conn.execute(
                "SELECT status FROM presence WHERE agent_name = 'agent-a'"
            ).fetchone()
            assert row["status"] == "offline"

    def test_expired_lease_drops_from_active_swarm(self, db):
        """Acceptance #3: A crashed listener disappears by lease expiry."""
        session_id = f"sess-{uuid.uuid4().hex[:8]}"
        # Create with a 1-second lease
        db.upsert_agent_session(
            "agent-crash",
            session_id,
            session_kind="local_client",
            lease_seconds=1,
        )
        # Should be online now
        with db.get_connection() as conn:
            assert conn.execute(
                "SELECT status FROM presence WHERE agent_name = 'agent-crash'"
            ).fetchone()["status"] == "online"

        # Wait for lease to expire
        time.sleep(2)

        # Reap expired sessions
        reaped = db.reap_expired_agent_sessions()
        assert reaped >= 1

        # Should be offline now
        with db.get_connection() as conn:
            row = conn.execute(
                "SELECT status FROM presence WHERE agent_name = 'agent-crash'"
            ).fetchone()
            assert row["status"] == "offline"

    def test_lease_renewal_keeps_agent_online(self, db):
        """Acceptance #1: A live listener keeps its lease valid via renewal."""
        session_id = f"sess-{uuid.uuid4().hex[:8]}"
        db.upsert_agent_session(
            "agent-alive",
            session_id,
            session_kind="local_client",
            lease_seconds=3,
        )
        # Renew before expiry
        time.sleep(1)
        db.upsert_agent_session(
            "agent-alive",
            session_id,
            session_kind="local_client",
            lease_seconds=3,
        )
        # Wait past original expiry
        time.sleep(3)

        # Should still be online because we renewed
        with db.get_connection() as conn:
            active = conn.execute(
                """
                SELECT 1 FROM agent_sessions
                WHERE agent_name = 'agent-alive'
                  AND lease_expires_at >= CURRENT_TIMESTAMP
                """,
            ).fetchone()
        assert active is not None

    def test_multiple_sessions_one_agent(self, db):
        """An agent with multiple sessions stays online if any session is valid."""
        sess_1 = f"sess-{uuid.uuid4().hex[:8]}"
        sess_2 = f"sess-{uuid.uuid4().hex[:8]}"
        db.upsert_agent_session("multi", sess_1, session_kind="local_client", lease_seconds=1)
        db.upsert_agent_session("multi", sess_2, session_kind="mcp_bridge", lease_seconds=30)

        # Let first session expire
        time.sleep(2)
        db.reap_expired_agent_sessions()

        # Still online via second session
        with db.get_connection() as conn:
            row = conn.execute(
                "SELECT status FROM presence WHERE agent_name = 'multi'"
            ).fetchone()
            assert row["status"] == "online"

    def test_no_sessions_means_offline(self, db):
        """An agent with zero active sessions is offline."""
        session_id = f"sess-{uuid.uuid4().hex[:8]}"
        db.upsert_agent_session("loner", session_id, session_kind="local_client", lease_seconds=1)
        time.sleep(2)
        db.reap_expired_agent_sessions()

        with db.get_connection() as conn:
            row = conn.execute(
                "SELECT status FROM presence WHERE agent_name = 'loner'"
            ).fetchone()
            assert row["status"] == "offline"

    def test_session_kind_is_recorded(self, db):
        """Sessions track their kind for classification."""
        session_id = f"sess-{uuid.uuid4().hex[:8]}"
        db.upsert_agent_session(
            "typed-agent",
            session_id,
            session_kind="remote_http",
            lease_seconds=30,
        )
        with db.get_connection() as conn:
            row = conn.execute(
                "SELECT session_kind FROM agent_sessions WHERE session_id = ?",
                (session_id,),
            ).fetchone()
        assert row["session_kind"] == "remote_http"

    def test_mcp_bridge_session_seeds_available_startup_posture(self, db):
        """Fresh MCP hosts should appear as interactive listening peers immediately."""
        from whispers.client import WhispersClient

        cursor = WhispersClient("cursor", db_path=db.db_path, agent_type="mcp_server")
        viewer = WhispersClient("viewer", db_path=db.db_path)

        with db.get_connection() as conn:
            session = conn.execute(
                "SELECT session_kind FROM agent_sessions WHERE session_id = ?",
                (cursor.session_id,),
            ).fetchone()
            presence = conn.execute(
                """
                SELECT cognitive_state, intent_broadcast, last_active
                FROM presence
                WHERE agent_name = 'cursor'
                """
            ).fetchone()

        assert session is not None
        assert session["session_kind"] == "mcp_bridge"
        assert presence is not None
        assert presence["cognitive_state"] == "listening"
        assert presence["intent_broadcast"] == "available via mcp"
        assert presence["last_active"] is not None

        runtime = cursor.get_runtime_state()
        assert runtime["readiness"] == "ready"

        status = viewer.status()
        peer = next(agent for agent in status["peers_online"] if agent["agent_name"] == "cursor")
        assert peer["presence_kind"] == "interactive"
        assert peer["cognitive_state"] == "listening"
        assert peer["readiness"] == "ready"


# ---------------------------------------------------------------------------
# Stage 0: Ack Lifecycle Independence
# ---------------------------------------------------------------------------

class TestAckLifecycleIndependence:
    """Message acknowledgment must stay separate from presence/heartbeat.
    ack_state, ack_detail, acked_by, acked_at are message lifecycle fields only."""

    def test_ack_fields_do_not_affect_presence(self, db):
        """Acknowledging a message does not change the agent's presence status."""
        from whispers.client import WhispersClient

        client_a = WhispersClient("ack-sender", db_path=db.db_path)
        client_b = WhispersClient("ack-receiver", db_path=db.db_path)

        result = client_a.send("ack-receiver", "ack test", body="Test ack independence")

        # Check presence before ack
        with db.get_connection() as conn:
            before = conn.execute(
                "SELECT status FROM presence WHERE agent_name = 'ack-receiver'"
            ).fetchone()

        # Acknowledge the message
        client_b.acknowledge_message(result["id"], state="processed")

        # Presence should be unchanged
        with db.get_connection() as conn:
            after = conn.execute(
                "SELECT status FROM presence WHERE agent_name = 'ack-receiver'"
            ).fetchone()

        assert before["status"] == after["status"]


# ---------------------------------------------------------------------------
# Stage 2: Readiness State (future - requires implementation)
# ---------------------------------------------------------------------------

class TestReadinessState:
    """Readiness is independent from liveness. An agent can be online but not ready."""

    def test_online_and_paused_by_operator(self, db):
        """Acceptance #4: An agent can be online and paused_by_operator simultaneously."""
        session_id = f"sess-{uuid.uuid4().hex[:8]}"
        db.upsert_agent_session("pausable", session_id, session_kind="local_client", lease_seconds=30)

        runtime = db.set_readiness_state("pausable", session_id, readiness="paused_by_operator")

        with db.get_connection() as conn:
            presence = conn.execute(
                "SELECT status FROM presence WHERE agent_name = 'pausable'"
            ).fetchone()
            assert presence["status"] == "online"

        assert runtime["readiness"] == "paused_by_operator"
        latest_runtime = db.get_runtime_state("pausable")
        assert latest_runtime["readiness"] == "paused_by_operator"

    def test_readiness_change_does_not_kill_lease(self, db):
        """Changing readiness must not revoke the session lease."""
        session_id = f"sess-{uuid.uuid4().hex[:8]}"
        db.upsert_agent_session("steady-agent", session_id, session_kind="local_client", lease_seconds=30)

        db.set_readiness_state("steady-agent", session_id, readiness="busy")

        assert db.agent_has_active_session("steady-agent") is True
        with db.get_connection() as conn:
            session = conn.execute(
                "SELECT session_id FROM agent_sessions WHERE agent_name = 'steady-agent' AND lease_expires_at >= CURRENT_TIMESTAMP",
            ).fetchone()
        assert session is not None
        assert session["session_id"] == session_id

    def test_reception_mode_independent_from_readiness(self, db):
        """Reception mode (OPEN/FOCUSED/QUIET) and readiness are distinct controls."""
        from whispers.client import WhispersClient

        client = WhispersClient("focus-test", db_path=db.db_path)
        client.set_mode("quiet", allow_senders=["ally"])
        client.set_readiness("busy", current_task="deep focus")

        with db.get_connection() as conn:
            presence = conn.execute(
                "SELECT reception_mode FROM presence WHERE agent_name = 'focus-test'"
            ).fetchone()
        runtime = db.get_runtime_state("focus-test")

        assert presence["reception_mode"] == "quiet"
        assert runtime["readiness"] == "busy"
        assert runtime["current_task"] == "deep focus"


# ---------------------------------------------------------------------------
# Stage 3: Cognitive Heartbeat (future - requires implementation)
# ---------------------------------------------------------------------------

class TestCognitiveHeartbeat:
    """Cognitive heartbeat is a volatile semantic state path separate from the session lease."""

    def test_volatile_telemetry_bypasses_sqlite_but_touches_lease(self, db):
        """Acceptance: High-frequency variables do not hit SQL, but lease is maintained."""
        session_id = f"sess-{uuid.uuid4().hex[:8]}"
        db.upsert_agent_session("agent-focused", session_id, session_kind="local_client", lease_seconds=30)
        db.update_cognitive_heartbeat(
            "agent-focused",
            session_id,
            {
                "interruptibility": "do_not_interrupt",
                "context_load": 0.9,
                "current_task": "deep refactor",
            },
        )
        with db.get_connection() as conn:
            presence = conn.execute(
                "SELECT status FROM presence WHERE agent_name = 'agent-focused'"
            ).fetchone()
            assert presence["status"] == "online"
            
            # Verify the high-frequency telemetry payload was stripped from the sqlite row!
            runtime = conn.execute(
                "SELECT context_load, interruptibility, current_task FROM agent_runtime_state WHERE session_id = ?",
                (session_id,)
            ).fetchone()
            assert runtime["context_load"] is None
            assert runtime["interruptibility"] is None
            assert runtime["current_task"] == "deep refactor" # Preserved as structural

    def test_heartbeat_endpoint_is_not_lease_endpoint(self, db):
        """Hard boundary: cognitive heartbeat does NOT go through /lease."""
        session_id = f"sess-{uuid.uuid4().hex[:8]}"
        db.upsert_agent_session("heartbeat-agent", session_id, session_kind="local_client", lease_seconds=30)
        with db.get_connection() as conn:
            before = conn.execute(
                "SELECT lease_expires_at, last_seen_at FROM agent_sessions WHERE session_id = ?",
                (session_id,),
            ).fetchone()
        time.sleep(1)
        db.update_cognitive_heartbeat(
            "heartbeat-agent",
            session_id,
            {
                "interruptibility": "defer",
                "context_load": 0.6,
                "progress_summary": "still working",
            },
        )
        with db.get_connection() as conn:
            after = conn.execute(
                "SELECT lease_expires_at, last_seen_at FROM agent_sessions WHERE session_id = ?",
                (session_id,),
            ).fetchone()
        assert after["lease_expires_at"] == before["lease_expires_at"]
        assert after["last_seen_at"] == before["last_seen_at"]


# ---------------------------------------------------------------------------
# Stage 4: Derived Active Mode (future - requires implementation)
# ---------------------------------------------------------------------------

class TestDerivedActiveMode:
    """Active mode is derived from lease + readiness + in-memory heartbeat."""

    def test_derived_mode_offline_when_no_lease(self, db):
        """No active lease -> derived mode is 'offline'."""
        assert db.get_derived_active_mode("nobody") == "offline"

    def test_derived_mode_ready_when_lease_and_ready(self, db):
        """Active lease + readiness=ready + low load -> derived mode is 'ready'."""
        session_id = f"sess-{uuid.uuid4().hex[:8]}"
        db.upsert_agent_session("ready-agent", session_id, session_kind="local_client", lease_seconds=30)
        db.set_readiness_state("ready-agent", session_id, readiness="ready")
        assert db.get_derived_active_mode("ready-agent") == "ready"

    def test_derived_mode_degraded_when_high_quality_risk(self, db):
        """Active lease + quality_risk=high passed in memory -> derived mode includes 'degraded'."""
        session_id = f"sess-{uuid.uuid4().hex[:8]}"
        db.upsert_agent_session("risky-agent", session_id, session_kind="local_client", lease_seconds=30)
        assert db.get_derived_active_mode(
            "risky-agent",
            ephemeral_state={"quality_risk": "high", "context_load": 0.4}
        ) == "degraded"
