import pytest
from datetime import datetime, timedelta, timezone
from whispers.storage.db import WhispersDB
from whispers.trust import TrustManager

@pytest.fixture
def trust_manager(tmp_path):
    db_path = str(tmp_path / "test_trust.db")
    db = WhispersDB(db_path)
    return TrustManager(db)

def test_issue_and_verify_nonce(trust_manager):
    scope = {"action": "delete_workspace", "workspace_id": "ws-123"}
    nonce = trust_manager.issue_nonce("operator-1", scope)
    
    assert nonce.startswith("sn-")
    
    # Verify with partial requirements (granted scope has everything we need)
    assert trust_manager.verify_nonce(nonce, {"action": "delete_workspace"}) is True
    assert trust_manager.verify_nonce(nonce, {"workspace_id": "ws-123"}) is True
    
    # Must fail if requiring something not in the granted scope
    assert trust_manager.verify_nonce(nonce, {"action": "delete_workspace", "extra": "invalid"}) is False

def test_nonce_expiration(trust_manager):
    past = datetime.now(timezone.utc) - timedelta(minutes=5)
    nonce = trust_manager.issue_nonce("operator-1", {"action": "test"}, expires_at=past)
    
    # Should fail because it is chronologically expired
    assert trust_manager.verify_nonce(nonce, {"action": "test"}) is False

def test_revoke_nonce(trust_manager):
    nonce = trust_manager.issue_nonce("operator-1", {"action": "test"})
    assert trust_manager.verify_nonce(nonce, {"action": "test"}) is True
    
    trust_manager.revoke_nonce(nonce)
    assert trust_manager.verify_nonce(nonce, {"action": "test"}) is False

def test_verify_requires_active_status(trust_manager):
    nonce = trust_manager.issue_nonce("admin-1", {"action": "upgrade"})
    
    # Simulate a spent nonce
    with trust_manager.db._db_op("test-tamper") as conn:
        conn.execute("UPDATE authority_proofs SET status = 'spent' WHERE nonce = ?", (nonce,))
        conn.commit()
        
    assert trust_manager.verify_nonce(nonce, {"action": "upgrade"}) is False
