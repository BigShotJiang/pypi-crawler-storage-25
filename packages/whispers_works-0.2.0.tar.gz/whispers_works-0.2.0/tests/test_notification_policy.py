import asyncio

from whispers.dispatcher import Dispatcher
from whispers.envelope import Envelope, MsgType
from whispers.storage.db import WhispersDB
from whispers.transports.sse import SSETransport


def test_dispatcher_preserves_recipient_specific_alert_flags(temp_db):
    db = WhispersDB(temp_db)
    with db.get_connection() as conn:
        conn.execute(
            """
            INSERT INTO agent_cards (agent_id, callsign, agent_type)
            VALUES ('agent-alpha', 'alpha', 'llm')
            """
        )
        conn.execute(
            """
            INSERT INTO agent_cards (agent_id, callsign, agent_type)
            VALUES ('agent-beta', 'beta', 'llm')
            """
        )
        conn.execute(
            """
            INSERT INTO agent_cards (agent_id, callsign, agent_type)
            VALUES ('agent-gamma', 'gamma', 'llm')
            """
        )
        conn.execute(
            """
            INSERT INTO rooms (room_id, name, created_by)
            VALUES ('room-ops', 'ops', 'alpha')
            """
        )
        conn.execute(
            """
            INSERT INTO room_members (room_id, agent_id)
            VALUES ('room-ops', 'agent-beta')
            """
        )
        conn.execute(
            """
            INSERT INTO room_members (room_id, agent_id)
            VALUES ('room-ops', 'agent-gamma')
            """
        )
        conn.commit()

    db.set_presence_policy("beta", {"notification_policy": "direct_only"})
    db.set_presence_policy("gamma", {"notification_policy": "all"})

    dispatcher = Dispatcher(db)
    sse = SSETransport()
    dispatcher.add_transport_listener(sse.push)

    beta_queue = asyncio.Queue()
    gamma_queue = asyncio.Queue()
    sse.add_listener("beta", beta_queue)
    sse.add_listener("gamma", gamma_queue)

    dispatcher.dispatch(
        Envelope(
            sender="alpha",
            recipient="#ops",
            subject="Room update",
            body="Shared update without direct mention.",
            msg_type=MsgType.INFORM,
        )
    )

    beta_delivery = beta_queue.get_nowait()
    gamma_delivery = gamma_queue.get_nowait()

    assert beta_delivery is not gamma_delivery
    assert getattr(beta_delivery, "_alert", True) is False
    assert getattr(gamma_delivery, "_alert", False) is True
