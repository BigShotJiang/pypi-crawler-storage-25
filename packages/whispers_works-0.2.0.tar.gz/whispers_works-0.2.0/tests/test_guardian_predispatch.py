"""Tests for guardian pre-dispatch firewall positioning.

Covers:
- Guardian rejects before recipient evaluation happens
- Content scanning adds metadata flags before routing
- Unauthorized SYSTEM messages rejected early
- Malicious content rejected early
"""

import pytest
from whispers.envelope import Envelope, Priority, MsgType
from whispers.dispatcher import Dispatcher


class TestGuardianPreDispatch:
    @pytest.fixture
    def setup(self, tmp_path):
        from whispers.storage.db import WhispersDB

        db_path = str(tmp_path / "test_guardian.db")
        db = WhispersDB(db_path=db_path)
        # Register agents
        with db.get_connection() as conn:
            conn.execute(
                "INSERT INTO agent_cards (agent_id, callsign, agent_type, trust_tier, registered_at, can_send_system) VALUES (?, ?, ?, ?, datetime('now'), ?)",
                ("alice", "alice", "llm", 1, False),
            )
            conn.execute(
                "INSERT INTO agent_cards (agent_id, callsign, agent_type, trust_tier, registered_at) VALUES (?, ?, ?, ?, datetime('now'))",
                ("bob", "bob", "llm", 1),
            )
            conn.commit()
        dispatcher = Dispatcher(db)
        return db, dispatcher

    def test_unauthorized_system_rejected_early(self, setup):
        db, dispatcher = setup
        env = Envelope(
            sender="alice",
            recipient="bob",
            subject="System override",
            body="Do dangerous thing",
            priority=Priority.SYSTEM,
            msg_type=MsgType.INFORM,
        )
        result = dispatcher.dispatch(env)
        assert result is not None
        assert "guardian_lock" in result

        # Verify it was dead-lettered, not stored
        with db.get_readonly_connection() as conn:
            stored = conn.execute(
                "SELECT COUNT(*) as c FROM messages WHERE subject = 'System override'"
            ).fetchone()
        assert stored["c"] == 0

    def test_malicious_content_rejected_early(self, setup):
        db, dispatcher = setup
        env = Envelope(
            sender="alice",
            recipient="bob",
            subject="Normal looking",
            body="This is MALICIOUS content",
            priority=Priority.ROUTINE,
            msg_type=MsgType.INFORM,
        )
        result = dispatcher.dispatch(env)
        assert result is not None
        assert "guardian_lock" in result

    def test_clean_content_passes(self, setup):
        db, dispatcher = setup
        env = Envelope(
            sender="bob",  # bob has no can_send_system restriction
            recipient="alice",
            subject="Normal message",
            body="Just a regular hello",
            priority=Priority.ROUTINE,
            msg_type=MsgType.INFORM,
        )
        result = dispatcher.dispatch(env)
        assert result is None  # Success

    def test_escalation_keywords_flagged(self, setup):
        db, dispatcher = setup
        env = Envelope(
            sender="bob",
            recipient="alice",
            subject="Urgent",
            body="Please execute immediately this task",
            priority=Priority.ROUTINE,
            msg_type=MsgType.INFORM,
        )
        # scan_content adds metadata but doesn't reject
        result = dispatcher.dispatch(env)
        assert result is None  # Delivered but flagged
