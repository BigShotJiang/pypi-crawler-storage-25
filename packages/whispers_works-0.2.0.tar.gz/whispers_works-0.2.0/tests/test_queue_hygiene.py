import json
import sqlite3
import uuid

from whispers.client import WhispersClient
from whispers.storage.db import WhispersDB


def _active_hot_queue_count(db_path: str, recipient: str) -> int:
    with sqlite3.connect(db_path) as conn:
        return conn.execute(
            """
            SELECT COUNT(*)
            FROM message_recipients r
            JOIN messages m ON m.uuid = r.message_uuid
            WHERE r.recipient_callsign = ?
              AND m.status = 'new'
              AND r.delivery_status IN ('queued', 'unclaimed', 'delivered')
              AND r.archived_at IS NULL
              AND (r.snoozed_until IS NULL OR r.snoozed_until <= CURRENT_TIMESTAMP)
            """,
            (recipient,),
        ).fetchone()[0]


def _workspace_delta_payload(index: int) -> tuple[dict, dict]:
    payload = {
        "wire_v": 1,
        "schema": "workspace_delta.v1",
        "mode": "bilingual",
        "signal_class": "whispers_internal",
        "trace": {
            "message_id": f"workspace-msg-{index}",
            "trace_id": f"workspace-trace-{index}",
        },
        "summary": {
            "headline": "Workspace note",
            "human": f"Workspace note {index}",
        },
        "accept_schemas": [],
        "payload": {
            "workspace_id": "ws-queue",
            "delta_kind": "note",
            "text": f"Workspace note {index}",
            "sequence": index,
            "actor": "antigravity",
        },
    }
    metadata = {
        "whispers:schema": "workspace_delta.v1",
        "whispers:delta_kind": "note",
        "whispers:workspace_id": "ws-queue",
        "whispers:workspace_sequence": str(index),
    }
    return payload, metadata


def _seed_queued_messages(
    db_path: str,
    *,
    recipient: str,
    count: int,
    sender: str,
    subject_prefix: str,
    body_prefix: str,
    msg_type: str = "inform",
    priority: str = "routine",
    payload_factory=None,
) -> list[str]:
    message_ids: list[str] = []
    with sqlite3.connect(db_path) as conn:
        for index in range(count):
            message_id = str(uuid.uuid4())
            payload = None
            metadata = None
            if payload_factory is not None:
                payload, metadata = payload_factory(index)
            created_at = f"2026-03-30T00:00:{index:02d}+00:00"
            conn.execute(
                """
                INSERT INTO messages (
                    uuid, from_agent, to_agent, msg_type, subject, body, payload, priority,
                    status, delivery_status, metadata, created_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'new', 'queued', ?, ?)
                """,
                (
                    message_id,
                    sender,
                    recipient,
                    msg_type,
                    f"{subject_prefix} {index}",
                    f"{body_prefix} {index}",
                    json.dumps(payload) if payload is not None else None,
                    priority,
                    json.dumps(metadata) if metadata is not None else None,
                    created_at,
                ),
            )
            conn.execute(
                """
                INSERT INTO message_recipients (message_uuid, recipient_callsign, delivery_status, created_at)
                VALUES (?, ?, 'queued', ?)
                """,
                (message_id, recipient, created_at),
            )
            message_ids.append(message_id)
        conn.commit()
    return message_ids


def test_registry_assigns_baseline_trust_tier_for_core_agents(temp_db):
    codex = WhispersClient("codex", db_path=temp_db)
    with codex.db.get_connection() as conn:
        trust_tier = conn.execute(
            "SELECT trust_tier FROM agent_cards WHERE callsign = 'codex'"
        ).fetchone()[0]
    assert trust_tier == 5


def test_existing_core_agent_tier_is_backfilled_when_db_reopens(temp_db):
    db = WhispersDB(temp_db)
    with db.get_connection() as conn:
        conn.execute(
            """
            INSERT INTO agent_cards (agent_id, callsign, agent_type, trust_tier)
            VALUES (?, ?, ?, ?)
            """,
            (str(uuid.uuid4()), "codex", "script", 1),
        )
        conn.commit()

    reopened = WhispersDB(temp_db)
    with reopened.get_connection() as conn:
        trust_tier = conn.execute(
            "SELECT trust_tier FROM agent_cards WHERE callsign = 'codex'"
        ).fetchone()[0]
    assert trust_tier == 5


def test_queue_limit_ignores_archived_and_snoozed_rows(temp_db):
    sender = WhispersClient("alice", db_path=temp_db)
    sender.registry.register("bob")

    sent_ids = _seed_queued_messages(
        temp_db,
        recipient="bob",
        count=50,
        sender="queue-seed",
        subject_prefix="Message",
        body_prefix="fill",
    )
    db = WhispersDB(temp_db)
    db.message_action(sent_ids[0], "bob", "archive")
    db.message_action(sent_ids[1], "bob", "snooze", snooze_minutes=30)

    first_extra = sender.send("bob", "Extra 1", body="should fit")
    second_extra = sender.send("bob", "Extra 2", body="should also fit")

    assert first_extra["status"] == "queued"
    assert second_extra["status"] == "queued"
    assert _active_hot_queue_count(temp_db, "bob") == 50


def test_queue_compaction_archives_workspace_fanout_before_rejecting_real_work(temp_db):
    noise = WhispersClient("antigravity", db_path=temp_db)
    real_sender = WhispersClient("claude-code", db_path=temp_db)
    noise.registry.register("worker")

    _seed_queued_messages(
        temp_db,
        recipient="worker",
        count=50,
        sender="antigravity",
        subject_prefix="Workspace note",
        body_prefix="Workspace note",
        payload_factory=_workspace_delta_payload,
    )

    sent = real_sender.send(
        "worker",
        subject="Real assignment",
        body="Please pick this up.",
        priority="priority",
        msg_type="handoff",
    )

    assert sent["status"] == "queued"

    with sqlite3.connect(temp_db) as conn:
        archived_workspace = conn.execute(
            """
            SELECT COUNT(*)
            FROM message_recipients r
            JOIN messages m ON m.uuid = r.message_uuid
            WHERE r.recipient_callsign = 'worker'
              AND r.archived_at IS NOT NULL
              AND json_extract(m.metadata, '$."whispers:schema"') = 'workspace_delta.v1'
            """
        ).fetchone()[0]
        live_assignment = conn.execute(
            """
            SELECT archived_at
            FROM message_recipients
            WHERE recipient_callsign = 'worker' AND message_uuid = ?
            """,
            (sent["id"],),
        ).fetchone()[0]

    assert archived_workspace >= 1
    assert live_assignment is None
    assert _active_hot_queue_count(temp_db, "worker") == 50


def test_queue_compaction_archives_server_reminders_before_rejecting_real_work(temp_db):
    server = WhispersClient("whispers-server", db_path=temp_db, agent_type="infrastructure")
    real_sender = WhispersClient("claude-code", db_path=temp_db)
    server.registry.register("worker")

    _seed_queued_messages(
        temp_db,
        recipient="worker",
        count=50,
        sender="whispers-server",
        subject_prefix="Reminder: handoff from antigravity waiting",
        body_prefix="Reminder body",
        msg_type="heads_up",
    )

    sent = real_sender.send(
        "worker",
        subject="Priority review",
        body="Real work should still land.",
        priority="priority",
        msg_type="request",
    )

    assert sent["status"] == "queued"

    with sqlite3.connect(temp_db) as conn:
        archived_reminders = conn.execute(
            """
            SELECT COUNT(*)
            FROM message_recipients r
            JOIN messages m ON m.uuid = r.message_uuid
            WHERE r.recipient_callsign = 'worker'
              AND r.archived_at IS NOT NULL
              AND m.from_agent = 'whispers-server'
              AND m.msg_type = 'heads_up'
            """
        ).fetchone()[0]

    assert archived_reminders >= 1
    assert _active_hot_queue_count(temp_db, "worker") == 50


def test_stalled_handoff_reminder_supersedes_only_matching_baton(temp_db):
    server = WhispersClient("whispers-server", db_path=temp_db, agent_type="infrastructure")
    worker = WhispersClient("worker", db_path=temp_db)

    def _reminder_metadata(baton_ref: str, owner: str, subject: str) -> dict:
        return {
            "whispers:reminder_kind": "stalled_handoff",
            "whispers:baton_ref": baton_ref,
            "whispers:handoff_owner": owner,
            "whispers:handoff_subject": subject,
        }

    first = server.send(
        "worker",
        subject="Reminder: handoff from antigravity waiting (30m)",
        body="First reminder",
        msg_type="heads_up",
        metadata=_reminder_metadata("baton-1", "antigravity", "Spec review"),
    )
    second = server.send(
        "worker",
        subject="Reminder: handoff from claude-code waiting (25m)",
        body="Different baton should remain visible",
        msg_type="heads_up",
        metadata=_reminder_metadata("baton-2", "claude-code", "Startup audit"),
    )
    latest = server.send(
        "worker",
        subject="Reminder: handoff from antigravity waiting (45m)",
        body="Newest reminder should replace the older copy",
        msg_type="heads_up",
        metadata=_reminder_metadata("baton-1", "antigravity", "Spec review"),
    )

    assert first["status"] == "delivered"
    assert second["status"] == "delivered"
    assert latest["status"] == "delivered"

    with sqlite3.connect(temp_db) as conn:
        rows = conn.execute(
            """
            SELECT
                json_extract(m.metadata, '$."whispers:baton_ref"') AS baton_ref,
                SUM(CASE WHEN r.archived_at IS NULL THEN 1 ELSE 0 END) AS live_count,
                SUM(CASE WHEN r.archived_at IS NOT NULL THEN 1 ELSE 0 END) AS archived_count
            FROM message_recipients r
            JOIN messages m ON m.uuid = r.message_uuid
            WHERE r.recipient_callsign = 'worker'
              AND m.from_agent = 'whispers-server'
              AND m.msg_type = 'heads_up'
            GROUP BY baton_ref
            ORDER BY baton_ref
            """
        ).fetchall()

    counts = {
        baton_ref: {"live": live_count, "archived": archived_count}
        for baton_ref, live_count, archived_count in rows
    }
    assert counts == {
        "baton-1": {"live": 1, "archived": 1},
        "baton-2": {"live": 1, "archived": 0},
    }

    status = worker.status()
    assert status["pending_messages"] == 2
    assert status["pending_by_priority"] == {"routine": 2}


def test_acknowledging_handoff_archives_matching_stalled_reminder(temp_db):
    owner = WhispersClient("antigravity", db_path=temp_db)
    server = WhispersClient("whispers-server", db_path=temp_db, agent_type="infrastructure")
    worker = WhispersClient("worker", db_path=temp_db)

    handoff = owner.send(
        "worker",
        subject="Legacy handoff",
        body="Pick this up from the older handoff path.",
        priority="priority",
        msg_type="handoff",
    )
    reminder = server.send(
        "worker",
        subject="Reminder: handoff from antigravity waiting (45m)",
        body="Please ack, decline, or defer.",
        msg_type="heads_up",
        metadata={
            "whispers:reminder_kind": "stalled_handoff",
            "whispers:baton_ref": handoff["id"],
            "whispers:handoff_owner": "antigravity",
            "whispers:handoff_subject": "Legacy handoff",
        },
    )

    worker.acknowledge_message(handoff["id"], "processed", detail="Reviewed and cleared")

    with sqlite3.connect(temp_db) as conn:
        archived_at = conn.execute(
            """
            SELECT archived_at
            FROM message_recipients
            WHERE recipient_callsign = 'worker' AND message_uuid = ?
            """,
            (reminder["id"],),
        ).fetchone()[0]

    assert archived_at is not None
    status = worker.status()
    assert status["pending_messages"] == 0


def test_status_pending_counts_ignore_archived_and_snoozed_hot_queue_rows(temp_db):
    sender = WhispersClient("alice", db_path=temp_db)
    receiver = WhispersClient("worker", db_path=temp_db)

    archived = sender.send("worker", "Archive me", body="handled", priority="routine")
    snoozed = sender.send("worker", "Snooze me", body="later", priority="flash")
    live = sender.send("worker", "Still pending", body="keep", priority="priority")

    db = WhispersDB(temp_db)
    db.message_action(archived["id"], "worker", "archive")
    db.message_action(snoozed["id"], "worker", "snooze", snooze_minutes=30)

    status = receiver.status()

    assert status["pending_messages"] == 1
    assert status["pending_by_priority"] == {"priority": 1}
    inbox = receiver.check_inbox(mark_seen=False)
    assert [message["uuid"] for message in inbox] == [live["id"]]
