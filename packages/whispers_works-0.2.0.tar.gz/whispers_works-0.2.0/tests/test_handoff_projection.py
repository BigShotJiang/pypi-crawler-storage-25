from whispers.testing import WhispersTestClient

def test_handoff_workspace_projection(temp_db):
    """
    Tests that the real send_handoff() path projects a workspace-linked baton
    into the workspace event stream.
    """
    claude = WhispersTestClient("claude", shared_db_path=temp_db)
    codex = WhispersTestClient("codex", shared_db_path=temp_db)
    antigravity = WhispersTestClient("antigravity", shared_db_path=temp_db)
    operator = WhispersTestClient("whispers-console", shared_db_path=temp_db)

    created = antigravity.create_workspace(
        purpose="Projection testing",
        join_policy="invite",
        members=["codex", "claude"],
    )
    ws_id = created["workspace_id"]

    # Creator (antigravity) is auto-joined at seq 1
    codex.join_workspace(ws_id)       # seq 2
    claude.join_workspace(ws_id) # seq 3
    antigravity.send_handoff(
        "codex",
        objective="Build projection hook",
        deliverable="Projection integration",
        completed="Task updated",
        remaining="Projection test",
        next_action="Run pytest",
        workspace_id=ws_id,
        human_summary="Handed the projection hook to Codex for verification.",
        trace_id="projection-pass-1",
    )

    handoff = operator.list_handoffs(limit=10, workspace_id=ws_id)[0]
    state = claude.workspace_state(ws_id, since_sequence=3)
    handoff_delta = state["deltas"][0]

    assert handoff_delta["delta_kind"] == "handoff_in"
    assert handoff_delta["actor"] == "antigravity"
    assert handoff_delta["related_message_id"] == handoff["message_id"]
    assert handoff_delta["text"] == "Handed the projection hook to Codex for verification."
    assert handoff_delta["state_patch"]["handoff_payload"]["workspace_id"] == ws_id
    assert handoff_delta["state_patch"]["handoff_payload"]["completed"] == "Task updated"
    assert handoff_delta["state_patch"]["handoff_recipient"] == "codex"
