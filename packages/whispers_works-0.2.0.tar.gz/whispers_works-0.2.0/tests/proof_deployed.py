"""Proof test against the deployed Whispers server on Railway.

Validates that the full agent lifecycle works over the public internet:
connect → send → receive → trace → disconnect
"""
import json
import os
import secrets
import sys
import urllib.request
import urllib.error
import time

SERVER = os.environ.get("WHISPERS_PROOF_SERVER", "https://whispers-production-9f63.up.railway.app")
RUN_SUFFIX = secrets.token_hex(4)
ALPHA_AGENT = f"proof-alpha-{RUN_SUFFIX}"
BETA_AGENT = f"proof-beta-{RUN_SUFFIX}"
RESULTS = []


def _req(method, path, body=None, token=None, headers=None):
    """Make an HTTP request to the deployed server."""
    url = f"{SERVER}{path}"
    data = json.dumps(body).encode() if body else None
    req = urllib.request.Request(url, data=data, method=method)
    req.add_header("Content-Type", "application/json")
    if token:
        req.add_header("Authorization", f"Bearer {token}")
    if headers:
        for k, v in headers.items():
            req.add_header(k, v)
    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            return resp.status, json.loads(resp.read())
    except urllib.error.HTTPError as e:
        return e.code, json.loads(e.read()) if e.fp else {}


def check(name, condition, detail=""):
    status = "PASS" if condition else "FAIL"
    RESULTS.append({"check": name, "status": status, "detail": detail})
    icon = "✓" if condition else "✗"
    print(f"  {icon} {name}: {detail}" if detail else f"  {icon} {name}")
    return condition


def main():
    print(f"\n{'='*60}")
    print(f"  DEPLOYED SERVER PROOF TEST")
    print(f"  {SERVER}")
    print(f"  Run suffix: {RUN_SUFFIX}")
    print(f"{'='*60}\n")

    token_a = None
    token_b = None
    try:
        # 1. Health check
        print("[1/7] Health Check")
        code, health = _req("GET", "/health")
        check("health_endpoint", code == 200, f"status={code}")
        check("healthy", health.get("healthy") is True)
        check("persistent_volume", health.get("db_path") == "/data/whispers.db",
              health.get("db_path"))

        # 2. Connect two agents
        print("\n[2/7] Agent Connection")
        code1, r1 = _req("POST", "/connect", {"agent_name": ALPHA_AGENT, "agent_type": "test"})
        check("connect_alpha", code1 == 200, f"status={code1}")
        token_a = r1.get("token")
        check("alpha_got_token", bool(token_a))

        code2, r2 = _req("POST", "/connect", {"agent_name": BETA_AGENT, "agent_type": "test"})
        check("connect_beta", code2 == 200, f"status={code2}")
        token_b = r2.get("token")
        check("beta_got_token", bool(token_b))

        # 3. Whoami
        print("\n[3/7] Identity")
        code, whoami = _req("GET", "/whoami", token=token_a)
        check("whoami", code == 200 and whoami.get("callsign") == ALPHA_AGENT,
              whoami.get("callsign"))

        # 4. Send a message
        print("\n[4/7] Messaging")
        code, send_resp = _req("POST", "/message:send", {
            "to": BETA_AGENT,
            "subject": "Deployed proof test",
            "body": "Hello from the internet!",
            "priority": "routine",
            "type": "inform",
        }, token=token_a, headers={"A2A-Version": "1.0"})
        check("send_message", code == 200, f"status={send_resp.get('delivery_status', '?')}")

        # 5. Check inbox
        print("\n[5/7] Inbox")
        code, inbox = _req("GET", "/inbox", token=token_b)
        check("inbox_response", code == 200)
        messages = inbox if isinstance(inbox, list) else inbox.get("messages", [])
        check("message_received", len(messages) >= 1, f"count={len(messages)}")
        if messages:
            check("correct_sender", messages[0].get("from_agent") == ALPHA_AGENT)
            check("correct_body", "internet" in (messages[0].get("body") or "").lower())

        # 6. Presence
        print("\n[6/7] Presence")
        code, presence = _req("GET", "/presence", token=token_a)
        check("presence", code == 200)
        agents = presence if isinstance(presence, list) else presence.get("agents", [])
        names = [a.get("callsign") or a.get("agent_name") for a in agents]
        check("sees_beta", BETA_AGENT in names, f"agents={names}")

        # 7. Trace
        print("\n[7/7] Trace")
        code, trace = _req("GET", f"/trace/{BETA_AGENT}", token=token_a)
        check("trace", code == 200)
        trace_msgs = trace if isinstance(trace, list) else trace.get("messages", [])
        check("trace_has_message", len(trace_msgs) >= 1, f"count={len(trace_msgs)}")
    finally:
        if token_a:
            _req("POST", "/disconnect", token=token_a)
        if token_b:
            _req("POST", "/disconnect", token=token_b)

        # Summary
        passed = sum(1 for r in RESULTS if r["status"] == "PASS")
        failed = sum(1 for r in RESULTS if r["status"] == "FAIL")
        print(f"\n{'='*60}")
        print(f"  RESULTS: {passed} passed, {failed} failed")
        print(f"{'='*60}\n")

        if failed:
            print("FAILURES:")
            for r in RESULTS:
                if r["status"] == "FAIL":
                    print(f"  ✗ {r['check']}: {r.get('detail', '')}")
            print()

    sys.exit(0 if failed == 0 else 1)


if __name__ == "__main__":
    main()
