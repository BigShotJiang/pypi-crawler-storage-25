import pytest

from whispers.dispatcher import Dispatcher
from whispers.envelope import Envelope, MsgType, Priority
from whispers.storage.db import WhispersDB


def _twoack_envelope(schema: str, payload: dict, **overrides) -> dict:
    envelope = {
        "wire_v": 1,
        "schema": schema,
        "mode": "bilingual",
        "signal_class": "whispers_internal",
        "trace": {"message_id": "msg-test-1"},
        "summary": {"headline": "2ack test", "human": "dispatcher test"},
        "payload": payload,
    }
    envelope.update(overrides)
    return envelope


def _dispatch_envelope(payload: dict, *, recipient: str = "bob", metadata: dict | None = None) -> Envelope:
    return Envelope(
        sender="alice",
        recipient=recipient,
        subject="2ack dispatch test",
        body="dispatcher local 2ack test",
        priority=Priority.ROUTINE,
        msg_type=MsgType.INFORM,
        payload=payload,
        metadata=metadata,
    )


@pytest.fixture
def setup(temp_db):
    db = WhispersDB(db_path=temp_db)
    with db.get_connection() as conn:
        conn.execute(
            "INSERT INTO agent_cards (agent_id, callsign, agent_type, trust_tier, registered_at) VALUES (?, ?, ?, ?, datetime('now'))",
            ("alice", "alice", "llm", 5),
        )
        conn.execute(
            "INSERT INTO agent_cards (agent_id, callsign, agent_type, trust_tier, registered_at) VALUES (?, ?, ?, ?, datetime('now'))",
            ("bob", "bob", "llm", 1),
        )
        conn.execute(
            "INSERT INTO agent_cards (agent_id, callsign, agent_type, trust_tier, registered_at) VALUES (?, ?, ?, ?, datetime('now'))",
            ("carol", "carol", "llm", 4),
        )
        conn.commit()
    return db, Dispatcher(db)


def _latest_security_event(db: WhispersDB, event_type: str):
    with db.get_connection() as conn:
        return conn.execute(
            """
            SELECT event_type, outcome, detail
            FROM security_events
            WHERE event_type = ?
            ORDER BY created_at DESC
            LIMIT 1
            """,
            (event_type,),
        ).fetchone()


def _message_count(db: WhispersDB) -> int:
    with db.get_connection() as conn:
        row = conn.execute("SELECT COUNT(*) AS c FROM messages").fetchone()
    return row["c"]


class TestDispatcherTwoAckPredispatch:
    def test_expired_twoack_rejected_before_storage(self, setup):
        db, dispatcher = setup
        payload = _twoack_envelope(
            "handoff_baton.v1",
            {"objective": "Ship it", "deliverable": "deploy plan"},
            expires_at="2026-03-25T11:59:00Z",
        )

        reason = dispatcher.dispatch(_dispatch_envelope(payload))

        assert reason == "2ack_preflight_rejected:ERR_EXPIRED"
        assert _message_count(db) == 0
        event = _latest_security_event(db, "2ack_preflight_rejected")
        assert event is not None
        assert event["outcome"] == "rejected"

    def test_malformed_twoack_rejected_on_local_dispatch(self, setup):
        db, dispatcher = setup
        payload = {
            "wire_v": 1,
            "schema": "handoff_baton.v1",
            "payload": {"objective": "Ship it", "deliverable": "deploy plan"},
        }

        reason = dispatcher.dispatch(
            _dispatch_envelope(payload, metadata={"whispers:schema": "handoff_baton.v1"})
        )

        assert reason == "2ack_invalid_envelope"
        assert _message_count(db) == 0
        event = _latest_security_event(db, "2ack_validation_failed")
        assert event is not None

    def test_trust_tier_requirement_blocks_low_trust_recipient(self, setup):
        db, dispatcher = setup
        payload = _twoack_envelope(
            "handoff_baton.v1",
            {"objective": "Ship it", "deliverable": "deploy plan"},
            trust={"tier_required": 3},
        )

        reason = dispatcher.dispatch(_dispatch_envelope(payload, recipient="bob"))

        assert reason == "2ack_trust_insufficient"
        assert _message_count(db) == 0
        event = _latest_security_event(db, "2ack_trust_insufficient")
        assert event is not None
        assert event["outcome"] == "rejected"

    def test_invalid_authority_claim_rejected_on_local_dispatch(self, setup):
        db, dispatcher = setup
        payload = _twoack_envelope(
            "handoff_baton.v1",
            {"objective": "Ship it", "deliverable": "deploy plan"},
            authority={"principal": "zack", "scope": {"deploy": "staging"}},
        )

        reason = dispatcher.dispatch(_dispatch_envelope(payload, recipient="carol"))

        assert reason == "2ack_authority_failed"
        assert _message_count(db) == 0
        event = _latest_security_event(db, "2ack_authority_failed")
        assert event is not None

    def test_high_risk_external_action_requires_authority(self, setup):
        db, dispatcher = setup
        payload = _twoack_envelope(
            "external_action_request.v1",
            {
                "action_class": "deploy",
                "intent": "Ship to production",
                "risk_level": "critical",
            },
        )

        reason = dispatcher.dispatch(_dispatch_envelope(payload, recipient="carol"))

        assert reason == "2ack_authority_required"
        assert _message_count(db) == 0
        event = _latest_security_event(db, "2ack_authority_required")
        assert event is not None

    def test_valid_high_trust_authorized_twoack_stores(self, setup):
        db, dispatcher = setup
        payload = _twoack_envelope(
            "external_action_request.v1",
            {
                "action_class": "deploy",
                "intent": "Ship to staging",
                "risk_level": "critical",
            },
            trust={"tier_required": 3},
            authority={"principal": "zack", "scope": {"deploy": "staging"}},
            authority_proof={"kind": "server_nonce", "nonce": "sn-abc123"},
        )

        reason = dispatcher.dispatch(_dispatch_envelope(payload, recipient="carol"))

        assert reason is None
        assert _message_count(db) == 1
