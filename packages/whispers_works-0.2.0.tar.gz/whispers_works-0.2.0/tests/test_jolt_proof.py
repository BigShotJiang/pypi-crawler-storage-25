"""Jolt proof/pressure tests.

Proves that the Jolt substrate behaves honestly under pressure:
1. Stale hot-thread wakeups do not masquerade as success
2. Terminal sidecar stage-context output stays truthful
3. Packet signature deduplication catches real transitions

These tests target the committed host surfaces (managed terminal sidecar,
packet truth, CLI rendering) without modifying shared-core semantics.
"""

import whispers.cli as cli_module
from whispers.jolt import (
    HostWakeCapabilities,
    JoltBudget,
    JoltContext,
    decide_jolt_action,
)


# ---------------------------------------------------------------------------
# PROOF TARGET 1: Stale hot-thread wakeups do not masquerade as success
# ---------------------------------------------------------------------------


class TestStaleHotThreadSuppression:
    """Prove that stale hot-thread signals are blocked from notification,
    while fresh hot-threads and stale non-hot-thread triggers pass through."""

    def test_stale_hot_thread_is_suppressed(self):
        assert cli_module._should_emit_jolt_notification(
            {"trigger": "hot_thread", "freshness": "stale"}
        ) is False

    def test_fresh_hot_thread_is_emitted(self):
        assert cli_module._should_emit_jolt_notification(
            {"trigger": "hot_thread", "freshness": "fresh"}
        ) is True

    def test_stale_direct_assignment_still_emitted(self):
        """Staleness only suppresses hot_thread, not other triggers."""
        assert cli_module._should_emit_jolt_notification(
            {"trigger": "direct_assignment", "freshness": "stale"}
        ) is True

    def test_stale_blocking_dependency_still_emitted(self):
        assert cli_module._should_emit_jolt_notification(
            {"trigger": "blocking_dependency", "freshness": "stale"}
        ) is True

    def test_stale_flash_message_still_emitted(self):
        assert cli_module._should_emit_jolt_notification(
            {"trigger": "flash_message", "freshness": "stale"}
        ) is True

    def test_stale_operator_directed_still_emitted(self):
        assert cli_module._should_emit_jolt_notification(
            {"trigger": "operator_directed", "freshness": "stale"}
        ) is True

    def test_missing_freshness_field_emits(self):
        """A hot_thread with no freshness data should still emit
        (fail-open for attention, not fail-closed)."""
        assert cli_module._should_emit_jolt_notification(
            {"trigger": "hot_thread"}
        ) is True

    def test_empty_freshness_string_emits(self):
        assert cli_module._should_emit_jolt_notification(
            {"trigger": "hot_thread", "freshness": ""}
        ) is True

    def test_none_packet_does_not_emit(self):
        assert cli_module._should_emit_jolt_notification(None) is False

    def test_non_dict_packet_does_not_emit(self):
        assert cli_module._should_emit_jolt_notification("not a packet") is False


class TestStaleHotThreadRendering:
    """Prove that when a stale hot-thread does render (e.g. in terminal lines),
    the staleness is clearly visible — it cannot appear fresh."""

    def test_stale_notification_shows_freshness_and_age(self):
        notification = cli_module._build_jolt_notification(
            {
                "action": "notify",
                "headline": "Hot reply from antigravity",
                "trigger": "hot_thread",
                "recommended_action": "Open hot collaborator replies.",
                "freshness": "stale",
                "age_label": "6m",
                "source_stage": "reply_ready",
                "stale_after_seconds": 240,
                "reasons": ["manual-wake host falls back to notification only"],
            },
            agent_name="codex",
        )
        title, detail = notification
        assert "stale" in detail.lower()
        assert "6m" in detail
        assert "reply ready" in detail.lower()
        assert "4m" in detail  # stale_after_seconds=240 → target <= 4m

    def test_fresh_notification_does_not_say_stale(self):
        notification = cli_module._build_jolt_notification(
            {
                "action": "notify",
                "headline": "Hot reply from antigravity",
                "trigger": "hot_thread",
                "freshness": "fresh",
                "age_label": "30s",
                "reasons": ["manual-wake host falls back to notification only"],
            },
            agent_name="codex",
        )
        _, detail = notification
        assert "stale" not in detail.lower()

    def test_terminal_lines_show_stale_marker(self):
        lines = cli_module._build_terminal_jolt_lines(
            {
                "action": "notify",
                "headline": "Hot reply from antigravity",
                "trigger": "hot_thread",
                "priority": "priority",
                "freshness": "stale",
                "age_label": "8m",
            },
            status_snapshot={},
            agent_name="claude-code",
        )
        signal_line = [l for l in lines if l.startswith("Signal:")]
        assert len(signal_line) == 1
        assert "stale" in signal_line[0].lower()
        assert "8m old" in signal_line[0]

    def test_terminal_lines_show_fresh_marker(self):
        lines = cli_module._build_terminal_jolt_lines(
            {
                "action": "notify",
                "headline": "Hot reply from antigravity",
                "trigger": "hot_thread",
                "priority": "priority",
                "freshness": "fresh",
            },
            status_snapshot={},
            agent_name="claude-code",
        )
        signal_line = [l for l in lines if l.startswith("Signal:")]
        assert len(signal_line) == 1
        assert "fresh" in signal_line[0].lower()
        assert "stale" not in signal_line[0].lower()


class TestJoltDecisionStalenessIntegrity:
    """Prove that the decide_jolt_action engine itself cannot produce
    a 'success-looking' decision for scenarios that should suppress."""

    def test_do_not_interrupt_suppresses_hot_thread(self):
        decision = decide_jolt_action(
            JoltContext(
                trigger="hot_thread",
                wake_model="manual_wake",
                interruptibility="do_not_interrupt",
                explicitly_addressed=True,
            ),
            HostWakeCapabilities(host_kind="cursor", can_notify=True, can_stage_context=True),
            JoltBudget(),
        )
        assert decision.action == "suppress"

    def test_urgent_only_suppresses_non_urgent_hot_thread(self):
        decision = decide_jolt_action(
            JoltContext(
                trigger="hot_thread",
                wake_model="listener_backed",
                interruptibility="urgent_only",
                priority="routine",
                explicitly_addressed=True,
            ),
            HostWakeCapabilities(
                host_kind="listener",
                can_notify=True,
                can_stage_context=True,
                can_trigger_inference=True,
            ),
            JoltBudget(autonomous_inference_enabled=True, max_inferences_per_hour=4),
        )
        assert decision.action == "suppress"

    def test_ambient_update_never_jolts_even_with_full_capabilities(self):
        decision = decide_jolt_action(
            JoltContext(trigger="ambient_update", wake_model="always_on"),
            HostWakeCapabilities(
                host_kind="always_on",
                can_notify=True,
                can_stage_context=True,
                can_trigger_inference=True,
            ),
            JoltBudget(
                autonomous_inference_enabled=True,
                max_inferences_per_hour=100,
            ),
        )
        assert decision.action == "suppress"


# ---------------------------------------------------------------------------
# PROOF TARGET 1B: Packet signature dedupe ignores display-only age drift
# ---------------------------------------------------------------------------


class TestJoltPacketSignatureDedupe:
    def test_age_label_drift_does_not_change_signature(self):
        fresh_30s = cli_module._jolt_packet_signature(
            {
                "action": "stage_context",
                "trigger": "direct_assignment",
                "headline": "1 assignment waiting",
                "recommended_action": "Open the assignment queue.",
                "freshness": "fresh",
                "age_label": "30s",
                "stale_after_seconds": 240,
                "adapter": {
                    "adapter_kind": "managed_pty",
                    "supported_actions": ["notify", "stage_context"],
                },
            }
        )
        fresh_45s = cli_module._jolt_packet_signature(
            {
                "action": "stage_context",
                "trigger": "direct_assignment",
                "headline": "1 assignment waiting",
                "recommended_action": "Open the assignment queue.",
                "freshness": "fresh",
                "age_label": "45s",
                "stale_after_seconds": 240,
                "adapter": {
                    "adapter_kind": "managed_pty",
                    "supported_actions": ["notify", "stage_context"],
                },
            }
        )
        assert fresh_30s == fresh_45s

    def test_freshness_transition_still_changes_signature(self):
        fresh = cli_module._jolt_packet_signature(
            {
                "action": "stage_context",
                "trigger": "direct_assignment",
                "headline": "1 assignment waiting",
                "recommended_action": "Open the assignment queue.",
                "freshness": "fresh",
                "age_label": "30s",
                "stale_after_seconds": 240,
                "adapter": {
                    "adapter_kind": "managed_pty",
                    "supported_actions": ["notify", "stage_context"],
                },
            }
        )
        stale = cli_module._jolt_packet_signature(
            {
                "action": "stage_context",
                "trigger": "direct_assignment",
                "headline": "1 assignment waiting",
                "recommended_action": "Open the assignment queue.",
                "freshness": "stale",
                "age_label": "6m",
                "stale_after_seconds": 240,
                "source_stage": "reply_ready",
                "adapter": {
                    "adapter_kind": "managed_pty",
                    "supported_actions": ["notify", "stage_context"],
                },
            }
        )
        assert fresh != stale


# ---------------------------------------------------------------------------
# PROOF TARGET 2: Terminal sidecar stage-context output stays truthful
# ---------------------------------------------------------------------------


class TestTerminalStageContextTruth:
    """Prove that the terminal sidecar renders context that matches
    the actual status snapshot — it can't invent or drop fields."""

    def test_stage_context_renders_all_status_fields(self):
        lines = cli_module._build_terminal_jolt_lines(
            {
                "action": "stage_context",
                "headline": "1 assignment waiting",
                "trigger": "direct_assignment",
                "priority": "priority",
                "recommended_action": "Open the assignment queue.",
                "reasons": ["host can stage context"],
            },
            status_snapshot={
                "my_mode": "OPEN",
                "readiness": "ready",
                "pending_messages": 3,
                "pending_assignments": 1,
                "pending_review_requests": 2,
                "connection_story": {
                    "recommended_action": "Pick up the assignment queue.",
                    "huddle_peers": [
                        {"callsign": "antigravity", "reasons": ["shared workspace Sprint"]},
                        {"callsign": "codex", "reasons": ["review waiting"]},
                    ],
                },
            },
            agent_name="claude-code",
        )
        full_text = "\n".join(lines)
        assert "mode OPEN" in full_text
        assert "readiness ready" in full_text
        assert "3 pending messages" in full_text
        assert "1 assignments" in full_text
        assert "2 reviews" in full_text
        assert "antigravity" in full_text
        assert "codex" in full_text
        assert "Pick up the assignment queue." in full_text

    def test_stage_context_shows_blocking_reviews_when_present(self):
        lines = cli_module._build_terminal_jolt_lines(
            {
                "action": "stage_context",
                "headline": "Blocking review",
                "trigger": "blocking_dependency",
                "reasons": ["host can stage context"],
            },
            status_snapshot={
                "my_mode": "FOCUSED",
                "readiness": "busy",
                "pending_messages": 0,
                "pending_assignments": 0,
                "pending_review_requests": 1,
                "blocking_review_requests": 1,
                "connection_story": {},
            },
            agent_name="claude-code",
        )
        full_text = "\n".join(lines)
        assert "1 blocking" in full_text
        assert "mode FOCUSED" in full_text
        assert "readiness busy" in full_text

    def test_stage_context_with_empty_snapshot_produces_no_context_line(self):
        lines = cli_module._build_terminal_jolt_lines(
            {
                "action": "stage_context",
                "headline": "Check in",
                "trigger": "direct_assignment",
                "reasons": ["host can stage context"],
            },
            status_snapshot={},
            agent_name="claude-code",
        )
        context_lines = [l for l in lines if l.startswith("Context:")]
        assert len(context_lines) == 0

    def test_non_stage_context_action_does_not_render_context(self):
        """A notify action should never include stage context lines,
        even if the snapshot has data."""
        lines = cli_module._build_terminal_jolt_lines(
            {
                "action": "notify",
                "headline": "Something happened",
                "trigger": "hot_thread",
                "reasons": ["fallback to notification"],
            },
            status_snapshot={
                "my_mode": "OPEN",
                "readiness": "ready",
                "pending_messages": 5,
                "connection_story": {
                    "recommended_action": "Check inbox.",
                    "huddle_peers": [{"callsign": "antigravity", "reasons": ["working"]}],
                },
            },
            agent_name="claude-code",
        )
        full_text = "\n".join(lines)
        assert "Context:" not in full_text
        assert "Peers:" not in full_text
        assert "Story:" not in full_text

    def test_stage_context_truncates_huddle_peers_at_three(self):
        lines = cli_module._build_terminal_jolt_lines(
            {
                "action": "stage_context",
                "headline": "Check in",
                "trigger": "direct_assignment",
                "reasons": ["host can stage context"],
            },
            status_snapshot={
                "connection_story": {
                    "huddle_peers": [
                        {"callsign": "agent-1", "reasons": ["workspace"]},
                        {"callsign": "agent-2", "reasons": ["workspace"]},
                        {"callsign": "agent-3", "reasons": ["workspace"]},
                        {"callsign": "agent-4", "reasons": ["workspace"]},
                        {"callsign": "agent-5", "reasons": ["workspace"]},
                    ],
                },
            },
            agent_name="claude-code",
        )
        peer_lines = [l for l in lines if l.startswith("Peers:")]
        if peer_lines:
            # Should not list all 5 — the sidecar caps at 3
            assert "agent-4" not in peer_lines[0]
            assert "agent-5" not in peer_lines[0]

    def test_none_packet_produces_empty_lines(self):
        lines = cli_module._build_terminal_jolt_lines(
            None,
            status_snapshot={"my_mode": "OPEN", "readiness": "ready"},
            agent_name="claude-code",
        )
        assert lines == []


# ---------------------------------------------------------------------------
# PROOF TARGET 3: Packet signature deduplication catches real transitions
# ---------------------------------------------------------------------------


class TestPacketSignatureDedup:
    """Prove that _jolt_packet_signature captures meaningful state changes
    and ignores noise like server_time_utc or minor metadata."""

    _BASE_PACKET = {
        "action": "stage_context",
        "trigger": "direct_assignment",
        "headline": "1 assignment waiting",
        "priority": "priority",
        "recommended_action": "Open the assignment queue.",
        "freshness": "fresh",
        "age_label": "30s",
        "stale_after_seconds": 240,
        "source_stage": "",
        "reasons": ["host can stage context"],
        "adapter": {
            "adapter_kind": "native_extension",
            "supported_actions": ["notify", "stage_context"],
        },
        "budget_limited": False,
        "fallback_used": False,
    }

    def test_identical_packets_produce_same_signature(self):
        sig1 = cli_module._jolt_packet_signature(self._BASE_PACKET)
        sig2 = cli_module._jolt_packet_signature({**self._BASE_PACKET})
        assert sig1 == sig2

    def test_freshness_change_changes_signature(self):
        fresh_sig = cli_module._jolt_packet_signature(self._BASE_PACKET)
        stale_sig = cli_module._jolt_packet_signature(
            {**self._BASE_PACKET, "freshness": "stale", "age_label": "6m"}
        )
        assert fresh_sig != stale_sig

    def test_age_label_change_alone_does_not_change_signature(self):
        """age_label is display-only drift and should not retrigger a wake."""
        sig_30s = cli_module._jolt_packet_signature(self._BASE_PACKET)
        sig_2m = cli_module._jolt_packet_signature(
            {**self._BASE_PACKET, "age_label": "2m"}
        )
        assert sig_30s == sig_2m

    def test_source_stage_change_changes_signature(self):
        sig_no_stage = cli_module._jolt_packet_signature(self._BASE_PACKET)
        sig_reply_ready = cli_module._jolt_packet_signature(
            {**self._BASE_PACKET, "source_stage": "reply_ready"}
        )
        assert sig_no_stage != sig_reply_ready

    def test_headline_change_changes_signature(self):
        sig1 = cli_module._jolt_packet_signature(self._BASE_PACKET)
        sig2 = cli_module._jolt_packet_signature(
            {**self._BASE_PACKET, "headline": "2 assignments waiting"}
        )
        assert sig1 != sig2

    def test_budget_limited_flag_changes_signature(self):
        sig_normal = cli_module._jolt_packet_signature(self._BASE_PACKET)
        sig_limited = cli_module._jolt_packet_signature(
            {**self._BASE_PACKET, "budget_limited": True}
        )
        assert sig_normal != sig_limited

    def test_trigger_change_changes_signature(self):
        sig_assignment = cli_module._jolt_packet_signature(self._BASE_PACKET)
        sig_hot = cli_module._jolt_packet_signature(
            {**self._BASE_PACKET, "trigger": "hot_thread"}
        )
        assert sig_assignment != sig_hot

    def test_action_change_changes_signature(self):
        sig_stage = cli_module._jolt_packet_signature(self._BASE_PACKET)
        sig_notify = cli_module._jolt_packet_signature(
            {**self._BASE_PACKET, "action": "notify"}
        )
        assert sig_stage != sig_notify

    def test_none_packet_returns_none_signature(self):
        assert cli_module._jolt_packet_signature(None) is None

    def test_empty_dict_returns_tuple_not_none(self):
        """An empty dict is still a packet — it has a signature."""
        sig = cli_module._jolt_packet_signature({})
        assert sig is not None

    def test_server_time_utc_does_not_affect_signature(self):
        """server_time_utc is NOT part of the signature — timestamp-only
        changes should not trigger a watcher emission."""
        sig1 = cli_module._jolt_packet_signature(
            {**self._BASE_PACKET, "server_time_utc": "2026-03-30T17:30:43Z"}
        )
        sig2 = cli_module._jolt_packet_signature(
            {**self._BASE_PACKET, "server_time_utc": "2026-03-30T17:30:44Z"}
        )
        assert sig1 == sig2

    def test_version_field_does_not_affect_signature(self):
        sig1 = cli_module._jolt_packet_signature(
            {**self._BASE_PACKET, "version": "jolt-packet-v1"}
        )
        sig2 = cli_module._jolt_packet_signature(
            {**self._BASE_PACKET, "version": "jolt-packet-v2"}
        )
        assert sig1 == sig2


class TestPacketSignaturePressure:
    """Pressure scenarios — prove the signature doesn't produce false
    negatives (missed transitions) or false positives (spurious emissions)."""

    def test_full_lifecycle_fresh_to_stale_to_cleared(self):
        """Simulate the canonical 3-event lifecycle and verify each
        transition produces a distinct signature."""
        fresh_packet = {
            "action": "stage_context",
            "trigger": "direct_assignment",
            "headline": "1 assignment waiting",
            "priority": "priority",
            "freshness": "fresh",
            "age_label": "30s",
            "stale_after_seconds": 240,
            "reasons": ["host can stage context"],
            "adapter": {
                "adapter_kind": "native_extension",
                "supported_actions": ["notify", "stage_context"],
            },
        }
        stale_packet = {
            **fresh_packet,
            "freshness": "stale",
            "age_label": "6m",
            "source_stage": "reply_ready",
        }
        cleared_packet = None

        sig_fresh = cli_module._jolt_packet_signature(fresh_packet)
        sig_stale = cli_module._jolt_packet_signature(stale_packet)
        sig_cleared = cli_module._jolt_packet_signature(cleared_packet)

        # All three are distinct
        assert sig_fresh is not None
        assert sig_stale is not None
        assert sig_cleared is None
        assert sig_fresh != sig_stale

    def test_rapid_age_label_ticks_do_not_produce_distinct_signatures(self):
        """Rapid age drift must not create repeat wakes for the same signal."""
        base = {
            "action": "notify",
            "trigger": "hot_thread",
            "headline": "Reply from antigravity",
            "freshness": "fresh",
            "reasons": ["fallback"],
        }
        sigs = set()
        for label in ["30s", "1m", "2m", "3m"]:
            sig = cli_module._jolt_packet_signature({**base, "age_label": label})
            sigs.add(sig)
        assert len(sigs) == 1

    def test_two_different_agents_same_action_different_headline(self):
        """Packets from different agent contexts should have different
        signatures even if action/trigger match."""
        packet_a = {
            "action": "stage_context",
            "trigger": "direct_assignment",
            "headline": "antigravity needs review",
            "reasons": ["host can stage context"],
        }
        packet_b = {
            "action": "stage_context",
            "trigger": "direct_assignment",
            "headline": "codex needs review",
            "reasons": ["host can stage context"],
        }
        assert cli_module._jolt_packet_signature(packet_a) != cli_module._jolt_packet_signature(packet_b)
