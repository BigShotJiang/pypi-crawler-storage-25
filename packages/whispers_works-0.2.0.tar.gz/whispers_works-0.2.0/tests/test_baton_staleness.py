"""Baton staleness detection proof tests.

Proves that check_baton_staleness correctly identifies stale batons
before acceptance, surfacing actionable context instead of letting
agents blindly execute outdated work.
"""

from datetime import datetime, timezone, timedelta
from whispers.twoack import check_baton_staleness, _BATON_STALE_AGE_THRESHOLD, _BATON_VERY_STALE_AGE_THRESHOLD


def _now():
    return datetime(2026, 3, 30, 20, 0, 0, tzinfo=timezone.utc)


class TestBatonAgeDetection:

    def test_fresh_baton_is_not_stale(self):
        report = check_baton_staleness(
            baton_created_at=_now() - timedelta(minutes=5),
            baton_updated_at=None,
            owner_callsign="codex",
            now=_now(),
        )
        assert report.stale is False
        assert report.reasons == []

    def test_30_minute_baton_is_stale(self):
        report = check_baton_staleness(
            baton_created_at=_now() - timedelta(seconds=_BATON_STALE_AGE_THRESHOLD),
            baton_updated_at=None,
            owner_callsign="codex",
            now=_now(),
        )
        assert report.stale is True
        assert any("30m" in r for r in report.reasons)

    def test_2_hour_baton_is_very_stale(self):
        report = check_baton_staleness(
            baton_created_at=_now() - timedelta(seconds=_BATON_VERY_STALE_AGE_THRESHOLD),
            baton_updated_at=None,
            owner_callsign="codex",
            now=_now(),
        )
        assert report.stale is True
        assert any("significantly changed" in r for r in report.reasons)
        assert "codex" in report.suggested_action

    def test_updated_at_resets_age(self):
        """If the baton was updated recently, age counts from update, not creation."""
        report = check_baton_staleness(
            baton_created_at=_now() - timedelta(hours=3),
            baton_updated_at=_now() - timedelta(minutes=5),
            owner_callsign="codex",
            now=_now(),
        )
        assert report.stale is False

    def test_age_label_formats_correctly(self):
        report = check_baton_staleness(
            baton_created_at=_now() - timedelta(minutes=45),
            baton_updated_at=None,
            owner_callsign="codex",
            now=_now(),
        )
        assert report.age_label == "45m"

    def test_age_label_hours(self):
        report = check_baton_staleness(
            baton_created_at=_now() - timedelta(hours=3),
            baton_updated_at=None,
            owner_callsign="codex",
            now=_now(),
        )
        assert "h" in report.age_label

    def test_string_timestamp_parsing(self):
        created = (_now() - timedelta(hours=1)).isoformat()
        report = check_baton_staleness(
            baton_created_at=created,
            baton_updated_at=None,
            owner_callsign="codex",
            now=_now(),
        )
        assert report.stale is True
        assert report.age_seconds >= 3600


class TestOwnerStateDetection:

    def test_owner_blocked_flags_staleness(self):
        report = check_baton_staleness(
            baton_created_at=_now() - timedelta(minutes=10),
            baton_updated_at=None,
            owner_callsign="codex",
            owner_current_state={"readiness": "blocked"},
            now=_now(),
        )
        assert report.stale is True
        assert any("blocked" in r for r in report.reasons)

    def test_owner_paused_flags_staleness(self):
        report = check_baton_staleness(
            baton_created_at=_now() - timedelta(minutes=10),
            baton_updated_at=None,
            owner_callsign="codex",
            owner_current_state={"readiness": "paused_by_operator"},
            now=_now(),
        )
        assert report.stale is True
        assert any("paused_by_operator" in r for r in report.reasons)

    def test_owner_ready_does_not_flag(self):
        report = check_baton_staleness(
            baton_created_at=_now() - timedelta(minutes=10),
            baton_updated_at=None,
            owner_callsign="codex",
            owner_current_state={"readiness": "ready"},
            now=_now(),
        )
        assert report.stale is False

    def test_owner_busy_does_not_flag(self):
        report = check_baton_staleness(
            baton_created_at=_now() - timedelta(minutes=10),
            baton_updated_at=None,
            owner_callsign="codex",
            owner_current_state={"readiness": "busy", "current_task": "something else"},
            now=_now(),
        )
        assert report.stale is False


class TestFileLeaseCollisionDetection:

    def test_leased_files_flag_staleness(self):
        report = check_baton_staleness(
            baton_created_at=_now() - timedelta(minutes=5),
            baton_updated_at=None,
            owner_callsign="codex",
            active_file_leases=["whispers/client.py", "whispers/server.py"],
            now=_now(),
        )
        assert report.stale is True
        assert any("leased" in r for r in report.reasons)
        assert "client.py" in report.reasons[0]

    def test_no_leases_no_flag(self):
        report = check_baton_staleness(
            baton_created_at=_now() - timedelta(minutes=5),
            baton_updated_at=None,
            owner_callsign="codex",
            active_file_leases=[],
            now=_now(),
        )
        assert report.stale is False

    def test_lease_list_truncates_at_three(self):
        report = check_baton_staleness(
            baton_created_at=_now() - timedelta(minutes=5),
            baton_updated_at=None,
            owner_callsign="codex",
            active_file_leases=["a.py", "b.py", "c.py", "d.py", "e.py"],
            now=_now(),
        )
        lease_reason = [r for r in report.reasons if "leased" in r][0]
        assert "d.py" not in lease_reason
        assert "e.py" not in lease_reason


class TestCompoundStaleness:

    def test_age_plus_owner_state_compounds(self):
        report = check_baton_staleness(
            baton_created_at=_now() - timedelta(hours=1),
            baton_updated_at=None,
            owner_callsign="codex",
            owner_current_state={"readiness": "blocked"},
            now=_now(),
        )
        assert report.stale is True
        assert len(report.reasons) == 2

    def test_age_plus_leases_compounds(self):
        report = check_baton_staleness(
            baton_created_at=_now() - timedelta(hours=1),
            baton_updated_at=None,
            owner_callsign="codex",
            active_file_leases=["whispers/dispatcher.py"],
            now=_now(),
        )
        assert report.stale is True
        assert len(report.reasons) == 2

    def test_all_three_compound(self):
        report = check_baton_staleness(
            baton_created_at=_now() - timedelta(hours=3),
            baton_updated_at=None,
            owner_callsign="codex",
            owner_current_state={"readiness": "degraded"},
            active_file_leases=["whispers/client.py"],
            now=_now(),
        )
        assert report.stale is True
        assert len(report.reasons) == 3


class TestSuggestedAction:

    def test_very_stale_suggests_checking_with_owner(self):
        report = check_baton_staleness(
            baton_created_at=_now() - timedelta(hours=3),
            baton_updated_at=None,
            owner_callsign="antigravity",
            now=_now(),
        )
        assert "antigravity" in report.suggested_action
        assert "fresh assignment" in report.suggested_action

    def test_moderately_stale_suggests_review(self):
        report = check_baton_staleness(
            baton_created_at=_now() - timedelta(minutes=35),
            baton_updated_at=None,
            owner_callsign="codex",
            now=_now(),
        )
        assert "swarm state" in report.suggested_action

    def test_fresh_has_no_suggestion(self):
        report = check_baton_staleness(
            baton_created_at=_now() - timedelta(minutes=5),
            baton_updated_at=None,
            owner_callsign="codex",
            now=_now(),
        )
        assert report.suggested_action == ""


class TestReportSerialization:

    def test_to_dict_includes_all_fields_when_stale(self):
        report = check_baton_staleness(
            baton_created_at=_now() - timedelta(hours=1),
            baton_updated_at=None,
            owner_callsign="codex",
            owner_current_state={"readiness": "blocked"},
            now=_now(),
        )
        d = report.to_dict()
        assert d["stale"] is True
        assert "reasons" in d
        assert "suggested_action" in d
        assert d["age_seconds"] >= 3600

    def test_to_dict_omits_empty_fields_when_fresh(self):
        report = check_baton_staleness(
            baton_created_at=_now() - timedelta(minutes=5),
            baton_updated_at=None,
            owner_callsign="codex",
            now=_now(),
        )
        d = report.to_dict()
        assert d["stale"] is False
        assert "reasons" not in d
        assert "suggested_action" not in d
