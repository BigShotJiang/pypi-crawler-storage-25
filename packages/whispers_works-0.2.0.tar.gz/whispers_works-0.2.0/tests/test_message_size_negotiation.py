import asyncio
import importlib
import sys

from fastapi.testclient import TestClient

from whispers.client import WhispersClient
from whispers.context_cost import ContextCostRecipient, negotiate_message_size


def test_negotiation_prefers_layered_summary_for_loaded_recipient():
    result = negotiate_message_size(
        ContextCostRecipient(
            "claude-code",
            model_id="claude-sonnet",
            context_load=0.72,
            interruptibility="urgent_only",
        ),
        subject="Execution packet",
        body="detail " * 4000,
        summary="Execution packet summary",
    )
    assert result.recommended_delivery_depth == "summarize"
    assert result.suggested_transport == "layered_send"
    assert result.missing_layers == []


def test_negotiation_prefers_artifact_reference_for_large_payload_without_summary():
    result = negotiate_message_size(
        ContextCostRecipient(
            "codex",
            model_id="gemini-2.5-pro",
            context_load=0.05,
        ),
        subject="Large packet",
        body="blob " * 100000,
    )
    assert result.suggested_transport == "artifact_reference"
    assert "summary" in result.missing_layers


def test_local_client_message_size_check_uses_recipient_runtime(temp_db, monkeypatch):
    monkeypatch.setenv("WHISPERS_RUNTIME_STATE_PATH", temp_db + "-runtime.json")
    sender = WhispersClient("sender", db_path=temp_db)
    recipient = WhispersClient("recipient", db_path=temp_db, model_id="claude-sonnet")
    recipient.update_cognitive_heartbeat(
        {
            "context_load": 0.91,
            "interruptibility": "do_not_interrupt",
        }
    )

    result = sender.message_size_check(
        to="recipient",
        subject="Need review",
        body="details " * 1000,
        headline="Need review",
    )
    assert result["recommended_delivery_depth"] == "headline_only"
    assert result["suggested_transport"] == "layered_send"
    assert result["missing_layers"] == []


def test_server_message_size_check_endpoint(temp_db, monkeypatch):
    runtime_state_path = temp_db + "-runtime.json"

    with monkeypatch.context() as mp:
        mp.setenv("WHISPERS_DB_PATH", temp_db)
        mp.setenv("WHISPERS_RUNTIME_STATE_PATH", runtime_state_path)
        mp.setenv("WHISPERS_REMOTE_ADMISSION_MODE", "open")

        import whispers.server as server_module

        server_module = importlib.reload(server_module)
        with TestClient(server_module.app) as api:
            sender = api.post("/connect", json={"agent_name": "sender"}).json()
            recipient = api.post(
                "/connect",
                json={"agent_name": "recipient", "client": {"version": "claude-sonnet"}},
            ).json()

            heartbeat = api.post(
                "/heartbeat",
                json={"context_load": 0.88, "interruptibility": "do_not_interrupt"},
                headers={"Authorization": f"Bearer {recipient['token']}"},
            )
            assert heartbeat.status_code == 200

            response = api.post(
                "/message:size-check",
                json={
                    "to": "recipient",
                    "subject": "Need review",
                    "body": "details " * 2000,
                    "headline": "Need review",
                },
                headers={"Authorization": f"Bearer {sender['token']}"},
            )
            assert response.status_code == 200
            payload = response.json()
            assert payload["recommended_delivery_depth"] == "headline_only"
            assert payload["suggested_transport"] == "layered_send"
            assert payload["recipient"] == "recipient"


def test_mcp_message_size_check_tool(temp_db, monkeypatch):
    monkeypatch.setenv("WHISPERS_DB_PATH", temp_db)
    monkeypatch.setenv("WHISPERS_RUNTIME_STATE_PATH", temp_db + "-runtime.json")
    import whispers.mcp_server as module

    module = importlib.reload(module)
    module._clients.clear()

    recipient = WhispersClient("claude-code", db_path=temp_db, model_id="claude-sonnet")
    recipient.update_cognitive_heartbeat(
        {
            "context_load": 0.78,
            "interruptibility": "urgent_only",
        }
    )

    token = module.current_agent_name.set("codex")
    try:
        result = asyncio.run(
            module.handle_tool(
                "message_size_check",
                {
                    "to": "claude-code",
                    "subject": "Execution packet",
                    "body": "details " * 4000,
                    "summary": "Execution packet summary",
                },
            )
        )
        assert "RECOMMEND: summarize via layered_send to claude-code" in result[0].text
    finally:
        module.current_agent_name.reset(token)
        module._clients.clear()
