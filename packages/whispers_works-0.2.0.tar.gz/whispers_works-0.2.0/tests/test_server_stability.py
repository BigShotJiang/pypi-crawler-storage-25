import importlib
import sqlite3
import subprocess
import sys
import time

from fastapi.testclient import TestClient

from whispers import client as client_module
from whispers.storage import db as db_module


class _HTTPResponse:
    def __init__(self, status: int = 200):
        self.status = status

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        return False


def test_status_uses_livez_for_http_reachability(monkeypatch, temp_db):
    monkeypatch.setenv("WHISPERS_DB_PATH", temp_db)
    urls = []

    def fake_urlopen(url, timeout=0):
        urls.append(url)
        if url == "http://127.0.0.1:8752/readyz":
            payload = {"db_path": temp_db, "ok": True}
            class _ReadyzResponse(_HTTPResponse):
                def read(self_inner):
                    import json
                    return json.dumps(payload).encode("utf-8")
            return _ReadyzResponse(200)
        assert url == "http://127.0.0.1:8752/livez"
        return _HTTPResponse(200)

    monkeypatch.setattr(client_module.urllib.request, "urlopen", fake_urlopen)

    client = client_module.WhispersClient("alpha", db_path=temp_db)
    status = client.status()

    assert status["http_server_reachable"] is True
    assert set(urls) == {"http://127.0.0.1:8752/readyz", "http://127.0.0.1:8752/livez"}


def test_autostart_waits_for_existing_booting_server_without_spawning(monkeypatch, temp_dir):
    pid_path = temp_dir / "server.pid"
    lock_path = temp_dir / ".server-autostart-lock"
    pid_path.write_text("123", encoding="utf-8")

    probe_results = iter([False, True])
    popen_calls = []

    monkeypatch.setattr(client_module, "_PID_FILE_PATH", str(pid_path))
    monkeypatch.setattr(client_module, "_AUTOSTART_LOCK_PATH", str(lock_path))
    monkeypatch.setattr(client_module, "_AUTOSTART_WAIT_SECONDS", 1.0)
    monkeypatch.setattr(client_module, "_read_server_pid", lambda: 123)
    monkeypatch.setattr(client_module, "_is_pid_alive", lambda pid: True)
    monkeypatch.setattr(client_module.time, "sleep", lambda _: None)
    monkeypatch.setattr(
        client_module,
        "_probe_http_server",
        lambda url=client_module._LIVEZ_URL, timeout=1.0: next(probe_results, True),
    )
    monkeypatch.setattr(subprocess, "Popen", lambda *args, **kwargs: popen_calls.append((args, kwargs)))

    assert client_module._try_autostart_server() is True
    assert popen_calls == []


def test_health_endpoint_does_not_write_runtime_state_on_routine_poll(monkeypatch, temp_db):
    runtime_state_path = temp_db + "-runtime.json"
    original_module = sys.modules.get("whispers.server")
    original_db = getattr(original_module, "db", None) if original_module else None

    with monkeypatch.context() as mp:
        mp.setenv("WHISPERS_DB_PATH", temp_db)
        mp.setenv("WHISPERS_RUNTIME_STATE_PATH", runtime_state_path)

        import whispers.server as server_module

        server_module = importlib.reload(server_module)
        write_calls = []
        mp.setattr(
            server_module,
            "_write_runtime_state",
            lambda payload: write_calls.append(payload.copy()),
        )

        with TestClient(server_module.app) as client:
            write_calls.clear()
            first = client.get("/health")
            second = client.get("/health")

        assert first.status_code == 200
        assert second.status_code == 200
        assert write_calls == []

    if original_db is not None:
        server_module.db = original_db


def test_importing_server_defers_runtime_bootstrap(monkeypatch, temp_db):
    runtime_state_path = temp_db + "-runtime.json"

    def fail_on_init(self, *args, **kwargs):
        raise AssertionError("WhispersDB initialized during import")

    with monkeypatch.context() as mp:
        mp.setenv("WHISPERS_DB_PATH", temp_db)
        mp.setenv("WHISPERS_RUNTIME_STATE_PATH", runtime_state_path)
        mp.setattr(db_module.WhispersDB, "__init__", fail_on_init)

        import whispers.server as server_module

        server_module = importlib.reload(server_module)
        assert server_module.app is not None
        assert server_module._server_runtime._initialized is False


def test_check_write_ready_can_fail_fast_on_locked_db(temp_db):
    db = db_module.WhispersDB(temp_db)
    lock_conn = sqlite3.connect(temp_db, timeout=10.0)
    lock_conn.execute("PRAGMA busy_timeout=10000")
    lock_conn.execute("BEGIN IMMEDIATE")

    try:
        started = time.monotonic()
        ready, error = db.check_write_ready(timeout_ms=0)
        elapsed = time.monotonic() - started
    finally:
        lock_conn.rollback()
        lock_conn.close()

    assert ready is False
    assert error is not None and "locked" in error.lower()
    assert elapsed < 1.0


def test_health_and_readyz_use_fast_write_ready_probe(monkeypatch, temp_db):
    runtime_state_path = temp_db + "-runtime.json"

    with monkeypatch.context() as mp:
        mp.setenv("WHISPERS_DB_PATH", temp_db)
        mp.setenv("WHISPERS_RUNTIME_STATE_PATH", runtime_state_path)

        import whispers.server as server_module

        server_module = importlib.reload(server_module)
        observed = []
        original = server_module.db.check_write_ready

        def wrapped_check_write_ready(*, timeout_ms=None):
            observed.append(timeout_ms)
            return original(timeout_ms=timeout_ms)

        mp.setattr(server_module.db, "check_write_ready", wrapped_check_write_ready)

        with TestClient(server_module.app) as client:
            health = client.get("/health")
            readyz = client.get("/readyz")

        assert health.status_code == 200
        assert readyz.status_code == 200
        assert observed
        assert all(timeout == server_module._HEALTH_DB_WRITE_READY_TIMEOUT_MS for timeout in observed)
