"""Tests for collaboration health signal detection.

Covers all four signal types + false-positive guards from the spec:
  T1: Stalled handoff detection
  T2: Stalled handoff clears on ack
  T3: Bad-timing interruption
  T4: Missing challenge in workspace
  T5: Solo workspace — no false positive (FP-HS2)
  FP-HS1: Stalled handoff doesn't fire for offline recipients
  FP-HS3: Bad-timing doesn't fire for operator-sent messages
  FP-HS4: Stale availability suppressed by recent high context_load
"""

import time
from unittest.mock import patch

from whispers.client import WhispersClient
from whispers.collaboration_health import (
    CollaborationHealthScanner,
    HealthSignal,
    Severity,
    check_bad_timing,
    clamp_confidence,
)
from whispers.storage.db import WhispersDB


def _make_scanner(db_path: str) -> CollaborationHealthScanner:
    db = WhispersDB(db_path=db_path)
    return CollaborationHealthScanner(db)


# ---------------------------------------------------------------------------
# T1: Stalled handoff detection
# ---------------------------------------------------------------------------

def test_stalled_handoff_detected(temp_db):
    """A handoff sent > 15 min ago with online recipient and no ack triggers a signal."""
    claude = WhispersClient("claude-code", db_path=temp_db)
    codex = WhispersClient("codex", db_path=temp_db)

    claude.send_handoff(
        "codex",
        objective="Build something",
        deliverable="SPEC.md",
        completed="Nothing",
        remaining="Everything",
        next_action="Start building",
    )

    # Backdate the handoff message to 20 minutes ago
    db = WhispersDB(db_path=temp_db)
    with db.get_connection() as conn:
        conn.execute("""
            UPDATE messages
            SET created_at = datetime('now', '-20 minutes')
            WHERE from_agent = 'claude-code' AND to_agent = 'codex'
        """)
        conn.commit()

    scanner = CollaborationHealthScanner(db)
    signals = scanner.scan()

    stalled = [s for s in signals if s.signal == "stalled_handoff"]
    assert len(stalled) == 1
    assert stalled[0].severity == Severity.WARNING
    assert stalled[0].details["sender"] == "claude-code"
    assert stalled[0].details["recipient"] == "codex"
    assert stalled[0].details["stalled_minutes"] >= 19


# ---------------------------------------------------------------------------
# T2: Stalled handoff clears when acked
# ---------------------------------------------------------------------------

def test_stalled_handoff_clears_on_read(temp_db):
    """Once the recipient reads the handoff, the signal should disappear."""
    claude = WhispersClient("claude-code", db_path=temp_db)
    codex = WhispersClient("codex", db_path=temp_db)

    claude.send_handoff(
        "codex",
        objective="Build something",
        deliverable="SPEC.md",
        completed="Nothing",
        remaining="Everything",
        next_action="Start",
    )

    db = WhispersDB(db_path=temp_db)
    with db.get_connection() as conn:
        conn.execute("""
            UPDATE messages
            SET created_at = datetime('now', '-20 minutes')
            WHERE from_agent = 'claude-code' AND to_agent = 'codex'
        """)
        conn.commit()

    scanner = CollaborationHealthScanner(db)
    signals = scanner.scan()
    assert any(s.signal == "stalled_handoff" for s in signals)

    # Codex reads the handoff — set read_at on message_recipients
    with db.get_connection() as conn:
        conn.execute("""
            UPDATE message_recipients
            SET read_at = CURRENT_TIMESTAMP
            WHERE recipient_callsign = 'codex'
        """)
        conn.commit()

    signals2 = scanner.scan()
    # After dedup, stalled_handoff should be cleared
    active = scanner.get_active_signals()
    stalled = [s for s in active if s.signal == "stalled_handoff"]
    assert len(stalled) == 0


# ---------------------------------------------------------------------------
# FP-HS1: Stalled handoff doesn't fire for offline recipients
# ---------------------------------------------------------------------------

def test_stalled_handoff_not_for_offline_recipient(temp_db):
    """If recipient is offline, no stalled handoff signal."""
    claude = WhispersClient("claude-code", db_path=temp_db)
    # Register codex but don't connect (offline)
    db = WhispersDB(db_path=temp_db)
    with db.get_connection() as conn:
        conn.execute(
            "INSERT OR IGNORE INTO presence (agent_name, status) VALUES (?, ?)",
            ("codex", "offline"),
        )
        conn.commit()

    claude.send_handoff(
        "codex",
        objective="Build something",
        deliverable="SPEC.md",
        completed="Nothing",
        remaining="Everything",
        next_action="Start",
    )

    with db.get_connection() as conn:
        conn.execute("""
            UPDATE messages
            SET created_at = datetime('now', '-20 minutes')
            WHERE from_agent = 'claude-code' AND to_agent = 'codex'
        """)
        # Ensure codex is offline
        conn.execute("UPDATE presence SET status = 'offline' WHERE agent_name = 'codex'")
        conn.commit()

    scanner = CollaborationHealthScanner(db)
    signals = scanner.scan()
    stalled = [s for s in signals if s.signal == "stalled_handoff"]
    assert len(stalled) == 0


# ---------------------------------------------------------------------------
# T3: Bad-timing interruption
# ---------------------------------------------------------------------------

def test_bad_timing_interruption_detected(temp_db):
    """Routine message to do_not_interrupt agent produces a signal."""
    from whispers.envelope import Envelope, Priority

    envelope = Envelope(
        sender="antigravity",
        recipient="codex",
        msg_type="inform",
        subject="Quick question",
        priority=Priority.ROUTINE,
    )

    recipient_state = {
        "interruptibility": "do_not_interrupt",
        "quality_risk": "low",
    }

    signal = check_bad_timing(envelope, recipient_state)
    assert signal is not None
    assert signal.signal == "bad_timing_interruption"
    assert signal.details["sender"] == "antigravity"
    assert signal.details["recipient"] == "codex"
    assert signal.confidence >= 0.7


def test_bad_timing_not_for_flash_priority(temp_db):
    """Flash priority messages should NOT trigger bad-timing."""
    from whispers.envelope import Envelope, Priority

    envelope = Envelope(
        sender="antigravity",
        recipient="codex",
        msg_type="inform",
        subject="Urgent!",
        priority=Priority.FLASH,
    )

    recipient_state = {"interruptibility": "do_not_interrupt"}
    signal = check_bad_timing(envelope, recipient_state)
    assert signal is None


# ---------------------------------------------------------------------------
# FP-HS3: Bad-timing doesn't fire for operator-sent messages
# ---------------------------------------------------------------------------

def test_bad_timing_not_for_operator(temp_db):
    """Operator-sent messages should not trigger bad-timing."""
    from whispers.envelope import Envelope, Priority

    envelope = Envelope(
        sender="operator",
        recipient="codex",
        msg_type="inform",
        subject="Check in",
        priority=Priority.ROUTINE,
    )

    recipient_state = {"interruptibility": "do_not_interrupt"}
    signal = check_bad_timing(envelope, recipient_state)
    assert signal is None


def test_bad_timing_higher_confidence_when_quality_risk_high():
    """Quality risk 'high' bumps confidence by 0.2."""
    from whispers.envelope import Envelope, Priority

    envelope = Envelope(
        sender="antigravity",
        recipient="codex",
        msg_type="inform",
        subject="Hey",
        priority=Priority.ROUTINE,
    )

    signal = check_bad_timing(envelope, {
        "interruptibility": "urgent_only",
        "quality_risk": "high",
    })
    assert signal is not None
    assert signal.confidence >= 0.89


# ---------------------------------------------------------------------------
# T4: Missing challenge in workspace
# ---------------------------------------------------------------------------

def test_missing_challenge_detected(temp_db):
    """Unchallenged decision in a multi-member workspace triggers signal."""
    claude = WhispersClient("claude-code", db_path=temp_db)
    codex = WhispersClient("codex", db_path=temp_db)

    ws = claude.create_workspace(purpose="Design review", members=["codex"])
    ws_id = ws["workspace_id"]
    codex.join_workspace(ws_id)

    claude.send_workspace_delta(ws_id, delta_kind="decision", text="Going with SSE over WebSocket")

    # Backdate the decision to 20 minutes ago
    db = WhispersDB(db_path=temp_db)
    with db.get_connection() as conn:
        conn.execute("""
            UPDATE workspace_events
            SET created_at = datetime('now', '-20 minutes')
            WHERE workspace_id = ? AND delta_kind = 'decision'
        """, (ws_id,))
        conn.commit()

    scanner = CollaborationHealthScanner(db)
    signals = scanner.scan()

    missing = [s for s in signals if s.signal == "missing_challenge"]
    assert len(missing) >= 1
    assert missing[0].details["decision_actor"] == "claude-code"


# ---------------------------------------------------------------------------
# T5: Solo workspace — FP-HS2 (no false positive)
# ---------------------------------------------------------------------------

def test_missing_challenge_not_for_solo_workspace(temp_db):
    """Single-member workspace decisions should NOT trigger missing challenge."""
    claude = WhispersClient("claude-code", db_path=temp_db)

    ws = claude.create_workspace(purpose="Solo work")
    ws_id = ws["workspace_id"]

    claude.send_workspace_delta(ws_id, delta_kind="decision", text="Using Redis")

    db = WhispersDB(db_path=temp_db)
    with db.get_connection() as conn:
        conn.execute("""
            UPDATE workspace_events
            SET created_at = datetime('now', '-20 minutes')
            WHERE workspace_id = ? AND delta_kind = 'decision'
        """, (ws_id,))
        conn.commit()

    scanner = CollaborationHealthScanner(db)
    signals = scanner.scan()

    missing = [s for s in signals if s.signal == "missing_challenge"]
    assert len(missing) == 0


# ---------------------------------------------------------------------------
# Stale availability + FP-HS4
# ---------------------------------------------------------------------------

def test_stale_availability_detected(temp_db):
    """Agent still 'busy' after completing work triggers stale_availability."""
    claude = WhispersClient("claude-code", db_path=temp_db)
    claude.set_readiness("busy", current_task="Building feature")

    db = WhispersDB(db_path=temp_db)
    with db.get_connection() as conn:
        # Set last_progress_at to 15 minutes ago
        conn.execute("""
            UPDATE agent_runtime_state
            SET last_progress_at = datetime('now', '-15 minutes')
            WHERE agent_name = 'claude-code'
        """)
        conn.commit()

    scanner = CollaborationHealthScanner(db)
    signals = scanner.scan()

    stale = [s for s in signals if s.signal == "stale_availability"]
    assert len(stale) == 1
    assert stale[0].details["agent"] == "claude-code"
    assert stale[0].details["current_readiness"] == "busy"


def test_stale_availability_suppressed_by_high_context_load(temp_db):
    """FP-HS4: If context_load > 0.5, suppress stale_availability."""
    claude = WhispersClient("claude-code", db_path=temp_db)
    claude.set_readiness("busy", current_task="Deep work")

    db = WhispersDB(db_path=temp_db)
    with db.get_connection() as conn:
        conn.execute("""
            UPDATE agent_runtime_state
            SET last_progress_at = datetime('now', '-15 minutes'),
                context_load = 0.8
            WHERE agent_name = 'claude-code'
        """)
        conn.commit()

    scanner = CollaborationHealthScanner(db)
    signals = scanner.scan()

    stale = [s for s in signals if s.signal == "stale_availability"]
    # Signal might still appear but with very low confidence (0.5 - 0.3 = 0.2)
    # Either no signal or confidence < 0.5
    for s in stale:
        if s.details["agent"] == "claude-code":
            assert s.confidence <= 0.5


# ---------------------------------------------------------------------------
# Signal deduplication
# ---------------------------------------------------------------------------

def test_deduplication_returns_only_changed(temp_db):
    """Second scan with same signals should return empty (no changes)."""
    db = WhispersDB(db_path=temp_db)
    scanner = CollaborationHealthScanner(db)

    # Manually inject signals for dedup testing
    s1 = HealthSignal(
        signal="stalled_handoff",
        severity=Severity.WARNING,
        confidence=0.8,
        suggestion="test",
        details={"handoff_uuid": "abc123"},
    )

    # First pass: should register as new
    changed = scanner._deduplicate_and_update([s1])
    assert len(changed) == 1

    # Second pass with same signal: no changes
    changed = scanner._deduplicate_and_update([s1])
    assert len(changed) == 0


def test_deduplication_detects_severity_change(temp_db):
    """If severity escalates, it should show up as changed."""
    db = WhispersDB(db_path=temp_db)
    scanner = CollaborationHealthScanner(db)

    s1 = HealthSignal(
        signal="stalled_handoff",
        severity=Severity.WARNING,
        confidence=0.8,
        suggestion="test",
        details={"handoff_uuid": "abc123"},
    )
    scanner._deduplicate_and_update([s1])

    s2 = HealthSignal(
        signal="stalled_handoff",
        severity=Severity.ESCALATE,
        confidence=0.9,
        suggestion="test escalated",
        details={"handoff_uuid": "abc123"},
    )
    changed = scanner._deduplicate_and_update([s2])
    assert len(changed) == 1
    assert changed[0].severity == Severity.ESCALATE


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def test_clamp_confidence():
    assert clamp_confidence(1.5) == 1.0
    assert clamp_confidence(-0.3) == 0.0
    assert clamp_confidence(0.7) == 0.7


def test_signal_id_format():
    s = HealthSignal(
        signal="stalled_handoff",
        severity=Severity.WARNING,
        confidence=0.8,
        suggestion="test",
        details={"handoff_uuid": "msg-42"},
    )
    assert s.signal_id == "stalled_handoff:msg-42"


def test_to_dict_includes_signal_id():
    s = HealthSignal(
        signal="bad_timing_interruption",
        severity=Severity.INFO,
        confidence=0.7,
        suggestion="test",
        details={"message_uuid": "msg-99"},
    )
    d = s.to_dict()
    assert d["signal_id"] == "bad_timing:msg-99"
    assert d["severity"] == "info"
