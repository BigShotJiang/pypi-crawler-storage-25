"""Tests for metadata minimization (security item #9).

Covers:
- Internal DB fields stripped
- Routing policy metadata stripped
- Agent-relevant fields preserved
- Scope redaction flags preserved (agents need to know content was redacted)
- Working scope preserved
- Empty/null metadata handled gracefully
- String and dict metadata formats both handled
"""

import json
import pytest
from whispers.metadata_minimization import sanitize_message, sanitize_messages


class TestMetadataMinimization:
    def _make_message(self, **overrides):
        """Create a realistic message dict like what INBOX_SELECT_COLS returns."""
        msg = {
            "uuid": "test-uuid-123",
            "from_agent": "alice",
            "to_agent": "bob",
            "recipient_callsign": "bob",
            "context_id": "ctx-456",
            "msg_type": "inform",
            "content_type": "text/plain",
            "subject": "Hello",
            "body": "Message body here",
            "payload": None,
            "priority": "routine",
            "status": "new",
            "reply_to": None,
            "trace_id": "trace-789",
            "ttl_seconds": 3600,
            "idempotency_key": "idem-key-abc",
            "metadata": json.dumps({
                "whispers_audience_scope": "direct",
                "whispers_visibility_mode": "normal",
                "whispers_memory_mode": "thread",
                "user_key": "user_value",
            }),
            "created_at": "2026-03-29T19:00:00Z",
            "seen_at": "2026-03-29T19:01:00Z",
            "negotiation_id": "neg-001",
            "turn_number": 1,
            "turns_total": 3,
            "delivery_status": "delivered",
            "claimed_by": "transport-1",
            "claimed_at": "2026-03-29T19:00:01Z",
            "read_at": "2026-03-29T19:01:00Z",
            "ack_state": "acked",
            "ack_detail": "auto-ack",
            "acked_by": "bob",
            "acked_at": "2026-03-29T19:01:01Z",
            "pinned_at": None,
            "snoozed_until": None,
            "archived_at": None,
            "recipient_row_id": 42,
        }
        msg.update(overrides)
        return msg

    def test_strips_db_internal_fields(self):
        msg = self._make_message()
        result = sanitize_message(msg)
        assert "recipient_row_id" not in result
        assert "claimed_by" not in result
        assert "claimed_at" not in result

    def test_strips_protocol_internals(self):
        msg = self._make_message()
        result = sanitize_message(msg)
        assert "negotiation_id" not in result
        assert "turn_number" not in result
        assert "turns_total" not in result
        assert "idempotency_key" not in result

    def test_strips_inbox_management(self):
        msg = self._make_message()
        result = sanitize_message(msg)
        assert "pinned_at" not in result
        assert "snoozed_until" not in result
        assert "archived_at" not in result
        assert "acked_by" not in result
        assert "acked_at" not in result
        assert "ack_detail" not in result

    def test_strips_tracking_fields(self):
        msg = self._make_message()
        result = sanitize_message(msg)
        assert "seen_at" not in result
        assert "ttl_seconds" not in result
        assert "content_type" not in result
        assert "recipient_callsign" not in result

    def test_preserves_agent_relevant_fields(self):
        msg = self._make_message()
        result = sanitize_message(msg)
        assert result["uuid"] == "test-uuid-123"
        assert result["from_agent"] == "alice"
        assert result["to_agent"] == "bob"
        assert result["subject"] == "Hello"
        assert result["body"] == "Message body here"
        assert result["priority"] == "routine"
        assert result["msg_type"] == "inform"
        assert result["context_id"] == "ctx-456"
        assert result["trace_id"] == "trace-789"
        assert result["created_at"] == "2026-03-29T19:00:00Z"
        assert result["delivery_status"] == "delivered"
        assert result["read_at"] == "2026-03-29T19:01:00Z"
        assert result["ack_state"] == "acked"
        assert result["status"] == "new"

    def test_strips_routing_policy_metadata(self):
        msg = self._make_message()
        result = sanitize_message(msg)
        meta = json.loads(result["metadata"])
        assert "whispers_audience_scope" not in meta
        assert "whispers_visibility_mode" not in meta
        assert "whispers_memory_mode" not in meta

    def test_preserves_user_metadata(self):
        msg = self._make_message()
        result = sanitize_message(msg)
        meta = json.loads(result["metadata"])
        assert meta["user_key"] == "user_value"

    def test_preserves_scope_redaction_flags(self):
        msg = self._make_message(metadata=json.dumps({
            "whispers_audience_scope": "direct",
            "whispers:scope_redacted": True,
            "whispers:scope_redaction_reason": "non_member_workspace_delivery",
            "whispers:scope_redaction_mode": "full_redaction",
            "whispers:workspace_id": "ws_123",
        }))
        result = sanitize_message(msg)
        meta = json.loads(result["metadata"])
        assert meta["whispers:scope_redacted"] is True
        assert meta["whispers:scope_redaction_reason"] == "non_member_workspace_delivery"
        assert meta["whispers:scope_redaction_mode"] == "full_redaction"
        assert "whispers_audience_scope" not in meta

    def test_preserves_working_scope(self):
        msg = self._make_message(metadata=json.dumps({
            "whispers:working_scope": "ws_alpha",
            "whispers_audience_scope": "direct",
        }))
        result = sanitize_message(msg)
        meta = json.loads(result["metadata"])
        assert meta["whispers:working_scope"] == "ws_alpha"
        assert "whispers_audience_scope" not in meta

    def test_strips_internal_prefixed_metadata(self):
        msg = self._make_message(metadata=json.dumps({
            "whispers:internal_routing_decision": "round_robin",
            "whispers:delivery_attempt_count": 3,
            "whispers:trust_score_at_delivery": 0.95,
            "user_data": "kept",
        }))
        result = sanitize_message(msg)
        meta = json.loads(result["metadata"])
        assert "whispers:internal_routing_decision" not in meta
        assert "whispers:delivery_attempt_count" not in meta
        assert "whispers:trust_score_at_delivery" not in meta
        assert meta["user_data"] == "kept"

    def test_handles_null_metadata(self):
        msg = self._make_message(metadata=None)
        result = sanitize_message(msg)
        assert result.get("metadata") is None

    def test_handles_empty_metadata_string(self):
        msg = self._make_message(metadata="{}")
        result = sanitize_message(msg)
        assert json.loads(result["metadata"]) == {}

    def test_handles_dict_metadata(self):
        """When metadata is already parsed as a dict (not JSON string)."""
        msg = self._make_message(metadata={
            "whispers_audience_scope": "direct",
            "user_key": "value",
        })
        result = sanitize_message(msg)
        assert isinstance(result["metadata"], dict)
        assert "whispers_audience_scope" not in result["metadata"]
        assert result["metadata"]["user_key"] == "value"

    def test_handles_unparseable_metadata(self):
        msg = self._make_message(metadata="not valid json {{{")
        result = sanitize_message(msg)
        assert result["metadata"] == "{}"

    def test_does_not_mutate_original(self):
        msg = self._make_message()
        original_keys = set(msg.keys())
        sanitize_message(msg)
        assert set(msg.keys()) == original_keys
        assert "recipient_row_id" in msg

    def test_sanitize_messages_batch(self):
        msgs = [self._make_message(uuid=f"uuid-{i}") for i in range(5)]
        results = sanitize_messages(msgs)
        assert len(results) == 5
        for r in results:
            assert "recipient_row_id" not in r
            assert r["uuid"].startswith("uuid-")

    def test_sanitize_empty_list(self):
        assert sanitize_messages([]) == []
