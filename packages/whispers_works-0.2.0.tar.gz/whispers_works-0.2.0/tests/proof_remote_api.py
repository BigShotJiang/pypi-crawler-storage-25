"""Baseline acceptance tests for the Whispers remote HTTP API surface.

Standalone proof script — no pytest. Spins up a temp server, exercises
each endpoint family through /connect token flow, reports pass/fail.

This captures a snapshot of what works TODAY before Gemini modifies the
networking layer. Any regression will show up as a failing check.

Usage:
    python tests/proof_remote_api.py
"""
from __future__ import annotations

import json
import os
import secrets
import shutil
import socket
import subprocess
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ARTIFACT_DIR = ROOT / "tests" / ".artifacts" / "proof_remote_api"
DB_PATH = ARTIFACT_DIR / "proof_remote_api.db"
RUNTIME_STATE_PATH = ARTIFACT_DIR / "runtime-state.json"
PROOF_HOME = ARTIFACT_DIR / "home"
PROOF_MCP_TOKEN = secrets.token_urlsafe(24)

# ---------------------------------------------------------------------------
# Helpers (same pattern as proof_startup.py)
# ---------------------------------------------------------------------------


def reset_artifacts() -> None:
    if ARTIFACT_DIR.exists():
        shutil.rmtree(ARTIFACT_DIR, ignore_errors=True)
    ARTIFACT_DIR.mkdir(parents=True, exist_ok=True)


def proof_env() -> dict[str, str]:
    env = os.environ.copy()
    env["HOME"] = str(PROOF_HOME)
    env["USERPROFILE"] = str(PROOF_HOME)
    env["WHISPERS_DB_PATH"] = str(DB_PATH)
    env["WHISPERS_RUNTIME_STATE_PATH"] = str(RUNTIME_STATE_PATH)
    env["WHISPERS_MCP_TOKEN"] = PROOF_MCP_TOKEN
    # The proof should validate the remote API surface itself, not fail because
    # the operator's ambient runtime is in trusted-team mode.
    env["WHISPERS_REMOTE_ADMISSION_MODE"] = "open"
    return env


def require(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


def parse_json(text: str) -> dict:
    try:
        return json.loads(text)
    except json.JSONDecodeError as exc:
        raise AssertionError(f"Expected JSON, got: {text[:200]!r}") from exc


def get_mcp_token() -> str:
    token = os.environ.get("WHISPERS_MCP_TOKEN", "").strip()
    if token:
        return token
    env_path = Path.home() / ".whispers" / ".env"
    if env_path.exists():
        for line in env_path.read_text().splitlines():
            line = line.strip()
            if line.startswith("WHISPERS_MCP_TOKEN="):
                return line.split("=", 1)[1].strip().strip('"').strip("'")
    return PROOF_MCP_TOKEN


def find_free_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.bind(("127.0.0.1", 0))
        return int(sock.getsockname()[1])


def wait_for_health(port: int, timeout_seconds: float = 15.0) -> None:
    deadline = time.time() + timeout_seconds
    url = f"http://127.0.0.1:{port}/health"
    while time.time() < deadline:
        try:
            with urllib.request.urlopen(url, timeout=1.0) as resp:
                if resp.status == 200:
                    return
        except Exception:
            time.sleep(0.25)
    raise AssertionError(f"Server on port {port} did not become healthy")


def start_temp_server() -> tuple[subprocess.Popen, int, str]:
    port = find_free_port()
    token = get_mcp_token()
    env = proof_env()
    env["WHISPERS_MCP_TOKEN"] = token
    proc = subprocess.Popen(
        [sys.executable, "-c", f"from whispers.server import start; start(port={port})"],
        cwd=ROOT,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        env=env,
    )
    try:
        wait_for_health(port)
    except Exception:
        proc.terminate()
        raise
    return proc, port, token


def stop_temp_server(proc: subprocess.Popen) -> None:
    if proc.poll() is not None:
        return
    proc.terminate()
    try:
        proc.wait(timeout=5)
    except subprocess.TimeoutExpired:
        proc.kill()
        proc.wait(timeout=5)


def http_get(url: str, token: str) -> tuple[int, str]:
    req = urllib.request.Request(
        url,
        method="GET",
        headers={"Authorization": f"Bearer {token}"},
    )
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            return resp.status, resp.read().decode()
    except urllib.error.HTTPError as exc:
        return exc.code, exc.read().decode()


def http_post(url: str, payload: dict, token: str, extra_headers: dict | None = None) -> tuple[int, str]:
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {token}",
    }
    if extra_headers:
        headers.update(extra_headers)
    req = urllib.request.Request(
        url,
        data=json.dumps(payload).encode(),
        method="POST",
        headers=headers,
    )
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            return resp.status, resp.read().decode()
    except urllib.error.HTTPError as exc:
        return exc.code, exc.read().decode()


def base_url(port: int) -> str:
    return f"http://127.0.0.1:{port}"


def connect_agent(port: str, operator_token: str, agent_name: str) -> dict:
    """Connect an agent and return the full response including agent token."""
    status, body = http_post(
        f"{base_url(port)}/connect",
        {"agent_name": agent_name, "agent_type": "remote_client"},
        operator_token,
    )
    require(status == 200, f"/connect failed for {agent_name}: HTTP {status} {body[:200]}")
    data = parse_json(body)
    require("token" in data, f"/connect response missing token for {agent_name}")
    return data


# ---------------------------------------------------------------------------
# Check: Health & Status (no auth needed for health probes)
# ---------------------------------------------------------------------------


def check_health_and_status(port: int, operator_token: str, results: list, errors: list) -> None:
    name = "health_and_status"
    try:
        # Health — no auth
        h_status, h_body = http_get(f"{base_url(port)}/health", "")
        require(h_status == 200, f"/health returned {h_status}")
        health = parse_json(h_body)
        require(health.get("healthy") is True, "/health not healthy")

        # Liveness probe
        l_status, _ = http_get(f"{base_url(port)}/livez", "")
        require(l_status == 200, f"/livez returned {l_status}")

        # Readiness probe
        r_status, _ = http_get(f"{base_url(port)}/readyz", "")
        require(r_status == 200, f"/readyz returned {r_status}")

        # Status (needs a connected agent)
        conn = connect_agent(port, operator_token, "proof-status-agent")
        agent_token = conn["token"]
        s_status, s_body = http_get(f"{base_url(port)}/status", agent_token)
        require(s_status == 200, f"/status returned {s_status}")
        status_data = parse_json(s_body)
        require("agents_online_count" in status_data, "/status missing agents_online_count")

        # Runtime GET
        rt_status, rt_body = http_get(f"{base_url(port)}/runtime", operator_token)
        require(rt_status == 200, f"/runtime GET returned {rt_status}")

        results.append({"check": name, "health": health, "status_keys": list(status_data.keys())})
    except AssertionError as exc:
        errors.append({"check": name, "error": str(exc)})


# ---------------------------------------------------------------------------
# Check: Connection & Auth lifecycle
# ---------------------------------------------------------------------------


def check_connection_and_auth(port: int, operator_token: str, results: list, errors: list) -> None:
    name = "connection_and_auth"
    try:
        # Connect a fresh agent
        conn = connect_agent(port, operator_token, "proof-auth-agent")
        agent_token = conn["token"]
        session_id = conn["session"]["session_id"]
        require(conn["token_status"] in ("created", "reclaimed"), f"unexpected token_status: {conn['token_status']}")
        require(conn["agent_name"] == "proof-auth-agent", "agent_name mismatch")

        # Lease renewal
        lease_status, lease_body = http_post(
            f"{base_url(port)}/lease",
            {"session_id": session_id},
            agent_token,
        )
        require(lease_status == 200, f"/lease returned {lease_status}: {lease_body[:200]}")
        lease_data = parse_json(lease_body)
        require("session" in lease_data, "/lease response missing session")

        # Token create
        tc_status, tc_body = http_post(
            f"{base_url(port)}/token:create",
            {"description": "proof-extra-token"},
            agent_token,
        )
        require(tc_status == 200, f"/token:create returned {tc_status}")
        tc_data = parse_json(tc_body)
        extra_token = tc_data["token"]
        require(bool(extra_token), "/token:create returned empty token")

        # Token revoke (revoke the extra one)
        tr_status, tr_body = http_post(
            f"{base_url(port)}/token:revoke",
            {"token": extra_token},
            agent_token,
        )
        require(tr_status == 200, f"/token:revoke returned {tr_status}")

        # Verify revoked token is rejected
        bad_status, _ = http_get(f"{base_url(port)}/whoami", extra_token)
        require(bad_status == 401, f"revoked token should get 401, got {bad_status}")

        # Token rotate
        rot_status, rot_body = http_post(
            f"{base_url(port)}/token:rotate",
            {"description": "proof-rotated"},
            agent_token,
        )
        require(rot_status == 200, f"/token:rotate returned {rot_status}")
        rot_data = parse_json(rot_body)
        new_token = rot_data["token"]
        require(new_token != agent_token, "/token:rotate returned same token")

        # Old token should now be invalid
        old_status, _ = http_get(f"{base_url(port)}/whoami", agent_token)
        require(old_status == 401, f"old token after rotate should get 401, got {old_status}")

        # Disconnect using the new token
        dc_status, dc_body = http_post(
            f"{base_url(port)}/disconnect",
            {},
            new_token,
        )
        require(dc_status == 200, f"/disconnect returned {dc_status}")

        results.append({
            "check": name,
            "token_statuses": [conn["token_status"], "created_extra", "revoked_extra", "rotated"],
            "disconnect": "ok",
        })
    except AssertionError as exc:
        errors.append({"check": name, "error": str(exc)})


# ---------------------------------------------------------------------------
# Check: Messaging
# ---------------------------------------------------------------------------


def check_messaging(port: int, operator_token: str, results: list, errors: list) -> None:
    name = "messaging"
    try:
        # Connect sender and receiver
        sender_conn = connect_agent(port, operator_token, "proof-sender")
        receiver_conn = connect_agent(port, operator_token, "proof-receiver")
        sender_token = sender_conn["token"]
        receiver_token = receiver_conn["token"]

        # Send a message
        send_status, send_body = http_post(
            f"{base_url(port)}/message:send",
            {
                "to": "proof-receiver",
                "subject": "Proof baseline",
                "body": "Testing the remote API surface",
                "type": "inform",
                "priority": "routine",
            },
            sender_token,
            extra_headers={"A2A-Version": "1.0"},
        )
        require(send_status == 200, f"/message:send returned {send_status}: {send_body[:200]}")
        send_data = parse_json(send_body)
        msg_id = send_data.get("id") or send_data.get("message_id")
        require(send_data.get("status") in ("delivered", "queued"), f"unexpected send status: {send_data.get('status')}")

        # Check receiver inbox
        inbox_status, inbox_body = http_get(f"{base_url(port)}/inbox?limit=10", receiver_token)
        require(inbox_status == 200, f"/inbox returned {inbox_status}")
        inbox_data = parse_json(inbox_body)
        messages = inbox_data if isinstance(inbox_data, list) else inbox_data.get("messages", [])
        require(any(m.get("subject") == "Proof baseline" for m in messages), "receiver inbox missing proof message")

        # Check sender outbox
        outbox_status, outbox_body = http_get(f"{base_url(port)}/outbox?limit=10", sender_token)
        require(outbox_status == 200, f"/outbox returned {outbox_status}")
        outbox_data = parse_json(outbox_body)
        out_messages = outbox_data if isinstance(outbox_data, list) else outbox_data.get("messages", [])
        require(any(m.get("subject") == "Proof baseline" for m in out_messages), "sender outbox missing proof message")

        # Ack the message (requires state field: processed, insufficient_context, etc.)
        if msg_id:
            ack_status, ack_body = http_post(
                f"{base_url(port)}/message:ack",
                {"message_id": msg_id, "state": "processed"},
                receiver_token,
            )
            require(ack_status == 200, f"/message:ack returned {ack_status}: {ack_body[:200]}")

        # Trace
        trace_status, trace_body = http_get(
            f"{base_url(port)}/trace/proof-sender?limit=10",
            receiver_token,
        )
        require(trace_status == 200, f"/trace returned {trace_status}")
        trace_data = parse_json(trace_body)
        trace_messages = trace_data if isinstance(trace_data, list) else trace_data.get("messages", [])
        require(any(m.get("subject") == "Proof baseline" for m in trace_messages), "trace missing proof message")

        # A2A header enforcement — send without header should fail
        no_header_status, _ = http_post(
            f"{base_url(port)}/message:send",
            {"to": "proof-receiver", "subject": "Should fail", "body": "no header"},
            sender_token,
        )
        require(no_header_status == 400, f"missing A2A-Version should get 400, got {no_header_status}")

        results.append({
            "check": name,
            "send_status": send_data.get("status"),
            "inbox_count": len(messages),
            "outbox_count": len(out_messages),
            "trace_count": len(trace_messages),
            "ack": "ok" if msg_id else "skipped",
            "a2a_enforcement": "ok",
        })
    except AssertionError as exc:
        errors.append({"check": name, "error": str(exc)})


# ---------------------------------------------------------------------------
# Check: Presence & State
# ---------------------------------------------------------------------------


def check_presence_and_state(port: int, operator_token: str, results: list, errors: list) -> None:
    name = "presence_and_state"
    try:
        conn = connect_agent(port, operator_token, "proof-presence-agent")
        agent_token = conn["token"]

        # Presence
        p_status, p_body = http_get(f"{base_url(port)}/presence", agent_token)
        require(p_status == 200, f"/presence returned {p_status}")
        presence = parse_json(p_body)
        # Should see ourselves in presence
        agents = presence if isinstance(presence, list) else presence.get("agents", [])

        # Wag
        wag_status, wag_body = http_post(
            f"{base_url(port)}/wag",
            {"state": "building", "intent": "proof testing"},
            agent_token,
        )
        require(wag_status == 200, f"/wag returned {wag_status}")

        # Set mode
        mode_status, mode_body = http_post(
            f"{base_url(port)}/mode",
            {"mode": "focused"},
            agent_token,
        )
        require(mode_status == 200, f"/mode POST returned {mode_status}")

        # Get mode
        gm_status, gm_body = http_get(f"{base_url(port)}/mode/proof-presence-agent", agent_token)
        require(gm_status == 200, f"/mode GET returned {gm_status}")

        # Set readiness
        rd_status, rd_body = http_post(
            f"{base_url(port)}/readiness",
            {"readiness": "busy", "current_task": "proof test"},
            agent_token,
        )
        require(rd_status == 200, f"/readiness POST returned {rd_status}")

        # Get readiness
        gr_status, gr_body = http_get(f"{base_url(port)}/readiness/proof-presence-agent", agent_token)
        require(gr_status == 200, f"/readiness GET returned {gr_status}")

        # Heartbeat
        hb_status, hb_body = http_post(
            f"{base_url(port)}/heartbeat",
            {
                "context_load": 0.4,
                "interruptibility": "defer",
                "quality_risk": "low",
                "current_task": "proof testing",
            },
            agent_token,
        )
        require(hb_status == 200, f"/heartbeat returned {hb_status}")

        # Active mode (derived)
        am_status, am_body = http_get(f"{base_url(port)}/active-mode/proof-presence-agent", agent_token)
        require(am_status == 200, f"/active-mode returned {am_status}")

        # Watchdog
        wd_status, wd_body = http_post(
            f"{base_url(port)}/watchdog",
            {},
            agent_token,
        )
        require(wd_status == 200, f"/watchdog returned {wd_status}")

        results.append({
            "check": name,
            "presence_agent_count": len(agents) if isinstance(agents, list) else "unknown",
            "wag": "ok",
            "mode": "ok",
            "readiness": "ok",
            "heartbeat": "ok",
            "active_mode": "ok",
            "watchdog": "ok",
        })
    except AssertionError as exc:
        errors.append({"check": name, "error": str(exc)})


# ---------------------------------------------------------------------------
# Check: Identity
# ---------------------------------------------------------------------------


def check_identity(port: int, operator_token: str, results: list, errors: list) -> None:
    name = "identity"
    try:
        conn = connect_agent(port, operator_token, "proof-identity-agent")
        agent_token = conn["token"]

        # Whoami
        w_status, w_body = http_get(f"{base_url(port)}/whoami", agent_token)
        require(w_status == 200, f"/whoami returned {w_status}")
        whoami = parse_json(w_body)
        require(whoami.get("callsign") == "proof-identity-agent", f"whoami callsign wrong: {whoami.get('callsign')}")

        # Handle
        h_status, h_body = http_get(f"{base_url(port)}/handle/proof-identity-agent", agent_token)
        require(h_status == 200, f"/handle returned {h_status}")

        # Identity key GET (should work even if no key bound)
        ik_status, ik_body = http_get(f"{base_url(port)}/identity/key", agent_token)
        require(ik_status == 200, f"/identity/key GET returned {ik_status}")

        # Rename
        rn_status, rn_body = http_post(
            f"{base_url(port)}/rename",
            {"new_callsign": "proof-renamed-agent"},
            agent_token,
        )
        require(rn_status == 200, f"/rename returned {rn_status}: {rn_body[:200]}")

        # Verify rename stuck
        w2_status, w2_body = http_get(f"{base_url(port)}/whoami", agent_token)
        require(w2_status == 200, f"/whoami after rename returned {w2_status}")
        whoami2 = parse_json(w2_body)
        require(whoami2.get("callsign") == "proof-renamed-agent", f"rename did not stick: {whoami2.get('callsign')}")

        results.append({
            "check": name,
            "whoami": "ok",
            "handle": "ok",
            "identity_key": "ok",
            "rename": "ok",
        })
    except AssertionError as exc:
        errors.append({"check": name, "error": str(exc)})


# ---------------------------------------------------------------------------
# Check: Auth enforcement — unauthenticated requests should fail
# ---------------------------------------------------------------------------


def check_auth_enforcement(port: int, operator_token: str, results: list, errors: list) -> None:
    name = "auth_enforcement"
    try:
        # These endpoints should reject requests without a valid agent token
        no_token = "invalid-token-that-does-not-exist"
        protected_gets = ["/inbox", "/outbox", "/whoami", "/status"]
        protected_posts = [
            ("/wag", {"state": "idle"}),
            ("/mode", {"mode": "open"}),
            ("/readiness", {"readiness": "ready"}),
            ("/disconnect", {}),
        ]

        failures = []
        for path in protected_gets:
            status, _ = http_get(f"{base_url(port)}{path}", no_token)
            if status != 401:
                failures.append(f"GET {path} returned {status}, expected 401")

        for path, payload in protected_posts:
            status, _ = http_post(f"{base_url(port)}{path}", payload, no_token)
            if status != 401:
                failures.append(f"POST {path} returned {status}, expected 401")

        require(not failures, "; ".join(failures))

        # Health endpoints should NOT require auth
        for path in ["/health", "/livez", "/readyz"]:
            status, _ = http_get(f"{base_url(port)}{path}", "")
            require(status == 200, f"{path} should be open, got {status}")

        results.append({"check": name, "protected_endpoints_checked": len(protected_gets) + len(protected_posts)})
    except AssertionError as exc:
        errors.append({"check": name, "error": str(exc)})


# ---------------------------------------------------------------------------
# Check: Connect edge cases
# ---------------------------------------------------------------------------


def check_connect_edge_cases(port: int, operator_token: str, results: list, errors: list) -> None:
    name = "connect_edge_cases"
    try:
        # Missing agent_name
        s1, _ = http_post(f"{base_url(port)}/connect", {}, operator_token)
        require(s1 == 400, f"empty agent_name should get 400, got {s1}")

        # Invalid callsign format
        s2, _ = http_post(f"{base_url(port)}/connect", {"agent_name": "BAD NAME!"}, operator_token)
        require(s2 == 400, f"invalid callsign should get 400, got {s2}")

        # Reserved name
        s3, _ = http_post(f"{base_url(port)}/connect", {"agent_name": "system"}, operator_token)
        require(s3 == 400, f"reserved name should get 400, got {s3}")

        results.append({
            "check": name,
            "empty_name": s1,
            "invalid_callsign": s2,
            "reserved_name": s3,
        })
    except AssertionError as exc:
        errors.append({"check": name, "error": str(exc)})


# ---------------------------------------------------------------------------
# Runner
# ---------------------------------------------------------------------------


def main() -> int:
    reset_artifacts()
    results: list[dict] = []
    errors: list[dict] = []

    proc, port, operator_token = start_temp_server()
    try:
        print(f"Server up on port {port}, DB at {DB_PATH}")
        print()

        checks = [
            ("health_and_status", lambda r, e: check_health_and_status(port, operator_token, r, e)),
            ("connect_edge_cases", lambda r, e: check_connect_edge_cases(port, operator_token, r, e)),
            ("connection_and_auth", lambda r, e: check_connection_and_auth(port, operator_token, r, e)),
            ("messaging", lambda r, e: check_messaging(port, operator_token, r, e)),
            ("presence_and_state", lambda r, e: check_presence_and_state(port, operator_token, r, e)),
            ("identity", lambda r, e: check_identity(port, operator_token, r, e)),
            ("auth_enforcement", lambda r, e: check_auth_enforcement(port, operator_token, r, e)),
        ]

        for check_name, check_fn in checks:
            pre_error_count = len(errors)
            check_fn(results, errors)
            status = "PASS" if len(errors) == pre_error_count else "FAIL"
            print(f"  [{status}] {check_name}")

    finally:
        stop_temp_server(proc)

    print()
    overall = "FAIL" if errors else "PASS"
    summary = {
        "overall": overall,
        "db_path": str(DB_PATH),
        "runtime_state_path": str(RUNTIME_STATE_PATH),
        "remote_admission_mode": "open",
        "checks_run": len(checks),
        "checks_passed": len(checks) - len(errors),
        "checks_failed": len(errors),
    }

    if errors:
        summary["errors"] = errors
        print(json.dumps(summary, indent=2))
        return 1

    summary["results"] = results
    print(json.dumps(summary, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
