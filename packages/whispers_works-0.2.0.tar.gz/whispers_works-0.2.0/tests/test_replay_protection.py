"""Tests for replay protection — idempotency_key enforcement.

Covers:
- First message with idempotency_key delivers normally
- Duplicate idempotency_key from same sender is rejected
- Same idempotency_key from different sender is allowed
- No idempotency_key = no enforcement (backward compatible)
- Security event logged on rejection
"""

import json
import pytest


class TestReplayProtection:
    @pytest.fixture
    def setup(self, tmp_path):
        from whispers.storage.db import WhispersDB
        from whispers.client import WhispersClient

        db_path = str(tmp_path / "test_replay.db")
        db = WhispersDB(db_path=db_path)
        alice = WhispersClient("alice", db_path=db_path)
        bob = WhispersClient("bob", db_path=db_path)
        return db, alice, bob

    def test_first_message_delivers(self, setup):
        db, alice, bob = setup
        result = alice.send(
            "bob", "Test", body="Hello",
            idempotency_key="unique-key-1",
        )
        assert result.get("status") != "dead_lettered"

    def test_duplicate_key_returns_original(self, setup):
        """Client-side dedup returns the original message (idempotent)."""
        db, alice, bob = setup
        r1 = alice.send("bob", "First", body="Original", idempotency_key="dup-key")
        r2 = alice.send("bob", "Second", body="Duplicate", idempotency_key="dup-key")
        # Second send returns the same ID as the first (idempotent, not rejected)
        assert r1["id"] == r2["id"]

    def test_same_key_different_sender_allowed(self, setup):
        db, alice, bob = setup
        alice.send("bob", "From Alice", body="Hello", idempotency_key="shared-key")
        result = bob.send("alice", "From Bob", body="Hello", idempotency_key="shared-key")
        assert result.get("status") != "dead_lettered"

    def test_no_key_no_enforcement(self, setup):
        db, alice, bob = setup
        r1 = alice.send("bob", "First", body="Hello")
        r2 = alice.send("bob", "Second", body="Hello again")
        assert r1.get("status") != "dead_lettered"
        assert r2.get("status") != "dead_lettered"

    def test_dispatcher_rejects_replay_on_raw_path(self, setup):
        """Dispatcher-level replay protection catches duplicates that bypass client dedup."""
        db, alice, bob = setup
        from whispers.envelope import Envelope, Priority, MsgType
        from whispers.dispatcher import Dispatcher

        dispatcher = Dispatcher(db)

        env1 = Envelope(
            sender="alice", recipient="bob", subject="First",
            body="Original", priority=Priority.ROUTINE, msg_type=MsgType.INFORM,
            idempotency_key="raw-dup-key",
        )
        result1 = dispatcher.dispatch(env1)
        assert result1 is None  # Success

        env2 = Envelope(
            sender="alice", recipient="bob", subject="Replay",
            body="Duplicate", priority=Priority.ROUTINE, msg_type=MsgType.INFORM,
            idempotency_key="raw-dup-key",
        )
        result2 = dispatcher.dispatch(env2)
        assert result2 is not None
        assert "replay_rejected" in result2

        # Security event logged
        with db.get_readonly_connection() as conn:
            events = conn.execute(
                "SELECT * FROM security_events WHERE event_type = 'replay_rejected'"
            ).fetchall()
        assert len(events) >= 1
        assert "raw-dup-key" in events[0]["detail"]
