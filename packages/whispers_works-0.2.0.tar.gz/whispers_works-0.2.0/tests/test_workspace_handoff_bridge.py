"""Workspace-to-coordination bridge tests.

Tests the handoff-to-workspace projection that injects workspace deltas
when a handoff references a workspace_id. Covers edge cases the E2E
proof milestone test doesn't exercise.
"""

import json
from datetime import datetime, timezone

import pytest

from whispers.envelope import Envelope, MsgType, Priority
from whispers.storage.db import WhispersDBError
from whispers.testing import WhispersTestHarness
from whispers.workspaces import WorkspaceManager


class TestHandoffProjectionHappyPath:
    """Verify that handoffs with workspace_id correctly project into workspace events."""

    def test_handoff_with_workspace_id_creates_delta(self):
        with WhispersTestHarness() as h:
            alice = h.make_client("alice")
            bob = h.make_client("bob")

            wm = WorkspaceManager(alice.db)
            ws_id = wm.create_workspace("Collab project", "alice")
            wm.join_workspace(ws_id, "bob")

            alice.send_handoff(
                "bob",
                objective="Finish the tests",
                deliverable="test suite",
                completed="wrote 10 tests",
                remaining="5 more edge cases",
                next_action="write remaining tests",
                workspace_id=ws_id,
            )

            state = wm.get_state(ws_id)
            handoff_deltas = [d for d in state["deltas"] if d["delta_kind"] == "handoff_in"]
            assert len(handoff_deltas) >= 1
            assert "alice" in handoff_deltas[0]["actor"]

    def test_projected_delta_contains_handoff_context(self):
        with WhispersTestHarness() as h:
            alice = h.make_client("alice")
            bob = h.make_client("bob")

            wm = WorkspaceManager(alice.db)
            ws_id = wm.create_workspace("Context test", "alice")
            wm.join_workspace(ws_id, "bob")

            alice.send_handoff(
                "bob",
                objective="Deploy feature",
                deliverable="deployed service",
                completed="code reviewed",
                remaining="deploy to staging",
                next_action="run deploy script",
                workspace_id=ws_id,
            )

            state = wm.get_state(ws_id)
            handoff_deltas = [d for d in state["deltas"] if d["delta_kind"] == "handoff_in"]
            assert len(handoff_deltas) >= 1

            text = handoff_deltas[0].get("text", "")
            # The projection text should contain meaningful handoff context
            assert len(text) > 10


class TestHandoffProjectionEdgeCases:
    """Edge cases where the projection should gracefully handle bad inputs."""

    def test_handoff_with_nonexistent_workspace_silently_skips(self):
        """Handoff referencing a workspace_id that doesn't exist should still deliver the handoff."""
        with WhispersTestHarness() as h:
            alice = h.make_client("alice")
            bob = h.make_client("bob")

            result = alice.send_handoff(
                "bob",
                objective="Test nonexistent workspace",
                deliverable="test",
                completed="nothing",
                remaining="everything",
                next_action="figure it out",
                workspace_id="ws_does_not_exist",
            )

            # Handoff should still be delivered to bob
            assert result.get("status") in ("delivered", "queued")

            # Bob should have the handoff in inbox
            inbox = bob.check_inbox()
            assert len(inbox) >= 1

    def test_handoff_with_closed_workspace_skips_projection(self):
        """Handoff to a closed workspace should deliver the handoff but not project a delta."""
        with WhispersTestHarness() as h:
            alice = h.make_client("alice")
            bob = h.make_client("bob")

            wm = WorkspaceManager(alice.db)
            ws_id = wm.create_workspace("Will close", "alice")
            wm.join_workspace(ws_id, "bob")
            close_seq = wm.close_workspace(ws_id, "alice")

            alice.send_handoff(
                "bob",
                objective="Test closed workspace",
                deliverable="test",
                completed="nothing",
                remaining="everything",
                next_action="figure it out",
                workspace_id=ws_id,
            )

            state = wm.get_state(ws_id)
            handoff_deltas = [d for d in state["deltas"] if d["delta_kind"] == "handoff_in"]
            # No handoff_in delta should appear — workspace was closed
            assert len(handoff_deltas) == 0

            # But the handoff message itself should still be delivered
            inbox = bob.check_inbox()
            assert len(inbox) >= 1

    def test_handoff_without_workspace_id_no_projection(self):
        """Handoffs without workspace_id should not create any workspace events."""
        with WhispersTestHarness() as h:
            alice = h.make_client("alice")
            bob = h.make_client("bob")

            wm = WorkspaceManager(alice.db)
            ws_id = wm.create_workspace("Unrelated workspace", "alice")

            alice.send_handoff(
                "bob",
                objective="No workspace link",
                deliverable="test",
                completed="nothing",
                remaining="everything",
                next_action="do stuff",
                # No workspace_id
            )

            state = wm.get_state(ws_id)
            handoff_deltas = [d for d in state["deltas"] if d["delta_kind"] == "handoff_in"]
            assert len(handoff_deltas) == 0


class TestProjectionSequenceIntegrity:
    """Verify projected handoff deltas integrate correctly with workspace sequence."""

    def test_projected_delta_gets_monotonic_sequence(self):
        """Handoff projection should receive the next sequence number in the workspace."""
        with WhispersTestHarness() as h:
            alice = h.make_client("alice")
            bob = h.make_client("bob")

            wm = WorkspaceManager(alice.db)
            ws_id = wm.create_workspace("Sequence test", "alice")
            wm.join_workspace(ws_id, "bob")

            # Post a regular delta first
            regular_seq = wm.post_delta(ws_id, "note", "alice", text="Before handoff")

            alice.send_handoff(
                "bob",
                objective="Check sequence",
                deliverable="test",
                completed="regular delta posted",
                remaining="verify sequence",
                next_action="check ordering",
                workspace_id=ws_id,
            )

            state = wm.get_state(ws_id)
            handoff_deltas = [d for d in state["deltas"] if d["delta_kind"] == "handoff_in"]
            assert len(handoff_deltas) >= 1

            handoff_seq = handoff_deltas[0]["sequence"]
            assert handoff_seq > regular_seq

    def test_non_member_workspace_handoff_is_rejected_and_audited(self):
        """A non-member sender cannot claim workspace-linked handoff scope."""
        with WhispersTestHarness() as h:
            alice = h.make_client("alice")
            bob = h.make_client("bob")
            charlie = h.make_client("charlie")

            wm = WorkspaceManager(alice.db)
            ws_id = wm.create_workspace("Projection test", "alice")
            wm.join_workspace(ws_id, "bob")
            # charlie is NOT a member of the workspace

            result = charlie.send_handoff(
                "bob",
                objective="Outsider handoff",
                deliverable="test",
                completed="nothing",
                remaining="everything",
                next_action="check if it projects",
                workspace_id=ws_id,
            )

            assert result["status"] == "dead_lettered"
            assert result["reason"] == "workspace_handoff_blocked_non_member"

            inbox = bob.check_inbox()
            assert len(inbox) == 0

            state = wm.get_state(ws_id)
            handoff_deltas = [d for d in state["deltas"] if d["delta_kind"] == "handoff_in"]
            assert len(handoff_deltas) == 0

            with charlie.db.get_connection() as conn:
                event = conn.execute(
                    """
                    SELECT event_type, outcome, actor_agent, target_agent, detail
                    FROM security_events
                    WHERE event_type = 'scope_boundary'
                    ORDER BY created_at DESC
                    LIMIT 1
                    """
                ).fetchone()

            assert event is not None
            assert event["outcome"] == "workspace_handoff_blocked_non_member"
            assert event["actor_agent"] == "charlie"
            assert event["target_agent"] == "bob"

            detail = json.loads(event["detail"])
            assert detail["workspace_id"] == ws_id
            assert detail["reason"] == "non_member_workspace_handoff"
            assert detail["projected"] is False
            assert detail["delivered"] is False
            assert "Workspace-linked handoff blocked" in detail["explanation"]

            recent = charlie.db.get_recent_security_events(limit=5)
            assert any(
                entry["type"] == "scope_boundary"
                and "Workspace-linked handoff blocked" in entry["detail"]
                for entry in recent
            )

    def test_non_member_direct_store_message_workspace_handoff_is_rejected(self):
        with WhispersTestHarness() as h:
            alice = h.make_client("alice")
            bob = h.make_client("bob")
            charlie = h.make_client("charlie")

            wm = WorkspaceManager(alice.db)
            ws_id = wm.create_workspace("Projection test", "alice")
            wm.join_workspace(ws_id, "bob")

            envelope = Envelope(
                sender="charlie",
                recipient="bob",
                subject="Outsider handoff",
                msg_type=MsgType("handoff_baton.v1"),
                priority=Priority("routine"),
                payload={
                    "objective": "Outsider handoff",
                    "deliverable": "test",
                    "completed": "nothing",
                    "remaining": "everything",
                    "next_action": "check if it projects",
                    "workspace_id": ws_id,
                },
                created_at=datetime.now(timezone.utc),
            )

            with pytest.raises(WhispersDBError, match="Workspace-linked handoff blocked"):
                charlie.db.store_message(envelope, allowed_recipients=["bob"])

            assert len(bob.check_inbox()) == 0

            with charlie.db.get_connection() as conn:
                count = conn.execute(
                    "SELECT COUNT(*) FROM messages WHERE from_agent = ? AND to_agent = ?",
                    ("charlie", "bob"),
                ).fetchone()[0]
            assert count == 0


class TestBatonWorkspaceLinkage:
    """Verify baton operations with workspace linkage work correctly."""

    def test_baton_ack_on_workspace_linked_handoff(self):
        """Acknowledging a workspace-linked handoff should work normally."""
        with WhispersTestHarness() as h:
            alice = h.make_client("alice")
            bob = h.make_client("bob")

            wm = WorkspaceManager(alice.db)
            ws_id = wm.create_workspace("Baton test", "alice")
            wm.join_workspace(ws_id, "bob")

            result = alice.send_handoff(
                "bob",
                objective="Baton workspace linkage",
                deliverable="test",
                completed="sent handoff",
                remaining="ack it",
                next_action="bob acks",
                workspace_id=ws_id,
            )

            inbox = bob.check_inbox(mark_seen=True)
            assert len(inbox) >= 1
            handoff_msg = inbox[0]

            # Acknowledge the handoff
            bob.acknowledge_message(handoff_msg["uuid"], "accepted")

            # Verify the ack was recorded
            import sqlite3
            conn = sqlite3.connect(bob.db_path)
            conn.row_factory = sqlite3.Row
            row = conn.execute(
                "SELECT ack_state FROM message_recipients WHERE message_uuid = ? AND recipient_callsign = ?",
                (handoff_msg["uuid"], "bob"),
            ).fetchone()
            conn.close()
            assert row["ack_state"] == "accepted"
