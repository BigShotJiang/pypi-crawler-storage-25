"""Shared test fixtures for Whispers test suite."""

import shutil
import uuid
from pathlib import Path

import pytest


@pytest.fixture
def temp_db():
    """Create a temporary SQLite database path, cleaned up after use."""
    root = Path(__file__).resolve().parents[1] / ".tmp"
    root.mkdir(parents=True, exist_ok=True)
    case_dir = root / f"whispers-test-{uuid.uuid4().hex}"
    case_dir.mkdir(parents=True, exist_ok=False)
    db_path = str(case_dir / "test_whispers.db")
    yield db_path
    shutil.rmtree(case_dir, ignore_errors=True)


@pytest.fixture
def temp_dir():
    """Create a temporary directory, cleaned up after use."""
    root = Path(__file__).resolve().parents[1] / ".tmp"
    root.mkdir(parents=True, exist_ok=True)
    case_dir = root / f"whispers-tmp-{uuid.uuid4().hex}"
    case_dir.mkdir(parents=True, exist_ok=False)
    yield case_dir
    shutil.rmtree(case_dir, ignore_errors=True)


@pytest.fixture(autouse=True)
def isolated_shared_state_paths(monkeypatch, temp_dir):
    """Keep runtime-state and PID file writes inside per-test temp space by default."""
    monkeypatch.setenv("WHISPERS_RUNTIME_STATE_PATH", str(temp_dir / "runtime-state.json"))

    import whispers.process_utils as process_utils

    monkeypatch.setattr(process_utils, "_PID_FILE_PATH", str(temp_dir / "server.pid"))


@pytest.fixture
def client(temp_db):
    """Create a WhispersClient connected to a temporary database."""
    from whispers.client import WhispersClient
    return WhispersClient("test-agent", db_path=temp_db)


@pytest.fixture
def mock_client():
    """Create a MockWhispersClient for unit tests that don't need a real DB."""
    from whispers.client import MockWhispersClient
    return MockWhispersClient("test-agent")
