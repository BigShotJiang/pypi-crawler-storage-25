"""Workspace edge-case pressure tests.

Exercises boundary conditions that the E2E proof milestone test doesn't cover:
concurrent membership, delta ordering, reconnection edges, cross-workspace
isolation, and closed workspace behavior.
"""

import pytest

from whispers.storage.db import WhispersDBError
from whispers.testing import WhispersTestHarness
from whispers.workspaces import WorkspaceManager


class TestMembershipEdgeCases:
    """Membership lifecycle boundary conditions."""

    def test_join_closed_workspace_rejected(self):
        with WhispersTestHarness() as h:
            creator = h.make_client("creator")
            joiner = h.make_client("joiner")

            wm = WorkspaceManager(creator.db)
            ws_id = wm.create_workspace("Test", "creator")
            wm.close_workspace(ws_id, "creator")

            with pytest.raises(WhispersDBError, match="closed"):
                wm.join_workspace(ws_id, "joiner")

    def test_double_join_is_idempotent(self):
        with WhispersTestHarness() as h:
            creator = h.make_client("creator")
            joiner = h.make_client("joiner")

            wm = WorkspaceManager(creator.db)
            ws_id = wm.create_workspace("Test", "creator")
            seq1 = wm.join_workspace(ws_id, "joiner")
            seq2 = wm.join_workspace(ws_id, "joiner")

            # Second join should still produce a lifecycle event
            assert seq2 > seq1

    def test_leave_then_rejoin(self):
        with WhispersTestHarness() as h:
            creator = h.make_client("creator")
            member = h.make_client("member")

            wm = WorkspaceManager(creator.db)
            ws_id = wm.create_workspace("Test", "creator")
            wm.join_workspace(ws_id, "member")
            wm.leave_workspace(ws_id, "member")
            rejoin_seq = wm.join_workspace(ws_id, "member")

            # Should be able to rejoin after leaving
            state = wm.get_state(ws_id)
            active_members = [
                m for m in state["members"]
                if m["agent_name"] == "member" and m["membership_state"] == "active"
            ]
            assert len(active_members) == 1
            assert rejoin_seq > 0

    def test_leave_non_member_rejected(self):
        with WhispersTestHarness() as h:
            creator = h.make_client("creator")
            stranger = h.make_client("stranger")

            wm = WorkspaceManager(creator.db)
            ws_id = wm.create_workspace("Test", "creator")

            with pytest.raises(WhispersDBError, match="not active"):
                wm.leave_workspace(ws_id, "stranger")

    def test_close_already_closed_rejected(self):
        with WhispersTestHarness() as h:
            creator = h.make_client("creator")

            wm = WorkspaceManager(creator.db)
            ws_id = wm.create_workspace("Test", "creator")
            wm.close_workspace(ws_id, "creator")

            with pytest.raises(WhispersDBError, match="already closed"):
                wm.close_workspace(ws_id, "creator")


class TestDeltaOrdering:
    """Monotonic sequence guarantee tests."""

    def test_sequences_are_strictly_monotonic(self):
        with WhispersTestHarness() as h:
            agent = h.make_client("agent")
            wm = WorkspaceManager(agent.db)
            ws_id = wm.create_workspace("Ordering test", "agent")

            sequences = []
            for i in range(10):
                seq = wm.post_delta(ws_id, "note", "agent", text=f"Delta {i}")
                sequences.append(seq)

            # All sequences must be strictly increasing
            for i in range(1, len(sequences)):
                assert sequences[i] > sequences[i - 1], f"Sequence {sequences[i]} not greater than {sequences[i - 1]}"

    def test_lifecycle_and_user_deltas_share_sequence_space(self):
        """Join, leave, and user deltas all share the same monotonic sequence."""
        with WhispersTestHarness() as h:
            creator = h.make_client("creator")
            member = h.make_client("member")

            wm = WorkspaceManager(creator.db)
            ws_id = wm.create_workspace("Shared sequence", "creator")
            # creator auto-join is seq 1
            join_seq = wm.join_workspace(ws_id, "member")  # seq 2
            delta_seq = wm.post_delta(ws_id, "note", "creator", text="Hello")  # seq 3
            leave_seq = wm.leave_workspace(ws_id, "member")  # seq 4

            assert join_seq < delta_seq < leave_seq


class TestReconnectionEdgeCases:
    """since_sequence boundary conditions."""

    def test_since_zero_returns_all_events(self):
        with WhispersTestHarness() as h:
            agent = h.make_client("agent")
            wm = WorkspaceManager(agent.db)
            ws_id = wm.create_workspace("Reconnect test", "agent")

            for i in range(5):
                wm.post_delta(ws_id, "note", "agent", text=f"Delta {i}")

            state = wm.get_state(ws_id, since_sequence=0)
            # Should get all events (auto-join + 5 deltas = 6)
            assert len(state["deltas"]) >= 6

    def test_since_sequence_beyond_current_returns_empty(self):
        with WhispersTestHarness() as h:
            agent = h.make_client("agent")
            wm = WorkspaceManager(agent.db)
            ws_id = wm.create_workspace("Future seq test", "agent")

            wm.post_delta(ws_id, "note", "agent", text="Only delta")

            state = wm.get_state(ws_id, since_sequence=9999)
            # No deltas at or after sequence 9999
            assert len(state["deltas"]) == 0

    def test_since_sequence_exact_boundary(self):
        """Request since the exact last sequence — should return nothing new."""
        with WhispersTestHarness() as h:
            agent = h.make_client("agent")
            wm = WorkspaceManager(agent.db)
            ws_id = wm.create_workspace("Boundary test", "agent")

            last_seq = wm.post_delta(ws_id, "note", "agent", text="Last one")

            state = wm.get_state(ws_id, since_sequence=last_seq)
            # Should return zero deltas — we already have this sequence
            assert len(state["deltas"]) == 0

    def test_reconnection_includes_lifecycle_events(self):
        """Lifecycle events (join/leave) should appear in catch-up."""
        with WhispersTestHarness() as h:
            creator = h.make_client("creator")
            member = h.make_client("member")

            wm = WorkspaceManager(creator.db)
            ws_id = wm.create_workspace("Lifecycle catchup", "creator")
            # creator auto-join = seq 1
            catchup_from = 1  # Start catching up after the creator's join

            wm.join_workspace(ws_id, "member")  # seq 2
            wm.post_delta(ws_id, "note", "member", text="I'm here")  # seq 3
            wm.leave_workspace(ws_id, "member")  # seq 4

            state = wm.get_state(ws_id, since_sequence=catchup_from)
            delta_kinds = [d["delta_kind"] for d in state["deltas"]]
            assert "lifecycle" in delta_kinds
            assert "note" in delta_kinds


class TestCrossWorkspaceIsolation:
    """Deltas in one workspace must not appear in another."""

    def test_deltas_isolated_between_workspaces(self):
        with WhispersTestHarness() as h:
            agent = h.make_client("agent")
            wm = WorkspaceManager(agent.db)

            ws_a = wm.create_workspace("Workspace A", "agent")
            ws_b = wm.create_workspace("Workspace B", "agent")

            wm.post_delta(ws_a, "note", "agent", text="Only in A")
            wm.post_delta(ws_b, "note", "agent", text="Only in B")

            state_a = wm.get_state(ws_a)
            state_b = wm.get_state(ws_b)

            texts_a = [d.get("text", "") for d in state_a["deltas"]]
            texts_b = [d.get("text", "") for d in state_b["deltas"]]

            assert "Only in A" in texts_a
            assert "Only in B" not in texts_a
            assert "Only in B" in texts_b
            assert "Only in A" not in texts_b


class TestClosedWorkspaceBehavior:
    """Operations on closed workspaces."""

    def test_post_delta_to_closed_workspace_rejected(self):
        with WhispersTestHarness() as h:
            agent = h.make_client("agent")
            wm = WorkspaceManager(agent.db)
            ws_id = wm.create_workspace("Will close", "agent")
            wm.close_workspace(ws_id, "agent")

            with pytest.raises(WhispersDBError, match="closed"):
                wm.post_delta(ws_id, "note", "agent", text="Too late")

    def test_get_state_on_closed_workspace_works(self):
        """Closed workspaces should still be queryable for history."""
        with WhispersTestHarness() as h:
            agent = h.make_client("agent")
            wm = WorkspaceManager(agent.db)
            ws_id = wm.create_workspace("Historical", "agent")
            wm.post_delta(ws_id, "note", "agent", text="Before close")
            wm.close_workspace(ws_id, "agent")

            state = wm.get_state(ws_id)
            assert state["workspace"]["status"] == "closed"
            texts = [d.get("text", "") for d in state["deltas"]]
            assert "Before close" in texts

    def test_observer_cannot_post_delta(self):
        """Observers can read but not write."""
        with WhispersTestHarness() as h:
            creator = h.make_client("creator")
            observer = h.make_client("observer")

            wm = WorkspaceManager(creator.db)
            ws_id = wm.create_workspace("Observable", "creator")
            wm.join_workspace(ws_id, "observer", membership_role="observer")

            with pytest.raises(WhispersDBError, match="observer"):
                wm.post_delta(ws_id, "note", "observer", text="I shouldn't be able to write")
