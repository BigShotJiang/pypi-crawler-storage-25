import importlib
import json
import shutil
import uuid
from pathlib import Path

from fastapi.testclient import TestClient

from whispers.client import WhispersClient


def _make_case_dir() -> Path:
    root = Path(__file__).resolve().parents[1] / ".tmp"
    root.mkdir(parents=True, exist_ok=True)
    case_dir = root / f"mcp-resource-packets-{uuid.uuid4().hex}"
    case_dir.mkdir(parents=True, exist_ok=False)
    return case_dir


def _mcp_initialize(client: TestClient, agent_name: str, token: str) -> dict:
    response = client.post(
        f"/mcp/?agent={agent_name}",
        json={
            "jsonrpc": "2.0",
            "id": 1,
            "method": "initialize",
            "params": {
                "protocolVersion": "2024-11-05",
                "capabilities": {},
                "clientInfo": {"name": "pytest", "version": "1.0"},
            },
        },
        headers={
            "Authorization": f"Bearer {token}",
            "Accept": "text/event-stream, application/json",
        },
    )
    assert response.status_code == 200
    return response.json()


def _mcp_read_resource(client: TestClient, agent_name: str, token: str, uri: str) -> str:
    response = client.post(
        f"/mcp/?agent={agent_name}",
        json={
            "jsonrpc": "2.0",
            "id": 2,
            "method": "resources/read",
            "params": {"uri": uri},
        },
        headers={
            "Authorization": f"Bearer {token}",
            "Accept": "text/event-stream, application/json",
        },
    )
    assert response.status_code == 200
    return response.json()["result"]["contents"][0]["text"]


def test_mcp_outbox_resource_returns_human_readable_delivery_state(monkeypatch):
    case_dir = _make_case_dir()
    db_path = case_dir / "network.db"

    try:
        monkeypatch.setenv("WHISPERS_DB_PATH", str(db_path))
        monkeypatch.setenv("WHISPERS_MCP_TOKEN", "mcp-outbox-token")

        import whispers.server as server_module

        server_module = importlib.reload(server_module)

        with TestClient(server_module.app) as client:
            alpha = WhispersClient("alpha", db_path=str(db_path))
            WhispersClient("beta", db_path=str(db_path))
            alpha.send("beta", "Outbox packet", body="machine readable")

            _mcp_initialize(client, "alpha", "mcp-outbox-token")
            text = _mcp_read_resource(client, "alpha", "mcp-outbox-token", "whispers://outbox")

            assert "Outbox packet" in text
            assert "beta" in text
            assert "(delivered)" in text or "(queued)" in text or "(unclaimed)" in text
    finally:
        shutil.rmtree(case_dir, ignore_errors=True)


def test_mcp_outbox_packet_resource_returns_machine_readable_snapshot(monkeypatch):
    case_dir = _make_case_dir()
    db_path = case_dir / "network.db"

    try:
        monkeypatch.setenv("WHISPERS_DB_PATH", str(db_path))
        monkeypatch.setenv("WHISPERS_MCP_TOKEN", "mcp-outbox-packet-token")

        import whispers.server as server_module

        server_module = importlib.reload(server_module)

        with TestClient(server_module.app) as client:
            alpha = WhispersClient("alpha", db_path=str(db_path))
            WhispersClient("beta", db_path=str(db_path))
            alpha.send("beta", "Outbox packet", body="machine readable")

            _mcp_initialize(client, "alpha", "mcp-outbox-packet-token")
            payload = json.loads(
                _mcp_read_resource(client, "alpha", "mcp-outbox-packet-token", "whispers://outbox-packet")
            )

            assert payload["agent_name"] == "alpha"
            assert payload["resource"] == "whispers://outbox-packet"
            assert payload["state"] == "messages"
            assert payload["message_count"] == 1
            assert payload["messages"][0]["to_agent"] == "beta"
            assert payload["messages"][0]["subject"] == "Outbox packet"
            assert payload["messages"][0]["delivery_status"] in {"delivered", "queued", "unclaimed"}
    finally:
        shutil.rmtree(case_dir, ignore_errors=True)


def test_mcp_handoffs_resource_returns_human_readable_baton_state(monkeypatch):
    case_dir = _make_case_dir()
    db_path = case_dir / "network.db"

    try:
        monkeypatch.setenv("WHISPERS_DB_PATH", str(db_path))
        monkeypatch.setenv("WHISPERS_MCP_TOKEN", "mcp-handoffs-token")

        import whispers.server as server_module

        server_module = importlib.reload(server_module)

        with TestClient(server_module.app) as client:
            sender = WhispersClient("antigravity", db_path=str(db_path))
            WhispersClient("codex", db_path=str(db_path))
            sender.send_handoff(
                "codex",
                objective="Build handoff packet",
                deliverable="Resource parity",
                next_action="Read the baton packet.",
                human_summary="Handed the packet surface follow-through to Codex.",
                workspace_id="ws_packet_truth",
            )

            _mcp_initialize(client, "codex", "mcp-handoffs-token")
            text = _mcp_read_resource(client, "codex", "mcp-handoffs-token", "whispers://handoffs")

            assert "antigravity" in text
            assert "codex" in text
            assert "Read the baton packet." in text
            assert "workspace ws_packet_truth" in text
    finally:
        shutil.rmtree(case_dir, ignore_errors=True)


def test_mcp_handoffs_packet_resource_returns_machine_readable_snapshot(monkeypatch):
    case_dir = _make_case_dir()
    db_path = case_dir / "network.db"

    try:
        monkeypatch.setenv("WHISPERS_DB_PATH", str(db_path))
        monkeypatch.setenv("WHISPERS_MCP_TOKEN", "mcp-handoffs-packet-token")

        import whispers.server as server_module

        server_module = importlib.reload(server_module)

        with TestClient(server_module.app) as client:
            sender = WhispersClient("antigravity", db_path=str(db_path))
            WhispersClient("codex", db_path=str(db_path))
            sender.send_handoff(
                "codex",
                objective="Build handoff packet",
                deliverable="Resource parity",
                next_action="Read the baton packet.",
                human_summary="Handed the packet surface follow-through to Codex.",
                workspace_id="ws_packet_truth",
            )

            _mcp_initialize(client, "codex", "mcp-handoffs-packet-token")
            payload = json.loads(
                _mcp_read_resource(client, "codex", "mcp-handoffs-packet-token", "whispers://handoffs-packet")
            )

            assert payload["agent_name"] == "codex"
            assert payload["resource"] == "whispers://handoffs-packet"
            assert payload["state"] == "handoffs"
            assert payload["handoff_count"] == 1
            assert payload["handoffs"][0]["from_agent"] == "antigravity"
            assert payload["handoffs"][0]["recipient_callsign"] == "codex"
            assert payload["handoffs"][0]["next_action"] == "Read the baton packet."
            assert payload["handoffs"][0]["workspace_id"] == "ws_packet_truth"
    finally:
        shutil.rmtree(case_dir, ignore_errors=True)
