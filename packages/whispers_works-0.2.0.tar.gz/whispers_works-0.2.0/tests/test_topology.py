"""Tests for topology enrichment — collaboration-aware agent state derivation.

Validates the state derivation logic from NEXT-BUILD-ORDER-COLLABORATION-RUNTIME.md Item 7:
  - available, busy, blocked, reviewing, synthesizing, carrying the baton, winding_down, degraded, offline
"""

from whispers.topology import TopologyState, derive_topology_state, enrich_agent_presence


def test_offline_is_highest_priority():
    """Offline overrides everything."""
    state, _ = derive_topology_state(
        cognitive_state="building",
        readiness="busy",
        derived_active_mode="offline",
    )
    assert state == TopologyState.OFFLINE


def test_degraded_overrides_busy():
    """System-level degradation overrides work state."""
    state, _ = derive_topology_state(
        cognitive_state="building",
        derived_active_mode="degraded",
    )
    assert state == TopologyState.DEGRADED

    state2, _ = derive_topology_state(
        cognitive_state="building",
        derived_active_mode="overloaded",
    )
    assert state2 == TopologyState.DEGRADED


def test_blocked_from_readiness():
    """Explicit blocked readiness maps to blocked topology."""
    state, _ = derive_topology_state(readiness="blocked")
    assert state == TopologyState.BLOCKED

    state2, detail = derive_topology_state(readiness="paused_by_operator")
    assert state2 == TopologyState.BLOCKED
    assert "operator" in detail.lower()


def test_blocked_from_cognitive_state():
    """Wag cognitive_state 'blocked' maps to blocked topology."""
    state, _ = derive_topology_state(cognitive_state="blocked")
    assert state == TopologyState.BLOCKED


def test_carrying_baton():
    """Agent with pending handoff shows as carrying baton."""
    state, _ = derive_topology_state(
        cognitive_state="listening",
        readiness="ready",
        has_pending_handoff=True,
    )
    assert state == TopologyState.CARRYING_BATON


def test_reviewing_from_workspace_activity():
    """Recent review/decision workspace activity → reviewing state."""
    state, _ = derive_topology_state(
        cognitive_state="building",
        recent_workspace_kinds=["review", "note"],
    )
    assert state == TopologyState.REVIEWING


def test_reviewing_from_intent():
    """Intent containing review keywords → reviewing state."""
    state, _ = derive_topology_state(
        cognitive_state="building",
        intent="Reviewing Antigravity's ephemeral telemetry plan",
    )
    assert state == TopologyState.REVIEWING


def test_synthesizing_from_intent():
    """Intent containing synthesis keywords → synthesizing state."""
    state, _ = derive_topology_state(
        cognitive_state="exploring",
        intent="Synthesizing research on coordination taxonomies",
    )
    assert state == TopologyState.SYNTHESIZING


def test_busy_from_building():
    """Building/exploring/eureka cognitive states → busy topology."""
    for cs in ("building", "exploring", "eureka"):
        state, _ = derive_topology_state(cognitive_state=cs)
        assert state == TopologyState.BUSY, f"Expected BUSY for cognitive_state={cs}"


def test_busy_from_readiness():
    """Busy readiness → busy topology."""
    state, _ = derive_topology_state(readiness="busy")
    assert state == TopologyState.BUSY


def test_winding_down():
    """Winding down cognitive state → winding_down topology."""
    state, _ = derive_topology_state(cognitive_state="winding_down")
    assert state == TopologyState.WINDING_DOWN


def test_default_is_available():
    """No strong signals → available."""
    state, _ = derive_topology_state()
    assert state == TopologyState.AVAILABLE

    state2, _ = derive_topology_state(cognitive_state="listening", readiness="ready")
    assert state2 == TopologyState.AVAILABLE


def test_enrich_agent_presence_adds_fields():
    """enrich_agent_presence adds topology_state and topology_detail."""
    agent = {
        "callsign": "claude-code",
        "cognitive_state": "building",
        "readiness": "busy",
        "derived_active_mode": "busy",
        "working_on": "Repo coordination module",
    }
    enriched = enrich_agent_presence(agent)
    assert "topology_state" in enriched
    assert "topology_detail" in enriched
    assert enriched["topology_state"] == "busy"
    # Original fields preserved
    assert enriched["callsign"] == "claude-code"


def test_enrich_preserves_original():
    """enrich_agent_presence doesn't mutate the input dict."""
    agent = {"cognitive_state": "listening", "readiness": "ready", "derived_active_mode": "ready"}
    enriched = enrich_agent_presence(agent)
    assert "topology_state" not in agent
    assert "topology_state" in enriched


def test_priority_order_blocked_over_baton():
    """Blocked takes priority over carrying baton."""
    state, _ = derive_topology_state(
        readiness="blocked",
        has_pending_handoff=True,
    )
    assert state == TopologyState.BLOCKED


def test_priority_order_baton_over_review():
    """Carrying baton takes priority over reviewing."""
    state, _ = derive_topology_state(
        cognitive_state="building",
        has_pending_handoff=True,
        recent_workspace_kinds=["review"],
    )
    assert state == TopologyState.CARRYING_BATON
