import pytest
import shutil
import tempfile
import json
import importlib
import asyncio
from pathlib import Path
from fastapi.testclient import TestClient

from whispers import client as client_module
import whispers.server as server_module

def _make_case_dir():
    d = tempfile.mkdtemp(prefix="whispers_volatile_telemetry_test_")
    return Path(d)

def test_ephemeral_message_bypasses_sqlite(monkeypatch):
    case_dir = _make_case_dir()
    db_path = case_dir / "network.db"

    try:
        monkeypatch.setenv("WHISPERS_DB_PATH", str(db_path))
        monkeypatch.setenv("WHISPERS_REMOTE_ADMISSION_MODE", "open")
        importlib.reload(server_module)

        with TestClient(server_module.app) as client:
            alpha_res = client.post("/connect", json={"agent_name": "alpha"}).json()
            assert "token" in alpha_res, str(alpha_res)
            alpha_token = alpha_res["token"]

            beta_res = client.post("/connect", json={"agent_name": "beta"}).json()
            assert "token" in beta_res, str(beta_res)
            beta_token = beta_res["token"]

            # Listen directly on SSE transport to verify volatile delivery
            q = asyncio.Queue()
            server_module.sse.add_listener("beta", q)

            # Fire an ephemeral message from alpha to beta
            send_res = client.post(
                "/message:send",
                json={
                    "to": "beta",
                    "subject": "transient state change",
                    "msg_type": "inform",
                    "ephemeral": True,
                    "payload": {"state": "eureka"}
                },
                headers={
                    "Authorization": f"Bearer {alpha_token}",
                    "A2A-Version": "1.0"
                }
            )
            assert send_res.status_code == 200, f"Send failed: {send_res.text}"
            msg_id = send_res.json().get("id")
            assert msg_id

            # Verify it arrived on the SSE transport queue immediately
            envelope = q.get_nowait()
            assert envelope.id == msg_id
            assert envelope.subject == "transient state change"
            assert envelope.ephemeral is True

            # Verify it bypassed SQLite persistence
            import sqlite3
            with sqlite3.connect(db_path) as conn:
                cursor = conn.cursor()
                cursor.execute("SELECT count(*) FROM messages WHERE uuid = ?", (msg_id,))
                count = cursor.fetchone()[0]
                assert count == 0, "Ephemeral message was incorrectly persisted to SQLite."

            server_module.sse.remove_listener("beta", q)

    finally:
        shutil.rmtree(case_dir, ignore_errors=True)
