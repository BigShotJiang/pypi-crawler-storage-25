"""Tests for scope-aware artifact fetch policy (security item #7).

Covers:
- Blob provenance recording on store
- Same-workspace fetch allowed
- Cross-workspace fetch blocked for non-members
- Unscoped blob always accessible
- operator_override bypasses scope check
- delegated_capability bypasses scope check
- Security events recorded for all outcomes
"""

import json
import pytest


class TestBlobProvenance:
    @pytest.fixture
    def setup(self, tmp_path):
        from whispers.storage.db import WhispersDB
        from whispers.client import WhispersClient

        db_path = str(tmp_path / "test_scope.db")
        db = WhispersDB(db_path=db_path)

        # Create two workspaces
        with db.get_connection() as conn:
            conn.execute(
                "INSERT INTO workspaces (workspace_id, purpose, status, created_by, created_at) VALUES (?, ?, ?, ?, datetime('now'))",
                ("ws_alpha", "Alpha team workspace", "active", "operator"),
            )
            conn.execute(
                "INSERT INTO workspaces (workspace_id, purpose, status, created_by, created_at) VALUES (?, ?, ?, ?, datetime('now'))",
                ("ws_beta", "Beta team workspace", "active", "operator"),
            )
            # Alice is a member of ws_alpha only
            conn.execute(
                "INSERT INTO workspace_members (workspace_id, agent_name, membership_role, membership_state, joined_at) VALUES (?, ?, ?, ?, datetime('now'))",
                ("ws_alpha", "alice", "member", "active"),
            )
            # Bob is a member of ws_beta only
            conn.execute(
                "INSERT INTO workspace_members (workspace_id, agent_name, membership_role, membership_state, joined_at) VALUES (?, ?, ?, ?, datetime('now'))",
                ("ws_beta", "bob", "member", "active"),
            )
            # Charlie is in both
            conn.execute(
                "INSERT INTO workspace_members (workspace_id, agent_name, membership_role, membership_state, joined_at) VALUES (?, ?, ?, ?, datetime('now'))",
                ("ws_alpha", "charlie", "member", "active"),
            )
            conn.execute(
                "INSERT INTO workspace_members (workspace_id, agent_name, membership_role, membership_state, joined_at) VALUES (?, ?, ?, ?, datetime('now'))",
                ("ws_beta", "charlie", "member", "active"),
            )
            conn.commit()

        alice = WhispersClient("alice", db_path=db_path)
        bob = WhispersClient("bob", db_path=db_path)
        charlie = WhispersClient("charlie", db_path=db_path)

        return db, alice, bob, charlie

    def test_provenance_recorded_on_store(self, setup):
        db, alice, bob, charlie = setup
        ref = alice.store_blob(b"secret data", workspace_id="ws_alpha")
        provenance = db.get_blob_provenance(ref["ref"])
        assert provenance is not None
        assert provenance["stored_by"] == "alice"
        assert provenance["workspace_id"] == "ws_alpha"

    def test_provenance_recorded_without_workspace(self, setup):
        db, alice, bob, charlie = setup
        ref = alice.store_blob(b"public data")
        provenance = db.get_blob_provenance(ref["ref"])
        assert provenance is not None
        assert provenance["stored_by"] == "alice"
        assert provenance["workspace_id"] is None

    def test_same_workspace_member_can_fetch(self, setup):
        db, alice, bob, charlie = setup
        ref = alice.store_blob(b"alpha secret", workspace_id="ws_alpha")
        # Charlie is also in ws_alpha
        data = charlie.fetch_blob(ref["ref"], current_scope="ws_alpha")
        assert data == b"alpha secret"

    def test_cross_workspace_blocked(self, setup):
        db, alice, bob, charlie = setup
        ref = alice.store_blob(b"alpha only", workspace_id="ws_alpha")
        # Bob is NOT in ws_alpha — should be blocked
        data = bob.fetch_blob(ref["ref"], current_scope="ws_beta")
        assert data is None

    def test_cross_workspace_blocked_even_without_current_scope(self, setup):
        db, alice, bob, charlie = setup
        ref = alice.store_blob(b"alpha only", workspace_id="ws_alpha")
        # Bob doesn't declare a scope, but blob is scoped — still blocked
        data = bob.fetch_blob(ref["ref"])
        assert data is None

    def test_unscoped_blob_accessible_to_anyone(self, setup):
        db, alice, bob, charlie = setup
        ref = alice.store_blob(b"public content")
        data = bob.fetch_blob(ref["ref"])
        assert data == b"public content"

    def test_operator_override_bypasses_scope(self, setup):
        db, alice, bob, charlie = setup
        ref = alice.store_blob(b"alpha restricted", workspace_id="ws_alpha")
        # Bob is NOT in ws_alpha but uses operator_override
        data = bob.fetch_blob(ref["ref"], operator_override=True)
        assert data == b"alpha restricted"

    def test_delegated_capability_bypasses_scope(self, setup):
        db, alice, bob, charlie = setup
        ref = alice.store_blob(b"delegated access", workspace_id="ws_alpha")
        # Bob is NOT in ws_alpha but has delegated_capability
        data = bob.fetch_blob(ref["ref"], delegated_capability=True)
        assert data == b"delegated access"

    def test_security_event_recorded_on_block(self, setup):
        db, alice, bob, charlie = setup
        ref = alice.store_blob(b"sensitive", workspace_id="ws_alpha")
        bob.fetch_blob(ref["ref"])

        # Query raw security_events table for full detail
        with db.get_readonly_connection() as conn:
            rows = conn.execute(
                "SELECT event_type, outcome, detail FROM security_events WHERE event_type = 'artifact_fetch' ORDER BY created_at DESC"
            ).fetchall()
        assert len(rows) >= 1
        latest = rows[0]
        assert latest["outcome"] == "cross_scope_blocked"
        detail = json.loads(latest["detail"])
        assert detail["blocked"] is True
        assert detail["source_scope"] == "ws_alpha"

    def test_security_event_recorded_on_allow(self, setup):
        db, alice, bob, charlie = setup
        ref = alice.store_blob(b"team data", workspace_id="ws_alpha")
        charlie.fetch_blob(ref["ref"], current_scope="ws_alpha")

        with db.get_readonly_connection() as conn:
            rows = conn.execute(
                "SELECT event_type, outcome, detail FROM security_events WHERE event_type = 'artifact_fetch' ORDER BY created_at DESC"
            ).fetchall()
        assert len(rows) >= 1
        latest = rows[0]
        assert latest["outcome"] == "same_scope"
        detail = json.loads(latest["detail"])
        assert detail["blocked"] is False

    def test_security_event_on_override(self, setup):
        db, alice, bob, charlie = setup
        ref = alice.store_blob(b"override test", workspace_id="ws_alpha")
        bob.fetch_blob(ref["ref"], operator_override=True)

        with db.get_readonly_connection() as conn:
            rows = conn.execute(
                "SELECT event_type, outcome, detail FROM security_events WHERE event_type = 'artifact_fetch' ORDER BY created_at DESC"
            ).fetchall()
        assert len(rows) >= 1
        latest = rows[0]
        assert latest["outcome"] == "cross_scope_override"
        detail = json.loads(latest["detail"])
        assert detail["blocked"] is False
        assert detail["operator_override"] is True

    def test_multi_workspace_member_can_fetch_from_either(self, setup):
        db, alice, bob, charlie = setup
        ref_alpha = alice.store_blob(b"from alpha", workspace_id="ws_alpha")
        ref_beta = bob.store_blob(b"from beta", workspace_id="ws_beta")
        # Charlie is in both workspaces
        assert charlie.fetch_blob(ref_alpha["ref"]) == b"from alpha"
        assert charlie.fetch_blob(ref_beta["ref"]) == b"from beta"

    def test_blob_without_provenance_is_accessible(self, setup):
        """Pre-existing blobs without provenance records should be fetchable (backward compat)."""
        db, alice, bob, charlie = setup
        # Store directly via BlobStore bypassing provenance
        from whispers.storage.blobs import BlobStore
        store = BlobStore()
        raw_ref = store.put(b"legacy data")
        # No provenance recorded — should be accessible
        data = bob.fetch_blob(raw_ref["ref"])
        assert data == b"legacy data"

    def test_inactive_member_blocked(self, setup):
        """Agent whose membership_state is not 'active' should be blocked."""
        db, alice, bob, charlie = setup
        ref = alice.store_blob(b"active only", workspace_id="ws_alpha")
        # Deactivate charlie's alpha membership
        with db.get_connection() as conn:
            conn.execute(
                "UPDATE workspace_members SET membership_state = 'departed' WHERE workspace_id = ? AND agent_name = ?",
                ("ws_alpha", "charlie"),
            )
            conn.commit()
        data = charlie.fetch_blob(ref["ref"])
        assert data is None
