"""Tests for pre-handoff cognitive load checks.

Covers:
- Ready agent returns "clear"
- Busy agent returns "caution"
- High context_load returns "defer"
- do_not_interrupt returns "defer"
- Offline agent returns "unavailable"
- Degraded quality_risk returns "defer"
- Format advisory produces readable output
"""

import pytest
from whispers.handoff_preflight import check_handoff_readiness, format_preflight_advisory


class TestHandoffPreflight:
    @pytest.fixture
    def setup(self, tmp_path):
        from whispers.storage.db import WhispersDB

        db_path = str(tmp_path / "test_preflight.db")
        db = WhispersDB(db_path=db_path)
        return db

    def _register_agent(self, db, name, readiness="ready", context_load=None, interruptibility=None, quality_risk=None):
        """Register an agent with specific runtime state."""
        session_id = f"sess-{name}"
        with db.get_connection() as conn:
            conn.execute(
                "INSERT OR IGNORE INTO agent_cards (agent_id, callsign, agent_type, trust_tier, registered_at) VALUES (?, ?, ?, ?, datetime('now'))",
                (name, name, "llm", 1),
            )
            conn.execute(
                "INSERT OR IGNORE INTO agent_sessions (session_id, agent_name, session_kind, lease_expires_at) VALUES (?, ?, ?, datetime('now', '+1 hour'))",
                (session_id, name, "local_client"),
            )
            conn.execute(
                """INSERT OR REPLACE INTO agent_runtime_state
                   (session_id, agent_name, readiness, interruptibility, context_load, quality_risk)
                   VALUES (?, ?, ?, ?, ?, ?)""",
                (session_id, name, readiness, interruptibility, context_load, quality_risk),
            )
            conn.commit()

    def test_ready_agent_is_clear(self, setup):
        db = setup
        self._register_agent(db, "worker", readiness="ready", context_load=0.2)
        result = check_handoff_readiness(db, "worker")
        assert result["recommendation"] == "clear"

    def test_busy_agent_is_caution(self, setup):
        db = setup
        self._register_agent(db, "worker", readiness="busy")
        result = check_handoff_readiness(db, "worker")
        assert result["recommendation"] == "caution"

    def test_high_load_is_defer(self, setup):
        db = setup
        self._register_agent(db, "worker", context_load=0.95)
        result = check_handoff_readiness(db, "worker")
        assert result["recommendation"] == "defer"
        assert any("nearly full" in r for r in result["reasons"])

    def test_do_not_interrupt_is_defer(self, setup):
        db = setup
        self._register_agent(db, "worker", interruptibility="do_not_interrupt")
        result = check_handoff_readiness(db, "worker")
        assert result["recommendation"] == "defer"

    def test_offline_is_unavailable(self, setup):
        db = setup
        # Don't create a session — agent is offline
        result = check_handoff_readiness(db, "nobody")
        assert result["recommendation"] == "unavailable"

    def test_high_quality_risk_is_defer(self, setup):
        db = setup
        self._register_agent(db, "worker", quality_risk="high")
        result = check_handoff_readiness(db, "worker")
        assert result["recommendation"] == "defer"
        assert any("hallucinating" in r for r in result["reasons"])

    def test_paused_by_operator_is_unavailable(self, setup):
        db = setup
        self._register_agent(db, "worker", readiness="paused_by_operator")
        result = check_handoff_readiness(db, "worker")
        assert result["recommendation"] == "unavailable"

    def test_medium_load_is_caution(self, setup):
        db = setup
        self._register_agent(db, "worker", context_load=0.75)
        result = check_handoff_readiness(db, "worker")
        assert result["recommendation"] == "caution"

    def test_format_clear(self, setup):
        text = format_preflight_advisory({"target": "bob", "recommendation": "clear", "reasons": []})
        assert "ready" in text

    def test_format_defer(self, setup):
        text = format_preflight_advisory({
            "target": "bob",
            "recommendation": "defer",
            "reasons": ["context window nearly full (95%)"],
        })
        assert "DEFER" in text
        assert "another agent" in text

    def test_format_caution(self, setup):
        text = format_preflight_advisory({
            "target": "bob",
            "recommendation": "caution",
            "reasons": ["agent is busy"],
        })
        assert "CAUTION" in text
