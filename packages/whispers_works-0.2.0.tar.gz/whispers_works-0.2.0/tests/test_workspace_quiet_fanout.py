import pytest
from whispers.client import WhispersClient
from whispers.storage.db import WhispersDB
from whispers.workspaces import WorkspaceManager

def test_workspace_quiet_fanout(temp_db):
    db = WhispersDB(temp_db)
    
    with db.get_connection() as conn:
        conn.execute("INSERT INTO agent_cards (agent_id, callsign, agent_type, realm) VALUES (?, ?, ?, 'local')", ("uid1", "agent_creator", "simulated"))
        conn.execute("INSERT INTO agent_cards (agent_id, callsign, agent_type, realm) VALUES (?, ?, ?, 'local')", ("uid2", "agent_open", "simulated"))
        conn.execute("INSERT INTO agent_cards (agent_id, callsign, agent_type, realm) VALUES (?, ?, ?, 'local')", ("uid3", "agent_quiet", "simulated"))
        
        conn.execute("INSERT INTO presence (agent_name, reception_mode) VALUES (?, 'open')", ("agent_creator",))
        conn.execute("INSERT INTO presence (agent_name, reception_mode) VALUES (?, 'open')", ("agent_open",))
        conn.execute("INSERT INTO presence (agent_name, reception_mode) VALUES (?, 'quiet')", ("agent_quiet",))
        conn.commit()

    manager = WorkspaceManager(db)
    ws_id = manager.create_workspace(purpose="Testing quiet fanout", created_by="agent_creator")
    manager.join_workspace(ws_id, "agent_open")
    manager.join_workspace(ws_id, "agent_quiet")

    # The client needs an agent definition to post events as the creator
    client_creator = WhispersClient(db_path=temp_db, agent_name="agent_creator")
    
    # Verify no fanout yet for the new delta
    with db.get_readonly_connection() as conn:
        initial_count = conn.execute("SELECT COUNT(*) FROM message_recipients").fetchone()[0]

    # Post a new delta
    client_creator.send_workspace_delta(
        workspace_id=ws_id,
        delta_kind="note",
        text="This is a test delta"
    )

    with db.get_readonly_connection() as conn:
        rows = conn.execute("SELECT recipient_callsign FROM message_recipients").fetchall()
        recipients = [r[0] for r in rows]

    # We expect agent_open to receive it
    assert "agent_open" in recipients
    # We expect agent_quiet to NOT receive it
    assert "agent_quiet" not in recipients

    # Verify agent_quiet can still retrieve the workspace data on-demand
    state = manager.get_state(ws_id)
    delta_texts = [d.get("text", "") for d in state.get("deltas", [])]
    assert any("This is a test delta" in t for t in delta_texts if t)
