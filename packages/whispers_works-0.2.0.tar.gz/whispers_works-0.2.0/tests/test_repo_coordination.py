"""Tests for repo/worktree coordination.

Validates the acceptance criteria from REPO-WORKTREE-COORDINATION.md:
  1. Agent can publish repo state (branch, worktree, commits, dirty)
  2. Operator can see which branch/worktree each agent is using
  3. Superseded/archived lanes are visibly marked
  4. Divergence detection when agents are on conflicting assumptions
  5. Lane state transitions (active, handoff_pending, superseded, archived)
"""

import asyncio
import importlib
import sqlite3
import sys

import pytest
from fastapi.testclient import TestClient

import whispers.mcp_server as mcp_module
from whispers.repo_coordination import RepoCoordinator, RepoState, DivergenceWarning
from whispers.storage.db import WhispersDB


def _make_coordinator() -> RepoCoordinator:
    return RepoCoordinator()


def test_publish_and_retrieve_repo_state():
    """Agents can publish repo state and it's retrievable."""
    coord = _make_coordinator()
    coord.publish(RepoState(
        agent_name="claude-code",
        branch="codex/2ack-p1-post-ws0",
        head_commit="3cf8008abc",
        dirty=False,
    ))

    state = coord.get_state("claude-code")
    assert state is not None
    assert state.branch == "codex/2ack-p1-post-ws0"
    assert state.head_commit == "3cf8008abc"
    assert state.dirty is False
    assert state.published_at is not None


def test_get_lanes_returns_all_active_agents():
    """Operator can see all agents' repo states."""
    coord = _make_coordinator()
    coord.publish(RepoState(agent_name="claude-code", branch="codex/2ack-p1-post-ws0", head_commit="3cf8008"))
    coord.publish(RepoState(agent_name="codex", branch="codex/2ack-p1-post-ws0", head_commit="3cf8008"))
    coord.publish(RepoState(agent_name="antigravity", branch="main", head_commit="abc1234"))

    lanes = coord.get_lanes()
    assert len(lanes) == 3
    names = [l.agent_name for l in lanes]
    assert "claude-code" in names
    assert "codex" in names
    assert "antigravity" in names


def test_superseded_lane_marked_visibly():
    """Superseded lanes are visibly marked in the headline."""
    coord = _make_coordinator()
    coord.publish(RepoState(agent_name="codex", branch="old-branch", head_commit="dead000"))
    coord.set_lane_state("codex", "superseded")

    state = coord.get_state("codex")
    assert state.lane_state == "superseded"
    assert "[superseded]" in state.headline


def test_archived_lanes_hidden_by_default():
    """Archived lanes are excluded from get_lanes() unless requested."""
    coord = _make_coordinator()
    coord.publish(RepoState(agent_name="claude-code", branch="main", head_commit="abc"))
    coord.publish(RepoState(agent_name="codex", branch="old-branch", head_commit="def"))
    coord.set_lane_state("codex", "archived")

    lanes = coord.get_lanes()
    assert len(lanes) == 1
    assert lanes[0].agent_name == "claude-code"

    all_lanes = coord.get_lanes(include_archived=True)
    assert len(all_lanes) == 2


def test_divergence_detected_same_branch_different_heads():
    """Two agents on the same branch at different commits triggers a warning."""
    coord = _make_coordinator()
    coord.publish(RepoState(agent_name="claude-code", branch="codex/2ack-p1-post-ws0", head_commit="3cf8008"))
    coord.publish(RepoState(agent_name="codex", branch="codex/2ack-p1-post-ws0", head_commit="a69ea52"))

    warnings = coord.check_divergence()
    assert len(warnings) >= 1
    w = warnings[0]
    assert w.reason == "same_branch_different_heads"
    assert "claude-code" in w.detail
    assert "codex" in w.detail


def test_divergence_detected_superseded_lane():
    """An agent on a superseded lane triggers a warning."""
    coord = _make_coordinator()
    coord.publish(RepoState(agent_name="codex", branch="old-lane", head_commit="dead000"))
    coord.set_lane_state("codex", "superseded")

    warnings = coord.check_divergence()
    assert any(w.reason == "superseded_lane" for w in warnings)


def test_no_divergence_when_aligned():
    """Agents on the same branch at the same commit produce no warnings."""
    coord = _make_coordinator()
    coord.publish(RepoState(agent_name="claude-code", branch="codex/2ack-p1-post-ws0", head_commit="3cf8008"))
    coord.publish(RepoState(agent_name="codex", branch="codex/2ack-p1-post-ws0", head_commit="3cf8008"))

    warnings = coord.check_divergence()
    assert len(warnings) == 0


def test_headline_format():
    """Headline includes branch, short commit, dirty marker, and lane state."""
    coord = _make_coordinator()

    # Clean active
    coord.publish(RepoState(agent_name="claude-code", branch="main", head_commit="abc1234def"))
    assert coord.get_state("claude-code").headline == "claude-code: main @ abc1234"

    # Dirty
    coord.publish(RepoState(agent_name="codex", branch="feature/x", head_commit="def5678", dirty=True))
    assert "feature/x*" in coord.get_state("codex").headline

    # Superseded
    coord.publish(RepoState(agent_name="antigravity", branch="old", head_commit="000dead"))
    coord.set_lane_state("antigravity", "superseded")
    assert "[superseded]" in coord.get_state("antigravity").headline


def test_to_dict_matches_spec_shape():
    """to_dict() output has all fields from REPO-WORKTREE-COORDINATION.md."""
    state = RepoState(
        agent_name="claude-code",
        repo_path="/home/user/dev/whispers",
        branch="main",
        head_commit="abc1234",
        base_commit="000dead",
        dirty=True,
        lane_state="active",
        claimed_paths=["whispers/mcp_server.py"],
        workspace_id="ws_test",
    )
    d = state.to_dict()

    required = {
        "agent_name", "repo_path", "worktree_id", "branch", "base_commit",
        "head_commit", "dirty", "lane_state", "claimed_paths", "workspace_id",
        "upstream_ref", "published_at",
    }
    assert required.issubset(d.keys()), f"Missing fields: {required - d.keys()}"


def test_clear_resets_all():
    """clear() removes all state."""
    coord = _make_coordinator()
    coord.publish(RepoState(agent_name="claude-code", branch="main"))
    assert len(coord.get_lanes()) == 1
    coord.clear()
    assert len(coord.get_lanes()) == 0


def test_publish_repo_state_returns_overlapping_paths():
    """Publishing repo state with claimed paths returns warnings if paths overlap with an active agent."""
    coord = _make_coordinator()
    overlaps1 = coord.publish(RepoState(agent_name="claude-code", claimed_paths=["whispers/client.py"]))
    assert not overlaps1

    overlaps2 = coord.publish(RepoState(agent_name="antigravity", claimed_paths=["whispers/client.py", "whispers/server.py"]))
    assert len(overlaps2) == 1
    assert overlaps2[0].agent_b == "claude-code"
    assert "whispers/client.py" in overlaps2[0].overlapping_paths


def test_divergence_detected_overlapping_claimed_paths():
    """check_divergence detects multiple agents having claimed the same files."""
    coord = _make_coordinator()
    coord.publish(RepoState(agent_name="claude-code", claimed_paths=["tests/"]))
    # Prefix overlap should trigger it
    coord.publish(RepoState(agent_name="codex", claimed_paths=["tests/test_repo_coordination.py"]))

    warnings = coord.check_divergence()
    assert any(w.reason == "overlapping_claims" for w in warnings)

    overlap_warning = next(w for w in warnings if w.reason == "overlapping_claims")
    assert "claude-code" in overlap_warning.detail
    assert "codex" in overlap_warning.detail


def test_db_repo_lanes_persist_across_instances(temp_db):
    """Repo lane truth survives fresh DB instances instead of living only in memory."""
    db = WhispersDB(temp_db)
    db.publish_repo_state(
        RepoState(
            agent_name="claude-code",
            branch="main",
            head_commit="abc1234",
            claimed_paths=["whispers/client.py"],
        )
    )
    db.publish_repo_state(
        RepoState(
            agent_name="codex",
            branch="main",
            head_commit="def5678",
            claimed_paths=["whispers/client.py"],
        )
    )

    reloaded = WhispersDB(temp_db)
    lanes = reloaded.list_repo_lanes()
    warnings = reloaded.check_repo_divergence()

    assert [lane.agent_name for lane in lanes] == ["claude-code", "codex"]
    assert any(w.reason == "same_branch_different_heads" for w in warnings)
    assert any(w.reason == "overlapping_claims" for w in warnings)


def test_db_migrates_legacy_repo_lanes_updated_at_without_warning(temp_db, caplog):
    db = WhispersDB(temp_db)
    db.publish_repo_state(
        RepoState(
            agent_name="codex",
            branch="main",
            head_commit="abc1234",
            claimed_paths=["whispers/client.py"],
        )
    )

    with sqlite3.connect(temp_db) as conn:
        conn.execute("ALTER TABLE repo_lanes RENAME TO repo_lanes_old")
        conn.execute(
            """
            CREATE TABLE repo_lanes (
                agent_name TEXT PRIMARY KEY,
                repo_path TEXT,
                worktree_id TEXT,
                branch TEXT,
                base_commit TEXT,
                head_commit TEXT,
                dirty BOOLEAN NOT NULL DEFAULT FALSE,
                lane_state TEXT NOT NULL DEFAULT 'active',
                claimed_paths_json TEXT,
                workspace_id TEXT,
                upstream_ref TEXT,
                published_at TEXT NOT NULL,
                basis TEXT
            )
            """
        )
        conn.execute(
            """
            INSERT INTO repo_lanes (
                agent_name, repo_path, worktree_id, branch, base_commit, head_commit,
                dirty, lane_state, claimed_paths_json, workspace_id, upstream_ref, published_at, basis
            )
            SELECT
                agent_name, repo_path, worktree_id, branch, base_commit, head_commit,
                dirty, lane_state, claimed_paths_json, workspace_id, upstream_ref, published_at, basis
            FROM repo_lanes_old
            """
        )
        conn.execute("DROP TABLE repo_lanes_old")
        conn.commit()

    caplog.clear()
    caplog.set_level("WARNING", logger="whispers")

    reloaded = WhispersDB(temp_db)
    lanes = reloaded.list_repo_lanes()

    with sqlite3.connect(temp_db) as conn:
        columns = {row[1] for row in conn.execute("PRAGMA table_info(repo_lanes)").fetchall()}
        row = conn.execute(
            "SELECT updated_at FROM repo_lanes WHERE agent_name = ?",
            ("codex",),
        ).fetchone()

    assert "updated_at" in columns
    assert row is not None and row[0]
    assert lanes[0].agent_name == "codex"
    assert not any("_ensure_column(repo_lanes.updated_at) failed" in record.message for record in caplog.records)


def test_server_repo_endpoints_read_persisted_lane_state(temp_db):
    """Server repo endpoints should still work after the in-memory coordinator is cleared."""
    runtime_state_path = temp_db + "-runtime.json"
    original_module = sys.modules.get("whispers.server")
    original_db = getattr(original_module, "db", None) if original_module else None

    with pytest.MonkeyPatch.context() as mp:
        mp.setenv("WHISPERS_DB_PATH", temp_db)
        mp.setenv("WHISPERS_RUNTIME_STATE_PATH", runtime_state_path)
        mp.setenv("WHISPERS_REMOTE_ADMISSION_MODE", "open")

        import whispers.server as server_module

        server_module = importlib.reload(server_module)
        with TestClient(server_module.app) as api:
            alpha = api.post("/connect", json={"agent_name": "alpha"}).json()
            beta = api.post("/connect", json={"agent_name": "beta"}).json()

            first = api.post(
                "/repo:publish",
                json={"branch": "main", "head_commit": "1111111", "claimed_paths": ["whispers/client.py"]},
                headers={"Authorization": f"Bearer {alpha['token']}"},
            )
            second = api.post(
                "/repo:publish",
                json={"branch": "main", "head_commit": "2222222", "claimed_paths": ["whispers/server.py"]},
                headers={"Authorization": f"Bearer {beta['token']}"},
            )

            assert first.status_code == 200
            assert second.status_code == 200

            from whispers.repo_coordination import get_coordinator

            get_coordinator().clear()

            lanes = api.get(
                "/repo/lanes",
                headers={"Authorization": f"Bearer {alpha['token']}"},
            )
            divergence = api.get(
                "/repo/divergence",
                headers={"Authorization": f"Bearer {alpha['token']}"},
            )

            assert lanes.status_code == 200
            assert lanes.json()["total"] == 2
            assert {lane["agent_name"] for lane in lanes.json()["lanes"]} == {"alpha", "beta"}

            assert divergence.status_code == 200
            reasons = {warning["reason"] for warning in divergence.json()["warnings"]}
            assert "same_branch_different_heads" in reasons

    if original_db is not None:
        server_module.db = original_db


def test_mcp_repo_lane_tools_read_persisted_state(temp_db, monkeypatch):
    """MCP repo tools should not depend on process-local coordinator state."""
    monkeypatch.setenv("WHISPERS_DB_PATH", temp_db)
    mcp_module = importlib.reload(sys.modules["whispers.mcp_server"])
    mcp_module._clients.clear()

    token = mcp_module.current_agent_name.set("codex")
    try:
        publish_result = asyncio.run(
            mcp_module.handle_tool(
                "publish_repo_state",
                {
                    "branch": "main",
                    "head_commit": "abc1234",
                    "claimed_paths": ["whispers/storage/db.py"],
                },
            )
        )
        assert "Repo state published" in publish_result[0].text

        from whispers.repo_coordination import get_coordinator

        get_coordinator().clear()

        lanes = asyncio.run(mcp_module.handle_tool("repo_lanes", {}))
        assert "codex: main @ abc1234" in lanes[0].text
    finally:
        mcp_module.current_agent_name.reset(token)
        mcp_module._clients.clear()
