"""Tests for signal protection classification and saturation resilience."""

import pytest

from whispers.envelope import Envelope, Priority, MsgType
from whispers.dispatcher import classify_signal_protection


class TestSignalClassification:
    def test_flash_is_protected(self):
        env = Envelope(sender="a", recipient="b", subject="urgent", priority=Priority.FLASH, msg_type=MsgType.INFORM)
        assert classify_signal_protection(env) == "protected"

    def test_system_is_protected(self):
        env = Envelope(sender="a", recipient="b", subject="sys", priority=Priority.SYSTEM, msg_type=MsgType.INFORM)
        assert classify_signal_protection(env) == "protected"

    def test_handoff_is_protected(self):
        env = Envelope(sender="a", recipient="b", subject="handoff", msg_type=MsgType.HANDOFF)
        assert classify_signal_protection(env) == "protected"

    def test_external_action_request_schema_is_protected(self):
        env = Envelope(
            sender="a", recipient="b", subject="action",
            payload={"schema": "external_action_request.v1"}, msg_type=MsgType.INFORM,
        )
        assert classify_signal_protection(env) == "protected"

    def test_decision_request_schema_is_protected(self):
        env = Envelope(
            sender="a", recipient="b", subject="decide", msg_type=MsgType.INFORM,
            payload={"schema": "decision_request.v1"},
        )
        assert classify_signal_protection(env) == "protected"

    def test_priority_request_is_degradable(self):
        env = Envelope(
            sender="a", recipient="b", subject="review",
            priority=Priority.PRIORITY, msg_type=MsgType.REQUEST,
        )
        assert classify_signal_protection(env) == "degradable"

    def test_routine_inform_is_deferrable(self):
        env = Envelope(
            sender="a", recipient="b", subject="status",
            priority=Priority.ROUTINE, msg_type=MsgType.INFORM,
        )
        assert classify_signal_protection(env) == "deferrable"

    def test_priority_inform_is_degradable(self):
        env = Envelope(
            sender="a", recipient="b", subject="update",
            priority=Priority.PRIORITY, msg_type=MsgType.INFORM,
        )
        assert classify_signal_protection(env) == "degradable"

    def test_flash_overrides_deferrable_type(self):
        """Flash priority should be protected even if msg_type is INFORM."""
        env = Envelope(
            sender="a", recipient="b", subject="alert",
            priority=Priority.FLASH, msg_type=MsgType.INFORM,
        )
        assert classify_signal_protection(env) == "protected"
