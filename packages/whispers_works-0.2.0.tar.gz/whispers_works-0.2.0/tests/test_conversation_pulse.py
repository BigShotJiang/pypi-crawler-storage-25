"""Tests for the conversation pulse tracker.

Validates the core rules from CONVERSATION-PULSE-UX.md:
  1. Conversation presence, not raw flood
  2. Bidirectional detection (both sides must send)
  3. Human-speed rate limiting via time windows
  4. Burst coalescing into grouped activity
  5. Idle fade (active -> recent -> idle)
  6. Backlog safety (old traffic doesn't create live pulses)
"""

import time
from whispers.conversation_pulse import PulseTracker, ConversationPulse


def _make_tracker(**kwargs) -> PulseTracker:
    """Create a tracker with short timeouts for testing."""
    defaults = {"active_timeout": 0.5, "recent_timeout": 1.5, "window": 5.0}
    defaults.update(kwargs)
    return PulseTracker(**defaults)


def test_single_message_creates_unidirectional_pulse():
    """One-way traffic should show as a pulse but NOT bidirectional."""
    tracker = _make_tracker()
    tracker.record_exchange("codex", "claude-code")

    pulses = tracker.get_pulses()
    assert len(pulses) == 1
    p = pulses[0]
    assert p.participants == ["claude-code", "codex"]
    assert p.scope == "direct"
    assert p.state == "active"
    assert p.exchange_count_window == 1
    assert p.bidirectional is False
    assert "\u2192" in p.headline  # → (one-way arrow)


def test_bidirectional_exchange_detected():
    """When both sides send, the pulse should be marked bidirectional."""
    tracker = _make_tracker()
    tracker.record_exchange("codex", "claude-code")
    tracker.record_exchange("claude-code", "codex")

    pulses = tracker.get_pulses()
    assert len(pulses) == 1
    p = pulses[0]
    assert p.bidirectional is True
    assert "\u2194" in p.headline  # ↔ (two-way arrow)
    assert p.exchange_count_window == 2


def test_burst_coalescing_counts_exchanges():
    """Rapid exchanges should be coalesced into one pulse with a count."""
    tracker = _make_tracker()
    for i in range(6):
        sender = "codex" if i % 2 == 0 else "claude-code"
        tracker.record_exchange(sender, "codex" if sender == "claude-code" else "claude-code")

    pulses = tracker.get_pulses()
    assert len(pulses) == 1
    p = pulses[0]
    assert p.exchange_count_window == 6
    assert p.bidirectional is True
    assert "6 exchanges" in p.headline


def test_idle_fade_active_to_recent_to_idle():
    """Pulse should transition from active -> recent -> idle over time."""
    tracker = _make_tracker(active_timeout=0.1, recent_timeout=0.3)
    tracker.record_exchange("codex", "claude-code")

    # Immediately: active
    pulses = tracker.get_pulses()
    assert pulses[0].state == "active"

    # After active timeout: recent
    time.sleep(0.15)
    pulses = tracker.get_pulses()
    assert len(pulses) == 1
    assert pulses[0].state == "recent"

    # After recent timeout: idle (not returned by default)
    time.sleep(0.25)
    pulses = tracker.get_pulses()
    assert len(pulses) == 0

    # But available with include_idle
    pulses = tracker.get_pulses(include_idle=True)
    assert len(pulses) == 1
    assert pulses[0].state == "idle"


def test_separate_conversations_tracked_independently():
    """Different agent pairs should produce separate pulses."""
    tracker = _make_tracker()
    tracker.record_exchange("codex", "claude-code")
    tracker.record_exchange("antigravity", "claude-code")

    pulses = tracker.get_pulses()
    assert len(pulses) == 2
    keys = {p.conversation_key for p in pulses}
    assert "direct:claude-code:codex" in keys
    assert "direct:antigravity:claude-code" in keys


def test_conversation_key_is_canonical():
    """A->B and B->A should map to the same conversation key."""
    tracker = _make_tracker()
    tracker.record_exchange("codex", "claude-code")
    tracker.record_exchange("claude-code", "codex")

    pulses = tracker.get_pulses()
    assert len(pulses) == 1  # Same conversation, not two


def test_topic_hint_preserved():
    """Topic hint from the latest exchange should be preserved."""
    tracker = _make_tracker()
    tracker.record_exchange("codex", "claude-code", topic_hint="startup investigation")

    pulses = tracker.get_pulses()
    assert pulses[0].topic_hint == "startup investigation"


def test_pulse_to_dict_matches_spec_shape():
    """to_dict() output must match the shape defined in CONVERSATION-PULSE-UX.md."""
    tracker = _make_tracker()
    tracker.record_exchange("codex", "claude-code", topic_hint="test topic")
    tracker.record_exchange("claude-code", "codex")

    pulse = tracker.get_pulses()[0]
    d = pulse.to_dict()

    # All spec fields present
    required_fields = {
        "conversation_key", "participants", "scope", "state",
        "exchange_count_window", "window_seconds", "last_activity_at",
        "headline", "topic_hint", "bidirectional",
    }
    assert required_fields.issubset(d.keys()), f"Missing fields: {required_fields - d.keys()}"
    assert isinstance(d["participants"], list)
    assert isinstance(d["exchange_count_window"], int)
    assert isinstance(d["window_seconds"], float)
    assert isinstance(d["bidirectional"], bool)


def test_clear_resets_all_state():
    """clear() should remove all tracked conversations."""
    tracker = _make_tracker()
    tracker.record_exchange("codex", "claude-code")
    assert len(tracker.get_pulses()) == 1

    tracker.clear()
    assert len(tracker.get_pulses()) == 0


def test_headline_format_for_active_burst():
    """Active burst headline should match 'A ↔ B active · N exchanges in Xs'."""
    tracker = _make_tracker()
    tracker.record_exchange("codex", "claude-code")
    tracker.record_exchange("claude-code", "codex")
    tracker.record_exchange("codex", "claude-code")
    tracker.record_exchange("claude-code", "codex")

    pulse = tracker.get_pulses()[0]
    assert "claude-code" in pulse.headline
    assert "codex" in pulse.headline
    assert "active" in pulse.headline
    assert "4 exchanges" in pulse.headline
