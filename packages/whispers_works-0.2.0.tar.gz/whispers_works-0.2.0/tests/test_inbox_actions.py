"""Tests for inbox organization: pin, snooze, archive."""

from whispers.client import WhispersClient
from whispers.storage.db import WhispersDB


def test_pin_message(temp_db):
    """Pinned messages should have pinned_at set."""
    sender = WhispersClient("alice", db_path=temp_db)
    receiver = WhispersClient("bob", db_path=temp_db)

    sender.send("bob", subject="Important", body="Read this")
    inbox = receiver.check_inbox()
    assert len(inbox) >= 1
    msg_uuid = inbox[0]["uuid"]

    db = WhispersDB(db_path=temp_db)
    db.message_action(msg_uuid, "bob", "pin")

    with db.get_connection() as conn:
        row = conn.execute(
            "SELECT pinned_at FROM message_recipients WHERE message_uuid = ? AND recipient_callsign = ?",
            (msg_uuid, "bob"),
        ).fetchone()
    assert row["pinned_at"] is not None


def test_unpin_message(temp_db):
    """Unpinning should clear pinned_at."""
    sender = WhispersClient("alice", db_path=temp_db)
    receiver = WhispersClient("bob", db_path=temp_db)

    sender.send("bob", subject="Important", body="Read this")
    inbox = receiver.check_inbox()
    msg_uuid = inbox[0]["uuid"]

    db = WhispersDB(db_path=temp_db)
    db.message_action(msg_uuid, "bob", "pin")
    db.message_action(msg_uuid, "bob", "unpin")

    with db.get_connection() as conn:
        row = conn.execute(
            "SELECT pinned_at FROM message_recipients WHERE message_uuid = ? AND recipient_callsign = ?",
            (msg_uuid, "bob"),
        ).fetchone()
    assert row["pinned_at"] is None


def test_snooze_message(temp_db):
    """Snoozed messages should have snoozed_until set."""
    sender = WhispersClient("alice", db_path=temp_db)
    receiver = WhispersClient("bob", db_path=temp_db)

    sender.send("bob", subject="Later", body="Can wait")
    inbox = receiver.check_inbox()
    msg_uuid = inbox[0]["uuid"]

    db = WhispersDB(db_path=temp_db)
    db.message_action(msg_uuid, "bob", "snooze", snooze_minutes=30)

    with db.get_connection() as conn:
        row = conn.execute(
            "SELECT snoozed_until FROM message_recipients WHERE message_uuid = ? AND recipient_callsign = ?",
            (msg_uuid, "bob"),
        ).fetchone()
    assert row["snoozed_until"] is not None


def test_unsnooze_message(temp_db):
    """Unsnoozing should clear snoozed_until."""
    sender = WhispersClient("alice", db_path=temp_db)
    receiver = WhispersClient("bob", db_path=temp_db)

    sender.send("bob", subject="Later", body="Can wait")
    inbox = receiver.check_inbox()
    msg_uuid = inbox[0]["uuid"]

    db = WhispersDB(db_path=temp_db)
    db.message_action(msg_uuid, "bob", "snooze", snooze_minutes=30)
    db.message_action(msg_uuid, "bob", "unsnooze")

    with db.get_connection() as conn:
        row = conn.execute(
            "SELECT snoozed_until FROM message_recipients WHERE message_uuid = ? AND recipient_callsign = ?",
            (msg_uuid, "bob"),
        ).fetchone()
    assert row["snoozed_until"] is None


def test_archive_message(temp_db):
    """Archived messages should have archived_at set."""
    sender = WhispersClient("alice", db_path=temp_db)
    receiver = WhispersClient("bob", db_path=temp_db)

    sender.send("bob", subject="Done", body="Handled")
    inbox = receiver.check_inbox()
    msg_uuid = inbox[0]["uuid"]

    db = WhispersDB(db_path=temp_db)
    db.message_action(msg_uuid, "bob", "archive")

    with db.get_connection() as conn:
        row = conn.execute(
            "SELECT archived_at FROM message_recipients WHERE message_uuid = ? AND recipient_callsign = ?",
            (msg_uuid, "bob"),
        ).fetchone()
    assert row["archived_at"] is not None


def test_unarchive_message(temp_db):
    """Unarchiving should clear archived_at."""
    sender = WhispersClient("alice", db_path=temp_db)
    receiver = WhispersClient("bob", db_path=temp_db)

    sender.send("bob", subject="Done", body="Handled")
    inbox = receiver.check_inbox()
    msg_uuid = inbox[0]["uuid"]

    db = WhispersDB(db_path=temp_db)
    db.message_action(msg_uuid, "bob", "archive")
    db.message_action(msg_uuid, "bob", "unarchive")

    with db.get_connection() as conn:
        row = conn.execute(
            "SELECT archived_at FROM message_recipients WHERE message_uuid = ? AND recipient_callsign = ?",
            (msg_uuid, "bob"),
        ).fetchone()
    assert row["archived_at"] is None


def test_unsnooze_expired(temp_db):
    """Maintenance loop should clear expired snoozes."""
    sender = WhispersClient("alice", db_path=temp_db)
    receiver = WhispersClient("bob", db_path=temp_db)

    sender.send("bob", subject="Snoozed", body="test")
    inbox = receiver.check_inbox()
    msg_uuid = inbox[0]["uuid"]

    db = WhispersDB(db_path=temp_db)
    # Snooze with a time in the past (already expired)
    with db.get_connection() as conn:
        conn.execute(
            "UPDATE message_recipients SET snoozed_until = datetime('now', '-1 minutes') WHERE message_uuid = ? AND recipient_callsign = ?",
            (msg_uuid, "bob"),
        )
        conn.commit()

    count = db.unsnooze_expired()
    assert count >= 1

    with db.get_connection() as conn:
        row = conn.execute(
            "SELECT snoozed_until FROM message_recipients WHERE message_uuid = ? AND recipient_callsign = ?",
            (msg_uuid, "bob"),
        ).fetchone()
    assert row["snoozed_until"] is None


def test_invalid_action_raises(temp_db):
    """Unknown actions should raise ValueError."""
    sender = WhispersClient("alice", db_path=temp_db)
    receiver = WhispersClient("bob", db_path=temp_db)

    sender.send("bob", subject="Test", body="test")
    inbox = receiver.check_inbox()
    msg_uuid = inbox[0]["uuid"]

    db = WhispersDB(db_path=temp_db)
    try:
        db.message_action(msg_uuid, "bob", "explode")
        assert False, "Should have raised ValueError"
    except ValueError as e:
        assert "explode" in str(e)


def test_archived_messages_are_hidden_from_default_inbox(temp_db):
    sender = WhispersClient("alice", db_path=temp_db)
    receiver = WhispersClient("bob", db_path=temp_db)

    sent = sender.send("bob", subject="Archive me", body="done")

    db = WhispersDB(db_path=temp_db)
    db.message_action(sent["id"], "bob", "archive")

    inbox = receiver.check_inbox(mark_seen=False)
    assert all(message["uuid"] != sent["id"] for message in inbox)


def test_snoozed_messages_are_hidden_until_unsnoozed(temp_db):
    sender = WhispersClient("alice", db_path=temp_db)
    receiver = WhispersClient("bob", db_path=temp_db)

    sent = sender.send("bob", subject="Snooze me", body="later")

    db = WhispersDB(db_path=temp_db)
    db.message_action(sent["id"], "bob", "snooze", snooze_minutes=30)

    hidden = receiver.check_inbox(mark_seen=False)
    assert all(message["uuid"] != sent["id"] for message in hidden)

    with db.get_connection() as conn:
        conn.execute(
            "UPDATE message_recipients SET snoozed_until = datetime('now', '-1 minutes') WHERE message_uuid = ? AND recipient_callsign = ?",
            (sent["id"], "bob"),
        )
        conn.commit()

    assert db.unsnooze_expired() >= 1

    resurfaced = receiver.check_inbox(mark_seen=False)
    assert any(message["uuid"] == sent["id"] for message in resurfaced)


def test_pinned_messages_sort_to_top_of_default_inbox(temp_db):
    sender = WhispersClient("alice", db_path=temp_db)
    receiver = WhispersClient("bob", db_path=temp_db)

    first = sender.send("bob", subject="First", body="normal")
    second = sender.send("bob", subject="Second", body="pin me")

    db = WhispersDB(db_path=temp_db)
    db.message_action(second["id"], "bob", "pin")

    inbox = receiver.check_inbox(mark_seen=False)

    assert len(inbox) >= 2
    assert inbox[0]["uuid"] == second["id"]
    assert inbox[1]["uuid"] == first["id"]
