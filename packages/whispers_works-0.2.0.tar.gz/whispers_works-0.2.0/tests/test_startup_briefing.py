from whispers.connection_story import ConnectionStory, build_briefing_capsule
from whispers.startup import STARTUP_MESSAGE_HANDLING_RULE, build_startup_briefing


def test_startup_briefing_embeds_inbox_state_rule():
    briefing = build_startup_briefing(
        {
            "self_agent": "codex",
            "my_mode": "OPEN",
            "peers_online_count": 0,
            "pending_messages": 0,
            "pending_by_priority": {},
            "schema_version": 2,
        }
    )

    assert STARTUP_MESSAGE_HANDLING_RULE in briefing["detail_block"]


def test_startup_briefing_omits_priority_breakdown_when_inbox_is_empty():
    briefing = build_startup_briefing(
        {
            "self_agent": "codex",
            "my_mode": "OPEN",
            "peers_online_count": 0,
            "pending_messages": 0,
            "pending_by_priority": {},
            "schema_version": 2,
        }
    )

    assert "Unread by priority:" not in briefing["detail_block"]


def test_startup_briefing_surfaces_deployment_mode():
    briefing = build_startup_briefing(
        {
            "self_agent": "codex",
            "deployment_mode": "remote",
            "my_mode": "OPEN",
            "peers_online_count": 0,
            "pending_messages": 0,
            "pending_by_priority": {},
            "schema_version": 2,
        }
    )

    assert "Deployment: Remote" in briefing["detail_block"]


def test_startup_briefing_normalizes_queue_class_and_attention_treatment():
    briefing = build_startup_briefing(
        {
            "self_agent": "codex",
            "my_mode": "OPEN",
            "readiness": "busy",
            "interruptibility": "do_not_interrupt",
            "peers_online_count": 0,
            "pending_messages": 4,
            "pending_by_priority": {"routine": 4},
            "pending_by_class": {"actionable": 1, "conversation": 2, "reference": 1},
            "schema_version": 2,
        }
    )

    assert "Unread by class: actionable 1, conversation 2, archive/history 1" in briefing["detail_block"]
    assert "Attention treatment: hold quietly 3, archive only 1" in briefing["detail_block"]
    assert briefing["attention_treatment"]["counts"]["hold_quietly"] == 3
    assert briefing["pending_by_class"]["archive_history"] == 1


def test_startup_briefing_surfaces_wake_posture():
    briefing = build_startup_briefing(
        {
            "self_agent": "codex",
            "my_mode": "OPEN",
            "wake_model": "manual_wake",
            "interruptibility": "defer",
            "peers_online_count": 0,
            "pending_messages": 0,
            "pending_by_priority": {},
            "schema_version": 2,
        }
    )

    assert "Wake posture: manual-wake | pickup requires explicit ack | re-entry: bounded catch-up | interruptibility defer" in briefing["detail_block"]
    assert briefing["wake_posture"]["wake_model"] == "manual_wake"


def test_connection_story_briefing_reuses_shared_message_rule():
    capsule = build_briefing_capsule(ConnectionStory(agent_name="codex"))

    assert STARTUP_MESSAGE_HANDLING_RULE in capsule["detail_block"]


def test_startup_briefings_surface_local_client_auth_gap():
    issue = (
        "Startup/client surfaces auth failed for codex. "
        "The available token is not a valid remote client token for /connect, /inbox, or /message:stream. "
        "Use the Whispers MCP startup path for live startup, or provision a real client token for this agent."
    )
    briefing = build_startup_briefing(
        {
            "self_agent": "codex",
            "my_mode": "OPEN",
            "peers_online_count": 0,
            "pending_messages": 0,
            "pending_by_priority": {},
            "schema_version": 2,
            "local_client_auth_healthy": False,
            "local_client_token_source": "mcp_token",
            "local_client_auth_issue": issue,
        }
    )
    capsule = build_briefing_capsule(
        ConnectionStory(
            agent_name="codex",
            local_client_auth_healthy=False,
            local_client_token_source="mcp_token",
            local_client_auth_issue=issue,
        )
    )

    assert "Startup/client auth: DEGRADED (mcp_token)" in briefing["detail_block"]
    assert issue in briefing["detail_block"]
    assert "Startup/client auth: DEGRADED (mcp_token)" in capsule["detail_block"]
    assert issue in capsule["detail_block"]


def test_startup_briefing_surfaces_huddle_peers():
    briefing = build_startup_briefing(
        {
            "self_agent": "codex",
            "my_mode": "OPEN",
            "peers_online_count": 1,
            "pending_messages": 0,
            "pending_by_priority": {},
            "schema_version": 2,
            "huddle_peers": [
                {
                    "agent_name": "antigravity",
                    "readiness": "ready",
                    "shared_workspaces": ["Collaboration Runtime"],
                    "incoming_baton_from_peer": True,
                    "incoming_baton_count": 1,
                }
            ],
        }
    )

    assert "Huddle nearby: antigravity [ready] | workspace Collaboration Runtime | ← [🟨 BATON x1]" in briefing["detail_block"]


def test_startup_briefing_surfaces_visual_baton_state():
    briefing = build_startup_briefing(
        {
            "self_agent": "codex",
            "my_mode": "OPEN",
            "peers_online_count": 0,
            "pending_messages": 0,
            "pending_by_priority": {},
            "incoming_batons": 1,
            "carrying_batons": 2,
            "claimed_reviews": 1,
            "schema_version": 2,
        }
    )

    assert "BATON state: ← [🟨 BATON x1] | → [🟦 BATON x2] | ◈ [🟪 REVIEW x1]" in briefing["detail_block"]


def test_startup_briefing_surfaces_operator_nudge_for_manual_wake_peer():
    briefing = build_startup_briefing(
        {
            "self_agent": "codex",
            "my_mode": "OPEN",
            "peers_online_count": 1,
            "pending_messages": 0,
            "pending_by_priority": {},
            "schema_version": 2,
            "peer_assignment_alerts": [
                {
                    "agent_name": "antigravity",
                    "attention_state": "needs_assignment",
                    "attention_detail": "Main and backup packets are complete.",
                    "trust_tier": 3,
                    "wake_model": "manual_wake",
                }
            ],
        }
    )

    assert "operator nudge required" in briefing["detail_block"]
    assert briefing["peer_nudge_requests"] == 1
    assert briefing["peer_nudge_alerts"][0]["name"] == "antigravity"


def test_startup_briefing_skips_operator_nudge_for_manual_wake_peer_with_jolt_path():
    briefing = build_startup_briefing(
        {
            "self_agent": "codex",
            "my_mode": "OPEN",
            "peers_online_count": 1,
            "pending_messages": 0,
            "pending_by_priority": {},
            "schema_version": 2,
            "peer_assignment_alerts": [
                {
                    "agent_name": "claude-code",
                    "attention_state": "needs_assignment",
                    "attention_detail": "Ready for the next slice.",
                    "trust_tier": 3,
                    "wake_model": "manual_wake",
                    "jolt_host_capabilities": {
                        "host_kind": "claude_code",
                        "can_notify": True,
                        "can_stage_context": True,
                        "can_trigger_inference": True,
                        "steals_focus": False,
                    },
                    "operator_nudge_required": False,
                }
            ],
        }
    )

    assert briefing["peer_nudge_requests"] == 0
    assert briefing["peer_nudge_alerts"] == []


def test_startup_briefing_surfaces_captain_action_alerts_before_assignment_noise():
    briefing = build_startup_briefing(
        {
            "self_agent": "codex",
            "my_mode": "OPEN",
            "peers_online_count": 1,
            "pending_messages": 2,
            "pending_by_priority": {"priority": 2},
            "schema_version": 2,
            "captain_action_alerts": [
                {
                    "sender": "claude-code",
                    "label": "completion + proposal",
                    "detail": "Completed all 3 items in backup pull order. Ready for next slice.",
                    "priority": "priority",
                }
            ],
            "peer_assignment_alerts": [
                {
                    "agent_name": "claude-code",
                    "attention_state": "needs_assignment",
                    "attention_detail": "Completed all 3 items in backup pull order. Ready for next slice.",
                    "trust_tier": 3,
                    "wake_model": "manual_wake",
                }
            ],
        }
    )

    assert "Captain alert: claude-code completion + proposal pending" in briefing["detail_block"]
    assert briefing["captain_action_requests"] == 1
    assert briefing["captain_action_alerts"][0]["sender"] == "claude-code"
