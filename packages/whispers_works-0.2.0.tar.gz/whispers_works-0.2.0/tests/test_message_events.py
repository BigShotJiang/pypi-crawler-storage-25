import pytest
from whispers.storage.db import WhispersDB
from whispers.envelope import Envelope, Priority, MsgType

def test_message_lifecycle_events(tmp_path):
    events = []
    def on_event(message_id, trace_id, sender, recipient, step):
        events.append({
            "type": "message_lifecycle",
            "message_uuid": message_id,
            "sender_agent": sender,
            "recipient_agent": recipient,
            "lifecycle_step": step,
            "detail": f"Message transitioned to {step}"
        })

    db_path = tmp_path / "test.db"
    db = WhispersDB(str(db_path), on_message_transition=on_event)

    # 1. Queue a message
    env = Envelope(
        sender="alice",
        recipient="bob",
        msg_type=MsgType.REQUEST,
        subject="test query",
        body="hello bob"
    )
    db.store_message(env)

    assert len(events) == 1, f"Expected 1 event, got {len(events)}"
    assert events[0]["lifecycle_step"] == "queued"
    assert events[0]["message_uuid"] == env.id
    assert events[0]["sender_agent"] == "alice"
    assert events[0]["recipient_agent"] == "bob"
    assert events[0]["type"] == "message_lifecycle"
    assert events[0]["detail"] == "Message transitioned to queued"

    # 2. Deliver it
    db.deliver_inbox("bob", limit=10)
    assert len(events) == 2, f"Expected 2 events, got {len(events)}"
    assert events[1]["lifecycle_step"] == "delivered"
    assert events[1]["message_uuid"] == env.id

    # 3. Read it
    # read_inbox will find the 'delivered' message where read_at IS NULL
    db.read_inbox("bob", limit=10)
    assert len(events) == 3, f"Expected 3 events, got {len(events)}"
    assert events[2]["lifecycle_step"] == "read"
    assert events[2]["message_uuid"] == env.id

    # 4. Acknowledge it
    db.acknowledge_message(env.id, "bob", "processed")
    assert len(events) == 4, f"Expected 4 events, got {len(events)}"
    assert events[3]["lifecycle_step"] == "acknowledged"
    assert events[3]["message_uuid"] == env.id

def test_claim_message_delivery(tmp_path):
    events = []
    def on_event(message_id, trace_id, sender, recipient, step):
        events.append({
            "type": "message_lifecycle",
            "message_uuid": message_id,
            "sender_agent": sender,
            "recipient_agent": recipient,
            "lifecycle_step": step,
            "detail": f"Message transitioned to {step}"
        })

    db_path = tmp_path / "test.db"
    db = WhispersDB(str(db_path), on_message_transition=on_event)
    env = Envelope(
        sender="alice",
        recipient="bob",
        msg_type=MsgType.REQUEST,
        subject="test query",
        body="hello bob"
    )
    db.store_message(env)
    assert len(events) == 1
    
    # Use explicit claim delivery
    db.claim_message_delivery(env.id, "bob")
    assert len(events) == 2
    assert events[1]["lifecycle_step"] == "delivered"

    # Ensure ack works out of order
    db.acknowledge_message(env.id, "bob", "processed")
    assert len(events) == 3
    assert events[2]["lifecycle_step"] == "acknowledged"


def test_claim_message_delivery_accepts_unclaimed_delivered_rows(tmp_path):
    db_path = tmp_path / "test.db"
    db = WhispersDB(str(db_path))
    env = Envelope(
        sender="alice",
        recipient="bob",
        msg_type=MsgType.REQUEST,
        subject="delivered but unclaimed",
        body="hello bob"
    )
    db.store_message(env)

    with db.get_connection() as conn:
        conn.execute(
            """
            UPDATE message_recipients
            SET delivery_status = 'delivered'
            WHERE message_uuid = ?
            """,
            (env.id,),
        )
        conn.commit()

    assert db.claim_message_delivery(env.id, "bob") is True

    with db.get_connection() as conn:
        row = conn.execute(
            """
            SELECT delivery_status, claimed_by, claimed_at, read_at
            FROM message_recipients
            WHERE message_uuid = ?
            """,
            (env.id,),
        ).fetchone()

    assert row["delivery_status"] == "delivered"
    assert row["claimed_by"] == "bob"
    assert row["claimed_at"] is not None
    assert row["read_at"] is None

def test_room_delivery_events_use_actual_recipient_callsign(tmp_path):
    events = []

    def on_event(message_id, trace_id, sender, recipient, step):
        events.append({
            "type": "message_lifecycle",
            "message_uuid": message_id,
            "sender_agent": sender,
            "recipient_agent": recipient,
            "lifecycle_step": step,
            "detail": f"Message transitioned to {step}",
        })

    db_path = tmp_path / "test.db"
    db = WhispersDB(str(db_path), on_message_transition=on_event)

    with db.get_connection() as conn:
        conn.execute(
            """
            INSERT INTO agent_cards (agent_id, callsign, agent_type)
            VALUES ('agent-bob', 'bob', 'script')
            """
        )
        conn.execute(
            """
            INSERT INTO rooms (room_id, name, created_by)
            VALUES ('room-ops', 'ops', 'alice')
            """
        )
        conn.execute(
            """
            INSERT INTO room_members (room_id, agent_id)
            VALUES ('room-ops', 'agent-bob')
            """
        )
        conn.commit()

    env = Envelope(
        sender="alice",
        recipient="#ops",
        msg_type=MsgType.REQUEST,
        subject="room query",
        body="hello ops",
    )
    db.store_message(env)
    db.deliver_inbox("bob", limit=10)
    db.read_inbox("bob", limit=10)
    db.acknowledge_message(env.id, "bob", "processed")

    assert [event["lifecycle_step"] for event in events] == ["queued", "delivered", "read", "acknowledged"]
    assert all(event["recipient_agent"] == "bob" for event in events)
