"""Tests for operator stream contract: coalescing, board snapshot, event vocabulary."""

import asyncio
import time

import pytest

from whispers.transports.operator import (
    OperatorEventType,
    OperatorSSETransport,
    OperatorBoardSnapshot,
    SignalFeedFilter,
    coalescing_event_reader,
    _coalesce_batch,
    empty_agent_counters,
    empty_system_counters,
)


# ---------------------------------------------------------------------------
# Event vocabulary coverage
# ---------------------------------------------------------------------------


class TestEventVocabulary:
    def test_known_types_is_complete(self):
        """All named constants are in the _KNOWN set."""
        named = {
            OperatorEventType.HEALTH_RAISED,
            OperatorEventType.HEALTH_CLEARED,
            OperatorEventType.HEALTH_SCAN,
            OperatorEventType.AGENT_WAG,
            OperatorEventType.AGENT_HEARTBEAT,
            OperatorEventType.REVIEW_PUBLISHED,
            OperatorEventType.REVIEW_CLAIMED,
            OperatorEventType.REVIEW_RESOLVED,
            OperatorEventType.REVIEW_VERDICT,
            OperatorEventType.BOARD_SNAPSHOT,
            OperatorEventType.COORDINATION_REFLEX,
            OperatorEventType.COORDINATION_RESOLVED,
            OperatorEventType.LANE_PATH_OVERLAP,
            OperatorEventType.LANE_DIVERGENCE,
            OperatorEventType.NARRATIVE_EVENT,
            OperatorEventType.PRESENCE_CHANGE,
            OperatorEventType.BATON_STATE_CHANGE,
            OperatorEventType.CONVERSATION_PULSE,
            OperatorEventType.GAP_DETECTED,
        }
        assert named == OperatorEventType._KNOWN

    def test_immediate_types_are_subset_of_known(self):
        assert OperatorEventType._IMMEDIATE.issubset(OperatorEventType._KNOWN)

    def test_coalescible_types_are_subset_of_known(self):
        assert OperatorEventType._COALESCIBLE.issubset(OperatorEventType._KNOWN)

    def test_immediate_and_coalescible_are_disjoint(self):
        """An event cannot be both immediate and coalescible."""
        overlap = OperatorEventType._IMMEDIATE & OperatorEventType._COALESCIBLE
        assert overlap == set(), f"Overlap: {overlap}"

    def test_event_type_strings_are_namespaced(self):
        """All event types follow category:action format."""
        for t in OperatorEventType._KNOWN:
            assert ":" in t, f"Event type '{t}' missing namespace separator"


# ---------------------------------------------------------------------------
# Batch coalescing (synchronous unit)
# ---------------------------------------------------------------------------


class TestCoalesceBatch:
    def test_single_event_passes_through(self):
        events = [{"type": "health:signal_raised", "payload": {}, "ts": 1}]
        assert _coalesce_batch(events) == events

    def test_non_coalescible_events_all_kept(self):
        events = [
            {"type": "health:signal_raised", "payload": {"id": "a"}, "ts": 1},
            {"type": "health:signal_raised", "payload": {"id": "b"}, "ts": 2},
            {"type": "review:verdict", "payload": {}, "ts": 3},
        ]
        result = _coalesce_batch(events)
        assert len(result) == 3

    def test_coalescible_same_agent_keeps_latest(self):
        events = [
            {"type": "agent:wag", "payload": {"agent": "claude", "state": "building"}, "ts": 1},
            {"type": "agent:wag", "payload": {"agent": "claude", "state": "listening"}, "ts": 2},
            {"type": "agent:wag", "payload": {"agent": "claude", "state": "exploring"}, "ts": 3},
        ]
        result = _coalesce_batch(events)
        assert len(result) == 1
        assert result[0]["payload"]["state"] == "exploring"

    def test_coalescible_different_agents_kept_separately(self):
        events = [
            {"type": "agent:wag", "payload": {"agent": "claude"}, "ts": 1},
            {"type": "agent:wag", "payload": {"agent": "codex"}, "ts": 2},
        ]
        result = _coalesce_batch(events)
        assert len(result) == 2

    def test_mixed_coalescible_and_immediate(self):
        events = [
            {"type": "agent:heartbeat", "payload": {"agent": "claude"}, "ts": 1},
            {"type": "agent:heartbeat", "payload": {"agent": "claude"}, "ts": 2},
            {"type": "health:signal_raised", "payload": {"id": "x"}, "ts": 3},
        ]
        result = _coalesce_batch(events)
        # heartbeat coalesced to 1, health raised kept = 2 total
        assert len(result) == 2
        assert result[0]["type"] == "agent:heartbeat"
        assert result[1]["type"] == "health:signal_raised"

    def test_empty_batch(self):
        assert _coalesce_batch([]) == []


# ---------------------------------------------------------------------------
# Async coalescing reader
# ---------------------------------------------------------------------------


class TestCoalescingReader:
    @pytest.mark.asyncio
    async def test_single_event_immediate_passthrough(self):
        """Single event yields immediately without waiting for window."""
        q = asyncio.Queue()
        q.put_nowait({"type": "review:published", "payload": {}, "ts": 1})
        q.put_nowait(None)  # sentinel

        batches = []
        async for batch in coalescing_event_reader(q, window_ms=200):
            batches.append(batch)

        assert len(batches) == 1
        assert len(batches[0]) == 1

    @pytest.mark.asyncio
    async def test_immediate_event_yields_alone(self):
        """High-priority events bypass coalescing."""
        q = asyncio.Queue()
        q.put_nowait({"type": "health:signal_raised", "payload": {"id": "1"}, "ts": 1})
        q.put_nowait(None)

        batches = []
        async for batch in coalescing_event_reader(q, window_ms=200):
            batches.append(batch)

        assert len(batches) == 1
        assert len(batches[0]) == 1
        assert batches[0][0]["type"] == "health:signal_raised"

    @pytest.mark.asyncio
    async def test_burst_batched_within_window(self):
        """Multiple events arriving before window closes are batched."""
        q = asyncio.Queue()
        # Simulate rapid burst
        for i in range(5):
            q.put_nowait({"type": "agent:wag", "payload": {"agent": "claude", "n": i}, "ts": i})
        q.put_nowait(None)

        batches = []
        async for batch in coalescing_event_reader(q, window_ms=500):
            batches.append(batch)

        # Should be coalesced into 1 batch with 1 event (latest wag wins)
        assert len(batches) == 1
        assert len(batches[0]) == 1
        assert batches[0][0]["payload"]["n"] == 4  # latest

    @pytest.mark.asyncio
    async def test_immediate_event_flushes_pending_batch(self):
        """An immediate event arriving mid-batch forces a flush."""
        q = asyncio.Queue()
        q.put_nowait({"type": "agent:wag", "payload": {"agent": "a"}, "ts": 1})
        q.put_nowait({"type": "health:signal_raised", "payload": {"id": "x"}, "ts": 2})
        q.put_nowait(None)

        batches = []
        async for batch in coalescing_event_reader(q, window_ms=500):
            batches.append(batch)

        # First batch: wag + health raised (flushed by immediate)
        assert len(batches) == 1
        assert len(batches[0]) == 2

    @pytest.mark.asyncio
    async def test_sentinel_terminates(self):
        """None sentinel stops the reader."""
        q = asyncio.Queue()
        q.put_nowait(None)

        batches = []
        async for batch in coalescing_event_reader(q):
            batches.append(batch)

        assert len(batches) == 0


# ---------------------------------------------------------------------------
# Transport
# ---------------------------------------------------------------------------


class TestOperatorSSETransport:
    def test_push_adds_timestamp(self):
        transport = OperatorSSETransport()
        q = asyncio.Queue()
        transport.add_listener("console", q)

        transport.push("agent:wag", {"agent": "claude"})
        event = q.get_nowait()

        assert "ts" in event
        assert event["type"] == "agent:wag"
        assert event["payload"]["agent"] == "claude"

    def test_push_invalidates_board(self):
        transport = OperatorSSETransport()
        transport.board._dirty = False
        transport.push("agent:wag", {})
        assert transport.board._dirty is True

    def test_shutdown_sends_sentinel(self):
        transport = OperatorSSETransport()
        q = asyncio.Queue()
        transport.add_listener("console", q)

        transport.shutdown()
        assert q.get_nowait() is None
        assert len(transport.listeners) == 0

    def test_agent_filter_matches_multi_agent_lane_event(self):
        transport = OperatorSSETransport()
        alpha_q = asyncio.Queue()
        gamma_q = asyncio.Queue()
        transport.add_listener(
            "console-alpha",
            alpha_q,
            feed_filter=SignalFeedFilter(agents={"alpha"}),
        )
        transport.add_listener(
            "console-gamma",
            gamma_q,
            feed_filter=SignalFeedFilter(agents={"gamma"}),
        )

        transport.push(
            OperatorEventType.LANE_PATH_OVERLAP,
            {"agent_a": "alpha", "agent_b": "beta"},
            agents=["alpha", "beta"],
        )

        event = alpha_q.get_nowait()
        assert event["type"] == OperatorEventType.LANE_PATH_OVERLAP
        assert event["agents"] == ["alpha", "beta"]
        assert gamma_q.empty()


# ---------------------------------------------------------------------------
# Board snapshot
# ---------------------------------------------------------------------------


class TestOperatorBoardSnapshot:
    def test_empty_snapshot_shape(self):
        board = OperatorBoardSnapshot()
        board.set_builder(lambda: {"agents": {}, "system": empty_system_counters()})
        snap = board.get()

        assert "as_of" in snap
        assert "agents" in snap
        assert "system" in snap
        assert snap["system"]["agents_online"] == 0

    def test_snapshot_uses_builder(self):
        board = OperatorBoardSnapshot()
        board.set_builder(lambda: {
            "agents": {
                "claude-code": {
                    **empty_agent_counters(),
                    "online": True,
                    "readiness": "busy",
                    "pending_messages": 3,
                    "pending_actionable": 2,
                    "pending_assignments": 2,
                }
            },
            "system": {
                **empty_system_counters(),
                "agents_online": 1,
                "total_pending_messages": 3,
                "total_pending_actionable": 2,
                "total_pending_assignments": 2,
            }
        })

        snap = board.get()
        assert snap["agents"]["claude-code"]["online"] is True
        assert snap["agents"]["claude-code"]["pending_messages"] == 3
        assert snap["agents"]["claude-code"]["pending_actionable"] == 2
        assert snap["agents"]["claude-code"]["pending_assignments"] == 2
        assert snap["system"]["agents_online"] == 1
        assert snap["system"]["total_pending_messages"] == 3

    def test_snapshot_caches_until_invalidated(self):
        call_count = 0

        def builder():
            nonlocal call_count
            call_count += 1
            return {"agents": {}, "system": empty_system_counters()}

        board = OperatorBoardSnapshot()
        board.set_builder(builder)

        board.get()
        board.get()
        board.get()
        assert call_count == 1  # only built once

        board.invalidate()
        board.get()
        assert call_count == 2  # rebuilt after invalidation

    def test_agent_counter_shape_complete(self):
        """Canonical agent counter shape has all expected fields."""
        counters = empty_agent_counters()
        expected = {
            "online", "readiness", "attention_state", "current_task",
            "pending_messages", "pending_actionable",
            "active_assignments", "pending_assignments", "blocking_reviews",
            "incoming_batons", "carrying_batons", "claimed_reviews",
            "lane_warnings",
        }
        assert set(counters.keys()) == expected

    def test_system_counter_shape_complete(self):
        """Canonical system counter shape has all expected fields."""
        counters = empty_system_counters()
        expected = {
            "agents_online", "total_pending_messages", "total_pending_actionable",
            "total_active_assignments", "total_pending_assignments",
            "total_blocking_reviews", "total_batons_in_flight",
            "lane_warnings_active", "health_signals_active", "workspaces_active",
        }
        assert set(counters.keys()) == expected

    def test_builder_failure_serves_stale(self):
        """If builder raises, stale data is returned instead of crashing."""
        board = OperatorBoardSnapshot()
        board.set_builder(lambda: {"agents": {"a": {}}, "system": empty_system_counters()})
        board.get()  # populate

        # Now make builder fail
        board.set_builder(lambda: (_ for _ in ()).throw(RuntimeError("db error")))
        board.invalidate()

        snap = board.get()  # should return stale, not crash
        assert "a" in snap["agents"]
