"""Tests for the content-addressed blob store."""
from __future__ import annotations

import shutil
import tempfile
from pathlib import Path

from whispers.storage.blobs import BlobStore


def _temp_store():
    d = Path(tempfile.mkdtemp())
    return BlobStore(root=d), d


class TestBlobStore:

    def test_put_and_get_roundtrip(self):
        store, tmp = _temp_store()
        try:
            data = b"hello from the blob store"
            ref = store.put(data, media_type="text/plain", label="greeting")
            assert ref["ref"].startswith("sha256:")
            assert ref["media_type"] == "text/plain"
            assert ref["size_bytes"] == len(data)
            assert ref["label"] == "greeting"

            retrieved = store.get(ref["ref"])
            assert retrieved == data
        finally:
            shutil.rmtree(tmp, ignore_errors=True)

    def test_content_deduplication(self):
        store, tmp = _temp_store()
        try:
            data = b"identical content"
            ref1 = store.put(data)
            ref2 = store.put(data)
            assert ref1["ref"] == ref2["ref"]
        finally:
            shutil.rmtree(tmp, ignore_errors=True)

    def test_different_content_different_refs(self):
        store, tmp = _temp_store()
        try:
            ref1 = store.put(b"content A")
            ref2 = store.put(b"content B")
            assert ref1["ref"] != ref2["ref"]
        finally:
            shutil.rmtree(tmp, ignore_errors=True)

    def test_exists(self):
        store, tmp = _temp_store()
        try:
            ref = store.put(b"check existence")
            assert store.exists(ref["ref"])
            assert not store.exists("sha256:0000000000000000000000000000000000000000000000000000000000000000")
        finally:
            shutil.rmtree(tmp, ignore_errors=True)

    def test_size(self):
        store, tmp = _temp_store()
        try:
            data = b"measure this"
            ref = store.put(data)
            assert store.size(ref["ref"]) == len(data)
            assert store.size("sha256:nonexistent") is None
        finally:
            shutil.rmtree(tmp, ignore_errors=True)

    def test_delete(self):
        store, tmp = _temp_store()
        try:
            ref = store.put(b"temporary")
            assert store.exists(ref["ref"])
            assert store.delete(ref["ref"])
            assert not store.exists(ref["ref"])
            assert store.get(ref["ref"]) is None
        finally:
            shutil.rmtree(tmp, ignore_errors=True)

    def test_get_nonexistent_returns_none(self):
        store, tmp = _temp_store()
        try:
            assert store.get("sha256:0000000000000000000000000000000000000000000000000000000000000000") is None
        finally:
            shutil.rmtree(tmp, ignore_errors=True)

    def test_invalid_ref_format(self):
        store, tmp = _temp_store()
        try:
            assert store.get("not-a-ref") is None
            assert not store.exists("not-a-ref")
            assert store.size("not-a-ref") is None
            assert not store.delete("not-a-ref")
        finally:
            shutil.rmtree(tmp, ignore_errors=True)

    def test_large_blob(self):
        store, tmp = _temp_store()
        try:
            data = b"x" * 500_000  # 500KB
            ref = store.put(data, media_type="application/octet-stream", label="large artifact")
            assert ref["size_bytes"] == 500_000
            assert store.get(ref["ref"]) == data
        finally:
            shutil.rmtree(tmp, ignore_errors=True)

    def test_ref_in_attachment_format(self):
        """Verify the put() output matches 2ack attachments array format."""
        store, tmp = _temp_store()
        try:
            ref = store.put(b"code review content", media_type="text/plain", label="full code review")
            assert "ref" in ref
            assert "media_type" in ref
            assert "size_bytes" in ref
            assert "label" in ref
            assert isinstance(ref["ref"], str)
            assert isinstance(ref["size_bytes"], int)
        finally:
            shutil.rmtree(tmp, ignore_errors=True)
