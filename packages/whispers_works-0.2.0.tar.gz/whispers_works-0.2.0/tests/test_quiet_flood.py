"""Tests for quiet flood protection.

Covers:
- Under limit passes through unchanged
- Over limit caps at QUIET_FLOOD_LIMIT
- Flash messages always delivered
- Overflow summary includes sender/priority breakdown
- Not-quiet mode passes through unchanged
"""

import pytest
from whispers.quiet_flood_protection import (
    apply_quiet_flood_protection,
    format_overflow_summary,
    QUIET_FLOOD_LIMIT,
)


class TestQuietFloodProtection:
    def _make_messages(self, count, priority="routine", sender="alice"):
        return [
            {"uuid": f"msg-{i}", "from_agent": sender, "subject": f"Msg {i}",
             "body": f"Body {i}", "priority": priority}
            for i in range(count)
        ]

    def test_under_limit_passes_through(self):
        msgs = self._make_messages(3)
        delivered, overflow = apply_quiet_flood_protection(msgs, was_quiet=True)
        assert len(delivered) == 3
        assert overflow is None

    def test_over_limit_caps(self):
        msgs = self._make_messages(15)
        delivered, overflow = apply_quiet_flood_protection(msgs, was_quiet=True)
        assert len(delivered) == QUIET_FLOOD_LIMIT
        assert overflow is not None
        assert overflow["overflow_count"] == 10

    def test_flash_always_delivered(self):
        flash = self._make_messages(3, priority="flash")
        routine = self._make_messages(10, priority="routine")
        msgs = flash + routine
        delivered, overflow = apply_quiet_flood_protection(msgs, was_quiet=True)
        # All 3 flash + 2 routine (budget = 5 - 3 = 2)
        flash_delivered = [m for m in delivered if m["priority"] == "flash"]
        assert len(flash_delivered) == 3
        assert len(delivered) == 5

    def test_overflow_summary_has_sender_breakdown(self):
        msgs = (
            self._make_messages(5, sender="alice")
            + self._make_messages(5, sender="bob")
            + self._make_messages(5, sender="charlie")
        )
        _, overflow = apply_quiet_flood_protection(msgs, was_quiet=True)
        assert overflow is not None
        assert "alice" in overflow["by_sender"] or "bob" in overflow["by_sender"]

    def test_not_quiet_passes_through(self):
        msgs = self._make_messages(20)
        delivered, overflow = apply_quiet_flood_protection(msgs, was_quiet=False)
        assert len(delivered) == 20
        assert overflow is None

    def test_format_overflow_summary(self):
        summary = {
            "overflow_count": 10,
            "by_sender": {"alice": 5, "bob": 3, "charlie": 2},
            "by_priority": {"routine": 8, "priority": 2},
        }
        text = format_overflow_summary(summary)
        assert "10 messages summarized" in text
        assert "alice" in text
        assert "routine" in text
