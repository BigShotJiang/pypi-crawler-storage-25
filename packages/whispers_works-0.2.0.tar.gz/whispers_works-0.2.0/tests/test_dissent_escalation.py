import time
import pytest
from whispers.envelope import Envelope, Priority
from whispers.storage.db import WhispersDB
from whispers.dispatcher import Dispatcher
from whispers.collaboration_health import CollaborationHealthScanner, Severity

def test_blocking_dissent_escalation(temp_db):
    db = WhispersDB(temp_db)
    dispatcher = Dispatcher(db)
    scanner = CollaborationHealthScanner(db)

    # 1. Agent files a regular dissent (non-blocking)
    env1 = Envelope(
        sender="worker1",
        recipient="worker2",
        msg_type="inform",
        subject="disagree",
        payload={
            "schema": "dissent_record.v1",
            "decision_ref": "msg-123",
            "chosen_path": "Option A",
            "alternate_path": "Option B",
            "blocking": False
        }
    )
    db.store_message(env1, allowed_recipients=["worker2"])
    # Note: store_message sets created_at to now. Project uses that.
    dispatcher._project_review_dissent_events(env1)

    # Captain should not have a synthetic alert, and no health signals
    with db.get_connection() as conn:
        captain_msgs = conn.execute("SELECT * FROM message_recipients WHERE recipient_callsign = 'captain'").fetchall()
        assert len(captain_msgs) == 0
    signals = scanner.scan()
    assert len(signals) == 0

    # 2. Agent files a blocking dissent
    env2 = Envelope(
        sender="worker1",
        recipient="worker2",
        msg_type="inform",
        subject="strong disagree",
        payload={
            "schema": "dissent_record.v1",
            "decision_ref": "msg-124",
            "chosen_path": "Option X",
            "alternate_path": "Option Y",
            "blocking": True
        }
    )
    db.store_message(env2, allowed_recipients=["worker2"])
    dispatcher._project_review_dissent_events(env2)

    # Captain SHOULD have a synthetic alert, and there SHOULD be a health signal
    with db.get_connection() as conn:
        captain_msgs = conn.execute("SELECT * FROM message_recipients mr JOIN messages m ON mr.message_uuid = m.uuid WHERE mr.recipient_callsign = 'captain'").fetchall()
        assert len(captain_msgs) == 1
        
    signals = scanner.scan()
    assert len(signals) == 1
    assert signals[0].severity == Severity.ESCALATE
    assert signals[0].details["decision_ref"] == "msg-124"
    assert signals[0].details["dissent_ref"] == env2.id

    # 3. Blocking dissent is resolved
    env3 = Envelope(
        sender="worker2",
        recipient="worker1",
        msg_type="inform",
        subject="resolved",
        payload={
            "schema": "dissent_resolution.v1",
            "dissent_ref": env2.id,
            "resolution": "resolved"
        }
    )
    db.store_message(env3, allowed_recipients=["worker1"])
    dispatcher._project_review_dissent_events(env3)

    # Captain action alert should be cleared
    with db.get_connection() as conn:
        captain_msgs = conn.execute("SELECT * FROM message_recipients mr JOIN messages m ON mr.message_uuid = m.uuid WHERE mr.recipient_callsign = 'captain' AND m.status != 'done'").fetchall()
        assert len(captain_msgs) == 0
        
    # Health signal should be gone
    signals = scanner.scan()
    assert len(signals) == 0
