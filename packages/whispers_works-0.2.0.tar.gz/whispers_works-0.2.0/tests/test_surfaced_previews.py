"""Tests for surface-now message previews and interruptibility-coherent filtering.

These features kill the check-check-check polling loop by surfacing message
content inline in the startup briefing and filtering message_check results
based on interruptibility state.
"""
from datetime import datetime, timezone, timedelta

from whispers.connection_story import (
    _render_surfaced_message_lines,
    _render_reentry_lines,
    collapse_related_signals,
    _normalize_subject_stem,
    _top_preview_headline,
    _priority_filter_for_interruptibility,
)
from whispers.mcp_server import _classify_queue_class_for_filter


def _make_preview(sender="codex", subject="Test", priority="routine",
                  msg_type="inform", age_minutes=5):
    created = datetime.now(timezone.utc) - timedelta(minutes=age_minutes)
    return {
        "from_agent": sender,
        "subject": subject,
        "priority": priority,
        "msg_type": msg_type,
        "created_at": created.isoformat(),
    }


def _make_treatment(surface_now=0, defer_visible=0, hold_quietly=0,
                    interruptibility="free"):
    return {
        "counts": {
            "surface_now": surface_now,
            "defer_visible": defer_visible,
            "hold_quietly": hold_quietly,
            "archive_only": 0,
        },
        "interruptibility": interruptibility,
        "has_any": surface_now + defer_visible + hold_quietly > 0,
    }


# ---------------------------------------------------------------------------
# Surface-now preview rendering
# ---------------------------------------------------------------------------

class TestSurfacedPreviews:
    def test_no_previews_when_empty(self):
        lines = _render_surfaced_message_lines([], _make_treatment(surface_now=3))
        assert lines == []

    def test_no_previews_when_surface_now_zero(self):
        previews = [_make_preview()]
        lines = _render_surfaced_message_lines(previews, _make_treatment(surface_now=0))
        assert lines == []

    def test_renders_single_preview(self):
        previews = [_make_preview(sender="codex", subject="Scope packet", priority="priority")]
        lines = _render_surfaced_message_lines(previews, _make_treatment(surface_now=1))
        assert len(lines) == 1
        assert "codex" in lines[0]
        assert "Scope packet" in lines[0]
        assert "priority" in lines[0]

    def test_renders_multiple_previews(self):
        previews = [
            _make_preview(sender="codex", subject="First"),
            _make_preview(sender="antigravity", subject="Second"),
        ]
        lines = _render_surfaced_message_lines(previews, _make_treatment(surface_now=2))
        assert len(lines) == 2
        assert "codex" in lines[0]
        assert "antigravity" in lines[1]

    def test_max_lines_cap(self):
        previews = [_make_preview(subject=f"Msg {i}") for i in range(8)]
        lines = _render_surfaced_message_lines(previews, _make_treatment(surface_now=8), max_lines=3)
        assert len(lines) == 4  # 3 previews + overflow
        assert "+5 more" in lines[3]

    def test_routine_priority_not_tagged(self):
        """Routine priority is omitted from tags since it's the default."""
        previews = [_make_preview(priority="routine", msg_type="inform")]
        lines = _render_surfaced_message_lines(previews, _make_treatment(surface_now=1))
        assert len(lines) == 1
        assert "routine" not in lines[0]

    def test_non_routine_priority_tagged(self):
        previews = [_make_preview(priority="flash")]
        lines = _render_surfaced_message_lines(previews, _make_treatment(surface_now=1))
        assert "flash" in lines[0]

    def test_non_inform_msg_type_tagged(self):
        previews = [_make_preview(msg_type="handoff")]
        lines = _render_surfaced_message_lines(previews, _make_treatment(surface_now=1))
        assert "handoff" in lines[0]

    def test_age_label_minutes(self):
        previews = [_make_preview(age_minutes=15)]
        lines = _render_surfaced_message_lines(previews, _make_treatment(surface_now=1))
        assert "15m ago" in lines[0]

    def test_age_label_hours(self):
        previews = [_make_preview(age_minutes=90)]
        lines = _render_surfaced_message_lines(previews, _make_treatment(surface_now=1))
        assert "1h ago" in lines[0]

    def test_age_label_just_now(self):
        previews = [_make_preview(age_minutes=0)]
        lines = _render_surfaced_message_lines(previews, _make_treatment(surface_now=1))
        assert "just now" in lines[0]

    def test_uses_canonical_visual_signal(self):
        """Previews must use the ⏦⏦⏦> ⟡ format."""
        previews = [_make_preview()]
        lines = _render_surfaced_message_lines(previews, _make_treatment(surface_now=1))
        assert lines[0].startswith("\u23e6\u23e6\u23e6>")  # ⏦⏦⏦>
        assert "\u27e1" in lines[0]  # ⟡

    def test_none_treatment_treated_as_no_surface(self):
        previews = [_make_preview()]
        lines = _render_surfaced_message_lines(previews, None)
        assert lines == []

    def test_missing_counts_treated_as_zero(self):
        previews = [_make_preview()]
        lines = _render_surfaced_message_lines(previews, {"has_any": True})
        assert lines == []


# ---------------------------------------------------------------------------
# Interruptibility filtering in previews
# ---------------------------------------------------------------------------

class TestInterruptibilityPreviewFiltering:
    def test_free_shows_all_priorities(self):
        previews = [
            _make_preview(priority="flash", subject="Flash alert"),
            _make_preview(priority="priority", subject="Priority scope"),
            _make_preview(priority="routine", subject="Routine update"),
        ]
        lines = _render_surfaced_message_lines(
            previews, _make_treatment(surface_now=3, interruptibility="free")
        )
        assert len(lines) == 3

    def test_do_not_interrupt_shows_only_flash_system(self):
        previews = [
            _make_preview(priority="flash", subject="Flash"),
            _make_preview(priority="system", subject="System"),
            _make_preview(priority="priority", subject="Priority"),
            _make_preview(priority="routine", subject="Routine"),
        ]
        lines = _render_surfaced_message_lines(
            previews, _make_treatment(surface_now=4, interruptibility="do_not_interrupt")
        )
        assert len(lines) == 2
        assert "Flash" in lines[0]
        assert "System" in lines[1]

    def test_defer_shows_flash_system_priority(self):
        previews = [
            _make_preview(priority="flash", subject="Flash alert"),
            _make_preview(priority="priority", subject="Priority scope"),
            _make_preview(priority="routine", subject="Routine update"),
        ]
        lines = _render_surfaced_message_lines(
            previews, _make_treatment(surface_now=3, interruptibility="defer")
        )
        assert len(lines) == 2

    def test_urgent_only_same_as_defer(self):
        previews = [
            _make_preview(priority="flash"),
            _make_preview(priority="routine"),
        ]
        lines = _render_surfaced_message_lines(
            previews, _make_treatment(surface_now=2, interruptibility="urgent_only")
        )
        assert len(lines) == 1
        assert "flash" in lines[0]

    def test_do_not_interrupt_with_no_flash_returns_empty(self):
        previews = [
            _make_preview(priority="priority"),
            _make_preview(priority="routine"),
        ]
        lines = _render_surfaced_message_lines(
            previews, _make_treatment(surface_now=2, interruptibility="do_not_interrupt")
        )
        assert lines == []


# ---------------------------------------------------------------------------
# Queue class classification helper
# ---------------------------------------------------------------------------

class TestQueueClassForFilter:
    def test_handoff_is_actionable(self):
        m = {"msg_type": "handoff", "priority": "routine", "from_agent": "codex"}
        assert _classify_queue_class_for_filter(m) == "actionable"

    def test_assignment_is_actionable(self):
        m = {"msg_type": "assignment", "priority": "routine", "from_agent": "codex"}
        assert _classify_queue_class_for_filter(m) == "actionable"

    def test_flash_is_actionable(self):
        m = {"msg_type": "inform", "priority": "flash", "from_agent": "codex"}
        assert _classify_queue_class_for_filter(m) == "actionable"

    def test_inform_routine_is_conversation(self):
        m = {"msg_type": "inform", "priority": "routine", "from_agent": "codex"}
        assert _classify_queue_class_for_filter(m) == "conversation"

    def test_system_sender_is_system(self):
        m = {"msg_type": "inform", "priority": "routine", "from_agent": "whispers-server"}
        assert _classify_queue_class_for_filter(m) == "system"

    def test_system_priority_is_system(self):
        m = {"msg_type": "inform", "priority": "system", "from_agent": "codex"}
        assert _classify_queue_class_for_filter(m) == "system"

    def test_schema_from_dict_payload(self):
        m = {
            "msg_type": "inform", "priority": "routine", "from_agent": "codex",
            "payload": {"schema": "handoff_baton.v1"},
        }
        assert _classify_queue_class_for_filter(m) == "actionable"

    def test_schema_from_json_string_payload(self):
        import json
        m = {
            "msg_type": "inform", "priority": "routine", "from_agent": "codex",
            "payload": json.dumps({"schema": "handoff_baton.v1"}),
        }
        assert _classify_queue_class_for_filter(m) == "actionable"

    def test_missing_fields_defaults_to_conversation(self):
        m = {}
        result = _classify_queue_class_for_filter(m)
        assert result == "conversation"

    def test_none_payload_handled(self):
        m = {"msg_type": "inform", "priority": "routine", "from_agent": "codex", "payload": None}
        assert _classify_queue_class_for_filter(m) == "conversation"


# ---------------------------------------------------------------------------
# Edge cases
# ---------------------------------------------------------------------------

class TestSurfacedPreviewEdgeCases:
    def test_missing_subject(self):
        previews = [{"from_agent": "codex", "priority": "routine", "created_at": "2026-04-01T12:00:00+00:00"}]
        lines = _render_surfaced_message_lines(previews, _make_treatment(surface_now=1))
        assert "(no subject)" in lines[0]

    def test_missing_sender(self):
        previews = [{"subject": "Test", "priority": "routine", "created_at": "2026-04-01T12:00:00+00:00"}]
        lines = _render_surfaced_message_lines(previews, _make_treatment(surface_now=1))
        assert "unknown" in lines[0]

    def test_missing_created_at(self):
        previews = [{"from_agent": "codex", "subject": "Test", "priority": "routine"}]
        lines = _render_surfaced_message_lines(previews, _make_treatment(surface_now=1))
        assert len(lines) == 1
        assert "codex" in lines[0]

    def test_invalid_created_at(self):
        previews = [{"from_agent": "codex", "subject": "Test", "priority": "routine", "created_at": "not-a-date"}]
        lines = _render_surfaced_message_lines(previews, _make_treatment(surface_now=1))
        assert len(lines) == 1  # Should not crash

    def test_empty_string_fields(self):
        previews = [{"from_agent": "", "subject": "", "priority": "", "msg_type": "", "created_at": ""}]
        lines = _render_surfaced_message_lines(previews, _make_treatment(surface_now=1))
        assert len(lines) == 1
        assert "unknown" in lines[0]  # empty from_agent defaults to unknown


# ---------------------------------------------------------------------------
# Re-entry inline message previews
# ---------------------------------------------------------------------------

class TestReentryPreviews:
    def test_reentry_includes_message_previews(self):
        packet = {
            "style": "bounded",
            "changed": ["3 new messages"],
            "hot_now": [],
            "blocking": [],
            "can_wait": [],
            "message_previews": [
                _make_preview(sender="codex", subject="Scope update", priority="priority"),
            ],
        }
        lines = _render_reentry_lines(packet)
        assert any("codex" in line and "Scope update" in line for line in lines)

    def test_reentry_previews_capped_at_3(self):
        packet = {
            "style": "bounded",
            "changed": ["5 new messages"],
            "hot_now": [],
            "blocking": [],
            "can_wait": [],
            "message_previews": [_make_preview(subject=f"Msg {i}") for i in range(5)],
        }
        lines = _render_reentry_lines(packet)
        # 1 summary line + 3 preview lines + 1 overflow line
        preview_lines = [l for l in lines if "\u27e1" in l]  # ⟡ icon
        assert len(preview_lines) == 4  # 3 previews + overflow

    def test_reentry_no_previews_when_absent(self):
        packet = {
            "style": "bounded",
            "changed": ["joined codex"],
            "hot_now": [],
            "blocking": [],
            "can_wait": [],
        }
        lines = _render_reentry_lines(packet)
        preview_lines = [l for l in lines if "\u27e1" in l]
        assert len(preview_lines) == 0

    def test_reentry_empty_previews_list(self):
        packet = {
            "style": "bounded",
            "changed": ["1 new message"],
            "hot_now": [],
            "blocking": [],
            "can_wait": [],
            "message_previews": [],
        }
        lines = _render_reentry_lines(packet)
        preview_lines = [l for l in lines if "\u27e1" in l]
        assert len(preview_lines) == 0

    def test_reentry_preserves_summary_line(self):
        packet = {
            "style": "bounded",
            "changed": ["2 new messages"],
            "hot_now": ["hot reply from codex"],
            "blocking": [],
            "can_wait": [],
            "message_previews": [_make_preview()],
        }
        lines = _render_reentry_lines(packet)
        assert lines[0].startswith("Re-entry:")
        assert "hot reply from codex" in lines[0]

    def test_reentry_resume_hint_after_previews(self):
        packet = {
            "style": "bounded",
            "changed": ["1 new message"],
            "hot_now": [],
            "blocking": [],
            "can_wait": [],
            "message_previews": [_make_preview()],
            "resume_hint": "Continue from the scope packet",
        }
        lines = _render_reentry_lines(packet)
        assert lines[-1] == "Re-entry hint: Continue from the scope packet"

    def test_empty_packet_returns_empty(self):
        assert _render_reentry_lines({}) == []
        assert _render_reentry_lines(None) == []


# ---------------------------------------------------------------------------
# Alarm collapse
# ---------------------------------------------------------------------------

class TestAlarmCollapse:
    def test_single_message_not_collapsed(self):
        previews = [_make_preview()]
        result = collapse_related_signals(previews)
        assert len(result) == 1
        assert "_collapsed_count" not in result[0]

    def test_empty_list(self):
        assert collapse_related_signals([]) == []

    def test_identical_subject_stems_collapsed(self):
        """Three reminders about the same handoff → one collapsed signal."""
        previews = [
            _make_preview(sender="whispers-server", subject="Reminder: handoff from codex waiting (30m)"),
            _make_preview(sender="whispers-server", subject="Reminder: handoff from codex waiting (1h4m)"),
            _make_preview(sender="whispers-server", subject="Reminder: handoff from codex waiting (1h34m)"),
        ]
        result = collapse_related_signals(previews)
        assert len(result) == 1
        assert result[0]["_collapsed_count"] == 3
        assert "Reminder: handoff from codex waiting" in result[0]["subject"]

    def test_different_senders_not_collapsed(self):
        previews = [
            _make_preview(sender="codex", subject="Scope update"),
            _make_preview(sender="antigravity", subject="Scope update"),
        ]
        result = collapse_related_signals(previews)
        assert len(result) == 2

    def test_different_subjects_not_collapsed(self):
        previews = [
            _make_preview(sender="codex", subject="Plan A"),
            _make_preview(sender="codex", subject="Plan B"),
        ]
        result = collapse_related_signals(previews)
        assert len(result) == 2

    def test_highest_priority_promoted(self):
        previews = [
            _make_preview(sender="whispers-server", subject="Alert (1h)", priority="routine"),
            _make_preview(sender="whispers-server", subject="Alert (2h)", priority="priority"),
            _make_preview(sender="whispers-server", subject="Alert (3h)", priority="flash"),
        ]
        result = collapse_related_signals(previews)
        assert len(result) == 1
        assert result[0]["priority"] == "flash"
        assert result[0]["_collapsed_count"] == 3

    def test_newest_timestamp_kept(self):
        previews = [
            _make_preview(sender="srv", subject="Ping (old)", age_minutes=60),
            _make_preview(sender="srv", subject="Ping (new)", age_minutes=5),
        ]
        result = collapse_related_signals(previews)
        assert len(result) == 1
        # The newest (5m ago) should be kept
        newest_created = _make_preview(age_minutes=5)["created_at"]
        assert result[0]["created_at"] >= newest_created[:16]  # Compare up to minute

    def test_mixed_collapsed_and_individual(self):
        """Collapse reminders but keep unique messages intact."""
        previews = [
            _make_preview(sender="whispers-server", subject="Reminder (30m)"),
            _make_preview(sender="whispers-server", subject="Reminder (1h)"),
            _make_preview(sender="codex", subject="Full plan + lane split", priority="priority"),
        ]
        result = collapse_related_signals(previews)
        assert len(result) == 2
        assert result[0]["_collapsed_count"] == 2
        assert "_collapsed_count" not in result[1]

    def test_collapsed_count_rendered(self):
        """Collapsed signals show Nx in the rendered output."""
        previews = [
            _make_preview(sender="whispers-server", subject="Reminder (30m)", msg_type="heads_up"),
            _make_preview(sender="whispers-server", subject="Reminder (1h)", msg_type="heads_up"),
            _make_preview(sender="whispers-server", subject="Reminder (2h)", msg_type="heads_up"),
        ]
        lines = _render_surfaced_message_lines(
            previews, _make_treatment(surface_now=3)
        )
        assert len(lines) == 1
        assert "3x" in lines[0]

    def test_no_collapse_with_different_trailing_content(self):
        """Subjects that differ in more than just a trailing parenthetical."""
        previews = [
            _make_preview(sender="codex", subject="Build plan A"),
            _make_preview(sender="codex", subject="Build plan B"),
        ]
        result = collapse_related_signals(previews)
        assert len(result) == 2


class TestSubjectStemNormalization:
    def test_strips_trailing_parenthesized_age(self):
        assert _normalize_subject_stem("Reminder: handoff waiting (30m)") == "reminder: handoff waiting"

    def test_strips_trailing_parenthesized_timestamp(self):
        assert _normalize_subject_stem("Alert (2026-04-01T12:00:00Z)") == "alert"

    def test_preserves_mid_subject_parens(self):
        assert _normalize_subject_stem("Build (phase 2) complete") == "build (phase 2) complete"

    def test_case_insensitive(self):
        assert _normalize_subject_stem("REMINDER: Handoff") == "reminder: handoff"

    def test_empty_string(self):
        assert _normalize_subject_stem("") == ""

    def test_no_trailing_parens(self):
        assert _normalize_subject_stem("Full plan + lane split") == "full plan + lane split"


# ---------------------------------------------------------------------------
# Jolt headline enrichment
# ---------------------------------------------------------------------------

class TestJoltHeadlineEnrichment:
    def test_top_preview_headline_returns_sender_subject(self):
        previews = [_make_preview(sender="codex", subject="Heavy-lift scope")]
        assert _top_preview_headline(previews) == "codex: Heavy-lift scope"

    def test_top_preview_headline_with_priority_filter(self):
        previews = [
            _make_preview(sender="codex", subject="Routine update", priority="routine"),
            _make_preview(sender="codex", subject="Flash alert", priority="flash"),
        ]
        result = _top_preview_headline(previews, {"flash", "system"})
        assert result == "codex: Flash alert"

    def test_top_preview_headline_no_match(self):
        previews = [_make_preview(priority="routine")]
        assert _top_preview_headline(previews, {"flash"}) is None

    def test_top_preview_headline_empty(self):
        assert _top_preview_headline([]) is None
        assert _top_preview_headline(None) is None

    def test_top_preview_headline_skips_empty_fields(self):
        previews = [{"from_agent": "", "subject": "", "priority": "routine"}]
        assert _top_preview_headline(previews) is None

    def test_top_preview_headline_takes_first_match(self):
        previews = [
            _make_preview(sender="first", subject="A"),
            _make_preview(sender="second", subject="B"),
        ]
        assert _top_preview_headline(previews) == "first: A"


# ---------------------------------------------------------------------------
# Courtesy suppression coherence
# ---------------------------------------------------------------------------

class TestCourtesyCoherence:
    """All surfaces must agree on what to suppress at each interruptibility level."""

    def test_priority_filter_free_allows_all(self):
        assert _priority_filter_for_interruptibility("free") is None
        assert _priority_filter_for_interruptibility(None) is None
        assert _priority_filter_for_interruptibility("") is None

    def test_priority_filter_defer_allows_priority_plus(self):
        pf = _priority_filter_for_interruptibility("defer")
        assert pf == {"flash", "system", "priority"}

    def test_priority_filter_urgent_only_allows_priority_plus(self):
        pf = _priority_filter_for_interruptibility("urgent_only")
        assert pf == {"flash", "system", "priority"}

    def test_priority_filter_do_not_interrupt_allows_flash_system(self):
        pf = _priority_filter_for_interruptibility("do_not_interrupt")
        assert pf == {"flash", "system"}

    def test_reentry_respects_interruptibility(self):
        """Re-entry with do_not_interrupt should NOT show routine previews."""
        packet = {
            "style": "bounded",
            "changed": ["2 new messages"],
            "hot_now": [],
            "blocking": [],
            "can_wait": [],
            "message_previews": [
                _make_preview(priority="flash", subject="Flash alert"),
                _make_preview(priority="routine", subject="Routine noise"),
            ],
            "interruptibility": "do_not_interrupt",
        }
        lines = _render_reentry_lines(packet)
        preview_lines = [l for l in lines if "\u27e1" in l]  # ⟡ icon
        assert len(preview_lines) == 1
        assert "Flash alert" in preview_lines[0]
        assert "Routine noise" not in "\n".join(preview_lines)

    def test_reentry_without_interruptibility_shows_all(self):
        """Re-entry without interruptibility key should show all previews."""
        packet = {
            "style": "bounded",
            "changed": ["1 new message"],
            "hot_now": [],
            "blocking": [],
            "can_wait": [],
            "message_previews": [
                _make_preview(priority="routine", subject="Routine update"),
            ],
        }
        lines = _render_reentry_lines(packet)
        preview_lines = [l for l in lines if "\u27e1" in l]
        assert len(preview_lines) == 1

    def test_briefing_and_reentry_agree_on_do_not_interrupt(self):
        """Both surfaces should suppress routine at do_not_interrupt."""
        previews = [
            _make_preview(priority="flash", subject="Flash"),
            _make_preview(priority="routine", subject="Routine"),
        ]
        treatment = _make_treatment(surface_now=2, interruptibility="do_not_interrupt")

        briefing_lines = _render_surfaced_message_lines(previews, treatment)
        reentry_packet = {
            "style": "bounded",
            "changed": ["2 new messages"],
            "hot_now": [],
            "blocking": [],
            "can_wait": [],
            "message_previews": previews,
            "interruptibility": "do_not_interrupt",
        }
        reentry_lines = _render_reentry_lines(reentry_packet)

        briefing_preview_lines = [l for l in briefing_lines if "\u27e1" in l]
        reentry_preview_lines = [l for l in reentry_lines if "\u27e1" in l]

        # Both should show exactly 1 preview (flash only)
        assert len(briefing_preview_lines) == 1
        assert len(reentry_preview_lines) == 1
        assert "Flash" in briefing_preview_lines[0]
        assert "Flash" in reentry_preview_lines[0]

    def test_jolt_headline_respects_interruptibility(self):
        """_top_preview_headline with interruptibility filter should skip routine."""
        previews = [
            _make_preview(priority="routine", subject="Routine noise"),
            _make_preview(priority="priority", subject="Priority scope"),
        ]
        pf = _priority_filter_for_interruptibility("do_not_interrupt")
        result = _top_preview_headline(previews, pf)
        assert result is None  # neither routine nor priority pass flash+system filter

        pf_defer = _priority_filter_for_interruptibility("defer")
        result_defer = _top_preview_headline(previews, pf_defer)
        assert result_defer == "codex: Priority scope"
