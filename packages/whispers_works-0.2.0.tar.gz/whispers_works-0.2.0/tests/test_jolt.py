from whispers.jolt import (
    HostWakeCapabilities,
    JoltHostAdapter,
    JoltBudget,
    JoltContext,
    baseline_capabilities_for_wake_model,
    conservative_jolt_budget,
    decide_jolt_action,
    host_wake_capabilities_from_dict,
    infer_jolt_adapter_kind,
    jolt_adapter_from_dict,
    jolt_budget_from_dict,
)


def test_ambient_update_suppressed_by_default():
    decision = decide_jolt_action(
        JoltContext(trigger="ambient_update", wake_model="manual_wake"),
        HostWakeCapabilities(host_kind="cursor", can_notify=True, can_stage_context=True),
        JoltBudget(),
    )
    assert decision.action == "suppress"


def test_manual_wake_prefers_stage_context_when_supported():
    decision = decide_jolt_action(
        JoltContext(
            trigger="direct_assignment",
            wake_model="manual_wake",
            explicitly_addressed=True,
        ),
        HostWakeCapabilities(host_kind="cursor", can_notify=True, can_stage_context=True),
        JoltBudget(),
    )
    assert decision.action == "stage_context"


def test_manual_wake_falls_back_to_notify_without_staging():
    decision = decide_jolt_action(
        JoltContext(
            trigger="hot_thread",
            wake_model="manual_wake",
            explicitly_addressed=True,
        ),
        HostWakeCapabilities(host_kind="plain_terminal", can_notify=True, can_stage_context=False),
        JoltBudget(),
    )
    assert decision.action == "notify"
    assert decision.fallback_used is True


def test_listener_backed_can_infer_when_budget_allows():
    decision = decide_jolt_action(
        JoltContext(
            trigger="blocking_dependency",
            wake_model="listener_backed",
            blocking=True,
            priority="priority",
        ),
        HostWakeCapabilities(
            host_kind="listener",
            can_notify=True,
            can_stage_context=True,
            can_trigger_inference=True,
        ),
        JoltBudget(
            max_inferences_per_hour=4,
            inferences_used_last_hour=1,
            cooldown_seconds=60,
            seconds_since_last_inference=120,
            autonomous_inference_enabled=True,
        ),
    )
    assert decision.action == "infer"


def test_budget_exhaustion_degrades_to_stage_context():
    decision = decide_jolt_action(
        JoltContext(
            trigger="blocking_dependency",
            wake_model="listener_backed",
            blocking=True,
        ),
        HostWakeCapabilities(
            host_kind="listener",
            can_notify=True,
            can_stage_context=True,
            can_trigger_inference=True,
        ),
        JoltBudget(
            max_inferences_per_hour=1,
            inferences_used_last_hour=1,
            autonomous_inference_enabled=True,
        ),
    )
    assert decision.action == "stage_context"
    assert decision.budget_limited is True


def test_cooldown_degrades_to_notify_when_no_staging_path():
    decision = decide_jolt_action(
        JoltContext(
            trigger="flash_message",
            wake_model="listener_backed",
            blocking=True,
            priority="flash",
        ),
        HostWakeCapabilities(
            host_kind="pty",
            can_notify=True,
            can_stage_context=False,
            can_trigger_inference=True,
        ),
        JoltBudget(
            max_inferences_per_hour=4,
            inferences_used_last_hour=0,
            cooldown_seconds=300,
            seconds_since_last_inference=30,
            autonomous_inference_enabled=True,
        ),
    )
    assert decision.action == "notify"
    assert decision.budget_limited is True


def test_large_payloads_stage_instead_of_infer():
    decision = decide_jolt_action(
        JoltContext(
            trigger="direct_assignment",
            wake_model="listener_backed",
            explicitly_addressed=True,
            message_size_tier="artifact",
            estimated_tokens=250000,
        ),
        HostWakeCapabilities(
            host_kind="cursor",
            can_notify=True,
            can_stage_context=True,
            can_trigger_inference=True,
        ),
        JoltBudget(
            max_inferences_per_hour=4,
            inferences_used_last_hour=0,
            autonomous_inference_enabled=True,
        ),
    )
    assert decision.action == "stage_context"


def test_do_not_interrupt_blocks_non_operator_jolt():
    decision = decide_jolt_action(
        JoltContext(
            trigger="blocking_dependency",
            wake_model="manual_wake",
            blocking=True,
            interruptibility="do_not_interrupt",
        ),
        HostWakeCapabilities(host_kind="cursor", can_notify=True, can_stage_context=True),
        JoltBudget(),
    )
    assert decision.action == "suppress"


def test_operator_directed_can_still_notify_in_do_not_interrupt():
    decision = decide_jolt_action(
        JoltContext(
            trigger="operator_directed",
            wake_model="manual_wake",
            operator_requested=True,
            interruptibility="do_not_interrupt",
        ),
        HostWakeCapabilities(host_kind="cursor", can_notify=True, can_stage_context=True),
        JoltBudget(),
    )
    assert decision.action == "stage_context"


def test_baseline_capabilities_default_manual_wake_is_notify_only():
    capabilities = baseline_capabilities_for_wake_model("manual_wake")

    assert capabilities.can_notify is True
    assert capabilities.can_stage_context is False
    assert capabilities.can_trigger_inference is False


def test_baseline_capabilities_listener_backed_supports_staging():
    capabilities = baseline_capabilities_for_wake_model("listener_backed")

    assert capabilities.can_notify is True
    assert capabilities.can_stage_context is True
    assert capabilities.can_trigger_inference is True


def test_conservative_jolt_budget_disables_autonomous_inference():
    budget = conservative_jolt_budget()

    assert budget.autonomous_inference_enabled is False
    assert budget.max_inferences_per_hour == 0


def test_host_wake_capabilities_from_dict_overrides_manual_wake_defaults():
    capabilities = host_wake_capabilities_from_dict(
        "manual_wake",
        {
            "host_kind": "cursor",
            "can_stage_context": True,
        },
    )

    assert capabilities.host_kind == "cursor"
    assert capabilities.can_stage_context is True
    assert capabilities.can_trigger_inference is False


def test_host_wake_capabilities_from_dict_prefers_explicit_adapter_actions():
    capabilities = host_wake_capabilities_from_dict(
        "listener_backed",
        {
            "host_kind": "claude_code",
            "can_trigger_inference": True,
            "adapter": {
                "kind": "managed_pty",
                "supported_actions": ["notify", "stage_context"],
            },
        },
    )

    assert capabilities.host_kind == "claude_code"
    assert capabilities.can_notify is True
    assert capabilities.can_stage_context is True
    assert capabilities.can_trigger_inference is False


def test_jolt_budget_from_dict_reads_explicit_policy():
    budget = jolt_budget_from_dict(
        {
            "autonomous_inference_enabled": True,
            "max_inferences_per_hour": 4,
            "inferences_used_last_hour": 1,
            "cooldown_seconds": 60,
            "seconds_since_last_inference": 120,
        }
    )

    assert budget.autonomous_inference_enabled is True
    assert budget.max_inferences_per_hour == 4
    assert budget.cooldown_seconds == 60


def test_jolt_adapter_from_dict_derives_contract_for_cursor_host():
    adapter = jolt_adapter_from_dict(
        "manual_wake",
        {
            "host_kind": "cursor",
            "adapter": {"kind": "native_extension"},
            "can_stage_context": True,
        },
    )

    assert adapter == JoltHostAdapter(
        host_kind="cursor",
        adapter_kind="native_extension",
        supported_actions=("notify", "stage_context"),
        fallback_action="stage_context",
        state="supported",
    )


def test_infer_jolt_adapter_kind_recognizes_extension_desktop_and_terminal_hosts():
    assert infer_jolt_adapter_kind("antigravity", "manual_wake") == "native_extension"
    assert infer_jolt_adapter_kind("codex", "manual_wake") == "desktop_app"
    assert infer_jolt_adapter_kind("claude_app", "manual_wake") == "desktop_app"
    assert infer_jolt_adapter_kind("claude-cli", "manual_wake") == "managed_pty"


def test_jolt_adapter_from_dict_marks_listener_missing_infer_as_degraded():
    adapter = jolt_adapter_from_dict(
        "listener_backed",
        {
            "host_kind": "claude_code",
            "adapter": {
                "kind": "managed_pty",
                "supported_actions": ["notify", "stage_context"],
            },
        },
    )

    assert adapter.host_kind == "claude_code"
    assert adapter.adapter_kind == "managed_pty"
    assert adapter.supported_actions == ("notify", "stage_context")
    assert adapter.state == "degraded"
    assert adapter.detail == "missing infer"
