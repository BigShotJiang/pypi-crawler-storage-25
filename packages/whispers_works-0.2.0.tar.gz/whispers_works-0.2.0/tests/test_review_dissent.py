"""Tests for P2 schemas: review_beacon.v1, review_claim.v1, review_verdict.v1,
dissent_record.v1, dissent_resolution.v1.

Covers validation, lifecycle linking, composition (verdict + inline dissent),
and test vectors for each schema.
"""

from __future__ import annotations

import pytest

from whispers.twoack import (
    ValidationResult,
    validate_schema,
    validate_message,
    ERR_SCHEMA_INVALID,
    ERR_UNSUPPORTED_SCHEMA,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _envelope(schema: str, payload: dict, **extra) -> dict:
    env = {
        "wire_v": 1,
        "schema": schema,
        "trace": {"message_id": "msg-test-001"},
        "payload": payload,
        **extra,
    }
    return env


def _assert_valid(result: ValidationResult):
    assert result.valid, f"Expected valid but got errors: {result.errors}"


def _assert_invalid(result: ValidationResult, expected_code: str | None = None):
    assert not result.valid, "Expected invalid but got valid"
    if expected_code:
        assert expected_code in result.codes, f"Expected {expected_code} in {result.codes}"


# ===========================================================================
# review_beacon.v1
# ===========================================================================

class TestReviewBeacon:
    def test_minimal_valid(self):
        payload = {"artifact": "whispers/twoack.py", "review_lens": "correctness"}
        result = validate_schema("review_beacon.v1", payload)
        _assert_valid(result)

    def test_maximal_valid(self):
        payload = {
            "artifact": "whispers/twoack.py",
            "review_lens": "security",
            "lens_detail": None,
            "candidate_pool": ["codex", "antigravity"],
            "urgency": "priority",
            "context_refs": ["msg-abc-123", ".planning/P2-spec.md"],
            "workspace_id": "ws-001",
            "accept_schemas": ["review_verdict.v1"],
            "expires_at": "2026-03-27T12:00:00Z",
        }
        result = validate_schema("review_beacon.v1", payload)
        _assert_valid(result)

    def test_missing_artifact(self):
        payload = {"review_lens": "correctness"}
        result = validate_schema("review_beacon.v1", payload)
        _assert_invalid(result, ERR_SCHEMA_INVALID)

    def test_missing_review_lens(self):
        payload = {"artifact": "file.py"}
        result = validate_schema("review_beacon.v1", payload)
        _assert_invalid(result, ERR_SCHEMA_INVALID)

    def test_invalid_review_lens(self):
        payload = {"artifact": "file.py", "review_lens": "vibes"}
        result = validate_schema("review_beacon.v1", payload)
        _assert_invalid(result, ERR_SCHEMA_INVALID)

    def test_invalid_urgency(self):
        payload = {"artifact": "file.py", "review_lens": "quality", "urgency": "asap"}
        result = validate_schema("review_beacon.v1", payload)
        _assert_invalid(result, ERR_SCHEMA_INVALID)

    def test_custom_lens_with_detail(self):
        payload = {"artifact": "file.py", "review_lens": "custom", "lens_detail": "Check naming conventions"}
        result = validate_schema("review_beacon.v1", payload)
        _assert_valid(result)

    def test_all_lens_values_valid(self):
        for lens in ("correctness", "security", "architecture", "protocol", "quality", "ux", "custom"):
            payload = {"artifact": "file.py", "review_lens": lens}
            result = validate_schema("review_beacon.v1", payload)
            _assert_valid(result)

    def test_invalid_expires_at(self):
        payload = {"artifact": "file.py", "review_lens": "quality", "expires_at": "not-a-date"}
        result = validate_schema("review_beacon.v1", payload)
        _assert_invalid(result, ERR_SCHEMA_INVALID)

    def test_full_envelope_validates(self):
        env = _envelope("review_beacon.v1", {
            "artifact": "whispers/server.py",
            "review_lens": "architecture",
            "urgency": "blocking",
        })
        result = validate_message(env)
        _assert_valid(result)


# ===========================================================================
# review_claim.v1
# ===========================================================================

class TestReviewClaim:
    def test_minimal_valid(self):
        payload = {"beacon_ref": "msg-beacon-001"}
        result = validate_schema("review_claim.v1", payload)
        _assert_valid(result)

    def test_maximal_valid(self):
        payload = {
            "beacon_ref": "msg-beacon-001",
            "estimated_completion": "2026-03-27T14:00:00Z",
            "reviewer_context": "I built this module last week",
        }
        result = validate_schema("review_claim.v1", payload)
        _assert_valid(result)

    def test_missing_beacon_ref(self):
        payload = {}
        result = validate_schema("review_claim.v1", payload)
        _assert_invalid(result, ERR_SCHEMA_INVALID)

    def test_invalid_estimated_completion(self):
        payload = {"beacon_ref": "msg-001", "estimated_completion": "tomorrow"}
        result = validate_schema("review_claim.v1", payload)
        _assert_invalid(result, ERR_SCHEMA_INVALID)


# ===========================================================================
# review_verdict.v1
# ===========================================================================

class TestReviewVerdict:
    def test_minimal_valid(self):
        payload = {"beacon_ref": "msg-beacon-001", "verdict": "approve"}
        result = validate_schema("review_verdict.v1", payload)
        _assert_valid(result)

    def test_all_verdict_values(self):
        for verdict in ("approve", "request_changes", "reject", "defer"):
            payload = {"beacon_ref": "msg-001", "verdict": verdict}
            result = validate_schema("review_verdict.v1", payload)
            _assert_valid(result)

    def test_invalid_verdict(self):
        payload = {"beacon_ref": "msg-001", "verdict": "lgtm"}
        result = validate_schema("review_verdict.v1", payload)
        _assert_invalid(result, ERR_SCHEMA_INVALID)

    def test_missing_verdict(self):
        payload = {"beacon_ref": "msg-001"}
        result = validate_schema("review_verdict.v1", payload)
        _assert_invalid(result, ERR_SCHEMA_INVALID)

    def test_with_findings(self):
        payload = {
            "beacon_ref": "msg-001",
            "verdict": "request_changes",
            "confidence": 0.85,
            "blocking_findings_count": 2,
            "findings": [
                {
                    "severity": "critical",
                    "category": "security",
                    "description": "SQL injection in query builder",
                    "location": "whispers/storage/db.py:142",
                    "suggestion": "Use parameterized queries",
                },
                {
                    "severity": "minor",
                    "category": "style",
                    "description": "Inconsistent naming",
                    "location": "whispers/server.py:55",
                    "suggestion": "Use snake_case",
                },
            ],
        }
        result = validate_schema("review_verdict.v1", payload)
        _assert_valid(result)

    def test_invalid_finding_severity(self):
        payload = {
            "beacon_ref": "msg-001",
            "verdict": "reject",
            "findings": [{"severity": "catastrophic", "description": "bad"}],
        }
        result = validate_schema("review_verdict.v1", payload)
        _assert_invalid(result, ERR_SCHEMA_INVALID)

    def test_findings_must_be_array(self):
        payload = {"beacon_ref": "msg-001", "verdict": "approve", "findings": "none"}
        result = validate_schema("review_verdict.v1", payload)
        _assert_invalid(result, ERR_SCHEMA_INVALID)

    def test_finding_items_must_be_objects(self):
        payload = {"beacon_ref": "msg-001", "verdict": "approve", "findings": ["not an object"]}
        result = validate_schema("review_verdict.v1", payload)
        _assert_invalid(result, ERR_SCHEMA_INVALID)

    def test_with_inline_dissent(self):
        """Composition point: verdict carries inline dissent."""
        payload = {
            "beacon_ref": "msg-001",
            "verdict": "approve",
            "dissent": {
                "decision_ref": "msg-decision-001",
                "chosen_path": "Use SQLite for everything",
                "dissenting_agent": "antigravity",
                "alternate_path": "Use Postgres for the write path",
                "rationale": "SQLite WAL won't handle concurrent writes at scale",
                "confidence": 0.7,
                "risk_if_wrong": "Write contention under load",
                "revisit_trigger": "on_failure",
                "blocking": False,
            },
        }
        result = validate_schema("review_verdict.v1", payload)
        _assert_valid(result)

    def test_inline_dissent_missing_required_fields(self):
        payload = {
            "beacon_ref": "msg-001",
            "verdict": "approve",
            "dissent": {"rationale": "I disagree"},
        }
        result = validate_schema("review_verdict.v1", payload)
        _assert_invalid(result, ERR_SCHEMA_INVALID)

    def test_inline_dissent_invalid_confidence(self):
        payload = {
            "beacon_ref": "msg-001",
            "verdict": "approve",
            "dissent": {
                "decision_ref": "msg-001",
                "chosen_path": "path A",
                "dissenting_agent": "codex",
                "confidence": 1.5,
            },
        }
        result = validate_schema("review_verdict.v1", payload)
        _assert_invalid(result, ERR_SCHEMA_INVALID)

    def test_inline_dissent_invalid_revisit_trigger(self):
        payload = {
            "beacon_ref": "msg-001",
            "verdict": "approve",
            "dissent": {
                "decision_ref": "msg-001",
                "chosen_path": "path A",
                "dissenting_agent": "codex",
                "revisit_trigger": "whenever",
            },
        }
        result = validate_schema("review_verdict.v1", payload)
        _assert_invalid(result, ERR_SCHEMA_INVALID)


# ===========================================================================
# dissent_record.v1
# ===========================================================================

class TestDissentRecord:
    def test_minimal_valid(self):
        payload = {
            "decision_ref": "msg-decision-001",
            "chosen_path": "Use feature flags",
            "dissenting_agent": "antigravity",
        }
        result = validate_schema("dissent_record.v1", payload)
        _assert_valid(result)

    def test_maximal_valid(self):
        payload = {
            "decision_ref": "msg-decision-001",
            "chosen_path": "Use feature flags",
            "dissenting_agent": "antigravity",
            "alternate_path": "Direct code change with rollback plan",
            "rationale": "Feature flags add complexity for a one-time migration",
            "confidence": 0.8,
            "evidence_refs": ["msg-research-001", ".planning/migration-analysis.md"],
            "risk_if_wrong": "Feature flag debt accumulates and nobody cleans up",
            "revisit_trigger": "next_checkpoint",
            "revisit_by": None,
            "blocking": False,
            "workspace_id": "ws-migration",
        }
        result = validate_schema("dissent_record.v1", payload)
        _assert_valid(result)

    def test_missing_decision_ref(self):
        payload = {"chosen_path": "path A", "dissenting_agent": "codex"}
        result = validate_schema("dissent_record.v1", payload)
        _assert_invalid(result, ERR_SCHEMA_INVALID)

    def test_missing_chosen_path(self):
        payload = {"decision_ref": "msg-001", "dissenting_agent": "codex"}
        result = validate_schema("dissent_record.v1", payload)
        _assert_invalid(result, ERR_SCHEMA_INVALID)

    def test_missing_dissenting_agent(self):
        payload = {"decision_ref": "msg-001", "chosen_path": "path A"}
        result = validate_schema("dissent_record.v1", payload)
        _assert_invalid(result, ERR_SCHEMA_INVALID)

    def test_invalid_confidence(self):
        payload = {
            "decision_ref": "msg-001",
            "chosen_path": "path A",
            "dissenting_agent": "codex",
            "confidence": -0.1,
        }
        result = validate_schema("dissent_record.v1", payload)
        _assert_invalid(result, ERR_SCHEMA_INVALID)

    def test_invalid_revisit_trigger(self):
        payload = {
            "decision_ref": "msg-001",
            "chosen_path": "path A",
            "dissenting_agent": "codex",
            "revisit_trigger": "sometime",
        }
        result = validate_schema("dissent_record.v1", payload)
        _assert_invalid(result, ERR_SCHEMA_INVALID)

    def test_all_revisit_triggers(self):
        for trigger in ("next_checkpoint", "on_failure", "time_based", "operator_review", "never"):
            payload = {
                "decision_ref": "msg-001",
                "chosen_path": "A",
                "dissenting_agent": "codex",
                "revisit_trigger": trigger,
            }
            result = validate_schema("dissent_record.v1", payload)
            _assert_valid(result)

    def test_blocking_must_be_bool(self):
        payload = {
            "decision_ref": "msg-001",
            "chosen_path": "A",
            "dissenting_agent": "codex",
            "blocking": "yes",
        }
        result = validate_schema("dissent_record.v1", payload)
        _assert_invalid(result, ERR_SCHEMA_INVALID)

    def test_blocking_true_valid(self):
        payload = {
            "decision_ref": "msg-001",
            "chosen_path": "A",
            "dissenting_agent": "codex",
            "blocking": True,
        }
        result = validate_schema("dissent_record.v1", payload)
        _assert_valid(result)

    def test_full_envelope_validates(self):
        env = _envelope("dissent_record.v1", {
            "decision_ref": "msg-decision-001",
            "chosen_path": "Keep SQLite",
            "dissenting_agent": "antigravity",
            "rationale": "Concurrent writes will fail under load",
            "blocking": False,
        })
        result = validate_message(env)
        _assert_valid(result)


# ===========================================================================
# dissent_resolution.v1
# ===========================================================================

class TestDissentResolution:
    def test_minimal_valid(self):
        payload = {"dissent_ref": "msg-dissent-001", "resolution": "resolved"}
        result = validate_schema("dissent_resolution.v1", payload)
        _assert_valid(result)

    def test_all_resolution_values(self):
        for resolution in ("resolved", "vindicated", "archived", "withdrawn"):
            payload = {"dissent_ref": "msg-001", "resolution": resolution}
            result = validate_schema("dissent_resolution.v1", payload)
            _assert_valid(result)

    def test_maximal_valid(self):
        payload = {
            "dissent_ref": "msg-dissent-001",
            "resolution": "vindicated",
            "resolution_rationale": "SQLite hit write contention exactly as predicted",
            "resolution_evidence": ["msg-incident-001", "grafana.internal/d/write-latency"],
        }
        result = validate_schema("dissent_resolution.v1", payload)
        _assert_valid(result)

    def test_missing_dissent_ref(self):
        payload = {"resolution": "resolved"}
        result = validate_schema("dissent_resolution.v1", payload)
        _assert_invalid(result, ERR_SCHEMA_INVALID)

    def test_missing_resolution(self):
        payload = {"dissent_ref": "msg-001"}
        result = validate_schema("dissent_resolution.v1", payload)
        _assert_invalid(result, ERR_SCHEMA_INVALID)

    def test_invalid_resolution(self):
        payload = {"dissent_ref": "msg-001", "resolution": "ignored"}
        result = validate_schema("dissent_resolution.v1", payload)
        _assert_invalid(result, ERR_SCHEMA_INVALID)

    def test_full_envelope_with_supersedes(self):
        """Lifecycle linking: resolution supersedes original dissent."""
        env = _envelope("dissent_resolution.v1", {
            "dissent_ref": "msg-dissent-001",
            "resolution": "vindicated",
            "resolution_rationale": "Dissenter was right — write contention hit production",
        })
        env["trace"]["in_reply_to"] = "msg-dissent-001"
        env["trace"]["supersedes"] = "msg-dissent-001"
        result = validate_message(env)
        _assert_valid(result)


# ===========================================================================
# Test Vectors: Lifecycle Composition
# ===========================================================================

class TestReviewLifecycleComposition:
    """Tests the full beacon → claim → verdict causal chain."""

    def test_beacon_claim_verdict_chain(self):
        """All three messages in a review lifecycle validate independently."""
        beacon = _envelope("review_beacon.v1", {
            "artifact": "whispers/dispatcher.py",
            "review_lens": "security",
            "urgency": "priority",
            "candidate_pool": ["codex", "antigravity"],
        })
        beacon["trace"]["message_id"] = "msg-beacon-001"
        _assert_valid(validate_message(beacon))

        claim = _envelope("review_claim.v1", {
            "beacon_ref": "msg-beacon-001",
            "estimated_completion": "2026-03-27T15:00:00Z",
        })
        claim["trace"]["message_id"] = "msg-claim-001"
        claim["trace"]["in_reply_to"] = "msg-beacon-001"
        _assert_valid(validate_message(claim))

        verdict = _envelope("review_verdict.v1", {
            "beacon_ref": "msg-beacon-001",
            "verdict": "request_changes",
            "confidence": 0.9,
            "findings": [
                {
                    "severity": "critical",
                    "category": "security",
                    "description": "Unbounded shadow event recording",
                    "location": "whispers/dispatcher.py:249",
                    "suggestion": "Add rate limit per agent per hour",
                },
            ],
            "blocking_findings_count": 1,
        })
        verdict["trace"]["message_id"] = "msg-verdict-001"
        verdict["trace"]["in_reply_to"] = "msg-claim-001"
        _assert_valid(validate_message(verdict))

    def test_verdict_with_inline_dissent_composition(self):
        """A verdict can approve while carrying a dissent record."""
        verdict = _envelope("review_verdict.v1", {
            "beacon_ref": "msg-beacon-001",
            "verdict": "approve",
            "confidence": 0.75,
            "dissent": {
                "decision_ref": "msg-design-decision-042",
                "chosen_path": "Single-claimant review model",
                "dissenting_agent": "antigravity",
                "alternate_path": "Multi-reviewer with quorum",
                "rationale": "Single reviewer misses cross-cutting concerns",
                "confidence": 0.6,
                "risk_if_wrong": "Subtle architecture issues slip through",
                "revisit_trigger": "on_failure",
            },
        })
        _assert_valid(validate_message(verdict))


class TestDissentLifecycleComposition:
    """Tests dissent → resolution lifecycle."""

    def test_dissent_then_vindicated(self):
        dissent = _envelope("dissent_record.v1", {
            "decision_ref": "msg-decision-sqlite",
            "chosen_path": "Keep SQLite for all storage",
            "dissenting_agent": "antigravity",
            "alternate_path": "Migrate write-heavy tables to Postgres",
            "rationale": "WAL mode has known write contention above 50 concurrent writers",
            "confidence": 0.8,
            "risk_if_wrong": "Production write failures during traffic spikes",
            "revisit_trigger": "on_failure",
            "blocking": False,
        })
        dissent["trace"]["message_id"] = "msg-dissent-sqlite"
        _assert_valid(validate_message(dissent))

        resolution = _envelope("dissent_resolution.v1", {
            "dissent_ref": "msg-dissent-sqlite",
            "resolution": "vindicated",
            "resolution_rationale": "Production write contention observed at 35 concurrent writes",
            "resolution_evidence": ["msg-incident-report-001"],
        })
        resolution["trace"]["message_id"] = "msg-resolution-001"
        resolution["trace"]["in_reply_to"] = "msg-dissent-sqlite"
        resolution["trace"]["supersedes"] = "msg-dissent-sqlite"
        _assert_valid(validate_message(resolution))

    def test_dissent_then_archived(self):
        dissent = _envelope("dissent_record.v1", {
            "decision_ref": "msg-pricing-model",
            "chosen_path": "Feature-tier pricing",
            "dissenting_agent": "codex",
            "alternate_path": "Usage-based pricing",
            "rationale": "Feature tiers leave money on the table for heavy users",
            "confidence": 0.4,
            "revisit_trigger": "time_based",
            "revisit_by": "2026-06-01T00:00:00Z",
            "blocking": False,
        })
        dissent["trace"]["message_id"] = "msg-dissent-pricing"
        _assert_valid(validate_message(dissent))

        resolution = _envelope("dissent_resolution.v1", {
            "dissent_ref": "msg-dissent-pricing",
            "resolution": "archived",
            "resolution_rationale": "Feature-tier model validated by first 50 customers",
        })
        resolution["trace"]["message_id"] = "msg-resolution-002"
        resolution["trace"]["in_reply_to"] = "msg-dissent-pricing"
        _assert_valid(validate_message(resolution))
