"""A2A Protocol Interop Compliance Tests.

These tests validate that Whispers' A2A gateway behaves correctly from the
perspective of an EXTERNAL A2A client. No internal Whispers knowledge is used
in the assertions — only what the A2A v1.0 spec defines.

This is the "external auditor" test suite. If Google's sample agents hit our
gateway, these are the things that must work.

Test categories:
1. Agent Card Discovery — well-known URI, required fields, v1.0 format
2. JSON-RPC 2.0 Compliance — envelope structure, error codes, id echo
3. message/send — full lifecycle, Task object validation
4. tasks/get — retrieval of submitted tasks
5. tasks/cancel — cancellation lifecycle
6. message/stream — SSE format compliance
7. Wire Format — Part types, SCREAMING_SNAKE_CASE enums, camelCase fields
"""
import json
import re
import shutil
import uuid
from pathlib import Path

import pytest
from fastapi.testclient import TestClient


def _make_case_dir() -> Path:
    root = Path(__file__).resolve().parents[1] / ".tmp"
    root.mkdir(parents=True, exist_ok=True)
    case_dir = root / f"a2a-interop-{uuid.uuid4().hex}"
    case_dir.mkdir(parents=True, exist_ok=False)
    return case_dir


@pytest.fixture
def a2a_env(monkeypatch):
    """Stand up an isolated Whispers server with a registered agent for A2A tests."""
    import importlib

    case_dir = _make_case_dir()
    db_path = case_dir / "interop.db"

    monkeypatch.setenv("WHISPERS_DB_PATH", str(db_path))
    monkeypatch.setenv("WHISPERS_REMOTE_ADMISSION_MODE", "open")
    runtime_state_path = case_dir / "runtime-state.json"
    monkeypatch.setenv("WHISPERS_RUNTIME_STATE_PATH", str(runtime_state_path))

    import whispers.server as server_module

    server_module = importlib.reload(server_module)

    with TestClient(server_module.app) as client:
        # Register a target agent via /connect so it exists in the registry
        connect = client.post("/connect", json={"agent_name": "echo-agent"})
        assert connect.status_code == 200, f"Setup failed: {connect.text}"
        yield {
            "client": client,
            "case_dir": case_dir,
            "agent": "echo-agent",
            "token": connect.json()["token"],
        }

    shutil.rmtree(case_dir, ignore_errors=True)


def _jsonrpc_request(method: str, params: dict, request_id=1) -> dict:
    """Build a spec-compliant JSON-RPC 2.0 request."""
    return {
        "jsonrpc": "2.0",
        "id": request_id,
        "method": method,
        "params": params,
    }


def _a2a_message(text: str, recipient: str, **extra_meta) -> dict:
    """Build a spec-compliant A2A Message object."""
    meta = {"whispers:recipient": recipient, **extra_meta}
    return {
        "role": "user",
        "parts": [{"text": text}],
        "messageId": f"msg-{uuid.uuid4()}",
        "metadata": meta,
    }


# ===========================================================================
# 1. Agent Card Discovery
# ===========================================================================


class TestAgentCardDiscovery:
    """An external A2A client discovers agents via well-known URIs."""

    def test_well_known_uri_returns_valid_card(self, a2a_env):
        """RFC 8615: Agent Card MUST be at /.well-known/agent-card.json."""
        resp = a2a_env["client"].get("/.well-known/agent-card.json")
        assert resp.status_code == 200
        assert "application/json" in resp.headers.get("content-type", "")

    def test_hub_card_has_all_required_fields(self, a2a_env):
        """A2A v1.0: name, description, version, url, protocolVersions are required."""
        card = a2a_env["client"].get("/.well-known/agent-card.json").json()
        required = ["name", "description", "version", "url", "protocolVersions"]
        for field in required:
            assert field in card, f"Missing required field: {field}"

    def test_protocol_versions_includes_v1(self, a2a_env):
        """Must advertise v1.0 support."""
        card = a2a_env["client"].get("/.well-known/agent-card.json").json()
        assert "1.0" in card["protocolVersions"]

    def test_url_points_to_a2a_endpoint(self, a2a_env):
        """url field should point to the A2A gateway endpoint."""
        card = a2a_env["client"].get("/.well-known/agent-card.json").json()
        assert card["url"].endswith("/a2a/v1")

    def test_capabilities_are_booleans(self, a2a_env):
        """Capability flags must be boolean, not strings or ints."""
        card = a2a_env["client"].get("/.well-known/agent-card.json").json()
        caps = card.get("capabilities", {})
        for key in ["streaming", "pushNotifications", "stateTransitionHistory"]:
            if key in caps:
                assert isinstance(caps[key], bool), f"{key} must be boolean, got {type(caps[key])}"

    def test_supported_interfaces_has_jsonrpc(self, a2a_env):
        """supportedInterfaces SHOULD list JSONRPC binding."""
        card = a2a_env["client"].get("/.well-known/agent-card.json").json()
        interfaces = card.get("supportedInterfaces", [])
        protocols = [i.get("protocol") for i in interfaces]
        assert "JSONRPC" in protocols

    def test_per_agent_card_discovery(self, a2a_env):
        """Per-agent cards at /agents/{callsign}/.well-known/agent-card.json."""
        resp = a2a_env["client"].get(
            f"/agents/{a2a_env['agent']}/.well-known/agent-card.json"
        )
        assert resp.status_code == 200
        card = resp.json()
        assert card["name"]  # Must have a name
        assert "protocolVersions" in card

    def test_per_agent_card_has_whispers_metadata(self, a2a_env):
        """Whispers extensions should appear in metadata with whispers: prefix."""
        card = a2a_env["client"].get(
            f"/agents/{a2a_env['agent']}/.well-known/agent-card.json"
        ).json()
        meta = card.get("metadata", {})
        whispers_keys = [k for k in meta if k.startswith("whispers:")]
        assert len(whispers_keys) > 0, "No whispers: metadata extensions found"

    def test_nonexistent_agent_returns_404(self, a2a_env):
        """Unknown agent card request returns 404."""
        resp = a2a_env["client"].get(
            "/agents/does-not-exist/.well-known/agent-card.json"
        )
        assert resp.status_code == 404


# ===========================================================================
# 2. JSON-RPC 2.0 Compliance
# ===========================================================================


class TestJsonRpcCompliance:
    """JSON-RPC 2.0 envelope compliance — the transport layer."""

    def test_response_always_returns_200(self, a2a_env):
        """A2A convention: HTTP status is always 200, errors in JSON-RPC body."""
        resp = a2a_env["client"].post(
            "/a2a/v1",
            json=_jsonrpc_request("nonexistent/method", {}),
        )
        assert resp.status_code == 200

    def test_response_has_jsonrpc_field(self, a2a_env):
        """Every response MUST include "jsonrpc": "2.0"."""
        resp = a2a_env["client"].post(
            "/a2a/v1",
            json=_jsonrpc_request("tasks/get", {"taskId": "fake"}),
        )
        body = resp.json()
        assert body.get("jsonrpc") == "2.0"

    def test_response_echoes_request_id(self, a2a_env):
        """Server MUST echo the id from the request."""
        for req_id in ["abc-123", 42, "req-001"]:
            resp = a2a_env["client"].post(
                "/a2a/v1",
                json=_jsonrpc_request("tasks/get", {"taskId": "fake"}, request_id=req_id),
            )
            body = resp.json()
            assert body.get("id") == req_id, f"ID mismatch: expected {req_id}, got {body.get('id')}"

    def test_missing_jsonrpc_field_returns_invalid_request(self, a2a_env):
        """Missing "jsonrpc" field → error code -32600."""
        resp = a2a_env["client"].post(
            "/a2a/v1",
            json={"method": "message/send", "params": {}, "id": 1},
        )
        body = resp.json()
        assert "error" in body
        assert body["error"]["code"] == -32600

    def test_wrong_jsonrpc_version_returns_invalid_request(self, a2a_env):
        """jsonrpc != "2.0" → error code -32600."""
        resp = a2a_env["client"].post(
            "/a2a/v1",
            json={"jsonrpc": "1.0", "method": "message/send", "params": {}, "id": 1},
        )
        body = resp.json()
        assert "error" in body
        assert body["error"]["code"] == -32600

    def test_unknown_method_returns_method_not_found(self, a2a_env):
        """Unknown method → error code -32601."""
        resp = a2a_env["client"].post(
            "/a2a/v1",
            json=_jsonrpc_request("unknown/method", {}),
        )
        body = resp.json()
        assert "error" in body
        assert body["error"]["code"] == -32601

    def test_malformed_json_returns_parse_error(self, a2a_env):
        """Invalid JSON → error code -32700."""
        resp = a2a_env["client"].post(
            "/a2a/v1",
            content=b"not valid json {{{",
            headers={"Content-Type": "application/json"},
        )
        body = resp.json()
        assert "error" in body
        assert body["error"]["code"] == -32700

    def test_error_response_structure(self, a2a_env):
        """Error objects MUST have code (int) and message (string)."""
        resp = a2a_env["client"].post(
            "/a2a/v1",
            json=_jsonrpc_request("nonexistent/method", {}),
        )
        error = resp.json()["error"]
        assert isinstance(error["code"], int)
        assert isinstance(error["message"], str)

    def test_success_response_structure(self, a2a_env):
        """Success responses have "result", no "error"."""
        msg = _a2a_message("Hello", a2a_env["agent"])
        resp = a2a_env["client"].post(
            "/a2a/v1",
            json=_jsonrpc_request("message/send", {"message": msg}),
        )
        body = resp.json()
        assert "result" in body
        assert "error" not in body


# ===========================================================================
# 3. message/send — Task Lifecycle
# ===========================================================================


class TestMessageSend:
    """message/send: the core A2A method."""

    def test_returns_valid_task(self, a2a_env):
        """message/send MUST return a Task object."""
        msg = _a2a_message("What's the weather?", a2a_env["agent"])
        resp = a2a_env["client"].post(
            "/a2a/v1",
            json=_jsonrpc_request("message/send", {"message": msg}),
        )
        task = resp.json()["result"]
        assert "id" in task, "Task must have an id"
        assert "status" in task, "Task must have a status"
        assert "contextId" in task, "Task must have a contextId"

    def test_task_id_is_string(self, a2a_env):
        """Task id must be a string (UUID)."""
        msg = _a2a_message("Hello", a2a_env["agent"])
        task = a2a_env["client"].post(
            "/a2a/v1",
            json=_jsonrpc_request("message/send", {"message": msg}),
        ).json()["result"]
        assert isinstance(task["id"], str)

    def test_task_status_has_state_and_timestamp(self, a2a_env):
        """TaskStatus MUST have state and timestamp."""
        msg = _a2a_message("Hello", a2a_env["agent"])
        task = a2a_env["client"].post(
            "/a2a/v1",
            json=_jsonrpc_request("message/send", {"message": msg}),
        ).json()["result"]
        status = task["status"]
        assert "state" in status
        assert "timestamp" in status

    def test_task_state_uses_screaming_snake_case(self, a2a_env):
        """v1.0: Task states MUST use SCREAMING_SNAKE_CASE (e.g., TASK_STATE_SUBMITTED)."""
        msg = _a2a_message("Hello", a2a_env["agent"])
        task = a2a_env["client"].post(
            "/a2a/v1",
            json=_jsonrpc_request("message/send", {"message": msg}),
        ).json()["result"]
        state = task["status"]["state"]
        valid_states = {
            "TASK_STATE_SUBMITTED",
            "TASK_STATE_WORKING",
            "TASK_STATE_INPUT_REQUIRED",
            "TASK_STATE_AUTH_REQUIRED",
            "TASK_STATE_COMPLETED",
            "TASK_STATE_FAILED",
            "TASK_STATE_CANCELED",
            "TASK_STATE_REJECTED",
            "TASK_STATE_UNKNOWN",
        }
        assert state in valid_states, f"Invalid task state: '{state}'. Must be SCREAMING_SNAKE_CASE."

    def test_timestamp_is_iso_8601(self, a2a_env):
        """Timestamps MUST be ISO 8601."""
        msg = _a2a_message("Hello", a2a_env["agent"])
        task = a2a_env["client"].post(
            "/a2a/v1",
            json=_jsonrpc_request("message/send", {"message": msg}),
        ).json()["result"]
        ts = task["status"]["timestamp"]
        # Must parse as ISO 8601 — at minimum YYYY-MM-DDTHH:MM:SS
        assert re.match(r"\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}", ts), f"Invalid ISO 8601: {ts}"

    def test_artifacts_is_a_list(self, a2a_env):
        """Task.artifacts MUST be a list (may be empty)."""
        msg = _a2a_message("Hello", a2a_env["agent"])
        task = a2a_env["client"].post(
            "/a2a/v1",
            json=_jsonrpc_request("message/send", {"message": msg}),
        ).json()["result"]
        assert isinstance(task.get("artifacts", []), list)

    def test_body_becomes_text_part_artifact(self, a2a_env):
        """Message body should appear as a TextPart in artifacts."""
        msg = _a2a_message("Important message content", a2a_env["agent"])
        task = a2a_env["client"].post(
            "/a2a/v1",
            json=_jsonrpc_request("message/send", {"message": msg}),
        ).json()["result"]
        artifacts = task.get("artifacts", [])
        # Should have at least one artifact with the body text
        all_text = " ".join(
            part.get("text", "")
            for a in artifacts
            for part in a.get("parts", [])
            if "text" in part
        )
        assert "Important message content" in all_text

    def test_data_part_passed_through(self, a2a_env):
        """DataPart in message should be forwarded as structured data."""
        msg = {
            "role": "user",
            "parts": [
                {"text": "Weather request"},
                {"data": {"location": "Portland", "unit": "celsius"}},
            ],
            "messageId": f"msg-{uuid.uuid4()}",
            "metadata": {"whispers:recipient": a2a_env["agent"]},
        }
        resp = a2a_env["client"].post(
            "/a2a/v1",
            json=_jsonrpc_request("message/send", {"message": msg}),
        )
        body = resp.json()
        assert "result" in body
        task = body["result"]
        data_parts = [
            part["data"]
            for artifact in task.get("artifacts", [])
            for part in artifact.get("parts", [])
            if "data" in part
        ]
        assert {"location": "Portland", "unit": "celsius"} in data_parts

    def test_reachability_policy_block_surfaces_as_failed_task(self, a2a_env):
        """Runtime reachability rejects should surface as failed A2A tasks, not fake submissions."""
        from whispers.client import WhispersClient

        local = WhispersClient(a2a_env["agent"], db_path=str(a2a_env["case_dir"] / "interop.db"))
        local.set_presence_policy({"reachability": "none"})

        msg = _a2a_message("You should not get through", a2a_env["agent"])
        resp = a2a_env["client"].post(
            "/a2a/v1",
            json=_jsonrpc_request("message/send", {"message": msg}),
        )

        task = resp.json()["result"]
        assert task["status"]["state"] == "TASK_STATE_FAILED"
        assert task["metadata"]["whispers:deliveryStatus"] == "dead_lettered"
        assert task["metadata"]["whispers:dispatchRejectReason"] == "reachability_policy_blocked"

    def test_valid_twoack_data_part_is_validated_and_preserved(self, a2a_env):
        """2ack payloads should be recognized, validated, and passed through explicitly."""
        envelope = {
            "wire_v": 1,
            "schema": "decision_request.v1",
            "mode": "bilingual",
            "signal_class": "external",
            "trace": {
                "message_id": f"msg-{uuid.uuid4()}",
                "trace_id": "deploy-flow-1",
            },
            "summary": {
                "headline": "Deploy decision",
                "human": "Should we deploy to staging now?",
            },
            "payload": {
                "question": "Deploy to staging?",
                "options": ["yes", "no"],
                "recommended_option": "yes",
            },
        }
        msg = {
            "role": "user",
            "parts": [{"data": envelope}],
            "messageId": envelope["trace"]["message_id"],
            "metadata": {
                "whispers:recipient": a2a_env["agent"],
                "whispers:schema": "wrong_schema.v9",
            },
        }

        resp = a2a_env["client"].post(
            "/a2a/v1",
            json=_jsonrpc_request("message/send", {"message": msg}),
        )
        body = resp.json()
        assert "result" in body
        task = body["result"]

        data_parts = [
            part["data"]
            for artifact in task.get("artifacts", [])
            for part in artifact.get("parts", [])
            if "data" in part
        ]
        assert envelope in data_parts
        assert task["metadata"]["whispers:schema"] == "decision_request.v1"
        assert task["metadata"]["whispers:wireMode"] == "bilingual"
        assert task["metadata"]["whispers:signalClass"] == "external"
        assert "whispers:schema" in task["metadata"]["whispers:2ackMirrorConflicts"]

        all_text = " ".join(
            part.get("text", "")
            for artifact in task.get("artifacts", [])
            for part in artifact.get("parts", [])
            if "text" in part
        )
        assert "Should we deploy to staging now?" in all_text

    def test_invalid_twoack_data_part_returns_invalid_params(self, a2a_env):
        """Malformed 2ack payloads should be rejected at the gateway boundary."""
        msg = {
            "role": "user",
            "parts": [
                {
                    "data": {
                        "wire_v": 1,
                        "schema": "decision_request.v1",
                        "trace": {},
                        "payload": {
                            "question": "Deploy?",
                            "options": ["yes", "no"],
                        },
                    }
                }
            ],
            "messageId": f"msg-{uuid.uuid4()}",
            "metadata": {"whispers:recipient": a2a_env["agent"]},
        }

        resp = a2a_env["client"].post(
            "/a2a/v1",
            json=_jsonrpc_request("message/send", {"message": msg}),
        )
        body = resp.json()
        assert "error" in body
        assert body["error"]["code"] == -32602
        assert body["error"]["data"]["protocol"] == "2ack"
        paths = {entry["path"] for entry in body["error"]["data"]["errors"]}
        assert "trace.message_id" in paths

    def test_missing_message_returns_error(self, a2a_env):
        """message/send without message field should error."""
        resp = a2a_env["client"].post(
            "/a2a/v1",
            json=_jsonrpc_request("message/send", {}),
        )
        body = resp.json()
        assert "error" in body

    def test_missing_recipient_returns_error(self, a2a_env):
        """message/send without a determinable recipient should error."""
        msg = {
            "role": "user",
            "parts": [{"text": "Hello"}],
            "messageId": f"msg-{uuid.uuid4()}",
            # No metadata with whispers:recipient
        }
        resp = a2a_env["client"].post(
            "/a2a/v1",
            json=_jsonrpc_request("message/send", {"message": msg}),
        )
        body = resp.json()
        assert "error" in body

    def test_nonexistent_recipient_returns_agent_not_found(self, a2a_env):
        """Sending to unknown agent should return an A2A error."""
        msg = _a2a_message("Hello", "ghost-agent")
        resp = a2a_env["client"].post(
            "/a2a/v1",
            json=_jsonrpc_request("message/send", {"message": msg}),
        )
        body = resp.json()
        assert "error" in body

    def test_at_prefix_recipient_resolution(self, a2a_env):
        """Alternative recipient resolution: @agentname: message body."""
        agent = a2a_env["agent"]
        msg = {
            "role": "user",
            "parts": [{"text": f"@{agent}: Hello from at-prefix"}],
            "messageId": f"msg-{uuid.uuid4()}",
            # No metadata — recipient resolved from @-prefix
        }
        resp = a2a_env["client"].post(
            "/a2a/v1",
            json=_jsonrpc_request("message/send", {"message": msg}),
        )
        body = resp.json()
        assert "result" in body, f"Expected success, got: {body}"


# ===========================================================================
# 4. tasks/get — Task Retrieval
# ===========================================================================


class TestTasksGet:
    """tasks/get: retrieve a previously submitted task."""

    def test_get_submitted_task(self, a2a_env):
        """Can retrieve a task by ID after message/send."""
        msg = _a2a_message("Hello for retrieval", a2a_env["agent"])
        send_resp = a2a_env["client"].post(
            "/a2a/v1",
            json=_jsonrpc_request("message/send", {"message": msg}, request_id="send-1"),
        )
        task_id = send_resp.json()["result"]["id"]

        get_resp = a2a_env["client"].post(
            "/a2a/v1",
            json=_jsonrpc_request("tasks/get", {"taskId": task_id}, request_id="get-1"),
        )
        body = get_resp.json()
        assert "result" in body, f"Expected result, got: {body}"
        assert body["result"]["id"] == task_id

    def test_get_preserves_task_structure(self, a2a_env):
        """Retrieved task has the same structure as send response."""
        msg = _a2a_message("Structure test", a2a_env["agent"])
        send_task = a2a_env["client"].post(
            "/a2a/v1",
            json=_jsonrpc_request("message/send", {"message": msg}),
        ).json()["result"]

        get_task = a2a_env["client"].post(
            "/a2a/v1",
            json=_jsonrpc_request("tasks/get", {"taskId": send_task["id"]}),
        ).json()["result"]

        assert "id" in get_task
        assert "status" in get_task
        assert "state" in get_task["status"]

    def test_get_nonexistent_task(self, a2a_env):
        """Getting a nonexistent task returns an error."""
        resp = a2a_env["client"].post(
            "/a2a/v1",
            json=_jsonrpc_request("tasks/get", {"taskId": "nonexistent-task-id"}),
        )
        body = resp.json()
        # Should be an error (either in error field or result with error code)
        has_error = "error" in body or (
            isinstance(body.get("result"), dict)
            and "error" in body["result"]
        )
        assert has_error, f"Expected error for nonexistent task, got: {body}"

    def test_get_missing_task_id_returns_error(self, a2a_env):
        """tasks/get without taskId should error."""
        resp = a2a_env["client"].post(
            "/a2a/v1",
            json=_jsonrpc_request("tasks/get", {}),
        )
        body = resp.json()
        assert "error" in body


# ===========================================================================
# 5. tasks/cancel — Cancellation Lifecycle
# ===========================================================================


class TestTasksCancel:
    """tasks/cancel: cancellation of pending tasks."""

    def test_cancel_submitted_task(self, a2a_env):
        """Can cancel a task in SUBMITTED state."""
        msg = _a2a_message("Cancel me", a2a_env["agent"])
        task = a2a_env["client"].post(
            "/a2a/v1",
            json=_jsonrpc_request("message/send", {"message": msg}),
        ).json()["result"]

        cancel_resp = a2a_env["client"].post(
            "/a2a/v1",
            json=_jsonrpc_request("tasks/cancel", {"taskId": task["id"]}),
        )
        body = cancel_resp.json()
        assert "result" in body, f"Expected result, got: {body}"
        assert body["result"]["status"]["state"] == "TASK_STATE_CANCELED"

    def test_cancel_already_canceled_task_fails(self, a2a_env):
        """Canceling a terminal task MUST return TaskNotCancelableError."""
        msg = _a2a_message("Cancel twice", a2a_env["agent"])
        task = a2a_env["client"].post(
            "/a2a/v1",
            json=_jsonrpc_request("message/send", {"message": msg}),
        ).json()["result"]

        # Cancel once
        a2a_env["client"].post(
            "/a2a/v1",
            json=_jsonrpc_request("tasks/cancel", {"taskId": task["id"]}),
        )

        # Cancel again — should fail
        second = a2a_env["client"].post(
            "/a2a/v1",
            json=_jsonrpc_request("tasks/cancel", {"taskId": task["id"]}),
        )
        body = second.json()
        # Should indicate not cancelable (either error or result with error)
        has_error = "error" in body or (
            isinstance(body.get("result"), dict)
            and "error" in body["result"]
        )
        assert has_error, f"Expected not-cancelable error, got: {body}"

    def test_cancel_nonexistent_task(self, a2a_env):
        """Canceling a nonexistent task returns an error."""
        resp = a2a_env["client"].post(
            "/a2a/v1",
            json=_jsonrpc_request("tasks/cancel", {"taskId": "nonexistent"}),
        )
        body = resp.json()
        has_error = "error" in body or (
            isinstance(body.get("result"), dict)
            and "error" in body["result"]
        )
        assert has_error


# ===========================================================================
# 6. message/stream — SSE Compliance
# ===========================================================================


class TestMessageStream:
    """message/stream: SSE streaming for real-time task updates."""

    @pytest.mark.skip(reason="SSE generator polls for 5min with no state change — needs async test harness")
    def test_stream_returns_sse_content_type(self, a2a_env):
        """message/stream should return text/event-stream."""
        msg = _a2a_message("Stream test", a2a_env["agent"])
        resp = a2a_env["client"].post(
            "/a2a/v1",
            json=_jsonrpc_request("message/stream", {"message": msg}),
        )
        content_type = resp.headers.get("content-type", "")
        assert "text/event-stream" in content_type, f"Expected SSE content type, got: {content_type}"

    @pytest.mark.skip(reason="SSE generator polls for 5min with no state change — needs async test harness")
    def test_stream_events_are_json_rpc_responses(self, a2a_env):
        """Each SSE data event should contain a JSON-RPC response with a Task."""
        msg = _a2a_message("Stream JSON-RPC test", a2a_env["agent"])
        resp = a2a_env["client"].post(
            "/a2a/v1",
            json=_jsonrpc_request("message/stream", {"message": msg}, request_id="stream-1"),
        )
        # Parse SSE events from the response
        text = resp.text
        data_lines = [
            line.replace("data: ", "").strip()
            for line in text.split("\n")
            if line.startswith("data: ")
        ]
        assert len(data_lines) > 0, f"No SSE data events found in: {text[:500]}"

        for data_line in data_lines:
            event = json.loads(data_line)
            assert event.get("jsonrpc") == "2.0", "SSE event must be JSON-RPC 2.0"
            assert "result" in event, f"SSE event missing result: {event}"

    @pytest.mark.skip(reason="SSE generator polls for 5min with no state change — needs async test harness")
    def test_stream_task_state_is_valid(self, a2a_env):
        """Task states in stream events must be valid SCREAMING_SNAKE_CASE."""
        valid_states = {
            "TASK_STATE_SUBMITTED", "TASK_STATE_WORKING",
            "TASK_STATE_INPUT_REQUIRED", "TASK_STATE_AUTH_REQUIRED",
            "TASK_STATE_COMPLETED", "TASK_STATE_FAILED",
            "TASK_STATE_CANCELED", "TASK_STATE_REJECTED",
            "TASK_STATE_UNKNOWN",
        }
        msg = _a2a_message("Stream state test", a2a_env["agent"])
        resp = a2a_env["client"].post(
            "/a2a/v1",
            json=_jsonrpc_request("message/stream", {"message": msg}),
        )
        data_lines = [
            line.replace("data: ", "").strip()
            for line in resp.text.split("\n")
            if line.startswith("data: ")
        ]
        for data_line in data_lines:
            event = json.loads(data_line)
            if "result" in event:
                state = event["result"]["status"]["state"]
                assert state in valid_states, f"Invalid state in stream: {state}"

    def test_stream_missing_recipient_returns_error(self, a2a_env):
        """message/stream without recipient should return an error."""
        msg = {
            "role": "user",
            "parts": [{"text": "No recipient"}],
            "messageId": f"msg-{uuid.uuid4()}",
        }
        resp = a2a_env["client"].post(
            "/a2a/v1",
            json=_jsonrpc_request("message/stream", {"message": msg}),
        )
        # Should return an error response (not SSE)
        body = resp.json()
        assert "error" in body


# ===========================================================================
# 7. Wire Format — Field Naming & Part Types
# ===========================================================================


class TestWireFormat:
    """v1.0 wire format: camelCase fields, no 'kind' discriminator, etc."""

    def test_task_fields_are_camel_case(self, a2a_env):
        """Task fields MUST use camelCase (contextId, not context_id)."""
        msg = _a2a_message("camelCase test", a2a_env["agent"])
        task = a2a_env["client"].post(
            "/a2a/v1",
            json=_jsonrpc_request("message/send", {"message": msg}),
        ).json()["result"]

        # These MUST be camelCase
        assert "contextId" in task, "Must use 'contextId', not 'context_id'"
        assert "artifactId" in task["artifacts"][0] if task.get("artifacts") else True

    def test_text_part_has_no_kind_field(self, a2a_env):
        """v1.0: No 'kind' discriminator — presence of 'text' key IS the type."""
        msg = _a2a_message("No kind test", a2a_env["agent"])
        task = a2a_env["client"].post(
            "/a2a/v1",
            json=_jsonrpc_request("message/send", {"message": msg}),
        ).json()["result"]
        for artifact in task.get("artifacts", []):
            for part in artifact.get("parts", []):
                assert "kind" not in part, f"v1.0: 'kind' discriminator must not be present. Found in: {part}"

    def test_metadata_uses_whispers_prefix(self, a2a_env):
        """Whispers extensions in Task metadata use whispers: prefix."""
        msg = _a2a_message("Metadata test", a2a_env["agent"])
        task = a2a_env["client"].post(
            "/a2a/v1",
            json=_jsonrpc_request("message/send", {"message": msg}),
        ).json()["result"]
        meta = task.get("metadata", {})
        for key in meta:
            if "whispers" in key.lower():
                assert key.startswith("whispers:"), f"Extension key '{key}' should use 'whispers:' prefix"

    def test_agent_card_fields_are_camel_case(self, a2a_env):
        """Agent Card fields MUST use camelCase."""
        card = a2a_env["client"].get("/.well-known/agent-card.json").json()
        # These specific fields must be camelCase
        camel_fields = ["protocolVersions", "defaultInputModes", "defaultOutputModes", "supportedInterfaces"]
        for field in camel_fields:
            if field in card:
                # Just checking it exists with the right case
                assert True
            # Check no snake_case alternatives exist
            snake = re.sub(r"([A-Z])", r"_\1", field).lower()
            assert snake not in card, f"Found snake_case '{snake}' — must use '{field}'"


# ===========================================================================
# 8. End-to-End Lifecycle
# ===========================================================================


class TestEndToEndLifecycle:
    """Full lifecycle: send → get → cancel, validating transitions."""

    def test_send_then_get_then_cancel(self, a2a_env):
        """Complete lifecycle: send a task, retrieve it, cancel it."""
        # Send
        msg = _a2a_message("Full lifecycle test", a2a_env["agent"])
        send = a2a_env["client"].post(
            "/a2a/v1",
            json=_jsonrpc_request("message/send", {"message": msg}, request_id="lifecycle-1"),
        ).json()
        assert "result" in send
        task_id = send["result"]["id"]
        assert send["result"]["status"]["state"] in {
            "TASK_STATE_SUBMITTED", "TASK_STATE_WORKING"
        }

        # Get
        get = a2a_env["client"].post(
            "/a2a/v1",
            json=_jsonrpc_request("tasks/get", {"taskId": task_id}, request_id="lifecycle-2"),
        ).json()
        assert "result" in get
        assert get["result"]["id"] == task_id

        # Cancel
        cancel = a2a_env["client"].post(
            "/a2a/v1",
            json=_jsonrpc_request("tasks/cancel", {"taskId": task_id}, request_id="lifecycle-3"),
        ).json()
        assert "result" in cancel
        assert cancel["result"]["status"]["state"] == "TASK_STATE_CANCELED"

        # Verify terminal — get after cancel should still show canceled
        final = a2a_env["client"].post(
            "/a2a/v1",
            json=_jsonrpc_request("tasks/get", {"taskId": task_id}, request_id="lifecycle-4"),
        ).json()
        assert "result" in final
        assert final["result"]["status"]["state"] in {
            "TASK_STATE_CANCELED", "TASK_STATE_FAILED"
        }

    def test_multiple_tasks_have_unique_ids(self, a2a_env):
        """Each message/send creates a task with a unique ID."""
        ids = set()
        for i in range(5):
            msg = _a2a_message(f"Unique test {i}", a2a_env["agent"])
            task = a2a_env["client"].post(
                "/a2a/v1",
                json=_jsonrpc_request("message/send", {"message": msg}, request_id=f"unique-{i}"),
            ).json()["result"]
            ids.add(task["id"])
        assert len(ids) == 5, f"Expected 5 unique task IDs, got {len(ids)}"
