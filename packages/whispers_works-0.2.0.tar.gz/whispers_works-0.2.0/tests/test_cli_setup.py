import json
import sqlite3
import shutil
import urllib.parse
import uuid
from pathlib import Path

from click.testing import CliRunner

import whispers.cli as cli_module
import whispers.storage.db as db_module
from whispers.client import WhispersClient
from whispers.connection_story import ActiveReplyAlert, ConnectionStory
from whispers.storage.db import WhispersDB


def _make_case_dir() -> Path:
    root = Path(__file__).resolve().parents[1] / ".tmp"
    root.mkdir(parents=True, exist_ok=True)
    case_dir = root / f"cli-setup-{uuid.uuid4().hex}"
    case_dir.mkdir(parents=True, exist_ok=False)
    return case_dir


def test_doctor_continues_past_missing_db_and_reports_server_mismatch(monkeypatch):
    case_dir = _make_case_dir()
    local_db = case_dir / "local.db"
    server_db = case_dir / "server.db"
    codex_config = case_dir / ".codex" / "config.toml"
    codex_config.parent.mkdir(parents=True, exist_ok=True)
    codex_config.write_text(
        '\n[mcp_servers.whispers]\n'
        'url = "http://127.0.0.1:8752/mcp/?agent=codex"\n'
        'bearer_token_env_var = "WHISPERS_MCP_TOKEN"\n',
        encoding="utf-8",
    )

    try:
        monkeypatch.chdir(case_dir)
        monkeypatch.setenv("WHISPERS_DB_PATH", str(local_db))
        monkeypatch.setenv("WHISPERS_MCP_TOKEN", "token-123")
        monkeypatch.setattr(cli_module, "_check_server_health", lambda: {"db_path": str(server_db)})
        monkeypatch.setattr(cli_module, "_check_mcp_handshake", lambda token: 13)
        monkeypatch.setattr(
            cli_module,
            "_PLATFORMS",
            {
                "codex": {
                    "config": str(codex_config),
                    "config_format": "toml",
                    "config_key": "mcp_servers",
                    "default_agent": "codex",
                    "display_name": "Codex CLI",
                }
            }
        )

        runner = CliRunner()
        result = runner.invoke(cli_module.cli, ["doctor", "--agent-name", "codex"])

        assert result.exit_code == 0
        payload = json.loads(result.output)
        assert payload["db_exists"] is False
        assert payload["server_running"] is True
        assert payload["server_db_path"] == str(server_db)
        assert payload["server_db_matches_local"] is False
        assert payload["mcp_healthy"] is True
        assert payload["clients"]["codex"]["configured"] is True
        assert any("Server is using" in issue for issue in payload["issues"])
    finally:
        shutil.rmtree(case_dir, ignore_errors=True)


def test_doctor_opens_readonly_db_in_read_only_mode(monkeypatch):
    case_dir = _make_case_dir()
    local_db = case_dir / "local.db"
    codex_config = case_dir / ".codex" / "config.toml"
    codex_config.parent.mkdir(parents=True, exist_ok=True)
    codex_config.write_text(
        '\n[mcp_servers.whispers]\n'
        'url = "http://127.0.0.1:8752/mcp/?agent=codex"\n'
        'bearer_token_env_var = "WHISPERS_MCP_TOKEN"\n',
        encoding="utf-8",
    )

    try:
        WhispersDB(str(local_db))

        monkeypatch.chdir(case_dir)
        monkeypatch.setenv("WHISPERS_DB_PATH", str(local_db))
        monkeypatch.setattr(
            cli_module,
            "_inspect_db_state",
            lambda path: {
                "db_exists": True,
                "db_writable": False,
                "schema_version": 2,
                "schema_current": True,
                "wal_mode": True,
                "legacy_schema_detected": False,
                "open_error": None,
                "write_error": "attempt to write a readonly database",
            },
        )
        monkeypatch.setattr(cli_module, "_check_server_health", lambda: None)
        monkeypatch.setattr(cli_module, "_check_mcp_handshake", lambda token: None)
        monkeypatch.setattr(
            cli_module,
            "_PLATFORMS",
            {
                "codex": {
                    "config": str(codex_config),
                    "config_format": "toml",
                    "config_key": "mcp_servers",
                    "default_agent": "codex",
                    "display_name": "Codex CLI",
                }
            }
        )

        opened_modes = []
        original_db = db_module.WhispersDB

        class _SpyDB(original_db):
            def __init__(self, db_path=None, auto_repair=False, read_only=False, on_message_transition=None):
                opened_modes.append(read_only)
                super().__init__(
                    db_path,
                    auto_repair=auto_repair,
                    read_only=read_only,
                    on_message_transition=on_message_transition,
                )

        monkeypatch.setattr(db_module, "WhispersDB", _SpyDB)

        runner = CliRunner()
        result = runner.invoke(cli_module.cli, ["doctor", "--agent-name", "codex"])

        assert result.exit_code == 0
        payload = json.loads(result.output)
        assert any("Database not writable" in issue for issue in payload["issues"])
        assert True in opened_modes
    finally:
        shutil.rmtree(case_dir, ignore_errors=True)


def test_doctor_marks_local_client_auth_healthy_when_probe_passes(monkeypatch):
    case_dir = _make_case_dir()
    local_db = case_dir / "local.db"

    try:
        WhispersClient("codex", db_path=str(local_db))

        monkeypatch.chdir(case_dir)
        monkeypatch.setenv("WHISPERS_DB_PATH", str(local_db))
        monkeypatch.setenv("WHISPERS_MCP_TOKEN", "token-123")
        monkeypatch.setattr(cli_module, "_PLATFORMS", {})
        monkeypatch.setattr(cli_module, "_check_server_health", lambda: {"db_path": str(local_db)})
        monkeypatch.setattr(cli_module, "_check_mcp_handshake", lambda token: 13)
        monkeypatch.setattr(
            cli_module,
            "_probe_local_client_auth",
            lambda agent_name: {"ok": True, "source": "agent_token"},
        )

        runner = CliRunner()
        result = runner.invoke(cli_module.cli, ["doctor", "--agent-name", "codex"])

        assert result.exit_code == 0
        payload = json.loads(result.output)
        assert payload["overall"] == "PASS"
        assert payload["server_state"] == "up"
        assert payload["mcp_healthy"] is True
        assert payload["local_client_auth_healthy"] is True
        assert payload["local_client_token_source"] == "agent_token"
        assert "local_client_auth" not in payload["server_diagnostics"]["failing_checks"]
    finally:
        shutil.rmtree(case_dir, ignore_errors=True)


def test_doctor_reports_local_client_auth_gap_when_startup_surfaces_fail(monkeypatch):
    case_dir = _make_case_dir()
    local_db = case_dir / "local.db"

    try:
        WhispersClient("codex", db_path=str(local_db))

        monkeypatch.chdir(case_dir)
        monkeypatch.setenv("WHISPERS_DB_PATH", str(local_db))
        monkeypatch.setenv("WHISPERS_MCP_TOKEN", "token-123")
        monkeypatch.setattr(cli_module, "_PLATFORMS", {})
        monkeypatch.setattr(cli_module, "_check_server_health", lambda: {"db_path": str(local_db)})
        monkeypatch.setattr(cli_module, "_check_mcp_handshake", lambda token: 13)
        monkeypatch.setattr(
            cli_module,
            "_probe_local_client_auth",
            lambda agent_name: {
                "ok": False,
                "source": "mcp_token",
                "issue": cli_module._remote_client_auth_hint(
                    agent_name,
                    surface="Startup/client surfaces",
                ),
            },
        )

        runner = CliRunner()
        result = runner.invoke(cli_module.cli, ["doctor", "--agent-name", "codex"])

        assert result.exit_code == 0
        payload = json.loads(result.output)
        assert payload["overall"] == "FAIL"
        assert payload["server_state"] == "degraded"
        assert payload["mcp_healthy"] is True
        assert payload["local_client_auth_healthy"] is False
        assert payload["local_client_token_source"] == "mcp_token"
        assert any("Startup/client surfaces auth failed for codex" in issue for issue in payload["issues"])
        assert "local_client_auth" in payload["server_diagnostics"]["failing_checks"]
    finally:
        shutil.rmtree(case_dir, ignore_errors=True)


def test_listener_daemon_start_status_stop(monkeypatch):
    case_dir = _make_case_dir()
    profiles_path = case_dir / "profiles.json"
    credentials_path = case_dir / "credentials.json"
    listener_state_dir = case_dir / "listeners"

    try:
        monkeypatch.setenv("WHISPERS_PROFILES_PATH", str(profiles_path))
        monkeypatch.setenv("WHISPERS_CREDENTIALS_PATH", str(credentials_path))
        monkeypatch.setenv("WHISPERS_LISTENER_STATE_DIR", str(listener_state_dir))

        profiles_path.write_text(
            json.dumps(
                {
                    "profiles": {
                        "work": {
                            "server": "http://mesh.example",
                            "agent_name": "codex",
                            "listener_policy": {
                                "mode": "auto_ack_processed",
                                "auto_ack_detail": "done",
                            },
                        }
                    }
                }
            ),
            encoding="utf-8",
        )
        credentials_path.write_text(
            json.dumps({"profiles": {"work": {"agent_name": "codex", "token": "secret-token"}}}),
            encoding="utf-8",
        )

        started = {}
        running = {4242: True}
        killed = []
        disconnects = []

        class _FakeProcess:
            pid = 4242

        def _fake_popen(command, stdout=None, stderr=None, creationflags=0):
            started["command"] = command
            started["creationflags"] = creationflags
            return _FakeProcess()

        def _fake_running(pid):
            return bool(pid and running.get(int(pid), False))

        def _fake_kill(pid, sig):
            killed.append((pid, sig))
            running[int(pid)] = False

        monkeypatch.setattr(cli_module.subprocess, "Popen", _fake_popen)
        monkeypatch.setattr(cli_module, "_listener_process_running", _fake_running)
        monkeypatch.setattr(cli_module.os, "kill", _fake_kill)
        monkeypatch.setattr(
            cli_module,
            "_server_request",
            lambda server, path, **kwargs: disconnects.append((server, path, kwargs)) or {"ok": True},
        )

        runner = CliRunner()

        started_result = runner.invoke(cli_module.cli, ["listener", "start", "--profile", "work"])
        assert started_result.exit_code == 0
        started_payload = json.loads(started_result.output)
        assert started_payload["agent_name"] == "codex"
        assert started_payload["profile_name"] == "work"
        assert started_payload["running"] is True
        assert started_payload["policy"]["mode"] == "auto_ack_processed"
        assert started_payload["policy"]["auto_ack_state"] == "processed"
        assert "--profile" in started["command"]
        assert "--token" not in started["command"]

        status_result = runner.invoke(cli_module.cli, ["listener", "status", "--profile", "work"])
        assert status_result.exit_code == 0
        status_payload = json.loads(status_result.output)
        assert status_payload["running"] is True
        assert status_payload["pid"] == 4242

        stopped_result = runner.invoke(cli_module.cli, ["listener", "stop", "--profile", "work"])
        assert stopped_result.exit_code == 0
        stopped_payload = json.loads(stopped_result.output)
        assert stopped_payload["running"] is False
        assert stopped_payload["pid"] is None
        assert killed == [(4242, cli_module.signal.SIGTERM)]
        assert disconnects and disconnects[0][0] == "http://mesh.example"
        assert disconnects[0][1] == "/disconnect"
    finally:
        shutil.rmtree(case_dir, ignore_errors=True)


def test_listener_process_running_uses_tasklist_on_windows(monkeypatch):
    class _Result:
        def __init__(self, stdout):
            self.stdout = stdout

    monkeypatch.setattr(cli_module.sys, "platform", "win32")
    monkeypatch.setattr(
        cli_module.subprocess,
        "run",
        lambda *args, **kwargs: _Result('"python.exe","1234","Console","1","12,000 K"\n'),
    )

    assert cli_module._listener_process_running(1234) is True

    monkeypatch.setattr(
        cli_module.subprocess,
        "run",
        lambda *args, **kwargs: _Result("INFO: No tasks are running which match the specified criteria.\n"),
    )

    assert cli_module._listener_process_running(9999) is False


def test_listener_stop_revokes_local_listener_session(monkeypatch):
    case_dir = _make_case_dir()
    listener_state_dir = case_dir / "listeners"
    db_path = case_dir / "whispers.db"

    try:
        monkeypatch.setenv("WHISPERS_LISTENER_STATE_DIR", str(listener_state_dir))
        monkeypatch.setenv("WHISPERS_DB_PATH", str(db_path))

        db = WhispersDB(str(db_path))
        db.upsert_agent_session(
            "codex",
            "listener-session",
            session_kind="local_listener",
            lease_seconds=30,
            process_id=4242,
            substantive=True,
        )

        cli_module._write_listener_runtime_state(
            {
                "agent_name": "codex",
                "pid": 4242,
                "running": True,
                "started_at": "2026-03-21T00:00:00Z",
            },
            agent_name="codex",
        )

        monkeypatch.setattr(cli_module, "_listener_process_running", lambda pid: bool(pid == 4242))
        monkeypatch.setattr(cli_module.os, "kill", lambda pid, sig: None)

        runner = CliRunner()
        result = runner.invoke(cli_module.cli, ["listener", "stop", "--agent-name", "codex"])
        assert result.exit_code == 0

        with db.get_connection() as conn:
            remaining = conn.execute(
                "SELECT COUNT(*) FROM agent_sessions WHERE agent_name = 'codex' AND lease_expires_at >= CURRENT_TIMESTAMP"
            ).fetchone()[0]
            presence = conn.execute(
                "SELECT status, session_id FROM presence WHERE agent_name = 'codex'"
            ).fetchone()

        assert remaining == 0
        assert presence["status"] == "offline"
        assert presence["session_id"] is None
    finally:
        shutil.rmtree(case_dir, ignore_errors=True)


def test_init_fails_when_running_server_uses_different_db(monkeypatch):
    case_dir = _make_case_dir()
    local_db = case_dir / "local.db"
    server_db = case_dir / "server.db"

    try:
        monkeypatch.chdir(case_dir)
        monkeypatch.setenv("WHISPERS_DB_PATH", str(local_db))
        monkeypatch.setattr(cli_module, "_ensure_server_running", lambda: True)
        monkeypatch.setattr(cli_module, "_check_server_health", lambda: {"db_path": str(server_db)})

        runner = CliRunner()
        result = runner.invoke(cli_module.cli, ["init", "--agent-name", "codex"])

        assert result.exit_code == 0
        assert "FAILED: running server is using a different database" in result.output
        assert f"Local DB:  {local_db}" in result.output
        assert f"Server DB: {server_db}" in result.output
        assert "Configuring MCP clients" not in result.output
    finally:
        shutil.rmtree(case_dir, ignore_errors=True)


def test_mcp_install_records_manifest_for_configured_target(monkeypatch):
    case_dir = _make_case_dir()
    manifest_path = case_dir / ".whispers" / "install-state.json"
    config_path = case_dir / ".cursor" / "mcp.json"
    local_db = case_dir / ".whispers" / "whispers.db"

    try:
        monkeypatch.chdir(case_dir)
        monkeypatch.setenv("WHISPERS_INSTALL_STATE_PATH", str(manifest_path))
        monkeypatch.setenv("WHISPERS_MCP_TOKEN", "token-123")
        monkeypatch.setenv("WHISPERS_DB_PATH", str(local_db))
        monkeypatch.setattr(cli_module, "_ensure_server_running", lambda: True)
        monkeypatch.setattr(cli_module, "_check_server_health", lambda: {"db_path": str(local_db)})
        monkeypatch.setattr(cli_module, "_check_mcp_handshake", lambda token: 7)
        monkeypatch.setattr(
            cli_module,
            "_PLATFORMS",
            {
                "cursor": {
                    "config": str(config_path),
                    "config_format": "json",
                    "config_key": "mcpServers",
                    "default_agent": "cursor",
                    "display_name": "Cursor",
                }
            },
        )

        runner = CliRunner()
        result = runner.invoke(cli_module.cli, ["mcp-install", "--target", "cursor"])

        assert result.exit_code == 0
        assert "reload your host to activate Whispers tools" in result.output
        state = json.loads(manifest_path.read_text(encoding="utf-8"))
        assert state["targets"]["cursor"]["config_path"] == str(config_path)
        assert state["targets"]["cursor"]["entry_intent"]["identity"] == "cursor"
        assert state["targets"]["cursor"]["entry_intent"]["transport"] == "http"
        assert state["targets"]["cursor"]["token_source"] == "env"

        config = json.loads(config_path.read_text(encoding="utf-8"))
        parsed = urllib.parse.urlparse(config["mcpServers"]["whispers"]["url"])
        query = urllib.parse.parse_qs(parsed.query)
        assert query["agent"] == ["cursor"]
        assert query["jolt_host_kind"] == ["cursor"]
        assert query["jolt_adapter_kind"] == ["native_extension"]
    finally:
        shutil.rmtree(case_dir, ignore_errors=True)


def test_desired_mcp_entry_includes_jolt_args_for_stdio_antigravity():
    entry = cli_module._desired_mcp_entry(
        {
            "default_agent": "antigravity",
            "config_format": "json",
        },
        token="token-123",
        use_stdio=False,
    )

    assert entry["type"] == "stdio"
    assert entry["args"] == [
        "--agent-name",
        "antigravity",
        "--jolt-host-kind",
        "antigravity",
        "--jolt-adapter-kind",
        "native_extension",
    ]


def test_desired_mcp_entry_uses_http_for_codex_by_default():
    entry = cli_module._desired_mcp_entry(
        {
            "default_agent": "codex",
            "config_format": "toml",
        },
        token="token-123",
        use_stdio=False,
    )

    parsed = urllib.parse.urlparse(entry["url"])
    query = urllib.parse.parse_qs(parsed.query)
    assert query["agent"] == ["codex"]
    assert query["jolt_host_kind"] == ["codex_cli"]
    assert query["jolt_adapter_kind"] == ["managed_pty"]
    assert entry["bearer_token_env_var"] == "WHISPERS_MCP_TOKEN"


def test_mcp_install_codex_default_runs_http_preflight(monkeypatch):
    case_dir = _make_case_dir()
    config_path = case_dir / ".codex" / "config.toml"
    manifest_path = case_dir / "install-state.json"
    preflight = {"ensure": 0, "health": 0, "handshake": 0}

    try:
        monkeypatch.chdir(case_dir)
        monkeypatch.setenv("WHISPERS_INSTALL_STATE_PATH", str(manifest_path))
        monkeypatch.setattr(
            cli_module,
            "_ensure_server_running",
            lambda: preflight.__setitem__("ensure", preflight["ensure"] + 1) or True,
        )
        monkeypatch.setattr(
            cli_module,
            "_check_server_health",
            lambda: preflight.__setitem__("health", preflight["health"] + 1) or {"db_path": str(case_dir / "whispers.db")},
        )
        monkeypatch.setattr(
            cli_module,
            "_check_mcp_handshake",
            lambda token: preflight.__setitem__("handshake", preflight["handshake"] + 1) or 13,
        )
        monkeypatch.setattr(
            cli_module,
            "_PLATFORMS",
            {
                "codex": {
                    "config": str(config_path),
                    "config_format": "toml",
                    "config_key": "mcp_servers",
                    "default_agent": "codex",
                    "display_name": "Codex CLI",
                }
            },
        )

        runner = CliRunner()
        result = runner.invoke(cli_module.cli, ["mcp-install", "--target", "codex"])

        assert result.exit_code == 0
        assert preflight == {"ensure": 1, "health": 1, "handshake": 1}
        written = config_path.read_text(encoding="utf-8")
        assert 'url = "http://127.0.0.1:8752/mcp/?agent=codex&jolt_host_kind=codex_cli&jolt_adapter_kind=managed_pty"' in written
        assert 'bearer_token_env_var = "WHISPERS_MCP_TOKEN"' in written
    finally:
        shutil.rmtree(case_dir, ignore_errors=True)


def test_mcp_install_codex_preserves_existing_stdio_without_http_preflight(monkeypatch):
    case_dir = _make_case_dir()
    config_path = case_dir / ".codex" / "config.toml"
    manifest_path = case_dir / "install-state.json"
    config_path.parent.mkdir(parents=True, exist_ok=True)
    config_path.write_text(
        '\n[mcp_servers.whispers]\n'
        'command = "whispers-mcp"\n'
        'args = ["--agent-name", "codex", "--jolt-host-kind", "codex_cli", "--jolt-adapter-kind", "managed_pty"]\n',
        encoding="utf-8",
    )

    try:
        monkeypatch.chdir(case_dir)
        monkeypatch.setenv("WHISPERS_INSTALL_STATE_PATH", str(manifest_path))
        monkeypatch.setattr(
            cli_module,
            "_ensure_server_running",
            lambda: (_ for _ in ()).throw(AssertionError("server preflight should not run")),
        )
        monkeypatch.setattr(
            cli_module,
            "_check_server_health",
            lambda: (_ for _ in ()).throw(AssertionError("server health should not run")),
        )
        monkeypatch.setattr(
            cli_module,
            "_check_mcp_handshake",
            lambda token: (_ for _ in ()).throw(AssertionError("MCP handshake should not run")),
        )
        monkeypatch.setattr(
            cli_module,
            "_PLATFORMS",
            {
                "codex": {
                    "config": str(config_path),
                    "config_format": "toml",
                    "config_key": "mcp_servers",
                    "default_agent": "codex",
                    "display_name": "Codex CLI",
                }
            },
        )

        runner = CliRunner()
        result = runner.invoke(cli_module.cli, ["mcp-install", "--target", "codex"])

        assert result.exit_code == 0
        written = config_path.read_text(encoding="utf-8")
        assert 'command = "whispers-mcp"' in written
        assert '"--agent-name", "codex"' in written
        assert "url =" not in written
    finally:
        shutil.rmtree(case_dir, ignore_errors=True)


def test_doctor_accepts_codex_http_mcp_without_resilience_warning(monkeypatch):
    case_dir = _make_case_dir()
    local_db = case_dir / "local.db"
    codex_config = case_dir / ".codex" / "config.toml"
    codex_config.parent.mkdir(parents=True, exist_ok=True)
    codex_config.write_text(
        '\n[mcp_servers.whispers]\n'
        'url = "http://127.0.0.1:8752/mcp/?agent=codex"\n'
        'bearer_token_env_var = "WHISPERS_MCP_TOKEN"\n',
        encoding="utf-8",
    )

    try:
        monkeypatch.chdir(case_dir)
        monkeypatch.setenv("WHISPERS_DB_PATH", str(local_db))
        monkeypatch.setenv("WHISPERS_MCP_TOKEN", "token-123")
        monkeypatch.setattr(cli_module, "_check_server_health", lambda: {"db_path": str(local_db)})
        monkeypatch.setattr(cli_module, "_check_mcp_handshake", lambda token: 13)
        monkeypatch.setattr(
            cli_module,
            "_PLATFORMS",
            {
                "codex": {
                    "config": str(codex_config),
                    "config_format": "toml",
                    "config_key": "mcp_servers",
                    "default_agent": "codex",
                    "display_name": "Codex CLI",
                }
            },
        )

        runner = CliRunner()
        result = runner.invoke(cli_module.cli, ["doctor", "--agent-name", "codex"])

        assert result.exit_code == 0
        payload = json.loads(result.output)
        assert payload["clients"]["codex"]["transport"] == "http"
        assert "resilience_recommendation" not in payload["clients"]["codex"]
        assert not any("stdio is recommended" in warning for warning in payload["warnings"])
    finally:
        shutil.rmtree(case_dir, ignore_errors=True)


def test_doctor_fix_resyncs_stale_codex_manifest_without_rewriting_host(monkeypatch):
    case_dir = _make_case_dir()
    local_db = case_dir / "local.db"
    manifest_path = case_dir / ".whispers" / "install-state.json"
    codex_config = case_dir / ".codex" / "config.toml"
    codex_config.parent.mkdir(parents=True, exist_ok=True)
    original_config = (
        '\n[mcp_servers.whispers]\n'
        'url = "http://127.0.0.1:8752/mcp/?agent=codex&jolt_host_kind=codex_cli&jolt_adapter_kind=managed_pty"\n'
        'bearer_token_env_var = "WHISPERS_MCP_TOKEN"\n'
    )
    codex_config.write_text(original_config, encoding="utf-8")
    manifest_path.parent.mkdir(parents=True, exist_ok=True)
    manifest_path.write_text(
        json.dumps(
            {
                "version": 1,
                "updated_at": "2026-04-01T00:00:00Z",
                "init": {"agent_name": "codex", "db_path": str(local_db)},
                "targets": {
                    "codex": {
                        "display_name": "Codex CLI",
                        "config_path": str(codex_config),
                        "config_format": "toml",
                        "transport": "stdio",
                        "default_agent": "codex",
                        "entry_intent": {
                            "transport": "stdio",
                            "identity": "codex",
                            "command": "whispers-mcp",
                            "args": [
                                "--agent-name",
                                "codex",
                                "--jolt-host-kind",
                                "codex_cli",
                                "--jolt-adapter-kind",
                                "managed_pty",
                            ],
                        },
                        "token_source": "env",
                        "installed_at": "2026-04-01T00:00:00Z",
                    }
                },
            },
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )
    WhispersDB(str(local_db))

    try:
        monkeypatch.chdir(case_dir)
        monkeypatch.setenv("WHISPERS_DB_PATH", str(local_db))
        monkeypatch.setenv("WHISPERS_INSTALL_STATE_PATH", str(manifest_path))
        monkeypatch.setenv("WHISPERS_MCP_TOKEN", "token-123")
        monkeypatch.setattr(cli_module, "_check_server_health", lambda: {"db_path": str(local_db)})
        monkeypatch.setattr(cli_module, "_check_mcp_handshake", lambda token: 13)
        monkeypatch.setattr(
            cli_module,
            "_probe_local_client_auth",
            lambda agent_name: {"ok": True, "source": "env", "issue": None},
        )
        monkeypatch.setattr(
            cli_module,
            "_inject_mcp_config",
            lambda *args, **kwargs: (_ for _ in ()).throw(AssertionError("host config rewrite should not run")),
        )
        monkeypatch.setattr(
            cli_module,
            "_PLATFORMS",
            {
                "codex": {
                    "config": str(codex_config),
                    "config_format": "toml",
                    "config_key": "mcp_servers",
                    "default_agent": "codex",
                    "display_name": "Codex CLI",
                }
            },
        )

        runner = CliRunner()
        result = runner.invoke(cli_module.cli, ["doctor", "--fix", "--agent-name", "codex"])

        assert result.exit_code == 0
        payload = json.loads(result.output)
        assert "Resynced install manifest for Codex CLI from live MCP config" in payload["fixes_applied"]
        assert payload["clients"]["codex"]["transport"] == "http"
        assert "manifest_drift" not in payload["clients"]["codex"]
        assert not any("install manifest" in warning for warning in payload["warnings"])

        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        codex_target = manifest["targets"]["codex"]
        assert codex_target["transport"] == "http"
        assert codex_target["entry_intent"]["transport"] == "http"
        assert codex_target["entry_intent"]["token_binding"] == "env_var:WHISPERS_MCP_TOKEN"
        assert codex_target["entry_intent"]["url"] == (
            "http://127.0.0.1:8752/mcp/?agent=codex&jolt_host_kind=codex_cli&jolt_adapter_kind=managed_pty"
        )
        assert codex_config.read_text(encoding="utf-8") == original_config
    finally:
        shutil.rmtree(case_dir, ignore_errors=True)


def test_doctor_fix_resyncs_manifest_url_drift_from_live_json_host(monkeypatch):
    case_dir = _make_case_dir()
    local_db = case_dir / "local.db"
    manifest_path = case_dir / ".whispers" / "install-state.json"
    cursor_config = case_dir / ".cursor" / "mcp.json"
    cursor_config.parent.mkdir(parents=True, exist_ok=True)
    original_config = json.dumps(
        {
            "mcpServers": {
                "whispers": {
                    "type": "http",
                    "url": "http://127.0.0.1:8752/mcp/?agent=cursor&jolt_host_kind=cursor&jolt_adapter_kind=native_extension",
                    "headers": {"Authorization": "Bearer token-123"},
                }
            }
        },
        indent=2,
    ) + "\n"
    cursor_config.write_text(original_config, encoding="utf-8")
    manifest_path.parent.mkdir(parents=True, exist_ok=True)
    manifest_path.write_text(
        json.dumps(
            {
                "version": 1,
                "updated_at": "2026-04-01T00:00:00Z",
                "init": {"agent_name": "cursor", "db_path": str(local_db)},
                "targets": {
                    "cursor": {
                        "display_name": "Cursor",
                        "config_path": str(cursor_config),
                        "config_format": "json",
                        "transport": "http",
                        "default_agent": "cursor",
                        "entry_intent": {
                            "transport": "http",
                            "identity": "cursor",
                            "token_binding": "authorization_header",
                            "url": "http://127.0.0.1:8752/mcp/?agent=cursor",
                        },
                        "token_source": "env",
                        "installed_at": "2026-04-01T00:00:00Z",
                    }
                },
            },
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )
    WhispersDB(str(local_db))

    try:
        monkeypatch.chdir(case_dir)
        monkeypatch.setenv("WHISPERS_DB_PATH", str(local_db))
        monkeypatch.setenv("WHISPERS_INSTALL_STATE_PATH", str(manifest_path))
        monkeypatch.setenv("WHISPERS_MCP_TOKEN", "token-123")
        monkeypatch.setattr(cli_module, "_check_server_health", lambda: {"db_path": str(local_db)})
        monkeypatch.setattr(cli_module, "_check_mcp_handshake", lambda token: 13)
        monkeypatch.setattr(
            cli_module,
            "_probe_local_client_auth",
            lambda agent_name: {"ok": True, "source": "env", "issue": None},
        )
        monkeypatch.setattr(
            cli_module,
            "_inject_mcp_config",
            lambda *args, **kwargs: (_ for _ in ()).throw(AssertionError("host config rewrite should not run")),
        )
        monkeypatch.setattr(
            cli_module,
            "_PLATFORMS",
            {
                "cursor": {
                    "config": str(cursor_config),
                    "config_format": "json",
                    "config_key": "mcpServers",
                    "default_agent": "cursor",
                    "display_name": "Cursor",
                }
            },
        )

        runner = CliRunner()
        result = runner.invoke(cli_module.cli, ["doctor", "--fix", "--agent-name", "cursor"])

        assert result.exit_code == 0
        payload = json.loads(result.output)
        assert "Resynced install manifest for Cursor from live MCP config" in payload["fixes_applied"]
        assert "manifest_drift" not in payload["clients"]["cursor"]
        assert not any("install manifest" in warning for warning in payload["warnings"])

        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        cursor_target = manifest["targets"]["cursor"]
        assert cursor_target["entry_intent"]["url"] == (
            "http://127.0.0.1:8752/mcp/?agent=cursor&jolt_host_kind=cursor&jolt_adapter_kind=native_extension"
        )
        assert cursor_target["entry_intent"]["token_binding"] == "authorization_header"
        assert cursor_config.read_text(encoding="utf-8") == original_config
    finally:
        shutil.rmtree(case_dir, ignore_errors=True)


def test_resync_install_state_skips_identity_mismatch(monkeypatch):
    case_dir = _make_case_dir()
    manifest_path = case_dir / ".whispers" / "install-state.json"
    codex_config = case_dir / ".codex" / "config.toml"
    codex_config.parent.mkdir(parents=True, exist_ok=True)
    original_config = (
        '\n[mcp_servers.whispers]\n'
        'url = "http://127.0.0.1:8752/mcp/?agent=wrong-agent&jolt_host_kind=codex_cli&jolt_adapter_kind=managed_pty"\n'
        'bearer_token_env_var = "WHISPERS_MCP_TOKEN"\n'
    )
    codex_config.write_text(original_config, encoding="utf-8")
    manifest_path.parent.mkdir(parents=True, exist_ok=True)
    original_manifest = {
        "version": 1,
        "updated_at": "2026-04-01T00:00:00Z",
        "init": {"agent_name": "codex", "db_path": str(case_dir / "local.db")},
        "targets": {
            "codex": {
                "display_name": "Codex CLI",
                "config_path": str(codex_config),
                "config_format": "toml",
                "transport": "http",
                "default_agent": "codex",
                "entry_intent": {
                    "transport": "http",
                    "identity": "codex",
                    "token_binding": "env_var:WHISPERS_MCP_TOKEN",
                    "url": "http://127.0.0.1:8752/mcp/?agent=codex",
                },
                "token_source": "env",
            }
        },
    }
    manifest_path.write_text(json.dumps(original_manifest, indent=2) + "\n", encoding="utf-8")

    try:
        monkeypatch.chdir(case_dir)
        monkeypatch.setenv("WHISPERS_INSTALL_STATE_PATH", str(manifest_path))
        monkeypatch.setattr(
            cli_module,
            "_PLATFORMS",
            {
                "codex": {
                    "config": str(codex_config),
                    "config_format": "toml",
                    "config_key": "mcp_servers",
                    "default_agent": "codex",
                    "display_name": "Codex CLI",
                }
            },
        )

        report = cli_module._resync_install_state_from_live_configs()

        assert report["updated"] == []
        assert report["skipped"] == [
            {
                "target": "codex",
                "reason": "identity_mismatch",
                "live_identity": "wrong-agent",
                "expected_identity": "codex",
            }
        ]
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        assert manifest["targets"]["codex"]["entry_intent"]["identity"] == "codex"
        assert codex_config.read_text(encoding="utf-8") == original_config
    finally:
        shutil.rmtree(case_dir, ignore_errors=True)


def test_mcp_install_treats_zero_tool_count_as_success(monkeypatch):
    case_dir = _make_case_dir()
    config_path = case_dir / ".cursor" / "mcp.json"
    manifest_path = case_dir / "install-state.json"
    local_db = case_dir / ".whispers" / "whispers.db"

    try:
        monkeypatch.chdir(case_dir)
        monkeypatch.setenv("WHISPERS_INSTALL_STATE_PATH", str(manifest_path))
        monkeypatch.setenv("WHISPERS_MCP_TOKEN", "token-123")
        monkeypatch.setenv("WHISPERS_DB_PATH", str(local_db))
        monkeypatch.setattr(cli_module, "_ensure_server_running", lambda: True)
        monkeypatch.setattr(cli_module, "_check_server_health", lambda: {"db_path": str(local_db)})
        monkeypatch.setattr(cli_module, "_check_mcp_handshake", lambda token: 0)
        monkeypatch.setattr(
            cli_module,
            "_inject_mcp_config",
            lambda target, token, use_stdio=False: {"status": "configured", "config_path": str(config_path)},
        )
        monkeypatch.setattr(
            cli_module,
            "_PLATFORMS",
            {
                "cursor": {
                    "config": str(config_path),
                    "config_format": "json",
                    "config_key": "mcpServers",
                    "default_agent": "cursor",
                    "display_name": "Cursor",
                }
            },
        )

        runner = CliRunner()
        result = runner.invoke(cli_module.cli, ["mcp-install", "--target", "cursor"])

        assert result.exit_code == 0
        assert "MCP handshake OK (0 tools)" in result.output
        assert "writing config anyway" not in result.output
    finally:
        shutil.rmtree(case_dir, ignore_errors=True)


def test_mcp_install_reports_not_ready_probe_detail(monkeypatch):
    case_dir = _make_case_dir()
    config_path = case_dir / ".cursor" / "mcp.json"
    manifest_path = case_dir / "install-state.json"
    local_db = case_dir / ".whispers" / "whispers.db"

    def _fake_handshake(token):
        cli_module._LAST_MCP_HANDSHAKE = {
            "ok": False,
            "status": "not_ready",
            "stage": "initialize",
            "detail": "connection refused",
            "http_status": None,
        }
        return None

    try:
        monkeypatch.chdir(case_dir)
        monkeypatch.setenv("WHISPERS_INSTALL_STATE_PATH", str(manifest_path))
        monkeypatch.setenv("WHISPERS_MCP_TOKEN", "token-123")
        monkeypatch.setenv("WHISPERS_DB_PATH", str(local_db))
        monkeypatch.setattr(cli_module, "_ensure_server_running", lambda: True)
        monkeypatch.setattr(cli_module, "_check_server_health", lambda: {"db_path": str(local_db)})
        monkeypatch.setattr(cli_module, "_check_mcp_handshake", _fake_handshake)
        monkeypatch.setattr(
            cli_module,
            "_inject_mcp_config",
            lambda target, token, use_stdio=False: {"status": "configured", "config_path": str(config_path)},
        )
        monkeypatch.setattr(
            cli_module,
            "_PLATFORMS",
            {
                "cursor": {
                    "config": str(config_path),
                    "config_format": "json",
                    "config_key": "mcpServers",
                    "default_agent": "cursor",
                    "display_name": "Cursor",
                }
            },
        )

        runner = CliRunner()
        result = runner.invoke(cli_module.cli, ["mcp-install", "--target", "cursor"])

        assert result.exit_code == 0
        assert "MCP endpoint is not ready yet or is restarting" in result.output
        assert "wait a few seconds" in result.output.lower()
        assert "writing config anyway" in result.output
    finally:
        shutil.rmtree(case_dir, ignore_errors=True)


def test_check_mcp_handshake_uses_tools_list_probe(monkeypatch):
    responses = iter([
        {
            "ok": True,
            "status": "ok",
            "stage": "tools/list",
            "detail": None,
            "http_status": 200,
            "payload": {"result": {"tools": [{"name": "status"}, {"name": "message_check"}]}},
        },
    ])

    monkeypatch.setattr(cli_module, "_mcp_probe_request", lambda *args, **kwargs: next(responses))

    tool_count = cli_module._check_mcp_handshake("token-123")

    assert tool_count == 2
    assert cli_module._LAST_MCP_HANDSHAKE["ok"] is True
    assert cli_module._LAST_MCP_HANDSHAKE["stage"] == "tools/list"


def test_mcp_probe_request_reports_local_network_stack_error(monkeypatch):
    def fake_urlopen(*args, **kwargs):
        raise OSError("[WinError 10106] The requested service provider could not be loaded or initialized")

    monkeypatch.setattr(cli_module.urllib.request, "urlopen", fake_urlopen)

    probe = cli_module._mcp_probe_request("token-123", 1, "tools/list", {})

    assert probe["ok"] is False
    assert probe["status"] == "local_network_stack_error"
    assert "WinError 10106" in probe["detail"]


def test_check_server_health_uses_live_pid_when_loopback_probe_breaks(monkeypatch):
    def fake_server_request(server, path, **kwargs):
        raise OSError("[WinError 10106] The requested service provider could not be loaded or initialized")

    monkeypatch.setattr(cli_module, "_server_request", fake_server_request)
    monkeypatch.setattr(cli_module, "_read_server_pid", lambda: 32652)
    monkeypatch.setattr(cli_module, "_is_pid_alive", lambda pid: pid == 32652)

    snapshot = cli_module._check_server_health()

    assert snapshot["server_process_alive"] is True
    assert snapshot["server_pid"] == 32652
    assert snapshot["probe_issue_status"] == "local_network_stack_error"
    assert snapshot["http_server_reachable"] is None


def test_doctor_degrades_instead_of_claiming_server_down_when_live_pid_is_inferred(monkeypatch):
    case_dir = _make_case_dir()
    db_path = case_dir / "whispers.db"

    try:
        monkeypatch.chdir(case_dir)
        monkeypatch.setenv("WHISPERS_DB_PATH", str(db_path))
        monkeypatch.setenv("WHISPERS_MCP_TOKEN", "token-123")
        monkeypatch.setattr(
            cli_module,
            "_check_server_health",
            lambda: {
                "healthy": None,
                "http_server_reachable": None,
                "server_process_alive": True,
                "server_pid": 32652,
                "probe_issue": "[WinError 10106] The requested service provider could not be loaded or initialized",
                "probe_issue_status": "local_network_stack_error",
                "db_path": str(db_path),
            },
        )

        def fake_handshake(token):
            cli_module._LAST_MCP_HANDSHAKE = {
                "ok": False,
                "status": "local_network_stack_error",
                "stage": "tools/list",
                "detail": "[WinError 10106] The requested service provider could not be loaded or initialized",
                "http_status": None,
            }
            return None

        monkeypatch.setattr(cli_module, "_check_mcp_handshake", fake_handshake)
        monkeypatch.setattr(cli_module, "_PLATFORMS", {})

        runner = CliRunner()
        result = runner.invoke(cli_module.cli, ["doctor", "--agent-name", "codex"])

        assert result.exit_code == 0
        payload = json.loads(result.output)
        assert payload["server_running"] is True
        assert payload["server_state"] == "degraded"
        assert not any("Server not running" in issue for issue in payload["issues"])
        assert any("loopback" in warning.lower() for warning in payload["warnings"])
        assert "server_reachable" not in payload["server_diagnostics"]["failing_checks"]
    finally:
        shutil.rmtree(case_dir, ignore_errors=True)


def test_doctor_fix_skips_autostart_when_loopback_probe_is_broken(monkeypatch):
    case_dir = _make_case_dir()
    db_path = case_dir / "whispers.db"

    try:
        monkeypatch.chdir(case_dir)
        monkeypatch.setenv("WHISPERS_DB_PATH", str(db_path))
        monkeypatch.setattr(
            cli_module,
            "_check_server_health",
            lambda: None,
        )
        cli_module._LAST_LOCAL_SERVER_PROBE_ISSUE = {
            "status": "local_network_stack_error",
            "stage": "readyz",
            "path": "/readyz",
            "detail": "[WinError 10106] The requested service provider could not be loaded or initialized",
            "winerror": 10106,
        }
        monkeypatch.setattr(
            cli_module,
            "_ensure_server_running",
            lambda: (_ for _ in ()).throw(AssertionError("doctor --fix should not auto-start when loopback probing is broken")),
        )
        monkeypatch.setattr(cli_module, "_PLATFORMS", {})

        runner = CliRunner()
        result = runner.invoke(cli_module.cli, ["doctor", "--fix", "--agent-name", "codex"])

        assert result.exit_code == 0
        payload = json.loads(result.output)
        assert payload["server_state"] == "down"
        assert any("Skipped server auto-start" in issue for issue in payload["issues"])
        assert any("loopback" in warning.lower() for warning in payload["warnings"])
    finally:
        cli_module._LAST_LOCAL_SERVER_PROBE_ISSUE = None
        shutil.rmtree(case_dir, ignore_errors=True)


def test_doctor_reports_legacy_schema_from_live_inspection(monkeypatch):
    case_dir = _make_case_dir()
    legacy_db = case_dir / "legacy.db"

    try:
        monkeypatch.chdir(case_dir)
        monkeypatch.setenv("WHISPERS_DB_PATH", str(legacy_db))
        monkeypatch.setattr(cli_module, "_check_server_health", lambda: None)

        with sqlite3.connect(legacy_db) as conn:
            conn.execute("CREATE TABLE legacy_messages (id INTEGER PRIMARY KEY)")
            conn.commit()

        runner = CliRunner()
        result = runner.invoke(cli_module.cli, ["doctor", "--agent-name", "codex"])

        assert result.exit_code == 0
        payload = json.loads(result.output)
        assert payload["db_exists"] is True
        assert payload["legacy_schema_detected"] is True
        assert any("Legacy or unknown schema detected" in issue for issue in payload["issues"])
        assert payload["server_running"] is False
    finally:
        shutil.rmtree(case_dir, ignore_errors=True)


def test_uninstall_removes_host_config_and_manifest_entry(monkeypatch):
    case_dir = _make_case_dir()
    manifest_path = case_dir / ".whispers" / "install-state.json"
    config_path = case_dir / ".cursor" / "mcp.json"
    config_path.parent.mkdir(parents=True, exist_ok=True)
    config_path.write_text(
        json.dumps(
            {
                "mcpServers": {
                    "whispers": {
                        "type": "http",
                        "url": "http://127.0.0.1:8752/mcp/?agent=cursor",
                        "headers": {"Authorization": "Bearer token-123"},
                    }
                }
            },
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )
    manifest_path.parent.mkdir(parents=True, exist_ok=True)
    manifest_path.write_text(
        json.dumps(
            {
                "version": 1,
                "updated_at": "2026-03-20T00:00:00Z",
                "init": None,
                "targets": {
                    "cursor": {
                        "config_path": str(config_path),
                        "display_name": "Cursor",
                        "entry_intent": {
                            "transport": "http",
                            "identity": "cursor",
                            "token_binding": "authorization_header",
                            "url": "http://127.0.0.1:8752/mcp/?agent=cursor",
                        },
                    }
                },
            },
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )

    try:
        monkeypatch.chdir(case_dir)
        monkeypatch.setenv("WHISPERS_INSTALL_STATE_PATH", str(manifest_path))
        monkeypatch.setattr(
            cli_module,
            "_PLATFORMS",
            {
                "cursor": {
                    "config": str(config_path),
                    "config_format": "json",
                    "config_key": "mcpServers",
                    "default_agent": "cursor",
                    "display_name": "Cursor",
                }
            },
        )

        runner = CliRunner()
        result = runner.invoke(
            cli_module.cli,
            ["uninstall", "--target", "cursor", "--yes", "--keep-credentials", "--keep-db", "--keep-registered"],
        )

        assert result.exit_code == 0
        config = json.loads(config_path.read_text(encoding="utf-8"))
        assert "whispers" not in config["mcpServers"]
        assert manifest_path.exists() is False
        assert "Removed:" in result.output
    finally:
        shutil.rmtree(case_dir, ignore_errors=True)


def test_uninstall_all_attempts_server_stop(monkeypatch):
    case_dir = _make_case_dir()
    manifest_path = case_dir / ".whispers" / "install-state.json"
    config_path = case_dir / ".cursor" / "mcp.json"
    config_path.parent.mkdir(parents=True, exist_ok=True)
    config_path.write_text(
        json.dumps(
            {
                "mcpServers": {
                    "whispers": {
                        "type": "http",
                        "url": "http://127.0.0.1:8752/mcp/?agent=cursor",
                        "headers": {"Authorization": "Bearer token-123"},
                    }
                }
            },
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )
    manifest_path.parent.mkdir(parents=True, exist_ok=True)
    manifest_path.write_text(
        json.dumps(
            {
                "version": 1,
                "updated_at": "2026-03-20T00:00:00Z",
                "init": None,
                "targets": {
                    "cursor": {
                        "config_path": str(config_path),
                        "display_name": "Cursor",
                        "entry_intent": {
                            "transport": "http",
                            "identity": "cursor",
                            "token_binding": "authorization_header",
                            "url": "http://127.0.0.1:8752/mcp/?agent=cursor",
                        },
                    }
                },
            },
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )

    try:
        monkeypatch.chdir(case_dir)
        monkeypatch.setenv("WHISPERS_INSTALL_STATE_PATH", str(manifest_path))
        monkeypatch.setattr(
            cli_module,
            "_PLATFORMS",
            {
                "cursor": {
                    "config": str(config_path),
                    "config_format": "json",
                    "config_key": "mcpServers",
                    "default_agent": "cursor",
                    "display_name": "Cursor",
                }
            },
        )
        monkeypatch.setattr(cli_module, "_stop_local_server", lambda: {"attempted": True, "stopped": True, "warnings": []})

        runner = CliRunner()
        result = runner.invoke(
            cli_module.cli,
            ["uninstall", "--target", "all", "--yes", "--keep-credentials", "--keep-db", "--keep-registered"],
        )

        assert result.exit_code == 0
        assert "local whispers server process" in result.output
    finally:
        shutil.rmtree(case_dir, ignore_errors=True)


def test_send_falls_back_to_local_server_when_db_is_readonly(monkeypatch):
    class _ReadonlyClient:
        def __init__(self, agent_name, *args, **kwargs):
            self.agent_name = agent_name

        def send(self, **kwargs):
            raise RuntimeError("attempt to write a readonly database")

    monkeypatch.setattr(cli_module, "WhispersClient", _ReadonlyClient)
    monkeypatch.setattr(cli_module, "_check_server_health", lambda: {"db_path": "C:/tmp/whispers.db"})
    monkeypatch.setattr(cli_module, "_expected_db_path", lambda: "C:/tmp/whispers.db")
    monkeypatch.setattr(
        cli_module,
        "_send_via_local_server",
        lambda payload: {"status": "queued", "id": "server-fallback-id"},
    )

    runner = CliRunner()
    result = runner.invoke(
        cli_module.cli,
        ["send", "--to", "claude-code", "--subject", "Hello", "--body", "Fallback test", "--from-agent", "codex"],
    )

    assert result.exit_code == 0
    assert "Message queued. ID: server-fallback-id" in result.output


def test_send_passes_reply_to_and_context_id_to_local_client(monkeypatch):
    captured = {}

    class _Client:
        def __init__(self, agent_name, *args, **kwargs):
            self.agent_name = agent_name

        def send(self, **kwargs):
            captured.update(kwargs)
            return {"status": "delivered", "delivery_status": "delivered", "id": "local-send-id"}

    monkeypatch.setattr(cli_module, "WhispersClient", _Client)
    monkeypatch.setattr(cli_module, "_readonly_local_db_fallback_context", lambda: None)

    runner = CliRunner()
    result = runner.invoke(
        cli_module.cli,
        [
            "send",
            "--to",
            "claude-code",
            "--subject",
            "Reply payload",
            "--body",
            "Structured thread reply",
            "--from-agent",
            "codex",
            "--reply-to",
            "message-123",
            "--context-id",
            "thread-456",
        ],
    )

    assert result.exit_code == 0
    assert captured["reply_to"] == "message-123"
    assert captured["context_id"] == "thread-456"
    assert "Message delivered. ID: local-send-id" in result.output


def test_send_reports_queued_but_likely_reachable_when_online_hint_present(monkeypatch):
    class _ReadonlyClient:
        def __init__(self, agent_name, *args, **kwargs):
            self.agent_name = agent_name

        def send(self, **kwargs):
            raise RuntimeError("attempt to write a readonly database")

    monkeypatch.setattr(cli_module, "WhispersClient", _ReadonlyClient)
    monkeypatch.setattr(cli_module, "_check_server_health", lambda: {"db_path": "C:/tmp/whispers.db"})
    monkeypatch.setattr(cli_module, "_expected_db_path", lambda: "C:/tmp/whispers.db")
    monkeypatch.setattr(
        cli_module,
        "_send_via_local_server",
        lambda payload: {
            "status": "delivered",
            "delivery_status": "queued",
            "id": "server-fallback-id",
        },
    )

    runner = CliRunner()
    result = runner.invoke(
        cli_module.cli,
        ["send", "--to", "claude-code", "--subject", "Hello", "--body", "Fallback test", "--from-agent", "codex"],
    )

    assert result.exit_code == 0
    assert "Message queued. ID: server-fallback-id" in result.output


def test_send_prefers_server_preflight_when_local_db_is_readonly(monkeypatch):
    class _ShouldNotConstruct:
        def __init__(self, *args, **kwargs):
            raise AssertionError("local writable client should not be constructed")

    monkeypatch.setattr(cli_module, "WhispersClient", _ShouldNotConstruct)
    monkeypatch.setattr(
        cli_module,
        "_inspect_db_state",
        lambda path: {"db_exists": True, "db_writable": False},
    )
    monkeypatch.setattr(cli_module, "_check_server_health", lambda: {"db_path": "C:/tmp/whispers.db"})
    monkeypatch.setattr(cli_module, "_expected_db_path", lambda: "C:/tmp/whispers.db")
    monkeypatch.setattr(
        cli_module,
        "_send_via_local_server",
        lambda payload: {"status": "queued", "id": "server-preflight-id"},
    )

    runner = CliRunner()
    result = runner.invoke(
        cli_module.cli,
        ["send", "--to", "claude-code", "--subject", "Hello", "--body", "Fallback test", "--from-agent", "codex"],
    )

    assert result.exit_code == 0
    assert "Message queued. ID: server-preflight-id" in result.output


def test_send_server_fallback_preserves_reply_to_and_context_id(monkeypatch):
    class _ShouldNotConstruct:
        def __init__(self, *args, **kwargs):
            raise AssertionError("local writable client should not be constructed")

    captured = {}

    monkeypatch.setattr(cli_module, "WhispersClient", _ShouldNotConstruct)
    monkeypatch.setattr(
        cli_module,
        "_inspect_db_state",
        lambda path: {"db_exists": True, "db_writable": False},
    )
    monkeypatch.setattr(cli_module, "_check_server_health", lambda: {"db_path": "C:/tmp/whispers.db"})
    monkeypatch.setattr(cli_module, "_expected_db_path", lambda: "C:/tmp/whispers.db")

    def fake_send_via_local_server(payload):
        captured.update(payload)
        return {"status": "delivered", "delivery_status": "delivered", "id": "server-reply-id"}

    monkeypatch.setattr(cli_module, "_send_via_local_server", fake_send_via_local_server)

    runner = CliRunner()
    result = runner.invoke(
        cli_module.cli,
        [
            "send",
            "--to",
            "claude-code",
            "--subject",
            "Reply payload",
            "--body",
            "Structured thread reply",
            "--from-agent",
            "codex",
            "--reply-to",
            "message-123",
            "--context-id",
            "thread-456",
        ],
    )

    assert result.exit_code == 0
    assert captured["reply_to"] == "message-123"
    assert captured["context_id"] == "thread-456"
    assert "Message delivered. ID: server-reply-id" in result.output


def test_send_prefers_server_preflight_when_client_probe_fails(monkeypatch):
    class _ShouldNotConstruct:
        def __init__(self, *args, **kwargs):
            raise AssertionError("local writable client should not be constructed")

    monkeypatch.setattr(cli_module, "WhispersClient", _ShouldNotConstruct)
    monkeypatch.setattr(
        cli_module,
        "_inspect_db_state",
        lambda path: {"db_exists": True, "db_writable": True},
    )
    monkeypatch.setattr(
        cli_module,
        "_probe_local_writable_db_client_ready",
        lambda path: (False, "attempt to write a readonly database"),
    )
    monkeypatch.setattr(cli_module, "_check_server_health", lambda: {"db_path": "C:/tmp/whispers.db"})
    monkeypatch.setattr(cli_module, "_expected_db_path", lambda: "C:/tmp/whispers.db")
    monkeypatch.setattr(
        cli_module,
        "_send_via_local_server",
        lambda payload: {"status": "queued", "id": "server-probe-fallback-id"},
    )

    runner = CliRunner()
    result = runner.invoke(
        cli_module.cli,
        ["send", "--to", "claude-code", "--subject", "Hello", "--body", "Fallback test", "--from-agent", "codex"],
    )

    assert result.exit_code == 0
    assert "Message queued. ID: server-probe-fallback-id" in result.output


def test_status_and_outbox_render_local_time(monkeypatch):
    case_dir = _make_case_dir()
    db_path = case_dir / "whispers.db"

    try:
        monkeypatch.chdir(case_dir)
        monkeypatch.setenv("WHISPERS_DB_PATH", str(db_path))
        monkeypatch.setenv("WHISPERS_TIMEZONE", "America/Los_Angeles")

        sender = WhispersClient("agent_a", db_path=str(db_path))
        receiver = WhispersClient("agent_b", db_path=str(db_path))
        sender.send("agent_b", "Hello local time")
        receiver.check_inbox(limit=10, mark_seen=True)

        runner = CliRunner()
        status_result = runner.invoke(cli_module.cli, ["status"])
        outbox_result = runner.invoke(cli_module.cli, ["outbox", "--from-agent", "agent_a"])

        assert status_result.exit_code == 0
        assert "Display TZ: America/Los_Angeles" in status_result.output
        assert "Local Time:" in status_result.output
        assert "PDT" in status_result.output or "PST" in status_result.output

        assert outbox_result.exit_code == 0
        assert "PDT" in outbox_result.output or "PST" in outbox_result.output
        assert "read" in outbox_result.output
    finally:
        shutil.rmtree(case_dir, ignore_errors=True)


def test_outbox_json_output_includes_delivery_snapshot(monkeypatch):
    case_dir = _make_case_dir()
    db_path = case_dir / "whispers.db"

    try:
        monkeypatch.chdir(case_dir)
        monkeypatch.setenv("WHISPERS_DB_PATH", str(db_path))

        sender = WhispersClient("agent_a", db_path=str(db_path))
        WhispersClient("agent_b", db_path=str(db_path))
        sender.send("agent_b", "Outbox json")

        runner = CliRunner()
        result = runner.invoke(
            cli_module.cli,
            ["outbox", "--from-agent", "agent_a", "--json-output"],
        )

        assert result.exit_code == 0
        payload = json.loads(result.output)
        assert payload["agent_name"] == "agent_a"
        assert payload["state"] == "messages"
        assert payload["message_count"] == 1
        assert payload["messages"][0]["to_agent"] == "agent_b"
        assert payload["messages"][0]["subject"] == "Outbox json"
        assert payload["messages"][0]["delivery_status"] in {"queued", "delivered", "unclaimed"}
    finally:
        shutil.rmtree(case_dir, ignore_errors=True)


def test_status_uses_install_state_identity_for_pending_messages(monkeypatch):
    case_dir = _make_case_dir()
    db_path = case_dir / "whispers.db"
    install_state_path = case_dir / ".whispers" / "install-state.json"
    install_state_path.parent.mkdir(parents=True, exist_ok=True)
    install_state_path.write_text(
        json.dumps(
            {
                "version": 1,
                "updated_at": "2026-03-30T00:00:00Z",
                "init": {"agent_name": "codex", "db_path": str(db_path)},
                "targets": {},
            }
        ),
        encoding="utf-8",
    )

    try:
        monkeypatch.chdir(case_dir)
        monkeypatch.setenv("WHISPERS_DB_PATH", str(db_path))
        monkeypatch.setenv("WHISPERS_INSTALL_STATE_PATH", str(install_state_path))

        sender = WhispersClient("claude-code", db_path=str(db_path))
        WhispersClient("codex", db_path=str(db_path))
        sender.send("codex", "Unread for codex")

        runner = CliRunner()
        result = runner.invoke(cli_module.cli, ["status"])

        assert result.exit_code == 0
        assert "Pending Messages: 1" in result.output
    finally:
        shutil.rmtree(case_dir, ignore_errors=True)


def test_status_counts_delivered_unread_messages_for_install_state_identity(monkeypatch):
    case_dir = _make_case_dir()
    db_path = case_dir / "whispers.db"
    install_state_path = case_dir / ".whispers" / "install-state.json"
    install_state_path.parent.mkdir(parents=True, exist_ok=True)
    install_state_path.write_text(
        json.dumps(
            {
                "version": 1,
                "updated_at": "2026-03-30T00:00:00Z",
                "init": {"agent_name": "codex", "db_path": str(db_path)},
                "targets": {},
            }
        ),
        encoding="utf-8",
    )

    try:
        monkeypatch.chdir(case_dir)
        monkeypatch.setenv("WHISPERS_DB_PATH", str(db_path))
        monkeypatch.setenv("WHISPERS_INSTALL_STATE_PATH", str(install_state_path))

        sender = WhispersClient("claude-code", db_path=str(db_path))
        sender.registry.register("codex")
        token = sender.db.issue_api_token("codex", description="status-delivered-pending")
        session = sender.db.create_remote_session("codex", token, lease_seconds=300)
        sender.db.mark_agent_online("codex", session["session_id"])
        sender.send("codex", "Delivered unread for codex")

        runner = CliRunner()
        result = runner.invoke(cli_module.cli, ["status"])

        assert result.exit_code == 0
        assert "Pending Messages: 1" in result.output
    finally:
        shutil.rmtree(case_dir, ignore_errors=True)


def test_status_agent_name_override_beats_install_state(monkeypatch):
    case_dir = _make_case_dir()
    db_path = case_dir / "whispers.db"
    install_state_path = case_dir / ".whispers" / "install-state.json"
    install_state_path.parent.mkdir(parents=True, exist_ok=True)
    install_state_path.write_text(
        json.dumps(
            {
                "version": 1,
                "updated_at": "2026-03-30T00:00:00Z",
                "init": {"agent_name": "codex", "db_path": str(db_path)},
                "targets": {},
            }
        ),
        encoding="utf-8",
    )

    try:
        monkeypatch.chdir(case_dir)
        monkeypatch.setenv("WHISPERS_DB_PATH", str(db_path))
        monkeypatch.setenv("WHISPERS_INSTALL_STATE_PATH", str(install_state_path))

        sender = WhispersClient("claude-code", db_path=str(db_path))
        WhispersClient("codex", db_path=str(db_path))
        WhispersClient("antigravity", db_path=str(db_path))
        sender.send("antigravity", "Unread for antigravity")

        runner = CliRunner()
        result = runner.invoke(cli_module.cli, ["status", "--agent-name", "antigravity"])

        assert result.exit_code == 0
        assert "Pending Messages: 1" in result.output
    finally:
        shutil.rmtree(case_dir, ignore_errors=True)


def test_status_prefers_codex_runtime_env_when_install_state_is_ambiguous(monkeypatch):
    case_dir = _make_case_dir()
    db_path = case_dir / "whispers.db"
    install_state_path = case_dir / ".whispers" / "install-state.json"
    install_state_path.parent.mkdir(parents=True, exist_ok=True)
    install_state_path.write_text(
        json.dumps(
            {
                "version": 1,
                "updated_at": "2026-03-30T00:00:00Z",
                "init": {"agent_name": None, "db_path": None},
                "targets": {
                    "codex": {"default_agent": "codex"},
                    "claude": {"default_agent": "claude-code"},
                },
            }
        ),
        encoding="utf-8",
    )

    try:
        monkeypatch.chdir(case_dir)
        monkeypatch.setenv("WHISPERS_DB_PATH", str(db_path))
        monkeypatch.setenv("WHISPERS_INSTALL_STATE_PATH", str(install_state_path))
        monkeypatch.setenv("CODEX_THREAD_ID", "thread-123")

        sender = WhispersClient("claude-code", db_path=str(db_path))
        WhispersClient("codex", db_path=str(db_path))
        sender.send("codex", "Unread for codex via runtime hint")

        runner = CliRunner()
        result = runner.invoke(cli_module.cli, ["status"])

        assert result.exit_code == 0
        assert "Pending Messages: 1" in result.output
    finally:
        shutil.rmtree(case_dir, ignore_errors=True)


def test_status_and_who_render_manual_wake_bridge_with_jolt_suffix(monkeypatch):
    case_dir = _make_case_dir()
    db_path = case_dir / "whispers.db"

    try:
        monkeypatch.chdir(case_dir)
        monkeypatch.setenv("WHISPERS_DB_PATH", str(db_path))

        codex = WhispersClient("codex", db_path=str(db_path), agent_type="remote_client")
        claude = WhispersClient(
            "claude-code",
            db_path=str(db_path),
            agent_type="mcp_server",
            jolt_host_kind="claude_code",
            jolt_adapter_kind="managed_pty",
            jolt_can_stage_context=True,
            jolt_can_trigger_inference=True,
        )
        codex.set_readiness("ready")
        claude.set_readiness("ready")

        monkeypatch.setattr(cli_module, "_check_server_health", lambda: {"db_path": str(db_path)})

        runner = CliRunner()
        status_result = runner.invoke(cli_module.cli, ["status", "--agent-name", "codex"])
        who_result = runner.invoke(cli_module.cli, ["who"])

        assert status_result.exit_code == 0
        assert who_result.exit_code == 0
        assert "claude-code: ready [MANUAL-WAKE+JOLT]" in status_result.output
        assert "claude-code [mcp_server] [MANUAL-WAKE+JOLT]" in who_result.output
    finally:
        shutil.rmtree(case_dir, ignore_errors=True)


def test_status_surfaces_local_client_auth_gap(monkeypatch):
    case_dir = _make_case_dir()
    db_path = case_dir / "whispers.db"

    try:
        monkeypatch.chdir(case_dir)
        monkeypatch.setenv("WHISPERS_DB_PATH", str(db_path))

        WhispersClient("codex", db_path=str(db_path))
        monkeypatch.setattr(cli_module, "_check_server_health", lambda: {"db_path": str(db_path)})
        monkeypatch.setattr(
            cli_module,
            "_probe_local_client_auth",
            lambda agent_name: {
                "ok": False,
                "source": "mcp_token",
                "issue": cli_module._remote_client_auth_hint(
                    agent_name,
                    surface="Startup/client surfaces",
                ),
            },
        )

        runner = CliRunner()
        result = runner.invoke(cli_module.cli, ["status", "--agent-name", "codex"])

        assert result.exit_code == 0
        assert "Startup/Client Auth: DEGRADED (mcp_token)" in result.output
        assert "Startup/client surfaces auth failed for codex" in result.output
    finally:
        shutil.rmtree(case_dir, ignore_errors=True)


def test_status_surfaces_follow_through_lines_from_connection_story(monkeypatch):
    case_dir = _make_case_dir()
    db_path = case_dir / "whispers.db"

    try:
        monkeypatch.chdir(case_dir)
        monkeypatch.setenv("WHISPERS_DB_PATH", str(db_path))

        WhispersClient("codex", db_path=str(db_path))
        story = ConnectionStory(
            agent_name="codex",
            active_reply_alerts=[
                ActiveReplyAlert(
                    message_id="msg-hot",
                    counterpart="claude-code",
                    subject="Re: phase 3 state truth",
                )
            ],
            recommended_action="Open hot reply from claude-code -- Re: phase 3 state truth.",
        )
        monkeypatch.setattr(
            cli_module.WhispersClient,
            "get_connection_story",
            lambda self, status_snapshot=None: story,
        )

        runner = CliRunner()
        result = runner.invoke(cli_module.cli, ["status", "--agent-name", "codex"])

        assert result.exit_code == 0
        assert "Hot reply: claude-code responded | Re: phase 3 state truth" in result.output
        assert "Suggested next action: Open hot reply from claude-code" in result.output
    finally:
        shutil.rmtree(case_dir, ignore_errors=True)


def test_status_json_output_includes_startup_follow_through_lines(monkeypatch):
    case_dir = _make_case_dir()
    db_path = case_dir / "whispers.db"

    try:
        monkeypatch.chdir(case_dir)
        monkeypatch.setenv("WHISPERS_DB_PATH", str(db_path))

        WhispersClient("codex", db_path=str(db_path))
        story = ConnectionStory(
            agent_name="codex",
            active_reply_alerts=[
                ActiveReplyAlert(
                    message_id="msg-hot",
                    counterpart="claude-code",
                    subject="Re: phase 3 state truth",
                )
            ],
            recommended_action="Open hot reply from claude-code -- Re: phase 3 state truth.",
        )
        monkeypatch.setattr(
            cli_module.WhispersClient,
            "get_connection_story",
            lambda self, status_snapshot=None: story,
        )

        runner = CliRunner()
        result = runner.invoke(cli_module.cli, ["status", "--agent-name", "codex", "--json-output"])

        assert result.exit_code == 0
        payload = json.loads(result.output)
        assert payload["startup"]["agent_name"] == "codex"
        assert "Hot reply: claude-code responded | Re: phase 3 state truth" in payload["status_follow_through_lines"]
        assert any(
            line.startswith("Suggested next action: Open hot reply from claude-code")
            for line in payload["status_follow_through_lines"]
        )
    finally:
        shutil.rmtree(case_dir, ignore_errors=True)


def test_status_json_output_includes_local_client_auth_gap(monkeypatch):
    case_dir = _make_case_dir()
    db_path = case_dir / "whispers.db"

    try:
        monkeypatch.chdir(case_dir)
        monkeypatch.setenv("WHISPERS_DB_PATH", str(db_path))

        WhispersClient("codex", db_path=str(db_path))
        monkeypatch.setattr(cli_module, "_check_server_health", lambda: {"db_path": str(db_path)})
        monkeypatch.setattr(
            cli_module,
            "_probe_local_client_auth",
            lambda agent_name: {
                "ok": False,
                "source": "mcp_token",
                "issue": cli_module._remote_client_auth_hint(
                    agent_name,
                    surface="Startup/client surfaces",
                ),
            },
        )

        runner = CliRunner()
        result = runner.invoke(cli_module.cli, ["status", "--agent-name", "codex", "--json-output"])

        assert result.exit_code == 0
        payload = json.loads(result.output)
        assert payload["local_client_auth_healthy"] is False
        assert payload["local_client_token_source"] == "mcp_token"
        assert payload["startup"]["local_client_auth_healthy"] is False
        assert "Startup/client surfaces auth failed for codex" in payload["startup"]["detail_block"]
    finally:
        shutil.rmtree(case_dir, ignore_errors=True)


def test_checkpoint_blocks_peer_owned_branch(monkeypatch):
    class Result:
        def __init__(self, stdout="", stderr="", returncode=0):
            self.stdout = stdout
            self.stderr = stderr
            self.returncode = returncode

    def fake_run(args, cwd=None, capture_output=None, text=None, check=None):
        if args[:3] == ["git", "rev-parse", "--show-toplevel"]:
            return Result(stdout="C:/repo\n")
        if args[:4] == ["git", "rev-parse", "--abbrev-ref", "HEAD"]:
            return Result(stdout="antigravity/fix-thing\n")
        raise AssertionError(f"Unexpected subprocess call: {args}")

    monkeypatch.setattr(cli_module.subprocess, "run", fake_run)

    runner = CliRunner()
    result = runner.invoke(cli_module.cli, ["checkpoint", "-m", "test"])

    assert result.exit_code != 0
    assert "peer-owned branch" in result.output


def test_checkpoint_rejects_untracked_only_dirty_tree_without_include_untracked(monkeypatch):
    class Result:
        def __init__(self, stdout="", stderr="", returncode=0):
            self.stdout = stdout
            self.stderr = stderr
            self.returncode = returncode

    def fake_run(args, cwd=None, capture_output=None, text=None, check=None):
        if args[:3] == ["git", "rev-parse", "--show-toplevel"]:
            return Result(stdout="C:/repo\n")
        if args[:4] == ["git", "rev-parse", "--abbrev-ref", "HEAD"]:
            return Result(stdout="codex/reliability-truth\n")
        if args == ["git", "diff", "--cached", "--name-only"]:
            return Result(stdout="")
        if args == ["git", "diff", "--name-only"]:
            return Result(stdout="")
        if args == ["git", "ls-files", "--others", "--exclude-standard"]:
            return Result(stdout="tests/test_unread_parity.py\n")
        raise AssertionError(f"Unexpected subprocess call: {args}")

    monkeypatch.setattr(cli_module.subprocess, "run", fake_run)

    runner = CliRunner()
    result = runner.invoke(cli_module.cli, ["checkpoint", "-m", "test"])

    assert result.exit_code != 0
    assert "Only untracked files remain" in result.output


def test_status_renders_jolt_adapter_line(monkeypatch):
    class FakeClient:
        def __init__(self, *args, **kwargs):
            pass

        def status(self):
            return {
                "healthy": True,
                "deployment_mode": "embedded",
                "now_utc": "2026-03-30T12:00:00Z",
                "display_timezone": "America/Los_Angeles",
                "my_mode": "OPEN",
                "schema_version": 1,
                "primary_participants_registered": 0,
                "secondary_participants_registered": 0,
                "participant_counts": {},
                "agents_registered": 0,
                "agents_online": [],
                "pending_messages": 0,
                "jolt_adapter": {
                    "host_kind": "zmaia",
                    "adapter_kind": "managed_pty",
                    "supported_actions": ["notify", "stage_context"],
                    "fallback_action": "stage_context",
                    "state": "degraded",
                    "detail": "missing infer",
                },
            }

    monkeypatch.setattr(cli_module, "WhispersClient", FakeClient)

    runner = CliRunner()
    result = runner.invoke(cli_module.cli, ["status"])

    assert result.exit_code == 0
    assert "Jolt Adapter: zmaia via managed_pty" in result.output
    assert "fallback stage context" in result.output
    assert "missing infer" in result.output


def test_build_jolt_notification_prefers_recommended_action():
    notification = cli_module._build_jolt_notification(
        {
            "action": "notify",
            "headline": "Hot reply from antigravity",
            "trigger": "hot_thread",
            "recommended_action": "Open hot collaborator replies.",
            "reasons": ["manual-wake host falls back to notification only"],
        },
        agent_name="codex",
    )

    assert notification == (
        "Hot reply from antigravity",
        "Open hot collaborator replies. | Why: manual-wake host falls back to notification only",
    )


def test_build_jolt_notification_marks_requested_stage_context():
    notification = cli_module._build_jolt_notification(
        {
            "action": "stage_context",
            "headline": "1 assignment waiting",
            "trigger": "direct_assignment",
            "reasons": ["host can stage context"],
        },
        agent_name="codex",
    )

    assert notification == (
        "1 assignment waiting",
        "Trigger: direct assignment | Why: host can stage context | Requested action: stage context",
    )


def test_build_jolt_notification_marks_stale_hot_thread():
    notification = cli_module._build_jolt_notification(
        {
            "action": "notify",
            "headline": "Hot reply from antigravity",
            "trigger": "hot_thread",
            "recommended_action": "Open hot collaborator replies.",
            "freshness": "stale",
            "age_label": "6m",
            "source_stage": "reply_ready",
            "stale_after_seconds": 240,
            "reasons": ["manual-wake host falls back to notification only"],
        },
        agent_name="codex",
    )

    assert notification == (
        "Hot reply from antigravity",
        "Open hot collaborator replies. | Wake freshness: stale (reply ready, 6m old, target <= 4m) | Why: manual-wake host falls back to notification only",
    )


def test_should_emit_jolt_notification_suppresses_stale_hot_thread():
    assert cli_module._should_emit_jolt_notification(
        {
            "trigger": "hot_thread",
            "freshness": "stale",
        }
    ) is False
    assert cli_module._should_emit_jolt_notification(
        {
            "trigger": "direct_assignment",
            "freshness": "stale",
        }
    ) is True


def test_jolt_packet_signature_changes_when_packet_payload_changes():
    packet = {
        "action": "notify",
        "trigger": "hot_thread",
        "headline": "Hot reply from antigravity",
        "priority": "priority",
        "recommended_action": "Open hot collaborator replies.",
        "freshness": "fresh",
        "age_label": "30s",
        "source_stage": "reply_ready",
        "stale_after_seconds": 240,
        "reasons": ["manual-wake host falls back to notification only"],
        "adapter": {
            "adapter_kind": "notify_only",
            "supported_actions": ["notify"],
        },
        "fallback_used": True,
    }

    baseline = cli_module._jolt_packet_signature(packet)
    changed = cli_module._jolt_packet_signature(
        {
            **packet,
            "freshness": "stale",
        }
    )

    assert baseline is not None
    assert changed is not None
    assert changed != baseline


def test_infer_terminal_jolt_host_kind_prefers_known_cli_hosts():
    assert cli_module._infer_terminal_jolt_host_kind("claude-code") == "claude_code"
    assert cli_module._infer_terminal_jolt_host_kind("codex") == "codex_cli"
    assert cli_module._infer_terminal_jolt_host_kind("oddball-shell") == "plain_terminal"


def test_build_terminal_jolt_lines_include_stage_context_summary():
    lines = cli_module._build_terminal_jolt_lines(
        {
            "action": "stage_context",
            "headline": "1 assignment waiting",
            "trigger": "direct_assignment",
            "priority": "priority",
            "recommended_action": "Open the assignment queue.",
            "reasons": ["host can stage context"],
        },
        status_snapshot={
            "my_mode": "OPEN",
            "readiness": "ready",
            "pending_messages": 2,
            "pending_assignments": 1,
            "pending_review_requests": 0,
            "connection_story": {
                "recommended_action": "Pick up the assignment queue.",
                "huddle_peers": [
                    {"callsign": "antigravity", "reasons": ["shared workspace"]},
                    {"callsign": "claude-code", "working_on": "review waiting"},
                ],
            },
        },
        agent_name="claude-code",
    )

    assert lines == [
        "JOLT STAGE CONTEXT | 1 assignment waiting",
        "Signal: trigger direct assignment | priority priority",
        "Next: Open the assignment queue.",
        "Why: host can stage context",
        "Context: mode OPEN | readiness ready | 2 pending messages | 1 assignments | 0 reviews",
        "Peers: antigravity (shared workspace); claude-code (review waiting)",
        "Story: Pick up the assignment queue.",
    ]


def test_jolt_terminal_once_emits_stage_context_block(monkeypatch):
    class FakeClient:
        def status(self):
            return {
                "jolt_packet": {
                    "action": "stage_context",
                    "headline": "1 assignment waiting",
                    "trigger": "direct_assignment",
                    "recommended_action": "Open the assignment queue.",
                    "reasons": ["host can stage context"],
                },
                "connection_story": {
                    "signal_mode": "OPEN",
                    "readiness": "ready",
                    "pending_messages": 2,
                    "pending_assignments": 1,
                    "pending_review_requests": 0,
                    "recommended_action": "Pick up the assignment queue.",
                    "huddle_peers": [
                        {"callsign": "antigravity", "reasons": ["shared workspace"]},
                    ],
                },
            }

    monkeypatch.setattr(
        cli_module,
        "_build_terminal_jolt_client",
        lambda **kwargs: (FakeClient(), False),
    )
    monkeypatch.setattr(
        cli_module,
        "_load_credentials",
        lambda: {"profiles": {"default": {"token": "secret-token"}}},
    )

    runner = CliRunner()
    result = runner.invoke(
        cli_module.cli,
        ["jolt-terminal", "--agent", "claude-code", "--once", "--no-bell"],
    )

    assert result.exit_code == 0
    assert "JOLT STAGE CONTEXT | 1 assignment waiting" in result.output
    assert "Next: Open the assignment queue." in result.output
    assert "Context: mode OPEN | readiness ready | 2 pending messages | 1 assignments | 0 reviews" in result.output
    assert "Peers: antigravity (shared workspace)" in result.output


def test_build_terminal_jolt_client_registers_remote_http_session(monkeypatch):
    captured = {}

    class FakeClient:
        def __init__(self, agent_name, *args, **kwargs):
            captured["agent_name"] = agent_name
            captured["kwargs"] = kwargs

    monkeypatch.setattr(cli_module, "WhispersClient", FakeClient)

    client, degraded = cli_module._build_terminal_jolt_client(
        agent_name="codex",
        server_url="http://127.0.0.1:8752",
        token="secret-token",
        profile_name="default",
        host_kind="codex_cli",
    )

    assert degraded is False
    assert isinstance(client, FakeClient)
    assert captured["agent_name"] == "codex"
    assert captured["kwargs"]["session_kind"] == "remote_http"
    assert captured["kwargs"]["jolt_adapter_kind"] == "managed_pty"


def test_build_terminal_jolt_client_uses_local_readonly_client_for_mcp_token(monkeypatch):
    captured = {}

    class FakeClient:
        def __init__(self, agent_name, *args, **kwargs):
            captured["agent_name"] = agent_name
            captured["kwargs"] = kwargs

    monkeypatch.setattr(cli_module, "WhispersClient", FakeClient)
    monkeypatch.setattr(cli_module, "_get_mcp_token", lambda: "mcp-token")

    client, degraded = cli_module._build_terminal_jolt_client(
        agent_name="codex",
        server_url="http://127.0.0.1:8752",
        token="mcp-token",
        profile_name="default",
        host_kind="codex_cli",
    )

    assert degraded is True
    assert isinstance(client, FakeClient)
    assert captured["agent_name"] == "codex"
    assert captured["kwargs"]["read_only"] is True
    assert "server" not in captured["kwargs"]


def test_jolt_terminal_prefers_agent_local_token(monkeypatch):
    captured = {}

    class FakeClient:
        def status(self):
            return {"jolt_packet": None}

    monkeypatch.setattr(cli_module, "_local_server_token_for_agent", lambda agent: f"agent-token-for-{agent}")
    monkeypatch.setattr(
        cli_module,
        "_load_credentials",
        lambda: {"profiles": {"default": {"token": "default-token"}}},
    )

    def fake_build_terminal_jolt_client(**kwargs):
        captured.update(kwargs)
        return FakeClient(), False

    monkeypatch.setattr(cli_module, "_build_terminal_jolt_client", fake_build_terminal_jolt_client)

    runner = CliRunner()
    result = runner.invoke(
        cli_module.cli,
        ["jolt-terminal", "--agent", "antigravity", "--once", "--no-bell"],
    )

    assert result.exit_code == 0
    assert captured["agent_name"] == "antigravity"
    assert captured["token"] == "agent-token-for-antigravity"


def test_jolt_terminal_falls_back_to_mcp_token_before_profile_token(monkeypatch):
    captured = {}

    class FakeClient:
        def status(self):
            return {"jolt_packet": None}

    monkeypatch.setattr(cli_module, "_local_server_token_for_agent", lambda agent: None)
    monkeypatch.setattr(cli_module, "_get_mcp_token", lambda: "mcp-token")
    monkeypatch.setattr(
        cli_module,
        "_load_credentials",
        lambda: {"profiles": {"default": {"token": "default-token"}}},
    )

    def fake_build_terminal_jolt_client(**kwargs):
        captured.update(kwargs)
        return FakeClient(), False

    monkeypatch.setattr(cli_module, "_build_terminal_jolt_client", fake_build_terminal_jolt_client)

    runner = CliRunner()
    result = runner.invoke(
        cli_module.cli,
        ["jolt-terminal", "--agent", "codex", "--once", "--no-bell"],
    )

    assert result.exit_code == 0
    assert captured["agent_name"] == "codex"
    assert captured["token"] == "mcp-token"


def test_overlay_local_sidecar_unread_truth_rebuilds_jolt_from_server_unread(monkeypatch):
    class FakeClient:
        agent_name = "codex"

    monkeypatch.setattr(
        cli_module,
        "_read_inbox_via_local_server",
        lambda **kwargs: [
            {
                "uuid": "proof-msg",
                "created_at": "2026-04-01T20:12:21+00:00",
                "from_agent": "antigravity",
                "subject": "Live Jolt proof",
                "priority": "priority",
                "msg_type": "request",
                "reply_to": None,
            }
        ],
    )

    def fake_attach_status_story(client, payload):
        assert "startup" not in payload
        assert "connection_story" not in payload
        rebuilt = dict(payload)
        rebuilt["connection_story"] = {
            "recommended_action": "Check inbox -- 1 unread message.",
        }
        rebuilt["jolt_packet"] = {
            "action": "notify",
            "trigger": "direct_assignment",
            "headline": "antigravity: Live Jolt proof",
            "priority": "priority",
            "recommended_action": "Check inbox -- 1 unread message.",
            "reasons": ["manual-wake host falls back to notification only"],
        }
        return rebuilt

    monkeypatch.setattr(cli_module, "_attach_status_story", fake_attach_status_story)

    status = cli_module._overlay_local_sidecar_unread_truth(
        FakeClient(),
        {
            "pending_messages": 0,
            "pending_by_priority": {},
            "pending_by_class": {},
            "unread_previews": [],
            "startup": {"stale": True},
            "connection_story": {"recommended_action": "Stay idle."},
        },
        agent_name="codex",
    )

    assert status["pending_messages"] == 1
    assert status["pending_by_priority"] == {"priority": 1}
    assert status["pending_by_class"] == {"actionable": 1}
    assert status["unread_previews"] == [
        {
            "uuid": "proof-msg",
            "created_at": "2026-04-01T20:12:21+00:00",
            "from_agent": "antigravity",
            "subject": "Live Jolt proof",
            "priority": "priority",
            "msg_type": "request",
            "reply_to": None,
        }
    ]
    assert status["jolt_packet"]["headline"] == "antigravity: Live Jolt proof"


def test_jolt_terminal_once_uses_local_sidecar_unread_truth_when_degraded(monkeypatch):
    class FakeClient:
        def status(self):
            return {
                "pending_messages": 0,
                "pending_by_priority": {},
                "pending_by_class": {},
                "unread_previews": [],
                "startup": {"stale": True},
                "connection_story": {"recommended_action": "Stay idle."},
            }

    monkeypatch.setattr(cli_module, "_local_server_token_for_agent", lambda agent: None)
    monkeypatch.setattr(cli_module, "_get_mcp_token", lambda: "mcp-token")
    monkeypatch.setattr(
        cli_module,
        "_build_terminal_jolt_client",
        lambda **kwargs: (FakeClient(), True),
    )
    monkeypatch.setattr(
        cli_module,
        "_read_inbox_via_local_server",
        lambda **kwargs: [
            {
                "uuid": "proof-msg",
                "created_at": "2026-04-01T20:12:21+00:00",
                "from_agent": "antigravity",
                "subject": "Live Jolt proof",
                "priority": "priority",
                "msg_type": "request",
                "reply_to": None,
            }
        ],
    )

    def fake_attach_status_story(client, payload):
        rebuilt = dict(payload)
        rebuilt["jolt_packet"] = {
            "action": "notify",
            "trigger": "direct_assignment",
            "headline": "antigravity: Live Jolt proof",
            "priority": "priority",
            "recommended_action": "Check inbox -- 1 unread message.",
            "reasons": ["manual-wake host falls back to notification only"],
        }
        return rebuilt

    monkeypatch.setattr(cli_module, "_attach_status_story", fake_attach_status_story)

    runner = CliRunner()
    result = runner.invoke(
        cli_module.cli,
        ["jolt-terminal", "--agent", "codex", "--once", "--no-bell", "--json-output"],
    )

    assert result.exit_code == 0
    payload = json.loads(result.output)
    assert payload["agent_name"] == "codex"
    assert payload["jolt_packet"]["headline"] == "antigravity: Live Jolt proof"
    assert payload["terminal_lines"][0] == "JOLT NOTIFY | antigravity: Live Jolt proof"


def test_inbox_claim_falls_back_to_local_server_when_db_is_readonly(monkeypatch):
    class _ReadonlyClient:
        def __init__(self, agent_name, *args, **kwargs):
            self.agent_name = agent_name

        def check_inbox(self, **kwargs):
            raise RuntimeError("attempt to write a readonly database")

    monkeypatch.setattr(cli_module, "WhispersClient", _ReadonlyClient)
    monkeypatch.setattr(cli_module, "_check_server_health", lambda: {"db_path": "C:/tmp/whispers.db"})
    monkeypatch.setattr(cli_module, "_expected_db_path", lambda: "C:/tmp/whispers.db")
    monkeypatch.setattr(
        cli_module,
        "_read_inbox_via_local_server",
        lambda **kwargs: [
            {
                "uuid": "server-fallback-msg",
                "from_agent": "claude-code",
                "priority": "routine",
                "visibility_mode": "normal",
                "memory_mode": "thread",
                "audience_scope": "direct",
                "subject": "Recovered via server fallback",
                "created_at": "2026-03-31T11:00:00+00:00",
                "created_at_local": "2026-03-31 4:00:00 AM Pacific Daylight Time",
            }
        ],
    )

    runner = CliRunner()
    result = runner.invoke(cli_module.cli, ["inbox", "codex"])

    assert result.exit_code == 0
    assert '"from": "claude-code"' in result.output
    assert "Recovered via server fallback" in result.output


def test_inbox_claim_prefers_server_preflight_when_local_db_is_readonly(monkeypatch):
    class _ShouldNotConstruct:
        def __init__(self, *args, **kwargs):
            raise AssertionError("local readonly inbox client should not be constructed")

    monkeypatch.setattr(cli_module, "WhispersClient", _ShouldNotConstruct)
    monkeypatch.setattr(
        cli_module,
        "_inspect_db_state",
        lambda path: {"db_exists": True, "db_writable": False},
    )
    monkeypatch.setattr(cli_module, "_check_server_health", lambda: {"db_path": "C:/tmp/whispers.db"})
    monkeypatch.setattr(cli_module, "_expected_db_path", lambda: "C:/tmp/whispers.db")
    monkeypatch.setattr(
        cli_module,
        "_read_inbox_via_local_server",
        lambda **kwargs: [
            {
                "uuid": "server-fallback-msg",
                "from_agent": "claude-code",
                "priority": "routine",
                "visibility_mode": "normal",
                "memory_mode": "thread",
                "audience_scope": "direct",
                "subject": "Recovered via server fallback",
                "created_at": "2026-03-31T11:00:00+00:00",
                "created_at_local": "2026-03-31 4:00:00 AM Pacific Daylight Time",
            }
        ],
    )

    runner = CliRunner()
    result = runner.invoke(cli_module.cli, ["inbox", "codex"])

    assert result.exit_code == 0
    assert '"from": "claude-code"' in result.output
    assert "Recovered via server fallback" in result.output


def test_ack_prefers_server_preflight_when_client_probe_fails(monkeypatch):
    class _ShouldNotConstruct:
        def __init__(self, *args, **kwargs):
            raise AssertionError("local writable ack client should not be constructed")

    monkeypatch.setattr(cli_module, "WhispersClient", _ShouldNotConstruct)
    monkeypatch.setattr(
        cli_module,
        "_inspect_db_state",
        lambda path: {"db_exists": True, "db_writable": True},
    )
    monkeypatch.setattr(
        cli_module,
        "_probe_local_writable_db_client_ready",
        lambda path: (False, "attempt to write a readonly database"),
    )
    monkeypatch.setattr(cli_module, "_check_server_health", lambda: {"db_path": "C:/tmp/whispers.db"})
    monkeypatch.setattr(cli_module, "_expected_db_path", lambda: "C:/tmp/whispers.db")
    monkeypatch.setattr(
        cli_module,
        "_ack_via_local_server",
        lambda **kwargs: {
            "uuid": kwargs["message_id"],
            "ack_state": kwargs["state"],
            "ack_detail": kwargs["detail"] or None,
            "acked_by": kwargs["agent_name"],
        },
    )

    runner = CliRunner()
    result = runner.invoke(
        cli_module.cli,
        ["ack", "message-123", "--agent-name", "codex", "--state", "accepted", "--detail", "Picked up"],
    )

    assert result.exit_code == 0
    assert '"uuid": "message-123"' in result.output
    assert '"ack_state": "accepted"' in result.output
    assert '"acked_by": "codex"' in result.output


def test_check_server_health_falls_back_to_readyz_when_health_fails(monkeypatch):
    def fake_server_request(server, path, **kwargs):
        if path == "/readyz":
            return {
                "ok": True,
                "db_path": "C:/tmp/whispers.db",
                "schema_version": 2,
                "wal_mode": True,
                "db_write_ready": True,
            }
        if path == "/health":
            raise RuntimeError("timed out")
        raise AssertionError(f"Unexpected path: {path}")

    monkeypatch.setattr(cli_module, "_server_request", fake_server_request)

    snapshot = cli_module._check_server_health()

    assert snapshot == {
        "healthy": True,
        "http_server_reachable": True,
        "ok": True,
        "db_path": "C:/tmp/whispers.db",
        "schema_version": 2,
        "wal_mode": True,
        "db_write_ready": True,
    }


def test_send_prefers_readyz_snapshot_when_health_fails(monkeypatch):
    class _ShouldNotConstruct:
        def __init__(self, *args, **kwargs):
            raise AssertionError("local writable send client should not be constructed")

    captured = {}

    def fake_server_request(server, path, **kwargs):
        if path == "/readyz":
            return {
                "ok": True,
                "db_path": "C:/tmp/whispers.db",
                "schema_version": 2,
                "wal_mode": True,
                "db_write_ready": True,
            }
        if path == "/health":
            raise RuntimeError("timed out")
        raise AssertionError(f"Unexpected path: {path}")

    def fake_send_via_local_server(payload):
        captured["payload"] = payload
        return {
            "status": "delivered",
            "delivery_status": "delivered",
            "id": "server-fallback-send",
        }

    monkeypatch.setattr(cli_module, "WhispersClient", _ShouldNotConstruct)
    monkeypatch.setattr(
        cli_module,
        "_inspect_db_state",
        lambda path: {"db_exists": True, "db_writable": True},
    )
    monkeypatch.setattr(
        cli_module,
        "_probe_local_writable_db_client_ready",
        lambda path: (False, "attempt to write a readonly database"),
    )
    monkeypatch.setattr(cli_module, "_expected_db_path", lambda: "C:/tmp/whispers.db")
    monkeypatch.setattr(cli_module, "_server_request", fake_server_request)
    monkeypatch.setattr(cli_module, "_send_via_local_server", fake_send_via_local_server)

    runner = CliRunner()
    result = runner.invoke(
        cli_module.cli,
        [
            "send",
            "--to",
            "claude-code",
            "--subject",
            "Recovered via readyz fallback",
            "--priority",
            "routine",
            "--msg-type",
            "request",
            "--from-agent",
            "codex",
            "--body",
            "probe",
        ],
    )

    assert result.exit_code == 0
    assert "delivered" in result.output
    assert captured["payload"]["subject"] == "Recovered via readyz fallback"


def test_inbox_claim_prefers_readyz_snapshot_when_health_fails(monkeypatch):
    class _ShouldNotConstruct:
        def __init__(self, *args, **kwargs):
            raise AssertionError("local writable inbox client should not be constructed")

    def fake_server_request(server, path, **kwargs):
        if path == "/readyz":
            return {
                "ok": True,
                "db_path": "C:/tmp/whispers.db",
                "schema_version": 2,
                "wal_mode": True,
                "db_write_ready": True,
            }
        if path == "/health":
            raise RuntimeError("timed out")
        raise AssertionError(f"Unexpected path: {path}")

    monkeypatch.setattr(cli_module, "WhispersClient", _ShouldNotConstruct)
    monkeypatch.setattr(
        cli_module,
        "_inspect_db_state",
        lambda path: {"db_exists": True, "db_writable": True},
    )
    monkeypatch.setattr(
        cli_module,
        "_probe_local_writable_db_client_ready",
        lambda path: (False, "attempt to write a readonly database"),
    )
    monkeypatch.setattr(cli_module, "_expected_db_path", lambda: "C:/tmp/whispers.db")
    monkeypatch.setattr(cli_module, "_server_request", fake_server_request)
    monkeypatch.setattr(
        cli_module,
        "_read_inbox_via_local_server",
        lambda **kwargs: [
            {
                "uuid": "server-fallback-msg",
                "from_agent": "claude-code",
                "priority": "routine",
                "visibility_mode": "normal",
                "memory_mode": "thread",
                "audience_scope": "direct",
                "subject": "Recovered via readyz fallback",
                "created_at": "2026-03-31T11:00:00+00:00",
                "created_at_local": "2026-03-31 4:00:00 AM Pacific Daylight Time",
            }
        ],
    )

    runner = CliRunner()
    result = runner.invoke(cli_module.cli, ["inbox", "codex"])

    assert result.exit_code == 0
    assert '"from": "claude-code"' in result.output
    assert "Recovered via readyz fallback" in result.output


def test_server_request_handles_colon_paths(monkeypatch):
    captured = {}

    class _Response:
        def __enter__(self):
            return self

        def __exit__(self, exc_type, exc, tb):
            return False

        def read(self):
            return b"{}"

    def fake_urlopen(request, timeout):
        captured["url"] = request.full_url
        captured["timeout"] = timeout
        return _Response()

    monkeypatch.setattr(cli_module.urllib.request, "urlopen", fake_urlopen)

    cli_module._server_request(
        "http://127.0.0.1:8752",
        "/message:ack",
        method="POST",
        payload={"message_id": "abc"},
    )

    assert captured["url"] == "http://127.0.0.1:8752/message:ack"
    assert captured["timeout"] == 10


def test_read_inbox_via_local_server_passes_agent_name(monkeypatch):
    captured = {}

    def fake_server_request(server, path, **kwargs):
        captured["server"] = server
        captured["path"] = path
        captured["kwargs"] = kwargs
        return {"messages": []}

    monkeypatch.setattr(cli_module, "_server_request", fake_server_request)
    monkeypatch.setattr(cli_module, "_local_server_auth_token", lambda agent_name, profile_name=None: "mcp-token")

    cli_module._read_inbox_via_local_server(
        agent_name="codex",
        limit=3,
        mark_seen=True,
    )

    assert captured["server"] == cli_module._SERVER_URL
    assert captured["path"] == "/inbox"
    assert captured["kwargs"]["query"]["agent_name"] == "codex"
    assert captured["kwargs"]["token"] == "mcp-token"


def test_jolt_terminal_reports_clear_auth_hint_on_invalid_remote_token(monkeypatch):
    monkeypatch.setattr(cli_module, "_local_server_token_for_agent", lambda agent: None)
    monkeypatch.setattr(cli_module, "_get_mcp_token", lambda: "mcp-token")
    monkeypatch.setattr(
        cli_module,
        "_load_credentials",
        lambda: {"profiles": {"default": {"token": "default-token"}}},
    )
    monkeypatch.setattr(
        cli_module,
        "_build_terminal_jolt_client",
        lambda **kwargs: (_ for _ in ()).throw(RuntimeError("Invalid or revoked token.")),
    )

    runner = CliRunner()
    result = runner.invoke(
        cli_module.cli,
        ["jolt-terminal", "--agent", "codex", "--once", "--no-bell"],
    )

    assert result.exit_code != 0
    assert "Jolt sidecar auth failed for codex" in result.output
