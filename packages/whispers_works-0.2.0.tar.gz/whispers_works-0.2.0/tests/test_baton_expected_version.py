import asyncio

import pytest

import whispers.mcp_server as mcp_module
from whispers.client import WhispersClient, WhispersConflictError


def _send_test_handoff(sender, subject="test"):
    return sender.send_handoff(
        to="bob",
        subject=subject,
        objective="test objective",
        deliverable="test deliverable",
        completed="done so far",
        remaining="what's left",
        next_action="do it",
    )


def test_mcp_baton_tools_expose_expected_version():
    for tool_name in ("baton_ack", "baton_update", "baton_close"):
        tool = next(tool for tool in mcp_module.TOOLS if tool.name == tool_name)
        assert tool.inputSchema["properties"]["expected_version"]["type"] == "integer"


def test_local_client_rejects_stale_expected_version(temp_db):
    sender = WhispersClient("alice", db_path=temp_db)
    receiver = WhispersClient("bob", db_path=temp_db)

    baton_ref = _send_test_handoff(sender, "client stale version")["id"]
    receiver.baton_ack(baton_ref, "accepted")

    with pytest.raises(WhispersConflictError) as exc_info:
        receiver.baton_update(
            baton_ref,
            "in_progress",
            progress="still working from stale state",
            expected_version=1,
        )

    assert "expected version 1" in str(exc_info.value)
    assert sender.db.get_baton_version(baton_ref) == 2


def test_mcp_baton_tools_forward_expected_version(temp_db, monkeypatch):
    monkeypatch.setenv("WHISPERS_DB_PATH", temp_db)
    mcp_module._clients.clear()

    sender = WhispersClient("alice", db_path=temp_db)
    baton_ref = _send_test_handoff(sender, "mcp stale version")["id"]

    token = mcp_module.current_agent_name.set("bob")
    try:
        asyncio.run(
            mcp_module.handle_tool(
                "baton_ack",
                {"baton_ref": baton_ref, "decision": "accepted", "expected_version": 1},
            )
        )

        with pytest.raises(WhispersConflictError) as exc_info:
            asyncio.run(
                mcp_module.handle_tool(
                    "baton_update",
                    {"baton_ref": baton_ref, "state": "in_progress", "expected_version": 1},
                )
            )
    finally:
        mcp_module.current_agent_name.reset(token)
        mcp_module._clients.clear()

    assert "expected version 1" in str(exc_info.value)
    assert sender.db.get_baton_version(baton_ref) == 2
