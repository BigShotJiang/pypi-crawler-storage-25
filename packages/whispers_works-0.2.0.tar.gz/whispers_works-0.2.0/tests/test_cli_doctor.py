import json
import pytest
from unittest.mock import patch, MagicMock
from click.testing import CliRunner

from whispers.cli import doctor

def test_doctor_remote_offline():
    runner = CliRunner()
    
    with patch("whispers.cli._remote_server_health", return_value=None), \
         patch("whispers.cli._resolve_remote_profile", return_value={"server": "http://localhost:8752", "token": "test-tk"}):
        
        result = runner.invoke(doctor, ["--server", "http://localhost:8752"])
        assert result.exit_code == 0
        data = json.loads(result.output)
        
        assert data["reachable"] is False
        assert "Remote health endpoint is unreachable." in data["issues"]
        assert data["overall"] == "FAIL"

def test_doctor_remote_unauthenticated():
    runner = CliRunner()
    
    with patch("whispers.cli._remote_server_health", return_value={"status": "ok", "db_version": 2}), \
         patch("whispers.cli._server_request") as mock_req, \
         patch("whispers.cli._resolve_remote_profile", return_value={"server": "http://localhost:8752", "token": None}):
        
        # /readyz responds OK
        mock_req.return_value = {"ok": True}
        
        result = runner.invoke(doctor, ["--server", "http://localhost:8752"])
        
        assert result.exit_code == 0
        data = json.loads(result.output)
        
        assert data["reachable"] is True
        assert data["authenticated"] is False
        assert "Missing authentication token. Run 'whispers connect --server http://localhost:8752 --profile <name>' to provision credentials." in data["issues"]


def test_doctor_remote_missing_profile_token_points_to_connect():
    runner = CliRunner()

    with patch("whispers.cli._remote_server_health", return_value={"status": "ok", "db_version": 2}), \
         patch("whispers.cli._server_request") as mock_req, \
         patch(
             "whispers.cli._resolve_remote_profile",
             return_value={
                 "server": "http://localhost:8752",
                 "token": None,
                 "profile_name": "work",
             },
         ):

        mock_req.return_value = {"ok": True}

        result = runner.invoke(doctor, ["--profile", "work"])

        assert result.exit_code == 0
        data = json.loads(result.output)

        assert data["authenticated"] is False
        assert (
            "Missing authentication token for remote profile 'work'. "
            "Run 'whispers connect --server http://localhost:8752 --profile work' to provision credentials."
        ) in data["issues"]

def test_doctor_remote_authenticated_success():
    runner = CliRunner()
    
    with patch("whispers.cli._remote_server_health", return_value={"status": "ok", "db_version": 2}), \
         patch("whispers.cli._server_request") as mock_req, \
         patch("whispers.cli._resolve_remote_profile", return_value={"server": "http://localhost:8752", "token": "valid_token"}):
        
        def mock_request(server, path, **kwargs):
            if path == "/readyz":
                return {"ok": True}
            elif path == "/whoami":
                return {"callsign": "test-agent"}
            elif path == "/status":
                return {"agents_online_count": 1}
            elif path == "/connection-story":
                return {"story": []}
            return {}
            
        mock_req.side_effect = mock_request
        
        result = runner.invoke(doctor, ["--server", "http://localhost:8752"])
        
        assert result.exit_code == 0
        data = json.loads(result.output)
        
        assert data["reachable"] is True
        assert data["authenticated"] is True
        assert data["whoami"] == {"callsign": "test-agent"}
        assert data["overall"] == "PASS"

def test_doctor_remote_token_revoked():
    runner = CliRunner()
    from click import ClickException
    
    with patch("whispers.cli._remote_server_health", return_value={"status": "ok", "db_version": 2}), \
         patch("whispers.cli._server_request") as mock_req, \
         patch("whispers.cli._resolve_remote_profile", return_value={"server": "http://localhost:8752", "token": "revoked"}):
        
        def mock_request(server, path, **kwargs):
            if path == "/readyz":
                return {"ok": True}
            raise ClickException("Remote request failed (401) /whoami: Unauthorized")
            
        mock_req.side_effect = mock_request
        
        result = runner.invoke(doctor, ["--server", "http://localhost:8752"])
        
        assert result.exit_code == 0
        data = json.loads(result.output)
        
        assert data["authenticated"] is False
        assert any("Authentication rejected" in i for i in data["issues"])
        assert any("revoked" in i for i in data["issues"])
        assert any("whispers connect --server http://localhost:8752 --profile <name>" in i for i in data["issues"])
        assert not any("mcp-install" in i for i in data["issues"])
        assert data["overall"] == "FAIL"


def test_doctor_remote_token_revoked_for_profile_points_to_profile_reconnect():
    runner = CliRunner()
    from click import ClickException

    with patch("whispers.cli._remote_server_health", return_value={"status": "ok", "db_version": 2}), \
         patch("whispers.cli._server_request") as mock_req, \
         patch(
             "whispers.cli._resolve_remote_profile",
             return_value={
                 "server": "http://localhost:8752",
                 "token": "revoked",
                 "profile_name": "work",
             },
         ):

        def mock_request(server, path, **kwargs):
            if path == "/readyz":
                return {"ok": True}
            raise ClickException("Remote request failed (401) /whoami: Unauthorized")

        mock_req.side_effect = mock_request

        result = runner.invoke(doctor, ["--profile", "work"])

        assert result.exit_code == 0
        data = json.loads(result.output)

        assert data["authenticated"] is False
        assert any(
            "Run 'whispers connect --server http://localhost:8752 --profile work' to refresh the remote profile credentials."
            in i
            for i in data["issues"]
        )
