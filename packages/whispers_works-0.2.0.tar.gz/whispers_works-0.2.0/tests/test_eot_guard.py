"""Tests for EOT (End of Thread) guard.

Uses dispatcher directly to bypass client-side rate limiting.

Covers:
- Normal thread under limit delivers
- Thread at limit gets rejected
- Flash priority bypasses EOT
- Security event logged on termination
"""

import pytest
from whispers.envelope import Envelope, Priority, MsgType
from whispers.dispatcher import Dispatcher, EOT_EXCHANGE_LIMIT


class TestEOTGuard:
    @pytest.fixture
    def setup(self, tmp_path):
        from whispers.storage.db import WhispersDB

        db_path = str(tmp_path / "test_eot.db")
        db = WhispersDB(db_path=db_path)
        dispatcher = Dispatcher(db)
        return db, dispatcher

    def _make_envelope(self, context_id, sender="alice", priority=Priority.ROUTINE, n=0):
        return Envelope(
            sender=sender,
            recipient="bob",
            subject=f"Msg {n}",
            body=f"Exchange {n}",
            priority=priority,
            msg_type=MsgType.INFORM,
            context_id=context_id,
        )

    def _fill_thread(self, dispatcher, ctx, count):
        """Fill a thread using alternating senders to avoid velocity breaker."""
        senders = ["agent-a", "agent-b", "agent-c", "agent-d", "agent-e"]
        for i in range(count):
            sender = senders[i % len(senders)]
            dispatcher.dispatch(self._make_envelope(ctx, sender=sender, n=i))

    def test_normal_thread_delivers(self, setup):
        db, dispatcher = setup
        for i in range(5):
            result = dispatcher.dispatch(self._make_envelope("normal-thread", n=i))
            assert result is None

    def test_thread_at_limit_rejected(self, setup):
        db, dispatcher = setup
        ctx = "eot-thread"
        self._fill_thread(dispatcher, ctx, EOT_EXCHANGE_LIMIT)
        # Next should be rejected
        result = dispatcher.dispatch(self._make_envelope(ctx, n=EOT_EXCHANGE_LIMIT))
        assert result is not None
        assert "eot_thread_limit" in result

    def test_flash_bypasses_eot(self, setup):
        db, dispatcher = setup
        ctx = "flash-eot"
        self._fill_thread(dispatcher, ctx, EOT_EXCHANGE_LIMIT)
        result = dispatcher.dispatch(self._make_envelope(ctx, priority=Priority.FLASH, n=99))
        assert result is None or (result is not None and "eot_thread_limit" not in result)

    def test_security_event_logged(self, setup):
        db, dispatcher = setup
        ctx = "audit-eot"
        self._fill_thread(dispatcher, ctx, EOT_EXCHANGE_LIMIT)
        dispatcher.dispatch(self._make_envelope(ctx, n=EOT_EXCHANGE_LIMIT))

        with db.get_readonly_connection() as conn:
            events = conn.execute(
                "SELECT * FROM security_events WHERE event_type = 'eot_thread_limit'"
            ).fetchall()
        assert len(events) >= 1
        assert ctx in events[0]["detail"]
