"""Tests for Solution-Aware Error Responses (SAER v0.1).

Verifies that every A2A error response includes SAER diagnostic fields
(reason, resolution) and follows the ethical guardrails:
- No marketing URLs
- No product pitches
- `see` fields are always relative paths
- `saer` version tag present in all error data
"""

import json
import sys
import os
import pytest

# Add project root to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from whispers.a2a import (
    _solution_aware_error,
    _jsonrpc_error,
    SAER_VERSION,
    JSONRPC_PARSE_ERROR,
    JSONRPC_INVALID_REQUEST,
    JSONRPC_METHOD_NOT_FOUND,
    JSONRPC_INVALID_PARAMS,
    A2A_AUTH_INVALID,
    A2A_SCOPE_INSUFFICIENT,
    A2A_TASK_NOT_FOUND,
    A2A_AGENT_NOT_FOUND,
    A2A_TASK_NOT_CANCELABLE,
    A2A_RATE_LIMITED,
)


# ---------------------------------------------------------------------------
# Core helper tests
# ---------------------------------------------------------------------------

class TestSolutionAwareError:
    """Test the _solution_aware_error helper function."""

    def test_basic_structure(self):
        """SAER error has standard JSON-RPC 2.0 structure."""
        result = _solution_aware_error(
            -32001, "Test error", "req-1",
            reason="Something went wrong",
        )
        assert result["jsonrpc"] == "2.0"
        assert result["id"] == "req-1"
        assert "error" in result
        assert result["error"]["code"] == -32001
        assert result["error"]["message"] == "Test error"

    def test_saer_version_present(self):
        """Every SAER error includes the spec version in data."""
        result = _solution_aware_error(-32001, "Test")
        assert result["error"]["data"]["saer"] == SAER_VERSION

    def test_reason_field(self):
        """SAER error includes reason when provided."""
        result = _solution_aware_error(
            -32001, "Test",
            reason="Because X happened",
        )
        assert result["error"]["data"]["reason"] == "Because X happened"

    def test_resolution_field(self):
        """SAER error includes resolution when provided."""
        result = _solution_aware_error(
            -32001, "Test",
            resolution="Do Y to fix it",
        )
        assert result["error"]["data"]["resolution"] == "Do Y to fix it"

    def test_see_field(self):
        """SAER error includes see when provided."""
        result = _solution_aware_error(
            -32001, "Test",
            see="/.well-known/agent-card.json",
        )
        assert result["error"]["data"]["see"] == "/.well-known/agent-card.json"

    def test_context_merged(self):
        """Context dict fields are merged into data."""
        result = _solution_aware_error(
            -32001, "Test",
            context={"required_scopes": ["messages:send"], "granted_scopes": []},
        )
        data = result["error"]["data"]
        assert data["required_scopes"] == ["messages:send"]
        assert data["granted_scopes"] == []
        assert data["saer"] == SAER_VERSION  # version preserved

    def test_minimal_error(self):
        """SAER error with no optional fields still includes version."""
        result = _solution_aware_error(-32600, "Bad request")
        assert result["error"]["data"] == {"saer": SAER_VERSION}

    def test_null_request_id(self):
        """Works with None request_id (notification errors)."""
        result = _solution_aware_error(-32001, "Test")
        assert result["id"] is None


# ---------------------------------------------------------------------------
# Ethical guardrail tests
# ---------------------------------------------------------------------------

class TestSAERGuardrails:
    """Verify SAER responses don't contain marketing or absolute URLs."""

    SAMPLE_ERRORS = [
        # Auth error
        _solution_aware_error(
            A2A_AUTH_INVALID, "Invalid token", "r1",
            reason="Token not recognized",
            resolution="Request a new token via /connect",
            see="/.well-known/agent-card.json",
            context={"auth_methods": ["bearer"], "token_endpoint": "/connect"},
        ),
        # Scope error
        _solution_aware_error(
            A2A_SCOPE_INSUFFICIENT, "Insufficient scope", "r2",
            reason="Missing scope",
            resolution="Request token with required scopes",
            context={"required_scopes": ["messages:read"], "granted_scopes": ["messages:send"]},
        ),
        # Agent not found
        _solution_aware_error(
            A2A_AGENT_NOT_FOUND, "Agent not found: 'test'", "r3",
            reason="No agent registered",
            resolution="Verify callsign",
            see="/.well-known/agent-card.json",
            context={"requested_agent": "test"},
        ),
        # Task not found
        _solution_aware_error(
            A2A_TASK_NOT_FOUND, "Task not found", "r4",
            reason="No task with this ID",
            resolution="Verify task ID",
            context={"requested_id": "abc-123"},
        ),
        # Task not cancelable
        _solution_aware_error(
            A2A_TASK_NOT_CANCELABLE, "Cannot cancel", "r5",
            reason="Terminal state",
            resolution="Only non-terminal tasks can be canceled",
            context={"current_state": "TASK_STATE_COMPLETED"},
        ),
    ]

    @pytest.mark.parametrize("error", SAMPLE_ERRORS)
    def test_no_absolute_urls(self, error):
        """No absolute URLs (http:// or https://) in error data."""
        data_str = json.dumps(error["error"].get("data", {}))
        assert "http://" not in data_str, f"Absolute URL found in error data: {data_str}"
        assert "https://" not in data_str, f"Absolute URL found in error data: {data_str}"

    @pytest.mark.parametrize("error", SAMPLE_ERRORS)
    def test_no_marketing_language(self, error):
        """No marketing language in error responses."""
        data_str = json.dumps(error["error"].get("data", {})).lower()
        marketing_terms = ["learn more", "upgrade", "premium", "subscribe", "buy", "purchase"]
        for term in marketing_terms:
            assert term not in data_str, f"Marketing term '{term}' found in error data"

    @pytest.mark.parametrize("error", SAMPLE_ERRORS)
    def test_see_field_is_relative(self, error):
        """The 'see' field, if present, is always a relative path."""
        data = error["error"].get("data", {})
        see = data.get("see")
        if see:
            assert see.startswith("/"), f"'see' field must be relative path, got: {see}"
            assert "://" not in see, f"'see' field must not contain absolute URL: {see}"

    @pytest.mark.parametrize("error", SAMPLE_ERRORS)
    def test_saer_version_present(self, error):
        """Every SAER error includes the spec version."""
        data = error["error"].get("data", {})
        assert "saer" in data, "Missing 'saer' version field in error data"
        assert data["saer"] == SAER_VERSION


# ---------------------------------------------------------------------------
# Error code convention tests
# ---------------------------------------------------------------------------

class TestErrorCodeConvention:
    """Verify error codes follow the 4xxNN convention."""

    def test_auth_codes_in_401xx_range(self):
        assert 40100 <= A2A_AUTH_INVALID <= 40199

    def test_scope_codes_in_403xx_range(self):
        assert 40300 <= A2A_SCOPE_INSUFFICIENT <= 40399

    def test_not_found_codes_in_404xx_range(self):
        assert 40400 <= A2A_TASK_NOT_FOUND <= 40499
        assert 40400 <= A2A_AGENT_NOT_FOUND <= 40499

    def test_conflict_codes_in_409xx_range(self):
        assert 40900 <= A2A_TASK_NOT_CANCELABLE <= 40999

    def test_rate_limit_code_in_429xx_range(self):
        assert 42900 <= A2A_RATE_LIMITED <= 42999


# ---------------------------------------------------------------------------
# Backwards compatibility tests
# ---------------------------------------------------------------------------

class TestBackwardsCompatibility:
    """Verify _jsonrpc_error still works for non-SAER contexts."""

    def test_jsonrpc_error_basic(self):
        """Old helper still produces valid JSON-RPC errors."""
        result = _jsonrpc_error(-32600, "Bad request", "req-1")
        assert result["jsonrpc"] == "2.0"
        assert result["id"] == "req-1"
        assert result["error"]["code"] == -32600
        assert result["error"]["message"] == "Bad request"
        assert "data" not in result["error"]

    def test_jsonrpc_error_with_data(self):
        """Old helper passes through data field."""
        result = _jsonrpc_error(-32600, "Bad", "r1", data={"foo": "bar"})
        assert result["error"]["data"] == {"foo": "bar"}


# ---------------------------------------------------------------------------
# Integration-style tests (error catalog coverage)
# ---------------------------------------------------------------------------

class TestErrorCatalogCoverage:
    """Ensure all 9 error scenarios from the SAER spec are covered."""

    def test_auth_required_shape(self):
        """Auth required error includes token_endpoint and auth_methods."""
        err = _solution_aware_error(
            A2A_AUTH_INVALID, "Auth required",
            context={"auth_methods": ["bearer"], "token_endpoint": "/connect"},
        )
        data = err["error"]["data"]
        assert "auth_methods" in data
        assert "token_endpoint" in data
        assert data["token_endpoint"].startswith("/")

    def test_scope_error_includes_diff(self):
        """Scope error includes required vs granted comparison."""
        err = _solution_aware_error(
            A2A_SCOPE_INSUFFICIENT, "Insufficient scope",
            context={
                "required_scopes": ["messages:read"],
                "granted_scopes": ["messages:send"],
                "method": "tasks/get",
            },
        )
        data = err["error"]["data"]
        assert data["required_scopes"] == ["messages:read"]
        assert data["granted_scopes"] == ["messages:send"]
        assert data["method"] == "tasks/get"

    def test_method_not_found_lists_supported(self):
        """Method not found includes list of supported methods."""
        err = _solution_aware_error(
            JSONRPC_METHOD_NOT_FOUND, "Not found",
            context={
                "supported_methods": ["message/send", "tasks/get"],
                "requested_method": "tasks/explode",
            },
        )
        data = err["error"]["data"]
        assert "supported_methods" in data
        assert "requested_method" in data
        assert "tasks/explode" == data["requested_method"]

    def test_invalid_request_includes_example(self):
        """Invalid request error can include a valid example."""
        err = _solution_aware_error(
            JSONRPC_INVALID_REQUEST, "Invalid",
            context={"example": {"jsonrpc": "2.0", "method": "message/send", "params": {}, "id": "1"}},
        )
        data = err["error"]["data"]
        assert "example" in data
        assert data["example"]["jsonrpc"] == "2.0"

    def test_agent_not_found_includes_requested(self):
        """Agent not found includes the callsign that was requested."""
        err = _solution_aware_error(
            A2A_AGENT_NOT_FOUND, "Not found: 'ghost'",
            context={"requested_agent": "ghost"},
        )
        assert err["error"]["data"]["requested_agent"] == "ghost"

    def test_task_not_cancelable_includes_states(self):
        """Task not cancelable lists cancelable states."""
        err = _solution_aware_error(
            A2A_TASK_NOT_CANCELABLE, "Cannot cancel",
            context={
                "current_state": "TASK_STATE_COMPLETED",
                "cancelable_states": ["TASK_STATE_SUBMITTED", "TASK_STATE_WORKING"],
                "task_id": "xyz",
            },
        )
        data = err["error"]["data"]
        assert "cancelable_states" in data
        assert "current_state" in data
        assert data["task_id"] == "xyz"

    def test_whispers_extension_namespaced(self):
        """Whispers-specific fields use whispers: prefix."""
        err = _solution_aware_error(
            A2A_SCOPE_INSUFFICIENT, "Scope error",
            context={"whispers:suggested_profile": "external-agent"},
        )
        data = err["error"]["data"]
        assert "whispers:suggested_profile" in data
        # Standard fields don't have prefix
        assert "saer" in data
