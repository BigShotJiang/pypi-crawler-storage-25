from datetime import timedelta
import json

import pytest

from whispers.envelope import Envelope, MsgType, Priority
from whispers.testing import WhispersTestHarness
from whispers.time_utils import to_utc_iso, utc_now
from whispers.twoack_schemas import ExternalActionResult
from whispers.storage.db import WhispersDBError


def _override_rows(db_path: str) -> list[dict]:
    import sqlite3

    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    try:
        rows = conn.execute(
            """
            SELECT outcome, actor_agent, target_agent, detail
            FROM security_events
            WHERE event_type = 'operator_override'
            ORDER BY rowid ASC
            """
        ).fetchall()
        return [dict(row) for row in rows]
    finally:
        conn.close()


def test_operator_override_external_action_result_records_open_and_close_events():
    with WhispersTestHarness() as h:
        alice = h.make_client("alice")
        bob = h.make_client("bob")

        expires_at = to_utc_iso(utc_now() + timedelta(hours=1))
        closed_at = to_utc_iso(utc_now() + timedelta(minutes=10))
        result = alice.send_external_action_result(
            "bob",
            ExternalActionResult(
                action_ref="ext-1",
                outcome="success",
                operator_override=True,
                override_reason="Operator approved one-time break-glass deploy.",
                override_expires_at=expires_at,
                override_closed_at=closed_at,
                override_closure_note="Deploy finished and override was closed.",
            ),
            human_summary="deploy completed under break-glass override",
        )

        assert result["status"] in ("delivered", "queued")
        inbox = bob.check_inbox()
        assert len(inbox) == 1

        rows = _override_rows(alice.db_path)
        assert [row["outcome"] for row in rows] == ["opened", "closed"]
        opened = json.loads(rows[0]["detail"])
        closed = json.loads(rows[1]["detail"])

        assert opened["action_ref"] == "ext-1"
        assert opened["override_reason"] == "Operator approved one-time break-glass deploy."
        assert opened["override_expires_at"] == expires_at
        assert opened["execution_outcome"] == "success"
        assert closed["override_closed_at"] == closed_at
        assert closed["override_closure_note"] == "Deploy finished and override was closed."


def test_operator_override_requires_explicit_reason_and_future_expiry():
    with WhispersTestHarness() as h:
        alice = h.make_client("alice")
        bob = h.make_client("bob")

        result = alice.send_external_action_result(
            "bob",
            ExternalActionResult(
                action_ref="ext-2",
                outcome="success",
                operator_override=True,
            ),
            human_summary="override missing required metadata",
        )

        assert result["status"] == "dead_lettered"
        assert result["reason"] == "operator_override_invalid"
        assert bob.check_inbox() == []

        rows = _override_rows(alice.db_path)
        assert len(rows) == 1
        assert rows[0]["outcome"] == "rejected_invalid"
        detail = json.loads(rows[0]["detail"])
        assert detail["reason"] == "override_reason_required"


def test_direct_store_rejects_invalid_operator_override():
    with WhispersTestHarness() as h:
        alice = h.make_client("alice")
        bob = h.make_client("bob")

        envelope = Envelope(
            sender="alice",
            recipient="bob",
            subject="invalid override",
            msg_type=MsgType.EXTERNAL_ACTION_RESULT,
            priority=Priority.ROUTINE,
            payload={
                "wire_v": 1,
                "schema": "external_action_result.v1",
                "mode": "bilingual",
                "signal_class": "whispers_internal",
                "trace": {"message_id": "msg-ext-override", "trace_id": "trace-ext-override"},
                "summary": {"headline": "Action Result: success", "human": "invalid override"},
                "payload": {
                    "action_ref": "ext-3",
                    "outcome": "success",
                    "operator_override": True,
                    "override_reason": "Missing expiry should reject.",
                },
            },
            metadata={"whispers:schema": "external_action_result.v1"},
            created_at=utc_now(),
        )

        with pytest.raises(WhispersDBError, match="Operator override rejected"):
            alice.db.store_message(envelope, allowed_recipients=["bob"])

        assert bob.check_inbox() == []
        rows = _override_rows(alice.db_path)
        assert len(rows) == 1
        detail = json.loads(rows[0]["detail"])
        assert detail["reason"] == "override_expiry_required"
