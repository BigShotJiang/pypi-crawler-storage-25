"""Test A2A Protocol Integration — Phases A, B, and C.

Phase A: Agent Card discovery and serving
Phase B: JSON-RPC 2.0 gateway (message/send, tasks/get, tasks/cancel)
Phase C: SSE streaming (message/stream), outbound A2A client, loopback interop
"""
import importlib
import json
import pytest
from unittest.mock import patch, MagicMock
from fastapi.testclient import TestClient
from whispers.a2a import (
    A2A_MAX_REQUEST_BYTES,
    A2AClient,
    generate_server_card,
    generate_agent_card,
    _message_to_task,
    _whispers_to_a2a_state,
    _jsonrpc_response,
    _jsonrpc_error,
    TASK_SUBMITTED,
    TASK_WORKING,
    TASK_COMPLETED,
    TASK_FAILED,
    TASK_CANCELED,
    TASK_REJECTED,
    JSONRPC_PARSE_ERROR,
    JSONRPC_INVALID_REQUEST,
    JSONRPC_METHOD_NOT_FOUND,
    JSONRPC_INVALID_PARAMS,
    JSONRPC_INTERNAL_ERROR,
    A2A_TASK_NOT_FOUND,
    A2A_TASK_NOT_CANCELABLE,
    A2A_AGENT_NOT_FOUND,
    A2A_PROTOCOL_VERSION,
    WHISPERS_VERSION,
)


@pytest.fixture
def client(monkeypatch, temp_db):
    runtime_state_path = f"{temp_db}-runtime.json"
    monkeypatch.setenv("WHISPERS_DB_PATH", temp_db)
    monkeypatch.setenv("WHISPERS_RUNTIME_STATE_PATH", runtime_state_path)

    import whispers.server as server_module

    server_module = importlib.reload(server_module)
    with TestClient(server_module.app) as client:
        yield client


# ===========================================================================
# Phase A: Agent Card Discovery
# ===========================================================================


class TestAgentCardDiscovery:
    """Phase A: Agent Card serving and discovery."""

    def test_well_known_agent_card(self, client):
        """Server Agent Card at /.well-known/agent-card.json."""
        resp = client.get("/.well-known/agent-card.json")
        assert resp.status_code == 200
        card = resp.json()

        # Required A2A fields
        assert card["name"] == "Whispers Hub"
        assert "description" in card
        assert "version" in card
        assert "url" in card
        assert "protocolVersions" in card
        assert "1.0" in card["protocolVersions"]

        # Capabilities
        assert card["capabilities"]["streaming"] is True
        assert card["capabilities"]["stateTransitionHistory"] is True

        # Whispers extensions in metadata
        assert "metadata" in card
        assert card["metadata"]["whispers:type"] == "hub"
        assert "presence" in card["metadata"]["whispers:features"]

    def test_agent_card_not_found(self, client):
        """Non-existent agent returns 404."""
        resp = client.get("/agents/nonexistent-agent/.well-known/agent-card.json")
        assert resp.status_code == 404

    def test_agents_list(self, client):
        """Agent listing endpoint returns valid structure."""
        resp = client.get("/a2a/agents")
        assert resp.status_code == 200
        data = resp.json()
        assert "agents" in data
        assert "count" in data
        assert isinstance(data["agents"], list)

    def test_server_card_url_format(self, client):
        """Server card URL field matches the A2A endpoint path."""
        resp = client.get("/.well-known/agent-card.json")
        card = resp.json()
        assert card["url"].endswith("/a2a/v1")

    def test_server_card_skills(self, client):
        """Server card includes Whispers-specific skills."""
        resp = client.get("/.well-known/agent-card.json")
        card = resp.json()
        assert "skills" in card
        skill_ids = [s["id"] for s in card["skills"]]
        assert "message-routing" in skill_ids
        assert "agent-discovery" in skill_ids

    def test_server_card_supported_interfaces(self, client):
        """Server card declares supported protocol interfaces."""
        resp = client.get("/.well-known/agent-card.json")
        card = resp.json()
        assert "supportedInterfaces" in card
        protocols = [iface["protocol"] for iface in card["supportedInterfaces"]]
        assert "JSONRPC" in protocols

    def test_server_card_security_schemes(self, client):
        """Server card declares Bearer token auth (A2A v1.0 requirement)."""
        resp = client.get("/.well-known/agent-card.json")
        card = resp.json()
        assert "securitySchemes" in card
        assert "bearerToken" in card["securitySchemes"]
        scheme = card["securitySchemes"]["bearerToken"]
        assert scheme["type"] == "http"
        assert scheme["scheme"] == "bearer"
        assert "description" in scheme

    def test_server_card_security_requirements(self, client):
        """Server card requires auth via securityRequirements."""
        resp = client.get("/.well-known/agent-card.json")
        card = resp.json()
        assert "securityRequirements" in card
        assert len(card["securityRequirements"]) >= 1
        assert "bearerToken" in card["securityRequirements"][0]

    def test_server_card_scope_metadata(self, client):
        """Server card advertises available scopes and token profiles."""
        resp = client.get("/.well-known/agent-card.json")
        card = resp.json()
        meta = card["metadata"]
        # Scope vocabulary
        assert "whispers:availableScopes" in meta
        scopes = meta["whispers:availableScopes"]
        assert "messages:send" in scopes
        assert "messages:read" in scopes
        assert "tokens:manage" in scopes
        assert "*" in scopes
        # Token profiles
        assert "whispers:tokenProfiles" in meta
        profiles = meta["whispers:tokenProfiles"]
        assert "external-agent" in profiles
        assert "read-only" in profiles
        assert "messages:send" in profiles["external-agent"]["scopes"]
        assert "messages:send" not in profiles["read-only"]["scopes"]
        # Token endpoint
        assert "whispers:tokenEndpoint" in meta
        assert "/connect" in meta["whispers:tokenEndpoint"]
        # Scoped tokens in features list
        assert "scoped_tokens" in meta["whispers:features"]


class TestAgentCardSecurity:
    """Test per-agent card security fields."""

    def test_agent_card_has_security_schemes(self):
        """Per-agent cards include Bearer auth security schemes."""
        from whispers.a2a import generate_agent_card
        agent = {"callsign": "test-agent", "agent_type": "test"}
        card = generate_agent_card(agent, "http://localhost:8752")
        assert "securitySchemes" in card
        assert "bearerToken" in card["securitySchemes"]
        assert card["securitySchemes"]["bearerToken"]["type"] == "http"
        assert card["securitySchemes"]["bearerToken"]["scheme"] == "bearer"

    def test_agent_card_has_security_requirements(self):
        """Per-agent cards include securityRequirements."""
        from whispers.a2a import generate_agent_card
        agent = {"callsign": "test-agent", "agent_type": "test"}
        card = generate_agent_card(agent, "http://localhost:8752")
        assert "securityRequirements" in card
        assert {"bearerToken": []} in card["securityRequirements"]

    def test_agent_card_scope_metadata(self):
        """Per-agent cards advertise required scopes and token endpoint."""
        from whispers.a2a import generate_agent_card
        agent = {"callsign": "test-agent", "agent_type": "test"}
        card = generate_agent_card(agent, "http://localhost:8752")
        meta = card["metadata"]
        assert "whispers:tokenEndpoint" in meta
        assert "whispers:requiredScopes" in meta
        assert "messages:send" in meta["whispers:requiredScopes"]
        assert "messages:read" in meta["whispers:requiredScopes"]

    def test_server_card_function_has_security(self):
        """generate_server_card() includes security sections."""
        from whispers.a2a import generate_server_card
        card = generate_server_card("http://localhost:8752")
        assert "securitySchemes" in card
        assert "securityRequirements" in card
        assert card["securitySchemes"]["bearerToken"]["scheme"] == "bearer"


# ===========================================================================
# Phase B: JSON-RPC 2.0 Gateway
# ===========================================================================


class TestJsonRpcGateway:
    """Phase B: JSON-RPC 2.0 gateway at /a2a/v1."""

    def test_invalid_jsonrpc_version(self, client):
        """Rejects requests without jsonrpc: 2.0."""
        resp = client.post("/a2a/v1", json={
            "jsonrpc": "1.0",
            "method": "message/send",
            "id": "test-1",
        })
        assert resp.status_code == 200  # JSON-RPC always returns 200
        data = resp.json()
        assert "error" in data
        assert data["error"]["code"] == JSONRPC_INVALID_REQUEST

    def test_method_not_found(self, client):
        """Unknown methods return -32601."""
        resp = client.post("/a2a/v1", json={
            "jsonrpc": "2.0",
            "method": "nonexistent/method",
            "id": "test-2",
        })
        assert resp.status_code == 200
        data = resp.json()
        assert "error" in data
        assert data["error"]["code"] == JSONRPC_METHOD_NOT_FOUND

    def test_parse_error(self, client):
        """Malformed JSON returns parse error."""
        resp = client.post(
            "/a2a/v1",
            content=b"not json at all",
            headers={"Content-Type": "application/json"},
        )
        assert resp.status_code == 200
        data = resp.json()
        assert "error" in data
        assert data["error"]["code"] == JSONRPC_PARSE_ERROR

    def test_message_send_missing_recipient(self, client):
        """message/send without recipient returns error."""
        resp = client.post("/a2a/v1", json={
            "jsonrpc": "2.0",
            "method": "message/send",
            "id": "test-3",
            "params": {
                "message": {
                    "role": "user",
                    "parts": [{"text": "Hello agent!"}],
                    "messageId": "msg-001",
                },
            },
        })
        assert resp.status_code == 200
        data = resp.json()
        assert "error" in data  # No recipient specified

    def test_tasks_get_missing_id(self, client):
        """tasks/get without taskId returns error."""
        resp = client.post("/a2a/v1", json={
            "jsonrpc": "2.0",
            "method": "tasks/get",
            "id": "test-4",
            "params": {},
        })
        assert resp.status_code == 200
        data = resp.json()
        assert "error" in data

    def test_jsonrpc_id_echo(self, client):
        """Server echoes back the request ID."""
        resp = client.post("/a2a/v1", json={
            "jsonrpc": "2.0",
            "method": "nonexistent/method",
            "id": "echo-this-123",
        })
        data = resp.json()
        assert data["id"] == "echo-this-123"
        assert data["jsonrpc"] == "2.0"

    def test_internal_errors_are_sanitized(self, client):
        """Unexpected handler exceptions should not leak raw internal details."""
        with patch(
            "whispers.registry.AgentRegistry.get_agent_by_callsign",
            return_value={"callsign": "bob", "trust_tier": 1},
        ), patch("whispers.client.WhispersClient.send") as mock_send, patch(
            "whispers.a2a._message_to_task",
            side_effect=RuntimeError("db path C:\\secret\\whispers.db"),
        ):
            mock_send.return_value = {
                "id": "msg-internal-1",
                "status": "queued",
                "trace_id": "trace-internal-1",
            }
            resp = client.post("/a2a/v1", json={
                "jsonrpc": "2.0",
                "method": "message/send",
                "id": "internal-err-1",
                "params": {
                    "message": {
                        "role": "user",
                        "messageId": "msg-001",
                        "metadata": {
                            "whispers:recipient": "bob",
                            "whispers:sender": "alice",
                        },
                        "parts": [{"text": "Hello agent!"}],
                    },
                },
            })
        assert resp.status_code == 200
        data = resp.json()
        assert data["error"]["code"] == JSONRPC_INTERNAL_ERROR
        assert data["error"]["message"] == "Internal error"
        assert "C:\\secret\\whispers.db" not in json.dumps(data)

    def test_message_send_missing_message(self, client):
        """message/send with no message param returns error."""
        resp = client.post("/a2a/v1", json={
            "jsonrpc": "2.0",
            "method": "message/send",
            "id": "test-no-msg",
            "params": {},
        })
        data = resp.json()
        assert "error" in data

    def test_message_send_non_dict_body(self, client):
        """Non-dict request body returns invalid request."""
        resp = client.post("/a2a/v1", json=[1, 2, 3])
        assert resp.status_code == 200
        data = resp.json()
        assert "error" in data
        assert data["error"]["code"] == JSONRPC_INVALID_REQUEST

    def test_request_body_too_large_is_rejected_before_json_parse(self, client):
        """Oversized A2A requests are rejected before full JSON parsing."""
        huge_text = "x" * (A2A_MAX_REQUEST_BYTES + 512)
        request_body = json.dumps({
            "jsonrpc": "2.0",
            "method": "message/send",
            "id": "too-large-1",
            "params": {
                "message": {
                    "role": "user",
                    "parts": [{"text": huge_text}],
                    "messageId": "msg-too-large-1",
                    "metadata": {"whispers:recipient": "nobody"},
                }
            },
        })
        resp = client.post(
            "/a2a/v1",
            content=request_body,
            headers={"Content-Type": "application/json"},
        )
        assert resp.status_code == 200
        data = resp.json()
        assert data["error"]["code"] == JSONRPC_INVALID_REQUEST
        assert data["error"]["message"] == "Request body too large"
        assert data["error"]["data"]["limit"] == A2A_MAX_REQUEST_BYTES

    def test_expired_twoack_message_is_rejected_during_preflight(self, client):
        """Expired 2ack envelopes are rejected before agent lookup or dispatch."""
        from unittest.mock import patch
        with patch("whispers.client.WhispersClient.send") as mock_send:
            resp = client.post("/a2a/v1", json={
                "jsonrpc": "2.0",
                "method": "message/send",
                "id": "expired-1",
                "params": {
                    "message": {
                        "role": "user",
                        "messageId": "outer-expired-1",
                        "metadata": {"whispers:recipient": "bob", "whispers:sender": "alice"},
                        "parts": [
                            {
                                "data": {
                                    "wire_v": 1,
                                    "schema": "status_update.v1",
                                    "expires_at": "2026-03-25T00:00:00Z",
                                    "trace": {"message_id": "msg-expired-a2a-1"},
                                    "payload": {"state": "idle"},
                                }
                            }
                        ],
                    }
                },
            })
        assert resp.status_code == 200
        data = resp.json()
        assert data["error"]["code"] == JSONRPC_INVALID_PARAMS
        assert data["error"]["message"] == "2ack preflight rejected"
        assert data["error"]["data"]["preflight_code"] == "ERR_EXPIRED"
        mock_send.assert_not_called()


# ===========================================================================
# Phase C: SSE Streaming (message/stream)
# ===========================================================================


class TestMessageStream:
    """Phase C: message/stream SSE streaming endpoint."""

    def test_stream_missing_recipient(self, client):
        """message/stream without recipient returns JSON-RPC error."""
        resp = client.post("/a2a/v1", json={
            "jsonrpc": "2.0",
            "method": "message/stream",
            "id": "stream-1",
            "params": {
                "message": {
                    "role": "user",
                    "parts": [{"text": "Hello!"}],
                    "messageId": "msg-stream-001",
                },
            },
        })
        # Even stream errors return 200 with JSON-RPC error body
        assert resp.status_code == 200
        data = resp.json()
        assert "error" in data

    def test_stream_missing_message(self, client):
        """message/stream with no message returns JSON-RPC error."""
        resp = client.post("/a2a/v1", json={
            "jsonrpc": "2.0",
            "method": "message/stream",
            "id": "stream-2",
            "params": {},
        })
        assert resp.status_code == 200
        data = resp.json()
        assert "error" in data

    def test_stream_nonexistent_agent(self, client):
        """message/stream to non-existent agent returns error."""
        resp = client.post("/a2a/v1", json={
            "jsonrpc": "2.0",
            "method": "message/stream",
            "id": "stream-3",
            "params": {
                "message": {
                    "role": "user",
                    "parts": [{"text": "Test message"}],
                    "messageId": "msg-stream-002",
                    "metadata": {
                        "whispers:recipient": "totally-fake-agent-xyz",
                    },
                },
            },
        })
        assert resp.status_code == 200
        data = resp.json()
        assert "error" in data

    def test_stream_echoes_request_id(self, client):
        """message/stream error responses echo the request ID."""
        req_id = "stream-echo-test-42"
        resp = client.post("/a2a/v1", json={
            "jsonrpc": "2.0",
            "method": "message/stream",
            "id": req_id,
            "params": {
                "message": {
                    "role": "user",
                    "parts": [{"text": "Hello!"}],
                    "messageId": "msg-004",
                },
            },
        })
        data = resp.json()
        assert data["id"] == req_id
        assert data["jsonrpc"] == "2.0"


# ===========================================================================
# Phase C: Outbound A2A Client
# ===========================================================================


class TestA2AClientUnit:
    """Phase C: A2AClient unit tests (no network)."""

    def test_client_init(self):
        """Client initializes with endpoint URL."""
        a2a = A2AClient("https://example.com/a2a/v1")
        assert a2a.endpoint_url == "https://example.com/a2a/v1"
        assert a2a.agent_card is None

    def test_client_strips_trailing_slash(self):
        """Endpoint URL trailing slash is stripped."""
        a2a = A2AClient("https://example.com/a2a/v1/")
        assert a2a.endpoint_url == "https://example.com/a2a/v1"

    def test_client_custom_timeout(self):
        """Custom timeout is respected."""
        a2a = A2AClient("https://example.com/a2a/v1", timeout=60.0)
        assert a2a.timeout == 60.0

    def test_discover_unreachable(self):
        """discover() raises ConnectionError for unreachable hosts."""
        a2a = A2AClient("https://this-does-not-exist.invalid/a2a/v1", timeout=2.0)
        with pytest.raises(ConnectionError):
            a2a.discover()

    def test_send_unreachable(self):
        """send() raises ConnectionError for unreachable hosts."""
        a2a = A2AClient("https://this-does-not-exist.invalid/a2a/v1", timeout=2.0)
        with pytest.raises(ConnectionError):
            a2a.send("Hello", metadata={"whispers:recipient": "test"})

    def test_stream_unreachable(self):
        """stream() raises ConnectionError for unreachable hosts."""
        a2a = A2AClient("https://this-does-not-exist.invalid/a2a/v1", timeout=2.0)
        with pytest.raises(ConnectionError):
            # Generator won't execute until iterated, but the HTTP call
            # happens at generator creation time in our implementation
            list(a2a.stream("Hello", metadata={"whispers:recipient": "test"}))


# ===========================================================================
# Phase C: Loopback Interop — A2AClient against local server
# ===========================================================================


class TestA2ALoopbackInterop:
    """Phase C: A2AClient talking to the local A2A gateway.

    This validates the full round-trip: outbound client → JSON-RPC →
    Whispers gateway → internal routing → response back to client.
    """

    def test_discover_local_server(self, client):
        """A2AClient can discover the local server's Agent Card."""
        # Use TestClient to fetch the card directly (no network)
        resp = client.get("/.well-known/agent-card.json")
        assert resp.status_code == 200
        card = resp.json()

        # Validate it's a real A2A Agent Card
        assert card["name"] == "Whispers Hub"
        assert "1.0" in card["protocolVersions"]
        assert card["capabilities"]["streaming"] is True

    def test_message_send_agent_not_found(self, client):
        """Sending to a non-existent agent returns proper A2A error."""
        resp = client.post("/a2a/v1", json={
            "jsonrpc": "2.0",
            "id": "interop-1",
            "method": "message/send",
            "params": {
                "message": {
                    "role": "user",
                    "parts": [{"text": "Hello from interop test!"}],
                    "messageId": "interop-msg-001",
                    "metadata": {
                        "whispers:recipient": "nonexistent-interop-agent",
                    },
                },
            },
        })
        assert resp.status_code == 200
        data = resp.json()
        assert "error" in data
        assert data["jsonrpc"] == "2.0"
        assert data["id"] == "interop-1"

    def test_stream_agent_not_found(self, client):
        """Streaming to a non-existent agent returns proper A2A error."""
        resp = client.post("/a2a/v1", json={
            "jsonrpc": "2.0",
            "id": "interop-2",
            "method": "message/stream",
            "params": {
                "message": {
                    "role": "user",
                    "parts": [{"text": "Stream interop test"}],
                    "messageId": "interop-msg-002",
                    "metadata": {
                        "whispers:recipient": "nonexistent-stream-agent",
                    },
                },
            },
        })
        assert resp.status_code == 200
        data = resp.json()
        assert "error" in data
        assert data["id"] == "interop-2"


# ===========================================================================
# Unit Tests: Core A2A Functions
# ===========================================================================


class TestCoreA2AFunctions:
    """Unit tests for the pure A2A helper functions."""

    def test_generate_server_card_structure(self):
        """generate_server_card returns a valid Agent Card."""
        card = generate_server_card("https://whispers.works")
        assert card["name"] == "Whispers Hub"
        assert card["url"] == "https://whispers.works/a2a/v1"
        assert "1.0" in card["protocolVersions"]
        assert card["capabilities"]["streaming"] is True
        assert card["metadata"]["whispers:type"] == "hub"
        assert "supportedInterfaces" in card

    def test_generate_agent_card_minimal(self):
        """generate_agent_card works with minimal agent data."""
        agent = {
            "callsign": "test-agent",
            "agent_type": "mcp_client",
        }
        card = generate_agent_card(agent, "https://whispers.works")
        assert card["name"] == "test-agent"
        assert card["url"] == "https://whispers.works/a2a/v1"
        assert card["metadata"]["whispers:callsign"] == "test-agent"

    def test_generate_agent_card_with_presence(self):
        """generate_agent_card includes presence data when available."""
        agent = {"callsign": "alice", "agent_type": "mcp_client", "trust_tier": 3}
        presence = {
            "status": "online",
            "last_active": "2026-03-22T12:00:00Z",
            "reception_mode": "focused",
        }
        card = generate_agent_card(agent, "https://w.example.com", presence=presence)
        meta = card["metadata"]
        assert meta["whispers:presence"] == "online"
        assert meta["whispers:signalMode"] == "focused"
        assert meta["whispers:trustTier"] == 3

    def test_generate_agent_card_includes_participant_kind_and_profiles(self):
        """generate_agent_card exposes participant-kind and explicit profile tags."""
        agent = {
            "callsign": "alice",
            "agent_type": "mcp_client",
            "trust_tier": 3,
            "tags": ["profile:approval_surface", "status_source", "team:redwood"],
        }

        card = generate_agent_card(agent, "https://w.example.com")
        meta = card["metadata"]

        assert meta["whispers:participantKind"] == "agent"
        assert meta["whispers:isPrimaryParticipant"] is True
        assert meta["whispers:participantProfiles"] == ["approval_surface", "status_source"]
        assert meta["whispers:tags"] == ["profile:approval_surface", "status_source", "team:redwood"]

    def test_whispers_to_a2a_state_mapping(self):
        """State mapping covers all expected Whispers → A2A transitions."""
        assert _whispers_to_a2a_state("queued", "new") == TASK_SUBMITTED
        assert _whispers_to_a2a_state("delivered", "new") == TASK_SUBMITTED
        assert _whispers_to_a2a_state("delivered", "read") == TASK_WORKING
        assert _whispers_to_a2a_state("delivered", "replied") == TASK_COMPLETED
        assert _whispers_to_a2a_state("dead_lettered", "new") == TASK_FAILED
        # Unknown combo defaults to SUBMITTED
        assert _whispers_to_a2a_state("unknown", "unknown") == TASK_SUBMITTED

    def test_message_to_task(self):
        """_message_to_task produces a valid A2A Task object."""
        msg = {
            "uuid": "msg-123",
            "from_agent": "alice",
            "to_agent": "bob",
            "subject": "Test Task",
            "body": "Do something",
            "delivery_status": "delivered",
            "status": "new",
            "priority": "routine",
        }
        task = _message_to_task(msg, task_id="task-abc")
        assert task["id"] == "task-abc"
        assert task["status"]["state"] == TASK_SUBMITTED
        assert "timestamp" in task["status"]
        assert len(task["artifacts"]) == 1
        assert task["artifacts"][0]["parts"][0]["text"] == "Do something"
        assert task["metadata"]["whispers:sender"] == "alice"
        assert task["metadata"]["whispers:recipient"] == "bob"
        assert task["metadata"]["whispers:priority"] == "routine"

    def test_message_to_task_no_body(self):
        """_message_to_task works with messages that have no body."""
        msg = {
            "uuid": "msg-456",
            "from_agent": "alice",
            "to_agent": "bob",
            "delivery_status": "queued",
            "status": "new",
        }
        task = _message_to_task(msg)
        assert task["id"] == "msg-456"
        assert task["status"]["state"] == TASK_SUBMITTED
        assert task["artifacts"] == []

    def test_jsonrpc_response_structure(self):
        """JSON-RPC response has correct structure."""
        resp = _jsonrpc_response({"key": "value"}, "req-1")
        assert resp["jsonrpc"] == "2.0"
        assert resp["id"] == "req-1"
        assert resp["result"] == {"key": "value"}
        assert "error" not in resp

    def test_jsonrpc_error_structure(self):
        """JSON-RPC error has correct structure."""
        err = _jsonrpc_error(-32600, "Invalid Request", "req-2", data={"extra": True})
        assert err["jsonrpc"] == "2.0"
        assert err["id"] == "req-2"
        assert err["error"]["code"] == -32600
        assert err["error"]["message"] == "Invalid Request"
        assert err["error"]["data"]["extra"] is True

    def test_jsonrpc_error_no_data(self):
        """JSON-RPC error omits data field when None."""
        err = _jsonrpc_error(-32700, "Parse error")
        assert "data" not in err["error"]
        assert err["id"] is None  # Default request_id

    def test_task_state_constants(self):
        """Task state constants use v1.0 SCREAMING_SNAKE_CASE."""
        assert TASK_SUBMITTED == "TASK_STATE_SUBMITTED"
        assert TASK_WORKING == "TASK_STATE_WORKING"
        assert TASK_COMPLETED == "TASK_STATE_COMPLETED"
        assert TASK_FAILED == "TASK_STATE_FAILED"
        assert TASK_CANCELED == "TASK_STATE_CANCELED"
        assert TASK_REJECTED == "TASK_STATE_REJECTED"

    def test_error_code_constants(self):
        """JSON-RPC and A2A error codes are correct."""
        assert JSONRPC_PARSE_ERROR == -32700
        assert JSONRPC_INVALID_REQUEST == -32600
        assert JSONRPC_METHOD_NOT_FOUND == -32601
        assert JSONRPC_INVALID_PARAMS == -32602
        assert JSONRPC_INTERNAL_ERROR == -32603
        assert A2A_TASK_NOT_FOUND == 40401
        assert A2A_TASK_NOT_CANCELABLE == 40900

    def test_protocol_version(self):
        """Protocol version constants are correct."""
        assert A2A_PROTOCOL_VERSION == "1.0"


# ===========================================================================
# Phase C: A2AClient Discovery URL Derivation
# ===========================================================================


class TestA2AClientDiscoveryUrls:
    """Validate that A2AClient correctly derives the well-known URL."""

    def test_strips_a2a_v1_suffix(self):
        """Derive base URL from endpoint ending in /a2a/v1."""
        a2a = A2AClient("https://agent.example.com/a2a/v1")
        # We can't call discover() without network, but we can verify the
        # endpoint_url stripping works via the internal logic.
        # The discover method strips /a2a/v1 before appending /.well-known/...
        assert a2a.endpoint_url == "https://agent.example.com/a2a/v1"

    def test_strips_a2a_suffix(self):
        """Handles endpoints ending in just /a2a."""
        a2a = A2AClient("https://agent.example.com/a2a")
        assert a2a.endpoint_url == "https://agent.example.com/a2a"
