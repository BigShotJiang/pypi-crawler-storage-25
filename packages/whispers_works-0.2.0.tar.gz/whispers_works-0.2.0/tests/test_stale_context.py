"""Tests for stale-context rejection and version truth.

Covers:
- Baton version monotonicity
- Current-version pickup success
- Stale-version rejection after mutation
- Operator snapshot sequence monotonicity
"""

import asyncio
import time

import pytest

from whispers.transports.operator import (
    OperatorSSETransport,
    OperatorBoardSnapshot,
    OperatorEventType,
    empty_system_counters,
)


# ---------------------------------------------------------------------------
# Operator snapshot sequence monotonicity
# ---------------------------------------------------------------------------


class TestOperatorSequence:
    def test_sequence_starts_at_zero(self):
        transport = OperatorSSETransport()
        assert transport.sequence_id == 0

    def test_sequence_increments_on_push(self):
        transport = OperatorSSETransport()
        transport.push("agent:wag", {"agent": "a"})
        assert transport.sequence_id == 1
        transport.push("agent:wag", {"agent": "a"})
        assert transport.sequence_id == 2

    def test_sequence_is_monotonic_across_event_types(self):
        transport = OperatorSSETransport()
        seqs = []
        for etype in [
            OperatorEventType.AGENT_WAG,
            OperatorEventType.HEALTH_RAISED,
            OperatorEventType.REVIEW_PUBLISHED,
            OperatorEventType.AGENT_HEARTBEAT,
        ]:
            transport.push(etype, {})
            seqs.append(transport.sequence_id)

        assert seqs == [1, 2, 3, 4]
        # Strictly monotonic — no duplicates, no gaps
        for i in range(1, len(seqs)):
            assert seqs[i] > seqs[i - 1]

    def test_events_carry_sequence_id(self):
        transport = OperatorSSETransport()
        q = asyncio.Queue()
        transport.add_listener("console", q)

        transport.push("agent:wag", {})
        transport.push("health:scan_complete", {})

        e1 = q.get_nowait()
        e2 = q.get_nowait()
        assert e1["seq"] == 1
        assert e2["seq"] == 2

    def test_board_snapshot_includes_sequence(self):
        transport = OperatorSSETransport()
        transport.board.set_builder(
            lambda: {"agents": {}, "system": empty_system_counters()},
            seq_fn=lambda: transport.sequence_id,
        )

        transport.push("agent:wag", {})
        transport.push("agent:wag", {})
        snap = transport.board.get()

        assert snap["sequence_id"] == 2
        assert snap["as_of"] is not None

    def test_board_snapshot_sequence_updates_on_invalidation(self):
        transport = OperatorSSETransport()
        transport.board.set_builder(
            lambda: {"agents": {}, "system": empty_system_counters()},
            seq_fn=lambda: transport.sequence_id,
        )

        snap1 = transport.board.get()
        assert snap1["sequence_id"] == 0

        transport.push("agent:wag", {})
        snap2 = transport.board.get()
        assert snap2["sequence_id"] == 1


# ---------------------------------------------------------------------------
# Baton version truth (DB integration)
# ---------------------------------------------------------------------------


def _send_test_handoff(sender, subject="test"):
    """Helper: send a handoff with all required fields."""
    return sender.send_handoff(
        to="bob",
        subject=subject,
        objective="test objective",
        deliverable="test deliverable",
        completed="done so far",
        remaining="what's left",
        next_action="do it",
    )


class TestBatonVersion:
    @pytest.fixture
    def db_and_client(self, temp_db):
        from whispers.storage.db import WhispersDB
        from whispers.client import WhispersClient

        db_path = temp_db
        db = WhispersDB(db_path=db_path)
        sender = WhispersClient("alice", db_path=db_path)
        receiver = WhispersClient("bob", db_path=db_path)
        return db, sender, receiver

    def test_baton_starts_at_version_1(self, db_and_client):
        db, sender, receiver = db_and_client
        result = _send_test_handoff(sender, "test handoff")
        baton_ref = result["id"]
        version = db.get_baton_version(baton_ref)
        assert version == 1

    def test_version_increments_on_ack(self, db_and_client):
        db, sender, receiver = db_and_client
        result = _send_test_handoff(sender, "test handoff")
        baton_ref = result["id"]
        assert db.get_baton_version(baton_ref) == 1

        receiver.baton_ack(baton_ref, "accepted", reason="on it")
        assert db.get_baton_version(baton_ref) == 2

    def test_version_increments_on_update(self, db_and_client):
        db, sender, receiver = db_and_client
        result = _send_test_handoff(sender, "test handoff")
        baton_ref = result["id"]
        receiver.baton_ack(baton_ref, "accepted")
        assert db.get_baton_version(baton_ref) == 2

        receiver.baton_update(baton_ref, "in_progress", progress="halfway done")
        assert db.get_baton_version(baton_ref) == 3

    def test_version_increments_on_close(self, db_and_client):
        db, sender, receiver = db_and_client
        result = _send_test_handoff(sender, "test handoff")
        baton_ref = result["id"]
        receiver.baton_ack(baton_ref, "accepted")
        receiver.baton_close(baton_ref, "completed", summary="done")
        assert db.get_baton_version(baton_ref) == 3  # ack=2, close=3

    def test_version_not_found_returns_none(self, db_and_client):
        db, _, _ = db_and_client
        assert db.get_baton_version("nonexistent-ref") is None

    def test_version_is_monotonic_through_lifecycle(self, db_and_client):
        db, sender, receiver = db_and_client
        result = _send_test_handoff(sender, "lifecycle test")
        baton_ref = result["id"]
        versions = [db.get_baton_version(baton_ref)]

        receiver.baton_ack(baton_ref, "accepted")
        versions.append(db.get_baton_version(baton_ref))

        receiver.baton_update(baton_ref, "in_progress", progress="working")
        versions.append(db.get_baton_version(baton_ref))

        receiver.baton_update(baton_ref, "review_pending", progress="ready for review")
        versions.append(db.get_baton_version(baton_ref))

        receiver.baton_close(baton_ref, "completed", summary="shipped")
        versions.append(db.get_baton_version(baton_ref))

        assert versions == [1, 2, 3, 4, 5]
        for i in range(1, len(versions)):
            assert versions[i] > versions[i - 1]


# ---------------------------------------------------------------------------
# Stale-context rejection (server integration)
# ---------------------------------------------------------------------------


class TestStaleContextRejection:
    @pytest.fixture
    def test_app(self, temp_db, monkeypatch):
        """Create a test DB and patch the server's db proxy."""
        from whispers.storage.db import WhispersDB
        from whispers.client import WhispersClient
        import whispers.server as server_mod

        db_path = temp_db
        db = WhispersDB(db_path=db_path)
        sender = WhispersClient("alice", db_path=db_path)
        receiver = WhispersClient("bob", db_path=db_path)

        # Patch the module-level db proxy so _check_baton_version sees our test DB
        monkeypatch.setattr(server_mod, "db", db)

        return db, sender, receiver

    def test_current_version_accepted(self, test_app):
        """When expected_version matches current, no exception raised."""
        from whispers.server import _check_baton_version
        db, sender, receiver = test_app

        result = _send_test_handoff(sender, "version check")
        baton_ref = result["id"]

        # This should NOT raise — version matches
        _check_baton_version(baton_ref, 1)

    def test_stale_version_rejected_after_ack(self, test_app):
        """After a baton mutation, old version is rejected with 409."""
        from fastapi import HTTPException
        from whispers.server import _check_baton_version
        db, sender, receiver = test_app

        result = _send_test_handoff(sender, "stale check")
        baton_ref = result["id"]

        # Ack bumps version to 2
        receiver.baton_ack(baton_ref, "accepted")

        # Trying with old version should fail
        with pytest.raises(HTTPException) as exc_info:
            _check_baton_version(baton_ref, 1)

        assert exc_info.value.status_code == 409
        detail = exc_info.value.detail
        assert detail["error"] == "stale_context"
        assert detail["expected_version"] == 1
        assert detail["current_version"] == 2

    def test_stale_version_rejected_after_update(self, test_app):
        from fastapi import HTTPException
        from whispers.server import _check_baton_version
        db, sender, receiver = test_app

        result = _send_test_handoff(sender, "stale after update")
        baton_ref = result["id"]
        receiver.baton_ack(baton_ref, "accepted")  # v2
        receiver.baton_update(baton_ref, "in_progress")  # v3

        # Version 2 is now stale
        with pytest.raises(HTTPException) as exc_info:
            _check_baton_version(baton_ref, 2)
        assert exc_info.value.status_code == 409
        assert exc_info.value.detail["current_version"] == 3

    def test_no_version_check_when_omitted(self, test_app):
        """When expected_version is None, no check is performed."""
        from whispers.server import _check_baton_version
        db, sender, receiver = test_app

        result = _send_test_handoff(sender, "no check")
        baton_ref = result["id"]
        receiver.baton_ack(baton_ref, "accepted")  # v2

        # None means opt-out — should not raise even though version changed
        _check_baton_version(baton_ref, None)

    def test_nonexistent_baton_returns_404(self, test_app):
        from fastapi import HTTPException
        from whispers.server import _check_baton_version

        with pytest.raises(HTTPException) as exc_info:
            _check_baton_version("nonexistent-ref", 1)
        assert exc_info.value.status_code == 404

    def test_invalid_version_returns_400(self, test_app):
        from fastapi import HTTPException
        from whispers.server import _check_baton_version

        with pytest.raises(HTTPException) as exc_info:
            _check_baton_version("any-ref", "not-a-number")
        assert exc_info.value.status_code == 400

    def test_rejection_message_enables_reorientation(self, test_app):
        """The rejection detail contains enough info for the caller to recover."""
        from fastapi import HTTPException
        from whispers.server import _check_baton_version
        db, sender, receiver = test_app

        result = _send_test_handoff(sender, "recovery info")
        baton_ref = result["id"]
        receiver.baton_ack(baton_ref, "accepted")

        with pytest.raises(HTTPException) as exc_info:
            _check_baton_version(baton_ref, 1)

        detail = exc_info.value.detail
        # Caller gets: what they expected, what's current, which baton, actionable message
        assert "baton_ref" in detail
        assert "current_version" in detail
        assert "expected_version" in detail
        assert "Re-read" in detail["message"]
