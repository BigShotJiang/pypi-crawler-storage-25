"""
Tests for connect, doctor --fix, and recovery-state plumbing.
(Codex assignment: backend connect repair recovery tranche)

Coverage:
  - whispers connect: server unreachable → clear error, no profile saved
  - whispers connect: token missing in response → explicit rejection
  - whispers connect: token verification (whoami) failure → not saved
  - whispers connect: happy path → profile saved, token verified
  - whispers doctor --fix: server down → auto-start attempted
  - whispers doctor --fix: MCP config drift → repaired
  - whispers doctor: server_state enum derivation (up/degraded/recovering/down)
  - whispers doctor --fix: cold-start DB + server creation
"""

import json
import shutil
import uuid
from pathlib import Path

import pytest
from click.testing import CliRunner

import whispers.cli as cli_module
from whispers.storage.db import WhispersDB


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_case_dir() -> Path:
    root = Path(__file__).resolve().parents[1] / ".tmp"
    root.mkdir(parents=True, exist_ok=True)
    case_dir = root / f"crr-{uuid.uuid4().hex}"
    case_dir.mkdir(parents=True, exist_ok=False)
    return case_dir


# ---------------------------------------------------------------------------
# connect: server reachability checks
# ---------------------------------------------------------------------------

class TestConnectServerReachability:
    def test_connect_unreachable_server_fails_clearly(self, monkeypatch):
        """connect must fail at preflight if server is unreachable — no profile saved."""
        case_dir = _make_case_dir()
        profiles_path = case_dir / "profiles.json"
        credentials_path = case_dir / "credentials.json"
        try:
            monkeypatch.setenv("WHISPERS_PROFILES_PATH", str(profiles_path))
            monkeypatch.setenv("WHISPERS_CREDENTIALS_PATH", str(credentials_path))
            # Server is unreachable
            monkeypatch.setattr(cli_module, "_remote_server_health", lambda server: None)

            runner = CliRunner()
            result = runner.invoke(
                cli_module.cli,
                ["connect", "--server", "http://mesh.example", "--agent-name", "codex"],
            )

            assert result.exit_code != 0
            assert "Cannot reach Whispers server" in result.output
            # Profile must NOT have been saved
            assert not profiles_path.exists()
        finally:
            shutil.rmtree(case_dir, ignore_errors=True)

    def test_connect_missing_token_in_response_fails(self, monkeypatch):
        """connect fails explicitly when server returns no auth token."""
        case_dir = _make_case_dir()
        profiles_path = case_dir / "profiles.json"
        credentials_path = case_dir / "credentials.json"
        try:
            monkeypatch.setenv("WHISPERS_PROFILES_PATH", str(profiles_path))
            monkeypatch.setenv("WHISPERS_CREDENTIALS_PATH", str(credentials_path))
            monkeypatch.setattr(
                cli_module, "_remote_server_health",
                lambda server: {"ok": True, "peers_online_count": 0}
            )
            # Server returns no token
            monkeypatch.setattr(
                cli_module, "_server_connect",
                lambda server, payload: {
                    "agent_name": "codex",
                    "token": None,   # <-- missing token
                    "token_status": "new",
                    "session": {"session_id": "s1", "lease_expires_at": "2099-01-01T00:00:00Z"},
                    "status": {},
                },
            )

            runner = CliRunner()
            result = runner.invoke(
                cli_module.cli,
                ["connect", "--server", "http://mesh.example", "--agent-name", "codex"],
            )

            assert result.exit_code != 0
            assert "no auth token" in result.output.lower() or "no auth token" in str(result.exception).lower()
            assert not profiles_path.exists()
        finally:
            shutil.rmtree(case_dir, ignore_errors=True)

    def test_connect_whoami_verification_failure_does_not_save_profile(self, monkeypatch):
        """connect must not persist the profile when /whoami verification fails."""
        case_dir = _make_case_dir()
        profiles_path = case_dir / "profiles.json"
        credentials_path = case_dir / "credentials.json"
        try:
            monkeypatch.setenv("WHISPERS_PROFILES_PATH", str(profiles_path))
            monkeypatch.setenv("WHISPERS_CREDENTIALS_PATH", str(credentials_path))
            monkeypatch.setattr(
                cli_module, "_remote_server_health",
                lambda server: {"ok": True, "peers_online_count": 1}
            )
            monkeypatch.setattr(
                cli_module, "_server_connect",
                lambda server, payload: {
                    "agent_name": "codex",
                    "token": "bad-token",
                    "token_status": "new",
                    "session": {"session_id": "s1", "lease_expires_at": "2099-01-01T00:00:00Z"},
                    "status": {},
                },
            )
            # /whoami returns an unexpected structure
            monkeypatch.setattr(
                cli_module, "_server_request",
                lambda server, path, **kwargs: {} if "/whoami" in path else None,
            )

            runner = CliRunner()
            result = runner.invoke(
                cli_module.cli,
                ["connect", "--server", "http://mesh.example", "--agent-name", "codex"],
            )

            assert result.exit_code != 0
            assert "Token verification failed" in result.output
            assert not profiles_path.exists()
        finally:
            shutil.rmtree(case_dir, ignore_errors=True)

    def test_connect_happy_path_saves_profile_and_confirms_token(self, monkeypatch):
        """connect happy path: server healthy, token returned and verified, profile saved."""
        case_dir = _make_case_dir()
        profiles_path = case_dir / "profiles.json"
        credentials_path = case_dir / "credentials.json"
        try:
            monkeypatch.setenv("WHISPERS_PROFILES_PATH", str(profiles_path))
            monkeypatch.setenv("WHISPERS_CREDENTIALS_PATH", str(credentials_path))
            monkeypatch.setattr(
                cli_module, "_remote_server_health",
                lambda server: {"ok": True, "peers_online_count": 2}
            )
            monkeypatch.setattr(
                cli_module, "_server_connect",
                lambda server, payload: {
                    "agent_name": "codex",
                    "token": "valid-token-xyz",
                    "token_status": "new",
                    "session": {"session_id": "s-abc123", "lease_expires_at": "2099-01-01T00:00:00Z"},
                    "status": {"pending_messages": 3, "peers_online_count": 2},
                    "capabilities": {},
                    "policy": {},
                },
            )
            monkeypatch.setattr(
                cli_module, "_server_request",
                lambda server, path, **kwargs: {"agent_name": "codex"} if "/whoami" in path else None,
            )

            runner = CliRunner()
            result = runner.invoke(
                cli_module.cli,
                ["connect", "--server", "http://mesh.example", "--agent-name", "codex"],
            )

            assert result.exit_code == 0
            assert "Connected to http://mesh.example as codex" in result.output
            assert "Token verified" in result.output
            # Profile was saved
            assert profiles_path.exists()
            profiles = json.loads(profiles_path.read_text(encoding="utf-8"))
            assert profiles["profiles"]["default"]["agent_name"] == "codex"
            # Credentials were saved
            assert credentials_path.exists()
            creds = json.loads(credentials_path.read_text(encoding="utf-8"))
            assert creds["profiles"]["default"]["token"] == "valid-token-xyz"
        finally:
            shutil.rmtree(case_dir, ignore_errors=True)


# ---------------------------------------------------------------------------
# doctor --fix: server auto-start
# ---------------------------------------------------------------------------

class TestDoctorFixServerStart:
    def test_doctor_fix_starts_server_when_down(self, monkeypatch):
        """doctor --fix attempts to start the server when it's not running."""
        case_dir = _make_case_dir()
        db_path = case_dir / "whispers.db"
        try:
            monkeypatch.setenv("WHISPERS_DB_PATH", str(db_path))
            monkeypatch.setenv("WHISPERS_MCP_TOKEN", "tok-123")

            # Server is down initially; _ensure_server_running succeeds; second health check passes
            health_calls = [None, {"db_path": str(db_path), "status": "ok"}]
            health_iter = iter(health_calls)

            def _fake_health():
                try:
                    return next(health_iter)
                except StopIteration:
                    return {"db_path": str(db_path), "status": "ok"}

            monkeypatch.setattr(cli_module, "_check_server_health", _fake_health)
            monkeypatch.setattr(cli_module, "_ensure_server_running", lambda: True)
            monkeypatch.setattr(cli_module, "_check_mcp_handshake", lambda token: 13)
            monkeypatch.setattr(cli_module, "_PLATFORMS", {})

            runner = CliRunner()
            result = runner.invoke(cli_module.cli, ["doctor", "--fix", "--agent-name", "codex"])

            assert result.exit_code == 0
            payload = json.loads(result.output)
            assert payload["server_running"] is True
            assert any("Started server" in fix for fix in payload["fixes_applied"])
            assert payload["server_state"] in ("recovering", "up", "degraded")
        finally:
            shutil.rmtree(case_dir, ignore_errors=True)

    def test_doctor_fix_reports_failure_when_server_will_not_start(self, monkeypatch):
        """doctor --fix reports an issue when auto-start fails."""
        case_dir = _make_case_dir()
        db_path = case_dir / "whispers.db"
        try:
            monkeypatch.setenv("WHISPERS_DB_PATH", str(db_path))
            monkeypatch.setattr(cli_module, "_check_server_health", lambda: None)
            monkeypatch.setattr(cli_module, "_ensure_server_running", lambda: False)
            monkeypatch.setattr(cli_module, "_PLATFORMS", {})

            runner = CliRunner()
            result = runner.invoke(cli_module.cli, ["doctor", "--fix", "--agent-name", "codex"])

            assert result.exit_code == 0
            payload = json.loads(result.output)
            assert payload["server_running"] is False
            assert payload["server_state"] == "down"
            assert any("auto-start failed" in issue or "auto-start" in issue.lower() for issue in payload["issues"])
        finally:
            shutil.rmtree(case_dir, ignore_errors=True)


# ---------------------------------------------------------------------------
# doctor --fix: MCP config drift repair
# ---------------------------------------------------------------------------

class TestDoctorFixMcpDrift:
    def test_doctor_fix_repairs_drifted_mcp_config(self, monkeypatch):
        """doctor --fix repairs an MCP config entry whose URL/token has drifted."""
        case_dir = _make_case_dir()
        db_path = case_dir / "whispers.db"
        config_path = case_dir / ".cursor" / "mcp.json"
        config_path.parent.mkdir(parents=True, exist_ok=True)
        # Write a drifted config entry (wrong token)
        config_path.write_text(
            json.dumps({
                "mcpServers": {
                    "whispers": {
                        "type": "http",
                        "url": "http://127.0.0.1:8752/mcp/?agent=cursor",
                        "headers": {"Authorization": "Bearer OLD-STALE-TOKEN"},
                    }
                }
            }, indent=2) + "\n",
            encoding="utf-8",
        )

        inject_calls = []

        def _fake_inject(target, token, quiet=False, use_stdio=False):
            inject_calls.append(target)
            return {"status": "configured", "config_path": str(config_path)}

        try:
            monkeypatch.setenv("WHISPERS_DB_PATH", str(db_path))
            monkeypatch.setenv("WHISPERS_MCP_TOKEN", "NEW-FRESH-TOKEN")
            monkeypatch.setattr(
                cli_module, "_check_server_health",
                lambda: {"db_path": str(db_path), "status": "ok"}
            )
            monkeypatch.setattr(cli_module, "_check_mcp_handshake", lambda token: 13)
            monkeypatch.setattr(cli_module, "_inject_mcp_config", _fake_inject)
            monkeypatch.setattr(
                cli_module,
                "_PLATFORMS",
                {
                    "cursor": {
                        "config": str(config_path),
                        "config_format": "json",
                        "config_key": "mcpServers",
                        "default_agent": "cursor",
                        "display_name": "Cursor",
                    }
                },
            )

            runner = CliRunner()
            result = runner.invoke(cli_module.cli, ["doctor", "--fix", "--agent-name", "codex"])

            assert result.exit_code == 0
            payload = json.loads(result.output)
            # Fix was applied for the drifted cursor config
            assert any("Repaired MCP config" in fix for fix in payload["fixes_applied"])
            assert "cursor" in inject_calls
        finally:
            shutil.rmtree(case_dir, ignore_errors=True)

    def test_doctor_fix_does_not_inject_config_when_whispers_absent(self, monkeypatch):
        """doctor --fix must NOT inject Whispers config into hosts where it wasn't present."""
        case_dir = _make_case_dir()
        db_path = case_dir / "whispers.db"
        config_path = case_dir / ".cursor" / "mcp.json"
        config_path.parent.mkdir(parents=True, exist_ok=True)
        # Config exists but Whispers is NOT in it
        config_path.write_text(
            json.dumps({"mcpServers": {"other-server": {"url": "http://other"}}}, indent=2) + "\n",
            encoding="utf-8",
        )

        inject_calls = []

        def _fake_inject(target, token, quiet=False, use_stdio=False):
            inject_calls.append(target)
            return {"status": "configured", "config_path": str(config_path)}

        try:
            monkeypatch.setenv("WHISPERS_DB_PATH", str(db_path))
            monkeypatch.setenv("WHISPERS_MCP_TOKEN", "NEW-FRESH-TOKEN")
            monkeypatch.setattr(
                cli_module, "_check_server_health",
                lambda: {"db_path": str(db_path), "status": "ok"}
            )
            monkeypatch.setattr(cli_module, "_check_mcp_handshake", lambda token: 13)
            monkeypatch.setattr(cli_module, "_inject_mcp_config", _fake_inject)
            monkeypatch.setattr(
                cli_module,
                "_PLATFORMS",
                {
                    "cursor": {
                        "config": str(config_path),
                        "config_format": "json",
                        "config_key": "mcpServers",
                        "default_agent": "cursor",
                        "display_name": "Cursor",
                    }
                },
            )

            runner = CliRunner()
            result = runner.invoke(cli_module.cli, ["doctor", "--fix", "--agent-name", "codex"])

            assert result.exit_code == 0
            # Must NOT have injected into a config that didn't already have Whispers
            assert "cursor" not in inject_calls
        finally:
            shutil.rmtree(case_dir, ignore_errors=True)


# ---------------------------------------------------------------------------
# doctor: server_state enum derivation
# ---------------------------------------------------------------------------

class TestDoctorServerState:
    def test_server_state_down_when_unreachable(self, monkeypatch):
        case_dir = _make_case_dir()
        db_path = case_dir / "whispers.db"
        try:
            monkeypatch.setenv("WHISPERS_DB_PATH", str(db_path))
            monkeypatch.setattr(cli_module, "_check_server_health", lambda: None)
            monkeypatch.setattr(cli_module, "_PLATFORMS", {})

            runner = CliRunner()
            result = runner.invoke(cli_module.cli, ["doctor", "--agent-name", "codex"])

            assert result.exit_code == 0
            payload = json.loads(result.output)
            assert payload["server_state"] == "down"
            assert payload["server_running"] is False
        finally:
            shutil.rmtree(case_dir, ignore_errors=True)

    def test_server_state_up_when_healthy(self, monkeypatch):
        case_dir = _make_case_dir()
        db_path = case_dir / "whispers.db"
        try:
            monkeypatch.setenv("WHISPERS_DB_PATH", str(db_path))
            monkeypatch.setenv("WHISPERS_MCP_TOKEN", "tok-ok")
            monkeypatch.setattr(
                cli_module, "_check_server_health",
                lambda: {"db_path": str(db_path), "status": "ok"}
            )
            monkeypatch.setattr(cli_module, "_check_mcp_handshake", lambda token: 13)
            monkeypatch.setattr(cli_module, "_probe_local_client_auth", lambda name: {"ok": True, "source": "mock"})
            monkeypatch.setattr(cli_module, "_PLATFORMS", {})

            runner = CliRunner()
            result = runner.invoke(cli_module.cli, ["doctor", "--agent-name", "codex"])

            assert result.exit_code == 0
            payload = json.loads(result.output)
            assert payload["server_running"] is True
            assert payload["server_state"] == "up"
        finally:
            shutil.rmtree(case_dir, ignore_errors=True)

    def test_server_state_degraded_when_mcp_broken(self, monkeypatch):
        case_dir = _make_case_dir()
        db_path = case_dir / "whispers.db"
        try:
            monkeypatch.setenv("WHISPERS_DB_PATH", str(db_path))
            monkeypatch.setenv("WHISPERS_MCP_TOKEN", "tok-bad")
            monkeypatch.setattr(
                cli_module, "_check_server_health",
                lambda: {"db_path": str(db_path), "status": "ok"}
            )
            monkeypatch.setattr(cli_module, "_check_mcp_handshake", lambda token: None)  # MCP broken
            monkeypatch.setattr(cli_module, "_PLATFORMS", {})

            runner = CliRunner()
            result = runner.invoke(cli_module.cli, ["doctor", "--agent-name", "codex"])

            assert result.exit_code == 0
            payload = json.loads(result.output)
            assert payload["server_running"] is True
            assert payload["server_state"] == "degraded"
            assert payload["mcp_healthy"] is False
        finally:
            shutil.rmtree(case_dir, ignore_errors=True)

    def test_server_state_degraded_on_db_mismatch(self, monkeypatch):
        case_dir = _make_case_dir()
        local_db = case_dir / "local.db"
        server_db = case_dir / "server.db"
        try:
            monkeypatch.setenv("WHISPERS_DB_PATH", str(local_db))
            monkeypatch.setenv("WHISPERS_MCP_TOKEN", "tok-ok")
            monkeypatch.setattr(
                cli_module, "_check_server_health",
                lambda: {"db_path": str(server_db), "status": "ok"}
            )
            monkeypatch.setattr(cli_module, "_check_mcp_handshake", lambda token: 13)
            monkeypatch.setattr(cli_module, "_PLATFORMS", {})

            runner = CliRunner()
            result = runner.invoke(cli_module.cli, ["doctor", "--agent-name", "codex"])

            assert result.exit_code == 0
            payload = json.loads(result.output)
            assert payload["server_state"] == "degraded"
            assert payload["server_db_matches_local"] is False
        finally:
            shutil.rmtree(case_dir, ignore_errors=True)

    def test_server_state_recovering_after_fix_starts_server(self, monkeypatch):
        """When --fix starts the server, server_state should be 'recovering'."""
        case_dir = _make_case_dir()
        db_path = case_dir / "whispers.db"
        try:
            monkeypatch.setenv("WHISPERS_DB_PATH", str(db_path))
            monkeypatch.setenv("WHISPERS_MCP_TOKEN", "tok-123")

            # Server is down but _ensure_server_running succeeds
            health_responses = [None, {"db_path": str(db_path), "status": "ok"}]
            health_iter = iter(health_responses)

            def _fake_health():
                try:
                    return next(health_iter)
                except StopIteration:
                    return {"db_path": str(db_path), "status": "ok"}

            monkeypatch.setattr(cli_module, "_check_server_health", _fake_health)
            monkeypatch.setattr(cli_module, "_ensure_server_running", lambda: True)
            monkeypatch.setattr(cli_module, "_check_mcp_handshake", lambda token: 13)
            monkeypatch.setattr(cli_module, "_probe_local_client_auth", lambda name: {"ok": True, "source": "mock"})
            monkeypatch.setattr(cli_module, "_PLATFORMS", {})

            runner = CliRunner()
            result = runner.invoke(cli_module.cli, ["doctor", "--fix", "--agent-name", "codex"])

            assert result.exit_code == 0
            payload = json.loads(result.output)
            assert payload["server_state"] == "recovering"
        finally:
            shutil.rmtree(case_dir, ignore_errors=True)

    def test_server_state_recovering_downgrades_to_degraded_when_mcp_still_fails(self, monkeypatch):
        """recovering must NOT mask degraded: if post-restart MCP is still broken, state = degraded."""
        case_dir = _make_case_dir()
        db_path = case_dir / "whispers.db"
        try:
            monkeypatch.setenv("WHISPERS_DB_PATH", str(db_path))
            monkeypatch.setenv("WHISPERS_MCP_TOKEN", "tok-bad")

            # Server is down, auto-start succeeds, but MCP handshake still fails
            health_responses = [None, {"db_path": str(db_path), "status": "ok"}]
            health_iter = iter(health_responses)

            def _fake_health():
                try:
                    return next(health_iter)
                except StopIteration:
                    return {"db_path": str(db_path), "status": "ok"}

            monkeypatch.setattr(cli_module, "_check_server_health", _fake_health)
            monkeypatch.setattr(cli_module, "_ensure_server_running", lambda: True)
            monkeypatch.setattr(cli_module, "_check_mcp_handshake", lambda token: None)  # still broken
            monkeypatch.setattr(cli_module, "_PLATFORMS", {})

            runner = CliRunner()
            result = runner.invoke(cli_module.cli, ["doctor", "--fix", "--agent-name", "codex"])

            assert result.exit_code == 0
            payload = json.loads(result.output)
            # Auto-start was applied, but steady-state is still broken — must NOT say 'recovering'
            assert payload["server_state"] == "degraded", (
                f"Expected 'degraded' when MCP is still broken after fix, got '{payload['server_state']}'"
            )
            assert payload["server_running"] is True
            assert payload["mcp_healthy"] is False
        finally:
            shutil.rmtree(case_dir, ignore_errors=True)


# ---------------------------------------------------------------------------
# connect: wrong-identity token rejection (P1 regression)
# ---------------------------------------------------------------------------

class TestConnectIdentityVerification:
    def test_connect_rejects_token_for_wrong_agent(self, monkeypatch):
        """connect must reject and NOT save if /whoami returns a different agent than requested."""
        case_dir = _make_case_dir()
        profiles_path = case_dir / "profiles.json"
        credentials_path = case_dir / "credentials.json"
        try:
            monkeypatch.setenv("WHISPERS_PROFILES_PATH", str(profiles_path))
            monkeypatch.setenv("WHISPERS_CREDENTIALS_PATH", str(credentials_path))
            monkeypatch.setattr(
                cli_module, "_remote_server_health",
                lambda server: {"ok": True, "peers_online_count": 1}
            )
            monkeypatch.setattr(
                cli_module, "_server_connect",
                lambda server, payload: {
                    "agent_name": "codex",
                    "token": "bad-identity-token",
                    "token_status": "new",
                    "session": {"session_id": "s1", "lease_expires_at": "2099-01-01T00:00:00Z"},
                    "status": {},
                },
            )
            # /whoami returns a DIFFERENT agent — simulating a server cross-issuance bug
            monkeypatch.setattr(
                cli_module, "_server_request",
                lambda server, path, **kwargs: {"agent_name": "other-agent"} if "/whoami" in path else None,
            )

            runner = CliRunner()
            result = runner.invoke(
                cli_module.cli,
                ["connect", "--server", "http://mesh.example", "--agent-name", "codex"],
            )

            assert result.exit_code != 0
            assert "Token verification failed" in result.output
            assert "other-agent" in result.output
            assert "codex" in result.output
            # Profile must NOT have been saved
            assert not profiles_path.exists()
        finally:
            shutil.rmtree(case_dir, ignore_errors=True)


# ---------------------------------------------------------------------------
# doctor: server_state_detail and server_diagnostics
# ---------------------------------------------------------------------------

class TestDoctorDiagnostics:
    """Cover all 5 states for server_state_detail and server_diagnostics."""

    def _run_doctor(self, monkeypatch, db_path, mcp_token=None, health_fn=None,
                    mcp_result=None, fix=False, ensure_running_result=None,
                    local_auth_ok=True):
        if mcp_token:
            monkeypatch.setenv("WHISPERS_MCP_TOKEN", mcp_token)
        monkeypatch.setenv("WHISPERS_DB_PATH", str(db_path))
        monkeypatch.setattr(cli_module, "_PLATFORMS", {})
        monkeypatch.setattr(cli_module, "_check_server_health", health_fn)
        monkeypatch.setattr(cli_module, "_check_mcp_handshake", lambda token: mcp_result)
        monkeypatch.setattr(cli_module, "_probe_local_client_auth", lambda name: {"ok": local_auth_ok, "source": "mock"})
        if ensure_running_result is not None:
            monkeypatch.setattr(cli_module, "_ensure_server_running", lambda: ensure_running_result)
        args = ["doctor", "--agent-name", "codex"]
        if fix:
            args.append("--fix")
        runner = CliRunner()
        result = runner.invoke(cli_module.cli, args)
        assert result.exit_code == 0, result.output
        return json.loads(result.output)

    def test_diagnostics_up_state(self, monkeypatch):
        """up: no failing checks, no hints, state_detail says 'operational'."""
        case_dir = _make_case_dir()
        db_path = case_dir / "whispers.db"
        try:
            payload = self._run_doctor(
                monkeypatch, db_path,
                mcp_token="tok",
                health_fn=lambda: {"db_path": str(db_path), "status": "ok"},
                mcp_result=13,
            )
            assert payload["server_state"] == "up"
            assert payload["server_state_detail"] == "All systems operational."
            diag = payload["server_diagnostics"]
            assert diag["failing_checks"] == []
            assert diag["hints"] == []
            assert diag["checks"]["server_reachable"] is True
            assert diag["checks"]["mcp_handshake"] is True
            assert diag["checks"]["db_path_match"] is True
        finally:
            shutil.rmtree(case_dir, ignore_errors=True)

    def test_diagnostics_degraded_mcp_failure(self, monkeypatch):
        """degraded/mcp: failing_checks has mcp_handshake, hint suggests doctor --fix."""
        case_dir = _make_case_dir()
        db_path = case_dir / "whispers.db"
        try:
            payload = self._run_doctor(
                monkeypatch, db_path,
                mcp_token="bad-tok",
                health_fn=lambda: {"db_path": str(db_path), "status": "ok"},
                mcp_result=None,
            )
            assert payload["server_state"] == "degraded"
            assert "MCP handshake failed" in payload["server_state_detail"]
            diag = payload["server_diagnostics"]
            assert "mcp_handshake" in diag["failing_checks"]
            assert diag["checks"]["mcp_handshake"] is False
            assert diag["checks"]["server_reachable"] is True
            assert any("doctor --fix" in h for h in diag["hints"])
            assert any("MCP_TOKEN" in h for h in diag["hints"])
        finally:
            shutil.rmtree(case_dir, ignore_errors=True)

    def test_diagnostics_degraded_mcp_not_ready(self, monkeypatch):
        """degraded/mcp-not-ready: preserve MCP failure but surface startup/reload hints."""
        case_dir = _make_case_dir()
        db_path = case_dir / "whispers.db"

        def _fake_handshake(token):
            cli_module._LAST_MCP_HANDSHAKE = {
                "ok": False,
                "status": "not_ready",
                "stage": "initialize",
                "detail": "connection refused",
                "http_status": None,
            }
            return None

        try:
            monkeypatch.setenv("WHISPERS_MCP_TOKEN", "tok")
            monkeypatch.setenv("WHISPERS_DB_PATH", str(db_path))
            monkeypatch.setattr(cli_module, "_PLATFORMS", {})
            monkeypatch.setattr(cli_module, "_check_server_health", lambda: {"db_path": str(db_path), "status": "ok"})
            monkeypatch.setattr(cli_module, "_check_mcp_handshake", _fake_handshake)

            runner = CliRunner()
            result = runner.invoke(cli_module.cli, ["doctor", "--agent-name", "codex"])

            assert result.exit_code == 0
            payload = json.loads(result.output)
            assert payload["server_state"] == "degraded"
            assert payload["mcp_probe"]["status"] == "not_ready"
            assert "not ready yet" in payload["server_state_detail"]
            diag = payload["server_diagnostics"]
            assert any("wait a few seconds" in h.lower() for h in diag["hints"])
            assert any("reload your mcp host" in h.lower() for h in diag["hints"])
        finally:
            shutil.rmtree(case_dir, ignore_errors=True)

    def test_diagnostics_degraded_db_path_mismatch(self, monkeypatch):
        """degraded/db: failing_checks has db_path_match, hint about WHISPERS_DB_PATH."""
        case_dir = _make_case_dir()
        local_db = case_dir / "local.db"
        server_db = case_dir / "server.db"
        try:
            payload = self._run_doctor(
                monkeypatch, local_db,
                mcp_token="tok",
                health_fn=lambda: {"db_path": str(server_db), "status": "ok"},
                mcp_result=13,
            )
            assert payload["server_state"] == "degraded"
            detail = payload["server_state_detail"]
            assert "mismatch" in detail.lower() or "DB path" in detail
            diag = payload["server_diagnostics"]
            assert "db_path_match" in diag["failing_checks"]
            assert diag["checks"]["db_path_match"] is False
            assert any("WHISPERS_DB_PATH" in h for h in diag["hints"])
        finally:
            shutil.rmtree(case_dir, ignore_errors=True)

    def test_diagnostics_recovering_state(self, monkeypatch):
        """recovering: state_detail mentions restart, hint says monitor for stability."""
        case_dir = _make_case_dir()
        db_path = case_dir / "whispers.db"
        try:
            responses = [None, {"db_path": str(db_path), "status": "ok"}]
            resp_iter = iter(responses)

            def _fake_health():
                try:
                    return next(resp_iter)
                except StopIteration:
                    return {"db_path": str(db_path), "status": "ok"}

            payload = self._run_doctor(
                monkeypatch, db_path,
                mcp_token="tok",
                health_fn=_fake_health,
                mcp_result=13,
                fix=True,
                ensure_running_result=True,
            )
            assert payload["server_state"] == "recovering"
            detail = payload["server_state_detail"].lower()
            assert "restart" in detail or "restarted" in detail
            diag = payload["server_diagnostics"]
            assert diag["failing_checks"] == []
            assert any("monitor" in h.lower() or "stability" in h.lower() for h in diag["hints"])
        finally:
            shutil.rmtree(case_dir, ignore_errors=True)

    def test_diagnostics_down_state(self, monkeypatch):
        """down: state_detail names the port, hints suggest serve and doctor --fix."""
        case_dir = _make_case_dir()
        db_path = case_dir / "whispers.db"
        try:
            payload = self._run_doctor(
                monkeypatch, db_path,
                health_fn=lambda: None,
                mcp_result=None,
            )
            assert payload["server_state"] == "down"
            detail = payload["server_state_detail"].lower()
            assert "not running" in detail or "not reachable" in detail
            diag = payload["server_diagnostics"]
            assert "server_reachable" in diag["failing_checks"]
            assert diag["checks"]["server_reachable"] is False
            assert any("whispers serve" in h for h in diag["hints"])
            assert any("doctor --fix" in h for h in diag["hints"])
        finally:
            shutil.rmtree(case_dir, ignore_errors=True)

# ---------------------------------------------------------------------------
# doctor: recovery_timeline
# ---------------------------------------------------------------------------

class TestDoctorRecoveryTimeline:
    """Verify recovery_timeline is present and accurate in all relevant states."""

    def _run_doctor(self, monkeypatch, db_path, mcp_token=None, health_fn=None,
                    mcp_result=None, fix=False, ensure_running_result=None,
                    runtime_state_path=None, local_auth_ok=True):
        if mcp_token:
            monkeypatch.setenv("WHISPERS_MCP_TOKEN", mcp_token)
        monkeypatch.setenv("WHISPERS_DB_PATH", str(db_path))
        if runtime_state_path:
            monkeypatch.setenv("WHISPERS_RUNTIME_STATE_PATH", str(runtime_state_path))
        monkeypatch.setattr(cli_module, "_PLATFORMS", {})
        monkeypatch.setattr(cli_module, "_check_server_health", health_fn)
        monkeypatch.setattr(cli_module, "_check_mcp_handshake", lambda token: mcp_result)
        monkeypatch.setattr(cli_module, "_probe_local_client_auth", lambda name: {"ok": local_auth_ok, "source": "mock"})
        if ensure_running_result is not None:
            monkeypatch.setattr(cli_module, "_ensure_server_running", lambda: ensure_running_result)
        args = ["doctor", "--agent-name", "codex"]
        if fix:
            args.append("--fix")
        runner = CliRunner()
        result = runner.invoke(cli_module.cli, args)
        assert result.exit_code == 0, result.output
        return json.loads(result.output)

    def test_timeline_present_on_up_state(self, monkeypatch):
        """recovery_timeline is always present in the response, even when nothing has happened."""
        case_dir = _make_case_dir()
        db_path = case_dir / "whispers.db"
        runtime_state = case_dir / "runtime-state.json"
        try:
            payload = self._run_doctor(
                monkeypatch, db_path,
                mcp_token="tok",
                health_fn=lambda: {"db_path": str(db_path), "status": "ok"},
                mcp_result=13,
                runtime_state_path=runtime_state,
            )
            assert "recovery_timeline" in payload
            tl = payload["recovery_timeline"]
            # No auto-start was triggered — auto_started must be False
            assert tl["auto_started"] is False
        finally:
            shutil.rmtree(case_dir, ignore_errors=True)

    def test_timeline_present_on_down_state(self, monkeypatch):
        """recovery_timeline is present even when server is completely down."""
        case_dir = _make_case_dir()
        db_path = case_dir / "whispers.db"
        runtime_state = case_dir / "runtime-state.json"
        try:
            payload = self._run_doctor(
                monkeypatch, db_path,
                health_fn=lambda: None,
                mcp_result=None,
                runtime_state_path=runtime_state,
            )
            assert payload["server_state"] == "down"
            assert "recovery_timeline" in payload
            tl = payload["recovery_timeline"]
            assert tl["auto_started"] is False
        finally:
            shutil.rmtree(case_dir, ignore_errors=True)

    def test_timeline_records_attempt_and_success_after_fix(self, monkeypatch):
        """doctor --fix sets last_auto_start_attempt and last_successful_recovery_at on success."""
        case_dir = _make_case_dir()
        db_path = case_dir / "whispers.db"
        runtime_state = case_dir / "runtime-state.json"
        try:
            responses = [None, {"db_path": str(db_path), "status": "ok"}]
            resp_iter = iter(responses)
            def _fake_health():
                try:
                    return next(resp_iter)
                except StopIteration:
                    return {"db_path": str(db_path), "status": "ok"}

            payload = self._run_doctor(
                monkeypatch, db_path,
                mcp_token="tok",
                health_fn=_fake_health,
                mcp_result=13,
                fix=True,
                ensure_running_result=True,
                runtime_state_path=runtime_state,
            )
            assert payload["server_state"] == "recovering"
            tl = payload["recovery_timeline"]
            # auto_started must be True for a recovering state
            assert tl["auto_started"] is True
            # Both timestamps must be present and ISO-formatted
            assert tl.get("last_auto_start_attempt")
            assert "T" in tl["last_auto_start_attempt"]
            assert tl.get("last_successful_recovery_at")
            assert "T" in tl["last_successful_recovery_at"]
            # Timestamps must be persisted to disk
            assert runtime_state.exists()
            persisted = json.loads(runtime_state.read_text(encoding="utf-8"))
            assert "recovery_timeline" in persisted
            assert persisted["recovery_timeline"]["last_auto_start_attempt"] == tl["last_auto_start_attempt"]
            assert persisted["recovery_timeline"]["last_successful_recovery_at"] == tl["last_successful_recovery_at"]
        finally:
            shutil.rmtree(case_dir, ignore_errors=True)

    def test_timeline_persists_across_runs(self, monkeypatch):
        """recovery_timeline from a prior fix run is surfaced in subsequent doctor calls."""
        case_dir = _make_case_dir()
        db_path = case_dir / "whispers.db"
        runtime_state = case_dir / "runtime-state.json"
        # Pre-seed a prior recovery event
        runtime_state.write_text(json.dumps({
            "recovery_timeline": {
                "last_auto_start_attempt": "2026-03-24T10:00:00Z",
                "last_successful_recovery_at": "2026-03-24T10:00:05Z",
            }
        }), encoding="utf-8")
        try:
            # Now run doctor without --fix (server is back up)
            payload = self._run_doctor(
                monkeypatch, db_path,
                mcp_token="tok",
                health_fn=lambda: {"db_path": str(db_path), "status": "ok"},
                mcp_result=13,
                runtime_state_path=runtime_state,
            )
            assert payload["server_state"] == "up"
            tl = payload["recovery_timeline"]
            assert tl["last_auto_start_attempt"] == "2026-03-24T10:00:00Z"
            assert tl["last_successful_recovery_at"] == "2026-03-24T10:00:05Z"
            # Not a recovering run, so auto_started should be False
            assert tl["auto_started"] is False
        finally:
            shutil.rmtree(case_dir, ignore_errors=True)

# ---------------------------------------------------------------------------
# Recovery event history
# ---------------------------------------------------------------------------

class TestDoctorRecoveryEvents:
    """Verify recovery_events are recorded and surfaced correctly."""

    def _run_doctor(self, monkeypatch, db_path, mcp_token=None, health_fn=None,
                    mcp_result=None, fix=False, ensure_running_result=None,
                    runtime_state_path=None, local_auth_ok=True):
        if mcp_token:
            monkeypatch.setenv("WHISPERS_MCP_TOKEN", mcp_token)
        monkeypatch.setenv("WHISPERS_DB_PATH", str(db_path))
        if runtime_state_path:
            monkeypatch.setenv("WHISPERS_RUNTIME_STATE_PATH", str(runtime_state_path))
        monkeypatch.setattr(cli_module, "_PLATFORMS", {})
        monkeypatch.setattr(cli_module, "_check_server_health", health_fn)
        monkeypatch.setattr(cli_module, "_check_mcp_handshake", lambda token: mcp_result)
        monkeypatch.setattr(cli_module, "_probe_local_client_auth", lambda name: {"ok": local_auth_ok, "source": "mock"})
        if ensure_running_result is not None:
            monkeypatch.setattr(cli_module, "_ensure_server_running", lambda: ensure_running_result)
        args = ["doctor", "--agent-name", "codex"]
        if fix:
            args.append("--fix")
        runner = CliRunner()
        result = runner.invoke(cli_module.cli, args)
        assert result.exit_code == 0, result.output
        return json.loads(result.output)

    def test_recovery_events_always_present(self, monkeypatch):
        """recovery_events key is always present in doctor output."""
        case_dir = _make_case_dir()
        db_path = case_dir / "whispers.db"
        runtime_state = case_dir / "runtime-state.json"
        try:
            payload = self._run_doctor(
                monkeypatch, db_path,
                mcp_token="tok",
                health_fn=lambda: {"db_path": str(db_path), "status": "ok"},
                mcp_result=13,
                runtime_state_path=runtime_state,
            )
            assert "recovery_events" in payload
            assert isinstance(payload["recovery_events"], list)
        finally:
            shutil.rmtree(case_dir, ignore_errors=True)

    def test_auto_start_events_recorded_on_successful_fix(self, monkeypatch):
        """doctor --fix records auto_start_attempted and auto_start_succeeded events."""
        case_dir = _make_case_dir()
        db_path = case_dir / "whispers.db"
        runtime_state = case_dir / "runtime-state.json"
        try:
            responses = [None, {"db_path": str(db_path), "status": "ok"}]
            resp_iter = iter(responses)
            def _fake_health():
                try:
                    return next(resp_iter)
                except StopIteration:
                    return {"db_path": str(db_path), "status": "ok"}

            payload = self._run_doctor(
                monkeypatch, db_path,
                mcp_token="tok",
                health_fn=_fake_health,
                mcp_result=13,
                fix=True,
                ensure_running_result=True,
                runtime_state_path=runtime_state,
            )
            events = payload["recovery_events"]
            types = [e["type"] for e in events]
            assert "auto_start_attempted" in types
            assert "auto_start_succeeded" in types
            # attempted must come before succeeded
            idx_attempt = types.index("auto_start_attempted")
            idx_succeed = types.index("auto_start_succeeded")
            assert idx_attempt < idx_succeed
            # Verify event shape
            for ev in events:
                assert "type" in ev
                assert "created_at" in ev
                assert "detail" in ev
                assert "severity" in ev
                assert "T" in ev["created_at"]  # ISO timestamp
        finally:
            shutil.rmtree(case_dir, ignore_errors=True)

    def test_state_degraded_event_recorded(self, monkeypatch):
        """doctor records a state_degraded event when MCP handshake fails."""
        case_dir = _make_case_dir()
        db_path = case_dir / "whispers.db"
        runtime_state = case_dir / "runtime-state.json"
        try:
            payload = self._run_doctor(
                monkeypatch, db_path,
                mcp_token="bad-tok",
                health_fn=lambda: {"db_path": str(db_path), "status": "ok"},
                mcp_result=None,
                runtime_state_path=runtime_state,
            )
            assert payload["server_state"] == "degraded"
            events = payload["recovery_events"]
            types = [e["type"] for e in events]
            assert "state_degraded" in types
            degraded_ev = next(e for e in events if e["type"] == "state_degraded")
            assert degraded_ev["severity"] == "warning"
            assert "MCP" in degraded_ev["detail"] or "degraded" in degraded_ev["detail"]
        finally:
            shutil.rmtree(case_dir, ignore_errors=True)

    def test_events_persist_across_runs(self, monkeypatch):
        """Events from a prior run are returned in subsequent doctor calls."""
        case_dir = _make_case_dir()
        db_path = case_dir / "whispers.db"
        runtime_state = case_dir / "runtime-state.json"
        # Pre-seed an event
        runtime_state.write_text(json.dumps({
            "recovery_events": [
                {
                    "type": "auto_start_attempted",
                    "created_at": "2026-03-24T10:00:00Z",
                    "detail": "prior event",
                    "severity": "info",
                }
            ]
        }), encoding="utf-8")
        try:
            payload = self._run_doctor(
                monkeypatch, db_path,
                mcp_token="tok",
                health_fn=lambda: {"db_path": str(db_path), "status": "ok"},
                mcp_result=13,
                runtime_state_path=runtime_state,
            )
            events = payload["recovery_events"]
            # Prior event must still be present
            prior = next((e for e in events if e["detail"] == "prior event"), None)
            assert prior is not None, "Prior event was not retained"
        finally:
            shutil.rmtree(case_dir, ignore_errors=True)

    def test_event_cap_trims_oldest(self, monkeypatch):
        """Events are trimmed to _RECOVERY_EVENT_CAP when the list exceeds the limit."""
        case_dir = _make_case_dir()
        db_path = case_dir / "whispers.db"
        runtime_state = case_dir / "runtime-state.json"
        cap = cli_module._RECOVERY_EVENT_CAP
        # Pre-seed cap events
        old_events = [
            {"type": "state_degraded", "created_at": f"2026-03-24T09:{i:02d}:00Z",
             "detail": f"old event {i}", "severity": "warning"}
            for i in range(cap)
        ]
        runtime_state.write_text(json.dumps({"recovery_events": old_events}), encoding="utf-8")
        try:
            # This run will add a new degraded event (MCP fails)
            payload = self._run_doctor(
                monkeypatch, db_path,
                mcp_token="bad-tok",
                health_fn=lambda: {"db_path": str(db_path), "status": "ok"},
                mcp_result=None,
                runtime_state_path=runtime_state,
            )
            events = payload["recovery_events"]
            assert len(events) <= cap
            # The newest event should be the state_degraded just written
            assert events[-1]["type"] == "state_degraded"
        finally:
            shutil.rmtree(case_dir, ignore_errors=True)
