"""Proof of Baton Security Pressure: Real relay, stale version conflicts, terminal boundaries, workspace projection.
"""
from __future__ import annotations

import json
import os
import secrets
import shutil
import socket
import subprocess
import sys
import time
import urllib.request
from pathlib import Path

from whispers.client import WhispersClient


ROOT = Path(__file__).resolve().parents[1]
ARTIFACT_DIR = ROOT / "tests" / ".artifacts" / "proof_baton_security_pressure"
DB_PATH = ARTIFACT_DIR / "proof_baton_security_pressure.db"
RUNTIME_STATE_PATH = ARTIFACT_DIR / "runtime-state.json"
PROOF_HOME = ARTIFACT_DIR / "home"
PROOF_MCP_TOKEN = secrets.token_urlsafe(24)


def reset_artifacts() -> None:
    if ARTIFACT_DIR.exists():
        shutil.rmtree(ARTIFACT_DIR, ignore_errors=True)
    ARTIFACT_DIR.mkdir(parents=True, exist_ok=True)


def require(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


def require_error(fn, exception_msg_substring: str, failure_message: str) -> None:
    try:
        fn()
    except Exception as exc:
        if exception_msg_substring.lower() not in str(exc).lower():
            raise AssertionError(f"{failure_message}: Expected exception containing {exception_msg_substring!r}, got {str(exc)!r}") from exc
        return
    raise AssertionError(f"{failure_message}: Expected an exception containing {exception_msg_substring!r}, but it succeeded.")


def proof_env() -> dict[str, str]:
    env = os.environ.copy()
    env["HOME"] = str(PROOF_HOME)
    env["USERPROFILE"] = str(PROOF_HOME)
    env["WHISPERS_DB_PATH"] = str(DB_PATH)
    env["WHISPERS_RUNTIME_STATE_PATH"] = str(RUNTIME_STATE_PATH)
    env["WHISPERS_MCP_TOKEN"] = PROOF_MCP_TOKEN
    env["WHISPERS_REMOTE_ADMISSION_MODE"] = "open"
    return env


def get_mcp_token() -> str:
    token = os.environ.get("WHISPERS_MCP_TOKEN", "").strip()
    if token:
        return token
    env_path = Path.home() / ".whispers" / ".env"
    if env_path.exists():
        for line in env_path.read_text().splitlines():
            line = line.strip()
            if line.startswith("WHISPERS_MCP_TOKEN="):
                return line.split("=", 1)[1].strip().strip('"').strip("'")
    return PROOF_MCP_TOKEN


def find_free_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.bind(("127.0.0.1", 0))
        return int(sock.getsockname()[1])


def wait_for_health(port: int, timeout_seconds: float = 15.0) -> None:
    deadline = time.time() + timeout_seconds
    url = f"http://127.0.0.1:{port}/health"
    while time.time() < deadline:
        try:
            with urllib.request.urlopen(url, timeout=1.0) as resp:
                if resp.status == 200:
                    return
        except Exception:
            time.sleep(0.25)
    raise AssertionError(f"Server on port {port} did not become healthy")


def start_temp_server() -> tuple[subprocess.Popen[bytes], int]:
    port = find_free_port()
    token = get_mcp_token()
    require(bool(token), "No MCP token available for proof run.")

    env = proof_env()
    env["WHISPERS_MCP_TOKEN"] = token
    proc = subprocess.Popen(
        [sys.executable, "-c", f"from whispers.server import start; start(port={port})"],
        cwd=ROOT,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        env=env,
    )
    try:
        wait_for_health(port)
    except Exception:
        proc.terminate()
        raise
    return proc, port


def stop_temp_server(proc: subprocess.Popen[bytes]) -> None:
    if proc.poll() is not None:
        return
    proc.terminate()
    try:
        proc.wait(timeout=5)
    except subprocess.TimeoutExpired:
        proc.kill()
        proc.wait(timeout=5)


def decode_payload(value):
    if isinstance(value, str):
        return json.loads(value)
    return value


def main() -> int:
    reset_artifacts()
    proc, port = start_temp_server()
    base = f"http://127.0.0.1:{port}"
    results: dict[str, object] = {"server": base}
    try:
        antigravity = WhispersClient("antigravity", server=base)
        claude = WhispersClient("claude-code", server=base)
        codex = WhispersClient("codex", server=base)
        operator = WhispersClient("whispers-console", server=base)
        intruder = WhispersClient("intruder", server=base)

        # 1. Create a workspace
        created = antigravity.create_workspace(
            purpose="Proof Baton Security Pressure",
            name="Security Pressure Pass",
            join_policy="invite",
            members=["claude-code", "codex", "whispers-console"],
        )
        workspace_id = created["workspace_id"]
        claude.join_workspace(workspace_id)
        codex.join_workspace(workspace_id)

        results["workspace_id"] = workspace_id

        # 2. Real Relay -> Send Baton from Antigravity to Claude code
        sent_handoff = antigravity.send_handoff(
            "claude-code",
            objective="Pressure Test Baton",
            deliverable="Evidence of security holds",
            completed="Nothing yet",
            remaining="Everything",
            next_action="Acknowledge the baton",
            workspace_id=workspace_id,
        )
        baton_id = sent_handoff["id"]
        results["baton_id"] = baton_id

        # Flush inboxes to simulate realtime delivery
        antigravity.check_inbox(mark_seen=True)
        claude.check_inbox(mark_seen=True)
        intruder.check_inbox(mark_seen=True)

        # 3. Verify Intruder Cannot Act (Ownership Enforcement)
        # Note: Depending on server implementation, this might return 401, 403, or 404, or throw a BatonStateError.
        require_error(
            lambda: intruder.baton_ack(baton_id, "accepted"),
            "", # Match any error, assuming client raises an exception on HTTP failure
            "Intruder should not be able to ack a baton assigned to another agent"
        )

        # 4. Verify Sender Cannot Ack (Role Enforcement)
        require_error(
            lambda: antigravity.baton_ack(baton_id, "accepted"),
            "", 
            "Sender should not be able to ack the baton they offered"
        )

        # 5. Claude acks the baton correctly
        ack_res = claude.baton_ack(baton_id, "accepted", expected_version=1)
        # Assuming the backend returns the updated baton or sequence, the sequence increments
        current_version = ack_res.get("expected_version", 2)

        # 6. Verify Terminal/Transition Immutability (Cannot double-ack after accepted)
        require_error(
            lambda: claude.baton_ack(baton_id, "conditionally_accepted", expected_version=current_version),
            "",
            "Cannot double-ack a baton that is already accepted"
        )

        # 7. Verification of Stale Version Conflicts
        # Send an update with an explicit bad expected_version (version 1)
        require_error(
            lambda: claude.baton_update(baton_id, "in_progress", expected_version=1),
            "version", # Either 'version', 'expected_version mismatch' or similar HTTP 409
            "Backend must reject baton updates with stale versions"
        )

        # 8. Claude updates baton to in_progress with correct version
        update_res = claude.baton_update(baton_id, "in_progress", expected_version=current_version)
        current_version = update_res.get("expected_version", current_version + 1)

        # 9. Ensure the baton is visible to the operator in the correct state
        handoffs = operator.list_handoffs(limit=5, workspace_id=workspace_id)
        require(len(handoffs) > 0, "Operator handoff view is empty.")
        
        target_handoff = None
        for h in handoffs:
            if h.get("uuid") == baton_id:
                target_handoff = h
                break
        
        require(target_handoff is not None, "Baton missing from operator views in the workspace.")
        
        state_val = target_handoff.get("baton_state")
        
        if state_val != "in_progress":
            raise AssertionError(f"Operator console derived baton state is {state_val!r}, expected 'in_progress'. Handoff: {json.dumps(target_handoff, indent=2)}")

        # 10. Claude closes the baton -> completed
        close_res = claude.baton_close(baton_id, "completed", expected_version=current_version)
        current_version = close_res.get("expected_version", current_version + 1)

        # 11. Terminal Immutability: Cannot update after closed
        require_error(
            lambda: claude.baton_update(baton_id, "blocked", expected_version=current_version),
            "",
            "Cannot update a baton that is already completed (terminal state immutability)"
        )

        # 12. Terminal Immutability: Cannot close after closed
        require_error(
            lambda: claude.baton_close(baton_id, "superseded", expected_version=current_version),
            "",
            "Cannot close a baton that is already completed"
        )

        # 13. Context Leakage Boundary: Direct delivery of ambient workspace context to an outsider
        # Intruder is NOT a member of the workspace. If we send them a workspace-scoped message, 
        # it should be fully redacted.
        res_inform = antigravity.send(
            "intruder", 
            "Top secret strategy", 
            body="This is our plan.", 
            metadata={"whispers:workspace_id": workspace_id}
        )
        
        # Intruder checks inbox
        intruder_inbox = intruder.check_inbox(mark_seen=True)
        # Find the message: since body is redacted, we look by metadata workspace_id
        leaked_msg = None
        for m in intruder_inbox:
            meta = m.get("metadata")
            if isinstance(meta, str):
                try: meta = json.loads(meta)
                except: meta = {}
            if meta and meta.get("whispers:workspace_id") == workspace_id:
                leaked_msg = m
                break
                
        require(leaked_msg is not None, "Intruder did not receive the redacted message token.")
        require(leaked_msg.get("subject") == "[scope-redacted]", f"Expected subject to be [scope-redacted], got {leaked_msg.get('subject')!r}")
        require(leaked_msg.get("body") is None, "Body was not redacted!")

        # 14. Context Leakage Boundary: Handoff to an outsider
        # The explicit work object (handoff baton) is allowed but narrowed.
        res_handoff2 = antigravity.send_handoff(
            "intruder",
            objective="Do some work for us",
            deliverable="Work product",
            workspace_id=workspace_id,
            human_summary="Secret context you shouldn't see",
        )
        
        intruder_inbox2 = intruder.check_inbox(mark_seen=True)
        handoff_msg = None
        for m in intruder_inbox2:
            pay = m.get("payload")
            if isinstance(pay, str):
                try: pay = json.loads(pay)
                except: pay = {}
            if pay and pay.get("schema") == "handoff_baton.v1":
                inner_pay = pay.get("payload", {})
                if inner_pay.get("workspace_id") == workspace_id:
                    handoff_msg = m
                    break
                
        require(handoff_msg is not None, "Intruder did not receive the narrowed handoff message.")
        require(handoff_msg.get("subject") == "[workspace-scoped handoff_baton.v1]", "Handoff subject wasn't redacted.")
        require(handoff_msg.get("body") is None, "Handoff body wasn't redacted.")
        require("Secret context you shouldn't see" not in json.dumps(handoff_msg.get("payload", {})), "Inner human summary was not stripped from handoff payload.")
        
        results["checks"] = {
            "intruder_blocked": True,
            "sender_ack_blocked": True,
            "double_ack_blocked": True,
            "stale_version_blocked": True,
            "operator_visibility": True,
            "terminal_update_blocked": True,
            "terminal_close_blocked": True,
            "context_leakage_prevented": True,
        }

        print(json.dumps({"overall": "PASS", **results}, indent=2))
        return 0
    except AssertionError as exc:
        print(json.dumps({"overall": "FAIL", **results, "error": str(exc)}, indent=2))
        return 1
    finally:
        stop_temp_server(proc)


if __name__ == "__main__":
    raise SystemExit(main())
