"""Tests for tags/facets metadata and claimed_paths soft locks.

Covers:
- Agent registration with tags
- Tags persistence and retrieval
- Path overlap detection
- Overlap with prefix containment
- No overlap when paths are disjoint
- No overlap with self
- No overlap with non-active lanes
- Overlap warnings in publish return value
"""

import pytest

from whispers.repo_coordination import (
    RepoCoordinator,
    RepoState,
    PathOverlapWarning,
)


# ---------------------------------------------------------------------------
# Tags / facets metadata
# ---------------------------------------------------------------------------


class TestAgentTags:
    @pytest.fixture
    def registry(self, tmp_path):
        from whispers.storage.db import WhispersDB
        from whispers.registry import AgentRegistry

        db = WhispersDB(db_path=str(tmp_path / "test.db"))
        return AgentRegistry(db)

    def test_register_with_tags(self, registry):
        agent_id = registry.register(
            "claude-code",
            agent_type="assistant",
            tags=["primary", "strategic", "backend"],
        )
        assert agent_id

        agent = registry.get_agent_by_callsign("claude-code")
        import json
        tags = json.loads(agent["tags"])
        assert tags == ["primary", "strategic", "backend"]

    def test_register_without_tags_leaves_null(self, registry):
        registry.register("codex", agent_type="executor")
        agent = registry.get_agent_by_callsign("codex")
        assert agent["tags"] is None

    def test_tags_updated_on_reregister(self, registry):
        registry.register("claude-code", agent_type="assistant", tags=["v1"])
        registry.register("claude-code", agent_type="assistant", tags=["v2", "updated"])

        agent = registry.get_agent_by_callsign("claude-code")
        import json
        assert json.loads(agent["tags"]) == ["v2", "updated"]

    def test_tags_preserved_when_not_provided_on_reregister(self, registry):
        registry.register("claude-code", agent_type="assistant", tags=["original"])
        # Re-register without tags — should preserve existing
        registry.register("claude-code", agent_type="assistant")

        agent = registry.get_agent_by_callsign("claude-code")
        import json
        assert json.loads(agent["tags"]) == ["original"]

    def test_tags_empty_list(self, registry):
        registry.register("agent-x", agent_type="script", tags=[])
        agent = registry.get_agent_by_callsign("agent-x")
        import json
        assert json.loads(agent["tags"]) == []


# ---------------------------------------------------------------------------
# Path overlap detection
# ---------------------------------------------------------------------------


class TestPathOverlapDetection:
    def test_no_overlap_disjoint_paths(self):
        coord = RepoCoordinator()
        coord.publish(RepoState(
            agent_name="alice",
            branch="main",
            claimed_paths=["whispers/server.py", "whispers/registry.py"],
        ))
        overlaps = coord.publish(RepoState(
            agent_name="bob",
            branch="main",
            claimed_paths=["dashboard/src/App.tsx"],
        ))
        assert overlaps == []

    def test_overlap_exact_match(self):
        coord = RepoCoordinator()
        coord.publish(RepoState(
            agent_name="alice",
            branch="main",
            claimed_paths=["whispers/server.py"],
        ))
        overlaps = coord.publish(RepoState(
            agent_name="bob",
            branch="main",
            claimed_paths=["whispers/server.py"],
        ))
        assert len(overlaps) == 1
        assert overlaps[0].agent_a == "bob"
        assert overlaps[0].agent_b == "alice"
        assert "whispers/server.py" in overlaps[0].overlapping_paths

    def test_overlap_prefix_containment(self):
        coord = RepoCoordinator()
        coord.publish(RepoState(
            agent_name="alice",
            branch="main",
            claimed_paths=["whispers/"],
        ))
        overlaps = coord.publish(RepoState(
            agent_name="bob",
            branch="main",
            claimed_paths=["whispers/server.py"],
        ))
        assert len(overlaps) == 1
        assert "whispers" in overlaps[0].overlapping_paths[0]

    def test_no_overlap_with_self(self):
        coord = RepoCoordinator()
        coord.publish(RepoState(
            agent_name="alice",
            branch="main",
            claimed_paths=["whispers/server.py"],
        ))
        # Re-publish same agent — should not overlap with self
        overlaps = coord.publish(RepoState(
            agent_name="alice",
            branch="main",
            claimed_paths=["whispers/server.py"],
        ))
        assert overlaps == []

    def test_no_overlap_with_non_active_lane(self):
        coord = RepoCoordinator()
        coord.publish(RepoState(
            agent_name="alice",
            branch="main",
            lane_state="superseded",
            claimed_paths=["whispers/server.py"],
        ))
        overlaps = coord.publish(RepoState(
            agent_name="bob",
            branch="main",
            claimed_paths=["whispers/server.py"],
        ))
        assert overlaps == []

    def test_no_overlap_when_no_claimed_paths(self):
        coord = RepoCoordinator()
        coord.publish(RepoState(
            agent_name="alice",
            branch="main",
            claimed_paths=["whispers/server.py"],
        ))
        overlaps = coord.publish(RepoState(
            agent_name="bob",
            branch="main",
        ))
        assert overlaps == []

    def test_overlap_normalizes_backslashes(self):
        coord = RepoCoordinator()
        coord.publish(RepoState(
            agent_name="alice",
            branch="main",
            claimed_paths=["whispers\\server.py"],
        ))
        overlaps = coord.publish(RepoState(
            agent_name="bob",
            branch="main",
            claimed_paths=["whispers/server.py"],
        ))
        assert len(overlaps) == 1

    def test_multiple_overlaps_with_different_agents(self):
        coord = RepoCoordinator()
        coord.publish(RepoState(
            agent_name="alice",
            branch="main",
            claimed_paths=["whispers/client.py"],
        ))
        coord.publish(RepoState(
            agent_name="charlie",
            branch="main",
            claimed_paths=["whispers/client.py"],
        ))
        overlaps = coord.publish(RepoState(
            agent_name="bob",
            branch="main",
            claimed_paths=["whispers/client.py"],
        ))
        assert len(overlaps) == 2
        overlap_agents = {w.agent_b for w in overlaps}
        assert overlap_agents == {"alice", "charlie"}

    def test_overlap_warning_serialization(self):
        warning = PathOverlapWarning(
            agent_a="bob",
            agent_b="alice",
            overlapping_paths=["whispers/server.py"],
        )
        d = warning.to_dict()
        assert d["agent_a"] == "bob"
        assert d["agent_b"] == "alice"
        assert d["overlapping_paths"] == ["whispers/server.py"]

    def test_publish_returns_overlaps(self):
        coord = RepoCoordinator()
        coord.publish(RepoState(
            agent_name="alice",
            branch="main",
            claimed_paths=["whispers/server.py"],
        ))
        result = coord.publish(RepoState(
            agent_name="bob",
            branch="main",
            claimed_paths=["whispers/server.py"],
        ))
        assert isinstance(result, list)
        assert len(result) == 1
        assert isinstance(result[0], PathOverlapWarning)
