"""Tests for the Reflexive Coordination Engine v0.

Covers:
- Reflex: stalled handoff at various ages and conditions
- Engine: new insights, escalations, cooldowns, resolutions
- World state builder: DB integration
"""

import time
import pytest

from whispers.reflexive_engine import (
    Stage,
    CoordinationInsight,
    Resolution,
    CooldownTracker,
    ReflexiveCoordinationEngine,
    reflex_stalled_handoff,
    _format_age,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _baton(baton_ref="b1", owner="alice", assignee="bob", state="offered",
           age_minutes=0, assignee_online=True, version=1, subject="test handoff"):
    """Build a test baton dict with computed created_epoch."""
    return {
        "baton_ref": baton_ref,
        "owner": owner,
        "assignee": assignee,
        "state": state,
        "subject": subject,
        "version": version,
        "created_epoch": time.time() - (age_minutes * 60),
        "updated_epoch": time.time() - (age_minutes * 60),
        "assignee_online": assignee_online,
    }


def _world(batons=None, agents=None):
    return {
        "active_batons": batons or [],
        "agents": agents or [],
        "path_overlaps": [],
    }


# ---------------------------------------------------------------------------
# _format_age
# ---------------------------------------------------------------------------

class TestFormatAge:
    def test_under_one_minute(self):
        assert _format_age(30) == "just now"

    def test_minutes(self):
        assert _format_age(300) == "5m"

    def test_hours_and_minutes(self):
        assert _format_age(5400) == "1h30m"

    def test_exact_hours(self):
        assert _format_age(7200) == "2h"

    def test_days(self):
        assert _format_age(90000) == "1d"


# ---------------------------------------------------------------------------
# Reflex: stalled handoff
# ---------------------------------------------------------------------------

class TestReflexStalledHandoff:
    def test_below_threshold_no_insight(self):
        """Baton at 10min — below 15min threshold, no insight."""
        world = _world(batons=[_baton(age_minutes=10)])
        assert reflex_stalled_handoff(world) == []

    def test_at_threshold_concern(self):
        """Baton at 20min — above 15min, concern stage."""
        world = _world(batons=[_baton(age_minutes=20)])
        insights = reflex_stalled_handoff(world)
        assert len(insights) == 1
        assert insights[0].stage == Stage.CONCERN
        assert insights[0].reflex == "stalled_handoff"
        assert insights[0].details["action"] == "alert_only"

    def test_at_recommend_threshold(self):
        """Baton at 35min — above 30min, recommend stage."""
        world = _world(batons=[_baton(age_minutes=35)])
        insights = reflex_stalled_handoff(world)
        assert len(insights) == 1
        assert insights[0].stage == Stage.RECOMMEND
        assert insights[0].details["action"] == "re_notify"

    def test_assignee_offline_no_insight(self):
        """Baton at 20min but assignee offline — skip."""
        world = _world(batons=[_baton(age_minutes=20, assignee_online=False)])
        assert reflex_stalled_handoff(world) == []

    def test_already_acknowledged_no_insight(self):
        """Baton in 'accepted' state — not offered, skip."""
        world = _world(batons=[_baton(age_minutes=20, state="accepted")])
        assert reflex_stalled_handoff(world) == []

    def test_insight_contains_agents(self):
        """Insight lists both owner and assignee."""
        world = _world(batons=[_baton(age_minutes=20, owner="alice", assignee="bob")])
        insights = reflex_stalled_handoff(world)
        assert "alice" in insights[0].agents_involved
        assert "bob" in insights[0].agents_involved

    def test_insight_contains_version(self):
        """Insight carries baton version for stale-context awareness."""
        world = _world(batons=[_baton(age_minutes=20, version=3)])
        insights = reflex_stalled_handoff(world)
        assert insights[0].details["version"] == 3

    def test_insight_subject_key_is_stable(self):
        """Same baton always produces the same subject_key."""
        world = _world(batons=[_baton(baton_ref="xyz", age_minutes=20)])
        insights = reflex_stalled_handoff(world)
        assert insights[0].subject_key == "baton:xyz"

    def test_multiple_stalled_batons(self):
        """Multiple stalled batons each produce their own insight."""
        world = _world(batons=[
            _baton(baton_ref="b1", age_minutes=20),
            _baton(baton_ref="b2", age_minutes=40),
        ])
        insights = reflex_stalled_handoff(world)
        assert len(insights) == 2
        refs = {i.details["baton_ref"] for i in insights}
        assert refs == {"b1", "b2"}

    def test_age_human_readable(self):
        """Insight details include human-readable age."""
        world = _world(batons=[_baton(age_minutes=20)])
        insights = reflex_stalled_handoff(world)
        assert insights[0].details["age_human"] == "20m"

    def test_empty_world_no_insights(self):
        assert reflex_stalled_handoff(_world()) == []


# ---------------------------------------------------------------------------
# Cooldown tracker
# ---------------------------------------------------------------------------

class TestCooldownTracker:
    def test_first_fire_always_allowed(self):
        tracker = CooldownTracker()
        assert tracker.should_fire("key1", 600) is True

    def test_within_cooldown_blocked(self):
        tracker = CooldownTracker()
        tracker.record("key1")
        assert tracker.should_fire("key1", 600) is False

    def test_after_cooldown_allowed(self):
        tracker = CooldownTracker()
        tracker._last_fired["key1"] = time.time() - 700
        assert tracker.should_fire("key1", 600) is True

    def test_clear_resets_cooldown(self):
        tracker = CooldownTracker()
        tracker.record("key1")
        tracker.clear("key1")
        assert tracker.should_fire("key1", 600) is True

    def test_different_keys_independent(self):
        tracker = CooldownTracker()
        tracker.record("key1")
        assert tracker.should_fire("key2", 600) is True


# ---------------------------------------------------------------------------
# Engine
# ---------------------------------------------------------------------------

class TestReflexiveEngine:
    def test_new_insight_fires_callback(self):
        received = []
        engine = ReflexiveCoordinationEngine(on_insight=lambda i: received.append(i))

        world = _world(batons=[_baton(age_minutes=20)])
        result = engine.scan(world)

        assert len(received) == 1
        assert received[0].reflex == "stalled_handoff"
        assert result["new"][0]["reflex"] == "stalled_handoff"

    def test_escalation_fires_callback(self):
        received = []
        engine = ReflexiveCoordinationEngine(on_insight=lambda i: received.append(i))

        # First scan at concern level
        engine.scan(_world(batons=[_baton(age_minutes=20)]))
        assert len(received) == 1
        assert received[0].stage == Stage.CONCERN

        # Second scan at recommend level — should escalate
        engine.scan(_world(batons=[_baton(age_minutes=35)]))
        assert len(received) == 2
        assert received[1].stage == Stage.RECOMMEND

    def test_same_stage_within_cooldown_silent(self):
        """Same insight at same stage within cooldown window — no re-fire."""
        received = []
        engine = ReflexiveCoordinationEngine(on_insight=lambda i: received.append(i))

        engine.scan(_world(batons=[_baton(age_minutes=20)]))
        assert len(received) == 1

        # Same scan again — same stage, within cooldown
        engine.scan(_world(batons=[_baton(age_minutes=22)]))
        assert len(received) == 1  # no new callback

    def test_resolution_fires_callback(self):
        resolutions = []
        engine = ReflexiveCoordinationEngine(on_resolution=lambda r: resolutions.append(r))

        # Raise an insight
        engine.scan(_world(batons=[_baton(baton_ref="b1", age_minutes=20)]))
        assert len(resolutions) == 0

        # Baton acknowledged — no longer in offered state
        engine.scan(_world(batons=[_baton(baton_ref="b1", age_minutes=25, state="accepted")]))
        assert len(resolutions) == 1
        assert resolutions[0].subject_key == "baton:b1"
        assert resolutions[0].reflex == "stalled_handoff"
        assert resolutions[0].was_stage == "concern"

    def test_resolution_preserves_cooldown(self):
        """After resolution, cooldown is preserved to prevent online-flicker spam.

        When an assignee goes offline, the reflex stops producing the insight
        (resolution). When they come back online, the insight reappears. Without
        cooldown preservation, this would fire a new reminder immediately —
        causing rapid-fire reminder spam from online status changes.
        """
        received = []
        engine = ReflexiveCoordinationEngine(on_insight=lambda i: received.append(i))

        # Raise
        engine.scan(_world(batons=[_baton(baton_ref="b1", age_minutes=20)]))
        assert len(received) == 1

        # Resolve (e.g., assignee goes offline — baton disappears from world)
        engine.scan(_world())

        # Recur — should NOT fire again because cooldown is preserved
        engine.scan(_world(batons=[_baton(baton_ref="b1", age_minutes=20)]))
        assert len(received) == 1  # no new callback — cooldown still active

    def test_reflex_failure_doesnt_crash(self):
        """If a reflex raises, the engine continues with other reflexes."""
        engine = ReflexiveCoordinationEngine()

        # Inject a broken reflex
        from whispers.reflexive_engine import _REFLEXES
        original = list(_REFLEXES)

        def bad_reflex(world):
            raise RuntimeError("boom")

        _REFLEXES.insert(0, bad_reflex)
        try:
            result = engine.scan(_world(batons=[_baton(age_minutes=20)]))
            # Should still get results from the working reflex
            assert result["active_count"] >= 0  # didn't crash
        finally:
            _REFLEXES.clear()
            _REFLEXES.extend(original)

    def test_multiple_batons_tracked_independently(self):
        received = []
        engine = ReflexiveCoordinationEngine(on_insight=lambda i: received.append(i))

        engine.scan(_world(batons=[
            _baton(baton_ref="b1", age_minutes=20),
            _baton(baton_ref="b2", age_minutes=35),
        ]))

        assert len(received) == 2
        keys = {r.subject_key for r in received}
        assert keys == {"baton:b1", "baton:b2"}

    def test_active_insights_accessible(self):
        engine = ReflexiveCoordinationEngine()
        engine.scan(_world(batons=[_baton(age_minutes=20)]))
        assert len(engine.active_insights) == 1
        assert engine.active_insights[0].reflex == "stalled_handoff"


# ---------------------------------------------------------------------------
# World state builder (DB integration)
# ---------------------------------------------------------------------------

class TestWorldStateBuilder:
    @pytest.fixture
    def db_and_clients(self, temp_db):
        from whispers.storage.db import WhispersDB
        from whispers.client import WhispersClient

        db = WhispersDB(db_path=temp_db)
        sender = WhispersClient("alice", db_path=temp_db)
        receiver = WhispersClient("bob", db_path=temp_db)
        return db, sender, receiver

    def test_empty_db_returns_empty_world(self, db_and_clients):
        from whispers.reflexive_world import build_world_state
        db, _, _ = db_and_clients
        world = build_world_state(db)
        assert world["active_batons"] == []
        assert isinstance(world["agents"], list)
        assert "built_at" in world

    def test_world_includes_active_baton(self, db_and_clients):
        from whispers.reflexive_world import build_world_state
        db, sender, receiver = db_and_clients

        sender.send_handoff(
            to="bob",
            subject="test handoff",
            objective="obj",
            deliverable="del",
            completed="done",
            remaining="todo",
            next_action="go",
        )

        world = build_world_state(db)
        assert len(world["active_batons"]) == 1
        baton = world["active_batons"][0]
        assert baton["state"] == "offered"
        assert baton["owner"] == "alice"
        assert baton["assignee"] == "bob"
        assert baton["version"] >= 1
        assert baton["created_epoch"] > 0

    def test_world_includes_agents(self, db_and_clients):
        from whispers.reflexive_world import build_world_state
        db, sender, receiver = db_and_clients

        world = build_world_state(db)
        callsigns = {a["callsign"] for a in world["agents"]}
        # Both alice and bob should be registered
        assert "alice" in callsigns
        assert "bob" in callsigns

    def test_terminal_batons_excluded(self, db_and_clients):
        from whispers.reflexive_world import build_world_state
        db, sender, receiver = db_and_clients

        result = sender.send_handoff(
            to="bob",
            subject="will close",
            objective="obj",
            deliverable="del",
            completed="done",
            remaining="todo",
            next_action="go",
        )
        baton_ref = result["id"]
        receiver.baton_ack(baton_ref, "accepted")
        receiver.baton_close(baton_ref, "completed", summary="done")

        world = build_world_state(db)
        assert len(world["active_batons"]) == 0

    def test_acknowledged_legacy_handoff_excluded_from_world_active_batons(self, db_and_clients):
        from whispers.reflexive_world import build_world_state
        db, sender, receiver = db_and_clients

        result = sender.send(
            "bob",
            subject="Legacy handoff",
            body="Pick this up from the older handoff path.",
            priority="priority",
            msg_type="handoff",
        )

        receiver.acknowledge_message(result["id"], "processed", detail="Reviewed and cleared")

        world = build_world_state(db)
        assert world["active_batons"] == []

    def test_world_includes_db_backed_path_overlaps(self, db_and_clients):
        from whispers.reflexive_world import build_world_state
        from whispers.repo_coordination import get_coordinator, RepoState

        db, _, _ = db_and_clients
        db.publish_repo_state(
            RepoState(
                agent_name="alice",
                branch="main",
                head_commit="abc1234",
                claimed_paths=["whispers/"],
            )
        )
        db.publish_repo_state(
            RepoState(
                agent_name="bob",
                branch="main",
                head_commit="def5678",
                claimed_paths=["whispers/server.py"],
            )
        )

        # Prove world-state overlap truth no longer depends on process-local coordinator state.
        get_coordinator().clear()

        world = build_world_state(db)
        assert len(world["path_overlaps"]) == 1
        overlap = world["path_overlaps"][0]
        assert overlap["agent_a"] == "alice"
        assert overlap["agent_b"] == "bob"
        assert overlap["overlapping_paths"] == ["whispers"]
