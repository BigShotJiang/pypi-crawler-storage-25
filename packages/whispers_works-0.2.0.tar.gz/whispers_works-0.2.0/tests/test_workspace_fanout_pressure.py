import concurrent.futures
import uuid
import pytest
from whispers.storage.db import WhispersDB
from whispers.workspaces import WorkspaceManager

def test_workspace_fanout_pressure(temp_db):
    """
    Simulates high concurrent fanout traffic in a single workspace.
    20 agents each emit 50 deltas concurrently (1000 total deltas).
    Each delta fans out to 20 members (20,000 message deliveries).
    Tests the sqlite DB's transaction lock resiliency (WAL mode).
    """
    db = WhispersDB(temp_db)
    manager = WorkspaceManager(db)

    # Register 20 agents
    for i in range(20):
        callsign = f"agent_{i}"
        with db.get_connection() as conn:
            conn.execute(
                "INSERT INTO agent_cards (agent_id, callsign, agent_type, realm) VALUES (?, ?, ?, 'local')",
                (f"uuid_{i}", callsign, "simulated")
            )
            conn.commit()

    # Create one shared workspace
    ws_id = manager.create_workspace(purpose="Load testing fanout", created_by="agent_0")

    # agent_0 is auto-joined as creator. Other 19 agents join.
    for i in range(1, 20):
        manager.join_workspace(ws_id, f"agent_{i}")

    def post_and_fanout(actor: str, iterations: int):
        # We need a new db instance per thread to simulate actual concurrent web requests
        thread_db = WhispersDB(temp_db)
        thread_manager = WorkspaceManager(thread_db)

        for _ in range(iterations):
            # 1. Post the delta
            seq = thread_manager.post_delta(
                workspace_id=ws_id,
                delta_kind="note",
                actor=actor,
                text="Pressure test payload"
            )

            # 2. Simulate the server doing fanout (inserting a message into A2A)
            # Fetch members (simulating the server fetching who to send to)
            state = thread_manager.get_state(ws_id)
            members = [m["agent_name"] for m in state["members"] if m["membership_state"] == "active"]

            # Queue a dummy message (analogous to the server's db.queue_message)
            msg_uuid = str(uuid.uuid4())
            with thread_db._db_op("Simulate Fanout") as conn:
                conn.execute(
                    """
                    INSERT INTO messages (
                        uuid, from_agent, to_agent, msg_type, subject, payload
                    ) VALUES (?, ?, ?, ?, ?, ?)
                    """,
                    (msg_uuid, actor, "workspace", "workspace_delta.v1", "Fanout packet", '{"mock": true}')
                )
                
                # Insert 20 recipient rows
                conn.executemany(
                    """
                    INSERT INTO message_recipients (message_uuid, recipient_callsign)
                    VALUES (?, ?)
                    """,
                    [(msg_uuid, m) for m in members]
                )
                conn.commit()

    # Launch 20 concurrent threads, 50 iterations each
    with concurrent.futures.ThreadPoolExecutor(max_workers=20) as executor:
        futures = [executor.submit(post_and_fanout, f"agent_{i}", 50) for i in range(20)]
        for future in concurrent.futures.as_completed(futures):
            future.result()  # raise exceptions if any occurred

    # Verify final state
    final_state = manager.get_state(ws_id)
    # 20 joins + 1000 notes = 1020 deltas
    assert len(final_state["deltas"]) == 1020
    assert final_state["workspace"]["last_sequence"] == 1020

    # Verify 1000 messages * 20 recipients = 20,000 queue rows
    with db.get_readonly_connection() as conn:
        count = conn.execute("SELECT COUNT(*) FROM message_recipients").fetchone()[0]
        assert count == 20000

