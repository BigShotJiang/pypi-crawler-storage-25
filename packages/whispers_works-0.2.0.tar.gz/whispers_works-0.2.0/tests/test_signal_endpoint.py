"""Integration tests for the /signal endpoint — the Border Router.

Tests the actual HTTP layer, not just the underlying logic.
This endpoint is the entry point for the physical world into the
agent mesh. It must be robust against malformed input, rate storms,
privilege escalation, and edge cases.
"""
import importlib
import os
import shutil
import uuid
from pathlib import Path

import pytest
from fastapi.testclient import TestClient


@pytest.fixture
def signal_server():
    """Create a fresh Whispers server instance with a temp DB for /signal tests."""
    root = Path(__file__).resolve().parents[1] / ".tmp"
    root.mkdir(parents=True, exist_ok=True)
    case_dir = root / f"signal-test-{uuid.uuid4().hex}"
    case_dir.mkdir(parents=True, exist_ok=False)
    db_path = str(case_dir / "test.db")

    os.environ["WHISPERS_DB_PATH"] = db_path
    os.environ["WHISPERS_DEPLOYMENT_MODE"] = "standalone"

    import whispers.server as server_module
    server_module = importlib.reload(server_module)

    # Register a receiver
    from whispers.registry import AgentRegistry
    reg = AgentRegistry(server_module.db)
    reg.register("receiver", agent_type="llm")

    with TestClient(server_module.app) as client:
        yield client, server_module

    del os.environ["WHISPERS_DB_PATH"]
    shutil.rmtree(case_dir, ignore_errors=True)


class TestSignalEndpointHTTP:
    """Full HTTP integration tests for /signal."""

    def test_basic_signal_accepted(self, signal_server):
        client, _ = signal_server
        resp = client.post("/signal", json={
            "from": "iot-sensor-1",
            "to": "receiver",
            "subject": "Temperature Alert",
            "body": "Office temp > 80F",
        })
        assert resp.status_code == 200
        data = resp.json()
        assert data["status"] in ("queued", "delivered")
        assert data["id"] is not None
        assert data["sender"] == "iot-sensor-1"

    def test_missing_recipient_rejected(self, signal_server):
        client, _ = signal_server
        resp = client.post("/signal", json={
            "from": "sensor",
            "subject": "Alert",
        })
        assert resp.status_code == 400
        assert "to" in resp.json()["detail"].lower() or "who" in resp.json()["detail"].lower()

    def test_flash_priority_rejected(self, signal_server):
        client, _ = signal_server
        resp = client.post("/signal", json={
            "from": "sensor",
            "to": "receiver",
            "subject": "Urgent",
            "priority": "flash",
        })
        assert resp.status_code == 403

    def test_system_priority_rejected(self, signal_server):
        client, _ = signal_server
        resp = client.post("/signal", json={
            "from": "sensor",
            "to": "receiver",
            "subject": "System",
            "priority": "system",
        })
        assert resp.status_code == 403

    def test_priority_allowed(self, signal_server):
        client, _ = signal_server
        resp = client.post("/signal", json={
            "from": "sensor",
            "to": "receiver",
            "subject": "Important",
            "priority": "priority",
        })
        assert resp.status_code == 200

    def test_routine_is_default_priority(self, signal_server):
        client, _ = signal_server
        resp = client.post("/signal", json={
            "from": "sensor",
            "to": "receiver",
            "subject": "Normal",
        })
        assert resp.status_code == 200

    def test_rate_limit_kicks_in(self, signal_server):
        client, _ = signal_server
        # Send 5 signals (the limit) — should all succeed
        for i in range(5):
            resp = client.post("/signal", json={
                "from": "spammy-sensor",
                "to": "receiver",
                "subject": f"Signal {i}",
            })
            assert resp.status_code == 200, f"Signal {i} should succeed"

        # 6th signal from same sender — should be rate-limited
        resp = client.post("/signal", json={
            "from": "spammy-sensor",
            "to": "receiver",
            "subject": "Signal 5 — too many",
        })
        assert resp.status_code == 429

    def test_different_senders_independent_rate_limits(self, signal_server):
        client, _ = signal_server
        # Fill up sensor-1's rate limit
        for i in range(5):
            client.post("/signal", json={
                "from": "sensor-1",
                "to": "receiver",
                "subject": f"S1-{i}",
            })

        # sensor-2 should still be allowed
        resp = client.post("/signal", json={
            "from": "sensor-2",
            "to": "receiver",
            "subject": "From different sender",
        })
        assert resp.status_code == 200

    def test_anonymous_sender_defaults(self, signal_server):
        client, _ = signal_server
        resp = client.post("/signal", json={
            "to": "receiver",
            "subject": "No sender specified",
        })
        assert resp.status_code == 200
        assert resp.json()["sender"] == "anonymous-signal"

    def test_sender_auto_registered_as_ephemeral(self, signal_server):
        client, server_module = signal_server
        resp = client.post("/signal", json={
            "from": "brand-new-sensor",
            "to": "receiver",
            "subject": "First contact",
        })
        assert resp.status_code == 200

        # Verify agent was registered
        from whispers.registry import AgentRegistry
        reg = AgentRegistry(server_module.db)
        agent = reg.get_agent_by_callsign("brand-new-sensor")
        assert agent is not None
        assert agent["agent_type"] == "ephemeral"

    def test_metadata_passed_through(self, signal_server):
        client, _ = signal_server
        resp = client.post("/signal", json={
            "from": "sensor",
            "to": "receiver",
            "subject": "With metadata",
            "metadata": {"room": "office-3", "temp_f": 82},
        })
        assert resp.status_code == 200

    def test_basis_field_accepted(self, signal_server):
        client, _ = signal_server
        resp = client.post("/signal", json={
            "from": "sensor",
            "to": "receiver",
            "subject": "Observed reading",
            "basis": "observed",
        })
        assert resp.status_code == 200

    def test_empty_body_accepted(self, signal_server):
        client, _ = signal_server
        resp = client.post("/signal", json={
            "from": "sensor",
            "to": "receiver",
            "subject": "Heartbeat",
        })
        assert resp.status_code == 200

    def test_non_inform_msg_type_rejected(self, signal_server):
        """Ephemeral signals are restricted to inform type for audit trail integrity."""
        client, _ = signal_server
        resp = client.post("/signal", json={
            "from": "sensor",
            "to": "receiver",
            "subject": "Status",
            "msg_type": "request",
        })
        # Ephemeral delivery is restricted to INFORM
        assert resp.status_code == 400

    def test_inform_msg_type_explicit(self, signal_server):
        client, _ = signal_server
        resp = client.post("/signal", json={
            "from": "sensor",
            "to": "receiver",
            "subject": "Status",
            "msg_type": "inform",
        })
        assert resp.status_code == 200
