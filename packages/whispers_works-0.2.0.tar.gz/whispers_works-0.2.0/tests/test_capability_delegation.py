import json
from pathlib import Path

from whispers.client import WhispersClient
from whispers.twoack_schemas import BatonUpdate


def test_working_scope_travels_with_baton_and_lifecycle_messages(temp_db):
    claude = WhispersClient("claude-code", db_path=temp_db)
    codex = WhispersClient("codex", db_path=temp_db)

    policy = {
        "can_reply": True,
        "can_summarize": True,
        "can_classify": True,
        "can_external_action": True,
    }
    claude.db.set_autonomy_policy("claude-code", "project-alpha", policy)
    codex.db.set_autonomy_policy("codex", "project-alpha", policy)

    sent = claude.send_handoff(
        "codex",
        objective="Finalize the schema packet",
        deliverable="NOTIFICATION-SCHEMA-PACKET.md",
        remaining="Write the final draft",
        next_action="Draft the packet",
        working_scope="project-alpha",
    )

    assert sent["status"] in ("delivered", "queued")
    offered = claude.list_batons(limit=10)[0]
    assert offered["working_scope"] == "project-alpha"

    acked = codex.baton_ack(sent["id"], "accepted", reason="Picking up the scoped baton")
    assert acked["status"] == "delivered"

    updated = codex.baton_update(
        sent["id"],
        "in_progress",
        progress="Drafting packet",
    )
    assert updated["status"] == "delivered"

    after_update = claude.list_batons(limit=10)[0]
    assert after_update["working_scope"] == "project-alpha"

    with codex.db.get_connection() as conn:
        row = conn.execute(
            "SELECT metadata FROM messages WHERE uuid = ?",
            (updated["id"],),
        ).fetchone()

    metadata = json.loads(row["metadata"])
    assert metadata["whispers:working_scope"] == "project-alpha"


def test_baton_scope_cannot_be_silently_rewritten(temp_db):
    claude = WhispersClient("claude-code", db_path=temp_db)
    codex = WhispersClient("codex", db_path=temp_db)
    policy = {
        "can_reply": True,
        "can_summarize": True,
        "can_classify": True,
        "can_external_action": True,
    }
    claude.db.set_autonomy_policy("claude-code", "project-alpha", policy)
    codex.db.set_autonomy_policy("codex", "project-alpha", policy)

    sent = claude.send_handoff(
        "codex",
        objective="Finalize the schema packet",
        deliverable="NOTIFICATION-SCHEMA-PACKET.md",
        remaining="Write the final draft",
        next_action="Draft the packet",
        working_scope="project-alpha",
    )
    codex.baton_ack(sent["id"], "accepted", reason="Scoped baton acknowledged")

    update = BatonUpdate(
        baton_ref=sent["id"],
        state="in_progress",
        progress="Attempting a silent scope change",
    )
    envelope, trace_id, body, metadata = codex._build_2ack_envelope(
        schema="baton_update.v1",
        headline="Baton update",
        payload=update.to_payload(),
        human_summary="Attempting a silent scope change",
        trace_id=f"baton-{sent['id'][:12]}",
        context_id=None,
        msg_id_prefix="baton-update",
    )
    metadata["whispers:working_scope"] = "project-beta"

    result = codex.send(
        to="claude-code",
        subject="Bad baton update",
        body=body,
        priority="priority",
        msg_type="inform",
        trace_id=trace_id,
        payload=envelope,
        reply_to=sent["id"],
        metadata=metadata,
    )

    assert result["status"] == "dead_lettered"
    assert result["reason"] == "scope_widening:baton_scope_change"

    with codex.db.get_connection() as conn:
        row = conn.execute(
            """
            SELECT outcome, detail
            FROM security_events
            WHERE event_type = 'scope_widening_rejected'
            ORDER BY created_at DESC
            LIMIT 1
            """
        ).fetchone()

    assert row["outcome"] == "hard_reject"
    detail = json.loads(row["detail"])
    assert detail["reason"] == "baton_scope_mismatch"
    assert detail["stored_scope"] == "project-alpha"
    assert detail["declared_scope"] == "project-beta"


def test_cross_scope_blob_fetch_without_delegation_is_audited(temp_db, monkeypatch):
    from whispers.storage import blobs as blob_module

    blob_root = Path(temp_db).parent / "blobs"
    monkeypatch.setattr(blob_module, "_DEFAULT_BLOB_DIR", blob_root)

    claude = WhispersClient("claude-code", db_path=temp_db)
    codex = WhispersClient("codex", db_path=temp_db)
    policy = {
        "can_reply": True,
        "can_summarize": True,
        "can_classify": True,
        "can_external_action": True,
    }
    claude.db.set_autonomy_policy("claude-code", "project-alpha", policy)

    ref = claude.store_blob(b"secret packet", media_type="text/plain", label="packet")["ref"]
    sent = claude.send_handoff(
        "codex",
        objective="Review the packet",
        deliverable="Review notes",
        remaining="Read the attached artifact",
        next_action="Fetch the artifact",
        working_scope="project-alpha",
        artifacts=[ref],
    )

    data = codex.fetch_blob(
        ref,
        current_scope="project-beta",
        baton_ref=sent["id"],
    )

    assert data is None

    with codex.db.get_connection() as conn:
        row = conn.execute(
            """
            SELECT outcome, detail
            FROM security_events
            WHERE event_type = 'artifact_fetch'
            ORDER BY created_at DESC
            LIMIT 1
            """
        ).fetchone()

    assert row["outcome"] == "cross_scope_blocked"
    detail = json.loads(row["detail"])
    assert detail["artifact_ref"] == ref
    assert detail["baton_ref"] == sent["id"]
    assert detail["source_scope"] == "project-alpha"
    assert detail["target_scope"] == "project-beta"
    assert detail["delegated_capability"] is False
    assert detail["operator_override"] is False
    assert detail["blocked"] is True
