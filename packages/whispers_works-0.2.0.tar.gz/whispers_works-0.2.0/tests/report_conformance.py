import glob
import json
import os
import sys
from datetime import datetime, timezone
from pathlib import Path

# Provide fallback pathing for simple local execution
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from whispers.twoack import (
    validate_message,
    evaluate_preflight,
    PreflightPolicy,
    ERR_NEGOTIATION_FAILED
)

# Known schemas for preflight mocking
KNOWN_REPLY_SCHEMAS = (
    "decision_response.v1",
    "status_update.v1",
    "workspace_state.v1",
)

def _conformance_preflight_kwargs(fixture_data):
    expected_preflight = fixture_data["expected"].get("preflight_decision")
    accept_schemas = fixture_data["input"].get("accept_schemas")
    kwargs = {
        "policy": PreflightPolicy(
            receiver_trust_tier=1 if expected_preflight == "reject_trust" else 5
        ),
        "now": datetime.now(timezone.utc).isoformat(),
    }
    if accept_schemas is None or accept_schemas == []:
        return kwargs
    if expected_preflight == "reject_negotiation":
        for candidate in KNOWN_REPLY_SCHEMAS:
            if candidate not in accept_schemas:
                kwargs["proposed_reply_schema"] = candidate
                kwargs["available_reply_schemas"] = KNOWN_REPLY_SCHEMAS
                return kwargs
        kwargs["proposed_reply_schema"] = "unsupported_reply.v1"
        return kwargs
    kwargs["proposed_reply_schema"] = accept_schemas[0]
    kwargs["available_reply_schemas"] = KNOWN_REPLY_SCHEMAS
    return kwargs

def run_tests():
    conformance_dir = Path(__file__).resolve().parent / "fixtures" / "2ack" / "conformance"
    conformance_files = sorted(glob.glob(str(conformance_dir / "*.json")))

    categories = {
        "A": {"name": "Envelope Validity", "total": 0, "passed": 0},
        "B": {"name": "Schema Payloads", "total": 0, "passed": 0},
        "C": {"name": "Negotiation", "total": 0, "passed": 0},
        "D": {"name": "Trust & Policy", "total": 0, "passed": 0},
        "E": {"name": "Omission Semantics", "total": 0, "passed": 0},
    }

    print("Running 2ACK Conformance Suite...\n")

    failure_count = 0

    for filepath in conformance_files:
        with open(filepath, "r", encoding="utf-8") as f:
            data = json.load(f)
            for item in data:
                cat = item["category"]
                categories[cat]["total"] += 1

                input_envelope = item["input"]
                expected = item["expected"]

                passed = True

                # Validation
                result = validate_message(input_envelope)
                if result.valid != expected.get("valid", True):
                    passed = False
                
                expected_codes = expected.get("error_codes", [])
                for code in expected_codes:
                    if code not in result.codes:
                        passed = False

                # Preflight
                expected_preflight = expected.get("preflight_decision")
                if expected_preflight and passed:
                    decision = evaluate_preflight(dict(input_envelope), **_conformance_preflight_kwargs(item))
                    if expected_preflight == "reject_negotiation":
                        if decision.action != "reject" or decision.code != ERR_NEGOTIATION_FAILED:
                            passed = False
                    elif expected_preflight == "reject_trust":
                        if decision.action != "reject":
                            passed = False
                    else:
                        if decision.action != expected_preflight:
                            passed = False

                if passed:
                    categories[cat]["passed"] += 1
                else:
                    failure_count += 1

    level2_passes = True
    level3_passes = True

    print("==========================================")
    print(" 2ACK Conformance Results")
    print("==========================================\n")

    for cat_id, stats in categories.items():
        pass_rate = (stats["passed"] / stats["total"]) * 100 if stats["total"] > 0 else 0
        print(f"[{cat_id}] {stats['name']:25s} : {stats['passed']}/{stats['total']} ({pass_rate:.1f}%)")

        if stats["passed"] != stats["total"]:
            if cat_id in ["A", "B", "E"]:
                level2_passes = False
            if cat_id in ["C", "D"]:
                level3_passes = False

    print("\n------------------------------------------")
    if not level2_passes:
        conformance_level = 1
    elif not level3_passes:
        conformance_level = 2
    else:
        conformance_level = 3

    print(f"OVERALL CONFORMANCE LEVEL : Level {conformance_level}")
    print("------------------------------------------\n")
    
    if conformance_level == 3:
        print("SUCCESS: Full Level 3 conformance achieved.")
    elif conformance_level == 2:
        print("PARTIAL: Achieved Level 2. Level 3 (Trust/Negotiation) failed.")
    elif conformance_level <= 1:
        print("FAIL: Failed to achieve basic Level 2 schema conformance.")

    sys.exit(0 if failure_count == 0 else 1)

if __name__ == "__main__":
    run_tests()
