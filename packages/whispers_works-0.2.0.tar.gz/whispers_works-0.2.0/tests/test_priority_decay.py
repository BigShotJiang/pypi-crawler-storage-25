"""Tests for priority decay — urgency half-life.

Covers:
- FLASH decays to PRIORITY after 15 min
- PRIORITY decays to ROUTINE after 60 min
- ROUTINE never decays
- SYSTEM never decays
- Recent FLASH stays FLASH
- Batch processing works
- Original priority preserved
"""

import pytest
from whispers.priority_decay import (
    compute_decayed_priority,
    apply_priority_decay,
    apply_priority_decay_batch,
    FLASH_DECAY_SECONDS,
    PRIORITY_DECAY_SECONDS,
)


class TestComputeDecayedPriority:
    def test_flash_stays_flash_when_fresh(self):
        assert compute_decayed_priority("flash", 60) == "flash"

    def test_flash_decays_to_priority(self):
        assert compute_decayed_priority("flash", FLASH_DECAY_SECONDS + 1) == "priority"

    def test_priority_stays_priority_when_fresh(self):
        assert compute_decayed_priority("priority", 300) == "priority"

    def test_priority_decays_to_routine(self):
        assert compute_decayed_priority("priority", PRIORITY_DECAY_SECONDS + 1) == "routine"

    def test_routine_never_decays(self):
        assert compute_decayed_priority("routine", 999999) == "routine"

    def test_system_never_decays(self):
        assert compute_decayed_priority("system", 999999) == "system"


class TestApplyPriorityDecay:
    def test_flash_message_decays(self):
        from datetime import datetime, timezone, timedelta
        old_time = (datetime.now(timezone.utc) - timedelta(minutes=20)).isoformat()
        msg = {"priority": "flash", "created_at": old_time, "body": "Urgent!"}
        result = apply_priority_decay(msg)
        assert result["priority"] == "priority"
        assert result["original_priority"] == "flash"
        assert result["effective_priority"] == "priority"

    def test_fresh_flash_stays(self):
        from datetime import datetime, timezone
        now = datetime.now(timezone.utc).isoformat()
        msg = {"priority": "flash", "created_at": now, "body": "Urgent!"}
        result = apply_priority_decay(msg)
        assert result["priority"] == "flash"
        assert "original_priority" not in result

    def test_routine_passes_through(self):
        msg = {"priority": "routine", "created_at": "2020-01-01T00:00:00Z", "body": "Old"}
        result = apply_priority_decay(msg)
        assert result is msg  # Same object, no copy

    def test_no_mutation(self):
        from datetime import datetime, timezone, timedelta
        old_time = (datetime.now(timezone.utc) - timedelta(hours=2)).isoformat()
        msg = {"priority": "priority", "created_at": old_time, "body": "Important"}
        original_priority = msg["priority"]
        apply_priority_decay(msg)
        assert msg["priority"] == original_priority  # Original not mutated

    def test_batch_processing(self):
        from datetime import datetime, timezone, timedelta
        old = (datetime.now(timezone.utc) - timedelta(hours=2)).isoformat()
        fresh = datetime.now(timezone.utc).isoformat()
        messages = [
            {"priority": "flash", "created_at": old, "body": "Old flash"},
            {"priority": "flash", "created_at": fresh, "body": "New flash"},
            {"priority": "routine", "created_at": old, "body": "Old routine"},
        ]
        results = apply_priority_decay_batch(messages)
        assert results[0]["priority"] == "priority"  # Decayed
        assert results[1]["priority"] == "flash"      # Still fresh
        assert results[2]["priority"] == "routine"    # Never decays
