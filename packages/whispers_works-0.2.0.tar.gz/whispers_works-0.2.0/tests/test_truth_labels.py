"""Tests for 2ACK truth labels and reception truth (P1.6)."""
import pytest
from whispers.twoack import (
    ClaimLabel,
    Expectation,
    NegativeState,
    ReceptionTruth,
    ValidationResult,
    VALID_ATTENTION_POSTURES,
    VALID_BASIS_VALUES,
    VALID_CLOSURE_POSTURES,
    VALID_ESCALATION_POSTURES,
    VALID_NEGATIVE_STATES,
    VALID_PROOF_POSTURES,
    VALID_RECEPTION_STAGES,
    VALID_RESPONSE_POSTURES,
    VALID_TIMING_POSTURES,
    validate_envelope,
)


class TestNegativeState:
    def test_valid_state(self):
        ns = NegativeState(state="stale", reason="No heartbeat")
        assert ns.state == "stale"
        assert ns.reason == "No heartbeat"

    def test_invalid_state_raises(self):
        with pytest.raises(ValueError, match="Unknown negative state"):
            NegativeState(state="bogus")

    def test_to_dict_minimal(self):
        ns = NegativeState(state="contradicted")
        assert ns.to_dict() == {"state": "contradicted"}

    def test_to_dict_full(self):
        ns = NegativeState(
            state="stale",
            reason="45min since heartbeat",
            detected_at="2026-04-01T00:00:00Z",
            detected_by="whispers-server",
        )
        d = ns.to_dict()
        assert d["state"] == "stale"
        assert d["reason"] == "45min since heartbeat"
        assert d["detected_at"] == "2026-04-01T00:00:00Z"
        assert d["detected_by"] == "whispers-server"

    def test_roundtrip(self):
        ns = NegativeState(state="revoked", reason="Agent withdrew")
        assert NegativeState.from_dict(ns.to_dict()) == ns


class TestClaimLabel:
    def test_valid_basis(self):
        for basis in VALID_BASIS_VALUES:
            label = ClaimLabel(basis=basis)
            assert label.basis == basis

    def test_invalid_basis_raises(self):
        with pytest.raises(ValueError, match="Unknown basis"):
            ClaimLabel(basis="made_up")

    def test_confidence_range(self):
        ClaimLabel(confidence=0.0)
        ClaimLabel(confidence=1.0)
        ClaimLabel(confidence=0.5)
        with pytest.raises(ValueError, match="Confidence must be"):
            ClaimLabel(confidence=1.1)
        with pytest.raises(ValueError, match="Confidence must be"):
            ClaimLabel(confidence=-0.1)

    def test_none_basis_allowed(self):
        label = ClaimLabel()
        assert label.basis is None

    def test_with_negative(self):
        label = ClaimLabel(basis="declared", confidence=0.8)
        ns = NegativeState(state="stale", reason="old")
        degraded = label.with_negative(ns)
        assert degraded.is_stale
        assert degraded.is_degraded
        assert degraded.basis == "declared"
        assert degraded.confidence == 0.8
        # Original unchanged
        assert not label.is_stale

    def test_multiple_negatives_accumulate(self):
        label = ClaimLabel(basis="declared")
        label = label.with_negative(NegativeState(state="stale"))
        label = label.with_negative(NegativeState(state="contradicted"))
        assert len(label.negative_states) == 2
        assert label.is_stale
        assert label.is_degraded

    def test_to_dict_empty(self):
        assert ClaimLabel().to_dict() == {}

    def test_to_dict_full(self):
        label = ClaimLabel(
            basis="observed",
            as_of="2026-04-01T00:00:00Z",
            confidence=0.9,
            evidence_refs=("heartbeat:5s", "session:abc"),
        )
        d = label.to_dict()
        assert d["basis"] == "observed"
        assert d["confidence"] == 0.9
        assert d["evidence_refs"] == ["heartbeat:5s", "session:abc"]

    def test_roundtrip(self):
        label = ClaimLabel(
            basis="attested",
            as_of="2026-04-01T00:00:00Z",
            confidence=1.0,
            evidence_refs=("session:abc",),
            negative_states=(NegativeState(state="disputed", reason="challenged"),),
        )
        restored = ClaimLabel.from_dict(label.to_dict())
        assert restored.basis == label.basis
        assert restored.confidence == label.confidence
        assert len(restored.negative_states) == 1
        assert restored.negative_states[0].state == "disputed"


class TestReceptionTruth:
    def test_valid_stages(self):
        for stage in VALID_RECEPTION_STAGES:
            rt = ReceptionTruth.at_stage(stage, "2026-04-01T00:00:00Z")
            assert rt.stage == stage

    def test_invalid_stage_raises(self):
        with pytest.raises(ValueError, match="Unknown reception stage"):
            ReceptionTruth(
                stage="bogus",
                label=ClaimLabel(basis="declared"),
            )

    def test_at_stage_canonical_basis(self):
        rt = ReceptionTruth.at_stage("delivered", "2026-04-01T00:00:00Z")
        assert rt.label.basis == "attested"
        assert rt.delivered_at == "2026-04-01T00:00:00Z"

        rt2 = ReceptionTruth.at_stage("seen", "2026-04-01T00:01:00Z")
        assert rt2.label.basis == "observed"

        rt3 = ReceptionTruth.at_stage("read", "2026-04-01T00:02:00Z")
        assert rt3.label.basis == "declared"

        rt4 = ReceptionTruth.at_stage("acted_on", "2026-04-01T00:03:00Z")
        assert rt4.label.basis == "attested"

    def test_advance_forward(self):
        rt = ReceptionTruth.at_stage("queued", "2026-04-01T00:00:00Z")
        rt2 = rt.advance("delivered", "2026-04-01T00:00:01Z")
        assert rt2.stage == "delivered"
        assert rt2.queued_at == "2026-04-01T00:00:00Z"
        assert rt2.delivered_at == "2026-04-01T00:00:01Z"

    def test_advance_backward_raises(self):
        rt = ReceptionTruth.at_stage("seen", "2026-04-01T00:01:00Z")
        with pytest.raises(ValueError, match="Cannot go backward"):
            rt.advance("delivered", "2026-04-01T00:00:00Z")

    def test_advance_same_stage_raises(self):
        rt = ReceptionTruth.at_stage("delivered", "2026-04-01T00:00:00Z")
        with pytest.raises(ValueError, match="Cannot go backward"):
            rt.advance("delivered", "2026-04-01T00:00:01Z")

    def test_awaiting_read(self):
        assert ReceptionTruth.at_stage("queued", "t").awaiting_read
        assert ReceptionTruth.at_stage("delivered", "t").awaiting_read
        assert not ReceptionTruth.at_stage("seen", "t").awaiting_read

    def test_pending_action(self):
        rt = ReceptionTruth.at_stage("seen", "2026-04-01T00:01:00Z")
        assert rt.is_pending_action

        rt2 = rt.advance("acted_on", "2026-04-01T00:02:00Z")
        assert not rt2.is_pending_action

    def test_roundtrip(self):
        rt = ReceptionTruth.at_stage("delivered", "2026-04-01T00:00:00Z")
        rt = rt.advance("seen", "2026-04-01T00:01:00Z")
        restored = ReceptionTruth.from_dict(rt.to_dict())
        assert restored.stage == "seen"
        assert restored.delivered_at == "2026-04-01T00:00:00Z"
        assert restored.seen_at == "2026-04-01T00:01:00Z"

    def test_from_db_row_queued(self):
        row = {"created_at": "2026-04-01T00:00:00Z", "delivery_status": "queued"}
        rt = ReceptionTruth.from_db_row(row)
        assert rt.stage == "queued"
        assert rt.label.basis == "attested"

    def test_from_db_row_delivered(self):
        row = {
            "created_at": "2026-04-01T00:00:00Z",
            "delivery_status": "delivered",
            "claimed_at": "2026-04-01T00:00:01Z",
        }
        rt = ReceptionTruth.from_db_row(row)
        assert rt.stage == "delivered"
        assert rt.delivered_at == "2026-04-01T00:00:01Z"

    def test_from_db_row_seen(self):
        row = {
            "created_at": "2026-04-01T00:00:00Z",
            "delivery_status": "delivered",
            "claimed_at": "2026-04-01T00:00:01Z",
            "read_at": "2026-04-01T00:01:00Z",
        }
        rt = ReceptionTruth.from_db_row(row)
        assert rt.stage == "seen"
        assert rt.label.basis == "observed"

    def test_from_db_row_acted_on(self):
        row = {
            "created_at": "2026-04-01T00:00:00Z",
            "delivery_status": "delivered",
            "claimed_at": "2026-04-01T00:00:01Z",
            "read_at": "2026-04-01T00:01:00Z",
            "ack_state": "accepted",
            "acked_at": "2026-04-01T00:02:00Z",
        }
        rt = ReceptionTruth.from_db_row(row)
        assert rt.stage == "acted_on"
        assert rt.label.basis == "attested"
        assert rt.acted_on_at == "2026-04-01T00:02:00Z"

    def test_from_db_row_empty(self):
        rt = ReceptionTruth.from_db_row({})
        assert rt.stage == "queued"

    def test_full_lifecycle(self):
        """Message goes through entire lifecycle."""
        rt = ReceptionTruth.at_stage("queued", "2026-04-01T00:00:00Z")
        rt = rt.advance("delivered", "2026-04-01T00:00:01Z")
        rt = rt.advance("seen", "2026-04-01T00:01:00Z")
        rt = rt.advance("read", "2026-04-01T00:01:05Z")
        rt = rt.advance("acted_on", "2026-04-01T00:02:00Z")

        assert rt.stage == "acted_on"
        assert rt.queued_at is not None
        assert rt.delivered_at is not None
        assert rt.seen_at is not None
        assert rt.read_at is not None
        assert rt.acted_on_at is not None
        assert not rt.awaiting_read
        assert not rt.is_pending_action


def _make_envelope(**overrides):
    """Build a minimal valid 2ACK envelope."""
    base = {
        "wire_v": 1,
        "schema": "status_update.v1",
        "trace": {"message_id": "test-123"},
        "payload": {"status": "ready"},
    }
    base.update(overrides)
    return base


class TestEnvelopeLabelValidation:
    def test_valid_label_passes(self):
        env = _make_envelope(readiness_label={
            "basis": "observed",
            "as_of": "2026-04-01T00:00:00Z",
            "confidence": 0.9,
        })
        result = validate_envelope(env)
        assert result.valid

    def test_invalid_basis_in_label(self):
        env = _make_envelope(readiness_label={"basis": "made_up"})
        result = validate_envelope(env)
        assert not result.valid
        assert any("basis" in str(e) for e in result.errors)

    def test_invalid_confidence_in_label(self):
        env = _make_envelope(readiness_label={"confidence": 2.0})
        result = validate_envelope(env)
        assert not result.valid

    def test_invalid_evidence_refs(self):
        env = _make_envelope(readiness_label={"evidence_refs": "not-a-list"})
        result = validate_envelope(env)
        assert not result.valid

    def test_valid_negative_states_in_label(self):
        env = _make_envelope(readiness_label={
            "basis": "declared",
            "negative_states": [{"state": "stale", "reason": "old"}],
        })
        result = validate_envelope(env)
        assert result.valid

    def test_invalid_negative_state_in_label(self):
        env = _make_envelope(readiness_label={
            "negative_states": [{"state": "bogus"}],
        })
        result = validate_envelope(env)
        assert not result.valid

    def test_label_not_object_fails(self):
        env = _make_envelope(readiness_label="string")
        result = validate_envelope(env)
        assert not result.valid

    def test_payload_label_validated(self):
        env = _make_envelope(payload={
            "status": "ready",
            "status_label": {"basis": "invalid_basis"},
        })
        result = validate_envelope(env)
        assert not result.valid

    def test_label_with_no_fields_passes(self):
        """Empty label is valid -- spec says omission is allowed."""
        env = _make_envelope(readiness_label={})
        result = validate_envelope(env)
        assert result.valid

    def test_non_label_suffix_ignored(self):
        """Fields not ending in _label are not treated as truth labels."""
        env = _make_envelope(custom_field={"basis": "not_valid_but_irrelevant"})
        result = validate_envelope(env)
        assert result.valid


class TestExpectation:
    def test_valid_postures(self):
        e = Expectation(
            attention="actionable",
            response="required",
            timing="soon",
            closure="explicit_close",
            escalation="escalate_if_blocked",
            proof="structured",
        )
        assert e.attention == "actionable"
        assert e.needs_reply
        assert e.needs_closure

    def test_invalid_posture_raises(self):
        with pytest.raises(ValueError, match="Unknown attention posture"):
            Expectation(attention="bogus")
        with pytest.raises(ValueError, match="Unknown response posture"):
            Expectation(response="bogus")
        with pytest.raises(ValueError, match="Unknown timing posture"):
            Expectation(timing="bogus")

    def test_none_postures_allowed(self):
        e = Expectation()
        assert e.to_dict() == {}

    def test_is_blocking(self):
        assert Expectation(attention="blocking").is_blocking
        assert Expectation(attention="interrupt").is_blocking
        assert not Expectation(attention="actionable").is_blocking
        assert not Expectation(attention="ambient").is_blocking

    def test_needs_reply(self):
        assert Expectation(response="required").needs_reply
        assert Expectation(response="ack_then_answer").needs_reply
        assert not Expectation(response="none").needs_reply
        assert not Expectation(response="if_useful").needs_reply

    def test_needs_closure(self):
        assert Expectation(closure="explicit_close").needs_closure
        assert Expectation(closure="explicit_reject").needs_closure
        assert not Expectation(closure="none").needs_closure

    def test_to_attention_tier(self):
        assert Expectation(attention="interrupt").to_attention_tier() == "interrupt_now"
        assert Expectation(attention="blocking").to_attention_tier() == "interrupt_now"
        assert Expectation(timing="now").to_attention_tier() == "interrupt_now"
        assert Expectation(attention="actionable").to_attention_tier() == "surface_now"
        assert Expectation(response="required").to_attention_tier() == "surface_now"
        assert Expectation(attention="ambient").to_attention_tier() == "hold_visible"
        assert Expectation(attention="fyi").to_attention_tier() == "hold_visible"

    def test_roundtrip(self):
        e = Expectation(attention="actionable", response="required", timing="soon")
        restored = Expectation.from_dict(e.to_dict())
        assert restored.attention == e.attention
        assert restored.response == e.response
        assert restored.timing == e.timing

    def test_for_schema_decision_request(self):
        e = Expectation.for_schema("decision_request.v1")
        assert e.attention == "actionable"
        assert e.response == "required"
        assert e.closure == "explicit_close"
        assert e.proof == "structured"

    def test_for_schema_status_update(self):
        e = Expectation.for_schema("status_update.v1")
        assert e.attention == "fyi"
        assert e.response == "none"

    def test_for_schema_flash_override(self):
        e = Expectation.for_schema("status_update.v1", priority="flash")
        assert e.attention == "interrupt"
        assert e.timing == "now"

    def test_for_schema_priority_override(self):
        e = Expectation.for_schema("status_update.v1", priority="priority")
        assert e.attention == "actionable"
        assert e.timing == "soon"

    def test_for_schema_unknown(self):
        e = Expectation.for_schema("unknown_thing.v1")
        assert e.attention == "fyi"
        assert e.response == "if_useful"

    def test_envelope_validation_valid(self):
        env = _make_envelope(expectation={
            "attention": "actionable",
            "response": "required",
        })
        result = validate_envelope(env)
        assert result.valid

    def test_envelope_validation_invalid_posture(self):
        env = _make_envelope(expectation={"attention": "bogus_value"})
        result = validate_envelope(env)
        assert not result.valid

    def test_envelope_validation_null_expectation(self):
        env = _make_envelope(expectation=None)
        result = validate_envelope(env)
        assert result.valid

    def test_envelope_validation_not_object(self):
        env = _make_envelope(expectation="string")
        result = validate_envelope(env)
        assert not result.valid


# ---------------------------------------------------------------------------
# Participant roles (Slice 10)
# ---------------------------------------------------------------------------

class TestParticipantRoles:
    def test_basic_construction(self):
        from whispers.twoack import ParticipantRoles
        roles = ParticipantRoles(origin="gateway-1", subject_of="alice", principal="operator")
        assert roles.origin == "gateway-1"
        assert roles.subject_of == "alice"
        assert roles.principal == "operator"
        assert roles.is_relayed
        assert roles.is_delegated
        assert roles.has_explicit_subject

    def test_defaults_are_none(self):
        from whispers.twoack import ParticipantRoles
        roles = ParticipantRoles()
        assert not roles.is_relayed
        assert not roles.is_delegated
        assert not roles.has_explicit_subject
        assert roles.to_dict() == {}

    def test_roundtrip(self):
        from whispers.twoack import ParticipantRoles
        roles = ParticipantRoles(origin="relay", principal="boss")
        d = roles.to_dict()
        assert d == {"origin": "relay", "principal": "boss"}
        restored = ParticipantRoles.from_dict(d)
        assert restored.origin == "relay"
        assert restored.principal == "boss"
        assert restored.subject_of is None

    def test_from_dict_with_subject_agent_alias(self):
        from whispers.twoack import ParticipantRoles
        roles = ParticipantRoles.from_dict({"subject_agent": "alice"})
        assert roles.subject_of == "alice"


class TestParticipantState:
    def test_valid_construction(self):
        from whispers.twoack import ParticipantState
        state = ParticipantState(
            wake_posture="manual_wake",
            readiness="busy",
            interruptibility="defer",
            context_load=0.7,
            basis="declared",
        )
        assert state.wake_posture == "manual_wake"
        assert state.readiness == "busy"
        d = state.to_dict()
        assert d["schema"] == "participant_state.v1"
        assert d["context_load"] == 0.7

    def test_invalid_wake_posture_raises(self):
        from whispers.twoack import ParticipantState
        with pytest.raises(ValueError, match="wake_posture"):
            ParticipantState(wake_posture="sleeping")

    def test_invalid_readiness_raises(self):
        from whispers.twoack import ParticipantState
        with pytest.raises(ValueError, match="readiness"):
            ParticipantState(readiness="on_fire")

    def test_invalid_context_load_raises(self):
        from whispers.twoack import ParticipantState
        with pytest.raises(ValueError, match="context_load"):
            ParticipantState(context_load=1.5)

    def test_roundtrip(self):
        from whispers.twoack import ParticipantState
        state = ParticipantState(
            readiness="blocked",
            degraded_reason="context overflow",
            quality_risk="high",
        )
        d = state.to_dict()
        restored = ParticipantState.from_dict(d)
        assert restored.readiness == "blocked"
        assert restored.degraded_reason == "context overflow"
        assert restored.quality_risk == "high"

    def test_empty_state(self):
        from whispers.twoack import ParticipantState
        state = ParticipantState()
        d = state.to_dict()
        assert d == {"schema": "participant_state.v1"}


class TestConsequenceScope:
    def test_valid_scopes(self):
        from whispers.envelope import Envelope, VALID_CONSEQUENCE_SCOPES
        for scope in VALID_CONSEQUENCE_SCOPES:
            env = Envelope(
                sender="agent-a", recipient="agent-b",
                msg_type="inform", subject="test",
                consequence_scope=scope,
            )
            assert env.consequence_scope == scope

    def test_invalid_scope_raises(self):
        from whispers.envelope import Envelope
        with pytest.raises(ValueError, match="consequence_scope"):
            Envelope(
                sender="agent-a", recipient="agent-b",
                msg_type="inform", subject="test",
                consequence_scope="nuclear",
            )

    def test_none_scope_allowed(self):
        from whispers.envelope import Envelope
        env = Envelope(
            sender="agent-a", recipient="agent-b",
            msg_type="inform", subject="test",
        )
        assert env.consequence_scope is None

    def test_envelope_participant_roles(self):
        from whispers.envelope import Envelope
        env = Envelope(
            sender="gateway", recipient="operator",
            msg_type="inform", subject="sensor alert",
            origin="thermostat-1",
            subject_of="living-room-hvac",
            principal="home-automation",
            consequence_scope="physical_reversible",
        )
        assert env.origin == "thermostat-1"
        assert env.subject_of == "living-room-hvac"
        assert env.principal == "home-automation"
        assert env.consequence_scope == "physical_reversible"


# ---------------------------------------------------------------------------
# Actuation lifecycle (Slice 11)
# ---------------------------------------------------------------------------

class TestActuationLifecycle:
    def test_basic_construction(self):
        from whispers.twoack import ActuationLifecycle
        lc = ActuationLifecycle(action_ref="msg-123", state="intent")
        assert lc.state == "intent"
        assert not lc.is_terminal
        assert lc.operator_label == "proposed"

    def test_invalid_state_raises(self):
        from whispers.twoack import ActuationLifecycle
        with pytest.raises(ValueError, match="actuation state"):
            ActuationLifecycle(action_ref="msg-123", state="exploding")

    def test_terminal_states(self):
        from whispers.twoack import ActuationLifecycle, ACTUATION_TERMINAL_STATES
        for state in ACTUATION_TERMINAL_STATES:
            lc = ActuationLifecycle(action_ref="msg-123", state=state)
            assert lc.is_terminal
            assert lc.valid_transitions() == frozenset()

    def test_valid_transitions_from_intent(self):
        from whispers.twoack import ActuationLifecycle
        lc = ActuationLifecycle(action_ref="msg-123", state="intent")
        assert lc.can_transition_to("approved")
        assert lc.can_transition_to("cancelled")
        assert lc.can_transition_to("failed")
        assert not lc.can_transition_to("confirmed")
        assert not lc.can_transition_to("executing")

    def test_valid_transitions_from_executing(self):
        from whispers.twoack import ActuationLifecycle
        lc = ActuationLifecycle(action_ref="msg-123", state="executing")
        assert lc.can_transition_to("observed")
        assert lc.can_transition_to("confirmed")
        assert lc.can_transition_to("failed")
        assert lc.can_transition_to("reverted")
        assert not lc.can_transition_to("approved")

    def test_full_lifecycle_roundtrip(self):
        from whispers.twoack import ActuationLifecycle
        lc = ActuationLifecycle(
            action_ref="msg-456",
            state="confirmed",
            consequence_scope="physical_reversible",
            action_class="hvac_setpoint",
            intent_summary="Set living room to 72F",
            target="thermostat-1",
            approved_by="operator",
            approved_at="2026-04-01T10:00:00Z",
            issued_at="2026-04-01T10:00:01Z",
            observed_effect="Temperature reading 72F after 15 minutes",
            observed_at="2026-04-01T10:15:00Z",
            outcome_summary="Setpoint achieved",
            outcome_at="2026-04-01T10:15:00Z",
            evidence_refs=["sensor-reading-abc"],
            basis="observed",
        )
        d = lc.to_dict()
        assert d["schema"] == "actuation_lifecycle.v1"
        assert d["state"] == "confirmed"
        assert d["is_terminal"] is True
        assert d["operator_label"] == "confirmed"
        assert d["consequence_scope"] == "physical_reversible"
        assert d["evidence_refs"] == ["sensor-reading-abc"]

        restored = ActuationLifecycle.from_dict(d)
        assert restored.state == "confirmed"
        assert restored.action_ref == "msg-456"
        assert restored.observed_effect == "Temperature reading 72F after 15 minutes"

    def test_invalid_consequence_scope_raises(self):
        from whispers.twoack import ActuationLifecycle
        with pytest.raises(ValueError, match="consequence_scope"):
            ActuationLifecycle(action_ref="msg-123", consequence_scope="nuclear")

    def test_failure_with_reason(self):
        from whispers.twoack import ActuationLifecycle
        lc = ActuationLifecycle(
            action_ref="msg-789",
            state="failed",
            failure_reason="Device unreachable after 3 retries",
            basis="observed",
        )
        assert lc.is_terminal
        assert lc.operator_label == "FAILED"
        d = lc.to_dict()
        assert d["failure_reason"] == "Device unreachable after 3 retries"

    def test_revert_with_reason(self):
        from whispers.twoack import ActuationLifecycle
        lc = ActuationLifecycle(
            action_ref="msg-101",
            state="reverted",
            revert_reason="Operator cancelled after observing unexpected side effect",
        )
        assert lc.is_terminal
        assert lc.operator_label == "REVERTED"


# ---------------------------------------------------------------------------
# Alarm collapse (Slice 12)
# ---------------------------------------------------------------------------

class TestAlarmSignal:
    def test_severity_rank_base(self):
        from whispers.twoack import AlarmSignal
        info = AlarmSignal(signal_id="1", source="sensor-a", severity="info")
        crit = AlarmSignal(signal_id="2", source="sensor-b", severity="critical")
        assert crit.severity_rank > info.severity_rank

    def test_severity_rank_boosted_by_consequence(self):
        from whispers.twoack import AlarmSignal
        digital_crit = AlarmSignal(signal_id="1", source="s", severity="critical", consequence_scope="digital")
        physical_warning = AlarmSignal(signal_id="2", source="s", severity="warning", consequence_scope="physical_irreversible")
        # physical_irreversible boost (+2) on warning (rank 1) = 3
        # digital boost (+0) on critical (rank 3) = 3
        assert physical_warning.severity_rank == digital_crit.severity_rank

    def test_to_dict(self):
        from whispers.twoack import AlarmSignal
        s = AlarmSignal(signal_id="abc", source="thermostat", severity="elevated",
                        action_class="hvac", summary="Temp spike")
        d = s.to_dict()
        assert d["signal_id"] == "abc"
        assert d["severity"] == "elevated"
        assert d["action_class"] == "hvac"


class TestDecisionSurface:
    def test_single_signal_surface(self):
        from whispers.twoack import AlarmSignal, DecisionSurface
        signal = AlarmSignal(signal_id="1", source="sensor", severity="warning",
                            consequence_scope="physical_reversible", summary="Temp high")
        surface = DecisionSurface(
            group_id="test-1",
            signals=[signal],
            headline="Temperature alert",
            options=["Adjust setpoint", "Ignore"],
        )
        assert surface.signal_count == 1
        assert surface.promoted_severity == "warning"
        assert surface.promoted_consequence_scope == "physical_reversible"
        d = surface.to_dict()
        assert d["schema"] == "decision_surface.v1"
        assert d["signal_count"] == 1
        assert len(d["options"]) == 2

    def test_severity_promotion(self):
        from whispers.twoack import AlarmSignal, DecisionSurface
        signals = [
            AlarmSignal(signal_id="1", source="s1", severity="info"),
            AlarmSignal(signal_id="2", source="s2", severity="critical"),
            AlarmSignal(signal_id="3", source="s3", severity="warning"),
        ]
        surface = DecisionSurface(group_id="test-2", signals=signals)
        assert surface.promoted_severity == "critical"

    def test_consequence_scope_promotion(self):
        from whispers.twoack import AlarmSignal, DecisionSurface
        signals = [
            AlarmSignal(signal_id="1", source="s1", consequence_scope="digital"),
            AlarmSignal(signal_id="2", source="s2", consequence_scope="physical_irreversible"),
        ]
        surface = DecisionSurface(group_id="test-3", signals=signals)
        assert surface.promoted_consequence_scope == "physical_irreversible"

    def test_evidence_deduplication(self):
        from whispers.twoack import AlarmSignal, DecisionSurface
        signals = [
            AlarmSignal(signal_id="1", source="s1", evidence_refs=["a", "b"]),
            AlarmSignal(signal_id="2", source="s2", evidence_refs=["b", "c"]),
        ]
        surface = DecisionSurface(group_id="test-4", signals=signals)
        assert surface.all_evidence == ["a", "b", "c"]

    def test_unique_sources(self):
        from whispers.twoack import AlarmSignal, DecisionSurface
        signals = [
            AlarmSignal(signal_id="1", source="sensor-a"),
            AlarmSignal(signal_id="2", source="sensor-b"),
            AlarmSignal(signal_id="3", source="sensor-a"),
        ]
        surface = DecisionSurface(group_id="test-5", signals=signals)
        assert surface.sources == ["sensor-a", "sensor-b"]

    def test_roundtrip(self):
        from whispers.twoack import AlarmSignal, DecisionSurface
        surface = DecisionSurface(
            group_id="rt-1",
            signals=[AlarmSignal(signal_id="s1", source="src", severity="elevated")],
            headline="Test roundtrip",
            options=["Fix", "Ignore"],
            recommended_action="Fix",
        )
        d = surface.to_dict()
        restored = DecisionSurface.from_dict(d)
        assert restored.group_id == "rt-1"
        assert restored.signal_count == 1
        assert restored.headline == "Test roundtrip"
        assert restored.recommended_action == "Fix"


class TestCollapseAlarms:
    def test_empty_input(self):
        from whispers.twoack import collapse_alarms
        assert collapse_alarms([]) == []

    def test_single_group(self):
        from whispers.twoack import AlarmSignal, collapse_alarms
        signals = [
            AlarmSignal(signal_id="1", source="s1", severity="warning", action_class="hvac"),
            AlarmSignal(signal_id="2", source="s2", severity="critical", action_class="hvac"),
        ]
        surfaces = collapse_alarms(signals)
        assert len(surfaces) == 1
        assert surfaces[0].signal_count == 2
        assert surfaces[0].promoted_severity == "critical"
        assert surfaces[0].action_class == "hvac"

    def test_multiple_groups(self):
        from whispers.twoack import AlarmSignal, collapse_alarms
        signals = [
            AlarmSignal(signal_id="1", source="s1", severity="info", action_class="network"),
            AlarmSignal(signal_id="2", source="s2", severity="critical", action_class="security"),
            AlarmSignal(signal_id="3", source="s3", severity="warning", action_class="network"),
        ]
        surfaces = collapse_alarms(signals)
        assert len(surfaces) == 2
        # Most severe group first
        assert surfaces[0].action_class == "security"
        assert surfaces[1].action_class == "network"

    def test_headline_single_signal(self):
        from whispers.twoack import AlarmSignal, collapse_alarms
        signals = [AlarmSignal(signal_id="1", source="thermostat", action_class="hvac", summary="Temp spike to 85F")]
        surfaces = collapse_alarms(signals)
        assert "Temp spike to 85F" in surfaces[0].headline

    def test_headline_multiple_sources(self):
        from whispers.twoack import AlarmSignal, collapse_alarms
        signals = [
            AlarmSignal(signal_id="1", source="sensor-a", action_class="hvac"),
            AlarmSignal(signal_id="2", source="sensor-b", action_class="hvac"),
            AlarmSignal(signal_id="3", source="sensor-c", action_class="hvac"),
        ]
        surfaces = collapse_alarms(signals)
        assert "3 hvac alerts" in surfaces[0].headline
        assert "3 sources" in surfaces[0].headline
