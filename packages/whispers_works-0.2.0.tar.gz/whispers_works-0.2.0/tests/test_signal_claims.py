import pytest
import time
from whispers.storage.db import WhispersDB
from whispers.envelope import Envelope, MsgType

@pytest.fixture
def db(temp_db):
    db_path = temp_db
    db = WhispersDB(db_path)
    # create fake agents and a fake message to bind the signal_uuid
    with db.get_connection() as conn:
        conn.execute("INSERT INTO agent_cards (agent_id, callsign, agent_type) VALUES ('agent-one', 'alice', 'human')")
        conn.execute("INSERT INTO agent_cards (agent_id, callsign, agent_type) VALUES ('agent-two', 'bob', 'human')")
        conn.commit()
        
    env = Envelope(
        sender="alice",
        recipient="bob",
        msg_type=MsgType.PROPOSE,
        subject="test review beacon",
        body="Review this"
    )
    db.store_message(env, allowed_recipients=["bob"])
    
    # Store env for reference
    db._test_env = env
    
    yield db

def test_create_signal_claim(db):
    claim_id = db.create_signal_claim(
        signal_uuid=db._test_env.id,
        topic="code review",
        lens="security",
        audience_list=["bob"],
        ttl_seconds=3600
    )
    assert claim_id is not None
    
    claim = db.get_signal_claim(claim_id)
    assert claim["signal_uuid"] == db._test_env.id
    assert claim["state"] == "open"
    assert claim["topic"] == "code review"
    assert claim["lens"] == "security"

def test_atomic_claim_signal(db):
    claim_id = db.create_signal_claim(signal_uuid=db._test_env.id)
    
    # First claimant succeeds
    assert db.claim_signal(claim_id, "bob") is True
    
    # Second claimant fails
    assert db.claim_signal(claim_id, "charlie") is False
    
    claim = db.get_signal_claim(claim_id)
    assert claim["state"] == "claimed"
    assert claim["claimant_identity"] == "bob"

def test_transition_claim_state(db):
    claim_id = db.create_signal_claim(signal_uuid=db._test_env.id)
    db.claim_signal(claim_id, "bob")
    
    # Enforcing claimant successfully transitions to escalated
    assert db.transition_claim_state(claim_id, "escalated", enforcing_claimant="bob") is True
    assert db.get_signal_claim(claim_id)["state"] == "escalated"

    # Other agent fails to transition (not the claimant)
    assert db.transition_claim_state(claim_id, "completed", enforcing_claimant="alice") is False
    assert db.get_signal_claim(claim_id)["state"] == "escalated"

    # Original claimant can transition to completed
    assert db.transition_claim_state(claim_id, "completed", enforcing_claimant="bob") is True
    assert db.get_signal_claim(claim_id)["state"] == "completed"

    # Terminal state — cannot transition further
    assert db.transition_claim_state(claim_id, "open", enforcing_claimant="bob") is False
    assert db.get_signal_claim(claim_id)["state"] == "completed"

def test_hijack_prevention(db):
    claim_id = db.create_signal_claim(signal_uuid=db._test_env.id)
    db.claim_signal(claim_id, "bob")
    
    # charlie cannot claim because it is not open
    assert db.claim_signal(claim_id, "charlie") is False

def test_check_on_read_expiration(db, monkeypatch):
    # Create claim with very short TTL
    claim_id = db.create_signal_claim(signal_uuid=db._test_env.id, ttl_seconds=-10) # Immediately expired

    claim = db.get_signal_claim(claim_id)
    # The _expire_stale_claims check in get_signal_claim should transition it to expired
    assert claim is not None
    assert claim["state"] == "expired"
    
    # Verify DB state directly without triggering check-on-read
    with db.get_connection() as conn:
        row = conn.execute("SELECT state FROM signal_claims WHERE claim_id = ?", (claim_id,)).fetchone()
        assert row["state"] == "expired"

def test_list_signal_claims(db):
    db.create_signal_claim(signal_uuid=db._test_env.id, topic="a", lens="L1")
    db.create_signal_claim(signal_uuid=db._test_env.id, topic="b", lens="L2")
    
    # Need to trigger an _expire_stale_claims because list does
    claims = db.list_signal_claims(limit=10)
    assert len(claims) == 2
    
    filtered = db.list_signal_claims(lens="L1")
    assert len(filtered) == 1
    assert filtered[0]["topic"] == "a"


def test_claimed_review_counts_clear_after_release_or_escalation(db):
    claim_id = db.create_signal_claim(signal_uuid=db._test_env.id)
    assert db.claim_signal(claim_id, "bob") is True
    assert db.get_baton_state_counts("bob")["claimed_reviews"] == 1

    assert db.transition_claim_state(claim_id, "open", enforcing_claimant="bob") is True
    assert db.get_baton_state_counts("bob")["claimed_reviews"] == 0

    second_claim = db.create_signal_claim(signal_uuid=db._test_env.id)
    assert db.claim_signal(second_claim, "bob") is True
    assert db.get_baton_state_counts("bob")["claimed_reviews"] == 1

    assert db.transition_claim_state(second_claim, "escalated", enforcing_claimant="bob") is True
    assert db.get_baton_state_counts("bob")["claimed_reviews"] == 0
