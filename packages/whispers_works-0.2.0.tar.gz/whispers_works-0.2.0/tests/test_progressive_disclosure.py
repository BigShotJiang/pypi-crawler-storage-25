"""Tests for progressive disclosure — message layer selection by recipient state.

Covers:
- Layer selection based on context_load
- Layer selection based on interruptibility
- Flash/system priority override (always full)
- MessageLayers fallthrough when preferred layer missing
- apply_disclosure with metadata integration
- Disclosure metadata marking
- No mutation of original message
- No-op when no layers provided
"""

import json
import pytest
from whispers.progressive_disclosure import (
    MessageLayers,
    select_disclosure_level,
    extract_layers_from_metadata,
    apply_disclosure,
)


class TestSelectDisclosureLevel:
    def test_low_load_gets_full(self):
        assert select_disclosure_level(context_load=0.1) == "full"

    def test_medium_load_gets_summary(self):
        assert select_disclosure_level(context_load=0.5) == "summary"
        assert select_disclosure_level(context_load=0.7) == "summary"

    def test_high_load_gets_headline(self):
        assert select_disclosure_level(context_load=0.8) == "headline"
        assert select_disclosure_level(context_load=0.95) == "headline"

    def test_do_not_interrupt_gets_headline(self):
        assert select_disclosure_level(interruptibility="do_not_interrupt") == "headline"

    def test_urgent_only_gets_summary(self):
        assert select_disclosure_level(interruptibility="urgent_only") == "summary"

    def test_free_gets_full(self):
        assert select_disclosure_level(interruptibility="free") == "full"

    def test_defer_gets_full(self):
        assert select_disclosure_level(interruptibility="defer") == "full"

    def test_flash_always_full(self):
        assert select_disclosure_level(context_load=0.99, priority="flash") == "full"

    def test_system_always_full(self):
        assert select_disclosure_level(context_load=0.99, interruptibility="do_not_interrupt", priority="system") == "full"

    def test_no_state_defaults_full(self):
        assert select_disclosure_level() == "full"

    def test_load_takes_precedence_over_interruptibility(self):
        # High load → headline even if interruptibility is "free"
        assert select_disclosure_level(context_load=0.9, interruptibility="free") == "headline"


class TestMessageLayers:
    def test_best_available_headline(self):
        layers = MessageLayers(headline="TL;DR", summary="A bit more", full="Everything")
        assert layers.best_available("headline") == "TL;DR"

    def test_best_available_summary(self):
        layers = MessageLayers(headline="TL;DR", summary="A bit more", full="Everything")
        assert layers.best_available("summary") == "A bit more"

    def test_best_available_full(self):
        layers = MessageLayers(headline="TL;DR", summary="A bit more", full="Everything")
        assert layers.best_available("full") == "Everything"

    def test_fallthrough_headline_to_summary(self):
        layers = MessageLayers(summary="A bit more", full="Everything")
        assert layers.best_available("headline") == "A bit more"

    def test_fallthrough_headline_to_full(self):
        layers = MessageLayers(full="Everything")
        assert layers.best_available("headline") == "Everything"

    def test_fallthrough_summary_to_full(self):
        layers = MessageLayers(full="Everything")
        assert layers.best_available("summary") == "Everything"

    def test_has_layers_true(self):
        assert MessageLayers(headline="x").has_layers
        assert MessageLayers(summary="x").has_layers

    def test_has_layers_false(self):
        assert not MessageLayers(full="x").has_layers
        assert not MessageLayers().has_layers


class TestExtractLayers:
    def test_from_dict_metadata(self):
        meta = {
            "whispers:disclosure:headline": "Quick update",
            "whispers:disclosure:summary": "More details here",
        }
        layers = extract_layers_from_metadata(meta)
        assert layers is not None
        assert layers.headline == "Quick update"
        assert layers.summary == "More details here"

    def test_from_json_string(self):
        meta = json.dumps({"whispers:disclosure:headline": "One liner"})
        layers = extract_layers_from_metadata(meta)
        assert layers is not None
        assert layers.headline == "One liner"

    def test_none_when_no_layers(self):
        assert extract_layers_from_metadata({"other_key": "value"}) is None

    def test_none_when_none(self):
        assert extract_layers_from_metadata(None) is None


class TestApplyDisclosure:
    def _make_message(self, body="Full detailed message", headline=None, summary=None, **kw):
        meta = {}
        if headline:
            meta["whispers:disclosure:headline"] = headline
        if summary:
            meta["whispers:disclosure:summary"] = summary
        msg = {
            "uuid": "test-123",
            "from_agent": "alice",
            "to_agent": "bob",
            "subject": "Test",
            "body": body,
            "priority": "routine",
            "metadata": json.dumps(meta) if meta else "{}",
        }
        msg.update(kw)
        return msg

    def test_no_layers_passes_through(self):
        msg = self._make_message()
        result = apply_disclosure(msg, context_load=0.9)
        assert result["body"] == "Full detailed message"

    def test_high_load_gets_headline(self):
        msg = self._make_message(
            headline="Security sprint done",
            summary="All 10 items shipped with 48 tests",
        )
        result = apply_disclosure(msg, context_load=0.85)
        assert result["body"] == "Security sprint done"

    def test_medium_load_gets_summary(self):
        msg = self._make_message(
            headline="Sprint done",
            summary="All 10 security items shipped across three agents",
        )
        result = apply_disclosure(msg, context_load=0.6)
        assert result["body"] == "All 10 security items shipped across three agents"

    def test_low_load_gets_full(self):
        msg = self._make_message(
            headline="Sprint done",
            summary="All 10 shipped",
        )
        result = apply_disclosure(msg, context_load=0.2)
        assert result["body"] == "Full detailed message"

    def test_flash_bypasses_disclosure(self):
        msg = self._make_message(
            headline="Emergency",
            summary="Short version",
            priority="flash",
        )
        result = apply_disclosure(msg, context_load=0.95)
        assert result["body"] == "Full detailed message"

    def test_disclosure_metadata_marked(self):
        msg = self._make_message(headline="Short")
        result = apply_disclosure(msg, context_load=0.9)
        meta = json.loads(result["metadata"])
        assert meta["whispers:disclosed_level"] == "headline"
        assert meta["whispers:disclosed_from"] == "full"

    def test_does_not_mutate_original(self):
        msg = self._make_message(headline="Short")
        original_body = msg["body"]
        apply_disclosure(msg, context_load=0.9)
        assert msg["body"] == original_body

    def test_do_not_interrupt_gets_headline(self):
        msg = self._make_message(headline="Brief", summary="Medium")
        result = apply_disclosure(msg, interruptibility="do_not_interrupt")
        assert result["body"] == "Brief"
