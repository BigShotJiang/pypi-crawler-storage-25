"""Tests for narrative event model and lifecycle (Slice 3 of Narrator spec).

Tests narrative storage, retrieval, promotion, supersession, expiry,
challenge/annotation/revision mechanics, and schema validation.
"""

import json
import os
import tempfile
import time

import pytest

from whispers.storage.db import WhispersDB


# ---------------------------------------------------------------------------
# DB-level narrative CRUD
# ---------------------------------------------------------------------------

class TestNarrativeStorage:
    def setup_method(self):
        self._tmpdir = tempfile.mkdtemp()
        self._db_path = os.path.join(self._tmpdir, "test_narrative.db")
        self.db = WhispersDB(self._db_path)

    def teardown_method(self):
        import shutil
        shutil.rmtree(self._tmpdir, ignore_errors=True)

    def test_store_and_retrieve(self):
        result = self.db.store_narrative({
            "narrator_agent": "claude-code",
            "stance": "summary",
            "narrative_text": "Three handoffs completed in the last hour.",
            "signal_refs": ["seq_1", "seq_2", "seq_3"],
            "continuity": "live",
        })
        assert result["narrative_id"].startswith("nar_")
        fetched = self.db.get_narrative(result["narrative_id"])
        assert fetched is not None
        assert fetched["narrator_agent"] == "claude-code"
        assert fetched["stance"] == "summary"
        assert fetched["narrative_text"] == "Three handoffs completed in the last hour."

    def test_signal_refs_stored_as_json(self):
        result = self.db.store_narrative({
            "narrator_agent": "claude-code",
            "stance": "warning",
            "narrative_text": "Stale handoff.",
            "signal_refs": [100, 101, 102],
        })
        sources = self.db.get_narrative_sources(result["narrative_id"])
        assert sources["signal_refs"] == [100, 101, 102]

    def test_supersession_chain(self):
        first = self.db.store_narrative({
            "narrator_agent": "claude-code",
            "stance": "summary",
            "narrative_text": "First version.",
        })
        second = self.db.store_narrative({
            "narrator_agent": "claude-code",
            "stance": "revision",
            "narrative_text": "Updated version.",
            "supersedes": first["narrative_id"],
        })
        # First should have superseded_by set
        old = self.db.get_narrative(first["narrative_id"])
        assert old["superseded_by"] == second["narrative_id"]
        # Second should have supersedes set
        new = self.db.get_narrative(second["narrative_id"])
        assert new["supersedes"] == first["narrative_id"]

    def test_promotion(self):
        result = self.db.store_narrative({
            "narrator_agent": "claude-code",
            "stance": "recap",
            "narrative_text": "Overnight summary.",
        })
        promoted = self.db.promote_narrative(result["narrative_id"], "recap")
        assert promoted["promoted"] == 1
        assert promoted["retention_class"] == "recap"
        assert promoted["promoted_at"] is not None

    def test_list_narratives_filters_expired(self):
        # Store a narrative with 0-hour TTL (already expired)
        result = self.db.store_narrative({
            "narrator_agent": "claude-code",
            "stance": "summary",
            "narrative_text": "Will expire.",
            "ttl_hours": 0,
        })
        # It should not appear in default listing
        narratives = self.db.list_narratives()
        ids = [n["narrative_id"] for n in narratives]
        assert result["narrative_id"] not in ids

    def test_list_narratives_by_scope(self):
        self.db.store_narrative({
            "narrator_agent": "claude-code",
            "stance": "summary",
            "narrative_text": "Auth scope.",
            "scope": "auth",
        })
        self.db.store_narrative({
            "narrator_agent": "claude-code",
            "stance": "summary",
            "narrative_text": "Deploy scope.",
            "scope": "deploy",
        })
        auth_narratives = self.db.list_narratives(scope="auth")
        assert len(auth_narratives) == 1
        assert auth_narratives[0]["scope"] == "auth"

    def test_list_narratives_by_thread(self):
        self.db.store_narrative({
            "narrator_agent": "claude-code",
            "stance": "summary",
            "narrative_text": "Thread A.",
            "narrative_thread": "thread-a",
        })
        self.db.store_narrative({
            "narrator_agent": "claude-code",
            "stance": "summary",
            "narrative_text": "Thread B.",
            "narrative_thread": "thread-b",
        })
        thread_a = self.db.list_narratives(thread="thread-a")
        assert len(thread_a) == 1

    def test_expire_narratives(self):
        self.db.store_narrative({
            "narrator_agent": "claude-code",
            "stance": "summary",
            "narrative_text": "Ephemeral.",
            "ttl_hours": 0,
        })
        promoted = self.db.store_narrative({
            "narrator_agent": "claude-code",
            "stance": "recap",
            "narrative_text": "Promoted.",
            "ttl_hours": 0,
        })
        self.db.promote_narrative(promoted["narrative_id"], "recap")

        count = self.db.expire_narratives()
        assert count == 1  # Only the non-promoted one expired

    def test_challenge_narrative(self):
        original = self.db.store_narrative({
            "narrator_agent": "claude-code",
            "stance": "hypothesis",
            "narrative_text": "This looks like a routing gap.",
        })
        challenge = self.db.store_narrative({
            "narrator_agent": "codex",
            "stance": "challenge",
            "narrative_text": "I disagree — Codex heartbeat shows high load.",
            "signal_refs": [original["narrative_id"]],
        })
        assert challenge["narrator_agent"] == "codex"
        assert challenge["stance"] == "challenge"


# ---------------------------------------------------------------------------
# Stance vocabulary validation
# ---------------------------------------------------------------------------

class TestStanceVocabulary:
    def test_all_valid_stances(self):
        valid = {
            "summary", "warning", "hypothesis", "recap", "pattern",
            "challenge", "annotation", "revision",
        }
        assert len(valid) == 8

    def test_retention_classes(self):
        valid = {"recap", "postmortem", "incident", "handoff_summary"}
        assert len(valid) == 4
