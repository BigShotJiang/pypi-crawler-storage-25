"""Tests for velocity circuit breaker.

Covers:
- Normal rate messages deliver
- Burst exceeding limit gets rejected
- Flash priority bypasses velocity limit
- System priority bypasses velocity limit
- Security event logged on rate limit
- Different senders tracked independently
"""

import pytest
from whispers.envelope import Envelope, Priority, MsgType
from whispers.dispatcher import Dispatcher, VELOCITY_LIMIT


class TestVelocityBreaker:
    @pytest.fixture
    def setup(self, tmp_path):
        from whispers.storage.db import WhispersDB

        db_path = str(tmp_path / "test_velocity.db")
        db = WhispersDB(db_path=db_path)
        dispatcher = Dispatcher(db)
        return db, dispatcher

    def _make_envelope(self, sender="alice", recipient="bob", priority=Priority.ROUTINE, subject="Test"):
        return Envelope(
            sender=sender,
            recipient=recipient,
            subject=subject,
            body="Hello",
            priority=priority,
            msg_type=MsgType.INFORM,
        )

    def test_normal_rate_delivers(self, setup):
        db, dispatcher = setup
        for i in range(VELOCITY_LIMIT):
            result = dispatcher.dispatch(self._make_envelope(subject=f"Msg {i}"))
            assert result is None  # Success

    def test_burst_exceeding_limit_rejected(self, setup):
        db, dispatcher = setup
        results = []
        for i in range(VELOCITY_LIMIT + 3):
            results.append(dispatcher.dispatch(self._make_envelope(subject=f"Burst {i}")))
        # First VELOCITY_LIMIT should succeed, rest should be rejected
        rejections = [r for r in results if r is not None and "velocity_limit" in r]
        assert len(rejections) >= 1

    def test_flash_bypasses_limit(self, setup):
        db, dispatcher = setup
        # Fill up the rate
        for i in range(VELOCITY_LIMIT):
            dispatcher.dispatch(self._make_envelope(subject=f"Fill {i}"))
        # Flash should still go through
        result = dispatcher.dispatch(self._make_envelope(priority=Priority.FLASH, subject="Urgent"))
        assert result is None or (result is not None and "velocity_limit" not in result)

    def test_system_bypasses_limit(self, setup):
        db, dispatcher = setup
        for i in range(VELOCITY_LIMIT):
            dispatcher.dispatch(self._make_envelope(subject=f"Fill {i}"))
        result = dispatcher.dispatch(self._make_envelope(priority=Priority.SYSTEM, subject="System"))
        assert result is None or (result is not None and "velocity_limit" not in result)

    def test_security_event_logged(self, setup):
        db, dispatcher = setup
        for i in range(VELOCITY_LIMIT + 2):
            dispatcher.dispatch(self._make_envelope(subject=f"Spam {i}"))

        with db.get_readonly_connection() as conn:
            events = conn.execute(
                "SELECT * FROM security_events WHERE event_type = 'velocity_circuit_breaker'"
            ).fetchall()
        assert len(events) >= 1
        assert events[0]["actor_agent"] == "alice"

    def test_different_senders_independent(self, setup):
        db, dispatcher = setup
        # Fill alice's rate
        for i in range(VELOCITY_LIMIT):
            dispatcher.dispatch(self._make_envelope(sender="alice", subject=f"A{i}"))
        # Bob should still be fine
        result = dispatcher.dispatch(self._make_envelope(sender="bob", subject="Bob msg"))
        assert result is None
