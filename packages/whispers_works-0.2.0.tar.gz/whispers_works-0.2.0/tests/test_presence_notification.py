"""Tests for Presence Policy Substrate Enforcements.

These tests prove two key reliability improvements per the TR-02 Operator Calm tranche:

1. Idle Policy Enforcement (ab-ot1 to ab-ot3)
   Ensures that idle fading uses max(last_active, heartbeat_at, runtime_updated_at),
   so that active-but-quiet agents don't fade unexpectedly.

2. Notification Policy Enforcement (ab-ot4 to ab-ot6)
   Ensures `dispatcher._should_alert` correctly calculates the `alert` boolean flag
   for SSE transport, respecting 'all', 'none', 'direct_only', 'mentions_only',
   and 'trusted_or_priority' settings.
"""

from datetime import timedelta
import pytest

from whispers.envelope import Envelope, Priority, AudienceScope, MsgType
from whispers.presence_policy import apply_presence_policy_to_record
from whispers.dispatcher import Dispatcher
from whispers.testing import WhispersTestHarness
from whispers.time_utils import utc_now, to_utc_iso


class TestIdlePolicyEnforcement:
    def test_idle_fading_uses_max_activity_time(self):
        """Proof that max(last_active, heartbeat, runtime_updated_at) determines idle state."""
        now = utc_now()
        # 10 minutes ago
        past_10m = to_utc_iso(now - timedelta(minutes=10))
        # 2 minutes ago
        past_2m = to_utc_iso(now - timedelta(minutes=2))
        
        policy = {
            "idle_policy": {
                "mode": "hide_after_timeout",
                "timeout_seconds": 300  # 5 minutes
            }
        }
        
        # Scenario 1: ALL timestamps are older than 5 minutes -> Should hide
        stale_record = {
            "status": "online",
            "last_active": past_10m,
            "heartbeat_at": past_10m,
            "runtime_updated_at": past_10m,
        }
        result = apply_presence_policy_to_record(
            stale_record, policy, viewer_agent="operator", target_agent="target"
        )
        assert result is None  # hidden
        
        # Scenario 2: last_active is old, but runtime_updated_at is fresh -> Should stay visible
        fresh_runtime_record = {
            "status": "online",
            "last_active": past_10m,
            "heartbeat_at": past_10m,
            "runtime_updated_at": past_2m,
        }
        result2 = apply_presence_policy_to_record(
            fresh_runtime_record, policy, viewer_agent="operator", target_agent="target"
        )
        assert result2 is not None
        assert result2["status"] == "online"

    def test_idle_fading_offline_mode(self):
        """Proof that appear_offline_after_timeout mutates record state correctly."""
        now = utc_now()
        past_10m = to_utc_iso(now - timedelta(minutes=10))
        
        policy = {
            "idle_policy": {
                "mode": "appear_offline_after_timeout",
                "timeout_seconds": 300
            }
        }
        
        stale_record = {
            "status": "online",
            "presence_status": "online",
            "presence_kind": "active",
            "is_online": 1,
            "last_active": past_10m,
        }
        result = apply_presence_policy_to_record(
            stale_record, policy, viewer_agent="operator", target_agent="target"
        )
        assert result is not None
        assert result["status"] == "offline"
        assert result["presence_status"] == "offline"
        assert result["is_online"] == 0
        assert "last_active" not in result  # timestamps stripped


class TestNotificationPolicyEnforcement:
    def test_should_alert_honors_none_policy(self):
        """Proof that notification_policy='none' returns False."""
        with WhispersTestHarness() as h:
            alice = h.make_client("alice")
            bob = h.make_client("bob")
            
            bob.set_presence_policy({"notification_policy": "none"})
            dispatcher = Dispatcher(alice.db)
            
            env = Envelope(sender="alice", recipient="bob", subject="test", priority=Priority.ROUTINE, msg_type=MsgType.INFORM)
            assert dispatcher._should_alert(env, "bob") is False

    def test_should_alert_operator_and_flash_override(self):
        """Proof that flash priority and operator overrides 'none'."""
        with WhispersTestHarness() as h:
            alice = h.make_client("alice")
            bob = h.make_client("bob")
            
            bob.set_presence_policy({"notification_policy": "none"})
            dispatcher = Dispatcher(alice.db)
            
            env_operator = Envelope(sender="operator", recipient="bob", subject="test", priority=Priority.ROUTINE, msg_type=MsgType.INFORM)
            assert dispatcher._should_alert(env_operator, "bob") is True
            
            env_flash = Envelope(sender="alice", recipient="bob", subject="test", priority=Priority.FLASH, msg_type=MsgType.INFORM)
            assert dispatcher._should_alert(env_flash, "bob") is True

    def test_should_alert_direct_only(self):
        """Proof that direct_only alerts on audience scope DIRECT but not BROADCAST."""
        with WhispersTestHarness() as h:
            alice = h.make_client("alice")
            bob = h.make_client("bob")
            
            bob.set_presence_policy({"notification_policy": "direct_only"})
            dispatcher = Dispatcher(alice.db)
            
            env_direct = Envelope(sender="alice", recipient="bob", subject="test", priority=Priority.ROUTINE, audience_scope=AudienceScope.DIRECT, msg_type=MsgType.INFORM)
            assert dispatcher._should_alert(env_direct, "bob") is True
            
            env_broadcast = Envelope(sender="alice", recipient="bob", subject="test", priority=Priority.ROUTINE, audience_scope=AudienceScope.TEAM, msg_type=MsgType.INFORM)
            assert dispatcher._should_alert(env_broadcast, "bob") is False

    def test_should_alert_mentions_only(self):
        """Proof that mentions_only alerts if the exact handle is found."""
        with WhispersTestHarness() as h:
            alice = h.make_client("alice")
            bob = h.make_client("bob")
            
            bob.set_presence_policy({"notification_policy": "mentions_only"})
            dispatcher = Dispatcher(alice.db)
            
            env_mention = Envelope(sender="alice", recipient="bob", subject="Hey @bob, what's up?", priority=Priority.ROUTINE, msg_type=MsgType.INFORM)
            assert dispatcher._should_alert(env_mention, "bob") is True
            
            env_no_mention = Envelope(sender="alice", recipient="bob", subject="Hey bob, what's up?", priority=Priority.ROUTINE, msg_type=MsgType.INFORM)
            assert dispatcher._should_alert(env_no_mention, "bob") is False

    def test_should_alert_holds_quietly_for_do_not_interrupt_runtime(self):
        """Routine FYIs to do-not-interrupt recipients should stay visible but not alert."""
        with WhispersTestHarness() as h:
            alice = h.make_client("alice")
            bob = h.make_client("bob")

            with bob.db.get_connection() as conn:
                conn.execute(
                    """
                    UPDATE agent_runtime_state
                    SET interruptibility = 'do_not_interrupt'
                    WHERE agent_name = ? AND session_id = ?
                    """,
                    ("bob", bob.session_id),
                )
                conn.commit()

            dispatcher = Dispatcher(alice.db)

            env = Envelope(
                sender="alice",
                recipient="bob",
                subject="quiet note",
                priority=Priority.ROUTINE,
                msg_type=MsgType.INFORM,
            )
            assert dispatcher._should_alert(env, "bob") is False

    def test_dispatch_keeps_message_visible_when_courtesy_suppresses_interrupt(self):
        """Courtesy suppression must not archive the message out of the inbox."""
        with WhispersTestHarness() as h:
            alice = h.make_client("alice")
            bob = h.make_client("bob")

            with bob.db.get_connection() as conn:
                conn.execute(
                    """
                    UPDATE agent_runtime_state
                    SET interruptibility = 'do_not_interrupt'
                    WHERE agent_name = ? AND session_id = ?
                    """,
                    ("bob", bob.session_id),
                )
                conn.commit()

            dispatcher = Dispatcher(alice.db)
            dispatcher.dispatch(
                Envelope(
                    sender="alice",
                    recipient="bob",
                    subject="quiet note",
                    priority=Priority.ROUTINE,
                    msg_type=MsgType.INFORM,
                    body="Store this quietly but keep it visible.",
                )
            )

            inbox = bob.check_inbox(limit=10, mark_seen=False)
            assert any(message["subject"] == "quiet note" for message in inbox)
