"""Tests for backpressure signaling — capacity-aware routing.

Covers:
- Capacity computation from context_load
- Baton penalty reduces capacity
- Busy/blocked/degraded readiness
- High quality_risk = zero capacity
- Agent ranking by capacity
"""

import pytest
from whispers.backpressure import compute_capacity, get_agent_capacity, rank_agents_by_capacity


class TestComputeCapacity:
    def test_fully_available(self):
        assert compute_capacity(context_load=0.0) == 1.0

    def test_fully_loaded(self):
        assert compute_capacity(context_load=1.0) == 0.0

    def test_half_loaded(self):
        assert compute_capacity(context_load=0.5) == 0.5

    def test_baton_penalty(self):
        # 2 batons = 0.3 penalty from 1.0
        c = compute_capacity(context_load=0.0, active_baton_count=2)
        assert c == 0.7

    def test_baton_penalty_caps(self):
        # 10 batons = max 0.6 penalty
        c = compute_capacity(context_load=0.0, active_baton_count=10)
        assert c == 0.4

    def test_busy_halves_capacity(self):
        c = compute_capacity(context_load=0.0, readiness="busy")
        assert c == 0.5

    def test_blocked_is_zero(self):
        assert compute_capacity(readiness="blocked") == 0.0

    def test_degraded_is_zero(self):
        assert compute_capacity(readiness="degraded") == 0.0

    def test_high_quality_risk_is_zero(self):
        assert compute_capacity(quality_risk="high") == 0.0

    def test_combined_penalties(self):
        # context_load=0.3 → 0.7 base, 2 batons → 0.4, busy → 0.2
        c = compute_capacity(context_load=0.3, active_baton_count=2, readiness="busy")
        assert c == 0.2


class TestGetAgentCapacity:
    @pytest.fixture
    def setup(self, temp_db):
        from whispers.storage.db import WhispersDB
        db = WhispersDB(db_path=temp_db)
        # Register agent with session and runtime state
        with db.get_connection() as conn:
            conn.execute(
                "INSERT INTO agent_cards (agent_id, callsign, agent_type, trust_tier, registered_at) VALUES (?, ?, ?, ?, datetime('now'))",
                ("worker", "worker", "llm", 1),
            )
            conn.execute(
                "INSERT INTO agent_sessions (session_id, agent_name, session_kind, lease_expires_at) VALUES (?, ?, ?, datetime('now', '+1 hour'))",
                ("sess-worker", "worker", "local_client"),
            )
            conn.execute(
                "INSERT INTO agent_runtime_state (session_id, agent_name, readiness, context_load) VALUES (?, ?, ?, ?)",
                ("sess-worker", "worker", "ready", 0.3),
            )
            conn.commit()
        return db

    def test_returns_capacity(self, setup):
        db = setup
        result = get_agent_capacity(db, "worker")
        assert result["agent"] == "worker"
        assert result["capacity"] > 0
        assert result["context_load"] == 0.3


class TestRankAgents:
    @pytest.fixture
    def setup(self, temp_db):
        from whispers.storage.db import WhispersDB
        db = WhispersDB(db_path=temp_db)
        for name, load in [("fast", 0.1), ("medium", 0.5), ("slow", 0.9)]:
            with db.get_connection() as conn:
                conn.execute(
                    "INSERT OR IGNORE INTO agent_cards (agent_id, callsign, agent_type, trust_tier, registered_at) VALUES (?, ?, ?, ?, datetime('now'))",
                    (name, name, "llm", 1),
                )
                conn.execute(
                    "INSERT OR IGNORE INTO agent_sessions (session_id, agent_name, session_kind, lease_expires_at) VALUES (?, ?, ?, datetime('now', '+1 hour'))",
                    (f"sess-{name}", name, "local_client"),
                )
                conn.execute(
                    "INSERT OR REPLACE INTO agent_runtime_state (session_id, agent_name, readiness, context_load) VALUES (?, ?, ?, ?)",
                    (f"sess-{name}", name, "ready", load),
                )
                conn.commit()
        return db

    def test_ranked_by_capacity(self, setup):
        db = setup
        ranked = rank_agents_by_capacity(db, ["slow", "fast", "medium"])
        names = [r["agent"] for r in ranked]
        assert names[0] == "fast"
        assert names[-1] == "slow"
