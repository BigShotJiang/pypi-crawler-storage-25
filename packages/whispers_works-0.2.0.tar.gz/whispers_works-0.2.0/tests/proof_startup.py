from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor
import json
import os
import secrets
import shutil
import socket
import subprocess
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path

from whispers.client import WhispersClient


ROOT = Path(__file__).resolve().parents[1]
ARTIFACT_DIR = ROOT / "tests" / ".artifacts" / "proof_startup"
DB_PATH = ARTIFACT_DIR / "proof_startup.db"
RUNTIME_STATE_PATH = ARTIFACT_DIR / "runtime-state.json"
PROOF_HOME = ARTIFACT_DIR / "home"
INSTALL_STATE_PATH = PROOF_HOME / ".whispers" / "install-state.json"
PROFILES_PATH = PROOF_HOME / ".whispers" / "profiles.json"
CREDENTIALS_PATH = PROOF_HOME / ".whispers" / "credentials.json"
LISTENER_STATE_DIR = PROOF_HOME / ".whispers" / "listeners"


def reset_artifacts() -> None:
    if ARTIFACT_DIR.exists():
        shutil.rmtree(ARTIFACT_DIR, ignore_errors=True)
    ARTIFACT_DIR.mkdir(parents=True, exist_ok=True)


def proof_env() -> dict[str, str]:
    env = os.environ.copy()
    env["HOME"] = str(PROOF_HOME)
    env["USERPROFILE"] = str(PROOF_HOME)
    env["WHISPERS_DB_PATH"] = str(DB_PATH)
    env["WHISPERS_RUNTIME_STATE_PATH"] = str(RUNTIME_STATE_PATH)
    env["WHISPERS_SERVER_PORT"] = str(PROOF_SERVER_PORT)
    env["WHISPERS_MCP_TOKEN"] = PROOF_MCP_TOKEN
    env["WHISPERS_INSTALL_STATE_PATH"] = str(INSTALL_STATE_PATH)
    env["WHISPERS_PROFILES_PATH"] = str(PROFILES_PATH)
    env["WHISPERS_CREDENTIALS_PATH"] = str(CREDENTIALS_PATH)
    env["WHISPERS_LISTENER_STATE_DIR"] = str(LISTENER_STATE_DIR)
    return env


def run_cli(*args: str) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        [sys.executable, "-m", "whispers.cli", *args],
        cwd=ROOT,
        capture_output=True,
        text=True,
        env=proof_env(),
        check=False,
    )


def require(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


def parse_json(stdout: str) -> dict:
    try:
        return json.loads(stdout)
    except json.JSONDecodeError as exc:
        raise AssertionError(f"Expected JSON output, got: {stdout!r}") from exc


def get_mcp_token() -> str:
    token = os.environ.get("WHISPERS_MCP_TOKEN", "").strip()
    if token:
        return token

    env_path = Path.home() / ".whispers" / ".env"
    if env_path.exists():
        for line in env_path.read_text().splitlines():
            line = line.strip()
            if line.startswith("WHISPERS_MCP_TOKEN="):
                return line.split("=", 1)[1].strip().strip('"').strip("'")
    return PROOF_MCP_TOKEN


def find_free_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.bind(("127.0.0.1", 0))
        return int(sock.getsockname()[1])


PROOF_SERVER_PORT = find_free_port()
PROOF_MCP_TOKEN = secrets.token_urlsafe(24)


def wait_for_health(port: int, timeout_seconds: float = 15.0) -> None:
    deadline = time.time() + timeout_seconds
    url = f"http://127.0.0.1:{port}/health"
    while time.time() < deadline:
        try:
            with urllib.request.urlopen(url, timeout=1.0) as resp:
                if resp.status == 200:
                    return
        except Exception:
            time.sleep(0.25)
    raise AssertionError(f"temporary server on port {port} did not become healthy")


def start_temp_server() -> tuple[subprocess.Popen[bytes], int, str]:
    port = find_free_port()
    token = get_mcp_token()
    env = proof_env()
    env["WHISPERS_MCP_TOKEN"] = token
    proc = subprocess.Popen(
        [sys.executable, "-c", f"from whispers.server import start; start(port={port})"],
        cwd=ROOT,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        env=env,
    )
    try:
        wait_for_health(port)
    except Exception:
        proc.terminate()
        raise
    return proc, port, token


def stop_temp_server(proc: subprocess.Popen[bytes]) -> None:
    if proc.poll() is not None:
        return
    proc.terminate()
    try:
        proc.wait(timeout=5)
    except subprocess.TimeoutExpired:
        proc.kill()
        proc.wait(timeout=5)


def http_post_json(url: str, payload: dict, token: str) -> tuple[int, str]:
    req = urllib.request.Request(
        url,
        data=json.dumps(payload).encode(),
        method="POST",
        headers={
            "Content-Type": "application/json",
            "Accept": "text/event-stream, application/json",
            "Authorization": f"Bearer {token}",
        },
    )
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            return resp.status, resp.read().decode()
    except urllib.error.HTTPError as exc:
        return exc.code, exc.read().decode()


def mcp_url(port: int, agent: str | None = None) -> str:
    base = f"http://127.0.0.1:{port}/mcp/"
    if agent is None:
        return base
    return f"{base}?agent={urllib.parse.quote(agent)}"


def mcp_initialize(port: int, token: str, agent: str | None, client_name: str) -> dict:
    status, body = http_post_json(
        mcp_url(port, agent),
        {
            "jsonrpc": "2.0",
            "id": 1,
            "method": "initialize",
            "params": {
                "protocolVersion": "2024-11-05",
                "capabilities": {},
                "clientInfo": {"name": client_name, "version": "1.0"},
            },
        },
        token,
    )
    require(status == 200, f"initialize failed for agent {agent!r}: HTTP {status} {body}")
    return parse_json(body)


def mcp_call_tool(port: int, token: str, agent: str, name: str, arguments: dict | None = None, request_id: int = 2) -> dict:
    status, body = http_post_json(
        mcp_url(port, agent),
        {
            "jsonrpc": "2.0",
            "id": request_id,
            "method": "tools/call",
            "params": {"name": name, "arguments": arguments or {}},
        },
        token,
    )
    require(status == 200, f"tool call {name} failed for agent {agent!r}: HTTP {status} {body}")
    return parse_json(body)


def mcp_text(result: dict) -> str:
    content = result.get("result", {}).get("content", [])
    return "\n".join(item.get("text", "") for item in content if item.get("type") == "text")


def check_init(results: list[dict]) -> None:
    proc = run_cli("init", "--agent-name", "startup-proof")
    results.append(
        {
            "check": "cli_init",
            "returncode": proc.returncode,
            "stdout": proc.stdout.strip(),
            "stderr": proc.stderr.strip(),
        }
    )
    require(proc.returncode == 0, "whispers init failed")


def check_doctor(results: list[dict]) -> dict:
    proc = run_cli("doctor", "--agent-name", "startup-proof")
    payload = parse_json(proc.stdout)
    results.append(
        {
            "check": "cli_doctor",
            "returncode": proc.returncode,
            "stderr": proc.stderr.strip(),
            "payload": payload,
        }
    )
    require(proc.returncode == 0, "whispers doctor failed")
    require(payload.get("schema_version") == 2, "doctor did not report schema_version 2")
    require(payload.get("agent_registered") is True, "doctor did not confirm registration")
    require(payload.get("db_exists") is True, "doctor did not confirm DB existence")
    require(
        os.path.abspath(payload.get("db_path") or "") == os.path.abspath(str(DB_PATH)),
        f"doctor reported unexpected db_path: {payload.get('db_path')}",
    )
    require(payload.get("overall") == "PASS", f"whispers doctor reported {payload.get('overall')}: {payload.get('issues')}")
    require(payload.get("server_running") is True, "doctor did not confirm a running server")
    require(payload.get("mcp_healthy") is True, "doctor did not confirm healthy MCP handshake")
    require(
        payload.get("server_state") in {"up", "recovering"},
        f"doctor reported unhealthy server_state: {payload.get('server_state')}",
    )
    require(
        payload.get("server_db_matches_local") is not False,
        "doctor detected a DB path mismatch between the shell and the server",
    )
    return payload


def check_status(results: list[dict]) -> None:
    proc = run_cli("status")
    results.append(
        {
            "check": "cli_status",
            "returncode": proc.returncode,
            "stdout": proc.stdout.strip(),
            "stderr": proc.stderr.strip(),
        }
    )
    require(proc.returncode == 0, "whispers status failed")


def check_sdk_flow(results: list[dict]) -> None:
    sender = WhispersClient("startup-proof", db_path=str(DB_PATH))
    peer = WhispersClient("startup-proof-peer", db_path=str(DB_PATH))

    status = sender.status()
    require(status["healthy"] is True, "client.status() did not report healthy")
    require(status["agents_online_count"] >= 2, "expected both proof agents to be online")

    send_result = sender.send("startup-proof-peer", "Proof ping", body="startup harness")
    inbox = peer.check_inbox(limit=10, mark_seen=True)
    outbox = sender.outbox(limit=10)
    trace = sender.trace("startup-proof-peer", limit=10)

    require(send_result["status"] in {"delivered", "queued"}, "unexpected send status")
    require(any(msg["subject"] == "Proof ping" for msg in inbox), "peer did not receive proof message")
    require(any(msg["subject"] == "Proof ping" for msg in outbox), "outbox did not record proof message")
    require(any(msg["subject"] == "Proof ping" for msg in trace), "trace did not include proof message")

    results.append(
        {
            "check": "sdk_flow",
            "status": status,
            "send_result": send_result,
            "inbox_count": len(inbox),
            "outbox_count": len(outbox),
            "trace_count": len(trace),
        }
    )


def check_clean_startup_output(results: list[dict]) -> None:
    doctor = next(item for item in results if item["check"] == "cli_doctor")
    status = next(item for item in results if item["check"] == "cli_status")

    failures: list[str] = []
    if doctor["stderr"]:
        failures.append(f"doctor emitted stderr: {doctor['stderr']}")
    if status["stderr"]:
        failures.append(f"status emitted stderr: {status['stderr']}")

    results.append(
        {
            "check": "startup_cleanliness",
            "ok": not failures,
            "failures": failures,
        }
    )
    require(not failures, "; ".join(failures))


def check_cli_target_surface(results: list[dict]) -> None:
    proc = run_cli("mcp-install", "--help")
    stdout = proc.stdout
    require(proc.returncode == 0, "mcp-install --help failed")
    require("vscode" in stdout, "mcp-install help does not expose vscode target")
    require("antigravity" in stdout, "mcp-install help does not expose antigravity target")
    results.append(
        {
            "check": "cli_target_surface",
            "targets_present": ["vscode", "antigravity"],
        }
    )


def check_http_identity_and_guardrails(results: list[dict]) -> None:
    proc, port, token = start_temp_server()
    try:
        missing_status, missing_body = http_post_json(
            mcp_url(port, None),
            {
                "jsonrpc": "2.0",
                "id": 1,
                "method": "initialize",
                "params": {
                    "protocolVersion": "2024-11-05",
                    "capabilities": {},
                    "clientInfo": {"name": "proof-missing-agent", "version": "1.0"},
                },
            },
            token,
        )
        require(missing_status == 400, f"missing agent should return 400, got {missing_status}")

        invalid_status, invalid_body = http_post_json(
            mcp_url(port, "BadName"),
            {
                "jsonrpc": "2.0",
                "id": 2,
                "method": "initialize",
                "params": {
                    "protocolVersion": "2024-11-05",
                    "capabilities": {},
                    "clientInfo": {"name": "proof-invalid-agent", "version": "1.0"},
                },
            },
            token,
        )
        require(invalid_status == 400, f"invalid callsign should return 400, got {invalid_status}")

        reserved_status, reserved_body = http_post_json(
            mcp_url(port, "system"),
            {
                "jsonrpc": "2.0",
                "id": 3,
                "method": "initialize",
                "params": {
                    "protocolVersion": "2024-11-05",
                    "capabilities": {},
                    "clientInfo": {"name": "proof-reserved-agent", "version": "1.0"},
                },
            },
            token,
        )
        require(reserved_status == 400, f"reserved callsign should return 400, got {reserved_status}")

        def identity_roundtrip(agent: str) -> dict:
            init = mcp_initialize(port, token, agent, f"proof-{agent}")
            whoami = mcp_call_tool(port, token, agent, "whoami", request_id=10)
            status = mcp_call_tool(port, token, agent, "status", request_id=11)
            card = parse_json(mcp_text(whoami))
            summary = mcp_text(status).splitlines()[0]
            instructions = init.get("result", {}).get("instructions", "")
            return {"card": card, "summary": summary, "instructions": instructions}

        with ThreadPoolExecutor(max_workers=2) as pool:
            future_a = pool.submit(identity_roundtrip, "proof-http-a")
            future_b = pool.submit(identity_roundtrip, "proof-http-b")
            result_a = future_a.result()
            result_b = future_b.result()

        require(result_a["card"]["callsign"] == "proof-http-a", "proof-http-a identity collapsed")
        require(result_b["card"]["callsign"] == "proof-http-b", "proof-http-b identity collapsed")
        require(
            "proof-http-a" in result_a["summary"] and "\u23e6\u23e6\u23e6>" in result_a["summary"],
            "status summary missing proof-http-a startup line",
        )
        require(
            "proof-http-b" in result_b["summary"] and "\u23e6\u23e6\u23e6>" in result_b["summary"],
            "status summary missing proof-http-b startup line",
        )
        require(
            "not fresh marching orders" in result_a["instructions"],
            "initialize instructions missing stale-message guardrail for proof-http-a",
        )
        require(
            "not fresh marching orders" in result_b["instructions"],
            "initialize instructions missing stale-message guardrail for proof-http-b",
        )
        require(
            "Do NOT simulate Whispers tool behavior" in result_a["instructions"],
            "initialize instructions missing anti-imitation guardrail for proof-http-a",
        )
        require(
            "Do NOT simulate Whispers tool behavior" in result_b["instructions"],
            "initialize instructions missing anti-imitation guardrail for proof-http-b",
        )

        send_result = mcp_call_tool(
            port,
            token,
            "proof-http-a",
            "message_send",
            {
                "to": "proof-http-b",
                "subject": "Proof HTTP ping",
                "body": "hello from proof-http-a",
            },
            request_id=12,
        )
        inbox_result = mcp_call_tool(
            port,
            token,
            "proof-http-b",
            "message_check",
            {"limit": 10},
            request_id=13,
        )
        send_text = mcp_text(send_result)
        require(
            (" queued to " in send_text or " delivered to " in send_text or "Message queued." in send_text),
            "HTTP send did not report send outcome",
        )
        require("Proof HTTP ping" in mcp_text(inbox_result), "HTTP recipient did not receive proof message")

        results.append(
            {
                "check": "http_identity_guardrails",
                "port": port,
                "missing_identity_status": missing_status,
                "invalid_callsign_status": invalid_status,
                "reserved_callsign_status": reserved_status,
                "agent_a_summary": result_a["summary"],
                "agent_b_summary": result_b["summary"],
                "agent_a_instructions": result_a["instructions"],
                "agent_b_instructions": result_b["instructions"],
                "send_text": send_text,
                "inbox_text": mcp_text(inbox_result),
            }
        )
    finally:
        stop_temp_server(proc)


def record_skip(results: list[dict], check: str, reason: str) -> None:
    results.append({"check": check, "status": "skipped", "reason": reason})


def run_check(name: str, fn, results: list[dict], errors: list[dict]) -> None:
    try:
        fn(results)
    except AssertionError as exc:
        errors.append({"check": name, "error": str(exc)})


def run_check_with_value(name: str, fn, results: list[dict], errors: list[dict]):
    try:
        return fn(results)
    except AssertionError as exc:
        errors.append({"check": name, "error": str(exc)})
        return None


def main() -> int:
    reset_artifacts()
    results: list[dict] = []
    errors: list[dict] = []

    run_check("cli_init", check_init, results, errors)
    run_check_with_value("cli_doctor", check_doctor, results, errors)
    run_check("cli_status", check_status, results, errors)
    run_check("sdk_flow", check_sdk_flow, results, errors)
    run_check("startup_cleanliness", check_clean_startup_output, results, errors)
    run_check("cli_target_surface", check_cli_target_surface, results, errors)
    run_check("http_identity_guardrails", check_http_identity_and_guardrails, results, errors)

    if errors:
        print(
            json.dumps(
                {
                    "overall": "FAIL",
                    "db_path": str(DB_PATH),
                    "results": results,
                    "errors": errors,
                },
                indent=2,
            )
        )
        return 1

    print(
        json.dumps(
            {
                "overall": "PASS",
                "db_path": str(DB_PATH),
                "results": results,
            },
            indent=2,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
