import asyncio
import importlib
import json
import shutil
import sqlite3
import uuid
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from whispers.client import WhispersClient


def _make_case_dir() -> Path:
    root = Path(__file__).resolve().parents[1] / ".tmp"
    root.mkdir(parents=True, exist_ok=True)
    case_dir = root / f"context-window-leakage-{uuid.uuid4().hex}"
    case_dir.mkdir(parents=True, exist_ok=False)
    return case_dir


def _connect_agent(api: TestClient, agent_name: str) -> dict[str, str]:
    response = api.post(
        "/connect",
        json={
            "agent_name": agent_name,
            "client": {"name": "pytest", "version": "1.0"},
            "capabilities": {"transport": "http"},
        },
    )
    assert response.status_code == 200
    token = response.json()["token"]
    return {"Authorization": f"Bearer {token}"}


def _send_headers(auth_headers: dict[str, str]) -> dict[str, str]:
    return {
        **auth_headers,
        "A2A-Version": "1.0",
    }


def _latest_security_event(db_path: Path, outcome: str) -> sqlite3.Row | None:
    with sqlite3.connect(db_path) as conn:
        conn.row_factory = sqlite3.Row
        return conn.execute(
            """
            SELECT outcome, detail
            FROM security_events
            WHERE outcome = ?
            ORDER BY created_at DESC
            LIMIT 1
            """,
            (outcome,),
        ).fetchone()


def _load_server(monkeypatch: pytest.MonkeyPatch, case_dir: Path, db_path: Path):
    monkeypatch.setenv("WHISPERS_DB_PATH", str(db_path))
    monkeypatch.setenv("WHISPERS_REMOTE_ADMISSION_MODE", "open")
    monkeypatch.setenv("WHISPERS_RUNTIME_STATE_PATH", str(case_dir / "runtime-state.json"))

    import whispers.server as server_module

    return importlib.reload(server_module)


def _decode_metadata(raw_metadata):
    if isinstance(raw_metadata, dict):
        return raw_metadata
    if isinstance(raw_metadata, str):
        return json.loads(raw_metadata)
    return {}


def test_non_member_workspace_context_is_redacted_in_live_delivery_and_inbox(monkeypatch):
    case_dir = _make_case_dir()
    db_path = case_dir / "context-window.db"

    try:
        server_module = _load_server(monkeypatch, case_dir, db_path)

        with TestClient(server_module.app) as api:
            alice_headers = _connect_agent(api, "alice")
            charlie_headers = _connect_agent(api, "charlie")

            created = api.post(
                "/workspace:create",
                json={"purpose": "Context boundary", "join_policy": "open"},
                headers=alice_headers,
            )
            assert created.status_code == 200
            workspace_id = created.json()["workspace_id"]

            listener = asyncio.Queue()
            server_module.sse.add_listener("charlie", listener)
            try:
                sent = api.post(
                    "/message:send",
                    json={
                        "to": "charlie",
                        "subject": "Room state",
                        "body": "Top-secret room context",
                        "msg_type": "inform",
                        "payload": {"note": "Top-secret room context"},
                        "workspace_id": workspace_id,
                    },
                    headers=_send_headers(alice_headers),
                )
                assert sent.status_code == 200

                delivered = listener.get_nowait()
                assert delivered.subject == "[scope-redacted]"
                assert delivered.body is None
                assert delivered.payload is None
                assert delivered.metadata["whispers:scope_redacted"] is True
                assert delivered.metadata["whispers:scope_redaction_mode"] == "full_redaction"
                assert delivered.metadata["whispers:workspace_id"] == workspace_id

                inbox = api.get(
                    "/inbox",
                    headers=charlie_headers,
                    params={"mark_seen": "false"},
                )
                assert inbox.status_code == 200
                message = inbox.json()["messages"][0]
                assert message["subject"] == "[scope-redacted]"
                assert message["body"] is None
                assert message.get("payload") is None
                metadata = _decode_metadata(message.get("metadata"))
                assert metadata["whispers:scope_redacted"] is True
                assert metadata["whispers:workspace_id"] == workspace_id
                assert "Top-secret room context" not in json.dumps(message)
            finally:
                server_module.sse.remove_listener("charlie", listener)

        event = _latest_security_event(db_path, "workspace_context_delivery_redacted_non_member")
        assert event is not None
        detail = json.loads(event["detail"])
        assert detail["workspace_id"] == workspace_id
        assert detail["redaction_mode"] == "full_redaction"
        assert detail["reason"] == "non_member_workspace_delivery"
    finally:
        shutil.rmtree(case_dir, ignore_errors=True)


def test_local_plain_send_workspace_hint_redacts_non_member_delivery(temp_db):
    alice = WhispersClient("alice", db_path=temp_db)
    charlie = WhispersClient("charlie", db_path=temp_db)

    created = alice.create_workspace(
        purpose="Local context boundary",
        name="Local Context Boundary",
    )
    workspace_id = created["workspace_id"]

    sent = alice.send(
        "charlie",
        "Room state",
        body="Top-secret room context",
        workspace_id=workspace_id,
    )

    assert sent["status"] in ("delivered", "queued")
    inbox = charlie.check_inbox(mark_seen=False)
    assert inbox
    message = inbox[0]
    assert message["subject"] == "[scope-redacted]"
    assert message["body"] is None
    assert message.get("payload") is None
    metadata = _decode_metadata(message.get("metadata"))
    assert metadata["whispers:scope_redacted"] is True
    assert metadata["whispers:workspace_id"] == workspace_id
    assert metadata["whispers:scope_redaction_mode"] == "full_redaction"


def test_workspace_handoff_to_non_member_preserves_work_object_but_not_freeform_context(monkeypatch):
    case_dir = _make_case_dir()
    db_path = case_dir / "context-window.db"

    try:
        server_module = _load_server(monkeypatch, case_dir, db_path)

        with TestClient(server_module.app) as api:
            alice_headers = _connect_agent(api, "alice")
            charlie_headers = _connect_agent(api, "charlie")

            created = api.post(
                "/workspace:create",
                json={"purpose": "Cross-scope handoff", "join_policy": "open"},
                headers=alice_headers,
            )
            assert created.status_code == 200
            workspace_id = created.json()["workspace_id"]

            listener = asyncio.Queue()
            server_module.sse.add_listener("charlie", listener)
            try:
                sent = api.post(
                    "/message:send",
                    json={
                        "to": "charlie",
                        "subject": "Sensitive handoff",
                        "body": "Room-only history should not leak",
                        "msg_type": "handoff",
                        "payload": {
                            "wire_v": 1,
                            "schema": "handoff_baton.v1",
                            "mode": "bilingual",
                            "signal_class": "whispers_internal",
                            "trace": {
                                "message_id": "msg-handoff-test",
                                "trace_id": "handoff-scope-test",
                                "thread_id": "room-secret-thread",
                            },
                            "summary": {
                                "headline": "Sensitive handoff",
                                "human": "Room-only history should not leak",
                            },
                            "payload": {
                                "objective": "Fix auth race",
                                "deliverable": "Green auth tests",
                                "workspace_id": workspace_id,
                                "completed": "Root cause isolated",
                                "remaining": "Apply the patch",
                            },
                        },
                        "metadata": {"whispers:workspace_id": workspace_id},
                    },
                    headers=_send_headers(alice_headers),
                )
                assert sent.status_code == 200

                delivered = listener.get_nowait()
                assert delivered.subject == "[workspace-scoped handoff_baton.v1]"
                assert delivered.body is None
                assert delivered.payload["schema"] == "handoff_baton.v1"
                assert delivered.payload["payload"]["workspace_id"] == workspace_id
                assert delivered.payload["payload"]["objective"] == "Fix auth race"
                assert "summary" not in delivered.payload
                assert delivered.metadata["whispers:scope_redacted"] is True
                assert delivered.metadata["whispers:scope_redaction_mode"] == "payload_preserved"

                inbox = api.get(
                    "/inbox",
                    headers=charlie_headers,
                    params={"mark_seen": "false"},
                )
                assert inbox.status_code == 200
                message = inbox.json()["messages"][0]
                assert message["subject"] == "[workspace-scoped handoff_baton.v1]"
                assert message["body"] is None
                assert message["payload"]["schema"] == "handoff_baton.v1"
                assert message["payload"]["payload"]["workspace_id"] == workspace_id
                assert "summary" not in message["payload"]
                assert "Room-only history should not leak" not in json.dumps(message)
            finally:
                server_module.sse.remove_listener("charlie", listener)

        event = _latest_security_event(db_path, "workspace_context_delivery_redacted_non_member")
        assert event is not None
        detail = json.loads(event["detail"])
        assert detail["workspace_id"] == workspace_id
        assert detail["redaction_mode"] == "payload_preserved"
        assert detail["schema"] == "handoff_baton.v1"
    finally:
        shutil.rmtree(case_dir, ignore_errors=True)
