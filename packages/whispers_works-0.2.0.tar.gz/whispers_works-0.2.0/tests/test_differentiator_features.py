"""Tests for the differentiator feature garden:
- Queue class classification (attention rules)
- Habituation reflex (machine courtesy)
- Stale reminder escalation (machine courtesy)
- Inbox sweep (machine courtesy)
- /signal endpoint (zero-friction entry)
- Relationship health / trust topology
- Signal decay (priority ages over time)
"""
import json
import shutil
import time
import uuid
from collections import defaultdict
from datetime import datetime, timedelta, timezone
from pathlib import Path
from unittest.mock import patch

import pytest

from whispers.client import WhispersClient
from whispers.dispatcher import Dispatcher
from whispers.envelope import (
    Envelope,
    MsgType,
    Priority,
    QueueClass,
    classify_queue_class,
)
from whispers.reflexive_engine import (
    _ESCALATION_FLASH_THRESHOLD,
    _ESCALATION_PRIORITY_THRESHOLD,
    _STALE_CONCERN_THRESHOLD,
    _STALE_READINESS_THRESHOLD,
    _STALE_READINESS_URGENT,
    _STALE_RECOMMEND_THRESHOLD,
    reflex_stale_readiness,
    reflex_stalled_handoff,
)
from whispers.storage.db import WhispersDB


@pytest.fixture
def temp_db():
    root = Path(__file__).resolve().parents[1] / ".tmp"
    root.mkdir(parents=True, exist_ok=True)
    case_dir = root / f"whispers-test-{uuid.uuid4().hex}"
    case_dir.mkdir(parents=True, exist_ok=False)
    db_path = str(case_dir / "test_whispers.db")
    yield db_path
    shutil.rmtree(case_dir, ignore_errors=True)


@pytest.fixture
def db(temp_db):
    return WhispersDB(temp_db)


@pytest.fixture
def two_agents(temp_db):
    """Set up two registered agents with a dispatcher."""
    wdb = WhispersDB(temp_db)
    from whispers.registry import AgentRegistry
    reg = AgentRegistry(wdb)
    reg.register("alice", agent_type="llm")
    reg.register("bob", agent_type="llm")
    alice = WhispersClient("alice", db_path=temp_db)
    bob = WhispersClient("bob", db_path=temp_db)
    disp = Dispatcher(wdb)
    alice.dispatcher = disp
    bob.dispatcher = disp
    return alice, bob, wdb, disp


# ===========================================================================
# Queue Class Classification (Attention Rules)
# ===========================================================================


class TestQueueClassClassification:
    """classify_queue_class should deterministically bucket messages."""

    def test_system_from_whispers_server(self):
        assert classify_queue_class("inform", "routine", "whispers-server") == QueueClass.SYSTEM

    def test_system_from_system_priority(self):
        assert classify_queue_class("inform", "system", "alice") == QueueClass.SYSTEM

    def test_actionable_from_handoff_type(self):
        assert classify_queue_class("handoff", "routine", "alice") == QueueClass.ACTIONABLE

    def test_actionable_from_request_type(self):
        assert classify_queue_class("request", "routine", "alice") == QueueClass.ACTIONABLE

    def test_actionable_from_assignment_type(self):
        assert classify_queue_class("assignment", "routine", "alice") == QueueClass.ACTIONABLE

    def test_actionable_from_decision_request(self):
        assert classify_queue_class("decision_request", "routine", "alice") == QueueClass.ACTIONABLE

    def test_actionable_from_external_action_request(self):
        assert classify_queue_class("external_action_request", "routine", "alice") == QueueClass.ACTIONABLE

    def test_actionable_from_flash_priority(self):
        assert classify_queue_class("inform", "flash", "alice") == QueueClass.ACTIONABLE

    def test_actionable_from_handoff_baton_schema(self):
        assert classify_queue_class("inform", "routine", "alice", schema="handoff_baton.v1") == QueueClass.ACTIONABLE

    def test_actionable_from_decision_request_schema(self):
        assert classify_queue_class("inform", "routine", "alice", schema="decision_request.v1") == QueueClass.ACTIONABLE

    def test_reference_from_workspace_delta_schema(self):
        assert classify_queue_class("inform", "routine", "alice", schema="workspace_delta.v1") == QueueClass.REFERENCE

    def test_reference_from_baton_update_schema(self):
        assert classify_queue_class("inform", "routine", "alice", schema="baton_update.v1") == QueueClass.REFERENCE

    def test_reference_from_baton_close_schema(self):
        assert classify_queue_class("inform", "routine", "alice", schema="baton_close.v1") == QueueClass.REFERENCE

    def test_reference_from_checkpoint_type(self):
        assert classify_queue_class("checkpoint", "routine", "alice") == QueueClass.REFERENCE

    def test_conversation_is_default(self):
        assert classify_queue_class("inform", "routine", "alice") == QueueClass.CONVERSATION

    def test_conversation_for_reply(self):
        assert classify_queue_class("reply", "routine", "alice") == QueueClass.CONVERSATION

    def test_conversation_for_note(self):
        assert classify_queue_class("note", "priority", "alice") == QueueClass.CONVERSATION

    def test_system_takes_precedence_over_actionable_type(self):
        """whispers-server sending a handoff should still be system."""
        assert classify_queue_class("handoff", "routine", "whispers-server") == QueueClass.SYSTEM

    def test_flash_from_whispers_server_is_system(self):
        """System sender takes precedence over flash priority."""
        assert classify_queue_class("inform", "flash", "whispers-server") == QueueClass.SYSTEM

    def test_actionable_takes_precedence_over_reference(self):
        """Flash priority with a reference schema should still be actionable."""
        assert classify_queue_class("inform", "flash", "alice", schema="baton_update.v1") == QueueClass.ACTIONABLE


# ===========================================================================
# Habituation Reflex (Machine Courtesy)
# ===========================================================================


class TestHabituationReflex:
    """Duplicate coalescing should suppress repeated routine signals."""

    def test_duplicate_routine_coalesced(self, two_agents):
        alice, bob, wdb, disp = two_agents
        # First send goes through
        r1 = alice.send(to="bob", subject="status check", body="ping", priority="routine")
        assert r1.get("reason") != "habituation:coalesced"

        # Same sender+subject within 5 min should be coalesced (dead_lettered with reason)
        r2 = alice.send(to="bob", subject="status check", body="ping again", priority="routine")
        assert r2.get("status") == "dead_lettered"
        assert r2.get("reason") == "habituation:coalesced"

    def test_different_subject_not_coalesced(self, two_agents):
        alice, bob, wdb, disp = two_agents
        r1 = alice.send(to="bob", subject="status check", body="ping", priority="routine")
        assert r1.get("status") != "habituation:coalesced"

        r2 = alice.send(to="bob", subject="different topic", body="pong", priority="routine")
        assert r2.get("status") != "habituation:coalesced"

    def test_priority_bypasses_habituation(self, two_agents):
        alice, bob, wdb, disp = two_agents
        r1 = alice.send(to="bob", subject="urgent", body="first", priority="priority")
        assert r1.get("status") != "habituation:coalesced"

        r2 = alice.send(to="bob", subject="urgent", body="second", priority="priority")
        assert r2.get("status") != "habituation:coalesced"

    def test_flash_bypasses_habituation(self, two_agents):
        alice, bob, wdb, disp = two_agents
        r1 = alice.send(to="bob", subject="blocked", body="first", priority="flash")
        assert r1.get("status") != "habituation:coalesced"

        r2 = alice.send(to="bob", subject="blocked", body="second", priority="flash")
        assert r2.get("status") != "habituation:coalesced"

    def test_habituation_window_expires(self, two_agents):
        alice, bob, wdb, disp = two_agents
        r1 = alice.send(to="bob", subject="status check", body="ping", priority="routine")
        assert r1.get("status") != "habituation:coalesced"

        # Simulate window expiry by manipulating the habituation key timestamp
        for keys in disp._habituation_keys.values():
            for k in keys:
                keys[k] -= Dispatcher.HABITUATION_WINDOW_SECONDS + 1

        r2 = alice.send(to="bob", subject="status check", body="ping after window", priority="routine")
        assert r2.get("status") != "habituation:coalesced"

    def test_different_sender_not_coalesced(self, two_agents):
        alice, bob, wdb, disp = two_agents
        r1 = alice.send(to="bob", subject="status check", body="from alice", priority="routine")
        assert r1.get("status") != "habituation:coalesced"

        r2 = bob.send(to="bob", subject="status check", body="from bob", priority="routine")
        # bob sending to bob with same subject — different sender key, should not coalesce
        assert r2.get("status") != "habituation:coalesced"


# ===========================================================================
# Stale Reminder Escalation (Machine Courtesy)
# ===========================================================================


class TestStaleReminderEscalation:
    """Escalation tiers should map baton age to appropriate priority."""

    def _make_baton(self, age_seconds, *, assignee_online=True):
        """Build a baton dict matching reflex_stalled_handoff's expected shape.

        The function reads from world["active_batons"], requires state="offered",
        and computes age from created_epoch.
        """
        return {
            "baton_ref": str(uuid.uuid4()),
            "owner": "alice",
            "assignee": "bob",
            "assignee_online": assignee_online,
            "subject": "test handoff",
            "version": 1,
            "state": "offered",
            "created_epoch": time.time() - age_seconds,
        }

    def test_fresh_baton_not_stale(self):
        """Under concern threshold — no insight produced."""
        baton = self._make_baton(60)  # 1 minute
        insights = reflex_stalled_handoff({"active_batons": [baton]})
        assert len(insights) == 0

    def test_concern_tier_routine(self):
        """Between concern and recommend threshold — routine escalation."""
        baton = self._make_baton(_STALE_CONCERN_THRESHOLD + 60)
        insights = reflex_stalled_handoff({"active_batons": [baton]})
        assert len(insights) == 1
        assert insights[0].details["escalation"] == "routine"

    def test_recommend_tier_still_routine(self):
        """At recommend threshold but under 2h — still routine."""
        baton = self._make_baton(_STALE_RECOMMEND_THRESHOLD + 60)
        insights = reflex_stalled_handoff({"active_batons": [baton]})
        assert len(insights) == 1
        assert insights[0].details["escalation"] == "routine"

    def test_priority_tier(self):
        """Over 2 hours — escalates to priority."""
        baton = self._make_baton(_ESCALATION_PRIORITY_THRESHOLD + 60)
        insights = reflex_stalled_handoff({"active_batons": [baton]})
        assert len(insights) == 1
        assert insights[0].details["escalation"] == "priority"

    def test_flash_tier(self):
        """Over 6 hours — escalates to flash."""
        baton = self._make_baton(_ESCALATION_FLASH_THRESHOLD + 60)
        insights = reflex_stalled_handoff({"active_batons": [baton]})
        assert len(insights) == 1
        assert insights[0].details["escalation"] == "flash"

    def test_offline_assignee_skipped(self):
        """Offline assignees should not get reminders."""
        baton = self._make_baton(_ESCALATION_FLASH_THRESHOLD + 60, assignee_online=False)
        insights = reflex_stalled_handoff({"active_batons": [baton]})
        assert len(insights) == 0

    def test_recommend_stage_at_threshold(self):
        """At recommend threshold, stage should be RECOMMEND."""
        baton = self._make_baton(_STALE_RECOMMEND_THRESHOLD + 60)
        insights = reflex_stalled_handoff({"active_batons": [baton]})
        assert len(insights) == 1
        assert insights[0].stage.value == "recommend"

    def test_concern_stage_below_recommend(self):
        """Below recommend threshold, stage should be CONCERN."""
        baton = self._make_baton(_STALE_CONCERN_THRESHOLD + 60)
        insights = reflex_stalled_handoff({"active_batons": [baton]})
        assert len(insights) == 1
        assert insights[0].stage.value == "concern"


# ===========================================================================
# Inbox Sweep (Machine Courtesy)
# ===========================================================================


class TestInboxSweep:
    """Batch inbox management — pick_up/defer/note in one call."""

    def test_pick_up_marks_messages(self, two_agents):
        alice, bob, wdb, disp = two_agents
        r1 = alice.send(to="bob", subject="task 1", body="do this")
        r2 = alice.send(to="bob", subject="task 2", body="do that")
        msg1_id = r1["id"]
        msg2_id = r2["id"]

        result = wdb.inbox_sweep("bob", pick_up=[msg1_id, msg2_id])
        assert result["picked_up"] == 2

    def test_defer_snoozes_messages(self, two_agents):
        alice, bob, wdb, disp = two_agents
        r1 = alice.send(to="bob", subject="later", body="can wait")
        msg_id = r1["id"]

        result = wdb.inbox_sweep("bob", defer=[msg_id])
        assert result["deferred"] == 1

    def test_note_archives_messages(self, two_agents):
        alice, bob, wdb, disp = two_agents
        r1 = alice.send(to="bob", subject="fyi", body="noted")
        msg_id = r1["id"]

        result = wdb.inbox_sweep("bob", note=[msg_id])
        assert result["noted"] == 1

    def test_mixed_sweep(self, two_agents):
        alice, bob, wdb, disp = two_agents
        r1 = alice.send(to="bob", subject="task", body="do")
        r2 = alice.send(to="bob", subject="later", body="wait")
        r3 = alice.send(to="bob", subject="fyi", body="ok")

        result = wdb.inbox_sweep(
            "bob",
            pick_up=[r1["id"]],
            defer=[r2["id"]],
            note=[r3["id"]],
        )
        assert result["picked_up"] == 1
        assert result["deferred"] == 1
        assert result["noted"] == 1

    def test_empty_sweep_returns_zeros(self, db):
        result = db.inbox_sweep("nobody")
        assert result == {"picked_up": 0, "deferred": 0, "noted": 0}

    def test_wrong_recipient_no_effect(self, two_agents):
        alice, bob, wdb, disp = two_agents
        r1 = alice.send(to="bob", subject="task", body="do")

        # alice tries to sweep bob's message
        result = wdb.inbox_sweep("alice", pick_up=[r1["id"]])
        assert result["picked_up"] == 0


# ===========================================================================
# /signal Endpoint (Zero-Friction Entry)
# ===========================================================================


class TestSignalEndpoint:
    """Integration tests for the /signal HTTP endpoint."""

    def test_signal_dispatches_ephemeral_message(self, two_agents):
        """A /signal-style send should dispatch an ephemeral message (not stored in inbox)."""
        alice, bob, wdb, disp = two_agents
        from whispers.registry import AgentRegistry
        reg = AgentRegistry(wdb)

        # Track what the dispatcher delivers to transports
        delivered = []
        disp.add_transport_listener(lambda env: delivered.append(env))

        # Register an ephemeral sender (like /signal would)
        sender = "iot-sensor-1"
        reg.register(sender, agent_type="ephemeral")

        client = WhispersClient(sender, db_path=wdb.db_path, agent_type="ephemeral")
        client.dispatcher = disp

        result = client.send(
            to="bob",
            subject="Temperature Alert",
            body="Office temp > 80F",
            priority="routine",
            msg_type="inform",
            metadata={"whispers:signal_entry": True, "whispers:basis": "declared"},
            ephemeral=True,
        )
        assert result.get("id") is not None
        assert result.get("status") in ("queued", "delivered")

        # Ephemeral messages dispatch to transports but don't persist to inbox
        inbox = wdb.peek_inbox("bob")
        assert len(inbox) == 0, "Ephemeral signals should not persist to inbox"

    def test_signal_non_ephemeral_stores(self, two_agents):
        """A non-ephemeral send from the same sender should persist."""
        alice, bob, wdb, disp = two_agents
        from whispers.registry import AgentRegistry
        reg = AgentRegistry(wdb)
        reg.register("sensor", agent_type="ephemeral")

        client = WhispersClient("sensor", db_path=wdb.db_path, agent_type="ephemeral")
        client.dispatcher = disp

        result = client.send(
            to="bob",
            subject="Persistent Alert",
            body="This one stores",
            priority="routine",
            msg_type="inform",
            ephemeral=False,
        )
        assert result.get("id") is not None

        inbox = wdb.peek_inbox("bob")
        assert len(inbox) >= 1
        found = any(m["subject"] == "Persistent Alert" for m in inbox)
        assert found, "Non-ephemeral messages should persist to inbox"

    def test_signal_rejects_flash_priority(self, temp_db):
        """Flash priority should be rejected from unauthenticated /signal."""
        # This tests the logic, not the HTTP layer
        priority = "flash"
        assert priority in ("flash", "system"), "Flash should be in blocked set"

    def test_signal_rate_limit_logic(self):
        """Rate limiting should cap signals per sender."""
        from whispers.server import _SIGNAL_RATE_LIMIT, _SIGNAL_RATE_WINDOW
        assert _SIGNAL_RATE_LIMIT == 5, "Default rate limit should be 5 per minute"
        assert _SIGNAL_RATE_WINDOW == 60.0, "Rate window should be 60 seconds"


# ===========================================================================
# Relationship Health / Trust Topology
# ===========================================================================


class TestRelationshipHealth:
    """Trust topology from baton interaction history."""

    def _create_baton(self, db, owner, assignee, *, outcome=None, state="offered"):
        """Insert a baton projection for testing."""
        baton_ref = str(uuid.uuid4())
        with db.get_connection() as conn:
            conn.execute(
                """
                INSERT INTO baton_projections
                    (baton_ref, owner_callsign, assignee_callsign, state, outcome,
                     delineation_text, priority, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, 'test baton', 'routine',
                        datetime('now', '-1 hour'), datetime('now'))
                """,
                (baton_ref, owner, assignee, state, outcome),
            )
        return baton_ref

    def test_empty_returns_empty(self, db):
        result = db.get_relationship_health()
        assert result == []

    def test_single_completed_baton(self, db):
        self._create_baton(db, "alice", "bob", outcome="completed", state="completed")
        result = db.get_relationship_health()
        assert len(result) == 1
        pair = result[0]
        assert pair["sender"] == "alice"
        assert pair["receiver"] == "bob"
        assert pair["total_batons"] == 1
        assert pair["completed"] == 1
        assert pair["completion_rate"] == 1.0
        assert pair["health"] == 1.0
        assert pair["basis"] == "derived"

    def test_expired_baton_hurts_health(self, db):
        self._create_baton(db, "alice", "bob", outcome="completed", state="completed")
        self._create_baton(db, "alice", "bob", outcome="expired", state="expired")
        result = db.get_relationship_health()
        assert len(result) == 1
        pair = result[0]
        assert pair["total_batons"] == 2
        assert pair["completed"] == 1
        assert pair["expired"] == 1
        assert pair["health"] < 1.0  # expired should hurt health score

    def test_multiple_pairs_sorted_by_count(self, db):
        # alice->bob: 3 batons
        for _ in range(3):
            self._create_baton(db, "alice", "bob", outcome="completed", state="completed")
        # carol->dave: 1 baton
        self._create_baton(db, "carol", "dave", outcome="completed", state="completed")

        result = db.get_relationship_health()
        assert len(result) == 2
        assert result[0]["total_batons"] == 3  # most interactions first
        assert result[1]["total_batons"] == 1

    def test_open_batons_tracked(self, db):
        self._create_baton(db, "alice", "bob", state="offered")
        result = db.get_relationship_health()
        assert len(result) == 1
        assert result[0]["open"] == 1
        assert result[0]["completed"] == 0

    def test_limit_parameter(self, db):
        for i in range(5):
            self._create_baton(db, f"sender{i}", f"receiver{i}", outcome="completed", state="completed")
        result = db.get_relationship_health(limit=3)
        assert len(result) == 3


# ===========================================================================
# Signal Decay (Priority Ages Over Time)
# ===========================================================================


class TestSignalDecay:
    """Priority decay — urgency has a half-life."""

    def test_flash_decays_to_priority(self):
        from whispers.priority_decay import compute_decayed_priority, FLASH_DECAY_SECONDS
        assert compute_decayed_priority("flash", FLASH_DECAY_SECONDS + 1) == "priority"

    def test_flash_stays_fresh(self):
        from whispers.priority_decay import compute_decayed_priority, FLASH_DECAY_SECONDS
        assert compute_decayed_priority("flash", FLASH_DECAY_SECONDS - 1) == "flash"

    def test_priority_decays_to_routine(self):
        from whispers.priority_decay import compute_decayed_priority, PRIORITY_DECAY_SECONDS
        assert compute_decayed_priority("priority", PRIORITY_DECAY_SECONDS + 1) == "routine"

    def test_priority_stays_fresh(self):
        from whispers.priority_decay import compute_decayed_priority, PRIORITY_DECAY_SECONDS
        assert compute_decayed_priority("priority", PRIORITY_DECAY_SECONDS - 1) == "priority"

    def test_routine_never_decays(self):
        from whispers.priority_decay import compute_decayed_priority
        assert compute_decayed_priority("routine", 999999) == "routine"

    def test_system_never_decays(self):
        from whispers.priority_decay import compute_decayed_priority
        assert compute_decayed_priority("system", 999999) == "system"

    def test_apply_to_message_sets_effective_priority(self):
        from whispers.priority_decay import apply_priority_decay
        from datetime import datetime, timezone, timedelta
        old_time = (datetime.now(timezone.utc) - timedelta(minutes=20)).isoformat()
        msg = {"priority": "flash", "created_at": old_time, "subject": "test"}
        result = apply_priority_decay(msg)
        assert result["priority"] == "priority"
        assert result["effective_priority"] == "priority"
        assert result["original_priority"] == "flash"

    def test_apply_preserves_fresh_message(self):
        from whispers.priority_decay import apply_priority_decay
        from datetime import datetime, timezone
        now = datetime.now(timezone.utc).isoformat()
        msg = {"priority": "flash", "created_at": now, "subject": "test"}
        result = apply_priority_decay(msg)
        assert result["priority"] == "flash"
        assert "effective_priority" not in result

    def test_batch_applies_to_all(self):
        from whispers.priority_decay import apply_priority_decay_batch
        from datetime import datetime, timezone, timedelta
        old_time = (datetime.now(timezone.utc) - timedelta(hours=2)).isoformat()
        messages = [
            {"priority": "flash", "created_at": old_time},
            {"priority": "priority", "created_at": old_time},
            {"priority": "routine", "created_at": old_time},
        ]
        results = apply_priority_decay_batch(messages)
        assert results[0]["priority"] == "priority"  # flash → priority
        assert results[1]["priority"] == "routine"    # priority → routine
        assert results[2]["priority"] == "routine"    # routine stays

    def test_decay_wired_into_status_pending_counts(self, two_agents):
        """Verify that pending_by_priority in status uses decayed priorities."""
        alice, bob, wdb, disp = two_agents
        # Send a flash message and manually backdate it
        r = alice.send(to="bob", subject="old flash", body="stale", priority="flash")
        msg_id = r["id"]

        # Backdate the message by 20 minutes (past flash decay threshold)
        with wdb.get_connection() as conn:
            conn.execute(
                "UPDATE messages SET created_at = datetime('now', '-20 minutes') WHERE uuid = ?",
                (msg_id,),
            )

        # Get status — pending_by_priority should show decayed priority
        status = bob.status()
        pending = status.get("pending_by_priority", {})
        # Flash should have decayed to priority
        assert pending.get("flash", 0) == 0, "Stale flash should decay to priority"
        assert pending.get("priority", 0) >= 1, "Decayed flash should count as priority"


# ===========================================================================
# Auto-Noted Reflex / Archive Reason (Machine Courtesy)
# ===========================================================================


class TestArchiveWithReflexTag:
    """Reflexive archiving should use dedicated archive_reason, not ack_detail."""

    def test_archive_sets_reason(self, two_agents):
        alice, bob, wdb, disp = two_agents
        r = alice.send(to="bob", subject="fyi", body="info only")
        msg_id = r["id"]

        result = wdb.archive_with_reflex_tag(msg_id, "bob", reason="reflex:auto_noted", detail="routine inform while do_not_interrupt")
        assert result is True

        # Verify archive_reason is set correctly
        with wdb.get_connection() as conn:
            row = conn.execute(
                "SELECT archived_at, archive_reason, ack_detail FROM message_recipients WHERE message_uuid = ? AND recipient_callsign = ?",
                (msg_id, "bob"),
            ).fetchone()
            assert row is not None
            assert row["archived_at"] is not None
            assert "[reflex:auto_noted]" in row["archive_reason"]
            assert "do_not_interrupt" in row["archive_reason"]
            # ack_detail should NOT be polluted by reflex data
            assert row["ack_detail"] is None

    def test_archive_does_not_overwrite_existing_reason(self, two_agents):
        alice, bob, wdb, disp = two_agents
        r = alice.send(to="bob", subject="fyi", body="info")
        msg_id = r["id"]

        # First archive
        wdb.archive_with_reflex_tag(msg_id, "bob", reason="reflex:auto_noted")
        # Try to archive again (different reason)
        wdb.archive_with_reflex_tag(msg_id, "bob", reason="reflex:stale_cleanup")

        with wdb.get_connection() as conn:
            row = conn.execute(
                "SELECT archive_reason FROM message_recipients WHERE message_uuid = ? AND recipient_callsign = ?",
                (msg_id, "bob"),
            ).fetchone()
            # Should keep original reason (COALESCE preserves first non-null)
            # But archived_at IS NULL check prevents second update entirely
            assert "auto_noted" in row["archive_reason"]

    def test_already_archived_not_updated(self, two_agents):
        alice, bob, wdb, disp = two_agents
        r = alice.send(to="bob", subject="fyi", body="info")
        msg_id = r["id"]

        wdb.archive_with_reflex_tag(msg_id, "bob", reason="reflex:first")
        # Second call should no-op (WHERE archived_at IS NULL fails)
        wdb.archive_with_reflex_tag(msg_id, "bob", reason="reflex:second")

        with wdb.get_connection() as conn:
            row = conn.execute(
                "SELECT archive_reason FROM message_recipients WHERE message_uuid = ? AND recipient_callsign = ?",
                (msg_id, "bob"),
            ).fetchone()
            assert "first" in row["archive_reason"]
            assert "second" not in row["archive_reason"]


# ===========================================================================
# Predictive Escalation (Machine Courtesy)
# ===========================================================================


class TestPredictiveEscalation:
    """Stale readiness + actionable items = proactive surfacing."""

    def _make_agent(self, name, staleness_seconds, actionable_count=3, readiness="ready"):
        return {
            "agent_name": name,
            "last_heartbeat_epoch": time.time() - staleness_seconds,
            "actionable_count": actionable_count,
            "readiness": readiness,
        }

    def test_fresh_agent_no_escalation(self):
        agent = self._make_agent("bob", staleness_seconds=60)
        insights = reflex_stale_readiness({"agents": [agent]})
        assert len(insights) == 0

    def test_stale_with_actionable_triggers_concern(self):
        agent = self._make_agent("bob", staleness_seconds=_STALE_READINESS_THRESHOLD + 60)
        insights = reflex_stale_readiness({"agents": [agent]})
        assert len(insights) == 1
        assert insights[0].reflex == "stale_readiness"
        assert insights[0].stage.value == "concern"
        assert insights[0].details["escalation"] == "routine"
        assert insights[0].details["actionable_count"] == 3

    def test_very_stale_triggers_recommend(self):
        agent = self._make_agent("bob", staleness_seconds=_STALE_READINESS_THRESHOLD * 2 + 60)
        insights = reflex_stale_readiness({"agents": [agent]})
        assert len(insights) == 1
        assert insights[0].stage.value == "recommend"
        assert insights[0].details["escalation"] == "priority"

    def test_urgent_threshold(self):
        agent = self._make_agent("bob", staleness_seconds=_STALE_READINESS_URGENT + 60)
        insights = reflex_stale_readiness({"agents": [agent]})
        assert len(insights) == 1
        assert insights[0].stage.value == "urgent"
        assert insights[0].details["escalation"] == "flash"

    def test_stale_with_no_actionable_items_skipped(self):
        agent = self._make_agent("bob", staleness_seconds=_STALE_READINESS_URGENT + 60, actionable_count=0)
        insights = reflex_stale_readiness({"agents": [agent]})
        assert len(insights) == 0

    def test_multiple_agents_each_evaluated(self):
        agents = [
            self._make_agent("bob", staleness_seconds=_STALE_READINESS_THRESHOLD + 60),
            self._make_agent("carol", staleness_seconds=_STALE_READINESS_URGENT + 60),
            self._make_agent("dave", staleness_seconds=60),  # fresh
        ]
        insights = reflex_stale_readiness({"agents": agents})
        assert len(insights) == 2
        names = {i.details["agent_name"] for i in insights}
        assert names == {"bob", "carol"}


# ===========================================================================
# Queue-Class-Aware Inbox Ordering (Attention Rules as Runtime)
# ===========================================================================


class TestQueueClassInboxOrdering:
    """Inbox should sort by queue class: actionable > system > conversation > reference."""

    def test_actionable_before_conversation(self, two_agents):
        alice, bob, wdb, disp = two_agents
        # Send a conversation message first
        alice.send(to="bob", subject="chat", body="hey", priority="routine", msg_type="inform")
        # Then send an actionable message (request type)
        alice.send(to="bob", subject="task", body="do this", priority="routine", msg_type="request")

        inbox = wdb.peek_inbox("bob")
        assert len(inbox) == 2
        # Actionable (request) should come first despite being sent second
        assert inbox[0]["msg_type"] == "request"
        assert inbox[1]["msg_type"] == "inform"

    def test_flash_actionable_before_routine_actionable(self, two_agents):
        alice, bob, wdb, disp = two_agents
        # Both are actionable, but different priorities
        alice.send(to="bob", subject="routine task", body="do this", priority="routine", msg_type="request")
        alice.send(to="bob", subject="urgent task", body="now!", priority="flash", msg_type="inform")

        inbox = wdb.peek_inbox("bob")
        assert len(inbox) == 2
        # Both actionable (request is actionable by type, flash is actionable by priority)
        # Flash should come first within the actionable class
        assert inbox[0]["priority"] == "flash"

    def test_system_before_conversation(self, two_agents):
        alice, bob, wdb, disp = two_agents
        # Send a conversation message
        alice.send(to="bob", subject="chat", body="hey", priority="routine", msg_type="inform")

        # Send a system message (from whispers-server)
        from whispers.registry import AgentRegistry
        reg = AgentRegistry(wdb)
        reg.register("whispers-server", agent_type="service")
        server = WhispersClient("whispers-server", db_path=wdb.db_path, agent_type="service")
        server.dispatcher = disp
        server.send(to="bob", subject="system notice", body="maintenance", priority="routine", msg_type="inform")

        inbox = wdb.peek_inbox("bob")
        assert len(inbox) == 2
        # System should come before conversation
        subjects = [m["subject"] for m in inbox]
        assert subjects.index("system notice") < subjects.index("chat")


# ===========================================================================
# Courtesy Suppression (Interruptibility-Aware Delivery)
# ===========================================================================


class TestCourtesySuppression:
    """When recipients are busy, routine FYIs should be held or deferred, not alerting."""

    def _set_interruptibility(self, wdb, agent_name, session_id, interruptibility):
        """Set interruptibility for an agent via runtime state."""
        with wdb.get_connection() as conn:
            conn.execute(
                """
                INSERT OR REPLACE INTO agent_runtime_state
                    (session_id, agent_name, interruptibility)
                VALUES (?, ?, ?)
                """,
                (session_id, agent_name, interruptibility),
            )

    def test_do_not_interrupt_holds_routine_quietly(self, two_agents):
        alice, bob, wdb, disp = two_agents
        self._set_interruptibility(wdb, "bob", bob.session_id, "do_not_interrupt")

        # Routine inform to a do_not_interrupt recipient
        result = alice.send(to="bob", subject="fyi", body="no rush", priority="routine", msg_type="inform")
        # Message should still be delivered (stored), not dead-lettered
        assert result.get("status") != "dead_lettered"

    def test_do_not_interrupt_does_not_block_flash(self, two_agents):
        alice, bob, wdb, disp = two_agents
        self._set_interruptibility(wdb, "bob", bob.session_id, "do_not_interrupt")

        # Flash should bypass courtesy
        result = alice.send(to="bob", subject="blocked!", body="help", priority="flash")
        assert result.get("status") != "dead_lettered"

    def test_do_not_interrupt_does_not_block_requests(self, two_agents):
        alice, bob, wdb, disp = two_agents
        self._set_interruptibility(wdb, "bob", bob.session_id, "do_not_interrupt")

        # Request should bypass courtesy (protected signal type)
        result = alice.send(to="bob", subject="task", body="do this", priority="routine", msg_type="request")
        assert result.get("status") != "dead_lettered"

    def test_urgent_only_defers_routine(self, two_agents):
        alice, bob, wdb, disp = two_agents
        self._set_interruptibility(wdb, "bob", bob.session_id, "urgent_only")

        result = alice.send(to="bob", subject="fyi", body="info", priority="routine", msg_type="inform")
        assert result.get("status") != "dead_lettered"

    def test_free_interruptibility_no_courtesy(self, two_agents):
        alice, bob, wdb, disp = two_agents
        self._set_interruptibility(wdb, "bob", bob.session_id, "free")

        result = alice.send(to="bob", subject="fyi", body="info", priority="routine", msg_type="inform")
        assert result.get("status") != "dead_lettered"

    def test_priority_messages_bypass_courtesy(self, two_agents):
        alice, bob, wdb, disp = two_agents
        self._set_interruptibility(wdb, "bob", bob.session_id, "do_not_interrupt")

        # Priority (not flash) should not be courtesy-suppressed
        result = alice.send(to="bob", subject="important", body="read this", priority="priority", msg_type="inform")
        assert result.get("status") != "dead_lettered"

    def test_courtesy_only_affects_inform_and_heads_up(self, two_agents):
        alice, bob, wdb, disp = two_agents
        self._set_interruptibility(wdb, "bob", bob.session_id, "do_not_interrupt")

        # Request type should bypass courtesy even at routine priority
        result = alice.send(to="bob", subject="question", body="can you help?", priority="routine", msg_type="request")
        assert result.get("status") != "dead_lettered"


# ===========================================================================
# Feature Interaction Tests (cross-boundary behavior)
# ===========================================================================


class TestFeatureInteractions:
    """Tests for how differentiator features interact with each other."""

    def _set_interruptibility(self, wdb, agent_name, session_id, interruptibility):
        with wdb.get_connection() as conn:
            conn.execute(
                "INSERT OR REPLACE INTO agent_runtime_state (session_id, agent_name, interruptibility) VALUES (?, ?, ?)",
                (session_id, agent_name, interruptibility),
            )

    def test_habituation_plus_courtesy_both_apply(self, two_agents):
        """First send gets courtesy-held, duplicate gets coalesced."""
        alice, bob, wdb, disp = two_agents
        self._set_interruptibility(wdb, "bob", bob.session_id, "do_not_interrupt")

        # First: routine inform to do_not_interrupt → courtesy applies (but message stores)
        r1 = alice.send(to="bob", subject="fyi", body="info", priority="routine", msg_type="inform")
        assert r1.get("status") != "dead_lettered"

        # Second: same sender+subject within window → habituation coalesces
        r2 = alice.send(to="bob", subject="fyi", body="info again", priority="routine", msg_type="inform")
        assert r2.get("status") == "dead_lettered"
        assert r2.get("reason") == "habituation:coalesced"

    def test_decay_affects_inbox_ordering(self, two_agents):
        """A decayed flash should sort below a fresh priority in queue-class-aware inbox."""
        alice, bob, wdb, disp = two_agents

        # Send a flash message and backdate it past decay threshold
        r1 = alice.send(to="bob", subject="old flash", body="stale", priority="flash")
        with wdb.get_connection() as conn:
            conn.execute(
                "UPDATE messages SET created_at = datetime('now', '-20 minutes') WHERE uuid = ?",
                (r1["id"],),
            )

        # Send a fresh priority message
        r2 = alice.send(to="bob", subject="fresh priority", body="new", priority="priority")

        # Both should be in inbox
        inbox = wdb.peek_inbox("bob")
        assert len(inbox) == 2

        # Both are actionable class (flash→actionable, priority→conversation normally,
        # but priority msg_type=inform is conversation class). The key test is that
        # the decayed flash doesn't dominate over fresh messages in the same class.
        subjects = [m["subject"] for m in inbox]
        assert "old flash" in subjects
        assert "fresh priority" in subjects

    def test_sweep_pick_up_then_habituation_no_conflict(self, two_agents):
        """Picking up a message via sweep, then getting a duplicate, should still coalesce."""
        alice, bob, wdb, disp = two_agents

        r1 = alice.send(to="bob", subject="task", body="do this", priority="routine")
        wdb.inbox_sweep("bob", pick_up=[r1["id"]])

        # Duplicate within window should still be coalesced by habituation
        r2 = alice.send(to="bob", subject="task", body="do this again", priority="routine")
        assert r2.get("status") == "dead_lettered"
        assert r2.get("reason") == "habituation:coalesced"

    def test_queue_class_ordering_with_mixed_courtesy(self, two_agents):
        """Actionable messages should still sort first even when some get courtesy treatment."""
        alice, bob, wdb, disp = two_agents
        self._set_interruptibility(wdb, "bob", bob.session_id, "urgent_only")

        # Routine inform (conversation class, courtesy-deferred)
        alice.send(to="bob", subject="chat", body="hey", priority="routine", msg_type="inform")
        # Routine request (actionable class, bypasses courtesy)
        alice.send(to="bob", subject="task", body="do this", priority="routine", msg_type="request")

        inbox = wdb.peek_inbox("bob")
        assert len(inbox) == 2
        # Actionable (request) should still sort before conversation (inform)
        assert inbox[0]["msg_type"] == "request"

    def test_relationship_health_with_no_interactions(self, db):
        """Empty baton history should return empty, not crash."""
        result = db.get_relationship_health()
        assert result == []

    def test_escalation_tiers_boundary_exact(self):
        """Test exact boundary values for escalation thresholds."""
        from whispers.reflexive_engine import (
            _STALE_CONCERN_THRESHOLD,
            _ESCALATION_PRIORITY_THRESHOLD,
            reflex_stalled_handoff,
        )
        # Exactly AT the concern threshold — should fire
        baton = {
            "baton_ref": "test",
            "owner": "alice",
            "assignee": "bob",
            "assignee_online": True,
            "subject": "test",
            "version": 1,
            "state": "offered",
            "created_epoch": time.time() - _STALE_CONCERN_THRESHOLD,
        }
        insights = reflex_stalled_handoff({"active_batons": [baton]})
        assert len(insights) == 1

        # One second BELOW threshold — should not fire
        baton["created_epoch"] = time.time() - _STALE_CONCERN_THRESHOLD + 1
        insights = reflex_stalled_handoff({"active_batons": [baton]})
        assert len(insights) == 0

    def test_decay_exact_boundary(self):
        """Test exact boundary of flash decay threshold."""
        from whispers.priority_decay import compute_decayed_priority, FLASH_DECAY_SECONDS
        # Exactly at threshold — should decay
        assert compute_decayed_priority("flash", FLASH_DECAY_SECONDS) == "priority"
        # One second below — should not decay
        assert compute_decayed_priority("flash", FLASH_DECAY_SECONDS - 1) == "flash"
        # Zero age — definitely not decay
        assert compute_decayed_priority("flash", 0) == "flash"
        # Negative age (clock skew) — should not decay
        assert compute_decayed_priority("flash", -10) == "flash"

    def test_classify_queue_class_all_msg_types(self):
        """Every MsgType should classify to a valid QueueClass."""
        from whispers.envelope import MsgType, QueueClass, classify_queue_class
        valid_classes = {QueueClass.ACTIONABLE, QueueClass.CONVERSATION, QueueClass.SYSTEM, QueueClass.REFERENCE}
        for mt in MsgType:
            result = classify_queue_class(mt.value, "routine", "alice")
            assert result in valid_classes, f"MsgType {mt.value} classified to unexpected {result}"


# ===========================================================================
# Fortress: Null/Missing Input Handling (crash prevention)
# ===========================================================================


class TestNullAndMissingInputs:
    """Ensure no feature crashes on missing, null, or malformed inputs."""

    def test_classify_queue_class_empty_sender(self):
        result = classify_queue_class("inform", "routine", "")
        assert result == QueueClass.CONVERSATION

    def test_classify_queue_class_none_schema(self):
        result = classify_queue_class("inform", "routine", "alice", schema=None)
        assert result == QueueClass.CONVERSATION

    def test_classify_queue_class_empty_schema(self):
        result = classify_queue_class("inform", "routine", "alice", schema="")
        assert result == QueueClass.CONVERSATION

    def test_classify_queue_class_unknown_schema(self):
        result = classify_queue_class("inform", "routine", "alice", schema="made_up.v99")
        assert result == QueueClass.CONVERSATION

    def test_decay_missing_created_at(self):
        from whispers.priority_decay import apply_priority_decay
        msg = {"priority": "flash", "subject": "no timestamp"}
        result = apply_priority_decay(msg)
        assert result["priority"] == "flash"  # unchanged

    def test_decay_invalid_created_at(self):
        from whispers.priority_decay import apply_priority_decay
        msg = {"priority": "flash", "created_at": "garbage-timestamp", "subject": "bad"}
        result = apply_priority_decay(msg)
        assert result["priority"] == "flash"  # unchanged, not crashed

    def test_decay_null_created_at(self):
        from whispers.priority_decay import apply_priority_decay
        msg = {"priority": "flash", "created_at": None}
        result = apply_priority_decay(msg)
        assert result["priority"] == "flash"

    def test_decay_negative_age(self):
        from whispers.priority_decay import compute_decayed_priority
        assert compute_decayed_priority("flash", -100) == "flash"

    def test_decay_cascade_flash_to_routine(self):
        """Flash older than BOTH thresholds should decay to priority, not routine.
        Flash→priority is one step. A second decay would need priority→routine threshold."""
        from whispers.priority_decay import compute_decayed_priority, FLASH_DECAY_SECONDS, PRIORITY_DECAY_SECONDS
        # Flash at 2 hours — decays to priority (flash threshold met)
        result = compute_decayed_priority("flash", 7200)
        assert result == "priority"
        # The cascade question: compute_decayed_priority only does one step.
        # A flash message 2h old becomes priority. It does NOT cascade to routine
        # because the input was "flash", not "priority". This is correct — decay
        # is applied once at read time.

    def test_stale_escalation_empty_batons_list(self):
        insights = reflex_stalled_handoff({"active_batons": []})
        assert insights == []

    def test_stale_escalation_missing_batons_key(self):
        insights = reflex_stalled_handoff({})
        assert insights == []

    def test_stale_escalation_non_offered_state_ignored(self):
        """Batons in accepted/completed states should not trigger insights."""
        for state in ["accepted", "in_progress", "completed", "expired", "rejected"]:
            baton = {
                "baton_ref": "test",
                "owner": "alice",
                "assignee": "bob",
                "assignee_online": True,
                "subject": "test",
                "version": 1,
                "state": state,
                "created_epoch": time.time() - 99999,
            }
            insights = reflex_stalled_handoff({"active_batons": [baton]})
            assert len(insights) == 0, f"State '{state}' should not trigger insight"

    def test_predictive_escalation_missing_heartbeat(self):
        agent = {"agent_name": "bob", "last_heartbeat_epoch": 0, "actionable_count": 5, "readiness": "ready"}
        insights = reflex_stale_readiness({"agents": [agent]})
        assert len(insights) == 0  # epoch=0 means no heartbeat, skip

    def test_predictive_escalation_missing_fields(self):
        """Agent dict with missing keys should not crash."""
        agent = {"agent_name": "bob"}
        insights = reflex_stale_readiness({"agents": [agent]})
        assert len(insights) == 0

    def test_predictive_escalation_empty_agents(self):
        insights = reflex_stale_readiness({"agents": []})
        assert insights == []

    def test_predictive_escalation_missing_agents_key(self):
        insights = reflex_stale_readiness({})
        assert insights == []

    def test_inbox_sweep_empty_id_lists(self, db):
        result = db.inbox_sweep("nobody", pick_up=[], defer=[], note=[])
        assert result == {"picked_up": 0, "deferred": 0, "noted": 0}

    def test_inbox_sweep_nonexistent_ids(self, two_agents):
        alice, bob, wdb, disp = two_agents
        result = wdb.inbox_sweep("bob", pick_up=["nonexistent-uuid-1", "nonexistent-uuid-2"])
        assert result["picked_up"] == 0

    def test_relationship_health_null_assignee_ignored(self, db):
        """Batons with NULL assignee should not appear in health results."""
        with db.get_connection() as conn:
            conn.execute(
                """INSERT INTO baton_projections
                    (baton_ref, owner_callsign, assignee_callsign, state, outcome, priority, created_at, updated_at)
                VALUES ('test', 'alice', NULL, 'offered', NULL, 'routine', datetime('now'), datetime('now'))""",
            )
        result = db.get_relationship_health()
        assert len(result) == 0  # NULL assignee filtered by WHERE

    def test_relationship_health_limit_zero(self, db):
        result = db.get_relationship_health(limit=0)
        assert result == []

    def test_archive_reflex_nonexistent_message(self, db):
        """Archiving a nonexistent message should not crash."""
        result = db.archive_with_reflex_tag("nonexistent-uuid", "nobody")
        assert result is True  # Returns True even if no rows affected (current behavior)

    def test_archive_reflex_special_chars_in_reason(self, two_agents):
        """SQL injection attempt in reason should be safely escaped."""
        alice, bob, wdb, disp = two_agents
        r = alice.send(to="bob", subject="test", body="test")
        wdb.archive_with_reflex_tag(
            r["id"], "bob",
            reason="reflex:test'; DROP TABLE messages;--",
            detail='{"malicious": true}',
        )
        # Verify DB is intact
        inbox = wdb.peek_inbox("bob")
        assert isinstance(inbox, list)  # DB still works


# ===========================================================================
# Fortress: Queue Ordering Completeness
# ===========================================================================


class TestQueueOrderingCompleteness:
    """Exhaustive queue ordering tests — the attention model must be airtight."""

    def test_all_same_class_sorts_by_priority(self, two_agents):
        """Within same queue class, priority ordering must be correct."""
        alice, bob, wdb, disp = two_agents
        # All actionable (request type), different priorities
        alice.send(to="bob", subject="routine task", body="r", priority="routine", msg_type="request")
        alice.send(to="bob", subject="priority task", body="p", priority="priority", msg_type="request")

        inbox = wdb.peek_inbox("bob")
        assert len(inbox) == 2
        assert inbox[0]["subject"] == "priority task"
        assert inbox[1]["subject"] == "routine task"

    def test_peek_inbox_queue_class_filter_actionable(self, two_agents):
        """Filter should return ONLY matching class."""
        alice, bob, wdb, disp = two_agents
        alice.send(to="bob", subject="chat", body="hey", priority="routine", msg_type="inform")
        alice.send(to="bob", subject="task", body="do", priority="routine", msg_type="request")

        filtered = wdb.peek_inbox("bob", queue_class="actionable")
        assert len(filtered) >= 1
        assert all(m["msg_type"] == "request" for m in filtered)

    def test_peek_inbox_queue_class_filter_empty_result(self, two_agents):
        """Filter with no matches returns empty list."""
        alice, bob, wdb, disp = two_agents
        alice.send(to="bob", subject="chat", body="hey", priority="routine", msg_type="inform")

        filtered = wdb.peek_inbox("bob", queue_class="actionable")
        assert filtered == []

    def test_archived_excluded_from_inbox(self, two_agents):
        """Archived messages must not appear in inbox."""
        alice, bob, wdb, disp = two_agents
        r = alice.send(to="bob", subject="old", body="archive me")
        wdb.inbox_sweep("bob", note=[r["id"]])

        inbox = wdb.peek_inbox("bob")
        assert all(m["subject"] != "old" for m in inbox)

    def test_snoozed_excluded_from_inbox(self, two_agents):
        """Snoozed messages must not appear in inbox until snooze expires."""
        alice, bob, wdb, disp = two_agents
        r = alice.send(to="bob", subject="later", body="snooze me")
        wdb.inbox_sweep("bob", defer=[r["id"]])

        inbox = wdb.peek_inbox("bob")
        assert all(m["subject"] != "later" for m in inbox)

    def test_pinned_always_first(self, two_agents):
        """Pinned messages override all other sort criteria."""
        alice, bob, wdb, disp = two_agents
        r1 = alice.send(to="bob", subject="actionable task", body="do", priority="flash")
        r2 = alice.send(to="bob", subject="pinned chat", body="hey", priority="routine", msg_type="inform")

        # Pin the routine message
        with wdb.get_connection() as conn:
            conn.execute(
                "UPDATE message_recipients SET pinned_at = CURRENT_TIMESTAMP WHERE message_uuid = ?",
                (r2["id"],),
            )

        inbox = wdb.peek_inbox("bob")
        assert len(inbox) == 2
        # Pinned should be first even though it's routine conversation
        assert inbox[0]["subject"] == "pinned chat"


# ===========================================================================
# Fortress: Courtesy Edge Cases
# ===========================================================================


class TestCourtesyEdgeCases:
    """Edge cases in interruptibility-aware delivery."""

    def _set_interruptibility(self, wdb, agent_name, session_id, interruptibility):
        with wdb.get_connection() as conn:
            conn.execute(
                "INSERT OR REPLACE INTO agent_runtime_state (session_id, agent_name, interruptibility) VALUES (?, ?, ?)",
                (session_id, agent_name, interruptibility),
            )

    def test_null_interruptibility_defaults_to_free(self, two_agents):
        """Missing interruptibility should not trigger courtesy."""
        alice, bob, wdb, disp = two_agents
        # Don't set any interruptibility
        result = alice.send(to="bob", subject="fyi", body="info", priority="routine", msg_type="inform")
        assert result.get("status") != "dead_lettered"

    def test_heads_up_type_gets_courtesy(self, two_agents):
        """heads_up is one of the two types affected by courtesy."""
        alice, bob, wdb, disp = two_agents
        self._set_interruptibility(wdb, "bob", bob.session_id, "do_not_interrupt")

        result = alice.send(to="bob", subject="fyi", body="info", priority="routine", msg_type="heads_up")
        # Should succeed (message stores) but courtesy applies
        assert result.get("status") != "dead_lettered"

    def test_courtesy_message_still_in_inbox(self, two_agents):
        """Courtesy-suppressed messages should still be visible in inbox (not dead-lettered)."""
        alice, bob, wdb, disp = two_agents
        self._set_interruptibility(wdb, "bob", bob.session_id, "do_not_interrupt")

        r = alice.send(to="bob", subject="held quietly", body="info", priority="routine", msg_type="inform")
        assert r.get("status") != "dead_lettered"

        inbox = wdb.peek_inbox("bob")
        found = any(m["subject"] == "held quietly" for m in inbox)
        assert found, "Courtesy-held message should still be in inbox"

    def test_system_sender_bypasses_courtesy(self, two_agents):
        """Messages from whispers-server should always get through."""
        alice, bob, wdb, disp = two_agents
        self._set_interruptibility(wdb, "bob", bob.session_id, "do_not_interrupt")

        from whispers.registry import AgentRegistry
        reg = AgentRegistry(wdb)
        reg.register("whispers-server", agent_type="service")
        server = WhispersClient("whispers-server", db_path=wdb.db_path, agent_type="service")
        server.dispatcher = disp

        result = server.send(to="bob", subject="system notice", body="maintenance", priority="routine", msg_type="inform")
        assert result.get("status") != "dead_lettered"


class TestCourtesyLedger:
    """The courtesy ledger tracks what the runtime deferred, held, or coalesced."""

    def _set_interruptibility(self, wdb, agent_name, session_id, interruptibility):
        with wdb.get_connection() as conn:
            conn.execute(
                "INSERT OR REPLACE INTO agent_runtime_state (session_id, agent_name, interruptibility) VALUES (?, ?, ?)",
                (session_id, agent_name, interruptibility),
            )

    def test_courtesy_action_recorded_in_ledger(self, two_agents):
        """When courtesy holds a message, the ledger captures it."""
        alice, bob, wdb, disp = two_agents
        self._set_interruptibility(wdb, "bob", bob.session_id, "do_not_interrupt")

        alice.send(to="bob", subject="quiet fyi", body="info", priority="routine", msg_type="inform")

        summary = disp.get_courtesy_summary()
        assert summary["total_actions"] >= 1
        assert any(
            e["outcome"] in ("hold_quietly", "defer_visible")
            for e in summary["recent"]
        )

    def test_no_hold_quietly_when_free(self, two_agents):
        """Free interruptibility should never produce hold_quietly outcomes."""
        alice, bob, wdb, disp = two_agents
        self._set_interruptibility(wdb, "bob", bob.session_id, "free")

        alice.send(to="bob", subject="fyi", body="info", priority="routine", msg_type="inform")

        summary = disp.get_courtesy_summary()
        # hold_quietly only happens when recipient is busy — never when free
        holds = [
            e for e in summary.get("recent", [])
            if e["outcome"] == "hold_quietly"
        ]
        assert len(holds) == 0

    def test_habituation_coalescing_in_ledger(self, two_agents):
        """Duplicate messages within the habituation window appear in the ledger."""
        alice, bob, wdb, disp = two_agents

        alice.send(to="bob", subject="dup test", body="first", priority="routine", msg_type="inform")
        alice.send(to="bob", subject="dup test", body="second", priority="routine", msg_type="inform")

        summary = disp.get_courtesy_summary()
        coalesced = [e for e in summary.get("recent", []) if "coalesced" in e["outcome"]]
        assert len(coalesced) >= 1, "Habituation coalescing should appear in ledger"

    def test_summary_counts_by_outcome(self, two_agents):
        """Summary aggregates counts by outcome type."""
        alice, bob, wdb, disp = two_agents
        self._set_interruptibility(wdb, "bob", bob.session_id, "do_not_interrupt")

        for i in range(3):
            alice.send(to="bob", subject=f"fyi-{i}", body="info", priority="routine", msg_type="inform")

        summary = disp.get_courtesy_summary()
        assert summary["total_actions"] >= 3
        total_by_outcome = sum(summary["by_outcome"].values())
        assert total_by_outcome >= 3

    def test_summary_recent_bounded(self, two_agents):
        """Recent list never exceeds 5 entries."""
        alice, bob, wdb, disp = two_agents
        self._set_interruptibility(wdb, "bob", bob.session_id, "do_not_interrupt")

        for i in range(10):
            alice.send(to="bob", subject=f"fyi-{i}", body="info", priority="routine", msg_type="inform")

        summary = disp.get_courtesy_summary()
        assert len(summary["recent"]) <= 5


class TestConsequenceScopeRouting:
    """Consequence scope should influence attention tier in the dispatcher."""

    def test_physical_irreversible_always_interrupts(self, two_agents):
        alice, bob, wdb, disp = two_agents
        bob.set_readiness("busy")
        bob.update_cognitive_heartbeat({"interruptibility": "do_not_interrupt"})

        env = Envelope(
            sender="alice", recipient="bob",
            msg_type=MsgType.INFORM, subject="Emergency shutoff",
            priority=Priority.ROUTINE,
            consequence_scope="physical_irreversible",
        )
        disp.dispatch(env)
        assert env.metadata.get("_attention_tier") == "interrupt_now"
        assert env.metadata.get("_consequence_scope") == "physical_irreversible"

    def test_physical_reversible_promotes_hold_to_surface(self, two_agents):
        alice, bob, wdb, disp = two_agents

        env = Envelope(
            sender="alice", recipient="bob",
            msg_type=MsgType.INFORM, subject="Adjust thermostat",
            priority=Priority.ROUTINE,
            consequence_scope="physical_reversible",
        )
        disp.dispatch(env)
        # physical_reversible should promote hold_visible to surface_now
        tier = env.metadata.get("_attention_tier")
        assert tier in ("surface_now", "interrupt_now")
        assert env.metadata.get("_consequence_scope") == "physical_reversible"

    def test_digital_scope_does_not_boost(self, two_agents):
        alice, bob, wdb, disp = two_agents

        env = Envelope(
            sender="alice", recipient="bob",
            msg_type=MsgType.INFORM, subject="Log update",
            priority=Priority.ROUTINE,
            consequence_scope="digital",
        )
        disp.dispatch(env)
        assert env.metadata.get("_consequence_scope") == "digital"
        # digital should not force interrupt_now on a routine inform
        assert env.metadata.get("_attention_tier") != "interrupt_now"

    def test_metadata_consequence_scope_from_signal(self, two_agents):
        """consequence_scope from whispers:consequence_scope metadata (signal entry path)."""
        alice, bob, wdb, disp = two_agents

        env = Envelope(
            sender="alice", recipient="bob",
            msg_type=MsgType.INFORM, subject="Sensor alert",
            priority=Priority.ROUTINE,
            metadata={"whispers:consequence_scope": "physical_irreversible"},
        )
        disp.dispatch(env)
        assert env.metadata.get("_attention_tier") == "interrupt_now"

    @staticmethod
    def _set_interruptibility(wdb, agent_name, session_id, interruptibility):
        with wdb.get_connection() as conn:
            conn.execute(
                "INSERT OR REPLACE INTO runtime_state (agent_name, session_id, readiness, interruptibility, updated_at) "
                "VALUES (?, ?, 'busy', ?, datetime('now'))",
                (agent_name, session_id, interruptibility),
            )
