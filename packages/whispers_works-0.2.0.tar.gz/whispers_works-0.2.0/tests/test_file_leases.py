import asyncio
import importlib
import sys
import time

from fastapi.testclient import TestClient

import whispers.mcp_server as mcp_module
from whispers.storage.db import WhispersDB, WhispersLeaseConflictError


def test_db_file_leases_conflict_release_and_reacquire(temp_db):
    db = WhispersDB(temp_db)

    leases = db.acquire_file_leases("alpha", ["whispers/storage/db.py"], ttl_seconds=3600)
    assert len(leases) == 1
    assert leases[0]["agent_name"] == "alpha"

    try:
        db.acquire_file_leases("beta", ["whispers/storage/db.py"], ttl_seconds=3600)
        assert False, "Expected lease conflict"
    except WhispersLeaseConflictError as exc:
        assert exc.conflicts[0]["held_by"] == "alpha"
        assert exc.conflicts[0]["requested_path"] == "whispers/storage/db.py"

    assert db.release_file_leases("alpha", ["whispers/storage/db.py"]) == 1

    reacquired = db.acquire_file_leases("beta", ["whispers/storage/db.py"], ttl_seconds=3600)
    assert len(reacquired) == 1
    assert reacquired[0]["agent_name"] == "beta"


def test_db_expired_file_lease_can_be_reacquired(temp_db):
    db = WhispersDB(temp_db)
    db.acquire_file_leases("alpha", ["whispers/server.py"], ttl_seconds=1)

    time.sleep(2)
    assert db.reap_expired_file_leases() >= 1

    leases = db.acquire_file_leases("beta", ["whispers/server.py"], ttl_seconds=3600)
    assert len(leases) == 1
    assert leases[0]["agent_name"] == "beta"


def test_server_repo_publish_enforces_file_leases_and_disconnect_releases(temp_db, monkeypatch):
    runtime_state_path = temp_db + "-runtime.json"
    original_module = sys.modules.get("whispers.server")
    original_db = getattr(original_module, "db", None) if original_module else None

    with monkeypatch.context() as mp:
        mp.setenv("WHISPERS_DB_PATH", temp_db)
        mp.setenv("WHISPERS_RUNTIME_STATE_PATH", runtime_state_path)
        mp.setenv("WHISPERS_REMOTE_ADMISSION_MODE", "open")

        import whispers.server as server_module

        server_module = importlib.reload(server_module)
        with TestClient(server_module.app) as api:
            alpha = api.post("/connect", json={"agent_name": "alpha"}).json()
            beta = api.post("/connect", json={"agent_name": "beta"}).json()

            first = api.post(
                "/repo:publish",
                json={"branch": "main", "head_commit": "1111111", "claimed_paths": ["whispers/storage/db.py"]},
                headers={"Authorization": f"Bearer {alpha['token']}"},
            )
            assert first.status_code == 200

            second = api.post(
                "/repo:publish",
                json={"branch": "main", "head_commit": "2222222", "claimed_paths": ["whispers/storage/db.py"]},
                headers={"Authorization": f"Bearer {beta['token']}"},
            )
            assert second.status_code == 409
            assert second.json()["detail"]["message"] == "File lease conflict."
            assert second.json()["detail"]["conflicts"][0]["held_by"] == "alpha"

            disconnected = api.post(
                "/disconnect",
                headers={"Authorization": f"Bearer {alpha['token']}"},
            )
            assert disconnected.status_code == 200

            retry = api.post(
                "/repo:publish",
                json={"branch": "main", "head_commit": "2222222", "claimed_paths": ["whispers/storage/db.py"]},
                headers={"Authorization": f"Bearer {beta['token']}"},
            )
            assert retry.status_code == 200

    if original_db is not None:
        server_module.db = original_db


def test_mcp_file_lease_and_release_tools(temp_db, monkeypatch):
    monkeypatch.setenv("WHISPERS_DB_PATH", temp_db)
    module = importlib.reload(sys.modules["whispers.mcp_server"])
    module._clients.clear()

    token_a = module.current_agent_name.set("codex")
    try:
        acquired = asyncio.run(
            module.handle_tool(
                "file_lease",
                {"paths": ["whispers/storage/db.py"]},
            )
        )
        assert "File leases acquired:" in acquired[0].text
    finally:
        module.current_agent_name.reset(token_a)

    token_b = module.current_agent_name.set("claude-code")
    try:
        conflict = asyncio.run(
            module.handle_tool(
                "file_lease",
                {"paths": ["whispers/storage/db.py"]},
            )
        )
        assert conflict[0].text.startswith("CONFLICT:")
    finally:
        module.current_agent_name.reset(token_b)

    token_a = module.current_agent_name.set("codex")
    try:
        released = asyncio.run(module.handle_tool("file_release", {"paths": ["whispers/storage/db.py"]}))
        assert "Released 1 requested file leases." in released[0].text
    finally:
        module.current_agent_name.reset(token_a)

    token_b = module.current_agent_name.set("claude-code")
    try:
        acquired = asyncio.run(
            module.handle_tool(
                "file_lease",
                {"paths": ["whispers/storage/db.py"]},
            )
        )
        assert "File leases acquired:" in acquired[0].text
    finally:
        module.current_agent_name.reset(token_b)
        module._clients.clear()
