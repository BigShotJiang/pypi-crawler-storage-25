"""Unread-truth parity tests.

Proves has_pending_messages uses the same predicate as peek_inbox:
- delivered-unread counts as pending
- unclaimed-unread counts as pending
- queued counts as pending
- read messages do NOT count as pending
- archived messages do NOT count as pending
- snoozed messages do NOT count as pending (until snooze expires)
"""

import shutil
import uuid
from pathlib import Path

import pytest

from whispers.client import WhispersClient


@pytest.fixture
def setup():
    root = Path(__file__).resolve().parents[1] / ".tmp"
    root.mkdir(parents=True, exist_ok=True)
    case_dir = root / f"unread-parity-{uuid.uuid4().hex}"
    case_dir.mkdir(parents=True, exist_ok=False)
    db_path = str(case_dir / "test.db")
    alice = WhispersClient("alice", db_path=db_path)
    bob = WhispersClient("bob", db_path=db_path)
    try:
        yield alice, bob
    finally:
        shutil.rmtree(case_dir, ignore_errors=True)


def _send_msg(sender, to="bob", subject="test", body="hello"):
    return sender.send(to=to, subject=subject, body=body, msg_type="inform")


class TestHasPendingMatchesPeekInbox:

    def test_queued_message_is_pending(self, setup):
        alice, bob = setup
        _send_msg(alice)
        assert bob.db.has_pending_messages("bob") is True
        assert len(bob.db.peek_inbox("bob")) > 0

    def test_no_messages_not_pending(self, setup):
        alice, bob = setup
        assert bob.db.has_pending_messages("bob") is False
        assert len(bob.db.peek_inbox("bob")) == 0

    def test_read_message_not_pending(self, setup):
        alice, bob = setup
        _send_msg(alice)
        # Read the inbox (marks as seen/read)
        bob.check_inbox(mark_seen=True)
        assert bob.db.has_pending_messages("bob") is False

    def test_delivered_unread_is_pending(self, setup):
        alice, bob = setup
        result = _send_msg(alice)
        msg_id = result["id"]
        # Manually set delivery_status to delivered without reading
        with bob.db.get_connection() as conn:
            conn.execute(
                "UPDATE message_recipients SET delivery_status = 'delivered' WHERE message_uuid = ?",
                (msg_id,),
            )
            conn.commit()
        assert bob.db.has_pending_messages("bob") is True
        assert len(bob.db.peek_inbox("bob")) > 0

    def test_unclaimed_unread_is_pending(self, setup):
        alice, bob = setup
        result = _send_msg(alice)
        msg_id = result["id"]
        # Manually set delivery_status to unclaimed
        with bob.db.get_connection() as conn:
            conn.execute(
                "UPDATE message_recipients SET delivery_status = 'unclaimed' WHERE message_uuid = ?",
                (msg_id,),
            )
            conn.commit()
        assert bob.db.has_pending_messages("bob") is True
        assert len(bob.db.peek_inbox("bob")) > 0

    def test_archived_message_not_pending(self, setup):
        alice, bob = setup
        result = _send_msg(alice)
        msg_id = result["id"]
        with bob.db.get_connection() as conn:
            conn.execute(
                "UPDATE message_recipients SET archived_at = CURRENT_TIMESTAMP WHERE message_uuid = ?",
                (msg_id,),
            )
            conn.commit()
        assert bob.db.has_pending_messages("bob") is False

    def test_snoozed_message_not_pending(self, setup):
        alice, bob = setup
        result = _send_msg(alice)
        msg_id = result["id"]
        with bob.db.get_connection() as conn:
            conn.execute(
                "UPDATE message_recipients SET snoozed_until = datetime('now', '+60 minutes') WHERE message_uuid = ?",
                (msg_id,),
            )
            conn.commit()
        assert bob.db.has_pending_messages("bob") is False


class TestPendingAndPeekAlwaysAgree:
    """The core invariant: has_pending_messages returns True if and only
    if peek_inbox returns a non-empty list."""

    def test_agreement_with_fresh_message(self, setup):
        alice, bob = setup
        _send_msg(alice)
        has = bob.db.has_pending_messages("bob")
        peek = len(bob.db.peek_inbox("bob")) > 0
        assert has == peek

    def test_agreement_after_read(self, setup):
        alice, bob = setup
        _send_msg(alice)
        bob.check_inbox(mark_seen=True)
        has = bob.db.has_pending_messages("bob")
        peek = len(bob.db.peek_inbox("bob")) > 0
        assert has == peek

    def test_agreement_with_no_messages(self, setup):
        alice, bob = setup
        has = bob.db.has_pending_messages("bob")
        peek = len(bob.db.peek_inbox("bob")) > 0
        assert has == peek

    def test_agreement_with_delivered_unread(self, setup):
        alice, bob = setup
        result = _send_msg(alice)
        with bob.db.get_connection() as conn:
            conn.execute(
                "UPDATE message_recipients SET delivery_status = 'delivered' WHERE message_uuid = ?",
                (result["id"],),
            )
            conn.commit()
        has = bob.db.has_pending_messages("bob")
        peek = len(bob.db.peek_inbox("bob")) > 0
        assert has == peek
