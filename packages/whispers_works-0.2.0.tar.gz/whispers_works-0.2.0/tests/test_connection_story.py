"""Tests for Connection Story and Briefing Capsule (Tranche 1)."""

import shutil
import uuid
from datetime import timedelta
from pathlib import Path

import pytest

import whispers.client as client_module
from whispers.client import WhispersClient
from whispers.connection_story import (
    ActiveReplyAlert,
    ActiveThreadWatch,
    BatonDetail,
    ConnectionStory,
    HuddlePeer,
    PeerSnapshot,
    SinceLastSeen,
    _build_reentry_packet,
    _render_active_reply_lines,
    _render_baton_detail_lines,
    _render_active_thread_watch_lines,
    build_jolt_packet,
    build_briefing_capsule,
    infer_jolt_decision,
    infer_recommended_action,
)
from whispers.coordination_runtime import CoordinationItem
from whispers.context_cost import ContextCostRecipient, summarize_context_budget
from whispers.jolt import HostWakeCapabilities, JoltBudget, JoltHostAdapter
from whispers.time_utils import utc_now


@pytest.fixture
def temp_db():
    root = Path(__file__).resolve().parents[1] / ".tmp"
    root.mkdir(parents=True, exist_ok=True)
    case_dir = root / f"whispers-test-{uuid.uuid4().hex}"
    case_dir.mkdir(parents=True, exist_ok=False)
    db_path = str(case_dir / "test_whispers.db")
    yield db_path
    shutil.rmtree(case_dir, ignore_errors=True)


# ---------------------------------------------------------------------------
# Data model tests
# ---------------------------------------------------------------------------

class TestConnectionStoryDataModel:
    def test_peer_snapshot_to_dict(self):
        peer = PeerSnapshot(
            callsign="antigravity",
            agent_type="script",
            readiness="busy",
            working_on="fixing console",
        )
        d = peer.to_dict()
        assert d["callsign"] == "antigravity"
        assert d["readiness"] == "busy"
        assert d["working_on"] == "fixing console"

    def test_peer_snapshot_omits_none(self):
        peer = PeerSnapshot(callsign="codex")
        d = peer.to_dict()
        assert "working_on" not in d

    def test_huddle_peer_to_dict(self):
        peer = HuddlePeer(
            callsign="antigravity",
            shared_workspaces=["Collaboration Runtime"],
            incoming_baton_from_them=True,
            incoming_baton_count=1,
        )
        d = peer.to_dict()
        assert d["callsign"] == "antigravity"
        assert d["shared_workspaces"] == ["Collaboration Runtime"]
        assert d["incoming_baton_from_them"] is True
        assert d["incoming_baton_count"] == 1

    def test_since_last_seen_first_session(self):
        sls = SinceLastSeen(is_first_session=True)
        d = sls.to_dict()
        assert d["is_first_session"] is True
        assert "messages_by_priority" not in d
        assert "peers_joined" not in d

    def test_since_last_seen_with_data(self):
        sls = SinceLastSeen(
            last_session_ended="2026-03-24T10:00:00Z",
            messages_arrived=3,
            messages_by_priority={"priority": 2, "routine": 1},
            peers_joined=["codex"],
            peers_departed=["antigravity"],
        )
        d = sls.to_dict()
        assert d["messages_arrived"] == 3
        assert d["messages_by_priority"]["priority"] == 2
        assert "codex" in d["peers_joined"]
        assert "antigravity" in d["peers_departed"]

    def test_connection_story_to_dict(self):
        story = ConnectionStory(
            agent_name="claude-code",
            agent_type="llm",
            trust_tier=3,
            deployment_mode="standalone",
            signal_mode="OPEN",
            peers=[PeerSnapshot(callsign="antigravity")],
            huddle_peers=[HuddlePeer(callsign="antigravity", shared_workspaces=["Console Runtime"])],
            peers_online_count=1,
            agents_registered=5,
            pending_messages=2,
            pending_by_priority={"priority": 1, "routine": 1},
            pending_by_class={"actionable": 1, "archive_history": 1},
            attention_treatment={"counts": {"surface_now": 1, "archive_only": 1}, "has_any": True},
            incoming_batons=1,
            carrying_batons=2,
            claimed_reviews=1,
            pending_assignments=1,
            pending_review_requests=2,
            blocking_review_requests=1,
            blocked_waiting_for_review=1,
            answered_waiting_to_close=1,
            coordination_highlights=[
                CoordinationItem(
                    direction="incoming",
                    kind="review_request",
                    message_id="msg-1",
                    counterpart="antigravity",
                    subject="Review request: dissent plan",
                    blocking=True,
                    requested_action="Approve or redirect the plan",
                )
            ],
        )
        d = story.to_dict()
        assert d["agent_name"] == "claude-code"
        assert d["trust_tier"] == 3
        assert len(d["peers"]) == 1
        assert d["peers"][0]["callsign"] == "antigravity"
        assert d["huddle_peers"][0]["shared_workspaces"] == ["Console Runtime"]
        assert d["pending_messages"] == 2
        assert d["pending_by_class"]["archive_history"] == 1
        assert d["attention_treatment"]["counts"]["surface_now"] == 1
        assert d["incoming_batons"] == 1
        assert d["carrying_batons"] == 2
        assert d["claimed_reviews"] == 1
        assert d["pending_assignments"] == 1
        assert d["pending_review_requests"] == 2
        assert d["blocking_review_requests"] == 1
        assert d["blocked_waiting_for_review"] == 1
        assert d["answered_waiting_to_close"] == 1
        assert d["coordination_highlights"][0]["counterpart"] == "antigravity"
        assert d["active_thread_watch_count"] == 0
        # since_last_seen not included when None
        assert "since_last_seen" not in d

    def test_connection_story_to_dict_includes_jolt_fields(self):
        story = ConnectionStory(
            agent_name="codex",
            wake_model="manual_wake",
            interruptibility="free",
            jolt_adapter=JoltHostAdapter(
                host_kind="cursor",
                adapter_kind="native_extension",
                supported_actions=("notify", "stage_context"),
                fallback_action="stage_context",
                state="supported",
            ),
            jolt_host_capabilities=HostWakeCapabilities(host_kind="cursor", can_stage_context=True),
            jolt_budget=JoltBudget(max_inferences_per_hour=4),
            pending_messages=1,
            pending_by_priority={"routine": 1},
        )
        story.jolt_decision = infer_jolt_decision(story)

        d = story.to_dict()
        assert d["wake_model"] == "manual_wake"
        assert d["interruptibility"] == "free"
        assert d["jolt_adapter"]["adapter_kind"] == "native_extension"
        assert d["jolt_host_capabilities"]["host_kind"] == "cursor"
        assert d["jolt_budget"]["max_inferences_per_hour"] == 4
        assert d["jolt"]["action"] == "suppress"

    def test_connection_story_with_since_last_seen(self):
        story = ConnectionStory(
            agent_name="claude-code",
            since_last_seen=SinceLastSeen(
                last_session_ended="2026-03-24T08:00:00Z",
                messages_arrived=5,
            ),
        )
        d = story.to_dict()
        assert "since_last_seen" in d
        assert d["since_last_seen"]["messages_arrived"] == 5

    def test_connection_story_to_dict_includes_wake_posture_and_reentry_packet(self):
        story = ConnectionStory(
            agent_name="codex",
            wake_model="manual_wake",
            interruptibility="defer",
            pending_by_class={"actionable": 1, "conversation": 2},
            pending_by_priority={"routine": 3},
            since_last_seen=SinceLastSeen(
                messages_arrived=3,
                batons_received=1,
                resume_hint="1 handoff(s) waiting for your acknowledgment",
            ),
            incoming_batons=1,
            recommended_action="Review BATON state -- incoming from claude-code.",
        )

        d = story.to_dict()

        assert d["wake_posture"]["wake_model"] == "manual_wake"
        assert d["wake_posture"]["pickup_truth"] == "pickup requires explicit ack"
        assert d["reentry_packet"]["style"] == "bounded"
        assert "1 incoming baton" in d["reentry_packet"]["blocking"][0]
        assert d["reentry_packet"]["resume_hint"] == "1 handoff(s) waiting for your acknowledgment"

    def test_build_jolt_packet_for_hot_reply(self):
        story = ConnectionStory(
            agent_name="codex",
            wake_model="manual_wake",
            interruptibility="free",
            jolt_adapter=JoltHostAdapter(
                host_kind="cursor",
                adapter_kind="native_extension",
                supported_actions=("notify", "stage_context"),
                fallback_action="stage_context",
                state="supported",
            ),
            jolt_host_capabilities=HostWakeCapabilities(host_kind="cursor", can_stage_context=True),
            active_reply_alerts=[
                ActiveReplyAlert(
                    message_id="m-1",
                    counterpart="claude-code",
                    subject="Re: Jolt packet",
                    created_at=(utc_now() - timedelta(seconds=30)).replace(microsecond=0).isoformat().replace("+00:00", "Z"),
                )
            ],
        )
        story.recommended_action = infer_recommended_action(story)
        story.jolt_decision = infer_jolt_decision(story)

        packet = build_jolt_packet(story)

        assert packet is not None
        assert packet.action == "stage_context"
        assert packet.trigger == "hot_thread"
        assert packet.headline == "Hot reply from claude-code: Re: Jolt packet"
        assert packet.freshness == "fresh"
        assert packet.source_stage == "reply_ready"
        assert packet.stale_after_seconds == 240
        assert packet.adapter is not None
        assert packet.adapter.adapter_kind == "native_extension"

    def test_build_jolt_packet_for_surface_now_actionable_unread(self):
        story = ConnectionStory(
            agent_name="codex",
            wake_model="manual_wake",
            interruptibility="free",
            pending_messages=1,
            pending_by_priority={"routine": 1},
            pending_by_class={"actionable": 1},
            attention_treatment={
                "counts": {
                    "surface_now": 1,
                    "defer_visible": 0,
                    "hold_quietly": 0,
                    "archive_only": 0,
                },
                "has_any": True,
                "primary": "surface_now",
            },
            jolt_adapter=JoltHostAdapter(
                host_kind="plain_terminal",
                adapter_kind="managed_pty",
                supported_actions=("notify",),
                fallback_action="notify",
                state="supported",
            ),
            jolt_host_capabilities=HostWakeCapabilities(
                host_kind="plain_terminal",
                can_notify=True,
                can_stage_context=False,
            ),
        )
        story.recommended_action = infer_recommended_action(story)
        story.jolt_decision = infer_jolt_decision(story)

        packet = build_jolt_packet(story)

        assert packet is not None
        assert packet.action == "notify"
        assert packet.trigger == "direct_assignment"
        assert packet.headline == "1 actionable message waiting"
        assert packet.recommended_action == "Check inbox -- 1 unread message."

    def test_deferred_actionable_unread_stays_suppressed_for_jolt(self):
        story = ConnectionStory(
            agent_name="codex",
            wake_model="manual_wake",
            interruptibility="defer",
            pending_messages=1,
            pending_by_priority={"routine": 1},
            pending_by_class={"actionable": 1},
            attention_treatment={
                "counts": {
                    "surface_now": 0,
                    "defer_visible": 1,
                    "hold_quietly": 0,
                    "archive_only": 0,
                },
                "has_any": True,
                "primary": "defer_visible",
            },
        )

        decision = infer_jolt_decision(story)
        packet = build_jolt_packet(story)

        assert decision is not None
        assert decision.action == "suppress"
        assert packet is None

    def test_build_jolt_packet_suppresses_stale_hot_thread(self):
        story = ConnectionStory(
            agent_name="codex",
            wake_model="manual_wake",
            interruptibility="free",
            active_reply_alerts=[
                ActiveReplyAlert(
                    message_id="m-stale",
                    counterpart="antigravity",
                    subject="Re: baton truth",
                    created_at=(utc_now() - timedelta(minutes=6)).replace(microsecond=0).isoformat().replace("+00:00", "Z"),
                )
            ],
        )
        story.recommended_action = infer_recommended_action(story)
        story.jolt_decision = infer_jolt_decision(story)

        packet = build_jolt_packet(story)

        assert story.jolt_decision is not None
        assert story.jolt_decision.action == "suppress"
        assert packet is None

    def test_connection_story_to_dict_includes_context_budget(self):
        story = ConnectionStory(
            agent_name="codex",
            context_budget=summarize_context_budget(
                ContextCostRecipient("codex", model_id="gpt-5", context_load=0.72)
            ),
        )
        d = story.to_dict()
        assert d["context_budget"]["default_delivery_depth"] == "summarize"
        assert d["context_budget"]["remaining_tokens_estimate"] == 35_840


# ---------------------------------------------------------------------------
# Briefing Capsule tests
# ---------------------------------------------------------------------------

class TestBriefingCapsule:
    def test_basic_briefing(self):
        story = ConnectionStory(
            agent_name="claude-code",
            deployment_mode="standalone",
            signal_mode="OPEN",
            peers_online_count=2,
            agents_registered=10,
            pending_messages=3,
            pending_by_priority={"priority": 1, "routine": 2},
            pending_by_class={"actionable": 1, "conversation": 1, "archive_history": 1},
            attention_treatment={"counts": {"surface_now": 1, "defer_visible": 1, "archive_only": 1}, "has_any": True},
            incoming_batons=1,
            carrying_batons=2,
            local_time="2026-03-24 8:00 AM PDT",
        )
        capsule = build_briefing_capsule(story)

        assert "\u23e6\u23e6\u23e6>" in capsule["status_line"]
        assert "claude-code" in capsule["status_line"]
        assert "OPEN" in capsule["status_line"]
        assert "2 peers" in capsule["status_line"]
        assert "3 unread" in capsule["status_line"]
        assert "Unread by priority: priority 1, routine 2" in capsule["detail_block"]
        assert "Unread by class: actionable 1, conversation 1, archive/history 1" in capsule["detail_block"]
        assert "Attention treatment: surface now 1, defer visible 1, archive only 1" in capsule["detail_block"]
        assert "BATON state: ← [🟨 BATON x1] | → [🟦 BATON x2]" in capsule["detail_block"]
        assert capsule["pending_messages"] == 3
        assert capsule["pending_by_class"]["archive_history"] == 1
        assert capsule["attention_treatment"]["counts"]["archive_only"] == 1
        assert capsule["incoming_batons"] == 1
        assert capsule["carrying_batons"] == 2
        assert capsule["peer_names"] == []  # No peer objects, just count
        assert capsule["must_present_block"] == capsule["status_line"]

    def test_briefing_with_peers(self):
        story = ConnectionStory(
            agent_name="claude-code",
            peers=[
                PeerSnapshot(callsign="antigravity"),
                PeerSnapshot(callsign="codex"),
            ],
            peers_online_count=2,
        )
        capsule = build_briefing_capsule(story)
        assert "antigravity" in capsule["detail_block"]
        assert "codex" in capsule["detail_block"]
        assert capsule["peer_names"] == ["antigravity", "codex"]

    def test_briefing_surfaces_deployment_mode(self):
        story = ConnectionStory(
            agent_name="claude-code",
            deployment_mode="remote",
        )
        capsule = build_briefing_capsule(story)
        assert "Deployment: Remote" in capsule["detail_block"]

    def test_briefing_surfaces_huddle_peers(self):
        story = ConnectionStory(
            agent_name="claude-code",
            huddle_peers=[
                HuddlePeer(
                    callsign="antigravity",
                    shared_workspaces=["Collaboration Runtime"],
                    incoming_baton_from_them=True,
                    incoming_baton_count=1,
                )
            ],
        )
        capsule = build_briefing_capsule(story)
        assert "Huddle nearby: antigravity [ready] | workspace Collaboration Runtime | ← [🟨 BATON x1]" in capsule["detail_block"]

    def test_briefing_surfaces_context_budget_guidance(self):
        story = ConnectionStory(
            agent_name="claude-code",
            context_budget=summarize_context_budget(
                ContextCostRecipient("claude-code", model_id="claude-sonnet", context_load=0.72)
            ),
        )
        capsule = build_briefing_capsule(story)
        assert "Context budget: 72% load" in capsule["detail_block"]
        assert "prefer summaries for larger packets" in capsule["detail_block"]

    def test_briefing_surfaces_jolt_recommendation_for_listener_backed_host(self):
        story = ConnectionStory(
            agent_name="listener",
            wake_model="listener_backed",
            interruptibility="free",
            active_reply_alerts=[
                ActiveReplyAlert(
                    message_id="msg-1",
                    counterpart="claude-code",
                    subject="Re: startup contract",
                )
            ],
        )

        capsule = build_briefing_capsule(story)
        assert "Jolt: stage local context" in capsule["detail_block"]
        assert capsule["jolt"]["action"] == "stage_context"

    def test_briefing_since_last_seen(self):
        story = ConnectionStory(
            agent_name="claude-code",
            since_last_seen=SinceLastSeen(
                messages_arrived=3,
                peers_joined=["codex"],
                peers_departed=["antigravity"],
            ),
        )
        capsule = build_briefing_capsule(story)
        assert "Since last session" in capsule["detail_block"]
        assert "3 new messages" in capsule["detail_block"]
        assert "joined: codex" in capsule["detail_block"]
        assert "departed: antigravity" in capsule["detail_block"]

    def test_briefing_first_session_no_since_block(self):
        story = ConnectionStory(
            agent_name="claude-code",
            since_last_seen=SinceLastSeen(is_first_session=True),
        )
        capsule = build_briefing_capsule(story)
        assert "Since last session" not in capsule["detail_block"]

    def test_briefing_omits_empty_priority_breakdown(self):
        story = ConnectionStory(agent_name="claude-code")
        capsule = build_briefing_capsule(story)
        assert "Unread by priority:" not in capsule["detail_block"]

    def test_briefing_hides_stale_since_block_during_live_collaboration(self):
        story = ConnectionStory(
            agent_name="claude-code",
            peers_online_count=1,
            peers=[PeerSnapshot(callsign="codex")],
            since_last_seen=SinceLastSeen(messages_arrived=46),
        )
        story.recommended_action = infer_recommended_action(story)
        capsule = build_briefing_capsule(story)
        assert "Since last session" not in capsule["detail_block"]
        assert "Suggested next action: Stay in active collaboration" in capsule["detail_block"]

    def test_briefing_recommended_action(self):
        story = ConnectionStory(
            agent_name="claude-code",
            recommended_action="Check inbox -- 5 unread messages.",
        )
        capsule = build_briefing_capsule(story)
        assert "Unread messages are inbox state only." in capsule["detail_block"]
        assert "Suggested next action" in capsule["detail_block"]
        assert "5 unread" in capsule["detail_block"]

    def test_briefing_surfaces_coordination_state(self):
        story = ConnectionStory(
            agent_name="claude-code",
            pending_assignments=1,
            pending_review_requests=1,
            blocking_review_requests=1,
            answered_waiting_to_close=1,
            coordination_highlights=[
                CoordinationItem(
                    direction="incoming",
                    kind="review_request",
                    message_id="msg-1",
                    counterpart="antigravity",
                    subject="Review request: dissent plan",
                    blocking=True,
                    requested_action="Approve or redirect the plan",
                )
            ],
        )
        capsule = build_briefing_capsule(story)
        assert "Coordination: assignments 1, review requests 1, blocking reviews 1, answers waiting to close 1" in capsule["detail_block"]
        assert "Coordination now: review request from antigravity [blocking] | Approve or redirect the plan" in capsule["detail_block"]

    def test_briefing_surfaces_wake_posture_and_reentry_packet(self):
        story = ConnectionStory(
            agent_name="codex",
            wake_model="manual_wake",
            interruptibility="free",
            pending_by_class={"actionable": 1, "conversation": 2},
            pending_by_priority={"routine": 3},
            since_last_seen=SinceLastSeen(
                messages_arrived=3,
                batons_received=1,
                resume_hint="1 handoff(s) waiting for your acknowledgment",
            ),
            incoming_batons=1,
            recommended_action="Review BATON state -- incoming from claude-code.",
        )

        capsule = build_briefing_capsule(story)

        assert "Wake posture: manual-wake | pickup requires explicit ack | re-entry: bounded catch-up | interruptibility free" in capsule["detail_block"]
        assert "Re-entry: blocking: 1 incoming baton | can wait: defer visible 2 | changed: 3 new messages; 1 incoming baton" in capsule["detail_block"]
        assert "Re-entry hint: 1 handoff(s) waiting for your acknowledgment" in capsule["detail_block"]
        assert capsule["reentry_packet"]["style"] == "bounded"

    def test_briefing_surfaces_peer_assignment_alert(self):
        story = ConnectionStory(
            agent_name="codex",
            peers=[
                PeerSnapshot(
                    callsign="claude-code",
                    attention_state="needs_assignment",
                    attention_detail="Backup lane complete and ready for the next packet.",
                    trust_tier=3,
                )
            ],
            peers_online_count=1,
        )
        capsule = build_briefing_capsule(story)
        assert "Team alert: claude-code needs assignment" in capsule["detail_block"]
        assert "Backup lane complete" in capsule["detail_block"]

    def test_briefing_surfaces_operator_nudge_for_manual_wake_peer(self):
        story = ConnectionStory(
            agent_name="codex",
            peers=[
                PeerSnapshot(
                    callsign="antigravity",
                    attention_state="needs_assignment",
                    attention_detail="Main and backup packets are complete.",
                    trust_tier=3,
                    wake_model="manual_wake",
                    operator_nudge_required=True,
                )
            ],
            peers_online_count=1,
        )
        capsule = build_briefing_capsule(story)
        assert "operator nudge required" in capsule["detail_block"]
        assert capsule["peer_nudge_requests"] == 1
        assert capsule["peer_nudge_alerts"][0]["callsign"] == "antigravity"

    def test_briefing_http_unreachable_warning(self):
        story = ConnectionStory(
            agent_name="claude-code",
            http_server_reachable=False,
        )
        capsule = build_briefing_capsule(story)
        assert "\u23e6\u23e6\u23e6>" in capsule["detail_block"]
        assert "HTTP server unreachable" in capsule["detail_block"]

    def test_briefing_surfaces_hot_reply_lines(self):
        story = ConnectionStory(
            agent_name="codex",
            active_reply_alerts=[
                ActiveReplyAlert(
                    message_id="msg-hot",
                    counterpart="claude-code",
                    subject="Re: Codex synthesis",
                )
            ],
        )
        capsule = build_briefing_capsule(story)
        assert "Hot reply: claude-code responded" in capsule["detail_block"]
        assert "Re: Codex synthesis" in capsule["detail_block"]
        assert capsule["active_reply_requests"] == 1

    def test_briefing_marks_stale_hot_reply_as_waiting(self):
        story = ConnectionStory(
            agent_name="codex",
            active_reply_alerts=[
                ActiveReplyAlert(
                    message_id="msg-hot",
                    counterpart="claude-code",
                    subject="Re: Codex synthesis",
                    created_at=(utc_now() - timedelta(minutes=6)).replace(microsecond=0).isoformat().replace("+00:00", "Z"),
                )
            ],
        )
        capsule = build_briefing_capsule(story)
        assert "Reply waiting: claude-code responded" in capsule["detail_block"]
        assert "Hot reply:" not in capsule["detail_block"]

    def test_briefing_surfaces_hot_thread_lines(self):
        story = ConnectionStory(
            agent_name="codex",
            active_thread_watches=[
                ActiveThreadWatch(
                    message_id="msg-hot-thread",
                    counterpart="claude-code",
                    subject="Re: Codex synthesis",
                    stage="awaiting_reply",
                    stage_label="read",
                    age_label="45s",
                )
            ],
        )
        capsule = build_briefing_capsule(story)
        assert "Hot thread: claude-code read it" in capsule["detail_block"]
        assert "awaiting reply for 45s" in capsule["detail_block"]
        assert capsule["active_thread_watch_count"] == 1

    def test_briefing_marks_stale_hot_thread_as_cooling(self):
        story = ConnectionStory(
            agent_name="codex",
            active_thread_watches=[
                ActiveThreadWatch(
                    message_id="msg-hot-thread",
                    counterpart="claude-code",
                    subject="Re: Codex synthesis",
                    stage="awaiting_reply",
                    stage_started_at=(utc_now() - timedelta(minutes=6)).replace(microsecond=0).isoformat().replace("+00:00", "Z"),
                    stage_label="read",
                    age_label="6m",
                )
            ],
        )
        capsule = build_briefing_capsule(story)
        assert "Cooling thread: claude-code read it" in capsule["detail_block"]
        assert "Hot thread: claude-code read it" not in capsule["detail_block"]


# ---------------------------------------------------------------------------
# Recommended action inference tests
# ---------------------------------------------------------------------------

class TestRecommendedAction:
    def test_flash_messages_urgent(self):
        story = ConnectionStory(
            agent_name="test",
            pending_messages=3,
            pending_by_priority={"flash": 1, "routine": 2},
        )
        action = infer_recommended_action(story)
        assert "immediately" in action
        assert "flash" in action

    def test_unread_messages(self):
        story = ConnectionStory(
            agent_name="test",
            pending_messages=5,
            pending_by_priority={"routine": 5},
        )
        action = infer_recommended_action(story)
        assert "Check inbox" in action
        assert "5 unread" in action

    def test_hot_reply_outranks_generic_unread_messages(self):
        story = ConnectionStory(
            agent_name="test",
            pending_messages=5,
            pending_by_priority={"routine": 5},
            active_reply_alerts=[
                ActiveReplyAlert(
                    message_id="msg-1",
                    counterpart="claude-code",
                    subject="Re: Narrator contract",
                )
            ],
        )
        action = infer_recommended_action(story)
        assert "Open hot reply from claude-code" in action
        assert "Narrator contract" in action

    def test_hot_thread_outranks_generic_unread_messages(self):
        story = ConnectionStory(
            agent_name="test",
            pending_messages=5,
            pending_by_priority={"routine": 5},
            active_thread_watches=[
                ActiveThreadWatch(
                    message_id="msg-watch",
                    counterpart="claude-code",
                    subject="Re: Narrator contract",
                    stage="awaiting_reply",
                    stage_label="read",
                    age_label="2m",
                )
            ],
        )
        action = infer_recommended_action(story)
        assert "Stay hot on thread with claude-code" in action
        assert "Narrator contract" in action

    def test_hot_thread_recommended_action_surfaces_delivery_age(self):
        story = ConnectionStory(
            agent_name="test",
            active_thread_watches=[
                ActiveThreadWatch(
                    message_id="msg-watch",
                    counterpart="antigravity",
                    subject="Re: baton truth",
                    stage="awaiting_read",
                    stage_label="delivered",
                    age_label="2m",
                )
            ],
        )
        action = infer_recommended_action(story)
        assert "Stay hot on thread with antigravity" in action
        assert "delivered and unread" in action
        assert "delivered 2m ago" in action

    def test_hot_thread_recommended_action_surfaces_delivery_queue_age(self):
        story = ConnectionStory(
            agent_name="test",
            active_thread_watches=[
                ActiveThreadWatch(
                    message_id="msg-watch",
                    counterpart="claude-code",
                    subject="Re: Narrator contract",
                    stage="awaiting_delivery",
                    stage_label="sent",
                    age_label="45s",
                )
            ],
        )
        action = infer_recommended_action(story)
        assert "queued for delivery" in action
        assert "sent 45s ago" in action

    def test_hot_thread_recommended_action_collapses_same_counterpart_threads(self):
        story = ConnectionStory(
            agent_name="test",
            active_thread_watches=[
                ActiveThreadWatch(
                    message_id="msg-watch-1",
                    counterpart="claude-code",
                    subject="Reply payload",
                    stage="awaiting_reply",
                    stage_label="read",
                    age_label="31s",
                ),
                ActiveThreadWatch(
                    message_id="msg-watch-2",
                    counterpart="claude-code",
                    subject="Re: 8 commits landed + cron polling active",
                    stage="awaiting_reply",
                    stage_label="read",
                    age_label="2m",
                ),
            ],
        )
        action = infer_recommended_action(story)
        assert "Stay hot on thread with claude-code" in action
        assert "Reply payload (+1 more)" in action
        assert "claude-code, claude-code" not in action

    def test_render_active_thread_watch_lines_collapses_same_counterpart_threads(self):
        lines = _render_active_thread_watch_lines(
            [
                ActiveThreadWatch(
                    message_id="msg-watch-1",
                    counterpart="claude-code",
                    subject="Reply payload",
                    stage="awaiting_reply",
                    stage_label="read",
                    age_label="31s",
                ),
                ActiveThreadWatch(
                    message_id="msg-watch-2",
                    counterpart="claude-code",
                    subject="Re: 8 commits landed + cron polling active",
                    stage="awaiting_reply",
                    stage_label="read",
                    age_label="2m",
                ),
            ]
        )
        assert lines == [
            "Hot thread: claude-code read multiple messages | Reply payload (+1 more) | awaiting reply for 31s"
        ]

    def test_render_active_reply_lines_marks_stale_reply_waiting(self):
        lines = _render_active_reply_lines(
            [
                ActiveReplyAlert(
                    message_id="msg-hot",
                    counterpart="claude-code",
                    subject="Re: Codex synthesis",
                    created_at=(utc_now() - timedelta(minutes=6)).replace(microsecond=0).isoformat().replace("+00:00", "Z"),
                )
            ]
        )
        assert lines == ["Reply waiting: claude-code responded | Re: Codex synthesis | 6m old"]

    def test_render_active_thread_watch_lines_marks_stale_thread_as_cooling(self):
        lines = _render_active_thread_watch_lines(
            [
                ActiveThreadWatch(
                    message_id="msg-watch-1",
                    counterpart="claude-code",
                    subject="Reply payload",
                    stage="awaiting_reply",
                    stage_started_at=(utc_now() - timedelta(minutes=6)).replace(microsecond=0).isoformat().replace("+00:00", "Z"),
                    stage_label="read",
                    age_label="6m",
                )
            ]
        )
        assert lines == [
            "Cooling thread: claude-code read it | Reply payload | awaiting reply for 6m"
        ]

    def test_reentry_packet_omits_stale_hot_follow_through(self):
        story = ConnectionStory(
            agent_name="codex",
            active_thread_watches=[
                ActiveThreadWatch(
                    message_id="msg-watch-1",
                    counterpart="claude-code",
                    subject="Reply payload",
                    stage="awaiting_reply",
                    stage_started_at=(utc_now() - timedelta(minutes=6)).replace(microsecond=0).isoformat().replace("+00:00", "Z"),
                    stage_label="read",
                    age_label="6m",
                )
            ],
        )
        assert _build_reentry_packet(story) == {}

    def test_incoming_batons_outrank_plain_unread_messages(self):
        story = ConnectionStory(
            agent_name="test",
            pending_messages=5,
            pending_by_priority={"routine": 5},
            incoming_batons=2,
        )
        action = infer_recommended_action(story)
        assert "BATON state" in action
        assert "2 incoming baton" in action

    def test_carrying_batons_surface_when_no_incoming(self):
        story = ConnectionStory(
            agent_name="test",
            carrying_batons=1,
        )
        action = infer_recommended_action(story)
        assert "Advance BATON state" in action

    def test_surface_now_unread_outranks_carrying_batons(self):
        story = ConnectionStory(
            agent_name="test",
            pending_messages=1,
            pending_by_priority={"routine": 1},
            carrying_batons=1,
            attention_treatment={
                "counts": {
                    "surface_now": 1,
                    "defer_visible": 0,
                    "hold_quietly": 0,
                    "archive_only": 0,
                },
                "has_any": True,
                "primary": "surface_now",
            },
        )
        action = infer_recommended_action(story)
        assert "Check inbox" in action
        assert "1 unread message" in action

    def test_claimed_reviews_surface_before_peers_online(self):
        story = ConnectionStory(
            agent_name="test",
            claimed_reviews=2,
            peers_online_count=3,
        )
        action = infer_recommended_action(story)
        assert "claimed review" in action

    def test_blocking_review_request_outranks_batons(self):
        story = ConnectionStory(
            agent_name="test",
            incoming_batons=2,
            coordination_highlights=[
                CoordinationItem(
                    direction="incoming",
                    kind="review_request",
                    message_id="msg-1",
                    counterpart="antigravity",
                    subject="Review request: dissent plan",
                    blocking=True,
                    requested_action="Approve or redirect the plan",
                )
            ],
            blocking_review_requests=1,
        )
        action = infer_recommended_action(story)
        assert "Review blocking request from antigravity" in action
        assert "Approve or redirect the plan" in action

    def test_assignment_surfaces_before_plain_unread_messages(self):
        story = ConnectionStory(
            agent_name="test",
            pending_messages=5,
            coordination_highlights=[
                CoordinationItem(
                    direction="incoming",
                    kind="assignment",
                    message_id="msg-2",
                    counterpart="codex",
                    subject="Assignment: proof packet",
                    requested_action="Own the proof packet tranche",
                )
            ],
            pending_assignments=1,
        )
        action = infer_recommended_action(story)
        assert "Start assignment from codex" in action
        assert "Own the proof packet tranche" in action

    def test_peer_needing_assignment_outranks_plain_unread_messages(self):
        story = ConnectionStory(
            agent_name="codex",
            pending_messages=5,
            pending_by_priority={"routine": 5},
            peers_online_count=1,
            peers=[
                PeerSnapshot(
                    callsign="claude-code",
                    attention_state="needs_assignment",
                    attention_detail="Backup lane complete and ready for the next packet.",
                    trust_tier=3,
                )
            ],
        )
        action = infer_recommended_action(story)
        assert "Route next work" in action
        assert "claude-code" in action
        assert "Backup lane complete" in action

    def test_manual_wake_peer_assignment_requests_operator_nudge(self):
        story = ConnectionStory(
            agent_name="codex",
            peers_online_count=1,
            peers=[
                PeerSnapshot(
                    callsign="antigravity",
                    attention_state="needs_assignment",
                    attention_detail="Main and backup packets are complete.",
                    trust_tier=3,
                    wake_model="manual_wake",
                    operator_nudge_required=True,
                )
            ],
        )
        action = infer_recommended_action(story)
        assert "Route next work and nudge antigravity" in action
        assert "manual-wake" in action

    def test_captain_action_alert_outranks_peer_assignment_alert(self):
        story = ConnectionStory(
            agent_name="codex",
            pending_messages=4,
            pending_by_priority={"priority": 2, "routine": 2},
            peers_online_count=1,
            peers=[
                PeerSnapshot(
                    callsign="claude-code",
                    attention_state="needs_assignment",
                    attention_detail="Completed all 3 items in backup pull order. Ready for next slice.",
                    wake_model="manual_wake",
                    operator_nudge_required=True,
                )
            ],
            captain_action_alerts=[
                {
                    "sender": "claude-code",
                    "label": "completion + proposal",
                    "detail": "Completed all 3 items in backup pull order. Ready for next slice.",
                }
            ],
        )
        action = infer_recommended_action(story)
        assert "Review claude-code completion + proposal" in action
        assert "Route next work" not in action

    def test_blocked_waiting_for_review_surfaces_when_no_inbound_work(self):
        story = ConnectionStory(
            agent_name="test",
            blocked_waiting_for_review=1,
        )
        action = infer_recommended_action(story)
        assert "still open" in action

    def test_huddle_peers_outrank_generic_peers_online(self):
        story = ConnectionStory(
            agent_name="test",
            peers_online_count=2,
            peers=[
                PeerSnapshot(callsign="claude-code"),
                PeerSnapshot(callsign="antigravity"),
            ],
            huddle_peers=[
                HuddlePeer(
                    callsign="claude-code",
                    shared_workspaces=["Collaboration Runtime"],
                )
            ],
        )
        action = infer_recommended_action(story)
        assert "close huddle" in action
        assert "Collaboration Runtime" in action

    def test_messages_since_last_session(self):
        story = ConnectionStory(
            agent_name="test",
            pending_messages=0,
            since_last_seen=SinceLastSeen(messages_arrived=3),
        )
        action = infer_recommended_action(story)
        assert "3 message" in action
        assert "since last session" in action

    def test_peers_online_ready(self):
        story = ConnectionStory(
            agent_name="test",
            peers_online_count=2,
            peers=[
                PeerSnapshot(callsign="claude-code"),
                PeerSnapshot(callsign="antigravity"),
            ],
        )
        action = infer_recommended_action(story)
        assert "active collaboration" in action
        assert "claude-code" in action
        assert "antigravity" in action

    def test_peers_online_outrank_since_last_session_noise(self):
        story = ConnectionStory(
            agent_name="test",
            peers_online_count=1,
            peers=[PeerSnapshot(callsign="claude-code")],
            since_last_seen=SinceLastSeen(messages_arrived=37),
        )
        action = infer_recommended_action(story)
        assert "active collaboration" in action
        assert "claude-code" in action
        assert "since last session" not in action

    def test_no_pending_work(self):
        story = ConnectionStory(agent_name="test")
        action = infer_recommended_action(story)
        assert "Ready" in action


# ---------------------------------------------------------------------------
# Integration tests — real DB
# ---------------------------------------------------------------------------

class TestConnectionStoryIntegration:
    def test_fresh_agent_connection_story(self, temp_db):
        """A brand new agent gets a valid connection story."""
        client = WhispersClient("claude-code", db_path=temp_db)
        story = client.get_connection_story()

        assert story.agent_name == "claude-code"
        assert story.deployment_mode in ("standalone", "embedded")
        assert story.signal_mode == "OPEN"
        assert story.since_last_seen is not None
        # Client auto-registers which creates a last_seen, so this is
        # technically not a "first session" from the DB perspective.
        # The important thing is the story assembles without error.
        assert story.recommended_action is not None

    def test_connection_story_sees_peers(self, temp_db):
        """Connection story includes other registered agents that are online."""
        alice = WhispersClient("alice", db_path=temp_db)
        bob = WhispersClient("bob", db_path=temp_db)

        story = alice.get_connection_story()
        peer_names = [p.callsign for p in story.peers]
        # bob should be visible (registered, has presence)
        # Note: depends on whether bob has an active session — in embedded mode
        # both clients share the same DB and both have presence records
        assert story.agents_registered >= 2

    def test_connection_story_with_pending_messages(self, temp_db):
        """Pending messages show up in the connection story."""
        alice = WhispersClient("alice", db_path=temp_db)
        bob = WhispersClient("bob", db_path=temp_db)

        alice.send("bob", "Hello Bob", priority="priority")
        alice.send("bob", "Urgent!", priority="flash")

        story = bob.get_connection_story()
        assert story.pending_messages >= 2
        assert story.unread_flash >= 1
        assert "immediately" in story.recommended_action

    def test_status_surfaces_active_collaborator_reply_alerts(self, temp_db):
        alice = WhispersClient("alice", db_path=temp_db)
        bob = WhispersClient("bob", db_path=temp_db)

        original = alice.send("bob", "Initial request")
        bob.check_inbox(mark_seen=True)
        bob.send(
            "alice",
            "Re: Initial request",
            msg_type="checkpoint",
            reply_to=original["id"],
        )

        status = alice.status()
        assert status["active_reply_requests"] == 1
        assert status["active_reply_alerts"][0]["counterpart"] == "bob"
        assert "Re: Initial request" in status["active_reply_alerts"][0]["subject"]
        assert "Open hot reply from bob" in status["connection_story"]["recommended_action"]

    def test_status_surfaces_self_wake_model_and_jolt(self, temp_db):
        captain = WhispersClient("captain", db_path=temp_db, agent_type="assistant")
        peer = WhispersClient("peer", db_path=temp_db)

        original = captain.send("peer", "Review this packet")
        peer.check_inbox(mark_seen=True)
        peer.send(
            "captain",
            "Re: Review this packet",
            reply_to=original["id"],
        )

        status = captain.status()
        assert status["wake_model"] == "manual_wake"
        assert status["interruptibility"] == "free"
        assert status["jolt_packet"]["action"] == "notify"
        assert status["jolt_adapter"]["adapter_kind"] == "notify_only"
        assert status["jolt_host_capabilities"]["host_kind"] == "local_client"
        assert status["connection_story"]["wake_model"] == "manual_wake"
        assert status["connection_story"]["jolt_packet"]["action"] == "notify"
        assert status["connection_story"]["jolt_adapter"]["adapter_kind"] == "notify_only"
        assert status["connection_story"]["jolt"]["action"] == "notify"

    def test_status_cools_delayed_hot_reply_to_generic_unread(self, temp_db):
        captain = WhispersClient("captain", db_path=temp_db, agent_type="assistant")
        peer = WhispersClient("peer", db_path=temp_db)

        original = captain.send("peer", "Review this packet")
        peer.check_inbox(mark_seen=True)
        reply = peer.send(
            "captain",
            "Re: Review this packet",
            reply_to=original["id"],
        )

        with captain.db.get_connection() as conn:
            conn.execute(
                "UPDATE messages SET created_at = datetime('now', '-6 minutes') WHERE uuid = ?",
                (reply["id"],),
            )
            conn.commit()

        status = captain.status()

        assert status["pending_messages"] == 1
        assert status["jolt"]["action"] == "suppress"
        assert "jolt_packet" not in status
        assert status["connection_story"]["recommended_action"] == "Check inbox -- 1 unread message."
        assert status["connection_story"]["active_reply_requests"] == 1

    def test_status_surfaces_jolt_for_surface_now_actionable_unread(self, temp_db):
        captain = WhispersClient("captain", db_path=temp_db, agent_type="assistant")
        peer = WhispersClient("peer", db_path=temp_db)

        peer.send(
            "captain",
            "Please review this packet",
            body="Fresh actionable work should reach Jolt when surfaced now.",
            priority="routine",
            msg_type="request",
        )

        status = captain.status()

        assert status["pending_messages"] == 1
        assert status["pending_by_class"]["actionable"] == 1
        assert status["connection_story"]["attention_treatment"]["counts"]["surface_now"] == 1
        assert status["jolt_packet"]["action"] == "notify"
        assert status["jolt_packet"]["trigger"] == "direct_assignment"
        assert status["jolt_packet"]["headline"] == "peer: Please review this packet"
        assert status["jolt_packet"]["recommended_action"] == "Check inbox -- 1 unread message."

    def test_status_uses_explicit_jolt_staging_for_manual_wake_host(self, temp_db):
        captain = WhispersClient(
            "captain",
            db_path=temp_db,
            agent_type="assistant",
            jolt_host_kind="cursor",
            jolt_adapter_kind="native_extension",
            jolt_can_stage_context=True,
        )
        peer = WhispersClient("peer", db_path=temp_db)

        original = captain.send("peer", "Review this packet")
        peer.check_inbox(mark_seen=True)
        peer.send(
            "captain",
            "Re: Review this packet",
            reply_to=original["id"],
        )

        status = captain.status()
        assert status["jolt_packet"]["action"] == "stage_context"
        assert status["jolt_adapter"]["adapter_kind"] == "native_extension"
        assert status["jolt_adapter"]["supported_actions"] == ["notify", "stage_context"]
        assert status["jolt_host_capabilities"]["host_kind"] == "cursor"
        assert status["jolt_host_capabilities"]["can_stage_context"] is True
        assert status["jolt"]["action"] == "stage_context"
        assert status["connection_story"]["jolt"]["action"] == "stage_context"
        assert captain.get_jolt_packet(status_snapshot=status)["action"] == "stage_context"

    def test_status_uses_explicit_jolt_budget_for_listener_backed_host(self, temp_db):
        listener = WhispersClient(
            "listener",
            db_path=temp_db,
            agent_type="script",
            session_kind="local_listener",
            jolt_host_kind="listener",
            jolt_can_stage_context=True,
            jolt_can_trigger_inference=True,
            jolt_autonomous_inference_enabled=True,
            jolt_max_inferences_per_hour=4,
            jolt_cooldown_seconds=60,
            jolt_seconds_since_last_inference=120,
        )
        sender = WhispersClient("sender", db_path=temp_db)

        sender.send_assignment(
            "listener",
            objective="Own the host wake adapter packet.",
            deliverable="JOLT-HOST-ADAPTER-PACKET.md",
            requested_action="Draft the first supported-host adapter contract.",
            acceptance_bar="Concrete enough to implement.",
        )

        status = listener.status()
        assert status["wake_model"] == "listener_backed"
        assert status["jolt_packet"]["action"] == "infer"
        assert status["jolt_budget"]["autonomous_inference_enabled"] is True
        assert status["jolt_budget"]["max_inferences_per_hour"] == 4
        assert status["jolt"]["action"] == "infer"
        assert status["connection_story"]["jolt"]["action"] == "infer"

    def test_read_only_status_uses_active_session_jolt_adapter_contract(self, temp_db):
        zmaia = WhispersClient(
            "zmaia",
            db_path=temp_db,
            agent_type="assistant",
            session_kind="remote_http",
            jolt_host_kind="zmaia",
            jolt_adapter_kind="managed_pty",
            jolt_can_stage_context=True,
        )
        sender = WhispersClient("sender", db_path=temp_db)

        sender.send_assignment(
            "zmaia",
            objective="Own the host adapter contract.",
            deliverable="JOLT-ZMAIA-ADAPTER.md",
            requested_action="Wire the first supported-host adapter path.",
            acceptance_bar="Status truth shows the adapter contract.",
        )

        snapshot = WhispersClient(
            "zmaia",
            db_path=temp_db,
            read_only=True,
            assume_http_server_reachable=True,
        ).status()

        assert snapshot["wake_model"] == "manual_wake"
        assert snapshot["jolt_adapter"]["host_kind"] == "zmaia"
        assert snapshot["jolt_adapter"]["adapter_kind"] == "managed_pty"
        assert snapshot["jolt_adapter"]["supported_actions"] == ["notify", "stage_context"]
        assert snapshot["jolt_packet"]["action"] == "stage_context"
        assert snapshot["jolt"]["action"] == "stage_context"
        assert snapshot["connection_story"]["jolt_adapter"]["adapter_kind"] == "managed_pty"

    def test_status_surfaces_active_thread_watch_until_reply(self, temp_db):
        alice = WhispersClient("alice", db_path=temp_db)
        bob = WhispersClient("bob", db_path=temp_db)

        original = bob.send("alice", "Question for Alice")
        alice.check_inbox(mark_seen=True)
        follow_up = alice.send(
            "bob",
            "Re: Question for Alice",
            reply_to=original["id"],
        )

        before_read = alice.status()
        assert before_read["active_thread_watch_count"] == 1
        assert before_read["active_thread_watches"][0]["message_id"] == follow_up["id"]
        assert before_read["active_thread_watches"][0]["stage"] in {"awaiting_delivery", "awaiting_read"}
        assert "Stay hot on thread with bob" in before_read["connection_story"]["recommended_action"]

        bob.check_inbox(mark_seen=True)
        after_read = alice.status()
        assert after_read["active_thread_watch_count"] == 1
        assert after_read["active_thread_watches"][0]["stage"] == "awaiting_reply"
        assert after_read["active_thread_watches"][0]["age_label"] is not None

        bob.send(
            "alice",
            "Re: Question for Alice",
            reply_to=follow_up["id"],
        )
        after_reply = alice.status()
        assert after_reply["active_thread_watch_count"] == 0
        assert after_reply["active_reply_requests"] == 1

    def test_status_awaiting_read_age_anchors_to_delivery_time(self, temp_db):
        alice = WhispersClient("alice", db_path=temp_db)
        bob = WhispersClient("bob", db_path=temp_db)

        original = bob.send("alice", "Question for Alice")
        alice.check_inbox(mark_seen=True)
        follow_up = alice.send(
            "bob",
            "Re: Question for Alice",
            reply_to=original["id"],
        )

        with alice.db.get_connection() as conn:
            conn.execute(
                """
                UPDATE message_recipients
                SET claimed_at = datetime('now', '-2 minutes'),
                    read_at = NULL,
                    delivery_status = 'delivered'
                WHERE message_uuid = ?
                """,
                (follow_up["id"],),
            )
            conn.execute(
                "UPDATE messages SET created_at = datetime('now', '-10 minutes') WHERE uuid = ?",
                (follow_up["id"],),
            )
            conn.commit()

        status = alice.status()
        watch = status["active_thread_watches"][0]
        assert watch["stage"] == "awaiting_read"
        assert watch["stage_label"] == "delivered"
        assert watch["age_label"] == "2m"
        assert watch["stage_started_at"] is not None

    def test_status_drops_stale_awaiting_read_thread_pressure(self, temp_db):
        alice = WhispersClient("alice", db_path=temp_db)
        bob = WhispersClient("bob", db_path=temp_db)

        original = bob.send("alice", "Question for Alice")
        alice.check_inbox(mark_seen=True)
        follow_up = alice.send(
            "bob",
            "Re: Question for Alice",
            reply_to=original["id"],
        )

        with alice.db.get_connection() as conn:
            conn.execute(
                """
                UPDATE message_recipients
                SET claimed_at = datetime('now', '-6 minutes'),
                    read_at = NULL,
                    delivery_status = 'delivered'
                WHERE message_uuid = ?
                """,
                (follow_up["id"],),
            )
            conn.execute(
                "UPDATE messages SET created_at = datetime('now', '-10 minutes') WHERE uuid = ?",
                (follow_up["id"],),
            )
            conn.commit()

        status = alice.status()
        assert status["active_thread_watch_count"] == 0
        assert "Stay hot on thread with bob" not in status["connection_story"]["recommended_action"]

    def test_status_cools_stale_awaiting_reply_thread_pressure(self, temp_db):
        alice = WhispersClient("alice", db_path=temp_db)
        bob = WhispersClient("bob", db_path=temp_db)

        original = bob.send("alice", "Question for Alice")
        alice.check_inbox(mark_seen=True)
        follow_up = alice.send(
            "bob",
            "Re: Question for Alice",
            reply_to=original["id"],
        )
        bob.check_inbox(mark_seen=True)

        with alice.db.get_connection() as conn:
            conn.execute(
                """
                UPDATE message_recipients
                SET claimed_at = datetime('now', '-6 minutes'),
                    read_at = datetime('now', '-6 minutes'),
                    delivery_status = 'read'
                WHERE message_uuid = ?
                """,
                (follow_up["id"],),
            )
            conn.execute(
                "UPDATE messages SET created_at = datetime('now', '-10 minutes') WHERE uuid = ?",
                (follow_up["id"],),
            )
            conn.commit()

        status = alice.status()
        assert status["active_thread_watch_count"] == 1
        assert status["active_thread_watches"][0]["stage"] == "awaiting_reply"
        assert status["jolt"]["action"] == "suppress"
        assert "jolt_packet" not in status
        assert "Stay hot on thread with bob" not in status["connection_story"]["recommended_action"]

    def test_status_ignores_self_addressed_reply_and_thread_pressure(self, temp_db):
        alice = WhispersClient("alice", db_path=temp_db)

        alice.send(
            "alice",
            "Re: Self cleanup note",
            reply_to="self-thread",
            msg_type="inform",
            priority="priority",
        )

        status = alice.status()
        assert status["pending_messages"] == 1
        assert status["active_reply_requests"] == 0
        assert status["active_thread_watch_count"] == 0

    def test_status_ignores_accept_replies_for_hot_thread_pressure(self, temp_db):
        alice = WhispersClient("alice", db_path=temp_db)
        bob = WhispersClient("bob", db_path=temp_db)

        original = bob.send("alice", "Question for Alice")
        alice.check_inbox(mark_seen=True)
        alice.send(
            "bob",
            "Re: Question for Alice",
            reply_to=original["id"],
            msg_type="accept",
            priority="routine",
        )

        status = alice.status()
        assert status["active_thread_watch_count"] == 0
        assert "Stay hot on thread with bob" not in status["connection_story"]["recommended_action"]

    def test_status_ignores_outbound_baton_admin_updates_for_hot_thread_pressure(self, temp_db):
        alice = WhispersClient("alice", db_path=temp_db)
        bob = WhispersClient("bob", db_path=temp_db)

        handoff = alice.send_handoff(
            "bob",
            objective="Finish the queue cleanup",
            deliverable="queue hygiene patch",
            completed="Truth-floor analysis is in.",
            remaining="Land the cleanup patch and proof.",
            next_action="Ship the queue hygiene patch.",
            human_summary="Take the queue hygiene patch over the line.",
        )
        bob.baton_ack(handoff["id"], "accepted", reason="Patch is underway")

        alice.baton_update(handoff["id"], "in_progress", progress="Patch is under active review")
        after_update = alice.status()
        assert after_update["active_thread_watch_count"] == 0

        alice.baton_close(handoff["id"], "superseded", summary="Superseded by a broader lane split")
        after_close = alice.status()
        assert after_close["active_thread_watch_count"] == 0
        assert "Stay hot on thread" not in after_close["connection_story"]["recommended_action"]

    def test_briefing_surfaces_delivery_based_hot_thread_age(self):
        story = ConnectionStory(
            agent_name="codex",
            active_thread_watches=[
                ActiveThreadWatch(
                    message_id="msg-hot-delivered",
                    counterpart="antigravity",
                    subject="Re: baton truth",
                    stage="awaiting_read",
                    stage_label="delivered",
                    age_label="2m",
                )
            ],
        )
        capsule = build_briefing_capsule(story)
        assert "waiting on antigravity to read" in capsule["detail_block"]
        assert "delivered 2m ago" in capsule["detail_block"]

    def test_connection_story_surfaces_structured_assignment(self, temp_db):
        sender = WhispersClient("claude-code", db_path=temp_db)
        recipient = WhispersClient("codex", db_path=temp_db)

        sender.send_assignment(
            "codex",
            objective="Own the proof packet tranche.",
            deliverable="proof packet",
            requested_action="Draft and pressure-test the proof packet.",
            acceptance_bar="Implementation-ready and specific.",
            backup_pull_order=["Pressure-test edge cases", "Tighten acceptance bars"],
        )

        story = recipient.get_connection_story()

        assert story.pending_assignments == 1
        assert story.coordination_highlights
        assert story.coordination_highlights[0].kind == "assignment"
        assert "Start assignment" in story.recommended_action

    def test_assignment_persists_after_inbox_read_until_done(self, temp_db):
        sender = WhispersClient("claude-code", db_path=temp_db)
        recipient = WhispersClient("codex", db_path=temp_db)

        result = sender.send_assignment(
            "codex",
            objective="Own the proof packet tranche.",
            deliverable="proof packet",
            requested_action="Draft and pressure-test the proof packet.",
        )

        recipient.check_inbox(limit=10, mark_seen=True)
        still_pending = recipient.get_connection_story()
        assert still_pending.pending_assignments == 1

        recipient.mark_done(result["id"])
        cleared = recipient.get_connection_story()
        assert cleared.pending_assignments == 0

    def test_blocking_review_wait_stays_open_after_ack(self, temp_db):
        sender = WhispersClient("antigravity", db_path=temp_db)
        reviewer = WhispersClient("codex", db_path=temp_db)

        result = sender.request_review(
            "codex",
            artifact="P2 dissent plan",
            question="Approve or redirect the implementation plan.",
            blocking=True,
        )

        before = sender.get_connection_story()
        assert before.blocked_waiting_for_review == 1

        reviewer.acknowledge_message(result["id"], "processed", detail="Review picked up.")

        after = sender.get_connection_story()
        assert after.blocked_waiting_for_review == 1
        assert after.coordination_highlights[0].coordination_status == "acknowledged"

    def test_blocking_review_wait_clears_after_reply(self, temp_db):
        sender = WhispersClient("antigravity", db_path=temp_db)
        reviewer = WhispersClient("codex", db_path=temp_db)

        result = sender.request_review(
            "codex",
            artifact="P2 dissent plan",
            question="Approve or redirect the implementation plan.",
            blocking=True,
        )

        before_sender = sender.get_connection_story()
        before_reviewer = reviewer.get_connection_story()
        assert before_sender.blocked_waiting_for_review == 1
        assert before_reviewer.pending_review_requests == 1

        reviewer.send(
            "antigravity",
            "Re: P2 dissent plan",
            body="Approved. Proceed with the implementation.",
            reply_to=result["id"],
        )

        after_sender = sender.get_connection_story()
        after_reviewer = reviewer.get_connection_story()
        assert after_sender.blocked_waiting_for_review == 0
        assert after_sender.answered_waiting_to_close == 1
        assert "Open hot reply" in after_sender.recommended_action
        assert after_reviewer.pending_review_requests == 0

    def test_blocking_review_age_surfaces_in_connection_story(self, temp_db):
        sender = WhispersClient("antigravity", db_path=temp_db)
        reviewer = WhispersClient("codex", db_path=temp_db)

        result = sender.request_review(
            "codex",
            artifact="listener plan",
            question="Approve or redirect the listener plan.",
            blocking=True,
        )

        with reviewer.db.get_connection() as conn:
            conn.execute(
                "UPDATE messages SET created_at = datetime('now', '-12 minutes') WHERE uuid = ?",
                (result["id"],),
            )
            conn.commit()

        story = reviewer.get_connection_story()
        capsule = build_briefing_capsule(story)

        assert "12m waiting" in story.recommended_action
        assert "blocking 12m waiting" in capsule["detail_block"]

    def test_connection_story_surfaces_baton_counts(self, temp_db):
        sender = WhispersClient("claude-code", db_path=temp_db)
        recipient = WhispersClient("codex", db_path=temp_db)

        sent = sender.send_handoff(
            "codex",
            objective="Design notification runtime",
            deliverable="NOTIFICATION-SCHEMA-PACKET.md",
            completed="Design packet drafted.",
            remaining="Turn the packet into an implementation-ready schema note.",
            next_action="Write NOTIFICATION-SCHEMA-PACKET.md",
            workspace_id="ws_notification_design",
            human_summary="Turn the notification design into the schema packet.",
        )

        assert sent["status"] == "delivered"

        recipient_story = recipient.get_connection_story()
        sender_story = sender.get_connection_story()

        assert recipient_story.incoming_batons >= 1
        assert "BATON state" in recipient_story.recommended_action
        assert sender_story.carrying_batons >= 1

    def test_connection_story_surfaces_huddle_peers_from_status(self, temp_db):
        alice = WhispersClient("alice", db_path=temp_db)
        bob = WhispersClient("bob", db_path=temp_db)

        created = alice.create_workspace(
            purpose="Keep the collaboration runtime huddle visible.",
            name="Collaboration Runtime",
            members=["bob"],
        )
        workspace_id = created["workspace_id"]
        bob.join_workspace(workspace_id)
        alice.send_handoff(
            "bob",
            objective="Finish the huddle surface",
            deliverable="connection story update",
            completed="Runtime contract drafted.",
            remaining="Ship the startup surface and tests.",
            next_action="Implement the huddle status payload.",
            workspace_id=workspace_id,
            human_summary="Pick up the huddle status payload and finish the visible surface.",
        )

        status = bob.status()
        story = bob.get_connection_story(status_snapshot=status)

        assert status["huddle_peers"]
        assert status["huddle_peers"][0]["agent_name"] == "alice"
        assert status["huddle_peers"][0]["shared_workspaces"] == ["Collaboration Runtime"]
        assert status["huddle_peers"][0]["incoming_baton_from_peer"] is True
        assert story.huddle_peers
        assert story.huddle_peers[0].callsign == "alice"
        assert story.huddle_peers[0].shared_workspaces == ["Collaboration Runtime"]
        assert "BATON state" in story.recommended_action
        assert "Huddle nearby: alice [ready] | workspace Collaboration Runtime | ← [🟨 BATON x1]" in build_briefing_capsule(story)["detail_block"]

    def test_briefing_capsule_from_client(self, temp_db):
        """get_briefing_capsule() returns a valid capsule dict."""
        client = WhispersClient("claude-code", db_path=temp_db)
        capsule = client.get_briefing_capsule()

        assert "status_line" in capsule
        assert "claude-code" in capsule["status_line"]
        assert "must_present_block" in capsule
        assert "detail_block" in capsule
        assert capsule["resource_uri"] == "whispers://status"

    def test_connection_story_to_dict_roundtrip(self, temp_db):
        """Connection story serializes to dict cleanly."""
        client = WhispersClient("claude-code", db_path=temp_db)
        story = client.get_connection_story()
        d = story.to_dict()

        assert isinstance(d, dict)
        assert d["agent_name"] == "claude-code"
        assert isinstance(d["peers"], list)
        assert "whispers_version" in d
        assert "schema_version" in d

    def test_connection_story_server_context_skips_http_probe(self, temp_db, monkeypatch):
        """HTTP-transport MCP sessions should not probe the server they are already inside."""
        client = WhispersClient(
            "cursor",
            db_path=temp_db,
            agent_type="mcp_server",
            assume_http_server_reachable=True,
        )

        def _unexpected_probe(*args, **kwargs):
            raise AssertionError("status() should not probe HTTP from server-side MCP context")

        monkeypatch.setattr(client_module, "_probe_http_server", _unexpected_probe)

        story = client.get_connection_story()

        assert story.http_server_reachable is True

    def test_connection_story_can_use_precomputed_status_snapshot(self, temp_db, monkeypatch):
        """Startup paths can reuse one status snapshot instead of recomputing it."""
        client = WhispersClient("claude-code", db_path=temp_db)
        snapshot = client.status()

        monkeypatch.setattr(client, "status", lambda: (_ for _ in ()).throw(AssertionError("status() should not be called")))

        story = client.get_connection_story(status_snapshot=snapshot)

        assert story.agent_name == "claude-code"


# ---------------------------------------------------------------------------
# Baton detail operator truth tests
# ---------------------------------------------------------------------------


class TestBatonDetailDataModel:
    def test_baton_detail_to_dict(self):
        baton = BatonDetail(
            baton_ref="abc-123",
            counterpart="antigravity",
            direction="incoming",
            state="offered",
            label="Build operator truth layers",
        )
        d = baton.to_dict()
        assert d["baton_ref"] == "abc-123"
        assert d["counterpart"] == "antigravity"
        assert d["direction"] == "incoming"
        assert d["state"] == "offered"
        assert d["label"] == "Build operator truth layers"

    def test_baton_detail_omits_none(self):
        baton = BatonDetail(baton_ref="abc", counterpart="codex")
        d = baton.to_dict()
        assert "last_update" not in d
        assert "workspace_id" not in d

    def test_baton_detail_in_connection_story(self):
        story = ConnectionStory(
            agent_name="claude-code",
            baton_details=[
                BatonDetail(
                    baton_ref="b1",
                    counterpart="antigravity",
                    direction="incoming",
                    state="offered",
                    label="Build tests",
                ),
            ],
        )
        d = story.to_dict()
        assert len(d["baton_details"]) == 1
        assert d["baton_details"][0]["counterpart"] == "antigravity"


class TestBatonDetailRendering:
    def test_render_empty(self):
        assert _render_baton_detail_lines([]) == []

    def test_render_incoming_offered(self):
        batons = [
            BatonDetail(
                baton_ref="b1",
                counterpart="antigravity",
                direction="incoming",
                state="offered",
                label="Build operator truth",
            )
        ]
        lines = _render_baton_detail_lines(batons)
        assert len(lines) == 1
        assert "\u2190" in lines[0]  # ← arrow
        assert "antigravity" in lines[0]
        assert "waiting for ack" in lines[0]
        assert "Build operator truth" in lines[0]

    def test_render_outgoing_in_progress(self):
        batons = [
            BatonDetail(
                baton_ref="b2",
                counterpart="codex",
                direction="outgoing",
                state="in_progress",
                label="Align MCP tools",
                last_update="Schema alignment complete, testing now",
            )
        ]
        lines = _render_baton_detail_lines(batons)
        assert len(lines) == 1
        assert "\u2192" in lines[0]  # → arrow
        assert "codex" in lines[0]
        assert "in progress" in lines[0]
        assert "Schema alignment complete" in lines[0]

    def test_render_blocked_baton(self):
        batons = [
            BatonDetail(
                baton_ref="b3",
                counterpart="antigravity",
                direction="incoming",
                state="blocked",
                label="Listener infrastructure",
            )
        ]
        lines = _render_baton_detail_lines(batons)
        assert "BLOCKED" in lines[0]

    def test_render_truncates_at_max_lines(self):
        batons = [
            BatonDetail(baton_ref=f"b{i}", counterpart=f"agent{i}", label=f"task {i}")
            for i in range(6)
        ]
        lines = _render_baton_detail_lines(batons, max_lines=4)
        assert len(lines) == 5  # 4 detail + 1 overflow
        assert "+2 more active batons" in lines[4]


class TestBatonDetailInBriefing:
    def test_briefing_capsule_includes_baton_details(self):
        story = ConnectionStory(
            agent_name="claude-code",
            incoming_batons=1,
            baton_details=[
                BatonDetail(
                    baton_ref="b1",
                    counterpart="antigravity",
                    direction="incoming",
                    state="offered",
                    label="Build operator truth layers",
                ),
            ],
        )
        capsule = build_briefing_capsule(story)
        assert len(capsule["baton_details"]) == 1
        assert capsule["baton_details"][0]["counterpart"] == "antigravity"
        # Detail lines should appear in the detail_block text
        assert "antigravity" in capsule["detail_block"]
        assert "waiting for ack" in capsule["detail_block"]

    def test_briefing_capsule_no_batons(self):
        story = ConnectionStory(agent_name="claude-code")
        capsule = build_briefing_capsule(story)
        assert capsule["baton_details"] == []
        assert "BATON state" not in capsule["detail_block"]


class TestBatonDetailInRecommendedAction:
    def test_incoming_baton_names_counterpart(self):
        story = ConnectionStory(
            agent_name="claude-code",
            incoming_batons=1,
            baton_details=[
                BatonDetail(
                    baton_ref="b1",
                    counterpart="antigravity",
                    direction="incoming",
                    state="offered",
                    label="Build operator truth layers",
                ),
            ],
        )
        action = infer_recommended_action(story)
        assert "antigravity" in action
        assert "Build operator truth layers" in action

    def test_carrying_baton_names_counterpart(self):
        story = ConnectionStory(
            agent_name="claude-code",
            carrying_batons=1,
            baton_details=[
                BatonDetail(
                    baton_ref="b2",
                    counterpart="codex",
                    direction="outgoing",
                    state="in_progress",
                    label="Align MCP tools",
                ),
            ],
        )
        action = infer_recommended_action(story)
        assert "codex" in action
        assert "Align MCP tools" in action
        assert "in progress" in action

    def test_fallback_when_no_details(self):
        story = ConnectionStory(
            agent_name="claude-code",
            incoming_batons=2,
        )
        action = infer_recommended_action(story)
        assert "2 incoming batons" in action
