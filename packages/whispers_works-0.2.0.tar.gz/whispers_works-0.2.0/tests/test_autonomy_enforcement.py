"""Tests for variable autonomy enforcement.

Covers:
- Action classification from message types and schemas
- Policy check: allowed, denied, shadow mode
- No policy = allowed (open by default)
- Policy exists but action not in policy = allowed
- Dispatcher integration: denied actions are dead-lettered
- Shadow mode: allowed but logged
"""

import json
import pytest
from whispers.autonomy_enforcement import classify_action, check_autonomy


class TestClassifyAction:
    def test_reply_types(self):
        assert classify_action("reply") == "reply"
        assert classify_action("inform") == "reply"
        assert classify_action("note") == "reply"
        assert classify_action("accept") == "reply"
        assert classify_action("reject") == "reply"

    def test_external_action_from_schema(self):
        payload = {"schema": "external_action_request.v1"}
        assert classify_action("inform", payload) == "external_action"

    def test_checkpoint_is_summarize(self):
        assert classify_action("checkpoint") == "summarize"

    def test_unknown_type_returns_none(self):
        assert classify_action("handoff") is None
        assert classify_action("system") is None

    def test_schema_takes_precedence(self):
        # Even if msg_type maps to "reply", schema overrides
        payload = {"schema": "external_action_request.v1"}
        assert classify_action("reply", payload) == "external_action"

    def test_string_payload_parsed(self):
        payload = json.dumps({"schema": "external_action_request.v1"})
        assert classify_action("inform", payload) == "external_action"


class TestCheckAutonomy:
    @pytest.fixture
    def setup(self, tmp_path):
        from whispers.storage.db import WhispersDB

        db_path = str(tmp_path / "test_autonomy.db")
        db = WhispersDB(db_path=db_path)

        # Register agent
        with db.get_connection() as conn:
            conn.execute(
                "INSERT INTO agent_cards (agent_id, callsign, agent_type, trust_tier, registered_at) VALUES (?, ?, ?, ?, datetime('now'))",
                ("worker", "worker", "llm", 1),
            )
            conn.commit()
        return db

    def test_no_policy_allows_everything(self, setup):
        db = setup
        result = check_autonomy(db, "worker", "reply", "ws_test")
        assert result["allowed"] is True

    def test_policy_allows_permitted_action(self, setup):
        db = setup
        db.set_autonomy_policy("worker", "ws_test", {
            "can_summarize": True,
            "can_classify": True,
            "can_reply": True,
            "can_external_action": False,
        })
        result = check_autonomy(db, "worker", "reply", "ws_test")
        assert result["allowed"] is True

    def test_policy_denies_unpermitted_action(self, setup):
        db = setup
        db.set_autonomy_policy("worker", "ws_test", {
            "can_summarize": True,
            "can_classify": True,
            "can_reply": True,
            "can_external_action": False,
        })
        result = check_autonomy(db, "worker", "external_action", "ws_test")
        assert result["allowed"] is False
        assert "blocked" in result["reason"]

    def test_shadow_mode_allows_but_flags(self, setup):
        db = setup
        db.set_autonomy_policy("worker", "ws_test", {
            "can_summarize": True,
            "can_classify": True,
            "can_reply": True,
            "can_external_action": True,
            "shadow_mode": True,
        })
        result = check_autonomy(db, "worker", "reply", "ws_test")
        assert result["allowed"] is True
        assert result["shadow"] is True

    def test_no_scope_with_no_policy_allows(self, setup):
        db = setup
        result = check_autonomy(db, "worker", "reply")
        assert result["allowed"] is True

    def test_different_scope_no_policy_allows(self, setup):
        db = setup
        db.set_autonomy_policy("worker", "ws_alpha", {
            "can_reply": True,
            "can_external_action": False,
        })
        # Different scope — no policy for ws_beta
        result = check_autonomy(db, "worker", "external_action", "ws_beta")
        assert result["allowed"] is True


class TestDispatcherIntegration:
    @pytest.fixture
    def setup(self, tmp_path):
        from whispers.storage.db import WhispersDB
        from whispers.client import WhispersClient

        db_path = str(tmp_path / "test_dispatch.db")
        db = WhispersDB(db_path=db_path)

        with db.get_connection() as conn:
            conn.execute(
                "INSERT INTO agent_cards (agent_id, callsign, agent_type, trust_tier, registered_at) VALUES (?, ?, ?, ?, datetime('now'))",
                ("restricted", "restricted", "llm", 1),
            )
            conn.execute(
                "INSERT INTO agent_cards (agent_id, callsign, agent_type, trust_tier, registered_at) VALUES (?, ?, ?, ?, datetime('now'))",
                ("receiver", "receiver", "llm", 1),
            )
            conn.commit()

        restricted = WhispersClient("restricted", db_path=db_path)
        receiver = WhispersClient("receiver", db_path=db_path)
        return db, restricted, receiver

    def test_denied_action_dead_lettered(self, setup):
        db, restricted, receiver = setup
        # Set policy: can reply but NOT external_action
        db.set_autonomy_policy("restricted", "ws_locked", {
            "can_reply": True,
            "can_external_action": False,
        })
        # Send an external action request with working_scope
        result = restricted.send(
            "receiver",
            "External action",
            body="Do something dangerous",
            msg_type="inform",
            payload={"schema": "external_action_request.v1", "intent": "delete stuff"},
            metadata={"whispers:working_scope": "ws_locked"},
        )
        # Should be dead-lettered
        assert result.get("status") == "dead_lettered" or result.get("dead_letter_reason")

    def test_allowed_action_delivers(self, setup):
        db, restricted, receiver = setup
        db.set_autonomy_policy("restricted", "ws_open", {
            "can_reply": True,
            "can_external_action": True,
        })
        result = restricted.send(
            "receiver",
            "Normal reply",
            body="Hello",
            msg_type="inform",
            metadata={"whispers:working_scope": "ws_open"},
        )
        # Should deliver normally
        assert result.get("status") != "dead_lettered"

    def test_shadow_mode_delivers_and_logs(self, setup):
        db, restricted, receiver = setup
        db.set_autonomy_policy("restricted", "ws_shadow", {
            "can_reply": True,
            "can_external_action": True,
            "shadow_mode": True,
        })
        result = restricted.send(
            "receiver",
            "Shadow reply",
            body="Being watched",
            msg_type="inform",
            metadata={"whispers:working_scope": "ws_shadow"},
        )
        assert result.get("status") != "dead_lettered"
        # Check for shadow security event
        with db.get_readonly_connection() as conn:
            events = conn.execute(
                "SELECT * FROM security_events WHERE event_type = 'autonomy_shadow' AND actor_agent = 'restricted'"
            ).fetchall()
        assert len(events) >= 1
