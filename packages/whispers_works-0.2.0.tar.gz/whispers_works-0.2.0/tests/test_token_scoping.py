"""Token scoping tests — verify scope enforcement across all endpoints.

Tests cover:
- Schema migration (scopes column added to existing DBs)
- Token issuance with explicit scopes, profiles, and defaults
- Scope enforcement on every authenticated endpoint
- Wildcard scope matching (messages:*, admin:*, *)
- Backward compatibility (tokens without scopes get full access)
- Token rotation preserves scopes
- Security event logging for scope violations
"""

import importlib
import json
import pytest
from whispers.storage.db import WhispersDB, WhispersDBError


# ---------------------------------------------------------------------------
# DB-level scope tests
# ---------------------------------------------------------------------------


class TestTokenScopesDB:
    """Test scope support in WhispersDB."""

    @pytest.fixture(autouse=True)
    def setup(self, temp_db):
        self.db = WhispersDB(temp_db)

    def test_default_scopes_are_full_access(self):
        """Tokens issued without explicit scopes should get ["*"]."""
        token = self.db.issue_api_token("agent-a", description="default")
        row = self.db.get_api_token(token)
        assert row is not None
        scopes = json.loads(row["scopes"])
        assert scopes == ["*"]

    def test_explicit_scopes(self):
        """Tokens can be issued with specific scopes."""
        token = self.db.issue_api_token(
            "agent-b",
            scopes=["messages:send", "presence:read"],
        )
        row = self.db.get_api_token(token)
        scopes = json.loads(row["scopes"])
        assert set(scopes) == {"messages:send", "presence:read"}

    def test_profile_external_agent(self):
        """The 'external-agent' profile issues messaging + read scopes."""
        token = self.db.issue_api_token("agent-c", profile="external-agent")
        row = self.db.get_api_token(token)
        scopes = json.loads(row["scopes"])
        assert "messages:send" in scopes
        assert "messages:read" in scopes
        assert "presence:read" in scopes
        assert "agents:read" in scopes
        assert "*" not in scopes
        assert "tokens:manage" not in scopes
        assert "admin:*" not in scopes

    def test_profile_operator(self):
        """The 'operator' profile gives full access."""
        token = self.db.issue_api_token("agent-d", profile="operator")
        row = self.db.get_api_token(token)
        scopes = json.loads(row["scopes"])
        assert scopes == ["*"]

    def test_profile_read_only(self):
        """The 'read-only' profile gives read-only access."""
        token = self.db.issue_api_token("agent-e", profile="read-only")
        row = self.db.get_api_token(token)
        scopes = json.loads(row["scopes"])
        assert "messages:read" in scopes
        assert "presence:read" in scopes
        assert "agents:read" in scopes
        assert "messages:send" not in scopes

    def test_explicit_scopes_override_profile(self):
        """Explicit scopes take priority over profile."""
        token = self.db.issue_api_token(
            "agent-f",
            scopes=["messages:send"],
            profile="operator",  # this should be ignored
        )
        row = self.db.get_api_token(token)
        scopes = json.loads(row["scopes"])
        assert scopes == ["messages:send"]

    def test_invalid_scope_rejected(self):
        """Unknown scope names should be rejected."""
        with pytest.raises(WhispersDBError, match="Invalid scopes"):
            self.db.issue_api_token("agent-g", scopes=["totally:fake"])

    def test_invalid_profile_rejected(self):
        """Unknown profile names should be rejected."""
        with pytest.raises(WhispersDBError, match="Unknown token profile"):
            self.db.issue_api_token("agent-h", profile="nonexistent")

    def test_list_tokens_includes_scopes(self):
        """list_api_tokens should return parsed scope lists."""
        self.db.issue_api_token("agent-i", scopes=["messages:send"])
        self.db.issue_api_token("agent-i", description="full")
        tokens = self.db.list_api_tokens("agent-i")
        assert len(tokens) == 2
        for t in tokens:
            assert isinstance(t["scopes"], list)

    def test_scopes_sorted_in_storage(self):
        """Scopes should be stored in sorted order for consistency."""
        token = self.db.issue_api_token(
            "agent-j",
            scopes=["presence:read", "agents:read", "messages:send"],
        )
        row = self.db.get_api_token(token)
        scopes = json.loads(row["scopes"])
        assert scopes == sorted(scopes)


# ---------------------------------------------------------------------------
# Server-level scope enforcement tests
# ---------------------------------------------------------------------------


class TestTokenScopesServer:
    """Test scope enforcement in HTTP endpoints."""

    @pytest.fixture(autouse=True)
    def setup(self, temp_db, monkeypatch):
        monkeypatch.setenv("WHISPERS_DB_PATH", temp_db)
        import whispers.server as server_module
        from fastapi.testclient import TestClient

        server_module = importlib.reload(server_module)

        self.db = server_module.db
        self.app = server_module.app
        self.client = TestClient(server_module.app)
        self._parse_token_scopes = server_module._parse_token_scopes
        self._require_scope = server_module._require_scope

        # Register an external test agent with scoped token
        server_module._server_client.registry.register("scoped-agent", agent_type="test")
        self.scoped_token = self.db.issue_api_token(
            "scoped-agent",
            profile="external-agent",
            description="test-scoped",
        )
        # Create a remote session for the scoped token
        self.db.create_remote_session(
            "scoped-agent",
            self.scoped_token,
            client_name="test",
            lease_seconds=300,
        )

        # Also register a full-access agent
        server_module._server_client.registry.register("full-agent", agent_type="test")
        self.full_token = self.db.issue_api_token(
            "full-agent",
            description="test-full",
        )
        self.db.create_remote_session(
            "full-agent",
            self.full_token,
            client_name="test",
            lease_seconds=300,
        )

    def _auth(self, token):
        return {"Authorization": f"Bearer {token}"}

    # --- scope parsing tests ---

    def test_parse_scopes_from_json_string(self):
        row = {"scopes": '["messages:send", "presence:read"]'}
        assert set(self._parse_token_scopes(row)) == {"messages:send", "presence:read"}

    def test_parse_scopes_none_gets_full_access(self):
        row = {"scopes": None}
        assert self._parse_token_scopes(row) == ["*"]

    def test_parse_scopes_missing_key_gets_full_access(self):
        row = {}
        assert self._parse_token_scopes(row) == ["*"]

    def test_parse_scopes_list_passthrough(self):
        row = {"scopes": ["messages:send"]}
        assert self._parse_token_scopes(row) == ["messages:send"]

    # --- scope enforcement unit tests ---

    def test_require_scope_passes_with_wildcard(self):
        """Token with ["*"] should pass any scope check."""
        row = {"scopes": '["*"]', "agent_name": "test"}
        self._require_scope(row, "messages:send", "tokens:manage", endpoint="test")

    def test_require_scope_passes_with_exact_match(self):
        row = {"scopes": '["messages:send"]', "agent_name": "test"}
        self._require_scope(row, "messages:send", endpoint="test")

    def test_require_scope_passes_with_resource_wildcard(self):
        """messages:* should cover messages:send."""
        row = {"scopes": '["messages:*"]', "agent_name": "test"}
        self._require_scope(row, "messages:send", endpoint="test")

    def test_require_scope_passes_with_admin_wildcard(self):
        """admin:* should cover everything."""
        row = {"scopes": '["admin:*"]', "agent_name": "test"}
        self._require_scope(row, "messages:send", endpoint="test")

    def test_require_scope_fails_without_scope(self):
        from fastapi import HTTPException
        row = {"scopes": '["messages:read"]', "agent_name": "test", "token_id": "t1"}
        with pytest.raises(HTTPException) as exc_info:
            self._require_scope(row, "messages:send", endpoint="test")
        assert exc_info.value.status_code == 403
        assert "messages:send" in str(exc_info.value.detail)

    # --- endpoint integration tests ---

    def test_scoped_token_can_read_inbox(self):
        """External-agent profile includes messages:read → inbox should work."""
        r = self.client.get("/inbox", headers=self._auth(self.scoped_token))
        assert r.status_code == 200

    def test_scoped_token_can_read_presence(self):
        """External-agent profile includes presence:read → presence should work."""
        r = self.client.get("/presence", headers=self._auth(self.scoped_token))
        assert r.status_code == 200

    def test_scoped_token_can_read_presence_policy(self):
        """External-agent profile includes presence:read → presence-policy should work."""
        r = self.client.get("/presence-policy", headers=self._auth(self.scoped_token))
        assert r.status_code == 200
        body = r.json()
        assert body["agent_name"] == "scoped-agent"
        assert body["visibility_posture"] == "visible"

    def test_scoped_token_can_update_presence_policy(self):
        """Presence policy is part of the presence control surface for the authenticated agent."""
        r = self.client.post(
            "/presence-policy",
            json={"visibility_posture": "appear_offline", "notification_policy": "direct_only"},
            headers=self._auth(self.scoped_token),
        )
        assert r.status_code == 200
        body = r.json()
        assert body["agent_name"] == "scoped-agent"
        assert body["visibility_posture"] == "appear_offline"
        assert body["notification_policy"] == "direct_only"

    def test_token_without_presence_scope_cannot_update_presence_policy(self):
        """Mutating presence policy requires the same presence scope as the rest of the presence surface."""
        limited_token = self.db.issue_api_token(
            "scoped-agent",
            scopes=["messages:send"],
            description="send-only",
        )
        self.db.create_remote_session(
            "scoped-agent",
            limited_token,
            client_name="test",
            lease_seconds=300,
        )
        r = self.client.post(
            "/presence-policy",
            json={"visibility_posture": "appear_offline"},
            headers=self._auth(limited_token),
        )
        assert r.status_code == 403
        assert "presence:read" in r.json()["detail"]

    def test_scoped_token_cannot_read_another_agents_presence_policy(self):
        """Cross-agent reads stay closed until trusted/operator visibility rules exist."""
        r = self.client.get("/presence-policy/full-agent", headers=self._auth(self.scoped_token))
        assert r.status_code == 403
        assert "not available yet" in r.json()["detail"]

    def test_scoped_token_can_read_agents(self):
        """External-agent profile includes agents:read → agents should work."""
        r = self.client.get("/agents", headers=self._auth(self.scoped_token))
        assert r.status_code == 200

    def test_scoped_token_cannot_create_tokens(self):
        """External-agent profile does NOT include tokens:manage → 403."""
        r = self.client.post(
            "/token:create",
            json={"description": "sneaky"},
            headers=self._auth(self.scoped_token),
        )
        assert r.status_code == 403
        assert "tokens:manage" in r.json()["detail"]

    def test_scoped_token_cannot_revoke_tokens(self):
        """External-agent profile does NOT include tokens:manage → 403."""
        r = self.client.post(
            "/token:revoke",
            json={"token": self.scoped_token},
            headers=self._auth(self.scoped_token),
        )
        assert r.status_code == 403

    def test_scoped_token_cannot_rename(self):
        """External-agent profile does NOT include agents:write → 403."""
        r = self.client.post(
            "/rename",
            json={"new_callsign": "hacker"},
            headers=self._auth(self.scoped_token),
        )
        assert r.status_code == 403

    def test_full_token_can_create_tokens(self):
        """Full-access token (["*"]) should pass token:create."""
        r = self.client.post(
            "/token:create",
            json={"description": "legit"},
            headers=self._auth(self.full_token),
        )
        assert r.status_code == 200

    def test_full_token_can_read_inbox(self):
        """Full-access token should pass inbox."""
        r = self.client.get("/inbox", headers=self._auth(self.full_token))
        assert r.status_code == 200

    def test_create_token_with_scopes_via_api(self):
        """POST /token:create should accept scopes param."""
        r = self.client.post(
            "/token:create",
            json={
                "description": "scoped-new",
                "scopes": ["messages:send"],
            },
            headers=self._auth(self.full_token),
        )
        assert r.status_code == 200
        new_token = r.json()["token"]
        row = self.db.get_api_token(new_token)
        assert json.loads(row["scopes"]) == ["messages:send"]

    def test_create_token_with_profile_via_api(self):
        """POST /token:create should accept profile param."""
        r = self.client.post(
            "/token:create",
            json={
                "description": "profiled",
                "profile": "read-only",
            },
            headers=self._auth(self.full_token),
        )
        assert r.status_code == 200
        new_token = r.json()["token"]
        row = self.db.get_api_token(new_token)
        scopes = json.loads(row["scopes"])
        assert "messages:read" in scopes
        assert "messages:send" not in scopes

    def test_scope_violation_logged_as_security_event(self):
        """Scope violations should be recorded in security_events."""
        # Trigger a scope violation
        self.client.post(
            "/token:create",
            json={"description": "sneaky"},
            headers=self._auth(self.scoped_token),
        )
        # Check security events
        with self.db.get_connection() as conn:
            events = conn.execute(
                "SELECT * FROM security_events WHERE event_type = 'scope_violation' ORDER BY created_at DESC LIMIT 1"
            ).fetchall()
        assert len(events) >= 1
        event = dict(events[0])
        assert event["outcome"] == "insufficient_scope"
        assert event["actor_agent"] == "scoped-agent"
        detail = json.loads(event["detail"])
        assert "tokens:manage" in detail["required"]
