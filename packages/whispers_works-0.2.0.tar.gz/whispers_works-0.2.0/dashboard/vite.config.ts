import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

const hubTarget = process.env.WHISPERS_UI_PROXY_TARGET || 'http://127.0.0.1:8752'
const proxyRoutes = [
  '/connect',
  '/disconnect',
  '/health',
  '/heartbeat',
  '/inbox',
  '/lease',
  '/livez',
  '/message:send',
  '/message:stream',
  '/mode',
  '/outbox',
  '/presence',
  '/readiness',
  '/readyz',
  '/runtime',
  '/status',
  '/token:create',
  '/token:revoke',
  '/token:rotate',
  '/trace',
  '/wag',
  '/whoami',
  '/active-mode',
  '/agents',
]

// https://vite.dev/config/
export default defineConfig({
  plugins: [react()],
  base: '/ui/',
  server: {
    proxy: Object.fromEntries(
      proxyRoutes.map((route) => [
        route,
        {
          target: hubTarget,
          changeOrigin: true,
        },
      ]),
    ),
  },
  build: {
    outDir: '../whispers/ui',
    emptyOutDir: true,
  }
})
