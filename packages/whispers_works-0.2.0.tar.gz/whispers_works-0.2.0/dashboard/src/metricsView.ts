import type { MetricsSummary, ThroughputBucket } from 'whispers-sdk';

export type ThroughputBar = {
  hour: string;
  label: string;
  sent: number;
  delivered: number;
  failed: number;
  heightPct: number;
};

export function deriveThroughputBars(buckets: ThroughputBucket[], limit = 12): ThroughputBar[] {
  const trimmed = buckets.slice(-limit);
  const peak = Math.max(1, ...trimmed.map((bucket) => bucket.sent));

  return trimmed.map((bucket) => ({
    hour: bucket.hour,
    label: formatHourLabel(bucket.hour),
    sent: bucket.sent,
    delivered: bucket.delivered,
    failed: bucket.failed,
    heightPct: bucket.sent > 0 ? Math.max(12, Math.round((bucket.sent / peak) * 100)) : 0,
  }));
}

export function metricsSummaryFacts(summary: MetricsSummary | null): string[] {
  if (!summary) return [];
  return [
    `${summary.messages_today} messages today`,
    `${summary.delivery_success_pct} delivery success`,
    `${summary.handoffs_today} handoffs today`,
    `${summary.handoff_ack_pct} handoff acknowledgment`,
  ];
}

function formatHourLabel(hour: string): string {
  const date = new Date(hour);
  if (Number.isNaN(date.getTime())) return hour;
  const hours = date.getUTCHours();
  const suffix = hours >= 12 ? 'p' : 'a';
  const twelveHour = hours % 12 || 12;
  return `${twelveHour}${suffix}`;
}
