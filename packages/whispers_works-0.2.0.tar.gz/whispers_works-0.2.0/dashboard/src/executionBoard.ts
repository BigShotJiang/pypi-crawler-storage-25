import type {
  AgentRegistryEntry,
  CollaborationActivityEvent,
  ConnectionStory,
  ConversationPulse,
  HandoffView,
  OperatorBoardSnapshot,
  RepoDivergenceWarning,
  RepoLane,
  WorkspaceSummary,
} from 'whispers-sdk';
import type { ConsoleHealthTone, ConsoleSurfaceState } from './consoleStatus';

export type ExecutionBoardState = 'active' | 'planned' | 'watch' | 'blocked' | 'done';

export type ExecutionBoardOwner = {
  callsign: string;
  isOnline: boolean;
  activeMode: string;
  readiness: string;
  workLabel: string | null;
};

export type ExecutionBoardCard = {
  id: string;
  tranche: string;
  title: string;
  state: ExecutionBoardState;
  summary: string;
  acceptanceBar: string;
  liveSignal: string;
  highlights: string[];
  workspaceHint: string | null;
  owners: ExecutionBoardOwner[];
};

export type ExecutionBoardInput = {
  registry: AgentRegistryEntry[];
  workspaces: WorkspaceSummary[];
  handoffs: HandoffView[];
  activity: CollaborationActivityEvent[];
  connectionStory: ConnectionStory | null;
  conversationPulses: ConversationPulse[];
  repoLanes: RepoLane[];
  repoDivergence: RepoDivergenceWarning[];
  operatorBoard: OperatorBoardSnapshot | null;
  healthTone: ConsoleHealthTone;
  streamState: ConsoleSurfaceState;
  collaborationState: ConsoleSurfaceState;
};

type ExecutionSeed = {
  id: string;
  tranche: string;
  title: string;
  state: ExecutionBoardState | ((input: ExecutionBoardInput) => ExecutionBoardState);
  summary: string;
  acceptanceBar: string;
  workspaceHint?: string;
  owners: string[];
  signal: (input: ExecutionBoardInput) => string;
  highlights?: (input: ExecutionBoardInput) => string[];
};

const SEEDS: ExecutionSeed[] = [
  {
    id: 'arrival-startup',
    tranche: 'Tranche 1',
    title: 'Arrival And Startup Intelligence',
    state: (input) => (input.connectionStory ? 'active' : input.streamState === 'ready' ? 'watch' : 'planned'),
    summary: 'Connection Story, briefing capsule, startup rules, and resume-aware arrival surfaces.',
    acceptanceBar: 'Arrival should tell the agent who it is, where it is, what matters now, and what not to auto-execute.',
    workspaceHint: 'startup / connection story',
    owners: ['codex', 'claude-code'],
    signal: (input) => {
      if (input.connectionStory) {
        const peers = `${input.connectionStory.peers_online_count} peer${input.connectionStory.peers_online_count === 1 ? '' : 's'} online`;
        const unread = `${input.connectionStory.pending_messages} unread`;
        return `${input.connectionStory.signal_mode}/${input.connectionStory.derived_active_mode} · ${unread} · ${peers} · ${input.connectionStory.deployment_mode} deployment`;
      }
      const stream = input.streamState === 'ready' ? 'stream live' : input.streamState === 'loading' ? 'stream connecting' : 'stream degraded';
      return `Health ${input.healthTone}. ${stream}. ${input.activity.length} recent collaboration events visible.`;
    },
    highlights: (input) => {
      if (!input.connectionStory) return [];
      const captainAlerts = (input.connectionStory as any).captain_action_alerts ?? [];
      return [
        input.connectionStory.recommended_action,
        ...captainAlerts.slice(0, 2).map((alert: any) => {
          const sender = alert?.sender ?? 'peer';
          const label = alert?.label ?? alert?.kind ?? 'packet';
          const detail = alert?.detail ?? alert?.subject ?? 'fresh packet';
          return `${sender}: ${label} · ${detail}`;
        }),
        ...input.connectionStory.peers.slice(0, 2).map((peer) => `${peer.callsign}: ${peer.derived_active_mode || peer.readiness || 'ready'}`),
      ].filter((value): value is string => Boolean(value));
    },
  },
  {
    id: 'visibility-coordination',
    tranche: 'Runtime Visibility',
    title: 'Operator-Visible Coordination',
    state: (input) => (
      input.conversationPulses.length > 0 || input.activity.length > 0 || input.handoffs.length > 0
        ? 'active'
        : input.collaborationState === 'ready'
          ? 'watch'
          : 'planned'
    ),
    summary: 'Conversation pulse, activity rendering, and visible collaborator state instead of keyhole chat.',
    acceptanceBar: 'The operator should see active exchanges, current slices, and live movement without opening the machinery.',
    workspaceHint: 'conversation pulse / operator feed',
    owners: ['claude-code', 'codex'],
    signal: (input) => {
      const board = input.operatorBoard?.system;
      if (input.conversationPulses.length > 0) {
        const pulseSummary = summarizePulseStates(input.conversationPulses);
        const operatorSummary = board
          ? ` ${board.total_pending_assignments} pending, ${board.total_blocking_reviews} blocking, ${board.total_batons_in_flight} batons in flight.`
          : '';
        return `${pulseSummary.active} active pulses, ${pulseSummary.recent} recent, ${input.handoffs.length} open handoffs, ${input.activity.length} collaboration events.${operatorSummary}`;
      }
      const operatorSummary = board
        ? ` ${board.total_pending_assignments} pending, ${board.total_blocking_reviews} blocking, ${board.total_batons_in_flight} batons in flight.`
        : '';
      return `${input.handoffs.length} open handoffs, ${input.activity.length} collaboration events, ${input.workspaces.length} active workspaces.${operatorSummary}`;
    },
    highlights: (input) => input.conversationPulses
      .slice(0, 3)
      .map((pulse) => pulse.headline),
  },
  {
    id: 'liveness-presence',
    tranche: 'Liveness',
    title: 'Presence Truth And Low-Write Liveness',
    state: (input) => {
      const counts = summarizeAgentStates(input.registry);
      if (counts.blocked > 0) return 'blocked';
      if (counts.ready > 0 || counts.busy > 0) return 'active';
      return 'watch';
    },
    summary: 'Heartbeat, readiness, active-mode truth, and reduced write amplification for quiet healthy agents.',
    acceptanceBar: 'A quiet but healthy agent stays visible and routable without hammering SQLite.',
    workspaceHint: 'heartbeat / active mode',
    owners: ['antigravity'],
    signal: (input) => {
      const counts = summarizeAgentStates(input.registry);
      return `${counts.ready} ready, ${counts.busy} busy, ${counts.blocked} blocked, ${counts.offline} offline.`;
    },
  },
  {
    id: 'repo-worktree',
    tranche: 'Lane Coordination',
    title: 'Repo And Worktree Coordination',
    state: (input) => {
      if (input.repoDivergence.length > 0) return 'blocked';
      if (input.repoLanes.length > 0) return 'active';
      return input.collaborationState === 'ready' ? 'watch' : 'planned';
    },
    summary: 'Branch, worktree, lane-of-record, and superseded-lane visibility for multi-agent code execution.',
    acceptanceBar: 'The operator should be able to see the active lane, ownership, and stale or superseded branches at a glance.',
    workspaceHint: 'repo lane / worktree state',
    owners: ['claude-code', 'codex'],
    signal: (input) => {
      if (input.repoLanes.length > 0) {
        const laneSummary = summarizeRepoLanes(input.repoLanes);
        const warningCount = input.repoDivergence.length;
        return `${laneSummary.total} published lanes, ${laneSummary.dirty} dirty, ${laneSummary.superseded} superseded, ${warningCount} divergence warning${warningCount === 1 ? '' : 's'}.`;
      }
      return input.collaborationState === 'ready'
        ? 'No published repo lanes yet. Runtime is ready for agents to declare branch and worktree state.'
        : 'Runtime visibility still connecting before repo lane state can be rendered.';
    },
    highlights: (input) => input.repoLanes
      .slice(0, 3)
      .map((lane) => summarizeRepoLane(lane)),
  },
  {
    id: 'execution-board',
    tranche: 'Console',
    title: 'Execution Board',
    state: (input) => (
      input.connectionStory || input.conversationPulses.length > 0 || input.repoLanes.length > 0
        ? 'active'
        : input.collaborationState === 'ready'
          ? 'watch'
          : 'planned'
    ),
    summary: 'A live operator board that ties roadmap items to owners, runtime truth, and current collaboration signals.',
    acceptanceBar: 'The human should be able to follow the project through a visual board instead of reconstructing it from chat lines.',
    workspaceHint: 'console / operator board',
    owners: ['codex'],
    signal: (input) => {
      const sources = [
        input.connectionStory ? 'connection story' : null,
        input.conversationPulses.length > 0 ? 'conversation pulses' : null,
        input.repoLanes.length > 0 ? 'repo lanes' : null,
        input.operatorBoard ? 'operator board' : null,
      ].filter((value): value is string => Boolean(value));
      return sources.length > 0
        ? `Runtime-backed by ${sources.join(', ')}.`
        : 'This panel is the first slice: curated roadmap lanes with live runtime overlays.';
    },
    highlights: (input) => {
      const facts = [
        input.connectionStory ? `Connection Story for ${input.connectionStory.agent_name}` : null,
        input.conversationPulses.length > 0 ? `${input.conversationPulses.length} pulse${input.conversationPulses.length === 1 ? '' : 's'} visible` : null,
        input.repoLanes.length > 0 ? `${input.repoLanes.length} repo lane${input.repoLanes.length === 1 ? '' : 's'} published` : null,
        input.operatorBoard ? `Board seq ${input.operatorBoard.sequence_id} · ${input.operatorBoard.system.total_pending_assignments} pending · ${input.operatorBoard.system.total_blocking_reviews} blocking` : null,
      ];
      return facts.filter((value): value is string => Boolean(value));
    },
  },
];

function summarizePulseStates(pulses: ConversationPulse[]) {
  return pulses.reduce(
    (summary, pulse) => {
      if (pulse.state === 'active') summary.active += 1;
      else if (pulse.state === 'recent') summary.recent += 1;
      else summary.idle += 1;
      return summary;
    },
    { active: 0, recent: 0, idle: 0 },
  );
}

function summarizeRepoLanes(lanes: RepoLane[]) {
  return lanes.reduce(
    (summary, lane) => {
      summary.total += 1;
      if (lane.dirty) summary.dirty += 1;
      if ((lane.lane_state || 'active') === 'superseded') summary.superseded += 1;
      return summary;
    },
    { total: 0, dirty: 0, superseded: 0 },
  );
}

function summarizeRepoLane(lane: RepoLane) {
  const branch = lane.branch || 'detached';
  const head = lane.head_commit ? lane.head_commit.slice(0, 7) : 'unknown';
  const dirty = lane.dirty ? '*' : '';
  const state = lane.lane_state && lane.lane_state !== 'active' ? ` [${lane.lane_state}]` : '';
  return `${lane.agent_name}: ${branch}${dirty} @ ${head}${state}`;
}

function summarizeAgentStates(registry: AgentRegistryEntry[]) {
  const summary = {
    ready: 0,
    busy: 0,
    blocked: 0,
    offline: 0,
  };

  for (const agent of registry) {
    if (!agent.is_online) {
      summary.offline += 1;
      continue;
    }
    const mode = (agent.derived_active_mode || agent.readiness || 'ready').toLowerCase();
    if (mode === 'blocked' || mode === 'paused' || mode === 'paused_by_operator' || mode === 'degraded' || mode === 'overloaded') {
      summary.blocked += 1;
    } else if (mode === 'busy' || mode === 'warming' || mode === 'deep_work') {
      summary.busy += 1;
    } else {
      summary.ready += 1;
    }
  }

  return summary;
}

function deriveOwner(callsign: string, registry: AgentRegistryEntry[]): ExecutionBoardOwner {
  const agent = registry.find((entry) => entry.callsign === callsign);
  return {
    callsign,
    isOnline: Boolean(agent?.is_online),
    activeMode: agent?.derived_active_mode || (agent?.is_online ? agent?.readiness || 'ready' : 'offline') || 'offline',
    readiness: agent?.readiness || (agent?.is_online ? 'ready' : 'offline'),
    workLabel: agent?.working_on || agent?.current_task || agent?.cognitive_state || null,
  };
}

export function deriveExecutionBoard(input: ExecutionBoardInput): ExecutionBoardCard[] {
  return SEEDS.map((seed) => ({
    id: seed.id,
    tranche: seed.tranche,
    title: seed.title,
    state: typeof seed.state === 'function' ? seed.state(input) : seed.state,
    summary: seed.summary,
    acceptanceBar: seed.acceptanceBar,
    liveSignal: seed.signal(input),
    highlights: seed.highlights ? seed.highlights(input) : [],
    workspaceHint: seed.workspaceHint ?? null,
    owners: seed.owners.map((callsign) => deriveOwner(callsign, input.registry)),
  }));
}
