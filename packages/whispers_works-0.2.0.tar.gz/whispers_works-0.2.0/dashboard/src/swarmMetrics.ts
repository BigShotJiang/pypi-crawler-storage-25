import type { SwarmHealth, AgentRegistryEntry } from 'whispers-sdk';

type AgentEntry = NonNullable<SwarmHealth['agents']>[number];
type RegistryLikeAgent = AgentEntry | AgentRegistryEntry;
export type ParticipantKind = 'agent' | 'service' | 'automaton' | 'ephemeral';
export type WakeModel = 'listener_backed' | 'manual_wake' | 'operator_console' | 'mixed';
export type WakeModelBadge = {
  label: string;
  tone: 'listener' | 'manual' | 'console' | 'mixed';
};

export type AgentLandscapeCounts = {
  ready: number;
  busy: number;
  blocked: number;
  degraded: number;
  offline: number;
};

export type AgentFocusSummary = {
  callsign: string;
  state: string;
  summary: string;
};

export type ParticipantCounts = {
  firstClassRegistered: number;
  firstClassOnline: number;
  otherRegistered: number;
  otherOnline: number;
  buckets: Record<ParticipantKind, { registered: number; online: number }>;
};

function participantKind(agent: RegistryLikeAgent): ParticipantKind {
  const explicit = 'participant_kind' in agent && typeof agent.participant_kind === 'string'
    ? agent.participant_kind
    : null;
  if (explicit === 'agent' || explicit === 'service' || explicit === 'automaton' || explicit === 'ephemeral') {
    return explicit;
  }
  return agent.agent_type === 'infrastructure' ? 'service' : 'agent';
}

export function isFirstClassParticipant(agent: RegistryLikeAgent): boolean {
  if ('is_primary_participant' in agent && typeof agent.is_primary_participant === 'boolean') {
    return agent.is_primary_participant;
  }
  if ('is_first_class_participant' in agent && typeof agent.is_first_class_participant === 'boolean') {
    return agent.is_first_class_participant;
  }
  const kind = participantKind(agent);
  return kind === 'agent' || kind === 'service';
}

export function deriveParticipantCounts(agents: RegistryLikeAgent[]): ParticipantCounts {
  const buckets: Record<ParticipantKind, { registered: number; online: number }> = {
    agent: { registered: 0, online: 0 },
    service: { registered: 0, online: 0 },
    automaton: { registered: 0, online: 0 },
    ephemeral: { registered: 0, online: 0 },
  };

  for (const agent of agents) {
    const kind = participantKind(agent);
    buckets[kind].registered += 1;
    const isOnline = !('is_online' in agent) || Boolean(agent.is_online);
    if (isOnline) buckets[kind].online += 1;
  }

  return {
    firstClassRegistered: buckets.agent.registered + buckets.service.registered,
    firstClassOnline: buckets.agent.online + buckets.service.online,
    otherRegistered: buckets.automaton.registered + buckets.ephemeral.registered,
    otherOnline: buckets.automaton.online + buckets.ephemeral.online,
    buckets,
  };
}

export function visiblePeerCount(
  swarmState: (SwarmHealth & { background_agents?: AgentEntry[] }) | null,
): number {
  const activeAgents = swarmState?.agents ?? [];
  const backgroundAgents = swarmState?.background_agents ?? [];
  return activeAgents.length + backgroundAgents.length;
}

export function agentStateLabel(agent: RegistryLikeAgent): string {
  if ('presence_kind' in agent) {
    if (agent.presence_kind === 'background') return 'background';
    if (agent.presence_kind === 'system') return 'system';
  }
  return agent.derived_active_mode ?? agent.readiness ?? 'ready';
}

export function agentStateSummary(agent: RegistryLikeAgent): string | null {
  const fragments: string[] = [];
  if (agent.readiness && agent.readiness !== agentStateLabel(agent)) {
    fragments.push(`readiness ${agent.readiness}`);
  }
  if (agent.interruptibility) {
    fragments.push(`interrupt ${agent.interruptibility}`);
  }
  if (typeof agent.context_load === 'number') {
    fragments.push(`load ${Math.round(agent.context_load * 100)}%`);
  }
  if (agent.current_task) {
    fragments.push(agent.current_task);
  }
  return fragments.length ? fragments.join(' · ') : null;
}

export function describeWakeModel(wakeModel: string | null | undefined): WakeModelBadge | null {
  switch (wakeModel) {
    case 'listener_backed':
      return { label: 'SELF-WAKING', tone: 'listener' };
    case 'manual_wake':
      return { label: 'MANUAL-WAKE', tone: 'manual' };
    case 'operator_console':
      return { label: 'CONSOLE', tone: 'console' };
    case 'mixed':
      return { label: 'MIXED', tone: 'mixed' };
    default:
      return null;
  }
}

export function deriveLandscapeCounts(agents: RegistryLikeAgent[]): AgentLandscapeCounts {
  const counts: AgentLandscapeCounts = {
    ready: 0,
    busy: 0,
    blocked: 0,
    degraded: 0,
    offline: 0,
  };

  for (const agent of agents) {
    const isOnline = !('is_online' in agent) || Boolean(agent.is_online);
    if (!isOnline) {
      counts.offline += 1;
      continue;
    }

    const state = agentStateLabel(agent);
    if (state === 'blocked' || state === 'paused_by_operator') {
      counts.blocked += 1;
    } else if (state === 'degraded' || state === 'overloaded') {
      counts.degraded += 1;
    } else if (state === 'busy' || state === 'warming') {
      counts.busy += 1;
    } else {
      counts.ready += 1;
    }
  }

  return counts;
}

export function deriveFocusSummaries(
  agents: RegistryLikeAgent[],
  limit = 3,
): AgentFocusSummary[] {
  const priority = (state: string, attentionState: string | null): number => {
    if (attentionState === 'needs_assignment') return 0;
    if (state === 'blocked' || state === 'paused_by_operator') return 0;
    if (state === 'degraded' || state === 'overloaded') return 1;
    if (state === 'busy' || state === 'warming') return 2;
    return 3;
  };

  return agents
    .filter(agent => !('is_online' in agent) || Boolean(agent.is_online))
    .map((agent) => {
      const state = agentStateLabel(agent);
      const attentionState = typeof agent.attention_state === 'string'
        ? agent.attention_state.trim().toLowerCase()
        : null;
      const attentionDetail = [
        typeof agent.attention_detail === 'string' ? agent.attention_detail : null,
        typeof agent.progress_summary === 'string' ? agent.progress_summary : null,
      ].find((value): value is string => Boolean(value && value.trim().length > 0)) ?? null;
      const summary = agent.current_task
        || (attentionState === 'needs_assignment' ? (attentionDetail || 'needs assignment') : null)
        || ('working_on' in agent ? agent.working_on : null)
        || (state === 'ready' ? null : state);
      return summary
        ? {
          callsign: 'callsign' in agent
            ? agent.callsign
            : ('agent_name' in agent ? agent.agent_name : 'agent'),
          state,
          summary,
          priorityBucket: priority(state, attentionState),
        }
        : null;
    })
    .filter((item): item is AgentFocusSummary & { priorityBucket: number } => Boolean(item))
    .sort((a, b) => {
      const priorityDelta = a.priorityBucket - b.priorityBucket;
      if (priorityDelta !== 0) return priorityDelta;
      return a.callsign.localeCompare(b.callsign);
    })
    .map(({ priorityBucket: _priorityBucket, ...item }) => item)
    .slice(0, limit);
}
