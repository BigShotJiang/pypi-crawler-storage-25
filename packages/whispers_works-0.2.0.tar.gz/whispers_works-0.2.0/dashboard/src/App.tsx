import React, { useEffect, useState, useRef, startTransition } from 'react';
import type {
  A2AEnvelope,
  AgentRegistryEntry,
  CollaborationActivityEvent,
  CollaborationHealthSignal,
  ConnectionStory,
  ConversationPulse,
  HandoffView,
  MetricsSummary,
  OperatorBoardSnapshot,
  OperatorStreamEvent,
  RepoDivergenceWarning,
  RepoLane,
  RuntimeSettings,
  SwarmHealth,
  ThroughputBucket,
  WorkspaceState,
  WorkspaceSummary,
} from 'whispers-sdk';
import { WhispersClient } from 'whispers-sdk';
import {
  deriveAgentAttention,
  deriveBackendActivity,
  deriveCollaborationActivity,
  deriveConsoleDiagnostics,
  deriveConsoleHealth,
  deriveJoltSummary,
  deriveOpenHandoffs,
  deriveUnifiedFeed,
  deriveWorkspaceCards,
  formatConsoleDiagnosticsSummary,
  type ConsoleSurfaceState,
  type UnifiedFeedItem,
} from './consoleStatus';
import { deriveExecutionBoard } from './executionBoard';
import { deriveThroughputBars, metricsSummaryFacts } from './metricsView';
import {
  describeWakeModel,
  deriveFocusSummaries,
  deriveLandscapeCounts,
  deriveParticipantCounts,
  isFirstClassParticipant,
} from './swarmMetrics';

const AGENT_NAME = 'whispers-console';

type SystemEventTone = 'ok' | 'info' | 'warn' | 'error';
type SystemEvent = {
  id: string;
  title: string;
  detail: string;
  tone: SystemEventTone;
  createdAt: string;
};
type WakeAwareAgent = AgentRegistryEntry & {
  wake_model?: string | null;
  session_kinds?: string[];
};

function relativeTime(ts: string | null | undefined): string {
  if (!ts) return '';
  const now = Date.now();
  const then = new Date(ts).getTime();
  if (isNaN(then)) return '';
  const diffMs = now - then;
  if (diffMs < 0) return 'just now';
  const mins = Math.floor(diffMs / 60000);
  if (mins < 1) return 'just now';
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  const days = Math.floor(hrs / 24);
  return `${days}d ago`;
}

function dotColor(agent: AgentRegistryEntry): string {
  if (!agent.is_online) return 'dot-offline';
  const mode = agent.derived_active_mode || 'ready';
  if (mode === 'blocked' || mode === 'degraded' || mode === 'overloaded') return 'dot-critical';
  if (mode === 'busy' || agent.readiness === 'busy' || agent.readiness === 'warming') return 'dot-busy';
  return 'dot-online';
}

function agentTypeBadge(type: string): string {
  const map: Record<string, string> = {
    llm: 'LLM',
    mcp_server: 'MCP',
    remote_client: 'Remote',
    infrastructure: 'Infra',
    http_client: 'HTTP',
    script: 'Script',
  };
  return map[type] || type;
}

function participantBadge(agent: AgentRegistryEntry): string {
  if (agent.participant_kind === 'service') return 'PRIMARY SERVICE';
  if (agent.is_primary_participant ?? agent.is_first_class_participant) return 'PRIMARY';
  if (agent.participant_kind === 'automaton') return 'AUTOMATON';
  if (agent.participant_kind === 'ephemeral') return 'EPHEMERAL';
  return 'TRACKED';
}

function joltToneChip(tone: 'ok' | 'info' | 'warn' | 'error'): 'working' | 'waiting' | 'blocked' {
  if (tone === 'error') return 'blocked';
  if (tone === 'warn') return 'waiting';
  return 'working';
}


export default function App() {
  const [surfaceView, setSurfaceView] = useState<'collaboration' | 'metrics'>('collaboration');
  const [swarmState, setSwarmState] = useState<SwarmHealth | null>(null);
  const [registry, setRegistry] = useState<AgentRegistryEntry[]>([]);
  const [messages, setMessages] = useState<A2AEnvelope[]>([]);
  const [isConnected, setIsConnected] = useState(false);
  const [authReady, setAuthReady] = useState(false);
  const [observabilityMode, setObservabilityMode] = useState('metadata');
  const [runtimeProfile, setRuntimeProfile] = useState('unknown');
  const [runtimeAdmissionMode, setRuntimeAdmissionMode] = useState('unknown');
  const [isRuntimeUpdating, setIsRuntimeUpdating] = useState(false);
  const [injectionStatus, setInjectionStatus] = useState<{msg: string, isError: boolean} | null>(null);
  const [healthState, setHealthState] = useState<ConsoleSurfaceState>('loading');
  const [registryState, setRegistryState] = useState<ConsoleSurfaceState>('loading');
  const [streamState, setStreamState] = useState<ConsoleSurfaceState>('loading');
  const [collaborationState, setCollaborationState] = useState<ConsoleSurfaceState>('loading');
  const [lastError, setLastError] = useState<string | null>(null);
  const [systemEvents, setSystemEvents] = useState<SystemEvent[]>([]);
  const [workspaces, setWorkspaces] = useState<WorkspaceSummary[]>([]);
  const [handoffs, setHandoffs] = useState<HandoffView[]>([]);
  const [activity, setActivity] = useState<CollaborationActivityEvent[]>([]);
  const [collaborationSignals, setCollaborationSignals] = useState<CollaborationHealthSignal[]>([]);
  const [connectionStory, setConnectionStory] = useState<ConnectionStory | null>(null);
  const [conversationPulses, setConversationPulses] = useState<ConversationPulse[]>([]);
  const [repoLanes, setRepoLanes] = useState<RepoLane[]>([]);
  const [repoDivergence, setRepoDivergence] = useState<RepoDivergenceWarning[]>([]);
  const [metricsSummary, setMetricsSummary] = useState<MetricsSummary | null>(null);
  const [throughputBuckets, setThroughputBuckets] = useState<ThroughputBucket[]>([]);
  const [metricsState, setMetricsState] = useState<ConsoleSurfaceState>('loading');
  const [operatorBoard, setOperatorBoard] = useState<OperatorBoardSnapshot | null>(null);
  const [operatorBoardState, setOperatorBoardState] = useState<ConsoleSurfaceState>('loading');
  const [selectedAgentCallsign, setSelectedAgentCallsign] = useState<string>('');
  const [selectedWorkspaceId, setSelectedWorkspaceId] = useState<string>('all');
  const [activityAgentFilter, setActivityAgentFilter] = useState<string>('all');
  const [activityKindFilter, setActivityKindFilter] = useState<string>('all');
  const [workspaceDetail, setWorkspaceDetail] = useState<WorkspaceState | null>(null);
  const [workspaceDetailState, setWorkspaceDetailState] = useState<ConsoleSurfaceState>('loading');

  // Live activity pulse: tracks which agents had recent SSE message activity
  const [activityPulse, setActivityPulse] = useState<Record<string, number>>({});
  const pulseTimersRef = useRef<Record<string, ReturnType<typeof setTimeout>>>({});

  const [healthExpanded, setHealthExpanded] = useState(false);

  const [formTo, setFormTo] = useState('');
  const [formSubject, setFormSubject] = useState('');
  const [formPriority, setFormPriority] = useState('routine');
  const [formBody, setFormBody] = useState('');
  const [isDispatching, setIsDispatching] = useState(false);

  const triggerPulse = (callsign: string) => {
    const now = Date.now();
    setActivityPulse(prev => ({ ...prev, [callsign]: now }));
    // Clear existing timer for this agent
    if (pulseTimersRef.current[callsign]) {
      clearTimeout(pulseTimersRef.current[callsign]);
    }
    // Auto-decay pulse after 3 seconds
    pulseTimersRef.current[callsign] = setTimeout(() => {
      setActivityPulse(prev => {
        const next = { ...prev };
        delete next[callsign];
        return next;
      });
    }, 3000);
  };

  const primaryRegistry = registry.filter(isFirstClassParticipant);
  const secondaryRegistry = registry.filter(agent => !isFirstClassParticipant(agent));
  const participantCounts = deriveParticipantCounts(registry);
  const onlineAgents = primaryRegistry.filter(a => a.is_online);
  const offlineAgents = primaryRegistry.filter(a => !a.is_online);
  const secondaryOnlineAgents = secondaryRegistry.filter(a => a.is_online);
  const secondaryOfflineAgents = secondaryRegistry.filter(a => !a.is_online);
  const pendingMessages = swarmState?.pending_messages ?? 0;
  const consoleHealth = deriveConsoleHealth({
    authReady,
    isConnected,
    healthState,
    registryState,
    streamState,
    collaborationState,
    onlineAgents: onlineAgents.length,
    registeredAgents: registry.length,
    primaryOnline: onlineAgents.length,
    primaryRegistered: primaryRegistry.length,
    secondaryTrackedParticipants: secondaryRegistry.length,
    lastError,
    serverState: swarmState?.server_state,
    serverStateDetail: swarmState?.server_state_detail,
  });
  const consoleDiagnostics = deriveConsoleDiagnostics(swarmState?.server_diagnostics);
  const backendActivity = deriveBackendActivity(swarmState).slice(0, 6);
  const workspaceCards = deriveWorkspaceCards(workspaces).slice(0, 4);
  const openHandoffs = deriveOpenHandoffs(handoffs).slice(0, 6);
  const collaborationFeed = deriveCollaborationActivity(activity).slice(0, 8);
  const collaborationSignalCount = collaborationSignals.length;
  const pendingAssignments = connectionStory?.pending_assignments ?? 0;
  const blockingReviews = connectionStory?.blocking_review_requests ?? 0;
  const waitingOnReview = connectionStory?.blocked_waiting_for_review ?? 0;
  const operatorBoardSystem = operatorBoard?.system ?? null;
  const operatorBoardAsOf = operatorBoard?.as_of
    ? new Date(operatorBoard.as_of * 1000).toISOString()
    : null;
  const livePendingAssignments = operatorBoardSystem?.total_pending_assignments ?? pendingAssignments;
  const liveBlockingReviews = operatorBoardSystem?.total_blocking_reviews ?? blockingReviews;
  const totalBatonsInFlight = operatorBoardSystem?.total_batons_in_flight ?? 0;
  const selectedAgent = selectedAgentCallsign
    ? (registry.find(agent => agent.callsign === selectedAgentCallsign) as WakeAwareAgent | undefined) ?? null
    : null;
  const selectedWorkspace = selectedWorkspaceId === 'all'
    ? null
    : workspaces.find(workspace => workspace.workspace_id === selectedWorkspaceId) ?? null;
  const workspaceMembers = workspaceDetail?.members ?? [];
  const workspaceDeltas = workspaceDetail?.deltas ?? [];
  const activityAgents = Array.from(new Set([
    ...registry.map(agent => agent.callsign),
    ...activity.flatMap(event => [event.actor, event.sender, event.receiver].filter((value): value is string => Boolean(value))),
  ])).sort((a, b) => a.localeCompare(b));
  const landscapeCounts = deriveLandscapeCounts(primaryRegistry);
  const focusSummaries = deriveFocusSummaries(primaryRegistry, 4);
  const diagnosticHints = consoleDiagnostics.hints.slice(0, 2);
  const recentSystemEvents = systemEvents.slice(0, 4);
  const systemFeed = recentSystemEvents.map(event => ({
    id: event.id,
    title: event.title,
    detail: event.detail,
    tone: event.tone,
    createdAt: event.createdAt,
    sourceLabel: 'Console',
  }));
  const throughputBars = deriveThroughputBars(throughputBuckets, 12);
  const metricsFacts = metricsSummaryFacts(metricsSummary);
  const executionBoard = deriveExecutionBoard({
    registry: primaryRegistry,
    workspaces,
    handoffs,
    activity,
    connectionStory,
    conversationPulses,
    repoLanes,
    repoDivergence,
    operatorBoard,
    healthTone: consoleHealth.tone,
    streamState,
    collaborationState,
  });
  const unifiedFeed = deriveUnifiedFeed({
    workspaceCards,
    handoffs: openHandoffs,
    collaborationSignals,
    collaborationFeed,
    backendActivity,
    systemEvents: systemFeed,
    messages,
  });
  const filteredUnifiedFeed = unifiedFeed.filter(item => {
    const workspaceMatches = selectedWorkspaceId === 'all'
      || item.workspaceLabel === null
      || item.workspaceLabel === selectedWorkspaceId;
    const effectiveAgentFilter = selectedAgentCallsign || activityAgentFilter;
    const agentMatches = !effectiveAgentFilter || effectiveAgentFilter === 'all'
      || item.agents.includes(effectiveAgentFilter);
    const kindMatches = activityKindFilter === 'all'
      || item.kind === activityKindFilter;
    return workspaceMatches && agentMatches && kindMatches;
  });
  const huddlePeers = (connectionStory?.huddle_peers ?? []).map(peer => ({
    callsign: peer.callsign ?? peer.agent_name ?? 'peer',
    readiness: peer.readiness ?? 'ready',
    sharedWorkspaces: peer.shared_workspaces ?? [],
    incomingBatonCount: peer.incoming_baton_count ?? 0,
    outgoingBatonCount: peer.outgoing_baton_count ?? 0,
    incomingBaton: Boolean(peer.incoming_baton_from_them),
    outgoingBaton: Boolean(peer.outgoing_baton_to_them),
    workingOn: peer.working_on ?? null,
  }));
  type CaptainAlertCard = {
    sender?: string;
    label?: string;
    kind?: string;
    detail?: string | null;
    subject?: string | null;
    created_at?: string | null;
  };
  const captainAlerts: CaptainAlertCard[] = Array.isArray((connectionStory as any)?.captain_action_alerts)
    ? ((connectionStory as any).captain_action_alerts as CaptainAlertCard[])
    : [];
  const assignmentAlerts = connectionStory?.peer_assignment_alerts ?? [];
  const selectedAgentAttention = selectedAgent
    ? deriveAgentAttention({
      attention_state: selectedAgent.attention_state,
      attention_detail: selectedAgent.attention_detail,
      progress_summary: selectedAgent.progress_summary,
      last_progress_at: selectedAgent.last_progress_at,
      runtime_updated_at: selectedAgent.runtime_updated_at,
      readiness: selectedAgent.readiness,
    })
    : null;
  const selectedAgentWake = selectedAgent ? describeWakeModel(selectedAgent.wake_model) : null;
  const selectedAgentLastSeen = selectedAgent
    ? selectedAgent.session_last_seen || selectedAgent.last_active || selectedAgent.last_seen || null
    : null;
  const selectedAgentWorkLabel = selectedAgent
    ? selectedAgent.working_on || selectedAgent.current_task || selectedAgent.cognitive_state || null
    : null;
  const selectedAgentAssignments = selectedAgent
    ? executionBoard.filter(card => card.owners.some(owner => owner.callsign === selectedAgent.callsign))
    : [];
  const selectedAgentPulses = selectedAgent
    ? conversationPulses.filter(pulse => pulse.participants.includes(selectedAgent.callsign)).slice(0, 4)
    : [];
  const selectedAgentFeed = selectedAgent
    ? unifiedFeed.filter(item => item.agents.includes(selectedAgent.callsign)).slice(0, 6)
    : [];
  const selectedAgentHuddlePeer = selectedAgent
    ? huddlePeers.find(peer => peer.callsign === selectedAgent.callsign) ?? null
    : null;
  const selectedAgentAssignmentAlert = selectedAgent
    ? assignmentAlerts.find(alert => (alert.callsign ?? alert.agent_name) === selectedAgent.callsign) ?? null
    : null;
  const selectedAgentCaptainAlert = selectedAgent
    ? captainAlerts.find(alert => alert.sender === selectedAgent.callsign) ?? null
    : null;
  const selectedAgentBoardCounters = selectedAgent
    ? operatorBoard?.agents[selectedAgent.callsign] ?? null
    : null;
  const consoleJolt = deriveJoltSummary(connectionStory);

  const registryEmptyCopy = registryState === 'error'
    ? 'Participant registry unavailable.'
    : registryState === 'loading'
      ? 'Loading participant registry...'
      : 'No primary participants yet.';
  const feedEmptyTitle = !authReady
    ? 'Authenticating Console'
    : streamState === 'error'
      ? 'Live stream interrupted'
      : streamState === 'loading'
        ? 'Connecting live stream'
        : 'Waiting for activity';
  const feedEmptyDetail = !authReady
    ? 'The Console is still establishing its session with Whispers.'
    : streamState === 'error'
      ? 'Real-time updates will resume automatically when the stream reconnects.'
      : streamState === 'loading'
        ? 'Whispers is wiring up the real-time feed now.'
        : collaborationState === 'loading'
          ? 'Loading workspaces, handoffs, and operator activity.'
          : 'System events, collaboration runtime, and live messages will appear here.';
  const metricsEmptyTitle = metricsState === 'error'
    ? 'Metrics unavailable'
    : metricsState === 'loading'
      ? 'Loading metrics'
      : 'No throughput yet';
  const metricsEmptyDetail = metricsState === 'error'
    ? 'Operational metrics will return when the summary and throughput endpoints are reachable again.'
    : metricsState === 'loading'
      ? 'Whispers is wiring up the behind-the-scenes metrics view now.'
      : 'As soon as agents exchange messages, the first throughput bars will appear here.';

  const clientRef = useRef<WhispersClient | null>(null);
  const eventSeqRef = useRef(0);
  const lastServerStateRef = useRef<string | null>(null);
  const lastDiagnosticsSignatureRef = useRef<string | null>(null);
  const prevRegistryRef = useRef<Map<string, { isOnline: boolean; activeMode: string }>>(new Map());
  const registryFailCountRef = useRef(0);
  const collaborationFailCountRef = useRef(0);
  const operatorBoardSeqRef = useRef(0);
  const operatorBoardRefreshTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const operatorBoardSurfaceRef = useRef<ConsoleSurfaceState>('loading');
  const surfaceStateRef = useRef<{
    health: ConsoleSurfaceState;
    registry: ConsoleSurfaceState;
    stream: ConsoleSurfaceState;
    collaboration: ConsoleSurfaceState;
  }>({
    health: 'loading',
    registry: 'loading',
    stream: 'loading',
    collaboration: 'loading',
  });
  if (!clientRef.current) {
    clientRef.current = new WhispersClient(AGENT_NAME, {
      baseURL: window.location.origin,
      EventSourcePolyfill: window.EventSource
    });
  }

  const pushSystemEvent = (title: string, detail: string, tone: SystemEventTone = 'info') => {
    const event: SystemEvent = {
      id: `system-${eventSeqRef.current++}`,
      title,
      detail,
      tone,
      createdAt: new Date().toISOString(),
    };
    startTransition(() => {
      setSystemEvents(prev => [event, ...prev].slice(0, 24));
    });
  };

  const showToast = (msg: string, isError = false) => {
    setInjectionStatus({ msg, isError });
    setTimeout(() => setInjectionStatus(null), 4000);
  };

  const applyRuntimeSnapshot = (snapshot: Pick<RuntimeSettings, 'runtime_profile' | 'remote_admission_mode' | 'observability_mode'>) => {
    setRuntimeProfile(snapshot.runtime_profile);
    setRuntimeAdmissionMode(snapshot.remote_admission_mode);
    setObservabilityMode(snapshot.observability_mode);
  };

  const applyOperatorBoardSnapshot = (snapshot: OperatorBoardSnapshot) => {
    operatorBoardSeqRef.current = snapshot.sequence_id;
    startTransition(() => {
      setOperatorBoard(snapshot);
    });
    setOperatorBoardState('ready');
    if (operatorBoardSurfaceRef.current !== 'ready') {
      pushSystemEvent(
        'Operator board live',
        `Board seq ${snapshot.sequence_id} loaded for ${Object.keys(snapshot.agents).length} agents.`,
        'ok',
      );
    }
    operatorBoardSurfaceRef.current = 'ready';
  };

  const refreshOperatorBoard = async () => {
    try {
      const snapshot = await clientRef.current!.operatorBoard();
      applyOperatorBoardSnapshot(snapshot);
    } catch (err) {
      console.error('Operator board fetch failed:', err);
      setOperatorBoardState('error');
      if (operatorBoardSurfaceRef.current !== 'error') {
        const message = err instanceof Error ? err.message : 'Operator board fetch failed';
        pushSystemEvent('Operator board unavailable', message, 'warn');
      }
      operatorBoardSurfaceRef.current = 'error';
    }
  };

  const scheduleOperatorBoardRefresh = (seqHint?: number | null) => {
    if (typeof seqHint === 'number' && seqHint > 0 && seqHint <= operatorBoardSeqRef.current) {
      return;
    }
    if (operatorBoardRefreshTimerRef.current) {
      clearTimeout(operatorBoardRefreshTimerRef.current);
    }
    operatorBoardRefreshTimerRef.current = setTimeout(() => {
      operatorBoardRefreshTimerRef.current = null;
      void refreshOperatorBoard();
    }, 180);
  };

  const relayOperatorEvent = (event: OperatorStreamEvent) => {
    const payload = event.payload ?? {};
    switch (event.type) {
      case 'health:signal_raised':
        pushSystemEvent(
          'Health signal raised',
          payload?.signal
            ? `${payload.signal} requires attention.`
            : 'A collaboration health signal requires attention.',
          'warn',
        );
        break;
      case 'health:signal_cleared':
        pushSystemEvent(
          'Health signal cleared',
          payload?.signal_id
            ? `${payload.signal_id} has cleared.`
            : 'A collaboration health signal cleared.',
          'ok',
        );
        break;
      case 'review:published':
        pushSystemEvent(
          'Review published',
          `${payload?.agent ?? 'Someone'} opened a review beacon${payload?.topic ? ` for ${payload.topic}` : ''}.`,
          'info',
        );
        break;
      case 'review:claimed':
        pushSystemEvent(
          'Review claimed',
          `${payload?.claimant ?? 'Someone'} picked up review ${payload?.claim_id ?? 'claim'}.`,
          'ok',
        );
        break;
      case 'review:resolved':
        pushSystemEvent(
          'Review resolved',
          `${payload?.resolver ?? 'Someone'} moved review ${payload?.claim_id ?? 'claim'} to ${payload?.new_state ?? 'resolved'}.`,
          'ok',
        );
        break;
      case 'review:verdict':
        pushSystemEvent(
          'Review verdict',
          `${payload?.reviewer ?? 'Someone'} submitted ${payload?.verdict ?? 'a verdict'}${typeof payload?.findings_count === 'number' ? ` with ${payload.findings_count} finding${payload.findings_count === 1 ? '' : 's'}` : ''}.`,
          payload?.verdict === 'reject' || payload?.verdict === 'request_changes' ? 'warn' : 'ok',
        );
        break;
      case 'lane:path_overlap':
        pushSystemEvent(
          'Path overlap warning',
          `${payload?.agent_a ?? 'agent'} overlaps ${payload?.agent_b ?? 'peer'} on ${Array.isArray(payload?.overlapping_paths) ? payload.overlapping_paths.join(', ') : 'shared files'}.`,
          'warn',
        );
        if (payload?.agent_a) triggerPulse(String(payload.agent_a));
        if (payload?.agent_b) triggerPulse(String(payload.agent_b));
        break;
      default:
        // Pulse any agent referenced in the event payload
        if (payload?.agent) triggerPulse(String(payload.agent));
        if (payload?.claimant) triggerPulse(String(payload.claimant));
        if (payload?.reviewer) triggerPulse(String(payload.reviewer));
        if (payload?.resolver) triggerPulse(String(payload.resolver));
        break;
    }
  };

  // Auth
  useEffect(() => {
    let cancelled = false;
    const connectConsole = async () => {
      try {
        const result = await clientRef.current!.connect({
          displayName: 'Whispers Console',
          capabilities: { transport: 'http', dashboard: true, observability: true },
        });
        if (cancelled) return;
        setAuthReady(true);
        setLastError(null);
        setHealthState('loading');
        setRegistryState('loading');
        setStreamState('loading');
        setCollaborationState('loading');
        surfaceStateRef.current = { health: 'loading', registry: 'loading', stream: 'loading', collaboration: 'loading' };
        pushSystemEvent(
          'Console authenticated',
          'Connected to Whispers. Waiting for health, registry, collaboration, and live stream updates.',
          'ok',
        );
        const initialRuntime = result.policy;
        if (
          initialRuntime
          && typeof initialRuntime.runtime_profile === 'string'
          && typeof initialRuntime.remote_admission_mode === 'string'
          && typeof initialRuntime.observability_mode === 'string'
        ) {
          applyRuntimeSnapshot({
            runtime_profile: initialRuntime.runtime_profile,
            remote_admission_mode: initialRuntime.remote_admission_mode,
            observability_mode: initialRuntime.observability_mode,
          });
        } else {
          const runtime = await clientRef.current!.runtimeStatus();
          if (!cancelled) applyRuntimeSnapshot(runtime);
        }
      } catch (err) {
        if (cancelled) return;
        setAuthReady(false);
        setIsConnected(false);
        setHealthState('error');
        setRegistryState('error');
        setStreamState('error');
        setCollaborationState('error');
        const message = err instanceof Error ? err.message : 'Dashboard auth failed';
        setLastError(message);
        surfaceStateRef.current = { health: 'error', registry: 'error', stream: 'error', collaboration: 'error' };
        pushSystemEvent('Console authentication failed', message, 'error');
        setInjectionStatus({ msg: message, isError: true });
        setTimeout(() => setInjectionStatus(null), 4000);
      }
    };
    connectConsole();
    return () => { cancelled = true; };
  }, []);

  // Health polling (system metrics)
  useEffect(() => {
    const fetchHealth = async () => {
      try {
        const data = await clientRef.current!.health();
        startTransition(() => {
          setSwarmState(data);
        });
        setIsConnected(true);
        setHealthState('ready');
        setLastError(null);
        if (surfaceStateRef.current.health !== 'ready') {
          pushSystemEvent('Health restored', 'Whispers is responding to health checks again.', 'ok');
        }
        surfaceStateRef.current.health = 'ready';
        const nextServerState = data.server_state ?? 'up';
        const diagnostics = deriveConsoleDiagnostics(data.server_diagnostics);
        const diagnosticsSummary = formatConsoleDiagnosticsSummary(diagnostics);
        const diagnosticsSignature = diagnosticsSummary
          ? JSON.stringify({
            failingChecks: diagnostics.failingChecks,
            hints: diagnostics.hints.slice(0, 2),
          })
          : null;
        if (lastServerStateRef.current !== nextServerState) {
          const serverStateTitle = nextServerState === 'recovering'
            ? 'Server recovering'
            : nextServerState === 'degraded'
              ? 'Server degraded'
              : nextServerState === 'down'
                ? 'Server unavailable'
                : 'Server healthy';
          const serverStateTone: SystemEventTone = nextServerState === 'recovering'
            ? 'info'
            : nextServerState === 'degraded'
              ? 'warn'
              : nextServerState === 'down'
                ? 'error'
                : 'ok';
          pushSystemEvent(
            serverStateTitle,
            [
              data.server_state_detail || (
                nextServerState === 'up'
                  ? 'Whispers reports a healthy runtime state.'
                  : 'Whispers reported a server state change.'
              ),
              nextServerState !== 'up' ? diagnosticsSummary : null,
            ].filter(Boolean).join(' '),
            serverStateTone,
          );
          lastServerStateRef.current = nextServerState;
          lastDiagnosticsSignatureRef.current = nextServerState === 'up' ? null : diagnosticsSignature;
        } else if (
          nextServerState !== 'up'
          && diagnosticsSignature
          && lastDiagnosticsSignatureRef.current !== diagnosticsSignature
        ) {
          pushSystemEvent(
            nextServerState === 'recovering' ? 'Recovery checks updated' : 'Degraded checks updated',
            diagnosticsSummary || 'Whispers reported a diagnostics change.',
            nextServerState === 'recovering' ? 'info' : 'warn',
          );
          lastDiagnosticsSignatureRef.current = diagnosticsSignature;
        } else if (nextServerState === 'up') {
          lastDiagnosticsSignatureRef.current = null;
        }
        if (
          typeof data.runtime_profile === 'string'
          && typeof data.remote_admission_mode === 'string'
          && typeof data.observability_mode === 'string'
        ) {
          applyRuntimeSnapshot({
            runtime_profile: data.runtime_profile,
            remote_admission_mode: data.remote_admission_mode,
            observability_mode: data.observability_mode,
          });
        }
      } catch (err) {
        setIsConnected(false);
        setHealthState('error');
        const message = err instanceof Error ? err.message : 'Health check failed';
        setLastError(message);
        if (surfaceStateRef.current.health !== 'error') {
          pushSystemEvent('Health check failed', message, 'error');
        }
        surfaceStateRef.current.health = 'error';
      }
    };
    fetchHealth();
    const interval = setInterval(fetchHealth, 5000);
    return () => clearInterval(interval);
  }, [authReady]);

  // Registry polling (full agent list)
  useEffect(() => {
    if (!authReady) return;
    const fetchAgents = async () => {
      try {
        const agents = await clientRef.current!.listAgents();
        startTransition(() => {
          setRegistry(agents);
        });
        // Agent presence transition detection
        const nextMap = new Map<string, { isOnline: boolean; activeMode: string }>();
        for (const agent of agents) {
          const isOnline = Boolean(agent.is_online);
          const activeMode = agent.derived_active_mode || (isOnline ? 'ready' : 'offline');
          nextMap.set(agent.callsign, { isOnline, activeMode });
        }
        const prev = prevRegistryRef.current;
        if (prev.size > 0) {
          for (const [callsign, next] of nextMap) {
            const old = prev.get(callsign);
            if (!old) continue;
            const agent = agents.find(a => a.callsign === callsign);
            const label = agent?.display_name || callsign;
            if (old.isOnline && !next.isOnline) {
              const lastSeen = agent?.session_last_seen || agent?.last_active || agent?.last_seen;
              const seenSuffix = lastSeen ? ` Last seen ${relativeTime(lastSeen)}.` : '';
              pushSystemEvent(`${callsign} went offline`, `${label} is no longer reachable.${seenSuffix}`, 'warn');
            } else if (!old.isOnline && next.isOnline) {
              pushSystemEvent(`${callsign} came online`, `${label} is now online (${next.activeMode}).`, 'ok');
            } else if (next.isOnline && old.activeMode !== next.activeMode) {
              const modeTone: SystemEventTone =
                next.activeMode === 'blocked' || next.activeMode === 'degraded' || next.activeMode === 'overloaded'
                  ? 'warn' : next.activeMode === 'ready' ? 'ok' : 'info';
              pushSystemEvent(`${callsign} is now ${next.activeMode}`, `${label} transitioned from ${old.activeMode} to ${next.activeMode}.`, modeTone);
            }
          }
        }
        prevRegistryRef.current = nextMap;

        registryFailCountRef.current = 0;
        setRegistryState('ready');
        if (surfaceStateRef.current.registry !== 'ready') {
          pushSystemEvent(
            'Agent registry live',
            `Registry loaded. ${agents.filter(agent => Boolean(agent.is_online)).length} agents currently online.`,
            'ok',
          );
        }
        surfaceStateRef.current.registry = 'ready';
      } catch (err) {
        console.error('Registry fetch failed:', err);
        // Tolerate transient failures — only mark degraded after 3 consecutive failures
        registryFailCountRef.current = (registryFailCountRef.current || 0) + 1;
        if (registryFailCountRef.current >= 3) {
          setRegistryState('error');
          if (surfaceStateRef.current.registry !== 'error') {
            const message = err instanceof Error ? err.message : 'Registry fetch failed';
            pushSystemEvent('Agent registry unavailable', message, 'warn');
          }
          surfaceStateRef.current.registry = 'error';
        }
      }
    };
    fetchAgents();
    const interval = setInterval(fetchAgents, 6000);
    return () => clearInterval(interval);
  }, [authReady]);

  useEffect(() => {
    if (!selectedAgentCallsign) return;
    const exists = registry.some(agent => agent.callsign === selectedAgentCallsign);
    if (!exists) {
      setSelectedAgentCallsign('');
    }
  }, [registry, selectedAgentCallsign]);

  useEffect(() => {
    if (workspaces.length === 0) {
      if (selectedWorkspaceId !== 'all') setSelectedWorkspaceId('all');
      return;
    }
    if (selectedWorkspaceId === 'all') return;
    const exists = workspaces.some(workspace => workspace.workspace_id === selectedWorkspaceId);
    if (!exists) {
      setSelectedWorkspaceId(workspaces[0]?.workspace_id ?? 'all');
    }
  }, [workspaces, selectedWorkspaceId]);

  // Collaboration runtime polling
  useEffect(() => {
    if (!authReady) return;
    const selectedKinds = activityKindFilter === 'handoff'
      ? ['handoff_in', 'handoff_out']
      : activityKindFilter === 'all'
        ? undefined
        : [activityKindFilter];
    const workspaceFilter = selectedWorkspaceId === 'all' ? undefined : selectedWorkspaceId;
    const agentFilter = activityAgentFilter === 'all' ? undefined : activityAgentFilter;
    const fetchCollaboration = async () => {
      try {
        const [
          nextWorkspaces,
          nextHandoffs,
          nextActivity,
          nextCollaborationHealth,
          nextConnectionStory,
          nextConversationPulses,
          nextRepoLanes,
          nextRepoDivergence,
        ] = await Promise.all([
          clientRef.current!.listWorkspaces({ status: 'active', limit: 8 }),
          clientRef.current!.listHandoffs({ limit: 8, workspaceId: workspaceFilter, unacknowledgedOnly: true }),
          clientRef.current!.listActivity({ limit: 16, workspaceId: workspaceFilter, agent: agentFilter, kinds: selectedKinds }),
          clientRef.current!.collaborationHealth(),
          clientRef.current!.connectionStory(),
          clientRef.current!.conversationPulses(),
          clientRef.current!.repoLanes(),
          clientRef.current!.repoDivergence(),
        ]);
        startTransition(() => {
          setWorkspaces(nextWorkspaces);
          setHandoffs(nextHandoffs);
          setActivity(nextActivity);
          setCollaborationSignals(nextCollaborationHealth.signals);
          setConnectionStory(nextConnectionStory);
          setConversationPulses(nextConversationPulses);
          setRepoLanes(nextRepoLanes);
          setRepoDivergence(nextRepoDivergence);
        });
        collaborationFailCountRef.current = 0;
        setCollaborationState('ready');
        if (surfaceStateRef.current.collaboration !== 'ready') {
          pushSystemEvent(
            'Collaboration runtime live',
            `Loaded ${nextWorkspaces.length} active workspaces, ${nextHandoffs.length} open handoffs, ${nextActivity.length} recent activity events, ${nextCollaborationHealth.signals.length} collaboration health signals, ${nextConversationPulses.length} conversation pulses, and ${nextRepoLanes.length} repo lanes.`,
            'ok',
          );
        }
        surfaceStateRef.current.collaboration = 'ready';
      } catch (err) {
        collaborationFailCountRef.current = (collaborationFailCountRef.current || 0) + 1;
        if (collaborationFailCountRef.current >= 3) {
          setCollaborationState('error');
          if (surfaceStateRef.current.collaboration !== 'error') {
            const message = err instanceof Error ? err.message : 'Collaboration feed failed';
            pushSystemEvent('Collaboration runtime unavailable', message, 'warn');
          }
          surfaceStateRef.current.collaboration = 'error';
        }
      }
    };
    fetchCollaboration();
    const interval = setInterval(fetchCollaboration, 8000);
    return () => clearInterval(interval);
  }, [authReady, selectedWorkspaceId, activityAgentFilter, activityKindFilter]);

  useEffect(() => {
    if (!authReady) return;

    const fetchMetrics = async () => {
      try {
        const [nextSummary, nextThroughput] = await Promise.all([
          clientRef.current!.metricsSummary(),
          clientRef.current!.metricsThroughput({ hours: 24 }),
        ]);
        startTransition(() => {
          setMetricsSummary(nextSummary);
          setThroughputBuckets(nextThroughput.buckets);
        });
        setMetricsState('ready');
      } catch (err) {
        console.error('Metrics fetch failed:', err);
        setMetricsState('error');
      }
    };

    setMetricsState('loading');
    fetchMetrics();
    const interval = setInterval(fetchMetrics, 15000);
    return () => clearInterval(interval);
  }, [authReady]);

  useEffect(() => {
    if (!authReady) return;

    operatorBoardSurfaceRef.current = 'loading';
    setOperatorBoardState('loading');
    void refreshOperatorBoard();

    const interval = setInterval(() => {
      void refreshOperatorBoard();
    }, 15000);

    return () => {
      clearInterval(interval);
      if (operatorBoardRefreshTimerRef.current) {
        clearTimeout(operatorBoardRefreshTimerRef.current);
        operatorBoardRefreshTimerRef.current = null;
      }
    };
  }, [authReady]);

  useEffect(() => {
    if (!authReady || selectedWorkspaceId === 'all') {
      setWorkspaceDetail(null);
      setWorkspaceDetailState('ready');
      return;
    }

    const fetchWorkspaceDetail = async () => {
      try {
        const detail = await clientRef.current!.workspaceState(selectedWorkspaceId);
        startTransition(() => {
          setWorkspaceDetail(detail);
        });
        setWorkspaceDetailState('ready');
      } catch (err) {
        console.error('Workspace detail fetch failed:', err);
        setWorkspaceDetailState('error');
      }
    };

    setWorkspaceDetailState('loading');
    fetchWorkspaceDetail();
    const interval = setInterval(fetchWorkspaceDetail, 5000);
    return () => clearInterval(interval);
  }, [authReady, selectedWorkspaceId]);

  // SSE live feed
  useEffect(() => {
    if (!authReady) return;
    setStreamState('loading');
    surfaceStateRef.current.stream = 'loading';
    const unsub = clientRef.current!.listen(
      (envelope) => {
        startTransition(() => {
          setMessages(prev => [envelope, ...prev].slice(0, 100));
        });
        // Pulse agent tiles on live message activity
        if (envelope.from_agent || envelope.sender) {
          triggerPulse(String(envelope.from_agent || envelope.sender));
        }
        if (envelope.to || envelope.recipient) {
          triggerPulse(String(envelope.to || envelope.recipient));
        }
      },
      (err) => {
        console.error('SSE Error:', err);
        setStreamState('error');
        if (surfaceStateRef.current.stream !== 'error') {
          pushSystemEvent(
            'Live stream interrupted',
            'Real-time updates paused. The Console will reconnect when Whispers is reachable again.',
            'warn',
          );
        }
        surfaceStateRef.current.stream = 'error';
      }
    );
    setStreamState('ready');
    pushSystemEvent('Live stream armed', 'Console is listening for live activity.', 'info');
    surfaceStateRef.current.stream = 'ready';
    return () => unsub();
  }, [authReady]);

  useEffect(() => {
    if (!authReady) return;

    pushSystemEvent('Operator stream armed', 'Console is listening for operator board deltas.', 'info');

    const unsub = clientRef.current!.listenOperatorStream(
      (events) => {
        const maxSeq = events.reduce((max, event) => Math.max(max, event.seq ?? 0), 0);
        events.forEach(relayOperatorEvent);
        scheduleOperatorBoardRefresh(maxSeq);
      },
      (err) => {
        console.error('Operator SSE Error:', err);
        setOperatorBoardState('error');
        if (operatorBoardSurfaceRef.current !== 'error') {
          pushSystemEvent(
            'Operator stream interrupted',
            'Operator board deltas paused. The Console will fall back to periodic board refreshes.',
            'warn',
          );
        }
        operatorBoardSurfaceRef.current = 'error';
      },
    );

    return () => unsub();
  }, [authReady]);

  const handleDispatch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formTo || !formBody) return;
    if (!authReady) { showToast('Not authenticated', true); return; }
    setIsDispatching(true);
    let payloadBody: unknown = formBody;
    try {
      if (formBody.trim().startsWith('{') || formBody.trim().startsWith('[')) {
        payloadBody = JSON.parse(formBody);
      }
    } catch { /* keep as string */ }
    try {
      await clientRef.current!.send({
        to: formTo.trim(),
        subject: formSubject.trim(),
        priority: formPriority as 'routine' | 'priority' | 'flash',
        body: payloadBody
      });
      showToast(`Dispatched to ${formTo}`);
      setFormBody('');
    } catch (err: unknown) {
      showToast(err instanceof Error ? err.message : 'Dispatch failed', true);
    } finally {
      setIsDispatching(false);
    }
  };

  const handleRuntimeProfileChange = async (profile: 'dev' | 'trusted_team') => {
    if (!authReady || isRuntimeUpdating || runtimeProfile === profile) return;
    setIsRuntimeUpdating(true);
    try {
      const snapshot = await clientRef.current!.runtimeUpdate({ profile });
      applyRuntimeSnapshot(snapshot);
      showToast(`Profile: ${profile === 'dev' ? 'Local Dev' : 'Trusted Team'}`);
    } catch (err) {
      showToast(err instanceof Error ? err.message : 'Update failed', true);
    } finally {
      setIsRuntimeUpdating(false);
    }
  };

  const runtimeLabel = runtimeProfile === 'trusted_team' ? 'Trusted Team' : runtimeProfile === 'dev' ? 'Local Dev' : 'Unknown';

  const borderClass = (agent: AgentRegistryEntry): string => {
    if (!agent.is_online) return 'border-offline';
    const mode = agent.derived_active_mode || 'ready';
    if (mode === 'blocked' || mode === 'degraded' || mode === 'overloaded') return 'border-critical';
    if (mode === 'busy' || agent.readiness === 'busy' || agent.readiness === 'warming') return 'border-busy';
    return 'border-ready';
  };

  const loadBgClass = (pct: number): string => {
    if (pct > 80) return 'load-bg load-bg-high';
    if (pct > 50) return 'load-bg load-bg-mid';
    return 'load-bg load-bg-low';
  };

  const renderAgentCard = (agent: WakeAwareAgent) => {
    const isOnline = Boolean(agent.is_online);
    const isSelected = selectedAgentCallsign === agent.callsign;
    const activeMode = agent.derived_active_mode || (isOnline ? 'ready' : 'offline');
    const lastSeen = agent.session_last_seen || agent.last_active || agent.last_seen;
    const contextPct = typeof agent.context_load === 'number' ? Math.round(agent.context_load * 100) : null;
    const workLabel = agent.working_on || agent.current_task || agent.cognitive_state;
    const wake = describeWakeModel(agent.wake_model);
    const wakeTitle = agent.session_kinds?.length ? `session: ${agent.session_kinds.join(', ')}` : undefined;
    const attention = deriveAgentAttention({
      attention_state: agent.attention_state,
      attention_detail: agent.attention_detail,
      progress_summary: agent.progress_summary,
      last_progress_at: agent.last_progress_at,
      runtime_updated_at: agent.runtime_updated_at,
      readiness: agent.readiness,
    });
    const attentionDetail = attention?.detail && attention.detail !== workLabel ? attention.detail : null;
    const assignedCards = executionBoard.filter(c => c.owners.some(o => o.callsign === agent.callsign));
    const boardCounters = operatorBoard?.agents[agent.callsign];
    const boardFacts = boardCounters ? [
      boardCounters.pending_assignments > 0 ? `${boardCounters.pending_assignments} pending` : null,
      boardCounters.active_assignments > 0 ? `${boardCounters.active_assignments} active` : null,
      boardCounters.blocking_reviews > 0 ? `${boardCounters.blocking_reviews} blocking reviews` : null,
      boardCounters.incoming_batons > 0 ? `${boardCounters.incoming_batons} incoming batons` : null,
      boardCounters.carrying_batons > 0 ? `${boardCounters.carrying_batons} carrying batons` : null,
      boardCounters.claimed_reviews > 0 ? `${boardCounters.claimed_reviews} claimed reviews` : null,
    ].filter((value): value is string => Boolean(value)) : [];
    const showDetailRow = contextPct !== null || workLabel || assignedCards.length > 0 || boardFacts.length > 0 || attention;

    return (
      <li
        key={agent.callsign}
        className={`agent-card agent-card-interactive ${isSelected ? 'agent-card-selected' : ''} ${isOnline ? '' : 'agent-offline'} ${borderClass(agent)} ${activityPulse[agent.callsign] ? 'agent-pulse' : ''}`}
        role="button"
        tabIndex={0}
        aria-pressed={isSelected}
        onClick={() => setSelectedAgentCallsign(agent.callsign)}
        onKeyDown={(event) => {
          if (event.key === 'Enter' || event.key === ' ') {
            event.preventDefault();
            setSelectedAgentCallsign(agent.callsign);
          }
        }}
      >
        {/* Context load as background fill — see load at a glance */}
        {contextPct !== null && contextPct > 0 && (
          <div className={loadBgClass(contextPct)} style={{ width: `${contextPct}%` }} />
        )}
        <div className={`agent-dot ${dotColor(agent)}`} />
        <div className="agent-info">
          <div className="agent-row-primary">
            <span className="agent-callsign">{agent.callsign}</span>
            {agent.display_name && <span className="agent-display-name">{agent.display_name}</span>}
            <span className="agent-type-badge">{participantBadge(agent)}</span>
            <span className="agent-type-badge">{agentTypeBadge(agent.agent_type)}</span>
          </div>
          <div className="agent-row-state">
            <span className={`state-chip state-${activeMode}`}>{activeMode}</span>
            {agent.reception_mode && agent.reception_mode !== 'open' && (
              <span className="mode-label">{agent.reception_mode.toUpperCase()}</span>
            )}
            {agent.interruptibility && agent.interruptibility !== 'free' && (
              <span className="interrupt-label">{agent.interruptibility}</span>
            )}
            {wake && (
              <span className={`wake-label wake-${wake.tone}`} title={wakeTitle}>{wake.label}</span>
            )}
            {agent.quality_risk && agent.quality_risk !== 'low' && (
              <span className={`risk-label risk-${agent.quality_risk}`}>risk:{agent.quality_risk}</span>
            )}
            {attention && (
              <span className={`attention-label attention-${attention.tone}`}>{attention.label}</span>
            )}
          </div>
          {showDetailRow && (
            <div className="agent-row-detail">
              {contextPct !== null && (
                <div className="context-load-wrap">
                  <div className="context-load-bar">
                    <div
                      className={`context-load-fill ${contextPct > 80 ? 'load-high' : contextPct > 50 ? 'load-mid' : 'load-low'}`}
                      style={{ width: `${contextPct}%` }}
                    />
                  </div>
                  <span className="context-load-pct">{contextPct}%</span>
                </div>
              )}
              <div className="agent-cell-work">
                {workLabel && <span className="agent-work" title={workLabel}>{workLabel}</span>}
                {assignedCards.length > 0 && (
                  <div className="agent-assignments">
                    {assignedCards.map(c => (
                      <span key={c.id} className={`assignment-chip assignment-${c.state}`} title={c.summary}>
                        {c.tranche}: {c.title}
                      </span>
                    ))}
                  </div>
                )}
                {boardFacts.length > 0 && (
                  <div className="agent-assignments">
                    {boardFacts.map(fact => (
                      <span key={`${agent.callsign}-${fact}`} className="focus-chip">
                        {fact}
                      </span>
                    ))}
                  </div>
                )}
                {(attentionDetail || attention?.freshness) && (
                  <div className="agent-attention-meta">
                    {attentionDetail && <span className="agent-attention-detail" title={attentionDetail}>{attentionDetail}</span>}
                    {attention?.freshness && <span className="agent-attention-age">{attention.freshness}</span>}
                  </div>
                )}
              </div>
            </div>
          )}
          {!isOnline && lastSeen && (
            <div className="agent-row-lastseen">{relativeTime(lastSeen)}</div>
          )}
        </div>
      </li>
    );
  };

  const renderBatonChip = (
    chip: {
      key: string;
      glyph: string;
      label: string;
      tone: 'waiting' | 'active' | 'review' | 'blocked' | 'expired' | 'done';
      title?: string | null;
      ageLabel?: string | null;
      stale?: boolean;
    },
    prefix: string,
  ) => (
    <span
      key={`${prefix}-${chip.key}`}
      className={`baton-chip baton-chip-${chip.tone} ${chip.stale ? 'baton-chip-stale' : ''}`}
      title={chip.title ?? undefined}
    >
      <span className="baton-chip-glyph" aria-hidden="true">{chip.glyph}</span>
      <span>{chip.label}</span>
      {chip.ageLabel && (
        <span className={`baton-chip-age ${chip.stale ? 'baton-chip-age-stale' : ''}`}>{chip.ageLabel}</span>
      )}
    </span>
  );

  const renderHuddlePeerCard = (peer: typeof huddlePeers[number]) => {
    const batonChips: Array<{
      key: string;
      glyph: string;
      label: string;
      tone: 'waiting' | 'active' | 'review' | 'blocked' | 'expired' | 'done';
      title?: string | null;
    }> = [];
    if (peer.incomingBaton) {
      batonChips.push({
        key: `${peer.callsign}-incoming`,
        glyph: '←',
        label: `waiting x${Math.max(peer.incomingBatonCount, 1)}`,
        tone: 'waiting',
        title: 'Incoming baton pressure from this peer.',
      });
    }
    if (peer.outgoingBaton) {
      batonChips.push({
        key: `${peer.callsign}-outgoing`,
        glyph: '→',
        label: `active x${Math.max(peer.outgoingBatonCount, 1)}`,
        tone: 'active',
        title: 'Outgoing baton currently in motion with this peer.',
      });
    }

    return (
      <div key={peer.callsign} className="huddle-peer-card">
        <div className="huddle-peer-top">
          <span className="huddle-peer-name">{peer.callsign}</span>
          <span className={`state-chip state-${peer.readiness}`}>{peer.readiness}</span>
        </div>
        {peer.sharedWorkspaces.length > 0 && (
          <div className="huddle-peer-detail">
            {peer.sharedWorkspaces.join(', ')}
          </div>
        )}
        {batonChips.length > 0 && (
          <div className="baton-chip-list huddle-chip-list">
            {batonChips.map(chip => renderBatonChip(chip, `huddle-${peer.callsign}`))}
          </div>
        )}
        {!peer.sharedWorkspaces.length && peer.workingOn && (
          <div className="huddle-peer-detail">{peer.workingOn}</div>
        )}
      </div>
    );
  };

  const renderCaptainAlertCard = (alert: CaptainAlertCard, index: number) => {
    const sender = alert.sender ?? 'peer';
    const label = alert.label ?? alert.kind ?? 'packet';
    const detail = alert.detail ?? alert.subject ?? 'Fresh peer packet waiting on captain review.';
    const tone = label.includes('completion') ? 'active' : 'review';
    const glyph = label.includes('completion') ? '✓' : '◈';
    const chipLabel = label.includes('completion') ? 'completion waiting' : `${label} pending`;
    return (
      <div key={`captain-${sender}-${index}`} className="huddle-peer-card huddle-peer-card-alert">
        <div className="huddle-peer-top">
          <span className="huddle-peer-name">{sender}</span>
          <span className="state-chip state-busy">{label}</span>
        </div>
        <div className="huddle-peer-detail">{detail}</div>
        <div className="baton-chip-list huddle-chip-list">
          {renderBatonChip(
            {
              key: 'captain-queue',
              glyph,
              label: chipLabel,
              tone,
              title: 'Fresh peer packet waiting on captain review.',
              ageLabel: alert.created_at ? relativeTime(alert.created_at) : null,
            },
            `captain-${sender}-${index}`,
          )}
        </div>
      </div>
    );
  };

  const renderExecutionCard = (card: ReturnType<typeof deriveExecutionBoard>[number]) => (
    <article key={card.id} className={`execution-card execution-card-${card.state}`}>
      <div className="execution-card-top">
        <span className="execution-tranche">{card.tranche}</span>
        <span className={`execution-state execution-state-${card.state}`}>{card.state}</span>
      </div>
      <div className="execution-card-title">{card.title}</div>
      <p className="execution-card-summary">{card.summary}</p>
      <div className="execution-card-section">
        <span className="execution-card-label">Live</span>
        <p>{card.liveSignal}</p>
      </div>
      {card.owners.length > 0 && (
        <div className="execution-card-section">
          <span className="execution-card-label">Owners</span>
          <div className="execution-owner-list">
            {card.owners.map((owner) => {
              const ownerClass = !owner.isOnline
                ? 'execution-owner-offline'
                : owner.activeMode === 'busy' || owner.readiness === 'busy' || owner.readiness === 'warming'
                  ? 'execution-owner-busy'
                  : 'execution-owner-online';
              return (
                <span key={`${card.id}-${owner.callsign}`} className={`execution-owner ${ownerClass}`}>
                  <span>{owner.callsign}</span>
                  <span className="execution-owner-state">{owner.workLabel || owner.activeMode}</span>
                </span>
              );
            })}
          </div>
        </div>
      )}
      {card.highlights.length > 0 && (
        <div className="execution-card-section">
          <span className="execution-card-label">Signals</span>
          <div className="execution-owner-focus">
            {card.highlights.map((highlight) => (
              <span key={`${card.id}-${highlight}`} className="execution-focus-chip">{highlight}</span>
            ))}
          </div>
        </div>
      )}
      <div className="execution-card-section execution-card-meta">
        <span className="execution-card-label">Acceptance Bar</span>
        <p>{card.acceptanceBar}</p>
      </div>
    </article>
  );

  const renderUnifiedFeedItem = (item: UnifiedFeedItem) => (
    <article
      key={item.id}
      className={`system-card feed-stream-card system-card-${item.tone} ${item.workspaceLabel ? 'feed-stream-card-interactive' : ''}`}
      onClick={item.workspaceLabel ? () => setSelectedWorkspaceId(item.workspaceLabel!) : undefined}
    >
      <div className="system-card-top feed-stream-top">
        <div className="feed-stream-heading">
          <span className={`feed-kind-badge feed-kind-${item.kind}`}>{item.badge}</span>
          <span className="system-card-title">{item.title}</span>
        </div>
        {item.createdAt && <span className="system-card-time">{relativeTime(item.createdAt)}</span>}
      </div>
      {item.batonChips.length > 0 && (
        <div className="baton-chip-list collaboration-chip-list">
          {item.batonChips.map(chip => renderBatonChip(chip, item.id))}
        </div>
      )}
      <p className="system-card-detail">{item.detail}</p>
      <div className="system-card-meta feed-stream-meta">
        <span className="system-card-source">{item.sourceLabel}</span>
        {item.workspaceLabel && <span className="system-card-source">{item.workspaceLabel}</span>}
      </div>
    </article>
  );

  const renderAgentFocusFeedItem = (item: UnifiedFeedItem) => (
    <div key={`agent-focus-${item.id}`} className="agent-focus-event">
      <div className="agent-focus-event-top">
        <span className={`feed-kind-badge feed-kind-${item.kind}`}>{item.badge}</span>
        {item.createdAt && <span className="agent-focus-event-time">{relativeTime(item.createdAt)}</span>}
      </div>
      <div className="agent-focus-event-title">{item.title}</div>
      <p className="agent-focus-event-detail">{item.detail}</p>
    </div>
  );

  return (
    <div className="app-container">
      <header className="app-header">
        <div className="header-brand">
          <div className={`status-dot ${isConnected ? 'online' : ''}`} />
          <h1>Whispers <span className="header-subtitle">Console</span></h1>
        </div>
        <div className="header-view-switch" role="tablist" aria-label="Console surfaces">
          <button
            type="button"
            className={`view-switch-button ${surfaceView === 'collaboration' ? 'view-switch-button-active' : ''}`}
            onClick={() => setSurfaceView('collaboration')}
          >
            Collaboration
          </button>
          <button
            type="button"
            className={`view-switch-button ${surfaceView === 'metrics' ? 'view-switch-button-active' : ''}`}
            onClick={() => setSurfaceView('metrics')}
          >
            Metrics
          </button>
        </div>
        <div className="header-metrics">
          <div className="metric">
            <span className="metric-label">Primary</span>
            <span className="metric-value">
              <span className="metric-highlight">{onlineAgents.length}</span>
              <span className="metric-dim"> / {primaryRegistry.length}</span>
            </span>
          </div>
          <div className="metric">
            <span className="metric-label">Pending</span>
            <span className={`metric-value ${pendingMessages > 0 ? 'metric-warn' : ''}`}>{pendingMessages}</span>
          </div>
          <div className="metric">
            <span className="metric-label">Profile</span>
            <span className="metric-value">{runtimeLabel}</span>
          </div>
          <div className="metric">
            <span className="metric-label">Health</span>
            <span className={`metric-value metric-status metric-status-${consoleHealth.tone}`}>{consoleHealth.tone}</span>
          </div>
        </div>
      </header>

      {surfaceView === 'collaboration' ? (
      <main className="glance-grid">
        {/* ── AGENTS PANEL ── */}
        <section className="glance-panel glance-agents">
          <div className="glance-panel-header">
            <h2>Agents</h2>
            <span className="glance-count">{onlineAgents.length} online</span>
          </div>
          <div className="glance-agents-list">
            {onlineAgents.map(agent => {
              const activeMode = agent.derived_active_mode || (agent.is_online ? 'ready' : 'offline');
              const workLabel = agent.working_on || agent.current_task || agent.cognitive_state;
              const contextPct = typeof agent.context_load === 'number' ? Math.round(agent.context_load * 100) : null;
              const isSelected = selectedAgentCallsign === agent.callsign;
              return (
                <div
                  key={agent.callsign}
                  className={`glance-agent-tile ${isSelected ? 'glance-agent-selected' : ''} ${activityPulse[agent.callsign] ? 'agent-pulse' : ''}`}
                  onClick={() => setSelectedAgentCallsign(isSelected ? '' : agent.callsign)}
                  role="button"
                  tabIndex={0}
                  onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); setSelectedAgentCallsign(isSelected ? '' : agent.callsign); } }}
                >
                  <div className="glance-agent-header">
                    <div className={`glance-agent-dot dot-${dotColor(agent).replace('dot-', '')}`} />
                    <span className="glance-agent-name">{agent.display_name || agent.callsign}</span>
                    <span className={`glance-state-chip glance-state-${activeMode}`}>{activeMode}</span>
                  </div>
                  {workLabel && <div className="glance-agent-work">{workLabel}</div>}
                  {contextPct !== null && contextPct > 0 && (
                    <div className="glance-load-bar">
                      <div className={`glance-load-fill ${contextPct > 80 ? 'load-high' : contextPct > 50 ? 'load-mid' : 'load-low'}`} style={{ width: `${contextPct}%` }} />
                    </div>
                  )}
                </div>
              );
            })}
            {offlineAgents.length > 0 && (
              <div className="glance-offline-count">{offlineAgents.length} offline</div>
            )}
          </div>
          {/* Agent detail moved to right panel */}
        </section>

        {/* ── ACTIVITY PANEL ── */}
        <section className="glance-panel glance-activity">
          <div className="glance-panel-header">
            <h2>Activity{selectedAgentCallsign ? ` — ${selectedAgentCallsign}` : ''}</h2>
            <span className="glance-count">{filteredUnifiedFeed.length} events</span>
          </div>
          <div className="glance-activity-stream">
            {filteredUnifiedFeed.length === 0 ? (
              <div className="glance-empty">Waiting for activity...</div>
            ) : (
              filteredUnifiedFeed.slice(0, 50).map((item, idx) => {
                const prev = idx > 0 ? filteredUnifiedFeed[idx - 1] : null;
                if (prev && prev.title === item.title && prev.detail === item.detail && prev.agents?.join() === item.agents?.join()) return null;
                const time = item.createdAt ? new Date(item.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '';
                const agentLabel = item.agents?.length ? item.agents.join(', ') : null;
                const isHighlighted = selectedAgentCallsign && item.agents?.includes(selectedAgentCallsign);
                return (
                  <div key={item.id || `feed-${idx}`} className={`glance-activity-item glance-activity-${item.tone || 'info'} ${isHighlighted ? 'glance-activity-highlight' : ''}`}>
                    <span className="glance-activity-time">{time}</span>
                    <span className={`glance-activity-badge glance-badge-${item.kind}`}>{item.badge || item.kind}</span>
                    <div className="glance-activity-content">
                      <div className="glance-activity-headline">
                        {agentLabel && <strong className="glance-activity-agent">{agentLabel}</strong>}
                        {agentLabel && <span className="glance-activity-sep">&middot;</span>}
                        <span>{item.title}</span>
                      </div>
                      {item.detail && <div className="glance-activity-detail">{item.detail}</div>}
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </section>

        {/* ── RIGHT PANEL: Agent Detail or Attention ── */}
        <section className="glance-panel glance-right">
          <div className="glance-panel-header">
            {selectedAgent ? (
              <>
                <h2>{selectedAgent.display_name || selectedAgent.callsign}</h2>
                <button className="glance-detail-close" onClick={() => setSelectedAgentCallsign('')}>&times;</button>
              </>
            ) : (
              <h2>Attention</h2>
            )}
          </div>
          {selectedAgent ? (
          <div className="glance-agent-detail-full">
            <div className="glance-detail-section">
              <div className="glance-detail-line"><span className="glance-detail-key">state</span> <span className={`glance-state-chip glance-state-${selectedAgent.derived_active_mode || 'ready'}`}>{selectedAgent.derived_active_mode || 'ready'}</span></div>
              <div className="glance-detail-line"><span className="glance-detail-key">type</span> {agentTypeBadge(selectedAgent.agent_type)} &middot; {participantBadge(selectedAgent)}</div>
              {selectedAgent.reception_mode && <div className="glance-detail-line"><span className="glance-detail-key">mode</span> {selectedAgent.reception_mode}</div>}
              {typeof selectedAgent.context_load === 'number' && <div className="glance-detail-line"><span className="glance-detail-key">load</span> {Math.round(selectedAgent.context_load * 100)}%</div>}
            </div>
            {(selectedAgent.current_task || selectedAgent.progress_summary || selectedAgent.attention_detail) && (
              <div className="glance-detail-section">
                <div className="glance-detail-section-title">Current Work</div>
                {selectedAgent.current_task && <div className="glance-detail-block">{selectedAgent.current_task}</div>}
                {selectedAgent.progress_summary && <div className="glance-detail-block glance-detail-secondary">{selectedAgent.progress_summary}</div>}
                {selectedAgent.attention_detail && <div className="glance-detail-block glance-detail-secondary">{selectedAgent.attention_detail}</div>}
              </div>
            )}
            {selectedAgent.working_on && selectedAgent.working_on !== selectedAgent.current_task && (
              <div className="glance-detail-section">
                <div className="glance-detail-section-title">Intent</div>
                <div className="glance-detail-block">{selectedAgent.working_on}</div>
              </div>
            )}
          </div>
          ) : (
          <div className="glance-attention-list">
            {onlineAgents.filter(a => (a.derived_active_mode || '') === 'blocked' || (a.derived_active_mode || '') === 'degraded').map(agent => (
              <div key={`attn-blocked-${agent.callsign}`} className="glance-attention-item glance-attention-urgent">
                <span className="glance-attention-icon">&#x26A0;</span>
                <div>
                  <div className="glance-attention-title">{agent.callsign} is {agent.derived_active_mode}</div>
                  <div className="glance-attention-detail">{agent.attention_detail || agent.current_task || 'No detail reported'}</div>
                </div>
              </div>
            ))}
            {((swarmState as Record<string, any>)?.pending_by_priority?.flash ?? 0) > 0 && (
              <div className="glance-attention-item glance-attention-urgent">
                <span className="glance-attention-icon">&#x26A1;</span>
                <div>
                  <div className="glance-attention-title">Flash messages waiting</div>
                  <div className="glance-attention-detail">Check inbox immediately</div>
                </div>
              </div>
            )}
            {openHandoffs.map((h, i) => (
              <div key={`attn-handoff-${i}`} className="glance-attention-item glance-attention-warn">
                <span className="glance-attention-icon">&#x2709;</span>
                <div>
                  <div className="glance-attention-title">{h.route}</div>
                  <div className="glance-attention-detail">{h.nextAction || h.subject || 'Open handoff'}</div>
                </div>
              </div>
            ))}
            {assignmentAlerts.map((alert, i) => (
              <div key={`attn-assign-${i}`} className="glance-attention-item glance-attention-warn">
                <span className="glance-attention-icon">&#x279C;</span>
                <div>
                  <div className="glance-attention-title">{alert.callsign ?? alert.agent_name ?? 'Agent'} needs assignment</div>
                  <div className="glance-attention-detail">{String(alert.attention_detail ?? alert.detail ?? 'Ready for routing')}</div>
                </div>
              </div>
            ))}
            {collaborationSignals.filter(s => s.severity === 'escalate' || s.severity === 'warning').map((sig, i) => (
              <div key={`attn-health-${i}`} className="glance-attention-item glance-attention-warn">
                <span className="glance-attention-icon">&#x2731;</span>
                <div>
                  <div className="glance-attention-title">{sig.signal}</div>
                  <div className="glance-attention-detail">{String(sig.detail ?? '')}</div>
                </div>
              </div>
            ))}
            {onlineAgents.filter(a => (a.derived_active_mode || '') === 'blocked' || (a.derived_active_mode || '') === 'degraded').length === 0
              && openHandoffs.length === 0
              && assignmentAlerts.length === 0
              && collaborationSignals.filter(s => s.severity === 'escalate' || s.severity === 'warning').length === 0
              && (
              <div className="glance-all-clear">
                <div className="glance-all-clear-dot" />
                All clear
              </div>
            )}
          </div>
          )}
        </section>

        {/* ── STATUS BAR ── */}
        <footer className="glance-status-bar">
          <span className={`glance-status-dot glance-status-${consoleHealth.tone}`} />
          <span>{consoleHealth.title}</span>
          <span>&middot;</span>
          <span>{runtimeLabel}</span>
          <span>&middot;</span>
          <span>{onlineAgents.length} primary</span>
          <span>&middot;</span>
          <span>{swarmState?.my_mode || '?'}</span>
          <span>&middot;</span>
          <span>{new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
        </footer>
      </main>
      ) : (surfaceView as string) === '_legacy' ? (
      <main className="dashboard-grid">
        <section className={`health-banner health-banner-${consoleHealth.tone}`}>
          <div className="health-banner-main">
            <div
              className="health-summary-row health-summary-clickable"
              onClick={() => setHealthExpanded(prev => !prev)}
              role="button"
              tabIndex={0}
              onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); setHealthExpanded(prev => !prev); } }}
              title={healthExpanded ? 'Collapse health details' : 'Expand health details'}
            >
              <span className={`health-pill health-pill-${consoleHealth.tone}`}>{consoleHealth.title}</span>
              <p>{consoleHealth.detail}</p>
              <span className="health-expand-icon">{healthExpanded ? '\u25B4' : '\u25BE'}</span>
            </div>
            {healthExpanded && (consoleDiagnostics.failingChecks.length > 0 || diagnosticHints.length > 0) && (
              <div className="health-diagnostics">
                {consoleDiagnostics.failingChecks.length > 0 && (
                  <div className="health-detail-row">
                    <span className="health-detail-label">Failing</span>
                    <div className="health-chip-list">
                      {consoleDiagnostics.failingChecks.map(check => (
                        <span key={check} className={`health-check health-check-${consoleHealth.tone}`}>
                          {check}
                        </span>
                      ))}
                    </div>
                  </div>
                )}
                {diagnosticHints.length > 0 && (
                  <div className="health-detail-row">
                    <span className="health-detail-label">Next</span>
                    <p className="health-hint-list">{diagnosticHints.join(' ')}</p>
                  </div>
                )}
              </div>
            )}
            {healthExpanded && <div className="health-diagnostics">
              <div className="health-detail-row">
                <span className="health-detail-label">Landscape</span>
                <div className="health-chip-list">
                  <span className="landscape-chip landscape-chip-ready">Ready {landscapeCounts.ready}</span>
                  <span className="landscape-chip landscape-chip-busy">Busy {landscapeCounts.busy}</span>
                  <span className="landscape-chip landscape-chip-blocked">Blocked {landscapeCounts.blocked}</span>
                  <span className="landscape-chip landscape-chip-degraded">Degraded {landscapeCounts.degraded}</span>
                  <span className="landscape-chip landscape-chip-offline">Offline {landscapeCounts.offline}</span>
                </div>
              </div>
              {participantCounts.otherRegistered > 0 && (
                <div className="health-detail-row">
                  <span className="health-detail-label">Secondary</span>
                  <div className="health-chip-list">
                    {participantCounts.buckets.automaton.registered > 0 && (
                      <span className="focus-chip">Automata {participantCounts.buckets.automaton.registered}</span>
                    )}
                    {participantCounts.buckets.ephemeral.registered > 0 && (
                      <span className="focus-chip">Ephemeral {participantCounts.buckets.ephemeral.registered}</span>
                    )}
                    {participantCounts.otherOnline > 0 && (
                      <span className="focus-chip">Online {participantCounts.otherOnline}</span>
                    )}
                  </div>
                </div>
              )}
              {focusSummaries.length > 0 && (
                <div className="health-detail-row">
                  <span className="health-detail-label">Now</span>
                  <div className="health-chip-list">
                    {focusSummaries.map(item => (
                      <span key={`${item.callsign}-${item.summary}`} className="focus-chip">
                        {item.callsign}: {item.summary}
                      </span>
                    ))}
                  </div>
                </div>
              )}
              {captainAlerts.length > 0 && (
                <div className="health-detail-row">
                  <span className="health-detail-label">Captain</span>
                  <div className="huddle-peer-list">
                    {captainAlerts.map(renderCaptainAlertCard)}
                  </div>
                </div>
              )}
              {(huddlePeers.length > 0 || assignmentAlerts.length > 0) && (
                <div className="health-detail-row">
                  <span className="health-detail-label">Huddle</span>
                  <div className="huddle-peer-list">
                    {huddlePeers.map(renderHuddlePeerCard)}
                    {assignmentAlerts.map((alert, index) => (
                      <div key={`assignment-${alert.callsign ?? alert.agent_name ?? index}`} className="huddle-peer-card huddle-peer-card-alert">
                        <div className="huddle-peer-top">
                          <span className="huddle-peer-name">{alert.callsign ?? alert.agent_name ?? 'peer'}</span>
                          <span className="state-chip state-busy">needs route</span>
                        </div>
                        <div className="huddle-peer-detail">
                          {alert.attention_detail ?? alert.detail ?? alert.current_task ?? 'Waiting on next assignment.'}
                        </div>
                        <div className="baton-chip-list huddle-chip-list">
                          {renderBatonChip(
                            {
                              key: 'assignment-ready',
                              glyph: '◈',
                              label: alert.operator_nudge_required ? 'manual wake' : 'ready now',
                              tone: alert.operator_nudge_required ? 'review' : 'active',
                              title: alert.operator_nudge_required
                                ? 'This peer is ready but needs an explicit nudge because they are manual-wake.'
                                : 'This peer is ready for immediate routing.',
                            },
                            `assignment-${alert.callsign ?? alert.agent_name ?? index}`,
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>}
          </div>
          <span className="health-banner-side">{runtimeLabel} · {swarmState?.my_mode || 'mode unknown'}</span>
        </section>

        <section className="panel execution-board-panel">
          <div className="panel-header">
            <h2>Execution Board</h2>
            <div className="panel-header-actions">
              <span className="feed-stat">{executionBoard.length} lanes</span>
              <span className="feed-stat">{executionBoard.filter(card => card.state === 'active').length} live</span>
              <span className="feed-stat">operator {operatorBoardState}</span>
              {operatorBoard && <span className="feed-stat">seq {operatorBoard.sequence_id}</span>}
              {livePendingAssignments > 0 && <span className="feed-stat">{livePendingAssignments} pending</span>}
              {liveBlockingReviews > 0 && <span className="feed-stat">{liveBlockingReviews} blocking</span>}
              {executionBoard.some(card => card.state === 'blocked') && (
                <span className="feed-stat">blocked lanes</span>
              )}
            </div>
          </div>
          <div className="execution-board-grid">
            {executionBoard.map(renderExecutionCard)}
          </div>
        </section>

        {/* Runtime Surface Panel */}
        <section className="panel registry-panel">
          <div className="panel-header">
            <h2>Runtime Surface</h2>
            <span className="header-count">{onlineAgents.length} online · {primaryRegistry.length} primary</span>
          </div>
          <div className="registry-scroll">
            {onlineAgents.length > 0 && (
              <ul className="agent-list">
                {onlineAgents.map(renderAgentCard)}
              </ul>
            )}
            {offlineAgents.length > 0 && (
              <>
                <div className="section-divider">
                  <span>Offline ({offlineAgents.length})</span>
                </div>
                <ul className="agent-list agent-list-dim">
                  {offlineAgents.map(renderAgentCard)}
                </ul>
              </>
            )}
            {secondaryRegistry.length > 0 && (
              <>
                <div className="section-divider">
                  <span>Secondary tracked participants ({secondaryRegistry.length})</span>
                </div>
                <div className="health-chip-list">
                  {participantCounts.buckets.automaton.registered > 0 && (
                    <span className="focus-chip">Automata {participantCounts.buckets.automaton.registered}</span>
                  )}
                  {participantCounts.buckets.ephemeral.registered > 0 && (
                    <span className="focus-chip">Ephemeral {participantCounts.buckets.ephemeral.registered}</span>
                  )}
                  {secondaryOnlineAgents.length > 0 && (
                    <span className="focus-chip">Online {secondaryOnlineAgents.length}</span>
                  )}
                  {secondaryOfflineAgents.length > 0 && (
                    <span className="focus-chip">Offline {secondaryOfflineAgents.length}</span>
                  )}
                </div>
                {secondaryOnlineAgents.length > 0 && (
                  <ul className="agent-list agent-list-dim">
                    {secondaryOnlineAgents.map(renderAgentCard)}
                  </ul>
                )}
              </>
            )}
            {primaryRegistry.length === 0 && secondaryRegistry.length === 0 && (
              <div className="empty-state">
                <p>{registryEmptyCopy}</p>
              </div>
            )}
          </div>
        </section>

        {/* Live Feed Panel */}
        <section className="panel feed-panel">
          <div className="panel-header">
            <h2>Live Feed</h2>
            <div className="panel-header-actions">
              <span className="feed-stat">{filteredUnifiedFeed.length} items</span>
              <span className="feed-stat">{workspaceCards.length} ws</span>
              <span className="feed-stat">{openHandoffs.length} handoffs</span>
              {livePendingAssignments > 0 && <span className="feed-stat">{livePendingAssignments} assignments</span>}
              {liveBlockingReviews > 0 && <span className="feed-stat">{liveBlockingReviews} blocking reviews</span>}
              {waitingOnReview > 0 && <span className="feed-stat">{waitingOnReview} waiting</span>}
              {totalBatonsInFlight > 0 && <span className="feed-stat">{totalBatonsInFlight} batons</span>}
              {operatorBoard && <span className="feed-stat">board {operatorBoard.sequence_id}</span>}
              {collaborationSignalCount > 0 && <span className="feed-stat">{collaborationSignalCount} health</span>}
              <span className="feed-mode-badge">{observabilityMode === 'full' ? 'Full' : 'Metadata'}</span>
              <button className="btn-icon" onClick={() => setMessages([])} title="Clear">
                &#x2715;
              </button>
            </div>
          </div>
          <div className="feed-toolbar">
            <div className="feed-filter">
              <label>Workspace</label>
              <select value={selectedWorkspaceId} onChange={e => setSelectedWorkspaceId(e.target.value)}>
                <option value="all">All workspaces</option>
                {workspaces.map(workspace => (
                  <option key={workspace.workspace_id} value={workspace.workspace_id}>
                    {workspace.name || workspace.workspace_id}
                  </option>
                ))}
              </select>
            </div>
            <div className="feed-filter">
              <label>Agent</label>
              <select
                value={activityAgentFilter}
                onChange={e => {
                  const nextAgent = e.target.value;
                  setActivityAgentFilter(nextAgent);
                  if (nextAgent === 'all') return;
                  setSelectedAgentCallsign(nextAgent);
                }}
              >
                <option value="all">All agents</option>
                {activityAgents.map(agent => (
                  <option key={agent} value={agent}>{agent}</option>
                ))}
              </select>
            </div>
            <div className="feed-filter">
              <label>Kind</label>
              <select value={activityKindFilter} onChange={e => setActivityKindFilter(e.target.value)}>
                <option value="all">All events</option>
                <option value="workspace">Workspace</option>
                <option value="handoff">Handoffs</option>
                <option value="health">Health</option>
                <option value="runtime">Runtime</option>
                <option value="signal">Signals</option>
                <option value="system">System</option>
                <option value="message">Messages</option>
              </select>
            </div>
          </div>
          <div className="feed-scroll">
            {filteredUnifiedFeed.length === 0 ? (
              <div className="feed-empty">
                <div className="feed-empty-pulse" />
                <p>{unifiedFeed.length === 0 ? feedEmptyTitle : 'No feed items match the current filters'}</p>
                <p className="feed-empty-detail">{unifiedFeed.length === 0 ? feedEmptyDetail : 'Adjust workspace, agent, or kind filters to widen the live feed.'}</p>
                <code>{unifiedFeed.length === 0 ? '/message:stream' : 'filters active'}</code>
              </div>
            ) : (
              <div className="feed-stream">
                {filteredUnifiedFeed.map(renderUnifiedFeedItem)}
              </div>
            )}
          </div>
        </section>

        {/* Control Panel */}
        <section className="panel control-panel">
          <div className="panel-header">
            <h2>{selectedAgent ? 'Agent Focus' : selectedWorkspace ? 'Workspace Detail' : 'Controls'}</h2>
          </div>
          <div className="control-scroll">
            {injectionStatus && (
              <div className={`toast ${injectionStatus.isError ? 'toast-error' : 'toast-ok'}`}>
                {injectionStatus.msg}
              </div>
            )}

            <div className="control-section">
              <div className="control-section-title">Agent Focus</div>
              {selectedAgent ? (
                <div className="workspace-detail-card agent-focus-card">
                  <div className="workspace-detail-top">
                    <div>
                      <div className="workspace-detail-title">{selectedAgent.callsign}</div>
                      <div className="workspace-detail-subtitle">
                        {selectedAgent.display_name || selectedAgentWorkLabel || 'No explicit task reported yet.'}
                      </div>
                    </div>
                    <button type="button" className="btn-sm" onClick={() => setSelectedAgentCallsign('')}>
                      Clear
                    </button>
                  </div>
                  <div className="agent-focus-badges">
                    <span className={`state-chip state-${selectedAgent.derived_active_mode || selectedAgent.readiness || 'ready'}`}>
                      {selectedAgent.derived_active_mode || selectedAgent.readiness || 'ready'}
                    </span>
                    <span className="agent-type-badge">{participantBadge(selectedAgent)}</span>
                    <span className="agent-type-badge">{agentTypeBadge(selectedAgent.agent_type)}</span>
                    {selectedAgent.reception_mode && (
                      <span className="mode-label">{selectedAgent.reception_mode.toUpperCase()}</span>
                    )}
                    {selectedAgent.interruptibility && (
                      <span className="interrupt-label">{selectedAgent.interruptibility}</span>
                    )}
                    {selectedAgentWake && (
                      <span className={`wake-label wake-${selectedAgentWake.tone}`}>{selectedAgentWake.label}</span>
                    )}
                    {selectedAgent.quality_risk && selectedAgent.quality_risk !== 'low' && (
                      <span className={`risk-label risk-${selectedAgent.quality_risk}`}>risk:{selectedAgent.quality_risk}</span>
                    )}
                    {selectedAgentAttention && (
                      <span className={`attention-label attention-${selectedAgentAttention.tone}`}>{selectedAgentAttention.label}</span>
                    )}
                  </div>
                  <div className="workspace-detail-meta">
                    {selectedAgentLastSeen && <span>seen {relativeTime(selectedAgentLastSeen)}</span>}
                    {selectedAgent.last_progress_at && <span>progress {relativeTime(selectedAgent.last_progress_at)}</span>}
                    {typeof selectedAgent.context_load === 'number' && <span>load {Math.round(selectedAgent.context_load * 100)}%</span>}
                    {selectedAgent.current_task && <span>task active</span>}
                    {selectedAgentAssignments.length > 0 && <span>{selectedAgentAssignments.length} live lanes</span>}
                    {selectedAgentBoardCounters && <span>board seq {operatorBoard?.sequence_id ?? 0}</span>}
                    {selectedAgentBoardCounters && operatorBoardAsOf && <span>snapshot {relativeTime(operatorBoardAsOf)}</span>}
                  </div>
                  <div className="agent-focus-grid">
                    <div className="workspace-detail-section">
                      <div className="workspace-detail-label">Current</div>
                      <div className="agent-focus-stack">
                        {selectedAgent.current_task && (
                          <div className="agent-focus-line">
                            <span className="agent-focus-key">task</span>
                            <span>{selectedAgent.current_task}</span>
                          </div>
                        )}
                        {selectedAgentWorkLabel && selectedAgentWorkLabel !== selectedAgent.current_task && (
                          <div className="agent-focus-line">
                            <span className="agent-focus-key">working</span>
                            <span>{selectedAgentWorkLabel}</span>
                          </div>
                        )}
                        {selectedAgent.progress_summary && (
                          <div className="agent-focus-line">
                            <span className="agent-focus-key">progress</span>
                            <span>{selectedAgent.progress_summary}</span>
                          </div>
                        )}
                        {selectedAgentAttention?.detail && (
                          <div className="agent-focus-line">
                            <span className="agent-focus-key">attention</span>
                            <span>{selectedAgentAttention.detail}</span>
                          </div>
                        )}
                        {!selectedAgent.current_task && !selectedAgentWorkLabel && !selectedAgent.progress_summary && !selectedAgentAttention?.detail && (
                          <p className="workspace-detail-empty">No current slice reported yet.</p>
                        )}
                      </div>
                    </div>
                    <div className="workspace-detail-section">
                      <div className="workspace-detail-label">Assignments</div>
                      {selectedAgentBoardCounters && (
                        <div className="agent-focus-stack">
                          <div className="agent-focus-line">
                            <span className="agent-focus-key">active</span>
                            <span>{selectedAgentBoardCounters.active_assignments}</span>
                          </div>
                          <div className="agent-focus-line">
                            <span className="agent-focus-key">pending</span>
                            <span>{selectedAgentBoardCounters.pending_assignments}</span>
                          </div>
                          <div className="agent-focus-line">
                            <span className="agent-focus-key">reviews</span>
                            <span>{selectedAgentBoardCounters.blocking_reviews} blocking · {selectedAgentBoardCounters.claimed_reviews} claimed</span>
                          </div>
                          <div className="agent-focus-line">
                            <span className="agent-focus-key">batons</span>
                            <span>{selectedAgentBoardCounters.incoming_batons} incoming · {selectedAgentBoardCounters.carrying_batons} carrying</span>
                          </div>
                        </div>
                      )}
                      {selectedAgentAssignments.length > 0 ? (
                        <div className="agent-focus-chip-list">
                          {selectedAgentAssignments.map(card => (
                            <span key={`agent-focus-${card.id}`} className={`assignment-chip assignment-${card.state}`}>
                              {card.tranche}: {card.title}
                            </span>
                          ))}
                        </div>
                      ) : !selectedAgentBoardCounters ? (
                        <p className="workspace-detail-empty">No execution-board lanes attached right now.</p>
                      ) : null}
                    </div>
                    <div className="workspace-detail-section">
                      <div className="workspace-detail-label">Coordination</div>
                      <div className="agent-focus-stack">
                        {selectedAgentCaptainAlert && (
                          <div className="agent-focus-line">
                            <span className="agent-focus-key">captain</span>
                            <span>{selectedAgentCaptainAlert.label ?? selectedAgentCaptainAlert.kind ?? 'packet'} waiting on review</span>
                          </div>
                        )}
                        {selectedAgentAssignmentAlert && (
                          <div className="agent-focus-line">
                            <span className="agent-focus-key">route</span>
                            <span>{selectedAgentAssignmentAlert.operator_nudge_required ? 'Manual wake required.' : 'Ready for immediate routing.'}</span>
                          </div>
                        )}
                        {selectedAgentHuddlePeer && (
                          <div className="agent-focus-line">
                            <span className="agent-focus-key">baton</span>
                            <span>
                              {selectedAgentHuddlePeer.incomingBatonCount > 0 ? `waiting x${selectedAgentHuddlePeer.incomingBatonCount}` : 'no waiting baton'}
                              {selectedAgentHuddlePeer.outgoingBatonCount > 0 ? ` · active x${selectedAgentHuddlePeer.outgoingBatonCount}` : ''}
                            </span>
                          </div>
                        )}
                        {selectedAgentPulses.map((pulse) => (
                          <div key={`${selectedAgent.callsign}-${pulse.conversation_key}`} className="agent-focus-line">
                            <span className="agent-focus-key">pulse</span>
                            <span>{pulse.headline} · {pulse.state}</span>
                          </div>
                        ))}
                        {!selectedAgentCaptainAlert && !selectedAgentAssignmentAlert && !selectedAgentHuddlePeer && selectedAgentPulses.length === 0 && (
                          <p className="workspace-detail-empty">No active coordination signals for this agent.</p>
                        )}
                      </div>
                    </div>
                    <div className="workspace-detail-section">
                      <div className="workspace-detail-label">Recent Feed</div>
                      {selectedAgentFeed.length > 0 ? (
                        <div className="agent-focus-events">
                          {selectedAgentFeed.map(renderAgentFocusFeedItem)}
                        </div>
                      ) : (
                        <p className="workspace-detail-empty">No recent feed items tied to this agent yet.</p>
                      )}
                    </div>
                  </div>
                </div>
              ) : (
                <p className="workspace-detail-empty">Select an agent row to inspect its live state, pressure, coordination, and recent feed.</p>
              )}
            </div>

            <div className="control-section">
              <div className="control-section-title">Workspace Focus</div>
              {selectedWorkspace ? (
                <div className="workspace-detail-card">
                  <div className="workspace-detail-top">
                    <div>
                      <div className="workspace-detail-title">{selectedWorkspace.name || selectedWorkspace.workspace_id}</div>
                      <div className="workspace-detail-subtitle">{selectedWorkspace.purpose || 'No purpose recorded.'}</div>
                    </div>
                    <button type="button" className="btn-sm" onClick={() => setSelectedWorkspaceId('all')}>
                      Clear
                    </button>
                  </div>
                  <div className="workspace-detail-meta">
                    <span>{selectedWorkspace.status}</span>
                    <span>seq {selectedWorkspace.current_sequence ?? selectedWorkspace.last_sequence ?? 0}</span>
                    <span>members {selectedWorkspace.member_count ?? 0}</span>
                    <span>observers {selectedWorkspace.observer_count ?? 0}</span>
                    {selectedWorkspace.last_activity_at && <span>{relativeTime(selectedWorkspace.last_activity_at)}</span>}
                  </div>
                  <div className="workspace-detail-columns">
                    <div className="workspace-detail-section">
                      <div className="workspace-detail-label">Participants</div>
                      {workspaceDetailState === 'loading' ? (
                        <p className="workspace-detail-empty">Loading participants...</p>
                      ) : workspaceMembers.length > 0 ? (
                        workspaceMembers.map(member => (
                          <div key={`${member.agent_name}-${member.membership_role}`} className="workspace-detail-item">
                            <span>{member.agent_name}</span>
                            <span>{member.membership_role || 'member'}</span>
                          </div>
                        ))
                      ) : (
                        <p className="workspace-detail-empty">No active participants reported.</p>
                      )}
                    </div>
                    <div className="workspace-detail-section">
                      <div className="workspace-detail-label">Recent Deltas</div>
                      {workspaceDetailState === 'loading' ? (
                        <p className="workspace-detail-empty">Loading workspace activity...</p>
                      ) : workspaceDeltas.length > 0 ? (
                        workspaceDeltas.slice(0, 8).map(delta => (
                          <div key={`${delta.sequence}-${delta.delta_kind}`} className="workspace-delta-item">
                            <div className="workspace-delta-head">
                              <span>{delta.delta_kind}</span>
                              <span>{relativeTime(delta.created_at)}</span>
                            </div>
                            <p>{delta.text || `${delta.actor || 'system'} updated the workspace.`}</p>
                          </div>
                        ))
                      ) : (
                        <p className="workspace-detail-empty">No deltas available yet.</p>
                      )}
                    </div>
                  </div>
                </div>
              ) : (
                <p className="workspace-detail-empty">Select a workspace card to inspect participants and recent activity.</p>
              )}
            </div>

            <div className="control-section">
              <div className="control-section-title">Jolt</div>
              {consoleJolt ? (
                <div className="workspace-detail-card">
                  <div className="workspace-detail-top">
                    <div>
                      <div className="workspace-detail-title">{consoleJolt.title}</div>
                      <div className="workspace-detail-subtitle">{consoleJolt.detail}</div>
                    </div>
                  </div>
                  <div className="agent-focus-badges">
                    <span className="mode-label">{consoleJolt.actionLabel}</span>
                    {consoleJolt.freshnessLabel && (
                      <span className={`attention-label attention-${joltToneChip(consoleJolt.tone)}`}>
                        {consoleJolt.freshnessLabel}
                      </span>
                    )}
                    {consoleJolt.adapterLabel && (
                      <span className="interrupt-label">{consoleJolt.adapterLabel}</span>
                    )}
                  </div>
                  <div className="workspace-detail-meta">
                    {connectionStory?.agent_name && <span>{connectionStory.agent_name}</span>}
                    {consoleJolt.capabilityLabel && <span>{consoleJolt.capabilityLabel}</span>}
                    {consoleJolt.budgetLabel && <span>{consoleJolt.budgetLabel}</span>}
                  </div>
                  <div className="workspace-detail-columns">
                    <div className="workspace-detail-section">
                      <div className="workspace-detail-label">Packet</div>
                      <div className="agent-focus-stack">
                        <div className="agent-focus-line">
                          <span className="agent-focus-key">action</span>
                          <span>{consoleJolt.actionLabel}</span>
                        </div>
                        {consoleJolt.sourceStage && (
                          <div className="agent-focus-line">
                            <span className="agent-focus-key">source</span>
                            <span>{consoleJolt.sourceStage.replace(/_/g, ' ')}</span>
                          </div>
                        )}
                        {consoleJolt.recommendedAction && (
                          <div className="agent-focus-line">
                            <span className="agent-focus-key">recommended</span>
                            <span>{consoleJolt.recommendedAction}</span>
                          </div>
                        )}
                        {consoleJolt.reasons.map((reason, index) => (
                          <div key={`jolt-reason-${index}`} className="agent-focus-line">
                            <span className="agent-focus-key">reason</span>
                            <span>{reason}</span>
                          </div>
                        ))}
                        {!consoleJolt.sourceStage && !consoleJolt.recommendedAction && consoleJolt.reasons.length === 0 && (
                          <p className="workspace-detail-empty">No active Jolt packet details right now.</p>
                        )}
                      </div>
                    </div>
                    <div className="workspace-detail-section">
                      <div className="workspace-detail-label">Adapter</div>
                      <div className="agent-focus-stack">
                        {consoleJolt.adapterLabel && (
                          <div className="agent-focus-line">
                            <span className="agent-focus-key">host</span>
                            <span>{consoleJolt.adapterLabel}</span>
                          </div>
                        )}
                        {consoleJolt.adapterDetail && (
                          <div className="agent-focus-line">
                            <span className="agent-focus-key">state</span>
                            <span>{consoleJolt.adapterDetail}</span>
                          </div>
                        )}
                        {consoleJolt.capabilityLabel && (
                          <div className="agent-focus-line">
                            <span className="agent-focus-key">supports</span>
                            <span>{consoleJolt.capabilityLabel}</span>
                          </div>
                        )}
                        {consoleJolt.budgetLabel && (
                          <div className="agent-focus-line">
                            <span className="agent-focus-key">budget</span>
                            <span>{consoleJolt.budgetLabel}</span>
                          </div>
                        )}
                        {!consoleJolt.adapterLabel && !consoleJolt.adapterDetail && !consoleJolt.capabilityLabel && !consoleJolt.budgetLabel && (
                          <p className="workspace-detail-empty">Adapter registration has not been reported yet.</p>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              ) : (
                <p className="workspace-detail-empty">Waiting for connection story...</p>
              )}
            </div>

            <div className="control-section">
              <div className="control-section-title">Runtime</div>
              <div className="runtime-info">
                {runtimeLabel} · {runtimeAdmissionMode} · {observabilityMode}
              </div>
              <div className="runtime-buttons">
                <button
                  className={`btn-sm ${runtimeProfile === 'dev' ? 'btn-active' : ''}`}
                  disabled={!authReady || isRuntimeUpdating || runtimeProfile === 'dev'}
                  onClick={() => handleRuntimeProfileChange('dev')}
                >
                  Local Dev
                </button>
                <button
                  className={`btn-sm ${runtimeProfile === 'trusted_team' ? 'btn-active' : ''}`}
                  disabled={!authReady || isRuntimeUpdating || runtimeProfile === 'trusted_team'}
                  onClick={() => handleRuntimeProfileChange('trusted_team')}
                >
                  Trusted Team
                </button>
              </div>
            </div>

            <form className="control-section" onSubmit={handleDispatch}>
              <div className="control-section-title">Inject Message</div>
              <div className="form-row">
                <label>To</label>
                <input type="text" value={formTo} onChange={e => setFormTo(e.target.value)} placeholder="agent-name" required />
              </div>
              <div className="form-row">
                <label>Subject</label>
                <input type="text" value={formSubject} onChange={e => setFormSubject(e.target.value)} placeholder="Subject" required />
              </div>
              <div className="form-row">
                <label>Priority</label>
                <select value={formPriority} onChange={e => setFormPriority(e.target.value)}>
                  <option value="routine">Routine</option>
                  <option value="priority">Priority</option>
                  <option value="flash">Flash</option>
                </select>
              </div>
              <div className="form-row form-row-grow">
                <label>Body</label>
                <textarea value={formBody} onChange={e => setFormBody(e.target.value)} placeholder="JSON or text" required />
              </div>
              <button type="submit" className="btn-dispatch" disabled={isDispatching}>
                {isDispatching ? 'Sending...' : 'Dispatch'}
              </button>
            </form>
          </div>
        </section>
      </main>
      ) : (
      <main className="metrics-grid">
        <section className="panel metrics-overview-panel">
          <div className="panel-header">
            <h2>Metrics View</h2>
            <div className="panel-header-actions">
              <span className="feed-stat">{metricsSummary?.messages_today ?? 0} messages</span>
              <span className="feed-mode-badge">behind-the-scenes</span>
            </div>
          </div>
          <div className="metrics-overview-copy">
            <p>
              The collaboration front page shows who is doing what. This view answers whether the
              system is actually working, how well messages are flowing, and whether coordination is paying off.
            </p>
            <div className="metrics-fact-list">
              {metricsFacts.length > 0 ? metricsFacts.map((fact) => (
                <span key={fact} className="focus-chip">{fact}</span>
              )) : (
                <span className="focus-chip">Metrics will populate as soon as the summary endpoints respond.</span>
              )}
            </div>
          </div>
          <div className="metrics-card-grid">
            <article className="metrics-card">
              <span className="metrics-card-label">Messages Today</span>
              <span className="metrics-card-value">{metricsSummary?.messages_today ?? 0}</span>
              <span className="metrics-card-detail">Period starts {metricsSummary?.period_start ?? 'loading...'}</span>
            </article>
            <article className="metrics-card">
              <span className="metrics-card-label">Delivery Success</span>
              <span className="metrics-card-value">{metricsSummary?.delivery_success_pct ?? '--'}</span>
              <span className="metrics-card-detail">Derived from recipient delivery outcomes.</span>
            </article>
            <article className="metrics-card">
              <span className="metrics-card-label">Primary Online</span>
              <span className="metrics-card-value">{
                swarmState?.primary_participants_online
                ?? swarmState?.first_class_participants_online
                ?? onlineAgents.length
              }</span>
              <span className="metrics-card-detail">Live primary participant count across the current runtime.</span>
            </article>
            <article className="metrics-card">
              <span className="metrics-card-label">Active Workspaces</span>
              <span className="metrics-card-value">{metricsSummary?.active_workspaces ?? workspaces.length}</span>
              <span className="metrics-card-detail">Open collaboration rooms with live context.</span>
            </article>
            <article className="metrics-card">
              <span className="metrics-card-label">Handoffs Today</span>
              <span className="metrics-card-value">{metricsSummary?.handoffs_today ?? 0}</span>
              <span className="metrics-card-detail">Structured baton transfers recorded today.</span>
            </article>
            <article className="metrics-card">
              <span className="metrics-card-label">Handoff Ack Rate</span>
              <span className="metrics-card-value">{metricsSummary?.handoff_ack_pct ?? '--'}</span>
              <span className="metrics-card-detail">Acknowledged handoffs versus total handoffs.</span>
            </article>
          </div>
        </section>

        <section className="panel metrics-chart-panel">
          <div className="panel-header">
            <h2>Message Throughput</h2>
            <div className="panel-header-actions">
              <span className="feed-stat">24h window</span>
            </div>
          </div>
          {throughputBars.length > 0 ? (
            <div className="throughput-chart">
              {throughputBars.map((bar) => (
                <div key={bar.hour} className="throughput-column">
                  <div className="throughput-column-stack">
                    <div className="throughput-column-fill" style={{ height: `${bar.heightPct}%` }} />
                  </div>
                  <div className="throughput-column-meta">
                    <span className="throughput-column-value">{bar.sent}</span>
                    <span className="throughput-column-label">{bar.label}</span>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="metrics-empty-state">
              <h3>{metricsEmptyTitle}</h3>
              <p>{metricsEmptyDetail}</p>
            </div>
          )}
        </section>

        <section className="panel metrics-notes-panel">
          <div className="panel-header">
            <h2>Metrics Notes</h2>
          </div>
          <div className="metrics-note-list">
            <div className="metrics-note">
              <span className="metrics-note-label">Separation</span>
              <p>Collaboration stays on the front page. Metrics stay on a dedicated behind-the-scenes surface.</p>
            </div>
            <div className="metrics-note">
              <span className="metrics-note-label">Scope</span>
              <p>This is the minimal first build: top-level numbers plus a throughput chart from existing data stores.</p>
            </div>
            <div className="metrics-note">
              <span className="metrics-note-label">Current Runtime</span>
              <p>{runtimeLabel} · {swarmState?.my_mode || 'mode unknown'} · metrics state {metricsState}</p>
            </div>
          </div>
        </section>
      </main>
      )}
    </div>
  );
}
