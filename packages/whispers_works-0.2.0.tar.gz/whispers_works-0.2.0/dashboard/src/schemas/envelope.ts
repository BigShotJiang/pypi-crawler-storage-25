import { z } from 'zod';

export const AgentStatusSchema = z.object({
  agent_name: z.string(),
  status: z.string(),
  working_on: z.string().nullable().optional(),
  cognitive_state: z.string().nullable().optional(),
  reception_mode: z.string().optional(),
  agent_type: z.string().optional(),
});

export const SwarmHealthSchema = z.object({
  my_mode: z.string().optional(),
  agent_name: z.string().optional(),
  agents_registered: z.number().optional(),
  pending_messages: z.number().optional(),
  agents: z.array(AgentStatusSchema).optional(),
});

export const A2AEnvelopeSchema = z.object({
  from_agent: z.string().optional(),
  // Strict A2A parameters
  to: z.string().optional(),
  subject: z.string().optional(),
  body: z.any().optional(),
  priority: z.enum(["routine", "priority", "flash", "system", "urgent", "critical"]).default("routine"),
  type: z.string().default("inform"),
  
  // Return fields mapped by SSE push
  sender: z.string().optional(),
  recipient: z.string().optional(),
  created_at: z.string().optional(),
  payload: z.any().optional(),
});

export type A2AEnvelope = z.infer<typeof A2AEnvelopeSchema>;
export type SwarmHealth = z.infer<typeof SwarmHealthSchema>;
export type AgentStatus = z.infer<typeof AgentStatusSchema>;
