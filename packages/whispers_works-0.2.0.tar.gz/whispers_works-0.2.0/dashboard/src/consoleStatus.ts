import type { A2AEnvelope, CollaborationHealthSignal, ConnectionStory } from 'whispers-sdk';

export type ConsoleSurfaceState = 'loading' | 'ready' | 'error';
export type ConsoleHealthTone = 'up' | 'degraded' | 'recovering' | 'down';
export type CollaborationTone = 'ok' | 'info' | 'warn';
export type BatonChipTone = 'waiting' | 'active' | 'review' | 'blocked' | 'expired' | 'done';

export type BatonChip = {
  key: string;
  glyph: string;
  label: string;
  tone: BatonChipTone;
  title?: string | null;
  ageLabel?: string | null;
  stale?: boolean;
};

export type ConsoleHealthInput = {
  authReady: boolean;
  isConnected: boolean;
  healthState: ConsoleSurfaceState;
  registryState: ConsoleSurfaceState;
  streamState: ConsoleSurfaceState;
  collaborationState?: ConsoleSurfaceState;
  onlineAgents: number;
  registeredAgents: number;
  primaryOnline?: number;
  primaryRegistered?: number;
  secondaryTrackedParticipants?: number;
  firstClassOnline?: number;
  firstClassRegistered?: number;
  otherTrackedParticipants?: number;
  lastError: string | null;
  serverState?: ConsoleHealthTone;
  serverStateDetail?: string | null;
};

export type ConsoleHealthStatus = {
  tone: ConsoleHealthTone;
  title: string;
  detail: string;
};

export type ConsoleDiagnosticCheck = {
  name: string;
  label: string;
  failing: boolean;
};

export type ConsoleDiagnostics = {
  checks: ConsoleDiagnosticCheck[];
  failingChecks: string[];
  hints: string[];
};

export type ConsoleActivityTone = 'ok' | 'info' | 'warn' | 'error';

export type ConsoleActivityEvent = {
  id: string;
  title: string;
  detail: string;
  tone: ConsoleActivityTone;
  createdAt: string;
  sourceLabel: string;
};

export type CollaborationWorkspaceCard = {
  id: string;
  title: string;
  purpose: string;
  status: string;
  memberCount: number;
  observerCount: number;
  sequence: number;
  lastActivityAt: string | null;
};

export type CollaborationFeedEvent = {
  id: string;
  title: string;
  detail: string;
  tone: CollaborationTone;
  createdAt: string;
  sourceLabel: string;
  workspaceLabel: string;
  kind: 'handoff' | 'workspace_lifecycle' | 'workspace_delta' | 'coordination';
  batonChips: BatonChip[];
};

export type CollaborationHandoffCard = {
  id: string;
  route: string;
  subject: string;
  summary: string;
  workspaceLabel: string;
  nextAction: string | null;
  createdAt: string | null;
  batonChips: BatonChip[];
};

export type UnifiedFeedKind =
  | 'workspace'
  | 'handoff'
  | 'health'
  | 'runtime'
  | 'signal'
  | 'system'
  | 'message';

export type UnifiedFeedItem = {
  id: string;
  kind: UnifiedFeedKind;
  badge: string;
  title: string;
  detail: string;
  tone: ConsoleActivityTone;
  createdAt: string | null;
  sourceLabel: string;
  workspaceLabel: string | null;
  agents: string[];
  batonChips: BatonChip[];
};

export type UnifiedFeedInput = {
  workspaceCards: CollaborationWorkspaceCard[];
  handoffs: CollaborationHandoffCard[];
  collaborationSignals: CollaborationHealthSignal[];
  collaborationFeed: CollaborationFeedEvent[];
  backendActivity: ConsoleActivityEvent[];
  systemEvents: ConsoleActivityEvent[];
  messages: A2AEnvelope[];
};

export type AgentAttentionInput = {
  attention_state?: string | null;
  attention_detail?: string | null;
  progress_summary?: string | null;
  last_progress_at?: string | null;
  runtime_updated_at?: string | null;
  readiness?: string | null;
};

export type AgentAttentionSummary = {
  label: string;
  tone: 'working' | 'waiting' | 'blocked';
  detail: string | null;
  freshness: string | null;
};

export type ConsoleJoltSummary = {
  title: string;
  detail: string;
  tone: ConsoleActivityTone;
  headline: string | null;
  actionLabel: string;
  freshnessLabel: string | null;
  recommendedAction: string | null;
  sourceStage: string | null;
  adapterLabel: string | null;
  adapterDetail: string | null;
  capabilityLabel: string | null;
  budgetLabel: string | null;
  reasons: string[];
};

const CHECK_LABELS: Record<string, string> = {
  server_reachable: 'Server reachable',
  db_path_match: 'DB path match',
  mcp_handshake: 'MCP handshake',
  db_write_ready: 'DB write-ready',
  wal_mode: 'WAL mode',
};

function humanizeCheckName(name: string): string {
  if (CHECK_LABELS[name]) return CHECK_LABELS[name];
  return name
    .split('_')
    .filter(Boolean)
    .map(part => part.charAt(0).toUpperCase() + part.slice(1))
    .join(' ');
}

function joinSurfaceNames(items: string[]): string {
  if (items.length <= 1) return items[0] ?? 'core surfaces';
  if (items.length === 2) return `${items[0]} and ${items[1]}`;
  return `${items.slice(0, -1).join(', ')}, and ${items[items.length - 1]}`;
}

function humanizeEventType(type: string): string {
  return type
    .split('_')
    .filter(Boolean)
    .map(part => part.charAt(0).toUpperCase() + part.slice(1))
    .join(' ');
}

function humanizeSlug(value: string): string {
  return value
    .split(/[_-]+/)
    .filter(Boolean)
    .map(part => part.charAt(0).toUpperCase() + part.slice(1))
    .join(' ');
}

function normalizeText(value: unknown): string | null {
  if (typeof value !== 'string') return null;
  const normalized = value.trim();
  return normalized.length > 0 ? normalized : null;
}

function relativeAge(value: string, nowMs: number): string | null {
  const ts = Date.parse(value);
  if (Number.isNaN(ts)) return null;
  const diffMs = Math.max(0, nowMs - ts);
  const mins = Math.floor(diffMs / 60000);
  if (mins < 1) return 'just now';
  if (mins < 60) return `${mins}m ago`;
  const hours = Math.floor(mins / 60);
  if (hours < 24) return `${hours}h ago`;
  const days = Math.floor(hours / 24);
  return `${days}d ago`;
}

function compactAge(value: string, nowMs: number): string | null {
  const ts = Date.parse(value);
  if (Number.isNaN(ts)) return null;
  const diffMs = Math.max(0, nowMs - ts);
  const mins = Math.floor(diffMs / 60000);
  if (mins < 1) return 'now';
  if (mins < 60) return `${mins}m`;
  const hours = Math.floor(mins / 60);
  if (hours < 24) return `${hours}h`;
  const days = Math.floor(hours / 24);
  return `${days}d`;
}

function attentionFreshness(prefix: string, value: string | null, nowMs: number): string | null {
  if (!value) return null;
  const age = relativeAge(value, nowMs);
  return age ? `${prefix} ${age}` : null;
}

function humanizeDeltaKind(kind: string): string {
  const special: Record<string, string> = {
    note: 'Workspace note',
    decision: 'Decision recorded',
    artifact: 'Artifact posted',
    review: 'Review update',
    execution_update: 'Execution update',
    status_update: 'Status update',
    lifecycle: 'Workspace lifecycle',
    handoff_in: 'Structured handoff',
    handoff_out: 'Structured handoff',
  };
  return special[kind] || humanizeEventType(kind);
}

function collaborationSignalTone(signal: CollaborationHealthSignal): ConsoleActivityTone {
  if (signal.severity === 'escalate') return 'error';
  if (signal.severity === 'warning') return 'warn';
  return 'info';
}

function collaborationSignalTitle(signal: CollaborationHealthSignal): string {
  return signal.signal.replace(/_/g, ' ');
}

function uniqueStrings(values: Array<string | null | undefined>): string[] {
  return Array.from(new Set(values.filter((value): value is string => Boolean(value && value.trim()))));
}

function parseAgentLabels(value: string | null | undefined): string[] {
  if (!value) return [];
  if (value.includes('->')) {
    return uniqueStrings(value.split('->').map((part) => part.trim()));
  }
  const trimmed = value.trim();
  if (!trimmed || trimmed.includes(' ')) return [];
  return [trimmed];
}

function summarizeBody(value: unknown): string {
  const raw = typeof value === 'string'
    ? value
    : value && typeof value === 'object'
      ? JSON.stringify(value)
      : '';
  const compact = raw.replace(/\s+/g, ' ').trim();
  if (!compact) return 'No body.';
  return compact.length > 180 ? `${compact.slice(0, 177)}...` : compact;
}

function batonChip(
  key: string,
  glyph: string,
  label: string,
  tone: BatonChipTone,
  title?: string | null,
  createdAt?: string | null,
): BatonChip {
  const nowMs = Date.now();
  const ageLabel = createdAt ? compactAge(createdAt, nowMs) : null;
  const ts = createdAt ? Date.parse(createdAt) : Number.NaN;
  const ageMinutes = Number.isNaN(ts) ? null : Math.max(0, nowMs - ts) / 60000;
  const stale = ageMinutes !== null && (
    ((tone === 'blocked' || tone === 'review') && ageMinutes >= 10)
    || (tone === 'waiting' && ageMinutes >= 20)
  );
  const titleWithAge = [title ?? null, ageLabel ? `Age ${ageLabel}.` : null].filter(Boolean).join(' ');
  return {
    key,
    glyph,
    label,
    tone,
    title: titleWithAge || null,
    ageLabel,
    stale,
  };
}

function deriveHandoffBatonChips(handoff: Record<string, unknown>): BatonChip[] {
  const ackState = normalizeText(handoff.ack_state)?.toLowerCase() ?? null;
  const deliveryStatus = normalizeText(handoff.delivery_status)?.toLowerCase() ?? null;
  const createdAt = typeof handoff.created_at === 'string' ? handoff.created_at : null;

  if (ackState === 'accepted' || ackState === 'processed' || ackState === 'acknowledged') {
    return [batonChip('active', '→', 'active baton', 'active', 'Picked up and moving.', createdAt)];
  }
  if (ackState === 'deferred') {
    return [batonChip('review', '◈', 'needs follow-up', 'review', 'Deferred; waiting on a follow-up pass.', createdAt)];
  }
  if (ackState === 'declined' || ackState === 'rejected') {
    return [batonChip('blocked', '✕', 'declined', 'blocked', 'The assignee declined this baton.', createdAt)];
  }
  if (ackState === 'expired') {
    return [batonChip('expired', '⌛', 'expired baton', 'expired', 'The baton timed out and decayed to the expired terminal state.', createdAt)];
  }
  if (deliveryStatus === 'queued' || deliveryStatus === 'unclaimed') {
    return [batonChip('queued', '←', 'queued baton', 'waiting', 'Not yet picked up by the assignee.', createdAt)];
  }
  return [batonChip('offered', '←', 'offered baton', 'waiting', 'Waiting on the assignee.', createdAt)];
}

function deriveCoordinationBatonChips(event: Record<string, unknown>, deltaKind: string): BatonChip[] {
  const status = normalizeText(event.coordination_status)?.toLowerCase() ?? null;
  const blocking = Boolean(event.blocking);
  const createdAt = typeof event.created_at === 'string' ? event.created_at : null;

  if (deltaKind === 'review_request') {
    if (status === 'stalled' || status === 'waiting') {
      return [
        batonChip(
          blocking ? 'blocking-review' : 'review-wait',
          '◈',
          blocking ? 'blocking review' : 'review waiting',
          blocking ? 'blocked' : 'review',
          blocking ? 'This review is currently blocking progress.' : 'Review requested and waiting.',
          createdAt,
        ),
      ];
    }
    if (status === 'active' || status === 'acknowledged') {
      return [batonChip('review-active', '◈', 'review active', 'active', 'The review has been picked up.', createdAt)];
    }
    if (status === 'completed') {
      return [batonChip('review-done', '✓', 'review closed', 'done', 'The review loop is closed.', createdAt)];
    }
    return [batonChip('review', '◈', 'review', 'review', 'Review coordination activity.', createdAt)];
  }

  if (deltaKind === 'assignment') {
    if (status === 'completed') {
      return [batonChip('assignment-done', '✓', 'assignment closed', 'done', 'The assignment loop is closed.', createdAt)];
    }
    if (status === 'active' || status === 'acknowledged') {
      return [batonChip('assignment-active', '→', 'assignment active', 'active', 'The assignment has been picked up.', createdAt)];
    }
    return [batonChip('assignment-waiting', '←', 'assignment waiting', 'waiting', 'Assignment sent and waiting on pickup.', createdAt)];
  }

  return [];
}

function deriveCollaborationBatonChips(
  event: Record<string, unknown>,
  kind: CollaborationFeedEvent['kind'],
  deltaKind: string,
): BatonChip[] {
  const createdAt = typeof event.created_at === 'string' ? event.created_at : null;
  if (kind === 'handoff') {
    if (event.completed === true || normalizeText(event.outcome)?.toLowerCase() === 'completed') {
      return [batonChip('handoff-done', '✓', 'handoff complete', 'done', 'This handoff has been completed.', createdAt)];
    }
    if (normalizeText(event.outcome)?.toLowerCase() === 'expired') {
      return [batonChip('handoff-expired', '⌛', 'handoff expired', 'expired', 'This handoff timed out and expired before pickup or follow-through.', createdAt)];
    }
    return [batonChip('handoff', '←', 'handoff waiting', 'waiting', 'Structured baton waiting on the assignee.', createdAt)];
  }
  if (kind === 'coordination') {
    return deriveCoordinationBatonChips(event, deltaKind);
  }
  return [];
}

function coordinationTone(event: Record<string, unknown>): CollaborationTone {
  const status = typeof event.coordination_status === 'string' ? event.coordination_status : '';
  if (status === 'waiting' || status === 'stalled') return 'warn';
  if (status === 'acknowledged' || status === 'completed' || status === 'active') return 'ok';
  return 'info';
}

function coordinationTitle(event: Record<string, unknown>, sender: string | null, receiver: string | null): string {
  const senderLabel = sender || 'Someone';
  const receiverLabel = receiver || 'someone';
  const status = typeof event.coordination_status === 'string' ? event.coordination_status : '';
  const kind = typeof event.delta_kind === 'string' ? event.delta_kind : '';

  if (kind === 'assignment') {
    if (status === 'completed') return `${receiverLabel} closed ${senderLabel} assignment`;
    if (status === 'active') return `${receiverLabel} picked up ${senderLabel} assignment`;
    return `${senderLabel} assigned ${receiverLabel}`;
  }

  if (status === 'acknowledged') return `${receiverLabel} acknowledged ${senderLabel} review`;
  if (status === 'stalled') return `${senderLabel} is still waiting on ${receiverLabel} review`;
  if (status === 'waiting') return `${senderLabel} needs ${receiverLabel} review`;
  if (status === 'active') return `${receiverLabel} picked up ${senderLabel} review`;
  return `${senderLabel} requested review from ${receiverLabel}`;
}

function mapActivityTone(type: string, severity: unknown, lifecycleStep?: string | null): ConsoleActivityTone {
  if (severity === 'error') return 'error';
  if (severity === 'warning' || severity === 'warn') return 'warn';
  if (severity === 'success' || severity === 'ok') return 'ok';
  if (type === 'message_lifecycle') {
    if (lifecycleStep === 'delivered' || lifecycleStep === 'read' || lifecycleStep === 'acknowledged') return 'ok';
    if (lifecycleStep === 'dead_lettered') return 'error';
    return 'info';
  }
  if (type === 'auto_start_failed') return 'error';
  if (type === 'state_degraded') return 'warn';
  if (type === 'auto_start_succeeded' || type === 'state_up_restored') return 'ok';
  if (type === 'delivered' || type === 'read' || type === 'acknowledged') return 'ok';
  if (type === 'message_delivered' || type === 'message_read' || type === 'message_acknowledged') return 'ok';
  if (type === 'dead_lettered' || type === 'message_dead_lettered') return 'error';
  return 'info';
}

function recoveryEventTitle(type: string): string {
  const labels: Record<string, string> = {
    auto_start_attempted: 'Auto-start attempted',
    auto_start_succeeded: 'Auto-start succeeded',
    auto_start_failed: 'Auto-start failed',
    state_degraded: 'Server degraded',
    state_up_restored: 'Server restored',
  };
  return labels[type] || humanizeEventType(type);
}

function agentEventTitle(type: string, agentName: string | null): string {
  const labels: Record<string, string> = {
    active_mode_changed: 'active mode changed',
    readiness_changed: 'readiness changed',
    attention_changed: 'attention changed',
    working_on_changed: 'focus changed',
    shadow_filter: 'shadow block',
  };
  const suffix = labels[type] || humanizeEventType(type).toLowerCase();
  return agentName ? `${agentName} ${suffix}` : humanizeEventType(type);
}

function messageEventTitle(type: string, lifecycleStep?: string | null): string {
  const key = lifecycleStep || type;
  const labels: Record<string, string> = {
    queued: 'Message queued',
    delivered: 'Message delivered',
    read: 'Message read',
    acknowledged: 'Message acknowledged',
    dead_lettered: 'Message dead-lettered',
    message_queued: 'Message queued',
    message_delivered: 'Message delivered',
    message_read: 'Message read',
    message_acknowledged: 'Message acknowledged',
    message_dead_lettered: 'Message dead-lettered',
  };
  return labels[key] || humanizeEventType(key);
}

export function deriveAgentAttention(input: AgentAttentionInput, nowMs = Date.now()): AgentAttentionSummary | null {
  const attentionState = normalizeText(input.attention_state)?.toLowerCase() ?? null;
  const detail = normalizeText(input.attention_detail) ?? normalizeText(input.progress_summary);
  const progressAt = normalizeText(input.last_progress_at);
  const runtimeUpdatedAt = normalizeText(input.runtime_updated_at);
  const freshnessSource = progressAt ?? runtimeUpdatedAt;

  if (attentionState === 'working') {
    return {
      label: 'quietly working',
      tone: 'working',
      detail,
      freshness: attentionFreshness(progressAt ? 'progress' : 'updated', freshnessSource, nowMs),
    };
  }
  if (attentionState === 'waiting_on_operator') {
    return {
      label: 'needs operator',
      tone: 'waiting',
      detail,
      freshness: attentionFreshness('waiting', freshnessSource, nowMs),
    };
  }
  if (attentionState === 'needs_assignment') {
    return {
      label: 'needs assignment',
      tone: 'waiting',
      detail,
      freshness: attentionFreshness('waiting', freshnessSource, nowMs),
    };
  }
  if (attentionState === 'waiting_on_peer') {
    return {
      label: 'waiting on peer',
      tone: 'waiting',
      detail,
      freshness: attentionFreshness('waiting', freshnessSource, nowMs),
    };
  }
  if (attentionState === 'blocked_external') {
    return {
      label: 'blocked external',
      tone: 'blocked',
      detail,
      freshness: attentionFreshness('blocked', freshnessSource, nowMs),
    };
  }

  const readiness = normalizeText(input.readiness)?.toLowerCase();
  if (
    readiness
    && ['busy', 'warming', 'blocked', 'degraded'].includes(readiness)
    && (detail || freshnessSource)
  ) {
    return {
      label: 'recent update',
      tone: 'working',
      detail,
      freshness: attentionFreshness(progressAt ? 'progress' : 'updated', freshnessSource, nowMs),
    };
  }

  return null;
}

export function deriveJoltSummary(story: ConnectionStory | null | undefined): ConsoleJoltSummary | null {
  if (!story) return null;

  const packet = story.jolt_packet ?? null;
  const adapter = story.jolt_adapter ?? packet?.adapter ?? null;
  const capabilities = story.jolt_host_capabilities ?? null;
  const budget = story.jolt_budget ?? null;
  const headline = normalizeText(packet?.headline);
  const action = normalizeText(packet?.action) ?? normalizeText(story.jolt?.action) ?? (packet ? 'notify' : 'idle');
  const freshness = normalizeText(packet?.freshness);
  const ageLabel = normalizeText(packet?.age_label);
  const recommendedAction = normalizeText(packet?.recommended_action) ?? normalizeText(story.recommended_action);
  const sourceStage = normalizeText(packet?.source_stage);
  const reasons = uniqueStrings(
    Array.isArray(packet?.reasons)
      ? packet.reasons
      : Array.isArray(story.jolt?.reasons)
        ? story.jolt.reasons
        : [],
  ).slice(0, 3);

  const actionLabel = humanizeSlug(action);
  const freshnessLabel = uniqueStrings([
    freshness ? freshness.toLowerCase() : null,
    ageLabel,
  ]).join(' · ') || null;

  const hostKind = normalizeText(adapter?.host_kind) ?? normalizeText(capabilities?.host_kind);
  const adapterKind = normalizeText(adapter?.adapter_kind);
  const adapterState = normalizeText(adapter?.state);
  const adapterLabel = uniqueStrings([
    hostKind ? humanizeSlug(hostKind) : null,
    adapterKind ? humanizeSlug(adapterKind) : null,
  ]).join(' · ') || null;
  const adapterDetail = uniqueStrings([
    adapterState ? humanizeSlug(adapterState) : null,
    normalizeText(adapter?.detail),
  ]).join(' · ') || null;

  const supportedActions = uniqueStrings([
    ...(Array.isArray(adapter?.supported_actions)
      ? adapter.supported_actions.map((value) => normalizeText(value)?.replace(/_/g, ' '))
      : []),
    capabilities?.can_notify ? 'notify' : null,
    capabilities?.can_stage_context ? 'stage context' : null,
    capabilities?.can_trigger_inference ? 'inference' : null,
    capabilities?.steals_focus ? 'focus steal' : null,
  ]);
  const capabilityLabel = supportedActions.length > 0
    ? supportedActions
      .map((value) => value.includes(' ') ? value : humanizeSlug(value).toLowerCase())
      .join(' · ')
    : null;

  const budgetParts = uniqueStrings([
    budget?.autonomous_inference_enabled === true
      ? 'autonomous infer on'
      : budget?.autonomous_inference_enabled === false
        ? 'autonomous infer off'
        : null,
    typeof budget?.max_inferences_per_hour === 'number'
      ? `infer ${budget.inferences_used_last_hour ?? 0}/${budget.max_inferences_per_hour}h`
      : null,
    typeof budget?.cooldown_seconds === 'number'
      ? `cooldown ${Math.round(budget.cooldown_seconds)}s`
      : null,
  ]);
  const budgetLabel = budgetParts.length > 0 ? budgetParts.join(' · ') : null;

  let tone: ConsoleActivityTone = 'info';
  if (!packet && !adapter) {
    tone = 'warn';
  } else if (freshness === 'stale' || packet?.budget_limited || story.jolt?.budget_limited) {
    tone = 'warn';
  } else if (adapterState === 'degraded' || adapterState === 'blocked') {
    tone = 'warn';
  } else if (adapterState === 'error' || adapterState === 'failed') {
    tone = 'error';
  } else if (!packet) {
    tone = 'ok';
  }

  if (packet) {
    const packetSummary = uniqueStrings([
      freshnessLabel,
      sourceStage ? `stage ${humanizeSlug(sourceStage).toLowerCase()}` : null,
      recommendedAction ? `next ${recommendedAction}` : null,
    ]);
    return {
      title: headline ?? `Jolt ${actionLabel}`,
      detail: packetSummary.length > 0
        ? `${story.agent_name} has an active Jolt packet: ${packetSummary.join(' · ')}.`
        : `${story.agent_name} has an active Jolt packet.`,
      tone,
      headline,
      actionLabel,
      freshnessLabel,
      recommendedAction,
      sourceStage,
      adapterLabel,
      adapterDetail,
      capabilityLabel,
      budgetLabel,
      reasons,
    };
  }

  return {
    title: adapterLabel ? 'Jolt adapter ready' : 'Jolt not registered',
    detail: adapterLabel
      ? `${story.agent_name} is registered for Jolt delivery even though no packet is active right now.`
      : `${story.agent_name} has no active Jolt adapter registered yet.`,
    tone,
    headline: null,
    actionLabel,
    freshnessLabel: null,
    recommendedAction,
    sourceStage: null,
    adapterLabel,
    adapterDetail,
    capabilityLabel,
    budgetLabel,
    reasons,
  };
}

function securityEventTitle(type: string, agentName: string | null): string {
  if (type.endsWith(':shadow')) {
    return agentEventTitle('shadow_filter', agentName);
  }
  const label = humanizeEventType(type).toLowerCase();
  return agentName ? `${agentName} ${label}` : humanizeEventType(type);
}

function normalizeActivityEvent(
  source: 'recovery' | 'agent' | 'message' | 'security',
  raw: unknown,
  index: number,
): ConsoleActivityEvent | null {
  if (!raw || typeof raw !== 'object') return null;

  const event = raw as {
    type?: unknown;
    created_at?: unknown;
    detail?: unknown;
    severity?: unknown;
    agent_name?: unknown;
    lifecycle_step?: unknown;
    sender?: unknown;
    sender_agent?: unknown;
    from_agent?: unknown;
    recipient?: unknown;
    recipient_agent?: unknown;
    to_agent?: unknown;
  };
  if (typeof event.type !== 'string' || typeof event.created_at !== 'string') {
    return null;
  }

  const agentName = typeof event.agent_name === 'string' && event.agent_name.trim()
    ? event.agent_name
    : null;
  const sender = [event.sender, event.sender_agent, event.from_agent]
    .find((value): value is string => typeof value === 'string' && value.trim().length > 0) ?? null;
  const recipient = [event.recipient, event.recipient_agent, event.to_agent]
    .find((value): value is string => typeof value === 'string' && value.trim().length > 0) ?? null;
  const lifecycleStep = typeof event.lifecycle_step === 'string' && event.lifecycle_step.trim()
    ? event.lifecycle_step
    : null;
  const messageSourceLabel = sender && recipient
    ? `${sender} -> ${recipient}`
    : sender ?? recipient ?? 'Message lifecycle';

  return {
    id: `${source}-${event.created_at}-${event.type}-${agentName ?? sender ?? recipient ?? 'system'}-${index}`,
    title: source === 'recovery'
      ? recoveryEventTitle(event.type)
      : source === 'agent'
        ? agentEventTitle(event.type, agentName)
        : source === 'security'
          ? securityEventTitle(event.type, agentName)
          : messageEventTitle(event.type, lifecycleStep),
    detail: typeof event.detail === 'string' && event.detail.trim()
      ? event.detail
      : 'Whispers reported a state transition.',
    tone: mapActivityTone(event.type, event.severity, lifecycleStep),
    createdAt: event.created_at,
    sourceLabel: source === 'recovery'
      ? 'Recovery'
      : source === 'agent'
        ? (agentName ?? 'Agent state')
        : source === 'security'
          ? (agentName ?? 'Security')
          : messageSourceLabel,
  };
}

export function deriveConsoleDiagnostics(input: unknown): ConsoleDiagnostics {
  if (!input || typeof input !== 'object') {
    return { checks: [], failingChecks: [], hints: [] };
  }

  const raw = input as {
    checks?: unknown;
    failing_checks?: unknown;
    hints?: unknown;
  };

  const checks = typeof raw.checks === 'object' && raw.checks
    ? Object.entries(raw.checks as Record<string, unknown>)
      .filter(([, value]) => typeof value === 'boolean')
      .map(([name, value]) => ({
        name,
        label: humanizeCheckName(name),
        failing: value === false,
      }))
    : [];

  const failingChecks = new Set<string>();
  for (const check of checks) {
    if (check.failing) failingChecks.add(check.label);
  }

  if (Array.isArray(raw.failing_checks)) {
    for (const item of raw.failing_checks) {
      if (typeof item === 'string' && item.trim()) {
        failingChecks.add(humanizeCheckName(item));
      }
    }
  }

  const hints = Array.isArray(raw.hints)
    ? raw.hints.filter((item): item is string => typeof item === 'string' && item.trim().length > 0)
    : [];

  return {
    checks,
    failingChecks: Array.from(failingChecks),
    hints,
  };
}

export function formatConsoleDiagnosticsSummary(input: ConsoleDiagnostics): string | null {
  const parts: string[] = [];
  if (input.failingChecks.length > 0) {
    parts.push(`Failing checks: ${input.failingChecks.join(', ')}.`);
  }
  if (input.hints.length > 0) {
    parts.push(input.hints.slice(0, 2).join(' '));
  }
  return parts.length > 0 ? parts.join(' ') : null;
}

export function deriveBackendActivity(input: unknown): ConsoleActivityEvent[] {
  if (!input || typeof input !== 'object') return [];

  const raw = input as {
    recovery_events?: unknown;
    agent_events?: unknown;
    message_events?: unknown;
    security_events?: unknown;
  };

  const normalized: ConsoleActivityEvent[] = [];
  const recoveryEvents = Array.isArray(raw.recovery_events) ? raw.recovery_events : [];
  const agentEvents = Array.isArray(raw.agent_events) ? raw.agent_events : [];
  const messageEvents = Array.isArray(raw.message_events) ? raw.message_events : [];
  const securityEvents = Array.isArray(raw.security_events) ? raw.security_events : [];

  for (const [index, event] of recoveryEvents.entries()) {
    const normalizedEvent = normalizeActivityEvent('recovery', event, index);
    if (normalizedEvent) normalized.push(normalizedEvent);
  }

  for (const [index, event] of agentEvents.entries()) {
    const normalizedEvent = normalizeActivityEvent('agent', event, index);
    if (normalizedEvent) normalized.push(normalizedEvent);
  }

  for (const [index, event] of messageEvents.entries()) {
    const normalizedEvent = normalizeActivityEvent('message', event, index);
    if (normalizedEvent) normalized.push(normalizedEvent);
  }

  for (const [index, event] of securityEvents.entries()) {
    const normalizedEvent = normalizeActivityEvent('security', event, index + 1000);
    if (normalizedEvent) normalized.push(normalizedEvent);
  }

  return normalized.sort((a, b) => {
    const timeA = Date.parse(a.createdAt);
    const timeB = Date.parse(b.createdAt);
    return timeB - timeA;
  });
}

export function deriveConsoleHealth(input: ConsoleHealthInput): ConsoleHealthStatus {
  const unavailable: string[] = [];
  const recovering: string[] = [];

  if (input.registryState === 'error') unavailable.push('agent registry');
  if (input.streamState === 'error') unavailable.push('live stream');
  if (input.collaborationState === 'error') unavailable.push('collaboration feed');

  if (input.registryState === 'loading') recovering.push('agent registry');
  if (input.streamState === 'loading') recovering.push('live stream');
  if (input.collaborationState === 'loading') recovering.push('collaboration feed');

  if (!input.authReady || input.healthState === 'error' || !input.isConnected) {
    return {
      tone: 'down',
      title: 'Whispers unavailable',
      detail: input.lastError || 'The Console cannot reach the Whispers server right now.',
    };
  }

  if (input.serverState && input.serverState !== 'up') {
    return {
      tone: input.serverState,
      title: input.serverState === 'recovering'
        ? 'Whispers recovering'
        : input.serverState === 'degraded'
          ? 'Whispers degraded'
          : 'Whispers unavailable',
      detail: input.serverStateDetail || (
        input.serverState === 'recovering'
          ? 'The server is back but still restoring core services.'
          : input.serverState === 'degraded'
            ? 'The server is responding, but some recovery checks are still failing.'
            : 'The Whispers server is currently unavailable.'
      ),
    };
  }

  if (input.healthState === 'loading' || recovering.length > 0) {
    const detail = recovering.length > 0
      ? `Connected. Re-establishing ${joinSurfaceNames(recovering)}.`
      : 'Connected. Waiting for the first healthy runtime snapshot.';
    return {
      tone: 'recovering',
      title: 'Whispers recovering',
      detail,
    };
  }

  if (unavailable.length > 0) {
    return {
      tone: 'degraded',
      title: 'Whispers degraded',
      detail: `Core health is up, but ${joinSurfaceNames(unavailable)} ${unavailable.length === 1 ? 'is' : 'are'} unavailable.`,
    };
  }

  const primaryRegistered = input.primaryRegistered ?? input.firstClassRegistered ?? input.registeredAgents;
  const primaryOnline = input.primaryOnline ?? input.firstClassOnline ?? input.onlineAgents;
  const secondaryTrackedParticipants = input.secondaryTrackedParticipants
    ?? input.otherTrackedParticipants
    ?? Math.max(0, input.registeredAgents - primaryRegistered);
  const agentSummary = primaryRegistered > 0
    ? `${primaryOnline} online of ${primaryRegistered} primary participants.`
    : `${primaryOnline} primary participants online.`;
  const otherSummary = secondaryTrackedParticipants > 0
    ? ` ${secondaryTrackedParticipants} secondary tracked participants are split into automata and ephemeral buckets.`
    : '';

  return {
    tone: 'up',
    title: 'Whispers healthy',
    detail: input.serverStateDetail || `${agentSummary}${otherSummary} Health, registry, collaboration, and live stream are connected.`,
  };
}

export function deriveWorkspaceCards(input: unknown): CollaborationWorkspaceCard[] {
  if (!Array.isArray(input)) return [];

  return input
    .filter((item): item is Record<string, unknown> => Boolean(item) && typeof item === 'object')
    .map((workspace) => ({
      id: String(workspace.workspace_id ?? ''),
      title: typeof workspace.name === 'string' && workspace.name.trim()
        ? workspace.name
        : typeof workspace.workspace_id === 'string'
          ? workspace.workspace_id
          : 'Workspace',
      purpose: typeof workspace.purpose === 'string' && workspace.purpose.trim()
        ? workspace.purpose
        : 'No purpose recorded.',
      status: typeof workspace.status === 'string' ? workspace.status : 'unknown',
      memberCount: typeof workspace.member_count === 'number' ? workspace.member_count : 0,
      observerCount: typeof workspace.observer_count === 'number' ? workspace.observer_count : 0,
      sequence: typeof workspace.current_sequence === 'number'
        ? workspace.current_sequence
        : typeof workspace.last_sequence === 'number'
          ? workspace.last_sequence
          : 0,
      lastActivityAt: typeof workspace.last_activity_at === 'string'
        ? workspace.last_activity_at
        : typeof workspace.last_delta_at === 'string'
          ? workspace.last_delta_at
          : null,
    }))
    .filter((workspace) => workspace.id.length > 0);
}

export function deriveCollaborationActivity(input: unknown): CollaborationFeedEvent[] {
  if (!Array.isArray(input)) return [];

  return input
    .filter((item): item is Record<string, unknown> => Boolean(item) && typeof item === 'object')
    .map((event, index) => {
      const kind: CollaborationFeedEvent['kind'] = event.type === 'handoff'
        ? 'handoff'
        : event.type === 'workspace_lifecycle'
          ? 'workspace_lifecycle'
          : event.type === 'coordination'
            ? 'coordination'
            : 'workspace_delta';
      const workspaceLabel = typeof event.workspace_name === 'string' && event.workspace_name.trim()
        ? event.workspace_name
        : typeof event.workspace_id === 'string'
          ? event.workspace_id
          : 'Workspace';
      const sender = typeof event.sender === 'string'
        ? event.sender
        : typeof event.actor === 'string'
          ? event.actor
          : null;
      const receiver = typeof event.receiver === 'string' ? event.receiver : null;
      const summary = typeof event.summary === 'string' && event.summary.trim()
        ? event.summary
        : typeof event.text === 'string' && event.text.trim()
          ? event.text
          : 'Whispers reported collaboration activity.';
      const createdAt = typeof event.created_at === 'string' ? event.created_at : new Date(0).toISOString();
      const deltaKind = typeof event.delta_kind === 'string' ? event.delta_kind : '';
      const tone: CollaborationTone = kind === 'handoff'
        ? event.completed === true ? 'ok' : 'info'
        : kind === 'coordination'
          ? coordinationTone(event)
          : deltaKind === 'lifecycle' && typeof event.text === 'string' && event.text.includes('closed')
            ? 'ok'
            : 'info';

      return {
        id: `${String(event.workspace_id ?? 'workspace')}-${String(event.sequence ?? index)}-${kind}-${index}`,
        title: kind === 'handoff'
          ? sender && receiver
            ? `${sender} handed off to ${receiver}`
            : 'Structured handoff'
          : kind === 'coordination'
            ? coordinationTitle(event, sender, receiver)
            : humanizeDeltaKind(deltaKind),
        detail: summary,
        tone,
        createdAt,
        sourceLabel: kind === 'handoff' || kind === 'coordination'
          ? [sender, receiver].filter(Boolean).join(' -> ') || workspaceLabel
          : typeof event.actor === 'string' && event.actor.trim()
            ? event.actor
            : workspaceLabel,
        workspaceLabel,
        kind,
        batonChips: deriveCollaborationBatonChips(event, kind, deltaKind),
      };
    })
    .sort((a, b) => Date.parse(b.createdAt) - Date.parse(a.createdAt));
}

export function deriveOpenHandoffs(input: unknown): CollaborationHandoffCard[] {
  if (!Array.isArray(input)) return [];

  return input
    .filter((item): item is Record<string, unknown> => Boolean(item) && typeof item === 'object')
    .map((handoff) => {
      const fromAgent = typeof handoff.from_agent === 'string' ? handoff.from_agent : '?';
      const toAgent = typeof handoff.recipient_callsign === 'string' && handoff.recipient_callsign.trim()
        ? handoff.recipient_callsign
        : typeof handoff.to_agent === 'string' && handoff.to_agent.trim()
          ? handoff.to_agent
          : '?';
      const subject = typeof handoff.subject === 'string' && handoff.subject.trim()
        ? handoff.subject
        : 'Untitled handoff';
      const summary = typeof handoff.summary_human === 'string' && handoff.summary_human.trim()
        ? handoff.summary_human
        : typeof handoff.next_action === 'string' && handoff.next_action.trim()
          ? handoff.next_action
          : subject;

      return {
        id: String(handoff.uuid ?? `${fromAgent}-${toAgent}-${subject}`),
        route: `${fromAgent} -> ${toAgent}`,
        subject,
        summary,
        workspaceLabel: typeof handoff.workspace_id === 'string' && handoff.workspace_id.trim()
          ? handoff.workspace_id
          : 'Direct handoff',
        nextAction: typeof handoff.next_action === 'string' && handoff.next_action.trim()
          ? handoff.next_action
          : null,
        createdAt: typeof handoff.created_at === 'string' ? handoff.created_at : null,
        batonChips: deriveHandoffBatonChips(handoff),
      };
    })
    .filter((handoff) => handoff.id.length > 0);
}

export function deriveUnifiedFeed(input: UnifiedFeedInput): UnifiedFeedItem[] {
  const signalItems: UnifiedFeedItem[] = input.collaborationSignals.map((signal) => ({
    id: `health-${signal.signal_id}`,
    kind: 'health',
    badge: 'HEALTH',
    title: collaborationSignalTitle(signal),
    detail: signal.suggestion,
    tone: collaborationSignalTone(signal),
    createdAt: signal.detected_at,
    sourceLabel: signal.severity,
    workspaceLabel: null,
    agents: [],
    batonChips: [],
  }));

  const workspaceItems: UnifiedFeedItem[] = input.workspaceCards.map((workspace) => ({
    id: `workspace-${workspace.id}`,
    kind: 'workspace',
    badge: 'WORKSPACE',
    title: workspace.title,
    detail: workspace.purpose,
    tone: workspace.status === 'active' ? 'ok' : 'info',
    createdAt: workspace.lastActivityAt,
    sourceLabel: `${workspace.memberCount} members · seq ${workspace.sequence}`,
    workspaceLabel: workspace.id,
    agents: [],
    batonChips: [],
  }));

  const handoffItems: UnifiedFeedItem[] = input.handoffs.map((handoff) => ({
    id: `handoff-${handoff.id}`,
    kind: 'handoff',
    badge: 'HANDOFF',
    title: handoff.subject,
    detail: handoff.summary,
    tone: handoff.batonChips.some((chip) => chip.tone === 'blocked')
      ? 'error'
      : handoff.batonChips.some((chip) => chip.tone === 'review' || chip.tone === 'waiting')
        ? 'warn'
        : 'ok',
    createdAt: handoff.createdAt,
    sourceLabel: handoff.route,
    workspaceLabel: handoff.workspaceLabel,
    agents: parseAgentLabels(handoff.route),
    batonChips: handoff.batonChips,
  }));

  const collaborationItems: UnifiedFeedItem[] = input.collaborationFeed.map((event) => ({
    id: `runtime-${event.id}`,
    kind: event.kind === 'handoff' ? 'handoff' : 'runtime',
    badge: event.kind === 'handoff'
      ? 'HANDOFF'
      : event.kind === 'coordination'
        ? 'RUNTIME'
        : 'WORKSPACE',
    title: event.title,
    detail: event.detail,
    tone: event.tone === 'ok' ? 'ok' : event.tone === 'warn' ? 'warn' : 'info',
    createdAt: event.createdAt,
    sourceLabel: event.sourceLabel,
    workspaceLabel: event.workspaceLabel,
    agents: parseAgentLabels(event.sourceLabel),
    batonChips: event.batonChips,
  }));

  const backendItems: UnifiedFeedItem[] = input.backendActivity.map((event) => ({
    id: `signal-${event.id}`,
    kind: 'signal',
    badge: 'SIGNAL',
    title: event.title,
    detail: event.detail,
    tone: event.tone,
    createdAt: event.createdAt,
    sourceLabel: event.sourceLabel,
    workspaceLabel: null,
    agents: parseAgentLabels(event.sourceLabel),
    batonChips: [],
  }));

  const systemItems: UnifiedFeedItem[] = input.systemEvents.map((event) => ({
    id: `system-${event.id}`,
    kind: 'system',
    badge: 'SYSTEM',
    title: event.title,
    detail: event.detail,
    tone: event.tone,
    createdAt: event.createdAt,
    sourceLabel: event.sourceLabel,
    workspaceLabel: null,
    agents: parseAgentLabels(event.sourceLabel),
    batonChips: [],
  }));

  const messageItems: UnifiedFeedItem[] = input.messages.map((message, index) => {
    const sender = message.sender || message.from_agent || '?';
    const recipient = message.recipient || message.to || '?';
    const priority = typeof message.priority === 'string' ? message.priority : 'routine';
    const title = typeof message.subject === 'string' && message.subject.trim()
      ? message.subject
      : `${sender} -> ${recipient}`;
    return {
      id: `message-${message.created_at || index}-${sender}-${recipient}`,
      kind: 'message',
      badge: `MESSAGE ${priority.toUpperCase()}`,
      title,
      detail: summarizeBody(message.body ?? message.payload ?? ''),
      tone: priority === 'flash' || priority === 'critical'
        ? 'error'
        : priority === 'priority' || priority === 'urgent'
          ? 'warn'
          : 'info',
      createdAt: typeof message.created_at === 'string' ? message.created_at : null,
      sourceLabel: `${sender} -> ${recipient}`,
      workspaceLabel: null,
      agents: uniqueStrings([sender, recipient]),
      batonChips: [],
    };
  });

  return [
    ...signalItems,
    ...workspaceItems,
    ...handoffItems,
    ...collaborationItems,
    ...backendItems,
    ...systemItems,
    ...messageItems,
  ].sort((a, b) => {
    const aTime = a.createdAt ? Date.parse(a.createdAt) : Number.NEGATIVE_INFINITY;
    const bTime = b.createdAt ? Date.parse(b.createdAt) : Number.NEGATIVE_INFINITY;
    return bTime - aTime;
  });
}
