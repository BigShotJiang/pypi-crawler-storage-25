# Whispers Console Licensing Notice

This `dashboard/` directory is the open/base Console for Whispers.

Unless a more specific file notice says otherwise, the code and assets in this directory are licensed under Apache-2.0 as part of the public Whispers floor. See:

- [../LICENSE](../LICENSE)
- [../LICENSING.md](../LICENSING.md)

Premium `Whispers Works` Console modules are not included in this directory unless they are later added under an explicit separate notice.
