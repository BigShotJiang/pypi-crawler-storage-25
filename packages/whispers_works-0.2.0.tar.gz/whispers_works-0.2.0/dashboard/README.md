# Whispers Console

This directory contains the Whispers Operator Console application.

## Licensing

This directory is the open/base Console for Whispers and is part of the Apache-2.0 public floor unless a file in this directory explicitly says otherwise.

See:

- [LICENSE.md](LICENSE.md)
- [../LICENSING.md](../LICENSING.md)

## Development

This app currently uses React + TypeScript + Vite.

```bash
npm install
npm run dev
```
