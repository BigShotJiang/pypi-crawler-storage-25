import assert from 'node:assert/strict';
import test from 'node:test';
import config from '../vite.config';

test('dashboard build keeps the shipped UI under /ui/', () => {
  assert.equal(config.base, '/ui/');
  assert.equal(config.build?.outDir, '../whispers/ui');
});

test('dashboard dev server proxies the mesh routes to the local hub by default', () => {
  const proxy = (config.server as { proxy: Record<string, { target: string; changeOrigin: boolean }> }).proxy;
  const expectedRoutes = [
    '/connect',
    '/disconnect',
    '/active-mode',
    '/health',
    '/heartbeat',
    '/inbox',
    '/lease',
    '/livez',
    '/message:send',
    '/message:stream',
    '/mode',
    '/outbox',
    '/presence',
    '/readiness',
    '/readyz',
    '/runtime',
    '/status',
    '/token:create',
    '/token:revoke',
    '/token:rotate',
    '/trace',
    '/wag',
    '/whoami',
  ];

  for (const route of expectedRoutes) {
    assert.equal(proxy[route]?.target, 'http://127.0.0.1:8752');
    assert.equal(proxy[route]?.changeOrigin, true);
  }
});
