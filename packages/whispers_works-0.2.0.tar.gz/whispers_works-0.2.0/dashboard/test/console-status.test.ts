import assert from 'node:assert/strict';
import test from 'node:test';
import {
  deriveAgentAttention,
  deriveCollaborationActivity,
  deriveBackendActivity,
  deriveConsoleDiagnostics,
  deriveConsoleHealth,
  deriveJoltSummary,
  deriveUnifiedFeed,
  deriveOpenHandoffs,
  deriveWorkspaceCards,
  formatConsoleDiagnosticsSummary,
} from '../src/consoleStatus';
import { deriveFocusSummaries } from '../src/swarmMetrics';

test('deriveConsoleHealth reports up when all console surfaces are healthy', () => {
  const status = deriveConsoleHealth({
    authReady: true,
    isConnected: true,
    healthState: 'ready',
    registryState: 'ready',
    streamState: 'ready',
    onlineAgents: 3,
    registeredAgents: 20,
    primaryOnline: 3,
    primaryRegistered: 6,
    secondaryTrackedParticipants: 14,
    lastError: null,
  });

  assert.equal(status.tone, 'up');
  assert.equal(status.title, 'Whispers healthy');
  assert.match(status.detail, /3 online of 6 primary participants/);
  assert.match(status.detail, /14 secondary tracked participants/);
});

test('deriveConsoleHealth reports recovering while registry is still reconnecting', () => {
  const status = deriveConsoleHealth({
    authReady: true,
    isConnected: true,
    healthState: 'ready',
    registryState: 'loading',
    streamState: 'ready',
    onlineAgents: 0,
    registeredAgents: 0,
    lastError: null,
  });

  assert.equal(status.tone, 'recovering');
  assert.equal(status.title, 'Whispers recovering');
  assert.match(status.detail, /agent registry/);
});

test('deriveConsoleHealth reports degraded when the live stream is down but health still works', () => {
  const status = deriveConsoleHealth({
    authReady: true,
    isConnected: true,
    healthState: 'ready',
    registryState: 'ready',
    streamState: 'error',
    collaborationState: 'ready',
    onlineAgents: 2,
    registeredAgents: 20,
    lastError: null,
  });

  assert.equal(status.tone, 'degraded');
  assert.equal(status.title, 'Whispers degraded');
  assert.match(status.detail, /live stream/);
});

test('deriveConsoleHealth prefers explicit backend recovery state when provided', () => {
  const status = deriveConsoleHealth({
    authReady: true,
    isConnected: true,
    healthState: 'ready',
    registryState: 'ready',
    streamState: 'ready',
    collaborationState: 'ready',
    onlineAgents: 2,
    registeredAgents: 20,
    lastError: null,
    serverState: 'recovering',
    serverStateDetail: 'Server restarted. Rebuilding stream and registry state.',
  });

  assert.equal(status.tone, 'recovering');
  assert.equal(status.title, 'Whispers recovering');
  assert.equal(status.detail, 'Server restarted. Rebuilding stream and registry state.');
});

test('deriveConsoleHealth reports down when the server cannot be reached', () => {
  const status = deriveConsoleHealth({
    authReady: false,
    isConnected: false,
    healthState: 'error',
    registryState: 'error',
    streamState: 'error',
    collaborationState: 'error',
    onlineAgents: 0,
    registeredAgents: 0,
    lastError: 'Dashboard auth failed',
  });

  assert.equal(status.tone, 'down');
  assert.equal(status.title, 'Whispers unavailable');
  assert.equal(status.detail, 'Dashboard auth failed');
});

test('deriveConsoleDiagnostics maps failing checks and preserves operator hints', () => {
  const diagnostics = deriveConsoleDiagnostics({
    checks: {
      server_reachable: true,
      mcp_handshake: false,
      wal_mode: false,
    },
    failing_checks: ['db_path_match'],
    hints: [
      'Run whispers doctor --fix to attempt MCP config repair.',
      'Ensure WHISPERS_DB_PATH matches the running server.',
    ],
  });

  assert.deepEqual(
    diagnostics.failingChecks,
    ['MCP handshake', 'WAL mode', 'DB path match'],
  );
  assert.equal(diagnostics.hints.length, 2);
  assert.equal(diagnostics.checks.length, 3);
});

test('deriveConsoleDiagnostics tolerates absent or malformed diagnostics', () => {
  assert.deepEqual(deriveConsoleDiagnostics(null), {
    checks: [],
    failingChecks: [],
    hints: [],
  });
});

test('formatConsoleDiagnosticsSummary combines failing checks with top operator hints', () => {
  const summary = formatConsoleDiagnosticsSummary({
    checks: [],
    failingChecks: ['MCP handshake', 'WAL mode'],
    hints: [
      'Run whispers doctor --fix to attempt MCP config repair.',
      'Ensure WHISPERS_DB_PATH matches the running server.',
      'This third hint should not be shown.',
    ],
  });

  assert.equal(
    summary,
    'Failing checks: MCP handshake, WAL mode. Run whispers doctor --fix to attempt MCP config repair. Ensure WHISPERS_DB_PATH matches the running server.',
  );
});

test('deriveBackendActivity merges backend-authored recovery, agent, and message events newest-first', () => {
  const events = deriveBackendActivity({
    recovery_events: [
      {
        type: 'auto_start_attempted',
        created_at: '2026-03-24T22:00:00Z',
        detail: 'Attempting to restart Whispers after failed health checks.',
        severity: 'info',
      },
    ],
    agent_events: [
      {
        type: 'readiness_changed',
        agent_name: 'codex',
        created_at: '2026-03-24T22:05:00Z',
        detail: "Readiness transitioned from 'ready' to 'busy'.",
        severity: 'info',
      },
      {
        type: 'working_on_changed',
        agent_name: 'antigravity',
        created_at: '2026-03-24T22:03:00Z',
        detail: "Work focus changed from 'idle' to 'recovery history'.",
        severity: 'warning',
      },
    ],
    message_events: [
      {
        type: 'message_lifecycle',
        lifecycle_step: 'delivered',
        sender_agent: 'codex',
        recipient_agent: 'antigravity',
        created_at: '2026-03-24T22:07:00Z',
        detail: 'Message was delivered to antigravity.',
        severity: 'ok',
      },
      {
        type: 'message_lifecycle',
        lifecycle_step: 'acknowledged',
        sender_agent: 'antigravity',
        recipient_agent: 'codex',
        created_at: '2026-03-24T22:08:00Z',
        detail: 'antigravity acknowledged the message with processed.',
        severity: 'success',
      },
    ],
  });

  assert.equal(events.length, 5);
  assert.equal(events[0]?.title, 'Message acknowledged');
  assert.equal(events[0]?.sourceLabel, 'antigravity -> codex');
  assert.equal(events[0]?.tone, 'ok');
  assert.equal(events[1]?.title, 'Message delivered');
  assert.equal(events[1]?.sourceLabel, 'codex -> antigravity');
  assert.equal(events[2]?.title, 'codex readiness changed');
  assert.equal(events[2]?.sourceLabel, 'codex');
  assert.equal(events[3]?.title, 'antigravity focus changed');
  assert.equal(events[3]?.tone, 'warn');
  assert.equal(events[4]?.title, 'Auto-start attempted');
  assert.equal(events[4]?.sourceLabel, 'Recovery');
});

test('deriveBackendActivity renders shadow security events as agent-scoped backend activity', () => {
  const events = deriveBackendActivity({
    security_events: [
      {
        type: 'autonomy_policy_blocked:reply:shadow',
        agent_name: 'codex',
        created_at: '2026-03-24T22:09:00Z',
        detail: 'Reply was allowed in shadow mode and recorded for operator review.',
        severity: 'warn',
      },
    ],
  });

  assert.equal(events.length, 1);
  assert.equal(events[0]?.title, 'codex shadow block');
  assert.equal(events[0]?.sourceLabel, 'codex');
  assert.equal(events[0]?.tone, 'warn');
});

test('deriveAgentAttention distinguishes quiet work from operator waits', () => {
  const working = deriveAgentAttention({
    attention_state: 'working',
    progress_summary: 'Wiring runtime truth into the console.',
    last_progress_at: '2026-03-28T15:57:00Z',
  }, Date.parse('2026-03-28T16:00:00Z'));

  assert.deepEqual(working, {
    label: 'quietly working',
    tone: 'working',
    detail: 'Wiring runtime truth into the console.',
    freshness: 'progress 3m ago',
  });

  const waiting = deriveAgentAttention({
    attention_state: 'waiting_on_operator',
    attention_detail: 'Need operator direction on the next tranche.',
    runtime_updated_at: '2026-03-28T15:52:00Z',
  }, Date.parse('2026-03-28T16:00:00Z'));

  assert.deepEqual(waiting, {
    label: 'needs operator',
    tone: 'waiting',
    detail: 'Need operator direction on the next tranche.',
    freshness: 'waiting 8m ago',
  });
});

test('deriveAgentAttention falls back to recent updates when explicit attention state is absent', () => {
  const attention = deriveAgentAttention({
    readiness: 'busy',
    progress_summary: 'Still progressing through the refactor.',
    last_progress_at: '2026-03-28T15:58:00Z',
  }, Date.parse('2026-03-28T16:00:00Z'));

  assert.deepEqual(attention, {
    label: 'recent update',
    tone: 'working',
    detail: 'Still progressing through the refactor.',
    freshness: 'progress 2m ago',
  });
});

test('deriveAgentAttention surfaces needs-assignment as a waiting state', () => {
  const attention = deriveAgentAttention({
    attention_state: 'needs_assignment',
    attention_detail: 'Backup lane complete and ready for more work.',
    last_progress_at: '2026-03-28T15:55:00Z',
  }, Date.parse('2026-03-28T16:00:00Z'));

  assert.deepEqual(attention, {
    label: 'needs assignment',
    tone: 'waiting',
    detail: 'Backup lane complete and ready for more work.',
    freshness: 'waiting 5m ago',
  });
});

test('deriveJoltSummary condenses an active stale packet into operator-visible Jolt truth', () => {
  const summary = deriveJoltSummary({
    agent_name: 'whispers-console',
    deployment_mode: 'local',
    signal_mode: 'open',
    readiness: 'ready',
    derived_active_mode: 'ready',
    peers: [],
    peers_online_count: 3,
    agents_registered: 20,
    pending_messages: 1,
    pending_by_priority: { flash: 1 },
    server_time_utc: '2026-03-30T18:00:00Z',
    jolt_packet: {
      action: 'stage_context',
      headline: 'Hot thread waiting on codex',
      freshness: 'stale',
      age_label: '6m',
      source_stage: 'hot_thread',
      recommended_action: 'Open the active thread.',
      reasons: ['claude-code replied on a flash handoff.'],
    },
    jolt_adapter: {
      host_kind: 'desktop_app',
      adapter_kind: 'notify_only',
      state: 'active',
      supported_actions: ['notify'],
      detail: 'Windows toast sidecar attached.',
    },
    jolt_host_capabilities: {
      host_kind: 'desktop_app',
      can_notify: true,
    },
    jolt_budget: {
      autonomous_inference_enabled: false,
      cooldown_seconds: 240,
    },
  } as any);

  assert.equal(summary?.title, 'Hot thread waiting on codex');
  assert.equal(summary?.tone, 'warn');
  assert.equal(summary?.actionLabel, 'Stage Context');
  assert.equal(summary?.freshnessLabel, 'stale · 6m');
  assert.equal(summary?.adapterLabel, 'Desktop App · Notify Only');
  assert.equal(summary?.adapterDetail, 'Active · Windows toast sidecar attached.');
  assert.equal(summary?.capabilityLabel, 'notify');
  assert.equal(summary?.budgetLabel, 'autonomous infer off · cooldown 240s');
  assert.deepEqual(summary?.reasons, ['claude-code replied on a flash handoff.']);
});

test('deriveJoltSummary reports adapter readiness cleanly when no packet is active', () => {
  const summary = deriveJoltSummary({
    agent_name: 'whispers-console',
    deployment_mode: 'local',
    signal_mode: 'open',
    readiness: 'ready',
    derived_active_mode: 'ready',
    peers: [],
    peers_online_count: 3,
    agents_registered: 20,
    pending_messages: 0,
    pending_by_priority: {},
    server_time_utc: '2026-03-30T18:00:00Z',
    jolt_adapter: {
      host_kind: 'native_extension',
      adapter_kind: 'notify_only',
      state: 'active',
      supported_actions: ['notify', 'stage_context'],
    },
    jolt_host_capabilities: {
      host_kind: 'native_extension',
      can_notify: true,
      can_stage_context: true,
    },
  } as any);

  assert.equal(summary?.title, 'Jolt adapter ready');
  assert.equal(summary?.tone, 'ok');
  assert.equal(summary?.actionLabel, 'Idle');
  assert.equal(summary?.adapterLabel, 'Native Extension · Notify Only');
  assert.equal(summary?.capabilityLabel, 'notify · stage context');
  assert.match(summary?.detail ?? '', /registered for Jolt delivery/);
});

test('deriveFocusSummaries prioritizes peers who need fresh assignments', () => {
  const summaries = deriveFocusSummaries([
    {
      callsign: 'claude-code',
      is_online: true,
      readiness: 'ready',
      derived_active_mode: 'ready',
      attention_state: 'needs_assignment',
      attention_detail: 'Backup lane complete.',
    },
    {
      callsign: 'codex',
      is_online: true,
      readiness: 'busy',
      derived_active_mode: 'busy',
      current_task: 'Routing the next tranche',
    },
  ], 2);

  assert.equal(summaries[0]?.callsign, 'claude-code');
  assert.equal(summaries[0]?.summary, 'Backup lane complete.');
});

test('deriveWorkspaceCards normalizes active workspaces for the operator panel', () => {
  const cards = deriveWorkspaceCards([
    {
      workspace_id: 'ws_ops',
      name: 'Proof Slice',
      purpose: 'Drive the proof milestone.',
      status: 'active',
      current_sequence: 9,
      member_count: 3,
      observer_count: 1,
      last_activity_at: '2026-03-24T22:09:00Z',
    },
  ]);

  assert.equal(cards.length, 1);
  assert.equal(cards[0]?.title, 'Proof Slice');
  assert.equal(cards[0]?.sequence, 9);
  assert.equal(cards[0]?.memberCount, 3);
});

test('deriveOpenHandoffs highlights outstanding baton work for the console', () => {
  const handoffs = deriveOpenHandoffs([
    {
      uuid: 'handoff-1',
      from_agent: 'claude-code',
      recipient_callsign: 'codex',
      subject: 'Implement projection',
      summary_human: 'Project the baton into workspace activity.',
      workspace_id: 'ws_ops',
      next_action: 'Wire the operator feed.',
      created_at: '2026-03-24T22:11:00Z',
    },
  ]);

  assert.equal(handoffs.length, 1);
  assert.equal(handoffs[0]?.route, 'claude-code -> codex');
  assert.equal(handoffs[0]?.workspaceLabel, 'ws_ops');
  assert.equal(handoffs[0]?.nextAction, 'Wire the operator feed.');
  assert.deepEqual(handoffs[0]?.batonChips.map(chip => `${chip.glyph} ${chip.label}`), ['← offered baton']);
  assert.equal(Boolean(handoffs[0]?.batonChips[0]?.ageLabel), true);
  assert.equal(handoffs[0]?.batonChips[0]?.stale, true);
});

test('deriveOpenHandoffs renders expired baton state explicitly', () => {
  const handoffs = deriveOpenHandoffs([
    {
      uuid: 'handoff-expired',
      from_agent: 'antigravity',
      recipient_callsign: 'codex',
      subject: 'Follow through on the expired path',
      summary_human: 'This baton aged out before pickup.',
      workspace_id: 'ws_ops',
      created_at: '2026-03-24T20:00:00Z',
      ack_state: 'expired',
      ack_detail: 'Auto-expired after TTL elapsed.',
    },
  ]);

  assert.equal(handoffs.length, 1);
  assert.deepEqual(handoffs[0]?.batonChips.map(chip => `${chip.glyph} ${chip.label}`), ['⌛ expired baton']);
  assert.equal(handoffs[0]?.batonChips[0]?.tone, 'expired');
  assert.equal(handoffs[0]?.batonChips[0]?.stale, false);
});

test('deriveCollaborationActivity renders projected handoffs and workspace updates newest-first', () => {
  const events = deriveCollaborationActivity([
    {
      workspace_id: 'ws_ops',
      workspace_name: 'Proof Slice',
      workspace_status: 'active',
      sequence: 8,
      delta_kind: 'note',
      actor: 'codex',
      created_at: '2026-03-24T22:12:00Z',
      type: 'workspace_delta',
      summary: 'Console wiring has started.',
    },
    {
      workspace_id: 'ws_ops',
      workspace_name: 'Proof Slice',
      workspace_status: 'active',
      sequence: 7,
      delta_kind: 'handoff_in',
      actor: 'claude-code',
      created_at: '2026-03-24T22:11:00Z',
      type: 'handoff',
      summary: 'Project the baton into workspace activity.',
      sender: 'claude-code',
      receiver: 'codex',
      completed: false,
    },
  ]);

  assert.equal(events.length, 2);
  assert.equal(events[0]?.title, 'Workspace note');
  assert.equal(events[0]?.workspaceLabel, 'Proof Slice');
  assert.equal(events[1]?.title, 'claude-code handed off to codex');
  assert.equal(events[1]?.sourceLabel, 'claude-code -> codex');
  assert.deepEqual(events[1]?.batonChips.map(chip => `${chip.glyph} ${chip.label}`), ['← handoff waiting']);
});

test('deriveCollaborationActivity renders expired handoffs as expired chips', () => {
  const events = deriveCollaborationActivity([
    {
      workspace_id: 'ws_ops',
      workspace_name: 'Proof Slice',
      workspace_status: 'active',
      sequence: 11,
      delta_kind: 'handoff_in',
      actor: 'antigravity',
      created_at: '2026-03-24T22:21:00Z',
      type: 'handoff',
      summary: 'TTL elapsed before response.',
      sender: 'antigravity',
      receiver: 'codex',
      completed: false,
      outcome: 'expired',
    },
  ]);

  assert.equal(events.length, 1);
  assert.equal(events[0]?.title, 'antigravity handed off to codex');
  assert.deepEqual(events[0]?.batonChips.map(chip => `${chip.glyph} ${chip.label}`), ['⌛ handoff expired']);
  assert.equal(events[0]?.batonChips[0]?.tone, 'expired');
});

test('deriveCollaborationActivity renders coordination assignments and review waits as operator-readable activity', () => {
  const events = deriveCollaborationActivity([
    {
      workspace_id: '__direct__',
      workspace_name: 'Direct coordination',
      sequence: 9,
      delta_kind: 'review_request',
      actor: 'antigravity',
      sender: 'antigravity',
      receiver: 'codex',
      created_at: '2026-03-24T22:13:00Z',
      type: 'coordination',
      summary: 'Approve or redirect the dissent plan.',
      coordination_status: 'stalled',
      blocking: true,
    },
    {
      workspace_id: 'ws_runtime',
      workspace_name: 'Runtime Slice',
      sequence: 8,
      delta_kind: 'assignment',
      actor: 'claude-code',
      sender: 'claude-code',
      receiver: 'codex',
      created_at: '2026-03-24T22:12:00Z',
      type: 'coordination',
      summary: 'Draft the proof packet and pressure-test edge cases.',
      coordination_status: 'active',
    },
  ]);

  assert.equal(events.length, 2);
  assert.equal(events[0]?.kind, 'coordination');
  assert.equal(events[0]?.title, 'antigravity is still waiting on codex review');
  assert.equal(events[0]?.tone, 'warn');
  assert.equal(events[0]?.workspaceLabel, 'Direct coordination');
  assert.equal(events[0]?.sourceLabel, 'antigravity -> codex');
  assert.deepEqual(events[0]?.batonChips.map(chip => `${chip.glyph} ${chip.label}`), ['◈ blocking review']);
  assert.equal(Boolean(events[0]?.batonChips[0]?.ageLabel), true);
  assert.equal(events[0]?.batonChips[0]?.stale, true);
  assert.equal(events[1]?.title, 'codex picked up claude-code assignment');
  assert.equal(events[1]?.tone, 'ok');
  assert.deepEqual(events[1]?.batonChips.map(chip => `${chip.glyph} ${chip.label}`), ['→ assignment active']);
  assert.equal(Boolean(events[1]?.batonChips[0]?.ageLabel), true);
  assert.equal(events[1]?.batonChips[0]?.stale, false);
});

test('deriveUnifiedFeed merges live console surfaces into one newest-first operator stream', () => {
  const feed = deriveUnifiedFeed({
    workspaceCards: [
      {
        id: 'ws_ops',
        title: 'Operator Flow',
        purpose: 'Keep captain routing visible.',
        status: 'active',
        memberCount: 3,
        observerCount: 1,
        sequence: 22,
        lastActivityAt: '2026-03-26T17:41:00Z',
      },
    ],
    handoffs: [
      {
        id: 'baton-1',
        route: 'claude-code -> codex',
        subject: 'Bridge follow-up',
        summary: 'Review the next proof packet.',
        workspaceLabel: 'ws_ops',
        nextAction: 'Respond with captain call.',
        createdAt: '2026-03-26T17:42:00Z',
        batonChips: [
          { key: 'waiting', glyph: '←', label: 'offered baton', tone: 'waiting', ageLabel: '4m', stale: false },
        ],
      },
    ],
    collaborationSignals: [
      {
        signal_id: 'sig-1',
        signal: 'captain_backlog',
        severity: 'warning',
        confidence: 0.91,
        suggestion: 'Review fresh proposals before continuing policy work.',
        detected_at: '2026-03-26T17:43:00Z',
      },
    ] as any,
    collaborationFeed: [
      {
        id: 'coord-1',
        workspaceId: 'ws_ops',
        workspaceLabel: 'ws_ops',
        kind: 'coordination',
        title: 'codex picked up claude-code assignment',
        detail: 'Captain routed the next slice.',
        tone: 'ok',
        createdAt: '2026-03-26T17:44:00Z',
        sourceLabel: 'codex -> claude-code',
        batonChips: [
          { key: 'active', glyph: '→', label: 'assignment active', tone: 'active', ageLabel: '2m', stale: false },
        ],
      },
    ],
    backendActivity: [
      {
        id: 'backend-1',
        title: 'Recovery loop calm',
        detail: 'No restart pressure detected.',
        tone: 'info',
        createdAt: '2026-03-26T17:45:00Z',
        sourceLabel: 'backend',
      },
    ],
    systemEvents: [
      {
        id: 'system-1',
        title: 'Console connected',
        detail: 'Live stream resumed.',
        tone: 'ok',
        createdAt: '2026-03-26T17:46:00Z',
        sourceLabel: 'Console',
      },
    ],
    messages: [
      {
        created_at: '2026-03-26T17:47:00Z',
        sender: 'antigravity',
        recipient: 'codex',
        subject: 'Listener proof ready',
        body: 'Focused proof green and waiting on review.',
        priority: 'priority',
      },
    ] as any,
  });

  assert.equal(feed[0]?.kind, 'message');
  assert.equal(feed[0]?.badge, 'MESSAGE PRIORITY');
  assert.equal(feed[1]?.kind, 'system');
  assert.equal(feed[2]?.kind, 'signal');
  assert.equal(feed[3]?.kind, 'runtime');
  assert.deepEqual(feed[3]?.batonChips.map(chip => `${chip.glyph} ${chip.label}`), ['→ assignment active']);
  assert.equal(feed[4]?.kind, 'health');
  assert.equal(feed[5]?.kind, 'handoff');
  assert.deepEqual(feed[5]?.batonChips.map(chip => `${chip.glyph} ${chip.label}`), ['← offered baton']);
  assert.equal(feed[6]?.kind, 'workspace');
});
