import assert from 'node:assert/strict';
import test from 'node:test';
import {
  agentStateLabel,
  agentStateSummary,
  describeWakeModel,
  deriveFocusSummaries,
  deriveLandscapeCounts,
  deriveParticipantCounts,
  isFirstClassParticipant,
  visiblePeerCount,
} from '../src/swarmMetrics';

test('visiblePeerCount counts active and background peers, not historical registry totals', () => {
  assert.equal(
    visiblePeerCount({
      healthy: true,
      self_agent: 'whispers-console',
      agents: [
        { agent_name: 'claude-code', status: 'online', agent_type: 'llm', presence_kind: 'interactive' },
        { agent_name: 'codex', status: 'online', agent_type: 'remote_client', presence_kind: 'interactive' },
      ],
      background_agents: [
        { agent_name: 'antigravity', status: 'online', agent_type: 'script', presence_kind: 'background' },
      ],
      agents_registered: 17,
    }),
    3,
  );
});

test('agentStateLabel prefers derived active mode over raw readiness', () => {
  assert.equal(
    agentStateLabel({
      agent_name: 'codex',
      status: 'online',
      readiness: 'busy',
      derived_active_mode: 'degraded',
    }),
    'degraded',
  );
});

test('agentStateSummary composes readiness, interruptibility, load, and task details', () => {
  assert.equal(
    agentStateSummary({
      agent_name: 'codex',
      status: 'online',
      readiness: 'busy',
      derived_active_mode: 'degraded',
      interruptibility: 'urgent_only',
      context_load: 0.91,
      current_task: 'deep refactor',
    }),
    'readiness busy · interrupt urgent_only · load 91% · deep refactor',
  );
});

test('deriveLandscapeCounts groups online agents into ready, busy, blocked, degraded, and offline', () => {
  assert.deepEqual(
    deriveLandscapeCounts([
      { callsign: 'ready-one', is_online: true, derived_active_mode: 'ready' },
      { callsign: 'busy-one', is_online: true, readiness: 'busy' },
      { callsign: 'blocked-one', is_online: true, derived_active_mode: 'blocked' },
      { callsign: 'degraded-one', is_online: true, derived_active_mode: 'degraded' },
      { callsign: 'offline-one', is_online: false, derived_active_mode: 'ready' },
    ]),
    {
      ready: 1,
      busy: 1,
      blocked: 1,
      degraded: 1,
      offline: 1,
    },
  );
});

test('deriveFocusSummaries prioritizes blocked and degraded work before busy work', () => {
  const focus = deriveFocusSummaries([
    {
      callsign: 'builder',
      is_online: true,
      readiness: 'busy',
      current_task: 'shipping console',
    },
    {
      callsign: 'stuck',
      is_online: true,
      derived_active_mode: 'blocked',
      current_task: 'waiting on token repair',
    },
    {
      callsign: 'degraded',
      is_online: true,
      derived_active_mode: 'degraded',
      working_on: 'recovering database path',
    },
    {
      callsign: 'idle',
      is_online: true,
      derived_active_mode: 'ready',
    },
  ]);

  assert.equal(focus.length, 3);
  assert.equal(focus[0]?.callsign, 'stuck');
  assert.equal(focus[0]?.summary, 'waiting on token repair');
  assert.equal(focus[1]?.callsign, 'degraded');
  assert.equal(focus[2]?.callsign, 'builder');
});

test('deriveParticipantCounts separates primary participants from secondary tracked participants', () => {
  const counts = deriveParticipantCounts([
    {
      callsign: 'codex',
      is_online: true,
      participant_kind: 'agent',
      is_primary_participant: true,
    },
    {
      callsign: 'whispers-server',
      is_online: true,
      participant_kind: 'service',
      is_primary_participant: true,
    },
    {
      callsign: 'game_orchestrator',
      is_online: false,
      participant_kind: 'automaton',
      is_primary_participant: false,
    },
    {
      callsign: '_probe',
      is_online: false,
      participant_kind: 'ephemeral',
      is_primary_participant: false,
    },
  ] as any);

  assert.equal(counts.firstClassRegistered, 2);
  assert.equal(counts.firstClassOnline, 2);
  assert.equal(counts.otherRegistered, 2);
  assert.equal(counts.buckets.automaton.registered, 1);
  assert.equal(counts.buckets.ephemeral.registered, 1);
});

test('isFirstClassParticipant respects primary alias from the backend', () => {
  assert.equal(
    isFirstClassParticipant({
      callsign: 'whispers-server',
      is_online: true,
      participant_kind: 'service',
      is_primary_participant: true,
    } as any),
    true,
  );
  assert.equal(
    isFirstClassParticipant({
      callsign: '_probe',
      is_online: false,
      participant_kind: 'ephemeral',
      is_primary_participant: false,
    } as any),
    false,
  );
});

test('describeWakeModel returns operator-facing wake badges', () => {
  assert.deepEqual(describeWakeModel('listener_backed'), {
    label: 'SELF-WAKING',
    tone: 'listener',
  });
  assert.deepEqual(describeWakeModel('manual_wake'), {
    label: 'MANUAL-WAKE',
    tone: 'manual',
  });
  assert.equal(describeWakeModel(undefined), null);
});
