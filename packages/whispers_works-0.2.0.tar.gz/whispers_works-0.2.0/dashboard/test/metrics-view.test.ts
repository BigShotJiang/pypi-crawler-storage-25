import assert from 'node:assert/strict';
import test from 'node:test';
import { deriveThroughputBars, metricsSummaryFacts } from '../src/metricsView';

test('deriveThroughputBars scales recent buckets into chart bars', () => {
  const bars = deriveThroughputBars([
    { hour: '2026-03-26T16:00:00Z', sent: 2, delivered: 2, failed: 0 },
    { hour: '2026-03-26T17:00:00Z', sent: 8, delivered: 7, failed: 1 },
  ] as any, 12);

  assert.equal(bars.length, 2);
  assert.equal(bars[0]?.label, '4p');
  assert.equal(bars[1]?.label, '5p');
  assert.ok((bars[1]?.heightPct ?? 0) > (bars[0]?.heightPct ?? 0));
});

test('metricsSummaryFacts turns summary values into compact operator facts', () => {
  const facts = metricsSummaryFacts({
    messages_today: 47,
    delivery_success_rate: 1,
    delivery_success_pct: '100.0%',
    agents_online: 3,
    active_workspaces: 2,
    handoffs_today: 5,
    handoff_ack_rate: 0.8,
    handoff_ack_pct: '80.0%',
    period_start: '2026-03-26T00:00:00Z',
    period_end: '2026-03-26T18:00:00Z',
  } as any);

  assert.deepEqual(facts, [
    '47 messages today',
    '100.0% delivery success',
    '5 handoffs today',
    '80.0% handoff acknowledgment',
  ]);
});
