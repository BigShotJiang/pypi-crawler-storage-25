import assert from 'node:assert/strict';
import test from 'node:test';
import { deriveExecutionBoard } from '../src/executionBoard';

test('deriveExecutionBoard overlays live owner state and collaboration signals', () => {
  const cards = deriveExecutionBoard({
    registry: [
      {
        callsign: 'codex',
        is_online: true,
        derived_active_mode: 'busy',
        readiness: 'busy',
        current_task: 'landing startup slice',
      },
      {
        callsign: 'claude-code',
        is_online: true,
        derived_active_mode: 'ready',
        readiness: 'ready',
        working_on: 'conversation pulse runtime',
      },
      {
        callsign: 'antigravity',
        is_online: false,
        derived_active_mode: 'offline',
        readiness: 'offline',
      },
    ] as any,
    workspaces: [
      { workspace_id: 'ws_runtime', name: 'Runtime', purpose: 'Operator visibility', status: 'active' },
    ] as any,
    handoffs: [
      { uuid: 'h1', from_agent: 'claude-code', to_agent: 'codex', subject: 'Visibility pass' },
      { uuid: 'h2', from_agent: 'codex', to_agent: 'antigravity', subject: 'Liveness follow-up' },
    ] as any,
    activity: [
      { id: 'a1', type: 'execution_update', actor: 'codex' },
      { id: 'a2', type: 'decision', actor: 'claude-code' },
      { id: 'a3', type: 'status_update', actor: 'antigravity' },
    ] as any,
    connectionStory: {
      agent_name: 'codex',
      deployment_mode: 'standalone',
      signal_mode: 'OPEN',
      readiness: 'ready',
      derived_active_mode: 'ready',
      peers: [{ callsign: 'whispers-console' }],
      peers_online_count: 1,
      agents_registered: 26,
      pending_messages: 0,
      pending_by_priority: {},
      recommended_action: 'Stay in active collaboration.',
      server_time_utc: '2026-03-26T17:30:43Z',
    } as any,
    conversationPulses: [
      { conversation_key: 'direct:claude-code:codex', state: 'active', headline: 'claude-code ↔ codex active · 4 exchanges in 8s' },
      { conversation_key: 'direct:antigravity:codex', state: 'recent', headline: 'antigravity ↔ codex recent' },
    ] as any,
    repoLanes: [
      { agent_name: 'codex', branch: 'codex/2ack-p1-post-ws0', dirty: false, lane_state: 'active' },
      { agent_name: 'claude-code', branch: 'codex/2ack-p1-post-ws0', dirty: true, lane_state: 'superseded' },
    ] as any,
    repoDivergence: [
      { agent_a: 'codex', agent_b: 'claude-code', reason: 'same_branch_different_heads' },
    ] as any,
    operatorBoard: {
      as_of: 1711650000.5,
      sequence_id: 42,
      agents: {
        codex: {
          online: true,
          readiness: 'busy',
          attention_state: 'working',
          current_task: 'landing startup slice',
          active_assignments: 2,
          pending_assignments: 1,
          blocking_reviews: 0,
          incoming_batons: 1,
          carrying_batons: 2,
          claimed_reviews: 1,
        },
      },
      system: {
        agents_online: 2,
        total_active_assignments: 3,
        total_pending_assignments: 2,
        total_blocking_reviews: 1,
        total_batons_in_flight: 5,
        health_signals_active: 0,
        workspaces_active: 1,
      },
    } as any,
    healthTone: 'up',
    streamState: 'ready',
    collaborationState: 'ready',
  });

  assert.equal(cards.length, 5);

  const startup = cards.find((card) => card.id === 'arrival-startup');
  assert.ok(startup);
  assert.equal(startup.liveSignal, 'OPEN/ready · 0 unread · 1 peer online · standalone deployment');
  assert.deepEqual(startup.highlights, [
    'Stay in active collaboration.',
    'whispers-console: ready',
  ]);
  assert.equal(startup.owners[0]?.callsign, 'codex');
  assert.equal(startup.owners[0]?.activeMode, 'busy');

  const topology = cards.find((card) => card.id === 'visibility-coordination');
  assert.ok(topology);
  assert.equal(
    topology.liveSignal,
    '1 active pulses, 1 recent, 2 open handoffs, 3 collaboration events. 2 pending, 1 blocking, 5 batons in flight.',
  );
  assert.deepEqual(topology.highlights, [
    'claude-code ↔ codex active · 4 exchanges in 8s',
    'antigravity ↔ codex recent',
  ]);

  const liveness = cards.find((card) => card.id === 'liveness-presence');
  assert.ok(liveness);
  assert.equal(
    liveness.liveSignal,
    '1 ready, 1 busy, 0 blocked, 1 offline.',
  );

  const repo = cards.find((card) => card.id === 'repo-worktree');
  assert.ok(repo);
  assert.equal(repo.liveSignal, '2 published lanes, 1 dirty, 1 superseded, 1 divergence warning.');
  assert.deepEqual(repo.highlights, [
    'codex: codex/2ack-p1-post-ws0 @ unknown',
    'claude-code: codex/2ack-p1-post-ws0* @ unknown [superseded]',
  ]);

  const board = cards.find((card) => card.id === 'execution-board');
  assert.ok(board);
  assert.equal(board.liveSignal, 'Runtime-backed by connection story, conversation pulses, repo lanes, operator board.');
  assert.deepEqual(board.highlights, [
    'Connection Story for codex',
    '2 pulses visible',
    '2 repo lanes published',
    'Board seq 42 · 2 pending · 1 blocking',
  ]);
});

test('arrival-startup card surfaces captain action alerts ahead of peer summaries', () => {
  const cards = deriveExecutionBoard({
    registry: [
      {
        callsign: 'codex',
        is_online: true,
        derived_active_mode: 'busy',
        readiness: 'busy',
      },
    ] as any,
    workspaces: [] as any,
    handoffs: [] as any,
    activity: [] as any,
    connectionStory: {
      agent_name: 'codex',
      deployment_mode: 'standalone',
      signal_mode: 'OPEN',
      readiness: 'busy',
      derived_active_mode: 'busy',
      peers: [{ callsign: 'claude-code', derived_active_mode: 'ready', readiness: 'ready' }],
      peers_online_count: 1,
      agents_registered: 26,
      pending_messages: 2,
      pending_by_priority: { priority: 2 },
      recommended_action: 'Review claude-code proposal -- bridge tests are waiting.',
      captain_action_alerts: [
        {
          sender: 'claude-code',
          label: 'proposal',
          detail: 'Bridge tests are waiting.',
        },
      ],
      server_time_utc: '2026-03-26T17:30:43Z',
    } as any,
    conversationPulses: [] as any,
    repoLanes: [] as any,
    repoDivergence: [] as any,
    operatorBoard: null,
    healthTone: 'up',
    streamState: 'ready',
    collaborationState: 'ready',
  });

  const startup = cards.find((card) => card.id === 'arrival-startup');
  assert.ok(startup);
  assert.deepEqual(startup.highlights, [
    'Review claude-code proposal -- bridge tests are waiting.',
    'claude-code: proposal · Bridge tests are waiting.',
    'claude-code: ready',
  ]);
});
