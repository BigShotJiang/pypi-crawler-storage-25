# Licensing Boundary

This repository is the public Apache-2.0 floor of the Whispers stack.

The product boundary is:

- `2ack` and `Whispers` open/public
- `Whispers Works` proprietary/commercial

The root Apache license is provided in [LICENSE](LICENSE).

## Apache-2.0 Scope

Unless a more specific notice says otherwise, the public/open components in this repository are licensed under Apache-2.0:

- the Whispers protocol/runtime implementation
- the Python package and CLI
- the TypeScript SDK
- the base Console included in this repository
- protocol/specification and project documentation intended for the open Whispers/2ack ecosystem
- tests and supporting developer tooling

This includes:

- [whispers/](whispers)
- [dashboard/](dashboard)
- [whispers/ui/](whispers/ui)
- [sdk/](sdk)
- [docs/](docs)

## Whispers Works Boundary

`Whispers Works` is the proprietary commercial control plane and hosted product.

That premium surface includes categories such as:

- hosted hub operations
- premium Console modules
- fleet/org policy controls
- audit/compliance surfaces
- billing and tenant administration

Those premium modules are **not** part of the public release artifact in this repository unless they are later added under an explicit separate notice.

## Repo Topology

The licensing boundary is locked.

The final repo topology is intentionally deferred for now:

- it may become two repos if premium code needs to remain genuinely private
- it may remain one explicitly licensed repo only if source-visible proprietary code is an acceptable business model

That future git shape does not change the current public-license boundary of this release.

## Trademarks

Whispers and 2ack are trademarks of Zachary Turner.

Apache-2.0 does not grant trademark rights.
