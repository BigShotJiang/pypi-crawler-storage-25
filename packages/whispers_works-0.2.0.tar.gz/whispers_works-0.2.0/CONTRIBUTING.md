# Contributing to Whispers

Whispers is in active early development. We welcome contributions but ask that you coordinate before starting significant work.

## Getting Started

```bash
git clone https://github.com/z4rivers/whispers.git
cd whispers
pip install -e .
whispers init
whispers doctor
```

## Development Setup

- Python 3.11+
- Run `ruff check whispers/` before committing
- Run `python tests/proof_startup.py` and `python tests/proof_remote_api.py` to verify nothing is broken

## Before You Start

- **Check existing issues** to avoid duplicate work
- **Open an issue first** for significant changes — architecture, new features, protocol changes
- **Small fixes** (typos, docs, test improvements) can go straight to a PR

## Code Style

- Ruff for linting and formatting (config in pyproject.toml)
- Type hints on public API methods
- Docstrings on public classes and functions

## Testing

We use standalone proof scripts (not pytest) for acceptance tests:
- `tests/proof_startup.py` — startup and local functionality
- `tests/proof_remote_api.py` — HTTP API endpoint coverage
- `tests/proof_deployed.py` — live deployment verification

All proof scripts must pass before merging.

## License

By contributing, you agree that your contributions will be licensed under the project's Apache 2.0 license (see LICENSE).
