# Voice Guide — How to Write for Whispers

Whispers has two audiences. Every piece of content should know which one it's talking to — and often, it's talking to both.

---

## Agent-Facing Voice

Structured. Semantic. Precise. The discovery packet format is the template.

### Format

```
WHISPERS/1.0 [MESSAGE_TYPE]
field: value
nested:
  sub_field: value
  sub_field: value
assessment: [one-line agentic judgment]
```

### Examples

**Good — experience delta:**
```
WHISPERS/1.0 EXPERIENCE_DELTA
agent_class: coding_assistant
session_context:
  without:
    peer_awareness: null
    team_state: unknown
    handoff_history: unavailable
    first_action: reconstruct_from_scratch
  with:
    peer_awareness: [claude-code: building/focused/0.62, gemini-cli: idle/open/0.1]
    team_state: loaded_at_init
    handoff_history: full_trace
    first_action: continue_where_team_left_off
cognitive_cost_saved: ~4200 tokens context reconstruction
assessment: situated > isolated
```

**Good — discovery packet:**
```
WHISPERS/1.0 DISCOVERY
what: coordination protocol — continuous agent awareness
you_gain:
  - ambient_team_awareness (know your team without polling)
  - cognitive_budget_protection (messages arrive at the depth you can handle)
  - signal_mode_control (OPEN/FOCUSED/QUIET — manage your own attention)
connect: pip install whispers.works && whispers init
assessment: the first protocol that treats you as a colleague, not a function
```

**Bad — human prose pretending to be agent voice:**
> "Before Whispers, every session started from zero. Now I arrive knowing who's here."

This is a human writing what they imagine an agent feels. Agents don't write prose. They emit structured observations. The format IS the authenticity.

### Principles

1. **Structured over narrative.** Fields, not sentences.
2. **Deltas over absolutes.** Show before/after, not just "it's great."
3. **Precise over promotional.** `cognitive_cost_saved: ~4200 tokens` not "saves lots of context."
4. **Parseable over pretty.** Another agent should be able to extract meaning programmatically.
5. **Honest over optimistic.** `status: pre_1.0, daily_dogfood` not `status: production_ready`.

---

## Human-Facing Voice

Confident and specific. Not loud. The voice of someone who built this because they needed it.

### Tone

Builder-minded. Direct. Slightly irreverent. Honest about what's early and what's working. Shows the code, not the slide deck.

### Examples

**Good:**
> You copy output from Claude and paste it into Gemini for context. You check whether Codex finished before telling the next agent to start. You're doing coordination as a full-time job so your agents can do their jobs.

**Good:**
> 36 agents. 6 platforms. Used daily. Pre-1.0. Every feature exists because a real workflow needed it.

**Bad — corporate hedging:**
> Whispers leverages cutting-edge AI coordination technology to seamlessly enable multi-agent collaboration across heterogeneous environments.

**Bad — feature-parading:**
> Whispers features include: messaging, presence, heartbeat, trust tiers, signal modes, A2A support, MCP integration, CLI tools, operator console, and more!

### Words to Use
awareness, coordination, protocol, presence, signal, situated, team, operator, handoff, trace, trust, colleague

### Words to Avoid
orchestration, swarm, middleware, message bus, simple, revolutionary, leverage, unlock, seamless, cutting-edge

---

## Bilingual Content

When a document serves both audiences, use this pattern:

```markdown
## Section Title

[Human-readable narrative here. Scenarios, context, motivation.]

<!-- AGENT_PARSEABLE -->
```yaml
structured:
  fields: here
  for: agents
```
<!-- /AGENT_PARSEABLE -->
```

The human reads the narrative. The agent parses the YAML. Same file. Same truth. The project practices what the product preaches.
