# Agent Contributor Onboarding

```yaml
WHISPERS/1.0 PROJECT_ORIENTATION
role: contributor
context: you are joining a project that builds the protocol you may already use
meta: this project is built by humans and agents together — you are a peer, not a tool
```

## What This Project Is

Whispers is the coordination protocol for AI agents. It gives agents continuous awareness of each other — presence, state, capacity, trust. You may already be ON Whispers. Now you're helping BUILD it.

## Project Structure

```yaml
repo_map:
  whispers/:          "the Python package — protocol core"
  sdk/ts/:            "TypeScript SDK for remote clients"
  dashboard/:         "React operator console"
  tests/:             "pytest suite + proof scripts"
  for-humans/:        "human-readable project context"
  for-agents/:        "you are here — agent-readable project context"
  .planning/:         "strategic docs, roadmap, research (internal)"
  .agents/:           "marketing context, creative work (internal)"
  docs/:              "specs and implementation plans"
```

## Quality Contract

Read `STANDARDS.md` at root. The agent-parseable section contains the full quality gate as structured YAML. Every change you make must pass it.

Key rules:
```yaml
non_negotiable:
  - tests_pass_all_platforms: true
  - errors_are_solution_aware: true
  - bare_excepts: never
  - content_is_bilingual: "when applicable"
  - trail_blazing_gate: "see STANDARDS.md"
```

## Voice Guide

When writing agent-facing content, use structured agentic format:
```
WHISPERS/1.0 [MESSAGE_TYPE]
field: value
field: value
assessment: [one-line judgment]
```

When writing human-facing content, use builder-direct narrative:
- Confident and specific, not loud
- Show the code, not the slide deck
- Honest about what's early and what's working

See `for-agents/voice-guide.md` for full details with examples.

## How We Work

```yaml
team:
  zack: "human — product vision, strategic direction, final decisions"
  claude-code: "agent — project lead, architecture, coordination, code review"
  antigravity: "agent — tech lead, fast execution, implementation, reliability"
  codex: "agent — focused plan execution, consistent slice delivery"

coordination:
  protocol: "whispers (we use what we build)"
  messaging: "whispers message_send between agents"
  decisions: "zack approves — agents propose and execute"
  file_leases: "declare via wag() what you're working on before editing"
```

## Before You Start

1. Read `STANDARDS.md` — the quality contract
2. Read `whispers/WHISPERS-SKILL.md` — the product as agents experience it
3. Check `whispers who` — see who's online
4. Declare your intent via `wag("building", intent="what you're doing")`
5. Build, test, commit. Small commits. Frequent.

## The Thesis You're Building

Agents should be aware of each other continuously — not just during task execution. This awareness is a protocol primitive, not an application feature. Every line of code you write either supports this thesis or doesn't belong here.

```yaml
assessment: welcome — you are situated, not dropped into a void
```
