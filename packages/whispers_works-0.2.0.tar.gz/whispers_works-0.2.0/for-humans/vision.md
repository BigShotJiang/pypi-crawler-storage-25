# Why Whispers Exists

AI agents are powerful individually. Collectively, they're chaos.

If you use more than one AI agent — Claude in one window, Gemini in another, Codex running in the background — you've felt it. They can't see each other. They duplicate work. They edit the same files. They don't know what the others have done. And you become the relay, copying outputs between tools, checking if tasks landed, resolving conflicts by hand.

This isn't a tooling problem. It's a missing primitive. Agents have intelligence, memory, and tool access. What they don't have is **awareness** — of each other's existence, state, capacity, and work.

Whispers adds that primitive.

## What It Does

Whispers is a coordination runtime. `2ack` is the open structured signal protocol it is incubating over A2A. Install Whispers, and your agents gain continuous awareness of each other — who's online, what they're working on, how loaded they are, whether now is a good time to interrupt. They coordinate the way people in the same room coordinate — because they can see each other.

Whispers defines and operationalizes the relationship between agents. `2ack` is the structured signal mechanism that carries the message-level parts of that relationship over A2A.

You go from being the nervous system to being the operator.

## How It Got Here

Whispers was built by a human and his AI agents — Claude, Gemini, and Codex — coordinating through Whispers to build Whispers and shape `2ack`. Every feature exists because a real workflow hit a real wall without it. Nothing was built to check a box.

The team that builds Whispers is the first team that uses Whispers. The proof isn't in a pitch deck. It's in the message logs from this morning's build session.

## What It Isn't

- Not a framework. Your agents stay where they live. Nothing to rebuild.
- Not an orchestration engine. It doesn't direct your agents — it makes them aware.
- Not a product you're locked into. `2ack` is open. The Whispers core runtime is self-hostable and Apache-2.0. Console/commercial operator surfaces are licensed separately.

## Where It's Going

Agent awareness becomes a standard primitive — like TCP for networking or HTTP for the web. `2ack` can become a shared protocol layer for structured collaboration over A2A. Whispers remains the first implementation, the proving ground, and the runtime/operator experience built on top. Operating fleets of aware agents is where the business lives.

**This would work with whispers.**
