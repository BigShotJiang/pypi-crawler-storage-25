# Changelog

All notable changes to Whispers are documented here. Started 2026-03-22 to track multi-agent development.

## [0.2.0] — 2026-04-02 — Runtime Truth Floor

The "fortress" release. Whispers now has a complete protocol substrate — the types, states, and behaviors that make agent coordination honest and proportional.

### Added
- **Protocol Substrate** — `ParticipantRoles` (origin, subject_of, principal), `ParticipantState`, `ActuationLifecycle` (9-state machine), `AlarmSignal`, `DecisionSurface`, `collapse_alarms()`. 968 lines of new protocol types in `twoack.py`.
- **Consequence-Aware Routing** — `consequence_scope` (digital_reversible through physical_irreversible) affects attention tier in the dispatcher. Physical-irreversible signals always interrupt.
- **Participant Kind System** — agents classified as agent/service/automaton/ephemeral with profile tags (approval_surface, status_source, human_contact, action_target, sensor, bridge_gateway).
- **Path Utils Module** — cross-platform home directory resolution for Windows/Unix compatibility.
- **`delivered_at` Timestamps** — message recipients now track actual delivery time, removing the outbox timestamp lie.
- **Queue Class in Re-entry** — startup briefing shows actionable/conversation/system/reference breakdown.
- **Primary Peer Filtering** — `ConnectionStory` filters non-primary participants from peer lists.
- **A2A Agent Card Enrichment** — participant kind, profiles, and tags surfaced in A2A Agent Cards.
- **`/signal` Gateway Enrichment** — participant roles and consequence scope injected at ingress.
- **Manual-Wake Jolt Truth** — agents with Jolt host capabilities no longer trigger false operator nudge alerts.
- **Demo Script** — `examples/two_agent_coordination.py` runs a two-agent coordination scenario in 30 seconds.
- **LLM Setup Guide** — `LLM_SETUP.md` for deterministic agent self-configuration.
- **Artifact Reference Architecture** — designed and reviewed topology-aware reference system (Slice 14).
- **Guided Participant Bring-In** — design packet for native/thin/gatewayed participant onboarding (Slice 10A).
- **47 new tests** (2098 total, up from ~2050).

### Changed
- `repo_lanes` migration backfills `updated_at` from `published_at` instead of using DEFAULT that breaks existing rows.
- Brain MCP stdio proxy renamed from Promaia to Zmaia.
- CLI `card` command shows participant kind and profiles.
- `whoami` annotates participant kind on both local and remote paths.

### Infrastructure
- Fortress branch: 24 commits merged to main.
- All 13 working board slices completed and verified.
- Version bumped to 0.2.0 for external user gate.

---

## [Unreleased] — feature/a2a-integration

### Added
- **A2A SSE Streaming** — `message/stream` endpoint returns real-time task state updates as JSON-RPC 2.0 responses wrapped in Server-Sent Events. Adaptive polling with backoff (500ms → 2s), 5-minute ceiling, auto-closes on terminal state.
- **Outbound A2AClient** — `A2AClient` class for sending tasks to external A2A agents. Supports `discover()` (Agent Card fetch), `send()` (synchronous), and `stream()` (SSE generator). Uses stdlib `urllib` — no external HTTP dependency.
- **DRY refactor** — Extracted `_extract_and_route_message()` shared helper to eliminate ~60 lines of duplicated message parsing between `message/send` and `message/stream`.
- **41 A2A tests** — comprehensive test suite covering Phases A, B, and C: Agent Card discovery (6), JSON-RPC gateway (8), SSE streaming (4), outbound client (6), loopback interop (3), core function units (12), discovery URL derivation (2)
- Known Risks and Gaps section in roadmap (23 items, 3 tiers)
- A2A integration work in progress (Antigravity)

### Fixed
- Deployed proof test field name (`from_agent` not `sender`)

---

## 2026-03-22 — Phase 2 Networking Complete

The biggest day yet. Deployed to Railway, baselined all endpoints, closed out Phase 1, and audited the entire roadmap.

### Added
- **Railway deployment** — live at `https://whispers-production-9f63.up.railway.app` with persistent SQLite volume
- **Remote API proof tests** (`proof_remote_api.py`) — 7 check families covering 24+ HTTP endpoints, all passing
- **Deployed proof tests** (`proof_deployed.py`) — 17/17 passing against live Railway server
- **MCP tool annotations** — `ToolAnnotations` (readOnlyHint, destructiveHint, idempotentHint, openWorldHint) on all 15 tools per MCP 2025 spec
- **Version handshake** — `check_version_handshake()` warns on schema mismatch during MCP init
- **Skill file packaging** — WHISPERS-SKILL.md in pyproject.toml via force-include, `whispers.skill_file_path()` helper
- **9 Whispers agent skills** — whispers-developer, whispers-a2a, whispers-console, whispers-listeners, whispers-liveness, whispers-orchestrator, whispers-protocol-pm, whispers-storage, whispers-trust
- **5 Antigravity rules** — team-context, working-with-zack, safety-as-character, orchestration-literacy, whispers-vision
- **Full roadmap audit** — corrected stale statuses across all phases (saved as ROADMAP-AUDIT-2026-03-22.md)
- Remote API coverage gaps filled (remaining server endpoints)

### Changed
- MCP tool descriptions rewritten to be scenario-based (when to use, not just what it does)
- Roadmap statuses corrected: Phase 2B security 85% done, Phase 4B heartbeat 70% done
- Global CLAUDE.md trimmed, dev-level CLAUDE.md created, Whispers CLAUDE.md enriched (26 → 80 lines)
- Promaia CLAUDE.md deduplicated (185 → 30 lines)
- Global GEMINI.md rewritten with personality-based framing
- Permissions consolidated (~500 rules streamlined)

---

## 2026-03-21 — Heartbeat Stack & Research Sprint

### Added
- **Heartbeat Stages 3-5** — cognitive heartbeat, watchdog hooks, MCP integration
- **Readiness and active mode stack** — ready/busy/blocked/warming/paused_by_operator/degraded states
- **Derived active mode** — computed from lease + readiness + heartbeat freshness
- **Lease-backed presence** — sessions as source of online/offline truth
- **Pillar 0 foundation** — persistent listener commands, acknowledgment states (PROCESSED, INSUFFICIENT_CONTEXT)
- **6 deep research docs** — A2A spec compliance, wire formats, storage abstraction, trust/reputation, persistent listener architecture, observability
- **Infrastructure roadmap** — A2A strategic positioning, Phase 2C, tier-gated delivery, working-scope contracts, heartbeat execution plan
- Runtime server profile persistence
- Background presence split from active swarm
- Managed background listener commands

### Changed
- Unified build priority with all 3 agents: liveness → security → storage → tests → observability → social layer
- Refined active swarm presence classification
- Hardened readiness, queues, and server restart

### Fixed
- Listener verification and readonly client init
- Local CLI send auth fallback
- Skip maintenance sweeps in read-only status

---

## 2026-03-20 — Networking & A2A Foundation

### Added
- **Remote connect and session leases** — `/connect`, `/lease`, `/disconnect` endpoints
- **Remote client** — HTTP transport with rate limiting
- **TypeScript SDK** — isomorphic client for remote connections
- **Operator Console** — Phase 6 TS migration
- **A2A endpoint refactoring** — JSON-RPC 2.0 foundation, SSE integration
- **Native OS notifications** — Phase 5
- Deployed server proof tests
- Dead-letter response fixes
- Dispatcher patches for remote routing

### Fixed
- Pytest exception namespace leakage
- URL string parsing for A2A endpoints

---

## 2026-03-19 — Phase 1 Closeout & Streamable HTTP

### Added
- **Streamable HTTP transport** — MCP served via HTTP at `/mcp/` on port 8752, bypassing Windows stdio bug #35287
- **`mcp-install` hardened** — one command configures Claude, Codex, Gemini, Cursor clients
- **`doctor` enhanced** — checks server, MCP handshake, token, per-client config
- **`init` enhanced** — creates DB → starts server → runs mcp-install → verifies MCP
- **Infrastructure roadmap** — from `/protocol-pm audit`, 75 items across 7 phases
- Windows auto-start via brain's startup.py
- Auth token generation on first server start

---

## 2026-03-18 — V2 Core & Hardening

### Added
- **Whispers V2 core** — identity schema, leaky bucket, client protections
- **Game engine** — Guardian pre-dispatch firewall, scoring, tension heuristics
- **Standalone MCP server** — `whispers-mcp` console script
- **Groups and routing** — Phase 3-6 engine features
- **Network planning** — PLAN-3-THE-NETWORK architecture document
- Install manifest and guided uninstall
- Getting started guide for new agents

### Changed
- Part 1.5 hardening — 7 startup issues from live session
- mcp-install targets correct config paths

### Fixed
- Client and MCP server hardened for standalone operation

---

## 2026-03-17 — Project Inception

### Added
- **Phase 1 and 2 complete** — standalone DX and routing engine
- Initial planning documents
- V2 threat model and abuse vectors
- Guardian concept as pre-dispatch IPS firewall
- V2 implementation plan and concept expansion
- Business strategy discussion

---

*80 commits across 6 days by Claude, Antigravity (Gemini), and Codex.*
