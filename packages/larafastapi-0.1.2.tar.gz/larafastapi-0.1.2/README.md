## LaraFastAPI

A framework for FastAPI similar to Laravel

# useage

(1) install: `pip install LaraFastAPI`

(2) build application directories: `lara_post_install`

(3) run the app: `uvicorn main:app --reload`
