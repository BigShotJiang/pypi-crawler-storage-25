# CLI Rename: `specify` → `apm`

## Summary

Rename the user-facing CLI command from `specify` to `apm` and the PyPI package from `specify-cli` to `ai-apm`. The internal Python module (`specify_cli`) stays unchanged.

- **CLI command**: `specify` → `apm`
- **PyPI package**: `specify-cli` → `ai-apm` (i.e., `pip install ai-apm`)
- **"APM" stands for**: AI/Agent Package Manager

## Scope

**In scope — 5 edits across 2 files:**

### `pyproject.toml`

1. **Line 2** — Package name:
   ```
   - name = "specify-cli"
   + name = "ai-apm"
   ```

2. **Line 21** — CLI entry point:
   ```
   - specify = "specify_cli:main"
   + apm = "specify_cli:main"
   ```

### `src/specify_cli/__init__.py`

3. **Lines 350-357** — ASCII banner: Replace `SPECIFY` art with `APM` art.

4. **Line 552** — Typer app name:
   ```python
   - name="specify",
   + name="apm",
   ```

5. **Lines 2587, 2691** — Version lookup (two occurrences):
   ```python
   - importlib.metadata.version("specify-cli")
   + importlib.metadata.version("ai-apm")
   ```

## Explicitly out of scope

- `specify_cli` Python module name and directory (`src/specify_cli/`)
- All `from specify_cli import ...` statements in tests and source
- `.specify/` project directory used by scaffolded projects
- `/speckit.specify` slash commands in AI agent integrations
- Help text, branding strings ("Specify CLI"), docstrings
- Documentation (README.md, docs/, TESTING.md, CONTRIBUTING.md, CHANGELOG.md)
- Shell scripts (`scripts/bash/`, `scripts/powershell/`)
- Release/CI scripts (`.github/workflows/`)
- Template files (`templates/`)
- Extension and preset system references

## Verification

After making changes:
1. `uv sync` — reinstall with new entry point
2. `apm --help` — confirm CLI responds under new name with APM banner
3. `uv run pytest` — confirm all tests still pass (they import `specify_cli`, not the CLI name)

## Risks

- **Low risk**: Tests import `specify_cli` module directly, not via the CLI command. No test changes needed.
- **Documentation drift**: Docs still reference `specify`. User will update docs separately.
- **PyPI conflict**: `ai-apm` confirmed available on PyPI as of 2026-04-02.
