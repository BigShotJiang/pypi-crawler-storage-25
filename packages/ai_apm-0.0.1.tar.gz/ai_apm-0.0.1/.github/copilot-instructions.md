# Copilot Instructions for Spec Kit

## Project Overview

Specify CLI (`specify`) is a Python CLI that bootstraps projects for Spec-Driven Development (SDD). It scaffolds directory structures, templates, scripts, and AI agent command files for 25+ coding assistants (Claude, Copilot, Gemini, Cursor, etc.). It also manages an extension system and a preset system for customizing SDD workflows.

## Build, Test, and Lint

```bash
# Setup
uv sync --extra test
source .venv/bin/activate

# Run all tests
uv run pytest

# Run a single test file
uv run pytest tests/test_core_pack_scaffold.py -q

# Run a single test by name
uv run pytest tests/test_extensions.py -k "test_name_here"

# Key test suites
uv run pytest tests/test_core_pack_scaffold.py -q    # Scaffolding & package parity
uv run pytest tests/test_agent_config_consistency.py -q  # Agent metadata consistency

# Lint
uvx ruff check src/

# Verify CLI works
uv run specify --help
```

## Architecture

### Source Layout

All CLI logic lives in `src/specify_cli/`. The main entry point is `__init__.py` (~4700 lines) which defines the Typer app, all CLI commands, and the `AGENT_CONFIG` dictionary — the single source of truth for agent metadata.

Supporting modules:
- `agents.py` — `CommandRegistrar`: writes command files to agent-specific directories in the correct format (Markdown or TOML)
- `extensions.py` — `ExtensionManager`: install/remove/enable/disable modular command extensions
- `presets.py` — `PresetManager`: install/remove template presets that customize the SDD workflow
- `integrations/` — Plugin architecture for agent integrations. Each agent has a submodule under `integrations/` that subclasses `IntegrationBase` (or `MarkdownIntegration`/`TomlIntegration`) from `integrations/base.py`

### Integration Inheritance

```
IntegrationBase (abstract)
├── MarkdownIntegration (concrete) → Most agents (Claude, Copilot, Qwen, etc.)
└── TomlIntegration (concrete)     → Gemini, Tabnine
```

Adding a new agent integration = subclass the appropriate base, set 3 class attributes (`key`, `config`, `registrar_config`), done.

### Key Data Flow

`specify init --ai <agent>` → validates tools → downloads/scaffolds templates → writes agent command files → installs skills (optional) → initializes git

Templates in `templates/commands/` define the 9 core slash commands (specify, plan, tasks, implement, analyze, constitution, checklist, clarify, taskstoissues). These get rendered into agent-specific directories with correct frontmatter, argument placeholders, and path rewrites.

## Conventions

### AGENT_CONFIG Keys Must Match CLI Tool Names

The `AGENT_CONFIG` dict key **must** be the actual executable name (what `shutil.which()` looks for). Use `"cursor-agent"` not `"cursor"` if the tool binary is `cursor-agent`. This eliminates special-case mappings throughout the codebase. See AGENTS.md for the full guide on adding new agent support.

### Agent Directory Patterns

Most agents use `.<agent>/commands/` but there are notable exceptions:
- Copilot: `.github/agents/` with `.agent.md` extension
- Windsurf/Kilo Code: use `workflows/` subdirectory
- opencode: singular `command/` (not `commands/`)
- Codex/Amp: shared `.agents/` folder
- Gemini/Tabnine: TOML format instead of Markdown

### Argument Placeholders

- Markdown-based agents: `$ARGUMENTS`
- TOML-based agents (Gemini, Tabnine): `{{args}}`
- Script path placeholder: `{SCRIPT}` (replaced with actual path)

### Testing Requirements

- Changes affecting scaffolding: run `test_core_pack_scaffold.py`
- Changes affecting agent metadata, release scripts, or context update scripts: run `test_agent_config_consistency.py`
- Changes affecting slash commands: require manual testing through an AI agent (see TESTING.md)
- The `test_core_pack_scaffold.py` tests validate byte-for-byte parity between the Python scaffolder and `create-release-packages.sh`

### Offline / Air-Gapped Support

Core assets are bundled into the wheel at build time (configured in `pyproject.toml` under `[tool.hatch.build.targets.wheel.force-include]`). The `--offline` flag uses these bundled assets instead of downloading from GitHub. This is becoming the default in v0.6.0.

### Scripts Exist in Both Bash and PowerShell

Any change to `scripts/bash/*.sh` must have a corresponding change in `scripts/powershell/*.ps1`. Both the bash and PowerShell update-agent-context scripts must be updated when adding new agents.

### Extension and Preset System

Extensions live in `extensions/` with a community catalog (`catalog.community.json`). Presets live in `presets/` with their own catalog. Both use YAML manifests, version constraints via `packaging.specifiers`, and priority-based ordering for command resolution. The registry is stored in `.speckit/extensions-registry.json` within target projects.
