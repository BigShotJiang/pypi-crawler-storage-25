import os

from dotenv import load_dotenv

from phad_llm_sdk.utils.HttpUtils import request_rerank

load_dotenv()

RERANK_URL = os.getenv("RERANK_URL")


class RerankClient:
    _instance = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(RerankClient, cls).__new__(cls)
        return cls._instance

    def __init__(self):
        self.url = RERANK_URL

    def rerank(self, query, documents, timeout=60, url=None):
        request_url = url or self.url
        if not request_url:
            raise ValueError("RERANK_URL 未配置")
        if not isinstance(query, str):
            raise TypeError("query 必须是字符串类型")
        if not isinstance(documents, list):
            raise TypeError("documents 必须是列表类型")
        return request_rerank(request_url, query, documents, timeout=timeout)


rerank_client = RerankClient()
