#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Setup script for Phad LLM SDK
"""

from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as f:
    long_description = f.read()

setup(
    name="phad-llm-sdk",
    version="1.2.6",
    author="令狐荣豪",
    author_email="1714873054@qq.com",
    description="Phad LLM SDK for Python",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/yourusername/phad-llm-sdk-python",
    license="MIT",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.7",
    packages=find_packages(where="src"),
    package_dir={"": "src"},
    include_package_data=True,
    install_requires=[
        "requests>=2.32.5",
        "pydantic>=2.12.5",
        "python-dotenv>=1.0.0",
        "httpx>=0.28.1",
        "fastapi>=0.115.6",
        "uvicorn[standard]>=0.34.0",
        "ollama>=0.6.1",
        "minio>=7.2.20",
        "pymilvus>=2.4.4",
        "tqdm>=4.66.0",
        "streamlit>=1.36.0",
        "nacos-sdk-python>=1.0.0"
    ],
    extras_require={
        "dev": [
            "pytest>=7.0.0",
            "black>=23.0.0",
            "flake8>=6.0.0",
        ],
    },
)
