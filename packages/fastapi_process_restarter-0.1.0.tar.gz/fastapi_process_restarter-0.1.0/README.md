# FastAPI Process Restarter

一个基于 FastAPI 的通用进程管理和重启工具，支持跨平台（Linux/macOS/Windows）。

## 功能特性

- 🚀 **一键重启**: 通过 HTTP API 重启任何命令/脚本
- 🖥️ **跨平台支持**: 原生兼容 Linux、macOS 和 Windows
- 📊 **状态监控**: 实时查看进程运行状态和 PID
- 🧩 **易于集成**: 可作为子应用挂载到现有 FastAPI 项目
- 🔧 **CLI 工具**: 提供命令行工具，开箱即用

## 安装

```bash
pip install fastapi-process-restarter
```

## 使用方法

### 方式一：命令行工具 (CLI)

安装后，直接在终端使用 `restarter` 命令：

```bash
# 基本用法
restarter --cmd "python main.py"

# 指定端口
restarter --cmd "python main.py" --port 9000

# 指定监听地址
restarter --cmd "node server.js" --host 127.0.0.1 --port 8080
```

API 端点：
- `POST /restart` - 重启进程
- `GET /status` - 获取进程状态

示例：
```bash
# 重启进程
curl -X POST http://localhost:8080/restart

# 查看状态
curl http://localhost:8080/status
```

### 方式二：Python API 集成

在现有 FastAPI 项目中作为子应用挂载：

```python
from fastapi import FastAPI
from process_restarter import create_app

# 你的主应用
main_app = FastAPI()

@main_app.get("/")
def home():
    return {"message": "Hello World"}

# 挂载进程重启器
cmd_app = create_app(cmd="node server.js")
main_app.mount("/subsystem", cmd_app)

# 现在可以通过 POST /subsystem/restart 重启 node server.js
```

也可以直接使用 `ProcessManager`：

```python
from process_restarter import ProcessManager

manager = ProcessManager(cmd="python worker.py")
manager.start()      # 启动进程
manager.restart()    # 重启进程
manager.stop()       # 停止进程
```

## 技术细节

- **跨平台进程管理**: 
  - Linux/macOS: 使用 `os.setsid` 创建进程组
  - Windows: 使用 `CREATE_NEW_PROCESS_GROUP` 创建进程组
- **生命周期管理**: 使用 FastAPI `@asynccontextmanager` 确保程序退出时子进程被清理
- **日志桥接**: 子进程输出实时转发到主进程 stdout

## 许可证

MIT License
