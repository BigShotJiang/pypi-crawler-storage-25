import os
import subprocess
import sys
import threading
import signal
import platform


class ProcessManager:
    def __init__(self, cmd: str):
        self.cmd = cmd
        self.proc = None

    def log_bridge(self, pipe):
        """实时将子进程日志写到主进程的 stdout"""
        if not pipe:
            return
        for line in iter(pipe.readline, b""):
            sys.stdout.buffer.write(line)
            sys.stdout.buffer.flush()

    def start(self):
        print(f"[@] Starting command: {self.cmd}")
        kwargs = {
            "shell": True,
            "stdout": subprocess.PIPE,
            "stderr": subprocess.STDOUT,
        }

        # 跨平台进程组处理
        if platform.system() != "Windows":
            kwargs["preexec_fn"] = os.setsid
        else:
            kwargs["creationflags"] = subprocess.CREATE_NEW_PROCESS_GROUP

        self.proc = subprocess.Popen(self.cmd, **kwargs)

        # 异步读取日志
        threading.Thread(
            target=self.log_bridge, args=(self.proc.stdout,), daemon=True
        ).start()

    def stop(self):
        if self.proc:
            print("[!] Stopping process...")
            try:
                if platform.system() != "Windows":
                    os.killpg(os.getpgid(self.proc.pid), signal.SIGKILL)
                else:
                    # Windows 下彻底杀死进程树
                    subprocess.run(
                        ["taskkill", "/F", "/T", "/PID", str(self.proc.pid)],
                        stdout=subprocess.DEVNULL,
                        stderr=subprocess.DEVNULL,
                    )
            except Exception as e:
                print(f"[x] Error stopping process: {e}")
            self.proc = None

    def restart(self):
        self.stop()
        self.start()
