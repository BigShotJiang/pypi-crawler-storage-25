from contextlib import asynccontextmanager
from fastapi import FastAPI
from .manager import ProcessManager


def create_app(cmd: str) -> FastAPI:
    manager = ProcessManager(cmd)

    # FastAPI 现代生命周期管理
    @asynccontextmanager
    async def lifespan(app: FastAPI):
        manager.start()  # 启动时运行
        yield
        manager.stop()  # 退出时清理

    app = FastAPI(title="Process Restarter API", lifespan=lifespan)

    @app.post("/restart")
    async def restart():
        manager.restart()
        return {"status": "restarting", "cmd": cmd, "new_pid": manager.proc.pid}

    @app.get("/status")
    async def status():
        is_running = manager.proc is not None and manager.proc.poll() is None
        pid = manager.proc.pid if is_running else None
        return {"running": is_running, "pid": pid}

    return app
