import argparse
import uvicorn
from .api import create_app


def main():
    parser = argparse.ArgumentParser(
        description="Run a command with a FastAPI restart endpoint."
    )
    parser.add_argument(
        "-c", "--cmd", required=True, help="The command to run (e.g., 'python main.py')"
    )
    parser.add_argument(
        "--host", default="0.0.0.0", help="API Host (default: 0.0.0.0)"
    )
    parser.add_argument(
        "-p", "--port", type=int, default=8080, help="API Port (default: 8080)"
    )

    args = parser.parse_args()

    app = create_app(args.cmd)
    uvicorn.run(app, host=args.host, port=args.port)


if __name__ == "__main__":
    main()
