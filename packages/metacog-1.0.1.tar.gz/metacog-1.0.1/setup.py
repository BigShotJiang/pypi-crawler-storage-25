from setuptools import setup, find_packages

setup(
    name="metacog",
    version="1.0.1",
    description="Metacog Python SDK — Governed vertical AI for regulated industries",
    long_description=open("README.md").read() if __import__("os").path.exists("README.md") else "",
    long_description_content_type="text/markdown",
    author="Metacog",
    author_email="api@metacog.ai",
    url="https://github.com/metacog-ai/metacog-python",
    packages=find_packages(),
    python_requires=">=3.9",
    install_requires=[
        "httpx>=0.27.0",
    ],
    extras_require={
        "dev": ["pytest", "pytest-asyncio", "python-dotenv"]
    },
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Programming Language :: Python :: 3.13",
    ],
    keywords="ai compliance india payroll gst tds governance hallucination",
    project_urls={
        "Documentation": "https://docs.metacog.ai",
        "API Reference": "https://docs.metacog.ai/api",
        "Source": "https://github.com/metacog-ai/metacog-python",
        "Bug Tracker": "https://github.com/metacog-ai/metacog-python/issues",
    },
)
