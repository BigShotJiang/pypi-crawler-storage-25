# metacog

Governed vertical AI for regulated industries in India.

Request API access: api@metacog.ai
