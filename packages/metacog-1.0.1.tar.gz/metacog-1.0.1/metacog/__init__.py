"""
Metacog Python SDK
pip install metacog

Usage:
    import metacog

    client = metacog.Metacog(api_key="mk-...")

    # Simple governed completion
    response = client.governed.create(
        model="metacog-m3",
        prompt="What is the TDS rate for salary of 12 lakhs?",
    )
    print(response.answer)
    print(response.confidence)
    print(response.sources)

    # With full governance parameters
    response = client.governed.create(
        model="metacog-m3",
        prompt="What is the PF contribution rate?",
        governance=metacog.GovernanceConfig(
            vertical="payroll",
            confidence_threshold=0.85,
            pii_scan=True,
            cite_sources=True,
        )
    )

    # Check governance metadata
    print(response.governance_passed)   # True
    print(response.hallucination_risk)  # "low"
    print(response.pii_clean)           # True

    # Async usage
    import asyncio
    async def main():
        response = await client.governed.acreate(
            model="metacog-m3",
            prompt="GSTR-3B due date?"
        )
    asyncio.run(main())
"""

import httpx
import os
from dataclasses import dataclass, field
from typing import Optional, List, Any
from datetime import datetime


# ── Models ────────────────────────────────────────────────────────────────────

# Metacog model family — M-numbers match governance plane
METACOG_M1 = "metacog-m1"        # Fast, efficient — for high-volume, lower complexity queries
METACOG_M3 = "metacog-m3"        # Balanced — daily compliance work, recommended default
METACOG_M7 = "metacog-m7"        # Most capable, most governed — complex reasoning, filing decisions

# Aliases by vertical
METACOG_FINANCE = "metacog-f1"   # Finance & payroll specialist
METACOG_BANKING = "metacog-b1"   # Banking & RBI specialist
METACOG_HEALTH  = "metacog-h1"   # Healthcare specialist


@dataclass
class GovernanceConfig:
    """
    Governance parameters for a Metacog API call.
    These control the M1-M7 metacognition plane behaviour.
    """
    vertical: str = "payroll"
    confidence_threshold: float = 0.70
    pii_scan: bool = True
    cite_sources: bool = True
    drift_check: bool = False
    escalate_below_threshold: bool = True
    custom_rules: Optional[List[str]] = None


@dataclass
class GovernedResponse:
    """
    Response from a Metacog governed completion.
    Every field is populated — governance is not optional.
    """
    id: str
    model: str
    answer: Optional[str]
    confidence: float
    governance_passed: bool
    escalation_required: bool
    sources: List[str]
    pii_clean: bool
    hallucination_risk: str       # "low", "medium", "high"
    drift_status: str             # "none", "warn", "alert"
    disclaimer: str
    usage: dict
    metadata: dict
    created: int = 0

    @property
    def text(self) -> str:
        """Alias for answer — familiar to developers used to .text or .content"""
        return self.answer or ""

    @property
    def content(self) -> str:
        """Alias for answer — familiar to developers used to Claude SDK"""
        return self.answer or ""

    @property
    def is_safe(self) -> bool:
        """Returns True if response passed all governance checks"""
        return self.governance_passed and self.pii_clean and not self.escalation_required

    @property
    def confidence_percent(self) -> str:
        """Confidence as percentage string"""
        return f"{int(self.confidence * 100)}%"

    def __repr__(self):
        return (
            f"GovernedResponse("
            f"confidence={self.confidence_percent}, "
            f"governed={self.governance_passed}, "
            f"hallucination_risk={self.hallucination_risk})"
        )


class GovernedCompletions:
    """
    The governed completions namespace.
    Mirrors anthropic.messages — drop-in for regulated use cases.
    """

    def __init__(self, client: "Metacog"):
        self._client = client

    def create(
        self,
        prompt: str,
        model: str = METACOG_M3,
        governance: Optional[GovernanceConfig] = None,
        max_tokens: int = 1024,
        temperature: float = 0.1,
        **kwargs
    ) -> GovernedResponse:
        """
        Create a governed completion.

        Args:
            prompt: The compliance question or task
            model: Metacog model to use (default: metacog-m3)
            governance: GovernanceConfig with M1-M7 parameters
            max_tokens: Maximum output tokens
            temperature: Sampling temperature (lower = more deterministic)

        Returns:
            GovernedResponse with answer + full governance metadata

        Raises:
            MetacogAuthError: Invalid API key
            MetacogRateLimitError: Rate limit exceeded
            MetacogGovernanceError: Response blocked by governance layer
        """
        gov = governance or GovernanceConfig()

        payload = {
            "model": model,
            "prompt": prompt,
            "max_tokens": max_tokens,
            "temperature": temperature,
            "governance": {
                "vertical": gov.vertical,
                "confidence_threshold": gov.confidence_threshold,
                "pii_scan": gov.pii_scan,
                "cite_sources": gov.cite_sources,
                "drift_check": gov.drift_check,
                "custom_rules": gov.custom_rules,
            }
        }

        response = self._client._post("/v1/governed/complete", payload)
        return self._parse_response(response)

    async def acreate(
        self,
        prompt: str,
        model: str = METACOG_M3,
        governance: Optional[GovernanceConfig] = None,
        max_tokens: int = 1024,
        temperature: float = 0.1,
    ) -> GovernedResponse:
        """Async version of create."""
        gov = governance or GovernanceConfig()

        payload = {
            "model": model,
            "prompt": prompt,
            "max_tokens": max_tokens,
            "temperature": temperature,
            "governance": {
                "vertical": gov.vertical,
                "confidence_threshold": gov.confidence_threshold,
                "pii_scan": gov.pii_scan,
                "cite_sources": gov.cite_sources,
                "drift_check": gov.drift_check,
            }
        }

        response = await self._client._apost("/v1/governed/complete", payload)
        return self._parse_response(response)

    def _parse_response(self, data: dict) -> GovernedResponse:
        """Parse API response into GovernedResponse."""
        if "error" in data:
            raise MetacogAPIError(data["error"])

        return GovernedResponse(
            id=data.get("id", ""),
            model=data.get("model", ""),
            answer=data.get("answer"),
            confidence=data.get("confidence", 0.0),
            governance_passed=data.get("governance_passed", False),
            escalation_required=data.get("escalation_required", True),
            sources=data.get("sources", []),
            pii_clean=data.get("pii_clean", True),
            hallucination_risk=data.get("hallucination_risk", "unknown"),
            drift_status=data.get("drift_status", "none"),
            disclaimer=data.get("disclaimer", ""),
            usage=data.get("usage", {}),
            metadata=data.get("metacog_metadata", {}),
            created=data.get("created", 0)
        )


class Models:
    """List and inspect available Metacog models."""

    def __init__(self, client: "Metacog"):
        self._client = client

    def list(self) -> dict:
        """List all available models for your tier."""
        return self._client._get("/v1/models")

    def retrieve(self, model_id: str) -> dict:
        """Get details for a specific model."""
        models = self.list()
        for m in models.get("data", []):
            if m["id"] == model_id:
                return m
        raise MetacogAPIError(f"Model {model_id} not found")


class Usage:
    """Check API usage and billing."""

    def __init__(self, client: "Metacog"):
        self._client = client

    def retrieve(self) -> dict:
        """Get current month's usage and cost."""
        key_prefix = self._client.api_key[:8]
        return self._client._get(f"/v1/usage/{key_prefix}")


class Governance:
    """Access Metacog governance scores and metadata."""

    def __init__(self, client: "Metacog"):
        self._client = client

    def score(self) -> dict:
        """Get current Metacog governance score."""
        return self._client._get("/v1/governance/score")

    def license_tiers(self) -> dict:
        """Get available license tiers and pricing."""
        return self._client._get("/v1/license/tiers")


class Metacog:
    """
    Metacog Python SDK client.

    Usage:
        import metacog
        client = metacog.Metacog(api_key="mk-...")
        response = client.governed.create(
            model=metacog.METACOG_M3,
            prompt="What is the TDS rate for 12 lakh salary?"
        )
        print(response.answer)
        print(response.confidence)
    """

    DEFAULT_BASE_URL = "https://api.metacog.ai"

    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        timeout: float = 30.0,
    ):
        self.api_key = api_key or os.environ.get("METACOG_API_KEY", "")
        self.base_url = (base_url or os.environ.get("METACOG_BASE_URL", self.DEFAULT_BASE_URL)).rstrip("/")
        self.timeout = timeout

        if not self.api_key:
            raise MetacogAuthError(
                "No API key provided. Pass api_key= or set METACOG_API_KEY environment variable."
            )

        # Namespaces — mirrors Anthropic SDK structure
        self.governed = GovernedCompletions(self)
        self.models = Models(self)
        self.usage = Usage(self)
        self.governance = Governance(self)

    def _headers(self) -> dict:
        return {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
            "User-Agent": "metacog-python/1.0.0",
        }

    def _post(self, path: str, payload: dict) -> dict:
        with httpx.Client(timeout=self.timeout) as client:
            response = client.post(
                f"{self.base_url}{path}",
                json=payload,
                headers=self._headers()
            )
            return self._handle_response(response)

    async def _apost(self, path: str, payload: dict) -> dict:
        async with httpx.AsyncClient(timeout=self.timeout) as client:
            response = await client.post(
                f"{self.base_url}{path}",
                json=payload,
                headers=self._headers()
            )
            return self._handle_response(response)

    def _get(self, path: str) -> dict:
        with httpx.Client(timeout=self.timeout) as client:
            response = client.get(
                f"{self.base_url}{path}",
                headers=self._headers()
            )
            return self._handle_response(response)

    def _handle_response(self, response: httpx.Response) -> dict:
        if response.status_code == 401:
            raise MetacogAuthError("Invalid API key")
        if response.status_code == 429:
            raise MetacogRateLimitError("Rate limit exceeded. Upgrade your plan.")
        if response.status_code == 403:
            raise MetacogPermissionError("Model or feature not available on your plan.")
        if response.status_code >= 500:
            raise MetacogAPIError(f"Metacog API error: {response.status_code}")
        return response.json()


# ── Exceptions ────────────────────────────────────────────────────────────────

class MetacogError(Exception):
    """Base Metacog exception."""
    pass

class MetacogAuthError(MetacogError):
    """Invalid or missing API key."""
    pass

class MetacogRateLimitError(MetacogError):
    """Rate limit exceeded."""
    pass

class MetacogPermissionError(MetacogError):
    """Feature not available on current plan."""
    pass

class MetacogGovernanceError(MetacogError):
    """Response blocked by governance layer."""
    pass

class MetacogAPIError(MetacogError):
    """General API error."""
    pass


# ── Module-level convenience ───────────────────────────────────────────────────

def create(api_key: Optional[str] = None, **kwargs) -> Metacog:
    """Create a Metacog client. Convenience function."""
    return Metacog(api_key=api_key, **kwargs)
