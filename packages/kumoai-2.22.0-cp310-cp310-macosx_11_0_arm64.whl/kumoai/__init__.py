from functools import lru_cache
import warnings
import os
import sys
import threading
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Union
import logging

from kumoapi.typing import Dtype, Stype

from kumoai.client.client import KumoClient
from kumoai._logging import initialize_logging, _ENV_KUMO_LOG
from kumoai._singleton import Singleton
from kumoai.futures import create_future, initialize_event_loop
from kumoai.spcs import (
    _get_active_session,
    _get_spcs_token,
    _run_refresh_spcs_token,
)

initialize_logging()
initialize_event_loop()

_ENV_RBAC_ENABLED = 'RBAC_ENABLED'


@dataclass
class GlobalState(metaclass=Singleton):
    r"""Global storage of the state needed to create a Kumo client object. A
    singleton so its initialized state can be referenced elsewhere for free.
    """

    # NOTE fork semantics: CoW on Linux, and re-execed on Windows. So this will
    # likely not work on Windows unless we have special handling for the shared
    # state:
    _url: Optional[str] = None
    _api_key: Optional[str] = None
    _snowflake_credentials: Optional[Dict[str, Any]] = None
    _spcs_token: Optional[str] = None
    _snowpark_session: Optional[Any] = None

    # RBAC state:
    _rbac_enabled: bool = False
    _group_id: Optional[str] = None
    _group_name: Optional[str] = None
    _project_id: Optional[str] = None
    _project_name: Optional[str] = None

    thread_local: threading.local = field(default_factory=threading.local)

    def clear(self) -> None:
        if hasattr(self.thread_local, '_client'):
            del self.thread_local._client
        self._url = None
        self._api_key = None
        self._snowflake_credentials = None
        self._spcs_token = None
        self._rbac_enabled = False
        self._group_id = None
        self._group_name = None
        self._project_id = None
        self._project_name = None

    def set_spcs_token(self, spcs_token: str) -> None:
        # Set the spcs token in the global state. This will be picked up the
        # next time client() is accessed.
        self._spcs_token = spcs_token

    @property
    def initialized(self) -> bool:
        return self._url is not None and (
            self._api_key is not None or self._snowflake_credentials
            is not None or self._snowpark_session is not None)

    @property
    def client(self) -> KumoClient:
        r"""Accessor for the Kumo client. Note that clients are stored as
        thread-local variables as the requests Session library is not
        guaranteed to be thread-safe.

        For more information, see https://github.com/psf/requests/issues/1871.
        """
        if self._url is None or (self._api_key is None
                                 and self._spcs_token is None
                                 and self._snowpark_session is None):
            raise ValueError("Client creation or authentication failed. "
                             "Please re-create your client before proceeding.")

        if hasattr(self.thread_local, '_client'):
            # Set the spcs token in the client to ensure it has the latest.
            if self._spcs_token is not None:
                self.thread_local._client.set_spcs_token(self._spcs_token)
            return self.thread_local._client

        client = KumoClient(self._url, self._api_key, self._spcs_token)
        self.thread_local._client = client
        return client

    @property
    def is_spcs(self) -> bool:
        return (self._api_key is None
                and (self._snowflake_credentials is not None
                     or self._snowpark_session is not None))


global_state: GlobalState = GlobalState()


def init(
    url: Optional[str] = None,
    api_key: Optional[str] = None,
    snowflake_credentials: Optional[Dict[str, str]] = None,
    snowflake_application: Optional[str] = None,
    log_level: str = "INFO",
    group: Optional[str] = None,
    project: Optional[str] = None,
) -> None:
    r"""Initializes and authenticates the API key against the Kumo service.
    Successful authentication is required to use the SDK.

    Example:
        >>> import kumoai
        >>> kumoai.init(url="<api_url>", api_key="<api_key>")  # doctest: +SKIP

    Args:
        url: The Kumo API endpoint. Can also be provided via the
            ``KUMO_API_ENDPOINT`` envronment variable. Will be inferred from
            the provided API key, if not provided.
        api_key: The Kumo API key. Can also be provided via the
            ``KUMO_API_KEY`` environment variable.
        snowflake_credentials: The Snowflake credentials to authenticate
            against the Kumo service. For SPCS only. Either password-based:
            ``{"user", "password", "account"}``, or key-pair:
            ``{"user", "private_key", "account"}`` with optional
            ``"private_key_passphrase"`` for encrypted keys. The private key
            should be PEM format (same as used for connector auth in the UI).
        snowflake_application: The Snowflake application.
        log_level: The logging level that Kumo operates under. Defaults to
            INFO; for more information, please see
            :class:`~kumoai.set_log_level`. Can also be set with the
            environment variable ``KUMOAI_LOG``.
        group: The group to operate in. Only applicable when RBAC is enabled.
            Can be a group name or ID. If the user belongs to only one group,
            it will be auto-selected even if not provided.
        project: The project to operate in. Only applicable when RBAC is
            enabled. Can be a project name or ID. Requires ``group`` to be
            resolvable.
    """  # noqa
    # Avoid mutations to the global state after it is set:
    if global_state.initialized:
        warnings.warn("Kumo SDK already initialized. To re-initialize the "
                      "SDK, please start a new interpreter. No changes will "
                      "be made to the current session.")
        return

    set_log_level(os.getenv(_ENV_KUMO_LOG, log_level))

    # Get API key:
    api_key = api_key or os.getenv("KUMO_API_KEY")

    snowpark_session = None
    if snowflake_application:
        if url is not None:
            raise ValueError(
                "Kumo SDK initialization failed. Both 'snowflake_application' "
                "and 'url' are specified. If running from a Snowflake "
                "notebook, specify only 'snowflake_application'.")
        snowpark_session = _get_active_session()
        if not snowpark_session:
            raise ValueError(
                "Kumo SDK initialization failed. 'snowflake_application' is "
                "specified without an active Snowpark session. If running "
                "outside a Snowflake notebook, specify a URL and credentials.")
        description = snowpark_session.sql(
            f"DESCRIBE SERVICE {snowflake_application}."
            "USER_SCHEMA.KUMO_SERVICE").collect()[0]
        url = f"http://{description.dns_name}:8888/public_api"

    if api_key is None and not snowflake_application:
        if snowflake_credentials is None:
            raise ValueError(
                "Kumo SDK initialization failed. Neither an API key nor "
                "Snowflake credentials provided. Please either set the "
                "'KUMO_API_KEY' or explicitly call `kumoai.init(...)`.")
        required_password = {'user', 'password', 'account'}
        required_keypair = {'user', 'private_key', 'account'}
        keys = set(snowflake_credentials.keys())
        keypair_ok = required_keypair.issubset(keys) and 'password' not in keys
        password_ok = required_password.issubset(keys)
        if not (password_ok or keypair_ok):
            raise ValueError(
                f"Snowflake credentials must be either password-based "
                f"{{'user', 'password', 'account'}} or key-pair "
                f"{{'user', 'private_key', 'account'}} with optional "
                f"'private_key_passphrase'. Got keys: {keys}")

    # Get or infer URL:
    url = url or os.getenv("KUMO_API_ENDPOINT")
    try:
        if api_key:
            url = url or f"http://{api_key.split(':')[0]}.kumoai.cloud/api"
    except KeyError:
        pass
    if url is None:
        raise ValueError("Kumo SDK initialization failed since no endpoint "
                         "URL was provided. Please either set the "
                         "'KUMO_API_ENDPOINT' environment variable or "
                         "explicitly call `kumoai.init(...)`.")

    # Assign global state after verification that client can be created and
    # authenticated successfully:
    spcs_token = _get_spcs_token(
        snowflake_credentials
    ) if not api_key and snowflake_credentials else None
    client = KumoClient(url=url, api_key=api_key, spcs_token=spcs_token)
    client.authenticate()
    global_state._url = client._url
    global_state._api_key = client._api_key
    global_state._snowflake_credentials = snowflake_credentials
    global_state._spcs_token = client._spcs_token
    global_state._snowpark_session = snowpark_session

    if not api_key and snowflake_credentials:
        # Refresh token every 10 minutes (expires in 1 hour):
        create_future(_run_refresh_spcs_token(minutes=10))

    # Determine whether RBAC is enabled. The env var takes precedence over the
    # server-side capability check. RBAC_ENABLED=false lets users opt out of
    # RBAC even when the server has it enabled (escape hatch for automation
    # scripts migrating to the new flow).
    env_rbac = os.getenv(_ENV_RBAC_ENABLED)
    if env_rbac is not None:
        global_state._rbac_enabled = env_rbac.lower() == 'true'
    else:
        features = client.fetch_config()
        global_state._rbac_enabled = features.get('rbac', False)

    if global_state._rbac_enabled:
        _init_rbac(client, group, project)

    logger = logging.getLogger('kumoai')
    log_level = logging.getLevelName(logger.getEffectiveLevel())

    logger.info(f"Initialized Kumo SDK v{__version__} against deployment "
                f"'{url}'")


def _init_rbac(
    client: KumoClient,
    group: Optional[str],
    project: Optional[str],
) -> None:
    r"""Resolves and sets group/project context
    during init when RBAC is enabled.
    """
    logger = logging.getLogger('kumoai')

    groups = client.groups_api.list_groups()

    if group is not None:
        match = next((g for g in groups if g.id == group or g.name == group),
                     None)
        if match is None:
            raise ValueError(f"Group {group!r} not found. Available groups: "
                             f"{[g.name for g in groups]}")
        global_state._group_id = match.id
        global_state._group_name = match.name
    elif len(groups) == 1:
        global_state._group_id = groups[0].id
        global_state._group_name = groups[0].name
        logger.info(f"Auto-selected group: '{groups[0].name}'")
    elif len(groups) > 1:
        logger.warning(
            f"Multiple groups available: {[g.name for g in groups]}. "
            f"Call kumoai.set_group() or pass group= to kumoai.init().")

    if project is not None:
        if global_state._group_id is None:
            raise ValueError(
                "Cannot resolve project= without a group. Pass group= to "
                "kumoai.init() alongside project=.")
        projects = client.projects_api.list_projects(global_state._group_id)
        match = next(
            (p for p in projects if p.id == project or p.name == project),
            None)
        if match is None:
            raise ValueError(
                f"Project {project!r} not found in group "
                f"'{global_state._group_name}'. Available projects: "
                f"{[p.name for p in projects]}")
        global_state._project_id = match.id
        global_state._project_name = match.name


def _require_rbac() -> None:
    from kumoai.exceptions import FeatureNotEnabledError
    if not global_state._rbac_enabled:
        raise FeatureNotEnabledError()


def _require_group() -> None:
    _require_rbac()
    from kumoai.exceptions import GroupNotSetError
    if global_state._group_id is None:
        raise GroupNotSetError()


def _require_project() -> None:
    _require_group()
    from kumoai.exceptions import ProjectNotSetError
    if global_state._project_id is None:
        raise ProjectNotSetError()


def list_groups() -> 'List[Group]':
    r"""Lists all groups the authenticated user belongs to.

    Requires RBAC to be enabled for this workspace.

    Returns:
        A list of :class:`~kumoai.rbac.Group` objects.

    Raises:
        :class:`~kumoai.exceptions.FeatureNotEnabledError`: if RBAC is not
            enabled for this workspace.
    """
    _require_rbac()
    return global_state.client.groups_api.list_groups()


def set_group(group: 'Union[str, Group]') -> None:
    r"""Sets the active group context. All subsequent operations will be
    scoped to this group.

    Args:
        group: A :class:`~kumoai.rbac.Group` object, or a group name or ID.

    Raises:
        :class:`~kumoai.exceptions.FeatureNotEnabledError`: if RBAC is not
            enabled for this workspace.
        :class:`ValueError`: if the group cannot be found.
    """
    _require_rbac()
    # Switching groups invalidates the current project context, since
    # projects belong to a specific group:
    global_state._project_id = None
    global_state._project_name = None
    from kumoai.rbac import Group
    if isinstance(group, Group):
        global_state._group_id = group.id
        global_state._group_name = group.name
    else:
        groups = global_state.client.groups_api.list_groups()
        match = next((g for g in groups if g.id == group or g.name == group),
                     None)
        if match is None:
            raise ValueError(f"Group {group!r} not found. Available groups: "
                             f"{[g.name for g in groups]}")
        global_state._group_id = match.id
        global_state._group_name = match.name


def current_group() -> 'Group':
    r"""Returns the currently active group.

    Raises:
        :class:`~kumoai.exceptions.GroupNotSetError`: if no group is set.
    """
    _require_group()
    from kumoai.rbac import Group
    assert global_state._group_id is not None
    assert global_state._group_name is not None
    return Group(id=global_state._group_id, name=global_state._group_name)


def list_projects() -> 'List[Project]':
    r"""Lists all projects within the currently active group.

    Requires a group to be set via :func:`set_group` or the ``group=``
    parameter in :func:`init`.

    Returns:
        A list of :class:`~kumoai.rbac.Project` objects.

    Raises:
        :class:`~kumoai.exceptions.GroupNotSetError`: if no group is set.
    """
    _require_group()
    assert global_state._group_id is not None
    return global_state.client.projects_api.list_projects(
        global_state._group_id)


def set_project(project: 'Union[str, Project]') -> None:
    r"""Sets the active project context. All subsequent object operations will
    be scoped to this project.

    Args:
        project: A :class:`~kumoai.rbac.Project` object, or a project name
            or ID.

    Raises:
        :class:`~kumoai.exceptions.GroupNotSetError`: if no group is set.
        :class:`ValueError`: if the project cannot be found.
    """
    _require_group()
    from kumoai.rbac import Project
    if isinstance(project, Project):
        global_state._project_id = project.id
        global_state._project_name = project.name
    else:
        assert global_state._group_id is not None
        projects = global_state.client.projects_api.list_projects(
            global_state._group_id)
        match = next(
            (p for p in projects if p.id == project or p.name == project),
            None)
        if match is None:
            raise ValueError(
                f"Project {project!r} not found in group "
                f"'{global_state._group_name}'. Available projects: "
                f"{[p.name for p in projects]}")
        global_state._project_id = match.id
        global_state._project_name = match.name


def current_project() -> 'Project':
    r"""Returns the currently active project.

    Raises:
        :class:`~kumoai.exceptions.ProjectNotSetError`: if no project is set.
    """
    _require_project()
    from kumoai.rbac import Project
    assert global_state._project_id is not None
    assert global_state._project_name is not None
    assert global_state._group_id is not None
    return Project(
        id=global_state._project_id,
        name=global_state._project_name,
        group_id=global_state._group_id,
    )


def create_project(name: str, is_private: bool = False) -> 'Project':
    r"""Creates a new project within the currently active group.

    Args:
        name: The name for the new project.
        is_private: If ``True``, the project is visible only to its creator.
            If ``False`` (default), it is shared with all members of the group.

    Returns:
        The newly created :class:`~kumoai.rbac.Project`.

    Raises:
        :class:`~kumoai.exceptions.GroupNotSetError`: if no group is set.
    """
    _require_group()
    assert global_state._group_id is not None
    return global_state.client.projects_api.create_project(
        name=name,
        group_id=global_state._group_id,
        is_private=is_private,
    )


def list_group_connectors() -> 'List[GroupConnector]':
    r"""Lists all group connectors available within the currently active group.

    Group connectors are created and managed by administrators. They are
    shared across all projects within the group and are the only supported
    connector type in RBAC-enabled workspaces.

    Returns:
        A list of :class:`~kumoai.connector.GroupConnector` objects.

    Raises:
        :class:`~kumoai.exceptions.GroupNotSetError`: if no group is set.
    """
    _require_group()
    assert global_state._group_id is not None
    return global_state.client.groups_api.list_group_connectors(
        global_state._group_id)


def set_log_level(level: str) -> None:
    r"""Sets the Kumo logging level, which defines the amount of output that
    methods produce.

    Example:
        >>> import kumoai
        >>> kumoai.set_log_level("INFO")  # doctest: +SKIP

    Args:
        level: the logging level. Can be one of (in order of lowest to highest
            log output) :obj:`DEBUG`, :obj:`INFO`, :obj:`WARNING`,
            :obj:`ERROR`, :obj:`FATAL`, :obj:`CRITICAL`.
    """
    # logging library will ensure `level` is a valid string, and raise a
    # warning if not:
    logging.getLogger('kumoai').setLevel(level)


# Try to initialize purely with environment variables:
if ("pytest" not in sys.modules and "KUMO_API_KEY" in os.environ
        and "KUMO_API_ENDPOINT" in os.environ):
    init()

import kumoai.connector  # noqa
import kumoai.encoder  # noqa
import kumoai.graph  # noqa
import kumoai.pquery  # noqa
import kumoai.trainer  # noqa
import kumoai.utils  # noqa
import kumoai.databricks  # noqa

from kumoai.connector import (  # noqa
    SourceTable, SourceTableFuture, S3Connector, GCSConnector,
    SnowflakeConnector, DatabricksConnector, BigQueryConnector,
    FileUploadConnector, GlueConnector, GroupConnector)
from kumoai.rbac import Group, Project  # noqa
from kumoai.exceptions import (  # noqa
    FeatureNotEnabledError, GroupNotSetError, ProjectNotSetError)
from kumoai.graph import Column, Edge, Graph, Table  # noqa
from kumoai.pquery import (  # noqa
    PredictionTableGenerationPlan, PredictiveQuery,
    TrainingTableGenerationPlan, TrainingTable, TrainingTableJob,
    PredictionTable, PredictionTableJob)
from kumoai.trainer import (  # noqa
    ModelPlan, Trainer, TrainingJobResult, TrainingJob,
    BatchPredictionJobResult, BatchPredictionJob, ModelOutputConfig,
    export_model)
from kumoai.session import ComputeType, Session  # noqa
from kumoai._version import __version__  # noqa

__all__ = [
    'Dtype',
    'Stype',
    'SourceTable',
    'SourceTableFuture',
    'S3Connector',
    'GCSConnector',
    'SnowflakeConnector',
    'DatabricksConnector',
    'BigQueryConnector',
    'FileUploadConnector',
    'GlueConnector',
    'GroupConnector',
    'Column',
    'Table',
    'Graph',
    'Edge',
    'PredictiveQuery',
    'TrainingTable',
    'TrainingTableJob',
    'TrainingTableGenerationPlan',
    'PredictionTable',
    'PredictionTableJob',
    'PredictionTableGenerationPlan',
    'Trainer',
    'TrainingJobResult',
    'TrainingJob',
    'BatchPredictionJobResult',
    'BatchPredictionJob',
    'ModelPlan',
    'ModelOutputConfig',
    'export_model',
    'ComputeType',
    'Session',
    # RBAC
    'Group',
    'Project',
    'FeatureNotEnabledError',
    'GroupNotSetError',
    'ProjectNotSetError',
    'list_groups',
    'set_group',
    'current_group',
    'list_projects',
    'set_project',
    'create_project',
    'current_project',
    'list_group_connectors',
    '__version__',
]


@lru_cache
def in_streamlit_notebook() -> bool:
    try:
        from snowflake.snowpark.context import get_active_session
        import streamlit  # noqa: F401
        get_active_session()
        return True
    except Exception:
        return False


@lru_cache
def in_jupyter_notebook() -> bool:
    try:
        from IPython import get_ipython
        shell = get_ipython()
        if 'google.colab' in str(shell.__class__):
            return True
        if 'DatabricksShell' in str(shell.__class__):
            return True
        return shell.__class__.__name__ == 'ZMQInteractiveShell'
    except Exception:
        return False


@lru_cache
def in_vnext_notebook() -> bool:
    try:
        from snowflake.snowpark.context import get_active_session
        get_active_session()
        return in_jupyter_notebook()
    except Exception:
        return False


@lru_cache
def in_notebook() -> bool:
    return in_streamlit_notebook() or in_jupyter_notebook()


@lru_cache
def in_tmux() -> bool:
    return 'TMUX' in os.environ


ascii_logo = """
@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@  @@@@@@@@@@@
@@@@@@@@  @@@@@@@@@@@
@@@@@@@@  @%  %  @@@@
@@@@@@@@  %  %@  @@@@
@@@@@@@@    .@@  @@@@
@@@@@@@@  @. .@: .@@.
@@@@@@@@  @@. .@+
@@@@@@@@@@@@@@@@@@@@@
"""[1:-1]
