"""Triton V2 inference proxy."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Dict, List, Optional

from .._models import (
    InferInput,
    InferOutput,
    InferRequest,
    InferResponse,
    _model_dump,
)

if TYPE_CHECKING:
    from .._client import OnlineHTTPClient


class PredictAPI:
    def __init__(self, client: 'OnlineHTTPClient') -> None:
        self._client = client

    def infer(
        self,
        infer_url: str,
        inputs: List[Dict[str, Any]],
        outputs: Optional[List[Dict[str, Any]]] = None,
    ) -> InferResponse:
        """POST a Triton V2 inference request to an arbitrary inference URL.

        Args:
            infer_url: Full URL returned in the ``urls`` field of a service
                response, e.g. ``service.urls.weighted``.
            inputs: List of Triton input dicts with keys ``name``, ``shape``,
                ``datatype``, ``data``.
            outputs: Optional list of output dicts with at least ``name``.
        """
        req = InferRequest(
            inputs=[InferInput(**i) for i in inputs],
            outputs=[InferOutput(**o) for o in outputs] if outputs else None,
        )
        # infer_url is an external URL, so we call it directly with auth.
        import requests as _requests
        headers = {'Authorization': f'Bearer {self._client._auth.token}'}
        resp = _requests.post(
            infer_url,
            headers=headers,
            json=_model_dump(req, exclude_none=True),
            timeout=60,
        )
        resp.raise_for_status()
        return InferResponse(**resp.json())
