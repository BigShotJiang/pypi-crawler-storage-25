"""Health and readiness status."""

from __future__ import annotations

from typing import TYPE_CHECKING, Dict

from .._models import ServiceStatus

if TYPE_CHECKING:
    from .._client import OnlineHTTPClient


class StatusAPI:
    def __init__(self, client: 'OnlineHTTPClient') -> None:
        self._client = client

    def health(self) -> bool:
        """Return True if the control plane reports healthy."""
        # Use the authenticated client: deployments fronted by an auth-
        # enforcing proxy (e.g. Istio with deny-no-jwt) reject anonymous
        # requests at the mesh layer, so /health needs the same Bearer
        # token as every other endpoint.
        try:
            data = self._client.get('/health')
        except Exception:
            return False
        return isinstance(data, dict) and data.get('status') == 'ok'

    def get_status(self) -> Dict[str, ServiceStatus]:
        data = self._client.get('/status')
        if not isinstance(data, dict):
            return {}
        services = data.get('inference_services')
        if not isinstance(services, list):
            return {}
        result: Dict[str, ServiceStatus] = {}
        for entry in services:
            if not isinstance(entry, dict):
                continue
            name = entry.get('inference_service_name') or entry.get('name')
            if not name:
                continue
            result[name] = ServiceStatus(
                ready=bool(entry.get('is_ready', entry.get('ready', False))),
                message=entry.get('message'),
            )
        return result
