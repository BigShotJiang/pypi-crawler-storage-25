"""Instance types discovery API."""

from __future__ import annotations

from typing import TYPE_CHECKING, List

if TYPE_CHECKING:
    from .._client import OnlineHTTPClient


class InstanceTypesAPI:
    def __init__(self, client: 'OnlineHTTPClient') -> None:
        self._client = client

    def list(self) -> List[str]:
        data = self._client.get('/instance-types')
        return data.get('instance_types', [])
