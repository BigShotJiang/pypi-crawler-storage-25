"""Traffic and canary state read operations."""

from __future__ import annotations

from typing import TYPE_CHECKING, Dict

from .._models import TrafficStatus

if TYPE_CHECKING:
    from .._client import OnlineHTTPClient


class TrafficAPI:
    def __init__(self, client: 'OnlineHTTPClient') -> None:
        self._client = client

    def get_traffic(self) -> Dict[str, TrafficStatus]:
        # The control-app returns ``{"inference_services": [...]}`` with each
        # entry keyed by ``inference_service_name``.  Parse that shape into
        # the documented ``Dict[name, TrafficStatus]`` return type.
        data = self._client.get('/traffic')
        if not isinstance(data, dict):
            return {}
        services = data.get('inference_services')
        if not isinstance(services, list):
            return {}
        result: Dict[str, TrafficStatus] = {}
        for entry in services:
            if not isinstance(entry, dict):
                continue
            name = entry.get('inference_service_name') or entry.get('name')
            if not name:
                continue
            result[name] = TrafficStatus(
                stable_model_id=entry.get('stable_model_id'),
                canary_model_id=entry.get('canary_model_id'),
                canary_traffic_percent=entry.get('canary_traffic_percent', 0)
                or 0,
            )
        return result
