"""Model CRUD operations."""

from __future__ import annotations

from typing import TYPE_CHECKING, List

from .._models import (
    ModelListResponse,
    RegisteredModel,
    RegisterModelRequest,
    _model_dump,
)

if TYPE_CHECKING:
    from .._client import OnlineHTTPClient


class ModelsAPI:
    def __init__(self, client: 'OnlineHTTPClient') -> None:
        self._client = client

    def register(
        self,
        model_id: str,
        s3_model_uri: str,
    ) -> RegisteredModel:
        req = RegisterModelRequest(
            model_id=model_id,
            s3_model_uri=s3_model_uri,
        )
        data = self._client.post('/models',
                                 json=_model_dump(req, exclude_none=True))
        return RegisteredModel(**data)

    def list(self) -> List[RegisteredModel]:
        data = self._client.get('/models')
        resp = ModelListResponse(**data)
        return resp.models

    def get(self, model_id: str) -> RegisteredModel:
        data = self._client.get(f'/models/{model_id}')
        return RegisteredModel(**data)

    def delete(self, model_id: str) -> None:
        self._client.delete(f'/models/{model_id}')
