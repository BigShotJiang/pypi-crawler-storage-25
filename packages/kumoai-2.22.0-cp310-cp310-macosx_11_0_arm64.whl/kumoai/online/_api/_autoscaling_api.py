"""HPA autoscaling management."""

from __future__ import annotations

from typing import TYPE_CHECKING, Union

from .._models import AutoscalingStatus, ScaleMetric

if TYPE_CHECKING:
    from .._client import OnlineHTTPClient


class AutoscalingAPI:
    def __init__(self, client: 'OnlineHTTPClient') -> None:
        self._client = client

    def create(
        self,
        service_name: str,
        min_capacity: int = 1,
        max_capacity: int = 5,
        scale_metric: Union[ScaleMetric, str] = ScaleMetric.cpu,
        scale_target: int = 80,
        for_canary: bool = False,
    ) -> AutoscalingStatus:
        metric_value = (scale_metric.value if isinstance(
            scale_metric, ScaleMetric) else scale_metric)
        body: dict = {
            'min_capacity': min_capacity,
            'max_capacity': max_capacity,
            'scale_metric': metric_value,
            'scale_target': scale_target,
        }
        params = {'for_canary': 'true'} if for_canary else None
        data = self._client.post(
            f'/inference-services/{service_name}/autoscaling',
            json=body,
            params=params,
        )
        return AutoscalingStatus(**data) if data else AutoscalingStatus()

    def get(self, service_name: str) -> AutoscalingStatus:
        # The control-app returns:
        #   {"inference_service_name": ...,
        #    "primary": {...} | null,
        #    "canary":  {...} | null}
        # — primary is the stable IS's HPA, canary (if present) lives one
        # level down.  Unwrap that into the documented flat
        # ``AutoscalingStatus`` (with ``.canary`` carrying the canary HPA).
        data = self._client.get(
            f'/inference-services/{service_name}/autoscaling')
        if not isinstance(data, dict):
            return AutoscalingStatus()
        primary = data.get('primary') if 'primary' in data else data
        canary = data.get('canary')
        if not isinstance(primary, dict):
            primary = {}
        return AutoscalingStatus(
            **primary,
            canary=AutoscalingStatus(
                **canary) if isinstance(canary, dict) else None,
        )

    def delete(self, service_name: str, for_canary: bool = False) -> None:
        params = {'for_canary': 'true'} if for_canary else None
        self._client.delete(
            f'/inference-services/{service_name}/autoscaling',
            params=params,
        )
