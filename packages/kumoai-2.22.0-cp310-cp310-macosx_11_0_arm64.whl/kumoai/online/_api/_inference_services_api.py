"""Inference service CRUD and canary operations."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Dict, List, Optional

from .._models import (
    CreateInferenceServiceRequest,
    InferenceServiceRecord,
    InferenceServiceUrls,
    StartCanaryRequest,
    _model_dump,
)

if TYPE_CHECKING:
    from .._client import OnlineHTTPClient


def _parse_service(data: Dict[str, Any]) -> InferenceServiceRecord:
    urls_raw = data.get('urls')
    urls = InferenceServiceUrls(
        **urls_raw) if isinstance(urls_raw, dict) else None
    # The control-app returns the IS name under `inference_service_name`;
    # accept legacy `name` as a fallback in case older deployments are hit.
    return InferenceServiceRecord(
        name=data.get('inference_service_name') or data.get('name', ''),
        model_name=data.get('model_name'),
        stable_model_id=data.get('stable_model_id'),
        canary_model_id=data.get('canary_model_id'),
        canary_traffic_percent=data.get('canary_traffic_percent', 0),
        status=data.get('status'),
        urls=urls,
    )


class InferenceServicesAPI:
    def __init__(self, client: 'OnlineHTTPClient') -> None:
        self._client = client

    def create(
        self,
        name: str,
        model_id: str,
        instance_type: Optional[str] = None,
        resources: Optional[Dict[str, Any]] = None,
        tolerations: Optional[List[Dict[str, Any]]] = None,
        node_selector: Optional[Dict[str, str]] = None,
    ) -> InferenceServiceRecord:
        req = CreateInferenceServiceRequest(
            inference_service_name=name,
            model_id=model_id,
            instance_type=instance_type,
            resources=resources,
            tolerations=tolerations,
            node_selector=node_selector,
        )
        data = self._client.post('/inference-services',
                                 json=_model_dump(req, exclude_none=True))
        return _parse_service(data)

    def get(self, name: str) -> InferenceServiceRecord:
        data = self._client.get(f'/inference-services/{name}')
        return _parse_service(data)

    def list(self) -> List[InferenceServiceRecord]:
        data = self._client.get('/inference-services')
        return [_parse_service(s) for s in data.get('inference_services', [])]

    def delete(self, name: str) -> None:
        self._client.delete(f'/inference-services/{name}')

    def start_canary(
        self,
        name: str,
        canary_model_id: str,
        canary_traffic_percent: int,
        allow_overwrite: bool = False,
    ) -> InferenceServiceRecord:
        req = StartCanaryRequest(
            canary_model_id=canary_model_id,
            canary_traffic_percent=canary_traffic_percent,
            allow_overwrite=allow_overwrite if allow_overwrite else None,
        )
        data = self._client.post(
            f'/inference-services/{name}/canary',
            json=_model_dump(req, exclude_none=True),
        )
        return _parse_service(data)

    def promote(self, name: str) -> InferenceServiceRecord:
        data = self._client.post(f'/inference-services/{name}/promote')
        return _parse_service(data)

    def rollback(self, name: str) -> InferenceServiceRecord:
        data = self._client.post(f'/inference-services/{name}/rollback')
        return _parse_service(data)
