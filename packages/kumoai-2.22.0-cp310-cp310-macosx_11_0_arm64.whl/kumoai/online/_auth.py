"""Cognito OAuth2 client_credentials token manager with auto-refresh."""

from __future__ import annotations

import logging
import threading
from typing import Optional

import requests

from ._exceptions import AuthError

logger = logging.getLogger('kumoai_online')

# Refresh the token this many seconds before it actually expires.
_REFRESH_BUFFER_SECONDS = 60


class CognitoAuth:
    """Manages a Cognito client_credentials bearer token.

    Fetches an access token on construction and schedules a background
    ``threading.Timer`` to silently refresh it before expiry. Thread-safe:
    multiple threads can call ``token`` concurrently.
    """
    def __init__(
        self,
        token_url: str,
        client_id: str,
        client_secret: str,
        scope: Optional[str] = None,
    ) -> None:
        self._token_url = token_url
        self._client_id = client_id
        self._client_secret = client_secret
        self._scope = scope
        self._lock = threading.Lock()
        self._token: Optional[str] = None
        self._timer: Optional[threading.Timer] = None
        self._fetch_token()

    # ------------------------------------------------------------------
    # Public interface
    # ------------------------------------------------------------------

    @property
    def token(self) -> str:
        with self._lock:
            if self._token is None:
                raise AuthError('No access token available; init failed.')
            return self._token

    def refresh(self) -> None:
        """Force an immediate token refresh (e.g. after a 401)."""
        self._cancel_timer()
        self._fetch_token()

    def shutdown(self) -> None:
        """Cancel any pending refresh timer."""
        self._cancel_timer()

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _fetch_token(self) -> None:
        data = {
            'grant_type': 'client_credentials',
            'client_id': self._client_id,
            'client_secret': self._client_secret,
        }
        if self._scope:
            data['scope'] = self._scope
        try:
            resp = requests.post(
                self._token_url,
                data=data,
                timeout=30,
            )
            resp.raise_for_status()
        except requests.RequestException as exc:
            raise AuthError(f'Failed to obtain Cognito token: {exc}') from exc

        payload = resp.json()
        access_token = payload.get('access_token')
        if not access_token:
            raise AuthError(
                f'Cognito token response missing access_token: {payload}')

        expires_in: int = int(payload.get('expires_in', 3600))
        refresh_delay = max(expires_in - _REFRESH_BUFFER_SECONDS, 30)

        with self._lock:
            self._token = access_token

        logger.debug('Cognito token acquired; next refresh in %d s',
                     refresh_delay)
        self._schedule_refresh(refresh_delay)

    def _schedule_refresh(self, delay_seconds: float) -> None:
        timer = threading.Timer(delay_seconds, self._background_refresh)
        timer.daemon = True
        timer.start()
        with self._lock:
            self._timer = timer

    def _background_refresh(self) -> None:
        try:
            self._fetch_token()
        except AuthError:
            logger.warning(
                'Background Cognito token refresh failed; '
                'will retry in 30 s',
                exc_info=True,
            )
            self._schedule_refresh(30)

    def _cancel_timer(self) -> None:
        with self._lock:
            if self._timer is not None:
                self._timer.cancel()
                self._timer = None
