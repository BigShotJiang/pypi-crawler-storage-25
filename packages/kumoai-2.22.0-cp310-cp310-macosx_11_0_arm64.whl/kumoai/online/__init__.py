"""Online serving SDK — a separate system from the main Kumo SDK.

Connect to a Kumo online serving control plane and manage model deployments,
inference services, canary rollouts, and autoscaling.

Usage::

    import kumoai.online as kumo_online

    client = kumo_online.init(
        url='https://control.example.com',
        client_id='my-client-id',
        client_secret='my-client-secret',
        token_url='https://cognito-idp.us-east-1.amazonaws.com/POOL/oauth2/token',
    )

    client.register_model('v1', 's3://bucket/models/my_model/')
    svc = client.create_inference_service('svc-1', 'v1')
    svc.start_canary('v2', canary_traffic_percent=20)
    svc.promote()
    result = svc.infer(inputs=[...])
"""

from __future__ import annotations

import logging
import warnings
from typing import Any, Dict, List, Optional

from ._api._autoscaling_api import AutoscalingAPI
from ._api._inference_services_api import InferenceServicesAPI
from ._api._instance_types_api import InstanceTypesAPI
from ._api._models_api import ModelsAPI
from ._api._predict_api import PredictAPI
from ._api._status_api import StatusAPI
from ._api._traffic_api import TrafficAPI
from ._auth import CognitoAuth
from ._client import OnlineHTTPClient
from ._exceptions import (
    AuthError,
    ConflictError,
    ExperimentalWarning,
    NotFoundError,
    OnlineServingError,
    ValidationError,
)
from ._inference_service import InferenceService
from ._models import (
    AutoscalingStatus,
    InferenceServiceRecord,
    RegisteredModel,
    ScaleMetric,
    ServiceStatus,
    TrafficStatus,
)

logger = logging.getLogger('kumoai_online')

warnings.warn(
    'kumoai.online is experimental and may change without notice.',
    category=ExperimentalWarning,
    stacklevel=2,
)


class OnlineServingClient:
    """Client for the Kumo online serving control plane.

    Obtain an instance via :func:`kumoai.online.init`.
    """
    def __init__(self, http_client: OnlineHTTPClient) -> None:
        self._http = http_client
        self._models = ModelsAPI(http_client)
        self._inference_services = InferenceServicesAPI(http_client)
        self._instance_types = InstanceTypesAPI(http_client)
        self._autoscaling = AutoscalingAPI(http_client)
        self._traffic = TrafficAPI(http_client)
        self._status = StatusAPI(http_client)
        self._predict = PredictAPI(http_client)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _wrap(self, record: InferenceServiceRecord) -> InferenceService:
        return InferenceService(
            record=record,
            inference_services_api=self._inference_services,
            autoscaling_api=self._autoscaling,
            predict_api=self._predict,
        )

    # ------------------------------------------------------------------
    # Registered model management
    # ------------------------------------------------------------------

    def register_model(
        self,
        model_id: str,
        s3_model_uri: str,
    ) -> RegisteredModel:
        """Register a model version in the control plane.

        The appropriate Triton serving image is inferred automatically from
        the model directory.

        Args:
            model_id: Unique version identifier (DNS-safe).
            s3_model_uri: S3 URI of the model directory (the final path
                component is used as the Triton model name).

        Returns:
            The created :class:`RegisteredModel`.
        """
        return self._models.register(model_id, s3_model_uri)

    def list_registered_models(self) -> List[RegisteredModel]:
        """List all registered models."""
        return self._models.list()

    def get_registered_model(self, model_id: str) -> RegisteredModel:
        """Get a registered model by its ``model_id``."""
        return self._models.get(model_id)

    def delete_registered_model(self, model_id: str) -> None:
        """Delete a registered model by its ``model_id``."""
        self._models.delete(model_id)

    # ------------------------------------------------------------------
    # Inference service factory / collection
    # ------------------------------------------------------------------

    def list_instance_types(self) -> List[str]:
        """Return GPU instance type names available in this cluster.

        Call this to discover valid ``instance_type`` strings before calling
        :meth:`create_inference_service`.

        Returns:
            List of instance type name strings.
        """
        return self._instance_types.list()

    def create_inference_service(
        self,
        name: str,
        model_id: str,
        instance_type: Optional[str] = None,
        resources: Optional[Dict[str, Any]] = None,
        tolerations: Optional[List[Dict[str, Any]]] = None,
        node_selector: Optional[Dict[str, str]] = None,
    ) -> InferenceService:
        """Deploy a new inference service at 100% stable traffic.

        Pass ``instance_type`` as a string (e.g. ``"g6.4xlarge"``) to let the
        server resolve the correct Kubernetes scheduling constraints.  Use
        :meth:`list_instance_types` to discover what is available in the
        cluster.  The raw ``resources`` / ``tolerations`` / ``node_selector``
        kwargs are for advanced use only and are mutually exclusive with
        ``instance_type``.

        Args:
            name: Service name (DNS-safe, must be unique).
            model_id: The model version to deploy.
            instance_type: Instance type string (e.g. ``"g6.4xlarge"``).
                Validated server-side against the cluster's configured list.
            resources: Kubernetes resource requests/limits (advanced).
            tolerations: Kubernetes tolerations (advanced).
            node_selector: Kubernetes node selector (advanced).

        Returns:
            An :class:`InferenceService` with action methods and prediction
            URLs.
        """
        if instance_type is not None and any(
                p is not None
                for p in (resources, tolerations, node_selector)):
            raise ValueError(
                'instance_type is mutually exclusive with resources, '
                'tolerations, and node_selector')
        record = self._inference_services.create(
            name,
            model_id,
            instance_type=instance_type,
            resources=resources,
            tolerations=tolerations,
            node_selector=node_selector,
        )
        return self._wrap(record)

    def get_inference_service(self, name: str) -> InferenceService:
        """Fetch an existing inference service by name.

        Args:
            name: The service name.

        Returns:
            An :class:`InferenceService` with the current server state.
        """
        return self._wrap(self._inference_services.get(name))

    def list_inference_services(self) -> List[InferenceService]:
        """List all inference services with their canary state and URLs."""
        return [self._wrap(r) for r in self._inference_services.list()]

    # ------------------------------------------------------------------
    # Cross-cutting observability (all services at once)
    # ------------------------------------------------------------------

    def get_traffic(self) -> Dict[str, TrafficStatus]:
        """Return the current canary traffic state for all services."""
        return self._traffic.get_traffic()

    def get_status(self) -> Dict[str, ServiceStatus]:
        """Return the readiness status for all services."""
        return self._status.get_status()

    def health(self) -> bool:
        """Return True if the control plane is healthy."""
        return self._status.health()


# ---------------------------------------------------------------------------
# Module-level init
# ---------------------------------------------------------------------------


def init(
    url: str,
    client_id: str,
    client_secret: str,
    token_url: str,
    scope: Optional[str] = None,
    log_level: str = 'INFO',
) -> OnlineServingClient:
    """Connect to a Kumo online serving control plane.

    Fetches a Cognito bearer token on init and silently refreshes it in
    the background before it expires — no manual token management required.
    This is a **separate system** from the main Kumo SDK; you do not need
    to call ``kumoai.init()`` first.

    Args:
        url: Base URL of the online serving control plane.
        client_id: Cognito app client ID.
        client_secret: Cognito app client secret.
        token_url: Cognito OAuth2 token endpoint URL, e.g.
            ``https://cognito-idp.<region>.amazonaws.com/<pool>/oauth2/token``.
        scope: Optional OAuth2 scope to request (e.g.
            ``'https://inference.kumo.ai/invoke'``). Required when the
            Cognito app client is configured with custom scopes.
        log_level: Python log level for the ``kumoai_online`` logger
            (default ``'INFO'``).

    Returns:
        An authenticated :class:`OnlineServingClient`.

    Example::

        import kumoai.online as kumo_online

        client = kumo_online.init(
            url='https://control.example.com',
            client_id='abc123',
            client_secret='secret',
            token_url='https://cognito-idp.us-east-1.amazonaws.com/POOL/oauth2/token',
        )
    """
    logging.getLogger('kumoai_online').setLevel(log_level.upper())
    auth = CognitoAuth(token_url=token_url, client_id=client_id,
                       client_secret=client_secret, scope=scope)
    http_client = OnlineHTTPClient(base_url=url, auth=auth)
    return OnlineServingClient(http_client)


__all__ = [
    'init',
    'OnlineServingClient',
    'InferenceService',
    # Data models
    'RegisteredModel',
    'InferenceServiceRecord',
    'AutoscalingStatus',
    'ScaleMetric',
    'TrafficStatus',
    'ServiceStatus',
    # Exceptions
    'ExperimentalWarning',
    'OnlineServingError',
    'NotFoundError',
    'ConflictError',
    'AuthError',
    'ValidationError',
]
