"""InferenceService — a live deployed service with action methods."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Dict, List, Optional, Union

from ._models import (
    AutoscalingStatus,
    InferenceServiceRecord,
    InferenceServiceUrls,
    InferResponse,
    ScaleMetric,
)

if TYPE_CHECKING:
    from ._api._autoscaling_api import AutoscalingAPI
    from ._api._inference_services_api import InferenceServicesAPI
    from ._api._predict_api import PredictAPI


class InferenceService:
    """A deployed inference service with canary and autoscaling controls.

    Obtain via :meth:`~OnlineServingClient.create_inference_service`,
    :meth:`~OnlineServingClient.get_inference_service`, or
    :meth:`~OnlineServingClient.list_inference_services`.

    Mutating methods (:meth:`start_canary`, :meth:`promote`,
    :meth:`rollback`) refresh this object in-place from the server
    response and return ``self``, so the instance is never stale after
    a call.
    """
    def __init__(
        self,
        record: InferenceServiceRecord,
        inference_services_api: 'InferenceServicesAPI',
        autoscaling_api: 'AutoscalingAPI',
        predict_api: 'PredictAPI',
    ) -> None:
        self._record = record
        self._inference_services = inference_services_api
        self._autoscaling = autoscaling_api
        self._predict = predict_api

    # ------------------------------------------------------------------
    # Data properties — delegate to the underlying server record
    # ------------------------------------------------------------------

    @property
    def name(self) -> str:
        """Service name (DNS-safe identifier)."""
        return self._record.name

    @property
    def model_name(self) -> Optional[str]:
        """Triton model name derived from the S3 model URI."""
        return self._record.model_name

    @property
    def stable_model_id(self) -> Optional[str]:
        """Model version currently serving 100% (or stable-split) traffic."""
        return self._record.stable_model_id

    @property
    def canary_model_id(self) -> Optional[str]:
        """Model version receiving canary traffic, or ``None``."""
        return self._record.canary_model_id

    @property
    def canary_traffic_percent(self) -> int:
        """Percentage of traffic routed to the canary (0 when inactive)."""
        return self._record.canary_traffic_percent

    @property
    def status(self) -> Optional[str]:
        """Deployment status string (e.g. ``'ACTIVE'``)."""
        return self._record.status

    @property
    def urls(self) -> Optional[InferenceServiceUrls]:
        """Inference URL bundle (``weighted``, ``stable``, ``latest``)."""
        return self._record.urls

    def __repr__(self) -> str:
        return (f'InferenceService(name={self.name!r}, '
                f'stable={self.stable_model_id!r}, '
                f'canary={self.canary_model_id!r}, '
                f'canary_traffic={self.canary_traffic_percent}%, '
                f'status={self.status!r})')

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _refresh(self, record: InferenceServiceRecord) -> 'InferenceService':
        self._record = record
        return self

    # ------------------------------------------------------------------
    # Canary rollouts
    # ------------------------------------------------------------------

    def start_canary(
        self,
        canary_model_id: str,
        canary_traffic_percent: int,
        allow_overwrite: bool = False,
    ) -> 'InferenceService':
        """Activate a canary rollout on this service.

        Args:
            canary_model_id: Model version for the canary.  Must share the
                same Triton model name as the stable version.
            canary_traffic_percent: Percentage of traffic for the canary
                (1–99).
            allow_overwrite: If ``True``, replace an existing active canary
                instead of raising a conflict error (default ``False``).

        Returns:
            ``self``, refreshed with the server's response.
        """
        record = self._inference_services.start_canary(
            self.name,
            canary_model_id,
            canary_traffic_percent,
            allow_overwrite=allow_overwrite,
        )
        return self._refresh(record)

    def promote(self) -> 'InferenceService':
        """Promote the active canary to 100% stable traffic.

        Returns:
            ``self``, refreshed with the server's response.
        """
        return self._refresh(self._inference_services.promote(self.name))

    def rollback(self) -> 'InferenceService':
        """Roll back to the stable model (0% canary traffic).

        Returns:
            ``self``, refreshed with the server's response.
        """
        return self._refresh(self._inference_services.rollback(self.name))

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def delete(self) -> None:
        """Remove this inference service and its routing configuration."""
        self._inference_services.delete(self.name)

    # ------------------------------------------------------------------
    # Autoscaling
    # ------------------------------------------------------------------

    def create_autoscaling(
        self,
        min_capacity: int = 1,
        max_capacity: int = 5,
        scale_metric: Union[ScaleMetric, str] = ScaleMetric.cpu,
        scale_target: int = 80,
        for_canary: bool = False,
    ) -> AutoscalingStatus:
        """Create or replace an HPA for this service.

        Args:
            min_capacity: Minimum replica count (default 1).
            max_capacity: Maximum replica count (default 5).
            scale_metric: Kubernetes resource metric to scale on —
                :attr:`ScaleMetric.cpu` or :attr:`ScaleMetric.memory`
                (default :attr:`ScaleMetric.cpu`).  ``concurrency`` and
                ``rps`` are defined but require a Prometheus custom-metrics
                adapter and will be rejected by the server with a 400.
            scale_target: Target average utilisation percentage (default 80).
            for_canary: If ``True``, create the HPA for the canary deployment
                instead of the stable one (default ``False``).

        Returns:
            :class:`~._models.AutoscalingStatus`.
        """
        return self._autoscaling.create(self.name, min_capacity, max_capacity,
                                        scale_metric, scale_target, for_canary)

    def get_autoscaling(self) -> AutoscalingStatus:
        """Get HPA status for this service.

        Returns an :class:`~._models.AutoscalingStatus` for the stable
        deployment.  If a canary HPA also exists, it is available on the
        returned object's ``canary`` attribute.
        """
        return self._autoscaling.get(self.name)

    def delete_autoscaling(self, for_canary: bool = False) -> None:
        """Delete the HPA for this service.

        Args:
            for_canary: If ``True``, delete the canary HPA instead of the
                stable one (default ``False``).
        """
        self._autoscaling.delete(self.name, for_canary)

    # ------------------------------------------------------------------
    # Inference
    # ------------------------------------------------------------------

    def infer(
        self,
        inputs: List[Dict[str, Any]],
        outputs: Optional[List[Dict[str, Any]]] = None,
        *,
        url: Optional[str] = None,
    ) -> InferResponse:
        """Send a Triton V2 inference request.

        Defaults to ``self.urls.weighted`` (the load-balanced endpoint).
        Pass ``url=`` to target ``self.urls.stable`` or
        ``self.urls.latest`` instead.

        Args:
            inputs: Triton input dicts with keys ``name``, ``shape``,
                ``datatype``, ``data``.
            outputs: Optional list of output dicts: ``[{"name": "..."}]``.
            url: Override the inference URL (default: ``self.urls.weighted``).

        Returns:
            :class:`~._models.InferResponse` with model outputs.
        """
        infer_url = url or (self.urls.weighted if self.urls else None)
        if not infer_url:
            raise ValueError(
                'No inference URL available; provide url= explicitly '
                'or wait for the service to become ready.')
        return self._predict.infer(infer_url, inputs, outputs)
