"""Pydantic request/response models for the online serving SDK."""

from __future__ import annotations

from enum import Enum
from typing import Any, Dict, List, Optional

from pydantic import BaseModel


def _model_dump(model: BaseModel,
                exclude_none: bool = False) -> Dict[str, Any]:
    """Serialize a Pydantic model — works with both v1 and v2."""
    if hasattr(model, 'model_dump'):
        return model.model_dump(exclude_none=exclude_none)
    return model.dict(exclude_none=exclude_none)


# ---------------------------------------------------------------------------
# Model management
# ---------------------------------------------------------------------------


class RegisterModelRequest(BaseModel):
    model_id: str
    s3_model_uri: str
    environment: Optional[Dict[str, str]] = None
    image_uri: Optional[str] = None


class RegisteredModel(BaseModel):
    model_id: str
    model_name: str
    s3_model_uri: str
    created_at: str
    image_uri: Optional[str] = None
    environment: Optional[Dict[str, str]] = None


class ModelListResponse(BaseModel):
    models: List[RegisteredModel]
    count: int


# ---------------------------------------------------------------------------
# Inference service management
# ---------------------------------------------------------------------------


class CreateInferenceServiceRequest(BaseModel):
    inference_service_name: str
    model_id: str
    instance_type: Optional[str] = None
    resources: Optional[Dict[str, Any]] = None
    tolerations: Optional[List[Dict[str, Any]]] = None
    node_selector: Optional[Dict[str, str]] = None


class InferenceServiceUrls(BaseModel):
    weighted: Optional[str] = None
    stable: Optional[str] = None
    latest: Optional[str] = None


class InferenceServiceRecord(BaseModel):
    name: str
    model_name: Optional[str] = None
    stable_model_id: Optional[str] = None
    canary_model_id: Optional[str] = None
    canary_traffic_percent: int = 0
    status: Optional[str] = None
    urls: Optional[InferenceServiceUrls] = None


class InferenceServiceListResponse(BaseModel):
    inference_services: List[InferenceServiceRecord]


class StartCanaryRequest(BaseModel):
    canary_model_id: str
    canary_traffic_percent: int
    allow_overwrite: Optional[bool] = None


# ---------------------------------------------------------------------------
# Traffic / status
# ---------------------------------------------------------------------------


class TrafficStatus(BaseModel):
    stable_model_id: Optional[str] = None
    canary_model_id: Optional[str] = None
    canary_traffic_percent: int = 0


class ServiceStatus(BaseModel):
    ready: bool
    message: Optional[str] = None


# ---------------------------------------------------------------------------
# Autoscaling
# ---------------------------------------------------------------------------


class ScaleMetric(str, Enum):
    """Kubernetes HPA metric to scale on."""

    cpu = 'cpu'
    memory = 'memory'
    concurrency = 'concurrency'
    rps = 'rps'


class AutoscalingConfig(BaseModel):
    min_capacity: int = 1
    max_capacity: int = 5
    scale_metric: ScaleMetric = ScaleMetric.cpu
    scale_target: int = 80


class AutoscalingStatus(BaseModel):
    min_replicas: Optional[int] = None
    max_replicas: Optional[int] = None
    scale_metric: Optional[str] = None
    scale_target: Optional[int] = None
    current_replicas: Optional[int] = None
    canary: Optional['AutoscalingStatus'] = None


AutoscalingStatus.model_rebuild() if hasattr(
    AutoscalingStatus,
    'model_rebuild') else AutoscalingStatus.update_forward_refs()

# ---------------------------------------------------------------------------
# Inference (Triton V2 JSON protocol)
# ---------------------------------------------------------------------------


class InferInput(BaseModel):
    name: str
    shape: List[int]
    datatype: str
    data: List[Any]


class InferOutput(BaseModel):
    name: str


class InferRequest(BaseModel):
    inputs: List[InferInput]
    outputs: Optional[List[InferOutput]] = None


class InferResponse(BaseModel):
    outputs: Optional[List[Dict[str, Any]]] = None
    model_name: Optional[str] = None
    model_version: Optional[str] = None
    id: Optional[str] = None
