"""HTTP client for the online serving control plane."""

from __future__ import annotations

import logging
from typing import Any, Dict, Optional

import requests
from requests.adapters import HTTPAdapter
from urllib3.util import Retry

from ._auth import CognitoAuth
from ._exceptions import (
    AuthError,
    ConflictError,
    NotFoundError,
    OnlineServingError,
    ValidationError,
)

logger = logging.getLogger('kumoai_online')


class OnlineHTTPClient:
    """Thin HTTP client wrapping ``requests.Session`` with Cognito auth.

    Retries on transient errors (408, 429, 5xx) with exponential backoff,
    and handles 401 by refreshing the Cognito token once before giving up.
    """
    def __init__(self, base_url: str, auth: CognitoAuth) -> None:
        self._base_url = base_url.rstrip('/')
        self._auth = auth

        retry_strategy = Retry(
            total=10,
            connect=3,
            read=3,
            status=5,
            status_forcelist=[408, 429, 500, 502, 503, 504],
            backoff_factor=2.0,
        )
        adapter = HTTPAdapter(max_retries=retry_strategy)
        session = requests.Session()
        session.mount('http://', adapter)
        session.mount('https://', adapter)
        self._session = session

    # ------------------------------------------------------------------
    # Public HTTP methods
    # ------------------------------------------------------------------

    def get(self, path: str, **kwargs: Any) -> Any:
        return self._request('GET', path, **kwargs)

    def post(
        self,
        path: str,
        json: Optional[Dict[str, Any]] = None,
        **kwargs: Any,
    ) -> Any:
        return self._request('POST', path, json=json, **kwargs)

    def patch(
        self,
        path: str,
        json: Optional[Dict[str, Any]] = None,
        **kwargs: Any,
    ) -> Any:
        return self._request('PATCH', path, json=json, **kwargs)

    def delete(self, path: str, **kwargs: Any) -> Any:
        return self._request('DELETE', path, **kwargs)

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _request(self, method: str, path: str, **kwargs: Any) -> Any:
        url = f'{self._base_url}{path}'
        headers = {'Authorization': f'Bearer {self._auth.token}'}
        resp = self._session.request(method, url, headers=headers, **kwargs)

        if resp.status_code == 401:
            # Token may have just expired; refresh once and retry.
            logger.debug('Received 401; refreshing Cognito token and retrying')
            self._auth.refresh()
            headers = {'Authorization': f'Bearer {self._auth.token}'}
            resp = self._session.request(method, url, headers=headers,
                                         **kwargs)

        return self._raise_or_parse(resp)

    def _raise_or_parse(self, resp: requests.Response) -> Any:
        if resp.ok:
            if resp.status_code == 204 or not resp.content:
                return None
            return resp.json()

        detail = _extract_detail(resp)
        status = resp.status_code

        if status == 401:
            raise AuthError(f'Authentication failed: {detail}',
                            status_code=status)
        if status == 404:
            raise NotFoundError(detail, status_code=status)
        if status == 409:
            raise ConflictError(detail, status_code=status)
        if status in (400, 422):
            raise ValidationError(detail, status_code=status)
        raise OnlineServingError(f'Request failed ({status}): {detail}',
                                 status_code=status)


def _extract_detail(resp: requests.Response) -> str:
    try:
        body = resp.json()
        return str(body.get('detail', body))
    except Exception:
        return resp.text or resp.reason or str(resp.status_code)
