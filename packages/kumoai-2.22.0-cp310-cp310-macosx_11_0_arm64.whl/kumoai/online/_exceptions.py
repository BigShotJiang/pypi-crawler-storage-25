"""Exception hierarchy for the online serving SDK."""


class ExperimentalWarning(UserWarning):
    """Emitted on import to flag that kumoai.online is experimental."""


class OnlineServingError(Exception):
    """Base exception for all online serving SDK errors."""
    def __init__(self, message: str, status_code: int | None = None) -> None:
        super().__init__(message)
        self.status_code = status_code


class NotFoundError(OnlineServingError):
    """Raised when a resource is not found (HTTP 404)."""


class ConflictError(OnlineServingError):
    """Raised on duplicate or conflicting resource state (HTTP 409)."""


class AuthError(OnlineServingError):
    """Raised on authentication failure after token refresh (HTTP 401)."""


class ValidationError(OnlineServingError):
    """Raised on request validation failure (HTTP 400/422)."""
