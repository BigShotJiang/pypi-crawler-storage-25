# artdam-cli

ArtDAM 数字资产管理平台命令行工具，支持搜索、查看、下载数字资产。适用于 AI Agent（Claude Code、Codex）和开发者。

## 安装

```bash
# 推荐（无需 Python）
uv tool install artdam-cli

# 或使用 pip
pip install artdam-cli
```

## 快速开始

```bash
# 登录（首次使用）
artdam login --url http://172.26.166.187:8000

# 搜索资产
artdam search "关键词" --project 1

# 查看资产详情
artdam get 123

# 下载资产
artdam download 123 --out ./downloads
```

## 命令说明

### `artdam login`
登录 ArtDAM 服务器，保存 token 到本地 `~/.artdam/config.json`。

```bash
artdam login --url http://172.26.166.187:8000
```

### `artdam search`
搜索资产，返回匹配列表。

```bash
artdam search "头盔" --project 1
artdam search "头盔" --project 1 --limit 50
artdam search "头盔" --project 1 --type image/png
artdam search "头盔" --project 1 --folder 10
artdam search "头盔" --project 1 --json   # 输出原始 JSON（AI Agent 用）
```

| 参数 | 说明 |
|---|---|
| `KEYWORD` | 搜索关键词 |
| `-p, --project` | 项目 ID（必填） |
| `-n, --limit` | 返回数量上限（默认 20） |
| `--type` | 文件类型，如 `image/png` |
| `--folder` | 限定文件夹 ID |
| `--json` | 输出原始 JSON |

### `artdam get`
查看单个资产详情。

```bash
artdam get 123
artdam get 123 --json   # 输出原始 JSON（AI Agent 用）
```

### `artdam download`
下载资产文件到本地。

```bash
artdam download 123
artdam download 123 --out ./downloads
```

| 参数 | 说明 |
|---|---|
| `ASSET_ID` | 资产 ID |
| `-o, --out` | 下载目录（默认当前目录） |

### `artdam tags`
列出项目标签。

```bash
artdam tags --project 1
artdam tags --project 1 --search "角色"
artdam tags --project 1 --json
```

### `artdam folders`
查看文件夹结构。

```bash
artdam folders --project 1
artdam folders --project 1 --json
```

## AI Agent 使用指南

所有查询命令支持 `--json` 输出原始 JSON，适合 Agent 解析：

```bash
# 搜索并获取 JSON
artdam search "安妮" --project 1 --json

# 获取资产详情 JSON
artdam get 123 --json

# 获取标签列表 JSON
artdam tags --project 1 --json
```

### 典型 Agent 工作流

```bash
# 1. 登录（向用户获取用户名密码后执行）
artdam login --username <用户名> --password <密码>

# 2. 搜索资产，找到 ID
artdam search "头盔" --project 1 --json

# 3. 查看详情确认
artdam get 50707 --json

# 4. 下载文件
artdam download 50707 --out ./assets
```

## 配置文件

登录信息保存在 `~/.artdam/config.json`：

```json
{
  "url": "http://172.26.166.187:8000",
  "token": "eyJ..."
}
```
