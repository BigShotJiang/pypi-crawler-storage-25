from __future__ import annotations

import httpx

from artdam_cli import config


def _make_client() -> httpx.Client:
    base_url = config.require("base_url")
    token = config.require("token")
    return httpx.Client(
        base_url=base_url,
        headers={"Authorization": f"Bearer {token}"},
        timeout=30,
    )


def get(path: str, params: dict | None = None) -> dict:
    with _make_client() as c:
        r = c.get(path, params=params)
        _raise(r)
        return r.json()


def download_file(path: str, dest: str) -> int:
    base_url = config.require("base_url")
    token = config.require("token")
    with httpx.stream(
        "GET",
        f"{base_url}{path}",
        headers={"Authorization": f"Bearer {token}"},
        timeout=120,
        follow_redirects=True,
    ) as r:
        _raise(r)
        total = 0
        with open(dest, "wb") as f:
            for chunk in r.iter_bytes(65536):
                f.write(chunk)
                total += len(chunk)
    return total


def _raise(r: httpx.Response) -> None:
    if r.status_code == 401:
        raise SystemExit("Token 无效或已过期，请重新运行 artdam login")
    if r.status_code == 404:
        raise SystemExit("资源不存在")
    if r.is_error:
        raise SystemExit(f"请求失败 {r.status_code}: {r.text[:200]}")
