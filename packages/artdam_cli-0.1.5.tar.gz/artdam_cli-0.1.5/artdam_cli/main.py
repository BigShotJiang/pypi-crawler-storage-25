import click

from artdam_cli.commands.login import login
from artdam_cli.commands.search import search
from artdam_cli.commands.get import get
from artdam_cli.commands.tags import tags
from artdam_cli.commands.folders import folders
from artdam_cli.commands.download import download


@click.group()
@click.version_option(package_name="artdam-cli")
def cli() -> None:
    """ArtDAM 命令行工具 — 搜索、查看、下载数字资产。"""


cli.add_command(login)
cli.add_command(search)
cli.add_command(get)
cli.add_command(tags)
cli.add_command(folders)
cli.add_command(download)
