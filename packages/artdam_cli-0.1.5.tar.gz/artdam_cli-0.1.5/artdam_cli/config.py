from __future__ import annotations

import json
from pathlib import Path

_CONFIG_PATH = Path.home() / ".artdam" / "config.json"


def load() -> dict:
    if not _CONFIG_PATH.exists():
        return {}
    return json.loads(_CONFIG_PATH.read_text(encoding="utf-8"))


def save(data: dict) -> None:
    _CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
    _CONFIG_PATH.write_text(json.dumps(data, indent=2), encoding="utf-8")


def get(key: str) -> str | None:
    return load().get(key)


def require(key: str) -> str:
    value = get(key)
    if not value:
        raise SystemExit(f"未配置 {key}，请先运行: artdam login")
    return value
