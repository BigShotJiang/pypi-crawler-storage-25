import json

import click
from rich.console import Console
from rich.table import Table

from artdam_cli import client

console = Console()


@click.command()
@click.option("--project", "-p", required=True, type=int, help="项目 ID")
@click.option("--search", "-s", default=None, help="按名称过滤")
@click.option("--json", "as_json", is_flag=True, help="输出原始 JSON")
def tags(project: int, search: str | None, as_json: bool) -> None:
    """列出项目标签。"""
    params: dict = {"project_id": project}
    if search:
        data = client.get("/api/tags/search", params={"project_id": project, "q": search})
    else:
        data = client.get("/api/tags/", params=params)

    items = data if isinstance(data, list) else data.get("items", [])

    if as_json:
        click.echo(json.dumps(items, ensure_ascii=False, indent=2))
        return

    if not items:
        console.print("[yellow]暂无标签[/yellow]")
        return

    table = Table(title=f"项目 {project} 标签列表（{len(items)} 个）")
    table.add_column("ID", style="dim", width=6)
    table.add_column("标签名", min_width=20)
    table.add_column("资产数", width=8)

    for item in items:
        table.add_row(
            str(item["id"]),
            item.get("name", ""),
            str(item.get("asset_count", "—")),
        )

    console.print(table)
