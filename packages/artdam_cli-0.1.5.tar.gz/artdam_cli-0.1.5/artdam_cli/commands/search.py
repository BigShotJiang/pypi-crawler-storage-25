import json

import click
from rich.console import Console
from rich.table import Table

from artdam_cli import client

console = Console()


@click.command()
@click.argument("keyword")
@click.option("--project", "-p", required=True, type=int, help="项目 ID")
@click.option("--limit", "-n", default=20, show_default=True, help="返回数量上限")
@click.option("--type", "mime", default=None, help="文件类型，例: image/png")
@click.option("--folder", default=None, type=int, help="限定文件夹 ID")
@click.option("--json", "as_json", is_flag=True, help="输出原始 JSON（AI Agent 用）")
def search(keyword: str, project: int, limit: int, mime: str | None, folder: int | None, as_json: bool) -> None:
    """搜索资产。"""
    params: dict = {
        "project_id": project,
        "q": keyword,
        "page_size": limit,
    }
    if mime:
        params["mime_type"] = mime
    if folder:
        params["folder_id"] = folder

    data = client.get("/api/assets/", params=params)
    items = data.get("items", [])

    if as_json:
        click.echo(json.dumps(items, ensure_ascii=False, indent=2))
        return

    if not items:
        console.print("[yellow]未找到匹配资产[/yellow]")
        return

    table = Table(title=f"搜索「{keyword}」— 共 {data.get('total', len(items))} 条")
    table.add_column("ID", style="dim", width=6)
    table.add_column("文件名", min_width=20)
    table.add_column("类型", width=10)
    table.add_column("大小", width=10)
    table.add_column("标签", min_width=20)

    for item in items:
        tags = ", ".join(t["name"] for t in item.get("tags", []))
        size = item.get("file_size") or 0
        size_str = f"{size / 1024 / 1024:.1f} MB" if size > 0 else "—"
        table.add_row(
            str(item["id"]),
            item.get("filename", ""),
            (item.get("mime_type") or "").split("/")[-1],
            size_str,
            tags or "—",
        )

    console.print(table)
