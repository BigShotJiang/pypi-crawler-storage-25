import json

import click
from rich.console import Console
from rich.panel import Panel
from rich.text import Text

from artdam_cli import client

console = Console()


@click.command()
@click.argument("asset_id", type=int)
@click.option("--json", "as_json", is_flag=True, help="输出原始 JSON（AI Agent 用）")
def get(asset_id: int, as_json: bool) -> None:
    """查看资产详情。"""
    data = client.get(f"/api/assets/{asset_id}")

    if as_json:
        click.echo(json.dumps(data, ensure_ascii=False, indent=2))
        return

    tags = ", ".join(t["name"] for t in data.get("tags", []))
    size = data.get("file_size") or 0
    size_str = f"{size / 1024 / 1024:.1f} MB" if size > 0 else "—"

    lines = [
        f"[bold]ID[/bold]          {data['id']}",
        f"[bold]文件名[/bold]      {data.get('filename', '—')}",
        f"[bold]类型[/bold]        {data.get('mime_type', '—')}",
        f"[bold]大小[/bold]        {size_str}",
        f"[bold]标签[/bold]        {tags or '—'}",
        f"[bold]AI 描述[/bold]     {data.get('ai_description') or '—'}",
        f"[bold]上传时间[/bold]    {data.get('created_at', '—')}",
        f"[bold]路径[/bold]        {data.get('original_path', '—')}",
    ]

    console.print(Panel("\n".join(lines), title=f"资产 #{asset_id}"))
