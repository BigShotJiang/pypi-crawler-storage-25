import os

import click
from rich.console import Console
from rich.progress import Progress

from artdam_cli import client

console = Console()


@click.command()
@click.argument("asset_id", type=int)
@click.option("--out", "-o", default=".", help="下载目录（默认当前目录）")
def download(asset_id: int, out: str) -> None:
    """下载资产文件。"""
    data = client.get(f"/api/assets/{asset_id}")
    filename = data.get("filename", f"asset_{asset_id}")
    dest = os.path.join(out, filename)
    os.makedirs(out, exist_ok=True)

    with Progress() as progress:
        task = progress.add_task(f"下载 {filename}...", total=None)
        total = client.download_file(f"/api/assets/{asset_id}/file", dest)
        progress.update(task, completed=total, total=total)

    size_str = f"{total / 1024 / 1024:.1f} MB"
    console.print(f"✓ 已下载到 [green]{dest}[/green]（{size_str}）")
