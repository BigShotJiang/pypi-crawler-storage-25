import json

import click
from rich.console import Console
from rich.tree import Tree

from artdam_cli import client

console = Console()


def _build_tree(node: Tree, items: list[dict], parent_id: int | None) -> None:
    children = [i for i in items if i.get("parent_id") == parent_id]
    for child in children:
        branch = node.add(f"[cyan]{child['name']}[/cyan] [dim](id={child['id']})[/dim]")
        _build_tree(branch, items, child["id"])


@click.command()
@click.option("--project", "-p", required=True, type=int, help="项目 ID")
@click.option("--json", "as_json", is_flag=True, help="输出原始 JSON")
def folders(project: int, as_json: bool) -> None:
    """查看文件夹结构。"""
    data = client.get("/api/collections/", params={"project_id": project})
    items = data if isinstance(data, list) else data.get("items", [])

    if as_json:
        click.echo(json.dumps(items, ensure_ascii=False, indent=2))
        return

    if not items:
        console.print("[yellow]暂无文件夹[/yellow]")
        return

    tree = Tree(f"[bold]项目 {project} 文件夹[/bold]")
    _build_tree(tree, items, None)
    console.print(tree)
