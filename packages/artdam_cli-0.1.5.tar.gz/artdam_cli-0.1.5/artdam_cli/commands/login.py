import click
import httpx

from artdam_cli import config


@click.command()
@click.option("--url", default="http://172.26.166.187:8000", help="服务器地址，默认: http://172.26.166.187:8000")
@click.option("--username", prompt="用户名")
@click.option("--password", prompt="密码", hide_input=True)
def login(url: str, username: str, password: str) -> None:
    """登录 ArtDAM，保存 token 到本地。"""
    url = url.rstrip("/")
    try:
        r = httpx.post(
            f"{url}/api/auth/login",
            json={"username": username, "password": password},
            timeout=10,
        )
    except httpx.ConnectError:
        raise SystemExit(f"无法连接到 {url}，请检查地址")

    if r.status_code != 200:
        raise SystemExit(f"登录失败: {r.json().get('detail', r.text)}")

    token = r.json().get("access_token")
    if not token:
        raise SystemExit("登录响应中未找到 token")

    config.save({"base_url": url, "token": token})
    click.echo(f"✓ 登录成功，配置已保存到 ~/.artdam/config.json")
