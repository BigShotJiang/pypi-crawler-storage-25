from __future__ import annotations

import hashlib
import json
import os
import platform
import socket
import time
import uuid
from pathlib import Path

import typer

from benchci.auth.client import get_me, list_workspaces, login_user, logout_user, refresh_user_session, register_user
from benchci.auth.session import (
    clear_session,
    get_api_base_url,
    load_session,
    save_session,
    session_from_auth_response,
    set_active_workspace,
)
from benchci.commands.doctor import run_doctor
from benchci.runner.local import run_local


app = typer.Typer(
    no_args_is_help=True,
    help="BenchCI — Hardware test automation for embedded systems.",
    pretty_exceptions_enable=False,
)

agent_app = typer.Typer(
    no_args_is_help=True,
    help="Run and manage BenchCI Agent services.",
)
app.add_typer(agent_app, name="agent")

benches_app = typer.Typer(
    no_args_is_help=True,
    help="List and inspect cloud benches available through the BenchCI backend.",
)
app.add_typer(benches_app, name="benches")

runs_app = typer.Typer(
    no_args_is_help=True,
    help="Inspect cloud runs and view their events.",
)
app.add_typer(runs_app, name="runs")

workspace_app = typer.Typer(
    no_args_is_help=True,
    help="List and switch active workspaces for cloud operations.",
)
app.add_typer(workspace_app, name="workspace")


def _info(msg: str) -> None:
    typer.echo(f"[INFO] {msg}")


def _ok(msg: str) -> None:
    typer.echo(f"[ OK ] {msg}")


def _warn(msg: str) -> None:
    typer.echo(f"[WARN] {msg}")


def _fail(msg: str) -> None:
    typer.echo(f"[FAIL] {msg}")


def _is_ci_environment() -> bool:
    # Explicit override for controlled environments.
    override = os.getenv("BENCHCI_IS_CI", "").strip().lower()
    if override in {"1", "true", "yes", "on"}:
        return True
    if override in {"0", "false", "no", "off"}:
        return False

    ci_markers = [
        # Generic
        "CI",
        "CONTINUOUS_INTEGRATION",
        "BUILD_NUMBER",
        "RUN_ID",

        # GitHub / GitLab / Bitbucket
        "GITHUB_ACTIONS",
        "GITLAB_CI",
        "BITBUCKET_BUILD_NUMBER",

        # Common hosted CI
        "CIRCLECI",
        "TRAVIS",
        "APPVEYOR",
        "SEMAPHORE",
        "BUILDKITE",
        "DRONE",

        # Enterprise / cloud CI
        "JENKINS_URL",
        "TEAMCITY_VERSION",
        "TF_BUILD",
        "CODEBUILD_BUILD_ID",
        "HEROKU_TEST_RUN_ID",
        "BAMBOO_BUILDKEY",
        "BUDDY",
        "GOCD_SERVER_HOST",
    ]

    return any(os.getenv(name) for name in ci_markers)

def _machine_id() -> str:
    raw = f"{platform.node()}:{uuid.getnode()}:{socket.gethostname()}"
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def _machine_name() -> str:
    return platform.node() or socket.gethostname() or "unknown-machine"


def _session_workspace_id(session: dict) -> str | None:
    return session.get("active_workspace_id")


def _require_valid_session() -> dict:
    session = load_session()
    if not session:
        raise RuntimeError("No BenchCI session found. Run 'benchci login' first.")

    api_base_url = session.get("api_base_url") or get_api_base_url()
    refresh_token_value = session.get("refresh_token")
    active_workspace_id = session.get("active_workspace_id")

    if not refresh_token_value:
        raise RuntimeError("BenchCI session is missing a refresh token. Run 'benchci login' again.")

    refreshed = refresh_user_session(
        api_base_url=api_base_url,
        refresh_token=refresh_token_value,
        machine_id=_machine_id(),
    )
    updated_session = session_from_auth_response(api_base_url, refreshed)

    if active_workspace_id:
        try:
            updated_session = set_active_workspace(updated_session, active_workspace_id)
        except Exception:
            pass

    updated_session["refreshed_at_unix"] = int(time.time())
    save_session(updated_session)
    return updated_session


def _require_cloud_session() -> tuple[str, str, str | None]:
    session = _require_valid_session()
    api_base_url = session.get("api_base_url") or get_api_base_url()
    access_token = session.get("access_token")
    workspace_id = session.get("active_workspace_id")
    if not access_token:
        raise RuntimeError("BenchCI session is missing an access token. Run 'benchci login' again.")
    return api_base_url, access_token, workspace_id

def _format_plan(value: object) -> str:
    if value is None:
        return "—"
    return str(value).replace("-", " ").title()


def _workspace_entitled(session: dict) -> bool:
    return bool(session.get("active_workspace_entitled"))


def _require_entitled_workspace(action: str = "run execution") -> dict:
    session = _require_valid_session()

    if _workspace_entitled(session):
        return session

    workspace_name = session.get("active_workspace_name") or "BenchCI workspace"
    workspace_status = session.get("active_workspace_status") or "unknown"
    workspace_plan = session.get("active_workspace_plan") or "unknown"

    raise RuntimeError(
        f"Workspace is not active for {action}.\n"
        f"Workspace: {workspace_name}\n"
        f"Plan: {_format_plan(workspace_plan)}\n"
        f"Status: {_format_plan(workspace_status)}\n"
        "Contact tech@benchci.dev to activate your BenchCI workspace."
    )

def _emit_cloud_status(run_id: str, payload: dict) -> None:
    status = payload.get("status")
    exit_code = payload.get("exit_code")
    assigned_agent = payload.get("assigned_agent_id")
    assigned_bench = payload.get("assigned_bench_id")

    if status == "queued":
        _info(f"{run_id} queued")
    elif status == "preparing":
        _info(f"{run_id} preparing (agent={assigned_agent}, bench={assigned_bench})")
    elif status == "running":
        _info(f"{run_id} running (agent={assigned_agent}, bench={assigned_bench})")
    elif status == "uploading_artifacts":
        _info(f"{run_id} uploading artifacts")
    elif status == "done":
        _ok(f"{run_id} finished successfully (exit_code={exit_code})")
    elif status == "failed":
        _fail(f"{run_id} failed: {payload.get('error')} (exit_code={exit_code})")


def _emit_cloud_event(event: dict) -> None:
    event_type = event.get("event_type")
    message = event.get("message")
    if message:
        _info(f"event {event_type}: {message}")
    else:
        _info(f"event {event_type}")


@app.command(help="Create a new BenchCI account and your first workspace.")
def register(
    email: str | None = typer.Option(None, "--email", help="Email address for your BenchCI account."),
    password: str | None = typer.Option(None, "--password", help="Password for your BenchCI account."),
    workspace_name: str | None = typer.Option(None, "--workspace-name", help="Name of the workspace to create."),
    display_name: str | None = typer.Option(None, "--display-name", help="Optional display name."),
    api_url: str | None = typer.Option(None, "--api-url", help="BenchCI backend API base URL."),
):
    api_base_url = (api_url or get_api_base_url()).rstrip("/")

    if not email:
        email = typer.prompt("Email").strip()
    if not password:
        password = typer.prompt("Password", hide_input=True, confirmation_prompt=True).strip()
    if not workspace_name:
        workspace_name = typer.prompt("Workspace name").strip()
    if display_name is None:
        display_name = typer.prompt("Display name", default="").strip() or None

    _info(f"Using backend: {api_base_url}")
    result = register_user(
        api_base_url=api_base_url,
        email=email,
        password=password,
        workspace_name=workspace_name,
        display_name=display_name,
    )

    session = session_from_auth_response(api_base_url, result)
    session["registered_at_unix"] = int(time.time())
    path = save_session(session)

    _ok("BenchCI registration successful")
    _info(f"User: {result.get('email')}")
    _info(f"Workspace: {result.get('workspace_name')} ({result.get('workspace_role')})")
    _info(f"Session saved to: {path}")


@app.command(help="Log in to BenchCI using your email and password.")
def login(
    email: str | None = typer.Option(None, "--email", help="BenchCI account email."),
    password: str | None = typer.Option(None, "--password", help="BenchCI account password."),
    api_url: str | None = typer.Option(None, "--api-url", help="BenchCI backend API base URL."),
):
    api_base_url = (api_url or get_api_base_url()).rstrip("/")

    if not email:
        email = typer.prompt("Email").strip()
    if not password:
        password = typer.prompt("Password", hide_input=True).strip()

    _info(f"Using backend: {api_base_url}")
    result = login_user(
        api_base_url=api_base_url,
        email=email,
        password=password,
        machine_id=_machine_id(),
        machine_name=_machine_name(),
        is_ci=_is_ci_environment(),
    )

    session = session_from_auth_response(api_base_url, result)
    session["logged_in_at_unix"] = int(time.time())
    path = save_session(session)

    _ok("BenchCI login successful")
    _info(f"User: {result.get('email')}")
    _info(f"Active workspace: {result.get('workspace_name')} ({result.get('workspace_role')})")
    _info(f"Access token expires at: {result.get('expires_at')}")
    _info(f"Session saved to: {path}")


@app.command(help="Remove the current local BenchCI session from this machine.")
def logout():
    session = load_session()
    if session is None:
        _warn("No BenchCI session found")
        raise SystemExit(0)

    try:
        api_base_url = session.get("api_base_url") or get_api_base_url()
        refresh_token_value = session.get("refresh_token")
        if refresh_token_value:
            logout_user(
                api_base_url=api_base_url,
                refresh_token=refresh_token_value,
                machine_id=_machine_id(),
            )
    except Exception as exc:
        _warn(f"Remote logout failed, clearing local session anyway: {exc}")

    clear_session()
    _ok("BenchCI session removed")


@app.command(help="Show the current authenticated BenchCI user and active workspace.")
def whoami():
    try:
        session = _require_valid_session()
    except Exception as exc:
        _fail(str(exc))
        raise SystemExit(1)

    access_token = session.get("access_token")
    api_base_url = session.get("api_base_url") or get_api_base_url()
    workspace_id = session.get("active_workspace_id")

    if not access_token:
        _fail("Session is missing an access token. Run 'benchci login' again.")
        raise SystemExit(1)

    me = get_me(api_base_url=api_base_url, access_token=access_token, workspace_id=workspace_id)

    _ok("BenchCI session is active")
    _info(f"Backend: {api_base_url}")
    _info(f"User: {me.get('email')} ({me.get('display_name')})")
    _info(f"Active workspace: {me.get('workspace_name')} ({me.get('workspace_role')})")
    _info(f"Workspace plan: {_format_plan(me.get('workspace_plan'))}")
    _info(f"Workspace status: {_format_plan(me.get('workspace_status'))}")
    _info(f"Workspace entitled: {bool(me.get('workspace_entitled'))}")
    _info(f"Limits: {me.get('seat_limit') or '—'} seats · {me.get('bench_limit') or '—'} benches")    
    _info(f"User status: {me.get('status')}")


@app.command(
    help="Validate bench.yaml and/or suite.yaml files before running tests."
)
def validate(
    bench: str | None = typer.Option(
        None,
        "--bench",
        "-b",
        help="Path to bench config YAML to validate.",
    ),
    suite: str | None = typer.Option(
        None,
        "--suite",
        "-s",
        help="Path to suite config YAML to validate.",
    ),
):
    if not bench and not suite:
        raise typer.BadParameter("Provide --bench and/or --suite")

    if bench:
        from benchci.config.bench import get_bench_warnings, load_bench_config

        cfg = load_bench_config(bench)
        _ok(f"Bench loaded: '{cfg.bench.name}' ({len(cfg.nodes)} nodes)")

        if cfg.defaults and cfg.defaults.node:
            _info(f"Default node: {cfg.defaults.node}")

        for node_name, node_cfg in cfg.nodes.items():
            _info(
                f"Node '{node_name}': "
                f"kind={node_cfg.kind} "
                f"transports={len(node_cfg.transports)} "
                f"gpio={len(node_cfg.gpio)} "
                f"flash={'yes' if node_cfg.flash else 'no'}"
            )

        warns = get_bench_warnings(cfg)
        for w in warns:
            _warn(w)

    if suite:
        from benchci.config.suite import load_suite_config

        suite_cfg = load_suite_config(suite)
        _ok(f"Suite loaded: '{suite_cfg.suite.name}' ({len(suite_cfg.tests)} tests)")


@app.command(
    help=(
        "Run a BenchCI test suite locally, through a remote agent, or through the cloud "
        "control plane. Use exactly one execution mode: local (default), --agent, or --cloud."
    )
)
def run(
    bench: str | None = typer.Option(
        None,
        "--bench",
        "-b",
        help=(
            "Path to bench config YAML. Required for local runs and for remote uploaded-bench "
            "runs sent to an agent."
        ),
    ),
    bench_id: str | None = typer.Option(
        None,
        "--bench-id",
        help=(
            "Registered bench identifier for agent mode, or exact cloud bench identifier for "
            "cloud mode."
        ),
    ),
    suite: str = typer.Option(
        ...,
        "--suite",
        "-s",
        help="Path to suite config YAML to execute.",
    ),
    artifact: str | None = typer.Option(
        None,
        "--artifact",
        "-a",
        help="Firmware artifact override (.elf, .hex, .bin depending on the flash backend).",
    ),
    skip_flash: bool = typer.Option(
        False,
        "--skip-flash",
        help="Skip all flash steps and run tests against the board's current firmware.",
    ),
    verbose: bool = typer.Option(
        False,
        "--verbose",
        help="Show additional failure context and end-of-run summaries.",
    ),
    agent: str | None = typer.Option(
        None,
        "--agent",
        help="Remote BenchCI Agent base URL for agent-managed runs.",
    ),
    token: str | None = typer.Option(
        None,
        "--token",
        help="BenchCI Agent authentication token. Defaults to BENCHCI_AGENT_TOKEN if set.",
    ),
    cloud: bool = typer.Option(
        False,
        "--cloud",
        help="Submit the run through the BenchCI backend cloud control plane.",
    ),
    tag: list[str] = typer.Option(
        None,
        "--tag",
        help="Required cloud bench tag. Repeat this option to require multiple tags.",
    ),
    transport: list[str] = typer.Option(
        None,
        "--transport",
        help="Required cloud transport backend. Repeat this option for multiple transports.",
    ),
    flash_backend: list[str] = typer.Option(
        None,
        "--flash-backend",
        help="Required cloud flash backend. Repeat this option for multiple backends.",
    ),
    has_gpio: bool | None = typer.Option(
        None,
        "--has-gpio/--no-has-gpio",
        help="Require or forbid GPIO capability when selecting a cloud bench.",
    ),
    has_power: bool | None = typer.Option(
        None,
        "--has-power/--no-has-power",
        help="Require or forbid power control capability when selecting a cloud bench.",
    ),
    min_node_count: int | None = typer.Option(
        None,
        "--min-node-count",
        help="Minimum node count required when selecting a cloud bench.",
    ),
):
    if cloud and agent:
        raise typer.BadParameter("Use either --cloud or --agent, not both")

    try:
        entitled_session = _require_entitled_workspace("run execution")
    except Exception as exc:
        _fail(str(exc))
        raise SystemExit(1)

    if bench and bench_id and not cloud:
        raise typer.BadParameter("Use either --bench or --bench-id, not both")

    if cloud:
        from benchci.cloud.client import download_artifacts, submit_cloud_run, wait_run

        if bench:
            raise typer.BadParameter(
                "--bench is not used in cloud mode; use --bench-id or capability filters instead"
            )

        requirements: dict[str, object] = {}
        if tag:
            requirements["tags"] = list(tag)
        if transport:
            requirements["transports"] = list(transport)
        if flash_backend:
            requirements["flash_backends"] = list(flash_backend)
        if has_gpio is not None:
            requirements["has_gpio"] = has_gpio
        if has_power is not None:
            requirements["has_power"] = has_power
        if min_node_count is not None:
            requirements["min_node_count"] = min_node_count

        if not bench_id and not requirements:
            raise typer.BadParameter(
                "Cloud runs require --bench-id or at least one cloud selector such as --tag, "
                "--transport, --flash-backend, --has-gpio, --has-power, or --min-node-count"
            )

        api_base_url = entitled_session.get("api_base_url") or get_api_base_url()
        access_token = entitled_session.get("access_token")
        workspace_id = entitled_session.get("active_workspace_id")
        if not access_token:
            _fail("BenchCI session is missing an access token. Run 'benchci login' again.")
            raise SystemExit(1)

        _info(f"Submitting cloud run to backend: {api_base_url}")
        _info(f"Active workspace: {workspace_id}")
        if bench_id:
            _info(f"Requested bench: {bench_id}")
        elif requirements:
            _info(f"Cloud requirements: {json.dumps(requirements, sort_keys=True)}")

        res = submit_cloud_run(
            api_base_url=api_base_url,
            access_token=access_token,
            workspace_id=workspace_id,
            suite_path=suite,
            artifact_path=artifact,
            bench_id=bench_id,
            requirements=requirements or None,
            skip_flash=skip_flash,
            verbose=verbose,
        )

        run_id = res.get("run_id")
        if not run_id:
            _fail(f"Backend response missing run_id: {res}")
            raise SystemExit(1)

        _ok(f"Cloud run submitted: {run_id}")

        final = wait_run(
            api_base_url,
            run_id,
            access_token,
            workspace_id=workspace_id,
            poll_interval_s=1.0,
            timeout_s=1800.0,
            on_update=lambda payload: _emit_cloud_status(run_id, payload),
            on_event=_emit_cloud_event,
        )

        if final.get("status") in {"done", "failed"}:
            try:
                out_dir = Path("benchci-results")
                out_dir.mkdir(parents=True, exist_ok=True)
                zip_path = out_dir / f"cloud_{run_id}.zip"
                download_artifacts(
                    api_base_url=api_base_url,
                    run_id=run_id,
                    access_token=access_token,
                    workspace_id=workspace_id,
                    out_zip_path=zip_path,
                )
                _ok(f"Artifacts downloaded: {zip_path}")
            except Exception as exc:
                _warn(f"Run ended but artifact download failed: {exc}")

        _info(f"Run complete: status={final.get('status')} exit_code={final.get('exit_code')}")
        exit_code = final.get("exit_code")
        success = final.get("status") == "done" and exit_code is not None and int(exit_code) == 0
        raise SystemExit(0 if success else 1)

    if agent:
        from benchci.agent.client import download_artifacts, submit_registered_run, submit_run, wait_run

        agent_token = token or os.getenv("BENCHCI_AGENT_TOKEN")

        if bench_id:
            _info(f"Submitting registered-bench run to agent: {agent}")
            _info(f"Registered bench: {bench_id}")

            res = submit_registered_run(
                agent_url=agent,
                bench_id=bench_id,
                suite_path=suite,
                artifact_path=artifact,
                skip_flash=skip_flash,
                verbose=verbose,
                token=agent_token,
            )
        else:
            if not bench:
                raise typer.BadParameter(
                    "Remote uploaded-bench mode requires --bench, or use --bench-id for registered benches"
                )

            _info(f"Submitting uploaded-bench run to agent: {agent}")

            res = submit_run(
                agent_url=agent,
                bench_path=bench,
                suite_path=suite,
                artifact_path=artifact,
                skip_flash=skip_flash,
                verbose=verbose,
                token=agent_token,
            )

        run_id = res.get("run_id")
        if not run_id:
            _fail(f"Agent response missing run_id: {res}")
            raise SystemExit(1)

        _ok(f"Run submitted: {run_id}")

        def _on_update(r: dict) -> None:
            status = r.get("status")
            qd = r.get("queue_depth")
            ec = r.get("exit_code")

            if status == "queued":
                _info(f"{run_id} queued (queue depth={qd})")
            elif status == "preparing":
                _info(f"{run_id} preparing")
            elif status == "running":
                _info(f"{run_id} running")
            elif status == "uploading_artifacts":
                _info(f"{run_id} packaging artifacts")
            elif status == "done":
                _ok(f"{run_id} finished successfully (exit_code={ec})")
            elif status == "failed":
                _fail(f"{run_id} failed: {r.get('error')} (exit_code={ec})")

        final = wait_run(
            agent,
            run_id,
            token=agent_token,
            poll_interval_s=1.0,
            timeout_s=1800.0,
            on_update=_on_update,
        )

        if final.get("status") in {"done", "failed"}:
            try:
                out_dir = Path("benchci-results")
                out_dir.mkdir(parents=True, exist_ok=True)
                zip_path = out_dir / f"agent_{run_id}.zip"
                download_artifacts(
                    agent_url=agent,
                    run_id=run_id,
                    out_zip_path=zip_path,
                    token=agent_token,
                )
                _ok(f"Artifacts downloaded: {zip_path}")
            except Exception as exc:
                _warn(f"Run ended but artifact download failed: {exc}")

        _info(f"Run complete: status={final.get('status')} exit_code={final.get('exit_code')}")
        success = final.get("status") == "done" and int(final.get("exit_code", 1)) == 0
        raise SystemExit(0 if success else 1)

    if bench_id:
        raise typer.BadParameter("--bench-id can only be used together with --agent or --cloud")

    if not bench:
        raise typer.BadParameter("Local runs require --bench")

    _info("Running tests locally")
    if verbose:
        _info("Verbose logging enabled")

    raise SystemExit(
        run_local(
            bench_path=bench,
            suite_path=suite,
            artifact_path=artifact,
            skip_flash=skip_flash,
            verbose=verbose,
        )
    )


@app.command(
    help="Run environment, connectivity, and bench diagnostics for local and remote setups."
)
def doctor(
    port: str | None = typer.Option(
        None,
        "--port",
        help="Serial port to probe during diagnostics, for example /dev/ttyUSB0 or COM3.",
    ),
    baud: int = typer.Option(
        115200,
        "--baud",
        help="Baud rate to use when probing the serial port.",
    ),
    bench: str | None = typer.Option(
        None,
        "--bench",
        "-b",
        help="Path to bench config YAML to validate during diagnostics.",
    ),
    agent: str | None = typer.Option(
        None,
        "--agent",
        help="Remote BenchCI Agent URL to health-check.",
    ),
    token: str | None = typer.Option(
        None,
        "--token",
        help="BenchCI Agent authentication token for authenticated health checks.",
    ),
    json_output: bool = typer.Option(
        False,
        "--json",
        help="Print machine-readable JSON instead of human-readable diagnostics.",
    ),
    export: str | None = typer.Option(
        None,
        "--export",
        help="Write a diagnostics ZIP bundle to this path.",
    ),
):
    raise SystemExit(
        run_doctor(
            port=port,
            baud=baud,
            bench=bench,
            agent=agent,
            agent_token=token or os.getenv("BENCHCI_AGENT_TOKEN"),
            json_output=json_output,
            export=export,
        )
    )

@app.command(
    help="Run a local BenchCI demo without hardware or login."
)
def demo(
    open_dashboard: bool = typer.Option(
        False,
        "--open-dashboard",
        help="Open a local HTML report after the demo run completes.",
    ),
    verbose: bool = typer.Option(
        False,
        "--verbose",
        help="Show additional logs during demo execution.",
    ),
):
    from benchci.commands.demo import run_demo
    raise SystemExit(run_demo(open_dashboard=open_dashboard, verbose=verbose))

@workspace_app.command("list", help="List workspaces available to the current user.")
def workspace_list(
    json_output: bool = typer.Option(False, "--json", help="Print machine-readable JSON instead of formatted text."),
):
    try:
        session = _require_valid_session()
    except Exception as exc:
        _fail(str(exc))
        raise SystemExit(1)

    payload = {
        "active_workspace_id": session.get("active_workspace_id"),
        "active_workspace_name": session.get("active_workspace_name"),
        "active_workspace_role": session.get("active_workspace_role"),
        "workspaces": session.get("workspaces", []),
    }

    if json_output:
        typer.echo(json.dumps(payload, indent=2))
        raise SystemExit(0)

    active_id = session.get("active_workspace_id")
    for ws in session.get("workspaces", []):
        marker = "*" if ws.get("workspace_id") == active_id else " "
        typer.echo(f"{marker} {ws.get('workspace_id')}  {ws.get('workspace_name')}  role={ws.get('role')}  status={ws.get('status')}")


@workspace_app.command("use", help="Switch the active workspace used for cloud operations.")
def workspace_use(workspace_id: str = typer.Argument(..., help="Workspace identifier to activate.")):
    session = load_session()
    if not session:
        _fail("No BenchCI session found. Run 'benchci login' first.")
        raise SystemExit(1)

    try:
        updated = set_active_workspace(session, workspace_id)
        save_session(updated)
    except Exception as exc:
        _fail(str(exc))
        raise SystemExit(1)

    _ok(f"Active workspace set to {updated.get('active_workspace_name')} ({updated.get('active_workspace_id')})")


@benches_app.command(
    "list",
    help="List cloud benches accessible to the current authenticated user."
)
def benches_list(
    json_output: bool = typer.Option(
        False,
        "--json",
        help="Print machine-readable JSON instead of formatted text.",
    )
):
    from benchci.cloud.client import list_benches

    try:
        api_base_url, access_token, workspace_id = _require_cloud_session()
        benches = list_benches(api_base_url, access_token, workspace_id=workspace_id)
    except Exception as exc:
        _fail(str(exc))
        raise SystemExit(1)

    if json_output:
        typer.echo(json.dumps(benches, indent=2))
        raise SystemExit(0)

    if not benches:
        _warn("No cloud benches available")
        raise SystemExit(0)

    for bench in benches:
        typer.echo("")
        typer.echo(f"{bench.get('bench_id')}")
        typer.echo(f"  name: {bench.get('name')}")
        typer.echo(f"  status: {bench.get('status')}")
        typer.echo(f"  agent: {bench.get('agent_id')}")
        tags = ", ".join(bench.get("tags", [])) or "<none>"
        typer.echo(f"  tags: {tags}")
        caps = bench.get("capabilities", {})
        typer.echo(
            "  capabilities: "
            f"transports={caps.get('transports', [])} "
            f"flash_backends={caps.get('flash_backends', [])} "
            f"has_gpio={caps.get('has_gpio')} "
            f"has_power={caps.get('has_power')} "
            f"node_count={caps.get('node_count')}"
        )


@benches_app.command(
    "show",
    help="Show details for a specific cloud bench."
)
def benches_show(
    bench_id: str = typer.Argument(..., help="Cloud bench identifier to inspect."),
    json_output: bool = typer.Option(
        False,
        "--json",
        help="Print machine-readable JSON instead of formatted text.",
    ),
):
    from benchci.cloud.client import get_bench

    try:
        api_base_url, access_token, workspace_id = _require_cloud_session()
        bench = get_bench(api_base_url, bench_id, access_token, workspace_id=workspace_id)
    except Exception as exc:
        _fail(str(exc))
        raise SystemExit(1)

    if json_output:
        typer.echo(json.dumps(bench, indent=2))
        raise SystemExit(0)

    typer.echo(f"bench_id: {bench.get('bench_id')}")
    typer.echo(f"name: {bench.get('name')}")
    typer.echo(f"status: {bench.get('status')}")
    typer.echo(f"agent_id: {bench.get('agent_id')}")
    typer.echo(f"description: {bench.get('description')}")
    typer.echo(f"tags: {', '.join(bench.get('tags', [])) or '<none>'}")
    typer.echo(f"node_names: {', '.join(bench.get('node_names', [])) or '<none>'}")
    typer.echo("capabilities:")
    caps = bench.get("capabilities", {})
    typer.echo(f"  transports: {caps.get('transports', [])}")
    typer.echo(f"  flash_backends: {caps.get('flash_backends', [])}")
    typer.echo(f"  has_gpio: {caps.get('has_gpio')}")
    typer.echo(f"  has_power: {caps.get('has_power')}")
    typer.echo(f"  node_count: {caps.get('node_count')}")


@runs_app.command(
    "list",
    help="List cloud runs submitted through the BenchCI backend."
)
def runs_list(
    json_output: bool = typer.Option(
        False,
        "--json",
        help="Print machine-readable JSON instead of formatted text.",
    )
):
    from benchci.cloud.client import list_runs

    try:
        api_base_url, access_token, workspace_id = _require_cloud_session()
        runs = list_runs(api_base_url, access_token, workspace_id=workspace_id)
    except Exception as exc:
        _fail(str(exc))
        raise SystemExit(1)

    if json_output:
        typer.echo(json.dumps(runs, indent=2))
        raise SystemExit(0)

    if not runs:
        _warn("No cloud runs found")
        raise SystemExit(0)

    for run in runs:
        typer.echo(
            f"{run.get('run_id')} "
            f"status={run.get('status')} "
            f"bench={run.get('assigned_bench_id') or run.get('requested_bench_id')} "
            f"agent={run.get('assigned_agent_id')} "
            f"exit_code={run.get('exit_code')}"
        )


@runs_app.command(
    "show",
    help="Show detailed status for a specific cloud run."
)
def runs_show(
    run_id: str = typer.Argument(..., help="Cloud run identifier to inspect."),
    json_output: bool = typer.Option(
        False,
        "--json",
        help="Print machine-readable JSON instead of formatted text.",
    ),
):
    from benchci.cloud.client import get_run

    try:
        api_base_url, access_token, workspace_id = _require_cloud_session()
        run = get_run(api_base_url, run_id, access_token, workspace_id=workspace_id)
    except Exception as exc:
        _fail(str(exc))
        raise SystemExit(1)

    if json_output:
        typer.echo(json.dumps(run, indent=2))
        raise SystemExit(0)

    for key in [
        "run_id",
        "status",
        "requested_bench_id",
        "assigned_bench_id",
        "assigned_agent_id",
        "exit_code",
        "error",
        "created_at",
        "started_at",
        "finished_at",
    ]:
        typer.echo(f"{key}: {run.get(key)}")


@runs_app.command(
    "events",
    help="Show the event timeline for a specific cloud run."
)
def runs_events(
    run_id: str = typer.Argument(..., help="Cloud run identifier whose events will be shown."),
    json_output: bool = typer.Option(
        False,
        "--json",
        help="Print machine-readable JSON instead of formatted text.",
    ),
):
    from benchci.cloud.client import get_run_events

    try:
        api_base_url, access_token, workspace_id = _require_cloud_session()
        payload = get_run_events(api_base_url, run_id, access_token, workspace_id=workspace_id)
    except Exception as exc:
        _fail(str(exc))
        raise SystemExit(1)

    if json_output:
        typer.echo(json.dumps(payload, indent=2))
        raise SystemExit(0)

    typer.echo(f"run_id: {payload.get('run_id')}")
    typer.echo(f"status: {payload.get('status')}")
    for event in payload.get("events", []):
        typer.echo(
            f"{event.get('timestamp')} {event.get('event_type')} "
            f"{(event.get('message') or '').rstrip()}"
        )


@agent_app.command(
    "serve",
    help="Start a local BenchCI Agent HTTP server."
)
def agent_serve(
    host: str = typer.Option(
        "0.0.0.0",
        "--host",
        help="Bind address for the agent HTTP server.",
    ),
    port: int = typer.Option(
        8080,
        "--port",
        help="Listen port for the agent HTTP server.",
    ),
):
    import uvicorn

    from benchci.agent.server import create_app

    _info(f"Starting BenchCI agent on {host}:{port}")

    uvicorn.run(create_app(), host=host, port=port, log_level="info")


@agent_app.command(
    "cloud",
    help="Run an agent in cloud-connected mode so it can poll the backend for work."
)
def agent_cloud(
    backend: str = typer.Option(
        ...,
        "--backend",
        help="BenchCI backend base URL.",
    ),
    token: str = typer.Option(
        ...,
        "--token",
        help="BenchCI backend-issued agent token.",
    ),
    bench: str = typer.Option(
        ...,
        "--bench",
        help="Path to bench.yaml describing the managed bench.",
    ),
    bench_id: str | None = typer.Option(
        None,
        "--bench-id",
        help="Override the cloud bench identifier reported by this agent.",
    ),
    tag: list[str] = typer.Option(
        None,
        "--tag",
        help="Bench tag to publish to the cloud scheduler. Repeatable.",
    ),
    agent_name: str | None = typer.Option(
        None,
        "--agent-name",
        help="Human-friendly agent name sent in heartbeats.",
    ),
    region: str | None = typer.Option(
        None,
        "--region",
        help="Region metadata sent in heartbeats.",
    ),
    poll_interval_s: float = typer.Option(
        2.0,
        "--poll-interval-s",
        help="Cloud polling interval in seconds.",
    ),
    machine_id: str | None = typer.Option(
        None,
        "--machine-id",
        help="Advanced: override the stable machine id used to bind this agent token.",
    ),
    machine_name: str | None = typer.Option(
        None,
        "--machine-name",
        help="Advanced: override the machine name sent to the backend.",
    ),
):
    try:
        _require_entitled_workspace("cloud agent execution")
    except Exception as exc:
        _fail(str(exc))
        raise SystemExit(1)

    from benchci.agent.cloud_client import get_machine_name, get_or_create_machine_id
    from benchci.agent.cloud_runner import CloudAgent

    resolved_machine_id = machine_id or get_or_create_machine_id()
    resolved_machine_name = machine_name or get_machine_name()

    _info(f"Cloud agent machine id: {resolved_machine_id}")
    _info(f"Cloud agent machine name: {resolved_machine_name}")

    CloudAgent(
        backend_url=backend,
        agent_token=token,
        bench_path=bench,
        bench_id=bench_id,
        bench_tags=list(tag or []),
        agent_name=agent_name,
        region=region,
        poll_interval_s=poll_interval_s,
        machine_id=resolved_machine_id,
        machine_name=resolved_machine_name,
    ).start()


def main():
    try:
        app()
    except typer.Exit:
        raise
    except KeyboardInterrupt:
        _warn("Cancelled by user.")
        raise SystemExit(130)
    except Exception as exc:
        _fail(_clean_error_message(exc))
        raise SystemExit(1)


def _clean_error_message(exc: Exception) -> str:
    text = str(exc).strip()

    if not text:
        return "BenchCI failed unexpectedly."

    blocked = [
        "Traceback",
        "File \"",
        "line ",
        "/site-packages/",
        "\\site-packages\\",
        "/benchci/",
        "\\benchci\\",
    ]

    if any(item in text for item in blocked):
        return "BenchCI failed unexpectedly."

    return text


if __name__ == "__main__":
    main()
