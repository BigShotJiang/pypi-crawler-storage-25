from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any


DEFAULT_API_URL = "https://api.benchci.dev"


def get_api_base_url() -> str:
    return os.getenv("BENCHCI_API_URL", DEFAULT_API_URL).rstrip("/")


def get_session_dir() -> Path:
    return Path.home() / ".benchci"


def get_session_path() -> Path:
    return get_session_dir() / "session.json"


def load_session() -> dict[str, Any] | None:
    path = get_session_path()
    if not path.exists():
        return None
    return json.loads(path.read_text(encoding="utf-8"))


def save_session(data: dict[str, Any]) -> Path:
    session_dir = get_session_dir()
    session_dir.mkdir(parents=True, exist_ok=True)
    path = get_session_path()
    path.write_text(json.dumps(data, indent=2), encoding="utf-8")
    return path


def clear_session() -> None:
    path = get_session_path()
    if path.exists():
        path.unlink()


def session_from_auth_response(api_base_url: str, payload: dict[str, Any]) -> dict[str, Any]:
    workspaces = list(payload.get("workspaces") or [])
    workspace_id = payload.get("workspace_id")
    workspace_name = payload.get("workspace_name")
    workspace_role = payload.get("workspace_role")

    if not workspace_id and workspaces:
        first = workspaces[0]
        workspace_id = first.get("workspace_id")
        workspace_name = first.get("workspace_name")
        workspace_role = first.get("role")

    return {
        "api_base_url": api_base_url.rstrip("/"),
        "access_token": payload.get("access_token"),
        "refresh_token": payload.get("refresh_token"),
        "expires_at": payload.get("expires_at"),
        "refresh_expires_at": payload.get("refresh_expires_at"),
        "user_id": payload.get("user_id"),
        "email": payload.get("email"),
        "display_name": payload.get("display_name"),
        "active_workspace_id": workspace_id,
        "active_workspace_name": workspace_name,
        "active_workspace_role": workspace_role,
        "active_workspace_plan": payload.get("workspace_plan"),
        "active_workspace_status": payload.get("workspace_status"),
        "active_workspace_entitled": payload.get("workspace_entitled"),
        "seat_limit": payload.get("seat_limit"),
        "bench_limit": payload.get("bench_limit"),
        "trial_ends_at": payload.get("trial_ends_at"),
        "workspaces": workspaces,
    }


def set_active_workspace(session: dict[str, Any], workspace_id: str) -> dict[str, Any]:
    workspaces = list(session.get("workspaces") or [])
    selected = next((w for w in workspaces if w.get("workspace_id") == workspace_id), None)
    if selected is None:
        known = ", ".join(w.get("workspace_id", "") for w in workspaces) or "<none>"
        raise RuntimeError(f"Unknown workspace_id '{workspace_id}'. Known workspaces: {known}")

    session = dict(session)
    session["active_workspace_id"] = selected.get("workspace_id")
    session["active_workspace_name"] = selected.get("workspace_name")
    session["active_workspace_role"] = selected.get("role")
    session["active_workspace_plan"] = selected.get("plan")
    session["active_workspace_status"] = selected.get("workspace_status")
    session["active_workspace_entitled"] = selected.get("workspace_entitled")
    session["seat_limit"] = selected.get("seat_limit")
    session["bench_limit"] = selected.get("bench_limit")
    session["trial_ends_at"] = selected.get("trial_ends_at")

    return session
