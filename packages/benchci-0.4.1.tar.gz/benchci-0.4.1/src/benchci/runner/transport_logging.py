from __future__ import annotations

import typer

from benchci.config.bench import (
    BenchConfig,
    TransportCan,
    TransportConfig,
    TransportModbusRtu,
    TransportModbusTcp,
    TransportUart,
)


def print_transport_config_summary(
    node_name: str,
    transport_name: str,
    transport: TransportConfig,
) -> None:
    """Print a short, user-facing summary of one configured transport."""
    typer.echo(f"[INFO] Node: {node_name}")
    typer.echo(f"[INFO] Transport name: {transport_name}")
    typer.echo(f"[INFO] Transport backend: {transport.backend}")

    if isinstance(transport, TransportUart):
        typer.echo(f"[INFO] Port: {transport.port}")
        typer.echo(f"[INFO] Baud: {transport.baud}")
        typer.echo(f"[INFO] Timeout: {transport.timeout_ms} ms")
        return

    if isinstance(transport, TransportModbusRtu):
        typer.echo(f"[INFO] Port: {transport.port}")
        typer.echo(f"[INFO] Baud: {transport.baud}")
        typer.echo(f"[INFO] Timeout: {transport.timeout_ms} ms")
        typer.echo(f"[INFO] Default slave: {transport.default_slave}")
        return

    if isinstance(transport, TransportModbusTcp):
        typer.echo(f"[INFO] Host: {transport.host}")
        typer.echo(f"[INFO] Port: {transport.port}")
        typer.echo(f"[INFO] Timeout: {transport.timeout_ms} ms")
        typer.echo(f"[INFO] Default slave: {transport.default_slave}")
        return

    if isinstance(transport, TransportCan):
        typer.echo(f"[INFO] Interface: {transport.interface}")
        typer.echo(f"[INFO] Bitrate: {transport.bitrate}")
        typer.echo(f"[INFO] Timeout: {transport.timeout_ms} ms")
        return

    typer.echo("[WARN] Unknown transport backend configuration")


def print_bench_transport_summary(bench: BenchConfig) -> None:
    """Print a bench-wide summary of all configured node transports."""
    if not bench.nodes:
        typer.echo("[WARN] Bench defines no nodes")
        return

    found_any = False

    for node_name, node_cfg in bench.nodes.items():
        if not node_cfg.transports:
            continue

        found_any = True
        typer.echo("")
        typer.echo(f"[INFO] Node '{node_name}' transports:")

        for transport_name, transport_cfg in node_cfg.transports.items():
            typer.echo(
                f"[INFO]   - {transport_name}: {transport_cfg.backend}"
            )

    if not found_any:
        typer.echo("[WARN] Bench defines no transports")