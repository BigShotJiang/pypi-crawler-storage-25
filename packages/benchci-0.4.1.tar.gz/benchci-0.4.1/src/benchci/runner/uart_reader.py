from __future__ import annotations

import threading
import time
from collections import deque
from datetime import datetime, timezone
from pathlib import Path
from typing import Deque

import serial  # type: ignore


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


class UartReader:
    """
    Background UART reader.

    Responsibilities:
        • Continuously read bytes from a pyserial Serial() object
        • Lazily write raw bytes to a log file only when data is actually received
        • Maintain a rolling in-memory decoded text buffer
        • Provide snapshot/tail access for test expectations

    The reader runs in a daemon thread and is safe for concurrent reads
    from the main test runner.
    """

    def __init__(
        self,
        ser: serial.Serial,
        log_path: Path,
        max_buffer_chars: int = 200_000,
        echo: bool = False,
    ):
        """
        Args:
            ser:
                Open pyserial Serial instance.

            log_path:
                Path where raw UART bytes should be written.

            max_buffer_chars:
                Maximum number of decoded characters retained
                in the in-memory rolling buffer.

            echo:
                If True, UART text will also be printed to stdout.
                Useful for interactive debugging.
        """
        self._ser = ser
        self._log_path = log_path
        self._max_buffer_chars = max_buffer_chars
        self._echo = echo

        self._buf: Deque[str] = deque()
        self._buf_len = 0
        self._lock = threading.Lock()

        self._stop = threading.Event()
        self._thread = threading.Thread(
            target=self._run,
            name="benchci-uart-reader",
            daemon=True,
        )

        self._fh = None
        self._logged_any_data = False
        self._session_started_at = _utc_now()

    def start(self) -> None:
        """Start the background UART reader thread."""
        self._thread.start()

    def stop(self) -> None:
        """Stop the reader thread and close the log file."""
        self._stop.set()
        self._thread.join(timeout=2.0)

        if self._fh:
            try:
                self._fh.flush()
                self._fh.close()
            finally:
                self._fh = None

    def _ensure_log_open(self) -> None:
        """Open the UART log lazily on first received data."""
        if self._fh is not None:
            return

        self._log_path.parent.mkdir(parents=True, exist_ok=True)
        self._fh = open(self._log_path, "ab", buffering=0)

        header = (
            f"# BenchCI UART transport log\n"
            f"# Session started: {self._session_started_at}\n"
            f"# Port: {getattr(self._ser, 'port', '<unknown>')}\n"
            f"# Baud: {getattr(self._ser, 'baudrate', '<unknown>')}\n"
            f"# Raw UART bytes follow below\n"
        ).encode("utf-8", errors="replace")

        try:
            self._fh.write(header)
        except Exception:
            pass

    def _append_text(self, s: str) -> None:
        """Append decoded text to the rolling buffer."""
        if not s:
            return

        with self._lock:
            self._buf.append(s)
            self._buf_len += len(s)

            while self._buf_len > self._max_buffer_chars and self._buf:
                old = self._buf.popleft()
                self._buf_len -= len(old)

    def snapshot_text(self) -> str:
        """Return the current UART buffer contents."""
        with self._lock:
            return "".join(self._buf)

    def tail(self, n_chars: int = 800) -> str:
        """Return the last N characters from the UART buffer."""
        text = self.snapshot_text()
        return text[-n_chars:]

    def is_alive(self) -> bool:
        """Return whether the background reader thread is still alive."""
        return self._thread.is_alive()

    def has_log_data(self) -> bool:
        """Return True if any UART data was received and written to log."""
        return self._logged_any_data

    def _run(self) -> None:
        """Main reader loop."""
        while not self._stop.is_set():
            try:
                data = self._ser.read(1024)  # obeys serial timeout
            except Exception:
                time.sleep(0.05)
                continue

            if not data:
                continue

            self._logged_any_data = True

            # Lazily create log only when real data is received
            self._ensure_log_open()

            if self._fh:
                try:
                    self._fh.write(data)
                except Exception:
                    pass

            try:
                text = data.decode(errors="replace")
            except Exception:
                text = ""

            if text:
                if self._echo:
                    print(text, end="", flush=True)

                self._append_text(text)