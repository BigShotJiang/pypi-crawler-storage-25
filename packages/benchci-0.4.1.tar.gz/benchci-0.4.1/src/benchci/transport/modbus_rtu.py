from __future__ import annotations

from pathlib import Path

from benchci.transport.modbus_base import ModbusBaseTransport


class ModbusRtuTransport(ModbusBaseTransport):
    def __init__(
        self,
        port: str,
        baud: int,
        timeout_ms: int,
        default_slave: int,
        log_path: Path | None = None,
    ):
        super().__init__(default_slave=default_slave, log_path=log_path)
        self._port = port
        self._baud = baud
        self._timeout_ms = timeout_ms
        self._backend_name = "modbus_rtu"

    def start(self) -> None:
        try:
            from pymodbus.client import ModbusSerialClient
        except Exception as e:
            raise RuntimeError(f"pymodbus is required for Modbus RTU transport: {e}") from e

        self._log(
            f"START backend=modbus_rtu port={self._port} baud={self._baud} "
            f"timeout_ms={self._timeout_ms} default_slave={self._default_slave}"
        )

        self._client = ModbusSerialClient(
            port=self._port,
            baudrate=self._baud,
            timeout=self._timeout_ms / 1000.0,
        )

        if not self._client.connect():
            self._log("ERROR connect_failed")
            raise RuntimeError(f"Failed to connect Modbus RTU transport on {self._port}")

        self._log("CONNECTED")