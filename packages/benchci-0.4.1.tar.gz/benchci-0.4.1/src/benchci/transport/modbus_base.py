from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path
from typing import Any


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")


class ModbusBaseTransport:
    def __init__(self, default_slave: int, log_path: Path | None = None):
        self._default_slave = default_slave
        self._log_path = log_path
        self._client: Any = None
        self._backend_name = "modbus"

    def _log(self, message: str) -> None:
        if self._log_path is None:
            return
        self._log_path.parent.mkdir(parents=True, exist_ok=True)
        with self._log_path.open("a", encoding="utf-8") as f:
            f.write(f"{_utc_now()} {message}\n")

    def _require_client(self) -> Any:
        if self._client is None:
            raise RuntimeError(f"{self._backend_name} transport is not started")
        return self._client

    def _slave(self, slave: int | None) -> int:
        return slave if slave is not None else self._default_slave

    def stop(self) -> None:
        if self._client is not None:
            try:
                self._client.close()
                self._log("STOP disconnected")
            except Exception as e:
                self._log(f"STOP error={type(e).__name__}: {e}")
            self._client = None

    def read_holding_registers(self, address: int, count: int, slave: int | None = None) -> list[int]:
        client = self._require_client()
        device_id = self._slave(slave)
        self._log(f"READ_HOLDING slave={device_id} address={address} count={count}")

        result = client.read_holding_registers(
            address=address,
            count=count,
            device_id=device_id,
        )

        if result.isError():
            self._log(
                f"READ_HOLDING_ERROR slave={device_id} address={address} count={count} result={result}"
            )
            raise RuntimeError(f"Modbus read_holding_registers failed: {result}")

        values = list(result.registers)
        self._log(f"READ_HOLDING_OK slave={device_id} address={address} values={values}")
        return values

    def write_single_register(self, address: int, value: int, slave: int | None = None) -> None:
        client = self._require_client()
        device_id = self._slave(slave)
        self._log(f"WRITE_REGISTER slave={device_id} address={address} value={value}")

        result = client.write_register(
            address=address,
            value=value,
            device_id=device_id,
        )

        if result.isError():
            self._log(
                f"WRITE_REGISTER_ERROR slave={device_id} address={address} value={value} result={result}"
            )
            raise RuntimeError(f"Modbus write_single_register failed: {result}")

        self._log(f"WRITE_REGISTER_OK slave={device_id} address={address} value={value}")

    def read_coils(self, address: int, count: int, slave: int | None = None) -> list[bool]:
        client = self._require_client()
        device_id = self._slave(slave)
        self._log(f"READ_COILS slave={device_id} address={address} count={count}")

        result = client.read_coils(
            address=address,
            count=count,
            device_id=device_id,
        )

        if result.isError():
            self._log(
                f"READ_COILS_ERROR slave={device_id} address={address} count={count} result={result}"
            )
            raise RuntimeError(f"Modbus read_coils failed: {result}")

        values = list(result.bits)[:count]
        self._log(f"READ_COILS_OK slave={device_id} address={address} values={values}")
        return values

    def write_single_coil(self, address: int, value: bool, slave: int | None = None) -> None:
        client = self._require_client()
        device_id = self._slave(slave)
        self._log(f"WRITE_COIL slave={device_id} address={address} value={value}")

        result = client.write_coil(
            address=address,
            value=value,
            device_id=device_id,
        )

        if result.isError():
            self._log(
                f"WRITE_COIL_ERROR slave={device_id} address={address} value={value} result={result}"
            )
            raise RuntimeError(f"Modbus write_single_coil failed: {result}")

        self._log(f"WRITE_COIL_OK slave={device_id} address={address} value={value}")