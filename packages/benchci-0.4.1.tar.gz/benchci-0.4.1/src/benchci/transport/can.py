from __future__ import annotations

import time
from datetime import datetime, timezone
from pathlib import Path


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")


def _parse_hex_bytes(data: str) -> bytes:
    cleaned = " ".join(data.strip().split())
    if not cleaned:
        return b""

    parts = cleaned.split(" ")
    out = bytearray()

    for part in parts:
        token = part.strip()
        if not token:
            continue
        if len(token) > 2:
            raise RuntimeError(f"Invalid CAN data byte '{token}' (must be 1 or 2 hex chars)")
        try:
            out.append(int(token, 16))
        except ValueError as exc:
            raise RuntimeError(f"Invalid CAN data byte '{token}'")

    if len(out) > 8:
        raise RuntimeError(f"Classic CAN supports at most 8 data bytes, got {len(out)}")

    return bytes(out)


def _format_hex_bytes(data: bytes) -> str:
    return " ".join(f"{b:02X}" for b in data)


class CanTransport:
    """python-can backed CAN transport."""

    def __init__(
        self,
        interface: str,
        bitrate: int,
        timeout_ms: int,
        log_path: Path | None = None,
    ):
        self._interface = interface
        self._bitrate = bitrate
        self._timeout_ms = timeout_ms
        self._log_path = log_path
        self._bus = None

    def _log(self, message: str) -> None:
        if self._log_path is None:
            return
        self._log_path.parent.mkdir(parents=True, exist_ok=True)
        with self._log_path.open("a", encoding="utf-8") as f:
            f.write(f"{_utc_now()} {message}\n")

    def start(self) -> None:
        try:
            import can  # type: ignore
        except Exception as exc:
            raise RuntimeError("python-can is required for CAN transport.")

        try:
            self._bus = can.Bus(
                interface="socketcan",
                channel=self._interface,
                bitrate=self._bitrate,
            )
        except TypeError:
            # Compatibility with older python-can signatures.
            self._bus = can.Bus(
                bustype="socketcan",
                channel=self._interface,
                bitrate=self._bitrate,
            )
        except Exception as exc:
            raise RuntimeError("Failed to open CAN interface.")

        self._log(
            f"START backend=can interface={self._interface} bitrate={self._bitrate} timeout_ms={self._timeout_ms}"
        )

    def stop(self) -> None:
        if self._bus is not None:
            try:
                shutdown = getattr(self._bus, "shutdown", None)
                if callable(shutdown):
                    shutdown()
                else:
                    close = getattr(self._bus, "close", None)
                    if callable(close):
                        close()
                self._log("STOP disconnected")
            except Exception as exc:
                self._log("STOP error")
            self._bus = None

    def _require_bus(self):
        if self._bus is None:
            raise RuntimeError("CAN transport is not started")
        return self._bus

    def send_frame(self, frame_id: int, data: str, extended: bool = False) -> None:
        bus = self._require_bus()

        try:
            import can  # type: ignore
        except Exception as exc:
            raise RuntimeError("python-can is required for CAN transport.")

        payload = _parse_hex_bytes(data)

        msg = can.Message(
            arbitration_id=frame_id,
            data=payload,
            is_extended_id=extended,
        )

        try:
            bus.send(msg)
        except Exception as exc:
            raise RuntimeError("Failed to send CAN frame.")

        self._log(
            f"SEND id=0x{frame_id:X} extended={extended} dlc={len(payload)} data={_format_hex_bytes(payload)}"
        )

    def expect_frame(
        self,
        frame_id: int,
        data: str,
        within_ms: int,
        extended: bool = False,
    ) -> tuple[bool, str]:
        bus = self._require_bus()
        expected = _parse_hex_bytes(data)

        deadline = time.time() + (within_ms / 1000.0)
        last_seen = ""

        while time.time() < deadline:
            remaining = max(0.0, deadline - time.time())
            timeout = min(0.05, remaining)

            try:
                msg = bus.recv(timeout=timeout)
            except Exception as exc:
                raise RuntimeError("Failed while waiting for CAN frame.")

            if msg is None:
                continue

            actual_data = bytes(msg.data)
            last_seen = (
                f"id=0x{int(msg.arbitration_id):X} "
                f"extended={bool(msg.is_extended_id)} "
                f"data={_format_hex_bytes(actual_data)}"
            )

            self._log(
                f"RECV id=0x{int(msg.arbitration_id):X} "
                f"extended={bool(msg.is_extended_id)} "
                f"dlc={len(actual_data)} data={_format_hex_bytes(actual_data)}"
            )

            if (
                int(msg.arbitration_id) == frame_id
                and bool(msg.is_extended_id) == extended
                and actual_data == expected
            ):
                self._log(
                    f"EXPECT_OK id=0x{frame_id:X} extended={extended} data={_format_hex_bytes(expected)} within_ms={within_ms}"
                )
                return True, last_seen

        self._log(
            f"EXPECT_TIMEOUT id=0x{frame_id:X} extended={extended} data={_format_hex_bytes(expected)} within_ms={within_ms}"
        )
        return False, last_seen