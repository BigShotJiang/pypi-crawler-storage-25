from __future__ import annotations

import re
import time
from pathlib import Path

from benchci.runner.uart_reader import UartReader
from benchci.transport.base import TextTransport


class UartTextTransport(TextTransport):
    """UART-backed text transport."""

    def __init__(self, port: str, baud: int, timeout_ms: int, log_path: Path):
        self._port = port
        self._baud = baud
        self._timeout_ms = timeout_ms
        self._log_path = log_path

        self._ser = None
        self._reader = None

    def start(self) -> None:
        try:
            import serial  # pyserial
        except Exception as e:
            raise RuntimeError(f"pyserial is required for UART transport: {e}") from e

        self._ser = serial.Serial(
            port=self._port,
            baudrate=self._baud,
            timeout=self._timeout_ms / 1000.0,
        )
        self._reader = UartReader(self._ser, self._log_path)
        self._reader.start()

    def stop(self) -> None:
        if self._reader is not None:
            try:
                self._reader.stop()
            except Exception:
                pass
            self._reader = None

        if self._ser is not None:
            try:
                self._ser.close()
            except Exception:
                pass
            self._ser = None

    def send_text(self, text: str) -> None:
        if self._ser is None:
            raise RuntimeError("UART transport is not started")
        self._ser.write(text.encode())
        self._ser.flush()

    def expect_contains(self, substr: str, within_ms: int) -> tuple[bool, str]:
        if self._reader is None:
            raise RuntimeError("UART transport is not started")

        deadline = time.time() + within_ms / 1000.0
        while time.time() < deadline:
            buf = self._reader.snapshot_text()
            if substr in buf:
                return True, buf
            time.sleep(0.02)
        return False, self._reader.snapshot_text()

    def expect_regex(self, pattern: str, within_ms: int) -> tuple[bool, str]:
        if self._reader is None:
            raise RuntimeError("UART transport is not started")

        rx = re.compile(pattern)
        deadline = time.time() + within_ms / 1000.0
        while time.time() < deadline:
            buf = self._reader.snapshot_text()
            if rx.search(buf):
                return True, buf
            time.sleep(0.02)
        return False, self._reader.snapshot_text()

    def tail(self, n_chars: int = 800) -> str:
        if self._reader is None:
            return ""
        return self._reader.tail(n_chars)