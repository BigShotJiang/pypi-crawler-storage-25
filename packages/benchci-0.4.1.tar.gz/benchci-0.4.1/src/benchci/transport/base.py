from __future__ import annotations

from abc import ABC, abstractmethod


class TextTransport(ABC):
    """Abstract text-based transport used by the test runner."""

    @abstractmethod
    def start(self) -> None:
        """Open/start the transport."""
        raise NotImplementedError

    @abstractmethod
    def stop(self) -> None:
        """Stop/close the transport."""
        raise NotImplementedError

    @abstractmethod
    def send_text(self, text: str) -> None:
        """Send text to the device."""
        raise NotImplementedError

    @abstractmethod
    def expect_contains(self, substr: str, within_ms: int) -> tuple[bool, str]:
        """Wait until the given substring appears or timeout occurs."""
        raise NotImplementedError

    @abstractmethod
    def expect_regex(self, pattern: str, within_ms: int) -> tuple[bool, str]:
        """Wait until the regex matches or timeout occurs."""
        raise NotImplementedError

    @abstractmethod
    def tail(self, n_chars: int = 800) -> str:
        """Return recent received text."""
        raise NotImplementedError