from __future__ import annotations

from pathlib import Path

from benchci.transport.modbus_base import ModbusBaseTransport


class ModbusTcpTransport(ModbusBaseTransport):
    def __init__(
        self,
        host: str,
        port: int,
        timeout_ms: int,
        default_slave: int,
        log_path: Path | None = None,
    ):
        super().__init__(default_slave=default_slave, log_path=log_path)
        self._host = host
        self._port = port
        self._timeout_ms = timeout_ms
        self._backend_name = "modbus_tcp"

    def start(self) -> None:
        try:
            from pymodbus.client import ModbusTcpClient
        except Exception as e:
            raise RuntimeError(f"pymodbus is required for Modbus TCP transport: {e}") from e

        self._log(
            f"START backend=modbus_tcp host={self._host} port={self._port} "
            f"timeout_ms={self._timeout_ms} default_slave={self._default_slave}"
        )

        self._client = ModbusTcpClient(
            host=self._host,
            port=self._port,
            timeout=self._timeout_ms / 1000.0,
        )

        if not self._client.connect():
            self._log("ERROR connect_failed")
            raise RuntimeError(
                f"Failed to connect Modbus TCP transport on {self._host}:{self._port}"
            )

        self._log("CONNECTED")