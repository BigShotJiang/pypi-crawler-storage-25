from __future__ import annotations

from pathlib import Path

from benchci.config.bench import (
    BenchConfig,
    NodeConfig,
    TransportCan,
    TransportConfig,
    TransportModbusRtu,
    TransportModbusTcp,
    TransportUart,
)
from benchci.transport.can import CanTransport
from benchci.transport.modbus_rtu import ModbusRtuTransport
from benchci.transport.modbus_tcp import ModbusTcpTransport
from benchci.transport.uart import UartTextTransport


def _require_node(bench: BenchConfig, node_name: str) -> NodeConfig:
    node = bench.nodes.get(node_name)
    if node is None:
        known = ", ".join(sorted(bench.nodes.keys())) or "<none>"
        raise RuntimeError(f"Unknown node '{node_name}'. Known nodes: {known}")
    return node


def _require_transport(node: NodeConfig, node_name: str, transport_name: str) -> TransportConfig:
    transport = node.transports.get(transport_name)
    if transport is None:
        known = ", ".join(sorted(node.transports.keys())) or "<none>"
        raise RuntimeError(
            f"Unknown transport '{transport_name}' on node '{node_name}'. Known transports: {known}"
        )
    return transport


def create_transport_from_config(
    transport_cfg: TransportConfig,
    log_path: Path,
):
    if isinstance(transport_cfg, TransportUart):
        return UartTextTransport(
            port=transport_cfg.port,
            baud=transport_cfg.baud,
            timeout_ms=transport_cfg.timeout_ms,
            log_path=log_path,
        )

    if isinstance(transport_cfg, TransportModbusRtu):
        return ModbusRtuTransport(
            port=transport_cfg.port,
            baud=transport_cfg.baud,
            timeout_ms=transport_cfg.timeout_ms,
            default_slave=transport_cfg.default_slave,
            log_path=log_path,
        )

    if isinstance(transport_cfg, TransportModbusTcp):
        return ModbusTcpTransport(
            host=transport_cfg.host,
            port=transport_cfg.port,
            timeout_ms=transport_cfg.timeout_ms,
            default_slave=transport_cfg.default_slave,
            log_path=log_path,
        )

    if isinstance(transport_cfg, TransportCan):
        return CanTransport(
            interface=transport_cfg.interface,
            bitrate=transport_cfg.bitrate,
            timeout_ms=transport_cfg.timeout_ms,
            log_path=log_path,
        )

    raise RuntimeError(f"Unsupported transport config type: {type(transport_cfg).__name__}")


def create_transport(
    bench: BenchConfig,
    node_name: str,
    transport_name: str,
    log_path: Path,
):
    node = _require_node(bench, node_name)
    transport_cfg = _require_transport(node, node_name, transport_name)
    return create_transport_from_config(transport_cfg, log_path)


def get_transport_config(
    bench: BenchConfig,
    node_name: str,
    transport_name: str,
) -> TransportConfig:
    node = _require_node(bench, node_name)
    return _require_transport(node, node_name, transport_name)