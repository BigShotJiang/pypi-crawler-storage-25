from __future__ import annotations

import json
import time
import uuid
import webbrowser
import zipfile
from datetime import datetime, timezone
from pathlib import Path


APP_URL = "https://app.benchci.dev"
DOCS_URL = "https://docs.benchci.dev"


# ----------------------------
# Helpers
# ----------------------------

def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _write(path: Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")


def _line() -> None:
    print("=" * 80)


def _section(title: str) -> None:
    _line()
    print(title)
    _line()


def _ok_detail(message: str, details: dict[str, object] | None = None) -> None:
    print(f"[ OK ] {message}")
    for key, value in (details or {}).items():
        print(f"        {key}: {value}")


def _info(message: str) -> None:
    print(f"[INFO] {message}")


def _demo_tmp_path(run_id: str, suffix: str) -> str:
    return f"/tmp/benchci-demo-{run_id}/results/{suffix}"


def _format_duration(seconds: float) -> str:
    if seconds < 60:
        return f"{seconds:.2f}s"
    minutes = int(seconds // 60)
    remaining = int(seconds % 60)
    return f"{minutes}m {remaining}s"


# ----------------------------
# HTML (dashboard-like)
# ----------------------------

def _html(run: dict, events: list[dict]) -> str:
    status = run["status"]

    status_label = {
        "queued": "Queued",
        "preparing": "Preparing",
        "running": "Running",
        "uploading_artifacts": "Uploading",
        "done": "Passed",
        "failed": "Failed",
    }.get(status, status.title())

    status_class = {
        "done": "success",
        "failed": "failed",
        "running": "running",
        "queued": "queued",
        "preparing": "running",
        "uploading_artifacts": "running",
    }.get(status, "queued")

    duration_label = _format_duration(float(run["duration_seconds"]))

    timeline_rows = "\n".join(
        f"""
        <div class="timeline-row">
          <div class="timeline-rail">
            <span class="timeline-dot"></span>
            {"<span class='timeline-line'></span>" if i < len(events) - 1 else ""}
          </div>
          <div class="timeline-content">
            <div class="timeline-type">{e["event_type"].upper()}</div>
            <div class="timeline-message">{e.get("message", "—")}</div>
            <div class="muted small">{e["timestamp"]}</div>
          </div>
        </div>
        """
        for i, e in enumerate(events)
    )

    return f"""<!doctype html>
<html>
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>BenchCI Demo Run {run["run_id"]}</title>
<style>
:root {{
  --bg: #0f1015;
  --card: #111217;
  --card-soft: #101116;
  --border: #252731;
  --border-strong: #3b3e4a;
  --text: #f4f4f5;
  --muted: #a1a1aa;
  --muted-2: #71717a;
  --green: #6ee7b7;
  --green-bg: rgba(16, 185, 129, 0.14);
  --green-border: rgba(52, 211, 153, 0.35);
  --red: #fb7185;
  --red-bg: rgba(244, 63, 94, 0.14);
  --red-border: rgba(251, 113, 133, 0.35);
  --blue: #93c5fd;
  --blue-bg: rgba(59, 130, 246, 0.14);
  --blue-border: rgba(147, 197, 253, 0.35);
}}

* {{
  box-sizing: border-box;
}}

html {{
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-rendering: geometricPrecision;
}}

body {{
  margin: 0;
  font-family:
    Inter,
    ui-sans-serif,
    system-ui,
    -apple-system,
    BlinkMacSystemFont,
    "Segoe UI",
    Roboto,
    Helvetica,
    Arial,
    sans-serif;
  background: var(--bg);
  color: var(--text);
  font-size: 14px;
  line-height: 1.45;
}}

.page {{
  padding: 24px 32px;
}}

.topbar {{
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  gap: 24px;
  margin-bottom: 24px;
}}

h1 {{
  margin: 0;
  font-size: 34px;
  line-height: 1.05;
  letter-spacing: -0.04em;
  font-weight: 800;
}}

.subtitle {{
  margin-top: 8px;
  color: var(--muted);
  font-size: 16px;
  font-weight: 500;
}}

.top-actions {{
  display: flex;
  gap: 12px;
  align-items: center;
}}

.search {{
  min-width: 300px;
  height: 48px;
  border: 1px solid var(--border);
  border-radius: 18px;
  background: #0c0d12;
  color: var(--muted);
  display: flex;
  align-items: center;
  padding: 0 18px;
  font-size: 15px;
  font-weight: 500;
}}

.grid {{
  display: grid;
  grid-template-columns: 1.1fr 0.9fr;
  gap: 24px;
}}

.card {{
  background: var(--card);
  border: 1px solid var(--border);
  border-radius: 24px;
  padding: 26px;
  min-height: 300px;
}}

.card h2 {{
  margin: 0;
  font-size: 25px;
  line-height: 1.1;
  letter-spacing: -0.035em;
  font-weight: 800;
}}

.card-desc {{
  color: var(--muted);
  font-size: 15px;
  font-weight: 500;
  margin: 14px 0 26px;
}}

.filters {{
  display: flex;
  gap: 10px;
  margin-bottom: 18px;
}}

.fake-select {{
  border: 1px solid var(--border);
  background: #0c0d12;
  color: var(--text);
  border-radius: 14px;
  padding: 11px 18px;
  font-size: 14px;
  font-weight: 600;
}}

.list-card {{
  border: 1px solid var(--border);
  border-radius: 22px;
  padding: 18px;
  background: var(--card-soft);
  margin-bottom: 14px;
}}

.list-card.selected {{
  border-color: var(--border-strong);
}}

.list-card-head {{
  display: flex;
  gap: 14px;
  align-items: center;
  margin-bottom: 12px;
}}

.badge {{
  display: inline-flex;
  align-items: center;
  gap: 7px;
  border-radius: 999px;
  padding: 6px 11px;
  font-size: 13px;
  line-height: 1;
  font-weight: 800;
}}

.badge::before {{
  content: "✓";
  width: 14px;
  height: 14px;
  border: 1.5px solid currentColor;
  border-radius: 999px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  font-size: 9px;
  line-height: 1;
}}

.badge.success {{
  color: var(--green);
  background: var(--green-bg);
  border: 1px solid var(--green-border);
}}

.badge.failed {{
  color: var(--red);
  background: var(--red-bg);
  border: 1px solid var(--red-border);
}}

.badge.running,
.badge.queued {{
  color: var(--blue);
  background: var(--blue-bg);
  border: 1px solid var(--blue-border);
}}

.mono {{
  font-family:
    ui-monospace,
    SFMono-Regular,
    Menlo,
    Monaco,
    Consolas,
    "Liberation Mono",
    monospace;
  font-size: 16px;
  letter-spacing: 0.02em;
}}

.run-title {{
  font-size: 16px;
  font-weight: 650;
  margin-bottom: 6px;
}}

.muted {{
  color: var(--muted);
}}

.small {{
  font-size: 13px;
}}

.detail-title {{
  display: flex;
  align-items: center;
  gap: 14px;
  margin: 34px 0 16px;
}}

.detail-meta-grid {{
  display: grid;
  grid-template-columns: 1fr 1fr;
  column-gap: 26px;
  row-gap: 10px;
  font-size: 14px;
  margin-bottom: 18px;
}}

.detail-meta-grid span {{
  color: var(--muted);
  font-weight: 700;
}}

.actions {{
  display: flex;
  gap: 12px;
  margin: 18px 0 24px;
  flex-wrap: wrap;
}}

.button {{
  border: 1px solid var(--border);
  background: #0d0e13;
  color: var(--text);
  border-radius: 15px;
  padding: 11px 18px;
  font-size: 14px;
  font-weight: 700;
  text-decoration: none;
  cursor: pointer;
  display: inline-flex;
  align-items: center;
  gap: 8px;
}}

.button.primary {{
  color: #0f1015;
  background: #e4e4e7;
  border-color: #e4e4e7;
}}

.button.disabled {{
  color: var(--muted-2);
  cursor: default;
}}

.sub-card {{
  border: 1px solid var(--border);
  border-radius: 22px;
  padding: 18px 20px;
  margin-top: 22px;
  background: var(--card-soft);
}}

.sub-card-title {{
  font-size: 16px;
  line-height: 1.2;
  font-weight: 800;
  margin-bottom: 12px;
}}

.success-text {{
  color: var(--green);
  font-size: 15px;
  font-weight: 600;
}}

.failure-text {{
  color: var(--red);
  font-size: 15px;
  font-weight: 600;
}}

.timeline {{
  margin-top: 14px;
}}

.timeline-row {{
  display: grid;
  grid-template-columns: 22px 1fr;
  gap: 14px;
  min-height: 74px;
}}

.timeline-rail {{
  display: flex;
  flex-direction: column;
  align-items: center;
}}

.timeline-dot {{
  width: 11px;
  height: 11px;
  border-radius: 999px;
  background: #ffffff;
  margin-top: 4px;
}}

.timeline-line {{
  width: 1px;
  flex: 1;
  background: var(--border);
  margin-top: 7px;
}}

.timeline-type {{
  color: var(--muted);
  font-size: 11px;
  font-weight: 900;
  letter-spacing: 0.16em;
  margin-bottom: 6px;
}}

.timeline-message {{
  font-size: 15px;
  font-weight: 600;
  line-height: 1.35;
  margin-bottom: 3px;
}}

.artifact-links {{
  display: grid;
  gap: 8px;
}}

.artifact-links a {{
  color: var(--text);
  text-decoration: none;
  border: 1px solid var(--border);
  border-radius: 12px;
  padding: 10px 12px;
  background: #0d0e13;
  font-size: 13px;
  font-weight: 600;
}}

.artifact-links a:hover {{
  border-color: var(--border-strong);
}}

.cta-card {{
  border: 1px solid var(--blue-border);
  background: var(--blue-bg);
}}

.cta-card .sub-card-title {{
  margin-bottom: 8px;
}}

.cta-actions {{
  display: flex;
  gap: 10px;
  margin-top: 14px;
  flex-wrap: wrap;
}}

.toast {{
  position: fixed;
  right: 24px;
  bottom: 24px;
  border: 1px solid var(--green-border);
  background: #0d1714;
  color: var(--green);
  border-radius: 14px;
  padding: 12px 14px;
  font-weight: 700;
  display: none;
}}

.toast.visible {{
  display: block;
}}

@media (max-width: 1100px) {{
  .grid {{
    grid-template-columns: 1fr;
  }}

  .search {{
    display: none;
  }}
}}
</style>
</head>
<body>
  <main class="page">
    <div class="topbar">
      <div>
        <h1>Runs</h1>
        <div class="subtitle">Investigate execution state, timeline, and run failures.</div>
      </div>
      <div class="top-actions">
        <div class="search">⌕ Search runs...</div>
        <button class="button" type="button" onclick="sharePage()">Share this page</button>
        <a class="button primary" href="{APP_URL}" target="_blank" rel="noreferrer">Register</a>
      </div>
    </div>

    <div class="grid">
      <section class="card">
        <h2>Run history</h2>
        <div class="card-desc">Inspect queue state, failures, and run progression.</div>

        <div class="filters">
          <div class="fake-select">All statuses</div>
          <div class="fake-select">All benches</div>
        </div>

        <div class="list-card selected">
          <div class="list-card-head">
            <span class="badge {status_class}">{status_label}</span>
            <span class="mono">{run["run_id"]}</span>
          </div>
          <div class="run-title">Bench: {run["assigned_bench_id"]}</div>
          <div class="muted small">Agent: {run["assigned_agent_id"]} · Created just now · Duration {duration_label}</div>
        </div>

        <div class="list-card">
          <div class="list-card-head">
            <span class="badge success">Passed</span>
            <span class="mono">demo_previous</span>
          </div>
          <div class="run-title">Bench: demo-bench</div>
          <div class="muted small">Agent: demo-agent · Created 4m ago · Duration 2.8s</div>
        </div>

        <div class="sub-card cta-card">
          <div class="sub-card-title">Run this on your hardware</div>
          <div class="muted small">
            Create a BenchCI workspace, connect an Agent, and run the same workflow from CI on your own devices.
          </div>
          <div class="cta-actions">
            <a class="button primary" href="{APP_URL}" target="_blank" rel="noreferrer">Register from app.benchci.dev</a>
            <a class="button" href="{DOCS_URL}" target="_blank" rel="noreferrer">Read docs</a>
          </div>
        </div>
      </section>

      <section class="card">
        <h2>Run detail</h2>
        <div class="card-desc">The page that proves the system is understandable.</div>

        <div class="detail-title">
          <span class="badge {status_class}">{status_label}</span>
          <span class="mono">{run["run_id"]}</span>
        </div>

        <div class="detail-meta-grid">
          <div><span>Bench:</span> {run["assigned_bench_id"]}</div>
          <div><span>Agent:</span> {run["assigned_agent_id"]}</div>
          <div><span>Started:</span> {run["started_at"]}</div>
          <div><span>Duration:</span> {duration_label}</div>
        </div>

        <div class="actions">
          <span class="button disabled">↻ Rerun</span>
          <a class="button" href="artifacts.zip">⇩ Artifacts</a>
          <button class="button" type="button" onclick="sharePage()">Share this page</button>
        </div>

        <div class="sub-card">
          <div class="sub-card-title">Failure classification</div>
          <div class="success-text">Healthy run</div>
          <div class="muted small">No explicit error message was reported for this run.</div>
        </div>

        <div class="sub-card">
          <div class="sub-card-title">Execution timeline</div>
          <div class="timeline">
            {timeline_rows}
          </div>
        </div>

        <div class="sub-card">
          <div class="sub-card-title">Artifacts</div>
          <div class="artifact-links">
            <a href="artifacts.zip">artifacts.zip</a>
            <a href="results.json">results.json</a>
            <a href="events.json">events.json</a>
            <a href="nodes/dut/flash.log">nodes/dut/flash.log</a>
            <a href="nodes/dut/transport-console.log">nodes/dut/transport-console.log</a>
            <a href="nodes/dut/gpio.log">nodes/dut/gpio.log</a>
            <a href="nodes/dut/transport-can.log">nodes/dut/transport-can.log</a>
            <a href="nodes/dut/transport-modbus.log">nodes/dut/transport-modbus.log</a>
          </div>
        </div>

        <div class="sub-card cta-card">
          <div class="sub-card-title">Ready to connect a real bench?</div>
          <div class="muted small">
            Register from <strong>app.benchci.dev</strong>, create or join a workspace, then connect your first Agent.
          </div>
          <div class="cta-actions">
            <a class="button primary" href="{APP_URL}" target="_blank" rel="noreferrer">Register from app.benchci.dev</a>
            <a class="button" href="{DOCS_URL}/quickstart.html" target="_blank" rel="noreferrer">Quickstart</a>
          </div>
        </div>
      </section>
    </div>
  </main>

  <div id="toast" class="toast">Page link copied</div>

  <script>
    async function sharePage() {{
      const shareText = "BenchCI demo run: " + window.location.href;

      if (navigator.share) {{
        try {{
          await navigator.share({{
            title: "BenchCI Demo Run",
            text: "BenchCI demo run report",
            url: window.location.href
          }});
          return;
        }} catch (err) {{
          // Fall through to clipboard.
        }}
      }}

      try {{
        await navigator.clipboard.writeText(shareText);
        showToast("Page link copied");
      }} catch (err) {{
        window.prompt("Copy this page path:", window.location.href);
      }}
    }}

    function showToast(message) {{
      const toast = document.getElementById("toast");
      toast.textContent = message;
      toast.classList.add("visible");
      window.setTimeout(() => toast.classList.remove("visible"), 2200);
    }}
  </script>
</body>
</html>
"""


# ----------------------------
# MAIN DEMO
# ----------------------------

def run_demo(open_dashboard: bool = False, verbose: bool = False) -> int:

    run_id = f"demo_{uuid.uuid4().hex[:8]}"
    start = time.time()
    started_at = _now()

    out = Path("benchci-results") / "demo" / run_id
    node = out / "nodes" / "dut"
    resources = out / "resources" / "dut_power"
    node.mkdir(parents=True, exist_ok=True)
    resources.mkdir(parents=True, exist_ok=True)

    events: list[dict[str, str]] = []

    def event(event_type: str, msg: str) -> None:
        events.append({
            "timestamp": _now(),
            "event_type": event_type,
            "message": msg,
        })

    _section("BenchCI demo run")
    _info("Mode: local demo")
    _info("No login required")
    _info("No hardware required")
    _info("This simulates the same flow used for real hardware runs")
    print("")

    event("RUN.STARTED", "Run started for bench 'demo-bench'")

    # Test 1
    _section("Test 1/7: boot_and_ready")

    _info("Starting step 1/8: power_set on node 'dut'")
    _info("Step 1: set power dut_power.main to False")
    _ok_detail("Power state updated", {
        "power_log_path": _demo_tmp_path(run_id, "resources/dut_power/power.log"),
        "observed_state": "None",
        "step_duration_s": "0.503",
    })
    event("POWER.SET", "Set dut_power.main to False")
    time.sleep(0.1)

    _info("Starting step 2/8: sleep_ms")
    _info("Step 2: sleep for 1000 ms")
    print("        step_duration_s: 1.000")
    event("SLEEP", "Waited 1000 ms")
    time.sleep(0.1)

    _info("Starting step 3/8: power_set on node 'dut'")
    _info("Step 3: set power dut_power.main to True")
    _ok_detail("Power state updated", {
        "power_log_path": _demo_tmp_path(run_id, "resources/dut_power/power.log"),
        "observed_state": "None",
        "step_duration_s": "0.482",
    })
    event("POWER.SET", "Set dut_power.main to True")
    time.sleep(0.1)

    _info("Starting step 4/8: sleep_ms")
    _info("Step 4: sleep for 1000 ms")
    print("        step_duration_s: 1.000")
    event("SLEEP", "Waited 1000 ms")
    time.sleep(0.1)

    _info("Starting step 5/8: flash on node 'dut'")
    print("")
    _section("FLASH: dut")
    _info("Backend: openocd")
    _info(f"Artifact: {_demo_tmp_path(run_id, 'firmware.elf')} (896848 bytes)")
    _ok_detail("Flash completed in 2.11s")
    _info(f"Flash log saved to: {_demo_tmp_path(run_id, 'nodes/dut/flash.log')}")
    print("        artifact: " + _demo_tmp_path(run_id, "firmware.elf"))
    print("        flash_log_path: " + _demo_tmp_path(run_id, "nodes/dut/flash.log"))
    print("        step_duration_s: 2.110")
    event("FLASH.STARTING", "Flashing demo firmware artifact 'demo-firmware.elf'")
    event("FLASH.DONE", "Firmware flashed successfully")
    time.sleep(0.1)

    _info("Starting step 6/8: expect_uart on node 'dut'")
    _info("Step 6: expect text on dut.console containing '[BOOT] OK' within 8000 ms")
    _ok_detail("Expectation satisfied", {
        "transport_log_path": _demo_tmp_path(run_id, "nodes/dut/transport-console.log"),
        "within_ms": 8000,
        "step_duration_s": "0.001",
    })
    event("UART.EXPECT.PASSED", "Found expected UART output '[BOOT] OK'")
    time.sleep(0.1)

    _info("Starting step 7/8: expect_uart on node 'dut'")
    _info("Step 7: expect text on dut.console containing 'SYSTEM READY' within 3000 ms")
    _ok_detail("Expectation satisfied", {
        "transport_log_path": _demo_tmp_path(run_id, "nodes/dut/transport-console.log"),
        "within_ms": 3000,
        "step_duration_s": "0.001",
    })
    event("UART.EXPECT.PASSED", "Found expected UART output 'SYSTEM READY'")
    time.sleep(0.1)

    _info("Starting step 8/8: expect_uart on node 'dut'")
    _info("Step 8: expect text on dut.console containing 'FW:BENCHCI_DEMO' within 3000 ms")
    _ok_detail("Expectation satisfied", {
        "transport_log_path": _demo_tmp_path(run_id, "nodes/dut/transport-console.log"),
        "within_ms": 3000,
        "step_duration_s": "0.001",
    })
    event("UART.EXPECT.PASSED", "Found expected UART output 'FW:BENCHCI_DEMO'")
    _ok_detail("Test passed in 6.21s")
    event("TEST.PASSED", "Test 'boot_and_ready' passed")
    time.sleep(0.1)

    # Test 2
    _section("Test 2/7: uart_console_ping")

    _info("Starting step 1/2: send_uart on node 'dut'")
    _info("Step 1: send UART text to dut.console: 'PING\\n'")
    _ok_detail("Text sent", {
        "transport_log_path": _demo_tmp_path(run_id, "nodes/dut/transport-console.log"),
        "step_duration_s": "0.411",
    })
    event("UART.SEND", "Sent 'PING' over transport 'console'")
    time.sleep(0.1)

    _info("Starting step 2/2: expect_uart on node 'dut'")
    _info("Step 2: expect text on dut.console containing 'PONG' within 1000 ms")
    _ok_detail("Expectation satisfied", {
        "transport_log_path": _demo_tmp_path(run_id, "nodes/dut/transport-console.log"),
        "within_ms": 1000,
        "step_duration_s": "0.001",
    })
    event("UART.EXPECT.PASSED", "Found expected UART output 'PONG'")
    _ok_detail("Test passed in 1.99s")
    event("TEST.PASSED", "Test 'uart_console_ping' passed")
    time.sleep(0.1)

    # Test 3
    _section("Test 3/7: gpio_ready")

    _info("Starting step 1/2: gpio_set on node 'dut'")
    _info("Step 1: set GPIO dut.reset_n to True")
    _ok_detail("GPIO state updated", {
        "gpio_log_path": _demo_tmp_path(run_id, "nodes/dut/gpio.log"),
        "step_duration_s": "0.084",
    })
    event("GPIO.SET", "Set dut.reset_n to True")

    _info("Starting step 2/2: gpio_expect on node 'dut'")
    _info("Step 2: expect GPIO dut.ready to be True within 3000 ms")
    _ok_detail("GPIO expectation satisfied", {
        "gpio_log_path": _demo_tmp_path(run_id, "nodes/dut/gpio.log"),
        "within_ms": 3000,
        "step_duration_s": "0.002",
    })
    event("GPIO.EXPECT.PASSED", "GPIO dut.ready reached True")
    _ok_detail("Test passed in 0.62s")
    event("TEST.PASSED", "Test 'gpio_ready' passed")
    time.sleep(0.1)

    # Test 4
    _section("Test 4/7: can_heartbeat")

    _info("Starting step 1/2: send_can on node 'dut'")
    _info("Step 1: send CAN frame on dut.bus id=0x123 data=[01 02 03 04]")
    _ok_detail("CAN frame sent", {
        "transport_log_path": _demo_tmp_path(run_id, "nodes/dut/transport-can.log"),
        "step_duration_s": "0.018",
    })
    event("CAN.SEND", "Sent CAN frame id=0x123")

    _info("Starting step 2/2: expect_can on node 'dut'")
    _info("Step 2: expect CAN frame on dut.bus id=0x321 within 1000 ms")
    _ok_detail("CAN expectation satisfied", {
        "transport_log_path": _demo_tmp_path(run_id, "nodes/dut/transport-can.log"),
        "within_ms": 1000,
        "step_duration_s": "0.004",
    })
    event("CAN.EXPECT.PASSED", "Observed expected CAN heartbeat")
    _ok_detail("Test passed in 0.44s")
    event("TEST.PASSED", "Test 'can_heartbeat' passed")
    time.sleep(0.1)

    # Test 5
    _section("Test 5/7: uart_status")

    _info("Starting step 1/2: send_uart on node 'dut'")
    _info("Step 1: send UART text to dut.console: 'STATUS\\n'")
    _ok_detail("Text sent", {
        "transport_log_path": _demo_tmp_path(run_id, "nodes/dut/transport-console.log"),
        "step_duration_s": "0.411",
    })
    event("UART.SEND", "Sent 'STATUS' over transport 'console'")

    _info("Starting step 2/2: expect_uart on node 'dut'")
    _info("Step 2: expect text on dut.console containing 'STATUS:OK' within 3000 ms")
    _ok_detail("Expectation satisfied", {
        "transport_log_path": _demo_tmp_path(run_id, "nodes/dut/transport-console.log"),
        "within_ms": 3000,
        "step_duration_s": "0.001",
    })
    event("UART.EXPECT.PASSED", "Found expected UART output 'STATUS:OK'")
    _ok_detail("Test passed in 2.10s")
    event("TEST.PASSED", "Test 'uart_status' passed")
    time.sleep(0.1)

    # Test 6
    _section("Test 6/7: uart1_path")

    _info("Starting step 1/3: send_uart on node 'dut'")
    _info("Step 1: send UART text to dut.console: 'UART1 TEST\\n'")
    _ok_detail("Text sent", {
        "transport_log_path": _demo_tmp_path(run_id, "nodes/dut/transport-console.log"),
        "step_duration_s": "0.394",
    })
    event("UART.SEND", "Sent 'UART1 TEST' over transport 'console'")

    _info("Starting step 2/3: expect_uart on node 'dut'")
    _info("Step 2: expect text on dut.uart1 containing 'UART1:TEST_OK' within 1000 ms")
    _ok_detail("Expectation satisfied", {
        "transport_log_path": _demo_tmp_path(run_id, "nodes/dut/transport-uart1.log"),
        "within_ms": 1000,
        "step_duration_s": "0.001",
    })
    event("UART.EXPECT.PASSED", "Found expected UART1 output 'UART1:TEST_OK'")

    _info("Starting step 3/3: sleep_ms")
    _info("Step 3: sleep for 1000 ms")
    print("        step_duration_s: 1.000")
    event("SLEEP", "Waited 1000 ms")
    _ok_detail("Test passed in 3.92s")
    event("TEST.PASSED", "Test 'uart1_path' passed")
    time.sleep(0.1)

    # Test 7
    _section("Test 7/7: modbus_fixed_registers")

    _info("Starting step 1/1: modbus_read_holding_registers on node 'dut'")
    _info("Step 1: read holding registers on dut.modbus (slave=1, address=16, count=2)")
    _ok_detail("Holding registers matched: [4660, 22136]", {
        "transport_log_path": _demo_tmp_path(run_id, "nodes/dut/transport-modbus.log"),
        "step_duration_s": "0.018",
    })
    event("MODBUS.READ.PASSED", "Holding registers matched: [4660, 22136]")
    _ok_detail("Test passed in 1.80s")
    event("TEST.PASSED", "Test 'modbus_fixed_registers' passed")

    _section("RESULT")
    _ok_detail("All tests passed (7/7)")
    _info(f"Results JSON saved to: {_demo_tmp_path(run_id, 'results.json')}")
    event("ARTIFACTS.PACKAGED", "Artifacts packaged successfully")
    event("RUN.FINISHED", "Run completed successfully")

    finished_at = _now()
    duration = round(time.time() - start, 2)

    run = {
        "run_id": run_id,
        "status": "done",
        "requested_bench_id": "demo-bench",
        "assigned_bench_id": "demo-bench",
        "assigned_agent_id": "demo-agent",
        "created_at": started_at,
        "started_at": started_at,
        "finished_at": finished_at,
        "duration_seconds": duration,
        "exit_code": 0,
        "error": None,
    }

    # logs
    _write(
        node / "flash.log",
        """FLASH: dut
[INFO] Backend: openocd
[INFO] Artifact: demo-firmware.elf (896848 bytes)
[ OK ] Flash completed in 2.11s
[INFO] Flash log saved to: nodes/dut/flash.log
""",
    )

    _write(
        node / "transport-console.log",
        """[BOOT] Demo firmware starting
[BOOT] OK
SYSTEM READY
FW:BENCHCI_DEMO
PING
PONG
STATUS
STATUS:OK
UART1 TEST
""",
    )

    _write(node / "transport-uart1.log", "UART1:TEST_OK\n")

    _write(
        node / "transport-can.log",
        """TX id=0x123 data=01 02 03 04
RX id=0x321 data=AA BB CC DD
""",
    )

    _write(
        node / "transport-modbus.log",
        """READ_HOLDING_REGISTERS slave=1 address=16 count=2
RESULT [4660, 22136]
""",
    )

    _write(
        node / "gpio.log",
        """GPIO reset_n=True
GPIO ready=True
""",
    )

    _write(
        resources / "power.log",
        """POWER dut_power.main=False
POWER dut_power.main=True
""",
    )

    # results.json and events.json
    _write(out / "results.json", json.dumps(run, indent=2))
    _write(out / "events.json", json.dumps({"run_id": run_id, "status": "done", "events": events}, indent=2))

    # zip artifacts
    with zipfile.ZipFile(out / "artifacts.zip", "w", compression=zipfile.ZIP_DEFLATED) as z:
        z.write(out / "results.json", "results.json")
        z.write(out / "events.json", "events.json")
        z.write(node / "flash.log", "nodes/dut/flash.log")
        z.write(node / "transport-console.log", "nodes/dut/transport-console.log")
        z.write(node / "transport-uart1.log", "nodes/dut/transport-uart1.log")
        z.write(node / "transport-can.log", "nodes/dut/transport-can.log")
        z.write(node / "transport-modbus.log", "nodes/dut/transport-modbus.log")
        z.write(node / "gpio.log", "nodes/dut/gpio.log")
        z.write(resources / "power.log", "resources/dut_power/power.log")

    # html
    report_path = out / "index.html"
    artifacts_path = out / "artifacts.zip"
    _write(report_path, _html(run, events))

    print("")
    _ok_detail("Demo passed")
    _info(f"Local results directory: {out.resolve()}")
    _info(f"Local dashboard report: {report_path.resolve()}")
    _info(f"Artifacts ZIP: {artifacts_path.resolve()}")
    _info(f"Share this demo page by sending this file: {report_path.resolve()}")
    _info(f"Register and connect your own bench: {APP_URL}")
    _info(f"Docs: {DOCS_URL}")

    if open_dashboard:
        webbrowser.open(report_path.resolve().as_uri())

    return 0
