from __future__ import annotations

import json
import platform
import shutil
import subprocess
import sys
import tempfile
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

import typer


@dataclass
class CheckResult:
    """Represents the result of a single diagnostic check."""

    name: str
    ok: bool
    details: str = ""
    required: bool = True
    hint: str | None = None

    def to_dict(self) -> dict:
        """Convert to a JSON-serializable dictionary."""
        return {
            "name": self.name,
            "ok": self.ok,
            "details": self.details,
            "required": self.required,
            "hint": self.hint,
        }


def _run_cmd(cmd: list[str], timeout_s: int = 5) -> tuple[int, str]:
    """Run a command and return (exit_code, combined_output)."""
    try:
        p = subprocess.run(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            timeout=timeout_s,
            check=False,
        )
        return p.returncode, (p.stdout or "").strip()
    except FileNotFoundError:
        return 127, "not found"
    except subprocess.TimeoutExpired:
        return 124, "timeout"


def _check_python(min_major: int = 3, min_minor: int = 11) -> CheckResult:
    """Verify Python version meets minimum requirement."""
    v = sys.version_info
    ok = (v.major, v.minor) >= (min_major, min_minor)
    return CheckResult(
        name="Python",
        ok=ok,
        details=f"{v.major}.{v.minor}.{v.micro} (need >= {min_major}.{min_minor})",
        required=True,
        hint="Install Python 3.11+ and ensure your environment uses it.",
    )


def _check_os() -> CheckResult:
    """Collect OS/platform info (informational only)."""
    return CheckResult(
        name="OS",
        ok=True,
        details=f"{platform.system()} {platform.release()} ({platform.machine()})",
        required=False,
    )


def _check_tool(
    exe_name: str,
    version_args: list[str] | None = None,
    required: bool = False,
    hint: str | None = None,
) -> CheckResult:
    """Check that an executable exists in PATH and optionally report its version."""
    path = shutil.which(exe_name)
    if not path:
        return CheckResult(
            name=f"Tool: {exe_name}",
            ok=False,
            details="not found in PATH",
            required=required,
            hint=hint,
        )

    details = f"found at {path}"
    if version_args:
        code, out = _run_cmd([exe_name, *version_args], timeout_s=5)
        if out:
            details += f" | {out.splitlines()[0][:200]}"
        elif code == 124:
            details += " | version check timeout"
        else:
            details += " | version check failed"
    return CheckResult(
        name=f"Tool: {exe_name}",
        ok=True,
        details=details,
        required=required,
    )


def _check_python_module(
    module_name: str,
    required: bool = False,
    hint: str | None = None,
) -> CheckResult:
    """Check whether a Python module can be imported."""
    try:
        __import__(module_name)
        return CheckResult(
            name=f"Python module: {module_name}",
            ok=True,
            details="import successful",
            required=required,
            hint=hint,
        )
    except Exception as e:
        return CheckResult(
            name=f"Python module: {module_name}",
            ok=False,
            details=f"import failed: {e}",
            required=required,
            hint=hint,
        )


def _list_serial_candidates() -> tuple[list[str], list[str]]:
    """Return (devices, pretty_lines) for detected serial ports."""
    sysname = platform.system().lower()
    try:
        from serial.tools import list_ports  # type: ignore

        ports = list(list_ports.comports())
        devices = [p.device for p in ports if p.device]
        pretty: list[str] = []
        for p in ports:
            dev = p.device or ""
            if not dev:
                continue
            desc = p.description or ""
            hwid = p.hwid or ""
            pretty.append(f"{dev} ({desc}) [{hwid}]".strip())
        if devices:
            return devices, pretty
    except Exception:
        pass

    if sysname == "windows":
        devices = [f"COM{i}" for i in range(1, 9)]
        return devices, devices

    dev = Path("/dev")
    candidates: list[Path] = []
    if sysname == "darwin":
        candidates += sorted(dev.glob("cu.*"))
        candidates += sorted(dev.glob("tty.*"))
    else:
        candidates += sorted(dev.glob("ttyUSB*"))
        candidates += sorted(dev.glob("ttyACM*"))

    devices: list[str] = []
    seen: set[str] = set()
    for p in candidates:
        sp = str(p)
        if sp not in seen:
            seen.add(sp)
            devices.append(sp)
    return devices, devices


def _check_serial_list() -> CheckResult:
    """List candidate UART ports (informational; not required)."""
    devices, pretty = _list_serial_candidates()
    if not devices:
        return CheckResult(
            name="UART ports",
            ok=False,
            details="no serial ports detected (OK on machines without USB devices)",
            required=False,
        )
    shown = ", ".join(pretty[:3])
    more = f" (+{len(devices) - 3} more)" if len(devices) > 3 else ""
    return CheckResult(
        name="UART ports",
        ok=True,
        details=f"found: {shown}{more}",
        required=False,
    )


def _test_uart_open(port: str, baud: int) -> CheckResult:
    """Attempt to open/close a UART port with pyserial."""
    try:
        import serial  # type: ignore
    except Exception as e:
        return CheckResult(
            name="UART open test",
            ok=False,
            details=f"pyserial import failed: {e}",
            required=True,
            hint="Install pyserial: pip install pyserial",
        )

    try:
        s = serial.Serial(port=port, baudrate=baud, timeout=0.2)
        s.close()
        return CheckResult(
            name="UART open test",
            ok=True,
            details=f"opened and closed {port} @ {baud}",
            required=True,
        )
    except Exception as e:
        return CheckResult(
            name="UART open test",
            ok=False,
            details=f"failed to open {port}: {e}",
            required=True,
            hint="Close programs using the port (screen/minicom/CubeIDE) and verify device permissions.",
        )


def _check_agent_health(agent_url: str, token: str | None = None) -> CheckResult:
    """Check that a BenchCI agent is reachable (GET /health)."""
    try:
        import httpx
    except Exception as e:
        return CheckResult(
            name="Agent health",
            ok=False,
            details=f"httpx missing: {e}",
            required=True,
            hint="Install httpx: pip install httpx",
        )

    url = agent_url.rstrip("/") + "/health"
    try:
        headers = {}
        if token:
            headers["Authorization"] = f"Bearer {token}"
        with httpx.Client(timeout=3.0) as client:
            r = client.get(url, headers=headers)
        if r.status_code == 200:
            return CheckResult(
                name="Agent health",
                ok=True,
                details=f"OK: {url}",
                required=True,
            )
        return CheckResult(
            name="Agent health",
            ok=False,
            details=f"{url} returned HTTP {r.status_code}",
            required=True,
            hint="Check agent URL, network, firewall, and that agent is running.",
        )
    except Exception as e:
        return CheckResult(
            name="Agent health",
            ok=False,
            details=f"failed to reach {url}: {e}",
            required=True,
            hint="Check agent URL, network connectivity, and firewall.",
        )


def _check_gpiochip_device(path_str: str) -> CheckResult:
    """Check whether a gpiochip path exists and looks usable."""
    p = Path(path_str)
    if not p.exists():
        return CheckResult(
            name=f"GPIO chip: {path_str}",
            ok=False,
            details="device path does not exist",
            required=True,
            hint="Verify the gpiochip path in bench.yaml and check that the kernel exposes the GPIO controller.",
        )

    if not p.is_char_device():
        return CheckResult(
            name=f"GPIO chip: {path_str}",
            ok=False,
            details="path exists but is not a character device",
            required=True,
            hint="Verify that this is a Linux gpiochip device such as /dev/gpiochip0.",
        )

    try:
        import gpiod  # type: ignore

        if hasattr(gpiod, "is_gpiochip_device"):
            try:
                is_chip = gpiod.is_gpiochip_device(path_str)
            except Exception:
                is_chip = True
        else:
            is_chip = True
    except Exception:
        is_chip = True

    if not is_chip:
        return CheckResult(
            name=f"GPIO chip: {path_str}",
            ok=False,
            details="device exists but does not appear to be a gpiochip device",
            required=True,
            hint="Use a Linux GPIO character device such as /dev/gpiochip0.",
        )

    return CheckResult(
        name=f"GPIO chip: {path_str}",
        ok=True,
        details="available",
        required=True,
    )


def _render_human(results: list[CheckResult]) -> str:
    """Render human-friendly doctor output."""
    lines: list[str] = []

    lines.append("BenchCI Doctor")
    lines.append("=" * 60)
    lines.append("")

    for r in results:
        status = "[ OK ]" if r.ok else "[FAIL]"
        req = "" if r.required else " (optional)"
        lines.append(f"{status} {r.name}{req}")
        if r.details:
            lines.append(f"       {r.details}")

    lines.append("")

    failed_required = [r for r in results if r.required and not r.ok]
    if failed_required:
        lines.append("Recommended actions")
        lines.append("-" * 60)
        for r in failed_required:
            if r.hint:
                lines.append(f"- {r.hint}")
        lines.append("")

    return "\n".join(lines)


def _maybe_pip_freeze() -> str:
    """Best-effort dependency snapshot for diagnostics export."""
    code, out = _run_cmd([sys.executable, "-m", "pip", "freeze"], timeout_s=10)
    if code == 0 and out:
        return out
    return "(pip freeze unavailable)"


def _write_export_zip(
    export_path: Path,
    payload: dict,
    human_text: str,
    bench_path: str | None,
    tool_outputs: dict[str, str],
) -> Path:
    """Write a diagnostics ZIP file for support/debugging."""
    export_path = export_path.expanduser().resolve()
    if export_path.suffix.lower() != ".zip":
        export_path = export_path.with_suffix(".zip")

    with tempfile.TemporaryDirectory(prefix="benchci-doctor-") as td:
        d = Path(td)

        (d / "doctor.json").write_text(json.dumps(payload, indent=2), encoding="utf-8")
        (d / "doctor.txt").write_text(human_text, encoding="utf-8")

        env_text = "\n".join(
            [
                f"python: {sys.version.replace(chr(10), ' ')}",
                f"platform: {platform.platform()}",
                f"cwd: {Path.cwd()}",
                f"time_utc: {payload.get('timestamp')}",
            ]
        )
        (d / "env.txt").write_text(env_text + "\n", encoding="utf-8")
        (d / "pip_freeze.txt").write_text(_maybe_pip_freeze() + "\n", encoding="utf-8")

        tools_lines: list[str] = []
        for k, v in tool_outputs.items():
            tools_lines.append(f"{k}:\n{v}\n")
        (d / "tools.txt").write_text("\n".join(tools_lines), encoding="utf-8")

        if bench_path:
            bp = Path(bench_path)
            if bp.exists():
                shutil.copy2(bp, d / "bench.yaml")

        base_name = str(export_path.with_suffix(""))
        shutil.make_archive(base_name, "zip", root_dir=str(d))

    return export_path


def run_doctor(
    port: Optional[str] = None,
    baud: int = 115200,
    bench: Optional[str] = None,
    agent: Optional[str] = None,
    agent_token: Optional[str] = None,
    json_output: bool = False,
    export: Optional[str] = None,
) -> int:
    """Run BenchCI environment diagnostics."""
    results: list[CheckResult] = [_check_python(), _check_os()]

    bench_cfg = None
    bench_path = bench

    if bench_path:
        try:
            from benchci.config.bench import get_bench_warnings, load_bench_config

            bench_cfg = load_bench_config(bench_path)
            results.append(
                CheckResult(
                    name="Bench config",
                    ok=True,
                    details=f"loaded '{bench_cfg.bench.name}' ({len(bench_cfg.nodes)} nodes)",
                    required=True,
                )
            )

            warns = get_bench_warnings(bench_cfg)
            for w in warns:
                results.append(
                    CheckResult(
                        name="Bench warning",
                        ok=True,
                        details=w,
                        required=False,
                    )
                )
        except Exception as e:
            results.append(
                CheckResult(
                    name="Bench config",
                    ok=False,
                    details=f"failed to load: {e}",
                    required=True,
                )
            )
            bench_cfg = None

    openocd_hint = "Install OpenOCD and ensure it is in PATH."
    cube_hint = "Install STM32CubeProgrammer and ensure STM32_Programmer_CLI is in PATH."
    jlink_hint = "Install SEGGER J-Link tools and ensure JLinkExe (or JLink.exe on Windows) is in PATH."
    esptool_hint = "Install esptool.py and ensure it is available in PATH."
    gpiod_hint = "Install Python gpiod bindings and ensure Linux gpiochip devices are accessible."

    tool_outputs: dict[str, str] = {}

    openocd = _check_tool("openocd", ["-v"], required=False, hint=openocd_hint)
    cubeprog = _check_tool("STM32_Programmer_CLI", ["--version"], required=False, hint=cube_hint)
    esptool = _check_tool("esptool.py", ["version"], required=False, hint=esptool_hint)

    if platform.system().lower() == "windows":
        jlink = _check_tool("JLink.exe", ["-?"], required=False, hint=jlink_hint)
        jlink_tool_name = "JLink.exe"
    else:
        jlink = _check_tool("JLinkExe", ["-?"], required=False, hint=jlink_hint)
        jlink_tool_name = "JLinkExe"

    results.extend([openocd, cubeprog, jlink, esptool])

    required_flash_backends: set[str] = set()
    local_gpio_chip_paths: set[str] = set()
    needs_gpiod = False
    needs_python_can = False

    if bench_cfg is not None:
        for _, node_cfg in bench_cfg.nodes.items():
            if node_cfg.flash is not None:
                backend = getattr(node_cfg.flash, "backend", "").strip()
                if backend:
                    required_flash_backends.add(backend)

            for _, gpio_cfg in node_cfg.gpio.items():
                if getattr(gpio_cfg, "backend", None) == "local_gpio":
                    needs_gpiod = True
                    chip = getattr(gpio_cfg, "chip", None)
                    if chip:
                        local_gpio_chip_paths.add(chip)

            for _, transport_cfg in node_cfg.transports.items():
                if getattr(transport_cfg, "backend", None) == "can":
                    needs_python_can = True

        if required_flash_backends:
            results.append(
                CheckResult(
                    name="Bench flash backends",
                    ok=True,
                    details=", ".join(sorted(required_flash_backends)),
                    required=False,
                )
            )

        for backend in sorted(required_flash_backends):
            if backend == "openocd":
                results.append(
                    CheckResult(
                        name=f"Flashing backend: {backend}",
                        ok=openocd.ok,
                        details="requires openocd",
                        required=True,
                        hint=openocd_hint,
                    )
                )
            elif backend in {"cubeprog", "stm32cubeprogrammer"}:
                results.append(
                    CheckResult(
                        name=f"Flashing backend: {backend}",
                        ok=cubeprog.ok,
                        details="requires STM32_Programmer_CLI",
                        required=True,
                        hint=cube_hint,
                    )
                )
            elif backend == "jlink":
                results.append(
                    CheckResult(
                        name=f"Flashing backend: {backend}",
                        ok=jlink.ok,
                        details=f"requires {jlink_tool_name}",
                        required=True,
                        hint=jlink_hint,
                    )
                )
            elif backend == "esptool":
                results.append(
                    CheckResult(
                        name=f"Flashing backend: {backend}",
                        ok=esptool.ok,
                        details="requires esptool.py",
                        required=True,
                        hint=esptool_hint,
                    )
                )
            else:
                results.append(
                    CheckResult(
                        name=f"Flashing backend: {backend}",
                        ok=False,
                        details="unknown flash backend",
                        required=True,
                        hint="Check the flash backend name in bench.yaml.",
                    )
                )

    tool_outputs["openocd -v"] = _run_cmd(["openocd", "-v"], timeout_s=5)[1] if openocd.ok else "not found"
    tool_outputs["STM32_Programmer_CLI --version"] = _run_cmd(["STM32_Programmer_CLI", "--version"], timeout_s=5)[1] if cubeprog.ok else "not found"
    tool_outputs[f"{jlink_tool_name} -?"] = _run_cmd([jlink_tool_name, "-?"], timeout_s=5)[1] if jlink.ok else "not found"
    tool_outputs["esptool.py version"] = _run_cmd(["esptool.py", "version"], timeout_s=5)[1] if esptool.ok else "not found"

    results.append(_check_serial_list())

    if port:
        results.append(_test_uart_open(port=port, baud=baud))

    if agent:
        results.append(_check_agent_health(agent, token=agent_token))

    if needs_gpiod:
        results.append(
            _check_python_module(
                "gpiod",
                required=True,
                hint=gpiod_hint,
            )
        )

    if needs_python_can:
        results.append(
            _check_python_module(
                "can",
                required=True,
                hint="Install python-can: pip install python-can",
            )
        )

    for chip_path in sorted(local_gpio_chip_paths):
        results.append(_check_gpiochip_device(chip_path))

    all_ok = True
    for r in results:
        if r.required and not r.ok:
            all_ok = False

    payload = {
        "tool": "benchci",
        "command": "doctor",
        "timestamp": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
        "ok": all_ok,
        "inputs": {
            "port": port,
            "baud": baud,
            "bench": bench_path,
            "agent": agent,
            "agent_token_provided": bool(agent_token),
        },
        "checks": [r.to_dict() for r in results],
    }

    human_text = _render_human(results)

    if export:
        out_zip = _write_export_zip(
            export_path=Path(export),
            payload=payload,
            human_text=human_text,
            bench_path=bench_path,
            tool_outputs=tool_outputs,
        )
        typer.echo(f"[ OK ] Diagnostics exported to: {out_zip}")

    if json_output:
        typer.echo(json.dumps(payload, indent=2))
        return 0 if all_ok else 1

    typer.echo(human_text.rstrip("\n"))

    passed = sum(1 for r in results if r.ok)
    failed = sum(1 for r in results if not r.ok and r.required)

    summary = f"\nSummary: {passed} checks passed"
    if failed:
        summary += f", {failed} required checks failed"

    typer.echo(summary)

    return 0 if all_ok else 1