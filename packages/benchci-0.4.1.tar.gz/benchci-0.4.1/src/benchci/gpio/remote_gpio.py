from __future__ import annotations

import json
import os
import urllib.error
import urllib.request
from dataclasses import dataclass
from pathlib import Path

from .base import GpioController


@dataclass
class RemoteGpioLineConfig:
    """Resolved per-line configuration for the remote_gpio backend."""
    channel: int
    direction: str  # "input" | "output"
    bias: str | None = None  # None | "disabled" | "pull_up" | "pull_down"
    edge: str | None = None  # None | "rising" | "falling" | "both"


class RemoteGpioController(GpioController):
    """Remote Linux GPIO backend over HTTP.

    This backend delegates GPIO operations to a BenchCI-compatible remote agent
    running on another machine. Logical polarity handling is performed by higher
    layers; this controller operates on physical values and edges.
    """

    def __init__(
        self,
        host: str,
        port: int,
        token_env: str,
        chip_path: str,
        line_configs: dict[int, RemoteGpioLineConfig],
        log_path: Path | None = None,
    ):
        self._host = host
        self._port = port
        self._token_env = token_env
        self._chip_path = chip_path
        self._line_configs = line_configs
        self._log_path = log_path

        self._base_url = f"http://{host}:{port}"
        self._session_id: str | None = None
        self._started = False

    def _log(self, message: str) -> None:
        if self._log_path is None:
            return

        from datetime import datetime, timezone

        ts = datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
        self._log_path.parent.mkdir(parents=True, exist_ok=True)

        with self._log_path.open("a", encoding="utf-8") as f:
            f.write(f"{ts} {message}\n")

    def _ensure_started(self) -> None:
        if not self._started or not self._session_id:
            raise RuntimeError("Remote GPIO backend not started")

    def _get_token(self) -> str:
        token = os.environ.get(self._token_env, "").strip()
        if not token:
            raise RuntimeError(
                f"remote_gpio requires environment variable '{self._token_env}' "
                "to be set with a valid access token"
            )
        return token

    def _request(
        self,
        method: str,
        path: str,
        payload: dict | None = None,
        timeout_s: float = 10.0,
    ) -> dict:
        url = f"{self._base_url}{path}"
        token = self._get_token()

        body = None
        headers = {
            "Accept": "application/json",
            "Authorization": f"Bearer {token}",
        }

        if payload is not None:
            body = json.dumps(payload).encode("utf-8")
            headers["Content-Type"] = "application/json"

        req = urllib.request.Request(
            url=url,
            data=body,
            headers=headers,
            method=method,
        )

        try:
            with urllib.request.urlopen(req, timeout=timeout_s) as resp:
                raw = resp.read().decode("utf-8").strip()
                if not raw:
                    return {}
                return json.loads(raw)
        except urllib.error.HTTPError as e:
            try:
                err_body = e.read().decode("utf-8", errors="replace")
            except Exception:
                err_body = ""
            raise RuntimeError(
                f"Remote GPIO request failed: {method} {path} "
                f"returned HTTP {e.code}. {err_body}".strip()
            ) from e
        except urllib.error.URLError as e:
            raise RuntimeError(
                f"Remote GPIO request failed: {method} {path} "
                f"could not reach {self._base_url}: {e}"
            ) from e
        except json.JSONDecodeError as e:
            raise RuntimeError(
                f"Remote GPIO request failed: {method} {path} "
                "returned invalid JSON"
            ) from e

    def _build_session_payload(self) -> dict:
        lines: dict[str, dict[str, str | None]] = {}

        for channel, cfg in self._line_configs.items():
            lines[str(channel)] = {
                "direction": cfg.direction,
                "bias": cfg.bias,
                "edge": cfg.edge,
            }

        return {
            "chip": self._chip_path,
            "lines": lines,
        }

    def start(self) -> None:
        if self._started:
            return

        try:
            self._request("GET", "/health", payload=None, timeout_s=5.0)
        except Exception as e:
            raise RuntimeError(
                f"Failed to reach remote BenchCI agent at {self._base_url}: {e}"
            ) from e

        payload = self._build_session_payload()

        try:
            resp = self._request(
                "POST",
                "/v1/gpio/session/start",
                payload=payload,
                timeout_s=10.0,
            )
        except Exception as e:
            raise RuntimeError(
                f"Failed to start remote GPIO session on {self._base_url}: {e}"
            ) from e

        session_id = str(resp.get("session_id", "")).strip()
        if not session_id:
            raise RuntimeError(
                "Remote GPIO service did not return a valid session_id"
            )

        self._session_id = session_id
        self._started = True
        self._log(
            f"GPIO_REMOTE_START host={self._host} port={self._port} "
            f"chip={self._chip_path} session_id={self._session_id}"
        )

    def stop(self) -> None:
        if self._session_id:
            try:
                self._request(
                    "POST",
                    "/v1/gpio/session/stop",
                    payload={"session_id": self._session_id},
                    timeout_s=5.0,
                )
            except Exception as e:
                self._log(
                    f"GPIO_REMOTE_STOP_ERROR host={self._host} port={self._port} "
                    f"chip={self._chip_path} session_id={self._session_id} "
                    f"error={type(e).__name__}: {e}"
                )

        if self._started:
            self._log(
                f"GPIO_REMOTE_STOP host={self._host} port={self._port} "
                f"chip={self._chip_path} session_id={self._session_id}"
            )

        self._session_id = None
        self._started = False

    def set_value(self, channel: int, value: bool) -> None:
        self._ensure_started()

        cfg = self._line_configs.get(channel)
        if cfg is None:
            raise RuntimeError(
                f"No remote_gpio configuration found for channel {channel}"
            )
        if cfg.direction != "output":
            raise RuntimeError(f"GPIO line {channel} is not configured as output")

        payload = {
            "session_id": self._session_id,
            "channel": channel,
            "value": value,
        }

        try:
            self._request("POST", "/v1/gpio/set", payload=payload, timeout_s=5.0)
        except Exception as e:
            raise RuntimeError(
                f"Failed to set remote GPIO line {channel} on {self._host}:{self._port} "
                f"to {value}: {e}"
            ) from e

        self._log(
            f"GPIO_REMOTE_SET host={self._host} port={self._port} "
            f"chip={self._chip_path} line={channel} value={value}"
        )

    def get_value(self, channel: int) -> bool:
        self._ensure_started()

        cfg = self._line_configs.get(channel)
        if cfg is None:
            raise RuntimeError(
                f"No remote_gpio configuration found for channel {channel}"
            )
        if cfg.direction != "input":
            raise RuntimeError(f"GPIO line {channel} is not configured as input")

        payload = {
            "session_id": self._session_id,
            "channel": channel,
        }

        try:
            resp = self._request("POST", "/v1/gpio/get", payload=payload, timeout_s=5.0)
        except Exception as e:
            raise RuntimeError(
                f"Failed to read remote GPIO line {channel} on {self._host}:{self._port}: {e}"
            ) from e

        if "value" not in resp:
            raise RuntimeError(
                f"Remote GPIO service did not return a value for line {channel}"
            )

        value = bool(resp["value"])
        self._log(
            f"GPIO_REMOTE_GET host={self._host} port={self._port} "
            f"chip={self._chip_path} line={channel} value={value}"
        )
        return value

    def wait_for_value(self, channel: int, value: bool, timeout_ms: int) -> bool:
        self._ensure_started()

        cfg = self._line_configs.get(channel)
        if cfg is None:
            raise RuntimeError(
                f"No remote_gpio configuration found for channel {channel}"
            )
        if cfg.direction != "input":
            raise RuntimeError(f"GPIO line {channel} is not configured as input")

        payload = {
            "session_id": self._session_id,
            "channel": channel,
            "value": value,
            "timeout_ms": timeout_ms,
        }

        timeout_s = max(1.0, (timeout_ms / 1000.0) + 2.0)

        try:
            resp = self._request(
                "POST",
                "/v1/gpio/wait_value",
                payload=payload,
                timeout_s=timeout_s,
            )
        except Exception as e:
            raise RuntimeError(
                f"Failed while waiting for value on remote GPIO line {channel} "
                f"on {self._host}:{self._port}: {e}"
            ) from e

        matched = bool(resp.get("matched", False))

        if matched:
            self._log(
                f"GPIO_REMOTE_WAIT_VALUE_OK host={self._host} port={self._port} "
                f"chip={self._chip_path} line={channel} value={value} timeout_ms={timeout_ms}"
            )
        else:
            self._log(
                f"GPIO_REMOTE_WAIT_VALUE_TIMEOUT host={self._host} port={self._port} "
                f"chip={self._chip_path} line={channel} value={value} timeout_ms={timeout_ms}"
            )

        return matched

    def wait_for_edge(self, channel: int, edge: str, timeout_ms: int) -> bool:
        self._ensure_started()

        cfg = self._line_configs.get(channel)
        if cfg is None:
            raise RuntimeError(
                f"No remote_gpio configuration found for channel {channel}"
            )
        if cfg.direction != "input":
            raise RuntimeError(f"GPIO line {channel} is not configured as input")

        if cfg.edge is None:
            raise RuntimeError(
                f"GPIO line {channel} is not configured with edge detection in bench.yaml"
            )

        if edge not in {"rising", "falling", "both"}:
            raise RuntimeError(f"Unsupported edge type: {edge}")

        if cfg.edge != "both":
            if edge == "both":
                raise RuntimeError(
                    f"GPIO line {channel} is configured for edge={cfg.edge}, cannot wait for both"
                )
            if edge != cfg.edge:
                raise RuntimeError(
                    f"GPIO line {channel} is configured for edge={cfg.edge}, cannot wait for {edge}"
                )

        payload = {
            "session_id": self._session_id,
            "channel": channel,
            "edge": edge,
            "timeout_ms": timeout_ms,
        }

        timeout_s = max(1.0, (timeout_ms / 1000.0) + 2.0)

        try:
            resp = self._request(
                "POST",
                "/v1/gpio/wait_edge",
                payload=payload,
                timeout_s=timeout_s,
            )
        except Exception as e:
            raise RuntimeError(
                f"Failed while waiting for edge on remote GPIO line {channel} "
                f"on {self._host}:{self._port}: {e}"
            ) from e

        matched = bool(resp.get("matched", False))

        if matched:
            self._log(
                f"GPIO_REMOTE_WAIT_EDGE_OK host={self._host} port={self._port} "
                f"chip={self._chip_path} line={channel} edge={edge} timeout_ms={timeout_ms}"
            )
        else:
            self._log(
                f"GPIO_REMOTE_WAIT_EDGE_TIMEOUT host={self._host} port={self._port} "
                f"chip={self._chip_path} line={channel} edge={edge} timeout_ms={timeout_ms}"
            )

        return matched