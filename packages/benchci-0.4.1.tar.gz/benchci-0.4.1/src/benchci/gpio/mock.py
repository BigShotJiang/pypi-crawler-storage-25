from __future__ import annotations

import threading
import time
from datetime import datetime, timezone
from pathlib import Path

from .base import GpioController


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


class MockGpioController(GpioController):
    """Mock GPIO backend.

    This backend does not control real hardware. It simulates GPIO state in
    memory and records operations to a log file for development and testing.
    """

    def __init__(self, log_path: Path | None = None):
        self._log_path = log_path
        self._started = False
        self._values: dict[int, bool] = {}
        self._events: dict[int, list[tuple[float, bool, bool]]] = {}
        self._lock = threading.Lock()
        self._cond = threading.Condition(self._lock)

    def _log(self, message: str) -> None:
        if self._log_path is None:
            return

        ts = _utc_now()
        self._log_path.parent.mkdir(parents=True, exist_ok=True)

        with self._log_path.open("a", encoding="utf-8") as f:
            f.write(f"{ts} {message}\n")

    def start(self) -> None:
        with self._lock:
            self._started = True
            self._values.clear()
            self._events.clear()
        self._log("GPIO_MOCK_START")

    def stop(self) -> None:
        with self._lock:
            was_started = self._started
            self._started = False
            self._cond.notify_all()

        if was_started:
            self._log("GPIO_MOCK_STOP")

    def _ensure_started(self) -> None:
        if not self._started:
            raise RuntimeError("GPIO backend not started")

    def set_value(self, channel: int, value: bool) -> None:
        with self._lock:
            self._ensure_started()

            old = self._values.get(channel, False)
            self._values[channel] = value

            if old != value:
                now = time.monotonic()
                self._events.setdefault(channel, []).append((now, old, value))

            self._cond.notify_all()

        self._log(f"GPIO_SET channel={channel} value={value}")

    def get_value(self, channel: int) -> bool:
        with self._lock:
            self._ensure_started()
            value = self._values.get(channel, False)

        self._log(f"GPIO_GET channel={channel} value={value}")
        return value

    def wait_for_value(self, channel: int, value: bool, timeout_ms: int) -> bool:
        deadline = time.monotonic() + (timeout_ms / 1000.0)

        with self._lock:
            self._ensure_started()

            while True:
                current = self._values.get(channel, False)
                if current == value:
                    self._log(f"GPIO_WAIT_VALUE_OK channel={channel} value={value} timeout_ms={timeout_ms}")
                    return True

                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    self._log(f"GPIO_WAIT_VALUE_TIMEOUT channel={channel} value={value} timeout_ms={timeout_ms}")
                    return False

                self._cond.wait(timeout=remaining)

    def wait_for_edge(self, channel: int, edge: str, timeout_ms: int) -> bool:
        if edge not in {"rising", "falling", "both"}:
            raise RuntimeError(f"Unsupported edge type: {edge}")

        deadline = time.monotonic() + (timeout_ms / 1000.0)

        with self._lock:
            self._ensure_started()

            already_seen = len(self._events.get(channel, []))

            while True:
                events = self._events.get(channel, [])
                for _, old, new in events[already_seen:]:
                    is_rising = (old is False and new is True)
                    is_falling = (old is True and new is False)

                    if edge == "both":
                        self._log(f"GPIO_WAIT_EDGE_OK channel={channel} edge={edge} timeout_ms={timeout_ms}")
                        return True
                    if edge == "rising" and is_rising:
                        self._log(f"GPIO_WAIT_EDGE_OK channel={channel} edge={edge} timeout_ms={timeout_ms}")
                        return True
                    if edge == "falling" and is_falling:
                        self._log(f"GPIO_WAIT_EDGE_OK channel={channel} edge={edge} timeout_ms={timeout_ms}")
                        return True

                already_seen = len(events)

                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    self._log(f"GPIO_WAIT_EDGE_TIMEOUT channel={channel} edge={edge} timeout_ms={timeout_ms}")
                    return False

                self._cond.wait(timeout=remaining)