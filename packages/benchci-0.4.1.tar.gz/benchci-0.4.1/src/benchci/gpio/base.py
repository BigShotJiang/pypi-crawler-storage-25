from __future__ import annotations

from abc import ABC, abstractmethod


class GpioController(ABC):
    """Abstract GPIO controller interface.

    A GPIO controller backend is responsible for interacting with hardware GPIO
    lines used by BenchCI during test execution.

    Backends may support output control, input reading, and edge/event waiting.
    """

    @abstractmethod
    def start(self) -> None:
        """Initialize the GPIO backend."""
        raise NotImplementedError

    @abstractmethod
    def stop(self) -> None:
        """Release backend resources."""
        raise NotImplementedError

    @abstractmethod
    def set_value(self, channel: int, value: bool) -> None:
        """Drive a physical GPIO channel to a physical boolean value.

        Args:
            channel:
                Backend-specific GPIO channel identifier.

            value:
                Physical value to drive. This is already resolved for
                active_high/active_low behavior by higher layers.
        """
        raise NotImplementedError

    @abstractmethod
    def get_value(self, channel: int) -> bool:
        """Read the current physical boolean value of a GPIO channel.

        Args:
            channel:
                Backend-specific GPIO channel identifier.

        Returns:
            Physical GPIO value.
        """
        raise NotImplementedError

    @abstractmethod
    def wait_for_value(self, channel: int, value: bool, timeout_ms: int) -> bool:
        """Wait until a GPIO channel reaches the requested physical value.

        Args:
            channel:
                Backend-specific GPIO channel identifier.

            value:
                Physical value to wait for.

            timeout_ms:
                Maximum time to wait in milliseconds.

        Returns:
            True if the expected value was observed before timeout, otherwise False.
        """
        raise NotImplementedError

    @abstractmethod
    def wait_for_edge(self, channel: int, edge: str, timeout_ms: int) -> bool:
        """Wait until an edge is observed on a GPIO channel.

        Args:
            channel:
                Backend-specific GPIO channel identifier.

            edge:
                Edge to wait for: 'rising', 'falling', or 'both'.

            timeout_ms:
                Maximum time to wait in milliseconds.

        Returns:
            True if the edge was observed before timeout, otherwise False.
        """
        raise NotImplementedError