from __future__ import annotations

import time
from dataclasses import dataclass
from pathlib import Path

from .base import GpioController


@dataclass
class LocalGpioLineConfig:
    """Resolved per-line configuration for the local_gpio backend."""
    channel: int
    direction: str  # "input" | "output"
    bias: str | None = None  # None | "disabled" | "pull_up" | "pull_down"
    edge: str | None = None  # None | "rising" | "falling" | "both"


class LocalGpioController(GpioController):
    """Linux local GPIO backend using libgpiod.

    This backend interacts with real GPIO lines exposed by the Linux GPIO
    character device interface, e.g. /dev/gpiochip0.
    """

    def __init__(
        self,
        chip_path: str,
        line_configs: dict[int, LocalGpioLineConfig],
        log_path: Path | None = None,
    ):
        self._chip_path = chip_path
        self._line_configs = line_configs
        self._log_path = log_path
        self._requests: dict[int, object] = {}
        self._started = False
        self._gpiod = None

    def _log(self, message: str) -> None:
        if self._log_path is None:
            return

        from datetime import datetime, timezone

        ts = datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
        self._log_path.parent.mkdir(parents=True, exist_ok=True)

        with self._log_path.open("a", encoding="utf-8") as f:
            f.write(f"{ts} {message}\n")

    def _ensure_started(self) -> None:
        if not self._started or self._gpiod is None:
            raise RuntimeError("GPIO backend not started")

    def start(self) -> None:
        if self._started:
            return

        try:
            import gpiod  # type: ignore
        except Exception as e:
            raise RuntimeError(
                f"local_gpio backend requires python gpiod bindings: {e}"
            ) from e

        if not gpiod.is_gpiochip_device(self._chip_path):
            raise RuntimeError(
                f"Configured GPIO chip path is not a gpiochip device: {self._chip_path}"
            )

        self._gpiod = gpiod
        self._started = True
        self._log(f"GPIO_LOCAL_START chip={self._chip_path}")

    def stop(self) -> None:
        for line, req in list(self._requests.items()):
            try:
                release = getattr(req, "release", None)
                if callable(release):
                    release()
            except Exception as e:
                self._log(
                    f"GPIO_LOCAL_RELEASE_ERROR chip={self._chip_path} line={line} "
                    f"error={type(e).__name__}: {e}"
                )

        self._requests.clear()

        if self._started:
            self._log(f"GPIO_LOCAL_STOP chip={self._chip_path}")

        self._started = False
        self._gpiod = None

    def _map_bias(self, bias: str | None):
        self._ensure_started()
        gpiod = self._gpiod

        if bias is None:
            return None

        bias_map = {
            "disabled": gpiod.line.Bias.DISABLED,
            "pull_up": gpiod.line.Bias.PULL_UP,
            "pull_down": gpiod.line.Bias.PULL_DOWN,
        }

        if bias not in bias_map:
            raise RuntimeError(f"Unsupported GPIO bias: {bias}")

        return bias_map[bias]

    def _map_edge(self, edge: str | None):
        self._ensure_started()
        gpiod = self._gpiod

        if edge is None:
            return None

        edge_map = {
            "rising": gpiod.line.Edge.RISING,
            "falling": gpiod.line.Edge.FALLING,
            "both": gpiod.line.Edge.BOTH,
        }

        if edge not in edge_map:
            raise RuntimeError(f"Unsupported GPIO edge: {edge}")

        return edge_map[edge]

    def _validate_requested_edge(self, configured_edge: str | None, requested_edge: str) -> None:
        if configured_edge is None:
            raise RuntimeError(
                "GPIO line is not configured with edge detection in bench.yaml"
            )

        if requested_edge not in {"rising", "falling", "both"}:
            raise RuntimeError(f"Unsupported edge type: {requested_edge}")

        if configured_edge == "both":
            return

        if requested_edge == "both" and configured_edge != "both":
            raise RuntimeError(
                f"GPIO line is configured for edge={configured_edge}, cannot wait for both"
            )

        if requested_edge != configured_edge:
            raise RuntimeError(
                f"GPIO line is configured for edge={configured_edge}, cannot wait for {requested_edge}"
            )

    def _event_matches_edge(self, event, requested_edge: str) -> bool:
        self._ensure_started()
        gpiod = self._gpiod

        ev_type = getattr(event, "event_type", None)

        # Prefer direct enum comparison when available.
        try:
            if ev_type == gpiod.line.Edge.RISING:
                return requested_edge in {"rising", "both"}
            if ev_type == gpiod.line.Edge.FALLING:
                return requested_edge in {"falling", "both"}
        except Exception:
            pass

        # Fallback to string matching for compatibility across bindings.
        ev_type_str = str(ev_type).lower()
        is_rising = "rising" in ev_type_str
        is_falling = "falling" in ev_type_str

        if requested_edge == "both":
            return is_rising or is_falling
        if requested_edge == "rising":
            return is_rising
        if requested_edge == "falling":
            return is_falling

        return False

    def _get_or_request_line(self, channel: int):
        self._ensure_started()
        gpiod = self._gpiod

        req = self._requests.get(channel)
        if req is not None:
            return req

        cfg = self._line_configs.get(channel)
        if cfg is None:
            raise RuntimeError(f"No local_gpio configuration found for channel {channel}")

        kwargs = {}

        bias = self._map_bias(cfg.bias)
        if bias is not None:
            kwargs["bias"] = bias

        if cfg.direction == "output":
            kwargs["direction"] = gpiod.line.Direction.OUTPUT
            kwargs["output_value"] = gpiod.line.Value.INACTIVE

        elif cfg.direction == "input":
            kwargs["direction"] = gpiod.line.Direction.INPUT
            edge = self._map_edge(cfg.edge)
            if edge is not None:
                kwargs["edge_detection"] = edge

        else:
            raise RuntimeError(f"Unsupported GPIO direction: {cfg.direction}")

        try:
            settings = gpiod.LineSettings(**kwargs)

            req = gpiod.request_lines(
                self._chip_path,
                consumer="benchci",
                config={channel: settings},
            )
        except Exception as e:
            raise RuntimeError(
                f"Failed to request GPIO line {channel} on {self._chip_path}: {e}"
            ) from e

        self._requests[channel] = req
        self._log(
            f"GPIO_LOCAL_REQUEST chip={self._chip_path} line={channel} "
            f"direction={cfg.direction} bias={cfg.bias} edge={cfg.edge}"
        )
        return req

    def set_value(self, channel: int, value: bool) -> None:
        cfg = self._line_configs.get(channel)
        if cfg is None:
            raise RuntimeError(f"No local_gpio configuration found for channel {channel}")
        if cfg.direction != "output":
            raise RuntimeError(f"GPIO line {channel} is not configured as output")

        req = self._get_or_request_line(channel)
        gpiod = self._gpiod

        physical = gpiod.line.Value.ACTIVE if value else gpiod.line.Value.INACTIVE

        try:
            req.set_value(channel, physical)
        except Exception as e:
            raise RuntimeError(
                f"Failed to set GPIO line {channel} on {self._chip_path} to {value}: {e}"
            ) from e

        self._log(f"GPIO_LOCAL_SET chip={self._chip_path} line={channel} value={value}")

    def get_value(self, channel: int) -> bool:
        cfg = self._line_configs.get(channel)
        if cfg is None:
            raise RuntimeError(f"No local_gpio configuration found for channel {channel}")
        if cfg.direction != "input":
            raise RuntimeError(f"GPIO line {channel} is not configured as input")

        req = self._get_or_request_line(channel)
        gpiod = self._gpiod

        try:
            raw = req.get_value(channel)
        except Exception as e:
            raise RuntimeError(
                f"Failed to read GPIO line {channel} on {self._chip_path}: {e}"
            ) from e

        value = raw == gpiod.line.Value.ACTIVE
        self._log(f"GPIO_LOCAL_GET chip={self._chip_path} line={channel} value={value}")
        return value

    def wait_for_value(self, channel: int, value: bool, timeout_ms: int) -> bool:
        deadline = time.monotonic() + (timeout_ms / 1000.0)

        while True:
            current = self.get_value(channel)
            if current == value:
                self._log(
                    f"GPIO_LOCAL_WAIT_VALUE_OK chip={self._chip_path} line={channel} "
                    f"value={value} timeout_ms={timeout_ms}"
                )
                return True

            remaining = deadline - time.monotonic()
            if remaining <= 0:
                self._log(
                    f"GPIO_LOCAL_WAIT_VALUE_TIMEOUT chip={self._chip_path} line={channel} "
                    f"value={value} timeout_ms={timeout_ms}"
                )
                return False

            time.sleep(min(0.01, remaining))

    def wait_for_edge(self, channel: int, edge: str, timeout_ms: int) -> bool:
        cfg = self._line_configs.get(channel)
        if cfg is None:
            raise RuntimeError(f"No local_gpio configuration found for channel {channel}")
        if cfg.direction != "input":
            raise RuntimeError(f"GPIO line {channel} is not configured as input")

        self._validate_requested_edge(cfg.edge, edge)

        req = self._get_or_request_line(channel)
        deadline = time.monotonic() + (timeout_ms / 1000.0)

        while True:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                self._log(
                    f"GPIO_LOCAL_WAIT_EDGE_TIMEOUT chip={self._chip_path} line={channel} "
                    f"edge={edge} timeout_ms={timeout_ms}"
                )
                return False

            try:
                event_ready = req.wait_edge_events(timeout=remaining)
            except Exception as e:
                raise RuntimeError(
                    f"Failed while waiting for edge on GPIO line {channel} "
                    f"on {self._chip_path}: {e}"
                ) from e

            if not event_ready:
                self._log(
                    f"GPIO_LOCAL_WAIT_EDGE_TIMEOUT chip={self._chip_path} line={channel} "
                    f"edge={edge} timeout_ms={timeout_ms}"
                )
                return False

            try:
                events = req.read_edge_events()
            except Exception as e:
                raise RuntimeError(
                    f"Failed to read edge events for GPIO line {channel} "
                    f"on {self._chip_path}: {e}"
                ) from e

            for ev in events:
                if self._event_matches_edge(ev, edge):
                    self._log(
                        f"GPIO_LOCAL_WAIT_EDGE_OK chip={self._chip_path} line={channel} "
                        f"edge={edge} timeout_ms={timeout_ms}"
                    )
                    return True