from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from benchci.config.bench import BenchConfig, GpioLocal, GpioMock, GpioRemote, NodeConfig

from .base import GpioController
from .local_gpio import LocalGpioController, LocalGpioLineConfig
from .mock import MockGpioController
from .remote_gpio import RemoteGpioController, RemoteGpioLineConfig


@dataclass
class GpioLineBinding:
    """Resolved logical GPIO line binding."""
    name: str
    backend: str
    channel: int
    direction: str
    active_high: bool
    bias: str | None = None
    edge: str | None = None


class GpioManager:
    """High-level GPIO manager used by the runner.

    This resolves logical GPIO line names from a node's GPIO config to
    backend-specific channels and applies active_high/active_low mapping
    for both outputs and inputs.
    """

    def __init__(self, controller: GpioController, lines: dict[str, GpioLineBinding]):
        self._controller = controller
        self._lines = lines

    def start(self) -> None:
        self._controller.start()

    def stop(self) -> None:
        self._controller.stop()

    def has_lines(self) -> bool:
        return bool(self._lines)

    def line_names(self) -> list[str]:
        return sorted(self._lines.keys())

    def _require_line(self, line: str) -> GpioLineBinding:
        binding = self._lines.get(line)
        if binding is None:
            known = ", ".join(sorted(self._lines.keys())) or "<none>"
            raise RuntimeError(f"Unknown GPIO line '{line}'. Known lines: {known}")
        return binding

    def set_logical_value(self, line: str, value: bool) -> None:
        binding = self._require_line(line)

        if binding.direction != "output":
            raise RuntimeError(f"GPIO line '{line}' is not configured as output")

        physical_value = value if binding.active_high else (not value)
        self._controller.set_value(binding.channel, physical_value)

    def get_logical_value(self, line: str) -> bool:
        binding = self._require_line(line)

        if binding.direction != "input":
            raise RuntimeError(f"GPIO line '{line}' is not configured as input")

        physical_value = self._controller.get_value(binding.channel)
        return physical_value if binding.active_high else (not physical_value)

    def wait_for_logical_value(self, line: str, value: bool, timeout_ms: int) -> bool:
        binding = self._require_line(line)

        if binding.direction != "input":
            raise RuntimeError(f"GPIO line '{line}' is not configured as input")

        physical_value = value if binding.active_high else (not value)
        return self._controller.wait_for_value(binding.channel, physical_value, timeout_ms)

    def wait_for_logical_edge(self, line: str, edge: str, timeout_ms: int) -> bool:
        binding = self._require_line(line)

        if binding.direction != "input":
            raise RuntimeError(f"GPIO line '{line}' is not configured as input")

        if edge not in {"rising", "falling", "both"}:
            raise RuntimeError(f"Unsupported logical edge type: {edge}")

        physical_edge = edge
        if not binding.active_high:
            if edge == "rising":
                physical_edge = "falling"
            elif edge == "falling":
                physical_edge = "rising"

        return self._controller.wait_for_edge(binding.channel, physical_edge, timeout_ms)


def _require_node(bench: BenchConfig, node_name: str) -> NodeConfig:
    node = bench.nodes.get(node_name)
    if node is None:
        known = ", ".join(sorted(bench.nodes.keys())) or "<none>"
        raise RuntimeError(f"Unknown node '{node_name}'. Known nodes: {known}")
    return node


def create_gpio_manager_for_node(
    node_cfg: NodeConfig,
    log_path: Path | None = None,
) -> GpioManager | None:
    """Create a GPIO manager from one node configuration.

    Returns None if the node does not define any GPIO lines.

    Current limitation:
    - only one GPIO backend per node
    - local_gpio supports one chip per node
    - remote_gpio supports one host+port+chip per node
    """
    if not node_cfg.gpio:
        return None

    backends = {cfg.backend for cfg in node_cfg.gpio.values()}
    if len(backends) != 1:
        raise RuntimeError(
            "GPIO currently supports only one GPIO backend per node configuration. "
            f"Found backends: {sorted(backends)}"
        )

    backend = next(iter(backends))
    bindings: dict[str, GpioLineBinding] = {}

    if backend == "mock_gpio":
        controller: GpioController = MockGpioController(log_path=log_path)

        for line_name, cfg in node_cfg.gpio.items():
            if not isinstance(cfg, GpioMock):
                raise RuntimeError(
                    f"Unsupported GPIO config type for line '{line_name}': {type(cfg).__name__}"
                )

            bindings[line_name] = GpioLineBinding(
                name=line_name,
                backend=cfg.backend,
                channel=cfg.channel,
                direction=cfg.direction,
                active_high=cfg.active_high,
                bias=cfg.bias,
                edge=cfg.edge,
            )

    elif backend == "local_gpio":
        chips = {
            cfg.chip
            for cfg in node_cfg.gpio.values()
            if isinstance(cfg, GpioLocal)
        }

        if len(chips) != 1:
            raise RuntimeError(
                "local_gpio currently supports only one chip per node configuration. "
                f"Found chips: {sorted(chips)}"
            )

        chip = next(iter(chips))
        line_configs: dict[int, LocalGpioLineConfig] = {}

        for line_name, cfg in node_cfg.gpio.items():
            if not isinstance(cfg, GpioLocal):
                raise RuntimeError(
                    f"Unsupported GPIO config type for line '{line_name}': {type(cfg).__name__}"
                )

            if cfg.line in line_configs:
                raise RuntimeError(
                    f"Duplicate local_gpio line number {cfg.line} in node.gpio "
                    f"(conflict at logical line '{line_name}')"
                )

            line_configs[cfg.line] = LocalGpioLineConfig(
                channel=cfg.line,
                direction=cfg.direction,
                bias=cfg.bias,
                edge=cfg.edge,
            )

            bindings[line_name] = GpioLineBinding(
                name=line_name,
                backend=cfg.backend,
                channel=cfg.line,
                direction=cfg.direction,
                active_high=cfg.active_high,
                bias=cfg.bias,
                edge=cfg.edge,
            )

        controller = LocalGpioController(
            chip_path=chip,
            line_configs=line_configs,
            log_path=log_path,
        )

    elif backend == "remote_gpio":
        remote_endpoints = {
            (cfg.host, cfg.port, cfg.token_env, cfg.chip)
            for cfg in node_cfg.gpio.values()
            if isinstance(cfg, GpioRemote)
        }

        if len(remote_endpoints) != 1:
            raise RuntimeError(
                "remote_gpio currently supports only one host+port+chip per node configuration. "
                f"Found remote endpoints: {sorted(remote_endpoints)}"
            )

        host, port, token_env, chip = next(iter(remote_endpoints))
        line_configs: dict[int, RemoteGpioLineConfig] = {}

        for line_name, cfg in node_cfg.gpio.items():
            if not isinstance(cfg, GpioRemote):
                raise RuntimeError(
                    f"Unsupported GPIO config type for line '{line_name}': {type(cfg).__name__}"
                )

            if cfg.line in line_configs:
                raise RuntimeError(
                    f"Duplicate remote_gpio line number {cfg.line} in node.gpio "
                    f"(conflict at logical line '{line_name}')"
                )

            line_configs[cfg.line] = RemoteGpioLineConfig(
                channel=cfg.line,
                direction=cfg.direction,
                bias=cfg.bias,
                edge=cfg.edge,
            )

            bindings[line_name] = GpioLineBinding(
                name=line_name,
                backend=cfg.backend,
                channel=cfg.line,
                direction=cfg.direction,
                active_high=cfg.active_high,
                bias=cfg.bias,
                edge=cfg.edge,
            )

        controller = RemoteGpioController(
            host=host,
            port=port,
            token_env=token_env,
            chip_path=chip,
            line_configs=line_configs,
            log_path=log_path,
        )

    else:
        raise RuntimeError(f"Unsupported GPIO backend: {backend}")

    return GpioManager(controller=controller, lines=bindings)


def create_gpio_manager(
    bench: BenchConfig,
    node_name: str,
    log_path: Path | None = None,
) -> GpioManager | None:
    """Resolve a node from the bench and create its GPIO manager."""
    node_cfg = _require_node(bench, node_name)
    return create_gpio_manager_for_node(node_cfg=node_cfg, log_path=log_path)