from __future__ import annotations

from dataclasses import dataclass, field

from benchci.agent.models import RunEvent, RunRecord, RunStatusResponse


@dataclass
class AgentStateStore:
    """In-memory state store for runs and bench occupancy."""
    runs: dict[str, RunRecord] = field(default_factory=dict)
    current_run_by_bench: dict[str, str | None] = field(default_factory=dict)

    def create_run(self, rec: RunRecord) -> None:
        if rec.run_id in self.runs:
            raise RuntimeError(f"run_id already exists: {rec.run_id}")
        self.runs[rec.run_id] = rec

    def get_run(self, run_id: str) -> RunRecord | None:
        return self.runs.get(run_id)

    def require_run(self, run_id: str) -> RunRecord:
        rec = self.get_run(run_id)
        if rec is None:
            raise RuntimeError(f"run not found: {run_id}")
        return rec

    def append_event(self, run_id: str, event: RunEvent) -> None:
        rec = self.require_run(run_id)
        rec.events.append(event)

    def set_bench_current_run(self, bench_id: str, run_id: str | None) -> None:
        self.current_run_by_bench[bench_id] = run_id

    def run_to_response(self, rec: RunRecord, queue_depth: int) -> RunStatusResponse:
        return RunStatusResponse(
            run_id=rec.run_id,
            status=rec.status,
            mode=rec.mode,
            bench_id=rec.bench_id,
            exit_code=rec.exit_code,
            error=rec.error,
            created_at=rec.created_at,
            started_at=rec.started_at,
            finished_at=rec.finished_at,
            current_test=rec.current_test,
            current_step=rec.current_step,
            queue_depth=queue_depth,
        )