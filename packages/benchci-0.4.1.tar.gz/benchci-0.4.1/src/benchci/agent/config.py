from __future__ import annotations

from pathlib import Path

import yaml
from pydantic import BaseModel, Field, model_validator

from benchci.config.bench import BenchConfig, load_bench_config


class AgentMetaConfig(BaseModel):
    """Metadata describing this agent instance."""
    id: str = Field(..., min_length=1, description="Stable agent identifier.")
    name: str | None = Field(None, description="Human-friendly agent name.")


class RegisteredBenchConfig(BaseModel):
    """One bench registered on this agent."""
    id: str = Field(..., min_length=1, description="Stable bench identifier.")
    bench_file: str = Field(..., min_length=1, description="Path to bench.yaml on disk.")
    tags: list[str] = Field(default_factory=list, description="Optional bench tags.")

    @model_validator(mode="after")
    def _normalize_tags(self) -> "RegisteredBenchConfig":
        self.tags = [t.strip() for t in self.tags if t and t.strip()]
        return self


class AgentConfig(BaseModel):
    """Agent configuration loaded from agent.yaml."""
    agent: AgentMetaConfig
    benches: list[RegisteredBenchConfig] = Field(default_factory=list)

    @model_validator(mode="after")
    def _validate_unique_bench_ids(self) -> "AgentConfig":
        seen: set[str] = set()
        for bench in self.benches:
            if bench.id in seen:
                raise ValueError(f"duplicate bench id in agent config: '{bench.id}'")
            seen.add(bench.id)
        return self


class RegisteredBenchRecord(BaseModel):
    """Resolved registered bench with loaded BenchConfig."""
    id: str
    tags: list[str] = Field(default_factory=list)
    bench_file: str
    bench: BenchConfig


def load_agent_config(path: str | Path) -> AgentConfig:
    """Load and validate agent.yaml."""
    p = Path(path).expanduser().resolve()
    if not p.exists():
        raise FileNotFoundError(p)

    data = yaml.safe_load(p.read_text(encoding="utf-8")) or {}
    return AgentConfig.model_validate(data)


def resolve_registered_benches(cfg: AgentConfig) -> list[RegisteredBenchRecord]:
    """Load all registered benches declared in agent.yaml."""
    records: list[RegisteredBenchRecord] = []

    for bench_cfg in cfg.benches:
        bench_path = Path(bench_cfg.bench_file).expanduser().resolve()
        bench = load_bench_config(bench_path)

        records.append(
            RegisteredBenchRecord(
                id=bench_cfg.id,
                tags=list(bench_cfg.tags),
                bench_file=str(bench_path),
                bench=bench,
            )
        )

    return records