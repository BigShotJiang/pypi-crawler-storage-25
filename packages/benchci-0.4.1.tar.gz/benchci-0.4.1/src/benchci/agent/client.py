from __future__ import annotations

import base64
import json
import time
from pathlib import Path
from typing import Any, Callable

import httpx


def _normalize_agent_url(agent_url: str) -> str:
    return agent_url.rstrip("/")


def _build_headers(token: str | None = None) -> dict[str, str]:
    headers: dict[str, str] = {}
    if token:
        headers["Authorization"] = f"Bearer {token}"
    return headers


def _extract_error_detail(response: httpx.Response) -> str | None:
    try:
        body = response.json()
        detail = body.get("detail") or body.get("error")
        if isinstance(detail, str) and detail.strip():
            return detail.strip()
        if isinstance(detail, list):
            return "Request validation failed. Please check your input."
    except Exception:
        pass
    return None


def _raise_http_error_with_context(exc: httpx.HTTPStatusError, action: str) -> None:
    status = exc.response.status_code
    detail = _extract_error_detail(exc.response)

    if detail:
        raise RuntimeError(detail)

    if status == 400:
        raise RuntimeError("Request was invalid. Please check your input.")
    if status == 401:
        raise RuntimeError("Agent authentication failed.")
    if status == 403:
        raise RuntimeError("Agent is not allowed to perform this action.")
    if status == 404:
        raise RuntimeError("Requested agent resource was not found.")
    if status == 409:
        raise RuntimeError("Agent rejected the request because of a state conflict.")
    if status == 422:
        raise RuntimeError("Request validation failed. Please check your input.")
    if status == 429:
        raise RuntimeError("Too many requests. Please try again shortly.")
    if status >= 500:
        raise RuntimeError("BenchCI agent is temporarily unavailable.")

    raise RuntimeError(f"{action} failed.")

def submit_run(
    agent_url: str,
    bench_path: str | Path,
    suite_path: str | Path,
    artifact_path: str | Path | None = None,
    skip_flash: bool = False,
    verbose: bool = False,
    timeout_s: float = 60.0,
    token: str | None = None,
) -> dict:
    """Submit a run using uploaded bench mode.

    This keeps backward compatibility with the older agent flow:
    - uploads bench.yaml
    - uploads suite.yaml
    - optionally uploads artifact
    """
    agent_url = _normalize_agent_url(agent_url)

    bench_file = Path(bench_path).expanduser().resolve()
    suite_file = Path(suite_path).expanduser().resolve()
    artifact_file = Path(artifact_path).expanduser().resolve() if artifact_path else None

    if not bench_file.exists():
        raise RuntimeError("Bench file was not found.")
    if not suite_file.exists():
        raise RuntimeError("Suite file was not found.")
    if not skip_flash and artifact_file is None:
        raise RuntimeError("Artifact path is required unless skip_flash=True.")
    if not skip_flash and artifact_file is not None and not artifact_file.exists():
        raise RuntimeError("Artifact file was not found.")

    files: dict[str, tuple[str, bytes, str]] = {
        "bench_yaml": ("bench.yaml", bench_file.read_bytes(), "application/x-yaml"),
        "suite_yaml": ("suite.yaml", suite_file.read_bytes(), "application/x-yaml"),
    }

    if not skip_flash and artifact_file is not None:
        files["artifact"] = (
            artifact_file.name,
            artifact_file.read_bytes(),
            "application/octet-stream",
        )

    data = {
        "skip_flash": "true" if skip_flash else "false",
        "verbose": "true" if verbose else "false",
    }
    headers = _build_headers(token)

    try:
        with httpx.Client(timeout=timeout_s) as client:
            response = client.post(
                f"{agent_url}/v1/runs",
                files=files,
                data=data,
                headers=headers,
            )
            response.raise_for_status()
            return response.json()
    except httpx.HTTPStatusError as exc:
        _raise_http_error_with_context(exc, "Submitting uploaded-bench run")
    except httpx.HTTPError as exc:
        raise RuntimeError("Submitting uploaded-bench run failed.")


def submit_registered_run(
    agent_url: str,
    bench_id: str,
    suite_path: str | Path,
    artifact_path: str | Path | None = None,
    artifact_relpath: str | None = None,
    skip_flash: bool = False,
    verbose: bool = False,
    timeout_s: float = 60.0,
    token: str | None = None,
) -> dict:
    """Submit a run against a registered bench.

    Notes:
    - This uses the Agent v2 JSON endpoint.
    - The suite is sent as raw YAML text.
    - If skip_flash=False, artifact_path is uploaded inside the JSON payload.
    - artifact_relpath may be used to override the filename stored under the run dir.
    """
    agent_url = _normalize_agent_url(agent_url)

    suite_file = Path(suite_path).expanduser().resolve()
    if not suite_file.exists():
        raise RuntimeError("Suite file was not found.")

    artifact_file = Path(artifact_path).expanduser().resolve() if artifact_path else None
    if not skip_flash:
        if artifact_file is None:
            raise RuntimeError("Artifact path is required for registered-bench runs unless skip_flash=True.")
        if not artifact_file.exists():
            raise RuntimeError("Artifact file was not found.")

    payload: dict[str, Any] = {
        "bench_id": bench_id,
        "suite_yaml": suite_file.read_text(encoding="utf-8"),
        "skip_flash": skip_flash,
        "verbose": verbose,
    }

    if artifact_file is not None:
        stored_name = Path(artifact_relpath).name if artifact_relpath else artifact_file.name
        payload["artifact_relpath"] = stored_name
        payload["artifact_filename"] = artifact_file.name
        payload["artifact_base64"] = base64.b64encode(
            artifact_file.read_bytes()
        ).decode("ascii")

    headers = _build_headers(token)
    headers["Content-Type"] = "application/json"

    try:
        with httpx.Client(timeout=timeout_s) as client:
            response = client.post(
                f"{agent_url}/v1/runs/json",
                content=json.dumps(payload),
                headers=headers,
            )
            response.raise_for_status()
            return response.json()
    except httpx.HTTPStatusError as exc:
        _raise_http_error_with_context(exc, "Submitting registered-bench run")
    except httpx.HTTPError as exc:
        raise RuntimeError("Submitting registered-bench run failed.")


def get_run(
    agent_url: str,
    run_id: str,
    token: str | None = None,
    timeout_s: float = 10.0,
) -> dict:
    """Fetch the current status of a run."""
    agent_url = _normalize_agent_url(agent_url)
    headers = _build_headers(token)

    try:
        with httpx.Client(timeout=timeout_s) as client:
            response = client.get(
                f"{agent_url}/v1/runs/{run_id}",
                headers=headers,
            )
            response.raise_for_status()
            return response.json()
    except httpx.HTTPStatusError as exc:
        _raise_http_error_with_context(exc, f"Fetching run status for '{run_id}'")
    except httpx.HTTPError as exc:
        raise RuntimeError("Fetching run status failed.")


def get_run_events(
    agent_url: str,
    run_id: str,
    token: str | None = None,
    timeout_s: float = 10.0,
) -> dict:
    """Fetch structured lifecycle/progress events for a run."""
    agent_url = _normalize_agent_url(agent_url)
    headers = _build_headers(token)

    try:
        with httpx.Client(timeout=timeout_s) as client:
            response = client.get(
                f"{agent_url}/v1/runs/{run_id}/events",
                headers=headers,
            )
            response.raise_for_status()
            return response.json()
    except httpx.HTTPStatusError as exc:
        _raise_http_error_with_context(exc, f"Fetching run events for '{run_id}'")
    except httpx.HTTPError as exc:
        raise RuntimeError("Fetching run events failed.")


def wait_run(
    agent_url: str,
    run_id: str,
    token: str | None = None,
    poll_interval_s: float = 1.0,
    timeout_s: float = 1800.0,
    on_update: Callable[[dict], Any] | None = None,
) -> dict:
    """Poll the agent until the run completes or timeout is reached."""
    start = time.time()
    last_key: tuple[Any, ...] | None = None

    terminal_states = {"done", "failed"}

    while True:
        result = get_run(agent_url, run_id, token=token)
        status = result.get("status")
        exit_code = result.get("exit_code")
        queue_depth = result.get("queue_depth")
        started_at = result.get("started_at")
        finished_at = result.get("finished_at")
        error = result.get("error")
        current_test = result.get("current_test")
        current_step = result.get("current_step")

        key = (
            status,
            exit_code,
            queue_depth,
            started_at,
            finished_at,
            error,
            current_test,
            current_step,
        )

        if key != last_key:
            last_key = key
            if on_update is not None:
                on_update(result)

        if status in terminal_states:
            return result

        elapsed = time.time() - start
        if elapsed > timeout_s:
            raise TimeoutError(
                f"Timed out waiting for run '{run_id}' after {timeout_s:.1f}s"
            )

        time.sleep(poll_interval_s)


def wait_run_with_events(
    agent_url: str,
    run_id: str,
    token: str | None = None,
    poll_interval_s: float = 1.0,
    timeout_s: float = 1800.0,
    on_status_update: Callable[[dict], Any] | None = None,
    on_event: Callable[[dict], Any] | None = None,
) -> dict:
    """Poll run status and stream newly observed structured events.

    This is useful for building richer CLI output or a future TUI/UI layer.
    """
    start = time.time()
    seen_events = 0
    last_status_key: tuple[Any, ...] | None = None

    terminal_states = {"done", "failed"}

    while True:
        status = get_run(agent_url, run_id, token=token)
        status_key = (
            status.get("status"),
            status.get("exit_code"),
            status.get("queue_depth"),
            status.get("started_at"),
            status.get("finished_at"),
            status.get("error"),
            status.get("current_test"),
            status.get("current_step"),
        )

        if status_key != last_status_key:
            last_status_key = status_key
            if on_status_update is not None:
                on_status_update(status)

        events_payload = get_run_events(agent_url, run_id, token=token)
        events = list(events_payload.get("events", []))

        if seen_events < len(events):
            for event in events[seen_events:]:
                if on_event is not None:
                    on_event(event)
            seen_events = len(events)

        if status.get("status") in terminal_states:
            return status

        elapsed = time.time() - start
        if elapsed > timeout_s:
            raise TimeoutError(
                f"Timed out waiting for run '{run_id}' after {timeout_s:.1f}s"
            )

        time.sleep(poll_interval_s)


def download_artifacts(
    agent_url: str,
    run_id: str,
    out_zip_path: str | Path,
    token: str | None = None,
    timeout_s: float = 120.0,
) -> Path:
    """Download run artifacts ZIP from the agent."""
    agent_url = _normalize_agent_url(agent_url)
    out_path = Path(out_zip_path).expanduser().resolve()
    out_path.parent.mkdir(parents=True, exist_ok=True)
    headers = _build_headers(token)

    try:
        with httpx.Client(timeout=timeout_s) as client:
            response = client.get(
                f"{agent_url}/v1/runs/{run_id}/artifacts.zip",
                headers=headers,
            )
            response.raise_for_status()
            out_path.write_bytes(response.content)
            return out_path
    except httpx.HTTPStatusError as exc:
        _raise_http_error_with_context(exc, f"Downloading artifacts for '{run_id}'")
    except httpx.HTTPError as exc:
        raise RuntimeError("Downloading artifacts failed.")


def list_benches(
    agent_url: str,
    token: str | None = None,
    timeout_s: float = 10.0,
) -> list[dict]:
    """List all registered benches on the agent."""
    agent_url = _normalize_agent_url(agent_url)
    headers = _build_headers(token)

    try:
        with httpx.Client(timeout=timeout_s) as client:
            response = client.get(
                f"{agent_url}/v1/benches",
                headers=headers,
            )
            response.raise_for_status()
            payload = response.json()
            if not isinstance(payload, list):
                raise RuntimeError(f"Unexpected benches response: {payload!r}")
            return payload
    except httpx.HTTPStatusError as exc:
        _raise_http_error_with_context(exc, "Listing benches")
    except httpx.HTTPError as exc:
        raise RuntimeError("Listing benches failed.")


def get_bench(
    agent_url: str,
    bench_id: str,
    token: str | None = None,
    timeout_s: float = 10.0,
) -> dict:
    """Fetch one registered bench from the agent."""
    agent_url = _normalize_agent_url(agent_url)
    headers = _build_headers(token)

    try:
        with httpx.Client(timeout=timeout_s) as client:
            response = client.get(
                f"{agent_url}/v1/benches/{bench_id}",
                headers=headers,
            )
            response.raise_for_status()
            return response.json()
    except httpx.HTTPStatusError as exc:
        _raise_http_error_with_context(exc, f"Fetching bench '{bench_id}'")
    except httpx.HTTPError as exc:
        raise RuntimeError("Fetching bench failed.")


def get_health(
    agent_url: str,
    token: str | None = None,
    timeout_s: float = 10.0,
) -> dict:
    """Fetch agent health and registration summary."""
    agent_url = _normalize_agent_url(agent_url)
    headers = _build_headers(token)

    try:
        with httpx.Client(timeout=timeout_s) as client:
            response = client.get(
                f"{agent_url}/health",
                headers=headers,
            )
            response.raise_for_status()
            return response.json()
    except httpx.HTTPStatusError as exc:
        _raise_http_error_with_context(exc, "Fetching agent health")
    except httpx.HTTPError as exc:
        raise RuntimeError("Fetching agent health failed.")
