from __future__ import annotations

import base64
import tempfile
import threading
import zipfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .bench_export import load_bench_for_cloud
from .cloud_client import CloudClient

from benchci.runner.local import run_local


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _zip_dir(src_dir: Path, out_zip_path: Path) -> Path:
    out_zip_path = out_zip_path.expanduser().resolve()
    out_zip_path.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(out_zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
        for p in src_dir.rglob("*"):
            if p.is_file():
                zf.write(p, p.relative_to(src_dir))
    return out_zip_path


class CloudAgent:
    def __init__(
        self,
        backend_url: str,
        agent_token: str,
        bench_path: str | Path,
        *,
        bench_id: str | None = None,
        bench_tags: list[str] | None = None,
        agent_name: str | None = None,
        region: str | None = None,
        poll_interval_s: float = 2.0,
        machine_id: str | None = None,
        machine_name: str | None = None,
    ):
        self.client = CloudClient(
            backend_url,
            agent_token,
            machine_id=machine_id,
            machine_name=machine_name,
        )
        self.bench_path = Path(bench_path).expanduser().resolve()
        self.bench_id = bench_id
        self.bench_tags = bench_tags or []
        self.agent_name = agent_name
        self.region = region
        self.poll_interval_s = poll_interval_s

    def start(self) -> None:
        import time

        while True:
            try:
                self.loop_once()
            except KeyboardInterrupt:
                raise
            except Exception as exc:
                print(f"Agent loop error: {type(exc).__name__}: {exc}")
            time.sleep(self.poll_interval_s)

    def _sync_current_bench(self, *, status: str = "idle", current_run_id: str | None = None) -> None:
        bench_summary = load_bench_for_cloud(
            self.bench_path,
            bench_id=self.bench_id,
            tags=self.bench_tags,
        )
        bench_summary["status"] = status
        bench_summary["current_run_id"] = current_run_id
        self.client.sync_benches([bench_summary])

    def _heartbeat_and_sync(self, *, status: str = "idle", current_run_id: str | None = None) -> None:
        self.client.heartbeat(agent_name=self.agent_name, region=self.region)
        self._sync_current_bench(status=status, current_run_id=current_run_id)

    def loop_once(self) -> None:
        self._heartbeat_and_sync(status="idle", current_run_id=None)

        assignment = self.client.get_assignment()
        if not assignment:
            return

        self.execute_run(assignment)

    def execute_run(self, assignment: dict[str, Any]) -> None:
        run_id = str(assignment["run_id"])
        started_at = _utc_now()

        stop_heartbeat = threading.Event()

        def _heartbeat_while_running() -> None:
            while not stop_heartbeat.wait(10.0):
                try:
                    self._heartbeat_and_sync(status="busy", current_run_id=run_id)
                except Exception as exc:
                    print(f"Heartbeat warning during run {run_id}: {type(exc).__name__}: {exc}")

        heartbeat_thread = threading.Thread(target=_heartbeat_while_running, daemon=True)

        try:
            self._heartbeat_and_sync(status="busy", current_run_id=run_id)
        except Exception as exc:
            print(f"Initial busy sync warning for run {run_id}: {type(exc).__name__}: {exc}")

        heartbeat_thread.start()

        try:
            with tempfile.TemporaryDirectory(prefix=f"benchci-cloud-{run_id}-") as td:
                tmpdir = Path(td)
                suite_path = tmpdir / "suite.yaml"
                suite_path.write_text(assignment["suite_yaml"], encoding="utf-8")

                artifact_path: Path | None = None
                artifact_b64 = assignment.get("artifact_base64")
                artifact_name = assignment.get("artifact_filename")

                if artifact_b64:
                    if not artifact_name:
                        raise RuntimeError("Assignment contains artifact_base64 but no artifact_filename")
                    artifact_path = tmpdir / Path(str(artifact_name)).name
                    artifact_path.write_bytes(base64.b64decode(artifact_b64))

                results_dir = tmpdir / "results"

                def _event_cb(event: dict[str, Any]) -> None:
                    try:
                        self.client.send_events(run_id, [event])
                    except Exception as exc:
                        print(f"Event upload warning for run {run_id}: {type(exc).__name__}: {exc}")

                exit_code: int | None = None
                status = "failed"
                error: str | None = None

                try:
                    exit_code = int(
                        run_local(
                            bench_path=self.bench_path,
                            suite_path=suite_path,
                            artifact_path=artifact_path,
                            skip_flash=bool(assignment.get("skip_flash", False)),
                            out_dir=results_dir,
                            event_cb=_event_cb,
                            verbose=bool(assignment.get("verbose", False)),
                        )
                    )
                    status = "done" if exit_code == 0 else "failed"
                    if exit_code != 0:
                        error = f"Run exited with non-zero exit code: {exit_code}"
                except Exception as exc:
                    status = "failed"
                    exit_code = 1
                    error = f"{type(exc).__name__}: {exc}"
                    try:
                        self.client.send_events(
                            run_id,
                            [
                                {
                                    "timestamp": _utc_now(),
                                    "event_type": "run.failed",
                                    "message": error,
                                    "data": {},
                                }
                            ],
                        )
                    except Exception:
                        pass

                artifact_zip = tmpdir / "artifacts.zip"
                if results_dir.exists():
                    _zip_dir(results_dir, artifact_zip)
                else:
                    artifact_zip.write_bytes(b"")

                try:
                    self.client.upload_artifacts(run_id, artifact_zip)
                except Exception as exc:
                    if error:
                        error = f"{error}; artifact upload failed: {type(exc).__name__}: {exc}"
                    else:
                        error = f"Artifact upload failed: {type(exc).__name__}: {exc}"
                    status = "failed"

                self.client.complete_run(
                    run_id,
                    status=status,
                    exit_code=exit_code,
                    error=error,
                    started_at=started_at,
                    finished_at=_utc_now(),
                )
        finally:
            stop_heartbeat.set()
            heartbeat_thread.join(timeout=2.0)

            try:
                self._heartbeat_and_sync(status="idle", current_run_id=None)
            except Exception as exc:
                print(f"Final idle sync warning for run {run_id}: {type(exc).__name__}: {exc}")
