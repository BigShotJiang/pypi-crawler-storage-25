from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Literal

from pydantic import BaseModel, Field


RunStatus = Literal[
    "queued",
    "preparing",
    "running",
    "uploading_artifacts",
    "done",
    "failed",
]


class BenchCapabilitySummary(BaseModel):
    """Machine-readable bench capability summary."""
    transports: list[str] = Field(default_factory=list)
    has_gpio: bool = False
    flash_backends: list[str] = Field(default_factory=list)
    node_count: int = 0


class BenchSummary(BaseModel):
    """API representation of a registered bench."""
    bench_id: str
    agent_id: str
    name: str
    description: str | None = None
    tags: list[str] = Field(default_factory=list)
    status: Literal["idle", "busy"] = "idle"
    current_run_id: str | None = None
    capabilities: BenchCapabilitySummary


class RunEvent(BaseModel):
    """Structured event emitted during a run lifecycle."""
    timestamp: str
    event_type: str
    message: str | None = None
    data: dict[str, Any] = Field(default_factory=dict)


@dataclass
class RunRecord:
    """Internal mutable run state stored by the agent."""
    run_id: str
    status: RunStatus

    mode: Literal["registered", "uploaded"]
    bench_id: str | None = None

    skip_flash: bool = False
    verbose: bool = False
    artifact_relpath: str | None = None

    exit_code: int | None = None
    error: str | None = None

    run_dir: str | None = None
    result_dir: str | None = None

    created_at: str = ""
    started_at: str | None = None
    finished_at: str | None = None

    current_test: str | None = None
    current_step: str | None = None

    events: list[RunEvent] = field(default_factory=list)


class RegisteredRunRequest(BaseModel):
    """POST /v1/runs/json mode for a registered bench."""
    bench_id: str = Field(..., min_length=1)
    suite_yaml: str = Field(..., min_length=1, description="Suite YAML content.")
    artifact_relpath: str | None = Field(
        None,
        description="Artifact filename to use under the run directory.",
    )
    artifact_filename: str | None = Field(
        None,
        description="Original uploaded artifact filename for registered-bench JSON mode.",
    )
    artifact_base64: str | None = Field(
        None,
        description="Base64-encoded artifact content for registered-bench JSON mode.",
    )
    skip_flash: bool = False
    verbose: bool = False


class RunStatusResponse(BaseModel):
    """Public response shape for run status."""
    run_id: str
    status: RunStatus
    mode: Literal["registered", "uploaded"]
    bench_id: str | None = None
    exit_code: int | None = None
    error: str | None = None
    created_at: str
    started_at: str | None = None
    finished_at: str | None = None
    current_test: str | None = None
    current_step: str | None = None
    queue_depth: int = 0
