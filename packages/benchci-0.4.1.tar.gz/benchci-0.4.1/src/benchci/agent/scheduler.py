from __future__ import annotations

import asyncio
from dataclasses import dataclass


@dataclass
class ScheduledRun:
    run_id: str
    bench_id: str | None


class RunScheduler:
    """Simple in-memory scheduler with one queue and per-bench locks."""
    def __init__(self) -> None:
        self._queue: asyncio.Queue[ScheduledRun] = asyncio.Queue()
        self._bench_locks: dict[str, asyncio.Lock] = {}

    def ensure_bench(self, bench_id: str) -> None:
        if bench_id not in self._bench_locks:
            self._bench_locks[bench_id] = asyncio.Lock()

    async def submit(self, run_id: str, bench_id: str | None) -> None:
        if bench_id is not None:
            self.ensure_bench(bench_id)
        await self._queue.put(ScheduledRun(run_id=run_id, bench_id=bench_id))

    async def next_run(self) -> ScheduledRun:
        return await self._queue.get()

    def task_done(self) -> None:
        self._queue.task_done()

    def queue_depth(self) -> int:
        return self._queue.qsize()

    def bench_lock(self, bench_id: str) -> asyncio.Lock:
        self.ensure_bench(bench_id)
        return self._bench_locks[bench_id]