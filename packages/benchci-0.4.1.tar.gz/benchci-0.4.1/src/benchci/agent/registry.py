from __future__ import annotations

from dataclasses import dataclass

from benchci.agent.config import RegisteredBenchRecord
from benchci.agent.models import BenchCapabilitySummary, BenchSummary


@dataclass
class BenchRegistry:
    """In-memory registry of benches known to this agent."""
    agent_id: str
    benches: dict[str, RegisteredBenchRecord]

    @classmethod
    def from_records(
        cls,
        agent_id: str,
        records: list[RegisteredBenchRecord],
    ) -> "BenchRegistry":
        return cls(
            agent_id=agent_id,
            benches={record.id: record for record in records},
        )

    def list_ids(self) -> list[str]:
        return sorted(self.benches.keys())

    def list_records(self) -> list[RegisteredBenchRecord]:
        return [self.benches[k] for k in self.list_ids()]

    def get(self, bench_id: str) -> RegisteredBenchRecord | None:
        return self.benches.get(bench_id)

    def require(self, bench_id: str) -> RegisteredBenchRecord:
        rec = self.get(bench_id)
        if rec is None:
            known = ", ".join(self.list_ids()) or "<none>"
            raise RuntimeError(f"Unknown bench_id '{bench_id}'. Known benches: {known}")
        return rec

    def _capabilities_for(self, rec: RegisteredBenchRecord) -> BenchCapabilitySummary:
        transports: set[str] = set()
        flash_backends: set[str] = set()
        has_gpio = False

        for node_cfg in rec.bench.nodes.values():
            for transport_cfg in node_cfg.transports.values():
                transports.add(transport_cfg.backend)

            if node_cfg.flash is not None:
                flash_backends.add(node_cfg.flash.backend)

            if node_cfg.gpio:
                has_gpio = True

        return BenchCapabilitySummary(
            transports=sorted(transports),
            has_gpio=has_gpio,
            flash_backends=sorted(flash_backends),
            node_count=len(rec.bench.nodes),
        )

    def to_summary(
        self,
        rec: RegisteredBenchRecord,
        *,
        status: str = "idle",
        current_run_id: str | None = None,
    ) -> BenchSummary:
        return BenchSummary(
            bench_id=rec.id,
            agent_id=self.agent_id,
            name=rec.bench.bench.name,
            description=rec.bench.bench.description,
            tags=list(rec.tags),
            status="busy" if status == "busy" else "idle",
            current_run_id=current_run_id,
            capabilities=self._capabilities_for(rec),
        )

    def list_summaries(
        self,
        *,
        bench_status: dict[str, str] | None = None,
        current_run_by_bench: dict[str, str | None] | None = None,
    ) -> list[BenchSummary]:
        bench_status = bench_status or {}
        current_run_by_bench = current_run_by_bench or {}

        return [
            self.to_summary(
                rec,
                status=bench_status.get(rec.id, "idle"),
                current_run_id=current_run_by_bench.get(rec.id),
            )
            for rec in self.list_records()
        ]