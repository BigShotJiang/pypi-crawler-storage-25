from __future__ import annotations

from pathlib import Path
from typing import Any

import yaml
from pydantic import BaseModel, Field, model_validator


# =========================
# Common rule models
# =========================

class ResetRule(BaseModel):
    """Reset a specific node."""
    node: str = Field(..., min_length=1, description="Target node name from bench.nodes.")


class StepReset(BaseModel):
    """Reset the target node."""
    reset: ResetRule


class StepSleepMs(BaseModel):
    """Sleep for a number of milliseconds."""
    sleep_ms: int = Field(..., ge=0, description="Milliseconds to sleep.")


# =========================
# UART / text transport
# =========================

class SendUartRule(BaseModel):
    """Send a string over a named UART/text transport on a specific node."""
    node: str = Field(..., min_length=1, description="Target node name from bench.nodes.")
    transport: str = Field(..., min_length=1, description="Named transport on the target node.")
    data: str = Field(..., min_length=1, description="Text to transmit.")


class StepSendUart(BaseModel):
    """Send a string over UART/text transport."""
    send_uart: SendUartRule


class ExpectUartRule(BaseModel):
    """Expectation rule for text output on a named transport."""
    node: str = Field(..., min_length=1, description="Target node name from bench.nodes.")
    transport: str = Field(..., min_length=1, description="Named transport on the target node.")
    contains: str | None = Field(None, description="Substring expected in received text.")
    regex: str | None = Field(None, description="Regex expected to match received text.")
    within_ms: int = Field(..., gt=0, description="Timeout in milliseconds.")

    @model_validator(mode="after")
    def _check_contains_or_regex(self) -> "ExpectUartRule":
        if (self.contains is None) == (self.regex is None):
            raise ValueError("expect_uart must define exactly one of: contains or regex")
        return self


class StepExpectUart(BaseModel):
    """Wait for text output to match an expectation rule."""
    expect_uart: ExpectUartRule


# =========================
# Flashing
# =========================

class FlashRule(BaseModel):
    """Flash a specific node using the node's configured flash backend."""
    node: str = Field(..., min_length=1, description="Target node name from bench.nodes.")
    artifact: str | None = Field(
        None,
        description="Optional artifact override. If omitted, node.flash.artifact is used.",
    )


class StepFlash(BaseModel):
    """Flash a node."""
    flash: FlashRule


# =========================
# Modbus
# =========================

class ModbusReadHoldingRegistersRule(BaseModel):
    node: str = Field(..., min_length=1, description="Target node name from bench.nodes.")
    transport: str = Field(..., min_length=1, description="Named Modbus transport on the target node.")
    slave: int | None = Field(None, ge=1, le=247)
    address: int = Field(..., ge=0)
    count: int = Field(..., gt=0)
    expect: list[int] = Field(..., min_length=1)


class StepModbusReadHoldingRegisters(BaseModel):
    modbus_read_holding_registers: ModbusReadHoldingRegistersRule


class ModbusWriteSingleRegisterRule(BaseModel):
    node: str = Field(..., min_length=1, description="Target node name from bench.nodes.")
    transport: str = Field(..., min_length=1, description="Named Modbus transport on the target node.")
    slave: int | None = Field(None, ge=1, le=247)
    address: int = Field(..., ge=0)
    value: int = Field(...)


class StepModbusWriteSingleRegister(BaseModel):
    modbus_write_single_register: ModbusWriteSingleRegisterRule


class ModbusReadCoilsRule(BaseModel):
    node: str = Field(..., min_length=1, description="Target node name from bench.nodes.")
    transport: str = Field(..., min_length=1, description="Named Modbus transport on the target node.")
    slave: int | None = Field(None, ge=1, le=247)
    address: int = Field(..., ge=0)
    count: int = Field(..., gt=0)
    expect: list[bool] = Field(..., min_length=1)


class StepModbusReadCoils(BaseModel):
    modbus_read_coils: ModbusReadCoilsRule


class ModbusWriteSingleCoilRule(BaseModel):
    node: str = Field(..., min_length=1, description="Target node name from bench.nodes.")
    transport: str = Field(..., min_length=1, description="Named Modbus transport on the target node.")
    slave: int | None = Field(None, ge=1, le=247)
    address: int = Field(..., ge=0)
    value: bool = Field(...)


class StepModbusWriteSingleCoil(BaseModel):
    modbus_write_single_coil: ModbusWriteSingleCoilRule


# =========================
# GPIO
# =========================

class GpioSetRule(BaseModel):
    """Drive a named GPIO line on a node to a logical value."""
    node: str = Field(..., min_length=1, description="Target node name from bench.nodes.")
    line: str = Field(..., min_length=1, description="Logical GPIO line name from node.gpio.")
    value: bool = Field(..., description="Logical GPIO value to drive.")


class StepGpioSet(BaseModel):
    gpio_set: GpioSetRule


class GpioGetRule(BaseModel):
    """Read the current logical value of a GPIO line."""
    node: str = Field(..., min_length=1, description="Target node name from bench.nodes.")
    line: str = Field(..., min_length=1, description="Logical GPIO line name from node.gpio.")
    expect: bool | None = Field(
        None,
        description="Optional expected logical value. If provided, the step fails if the value does not match.",
    )


class StepGpioGet(BaseModel):
    gpio_get: GpioGetRule


class GpioExpectRule(BaseModel):
    """Wait until a GPIO line reaches the requested logical value."""
    node: str = Field(..., min_length=1, description="Target node name from bench.nodes.")
    line: str = Field(..., min_length=1, description="Logical GPIO line name from node.gpio.")
    value: bool = Field(..., description="Expected logical GPIO value.")
    within_ms: int = Field(..., gt=0, description="Timeout in milliseconds.")


class StepGpioExpect(BaseModel):
    gpio_expect: GpioExpectRule


class GpioWaitEdgeRule(BaseModel):
    """Wait until an edge is observed on a GPIO line."""
    node: str = Field(..., min_length=1, description="Target node name from bench.nodes.")
    line: str = Field(..., min_length=1, description="Logical GPIO line name from node.gpio.")
    edge: str = Field(..., description="Edge to wait for: rising, falling, or both.")
    within_ms: int = Field(..., gt=0, description="Timeout in milliseconds.")

    @model_validator(mode="after")
    def _validate_edge(self) -> "GpioWaitEdgeRule":
        allowed = {"rising", "falling", "both"}
        if self.edge not in allowed:
            raise ValueError(f"gpio_wait_edge.edge must be one of: {sorted(allowed)}")
        return self


class StepGpioWaitEdge(BaseModel):
    gpio_wait_edge: GpioWaitEdgeRule




# =========================
# Bench power control
# =========================

class PowerSetRule(BaseModel):
    """Set a bench-level power outlet on or off."""
    resource: str = Field(..., min_length=1, description="Bench resource name from bench.resources.")
    outlet: str = Field(..., min_length=1, description="Logical outlet name defined by the resource driver.")
    state: bool = Field(..., description="Requested power state: true=on, false=off.")


class StepPowerSet(BaseModel):
    power_set: PowerSetRule


class PowerCycleRule(BaseModel):
    """Power-cycle a bench-level outlet."""
    resource: str = Field(..., min_length=1, description="Bench resource name from bench.resources.")
    outlet: str = Field(..., min_length=1, description="Logical outlet name defined by the resource driver.")
    off_ms: int = Field(1000, ge=0, description="Time to keep power off before turning it back on.")
    on_settle_ms: int = Field(1000, ge=0, description="Delay after power is turned back on.")


class StepPowerCycle(BaseModel):
    power_cycle: PowerCycleRule

# =========================
# CAN
# =========================

class CanFrameRule(BaseModel):
    """Raw CAN frame description."""
    id: int = Field(..., ge=0, description="CAN identifier.")
    extended: bool = Field(False, description="Whether the CAN ID is extended (29-bit).")
    data: str = Field(
        ...,
        min_length=1,
        description='Frame data bytes as hex string, e.g. "01 02 0A FF".',
    )


class SendCanRule(BaseModel):
    """Send a CAN frame over a named CAN transport on a node."""
    node: str = Field(..., min_length=1, description="Target node name from bench.nodes.")
    transport: str = Field(..., min_length=1, description="Named CAN transport on the target node.")
    frame: CanFrameRule


class StepSendCan(BaseModel):
    send_can: SendCanRule


class ExpectCanRule(BaseModel):
    """Wait for a CAN frame on a named CAN transport."""
    node: str = Field(..., min_length=1, description="Target node name from bench.nodes.")
    transport: str = Field(..., min_length=1, description="Named CAN transport on the target node.")
    frame: CanFrameRule
    within_ms: int = Field(..., gt=0, description="Timeout in milliseconds.")


class StepExpectCan(BaseModel):
    expect_can: ExpectCanRule


# =========================
# Step union
# =========================

StepModel = (
    StepReset
    | StepSleepMs
    | StepFlash
    | StepSendUart
    | StepExpectUart
    | StepModbusReadHoldingRegisters
    | StepModbusWriteSingleRegister
    | StepModbusReadCoils
    | StepModbusWriteSingleCoil
    | StepGpioSet
    | StepGpioGet
    | StepGpioExpect
    | StepGpioWaitEdge
    | StepPowerSet
    | StepPowerCycle
    | StepSendCan
    | StepExpectCan
)


def _parse_step(step: Any) -> StepModel:
    """Parse a raw YAML step into the correct step model."""
    if not isinstance(step, dict):
        raise ValueError(f"step must be a mapping, got {type(step).__name__}")

    if len(step) != 1:
        raise ValueError(f"step must have exactly one action key, got keys: {list(step.keys())}")

    key = next(iter(step.keys()))
    val = step[key]

    if key == "reset":
        if not isinstance(val, dict):
            raise ValueError("reset step value must be a mapping (dict)")
        return StepReset(reset=ResetRule.model_validate(val))

    if key == "sleep_ms":
        return StepSleepMs(sleep_ms=val)

    if key == "flash":
        if not isinstance(val, dict):
            raise ValueError("flash step value must be a mapping (dict)")
        return StepFlash(flash=FlashRule.model_validate(val))

    if key == "send_uart":
        if not isinstance(val, dict):
            raise ValueError("send_uart step value must be a mapping (dict)")
        return StepSendUart(send_uart=SendUartRule.model_validate(val))

    if key == "expect_uart":
        if not isinstance(val, dict):
            raise ValueError("expect_uart step value must be a mapping (dict)")
        return StepExpectUart(expect_uart=ExpectUartRule.model_validate(val))

    if key == "modbus_read_holding_registers":
        if not isinstance(val, dict):
            raise ValueError("modbus_read_holding_registers step value must be a mapping (dict)")
        return StepModbusReadHoldingRegisters(
            modbus_read_holding_registers=ModbusReadHoldingRegistersRule.model_validate(val)
        )

    if key == "modbus_write_single_register":
        if not isinstance(val, dict):
            raise ValueError("modbus_write_single_register step value must be a mapping (dict)")
        return StepModbusWriteSingleRegister(
            modbus_write_single_register=ModbusWriteSingleRegisterRule.model_validate(val)
        )

    if key == "modbus_read_coils":
        if not isinstance(val, dict):
            raise ValueError("modbus_read_coils step value must be a mapping (dict)")
        return StepModbusReadCoils(
            modbus_read_coils=ModbusReadCoilsRule.model_validate(val)
        )

    if key == "modbus_write_single_coil":
        if not isinstance(val, dict):
            raise ValueError("modbus_write_single_coil step value must be a mapping (dict)")
        return StepModbusWriteSingleCoil(
            modbus_write_single_coil=ModbusWriteSingleCoilRule.model_validate(val)
        )

    if key == "gpio_set":
        if not isinstance(val, dict):
            raise ValueError("gpio_set step value must be a mapping (dict)")
        return StepGpioSet(gpio_set=GpioSetRule.model_validate(val))

    if key == "gpio_get":
        if not isinstance(val, dict):
            raise ValueError("gpio_get step value must be a mapping (dict)")
        return StepGpioGet(gpio_get=GpioGetRule.model_validate(val))

    if key == "gpio_expect":
        if not isinstance(val, dict):
            raise ValueError("gpio_expect step value must be a mapping (dict)")
        return StepGpioExpect(gpio_expect=GpioExpectRule.model_validate(val))

    if key == "gpio_wait_edge":
        if not isinstance(val, dict):
            raise ValueError("gpio_wait_edge step value must be a mapping (dict)")
        return StepGpioWaitEdge(gpio_wait_edge=GpioWaitEdgeRule.model_validate(val))

    if key == "power_set":
        if not isinstance(val, dict):
            raise ValueError("power_set step value must be a mapping (dict)")
        return StepPowerSet(power_set=PowerSetRule.model_validate(val))

    if key == "power_cycle":
        if not isinstance(val, dict):
            raise ValueError("power_cycle step value must be a mapping (dict)")
        return StepPowerCycle(power_cycle=PowerCycleRule.model_validate(val))

    if key == "send_can":
        if not isinstance(val, dict):
            raise ValueError("send_can step value must be a mapping (dict)")
        return StepSendCan(send_can=SendCanRule.model_validate(val))

    if key == "expect_can":
        if not isinstance(val, dict):
            raise ValueError("expect_can step value must be a mapping (dict)")
        return StepExpectCan(expect_can=ExpectCanRule.model_validate(val))

    raise ValueError(f"unknown step action: {key}")


class TestCase(BaseModel):
    """A named test consisting of an ordered list of steps."""
    name: str = Field(..., min_length=1)
    steps: list[StepModel] = Field(default_factory=list)

    @model_validator(mode="before")
    @classmethod
    def _parse_steps(cls, data: Any) -> Any:
        if not isinstance(data, dict):
            return data

        name = data.get("name", "<unnamed>")
        raw_steps = data.get("steps", [])

        if not isinstance(raw_steps, list):
            raise ValueError(f"tests[{name}].steps must be a list")

        parsed: list[StepModel] = []
        for i, s in enumerate(raw_steps):
            try:
                parsed.append(_parse_step(s))
            except Exception as e:
                raise ValueError(f"tests[{name}].steps[{i}]: {e}") from e

        data["steps"] = parsed
        return data


class SuiteMeta(BaseModel):
    """Top-level suite metadata."""
    name: str = Field(..., min_length=1)
    description: str | None = Field(None, description="Optional suite description.")


class SuiteConfig(BaseModel):
    """A suite is a collection of test cases executed in order."""
    version: str = Field(..., description="Suite config schema version.")
    suite: SuiteMeta = Field(..., description="Suite metadata.")
    tests: list[TestCase] = Field(default_factory=list)


def load_suite_config(path: str | Path) -> SuiteConfig:
    """Load and validate a suite YAML file."""
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(p)
    data = yaml.safe_load(p.read_text(encoding="utf-8")) or {}
    return SuiteConfig.model_validate(data)