from __future__ import annotations

from pathlib import Path
from typing import Annotated, Literal, Union

import yaml
from pydantic import BaseModel, Field, model_validator


# =========================
# Bench metadata / defaults
# =========================

class BenchMeta(BaseModel):
    """Top-level bench metadata."""
    name: str = Field(..., description="Human-friendly bench name.")
    description: str | None = Field(None, description="Optional bench description.")


class TimeoutDefaults(BaseModel):
    """Default timeout values that suite steps may inherit."""
    within_ms: int | None = Field(
        None,
        gt=0,
        description="Default timeout in milliseconds for wait/expect operations.",
    )


class BenchDefaults(BaseModel):
    """Optional defaults used by suites/runners."""
    node: str | None = Field(
        None,
        description="Default node name used when a suite step omits node.",
    )
    timeouts: TimeoutDefaults | None = Field(
        None,
        description="Optional default timeout values.",
    )


class ArtifactConfig(BaseModel):
    """Artifact output configuration."""
    root_dir: str = Field(
        "benchci-results",
        description="Root directory where run artifacts are written.",
    )
    per_node_dirs: bool = Field(
        True,
        description="If true, write artifacts into separate per-node subdirectories.",
    )


# =========================
# Flashing configuration
# =========================

class FlashBase(BaseModel):
    """Base model for flashing configuration."""
    backend: str
    artifact: str | None = Field(
        None,
        description="Optional default firmware artifact path for this node.",
    )


class FlashOpenOCD(FlashBase):
    """OpenOCD flashing backend configuration."""
    backend: Literal["openocd"] = "openocd"

    interface_cfg: str = Field(
        ...,
        description="OpenOCD interface cfg, e.g. 'interface/stlink.cfg' or 'interface/jlink.cfg'",
    )
    target_cfg: str = Field(
        ...,
        description="OpenOCD target cfg, e.g. 'target/stm32f4x.cfg' or 'target/stm32wlx.cfg'",
    )
    extra_args: list[str] = Field(
        default_factory=list,
        description="Extra arguments appended to the openocd command (advanced use).",
    )
    adapter_speed_khz: int | None = Field(
        None,
        description="SWD/JTAG adapter speed in kHz (optional).",
    )
    probe_serial: str | None = Field(
        None,
        description="Probe serial number (default behavior uses OpenOCD 'hla_serial <SN>').",
    )
    probe_serial_cmd: str | None = Field(
        None,
        description="Advanced: full OpenOCD command to select probe serial (e.g. 'jlink serial 12345678').",
    )


class FlashCubeProg(FlashBase):
    """STM32CubeProgrammer CLI flashing backend configuration."""
    backend: Literal["cubeprog"] = "cubeprog"

    port: str = Field("SWD", description="Connection port (e.g. SWD or USB).")
    serial: str | None = Field(None, description="Optional ST-Link serial number.")


class FlashJLink(FlashBase):
    """SEGGER J-Link flashing backend configuration."""
    backend: Literal["jlink"] = "jlink"

    device: str = Field(
        ...,
        description="Target MCU name understood by JLinkExe, e.g. STM32F407VG.",
    )
    interface: Literal["SWD", "JTAG"] = Field("SWD", description="Debug interface.")
    speed_khz: int = Field(4000, description="J-Link speed in kHz.")
    serial: str | None = Field(None, description="Optional J-Link serial number.")


class FlashEspTool(FlashBase):
    """ESP32/ESP-family flashing backend via esptool.py."""
    backend: Literal["esptool"] = "esptool"

    port: str = Field(..., description="Serial device path used for flashing.")
    baud: int = Field(921600, description="Flashing baud rate.")
    chip: str | None = Field(
        None,
        description="Optional chip name, e.g. esp32, esp32s3.",
    )
    offset: str = Field(
        "0x10000",
        description="Default flash offset when writing a single app image.",
    )
    extra_args: list[str] = Field(
        default_factory=list,
        description="Extra arguments appended to esptool.py.",
    )


FlashConfig = Annotated[
    Union[FlashOpenOCD, FlashCubeProg, FlashJLink, FlashEspTool],
    Field(discriminator="backend"),
]


# =========================
# Reset configuration
# =========================

class ResetConfig(BaseModel):
    """How BenchCI should reset the node between steps/tests."""
    method: Literal["openocd", "cubeprog", "jlink", "esptool", "none"] = Field(
        "none",
        description="Reset strategy: 'openocd', 'cubeprog', 'jlink', 'esptool', or 'none'.",
    )


# =========================
# Transport configuration
# =========================

class TransportBase(BaseModel):
    """Base model for communication transport configuration."""
    backend: str


class TransportUart(TransportBase):
    """UART text transport configuration."""
    backend: Literal["uart"] = "uart"

    port: str = Field(..., description="Serial device path (e.g. /dev/ttyUSB0 or COM3).")
    baud: int = Field(115200, description="UART baud rate.")
    timeout_ms: int = Field(100, description="Read timeout in milliseconds used by the test runner.")


class TransportModbusRtu(TransportBase):
    """Modbus RTU transport configuration."""
    backend: Literal["modbus_rtu"] = "modbus_rtu"

    port: str = Field(..., description="RS485/serial device path (e.g. /dev/ttyUSB0 or COM3).")
    baud: int = Field(9600, description="Modbus RTU baud rate.")
    timeout_ms: int = Field(500, description="Modbus request timeout in milliseconds.")
    default_slave: int = Field(1, ge=1, le=247, description="Default Modbus slave/unit ID.")


class TransportModbusTcp(TransportBase):
    """Modbus TCP transport configuration."""
    backend: Literal["modbus_tcp"] = "modbus_tcp"

    host: str = Field(..., description="Target host or IP address (e.g. 192.168.1.50).")
    port: int = Field(502, ge=1, le=65535, description="Modbus TCP port.")
    timeout_ms: int = Field(1000, description="Modbus request timeout in milliseconds.")
    default_slave: int = Field(1, ge=1, le=247, description="Default Modbus slave/unit ID.")


class TransportCan(TransportBase):
    """CAN transport configuration."""
    backend: Literal["can"] = "can"

    interface: str = Field(..., description="CAN interface name, e.g. can0, can1, vcan0.")
    bitrate: int = Field(..., gt=0, description="CAN bitrate in bits per second.")
    timeout_ms: int = Field(500, description="Receive timeout in milliseconds.")


TransportConfig = Annotated[
    Union[TransportUart, TransportModbusRtu, TransportModbusTcp, TransportCan],
    Field(discriminator="backend"),
]


# =========================
# GPIO configuration
# =========================

class GpioBase(BaseModel):
    """Base model for GPIO line configuration."""
    backend: str
    direction: Literal["input", "output"] = Field(
        ...,
        description="GPIO line direction.",
    )
    active_high: bool = Field(
        True,
        description="If true, logical true maps to physical high. If false, logical true maps to physical low.",
    )
    bias: Literal["disabled", "pull_up", "pull_down"] | None = Field(
        None,
        description="Optional GPIO bias configuration for supported input-capable backends.",
    )
    edge: Literal["rising", "falling", "both"] | None = Field(
        None,
        description="Optional edge detection mode for supported input-capable backends.",
    )


class GpioMock(GpioBase):
    """Mock GPIO backend used for development and testing."""
    backend: Literal["mock_gpio"] = "mock_gpio"
    channel: int = Field(..., ge=0, description="Mock GPIO channel number.")


class GpioLocal(GpioBase):
    """Linux local GPIO backend using gpiochip character device."""
    backend: Literal["local_gpio"] = "local_gpio"
    chip: str = Field(
        ...,
        description="GPIO chip device path, e.g. /dev/gpiochip0.",
    )
    line: int = Field(
        ...,
        ge=0,
        description="GPIO line number within the selected chip.",
    )


class GpioRemote(GpioBase):
    """Remote Linux GPIO backend served by a BenchCI-compatible GPIO service."""
    backend: Literal["remote_gpio"] = "remote_gpio"
    host: str = Field(
        ...,
        description="Remote GPIO host or IP address, e.g. 192.168.1.60.",
    )
    port: int = Field(
        8090,
        ge=1,
        le=65535,
        description="Remote GPIO service port.",
    )
    token_env: str = Field(
        ...,
        description="Environment variable name containing the remote GPIO access token.",
    )
    chip: str = Field(
        ...,
        description="Remote GPIO chip device path, e.g. /dev/gpiochip0.",
    )
    line: int = Field(
        ...,
        ge=0,
        description="GPIO line number within the selected remote chip.",
    )


GpioConfig = Annotated[
    Union[GpioMock, GpioLocal, GpioRemote],
    Field(discriminator="backend"),
]


# =========================
# Bench resources
# =========================

class ResourceDriverBase(BaseModel):
    type: str


class ResourceDriverScpi(ResourceDriverBase):
    type: Literal["scpi"] = "scpi"
    address: str = Field(..., description="SCPI resource address, e.g. tcp://192.168.1.50:5025")


class ResourceDriverGpio(ResourceDriverBase):
    type: Literal["gpio"] = "gpio"
    chip: str = Field(..., description="GPIO chip device path used by the resource controller.")


class ResourceDriverUsbRelaySerialBase(ResourceDriverBase):
    """Base config for vendor-specific USB relay modules controlled over serial."""
    type: Literal["usb_relay_serial"] = "usb_relay_serial"
    vendor: str
    model: str
    port: str = Field(..., description="Serial device path for the relay module, e.g. /dev/ttyUSB0 or COM3.")
    baud: int = Field(9600, gt=0, description="Serial baud rate used by the relay module.")
    timeout_ms: int = Field(500, gt=0, description="Serial command timeout in milliseconds.")
    outlets: dict[str, str] = Field(
        default_factory=dict,
        min_length=1,
        description="Logical outlet name -> driver channel/identifier mapping.",
    )
    on_settle_ms: int = Field(1000, ge=0, description="Delay after turning power on.")
    off_settle_ms: int = Field(250, ge=0, description="Delay after turning power off.")


class ResourceDriverUsbRelaySerialLcus1(ResourceDriverUsbRelaySerialBase):
    """LCUS-1 single-channel USB relay module over serial."""
    type: Literal["usb_relay_serial"] = "usb_relay_serial"
    vendor: Literal["lcus"] = "lcus"
    model: Literal["lcus_1"] = "lcus_1"
    baud: int = Field(9600, gt=0, description="LCUS-1 serial baud rate.")
    channel_on_value: str = Field(
        "1",
        description="Driver channel value representing the LCUS-1 relay output.",
    )

    @model_validator(mode="after")
    def _validate_lcus1_outlets(self) -> "ResourceDriverUsbRelaySerialLcus1":
        allowed_values = {"1"}
        bad: list[str] = []

        for outlet_name, channel in self.outlets.items():
            if channel not in allowed_values:
                bad.append(f"{outlet_name}={channel}")

        if bad:
            raise ValueError(
                "LCUS-1 is a single-channel relay. All outlets must map to channel '1'. "
                f"Invalid mappings: {', '.join(bad)}"
            )

        return self


ResourceDriverConfig = Annotated[
    Union[
        ResourceDriverScpi,
        ResourceDriverGpio,
        ResourceDriverUsbRelaySerialLcus1,
    ],
    Field(discriminator="type"),
]


class ResourceConfig(BaseModel):
    """Shared bench-level resource."""
    kind: str = Field(..., description="Resource kind, e.g. power_supply, relay_controller, power_controller.")
    driver: ResourceDriverConfig


# =========================
# Node / Bench configuration
# =========================

class NodeConfig(BaseModel):
    """A named participant in the bench workflow.

    A node can be a DUT, helper MCU, simulator peer, gateway, etc.
    """
    kind: str = Field(..., description="Node kind, e.g. mcu, simulator, gateway.")
    role: str | None = Field(None, description="Optional semantic role, e.g. primary, helper.")
    flash: FlashConfig | None = Field(None, description="Optional flashing backend for this node.")
    reset: ResetConfig = Field(default_factory=ResetConfig, description="Reset configuration for this node.")
    transports: dict[str, TransportConfig] = Field(
        default_factory=dict,
        description="Named transports available on this node.",
    )
    gpio: dict[str, GpioConfig] = Field(
        default_factory=dict,
        description="Optional named GPIO lines available on this node.",
    )
    tags: list[str] = Field(default_factory=list, description="Optional node tags.")

    @model_validator(mode="after")
    def _validate_unique_content(self) -> "NodeConfig":
        if self.flash is None and not self.transports and not self.gpio:
            raise ValueError(
                "node must define at least one of: flash, transports, gpio"
            )
        return self


class BenchConfig(BaseModel):
    """Top-level bench configuration.

    This describes the whole bench: named nodes, their flashing/reset behavior,
    transports, GPIO, optional shared resources, and artifact settings.
    """
    version: str = Field(..., description="Bench config schema version.")
    bench: BenchMeta = Field(..., description="Bench metadata.")
    defaults: BenchDefaults | None = Field(None, description="Optional bench defaults.")
    nodes: dict[str, NodeConfig] = Field(
        ...,
        min_length=1,
        description="Named nodes available in this bench.",
    )
    resources: dict[str, ResourceConfig] = Field(
        default_factory=dict,
        description="Optional shared bench-level resources.",
    )
    artifacts: ArtifactConfig = Field(
        default_factory=ArtifactConfig,
        description="Artifact output configuration.",
    )

    @model_validator(mode="after")
    def _validate_defaults(self) -> "BenchConfig":
        if self.defaults and self.defaults.node:
            if self.defaults.node not in self.nodes:
                raise ValueError(
                    f"defaults.node='{self.defaults.node}' does not exist in nodes"
                )
        return self


def get_bench_warnings(cfg: BenchConfig) -> list[str]:
    """Return non-fatal warnings about potentially confusing combinations."""
    warns: list[str] = []

    for node_name, node_cfg in cfg.nodes.items():
        flash_backend = getattr(node_cfg.flash, "backend", None) if node_cfg.flash else None
        reset_method = getattr(node_cfg.reset, "method", "none")

        if (
            reset_method in ("openocd", "cubeprog", "jlink", "esptool")
            and flash_backend
            and reset_method != flash_backend
        ):
            if flash_backend == "cubeprog" and reset_method == "openocd":
                warns.append(
                    f"Node '{node_name}': CubeProgrammer flashing selected, but reset uses OpenOCD. "
                    "Ensure both tools are installed or align reset.method with flash.backend."
                )
            elif flash_backend == "openocd" and reset_method == "cubeprog":
                warns.append(
                    f"Node '{node_name}': OpenOCD flashing selected, but reset uses STM32_Programmer_CLI. "
                    "Ensure both tools are installed or align reset.method with flash.backend."
                )
            elif flash_backend == "jlink" and reset_method != "jlink":
                warns.append(
                    f"Node '{node_name}': J-Link flashing selected, but reset uses a different backend. "
                    "Ensure the selected reset tool is installed and intended."
                )
            elif flash_backend == "esptool" and reset_method != "esptool":
                warns.append(
                    f"Node '{node_name}': esptool flashing selected, but reset uses a different backend. "
                    "Ensure the selected reset method is intentional."
                )
            else:
                warns.append(
                    f"Node '{node_name}': reset.method is '{reset_method}' but flash.backend is '{flash_backend}'. "
                    "Ensure the required tool is installed on the bench machine."
                )

        for line_name, gpio_cfg in node_cfg.gpio.items():
            if gpio_cfg.direction == "output":
                if gpio_cfg.bias is not None:
                    warns.append(
                        f"Node '{node_name}', GPIO line '{line_name}' is configured as output but also defines "
                        f"bias='{gpio_cfg.bias}'. Bias is typically only relevant for input lines."
                    )
                if gpio_cfg.edge is not None:
                    warns.append(
                        f"Node '{node_name}', GPIO line '{line_name}' is configured as output but also defines "
                        f"edge='{gpio_cfg.edge}'. Edge detection is only relevant for input lines."
                    )

            if getattr(gpio_cfg, "backend", None) == "remote_gpio":
                token_env = getattr(gpio_cfg, "token_env", "")
                if not token_env.strip():
                    warns.append(
                        f"Node '{node_name}', GPIO line '{line_name}' uses remote_gpio but token_env is empty."
                    )

    for resource_name, resource_cfg in cfg.resources.items():
        driver = resource_cfg.driver

        if isinstance(driver, ResourceDriverUsbRelaySerialLcus1):
            if driver.baud != 9600:
                warns.append(
                    f"Resource '{resource_name}': LCUS-1 is usually configured for 9600 baud, "
                    f"but bench.yaml sets baud={driver.baud}. Ensure your module is configured accordingly."
                )

            if len(driver.outlets) > 1:
                warns.append(
                    f"Resource '{resource_name}': LCUS-1 is a single-channel relay. "
                    "Multiple logical outlets may be confusing even if all map to channel '1'."
                )

    return warns


def load_bench_config(path: str | Path) -> BenchConfig:
    """Load and validate a bench YAML file."""
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(p)
    data = yaml.safe_load(p.read_text(encoding="utf-8")) or {}
    return BenchConfig.model_validate(data)