from __future__ import annotations

import time
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path

from benchci.config.bench import (
    BenchConfig,
    ResourceConfig,
    ResourceDriverUsbRelaySerialLcus1,
)


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")


def _hex_bytes(data: bytes) -> str:
    return " ".join(f"{b:02X}" for b in data)


class PowerController:
    """Abstract bench-level power controller."""

    def start(self) -> None:
        pass

    def stop(self) -> None:
        pass

    def set_state(self, outlet: str, state: bool) -> None:
        raise NotImplementedError

    def get_state(self, outlet: str) -> bool | None:
        return None

    def cycle(self, outlet: str, off_ms: int, on_settle_ms: int) -> None:
        self.set_state(outlet, False)
        time.sleep(off_ms / 1000.0)
        self.set_state(outlet, True)
        time.sleep(on_settle_ms / 1000.0)


@dataclass
class _OutletBinding:
    logical_name: str
    driver_channel: str


class UsbRelayProtocol:
    """Abstract protocol for vendor-specific USB relay modules."""

    def set_state_command(self, channel: str, state: bool) -> bytes:
        raise NotImplementedError

    def get_state_command(self, channel: str) -> bytes | None:
        return None

    def parse_state_response(self, channel: str, payload: bytes) -> bool | None:
        return None


class Lcus1RelayProtocol(UsbRelayProtocol):
    """Protocol implementation for LCUS-1 single-channel relay modules.

    Supported commands:
    - ON  -> A0 01 01 A2
    - OFF -> A0 01 00 A1

    State query is intentionally left unimplemented for now because board
    revisions / clones may differ in reply behavior.
    """

    def set_state_command(self, channel: str, state: bool) -> bytes:
        if channel != "1":
            raise RuntimeError(
                f"LCUS-1 supports only channel '1', got '{channel}'"
            )
        return bytes.fromhex("A0 01 01 A2") if state else bytes.fromhex("A0 01 00 A1")

    def get_state_command(self, channel: str) -> bytes | None:
        # Not implemented yet for safety across revisions/clones.
        return None

    def parse_state_response(self, channel: str, payload: bytes) -> bool | None:
        # Not implemented yet for safety across revisions/clones.
        return None


class UsbRelaySerialPowerController(PowerController):
    """Serial USB relay power controller using a vendor-specific protocol."""

    def __init__(
        self,
        resource_name: str,
        cfg: ResourceConfig,
        protocol: UsbRelayProtocol,
        log_path: Path | None = None,
    ):
        self._resource_name = resource_name
        self._cfg = cfg
        self._driver = cfg.driver
        self._protocol = protocol
        self._log_path = log_path
        self._ser = None

    def _log(self, message: str) -> None:
        if self._log_path is None:
            return
        self._log_path.parent.mkdir(parents=True, exist_ok=True)
        with self._log_path.open("a", encoding="utf-8") as f:
            f.write(f"{_utc_now()} {message}\n")

    def _require_serial(self):
        if self._ser is None:
            raise RuntimeError(
                f"Power controller for resource '{self._resource_name}' is not started"
            )
        return self._ser

    def _resolve_channel(self, outlet: str) -> str:
        channel = self._driver.outlets.get(outlet)
        if channel is None:
            known = ", ".join(sorted(self._driver.outlets.keys())) or "<none>"
            raise RuntimeError(
                f"Unknown outlet '{outlet}' for power resource '{self._resource_name}'. "
                f"Known outlets: {known}"
            )
        return channel

    def start(self) -> None:
        if self._ser is not None:
            return

        try:
            import serial  # type: ignore
        except Exception as exc:
            raise RuntimeError("pyserial is required for USB relay power control.")

        try:
            self._ser = serial.Serial(
                port=self._driver.port,
                baudrate=self._driver.baud,
                timeout=self._driver.timeout_ms / 1000.0,
                write_timeout=self._driver.timeout_ms / 1000.0,
            )
        except Exception as exc:
            raise RuntimeError("Failed to open USB relay serial port.")

        self._log(
            f"SERIAL_START resource={self._resource_name} "
            f"port={self._driver.port} baud={self._driver.baud} timeout_ms={self._driver.timeout_ms}"
        )

    def stop(self) -> None:
        if self._ser is None:
            return

        try:
            self._ser.close()
            self._log(
                f"SERIAL_STOP resource={self._resource_name} port={self._driver.port}"
            )
        except Exception as exc:
            self._log(
                f"SERIAL_STOP_ERROR resource={self._resource_name} "
                f"port={self._driver.port}"
            )
        finally:
            self._ser = None

    def _write_command(self, payload: bytes, *, action: str, outlet: str, channel: str) -> None:
        ser = self._require_serial()

        self._log(
            f"TX action={action} outlet={outlet} channel={channel} bytes={_hex_bytes(payload)}"
        )

        try:
            reset_input_buffer = getattr(ser, "reset_input_buffer", None)
            if callable(reset_input_buffer):
                reset_input_buffer()
        except Exception:
            pass

        try:
            ser.write(payload)
            ser.flush()
        except Exception as exc:
            raise RuntimeError("Failed to send USB relay command.")

    def _read_response(self, max_bytes: int = 64) -> bytes:
        ser = self._require_serial()

        try:
            data = ser.read(max_bytes)
        except Exception as exc:
            raise RuntimeError("Failed to read USB relay response.")

        if data:
            self._log(f"RX bytes={_hex_bytes(data)}")
        else:
            self._log("RX bytes=<none>")

        return bytes(data)

    def set_state(self, outlet: str, state: bool) -> None:
        channel = self._resolve_channel(outlet)
        payload = self._protocol.set_state_command(channel, state)
        action = "on" if state else "off"

        self._write_command(payload, action=action, outlet=outlet, channel=channel)

        settle_ms = self._driver.on_settle_ms if state else self._driver.off_settle_ms
        if settle_ms > 0:
            time.sleep(settle_ms / 1000.0)

    def get_state(self, outlet: str) -> bool | None:
        channel = self._resolve_channel(outlet)
        cmd = self._protocol.get_state_command(channel)
        if cmd is None:
            return None

        self._write_command(cmd, action="get", outlet=outlet, channel=channel)
        reply = self._read_response()
        return self._protocol.parse_state_response(channel, reply)


class Lcus1SerialRelayPowerController(UsbRelaySerialPowerController):
    """LCUS-1 single-channel relay power controller."""

    def __init__(
        self,
        resource_name: str,
        cfg: ResourceConfig,
        log_path: Path | None = None,
    ):
        if not isinstance(cfg.driver, ResourceDriverUsbRelaySerialLcus1):
            raise RuntimeError(
                "Lcus1SerialRelayPowerController requires ResourceDriverUsbRelaySerialLcus1"
            )
        super().__init__(
            resource_name=resource_name,
            cfg=cfg,
            protocol=Lcus1RelayProtocol(),
            log_path=log_path,
        )


class PowerManager:
    def __init__(self, controller: PowerController, outlets: dict[str, str]):
        self._controller = controller
        self._outlets = outlets

    def start(self) -> None:
        self._controller.start()

    def stop(self) -> None:
        self._controller.stop()

    def outlet_names(self) -> list[str]:
        return sorted(self._outlets.keys())

    def _require_outlet(self, outlet: str) -> None:
        if outlet not in self._outlets:
            known = ", ".join(sorted(self._outlets.keys())) or "<none>"
            raise RuntimeError(f"Unknown power outlet '{outlet}'. Known outlets: {known}")

    def set_state(self, outlet: str, state: bool) -> None:
        self._require_outlet(outlet)
        self._controller.set_state(outlet, state)

    def get_state(self, outlet: str) -> bool | None:
        self._require_outlet(outlet)
        return self._controller.get_state(outlet)

    def cycle(self, outlet: str, off_ms: int, on_settle_ms: int) -> None:
        self._require_outlet(outlet)
        self._controller.cycle(outlet, off_ms, on_settle_ms)


def create_power_manager(
    bench: BenchConfig,
    resource_name: str,
    log_path: Path | None = None,
) -> PowerManager:
    cfg = bench.resources.get(resource_name)
    if cfg is None:
        known = ", ".join(sorted(bench.resources.keys())) or "<none>"
        raise RuntimeError(f"Unknown bench resource '{resource_name}'. Known resources: {known}")

    if isinstance(cfg.driver, ResourceDriverUsbRelaySerialLcus1):
        return PowerManager(
            controller=Lcus1SerialRelayPowerController(
                resource_name=resource_name,
                cfg=cfg,
                log_path=log_path,
            ),
            outlets=dict(cfg.driver.outlets),
        )

    raise RuntimeError(
        f"Resource '{resource_name}' is not a supported power controller driver."
    )