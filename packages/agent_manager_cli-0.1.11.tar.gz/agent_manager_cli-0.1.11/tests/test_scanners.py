"""Tests for session scanners."""

import json

from am.scanners._util import read_tail
from am.scanners.claude import (
    _last_user_message,
    _slug_fallback_name,
    scan_claude_sessions,
)
from am.scanners.codex import _parse_codex_session, scan_codex_sessions
from am.scanners.gemini import _parse_gemini_project, scan_gemini_sessions


class TestUtil:
    def test_read_tail_small_file(self, tmp_path):
        f = tmp_path / "small.txt"
        f.write_text("line1\nline2\nline3\n")
        result = read_tail(f)
        assert "line1" in result
        assert "line3" in result

    def test_read_tail_large_file(self, tmp_path):
        f = tmp_path / "large.txt"
        # Write more than 64KB
        content = "x" * 100 + "\n"
        f.write_text(content * 1000)
        result = read_tail(f, max_bytes=1024)
        assert len(result) <= 1024 + 200  # some margin for partial line skip

    def test_read_tail_missing_file(self, tmp_path):
        f = tmp_path / "missing.txt"
        assert read_tail(f) == ""


class TestClaudeScanner:
    def test_slug_fallback_name(self):
        # Used only when cwd cannot be read from jsonl. Slug is lossy by
        # design — projects whose own name contains dashes lose info here.
        assert _slug_fallback_name("-Users-me-projects-MyApp") == "MyApp"
        assert _slug_fallback_name("single") == "single"
        assert _slug_fallback_name("") == ""
        # Known limitation: Trade-EUR-USD vs Trade/EUR/USD collapse to same slug.
        assert _slug_fallback_name("-Users-me-projects-Trade-EUR-USD") == "USD"

    def test_last_user_message(self, tmp_path):
        f = tmp_path / "session.jsonl"
        lines = [
            json.dumps(
                {
                    "type": "user",
                    "message": {
                        "role": "user",
                        "content": [{"type": "text", "text": "Fix the bug"}],
                    },
                }
            ),
            json.dumps(
                {
                    "type": "assistant",
                    "message": {"content": [{"type": "text", "text": "Done"}]},
                }
            ),
        ]
        f.write_text("\n".join(lines) + "\n")
        result = _last_user_message(f)
        assert result == "Fix the bug"

    def test_last_user_message_skips_interrupted(self, tmp_path):
        f = tmp_path / "session.jsonl"
        lines = [
            json.dumps(
                {
                    "type": "user",
                    "message": {
                        "role": "user",
                        "content": [{"type": "text", "text": "Real message"}],
                    },
                }
            ),
            json.dumps(
                {
                    "type": "user",
                    "message": {
                        "role": "user",
                        "content": [{"type": "text", "text": "[Request interrupted by user"}],
                    },
                }
            ),
        ]
        f.write_text("\n".join(lines) + "\n")
        result = _last_user_message(f)
        assert result == "Real message"

    def test_scan_claude_sessions_empty(self, tmp_path, monkeypatch):
        monkeypatch.setattr("am.scanners.claude.CLAUDE_DIR", tmp_path / "nonexistent")
        result = scan_claude_sessions()
        assert result == []

    def test_scan_claude_sessions_with_data(self, tmp_path, monkeypatch):
        monkeypatch.setattr("am.scanners.claude.CLAUDE_DIR", tmp_path)

        project_dir = tmp_path / "-Users-me-MyProject"
        project_dir.mkdir()

        session_file = project_dir / "a1b2c3d4-e5f6-7890-abcd-ef1234567890.jsonl"
        lines = [
            json.dumps({"cwd": "/home/me/MyProject"}),
            json.dumps(
                {
                    "type": "user",
                    "message": {
                        "role": "user",
                        "content": [{"type": "text", "text": "Hello"}],
                    },
                }
            ),
        ]
        session_file.write_text("\n".join(lines) + "\n")

        result = scan_claude_sessions()
        assert len(result) == 1
        assert result[0].session_id == "a1b2c3d4-e5f6-7890-abcd-ef1234567890"
        assert result[0].project == "MyProject"
        assert result[0].cli == "claude"
        assert result[0].last_message == "Hello"
        assert result[0].project_path == "/home/me/MyProject"

    def test_scan_uses_cwd_basename_not_slug(self, tmp_path, monkeypatch):
        """Project name must come from cwd basename, not from the lossy slug.

        Regression for projects whose folder name itself contains dashes
        (e.g. `Trade-EUR-USD`) — slug-decoding loses everything but the
        last segment, so we'd previously call them just `USD`."""
        monkeypatch.setattr("am.scanners.claude.CLAUDE_DIR", tmp_path)

        project_dir = tmp_path / "-Users-me-projects-Trade-EUR-USD"
        project_dir.mkdir()

        session_file = project_dir / "b2c3d4e5-f6a7-8901-bcde-f12345678901.jsonl"
        session_file.write_text(json.dumps({"cwd": "/home/me/projects/Trade-EUR-USD"}) + "\n")

        result = scan_claude_sessions()
        assert len(result) == 1
        assert result[0].project == "Trade-EUR-USD"  # not "USD"
        assert result[0].project_path == "/home/me/projects/Trade-EUR-USD"


class TestCodexScanner:
    def test_parse_codex_session(self, tmp_path):
        f = tmp_path / "rollout-123-abc.jsonl"
        lines = [
            json.dumps({"type": "session_meta", "cwd": "/home/me/project"}),
            json.dumps(
                {
                    "payload": {"type": "user_message", "message": "Build feature X"},
                }
            ),
        ]
        f.write_text("\n".join(lines) + "\n")

        session = _parse_codex_session(f)
        assert session is not None
        assert session.session_id == "rollout-123-abc"
        assert session.cli == "codex"
        assert session.last_message == "Build feature X"
        assert session.project_path == "/home/me/project"

    def test_parse_empty_file(self, tmp_path):
        f = tmp_path / "rollout-empty.jsonl"
        f.write_text("")
        assert _parse_codex_session(f) is None

    def test_scan_codex_no_dir(self, tmp_path, monkeypatch):
        monkeypatch.setattr("am.scanners.codex.SESSIONS_DIR", tmp_path / "nope")
        assert scan_codex_sessions() == []


class TestGeminiScanner:
    def test_parse_gemini_project(self, tmp_path):
        project_dir = tmp_path / "hash123"
        chats_dir = project_dir / "chats"
        chats_dir.mkdir(parents=True)

        logs_file = chats_dir / "logs.json"
        logs_file.write_text(json.dumps({"cwd": "/home/me/gemini-project"}))

        chat_file = chats_dir / "chat-1.json"
        chat_file.write_text(
            json.dumps(
                {
                    "messages": [
                        {"role": "user", "content": "Explain this code"},
                        {"role": "assistant", "content": "Sure..."},
                    ],
                }
            )
        )

        sessions = _parse_gemini_project(project_dir)
        assert len(sessions) == 1
        assert sessions[0].cli == "gemini"
        assert sessions[0].last_message == "Explain this code"
        assert sessions[0].project == "gemini-project"

    def test_parse_gemini_no_chats_dir(self, tmp_path):
        project_dir = tmp_path / "nochats"
        project_dir.mkdir()
        assert _parse_gemini_project(project_dir) == []

    def test_scan_gemini_no_dir(self, tmp_path, monkeypatch):
        monkeypatch.setattr("am.scanners.gemini.GEMINI_DIR", tmp_path / "nope")
        assert scan_gemini_sessions() == []


class TestScanAll:
    def test_scan_all_empty(self, tmp_path, monkeypatch):
        monkeypatch.setattr("am.scanners.claude.CLAUDE_DIR", tmp_path / "no1")
        monkeypatch.setattr("am.scanners.codex.SESSIONS_DIR", tmp_path / "no2")
        monkeypatch.setattr("am.scanners.gemini.GEMINI_DIR", tmp_path / "no3")

        from am.scanners import scan_all_sessions

        result = scan_all_sessions()
        assert result == []
