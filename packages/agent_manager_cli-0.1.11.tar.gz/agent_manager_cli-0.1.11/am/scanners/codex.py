"""Scanner for OpenAI Codex CLI sessions (~/.codex/sessions/)."""

from __future__ import annotations

import json
import os
from datetime import UTC, datetime
from pathlib import Path

from am.scanners._util import read_tail
from am.schemas.session import LocalSession

CODEX_DIR = Path(os.environ.get("CODEX_HOME", Path.home() / ".codex"))
SESSIONS_DIR = CODEX_DIR / "sessions"


def _parse_codex_session(jsonl_path: Path) -> LocalSession | None:
    """Parse a Codex rollout-*.jsonl file."""
    tail = read_tail(jsonl_path)
    if not tail:
        return None

    # Extract session_id from filename: rollout-<timestamp>-<id>.jsonl
    sid = jsonl_path.stem  # e.g. "rollout-1234567890-abcdef"

    project_path = ""
    last_message = None

    for line in reversed(tail.strip().splitlines()):
        try:
            entry = json.loads(line)
        except json.JSONDecodeError:
            continue

        # Try to find project path from turn_context or session_meta
        if not project_path:
            if entry.get("type") == "session_meta":
                project_path = entry.get("cwd", "")
            elif entry.get("cwd"):
                project_path = entry["cwd"]

        # Find last user message
        if not last_message:
            payload = entry.get("payload", {})
            if payload.get("type") == "user_message":
                text = payload.get("message", "").strip()
                if text:
                    last_message = text[:200]

            # Also check event_msg wrapper
            if entry.get("type") == "event_msg":
                inner = entry.get("payload", {})
                if inner.get("type") == "user_message":
                    text = inner.get("message", "").strip()
                    if text:
                        last_message = text[:200]

        if project_path and last_message:
            break

    project_name = Path(project_path).name if project_path else sid

    return LocalSession(
        session_id=sid,
        project=project_name,
        project_path=project_path,
        cli="codex",
        last_message=last_message,
        updated_at=datetime.fromtimestamp(jsonl_path.stat().st_mtime, tz=UTC),
    )


def scan_codex_sessions() -> list[LocalSession]:
    if not SESSIONS_DIR.is_dir():
        return []

    sessions: list[LocalSession] = []

    # Sessions are in YYYY/MM/DD/ subdirectories
    for jsonl_file in SESSIONS_DIR.rglob("rollout-*.jsonl"):
        try:
            session = _parse_codex_session(jsonl_file)
            if session:
                sessions.append(session)
        except Exception:
            continue

    return sessions
