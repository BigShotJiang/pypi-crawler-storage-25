"""Scanner for Claude Code CLI sessions (~/.claude/projects/)."""

from __future__ import annotations

import json
import re
from datetime import UTC, datetime
from pathlib import Path

from am.scanners._util import read_tail
from am.schemas.session import LocalSession

CLAUDE_DIR = Path.home() / ".claude" / "projects"

_UUID_RE = re.compile(r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$")


def _slug_fallback_name(dirname: str) -> str:
    """Fallback when we can't read `cwd` from jsonl: best-effort guess
    from the directory slug. Note: slug is lossy — `Trade-EUR-USD` and
    `Trade/EUR/USD` map to the same slug — so this is only used when
    no jsonl entry was readable."""
    parts = dirname.strip("-").split("-")
    return parts[-1] if parts else dirname


def _resolve_cwd(project_dir: Path) -> str | None:
    """Extract real project path from `cwd` field in JSONL metadata."""
    for jsonl_file in project_dir.glob("*.jsonl"):
        try:
            with open(jsonl_file, encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        entry = json.loads(line)
                    except json.JSONDecodeError:
                        continue
                    cwd = entry.get("cwd")
                    if cwd and isinstance(cwd, str):
                        return cwd
        except Exception:
            continue
    return None


def _last_user_message(jsonl_path: Path) -> str | None:
    tail = read_tail(jsonl_path)
    if not tail:
        return None

    for line in reversed(tail.strip().splitlines()):
        try:
            entry = json.loads(line)
        except json.JSONDecodeError:
            continue
        if entry.get("type") != "user":
            continue
        msg = entry.get("message", {})
        if msg.get("role") != "user":
            continue
        content = msg.get("content")
        if isinstance(content, str):
            text = content
        elif isinstance(content, list):
            text = " ".join(
                b.get("text", "")
                for b in content
                if isinstance(b, dict) and b.get("type") == "text"
            )
        else:
            continue
        text = text.strip()
        if text and not text.startswith("[Request interrupted"):
            return text[:200]
    return None


def scan_claude_sessions() -> list[LocalSession]:
    if not CLAUDE_DIR.is_dir():
        return []

    sessions: list[LocalSession] = []

    for project_dir in CLAUDE_DIR.iterdir():
        if not project_dir.is_dir():
            continue

        # Prefer the real cwd basename — slug-decoded names lose information
        # for projects whose folder name itself contains dashes (e.g.
        # `Trade-EUR-USD` and `Trade/EUR/USD` collide in the slug form).
        cwd = _resolve_cwd(project_dir)
        name = Path(cwd).name if cwd else _slug_fallback_name(project_dir.name)

        for f in project_dir.glob("*.jsonl"):
            sid = f.stem
            if not _UUID_RE.match(sid):
                continue

            sessions.append(
                LocalSession(
                    session_id=sid,
                    project=name,
                    project_path=cwd or "",
                    cli="claude",
                    last_message=_last_user_message(f),
                    updated_at=datetime.fromtimestamp(f.stat().st_mtime, tz=UTC),
                )
            )

    return sessions
