"""Allow running as `python -m am`."""

from am.cli import main

main()
