from datetime import datetime

from pydantic import BaseModel


class LocalSession(BaseModel):
    session_id: str
    project: str
    project_path: str
    cli: str  # "claude", "codex", "gemini"
    last_message: str | None = None
    updated_at: datetime | None = None
