"""Riched package."""
