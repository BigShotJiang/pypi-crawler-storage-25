# -*- coding: utf-8 -*-
import re
import os
import time
import uuid
import struct
import zlib
import json
import base64
import requests
from PIL import Image
from concurrent.futures import ThreadPoolExecutor
from loguru import logger
from lxml import etree
import tempfile
import shutil
from pypdf import PdfWriter

key1 = "PJLKMNOI3xyz021wvrpqstouHCFBDEGAnhikjlmgfZbacedYRXTSUVQW!56789+4"
key2 = "PJKLMNOI3xyz012wvprqstuoHBCDEFGAnhijklmgfZabcdeYXRSTUVWQ!56789+4"
std_str = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"


def encode(data: str, key: str = key1) -> str:
    return base64.b64encode(data.encode("utf-8")).decode("utf-8").translate(str.maketrans(std_str, key))


def decode(data: str, key: str = key1) -> str:
    return base64.b64decode(data.translate(str.maketrans(key, std_str))).decode("utf-8")


def special_path(path):
    """处理文件名中的特殊字符"""
    return path.translate(str.maketrans('*|:?/<>"\\', '＊｜：？／＜＞＂＼'))


class gen_cfg:
    def __init__(self, config: dict) -> None:
        self.headerInfo, self.p_swf, self.ebt_host, self.p_code = config['headerInfo'], config['p_swf'], config[
            'ebt_host'], config['p_code']
        self.pageInfo = config['pageInfo']
        self.p_name = config.get('p_name', self.p_code)  # 文档名称，如果没有则使用文档ID
        self.pageids = decode(self.pageInfo).split(",")
        self.p_count = len(self.pageids)
        self.headnums = self.headerInfo.replace('"', "").split(',')

    def ph_nums(self) -> int:
        return len(self.headnums)

    def ph_num(self, page: int) -> int:
        return int(self.pageids[page - 1].split("-")[0])

    def ph(self, level: int):
        name = "getebt-" + encode(f"{level}-0-{self.headnums[level - 1]}-{self.p_swf}", key2) + ".ebt"
        return f"{self.ebt_host}/{name}"

    def pk(self, page: int):
        pageid = self.pageids[page - 1].split("-")
        level_num = int(pageid[0])
        name = "getebt-" + encode(f"{level_num}-{pageid[3]}-{pageid[4]}-{self.p_swf}-{page}-{self.p_code}",
                                  key2) + ".ebt"
        return f"{self.ebt_host}/{name}"


def decompress_ph(data):
    buff = bytearray(zlib.decompress(data[40:]))
    buff[4:8] = struct.pack("<I", len(buff))
    return buff


def decompress_pk(data):
    return zlib.decompress(data[32:])


def make_swf(ph_data, pk_data):
    buff = bytearray(ph_data + pk_data)
    buff.extend(struct.pack("<BBBB", 64, 0, 0, 0))
    buff[4:8] = struct.pack("<I", len(buff))
    return buff


def convert_swf_to_image(swf_data, image_file, scale=5):
    """将 SWF 数据转换为图片（不保存 SWF 文件）"""
    temp_dir = os.path.join(os.path.dirname(image_file), f"temp_{uuid.uuid4().hex[:8]}")
    temp_swf = os.path.join(temp_dir, "temp.swf")
    temp_png = os.path.join(temp_dir, "1.png")
    try:
        os.makedirs(temp_dir, exist_ok=True)
        with open(temp_swf, 'wb') as f:
            f.write(swf_data)
        os.popen(
            f'java -Xmx512m -XX:ReservedCodeCacheSize=128m -jar ffdec/ffdec.jar -format frame:png -select 1 -export frame "{temp_dir}" "{temp_swf}"').read()
        for _ in range(50):
            if os.path.exists(temp_png):
                img = Image.open(temp_png)
                if scale > 1:
                    img = img.resize((int(img.width * scale), int(img.height * scale)), Image.Resampling.LANCZOS)
                img.save(image_file, "PNG")
                img.close()
                return True
            time.sleep(0.1)
        return False
    finally:
        if os.path.exists(temp_dir):
            shutil.rmtree(temp_dir)


def convert_swf_to_pdf(swf_data, pdf_file):
    """将 SWF 数据直接转换为 PDF（不保存 SWF 文件）"""
    # 使用统一的临时目录，减少I/O开销
    temp_dir = os.path.join(os.path.dirname(pdf_file), f"temp_{uuid.uuid4().hex[:8]}")
    temp_swf = os.path.join(temp_dir, "temp.swf")
    temp_pdf_dir = os.path.join(temp_dir, "pdf")
    temp_pdf = os.path.join(temp_pdf_dir, "frames.pdf")
    try:
        os.makedirs(temp_pdf_dir, exist_ok=True)
        with open(temp_swf, 'wb') as f:
            f.write(swf_data)
        # 优化：使用subprocess替代os.popen，添加超时控制
        import subprocess
        cmd = [
            'java', '-Xmx512m', '-XX:ReservedCodeCacheSize=128m',
            '-jar', 'ffdec/ffdec.jar',
            '-format', 'frame:pdf', '-select', '1',
            '-export', 'frame', temp_pdf_dir, temp_swf
        ]
        subprocess.run(cmd, capture_output=True, timeout=60)

        # 等待PDF生成，最多等待5秒
        for _ in range(50):
            if os.path.exists(temp_pdf):
                try:
                    shutil.move(temp_pdf, pdf_file)
                    return True
                except Exception as e:
                    logger.error(f"移动PDF文件失败: {e}")
                    return False
            time.sleep(0.1)
        logger.warning(f"PDF转换超时: {pdf_file}")
        return False
    except subprocess.TimeoutExpired:
        logger.error(f"SWF转PDF超时: {pdf_file}")
        return False
    except Exception as e:
        logger.error(f"SWF转PDF失败: {e}")
        return False
    finally:
        if os.path.exists(temp_dir):
            shutil.rmtree(temp_dir)


def process_page(cfg, page, image_dir, ph_cache, scale=5):
    """处理单页：下载 EBT -> 解压 -> 生成 SWF -> 转换为图片（不保存中间文件）"""
    level_num = cfg.ph_num(page)
    if level_num not in ph_cache:
        ph_url = cfg.ph(level_num)
        ph_cache[level_num] = requests.get(ph_url, headers={"User-Agent": "Mozilla/5.0"}).content
    pk_url = cfg.pk(page)
    pk_data = requests.get(pk_url, headers={"User-Agent": "Mozilla/5.0"}).content
    ph_decompressed = decompress_ph(ph_cache[level_num])
    pk_decompressed = decompress_pk(pk_data)
    swf_data = make_swf(ph_decompressed, pk_decompressed)
    image_file = os.path.join(image_dir, f"{page}.png")
    return convert_swf_to_image(swf_data, image_file, scale)


def process_page_to_pdf(cfg, page, pdf_dir, ph_cache):
    """处理单页：下载 EBT -> 解压 -> 生成 SWF -> 直接转换为 PDF（不保存中间文件）"""
    level_num = cfg.ph_num(page)
    if level_num not in ph_cache:
        ph_url = cfg.ph(level_num)
        ph_cache[level_num] = requests.get(ph_url, headers={"User-Agent": "Mozilla/5.0"}).content
    pk_url = cfg.pk(page)
    pk_data = requests.get(pk_url, headers={"User-Agent": "Mozilla/5.0"}).content
    ph_decompressed = decompress_ph(ph_cache[level_num])
    pk_decompressed = decompress_pk(pk_data)
    swf_data = make_swf(ph_decompressed, pk_decompressed)
    pdf_file = os.path.join(pdf_dir, f"{page}.pdf")
    return convert_swf_to_pdf(swf_data, pdf_file)


def get_images(url, output_dir=None, image_scale=5):
    """从 URL 获取图片"""
    # 获取配置
    response = requests.get(url, headers={"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"})
    data_match = re.search(r"m_main.init\(\"(.*?)\"\);", response.text)
    if not data_match:
        logger.error("无法获取配置")
        return False
    config = json.loads(decode(data_match.group(1)))
    cfg = gen_cfg(config)
    # 根据文档ID创建输出目录
    if output_dir is None:
        output_dir = os.path.join("输出目录", cfg.p_code)
    else:
        output_dir = os.path.join(output_dir, cfg.p_code)
    image_dir = os.path.join(output_dir, "images")
    os.makedirs(image_dir, exist_ok=True)
    # PH 缓存（避免重复下载）
    ph_cache = {}

    # 多线程处理
    def process_one(page):
        try:
            return process_page(cfg, page, image_dir, ph_cache, image_scale)
        except Exception as e:
            logger.error(f"页面 {page} 处理失败: {e}")
            return False

    with ThreadPoolExecutor(max_workers=10) as executor:
        results = list(executor.map(process_one, range(1, cfg.p_count + 1)))
    success = sum(1 for r in results if r)
    logger.info(f"转换完成: {success}/{cfg.p_count} 页成功")
    return image_dir


def get_pdf(url, output_dir=None, image_scale=5, delete_images=True, direct_pdf=False):
    """从 URL 获取并生成 PDF
    Args:
        url: 文档URL
        output_dir: 输出目录
        image_scale: 图片缩放倍数（仅用于图片模式）
        delete_images: 是否删除中间文件（仅用于图片模式）
        direct_pdf: True=直接转PDF（高效，默认），False=图片转PDF
    Returns:
        PDF文件路径，失败返回False
    """
    response = requests.get(url, headers={"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"})
    data_match = re.search(r"m_main.init\(\"(.*?)\"\);", response.text)
    if not data_match:
        logger.error("无法获取配置")
        return False
    config = json.loads(decode(data_match.group(1)))
    cfg = gen_cfg(config)
    if output_dir is None:
        output_dir = os.path.join("输出目录", cfg.p_code)
    else:
        output_dir = os.path.join(output_dir, cfg.p_code)
    os.makedirs(output_dir, exist_ok=True)
    # 使用文档名称作为PDF文件名，处理特殊字符
    pdf_name = special_path(cfg.p_name)
    pdf_file = os.path.join(output_dir, f"{pdf_name}.pdf")
    if direct_pdf:
        # 直接转PDF模式：SWF -> PDF（不经过图片）
        pdf_dir = os.path.join(output_dir, "temp_pdfs")
        os.makedirs(pdf_dir, exist_ok=True)
        ph_cache = {}
        pdf_list = []  # 跟踪成功转换的页面编号（类似get_pdf.py的pdflist）

        def process_one(page):
            try:
                if process_page_to_pdf(cfg, page, pdf_dir, ph_cache):
                    pdf_list.append(page)  # 只有成功转换才添加到列表
                    return True
                return False
            except Exception as e:
                logger.error(f"页面 {page} 转PDF失败: {e}")
                return False

        with ThreadPoolExecutor(max_workers=10) as executor:
            results = list(executor.map(process_one, range(1, cfg.p_count + 1)))

        success = len(pdf_list)
        logger.info(f"转换完成: {success}/{cfg.p_count} 页成功")

        if success == 0:
            logger.error("没有成功转换的页面")
            return False

        # 合并PDF（与get_pdf.py方式一致：按成功转换的页面顺序合并）
        try:
            logger.info("正在合并PDF...")
            pdf_writer = PdfWriter()
            # 按成功转换的页面顺序添加PDF（类似get_pdf.py的makepdf方法）
            for page in sorted(pdf_list):
                page_pdf = os.path.join(pdf_dir, f"{page}.pdf")
                try:
                    pdf_writer.append(page_pdf)
                except Exception as e:
                    logger.warning(f"跳过无效PDF: {page_pdf}, 错误: {e}")
                    continue

            if len(pdf_writer.pages) == 0:
                logger.error("没有有效的PDF页面可以合并")
                return False

            pdf_writer.write(pdf_file)
            pdf_writer.close()
            logger.info(f"PDF生成成功: {pdf_file} (共 {len(pdf_writer.pages)} 页)")
            shutil.rmtree(pdf_dir)
            return pdf_file
        except Exception as e:
            logger.error(f"合并PDF失败: {e}")
            return False
    else:
        # 图片转PDF模式（兼容旧方式）
        image_dir = get_images(url, output_dir, image_scale)
        if not image_dir:
            logger.error("获取图片失败，无法生成PDF")
            return False
        image_files = []
        for filename in sorted(os.listdir(image_dir),
                               key=lambda x: int(x.split('.')[0]) if x.split('.')[0].isdigit() else 0):
            if filename.lower().endswith(('.png', '.jpg', '.jpeg')):
                image_files.append(os.path.join(image_dir, filename))
        if not image_files:
            logger.error("未找到图片文件，无法生成PDF")
            return False
        try:
            images = []
            for img_path in image_files:
                img = Image.open(img_path)
                if img.mode != 'RGB':
                    img = img.convert('RGB')
                images.append(img)
            if images:
                images[0].save(pdf_file, "PDF", resolution=100.0, save_all=True,
                               append_images=images[1:] if len(images) > 1 else [])
                logger.info(f"PDF生成成功: {pdf_file}")
                for img in images:
                    img.close()
                if delete_images:
                    shutil.rmtree(image_dir)
                    logger.info(f"已删除图片目录: {image_dir}")
                return pdf_file
            return False
        except Exception as e:
            logger.error(f"生成PDF失败: {e}")
            return False


def start(keyword, output_base_dir="输出目录", image_scale=5):
    """根据关键词搜索并获取图片"""
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        'Host': 'www.doc88.com',
    }
    params = {
        'f': '', 'h': '1', 'pageRange': '0', 'pageNum': '0',
        'format': '', 'p': '1', 'ct': '2', 'q': keyword,
        'sDate': '', 'eDate': '',
    }
    response = requests.get('https://www.doc88.com/search/post.do', params=params, headers=headers)
    html = etree.HTML(response.text)
    lists = html.xpath('//div[@class="sd-list-con"]')
    if not lists:
        logger.error(f"未找到关键词 '{keyword}' 的搜索结果")
        return False
    for list_item in lists:
        url = list_item.xpath('.//a/@href')[0]
        if url:
            if not url.startswith('http'):
                url = 'https://www.doc88.com' + url
            return get_images(url, output_base_dir, image_scale)
    return False


# if __name__ == "__main__":
#     # start("YY 9706.261-2023", image_scale=5)
#     # 方式2: 直接使用URL获取图片
#     # get_images("https://www.doc88.com/p-90490194049280.html", image_scale=5)
#     # 方式3: 直接转PDF（高效，默认方式）
#     get_pdf("https://www.doc88.com/p-90490194049280.html", direct_pdf=True)
#     # 方式4: 图片转PDF（兼容旧方式）
#     # get_pdf("https://www.doc88.com/p-90490194049280.html", direct_pdf=False, image_scale=5, delete_images=True)

