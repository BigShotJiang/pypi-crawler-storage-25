from threading import Lock, Thread
from concurrent.futures import ThreadPoolExecutor
from DrissionPage import ChromiumPage, ChromiumOptions
from fake_useragent import UserAgent
from loguru import logger
import time
import random


class BrowserPool:
    def __init__(self, tab_count=4, url='https://www.baidu.com'):
        self.url = url
        self.tab_count = tab_count
        self.browser = None
        self.tabs = []
        self.tab_locks = []
        self.ua = UserAgent()
        self.current_tab = 0
        self.pool_lock = Lock()
        self.init_browser()
        self.init_all_tabs()

    def init_browser(self):
        options = ChromiumOptions()
        options.auto_port()
        options.headless()
        options.set_user_agent(self.ua.chrome)
        options.set_argument('--no-sandbox')
        options.set_argument('--disable-gpu')
        options.set_argument('--disable-images')
        options.set_argument('--disable-css')
        self.browser = ChromiumPage(options)

    def init_all_tabs(self):
        # logger.info(f"初始化 {self.tab_count} 个 tab 页...")
        for i in range(self.tab_count):
            tab = self.browser.new_tab(new_context=True)
            tab.get(self.url, timeout=10)
            tab.wait.doc_loaded()
            self.tabs.append(tab)
            self.tab_locks.append(Lock())  # 每个Tab配一把锁
        # logger.success(f"成功创建 {len(self.tabs)} 个 tab")

    def _get_tab(self):
        with self.pool_lock:
            tab_idx = self.current_tab
            self.current_tab = (self.current_tab + 1) % self.tab_count
        return tab_idx, self.tabs[tab_idx], self.tab_locks[tab_idx]

    def run_js(self, js_code):
        """执行JS：自动分配到空闲Tab，带锁保护"""
        tab_idx, tab, tab_lock = self._get_tab()
        with tab_lock:
            try:
                start = time.time()
                result = tab.run_js(js_code)
                cost = round(time.time() - start, 4)
                # logger.debug(f"执行JS完成 | 耗时：{cost}s")
                return {"tab_idx": tab_idx + 1, "result": result, "cost": cost}
            except Exception as e:
                logger.error(f"Tab {tab_idx + 1} 执行失败：{e}")
                return {"tab_idx": tab_idx + 1, "result": None, "cost": 0}

    def close(self):
        logger.info("关闭浏览器...")
        for tab in self.tabs:
            tab.close()
        self.browser.quit()
        logger.success("浏览器已关闭")


# # ========== 测试：多任务并行利用多Tab ==========
# if __name__ == "__main__":
#     # 1. 初始化4个Tab的浏览器池
#     browser_pool = BrowserPool(4)
#     # 2. 定义要执行的JS任务列表（模拟多个任务）
#     js_tasks = [
#         'return document.title + " | " + new Date().getTime()',
#         'return document.URL + " | " + Math.random()',
#         'return navigator.userAgent',
#         'return document.cookie',
#         'return "任务5-" + new Date().getTime()',
#         'return "任务6-" + Math.random()',
#         'return "任务7-" + document.title',
#         'return "任务8-" + navigator.language'
#     ]
#     # # 3. 用线程池并行执行（最大程度利用多Tab）
#     # with ThreadPoolExecutor(max_workers=4) as executor:
#     #     # 提交所有任务，自动分发到不同Tab
#     #     results = list(executor.map(browser_pool.run_js, js_tasks))
#     # # 4. 打印结果（验证任务分配到不同Tab）
#     # print("\n=== 多Tab执行结果 ===")
#     # for idx, res in enumerate(results):
#     #     print(f"任务{idx + 1} | 执行Tab：{res['tab_idx']} | 结果：{res['result']} | 耗时：{res['cost']}s")
#     for data in js_tasks:
#         result = browser_pool.run_js(data)
#         print(result)
#     browser_pool.close()