# Third Party Licenses

This project includes code from external sources (see details and license statements below):
- Solvers `fourier_boris`, `ec` and `ec2` use [FFTW3](#FFTW3)
- Extention `qed_volokitin2023` uses files and adopted code from [pyHiChi](#pyHiChi)

## FFTW3

**Source:** https://www.fftw.org

**License:** GPL

**Original Copyright:**

FFTW is Copyright © 2003, 2007-11 Matteo Frigo, Copyright © 2003, 2007-11 Massachusetts Institute of Technology.

**License Text:**

FFTW is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

## pyHiChi

**Source:** https://github.com/hi-chi/pyHiChi

**License:** MIT

**Files used:**

- \[src/extensions/qed_volokitin2023/QED_emis.in]
- \[src/extensions/qed_volokitin2023/QED_pair_half.in]
- \[src/extensions/qed_volokitin2023/compton.h]
- \[src/extensions/qed_volokitin2023/breit_wheeler.h]

**Original Copyright:**

Copyright © 2019 pyhichi

**License Text:**

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.