"""
Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com

Command to stop a job in the queue.
"""

from typing import Any, Dict

from mcp_proxy_adapter.commands.base import Command
from mcp_proxy_adapter.commands.result import SuccessResult, ErrorResult
from mcp_proxy_adapter.integrations.queuemgr_integration import (
    QueueJobError,
    get_global_queue_manager,
)
from mcp_proxy_adapter.core.errors import ValidationError


class QueueStopJobCommand(Command):
    """Command to stop a job in the queue."""

    name = "queue_stop_job"
    descr = "Stop a running job in the background queue"

    @classmethod
    def get_schema(cls) -> Dict[str, Any]:
        """Get command schema."""
        return {
            "type": "object",
            "properties": {
                "job_id": {
                    "type": "string",
                    "description": "Job identifier to stop",
                    "minLength": 1,
                }
            },
            "required": ["job_id"],
        }

    async def execute(self, job_id: str = None, **kwargs) -> Dict[str, Any]:
        """Execute queue stop job command."""
        if not job_id:
            job_id = kwargs.get("job_id")
        try:

            if not job_id:
                raise ValidationError("job_id is required")

            # Get global queue manager
            queue_manager = await get_global_queue_manager()

            # Stop job
            result = await queue_manager.stop_job(job_id)

            if result.status == "stopped":
                message = f"Job {job_id} stopped successfully"
            else:
                message = (
                    f"Stop requested for job {job_id}, actual status is {result.status}"
                )

            data = {
                "message": message,
                "job_id": job_id,
                "status": result.status,
                "description": result.description,
            }
            if result.metadata:
                data.update(result.metadata)

            return SuccessResult(data=data)

        except QueueJobError as e:
            details: Dict[str, Any] = {"job_id": getattr(e, "job_id", "unknown")}
            if getattr(e, "details", None):
                details.update(getattr(e, "details"))
            if "Invalid job state for stop" in str(e):
                details["error_code"] = "INVALID_JOB_STATE"
                details["detail"] = str(e)
            return ErrorResult(
                message=f"Queue job error: {str(e)}",
                code=-32603,
                details=details,
            )
        except Exception as e:
            return ErrorResult(
                message=f"Failed to stop job: {str(e)}",
                code=-32603,
            )
