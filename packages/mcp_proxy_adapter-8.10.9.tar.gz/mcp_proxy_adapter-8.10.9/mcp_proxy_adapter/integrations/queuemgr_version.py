"""
Queuemgr version policy for mcp-proxy-adapter (import-safe; no queuemgr dependency).

Author: Vasiliy Zdanovskiy
"""

from __future__ import annotations

# Minimum queuemgr for AsyncQueueSystem retention and adapter queue integration.
# Minimum queuemgr for terminal-state consistency and truthful queue control responses.
MIN_QUEUEMGR_VERSION = "1.0.19"


def check_queuemgr_version(installed_version: str, minimum: str = MIN_QUEUEMGR_VERSION) -> None:
    """
    Raise ImportError if installed_version is below minimum.

    Used at import time for ``queuemgr_integration`` and in unit tests.
    """
    if installed_version == "unknown":
        return
    from packaging import version

    if version.parse(installed_version) < version.parse(minimum):
        raise ImportError(
            f"queuemgr version {installed_version} is too old. "
            f"mcp-proxy-adapter requires queuemgr>={minimum} for stopped/deleted "
            f"terminal-state consistency and truthful queue control responses. "
            f"Please upgrade: pip install --upgrade queuemgr>={minimum}"
        )
