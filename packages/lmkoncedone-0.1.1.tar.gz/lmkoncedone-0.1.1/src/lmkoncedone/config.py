"""
Configuration utilities for notify-me
"""

import os
from typing import Dict, Optional


def get_config() -> Dict[str, Optional[str]]:
    """
    Get current configuration from environment variables.
    
    Returns:
        Dictionary with configuration values
    """
    return {
        'smtp_host': os.getenv('NOTIFY_SMTP_HOST', 'smtp.gmail.com'),
        'smtp_port': os.getenv('NOTIFY_SMTP_PORT', '587'),
        'from_email': os.getenv('NOTIFY_EMAIL_FROM'),
        'to_email': os.getenv('NOTIFY_EMAIL_TO'),
        'password': os.getenv('NOTIFY_EMAIL_PASSWORD'),
    }


def validate_config() -> bool:
    """
    Validate that all required configuration is present.
    
    Returns:
        True if configuration is valid, False otherwise
    """
    config = get_config()
    required = ['from_email', 'to_email', 'password']
    
    missing = [k for k in required if not config.get(k)]
    
    if missing:
        print(f"Missing required environment variables:")
        for var in missing:
            env_name = f"NOTIFY_{var.upper()}"
            print(f"  - {env_name}")
        return False
    
    return True


def print_config(hide_password: bool = True):
    """
    Print current configuration (for debugging).
    
    Args:
        hide_password: Whether to hide the password (default: True)
    """
    config = get_config()
    
    print("Current notify-me configuration:")
    print(f"  SMTP Host: {config['smtp_host']}")
    print(f"  SMTP Port: {config['smtp_port']}")
    print(f"  From Email: {config['from_email']}")
    print(f"  To Email: {config['to_email']}")
    
    if hide_password:
        password = config.get('password')
        if password:
            print(f"  Password: {'*' * len(password)}")
        else:
            print(f"  Password: Not set")
    else:
        print(f"  Password: {config['password']}") 
