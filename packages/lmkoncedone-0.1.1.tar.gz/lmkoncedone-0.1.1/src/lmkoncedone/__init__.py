 
"""
notify-me: Simple email notifications for Python functions
"""

__version__ = "0.1.0"

import smtplib
import functools
import os
import time
import traceback
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from datetime import datetime
from typing import Callable, Optional, Any
from dotenv import load_dotenv

load_dotenv()


def _format_duration(seconds: float) -> str:
    """Format duration in a human-readable way"""
    if seconds < 60:
        return f"{seconds:.2f}s"
    elif seconds < 3600:
        minutes = int(seconds // 60)
        secs = int(seconds % 60)
        return f"{minutes}m {secs}s"
    else:
        hours = int(seconds // 3600)
        minutes = int((seconds % 3600) // 60)
        return f"{hours}h {minutes}m"


def _send_email(
    subject: str,
    body: str,
    smtp_host: str,
    smtp_port: int,
    from_email: str,
    to_email: str,
    password: str,
    use_tls: bool = True
):
    """Send email via SMTP"""
    try:
        msg = MIMEMultipart()
        msg['Subject'] = subject
        msg['From'] = from_email
        msg['To'] = to_email
        msg['Date'] = datetime.now().strftime('%a, %d %b %Y %H:%M:%S %z')
        
        msg.attach(MIMEText(body, 'plain'))
        
        with smtplib.SMTP(smtp_host, smtp_port, timeout=10) as server:
            if use_tls:
                server.starttls()
            server.login(from_email, password)
            server.send_message(msg)
            
    except Exception as e:
        # Don't let notification failure break the original function
        print(f"Warning: Failed to send email notification: {e}")


def notify(
    _func: Optional[Callable] = None,
    *,
    smtp_host: Optional[str] = None,
    smtp_port: Optional[int] = None,
    from_email: Optional[str] = None,
    to_email: Optional[str] = None,
    password: Optional[str] = None,
    only_errors: bool = False,
    include_result: bool = False,
    subject_prefix: str = "",
    use_tls: bool = True
) -> Callable:
    """
    Decorator to send email notifications when a function completes or fails.
    
    Args:
        smtp_host: SMTP server hostname (default: from NOTIFY_SMTP_HOST env var)
        smtp_port: SMTP server port (default: from NOTIFY_SMTP_PORT env var or 587)
        from_email: Sender email address (default: from NOTIFY_EMAIL_FROM env var)
        to_email: Recipient email address (default: from NOTIFY_EMAIL_TO env var)
        password: Email password (default: from NOTIFY_EMAIL_PASSWORD env var)
        only_errors: Only send notifications on errors (default: False)
        include_result: Include function return value in email (default: False)
        subject_prefix: Prefix to add to email subject (default: "")
        use_tls: Use TLS for SMTP connection (default: True)
    
    Example:
        >>> @notify
        ... def long_task():
        ...     time.sleep(100)
        ...     return "Done!"
        
        >>> @notify(only_errors=True)
        ... def risky_task():
        ...     might_fail()
    """
    
    def decorator(func: Callable) -> Callable:
        @functools.wraps(func)
        def wrapper(*args, **kwargs) -> Any:
            # Get configuration from parameters or environment variables
            config = {
                'smtp_host': smtp_host or os.getenv('NOTIFY_SMTP_HOST', 'smtp.gmail.com'),
                'smtp_port': smtp_port or int(os.getenv('NOTIFY_SMTP_PORT', '587')),
                'from_email': from_email or os.getenv('NOTIFY_EMAIL_FROM'),
                'to_email': to_email or os.getenv('NOTIFY_EMAIL_TO'),
                'password': password or os.getenv('NOTIFY_EMAIL_PASSWORD'),
                'use_tls': use_tls
            }
            
            # Validate required configuration
            missing = [k for k, v in config.items() if v is None and k != 'use_tls']
            if missing:
                print(f"Warning: Missing email configuration: {', '.join(missing)}")
                print("Set environment variables or pass as decorator parameters")
                # Still run the function even if notification config is missing
                return func(*args, **kwargs)
            
            func_name = func.__name__
            start_time = time.time()
            start_datetime = datetime.now()
            
            try:
                # Execute the function
                result = func(*args, **kwargs)
                
                # Calculate duration
                duration = time.time() - start_time
                
                # Send success notification (unless only_errors is True)
                if not only_errors:
                    subject = f"{subject_prefix}✅ {func_name} completed successfully"
                    
                    body_parts = [
                        f"Function: {func_name}",
                        f"Status: Success",
                        f"Duration: {_format_duration(duration)}",
                        f"Started: {start_datetime.strftime('%Y-%m-%d %H:%M:%S')}",
                        f"Completed: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
                    ]
                    
                    if include_result:
                        result_preview = str(result)[:500]  # Limit to 500 chars
                        if len(str(result)) > 500:
                            result_preview += "... (truncated)"
                        body_parts.append(f"\n---\nResult:\n{result_preview}")
                    
                    body = "\n".join(body_parts)
                    
                    _send_email(
                        subject=subject,
                        body=body,
                        **config
                    )
                
                return result
                
            except Exception as e:
                # Calculate duration
                duration = time.time() - start_time
                
                # Send error notification
                subject = f"{subject_prefix}❌ {func_name} failed"
                
                body_parts = [
                    f"Function: {func_name}",
                    f"Status: Failed",
                    f"Duration: {_format_duration(duration)}",
                    f"Started: {start_datetime.strftime('%Y-%m-%d %H:%M:%S')}",
                    f"Failed at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
                    f"\nError: {type(e).__name__}: {str(e)}",
                    f"\n---\nTraceback:\n{traceback.format_exc()}"
                ]
                
                body = "\n".join(body_parts)
                
                _send_email(
                    subject=subject,
                    body=body,
                    **config
                )
                
                # Re-raise the exception
                raise
        
        return wrapper
    
    # Handle both @notify and @notify() syntax
    if _func is None:
        # Called with arguments: @notify(...)
        return decorator
    else:
        # Called without arguments: @notify
        return decorator(_func)


# Convenience function for manual notifications
def send_notification(
    message: str,
    subject: Optional[str] = None,
    smtp_host: Optional[str] = None,
    smtp_port: Optional[int] = None,
    from_email: Optional[str] = None,
    to_email: Optional[str] = None,
    password: Optional[str] = None,
    use_tls: bool = True
):
    """
    Send a custom email notification.
    
    Args:
        message: Email body message
        subject: Email subject (default: "Notification from notify-me")
        smtp_host: SMTP server hostname (default: from env var)
        smtp_port: SMTP server port (default: from env var or 587)
        from_email: Sender email (default: from env var)
        to_email: Recipient email (default: from env var)
        password: Email password (default: from env var)
        use_tls: Use TLS (default: True)
    
    Example:
        >>> send_notification("Model training checkpoint saved!")
    """
    config = {
        'smtp_host': smtp_host or os.getenv('NOTIFY_SMTP_HOST', 'smtp.gmail.com'),
        'smtp_port': smtp_port or int(os.getenv('NOTIFY_SMTP_PORT', '587')),
        'from_email': from_email or os.getenv('NOTIFY_EMAIL_FROM'),
        'to_email': to_email or os.getenv('NOTIFY_EMAIL_TO'),
        'password': password or os.getenv('NOTIFY_EMAIL_PASSWORD'),
        'use_tls': use_tls
    }
    
    missing = [k for k, v in config.items() if v is None and k != 'use_tls']
    if missing:
        raise ValueError(f"Missing email configuration: {', '.join(missing)}")
    
    email_subject = subject or "Notification from notify-me"
    
    _send_email(
        subject=email_subject,
        body=message,
        **config
    )


__all__ = ['notify', 'send_notification']