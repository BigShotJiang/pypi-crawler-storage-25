# lmkoncedone 📧

> Get email notifications when your Python functions complete — simple as a decorator!

Perfect for long-running tasks, data pipelines, ML training, web scraping, and any code you want to monitor remotely.

## Why notify-me?

- 🎯 **Simple**: Just add `@notify` to your function
- 📧 **Email-based**: Works everywhere, no external services needed
- 🔋 **Zero dependencies**: Pure Python, uses only stdlib
- ⚡ **Quick setup**: Configure once with environment variables
- 🛡️ **Safe**: Notification failures won't break your code
- 📊 **Informative**: Get function name, duration, errors, and results

## Installation

```bash
pip install lmkoncedone