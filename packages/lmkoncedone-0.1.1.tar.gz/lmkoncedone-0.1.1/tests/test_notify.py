 
"""
Tests for notify-me
"""

import pytest
import os
import time
from notify_me import notify, send_notification
from notify_me.config import get_config, validate_config


def test_decorator_success():
    """Test decorator on successful function"""
    
    @notify
    def success_func():
        return "success"
    
    result = success_func()
    assert result == "success"


def test_decorator_with_error():
    """Test decorator on failing function"""
    
    @notify
    def failing_func():
        raise ValueError("Test error")
    
    with pytest.raises(ValueError):
        failing_func()


def test_decorator_only_errors():
    """Test only_errors parameter"""
    
    @notify(only_errors=True)
    def success_func():
        return "success"
    
    result = success_func()
    assert result == "success"


def test_decorator_with_args():
    """Test decorator with function arguments"""
    
    @notify
    def add_numbers(a, b):
        return a + b
    
    result = add_numbers(2, 3)
    assert result == 5


def test_decorator_preserves_function_name():
    """Test that decorator preserves function metadata"""
    
    @notify
    def my_function():
        """My docstring"""
        pass
    
    assert my_function.__name__ == "my_function"
    assert my_function.__doc__ == "My docstring"


def test_get_config():
    """Test config retrieval"""
    config = get_config()
    assert 'smtp_host' in config
    assert 'from_email' in config


def test_duration_formatting():
    """Test duration formatting"""
    from notify_me import _format_duration
    
    assert "0.50s" in _format_duration(0.5)
    assert "1m 30s" in _format_duration(90)
    assert "1h 0m" in _format_duration(3600)


def test_custom_parameters():
    """Test decorator with custom parameters"""
    
    @notify(
        subject_prefix="[TEST] ",
        include_result=True
    )
    def custom_func():
        return {"status": "ok"}
    
    result = custom_func()
    assert result == {"status": "ok"}


def test_missing_config_doesnt_break_function():
    """Test that missing config doesn't prevent function execution"""
    # Temporarily clear env vars
    original_env = {
        'NOTIFY_EMAIL_FROM': os.environ.get('NOTIFY_EMAIL_FROM'),
        'NOTIFY_EMAIL_TO': os.environ.get('NOTIFY_EMAIL_TO'),
        'NOTIFY_EMAIL_PASSWORD': os.environ.get('NOTIFY_EMAIL_PASSWORD'),
    }
    
    for key in original_env:
        if key in os.environ:
            del os.environ[key]
    
    @notify
    def test_func():
        return "executed"
    
    result = test_func()
    assert result == "executed"
    
    # Restore env vars
    for key, value in original_env.items():
        if value is not None:
            os.environ[key] = value


if __name__ == "__main__":
    pytest.main([__file__, "-v"])