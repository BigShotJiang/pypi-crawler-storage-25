from __future__ import annotations

import asyncio
import itertools
from collections import Counter
from typing import Optional

import aiohttp

from .node import Node
from .result import Result
from .exceptions import CycleError
from .nodes.http import _session_var


class Graph:
    """Declares and executes a pipeline of nodes.

    Pass the terminal node(s) of your pipeline: the nodes that no other node
    depends on. ``Graph`` discovers all ancestors by walking upstream through
    each node's ``depends_on`` declarations.

    ::

        source      = Source({"user_id": "1"})
        fetch_user  = HTTP("fetch_user",  url="…/users/${user_id}",  depends_on=[source])
        fetch_posts = HTTP("fetch_posts", url="…/users/${user_id}/posts", depends_on=[fetch_user])

        graph   = Graph(fetch_posts, workers=20)
        results = await graph.run()

    **Fan-in**: a node with multiple upstreams runs once per cross-product of
    their result sets. All upstream values are merged into a single dict.
    Conflicting key names are auto-namespaced as ``{upstream_node_id}__{key}``::

        classify = Transform(
            "classify",
            fn=lambda v: tag(v["text"], v["fetch_labels__id"], v["fetch_docs__id"]),
            depends_on=[fetch_text, fetch_labels, fetch_docs],
        )

    Resolve conflicts explicitly with a mapping dict ``{local_name: upstream_name}``::

        combine = Transform(
            "combine",
            fn=lambda v: f"user {v['uid']} / post {v['pid']}",
            depends_on=[
                (fetch_user, {"uid": "id"}),
                (fetch_post, {"pid": "id"}),
            ],
        )

    Args:
        *terminals: Terminal nodes (no other node in the graph depends on these).
        workers:    Maximum number of concurrent ``node.run()`` calls across the
                    whole graph. ``None`` (default) means unlimited.
    """

    def __init__(self, *terminals: Node, workers: Optional[int] = None):
        if not terminals:
            raise ValueError("Graph requires at least one terminal node")
        self._terminals = list(terminals)
        self._workers = workers

        # Post-order DFS from terminals → topological order (sources first)
        self._nodes: list[Node] = self._discover()
        self._check_cycles()

    # ------------------------------------------------------------------
    # Execution
    # ------------------------------------------------------------------

    async def run(self) -> list[Result]:
        """Execute the graph and return results from all terminal nodes.

        Nodes at the same topological level run concurrently. The optional
        ``workers`` cap limits how many ``node.run()`` calls are active at once
        across the entire graph.

        All HTTP nodes share a single ``aiohttp.ClientSession`` for the duration
        of this call, enabling connection reuse across concurrent requests.
        """
        semaphore = asyncio.Semaphore(self._workers) if self._workers else None
        # id(node) → list of Results produced by that node
        completed: dict[int, list[Result]] = {}

        async with aiohttp.ClientSession() as session:
            token = _session_var.set(session)
            try:
                pending = list(self._nodes)

                while pending:
                    # All nodes whose every upstream has already completed
                    ready = [
                        n for n in pending
                        if all(id(up) in completed for up in n.upstream_nodes)
                    ]

                    if not ready:
                        raise RuntimeError(
                            "No nodes are ready to run but the graph is not finished. "
                            "This is a bug; please report it."
                        )

                    # Run the whole wave in parallel
                    wave = await asyncio.gather(
                        *[self._run_node(n, completed, semaphore) for n in ready]
                    )
                    for node, results in zip(ready, wave):
                        completed[id(node)] = results
                    for node in ready:
                        pending.remove(node)

            finally:
                _session_var.reset(token)

        terminal_ids = {id(n) for n in self._terminals}
        return [r for nid, results in completed.items()
                if nid in terminal_ids for r in results]

    async def _run_node(
        self,
        node: Node,
        completed: dict[int, list[Result]],
        semaphore: Optional[asyncio.Semaphore],
    ) -> list[Result]:
        if not node._depends_on:
            # Source: single invocation, no upstream inputs
            return await self._invoke(node, {}, [], semaphore)

        # Build every cross-product combination of upstream results, then run
        # each combination as a separate concurrent invocation.
        upstream_result_sets = [completed[id(up)] for up, _ in node._depends_on]
        combos = list(itertools.product(*upstream_result_sets))

        jobs = [
            self._invoke(node, *self._build_input(combo, node._depends_on), semaphore)
            for combo in combos
        ]
        batches = await asyncio.gather(*jobs)
        return [r for batch in batches for r in batch]

    @staticmethod
    def _build_input(
        combo: tuple[Result, ...],
        depends_on: list[tuple[Node, dict[str, str]]],
    ) -> tuple[dict, list[Result]]:
        """Merge one cross-product combination into a single input dict + parent list.

        Each upstream's output keys are renamed per its mapping, then merged.
        When two upstreams contribute the same key name (after renaming), both
        copies are kept under ``{upstream_node_id}__{key}`` and the unqualified
        key is dropped so the template author is never silently handed the wrong
        value.
        """
        parents: list[Result] = []
        # (upstream_node_id, {key: value}) after applying explicit mappings
        contributions: list[tuple[str, dict]] = []

        for result, (upstream_node, mapping) in zip(combo, depends_on):
            raw = result.value if isinstance(result.value, dict) else {"value": result.value}
            renamed = Graph._apply_mapping(raw, mapping)
            contributions.append((upstream_node.node_id, renamed))
            parents.append(result)

        # Find conflicting keys (same local name from more than one upstream)
        key_counts = Counter(k for _, vals in contributions for k in vals)
        conflicts = {k for k, n in key_counts.items() if n > 1}

        merged: dict = {}
        for upstream_id, vals in contributions:
            for k, v in vals.items():
                if k in conflicts:
                    merged[f"{upstream_id}__{k}"] = v
                else:
                    merged[k] = v

        return merged, parents

    @staticmethod
    def _apply_mapping(value: dict, mapping: dict[str, str]) -> dict:
        """Rename keys according to *mapping* (``{local_name: upstream_name}``).

        Keys not mentioned in the mapping pass through unchanged.
        """
        if not mapping:
            return dict(value)
        # Build reverse: upstream_name → local_name
        reverse = {upstream: local for local, upstream in mapping.items()}
        return {reverse.get(k, k): v for k, v in value.items()}

    @staticmethod
    async def _invoke(
        node: Node,
        value: dict,
        parents: list[Result],
        semaphore: Optional[asyncio.Semaphore],
    ) -> list[Result]:
        if semaphore:
            async with semaphore:
                return await node.run(value, parents)
        return await node.run(value, parents)

    # ------------------------------------------------------------------
    # Topology helpers
    # ------------------------------------------------------------------

    def _discover(self) -> list[Node]:
        """Post-order DFS from terminals through ``depends_on`` → topological order."""
        visited: set[int] = set()
        nodes: list[Node] = []

        def visit(node: Node) -> None:
            if id(node) in visited:
                return
            visited.add(id(node))
            for upstream, _ in node._depends_on:
                visit(upstream)
            nodes.append(node)

        for terminal in self._terminals:
            visit(terminal)

        return nodes

    def _check_cycles(self) -> None:
        visiting: set[int] = set()
        visited: set[int] = set()

        def dfs(node: Node) -> None:
            key = id(node)
            if key in visiting:
                raise CycleError(
                    f"Cycle detected involving node {node.node_id!r}"
                )
            if key in visited:
                return
            visiting.add(key)
            for upstream, _ in node._depends_on:
                dfs(upstream)
            visiting.discard(key)
            visited.add(key)

        for node in self._nodes:
            dfs(node)
