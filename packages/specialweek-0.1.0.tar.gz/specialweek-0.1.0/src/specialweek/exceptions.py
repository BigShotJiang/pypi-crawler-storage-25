class GraphError(Exception):
    """Base class for all specialweek errors."""


class CycleError(GraphError):
    """Raised when the graph contains a cycle."""


class ExecutionError(GraphError):
    """Raised when a node fails during execution."""


class TemplateMissingVariables(GraphError):
    """Raised when a URL or body template references a variable not present in the
    merged input dict. Usually means a key conflict was not resolved with an explicit
    mapping, or an upstream node didn't produce the expected key."""


class ExtractionError(GraphError):
    """Raised when the extract function or JSONPath fails on a response."""
