from __future__ import annotations

from functools import cached_property
from typing import Any


class Result:
    """A value produced by a node, carrying the full provenance DAG back to the sources.

    Attributes:
        value:   The data this node produced.
        node_id: The ID of the node that produced this result.
        parents: The Result(s) that were fed *into* this node. Empty for source nodes.
                 Fan-in nodes have one parent per upstream.
    """

    def __init__(self, value: Any, node_id: str, parents: list[Result] | None = None):
        self.value = value
        self.node_id = node_id
        self.parents = parents or []

    @cached_property
    def provenance(self) -> list[dict[str, Any]]:
        """All ancestor results in topological order (oldest first), then this result.

        For fan-in nodes the ancestor tree is flattened: each ancestor appears
        exactly once. Each entry is ``{"node": <node_id>, "value": <value>}``.
        """
        visited: set[int] = set()
        chain: list[dict[str, Any]] = []

        def visit(r: Result) -> None:
            if id(r) in visited:
                return
            visited.add(id(r))
            for parent in r.parents:
                visit(parent)
            chain.append({"node": r.node_id, "value": r.value})

        visit(self)
        return chain

    def __repr__(self) -> str:
        return f"Result(node={self.node_id!r}, value={self.value!r})"
