from __future__ import annotations

from typing import Any, Callable

from ..node import Node
from ..result import Result


class Transform(Node):
    """Applies a Python function to the merged input dict from upstream nodes.

    If the function returns a list, every element fans out as its own independent
    result through downstream nodes::

        # Single output: reshape or compute something
        Transform("word", fn=lambda v: {"word": v["title"].split()[0].lower()},
                  depends_on=[fetch_comic])

        # Fan-out: split one result into many
        Transform("tags", fn=lambda v: v["tags"], depends_on=[fetch_post])
        # If v["tags"] == ["python", "async"], two results flow downstream.

        # Fan-in: combine results from two upstreams (cross-product)
        Transform(
            "multiply",
            fn=lambda v: {"result": v["x"] * v["y"]},
            depends_on=[source_x, source_y],
        )

    Args:
        node_id:    Label shown in provenance chains.
        fn:         Callable receiving the merged input dict. Return a single value
                    for one downstream result, or a list for fan-out.
        depends_on: Upstream nodes. See ``Node`` for mapping syntax.
    """

    def __init__(self, node_id: str, fn: Callable[[dict[str, Any]], Any], depends_on=None):
        super().__init__(node_id, depends_on)
        self.fn = fn

    async def run(self, value: dict[str, Any], parents: list[Result]) -> list[Result]:
        output = self.fn(value)
        if isinstance(output, list):
            return [Result(v, self.node_id, parents) for v in output]
        return [Result(output, self.node_id, parents)]
