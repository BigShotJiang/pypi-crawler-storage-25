from __future__ import annotations

from typing import Any

from ..node import Node
from ..result import Result


class Source(Node):
    """Seeds a graph with one or more initial values.

    Each positional argument becomes its own ``Result``, fanning out through
    downstream nodes independently and concurrently::

        # Single item
        source = Source({"user_id": "42"})

        # Three independent pipelines run concurrently
        source = Source({"id": "2630"}, {"id": "2631"}, {"id": "2632"})

    Args:
        *items:   One or more seed values (typically dicts, but any type works).
        node_id:  Optional label shown in provenance chains (default: ``"source"``).
    """

    def __init__(self, *items: Any, node_id: str = "source"):
        super().__init__(node_id, depends_on=None)
        if not items:
            raise ValueError("Source requires at least one item")
        self._items = list(items)

    async def run(self, value: dict, parents: list[Result]) -> list[Result]:
        return [Result(item, self.node_id, []) for item in self._items]
