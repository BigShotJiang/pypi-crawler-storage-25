from __future__ import annotations

import asyncio
import contextvars
import re
from contextlib import nullcontext
from string import Template
from typing import Any, Callable, Dict, Optional, Union

import aiohttp

from ..node import Node
from ..result import Result
from ..exceptions import ExecutionError, ExtractionError, TemplateMissingVariables

try:
    import jsonpath_ng
    _HAS_JSONPATH = True
except ImportError:  # pragma: no cover
    _HAS_JSONPATH = False

# Set by Graph.run() so all HTTP nodes in one execution share a single session.
_session_var: contextvars.ContextVar[Optional[aiohttp.ClientSession]] = (
    contextvars.ContextVar("specialweek_session", default=None)
)


class HTTP(Node):
    """Makes an HTTP request for each incoming value dict.

    URL and optional body templates use ``${variable}`` substitution. Variables
    are resolved from the merged input dict built from all upstream results. When
    two upstream nodes produce a key with the same name the graph automatically
    namespaces the conflicting copies as ``{upstream_node_id}__{key}``; use that
    form in your URL template, or resolve the conflict with an explicit mapping on
    ``depends_on``::

        # No conflict: plain key works
        HTTP("fetch_user", url="https://api.example.com/users/${user_id}",
             depends_on=[source])

        # Fan-out: response is a list; each element becomes its own result
        HTTP("fetch_posts",
             url="https://api.example.com/users/${user_id}/posts",
             extract=lambda r: r,
             depends_on=[fetch_user])

        # Two upstreams both produce "id": explicit mapping eliminates the conflict
        HTTP("process",
             url="https://api.example.com/${user_id}/actions/${action_id}",
             depends_on=[
                 (fetch_user,   {"user_id":   "id"}),
                 (fetch_action, {"action_id": "id"}),
             ])

    Args:
        node_id:     Label shown in provenance chains.
        url:         URL template; use ``${var}`` for substitution.
        method:      HTTP method (default ``"GET"``).
        body:        Optional body template string (substituted then sent as JSON).
        headers:     Optional dict of static request headers.
        extract:     Callable or JSONPath string applied to the raw JSON response.
                     Return a list to fan out. Omit to use the raw response as-is.
        on_error:    Dict of ``{status_code: callable}``; the callable receives the
                     input values dict and its return value becomes the node output.
        fallback:    Value to emit if the request fails and no ``on_error`` handler
                     applies. ``None`` (default) re-raises the exception.
        retries:     Number of attempts before giving up (default 3).
        retry_delay: Base delay in seconds between retries (default 1.0), multiplied
                     by the attempt number.
        concurrency: Optional cap on simultaneous in-flight requests from this node.
        depends_on:  Upstream nodes. See ``Node`` for mapping syntax.
    """

    def __init__(
        self,
        node_id: str,
        url: str,
        *,
        method: str = "GET",
        body: Optional[str] = None,
        headers: Optional[Dict[str, str]] = None,
        extract: Optional[Union[Callable[[Any], Any], str]] = None,
        on_error: Optional[Dict[int, Callable[[Dict[str, Any]], Any]]] = None,
        fallback: Any = None,
        retries: int = 3,
        retry_delay: float = 1.0,
        concurrency: Optional[int] = None,
        depends_on=None,
    ):
        super().__init__(node_id, depends_on)
        self.url_template = url
        self.method = method.upper()
        self.body_template = body
        self.headers = headers or {}
        self.extract = extract
        self.on_error = on_error or {}
        self.fallback = fallback
        self.retries = retries
        self.retry_delay = retry_delay
        self._semaphore = asyncio.Semaphore(concurrency) if concurrency else None

    async def run(self, value: dict[str, Any], parents: list[Result]) -> list[Result]:
        try:
            status, raw = await self._fetch(value)
        except Exception:
            if self.fallback is not None:
                return [Result(self.fallback, self.node_id, parents)]
            raise

        if status in self.on_error:
            result = self.on_error[status](value)
        else:
            result = self._extract(raw, value)

        if isinstance(result, list):
            return [Result(v, self.node_id, parents) for v in result]
        return [Result(result, self.node_id, parents)]

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    async def _fetch(self, values: Dict[str, Any]) -> tuple[int, Any]:
        """Return ``(status, body)`` where body is the parsed JSON response.

        For non-error status codes the body is the full response JSON.  For
        status codes listed in ``on_error`` the body is ``None``; the caller
        uses the status to invoke the right handler instead of running extract.
        """
        url = self._fill(self.url_template, values)
        body = self._fill(self.body_template, values) if self.body_template else None

        session = _session_var.get()
        own_session = session is None
        if own_session:
            session = aiohttp.ClientSession()

        last_exc: Optional[Exception] = None

        try:
            for attempt in range(self.retries):
                try:
                    guard = self._semaphore if self._semaphore else nullcontext()
                    async with guard:
                        async with session.request(
                            method=self.method,
                            url=url,
                            json=body,
                            headers=self.headers or None,
                        ) as response:
                            if response.status in self.on_error:
                                return response.status, None
                            if response.status == 429:
                                wait = float(
                                    response.headers.get("Retry-After", self.retry_delay)
                                )
                                await asyncio.sleep(wait)
                                continue
                            if response.status >= 400:
                                raise ExecutionError(
                                    f"[{self.node_id}] HTTP {response.status} {url}: "
                                    f"{await response.text()}"
                                )
                            return response.status, await response.json()
                except aiohttp.ClientError as e:
                    last_exc = e
                    await asyncio.sleep(self.retry_delay * (attempt + 1))
        finally:
            if own_session:
                await session.close()

        raise ExecutionError(
            f"[{self.node_id}] Request to {url!r} failed after {self.retries} "
            f"attempts: {last_exc}"
        )

    def _extract(self, raw: Any, values: Dict[str, Any]) -> Any:
        if self.extract is None:
            return raw
        if callable(self.extract):
            try:
                return self.extract(raw)
            except Exception as e:
                raise ExtractionError(
                    f"[{self.node_id}] extract callable raised: {e}"
                ) from e
        # JSONPath string
        if not _HAS_JSONPATH:
            raise ImportError(  # pragma: no cover
                "jsonpath-ng is required for JSONPath extraction: pip install jsonpath-ng"
            )
        try:
            matches = [m.value for m in jsonpath_ng.parse(self.extract).find(raw)]
        except Exception as e:
            raise ExtractionError(
                f"[{self.node_id}] JSONPath '{self.extract}' failed: {e}"
            ) from e
        if not matches:
            raise ExtractionError(
                f"[{self.node_id}] JSONPath '{self.extract}' found no matches in response"
            )
        return matches[0] if len(matches) == 1 else matches

    @staticmethod
    def _fill(template: str, values: Dict[str, Any]) -> str:
        needed = set(re.findall(r"\$\{([^}]+)\}", template))
        missing = needed - set(values.keys())
        if missing:
            raise TemplateMissingVariables(
                f"[{template!r}] variables {missing} not found in input "
                f"(available: {set(values.keys())}). "
                f"If two upstreams produced the same key, it was namespaced as "
                f"'upstream_node_id__key'. Check your template or use an explicit mapping."
            )
        return Template(template).safe_substitute(values)
