from __future__ import annotations

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from .result import Result


class Node(ABC):
    """Base class for all specialweek nodes.

    Nodes are stateless. Each call to ``run()`` receives a merged dict of values
    from all upstream nodes and the list of parent ``Result`` objects that were
    combined to produce that dict. It returns a list of ``Result`` objects; each
    element fans out independently through downstream nodes.

    Nodes declare their own antecedents via the ``depends_on`` parameter::

        fetch_user  = HTTP("fetch_user",  url="…", depends_on=[source])
        fetch_posts = HTTP("fetch_posts", url="…", depends_on=[fetch_user])

    When a node has multiple upstreams it runs once per cross-product of their
    result sets. Inputs are merged into a single flat dict; conflicting key names
    are auto-namespaced as ``{upstream_node_id}__{key}``. To rename keys
    explicitly (and avoid auto-namespacing), pass a mapping dict::

        combine = Transform(
            "combine", fn=…,
            depends_on=[
                fetch_user,                           # all keys pass through unchanged
                (fetch_posts, {"post_id": "id"}),     # upstream "id" → local "post_id"
            ],
        )

    The mapping dict has the form ``{local_name: upstream_name}``.
    """

    def __init__(self, node_id: str, depends_on: list | None = None):
        self.node_id = node_id
        self._depends_on: list[tuple[Node, dict[str, str]]] = []

        for spec in (depends_on or []):
            if isinstance(spec, Node):
                self._depends_on.append((spec, {}))
            elif (
                isinstance(spec, tuple)
                and len(spec) == 2
                and isinstance(spec[0], Node)
                and isinstance(spec[1], dict)
            ):
                upstream, mapping = spec
                self._depends_on.append((upstream, mapping))
            else:
                raise ValueError(
                    f"Each entry in 'depends_on' must be a Node or a (Node, dict) tuple; "
                    f"got {spec!r}"
                )

    @property
    def upstream_nodes(self) -> list[Node]:
        return [node for node, _ in self._depends_on]

    @abstractmethod
    async def run(self, value: dict[str, Any], parents: list[Result]) -> list[Result]:
        """Execute this node.

        ``value``:   merged dict built from all upstream results + declared mappings.
        ``parents``: the ``Result`` objects that contributed to ``value``, one per
                      upstream (in the same order as ``depends_on``).

        Always return a list. Each element fans out as its own independent result
        flowing through downstream nodes.
        """
