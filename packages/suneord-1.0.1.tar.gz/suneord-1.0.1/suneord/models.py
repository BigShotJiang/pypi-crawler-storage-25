from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any


class Color:
    RED = 0xED4245
    GREEN = 0x57F287
    BLUE = 0x5865F2
    YELLOW = 0xFEE75C
    BLURPLE = 0x5865F2
    WHITE = 0xFFFFFF
    BLACK = 0x000000
    ORANGE = 0xFAA61A
    FUCHSIA = 0xEB459E
    AQUA = 0x1ABC9C
    GRAY = 0x95A5A6


@dataclass(slots=True)
class Embed:
    title: str | None = None
    description: str | None = None
    url: str | None = None
    color: int | None = None
    timestamp: str | None = None
    fields: list[dict[str, Any]] = field(default_factory=list)
    author: dict[str, Any] | None = None
    thumbnail: dict[str, Any] | None = None
    image: dict[str, Any] | None = None
    footer: dict[str, Any] | None = None

    def set_title(self, value: str | None) -> "Embed":
        self.title = value
        return self

    def set_description(self, value: str | None) -> "Embed":
        self.description = value
        return self

    def set_color(self, value: int | None) -> "Embed":
        self.color = value
        return self

    def set_url(self, value: str | None) -> "Embed":
        self.url = value
        return self

    def add_field(self, *, name: str, value: str, inline: bool = False) -> "Embed":
        self.fields.append({"name": name, "value": value, "inline": inline})
        return self

    def remove_field(self, index: int) -> "Embed":
        self.fields.pop(index)
        return self

    def clear_fields(self) -> "Embed":
        self.fields.clear()
        return self

    def set_author(
        self,
        *,
        name: str,
        url: str | None = None,
        icon_url: str | None = None,
    ) -> "Embed":
        author = {"name": name}
        if url is not None:
            author["url"] = url
        if icon_url is not None:
            author["icon_url"] = icon_url
        self.author = author
        return self

    def set_thumbnail(self, *, url: str) -> "Embed":
        self.thumbnail = {"url": url}
        return self

    def set_image(self, *, url: str) -> "Embed":
        self.image = {"url": url}
        return self

    def set_footer(self, *, text: str, icon_url: str | None = None) -> "Embed":
        footer = {"text": text}
        if icon_url is not None:
            footer["icon_url"] = icon_url
        self.footer = footer
        return self

    def set_timestamp(self, value: datetime | None = None) -> "Embed":
        timestamp = value or datetime.now(timezone.utc)
        self.timestamp = timestamp.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")
        return self

    def copy(self) -> "Embed":
        return Embed.from_dict(self.to_dict())

    @classmethod
    def from_dict(cls, payload: dict[str, Any]) -> "Embed":
        return cls(
            title=payload.get("title"),
            description=payload.get("description"),
            url=payload.get("url"),
            color=payload.get("color"),
            timestamp=payload.get("timestamp"),
            fields=list(payload.get("fields", [])),
            author=payload.get("author"),
            thumbnail=payload.get("thumbnail"),
            image=payload.get("image"),
            footer=payload.get("footer"),
        )

    def to_dict(self) -> dict[str, Any]:
        payload: dict[str, Any] = {}
        if self.title is not None:
            payload["title"] = self.title
        if self.description is not None:
            payload["description"] = self.description
        if self.url is not None:
            payload["url"] = self.url
        if self.color is not None:
            payload["color"] = self.color
        if self.timestamp is not None:
            payload["timestamp"] = self.timestamp
        if self.fields:
            payload["fields"] = self.fields
        if self.author is not None:
            payload["author"] = self.author
        if self.thumbnail is not None:
            payload["thumbnail"] = self.thumbnail
        if self.image is not None:
            payload["image"] = self.image
        if self.footer is not None:
            payload["footer"] = self.footer
        return payload
