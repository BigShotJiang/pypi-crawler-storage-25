from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable, Iterable


ModalCallback = Callable[..., Any]


class TextInputStyle:
    SHORT = 1
    PARAGRAPH = 2


@dataclass(slots=True)
class TextInput:
    custom_id: str
    label: str
    style: int = TextInputStyle.SHORT
    placeholder: str | None = None
    value: str | None = None
    required: bool = True
    min_length: int | None = None
    max_length: int | None = None

    def to_dict(self) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "type": 4,
            "custom_id": self.custom_id,
            "label": self.label,
            "style": self.style,
            "required": self.required,
        }
        if self.placeholder is not None:
            payload["placeholder"] = self.placeholder
        if self.value is not None:
            payload["value"] = self.value
        if self.min_length is not None:
            payload["min_length"] = self.min_length
        if self.max_length is not None:
            payload["max_length"] = self.max_length
        return payload


@dataclass(slots=True)
class Modal:
    custom_id: str
    title: str
    components: tuple[TextInput, ...]
    callback: ModalCallback | None = None
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "custom_id": self.custom_id,
            "title": self.title,
            "components": [
                {
                    "type": 1,
                    "components": [component.to_dict()],
                }
                for component in self.components
            ],
        }


def modal(
    *,
    custom_id: str,
    title: str,
    components: Iterable[TextInput],
    **metadata: Any,
) -> Callable[[ModalCallback], ModalCallback]:
    def decorator(callback: ModalCallback) -> ModalCallback:
        callback.__suneord_modal__ = {
            "custom_id": custom_id,
            "title": title,
            "components": tuple(components),
            "metadata": metadata,
        }
        return callback

    return decorator
