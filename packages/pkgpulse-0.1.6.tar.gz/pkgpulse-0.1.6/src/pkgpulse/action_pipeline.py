"""Action execution pipeline helpers."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

from .actions import ActionResult, build_action_context, dispatch_action

if TYPE_CHECKING:
    from .actions import ActionContext
    from .config import ActionSpec, Config, TargetSpec
    from .nvchecker import CheckResult
    from .render import RenderResult


def should_run_action(
    action: ActionSpec,
    check: CheckResult | None,
    render: RenderResult,
) -> bool:
    """Decide whether an action should run for the current target result.

    Args:
        action (ActionSpec): Action configuration being evaluated.
        check (CheckResult | None): Update-check result for the target, if one
            exists.
        render (RenderResult): Render result for the target output.

    Returns:
        bool: `True` when the action condition matches the current target
        state.

    Raises:
        ValueError: If `action.when` contains an unsupported condition.

    """
    when = action.when
    if when == "always":
        return True
    if when == "changed":
        return render.changed
    if when == "updated":
        return check is not None and check.changed
    if when == "rendered":
        return render.changed
    raise ValueError(f"unsupported action when={when!r}")


@dataclass(slots=True)
class ActionPipeline:
    """Run a target's configured actions with isolated failure handling."""

    context: ActionContext
    actions: list[ActionSpec]

    def execute(self) -> list[ActionResult]:
        """Execute configured actions in order.

        Returns:
            list[ActionResult]: A list of per-action execution results.

        """
        results: list[ActionResult] = []

        for action in self.actions:
            try:
                if not should_run_action(action, self.context.check, self.context.render):
                    results.append(
                        ActionResult(
                            kind=action.type,
                            ok=True,
                            detail="condition not met",
                            skipped=True,
                        )
                    )
                    continue

                results.append(dispatch_action(action, self.context))
            except Exception as exc:
                # Actions are plugin-style boundaries; isolate failures per action.
                results.append(ActionResult(kind=action.type, ok=False, detail=str(exc)))

        return results


def run_actions(
    config: Config,
    target: TargetSpec,
    check: CheckResult | None,
    render: RenderResult,
) -> list[ActionResult]:
    """Build action context and execute the target's actions.

    Args:
        config (Config): Loaded project configuration.
        target (TargetSpec): Target whose actions should run.
        check (CheckResult | None): Update-check result for the target, if
            present.
        render (RenderResult): Render result for the target output.

    Returns:
        list[ActionResult]: The ordered list of action execution results.

    """
    context = build_action_context(config, target, check, render)
    return ActionPipeline(context=context, actions=target.actions).execute()
