"""nvchecker integration and state management."""

from __future__ import annotations

import asyncio
import dataclasses
import json
from dataclasses import dataclass
from typing import TYPE_CHECKING

from nvchecker import core
from nvchecker.api import EntryWaiter, KeyManager

if TYPE_CHECKING:
    from pathlib import Path

    from nvchecker.api import RichResult

    from .config import Config, NvcheckerConfig, TargetSpec


@dataclass(slots=True)
class CheckResult:
    """Normalized result for a single target update check."""

    name: str
    version: str
    old_version: str | None
    changed: bool
    url: str | None = None
    revision: str | None = None
    gitref: str | None = None
    raw_result: RichResult | None = None


@dataclass(slots=True)
class CheckRun:
    """Batch result for a set of target update checks."""

    results: dict[str, CheckResult]
    failures: dict[str, str]


def _load_verfile(path: Path) -> dict[str, RichResult]:
    try:
        return core.read_verfile(path)
    except (FileNotFoundError, json.JSONDecodeError, OSError, ValueError):
        return {}


def _write_verfile(path: Path, data: dict[str, RichResult]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "version": 2,
        "data": {
            name: {
                key: value for key, value in dataclasses.asdict(result).items() if value is not None
            }
            for name, result in sorted(data.items())
        },
    }
    encoded = json.dumps(payload, indent=2, ensure_ascii=False) + "\n"
    tmp_path = path.with_name(path.name + ".tmp")
    tmp_path.write_text(encoded, encoding="utf-8")
    tmp_path.replace(path)


async def _close_http_session() -> None:
    client = getattr(core.httpclient.session, "_obj", None)
    if client is None:
        return
    aclose = getattr(client, "aclose", None)
    close = getattr(client, "close", None)
    if callable(aclose):
        await aclose()
    elif callable(close):
        close()


async def _run_checks_async(
    entries: dict[str, dict[str, object]],
    settings: NvcheckerConfig,
    oldvers: dict[str, RichResult],
) -> CheckRun:
    if not entries:
        return CheckRun(results={}, failures={})

    dispatcher = core.setup_httpclient(
        max_concurrency=settings.max_concurrency,
        httplib=settings.httplib,
        http_timeout=settings.http_timeout,
    )
    result_q: asyncio.Queue[core.RawResult] = asyncio.Queue()
    task_sem = asyncio.Semaphore(settings.max_concurrency)
    entry_waiter = EntryWaiter()
    keymanager = KeyManager(settings.keyfile)

    try:
        coroutines = dispatcher.dispatch(
            entries,
            task_sem,
            result_q,
            keymanager,
            entry_waiter,
            settings.tries,
            settings.source_configs,
        )
        tasks = [asyncio.create_task(coro) for coro in coroutines]
        await asyncio.gather(*tasks)

        results: dict[str, CheckResult] = {}
        failures: dict[str, str] = {}
        seen: set[str] = set()

        while not result_q.empty():
            raw_result = result_q.get_nowait()
            seen.add(raw_result.name)
            processed = core._process_result(raw_result)  # type: ignore[attr-defined]
            if isinstance(processed, Exception):
                failures[raw_result.name] = str(processed)
                continue

            old_result = oldvers.get(raw_result.name)
            old_version = old_result.version if old_result is not None else None
            results[raw_result.name] = CheckResult(
                name=raw_result.name,
                version=processed.version,
                old_version=old_version,
                changed=old_version != processed.version,
                url=processed.url,
                revision=processed.revision,
                gitref=processed.gitref,
                raw_result=processed,
            )

        for missing in set(entries) - seen:
            failures[missing] = "nvchecker returned no result"

        return CheckRun(results=results, failures=failures)
    finally:
        await _close_http_session()


def _collect_entries(targets: list[TargetSpec]) -> dict[str, dict[str, object]]:
    entries: dict[str, dict[str, object]] = {}
    for target in targets:
        if target.check is not None:
            entries[target.name] = dict(target.check.entry)
    return entries


def check_targets(config: Config, targets: list[TargetSpec]) -> CheckRun:
    """Run nvchecker for the selected targets and refresh `newver`.

    Args:
        config (Config): Loaded project configuration.
        targets (list[TargetSpec]): Targets to check for upstream updates.

    Returns:
        CheckRun: The batch check result, including successful results and
        failures.

    """
    entries = _collect_entries(targets)
    if not entries:
        return CheckRun(results={}, failures={})

    oldvers = _load_verfile(config.state.oldver)
    run = asyncio.run(_run_checks_async(entries, config.nvchecker, oldvers))

    newver_payload = _load_verfile(config.state.newver)
    newver_payload.update(
        {name: result.raw_result for name, result in run.results.items() if result.raw_result}
    )
    _write_verfile(config.state.newver, newver_payload)
    return run


def promote_successful_versions(config: Config, results: dict[str, CheckResult]) -> None:
    """Promote successful check results into `oldver` state.

    Args:
        config (Config): Loaded project configuration.
        results (dict[str, CheckResult]): Successful check results keyed by
            target name.

    """
    oldvers = _load_verfile(config.state.oldver)
    for name, result in results.items():
        if result.raw_result is not None:
            oldvers[name] = result.raw_result
    _write_verfile(config.state.oldver, oldvers)
