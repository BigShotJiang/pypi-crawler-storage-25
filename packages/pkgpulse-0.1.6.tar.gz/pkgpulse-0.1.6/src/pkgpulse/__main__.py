"""Module entrypoint for running pkgpulse with `python -m pkgpulse`."""

from .cli import main

if __name__ == "__main__":
    raise SystemExit(main())
