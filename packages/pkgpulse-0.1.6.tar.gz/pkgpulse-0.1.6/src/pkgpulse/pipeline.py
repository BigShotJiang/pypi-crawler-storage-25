"""High-level pipeline orchestration."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING

from .action_pipeline import run_actions
from .nvchecker import check_targets, promote_successful_versions
from .render import render_target

if TYPE_CHECKING:
    from .actions import ActionResult
    from .config import Config, TargetSpec
    from .nvchecker import CheckResult, CheckRun
    from .render import RenderResult


@dataclass(slots=True)
class TargetRun:
    """Execution result for a single target."""

    target: TargetSpec
    check: CheckResult | None = None
    render: RenderResult | None = None
    actions: list[ActionResult] = field(default_factory=list)
    error: str | None = None

    @property
    def ok(self) -> bool:
        """Return whether the target completed without errors."""
        return self.error is None and all(action.ok for action in self.actions)


@dataclass(slots=True)
class PipelineRun:
    """Execution result for a pipeline run across multiple targets."""

    checks: CheckRun
    targets: list[TargetRun]

    @property
    def ok(self) -> bool:
        """Return whether the full pipeline completed without failures."""
        return not self.checks.failures and all(target.ok for target in self.targets)


def select_targets(config: Config, names: list[str]) -> list[TargetSpec]:
    """Select configured targets by name.

    Args:
        config (Config): Loaded project configuration.
        names (list[str]): Optional list of target names to select.

    Returns:
        list[TargetSpec]: The selected targets, or all targets when `names` is
        empty.

    Raises:
        ValueError: If any requested target names are unknown.

    """
    if not names:
        return config.targets
    selected = [target for target in config.targets if target.name in names]
    missing = sorted(set(names) - {target.name for target in selected})
    if missing:
        raise ValueError(f"unknown targets: {', '.join(missing)}")
    return selected


def run_pipeline(
    config: Config,
    targets: list[TargetSpec],
    *,
    render_outputs: bool,
    write: bool,
    execute_actions: bool,
    promote_versions: bool,
) -> PipelineRun:
    """Run update checks, rendering, and optional actions for selected targets.

    Args:
        config (Config): Loaded project configuration.
        targets (list[TargetSpec]): Targets selected for execution.
        render_outputs (bool): Whether templates should be rendered.
        write (bool): Whether rendered output should be written to disk.
        execute_actions (bool): Whether configured actions should run.
        promote_versions (bool): Whether successful results should update
            `oldver`.

    Returns:
        PipelineRun: The aggregated pipeline result.

    """
    checks = check_targets(config, targets)
    target_runs: list[TargetRun] = []
    promoted: dict[str, CheckResult] = {}

    for target in targets:
        check = checks.results.get(target.name)
        if target.check is not None and check is None:
            target_runs.append(
                TargetRun(
                    target=target,
                    error=checks.failures.get(target.name, "check result missing"),
                )
            )
            continue

        if not render_outputs:
            target_runs.append(TargetRun(target=target, check=check))
            if check is not None and promote_versions:
                promoted[target.name] = check
            continue

        try:
            render = render_target(config, target, check, write=write)
        except Exception as exc:
            # Rendering happens at a user-configurable template boundary.
            target_runs.append(TargetRun(target=target, check=check, error=str(exc)))
            continue

        target_run = TargetRun(target=target, check=check, render=render)
        if execute_actions:
            try:
                target_run.actions = run_actions(config, target, check, render)
            except Exception as exc:
                # Actions are isolated so one target failure does not abort the run.
                target_run.error = str(exc)

        if target_run.ok and check is not None and promote_versions:
            promoted[target.name] = check

        target_runs.append(target_run)

    if promote_versions and promoted:
        promote_successful_versions(config, promoted)

    return PipelineRun(checks=checks, targets=target_runs)
