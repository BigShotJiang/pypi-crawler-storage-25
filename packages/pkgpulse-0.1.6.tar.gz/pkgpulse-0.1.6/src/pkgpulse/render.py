"""Template rendering helpers."""

from __future__ import annotations

from dataclasses import asdict, dataclass
from datetime import UTC, datetime
from difflib import unified_diff
from typing import TYPE_CHECKING, Any

from jinja2 import Environment, FileSystemLoader, StrictUndefined

if TYPE_CHECKING:
    from pathlib import Path

    from .config import Config, TargetSpec
    from .nvchecker import CheckResult


@dataclass(slots=True)
class RenderResult:
    """Result of rendering a single target."""

    target_name: str
    output: Path
    rendered: str
    previous: str
    changed: bool

    @property
    def diff(self) -> str:
        """Return a unified diff for changed output, or an empty string."""
        if not self.changed:
            return ""
        before = self.previous.splitlines(keepends=True)
        after = self.rendered.splitlines(keepends=True)
        return "".join(
            unified_diff(
                before,
                after,
                fromfile=str(self.output),
                tofile=str(self.output),
            )
        )


def make_environment(template_dir: Path) -> Environment:
    """Create a Jinja environment rooted at a target template directory.

    Args:
        template_dir (Path): Directory containing the target template.

    Returns:
        Environment: A strict Jinja environment configured for plain-text
        templates.

    """
    return Environment(
        loader=FileSystemLoader(template_dir),
        undefined=StrictUndefined,
        autoescape=False,
        trim_blocks=True,
        lstrip_blocks=True,
    )


def build_runtime_context(
    config: Config,
    target: TargetSpec,
    check: CheckResult | None,
) -> dict[str, Any]:
    """Build the template context for a target render.

    Args:
        config (Config): Loaded project configuration.
        target (TargetSpec): Target being rendered.
        check (CheckResult | None): Update-check result for the target, if
            present.

    Returns:
        dict[str, Any]: The context mapping exposed to the template and inline
        render helpers.

    """
    context = {
        "job": {
            "name": target.name,
            "template": str(target.template),
            "output": str(target.output),
            "context": target.context,
        },
        "target": {
            "name": target.name,
            "template": str(target.template),
            "output": str(target.output),
        },
        "paths": {
            "project_root": str(config.root),
            "template": str(target.template),
            "output": str(target.output),
        },
        "check": asdict(check) if check is not None else None,
        "context": target.context,
        "now": datetime.now(UTC).isoformat(timespec="seconds"),
    }
    context.update(target.context)
    return context


def render_inline(value: Any, env: Environment, context: dict[str, Any]) -> Any:
    """Render strings nested inside Python values.

    Args:
        value (Any): String, list, dict, or scalar to render recursively.
        env (Environment): Jinja environment used to render inline templates.
        context (dict[str, Any]): Runtime template context.

    Returns:
        Any: The rendered value with strings expanded recursively.

    """
    if isinstance(value, str):
        return env.from_string(value).render(**context)
    if isinstance(value, list):
        return [render_inline(item, env, context) for item in value]
    if isinstance(value, dict):
        return {key: render_inline(item, env, context) for key, item in value.items()}
    return value


def render_target(
    config: Config,
    target: TargetSpec,
    check: CheckResult | None,
    *,
    write: bool,
) -> RenderResult:
    """Render a target template and optionally write the output file.

    Args:
        config (Config): Loaded project configuration.
        target (TargetSpec): Target to render.
        check (CheckResult | None): Update-check result for the target, if
            present.
        write (bool): Whether the rendered output should be written to disk.

    Returns:
        RenderResult: The render result, including the previous content and
        diff state.

    """
    env = make_environment(target.template.parent)
    context = build_runtime_context(config, target, check)
    rendered = env.get_template(target.template.name).render(**context)
    previous = target.output.read_text(encoding="utf-8") if target.output.exists() else ""
    changed = rendered != previous

    if write and changed:
        target.output.parent.mkdir(parents=True, exist_ok=True)
        target.output.write_text(rendered, encoding="utf-8")

    return RenderResult(
        target_name=target.name,
        output=target.output,
        rendered=rendered,
        previous=previous,
        changed=changed,
    )
