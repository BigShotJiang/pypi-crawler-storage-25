"""ai-shell CLI entry point."""

import logging
import sys

import click

from ai_shell import __version__
from ai_shell.cli.commands.llm import llm_group
from ai_shell.cli.commands.manage import manage_group
from ai_shell.cli.commands.tools import aider, claude, codex, init, opencode, shell


@click.group()
@click.version_option(version=__version__, prog_name="ai-shell")
@click.option("--project", default=None, help="Override project name for container naming.")
@click.option("--verbose", "-v", is_flag=True, default=False, help="Enable debug logging.")
@click.pass_context
def cli(ctx, project, verbose):
    """AI Shell - Launch AI coding tools and local LLMs in Docker containers."""
    ctx.ensure_object(dict)
    ctx.obj["project"] = project
    if verbose:
        logging.basicConfig(level=logging.DEBUG, format="%(name)s: %(message)s")


# Tool subcommands
cli.add_command(claude)
cli.add_command(codex)
cli.add_command(opencode)
cli.add_command(aider)
cli.add_command(shell)
cli.add_command(init)

# Command groups
cli.add_command(llm_group, "llm")
cli.add_command(manage_group, "manage")


def main():
    """Main entry point."""
    try:
        cli()
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


if __name__ == "__main__":
    main()
