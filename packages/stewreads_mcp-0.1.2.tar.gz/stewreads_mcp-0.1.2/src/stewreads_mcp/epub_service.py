from __future__ import annotations

import asyncio
import re
import shutil
import tempfile
import unicodedata
from pathlib import Path
from typing import Optional

import pypandoc

DEFAULT_LANGUAGE = "en-US"

# Keep typography close to the existing StewReads backend EPUB output.
DEFAULT_CSS = """
h1, h2, h3, h4, h5, h6 {
    font-family: serif;
    font-weight: 700;
    line-height: 1.3;
    margin-top: 1.5em;
    margin-bottom: 0.5em;
}

h1 { font-size: 2em; }
h2 { font-size: 1.5em; }
h3 { font-size: 1.25em; }

body, p, li, blockquote {
    font-family: serif;
    line-height: 1.6;
}

p { margin-bottom: 1em; }
ul, ol { margin-bottom: 1em; }
li { margin-bottom: 0.5em; }

blockquote {
    margin: 1em 2em;
    padding-left: 1em;
    border-left: 3px solid #ccc;
    font-style: italic;
}
"""


def create_appendix_content(
    original_prompt: Optional[str] = None,
    model_id: Optional[str] = None,
    model_name: Optional[str] = None,
) -> str:
    """Create appendix content for the ebook."""
    if not original_prompt and not model_id:
        return ""

    appendix = "\n\n<div style=\"page-break-before: always;\"></div>\n\n# Appendix\n\n"

    if original_prompt:
        appendix += "## Original Request\n\n"
        appendix += f"> {original_prompt}\n\n"

    if model_id or model_name:
        appendix += "## Generation Details\n\n"
        if model_name and model_id:
            appendix += f"**AI Model:** {model_name} ({model_id})\n\n"
        elif model_name:
            appendix += f"**AI Model:** {model_name}\n\n"
        else:
            appendix += f"**AI Model:** {model_id}\n\n"

    appendix += "*This ebook was generated using artificial intelligence.*"
    return appendix


def sanitize_filename(filename: str) -> str:
    """Sanitize filename for safe file operations."""
    if not filename:
        return "ebook"

    normalized = unicodedata.normalize("NFKD", filename)
    ascii_only = normalized.encode("ascii", "ignore").decode("ascii")
    ascii_only = ascii_only.replace("/", "-").replace("\\", "-")
    ascii_only = re.sub(r"[^\w\s\-.()]+", "", ascii_only)
    ascii_only = re.sub(r"\s+", " ", ascii_only).strip()
    ascii_only = ascii_only.lstrip(".").strip()
    return ascii_only or "ebook"


def normalize_language_code(language: Optional[str]) -> str:
    """Normalize detected language codes to a BCP-47 style value."""
    if not language:
        return DEFAULT_LANGUAGE

    code = language.strip()
    if not code:
        return DEFAULT_LANGUAGE

    code = code.replace("_", "-")
    code = re.sub(r"[^A-Za-z-]", "", code).strip("-")
    if not code:
        return DEFAULT_LANGUAGE

    parts = [part for part in code.split("-") if part]
    if not parts:
        return DEFAULT_LANGUAGE

    normalized_parts = []
    for index, part in enumerate(parts):
        if index == 0:
            normalized_parts.append(part.lower())
        elif len(part) == 2:
            normalized_parts.append(part.upper())
        else:
            normalized_parts.append(part.capitalize())

    normalized = "-".join(normalized_parts)
    if normalized.lower() in {"c", "und"}:
        return DEFAULT_LANGUAGE

    return normalized


def _run_pandoc(md_file: Path, epub_file: Path, title: str, language_code: str, css_file: Path) -> None:
    safe_title = title.replace("\n", " ").strip()
    extra_args = [
        f"--metadata=title:{safe_title}",
        "--metadata=author:StewReads",
        f"--metadata=language:{language_code}",
        f"--metadata=lang:{language_code}",
        f"--css={css_file}",
        "--standalone",
    ]

    pypandoc.convert_file(
        str(md_file),
        "epub",
        outputfile=str(epub_file),
        extra_args=extra_args,
    )


async def convert_markdown_to_epub(
    markdown: str,
    title: str,
    output_dir: Path,
    filename: Optional[str] = None,
    original_prompt: Optional[str] = None,
    model_id: Optional[str] = None,
    model_name: Optional[str] = None,
    language: Optional[str] = None,
) -> Path:
    """Convert markdown content to EPUB and save it to output_dir."""
    if not markdown or not markdown.strip():
        raise ValueError("Markdown content is required.")
    if not title or not title.strip():
        raise ValueError("Title is required.")

    output_dir.mkdir(parents=True, exist_ok=True)
    sanitized_filename = sanitize_filename(filename or title)
    target_path = output_dir / f"{sanitized_filename}.epub"

    language_code = normalize_language_code(language)
    appendix = create_appendix_content(original_prompt, model_id, model_name)
    full_markdown = markdown + appendix

    try:
        with tempfile.TemporaryDirectory(prefix="stewreads-epub-") as tmp_dir:
            temp_dir = Path(tmp_dir)
            md_file = temp_dir / f"{sanitized_filename}.md"
            css_file = temp_dir / f"{sanitized_filename}.css"
            epub_file = temp_dir / f"{sanitized_filename}.epub"

            md_file.write_text(full_markdown, encoding="utf-8")
            css_file.write_text(DEFAULT_CSS, encoding="utf-8")

            loop = asyncio.get_running_loop()
            await loop.run_in_executor(
                None,
                _run_pandoc,
                md_file,
                epub_file,
                title,
                language_code,
                css_file,
            )

            if not epub_file.exists():
                raise ValueError("EPUB conversion completed but no file was produced.")

            shutil.move(str(epub_file), str(target_path))
            return target_path

    except (OSError, RuntimeError) as exc:
        message = str(exc)
        if "pandoc" in message.lower():
            raise ValueError(
                "Pandoc is not installed or not accessible. Reinstall stewreads-mcp so bundled pandoc is available."
            ) from exc
        raise ValueError(f"Failed to convert markdown to EPUB: {message}") from exc
    except ValueError:
        raise
    except Exception as exc:
        raise ValueError(f"Failed to convert markdown to EPUB: {exc}") from exc
