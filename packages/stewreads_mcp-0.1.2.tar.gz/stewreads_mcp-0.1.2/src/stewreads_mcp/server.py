from __future__ import annotations

import os
import sys
import asyncio
from pathlib import Path
from typing import Any, Optional

from fastmcp import FastMCP

from stewreads_mcp.config import (
    ConfigError,
    ensure_output_directory,
    get_config_status,
    load_config,
    update_config_output_dir,
)
from stewreads_mcp.epub_service import convert_markdown_to_epub, sanitize_filename
from stewreads_mcp.audio_service import (
    ELEVENLABS_API_KEY_ENV,
    ELEVENLABS_DEFAULT_VOICE_ID,
    ELEVENLABS_VOICE_ID_ENV,
    AudioServiceError,
    generate_audiobook,
)
from stewreads_mcp.email_service import (
    GMAIL_APP_PASSWORD_ENV,
    resolve_epub_path,
    send_epub_email,
)
from stewreads_mcp.prompts import get_stew_prompt_template as get_prompt_text

mcp = FastMCP("stewreads")

_background_tasks: set[asyncio.Task] = set()


def log_to_stderr(message: str) -> None:
    print(f"[STEWREADS] {message}", file=sys.stderr, flush=True)


def _success_result(title: str, saved_path: Path, size_bytes: int) -> dict[str, Any]:
    return {
        "ok": True,
        "title": title,
        "format": "epub",
        "path": str(saved_path),
        "size_bytes": size_bytes,
        "message": f"Saved ebook '{title}' as EPUB.",
    }


def _error_result(error_code: str, message: str, **extra: Any) -> dict[str, Any]:
    payload: dict[str, Any] = {
        "ok": False,
        "error_code": error_code,
        "message": message,
    }
    payload.update(extra)
    return payload


def _is_env_var_set(name: str) -> bool:
    value = os.getenv(name)
    return bool(value and value.strip())


@mcp.tool()
def get_stew_prompt() -> str:
    """Return the StewReads markdown generation prompt used for ebook creation."""
    return get_prompt_text()


@mcp.tool(
    name="get_stew_config",
    description=(
        "Read current non-sensitive StewReads config status. "
        "Use this before save_ebook to confirm output_dir is configured."
    ),
)
def get_stew_config() -> dict:
    """Get current local StewReads config status."""
    return get_config_status()


@mcp.tool(
    name="get_email_status",
    description=(
        "Check whether Gmail email sending is configured. "
        "Requires from_email in config and STEWREADS_GMAIL_APP_PASSWORD in env."
    ),
)
def get_email_status() -> dict[str, Any]:
    """Return non-secret readiness checks for Gmail SMTP sending."""
    try:
        config = load_config()
        app_password_set = _is_env_var_set(GMAIL_APP_PASSWORD_ENV)
        ready = bool(config.from_email and app_password_set)
        return {
            "ok": True,
            "ready": ready,
            "from_email": config.from_email,
            "default_to_email": config.default_to_email,
            "gmail_app_password_set": app_password_set,
            "message": (
                "Email is configured."
                if ready
                else "Email is partially configured. Set from_email and Gmail app password."
            ),
        }
    except ConfigError as exc:
        return _error_result(
            "config_error",
            str(exc),
            ready=False,
            gmail_app_password_set=_is_env_var_set(GMAIL_APP_PASSWORD_ENV),
        )


@mcp.tool(
    name="save_stew_config",
    description=(
        "Save user-configurable non-sensitive StewReads settings. "
        "If output_dir is missing, ask the user for their preferred local folder and call this tool. "
        "Do not use for passwords or secrets."
    ),
)
def save_stew_config(output_dir: str) -> dict:
    """Create/update local config file with output directory."""
    try:
        updated = update_config_output_dir(output_dir)
        status = get_config_status()
        status["saved"] = True
        status["message"] = f"Config saved. output_dir set to {updated.output_dir}."
        return status
    except ConfigError as exc:
        return {
            "saved": False,
            "configured": False,
            "output_dir": None,
            "config_path": str(get_config_status().get("config_path")),
            "message": str(exc),
        }


@mcp.tool(
    name="save_ebook",
    description=(
        "Save completed ebook markdown as an EPUB file in the user's configured output "
        "directory. Use this after writing the full ebook content. "
        "If config is missing, ask the user for a directory and call save_stew_config first. "
        "Arguments: markdown, title, optional filename, optional original_prompt, "
        "optional create_audio (requires ELEVENLABS_API_KEY env var)."
    ),
)
async def save_ebook(
    markdown: str,
    title: str,
    filename: Optional[str] = None,
    original_prompt: Optional[str] = None,
    create_audio: bool = False,
) -> dict[str, Any]:
    """Convert markdown to EPUB and save it locally in the configured output directory.

    If create_audio=True, also generates an MP3 audiobook via ElevenLabs TTS.
    Requires ELEVENLABS_API_KEY to be set in the environment.
    EPUB is always saved first; audio failure does not prevent EPUB delivery.
    """
    log_to_stderr(f"Saving EPUB ebook for title={title!r}, filename={filename!r}, create_audio={create_audio}")

    try:
        config = load_config()
        output_dir = ensure_output_directory(config.output_dir)
        saved_path = await convert_markdown_to_epub(
            markdown=markdown,
            title=title,
            output_dir=output_dir,
            filename=filename,
            original_prompt=original_prompt,
        )

        resolved_path = Path(saved_path).resolve()
        size_bytes = resolved_path.stat().st_size

    except ConfigError as exc:
        return _error_result(
            "config_error",
            str(exc),
            next_step=(
                "Ask the user for a save directory and call "
                "save_stew_config(output_dir='...'), then call save_ebook again."
            ),
        )
    except ValueError as exc:
        return _error_result("conversion_error", str(exc))
    except Exception as exc:  # Defensive catch for tool stability.
        log_to_stderr(f"Unexpected conversion error: {exc}")
        return _error_result("unexpected_error", str(exc))

    epub_result = _success_result(title=title, saved_path=resolved_path, size_bytes=size_bytes)

    if not create_audio:
        return epub_result

    api_key = os.getenv(ELEVENLABS_API_KEY_ENV, "").strip()
    if not api_key:
        return {
            **epub_result,
            "audio_error": f"{ELEVENLABS_API_KEY_ENV} is not set.",
            "message": f"Saved EPUB. Audio skipped: {ELEVENLABS_API_KEY_ENV} is not set.",
        }

    voice_id = os.getenv(ELEVENLABS_VOICE_ID_ENV, "").strip() or ELEVENLABS_DEFAULT_VOICE_ID
    audio_path = output_dir / f"{sanitize_filename(filename or title)}.mp3"

    task = asyncio.create_task(generate_audiobook(markdown, audio_path, api_key, voice_id))
    _background_tasks.add(task)
    task.add_done_callback(_background_tasks.discard)

    return {
        **epub_result,
        "audio_status": "generating",
        "audio_path": str(audio_path),
        "message": f"Saved EPUB. Audiobook is generating in the background — check your output folder in a minute.",
    }


@mcp.tool(
    name="email_ebook",
    description=(
        "Send an EPUB via Gmail SMTP using App Password auth. "
        "If ebook_path is omitted, the most recent EPUB in output_dir is attached. "
        "Requires config email.from_email and env STEWREADS_GMAIL_APP_PASSWORD."
    ),
)
async def email_ebook(
    to_email: Optional[str] = None,
    ebook_path: Optional[str] = None,
    subject: Optional[str] = None,
    body: Optional[str] = None,
) -> dict[str, Any]:
    """Email an EPUB attachment using Gmail SMTP."""
    try:
        config = load_config()
        output_dir = ensure_output_directory(config.output_dir)
    except ConfigError as exc:
        return _error_result("config_error", str(exc))

    from_email = (config.from_email or "").strip()
    if not from_email:
        return _error_result(
            "email_config_error",
            "Missing sender email. Set [email].from_email in config or STEWREADS_FROM_EMAIL.",
        )

    recipient = (to_email or config.default_to_email or "").strip()
    if not recipient:
        return _error_result(
            "email_config_error",
            "Missing recipient email. Provide to_email or set [email].default_to_email.",
        )

    app_password = os.getenv(GMAIL_APP_PASSWORD_ENV, "").strip()
    if not app_password:
        return _error_result(
            "email_secret_missing",
            f"Missing {GMAIL_APP_PASSWORD_ENV}. Set it in your Claude MCP server env.",
        )

    try:
        attachment = resolve_epub_path(output_dir=output_dir, ebook_path=ebook_path)
        loop = asyncio.get_running_loop()
        final_subject = await loop.run_in_executor(
            None,
            send_epub_email,
            from_email,
            app_password,
            recipient,
            attachment,
            subject,
            body,
        )
        size_bytes = attachment.stat().st_size
        return {
            "ok": True,
            "from_email": from_email,
            "to_email": recipient,
            "path": str(attachment),
            "size_bytes": size_bytes,
            "subject": final_subject,
            "message": "Email sent successfully.",
        }
    except ValueError as exc:
        return _error_result("email_send_error", str(exc))
    except Exception as exc:
        log_to_stderr(f"Unexpected email error: {exc}")
        return _error_result("unexpected_error", str(exc))


def main() -> None:
    # stdio transport for Claude Desktop local MCP integration.
    mcp.run(
        transport="stdio",
        show_banner=False,
        log_level="ERROR",
    )


if __name__ == "__main__":
    main()
