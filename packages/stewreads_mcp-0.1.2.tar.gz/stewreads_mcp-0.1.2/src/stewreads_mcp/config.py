from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any

try:
    import tomllib
except ModuleNotFoundError:  # Python < 3.11
    import tomli as tomllib

CONFIG_PATH_ENV = "STEWREADS_CONFIG_PATH"
OUTPUT_DIR_ENV = "STEWREADS_OUTPUT_DIR"
FROM_EMAIL_ENV = "STEWREADS_FROM_EMAIL"
DEFAULT_TO_EMAIL_ENV = "STEWREADS_DEFAULT_TO_EMAIL"
DEFAULT_CONFIG_PATH = Path("~/.config/stewreads/config.toml")


class ConfigError(ValueError):
    """Raised when local StewReads configuration is missing or invalid."""


@dataclass(frozen=True)
class AppConfig:
    output_dir: Path
    config_path: Path
    from_email: str | None = None
    default_to_email: str | None = None


def resolve_config_path() -> Path:
    configured_path = os.getenv(CONFIG_PATH_ENV)
    if configured_path:
        return Path(configured_path).expanduser()
    return DEFAULT_CONFIG_PATH.expanduser()


def _normalize_output_path(raw_path: str, *, base_dir: Path | None = None) -> Path:
    path = Path(raw_path).expanduser()
    base = base_dir or Path.cwd()
    if not path.is_absolute():
        path = (base / path).resolve()
    else:
        path = path.resolve()
    return path


def _read_config_file(config_path: Path) -> dict:
    if not config_path.exists():
        raise ConfigError(
            f"Config file not found at {config_path}. Create it or set {OUTPUT_DIR_ENV}."
        )

    try:
        with config_path.open("rb") as f:
            data = tomllib.load(f)
    except Exception as exc:
        raise ConfigError(f"Failed to parse config file at {config_path}: {exc}") from exc

    if not isinstance(data, dict):
        raise ConfigError("Config file must contain a TOML table.")

    return data


def _read_optional_string_value(
    value: Any,
    *,
    field_name: str,
) -> str | None:
    if value is None:
        return None
    if not isinstance(value, str):
        raise ConfigError(f"{field_name} must be a string when set.")
    stripped = value.strip()
    return stripped or None


def _read_email_values(data: dict[str, Any] | None) -> tuple[str | None, str | None]:
    from_email: str | None = None
    default_to_email: str | None = None

    if isinstance(data, dict):
        email_section = data.get("email")
        if email_section is not None and not isinstance(email_section, dict):
            raise ConfigError("If present, [email] must be a TOML table.")

        if isinstance(email_section, dict):
            from_email = _read_optional_string_value(
                email_section.get("from_email"),
                field_name="email.from_email",
            )
            default_to_email = _read_optional_string_value(
                email_section.get("default_to_email"),
                field_name="email.default_to_email",
            )

    from_email_override = os.getenv(FROM_EMAIL_ENV)
    if from_email_override and from_email_override.strip():
        from_email = from_email_override.strip()

    default_to_email_override = os.getenv(DEFAULT_TO_EMAIL_ENV)
    if default_to_email_override and default_to_email_override.strip():
        default_to_email = default_to_email_override.strip()

    return from_email, default_to_email


def _serialize_toml_value(value: Any) -> str:
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, int):
        return str(value)
    if isinstance(value, float):
        return repr(value)
    if isinstance(value, str):
        escaped = value.replace("\\", "\\\\").replace('"', '\\"')
        return f'"{escaped}"'
    if isinstance(value, list):
        return "[" + ", ".join(_serialize_toml_value(item) for item in value) + "]"
    raise ConfigError(f"Unsupported config value type for TOML serialization: {type(value).__name__}")


def _render_toml_tables(table: dict[str, Any], prefix: list[str], lines: list[str]) -> None:
    if prefix:
        lines.append(f"[{'.'.join(prefix)}]")

    for key, value in table.items():
        if isinstance(value, dict):
            continue
        lines.append(f"{key} = {_serialize_toml_value(value)}")

    if prefix:
        lines.append("")

    for key, value in table.items():
        if isinstance(value, dict):
            _render_toml_tables(value, [*prefix, key], lines)


def _dump_toml(data: dict[str, Any]) -> str:
    lines: list[str] = []

    for key, value in data.items():
        if isinstance(value, dict):
            continue
        lines.append(f"{key} = {_serialize_toml_value(value)}")

    if lines:
        lines.append("")

    for key, value in data.items():
        if isinstance(value, dict):
            _render_toml_tables(value, [key], lines)

    while lines and lines[-1] == "":
        lines.pop()

    return "\n".join(lines)


def load_config() -> AppConfig:
    config_path = resolve_config_path()

    data: dict[str, Any] | None = None
    if config_path.exists():
        data = _read_config_file(config_path)

    from_email, default_to_email = _read_email_values(data)
    output_dir_from_env = os.getenv(OUTPUT_DIR_ENV)
    if output_dir_from_env and output_dir_from_env.strip():
        output_dir = _normalize_output_path(output_dir_from_env.strip())
        return AppConfig(
            output_dir=output_dir,
            config_path=config_path,
            from_email=from_email,
            default_to_email=default_to_email,
        )

    if data is None:
        raise ConfigError(
            f"Config file not found at {config_path}. Create it or set {OUTPUT_DIR_ENV}."
        )

    paths_section = data.get("paths")
    if not isinstance(paths_section, dict):
        raise ConfigError(
            "Missing [paths] table in config. Example: [paths] output_dir = '/Users/you/Documents/StewReads'"
        )

    raw_output_dir = paths_section.get("output_dir")
    if not isinstance(raw_output_dir, str) or not raw_output_dir.strip():
        raise ConfigError(
            "Missing paths.output_dir in config. Example: [paths] output_dir = '/Users/you/Documents/StewReads'"
        )

    output_dir = _normalize_output_path(raw_output_dir.strip(), base_dir=config_path.parent)
    return AppConfig(
        output_dir=output_dir,
        config_path=config_path,
        from_email=from_email,
        default_to_email=default_to_email,
    )


def get_config_status() -> dict[str, Any]:
    """Return the current StewReads config status for MCP callers."""
    config_path = resolve_config_path()
    output_dir_from_env = os.getenv(OUTPUT_DIR_ENV)
    env_active = bool(output_dir_from_env and output_dir_from_env.strip())
    data: dict[str, Any] | None = None
    if config_path.exists():
        try:
            data = _read_config_file(config_path)
        except ConfigError as exc:
            if not env_active:
                return {
                    "configured": False,
                    "source": "file",
                    "config_path": str(config_path),
                    "config_file_exists": True,
                    "output_dir": None,
                    "from_email": None,
                    "default_to_email": None,
                    "message": str(exc),
                }
    from_email, default_to_email = _read_email_values(data)

    if env_active:
        output_dir = _normalize_output_path(output_dir_from_env.strip())
        return {
            "configured": True,
            "source": "env",
            "config_path": str(config_path),
            "config_file_exists": config_path.exists(),
            "output_dir": str(output_dir),
            "from_email": from_email,
            "default_to_email": default_to_email,
            "message": f"{OUTPUT_DIR_ENV} is set and overrides file config.",
        }

    try:
        config = load_config()
        return {
            "configured": True,
            "source": "file",
            "config_path": str(config.config_path),
            "config_file_exists": config_path.exists(),
            "output_dir": str(config.output_dir),
            "from_email": config.from_email,
            "default_to_email": config.default_to_email,
            "message": "Config loaded successfully.",
        }
    except ConfigError as exc:
        return {
            "configured": False,
            "source": "none" if not config_path.exists() else "file",
            "config_path": str(config_path),
            "config_file_exists": config_path.exists(),
            "output_dir": None,
            "from_email": None,
            "default_to_email": None,
            "message": str(exc),
        }


def update_config_output_dir(output_dir: str) -> AppConfig:
    """Create/update config file with a non-secret output directory setting."""
    if not isinstance(output_dir, str) or not output_dir.strip():
        raise ConfigError("output_dir must be a non-empty string.")

    config_path = resolve_config_path()
    normalized_output_dir = _normalize_output_path(output_dir.strip(), base_dir=config_path.parent)
    ensure_output_directory(normalized_output_dir)

    config_data: dict[str, Any]
    if config_path.exists():
        config_data = _read_config_file(config_path)
    else:
        config_data = {}

    if not isinstance(config_data, dict):
        config_data = {}

    paths_table = config_data.get("paths")
    if not isinstance(paths_table, dict):
        paths_table = {}
        config_data["paths"] = paths_table

    paths_table["output_dir"] = str(normalized_output_dir)

    config_path.parent.mkdir(parents=True, exist_ok=True)
    config_path.write_text(_dump_toml(config_data) + "\n", encoding="utf-8")

    return AppConfig(output_dir=normalized_output_dir, config_path=config_path)


def ensure_output_directory(path: Path) -> Path:
    try:
        path.mkdir(parents=True, exist_ok=True)
    except Exception as exc:
        raise ConfigError(f"Could not create output directory {path}: {exc}") from exc

    if not path.is_dir():
        raise ConfigError(f"Configured output path is not a directory: {path}")

    return path
