from __future__ import annotations

import asyncio
import re
import shutil
import subprocess
import tempfile
from pathlib import Path

import httpx

ELEVENLABS_API_KEY_ENV = "ELEVENLABS_API_KEY"
ELEVENLABS_VOICE_ID_ENV = "ELEVENLABS_VOICE_ID"
ELEVENLABS_DEFAULT_VOICE_ID = "21m00Tcm4TlvDq8ikWAM"  # Rachel
ELEVENLABS_TTS_URL = "https://api.elevenlabs.io/v1/text-to-speech/{voice_id}"
ELEVENLABS_MODEL_ID = "eleven_multilingual_v2"
ELEVENLABS_OUTPUT_FORMAT = "mp3_44100_128"
CHUNK_CHAR_LIMIT = 9_000


class AudioServiceError(Exception):
    """Raised for recoverable audio generation failures."""


def strip_markdown(text: str) -> str:
    """Strip markdown syntax, returning plain prose suitable for TTS."""
    # Fenced code blocks
    text = re.sub(r"```[\s\S]*?```", "", text)
    text = re.sub(r"~~~[\s\S]*?~~~", "", text)
    # Inline code
    text = re.sub(r"`[^`]*`", "", text)
    # ATX headers — keep the heading text
    text = re.sub(r"^#{1,6}\s+", "", text, flags=re.MULTILINE)
    # Bold / italic
    text = re.sub(r"\*{1,3}([^*]+)\*{1,3}", r"\1", text)
    text = re.sub(r"_{1,3}([^_]+)_{1,3}", r"\1", text)
    # Links — keep link text, drop URL
    text = re.sub(r"!?\[([^\]]*)\]\([^)]*\)", r"\1", text)
    # Reference-style links
    text = re.sub(r"\[([^\]]*)\]\[[^\]]*\]", r"\1", text)
    # Blockquotes
    text = re.sub(r"^>\s*", "", text, flags=re.MULTILINE)
    # Horizontal rules
    text = re.sub(r"^[-*_]{3,}\s*$", "", text, flags=re.MULTILINE)
    # List markers (unordered and ordered)
    text = re.sub(r"^\s*[-*+]\s+", "", text, flags=re.MULTILINE)
    text = re.sub(r"^\s*\d+\.\s+", "", text, flags=re.MULTILINE)
    # HTML tags
    text = re.sub(r"<[^>]+>", "", text)
    # Collapse excessive whitespace
    text = re.sub(r"\n{3,}", "\n\n", text)
    text = re.sub(r"[ \t]+", " ", text)
    return text.strip()


def chunk_text(text: str, limit: int = CHUNK_CHAR_LIMIT) -> list[str]:
    """Split text into chunks at paragraph boundaries, then sentence boundaries if needed."""
    paragraphs = re.split(r"\n\n+", text)
    chunks: list[str] = []
    current = ""

    for para in paragraphs:
        para = para.strip()
        if not para:
            continue

        if len(para) > limit:
            # Split long paragraph at sentence boundaries
            sentences = re.split(r"(?<=[.!?])\s+", para)
            for sentence in sentences:
                sentence = sentence.strip()
                if not sentence:
                    continue
                if len(current) + len(sentence) + 1 <= limit:
                    current = (current + " " + sentence).strip() if current else sentence
                else:
                    if current:
                        chunks.append(current)
                    # Hard-split oversized single sentences as last resort
                    while len(sentence) > limit:
                        chunks.append(sentence[:limit])
                        sentence = sentence[limit:]
                    current = sentence
        else:
            if len(current) + len(para) + 2 <= limit:
                current = (current + "\n\n" + para).strip() if current else para
            else:
                if current:
                    chunks.append(current)
                current = para

    if current:
        chunks.append(current)

    return chunks


async def fetch_audio_chunk(
    client: httpx.AsyncClient,
    text: str,
    api_key: str,
    voice_id: str,
    previous_text: str | None = None,
    next_text: str | None = None,
) -> bytes:
    """POST one chunk to ElevenLabs TTS and return raw MP3 bytes."""
    url = ELEVENLABS_TTS_URL.format(voice_id=voice_id)
    payload = {
        "text": text,
        "model_id": ELEVENLABS_MODEL_ID,
        "output_format": ELEVENLABS_OUTPUT_FORMAT,
    }
    if previous_text:
        payload["previous_text"] = previous_text
    if next_text:
        payload["next_text"] = next_text
    headers = {
        "xi-api-key": api_key,
        "Content-Type": "application/json",
        "Accept": "audio/mpeg",
    }

    response = await client.post(url, json=payload, headers=headers)

    if response.status_code == 401:
        raise AudioServiceError("ElevenLabs API key is invalid or unauthorized (HTTP 401).")
    if response.status_code == 422:
        raise AudioServiceError(f"ElevenLabs rejected the request (HTTP 422): {response.text}")
    if not (200 <= response.status_code < 300):
        raise AudioServiceError(
            f"ElevenLabs TTS request failed (HTTP {response.status_code}): {response.text}"
        )

    return response.content


def _stitch_mp3_chunks(chunk_paths: list[Path], output_path: Path) -> None:
    """Concatenate MP3 chunk files into a single output file (blocking)."""
    if not chunk_paths:
        raise AudioServiceError("No audio chunks to stitch.")

    if len(chunk_paths) == 1:
        shutil.move(str(chunk_paths[0]), str(output_path))
        return

    # Write ffmpeg concat list file
    concat_list = output_path.parent / "concat_list.txt"
    concat_list.write_text(
        "\n".join(f"file '{p}'" for p in chunk_paths),
        encoding="utf-8",
    )

    try:
        result = subprocess.run(
            [
                "ffmpeg",
                "-y",
                "-f", "concat",
                "-safe", "0",
                "-i", str(concat_list),
                "-c", "copy",
                str(output_path),
            ],
            capture_output=True,
            text=True,
        )
    finally:
        concat_list.unlink(missing_ok=True)

    if result.returncode != 0:
        raise AudioServiceError(
            f"ffmpeg failed to concatenate audio chunks (exit {result.returncode}):\n{result.stderr}"
        )


async def generate_audiobook(
    markdown: str,
    output_path: Path,
    api_key: str,
    voice_id: str,
) -> Path:
    """Convert markdown to an MP3 audiobook via ElevenLabs TTS.

    Steps:
    1. Strip markdown syntax → chunk at paragraph/sentence boundaries
    2. Fetch each chunk sequentially (avoids rate limits)
    3. Write chunks to a temp directory
    4. Stitch with ffmpeg (run_in_executor to keep the event loop free)
    5. Return resolved output_path
    """
    plain_text = strip_markdown(markdown)
    if not plain_text:
        raise AudioServiceError("No readable text found after stripping markdown.")

    chunks = chunk_text(plain_text)
    if not chunks:
        raise AudioServiceError("Text produced no usable chunks.")

    output_path = output_path.resolve()
    output_path.parent.mkdir(parents=True, exist_ok=True)

    with tempfile.TemporaryDirectory(prefix="stewreads-audio-") as tmp_dir:
        tmp = Path(tmp_dir)
        chunk_paths: list[Path] = []

        async with httpx.AsyncClient(timeout=120.0) as client:
            for i, chunk in enumerate(chunks):
                audio_bytes = await fetch_audio_chunk(
                    client,
                    chunk,
                    api_key,
                    voice_id,
                    previous_text=chunks[i - 1] if i > 0 else None,
                    next_text=chunks[i + 1] if i < len(chunks) - 1 else None,
                )
                chunk_file = tmp / f"chunk_{i:04d}.mp3"
                chunk_file.write_bytes(audio_bytes)
                chunk_paths.append(chunk_file)

        loop = asyncio.get_running_loop()
        await loop.run_in_executor(None, _stitch_mp3_chunks, chunk_paths, output_path)

    return output_path
