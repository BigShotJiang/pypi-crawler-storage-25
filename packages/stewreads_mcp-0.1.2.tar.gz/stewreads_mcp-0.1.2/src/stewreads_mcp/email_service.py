from __future__ import annotations

import smtplib
import ssl
from email.message import EmailMessage
from pathlib import Path
from typing import Optional

GMAIL_APP_PASSWORD_ENV = "STEWREADS_GMAIL_APP_PASSWORD"
GMAIL_SMTP_HOST = "smtp.gmail.com"
GMAIL_SMTP_PORT = 587


def resolve_epub_path(output_dir: Path, ebook_path: Optional[str]) -> Path:
    if ebook_path and ebook_path.strip():
        resolved = Path(ebook_path.strip()).expanduser()
        if not resolved.is_absolute():
            resolved = (output_dir / resolved).resolve()
        else:
            resolved = resolved.resolve()

        if not resolved.exists() or not resolved.is_file():
            raise ValueError(f"EPUB file not found: {resolved}")
        return resolved

    candidates = [path for path in output_dir.glob("*.epub") if path.is_file()]
    if not candidates:
        raise ValueError(f"No EPUB files found in {output_dir}")

    return max(candidates, key=lambda item: item.stat().st_mtime).resolve()


def send_epub_email(
    from_email: str,
    app_password: str,
    to_email: str,
    epub_path: Path,
    subject: Optional[str] = None,
    body: Optional[str] = None,
) -> str:
    sender = from_email.strip()
    recipient = to_email.strip()
    password = app_password.strip()

    if not sender:
        raise ValueError("from_email is required.")
    if not recipient:
        raise ValueError("to_email is required.")
    if not password:
        raise ValueError("Gmail App Password is required.")

    if not epub_path.exists() or not epub_path.is_file():
        raise ValueError(f"EPUB file not found: {epub_path}")

    final_subject = (
        subject.strip() if subject and subject.strip() else f"Your StewReads ebook: {epub_path.stem}"
    )
    final_body = (
        body.strip()
        if body and body.strip()
        else "Attached is your ebook from StewReads."
    )

    message = EmailMessage()
    message["From"] = sender
    message["To"] = recipient
    message["Subject"] = final_subject
    message.set_content(final_body)
    message.add_attachment(
        epub_path.read_bytes(),
        maintype="application",
        subtype="epub+zip",
        filename=epub_path.name,
    )

    context = ssl.create_default_context()

    try:
        with smtplib.SMTP(GMAIL_SMTP_HOST, GMAIL_SMTP_PORT, timeout=30) as smtp:
            smtp.ehlo()
            smtp.starttls(context=context)
            smtp.ehlo()
            smtp.login(sender, password)
            smtp.send_message(message)
    except (smtplib.SMTPException, OSError) as exc:
        raise ValueError(f"Failed to send email via Gmail SMTP: {exc}") from exc

    return final_subject
