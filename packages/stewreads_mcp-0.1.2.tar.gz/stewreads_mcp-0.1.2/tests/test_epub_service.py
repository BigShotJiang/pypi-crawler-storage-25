import asyncio
from pathlib import Path

import pytest

from stewreads_mcp import epub_service
from stewreads_mcp.epub_service import convert_markdown_to_epub, sanitize_filename


def test_sanitize_filename_handles_symbols():
    assert sanitize_filename("..Hi/There: A Test?") == "Hi-There A Test"


def test_convert_markdown_to_epub_writes_output(monkeypatch, tmp_path):
    def fake_convert_file(*args, **kwargs):
        outputfile = kwargs["outputfile"]
        Path(outputfile).write_bytes(b"fake-epub")

    monkeypatch.setattr(epub_service.pypandoc, "convert_file", fake_convert_file)

    output_path = asyncio.run(
        convert_markdown_to_epub(
            markdown="# Title\n\nBody",
            title="My Test Book",
            output_dir=tmp_path,
        )
    )

    assert output_path.exists()
    assert output_path.read_bytes() == b"fake-epub"


def test_convert_markdown_to_epub_reports_missing_pandoc(monkeypatch, tmp_path):
    def fake_convert_file(*args, **kwargs):
        raise OSError("No pandoc was found")

    monkeypatch.setattr(epub_service.pypandoc, "convert_file", fake_convert_file)

    with pytest.raises(ValueError, match="Pandoc"):
        asyncio.run(
            convert_markdown_to_epub(
                markdown="# Title\n\nBody",
                title="My Test Book",
                output_dir=tmp_path,
            )
        )
