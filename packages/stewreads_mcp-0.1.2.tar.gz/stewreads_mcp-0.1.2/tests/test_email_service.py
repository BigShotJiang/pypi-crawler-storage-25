import os

import pytest

from stewreads_mcp.email_service import resolve_epub_path


def test_resolve_epub_path_uses_explicit_relative_path(tmp_path):
    output_dir = tmp_path / "books"
    output_dir.mkdir(parents=True, exist_ok=True)
    target = output_dir / "my-book.epub"
    target.write_bytes(b"epub")

    resolved = resolve_epub_path(output_dir=output_dir, ebook_path="my-book.epub")

    assert resolved == target.resolve()


def test_resolve_epub_path_uses_latest_file_when_path_missing(tmp_path):
    output_dir = tmp_path / "books"
    output_dir.mkdir(parents=True, exist_ok=True)

    older = output_dir / "older.epub"
    newer = output_dir / "newer.epub"
    older.write_bytes(b"old")
    newer.write_bytes(b"new")

    older_ts = newer.stat().st_mtime - 10
    os.utime(older, (older_ts, older_ts))

    resolved = resolve_epub_path(output_dir=output_dir, ebook_path=None)

    assert resolved == newer.resolve()


def test_resolve_epub_path_raises_when_no_epubs(tmp_path):
    output_dir = tmp_path / "books"
    output_dir.mkdir(parents=True, exist_ok=True)

    with pytest.raises(ValueError, match="No EPUB files"):
        resolve_epub_path(output_dir=output_dir, ebook_path=None)
