import pytest

from stewreads_mcp.config import ConfigError, get_config_status, load_config, update_config_output_dir


def test_load_config_uses_env_output_dir(monkeypatch, tmp_path):
    monkeypatch.setenv("STEWREADS_OUTPUT_DIR", str(tmp_path / "books"))
    monkeypatch.delenv("STEWREADS_CONFIG_PATH", raising=False)

    cfg = load_config()

    assert cfg.output_dir == (tmp_path / "books").resolve()


def test_load_config_reads_file(monkeypatch, tmp_path):
    config_file = tmp_path / "config.toml"
    config_file.write_text("[paths]\noutput_dir = 'ebooks'\n", encoding="utf-8")

    monkeypatch.delenv("STEWREADS_OUTPUT_DIR", raising=False)
    monkeypatch.setenv("STEWREADS_CONFIG_PATH", str(config_file))

    cfg = load_config()

    assert cfg.output_dir == (config_file.parent / "ebooks").resolve()


def test_load_config_raises_when_missing(monkeypatch, tmp_path):
    missing_file = tmp_path / "missing.toml"
    monkeypatch.delenv("STEWREADS_OUTPUT_DIR", raising=False)
    monkeypatch.setenv("STEWREADS_CONFIG_PATH", str(missing_file))

    with pytest.raises(ConfigError):
        load_config()


def test_get_config_status_missing(monkeypatch, tmp_path):
    missing_file = tmp_path / "missing.toml"
    monkeypatch.delenv("STEWREADS_OUTPUT_DIR", raising=False)
    monkeypatch.setenv("STEWREADS_CONFIG_PATH", str(missing_file))

    status = get_config_status()

    assert status["configured"] is False
    assert status["config_file_exists"] is False


def test_update_config_output_dir_writes_file(monkeypatch, tmp_path):
    config_file = tmp_path / "config.toml"
    output_dir = tmp_path / "ebooks"
    monkeypatch.delenv("STEWREADS_OUTPUT_DIR", raising=False)
    monkeypatch.setenv("STEWREADS_CONFIG_PATH", str(config_file))

    cfg = update_config_output_dir(str(output_dir))

    assert cfg.output_dir == output_dir.resolve()
    assert config_file.exists()
    content = config_file.read_text(encoding="utf-8")
    assert "[paths]" in content
    assert str(output_dir.resolve()) in content


def test_update_config_output_dir_relative_path_uses_config_parent(monkeypatch, tmp_path):
    config_dir = tmp_path / "settings"
    config_file = config_dir / "config.toml"
    monkeypatch.delenv("STEWREADS_OUTPUT_DIR", raising=False)
    monkeypatch.setenv("STEWREADS_CONFIG_PATH", str(config_file))

    cfg = update_config_output_dir("ebooks")

    assert cfg.output_dir == (config_dir / "ebooks").resolve()
    content = config_file.read_text(encoding="utf-8")
    assert str((config_dir / "ebooks").resolve()) in content


def test_update_config_preserves_existing_non_paths_fields(monkeypatch, tmp_path):
    config_file = tmp_path / "config.toml"
    config_file.write_text(
        "theme = \"warm\"\n\n[paths]\noutput_dir = \"/tmp/old\"\n",
        encoding="utf-8",
    )
    monkeypatch.delenv("STEWREADS_OUTPUT_DIR", raising=False)
    monkeypatch.setenv("STEWREADS_CONFIG_PATH", str(config_file))

    update_config_output_dir(str(tmp_path / "new-books"))

    content = config_file.read_text(encoding="utf-8")
    assert "theme = \"warm\"" in content


def test_load_config_reads_email_fields(monkeypatch, tmp_path):
    config_file = tmp_path / "config.toml"
    config_file.write_text(
        "[paths]\noutput_dir = 'ebooks'\n\n[email]\nfrom_email = 'sender@example.com'\ndefault_to_email = 'reader@example.com'\n",
        encoding="utf-8",
    )

    monkeypatch.delenv("STEWREADS_OUTPUT_DIR", raising=False)
    monkeypatch.delenv("STEWREADS_FROM_EMAIL", raising=False)
    monkeypatch.delenv("STEWREADS_DEFAULT_TO_EMAIL", raising=False)
    monkeypatch.setenv("STEWREADS_CONFIG_PATH", str(config_file))

    cfg = load_config()

    assert cfg.from_email == "sender@example.com"
    assert cfg.default_to_email == "reader@example.com"


def test_load_config_env_overrides_email_fields(monkeypatch, tmp_path):
    config_file = tmp_path / "config.toml"
    config_file.write_text(
        "[paths]\noutput_dir = 'ebooks'\n\n[email]\nfrom_email = 'sender@example.com'\ndefault_to_email = 'reader@example.com'\n",
        encoding="utf-8",
    )

    monkeypatch.delenv("STEWREADS_OUTPUT_DIR", raising=False)
    monkeypatch.setenv("STEWREADS_CONFIG_PATH", str(config_file))
    monkeypatch.setenv("STEWREADS_FROM_EMAIL", "override@example.com")
    monkeypatch.setenv("STEWREADS_DEFAULT_TO_EMAIL", "alt@example.com")

    cfg = load_config()

    assert cfg.from_email == "override@example.com"
    assert cfg.default_to_email == "alt@example.com"
