import asyncio

from stewreads_mcp.config import AppConfig, ConfigError
from stewreads_mcp.email_service import GMAIL_APP_PASSWORD_ENV
from stewreads_mcp import server


def test_save_ebook_returns_structured_success(monkeypatch, tmp_path):
    config_path = tmp_path / "config.toml"
    output_dir = tmp_path / "books"
    output_dir.mkdir(parents=True, exist_ok=True)

    async def fake_convert_markdown_to_epub(**kwargs):
        saved = output_dir / "demo.epub"
        saved.write_bytes(b"epub")
        return saved

    monkeypatch.setattr(
        server,
        "load_config",
        lambda: AppConfig(output_dir=output_dir, config_path=config_path),
    )
    monkeypatch.setattr(server, "ensure_output_directory", lambda path: path)
    monkeypatch.setattr(server, "convert_markdown_to_epub", fake_convert_markdown_to_epub)

    result = asyncio.run(server.save_ebook(markdown="# Hello", title="Demo"))

    assert result["ok"] is True
    assert result["format"] == "epub"
    assert result["title"] == "Demo"
    assert result["size_bytes"] == 4
    assert result["path"].endswith("demo.epub")
    assert "Saved ebook 'Demo' as EPUB." in result["message"]


def test_save_ebook_returns_structured_config_error(monkeypatch):
    def fake_load_config():
        raise ConfigError("config missing")

    monkeypatch.setattr(server, "load_config", fake_load_config)

    result = asyncio.run(server.save_ebook(markdown="# Hello", title="Demo"))

    assert result["ok"] is False
    assert result["error_code"] == "config_error"
    assert "config missing" in result["message"]
    assert "save_stew_config" in result["next_step"]


def test_save_ebook_returns_structured_conversion_error(monkeypatch, tmp_path):
    config_path = tmp_path / "config.toml"
    output_dir = tmp_path / "books"
    output_dir.mkdir(parents=True, exist_ok=True)

    async def fake_convert_markdown_to_epub(**kwargs):
        raise ValueError("pandoc failed")

    monkeypatch.setattr(
        server,
        "load_config",
        lambda: AppConfig(output_dir=output_dir, config_path=config_path),
    )
    monkeypatch.setattr(server, "ensure_output_directory", lambda path: path)
    monkeypatch.setattr(server, "convert_markdown_to_epub", fake_convert_markdown_to_epub)

    result = asyncio.run(server.save_ebook(markdown="# Hello", title="Demo"))

    assert result["ok"] is False
    assert result["error_code"] == "conversion_error"
    assert "pandoc failed" in result["message"]


def test_get_email_status_ready(monkeypatch, tmp_path):
    config_path = tmp_path / "config.toml"
    output_dir = tmp_path / "books"
    monkeypatch.setattr(
        server,
        "load_config",
        lambda: AppConfig(
            output_dir=output_dir,
            config_path=config_path,
            from_email="sender@example.com",
            default_to_email="reader@example.com",
        ),
    )
    monkeypatch.setenv(GMAIL_APP_PASSWORD_ENV, "app-pass")

    result = server.get_email_status()

    assert result["ok"] is True
    assert result["ready"] is True
    assert result["from_email"] == "sender@example.com"
    assert result["default_to_email"] == "reader@example.com"
    assert result["gmail_app_password_set"] is True


def test_email_ebook_success(monkeypatch, tmp_path):
    config_path = tmp_path / "config.toml"
    output_dir = tmp_path / "books"
    output_dir.mkdir(parents=True, exist_ok=True)
    attachment = output_dir / "latest.epub"
    attachment.write_bytes(b"epub-bytes")

    monkeypatch.setattr(
        server,
        "load_config",
        lambda: AppConfig(
            output_dir=output_dir,
            config_path=config_path,
            from_email="sender@example.com",
            default_to_email="reader@example.com",
        ),
    )
    monkeypatch.setattr(server, "ensure_output_directory", lambda path: path)
    monkeypatch.setattr(server, "resolve_epub_path", lambda **kwargs: attachment)

    def fake_send_epub_email(from_email, app_password, to_email, epub_path, subject, body):
        assert from_email == "sender@example.com"
        assert to_email == "reader@example.com"
        assert epub_path == attachment
        return "Test Subject"

    monkeypatch.setattr(server, "send_epub_email", fake_send_epub_email)
    monkeypatch.setenv(GMAIL_APP_PASSWORD_ENV, "app-pass")

    result = asyncio.run(server.email_ebook())

    assert result["ok"] is True
    assert result["to_email"] == "reader@example.com"
    assert result["from_email"] == "sender@example.com"
    assert result["path"].endswith("latest.epub")
    assert result["size_bytes"] == len(b"epub-bytes")
    assert result["subject"] == "Test Subject"


def test_email_ebook_missing_app_password(monkeypatch, tmp_path):
    config_path = tmp_path / "config.toml"
    output_dir = tmp_path / "books"
    output_dir.mkdir(parents=True, exist_ok=True)

    monkeypatch.setattr(
        server,
        "load_config",
        lambda: AppConfig(
            output_dir=output_dir,
            config_path=config_path,
            from_email="sender@example.com",
            default_to_email="reader@example.com",
        ),
    )
    monkeypatch.delenv(GMAIL_APP_PASSWORD_ENV, raising=False)

    result = asyncio.run(server.email_ebook())

    assert result["ok"] is False
    assert result["error_code"] == "email_secret_missing"
