"""
Context tools — organization and entity selection.

These must be called before any other tools to establish
which organization and entity the user is working with.
"""

from fastmcp import Context

from ..server import mcp
from ..client import get_client


@mcp.tool(annotations={"readOnlyHint": True})
async def list_organizations(ctx: Context) -> str:
    """List all organizations the current user has access to. Use this to find organization IDs for set_context()."""
    client = await get_client(ctx)
    result = await client.get("/accounts/auth/me")
    user = result["data"]["user"]
    orgs = result["data"]["organizations"]

    lines = [f"Logged in as: {user['email']}\n"]
    lines.append(f"Organizations ({len(orgs)}):")
    for org in orgs:
        lines.append(f"  - {org['name']} (id={org['id']}, role={org['user_role']})")

    current_org = client.organization_id
    if current_org:
        lines.append(f"\nActive organization: {current_org}")
    else:
        lines.append("\nNo active organization. Use set_context() to select one.")

    return "\n".join(lines)


@mcp.tool(annotations={"readOnlyHint": False, "destructiveHint": False, "openWorldHint": False})
async def set_context(organization_id: int, entity_id: int, ctx: Context) -> str:
    """Set the active organization and entity for all subsequent operations.
    Use list_organizations() to find org IDs, then list_entities() to find entity IDs.
    All create/list operations will use this context automatically."""
    client = await get_client(ctx)
    try:
        # Validate user is a member of the requested organization
        me_result = await client.get("/accounts/auth/me")
        user_orgs = me_result["data"]["organizations"]
        user_org_ids = [org["id"] for org in user_orgs]

        if organization_id not in user_org_ids:
            return "Error: You are not a member of this organization. Use list_organizations() to see your organizations."

        # Validate entity access by trying to fetch it with the correct org context
        client.organization_id = organization_id
        client.entity_id = entity_id

        result = await client.get(f"/assetmanager/entities/{entity_id}")
        entity = result["data"]

        # Persist in session state for future tool calls (multi-user safe)
        await ctx.set_state("organization_id", organization_id)
        await ctx.set_state("entity_id", entity_id)

        return (
            f"Context set successfully.\n"
            f"Organization: {organization_id}\n"
            f"Entity: {entity['name']} (id={entity_id}, type={entity['entity_type']}, currency={entity['currency']})"
        )
    except Exception:
        # Clear session state on failure
        await ctx.set_state("organization_id", None)
        await ctx.set_state("entity_id", None)
        return "Error: Cannot access this entity. Check organization_id and entity_id are correct and you have access."


@mcp.tool(annotations={"readOnlyHint": True})
async def list_entities(ctx: Context) -> str:
    """List all entities in the current organization. Use this to find entity IDs for set_context()."""
    client = await get_client(ctx)
    result = await client.get("/assetmanager/entities/")
    entities = result.get("data", [])

    if not entities:
        return "No entities found in this organization. Create one with create_entity()."

    lines = [f"Entities ({len(entities)}):"]
    for e in entities:
        lines.append(
            f"  - {e['name']} (id={e['id']}, type={e['entity_type']}, currency={e['currency']})"
        )

    if client.entity_id:
        lines.append(f"\nActive entity: {client.entity_id}")

    return "\n".join(lines)


@mcp.tool(annotations={"readOnlyHint": True})
async def get_entity_details(entity_id: int, ctx: Context) -> str:
    """Get detailed information about a specific entity."""
    client = await get_client(ctx)
    result = await client.get(f"/assetmanager/entities/{entity_id}")
    e = result["data"]

    lines = [
        f"Entity: {e['name']}",
        f"  Type: {e['entity_type']}",
        f"  Currency: {e['currency']}",
        f"  Discoverable: {e.get('is_discoverable', False)}",
    ]
    if e.get("parent_id"):
        lines.append(f"  Parent ID: {e['parent_id']}")

    return "\n".join(lines)
