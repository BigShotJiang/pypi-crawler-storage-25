"""
Cap Table tools — stakeholders, funding rounds, securities, transactions.

Debit/credit convention (entity perspective):
- amount_debit  = cash COMING IN to the entity (from investor)
- amount_credit = cash GOING OUT from the entity (to investor)
- units_debit   = units returned TO the entity (e.g., buyback)
- units_credit  = units ISSUED BY the entity (e.g., new shares to investor)
"""

from typing import Literal

from fastmcp import Context

from ..server import mcp
from ..client import get_client


# ==========================================
# Stakeholders
# ==========================================

@mcp.tool(annotations={"readOnlyHint": True})
async def list_stakeholders(ctx: Context) -> str:
    """List all stakeholders on the current entity's cap table."""
    client = await get_client(ctx)
    if not client.entity_id:
        return "Error: No entity set. Use set_context() first."

    result = await client.get("/assetmanager/stakeholders/", params={"entity_id": client.entity_id})
    items = result.get("data", [])

    if not items:
        return "No stakeholders found on this entity's cap table."

    lines = [f"Stakeholders ({len(items)}):"]
    for s in items:
        name = s.get("source_entity_name") or s.get("name") or f"Stakeholder #{s['id']}"
        pref = f", pref_return={s['preferred_return_rate']}%" if s.get("preferred_return_rate") else ""
        carry = f", carry={s['carried_interest_percentage']}%" if s.get("carried_interest_percentage") else ""
        lines.append(f"  - {name} (id={s['id']}, type={s['type']}{pref}{carry})")

    return "\n".join(lines)


@mcp.tool(annotations={"readOnlyHint": False, "destructiveHint": False, "openWorldHint": False})
async def create_stakeholder(
    source_entity_id: int,
    type: Literal["general_partner", "limited_partner", "employee", "advisor", "board_member", "investor"],
    preferred_return_rate: float | None = None,
    carried_interest_percentage: float | None = None,
    catch_up_rate: float | None = None,
    distribution_tier: int = 1,
    voting_rights: bool = True,
    pro_rata_rights: bool = False,
    board_seats: int = 0,
    ctx: Context = None,
) -> str:
    """Add a stakeholder to the current entity's cap table.
    source_entity_id is the INVESTING entity (whose name appears on the cap table).
    The cap table entity comes from your current context.
    Use list_entities() to find valid entity IDs for source_entity_id."""
    client = await get_client(ctx)
    if not client.entity_id:
        return "Error: No entity set. Use set_context() first."

    payload: dict = {
        "entity_id": client.entity_id,
        "source_entity_id": source_entity_id,
        "type": type,
        "distribution_tier": distribution_tier,
        "voting_rights": voting_rights,
        "pro_rata_rights": pro_rata_rights,
        "board_seats": board_seats,
    }
    if preferred_return_rate is not None:
        payload["preferred_return_rate"] = preferred_return_rate
    if carried_interest_percentage is not None:
        payload["carried_interest_percentage"] = carried_interest_percentage
    if catch_up_rate is not None:
        payload["catch_up_rate"] = catch_up_rate

    result = await client.post("/assetmanager/stakeholders/", payload)
    s = result["data"]

    return f"Stakeholder created (id={s['id']}, type={s['type']}) on entity {client.entity_id}."



@mcp.tool(annotations={"readOnlyHint": False, "destructiveHint": False, "openWorldHint": False})
async def update_stakeholder(
    stakeholder_id: int,
    type: Literal["general_partner", "limited_partner", "employee", "advisor", "board_member", "investor"] | None = None,
    preferred_return_rate: float | None = None,
    carried_interest_percentage: float | None = None,
    catch_up_rate: float | None = None,
    distribution_tier: int | None = None,
    voting_rights: bool | None = None,
    pro_rata_rights: bool | None = None,
    board_seats: int | None = None,
    ctx: Context = None,
) -> str:
    """Update a stakeholder's governance and distribution fields. Only provided fields are changed.
    Common use: adjust carry %, preferred return, voting rights, board seats."""
    client = await get_client(ctx)
    payload: dict = {}
    if type is not None:
        payload["type"] = type
    if preferred_return_rate is not None:
        payload["preferred_return_rate"] = preferred_return_rate
    if carried_interest_percentage is not None:
        payload["carried_interest_percentage"] = carried_interest_percentage
    if catch_up_rate is not None:
        payload["catch_up_rate"] = catch_up_rate
    if distribution_tier is not None:
        payload["distribution_tier"] = distribution_tier
    if voting_rights is not None:
        payload["voting_rights"] = voting_rights
    if pro_rata_rights is not None:
        payload["pro_rata_rights"] = pro_rata_rights
    if board_seats is not None:
        payload["board_seats"] = board_seats

    if not payload:
        return "Error: No fields to update."

    result = await client.put(f"/assetmanager/stakeholders/{stakeholder_id}", payload)
    s = result["data"]

    return f"Stakeholder updated (id={s['id']}, type={s['type']})."


# ==========================================
# Funding Rounds
# ==========================================

@mcp.tool(annotations={"readOnlyHint": True})
async def list_funding_rounds(ctx: Context) -> str:
    """List all funding rounds for the current entity."""
    client = await get_client(ctx)
    if not client.entity_id:
        return "Error: No entity set. Use set_context() first."

    result = await client.get("/assetmanager/funding-rounds/", params={"entity_id": client.entity_id})
    items = result.get("data", [])

    if not items:
        return "No funding rounds found. Create one with create_funding_round()."

    lines = [f"Funding Rounds ({len(items)}):"]
    for r in items:
        raised = f", raised={r['raised_amount']}" if r.get("raised_amount") else ""
        target = f", target={r['target_amount']}" if r.get("target_amount") else ""
        lines.append(f"  - {r['name']} (id={r['id']}, type={r['round_type']}, date={r['date']}{target}{raised})")

    return "\n".join(lines)


@mcp.tool(annotations={"readOnlyHint": False, "destructiveHint": False, "openWorldHint": False})
async def create_funding_round(
    name: str,
    round_type: Literal["seed", "pre_series_a", "series_a", "series_b", "series_c", "series_d", "debt", "convertible", "safe", "bridge", "secondary", "other"],
    date: str,
    target_amount: float | None = None,
    raised_amount: float | None = None,
    pre_money_valuation: float | None = None,
    post_money_valuation: float | None = None,
    ctx: Context = None,
) -> str:
    """Create a new funding round. Date format: YYYY-MM-DD."""
    client = await get_client(ctx)
    if not client.entity_id:
        return "Error: No entity set. Use set_context() first."

    payload: dict = {
        "entity_id": client.entity_id,
        "name": name,
        "round_type": round_type,
        "date": date,
    }
    if target_amount is not None:
        payload["target_amount"] = target_amount
    if raised_amount is not None:
        payload["raised_amount"] = raised_amount
    if pre_money_valuation is not None:
        payload["pre_money_valuation"] = pre_money_valuation
    if post_money_valuation is not None:
        payload["post_money_valuation"] = post_money_valuation

    result = await client.post("/assetmanager/funding-rounds/", payload)
    r = result["data"]

    return f"Funding round created: {r['name']} (id={r['id']}, type={r['round_type']})."


# ==========================================
# Securities
# ==========================================

@mcp.tool(annotations={"readOnlyHint": True})
async def list_securities(ctx: Context) -> str:
    """List all securities across all funding rounds for the current entity."""
    client = await get_client(ctx)
    if not client.entity_id:
        return "Error: No entity set. Use set_context() first."

    # Securities endpoint filters via FundingRound JOIN — pass entity context via org_id
    result = await client.get("/assetmanager/securities/")
    items = result.get("data", [])

    if not items:
        return "No securities found. Create one with create_security()."

    lines = [f"Securities ({len(items)}):"]
    for s in items:
        price = f", price={s['issue_price']}" if s.get("issue_price") else ""
        active = "active" if s.get("is_active") else "inactive"
        lines.append(
            f"  - {s['security_name']} (id={s['id']}, code={s['code']}, "
            f"type={s['security_type']}, round_id={s['funding_round_id']}, {active}{price})"
        )

    return "\n".join(lines)


@mcp.tool(annotations={"readOnlyHint": False, "destructiveHint": False, "openWorldHint": False})
async def create_security(
    funding_round_id: int,
    security_name: str,
    code: str,
    security_type: Literal["common", "preferred", "convertible", "warrant", "option", "bond", "safe"],
    currency: str = "USD",
    issue_price: float | None = None,
    # Preferred-specific
    dividend_rate: float | None = None,
    liquidation_preference: float | None = None,
    seniority: int | None = None,
    # Option/Warrant-specific
    strike_price: float | None = None,
    vesting_months: int | None = None,
    cliff_months: int | None = None,
    # Convertible/SAFE-specific
    valuation_cap: float | None = None,
    conversion_discount: float | None = None,
    interest_rate: float | None = None,
    maturity_date: str | None = None,
    # Bond-specific
    principal: float | None = None,
    coupon_rate: float | None = None,
    tenure_months: int | None = None,
    ctx: Context = None,
) -> str:
    """Create a new security class under a funding round.
    Ask only for fields relevant to the security_type:
    - Common: issue_price
    - Preferred: dividend_rate, liquidation_preference, seniority
    - Option/Warrant: strike_price, vesting_months, cliff_months
    - Convertible/SAFE: valuation_cap, conversion_discount, interest_rate, maturity_date
    - Bond: principal, coupon_rate, tenure_months"""
    client = await get_client(ctx)
    payload: dict = {
        "funding_round_id": funding_round_id,
        "security_name": security_name,
        "code": code,
        "security_type": security_type,
        "currency": currency,
    }
    # Add optional fields only if provided
    optional = {
        "issue_price": issue_price, "dividend_rate": dividend_rate,
        "liquidation_preference": liquidation_preference, "seniority": seniority,
        "strike_price": strike_price, "vesting_months": vesting_months,
        "cliff_months": cliff_months, "valuation_cap": valuation_cap,
        "conversion_discount": conversion_discount, "interest_rate": interest_rate,
        "maturity_date": maturity_date, "principal": principal,
        "coupon_rate": coupon_rate, "tenure_months": tenure_months,
    }
    for k, v in optional.items():
        if v is not None:
            payload[k] = v

    result = await client.post("/assetmanager/securities/", payload)
    s = result["data"]

    return f"Security created: {s['security_name']} (id={s['id']}, type={s['security_type']}, code={s['code']})."


# ==========================================
# Security Transactions
# ==========================================

@mcp.tool(annotations={"readOnlyHint": True})
async def list_transactions(ctx: Context) -> str:
    """List all security transactions for the current entity."""
    client = await get_client(ctx)
    if not client.entity_id:
        return "Error: No entity set. Use set_context() first."

    result = await client.get("/assetmanager/security-transactions/", params={"entity_id": client.entity_id})
    items = result.get("data", [])

    if not items:
        return "No transactions found on this entity."

    lines = [f"Transactions ({len(items)}):"]
    for t in items:
        ref = t.get("transaction_reference", "—")
        ttype = t.get("transaction_type", "—")
        date = t.get("transaction_date", "—")
        u_debit = t.get("units_debit", 0)
        u_credit = t.get("units_credit", 0)
        a_debit = t.get("amount_debit", 0)
        a_credit = t.get("amount_credit", 0)
        lines.append(
            f"  - {ref} | {ttype} | {date} | "
            f"units: debit={u_debit:,.0f} credit={u_credit:,.0f} | "
            f"amount: debit={a_debit:,.2f} credit={a_credit:,.2f}"
        )

    return "\n".join(lines)

@mcp.tool(annotations={"readOnlyHint": False, "destructiveHint": False, "openWorldHint": False})
async def create_transaction(
    stakeholder_id: int,
    funding_round_id: int,
    transaction_type: Literal[
        "issuance", "distribution", "redemption",
        "transfer_in", "transfer_out",
        "cash_in", "cash_out", "coupon_in", "coupon_out",
        "conversion_in", "conversion_out", "split", "consolidation",
        "grant", "vest", "exercise", "expire", "forfeit", "cancel",
        "dividend", "interest", "adjustment",
    ],
    transaction_date: str,
    transaction_reference: str,
    security_id: int | None = None,
    units_debit: float = 0,
    units_credit: float = 0,
    amount_debit: float = 0,
    amount_credit: float = 0,
    notes: str | None = None,
    ctx: Context = None,
) -> str:
    """Create a security transaction on the cap table.
    DEBIT/CREDIT from ENTITY perspective:
    - ISSUANCE: amount_debit = cash investor pays IN, units_credit = shares issued TO stakeholder
    - DISTRIBUTION: amount_credit = cash paid OUT to stakeholder
    - REDEMPTION: units_debit = shares returned, amount_credit = buyback price paid OUT
    - GRANT: units_credit = options granted
    - EXERCISE: amount_debit = strike price paid IN, units_debit = options exercised
    Date format: YYYY-MM-DD. transaction_reference must be unique."""
    client = await get_client(ctx)
    if not client.entity_id:
        return "Error: No entity set. Use set_context() first."

    payload: dict = {
        "entity_id": client.entity_id,
        "stakeholder_id": stakeholder_id,
        "funding_round_id": funding_round_id,
        "transaction_type": transaction_type,
        "transaction_date": transaction_date,
        "transaction_reference": transaction_reference,
        "units_debit": units_debit,
        "units_credit": units_credit,
        "amount_debit": amount_debit,
        "amount_credit": amount_credit,
    }
    if security_id is not None:
        payload["security_id"] = security_id
    if notes:
        payload["notes"] = notes

    result = await client.post("/assetmanager/security-transactions/", payload)
    t = result["data"]

    return (
        f"Transaction created (id={t['id']}, type={t['transaction_type']}, ref={t['transaction_reference']}).\n"
        f"  Units: debit={t['units_debit']}, credit={t['units_credit']}\n"
        f"  Amount: debit={t['amount_debit']}, credit={t['amount_credit']}"
    )


# ==========================================
# Computed Cap Table
# ==========================================

@mcp.tool(annotations={"readOnlyHint": True})
async def get_cap_table(ctx: Context) -> str:
    """Get the computed cap table for the current entity. Shows ownership breakdown by stakeholder."""
    client = await get_client(ctx)
    if not client.entity_id:
        return "Error: No entity set. Use set_context() first."

    result = await client.get(f"/assetmanager/computed-captable/{client.entity_id}")
    rows = result.get("data", [])

    if not rows:
        return "No cap table entries yet. Create stakeholders and transactions first."

    # Compute totals from rows
    total_units = sum(r.get("total_units", 0) for r in rows)
    total_investment = sum(r.get("total_investment", 0) for r in rows)

    lines = [
        f"Cap Table ({len(rows)} stakeholders)",
        f"Total units: {total_units:,.0f} | Total investment: {total_investment:,.2f}",
        "",
        "Stakeholder | Type | Units | Investment | Ownership %",
        "-" * 70,
    ]
    for row in rows:
        name = row.get("stakeholder_name", "Unknown")
        stype = row.get("stakeholder_type", "")
        units = row.get("total_units", 0)
        investment = row.get("total_investment", 0)
        pct = row.get("equity_ownership_pct", 0)
        lines.append(f"{name} | {stype} | {units:,.0f} | {investment:,.2f} | {pct:.2f}%")

    return "\n".join(lines)


# ==========================================
# Commitments (Cap Table — pro-rata subscription lifecycle)
# ==========================================

@mcp.tool(annotations={"readOnlyHint": True})
async def list_commitments(ctx: Context) -> str:
    """List capital commitments (pro-rata subscriptions) for the current entity.
    These are commitment invitations sent to stakeholders for funding rounds.
    Status lifecycle: invited → committed → approved → transaction generated."""
    client = await get_client(ctx)
    if not client.entity_id:
        return "Error: No entity set. Use set_context() first."

    result = await client.get("/assetmanager/commitments/", params={"entity_id": client.entity_id})
    items = result.get("data", [])

    if not items:
        return "No commitments found for this entity."

    lines = [f"Commitments ({len(items)}):"]
    for c in items:
        name = c.get("stakeholder_name", "Unknown")
        round_name = c.get("funding_round_name", "—")
        pro_rata = c.get("pro_rata_amount", 0)
        committed = c.get("committed_amount", "—")
        lines.append(
            f"  - id={c['id']} | {name} | round={round_name} | "
            f"status={c['status']} | pro_rata={pro_rata:,.2f} | committed={committed}"
        )

    return "\n".join(lines)


# ==========================================
# Stakeholder Positions (Computed — investor's view)
# ==========================================

@mcp.tool(annotations={"readOnlyHint": True})
async def list_positions(ctx: Context) -> str:
    """List stakeholder positions — shows the current entity's investments across all cap tables.
    This is the INVESTOR view: what securities/ownership does this entity hold in OTHER entities."""
    client = await get_client(ctx)
    if not client.entity_id:
        return "Error: No entity set. Use set_context() first."

    result = await client.get(
        "/assetmanager/stakeholder-positions/",
        params={"source_entity_id": client.entity_id}
    )
    items = result.get("data", [])

    if not items:
        return "No positions found. This entity has no investments in other entities' cap tables."

    lines = [f"Positions ({len(items)}):"]
    for p in items:
        entity_name = p.get("entity_name", "Unknown")
        ownership = p.get("ownership_pct", 0)
        units = p.get("total_units", 0)
        investment = p.get("total_investment", 0)
        lines.append(
            f"  - {entity_name} | ownership={ownership:.2f}% | "
            f"units={units:,.0f} | invested={investment:,.2f}"
        )

    return "\n".join(lines)


@mcp.tool(annotations={"readOnlyHint": True})
async def list_distributions(ctx: Context) -> str:
    """List distributions received by the current entity as a stakeholder/investor."""
    client = await get_client(ctx)
    if not client.entity_id:
        return "Error: No entity set. Use set_context() first."

    result = await client.get(
        "/assetmanager/stakeholder-positions/distributions/",
        params={"source_entity_id": client.entity_id}
    )
    items = result.get("data", [])

    if not items:
        return "No distributions received."

    lines = [f"Distributions Received ({len(items)}):"]
    for d in items:
        entity_name = d.get("entity_name", "Unknown")
        amount = d.get("amount", 0)
        date = d.get("date", "—")
        lines.append(f"  - {entity_name} | {date} | amount={amount:,.2f}")

    return "\n".join(lines)
