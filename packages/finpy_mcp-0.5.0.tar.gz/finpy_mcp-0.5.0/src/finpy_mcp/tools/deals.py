"""
Deal tools — deals, commitments, express interest, execute.

Deal lifecycle: DRAFT → ACTIVE → CLOSED → EXECUTED (or CANCELLED)
Deal execution creates: 1 FundingRound + 1 Security + N Stakeholders + N SecurityTransactions
"""

from typing import Literal

from fastmcp import Context

from ..server import mcp
from ..client import get_client


@mcp.tool(annotations={"readOnlyHint": True})
async def list_deals(ctx: Context) -> str:
    """List all deals for the current entity."""
    client = await get_client(ctx)
    if not client.entity_id:
        return "Error: No entity set. Use set_context() first."

    result = await client.get("/assetmanager/deals/", params={"entity_id": client.entity_id})
    items = result.get("data", [])

    if not items:
        return "No deals found. Create one with create_deal()."

    lines = [f"Deals ({len(items)}):"]
    for d in items:
        target = f", target={d['target_amount']}" if d.get("target_amount") else ""
        firm = f", firm={d['firm_commitments']}" if d.get("firm_commitments") else ""
        lines.append(
            f"  - {d['name']} (id={d['id']}, type={d['deal_type']}, status={d['status']}"
            f"{target}{firm}, {d.get('start_date', '?')} — {d.get('end_date', '?')})"
        )

    return "\n".join(lines)


@mcp.tool(annotations={"readOnlyHint": False, "destructiveHint": False, "openWorldHint": False})
async def create_deal(
    name: str,
    start_date: str,
    end_date: str,
    deal_type: Literal["fundraising", "acquisition", "secondary", "debt"] = "fundraising",
    target_amount: float | None = None,
    minimum_investment: float | None = None,
    share_price: float | None = None,
    pre_money_valuation: float | None = None,
    post_money_valuation: float | None = None,
    currency: str = "USD",
    ctx: Context = None,
) -> str:
    """Create a new deal. Dates format: YYYY-MM-DD.
    Deal starts in DRAFT status. Use the Finpy dashboard to set it to ACTIVE
    and enable discoverability for other organizations to find it."""
    client = await get_client(ctx)
    if not client.entity_id:
        return "Error: No entity set. Use set_context() first."

    payload: dict = {
        "entity_id": client.entity_id,
        "name": name,
        "deal_type": deal_type,
        "start_date": start_date,
        "end_date": end_date,
        "currency": currency,
    }
    optional = {
        "target_amount": target_amount, "minimum_investment": minimum_investment,
        "share_price": share_price, "pre_money_valuation": pre_money_valuation,
        "post_money_valuation": post_money_valuation,
    }
    for k, v in optional.items():
        if v is not None:
            payload[k] = v

    result = await client.post("/assetmanager/deals/", payload)
    d = result["data"]

    return (
        f"Deal created: {d['name']} (id={d['id']}, status={d['status']}).\n"
        f"Note: Deal starts in DRAFT. Use update_deal_status() to set it to ACTIVE."
    )


@mcp.tool(annotations={"readOnlyHint": False, "destructiveHint": False, "openWorldHint": False})
async def update_deal(
    deal_id: int,
    name: str | None = None,
    target_amount: float | None = None,
    share_price: float | None = None,
    minimum_investment: float | None = None,
    is_discoverable: bool | None = None,
    ctx: Context = None,
) -> str:
    """Update a deal's fields. Only provided fields are changed.
    NOTE: To change deal STATUS (draft→active→closed), use update_deal_status() instead."""
    client = await get_client(ctx)
    payload: dict = {}
    if name is not None:
        payload["name"] = name
    if target_amount is not None:
        payload["target_amount"] = target_amount
    if share_price is not None:
        payload["share_price"] = share_price
    if minimum_investment is not None:
        payload["minimum_investment"] = minimum_investment
    if is_discoverable is not None:
        payload["is_discoverable"] = is_discoverable

    if not payload:
        return "Error: No fields to update."

    result = await client.put(f"/assetmanager/deals/{deal_id}", payload)
    d = result["data"]

    return f"Deal updated: {d['name']} (id={d['id']}, status={d['status']})."


@mcp.tool(annotations={"readOnlyHint": False, "destructiveHint": False, "openWorldHint": False})
async def update_deal_status(
    deal_id: int,
    status: Literal["active", "closed", "cancelled"],
    ctx: Context = None,
) -> str:
    """Change a deal's lifecycle status. Uses the dedicated status endpoint with transition rules.
    Allowed transitions: draft→active, active→closed/cancelled, closed→active/cancelled.
    Cannot set 'executed' directly — use execute_deal() instead."""
    client = await get_client(ctx)
    result = await client.put(f"/assetmanager/deals/{deal_id}/status", {"status": status})
    d = result["data"]

    return f"Deal status updated: {d['name']} → {d['status']}."


@mcp.tool(annotations={"readOnlyHint": True})
async def list_deal_commitments(deal_id: int, ctx: Context = None) -> str:
    """List all commitments for a specific deal."""
    client = await get_client(ctx)
    result = await client.get("/assetmanager/deal-commitments/", params={"deal_id": deal_id})
    items = result.get("data", [])

    if not items:
        return f"No commitments found for deal {deal_id}."

    lines = [f"Commitments for deal {deal_id} ({len(items)}):"]
    for c in items:
        investor = c.get("investor_entity_name", f"Entity #{c['entity_id']}")
        currency = c.get("deal_currency", "USD")
        lines.append(
            f"  - {investor}: {c['commitment_type']} — {currency} {c['amount']:,.2f} (id={c['id']})"
        )

    return "\n".join(lines)


@mcp.tool(annotations={"readOnlyHint": False, "destructiveHint": False, "openWorldHint": False})
async def express_interest(
    deal_id: int,
    entity_id: int,
    commitment_type: Literal["soft", "firm"] = "soft",
    amount: float | None = None,
    notes: str | None = None,
    ctx: Context = None,
) -> str:
    """Express interest in a deal as an investing entity.
    entity_id is the investing entity (who is committing capital).
    commitment_type: 'soft' = non-binding interest, 'firm' = binding commitment."""
    client = await get_client(ctx)
    payload: dict = {
        "deal_id": deal_id,
        "entity_id": entity_id,
        "commitment_type": commitment_type,
    }
    if amount is not None:
        payload["amount"] = amount
    if notes:
        payload["notes"] = notes

    result = await client.post("/assetmanager/deals/express-interest", payload)
    c = result["data"]

    return f"Interest expressed: {c['commitment_type']} commitment of {c.get('deal_currency', 'USD')} {c['amount']:,.2f} (id={c['id']})."


@mcp.tool(annotations={"readOnlyHint": False, "destructiveHint": False, "openWorldHint": False})
async def execute_deal(
    deal_id: int,
    commitment_ids: list[int],
    round_type: str,
    security_name: str,
    security_code: str,
    security_type: Literal["common", "preferred", "convertible", "safe"] = "preferred",
    stakeholder_type: str = "limited_partner",
    ctx: Context = None,
) -> str:
    """Execute a fundraising deal — creates FundingRound, Security, Stakeholders, and Transactions.
    Deal must be ACTIVE or CLOSED with at least 1 firm commitment.
    commitment_ids: select which firm commitments to include (use list_deal_commitments to see IDs).
    This creates cap table impact from deal data."""
    client = await get_client(ctx)
    payload = {
        "round_type": round_type,
        "security_name": security_name,
        "security_code": security_code,
        "security_type": security_type,
        "stakeholder_type": stakeholder_type,
        "commitment_ids": commitment_ids,
    }

    result = await client.post(f"/assetmanager/deals/{deal_id}/execute", payload)

    return (
        f"Deal executed successfully!\n"
        f"  Funding Round ID: {result.get('funding_round_id')}\n"
        f"  Security ID: {result.get('security_id')}\n"
        f"  Stakeholders created: {result.get('stakeholders_created')}\n"
        f"  Transactions created: {result.get('transactions_created')}\n"
        f"  Total amount: {result.get('total_amount', 0):,.2f}"
    )
