"""
Financial tools — income statements, balance sheets, cash flow statements, financial metrics.

Only entity_id + year are required. All line items are optional.
Scenario defaults to 'actual' (can be 'forecast' or 'budget').
"""

from typing import Literal

from fastmcp import Context

from ..server import mcp
from ..client import get_client


@mcp.tool(annotations={"readOnlyHint": False, "destructiveHint": False, "openWorldHint": False})
async def create_income_statement(
    year: int,
    scenario: Literal["actual", "forecast", "budget"] = "actual",
    quarter: Literal["Q1", "Q2", "Q3", "Q4"] | None = None,
    # Revenue
    revenue: float | None = None,
    cost_of_goods: float | None = None,
    # Operating Expenses
    research_and_development: float | None = None,
    selling_general_and_administrative: float | None = None,
    other_operating_expenses: float | None = None,
    # Results
    operating_income: float | None = None,
    net_income: float | None = None,
    ebitda: float | None = None,
    ctx: Context = None,
) -> str:
    """Create an income statement for the current entity.
    Only year is required. Provide revenue, expenses, and results as available.
    The LLM should ask: 'What was the revenue? COGS? Major expenses?'"""
    client = await get_client(ctx)
    if not client.entity_id:
        return "Error: No entity set. Use set_context() first."

    payload: dict = {
        "entity_id": client.entity_id,
        "year": year,
        "scenario": scenario,
    }
    if quarter:
        payload["quarter"] = quarter

    optional = {
        "revenue": revenue, "cost_of_goods": cost_of_goods,
        "research_and_development": research_and_development,
        "selling_general_and_administrative": selling_general_and_administrative,
        "other_operating_expenses": other_operating_expenses,
        "operating_income": operating_income, "net_income": net_income,
        "ebitda": ebitda,
    }
    for k, v in optional.items():
        if v is not None:
            payload[k] = v

    result = await client.post("/assetmanager/income-statements/", payload)
    item = result["data"]

    return f"Income statement created (id={item['id']}, year={item['year']}, scenario={item['scenario']})."


@mcp.tool(annotations={"readOnlyHint": False, "destructiveHint": False, "openWorldHint": False})
async def create_balance_sheet(
    year: int,
    scenario: Literal["actual", "forecast", "budget"] = "actual",
    quarter: Literal["Q1", "Q2", "Q3", "Q4"] | None = None,
    # Assets
    cash_and_cash_equivalents: float | None = None,
    accounts_receivable: float | None = None,
    inventory: float | None = None,
    total_current_assets: float | None = None,
    total_non_current_assets: float | None = None,
    # Liabilities
    accounts_payable: float | None = None,
    short_term_debt: float | None = None,
    long_term_debt: float | None = None,
    total_current_liabilities: float | None = None,
    total_non_current_liabilities: float | None = None,
    # Equity
    common_stock: float | None = None,
    retained_earnings: float | None = None,
    total_shareholders_equity: float | None = None,
    ctx: Context = None,
) -> str:
    """Create a balance sheet for the current entity.
    Only year is required. Provide assets, liabilities, and equity as available.
    The LLM should ask: 'What are the major asset and liability categories?'"""
    client = await get_client(ctx)
    if not client.entity_id:
        return "Error: No entity set. Use set_context() first."

    payload: dict = {
        "entity_id": client.entity_id,
        "year": year,
        "scenario": scenario,
    }
    if quarter:
        payload["quarter"] = quarter

    optional = {
        "cash_and_cash_equivalents": cash_and_cash_equivalents,
        "accounts_receivable": accounts_receivable, "inventory": inventory,
        "total_current_assets": total_current_assets,
        "total_non_current_assets": total_non_current_assets,
        "accounts_payable": accounts_payable, "short_term_debt": short_term_debt,
        "long_term_debt": long_term_debt,
        "total_current_liabilities": total_current_liabilities,
        "total_non_current_liabilities": total_non_current_liabilities,
        "common_stock": common_stock, "retained_earnings": retained_earnings,
        "total_shareholders_equity": total_shareholders_equity,
    }
    for k, v in optional.items():
        if v is not None:
            payload[k] = v

    result = await client.post("/assetmanager/balance-sheets/", payload)
    item = result["data"]

    return f"Balance sheet created (id={item['id']}, year={item['year']}, scenario={item['scenario']})."


@mcp.tool(annotations={"readOnlyHint": False, "destructiveHint": False, "openWorldHint": False})
async def create_cash_flow_statement(
    year: int,
    scenario: Literal["actual", "forecast", "budget"] = "actual",
    quarter: Literal["Q1", "Q2", "Q3", "Q4"] | None = None,
    # Operating
    cash_from_operations: float | None = None,
    # Investing
    cash_from_investing: float | None = None,
    # Financing
    cash_from_financing: float | None = None,
    # Net
    net_change_in_cash: float | None = None,
    ctx: Context = None,
) -> str:
    """Create a cash flow statement for the current entity.
    Only year is required. Provide operating, investing, and financing cash flows as available."""
    client = await get_client(ctx)
    if not client.entity_id:
        return "Error: No entity set. Use set_context() first."

    payload: dict = {
        "entity_id": client.entity_id,
        "year": year,
        "scenario": scenario,
    }
    if quarter:
        payload["quarter"] = quarter

    optional = {
        "cash_from_operations": cash_from_operations,
        "cash_from_investing": cash_from_investing,
        "cash_from_financing": cash_from_financing,
        "net_change_in_cash": net_change_in_cash,
    }
    for k, v in optional.items():
        if v is not None:
            payload[k] = v

    result = await client.post("/assetmanager/cash-flow-statements/", payload)
    item = result["data"]

    return f"Cash flow statement created (id={item['id']}, year={item['year']}, scenario={item['scenario']})."


@mcp.tool(annotations={"readOnlyHint": False, "destructiveHint": False, "openWorldHint": False})
async def create_financial_metrics(
    year: int,
    scenario: Literal["actual", "forecast", "budget"] = "actual",
    quarter: Literal["Q1", "Q2", "Q3", "Q4"] | None = None,
    ctx: Context = None,
) -> str:
    """Create a financial metrics record for the current entity.
    Only year is required. Additional metric fields can be provided."""
    client = await get_client(ctx)
    if not client.entity_id:
        return "Error: No entity set. Use set_context() first."

    payload: dict = {
        "entity_id": client.entity_id,
        "year": year,
        "scenario": scenario,
    }
    if quarter:
        payload["quarter"] = quarter

    result = await client.post("/assetmanager/financial-metrics/", payload)
    item = result["data"]

    return f"Financial metrics created (id={item['id']}, year={item['year']}, scenario={item['scenario']})."
