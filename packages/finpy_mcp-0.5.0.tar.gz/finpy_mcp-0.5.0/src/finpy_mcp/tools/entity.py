"""
Entity tools — create and update entities.

Entity is the foundation of Finpy. Everything (stakeholders, securities,
deals, holdings, financials) belongs to an entity.
Subscription is charged per entity.
"""

from typing import Literal

from fastmcp import Context

from ..server import mcp
from ..client import get_client


@mcp.tool(annotations={"readOnlyHint": False, "destructiveHint": False, "openWorldHint": False})
async def create_entity(
    name: str,
    entity_type: Literal["fund", "company", "individual", "syndicate"],
    currency: str = "USD",
    ctx: Context = None,
) -> str:
    """Create a new entity (fund, company, individual, or syndicate).
    IMPORTANT: Subscription is charged per entity — inform the user before creating.
    Currency defaults to USD. Common currencies: USD, EUR, GBP, CHF."""
    client = await get_client(ctx)
    if not client.organization_id:
        return "Error: No organization set. Use set_context() first."

    payload = {
        "name": name,
        "entity_type": entity_type,
        "currency": currency,
        "organization_id": client.organization_id,
    }

    result = await client.post("/assetmanager/entities/", payload)
    e = result["data"]

    return (
        f"Entity created successfully.\n"
        f"  Name: {e['name']}\n"
        f"  ID: {e['id']}\n"
        f"  Type: {e['entity_type']}\n"
        f"  Currency: {e['currency']}\n\n"
        f"Note: Your subscription is charged per entity.\n"
        f"Use set_context(organization_id={client.organization_id}, entity_id={e['id']}) to start working with this entity."
    )


@mcp.tool(annotations={"readOnlyHint": False, "destructiveHint": False, "openWorldHint": False})
async def update_entity(
    entity_id: int,
    name: str | None = None,
    currency: str | None = None,
    entity_type: Literal["fund", "company", "individual", "syndicate"] | None = None,
    is_discoverable: bool | None = None,
    ctx: Context = None,
) -> str:
    """Update an entity's basic fields. Only provided fields are changed.
    Common use: change currency, rename, toggle discoverability."""
    client = await get_client(ctx)
    payload: dict = {}
    if name is not None:
        payload["name"] = name
    if currency is not None:
        payload["currency"] = currency
    if entity_type is not None:
        payload["entity_type"] = entity_type
    if is_discoverable is not None:
        payload["is_discoverable"] = is_discoverable

    if not payload:
        return "Error: No fields to update. Provide at least one field (name, currency, entity_type, is_discoverable)."

    result = await client.put(f"/assetmanager/entities/{entity_id}", payload)
    e = result["data"]

    return f"Entity updated: {e['name']} (id={e['id']}, type={e['entity_type']}, currency={e['currency']})"
