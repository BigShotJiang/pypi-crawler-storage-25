"""
KPI tools — define custom KPIs and track their values over time.
"""

from typing import Literal

from fastmcp import Context

from ..server import mcp
from ..client import get_client


# ==========================================
# KPIs (definitions)
# ==========================================

@mcp.tool(annotations={"readOnlyHint": True})
async def list_kpis(ctx: Context) -> str:
    """List all KPI definitions for the current entity."""
    client = await get_client(ctx)
    if not client.entity_id:
        return "Error: No entity set. Use set_context() first."

    result = await client.get("/assetmanager/kpis/", params={"entity_id": client.entity_id})
    items = result.get("data", [])

    if not items:
        return "No KPIs defined. Create one with create_kpi()."

    lines = [f"KPIs ({len(items)}):"]
    for k in items:
        desc = f" — {k['description']}" if k.get("description") else ""
        lines.append(f"  - {k['name']} (id={k['id']}, type={k['data_type']}{desc})")

    return "\n".join(lines)


@mcp.tool(annotations={"readOnlyHint": False, "destructiveHint": False, "openWorldHint": False})
async def create_kpi(
    name: str,
    data_type: Literal["decimal", "integer", "percentage", "string"] = "decimal",
    description: str | None = None,
    formula: str | None = None,
    ctx: Context = None,
) -> str:
    """Create a KPI definition on the current entity.
    Examples: Revenue, MRR, Burn Rate, Customer Count, NPS Score.
    data_type determines how values are displayed (decimal, integer, percentage, string)."""
    client = await get_client(ctx)
    if not client.entity_id:
        return "Error: No entity set. Use set_context() first."

    payload: dict = {
        "entity_id": client.entity_id,
        "name": name,
        "data_type": data_type,
    }
    if description is not None:
        payload["description"] = description
    if formula is not None:
        payload["formula"] = formula

    result = await client.post("/assetmanager/kpis/", payload)
    k = result["data"]

    return f"KPI created: {k['name']} (id={k['id']}, type={k['data_type']}). Use create_kpi_value() to add data points."


# ==========================================
# KPI Values (data points)
# ==========================================

@mcp.tool(annotations={"readOnlyHint": True})
async def list_kpi_values(kpi_id: int, ctx: Context = None) -> str:
    """List all values for a specific KPI. Use list_kpis() first to find kpi_id."""
    client = await get_client(ctx)
    result = await client.get("/assetmanager/kpi-values/", params={"kpi_id": kpi_id})
    items = result.get("data", [])

    if not items:
        return f"No values found for KPI id={kpi_id}. Add some with create_kpi_value()."

    lines = [f"KPI Values for kpi_id={kpi_id} ({len(items)}):"]
    for v in items:
        period = f"year={v['year']}"
        if v.get("quarter"):
            period += f" {v['quarter']}"
        val = v.get("value", "—")
        scenario = v.get("scenario", "actual")
        notes = f" — {v['notes']}" if v.get("notes") else ""
        lines.append(f"  - id={v['id']} | {period} | {scenario} | value={val}{notes}")

    return "\n".join(lines)


@mcp.tool(annotations={"readOnlyHint": False, "destructiveHint": False, "openWorldHint": False})
async def create_kpi_value(
    kpi_id: int,
    year: int,
    value: float | None = None,
    scenario: Literal["actual", "forecast", "budget"] = "actual",
    quarter: Literal["Q1", "Q2", "Q3", "Q4"] | None = None,
    semester: Literal["S1", "S2"] | None = None,
    month: str | None = None,
    notes: str | None = None,
    ctx: Context = None,
) -> str:
    """Add a data point to a KPI. Use list_kpis() to find kpi_id.
    Example: create_kpi_value(kpi_id=1, year=2026, value=1000000) for annual Revenue of $1M.
    Use quarter for quarterly data, month for monthly."""
    client = await get_client(ctx)
    payload: dict = {
        "kpi_id": kpi_id,
        "year": year,
        "scenario": scenario,
    }
    optional = {
        "value": value, "quarter": quarter, "semester": semester,
        "month": month, "notes": notes,
    }
    for k, v in optional.items():
        if v is not None:
            payload[k] = v

    result = await client.post("/assetmanager/kpi-values/", payload)
    v = result["data"]

    return f"KPI value created: id={v['id']}, kpi_id={v['kpi_id']}, year={v['year']}, value={v.get('value', '—')}."
