"""
Holdings tools — portfolio holdings and performance.

A holding represents an investment your entity made in another company/fund.
The entity_id on holding = the INVESTING entity (your fund), not the company invested in.
"""

from typing import Literal

from fastmcp import Context

from ..server import mcp
from ..client import get_client


@mcp.tool(annotations={"readOnlyHint": True})
async def list_holdings(ctx: Context) -> str:
    """List all holdings (portfolio investments) for the current entity."""
    client = await get_client(ctx)
    if not client.entity_id:
        return "Error: No entity set. Use set_context() first."

    result = await client.get("/assetmanager/holdings/", params={"entity_id": client.entity_id})
    items = result.get("data", [])

    if not items:
        return "No holdings found. Create one with create_holding()."

    lines = [f"Holdings ({len(items)}):"]
    for h in items:
        amount = f", invested={h['total_investment_amount']:,.2f}" if h.get("total_investment_amount") else ""
        ownership = f", ownership={h['ownership_percentage']}%" if h.get("ownership_percentage") else ""
        fair_value = f", fair_value={h['current_fair_value']:,.2f}" if h.get("current_fair_value") else ""
        lines.append(
            f"  - {h['investment_name']} (id={h['id']}, type={h['investment_type']}, "
            f"status={h['investment_status']}{amount}{ownership}{fair_value})"
        )

    return "\n".join(lines)


@mcp.tool(annotations={"readOnlyHint": False, "destructiveHint": False, "openWorldHint": False})
async def create_holding(
    investment_name: str,
    entity_type: Literal["venture_capital", "private_equity", "public", "cash"],
    investment_type: Literal["equity", "debt", "convertible", "warrant", "option", "cash"],
    sector: Literal["fintech", "healthtech", "ecommerce", "saas", "ai_ml", "blockchain", "cleantech", "edtech", "enterprise", "consumer", "other"] | None = None,
    total_investment_amount: float | None = None,
    ownership_percentage: float | None = None,
    current_fair_value: float | None = None,
    original_investment_date: str | None = None,
    ctx: Context = None,
) -> str:
    """Create a new portfolio holding (investment your entity made in another company/fund).
    The current entity (from context) is the INVESTOR. investment_name is the display name.
    If the target company is also a Finpy entity, create it first with create_entity()."""
    client = await get_client(ctx)
    if not client.entity_id:
        return "Error: No entity set. Use set_context() first."

    payload: dict = {
        "entity_id": client.entity_id,
        "investment_name": investment_name,
        "entity_type": entity_type,
        "investment_type": investment_type,
    }
    optional = {
        "sector": sector, "total_investment_amount": total_investment_amount,
        "ownership_percentage": ownership_percentage, "current_fair_value": current_fair_value,
        "original_investment_date": original_investment_date,
    }
    for k, v in optional.items():
        if v is not None:
            payload[k] = v

    result = await client.post("/assetmanager/holdings/", payload)
    h = result["data"]

    return f"Holding created: {h['investment_name']} (id={h['id']}, type={h['investment_type']})."


@mcp.tool(annotations={"readOnlyHint": False, "destructiveHint": False, "openWorldHint": False})
async def update_holding(
    holding_id: int,
    investment_status: Literal["active", "exited", "written_off"] | None = None,
    current_fair_value: float | None = None,
    ownership_percentage: float | None = None,
    total_investment_amount: float | None = None,
    investment_name: str | None = None,
    ctx: Context = None,
) -> str:
    """Update a holding's key fields. Only provided fields are changed.
    Common use: mark-to-market (update fair_value), change status to exited, adjust ownership %."""
    client = await get_client(ctx)
    payload: dict = {}
    if investment_status is not None:
        payload["investment_status"] = investment_status
    if current_fair_value is not None:
        payload["current_fair_value"] = current_fair_value
    if ownership_percentage is not None:
        payload["ownership_percentage"] = ownership_percentage
    if total_investment_amount is not None:
        payload["total_investment_amount"] = total_investment_amount
    if investment_name is not None:
        payload["investment_name"] = investment_name

    if not payload:
        return "Error: No fields to update."

    result = await client.put(f"/assetmanager/holdings/{holding_id}", payload)
    h = result["data"]

    return f"Holding updated: {h['investment_name']} (id={h['id']}, status={h['investment_status']})."


# ==========================================
# Holding Cash Flows
# ==========================================

@mcp.tool(annotations={"readOnlyHint": True})
async def list_holding_cash_flows(holding_id: int | None = None, ctx: Context = None) -> str:
    """List cash flows for the current entity's holdings.
    Optionally filter by holding_id. Use list_holdings() to find holding IDs."""
    client = await get_client(ctx)
    if not client.entity_id:
        return "Error: No entity set. Use set_context() first."

    params: dict = {"entity_id": client.entity_id}
    if holding_id is not None:
        params["holding_id"] = holding_id

    result = await client.get("/assetmanager/holding-cash-flows/", params=params)
    items = result.get("data", [])

    if not items:
        return "No holding cash flows found. Create one with create_holding_cash_flow()."

    lines = [f"Holding Cash Flows ({len(items)}):"]
    for cf in items:
        debit = cf.get("amount_debit", 0)
        credit = cf.get("amount_credit", 0)
        lines.append(
            f"  - id={cf['id']} | holding_id={cf['holding_id']} | {cf['date']} | "
            f"{cf['cash_flow_type']} | debit={debit:,.2f} credit={credit:,.2f}"
        )

    return "\n".join(lines)


@mcp.tool(annotations={"readOnlyHint": False, "destructiveHint": False, "openWorldHint": False})
async def create_holding_cash_flow(
    holding_id: int,
    date: str,
    cash_flow_type: Literal["investment", "distribution", "dividend", "fee", "other"],
    amount_debit: float = 0,
    amount_credit: float = 0,
    currency: str = "USD",
    category: Literal["actual", "projected"] = "actual",
    include_in_irr: bool = True,
    description: str | None = None,
    ctx: Context = None,
) -> str:
    """Record a cash flow on a holding. Date format: YYYY-MM-DD.
    From ENTITY perspective (the investor):
    - amount_debit = cash RECEIVED (distributions, dividends coming back)
    - amount_credit = cash PAID OUT (investment capital deployed)
    Examples:
    - Investment of $500K: amount_credit=500000
    - Distribution received of $100K: amount_debit=100000
    - Management fee paid of $10K: amount_credit=10000"""
    client = await get_client(ctx)
    if not client.entity_id:
        return "Error: No entity set. Use set_context() first."

    payload: dict = {
        "entity_id": client.entity_id,
        "holding_id": holding_id,
        "date": date,
        "cash_flow_type": cash_flow_type,
        "amount_debit": amount_debit,
        "amount_credit": amount_credit,
        "currency": currency,
        "category": category,
        "include_in_irr": include_in_irr,
    }
    if description is not None:
        payload["description"] = description

    result = await client.post("/assetmanager/holding-cash-flows/", payload)
    cf = result["data"]

    return (
        f"Holding cash flow created: id={cf['id']}, {cf['cash_flow_type']}, "
        f"debit={cf['amount_debit']:,.2f}, credit={cf['amount_credit']:,.2f}."
    )


# ==========================================
# Performance (Computed)
# ==========================================

@mcp.tool(annotations={"readOnlyHint": True})
async def get_entity_performance(ctx: Context) -> str:
    """Get computed performance metrics for the current entity (IRR, TVPI, DPI, etc.)."""
    client = await get_client(ctx)
    if not client.entity_id:
        return "Error: No entity set. Use set_context() first."

    result = await client.get(f"/assetmanager/performance/entity/{client.entity_id}")
    data = result.get("data", {})

    lines = [
        f"Entity Performance:",
        f"  Total Invested: {data.get('total_invested', 0):,.2f}",
        f"  Total Fair Value: {data.get('total_fair_value', 0):,.2f}",
        f"  Total Distributions: {data.get('total_distributions', 0):,.2f}",
        f"  TVPI: {data.get('tvpi', 0):.2f}x",
        f"  DPI: {data.get('dpi', 0):.2f}x",
        f"  RVPI: {data.get('rvpi', 0):.2f}x",
        f"  IRR: {data.get('irr', 0):.2f}%",
    ]

    return "\n".join(lines)


@mcp.tool(annotations={"readOnlyHint": True})
async def get_holdings_performance(ctx: Context) -> str:
    """Get computed performance for each individual holding (per-investment IRR, TVPI, DPI)."""
    client = await get_client(ctx)
    if not client.entity_id:
        return "Error: No entity set. Use set_context() first."

    result = await client.get(f"/assetmanager/performance/holdings/{client.entity_id}")
    items = result.get("data", [])

    if not items:
        return "No holdings performance data available."

    lines = [f"Holdings Performance ({len(items)}):"]
    for h in items:
        name = h.get("investment_name", "Unknown")
        tvpi = h.get("tvpi", 0)
        irr = h.get("irr", 0)
        invested = h.get("total_invested", 0)
        lines.append(f"  - {name} | invested={invested:,.2f} | TVPI={tvpi:.2f}x | IRR={irr:.2f}%")

    return "\n".join(lines)


@mcp.tool(annotations={"readOnlyHint": True})
async def get_stakeholder_returns(ctx: Context) -> str:
    """Get computed returns for each stakeholder (per-LP performance)."""
    client = await get_client(ctx)
    if not client.entity_id:
        return "Error: No entity set. Use set_context() first."

    result = await client.get(f"/assetmanager/performance/stakeholders/{client.entity_id}")
    items = result.get("data", [])

    if not items:
        return "No stakeholder returns data available."

    lines = [f"Stakeholder Returns ({len(items)}):"]
    for s in items:
        name = s.get("stakeholder_name", "Unknown")
        committed = s.get("total_committed", 0)
        distributed = s.get("total_distributed", 0)
        tvpi = s.get("tvpi", 0)
        lines.append(f"  - {name} | committed={committed:,.2f} | distributed={distributed:,.2f} | TVPI={tvpi:.2f}x")

    return "\n".join(lines)
