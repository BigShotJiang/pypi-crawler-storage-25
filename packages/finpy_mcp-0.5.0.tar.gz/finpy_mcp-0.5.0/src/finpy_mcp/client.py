"""
Finpy MCP Server — HTTP Client

Async httpx wrapper that handles:
- JWT authentication (from ~/.finpy/credentials.json or OAuth token)
- Organization context (query param)
- Entity context (for tools that need it)
- Automatic token refresh on 401 responses

Two modes:
- Local (stdio): token read from ~/.finpy/credentials.json (token=None)
- Remote (HTTP): token passed from OAuth flow via get_client(ctx)
"""

import httpx
from fastmcp import Context
from fastmcp.server.dependencies import get_access_token

from .config import API_BASE_URL, REQUEST_TIMEOUT
from .credentials import load_credentials, save_credentials


class FinpyClient:
    """HTTP client for Finpy API with JWT auth and org/entity context.

    Two modes:
    - Local (stdio): token read from ~/.finpy/credentials.json (token=None)
    - Remote (HTTP): token passed from OAuth flow (token="eyJ...")
    """

    def __init__(self, token: str | None = None) -> None:
        self.base_url = API_BASE_URL
        self.organization_id: int | None = None
        self.entity_id: int | None = None
        self._token = token  # Remote mode: JWT from OAuth header

    def _get_credentials(self) -> dict:
        """Load credentials or raise descriptive error."""
        creds = load_credentials()
        if not creds or not creds.get("access_token"):
            raise RuntimeError(
                "Not authenticated. Please run 'finpy-cli login' in your terminal first."
            )
        return creds

    @property
    def _headers(self) -> dict:
        """Auth headers — from OAuth token (remote) or stored credentials (local)."""
        if self._token:
            return {"Authorization": f"Bearer {self._token}"}
        creds = self._get_credentials()
        return {"Authorization": f"Bearer {creds['access_token']}"}

    @property
    def _params(self) -> dict:
        """Default query params (organization_id)."""
        org_id = self.organization_id
        # Local mode: fall back to org from credentials file
        if org_id is None and not self._token:
            creds = load_credentials()
            if creds:
                org_id = creds.get("organization_id")
        params: dict = {}
        if org_id is not None:
            params["organization_id"] = org_id
        return params

    async def _refresh_token(self) -> bool:
        """Attempt to refresh JWT using refresh_token. Returns True if successful.
        Remote mode: no local refresh — OAuth provider handles refresh via FastMCP."""
        if self._token:
            return False

        creds = load_credentials()
        if not creds or not creds.get("refresh_token"):
            return False

        try:
            async with httpx.AsyncClient(timeout=REQUEST_TIMEOUT) as http:
                r = await http.post(
                    f"{self.base_url}/accounts/auth/refresh-token",
                    json={"refresh_token": creds["refresh_token"]},
                )
                if r.status_code == 200:
                    data = r.json()
                    creds["access_token"] = data["token"]["access_token"]
                    creds["refresh_token"] = data["token"]["refresh_token"]
                    save_credentials(creds)
                    return True
        except httpx.HTTPError:
            pass
        return False

    async def _request(self, method: str, path: str, **kwargs) -> dict:
        """Make HTTP request with auto-refresh on 401."""
        params = {**self._params, **kwargs.pop("params", {})}

        async with httpx.AsyncClient(timeout=REQUEST_TIMEOUT) as http:
            r = await http.request(
                method,
                f"{self.base_url}{path}",
                headers=self._headers,
                params=params,
                **kwargs,
            )

            # Auto-refresh on 401
            if r.status_code == 401:
                refreshed = await self._refresh_token()
                if refreshed:
                    r = await http.request(
                        method,
                        f"{self.base_url}{path}",
                        headers=self._headers,
                        params=params,
                        **kwargs,
                    )
                else:
                    if self._token:
                        raise RuntimeError("Session expired. Please re-authenticate via /mcp → Authenticate.")
                    raise RuntimeError("Session expired. Please run 'finpy-cli login' again.")

            r.raise_for_status()
            return r.json()

    async def get(self, path: str, **kwargs) -> dict:
        """GET request to Finpy API."""
        return await self._request("GET", path, **kwargs)

    async def post(self, path: str, data: dict) -> dict:
        """POST request to Finpy API."""
        return await self._request("POST", path, json=data)

    async def put(self, path: str, data: dict) -> dict:
        """PUT request to Finpy API."""
        return await self._request("PUT", path, json=data)


# Singleton instance — used in local/stdio mode (single user)
finpy = FinpyClient()


async def get_client(ctx: Context) -> FinpyClient:
    """Get a FinpyClient for the current request.
    Local mode (no auth token): returns singleton.
    Remote mode (auth token present): creates per-request client with session state."""
    token_obj = get_access_token()
    if not token_obj:
        # Local mode — use singleton
        return finpy

    # Remote mode — per-request client with user's JWT
    client = FinpyClient(token=token_obj.token)

    # Restore org/entity from session state (set by set_context tool)
    client.organization_id = await ctx.get_state("organization_id")
    client.entity_id = await ctx.get_state("entity_id")

    return client
