# finpy-mcp

**Finpy MCP Server** — Manage cap tables, deals, holdings, and financials through AI conversation.

Connect your favorite AI tool (Claude Desktop, Cursor, VS Code, Claude Code) to the [Finpy](https://www.finpy.tech) platform and work with your financial data through natural language.

## Features

- **30 tools** for asset management operations
- **Cap table management** — stakeholders, funding rounds, securities, transactions
- **Deal flow** — create deals, express interest, execute fundraising rounds
- **Portfolio tracking** — holdings, valuations, performance metrics (IRR, MOIC, TVPI)
- **Financial reporting** — income statements, balance sheets, cash flow statements
- **Secure** — OAuth device flow login, credentials stored locally, no passwords sent to AI

## Quick Start

### 1. Install

```bash
pip install finpy-mcp
```

Or with uv:

```bash
# Install uv (if not already installed)
brew install uv

# Add uv tools to PATH (one-time setup)
echo 'export PATH="$HOME/.local/bin:$PATH"' >> ~/.zshrc
source ~/.zshrc

# Install finpy-mcp
uv tool install finpy-mcp
```

Already installed? Update:

```bash
pip install --upgrade finpy-mcp
# or
uv tool upgrade finpy-mcp
```

### 2. Login

```bash
finpy-cli login
```

Opens your browser automatically. Sign in on the Finpy web app, then return to your terminal.

### 3. Configure your AI client

**Claude Desktop** — Edit `~/Library/Application Support/Claude/claude_desktop_config.json` (macOS) or `%APPDATA%\Claude\claude_desktop_config.json` (Windows):

```json
{
  "mcpServers": {
    "finpy": {
      "command": "finpy-mcp"
    }
  }
}
```

**Cursor** — Edit `.cursor/mcp.json`:

```json
{
  "mcpServers": {
    "finpy": {
      "command": "finpy-mcp"
    }
  }
}
```

**Claude Code:**

```bash
claude mcp add finpy -- finpy-mcp
```

Restart your AI client after configuring.

### 4. Start talking

Open a new conversation and say:

- *"List my entities"*
- *"Show me the cap table for Nexotype"*
- *"Create a stakeholder John Doe as limited partner with 8% preferred return"*
- *"Create an income statement for 2026 with $1M revenue"*

## Available Tools (30)

| Category | Tools |
|----------|-------|
| **Context** | list_organizations, set_context, list_entities, get_entity_details |
| **Entity** | create_entity, update_entity |
| **Cap Table** | list_stakeholders, create_stakeholder, update_stakeholder, list_funding_rounds, create_funding_round, create_security, list_transactions, create_transaction, get_cap_table |
| **Deals** | list_deals, create_deal, update_deal, update_deal_status, list_deal_commitments, express_interest, execute_deal |
| **Holdings** | list_holdings, create_holding, update_holding, get_entity_performance |
| **Financials** | create_income_statement, create_balance_sheet, create_cash_flow_statement, create_financial_metrics |

## CLI Commands

```bash
finpy-cli login          # Login via browser (OAuth device flow)
finpy-cli login --basic  # Login with email/password (headless fallback)
finpy-cli logout         # Delete stored credentials
finpy-cli set-org <id>   # Switch active organization
finpy-cli status         # Show auth status
```

## Security

- Passwords never reach the AI — login happens in your browser
- Credentials stored locally in `~/.finpy/credentials.json` (chmod 600)
- Automatic token refresh on expiry
- No delete operations exposed — prevents accidental data loss
- All API validations, permissions, and audit logging apply

## Requirements

- Python 3.12+
- A [Finpy](https://www.finpy.tech) account

## Links

- [Finpy Platform](https://www.finpy.tech)
- [PyPI Package](https://pypi.org/project/finpy-mcp/)
