"""Tests for project-config rules + opt-in test-quality heuristics + gating."""

from pathlib import Path

import pytest

from gruffpy.config.analysis_config import AnalysisConfig
from gruffpy.config.rule_settings import RuleSettings
from gruffpy.rule.context import RuleContext
from gruffpy.rule.registry import RuleRegistry
from gruffpy.rule.test_quality._pytest_config import reset_cache
from gruffpy.rule.test_quality.mocking_domain_object_rule import MockingDomainObjectRule
from gruffpy.rule.test_quality.multiple_aaa_cycles_rule import MultipleAaaCyclesRule
from gruffpy.rule.test_quality.pytest_coverage_source_missing_rule import (
    PytestCoverageSourceMissingRule,
)
from gruffpy.rule.test_quality.pytest_deprecations_not_fatal_rule import (
    PytestDeprecationsNotFatalRule,
)
from gruffpy.rule.test_quality.pytest_strict_config_missing_rule import (
    PytestStrictConfigMissingRule,
)
from gruffpy.rule.test_quality.testdox_readability_rule import TestdoxReadabilityRule
from tests.unit.rule.test_quality._helpers import make_unit

_TEST_FIXTURE = "def test_something():\n    assert 1 + 1 == 2\n"
_NON_TEST_FIXTURE = "def helper():\n    return 1\n"


def _ctx_with_pyproject(tmp_path: Path, contents: str) -> RuleContext:
    (tmp_path / "pyproject.toml").write_text(contents)
    reset_cache()
    return RuleContext(
        project_root=str(tmp_path),
        config=AnalysisConfig.from_registry(RuleRegistry.defaults()),
    )


def test_strict_config_missing_emits_when_pytest_block_lacks_flags(tmp_path: Path):
    ctx = _ctx_with_pyproject(
        tmp_path,
        "[tool.pytest.ini_options]\naddopts = '-ra -q'\n",
    )
    findings = PytestStrictConfigMissingRule().analyse(make_unit(_TEST_FIXTURE), ctx)
    assert len(findings) == 1
    assert findings[0].file_path == "pyproject.toml"


def test_strict_config_present_skips(tmp_path: Path):
    ctx = _ctx_with_pyproject(
        tmp_path,
        '[tool.pytest.ini_options]\naddopts = "--strict-config --strict-markers"\n',
    )
    assert PytestStrictConfigMissingRule().analyse(make_unit(_TEST_FIXTURE), ctx) == []


def test_strict_config_rule_skipped_on_non_test_unit(tmp_path: Path):
    """Project-config rules must not fire on non-test units - gating regression.

    Args:
        tmp_path: Pytest-provided per-test directory holding the synthetic ``pyproject.toml``.
    """
    ctx = _ctx_with_pyproject(
        tmp_path,
        "[tool.pytest.ini_options]\naddopts = '-ra'\n",
    )
    assert PytestStrictConfigMissingRule().analyse(make_unit(_NON_TEST_FIXTURE), ctx) == []


def test_all_project_config_rules_skip_non_test_units(tmp_path: Path):
    ctx = _ctx_with_pyproject(
        tmp_path,
        "[tool.pytest.ini_options]\naddopts = '-ra'\n",
    )
    unit = make_unit(_NON_TEST_FIXTURE)

    assert PytestStrictConfigMissingRule().analyse(unit, ctx) == []
    assert PytestDeprecationsNotFatalRule().analyse(unit, ctx) == []
    assert PytestCoverageSourceMissingRule().analyse(unit, ctx) == []


def test_deprecations_not_fatal_emits_when_filterwarnings_silent(tmp_path: Path):
    ctx = _ctx_with_pyproject(
        tmp_path,
        "[tool.pytest.ini_options]\naddopts = '--strict-config'\n",
    )
    findings = PytestDeprecationsNotFatalRule().analyse(make_unit(_TEST_FIXTURE), ctx)
    assert len(findings) == 1
    assert findings[0].file_path == "pyproject.toml"


def test_deprecations_not_fatal_skipped_with_filterwarnings(tmp_path: Path):
    ctx = _ctx_with_pyproject(
        tmp_path,
        ('[tool.pytest.ini_options]\nfilterwarnings = ["error::DeprecationWarning"]\n'),
    )
    assert PytestDeprecationsNotFatalRule().analyse(make_unit(_TEST_FIXTURE), ctx) == []


def test_coverage_source_missing_emits(tmp_path: Path):
    ctx = _ctx_with_pyproject(
        tmp_path,
        "[tool.pytest.ini_options]\naddopts = '-q'\n",
    )
    findings = PytestCoverageSourceMissingRule().analyse(make_unit(_TEST_FIXTURE), ctx)
    assert len(findings) == 1
    assert findings[0].file_path == "pyproject.toml"


def test_project_config_rules_skip_when_pyproject_has_no_pytest_config(tmp_path: Path):
    ctx = _ctx_with_pyproject(
        tmp_path,
        '[tool.coverage.run]\nsource = ["my_package"]\n',
    )
    unit = make_unit(_TEST_FIXTURE)

    assert PytestStrictConfigMissingRule().analyse(unit, ctx) == []
    assert PytestDeprecationsNotFatalRule().analyse(unit, ctx) == []
    assert PytestCoverageSourceMissingRule().analyse(unit, ctx) == []


def test_coverage_source_present_skips(tmp_path: Path):
    ctx = _ctx_with_pyproject(
        tmp_path,
        '[tool.coverage.run]\nsource = ["my_package"]\n',
    )
    assert PytestCoverageSourceMissingRule().analyse(make_unit(_TEST_FIXTURE), ctx) == []


@pytest.mark.parametrize(
    "rule_cls",
    [MockingDomainObjectRule, MultipleAaaCyclesRule, TestdoxReadabilityRule],
    ids=lambda c: c.__name__,
)
def test_opt_in_rule_default_off(rule_cls: type) -> None:
    """The opt-in test-quality rules must default to enabled=False.

    Args:
        rule_cls: Rule class expected to ship with ``default_enabled=False``.
    """
    assert rule_cls().definition().default_enabled is False


def test_multiple_aaa_cycles_requires_opt_in():
    """Default-off rules don't fire through the registry unless explicitly enabled."""
    config = AnalysisConfig.from_registry(RuleRegistry.defaults())
    # Verify the rule is in defaults() but its settings.enabled is False.
    settings = config.rule_settings(MultipleAaaCyclesRule.ID)
    assert settings.enabled is False


def test_multiple_aaa_cycles_fires_when_enabled(tmp_path: Path):
    """When opted in, the rule does fire on multi-cycle tests.

    Args:
        tmp_path: Pytest-provided per-test directory used as the project root.
    """
    rule = MultipleAaaCyclesRule()
    config = AnalysisConfig(
        rules={
            rule.definition().id: RuleSettings(enabled=True, thresholds={"maxCycles": 1}),
        }
    )
    ctx = RuleContext(project_root=str(tmp_path), config=config)
    src = (
        "def test_x():\n"
        "    x = 1\n"
        "    assert x == 1\n"
        "    y = 2\n"
        "    assert y == 2\n"
        "    z = 3\n"
        "    assert z == 3\n"
    )
    findings = rule.analyse(make_unit(src), ctx)
    assert len(findings) == 1
    assert findings[0].metadata["cycles"] >= 2


def test_testdox_readability_skipped_when_default(tmp_path: Path):
    """testdox-readability is default-off; even short test names don't fire by default.

    Args:
        tmp_path: Pytest-provided per-test directory used as the project root.
    """
    rule = TestdoxReadabilityRule()
    registry = RuleRegistry.defaults()
    config = AnalysisConfig.from_registry(registry)
    ctx = RuleContext(project_root=str(tmp_path), config=config)
    # Default-off rule must NOT appear in any finding produced by the full registry.
    findings = registry.analyse([make_unit("def test_x():\n    pass\n")], ctx)
    assert all(f.rule_id != rule.definition().id for f in findings)
