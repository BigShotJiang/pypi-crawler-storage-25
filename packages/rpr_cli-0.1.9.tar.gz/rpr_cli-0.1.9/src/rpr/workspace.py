from __future__ import annotations

import json
import re
from pathlib import Path

from rich.console import Console

from rpr.context import RunContext

console = Console()
DEFAULT_NPM_WORKSPACES = ["apps/*", "packages/node/*"]


def _npm_package_name(package_name: str) -> str:
    normalized = package_name.replace("_", "-").lower()
    normalized = re.sub(r"[^a-z0-9._-]+", "-", normalized).strip(".-")
    return normalized or "package"


def add_workspace_member(ctx: RunContext, member: str) -> None:
    """Add a UV workspace member to the root pyproject.toml."""
    pyproject_path = ctx.project_dir / "pyproject.toml"
    if ctx.dry_run:
        console.print(
            f"[bold yellow][DRY RUN][/] Would add '{member}' to workspace members in {pyproject_path}",
            soft_wrap=True,
        )
        return

    import tomllib

    with open(pyproject_path, "rb") as f:
        data = tomllib.load(f)

    members = data.get("tool", {}).get("uv", {}).get("workspace", {}).get("members", [])
    if member in members:
        return

    members.append(member)
    members_str = ", ".join(f'"{m}"' for m in members)
    new_members_line = f"members = [{members_str}]"

    content = pyproject_path.read_text()
    content = re.sub(
        r"members\s*=\s*\[.*?\]", new_members_line, content, flags=re.DOTALL
    )
    pyproject_path.write_text(content)
    console.print(f"[bold green]Updated:[/] Added '{member}' to workspace members")


def derive_variables(project_name: str) -> dict[str, str]:
    """Derive the four canonical token variants from the raw project name."""
    name_underscore = project_name.replace("-", "_")
    pascal = "".join(w.capitalize() for w in re.split(r"[-_]+", project_name) if w)
    return {
        "name": project_name,
        "name-of-app": project_name,
        "name_underscore": name_underscore,
        "NamePascal": pascal,
    }


def write_package_json(
    ctx: RunContext,
    path: Path,
    *,
    defaults: dict[str, object] | None = None,
    dependencies: dict[str, str] | None = None,
    dev_dependencies: dict[str, str] | None = None,
) -> None:
    """Create or update a package.json while preserving existing package pins."""
    package: dict[str, object]
    existed = path.exists()

    if existed:
        try:
            package = json.loads(path.read_text())
        except json.JSONDecodeError:
            package = {}
    else:
        package = {}

    for key, value in (defaults or {}).items():
        if key == "name":
            package[key] = value
        else:
            package.setdefault(key, value)

    for field_name, additions in (
        ("dependencies", dependencies or {}),
        ("devDependencies", dev_dependencies or {}),
    ):
        field = package.setdefault(field_name, {})
        if not isinstance(field, dict):
            field = {}
            package[field_name] = field
        for dep_name, version in additions.items():
            if version.startswith("file:"):
                for existing_name, existing_value in list(field.items()):
                    if (
                        existing_name != dep_name
                        and isinstance(existing_value, str)
                        and existing_value.startswith("workspace:")
                    ):
                        field.pop(existing_name)
            existing_version = field.get(dep_name)
            if existing_version is None:
                field[dep_name] = version
            elif (
                isinstance(existing_version, str)
                and existing_version.startswith("workspace:")
                and version.startswith("file:")
            ):
                field[dep_name] = version

    content = json.dumps(package, indent=2) + "\n"
    if existed:
        ctx.update_file(path, content)
    else:
        ctx.write_file(path, content)


def ensure_npm_workspaces(ctx: RunContext, *, package_name: str | None = None) -> None:
    """Ensure the root package.json declares the standard npm workspace globs."""
    package_path = ctx.project_dir / "package.json"
    package: dict[str, object]
    existed = package_path.exists()

    if existed:
        try:
            package = json.loads(package_path.read_text())
        except json.JSONDecodeError:
            package = {}
    else:
        package = {}

    if package_name:
        package["name"] = _npm_package_name(package_name)
    package["private"] = True

    workspaces = package.get("workspaces", [])
    if not isinstance(workspaces, list):
        workspaces = []

    for workspace in DEFAULT_NPM_WORKSPACES:
        if workspace not in workspaces:
            workspaces.append(workspace)

    package["workspaces"] = workspaces

    content = json.dumps(package, indent=2) + "\n"
    if existed:
        ctx.update_file(package_path, content)
    else:
        ctx.write_file(package_path, content)
