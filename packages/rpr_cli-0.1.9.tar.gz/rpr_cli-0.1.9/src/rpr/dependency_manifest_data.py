from __future__ import annotations

# This file is maintained by `rpr refresh manifest`.
# Keep the structure stable so the refresh command can rewrite it safely.

MANIFEST = {
    "root_node_dev_dependencies": {
        "@eslint/js": {
            "specifier": "^9.39.4",
        },
        "@nx/eslint": {
            "specifier": "^22.7.1",
        },
        "@nx/eslint-plugin": {
            "specifier": "^22.7.1",
        },
        "eslint": {
            "specifier": "^9.39.4",
        },
        "eslint-plugin-import": {
            "specifier": "^2.32.0",
        },
        "eslint-plugin-jsx-a11y": {
            "specifier": "^6.10.2",
        },
        "eslint-plugin-react": {
            "specifier": "^7.37.5",
        },
        "eslint-plugin-react-hooks": {
            "specifier": "^7.1.1",
        },
        "globals": {
            "specifier": "^15.15.0",
        },
        "prettier": {
            "specifier": "^3.7.4",
        },
        "typescript-eslint": {
            "specifier": "^8.59.2",
        },
    },
    "root_storybook_dev_dependencies": {
        "@nx/storybook": {
            "registry": "npm",
            "specifier": "latest",
            "strategy": "caret",
        }
    },
    "ui_library_dependencies": {
        "@mui/material": {
            "registry": "npm",
            "specifier": "^9",
            "strategy": "caret",
        },
        "@emotion/react": {
            "registry": "npm",
            "specifier": "^11",
            "strategy": "caret",
        },
        "@emotion/styled": {
            "registry": "npm",
            "specifier": "^11",
            "strategy": "caret",
        },
        "@tanstack/react-query": {
            "registry": "npm",
            "specifier": "^5",
            "strategy": "caret",
        },
        "@tanstack/react-router": {
            "registry": "npm",
            "specifier": "^1",
            "strategy": "caret",
        },
        "react": {
            "registry": "npm",
            "specifier": "^19",
            "strategy": "caret",
        },
        "react-dom": {
            "registry": "npm",
            "specifier": "^19",
            "strategy": "caret",
        },
    },
    "ui_library_dev_dependencies": {
        "@types/react": {
            "registry": "npm",
            "specifier": "^19",
            "strategy": "caret",
        },
        "@types/react-dom": {
            "registry": "npm",
            "specifier": "^19",
            "strategy": "caret",
        },
        "typescript": {
            "registry": "npm",
            "specifier": "^5",
            "strategy": "caret",
        },
        "vite": {
            "registry": "npm",
            "specifier": "^8",
            "strategy": "caret",
        },
        "vitest": {
            "registry": "npm",
            "specifier": "^4",
            "strategy": "caret",
        },
    },
    "web_app_dev_dependencies": {
        "@types/react": {
            "registry": "npm",
            "specifier": "^19",
            "strategy": "caret",
        },
        "@types/react-dom": {
            "registry": "npm",
            "specifier": "^19",
            "strategy": "caret",
        },
        "@vitejs/plugin-react": {
            "registry": "npm",
            "specifier": "latest",
            "strategy": "caret",
        },
        "typescript": {
            "registry": "npm",
            "specifier": "^5",
            "strategy": "caret",
        },
        "vite": {
            "registry": "npm",
            "specifier": "^8",
            "strategy": "caret",
        },
        "vitest": {
            "registry": "npm",
            "specifier": "^4",
            "strategy": "caret",
        },
    },
    "storybook_dependencies": {
        "@emotion/react": {
            "registry": "npm",
            "specifier": "^11",
            "strategy": "caret",
        },
        "@emotion/styled": {
            "registry": "npm",
            "specifier": "^11",
            "strategy": "caret",
        },
        "@mui/material": {
            "registry": "npm",
            "specifier": "^9",
            "strategy": "caret",
        },
        "react": {
            "registry": "npm",
            "specifier": "^19",
            "strategy": "caret",
        },
        "react-dom": {
            "registry": "npm",
            "specifier": "^19",
            "strategy": "caret",
        },
    },
    "storybook_dev_dependencies": {
        "@storybook/addon-essentials": {
            "registry": "npm",
            "specifier": "^8",
            "strategy": "caret",
        },
        "@storybook/react": {
            "registry": "npm",
            "specifier": "^8",
            "strategy": "caret",
        },
        "@storybook/react-vite": {
            "registry": "npm",
            "specifier": "^8",
            "strategy": "caret",
        },
        "@types/react": {
            "registry": "npm",
            "specifier": "^19",
            "strategy": "caret",
        },
        "@types/react-dom": {
            "registry": "npm",
            "specifier": "^19",
            "strategy": "caret",
        },
        "storybook": {
            "registry": "npm",
            "specifier": "^8",
            "strategy": "caret",
        },
        "typescript": {
            "registry": "npm",
            "specifier": "^5",
            "strategy": "caret",
        },
        "vite": {
            "registry": "npm",
            "specifier": "^8",
            "strategy": "caret",
        },
        "vitest": {
            "registry": "npm",
            "specifier": "^4",
            "strategy": "caret",
        },
    },
    "domain_runtime_dependencies": {
        "sqlmodel": {
            "registry": "pypi",
            "specifier": "sqlmodel",
            "strategy": "minimum",
        },
        "httpx": {
            "registry": "pypi",
            "specifier": "httpx",
            "strategy": "minimum",
        },
        "dependency-injector": {
            "registry": "pypi",
            "specifier": "dependency-injector",
            "strategy": "minimum",
        },
        "pydantic": {
            "registry": "pypi",
            "specifier": "pydantic",
            "strategy": "minimum",
        },
        "pydantic-settings": {
            "registry": "pypi",
            "specifier": "pydantic-settings",
            "strategy": "minimum",
        },
        "asyncpg": {
            "registry": "pypi",
            "specifier": "asyncpg",
            "strategy": "minimum",
        },
    },
    "domain_migration_dependencies": {
        "alembic": {
            "registry": "pypi",
            "specifier": "alembic",
            "strategy": "minimum",
        }
    },
    "api_runtime_base_dependencies": {
        "fastapi": {
            "registry": "pypi",
            "specifier": "fastapi>=0.115",
            "strategy": "minimum",
            "package": "fastapi",
        },
        "uvicorn[standard]": {
            "registry": "pypi",
            "specifier": "uvicorn[standard]>=0.34",
            "strategy": "minimum",
            "package": "uvicorn",
        },
    },
    "engine": {
        "pyo3": {
            "registry": "cratesio",
            "specifier": "0.28",
            "strategy": "exact",
        },
        "maturin": {
            "registry": "pypi",
            "specifier": "maturin>=1.8.2,<2.0",
            "strategy": "major-range",
        },
    },
}