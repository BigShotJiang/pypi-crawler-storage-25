from __future__ import annotations

import json
import tomllib
from pathlib import Path

from rpr.checks.base import CheckResult


def check_workspace(project_dir: Path) -> list[CheckResult]:
    results: list[CheckResult] = []

    # NX workspace
    nx_json = project_dir / "nx.json"
    nx_data: dict[str, object] = {}
    nx_ok = False
    nx_cloud_disabled = False
    if nx_json.exists():
        try:
            nx_data = json.loads(nx_json.read_text())
            nx_ok = True
            nx_cloud_disabled = nx_data.get("neverConnectToCloud") is True
        except (OSError, json.JSONDecodeError):
            nx_ok = False

    results.append(
        CheckResult(
            group="Workspace",
            area="NX workspace",
            status=nx_ok,
            path=str(nx_json) if nx_ok else "nx.json missing",
            suggestion="rpr init <name>",
        )
    )
    results.append(
        CheckResult(
            group="Workspace",
            area="NX Cloud disabled",
            status=nx_cloud_disabled,
            path=str(nx_json)
            if nx_cloud_disabled
            else "nx.json missing neverConnectToCloud=true",
            suggestion="rpr init <name>",
        )
    )

    # UV workspace
    pyproject = project_dir / "pyproject.toml"
    pyproject_data: dict[str, object] = {}
    uv_ok = False
    if pyproject.exists():
        try:
            pyproject_data = tomllib.loads(pyproject.read_text())
            tool = pyproject_data.get("tool", {})
            uv_ok = "uv" in tool and "workspace" in tool["uv"]
        except (OSError, tomllib.TOMLDecodeError):
            uv_ok = False

    results.append(
        CheckResult(
            group="Workspace",
            area="UV workspace",
            status=uv_ok,
            path=str(pyproject)
            if uv_ok
            else "pyproject.toml with [tool.uv.workspace] missing",
            suggestion="rpr init <name>",
        )
    )

    tool = pyproject_data.get("tool", {}) if pyproject_data else {}
    uv_require_version = False
    pytest_config = False
    dev_dependencies_ok = False
    if tool:
        uv_require_version = "required-version" in tool.get("uv", {})
        pytest_config = "pytest" in tool and "ini_options" in tool["pytest"]

    dependency_groups = pyproject_data.get("dependency-groups", {}) if pyproject_data else {}
    dev_dependencies = dependency_groups.get("dev", []) if isinstance(dependency_groups, dict) else []
    if isinstance(dev_dependencies, list):
        required = {
            "pytest",
            "pytest-asyncio",
            "pytest-cov",
            "ipykernel",
            "pre-commit",
            "pyright",
            "ruff",
            "maturin",
        }
        dev_dependencies_ok = required.issubset(set(dev_dependencies))

    results.append(
        CheckResult(
            group="Workspace",
            area="Root Python tooling",
            status=uv_require_version and pytest_config and dev_dependencies_ok,
            path=str(pyproject)
            if uv_require_version and pytest_config and dev_dependencies_ok
            else "pyproject.toml missing guide-aligned UV/Python sections",
            suggestion="rpr init <name>",
        )
    )

    package_json = project_dir / "package.json"
    node_workspace_ok = False
    if package_json.exists():
        try:
            package_data = json.loads(package_json.read_text())
            workspaces = package_data.get("workspaces", [])
            node_workspace_ok = isinstance(workspaces, list) and {
                "apps/*",
                "packages/node/*",
            }.issubset(set(workspaces))
        except (OSError, json.JSONDecodeError):
            node_workspace_ok = False

    results.append(
        CheckResult(
            group="Workspace",
            area="Node workspace",
            status=node_workspace_ok,
            path=str(package_json)
            if node_workspace_ok
            else "package.json missing npm workspaces",
            suggestion="rpr init <name>",
        )
    )

    pre_commit = project_dir / ".pre-commit-config.yaml"
    pre_commit_ok = False
    if pre_commit.exists():
        content = pre_commit.read_text()
        pre_commit_ok = all(
            needle in content
            for needle in (
                "pre-commit-hooks",
                "nbstripout",
                "uv run ruff format",
                "uv run ruff check --fix",
                "npx nx run-many --target=lint --all --fix --exclude=engine",
            )
        )

    results.append(
        CheckResult(
            group="Workspace",
            area="Pre-commit config",
            status=pre_commit_ok,
            path=str(pre_commit)
            if pre_commit_ok
            else ".pre-commit-config.yaml missing guide-aligned hooks",
            suggestion="rpr init <name>",
        )
    )

    # .rpr.yaml
    rpr_yaml = project_dir / ".rpr.yaml"
    results.append(
        CheckResult(
            group="Workspace",
            area=".rpr.yaml config",
            status=rpr_yaml.exists(),
            path=str(rpr_yaml) if rpr_yaml.exists() else ".rpr.yaml missing",
            suggestion="rpr init <name>",
        )
    )

    return results
