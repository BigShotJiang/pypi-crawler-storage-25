from __future__ import annotations

import json
import subprocess
from pathlib import Path

from rich.console import Console
from typer.testing import CliRunner

from rpr.cli import app
from rpr.dependencies import api_runtime_dependencies


runner = CliRunner()


def _completed(cmd: list[str]) -> subprocess.CompletedProcess[str]:
    return subprocess.CompletedProcess(cmd, 0, stdout="", stderr="")


def _write_root_pyproject() -> None:
    Path("pyproject.toml").write_text(
        """[project]
name = "workspace"
version = "0.0.0"
requires-python = ">=3.12"
dependencies = []

[tool.uv.workspace]
members = []
"""
    )


def test_generate_api_scaffolds_src_layout_tests_and_build_target(monkeypatch):
    recorded_calls: list[tuple[list[str], Path | str | None]] = []

    def fake_run_command(
        self, cmd, *, cwd=None, env=None, capture=False, supports_dry_run=False
    ):
        recorded_calls.append((cmd, cwd))
        return _completed(cmd)

    monkeypatch.setattr("rpr.context.RunContext.run_command", fake_run_command)

    with runner.isolated_filesystem():
        _write_root_pyproject()

        result = runner.invoke(app, ["generate", "api", "my-app"])
        assert result.exit_code == 0, result.stdout

        api_root = Path("apps/my-app-api")
        src_root = api_root / "src" / "my_app_api"
        tests_root = api_root / "tests"

        assert api_root.exists()
        assert (src_root / "main.py").exists()
        assert (src_root / "routes" / "health.py").exists()
        assert (src_root / "__init__.py").exists()
        assert (src_root / "routes" / "__init__.py").exists()
        assert (tests_root / "test_health.py").exists()
        assert (api_root / "README.md").read_text().startswith("# my-app API")

        pyproject = (api_root / "pyproject.toml").read_text()
        project = json.loads((api_root / "project.json").read_text())
        main = (src_root / "main.py").read_text()
        health_test = (tests_root / "test_health.py").read_text()
        root_pyproject = Path("pyproject.toml").read_text()

        assert 'packages = ["src/my_app_api"]' in pyproject
        assert 'readme = "README.md"' in pyproject
        assert '[tool.pytest.ini_options]' in pyproject
        assert 'testpaths = ["tests"]' in pyproject
        assert project["name"] == "my-app-api"
        assert project["targets"]["build"]["options"]["command"] == "uv build"
        assert (
            project["targets"]["serve"]["options"]["command"]
            == "uv run uvicorn my_app_api.main:app --reload --host 0.0.0.0 --port 8000"
        )
        assert "config.logging" not in main
        assert "CORSMiddleware" not in main
        assert "from my_app_api.routes.health import health_check" in health_test
        assert 'members = ["apps/my-app-api"]' in root_pyproject
        assert recorded_calls == [(["uv", "sync"], Path.cwd())]


def test_generate_api_dry_run_previews_src_layout(monkeypatch, capsys):
    monkeypatch.setattr(
        "rpr.context.console", Console(highlight=False, no_color=True), raising=False
    )
    monkeypatch.setattr(
        "rpr.commands.generate.api.console", Console(highlight=False, no_color=True)
    )
    monkeypatch.setattr(
        "rpr.workspace.console", Console(highlight=False, no_color=True)
    )

    with runner.isolated_filesystem():
        _write_root_pyproject()

        result = runner.invoke(app, ["generate", "api", "my-app", "--dry-run"])
        assert result.exit_code == 0, result.stdout

        output = result.stdout + capsys.readouterr().out

        assert "DRY RUN" in output
        assert "apps/my-app-api/src/my_app_api/routes" in output
        assert "apps/my-app-api/tests" in output
        assert "apps/my-app-api/project.json" in output
        assert "Would add 'apps/my-app-api' to workspace members" in output
        assert "Would install uv dependencies for apps/my-app-api" in output
        assert f"runtime=[{', '.join(api_runtime_dependencies('my-app'))}]" in output
        assert not Path("apps").exists()
        assert 'members = []' in Path("pyproject.toml").read_text()