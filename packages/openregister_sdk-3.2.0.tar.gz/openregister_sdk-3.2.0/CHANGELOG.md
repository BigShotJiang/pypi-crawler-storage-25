# Changelog

## 3.2.0 (2026-04-11)

Full Changelog: [v3.1.1...v3.2.0](https://github.com/oregister/openregister-python/compare/v3.1.1...v3.2.0)

### Features

* **api:** add lei ([1f29206](https://github.com/oregister/openregister-python/commit/1f29206f95c4bd3ce66025fa1978ee407c0c30e5))


### Bug Fixes

* ensure file data are only sent as 1 parameter ([a3a8259](https://github.com/oregister/openregister-python/commit/a3a82590fc8393190ffd5157b518c999c1559520))

## 3.1.1 (2026-04-08)

Full Changelog: [v3.1.0...v3.1.1](https://github.com/oregister/openregister-python/compare/v3.1.0...v3.1.1)

### Bug Fixes

* **client:** preserve hardcoded query params when merging with user params ([fa40ea6](https://github.com/oregister/openregister-python/commit/fa40ea6bd6af4dfe19c55e67a2dbb0c51098bc6e))


### Chores

* **client:** increase timeouts ([61f64e6](https://github.com/oregister/openregister-python/commit/61f64e689752e125cf887e8c5c0bd11ccc9c3843))

## 3.1.0 (2026-03-27)

Full Changelog: [v3.0.3...v3.1.0](https://github.com/oregister/openregister-python/compare/v3.0.3...v3.1.0)

### Features

* **api:** monitoring endpoints ([2051511](https://github.com/oregister/openregister-python/commit/205151139e0f27c8d731890a0341276bedcddb8d))
* **internal:** implement indices array format for query and form serialization ([87468c0](https://github.com/oregister/openregister-python/commit/87468c0ba7e8be29d701bf25fa6c1d3606d85446))


### Bug Fixes

* **deps:** bump minimum typing-extensions version ([2f29556](https://github.com/oregister/openregister-python/commit/2f29556e998619b9a3118e8ed73a648a93a12860))
* **pydantic:** do not pass `by_alias` unless set ([3027dda](https://github.com/oregister/openregister-python/commit/3027dda1781ce25e428551cb4cbdd4f9b6efddc8))
* sanitize endpoint path params ([924be9b](https://github.com/oregister/openregister-python/commit/924be9b09c0ee804aa934b3615db0c6089d2e224))


### Chores

* **ci:** skip lint on metadata-only changes ([f053a64](https://github.com/oregister/openregister-python/commit/f053a64334e4de4eea8ed8d7977b679b8c8fe019))
* **internal:** tweak CI branches ([4b0ff82](https://github.com/oregister/openregister-python/commit/4b0ff8267fd4ba3b0c6990d87fdd87b7fc1c3fa4))
* **internal:** update gitignore ([26e53e0](https://github.com/oregister/openregister-python/commit/26e53e088b1e334b1adfc6baa54a997831f9ba84))

## 3.0.3 (2026-03-12)

Full Changelog: [v3.0.2...v3.0.3](https://github.com/oregister/openregister-python/compare/v3.0.2...v3.0.3)

### Bug Fixes

* **api:** historical owners v1 ([fd459a8](https://github.com/oregister/openregister-python/commit/fd459a804464fe932843b277822b2cae1a729e97))
* **api:** owner historical v1 ([cf06b44](https://github.com/oregister/openregister-python/commit/cf06b44b5a70cf5a496fd88de4f30ac66a4a052c))

## 3.0.2 (2026-03-11)

Full Changelog: [v3.0.1...v3.0.2](https://github.com/oregister/openregister-python/compare/v3.0.1...v3.0.2)

### Bug Fixes

* **api:** adjust historical owner ids ([182f808](https://github.com/oregister/openregister-python/commit/182f808f18e0237984f95869bd3f12c30cdbbdf3))

## 3.0.1 (2026-03-10)

Full Changelog: [v3.0.0...v3.0.1](https://github.com/oregister/openregister-python/compare/v3.0.0...v3.0.1)

## 3.0.0 (2026-03-10)

Full Changelog: [v2.4.2...v3.0.0](https://github.com/oregister/openregister-python/compare/v2.4.2...v3.0.0)

### ⚠ BREAKING CHANGES

* deprecate v0 document & shareholder endpoint

### Features

* **api:** additional static models ([369c641](https://github.com/oregister/openregister-python/commit/369c6410cc451a418f1fb9eaa5f9aff397053409))
* **company:** enable filtering by business purpose ([f3769ac](https://github.com/oregister/openregister-python/commit/f3769acdd1b227d8d050611c910ddf4911a36e64))
* deprecate v0 document & shareholder endpoint ([a50df4a](https://github.com/oregister/openregister-python/commit/a50df4a5a9e458a1d49c2a0388b92f071fca50ae))
* **v0:** add historical owners endpoint ([ecfa4d7](https://github.com/oregister/openregister-python/commit/ecfa4d7d8181e36df9fede04455bc4c2be07fe8e))
* **v0:** remove cached document endpoints ([ddeba62](https://github.com/oregister/openregister-python/commit/ddeba625c0712cf220c83fbfe16951d750a46b13))


### Chores

* **ci:** skip uploading artifacts on stainless-internal branches ([ea86a06](https://github.com/oregister/openregister-python/commit/ea86a06072e7edafbd48d55d00fc346f99b329a1))
* **python:** shadowing pydantic property ([6a22730](https://github.com/oregister/openregister-python/commit/6a22730042b6d6d4c4d6db77ec33f77202d0cd7f))
* remove breaking company model ([77fb61b](https://github.com/oregister/openregister-python/commit/77fb61b1dbfac8deff1fb2ddcca437a27807a950))

## 2.4.2 (2026-02-25)

Full Changelog: [v2.4.1...v2.4.2](https://github.com/oregister/openregister-python/compare/v2.4.1...v2.4.2)

### Chores

* **internal:** add request options to SSE classes ([58bbc1d](https://github.com/oregister/openregister-python/commit/58bbc1d08545824b48d1b70a1bb13f44c32ebc18))
* **internal:** make `test_proxy_environment_variables` more resilient ([383f20e](https://github.com/oregister/openregister-python/commit/383f20e8ad296383157e87b5f7106e14b0496f80))
* **internal:** make `test_proxy_environment_variables` more resilient to env ([9ca7a33](https://github.com/oregister/openregister-python/commit/9ca7a339458bbd05380755a5fe0b64a5a0713353))
* **internal:** remove mock server code ([507c9e2](https://github.com/oregister/openregister-python/commit/507c9e2437fe0bed58c8109ee9622835ddada0de))
* update mock server docs ([7d619fc](https://github.com/oregister/openregister-python/commit/7d619fce04548efd1304a51d45f6765b2847579f))

## 2.4.1 (2026-02-13)

Full Changelog: [v2.4.0...v2.4.1](https://github.com/oregister/openregister-python/compare/v2.4.0...v2.4.1)

### Chores

* format all `api.md` files ([3887982](https://github.com/oregister/openregister-python/commit/3887982f272467f9ff4cfc3b48de84c6a87684ca))
* **internal:** bump dependencies ([4f5b910](https://github.com/oregister/openregister-python/commit/4f5b9108c023b4b0aa51d0304864a8e64286c36d))
* **internal:** fix lint error on Python 3.14 ([e0b9cb6](https://github.com/oregister/openregister-python/commit/e0b9cb621c5b154540383136b54f773c3ffd2d7b))

## 2.4.0 (2026-01-30)

Full Changelog: [v2.3.0...v2.4.0](https://github.com/oregister/openregister-python/compare/v2.3.0...v2.4.0)

### Features

* **client:** add custom JSON encoder for extended type support ([2079416](https://github.com/oregister/openregister-python/commit/20794167b70ca1c47709afb5695507a48eb583eb))


### Bug Fixes

* **docs:** fix mcp installation instructions for remote servers ([aa6fc21](https://github.com/oregister/openregister-python/commit/aa6fc210fe312d012f219916b75c61ca7116180a))

## 2.3.0 (2026-01-24)

Full Changelog: [v2.2.0...v2.3.0](https://github.com/oregister/openregister-python/compare/v2.2.0...v2.3.0)

### Features

* **client:** add support for binary request streaming ([6183e0b](https://github.com/oregister/openregister-python/commit/6183e0bbaef8e431fc3fb4f53e0d6faf863eec35))


### Bug Fixes

* ensure streams are always closed ([7f85ea5](https://github.com/oregister/openregister-python/commit/7f85ea5fd98ed4735ea637ecabb216c828d659b8))
* **types:** allow pyright to infer TypedDict types within SequenceNotStr ([34ae2ce](https://github.com/oregister/openregister-python/commit/34ae2ceb1f20470ae2c63090ea62a21c8da3ad68))
* use async_to_httpx_files in patch method ([74330b0](https://github.com/oregister/openregister-python/commit/74330b03407211e4131dbaff1d81339533930247))


### Chores

* add missing docstrings ([d245a38](https://github.com/oregister/openregister-python/commit/d245a382f57c6a44141a1e20aac64dbc236ca532))
* **ci:** upgrade `actions/github-script` ([bace3b7](https://github.com/oregister/openregister-python/commit/bace3b7a63f89951b8d8938507dd54edb973abd7))
* **deps:** mypy 1.18.1 has a regression, pin to 1.17 ([95f5cfc](https://github.com/oregister/openregister-python/commit/95f5cfc63d1cffaf9f6273bb572e11cc0229ad11))
* **docs:** use environment variables for authentication in code snippets ([0215d19](https://github.com/oregister/openregister-python/commit/0215d1980cc9ab77d5e34e0250657fc2d71ea1fc))
* **internal:** add `--fix` argument to lint script ([7b78f42](https://github.com/oregister/openregister-python/commit/7b78f42187777c26ddc5d32435075a0cdfa92d09))
* **internal:** add missing files argument to base client ([42842cb](https://github.com/oregister/openregister-python/commit/42842cb64f87eadce9b53a3f9c419232a2cb6669))
* **internal:** codegen related update ([d134c9a](https://github.com/oregister/openregister-python/commit/d134c9a96d0f35891b4d9f167435c17156fd4dbe))
* **internal:** update `actions/checkout` version ([4bd7c8e](https://github.com/oregister/openregister-python/commit/4bd7c8e1705aa39d70ba2762b3891f8c77855006))
* speedup initial import ([8123b1f](https://github.com/oregister/openregister-python/commit/8123b1f95a1b68e3253f0ff018d839e70e0975c6))
* update lockfile ([76d9210](https://github.com/oregister/openregister-python/commit/76d9210837cab647b31632a92a401c8d675c18ae))


### Documentation

* prominently feature MCP server setup in root SDK readmes ([dd8660a](https://github.com/oregister/openregister-python/commit/dd8660a576462b8a34d663deab9081475b9788d7))

## 2.2.0 (2025-11-22)

Full Changelog: [v2.1.0...v2.2.0](https://github.com/oregister/openregister-python/compare/v2.1.0...v2.2.0)

### Features

* **api:** manual updates ([f107d15](https://github.com/oregister/openregister-python/commit/f107d158125427489a971407d273a1708a89aca9))
* **api:** manual updates ([8384197](https://github.com/oregister/openregister-python/commit/838419707fd3ca4902d60f8d1cdad7512b782bfb))


### Bug Fixes

* **client:** close streams without requiring full consumption ([7f40099](https://github.com/oregister/openregister-python/commit/7f40099357b2d03da08a78b59138deac4a1fd1d5))
* compat with Python 3.14 ([d67c71e](https://github.com/oregister/openregister-python/commit/d67c71ec567dd379440760aa7c4fb2b7ceec73bc))
* **compat:** update signatures of `model_dump` and `model_dump_json` for Pydantic v1 ([396883e](https://github.com/oregister/openregister-python/commit/396883e7a3f1f369c40d4588780eb7421cbfeac1))


### Chores

* add Python 3.14 classifier and testing ([b447b14](https://github.com/oregister/openregister-python/commit/b447b145a261b56b5bd4c58cca96b405d5052261))
* bump `httpx-aiohttp` version to 0.1.9 ([ae5a654](https://github.com/oregister/openregister-python/commit/ae5a654b9dd074e447d1c2ae2403be9d95b78f93))
* **internal/tests:** avoid race condition with implicit client cleanup ([6e59ab8](https://github.com/oregister/openregister-python/commit/6e59ab80766a10856eb4daa94a11967332bcaf75))
* **internal:** detect missing future annotations with ruff ([9cf1eae](https://github.com/oregister/openregister-python/commit/9cf1eaef736ab58602791ae341dc9f1a0e31fd8f))
* **internal:** grammar fix (it's -&gt; its) ([bf06331](https://github.com/oregister/openregister-python/commit/bf0633157ecd498c2eb5d81087a3a6b10beb2ef6))
* **package:** drop Python 3.8 support ([32ed4ca](https://github.com/oregister/openregister-python/commit/32ed4ca3462c941c2068c953f72273457146fc7b))

## 2.1.0 (2025-10-02)

Full Changelog: [v2.0.3...v2.1.0](https://github.com/oregister/openregister-python/compare/v2.0.3...v2.1.0)

### Features

* **api:** add contact information ([e6de0a0](https://github.com/oregister/openregister-python/commit/e6de0a0090adeb46fc81af314c859afcb3fb418e))


### Bug Fixes

* **api:** merged reports ([8ea7720](https://github.com/oregister/openregister-python/commit/8ea77203c1b0c077ee93a9ec2177d63ef1c1f980))


### Chores

* do not install brew dependencies in ./scripts/bootstrap by default ([b9f2864](https://github.com/oregister/openregister-python/commit/b9f286485c71c1ff6e373b4680a7b59f8339bff2))
* **internal:** update pydantic dependency ([843ceae](https://github.com/oregister/openregister-python/commit/843ceae88a724c05047e0f08d92a2541a965c63a))
* **types:** change optional parameter type from NotGiven to Omit ([bcde93c](https://github.com/oregister/openregister-python/commit/bcde93caa39bcfbe3d894fd747c2cf763e21b1c0))

## 2.0.3 (2025-09-16)

Full Changelog: [v2.0.2...v2.0.3](https://github.com/oregister/openregister-python/compare/v2.0.2...v2.0.3)

### Features

* improve future compat with pydantic v3 ([f9c8857](https://github.com/oregister/openregister-python/commit/f9c8857b8a7d3ec739c721ec1b86cf3ff7e99327))
* **types:** replace List[str] with SequenceNotStr in params ([a26f258](https://github.com/oregister/openregister-python/commit/a26f258aaf652f9e261cf1120d29707c4825a5c4))


### Chores

* **internal:** add Sequence related utils ([b806f7f](https://github.com/oregister/openregister-python/commit/b806f7fc451e6619b76c45a89a282fd62fa2f979))
* **internal:** move mypy configurations to `pyproject.toml` file ([58cda42](https://github.com/oregister/openregister-python/commit/58cda426d8992da9ffefee2d699a339fbe3dd244))
* **tests:** simplify `get_platform` test ([9e03245](https://github.com/oregister/openregister-python/commit/9e0324599f45b2ae3c77d8a960ad595876c99fad))

## 2.0.2 (2025-08-29)

Full Changelog: [v2.0.1...v2.0.2](https://github.com/oregister/openregister-python/compare/v2.0.1...v2.0.2)

### Features

* **api:** update via SDK Studio ([3ba7dc8](https://github.com/oregister/openregister-python/commit/3ba7dc8528b37281efe333440af217b38ab4e461))

## 2.0.1 (2025-08-27)

Full Changelog: [v2.0.0...v2.0.1](https://github.com/oregister/openregister-python/compare/v2.0.0...v2.0.1)

### Features

* **api:** update via SDK Studio ([e07e919](https://github.com/oregister/openregister-python/commit/e07e919df6f9cc55e84966c41fe5e97d6d3d33d8))

## 2.0.0 (2025-08-27)

Full Changelog: [v1.9.0...v2.0.0](https://github.com/oregister/openregister-python/compare/v1.9.0...v2.0.0)

### Features

* **api:** update via SDK Studio ([5d401f3](https://github.com/oregister/openregister-python/commit/5d401f3fcfa0f6d6299368c8378c0be0743bb61e))
* **api:** update via SDK Studio ([261d645](https://github.com/oregister/openregister-python/commit/261d645f86335f36508acdce8496c1a1724c671c))
* **api:** update via SDK Studio ([9b13649](https://github.com/oregister/openregister-python/commit/9b13649467d2af86d3f1b7d50136c2a1cd7b170a))
* **api:** update via SDK Studio ([9032270](https://github.com/oregister/openregister-python/commit/903227015014375275d75e39fa7bf26e12df913f))
* **api:** update via SDK Studio ([ce52903](https://github.com/oregister/openregister-python/commit/ce52903f7e700cce88badb9c10eb0e6bc1af2585))
* **api:** update via SDK Studio ([c81c348](https://github.com/oregister/openregister-python/commit/c81c3488f8cdc47267c44a537677ea7edf205636))
* **api:** update via SDK Studio ([dc2b269](https://github.com/oregister/openregister-python/commit/dc2b26910c35f2cd508419253b1edd8faf4cafa9))


### Bug Fixes

* avoid newer type syntax ([c915b56](https://github.com/oregister/openregister-python/commit/c915b56b77157bb318251453d99db6aff168567e))


### Chores

* **internal:** change ci workflow machines ([db54687](https://github.com/oregister/openregister-python/commit/db54687f32f3c3710ab35b07ab85ce9a9c44cf12))
* **internal:** codegen related update ([5577d7e](https://github.com/oregister/openregister-python/commit/5577d7e156e5b818bd55d4e7b0ca59b116f345ae))
* **internal:** update comment in script ([c7fa138](https://github.com/oregister/openregister-python/commit/c7fa138dfa34a9a6269e50095420968041a8bbfc))
* **internal:** update pyright exclude list ([c1711d8](https://github.com/oregister/openregister-python/commit/c1711d867091a65cd9ee0943f83231aa69ab958b))
* update @stainless-api/prism-cli to v5.15.0 ([520709f](https://github.com/oregister/openregister-python/commit/520709f322b504f2d9a791df88987c85c1432550))
* update github action ([ee9e48a](https://github.com/oregister/openregister-python/commit/ee9e48aee56d5e602731a640578be89e8db25575))

## 1.9.0 (2025-08-06)

Full Changelog: [v1.8.0...v1.9.0](https://github.com/oregister/openregister-python/compare/v1.8.0...v1.9.0)

### Features

* **api:** update via SDK Studio ([a4bf32c](https://github.com/oregister/openregister-python/commit/a4bf32c5fc79bcb66069f1b27210af288beabd62))
* **api:** update via SDK Studio ([1ec1aea](https://github.com/oregister/openregister-python/commit/1ec1aeaf67bc192c6d59f5da9ba610f194f5e68b))
* **api:** update via SDK Studio ([cf8f581](https://github.com/oregister/openregister-python/commit/cf8f581da7dd8d8a1ce7189d5c5f535bffbb66e1))
* **api:** update via SDK Studio ([84588e0](https://github.com/oregister/openregister-python/commit/84588e06407a13cd5e43ec44824816c3da4251a4))
* **api:** update via SDK Studio ([5db6aee](https://github.com/oregister/openregister-python/commit/5db6aee2413a147c921de855f14ad3aada1166a8))
* **api:** update via SDK Studio ([f198922](https://github.com/oregister/openregister-python/commit/f1989229e8ea7894798f65b0d589eee7ac33354d))
* **api:** update via SDK Studio ([06c08d9](https://github.com/oregister/openregister-python/commit/06c08d985d4e7d1bf3d36b2091cf338123daeadb))
* **api:** update via SDK Studio ([c5b173a](https://github.com/oregister/openregister-python/commit/c5b173ac6a367a26986af381af3e5d884b42e666))
* **api:** update via SDK Studio ([53906ff](https://github.com/oregister/openregister-python/commit/53906ff16b8026e3d5a7fbc08bfe057db4ff7872))
* **api:** update via SDK Studio ([c469032](https://github.com/oregister/openregister-python/commit/c469032eb5f8b79cb9f86a2952746d704d5b5505))
* **api:** update via SDK Studio ([27022b3](https://github.com/oregister/openregister-python/commit/27022b3a0258c804371ac67010b9412cdbb3afc5))
* **api:** update via SDK Studio ([bb35bb3](https://github.com/oregister/openregister-python/commit/bb35bb32569dac1383c39835d37276944ba9c126))
* **api:** update via SDK Studio ([92868ee](https://github.com/oregister/openregister-python/commit/92868ee2ada5caec8d4d34d5009b1ffc7eae69d9))
* **api:** update via SDK Studio ([66fbcba](https://github.com/oregister/openregister-python/commit/66fbcba8e46e91e33132d9192e976a74a640f4f5))
* **api:** update via SDK Studio ([9b0b338](https://github.com/oregister/openregister-python/commit/9b0b338fde913eedcf567d9fc31a4c10acd6a12c))
* **api:** update via SDK Studio ([694db14](https://github.com/oregister/openregister-python/commit/694db143faec9f941510eb444dec62f85a83380a))
* **api:** update via SDK Studio ([3ccd737](https://github.com/oregister/openregister-python/commit/3ccd7372ad292a8219c44348e68f1774266d6dd6))
* **client:** support file upload requests ([e6b74b6](https://github.com/oregister/openregister-python/commit/e6b74b6c483a40445756ae5f27d718bb89a981e0))


### Chores

* **internal:** fix ruff target version ([baabfb9](https://github.com/oregister/openregister-python/commit/baabfb90b8d74d273f454996fda5006c89fa6fb1))
* **project:** add settings file for vscode ([beec64e](https://github.com/oregister/openregister-python/commit/beec64e01b9203a412f0874bc7d0224ec19e7b51))

## 1.8.0 (2025-07-23)

Full Changelog: [v1.7.0...v1.8.0](https://github.com/oregister/openregister-python/compare/v1.7.0...v1.8.0)

### Features

* **api:** update via SDK Studio ([069557d](https://github.com/oregister/openregister-python/commit/069557d8c97aa7d86c04120827d820b6163dd00a))
* clean up environment call outs ([23dba14](https://github.com/oregister/openregister-python/commit/23dba14b5be47e714812d0494f6f26bfde98fc6b))


### Bug Fixes

* **ci:** correct conditional ([aa5d0f7](https://github.com/oregister/openregister-python/commit/aa5d0f7e44ffaa3d8ee126c7a4fdedb3a88b85a4))
* **ci:** release-doctor — report correct token name ([94cd33d](https://github.com/oregister/openregister-python/commit/94cd33d48fb18b37ab30934561e533b3527c4f50))
* **client:** don't send Content-Type header on GET requests ([9a7b671](https://github.com/oregister/openregister-python/commit/9a7b6712e647c532c4bc3ed6c30d465c76e5172f))
* **parsing:** correctly handle nested discriminated unions ([c55746e](https://github.com/oregister/openregister-python/commit/c55746e6fa20a4b2a6c300a1e4d36993cbef30fc))
* **parsing:** ignore empty metadata ([3cb44b2](https://github.com/oregister/openregister-python/commit/3cb44b2fe7d306a7ade540449d81b420ab671535))
* **parsing:** parse extra field types ([6a7c90d](https://github.com/oregister/openregister-python/commit/6a7c90dcad29c2355d3a7e507aec80db915e6e84))


### Chores

* **ci:** change upload type ([d59202c](https://github.com/oregister/openregister-python/commit/d59202cb676ce4f7c42d6bdf369d973623855ddb))
* **ci:** only run for pushes and fork pull requests ([0b8d5eb](https://github.com/oregister/openregister-python/commit/0b8d5eb3e8bfc8774e322e6b0e6de710ca3f6878))
* **internal:** bump pinned h11 dep ([2f5a623](https://github.com/oregister/openregister-python/commit/2f5a62376dcc28ed73f5c1b7051afdf6d8231ec1))
* **internal:** codegen related update ([e8a7972](https://github.com/oregister/openregister-python/commit/e8a79726219df809f3b750ce828b052d0f7bca36))
* **package:** mark python 3.13 as supported ([1cceac5](https://github.com/oregister/openregister-python/commit/1cceac5170f4fcca5614f1c2e8126ca46e579373))
* **readme:** fix version rendering on pypi ([1239f10](https://github.com/oregister/openregister-python/commit/1239f10f72aae84b60488b287bd38997d8510a88))

## 1.7.0 (2025-06-24)

Full Changelog: [v1.6.0...v1.7.0](https://github.com/oregister/openregister-python/compare/v1.6.0...v1.7.0)

### Features

* **api:** update via SDK Studio ([dbc7813](https://github.com/oregister/openregister-python/commit/dbc7813839a3563e3d4e74abdf366104ca9487fe))

## 1.6.0 (2025-06-24)

Full Changelog: [v1.5.0...v1.6.0](https://github.com/oregister/openregister-python/compare/v1.5.0...v1.6.0)

### Features

* **api:** update via SDK Studio ([ba142a6](https://github.com/oregister/openregister-python/commit/ba142a6ecc663b673b65deeb6d89e9a8c169155e))
* **api:** update via SDK Studio ([0bd9e3c](https://github.com/oregister/openregister-python/commit/0bd9e3c3deb69a9713ace31371d998f03e503fca))
* **client:** add support for aiohttp ([7edb08a](https://github.com/oregister/openregister-python/commit/7edb08a37f1d0d5df0cd3de806a5406efe857d98))


### Chores

* **tests:** skip some failing tests on the latest python versions ([8d990dd](https://github.com/oregister/openregister-python/commit/8d990dd5dd4f3e8a9a3e01989f7b59a68021f709))

## 1.5.0 (2025-06-20)

Full Changelog: [v1.4.0...v1.5.0](https://github.com/oregister/openregister-python/compare/v1.4.0...v1.5.0)

### Features

* **api:** update via SDK Studio ([4eac8c2](https://github.com/oregister/openregister-python/commit/4eac8c2d786342ab445c9b062a9dc97a997e6d40))

## 1.4.0 (2025-06-20)

Full Changelog: [v1.3.0...v1.4.0](https://github.com/oregister/openregister-python/compare/v1.3.0...v1.4.0)

### Features

* **api:** update via SDK Studio ([c1f7f0b](https://github.com/oregister/openregister-python/commit/c1f7f0bb504bec37a98c229182987eb74cdf7732))
* **api:** update via SDK Studio ([29e115d](https://github.com/oregister/openregister-python/commit/29e115d98dd34e7f2320406e3d71fe9a4c5f34d1))


### Bug Fixes

* **client:** correctly parse binary response | stream ([3178a60](https://github.com/oregister/openregister-python/commit/3178a608d0bea505c36ee0dd53beef0b9637d3e2))
* **tests:** fix: tests which call HTTP endpoints directly with the example parameters ([9ff0d2d](https://github.com/oregister/openregister-python/commit/9ff0d2d45e64f8decc4d4f27f552b92fade72818))


### Chores

* **ci:** enable for pull requests ([2267910](https://github.com/oregister/openregister-python/commit/22679109aeef09c71cbf8297b1540792e9e1238e))
* **internal:** update conftest.py ([3159827](https://github.com/oregister/openregister-python/commit/3159827569407d2abd0a48610ba421cbe8bb1a1f))
* **readme:** update badges ([067d506](https://github.com/oregister/openregister-python/commit/067d5068b7c90cf0285f45e8942c9fd35d12db1a))
* **tests:** add tests for httpx client instantiation & proxies ([933aead](https://github.com/oregister/openregister-python/commit/933aead45e63051438e6d2b7ca22302df1735d3f))
* **tests:** run tests in parallel ([4f120e1](https://github.com/oregister/openregister-python/commit/4f120e11a6c102b6a9e976cb10e780d2d617115a))


### Documentation

* **client:** fix httpx.Timeout documentation reference ([e20479c](https://github.com/oregister/openregister-python/commit/e20479cd0e2e9fd3121713e7f168c503949230aa))

## 1.3.0 (2025-06-09)

Full Changelog: [v1.2.0...v1.3.0](https://github.com/oregister/openregister-python/compare/v1.2.0...v1.3.0)

### Features

* **api:** update via SDK Studio ([50198fb](https://github.com/oregister/openregister-python/commit/50198fb41cbf7c4b93df4fe4c3967126ae0e8b09))
* **api:** update via SDK Studio ([42905b5](https://github.com/oregister/openregister-python/commit/42905b56702cbf59d1ba582f112598fcab4ac435))
* **api:** update via SDK Studio ([ad4e5f4](https://github.com/oregister/openregister-python/commit/ad4e5f4ae5715443f4eddf2e09b2c4137ba89eb9))

## 1.2.0 (2025-06-09)

Full Changelog: [v1.1.0...v1.2.0](https://github.com/oregister/openregister-python/compare/v1.1.0...v1.2.0)

### Features

* **api:** update via SDK Studio ([228c918](https://github.com/oregister/openregister-python/commit/228c918a0281457e4a07ebc56925fa5fb40469e8))

## 1.1.0 (2025-06-07)

Full Changelog: [v1.0.1...v1.1.0](https://github.com/oregister/openregister-python/compare/v1.0.1...v1.1.0)

### Features

* **api:** update via SDK Studio ([87a3573](https://github.com/oregister/openregister-python/commit/87a3573991bc19fadd1c4c92c1d90fab80687c7f))

## 1.0.1 (2025-06-07)

Full Changelog: [v1.0.0...v1.0.1](https://github.com/oregister/openregister-python/compare/v1.0.0...v1.0.1)

### Chores

* **internal:** version bump ([722cc66](https://github.com/oregister/openregister-python/commit/722cc66631a7d16ed42771fcff10b2382c1ee6f1))

## 1.0.0 (2025-06-07)

Full Changelog: [v0.0.1-alpha.0...v1.0.0](https://github.com/oregister/openregister-python/compare/v0.0.1-alpha.0...v1.0.0)

### Features

* **api:** update via SDK Studio ([a018c07](https://github.com/oregister/openregister-python/commit/a018c0797b5296e8029e051d36dda94c909b0128))


### Chores

* configure new SDK language ([82da76d](https://github.com/oregister/openregister-python/commit/82da76d60986b6e1a49752ff77d7616f7e022aab))
* update SDK settings ([b3e38ee](https://github.com/oregister/openregister-python/commit/b3e38ee33379b4d063bef466fcbc69672d266815))
* update SDK settings ([145faf6](https://github.com/oregister/openregister-python/commit/145faf6f39192c044fd30bed4395085af8a487ac))
* update SDK settings ([8c2aa41](https://github.com/oregister/openregister-python/commit/8c2aa412e3660f742e3febc22364937dfb373cc4))
