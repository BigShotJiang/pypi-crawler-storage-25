from datetime import datetime
import json
import requests
from maisaedu_utilities_prefect.dw import get_dsn
from maisaedu_utilities_prefect.database.postgres import connect, execute

def update_authorization_access_token(base_url: str, secret_name: str, credentials: dict) -> dict:
        response = requests.post(
            f"{base_url}/v3/safea/oauth2/token",
            json={
                "client_id": credentials.get("client_id"),
                "client_secret": credentials.get("client_secret"),
                "grant_type": "client_credentials"
            }
        )

        if not response.ok:
            raise Exception(
                f"Failed to obtain access token: "
                f"status={response.status_code}, "
                f"url={response.url}, "
                f"response={response.text}"
            )
        data = response.json()
        credentials['authorization'] = f"Bearer {data.get('access_token')}"
        credentials['expires'] = datetime.now().strftime("%Y-%m-%d")

        conn = connect(get_dsn())

        execute(
            conn,
            f"""
            select * from meta.put_secret('{secret_name}', '{json.dumps(credentials)}');
            """,
        )

        return credentials