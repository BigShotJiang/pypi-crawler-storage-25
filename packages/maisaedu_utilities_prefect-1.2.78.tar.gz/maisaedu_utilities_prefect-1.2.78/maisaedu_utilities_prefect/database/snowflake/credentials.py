import base64
import os

from .params import SnowflakeParams, PROD
from .service import SnowflakeService

SNOWFLAKE_ACCOUNT = "A6020211027671-MAISA"
SNOWFLAKE_USER_PROD = "PREFECT_PROD"
SNOWFLAKE_USER_DEV = "PREFECT_DEV"


_DATA_DIR = os.path.join(os.path.dirname(__file__), "data")


def _get_private_key_path(env: str) -> str:
    filename = "dw-snowflake-prefect-prod.text" if env == PROD else "dw-snowflake-prefect-dev.text"
    return os.path.join(_DATA_DIR, filename)


def _load_private_key_bytes(env: str) -> bytes:
    path = _get_private_key_path(env)
    if not os.path.exists(path):
        raise FileNotFoundError(
            f"Snowflake private key not found at '{path}'. "
            "This file must be placed manually in the 'data/' directory — "
            "it is not stored as a database secret."
        )
    with open(path) as f:
        return base64.b64decode(f.read().strip())


def _resolve_user(env: str, user: str | None) -> str:
    if user is not None:
        return user
    return SNOWFLAKE_USER_PROD if env == PROD else SNOWFLAKE_USER_DEV


def build_snowflake_service(params: SnowflakeParams) -> SnowflakeService:
    return SnowflakeService(
        account=SNOWFLAKE_ACCOUNT,
        user=_resolve_user(params.env, params.user),
        private_key_bytes=_load_private_key_bytes(params.env),
        role=params.role,
        warehouse=params.warehouse,
    )
