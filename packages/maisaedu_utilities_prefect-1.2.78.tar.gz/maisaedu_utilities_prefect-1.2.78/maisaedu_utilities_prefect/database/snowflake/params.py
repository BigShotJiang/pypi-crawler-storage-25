from pydantic import BaseModel

PROD = "prod"


class SnowflakeParams(BaseModel):
    env: str = PROD
    role: str | None = None
    user: str | None = None
    warehouse: str | None = None
