# aethex-axiom-sdk

Python SDK for the **Axiom protocol** — AeThex's core identity and multi-platform verification layer.

## Installation

```bash
pip install aethex-axiom-sdk
```

## Quick Start

```python
import asyncio
from aethex_axiom_sdk import AxiomClient, Platform

async def main():
    async with AxiomClient(token="your-jwt-token") as client:
        # Create an identity
        identity = await client.create_identity("Ada Lovelace")
        print(identity.id)

        # Link a platform handle
        link = await client.link_platform(identity.id, Platform.DISCORD, "ada#0001")

        # Complete verification with OAuth token from Discord
        verified = await client.verify_platform(identity.id, Platform.DISCORD, oauth_token)
        print(verified.verified)  # True

        # Check which platforms are verified
        print(identity.verified_platforms)

        # Protocol health
        status = await client.get_protocol_status()
        print(status.status)  # "operational"

asyncio.run(main())
```

## Supported Platforms

| Constant | Platform |
|---|---|
| `Platform.DISCORD` | Discord |
| `Platform.ROBLOX` | Roblox |
| `Platform.STEAM` | Steam |
| `Platform.XBOX` | Xbox |
| `Platform.EPIC` | Epic Games |
| `Platform.GITHUB` | GitHub |

## API Reference

Full documentation: [https://docs.aethex.tech/axiom-sdk](https://docs.aethex.tech/axiom-sdk)

### AxiomClient

| Method | Description |
|---|---|
| `get_identity(identity_id)` | Fetch an identity by UUID |
| `list_identities(platform?, verified_only?, limit?, offset?)` | List identities with optional filters |
| `create_identity(display_name)` | Create a new Axiom identity |
| `delete_identity(identity_id)` | Permanently delete an identity |
| `link_platform(identity_id, platform, handle)` | Link a platform handle (unverified) |
| `verify_platform(identity_id, platform, token)` | Complete platform verification |
| `unlink_platform(identity_id, platform)` | Remove a platform link |
| `get_protocol_status()` | Get Axiom protocol operational status |

## Error Handling

```python
from aethex_axiom_sdk.exceptions import (
    AxiomAuthError,
    AxiomNotFoundError,
    AxiomRateLimitError,
    AxiomVerificationError,
)

try:
    await client.verify_platform(identity_id, Platform.DISCORD, token)
except AxiomVerificationError:
    print("Token invalid or expired")
except AxiomNotFoundError:
    print("No pending link for that platform")
except AxiomAuthError:
    print("JWT token invalid or expired")
except AxiomRateLimitError as e:
    print(f"Rate limited — retry in {e.retry_after}s")
```

## Requirements

- Python 3.10+
- `httpx >= 0.27`
- `pydantic >= 2.0`

## License

See [LICENSE](LICENSE).
