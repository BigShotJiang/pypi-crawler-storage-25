"""Tests for AxiomClient using respx for HTTP mocking."""

from __future__ import annotations

from uuid import UUID

import pytest
import respx
from httpx import Response

from aethex_axiom_sdk import AxiomClient
from aethex_axiom_sdk.exceptions import (
    AxiomAuthError,
    AxiomNotFoundError,
    AxiomRateLimitError,
    AxiomVerificationError,
)
from aethex_axiom_sdk.models import Identity, Platform, PlatformLink

BASE_URL = "https://api.aethex.tech"
TOKEN = "test-jwt-token"
IDENTITY_ID = "550e8400-e29b-41d4-a716-446655440000"

IDENTITY_PAYLOAD = {
    "id": IDENTITY_ID,
    "display_name": "Ada Lovelace",
    "platforms": [
        {
            "platform": "github",
            "handle": "ada",
            "verified": True,
            "verified_at": "2024-01-15T12:00:00Z",
        }
    ],
    "created_at": "2024-01-01T00:00:00Z",
    "updated_at": "2024-01-15T12:00:00Z",
}

STATUS_PAYLOAD = {"status": "operational", "version": "1.0.0", "uptime": 99.98}


@pytest.fixture
def client() -> AxiomClient:
    return AxiomClient(token=TOKEN, base_url=BASE_URL)


# ---------------------------------------------------------------------------
# get_identity
# ---------------------------------------------------------------------------


@respx.mock
@pytest.mark.asyncio
async def test_get_identity_success(client: AxiomClient) -> None:
    respx.get(f"{BASE_URL}/v1/identities/{IDENTITY_ID}").mock(
        return_value=Response(200, json=IDENTITY_PAYLOAD)
    )

    identity = await client.get_identity(IDENTITY_ID)

    assert identity.id == UUID(IDENTITY_ID)
    assert identity.display_name == "Ada Lovelace"
    assert len(identity.platforms) == 1
    assert identity.platforms[0].platform == Platform.GITHUB
    assert identity.is_verified() is True
    assert identity.verified_platforms[0].handle == "ada"


@respx.mock
@pytest.mark.asyncio
async def test_get_identity_not_found(client: AxiomClient) -> None:
    respx.get(f"{BASE_URL}/v1/identities/{IDENTITY_ID}").mock(
        return_value=Response(404, json={"message": "identity not found: " + IDENTITY_ID})
    )

    with pytest.raises(AxiomNotFoundError) as exc:
        await client.get_identity(IDENTITY_ID)

    assert exc.value.status_code == 404


@respx.mock
@pytest.mark.asyncio
async def test_get_identity_auth_error(client: AxiomClient) -> None:
    respx.get(f"{BASE_URL}/v1/identities/{IDENTITY_ID}").mock(
        return_value=Response(401, json={"message": "invalid token"})
    )

    with pytest.raises(AxiomAuthError):
        await client.get_identity(IDENTITY_ID)


# ---------------------------------------------------------------------------
# create_identity
# ---------------------------------------------------------------------------


@respx.mock
@pytest.mark.asyncio
async def test_create_identity(client: AxiomClient) -> None:
    respx.post(f"{BASE_URL}/v1/identities").mock(
        return_value=Response(201, json=IDENTITY_PAYLOAD)
    )

    identity = await client.create_identity("Ada Lovelace")

    assert identity.display_name == "Ada Lovelace"
    assert isinstance(identity.id, UUID)


# ---------------------------------------------------------------------------
# list_identities
# ---------------------------------------------------------------------------


@respx.mock
@pytest.mark.asyncio
async def test_list_identities(client: AxiomClient) -> None:
    respx.get(f"{BASE_URL}/v1/identities").mock(
        return_value=Response(200, json=[IDENTITY_PAYLOAD])
    )

    identities = await client.list_identities()

    assert len(identities) == 1
    assert identities[0].display_name == "Ada Lovelace"


@respx.mock
@pytest.mark.asyncio
async def test_list_identities_platform_filter(client: AxiomClient) -> None:
    route = respx.get(f"{BASE_URL}/v1/identities").mock(
        return_value=Response(200, json=[IDENTITY_PAYLOAD])
    )

    await client.list_identities(platform=Platform.DISCORD, verified_only=True)

    assert "platform=discord" in str(route.calls[0].request.url)
    assert "verified=true" in str(route.calls[0].request.url)


# ---------------------------------------------------------------------------
# link_platform / verify_platform
# ---------------------------------------------------------------------------


@respx.mock
@pytest.mark.asyncio
async def test_link_platform(client: AxiomClient) -> None:
    link_payload = {"platform": "discord", "handle": "ada#0001", "verified": False, "verified_at": None}
    respx.post(f"{BASE_URL}/v1/identities/{IDENTITY_ID}/platforms").mock(
        return_value=Response(201, json=link_payload)
    )

    link = await client.link_platform(IDENTITY_ID, Platform.DISCORD, "ada#0001")

    assert link.platform == Platform.DISCORD
    assert link.verified is False


@respx.mock
@pytest.mark.asyncio
async def test_verify_platform_success(client: AxiomClient) -> None:
    verified_payload = {
        "platform": "discord",
        "handle": "ada#0001",
        "verified": True,
        "verified_at": "2024-06-01T00:00:00Z",
    }
    respx.post(
        f"{BASE_URL}/v1/identities/{IDENTITY_ID}/platforms/discord/verify"
    ).mock(return_value=Response(200, json=verified_payload))

    link = await client.verify_platform(IDENTITY_ID, Platform.DISCORD, "one-time-token")

    assert link.verified is True
    assert link.verified_at is not None


@respx.mock
@pytest.mark.asyncio
async def test_verify_platform_bad_token(client: AxiomClient) -> None:
    respx.post(
        f"{BASE_URL}/v1/identities/{IDENTITY_ID}/platforms/discord/verify"
    ).mock(return_value=Response(422, json={"message": "platform verification failed: token expired"}))

    with pytest.raises(AxiomVerificationError):
        await client.verify_platform(IDENTITY_ID, Platform.DISCORD, "bad-token")


# ---------------------------------------------------------------------------
# get_protocol_status
# ---------------------------------------------------------------------------


@respx.mock
@pytest.mark.asyncio
async def test_get_protocol_status(client: AxiomClient) -> None:
    respx.get(f"{BASE_URL}/v1/status").mock(return_value=Response(200, json=STATUS_PAYLOAD))

    status = await client.get_protocol_status()

    assert status.status == "operational"
    assert status.uptime == pytest.approx(99.98)


# ---------------------------------------------------------------------------
# Rate limit
# ---------------------------------------------------------------------------


@respx.mock
@pytest.mark.asyncio
async def test_rate_limit(client: AxiomClient) -> None:
    respx.get(f"{BASE_URL}/v1/status").mock(
        return_value=Response(
            429,
            json={"message": "rate limit exceeded"},
            headers={"Retry-After": "30"},
        )
    )

    with pytest.raises(AxiomRateLimitError) as exc:
        await client.get_protocol_status()

    assert exc.value.retry_after == 30


# ---------------------------------------------------------------------------
# Context manager
# ---------------------------------------------------------------------------


@respx.mock
@pytest.mark.asyncio
async def test_context_manager() -> None:
    respx.get(f"{BASE_URL}/v1/status").mock(return_value=Response(200, json=STATUS_PAYLOAD))

    async with AxiomClient(token=TOKEN, base_url=BASE_URL) as client:
        status = await client.get_protocol_status()

    assert status.status == "operational"
