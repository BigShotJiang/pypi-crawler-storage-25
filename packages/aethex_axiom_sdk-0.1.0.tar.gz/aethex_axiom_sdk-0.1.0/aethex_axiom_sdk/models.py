"""Pydantic v2 response models matching the aethex-core Rust types."""

from __future__ import annotations

from datetime import datetime
from enum import Enum
from uuid import UUID

from pydantic import BaseModel, Field


class Platform(str, Enum):
    """Supported platform identifiers, matching the Rust Platform enum."""

    DISCORD = "discord"
    ROBLOX = "roblox"
    STEAM = "steam"
    XBOX = "xbox"
    EPIC = "epic"
    GITHUB = "github"

    def display_name(self) -> str:
        _names = {
            "discord": "Discord",
            "roblox": "Roblox",
            "steam": "Steam",
            "xbox": "Xbox",
            "epic": "Epic Games",
            "github": "GitHub",
        }
        return _names[self.value]


class PlatformLink(BaseModel):
    """A platform handle linked to an Axiom identity."""

    platform: Platform
    handle: str
    verified: bool
    verified_at: datetime | None = None

    model_config = {"frozen": True}


class Identity(BaseModel):
    """An Axiom identity with all linked platform verifications."""

    id: UUID
    display_name: str
    platforms: list[PlatformLink] = Field(default_factory=list)
    created_at: datetime
    updated_at: datetime

    model_config = {"frozen": True}

    @property
    def verified_platforms(self) -> list[PlatformLink]:
        """All fully verified platform links."""
        return [p for p in self.platforms if p.verified]

    def is_verified(self) -> bool:
        """Return True if at least one platform is verified."""
        return any(p.verified for p in self.platforms)

    def get_platform(self, platform: Platform) -> PlatformLink | None:
        """Return the PlatformLink for the given platform, or None."""
        return next((p for p in self.platforms if p.platform == platform), None)


class ProtocolStatus(BaseModel):
    """Current operational status of the Axiom protocol."""

    status: str = Field(..., description="'operational', 'degraded', or 'outage'")
    version: str
    uptime: float = Field(..., ge=0.0, le=100.0)

    model_config = {"frozen": True}
