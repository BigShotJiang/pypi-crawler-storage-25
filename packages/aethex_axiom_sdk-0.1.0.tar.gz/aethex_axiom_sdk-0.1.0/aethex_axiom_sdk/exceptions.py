"""Exception hierarchy for the Axiom SDK, mirroring aethex-core AxiomError variants."""


class AxiomError(Exception):
    """Base exception for all Axiom SDK errors."""

    def __init__(self, message: str, status_code: int | None = None) -> None:
        super().__init__(message)
        self.message = message
        self.status_code = status_code

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}(message={self.message!r}, status_code={self.status_code})"


class AxiomAuthError(AxiomError):
    """Raised on invalid, expired, or missing JWT token (HTTP 401/403)."""


class AxiomNotFoundError(AxiomError):
    """Raised when a requested resource does not exist (HTTP 404)."""


class AxiomRateLimitError(AxiomError):
    """Raised when the client exceeds the API rate limit (HTTP 429)."""

    def __init__(self, message: str, retry_after: int | None = None) -> None:
        super().__init__(message, status_code=429)
        self.retry_after = retry_after


class AxiomVerificationError(AxiomError):
    """Raised when platform verification fails (e.g. bad token, already claimed)."""
