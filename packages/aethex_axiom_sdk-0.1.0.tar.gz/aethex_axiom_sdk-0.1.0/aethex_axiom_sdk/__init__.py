"""aethex-axiom-sdk — Python SDK for the Axiom protocol."""

from aethex_axiom_sdk.client import AxiomClient
from aethex_axiom_sdk.exceptions import (
    AxiomAuthError,
    AxiomError,
    AxiomNotFoundError,
    AxiomRateLimitError,
    AxiomVerificationError,
)
from aethex_axiom_sdk.models import Identity, Platform, PlatformLink, ProtocolStatus

__version__ = "0.1.0"
__all__ = [
    "AxiomClient",
    "AxiomError",
    "AxiomAuthError",
    "AxiomNotFoundError",
    "AxiomRateLimitError",
    "AxiomVerificationError",
    "Identity",
    "Platform",
    "PlatformLink",
    "ProtocolStatus",
    "__version__",
]
