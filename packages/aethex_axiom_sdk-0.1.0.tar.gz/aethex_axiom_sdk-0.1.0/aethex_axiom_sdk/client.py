"""AxiomClient — async HTTP client for the Axiom protocol API."""

from __future__ import annotations

from typing import Any
from uuid import UUID

import httpx

from aethex_axiom_sdk.exceptions import (
    AxiomAuthError,
    AxiomError,
    AxiomNotFoundError,
    AxiomRateLimitError,
    AxiomVerificationError,
)
from aethex_axiom_sdk.models import Identity, Platform, PlatformLink, ProtocolStatus


class AxiomClient:
    """Async client for the Axiom protocol REST API.

    Args:
        token: JWT token issued by the Axiom server.
        base_url: Base URL for the Axiom API.
        timeout: Request timeout in seconds.

    Example::

        async with AxiomClient(token="eyJ...") as client:
            identity = await client.get_identity("550e8400-e29b-41d4-a716-446655440000")
    """

    def __init__(
        self,
        token: str,
        base_url: str = "https://api.aethex.tech",
        timeout: float = 30.0,
    ) -> None:
        self._token = token
        self._base_url = base_url.rstrip("/")
        self._timeout = timeout
        self._http: httpx.AsyncClient | None = None

    async def __aenter__(self) -> "AxiomClient":
        self._http = self._make_client()
        return self

    async def __aexit__(self, *_: Any) -> None:
        await self.close()

    async def close(self) -> None:
        """Close the underlying HTTP client."""
        if self._http is not None:
            await self._http.aclose()
            self._http = None

    # ------------------------------------------------------------------
    # Identity endpoints
    # ------------------------------------------------------------------

    async def get_identity(self, identity_id: UUID | str) -> Identity:
        """Fetch an identity by its UUID.

        Args:
            identity_id: The identity UUID.

        Raises:
            AxiomNotFoundError: No identity with that ID exists.
            AxiomAuthError: Token is invalid or expired.
        """
        data = await self._get(f"/v1/identities/{identity_id}")
        return Identity.model_validate(data)

    async def list_identities(
        self,
        platform: Platform | None = None,
        verified_only: bool = False,
        limit: int = 50,
        offset: int = 0,
    ) -> list[Identity]:
        """List identities with optional filtering.

        Args:
            platform: Filter to identities with a link on this platform.
            verified_only: Only return identities with at least one verified platform.
            limit: Max results to return (default 50).
            offset: Pagination offset.
        """
        params: dict[str, Any] = {"limit": limit, "offset": offset}
        if platform is not None:
            params["platform"] = platform.value
        if verified_only:
            params["verified"] = "true"
        data = await self._get("/v1/identities", params=params)
        return [Identity.model_validate(item) for item in data]

    async def create_identity(self, display_name: str) -> Identity:
        """Create a new Axiom identity.

        Args:
            display_name: Human-readable name for this identity.

        Returns:
            The newly created :class:`~aethex_axiom_sdk.models.Identity`.
        """
        data = await self._post("/v1/identities", json={"display_name": display_name})
        return Identity.model_validate(data)

    async def delete_identity(self, identity_id: UUID | str) -> None:
        """Permanently delete an identity and all its platform links.

        Args:
            identity_id: The identity UUID to delete.
        """
        await self._delete(f"/v1/identities/{identity_id}")

    # ------------------------------------------------------------------
    # Platform link endpoints
    # ------------------------------------------------------------------

    async def link_platform(
        self, identity_id: UUID | str, platform: Platform, handle: str
    ) -> PlatformLink:
        """Associate a platform handle with an identity (unverified initially).

        Args:
            identity_id: The identity to link.
            platform: Which platform (e.g. ``Platform.DISCORD``).
            handle: The user's handle on that platform.

        Returns:
            A :class:`~aethex_axiom_sdk.models.PlatformLink` with ``verified=False``.

        Raises:
            AxiomVerificationError: If the handle is already claimed by another identity.
        """
        data = await self._post(
            f"/v1/identities/{identity_id}/platforms",
            json={"platform": platform.value, "handle": handle},
        )
        return PlatformLink.model_validate(data)

    async def verify_platform(
        self, identity_id: UUID | str, platform: Platform, verification_token: str
    ) -> PlatformLink:
        """Complete platform verification using the one-time token from the platform.

        Args:
            identity_id: The identity whose platform link to verify.
            platform: Which platform to verify.
            verification_token: The one-time token obtained from the platform OAuth flow.

        Returns:
            An updated :class:`~aethex_axiom_sdk.models.PlatformLink` with ``verified=True``.

        Raises:
            AxiomVerificationError: If the token is invalid, expired, or already used.
            AxiomNotFoundError: If no pending link exists for this identity + platform.
        """
        data = await self._post(
            f"/v1/identities/{identity_id}/platforms/{platform.value}/verify",
            json={"token": verification_token},
        )
        return PlatformLink.model_validate(data)

    async def unlink_platform(self, identity_id: UUID | str, platform: Platform) -> None:
        """Remove a platform link from an identity.

        Args:
            identity_id: The identity to modify.
            platform: The platform link to remove.
        """
        await self._delete(f"/v1/identities/{identity_id}/platforms/{platform.value}")

    # ------------------------------------------------------------------
    # Protocol status
    # ------------------------------------------------------------------

    async def get_protocol_status(self) -> ProtocolStatus:
        """Fetch the current Axiom protocol operational status."""
        data = await self._get("/v1/status")
        return ProtocolStatus.model_validate(data)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _make_client(self) -> httpx.AsyncClient:
        return httpx.AsyncClient(
            base_url=self._base_url,
            headers={
                "Authorization": f"Bearer {self._token}",
                "Accept": "application/json",
                "User-Agent": "aethex-axiom-sdk/0.1.0",
            },
            timeout=self._timeout,
        )

    def _client(self) -> httpx.AsyncClient:
        if self._http is None:
            self._http = self._make_client()
        return self._http

    async def _get(self, path: str, params: dict[str, Any] | None = None) -> Any:
        response = await self._client().get(path, params=params)
        return self._raise_for_status(response)

    async def _post(self, path: str, json: Any = None) -> Any:
        response = await self._client().post(path, json=json)
        return self._raise_for_status(response)

    async def _delete(self, path: str) -> None:
        response = await self._client().delete(path)
        self._raise_for_status(response)

    @staticmethod
    def _raise_for_status(response: httpx.Response) -> Any:
        if response.is_success:
            if response.status_code == 204:
                return None
            return response.json()

        status = response.status_code
        try:
            body = response.json()
            message: str = body.get("message") or body.get("error") or response.text
        except Exception:
            message = response.text or f"HTTP {status}"

        if status in (401, 403):
            raise AxiomAuthError(message, status_code=status)
        if status == 404:
            raise AxiomNotFoundError(message, status_code=status)
        if status == 422:
            raise AxiomVerificationError(message, status_code=status)
        if status == 429:
            retry_raw = response.headers.get("Retry-After")
            retry_after = int(retry_raw) if retry_raw and retry_raw.isdigit() else None
            raise AxiomRateLimitError(message, retry_after=retry_after)

        raise AxiomError(message, status_code=status)
