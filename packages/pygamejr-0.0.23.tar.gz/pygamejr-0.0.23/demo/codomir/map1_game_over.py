from codomir import player, wait_quit

player.move_forward()
player.turn_left()
player.move_forward()

wait_quit()
