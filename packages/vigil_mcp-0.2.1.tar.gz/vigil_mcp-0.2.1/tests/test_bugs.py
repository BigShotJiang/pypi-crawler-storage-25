"""
Targeted regression tests for the two bugs fixed in this PR:

Bug 1 – Analyzer dedup loop (analyzer.py)
    Small signal groups (< _MIN_SIGNALS) were left as processed=0 forever,
    causing them to be re-fetched on every run (busy loop).  Fix: mark them
    as pending (processed=2) and reset back to 0 when a new signal arrives.

Bug 2 – Recurring commitment DST drift (db.py)
    _next_recurrence used now.replace(hour=h, minute=m) which preserves the
    existing tzinfo/fold and can silently produce the wrong wall-clock time
    when crossing DST boundaries.  Fix: construct the wall-clock time as a
    naive datetime then attach _LOCAL_TZ so zoneinfo resolves the offset.
"""

from __future__ import annotations

import json
import os
import sqlite3
import tempfile
from datetime import datetime, timedelta
from pathlib import Path
from unittest.mock import MagicMock, patch
from zoneinfo import ZoneInfo

import pytest

# ── helpers ──────────────────────────────────────────────────────────────────

def _make_db(tmp_path: Path):
    """Return a fresh Database instance backed by a temp file."""
    db_file = tmp_path / "test.db"
    with patch.dict(os.environ, {"HOME": str(tmp_path)}):
        # Patch DB_PATH so the DB lands in our temp dir
        from vigil_mcp import db as db_module
        original = db_module.DB_PATH
        db_module.DB_PATH = db_file
        try:
            instance = db_module.Database()
        finally:
            db_module.DB_PATH = original
    return instance, db_module


# ══════════════════════════════════════════════════════════════════════════════
# Bug 1 – Analyzer pending/dedup loop
# ══════════════════════════════════════════════════════════════════════════════

class TestAnalyzerPendingSet:
    """Small signal groups must be deferred, not re-fetched on every run."""

    def test_small_group_marked_pending_not_processed(self, tmp_path):
        """
        After analyze_signals() runs, a group with < _MIN_SIGNALS signals must
        have processed=2 (pending), NOT processed=0 (would cause busy loop).
        """
        db, db_module = _make_db(tmp_path)
        db_module.DB_PATH = tmp_path / "test.db"

        # Insert exactly 1 signal — below _MIN_SIGNALS=2
        sid = db.save_signal("lead-001", "email_opened", user_id="u1")

        # Run the analyzer (with ANTHROPIC_API_KEY absent so Claude is skipped)
        with patch.dict(os.environ, {}, clear=False):
            os.environ.pop("ANTHROPIC_API_KEY", None)
            # We need to call the internal logic: simulate by checking that
            # mark_signals_pending is called with the small-group IDs.
            from vigil_mcp import analyzer

            # Patch the db methods we want to observe
            pending_called_with: list[list[int]] = []
            processed_called_with: list[list[int]] = []

            original_pending = db.mark_signals_pending
            original_processed = db.mark_signals_processed

            def spy_pending(ids):
                pending_called_with.append(list(ids))
                original_pending(ids)

            def spy_processed(ids):
                processed_called_with.append(list(ids))
                original_processed(ids)

            db.mark_signals_pending = spy_pending
            db.mark_signals_processed = spy_processed

            # analyze_signals returns early when no API key, but we can test
            # the DB state by calling the internal grouping logic directly.
            # Instead, set a fake API key and mock the anthropic module so
            # we can reach the grouping/pending logic.
            # anthropic is imported lazily inside analyze_signals, so we
            # use sys.modules to inject a mock before the import happens.
            import sys
            mock_anthropic_module = MagicMock()
            mock_client = MagicMock()
            mock_anthropic_module.Anthropic.return_value = mock_client

            with patch.dict(os.environ, {"ANTHROPIC_API_KEY": "test-key"}):
                with patch.dict(sys.modules, {"anthropic": mock_anthropic_module}):
                    # The group has only 1 signal (<2) so Claude should never
                    # be called.
                    analyzer.analyze_signals(db)

            # Claude must NOT have been called
            mock_client.messages.create.assert_not_called()

            # The single signal must have been marked pending (processed=2)
            assert any(sid in ids for ids in pending_called_with), (
                "Small-group signal was not passed to mark_signals_pending"
            )

            # And NOT marked as fully processed (processed=1)
            assert not any(sid in ids for ids in processed_called_with), (
                "Small-group signal was incorrectly marked as processed"
            )

        # Confirm DB state: processed=2 (pending), not 0 or 1
        row = db.conn.execute("SELECT processed FROM signals WHERE id = ?", (sid,)).fetchone()
        assert row[0] == 2, f"Expected processed=2 (pending), got {row[0]}"

    def test_pending_signal_reset_when_new_signal_arrives(self, tmp_path):
        """
        A new signal for the same entity must reset pending signals back to
        processed=0 so they are reconsidered together with the new one.
        """
        db, db_module = _make_db(tmp_path)
        db_module.DB_PATH = tmp_path / "test.db"

        # Insert a signal and mark it pending
        sid = db.save_signal("lead-002", "email_opened", user_id="u1")
        db.mark_signals_pending([sid])

        row = db.conn.execute("SELECT processed FROM signals WHERE id = ?", (sid,)).fetchone()
        assert row[0] == 2, "Precondition: signal should be pending"

        # A new signal for the same entity arrives
        db.save_signal("lead-002", "link_clicked", user_id="u1")

        # The old pending signal must now be unprocessed again
        row = db.conn.execute("SELECT processed FROM signals WHERE id = ?", (sid,)).fetchone()
        assert row[0] == 0, (
            f"Expected pending signal to be reset to processed=0 after new signal, got {row[0]}"
        )

    def test_pending_signal_not_returned_by_get_unprocessed(self, tmp_path):
        """
        get_unprocessed_signals() must return only processed=0 rows, not
        processed=2 (pending) rows — so deferred groups stay quiet until reset.
        """
        db, db_module = _make_db(tmp_path)
        db_module.DB_PATH = tmp_path / "test.db"

        sid = db.save_signal("lead-003", "email_opened", user_id="u1")
        db.mark_signals_pending([sid])

        unprocessed = db.get_unprocessed_signals()
        ids = [s["id"] for s in unprocessed]
        assert sid not in ids, "Pending signal should not appear in get_unprocessed_signals()"


# ══════════════════════════════════════════════════════════════════════════════
# Bug 2 – Recurring commitment DST drift
# ══════════════════════════════════════════════════════════════════════════════

class TestRecurrenceDST:
    """_next_recurrence must keep wall-clock time stable across DST changes."""

    def _commitment(self, recurrence: str, recurrence_time: str = "09:00", **kwargs) -> dict:
        days = kwargs.pop("recurrence_days", [])
        return {
            "recurrence": recurrence,
            "recurrence_time": recurrence_time,
            # _next_recurrence expects a JSON string for recurrence_days
            "recurrence_days": json.dumps(days),
            **kwargs,
        }

    def test_daily_wall_clock_stable_after_dst_spring_forward(self, tmp_path):
        """
        When clocks spring forward (e.g. 02:00 → 03:00 in Europe/Budapest),
        a daily 09:00 commitment should still land at 09:00 local time, not
        08:00 or 10:00.
        """
        db, db_module = _make_db(tmp_path)

        # Europe/Budapest springs forward on the last Sunday of March.
        # 2025-03-30 02:00 CET → 03:00 CEST.
        # Simulate "now" as just before the DST boundary in local time.
        tz = ZoneInfo("Europe/Budapest")
        # 01:30 local on the day clocks change — still in CET (UTC+1)
        now_local = datetime(2025, 3, 30, 1, 30, 0, tzinfo=tz)

        c = self._commitment("daily", "09:00")
        with patch.object(db_module, "_LOCAL_TZ", tz):
            with patch("vigil_mcp.db.datetime") as mock_dt:
                mock_dt.now.return_value = now_local
                # Allow other datetime calls to pass through
                mock_dt.side_effect = lambda *a, **kw: datetime(*a, **kw)
                result = db._next_recurrence(c)

        assert result is not None
        # The scheduled time must be 09:00 local wall-clock on the same day
        # (since 09:00 CEST hasn't passed yet from 01:30 CET).
        assert result.hour == 9, f"Expected hour=9 in local time, got {result.hour}"
        assert result.minute == 0

    def test_daily_wall_clock_next_day(self, tmp_path):
        """
        When 'now' is after 09:00 local time, the next occurrence must be
        09:00 tomorrow — in whatever offset applies tomorrow.
        """
        db, db_module = _make_db(tmp_path)

        tz = ZoneInfo("Europe/Budapest")
        # 10:00 local on March 29 (day before DST change) → next 09:00 is
        # March 30 09:00 CEST (UTC+2), NOT 08:00 CEST.
        now_local = datetime(2025, 3, 29, 10, 0, 0, tzinfo=tz)

        c = self._commitment("daily", "09:00")
        with patch.object(db_module, "_LOCAL_TZ", tz):
            with patch("vigil_mcp.db.datetime") as mock_dt:
                mock_dt.now.return_value = now_local
                mock_dt.side_effect = lambda *a, **kw: datetime(*a, **kw)
                result = db._next_recurrence(c)

        assert result is not None
        assert result.year == 2025
        assert result.month == 3
        assert result.day == 30
        assert result.hour == 9, (
            f"Expected 09:00 local on Mar 30, got {result.hour}:{result.minute:02d} "
            f"(UTC offset: {result.utcoffset()})"
        )

    def test_weekly_wall_clock_stable(self, tmp_path):
        """Weekly recurrence must also produce the correct local hour."""
        db, db_module = _make_db(tmp_path)

        tz = ZoneInfo("Europe/Budapest")
        # Monday 2025-03-31 (after DST has sprung forward) at 08:00 CEST
        now_local = datetime(2025, 3, 31, 8, 0, 0, tzinfo=tz)

        c = self._commitment("weekly", "09:00", recurrence_days=["monday"])
        with patch.object(db_module, "_LOCAL_TZ", tz):
            with patch("vigil_mcp.db.datetime") as mock_dt:
                mock_dt.now.return_value = now_local
                mock_dt.side_effect = lambda *a, **kw: datetime(*a, **kw)
                result = db._next_recurrence(c)

        assert result is not None
        assert result.weekday() == 0  # Monday
        assert result.hour == 9
        assert result.minute == 0

    def test_monthly_wall_clock_stable(self, tmp_path):
        """Monthly recurrence must produce the correct local hour."""
        db, db_module = _make_db(tmp_path)

        tz = ZoneInfo("Europe/Budapest")
        now_local = datetime(2025, 3, 15, 10, 0, 0, tzinfo=tz)

        c = self._commitment("monthly", "09:00")
        with patch.object(db_module, "_LOCAL_TZ", tz):
            with patch("vigil_mcp.db.datetime") as mock_dt:
                mock_dt.now.return_value = now_local
                mock_dt.side_effect = lambda *a, **kw: datetime(*a, **kw)
                result = db._next_recurrence(c)

        assert result is not None
        assert result.month == 4
        assert result.hour == 9
        assert result.minute == 0
