"""
Progressive Web App assets — served inline by the dashboard HTTP server.

Includes:
  - manifest.json        → makes the app installable
  - service-worker.js    → handles push events + shows notifications
  - icon-192.svg / 512   → home-screen icons (SVG for simplicity)
"""

MANIFEST = """{
  "name": "Vigil",
  "short_name": "Vigil",
  "description": "The AI that reaches back out to you",
  "start_url": "/",
  "display": "standalone",
  "background_color": "#0b0e14",
  "theme_color": "#f59e0b",
  "orientation": "portrait",
  "icons": [
    { "src": "/icon-192.svg", "sizes": "192x192", "type": "image/svg+xml", "purpose": "any" },
    { "src": "/icon-512.svg", "sizes": "512x512", "type": "image/svg+xml", "purpose": "any" },
    { "src": "/icon-192.svg", "sizes": "192x192", "type": "image/svg+xml", "purpose": "maskable" }
  ]
}"""

# Inline SVG icon — fire emoji style, 192 and 512 share same markup
ICON_SVG_192 = """<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 192 192" width="192" height="192">
  <rect width="192" height="192" rx="42" fill="#0b0e14"/>
  <text x="96" y="134" text-anchor="middle" font-size="110" font-family="-apple-system, sans-serif">🔥</text>
</svg>"""

ICON_SVG_512 = """<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" width="512" height="512">
  <rect width="512" height="512" rx="112" fill="#0b0e14"/>
  <text x="256" y="360" text-anchor="middle" font-size="300" font-family="-apple-system, sans-serif">🔥</text>
</svg>"""

SERVICE_WORKER = """// Vigil service worker — handles Web Push events
const CACHE_NAME = 'vigil-v1';

self.addEventListener('install', (event) => {
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(self.clients.claim());
});

// ── Push event: show notification ──────────────────────────────────────
self.addEventListener('push', (event) => {
  let data = { title: 'Vigil', body: 'You have a pending commitment', url: '/' };
  try {
    if (event.data) data = { ...data, ...event.data.json() };
  } catch (e) {
    if (event.data) data.body = event.data.text();
  }

  const options = {
    body: data.body,
    icon: '/icon-192.svg',
    badge: '/icon-192.svg',
    tag: data.tag || 'vigil',
    renotify: true,
    requireInteraction: false,
    data: { url: data.url || '/' },
  };

  event.waitUntil(self.registration.showNotification(data.title, options));
});

// ── Click: focus existing tab or open a new one ────────────────────────
self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  const url = (event.notification.data && event.notification.data.url) || '/';

  event.waitUntil(
    self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then((clients) => {
      for (const client of clients) {
        if (client.url.includes(self.registration.scope) && 'focus' in client) {
          client.postMessage({ type: 'navigate', url });
          return client.focus();
        }
      }
      if (self.clients.openWindow) return self.clients.openWindow(url);
    })
  );
});
"""
