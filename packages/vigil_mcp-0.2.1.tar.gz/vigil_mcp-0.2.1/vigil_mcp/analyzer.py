"""
Signal analyzer — the AI brain that watches incoming signals and decides
when to create commitments autonomously.

Flow:
    External system → POST /api/signals → db.save_signal()
    Background loop → analyze_signals() every 5 min
        → group signals by entity_id
        → call Claude API to detect patterns
        → auto-create commitments for anything worth acting on
        → mark signals as processed

Requires: ANTHROPIC_API_KEY environment variable.
Falls back silently if not configured (signals are still stored).
"""

from __future__ import annotations

import json
import os
from collections import defaultdict
from datetime import datetime, timedelta
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .db import Database

from . import logger as log

# ── How many unprocessed signals to batch per run ───────────────────────────
_BATCH_LIMIT = 100

# ── Minimum signals per entity before we bother asking Claude ────────────────
_MIN_SIGNALS = 2

# ── Don't create a commitment for the same entity more than once per window ──
_DEDUP_HOURS = 24


def is_configured() -> bool:
    return bool(os.environ.get("ANTHROPIC_API_KEY"))


def analyze_signals(db: "Database") -> int:
    """
    Analyze unprocessed signals. Returns the number of commitments auto-created.
    Silently returns 0 if ANTHROPIC_API_KEY is not set.
    """
    if not is_configured():
        return 0

    try:
        import anthropic
    except ImportError:
        log.server.warning(log.kv(event="analyzer_skipped", reason="anthropic not installed"))
        return 0

    signals = db.get_unprocessed_signals(limit=_BATCH_LIMIT)
    if not signals:
        return 0

    # Group by (user_id, entity_id)
    groups: dict[tuple, list] = defaultdict(list)
    for s in signals:
        groups[(s["user_id"], s["entity_id"])].append(s)

    client = anthropic.Anthropic()
    created = 0
    # IDs for groups that are large enough — will be marked processed.
    all_signal_ids: list[int] = []
    # IDs for groups that are too small this run — will be marked pending
    # (processed=2) so they are not re-fetched every run, but will be reset
    # back to unprocessed (processed=0) as soon as a new signal arrives for
    # that entity, allowing the group to be reconsidered then.
    pending_signal_ids: list[int] = []

    for (user_id, entity_id), group in groups.items():
        if len(group) < _MIN_SIGNALS:
            # Not enough data yet — defer until more signals arrive.
            pending_signal_ids.extend(s["id"] for s in group)
            continue

        # Only add IDs to the batch AFTER we know the group is large enough.
        all_signal_ids.extend(s["id"] for s in group)

        # Check if we already created a commitment for this entity recently
        recent = db.get_signals_for_entity(entity_id, hours=_DEDUP_HOURS, user_id=user_id)
        existing_commitment = _has_recent_commitment(db, entity_id, user_id)
        if existing_commitment:
            log.server.info(log.kv(event="analyzer_dedup", entity=entity_id))
            continue

        # Build signal summary for Claude
        signal_lines = []
        for s in sorted(group, key=lambda x: x["created_at"]):
            meta_str = json.dumps(s["metadata"]) if s["metadata"] else ""
            signal_lines.append(
                f"- [{s['created_at'][:16]}] {s['event']}"
                + (f" | {meta_str}" if meta_str and meta_str != "{}" else "")
            )

        prompt = f"""You are Vigil, a proactive commitment tracker. Analyze these behavioral signals about entity "{entity_id}" (type: {group[0].get('entity_type', 'lead')}) and decide if a follow-up commitment should be created.

Signals (most recent {len(group)}):
{chr(10).join(signal_lines)}

Rules:
- Only create a commitment if the pattern clearly warrants proactive follow-up
- Examples that warrant action: email opened 3+ times with no reply, 48h+ of agent inactivity on a hot lead, repeated questions about the same topic
- Examples that DON'T warrant action: a single email open, normal check-ins, completed tasks

Respond with JSON only, no other text:
{{
  "create_commitment": true or false,
  "description": "specific actionable description (max 120 chars)",
  "importance_score": 0.0 to 1.0,
  "due_hours": hours until this should be acted on (e.g. 4, 24, 48),
  "reasoning": "one sentence why"
}}"""

        try:
            response = client.messages.create(
                model="claude-opus-4-5",
                max_tokens=256,
                messages=[{"role": "user", "content": prompt}],
            )
            raw = response.content[0].text.strip()

            # Strip markdown code fences if present
            if raw.startswith("```"):
                raw = raw.split("```")[1]
                if raw.startswith("json"):
                    raw = raw[4:]
                raw = raw.strip()

            decision = json.loads(raw)

            log.server.info(log.kv(
                event="analyzer_decision",
                entity=entity_id,
                create=decision.get("create_commitment"),
                reason=repr(decision.get("reasoning", "")[:80]),
            ))

            if decision.get("create_commitment"):
                due_hours = int(decision.get("due_hours", 24))
                due_by = (datetime.now() + timedelta(hours=due_hours)).isoformat()
                cid = db.save_commitment(
                    description=decision["description"],
                    due_by=due_by,
                    ai_summary=f"Auto-created from {len(group)} signals. {decision.get('reasoning', '')}",
                    intent_strength="hard",
                    importance_score=float(decision.get("importance_score", 0.7)),
                    confidence_score=1.0,
                    user_id=user_id,
                    context=f"entity_id:{entity_id}",
                )
                db.log_decision(
                    commitment_id=cid,
                    event="signal_auto_created",
                    phase="captured",
                    action="none",
                    reasoning=f"Auto-created from signals for entity '{entity_id}'. {decision.get('reasoning', '')}",
                )
                log.server.info(log.kv(
                    event="signal_commitment_created",
                    id=cid,
                    entity=entity_id,
                    signals=len(group),
                ))
                created += 1

        except json.JSONDecodeError as e:
            log.server.warning(log.kv(event="analyzer_json_error", entity=entity_id, error=str(e)[:80]))
        except Exception as e:
            log.server.error(log.kv(event="analyzer_error", entity=entity_id, error=repr(str(e))[:120]))

    # Mark processed (even if no commitment was created — avoids re-processing)
    db.mark_signals_processed(all_signal_ids)
    # Mark small groups as pending so they are not re-fetched every run.
    # They will be reset to unprocessed when a new signal arrives for the entity.
    db.mark_signals_pending(pending_signal_ids)

    if created:
        log.server.info(log.kv(event="analyzer_complete", commitments_created=created))

    return created


def parse_commitment_from_text(text: str, user_timezone: str | None = None) -> dict | None:
    """
    Parse natural language into a commitment dict.

    Returns a dict with keys: description, due_by, importance_score,
    intent_strength, context, ai_summary.
    Returns None if the text is not a commitment (question, greeting, etc.).
    Raises RuntimeError if ANTHROPIC_API_KEY is not set.
    Raises ImportError if the anthropic package is not installed.
    """
    if not is_configured():
        raise RuntimeError("ANTHROPIC_API_KEY is not set")

    try:
        import anthropic
    except ImportError:
        raise ImportError("anthropic package not installed. Run: pip install vigil-mcp[hosted]")

    tz = user_timezone or os.environ.get("TIMEZONE", "Europe/Budapest")
    now = datetime.now().isoformat()

    prompt = f"""Today's datetime is {now} (timezone: {tz}).

Parse this natural language into a commitment. The user said:
"{text}"

Rules:
- due_by: ISO 8601 string. Interpret relative times:
    "EOD" / "end of day" = today 18:00
    "tomorrow" = tomorrow 09:00
    "next Friday" = next Friday 09:00
    "in 2 hours" = 2 hours from now
    Leave as "" if no time is mentioned.
- intent_strength: "hard" if the user says "I will", "I need to", "must".
  "soft" if "I should", "I want to", "I'll try". "hypothetical" if "maybe", "someday", "might".
- importance_score: 0.0-1.0. Consider: is this deadline-driven? Is missing it costly?
  0.3 = low stakes, 0.6 = meaningful, 0.9 = critical.
- context: 3-5 word label for the topic (e.g. "GitHub PR", "client call", "tax return").
- ai_summary: 1-2 sentences expanding on what this commitment involves.
- is_commitment: false if the text is a question, greeting, or not a future action.

Respond with JSON only, no other text:
{{"is_commitment": true, "description": "clear actionable description (max 120 chars)", "due_by": "ISO 8601 or empty string", "importance_score": 0.5, "intent_strength": "hard", "context": "short topic label", "ai_summary": "1-2 sentence context"}}"""

    client = anthropic.Anthropic()
    response = client.messages.create(
        model="claude-haiku-4-5",
        max_tokens=300,
        messages=[{"role": "user", "content": prompt}],
    )
    raw = response.content[0].text.strip()

    # Strip markdown code fences if present
    if raw.startswith("```"):
        raw = raw.split("```")[1]
        if raw.startswith("json"):
            raw = raw[4:]
        raw = raw.strip()

    result = json.loads(raw)

    if not result.get("is_commitment"):
        return None

    return {
        "description":      result.get("description", text[:120]),
        "due_by":           result.get("due_by", ""),
        "importance_score": float(result.get("importance_score", 0.5)),
        "intent_strength":  result.get("intent_strength", "hard"),
        "context":          result.get("context", ""),
        "ai_summary":       result.get("ai_summary", ""),
    }


def _has_recent_commitment(db: "Database", entity_id: str, user_id: str) -> bool:
    """Check if a commitment for this entity was already auto-created recently."""
    since = (datetime.now() - timedelta(hours=_DEDUP_HOURS)).isoformat()
    cur = db.conn.execute(
        """SELECT id FROM commitments
           WHERE user_id = ? AND context LIKE ? AND created_at >= ?
             AND completed_at IS NULL AND state != 'abandoned'
           LIMIT 1""",
        (user_id, f"%entity_id:{entity_id}%", since),
    )
    return cur.fetchone() is not None
