import json
import os
import sqlite3
import threading
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional
from zoneinfo import ZoneInfo

DB_PATH = Path.home() / ".vigil" / "commitments.db"

# Timezone used for recurring commitment scheduling.
# Override via the TIMEZONE environment variable (e.g. "America/New_York").
_LOCAL_TZ = ZoneInfo(os.environ.get("TIMEZONE", "Europe/Budapest"))


class Database:
    def __init__(self):
        DB_PATH.parent.mkdir(exist_ok=True)
        self._local = threading.local()
        self._init()

    @property
    def conn(self):
        if not hasattr(self._local, "conn"):
            self._local.conn = sqlite3.connect(str(DB_PATH))
            self._local.conn.row_factory = sqlite3.Row
        return self._local.conn

    def _init(self):
        self.conn.executescript("""
            CREATE TABLE IF NOT EXISTS commitments (
                id               INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id          TEXT    DEFAULT 'local',
                title            TEXT,
                description      TEXT    NOT NULL,
                due_by           TEXT,
                context          TEXT,
                ai_summary       TEXT    DEFAULT '',
                intent_strength  TEXT    DEFAULT 'hard',
                confidence_score REAL    DEFAULT 1.0,
                importance_score REAL    DEFAULT 0.5,
                state            TEXT    DEFAULT 'captured',
                created_at       TEXT    NOT NULL,
                completed_at     TEXT,
                snoozed_until    TEXT,
                recurrence       TEXT    DEFAULT 'none',
                recurrence_days  TEXT,
                recurrence_time  TEXT    DEFAULT '',
                parent_id        INTEGER
            );

            CREATE TABLE IF NOT EXISTS decision_log (
                id             INTEGER PRIMARY KEY AUTOINCREMENT,
                commitment_id  INTEGER NOT NULL,
                event          TEXT    NOT NULL,
                phase          TEXT,
                action         TEXT    NOT NULL,
                reasoning      TEXT    NOT NULL,
                urgency        REAL,
                budget_used    INTEGER,
                budget_limit   INTEGER,
                created_at     TEXT    NOT NULL
            );

            CREATE TABLE IF NOT EXISTS settings (
                key     TEXT NOT NULL,
                user_id TEXT DEFAULT 'local',
                value   TEXT,
                PRIMARY KEY (key, user_id)
            );

            CREATE TABLE IF NOT EXISTS users (
                id         TEXT PRIMARY KEY,
                created_at TEXT NOT NULL,
                last_seen  TEXT
            );

            CREATE TABLE IF NOT EXISTS push_subscriptions (
                id         INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id    TEXT NOT NULL,
                endpoint   TEXT NOT NULL UNIQUE,
                p256dh     TEXT NOT NULL,
                auth       TEXT NOT NULL,
                created_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS signals (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id     TEXT    DEFAULT 'local',
                entity_id   TEXT    NOT NULL,
                entity_type TEXT    DEFAULT 'lead',
                event       TEXT    NOT NULL,
                metadata    TEXT    DEFAULT '{}',
                created_at  TEXT    NOT NULL,
                processed   INTEGER DEFAULT 0
            );
        """)
        self._migrate()
        self._ensure_indexes()
        self.conn.commit()

    def _ensure_indexes(self):
        self.conn.executescript("""
            CREATE INDEX IF NOT EXISTS idx_decision_log_commitment
                ON decision_log (commitment_id, created_at DESC);
            CREATE INDEX IF NOT EXISTS idx_decision_log_date_action
                ON decision_log (action, created_at);
            CREATE INDEX IF NOT EXISTS idx_commitments_state
                ON commitments (state, due_by);
            CREATE INDEX IF NOT EXISTS idx_commitments_user
                ON commitments (user_id, state, due_by);
            CREATE INDEX IF NOT EXISTS idx_push_subs_user
                ON push_subscriptions (user_id);
            CREATE INDEX IF NOT EXISTS idx_signals_entity
                ON signals (entity_id, created_at DESC);
            CREATE INDEX IF NOT EXISTS idx_signals_unprocessed
                ON signals (processed, created_at DESC);
        """)

    def _migrate(self):
        cur = self.conn.execute("PRAGMA table_info(commitments)")
        existing = {row["name"] for row in cur.fetchall()}
        new_columns = [
            ("user_id",          "TEXT DEFAULT 'local'"),
            ("title",            "TEXT"),
            ("ai_summary",       "TEXT DEFAULT ''"),
            ("intent_strength",  "TEXT DEFAULT 'hard'"),
            ("confidence_score", "REAL DEFAULT 1.0"),
            ("importance_score", "REAL DEFAULT 0.5"),
            ("state",            "TEXT DEFAULT 'captured'"),
            ("recurrence",       "TEXT DEFAULT 'none'"),
            ("recurrence_days",  "TEXT"),
            ("recurrence_time",  "TEXT DEFAULT ''"),
            ("parent_id",        "INTEGER"),
        ]
        for col, definition in new_columns:
            if col not in existing:
                self.conn.execute(f"ALTER TABLE commitments ADD COLUMN {col} {definition}")
        self.conn.commit()

    # ─── Commitments ────────────────────────────────────────────────────────

    def save_commitment(
        self,
        description: str,
        due_by: str,
        context: str = "",
        ai_summary: str = "",
        intent_strength: str = "hard",
        confidence_score: float = 1.0,
        importance_score: float = 0.5,
        recurrence: str = "none",
        recurrence_days: Optional[list] = None,
        recurrence_time: str = "",
        parent_id: Optional[int] = None,
        title: str = "",
        user_id: str = "local",
    ) -> int:
        cur = self.conn.execute(
            """INSERT INTO commitments
               (user_id, title, description, due_by, context, ai_summary,
                intent_strength, confidence_score, importance_score,
                state, created_at,
                recurrence, recurrence_days, recurrence_time, parent_id)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'captured', ?, ?, ?, ?, ?)""",
            (
                user_id,
                title or description[:60],
                description,
                due_by,
                context,
                ai_summary,
                intent_strength,
                confidence_score,
                importance_score,
                datetime.now().isoformat(),
                recurrence or "none",
                json.dumps(recurrence_days) if recurrence_days else None,
                recurrence_time or "",
                parent_id,
            ),
        )
        self.conn.commit()
        return cur.lastrowid

    def get_pending(self, user_id: Optional[str] = None) -> list[dict]:
        if user_id is None:
            cur = self.conn.execute(
                """SELECT * FROM commitments
                   WHERE completed_at IS NULL AND state != 'abandoned'
                   ORDER BY importance_score DESC, due_by ASC NULLS LAST"""
            )
        else:
            cur = self.conn.execute(
                """SELECT * FROM commitments
                   WHERE user_id = ? AND completed_at IS NULL AND state != 'abandoned'
                   ORDER BY importance_score DESC, due_by ASC NULLS LAST""",
                (user_id,),
            )
        return [dict(row) for row in cur.fetchall()]

    def get_completed(self, limit: int = 20, user_id: Optional[str] = None) -> list[dict]:
        if user_id is None:
            cur = self.conn.execute(
                "SELECT * FROM commitments WHERE completed_at IS NOT NULL ORDER BY completed_at DESC LIMIT ?",
                (limit,),
            )
        else:
            cur = self.conn.execute(
                "SELECT * FROM commitments WHERE user_id = ? AND completed_at IS NOT NULL ORDER BY completed_at DESC LIMIT ?",
                (user_id, limit),
            )
        return [dict(row) for row in cur.fetchall()]

    def get_all(self) -> list[dict]:
        cur = self.conn.execute("SELECT * FROM commitments ORDER BY created_at DESC")
        return [dict(row) for row in cur.fetchall()]

    def get_all_user_ids(self) -> list[str]:
        """Returns every user_id that has at least one pending commitment."""
        cur = self.conn.execute(
            "SELECT DISTINCT user_id FROM commitments WHERE completed_at IS NULL AND state != 'abandoned'"
        )
        return [row["user_id"] for row in cur.fetchall()]

    def get_by_id(self, commitment_id: int) -> Optional[dict]:
        cur = self.conn.execute("SELECT * FROM commitments WHERE id = ?", (commitment_id,))
        row = cur.fetchone()
        return dict(row) if row else None

    def update_state(self, commitment_id: int, state: str):
        self.conn.execute(
            "UPDATE commitments SET state = ? WHERE id = ?",
            (state, commitment_id),
        )
        self.conn.commit()

    def complete_commitment(self, commitment_id: int) -> Optional[int]:
        c = self.get_by_id(commitment_id)
        if not c:
            return None

        self.conn.execute(
            "UPDATE commitments SET completed_at = ?, state = 'completed' WHERE id = ?",
            (datetime.now().isoformat(), commitment_id),
        )
        self.conn.commit()

        if c.get("recurrence") and c["recurrence"] != "none":
            next_due = self._next_recurrence(c)
            if next_due:
                days = json.loads(c["recurrence_days"]) if c.get("recurrence_days") else None
                return self.save_commitment(
                    description=c["description"],
                    due_by=next_due.isoformat(),
                    context=c.get("context") or "",
                    ai_summary=c.get("ai_summary") or "",
                    intent_strength=c.get("intent_strength") or "hard",
                    confidence_score=float(c.get("confidence_score") or 1.0),
                    importance_score=float(c.get("importance_score") or 0.5),
                    recurrence=c["recurrence"],
                    recurrence_days=days,
                    recurrence_time=c.get("recurrence_time") or "",
                    parent_id=c.get("parent_id") or commitment_id,
                    title=c.get("title") or "",
                    user_id=c.get("user_id") or "local",
                )
        return None

    def update_commitment(
        self,
        commitment_id: int,
        description: Optional[str] = None,
        due_by: Optional[str] = None,
        importance_score: Optional[float] = None,
        intent_strength: Optional[str] = None,
        ai_summary: Optional[str] = None,
    ):
        fields, values = [], []
        if description is not None:
            fields.append("description = ?")
            values.append(description)
            # keep title in sync
            fields.append("title = ?")
            values.append(description[:60])
        if due_by is not None:
            fields.append("due_by = ?")
            values.append(due_by)
        if importance_score is not None:
            fields.append("importance_score = ?")
            values.append(round(max(0.0, min(1.0, importance_score)), 3))
        if intent_strength is not None:
            fields.append("intent_strength = ?")
            values.append(intent_strength)
        if ai_summary is not None:
            fields.append("ai_summary = ?")
            values.append(ai_summary)
        if not fields:
            return
        values.append(commitment_id)
        self.conn.execute(
            f"UPDATE commitments SET {', '.join(fields)} WHERE id = ?",
            values,
        )
        self.conn.commit()

    def abandon_commitment(self, commitment_id: int):
        self.conn.execute(
            "UPDATE commitments SET state = 'abandoned' WHERE id = ?",
            (commitment_id,),
        )
        self.conn.commit()

    def update_importance(self, commitment_id: int, new_score: float):
        new_score = round(max(0.0, min(1.0, new_score)), 3)
        self.conn.execute(
            "UPDATE commitments SET importance_score = ? WHERE id = ?",
            (new_score, commitment_id),
        )
        self.conn.commit()

    def get_nudge_count(self, commitment_id: int) -> int:
        """Count how many times this commitment has triggered an actual action."""
        cur = self.conn.execute(
            "SELECT COUNT(*) FROM decision_log WHERE commitment_id = ? AND action != 'none'",
            (commitment_id,),
        )
        return cur.fetchone()[0]

    def snooze_commitment(self, commitment_id: int, snooze_until: str):
        self.conn.execute(
            "UPDATE commitments SET due_by = ?, snoozed_until = ?, state = 'scheduled' WHERE id = ?",
            (snooze_until, snooze_until, commitment_id),
        )
        self.conn.commit()

    # ─── Decision log ────────────────────────────────────────────────────────

    def log_decision(
        self,
        commitment_id: int,
        event: str,
        phase: str,
        action: str,
        reasoning: str,
        urgency: float = 0.0,
    ):
        budget_used  = self.get_budget_used_today()
        budget_limit = self.get_budget_limit()
        self.conn.execute(
            """INSERT INTO decision_log
               (commitment_id, event, phase, action, reasoning, urgency,
                budget_used, budget_limit, created_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                commitment_id, event, phase, action, reasoning,
                urgency, budget_used, budget_limit,
                datetime.now().isoformat(),
            ),
        )
        self.conn.commit()

    def get_decision_history(self, commitment_id: int, limit: int = 10) -> list[dict]:
        cur = self.conn.execute(
            """SELECT * FROM decision_log WHERE commitment_id = ?
               ORDER BY created_at DESC LIMIT ?""",
            (commitment_id, limit),
        )
        return [dict(row) for row in cur.fetchall()]

    def get_last_nudge_time(self, commitment_id: int) -> Optional[datetime]:
        cur = self.conn.execute(
            """SELECT created_at FROM decision_log
               WHERE commitment_id = ? AND action != 'none'
               ORDER BY created_at DESC LIMIT 1""",
            (commitment_id,),
        )
        row = cur.fetchone()
        return datetime.fromisoformat(row["created_at"]) if row else None

    # ─── Attention budget ────────────────────────────────────────────────────

    def prune_decision_log(self, keep_per_commitment: int = 50, keep_days: int = 30):
        """
        Prevent unbounded growth of the decision log.
        Keeps the last N decisions per commitment and drops anything older than keep_days.
        """
        # Step 1: drop old entries
        self.conn.execute(
            "DELETE FROM decision_log WHERE created_at < datetime('now', ?)",
            (f"-{keep_days} days",),
        )

        # Step 2: for each commitment, keep only the latest N rows.
        # Written in Python for clarity — correlated DELETE subqueries are
        # fragile across SQLite versions.
        rows = self.conn.execute(
            "SELECT DISTINCT commitment_id FROM decision_log"
        ).fetchall()
        for row in rows:
            cid = row["commitment_id"]
            cutoff = self.conn.execute(
                """SELECT created_at FROM decision_log
                   WHERE commitment_id = ?
                   ORDER BY created_at DESC
                   LIMIT 1 OFFSET ?""",
                (cid, keep_per_commitment - 1),
            ).fetchone()
            if cutoff:
                self.conn.execute(
                    "DELETE FROM decision_log WHERE commitment_id = ? AND created_at < ?",
                    (cid, cutoff["created_at"]),
                )
        self.conn.commit()

    def get_budget_used_today(self, user_id: Optional[str] = None) -> int:
        today = datetime.now().date().isoformat()
        if user_id is None:
            cur = self.conn.execute(
                "SELECT COUNT(*) FROM decision_log WHERE action != 'none' AND date(created_at) = ?",
                (today,),
            )
        else:
            cur = self.conn.execute(
                """SELECT COUNT(*) FROM decision_log dl
                   JOIN commitments c ON dl.commitment_id = c.id
                   WHERE c.user_id = ? AND dl.action != 'none' AND date(dl.created_at) = ?""",
                (user_id, today),
            )
        return cur.fetchone()[0]

    def get_budget_limit(self, user_id: str = "local") -> int:
        return int(self.get_setting("attention_budget", "10", user_id=user_id))

    # ─── Recurrence ─────────────────────────────────────────────────────────

    def _next_recurrence(self, c: dict) -> Optional[datetime]:
        # Work in local time so that DST transitions don't shift the scheduled
        # hour (e.g. a 9:00 daily commitment stays at 9:00 local time after
        # the clocks change, rather than drifting to 8:00 or 10:00 UTC).
        now = datetime.now(_LOCAL_TZ)
        recurrence = c.get("recurrence", "none")
        h, m = 9, 0
        if c.get("recurrence_time"):
            try:
                h, m = map(int, c["recurrence_time"].split(":"))
            except ValueError:
                pass

        def _localize(year: int, month: int, day: int, hour: int, minute: int) -> datetime:
            # Build a timezone-aware datetime by constructing the wall-clock time
            # as a naive datetime first, then attaching _LOCAL_TZ.  This lets
            # zoneinfo handle DST transitions correctly (e.g. "daily at 09:00"
            # stays at 09:00 local time after the clocks change).
            return datetime(year, month, day, hour, minute, 0, tzinfo=_LOCAL_TZ)

        if recurrence == "daily":
            candidate = _localize(now.year, now.month, now.day, h, m)
            if candidate <= now:
                # Advance by one calendar day in local time
                next_day = (now + timedelta(days=1))
                candidate = _localize(next_day.year, next_day.month, next_day.day, h, m)
            return candidate

        elif recurrence == "weekly":
            day_map = {
                "monday": 0, "tuesday": 1, "wednesday": 2,
                "thursday": 3, "friday": 4, "saturday": 5, "sunday": 6,
            }
            days_raw = json.loads(c["recurrence_days"]) if c.get("recurrence_days") else []
            target_days = [day_map[d.lower()] for d in days_raw if d.lower() in day_map]
            if not target_days:
                next_week = now + timedelta(weeks=1)
                return _localize(next_week.year, next_week.month, next_week.day, h, m)
            for i in range(1, 8):
                candidate_day = now + timedelta(days=i)
                if candidate_day.weekday() in target_days:
                    return _localize(candidate_day.year, candidate_day.month, candidate_day.day, h, m)

        elif recurrence == "monthly":
            if now.month == 12:
                return _localize(now.year + 1, 1, 1, h, m)
            return _localize(now.year, now.month + 1, 1, h, m)

        return None

    # ─── Settings ────────────────────────────────────────────────────────────

    def get_setting(self, key: str, default: str = "", user_id: str = "local") -> str:
        cur = self.conn.execute(
            "SELECT value FROM settings WHERE key = ? AND user_id = ?",
            (key, user_id),
        )
        row = cur.fetchone()
        return row["value"] if row else default

    def set_setting(self, key: str, value: str, user_id: str = "local"):
        self.conn.execute(
            "INSERT OR REPLACE INTO settings (key, user_id, value) VALUES (?, ?, ?)",
            (key, user_id, value),
        )
        self.conn.commit()

    # ─── Stats ───────────────────────────────────────────────────────────────

    # ─── Users ──────────────────────────────────────────────────────────────

    def ensure_user(self, user_id: str):
        """Upsert a user record and update last_seen."""
        now = datetime.now().isoformat()
        self.conn.execute(
            """INSERT INTO users (id, created_at, last_seen) VALUES (?, ?, ?)
               ON CONFLICT(id) DO UPDATE SET last_seen = excluded.last_seen""",
            (user_id, now, now),
        )
        self.conn.commit()

    # ─── Push subscriptions ─────────────────────────────────────────────────

    def save_push_subscription(self, user_id: str, endpoint: str, p256dh: str, auth: str):
        self.conn.execute(
            """INSERT INTO push_subscriptions (user_id, endpoint, p256dh, auth, created_at)
               VALUES (?, ?, ?, ?, ?)
               ON CONFLICT(endpoint) DO UPDATE SET
                   user_id = excluded.user_id,
                   p256dh  = excluded.p256dh,
                   auth    = excluded.auth""",
            (user_id, endpoint, p256dh, auth, datetime.now().isoformat()),
        )
        self.conn.commit()

    def get_push_subscriptions(self, user_id: str) -> list[dict]:
        cur = self.conn.execute(
            "SELECT * FROM push_subscriptions WHERE user_id = ?",
            (user_id,),
        )
        return [dict(row) for row in cur.fetchall()]

    def delete_push_subscription(self, endpoint: str):
        self.conn.execute(
            "DELETE FROM push_subscriptions WHERE endpoint = ?",
            (endpoint,),
        )
        self.conn.commit()

    # ─── Stats ──────────────────────────────────────────────────────────────

    def get_stats(self, user_id: Optional[str] = None) -> dict:
        if user_id is None:
            total = self.conn.execute("SELECT COUNT(*) FROM commitments").fetchone()[0]
            completed = self.conn.execute(
                "SELECT COUNT(*) FROM commitments WHERE completed_at IS NOT NULL"
            ).fetchone()[0]
            overdue = self.conn.execute(
                "SELECT COUNT(*) FROM commitments WHERE completed_at IS NULL AND due_by < ? AND state != 'abandoned'",
                (datetime.now().isoformat(),),
            ).fetchone()[0]
            budget_used = self.get_budget_used_today()
            budget_limit = self.get_budget_limit()
        else:
            total = self.conn.execute(
                "SELECT COUNT(*) FROM commitments WHERE user_id = ?", (user_id,)
            ).fetchone()[0]
            completed = self.conn.execute(
                "SELECT COUNT(*) FROM commitments WHERE user_id = ? AND completed_at IS NOT NULL",
                (user_id,),
            ).fetchone()[0]
            overdue = self.conn.execute(
                "SELECT COUNT(*) FROM commitments WHERE user_id = ? AND completed_at IS NULL AND due_by < ? AND state != 'abandoned'",
                (user_id, datetime.now().isoformat()),
            ).fetchone()[0]
            budget_used = self.get_budget_used_today(user_id=user_id)
            budget_limit = self.get_budget_limit(user_id=user_id)
        return {
            "total": total,
            "completed": completed,
            "pending": total - completed,
            "overdue": overdue,
            "follow_through_rate": round((completed / total * 100) if total > 0 else 0, 1),
            "budget_used": budget_used,
            "budget_limit": budget_limit,
        }

    # ─── Signals ─────────────────────────────────────────────────────────────

    def save_signal(
        self,
        entity_id: str,
        event: str,
        entity_type: str = "lead",
        metadata: Optional[dict] = None,
        user_id: str = "local",
    ) -> int:
        # A new signal for an entity means any previously-deferred (pending)
        # signals for that entity should be reconsidered together with it,
        # so reset processed=2 → processed=0 for this entity/user pair.
        self.conn.execute(
            "UPDATE signals SET processed = 0 WHERE entity_id = ? AND user_id = ? AND processed = 2",
            (entity_id, user_id),
        )
        cur = self.conn.execute(
            """INSERT INTO signals (user_id, entity_id, entity_type, event, metadata, created_at)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (
                user_id,
                entity_id,
                entity_type,
                event,
                json.dumps(metadata or {}),
                datetime.now().isoformat(),
            ),
        )
        self.conn.commit()
        return cur.lastrowid

    def get_unprocessed_signals(self, user_id: Optional[str] = None, limit: int = 200) -> list[dict]:
        if user_id is not None:
            cur = self.conn.execute(
                """SELECT * FROM signals WHERE processed = 0 AND user_id = ?
                   ORDER BY created_at ASC LIMIT ?""",
                (user_id, limit),
            )
        else:
            cur = self.conn.execute(
                "SELECT * FROM signals WHERE processed = 0 ORDER BY created_at ASC LIMIT ?",
                (limit,),
            )
        rows = []
        for row in cur.fetchall():
            r = dict(row)
            r["metadata"] = json.loads(r.get("metadata") or "{}")
            rows.append(r)
        return rows

    def mark_signals_processed(self, signal_ids: list[int]):
        if not signal_ids:
            return
        placeholders = ",".join("?" * len(signal_ids))
        self.conn.execute(
            f"UPDATE signals SET processed = 1 WHERE id IN ({placeholders})",
            signal_ids,
        )
        self.conn.commit()

    def mark_signals_pending(self, signal_ids: list[int]):
        """
        Mark signals as pending (processed=2) — the group had too few signals
        this run but should not be re-fetched until a new signal arrives for
        that entity.  A new signal insertion resets any pending signals for the
        same entity back to processed=0 so they are reconsidered together.
        """
        if not signal_ids:
            return
        placeholders = ",".join("?" * len(signal_ids))
        self.conn.execute(
            f"UPDATE signals SET processed = 2 WHERE id IN ({placeholders})",
            signal_ids,
        )
        self.conn.commit()

    def get_signals_for_entity(
        self, entity_id: str, hours: int = 72, user_id: str = "local"
    ) -> list[dict]:
        since = (datetime.now() - timedelta(hours=hours)).isoformat()
        cur = self.conn.execute(
            """SELECT * FROM signals
               WHERE entity_id = ? AND user_id = ? AND created_at >= ?
               ORDER BY created_at ASC""",
            (entity_id, user_id, since),
        )
        rows = []
        for row in cur.fetchall():
            r = dict(row)
            r["metadata"] = json.loads(r.get("metadata") or "{}")
            rows.append(r)
        return rows

    def get_recent_signals(self, hours: int = 24, user_id: Optional[str] = None) -> list[dict]:
        since = (datetime.now() - timedelta(hours=hours)).isoformat()
        if user_id is not None:
            cur = self.conn.execute(
                "SELECT * FROM signals WHERE user_id = ? AND created_at >= ? ORDER BY created_at DESC",
                (user_id, since),
            )
        else:
            cur = self.conn.execute(
                "SELECT * FROM signals WHERE created_at >= ? ORDER BY created_at DESC",
                (since,),
            )
        rows = []
        for row in cur.fetchall():
            r = dict(row)
            r["metadata"] = json.loads(r.get("metadata") or "{}")
            rows.append(r)
        return rows

