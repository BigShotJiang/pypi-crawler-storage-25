"""
Vigil REST API — exposes all commitment tools as plain HTTP endpoints.

Lets non-MCP clients (ChatGPT Custom GPT Actions, Kimi, web apps, scripts)
interact with Vigil without Claude Desktop.

OpenAPI spec auto-generated at /openapi.json
Interactive docs at        /docs
"""

from __future__ import annotations

import os
import threading
from datetime import datetime
from typing import Optional

from .db import Database
from .policy import compute_phase
from . import logger as log

# ── FastAPI is an optional dep. If not installed, start_api() is a no-op. ──
try:
    from fastapi import FastAPI, HTTPException, Header, Depends
    from fastapi.middleware.cors import CORSMiddleware
    from pydantic import BaseModel
    import uvicorn
    _HAS_FASTAPI = True
except ImportError:
    _HAS_FASTAPI = False

API_PORT = 7735

# ─── Shared db instance (set by start_api) ─────────────────────────────────

_db: Optional[Database] = None


def _get_db() -> "Database":
    if _db is None:
        raise RuntimeError("API db not initialised")
    return _db


# ─── Only build app if FastAPI is available ─────────────────────────────────

if _HAS_FASTAPI:

    def _verify_token(authorization: str = Header(default="")) -> None:
        """FastAPI dependency — raises 401 if VIGIL_SECRET_TOKEN is set and header is wrong."""
        token = os.environ.get("VIGIL_SECRET_TOKEN")
        if not token:
            return  # local mode — no auth required
        if authorization != f"Bearer {token}":
            raise HTTPException(status_code=401, detail="Invalid or missing token. Set Authorization: Bearer <VIGIL_SECRET_TOKEN>.")

    app = FastAPI(
        title="Vigil",
        description=(
            "Proactive commitment tracking with a policy engine. "
            "Save commitments, let Vigil decide when to follow up."
        ),
        version="0.1.0",
    )

    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # ─── Schemas ─────────────────────────────────────────────────────────────

    class SaveRequest(BaseModel):
        description:      str
        due_by:           str = ""
        ai_summary:       str = ""
        context:          str = ""
        intent_strength:  str = "hard"
        importance_score: float = 0.5
        confidence_score: float = 1.0
        recurrence:       str = "none"
        recurrence_days:  list[str] = []
        recurrence_time:  str = ""

    class UpdateRequest(BaseModel):
        description:      Optional[str]   = None
        due_by:           Optional[str]   = None
        importance_score: Optional[float] = None
        intent_strength:  Optional[str]   = None
        ai_summary:       Optional[str]   = None

    class SnoozeRequest(BaseModel):
        snooze_until: str

    class BudgetRequest(BaseModel):
        daily_limit: int

    class DigestRequest(BaseModel):
        time: str  # "HH:MM"

    class NLRequest(BaseModel):
        text: str

    class SignalRequest(BaseModel):
        entity_id:   str
        event:       str
        entity_type: str = "lead"
        metadata:    dict = {}

    class FeatureToggleRequest(BaseModel):
        enabled: bool

    # ─── Endpoints ───────────────────────────────────────────────────────────

    @app.get("/commitments", summary="List all pending commitments", dependencies=[Depends(_verify_token)])
    def list_commitments():
        """
        Returns all non-completed commitments with their current phase,
        plus summary stats.
        """
        db = _get_db()
        commitments = db.get_pending()
        now = datetime.now()
        for c in commitments:
            c["phase"] = compute_phase(c, now).value
        return {"commitments": commitments, "stats": db.get_stats()}

    @app.post("/commitments", summary="Save a new commitment", status_code=201, dependencies=[Depends(_verify_token)])
    def save_commitment(req: SaveRequest):
        """
        Save a commitment. Call whenever the user signals future intent.
        intent_strength: 'hard' = "I will", 'soft' = "I should", 'hypothetical' = "maybe".
        importance_score: 0.0–1.0. Cost of missing this commitment.
        """
        db = _get_db()
        if req.confidence_score < 0.5:
            raise HTTPException(
                400,
                f"Confidence too low ({req.confidence_score:.1f}). Clarify intent before saving.",
            )
        cid = db.save_commitment(
            description=req.description,
            due_by=req.due_by,
            context=req.context,
            ai_summary=req.ai_summary,
            intent_strength=req.intent_strength,
            confidence_score=req.confidence_score,
            importance_score=req.importance_score,
            recurrence=req.recurrence,
            recurrence_days=req.recurrence_days or [],
            recurrence_time=req.recurrence_time,
        )
        log.server.info(log.kv(event="api_saved", id=cid))
        return {"id": cid, "message": f"Saved commitment {cid}."}

    @app.post("/commitments/from-text", summary="Create a commitment from natural language", status_code=201, dependencies=[Depends(_verify_token)])
    def create_from_text(req: NLRequest):
        """
        Parse natural language and create a commitment automatically.
        Requires ANTHROPIC_API_KEY to be set on the server.

        Example: {"text": "remind me to push the PR before EOD"}
        """
        try:
            from .analyzer import parse_commitment_from_text
            parsed = parse_commitment_from_text(req.text)
        except RuntimeError as e:
            raise HTTPException(503, str(e))
        except ImportError as e:
            raise HTTPException(503, str(e))
        except Exception as e:
            raise HTTPException(500, str(e)[:100])
        if parsed is None:
            raise HTTPException(400, "Text doesn't look like a commitment. Try: 'remind me to X by Y'.")
        db = _get_db()
        cid = db.save_commitment(
            description=parsed["description"],
            due_by=parsed["due_by"],
            context=parsed["context"],
            ai_summary=parsed["ai_summary"],
            intent_strength=parsed["intent_strength"],
            confidence_score=1.0,
            importance_score=parsed["importance_score"],
        )
        log.server.info(log.kv(event="api_nl_saved", id=cid))
        return {"id": cid, "message": f"Saved commitment {cid}.", "parsed": parsed}

    @app.get("/commitments/{commitment_id}", summary="Get a single commitment", dependencies=[Depends(_verify_token)])
    def get_commitment(commitment_id: int):
        db = _get_db()
        c = db.get_by_id(commitment_id)
        if not c:
            raise HTTPException(404, f"Commitment {commitment_id} not found.")
        c["phase"] = compute_phase(c).value
        return c

    @app.patch("/commitments/{commitment_id}", summary="Update an existing commitment", dependencies=[Depends(_verify_token)])
    def update_commitment(commitment_id: int, req: UpdateRequest):
        """Edit any field of an existing commitment. Only pass fields you want to change."""
        db = _get_db()
        if not db.get_by_id(commitment_id):
            raise HTTPException(404, f"Commitment {commitment_id} not found.")
        db.update_commitment(
            commitment_id=commitment_id,
            description=req.description,
            due_by=req.due_by,
            importance_score=req.importance_score,
            intent_strength=req.intent_strength,
            ai_summary=req.ai_summary,
        )
        log.server.info(log.kv(event="api_updated", id=commitment_id))
        return {"message": f"Updated commitment {commitment_id}."}

    @app.post("/commitments/{commitment_id}/complete", summary="Mark a commitment as done", dependencies=[Depends(_verify_token)])
    def complete_commitment(commitment_id: int):
        """
        Mark as complete. If the commitment is recurring, the next instance
        is automatically scheduled and its ID is returned.
        """
        db = _get_db()
        if not db.get_by_id(commitment_id):
            raise HTTPException(404, f"Commitment {commitment_id} not found.")
        new_id = db.complete_commitment(commitment_id)
        db.log_decision(commitment_id, "api_completed", "completed", "none",
                        "Marked complete via REST API.")
        result = {"message": f"Commitment {commitment_id} complete."}
        if new_id:
            result["next_id"] = new_id
            result["message"] += f" Next recurrence scheduled (ID: {new_id})."
        return result

    @app.post("/commitments/{commitment_id}/snooze", summary="Snooze a commitment", dependencies=[Depends(_verify_token)])
    def snooze_commitment(commitment_id: int, req: SnoozeRequest):
        """Push the deadline to a later time. snooze_until must be ISO 8601."""
        db = _get_db()
        if not db.get_by_id(commitment_id):
            raise HTTPException(404, f"Commitment {commitment_id} not found.")
        db.snooze_commitment(commitment_id, req.snooze_until)
        db.log_decision(commitment_id, "api_snoozed", "snoozed", "none",
                        f"Snoozed via REST API until {req.snooze_until}.")
        return {"message": f"Snoozed until {req.snooze_until}."}

    @app.delete("/commitments/{commitment_id}", summary="Abandon (archive) a commitment", dependencies=[Depends(_verify_token)])
    def abandon_commitment(commitment_id: int):
        db = _get_db()
        if not db.get_by_id(commitment_id):
            raise HTTPException(404, f"Commitment {commitment_id} not found.")
        db.abandon_commitment(commitment_id)
        log.server.info(log.kv(event="api_abandoned", id=commitment_id))
        return {"message": f"Commitment {commitment_id} abandoned."}

    @app.get("/commitments/{commitment_id}/decisions",
             summary="Get the policy decision trace for a commitment",
             dependencies=[Depends(_verify_token)])
    def get_decisions(commitment_id: int):
        """
        Returns the last 10 policy decisions for this commitment —
        what the engine considered and why it acted (or stayed silent).
        """
        db = _get_db()
        history = db.get_decision_history(commitment_id, limit=10)
        if not history:
            raise HTTPException(404, "No decisions logged for this commitment yet.")
        return {"decisions": history}

    @app.get("/signals", summary="Recent signals (last 24h)", dependencies=[Depends(_verify_token)])
    def list_signals(hours: int = 24):
        """Returns behavioral signals received in the last N hours."""
        return {"signals": _get_db().get_recent_signals(hours=hours)}

    @app.post("/signals", summary="Ingest a behavioral signal", status_code=201, dependencies=[Depends(_verify_token)])
    def ingest_signal(req: SignalRequest):
        """
        Push a behavioral signal into Vigil. The analyzer runs every 5 minutes
        and will auto-create a commitment if the pattern warrants it.

        Examples:
        - {"entity_id": "lead_john_smith", "event": "email_opened", "metadata": {"count": 4}}
        - {"entity_id": "agent_sarah", "event": "no_contact_48h", "entity_type": "agent"}
        - {"entity_id": "lead_group_parking", "event": "topic_mentioned", "metadata": {"topic": "parking"}}
        """
        db = _get_db()
        sid = db.save_signal(
            entity_id=req.entity_id,
            event=req.event,
            entity_type=req.entity_type,
            metadata=req.metadata,
        )
        log.server.info(log.kv(event="api_signal", id=sid, entity=req.entity_id, signal=req.event))
        return {"id": sid, "message": f"Signal {sid} recorded. Analyzer runs every 5 minutes."}

    @app.get("/stats", summary="Overall stats", dependencies=[Depends(_verify_token)])
    def get_stats():
        """Follow-through rate, overdue count, budget usage, etc."""
        return _get_db().get_stats()

    @app.get("/settings", summary="Current settings", dependencies=[Depends(_verify_token)])
    def get_settings():
        db = _get_db()
        return {
            "attention_budget": db.get_budget_limit(),
            "digest_time": db.get_setting("digest_time") or None,
        }

    @app.put("/settings/budget", summary="Set daily attention budget", dependencies=[Depends(_verify_token)])
    def set_budget(req: BudgetRequest):
        """How many nudges Vigil is allowed to send per day (1–50, default 10)."""
        limit = max(1, min(50, req.daily_limit))
        _get_db().set_setting("attention_budget", str(limit))
        return {"message": f"Budget set to {limit} nudges/day."}

    @app.put("/settings/digest", summary="Set daily digest time", dependencies=[Depends(_verify_token)])
    def set_digest(req: DigestRequest):
        """Schedule a morning summary notification. time must be 'HH:MM'."""
        try:
            parts = req.time.strip().split(":")
            if len(parts) != 2:
                raise ValueError
            h, m = int(parts[0]), int(parts[1])
            if not (0 <= h <= 23 and 0 <= m <= 59):
                raise ValueError
        except ValueError:
            raise HTTPException(400, f"Invalid time '{req.time}'. Use HH:MM format.")
        normalised = f"{h:02d}:{m:02d}"
        _get_db().set_setting("digest_time", normalised)
        return {"message": f"Daily digest set for {normalised}."}

    @app.get("/features", summary="List all V3 features", dependencies=[Depends(_verify_token)])
    def list_features_endpoint():
        try:
            from .features import get_all_status
        except ImportError as e:
            raise HTTPException(503, str(e))
        return {"features": get_all_status(_get_db(), user_id="local")}

    @app.put("/features/{feature_name}", summary="Enable or disable a V3 feature", dependencies=[Depends(_verify_token)])
    def toggle_feature(feature_name: str, req: FeatureToggleRequest):
        try:
            from .features import set_enabled, FEATURES
        except ImportError as e:
            raise HTTPException(503, str(e))
        if feature_name not in FEATURES:
            raise HTTPException(404, f"Unknown feature. Valid: {list(FEATURES.keys())}")
        set_enabled(feature_name, req.enabled, _get_db(), user_id="local")
        feat = FEATURES[feature_name]
        missing = [v for v in feat.requires_env if not os.environ.get(v)]
        if missing and req.enabled:
            return {"message": f"'{feat.label}' toggled on, needs: {', '.join(missing)}", "warning": True}
        return {"message": f"'{feat.label}' {'enabled' if req.enabled else 'disabled'}."}


# ─── Starter ─────────────────────────────────────────────────────────────────

def start_api(db_instance: "Database", port: int = API_PORT) -> Optional[int]:
    """
    Start the REST API in a background thread.
    Returns the port it bound to, or None if FastAPI is not installed.
    """
    if not _HAS_FASTAPI:
        log.server.info(log.kv(event="api_skipped", reason="fastapi not installed"))
        return None

    global _db
    _db = db_instance

    config = uvicorn.Config(app, host="0.0.0.0", port=port, log_level="error")
    server = uvicorn.Server(config)

    thread = threading.Thread(target=server.run, daemon=True)
    thread.start()
    log.server.info(log.kv(event="api_started", port=port))
    return port


# ─── Standalone entry point (no Claude Desktop needed) ───────────────────────

def main():
    """
    Run Vigil as a standalone service — no Claude Desktop required.

    Local mode:
      - Dashboard/PWA on localhost:7734
      - REST API (OpenAPI docs) on localhost:7735

    Cloud mode (Railway/Render/Fly — auto-detected via $PORT):
      - Everything served on 0.0.0.0:$PORT through the dashboard HTTP server.
        The PWA + CRUD API work identically. ChatGPT integrations point at
        the public URL directly.
    """
    import os
    import signal
    from .db import Database as _Database
    from .dashboard import start_dashboard, _make_handler, _ReusableHTTPServer
    from .server import _background_loop
    import threading as _threading

    db = _Database()

    vigil_features_env = os.environ.get("VIGIL_FEATURES", "").strip()
    if vigil_features_env:
        try:
            from .features import set_enabled, FEATURES
            for name in [n.strip() for n in vigil_features_env.split(",") if n.strip()]:
                if name in FEATURES:
                    set_enabled(name, True, db)
                    print(f"  Auto-enabled feature: {name}")
        except Exception as e:
            print(f"  Warning: could not process VIGIL_FEATURES: {e}")

    _threading.Thread(target=_background_loop, daemon=True).start()

    cloud_port = os.environ.get("PORT")

    if cloud_port:
        # Cloud deploy — bind dashboard server to 0.0.0.0:$PORT
        port = int(cloud_port)
        handler = _make_handler(db)
        server = _ReusableHTTPServer(("0.0.0.0", port), handler)
        print(f"Vigil listening on 0.0.0.0:{port}")
        if push_mod := _safe_import_push():
            if push_mod.is_configured():
                print("Web Push: configured")
            else:
                print("Web Push: NOT configured — set VIGIL_VAPID_PRIVATE_KEY and VIGIL_VAPID_PUBLIC_KEY")
        server.serve_forever()
        return

    # Local mode
    if not _HAS_FASTAPI:
        print("Note: FastAPI not installed — REST API disabled.")
        print("      Install with: pip install vigil-mcp[hosted]")

    dash_port = start_dashboard(db)
    if dash_port:
        print(f"Vigil dashboard → http://localhost:{dash_port}")

    api_port = start_api(db)
    if api_port:
        print(f"Vigil REST API  → http://localhost:{api_port}/docs")
        print(f"OpenAPI spec    → http://localhost:{api_port}/openapi.json")

    print("Vigil is running. Press Ctrl+C to stop.")
    try:
        signal.pause()
    except (AttributeError, KeyboardInterrupt):
        import time
        while True:
            time.sleep(3600)


def _safe_import_push():
    try:
        from . import push as _p
        return _p
    except Exception:
        return None
