"""
Policy Engine — the decision layer that determines whether Vigil should act.

Every potential nudge passes through here. The output is not just
"send notification" but a reasoned decision with a full trace of why.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from enum import Enum
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .db import Database


# ─── Enumerations ───────────────────────────────────────────────────────────

class Phase(str, Enum):
    EARLY     = "early"       # > 48h until due — planning horizon
    EXECUTION = "execution"   # 4–48h until due — action window
    RISK      = "risk"        # < 4h until due  — high alert
    OVERDUE   = "overdue"     # past deadline


class Action(str, Enum):
    NONE                  = "none"
    NOTIFY                = "notify"
    MESSAGE_CURRENT_THREAD = "message_current_thread"


class IntentStrength(str, Enum):
    HARD         = "hard"         # "I will do X"
    SOFT         = "soft"         # "I should do X" / "I'll try to"
    HYPOTHETICAL = "hypothetical" # "Maybe I'll do X" / "It'd be nice to"


# ─── Output ─────────────────────────────────────────────────────────────────

@dataclass
class PolicyDecision:
    action:           Action
    reasoning:        str
    phase:            Phase
    urgency:          float       # 0.0 – 1.0
    budget_remaining: int
    suppressed:       bool = False # True if budget caused suppression


# ─── Phase computation ──────────────────────────────────────────────────────

def compute_phase(commitment: dict, now: datetime | None = None) -> Phase:
    now = now or datetime.now()
    due_by = commitment.get("due_by")
    if not due_by:
        return Phase.EARLY

    due = datetime.fromisoformat(due_by)
    if due < now:
        return Phase.OVERDUE

    hours_remaining = (due - now).total_seconds() / 3600
    if hours_remaining < 4:
        return Phase.RISK
    elif hours_remaining < 48:
        return Phase.EXECUTION
    return Phase.EARLY


# ─── State auto-transition ──────────────────────────────────────────────────

def state_for_phase(phase: Phase, current_state: str) -> str:
    """Map the current phase to the appropriate lifecycle state."""
    if current_state in ("completed", "abandoned"):
        return current_state

    return {
        Phase.EARLY:     "scheduled",
        Phase.EXECUTION: "in_progress",
        Phase.RISK:      "at_risk",
        Phase.OVERDUE:   "overdue",
    }[phase]


# ─── Urgency ────────────────────────────────────────────────────────────────

def compute_urgency(commitment: dict, phase: Phase, now: datetime | None = None) -> float:
    """
    Returns a 0–1 float representing urgency.
    0 = no rush, 1 = critical / already missed.
    """
    now = now or datetime.now()

    if phase == Phase.OVERDUE:
        due = datetime.fromisoformat(commitment["due_by"])
        hours_overdue = (now - due).total_seconds() / 3600
        return min(1.0, 0.7 + hours_overdue * 0.03)

    if not commitment.get("due_by"):
        return 0.1

    due      = datetime.fromisoformat(commitment["due_by"])
    created  = datetime.fromisoformat(commitment["created_at"])
    total    = (due - created).total_seconds()
    remaining = (due - now).total_seconds()

    if total <= 0:
        return 1.0

    progress = 1.0 - (remaining / total)
    return max(0.0, min(1.0, progress))


# ─── Cooldown windows per phase ─────────────────────────────────────────────

_COOLDOWN_SECONDS: dict[Phase, int] = {
    Phase.EARLY:     0,         # never nudge in early phase
    Phase.EXECUTION: 4 * 3600,  # max once every 4h
    Phase.RISK:      3600,      # max once per hour
    Phase.OVERDUE:   2 * 3600,  # max once every 2h
}


# ─── Core decision function ─────────────────────────────────────────────────

def decide_action(commitment: dict, db: "Database") -> PolicyDecision:
    """
    The single entry point for all proactivity decisions.

    Considers: phase, urgency, intent strength, importance,
               attention budget, cooldown, and past nudge history.

    Returns a PolicyDecision with full reasoning trace.
    """
    now        = datetime.now()
    phase      = compute_phase(commitment, now)
    urgency    = compute_urgency(commitment, phase, now)
    importance = float(commitment.get("importance_score") or 0.5)
    intent     = commitment.get("intent_strength") or "hard"
    budget_limit = db.get_budget_limit()
    budget_used  = db.get_budget_used_today()
    budget_left  = budget_limit - budget_used

    # ── 1. Never act on hypotheticals ───────────────────────────────────────
    if intent == IntentStrength.HYPOTHETICAL:
        return PolicyDecision(
            action=Action.NONE,
            reasoning="Commitment was marked hypothetical — not actionable until confirmed.",
            phase=phase, urgency=urgency, budget_remaining=budget_left,
        )

    # ── 2. Soft intents get a reduced effective importance ──────────────────
    effective_importance = importance if intent == "hard" else max(0.0, importance - 0.2)

    # ── 3. Grace period — never nudge within 30 min of creation ────────────
    created = datetime.fromisoformat(commitment.get("created_at", now.isoformat()))
    if (now - created).total_seconds() < 1800:
        return PolicyDecision(
            action=Action.NONE,
            reasoning="Grace period — commitment was just created. No nudge within the first 30 minutes.",
            phase=phase, urgency=urgency, budget_remaining=budget_left,
        )

    # ── 4. Early phase — no nudge, it's too soon ────────────────────────────
    if phase == Phase.EARLY:
        return PolicyDecision(
            action=Action.NONE,
            reasoning=f"Early phase — more than 48h until deadline. No nudge warranted.",
            phase=phase, urgency=urgency, budget_remaining=budget_left,
        )

    # ── 5. Check cooldown — no spam ─────────────────────────────────────────
    last_nudge = db.get_last_nudge_time(commitment["id"])
    cooldown   = _COOLDOWN_SECONDS[phase]
    if last_nudge and (now - last_nudge).total_seconds() < cooldown:
        minutes_ago = int((now - last_nudge).total_seconds() / 60)
        return PolicyDecision(
            action=Action.NONE,
            reasoning=f"Cooldown active ({phase.value} phase = {cooldown // 3600}h window). "
                      f"Last nudge was {minutes_ago} minutes ago.",
            phase=phase, urgency=urgency, budget_remaining=budget_left,
        )

    # ── 6. Check attention budget ────────────────────────────────────────────
    if budget_left <= 0 and effective_importance < 0.8:
        return PolicyDecision(
            action=Action.NONE,
            reasoning=f"Daily attention budget exhausted ({budget_used}/{budget_limit}). "
                      f"Suppressing — importance {effective_importance:.1f} below override threshold (0.8).",
            phase=phase, urgency=urgency, budget_remaining=0, suppressed=True,
        )

    # ── 7. Phase-based action decision ──────────────────────────────────────
    if phase == Phase.OVERDUE:
        action   = Action.NOTIFY
        reasoning = (
            f"Commitment is overdue. Urgency: {urgency:.2f}. "
            f"Importance: {effective_importance:.1f}. Escalating."
        )

    elif phase == Phase.RISK:
        action   = Action.NOTIFY
        reasoning = (
            f"Less than 4 hours until deadline. Risk phase. "
            f"Urgency: {urgency:.2f}. Importance: {effective_importance:.1f}."
        )

    elif phase == Phase.EXECUTION:
        if effective_importance >= 0.6:
            action   = Action.NOTIFY
            reasoning = (
                f"Execution phase. High enough importance ({effective_importance:.1f}) "
                f"to justify a nudge. Urgency: {urgency:.2f}."
            )
        else:
            action   = Action.NONE
            reasoning = (
                f"Execution phase but importance too low ({effective_importance:.1f} < 0.6) "
                f"to justify interruption. Will reassess in risk phase."
            )
    else:
        action   = Action.NONE
        reasoning = f"No action warranted at {phase.value} phase."

    return PolicyDecision(
        action=action,
        reasoning=reasoning,
        phase=phase,
        urgency=urgency,
        budget_remaining=max(0, budget_left - (1 if action != Action.NONE else 0)),
    )
