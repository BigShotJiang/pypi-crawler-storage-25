"""
notify.py — Shared notification delivery used by both the background loop and integrations.

Sending chain: Web Push → Slack/Discord webhooks → desktop fallback.
Importable by any module without circular-import risk.
"""
from __future__ import annotations
import subprocess
import sys
from typing import TYPE_CHECKING
if TYPE_CHECKING:
    from .db import Database
from . import logger as log


def send_notification(
    db: "Database",
    title: str,
    message: str,
    user_id: str = "local",
    commitment_id: int = 0,
):
    """Deliver a notification via Web Push → webhooks → desktop fallback."""
    push_sent = 0
    try:
        from . import push as push_mod
        push_sent = push_mod.send_to_user(db, user_id, title, message)
    except Exception as e:
        log.schedule.warning(log.kv(event="push_fallback", error=repr(str(e))[:80]))

    try:
        from .webhooks import notify_via_webhooks
        notify_via_webhooks(db, user_id, title, message, commitment_id)
    except Exception as e:
        log.schedule.warning(log.kv(event="webhook_notify_error", error=repr(str(e))[:80]))

    if push_sent > 0:
        return

    try:
        platform_notify(title, message)
        log.schedule.info(log.kv(event="notification_sent", title=repr(title[:40]), message=repr(message[:60])))
    except Exception as e:
        log.schedule.error(log.kv(event="notification_failed", error=repr(str(e))))


def platform_notify(title: str, message: str):
    """Send a desktop notification on macOS, Windows, or Linux."""
    if sys.platform == "darwin":
        safe_title   = title.replace('"', '\\"').replace("'", "\\'")
        safe_message = message.replace('"', '\\"').replace("'", "\\'")
        subprocess.run(
            ["osascript", "-e",
             f'display notification "{safe_message}" with title "{safe_title}" sound name "Ping"'],
            check=True, capture_output=True,
        )

    elif sys.platform == "win32":
        try:
            from plyer import notification as plyer_notify  # type: ignore
            plyer_notify.notify(title=title, message=message, app_name="Vigil", timeout=8)
            return
        except ImportError:
            pass
        safe = lambda s: s.replace('"', "").replace("'", "")
        script = (
            "Add-Type -AssemblyName System.Windows.Forms;"
            "$n = [System.Windows.Forms.NotifyIcon]::new();"
            "$n.Icon = [System.Drawing.SystemIcons]::Information;"
            "$n.Visible = $true;"
            f'$n.ShowBalloonTip(6000,"{safe(title)}","{safe(message)}",'
            "[System.Windows.Forms.ToolTipIcon]::Info);"
            "Start-Sleep -Milliseconds 6500;"
            "$n.Dispose()"
        )
        subprocess.run(["powershell", "-Command", script], capture_output=True)

    else:
        subprocess.run(["notify-send", "--", title, message], check=True, capture_output=True)
