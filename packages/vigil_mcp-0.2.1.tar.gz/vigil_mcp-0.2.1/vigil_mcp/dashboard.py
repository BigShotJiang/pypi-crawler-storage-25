import json
import threading
from datetime import datetime, timedelta
from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import urlparse

from . import push as push_mod
from .pwa import MANIFEST, ICON_SVG_192, ICON_SVG_512, SERVICE_WORKER

PORT = 7734

HTML = """<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Vigil</title>
  <link rel="manifest" href="/manifest.json">
  <meta name="theme-color" content="#f59e0b">
  <meta name="apple-mobile-web-app-capable" content="yes">
  <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
  <meta name="apple-mobile-web-app-title" content="Vigil">
  <link rel="apple-touch-icon" href="/icon-192.svg">
  <link rel="icon" type="image/svg+xml" href="/icon-192.svg">
  <style>
    *, *::before, *::after { margin: 0; padding: 0; box-sizing: border-box; }
    body {
      background: #0b0e14;
      color: #e2e8f0;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
      padding: 2rem;
      max-width: 860px;
      margin: 0 auto;
    }
    header { margin-bottom: 2.5rem; display: flex; align-items: flex-start; justify-content: space-between; gap: 1rem; }
    .header-left h1 { font-size: 1.6rem; font-weight: 700; color: #f59e0b; letter-spacing: -0.02em; }
    .subtitle { color: #475569; font-size: 0.85rem; margin-top: 0.25rem; }

    /* Add button */
    .btn-add {
      flex-shrink: 0;
      background: #f59e0b; color: #0b0e14;
      border: none; border-radius: 0.75rem;
      padding: 0.6rem 1.25rem; font-size: 0.875rem; font-weight: 700;
      cursor: pointer; transition: background 0.15s;
    }
    .btn-add:hover { background: #fbbf24; }

    /* Stats */
    .stats { display: grid; grid-template-columns: repeat(auto-fit, minmax(140px, 1fr)); gap: 1rem; margin-bottom: 2.5rem; }
    .stat { background: #141820; border: 1px solid #1e2535; border-radius: 0.875rem; padding: 1.25rem 1.5rem; }
    .stat-label { font-size: 0.7rem; color: #475569; text-transform: uppercase; letter-spacing: 0.08em; margin-bottom: 0.5rem; }
    .stat-value { font-size: 2.25rem; font-weight: 700; line-height: 1; }
    .stat-value.amber { color: #f59e0b; }
    .stat-value.red   { color: #ef4444; }
    .stat-value.green { color: #22c55e; }
    .stat-value.white { color: #f1f5f9; }
    .rate-bar { height: 3px; background: #1e2535; border-radius: 9999px; margin-top: 0.75rem; overflow: hidden; }
    .rate-fill { height: 100%; background: #f59e0b; border-radius: 9999px; transition: width 0.6s ease; }

    /* Section */
    .section { margin-bottom: 2rem; }
    .section-label {
      font-size: 0.72rem; font-weight: 600; color: #475569;
      text-transform: uppercase; letter-spacing: 0.1em;
      margin-bottom: 0.875rem;
    }

    /* Cards */
    .card {
      background: #141820;
      border: 1px solid #1e2535;
      border-radius: 0.875rem;
      padding: 1.125rem 1.375rem;
      margin-bottom: 0.625rem;
      display: flex;
      gap: 1rem;
      align-items: flex-start;
    }
    .card.overdue    { border-left: 3px solid #ef4444; }
    .card.risk       { border-left: 3px solid #f97316; }
    .card.execution  { border-left: 3px solid #f59e0b; }
    .card.early      { border-left: 3px solid #334155; }
    .card.done       { border-left: 3px solid #22c55e; opacity: 0.55; }

    .card-body { flex: 1; min-width: 0; }
    .card-badges { display: flex; flex-wrap: wrap; gap: 0.375rem; margin-bottom: 0.5rem; }
    .badge {
      font-size: 0.65rem; font-weight: 700; padding: 0.2rem 0.55rem;
      border-radius: 9999px; text-transform: uppercase; letter-spacing: 0.05em;
    }
    .badge.overdue       { background: #450a0a; color: #fca5a5; }
    .badge.risk          { background: #4a1a00; color: #fb923c; }
    .badge.execution     { background: #451a03; color: #fcd34d; }
    .badge.early         { background: #1a2535; color: #94a3b8; }
    .badge.done          { background: #052e16; color: #86efac; }
    .badge.recurring     { background: #0c1a3a; color: #93c5fd; }
    .badge.hard          { background: #1a1a2e; color: #a78bfa; }
    .badge.soft          { background: #1a2535; color: #7dd3fc; }
    .badge.hypothetical  { background: #1a1a1a; color: #64748b; }

    .card-desc { font-size: 0.95rem; color: #e2e8f0; margin-bottom: 0.25rem; font-weight: 500; }
    .card-meta { font-size: 0.78rem; color: #475569; }
    .card-summary { font-size: 0.8rem; color: #64748b; margin-top: 0.5rem; font-style: italic; line-height: 1.4; }

    /* Card actions */
    .card-actions { display: flex; gap: 0.375rem; margin-top: 0.75rem; flex-wrap: wrap; align-items: center; }
    .btn-action {
      font-size: 0.7rem; font-weight: 600;
      padding: 0.25rem 0.625rem; border-radius: 0.375rem;
      border: 1px solid; cursor: pointer; transition: all 0.15s;
      background: none;
    }
    .btn-done    { color: #22c55e; border-color: #14532d; }
    .btn-done:hover { background: #14532d; }
    .btn-snooze  { color: #7dd3fc; border-color: #0c3a5c; }
    .btn-snooze:hover { background: #0c3a5c; }
    .btn-abandon { color: #64748b; border-color: #1e2535; }
    .btn-abandon:hover { color: #ef4444; border-color: #450a0a; }
    .btn-why {
      font-size: 0.7rem; color: #334155; background: none; border: 1px solid #1e2535;
      border-radius: 0.375rem; padding: 0.25rem 0.5rem; cursor: pointer;
      transition: color 0.15s, border-color 0.15s; font-weight: 600;
    }
    .btn-why:hover { color: #94a3b8; border-color: #334155; }

    .why-panel {
      display: none; margin-top: 0.75rem; padding: 0.75rem;
      background: #0b0e14; border-radius: 0.5rem; border: 1px solid #1e2535;
    }
    .why-panel.open { display: block; }
    .why-entry { font-size: 0.75rem; margin-bottom: 0.625rem; }
    .why-entry-header { color: #475569; margin-bottom: 0.2rem; }
    .why-entry-action { font-weight: 600; }
    .why-entry-action.acted { color: #f59e0b; }
    .why-entry-action.suppressed { color: #334155; }
    .why-entry-reason { color: #64748b; line-height: 1.4; }

    .empty { color: #334155; font-size: 0.85rem; padding: 0.75rem 0; }
    footer { font-size: 0.72rem; color: #334155; text-align: right; margin-top: 3rem; }

    /* ── Modal ─────────────────────────────────────────────────────── */
    .overlay {
      display: none; position: fixed; inset: 0;
      background: rgba(0,0,0,0.75); z-index: 100;
      align-items: center; justify-content: center;
    }
    .overlay.open { display: flex; }
    .modal {
      background: #141820; border: 1px solid #1e2535;
      border-radius: 1rem; padding: 2rem;
      width: min(520px, calc(100vw - 2rem));
      max-height: 90vh; overflow-y: auto;
    }
    .modal h2 { font-size: 1.1rem; font-weight: 700; color: #f1f5f9; margin-bottom: 1.5rem; }
    .field { margin-bottom: 1.25rem; }
    .field label { display: block; font-size: 0.75rem; color: #94a3b8; font-weight: 600; margin-bottom: 0.4rem; text-transform: uppercase; letter-spacing: 0.05em; }
    .field input, .field textarea, .field select {
      width: 100%; background: #0b0e14; border: 1px solid #1e2535;
      border-radius: 0.5rem; color: #e2e8f0; padding: 0.625rem 0.875rem;
      font-size: 0.9rem; font-family: inherit;
      transition: border-color 0.15s; outline: none;
    }
    .field input:focus, .field textarea:focus, .field select:focus { border-color: #f59e0b; }
    .field textarea { min-height: 80px; resize: vertical; }
    .field select option { background: #141820; }

    .importance-row { display: flex; align-items: center; gap: 1rem; }
    .importance-row input[type=range] { flex: 1; accent-color: #f59e0b; }
    .importance-val { font-size: 0.875rem; color: #f59e0b; font-weight: 700; width: 2.5rem; text-align: right; }

    .modal-actions { display: flex; gap: 0.75rem; justify-content: flex-end; margin-top: 1.5rem; }
    .btn-cancel {
      background: none; border: 1px solid #1e2535; color: #64748b;
      border-radius: 0.5rem; padding: 0.5rem 1.25rem;
      font-size: 0.875rem; cursor: pointer; transition: all 0.15s;
    }
    .btn-cancel:hover { border-color: #334155; color: #94a3b8; }
    .btn-save {
      background: #f59e0b; color: #0b0e14; border: none;
      border-radius: 0.5rem; padding: 0.5rem 1.5rem;
      font-size: 0.875rem; font-weight: 700; cursor: pointer; transition: all 0.15s;
    }
    .btn-save:hover { background: #fbbf24; }
    .btn-save:disabled { opacity: 0.5; cursor: not-allowed; }

    /* Snooze modal */
    .snooze-options { display: grid; grid-template-columns: 1fr 1fr; gap: 0.5rem; margin-bottom: 1rem; }
    .btn-snooze-opt {
      background: #0b0e14; border: 1px solid #1e2535; color: #94a3b8;
      border-radius: 0.5rem; padding: 0.625rem; font-size: 0.8rem;
      cursor: pointer; transition: all 0.15s; text-align: center;
    }
    .btn-snooze-opt:hover { border-color: #7dd3fc; color: #7dd3fc; }

    .toast {
      position: fixed; bottom: 2rem; right: 2rem;
      background: #1e2535; border: 1px solid #334155;
      border-radius: 0.75rem; padding: 0.75rem 1.25rem;
      font-size: 0.85rem; color: #e2e8f0; z-index: 200;
      opacity: 0; transform: translateY(0.5rem);
      transition: all 0.2s; pointer-events: none;
    }
    .toast.show { opacity: 1; transform: translateY(0); }

    /* ── Notification banner ─────────────────────────────────────── */
    .notif-banner {
      display: none; background: linear-gradient(135deg, #451a03, #78350f);
      border: 1px solid #92400e; border-radius: 0.875rem;
      padding: 1rem 1.25rem; margin-bottom: 1.5rem;
      align-items: center; justify-content: space-between; gap: 1rem;
    }
    .notif-banner.show { display: flex; }
    .notif-banner-text { flex: 1; font-size: 0.85rem; color: #fef3c7; }
    .notif-banner-text strong { color: #fcd34d; display: block; font-size: 0.95rem; margin-bottom: 0.2rem; }
    .btn-enable {
      background: #f59e0b; color: #0b0e14; border: none;
      border-radius: 0.5rem; padding: 0.5rem 1rem;
      font-size: 0.8rem; font-weight: 700; cursor: pointer;
      white-space: nowrap; transition: background 0.15s;
    }
    .btn-enable:hover { background: #fbbf24; }
    .btn-dismiss {
      background: none; border: none; color: #fcd34d;
      font-size: 1.2rem; cursor: pointer; padding: 0.25rem 0.5rem;
      opacity: 0.6; transition: opacity 0.15s;
    }
    .btn-dismiss:hover { opacity: 1; }

    /* iOS install banner */
    .install-hint {
      display: none; font-size: 0.8rem; color: #94a3b8;
      background: #141820; border: 1px dashed #334155;
      border-radius: 0.625rem; padding: 0.75rem 1rem;
      margin-bottom: 1.5rem; line-height: 1.5;
    }
    .install-hint.show { display: block; }
    .install-hint strong { color: #f59e0b; }

    /* ── Natural language input ─────────────────────────────────── */
    .nl-bar { display: flex; gap: 0.5rem; margin-bottom: 1.5rem; }
    .nl-input {
      flex: 1; background: #141820; border: 1px solid #1e2535;
      border-radius: 0.75rem; color: #e2e8f0; padding: 0.75rem 1rem;
      font-size: 0.9rem; font-family: inherit; outline: none;
      transition: border-color 0.15s;
    }
    .nl-input:focus { border-color: #f59e0b; }
    .nl-input::placeholder { color: #334155; }
    .btn-nl {
      flex-shrink: 0; background: #f59e0b; color: #0b0e14; border: none;
      border-radius: 0.75rem; padding: 0.75rem 1.25rem;
      font-size: 1rem; font-weight: 700; cursor: pointer; transition: background 0.15s;
    }
    .btn-nl:hover { background: #fbbf24; }
    .btn-nl:disabled { opacity: 0.5; cursor: not-allowed; }
    .nl-result {
      padding: 0.75rem 1rem; border-radius: 0.625rem;
      background: #141820; border: 1px solid #1e2535;
      font-size: 0.85rem; margin-bottom: 1.5rem; line-height: 1.5;
    }
    .nl-result.success { border-color: #14532d; color: #86efac; }
    .nl-result.error   { border-color: #450a0a; color: #fca5a5; }

    /* ── Integrations section ────────────────────────────────────── */
    .int-card { background: #141820; border: 1px solid #1e2535; border-radius: 0.875rem; padding: 1.25rem 1.5rem; }
    .int-row { display: flex; gap: 0.5rem; align-items: center; margin-bottom: 0.75rem; }
    .int-row:last-child { margin-bottom: 0; }
    .int-label { font-size: 0.8rem; color: #94a3b8; font-weight: 600; width: 6.5rem; flex-shrink: 0; }
    .int-input {
      flex: 1; background: #0b0e14; border: 1px solid #1e2535; border-radius: 0.5rem;
      color: #e2e8f0; padding: 0.5rem 0.75rem; font-size: 0.8rem;
      font-family: inherit; outline: none; transition: border-color 0.15s;
    }
    .int-input:focus { border-color: #f59e0b; }
    .btn-int {
      flex-shrink: 0; background: #1e2535; color: #94a3b8; border: 1px solid #334155;
      border-radius: 0.5rem; padding: 0.45rem 0.875rem;
      font-size: 0.75rem; font-weight: 600; cursor: pointer; transition: all 0.15s;
    }
    .btn-int:hover { background: #334155; color: #e2e8f0; }

    /* ── Feature flags panel ─────────────────────────────────── */
    .features-grid { display: flex; flex-direction: column; gap: 1.5rem; }
    .features-direction { background: #141820; border: 1px solid #1e2535; border-radius: 0.875rem; padding: 1.25rem 1.5rem; }
    .features-direction-label { font-size: 0.7rem; font-weight: 700; color: #475569; text-transform: uppercase; letter-spacing: 0.1em; margin-bottom: 1rem; }
    .feature-row { display: flex; align-items: flex-start; gap: 1rem; padding: 0.625rem 0; border-bottom: 1px solid #1a2535; }
    .feature-row:last-child { border-bottom: none; }
    .feature-text { flex: 1; min-width: 0; }
    .feature-name { font-size: 0.875rem; font-weight: 600; color: #e2e8f0; margin-bottom: 0.2rem; }
    .feature-desc { font-size: 0.75rem; color: #475569; line-height: 1.4; }
    .feature-env-warn { font-size: 0.7rem; color: #f59e0b; margin-top: 0.2rem; }
    .toggle { position: relative; flex-shrink: 0; width: 2.5rem; height: 1.375rem; margin-top: 0.1rem; }
    .toggle input { opacity: 0; width: 0; height: 0; }
    .toggle-track { position: absolute; inset: 0; background: #1e2535; border-radius: 9999px; cursor: pointer; transition: background 0.2s; }
    .toggle input:checked + .toggle-track { background: #f59e0b; }
    .toggle-thumb { position: absolute; top: 0.2rem; left: 0.2rem; width: 1rem; height: 1rem; background: #e2e8f0; border-radius: 50%; pointer-events: none; transition: transform 0.2s; }
    .toggle input:checked ~ .toggle-thumb { transform: translateX(1.125rem); }
    .toggle input:disabled + .toggle-track { opacity: 0.4; cursor: not-allowed; }

    /* ── Mobile ──────────────────────────────────────────────────── */
    @media (max-width: 600px) {
      body { padding: 1rem; }
      header { flex-direction: column; align-items: stretch; }
      .header-left h1 { font-size: 1.4rem; }
      .btn-add { width: 100%; padding: 0.75rem; font-size: 0.95rem; }
      .stats { grid-template-columns: repeat(2, 1fr); gap: 0.625rem; }
      .stat { padding: 0.875rem 1rem; }
      .stat-value { font-size: 1.75rem; }
      .modal { padding: 1.5rem; border-radius: 1rem 1rem 0 0; }
      .overlay { align-items: flex-end; }
      .overlay .modal { width: 100%; max-height: 85vh; }
    }
  </style>
</head>
<body>
  <header>
    <div class="header-left">
      <h1>🔥 Vigil</h1>
      <p class="subtitle" id="subtitle">Loading...</p>
    </div>
    <button class="btn-add" onclick="openAdd()">＋ New commitment</button>
  </header>

  <!-- ── Natural language commitment input ────────────────────── -->
  <div class="nl-bar">
    <input type="text" id="nlInput" class="nl-input"
      placeholder='Try: "remind me to push the PR before EOD" or "call the client tomorrow morning" …'
      onkeydown="if(event.key==='Enter')submitNL()">
    <button class="btn-nl" id="nlBtn" onclick="submitNL()">→</button>
  </div>
  <div class="nl-result" id="nlResult" style="display:none"></div>

  <div class="notif-banner" id="notifBanner">
    <div class="notif-banner-text">
      <strong>Get notified on this device</strong>
      Vigil will push to your phone or browser when a commitment needs attention.
    </div>
    <button class="btn-enable" onclick="enablePush()">Enable</button>
    <button class="btn-dismiss" onclick="dismissBanner()" title="Dismiss">✕</button>
  </div>

  <div class="install-hint" id="installHint">
    💡 <strong>Install on iPhone:</strong> Tap the Share button
    <span style="display:inline-block;width:14px;height:14px;border:1.5px solid #94a3b8;border-radius:3px;position:relative;top:2px"></span>
    then "Add to Home Screen" to get push notifications.
  </div>

  <div class="stats" id="stats"></div>

  <div class="section">
    <div class="section-label">Overdue &amp; At Risk</div>
    <div id="overdue"></div>
  </div>

  <div class="section">
    <div class="section-label">Upcoming</div>
    <div id="upcoming"></div>
  </div>

  <div class="section">
    <div class="section-label">Recently Completed</div>
    <div id="done"></div>
  </div>

  <div class="section">
    <div class="section-label">Integrations</div>
    <div class="int-card">
      <div class="int-row">
        <span class="int-label">Slack</span>
        <input type="url" id="slackWebhook" class="int-input"
          placeholder="https://hooks.slack.com/services/…">
        <button class="btn-int" onclick="saveIntegration('slack')">Save</button>
      </div>
      <div class="int-row">
        <span class="int-label">Discord</span>
        <input type="url" id="discordWebhook" class="int-input"
          placeholder="https://discord.com/api/webhooks/…">
        <button class="btn-int" onclick="saveIntegration('discord')">Save</button>
      </div>
    </div>
  </div>

  <div class="section">
    <div class="section-label">V3 Features</div>
    <div class="features-grid" id="featuresPanel">
      <div class="empty">Loading features...</div>
    </div>
  </div>

  <footer>Auto-refreshes every 30s &nbsp;·&nbsp; <a href="/api/data" style="color:#334155">raw JSON</a></footer>

  <!-- ── Add/Edit Modal ─────────────────────────────────────────── -->
  <div class="overlay" id="addOverlay" onclick="if(event.target===this)closeAdd()">
    <div class="modal">
      <h2 id="modalTitle">New commitment</h2>
      <input type="hidden" id="editId" value="">

      <div class="field">
        <label>What do you want to do?</label>
        <textarea id="f-desc" placeholder="e.g. Push vigil-mcp to GitHub"></textarea>
      </div>
      <div class="field">
        <label>Due by</label>
        <input type="datetime-local" id="f-due">
      </div>
      <div class="field">
        <label>Intent</label>
        <select id="f-intent">
          <option value="hard">Hard — "I will do this"</option>
          <option value="soft">Soft — "I should do this"</option>
          <option value="hypothetical">Hypothetical — "Maybe someday"</option>
        </select>
      </div>
      <div class="field">
        <label>Importance</label>
        <div class="importance-row">
          <input type="range" id="f-imp" min="0.1" max="1.0" step="0.1" value="0.5"
                 oninput="document.getElementById('f-imp-val').textContent=parseFloat(this.value).toFixed(1)">
          <span class="importance-val" id="f-imp-val">0.5</span>
        </div>
      </div>
      <div class="field">
        <label>Context note <span style="color:#334155;text-transform:none;font-weight:400">(optional — helps Vigil surface it intelligently)</span></label>
        <textarea id="f-summary" placeholder="What were you working on? What's the context?" style="min-height:60px"></textarea>
      </div>

      <div class="modal-actions">
        <button class="btn-cancel" onclick="closeAdd()">Cancel</button>
        <button class="btn-save" id="saveBtn" onclick="submitCommitment()">Save commitment</button>
      </div>
    </div>
  </div>

  <!-- ── Snooze Modal ────────────────────────────────────────────── -->
  <div class="overlay" id="snoozeOverlay" onclick="if(event.target===this)closeSnooze()">
    <div class="modal" style="max-width:360px">
      <h2>Snooze commitment</h2>
      <div class="snooze-options">
        <button class="btn-snooze-opt" onclick="doSnooze(1)">Tomorrow</button>
        <button class="btn-snooze-opt" onclick="doSnooze(2)">In 2 days</button>
        <button class="btn-snooze-opt" onclick="doSnooze(7)">Next week</button>
        <button class="btn-snooze-opt" onclick="doSnooze(30)">Next month</button>
      </div>
      <div class="field">
        <label>Or pick a date &amp; time</label>
        <input type="datetime-local" id="snooze-custom">
      </div>
      <div class="modal-actions">
        <button class="btn-cancel" onclick="closeSnooze()">Cancel</button>
        <button class="btn-save" onclick="doSnoozeCustom()">Snooze</button>
      </div>
    </div>
  </div>

  <div class="toast" id="toast"></div>

  <script>
    let _snoozeId = null;

    /* ── Auth: anonymous device ID in localStorage ─────────────────── */
    function getUserId() {
      let id = localStorage.getItem('vigilUserId');
      if (!id) {
        id = 'u_' + (crypto.randomUUID ? crypto.randomUUID() : Math.random().toString(36).slice(2) + Date.now());
        localStorage.setItem('vigilUserId', id);
      }
      return id;
    }
    const USER_ID = getUserId();

    /* Auth token from ?token= query param (set once, stays in URL) */
    const _vigilToken = new URLSearchParams(window.location.search).get('token') || '';

    /* Wrap fetch to always send user-id + auth headers */
    const _origFetch = window.fetch.bind(window);
    window.fetch = (url, opts = {}) => {
      const headers = new Headers(opts.headers || {});
      headers.set('X-Vigil-User-Id', USER_ID);
      if (_vigilToken) headers.set('Authorization', 'Bearer ' + _vigilToken);
      return _origFetch(url, { ...opts, headers });
    };

    function showToast(msg, isError = false) {
      const t = document.getElementById('toast');
      t.textContent = msg;
      t.style.borderColor = isError ? '#450a0a' : '#334155';
      t.classList.add('show');
      setTimeout(() => t.classList.remove('show'), 2800);
    }

    function badge(cls, label) {
      return `<span class="badge ${cls}">${label}</span>`;
    }

    function phaseFor(c) {
      if (!c.due_by) return 'early';
      const due = new Date(c.due_by), now = new Date();
      if (due < now) return 'overdue';
      const h = (due - now) / 3600000;
      return h < 4 ? 'risk' : h < 48 ? 'execution' : 'early';
    }

    function card(c, status) {
      const phase     = status === 'done' ? 'done' : phaseFor(c);
      const recurring = c.recurrence && c.recurrence !== 'none'
        ? badge('recurring', '↻ ' + c.recurrence) : '';
      const intentBadge = c.intent_strength && c.intent_strength !== 'hard'
        ? badge(c.intent_strength, c.intent_strength) : '';
      const summary = c.ai_summary
        ? `<div class="card-summary">${c.ai_summary}</div>` : '';
      const imp = c.importance_score != null
        ? `<span style="font-size:0.72rem;color:#475569;margin-left:0.5rem">importance ${parseFloat(c.importance_score).toFixed(1)}</span>` : '';
      const dateStr = status === 'done'
        ? 'Completed ' + (c.completed_at || '').slice(0, 10)
        : c.due_by
          ? 'Due ' + c.due_by.slice(0, 16).replace('T', ' at ')
          : 'No deadline';
      const panelId = `why-${c.id}`;

      const actions = status !== 'done' ? `
        <div class="card-actions">
          <button class="btn-action btn-done"    onclick="markDone(${c.id})">✓ Done</button>
          <button class="btn-action btn-snooze"  onclick="openSnooze(${c.id})">⏰ Snooze</button>
          <button class="btn-action btn-abandon" onclick="abandon(${c.id})">✕</button>
          <button class="btn-why" onclick="toggleWhy(${c.id}, '${panelId}')">Why? ▾</button>
        </div>
        <div class="why-panel" id="${panelId}"><span style="color:#334155;font-size:0.75rem">Loading...</span></div>
      ` : '';

      return `
        <div class="card ${phase}" id="card-${c.id}">
          <div class="card-body">
            <div class="card-badges">${badge(phase, phase)}${recurring}${intentBadge}</div>
            <div class="card-desc">${c.description}${imp}</div>
            <div class="card-meta">${dateStr} · state: ${c.state || '?'}</div>
            ${summary}${actions}
          </div>
        </div>`;
    }

    async function load() {
      try {
        const r = await fetch('/api/data');
        const d = await r.json();
        const s = d.stats;

        document.getElementById('subtitle').textContent =
          'The AI that stays · Last updated ' + new Date().toLocaleTimeString();

        document.getElementById('stats').innerHTML = `
          <div class="stat">
            <div class="stat-label">Follow-through</div>
            <div class="stat-value amber">${s.follow_through_rate}%</div>
            <div class="rate-bar"><div class="rate-fill" style="width:${s.follow_through_rate}%"></div></div>
          </div>
          <div class="stat">
            <div class="stat-label">Completed</div>
            <div class="stat-value green">${s.completed}</div>
          </div>
          <div class="stat">
            <div class="stat-label">Pending</div>
            <div class="stat-value white">${s.pending}</div>
          </div>
          <div class="stat">
            <div class="stat-label">Overdue</div>
            <div class="stat-value ${s.overdue > 0 ? 'red' : 'white'}">${s.overdue}</div>
          </div>
          <div class="stat">
            <div class="stat-label">Nudges today</div>
            <div class="stat-value ${s.budget_used >= s.budget_limit ? 'red' : 'white'}">${s.budget_used}<span style="font-size:1rem;color:#475569">/${s.budget_limit}</span></div>
          </div>`;

        const overdue   = d.pending.filter(c => phaseFor(c) === 'overdue');
        const risk      = d.pending.filter(c => phaseFor(c) === 'risk');
        const execution = d.pending.filter(c => phaseFor(c) === 'execution');
        const early     = d.pending.filter(c => phaseFor(c) === 'early');

        document.getElementById('overdue').innerHTML =
          [...overdue, ...risk].length
            ? [...overdue, ...risk].map(c => card(c, phaseFor(c))).join('')
            : '<div class="empty">Nothing overdue or at risk.</div>';

        document.getElementById('upcoming').innerHTML =
          [...execution, ...early].length
            ? [...execution, ...early].map(c => card(c, phaseFor(c))).join('')
            : '<div class="empty">Nothing upcoming.</div>';

        document.getElementById('done').innerHTML = d.completed.length
          ? d.completed.map(c => card(c, 'done')).join('')
          : '<div class="empty">No completed commitments yet.</div>';

      } catch (e) {
        document.getElementById('subtitle').textContent = 'Could not load data.';
      }
    }

    async function toggleWhy(id, panelId) {
      const panel = document.getElementById(panelId);
      if (panel.classList.toggle('open') && panel.innerHTML.includes('Loading')) {
        const r = await fetch(`/api/decisions/${id}`);
        const entries = await r.json();
        if (!entries.length) {
          panel.innerHTML = '<span style="color:#334155;font-size:0.75rem">No decisions logged yet.</span>';
          return;
        }
        panel.innerHTML = entries.map(e => {
          const acted = e.action !== 'none';
          const actionLabel = acted ? e.action.replace(/_/g,' ') : 'suppressed';
          const cls = acted ? 'acted' : 'suppressed';
          return `<div class="why-entry">
            <div class="why-entry-header">${e.created_at.slice(0,16).replace('T',' ')} · phase: ${e.phase || '?'} · urgency: ${(e.urgency||0).toFixed(2)} · budget: ${e.budget_used||0}/${e.budget_limit||10}</div>
            <span class="why-entry-action ${cls}">${actionLabel}</span>
            <div class="why-entry-reason">${e.reasoning}</div>
          </div>`;
        }).join('');
      }
    }

    /* ── Add/Edit ─────────────────────────────────────────────────── */
    function openAdd() {
      document.getElementById('modalTitle').textContent = 'New commitment';
      document.getElementById('editId').value = '';
      document.getElementById('f-desc').value = '';
      // default due = tomorrow noon
      const t = new Date(); t.setDate(t.getDate()+1); t.setHours(12,0,0,0);
      document.getElementById('f-due').value = t.toISOString().slice(0,16);
      document.getElementById('f-intent').value = 'hard';
      document.getElementById('f-imp').value = '0.5';
      document.getElementById('f-imp-val').textContent = '0.5';
      document.getElementById('f-summary').value = '';
      document.getElementById('addOverlay').classList.add('open');
      setTimeout(() => document.getElementById('f-desc').focus(), 50);
    }

    function closeAdd() {
      document.getElementById('addOverlay').classList.remove('open');
    }

    async function submitCommitment() {
      const desc = document.getElementById('f-desc').value.trim();
      if (!desc) { document.getElementById('f-desc').focus(); return; }
      const editId = document.getElementById('editId').value;
      const btn = document.getElementById('saveBtn');
      btn.disabled = true;

      const body = {
        description:     desc,
        due_by:          document.getElementById('f-due').value || null,
        intent_strength: document.getElementById('f-intent').value,
        importance_score: parseFloat(document.getElementById('f-imp').value),
        ai_summary:      document.getElementById('f-summary').value.trim(),
      };

      try {
        let r;
        if (editId) {
          r = await fetch(`/api/commitments/${editId}`, {
            method: 'PATCH', headers: {'Content-Type':'application/json'},
            body: JSON.stringify(body),
          });
        } else {
          r = await fetch('/api/commitments', {
            method: 'POST', headers: {'Content-Type':'application/json'},
            body: JSON.stringify({...body, confidence_score: 1.0}),
          });
        }
        if (!r.ok) throw new Error(await r.text());
        closeAdd();
        showToast(editId ? 'Updated ✓' : 'Saved ✓');
        await load();
      } catch(e) {
        showToast('Error: ' + e.message, true);
      } finally {
        btn.disabled = false;
      }
    }

    /* ── Complete ─────────────────────────────────────────────────── */
    async function markDone(id) {
      try {
        const r = await fetch(`/api/commitments/${id}/complete`, { method: 'POST' });
        if (!r.ok) throw new Error(await r.text());
        showToast('Marked complete ✓');
        await load();
      } catch(e) { showToast('Error: ' + e.message, true); }
    }

    /* ── Snooze ───────────────────────────────────────────────────── */
    function openSnooze(id) {
      _snoozeId = id;
      const t = new Date(); t.setDate(t.getDate()+1); t.setHours(9,0,0,0);
      document.getElementById('snooze-custom').value = t.toISOString().slice(0,16);
      document.getElementById('snoozeOverlay').classList.add('open');
    }

    function closeSnooze() {
      document.getElementById('snoozeOverlay').classList.remove('open');
      _snoozeId = null;
    }

    async function doSnooze(days) {
      const t = new Date(); t.setDate(t.getDate()+days); t.setHours(9,0,0,0);
      await _snoozeCommitment(_snoozeId, t.toISOString().slice(0,19));
    }

    async function doSnoozeCustom() {
      const val = document.getElementById('snooze-custom').value;
      if (!val) return;
      await _snoozeCommitment(_snoozeId, val);
    }

    async function _snoozeCommitment(id, until) {
      try {
        const r = await fetch(`/api/commitments/${id}/snooze`, {
          method: 'POST', headers: {'Content-Type':'application/json'},
          body: JSON.stringify({ snooze_until: until }),
        });
        if (!r.ok) throw new Error(await r.text());
        closeSnooze();
        showToast('Snoozed ⏰');
        await load();
      } catch(e) { showToast('Error: ' + e.message, true); }
    }

    /* ── Abandon ──────────────────────────────────────────────────── */
    async function abandon(id) {
      if (!confirm('Archive this commitment?')) return;
      try {
        const r = await fetch(`/api/commitments/${id}`, { method: 'DELETE' });
        if (!r.ok) throw new Error(await r.text());
        showToast('Archived');
        await load();
      } catch(e) { showToast('Error: ' + e.message, true); }
    }

    /* ── Natural language commitment creation ───────────────────── */
    async function submitNL() {
      const input  = document.getElementById('nlInput');
      const btn    = document.getElementById('nlBtn');
      const result = document.getElementById('nlResult');
      const text   = input.value.trim();
      if (!text) return;
      btn.disabled = true; btn.textContent = '…';
      result.style.display = 'none';
      try {
        const r = await fetch('/api/nl', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ text }),
        });
        const d = await r.json();
        if (r.ok) {
          result.textContent = d.message;
          result.className = 'nl-result success';
          input.value = '';
          await load();
        } else {
          result.textContent = d.error || 'Failed to parse.';
          result.className = 'nl-result error';
        }
      } catch(e) {
        result.textContent = 'Error: ' + e.message;
        result.className = 'nl-result error';
      } finally {
        result.style.display = 'block';
        btn.disabled = false; btn.textContent = '→';
      }
    }

    /* ── Integrations ────────────────────────────────────────────── */
    async function loadSettings() {
      try {
        const r = await fetch('/api/settings');
        if (!r.ok) return;
        const d = await r.json();
        if (d.slack_webhook_url)   document.getElementById('slackWebhook').value   = d.slack_webhook_url;
        if (d.discord_webhook_url) document.getElementById('discordWebhook').value = d.discord_webhook_url;
      } catch(e) { /* non-critical */ }
    }

    async function saveIntegration(platform) {
      const inputId = platform === 'slack' ? 'slackWebhook' : 'discordWebhook';
      const url = document.getElementById(inputId).value.trim();
      try {
        const r = await fetch('/api/settings/integration', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ platform, url }),
        });
        const d = await r.json();
        if (r.ok) {
          showToast(d.message || 'Saved ✓');
        } else {
          showToast(d.error || 'Failed to save.', true);
        }
      } catch(e) {
        showToast('Error: ' + e.message, true);
      }
    }

    /* ── V3 Feature flags ────────────────────────────────────── */
    const DIRECTION_LABELS = { context_awareness: 'Context Awareness', multi_person: 'Multi-Person / Team', adaptive: 'Adaptive' };

    async function loadFeatures() {
      try {
        const r = await fetch('/api/features');
        if (!r.ok) return;
        const { features } = await r.json();
        const groups = {};
        for (const f of features) { if (!groups[f.direction]) groups[f.direction] = []; groups[f.direction].push(f); }
        const panel = document.getElementById('featuresPanel');
        panel.innerHTML = Object.entries(groups).map(([dir, items]) => `
          <div class="features-direction">
            <div class="features-direction-label">${DIRECTION_LABELS[dir] || dir}</div>
            ${items.map(f => {
              const warn = f.missing_env && f.missing_env.length ? `<div class="feature-env-warn">⚠ Needs: ${f.missing_env.join(', ')}</div>` : '';
              return `<div class="feature-row">
                <div class="feature-text">
                  <div class="feature-name">${f.label}</div>
                  <div class="feature-desc">${f.description}</div>${warn}
                </div>
                <label class="toggle">
                  <input type="checkbox" id="feat-${f.name}" ${f.toggled_on ? 'checked' : ''}
                    onchange="toggleFeature('${f.name}', this.checked)">
                  <span class="toggle-track"></span>
                  <span class="toggle-thumb"></span>
                </label>
              </div>`;
            }).join('')}
          </div>`).join('');
      } catch(e) {
        document.getElementById('featuresPanel').innerHTML = '<div class="empty">Could not load features.</div>';
      }
    }

    async function toggleFeature(name, enabled) {
      try {
        const r = await fetch('/api/settings/feature', {
          method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ name, enabled }),
        });
        const d = await r.json();
        if (r.ok) { showToast(d.message || (enabled ? 'Enabled' : 'Disabled')); await loadFeatures(); }
        else { showToast(d.error || 'Failed.', true); const el = document.getElementById(`feat-${name}`); if (el) el.checked = !enabled; }
      } catch(e) { showToast('Error: ' + e.message, true); }
    }

    load();
    loadSettings();
    loadFeatures();
    setInterval(load, 30000);

    /* ── PWA install + Web Push ──────────────────────────────────── */
    const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent) && !window.MSStream;
    const isStandalone = window.matchMedia('(display-mode: standalone)').matches ||
                         window.navigator.standalone === true;

    // Register service worker
    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.register('/service-worker.js').catch(e => console.warn('SW:', e));
      navigator.serviceWorker.addEventListener('message', (e) => {
        if (e.data && e.data.type === 'navigate') window.location.href = e.data.url;
      });
    }

    async function maybeShowNotifBanner() {
      // Don't show on browsers with no support at all
      if (!('serviceWorker' in navigator) || !('PushManager' in window)) {
        // iOS Safari without PWA install — show install hint instead
        if (isIOS && !isStandalone) {
          document.getElementById('installHint').classList.add('show');
        }
        return;
      }
      if (localStorage.getItem('vigilNotifDismissed')) return;
      if (Notification.permission === 'granted') {
        // Already granted — make sure we have a live subscription
        await ensureSubscription();
        return;
      }
      if (Notification.permission === 'default') {
        document.getElementById('notifBanner').classList.add('show');
      }
    }

    function dismissBanner() {
      localStorage.setItem('vigilNotifDismissed', '1');
      document.getElementById('notifBanner').classList.remove('show');
    }

    async function enablePush() {
      try {
        const perm = await Notification.requestPermission();
        if (perm !== 'granted') {
          showToast('Notifications blocked. Enable in browser settings.', true);
          return;
        }
        await ensureSubscription();
        document.getElementById('notifBanner').classList.remove('show');
        showToast('Notifications enabled 🔔');
      } catch (e) {
        showToast('Error: ' + e.message, true);
      }
    }

    async function ensureSubscription() {
      const reg = await navigator.serviceWorker.ready;
      let sub = await reg.pushManager.getSubscription();
      if (!sub) {
        const r = await fetch('/api/vapid-public-key');
        const { key } = await r.json();
        if (!key) {
          console.info('Web Push not configured on server');
          return;
        }
        sub = await reg.pushManager.subscribe({
          userVisibleOnly: true,
          applicationServerKey: urlB64ToUint8(key),
        });
      }
      const json = sub.toJSON();
      await fetch('/api/push/subscribe', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          endpoint: json.endpoint,
          p256dh: json.keys.p256dh,
          auth: json.keys.auth,
        }),
      });
    }

    function urlB64ToUint8(b64) {
      const padding = '='.repeat((4 - b64.length % 4) % 4);
      const base64 = (b64 + padding).replace(/-/g, '+').replace(/_/g, '/');
      const raw = atob(base64);
      return Uint8Array.from([...raw].map(c => c.charCodeAt(0)));
    }

    maybeShowNotifBanner();
  </script>
</body>
</html>"""


def _make_handler(db):
    class Handler(BaseHTTPRequestHandler):
        def _json(self, data, status=200):
            body = json.dumps(data, default=str).encode()
            self.send_response(status)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Access-Control-Allow-Origin", "*")
            self.end_headers()
            self.wfile.write(body)

        def _static(self, content: str, content_type: str):
            body = content.encode()
            self.send_response(200)
            self.send_header("Content-Type", content_type)
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "public, max-age=3600")
            self.end_headers()
            self.wfile.write(body)

        def _read_body(self):
            length = int(self.headers.get("Content-Length", 0))
            return json.loads(self.rfile.read(length)) if length else {}

        def _user_id(self) -> str:
            """Read user ID from header; default to 'local' for backward compat."""
            uid = self.headers.get("X-Vigil-User-Id", "local")
            if uid != "local":
                db.ensure_user(uid)
            return uid

        def _check_auth(self) -> bool:
            import os
            token = os.environ.get("VIGIL_SECRET_TOKEN")
            if not token:
                return True  # local mode — no auth required
            auth_header = self.headers.get("Authorization", "")
            if auth_header == f"Bearer {token}":
                return True
            # Also accept ?token= query param (for bookmarkable dashboard URLs)
            from urllib.parse import parse_qs
            qs = parse_qs(urlparse(self.path).query)
            return qs.get("token", [""])[0] == token

        def _send_auth_error(self):
            body = b'{"error": "Unauthorized. Pass Authorization: Bearer <VIGIL_SECRET_TOKEN> or ?token= query param."}'
            self.send_response(401)
            self.send_header("Content-Type", "application/json")
            self.send_header("WWW-Authenticate", 'Bearer realm="Vigil"')
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Access-Control-Allow-Origin", "*")
            self.end_headers()
            self.wfile.write(body)

        def do_OPTIONS(self):
            self.send_response(204)
            self.send_header("Access-Control-Allow-Origin", "*")
            self.send_header("Access-Control-Allow-Methods", "GET,POST,PATCH,DELETE,OPTIONS")
            self.send_header("Access-Control-Allow-Headers", "Content-Type, X-Vigil-User-Id, Authorization")
            self.end_headers()

        def do_GET(self):
            path = urlparse(self.path).path

            # ── Static PWA assets ──
            if path == "/manifest.json":
                self._static(MANIFEST, "application/manifest+json"); return
            if path == "/service-worker.js":
                self._static(SERVICE_WORKER, "application/javascript"); return
            if path == "/icon-192.svg":
                self._static(ICON_SVG_192, "image/svg+xml"); return
            if path == "/icon-512.svg":
                self._static(ICON_SVG_512, "image/svg+xml"); return

            # ── Auth gate (static assets above are always public) ──
            if not self._check_auth():
                self._send_auth_error(); return

            # ── VAPID public key (so frontend can subscribe) ──
            if path == "/api/vapid-public-key":
                self._json({"key": push_mod.get_public_key()}); return

            # ── Data endpoints (scoped to user) ──
            uid = self._user_id()
            if path == "/api/data":
                self._json({
                    "stats":     db.get_stats(user_id=uid),
                    "pending":   db.get_pending(user_id=uid),
                    "completed": db.get_completed(limit=10, user_id=uid),
                })
            elif path.startswith("/api/decisions/"):
                try:
                    cid = int(path.split("/")[-1])
                    # Verify commitment belongs to this user
                    c = db.get_by_id(cid)
                    if c and c.get("user_id", "local") != uid:
                        self._json({"error": "forbidden"}, 403); return
                    self._json(db.get_decision_history(cid, limit=10))
                except (ValueError, IndexError):
                    self._json({"error": "bad id"}, 400)
            elif path == "/api/settings":
                self._json({
                    "slack_webhook_url":    db.get_setting("slack_webhook_url",    user_id=uid),
                    "discord_webhook_url":  db.get_setting("discord_webhook_url",  user_id=uid),
                    "slack_nudge_enabled":  db.get_setting("slack_nudge_enabled",  default="true", user_id=uid),
                    "discord_nudge_enabled":db.get_setting("discord_nudge_enabled",default="true", user_id=uid),
                    "attention_budget":     db.get_budget_limit(user_id=uid),
                    "digest_time":          db.get_setting("digest_time", user_id=uid),
                })
            elif path == "/api/features":
                try:
                    from .features import get_all_status
                    self._json({"features": get_all_status(db, user_id=uid)})
                except Exception as e:
                    self._json({"error": str(e)}, 500)
            elif path == "/api/signals":
                hours = 24
                from urllib.parse import parse_qs
                qs = parse_qs(urlparse(self.path).query)
                if "hours" in qs:
                    try: hours = int(qs["hours"][0])
                    except ValueError: pass
                self._json({"signals": db.get_recent_signals(hours=hours, user_id=uid)})
            else:
                body = HTML.encode()
                self.send_response(200)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)

        def _owns(self, cid: int, uid: str) -> bool:
            c = db.get_by_id(cid)
            return c is not None and c.get("user_id", "local") == uid

        def do_POST(self):
            path = urlparse(self.path).path

            # Slack slash commands use their own signing secret — skip our token check
            if path != "/api/slack/command" and not self._check_auth():
                self._send_auth_error(); return

            uid = self._user_id()

            # POST /api/nl — natural language commitment creation
            if path == "/api/nl":
                body = self._read_body()
                text = body.get("text", "").strip()
                if not text:
                    self._json({"error": "text required"}, 400); return
                try:
                    from .analyzer import parse_commitment_from_text
                    parsed = parse_commitment_from_text(text)
                except RuntimeError as e:
                    self._json({"error": f"NL parsing not available: {e}. Set ANTHROPIC_API_KEY."}, 503); return
                except ImportError as e:
                    self._json({"error": str(e)}, 503); return
                except Exception as e:
                    self._json({"error": f"Parse failed: {str(e)[:100]}"}, 500); return
                if parsed is None:
                    self._json({"error": "That doesn't look like a commitment. Try: 'remind me to X by Y'"}, 400); return
                cid = db.save_commitment(
                    description=parsed["description"],
                    due_by=parsed["due_by"],
                    context=parsed["context"],
                    ai_summary=parsed["ai_summary"],
                    intent_strength=parsed["intent_strength"],
                    confidence_score=1.0,
                    importance_score=parsed["importance_score"],
                    user_id=uid,
                )
                due_str = f" — due {parsed['due_by']}" if parsed["due_by"] else ""
                self._json({
                    "id": cid,
                    "message": f"Saved: '{parsed['description']}'{due_str} (ID: {cid})",
                    "parsed": parsed,
                }, 201)
                return

            # POST /api/push/subscribe — register a device for Web Push
            if path == "/api/push/subscribe":
                body = self._read_body()
                endpoint = body.get("endpoint", "")
                p256dh   = body.get("p256dh", "")
                auth     = body.get("auth", "")
                if not endpoint or not p256dh or not auth:
                    self._json({"error": "endpoint, p256dh, auth required"}, 400); return
                db.save_push_subscription(uid, endpoint, p256dh, auth)
                self._json({"message": "subscribed"})
                return

            # POST /api/signals — ingest a behavioral signal from any external system
            if path == "/api/signals":
                body = self._read_body()
                entity_id = body.get("entity_id", "").strip()
                event     = body.get("event", "").strip()
                if not entity_id or not event:
                    self._json({"error": "entity_id and event required"}, 400); return
                sid = db.save_signal(
                    entity_id=entity_id,
                    event=event,
                    entity_type=body.get("entity_type", "lead"),
                    metadata=body.get("metadata") or {},
                    user_id=uid,
                )
                self._json({"id": sid, "message": f"Signal {sid} recorded."}, 201)
                return

            # POST /api/commitments  → save new (scoped to this user)
            if path == "/api/commitments":
                body = self._read_body()
                desc = body.get("description", "").strip()
                if not desc:
                    self._json({"error": "description required"}, 400)
                    return
                due_by = body.get("due_by") or ""
                cid = db.save_commitment(
                    description=desc,
                    due_by=due_by,
                    context=body.get("context", ""),
                    ai_summary=body.get("ai_summary", ""),
                    intent_strength=body.get("intent_strength", "hard"),
                    confidence_score=float(body.get("confidence_score", 1.0)),
                    importance_score=float(body.get("importance_score", 0.5)),
                    recurrence=body.get("recurrence", "none"),
                    recurrence_days=body.get("recurrence_days") or [],
                    recurrence_time=body.get("recurrence_time", ""),
                    user_id=uid,
                )
                self._json({"id": cid, "message": f"Saved commitment {cid}."}, 201)
                return

            parts = path.strip("/").split("/")

            # POST /api/commitments/{id}/complete
            if len(parts) == 4 and parts[0] == "api" and parts[1] == "commitments" and parts[3] == "complete":
                try:
                    cid = int(parts[2])
                except ValueError:
                    self._json({"error": "bad id"}, 400); return
                if not self._owns(cid, uid):
                    self._json({"error": "not found"}, 404); return
                new_id = db.complete_commitment(cid)
                db.log_decision(cid, "dashboard_completed", "completed", "none", "Marked complete via dashboard.")
                result = {"message": f"Commitment {cid} complete."}
                if new_id:
                    result["next_id"] = new_id
                self._json(result)
                return

            # POST /api/commitments/{id}/snooze
            if len(parts) == 4 and parts[0] == "api" and parts[1] == "commitments" and parts[3] == "snooze":
                try:
                    cid = int(parts[2])
                except ValueError:
                    self._json({"error": "bad id"}, 400); return
                if not self._owns(cid, uid):
                    self._json({"error": "not found"}, 404); return
                body = self._read_body()
                until = body.get("snooze_until", "")
                if not until:
                    self._json({"error": "snooze_until required"}, 400); return
                db.snooze_commitment(cid, until)
                db.log_decision(cid, "dashboard_snoozed", "snoozed", "none", f"Snoozed via dashboard until {until}.")
                self._json({"message": f"Snoozed until {until}."})
                return

            # POST /api/settings/integration — save Slack or Discord webhook URL
            if path == "/api/settings/integration":
                body = self._read_body()
                platform = body.get("platform", "")
                url = body.get("url", "").strip()
                if platform == "slack":
                    if url and not url.startswith("https://hooks.slack.com/"):
                        self._json({"error": "Invalid Slack webhook URL"}, 400); return
                    db.set_setting("slack_webhook_url", url, user_id=uid)
                    db.set_setting("slack_nudge_enabled", "true" if url else "false", user_id=uid)
                elif platform == "discord":
                    if url and not url.startswith("https://discord.com/api/webhooks/"):
                        self._json({"error": "Invalid Discord webhook URL"}, 400); return
                    db.set_setting("discord_webhook_url", url, user_id=uid)
                    db.set_setting("discord_nudge_enabled", "true" if url else "false", user_id=uid)
                else:
                    self._json({"error": "platform must be 'slack' or 'discord'"}, 400); return
                label = platform.capitalize()
                self._json({"message": f"{label} integration {'saved' if url else 'cleared'}."})
                return

            # POST /api/settings/feature — toggle a V3 feature flag
            if path == "/api/settings/feature":
                body = self._read_body()
                name    = body.get("name", "").strip()
                enabled = bool(body.get("enabled", False))
                if not name:
                    self._json({"error": "name required"}, 400); return
                try:
                    from .features import set_enabled, FEATURES
                except ImportError as e:
                    self._json({"error": str(e)}, 503); return
                if name not in FEATURES:
                    self._json({"error": f"Unknown feature '{name}'", "available": list(FEATURES.keys())}, 400); return
                set_enabled(name, enabled, db, user_id=uid)
                feat = FEATURES[name]
                import os as _os
                missing = [v for v in feat.requires_env if not _os.environ.get(v)]
                if missing and enabled:
                    self._json({"message": f"'{feat.label}' toggled on, needs: {', '.join(missing)}", "warning": True}); return
                self._json({"message": f"'{feat.label}' {'enabled' if enabled else 'disabled'}."})
                return

            # POST /api/slack/command — inbound Slack slash commands
            # Note: auth is Slack's own signing secret, not VIGIL_SECRET_TOKEN
            if path == "/api/slack/command":
                import os as _os
                length = int(self.headers.get("Content-Length", 0))
                raw_body = self.rfile.read(length)

                signing_secret = _os.environ.get("VIGIL_SLACK_SIGNING_SECRET", "")
                if signing_secret:
                    from .webhooks import verify_slack_signature
                    ts  = self.headers.get("X-Slack-Request-Timestamp", "")
                    sig = self.headers.get("X-Slack-Signature", "")
                    if not verify_slack_signature(signing_secret, ts, raw_body, sig):
                        self._json({"text": "Invalid request signature."}, 403); return

                from .webhooks import parse_slack_slash_command, slack_response
                cmd  = parse_slack_slash_command(raw_body)
                text = cmd["text"].strip()

                if not text or text.lower() in ("help", "--help"):
                    self._json(slack_response(
                        "Usage: `/vigil <natural language>`\n"
                        "Example: `/vigil remind me to push the PR before EOD`\n"
                        "Example: `/vigil I need to call the client tomorrow morning`"
                    ))
                    return

                try:
                    from .analyzer import parse_commitment_from_text
                    parsed = parse_commitment_from_text(text)
                except RuntimeError as e:
                    self._json(slack_response(f"NL parsing not available: {e}")); return
                except Exception as e:
                    self._json(slack_response(f"Error: {str(e)[:100]}")); return

                if parsed is None:
                    self._json(slack_response(
                        "That doesn't look like a commitment. "
                        "Try: `/vigil remind me to X by Y`"
                    ))
                    return

                slack_user_id = f"slack_{cmd['user_id']}"
                cid = db.save_commitment(
                    description=parsed["description"],
                    due_by=parsed["due_by"],
                    context=parsed["context"],
                    ai_summary=parsed["ai_summary"],
                    intent_strength=parsed["intent_strength"],
                    confidence_score=1.0,
                    importance_score=parsed["importance_score"],
                    user_id=slack_user_id,
                )
                due_str = f"\nDue: {parsed['due_by']}" if parsed["due_by"] else ""
                self._json(slack_response(
                    f"Saved: *{parsed['description']}*{due_str}\n"
                    f"Intent: {parsed['intent_strength']} · Importance: {parsed['importance_score']:.1f} "
                    f"(ID: {cid})",
                    response_type="in_channel",
                ))
                return

            self._json({"error": "not found"}, 404)

        def do_PATCH(self):
            path = urlparse(self.path).path
            if not self._check_auth():
                self._send_auth_error(); return
            uid = self._user_id()
            parts = path.strip("/").split("/")
            # PATCH /api/commitments/{id}
            if len(parts) == 3 and parts[0] == "api" and parts[1] == "commitments":
                try:
                    cid = int(parts[2])
                except ValueError:
                    self._json({"error": "bad id"}, 400); return
                if not self._owns(cid, uid):
                    self._json({"error": "not found"}, 404); return
                body = self._read_body()
                db.update_commitment(
                    commitment_id=cid,
                    description=body.get("description"),
                    due_by=body.get("due_by"),
                    importance_score=body.get("importance_score"),
                    intent_strength=body.get("intent_strength"),
                    ai_summary=body.get("ai_summary"),
                )
                db.log_decision(cid, "dashboard_updated", "updated", "none", "Edited via dashboard.")
                self._json({"message": f"Updated commitment {cid}."})
                return
            self._json({"error": "not found"}, 404)

        def do_DELETE(self):
            path = urlparse(self.path).path
            if not self._check_auth():
                self._send_auth_error(); return
            uid = self._user_id()
            parts = path.strip("/").split("/")

            # DELETE /api/push/subscribe?endpoint=...
            if path.startswith("/api/push/subscribe"):
                body = self._read_body()
                endpoint = body.get("endpoint", "")
                if endpoint:
                    db.delete_push_subscription(endpoint)
                self._json({"message": "unsubscribed"}); return

            # DELETE /api/commitments/{id}
            if len(parts) == 3 and parts[0] == "api" and parts[1] == "commitments":
                try:
                    cid = int(parts[2])
                except ValueError:
                    self._json({"error": "bad id"}, 400); return
                if not self._owns(cid, uid):
                    self._json({"error": "not found"}, 404); return
                db.abandon_commitment(cid)
                self._json({"message": f"Commitment {cid} abandoned."})
                return
            self._json({"error": "not found"}, 404)

        def log_message(self, *args):
            pass  # silence access logs

    return Handler


class _ReusableHTTPServer(HTTPServer):
    allow_reuse_address = True


def start_dashboard(db):
    handler = _make_handler(db)
    for port in range(PORT, PORT + 10):
        try:
            server = _ReusableHTTPServer(("localhost", port), handler)
            thread = threading.Thread(target=server.serve_forever, daemon=True)
            thread.start()
            return port
        except OSError:
            continue
    return None
