from __future__ import annotations
import os
from dataclasses import dataclass, field
from typing import TYPE_CHECKING
if TYPE_CHECKING:
    from .db import Database


@dataclass
class FeatureDef:
    name: str
    label: str
    description: str
    direction: str  # "context_awareness" | "multi_person" | "adaptive"
    requires_env: list[str] = field(default_factory=list)


FEATURES: dict[str, FeatureDef] = {
    "github_integration": FeatureDef(
        "github_integration", "GitHub Integration",
        "Auto-create commitments from stale PRs and review inactivity.",
        "context_awareness", ["GITHUB_TOKEN"],
    ),
    "calendar_sync": FeatureDef(
        "calendar_sync", "Calendar Sync",
        "Surface commitments before related calendar meetings.",
        "context_awareness", ["GOOGLE_CALENDAR_TOKEN"],
    ),
    "idle_detection": FeatureDef(
        "idle_detection", "Idle Detection",
        "Escalate to push when no Claude session detected for N hours.",
        "context_awareness", [],
    ),
    "accountability_partners": FeatureDef(
        "accountability_partners", "Accountability Partners",
        "Ping a Slack user if a tagged commitment is missed.",
        "multi_person", ["VIGIL_SLACK_BOT_TOKEN"],
    ),
    "shared_commitments": FeatureDef(
        "shared_commitments", "Shared Commitments",
        "Team-visible commitments with collective nudges via Slack.",
        "multi_person", ["VIGIL_SLACK_BOT_TOKEN"],
    ),
    "adaptive_policy": FeatureDef(
        "adaptive_policy", "Adaptive Policy",
        "Learn per-category follow-through patterns and adjust importance thresholds.",
        "adaptive", [],
    ),
    "reliability_reports": FeatureDef(
        "reliability_reports", "Reliability Reports",
        "Weekly summary of follow-through rate broken down by category.",
        "adaptive", [],
    ),
}

DIRECTIONS = {
    "context_awareness": "Context Awareness",
    "multi_person":      "Multi-Person / Team",
    "adaptive":          "Adaptive",
}


def _key(name: str) -> str:
    return f"feature:{name}"


def is_enabled(name: str, db: "Database", user_id: str = "local") -> bool:
    if name not in FEATURES:
        return False
    feat = FEATURES[name]
    if any(not os.environ.get(v) for v in feat.requires_env):
        return False
    return db.get_setting(_key(name), default="false", user_id=user_id) == "true"


def set_enabled(name: str, enabled: bool, db: "Database", user_id: str = "local") -> bool:
    if name not in FEATURES:
        return False
    db.set_setting(_key(name), "true" if enabled else "false", user_id=user_id)
    return True


def get_all_status(db: "Database", user_id: str = "local") -> list[dict]:
    result = []
    for feat in FEATURES.values():
        raw = db.get_setting(_key(feat.name), default="false", user_id=user_id)
        toggled_on = raw == "true"
        missing_env = [v for v in feat.requires_env if not os.environ.get(v)]
        result.append({
            "name":         feat.name,
            "label":        feat.label,
            "description":  feat.description,
            "direction":    feat.direction,
            "enabled":      toggled_on and not missing_env,
            "toggled_on":   toggled_on,
            "requires_env": feat.requires_env,
            "missing_env":  missing_env,
        })
    return result
