"""
reliability_reports.py — Reliability Reports: Weekly summary of follow-through rate broken down by category.

How it works:
- Fires every Monday at REPORT_HOUR (default 09:00 local time).
- Deduped by ISO year-week so it won't re-fire even if the loop runs multiple times.
- Queries the last 7 days of completed/abandoned commitments, groups by context.
- Sends via the full notification stack (push → webhooks → desktop).

Required env vars: none
"""
from __future__ import annotations
import os
from datetime import datetime, timedelta
from typing import TYPE_CHECKING
if TYPE_CHECKING:
    from ..db import Database
from .. import logger as log

FEATURE_NAME = "reliability_reports"

_REPORT_WEEKDAY  = 0   # Monday (0=Mon … 6=Sun)
_REPORT_HOUR     = int(os.environ.get("VIGIL_REPORT_HOUR", "9"))
_LOOKBACK_DAYS   = 7
_SETTING_LAST_WEEK = "reliability_report_week"


def run(db: "Database", user_id: str = "local") -> None:
    try:
        from ..features import is_enabled
    except ImportError:
        return
    if not is_enabled(FEATURE_NAME, db, user_id=user_id):
        return

    now = datetime.now()
    if not _should_send_report(db, now, user_id):
        return

    report_text = _build_weekly_report(db, user_id, now)
    if not report_text:
        return

    try:
        from ..notify import send_notification
        send_notification(db, "Vigil — Weekly Report", report_text, user_id=user_id)
    except Exception as e:
        log.schedule.warning(log.kv(event="report_notify_error", error=repr(str(e))[:80]))
        return

    _mark_report_sent(db, now, user_id)
    log.schedule.info(log.kv(event="reliability_report_sent", user=user_id, week=_iso_week(now)))


def _should_send_report(db: "Database", now: datetime, user_id: str) -> bool:
    """Return True only if it's Monday at/after REPORT_HOUR and not yet sent this week."""
    if now.weekday() != _REPORT_WEEKDAY:
        return False
    if now.hour < _REPORT_HOUR:
        return False
    current_week = _iso_week(now)
    return db.get_setting(_SETTING_LAST_WEEK, user_id=user_id) != current_week


def _build_weekly_report(db: "Database", user_id: str, now: datetime) -> str:
    """Build a human-readable weekly follow-through report."""
    since = (now - timedelta(days=_LOOKBACK_DAYS)).isoformat()

    if user_id == "local":
        rows = db.conn.execute(
            """SELECT context,
                      SUM(CASE WHEN completed_at IS NOT NULL THEN 1 ELSE 0 END) AS completed,
                      SUM(CASE WHEN state = 'abandoned' THEN 1 ELSE 0 END) AS abandoned
               FROM commitments
               WHERE (user_id = 'local' OR user_id IS NULL)
                 AND (completed_at >= ? OR (state = 'abandoned' AND created_at >= ?))
               GROUP BY COALESCE(NULLIF(context, ''), 'uncategorised')
               ORDER BY completed DESC""",
            (since, since),
        ).fetchall()
        total_row = db.conn.execute(
            """SELECT SUM(CASE WHEN completed_at IS NOT NULL THEN 1 ELSE 0 END) AS completed,
                      SUM(CASE WHEN state = 'abandoned' THEN 1 ELSE 0 END) AS abandoned
               FROM commitments
               WHERE (user_id = 'local' OR user_id IS NULL)
                 AND (completed_at >= ? OR (state = 'abandoned' AND created_at >= ?))""",
            (since, since),
        ).fetchone()
        pending_count = db.conn.execute(
            """SELECT COUNT(*) FROM commitments
               WHERE (user_id = 'local' OR user_id IS NULL)
                 AND completed_at IS NULL AND state != 'abandoned'""",
        ).fetchone()[0]
    else:
        rows = db.conn.execute(
            """SELECT context,
                      SUM(CASE WHEN completed_at IS NOT NULL THEN 1 ELSE 0 END) AS completed,
                      SUM(CASE WHEN state = 'abandoned' THEN 1 ELSE 0 END) AS abandoned
               FROM commitments
               WHERE user_id = ?
                 AND (completed_at >= ? OR (state = 'abandoned' AND created_at >= ?))
               GROUP BY COALESCE(NULLIF(context, ''), 'uncategorised')
               ORDER BY completed DESC""",
            (user_id, since, since),
        ).fetchall()
        total_row = db.conn.execute(
            """SELECT SUM(CASE WHEN completed_at IS NOT NULL THEN 1 ELSE 0 END) AS completed,
                      SUM(CASE WHEN state = 'abandoned' THEN 1 ELSE 0 END) AS abandoned
               FROM commitments
               WHERE user_id = ?
                 AND (completed_at >= ? OR (state = 'abandoned' AND created_at >= ?))""",
            (user_id, since, since),
        ).fetchone()
        pending_count = db.conn.execute(
            """SELECT COUNT(*) FROM commitments
               WHERE user_id = ? AND completed_at IS NULL AND state != 'abandoned'""",
            (user_id,),
        ).fetchone()[0]

    total_completed = total_row["completed"] or 0
    total_abandoned = total_row["abandoned"] or 0
    total_resolved  = total_completed + total_abandoned
    overall_rate    = round(total_completed / total_resolved * 100) if total_resolved else 0

    if total_resolved == 0:
        return f"No completed or archived commitments in the past 7 days. {pending_count} still pending."

    lines = [
        f"Past 7 days: {total_completed}/{total_resolved} done ({overall_rate}%)",
        f"{pending_count} still pending",
    ]

    category_lines = []
    for row in rows:
        cat       = row["context"] or "uncategorised"
        completed = row["completed"] or 0
        abandoned = row["abandoned"] or 0
        resolved  = completed + abandoned
        if resolved == 0:
            continue
        rate = round(completed / resolved * 100)
        flag = "⚠" if rate < 50 else "✓"
        category_lines.append(f"  {flag} {cat}: {completed}/{resolved} ({rate}%)")

    if category_lines:
        lines.append("By category:")
        lines.extend(category_lines)

    return "\n".join(lines)


def _mark_report_sent(db: "Database", now: datetime, user_id: str) -> None:
    db.set_setting(_SETTING_LAST_WEEK, _iso_week(now), user_id=user_id)


def _iso_week(dt: datetime) -> str:
    """Return ISO year-week string like '2026-W20'."""
    iso = dt.isocalendar()
    return f"{iso.year}-W{iso.week:02d}"
