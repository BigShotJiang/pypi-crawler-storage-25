from __future__ import annotations
import importlib
from typing import TYPE_CHECKING
if TYPE_CHECKING:
    from ..db import Database


def run_all_integrations(db: "Database", user_id: str = "local") -> None:
    for name in [
        "github_integration",
        "calendar_sync",
        "idle_detection",
        "accountability_partners",
        "shared_commitments",
        "adaptive_policy",
        "reliability_reports",
    ]:
        _run_one(name, db, user_id)


def _run_one(feature_name: str, db: "Database", user_id: str) -> None:
    try:
        mod = importlib.import_module(f".{feature_name}", package=__name__)
        mod.run(db=db, user_id=user_id)
    except Exception:
        pass  # each module logs its own errors; don't crash the loop
