"""
idle_detection.py — Idle Detection: Escalate to push when no Claude session detected for N hours.

How it works:
- `vigil://pending` records `idle_heartbeat` every time Claude opens a session.
- This integration checks how long ago that was; if > IDLE_THRESHOLD_HOURS and
  there are overdue/at-risk commitments, it fires a nudge.
- Cooldown: won't re-nudge within IDLE_NUDGE_COOLDOWN_HOURS of the last idle nudge.

Required env vars: none
"""
from __future__ import annotations
import os
from datetime import datetime, timedelta
from typing import TYPE_CHECKING
if TYPE_CHECKING:
    from ..db import Database
from .. import logger as log

FEATURE_NAME = "idle_detection"

_THRESHOLD_HOURS = int(os.environ.get("VIGIL_IDLE_HOURS", "4"))
_COOLDOWN_HOURS  = 2
_SETTING_HEARTBEAT  = "idle_heartbeat"
_SETTING_NUDGE_SENT = "idle_nudge_sent_at"


def run(db: "Database", user_id: str = "local") -> None:
    try:
        from ..features import is_enabled
    except ImportError:
        return
    if not is_enabled(FEATURE_NAME, db, user_id=user_id):
        return

    now = datetime.now()

    # ── Heartbeat check ──────────────────────────────────────────────────────
    raw_hb = db.get_setting(_SETTING_HEARTBEAT, user_id=user_id)
    if not raw_hb:
        # First run — write a heartbeat so future checks have a baseline.
        db.set_setting(_SETTING_HEARTBEAT, now.isoformat(), user_id=user_id)
        return

    try:
        last_session = datetime.fromisoformat(raw_hb)
    except ValueError:
        return

    idle_hours = (now - last_session).total_seconds() / 3600
    if idle_hours < _THRESHOLD_HOURS:
        return  # not idle yet

    # ── Cooldown check ───────────────────────────────────────────────────────
    raw_nudge = db.get_setting(_SETTING_NUDGE_SENT, user_id=user_id)
    if raw_nudge:
        try:
            last_nudge = datetime.fromisoformat(raw_nudge)
            if (now - last_nudge).total_seconds() / 3600 < _COOLDOWN_HOURS:
                return
        except ValueError:
            pass

    # ── Find urgent commitments ──────────────────────────────────────────────
    urgent = _get_urgent_commitments(db, now, user_id)
    if not urgent:
        return

    # ── Fire nudge ──────────────────────────────────────────────────────────
    overdue = [c for c in urgent if _is_overdue(c, now)]
    at_risk = [c for c in urgent if not _is_overdue(c, now)]

    parts = []
    if overdue:
        parts.append(f"{len(overdue)} overdue")
    if at_risk:
        parts.append(f"{len(at_risk)} at risk")
    summary = ", ".join(parts)

    title   = f"Vigil — {int(idle_hours)}h idle"
    message = f"{summary}: {urgent[0]['description'][:60]}"
    if len(urgent) > 1:
        message += f" (+{len(urgent) - 1} more)"

    try:
        from ..notify import send_notification
        send_notification(db, title, message, user_id=user_id, commitment_id=urgent[0]["id"])
    except Exception as e:
        log.schedule.warning(log.kv(event="idle_notify_error", error=repr(str(e))[:80]))
        return

    db.set_setting(_SETTING_NUDGE_SENT, now.isoformat(), user_id=user_id)
    log.schedule.info(log.kv(
        event="idle_nudge_sent", user=user_id,
        idle_hours=f"{idle_hours:.1f}", urgent=len(urgent),
    ))


def _get_urgent_commitments(db: "Database", now: datetime, user_id: str) -> list[dict]:
    """Return overdue and at-risk (< 4h) pending commitments for this user."""
    pending = db.get_pending(user_id=user_id) if user_id != "local" else [
        c for c in db.get_pending() if c.get("user_id", "local") == "local"
    ]
    urgent = []
    for c in pending:
        if not c.get("due_by"):
            continue
        try:
            due = datetime.fromisoformat(c["due_by"])
        except ValueError:
            continue
        hours_left = (due - now).total_seconds() / 3600
        if hours_left < 4:  # overdue or at-risk
            urgent.append(c)
    urgent.sort(key=lambda c: c.get("due_by", ""))
    return urgent


def _is_overdue(c: dict, now: datetime) -> bool:
    try:
        return datetime.fromisoformat(c["due_by"]) < now
    except (ValueError, KeyError, TypeError):
        return False


def _record_heartbeat(db: "Database", user_id: str = "local") -> None:
    """Called externally to update the last-seen session timestamp."""
    db.set_setting(_SETTING_HEARTBEAT, datetime.now().isoformat(), user_id=user_id)
