"""
github_integration.py — GitHub Integration: Auto-create commitments from stale PRs and review inactivity.
Status: STUB — not yet implemented.
Required env vars: GITHUB_TOKEN
"""
from __future__ import annotations
import os
from typing import TYPE_CHECKING
if TYPE_CHECKING:
    from ..db import Database
from .. import logger as log

FEATURE_NAME = "github_integration"


def run(db: "Database", user_id: str = "local") -> None:
    try:
        from ..features import is_enabled
    except ImportError:
        return
    if not is_enabled(FEATURE_NAME, db, user_id=user_id):
        return
    log.schedule.debug(log.kv(event="integration_stub_called", feature=FEATURE_NAME))
    # TODO: implement
    # Planned: fetch open PRs via GitHub API, detect stale reviews,
    # auto-create commitments for PRs with no activity for N days.


def _fetch_open_prs(token: str, owner: str, repo: str) -> list[dict]:
    """Placeholder: fetch open PRs from GitHub API."""
    return []


def _is_pr_stale(pr: dict, stale_days: int = 3) -> bool:
    """Placeholder: return True if PR has had no activity for stale_days."""
    return False


def _commitment_exists(db: "Database", pr_url: str, user_id: str) -> bool:
    """Placeholder: check if a commitment for this PR already exists."""
    return False
