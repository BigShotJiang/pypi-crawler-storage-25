"""
accountability_partners.py — Accountability Partners: Ping a Slack user if a tagged commitment is missed.
Status: STUB — not yet implemented.
Required env vars: VIGIL_SLACK_BOT_TOKEN
"""
from __future__ import annotations
import os
from typing import TYPE_CHECKING
if TYPE_CHECKING:
    from ..db import Database
from .. import logger as log

FEATURE_NAME = "accountability_partners"


def run(db: "Database", user_id: str = "local") -> None:
    try:
        from ..features import is_enabled
    except ImportError:
        return
    if not is_enabled(FEATURE_NAME, db, user_id=user_id):
        return
    log.schedule.debug(log.kv(event="integration_stub_called", feature=FEATURE_NAME))
    # TODO: implement
    # Planned: check overdue commitments tagged with a partner Slack user ID,
    # send a DM via Slack Bot Token notifying the partner of the missed commitment.


def _get_partner_for_commitment(commitment: dict) -> str | None:
    """Placeholder: return Slack user ID of accountability partner, or None."""
    return None


def _notify_partner(bot_token: str, partner_slack_id: str, commitment: dict) -> bool:
    """Placeholder: DM the partner via Slack API chat.postMessage."""
    return False


def _already_notified_partner(db: "Database", commitment_id: int) -> bool:
    """Placeholder: check decision log to avoid duplicate partner pings."""
    return False
