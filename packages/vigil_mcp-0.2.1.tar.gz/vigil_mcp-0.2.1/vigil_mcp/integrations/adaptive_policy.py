"""
adaptive_policy.py — Adaptive Policy: Learn per-category follow-through patterns and adjust importance thresholds.

How it works:
- Runs once per day.
- Groups completed and abandoned commitments by their `context` field.
- Categories with ≥ 3 resolved commitments and < 50% follow-through are marked low-reliability.
- Pending commitments in low-reliability categories get their importance boosted by 15% (cap 0.95)
  so they are more likely to clear the policy engine's threshold and generate a nudge.
- Boost is logged to the decision log for full explainability.

Required env vars: none
"""
from __future__ import annotations
from datetime import datetime
from typing import TYPE_CHECKING
if TYPE_CHECKING:
    from ..db import Database
from .. import logger as log

FEATURE_NAME = "adaptive_policy"

_MIN_SAMPLES    = 3    # minimum resolved commitments to consider a category
_LOW_THRESHOLD  = 0.5  # follow-through rate below this triggers a boost
_BOOST_FACTOR   = 1.15 # multiply importance by this
_IMPORTANCE_CAP = 0.95
_SETTING_LAST_RUN = "adaptive_policy_last_run"


def run(db: "Database", user_id: str = "local") -> None:
    try:
        from ..features import is_enabled
    except ImportError:
        return
    if not is_enabled(FEATURE_NAME, db, user_id=user_id):
        return

    today = datetime.now().date().isoformat()
    if db.get_setting(_SETTING_LAST_RUN, user_id=user_id) == today:
        return  # already ran today

    stats = _get_category_stats(db, user_id)
    low_reliability = {
        cat for cat, s in stats.items()
        if s["total"] >= _MIN_SAMPLES and s["rate"] < _LOW_THRESHOLD
    }

    if not low_reliability:
        db.set_setting(_SETTING_LAST_RUN, today, user_id=user_id)
        return

    adjusted = _apply_boosts(db, user_id, low_reliability)
    db.set_setting(_SETTING_LAST_RUN, today, user_id=user_id)
    log.schedule.info(log.kv(
        event="adaptive_policy_ran", user=user_id,
        low_reliability_cats=len(low_reliability),
        commitments_boosted=adjusted,
    ))


def _get_category_stats(db: "Database", user_id: str) -> dict[str, dict]:
    """Return per-category follow-through stats. Only categories with resolved commitments."""
    if user_id == "local":
        rows = db.conn.execute(
            """SELECT context,
                      SUM(CASE WHEN completed_at IS NOT NULL THEN 1 ELSE 0 END) AS completed,
                      SUM(CASE WHEN state = 'abandoned' THEN 1 ELSE 0 END) AS abandoned
               FROM commitments
               WHERE (user_id = 'local' OR user_id IS NULL)
                 AND context IS NOT NULL AND context != ''
               GROUP BY context""",
        ).fetchall()
    else:
        rows = db.conn.execute(
            """SELECT context,
                      SUM(CASE WHEN completed_at IS NOT NULL THEN 1 ELSE 0 END) AS completed,
                      SUM(CASE WHEN state = 'abandoned' THEN 1 ELSE 0 END) AS abandoned
               FROM commitments
               WHERE user_id = ? AND context IS NOT NULL AND context != ''
               GROUP BY context""",
            (user_id,),
        ).fetchall()

    result = {}
    for row in rows:
        cat       = row["context"]
        completed = row["completed"] or 0
        abandoned = row["abandoned"] or 0
        total     = completed + abandoned
        result[cat] = {
            "completed": completed,
            "abandoned":  abandoned,
            "total":      total,
            "rate":       completed / total if total > 0 else 0.0,
        }
    return result


def _apply_boosts(db: "Database", user_id: str, low_categories: set[str]) -> int:
    """Boost importance of pending commitments in low-reliability categories. Returns count."""
    if user_id == "local":
        pending = db.conn.execute(
            """SELECT id, context, importance_score FROM commitments
               WHERE (user_id = 'local' OR user_id IS NULL)
                 AND completed_at IS NULL AND state != 'abandoned'
                 AND context IS NOT NULL AND context != ''""",
        ).fetchall()
    else:
        pending = db.conn.execute(
            """SELECT id, context, importance_score FROM commitments
               WHERE user_id = ? AND completed_at IS NULL AND state != 'abandoned'
                 AND context IS NOT NULL AND context != ''""",
            (user_id,),
        ).fetchall()

    count = 0
    for row in pending:
        if row["context"] not in low_categories:
            continue
        old_score = float(row["importance_score"] or 0.5)
        new_score = min(_IMPORTANCE_CAP, round(old_score * _BOOST_FACTOR, 3))
        if new_score <= old_score:
            continue
        db.update_importance(row["id"], new_score)
        db.log_decision(
            commitment_id=row["id"],
            event="adaptive_boost",
            phase="adaptive",
            action="none",
            reasoning=(
                f"Adaptive policy: category '{row['context']}' has low follow-through. "
                f"Importance boosted {old_score:.2f} → {new_score:.2f}."
            ),
        )
        count += 1
    return count


def _compute_adjusted_threshold(base_threshold: float, follow_through_rate: float) -> float:
    """Return what the effective importance threshold would be for a given follow-through rate."""
    if follow_through_rate < _LOW_THRESHOLD:
        return max(0.3, base_threshold - 0.1)
    return base_threshold
