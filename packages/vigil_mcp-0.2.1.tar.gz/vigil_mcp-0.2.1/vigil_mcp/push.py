"""
Web Push notifications — sends nudges to any device that has subscribed via the PWA.

Setup:
  1. Generate VAPID keys once:      python -m vigil_mcp.push --generate-keys
  2. Set environment variables:     VIGIL_VAPID_PRIVATE_KEY, VIGIL_VAPID_PUBLIC_KEY, VIGIL_VAPID_SUB
  3. Frontend fetches the public key from /api/vapid-public-key and subscribes
  4. Background loop calls send_to_user() instead of platform-specific notifications
"""

from __future__ import annotations

import json
import os
from typing import TYPE_CHECKING

from . import logger as log

if TYPE_CHECKING:
    from .db import Database

# ── pywebpush is optional (only needed for hosted mode) ────────────────────
try:
    from pywebpush import webpush, WebPushException  # type: ignore
    _HAS_PYWEBPUSH = True
except ImportError:
    _HAS_PYWEBPUSH = False


def _get_vapid_config() -> tuple[str | None, str | None, str]:
    """Reads VAPID keys from env. Returns (private, public, subject)."""
    priv = os.environ.get("VIGIL_VAPID_PRIVATE_KEY")
    pub  = os.environ.get("VIGIL_VAPID_PUBLIC_KEY")
    sub  = os.environ.get("VIGIL_VAPID_SUB", "mailto:vigil@local")
    return priv, pub, sub


def get_public_key() -> str | None:
    """The VAPID public key the frontend needs to subscribe."""
    _, pub, _ = _get_vapid_config()
    return pub


def is_configured() -> bool:
    """True if Web Push is set up (library + keys present)."""
    priv, pub, _ = _get_vapid_config()
    return _HAS_PYWEBPUSH and bool(priv) and bool(pub)


def send_to_user(db: "Database", user_id: str, title: str, message: str,
                 url: str = "/") -> int:
    """
    Send a push notification to all of a user's subscribed devices.
    Returns the number of devices successfully notified.
    Expired subscriptions are automatically pruned.
    """
    if not is_configured():
        return 0

    subs = db.get_push_subscriptions(user_id)
    if not subs:
        return 0

    priv, _, sub = _get_vapid_config()
    payload = json.dumps({"title": title, "body": message, "url": url})
    claims = {"sub": sub}

    sent = 0
    for s in subs:
        try:
            webpush(
                subscription_info={
                    "endpoint": s["endpoint"],
                    "keys": {"p256dh": s["p256dh"], "auth": s["auth"]},
                },
                data=payload,
                vapid_private_key=priv,
                vapid_claims=claims,
            )
            sent += 1
        except WebPushException as e:
            status = getattr(e.response, "status_code", None) if e.response else None
            if status in (404, 410):
                # Subscription gone — prune it
                db.delete_push_subscription(s["endpoint"])
                log.schedule.info(log.kv(event="push_pruned", endpoint=s["endpoint"][:60]))
            else:
                log.schedule.error(log.kv(event="push_failed", status=status, error=repr(str(e))[:100]))
        except Exception as e:
            log.schedule.error(log.kv(event="push_failed", error=repr(str(e))[:100]))

    log.schedule.info(log.kv(event="push_sent", user=user_id, devices=sent, title=repr(title[:40])))
    return sent


# ─── VAPID key generation helper ─────────────────────────────────────────────

def generate_vapid_keys() -> tuple[str, str]:
    """
    Generate a fresh VAPID key pair. Run once, store the result in env vars.
    Returns (private_key_pem, public_key_base64url).
    """
    from cryptography.hazmat.primitives import serialization
    from cryptography.hazmat.primitives.asymmetric import ec
    from cryptography.hazmat.backends import default_backend
    import base64

    private = ec.generate_private_key(ec.SECP256R1(), default_backend())
    private_pem = private.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption(),
    ).decode()

    public_numbers = private.public_key().public_numbers()
    public_raw = b"\x04" + public_numbers.x.to_bytes(32, "big") + public_numbers.y.to_bytes(32, "big")
    public_b64 = base64.urlsafe_b64encode(public_raw).rstrip(b"=").decode()

    return private_pem, public_b64


def _cli():
    import sys
    if "--generate-keys" in sys.argv:
        priv, pub = generate_vapid_keys()
        print("# Add these to your environment (.env file or Railway vars):")
        print(f'export VIGIL_VAPID_PUBLIC_KEY="{pub}"')
        print("export VIGIL_VAPID_PRIVATE_KEY=\"$(cat <<'EOF'")
        print(priv.strip())
        print("EOF")
        print(")\"")
        print('export VIGIL_VAPID_SUB="mailto:you@example.com"')
    else:
        print("Usage: python -m vigil_mcp.push --generate-keys")


if __name__ == "__main__":
    _cli()
