"""
Vigil structured logger.

Writes to ~/.vigil/vigil.log — rotating, searchable, grep-friendly.

Format:
  2026-04-17 10:00:00 [LEVEL ] [component] message {key=value ...}

Search examples:
  grep "action=notify" ~/.vigil/vigil.log
  grep "commitment_id=3" ~/.vigil/vigil.log
  grep "ERROR" ~/.vigil/vigil.log
  grep "auto_abandoned" ~/.vigil/vigil.log
"""

import logging
import logging.handlers
from pathlib import Path

LOG_PATH = Path.home() / ".vigil" / "vigil.log"
LOG_PATH.parent.mkdir(exist_ok=True)

_fmt = logging.Formatter(
    fmt="%(asctime)s [%(levelname)-5s] [%(name)s] %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)


def _build_logger(name: str) -> logging.Logger:
    logger = logging.getLogger(f"vigil.{name}")
    if logger.handlers:
        return logger  # already configured

    logger.setLevel(logging.DEBUG)

    # Rotating file — max 2MB, keep 3 backups
    fh = logging.handlers.RotatingFileHandler(
        LOG_PATH, maxBytes=2 * 1024 * 1024, backupCount=3, encoding="utf-8"
    )
    fh.setFormatter(_fmt)
    logger.addHandler(fh)
    logger.propagate = False
    return logger


def kv(**kwargs) -> str:
    """Format keyword pairs for structured log lines: key=value key2=value2"""
    return " ".join(f"{k}={v}" for k, v in kwargs.items())


# ─── Named loggers ────────────────────────────────────────────────────────────

policy   = _build_logger("policy")
db       = _build_logger("db")
server   = _build_logger("server")
schedule = _build_logger("scheduler")
