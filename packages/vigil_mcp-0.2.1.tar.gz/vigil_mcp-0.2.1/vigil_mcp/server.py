import threading
import time
from datetime import datetime
from typing import Optional

from mcp.server.fastmcp import FastMCP

from .dashboard import PORT, start_dashboard
from .db import Database
from . import logger as log
from .policy import Action, PolicyDecision, compute_phase, decide_action, state_for_phase

mcp = FastMCP(
    "vigil",
    instructions=f"""You are connected to Vigil — a proactive memory layer with a policy engine.

SESSION START:
- Always read vigil://pending first.
- OVERDUE or AT_RISK items: open with them naturally. Don't wait.
- Nothing urgent: proceed normally.
- Use vigil://status to check health or configuration.

EDITING: If user says "change the deadline", "update that", "make it more important" → call update_commitment with only the changed fields.

CAPTURING COMMITMENTS:
When user says "I'll come back", "remind me to...", "let's continue Friday",
"every Monday I want to...", "I'll do X later" → call create_from_text(text) for natural
phrasing, or save_commitment for precise structured input. Prefer create_from_text when
the user speaks naturally — it parses intent, deadline, and importance automatically.

How to fill in fields:
- intent_strength: "hard" if definite ("I will"), "soft" if uncertain ("I should"),
  "hypothetical" if vague ("maybe someday"). Vigil won't nudge hypotheticals.
- importance_score: 0.0–1.0. Ask yourself: what's the cost if this is missed?
  0.3 = low stakes, 0.6 = meaningful, 0.9 = critical.
- confidence_score: how sure are you this is a real commitment? 0.7+ = save it.
- ai_summary: 2 sentences on what was being worked on. This is what makes
  resurface feel human. Always fill this in.

COMPLETING: "done", "finished", "mark X complete" → call complete_commitment.

EXPLAINING: If user asks "why did you message me?" → call explain_nudge.

DASHBOARD: http://localhost:{PORT} — mention it when relevant.

THE POLICY ENGINE decides when Vigil acts. It reasons about phase, urgency,
importance, attention budget, and cooldowns. Vigil never acts randomly.
""",
)

db = Database()


# ─── Tools ──────────────────────────────────────────────────────────────────

@mcp.tool()
def save_commitment(
    description: str,
    due_by: str,
    ai_summary: str = "",
    context: str = "",
    intent_strength: str = "hard",
    importance_score: float = 0.5,
    confidence_score: float = 1.0,
    recurrence: str = "none",
    recurrence_days: Optional[list[str]] = None,
    recurrence_time: str = "",
) -> str:
    """
    Save a commitment. Call whenever the user signals future intent.

    Args:
        description:     Full description of the commitment.
        due_by:          ISO 8601 datetime (e.g. "2026-04-17T10:00:00").
        ai_summary:      2-sentence context of what was being worked on.
                         Always fill this — it makes resurface feel intelligent.
        context:         Brief topic label.
        intent_strength: "hard" | "soft" | "hypothetical"
                         hard = "I will", soft = "I should", hypothetical = "maybe"
        importance_score: 0.0–1.0. Cost of missing this commitment.
        confidence_score: 0.0–1.0. How certain are you this is a real commitment?
        recurrence:      "none" | "daily" | "weekly" | "monthly"
        recurrence_days: For weekly — e.g. ["monday", "thursday"]
        recurrence_time: "HH:MM" for recurring commitments.
    """
    if confidence_score < 0.5:
        return (
            f"Commitment not saved — confidence too low ({confidence_score:.1f}). "
            "Consider clarifying the intent before saving."
        )

    commitment_id = db.save_commitment(
        description=description,
        due_by=due_by,
        context=context,
        ai_summary=ai_summary,
        intent_strength=intent_strength,
        confidence_score=confidence_score,
        importance_score=importance_score,
        recurrence=recurrence,
        recurrence_days=recurrence_days or [],
        recurrence_time=recurrence_time,
    )

    log.server.info(log.kv(
        event="saved", id=commitment_id, intent=intent_strength,
        importance=importance_score, due=due_by, desc=repr(description[:60]),
    ))

    intent_note = "" if intent_strength == "hard" else f" [{intent_strength}]"
    recurrence_note = f" (repeats {recurrence})" if recurrence and recurrence != "none" else ""

    return (
        f"Saved{intent_note}{recurrence_note}: '{description}' — due {due_by}. "
        f"Importance: {importance_score:.1f}. (ID: {commitment_id})"
    )


@mcp.tool()
def create_from_text(text: str) -> str:
    """
    Create a commitment from natural language. Prefer this over save_commitment
    when the user speaks naturally.

    Parses the text using Claude to extract description, deadline, importance,
    and intent automatically.

    Args:
        text: Natural language commitment, e.g.:
              "remind me to push this PR before EOD"
              "I need to call the client back tomorrow morning"
              "every Monday at 9am review job applications"
    """
    try:
        from .analyzer import parse_commitment_from_text
        parsed = parse_commitment_from_text(text)
    except RuntimeError as e:
        return (
            f"NL parsing not available: {e}\n"
            "Set ANTHROPIC_API_KEY or use save_commitment with explicit fields."
        )
    except ImportError as e:
        return f"NL parsing not available: {e}"
    except Exception as e:
        return f"Failed to parse commitment: {e}"

    if parsed is None:
        return (
            "That doesn't look like a commitment. "
            "Try: 'remind me to X by Y' or 'I will do X tomorrow'."
        )

    commitment_id = db.save_commitment(
        description=parsed["description"],
        due_by=parsed["due_by"],
        context=parsed["context"],
        ai_summary=parsed["ai_summary"],
        intent_strength=parsed["intent_strength"],
        confidence_score=1.0,
        importance_score=parsed["importance_score"],
    )

    log.server.info(log.kv(
        event="nl_saved", id=commitment_id, intent=parsed["intent_strength"],
        importance=parsed["importance_score"], due=parsed["due_by"],
        desc=repr(parsed["description"][:60]),
    ))

    due_str = f" — due {parsed['due_by']}" if parsed["due_by"] else " (no deadline set)"
    return (
        f"Saved: '{parsed['description']}'{due_str}\n"
        f"Intent: {parsed['intent_strength']} · Importance: {parsed['importance_score']:.1f} "
        f"(ID: {commitment_id})"
    )


@mcp.tool()
def get_commitments() -> str:
    """Get all pending commitments with phase, state, and stats."""
    commitments = db.get_pending()
    stats = db.get_stats()

    footer = (
        f"\nFollow-through: {stats['follow_through_rate']}% "
        f"({stats['completed']}/{stats['total']}) · "
        f"Attention budget: {stats['budget_used']}/{stats['budget_limit']} today"
    )

    if not commitments:
        return f"No pending commitments.{footer}"

    now = datetime.now()
    lines = []
    for c in commitments:
        phase      = compute_phase(c, now)
        recurring  = f" [↻ {c['recurrence']}]" if c.get("recurrence") and c["recurrence"] != "none" else ""
        intent_tag = f" [{c.get('intent_strength', 'hard')}]" if c.get("intent_strength") != "hard" else ""
        summary    = f"\n  {c['ai_summary']}" if c.get("ai_summary") else ""
        lines.append(
            f"[{c['id']}] {phase.value.upper()}{recurring}{intent_tag}: {c['description']}\n"
            f"  state={c.get('state','?')} importance={c.get('importance_score',0.5):.1f} "
            f"due={c.get('due_by') or 'none'}"
            f"{summary}"
        )

    return "\n\n".join(lines) + footer


@mcp.tool()
def complete_commitment(commitment_id: int) -> str:
    """Mark a commitment as done. If recurring, schedules the next instance."""
    new_id = db.complete_commitment(commitment_id)
    db.log_decision(
        commitment_id=commitment_id,
        event="user_completed",
        phase="completed",
        action="none",
        reasoning="User explicitly marked as complete.",
    )
    if new_id:
        return f"Done ✓ Commitment {commitment_id} complete. Next recurrence scheduled (ID: {new_id})."
    return f"Done ✓ Commitment {commitment_id} marked as complete."


@mcp.tool()
def snooze_commitment(commitment_id: int, snooze_until: str) -> str:
    """
    Snooze a commitment to a later time.

    Args:
        commitment_id: ID to snooze.
        snooze_until:  New due datetime in ISO 8601 format.
    """
    db.snooze_commitment(commitment_id, snooze_until)
    db.log_decision(
        commitment_id=commitment_id,
        event="user_snoozed",
        phase="snoozed",
        action="none",
        reasoning=f"User snoozed until {snooze_until}.",
    )
    return f"Snoozed until {snooze_until}."


@mcp.tool()
def explain_nudge(commitment_id: int) -> str:
    """
    Explain why Vigil acted (or didn't act) on a commitment.
    Returns the full decision trace — phase, reasoning, budget, urgency.
    """
    c = db.get_by_id(commitment_id)
    if not c:
        return f"Commitment {commitment_id} not found."

    history = db.get_decision_history(commitment_id, limit=8)
    if not history:
        return f"No decisions logged yet for commitment {commitment_id}."

    lines = [f"Decision trace for [{commitment_id}] '{c['description']}'\n"]
    for entry in history:
        action_str = "ACTED" if entry["action"] != "none" else "suppressed"
        lines.append(
            f"[{entry['created_at'][:16]}] {action_str} | phase={entry['phase']} "
            f"urgency={entry.get('urgency', 0):.2f} "
            f"budget={entry.get('budget_used')}/{entry.get('budget_limit')}\n"
            f"  → {entry['reasoning']}"
        )

    return "\n\n".join(lines)


@mcp.tool()
def set_daily_digest_time(time: str) -> str:
    """
    Set the time for a daily morning digest notification.

    Args:
        time: "HH:MM" — e.g. "08:30"
    """
    try:
        parts = time.strip().split(":")
        if len(parts) != 2:
            raise ValueError
        h, m = int(parts[0]), int(parts[1])
        if not (0 <= h <= 23 and 0 <= m <= 59):
            raise ValueError
    except ValueError:
        return f"Invalid time '{time}'. Use HH:MM format (e.g. '08:30')."

    normalised = f"{h:02d}:{m:02d}"
    db.set_setting("digest_time", normalised)
    return f"Daily digest set for {normalised}. You'll get a morning notification with pending commitments."


@mcp.tool()
def update_commitment(
    commitment_id: int,
    description: Optional[str] = None,
    due_by: Optional[str] = None,
    importance_score: Optional[float] = None,
    intent_strength: Optional[str] = None,
    ai_summary: Optional[str] = None,
) -> str:
    """
    Edit an existing commitment. Only pass the fields you want to change.

    Args:
        commitment_id:   ID of the commitment to update.
        description:     New description text.
        due_by:          New due datetime in ISO 8601 format.
        importance_score: New importance (0.0–1.0).
        intent_strength: "hard" | "soft" | "hypothetical"
        ai_summary:      Updated context summary.
    """
    c = db.get_by_id(commitment_id)
    if not c:
        return f"Commitment {commitment_id} not found."

    db.update_commitment(
        commitment_id=commitment_id,
        description=description,
        due_by=due_by,
        importance_score=importance_score,
        intent_strength=intent_strength,
        ai_summary=ai_summary,
    )

    db.log_decision(
        commitment_id=commitment_id,
        event="user_updated",
        phase="updated",
        action="none",
        reasoning=(
            f"User edited: "
            + (f"description={repr(description[:40])} " if description else "")
            + (f"due_by={due_by} " if due_by else "")
            + (f"importance={importance_score} " if importance_score is not None else "")
            + (f"intent={intent_strength} " if intent_strength else "")
        ).strip(),
    )

    log.server.info(log.kv(event="updated", id=commitment_id))
    return f"Updated commitment {commitment_id}."


@mcp.tool()
def set_attention_budget(daily_limit: int) -> str:
    """
    Set how many nudges Vigil is allowed to send per day.
    Default is 10. Lower = less interruptions, higher priority items only get through.

    Args:
        daily_limit: Number of nudges allowed per day (1–50).
    """
    daily_limit = max(1, min(50, daily_limit))
    db.set_setting("attention_budget", str(daily_limit))
    return f"Attention budget set to {daily_limit} nudges per day."


@mcp.tool()
def set_slack_webhook(webhook_url: str) -> str:
    """
    Configure a Slack incoming webhook URL so Vigil sends nudges to your Slack channel.

    Create one at: https://api.slack.com/messaging/webhooks
    (Slack app → Incoming Webhooks → Add to Workspace → copy URL)

    Args:
        webhook_url: The https://hooks.slack.com/services/... URL.
    """
    if not webhook_url.startswith("https://hooks.slack.com/"):
        return "Invalid Slack webhook URL. Should start with https://hooks.slack.com/"
    db.set_setting("slack_webhook_url", webhook_url)
    db.set_setting("slack_nudge_enabled", "true")
    return "Slack webhook configured. Vigil will now send nudges to your Slack channel."


@mcp.tool()
def set_discord_webhook(webhook_url: str) -> str:
    """
    Configure a Discord webhook URL so Vigil sends nudges to your Discord channel.

    Create one in Discord: Channel Settings → Integrations → Webhooks → New Webhook → Copy URL.

    Args:
        webhook_url: The https://discord.com/api/webhooks/... URL.
    """
    if not webhook_url.startswith("https://discord.com/api/webhooks/"):
        return "Invalid Discord webhook URL. Should start with https://discord.com/api/webhooks/"
    db.set_setting("discord_webhook_url", webhook_url)
    db.set_setting("discord_nudge_enabled", "true")
    return "Discord webhook configured. Vigil will now send nudges to your Discord channel."


@mcp.tool()
def list_features() -> str:
    """List all V3 features and whether each is currently enabled."""
    try:
        from .features import get_all_status, DIRECTIONS
    except ImportError as e:
        return f"Features module not available: {e}"
    statuses = get_all_status(db, user_id="local")
    by_dir: dict[str, list] = {}
    for s in statuses:
        by_dir.setdefault(s["direction"], []).append(s)
    lines = ["## V3 Features\n"]
    for dk, items in by_dir.items():
        lines.append(f"### {DIRECTIONS.get(dk, dk)}")
        for s in items:
            marker = "ON " if s["enabled"] else "off"
            warn = f" (needs: {', '.join(s['missing_env'])})" if s["toggled_on"] and s["missing_env"] else ""
            lines.append(f"  [{marker}] {s['label']}: {s['description']}{warn}")
        lines.append("")
    return "\n".join(lines)


@mcp.tool()
def enable_feature(feature_name: str) -> str:
    """Enable a V3 feature. Run list_features() first to see available names."""
    try:
        from .features import set_enabled, FEATURES
    except ImportError as e:
        return f"Features module not available: {e}"
    if feature_name not in FEATURES:
        return f"Unknown feature '{feature_name}'. Available: {', '.join(FEATURES.keys())}"
    set_enabled(feature_name, True, db, user_id="local")
    feat = FEATURES[feature_name]
    import os
    missing = [v for v in feat.requires_env if not os.environ.get(v)]
    if missing:
        return f"'{feat.label}' toggled on, but won't run until env vars are set: {', '.join(missing)}"
    return f"Feature '{feat.label}' enabled."


@mcp.tool()
def disable_feature(feature_name: str) -> str:
    """Disable a V3 feature by name."""
    try:
        from .features import set_enabled, FEATURES
    except ImportError as e:
        return f"Features module not available: {e}"
    if feature_name not in FEATURES:
        return f"Unknown feature '{feature_name}'. Available: {', '.join(FEATURES.keys())}"
    set_enabled(feature_name, False, db, user_id="local")
    return f"Feature '{FEATURES[feature_name].label}' disabled."


# ─── Resources ──────────────────────────────────────────────────────────────

@mcp.resource("vigil://pending")
def pending_resource() -> str:
    """
    Pending commitments with phase, state, and policy context.
    Read this at every session start. Act on OVERDUE and AT_RISK items first.
    """
    # Record session heartbeat so idle_detection knows when Claude was last active
    db.set_setting("idle_heartbeat", datetime.now().isoformat())

    commitments = db.get_pending()
    if not commitments:
        return "No pending commitments. All clear."

    now = datetime.now()
    by_phase: dict[str, list] = {
        "overdue":   [],
        "risk":      [],
        "execution": [],
        "early":     [],
    }

    for c in commitments:
        phase = compute_phase(c, now)
        by_phase[phase.value].append(c)

    sections = []

    if by_phase["overdue"]:
        items = "\n".join(
            f"- [{c['id']}] {c['description']} (was due {c['due_by']})\n"
            f"  {c.get('ai_summary') or c.get('context') or '—'}"
            for c in by_phase["overdue"]
        )
        sections.append(f"## OVERDUE — address immediately\n{items}")

    if by_phase["risk"]:
        items = "\n".join(
            f"- [{c['id']}] {c['description']} (due {c['due_by']})"
            for c in by_phase["risk"]
        )
        sections.append(f"## AT RISK — less than 4 hours\n{items}")

    if by_phase["execution"]:
        items = "\n".join(
            f"- [{c['id']}] {c['description']} (due {c['due_by'] or 'no deadline'})"
            for c in by_phase["execution"]
        )
        sections.append(f"## In Progress\n{items}")

    if by_phase["early"]:
        items = "\n".join(
            f"- [{c['id']}] {c['description']} (due {c['due_by'] or 'no deadline'})"
            for c in by_phase["early"]
        )
        sections.append(f"## Upcoming\n{items}")

    stats = db.get_stats()
    sections.append(
        f"Budget: {stats['budget_used']}/{stats['budget_limit']} nudges used today · "
        f"Follow-through: {stats['follow_through_rate']}%"
    )

    return "\n\n".join(sections)


@mcp.resource("vigil://status")
def status_resource() -> str:
    """
    Health check for Vigil. Shows configuration, budget, and system state.
    Use to confirm Vigil is running and correctly configured.
    """
    stats        = db.get_stats()
    budget_limit = db.get_budget_limit()
    digest_time  = db.get_setting("digest_time") or "not set"
    dashboard_url = f"http://localhost:{PORT}"

    lines = [
        "## Vigil Status",
        f"Status: running",
        f"Dashboard: {dashboard_url}",
        "",
        "### Attention budget",
        f"Used today: {stats['budget_used']} / {budget_limit}",
        f"Remaining:  {max(0, budget_limit - stats['budget_used'])}",
        "",
        "### Commitments",
        f"Total:     {stats['total']}",
        f"Pending:   {stats['pending']}",
        f"Completed: {stats['completed']}",
        f"Overdue:   {stats['overdue']}",
        f"Follow-through rate: {stats['follow_through_rate']}%",
        "",
        "### Settings",
        f"Daily digest: {digest_time}",
        f"Attention budget: {budget_limit} nudges/day",
    ]
    return "\n".join(lines)


@mcp.resource("vigil://history")
def history_resource() -> str:
    """Completed commitments and follow-through stats."""
    completed = db.get_completed(limit=20)
    stats = db.get_stats()

    header = (
        f"## Track Record\n"
        f"Completed {stats['completed']} of {stats['total']} total commitments\n"
        f"Follow-through rate: {stats['follow_through_rate']}%\n"
        f"Currently overdue: {stats['overdue']}"
    )

    if not completed:
        return f"{header}\n\nNo completed commitments yet."

    items = "\n".join(
        f"✓ [{c['id']}] {c['description']} — {c['completed_at'][:10]}"
        for c in completed
    )
    return f"{header}\n\n{items}"


# ─── Background engine ───────────────────────────────────────────────────────

def _send_notification(title: str, message: str, user_id: str = "local", commitment_id: int = 0):
    """Deliver a notification via Web Push → webhooks → desktop fallback."""
    from .notify import send_notification
    send_notification(db, title, message, user_id=user_id, commitment_id=commitment_id)


def _background_loop():
    """
    Runs every 60 seconds.
    Every pending commitment is evaluated by the policy engine.
    The engine decides — not the clock.
    Signal analyzer runs every 5 minutes.
    """
    digest_sent_date    = None
    prune_done_date     = None
    last_signal_analyze = datetime.min

    while True:
        try:
            now = datetime.now()

            # Signal analyzer — runs every 5 minutes
            if (now - last_signal_analyze).total_seconds() >= 300:
                try:
                    from .analyzer import analyze_signals
                    n = analyze_signals(db)
                    if n:
                        log.schedule.info(log.kv(event="signal_analysis_done", commitments_created=n))
                    last_signal_analyze = now
                except Exception as e:
                    log.schedule.warning(log.kv(event="signal_analysis_error", error=repr(str(e))[:80]))

                try:
                    from .integrations import run_all_integrations
                    run_all_integrations(db, user_id="local")
                except Exception as e:
                    log.schedule.warning(log.kv(event="integration_run_error", error=repr(str(e))[:80]))

            for c in db.get_pending():
                decision: PolicyDecision = decide_action(c, db)

                # Always log the decision (even NONEs — for trace / explainability)
                db.log_decision(
                    commitment_id=c["id"],
                    event="background_check",
                    phase=decision.phase.value,
                    action=decision.action.value,
                    reasoning=decision.reasoning,
                    urgency=decision.urgency,
                )

                log_fn = log.schedule.info if decision.action == Action.NONE else log.schedule.warning
                log_fn(log.kv(
                    event="policy_decision", id=c["id"],
                    action=decision.action.value, phase=decision.phase.value,
                    urgency=f"{decision.urgency:.2f}", budget=decision.budget_remaining,
                    suppressed=decision.suppressed,
                ))
                log.schedule.debug(log.kv(event="reasoning", id=c["id"], reason=repr(decision.reasoning)))

                # Auto-update state based on phase
                new_state = state_for_phase(decision.phase, c.get("state", "captured"))
                if new_state != c.get("state"):
                    db.update_state(c["id"], new_state)
                    log.schedule.info(f"State transition: {log.kv(id=c['id'], old=c.get('state'), new=new_state)}")

                # ── Auto-decay: adjust importance based on ignored nudges ────
                nudge_count = db.get_nudge_count(c["id"])
                current_importance = float(c.get("importance_score") or 0.5)

                if nudge_count >= 6 and c.get("state") not in ("completed", "abandoned"):
                    db.abandon_commitment(c["id"])
                    db.log_decision(
                        commitment_id=c["id"],
                        event="auto_abandoned",
                        phase=decision.phase.value,
                        action="none",
                        reasoning=f"Auto-abandoned after {nudge_count} unacknowledged nudges.",
                        urgency=decision.urgency,
                    )
                    log.schedule.warning(
                        f"Auto-abandoned: {log.kv(id=c['id'], nudges=nudge_count, desc=repr(c['description'][:50]))}"
                    )
                    _send_notification(
                        "Vigil — Archived",
                        f"Archived: '{c['description'][:50]}'",
                        user_id=c.get("user_id", "local"),
                        commitment_id=c["id"],
                    )
                    continue

                elif nudge_count in (3, 4, 5):
                    decayed = current_importance * 0.85
                    if abs(decayed - current_importance) > 0.01:
                        db.update_importance(c["id"], decayed)
                        db.log_decision(
                            commitment_id=c["id"],
                            event="importance_decayed",
                            phase=decision.phase.value,
                            action="none",
                            reasoning=f"Importance decayed {current_importance:.2f} → {decayed:.2f} after {nudge_count} nudges.",
                            urgency=decision.urgency,
                        )
                        log.schedule.info(
                            f"Decay: {log.kv(id=c['id'], before=f'{current_importance:.2f}', after=f'{decayed:.2f}', nudges=nudge_count)}"
                        )

                # Execute action
                if decision.action == Action.NOTIFY:
                    _send_notification(
                        "Vigil",
                        c["description"],
                        user_id=c.get("user_id", "local"),
                        commitment_id=c["id"],
                    )

            # Daily digest — per user
            if digest_sent_date != now.date():
                users_to_digest = set(db.get_all_user_ids()) | {"local"}
                any_sent = False
                for uid in users_to_digest:
                    digest_time = db.get_setting("digest_time", user_id=uid)
                    if not digest_time:
                        continue
                    try:
                        dh, dm = map(int, digest_time.split(":"))
                    except ValueError:
                        continue
                    if now.hour == dh and now.minute >= dm:
                        pending = db.get_pending(user_id=uid) if uid != "local" else [
                            c for c in db.get_pending() if c.get("user_id", "local") == "local"
                        ]
                        overdue_count = sum(
                            1 for c in pending
                            if c.get("due_by") and datetime.fromisoformat(c["due_by"]) < now
                        )
                        if pending:
                            msg = f"{len(pending)} pending"
                            if overdue_count:
                                msg += f", {overdue_count} overdue"
                        else:
                            msg = "All clear — no pending commitments."
                        _send_notification("Vigil — Good morning", msg, user_id=uid)
                        any_sent = True
                        log.schedule.info(log.kv(event="digest_sent", user=uid,
                                                 pending=len(pending), overdue=overdue_count))
                if any_sent:
                    digest_sent_date = now.date()

            # Prune decision log once per day
            if prune_done_date != now.date():
                db.prune_decision_log()
                prune_done_date = now.date()
                log.schedule.info(log.kv(event="decision_log_pruned"))

        except Exception as e:
            log.schedule.error(log.kv(event="loop_error", error=repr(str(e)), type=type(e).__name__))

        time.sleep(60)


def main():
    threading.Thread(target=_background_loop, daemon=True).start()
    port = start_dashboard(db)
    if port:
        print(f"Vigil dashboard → http://localhost:{port}", flush=True, file=__import__("sys").stderr)

    import os as _os
    _vf = _os.environ.get("VIGIL_FEATURES", "").strip()
    if _vf:
        try:
            from .features import set_enabled, FEATURES
            for _n in [n.strip() for n in _vf.split(",") if n.strip()]:
                if _n in FEATURES:
                    set_enabled(_n, True, db)
        except Exception:
            pass

    # REST API — only starts if fastapi + uvicorn are installed
    try:
        from .api import start_api, API_PORT
        api_port = start_api(db, port=API_PORT)
        if api_port:
            print(f"Vigil REST API  → http://localhost:{api_port}/docs", flush=True, file=__import__("sys").stderr)
    except Exception:
        pass  # FastAPI not installed — skip silently

    mcp.run()


if __name__ == "__main__":
    main()
