"""
Webhooks — outbound Slack/Discord nudges and inbound Slack slash commands.

Outbound: called by the background loop when a commitment needs a nudge.
Inbound:  slash commands POST to /api/slack/command (configure in Slack app settings).

Uses only Python stdlib (urllib, hashlib, hmac) — no extra dependencies.
"""

from __future__ import annotations

import hashlib
import hmac
import json
import os
import urllib.parse
import urllib.request
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .db import Database

from . import logger as log


# ─── Outbound: send nudge to Slack ──────────────────────────────────────────

def send_slack_nudge(webhook_url: str, title: str, message: str, commitment_id: int) -> bool:
    """POST a nudge to a Slack incoming webhook. Returns True on success."""
    payload = {
        "blocks": [
            {
                "type": "section",
                "text": {
                    "type": "mrkdwn",
                    "text": f"*{title}*\n{message}",
                },
            },
            {
                "type": "context",
                "elements": [
                    {"type": "mrkdwn", "text": f"Vigil · commitment ID {commitment_id}"},
                ],
            },
        ]
    }
    return _post_webhook(webhook_url, payload)


def send_discord_nudge(webhook_url: str, title: str, message: str) -> bool:
    """POST a nudge to a Discord webhook. Returns True on success."""
    payload = {
        "username": "Vigil",
        "embeds": [
            {
                "title": title,
                "description": message,
                "color": 0xF59E0B,  # Vigil amber
            }
        ],
    }
    return _post_webhook(webhook_url, payload)


def _post_webhook(url: str, payload: dict) -> bool:
    """POST JSON to a webhook URL using stdlib urllib. Returns True on success."""
    try:
        data = json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(
            url,
            data=data,
            headers={
                "Content-Type": "application/json",
                "User-Agent": "vigil-mcp/2.0",
            },
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=5) as resp:
            return resp.status < 300
    except Exception as e:
        log.server.error(log.kv(event="webhook_post_failed", url=url[:60], error=repr(str(e))[:100]))
        return False


# ─── Outbound: try all configured channels for a user ───────────────────────

def notify_via_webhooks(
    db: "Database",
    user_id: str,
    title: str,
    message: str,
    commitment_id: int,
) -> int:
    """
    Try all configured webhook channels for the given user.
    Reads webhook URLs from the settings table; falls back to env vars.
    Returns the number of successful sends.
    """
    sent = 0

    # ── Slack ──
    slack_url = (
        db.get_setting("slack_webhook_url", user_id=user_id)
        or os.environ.get("VIGIL_SLACK_WEBHOOK", "")
    )
    slack_enabled = db.get_setting("slack_nudge_enabled", default="true", user_id=user_id)
    if slack_url and slack_enabled == "true":
        if send_slack_nudge(slack_url, title, message, commitment_id):
            sent += 1
            log.server.info(log.kv(event="slack_nudge_sent", user=user_id, id=commitment_id))
        else:
            log.server.error(log.kv(event="slack_nudge_failed", user=user_id, id=commitment_id))

    # ── Discord ──
    discord_url = (
        db.get_setting("discord_webhook_url", user_id=user_id)
        or os.environ.get("VIGIL_DISCORD_WEBHOOK", "")
    )
    discord_enabled = db.get_setting("discord_nudge_enabled", default="true", user_id=user_id)
    if discord_url and discord_enabled == "true":
        if send_discord_nudge(discord_url, f"Vigil — {title}", message):
            sent += 1
            log.server.info(log.kv(event="discord_nudge_sent", user=user_id, id=commitment_id))
        else:
            log.server.error(log.kv(event="discord_nudge_failed", user=user_id, id=commitment_id))

    return sent


# ─── Inbound: Slack slash command verification ───────────────────────────────

def verify_slack_signature(
    signing_secret: str, timestamp: str, body_bytes: bytes, signature: str
) -> bool:
    """
    Verify X-Slack-Signature header to confirm the request came from Slack.
    Returns True if valid, False otherwise.
    """
    sig_basestring = f"v0:{timestamp}:{body_bytes.decode('utf-8')}".encode()
    expected = "v0=" + hmac.new(
        signing_secret.encode(), sig_basestring, hashlib.sha256
    ).hexdigest()
    return hmac.compare_digest(expected, signature)


def parse_slack_slash_command(body_bytes: bytes) -> dict:
    """
    Parse a URL-encoded Slack slash command body.
    Returns dict with keys: text, user_id, user_name, channel_id, command.
    """
    parsed = urllib.parse.parse_qs(body_bytes.decode("utf-8"))
    return {
        "text":       parsed.get("text",       [""])[0],
        "user_id":    parsed.get("user_id",     [""])[0],
        "user_name":  parsed.get("user_name",   [""])[0],
        "channel_id": parsed.get("channel_id",  [""])[0],
        "command":    parsed.get("command",     ["/vigil"])[0],
    }


def slack_response(text: str, response_type: str = "ephemeral") -> dict:
    """Build a Slack slash command JSON response."""
    return {"response_type": response_type, "text": text}
