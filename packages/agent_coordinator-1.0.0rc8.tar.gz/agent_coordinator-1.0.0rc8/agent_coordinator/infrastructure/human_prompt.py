"""Human interaction prompts for the coordinator."""

from __future__ import annotations

import subprocess
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


def prompt_human_input(handoff_path: Path, task_id: str, current_status: str, display=None) -> str:
    """
    Prompt the user for input when the workflow requires human action.
    Uses the TUI display when available, falls back to plain text otherwise.
    Returns 'continue' or 'quit'.
    """
    if display is not None and hasattr(display, "show_error_dialog"):
        return _prompt_tui(handoff_path, task_id, current_status, display)
    return _prompt_plain(handoff_path, task_id, current_status)


# ── TUI path ──────────────────────────────────────────────────────────────────


def _prompt_tui(handoff_path: Path, task_id: str, current_status: str, display) -> str:
    t = display._theme

    display._append_content("")
    display._append_content(
        f"  {t.color_warning}\033[1m⚠  Human input required\033[0m"
        f"  {t.text_dim}task: {task_id}  status: {current_status}\033[0m"
    )
    display._append_content(f"  {t.text_dim}{'─' * (display._cols - 4)}\033[0m")

    while True:
        choice = display.show_error_dialog(
            "Human Input Required",
            f"Task: {task_id}\nStatus: {current_status}\n\nThe workflow needs your input to continue.",
            [("r", "Respond"), ("e", "Edit handoff.md"), ("v", "View handoff"), ("q", "Quit")],
        )

        if choice == "r":
            display._append_content(f"  {t.text_dim}Enter your response (blank line to finish):\033[0m")
            lines: list[str] = []
            while True:
                line = display.read_input("")
                if line == "":
                    break
                lines.append(line)

            response = "\n".join(lines).strip()
            if not response:
                display._append_content(f"  {t.color_warning}⚠  No response entered\033[0m")
                continue

            next_agent_raw = display.read_input("Route to agent [architect/developer/qa_engineer/helper]: ")
            next_agent = next_agent_raw.strip().lower() or "architect"

            _write_human_handoff(handoff_path, task_id, response, next_agent)
            display._append_content(f"  {t.color_success}✓  Response added → routing to {next_agent}\033[0m")
            return "continue"

        if choice == "e":
            display.with_editor(handoff_path)
            return "continue"

        if choice == "v":
            if handoff_path.exists():
                lines_view = handoff_path.read_text(errors="replace").splitlines()
                display._append_content(f"  {t.text_dim}── handoff.md ({'last 30 lines'}) ──\033[0m")
                for ln in lines_view[-30:]:
                    display._append_content(f"  {t.text_secondary}{ln}\033[0m")
            # loop back to show dialog again

        elif choice == "q":
            return "quit"


# ── Plain-text fallback ───────────────────────────────────────────────────────


def _prompt_plain(handoff_path: Path, task_id: str, current_status: str) -> str:
    print("\n" + "═" * 70)
    print("HUMAN INPUT REQUIRED")
    print("─" * 70)
    print(f"Task: {task_id}")
    print(f"Status: {current_status}")
    print("\nOptions:  r=Respond  e=Edit handoff  v=View  q=Quit")
    print("─" * 70)

    from agent_coordinator.infrastructure.enhanced_input import Colors, enhanced_choice, enhanced_input

    while True:
        choice = enhanced_choice(Colors.prompt("Choice [r/e/v/q]: "), choices=["r", "e", "v", "q"])

        if choice == "r":
            print(Colors.info("\nProvide your guidance (blank line to finish):"))
            lines: list[str] = []
            while True:
                try:
                    line = input("> ")
                except (EOFError, KeyboardInterrupt):
                    break
                if line == "":
                    break
                lines.append(line)
            response = "\n".join(lines).strip()
            if not response:
                print(Colors.warning("No response entered."))
                continue
            next_agent = (
                enhanced_input(
                    Colors.prompt("Route to agent [architect/developer/qa_engineer]: "),
                    default="architect",
                )
                .strip()
                .lower()
                or "architect"
            )
            _write_human_handoff(handoff_path, task_id, response, next_agent)
            print(Colors.success(f"✓ Response added → {next_agent}"))
            print("═" * 70)
            return "continue"

        if choice == "e":
            from agent_coordinator.infrastructure.editor import get_editor

            editor = get_editor()
            try:
                subprocess.run([editor, str(handoff_path)], check=True)
            except Exception as exc:
                print(f"Editor error: {exc}")
            print("═" * 70)
            return "continue"

        if choice == "v":
            if handoff_path.exists():
                print("\n" + "─" * 70)
                for ln in handoff_path.read_text().splitlines()[-30:]:
                    print(ln)
                print("─" * 70)
            enhanced_input(Colors.prompt("\nPress Enter to continue..."))

        elif choice == "q":
            print("═" * 70)
            return "quit"


# ── Shared ────────────────────────────────────────────────────────────────────


def _write_human_handoff(handoff_path: Path, task_id: str, response: str, next_agent: str) -> None:
    timestamp = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
    block = f"""
---HANDOFF---
ROLE: human
STATUS: continue
NEXT: {next_agent}
TASK_ID: {task_id}
TITLE: Human response provided
SUMMARY: Human provided guidance and direction for the workflow to continue.

Human response ({timestamp}):
{response}

ACCEPTANCE:
- Agent acknowledges human guidance
- Agent proceeds accordingly

CONSTRAINTS:
- Follow human guidance provided above
---END---
"""
    with open(handoff_path, "a") as f:
        f.write(block)


def _prompt_human_input_plain(handoff_path: Path, task_id: str, current_status: str) -> str:
    """
    Prompt human for input when the workflow requires human action.

    Returns:
        Action taken ('continue', 'quit', etc.)
    """
    print("\n" + "═" * 70)
    print("HUMAN INPUT REQUIRED")
    print("─" * 70)
    print(f"Task: {task_id}")
    print(f"Status: {current_status}")
    print("─" * 70)
    print("\nThe workflow needs your input to continue.")
    print("\nOptions:")
    print("  r - Respond with guidance (creates new handoff)")
    print("  e - Edit handoff.md manually in your editor")
    print("  v - View current handoff.md")
    print("  q - Quit")
    print("\n" + "─" * 70)

    from agent_coordinator.infrastructure.enhanced_input import (
        Colors,
        enhanced_choice,
        enhanced_input,
        enhanced_multiline,
    )

    while True:
        prompt = Colors.prompt("Choice [r/e/v/q]: ")
        choice = enhanced_choice(prompt, choices=["r", "e", "v", "q"])

        if choice == "r":
            result = _handle_respond(handoff_path, task_id, Colors, enhanced_input, enhanced_multiline)
            if result:
                return result
            continue

        if choice == "e":
            result = _handle_edit(handoff_path, Colors)
            if result:
                return result
            continue

        if choice == "v":
            _handle_view(handoff_path, Colors, enhanced_input)
            continue

        if choice == "q":
            print("═" * 70)
            return "quit"

        print("Invalid choice. Try again.")


def _handle_respond(
    handoff_path: Path,
    task_id: str,
    colors: Any,
    enhanced_input_fn: Any,
    enhanced_multiline_fn: Any,
) -> str:
    """Handle the 'respond' choice in _prompt_human_input_plain."""
    print("\n" + colors.info("Provide your response/guidance:"))
    print(colors.info("(This will be added to the handoff for the next agent)"))
    print()

    response = enhanced_multiline_fn("", colors.prompt("> "))

    if not response.strip():
        print(colors.warning("No response entered. Try again."))
        return ""  # signal to caller to continue the loop

    print()
    next_agent = (
        enhanced_input_fn(
            colors.prompt("Route to agent [architect/developer/qa_engineer/helper]: "), default="architect"
        )
        .strip()
        .lower()
    )

    if not next_agent:
        next_agent = "architect"

    use_helper = False
    if next_agent != "helper":
        format_choice = (
            enhanced_input_fn(colors.prompt("Format with helper agent first? [y/N]: "), default="n").strip().lower()
        )
        use_helper = format_choice in ["y", "yes"]

    handoff_block = _build_respond_handoff(task_id, response, next_agent, use_helper)

    if use_helper:
        print()
        print(colors.info("✓ Routing to helper agent for formatting"))
        print(colors.info(f"  Helper will format and route to: {next_agent}"))

    with open(handoff_path, "a") as f:
        f.write(handoff_block)

    print()
    print(colors.success("✓ Response added to handoff.md"))
    if use_helper:
        print(colors.success(f"✓ Routing to: helper → {next_agent}"))
    else:
        print(colors.success(f"✓ Routing to: {next_agent}"))
    print("═" * 70)
    return "continue"


def _build_respond_handoff(task_id: str, response: str, next_agent: str, use_helper: bool) -> str:
    """Build the handoff block for a human response."""
    timestamp = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
    if use_helper:
        return f"""
---HANDOFF---
ROLE: system
STATUS: continue
NEXT: helper
TASK_ID: {task_id}
TITLE: Format human input
SUMMARY: Human provided informal guidance that needs to be formatted into a proper handoff block for the {next_agent} agent.

Raw human input ({timestamp}):
{response}

Target agent: {next_agent}

ACCEPTANCE:
- Human input formatted into proper handoff structure
- Key requirements extracted and organized
- Handoff routed to {next_agent}

CONSTRAINTS:
- Preserve all information from human input
- Follow handoff format standards
---END---
"""
    return f"""
---HANDOFF---
ROLE: human
STATUS: continue
NEXT: {next_agent}
TASK_ID: {task_id}
TITLE: Human response provided
SUMMARY: Human provided guidance and direction for the workflow to continue.

Human response ({timestamp}):
{response}

ACCEPTANCE:
- Agent acknowledges human guidance
- Agent proceeds with implementation

CONSTRAINTS:
- Follow human guidance provided above

FILES_TO_TOUCH:
- handoff.md

CHANGED_FILES:
- handoff.md

VALIDATION:
- n/a

BLOCKERS:
- None
---END---
"""


def _handle_edit(handoff_path: Path, colors: Any) -> str:
    """Handle the 'edit' choice in _prompt_human_input_plain."""
    from agent_coordinator.infrastructure.editor import get_editor

    editor = get_editor()
    print(f"\nOpening handoff.md in {editor}...")
    try:
        subprocess.run([editor, str(handoff_path)], check=True)
        print(colors.success("Handoff updated"))
        print("═" * 70)
        return "continue"
    except Exception as e:
        print(colors.error(f"Editor error: {e}"))
        return ""  # signal to caller to continue the loop


def _handle_view(handoff_path: Path, colors: Any, enhanced_input_fn: Any) -> None:
    """Handle the 'view' choice in _prompt_human_input_plain."""
    if handoff_path.exists():
        print("\nCurrent handoff.md:")
        print("─" * 70)
        content = handoff_path.read_text()
        lines = content.split("\n")
        for line in lines[-50:]:
            print(line)
        print("─" * 70)
    enhanced_input_fn(colors.prompt("\nPress Enter to continue..."))
