"""Discussion system for agent-to-agent messaging in rooms.

Provides summarization and memory-write hooks for discussions.
The actual message CRUD is in routes.py; this module handles
the intelligence layer on top.
"""

from __future__ import annotations

import json
import logging
import os
from typing import Any, Callable
from uuid import UUID

from psycopg.rows import dict_row

logger = logging.getLogger(__name__)

SUMMARIZE_THRESHOLD = 20


class DiscussionEngine:
    """Manages discussion summarization and memory integration."""

    def __init__(self, pool, get_memory: Callable | None = None):
        self._pool = pool
        self._get_memory = get_memory
        self._model = os.environ.get("AMFS_MEDIATOR_MODEL", "openai/gpt-4o-mini")

    def get_unsummarized_count(self, room_id: UUID) -> int:
        with self._pool.connection() as conn:
            row = conn.execute(
                "SELECT count(*) FROM discussion_messages "
                "WHERE room_id = %s AND metadata->>'summarized' IS NULL",
                (str(room_id),),
            ).fetchone()
            return row[0] if row else 0

    def should_summarize(self, room_id: UUID) -> bool:
        return self.get_unsummarized_count(room_id) >= SUMMARIZE_THRESHOLD

    async def summarize_and_store(self, room_id: UUID, account_id: UUID) -> str | None:
        """Summarize recent discussion messages and write to room entity memory."""
        with self._pool.connection() as conn:
            conn.row_factory = dict_row
            messages = list(conn.execute(
                "SELECT agent_id, content, message_type, created_at "
                "FROM discussion_messages "
                "WHERE room_id = %s AND metadata->>'summarized' IS NULL "
                "ORDER BY created_at LIMIT %s",
                (str(room_id), SUMMARIZE_THRESHOLD * 2),
            ).fetchall())

        if not messages:
            return None

        summary = await self._generate_summary(messages)
        if not summary:
            return None

        room_row = None
        with self._pool.connection() as conn:
            conn.row_factory = dict_row
            room_row = conn.execute(
                "SELECT entity_path FROM entity_rooms WHERE id = %s",
                (str(room_id),),
            ).fetchone()

        if room_row and self._get_memory:
            mem = self._get_memory()
            from datetime import datetime, timezone
            ts = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")
            mem.write(
                entity_path=room_row["entity_path"],
                key=f"discussion-summary/{ts}",
                value=summary,
            )

        msg_ids = [str(m.get("id", "")) for m in messages if m.get("id")]
        if msg_ids:
            with self._pool.connection() as conn:
                conn.execute(
                    "UPDATE discussion_messages "
                    "SET metadata = metadata || '{\"summarized\": true}'::jsonb "
                    "WHERE room_id = %s AND metadata->>'summarized' IS NULL",
                    (str(room_id),),
                )
                conn.commit()

        return summary

    async def _generate_summary(self, messages: list[dict[str, Any]]) -> str | None:
        try:
            import litellm

            transcript = "\n".join(
                f"[{m.get('agent_id', '?')}] ({m.get('message_type', 'msg')}): {m.get('content', '')}"
                for m in messages
            )

            resp = await litellm.acompletion(
                model=self._model,
                messages=[
                    {
                        "role": "system",
                        "content": (
                            "Summarize this agent discussion concisely. "
                            "Highlight key decisions, disagreements, questions raised, "
                            "and action items. Keep it under 500 words."
                        ),
                    },
                    {"role": "user", "content": transcript},
                ],
                temperature=0.3,
            )
            return resp.choices[0].message.content
        except Exception:
            logger.warning("LLM summarization failed, using simple concat", exc_info=True)
            lines = [
                f"- [{m.get('agent_id', '?')}]: {m.get('content', '')[:100]}"
                for m in messages[:10]
            ]
            return "Discussion summary (auto):\n" + "\n".join(lines)
