"""RoomAdapterMixin — extends Pro adapters with room operation support.

Provides a standard interface for room CRUD, membership, and activity
that can be mixed into the HTTP and Postgres adapters.
"""

from __future__ import annotations

import logging
from typing import Any, Protocol
from uuid import UUID

logger = logging.getLogger(__name__)


class RoomAdapterProtocol(Protocol):
    """Protocol that room-aware adapters must implement."""

    def room_create(self, **kwargs: Any) -> dict: ...
    def room_get(self, room_id: str, account_id: str) -> dict | None: ...
    def room_list(self, account_id: str, user_id: str | None = None) -> list[dict]: ...
    def room_update(self, room_id: str, account_id: str, **kwargs: Any) -> dict | None: ...
    def room_close(self, room_id: str, account_id: str, closed_by: str) -> dict | None: ...
    def room_invite(self, room_id: str, **kwargs: Any) -> dict: ...
    def room_join(self, room_id: str, agent_id: str, **kwargs: Any) -> dict | None: ...
    def room_leave(self, room_id: str, agent_id: str, account_id: str) -> bool: ...
    def room_members(self, room_id: str, account_id: str) -> list[dict]: ...
    def room_activity(self, room_id: str, account_id: str, **kwargs: Any) -> tuple[list[dict], int]: ...


class RoomAdapterMixin:
    """Mixin for Pro adapters that adds room operations via RoomService.

    Mix into PostgresAdapter or HttpAdapter. Requires the adapter to have
    a ``_pool`` attribute (Postgres) or ``_base_url``/``_session`` (HTTP).
    """

    _room_service: Any = None

    def _get_room_service(self) -> Any:
        if self._room_service is not None:
            return self._room_service
        pool = getattr(self, "_pool", None)
        if pool is None:
            raise NotImplementedError("Room operations require Postgres adapter")
        from .service import RoomService
        get_memory = getattr(self, "_get_memory", None)
        self._room_service = RoomService(pool, get_memory=get_memory)
        return self._room_service

    def room_create(self, **kwargs: Any) -> dict:
        svc = self._get_room_service()
        return svc.create_room(**kwargs)

    def room_get(self, room_id: str, account_id: str) -> dict | None:
        svc = self._get_room_service()
        return svc.get_room(UUID(room_id), UUID(account_id))

    def room_list(self, account_id: str, user_id: str | None = None) -> list[dict]:
        svc = self._get_room_service()
        return svc.list_rooms(UUID(account_id), UUID(user_id) if user_id else None)

    def room_update(self, room_id: str, account_id: str, **kwargs: Any) -> dict | None:
        svc = self._get_room_service()
        return svc.update_room(UUID(room_id), UUID(account_id), **kwargs)

    def room_close(self, room_id: str, account_id: str, closed_by: str) -> dict | None:
        svc = self._get_room_service()
        return svc.close_room(UUID(room_id), UUID(account_id), UUID(closed_by))

    def room_invite(self, room_id: str, **kwargs: Any) -> dict:
        svc = self._get_room_service()
        return svc.invite_user(room_id=UUID(room_id), **{
            k: UUID(v) if k in ("account_id", "invited_user_id", "invited_by") else v
            for k, v in kwargs.items()
        })

    def room_join(self, room_id: str, agent_id: str, **kwargs: Any) -> dict | None:
        svc = self._get_room_service()
        return svc.agent_join(
            room_id=UUID(room_id),
            agent_id=agent_id,
            **{
                k: UUID(v) if k in ("account_id", "owner_user_id") else v
                for k, v in kwargs.items()
            },
        )

    def room_leave(self, room_id: str, agent_id: str, account_id: str) -> bool:
        svc = self._get_room_service()
        return svc.agent_leave(UUID(room_id), UUID(account_id), agent_id)

    def room_members(self, room_id: str, account_id: str) -> list[dict]:
        svc = self._get_room_service()
        return svc.list_members(UUID(room_id), UUID(account_id))

    def room_activity(
        self, room_id: str, account_id: str, **kwargs: Any
    ) -> tuple[list[dict], int]:
        svc = self._get_room_service()
        return svc.list_activity(UUID(room_id), UUID(account_id), **kwargs)
