"""Negotiation engine — orchestrates session lifecycle and state machine.

Combines the mediator, protocol, and reviewer into a cohesive workflow
that manages sessions from creation through consensus/failure.
"""

from __future__ import annotations

import json
import logging
from datetime import datetime, timedelta, timezone
from typing import Any, Callable
from uuid import UUID, uuid4

from psycopg.rows import dict_row

from .mediator import LLMMediator
from .models import (
    CreateSessionRequest,
    MediatorAnalysis,
    NegotiationSessionResponse,
    NegotiationIssueResponse,
    NegotiationOutcomeResponse,
    NegotiationRoundResponse,
    OutcomeType,
    RoundAction,
    SessionStatus,
    SubmitProposalRequest,
)
from .protocol import AlternatingOffersProtocol
from .reviewer import NegotiationReviewer

logger = logging.getLogger(__name__)


class NegotiationEngine:
    """Orchestrates NegMAS-style negotiation sessions."""

    def __init__(
        self,
        pool,
        get_memory: Callable | None = None,
        mediator: LLMMediator | None = None,
        reviewer: NegotiationReviewer | None = None,
    ):
        self._pool = pool
        self._get_memory = get_memory
        self._protocol = AlternatingOffersProtocol(pool)
        self._mediator = mediator or LLMMediator()
        self._reviewer = reviewer or NegotiationReviewer()

    def _tenant_conn(self, account_id: UUID):
        """Return a connection context manager with the RLS GUC set."""
        import contextlib

        @contextlib.contextmanager
        def _ctx():
            with self._pool.connection() as conn:
                conn.row_factory = dict_row
                conn.execute(
                    "SELECT set_config('amfs.current_account_id', %s, false)",
                    (str(account_id),),
                )
                yield conn

        return _ctx()

    def _write_memory_as(
        self,
        agent_id: str,
        entity_path: str,
        key: str,
        value: Any,
        *,
        memory_type: str = "fact",
    ) -> None:
        """Write a memory entry attributed to a specific agent instead of amfs-server."""
        if not self._get_memory:
            return
        try:
            from amfs_core.models import MemoryEntry, MemoryType, Provenance

            mem = self._get_memory()
            adapter = mem.adapter
            now = datetime.now(timezone.utc)

            mt = {"fact": MemoryType.FACT, "belief": MemoryType.BELIEF, "experience": MemoryType.EXPERIENCE}
            current = adapter.read(entity_path, key)
            next_version = (current.version + 1) if current else 1

            entry = MemoryEntry(
                entity_path=entity_path,
                key=key,
                version=next_version,
                value=value,
                provenance=Provenance(
                    agent_id=agent_id,
                    session_id=str(uuid4()),
                    written_at=now,
                ),
                confidence=1.0,
                memory_type=mt.get(memory_type, MemoryType.FACT),
            )
            adapter.write(entry)
        except Exception:
            logger.debug("_write_memory_as(%s) failed for %s/%s", agent_id, entity_path, key, exc_info=True)

    async def create_session(
        self,
        request: CreateSessionRequest,
        agent_id: str,
        account_id: UUID,
        created_by_user_id: UUID | None = None,
    ) -> dict[str, Any]:
        """Create a new negotiation session."""
        deadline_at = None
        if request.deadline_minutes:
            deadline_at = datetime.now(timezone.utc) + timedelta(minutes=request.deadline_minutes)

        with self._tenant_conn(account_id) as conn:
            row = conn.execute(
                """INSERT INTO negotiation_sessions
                   (room_id, account_id, title, description, strategy,
                    max_rounds, deadline_at, created_by, created_by_user_id)
                   VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
                   RETURNING *""",
                (
                    str(request.room_id), str(account_id),
                    request.title, request.description,
                    request.strategy.value, request.max_rounds,
                    deadline_at, agent_id,
                    str(created_by_user_id) if created_by_user_id else None,
                ),
            ).fetchone()
            conn.commit()
            session = dict(row) if row else {}

        self._write_negotiation_memory_entry(
            request.room_id, account_id, session, request.title, agent_id,
        )

        return session

    def _write_negotiation_memory_entry(
        self,
        room_id: UUID | str,
        account_id: UUID,
        session: dict,
        title: str,
        created_by: str,
    ) -> None:
        """Write a memory entry so agents can discover the negotiation via amfs_search/amfs_list."""
        entity_path = self._get_room_entity_path(str(room_id))
        if not entity_path:
            return
        topic_slug = title.lower().replace(" ", "-")[:50]
        self._write_memory_as(
            agent_id=created_by,
            entity_path=entity_path,
            key=f"active-negotiation/{topic_slug}",
            value=json.dumps({
                "session_id": str(session.get("id", "")),
                "title": title,
                "status": "open",
                "created_by": created_by,
                "room_id": str(room_id),
                "action_needed": (
                    "There is an active negotiation. Use amfs_negotiate_status(session_id) "
                    "to see details and amfs_negotiate_propose(session_id, ...) to submit "
                    "your position."
                ),
            }),
            memory_type="fact",
        )

    async def add_issues(
        self,
        session_id: UUID,
        issues: list[dict[str, Any]],
    ) -> list[dict[str, Any]]:
        """Add issues/dimensions to a negotiation session."""
        results = []
        with self._pool.connection() as conn:
            conn.row_factory = dict_row
            for issue in issues:
                row = conn.execute(
                    """INSERT INTO negotiation_issues
                       (session_id, name, description, value_type, constraints, weight)
                       VALUES (%s, %s, %s, %s, %s::jsonb, %s)
                       RETURNING *""",
                    (
                        str(session_id), issue["name"],
                        issue.get("description"), issue.get("value_type", "text"),
                        json.dumps(issue.get("constraints", {})),
                        issue.get("weight", 1.0),
                    ),
                ).fetchone()
                if row:
                    results.append(dict(row))
            conn.commit()
        return results

    async def submit_proposal(
        self,
        request: SubmitProposalRequest,
        agent_id: str,
    ) -> dict[str, Any]:
        """Submit an agent's proposal/response and trigger mediator analysis."""
        session = await self._protocol.get_session(request.session_id)
        if not session:
            raise ValueError("Session not found")
        if session["status"] in ("consensus", "failed", "cancelled"):
            raise ValueError(f"Session already {session['status']}")

        if session["status"] == "open":
            await self._protocol.update_session_status(
                request.session_id, SessionStatus.IN_PROGRESS,
            )

        mediator_text = None
        round_row = await self._protocol.submit_action(
            session_id=request.session_id,
            agent_id=agent_id,
            action=request.action,
            proposal=request.proposal,
            rationale=request.rationale,
            mediator_analysis=mediator_text,
            confidence=0.5,
        )

        analysis = await self._run_mediator_analysis(request.session_id, session)
        if analysis and analysis.mediator_analysis:
            round_row["mediator_analysis"] = analysis.mediator_analysis

        consensus_type = await self._protocol.check_consensus(request.session_id)
        if consensus_type or (analysis and analysis.should_conclude):
            final_type = consensus_type or (
                analysis.recommended_outcome if analysis else OutcomeType.TIMEOUT
            )
            if final_type:
                await self._conclude_session(
                    request.session_id, final_type, request.proposal, session,
                )

        return round_row

    async def _run_mediator_analysis(
        self,
        session_id: UUID,
        session: dict[str, Any],
    ) -> MediatorAnalysis | None:
        """Run the LLM mediator analysis on the current round."""
        issues = await self._protocol.get_issues(session_id)
        all_rounds = await self._protocol.get_rounds(session_id)
        current_round_num = await self._protocol.get_current_round_number(session_id)

        current_round = [
            r for r in all_rounds if r.get("round_number") == current_round_num
        ]
        prior_rounds = [
            r for r in all_rounds if r.get("round_number") < current_round_num
        ]

        analysis = await self._mediator.analyze_round(
            title=session.get("title", ""),
            description=session.get("description"),
            issues=[dict(i) for i in issues],
            rounds=[dict(r) for r in prior_rounds],
            current_round=[dict(r) for r in current_round],
            round_number=current_round_num,
            max_rounds=session.get("max_rounds", 10),
        )
        return analysis

    async def _conclude_session(
        self,
        session_id: UUID,
        outcome_type: OutcomeType,
        final_proposal: dict[str, Any],
        session: dict[str, Any],
    ) -> None:
        """Conclude a session: record outcome, run reviewer, write to memory."""
        participants = await self._protocol.get_participating_agents(session_id)
        rounds = await self._protocol.get_rounds(session_id)

        reject_agents = list({
            r.get("agent_id", "")
            for r in rounds
            if r.get("action") == "reject"
            and r.get("round_number") == await self._protocol.get_current_round_number(session_id)
        })

        outcome = await self._protocol.record_outcome(
            session_id=session_id,
            outcome_type=outcome_type,
            final_proposal=final_proposal,
            participating_agents=participants,
            dissenting_agents=reject_agents,
            summary=None,
        )

        try:
            review = await self._reviewer.review_session(
                title=session.get("title", ""),
                outcome_type=outcome_type.value,
                total_rounds=len(set(r.get("round_number", 0) for r in rounds)),
                issues=await self._protocol.get_issues(session_id),
                final_proposal=final_proposal,
                participants=participants,
                dissenters=reject_agents,
                rounds=[dict(r) for r in rounds],
            )

            if review:
                room_id = session.get("room_id")
                entity_path = self._get_room_entity_path(room_id)
                if entity_path:
                    prefix = "decisions" if outcome_type in (
                        OutcomeType.CONSENSUS, OutcomeType.MAJORITY,
                        OutcomeType.MEDIATOR_DECISION,
                    ) else "failed"
                    topic_slug = session.get("title", "unknown").lower().replace(" ", "-")[:50]
                    concluded_by = session.get("created_by", "unknown")
                    self._write_memory_as(
                        agent_id=concluded_by,
                        entity_path=entity_path,
                        key=f"{prefix}/{topic_slug}",
                        value=json.dumps({
                            "outcome": outcome_type.value,
                            "final_proposal": final_proposal,
                            "participants": participants,
                            "dissenting": reject_agents,
                            "review": review.model_dump(),
                        }),
                    )
        except Exception:
            logger.warning("Failed to write negotiation outcome to memory", exc_info=True)

    async def cancel_session(
        self,
        session_id: UUID,
        cancelled_by: str,
        reason: str | None = None,
        account_id: UUID | None = None,
    ) -> dict[str, Any]:
        """Cancel a negotiation session and record the cancellation to memory."""
        with self._pool.connection() as conn:
            conn.row_factory = dict_row
            if account_id:
                conn.execute(
                    "SELECT set_config('amfs.current_account_id', %s, false)",
                    (str(account_id),),
                )

            session = conn.execute(
                "SELECT * FROM negotiation_sessions WHERE id = %s",
                (str(session_id),),
            ).fetchone()
            if not session:
                raise ValueError("Session not found")
            if session["status"] in ("consensus", "failed", "cancelled"):
                raise ValueError(f"Session already {session['status']}")

            rounds = list(conn.execute(
                "SELECT * FROM negotiation_rounds WHERE session_id = %s",
                (str(session_id),),
            ).fetchall())
            participants = list({r.get("agent_id", "") for r in rounds})

            conn.execute(
                """INSERT INTO negotiation_outcomes
                   (session_id, outcome_type, final_proposal,
                    participating_agents, dissenting_agents, summary)
                   VALUES (%s, 'failed', '{}'::jsonb, %s, %s, %s)
                   ON CONFLICT DO NOTHING""",
                (
                    str(session_id),
                    participants,
                    [],
                    reason or f"Cancelled by {cancelled_by}",
                ),
            )
            conn.execute(
                "UPDATE negotiation_sessions SET status = 'cancelled', resolved_at = now() "
                "WHERE id = %s",
                (str(session_id),),
            )
            conn.commit()

        room_id = session.get("room_id")
        entity_path = self._get_room_entity_path(room_id)
        if entity_path:
            topic_slug = session.get("title", "unknown").lower().replace(" ", "-")[:50]
            self._write_memory_as(
                agent_id=cancelled_by,
                entity_path=entity_path,
                key=f"cancelled-negotiation/{topic_slug}",
                value=json.dumps({
                    "session_id": str(session_id),
                    "title": session.get("title"),
                    "cancelled_by": cancelled_by,
                    "reason": reason,
                    "round_count": len(set(r.get("round_number", 0) for r in rounds)),
                    "participants": participants,
                    "warning": (
                        "This negotiation was cancelled. "
                        "Proposals and positions discussed during this session "
                        "should NOT be treated as agreed decisions."
                    ),
                }),
                memory_type="experience",
            )

        return {
            "id": session["id"],
            "status": "cancelled",
            "cancelled_by": cancelled_by,
            "reason": reason,
        }

    def _get_room_entity_path(self, room_id) -> str | None:
        if not room_id:
            return None
        with self._pool.connection() as conn:
            conn.row_factory = dict_row
            row = conn.execute(
                "SELECT entity_path FROM entity_rooms WHERE id = %s",
                (str(room_id),),
            ).fetchone()
            return row["entity_path"] if row else None

    async def get_session_detail(self, session_id: UUID) -> NegotiationSessionResponse | None:
        """Get full session details including issues, rounds, outcome."""
        session = await self._protocol.get_session(session_id)
        if not session:
            return None

        issues = await self._protocol.get_issues(session_id)
        rounds = await self._protocol.get_rounds(session_id)

        with self._pool.connection() as conn:
            conn.row_factory = dict_row
            outcome_row = conn.execute(
                "SELECT * FROM negotiation_outcomes WHERE session_id = %s LIMIT 1",
                (str(session_id),),
            ).fetchone()

        outcome = None
        if outcome_row:
            outcome = NegotiationOutcomeResponse(**outcome_row)

        participants = list({r.get("agent_id", "") for r in rounds})

        return NegotiationSessionResponse(
            id=session["id"],
            room_id=session["room_id"],
            title=session["title"],
            description=session.get("description"),
            status=SessionStatus(session["status"]),
            strategy=session["strategy"],
            max_rounds=session["max_rounds"],
            created_by=session["created_by"],
            created_by_user_id=session.get("created_by_user_id"),
            created_at=session["created_at"],
            resolved_at=session.get("resolved_at"),
            issues=[NegotiationIssueResponse(**i) for i in issues],
            rounds=[NegotiationRoundResponse(**r) for r in rounds],
            outcome=outcome,
            round_count=len(set(r.get("round_number", 0) for r in rounds)),
            participant_count=len(participants),
        )

    async def list_sessions(
        self,
        room_id: UUID,
        status: str | None = None,
        limit: int = 50,
        account_id: UUID | None = None,
    ) -> list[dict[str, Any]]:
        """List negotiation sessions for a room."""
        with self._pool.connection() as conn:
            conn.row_factory = dict_row
            if account_id:
                conn.execute(
                    "SELECT set_config('amfs.current_account_id', %s, false)",
                    (str(account_id),),
                )
            if status:
                rows = conn.execute(
                    "SELECT * FROM negotiation_sessions "
                    "WHERE room_id = %s AND status = %s "
                    "ORDER BY created_at DESC LIMIT %s",
                    (str(room_id), status, limit),
                ).fetchall()
            else:
                rows = conn.execute(
                    "SELECT * FROM negotiation_sessions "
                    "WHERE room_id = %s ORDER BY created_at DESC LIMIT %s",
                    (str(room_id), limit),
                ).fetchall()
            return [dict(r) for r in rows]
