"""Pydantic models for the NegMAS-inspired negotiation engine."""

from __future__ import annotations

from datetime import datetime
from enum import Enum
from typing import Any
from uuid import UUID

from pydantic import BaseModel, Field


class SessionStatus(str, Enum):
    OPEN = "open"
    IN_PROGRESS = "in_progress"
    CONSENSUS = "consensus"
    FAILED = "failed"
    CANCELLED = "cancelled"


class NegotiationStrategy(str, Enum):
    MEDIATED = "mediated"
    ROUND_ROBIN = "round_robin"
    FREE_FORM = "free_form"


class RoundAction(str, Enum):
    PROPOSE = "propose"
    COUNTER = "counter"
    ACCEPT = "accept"
    REJECT = "reject"
    ABSTAIN = "abstain"


class AgentBehaviorType(str, Enum):
    BOULWARE = "boulware"
    CONCEDER = "conceder"
    LINEAR = "linear"
    UNPREDICTABLE = "unpredictable"


class OutcomeType(str, Enum):
    CONSENSUS = "consensus"
    MAJORITY = "majority"
    MEDIATOR_DECISION = "mediator_decision"
    TIMEOUT = "timeout"
    FAILED = "failed"


# --- Request models ---

class CreateSessionRequest(BaseModel):
    room_id: UUID
    title: str
    description: str | None = None
    strategy: NegotiationStrategy = NegotiationStrategy.MEDIATED
    max_rounds: int = 10
    deadline_minutes: int | None = None


class SubmitProposalRequest(BaseModel):
    session_id: UUID
    action: RoundAction
    proposal: dict[str, Any] = Field(default_factory=dict)
    rationale: str | None = None


# --- Response models ---

class NegotiationIssueResponse(BaseModel):
    id: UUID
    name: str
    description: str | None = None
    value_type: str = "text"
    constraints: dict[str, Any] = Field(default_factory=dict)
    weight: float = 1.0


class NegotiationRoundResponse(BaseModel):
    id: UUID
    round_number: int
    agent_id: str
    action: RoundAction
    proposal: dict[str, Any] = Field(default_factory=dict)
    rationale: str | None = None
    mediator_analysis: str | None = None
    confidence: float = 0.5
    created_at: datetime


class NegotiationOutcomeResponse(BaseModel):
    id: UUID
    outcome_type: OutcomeType
    final_proposal: dict[str, Any] = Field(default_factory=dict)
    participating_agents: list[str] = Field(default_factory=list)
    dissenting_agents: list[str] = Field(default_factory=list)
    summary: str | None = None
    created_at: datetime


class NegotiationSessionResponse(BaseModel):
    id: UUID
    room_id: UUID
    title: str
    description: str | None = None
    status: SessionStatus
    strategy: NegotiationStrategy
    max_rounds: int
    created_by: str
    created_by_user_id: UUID | None = None
    created_at: datetime
    resolved_at: datetime | None = None
    issues: list[NegotiationIssueResponse] = Field(default_factory=list)
    rounds: list[NegotiationRoundResponse] = Field(default_factory=list)
    outcome: NegotiationOutcomeResponse | None = None
    round_count: int = 0
    participant_count: int = 0


class MediatorAnalysis(BaseModel):
    """Output of the LLM mediator's per-round analysis."""

    behavior_classifications: dict[str, AgentBehaviorType] = Field(default_factory=dict)
    convergence_score: float = 0.0
    suggested_strategies: dict[str, str] = Field(default_factory=dict)
    summary: str = ""
    should_conclude: bool = False
    recommended_outcome: OutcomeType | None = None


class ReviewerAnalysis(BaseModel):
    """Post-session analysis from the reviewer."""

    pareto_efficient: bool | None = None
    fairness_score: float = 0.5
    effective_strategies: list[str] = Field(default_factory=list)
    lessons_learned: str = ""
    improvement_suggestions: list[str] = Field(default_factory=list)
