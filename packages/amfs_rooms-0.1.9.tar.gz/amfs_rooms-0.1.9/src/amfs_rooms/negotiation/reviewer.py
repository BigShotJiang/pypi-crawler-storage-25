"""Post-session reviewer — evaluates negotiation outcomes and records lessons.

Maps to Section 4.4 of the NegMAS paper: the reviewer analyzes whether
outcomes are Pareto-efficient, fair, and what strategies worked.
"""

from __future__ import annotations

import json
import logging
import os
from typing import Any

from .models import ReviewerAnalysis

logger = logging.getLogger(__name__)

_REVIEWER_SYSTEM_PROMPT = """\
You are reviewing a completed negotiation session. Analyze the outcome quality.

Evaluate:
1. PARETO EFFICIENCY: Could any agent be made better off without making another worse off?
2. FAIRNESS: Did each agent get a reasonable outcome relative to their stated positions?
3. EFFECTIVE STRATEGIES: Which negotiation strategies were most effective?
4. LESSONS LEARNED: What should agents remember for future negotiations?
5. IMPROVEMENT SUGGESTIONS: How could the process be improved?

Respond with valid JSON:
{{
  "pareto_efficient": true/false/null,
  "fairness_score": 0.0-1.0,
  "effective_strategies": ["strategy_name", ...],
  "lessons_learned": "Summary of key takeaways",
  "improvement_suggestions": ["suggestion", ...]
}}
"""

_REVIEW_PROMPT = """\
Negotiation: "{title}"
Outcome: {outcome_type}
Total rounds: {total_rounds}

Issues:
{issues_text}

Final proposal:
{final_proposal}

Participating agents: {participants}
Dissenting agents: {dissenters}

Round-by-round summary:
{rounds_summary}

Please analyze this negotiation outcome.
"""


class NegotiationReviewer:
    """Analyzes completed negotiation sessions for quality and lessons."""

    def __init__(self, model: str | None = None):
        self.model = model or os.environ.get(
            "AMFS_MEDIATOR_MODEL", "openai/gpt-4o-mini"
        )

    async def review_session(
        self,
        title: str,
        outcome_type: str,
        total_rounds: int,
        issues: list[dict[str, Any]],
        final_proposal: dict[str, Any],
        participants: list[str],
        dissenters: list[str],
        rounds: list[dict[str, Any]],
    ) -> ReviewerAnalysis:
        try:
            return await self._llm_review(
                title, outcome_type, total_rounds, issues,
                final_proposal, participants, dissenters, rounds,
            )
        except Exception:
            logger.warning("LLM reviewer failed, using heuristic", exc_info=True)
            return self._heuristic_review(
                outcome_type, total_rounds, participants, dissenters,
            )

    async def _llm_review(
        self,
        title: str,
        outcome_type: str,
        total_rounds: int,
        issues: list[dict[str, Any]],
        final_proposal: dict[str, Any],
        participants: list[str],
        dissenters: list[str],
        rounds: list[dict[str, Any]],
    ) -> ReviewerAnalysis:
        import litellm

        issues_text = "\n".join(
            f"- {i.get('name')}: {i.get('description', 'N/A')}"
            for i in issues
        ) or "No issues."

        rounds_summary = "\n".join(
            f"  Round {r.get('round_number')}: {r.get('agent_id')} "
            f"[{r.get('action')}] {json.dumps(r.get('proposal', {}))}"
            for r in rounds[-20:]
        ) or "No rounds recorded."

        user_msg = _REVIEW_PROMPT.format(
            title=title,
            outcome_type=outcome_type,
            total_rounds=total_rounds,
            issues_text=issues_text,
            final_proposal=json.dumps(final_proposal),
            participants=", ".join(participants),
            dissenters=", ".join(dissenters) or "None",
            rounds_summary=rounds_summary,
        )

        resp = await litellm.acompletion(
            model=self.model,
            messages=[
                {"role": "system", "content": _REVIEWER_SYSTEM_PROMPT},
                {"role": "user", "content": user_msg},
            ],
            temperature=0.3,
            response_format={"type": "json_object"},
        )

        data = json.loads(resp.choices[0].message.content)
        return ReviewerAnalysis(
            pareto_efficient=data.get("pareto_efficient"),
            fairness_score=float(data.get("fairness_score", 0.5)),
            effective_strategies=data.get("effective_strategies", []),
            lessons_learned=data.get("lessons_learned", ""),
            improvement_suggestions=data.get("improvement_suggestions", []),
        )

    def _heuristic_review(
        self,
        outcome_type: str,
        total_rounds: int,
        participants: list[str],
        dissenters: list[str],
    ) -> ReviewerAnalysis:
        fairness = 1.0 - (len(dissenters) / max(len(participants), 1))
        return ReviewerAnalysis(
            pareto_efficient=None,
            fairness_score=fairness,
            effective_strategies=[],
            lessons_learned=(
                f"Negotiation concluded as '{outcome_type}' after {total_rounds} rounds. "
                f"{len(participants)} participated, {len(dissenters)} dissented."
            ),
            improvement_suggestions=[],
        )
