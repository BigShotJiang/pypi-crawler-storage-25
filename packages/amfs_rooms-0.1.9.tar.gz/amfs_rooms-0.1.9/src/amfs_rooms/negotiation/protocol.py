"""Alternating offers protocol implementation.

Manages who proposes next, tracks round state, and enforces
the session lifecycle (open -> in_progress -> consensus/failed).
"""

from __future__ import annotations

import logging
from typing import Any
from uuid import UUID

from psycopg.rows import dict_row

from .models import (
    OutcomeType,
    RoundAction,
    SessionStatus,
)

logger = logging.getLogger(__name__)


class AlternatingOffersProtocol:
    """Implements the alternating offers negotiation protocol."""

    def __init__(self, pool):
        self._pool = pool

    async def get_session(self, session_id: UUID) -> dict[str, Any] | None:
        with self._pool.connection() as conn:
            conn.row_factory = dict_row
            return conn.execute(
                "SELECT * FROM negotiation_sessions WHERE id = %s",
                (str(session_id),),
            ).fetchone()

    async def get_issues(self, session_id: UUID) -> list[dict[str, Any]]:
        with self._pool.connection() as conn:
            conn.row_factory = dict_row
            return list(conn.execute(
                "SELECT * FROM negotiation_issues WHERE session_id = %s ORDER BY created_at",
                (str(session_id),),
            ).fetchall())

    async def get_rounds(self, session_id: UUID) -> list[dict[str, Any]]:
        with self._pool.connection() as conn:
            conn.row_factory = dict_row
            return list(conn.execute(
                "SELECT * FROM negotiation_rounds WHERE session_id = %s "
                "ORDER BY round_number, created_at",
                (str(session_id),),
            ).fetchall())

    async def get_current_round_number(self, session_id: UUID) -> int:
        with self._pool.connection() as conn:
            row = conn.execute(
                "SELECT COALESCE(MAX(round_number), 0) AS max_round "
                "FROM negotiation_rounds WHERE session_id = %s",
                (str(session_id),),
            ).fetchone()
            return row[0] if row else 0

    async def get_participating_agents(self, session_id: UUID) -> list[str]:
        with self._pool.connection() as conn:
            rows = conn.execute(
                "SELECT DISTINCT agent_id FROM negotiation_rounds WHERE session_id = %s",
                (str(session_id),),
            ).fetchall()
            return [r[0] for r in rows]

    async def submit_action(
        self,
        session_id: UUID,
        agent_id: str,
        action: RoundAction,
        proposal: dict[str, Any],
        rationale: str | None,
        mediator_analysis: str | None,
        confidence: float,
    ) -> dict[str, Any]:
        """Record an agent's action for the current round."""
        round_number = await self.get_current_round_number(session_id)

        if action == RoundAction.PROPOSE:
            round_number += 1

        with self._pool.connection() as conn:
            conn.row_factory = dict_row
            row = conn.execute(
                """INSERT INTO negotiation_rounds
                   (session_id, round_number, agent_id, action, proposal,
                    rationale, mediator_analysis, confidence)
                   VALUES (%s, %s, %s, %s, %s::jsonb, %s, %s, %s)
                   ON CONFLICT (session_id, round_number, agent_id) DO UPDATE
                   SET action = EXCLUDED.action, proposal = EXCLUDED.proposal,
                       rationale = EXCLUDED.rationale,
                       mediator_analysis = EXCLUDED.mediator_analysis,
                       confidence = EXCLUDED.confidence
                   RETURNING *""",
                (
                    str(session_id), round_number, agent_id,
                    action.value,
                    __import__("json").dumps(proposal),
                    rationale, mediator_analysis, confidence,
                ),
            ).fetchone()
            conn.commit()
            return dict(row) if row else {}

    async def check_consensus(self, session_id: UUID) -> OutcomeType | None:
        """Check if the latest round has reached consensus."""
        round_number = await self.get_current_round_number(session_id)
        if round_number == 0:
            return None

        with self._pool.connection() as conn:
            conn.row_factory = dict_row
            round_actions = list(conn.execute(
                "SELECT agent_id, action FROM negotiation_rounds "
                "WHERE session_id = %s AND round_number = %s",
                (str(session_id), round_number),
            ).fetchall())

        if not round_actions:
            return None

        accept_count = sum(1 for r in round_actions if r["action"] == "accept")
        reject_count = sum(1 for r in round_actions if r["action"] == "reject")
        total = len(round_actions)

        if accept_count == total:
            return OutcomeType.CONSENSUS
        if accept_count > total / 2:
            return OutcomeType.MAJORITY

        session = await self.get_session(session_id)
        if session and round_number >= session.get("max_rounds", 10):
            return OutcomeType.TIMEOUT

        return None

    async def record_outcome(
        self,
        session_id: UUID,
        outcome_type: OutcomeType,
        final_proposal: dict[str, Any],
        participating_agents: list[str],
        dissenting_agents: list[str],
        summary: str | None,
    ) -> dict[str, Any]:
        """Record the negotiation outcome and update session status."""
        import json as _json

        status = (
            SessionStatus.CONSENSUS
            if outcome_type in (OutcomeType.CONSENSUS, OutcomeType.MAJORITY, OutcomeType.MEDIATOR_DECISION)
            else SessionStatus.FAILED
        )

        with self._pool.connection() as conn:
            conn.row_factory = dict_row
            outcome = conn.execute(
                """INSERT INTO negotiation_outcomes
                   (session_id, outcome_type, final_proposal,
                    participating_agents, dissenting_agents, summary)
                   VALUES (%s, %s, %s::jsonb, %s, %s, %s)
                   RETURNING *""",
                (
                    str(session_id), outcome_type.value,
                    _json.dumps(final_proposal),
                    participating_agents, dissenting_agents, summary,
                ),
            ).fetchone()
            conn.execute(
                "UPDATE negotiation_sessions SET status = %s, resolved_at = now() "
                "WHERE id = %s",
                (status.value, str(session_id)),
            )
            conn.commit()
            return dict(outcome) if outcome else {}

    async def update_session_status(
        self, session_id: UUID, status: SessionStatus
    ) -> None:
        with self._pool.connection() as conn:
            conn.execute(
                "UPDATE negotiation_sessions SET status = %s WHERE id = %s",
                (status.value, str(session_id)),
            )
            conn.commit()
