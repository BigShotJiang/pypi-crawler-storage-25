"""NegMAS-inspired strategy pool.

Instead of DRL-trained strategies, we define concession patterns as templates
that the LLM mediator can suggest to agents. These are descriptive, not
prescriptive — the agents ultimately decide their own actions.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class ConcessionStrategy:
    name: str
    description: str
    recommended_for: str
    concession_pattern: str


STRATEGY_POOL: list[ConcessionStrategy] = [
    ConcessionStrategy(
        name="time_dependent_conceder",
        description="Gradually increase concessions as rounds progress, front-loading flexibility",
        recommended_for="When opponent is classified as Boulware (hard conceder)",
        concession_pattern="concession_rate = (round / max_rounds) ^ 0.3",
    ),
    ConcessionStrategy(
        name="time_dependent_boulware",
        description="Hold firm in early rounds, only concede significantly near the deadline",
        recommended_for="When opponent concedes too quickly or when you have a strong position",
        concession_pattern="concession_rate = (round / max_rounds) ^ 3.0",
    ),
    ConcessionStrategy(
        name="tit_for_tat",
        description="Mirror the opponent's last concession level — reciprocal strategy",
        recommended_for="When opponent is classified as Linear",
        concession_pattern="concession_rate = opponent_last_concession",
    ),
    ConcessionStrategy(
        name="nice_tit_for_tat",
        description="Like tit-for-tat but slightly more generous — concede a bit more than opponent did",
        recommended_for="Breaking deadlocks or building goodwill",
        concession_pattern="concession_rate = opponent_last_concession * 1.2",
    ),
    ConcessionStrategy(
        name="random_walk",
        description="Introduce controlled randomness to proposals to break patterns",
        recommended_for="When negotiations are stuck in a local optimum",
        concession_pattern="concession_rate = base_rate + random(-0.1, 0.1)",
    ),
    ConcessionStrategy(
        name="issue_trade",
        description="Concede on low-priority issues in exchange for gains on high-priority ones",
        recommended_for="Multi-issue negotiations where agents value issues differently",
        concession_pattern="concede_low_weight_issues, hold_firm_on_high_weight",
    ),
]


def get_strategy(name: str) -> ConcessionStrategy | None:
    for s in STRATEGY_POOL:
        if s.name == name:
            return s
    return None


def get_strategy_prompt_context() -> str:
    """Generate a strategy reference for the LLM mediator prompt."""
    lines = ["Available negotiation strategies:"]
    for s in STRATEGY_POOL:
        lines.append(f"\n- **{s.name}**: {s.description}")
        lines.append(f"  Recommended for: {s.recommended_for}")
    return "\n".join(lines)
