"""LLM Mediator — replaces the DRL classifier + strategy switcher from NegMAS.

The mediator performs three tasks after each negotiation round:
1. Classify each agent's behavior type (Boulware, Conceder, Linear, Unpredictable)
2. Suggest strategy adjustments based on classifications
3. Assess convergence and recommend whether to conclude
"""

from __future__ import annotations

import json
import logging
import os
from typing import Any

from .models import (
    AgentBehaviorType,
    MediatorAnalysis,
    OutcomeType,
)
from .strategies import get_strategy_prompt_context

logger = logging.getLogger(__name__)


_MEDIATOR_SYSTEM_PROMPT = """\
You are a negotiation mediator for a multi-agent collaboration room.
Your role is to analyze negotiation rounds and help agents reach consensus.

{strategy_context}

Your analysis should include:
1. BEHAVIOR CLASSIFICATION: For each agent, classify their behavior type:
   - boulware: Holds firm, concedes only near deadline
   - conceder: Makes significant early concessions
   - linear: Steady, predictable concession rate
   - unpredictable: No clear pattern

2. CONVERGENCE SCORE: 0.0 (no agreement possible) to 1.0 (near consensus)

3. STRATEGY SUGGESTIONS: For each agent, suggest which strategy might help.

4. CONCLUSION RECOMMENDATION: Should the negotiation conclude this round?

Respond ONLY with valid JSON matching this schema:
{{
  "behavior_classifications": {{"agent_id": "boulware|conceder|linear|unpredictable"}},
  "convergence_score": 0.0-1.0,
  "suggested_strategies": {{"agent_id": "strategy_name"}},
  "summary": "Brief analysis",
  "should_conclude": true/false,
  "recommended_outcome": null | "consensus" | "majority" | "mediator_decision" | "timeout" | "failed"
}}
"""

_ROUND_ANALYSIS_PROMPT = """\
Negotiation: "{title}"
Description: {description}

Issues under negotiation:
{issues_text}

Round history (most recent last):
{rounds_text}

Current round ({round_number}/{max_rounds}):
{current_round_text}

Analyze this round and provide your mediator analysis.
"""


class LLMMediator:
    """LLM-powered negotiation mediator.

    Uses litellm for provider-agnostic LLM calls. Falls back to a
    heuristic analysis if no LLM is configured.
    """

    def __init__(self, model: str | None = None):
        self.model = model or os.environ.get(
            "AMFS_MEDIATOR_MODEL", "openai/gpt-4o-mini"
        )

    async def analyze_round(
        self,
        title: str,
        description: str | None,
        issues: list[dict[str, Any]],
        rounds: list[dict[str, Any]],
        current_round: list[dict[str, Any]],
        round_number: int,
        max_rounds: int,
    ) -> MediatorAnalysis:
        """Analyze a negotiation round and return mediator guidance."""
        try:
            return await self._llm_analyze(
                title, description, issues, rounds,
                current_round, round_number, max_rounds,
            )
        except Exception:
            logger.warning("LLM mediator failed, using heuristic", exc_info=True)
            return self._heuristic_analyze(
                rounds, current_round, round_number, max_rounds,
            )

    async def _llm_analyze(
        self,
        title: str,
        description: str | None,
        issues: list[dict[str, Any]],
        rounds: list[dict[str, Any]],
        current_round: list[dict[str, Any]],
        round_number: int,
        max_rounds: int,
    ) -> MediatorAnalysis:
        import litellm

        issues_text = "\n".join(
            f"- {i.get('name', '?')}: {i.get('description', 'N/A')} "
            f"(type: {i.get('value_type', 'text')}, weight: {i.get('weight', 1.0)})"
            for i in issues
        ) or "No issues decomposed yet."

        rounds_text = "\n".join(
            f"  Round {r.get('round_number')}: {r.get('agent_id')} "
            f"[{r.get('action')}] — {json.dumps(r.get('proposal', {}))}"
            f"{(' — ' + r.get('rationale', '')) if r.get('rationale') else ''}"
            for r in rounds[-10:]
        ) or "No prior rounds."

        current_round_text = "\n".join(
            f"  {r.get('agent_id')} [{r.get('action')}]: "
            f"{json.dumps(r.get('proposal', {}))}"
            f"{(' — ' + r.get('rationale', '')) if r.get('rationale') else ''}"
            for r in current_round
        )

        user_msg = _ROUND_ANALYSIS_PROMPT.format(
            title=title,
            description=description or "N/A",
            issues_text=issues_text,
            rounds_text=rounds_text,
            round_number=round_number,
            max_rounds=max_rounds,
            current_round_text=current_round_text,
        )

        resp = await litellm.acompletion(
            model=self.model,
            messages=[
                {
                    "role": "system",
                    "content": _MEDIATOR_SYSTEM_PROMPT.format(
                        strategy_context=get_strategy_prompt_context()
                    ),
                },
                {"role": "user", "content": user_msg},
            ],
            temperature=0.3,
            response_format={"type": "json_object"},
        )

        raw = resp.choices[0].message.content
        data = json.loads(raw)

        classifications = {}
        for agent_id, btype in data.get("behavior_classifications", {}).items():
            try:
                classifications[agent_id] = AgentBehaviorType(btype)
            except ValueError:
                classifications[agent_id] = AgentBehaviorType.UNPREDICTABLE

        rec_outcome = None
        if data.get("recommended_outcome"):
            try:
                rec_outcome = OutcomeType(data["recommended_outcome"])
            except ValueError:
                pass

        return MediatorAnalysis(
            behavior_classifications=classifications,
            convergence_score=float(data.get("convergence_score", 0.0)),
            suggested_strategies=data.get("suggested_strategies", {}),
            summary=data.get("summary", ""),
            should_conclude=bool(data.get("should_conclude", False)),
            recommended_outcome=rec_outcome,
        )

    def _heuristic_analyze(
        self,
        rounds: list[dict[str, Any]],
        current_round: list[dict[str, Any]],
        round_number: int,
        max_rounds: int,
    ) -> MediatorAnalysis:
        """Simple heuristic when no LLM is available."""
        accept_count = sum(1 for r in current_round if r.get("action") == "accept")
        total = len(current_round) or 1
        convergence = accept_count / total

        should_conclude = (
            convergence >= 0.8
            or round_number >= max_rounds
        )

        rec_outcome = None
        if convergence >= 0.8:
            rec_outcome = OutcomeType.CONSENSUS
        elif round_number >= max_rounds:
            rec_outcome = OutcomeType.TIMEOUT

        return MediatorAnalysis(
            behavior_classifications={},
            convergence_score=convergence,
            suggested_strategies={},
            summary=f"Round {round_number}: {accept_count}/{total} agents accepted.",
            should_conclude=should_conclude,
            recommended_outcome=rec_outcome,
        )
