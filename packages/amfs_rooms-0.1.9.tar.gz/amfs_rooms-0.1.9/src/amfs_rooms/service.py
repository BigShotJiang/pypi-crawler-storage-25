"""Room service — core business logic for entity rooms."""

from __future__ import annotations

import contextlib
import logging
from datetime import datetime, timezone
from typing import Any
from uuid import UUID

import psycopg
from psycopg.rows import dict_row

logger = logging.getLogger(__name__)


class RoomService:
    """Handles room lifecycle: create, invite, join, close, clone."""

    def __init__(self, pool: Any, get_memory: Any = None) -> None:
        self._pool = pool
        self._get_memory = get_memory

    @contextlib.contextmanager
    def _tenant_conn(self, account_id: UUID):
        """Check out a connection with an explicit transaction and RLS GUC.

        The pool uses autocommit=True, and the pool wrapper reads the
        tenant from thread-local storage — which is empty when the caller
        is a sync route handler running in a worker thread.  Wrapping in
        an explicit transaction with set_config(..., true) guarantees the
        GUC is visible for every statement inside the block.
        """
        with self._pool.connection() as conn:
            conn.row_factory = dict_row
            with conn.transaction():
                conn.execute(
                    "SELECT set_config('amfs.current_account_id', %s, true)",
                    (str(account_id),),
                )
                yield conn

    # ── Room CRUD ─────────────────────────────────────────────────────

    def create_room(
        self,
        *,
        account_id: UUID,
        entity_path: str,
        namespace: str = "default",
        display_name: str | None = None,
        description: str | None = None,
        discussions_enabled: bool = False,
        settings: dict | None = None,
        created_by: UUID,
        creator_agent_id: str | None = None,
    ) -> dict:
        with self._tenant_conn(account_id) as conn:
            try:
                with conn.transaction():
                    row = conn.execute(
                        """
                        INSERT INTO entity_rooms
                            (account_id, entity_path, namespace, display_name, description,
                             discussions_enabled, settings, created_by)
                        VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
                        RETURNING *
                        """,
                        (
                            str(account_id), entity_path, namespace, display_name,
                            description, discussions_enabled,
                            psycopg.types.json.Json(settings or {}),
                            str(created_by),
                        ),
                    ).fetchone()
            except psycopg.errors.UniqueViolation:
                existing = conn.execute(
                    "SELECT * FROM entity_rooms WHERE account_id = %s AND namespace = %s AND entity_path = %s",
                    (str(account_id), namespace, entity_path),
                ).fetchone()
                if existing is not None:
                    return _row_to_dict(existing, conn)
                raise

            room = _row_to_dict(row, conn)
            room_id = str(room["id"])

            # Auto-add creator as an accepted user invite
            invite_row = conn.execute(
                """
                INSERT INTO room_user_invites
                    (room_id, account_id, invited_user_id, invited_by,
                     role, status, accepted_at)
                VALUES (%s, %s, %s, %s, 'collaborator', 'accepted', now())
                RETURNING id
                """,
                (room_id, str(account_id), str(created_by), str(created_by)),
            ).fetchone()
            invite_id = _first_val(invite_row)

            # Auto-join creator's agent if provided
            if creator_agent_id:
                conn.execute(
                    """
                    INSERT INTO room_memberships
                        (room_id, invite_id, agent_id, owner_user_id, role)
                    VALUES (%s, %s, %s, %s, 'member')
                    ON CONFLICT (room_id, agent_id) DO UPDATE
                        SET left_at = NULL, role = EXCLUDED.role
                    """,
                    (room_id, str(invite_id), creator_agent_id, str(created_by)),
                )
                conn.execute(
                    """
                    INSERT INTO room_activity
                        (room_id, account_id, agent_id, user_id,
                         activity_type, details)
                    VALUES (%s, %s, %s, %s, 'agent_joined', %s)
                    """,
                    (
                        room_id, str(account_id), creator_agent_id,
                        str(created_by),
                        psycopg.types.json.Json({"role": "member"}),
                    ),
                )

            # Auto-join all of the creator's agents that have written to this entity
            if invite_id:
                self._auto_join_entity_agents(
                    conn,
                    room_id=room_id,
                    account_id=account_id,
                    entity_path=entity_path,
                    namespace=namespace,
                    owner_user_id=created_by,
                    invite_id=invite_id,
                    skip_agent_id=creator_agent_id,
                )

            # Backfill existing entity memory entries as room activity
            self._backfill_entity_history(
                conn, room_id, account_id, entity_path, namespace,
            )

            conn.execute(
                """
                INSERT INTO room_activity
                    (room_id, account_id, user_id, activity_type, details)
                VALUES (%s, %s, %s, 'room_created', %s)
                """,
                (
                    room_id, str(account_id), str(created_by),
                    psycopg.types.json.Json({"entity_path": entity_path}),
                ),
            )
            return room

    def get_room(self, room_id: UUID, account_id: UUID) -> dict | None:
        with self._tenant_conn(account_id) as conn:
            row = conn.execute(
                "SELECT * FROM entity_rooms WHERE id = %s", (str(room_id),)
            ).fetchone()
            if row is None:
                return None
            room = _row_to_dict(row, conn)
            room["agent_count"] = self._count_active_agents(conn, room_id)
            room["user_count"] = self._count_invited_users(conn, room_id)
            return room

    def get_room_by_entity(
        self, entity_path: str, account_id: UUID, namespace: str = "default"
    ) -> dict | None:
        with self._tenant_conn(account_id) as conn:
            row = conn.execute(
                """SELECT * FROM entity_rooms
                   WHERE entity_path = %s AND namespace = %s""",
                (entity_path, namespace),
            ).fetchone()
            return _row_to_dict(row, conn) if row else None

    def list_rooms(
        self, account_id: UUID, user_id: UUID | None = None
    ) -> list[dict]:
        with self._tenant_conn(account_id) as conn:
            if user_id:
                rows = conn.execute(
                    """
                    SELECT DISTINCT er.*, 
                        CASE 
                            WHEN er.created_by = %s THEN 'owner'
                            ELSE rui.role
                        END AS your_role,
                        (SELECT MAX(ra.created_at) FROM room_activity ra 
                         WHERE ra.room_id = er.id) AS last_activity_at
                    FROM entity_rooms er
                    LEFT JOIN room_user_invites rui 
                        ON rui.room_id = er.id 
                        AND rui.invited_user_id = %s 
                        AND rui.status = 'accepted'
                    WHERE er.created_by = %s 
                       OR rui.id IS NOT NULL
                    ORDER BY er.created_at DESC
                    """,
                    (str(user_id), str(user_id), str(user_id)),
                ).fetchall()
            else:
                rows = conn.execute(
                    "SELECT * FROM entity_rooms ORDER BY created_at DESC"
                ).fetchall()

            result = []
            for row in rows:
                room = _row_to_dict(row, conn)
                room["agent_count"] = self._count_active_agents(conn, room["id"])
                room["user_count"] = self._count_invited_users(conn, room["id"])
                result.append(room)
            return result

    def update_room(
        self, room_id: UUID, account_id: UUID, **updates: Any
    ) -> dict | None:
        allowed = {"display_name", "description", "discussions_enabled", "settings"}
        filtered = {k: v for k, v in updates.items() if k in allowed and v is not None}
        if not filtered:
            return self.get_room(room_id, account_id)

        set_clauses = []
        params: list[Any] = []
        for key, val in filtered.items():
            if key == "settings":
                set_clauses.append(f"{key} = %s")
                params.append(psycopg.types.json.Json(val))
            else:
                set_clauses.append(f"{key} = %s")
                params.append(val)

        params.append(str(room_id))

        with self._tenant_conn(account_id) as conn:
            row = conn.execute(
                f"UPDATE entity_rooms SET {', '.join(set_clauses)} WHERE id = %s RETURNING *",
                params,
            ).fetchone()
            return _row_to_dict(row, conn) if row else None

    def close_room(
        self, room_id: UUID, account_id: UUID, closed_by: UUID
    ) -> dict | None:
        """Close and delete a room.

        INVARIANT: Entity memory data (amfs_memory_entries) is NEVER deleted
        or modified. Only the room metadata and its child tables are removed.
        The entity and its full history survive independently of the room.

        Before deletion:
        1. Knowledge snapshots are created for each member agent
        2. Room activity (reads, writes, joins) is persisted to amfs_events
        """
        with self._tenant_conn(account_id) as conn:
            row = conn.execute(
                "SELECT * FROM entity_rooms WHERE id = %s AND status = 'open'",
                (str(room_id),),
            ).fetchone()
            if row is None:
                return None

            room = _row_to_dict(row, conn)
            entity_path = room["entity_path"]
            namespace = room.get("namespace", "default")

            # 1. Create knowledge snapshots for member agents
            if self._get_memory:
                try:
                    from .knowledge_sync import KnowledgeSyncWorker
                    ks = KnowledgeSyncWorker(
                        pool=self._pool, get_memory=self._get_memory,
                    )
                    ks.create_close_snapshots(
                        room_id=room_id,
                        entity_path=entity_path,
                        account_id=account_id,
                    )
                except Exception:
                    logger.warning(
                        "Failed to create close snapshots for room %s",
                        room_id, exc_info=True,
                    )

            # 2. Persist room activity into amfs_events before cascade delete
            self._migrate_activity_to_events(
                conn, room_id, account_id, entity_path, namespace,
            )

            # 3. Delete the room — cascades to invites, memberships,
            #    activity, discussions, negotiations, concepts, snapshots
            conn.execute(
                "DELETE FROM entity_rooms WHERE id = %s",
                (str(room_id),),
            )

            return room

    def delete_room(
        self, room_id: UUID, account_id: UUID, deleted_by: UUID
    ) -> dict | None:
        """Delete a room regardless of status.

        Same invariant as close_room: entity memory data is NEVER touched.
        Only the room metadata and child tables are removed via CASCADE.
        """
        with self._tenant_conn(account_id) as conn:
            row = conn.execute(
                "SELECT * FROM entity_rooms WHERE id = %s",
                (str(room_id),),
            ).fetchone()
            if row is None:
                return None

            room = _row_to_dict(row, conn)
            if UUID(str(room["created_by"])) != deleted_by:
                return None

            entity_path = room["entity_path"]
            namespace = room.get("namespace", "default")

            self._migrate_activity_to_events(
                conn, room_id, account_id, entity_path, namespace,
            )

            conn.execute(
                "DELETE FROM entity_rooms WHERE id = %s",
                (str(room_id),),
            )
            return room

    # ── Invitations ───────────────────────────────────────────────────

    def invite_user(
        self,
        *,
        room_id: UUID,
        account_id: UUID,
        invited_user_id: UUID,
        invited_by: UUID,
        role: str = "collaborator",
    ) -> dict:
        with self._tenant_conn(account_id) as conn:
            row = conn.execute(
                """
                INSERT INTO room_user_invites
                    (room_id, account_id, invited_user_id, invited_by, role)
                VALUES (%s, %s, %s, %s, %s)
                ON CONFLICT (room_id, invited_user_id) DO UPDATE
                    SET role = EXCLUDED.role,
                        status = 'pending',
                        invited_by = EXCLUDED.invited_by
                RETURNING *
                """,
                (str(room_id), str(account_id), str(invited_user_id),
                 str(invited_by), role),
            ).fetchone()
            invite = _row_to_dict(row, conn)

            conn.execute(
                """
                INSERT INTO room_activity
                    (room_id, account_id, user_id, activity_type, details)
                VALUES (%s, %s, %s, 'user_invited', %s)
                """,
                (
                    str(room_id), str(account_id), str(invited_by),
                    psycopg.types.json.Json({
                        "invited_user_id": str(invited_user_id),
                        "role": role,
                    }),
                ),
            )
            return invite

    def accept_invite(
        self, invite_id: UUID, account_id: UUID, user_id: UUID
    ) -> dict | None:
        with self._tenant_conn(account_id) as conn:
            row = conn.execute(
                """
                UPDATE room_user_invites
                SET status = 'accepted', accepted_at = now()
                WHERE id = %s AND invited_user_id = %s AND status = 'pending'
                RETURNING *
                """,
                (str(invite_id), str(user_id)),
            ).fetchone()
            if row is None:
                return None
            invite = _row_to_dict(row, conn)

            conn.execute(
                """
                INSERT INTO room_activity
                    (room_id, account_id, user_id, activity_type, details)
                VALUES (%s, %s, %s, 'user_accepted', '{}')
                """,
                (str(invite["room_id"]), str(account_id), str(user_id)),
            )
            return invite

    def decline_invite(
        self, invite_id: UUID, account_id: UUID, user_id: UUID
    ) -> dict | None:
        with self._tenant_conn(account_id) as conn:
            row = conn.execute(
                """
                UPDATE room_user_invites
                SET status = 'declined'
                WHERE id = %s AND invited_user_id = %s AND status = 'pending'
                RETURNING *
                """,
                (str(invite_id), str(user_id)),
            ).fetchone()
            return _row_to_dict(row, conn) if row else None

    def revoke_invite(
        self, invite_id: UUID, account_id: UUID
    ) -> dict | None:
        with self._tenant_conn(account_id) as conn:
            row = conn.execute(
                """
                UPDATE room_user_invites SET status = 'revoked'
                WHERE id = %s AND status IN ('pending', 'accepted')
                RETURNING *
                """,
                (str(invite_id),),
            ).fetchone()
            return _row_to_dict(row, conn) if row else None

    def list_invites(self, room_id: UUID, account_id: UUID) -> list[dict]:
        with self._tenant_conn(account_id) as conn:
            rows = conn.execute(
                """
                SELECT rui.*, u.name AS user_name, u.email AS user_email
                FROM room_user_invites rui
                JOIN users u ON u.id = rui.invited_user_id
                WHERE rui.room_id = %s AND u.deleted_at IS NULL
                ORDER BY rui.created_at DESC
                """,
                (str(room_id),),
            ).fetchall()
            return [_row_to_dict(r, conn) for r in rows]

    def list_pending_invites_for_user(
        self, account_id: UUID, user_id: UUID
    ) -> list[dict]:
        """Return rooms where the user has a pending invite."""
        with self._tenant_conn(account_id) as conn:
            rows = conn.execute(
                """
                SELECT rui.id AS invite_id, rui.role, rui.created_at AS invited_at,
                       er.id AS room_id, er.entity_path, er.display_name,
                       er.status AS room_status, er.discussions_enabled,
                       inviter.name AS invited_by_name, inviter.email AS invited_by_email
                FROM room_user_invites rui
                JOIN entity_rooms er ON er.id = rui.room_id
                JOIN users inviter ON inviter.id = rui.invited_by
                WHERE rui.invited_user_id = %s
                  AND rui.status = 'pending'
                  AND er.status = 'open'
                ORDER BY rui.created_at DESC
                """,
                (str(user_id),),
            ).fetchall()
            return [_row_to_dict(r, conn) for r in rows]

    # ── Agent Membership ──────────────────────────────────────────────

    def agent_join(
        self,
        *,
        room_id: UUID,
        account_id: UUID,
        agent_id: str,
        owner_user_id: UUID,
    ) -> dict | None:
        with self._tenant_conn(account_id) as conn:
            invite = conn.execute(
                """
                SELECT id, role FROM room_user_invites
                WHERE room_id = %s AND invited_user_id = %s AND status = 'accepted'
                """,
                (str(room_id), str(owner_user_id)),
            ).fetchone()

            room = conn.execute(
                "SELECT created_by FROM entity_rooms WHERE id = %s",
                (str(room_id),),
            ).fetchone()

            if invite is None and (room is None or str(room["created_by"]) != str(owner_user_id)):
                return None

            invite_id = invite["id"] if invite else None
            role = invite["role"] if invite else "member"

            if invite_id is None:
                invite_row = conn.execute(
                    """
                    INSERT INTO room_user_invites
                        (room_id, account_id, invited_user_id, invited_by, role, status, accepted_at)
                    VALUES (%s, %s, %s, %s, 'collaborator', 'accepted', now())
                    RETURNING id
                    """,
                    (str(room_id), str(account_id), str(owner_user_id), str(owner_user_id)),
                ).fetchone()
                invite_id = _first_val(invite_row)
                role = "member"

            row = conn.execute(
                """
                INSERT INTO room_memberships
                    (room_id, invite_id, agent_id, owner_user_id, role)
                VALUES (%s, %s, %s, %s, %s)
                ON CONFLICT (room_id, agent_id) DO UPDATE
                    SET left_at = NULL, role = EXCLUDED.role
                RETURNING *
                """,
                (str(room_id), str(invite_id), agent_id, str(owner_user_id), role),
            ).fetchone()
            membership = _row_to_dict(row, conn)

            conn.execute(
                """
                INSERT INTO room_activity
                    (room_id, account_id, agent_id, user_id, activity_type, details)
                VALUES (%s, %s, %s, %s, 'agent_joined', %s)
                """,
                (
                    str(room_id), str(account_id), agent_id, str(owner_user_id),
                    psycopg.types.json.Json({"role": role}),
                ),
            )
            return membership

    def agent_leave(
        self, room_id: UUID, account_id: UUID, agent_id: str
    ) -> bool:
        with self._tenant_conn(account_id) as conn:
            result = conn.execute(
                """
                UPDATE room_memberships SET left_at = now()
                WHERE room_id = %s AND agent_id = %s AND left_at IS NULL
                """,
                (str(room_id), agent_id),
            )
            if result.rowcount == 0:
                return False

            conn.execute(
                """
                INSERT INTO room_activity
                    (room_id, account_id, agent_id, activity_type, details)
                VALUES (%s, %s, %s, 'agent_left', '{}')
                """,
                (str(room_id), str(account_id), agent_id),
            )
            return True

    def list_members(self, room_id: UUID, account_id: UUID) -> list[dict]:
        with self._tenant_conn(account_id) as conn:
            rows = conn.execute(
                """
                SELECT rm.*, u.name AS owner_user_name, u.email AS owner_user_email
                FROM room_memberships rm
                JOIN users u ON u.id = rm.owner_user_id
                WHERE rm.room_id = %s AND rm.left_at IS NULL
                ORDER BY rm.joined_at ASC
                """,
                (str(room_id),),
            ).fetchall()
            return [_row_to_dict(r, conn) for r in rows]

    # ── Activity ──────────────────────────────────────────────────────

    def list_activity(
        self,
        room_id: UUID,
        account_id: UUID,
        *,
        limit: int = 50,
        offset: int = 0,
        activity_type: str | None = None,
        since: datetime | None = None,
    ) -> tuple[list[dict], int]:
        with self._tenant_conn(account_id) as conn:
            conditions = ["room_id = %s"]
            params: list[Any] = [str(room_id)]

            if activity_type:
                conditions.append("activity_type = %s")
                params.append(activity_type)
            if since:
                conditions.append("created_at > %s")
                params.append(since)

            where = " AND ".join(conditions)

            total_row = conn.execute(
                f"SELECT COUNT(*) FROM room_activity WHERE {where}", params
            ).fetchone()
            total = _first_val(total_row) or 0

            params.extend([limit, offset])
            rows = conn.execute(
                f"""
                SELECT * FROM room_activity
                WHERE {where}
                ORDER BY created_at DESC
                LIMIT %s OFFSET %s
                """,
                params,
            ).fetchall()
            return [_row_to_dict(r, conn) for r in rows], total

    def log_activity(
        self,
        *,
        room_id: UUID,
        account_id: UUID,
        activity_type: str,
        agent_id: str | None = None,
        user_id: UUID | None = None,
        details: dict | None = None,
        conn: Any = None,
    ) -> None:
        """Log a room activity event. If conn is provided, use it directly."""
        def _do(c: Any) -> None:
            c.execute(
                """
                INSERT INTO room_activity
                    (room_id, account_id, agent_id, user_id, activity_type, details)
                VALUES (%s, %s, %s, %s, %s, %s)
                """,
                (
                    str(room_id), str(account_id), agent_id,
                    str(user_id) if user_id else None,
                    activity_type,
                    psycopg.types.json.Json(details or {}),
                ),
            )

        if conn is not None:
            _do(conn)
        else:
            with self._tenant_conn(account_id) as c:
                _do(c)

    # ── Entity history helpers ────────────────────────────────────────

    def _auto_join_entity_agents(
        self,
        conn: Any,
        *,
        room_id: str,
        account_id: UUID,
        entity_path: str,
        namespace: str,
        owner_user_id: UUID,
        invite_id: Any,
        skip_agent_id: str | None = None,
    ) -> None:
        """Auto-join agents that have written to this entity.

        Uses LEFT JOIN against the internal agents table so agents that
        are only registered in the OSS amfs_agents table (the common
        case for MCP/HTTP writes) are still included.  If the agent IS
        in the internal table but owned by a different user, it is
        excluded.
        """
        try:
            rows = conn.execute(
                """
                SELECT DISTINCT me.agent_id
                FROM amfs_memory_entries me
                LEFT JOIN agents a
                    ON a.agent_id = me.agent_id
                    AND a.account_id = %s
                    AND a.namespace = me.namespace
                WHERE me.entity_path = %s
                  AND me.namespace = %s
                  AND me.superseded_at IS NULL
                  AND (a.owner_user_id = %s OR a.id IS NULL)
                """,
                (str(account_id), entity_path, namespace, str(owner_user_id)),
            ).fetchall()
        except Exception:
            logger.warning(
                "Could not query entity agents for auto-join on %s",
                entity_path, exc_info=True,
            )
            return

        for row in rows:
            agent_id = row["agent_id"] if isinstance(row, dict) else row[0]
            if agent_id == skip_agent_id:
                continue
            try:
                conn.execute(
                    """
                    INSERT INTO room_memberships
                        (room_id, invite_id, agent_id, owner_user_id, role)
                    VALUES (%s, %s, %s, %s, 'member')
                    ON CONFLICT (room_id, agent_id) DO NOTHING
                    """,
                    (room_id, str(invite_id), agent_id, str(owner_user_id)),
                )
                conn.execute(
                    """
                    INSERT INTO room_activity
                        (room_id, account_id, agent_id, user_id,
                         activity_type, details)
                    VALUES (%s, %s, %s, %s, 'agent_joined', %s)
                    """,
                    (
                        room_id, str(account_id), agent_id, str(owner_user_id),
                        psycopg.types.json.Json({"auto_joined": True, "role": "member"}),
                    ),
                )
                logger.info("Auto-joined agent %s to room %s", agent_id, room_id)
            except Exception:
                logger.warning(
                    "Failed to auto-join agent %s to room %s",
                    agent_id, room_id, exc_info=True,
                )

    def _backfill_entity_history(
        self,
        conn: Any,
        room_id: str,
        account_id: UUID,
        entity_path: str,
        namespace: str,
    ) -> int:
        """Copy existing entity entries into room_activity as backfilled writes."""
        try:
            rows = conn.execute(
                """
                SELECT key, agent_id, written_at
                FROM amfs_memory_entries
                WHERE entity_path = %s AND namespace = %s
                  AND superseded_at IS NULL
                ORDER BY written_at ASC
                """,
                (entity_path, namespace),
            ).fetchall()
        except Exception:
            logger.debug(
                "Could not backfill entity history for %s", entity_path,
                exc_info=True,
            )
            return 0

        for row in rows:
            conn.execute(
                """
                INSERT INTO room_activity
                    (room_id, account_id, agent_id, activity_type,
                     details, created_at)
                VALUES (%s, %s, %s, 'write', %s, %s)
                """,
                (
                    room_id, str(account_id), row["agent_id"],
                    psycopg.types.json.Json({
                        "key": row["key"],
                        "entity_path": entity_path,
                        "backfilled": True,
                    }),
                    row["written_at"],
                ),
            )
        return len(rows)

    _EVENT_TYPE_MAP = {
        "write": "write",
        "read": "read",
    }

    def _migrate_activity_to_events(
        self,
        conn: Any,
        room_id: UUID,
        account_id: UUID,
        entity_path: str,
        namespace: str,
    ) -> int:
        """Copy room_activity rows into amfs_events before room deletion.

        Maps room activity types to valid amfs_events event_type values.
        Types not in the event_type CHECK constraint are stored as 'write'
        with the original type preserved in details.room_event_type.
        """
        rows = conn.execute(
            """
            SELECT agent_id, activity_type, details, created_at
            FROM room_activity
            WHERE room_id = %s
            ORDER BY created_at ASC
            """,
            (str(room_id),),
        ).fetchall()

        migrated = 0
        for row in rows:
            agent_id = row["agent_id"] or "system"
            activity_type = row["activity_type"]
            details = row["details"] if isinstance(row["details"], dict) else {}
            created_at = row["created_at"]

            event_type = self._EVENT_TYPE_MAP.get(activity_type, "write")
            event_details = {
                **details,
                "entity_path": entity_path,
                "room_id": str(room_id),
                "from_room": True,
            }
            if activity_type != event_type:
                event_details["room_event_type"] = activity_type

            try:
                conn.execute(
                    """
                    INSERT INTO amfs_events
                        (namespace, agent_id, branch, event_type,
                         summary, details, created_at, account_id)
                    VALUES (%s, %s, 'main', %s, %s, %s::jsonb, %s, %s)
                    """,
                    (
                        namespace, agent_id, event_type,
                        f"Room: {activity_type}",
                        psycopg.types.json.Json(event_details),
                        created_at, str(account_id),
                    ),
                )
                migrated += 1
            except Exception:
                logger.debug(
                    "Failed to migrate activity row to events",
                    exc_info=True,
                )

        return migrated

    # ── Helpers ───────────────────────────────────────────────────────

    def _count_active_agents(self, conn: Any, room_id: UUID) -> int:
        row = conn.execute(
            """SELECT COUNT(DISTINCT agent_id) FROM (
                SELECT agent_id FROM room_memberships
                WHERE room_id = %s AND left_at IS NULL
                UNION
                SELECT DISTINCT me.agent_id FROM amfs_memory_entries me
                JOIN entity_rooms er ON er.entity_path = me.entity_path
                LEFT JOIN agents a ON a.agent_id = me.agent_id
                    AND a.account_id = me.account_id
                WHERE er.id = %s
                  AND me.agent_id != 'amfs-server'
                  AND (a.id IS NOT NULL OR me.agent_id LIKE 'agent/%%')
            ) combined""",
            (str(room_id), str(room_id)),
        ).fetchone()
        return _first_val(row) or 0

    def _count_invited_users(self, conn: Any, room_id: UUID) -> int:
        row = conn.execute(
            """SELECT COUNT(DISTINCT invited_user_id) FROM room_user_invites
               WHERE room_id = %s AND status IN ('pending', 'accepted')""",
            (str(room_id),),
        ).fetchone()
        return _first_val(row) or 0


def _first_val(row: Any) -> Any:
    """Extract the single column value from a scalar query result row."""
    if row is None:
        return None
    if isinstance(row, dict):
        return next(iter(row.values()))
    return row[0]


def _row_to_dict(row: Any, conn: Any) -> dict:
    """Convert a psycopg row to a dict using cursor description."""
    if row is None:
        return {}
    if hasattr(row, "_asdict"):
        return row._asdict()
    if hasattr(row, "keys"):
        return dict(row)
    cols = [desc.name for desc in conn.description] if conn.description else []
    return dict(zip(cols, row))
