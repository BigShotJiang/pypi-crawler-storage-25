"""Knowledge sync — propagate room writes to each member agent's own memory.

When an agent writes to a room entity, this worker:
1. Detects the entity has an open room
2. For each member agent, creates a cross-reference entry in their private namespace
3. Logs the propagation in room_activity
"""

from __future__ import annotations

import logging
from typing import Any
from uuid import UUID

logger = logging.getLogger(__name__)


class KnowledgeSyncWorker:
    """Synchronizes room entity writes into each member agent's private memory."""

    def __init__(self, *, pool: Any, get_memory: Any) -> None:
        self._pool = pool
        self._get_memory = get_memory

    def on_room_write(
        self,
        *,
        entity_path: str,
        key: str,
        value: Any,
        confidence: float,
        author_agent_id: str,
        account_id: UUID,
        room_id: UUID,
    ) -> int:
        """Propagate a write to all room members' private memory.

        Returns the number of agents the write was propagated to.
        """
        members = self._get_room_members(room_id, exclude_agent=author_agent_id)
        if not members:
            return 0

        propagated = 0
        mem = self._get_memory()

        for member_agent_id in members:
            try:
                learned_path = f"{member_agent_id}/learned/{entity_path}"
                mem.write(
                    learned_path,
                    key,
                    value,
                    confidence=confidence,
                    memory_type="experience",
                    pattern_refs=[f"{entity_path}/{key}"],
                )
                propagated += 1
            except Exception:
                logger.warning(
                    "Failed to sync room write to agent %s",
                    member_agent_id,
                    exc_info=True,
                )

        logger.debug(
            "Propagated room write %s/%s to %d agents",
            entity_path, key, propagated,
        )
        return propagated

    def create_close_snapshots(
        self,
        *,
        room_id: UUID,
        entity_path: str,
        account_id: UUID,
    ) -> int:
        """Create knowledge snapshots for all member agents when a room closes.

        Copies all current room entity entries into each agent's private
        namespace at {agent_id}/rooms/{entity_path}/. The agent keeps this
        knowledge forever even after losing room access.

        Returns the number of snapshots created.
        """
        members = self._get_room_members(room_id)
        if not members:
            return 0

        mem = self._get_memory()
        entries = mem.list(entity_path)
        snapshots_created = 0

        for member_agent_id in members:
            snapshot_path = f"{member_agent_id}/rooms/{entity_path}"
            count = 0
            for entry in entries:
                try:
                    mem.write(
                        snapshot_path,
                        entry.key,
                        entry.value,
                        confidence=entry.confidence,
                        memory_type="experience",
                        pattern_refs=[f"{entity_path}/{entry.key}"],
                    )
                    count += 1
                except Exception:
                    logger.warning(
                        "Failed to snapshot entry %s for agent %s",
                        entry.key, member_agent_id, exc_info=True,
                    )

            try:
                with self._pool.connection() as conn:
                    conn.execute(
                        "SELECT set_config('amfs.current_account_id', %s, false)",
                        (str(account_id),),
                    )
                    conn.execute(
                        """
                        INSERT INTO room_snapshots
                            (room_id, agent_id, snapshot_entity_path, entry_count)
                        VALUES (%s, %s, %s, %s)
                        """,
                        (str(room_id), member_agent_id, snapshot_path, count),
                    )
                snapshots_created += 1
            except Exception:
                logger.warning(
                    "Failed to record snapshot for agent %s",
                    member_agent_id, exc_info=True,
                )

        return snapshots_created

    def _get_room_members(
        self, room_id: UUID, exclude_agent: str | None = None
    ) -> list[str]:
        try:
            with self._pool.connection() as conn:
                rows = conn.execute(
                    """
                    SELECT agent_id FROM room_memberships
                    WHERE room_id = %s AND left_at IS NULL
                    """,
                    (str(room_id),),
                ).fetchall()
                agents = [row[0] for row in rows]
                if exclude_agent:
                    agents = [a for a in agents if a != exclude_agent]
                return agents
        except Exception:
            logger.warning("Failed to get room members", exc_info=True)
            return []
