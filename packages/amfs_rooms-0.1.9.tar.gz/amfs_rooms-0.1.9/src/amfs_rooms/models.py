"""Pydantic request/response models for the Rooms API."""

from __future__ import annotations

from datetime import datetime
from uuid import UUID

from pydantic import BaseModel, Field


# ── Room ──────────────────────────────────────────────────────────────

class CreateRoomRequest(BaseModel):
    entity_path: str
    namespace: str = "default"
    display_name: str | None = None
    description: str | None = None
    discussions_enabled: bool = False
    settings: dict = Field(default_factory=dict)
    agent_id: str | None = None


class UpdateRoomRequest(BaseModel):
    display_name: str | None = None
    description: str | None = None
    discussions_enabled: bool | None = None
    settings: dict | None = None


class RoomResponse(BaseModel):
    id: UUID
    account_id: UUID
    entity_path: str
    namespace: str
    display_name: str | None
    description: str | None
    status: str
    discussions_enabled: bool
    settings: dict
    created_by: UUID
    closed_at: datetime | None
    closed_by: UUID | None
    created_at: datetime
    updated_at: datetime
    agent_count: int = 0
    user_count: int = 0


class RoomSummaryResponse(BaseModel):
    id: UUID
    entity_path: str
    namespace: str
    display_name: str | None
    status: str
    discussions_enabled: bool
    created_by: UUID
    created_at: datetime
    agent_count: int = 0
    user_count: int = 0
    your_role: str | None = None
    last_activity_at: datetime | None = None


# ── Invitations ───────────────────────────────────────────────────────

class InviteUserRequest(BaseModel):
    invited_user_id: UUID | None = None
    email: str | None = None
    role: str = "collaborator"


class InviteResponse(BaseModel):
    id: UUID
    room_id: UUID
    invited_user_id: UUID
    invited_by: UUID
    role: str
    status: str
    accepted_at: datetime | None
    created_at: datetime
    user_name: str | None = None
    user_email: str | None = None


# ── Memberships ───────────────────────────────────────────────────────

class JoinRoomRequest(BaseModel):
    agent_id: str


class MembershipResponse(BaseModel):
    id: UUID
    room_id: UUID
    agent_id: str
    owner_user_id: UUID
    role: str
    briefing_delivered: bool
    joined_at: datetime
    left_at: datetime | None
    owner_user_name: str | None = None
    owner_user_email: str | None = None


class MembersGroupedResponse(BaseModel):
    user_id: UUID
    user_name: str | None
    user_email: str | None
    agents: list[MembershipResponse]


# ── Activity ──────────────────────────────────────────────────────────

class ActivityResponse(BaseModel):
    id: UUID
    room_id: UUID
    agent_id: str | None
    user_id: UUID | None
    activity_type: str
    details: dict
    created_at: datetime


class ActivityPage(BaseModel):
    items: list[ActivityResponse]
    total: int
    has_more: bool


# ── Snapshots ─────────────────────────────────────────────────────────

class SnapshotResponse(BaseModel):
    id: UUID
    room_id: UUID
    agent_id: str
    snapshot_entity_path: str
    entry_count: int
    created_at: datetime


# ── Clone ─────────────────────────────────────────────────────────────

class CloneRoomRequest(BaseModel):
    display_name: str | None = None
    description: str | None = None
