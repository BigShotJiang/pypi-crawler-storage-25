"""Auto-briefing — generate a synthesized briefing when an agent joins a room."""

from __future__ import annotations

import logging
from datetime import datetime, timezone
from typing import Any
from uuid import UUID

logger = logging.getLogger(__name__)


class JoinBriefingService:
    """Generates and delivers a briefing to an agent when they join a room."""

    def __init__(self, *, pool: Any, get_memory: Any) -> None:
        self._pool = pool
        self._get_memory = get_memory

    def generate_and_deliver(
        self,
        *,
        room_id: UUID,
        entity_path: str,
        agent_id: str,
        account_id: UUID,
    ) -> str | None:
        """Generate a room briefing and deliver it to the agent's memory.

        Collects:
        - All entries on the room entity
        - Room activity log (who joined, what was written, what failed)
        - Discussion summaries (if discussions enabled)
        - Negotiation outcomes

        Returns the briefing text, or None if generation failed.
        """
        mem = self._get_memory()

        entries = mem.list(entity_path)
        activity = self._get_recent_activity(room_id, account_id)
        room_info = self._get_room_info(room_id, account_id)

        sections = []

        if room_info:
            sections.append(f"## Room: {room_info.get('display_name') or entity_path}")
            if room_info.get("description"):
                sections.append(room_info["description"])
            sections.append(f"Status: {room_info.get('status', 'open')}")
            sections.append(
                f"Discussions: {'enabled' if room_info.get('discussions_enabled') else 'disabled'}"
            )

        if entries:
            sections.append(f"\n## Knowledge ({len(entries)} entries)")
            for entry in entries[:50]:
                conf = getattr(entry, "confidence", None) or 0
                author = ""
                if hasattr(entry, "provenance") and hasattr(entry.provenance, "agent_id"):
                    author = f" (by {entry.provenance.agent_id})"
                val_preview = str(entry.value)[:200] if entry.value else ""
                sections.append(
                    f"- **{entry.key}** [conf={conf:.2f}]{author}: {val_preview}"
                )
            if len(entries) > 50:
                sections.append(f"  ... and {len(entries) - 50} more entries")

        if activity:
            sections.append(f"\n## Recent Activity ({len(activity)} events)")
            for evt in activity[:30]:
                ts = evt.get("created_at", "")
                atype = evt.get("activity_type", "")
                aid = evt.get("agent_id") or evt.get("user_id") or "system"
                sections.append(f"- [{ts}] {atype} by {aid}")

        failed_entries = [e for e in entries if e.key.startswith("failed/")]
        if failed_entries:
            sections.append(f"\n## What Failed ({len(failed_entries)} entries)")
            for entry in failed_entries[:20]:
                val_preview = str(entry.value)[:200] if entry.value else ""
                sections.append(f"- **{entry.key}**: {val_preview}")

        briefing_text = "\n".join(sections) if sections else "No room history yet."

        ts = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S")
        briefing_path = f"{agent_id}/briefings/rooms/{entity_path}"
        briefing_key = f"join-briefing-{ts}"

        try:
            mem.write(
                briefing_path,
                briefing_key,
                briefing_text,
                confidence=0.9,
                memory_type="experience",
            )
        except Exception:
            logger.warning("Failed to write join briefing for agent %s", agent_id, exc_info=True)

        try:
            with self._pool.connection() as conn:
                conn.execute(
                    "SELECT set_config('amfs.current_account_id', %s, false)",
                    (str(account_id),),
                )
                conn.execute(
                    """
                    UPDATE room_memberships SET briefing_delivered = true
                    WHERE room_id = %s AND agent_id = %s
                    """,
                    (str(room_id), agent_id),
                )
                conn.execute(
                    """
                    INSERT INTO room_activity
                        (room_id, account_id, agent_id, activity_type, details)
                    VALUES (%s, %s, %s, 'briefing_delivered', %s)
                    """,
                    (
                        str(room_id), str(account_id), agent_id,
                        f'{{"briefing_key": "{briefing_key}", "entry_count": {len(entries)}}}',
                    ),
                )
        except Exception:
            logger.warning("Failed to mark briefing as delivered", exc_info=True)

        return briefing_text

    def _get_recent_activity(self, room_id: UUID, account_id: UUID) -> list[dict]:
        try:
            with self._pool.connection() as conn:
                conn.execute(
                    "SELECT set_config('amfs.current_account_id', %s, false)",
                    (str(account_id),),
                )
                rows = conn.execute(
                    """
                    SELECT * FROM room_activity
                    WHERE room_id = %s
                    ORDER BY created_at DESC LIMIT 100
                    """,
                    (str(room_id),),
                ).fetchall()
                if not rows:
                    return []
                cols = [desc.name for desc in conn.description] if conn.description else []
                return [dict(zip(cols, row)) for row in rows]
        except Exception:
            logger.warning("Failed to get room activity for briefing", exc_info=True)
            return []

    def _get_room_info(self, room_id: UUID, account_id: UUID) -> dict | None:
        try:
            with self._pool.connection() as conn:
                conn.execute(
                    "SELECT set_config('amfs.current_account_id', %s, false)",
                    (str(account_id),),
                )
                row = conn.execute(
                    "SELECT * FROM entity_rooms WHERE id = %s",
                    (str(room_id),),
                ).fetchone()
                if row is None:
                    return None
                cols = [desc.name for desc in conn.description] if conn.description else []
                return dict(zip(cols, row))
        except Exception:
            logger.warning("Failed to get room info for briefing", exc_info=True)
            return None
