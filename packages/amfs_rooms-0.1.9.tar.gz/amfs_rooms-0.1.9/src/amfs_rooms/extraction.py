"""Background extraction worker for room knowledge graph.

Hooks into room writes and discussion messages to extract concepts
and relationships, storing them in room_concepts and room_concept_relations.
"""

from __future__ import annotations

import json
import logging
from typing import Any
from uuid import UUID

from psycopg.rows import dict_row

logger = logging.getLogger(__name__)


class RoomExtractionWorker:
    """Extracts concepts from room writes and persists to the knowledge graph tables."""

    def __init__(self, pool):
        self._pool = pool
        self._extractor = None

    def _get_extractor(self):
        if self._extractor is None:
            try:
                from amfs_extraction import EntityExtractor
                self._extractor = EntityExtractor(enabled=True)
            except ImportError:
                logger.debug("amfs_extraction not available, extraction disabled")
        return self._extractor

    def extract_from_write(
        self,
        room_id: UUID,
        account_id: UUID,
        entity_path: str,
        key: str,
        value: str,
        agent_id: str | None = None,
    ) -> int:
        """Extract concepts from a room write and store in the knowledge graph.

        Returns the number of concepts extracted.
        """
        extractor = self._get_extractor()
        if extractor is None or not extractor.enabled:
            return 0

        text = f"Entity: {entity_path}\nKey: {key}\n\n{value}"
        try:
            result = extractor.extract_from_text(text)
        except Exception:
            logger.warning("Extraction failed for room write", exc_info=True)
            return 0

        concept_count = 0
        concept_ids: dict[str, UUID] = {}

        with self._pool.connection() as conn:
            conn.row_factory = dict_row
            conn.execute(
                "SELECT set_config('amfs.current_account_id', %s, false)",
                (str(account_id),),
            )

            for entity in result.entities:
                row = conn.execute(
                    """INSERT INTO room_concepts
                       (room_id, account_id, name, concept_type, description,
                        confidence, source_entry_key, source_agent_id)
                       VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
                       ON CONFLICT (room_id, name, concept_type) DO UPDATE
                       SET description = COALESCE(EXCLUDED.description, room_concepts.description),
                           confidence = GREATEST(EXCLUDED.confidence, room_concepts.confidence),
                           source_entry_key = EXCLUDED.source_entry_key,
                           source_agent_id = EXCLUDED.source_agent_id,
                           extracted_at = now()
                       RETURNING id, name""",
                    (
                        str(room_id), str(account_id),
                        entity.name, entity.entity_type,
                        json.dumps(entity.attributes) if entity.attributes else None,
                        entity.confidence, key, agent_id,
                    ),
                ).fetchone()
                if row:
                    concept_ids[entity.name] = row["id"]
                    concept_count += 1

            for rel in result.relationships:
                source_id = concept_ids.get(rel.source_entity)
                target_id = concept_ids.get(rel.target_entity)
                if source_id and target_id:
                    conn.execute(
                        """INSERT INTO room_concept_relations
                           (room_id, source_id, target_id, relation_type,
                            confidence, metadata)
                           VALUES (%s, %s, %s, %s, %s, %s::jsonb)
                           ON CONFLICT (room_id, source_id, target_id, relation_type)
                           DO UPDATE SET confidence = GREATEST(EXCLUDED.confidence, room_concept_relations.confidence),
                                        extracted_at = now()""",
                        (
                            str(room_id), str(source_id), str(target_id),
                            rel.relationship_type, rel.confidence,
                            json.dumps({"description": rel.description}),
                        ),
                    )

            conn.commit()

        return concept_count

    def _set_tenant(self, conn, account_id: UUID | None) -> None:
        if account_id:
            conn.execute(
                "SELECT set_config('amfs.current_account_id', %s, false)",
                (str(account_id),),
            )

    def get_concepts(self, room_id: UUID, limit: int = 100, account_id: UUID | None = None) -> list[dict[str, Any]]:
        with self._pool.connection() as conn:
            conn.row_factory = dict_row
            self._set_tenant(conn, account_id)
            return list(conn.execute(
                "SELECT * FROM room_concepts WHERE room_id = %s "
                "ORDER BY confidence DESC, extracted_at DESC LIMIT %s",
                (str(room_id), limit),
            ).fetchall())

    def get_relations(self, room_id: UUID, limit: int = 200, account_id: UUID | None = None) -> list[dict[str, Any]]:
        with self._pool.connection() as conn:
            conn.row_factory = dict_row
            self._set_tenant(conn, account_id)
            return list(conn.execute(
                """SELECT r.*, s.name AS source_name, t.name AS target_name
                   FROM room_concept_relations r
                   JOIN room_concepts s ON s.id = r.source_id
                   JOIN room_concepts t ON t.id = r.target_id
                   WHERE r.room_id = %s
                   ORDER BY r.confidence DESC LIMIT %s""",
                (str(room_id), limit),
            ).fetchall())

    def get_graph(self, room_id: UUID, account_id: UUID | None = None) -> dict[str, Any]:
        """Return the full knowledge graph for a room as nodes + edges."""
        concepts = self.get_concepts(room_id, limit=200, account_id=account_id)
        relations = self.get_relations(room_id, limit=500, account_id=account_id)

        nodes = [
            {
                "id": str(c["id"]),
                "name": c["name"],
                "type": c.get("concept_type", "concept"),
                "confidence": c.get("confidence", 0.5),
            }
            for c in concepts
        ]
        edges = [
            {
                "source": str(r["source_id"]),
                "target": str(r["target_id"]),
                "type": r.get("relation_type", "related"),
                "source_name": r.get("source_name"),
                "target_name": r.get("target_name"),
                "confidence": r.get("confidence", 0.5),
            }
            for r in relations
        ]
        return {"nodes": nodes, "edges": edges}
