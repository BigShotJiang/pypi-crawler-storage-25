"""AMFS Rooms — collaborative entity rooms for multi-agent knowledge sharing.

Provides FastAPI routers that mount onto the AMFS HTTP server,
exposing room management, membership, activity, and knowledge sync.

The OSS server discovers this package via:

    try:
        from amfs_rooms import mount_rooms
        mount_rooms(app, get_memory=_get_memory)
    except ImportError:
        pass
"""

from __future__ import annotations

import logging
from typing import Any, Callable

_get_memory_fn: Callable | None = None
_db_pool: Any = None

logger = logging.getLogger(__name__)


def get_memory():
    """Access the shared AgentMemory singleton provided by the host server."""
    if _get_memory_fn is None:
        raise RuntimeError("Rooms not mounted — call mount_rooms first")
    return _get_memory_fn()


def get_db_pool():
    """Access the shared database pool (explicit or from memory adapter)."""
    if _db_pool is not None:
        return _db_pool
    # Fallback: derive from the memory adapter's internal pool
    if _get_memory_fn is not None:
        try:
            mem = _get_memory_fn()
            adapter = getattr(mem, "_adapter", None)
            if adapter is not None and hasattr(adapter, "_pool"):
                return adapter._pool
        except Exception:
            pass
    return None


def mount_rooms(app: Any, *, get_memory: Callable, db_pool: Any = None) -> None:
    """Mount all room API routers onto an existing FastAPI app."""
    global _get_memory_fn, _db_pool
    _get_memory_fn = get_memory
    _db_pool = db_pool

    from .routes import router as rooms_router
    from .routes import notifications_router

    app.include_router(rooms_router)
    app.include_router(notifications_router)
    logger.info("Room endpoints mounted at /api/v1/rooms, /api/v1/notifications")
