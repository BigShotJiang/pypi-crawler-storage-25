"""User notification helpers for room events (negotiations, agent engagement)."""

from __future__ import annotations

import logging
from typing import Any
from uuid import UUID

from psycopg.rows import dict_row

logger = logging.getLogger(__name__)


def insert_notification(
    pool: Any,
    account_id: UUID,
    user_id: UUID,
    notification_type: str,
    title: str,
    body: str | None = None,
    metadata: dict | None = None,
    room_id: UUID | None = None,
) -> bool:
    """Insert a single user notification. Returns True on success."""
    try:
        import json as _json
        import psycopg.types.json

        with pool.connection() as conn:
            conn.row_factory = dict_row
            conn.execute(
                "SELECT set_config('amfs.current_account_id', %s, false)",
                (str(account_id),),
            )
            conn.execute(
                """INSERT INTO user_notifications
                   (account_id, user_id, notification_type, title, body, metadata, room_id)
                   VALUES (%s, %s, %s, %s, %s, %s::jsonb, %s)
                   ON CONFLICT DO NOTHING""",
                (
                    str(account_id),
                    str(user_id),
                    notification_type,
                    title,
                    body,
                    _json.dumps(metadata or {}),
                    str(room_id) if room_id else None,
                ),
            )
            conn.commit()
        return True
    except Exception:
        logger.debug("Failed to insert notification", exc_info=True)
        return False


def notify_room_members(
    pool: Any,
    svc: Any,
    room_id: UUID,
    account_id: UUID,
    exclude_user_id: UUID | str | None,
    notification_type: str,
    title: str,
    body: str | None = None,
    metadata: dict | None = None,
) -> int:
    """Notify all accepted room members except the excluded user. Returns count sent."""
    count = 0
    try:
        invites = svc.list_invites(room_id, account_id)
        notified: set[str] = set()

        for inv in invites:
            if inv.get("status") != "accepted":
                continue
            uid = inv.get("invited_user_id")
            if not uid:
                continue
            uid_str = str(uid)
            if exclude_user_id and uid_str == str(exclude_user_id):
                continue
            if uid_str in notified:
                continue
            notified.add(uid_str)
            if insert_notification(
                pool, account_id, UUID(uid_str),
                notification_type, title, body, metadata, room_id,
            ):
                count += 1

        # Also include the room owner if not already notified
        try:
            room = svc.get_room(room_id, account_id)
            if room:
                owner_id = str(room.get("created_by", ""))
                if (
                    owner_id
                    and owner_id not in notified
                    and (not exclude_user_id or owner_id != str(exclude_user_id))
                ):
                    if insert_notification(
                        pool, account_id, UUID(owner_id),
                        notification_type, title, body, metadata, room_id,
                    ):
                        count += 1
        except Exception:
            pass

    except Exception:
        logger.debug("Failed to notify room members", exc_info=True)
    return count


def resolve_agent_owner(pool: Any, account_id: UUID, agent_id: str) -> UUID | None:
    """Look up the owner_user_id for an agent_id."""
    try:
        with pool.connection() as conn:
            conn.row_factory = dict_row
            conn.execute(
                "SELECT set_config('amfs.current_account_id', %s, false)",
                (str(account_id),),
            )
            row = conn.execute(
                "SELECT owner_user_id FROM agents WHERE agent_id = %s",
                (agent_id,),
            ).fetchone()
            return row["owner_user_id"] if row else None
    except Exception:
        logger.debug("Failed to resolve agent owner for %s", agent_id)
        return None
