"""Write-path middleware — enforces room membership on entity writes.

When a write targets an entity_path that has an open room:
- If the agent is a room member: allow + trigger knowledge sync + log activity
- If the agent is NOT a member AND not the owner's agent: block
- If no room exists on this entity: pass through (backward compatible)
"""

from __future__ import annotations

import logging
from typing import Any
from uuid import UUID

logger = logging.getLogger(__name__)


class RoomWriteMiddleware:
    """Intercepts writes to room-enabled entities for ACL + side effects."""

    def __init__(
        self, *, pool: Any, knowledge_sync: Any = None, extraction_worker: Any = None,
    ) -> None:
        self._pool = pool
        self._knowledge_sync = knowledge_sync
        self._extraction_worker = extraction_worker
        self._room_cache: dict[str, dict | None] = {}

    def check_write_access(
        self,
        *,
        entity_path: str,
        agent_id: str,
        account_id: UUID,
        namespace: str = "default",
    ) -> dict | None:
        """Check if a write to this entity_path should be allowed.

        Returns the room dict if the entity has a room and the agent is a member,
        or None if no room exists (write proceeds normally).

        If the agent is not a member but the owning user has an accepted invite,
        the agent is auto-joined to the room. Raises PermissionError only if
        the user has no accepted invite at all.
        """
        room = self._get_room_for_entity(entity_path, account_id, namespace)
        if room is None:
            return None

        if room["status"] != "open":
            return None

        if self._is_member(room["id"], agent_id):
            return room

        if self._is_owner_agent(room, agent_id, account_id):
            return room

        if self._try_auto_join(room["id"], agent_id, account_id):
            return room

        raise PermissionError(
            f"Agent '{agent_id}' is not a member of the room on entity '{entity_path}'. "
            "Join the room first with amfs_room_join."
        )

    def _try_auto_join(self, room_id: UUID, agent_id: str, account_id: UUID) -> bool:
        """Auto-join the agent if the owning user has an accepted invite."""
        try:
            with self._pool.connection() as conn:
                conn.execute(
                    "SELECT set_config('amfs.current_account_id', %s, false)",
                    (str(account_id),),
                )
                owner_row = conn.execute(
                    "SELECT owner_user_id FROM agents WHERE agent_id = %s LIMIT 1",
                    (agent_id,),
                ).fetchone()
                if not owner_row:
                    return False

                owner_user_id = str(owner_row[0])
                invite = conn.execute(
                    """SELECT id, role FROM room_user_invites
                       WHERE room_id = %s AND invited_user_id = %s AND status = 'accepted'""",
                    (str(room_id), owner_user_id),
                ).fetchone()
                if not invite:
                    return False

                import psycopg.types.json
                from psycopg.rows import dict_row
                conn.row_factory = dict_row
                conn.execute(
                    """INSERT INTO room_memberships
                           (room_id, invite_id, agent_id, owner_user_id, role)
                       VALUES (%s, %s, %s, %s, %s)
                       ON CONFLICT (room_id, agent_id) DO UPDATE
                           SET left_at = NULL, role = EXCLUDED.role""",
                    (str(room_id), str(invite[0]), agent_id, owner_user_id, invite[1] or "member"),
                )
                conn.execute(
                    """INSERT INTO room_activity
                           (room_id, account_id, agent_id, user_id, activity_type, details)
                       VALUES (%s, %s, %s, %s, 'agent_joined', %s)""",
                    (
                        str(room_id), str(account_id), agent_id, owner_user_id,
                        psycopg.types.json.Json({"role": invite[1] or "member", "auto_joined": True}),
                    ),
                )
                conn.commit()
                logger.info(
                    "Auto-joined agent %s to room %s (user %s had accepted invite)",
                    agent_id, room_id, owner_user_id,
                )
                return True
        except Exception:
            logger.warning("Auto-join failed for agent %s", agent_id, exc_info=True)
            return False

    def after_write(
        self,
        *,
        room: dict,
        entity_path: str,
        key: str,
        value: Any,
        confidence: float,
        agent_id: str,
        account_id: UUID,
    ) -> None:
        """Post-write side effects: knowledge sync + activity logging."""
        if self._knowledge_sync:
            try:
                self._knowledge_sync.on_room_write(
                    entity_path=entity_path,
                    key=key,
                    value=value,
                    confidence=confidence,
                    author_agent_id=agent_id,
                    account_id=account_id,
                    room_id=room["id"],
                )
            except Exception:
                logger.warning("Knowledge sync failed for room write", exc_info=True)

        try:
            import psycopg.types.json
            with self._pool.connection() as conn:
                conn.execute(
                    "SELECT set_config('amfs.current_account_id', %s, false)",
                    (str(account_id),),
                )
                conn.execute(
                    """
                    INSERT INTO room_activity
                        (room_id, account_id, agent_id, activity_type, details)
                    VALUES (%s, %s, %s, 'write', %s)
                    """,
                    (
                        str(room["id"]), str(account_id), agent_id,
                        psycopg.types.json.Json({
                            "entity_path": entity_path,
                            "key": key,
                        }),
                    ),
                )
        except Exception:
            logger.warning("Failed to log room write activity", exc_info=True)

        if self._extraction_worker:
            try:
                self._extraction_worker.extract_from_write(
                    room_id=UUID(str(room["id"])),
                    account_id=account_id,
                    entity_path=entity_path,
                    key=key,
                    value=str(value) if value else "",
                    agent_id=agent_id,
                )
            except Exception:
                logger.debug("Background extraction failed", exc_info=True)

    def log_read(
        self,
        *,
        room_id: UUID,
        entity_path: str,
        key: str,
        agent_id: str,
        account_id: UUID,
        author_agent_id: str | None = None,
    ) -> None:
        """Log a read event in room_activity."""
        try:
            import psycopg.types.json
            with self._pool.connection() as conn:
                conn.execute(
                    "SELECT set_config('amfs.current_account_id', %s, false)",
                    (str(account_id),),
                )
                conn.execute(
                    """
                    INSERT INTO room_activity
                        (room_id, account_id, agent_id, activity_type, details)
                    VALUES (%s, %s, %s, 'read', %s)
                    """,
                    (
                        str(room_id), str(account_id), agent_id,
                        psycopg.types.json.Json({
                            "entity_path": entity_path,
                            "key": key,
                            "author_agent_id": author_agent_id,
                        }),
                    ),
                )
        except Exception:
            logger.debug("Failed to log room read activity", exc_info=True)

    def _get_room_for_entity(
        self, entity_path: str, account_id: UUID, namespace: str
    ) -> dict | None:
        cache_key = f"{account_id}:{namespace}:{entity_path}"
        if cache_key in self._room_cache:
            return self._room_cache[cache_key]

        try:
            with self._pool.connection() as conn:
                conn.execute(
                    "SELECT set_config('amfs.current_account_id', %s, false)",
                    (str(account_id),),
                )
                row = conn.execute(
                    """SELECT * FROM entity_rooms
                       WHERE entity_path = %s AND namespace = %s""",
                    (entity_path, namespace),
                ).fetchone()
                if row is None:
                    self._room_cache[cache_key] = None
                    return None
                cols = [d.name for d in conn.description] if conn.description else []
                room = dict(zip(cols, row))
                self._room_cache[cache_key] = room
                return room
        except Exception:
            logger.warning("Failed to check room for entity", exc_info=True)
            return None

    def _is_member(self, room_id: UUID, agent_id: str) -> bool:
        try:
            with self._pool.connection() as conn:
                row = conn.execute(
                    """SELECT 1 FROM room_memberships
                       WHERE room_id = %s AND agent_id = %s AND left_at IS NULL""",
                    (str(room_id), agent_id),
                ).fetchone()
                return row is not None
        except Exception:
            return False

    def _is_owner_agent(self, room: dict, agent_id: str, account_id: UUID) -> bool:
        """Check if the agent belongs to the room owner (entity creator)."""
        try:
            owner_user_id = room.get("created_by")
            if not owner_user_id:
                return False
            with self._pool.connection() as conn:
                row = conn.execute(
                    "SELECT 1 FROM agents WHERE agent_id = %s AND owner_user_id = %s",
                    (agent_id, str(owner_user_id)),
                ).fetchone()
                return row is not None
        except Exception:
            return False
