"""VisibilityFilter — enforces user-scoped + room-entity-scoped access.

The single rule:
  An entry is VISIBLE to Agent W (owned by User B) if:
    1. The entry's author agent is owned by User B, OR
    2. The entry's entity_path matches a room's entity_path where Agent W
       is a member AND the entry's author is also a member of that room.
"""

from __future__ import annotations

import logging
from typing import Any
from uuid import UUID

logger = logging.getLogger(__name__)


class VisibilityFilter:
    """Wraps read operations to enforce user-level + room-entity-scoped visibility.

    Created once per MCP/API session. Caches user agents and room memberships
    lazily on first access.
    """

    def __init__(self, *, user_id: UUID, agent_id: str, pool: Any) -> None:
        self._user_id = user_id
        self._agent_id = agent_id
        self._pool = pool
        self._user_agent_ids: set[str] | None = None
        self._room_map: dict[str, set[str]] | None = None

    @property
    def user_id(self) -> UUID:
        return self._user_id

    @property
    def agent_id(self) -> str:
        return self._agent_id

    def invalidate_cache(self) -> None:
        """Force refresh on next access (e.g. after a room join/leave)."""
        self._user_agent_ids = None
        self._room_map = None

    # ── Core visibility checks ────────────────────────────────────────

    def get_user_agents(self) -> set[str]:
        """All agent_ids owned by this user (same account)."""
        if self._user_agent_ids is None:
            self._user_agent_ids = self._load_user_agents()
        return self._user_agent_ids

    def get_room_map(self) -> dict[str, set[str]]:
        """Map of entity_path -> set of member agent_ids for rooms this agent belongs to."""
        if self._room_map is None:
            self._room_map = self._load_room_map()
        return self._room_map

    def is_entry_visible(self, entry: Any) -> bool:
        """Check if a MemoryEntry should be visible to the current agent."""
        author = _get_author(entry)
        if author is None:
            return True

        if author in self.get_user_agents():
            return True

        entity_path = _get_entity_path(entry)
        room_members = self.get_room_map().get(entity_path)
        if room_members and author in room_members:
            return True

        return False

    def is_agent_visible(self, target_agent_id: str) -> bool:
        """Can the current agent see the target agent at all?"""
        if target_agent_id in self.get_user_agents():
            return True
        for members in self.get_room_map().values():
            if target_agent_id in members:
                return True
        return False

    def is_read_from_allowed(self, target_agent_id: str, entity_path: str) -> bool:
        """Can the current agent read from target_agent on this entity_path?"""
        if target_agent_id in self.get_user_agents():
            return True
        room_members = self.get_room_map().get(entity_path)
        if room_members and target_agent_id in room_members:
            return True
        return False

    def filter_entries(self, entries: list) -> list:
        """Filter a list of MemoryEntry objects to only visible ones."""
        if not entries:
            return entries
        user_agents = self.get_user_agents()
        room_map = self.get_room_map()
        result = []
        for entry in entries:
            author = _get_author(entry)
            if author is None or author in user_agents:
                result.append(entry)
                continue
            ep = _get_entity_path(entry)
            room_members = room_map.get(ep)
            if room_members and author in room_members:
                result.append(entry)
        return result

    def get_visible_agent_ids(self) -> set[str]:
        """All agent_ids visible to this agent (own user + room co-members)."""
        visible = set(self.get_user_agents())
        for members in self.get_room_map().values():
            visible.update(members)
        return visible

    # ── Data loaders ──────────────────────────────────────────────────

    def _load_user_agents(self) -> set[str]:
        try:
            with self._pool.connection() as conn:
                rows = conn.execute(
                    "SELECT agent_id FROM agents WHERE owner_user_id = %s",
                    (str(self._user_id),),
                ).fetchall()
                return {row[0] for row in rows}
        except Exception:
            logger.warning("Failed to load user agents for visibility filter", exc_info=True)
            return {self._agent_id}

    def _load_room_map(self) -> dict[str, set[str]]:
        try:
            with self._pool.connection() as conn:
                rows = conn.execute(
                    "SELECT room_id, entity_path, member_agent_ids FROM get_agent_room_entity_paths(%s)",
                    (self._agent_id,),
                ).fetchall()
                return {row[1]: set(row[2]) for row in rows}
        except Exception:
            logger.warning("Failed to load room map for visibility filter", exc_info=True)
            return {}


class UserVisibilityFilter:
    """Dashboard/API-level visibility filter scoped to a user (not a specific agent).

    Unlike VisibilityFilter which is agent-scoped (MCP context), this works
    for dashboard requests where there is no single agent identity.
    Admins bypass filtering entirely.
    """

    def __init__(self, *, user_id: UUID, pool: Any, is_admin: bool = False) -> None:
        self._user_id = user_id
        self._pool = pool
        self._is_admin = is_admin
        self._user_agent_ids: set[str] | None = None
        self._room_map: dict[str, set[str]] | None = None

    def should_filter(self) -> bool:
        """Return False for admins (see everything), True otherwise."""
        return not self._is_admin

    def get_user_agents(self) -> set[str]:
        if self._user_agent_ids is None:
            self._user_agent_ids = self._load_user_agents()
        return self._user_agent_ids

    def get_room_map(self) -> dict[str, set[str]]:
        if self._room_map is None:
            self._room_map = self._load_room_map()
        return self._room_map

    def is_entry_visible(self, entry: Any) -> bool:
        """An entry is visible if:
        1. Its author is one of the user's own agents, OR
        2. Its entity_path matches a shared room AND the author is a member
           of that room (covers both co-member agents and system agents).
        """
        author = _get_author(entry)
        if author is None:
            return True
        if author in self.get_user_agents():
            return True
        entity_path = _get_entity_path(entry)
        room_map = self.get_room_map()
        if entity_path in room_map:
            room_members = room_map[entity_path]
            if author in room_members:
                return True
            # System/service entries on a room entity path are visible
            # to all room participants (e.g. negotiation events by amfs-server)
            if author in ("amfs-server", "system", "amfs"):
                return True
        return False

    def is_agent_visible(self, target_agent_id: str) -> bool:
        """Only the user's OWN agents are visible at the agent level.
        Room co-members are NOT exposed on the agents page — their entries
        are only visible on the specific shared entity_path via is_entry_visible.
        """
        return target_agent_id in self.get_user_agents()

    def filter_entries(self, entries: list) -> list:
        if not entries:
            return entries
        user_agents = self.get_user_agents()
        room_map = self.get_room_map()
        result = []
        for entry in entries:
            author = _get_author(entry)
            if author is None or author in user_agents:
                result.append(entry)
                continue
            ep = _get_entity_path(entry)
            if ep in room_map:
                room_members = room_map[ep]
                if author in room_members or author in ("amfs-server", "system", "amfs"):
                    result.append(entry)
        return result

    def get_visible_agent_ids(self) -> set[str]:
        """For agent listing, only return user's own agents."""
        return set(self.get_user_agents())

    def _load_user_agents(self) -> set[str]:
        try:
            with self._pool.connection() as conn:
                rows = conn.execute(
                    "SELECT agent_id FROM agents WHERE owner_user_id = %s",
                    (str(self._user_id),),
                ).fetchall()
                return {
                    (row["agent_id"] if isinstance(row, dict) else row[0])
                    for row in rows
                }
        except Exception:
            logger.warning("Failed to load user agents for UserVisibilityFilter", exc_info=True)
            return set()

    def _load_room_map(self) -> dict[str, set[str]]:
        """Load room entity paths where this user has accepted invites."""
        try:
            with self._pool.connection() as conn:
                rows = conn.execute(
                    """
                    SELECT er.entity_path,
                           array_agg(DISTINCT rm.agent_id) AS member_agent_ids
                    FROM room_user_invites rui
                    JOIN entity_rooms er ON er.id = rui.room_id AND er.status = 'open'
                    JOIN room_memberships rm ON rm.room_id = er.id AND rm.left_at IS NULL
                    WHERE rui.invited_user_id = %s AND rui.status = 'accepted'
                    GROUP BY er.entity_path
                    """,
                    (str(self._user_id),),
                ).fetchall()
                return {
                    (row["entity_path"] if isinstance(row, dict) else row[0]):
                    set(row["member_agent_ids"] if isinstance(row, dict) else row[1])
                    for row in rows
                }
        except Exception:
            logger.warning("Failed to load room map for UserVisibilityFilter", exc_info=True)
            return {}


# ── Helpers ───────────────────────────────────────────────────────────

def _get_author(entry: Any) -> str | None:
    """Extract author agent_id from a MemoryEntry (handles both dict and model)."""
    if hasattr(entry, "provenance"):
        prov = entry.provenance
        if hasattr(prov, "agent_id"):
            return prov.agent_id
        if isinstance(prov, dict):
            return prov.get("agent_id")
    if isinstance(entry, dict):
        prov = entry.get("provenance", {})
        if isinstance(prov, dict):
            return prov.get("agent_id")
    return None


def _get_entity_path(entry: Any) -> str:
    """Extract entity_path from a MemoryEntry."""
    if hasattr(entry, "entity_path"):
        return entry.entity_path
    if isinstance(entry, dict):
        return entry.get("entity_path", "")
    return ""
