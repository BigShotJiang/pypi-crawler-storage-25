"""FastAPI routes for entity rooms."""

from __future__ import annotations

import logging
from datetime import datetime
from typing import Any
from uuid import UUID

from fastapi import APIRouter, HTTPException, Query, Request

from .models import (
    ActivityPage,
    ActivityResponse,
    CloneRoomRequest,
    CreateRoomRequest,
    InviteResponse,
    InviteUserRequest,
    JoinRoomRequest,
    MembershipResponse,
    MembersGroupedResponse,
    RoomResponse,
    RoomSummaryResponse,
    UpdateRoomRequest,
)

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/rooms", tags=["rooms"])


def _get_service(request: Request) -> Any:
    """Resolve the RoomService from app state."""
    svc = getattr(request.app.state, "room_service", None)
    if svc is None:
        from . import get_db_pool, get_memory
        from .service import RoomService

        pool = get_db_pool()
        if pool is None:
            raise HTTPException(status_code=503, detail="Database pool not available")
        svc = RoomService(pool, get_memory=get_memory)
        request.app.state.room_service = svc
    return svc


def _get_account_id(request: Request) -> UUID:
    account_id = getattr(request.state, "account_id", None)
    if account_id is None:
        raise HTTPException(status_code=401, detail="Account context required")
    return UUID(str(account_id))


def _get_user_id(request: Request) -> UUID:
    user_id = getattr(request.state, "user_id", None)
    if user_id is None:
        raise HTTPException(status_code=401, detail="User context required")
    return UUID(str(user_id))


# ── Account tier & visibility ─────────────────────────────────────────

@router.get("/account-tier")
def get_account_tier(request: Request) -> Any:
    """Return the account's plan tier and whether rooms are enabled."""
    account_id = _get_account_id(request)
    from . import get_db_pool
    from psycopg.rows import dict_row

    pool = get_db_pool()
    if pool is None:
        raise HTTPException(status_code=503, detail="Database pool not available")
    with pool.connection() as conn:
        conn.row_factory = dict_row
        conn.execute(
            "SELECT set_config('amfs.current_account_id', %s, false)",
            (str(account_id),),
        )
        row = conn.execute(
            "SELECT plan_tier, plan_status FROM accounts WHERE id = %s",
            (str(account_id),),
        ).fetchone()
    if not row:
        raise HTTPException(status_code=404, detail="Account not found")
    tier = row.get("plan_tier")
    return {
        "plan_tier": tier,
        "plan_status": row.get("plan_status"),
        "rooms_enabled": tier in ("pro", "teams", "enterprise"),
    }


@router.get("/my-visibility")
def my_visibility(request: Request) -> Any:
    """Return the current user's visible agent IDs and room-shared entity paths."""
    account_id = _get_account_id(request)
    user_id = _get_user_id(request)
    from . import get_db_pool
    from psycopg.rows import dict_row

    pool = get_db_pool()
    if pool is None:
        return {"my_agent_ids": [], "shared_entity_paths": {}}
    with pool.connection() as conn:
        conn.row_factory = dict_row
        conn.execute(
            "SELECT set_config('amfs.current_account_id', %s, false)",
            (str(account_id),),
        )
        agent_rows = conn.execute(
            "SELECT agent_id FROM agents WHERE owner_user_id = %s",
            (str(user_id),),
        ).fetchall()
        room_rows = conn.execute(
            """
            SELECT er.entity_path,
                   array_agg(DISTINCT rm.agent_id) AS member_agent_ids
            FROM room_user_invites rui
            JOIN entity_rooms er ON er.id = rui.room_id AND er.status = 'open'
            JOIN room_memberships rm ON rm.room_id = er.id AND rm.left_at IS NULL
            WHERE rui.invited_user_id = %s AND rui.status = 'accepted'
            GROUP BY er.entity_path
            """,
            (str(user_id),),
        ).fetchall()
    return {
        "my_agent_ids": [r["agent_id"] for r in agent_rows],
        "shared_entity_paths": {
            r["entity_path"]: r["member_agent_ids"] for r in room_rows
        },
    }


# ── Room CRUD ─────────────────────────────────────────────────────────

@router.post("", response_model=RoomResponse)
def create_room(body: CreateRoomRequest, request: Request) -> Any:
    svc = _get_service(request)
    account_id = _get_account_id(request)
    user_id = _get_user_id(request)
    try:
        return svc.create_room(
            account_id=account_id,
            entity_path=body.entity_path,
            namespace=body.namespace,
            display_name=body.display_name,
            description=body.description,
            discussions_enabled=body.discussions_enabled,
            settings=body.settings,
            created_by=user_id,
            creator_agent_id=body.agent_id,
        )
    except Exception:
        logger.exception(
            "create_room failed for entity_path=%s account_id=%s user_id=%s",
            body.entity_path, account_id, user_id,
        )
        raise


@router.get("", response_model=list[RoomSummaryResponse])
def list_rooms(request: Request) -> Any:
    svc = _get_service(request)
    account_id = _get_account_id(request)
    user_id = _get_user_id(request)
    return svc.list_rooms(account_id, user_id)


@router.get("/my-invites")
def my_pending_invites(request: Request) -> Any:
    svc = _get_service(request)
    account_id = _get_account_id(request)
    user_id = _get_user_id(request)
    return svc.list_pending_invites_for_user(account_id, user_id)


@router.get("/{room_id}", response_model=RoomResponse)
def get_room(room_id: UUID, request: Request) -> Any:
    svc = _get_service(request)
    account_id = _get_account_id(request)
    room = svc.get_room(room_id, account_id)
    if room is None:
        raise HTTPException(status_code=404, detail="Room not found")
    return room


@router.patch("/{room_id}", response_model=RoomResponse)
def update_room(room_id: UUID, body: UpdateRoomRequest, request: Request) -> Any:
    svc = _get_service(request)
    account_id = _get_account_id(request)
    user_id = _get_user_id(request)

    room = svc.get_room(room_id, account_id)
    if room is None:
        raise HTTPException(status_code=404, detail="Room not found")
    if UUID(str(room["created_by"])) != user_id:
        raise HTTPException(status_code=403, detail="Only the room owner can update settings")

    updated = svc.update_room(room_id, account_id, **body.model_dump(exclude_none=True))
    if updated is None:
        raise HTTPException(status_code=404, detail="Room not found")
    return updated


@router.post("/{room_id}/close")
def close_room(room_id: UUID, request: Request) -> Any:
    svc = _get_service(request)
    account_id = _get_account_id(request)
    user_id = _get_user_id(request)

    room = svc.get_room(room_id, account_id)
    if room is None:
        raise HTTPException(status_code=404, detail="Room not found")
    if UUID(str(room["created_by"])) != user_id:
        raise HTTPException(status_code=403, detail="Only the room owner can close the room")

    closed = svc.close_room(room_id, account_id, user_id)
    if closed is None:
        raise HTTPException(status_code=409, detail="Room is already closed")
    return {"status": "closed", "entity_path": closed.get("entity_path")}


@router.delete("/{room_id}")
def delete_room(room_id: UUID, request: Request) -> Any:
    svc = _get_service(request)
    account_id = _get_account_id(request)
    user_id = _get_user_id(request)

    deleted = svc.delete_room(room_id, account_id, user_id)
    if deleted is None:
        raise HTTPException(status_code=404, detail="Room not found or not authorized")
    return {"status": "deleted", "entity_path": deleted.get("entity_path")}


@router.post("/{room_id}/clone", response_model=RoomResponse)
def clone_room(room_id: UUID, body: CloneRoomRequest, request: Request) -> Any:
    svc = _get_service(request)
    account_id = _get_account_id(request)
    user_id = _get_user_id(request)

    room = svc.get_room(room_id, account_id)
    if room is None:
        raise HTTPException(status_code=404, detail="Room not found")
    if UUID(str(room["created_by"])) != user_id:
        raise HTTPException(status_code=403, detail="Only the room owner can clone")

    from datetime import timezone
    ts = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")
    clone_entity = f"{room['entity_path']}/clone-{ts}"

    return svc.create_room(
        account_id=account_id,
        entity_path=clone_entity,
        namespace=room["namespace"],
        display_name=body.display_name or f"{room.get('display_name') or room['entity_path']} (clone)",
        description=body.description or room.get("description"),
        discussions_enabled=room["discussions_enabled"],
        settings=room.get("settings", {}),
        created_by=user_id,
    )


# ── Invitations ───────────────────────────────────────────────────────

@router.post("/{room_id}/invites", response_model=InviteResponse)
def invite_user(room_id: UUID, body: InviteUserRequest, request: Request) -> Any:
    svc = _get_service(request)
    account_id = _get_account_id(request)
    user_id = _get_user_id(request)

    room = svc.get_room(room_id, account_id)
    if room is None:
        raise HTTPException(status_code=404, detail="Room not found")
    if UUID(str(room["created_by"])) != user_id:
        raise HTTPException(status_code=403, detail="Only the room owner can invite users")
    if room["status"] != "open":
        raise HTTPException(status_code=409, detail="Cannot invite to a closed room")

    if body.invited_user_id is None and body.email is None:
        raise HTTPException(status_code=400, detail="Provide invited_user_id or email")

    target_user_id = body.invited_user_id
    # TODO: resolve email to user_id if email is provided

    if target_user_id is None:
        raise HTTPException(status_code=400, detail="Could not resolve user")

    return svc.invite_user(
        room_id=room_id,
        account_id=account_id,
        invited_user_id=target_user_id,
        invited_by=user_id,
        role=body.role,
    )


@router.get("/{room_id}/invites", response_model=list[InviteResponse])
def list_invites(room_id: UUID, request: Request) -> Any:
    svc = _get_service(request)
    account_id = _get_account_id(request)
    return svc.list_invites(room_id, account_id)


@router.delete("/{room_id}/invites/{invite_id}")
def revoke_invite(room_id: UUID, invite_id: UUID, request: Request) -> Any:
    svc = _get_service(request)
    account_id = _get_account_id(request)
    user_id = _get_user_id(request)

    room = svc.get_room(room_id, account_id)
    if room is None:
        raise HTTPException(status_code=404, detail="Room not found")
    if UUID(str(room["created_by"])) != user_id:
        raise HTTPException(status_code=403, detail="Only the room owner can revoke invites")

    result = svc.revoke_invite(invite_id, account_id)
    if result is None:
        raise HTTPException(status_code=404, detail="Invite not found or already revoked")
    return {"status": "revoked"}


@router.post("/{room_id}/invites/{invite_id}/accept")
def accept_invite(room_id: UUID, invite_id: UUID, request: Request) -> Any:
    svc = _get_service(request)
    account_id = _get_account_id(request)
    user_id = _get_user_id(request)
    result = svc.accept_invite(invite_id, account_id, user_id)
    if result is None:
        raise HTTPException(status_code=404, detail="Invite not found or not pending")
    return {"status": "accepted"}


@router.post("/{room_id}/invites/{invite_id}/decline")
def decline_invite(room_id: UUID, invite_id: UUID, request: Request) -> Any:
    svc = _get_service(request)
    account_id = _get_account_id(request)
    user_id = _get_user_id(request)
    result = svc.decline_invite(invite_id, account_id, user_id)
    if result is None:
        raise HTTPException(status_code=404, detail="Invite not found or not pending")
    return {"status": "declined"}


# ── Agent Membership ──────────────────────────────────────────────────

@router.post("/{room_id}/agents", response_model=MembershipResponse)
def agent_join(room_id: UUID, body: JoinRoomRequest, request: Request) -> Any:
    svc = _get_service(request)
    account_id = _get_account_id(request)
    user_id = _get_user_id(request)

    room = svc.get_room(room_id, account_id)
    if room is None:
        raise HTTPException(status_code=404, detail="Room not found")
    if room["status"] != "open":
        raise HTTPException(status_code=409, detail="Room is closed")

    membership = svc.agent_join(
        room_id=room_id,
        account_id=account_id,
        agent_id=body.agent_id,
        owner_user_id=user_id,
    )
    if membership is None:
        raise HTTPException(
            status_code=403,
            detail="User must have an accepted invitation to join agents to this room",
        )
    return membership


@router.delete("/{room_id}/agents/{agent_id}")
def agent_leave(room_id: UUID, agent_id: str, request: Request) -> Any:
    svc = _get_service(request)
    account_id = _get_account_id(request)
    if not svc.agent_leave(room_id, account_id, agent_id):
        raise HTTPException(status_code=404, detail="Membership not found")
    return {"status": "left"}


@router.get("/{room_id}/agents")
def list_agents(room_id: UUID, request: Request) -> Any:
    svc = _get_service(request)
    account_id = _get_account_id(request)
    members = svc.list_members(room_id, account_id)

    grouped: dict[str, dict] = {}
    member_agent_ids: set[str] = set()
    for m in members:
        uid = str(m["owner_user_id"])
        if uid not in grouped:
            grouped[uid] = {
                "user_id": m["owner_user_id"],
                "user_name": m.get("owner_user_name"),
                "user_email": m.get("owner_user_email"),
                "agents": [],
            }
        grouped[uid]["agents"].append(m)
        member_agent_ids.add(m.get("agent_id", ""))

    invites = svc.list_invites(room_id, account_id)
    accepted_user_ids: set[str] = set()
    for inv in invites:
        if inv.get("status") != "accepted":
            continue
        uid = str(inv.get("invited_user_id", ""))
        accepted_user_ids.add(uid)
        if uid and uid not in grouped:
            grouped[uid] = {
                "user_id": inv.get("invited_user_id"),
                "user_name": inv.get("user_name"),
                "user_email": inv.get("user_email"),
                "agents": [],
                "invite_accepted": True,
            }

    _backfill_agents_from_entries(
        request, svc, room_id, account_id,
        grouped, member_agent_ids, accepted_user_ids,
    )

    return list(grouped.values())


def _backfill_agents_from_entries(
    request: Request,
    svc: Any,
    room_id: UUID,
    account_id: UUID,
    grouped: dict[str, dict],
    member_agent_ids: set[str],
    accepted_user_ids: set[str],
) -> None:
    """Discover agents that wrote to this entity but aren't in room_memberships yet.

    Uses LEFT JOIN on agents so we can also find agents whose owner_user_id
    was never set (registration failed silently). For those, we attempt to
    resolve the owner from the API key that authenticated the write.
    """
    try:
        room = svc.get_room(room_id, account_id)
        if not room:
            return
        entity_path = room.get("entity_path")
        if not entity_path:
            return

        from . import get_db_pool
        from psycopg.rows import dict_row
        pool = get_db_pool()
        if pool is None:
            return

        with pool.connection() as conn:
            conn.row_factory = dict_row
            conn.execute(
                "SELECT set_config('amfs.current_account_id', %s, false)",
                (str(account_id),),
            )

            rows = conn.execute(
                """SELECT DISTINCT me.agent_id,
                          a.owner_user_id,
                          u.name AS owner_user_name,
                          u.email AS owner_user_email
                   FROM amfs_memory_entries me
                   LEFT JOIN agents a
                       ON a.agent_id = me.agent_id
                       AND a.account_id = me.account_id
                   LEFT JOIN users u ON u.id = a.owner_user_id
                   WHERE me.entity_path = %s
                     AND me.agent_id NOT IN (
                         SELECT rm.agent_id FROM room_memberships rm
                         WHERE rm.room_id = %s AND rm.left_at IS NULL
                     )
                     AND me.agent_id != 'amfs-server'""",
                (entity_path, str(room_id)),
            ).fetchall()

            for row in rows:
                aid = row["agent_id"]
                uid = str(row["owner_user_id"]) if row.get("owner_user_id") else None

                if uid is None:
                    uid = _resolve_agent_owner_from_key(conn, aid, account_id)
                    if uid:
                        _register_agent_with_owner(conn, aid, account_id, uid)

                if uid is None:
                    continue

                if uid not in accepted_user_ids:
                    room_owner = room.get("created_by")
                    if uid != str(room_owner):
                        continue

                if uid not in grouped:
                    grouped[uid] = {
                        "user_id": row["owner_user_id"] or uid,
                        "user_name": row.get("owner_user_name"),
                        "user_email": row.get("owner_user_email"),
                        "agents": [],
                    }

                grouped[uid]["agents"].append({
                    "agent_id": aid,
                    "owner_user_id": row["owner_user_id"] or uid,
                    "role": "member",
                    "joined_at": None,
                    "discovered_from_entries": True,
                })

                conn.execute("SAVEPOINT backfill_membership")
                try:
                    _ensure_membership(conn, room_id, account_id, aid, uid)
                    conn.execute("RELEASE SAVEPOINT backfill_membership")
                except Exception:
                    conn.execute("ROLLBACK TO SAVEPOINT backfill_membership")
                    logger.debug("Membership backfill failed for %s", aid, exc_info=True)

            conn.commit()
    except Exception:
        logger.warning("Failed to backfill agents from entries", exc_info=True)


def _resolve_agent_owner_from_key(
    conn: Any, agent_id: str, account_id: UUID,
) -> str | None:
    """Try to find the owner user_id for an agent that's not in the agents table."""
    try:
        row = conn.execute(
            """SELECT DISTINCT ak.created_by
               FROM api_keys ak
               WHERE ak.account_id = %s
               ORDER BY ak.created_at DESC LIMIT 1""",
            (str(account_id),),
        ).fetchone()
        return str(row["created_by"]) if row else None
    except Exception:
        return None


def _register_agent_with_owner(
    conn: Any, agent_id: str, account_id: UUID, owner_user_id: str,
) -> None:
    """Register an agent in the agents table with its owner_user_id."""
    try:
        conn.execute(
            """INSERT INTO agents (account_id, agent_id, namespace, owner_user_id)
               VALUES (%s, %s, 'default', %s)
               ON CONFLICT (account_id, namespace, agent_id) DO UPDATE
                   SET owner_user_id = COALESCE(agents.owner_user_id, EXCLUDED.owner_user_id),
                       last_seen_at = now()""",
            (str(account_id), agent_id, owner_user_id),
        )
    except Exception:
        logger.debug("Failed to register agent %s with owner", agent_id, exc_info=True)


def _ensure_membership(conn, room_id: UUID, account_id: UUID, agent_id: str, user_id: str) -> None:
    """Create a room_memberships row for a discovered agent if missing."""
    try:
        invite_row = conn.execute(
            """SELECT id, role FROM room_user_invites
               WHERE room_id = %s AND invited_user_id = %s AND status = 'accepted'
               LIMIT 1""",
            (str(room_id), user_id),
        ).fetchone()
        invite_id = invite_row["id"] if invite_row else None
        role = (invite_row["role"] if invite_row else None) or "member"

        import psycopg.types.json
        conn.execute(
            """INSERT INTO room_memberships (room_id, invite_id, agent_id, owner_user_id, role)
               VALUES (%s, %s, %s, %s, %s)
               ON CONFLICT (room_id, agent_id) DO UPDATE SET left_at = NULL, role = EXCLUDED.role""",
            (str(room_id), str(invite_id) if invite_id else None, agent_id, user_id, role),
        )
        conn.execute(
            """INSERT INTO room_activity
                   (room_id, account_id, agent_id, user_id, activity_type, details)
               VALUES (%s, %s, %s, %s, 'agent_joined', %s)""",
            (
                str(room_id), str(account_id), agent_id, user_id,
                psycopg.types.json.Json({"role": role, "backfilled": True}),
            ),
        )
    except Exception:
        logger.debug("Failed to ensure membership for %s", agent_id, exc_info=True)


# ── Activity ──────────────────────────────────────────────────────────

@router.get("/{room_id}/activity", response_model=ActivityPage)
def list_activity(
    room_id: UUID,
    request: Request,
    limit: int = Query(default=50, le=200),
    offset: int = Query(default=0, ge=0),
    activity_type: str | None = Query(default=None),
    since: str | None = Query(default=None),
) -> Any:
    svc = _get_service(request)
    account_id = _get_account_id(request)

    _backfill_missing_activity(svc, room_id, account_id)

    since_dt = None
    if since:
        try:
            since_dt = datetime.fromisoformat(since)
        except ValueError:
            raise HTTPException(status_code=400, detail="Invalid 'since' ISO format")

    items, total = svc.list_activity(
        room_id, account_id,
        limit=limit, offset=offset,
        activity_type=activity_type, since=since_dt,
    )
    return {
        "items": items,
        "total": total,
        "has_more": (offset + limit) < total,
    }


_backfill_done: set[str] = set()


def _backfill_missing_activity(svc: Any, room_id: UUID, account_id: UUID) -> None:
    """One-time backfill: insert room_activity rows for entries not yet logged."""
    cache_key = f"{room_id}:{account_id}"
    if cache_key in _backfill_done:
        return
    _backfill_done.add(cache_key)

    try:
        room = svc.get_room(room_id, account_id)
        if not room:
            return
        entity_path = room.get("entity_path")
        namespace = room.get("namespace", "default")
        if not entity_path:
            return

        from . import get_db_pool
        from psycopg.rows import dict_row
        import psycopg.types.json
        pool = get_db_pool()
        if pool is None:
            return

        with pool.connection() as conn:
            conn.row_factory = dict_row
            conn.execute(
                "SELECT set_config('amfs.current_account_id', %s, false)",
                (str(account_id),),
            )

            rows = conn.execute(
                """SELECT me.key, me.agent_id, me.written_at, me.entity_path
                   FROM amfs_memory_entries me
                   WHERE me.entity_path = %s AND me.namespace = %s
                     AND me.superseded_at IS NULL
                     AND NOT EXISTS (
                         SELECT 1 FROM room_activity ra
                         WHERE ra.room_id = %s
                           AND ra.agent_id = me.agent_id
                           AND ra.activity_type = 'write'
                           AND ra.details->>'key' = me.key
                     )""",
                (entity_path, namespace, str(room_id)),
            ).fetchall()

            for row in rows:
                conn.execute(
                    """INSERT INTO room_activity
                           (room_id, account_id, agent_id, activity_type, details, created_at)
                       VALUES (%s, %s, %s, 'write', %s, %s)""",
                    (
                        str(room_id), str(account_id), row["agent_id"],
                        psycopg.types.json.Json({
                            "key": row["key"],
                            "entity_path": entity_path,
                            "backfilled": True,
                        }),
                        row["written_at"],
                    ),
                )
            conn.commit()
            if rows:
                logger.info(
                    "Backfilled %d missing activity entries for room %s",
                    len(rows), room_id,
                )
    except Exception:
        logger.debug("Failed to backfill missing activity", exc_info=True)


# ── Negotiations ──────────────────────────────────────────────────────

def _get_negotiation_engine(request: Request) -> Any:
    engine = getattr(request.app.state, "negotiation_engine", None)
    if engine is None:
        from . import get_db_pool, get_memory
        from .negotiation import NegotiationEngine
        pool = get_db_pool()
        if pool is None:
            raise HTTPException(status_code=503, detail="Database pool not available")
        engine = NegotiationEngine(pool=pool, get_memory=get_memory)
        request.app.state.negotiation_engine = engine
    return engine


@router.get("/{room_id}/negotiations")
async def list_negotiations(
    room_id: UUID,
    request: Request,
    status: str | None = Query(default=None),
    limit: int = Query(default=50, le=200),
) -> Any:
    account_id = _get_account_id(request)
    engine = _get_negotiation_engine(request)
    sessions = await engine.list_sessions(room_id, status=status, limit=limit, account_id=account_id)

    _enrich_with_participants(request, account_id, sessions)

    return sessions


def _enrich_with_participants(request: Request, account_id: UUID, sessions: list) -> None:
    """Add 'participants' to each session: list of {agent_id, action} dicts."""
    if not sessions:
        return
    try:
        from . import get_db_pool
        from psycopg.rows import dict_row

        pool = get_db_pool()
        if pool is None:
            return

        session_ids = [str(s["id"]) for s in sessions if s.get("id")]
        if not session_ids:
            return

        with pool.connection() as conn:
            conn.row_factory = dict_row
            conn.execute(
                "SELECT set_config('amfs.current_account_id', %s, false)",
                (str(account_id),),
            )
            rows = conn.execute(
                """SELECT session_id, agent_id, action
                   FROM negotiation_rounds
                   WHERE session_id = ANY(%s)
                   ORDER BY round_number ASC""",
                (session_ids,),
            ).fetchall()

        by_session: dict[str, list] = {}
        for r in rows:
            sid = str(r["session_id"])
            by_session.setdefault(sid, []).append({
                "agent_id": r["agent_id"],
                "action": r["action"],
            })

        for s in sessions:
            sid = str(s.get("id", ""))
            s["participants"] = by_session.get(sid, [])
    except Exception:
        logger.debug("Failed to enrich participants", exc_info=True)


@router.post("/{room_id}/negotiations")
async def create_negotiation(room_id: UUID, request: Request) -> Any:
    from .negotiation.models import CreateSessionRequest
    body = await request.json()
    body["room_id"] = str(room_id)
    req = CreateSessionRequest(**body)

    engine = _get_negotiation_engine(request)
    account_id = _get_account_id(request)
    user_id = _get_user_id(request)

    agent_id = body.get("agent_id") or _resolve_user_label(request) or "unknown"
    session = await engine.create_session(
        req, agent_id, account_id, created_by_user_id=user_id,
    )

    try:
        svc = _get_service(request)
        svc.log_activity(
            room_id=room_id, account_id=account_id,
            activity_type="negotiation_started",
            agent_id=agent_id,
            details={"session_id": str(session.get("id")), "title": req.title},
        )

        _auto_post_negotiation_discussion(
            request, svc, room_id, account_id, agent_id, session, req.title,
        )

        _notify_negotiation_started(
            svc, room_id, account_id, request, agent_id,
            session.get("id"), req.title,
        )
    except Exception:
        logger.warning("Post-create side-effects failed for session %s", session.get("id"), exc_info=True)

    return session


def _resolve_user_label(request: Request) -> str | None:
    """Try to resolve a human-readable label from the request's auth context."""
    user = getattr(request.state, "user", None)
    if user:
        return getattr(user, "name", None) or getattr(user, "email", None)
    for hdr in ("x-user-name", "x-user-email", "x-amfs-dashboard-user-id"):
        val = request.headers.get(hdr)
        if val:
            return val
    return None


def _auto_post_negotiation_discussion(
    request: Request, svc: Any,
    room_id: UUID, account_id: UUID, agent_id: str,
    session: dict, title: str,
) -> None:
    """Post an automatic discussion message when a negotiation starts."""
    try:
        room = svc.get_room(room_id, account_id)
        if not room or not room.get("discussions_enabled"):
            return

        from . import get_db_pool
        import json as _json
        from psycopg.rows import dict_row
        pool = get_db_pool()
        if pool is None:
            return

        session_id = session.get("id", "")
        content = (
            f"A new negotiation has been started: **{title}**\n\n"
            f"Session ID: `{session_id}`\n"
            f"All room members are invited to participate. "
            f"Use `amfs_negotiate_propose` or `amfs_negotiate_respond` to submit your position."
        )
        with pool.connection() as conn:
            conn.row_factory = dict_row
            conn.execute(
                "SELECT set_config('amfs.current_account_id', %s, false)",
                (str(account_id),),
            )
            conn.execute(
                """INSERT INTO discussion_messages
                   (room_id, account_id, agent_id, message_type, content, metadata)
                   VALUES (%s, %s, %s, 'system', %s, %s::jsonb)""",
                (
                    str(room_id), str(account_id), agent_id, content,
                    _json.dumps({"negotiation_session_id": str(session_id), "auto_generated": True}),
                ),
            )
            conn.commit()
    except Exception:
        logger.debug("Failed to auto-post negotiation discussion", exc_info=True)


def _notify_negotiation_started(
    svc: Any, room_id: UUID, account_id: UUID,
    request: Request, agent_id: str,
    session_id: Any, title: str,
) -> None:
    """Insert dashboard notifications for all room members when a negotiation starts."""
    try:
        from . import get_db_pool
        from .notifications import notify_room_members, resolve_agent_owner

        pool = get_db_pool()
        if pool is None:
            return

        creator_user_id = getattr(request.state, "user_id", None)
        if not creator_user_id:
            creator_user_id = resolve_agent_owner(pool, account_id, agent_id)

        notify_room_members(
            pool, svc, room_id, account_id,
            exclude_user_id=creator_user_id,
            notification_type="negotiation_started",
            title=f"New negotiation: {title}",
            body=(
                "A negotiation was started in a room you're a member of. "
                "Your agent will be prompted to participate automatically."
            ),
            metadata={"session_id": str(session_id), "room_id": str(room_id)},
        )
    except Exception:
        logger.debug("Failed to notify negotiation started", exc_info=True)


@router.get("/{room_id}/negotiations/{session_id}")
async def get_negotiation(room_id: UUID, session_id: UUID, request: Request) -> Any:
    engine = _get_negotiation_engine(request)
    detail = await engine.get_session_detail(session_id)
    if detail is None:
        raise HTTPException(status_code=404, detail="Negotiation session not found")
    return detail


@router.post("/{room_id}/negotiations/{session_id}/propose")
async def submit_proposal(room_id: UUID, session_id: UUID, request: Request) -> Any:
    from .negotiation.models import SubmitProposalRequest, RoundAction
    body = await request.json()
    req = SubmitProposalRequest(
        session_id=session_id,
        action=RoundAction(body.get("action", "propose")),
        proposal=body.get("proposal", {}),
        rationale=body.get("rationale"),
    )
    agent_id = body.get("agent_id") or _resolve_user_label(request) or "unknown"
    engine = _get_negotiation_engine(request)
    result = await engine.submit_proposal(req, agent_id)

    svc = _get_service(request)
    account_id = _get_account_id(request)
    svc.log_activity(
        room_id=room_id, account_id=account_id,
        activity_type="negotiation_round",
        agent_id=agent_id,
        details={
            "session_id": str(session_id),
            "action": req.action.value,
        },
    )

    _notify_agent_engaged(
        account_id, room_id, session_id, agent_id, req.action.value,
        result.get("session", {}).get("title") or str(session_id),
    )

    return result


def _notify_agent_engaged(
    account_id: UUID, room_id: UUID, session_id: UUID,
    agent_id: str, action: str, title: str,
) -> None:
    """Notify the agent's owner that their agent participated."""
    try:
        from . import get_db_pool
        from .notifications import insert_notification, resolve_agent_owner

        pool = get_db_pool()
        if pool is None:
            return
        owner_id = resolve_agent_owner(pool, account_id, agent_id)
        if not owner_id:
            return

        insert_notification(
            pool, account_id, owner_id,
            notification_type="agent_engaged",
            title=f"Your agent participated in '{title}'",
            body=f"Your agent submitted a {action} in the negotiation.",
            metadata={"session_id": str(session_id), "agent_id": agent_id, "action": action},
            room_id=room_id,
        )
    except Exception:
        logger.debug("Failed to notify agent engagement", exc_info=True)


@router.post("/{room_id}/negotiations/{session_id}/cancel")
async def cancel_negotiation(room_id: UUID, session_id: UUID, request: Request) -> Any:
    body = await request.json()
    engine = _get_negotiation_engine(request)
    account_id = _get_account_id(request)
    cancelled_by = body.get("agent_id") or _resolve_user_label(request) or "unknown"
    reason = body.get("reason")

    try:
        result = await engine.cancel_session(
            session_id, cancelled_by, reason=reason, account_id=account_id,
        )
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

    try:
        svc = _get_service(request)
        svc.log_activity(
            room_id=room_id, account_id=account_id,
            activity_type="negotiation_cancelled",
            agent_id=cancelled_by,
            details={
                "session_id": str(session_id),
                "reason": reason,
            },
        )

        _auto_post_cancel_discussion(
            svc, room_id, account_id, cancelled_by, session_id, reason,
        )

        _notify_negotiation_resolved(
            svc, room_id, account_id, session_id,
            status="cancelled",
            title=result.get("title") or str(session_id),
            summary=f"Cancelled by {cancelled_by}" + (f": {reason}" if reason else ""),
        )
    except Exception:
        logger.warning("Post-cancel side-effects failed for session %s", session_id, exc_info=True)

    return result


def _notify_negotiation_resolved(
    svc: Any, room_id: UUID, account_id: UUID,
    session_id: UUID, status: str, title: str, summary: str,
) -> None:
    """Notify all room members when a negotiation reaches a terminal state."""
    try:
        from . import get_db_pool
        from .notifications import notify_room_members

        pool = get_db_pool()
        if pool is None:
            return

        type_map = {
            "consensus": "negotiation_resolved",
            "failed": "negotiation_failed",
            "cancelled": "negotiation_cancelled",
        }

        notify_room_members(
            pool, svc, room_id, account_id,
            exclude_user_id=None,
            notification_type=type_map.get(status, "negotiation_resolved"),
            title=f"Negotiation '{title}' {status}",
            body=summary,
            metadata={"session_id": str(session_id), "outcome": status},
        )
    except Exception:
        logger.debug("Failed to notify negotiation resolved", exc_info=True)


def _auto_post_cancel_discussion(
    svc: Any, room_id: UUID, account_id: UUID,
    cancelled_by: str, session_id: UUID, reason: str | None,
) -> None:
    """Post a discussion message when a negotiation is cancelled."""
    try:
        room = svc.get_room(room_id, account_id)
        if not room or not room.get("discussions_enabled"):
            return

        from . import get_db_pool
        import json as _json
        from psycopg.rows import dict_row
        pool = get_db_pool()
        if pool is None:
            return

        content = f"Negotiation `{session_id}` has been **cancelled** by {cancelled_by}."
        if reason:
            content += f"\n\nReason: {reason}"
        content += (
            "\n\nAny proposals or positions discussed during this negotiation "
            "should not be treated as agreed decisions."
        )

        with pool.connection() as conn:
            conn.row_factory = dict_row
            conn.execute(
                "SELECT set_config('amfs.current_account_id', %s, false)",
                (str(account_id),),
            )
            conn.execute(
                """INSERT INTO discussion_messages
                   (room_id, account_id, agent_id, message_type, content, metadata)
                   VALUES (%s, %s, %s, 'system', %s, %s::jsonb)""",
                (
                    str(room_id), str(account_id), cancelled_by, content,
                    _json.dumps({
                        "negotiation_session_id": str(session_id),
                        "auto_generated": True,
                        "event": "negotiation_cancelled",
                    }),
                ),
            )
            conn.commit()
    except Exception:
        logger.debug("Failed to auto-post cancellation discussion", exc_info=True)


@router.post("/{room_id}/negotiations/{session_id}/issues")
async def add_issues(room_id: UUID, session_id: UUID, request: Request) -> Any:
    body = await request.json()
    issues = body.get("issues", [])
    engine = _get_negotiation_engine(request)
    return await engine.add_issues(session_id, issues)


# ── Discussions ──────────────────────────────────────────────────────

@router.post("/{room_id}/discussions")
def post_discussion_message(room_id: UUID, request: Request) -> Any:
    import json as _json
    from psycopg.rows import dict_row

    svc = _get_service(request)
    account_id = _get_account_id(request)

    room = svc.get_room(room_id, account_id)
    if room is None:
        raise HTTPException(status_code=404, detail="Room not found")
    if not room.get("discussions_enabled"):
        raise HTTPException(status_code=403, detail="Discussions are not enabled for this room")
    if room["status"] != "open":
        raise HTTPException(status_code=409, detail="Room is closed")

    body = request.state._body if hasattr(request.state, "_body") else None
    if body is None:
        import asyncio
        body = asyncio.get_event_loop().run_until_complete(request.json())
    else:
        body = _json.loads(body)

    agent_id = body.get("agent_id") or _resolve_user_label(request) or "unknown"
    content = body.get("content", "")
    message_type = body.get("message_type", "message")
    reply_to = body.get("reply_to")
    addressed_to = body.get("addressed_to")
    metadata = body.get("metadata", {})

    if not content.strip():
        raise HTTPException(status_code=400, detail="Message content cannot be empty")

    from . import get_db_pool
    pool = get_db_pool()
    with pool.connection() as conn:
        conn.row_factory = dict_row
        conn.execute(
            "SELECT set_config('amfs.current_account_id', %s, false)",
            (str(account_id),),
        )
        row = conn.execute(
            """INSERT INTO discussion_messages
               (room_id, account_id, agent_id, message_type, content,
                reply_to, addressed_to, metadata)
               VALUES (%s, %s, %s, %s, %s, %s, %s, %s::jsonb)
               RETURNING *""",
            (
                str(room_id), str(account_id), agent_id, message_type,
                content, str(reply_to) if reply_to else None,
                addressed_to, _json.dumps(metadata),
            ),
        ).fetchone()
        conn.commit()

    svc.log_activity(
        room_id=room_id, account_id=account_id,
        activity_type="discussion_message",
        agent_id=agent_id,
        details={"message_id": str(row["id"]), "message_type": message_type},
    )

    sse_manager = getattr(request.app.state, "sse_manager", None)
    if sse_manager:
        sse_manager.broadcast_room_event(
            str(room_id), "discussion_message",
            {"agent_id": agent_id, "content": content[:200], "message_type": message_type},
        )

    return dict(row)


@router.get("/{room_id}/discussions")
def list_discussion_messages(
    room_id: UUID,
    request: Request,
    limit: int = Query(default=50, le=200),
    offset: int = Query(default=0, ge=0),
    since: str | None = Query(default=None),
) -> Any:
    import json as _json
    from psycopg.rows import dict_row

    account_id = _get_account_id(request)
    svc = _get_service(request)
    room = svc.get_room(room_id, account_id)
    if room is None:
        raise HTTPException(status_code=404, detail="Room not found")
    if not room.get("discussions_enabled"):
        raise HTTPException(status_code=403, detail="Discussions are not enabled for this room")

    from . import get_db_pool
    pool = get_db_pool()

    params: list[Any] = [str(room_id)]
    where = "WHERE room_id = %s"
    if since:
        try:
            since_dt = datetime.fromisoformat(since)
            where += " AND created_at > %s"
            params.append(since_dt)
        except ValueError:
            raise HTTPException(status_code=400, detail="Invalid 'since' ISO format")

    with pool.connection() as conn:
        conn.row_factory = dict_row
        conn.execute(
            "SELECT set_config('amfs.current_account_id', %s, false)",
            (str(account_id),),
        )
        rows = list(conn.execute(
            f"SELECT * FROM discussion_messages {where} "
            f"ORDER BY created_at DESC LIMIT %s OFFSET %s",
            (*params, limit, offset),
        ).fetchall())
        count_row = conn.execute(
            f"SELECT count(*) FROM discussion_messages {where}", params,
        ).fetchone()
        total = count_row["count"] if count_row else 0

    return {"items": rows, "total": total, "has_more": (offset + limit) < total}


# ── Knowledge Graph ───────────────────────────────────────────────────

_kg_backfill_done: set[str] = set()


@router.get("/{room_id}/knowledge-graph")
def get_knowledge_graph(room_id: UUID, request: Request) -> Any:
    from . import get_db_pool
    from .extraction import RoomExtractionWorker

    account_id = _get_account_id(request)
    pool = get_db_pool()
    if pool is None:
        raise HTTPException(status_code=503, detail="Database pool not available")
    worker = RoomExtractionWorker(pool)

    cache_key = f"{room_id}:{account_id}"
    if cache_key not in _kg_backfill_done:
        if _backfill_knowledge_graph(worker, pool, room_id, account_id, request):
            _kg_backfill_done.add(cache_key)

    return worker.get_graph(room_id, account_id=account_id)


def _backfill_knowledge_graph(
    worker: Any, pool: Any, room_id: UUID, account_id: UUID, request: Request,
) -> bool:
    """Extract concepts from existing entries if the knowledge graph is empty.

    Returns True if backfill succeeded or was unnecessary (graph already populated).
    """
    try:
        from psycopg.rows import dict_row

        existing = worker.get_concepts(room_id, limit=1, account_id=account_id)
        if existing:
            return True

        svc = _get_service(request)
        room = svc.get_room(room_id, account_id)
        if not room:
            return True
        entity_path = room.get("entity_path")
        if not entity_path:
            return True

        with pool.connection() as conn:
            conn.row_factory = dict_row
            conn.execute(
                "SELECT set_config('amfs.current_account_id', %s, false)",
                (str(account_id),),
            )
            entries = conn.execute(
                """SELECT key, value, agent_id FROM amfs_memory_entries
                   WHERE entity_path = %s
                   ORDER BY written_at DESC LIMIT 50""",
                (entity_path,),
            ).fetchall()

        for entry in entries:
            try:
                worker.extract_from_write(
                    room_id=room_id,
                    account_id=account_id,
                    entity_path=entity_path,
                    key=entry["key"],
                    value=str(entry.get("value", "")),
                    agent_id=entry.get("agent_id"),
                )
            except Exception:
                logger.debug("Backfill extraction failed for key=%s", entry["key"])
        return True
    except Exception:
        logger.warning("Knowledge graph backfill failed", exc_info=True)
        return False


@router.get("/{room_id}/concepts")
def list_concepts(
    room_id: UUID,
    request: Request,
    limit: int = Query(default=100, le=500),
) -> Any:
    from . import get_db_pool
    from .extraction import RoomExtractionWorker

    account_id = _get_account_id(request)
    pool = get_db_pool()
    if pool is None:
        raise HTTPException(status_code=503, detail="Database pool not available")
    worker = RoomExtractionWorker(pool)
    return worker.get_concepts(room_id, limit=limit, account_id=account_id)


# ── SSE Stream ────────────────────────────────────────────────────────

@router.get("/{room_id}/stream")
async def room_stream(room_id: UUID, request: Request) -> Any:
    """SSE stream for real-time room events (writes, reads, joins, discussions)."""
    from starlette.responses import StreamingResponse

    sse_manager = getattr(request.app.state, "sse_manager", None)
    if sse_manager is None:
        raise HTTPException(status_code=503, detail="SSE not available")

    async def generate():
        async for event in sse_manager.room_event_generator(str(room_id)):
            yield f"event: {event['event']}\ndata: {event['data']}\n\n"

    return StreamingResponse(
        generate(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",
        },
    )


# ══════════════════════════════════════════════════════════════════════
# Notification routes (mounted at /api/v1/notifications)
# ══════════════════════════════════════════════════════════════════════

notifications_router = APIRouter(prefix="/api/v1/notifications", tags=["notifications"])


@notifications_router.get("")
def list_notifications(
    request: Request,
    limit: int = Query(default=20, le=100),
    offset: int = Query(default=0, ge=0),
) -> Any:
    """List notifications for the current user, newest first."""
    account_id = _get_account_id(request)
    user_id = _get_user_id(request)

    from . import get_db_pool
    from psycopg.rows import dict_row

    pool = get_db_pool()
    if pool is None:
        raise HTTPException(status_code=503, detail="Database pool not available")

    with pool.connection() as conn:
        conn.row_factory = dict_row
        conn.execute(
            "SELECT set_config('amfs.current_account_id', %s, false)",
            (str(account_id),),
        )
        rows = conn.execute(
            """SELECT * FROM user_notifications
               WHERE user_id = %s
               ORDER BY created_at DESC
               LIMIT %s OFFSET %s""",
            (str(user_id), limit, offset),
        ).fetchall()

        count_row = conn.execute(
            "SELECT count(*) FROM user_notifications WHERE user_id = %s",
            (str(user_id),),
        ).fetchone()
        total = count_row["count"] if count_row else 0

    import json as _json

    def _serialize(row: dict) -> dict:
        out = {}
        for k, v in row.items():
            if isinstance(v, UUID):
                out[k] = str(v)
            elif hasattr(v, "isoformat"):
                out[k] = v.isoformat()
            else:
                out[k] = v
        return out

    return {"items": [_serialize(r) for r in rows], "total": total}


@notifications_router.get("/unread-count")
def unread_count(request: Request) -> Any:
    """Return unread notification count for the badge."""
    account_id = _get_account_id(request)
    user_id = _get_user_id(request)

    from . import get_db_pool
    from psycopg.rows import dict_row

    pool = get_db_pool()
    if pool is None:
        return {"count": 0}

    with pool.connection() as conn:
        conn.row_factory = dict_row
        conn.execute(
            "SELECT set_config('amfs.current_account_id', %s, false)",
            (str(account_id),),
        )
        row = conn.execute(
            "SELECT count(*) FROM user_notifications WHERE user_id = %s AND read_at IS NULL",
            (str(user_id),),
        ).fetchone()

    return {"count": row["count"] if row else 0}


@notifications_router.patch("/{notification_id}/read")
def mark_read(notification_id: UUID, request: Request) -> Any:
    """Mark a single notification as read."""
    account_id = _get_account_id(request)
    user_id = _get_user_id(request)

    from . import get_db_pool
    from psycopg.rows import dict_row

    pool = get_db_pool()
    if pool is None:
        raise HTTPException(status_code=503)

    with pool.connection() as conn:
        conn.row_factory = dict_row
        conn.execute(
            "SELECT set_config('amfs.current_account_id', %s, false)",
            (str(account_id),),
        )
        conn.execute(
            "UPDATE user_notifications SET read_at = now() WHERE id = %s AND user_id = %s",
            (str(notification_id), str(user_id)),
        )
        conn.commit()

    return {"ok": True}


@notifications_router.patch("/read-all")
def mark_all_read(request: Request) -> Any:
    """Mark all notifications as read for the current user."""
    account_id = _get_account_id(request)
    user_id = _get_user_id(request)

    from . import get_db_pool
    from psycopg.rows import dict_row

    pool = get_db_pool()
    if pool is None:
        raise HTTPException(status_code=503)

    with pool.connection() as conn:
        conn.row_factory = dict_row
        conn.execute(
            "SELECT set_config('amfs.current_account_id', %s, false)",
            (str(account_id),),
        )
        conn.execute(
            "UPDATE user_notifications SET read_at = now() WHERE user_id = %s AND read_at IS NULL",
            (str(user_id),),
        )
        conn.commit()

    return {"ok": True}
