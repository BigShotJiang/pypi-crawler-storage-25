"""Tier-aware client for the DaaS /v1/account endpoint.

The DaaS API exposes a single source of truth for tier limits at
``GET /v1/account``. This module wraps that endpoint with a typed dataclass
and a short list of helpers used by the backtest engine and the live runner
to fail-fast when a strategy asks for data or streaming channels that exceed
the caller's tier.

Typical usage::

    from auspicium.account import get_tier

    tier = get_tier()
    if "5m" not in tier.allowed_intervals:
        raise ValueError("This strategy needs 5m data — upgrade your tier")
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

from auspicium.connectors.rest import RestConnector


@dataclass
class TierInfo:
    """Flattened tier snapshot from ``GET /v1/account``.

    Fields that are semantically "unrestricted" on the server side
    (e.g. enterprise's ``allowed_symbols``) are represented here as ``None``.
    """

    tier: str                           # "starter" | "pro" | "enterprise"
    max_bars: int                       # per REST request
    max_history_days: int               # how far back
    allowed_intervals: list[str]        # REST intervals
    ws_max_subscriptions: int           # per WS connection
    ws_allowed_intervals: list[str]     # WebSocket intervals
    max_production_bots: int            # 0 = quality/paper only
    allowed_exchanges: list[str]
    allowed_symbols: Optional[list[str]] = None   # None = unrestricted


# Ascending capability. Used by :func:`min_tier_for_interval` to compute the
# minimum tier that allows a given interval, for better error messages.
TIER_ORDER: tuple[str, ...] = ("starter", "pro", "enterprise")


def get_tier() -> TierInfo:
    """Fetch the current API key's tier and limits from ``GET /v1/account``.

    Raises:
        AuthError:       Invalid or missing API key.
        ConnectionError: Gateway unreachable.
    """
    data = RestConnector._request("GET", "/v1/account")
    limits = data.get("limits", {})
    rest = limits.get("rest", {})
    ws = limits.get("websocket", {})
    prod = limits.get("production", {})
    return TierInfo(
        tier=data["tier"],
        max_bars=rest.get("max_bars_per_request", 100),
        max_history_days=rest.get("max_history_days", 7),
        allowed_intervals=list(rest.get("allowed_intervals") or ["1h"]),
        ws_max_subscriptions=ws.get("max_subscriptions_per_connection", 2),
        ws_allowed_intervals=list(ws.get("allowed_intervals") or ["1h"]),
        max_production_bots=prod.get("max_bots", 0),
        allowed_exchanges=list(rest.get("allowed_exchanges") or ["binance"]),
        # None is the wire-level "unrestricted" sentinel; anything else is a list.
        allowed_symbols=(
            None if rest.get("allowed_symbols") is None
            else list(rest.get("allowed_symbols"))
        ),
    )


def min_tier_for_interval(interval: str, kind: str = "rest") -> Optional[str]:
    """Return the lowest tier name whose ``{kind}_allowed_intervals`` includes
    ``interval``, or ``None`` if no tier supports it.

    Requires one extra ``/v1/account`` request per unknown tier level checked.
    Cheap at single-digit calls per session; not a hot-path helper.

    ``kind`` is ``"rest"`` (default) or ``"ws"``.
    """
    # Optimisation: only hit the endpoint once. We know enterprise is the
    # widest envelope, so fetch the current tier and peek at its fields.
    # Callers that need the actual tier ceiling should use a server-side
    # lookup (``GET /v1/account`` for an enterprise key) — that's out of
    # scope for the SDK.
    info = get_tier()
    bucket = info.ws_allowed_intervals if kind == "ws" else info.allowed_intervals
    if interval in bucket:
        return info.tier
    # Caller is already maxed — interval isn't supported anywhere.
    return None
