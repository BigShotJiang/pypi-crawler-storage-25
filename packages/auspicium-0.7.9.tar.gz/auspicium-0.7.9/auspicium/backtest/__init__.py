"""Auspicium backtest module — historical strategy simulation + research sweeps.

Two complementary paths:

1. **Event-driven single backtest** — :func:`run`, :func:`run_sync`,
   :class:`BacktestResult`. Replays historical data through
   ``Strategy.on_data()`` so the same code runs backtest and live.
   Use this to validate production strategies.

2. **Vectorized parameter sweep** — :func:`run_sweep`, :func:`sweep_sync`,
   :class:`SweepResult`. Wraps ``vectorbt`` for fast research workflows:
   supply a ``signal_fn(close, **params) -> (entries, exits)`` and a grid
   of parameter values, get a ranked table of all combinations.

Quick start — single backtest::

    from auspicium.backtest import run_sync
    from my_strategy import BTCMomentum

    result = run_sync(BTCMomentum, symbol="BTC-USDT", start="2024-01-01")
    result.tearsheet()
    result.plot()

Quick start — parameter sweep::

    import numpy as np
    from auspicium.backtest import sweep_sync

    def sma_cross(close, fast, slow):
        f, s = close.rolling(fast).mean(), close.rolling(slow).mean()
        entries = (f > s) & (f.shift(1) <= s.shift(1))
        exits   = (f < s) & (f.shift(1) >= s.shift(1))
        return entries, exits

    result = sweep_sync(
        sma_cross,
        source="binance", symbol="BTC-USDT",
        start="2024-01-01", end="2024-12-31", interval="1h",
        params={"fast": np.arange(5, 50, 5), "slow": np.arange(20, 200, 10)},
    )
    result.best(by="sharpe_ratio", top=5)    # top 5 combos
    result.heatmap("total_return")           # plotly heatmap
    result.to_strategy_config()              # config.yaml for the winner
"""
from auspicium.backtest.engine import BacktestResult, run, run_sync
from auspicium.backtest.polymarket import PolymarketBacktest
from auspicium.backtest.sweep import SweepResult, run_sweep, sweep_sync

__all__ = [
    "run",
    "run_sync",
    "BacktestResult",
    "PolymarketBacktest",
    "run_sweep",
    "sweep_sync",
    "SweepResult",
]
