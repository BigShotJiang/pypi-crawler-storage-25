"""Vectorbt-backed parameter sweeps for research workflows.

The event-driven engine in :mod:`auspicium.backtest.engine` prioritizes
backtest-live parity (same ``Strategy.on_data()`` in both environments).
That is the right default when you are validating production code, but
it is slow for research: running 500 fast/slow SMA combinations means
500 replays of the bar loop.

This module adds a complementary path. Users write a **signal function**
that maps ``(close, **params) -> (entries, exits)`` boolean series, then
call :func:`sweep_sync` with a dict of parameter ranges. Every
combination is stacked into 2-D entry/exit arrays and handed to
``vectorbt.Portfolio.from_signals`` in a single vectorized pass —
orders of magnitude faster for pure parameter exploration.

The result is wrapped in a :class:`SweepResult` that mirrors the shape
of :class:`BacktestResult` (same ``to_dict()`` contract keys) so the
workspace-api and the Vue frontend can render sweep outputs with the
same components used for single backtests.

Typical workflow::

    import numpy as np
    from auspicium.backtest import sweep_sync

    def sma_cross(close, fast, slow):
        f = close.rolling(fast).mean()
        s = close.rolling(slow).mean()
        entries = (f > s) & (f.shift(1) <= s.shift(1))
        exits   = (f < s) & (f.shift(1) >= s.shift(1))
        return entries, exits

    result = sweep_sync(
        sma_cross,
        source="binance",
        symbol="BTC-USDT",
        start="2024-01-01",
        end="2024-12-31",
        interval="1h",
        params={
            "fast": np.arange(5, 50, 5),
            "slow": np.arange(20, 200, 10),
        },
        initial_capital=10_000.0,
    )

    result.best(by="sharpe_ratio", top=5)   # top 5 parameter combos
    result.heatmap("total_return")          # plotly heatmap over (fast, slow)
    result.to_strategy_config()             # emit config.yaml for the winner

Vectorbt is lazy-imported — the SDK itself imports cleanly even if
``auspicium[backtest]`` is not installed. Calling :func:`sweep_sync`
without vectorbt installed raises a clear :class:`ImportError` telling
the user which extra to install.
"""
from __future__ import annotations

import asyncio
import itertools
import logging
from dataclasses import dataclass, field
from typing import Any, Callable, Iterable

import numpy as np
import pandas as pd

log = logging.getLogger(__name__)


def _import_vectorbt():
    """Lazy-import vectorbt. Raises a clear ImportError if missing.

    Extracted into a module-level helper so tests can mock this single
    function instead of patching the import system.
    """
    try:
        import vectorbt as vbt
    except ImportError as exc:
        raise ImportError(
            "vectorbt is not installed. "
            "Run `pip install auspicium[backtest]` to enable parameter sweeps."
        ) from exc
    return vbt


# ------------------------------------------------------------------ #
# SweepResult                                                          #
# ------------------------------------------------------------------ #

@dataclass
class SweepResult:
    """Wrapped output of a vectorbt parameter sweep.

    Attributes:
        params:          List of parameter dicts, one per combination.
        stats:           DataFrame indexed by combination; columns mix
                         parameter values with performance metrics
                         (total_return, sharpe_ratio, max_drawdown,
                         win_rate, total_trades, final_value).
        equity_curves:   DataFrame indexed by time; columns = combination
                         tuples (matches vectorbt Portfolio.value() shape).
        price_series:    The close prices the sweep ran against — useful
                         for plotting.
        source:          Data source ("binance", "polymarket", ...).
        symbol:          Trading pair or condition_id.
        interval:        Bar interval ("1m", "5m", "1h", "1d").
        initial_capital: Starting cash for each combination.
        param_names:     Ordered list of parameter names (drives heatmap
                         axis defaults and strategy_config emission).
    """

    params: list[dict]
    stats: pd.DataFrame
    equity_curves: pd.DataFrame
    price_series: pd.Series
    source: str
    symbol: str
    interval: str
    initial_capital: float
    param_names: list[str] = field(default_factory=list)

    # ------------------------------------------------------------------ #
    # Analysis helpers                                                     #
    # ------------------------------------------------------------------ #

    def best(
        self,
        by: str = "sharpe_ratio",
        top: int = 5,
        ascending: bool = False,
    ) -> list[dict]:
        """Return the top N parameter combinations ranked by a metric.

        Args:
            by:        Metric column name — must exist in ``self.stats``.
            top:       Number of rows to return.
            ascending: ``False`` (default) ranks highest-first. Pass
                       ``True`` when optimizing a metric where lower is
                       better (e.g. ``max_drawdown``).

        Returns:
            List of dicts, each merging the parameter values with the
            metric values for one combination. Length ≤ ``top``.

        Raises:
            KeyError: If ``by`` is not a column in ``self.stats``.
        """
        if by not in self.stats.columns:
            available = sorted(self.stats.columns)
            raise KeyError(
                f"Metric {by!r} not in stats. Available columns: {available}"
            )
        sorted_stats = self.stats.sort_values(by, ascending=ascending)
        top_df = sorted_stats.head(top)
        return top_df.to_dict(orient="records")

    def heatmap(
        self,
        metric: str = "total_return",
        x: str | None = None,
        y: str | None = None,
    ):
        """Build a 2-D plotly heatmap of ``metric`` over two parameters.

        Args:
            metric: Column from ``self.stats`` to plot.
            x:      Parameter name for the x axis (default: first swept).
            y:      Parameter name for the y axis (default: second swept).

        Returns:
            A ``plotly.graph_objects.Figure`` ready to ``.show()``.

        Raises:
            ImportError: If plotly is not installed.
            ValueError:  If fewer than 2 parameters were swept.
        """
        try:
            import plotly.graph_objects as go
        except ImportError as exc:
            raise ImportError(
                "plotly is required for heatmap() — pip install auspicium[backtest]"
            ) from exc

        if len(self.param_names) < 2:
            raise ValueError(
                "heatmap() requires at least 2 swept parameters "
                f"(sweep had {len(self.param_names)})"
            )

        x = x or self.param_names[0]
        y = y or self.param_names[1]
        pivot = self.stats.pivot_table(
            values=metric, index=y, columns=x, aggfunc="mean"
        )
        fig = go.Figure(
            data=go.Heatmap(
                z=pivot.values,
                x=pivot.columns,
                y=pivot.index,
                colorscale="RdYlGn",
                colorbar={"title": metric},
            )
        )
        fig.update_layout(
            title=f"{metric} — {self.symbol} ({self.source})",
            xaxis_title=x,
            yaxis_title=y,
        )
        return fig

    def equity_curves_plot(self, top: int = 5, by: str = "sharpe_ratio"):
        """Overlay the equity curves of the top N parameter combinations."""
        try:
            import plotly.graph_objects as go
        except ImportError as exc:
            raise ImportError(
                "plotly is required for equity_curves_plot()"
            ) from exc

        best = self.best(by=by, top=top)
        fig = go.Figure()
        for item in best:
            combo_key = tuple(item[p] for p in self.param_names)
            label = ", ".join(f"{p}={item[p]}" for p in self.param_names)
            if combo_key in self.equity_curves.columns:
                series = self.equity_curves[combo_key]
                fig.add_trace(
                    go.Scatter(
                        x=series.index, y=series.values, name=label, mode="lines",
                    )
                )
        fig.update_layout(
            title=f"Top {top} equity curves — {self.symbol} ({self.source})",
            xaxis_title="Time",
            yaxis_title="Portfolio value",
        )
        return fig

    def to_strategy_config(
        self, rank: int = 0, by: str = "sharpe_ratio"
    ) -> dict:
        """Emit a config dict for the Nth-ranked parameter combination.

        Args:
            rank: 0 = best, 1 = second best, ...
            by:   Metric to rank by.

        Returns:
            ``{param_name: value}`` — drop into your strategy ``config.yaml``.

        Raises:
            IndexError: If ``rank`` exceeds the number of combinations.
        """
        best = self.best(by=by, top=rank + 1)
        if rank >= len(best):
            raise IndexError(
                f"rank={rank} exceeds available combinations ({len(best)})"
            )
        winning = best[rank]
        return {name: winning[name] for name in self.param_names}

    def to_dict(self) -> dict:
        """Serialize to a JSON-safe dict compatible with the Chart Data Contract.

        Keys:
            type:                "sweep"
            source / symbol / interval / initial_capital:  metadata
            param_names:         ordered list of parameters
            n_combinations:      total combinations run
            stats:               list of per-combination stat dicts
            best_equity_curve:   equity curve of the #1 combination by sharpe,
                                 as ``[{"time": int, "value": float}]``
                                 (Unix seconds, matches BacktestResult shape).
        """
        def _ts(idx) -> int:
            try:
                return int(idx.timestamp())
            except Exception:
                return 0

        best_equity: list[dict] = []
        if len(self.stats) > 0 and len(self.equity_curves.columns) > 0:
            try:
                best_combos = self.best(by="sharpe_ratio", top=1)
            except KeyError:
                best_combos = []
            if best_combos:
                combo_key = tuple(best_combos[0][p] for p in self.param_names)
                if combo_key in self.equity_curves.columns:
                    series = self.equity_curves[combo_key]
                    best_equity = [
                        {"time": _ts(t), "value": round(float(v), 2)}
                        for t, v in series.items()
                    ]

        return {
            "type": "sweep",
            "source": self.source,
            "symbol": self.symbol,
            "interval": self.interval,
            "initial_capital": float(self.initial_capital),
            "param_names": list(self.param_names),
            "n_combinations": int(len(self.params)),
            "stats": self.stats.to_dict(orient="records"),
            "best_equity_curve": best_equity,
        }


# ------------------------------------------------------------------ #
# Sweep runner                                                         #
# ------------------------------------------------------------------ #

async def run_sweep(
    signal_fn: Callable[..., tuple[pd.Series, pd.Series]],
    source: str = "binance",
    symbol: str = "BTC-USDT",
    start: str = "2024-01-01",
    end: str = "2024-12-31",
    interval: str = "1h",
    params: dict[str, Iterable[Any]] | None = None,
    initial_capital: float = 10_000.0,
    fees: float = 0.001,
    slippage: float = 0.0005,
    price_series: pd.Series | None = None,
) -> SweepResult:
    """Run a vectorbt-backed parameter sweep.

    Steps:
        1. Load close prices from DaaS (or use the provided ``price_series``).
        2. Expand ``params`` into the Cartesian product of combinations.
        3. Call ``signal_fn(close, **combo)`` for each combination, collect
           ``(entries, exits)`` into 2-D DataFrames with a MultiIndex column.
        4. Hand off to ``vectorbt.Portfolio.from_signals`` in a single call.
        5. Extract per-combination stats and equity curves.
        6. Wrap in a :class:`SweepResult`.

    Args:
        signal_fn:       Callable with signature ``signal_fn(close, **params)
                         -> (entries, exits)``. Both outputs must be
                         ``pd.Series`` of boolean values, same length as
                         ``close``.
        source:          DaaS source used when ``price_series`` is None.
        symbol:          Symbol or condition_id for DaaS loading.
        start / end:     ISO date strings for the backtest window.
        interval:        Bar interval.
        params:          Dict of ``{param_name: iterable_of_values}``. The
                         Cartesian product is swept.
        initial_capital: Starting cash per combination.
        fees:            Commission rate (e.g. 0.001 = 10 bps per fill).
        slippage:        Slippage rate.
        price_series:    Pre-loaded close prices. When provided, the DaaS
                         load is skipped — useful when you have prepared
                         Polymarket data via ``PolymarketBacktest``.

    Returns:
        :class:`SweepResult`.

    Raises:
        ImportError: If vectorbt is not installed.
        ValueError:  If no parameters were provided or no price data was
                     found for the requested window.
    """
    vbt = _import_vectorbt()

    if not params:
        raise ValueError(
            "Pass at least one parameter to sweep (e.g. params={'fast': [5, 10]})"
        )

    # --- Resolve price series ------------------------------------------------
    if price_series is None:
        from datetime import datetime, timezone

        from auspicium.connectors.rest import RestConnector

        start_dt = datetime.fromisoformat(start).replace(tzinfo=timezone.utc)
        end_dt = datetime.fromisoformat(end).replace(tzinfo=timezone.utc)
        days = max(1, (end_dt - start_dt).days + 1)

        df = RestConnector.ohlcv(
            source, symbol, interval=interval, days=days,
            from_ts=start_dt, to_ts=end_dt,
        )
        if df.empty:
            raise ValueError(
                f"No OHLCV data for {source}/{symbol} between {start} and {end}"
            )
        close = df["close"].copy()
        close.name = symbol
    else:
        close = price_series.copy()
        if close.name is None:
            close.name = symbol

    # --- Cartesian grid ------------------------------------------------------
    param_names = list(params.keys())
    param_values = [list(params[n]) for n in param_names]
    combinations = list(itertools.product(*param_values))
    log.info(
        "Sweep: %d combinations over %s (%d bars)",
        len(combinations), param_names, len(close),
    )

    # --- Call signal_fn for each combination ---------------------------------
    entries_cols: dict[tuple, pd.Series] = {}
    exits_cols: dict[tuple, pd.Series] = {}
    combo_dicts: list[dict] = []
    for combo in combinations:
        combo_dict = dict(zip(param_names, combo))
        combo_dicts.append(combo_dict)
        try:
            entries, exits = signal_fn(close, **combo_dict)
            entries = pd.Series(entries, index=close.index).astype(bool)
            exits = pd.Series(exits, index=close.index).astype(bool)
        except Exception as exc:
            log.warning("signal_fn failed for %s: %s", combo_dict, exc)
            entries = pd.Series(False, index=close.index)
            exits = pd.Series(False, index=close.index)
        entries_cols[combo] = entries
        exits_cols[combo] = exits

    entries_df = pd.DataFrame(entries_cols)
    exits_df = pd.DataFrame(exits_cols)
    entries_df.columns = pd.MultiIndex.from_tuples(combinations, names=param_names)
    exits_df.columns = pd.MultiIndex.from_tuples(combinations, names=param_names)

    # --- Run vectorbt portfolio simulation -----------------------------------
    portfolio = vbt.Portfolio.from_signals(
        close=close,
        entries=entries_df,
        exits=exits_df,
        init_cash=initial_capital,
        fees=fees,
        slippage=slippage,
        freq=interval,
    )

    # --- Extract per-combination stats ---------------------------------------
    stats_records: list[dict] = []
    for combo, combo_dict in zip(combinations, combo_dicts):
        try:
            sub = portfolio[combo] if len(combinations) > 1 else portfolio
            stats_row = _extract_stats(sub, initial_capital)
        except Exception as exc:
            log.warning("stats extraction failed for %s: %s", combo_dict, exc)
            stats_row = _default_stats(initial_capital)
        # Merge parameter values into the same row for easy filtering/heatmap
        stats_row.update(combo_dict)
        stats_records.append(stats_row)

    stats_df = pd.DataFrame(stats_records)

    # --- Extract equity curves -----------------------------------------------
    try:
        equity_curves = portfolio.value()
        if isinstance(equity_curves, pd.Series):
            # Single-combination case — wrap in a DataFrame keyed by combo tuple
            equity_curves = equity_curves.to_frame()
            equity_curves.columns = pd.MultiIndex.from_tuples(
                [combinations[0]], names=param_names
            )
    except Exception as exc:
        log.warning("equity extraction failed: %s", exc)
        equity_curves = pd.DataFrame(index=close.index)

    return SweepResult(
        params=combo_dicts,
        stats=stats_df,
        equity_curves=equity_curves,
        price_series=close,
        source=source,
        symbol=symbol,
        interval=interval,
        initial_capital=float(initial_capital),
        param_names=param_names,
    )


def sweep_sync(
    signal_fn: Callable[..., tuple[pd.Series, pd.Series]],
    **kwargs: Any,
) -> SweepResult:
    """Synchronous wrapper for :func:`run_sweep` — use in Jupyter notebooks.

    Mirrors the :func:`auspicium.backtest.run_sync` naming convention.
    """
    return asyncio.run(run_sweep(signal_fn, **kwargs))


# ------------------------------------------------------------------ #
# Private helpers                                                      #
# ------------------------------------------------------------------ #

def _extract_stats(sub_portfolio, initial_capital: float) -> dict:
    """Pull the headline metrics from a (sub-)vectorbt Portfolio."""
    total_return = float(sub_portfolio.total_return())
    sharpe = float(sub_portfolio.sharpe_ratio())
    max_dd = float(sub_portfolio.max_drawdown())
    final_value = float(sub_portfolio.final_value())
    try:
        trade_count = int(sub_portfolio.trades.count())
    except Exception:
        trade_count = 0
    win_rate = 0.0
    if trade_count > 0:
        try:
            win_rate = float(sub_portfolio.trades.win_rate())
        except Exception:
            win_rate = 0.0

    # vectorbt can emit NaN/inf for degenerate cases — coerce so downstream
    # JSON serialization never blows up the way the state API did in 0.4.1.
    def _finite(x: float, default: float = 0.0) -> float:
        if x is None or not np.isfinite(x):
            return default
        return x

    return {
        "total_return": _finite(total_return),
        "sharpe_ratio": _finite(sharpe),
        "max_drawdown": _finite(max_dd),
        "final_value": _finite(final_value, default=initial_capital),
        "total_trades": trade_count,
        "win_rate": _finite(win_rate),
    }


def _default_stats(initial_capital: float) -> dict:
    return {
        "total_return": 0.0,
        "sharpe_ratio": 0.0,
        "max_drawdown": 0.0,
        "final_value": float(initial_capital),
        "total_trades": 0,
        "win_rate": 0.0,
    }
