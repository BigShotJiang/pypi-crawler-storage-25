"""Binance spot exchange adapter.

Real spot order execution on Binance for ``AUSPICIUM_ENV=production``.
Wraps ``python-binance`` — lazy-imported so the SDK imports cleanly even
when ``auspicium[exchange]`` is not installed.

Credentials (all from environment variables):

    BINANCE_API_KEY     — Binance API key (required)
    BINANCE_API_SECRET  — Binance API secret (required)
    BINANCE_TESTNET     — "true" to target testnet (default: "false")

Symbol convention:
    Quants use dashed symbols in :class:`Order` (e.g. ``BTC-USDT``); this
    adapter normalises to Binance's concatenated form (``BTCUSDT``).

Partial fills:
    Market orders often return multiple partial fills in ``resp["fills"]``.
    :meth:`_resp_to_fill` computes a VWAP across them. Commissions are
    summed as-is — v1 does NOT convert non-stablecoin commission assets.
"""
from __future__ import annotations

import logging
import os
from datetime import datetime, timezone

from auspicium.errors import ExchangeError, OrderRejectedError
from auspicium.exchange.base import BaseExchange
from auspicium.strategy.models import (
    ORDER_TYPE_LIMIT,
    ORDER_TYPE_MARKET,
    ORDER_TYPE_OCO,
    ORDER_TYPE_STOP_LOSS,
    ORDER_TYPE_STOP_LOSS_LIMIT,
    ORDER_TYPE_TAKE_PROFIT,
    ORDER_TYPE_TAKE_PROFIT_LIMIT,
    ORDER_TYPE_TRAILING_STOP,
    Fill,
    Order,
)
from auspicium.strategy.stop_engine import check_trigger, update_trail_mark

log = logging.getLogger("auspicium.exchange.binance")

# Stablecoin quote assets we never try to emergency-sell.
_STABLES = {"USDT", "USDC", "BUSD", "FDUSD", "TUSD", "DAI"}


def _import_binance_client():
    """Lazy-import python-binance symbols.

    Returns ``(Client, BinanceAPIException)``. Extracted into a module-level
    helper so tests can mock this single function rather than the import
    system.

    Raises:
        ExchangeError: If ``python-binance`` is not installed.
    """
    try:
        from binance.client import Client
        from binance.exceptions import BinanceAPIException
    except ImportError as exc:
        raise ExchangeError(
            "python-binance is not installed. "
            "Run `pip install auspicium[exchange]` to enable the Binance adapter."
        ) from exc
    return Client, BinanceAPIException


def _normalize_symbol(market: str) -> str:
    """Convert ``BTC-USDT`` → ``BTCUSDT`` (Binance's on-wire format)."""
    return market.replace("-", "").replace("/", "").upper()


class BinanceExchange(BaseExchange):
    """Real Binance spot exchange adapter."""

    def __init__(self, fill_callback=None) -> None:
        super().__init__(fill_callback=fill_callback)
        self._client = None  # lazy
        self._open_orders: dict[str, Order] = {}  # exchange_id (str) → Order
        # OCO orders are tracked by orderListId, not orderId — Binance returns
        # a different shape, and polling uses /api/v3/orderList to get status.
        self._open_oco: dict[str, Order] = {}  # orderListId → Order
        # TRAILING_STOP is simulated client-side (spot API has no native trail).
        # Held here until triggered, then promoted to a real MARKET order.
        self._trailing_orders: dict[str, Order] = {}
        self._trail_marks: dict[str, float] = {}

    # ------------------------------------------------------------------ #
    # Client bootstrap                                                     #
    # ------------------------------------------------------------------ #

    def _get_client(self):
        if self._client is not None:
            return self._client

        Client, _BinanceAPIException = _import_binance_client()

        api_key = os.environ.get("BINANCE_API_KEY")
        api_secret = os.environ.get("BINANCE_API_SECRET")
        if not api_key or not api_secret:
            raise ExchangeError(
                "BINANCE_API_KEY and BINANCE_API_SECRET must both be set in "
                "the environment to use the Binance exchange adapter."
            )

        testnet = os.environ.get("BINANCE_TESTNET", "false").lower() == "true"
        self._client = Client(api_key, api_secret, testnet=testnet)
        log.info("Binance client initialized (testnet=%s)", testnet)
        return self._client

    # ------------------------------------------------------------------ #
    # BaseExchange interface                                               #
    # ------------------------------------------------------------------ #

    async def submit(self, order: Order) -> str:
        """Submit a spot order.

        MARKET / LIMIT go to the standard endpoint. STOP_LOSS, STOP_LOSS_LIMIT,
        TAKE_PROFIT, TAKE_PROFIT_LIMIT go as their native Binance spot types
        (server-side — they execute even if the bot disconnects). OCO uses
        the /api/v3/order/oco endpoint. TRAILING_STOP is simulated
        client-side because Binance spot has no native trailing stop
        (``TRAILING_STOP_MARKET`` is a futures-only type).
        """
        ot = order.order_type
        if ot == ORDER_TYPE_TRAILING_STOP:
            return self._submit_trailing_stop_local(order)
        if ot == ORDER_TYPE_OCO:
            return await self._submit_oco(order)
        if ot in (
            ORDER_TYPE_STOP_LOSS, ORDER_TYPE_STOP_LOSS_LIMIT,
            ORDER_TYPE_TAKE_PROFIT, ORDER_TYPE_TAKE_PROFIT_LIMIT,
        ):
            return await self._submit_stop(order)
        return await self._submit_plain(order)

    async def _submit_plain(self, order: Order) -> str:
        """Submit a plain MARKET or LIMIT order."""
        client = self._get_client()
        Client, _BinanceAPIException = _import_binance_client()
        symbol = _normalize_symbol(order.market)
        side_str = order.side.upper()

        try:
            if order.order_type == ORDER_TYPE_MARKET:
                if side_str == "BUY":
                    resp = client.order_market_buy(
                        symbol=symbol,
                        quoteOrderQty=order.size * order.price,
                    )
                else:
                    resp = client.order_market_sell(
                        symbol=symbol,
                        quantity=order.size,
                    )
            else:
                resp = client.create_order(
                    symbol=symbol,
                    side=side_str,
                    type=Client.ORDER_TYPE_LIMIT,
                    timeInForce=Client.TIME_IN_FORCE_GTC,
                    quantity=order.size,
                    price=str(order.price),
                )
        except Exception as exc:
            raise OrderRejectedError(
                f"Binance order rejected: {type(exc).__name__}: {exc}"
            ) from exc

        exchange_order_id = str(resp.get("orderId") or order.id)
        if str(resp.get("status", "")).upper() == "FILLED":
            fill = self._resp_to_fill(resp, order)
            log.info(
                "Binance order filled immediately: %s %s %.6f @ %.4f → %s",
                side_str, symbol, fill.size, fill.price, exchange_order_id,
            )
            await self._notify_fill(fill)
            return exchange_order_id

        self._open_orders[exchange_order_id] = order
        log.info(
            "Binance order submitted: %s %s %.6f @ %.4f → %s",
            side_str, symbol, order.size, order.price, exchange_order_id,
        )
        return exchange_order_id

    async def _submit_stop(self, order: Order) -> str:
        """Submit a native STOP_LOSS / TAKE_PROFIT (+ _LIMIT) spot order."""
        client = self._get_client()
        symbol = _normalize_symbol(order.market)
        side_str = order.side.upper()

        params = {
            "symbol": symbol,
            "side": side_str,
            "type": order.order_type,
            "quantity": order.size,
            "stopPrice": str(order.stop_price),
        }
        if "LIMIT" in order.order_type:
            params["price"] = str(order.price)
            params["timeInForce"] = "GTC"

        try:
            resp = client.create_order(**params)
        except Exception as exc:
            raise OrderRejectedError(
                f"Binance {order.order_type} rejected: {type(exc).__name__}: {exc}"
            ) from exc

        exchange_order_id = str(resp.get("orderId") or order.id)
        self._open_orders[exchange_order_id] = order
        log.info(
            "Binance %s submitted: %s %s stop=%.4f → %s",
            order.order_type, side_str, symbol, float(order.stop_price),
            exchange_order_id,
        )
        return exchange_order_id

    async def _submit_oco(self, order: Order) -> str:
        """Submit a native OCO (one-cancels-other) order.

        Binance returns an ``orderListId`` plus two child orders; the list id
        is what we track for polling and cancellation.
        """
        client = self._get_client()
        symbol = _normalize_symbol(order.market)
        side_str = order.side.upper()

        params = {
            "symbol": symbol,
            "side": side_str,
            "quantity": order.size,
            "price": str(order.oco_limit_price),         # take-profit limit leg
            "stopPrice": str(order.oco_stop_price),      # stop trigger
            "stopLimitPrice": str(order.price),           # stop-limit leg price
            "stopLimitTimeInForce": "GTC",
        }

        try:
            # python-binance exposes this as create_oco_order. Older versions
            # used order_oco_sell / order_oco_buy helpers.
            if hasattr(client, "create_oco_order"):
                resp = client.create_oco_order(**params)
            elif side_str == "BUY":
                resp = client.order_oco_buy(**params)
            else:
                resp = client.order_oco_sell(**params)
        except Exception as exc:
            raise OrderRejectedError(
                f"Binance OCO rejected: {type(exc).__name__}: {exc}"
            ) from exc

        list_id = str(resp.get("orderListId") or resp.get("listClientOrderId") or order.id)
        self._open_oco[list_id] = order
        log.info(
            "Binance OCO submitted: %s %s tp=%.4f sl=%.4f → list %s",
            side_str, symbol, float(order.oco_limit_price),
            float(order.oco_stop_price), list_id,
        )
        return list_id

    def _submit_trailing_stop_local(self, order: Order) -> str:
        """Queue a TRAILING_STOP locally — Binance spot has no native type.

        The trail watermark is seeded on the first ``check_pending_orders()``
        call that provides a current price for this market. When the effective
        stop is crossed, a MARKET order is submitted.
        """
        self._trailing_orders[order.id] = order
        log.info(
            "Binance TRAILING_STOP queued locally (spot has no native type): "
            "market=%s size=%.6f trail_pct=%s trail_amt=%s id=%s",
            order.market, order.size, order.trail_percent,
            order.trail_amount, order.id,
        )
        return order.id

    def _resp_to_fill(self, resp: dict, order: Order) -> Fill:
        """Build a Fill from a Binance order response (handles partial fills)."""
        fills_data = resp.get("fills") or []
        if fills_data:
            total_qty = sum(float(f["qty"]) for f in fills_data)
            if total_qty > 0:
                avg_price = (
                    sum(float(f["price"]) * float(f["qty"]) for f in fills_data)
                    / total_qty
                )
            else:
                avg_price = float(resp.get("price") or order.price)
            total_fee = sum(float(f.get("commission", 0.0)) for f in fills_data)
        else:
            avg_price = float(resp.get("price") or order.price)
            total_qty = float(resp.get("executedQty") or order.size)
            total_fee = 0.0

        return Fill(
            order_id=str(resp.get("orderId") or order.id),
            market=order.market,
            side=order.side,
            outcome=order.outcome,
            price=avg_price,
            size=total_qty,
            fee=total_fee,
            timestamp=datetime.now(timezone.utc),
            status="CONFIRMED",
        )

    async def cancel(self, order_id: str) -> bool:
        """Cancel an open order (plain / stop / OCO / locally-queued trailing).

        Looks up the order across every local registry. For OCO, cancels the
        whole list; Binance auto-cancels both legs.
        """
        # Locally-queued trailing stop — just drop it.
        if order_id in self._trailing_orders:
            self._trailing_orders.pop(order_id, None)
            self._trail_marks.pop(order_id, None)
            log.info("Binance: cancelled local trailing stop %s", order_id)
            return True

        # OCO — cancel the whole order list.
        if order_id in self._open_oco:
            order = self._open_oco[order_id]
            symbol = _normalize_symbol(order.market)
            try:
                client = self._get_client()
                # python-binance has cancel_order_list in newer versions.
                if hasattr(client, "cancel_order_list"):
                    client.cancel_order_list(symbol=symbol, orderListId=int(order_id))
                else:
                    # Fallback: signed DELETE to /api/v3/orderList
                    client._delete(
                        "orderList", True,
                        data={"symbol": symbol, "orderListId": int(order_id)},
                    )
            except Exception as exc:
                log.warning("Binance OCO cancel failed for %s: %s", order_id, exc)
                return False
            self._open_oco.pop(order_id, None)
            log.info("Binance OCO cancelled: %s", order_id)
            return True

        order = self._open_orders.get(order_id)
        if order is None:
            return False
        symbol = _normalize_symbol(order.market)
        try:
            client = self._get_client()
            client.cancel_order(symbol=symbol, orderId=int(order_id))
        except Exception as exc:
            log.warning("Binance cancel failed for %s: %s", order_id, exc)
            return False
        self._open_orders.pop(order_id, None)
        log.info("Binance order cancelled: %s", order_id)
        return True

    async def check_pending_orders(
        self, current_prices: dict[str, float]
    ) -> None:
        """Poll order status and drive locally-simulated trailing stops."""
        # First: update trailing-stop watermarks and fire any that triggered.
        await self._check_trailing_stops(current_prices)

        if not self._open_orders and not self._open_oco:
            return
        try:
            client = self._get_client()
        except ExchangeError as exc:
            log.warning("Binance check_pending_orders: %s", exc)
            return

        # Plain / stop / TP orders — poll by orderId.
        for exchange_id, order in list(self._open_orders.items()):
            symbol = _normalize_symbol(order.market)
            try:
                status = client.get_order(symbol=symbol, orderId=int(exchange_id))
            except Exception as exc:
                log.warning(
                    "Binance get_order failed for %s: %s", exchange_id, exc
                )
                continue

            order_status = str(status.get("status", "")).upper()
            if order_status == "FILLED":
                fill = self._resp_to_fill(status, order)
                self._open_orders.pop(exchange_id, None)
                await self._notify_fill(fill)
            elif order_status in ("CANCELED", "CANCELLED", "EXPIRED", "REJECTED"):
                self._open_orders.pop(exchange_id, None)
                log.warning(
                    "Binance order %s terminal state: %s",
                    exchange_id, order_status,
                )

        # OCO orders — poll by orderListId. When the list is ALL_DONE one
        # leg filled and Binance auto-cancelled the other.
        for list_id, order in list(self._open_oco.items()):
            try:
                get_list = getattr(client, "get_order_list", None)
                if get_list is not None:
                    status = get_list(orderListId=int(list_id))
                else:
                    status = client._get(
                        "orderList", True, data={"orderListId": int(list_id)},
                    )
            except Exception as exc:
                log.warning(
                    "Binance get_order_list failed for %s: %s", list_id, exc
                )
                continue

            list_status = str(status.get("listOrderStatus", "")).upper()
            if list_status == "ALL_DONE":
                # Find the leg that actually filled and emit its fill.
                filled_leg = None
                for leg in status.get("orders", []) or []:
                    try:
                        leg_status = client.get_order(
                            symbol=_normalize_symbol(order.market),
                            orderId=int(leg["orderId"]),
                        )
                    except Exception:
                        continue
                    if str(leg_status.get("status", "")).upper() == "FILLED":
                        filled_leg = leg_status
                        break
                if filled_leg is not None:
                    fill = self._resp_to_fill(filled_leg, order)
                    await self._notify_fill(fill)
                self._open_oco.pop(list_id, None)
            elif list_status in ("REJECT", "ALL_CANCELED", "ALL_CANCELLED"):
                self._open_oco.pop(list_id, None)
                log.warning(
                    "Binance OCO list %s terminal state: %s",
                    list_id, list_status,
                )

    async def _check_trailing_stops(
        self, current_prices: dict[str, float]
    ) -> None:
        """Drive locally-simulated trailing stops — seed/update watermarks
        and submit a MARKET order when the trail is breached."""
        triggered: list[str] = []
        for order_id, order in list(self._trailing_orders.items()):
            price = current_prices.get(order.market)
            if price is None:
                continue
            self._trail_marks[order_id] = update_trail_mark(
                order, price, self._trail_marks.get(order_id),
            )
            result = check_trigger(
                order, price, trail_mark=self._trail_marks.get(order_id),
            )
            if result.triggered:
                log.info(
                    "Binance trailing stop triggered for %s at %.4f — "
                    "submitting MARKET", order.market, result.fill_price,
                )
                market_order = Order(
                    market=order.market,
                    side=order.side,
                    outcome=order.outcome,
                    size=order.size,
                    price=result.fill_price,
                    order_type=ORDER_TYPE_MARKET,
                )
                try:
                    await self._submit_plain(market_order)
                except Exception as exc:
                    log.error(
                        "Trailing stop MARKET submit failed for %s: %s",
                        order.id, exc,
                    )
                triggered.append(order_id)
        for oid in triggered:
            self._trailing_orders.pop(oid, None)
            self._trail_marks.pop(oid, None)

    async def get_balance(self) -> float:
        """Return the free USDT balance from the spot account."""
        try:
            client = self._get_client()
            account = client.get_account()
        except Exception as exc:
            log.warning("Binance get_balance failed: %s", exc)
            return 0.0
        for asset in account.get("balances", []) or []:
            if asset.get("asset") == "USDT":
                try:
                    return float(asset.get("free", 0.0))
                except (TypeError, ValueError):
                    return 0.0
        return 0.0

    async def emergency_close_all(self) -> list[Fill]:
        """Cancel all open orders and market-sell all non-stablecoin balances.

        Idempotent; never raises. Errors are logged and the loop continues.
        """
        fills: list[Fill] = []

        # Step 1: cancel every open order we know about.
        for exchange_id in list(self._open_orders.keys()):
            try:
                await self.cancel(exchange_id)
            except Exception as exc:
                log.error("Binance cancel during emergency: %s", exc)

        # Step 2: market-sell every non-stablecoin free balance.
        try:
            client = self._get_client()
            account = client.get_account()
        except Exception as exc:
            log.error("Binance emergency_close_all account fetch failed: %s", exc)
            return fills

        for asset in account.get("balances", []) or []:
            name = asset.get("asset")
            try:
                free = float(asset.get("free", 0.0))
            except (TypeError, ValueError):
                free = 0.0
            if free <= 0 or name in _STABLES or not name:
                continue
            symbol = f"{name}USDT"
            try:
                resp = client.order_market_sell(symbol=symbol, quantity=free)
            except Exception as exc:
                log.error("Binance emergency sell %s failed: %s", symbol, exc)
                continue
            if str(resp.get("status", "")).upper() == "FILLED":
                synthetic_order = Order(
                    market=f"{name}-USDT",
                    side="SELL",
                    size=free,
                    price=0.0,
                    order_type="MARKET",
                )
                fill = self._resp_to_fill(resp, synthetic_order)
                fills.append(fill)
                await self._notify_fill(fill)

        # After successful close, drop internal state so a second call is a no-op.
        self._positions.clear()
        self._open_orders.clear()
        self._open_oco.clear()
        self._trailing_orders.clear()
        self._trail_marks.clear()
        return fills