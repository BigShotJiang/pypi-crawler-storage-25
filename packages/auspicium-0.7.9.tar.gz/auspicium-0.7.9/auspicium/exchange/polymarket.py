"""Polymarket CLOB exchange adapter.

Real order execution on Polymarket for ``AUSPICIUM_ENV=production``. Wraps
``py-clob-client`` — lazy-imported so the SDK itself imports cleanly even
when ``auspicium[exchange]`` is not installed.

Credentials (all from environment variables — never hard-coded):

    POLYMARKET_PRIVATE_KEY     — Ethereum private key for signing orders (required)
    POLYMARKET_FUNDER_ADDRESS  — Proxy/funder address that holds the USDC (optional)
    POLYMARKET_SIGNATURE_TYPE  — 0 (EOA/MetaMask) or 1 (email/Magic, default)
    POLYMARKET_API_KEY         — CLOB API key (optional — derived if absent)
    POLYMARKET_API_SECRET      — CLOB API secret
    POLYMARKET_API_PASSPHRASE  — CLOB API passphrase
    POLYMARKET_HOST            — CLOB host (default: https://clob.polymarket.com)
    POLYMARKET_CHAIN_ID        — Polygon chain id (default: 137)

Order semantics:
    ``order.market`` is treated as the CLOB **token_id** directly (YES or NO
    token). Quants resolve token_ids via :meth:`Strategy.find_active_market`
    or from the tick payload. No condition_id → token_id resolution happens
    on the hot path.

Fill model:
    v1 uses REST polling — ``check_pending_orders()`` polls ``get_order(id)``
    for each open order on every tick. A future 0.4.x can add WebSocket order
    streaming for lower-latency fills.
"""
from __future__ import annotations

import logging
import os
from datetime import datetime, timezone

from auspicium.errors import ExchangeError, OrderRejectedError
from auspicium.exchange.base import BaseExchange
from auspicium.strategy.models import Fill, Order

log = logging.getLogger("auspicium.exchange.polymarket")


def _import_clob_client():
    """Lazy-import py-clob-client symbols.

    Returns a tuple of
    ``(ClobClient, ApiCreds, OrderArgs, MarketOrderArgs, OrderType, BUY, SELL)``.

    Extracted into a module-level helper so tests can mock this single
    function instead of patching the import system.

    Raises:
        ExchangeError: If ``py-clob-client`` is not installed.
    """
    try:
        from py_clob_client.client import ClobClient
        from py_clob_client.clob_types import (
            ApiCreds,
            MarketOrderArgs,
            OrderArgs,
            OrderType,
        )
        from py_clob_client.order_builder.constants import BUY, SELL
    except ImportError as exc:
        raise ExchangeError(
            "py-clob-client is not installed. "
            "Run `pip install auspicium[exchange]` to enable the Polymarket adapter."
        ) from exc
    return ClobClient, ApiCreds, OrderArgs, MarketOrderArgs, OrderType, BUY, SELL


class PolymarketExchange(BaseExchange):
    """Real Polymarket CLOB exchange adapter."""

    def __init__(self, fill_callback=None) -> None:
        super().__init__(fill_callback=fill_callback)
        self._client = None  # lazy
        self._open_orders: dict[str, Order] = {}  # exchange_id → Order
        # (condition_id, outcome_upper) → CLOB token_id — populated on first lookup
        self._token_cache: dict[tuple[str, str], str] = {}

    # ------------------------------------------------------------------ #
    # Client bootstrap                                                     #
    # ------------------------------------------------------------------ #

    def _get_client(self):
        """Lazily initialize the ClobClient with credentials from env vars."""
        if self._client is not None:
            return self._client

        (
            ClobClient,
            ApiCreds,
            _OrderArgs,
            _MarketOrderArgs,
            _OrderType,
            _BUY,
            _SELL,
        ) = _import_clob_client()

        private_key = os.environ.get("POLYMARKET_PRIVATE_KEY")
        if not private_key:
            raise ExchangeError(
                "POLYMARKET_PRIVATE_KEY is not set. Export your private key "
                "from reveal.polymarket.com and set it in the environment."
            )

        host = os.environ.get("POLYMARKET_HOST", "https://clob.polymarket.com")
        chain_id = int(os.environ.get("POLYMARKET_CHAIN_ID", "137"))
        sig_type = int(os.environ.get("POLYMARKET_SIGNATURE_TYPE", "1"))
        funder = os.environ.get("POLYMARKET_FUNDER_ADDRESS") or None

        client = ClobClient(
            host,
            key=private_key,
            chain_id=chain_id,
            signature_type=sig_type,
            funder=funder,
        )

        api_key = os.environ.get("POLYMARKET_API_KEY")
        if api_key:
            client.set_api_creds(
                ApiCreds(
                    api_key=api_key,
                    api_secret=os.environ.get("POLYMARKET_API_SECRET", ""),
                    api_passphrase=os.environ.get("POLYMARKET_API_PASSPHRASE", ""),
                )
            )
        else:
            client.set_api_creds(client.create_or_derive_api_creds())

        self._client = client
        # Note: log chain_id + sig_type only — never the private key.
        log.info(
            "Polymarket CLOB client initialized (host=%s chain_id=%d sig_type=%d)",
            host, chain_id, sig_type,
        )
        return self._client

    # ------------------------------------------------------------------ #
    # Token id resolution                                                  #
    # ------------------------------------------------------------------ #

    def _looks_like_token_id(self, market: str) -> bool:
        """Token_ids are big decimal integers; condition_ids are 0x-hex."""
        return market.isdigit() and len(market) >= 20

    def _resolve_token_id(self, market: str, outcome: str) -> str:
        """Resolve ``(condition_id, outcome)`` to a CLOB token_id.

        Accepts either:
          * a raw CLOB token_id (returned unchanged), or
          * a Polymarket condition_id (resolved via ``client.get_market``
            and cached per ``(condition_id, outcome)`` pair).

        This lets the same strategy code run byte-identical in quality
        (paper fills don't need a real token_id) and production (real
        orders require the exact CLOB token_id for the YES or NO side).

        Raises:
            OrderRejectedError: If the market lookup fails or the requested
                outcome does not exist on this market.
        """
        if self._looks_like_token_id(market):
            return market

        cache_key = (market, outcome.upper())
        cached = self._token_cache.get(cache_key)
        if cached is not None:
            return cached

        try:
            client = self._get_client()
            info = client.get_market(market) or {}
        except Exception as exc:
            raise OrderRejectedError(
                f"Polymarket: cannot resolve token_id for {market}: "
                f"{type(exc).__name__}: {exc}"
            ) from exc

        # `info["tokens"]` is a list of {"token_id": "...", "outcome": "Yes"|"No"}
        for token in info.get("tokens", []) or []:
            token_outcome = str(token.get("outcome", "")).upper()
            if token_outcome == outcome.upper():
                tid = str(token.get("token_id") or "")
                if not tid:
                    break
                self._token_cache[cache_key] = tid
                log.info(
                    "Polymarket: resolved %s/%s → token_id %s",
                    market, outcome.upper(), tid,
                )
                return tid

        raise OrderRejectedError(
            f"Polymarket: outcome {outcome!r} not found for condition {market}"
        )

    # ------------------------------------------------------------------ #
    # BaseExchange interface                                               #
    # ------------------------------------------------------------------ #

    async def submit(self, order: Order) -> str:
        """Submit a LIMIT (GTC) or MARKET (FOK) order to Polymarket CLOB.

        ``order.market`` is the CLOB token_id (YES or NO).

        Conditional orders (STOP_LOSS / TAKE_PROFIT / TRAILING_STOP / OCO and
        their _LIMIT variants) are NOT supported on Polymarket in this SDK
        version — the CLOB has no native stop order type and client-side
        simulation is not implemented for the live Polymarket adapter.
        """
        ot = order.order_type.upper()
        if ot not in ("MARKET", "LIMIT"):
            raise OrderRejectedError(
                f"Polymarket adapter does not support {ot} orders. "
                f"Use MARKET/LIMIT on Polymarket; stop / take-profit / OCO / "
                f"trailing-stop are only available on Binance and in paper/backtest."
            )
        client = self._get_client()
        (
            _ClobClient,
            _ApiCreds,
            OrderArgs,
            MarketOrderArgs,
            OrderType,
            BUY,
            SELL,
        ) = _import_clob_client()

        side = BUY if order.side.upper() == "BUY" else SELL
        # Resolve condition_id → token_id (or pass token_id through). This is
        # the one indirection that lets the same strategy code run in both
        # quality and production without caring which id the runner received.
        token_id = self._resolve_token_id(order.market, order.outcome)

        try:
            if order.order_type.upper() == "MARKET":
                mo = MarketOrderArgs(
                    token_id=token_id,
                    amount=order.size * order.price,  # USDC notional
                    side=side,
                )
                signed = client.create_market_order(mo)
                resp = client.post_order(signed, OrderType.FOK)
            else:
                args = OrderArgs(
                    token_id=token_id,
                    price=order.price,
                    size=order.size,
                    side=side,
                )
                signed = client.create_order(args)
                resp = client.post_order(signed, OrderType.GTC)
        except Exception as exc:
            # Never include signed payloads in the message.
            raise OrderRejectedError(
                f"Polymarket order rejected: {type(exc).__name__}: {exc}"
            ) from exc

        exchange_order_id = str(
            resp.get("orderID") or resp.get("id") or order.id
        )
        self._open_orders[exchange_order_id] = order
        log.info(
            "Polymarket order submitted: %s size=%.4f price=%.4f → %s",
            order.side, order.size, order.price, exchange_order_id,
        )
        return exchange_order_id

    async def cancel(self, order_id: str) -> bool:
        """Cancel an open order on Polymarket CLOB."""
        try:
            client = self._get_client()
            client.cancel(order_id)
        except Exception as exc:
            log.warning("Polymarket cancel failed for %s: %s", order_id, exc)
            return False
        self._open_orders.pop(order_id, None)
        log.info("Polymarket order cancelled: %s", order_id)
        return True

    async def check_pending_orders(
        self, current_prices: dict[str, float]
    ) -> None:
        """Poll each open order's status and emit fills for matched orders.

        ``current_prices`` is ignored — we trust the exchange's own state.
        """
        if not self._open_orders:
            return
        try:
            client = self._get_client()
        except ExchangeError as exc:
            log.warning("Polymarket check_pending_orders: %s", exc)
            return

        for exchange_id, order in list(self._open_orders.items()):
            try:
                status = client.get_order(exchange_id) or {}
            except Exception as exc:
                log.warning(
                    "Polymarket get_order failed for %s: %s", exchange_id, exc
                )
                continue

            order_status = str(status.get("status", "")).upper()

            if order_status in ("MATCHED", "CONFIRMED"):
                fill_price = float(status.get("price", order.price))
                fill_size = float(status.get("size_matched", order.size))
                fee = float(status.get("fee", 0.0))
                fill = Fill(
                    order_id=exchange_id,
                    market=order.market,
                    side=order.side,
                    outcome=order.outcome,
                    price=fill_price,
                    size=fill_size,
                    fee=fee,
                    timestamp=datetime.now(timezone.utc),
                    status="CONFIRMED",
                )
                self._open_orders.pop(exchange_id, None)
                await self._notify_fill(fill)

            elif order_status in ("CANCELLED", "CANCELED", "EXPIRED", "FAILED"):
                self._open_orders.pop(exchange_id, None)
                log.warning(
                    "Polymarket order %s terminal state: %s",
                    exchange_id, order_status,
                )

    async def get_balance(self) -> float:
        """Return the USDC balance available for trading.

        v1 returns 0.0 — portfolio tracking is authoritative from fills, and
        Polymarket balances are on-chain (Polygon USDC). A future 0.4.x may
        add a web3 balance query here.
        """
        return 0.0

    async def emergency_close_all(self) -> list[Fill]:
        """Cancel all open orders and market-sell all positions.

        Safety net — not an optimization. Submits FOK sells at price=0.01
        (the minimum valid Polymarket price). Caveat: in thin liquidity the
        FOK at 0.01 may not fill; a future version could use best-bid minus
        slippage instead. Must be idempotent and never raise.
        """
        fills: list[Fill] = []

        # Step 1: cancel everything we know about.
        try:
            client = self._get_client()
            try:
                client.cancel_all()
                log.info("Polymarket: cancel_all() succeeded")
            except Exception as exc:
                log.error("Polymarket cancel_all failed: %s", exc)
        except ExchangeError as exc:
            log.error("Polymarket emergency_close_all: %s", exc)
            # Without a client we can't close positions either.
            self._open_orders.clear()
            self._positions.clear()
            return fills

        self._open_orders.clear()

        # Step 2: market-sell every open position.
        for market, position in list(self._positions.items()):
            if position.size <= 0:
                continue
            try:
                close_order = Order(
                    market=market,
                    side="SELL",
                    outcome=position.outcome,
                    size=position.size,
                    price=0.01,  # minimum valid Polymarket price — safety net
                    order_type="MARKET",
                )
                await self.submit(close_order)
                # submit() won't emit a fill directly — the next
                # check_pending_orders tick will. We don't await that here.
            except Exception as exc:
                log.error(
                    "Polymarket emergency close failed for %s: %s", market, exc
                )

        self._positions.clear()
        return fills