"""Lightweight rolling indicators for online strategy code.

Pure Python — no NumPy dependency, so strategies run in lean containers.
All classes are O(1) per ``push()`` and use Welford-style sliding updates
for numerical stability across long-running streams.

The motivating bug: users translate notebooks (``pandas.rolling(N).std()``,
default ``ddof=1``) into strategies and hand-roll the incremental version
with ``ddof=0`` (population stdev). The ~2.6% drift on N=20 windows
flips threshold checks across signal boundaries, so the live bot trades
nothing while the notebook reported plenty of signals.

Usage::

    from auspicium.indicators import RollingMean, RollingStdev

    class MyStrategy(Strategy):
        def configure(self):
            self._sma  = RollingMean(window=50)
            self._rvol = RollingStdev(window=20)   # ddof=1, matches pandas

        async def on_data(self, tick):
            close = tick.payload["close"]
            self._sma.push(close)
            self._rvol.push(math.log(close / self._prev) if self._prev else 0.0)
            if not self._rvol.ready:
                return    # warmup
            sma  = self._sma.value
            rvol = self._rvol.value
            ...
"""
from __future__ import annotations

import math
from collections import deque


class RollingMean:
    """O(1) rolling arithmetic mean over the last ``window`` samples.

    ``value`` returns ``None`` until ``window`` samples have been pushed.
    Matches ``pandas.Series.rolling(window).mean()`` once warm.
    """

    __slots__ = ("window", "_buf", "_sum")

    def __init__(self, window: int) -> None:
        if window < 1:
            raise ValueError(f"window must be >= 1, got {window}")
        self.window = int(window)
        self._buf: deque[float] = deque(maxlen=self.window)
        self._sum: float = 0.0

    def push(self, x: float) -> None:
        x = float(x)
        # When the deque is at maxlen, ``append`` evicts the oldest element.
        # We must subtract that element from the running sum *before* the
        # eviction happens, so we capture it first.
        if len(self._buf) == self.window:
            self._sum -= self._buf[0]
        self._buf.append(x)
        self._sum += x

    @property
    def value(self) -> float | None:
        if len(self._buf) < self.window:
            return None
        return self._sum / self.window

    @property
    def ready(self) -> bool:
        return len(self._buf) >= self.window

    def __len__(self) -> int:
        return len(self._buf)

    def reset(self) -> None:
        self._buf.clear()
        self._sum = 0.0


class RollingStdev:
    """O(1) rolling sample/population standard deviation.

    ``ddof=1`` (default) matches ``pandas.Series.rolling(window).std()``
    — the sample standard deviation. Use ``ddof=0`` for population stdev.

    Implementation: classical Welford with eviction on the oldest sample.
    For typical strategy windows (≤ 10,000) numerical drift stays below
    1e-9 after thousands of pushes — adequate for parity with pandas.
    """

    __slots__ = ("window", "ddof", "_buf", "_n", "_mean", "_m2")

    def __init__(self, window: int, ddof: int = 1) -> None:
        if window < 2:
            raise ValueError(f"window must be >= 2 for stdev, got {window}")
        if ddof < 0 or ddof >= window:
            raise ValueError(
                f"ddof must be in [0, {window - 1}] for window={window}, got {ddof}"
            )
        self.window = int(window)
        self.ddof = int(ddof)
        self._buf: deque[float] = deque()
        self._n: int = 0
        self._mean: float = 0.0
        self._m2: float = 0.0   # sum of squared deviations from the running mean

    def push(self, x: float) -> None:
        x = float(x)
        # Sliding eviction: when the buffer is full, remove the oldest sample
        # using the inverse Welford update before adding the new one.
        if len(self._buf) >= self.window:
            old = self._buf.popleft()
            self._n -= 1
            if self._n > 0:
                delta = old - self._mean
                self._mean -= delta / self._n
                self._m2 -= delta * (old - self._mean)
            else:
                self._mean = 0.0
                self._m2 = 0.0
        # Standard Welford update for the incoming sample.
        self._buf.append(x)
        self._n += 1
        delta = x - self._mean
        self._mean += delta / self._n
        self._m2 += delta * (x - self._mean)

    @property
    def value(self) -> float | None:
        if self._n < self.window:
            return None
        denom = self._n - self.ddof
        if denom <= 0:
            return None
        # Floating-point drift can push m2 negative by tiny amounts; clamp.
        m2 = self._m2 if self._m2 > 0 else 0.0
        return math.sqrt(m2 / denom)

    @property
    def ready(self) -> bool:
        return self._n >= self.window

    def __len__(self) -> int:
        return self._n

    def reset(self) -> None:
        self._buf.clear()
        self._n = 0
        self._mean = 0.0
        self._m2 = 0.0


__all__ = ["RollingMean", "RollingStdev"]
