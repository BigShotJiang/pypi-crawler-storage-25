"""Strategy framework data models.

Separate from auspicium/models.py (DaaS data models).
These models represent trading primitives: orders, fills, positions, portfolio.
"""
from __future__ import annotations

import uuid
from datetime import datetime, timezone
from typing import Any

from pydantic import BaseModel, model_validator

# Canonical order-type identifiers. Strings (not Enum) to keep the wire
# format stable and to avoid import-order issues in user code.
ORDER_TYPE_MARKET = "MARKET"
ORDER_TYPE_LIMIT = "LIMIT"
ORDER_TYPE_STOP_LOSS = "STOP_LOSS"
ORDER_TYPE_STOP_LOSS_LIMIT = "STOP_LOSS_LIMIT"
ORDER_TYPE_TAKE_PROFIT = "TAKE_PROFIT"
ORDER_TYPE_TAKE_PROFIT_LIMIT = "TAKE_PROFIT_LIMIT"
ORDER_TYPE_TRAILING_STOP = "TRAILING_STOP"
ORDER_TYPE_OCO = "OCO"

_VALID_ORDER_TYPES = frozenset({
    ORDER_TYPE_MARKET, ORDER_TYPE_LIMIT,
    ORDER_TYPE_STOP_LOSS, ORDER_TYPE_STOP_LOSS_LIMIT,
    ORDER_TYPE_TAKE_PROFIT, ORDER_TYPE_TAKE_PROFIT_LIMIT,
    ORDER_TYPE_TRAILING_STOP, ORDER_TYPE_OCO,
})

# Order types that require a stop_price trigger.
_STOP_TRIGGER_TYPES = frozenset({
    ORDER_TYPE_STOP_LOSS, ORDER_TYPE_STOP_LOSS_LIMIT,
    ORDER_TYPE_TAKE_PROFIT, ORDER_TYPE_TAKE_PROFIT_LIMIT,
})


class Order(BaseModel):
    """An order to submit to the exchange (paper or real)."""

    market: str                 # condition_id (Polymarket) or symbol (Binance, e.g. BTC-USDT)
    side: str                   # "BUY" or "SELL"
    outcome: str = "YES"        # "YES" or "NO" (Polymarket only, ignored for Binance)
    size: float                 # Number of shares/units
    price: float                # Limit price (used for LIMIT and *_LIMIT types; ignored for pure MARKET/stop-market)
    order_type: str = "LIMIT"   # see ORDER_TYPE_* constants
    id: str = ""                # Auto-generated if empty

    # Stop / conditional fields — None for plain LIMIT/MARKET orders.
    stop_price: float | None = None      # trigger price for STOP_LOSS/TAKE_PROFIT (+_LIMIT)
    trail_percent: float | None = None   # e.g. 0.02 = 2% trailing distance
    trail_amount: float | None = None    # absolute trailing distance in quote currency

    # OCO (one-cancels-other) fields — bracket a position with TP + SL.
    oco_stop_price: float | None = None   # stop-loss trigger
    oco_limit_price: float | None = None  # take-profit limit price

    @model_validator(mode="after")
    def _generate_id(self) -> Order:
        if not self.id:
            self.id = uuid.uuid4().hex[:12]
        return self

    # ------------------------------------------------------------------ #
    # Construction helpers                                                 #
    # ------------------------------------------------------------------ #

    @classmethod
    def binary_buy(
        cls,
        *,
        market: str,
        outcome: str,                         # "YES" | "NO"
        stake_usd: float,                     # how many dollars to deploy
        yes_price: float,                     # current YES price (0..1)
        order_type: str = "MARKET",           # MARKET | LIMIT
        id: str | None = None,                # auto-generated if missing
        reason: str = "entry_signal",         # used in auto-generated id
    ) -> Order:
        """Construct a binary-market BUY order, sizing in DOLLARS.

        Eliminates two compounding bugs users hit when constructing binary
        orders by hand:

        **A — size in USD vs shares.** ``Order.size`` is shares, not USD.
        ``Order(size=1000, price=0.40)`` is 1000 shares costing $400 to
        enter, not a $1000 stake — so backtest PnL diverges from notebook
        PnL by a factor of ``1/price``. ``binary_buy`` accepts the dollar
        stake and computes shares from ``stake_usd / entry_price``.

        **B — NO-direction LIMIT BUYs never fill.** For a NO trade,
        entry price = ``1 - yes_price``. A naive
        ``Order(side='BUY', outcome='NO', price=1-yes_price, order_type='LIMIT')``
        never fills in cross-market backtest harnesses where the
        exchange's ``current_bar_close`` is set to ``yes_price``: a LIMIT
        BUY fills when ``current_bar_close <= limit_price``, but
        ``yes_price > 1 - yes_price`` whenever ``yes_price > 0.5``. So
        the BUY hangs forever despite signals firing on both sides.
        ``binary_buy`` defaults ``order_type='MARKET'`` to dodge that
        trap; pass ``order_type='LIMIT'`` only if you understand the
        cross-market quirk.

        Computes:
          ``entry_price = yes_price if outcome == 'YES' else (1 - yes_price)``
          ``size (shares) = stake_usd / entry_price``

        Validates: ``0 < yes_price < 1``, ``stake_usd > 0``,
        ``outcome in {'YES', 'NO'}``. Raises :class:`ValueError` on bad
        input rather than silently producing a bogus order.

        Example::

            order = Order.binary_buy(
                market=condition_id,
                outcome="NO",
                stake_usd=100.0,
                yes_price=0.6,            # NO entry @ 0.4
            )
            # → size=250.0 shares, price=0.4, order_type='MARKET'
        """
        try:
            yes_price_f = float(yes_price)
        except (TypeError, ValueError) as exc:
            raise ValueError(f"yes_price must be a float in (0, 1), got {yes_price!r}") from exc
        if not (0.0 < yes_price_f < 1.0):
            raise ValueError(f"yes_price must be in (0, 1), got {yes_price_f}")
        try:
            stake = float(stake_usd)
        except (TypeError, ValueError) as exc:
            raise ValueError(f"stake_usd must be numeric, got {stake_usd!r}") from exc
        if stake <= 0.0:
            raise ValueError(f"stake_usd must be positive, got {stake}")
        outcome_upper = outcome.upper() if isinstance(outcome, str) else ""
        if outcome_upper not in ("YES", "NO"):
            raise ValueError(f"outcome must be 'YES' or 'NO', got {outcome!r}")

        entry_price = yes_price_f if outcome_upper == "YES" else (1.0 - yes_price_f)
        share_size = stake / entry_price

        order_id = id if id else f"{reason}:{uuid.uuid4().hex[:8]}"
        return cls(
            id=order_id,
            market=market,
            side="BUY",
            outcome=outcome_upper,
            size=share_size,
            price=entry_price,
            order_type=order_type,
        )

    @model_validator(mode="after")
    def _validate_order_type(self) -> Order:
        ot = self.order_type.upper()
        if ot not in _VALID_ORDER_TYPES:
            raise ValueError(
                f"Invalid order_type {self.order_type!r}. "
                f"Expected one of: {sorted(_VALID_ORDER_TYPES)}"
            )
        # Normalise case so downstream code can do string comparison without .upper()
        object.__setattr__(self, "order_type", ot)

        if ot in _STOP_TRIGGER_TYPES and self.stop_price is None:
            raise ValueError(f"{ot} requires stop_price")
        if ot == ORDER_TYPE_TRAILING_STOP and self.trail_percent is None and self.trail_amount is None:
            raise ValueError("TRAILING_STOP requires trail_percent or trail_amount")
        if ot == ORDER_TYPE_OCO:
            if self.oco_stop_price is None or self.oco_limit_price is None:
                raise ValueError("OCO requires both oco_stop_price and oco_limit_price")
        return self

    @property
    def is_conditional(self) -> bool:
        """True for any order whose submission is gated on a trigger price."""
        return self.order_type in _STOP_TRIGGER_TYPES or self.order_type in {
            ORDER_TYPE_TRAILING_STOP, ORDER_TYPE_OCO,
        }


class Fill(BaseModel):
    """A completed order fill (from paper or real exchange)."""

    order_id: str
    market: str
    side: str
    outcome: str
    price: float
    size: float
    fee: float = 0.0
    timestamp: datetime
    status: str = "CONFIRMED"   # "MATCHED" | "CONFIRMED" | "FAILED"

    @classmethod
    def now(cls, **kwargs: Any) -> Fill:
        """Convenience constructor that sets timestamp to now (UTC)."""
        return cls(timestamp=datetime.now(timezone.utc), **kwargs)


class Position(BaseModel):
    """A current position in a market."""

    market: str
    side: str                   # "LONG" or "SHORT"
    outcome: str = "YES"        # Polymarket outcome ("YES" / "NO")
    size: float
    entry_price: float
    current_price: float = 0.0
    unrealized_pnl: float = 0.0

    def update_price(self, price: float) -> None:
        """Update current_price and recompute unrealized PnL."""
        self.current_price = price
        direction = 1.0 if self.side == "LONG" else -1.0
        self.unrealized_pnl = direction * self.size * (price - self.entry_price)


class Portfolio(BaseModel):
    """Full portfolio state."""

    cash: float
    positions: dict[str, Position] = {}   # keyed by market (condition_id or symbol)
    total_value: float = 0.0
    realized_pnl: float = 0.0
    unrealized_pnl: float = 0.0
    daily_pnl: float = 0.0

    def recompute(self) -> None:
        """Recompute total_value and unrealized_pnl from current positions."""
        self.unrealized_pnl = sum(p.unrealized_pnl for p in self.positions.values())
        positions_value = sum(p.size * p.current_price for p in self.positions.values())
        self.total_value = self.cash + positions_value
