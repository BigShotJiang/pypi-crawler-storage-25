"""Shared trigger logic for stop-loss / take-profit / trailing-stop / OCO orders.

Used by :class:`PaperExchange`, :class:`BacktestPaperExchange`, and the
client-side TRAILING_STOP simulation inside :class:`BinanceExchange`.

The design is stateless trigger math plus an explicit high-water-mark store
passed in by the caller, so each adapter owns its own state dict and tests
don't need to poke at internals.

All trigger predicates work on either:
  * a single scalar ``price`` (tick-driven: Paper, live trailing), or
  * a bar's ``high`` and ``low`` (bar-driven: Backtest) — the stop triggers
    if the bar *traded through* the stop price, not just if it closed past it.
"""
from __future__ import annotations

from dataclasses import dataclass

from auspicium.strategy.models import (
    ORDER_TYPE_OCO,
    ORDER_TYPE_STOP_LOSS,
    ORDER_TYPE_STOP_LOSS_LIMIT,
    ORDER_TYPE_TAKE_PROFIT,
    ORDER_TYPE_TAKE_PROFIT_LIMIT,
    ORDER_TYPE_TRAILING_STOP,
    Order,
)


@dataclass
class Trigger:
    """Result of a trigger check.

    Attributes:
        triggered:  True if the order should fire now.
        fill_price: Price at which the synthesised child order should execute.
                    For *_LIMIT stops this is ``order.price``; for market stops
                    this is the stop_price / bar-level trigger price (standard
                    backtest convention — fills AT the stop, not at bar close,
                    because any trade through the level is assumed to have
                    taken out the resting stop).
        reason:     Short label for logging: "stop", "take_profit", "trail",
                    "oco_stop", "oco_tp".
    """

    triggered: bool
    fill_price: float = 0.0
    reason: str = ""


def _crosses_down(stop_price: float, price: float, low: float | None) -> bool:
    """True if the market traded at or below ``stop_price``.

    Uses ``low`` when supplied (bar-driven); otherwise falls back to the
    scalar ``price`` (tick-driven).
    """
    return (low if low is not None else price) <= stop_price


def _crosses_up(stop_price: float, price: float, high: float | None) -> bool:
    """True if the market traded at or above ``stop_price``."""
    return (high if high is not None else price) >= stop_price


def check_trigger(
    order: Order,
    price: float,
    *,
    high: float | None = None,
    low: float | None = None,
    trail_mark: float | None = None,
) -> Trigger:
    """Evaluate whether a conditional order should fire against the current price.

    Args:
        order:       The conditional order being evaluated.
        price:       Scalar "current" price — the bar close for backtest,
                     the tick price for live/paper.
        high:        Bar high (backtest only). When None, scalar ``price``
                     is used for upward-crossing checks.
        low:         Bar low (backtest only). When None, scalar ``price``
                     is used for downward-crossing checks.
        trail_mark:  The current high-water mark for TRAILING_STOP (maintained
                     by the caller across ticks). Required for TRAILING_STOP.

    Returns:
        Trigger — with ``triggered=False`` if the order should stay pending.

    Notes:
        * STOP_LOSS / TAKE_PROFIT direction is determined by ``order.side``:
          SELL stops fire when price falls to stop_price (protecting a long),
          BUY stops fire when price rises to stop_price (protecting a short).
        * OCO legs: TP fires at oco_limit_price, SL fires at oco_stop_price.
          The caller is responsible for cancelling the untriggered leg by
          removing the order from its registry after this returns.
    """
    ot = order.order_type
    is_limit = ot in (ORDER_TYPE_STOP_LOSS_LIMIT, ORDER_TYPE_TAKE_PROFIT_LIMIT)

    if ot in (ORDER_TYPE_STOP_LOSS, ORDER_TYPE_STOP_LOSS_LIMIT):
        sp = float(order.stop_price)  # guaranteed non-None by Order validator
        # SELL stop-loss: long holder protecting a downside.
        # BUY stop-loss:  short holder protecting an upside.
        if order.side.upper() == "SELL" and _crosses_down(sp, price, low):
            return Trigger(True, order.price if is_limit else sp, "stop")
        if order.side.upper() == "BUY" and _crosses_up(sp, price, high):
            return Trigger(True, order.price if is_limit else sp, "stop")
        return Trigger(False)

    if ot in (ORDER_TYPE_TAKE_PROFIT, ORDER_TYPE_TAKE_PROFIT_LIMIT):
        sp = float(order.stop_price)
        # SELL take-profit: long holder exiting on upside.
        # BUY take-profit:  short holder exiting on downside.
        if order.side.upper() == "SELL" and _crosses_up(sp, price, high):
            return Trigger(True, order.price if is_limit else sp, "take_profit")
        if order.side.upper() == "BUY" and _crosses_down(sp, price, low):
            return Trigger(True, order.price if is_limit else sp, "take_profit")
        return Trigger(False)

    if ot == ORDER_TYPE_TRAILING_STOP:
        if trail_mark is None:
            return Trigger(False)
        # Compute effective stop price from the watermark.
        if order.side.upper() == "SELL":
            # Long holder trailing a sell stop UP with price.
            if order.trail_percent is not None:
                effective = trail_mark * (1.0 - float(order.trail_percent))
            else:
                effective = trail_mark - float(order.trail_amount)
            if _crosses_down(effective, price, low):
                return Trigger(True, effective, "trail")
        else:  # BUY trailing stop for short positions
            if order.trail_percent is not None:
                effective = trail_mark * (1.0 + float(order.trail_percent))
            else:
                effective = trail_mark + float(order.trail_amount)
            if _crosses_up(effective, price, high):
                return Trigger(True, effective, "trail")
        return Trigger(False)

    if ot == ORDER_TYPE_OCO:
        sl = float(order.oco_stop_price)
        tp = float(order.oco_limit_price)
        # OCO side is the closing side: SELL brackets a long, BUY brackets a short.
        if order.side.upper() == "SELL":
            if _crosses_up(tp, price, high):
                return Trigger(True, tp, "oco_tp")
            if _crosses_down(sl, price, low):
                return Trigger(True, sl, "oco_stop")
        else:  # BUY OCO brackets a short position
            if _crosses_down(tp, price, low):
                return Trigger(True, tp, "oco_tp")
            if _crosses_up(sl, price, high):
                return Trigger(True, sl, "oco_stop")
        return Trigger(False)

    return Trigger(False)


def update_trail_mark(order: Order, price: float, current_mark: float | None) -> float:
    """Advance the trailing-stop high-water mark when the market moves in our favour.

    For a SELL trailing stop (long holder), the mark tracks the max price seen.
    For a BUY trailing stop  (short holder), the mark tracks the min price seen.

    Call once per tick with the current price; pass the returned value back
    into :func:`check_trigger`.
    """
    if current_mark is None:
        return price
    if order.side.upper() == "SELL":
        return max(current_mark, price)
    return min(current_mark, price)
