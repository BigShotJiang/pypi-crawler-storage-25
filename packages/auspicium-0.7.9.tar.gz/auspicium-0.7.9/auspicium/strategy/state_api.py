"""Read-only HTTP API for production bot state.

Runs inside the strategy runner event loop on ``:9091``. The platform
workspace-api proxies to this for chart data visualization. Not exposed
to the internet — bound to 0.0.0.0 so the Docker network can reach it,
but the Dockerfile only publishes ``:9090`` + ``:9091`` on the internal
bridge network.

Design notes:
    * Same event loop as the runner. Handlers read in-memory objects
      shared with the runner; there is no cross-thread access so no
      locks are needed. Reads are atomic between ``await`` points.
    * FastAPI and uvicorn are lazy-imported inside :func:`create_state_app`
      so ``auspicium`` still imports cleanly when ``auspicium[api]`` is
      not installed.
    * Blocking operations (``RestConnector.ohlcv``) are dispatched to a
      worker thread via ``asyncio.to_thread`` so they never stall the
      tick loop.
    * The returned JSON shape matches the Phase 2C Chart Data Contract
      (``BacktestResult.to_dict()``) so the Vue frontend has one renderer
      for backtests, quality bots, and production bots.
"""
from __future__ import annotations

import asyncio
import logging
from datetime import datetime, timezone
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from auspicium.exchange.base import BaseExchange
    from auspicium.strategy.base import Strategy
    from auspicium.strategy.state import StateManager

log = logging.getLogger("auspicium.state_api")


def create_state_app(
    state_manager: "StateManager",
    strategy: "Strategy",
    exchange: "BaseExchange",
    start_time: datetime,
    runner=None,
):
    """Build a FastAPI app serving read-only bot state.

    Args:
        state_manager: The runner's :class:`StateManager` (reads SQLite
            for fills, snapshots, and indicators).
        strategy:      The active :class:`Strategy` instance (reads
            portfolio, positions, open orders, in-memory indicators).
        exchange:      The runner's exchange adapter (reads cash via
            ``get_balance()``).
        start_time:    When the runner started — used for uptime.
        runner:        The :class:`StrategyRunner` itself (optional). When
                       provided, ``/api/status`` surfaces reconnect state
                       (``ws_connected``, ``ws_last_disconnect``,
                       ``ws_reconnect_attempts``) so the UI can show
                       "reconnecting…" without going blank.

    Returns:
        A ``fastapi.FastAPI`` instance. The caller is responsible for
        wiring it into a uvicorn server.

    Raises:
        ImportError: If ``fastapi`` or ``uvicorn`` are not installed.
            The runner catches this and logs a warning so quality /
            backtest flows remain unaffected.
    """
    from fastapi import FastAPI, Query
    from fastapi.responses import JSONResponse

    app = FastAPI(
        title="Auspicium Bot State API",
        docs_url=None,
        redoc_url=None,
    )

    @app.get("/api/health")
    async def health():
        import auspicium
        uptime = (datetime.now(timezone.utc) - start_time).total_seconds()
        return {
            "status": "ok",
            "uptime_seconds": uptime,
            "strategy": strategy.__class__.__name__,
            "version": getattr(auspicium, "__version__", "unknown"),
        }

    @app.get("/api/status")
    async def status(include_chart: bool = Query(False)):
        portfolio = strategy.portfolio
        # Refresh derived values so the API reflects current mark-to-market,
        # not whatever they were at the last fill.
        portfolio.recompute()

        uptime = (datetime.now(timezone.utc) - start_time).total_seconds()

        # Reconnect-aware status. When the runner isn't passed (older test
        # callers) we default to "running" so existing behaviour is preserved.
        if runner is not None:
            ws_status = getattr(runner, "_ws_status", "running") or "running"
            ws_connected = bool(getattr(runner, "_ws_connected", True))
            ws_last_disconnect = getattr(runner, "_ws_last_disconnect", None)
            ws_reconnect_attempts = int(getattr(runner, "_ws_reconnect_attempts", 0) or 0)
        else:
            ws_status = "running"
            ws_connected = True
            ws_last_disconnect = None
            ws_reconnect_attempts = 0

        # v0.7.8: data-freshness signals. ``ws_connected`` reflects the
        # connection layer (handshake state). ``data_fresh`` reflects the
        # ingestion layer (last tick observed). Mixing them would surprise
        # consumers already alerting on ``ws_connected``, so we keep both.
        last_tick_at_dt: datetime | None = (
            getattr(runner, "_last_tick_at", None) if runner is not None else None
        )
        last_tick_at_iso: str | None = (
            last_tick_at_dt.isoformat() if last_tick_at_dt else None
        )
        seconds_since_last_tick: float | None = (
            (datetime.now(timezone.utc) - last_tick_at_dt).total_seconds()
            if last_tick_at_dt else None
        )
        threshold = (
            float(getattr(runner, "_tick_freshness_threshold_s", 300.0))
            if runner is not None else 300.0
        )
        data_fresh: bool = (
            seconds_since_last_tick is not None
            and seconds_since_last_tick < threshold
        )
        last_tick_at_per_sub: dict[str, str] = {
            f"{channel}/{source}/{symbol}": ts.isoformat()
            for (channel, source, symbol), ts in (
                getattr(runner, "_last_tick_at_per_sub", None) or {}
            ).items()
        }

        result: dict = {
            "status": ws_status,
            "ws_connected": ws_connected,
            "ws_last_disconnect": ws_last_disconnect,
            "ws_reconnect_attempts": ws_reconnect_attempts,
            # v0.7.8 data-freshness fields. Use these (not ws_connected) to
            # detect "bot connected but ingesting nothing" — the silent-stall
            # failure mode the watchdog now also recovers from.
            "data_fresh": data_fresh,
            "last_tick_at": last_tick_at_iso,
            "seconds_since_last_tick": seconds_since_last_tick,
            "last_tick_at_per_sub": last_tick_at_per_sub,
            "uptime_seconds": uptime,
            "strategy": strategy.__class__.__name__,
            "environment": "production",
            "portfolio": {
                "cash": portfolio.cash,
                "total_value": portfolio.total_value,
                "realized_pnl": portfolio.realized_pnl,
                "unrealized_pnl": portfolio.unrealized_pnl,
                "daily_pnl": portfolio.daily_pnl,
            },
            "positions": [
                {
                    "market": p.market,
                    "side": p.side,
                    "outcome": p.outcome,
                    "size": p.size,
                    "entry_price": p.entry_price,
                    "current_price": p.current_price,
                    "unrealized_pnl": p.unrealized_pnl,
                }
                for p in portfolio.positions.values()
            ],
            "open_orders": len(strategy.open_orders),
            "risk_breaches": 0,  # TODO: surface from RiskGuardian in a later release
            "stats": _compute_stats(state_manager, portfolio),
        }

        if include_chart:
            result["chart"] = await _build_live_chart(state_manager, strategy)
            result["equity_curve"] = _build_equity(state_manager)
            result["drawdown"] = _build_drawdown(state_manager)
            result["trades"] = _build_trade_log(state_manager)

        return JSONResponse(result)

    @app.get("/api/trades")
    async def trades(limit: int = 100):
        fills = state_manager.get_fills(limit=limit)
        return [
            {
                "order_id": f.order_id,
                "market": f.market,
                "side": f.side,
                "outcome": f.outcome,
                "price": f.price,
                "size": f.size,
                "fee": f.fee,
                "timestamp": f.timestamp.isoformat(),
                "status": f.status,
            }
            for f in fills
        ]

    @app.get("/api/indicators")
    async def indicators():
        # Prefer the in-memory copy (always fresh); fall back to SQLite.
        if getattr(strategy, "_indicator_log", None):
            return strategy.indicators
        return state_manager.load_indicators()

    return app


# ------------------------------------------------------------------ #
# Helpers — module-level so tests can exercise them directly           #
# ------------------------------------------------------------------ #

def _compute_stats(state_manager, portfolio) -> dict:
    """Compute win rate / profit factor / drawdown from fills + snapshots.

    Uses the existing FIFO matcher in ``backtest.engine._compute_trade_pnl``
    so live stats match what the backtest engine produces for the same
    fill sequence.
    """
    from auspicium.backtest.engine import _compute_trade_pnl

    fills = state_manager.get_fills(limit=10_000)
    trades = _compute_trade_pnl(fills)

    total_trades = int(len(trades))
    if total_trades == 0 or "pnl" not in trades.columns:
        return {
            "total_return": 0.0,
            "total_trades": 0,
            "win_rate": 0.0,
            "profit_factor": 0.0,
            "max_drawdown": 0.0,
        }

    wins = trades[trades["pnl"] > 0]
    losses = trades[trades["pnl"] < 0]
    loss_sum = abs(float(losses["pnl"].sum())) if len(losses) else 0.0
    # Clamp profit_factor to a finite sentinel — JSONResponse rejects inf,
    # and the frontend can render ">= 999" for a "no losses yet" bot.
    if loss_sum == 0.0:
        profit_factor = 999.0 if len(wins) else 0.0
    else:
        profit_factor = float(wins["pnl"].sum() / loss_sum)

    # Drawdown from portfolio snapshots
    snaps = state_manager.get_portfolio_snapshots(limit=5000)
    max_dd = 0.0
    if snaps:
        peak = snaps[0][1]
        for _, v in snaps:
            if v > peak:
                peak = v
            dd = (v - peak) / peak if peak > 0 else 0.0
            if dd < max_dd:
                max_dd = dd

    denominator = max(portfolio.cash, 1.0)
    return {
        "total_return": float(portfolio.realized_pnl / denominator),
        "total_trades": total_trades,
        "win_rate": float(len(wins) / total_trades),
        "profit_factor": profit_factor,
        "max_drawdown": float(max_dd),
    }


# Per-interval lookback defaults for the live chart. Chosen to give ~180–1500
# bars — enough to see context without dragging the payload or the browser.
# Server clamps to the tier's max_history_days; starter users see 7d max
# regardless of these values.
_CHART_DEFAULT_DAYS: dict[str, int] = {
    "1m": 1,     # ~1,440 bars — full day
    "5m": 3,     # ~864 bars   — 3 days context
    "1h": 14,    # ~336 bars   — 2 weeks
    "4h": 30,    # ~180 bars   — 1 month
    "1d": 180,   # 180 bars    — 6 months
}


async def _build_live_chart(state_manager, strategy) -> dict:
    """Build chart data for the ``?include_chart=true`` path.

    Returns a dict with ``primary`` (candlesticks), ``indicators``
    (list of indicator overlays), and ``markers`` (trade arrows).
    """
    chart: dict = {"primary": None, "indicators": [], "markers": []}

    subs = getattr(strategy, "_subscriptions", None) or []
    if subs:
        sub = subs[0]
        source = sub.get("source", "binance")
        symbol = sub.get("symbol", "BTC-USDT")
        # Non-ohlcv subs (trades/orderbook/polymarket) don't carry a candle
        # interval — fall back to 1h so the chart still renders.
        interval = sub.get("interval", "1h")
        # Lookback adapts to the bar interval so charts always materialise a
        # useful window (e.g. 1d bars need months, 1m bars need a day).
        # Unknown intervals fall back to the old 1-day default.
        days = _CHART_DEFAULT_DAYS.get(interval, 1)
        try:
            # RestConnector.ohlcv() is blocking httpx — dispatch to a
            # worker thread so it does not stall the runner's tick loop.
            from auspicium.connectors.rest import RestConnector
            df = await asyncio.to_thread(
                RestConnector.ohlcv, source, symbol, interval=interval, days=days
            )
            if df is not None and not df.empty:
                chart["primary"] = {
                    "type": "candlestick",
                    "label": f"{symbol} ({source})",
                    "data": [
                        {
                            "time": int(ts.timestamp()),
                            "open": round(float(row["open"]), 8),
                            "high": round(float(row["high"]), 8),
                            "low": round(float(row["low"]), 8),
                            "close": round(float(row["close"]), 8),
                        }
                        for ts, row in df.iterrows()
                    ],
                }
        except Exception as exc:
            log.warning("chart ohlcv fetch failed: %s", exc)

    # Indicator overlays — prefer in-memory
    chart["indicators"] = list(strategy.indicators.values())

    # Trade markers from fills
    fills = state_manager.get_fills(limit=200)
    for f in fills:
        try:
            ts = int(f.timestamp.timestamp())
        except Exception:
            ts = 0
        is_buy = f.side.upper() == "BUY"
        chart["markers"].append({
            "time": ts,
            "position": "belowBar" if is_buy else "aboveBar",
            "color": "#26a69a" if is_buy else "#ef5350",
            "shape": "arrowUp" if is_buy else "arrowDown",
            "text": (
                f"{'BUY' if is_buy else 'SELL'} {f.outcome} "
                f"{f.size} @ {f.price:.4f}"
            ),
        })

    return chart


def _parse_ts(iso_str: str) -> int:
    """Parse an ISO-8601 timestamp string to Unix seconds (int).

    Returns 0 on parse failure (callers treat that as "unknown time").
    """
    try:
        return int(datetime.fromisoformat(iso_str).timestamp())
    except (ValueError, TypeError):
        return 0


def _build_equity(state_manager) -> list:
    """Equity curve for the Chart Data Contract — Unix seconds, not ISO."""
    return [
        {"time": _parse_ts(ts), "value": round(float(v), 2)}
        for ts, v in state_manager.get_portfolio_snapshots(limit=5000)
    ]


def _build_drawdown(state_manager) -> list:
    """Drawdown curve derived from the equity snapshots."""
    snaps = state_manager.get_portfolio_snapshots(limit=5000)
    if not snaps:
        return []
    peak = snaps[0][1]
    out: list = []
    for ts, v in snaps:
        if v > peak:
            peak = v
        dd = (v - peak) / peak if peak > 0 else 0.0
        out.append({"time": _parse_ts(ts), "value": round(dd, 6)})
    return out


def _build_trade_log(state_manager) -> list:
    """Trade log for the dashboard table."""
    fills = state_manager.get_fills(limit=200)
    return [
        {
            "id": f.order_id,
            "time": f.timestamp.isoformat(),
            "market": f.market,
            "side": f.side,
            "outcome": f.outcome,
            "price": round(f.price, 8),
            "size": round(f.size, 4),
            "fee": round(f.fee, 6),
            "pnl": None,
        }
        for f in fills
    ]
