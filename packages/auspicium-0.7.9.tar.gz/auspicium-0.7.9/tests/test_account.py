"""Unit tests for auspicium.account — respx-mocked, no network."""
from __future__ import annotations

import httpx
import pytest
import respx


@pytest.fixture(autouse=True)
def _set_config(monkeypatch):
    monkeypatch.setenv("AUSP_API_KEY", "unit-test-key")
    monkeypatch.setenv("AUSP_GATEWAY_URL", "https://test.example")
    from auspicium.config import reset_config
    reset_config()
    yield
    reset_config()


_STARTER_ACCOUNT = {
    "tier": "starter",
    "limits": {
        "rest": {
            "max_bars_per_request": 100,
            "max_requests_per_minute": 10,
            "max_history_days": 7,
            "allowed_intervals": ["1m", "5m", "1h", "1d"],
            "allowed_exchanges": ["binance"],
            "allowed_symbols": ["BTC-USDT", "ETH-USDT"],
        },
        "websocket": {
            "max_connections": 1,
            "max_subscriptions_per_connection": 2,
            "allowed_intervals": ["1h"],
        },
        "backtest": {"max_window_days": 7, "max_concurrent": 1},
        "production": {"max_bots": 0, "allowed_exchanges": []},
    },
    "usage": {"rest_requests_this_minute": 0, "websocket_connections": 0, "active_bots": 0},
}


@respx.mock
def test_get_tier_maps_all_fields():
    from auspicium.connectors.rest import RestConnector
    RestConnector.close()
    respx.get("https://test.example/v1/account").mock(
        return_value=httpx.Response(200, json=_STARTER_ACCOUNT)
    )
    from auspicium.account import get_tier
    t = get_tier()
    assert t.tier == "starter"
    assert t.max_bars == 100
    assert t.max_history_days == 7
    assert t.allowed_intervals == ["1m", "5m", "1h", "1d"]
    assert t.ws_max_subscriptions == 2
    assert t.ws_allowed_intervals == ["1h"]
    assert t.max_production_bots == 0
    assert t.allowed_exchanges == ["binance"]
    assert t.allowed_symbols == ["BTC-USDT", "ETH-USDT"]


@respx.mock
def test_allowed_symbols_none_means_unrestricted():
    from auspicium.connectors.rest import RestConnector
    RestConnector.close()
    payload = {**_STARTER_ACCOUNT}
    payload["tier"] = "enterprise"
    payload["limits"] = {
        **_STARTER_ACCOUNT["limits"],
        "rest": {**_STARTER_ACCOUNT["limits"]["rest"], "allowed_symbols": None},
    }
    respx.get("https://test.example/v1/account").mock(
        return_value=httpx.Response(200, json=payload)
    )
    from auspicium.account import get_tier
    t = get_tier()
    assert t.allowed_symbols is None


@respx.mock
def test_get_tier_defaults_when_fields_missing():
    """Server responses missing optional fields fall back to conservative defaults
    (not runtime errors)."""
    from auspicium.connectors.rest import RestConnector
    RestConnector.close()
    respx.get("https://test.example/v1/account").mock(
        return_value=httpx.Response(200, json={"tier": "starter", "limits": {}})
    )
    from auspicium.account import get_tier
    t = get_tier()
    assert t.tier == "starter"
    assert t.max_bars == 100
    assert t.ws_allowed_intervals == ["1h"]
    assert t.allowed_symbols is None
