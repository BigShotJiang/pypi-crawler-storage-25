"""
REST connector integration tests.

These tests hit the real Kong gateway → FastAPI service.
Run inside the sdk-dev container (platform network) with a pro-tier test key.

Environment required:
  AUSP_API_KEY=sdk-test-pro-key-do-not-use-in-prod
  AUSP_GATEWAY_URL=http://kong:8000
"""
import pytest

from auspicium.connectors.rest import RestConnector
from auspicium.errors import AuthError, RateLimitError, TierRestrictionError


# ---------------------------------------------------------------------------
# Health check (public endpoint — no auth needed, confirms connectivity)
# ---------------------------------------------------------------------------

def test_health_endpoint_reachable():
    """Confirm the container can reach Kong → FastAPI."""
    import httpx
    from auspicium.config import get_config
    cfg = get_config()
    resp = httpx.get(f"{cfg.gateway_url}/v1/health", timeout=10)
    assert resp.status_code == 200
    assert resp.json()["status"] == "ok"


# ---------------------------------------------------------------------------
# OHLCV
# ---------------------------------------------------------------------------

def test_ohlcv_binance_btc_returns_data():
    df = RestConnector.ohlcv("binance", "BTC-USDT", interval="1m", days=1, limit=10)
    assert not df.empty, "Expected OHLCV data for BTC-USDT — check collector is running"
    assert "close" in df.columns
    assert df.index.tz is not None   # UTC-aware DatetimeIndex
    assert (df["close"] > 0).all()


def test_ohlcv_symbol_uppercased():
    """SDK should uppercase symbol automatically."""
    df1 = RestConnector.ohlcv("binance", "BTC-USDT", limit=5)
    df2 = RestConnector.ohlcv("binance", "btc-usdt", limit=5)
    assert len(df1) == len(df2)


def test_ohlcv_multiple_assets():
    for symbol in ("ETH-USDT", "SOL-USDT"):
        df = RestConnector.ohlcv("binance", symbol, limit=5)
        assert not df.empty, f"No data for {symbol}"


def test_ohlcv_respects_limit():
    df = RestConnector.ohlcv("binance", "BTC-USDT", limit=3)
    assert len(df) <= 3


def test_ohlcv_rate_limit_headers_populated():
    RestConnector.ohlcv("binance", "BTC-USDT", limit=1)
    # Kong 3.x exposes X-RateLimit-Remaining-Minute or RateLimit-Remaining
    rl = RestConnector.last_rate_limit
    assert any("remaining" in k for k in rl), f"No rate-limit headers found: {rl}"


# ---------------------------------------------------------------------------
# Trades
# ---------------------------------------------------------------------------

def test_trades_binance_returns_data():
    df = RestConnector.trades("binance", symbol="BTC-USDT", hours=24, limit=20)
    # trades may be sparse — just check schema is correct if any rows returned
    if not df.empty:
        assert "price" in df.columns or "close" in df.columns


# ---------------------------------------------------------------------------
# Orderbook
# ---------------------------------------------------------------------------

def test_orderbook_returns_bids_asks():
    book = RestConnector.orderbook("binance", "BTC-USDT", depth=5)
    assert "bids" in book
    assert "asks" in book
    assert len(book["bids"]) > 0 or len(book["asks"]) > 0


# ---------------------------------------------------------------------------
# Polymarket markets
# ---------------------------------------------------------------------------

def test_markets_active_returns_rows():
    df = RestConnector.markets(status="active")
    assert not df.empty, "Expected active Polymarket markets — check collector is running"
    assert "condition_id" in df.columns
    assert "base_asset" in df.columns


def test_markets_filter_by_asset():
    df = RestConnector.markets(base_asset="BTC")
    if not df.empty:
        assert (df["base_asset"] == "BTC").all()


# ---------------------------------------------------------------------------
# Cross-market OHLCV
# ---------------------------------------------------------------------------

def test_cross_market_5m_returns_data():
    df = RestConnector.cross_market(granularity="5m", hours=2)
    assert not df.empty, "Expected cross-OHLCV data — check dag_compute_cross_ohlcv ran"
    assert "binance_close" in df.columns
    assert "polymarket_up_close" in df.columns


def test_cross_market_confirmed_only_excludes_provisional():
    df = RestConnector.cross_market(confirmed_only=True)
    if not df.empty and "is_provisional" in df.columns:
        assert not df["is_provisional"].any()


def test_cross_market_1m_returns_data():
    df = RestConnector.cross_market(granularity="1m", hours=1)
    assert not df.empty


# ---------------------------------------------------------------------------
# Account
# ---------------------------------------------------------------------------

def test_me_returns_tier_info():
    info = RestConnector.me()
    assert "tier" in info
    assert info["tier"] in ("starter", "pro", "enterprise")
    assert "limits" in info


# ---------------------------------------------------------------------------
# Auth error
# ---------------------------------------------------------------------------

def test_invalid_api_key_raises_auth_error(monkeypatch):
    monkeypatch.setenv("AUSP_API_KEY", "completely-invalid-key")
    from auspicium.config import reset_config
    reset_config()
    with pytest.raises(AuthError):
        RestConnector.ohlcv("binance", "BTC-USDT")