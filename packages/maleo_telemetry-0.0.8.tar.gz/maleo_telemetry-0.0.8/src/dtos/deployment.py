import json
from pydantic import Field
from typing import Annotated
from uuid import UUID
from nexo.enums.service import ServiceType, FullServiceTypeMixin
from nexo.enums.status import DataStatus, SimpleDataStatusMixin
from nexo.schemas.mixins.identity import UUIDId
from nexo.types.string import ListOfStrs, OptListOfStrs, ManyStrs
from ..enums.deployment import IdentifierType, Restart, RestartMixin
from ..mixins.common import ServiceKey
from ..mixins.deployment import Registry, RegistryUrl, Tag, Targets
from ..types.deployment import IdentifierValueType


class RunArgs(RestartMixin[Restart]):
    restart: Annotated[
        Restart,
        Field(Restart.UNLESS_STOPPED, description="Restart policy"),
    ] = Restart.UNLESS_STOPPED
    volumes: Annotated[
        OptListOfStrs, Field(None, description="Attached volumes", min_length=1)
    ] = None
    extra: Annotated[
        OptListOfStrs, Field(None, description="Extra arguments", min_length=1)
    ] = None


class DeployMessage(
    Tag[str],
    Registry[str],
    FullServiceTypeMixin[ServiceType],
    ServiceKey,
):
    args: Annotated[
        RunArgs, Field(default_factory=RunArgs, description="Docker run arguments")
    ]


class DeploymentDTO(
    Targets[ListOfStrs],
    Tag[str],
    RegistryUrl[str],
    ServiceKey[str],
    SimpleDataStatusMixin[DataStatus],
    UUIDId[UUID],
):
    @property
    def _identifiers(self) -> tuple[tuple[IdentifierType, IdentifierValueType], ...]:
        return (
            (IdentifierType.ID, str(self.id)),
            (IdentifierType.SERVICE_KEY, self.service_key),
        )

    @property
    def cache_key_identifiers(self) -> ManyStrs:
        return tuple(
            '"identifier": '
            + json.dumps(
                {
                    "type": type.value,
                    "value": value,
                }
            )
            for type, value in self._identifiers
        )
