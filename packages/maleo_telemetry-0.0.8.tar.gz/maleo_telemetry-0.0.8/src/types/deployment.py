from uuid import UUID

IdentifierValueType = UUID | str
