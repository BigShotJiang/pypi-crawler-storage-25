from pydantic import BaseModel, Field
from typing import Annotated, Generic, Literal, TypeGuard
from uuid import UUID
from nexo.schemas.mixins.identity import Identifier
from nexo.types.string import OptStrT, OptListOfStrsT
from ..enums.deployment import IdentifierType
from ..types.deployment import IdentifierValueType


class Registry(BaseModel, Generic[OptStrT]):
    registry: Annotated[OptStrT, Field(..., description="Registry")]


class RegistryUrl(BaseModel, Generic[OptStrT]):
    registry_url: Annotated[OptStrT, Field(..., description="Registry URL")]


class Tag(BaseModel, Generic[OptStrT]):
    tag: Annotated[OptStrT, Field(..., description="Tag")]


class Targets(BaseModel, Generic[OptListOfStrsT]):
    targets: Annotated[OptListOfStrsT, Field(..., description="Targets", min_length=1)]


class DeploymentIdentifier(Identifier[IdentifierType, IdentifierValueType]):
    @property
    def column_and_value(self) -> tuple[str, IdentifierValueType]:
        return self.type.column, self.value


class IdDeploymentIdentifier(Identifier[Literal[IdentifierType.ID], UUID]):
    type: Annotated[
        Literal[IdentifierType.ID],
        Field(IdentifierType.ID, description="Identifier's type"),
    ] = IdentifierType.ID


class ServiceKeyDeploymentIdentifier(
    Identifier[Literal[IdentifierType.SERVICE_KEY], str]
):
    type: Annotated[
        Literal[IdentifierType.SERVICE_KEY],
        Field(IdentifierType.SERVICE_KEY, description="Identifier's type"),
    ] = IdentifierType.SERVICE_KEY


AnyDeploymentIdentifier = (
    DeploymentIdentifier | IdDeploymentIdentifier | ServiceKeyDeploymentIdentifier
)


def is_id_identifier(
    identifier: AnyDeploymentIdentifier,
) -> TypeGuard[IdDeploymentIdentifier]:
    return identifier.type is IdentifierType.ID and isinstance(identifier.value, UUID)


def is_service_key_identifier(
    identifier: AnyDeploymentIdentifier,
) -> TypeGuard[ServiceKeyDeploymentIdentifier]:
    return identifier.type is IdentifierType.SERVICE_KEY and isinstance(
        identifier.value, str
    )
