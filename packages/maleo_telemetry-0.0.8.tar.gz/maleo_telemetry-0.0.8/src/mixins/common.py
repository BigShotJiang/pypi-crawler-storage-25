from datetime import datetime
from pydantic import BaseModel, Field
from typing import Annotated, Generic
from maleo.identity.schemas.service import StandardServiceSchema
from nexo.types.string import OptStrT, OptListOfStrsT


class MessageId(BaseModel):
    message_id: Annotated[str, Field(..., description="Message's ID")]


class PublishedAt(BaseModel):
    published_at: Annotated[datetime, Field(..., description="Published At")]


class InstanceId(BaseModel):
    instance_id: Annotated[str, Field(..., description="Instance's ID")]


class ServiceKey(BaseModel, Generic[OptStrT]):
    service_key: Annotated[OptStrT, Field(..., description="Service's Key")]


class ServiceKeys(BaseModel, Generic[OptListOfStrsT]):
    service_keys: Annotated[
        OptListOfStrsT, Field(..., description="Service's Keys", min_length=1)
    ]


class Service(BaseModel):
    service: Annotated[StandardServiceSchema, Field(..., description="Service")]
