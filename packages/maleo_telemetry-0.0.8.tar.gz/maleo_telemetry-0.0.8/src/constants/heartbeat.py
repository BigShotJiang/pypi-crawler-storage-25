from nexo.schemas.resource import Resource, ResourceIdentifier

HEARTBEAT_RESOURCE = Resource(
    identifiers=[
        ResourceIdentifier(key="heartbeat", name="Heartbeat", slug="heartbeats")
    ],
    details=None,
)
