from nexo.schemas.resource import Resource, ResourceIdentifier

DEPLOYMENT_RESOURCE = Resource(
    identifiers=[
        ResourceIdentifier(key="deployment", name="Deployment", slug="deployments")
    ],
    details=None,
)
