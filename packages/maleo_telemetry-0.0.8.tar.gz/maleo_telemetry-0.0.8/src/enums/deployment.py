from enum import StrEnum
from pydantic import BaseModel, Field
from typing import Annotated, Generic, TypeVar
from nexo.types.string import ListOfStrs


class IdentifierType(StrEnum):
    ID = "id"
    SERVICE_KEY = "service_key"

    @classmethod
    def choices(cls) -> ListOfStrs:
        return [e.value for e in cls]

    @property
    def column(self) -> str:
        return self.value


class Restart(StrEnum):
    NO = "no"
    ALWAYS = "always"
    UNLESS_STOPPED = "unless-stopped"

    @classmethod
    def choices(cls) -> ListOfStrs:
        return [e.value for e in cls]


RestartT = TypeVar("RestartT", bound=Restart)
OptRestart = Restart | None
OptRestartT = TypeVar("OptRestartT", bound=OptRestart)


class RestartMixin(BaseModel, Generic[OptRestartT]):
    restart: Annotated[OptRestartT, Field(..., description="Restart Policy")]
