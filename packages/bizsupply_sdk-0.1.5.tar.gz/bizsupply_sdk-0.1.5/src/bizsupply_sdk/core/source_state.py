"""Source state model for source plugins.

Source plugins use state to track their synchronization progress
between executions (e.g., last processed email ID, cursor position).
"""

from __future__ import annotations

from pydantic import BaseModel


class BaseSourceState(BaseModel):
    """Base class for source state models.

    All source plugins MUST define a state model that inherits from this class.
    The state model defines what data the plugin persists between executions.

    State is automatically serialized to JSON and stored in the database.
    On the next execution, it's deserialized back to your typed model.

    Example:
        class GmailSourceState(BaseSourceState):
            '''State for Gmail source plugin.'''
            last_email_index: int = 0
            last_message_id: str | None = None
            last_email_internal_date: datetime | None = None

        class MySourcePlugin(SourcePlugin):
            source_type = "my_gmail"
            source_state_model = GmailSourceState
            credential_fields = ["access_token", "refresh_token"]

            async def fetch(
                self,
                credentials: DynamicCredential,
                state: GmailSourceState,
                configs: dict[str, Any],
            ) -> AsyncIterator[DocumentInput]:
                # State is already typed as GmailSourceState
                # Use state to resume where we left off
                start_index = state.last_email_index

                # ... process emails ...
                for email in emails[start_index:]:
                    yield DocumentInput(
                        file_data=email.content,
                        filename=email.subject + ".eml",
                    )
                    # Update state - Engine saves automatically after each document
                    state.last_email_index += 1
    """

    pass
