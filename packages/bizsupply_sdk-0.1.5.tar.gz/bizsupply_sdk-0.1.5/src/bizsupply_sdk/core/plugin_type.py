"""Plugin type enumeration.

Defines the supported plugin types in the bizSupply platform.
"""

from __future__ import annotations

from enum import Enum


class PluginType(str, Enum):
    """Enumeration of supported plugin types.

    Attributes:
        source: Plugins that ingest documents from external sources (APIs, files, etc.)
        classification: Plugins that categorize/label documents
        extraction: Plugins that extract structured data from documents
    """

    source = "source"
    classification = "classification"
    extraction = "extraction"


# Execution priority order: Source -> Classification -> Extraction
TYPE_PRIORITY: dict[PluginType, int] = {
    PluginType.source: 0,
    PluginType.classification: 1,
    PluginType.extraction: 2,
}
