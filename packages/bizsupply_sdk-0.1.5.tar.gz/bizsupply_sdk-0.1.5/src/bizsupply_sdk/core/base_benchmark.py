"""BaseBenchmark - Abstract base class for all benchmark implementations.

Defines the interface that all benchmarks must implement.

A benchmark is responsible for pure calculation logic:
1. Scoring a single document (which includes its aggregations)
2. Computing a single benchmark value from scored documents
3. Comparing a document's score against the benchmark value

The benchmark does NOT:
- Query documents from database (engine does this)
- Save results to database (engine does this)
- Fetch aggregations (engine pre-fetches these and attaches to document)
- Construct score records (engine does this)
- Know its own benchmark_id (engine manages this)
- Know slot names (engine resolves semantic fields to slots via MappingRegistry)

Separation of concerns:
- Engine = Data access + orchestration + ExtendedDocument construction
- Benchmark = Pure business logic (calculation)

## ExtendedDocument

Benchmarks receive ExtendedDocument objects instead of raw dicts.
ExtendedDocument provides:
- .aggregations: list of related ExtendedDocuments
- .get("document_id"), .get("supplier"), .get("label_1"), etc.
- .get("field_name"): field access by semantic name
- .raw: dict escape hatch for direct access

The engine resolves physical slot names (number_1, string_2) to semantic
field names (price_per_kwh, client_tax_id) before constructing ExtendedDocument.
Partners never see slot names.
"""

from __future__ import annotations

from abc import ABC, abstractmethod

from bizsupply_sdk.core.document import ExtendedDocument, ScoredDocument


class BaseBenchmark(ABC):
    """Abstract base class for all benchmark implementations.

    Each benchmark defines:
    1. score(): How to calculate a score for ONE document
    2. compute(): How to reduce scored documents to a benchmark value
    3. compare(): How the document's score compares to the benchmark value

    The benchmark focuses on pure calculation:
    - Scoring logic (from document with its aggregations)
    - Compute logic (min, max, weighted average, etc.)
    - Comparison logic (how a document measures against its benchmark)

    The engine handles everything else:
    - Querying documents from database
    - Pre-fetching aggregations and attaching them to ExtendedDocument
    - Resolving slot names to semantic field names before construction
    - Constructing score records for persistence
    - The scoring loop (iterating documents)
    - Error handling and logging
    - Saving results to database

    Example:
        class EnergyBenchmark(BaseBenchmark):
            name = "energy_contract_price_portugal"
            target_labels = ["contract", "energy"]
            group_by = ["region"]
            metric_unit = "EUR/kWh"

            MATCH_RULES = [MatchRule(...)]

            def score(self, document):
                prices = [inv.get("price_per_kwh") for inv in document.aggregations]
                prices = [p for p in prices if p is not None]
                return sum(prices) / len(prices) if prices else None

            def compute(self, results):
                return min(r.score for r in results)

            def compare(self, document_score, benchmark_score):
                return document_score > benchmark_score
    """

    # ========================================================================
    # Identity Properties (MUST be defined by subclass)
    # ========================================================================

    name: str  # e.g., "energy_contract_price_portugal"
    target_labels: list[str]  # e.g., ["contract", "energy"]
    metric_unit: str  # e.g., "EUR/kWh"
    group_by: list[str] = []  # Field names to group by (e.g., ["region"])

    def __init_subclass__(cls, **kwargs):
        super().__init_subclass__(**kwargs)
        # Only validate concrete classes (all abstract methods implemented)
        for method in ("score", "compute", "compare"):
            if getattr(getattr(cls, method, None), "__isabstractmethod__", False):
                return
        missing = []
        for attr in ("name", "target_labels", "metric_unit"):
            if not getattr(cls, attr, None):
                missing.append(attr)
        if missing:
            raise TypeError(
                f"{cls.__name__} must define: {', '.join(missing)}"
            )

    # ========================================================================
    # Abstract Methods (MUST be implemented by subclass)
    # ========================================================================

    @abstractmethod
    def score(self, document: ExtendedDocument) -> float | None:
        """Calculate the score for a single document.

        This contains the core scoring logic for your benchmark.
        Related documents (aggregations) are available via document.aggregations.
        Use .get("field_name") on aggregated documents to read their
        fields by semantic name.

        Args:
            document: ExtendedDocument with typed access and aggregations

        Returns:
            Score as float, or None if document cannot be scored

        Example (Energy Contract Price):
            def score(self, document):
                if not document.aggregations:
                    return None
                prices = [inv.get("price_per_kwh") for inv in document.aggregations]
                prices = [p for p in prices if p is not None]
                if not prices:
                    return None
                return sum(prices) / len(prices)
        """
        pass

    @abstractmethod
    def compute(self, results: list[ScoredDocument]) -> float:
        """Compute a single benchmark value from all scored documents.

        Called by the engine after scoring all documents. Receives
        ScoredDocument objects pairing each document with its score,
        enabling both simple score-based and weighted/document-aware
        aggregation strategies.

        Common implementations:
            - min(r.score for r in results)     -> best/lowest
            - max(r.score for r in results)     -> best/highest
            - Weighted average using document properties

        Args:
            results: Non-empty list of ScoredDocument objects

        Returns:
            Single benchmark value as float

        Example (simple - best price):
            def compute(self, results):
                return min(r.score for r in results)

        Example (weighted by supplier volume):
            def compute(self, results):
                total_weight = sum(r.document.get("volume") or 1 for r in results)
                return sum(r.score * (r.document.get("volume") or 1) for r in results) / total_weight
        """
        pass

    @abstractmethod
    def compare(self, document_score: float, benchmark_score: float) -> bool:
        """Compare a document's score against the benchmark value.

        Called by the engine after scoring to determine how a document
        measures against its benchmark. Returns True if the document's
        score is unfavorable compared to the benchmark (requires action).

        Args:
            document_score: The document's calculated score
            benchmark_score: The benchmark value to compare against

        Returns:
            True if the document scores unfavorably, False otherwise

        Example Implementations:
            - Energy (lower is better): return document_score > benchmark_score
            - Quality (higher is better): return document_score < benchmark_score
            - Threshold: return abs(document_score - benchmark_score) > 0.10
        """
        pass
