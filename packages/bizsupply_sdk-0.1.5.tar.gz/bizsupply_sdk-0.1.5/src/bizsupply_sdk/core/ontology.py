"""Ontology models for classification and extraction.

Ontologies define the taxonomy of document classifications and the fields
to extract for each classification type.
"""

from __future__ import annotations

from datetime import datetime
from typing import Any

from pydantic import BaseModel, Field, field_validator

from bizsupply_sdk.constants import (
    MAX_DESCRIPTION_LENGTH,
    MAX_FIELD_DTYPE_LENGTH,
    MAX_LABEL_LENGTH,
    MAX_NAME_LENGTH,
    MAX_ONTOLOGY_CHILDREN_PER_NODE,
    MAX_ONTOLOGY_FIELDS_PER_NODE,
)


class OntologyField(BaseModel):
    """Definition of a data field in an ontology.

    Attributes:
        name: Field name (used as key in extracted data)
        dtype: Data type (e.g., "string", "int", "float", "date")
        description: Human-readable description of the field

    Example:
        OntologyField(
            name="contract_value",
            dtype="float",
            description="Total monetary value of the contract"
        )
    """

    model_config = {"extra": "forbid"}

    name: str = Field(..., max_length=MAX_NAME_LENGTH, description="Field name")
    dtype: str = Field(
        ...,
        max_length=MAX_FIELD_DTYPE_LENGTH,
        description="Data type (e.g., 'string', 'int', 'float', 'date')",
    )
    description: str | None = Field(
        default=None, max_length=MAX_DESCRIPTION_LENGTH, description="Field description"
    )


class OntologyNode(BaseModel):
    """Recursive ontology node that can contain labels, fields, and children.

    Ontologies are organized as trees where each node represents a
    classification category. Nodes can have:
    - A label (the classification name)
    - Fields (data to extract for documents with this classification)
    - Children (sub-classifications)

    Attributes:
        label: The classification label for this node
        fields: Fields to extract for documents at this classification level
        children: Child nodes (sub-classifications)

    Example:
        # A simple ontology tree:
        # Contract
        # ├── Energy
        # │   ├── Residential
        # │   └── Commercial
        # └── Water

        OntologyNode(
            label="Contract",
            fields=[OntologyField(name="start_date", dtype="date")],
            children=[
                OntologyNode(
                    label="Energy",
                    fields=[OntologyField(name="power_kw", dtype="float")],
                    children=[
                        OntologyNode(label="Residential"),
                        OntologyNode(label="Commercial"),
                    ]
                ),
                OntologyNode(label="Water"),
            ]
        )
    """

    model_config = {"extra": "forbid"}

    label: str = Field(
        ..., max_length=MAX_LABEL_LENGTH, description="Classification label for this node"
    )
    fields: list[OntologyField] = Field(
        default_factory=list,
        max_length=MAX_ONTOLOGY_FIELDS_PER_NODE,
        description="Fields to extract at this level",
    )
    children: list[OntologyNode] = Field(
        default_factory=list,
        max_length=MAX_ONTOLOGY_CHILDREN_PER_NODE,
        description="Child classification nodes",
    )

    def get_all_fields(self) -> list[OntologyField]:
        """Get all fields for this node including fields from all children.

        Returns:
            List of all OntologyField objects in this subtree
        """
        all_fields = self.fields.copy()
        for child in self.children:
            all_fields.extend(child.get_all_fields())
        return all_fields

    def find_node_by_path(self, path: list[str]) -> OntologyNode | None:
        """Find a node by following a path of labels.

        Args:
            path: List of labels to follow (e.g., ["Contract", "Energy", "Residential"])

        Returns:
            The matching OntologyNode or None if not found

        Example:
            node = ontology.taxonomy.find_node_by_path(["Contract", "Energy"])
            if node:
                print(f"Found {node.label} with {len(node.children)} children")
        """
        if not path:
            return self

        if path[0].lower() == self.label.lower():
            if len(path) == 1:
                return self
            # Continue searching in children
            for child in self.children:
                result = child.find_node_by_path(path[1:])
                if result:
                    return result
        return None

    def get_leaf_labels(self) -> list[list[str]]:
        """Get all possible label paths from root to leaves.

        Returns:
            List of paths, where each path is a list of labels
            e.g., [["Contract", "Energy", "Residential"], ["Contract", "Water"]]
        """
        if not self.children:
            # This is a leaf node
            return [[self.label]]

        paths = []
        for child in self.children:
            child_paths = child.get_leaf_labels()
            for child_path in child_paths:
                paths.append([self.label] + child_path)
        return paths


class OntologyManifest(BaseModel):
    """Ontology manifest model.

    This is the ontology model that plugins receive in their context.
    It contains the taxonomy tree and methods for navigating it.

    Attributes:
        ontology_id: Unique identifier for the ontology
        name: Human-readable name
        description: Description of the ontology's purpose
        taxonomy: Root node of the classification tree
        created_at: Creation timestamp
        updated_at: Last update timestamp

    Example:
        # In a plugin, access ontologies from context:
        for ontology in context.ontologies:
            paths = ontology.get_all_label_paths()
            for path in paths:
                print(f"Classification: {' > '.join(path)}")
    """

    model_config = {"extra": "forbid", "frozen": True}

    ontology_id: str | None = Field(default=None, max_length=36, description="Ontology ID")
    name: str = Field(..., max_length=MAX_NAME_LENGTH, description="Ontology name")
    description: str | None = Field(
        default=None, max_length=MAX_DESCRIPTION_LENGTH, description="Ontology description"
    )
    taxonomy: OntologyNode = Field(..., description="Root node of the taxonomy tree")
    created_at: datetime | None = Field(default=None, description="Creation timestamp")
    updated_at: datetime | None = Field(default=None, description="Last update timestamp")

    def get_all_label_paths(self) -> list[list[str]]:
        """Get all possible classification paths in this ontology.

        Returns:
            List of paths from root to each leaf node
        """
        return self.taxonomy.get_leaf_labels()

    def find_fields_for_path(self, path: list[str]) -> list[OntologyField]:
        """Find all fields that apply to a specific classification path.

        Inherits fields from parent nodes, so a document classified as
        ["Contract", "Energy", "Residential"] would get fields from all
        three levels.

        Args:
            path: Classification path (list of labels)

        Returns:
            List of OntologyField objects for the path
        """
        node = self.taxonomy.find_node_by_path(path)
        if not node:
            return []

        # Collect fields from the path to this node
        fields: list[OntologyField] = []
        current_node = self.taxonomy

        for label in path:
            if current_node.label.lower() == label.lower():
                fields.extend(current_node.fields)
                # Find the next child
                for child in current_node.children:
                    if len(path) > path.index(label) + 1:
                        next_label = path[path.index(label) + 1]
                        if child.label.lower() == next_label.lower():
                            current_node = child
                            break
            else:
                # Search in children
                for child in current_node.children:
                    if child.label.lower() == label.lower():
                        current_node = child
                        fields.extend(current_node.fields)
                        break

        return fields
