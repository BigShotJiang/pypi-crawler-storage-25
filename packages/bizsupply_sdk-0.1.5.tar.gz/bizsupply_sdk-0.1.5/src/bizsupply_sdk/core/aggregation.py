"""Aggregation models for the SDK.

These models define how related documents are linked together for benchmarks.
Partners use these to declare match rules in their benchmarks.

Note: The server-side matching logic (field resolution via MappingService,
document validation) lives in AggregationMatcher. These SDK models are
data-only with pure evaluation logic for local testing.
"""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, Field

from bizsupply_sdk.exceptions import InvalidOperatorError
from bizsupply_sdk.constants import (
    MAX_DESCRIPTION_LENGTH,
    MAX_DOCUMENT_LABELS,
    MAX_LABEL_LENGTH,
    MAX_NAME_LENGTH,
)


class MatchCondition(BaseModel):
    """A single matching condition between two document fields.

    Examples:
        - MatchCondition(left_field="client_tax_id", right_field="client_tax_id", match_type="==")
        - MatchCondition(left_field="end_date", right_field="emission_date", match_type=">=")
    """

    model_config = {"extra": "forbid"}

    left_field: str = Field(..., max_length=MAX_NAME_LENGTH, description="Field name in left document")
    right_field: str = Field(..., max_length=MAX_NAME_LENGTH, description="Field name in right document")
    match_type: str = Field(
        ..., max_length=20, description="Comparison operator: ==, !=, <, <=, >, >=, contains, starts_with"
    )

    def evaluate(self, left_value: Any, right_value: Any) -> bool:
        """Evaluate this condition against two field values.

        Pure comparison logic - useful for local testing without server dependencies.

        Returns:
            True if condition passes, False otherwise
        """
        if left_value is None or right_value is None:
            return False

        match self.match_type:
            case "==":
                return left_value == right_value
            case "!=":
                return left_value != right_value
            case "<":
                return left_value < right_value
            case "<=":
                return left_value <= right_value
            case ">":
                return left_value > right_value
            case ">=":
                return left_value >= right_value
            case "contains":
                return str(right_value) in str(left_value)
            case "starts_with":
                return str(left_value).startswith(str(right_value))
            case _:
                raise InvalidOperatorError(
                    f"Unknown match_type: {self.match_type}",
                    details={"match_type": self.match_type},
                )


class MatchRule(BaseModel):
    """Aggregation rule definition - links related document types.

    Defines how to match documents from left_group to right_group.

    Field names use semantic names (client_tax_id, price_per_kwh),
    which are resolved to Silver tier generic slots server-side via MappingService.
    This keeps rules readable while using the optimized Silver tier storage.

    Example:
        MatchRule(
            name="energy_contract_invoice_match",
            left_group=["contract", "energy"],
            right_group=["invoice", "energy"],
            conditions=[
                MatchCondition(
                    left_field="client_tax_id",
                    right_field="client_tax_id",
                    match_type="==",
                ),
                MatchCondition(
                    left_field="cpe_point_of_delivery",
                    right_field="cpe_point_of_delivery",
                    match_type="==",
                ),
            ],
        )
    """

    model_config = {"extra": "forbid"}

    name: str = Field(..., max_length=MAX_NAME_LENGTH, description="Unique identifier for this rule")
    left_group: list[str] = Field(..., max_length=MAX_DOCUMENT_LABELS, description="Labels for source documents")
    right_group: list[str] = Field(..., max_length=MAX_DOCUMENT_LABELS, description="Labels for target documents")
    conditions: list[MatchCondition] = Field(
        ..., max_length=20, description="ALL conditions must match (AND logic)"
    )
    description: str | None = Field(None, max_length=MAX_DESCRIPTION_LENGTH, description="Human-readable description")
