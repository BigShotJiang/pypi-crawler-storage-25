"""Credential models for source plugin authentication.

DynamicCredential provides access to credentials stored in Secret Manager.
Partners declare credential_fields as a class attribute in their plugin code
and access them by name at runtime.
"""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel

from bizsupply_sdk.exceptions import MissingFieldError


class DynamicCredential(BaseModel):
    """Dynamic credential for all source types (built-in and partner-defined).

    Partners declare credential_fields as a class attribute in their plugin code.
    Fields are accessed by name at runtime.

    Access patterns:
        # Using .get() - returns None or default if not found
        api_url = credentials.get("api_url")
        timeout = credentials.get("timeout_seconds", 30)

        # Using attribute access - raises AttributeError if not found
        api_key = credentials.api_key

    Example plugin class:
        class MySourcePlugin(SourcePlugin):
            source_type = "my_api"
            credential_fields = ["access_token", "api_url", "timeout_seconds"]

    Example usage in plugin:
        credentials = self.get_source_credentials()
        credentials.validate_required_fields(["access_token", "api_url"])
        token = credentials.access_token
        url = credentials.get("api_url")
    """

    model_config = {"extra": "forbid"}

    _fields: dict[str, Any] = {}

    def __init__(self, fields: dict[str, Any] | None = None, **kwargs: Any):
        """Initialize DynamicCredential with field values.

        Args:
            fields: Dictionary of credential field values
            **kwargs: Additional Pydantic model kwargs
        """
        super().__init__(**kwargs)
        # Store fields in private attribute (not validated by Pydantic)
        object.__setattr__(self, "_fields", fields or {})

    def get(self, field_name: str, default: Any = None) -> Any:
        """Get credential field by name.

        Args:
            field_name: Name of the credential field
            default: Default value if field not found

        Returns:
            Field value or default

        Example:
            api_url = credentials.get("api_url")
            timeout = credentials.get("timeout_seconds", 30)
        """
        return self._fields.get(field_name, default)

    def __getattr__(self, name: str) -> Any:
        """Allow attribute-style access to credential fields.

        Args:
            name: Attribute name (credential field name)

        Returns:
            Field value

        Raises:
            AttributeError: If field not found

        Example:
            api_key = credentials.api_key
        """
        # Don't intercept private attributes or Pydantic internals
        if name.startswith("_") or name in ("model_fields", "model_config"):
            return object.__getattribute__(self, name)

        # Check if it's a stored field
        fields = object.__getattribute__(self, "_fields")
        if name in fields:
            return fields[name]

        raise AttributeError(
            f"Credential has no field '{name}'. Available fields: {list(fields.keys())}"
        )

    def __contains__(self, field_name: str) -> bool:
        """Check if a field exists in credentials.

        Example:
            if "api_key" in credentials:
                ...
        """
        return field_name in self._fields

    def keys(self) -> list[str]:
        """Get all credential field names.

        Returns:
            List of field names
        """
        return list(self._fields.keys())

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary.

        Note: Use with caution - may expose secrets in logs.

        Returns:
            Dictionary of field names to values
        """
        return dict(self._fields)

    def validate_required_fields(self, required_fields: list[str]) -> None:
        """Validate that all required credential fields are present.

        Call this method early in plugin execution to fail fast if
        credentials are missing expected fields.

        Args:
            required_fields: List of field names that must be present

        Raises:
            MissingFieldError: If any required fields are missing

        Example:
            credentials = self.get_source_credentials()
            credentials.validate_required_fields(["api_key", "api_url"])
            # Now safe to access these fields
        """
        missing = [f for f in required_fields if f not in self._fields]
        if missing:
            available = list(self._fields.keys())
            raise MissingFieldError(
                f"Missing required credential fields: {missing}. Available fields: {available}",
                details={"missing_fields": missing, "available_fields": available},
            )

    def has_field(self, field_name: str) -> bool:
        """Check if a specific field is present and non-empty.

        Args:
            field_name: Name of the field to check

        Returns:
            True if field exists and has a truthy value
        """
        value = self._fields.get(field_name)
        return value is not None and value != ""
