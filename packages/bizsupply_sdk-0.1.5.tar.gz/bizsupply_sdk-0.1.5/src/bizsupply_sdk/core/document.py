"""Document models for plugin and benchmark development.

Document is the primary model that plugins work with.
ExtendedDocument is a read-only wrapper used in benchmarks, where a
document is extended by its aggregations (related documents).
"""

from __future__ import annotations

from datetime import datetime
from typing import Any

from pydantic import BaseModel, Field, field_validator

from bizsupply_sdk.constants import (
    JSONB_DOCUMENT_DATA_MAX_BYTES,
    JSONB_METADATA_MAX_BYTES,
    MAX_DOCUMENT_LABELS,
    MAX_FILENAME_LENGTH,
    MAX_LABEL_LENGTH,
)
from bizsupply_sdk.exceptions import FieldSizeExceededError
from bizsupply_sdk.validators import validate_jsonb_size


class Document(BaseModel):
    """Document model for plugin executions and API responses.

    This is the primary document model that plugins work with.
    Contains only the fields that plugin developers need.

    NOTE: Unlike other External models, this is NOT frozen because plugins
    need to modify document fields (labels, data, metadata) during pipeline
    execution.

    Attributes:
        document_id: Unique identifier for the document
        original_filename: Original filename with extension (e.g., "invoice.pdf")
        metadata: Custom metadata attached to the document
        labels: Classification labels assigned to the document
        data: Extracted data fields
        created_at: Timestamp when document was created
        updated_at: Timestamp when document was last updated

    Example:
        # Accessing document data in a plugin
        document = context.documents[0]
        filename = document.original_filename
        labels = document.labels or []
        extracted_data = document.data or {}
    """

    model_config = {"extra": "forbid"}

    document_id: str = Field(
        ..., max_length=36, description="Unique identifier for the document"
    )
    original_filename: str = Field(
        ...,
        max_length=MAX_FILENAME_LENGTH,
        description="Original filename with extension (e.g., 'invoice.pdf')",
    )
    metadata: dict[str, Any] | None = Field(
        default_factory=dict, description="Custom metadata attached to the document"
    )
    labels: list[str] | None = Field(
        default_factory=list,
        max_length=MAX_DOCUMENT_LABELS,
        description="Classification labels assigned to the document",
    )
    data: dict[str, Any] | None = Field(
        default_factory=dict, description="Extracted data fields"
    )

    @field_validator("labels")
    @classmethod
    def validate_label_lengths(cls, v: list[str] | None) -> list[str] | None:
        if v is not None:
            for label in v:
                if len(label) > MAX_LABEL_LENGTH:
                    raise FieldSizeExceededError(
                        f"Label '{label}' exceeds max length of {MAX_LABEL_LENGTH}",
                        details={"field": "labels", "value": label, "max_length": MAX_LABEL_LENGTH},
                    )
        return v

    @field_validator("metadata")
    @classmethod
    def validate_metadata_size(cls, v: dict[str, Any] | None) -> dict[str, Any] | None:
        return validate_jsonb_size(v, JSONB_METADATA_MAX_BYTES, "metadata")

    @field_validator("data")
    @classmethod
    def validate_data_size(cls, v: dict[str, Any] | None) -> dict[str, Any] | None:
        return validate_jsonb_size(v, JSONB_DOCUMENT_DATA_MAX_BYTES, "data")

    created_at: datetime | None = Field(
        default=None, description="Timestamp when document was created"
    )
    updated_at: datetime | None = Field(
        default=None, description="Timestamp when document was last updated"
    )


class ExtendedDocument:
    """A document extended by its aggregations (related documents).

    Read-only wrapper over a dict with semantic field names. The engine
    resolves slot names to semantic names before construction; partners
    just access data through .get().

    Access patterns:
        # Field access
        doc.get("price_per_kwh")
        doc.get("supplier")
        doc.get("label_1")

        # Related documents
        for inv in doc.aggregations:
            inv.get("price_per_kwh")

        # Escape hatch
        doc.raw["price_per_kwh"]
    """

    def __init__(
        self,
        data: dict[str, Any],
        *,
        aggregations: list[ExtendedDocument] | None = None,
    ):
        """Initialize an ExtendedDocument.

        Partners should NOT construct these directly -- the engine does.

        Args:
            data: Dict with semantic field names (engine resolves slots
                before construction)
            aggregations: List of related ExtendedDocuments
        """
        self._data = data
        self._aggregations = aggregations or []

    # ========================================================================
    # Aggregations
    # ========================================================================

    @property
    def aggregations(self) -> list[ExtendedDocument]:
        """Related documents (e.g., invoices linked to a contract)."""
        return self._aggregations

    # ========================================================================
    # Semantic field access
    # ========================================================================

    def get(self, field_name: str) -> Any:
        """Get a field value by name.

        Args:
            field_name: Field name (e.g., "price_per_kwh", "supplier")

        Returns:
            Field value, or None if not found
        """
        return self._data.get(field_name)

    # ========================================================================
    # Escape hatch
    # ========================================================================

    @property
    def raw(self) -> dict[str, Any]:
        """Access the underlying silver tier dict directly.

        Use this as an escape hatch when you need access to fields
        not covered by the semantic API.
        """
        return self._data

    def __repr__(self) -> str:
        doc_id = str(self._data.get("document_id", ""))[:8]
        labels = "/".join(
            filter(None, [
                self._data.get("label_1"),
                self._data.get("label_2"),
                self._data.get("label_3"),
                self._data.get("label_4"),
            ])
        )
        return f"ExtendedDocument(id={doc_id}..., labels={labels})"


class ScoredDocument:
    """A document paired with its calculated score.

    Used in compute() to give benchmarks access to both the document
    and its score, enabling weighted or document-aware aggregation
    strategies beyond simple score lists.

    Attributes:
        document: The scored ExtendedDocument (with aggregations, fields, etc.)
        score: The float score calculated by score()
    """

    __slots__ = ("document", "score")

    def __init__(self, document: ExtendedDocument, score: float):
        self.document = document
        self.score = score

    def __repr__(self) -> str:
        doc_id = str(self.document.get("document_id") or "")[:8]
        return f"ScoredDocument(id={doc_id}..., score={self.score})"
