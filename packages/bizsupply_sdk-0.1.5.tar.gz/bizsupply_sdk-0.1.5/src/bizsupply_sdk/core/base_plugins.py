"""Base plugin classes for bizSupply plugin development.

This module contains the abstract base classes that all plugins must inherit from:
- BasePlugin: Common functionality for all plugins
- SourcePlugin: For ingesting documents from external sources
- ClassificationPlugin: For categorizing documents
- ExtractionPlugin: For extracting structured data

Each plugin type has specific methods and requirements documented in its class.

Each plugin type has a dedicated lifecycle method:
- SourcePlugin: Implement fetch() and has_new_data()
- ClassificationPlugin: Implement classify()
- ExtractionPlugin: Implement extract()

The engine controls the lifecycle - fetching credentials, state, content,
and handling persistence. Developers only write business logic.
"""

from __future__ import annotations

import json
import logging
from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, Any, AsyncIterator, ClassVar

from pydantic import BaseModel, Field

from bizsupply_sdk.core.credentials import DynamicCredential
from bizsupply_sdk.core.document import Document
from bizsupply_sdk.core.ontology import OntologyManifest, OntologyField
from bizsupply_sdk.core.plugin_type import PluginType
from bizsupply_sdk.core.results import ClassificationResult, DocumentInput, ExtractionResult
from bizsupply_sdk.core.source_state import BaseSourceState

if TYPE_CHECKING:
    from bizsupply_sdk.protocols import PluginServicesProtocol


class ConfigurableParameter(BaseModel):
    """Runtime-configurable parameter that users can override.

    Plugins can declare configurable parameters that users can customize
    when executing the plugin through the platform UI or API.

    Attributes:
        parameter_name: Name of the parameter (used in context.plugin_configs)
        parameter_type: Type hint for the UI ('string', 'int', 'float', 'bool')
        default_value: Default value if user doesn't override
        description: Human-readable description for the UI

    Example:
        class MyClassifier(ClassificationPlugin):
            configurable_parameters = [
                ConfigurableParameter(
                    parameter_name="confidence_threshold",
                    parameter_type="float",
                    default_value=0.8,
                    description="Minimum confidence score for classification",
                ),
                ConfigurableParameter(
                    parameter_name="max_labels",
                    parameter_type="int",
                    default_value=5,
                    description="Maximum number of labels to assign",
                ),
            ]

            async def classify(
                self,
                document: Document,
                file_data: bytes | None,
                mime_type: str | None,
                available_labels: list[str],
                current_path: list[str],
                configs: dict[str, Any],
            ) -> str | None:
                # Access configured values from configs parameter
                threshold = configs.get("confidence_threshold", 0.8)
                max_labels = configs.get("max_labels", 5)
                ...
    """

    model_config = {"extra": "forbid"}

    parameter_name: str = Field(
        ...,
        min_length=1,
        max_length=100,
        description="Parameter name (used in context.plugin_configs)",
    )
    parameter_type: str = Field(
        ...,
        max_length=20,
        description="Type of the parameter: 'string', 'int', 'float', 'bool'",
    )
    default_value: Any = Field(
        ...,
        description="Default value when user doesn't provide one",
    )
    description: str = Field(
        ...,
        min_length=1,
        max_length=2000,
        description="Human-readable description shown in UI",
    )


class BasePlugin(ABC):
    """Base class for all plugins.

    Plugins process documents using lifecycle methods specific to their type.
    Service functions are injected at runtime by the platform.

    Class Attributes:
        configurable_parameters: Optional list of ConfigurableParameter for
            runtime-configurable settings that users can override

    Instance Attributes:
        services: Service context providing access to platform services
        logger: Logger instance for plugin-specific logging

    Required Methods (per plugin type):
        - SourcePlugin: fetch(), has_new_data()
        - ClassificationPlugin: classify()
        - ExtractionPlugin: extract()

    The Engine controls the lifecycle - fetching credentials, state, content,
    and handling persistence. Developers only write business logic.

    Example:
        class MyClassifier(ClassificationPlugin):
            configurable_parameters = [
                ConfigurableParameter(
                    parameter_name="classification_prompt",
                    parameter_type="str",
                    description="Prompt ID for classification",
                ),
            ]

            async def classify(
                self,
                document: Document,
                file_data: bytes | None,
                mime_type: str | None,
                available_labels: list[str],
                current_path: list[str],
                configs: dict[str, Any],
            ) -> str | None:
                # Just pick from available_labels - Engine handles traversal
                response = await self.prompt_llm(
                    prompt=f"Options: {available_labels}",
                    file_data=file_data,
                    mime_type=mime_type,
                )
                return response.get("category")  # str or None
    """

    # Plugin type identifier - MUST be set by subclasses (SourcePlugin, ClassificationPlugin, etc.)
    _plugin_type: ClassVar[PluginType]

    # Optional: Runtime-configurable parameters that users can override
    # Define in subclass to expose configuration options in the platform UI
    configurable_parameters: ClassVar[list[ConfigurableParameter]] = []

    def __init__(self) -> None:
        self.services: PluginServicesProtocol | None = None
        self._logger: logging.Logger | None = None

    @property
    def logger(self) -> logging.Logger:
        """Get a logger specific to this plugin instance.

        Creates a hierarchical logger name: bizsupply_sdk.plugins.{type}.{class_name}

        Returns:
            Logger instance with plugin-specific name
        """
        if self._logger is None:
            self._logger = logging.getLogger(
                f"bizsupply_sdk.plugins.{self._plugin_type.value}.{self.__class__.__name__}"
            )
        return self._logger

    def _set_services(self, services: PluginServicesProtocol) -> None:
        """Internal method for PluginRegistry to inject service functions.

        Args:
            services: Service context implementing PluginServicesProtocol
        """
        self.services = services

    async def prompt_llm(
        self,
        prompt: str,
        file_data: bytes | None = None,
        mime_type: str | None = None,
        schema: type[BaseModel] | dict[str, Any] | None = None,
        model_name: str | None = None,
    ) -> dict | list | None:
        """Send a prompt to an LLM and get a parsed JSON response.

        Simplified API for plugin developers. The platform handles caching,
        provider selection, and other optimizations automatically.

        Args:
            prompt: The prompt text to send
            file_data: Optional file bytes to include (for vision/multimodal)
            mime_type: MIME type of file_data (e.g., "application/pdf", "image/png")
            schema: Optional Pydantic model or dict schema for structured output
            model_name: Optional model name override (e.g., 'gemini-2.5-flash-lite').
                        Must be an allowed model. Default: gemini-2.5-flash.

        Returns:
            Parsed JSON (dict or list), or None if LLM fails or parsing fails

        Raises:
            RuntimeError: If services not initialized

        Example:
            # Text-only prompt
            result = await self.prompt_llm(prompt="Classify this: {content}")
            if result:
                category = result.get("category")

            # With file data (multimodal)
            result = await self.prompt_llm(
                prompt="Extract data from this document",
                file_data=pdf_bytes,
                mime_type="application/pdf",
            )

            # With schema for structured output
            class ExtractionSchema(BaseModel):
                vendor_name: str
                amount: float

            result = await self.prompt_llm(
                prompt="Extract vendor and amount",
                schema=ExtractionSchema,
            )
        """
        if not self.services:
            raise RuntimeError("Services not initialized. Verify that _set_services() was called.")

        response = await self.services.prompt_llm(
            prompt=prompt,
            file_data=file_data,
            mime_type=mime_type,
            schema=schema,
            model_name=model_name,
        )

        if not response:
            self.logger.error("LLM returned empty response")
            return None

        try:
            return json.loads(response)
        except json.JSONDecodeError as e:
            self.logger.error(f"Failed to parse LLM response as JSON: {e}")
            return None

    async def get_prompt(self, prompt_id: str) -> str:
        """Retrieve a prompt template by ID.

        Args:
            prompt_id: The prompt identifier

        Returns:
            The prompt template content as string

        Raises:
            RuntimeError: If services not initialized
            Exception: If prompt not found
        """
        if not self.services:
            raise RuntimeError("Services not initialized. Verify that _set_services() was called.")

        return await self.services.get_prompt_content(prompt_id)

    def format_fields_for_prompt(self, fields: list[OntologyField]) -> str:
        """Format ontology fields as JSON for inclusion in prompts.

        Converts a list of OntologyField objects into a JSON string suitable
        for inclusion in LLM prompts. Uses 'type' as the key name for data type
        to be more intuitive in prompts.

        Args:
            fields: List of OntologyField objects

        Returns:
            JSON string with field definitions

        Example:
            fields = self.get_ontology_fields_by_labels(doc.labels, ontologies)
            prompt = f"Extract these fields: {self.format_fields_for_prompt(fields)}"
        """
        return json.dumps(
            [
                {"name": f.name, "type": f.dtype, "description": f.description}
                for f in fields
            ],
            indent=2,
        )

class SourcePlugin(BasePlugin):
    """Base class for source plugins that ingest documents.

    Source plugins fetch documents from external sources (APIs, files, etc.).
    The Engine handles document creation, state persistence, and error handling.

    Required Class Attributes:
        source_type: Unique identifier for this source (e.g., "gmail", "salesforce")
        source_state_model: A Pydantic model class inheriting from BaseSourceState

    Optional Class Attributes:
        credential_fields: List of credential field names (strings)
        configurable_parameters: List of ConfigurableParameter for runtime config

    Required Methods:
        fetch(credentials, state, configs) -> AsyncIterator[DocumentInput]
        has_new_data(credentials, state, configs) -> bool  (for auto-sync)

    What the Engine Does:
        1. Fetches credentials via credential_manager
        2. Fetches state via user_sources_manager -> typed model
        3. Calls plugin.fetch(credentials, state, configs)
        4. For each yielded DocumentInput:
           - Creates document via documents_manager
           - Streams result to pipeline
        5. Saves state via user_sources_manager after each document

    Example:
        class MySourceState(BaseSourceState):
            cursor: str | None = None
            last_sync: datetime | None = None

        class MySourcePlugin(SourcePlugin):
            source_type = "my_api"
            source_state_model = MySourceState
            credential_fields = ["api_key", "api_url"]
            configurable_parameters = [
                {"parameter_name": "batch_size", "parameter_type": "int", ...},
            ]

            async def fetch(
                self,
                credentials: DynamicCredential,
                state: MySourceState,
                configs: dict[str, Any],
            ) -> AsyncIterator[DocumentInput]:
                api = MyAPI(credentials.api_key)
                batch_size = configs.get("batch_size", 100)

                for item in api.list_items(since=state.cursor, limit=batch_size):
                    yield DocumentInput(
                        file_data=item.content,
                        filename=item.name,
                        metadata={"source_id": item.id},
                    )
                    # Update state cursor (Engine saves automatically)
                    state.cursor = item.id

            async def has_new_data(
                self,
                credentials: DynamicCredential,
                state: MySourceState,
                configs: dict[str, Any],
            ) -> bool:
                api = MyAPI(credentials.api_key)
                return api.has_updates_since(state.cursor)
    """

    _plugin_type = PluginType.source

    # REQUIRED for source plugins: Unique identifier for this source type
    # Used for credential lookup and state management
    source_type: ClassVar[str]

    # Optional: Credential field names that users must configure for this source
    # The platform will prompt users to provide these credentials
    credential_fields: ClassVar[list[str]] = []

    # REQUIRED: Subclasses must define their state model for tracking sync progress
    source_state_model: ClassVar[type[BaseSourceState] | None] = None

    @abstractmethod
    async def fetch(
        self,
        credentials: DynamicCredential,
        state: BaseSourceState,
        configs: dict[str, Any],
    ) -> AsyncIterator[DocumentInput]:
        """Yield documents to create. Engine handles persistence and state.

        REQUIRED: All source plugins must implement this method.

        The Engine:
        1. Injects credentials, state, and configs automatically
        2. Creates documents from each yielded DocumentInput
        3. Saves state after each document (crash-resilient)
        4. Handles errors and retries

        Args:
            credentials: DynamicCredential injected by Engine
            state: Typed state injected by Engine (your source_state_model)
            configs: Runtime configuration (batch sizes, filters, etc.)

        Yields:
            DocumentInput for each document to create

        Example:
            async def fetch(self, credentials, state, configs):
                api = MyAPI(credentials.api_key)
                batch_size = configs.get("batch_size", 100)

                for item in api.list_items(since=state.cursor, limit=batch_size):
                    yield DocumentInput(
                        file_data=item.content,
                        filename=item.name,
                        metadata={"source_id": item.id},
                    )
                    state.cursor = item.id  # Engine saves this automatically
        """
        # This yield is here to make the type checker happy
        # Subclasses MUST override this method
        yield  # type: ignore[misc]

    @abstractmethod
    async def has_new_data(
        self,
        credentials: DynamicCredential,
        state: BaseSourceState,
        configs: dict[str, Any],
    ) -> bool:
        """Check if source has new data since last sync.

        REQUIRED: All source plugins must implement this for auto-sync.
        This is called by the auto-sync service to determine if a pipeline
        should be triggered.

        Args:
            credentials: DynamicCredential injected by Engine
            state: Current typed state from database
            configs: Runtime configuration

        Returns:
            True if new data exists, False otherwise

        Example:
            async def has_new_data(self, credentials, state, configs) -> bool:
                api = MyAPI(credentials.api_key)
                latest = await api.get_latest_item_date()
                return latest > state.last_sync if state.last_sync else True
        """
        ...


class ClassificationPlugin(BasePlugin):
    """Base class for classification plugins.

    Classification plugins implement classify() to handle one level
    of the ontology hierarchy at a time. The Engine handles traversal.

    Required Methods:
        classify(document, file_data, mime_type, available_labels, current_path, configs) -> str | None

    What the Engine Does:
        1. Fetches document file_data ONCE for all levels via documents_manager
        2. Traverses ontology tree, calling classify() at each level
        3. Builds the full classification path from your responses
        4. Handles llm_suggested labels when you return a non-ontology label
        5. Triggers suggestion workflow when you return None
        6. Persists classification via documents_manager

    Optional Helper Methods:
        prompt_llm(): Use LLM for classification (supports PDF via file_data)
        get_prompt(): Fetch prompt template by ID

    Example:
        class MyClassifier(ClassificationPlugin):
            configurable_parameters = [
                {"parameter_name": "classification_prompt", "parameter_type": "str", ...},
            ]

            async def classify(
                self,
                document: Document,
                file_data: bytes | None,
                mime_type: str | None,
                available_labels: list[str],
                current_path: list[str],
                configs: dict[str, Any],
            ) -> str | None:
                # Get prompt from configs
                prompt_id = configs.get("classification_prompt")
                prompt_template = await self.get_prompt(prompt_id) if prompt_id else None

                # Just pick from available_labels - Engine handles traversal
                path_str = " > ".join(current_path) if current_path else "Root"
                response = await self.prompt_llm(
                    prompt=f"Path: {path_str}\\nOptions: {available_labels}",
                    file_data=file_data,
                    mime_type=mime_type,
                )
                return response.get("category")  # str or None
    """

    _plugin_type = PluginType.classification

    @abstractmethod
    async def classify(
        self,
        document: Document,
        file_data: bytes | None,
        mime_type: str | None,
        available_labels: list[str],
        current_path: list[str],
        configs: dict[str, Any],
    ) -> str | None:
        """Classify at a single hierarchy level.

        REQUIRED: All classification plugins must implement this method.

        The Engine calls this method once per level of the ontology tree.
        You simply pick from the available labels at each level.

        Args:
            document: The document being classified
            file_data: Raw file bytes (Gemini can read PDFs directly)
            mime_type: File MIME type (e.g., "application/pdf")
            available_labels: Ontology labels at this level (no "other")
            current_path: Labels already selected (path so far, e.g., ["Energy", "Contract"])
            configs: Runtime configuration (prompt IDs, thresholds, etc.)

        Returns:
            - Label from available_labels: Engine continues traversal to children
            - Label NOT in available_labels: tracked as llm_suggested, traversal stops
            - None: Engine triggers suggestion workflow, traversal stops

        Example:
            async def classify(self, document, file_data, mime_type, available_labels, current_path, configs):
                prompt_id = configs.get("classification_prompt")
                result = await self.prompt_llm(
                    prompt=f"Select from {available_labels}",
                    file_data=file_data,
                    mime_type=mime_type,
                )
                return result.get("category")  # str or None
        """
        ...


class ExtractionPlugin(BasePlugin):
    """Base class for extraction plugins.

    Extraction plugins extract structured data from documents based on
    their classification and the corresponding ontology fields.
    The Engine handles field resolution and persistence.

    Required Methods:
        extract(document, file_data, mime_type, fields, configs) -> ExtractionResult

    What the Engine Does:
        1. Skips documents without labels
        2. Resolves fields from ontology (based on document.labels)
        3. Fetches document file_data via documents_manager
        4. Calls plugin.extract(document, file_data, mime_type, fields, configs)
        5. Persists extracted data via documents_manager
        6. Returns updated document to pipeline

    Optional Helper Methods:
        prompt_llm(): Use LLM for extraction (supports PDF via file_data)
        format_fields_for_prompt(): Format OntologyFields as JSON for prompts
        get_prompt(): Fetch prompt template by ID

    Example:
        class MyExtractor(ExtractionPlugin):
            configurable_parameters = [
                {"parameter_name": "extraction_prompt", "parameter_type": "str", ...},
            ]

            async def extract(
                self,
                document: Document,
                file_data: bytes | None,
                mime_type: str | None,
                fields: list[OntologyField],
                configs: dict[str, Any],
            ) -> ExtractionResult:
                if not fields:
                    return ExtractionResult(data={})

                # Get prompt from configs
                prompt_id = configs.get("extraction_prompt")

                fields_json = self.format_fields_for_prompt(fields)
                response = await self.prompt_llm(
                    prompt=f"Extract these fields: {fields_json}",
                    file_data=file_data,
                    mime_type=mime_type,
                )
                return ExtractionResult(
                    data=response or {},
                    llm_fields=list(response.keys()) if response else None,
                )
    """

    _plugin_type = PluginType.extraction

    @abstractmethod
    async def extract(
        self,
        document: Document,
        file_data: bytes | None,
        mime_type: str | None,
        fields: list[OntologyField],
        configs: dict[str, Any],
    ) -> ExtractionResult:
        """Extract data from a single document and return extracted values.

        REQUIRED: All extraction plugins must implement this method.

        The Engine:
        1. Injects document, file_data, mime_type, fields, and configs
        2. Calls add_document_data() with your result
        3. Syncs to silver tier if applicable
        4. Handles errors and returns updated document

        Args:
            document: The document to extract from (already classified)
            file_data: Raw file bytes (Gemini can read PDFs directly)
            mime_type: MIME type of file_data (e.g., "application/pdf")
            fields: OntologyFields to extract (resolved from document.labels)
            configs: Runtime configuration (prompt IDs, thresholds, etc.)

        Returns:
            ExtractionResult with data dict and optional llm_fields

        Example:
            async def extract(self, document, file_data, mime_type, fields, configs):
                prompt_id = configs.get("extraction_prompt")
                fields_json = self.format_fields_for_prompt(fields)
                response = await self.prompt_llm(
                    prompt=f"Extract: {fields_json}",
                    file_data=file_data,
                    mime_type=mime_type,
                )
                return ExtractionResult(data=response or {})
        """
        ...
