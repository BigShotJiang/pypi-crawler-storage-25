"""Core SDK modules - base classes, models, and types.

This module contains the source of truth for all plugin-related
classes and models used by both the SDK and the internal app.
"""

from bizsupply_sdk.core.plugin_type import PluginType
from bizsupply_sdk.core.document import Document
from bizsupply_sdk.core.ontology import (
    OntologyField,
    OntologyNode,
    OntologyManifest,
)
from bizsupply_sdk.core.source_state import BaseSourceState
from bizsupply_sdk.core.credentials import DynamicCredential
from bizsupply_sdk.core.base_plugins import ConfigurableParameter
from bizsupply_sdk.core.base_plugins import (
    BasePlugin,
    SourcePlugin,
    ClassificationPlugin,
    ExtractionPlugin,
)
from bizsupply_sdk.core.results import (
    DocumentInput,
    ClassificationResult,
    ExtractionResult,
)
from bizsupply_sdk.core.base_benchmark import BaseBenchmark
from bizsupply_sdk.core.document import ExtendedDocument, ScoredDocument
from bizsupply_sdk.core.aggregation import MatchCondition, MatchRule

__all__ = [
    # Plugin Types
    "PluginType",
    # Base Plugin Classes
    "BasePlugin",
    "SourcePlugin",
    "ClassificationPlugin",
    "ExtractionPlugin",
    # Configuration Models
    "ConfigurableParameter",
    # Core Models
    "Document",
    "BaseSourceState",
    "DynamicCredential",
    # Result Models (new lifecycle contracts)
    "DocumentInput",
    "ClassificationResult",
    "ExtractionResult",
    # Ontology Models
    "OntologyField",
    "OntologyNode",
    "OntologyManifest",
    # Benchmark Models
    "BaseBenchmark",
    "ExtendedDocument",
    "ScoredDocument",
    # Aggregation Models
    "MatchCondition",
    "MatchRule",
]
