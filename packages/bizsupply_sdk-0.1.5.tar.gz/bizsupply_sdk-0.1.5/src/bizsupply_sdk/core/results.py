"""Result models for the new plugin lifecycle contracts.

These models define the return types for the new plugin methods:
- DocumentInput: Returned by source plugins' fetch() method
- ClassificationResult: Returned by classification plugins' classify() method
- ExtractionResult: Returned by extraction plugins' extract() method

These models allow developers to focus on business logic while the Engine
handles persistence, state management, and lifecycle coordination.
"""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, Field, field_validator

from bizsupply_sdk.constants import (
    JSONB_DOCUMENT_DATA_MAX_BYTES,
    JSONB_METADATA_MAX_BYTES,
    MAX_DOCUMENT_LABELS,
    MAX_FILENAME_LENGTH,
    MAX_LABEL_LENGTH,
    MAX_NAME_LENGTH,
)
from bizsupply_sdk.exceptions import FieldSizeExceededError
from bizsupply_sdk.validators import validate_jsonb_size


class DocumentInput(BaseModel):
    """Input for creating a document (source plugins).

    Returned by source plugins' fetch() method. The Engine handles:
    - Calling create_document() with these parameters
    - State persistence after each document
    - Error handling and retry logic

    Example:
        async def fetch(self, credentials, state):
            for item in fetch_items():
                yield DocumentInput(
                    file_data=item.content,
                    filename=item.name,
                    metadata={"source_id": item.id},
                )
                state.cursor = item.id
    """

    file_data: bytes = Field(..., description="Raw file content as bytes")
    filename: str = Field(
        ...,
        max_length=MAX_FILENAME_LENGTH,
        description="Original filename (must include extension, e.g., 'invoice.pdf')",
    )
    mime_type: str | None = Field(
        default=None,
        max_length=100,
        description="MIME type of the file (e.g., 'application/pdf'). If not provided, inferred from content.",
    )
    metadata: dict[str, Any] | None = Field(
        default=None,
        description="Optional metadata to attach to the document",
    )

    model_config = {"extra": "forbid", "arbitrary_types_allowed": True}

    @field_validator("metadata")
    @classmethod
    def validate_metadata_size(cls, v: dict[str, Any] | None) -> dict[str, Any] | None:
        return validate_jsonb_size(v, JSONB_METADATA_MAX_BYTES, "metadata")


class ClassificationResult(BaseModel):
    """Internal model used by the Engine to store classification results.

    NOTE: Classification plugins now return `str | None` from classify(),
    not ClassificationResult. The Engine builds this internally from the
    accumulated classification path.

    The Engine handles:
    - Traversing the ontology tree
    - Calling classify() at each level
    - Building the classification path from individual label returns
    - Tracking LLM-generated labels for provenance
    - Persisting via add_document_classification()
    """

    model_config = {"extra": "forbid"}

    labels: list[str] = Field(
        ...,
        max_length=MAX_DOCUMENT_LABELS,
        description="List of classification labels (hierarchical order)",
    )
    llm_labels: list[str] | None = Field(
        default=None,
        max_length=MAX_DOCUMENT_LABELS,
        description="Labels suggested by LLM that are not in the ontology (for tracking)",
    )

    @field_validator("labels")
    @classmethod
    def validate_label_lengths(cls, v: list[str]) -> list[str]:
        for label in v:
            if len(label) > MAX_LABEL_LENGTH:
                raise FieldSizeExceededError(
                    f"Label '{label}' exceeds max length of {MAX_LABEL_LENGTH}",
                    details={"field": "labels", "value": label, "max_length": MAX_LABEL_LENGTH},
                )
        return v

    @field_validator("llm_labels")
    @classmethod
    def validate_llm_label_lengths(cls, v: list[str] | None) -> list[str] | None:
        if v is not None:
            for label in v:
                if len(label) > MAX_LABEL_LENGTH:
                    raise FieldSizeExceededError(
                        f"LLM label '{label}' exceeds max length of {MAX_LABEL_LENGTH}",
                        details={"field": "llm_labels", "value": label, "max_length": MAX_LABEL_LENGTH},
                    )
        return v


class ExtractionResult(BaseModel):
    """Result from extracting data from a document.

    Returned by extraction plugins' extract() method. The Engine handles:
    - Calling add_document_data() with the extracted data
    - Tracking LLM-generated fields for provenance
    - Syncing to silver tier if applicable
    - Returning the updated document

    Example:
        async def extract(self, document, file_data, mime_type, fields, configs):
            response = await self.prompt_llm(...)
            return ExtractionResult(
                data=response or {},
                llm_fields=list(response.keys()) if response else None,
            )
    """

    model_config = {"extra": "forbid"}

    data: dict[str, Any] = Field(
        ...,
        description="Dictionary of field_name -> extracted_value pairs",
    )
    llm_fields: list[str] | None = Field(
        default=None,
        max_length=200,
        description="Field names that were LLM-extracted but not in ontology (for tracking)",
    )
    document_type: str | None = Field(
        default=None,
        max_length=MAX_NAME_LENGTH,
        description="Document type for silver tier mapping (inferred from labels if not provided)",
    )

    @field_validator("data")
    @classmethod
    def validate_data_size(cls, v: dict[str, Any]) -> dict[str, Any]:
        return validate_jsonb_size(v, JSONB_DOCUMENT_DATA_MAX_BYTES, "data")

    @field_validator("llm_fields")
    @classmethod
    def validate_llm_field_lengths(cls, v: list[str] | None) -> list[str] | None:
        if v is not None:
            for field_name in v:
                if len(field_name) > MAX_NAME_LENGTH:
                    raise FieldSizeExceededError(
                        f"LLM field '{field_name}' exceeds max length of {MAX_NAME_LENGTH}",
                        details={"field": "llm_fields", "value": field_name, "max_length": MAX_NAME_LENGTH},
                    )
        return v
