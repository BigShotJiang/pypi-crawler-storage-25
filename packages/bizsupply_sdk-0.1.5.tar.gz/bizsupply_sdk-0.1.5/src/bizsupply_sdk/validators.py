"""Shared validators for SDK and app Pydantic models.

Single source of truth for JSONB byte-size validation. Both the SDK models
and the app (via re-export) use this function.
"""

from __future__ import annotations

import json
from typing import Any

from bizsupply_sdk.exceptions import JsonbSizeExceededError


def validate_jsonb_size(
    v: dict[str, Any] | None,
    max_bytes: int,
    field_name: str,
) -> dict[str, Any] | None:
    """Validate that a dict field does not exceed a JSONB byte size limit.

    Args:
        v: The dict value to validate (None values pass through).
        max_bytes: Maximum allowed size in bytes.
        field_name: Human-readable field name for error messages.

    Returns:
        The original value if valid.

    Raises:
        JsonbSizeExceededError: If serialized JSON exceeds max_bytes.
    """
    if v is None:
        return v
    size = len(json.dumps(v, default=str).encode("utf-8"))
    if size > max_bytes:
        raise JsonbSizeExceededError(
            f"{field_name} exceeds maximum size of {max_bytes} bytes "
            f"(actual: {size} bytes)",
            details={
                "field_name": field_name,
                "max_bytes": max_bytes,
                "actual_bytes": size,
            },
        )
    return v
