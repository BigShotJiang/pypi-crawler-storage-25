"""Pytest fixtures for plugin testing.

These fixtures are automatically available when using pytest with the SDK.
Import them in your conftest.py or test files.

Example conftest.py:
    from bizsupply_sdk.testing.fixtures import (
        mock_services,
        sample_document,
        sample_ontology,
    )
"""

from __future__ import annotations

import pytest

from bizsupply_sdk.testing.mock_services import MockPluginServices
from bizsupply_sdk.testing.factories import (
    create_test_document,
    create_test_ontology,
)
from bizsupply_sdk.core.document import Document
from bizsupply_sdk.core.ontology import OntologyManifest


@pytest.fixture
def mock_services() -> MockPluginServices:
    """Provide a fresh MockPluginServices instance.

    Usage:
        async def test_my_plugin(mock_services):
            plugin = mock_services.configure_plugin(MyPlugin())
            # ... test ...
    """
    return MockPluginServices()


@pytest.fixture
def mock_llm_services() -> MockPluginServices:
    """Provide MockPluginServices with sample LLM responses.

    Pre-configured with common response patterns for testing
    classification and extraction plugins.

    Usage:
        async def test_classification(mock_llm_services):
            plugin = mock_llm_services.configure_plugin(MyClassifier())
            # LLM calls will return pre-configured responses
    """
    return MockPluginServices(
        llm_responses={
            "default": '{"response": "default mock response"}',
            "classification": '{"labels": ["Contract", "Energy"]}',
            "extraction": '{"vendor": "ACME Corp", "amount": 1000.00}',
        }
    )


@pytest.fixture
def sample_document() -> Document:
    """Provide a sample document for testing.

    Usage:
        async def test_with_document(sample_document):
            assert sample_document.document_id is not None
    """
    return create_test_document(
        filename="sample_contract.pdf",
        metadata={"source": "test"},
    )


@pytest.fixture
def sample_ontology() -> OntologyManifest:
    """Provide a sample ontology for testing.

    Contains a hierarchy:
    - Document
      - Contract (fields: contract_date)
        - Energy (fields: contract_value, start_date)
        - Water
      - Invoice (fields: amount, vendor)

    Usage:
        async def test_with_ontology(sample_ontology):
            labels = sample_ontology.taxonomy.get_leaf_labels()
    """
    return create_test_ontology()


@pytest.fixture
def classified_document() -> Document:
    """Provide a document with classification labels.

    Useful for testing extraction plugins that require classified input.
    """
    return create_test_document(
        filename="classified_document.pdf",
        labels=["Document", "Contract", "Energy"],
    )


@pytest.fixture
def extracted_document() -> Document:
    """Provide a document with extracted data.

    Useful for testing plugins that require documents with pre-extracted data.
    """
    return create_test_document(
        filename="extracted_document.pdf",
        labels=["Document", "Invoice"],
        data={
            "vendor": "ACME Corp",
            "amount": 5000.00,
            "date": "2024-01-15",
        },
    )


@pytest.fixture
def source_plugin_services() -> MockPluginServices:
    """Provide MockPluginServices for source plugin testing.

    Note: Source plugins receive credentials and state as
    parameters injected by the engine. Use DynamicCredential and
    BaseSourceState directly in your tests.

    Usage:
        from bizsupply_sdk import DynamicCredential, BaseSourceState

        async def test_source_fetch(source_plugin_services):
            plugin = source_plugin_services.configure_plugin(MySource())
            creds = DynamicCredential(api_key="test-key", api_url="https://api.example.com")
            state = MySourceState(cursor=None)
            async for doc in plugin.fetch(creds, state, {}):
                # ... test ...
    """
    return MockPluginServices()
