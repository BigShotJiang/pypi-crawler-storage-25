"""Factory functions for creating test data.

These functions make it easy to create test documents and
ontologies with sensible defaults while allowing customization.
"""

from __future__ import annotations

import uuid
from datetime import datetime
from typing import Any

from bizsupply_sdk.core.document import ExtendedDocument, ScoredDocument
from bizsupply_sdk.core.document import Document
from bizsupply_sdk.core.ontology import (
    OntologyManifest,
    OntologyField,
    OntologyNode,
)


def create_test_document(
    document_id: str | None = None,
    filename: str = "test_document.pdf",
    metadata: dict[str, Any] | None = None,
    labels: list[str] | None = None,
    data: dict[str, Any] | None = None,
    content: str | None = None,
) -> Document:
    """Create a test document with sensible defaults.

    Args:
        document_id: Document ID (auto-generated if not provided)
        filename: Original filename (default: "test_document.pdf")
        metadata: Custom metadata dict
        labels: Classification labels
        data: Extracted data fields
        content: Ignored - use MockPluginServices.set_document_content()

    Returns:
        Document for use in tests

    Example:
        doc = create_test_document(
            filename="invoice.pdf",
            labels=["Contract", "Energy"],
            data={"vendor": "ACME Corp"}
        )
    """
    now = datetime.now()
    return Document(
        document_id=document_id or str(uuid.uuid4()),
        original_filename=filename,
        metadata=metadata or {},
        labels=labels or [],
        data=data or {},
        created_at=now,
        updated_at=now,
    )


def create_test_ontology(
    name: str = "Test Ontology",
    description: str | None = "Test ontology for plugin testing",
    taxonomy: OntologyNode | None = None,
) -> OntologyManifest:
    """Create a test ontology with a simple hierarchy.

    If no taxonomy is provided, creates a sample hierarchy:
    - Document
      - Contract
        - Energy (fields: contract_value, start_date)
        - Water
      - Invoice (fields: amount, vendor)

    Args:
        name: Ontology name
        description: Ontology description
        taxonomy: Custom taxonomy root node (uses default if not provided)

    Returns:
        OntologyManifest for use in tests

    Example:
        # Use default hierarchy
        ontology = create_test_ontology()

        # Custom hierarchy
        custom_taxonomy = OntologyNode(
            label="MyRoot",
            children=[
                OntologyNode(label="Child1"),
                OntologyNode(label="Child2"),
            ]
        )
        ontology = create_test_ontology(taxonomy=custom_taxonomy)
    """
    if taxonomy is None:
        taxonomy = OntologyNode(
            label="Document",
            children=[
                OntologyNode(
                    label="Contract",
                    fields=[
                        OntologyField(name="contract_date", dtype="date"),
                    ],
                    children=[
                        OntologyNode(
                            label="Energy",
                            fields=[
                                OntologyField(
                                    name="contract_value",
                                    dtype="float",
                                    description="Total contract value",
                                ),
                                OntologyField(
                                    name="start_date",
                                    dtype="date",
                                    description="Contract start date",
                                ),
                            ],
                        ),
                        OntologyNode(label="Water"),
                    ],
                ),
                OntologyNode(
                    label="Invoice",
                    fields=[
                        OntologyField(
                            name="amount",
                            dtype="float",
                            description="Invoice amount",
                        ),
                        OntologyField(
                            name="vendor",
                            dtype="string",
                            description="Vendor name",
                        ),
                    ],
                ),
            ],
        )

    now = datetime.now()
    return OntologyManifest(
        ontology_id=str(uuid.uuid4()),
        name=name,
        description=description,
        taxonomy=taxonomy,
        created_at=now,
        updated_at=now,
    )


def create_test_documents_batch(
    count: int = 5,
    filename_prefix: str = "document",
    extension: str = "pdf",
    labels: list[str] | None = None,
) -> list[Document]:
    """Create a batch of test documents.

    Args:
        count: Number of documents to create
        filename_prefix: Prefix for filenames
        extension: File extension
        labels: Labels to apply to all documents

    Returns:
        List of Document objects

    Example:
        docs = create_test_documents_batch(
            count=10,
            filename_prefix="invoice",
            labels=["Invoice"]
        )
    """
    return [
        create_test_document(
            filename=f"{filename_prefix}_{i}.{extension}",
            labels=labels,
        )
        for i in range(count)
    ]


def create_test_silver_document(
    document_id: str | None = None,
    label_1: str = "contract",
    label_2: str = "energy",
    supplier: str = "Test Supplier",
    **slot_overrides: Any,
) -> dict[str, Any]:
    """Create a silver-format test document dict for benchmark testing.

    Silver format documents are plain dicts with generic slots (number_1,
    string_1, etc.) instead of Document objects. This is the format
    benchmarks receive from the engine.

    Args:
        document_id: Document ID (auto-generated if not provided)
        label_1: Root document type (e.g., "contract", "invoice")
        label_2: Sub-type (e.g., "energy", "water")
        supplier: Supplier name (dedicated column)
        **slot_overrides: Override any slot values (e.g., number_1=0.145)

    Returns:
        Silver format dict for use in benchmark tests

    Example:
        doc = create_test_silver_document(
            label_1="invoice",
            label_2="energy",
            supplier="EDP",
            number_1=0.145,  # price_per_kwh
            string_1="INV-001",  # invoice_number
        )
    """
    doc = {
        "document_id": document_id or str(uuid.uuid4()),
        "label_1": label_1,
        "label_2": label_2,
        "label_3": None,
        "label_4": None,
        "supplier": supplier,
    }
    doc.update(slot_overrides)
    return doc


def create_test_silver_documents_batch(
    count: int = 5,
    label_1: str = "contract",
    label_2: str = "energy",
    supplier: str = "Test Supplier",
    **slot_overrides: Any,
) -> list[dict[str, Any]]:
    """Create a batch of silver-format test documents.

    Args:
        count: Number of documents to create
        label_1: Root document type
        label_2: Sub-type
        supplier: Supplier name
        **slot_overrides: Override any slot values for all documents

    Returns:
        List of silver format dicts

    Example:
        docs = create_test_silver_documents_batch(
            count=10,
            label_1="invoice",
            label_2="energy",
            number_1=0.145,
        )
    """
    return [
        create_test_silver_document(
            label_1=label_1,
            label_2=label_2,
            supplier=supplier,
            **slot_overrides,
        )
        for _ in range(count)
    ]


def create_benchmark_document(
    data: dict[str, Any] | None = None,
    aggregations: list[ExtendedDocument] | None = None,
    **overrides: Any,
) -> ExtendedDocument:
    """Create a ExtendedDocument for testing.

    Combines create_test_silver_document defaults with ExtendedDocument
    wrapping for convenient benchmark test setup. Use semantic field names
    directly in data or overrides — no slot mapping needed.

    Args:
        data: Dict with field values (uses defaults if not provided)
        aggregations: List of related ExtendedDocuments
        **overrides: Override any fields in the data dict

    Returns:
        ExtendedDocument for use in benchmark tests

    Example:
        doc = create_benchmark_document(
            aggregations=[
                create_benchmark_document(
                    price_per_kwh=0.145,
                    label_1="invoice",
                ),
                create_benchmark_document(
                    price_per_kwh=0.155,
                    label_1="invoice",
                ),
            ],
        )
        assert doc.aggregations[0].get("price_per_kwh") == 0.145
    """
    if data is None:
        data = create_test_silver_document(**overrides)
    elif overrides:
        data = {**data, **overrides}

    return ExtendedDocument(
        data=data,
        aggregations=aggregations,
    )


def create_scored_document(
    score: float,
    data: dict[str, Any] | None = None,
    aggregations: list[ExtendedDocument] | None = None,
    **overrides: Any,
) -> ScoredDocument:
    """Create a ScoredDocument for testing compute() logic.

    Convenience wrapper that creates a ExtendedDocument and pairs it
    with a score for testing benchmark compute() methods.

    Args:
        score: The document's score value
        data: Dict with field values (uses defaults if not provided)
        aggregations: List of related ExtendedDocuments
        **overrides: Override any fields in the data dict

    Returns:
        ScoredDocument for use in benchmark compute() tests

    Example:
        results = [
            create_scored_document(score=0.15, supplier="EDP"),
            create_scored_document(score=0.20, supplier="Galp"),
        ]
        benchmark_value = my_benchmark.compute(results)
    """
    doc = create_benchmark_document(
        data=data,
        aggregations=aggregations,
        **overrides,
    )
    return ScoredDocument(document=doc, score=score)
