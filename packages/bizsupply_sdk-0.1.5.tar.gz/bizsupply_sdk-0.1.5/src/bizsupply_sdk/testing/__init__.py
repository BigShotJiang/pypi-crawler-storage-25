"""Testing utilities for bizSupply plugin development.

This module provides mock services, fixtures, and utilities for testing
plugins without connecting to the actual platform.

Quick Start:
    from bizsupply_sdk.testing import (
        MockPluginServices,
        create_test_document,
        create_test_ontology,
    )

    @pytest.fixture
    def mock_services():
        return MockPluginServices()

    async def test_my_classifier(mock_services):
        plugin = MyClassifier()
        plugin._set_services(mock_services)

        doc = create_test_document()
        label = await plugin.classify(
            document=doc,
            file_data=b"test content",
            mime_type="application/pdf",
            available_labels=["Contract", "Invoice"],
            current_path=[],
            configs={},
        )
        assert label == "Contract"
"""

from bizsupply_sdk.testing.mock_services import MockPluginServices
from bizsupply_sdk.testing.factories import (
    create_benchmark_document,
    create_scored_document,
    create_test_document,
    create_test_ontology,
    create_test_silver_document,
    create_test_silver_documents_batch,
)
from bizsupply_sdk.testing.fixtures import (
    mock_services,
    mock_llm_services,
    sample_document,
    sample_ontology,
)

__all__ = [
    # Mock Services
    "MockPluginServices",
    # Factories
    "create_benchmark_document",
    "create_scored_document",
    "create_test_document",
    "create_test_ontology",
    "create_test_silver_document",
    "create_test_silver_documents_batch",
    # Fixtures
    "mock_services",
    "mock_llm_services",
    "sample_document",
    "sample_ontology",
]
