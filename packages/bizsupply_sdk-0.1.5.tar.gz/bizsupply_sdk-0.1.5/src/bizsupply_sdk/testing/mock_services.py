"""Mock implementation of PluginServicesProtocol for testing.

MockPluginServices provides an in-memory implementation of the plugin services
for local testing without requiring the actual platform infrastructure.

Implements the 2 methods plugins call directly:
- prompt_llm: Mock LLM responses
- get_prompt_content: Mock prompt templates
"""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel

from bizsupply_sdk.core.base_plugins import BasePlugin


class MockPluginServices:
    """Mock implementation of PluginServicesProtocol for testing.

    Provides configurable mock responses for LLM calls and prompt fetching.
    Tracks calls for test assertions.

    Attributes:
        llm_call_count: Number of LLM calls made

    Example:
        # Basic usage
        mock = MockPluginServices()
        plugin = mock.configure_plugin(MyClassifier())

        # With custom responses
        mock = MockPluginServices(
            llm_responses={"default": '{"category": "Contract"}'},
            prompts={"my-prompt": "Classify this document..."},
        )
        plugin = mock.configure_plugin(MyClassifier())

        # In tests
        result = await plugin.classify(doc, file_data, mime_type, labels, path, configs)
        assert mock.llm_call_count == 1
    """

    def __init__(
        self,
        prompts: dict[str, str] | None = None,
        llm_responses: dict[str, str] | None = None,
    ):
        """Initialize mock services with optional pre-configured data.

        Args:
            prompts: Map of prompt_id -> prompt content
            llm_responses: Map of response key -> LLM response text
                          Use "default" for the default response
        """
        self._prompts = prompts or {}
        self._llm_responses = llm_responses or {"default": "{}"}

        # Tracking
        self.llm_call_count = 0
        self._llm_call_history: list[dict[str, Any]] = []

    async def prompt_llm(
        self,
        prompt: str,
        file_data: bytes | None = None,
        mime_type: str | None = None,
        schema: type[BaseModel] | dict[str, Any] | None = None,
        model_name: str | None = None,
    ) -> str | None:
        """Return configured LLM response.

        Looks up response in order:
        1. Key matching prompt (exact match)
        2. "default" key
        """
        self.llm_call_count += 1
        self._llm_call_history.append({
            "prompt": prompt,
            "has_file": file_data is not None,
            "mime_type": mime_type,
            "has_schema": schema is not None,
            "model_name": model_name,
        })

        # Try exact prompt match
        if prompt in self._llm_responses:
            return self._llm_responses[prompt]

        # Fall back to default
        return self._llm_responses.get("default")

    async def get_prompt_content(self, prompt_id: str) -> str:
        """Return configured prompt content."""
        if prompt_id in self._prompts:
            return self._prompts[prompt_id]
        raise ValueError(f"Prompt not found: {prompt_id}")

    # =========================================================================
    # Test Helpers
    # =========================================================================

    def configure_plugin(self, plugin: BasePlugin) -> BasePlugin:
        """Configure a plugin to use these mock services.

        Args:
            plugin: The plugin instance to configure

        Returns:
            The same plugin instance (for chaining)

        Example:
            mock = MockPluginServices(llm_responses={"default": "{}"})
            plugin = mock.configure_plugin(MyClassifier())
        """
        plugin._set_services(self)
        return plugin

    def set_llm_response(self, key: str, response: str) -> None:
        """Set an LLM response for a specific key."""
        self._llm_responses[key] = response

    def set_prompt(self, prompt_id: str, content: str) -> None:
        """Set a prompt template."""
        self._prompts[prompt_id] = content

    def get_llm_call_history(self) -> list[dict[str, Any]]:
        """Get history of LLM calls for assertions."""
        return self._llm_call_history

    def reset(self) -> None:
        """Reset all tracking."""
        self.llm_call_count = 0
        self._llm_call_history.clear()
