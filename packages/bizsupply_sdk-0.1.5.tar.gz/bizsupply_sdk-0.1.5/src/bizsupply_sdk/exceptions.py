"""SDK exception hierarchy for validation errors.

All exceptions inherit from ValueError so they work inside Pydantic
@field_validator functions (which require ValueError or its subclasses).
Each exception carries an error_code and structured details dict,
matching the project's exception pattern in app/components/exceptions.py.
"""

from __future__ import annotations

from typing import Any


class SDKValidationError(ValueError):
    """Base SDK validation error. Pydantic-compatible (inherits ValueError)."""

    error_code: str = "SDK_VALIDATION_ERROR"

    def __init__(self, message: str, *, details: dict[str, Any] | None = None):
        self.details = details or {}
        super().__init__(message)


class FieldSizeExceededError(SDKValidationError):
    """A string or list field exceeds its maximum allowed length."""

    error_code: str = "FIELD_SIZE_EXCEEDED"


class JsonbSizeExceededError(SDKValidationError):
    """A JSONB/dict field exceeds its maximum allowed byte size."""

    error_code: str = "JSONB_SIZE_EXCEEDED"


class InvalidOperatorError(SDKValidationError):
    """An unknown comparison operator was used in a match condition."""

    error_code: str = "INVALID_OPERATOR"


class MissingFieldError(SDKValidationError):
    """Required credential fields are missing."""

    error_code: str = "MISSING_FIELD"


class InvalidParameterError(SDKValidationError):
    """A plugin configuration parameter has an invalid value."""

    error_code: str = "INVALID_PARAMETER"


class MissingParameterError(SDKValidationError):
    """A required plugin configuration parameter is missing."""

    error_code: str = "MISSING_PARAMETER"
