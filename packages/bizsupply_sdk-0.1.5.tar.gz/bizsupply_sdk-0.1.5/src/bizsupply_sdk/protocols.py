"""Protocol definitions for plugin services.

This module defines the PluginServicesProtocol - the contract that all
service implementations must follow for the plugin-facing API.

The protocol follows the Dependency Inversion Principle:
- SDK defines the interface (protocol)
- App provides the production implementation
- SDK provides mock implementation for testing

The Protocol only contains methods plugins call directly.
Internal engine operations (document creation, classification persistence,
state management) are handled by the platform but not exposed here.
"""

from __future__ import annotations

from typing import Any, Protocol, runtime_checkable

from pydantic import BaseModel


@runtime_checkable
class PluginServicesProtocol(Protocol):
    """Contract for plugin service implementations.

    This protocol defines the interface between plugins and the platform.
    Plugins call these methods via `self.services`.

    API:
    - prompt_llm: Send prompts to LLM (supports multimodal with file_data)
    - get_prompt_content: Fetch prompt templates by ID

    The engine handles everything else (document fetching, persistence,
    state management) and injects what plugins need via method parameters.

    Example usage in a plugin:
        async def classify(self, document, file_data, mime_type, ...):
            # Get prompt template
            prompt = await self.get_prompt(prompt_id)

            # Call LLM with file data
            result = await self.prompt_llm(
                prompt=prompt,
                file_data=file_data,
                mime_type=mime_type,
            )
            return result.get("category")
    """

    async def prompt_llm(
        self,
        prompt: str,
        file_data: bytes | None = None,
        mime_type: str | None = None,
        schema: type[BaseModel] | dict[str, Any] | None = None,
        model_name: str | None = None,
    ) -> str | None:
        """Send a prompt to an LLM and get the response.

        Args:
            prompt: The prompt text to send
            file_data: Optional file bytes for multimodal prompts (e.g., PDF)
            mime_type: MIME type of file_data (e.g., "application/pdf")
            schema: Optional Pydantic model or dict schema for structured output
            model_name: Optional model name override (e.g., 'gemini-2.5-flash-lite').
                        Must be an allowed model. Default: gemini-2.5-flash.

        Returns:
            LLM response as string, or None if failed
        """
        ...

    async def get_prompt_content(self, prompt_id: str) -> str:
        """Retrieve a prompt template by ID.

        Args:
            prompt_id: The prompt identifier

        Returns:
            The prompt template content as string

        Raises:
            Exception if prompt not found
        """
        ...
