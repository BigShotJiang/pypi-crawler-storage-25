"""Validation result models.

These models provide structured validation results that are easy to
interpret both programmatically and by humans.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any


class ValidationSeverity(str, Enum):
    """Severity level for validation errors."""

    ERROR = "error"  # Must be fixed - plugin won't work
    WARNING = "warning"  # Should be fixed - plugin may have issues


@dataclass
class ValidationError:
    """Structured validation error with helpful details.

    Attributes:
        error_type: Machine-readable error type (e.g., "syntax_error", "missing_method")
        message: Human-readable error description
        severity: Error severity (error or warning)
        hint: How to fix the issue
        fix_suggestion: Specific code change to fix the issue
        documentation: Link to relevant documentation
        line: Line number where error occurred
        context: Surrounding code lines for context
        details: Additional error-specific details

    Example:
        error = ValidationError(
            error_type="missing_method",
            message="Plugin class missing required method",
            severity=ValidationSeverity.ERROR,
            hint="Add the required async method to your plugin class",
            fix_suggestion="async def classify(self, document, file_data, mime_type, available_labels, current_path, configs) -> str | None:",
            documentation="https://bizsupply.readme.io/docs/plugin-interface",
            line=15,
        )
    """

    error_type: str
    message: str
    severity: ValidationSeverity = ValidationSeverity.ERROR
    hint: str | None = None
    fix_suggestion: str | None = None
    documentation: str | None = None
    line: int | None = None
    context: list[str] | None = None
    details: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        result: dict[str, Any] = {
            "error_type": self.error_type,
            "message": self.message,
            "severity": self.severity.value,
        }

        if self.hint:
            result["hint"] = self.hint
        if self.fix_suggestion:
            result["fix_suggestion"] = self.fix_suggestion
        if self.documentation:
            result["documentation"] = self.documentation
        if self.line is not None:
            result["line"] = self.line
        if self.context:
            result["context"] = self.context
        if self.details:
            result["details"] = self.details

        return result

    def __str__(self) -> str:
        """Format error for display."""
        parts = [f"[{self.severity.value.upper()}] {self.message}"]
        if self.line:
            parts.append(f"  Line: {self.line}")
        if self.hint:
            parts.append(f"  Hint: {self.hint}")
        if self.fix_suggestion:
            parts.append(f"  Fix: {self.fix_suggestion}")
        return "\n".join(parts)


@dataclass
class ValidationResult:
    """Result of plugin code validation.

    Attributes:
        is_valid: True if validation passed (no errors)
        errors: List of validation errors (if any)
        warnings: List of validation warnings (if any)
        checklist: List of checks that passed (for display)
        message: Summary message

    Example:
        result = validate_plugin(code, PluginType.classification)

        if result.is_valid:
            print("Plugin is valid!")
            print("Passed checks:", result.checklist)
        else:
            print("Validation failed:")
            for error in result.errors:
                print(f"  - {error.message}")
    """

    is_valid: bool
    errors: list[ValidationError] = field(default_factory=list)
    warnings: list[ValidationError] = field(default_factory=list)
    checklist: list[str] = field(default_factory=list)
    message: str | None = None

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for JSON/API response."""
        return {
            "valid": self.is_valid,
            "errors": [e.to_dict() for e in self.errors],
            "warnings": [w.to_dict() for w in self.warnings],
            "checklist": self.checklist,
            "message": self.message or (
                "Plugin code is valid!"
                if self.is_valid
                else "Plugin code validation failed. See errors for details."
            ),
            "documentation": "https://bizsupply.readme.io/docs/plugin-interface",
        }

    def __str__(self) -> str:
        """Format result for display."""
        lines = []

        if self.is_valid:
            lines.append("✅ Plugin validation PASSED")
            if self.checklist:
                lines.append("\nChecklist:")
                for check in self.checklist:
                    lines.append(f"  {check}")
        else:
            lines.append("❌ Plugin validation FAILED")
            if self.errors:
                lines.append(f"\nErrors ({len(self.errors)}):")
                for error in self.errors:
                    lines.append(f"  {error}")

        if self.warnings:
            lines.append(f"\nWarnings ({len(self.warnings)}):")
            for warning in self.warnings:
                lines.append(f"  {warning}")

        return "\n".join(lines)
