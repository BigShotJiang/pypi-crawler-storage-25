"""Plugin, benchmark, and ontology validation module.

This module provides simplified validation for plugin, benchmark, and ontology
code/files, giving developers fast feedback during local development. Full
security validation happens server-side.

Quick Start:
    from bizsupply_sdk.validation import validate_plugin, validate_benchmark, validate_ontology

    # Plugin validation
    result = validate_plugin(code, PluginType.classification)

    # Benchmark validation
    result = validate_benchmark(code)

    # Ontology validation
    result = validate_ontology(yaml_content)

    if result.is_valid:
        print("Valid!")
    else:
        for error in result.errors:
            print(f"{error.error_type}: {error.message}")
"""

from bizsupply_sdk.validation.models import (
    ValidationError,
    ValidationResult,
    ValidationSeverity,
)
from bizsupply_sdk.validation.ontology_validator import (
    OntologyValidator,
    validate_ontology,
    validate_ontology_file,
)
from bizsupply_sdk.validation.validator import (
    SimplifiedValidator,
    validate_benchmark,
    validate_benchmark_file,
    validate_plugin,
    validate_plugin_file,
)

__all__ = [
    # Models
    "ValidationError",
    "ValidationResult",
    "ValidationSeverity",
    # Plugin/Benchmark Validator
    "SimplifiedValidator",
    "validate_plugin",
    "validate_plugin_file",
    "validate_benchmark",
    "validate_benchmark_file",
    # Ontology Validator
    "OntologyValidator",
    "validate_ontology",
    "validate_ontology_file",
]
