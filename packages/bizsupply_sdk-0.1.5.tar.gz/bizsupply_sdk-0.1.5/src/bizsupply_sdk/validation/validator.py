"""Simplified plugin/benchmark validator for SDK.

This validator provides fast local feedback during development. It checks:
- Valid Python syntax
- Correct base class inheritance
- Required methods exist
- Methods have correct async/sync signatures

IMPORTANT: Full security validation (blocked imports, blocked builtins,
required method calls) happens server-side.
This simplified validator is for developer convenience only.
"""

from __future__ import annotations

import ast
from pathlib import Path
from typing import Any

from bizsupply_sdk.core.plugin_type import PluginType
from bizsupply_sdk.validation.models import (
    ValidationError,
    ValidationResult,
    ValidationSeverity,
)


# Documentation URL
DOCS_BASE_URL = "https://bizsupply.readme.io/docs"


# Base class names per plugin type
BASE_CLASS_NAMES: dict[PluginType, str] = {
    PluginType.source: "SourcePlugin",
    PluginType.classification: "ClassificationPlugin",
    PluginType.extraction: "ExtractionPlugin",
}

# Benchmark base class name (separate from plugin types)
BENCHMARK_BASE_CLASS_NAME = "BaseBenchmark"

# Methods that MUST be async
ASYNC_REQUIRED_METHODS: set[str] = {"fetch", "has_new_data", "classify", "extract"}

# Methods that MUST be sync (benchmarks are pure calculation)
SYNC_REQUIRED_METHODS: set[str] = {"score", "compare", "compute"}

# Methods required per plugin type
# - SourcePlugin: fetch() + has_new_data()
# - ClassificationPlugin: classify()
# - ExtractionPlugin: extract()
REQUIRED_METHODS_BY_TYPE: dict[PluginType, set[str]] = {
    PluginType.source: {"fetch", "has_new_data"},
    PluginType.classification: {"classify"},
    PluginType.extraction: {"extract"},
}

# Methods required for benchmarks
BENCHMARK_REQUIRED_METHODS: set[str] = {"score", "compare", "compute"}

# Attributes required for benchmarks
BENCHMARK_REQUIRED_ATTRS: set[str] = {"name", "target_labels", "metric_unit"}


class SimplifiedValidator:
    """Simplified validator for local plugin development.

    Checks basic structure without security validation (that happens server-side).

    Example:
        validator = SimplifiedValidator()
        result = validator.validate(code_content, PluginType.classification)

        if result.is_valid:
            print("Plugin is valid!")
        else:
            for error in result.errors:
                print(error)
    """

    def validate(
        self, code_content: str, plugin_type: PluginType | None = None
    ) -> ValidationResult:
        """Validate plugin code structure.

        Args:
            code_content: Python source code as string
            plugin_type: Expected plugin type (auto-detected if not provided)

        Returns:
            ValidationResult with is_valid, errors, and checklist
        """
        errors: list[ValidationError] = []
        warnings: list[ValidationError] = []
        checklist: list[str] = []
        code_lines = code_content.split("\n")

        # Step 1: Parse code into AST
        tree = self._parse_code(code_content, code_lines, errors)
        if tree is None:
            return ValidationResult(is_valid=False, errors=errors)
        checklist.append("✓ Valid Python syntax")

        # Step 2: Find the plugin class
        if plugin_type is not None:
            expected_base = BASE_CLASS_NAMES[plugin_type]
            plugin_classes, all_classes = self._find_plugin_classes(tree, expected_base)
            detected_type = plugin_type
        else:
            plugin_classes, all_classes, detected_type = self._find_any_plugin_class(tree)

        if not plugin_classes:
            if plugin_type is not None:
                expected_base = BASE_CLASS_NAMES[plugin_type]
                required = REQUIRED_METHODS_BY_TYPE[plugin_type]
                method_suggestion = "\n    ".join(f"async def {m}(self, ...):" for m in sorted(required))
                errors.append(
                    ValidationError(
                        error_type="missing_base_class",
                        message=f"No class found that inherits from {expected_base}",
                        severity=ValidationSeverity.ERROR,
                        hint=f"Your plugin class must inherit from {expected_base}.",
                        fix_suggestion=f"class MyPlugin({expected_base}):\n    {method_suggestion}\n        pass",
                        documentation=f"{DOCS_BASE_URL}/plugin-interface",
                        details={
                            "expected_base": expected_base,
                            "found_classes": all_classes,
                        },
                    )
                )
            else:
                errors.append(
                    ValidationError(
                        error_type="missing_base_class",
                        message="No plugin class found. Must inherit from SourcePlugin, ClassificationPlugin, or ExtractionPlugin",
                        severity=ValidationSeverity.ERROR,
                        hint="Your class must inherit from one of the plugin base classes.",
                        fix_suggestion="class MyPlugin(ClassificationPlugin):\n    async def classify(self, document, file_data, mime_type, available_labels, current_path, configs) -> str | None:\n        pass",
                        documentation=f"{DOCS_BASE_URL}/plugin-interface",
                        details={"found_classes": all_classes},
                    )
                )
            return ValidationResult(is_valid=False, errors=errors)

        if len(plugin_classes) > 1:
            class_names = [cls.name for cls in plugin_classes]
            errors.append(
                ValidationError(
                    error_type="multiple_plugin_classes",
                    message=f"Multiple plugin classes found: {class_names}",
                    severity=ValidationSeverity.ERROR,
                    hint="Only define ONE class that inherits from a base plugin class.",
                    details={"classes": class_names},
                )
            )
            return ValidationResult(is_valid=False, errors=errors)

        target_class = plugin_classes[0]
        plugin_type = detected_type
        expected_base = BASE_CLASS_NAMES[plugin_type]
        checklist.append(f"✓ Class '{target_class.name}' inherits from {expected_base}")

        # Step 3: Check for required methods
        defined_methods: dict[str, ast.FunctionDef | ast.AsyncFunctionDef] = {}
        for item in target_class.body:
            if isinstance(item, (ast.FunctionDef, ast.AsyncFunctionDef)):
                defined_methods[item.name] = item

        required_methods = REQUIRED_METHODS_BY_TYPE.get(plugin_type, {"execute"})

        for method_name in required_methods:
            if method_name not in defined_methods:
                errors.append(
                    ValidationError(
                        error_type="missing_method",
                        message=f"Plugin class '{target_class.name}' missing required '{method_name}' method",
                        severity=ValidationSeverity.ERROR,
                        hint=f"Add an async {method_name}() method to your plugin class.",
                        fix_suggestion=self._get_method_template(plugin_type, method_name),
                        documentation=f"{DOCS_BASE_URL}/plugin-interface",
                        line=target_class.lineno,
                        context=self._get_code_context(code_lines, target_class.lineno),
                    )
                )
            else:
                checklist.append(f"✓ '{method_name}' method defined")

                # Step 4: Check if method is async (for methods that require it)
                if method_name in ASYNC_REQUIRED_METHODS:
                    method_node = defined_methods[method_name]
                    if isinstance(method_node, ast.FunctionDef):  # sync def, not async def
                        errors.append(
                            ValidationError(
                                error_type="method_not_async",
                                message=f"Method '{method_name}' must be async (use 'async def {method_name}')",
                                severity=ValidationSeverity.ERROR,
                                hint=f"Change 'def {method_name}' to 'async def {method_name}'",
                                fix_suggestion=f"async def {method_name}(self, ...):",
                                documentation=f"{DOCS_BASE_URL}/plugin-interface#asyncawait-required",
                                line=method_node.lineno,
                                context=self._get_code_context(code_lines, method_node.lineno),
                            )
                        )
                    else:
                        checklist.append(f"✓ '{method_name}' method is async")

        # Step 5: Add warnings for common issues (non-blocking)
        self._check_sdk_import(tree, warnings)

        # Build result
        if errors:
            return ValidationResult(
                is_valid=False,
                errors=errors,
                warnings=warnings,
                checklist=checklist,
            )

        checklist.append("✓ No blocked imports detected (basic check)")
        checklist.append("✓ No blocked builtins detected (basic check)")

        return ValidationResult(
            is_valid=True,
            errors=[],
            warnings=warnings,
            checklist=checklist,
            message="Plugin code is valid! Full security validation happens server-side.",
        )

    def validate_benchmark(self, code_content: str) -> ValidationResult:
        """Validate benchmark code structure.

        Args:
            code_content: Python source code as string

        Returns:
            ValidationResult with is_valid, errors, and checklist
        """
        errors: list[ValidationError] = []
        warnings: list[ValidationError] = []
        checklist: list[str] = []
        code_lines = code_content.split("\n")

        # Step 1: Parse code into AST
        tree = self._parse_code(code_content, code_lines, errors)
        if tree is None:
            return ValidationResult(is_valid=False, errors=errors)
        checklist.append("✓ Valid Python syntax")

        # Step 2: Find the benchmark class
        benchmark_classes, all_classes = self._find_plugin_classes(
            tree, BENCHMARK_BASE_CLASS_NAME
        )

        if not benchmark_classes:
            errors.append(
                ValidationError(
                    error_type="missing_base_class",
                    message="No benchmark class found. Must inherit from BaseBenchmark",
                    severity=ValidationSeverity.ERROR,
                    hint="Your class must inherit from BaseBenchmark.",
                    fix_suggestion="class MyBenchmark(BaseBenchmark):\n    name = \"my_benchmark\"\n    target_labels = [\"contract\"]\n    metric_unit = \"EUR\"\n\n    def score(self, document): ...\n    def compute(self, results): ...\n    def compare(self, document_score, benchmark_score): ...",
                    details={"found_classes": all_classes},
                )
            )
            return ValidationResult(is_valid=False, errors=errors)

        if len(benchmark_classes) > 1:
            class_names = [cls.name for cls in benchmark_classes]
            errors.append(
                ValidationError(
                    error_type="multiple_benchmark_classes",
                    message=f"Multiple benchmark classes found: {class_names}",
                    severity=ValidationSeverity.ERROR,
                    hint="Only define ONE class that inherits from BaseBenchmark.",
                    details={"classes": class_names},
                )
            )
            return ValidationResult(is_valid=False, errors=errors)

        target_class = benchmark_classes[0]
        return self._validate_benchmark(target_class, code_lines, errors, warnings, checklist)

    def _parse_code(
        self,
        code_content: str,
        code_lines: list[str],
        errors: list[ValidationError],
    ) -> ast.Module | None:
        """Parse code into AST, appending errors if syntax is invalid."""
        try:
            return ast.parse(code_content)
        except SyntaxError as e:
            errors.append(
                ValidationError(
                    error_type="syntax_error",
                    message=f"Syntax error at line {e.lineno}: {e.msg}",
                    severity=ValidationSeverity.ERROR,
                    hint="Fix the syntax error before proceeding.",
                    line=e.lineno,
                    context=self._get_code_context(code_lines, e.lineno),
                    details={
                        "offset": e.offset,
                        "text": e.text.strip() if e.text else None,
                    },
                )
            )
            return None

    def _validate_benchmark(
        self,
        benchmark_class: ast.ClassDef,
        code_lines: list[str],
        errors: list[ValidationError],
        warnings: list[ValidationError],
        checklist: list[str],
    ) -> ValidationResult:
        """Validate a benchmark class."""
        checklist.append(f"✓ Class '{benchmark_class.name}' inherits from BaseBenchmark")

        # Check for required methods
        defined_methods: dict[str, ast.FunctionDef | ast.AsyncFunctionDef] = {}
        for item in benchmark_class.body:
            if isinstance(item, (ast.FunctionDef, ast.AsyncFunctionDef)):
                defined_methods[item.name] = item

        for method_name in BENCHMARK_REQUIRED_METHODS:
            if method_name not in defined_methods:
                errors.append(
                    ValidationError(
                        error_type="missing_method",
                        message=f"Benchmark class '{benchmark_class.name}' missing required '{method_name}' method",
                        severity=ValidationSeverity.ERROR,
                        hint=f"Add a def {method_name}() method to your benchmark class.",
                        fix_suggestion=self._get_benchmark_method_template(method_name),
                        line=benchmark_class.lineno,
                        context=self._get_code_context(code_lines, benchmark_class.lineno),
                    )
                )
            else:
                checklist.append(f"✓ '{method_name}' method defined")

                # Benchmark methods MUST be sync (not async)
                if method_name in SYNC_REQUIRED_METHODS:
                    method_node = defined_methods[method_name]
                    if isinstance(method_node, ast.AsyncFunctionDef):
                        errors.append(
                            ValidationError(
                                error_type="method_not_sync",
                                message=f"Method '{method_name}' must be sync (use 'def {method_name}', not 'async def')",
                                severity=ValidationSeverity.ERROR,
                                hint=f"Benchmark methods are pure calculations and must be sync. Change 'async def {method_name}' to 'def {method_name}'",
                                fix_suggestion=f"def {method_name}(self, ...):",
                                line=method_node.lineno,
                                context=self._get_code_context(code_lines, method_node.lineno),
                            )
                        )
                    else:
                        checklist.append(f"✓ '{method_name}' method is sync")

        # Check for required class attributes
        defined_attrs = set()
        for item in benchmark_class.body:
            if isinstance(item, ast.Assign):
                for target in item.targets:
                    if isinstance(target, ast.Name):
                        defined_attrs.add(target.id)
            elif isinstance(item, ast.AnnAssign) and isinstance(item.target, ast.Name):
                if item.value is not None:
                    defined_attrs.add(item.target.id)

        for attr_name in sorted(BENCHMARK_REQUIRED_ATTRS):
            if attr_name not in defined_attrs:
                errors.append(
                    ValidationError(
                        error_type="missing_attribute",
                        message=f"Benchmark class '{benchmark_class.name}' missing required '{attr_name}' attribute",
                        severity=ValidationSeverity.ERROR,
                        hint=f"Add '{attr_name}' as a class attribute.",
                        line=benchmark_class.lineno,
                        context=self._get_code_context(code_lines, benchmark_class.lineno),
                    )
                )
            else:
                checklist.append(f"✓ '{attr_name}' attribute defined")

        # Check for SDK import
        tree = ast.parse("\n".join(code_lines))
        self._check_sdk_import(tree, warnings)

        if errors:
            return ValidationResult(
                is_valid=False,
                errors=errors,
                warnings=warnings,
                checklist=checklist,
            )

        checklist.append("✓ No blocked imports detected (basic check)")
        checklist.append("✓ No blocked builtins detected (basic check)")

        return ValidationResult(
            is_valid=True,
            errors=[],
            warnings=warnings,
            checklist=checklist,
            message="Benchmark code is valid! Full security validation happens server-side.",
        )

    def _check_sdk_import(self, tree: ast.Module, warnings: list[ValidationError]) -> None:
        """Check for bizsupply_sdk import and add warning if missing."""
        has_sdk_import = any(
            isinstance(node, (ast.Import, ast.ImportFrom))
            and self._has_sdk_import(node)
            for node in ast.walk(tree)
        )
        if not has_sdk_import:
            warnings.append(
                ValidationError(
                    error_type="missing_import",
                    message="Consider importing from bizsupply_sdk for type hints",
                    severity=ValidationSeverity.WARNING,
                    hint="Add: from bizsupply_sdk import BaseBenchmark (or plugin base class)",
                )
            )

    def _find_plugin_classes(
        self, tree: ast.Module, expected_base: str
    ) -> tuple[list[ast.ClassDef], list[str]]:
        """Find all plugin classes and all class names."""
        plugin_classes: list[ast.ClassDef] = []
        all_classes: list[str] = []

        for node in ast.walk(tree):
            if isinstance(node, ast.ClassDef):
                all_classes.append(node.name)
                for base in node.bases:
                    base_name = self._get_base_name(base)
                    if base_name == expected_base:
                        plugin_classes.append(node)
                        break

        return plugin_classes, all_classes

    def _find_any_plugin_class(
        self, tree: ast.Module
    ) -> tuple[list[ast.ClassDef], list[str], PluginType | None]:
        """Find any plugin class and detect its type.

        Note: This only detects plugin types (not benchmarks).
        Benchmark detection is handled separately in validate().
        """
        # Map base class names to plugin types
        base_to_type = {v: k for k, v in BASE_CLASS_NAMES.items()}

        plugin_classes: list[ast.ClassDef] = []
        all_classes: list[str] = []
        detected_type: PluginType | None = None

        for node in ast.walk(tree):
            if isinstance(node, ast.ClassDef):
                all_classes.append(node.name)
                for base in node.bases:
                    base_name = self._get_base_name(base)
                    if base_name and base_name in base_to_type:
                        plugin_classes.append(node)
                        detected_type = base_to_type[base_name]
                        break

        return plugin_classes, all_classes, detected_type

    def _get_base_name(self, base: ast.expr) -> str | None:
        """Extract base class name from AST node."""
        if isinstance(base, ast.Name):
            return base.id
        elif isinstance(base, ast.Attribute):
            return base.attr
        return None

    def _get_code_context(
        self, code_lines: list[str], line_number: int | None, context_lines: int = 2
    ) -> list[str]:
        """Extract code context around a specific line."""
        if not line_number or line_number < 1:
            return []

        start = max(0, line_number - context_lines - 1)
        end = min(len(code_lines), line_number + context_lines)

        context = []
        for i in range(start, end):
            line_num = i + 1
            marker = " -> " if line_num == line_number else "    "
            context.append(f"{line_num:4d}{marker}{code_lines[i]}")

        return context

    def _has_sdk_import(self, node: ast.Import | ast.ImportFrom) -> bool:
        """Check if node imports from bizsupply_sdk."""
        if isinstance(node, ast.Import):
            return any("bizsupply_sdk" in alias.name for alias in node.names)
        elif isinstance(node, ast.ImportFrom):
            return node.module is not None and "bizsupply_sdk" in node.module
        return False

    def _get_method_template(self, plugin_type: PluginType, method_name: str) -> str:
        """Get method template for a specific plugin type and method."""
        if method_name == "fetch":
            return self._get_fetch_template()
        elif method_name == "has_new_data":
            return self._get_has_new_data_template()
        elif method_name == "classify":
            return self._get_classify_template()
        elif method_name == "extract":
            return self._get_extract_template()
        return f"async def {method_name}(self, ...):\n    pass"

    def _get_has_new_data_template(self) -> str:
        """Get has_new_data method template for source plugins."""
        return '''async def has_new_data(
    self,
    credentials: DynamicCredential,
    state: MySourceState,
    configs: dict[str, Any],
) -> bool:
    """Check if source has new data since last sync.

    Called by auto-sync service to determine if a pipeline should be triggered.

    Args:
        credentials: DynamicCredential injected by Engine
        state: Current typed state from database
        configs: Runtime configuration

    Returns:
        True if new data exists, False otherwise
    """
    # Example: Check if there's data newer than last sync
    # api = MyAPI(credentials.api_key)
    # latest = await api.get_latest_item_date()
    # return latest > state.last_sync if state.last_sync else True
    return True'''

    def _get_fetch_template(self) -> str:
        """Get fetch method template for source plugins."""
        return '''async def fetch(
    self,
    credentials: DynamicCredential,
    state: MySourceState,
    configs: dict[str, Any],
) -> AsyncIterator[DocumentInput]:
    """Yield documents to create. Engine handles persistence and state.

    Args:
        credentials: DynamicCredential injected by Engine
        state: Typed state injected by Engine
        configs: Runtime configuration (batch sizes, filters, etc.)

    Yields:
        DocumentInput for each document to create
    """
    # Example: Fetch items from your source API
    # api = MyAPI(credentials.api_key)
    # batch_size = configs.get("batch_size", 100)
    #
    # for item in api.list_items(since=state.cursor, limit=batch_size):
    #     yield DocumentInput(
    #         file_data=item.content,
    #         filename=item.name,
    #         metadata={"source_id": item.id},
    #     )
    #     state.cursor = item.id  # Engine saves this automatically
    pass'''

    def _get_classify_template(self) -> str:
        """Get classify method template for classification plugins."""
        return '''async def classify(
    self,
    document: Document,
    file_data: bytes | None,
    mime_type: str | None,
    available_labels: list[str],
    current_path: list[str],
    configs: dict[str, Any],
) -> str | None:
    """Classify at a single hierarchy level.

    The Engine calls this once per level. Just pick from available_labels.

    Args:
        document: The document being classified
        file_data: Raw file bytes (Gemini reads PDFs directly)
        mime_type: File MIME type
        available_labels: Ontology labels at this level (no "other")
        current_path: Labels already selected (e.g., ["Energy", "Contract"])
        configs: Runtime configuration (prompt IDs, thresholds, etc.)

    Returns:
        - Label from available_labels: continue to next level
        - Label NOT in available_labels: tracked as llm_suggested
        - None: Engine triggers suggestion workflow
    """
    # Example: Get prompt from configs and classify using LLM
    # prompt_id = configs.get("classification_prompt_id")
    # path_str = " > ".join(current_path) if current_path else "Root"
    # response = await self.prompt_llm(
    #     prompt=f"Path: {path_str}\\nOptions: {available_labels}",
    #     file_data=file_data,
    #     mime_type=mime_type,
    # )
    # return response.get("category")  # str or None

    return available_labels[0] if available_labels else None'''

    def _get_extract_template(self) -> str:
        """Get extract method template for extraction plugins."""
        return '''async def extract(
    self,
    document: Document,
    file_data: bytes | None,
    mime_type: str | None,
    fields: list[OntologyField],
    configs: dict[str, Any],
) -> ExtractionResult:
    """Extract data from a document and return extracted values.

    Args:
        document: The document to extract from
        file_data: Raw file bytes (Gemini reads PDFs directly)
        mime_type: MIME type of file_data
        fields: OntologyFields to extract (resolved from document.labels)
        configs: Runtime configuration (prompt IDs, thresholds, etc.)

    Returns:
        ExtractionResult with extracted data
    """
    # Example: Get prompt from configs and extract using LLM
    # prompt_id = configs.get("extraction_prompt_id")
    # fields_json = self.format_fields_for_prompt(fields)
    # response = await self.prompt_llm(
    #     prompt=f"Extract: {fields_json}",
    #     file_data=file_data,
    #     mime_type=mime_type,
    # )
    # return ExtractionResult(data=response or {})

    return ExtractionResult(data={})'''

    def _get_benchmark_method_template(self, method_name: str) -> str:
        """Get method template for a benchmark method."""
        if method_name == "score":
            return self._get_benchmark_score_template()
        elif method_name == "compare":
            return self._get_benchmark_compare_template()
        elif method_name == "compute":
            return self._get_benchmark_compute_template()
        return f"def {method_name}(self, ...):\n    pass"

    def _get_benchmark_score_template(self) -> str:
        """Get score template for benchmarks."""
        return '''def score(self, document):
    """Calculate score for a single document.

    Args:
        document: ExtendedDocument with typed access and aggregations

    Returns:
        Score as float, or None if not applicable
    """
    if not document.aggregations:
        return None
    # TODO: Implement scoring logic
    # Use inv.get("field_name") to read fields from aggregated documents
    values = [inv.get("price") for inv in document.aggregations]
    values = [v for v in values if v is not None]
    if not values:
        return None
    return sum(values) / len(values)'''

    def _get_benchmark_compare_template(self) -> str:
        """Get compare template for benchmarks."""
        return '''def compare(self, document_score, benchmark_score):
    """Compare document score against the benchmark value.

    Returns True if the document scores unfavorably.
    """
    # TODO: Implement comparison logic
    # Example (lower is better): return document_score > benchmark_score
    return document_score > benchmark_score'''

    def _get_benchmark_compute_template(self) -> str:
        """Get compute template for benchmarks."""
        return '''def compute(self, results):
    """Compute a single benchmark value from scored documents.

    Args:
        results: Non-empty list of ScoredDocument (each has .document and .score)

    Returns:
        Single benchmark value
    """
    # TODO: Choose computation method
    # min(r.score for r in results)  -> best/lowest
    # max(r.score for r in results)  -> best/highest
    # Weighted: sum(r.score * r.document.get("weight") for r in results) / total
    return min(r.score for r in results)'''


def validate_plugin(
    code_content: str, plugin_type: PluginType | None = None
) -> ValidationResult:
    """Validate plugin code structure.

    Convenience function that creates a SimplifiedValidator and validates.

    Args:
        code_content: Python source code as string
        plugin_type: Expected plugin type (auto-detected if not provided)

    Returns:
        ValidationResult with is_valid, errors, and checklist

    Example:
        result = validate_plugin(code, PluginType.classification)
        if result.is_valid:
            print("Plugin is valid!")

        # Auto-detect type
        result = validate_plugin(code)
    """
    validator = SimplifiedValidator()
    return validator.validate(code_content, plugin_type)


def validate_plugin_file(
    file_path: str | Path, plugin_type: PluginType | None = None
) -> ValidationResult:
    """Validate a plugin file.

    Args:
        file_path: Path to the Python plugin file
        plugin_type: Expected plugin type (auto-detected if not provided)

    Returns:
        ValidationResult with is_valid, errors, and checklist

    Raises:
        FileNotFoundError: If file doesn't exist
        IOError: If file can't be read

    Example:
        result = validate_plugin_file("my_plugin.py", PluginType.extraction)

        # Auto-detect type
        result = validate_plugin_file("my_plugin.py")
    """
    path = Path(file_path)
    if not path.exists():
        return ValidationResult(
            is_valid=False,
            errors=[
                ValidationError(
                    error_type="file_not_found",
                    message=f"File not found: {file_path}",
                    severity=ValidationSeverity.ERROR,
                )
            ],
        )

    try:
        code_content = path.read_text(encoding="utf-8")
    except IOError as e:
        return ValidationResult(
            is_valid=False,
            errors=[
                ValidationError(
                    error_type="file_read_error",
                    message=f"Could not read file: {e}",
                    severity=ValidationSeverity.ERROR,
                )
            ],
        )

    return validate_plugin(code_content, plugin_type)


def validate_benchmark(code_content: str) -> ValidationResult:
    """Validate benchmark code structure.

    Convenience function that creates a SimplifiedValidator and validates.

    Args:
        code_content: Python source code as string

    Returns:
        ValidationResult with is_valid, errors, and checklist

    Example:
        result = validate_benchmark(code)
        if result.is_valid:
            print("Benchmark is valid!")
    """
    validator = SimplifiedValidator()
    return validator.validate_benchmark(code_content)


def validate_benchmark_file(file_path: str | Path) -> ValidationResult:
    """Validate a benchmark file.

    Args:
        file_path: Path to the Python benchmark file

    Returns:
        ValidationResult with is_valid, errors, and checklist

    Example:
        result = validate_benchmark_file("my_benchmark.py")
    """
    path = Path(file_path)
    if not path.exists():
        return ValidationResult(
            is_valid=False,
            errors=[
                ValidationError(
                    error_type="file_not_found",
                    message=f"File not found: {file_path}",
                    severity=ValidationSeverity.ERROR,
                )
            ],
        )

    try:
        code_content = path.read_text(encoding="utf-8")
    except IOError as e:
        return ValidationResult(
            is_valid=False,
            errors=[
                ValidationError(
                    error_type="file_read_error",
                    message=f"Could not read file: {e}",
                    severity=ValidationSeverity.ERROR,
                )
            ],
        )

    return validate_benchmark(code_content)
