"""Ontology YAML validator for SDK.

This validator provides fast local feedback for ontology files. It checks:
- Valid YAML syntax
- Pydantic schema conformance (OntologyManifest)
- Semantic rules (valid dtypes, no duplicate labels/fields, etc.)
"""

from __future__ import annotations

from pathlib import Path

import yaml
from pydantic import ValidationError as PydanticValidationError

from bizsupply_sdk.core.ontology import OntologyManifest, OntologyNode
from bizsupply_sdk.validation.models import (
    ValidationError,
    ValidationResult,
    ValidationSeverity,
)

# Valid dtype values for ontology fields
VALID_DTYPES = {"string", "int", "float", "date", "boolean", "array"}


class OntologyValidator:
    """Validator for ontology YAML files.

    Performs three layers of validation:
    1. YAML syntax - parseable YAML
    2. Pydantic schema - conforms to OntologyManifest model
    3. Semantic checks - valid dtypes, no duplicates, etc.

    Example:
        validator = OntologyValidator()
        result = validator.validate(yaml_content)

        if result.is_valid:
            print("Ontology is valid!")
        else:
            for error in result.errors:
                print(error)
    """

    def validate(self, yaml_content: str) -> ValidationResult:
        """Validate ontology YAML content.

        Args:
            yaml_content: Raw YAML string

        Returns:
            ValidationResult with is_valid, errors, warnings, and checklist
        """
        errors: list[ValidationError] = []
        warnings: list[ValidationError] = []
        checklist: list[str] = []

        # Layer 1: YAML syntax
        data = self._parse_yaml(yaml_content, errors)
        if data is None:
            return ValidationResult(is_valid=False, errors=errors)
        checklist.append("✓ Valid YAML syntax")

        # Layer 2: Pydantic schema
        manifest = self._validate_schema(data, errors)
        if manifest is None:
            return ValidationResult(is_valid=False, errors=errors, checklist=checklist)
        checklist.append("✓ Schema valid (name, taxonomy present)")

        # Layer 3: Semantic checks
        self._validate_semantics(manifest.taxonomy, errors, warnings, checklist)

        if errors:
            return ValidationResult(
                is_valid=False,
                errors=errors,
                warnings=warnings,
                checklist=checklist,
            )

        return ValidationResult(
            is_valid=True,
            errors=[],
            warnings=warnings,
            checklist=checklist,
            message="Ontology is valid!",
        )

    def _parse_yaml(
        self, yaml_content: str, errors: list[ValidationError]
    ) -> dict | None:
        """Parse YAML content, appending errors if invalid."""
        try:
            data = yaml.safe_load(yaml_content)
        except yaml.YAMLError as e:
            errors.append(
                ValidationError(
                    error_type="yaml_syntax_error",
                    message=f"Invalid YAML syntax: {e}",
                    severity=ValidationSeverity.ERROR,
                    hint="Fix the YAML syntax error before proceeding.",
                )
            )
            return None

        if not isinstance(data, dict):
            errors.append(
                ValidationError(
                    error_type="yaml_not_mapping",
                    message="YAML content must be a mapping (object), not a scalar or list",
                    severity=ValidationSeverity.ERROR,
                    hint="Ontology YAML must start with key-value pairs like 'name:', 'taxonomy:', etc.",
                )
            )
            return None

        return data

    def _validate_schema(
        self, data: dict, errors: list[ValidationError]
    ) -> OntologyManifest | None:
        """Validate data against OntologyManifest Pydantic model."""
        try:
            return OntologyManifest.model_validate(data)
        except PydanticValidationError as e:
            for pydantic_error in e.errors():
                loc = " -> ".join(str(part) for part in pydantic_error["loc"])
                errors.append(
                    ValidationError(
                        error_type="schema_error",
                        message=f"Schema error at '{loc}': {pydantic_error['msg']}",
                        severity=ValidationSeverity.ERROR,
                        hint="Check the ontology structure matches the required schema.",
                        details={
                            "location": list(pydantic_error["loc"]),
                            "type": pydantic_error["type"],
                        },
                    )
                )
            return None

    def _validate_semantics(
        self,
        node: OntologyNode,
        errors: list[ValidationError],
        warnings: list[ValidationError],
        checklist: list[str],
        path: str = "",
    ) -> None:
        """Recursively validate semantic rules on the taxonomy tree."""
        current_path = f"{path} > {node.label}" if path else node.label

        # Check for empty/whitespace-only label
        if not node.label.strip():
            errors.append(
                ValidationError(
                    error_type="empty_label",
                    message=f"Empty or whitespace-only label at '{path or 'root'}'",
                    severity=ValidationSeverity.ERROR,
                    hint="All nodes must have a non-empty label.",
                )
            )

        # Check field dtypes
        for field in node.fields:
            if field.dtype not in VALID_DTYPES:
                errors.append(
                    ValidationError(
                        error_type="invalid_dtype",
                        message=f"Invalid dtype '{field.dtype}' for field '{field.name}' at '{current_path}'",
                        severity=ValidationSeverity.ERROR,
                        hint=f"Valid dtypes are: {', '.join(sorted(VALID_DTYPES))}",
                        details={
                            "field_name": field.name,
                            "invalid_dtype": field.dtype,
                            "valid_dtypes": sorted(VALID_DTYPES),
                        },
                    )
                )

        # Check for duplicate field names within this node
        field_names: list[str] = []
        for field in node.fields:
            lower_name = field.name.lower()
            if lower_name in [fn.lower() for fn in field_names]:
                errors.append(
                    ValidationError(
                        error_type="duplicate_field",
                        message=f"Duplicate field name '{field.name}' at '{current_path}'",
                        severity=ValidationSeverity.ERROR,
                        hint="Field names must be unique within a node.",
                    )
                )
            field_names.append(field.name)

        # Check for duplicate child labels (case-insensitive)
        child_labels: list[str] = []
        for child in node.children:
            lower_label = child.label.lower()
            if lower_label in [cl.lower() for cl in child_labels]:
                errors.append(
                    ValidationError(
                        error_type="duplicate_label",
                        message=f"Duplicate child label '{child.label}' at '{current_path}'",
                        severity=ValidationSeverity.ERROR,
                        hint="Child labels must be unique within the same parent (case-insensitive).",
                    )
                )
            child_labels.append(child.label)

        # Warning: root node with no children and no fields
        if not path and not node.children and not node.fields:
            warnings.append(
                ValidationError(
                    error_type="empty_taxonomy",
                    message="Root node has no children and no fields",
                    severity=ValidationSeverity.WARNING,
                    hint="Consider adding child nodes or fields to the root taxonomy node.",
                )
            )

        # Record progress
        if not errors or path:
            checklist.append(f"✓ Node '{current_path}' validated")

        # Recurse into children
        for child in node.children:
            self._validate_semantics(child, errors, warnings, checklist, current_path)


def validate_ontology(yaml_content: str) -> ValidationResult:
    """Validate ontology YAML content.

    Convenience function that creates an OntologyValidator and validates.

    Args:
        yaml_content: Raw YAML string

    Returns:
        ValidationResult with is_valid, errors, warnings, and checklist

    Example:
        result = validate_ontology(yaml_string)
        if result.is_valid:
            print("Ontology is valid!")
    """
    validator = OntologyValidator()
    return validator.validate(yaml_content)


def validate_ontology_file(file_path: str | Path) -> ValidationResult:
    """Validate an ontology YAML file.

    Args:
        file_path: Path to the YAML ontology file

    Returns:
        ValidationResult with is_valid, errors, warnings, and checklist

    Example:
        result = validate_ontology_file("my_ontology.yaml")
    """
    path = Path(file_path)
    if not path.exists():
        return ValidationResult(
            is_valid=False,
            errors=[
                ValidationError(
                    error_type="file_not_found",
                    message=f"File not found: {file_path}",
                    severity=ValidationSeverity.ERROR,
                )
            ],
        )

    try:
        yaml_content = path.read_text(encoding="utf-8")
    except IOError as e:
        return ValidationResult(
            is_valid=False,
            errors=[
                ValidationError(
                    error_type="file_read_error",
                    message=f"Could not read file: {e}",
                    severity=ValidationSeverity.ERROR,
                )
            ],
        )

    return validate_ontology(yaml_content)
