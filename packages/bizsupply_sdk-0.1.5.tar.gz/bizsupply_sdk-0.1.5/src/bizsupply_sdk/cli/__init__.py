"""CLI module for bizSupply Plugin SDK.

Provides command-line tools for plugin development:
- bizsupply init: Scaffold new plugin or benchmark projects
- bizsupply validate: Validate plugin or benchmark code
- bizsupply tutorial: Show plugin development workflow tutorial
"""

from bizsupply_sdk.cli.main import app

__all__ = ["app"]
