"""Plugin validation command.

Validates plugin code structure before registration.
"""

from __future__ import annotations

from pathlib import Path

import typer
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from bizsupply_sdk.core.plugin_type import PluginType
from bizsupply_sdk.validation import validate_benchmark_file, validate_ontology_file, validate_plugin_file

console = Console()


def validate_command(
    file_path: str = typer.Argument(
        ...,
        help="Path to the plugin Python file",
    ),
    plugin_type: str = typer.Option(
        None,
        "--type", "-t",
        help="Plugin type (auto-detected from code if not specified)",
    ),
    verbose: bool = typer.Option(
        False,
        "--verbose", "-v",
        help="Show detailed validation output",
    ),
    json_output: bool = typer.Option(
        False,
        "--json",
        help="Output results as JSON",
    ),
) -> None:
    """Validate a plugin, benchmark, or ontology file.

    Checks for:
    - Valid Python/YAML syntax
    - Correct base class inheritance (plugins/benchmarks)
    - Required methods (fetch/classify/extract for plugins, score/compute/compare for benchmarks)
    - Async method declarations (plugins only)
    - Required attributes (benchmarks only)
    - Schema and semantic validation (ontologies)

    Example:
        bizsupply validate my_plugin.py
        bizsupply validate my_plugin.py --type classification
        bizsupply validate my_benchmark.py --type benchmark
        bizsupply validate my_ontology.yaml
        bizsupply validate my_ontology.yaml --type ontology
        bizsupply validate my_plugin.py --json
    """
    # Check file exists
    path = Path(file_path)
    if not path.exists():
        console.print(f"[red]Error:[/red] File not found: {file_path}")
        raise typer.Exit(1)

    # Determine type and validate
    is_benchmark, is_ontology, ptype = _detect_type(path, plugin_type)
    if is_ontology:
        result = validate_ontology_file(path)
    elif is_benchmark:
        result = validate_benchmark_file(path)
    elif ptype is not None:
        result = validate_plugin_file(path, ptype)
    else:
        console.print("[red]Error:[/red] Could not determine type.")
        console.print(
            "Specify with --type or ensure your file is a .yaml/.yml ontology, "
            "or your class inherits from "
            "SourcePlugin, ClassificationPlugin, ExtractionPlugin, or BaseBenchmark."
        )
        raise typer.Exit(1)

    # Output results
    if json_output:
        import json
        console.print(json.dumps(result.to_dict(), indent=2))
    else:
        _print_result(result, verbose)

    # Exit with appropriate code
    if not result.is_valid:
        raise typer.Exit(1)


def _detect_type(
    plugin_path: Path, explicit_type: str | None
) -> tuple[bool, bool, PluginType | None]:
    """Detect whether file is a benchmark, ontology, or plugin.

    Returns:
        (is_benchmark, is_ontology, plugin_type) tuple.
        - (True, False, None) for benchmarks
        - (False, True, None) for ontologies
        - (False, False, PluginType) for plugins
        - (False, False, None) if type could not be determined
    """
    if explicit_type:
        type_lower = explicit_type.lower()
        if type_lower == "benchmark":
            return True, False, None
        if type_lower == "ontology":
            return False, True, None
        try:
            return False, False, PluginType(type_lower)
        except ValueError:
            console.print(f"[red]Error:[/red] Invalid type '{explicit_type}'")
            console.print("Valid types: source, classification, extraction, benchmark, ontology")
            return False, False, None

    # Auto-detect ontology by file extension
    if plugin_path.suffix.lower() in (".yaml", ".yml"):
        return False, True, None

    # Infer from file content by checking base class inheritance
    try:
        content = plugin_path.read_text()
        if "BaseBenchmark" in content:
            return True, False, None
        if "SourcePlugin" in content:
            return False, False, PluginType.source
        if "ClassificationPlugin" in content:
            return False, False, PluginType.classification
        if "ExtractionPlugin" in content:
            return False, False, PluginType.extraction
    except Exception:
        pass

    return False, False, None


def _print_result(result, verbose: bool) -> None:
    """Print validation result to console."""
    if result.is_valid:
        console.print(Panel.fit(
            "[green]✓ Plugin validation passed![/green]\n\n"
            f"{result.message or 'Plugin code is valid.'}",
            title="Validation Result",
            border_style="green",
        ))

        if verbose and result.checklist:
            console.print("\n[dim]Checklist:[/dim]")
            for check in result.checklist:
                console.print(f"  {check}")

        if result.warnings:
            console.print(f"\n[yellow]Warnings ({len(result.warnings)}):[/yellow]")
            for warning in result.warnings:
                console.print(f"  ⚠ {warning.message}")
                if verbose and warning.hint:
                    console.print(f"    [dim]Hint: {warning.hint}[/dim]")

    else:
        console.print(Panel.fit(
            "[red]✗ Plugin validation failed[/red]",
            title="Validation Result",
            border_style="red",
        ))

        if result.errors:
            table = Table(title="Errors", show_header=True, header_style="bold red")
            table.add_column("Line", style="dim", width=6)
            table.add_column("Type", style="cyan")
            table.add_column("Message")

            for error in result.errors:
                line = str(error.line) if error.line else "-"
                table.add_row(line, error.error_type, error.message)

            console.print(table)

            if verbose:
                for error in result.errors:
                    if error.hint or error.fix_suggestion:
                        console.print(f"\n[bold]{error.error_type}:[/bold]")
                        if error.hint:
                            console.print(f"  [dim]Hint:[/dim] {error.hint}")
                        if error.fix_suggestion:
                            console.print(f"  [dim]Fix:[/dim] {error.fix_suggestion}")
                        if error.context:
                            console.print("  [dim]Context:[/dim]")
                            for line in error.context:
                                console.print(f"    {line}")
