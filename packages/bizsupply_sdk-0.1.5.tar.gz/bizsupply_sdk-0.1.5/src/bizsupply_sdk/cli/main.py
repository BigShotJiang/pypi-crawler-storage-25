"""Main CLI application for bizSupply Plugin SDK.

Entry point for all CLI commands. Use `bizsupply --help` for usage.
"""

from __future__ import annotations

import typer
from rich.console import Console

from bizsupply_sdk.cli.init_cmd import init_command
from bizsupply_sdk.cli.tutorial_cmd import tutorial_command
from bizsupply_sdk.cli.validate_cmd import validate_command

# Create main app
app = typer.Typer(
    name="bizsupply",
    help="bizSupply Plugin SDK - Tools for plugin development",
    no_args_is_help=True,
    rich_markup_mode="rich",
)

console = Console()


app.command("init", help="Create a new plugin project")(init_command)
app.command("validate", help="Validate plugin code")(validate_command)
app.command("tutorial", help="Show plugin development workflow tutorial")(tutorial_command)


@app.callback()
def main_callback(
    version: bool = typer.Option(
        False, "--version", "-v", help="Show version and exit"
    ),
) -> None:
    """bizSupply Plugin SDK - Tools for plugin development."""
    if version:
        from bizsupply_sdk import __version__
        console.print(f"bizsupply-sdk version {__version__}")
        raise typer.Exit()


if __name__ == "__main__":
    app()
