"""Plugin scaffolding command.

Creates a new plugin project with boilerplate code.
"""

from __future__ import annotations

import re
from importlib import resources
from pathlib import Path

import typer
from jinja2 import Environment, BaseLoader
from rich.console import Console
from rich.panel import Panel

from bizsupply_sdk.core.plugin_type import PluginType

console = Console()


def _get_templates_dir() -> Path:
    """Get the path to the templates directory."""
    # Try to get templates from package resources
    try:
        with resources.files("bizsupply_sdk").joinpath("../../templates") as p:
            if p.exists():
                return Path(p)
    except (TypeError, FileNotFoundError):
        pass

    # Fallback: look relative to the SDK source
    sdk_src = Path(__file__).parent.parent.parent.parent
    templates_dir = sdk_src / "templates"
    if templates_dir.exists():
        return templates_dir

    # Last resort: current directory
    return Path("templates")


def _load_template(template_path: Path) -> str:
    """Load a Jinja2 template file.

    Args:
        template_path: Path to the .j2 template file

    Returns:
        Rendered template content

    Raises:
        FileNotFoundError: If template file doesn't exist
    """
    if not template_path.exists():
        raise FileNotFoundError(f"Template not found: {template_path}")
    return template_path.read_text(encoding="utf-8")


def _render_template(template_content: str, variables: dict) -> str:
    """Render a Jinja2 template with variables.

    Args:
        template_content: Jinja2 template string
        variables: Variables to substitute

    Returns:
        Rendered template content
    """
    env = Environment(loader=BaseLoader(), keep_trailing_newline=True)
    template = env.from_string(template_content)
    return template.render(**variables)


def _validate_source_type(source_type: str) -> bool:
    """Validate source_type format.

    Must be lowercase, alphanumeric with underscores only.

    Args:
        source_type: The source type identifier to validate

    Returns:
        True if valid, False otherwise
    """
    pattern = r"^[a-z][a-z0-9_]*$"
    return bool(re.match(pattern, source_type))


def init_command(
    plugin_type: str = typer.Argument(
        ...,
        help="Type: source, classification, extraction, benchmark, or ontology",
    ),
    name: str = typer.Option(
        ...,
        "--name",
        "-n",
        help="Plugin/benchmark/ontology name (used for class and file names)",
    ),
    output_dir: str = typer.Option(
        ".",
        "--output",
        "-o",
        help="Output directory (default: current directory)",
    ),
    description: str = typer.Option(
        "",
        "--description",
        "-d",
        help="Plugin/benchmark/ontology description",
    ),
    source_type: str = typer.Option(
        "",
        "--source-type",
        "-s",
        help="Source type identifier (source plugins only). Defaults to file name.",
    ),
) -> None:
    """Create a new plugin, benchmark, or ontology project from template.

    Example:
        bizsupply init classification --name invoice-classifier
        bizsupply init source --name salesforce-connector --output ./plugins
        bizsupply init source --name gmail --source-type acme_gmail
        bizsupply init benchmark --name energy-price
        bizsupply init ontology --name energy-contracts
    """
    type_lower = plugin_type.lower()

    # Handle special cases (not a PluginType)
    is_benchmark = type_lower == "benchmark"
    is_ontology = type_lower == "ontology"

    if not is_benchmark and not is_ontology:
        # Validate plugin type
        try:
            ptype = PluginType(type_lower)
        except ValueError:
            console.print(f"[red]Error:[/red] Invalid type '{plugin_type}'")
            console.print("Valid types: source, classification, extraction, benchmark, ontology")
            raise typer.Exit(1)

    # Generate name variants
    file_name = name.replace("-", "_").lower()

    # Create output directory
    output_path = Path(output_dir) / file_name

    if output_path.exists():
        console.print(f"[red]Error:[/red] Directory already exists: {output_path}")
        raise typer.Exit(1)

    # Handle ontology as a special case (YAML, no class)
    if is_ontology:
        ontology_name = " ".join(word.capitalize() for word in name.replace("-", "_").split("_"))
        output_path.mkdir(parents=True)

        templates_dir = _get_templates_dir()
        variables = {
            "ontology_name": ontology_name,
            "file_name": file_name,
            "description": description,
        }

        try:
            template_path = templates_dir / "ontology" / "ontology.yaml.j2"
            template_content = _load_template(template_path)
            file_content = _render_template(template_content, variables)
        except FileNotFoundError:
            file_content = _get_ontology_template_fallback(ontology_name, file_name, description)

        output_file = output_path / f"{file_name}.yaml"
        output_file.write_text(file_content)

        console.print(
            Panel.fit(
                f"[green]Created[/green] ontology: [bold]{name}[/bold]\n\n"
                f"[dim]Location:[/dim] {output_path.absolute()}\n\n"
                "[dim]Next steps:[/dim]\n"
                f"  1. Edit {file_name}.yaml to define your taxonomy\n"
                f"  2. Run [cyan]bizsupply validate {output_file}[/cyan]",
                title="Ontology Created",
                border_style="green",
            )
        )
        return

    class_name = "".join(word.capitalize() for word in name.replace("-", "_").split("_"))

    if is_benchmark:
        class_name = f"{class_name}Benchmark"
    else:
        class_name = f"{class_name}Plugin"

    # Handle source_type for source plugins
    actual_source_type = file_name
    if not is_benchmark and ptype == PluginType.source:
        if source_type:
            if not _validate_source_type(source_type):
                console.print(
                    f"[red]Error:[/red] Invalid source_type '{source_type}'. "
                    "Must be lowercase, start with a letter, and contain only letters, numbers, and underscores."
                )
                raise typer.Exit(1)
            actual_source_type = source_type
        else:
            # Add a warning about uniqueness
            console.print(
                f"[yellow]Note:[/yellow] Using default source_type '{file_name}'. "
                "Consider using --source-type for a unique identifier (e.g., mycompany_gmail)."
            )

    output_path.mkdir(parents=True)

    # Get templates directory
    templates_dir = _get_templates_dir()

    # Template variables
    variables = {
        "class_name": class_name,
        "file_name": file_name,
        "plugin_name": name,
        "description": description,
        "source_type": actual_source_type,
    }

    # Create file from template
    template_subdir = "benchmark" if is_benchmark else ptype.value
    try:
        template_path = templates_dir / template_subdir / "plugin.py.j2"
        template_content = _load_template(template_path)
        file_content = _render_template(template_content, variables)
    except FileNotFoundError:
        # Fallback to inline templates
        if is_benchmark:
            file_content = _get_benchmark_template_fallback(class_name, file_name, description)
        else:
            file_content = _get_plugin_template_fallback(ptype, class_name, file_name, description, actual_source_type)

    output_file = output_path / f"{file_name}.py"
    output_file.write_text(file_content)

    # Success message
    kind = "benchmark" if is_benchmark else f"{ptype.value} plugin"
    console.print(
        Panel.fit(
            f"[green]Created[/green] {kind}: [bold]{name}[/bold]\n\n"
            f"[dim]Location:[/dim] {output_path.absolute()}\n\n"
            "[dim]Next steps:[/dim]\n"
            f"  1. Edit {file_name}.py to implement your logic\n"
            f"  2. Run [cyan]bizsupply validate {output_file}[/cyan]",
            title=f"{'Benchmark' if is_benchmark else 'Plugin'} Created",
            border_style="green",
        )
    )


def _get_plugin_template_fallback(
    ptype: PluginType, class_name: str, file_name: str, description: str, source_type: str
) -> str:
    """Fallback plugin template if external templates not found."""
    templates = {
        PluginType.source: f'''"""Source plugin: {description or 'Ingests documents from external source'}."""

from typing import Any, AsyncIterator

from bizsupply_sdk import (
    SourcePlugin,
    BaseSourceState,
    DynamicCredential,
    DocumentInput,
)


class {class_name.replace("Plugin", "")}State(BaseSourceState):
    """State model for tracking sync progress."""

    cursor: str | None = None
    last_sync_count: int = 0


class {class_name}(SourcePlugin):
    """{description or 'Source plugin implementation'}.

    Fetches documents from external source. The Engine handles:
    - Injecting credentials and state
    - Creating documents from each yielded DocumentInput
    - Saving state after each document
    """

    # Required: unique identifier for this source type
    source_type = "{source_type}"

    # Required: state model for tracking sync progress
    source_state_model = {class_name.replace("Plugin", "")}State

    # Optional: credentials the user must configure (list of field names)
    credential_fields = ["api_key", "api_url"]

    async def fetch(
        self,
        credentials: DynamicCredential,
        state: {class_name.replace("Plugin", "")}State,
        configs: dict[str, Any],
    ) -> AsyncIterator[DocumentInput]:
        """Yield documents to create. Engine handles persistence and state.

        Args:
            credentials: DynamicCredential injected by Engine
            state: Typed state injected by Engine
            configs: Runtime configuration (from configurable_parameters)

        Yields:
            DocumentInput for each document to create
        """
        # TODO: Fetch data from your source
        # Example:
        # api = MyAPI(credentials.api_key)
        # for item in api.list_items(since=state.cursor):
        #     yield DocumentInput(
        #         file_data=item.content,
        #         filename=item.filename,
        #         metadata={{"source_id": item.id}},
        #     )
        #     state.cursor = item.id
        #     state.last_sync_count += 1

        # Remove this pass when you add your implementation
        pass

    async def has_new_data(
        self,
        credentials: DynamicCredential,
        state: {class_name.replace("Plugin", "")}State,
        configs: dict[str, Any],
    ) -> bool:
        """Check if source has new data since last sync.

        Required for auto-sync functionality.
        """
        # TODO: Implement check for new data
        # Example: return api.has_updates_since(state.cursor)
        return True
''',
        PluginType.classification: f'''"""Classification plugin: {description or 'Classifies documents'}."""

from typing import Any

from bizsupply_sdk import (
    ClassificationPlugin,
    ConfigurableParameter,
    Document,
)


class {class_name}(ClassificationPlugin):
    """{description or 'Classification plugin implementation'}.

    Classification plugins implement classify() to handle one level
    of the ontology hierarchy at a time. The Engine handles traversal.
    """

    # Optional: runtime-configurable parameters
    # configurable_parameters = [
    #     ConfigurableParameter(
    #         parameter_name="classification_prompt_id",
    #         parameter_type="str",
    #         default_value=None,
    #         description="Prompt ID for classification",
    #     ),
    # ]

    async def classify(
        self,
        document: Document,
        file_data: bytes | None,
        mime_type: str | None,
        available_labels: list[str],
        current_path: list[str],
        configs: dict[str, Any],
    ) -> str | None:
        """Classify at a single hierarchy level.

        Args:
            document: The document being classified
            file_data: Raw file bytes (Gemini reads PDFs directly)
            mime_type: File MIME type (e.g., "application/pdf")
            available_labels: Ontology labels at this level
            current_path: Labels already selected (path so far)
            configs: Runtime configuration (prompt IDs, thresholds, etc.)

        Returns:
            - Label from available_labels: Engine continues traversal
            - Label NOT in available_labels: tracked as llm_suggested, stop
            - None: Engine triggers suggestion workflow, stop
        """
        # TODO: Implement your classification logic
        # Example using LLM:
        # prompt_id = configs.get("classification_prompt_id")
        # response = await self.prompt_llm(
        #     prompt=f"Select from {{available_labels}}",
        #     file_data=file_data,
        #     mime_type=mime_type,
        # )
        # return response.get("category")  # str or None

        # Placeholder - replace with actual classification
        path_str = " > ".join(current_path) if current_path else "Root"
        self.logger.info(f"Classifying {{document.document_id}} at {{path_str}}")
        return available_labels[0] if available_labels else None
''',
        PluginType.extraction: f'''"""Extraction plugin: {description or 'Extracts data from documents'}."""

from typing import Any

from bizsupply_sdk import (
    ExtractionPlugin,
    ExtractionResult,
    ConfigurableParameter,
    Document,
    OntologyField,
)


class {class_name}(ExtractionPlugin):
    """{description or 'Extraction plugin implementation'}.

    Extracts structured data from documents. The Engine handles:
    - Resolving fields from document.labels using ontologies
    - Fetching document file_data
    - Persisting extracted data
    """

    # Optional: runtime-configurable parameters
    # configurable_parameters = [
    #     ConfigurableParameter(
    #         parameter_name="extraction_prompt_id",
    #         parameter_type="str",
    #         default_value=None,
    #         description="Prompt ID for extraction",
    #     ),
    # ]

    async def extract(
        self,
        document: Document,
        file_data: bytes | None,
        mime_type: str | None,
        fields: list[OntologyField],
        configs: dict[str, Any],
    ) -> ExtractionResult:
        """Extract data from a single document and return extracted values.

        Args:
            document: The document to extract from (already classified)
            file_data: Raw file bytes (Gemini reads PDFs directly)
            mime_type: MIME type of file_data (e.g., "application/pdf")
            fields: OntologyFields to extract (resolved from document.labels)
            configs: Runtime configuration (prompt IDs, thresholds, etc.)

        Returns:
            ExtractionResult with data dict and optional llm_fields
        """
        # TODO: Implement your extraction logic
        # Example using LLM:
        # prompt_id = configs.get("extraction_prompt_id")
        # fields_json = self.format_fields_for_prompt(fields)
        # response = await self.prompt_llm(
        #     prompt=f"Extract: {{fields_json}}",
        #     file_data=file_data,
        #     mime_type=mime_type,
        # )
        # return ExtractionResult(data=response or {{}})

        # Placeholder - replace with actual extraction
        self.logger.info(f"Extracting {{len(fields)}} fields from {{document.document_id}}")
        return ExtractionResult(data={{}})
''',
    }
    return templates.get(ptype, "# Unsupported plugin type")


def _get_benchmark_template_fallback(
    class_name: str, file_name: str, description: str
) -> str:
    """Fallback benchmark template if external templates not found."""
    return f'''"""Benchmark: {description or 'Custom benchmark implementation'}."""

from bizsupply_sdk import (
    BaseBenchmark,
    ExtendedDocument,
    ScoredDocument,
    MatchCondition,
    MatchRule,
)


class {class_name}(BaseBenchmark):
    """{description or 'Benchmark implementation'}.

    Benchmarks are pure calculation - no I/O, no async.
    The engine handles data fetching, slot resolution, and persistence.
    """

    # Identity properties
    name = "{file_name}"
    target_labels = ["contract"]  # TODO: Set target labels
    metric_unit = "EUR"  # TODO: Set metric unit
    group_by = []  # TODO: Set grouping dimensions (e.g., ["region"])

    # Aggregation rules for linking related documents
    MATCH_RULES = [
        MatchRule(
            name="{file_name}_match",
            left_group=["contract"],  # TODO: Set source document labels
            right_group=["invoice"],  # TODO: Set target document labels
            conditions=[
                MatchCondition(
                    left_field="client_tax_id",
                    right_field="client_tax_id",
                    match_type="==",
                ),
            ],
            description="Match contracts to invoices by client tax ID",
        ),
    ]

    def score(self, document: ExtendedDocument) -> float | None:
        """Calculate score for a single document.

        Args:
            document: ExtendedDocument with typed access and aggregations

        Returns:
            Score as float, or None if not applicable
        """
        if not document.aggregations:
            return None

        # TODO: Implement scoring logic
        # Use inv.get("field_name") to read fields from aggregated documents
        # The engine resolves slot names to semantic fields before construction
        values = [inv.get("price") for inv in document.aggregations]
        values = [v for v in values if v is not None]

        if not values:
            return None

        return sum(values) / len(values)

    def compute(self, results: list[ScoredDocument]) -> float:
        """Compute a single benchmark value from scored documents.

        Args:
            results: Non-empty list of ScoredDocument (each has .document and .score)

        Returns:
            Single benchmark value
        """
        # TODO: Choose computation method
        # min(r.score for r in results)  -> best/lowest
        # max(r.score for r in results)  -> best/highest
        return min(r.score for r in results)

    def compare(self, document_score: float, benchmark_score: float) -> bool:
        """Compare document score against the benchmark value.

        Args:
            document_score: The document's score
            benchmark_score: The benchmark value to compare against

        Returns:
            True if the document scores unfavorably
        """
        # TODO: Implement comparison logic
        # Example (lower is better): return document_score > benchmark_score
        return document_score > benchmark_score
'''


def _get_ontology_template_fallback(
    ontology_name: str, file_name: str, description: str
) -> str:
    """Fallback ontology template if external templates not found."""
    desc = description or "Document taxonomy for classification and extraction"
    return f'''# Ontology: {ontology_name}
# {desc}
#
# This file defines the document classification hierarchy and the fields
# to extract at each level. Upload via API or use in your plugins.
#
# Validate with: bizsupply validate {file_name}.yaml

name: "{ontology_name}"
description: "{desc}"

taxonomy:
  label: "Document"
  fields: []
  children:
    - label: "Contract"
      fields:
        - name: "contract_id"
          dtype: "string"
          description: "Unique contract identifier"
        - name: "start_date"
          dtype: "date"
          description: "Contract start date"
        - name: "is_active"
          dtype: "boolean"
          description: "Whether the contract is currently active"
      children:
        - label: "Energy"
          fields:
            - name: "price_per_kwh"
              dtype: "float"
              description: "Price per kilowatt-hour"
            - name: "power_kw"
              dtype: "float"
              description: "Contracted power in kilowatts"
          children: []
        - label: "Service"
          fields:
            - name: "service_type"
              dtype: "string"
              description: "Type of service provided"
          children: []
    - label: "Invoice"
      fields:
        - name: "invoice_number"
          dtype: "string"
          description: "Invoice reference number"
        - name: "total_amount"
          dtype: "float"
          description: "Total invoice amount"
        - name: "issue_date"
          dtype: "date"
          description: "Date the invoice was issued"
      children: []
'''
