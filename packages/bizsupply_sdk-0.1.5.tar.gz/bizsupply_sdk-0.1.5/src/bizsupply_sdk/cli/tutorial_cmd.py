"""Tutorial command for bizSupply Plugin SDK.

Interactive walkthrough of the plugin development workflow.
Interactive walkthrough of plugin lifecycle methods: fetch/classify/extract.
"""

from __future__ import annotations

import typer
from rich.console import Console
from rich.panel import Panel
from rich.markdown import Markdown
from rich.prompt import Confirm

console = Console()


WORKFLOW_INTRO = """
# bizSupply Plugin Development Workflow

Welcome to the bizSupply Plugin SDK! This tutorial will guide you through
the **three-step workflow** for creating and deploying plugins.

## Overview

```
+-------------------------------------------------------------+
|                                                             |
|   1. INIT        ->    2. VALIDATE                          |
|                                                             |
|   Create plugin       Check code                            |
|   from template       is correct                            |
|                                                             |
+-------------------------------------------------------------+
```

## Plugin Lifecycle

Plugins now use **explicit lifecycle methods** instead of a monolithic `execute()`:

| Plugin Type    | Required Method | What You Return          |
|----------------|-----------------|--------------------------|
| Source         | `fetch()`       | `AsyncIterator[DocumentInput]` |
| Classification | `classify()`    | `str | None`             |
| Extraction     | `extract()`     | `ExtractionResult`       |

**The Engine handles everything else:**
- Fetching credentials and state (source plugins)
- Fetching document file_data (Gemini reads PDFs directly)
- Traversing ontology tree (classification)
- Persisting results to database
- Saving state after each document
"""

STEP_1_INIT = """
# Step 1: Create a Plugin

Use `bizsupply init` to scaffold a new plugin from a template.

## Command

```bash
bizsupply init <type> --name <plugin-name>
```

## Plugin Types

| Type           | Purpose                                    | Method         |
|----------------|--------------------------------------------|----------------|
| `source`       | Ingest documents from external systems     | `fetch()`      |
| `classification` | Classify documents by type               | `classify()`   |
| `extraction`   | Extract structured data from documents     | `extract()`    |

## Examples

```bash
# Create a classification plugin
bizsupply init classification --name invoice-classifier

# Create a source plugin for Salesforce
bizsupply init source --name salesforce-connector

# Create an extraction plugin in a specific directory
bizsupply init extraction --name contract-extractor --output ./plugins
```

## What Gets Created

```
invoice_classifier/
+-- invoice_classifier.py    # Your plugin implementation
```

The generated file contains:
- Plugin class with the correct lifecycle method
- TODO comments showing what to implement
- Type hints and documentation
"""

STEP_2_VALIDATE = """
# Step 2: Validate Your Plugin

Use `bizsupply validate` to check your plugin before deploying.

## Command

```bash
bizsupply validate <plugin-file>
```

## What Gets Checked

- Plugin class inherits from correct base class
- Required lifecycle method exists (`fetch`/`classify`/`extract`)
- Method is async and properly typed
- Required attributes are defined (e.g., `source_type` for source plugins)

## Examples

```bash
# Validate a plugin
bizsupply validate invoice_classifier/invoice_classifier.py

# Validate with verbose output
bizsupply validate invoice_classifier/invoice_classifier.py --verbose
```

## Common Validation Errors

| Error                    | Fix                                              |
|--------------------------|--------------------------------------------------|
| `fetch must be async`    | Add `async` to `def fetch(...)`                  |
| `Missing classify method`| Add `async def classify(...)` to your class      |
| `Missing source_type`    | Add `source_type = "your_type"` attribute        |
| `Wrong return type`      | Return the correct result type for your plugin   |
"""

COMPLETE_EXAMPLE = """
# Complete Example: Invoice Classifier

Here's the full workflow from start to finish:

```bash
# Step 1: Create the plugin
bizsupply init classification --name invoice-classifier
```

```python
# Step 2: Implement classify() in invoice_classifier/invoice_classifier.py
from typing import Any
from bizsupply_sdk import ClassificationPlugin, Document

class InvoiceClassifierPlugin(ClassificationPlugin):
    configurable_parameters = [
        {"parameter_name": "classification_prompt_id", "parameter_type": "str", ...},
    ]

    async def classify(
        self,
        document: Document,
        file_data: bytes | None,
        mime_type: str | None,
        available_labels: list[str],
        current_path: list[str],
        configs: dict[str, Any],
    ) -> str | None:
        # Get prompt from configs if configured
        prompt_id = configs.get("classification_prompt_id")

        # Just pick from available_labels - Engine handles traversal!
        path_str = " > ".join(current_path) if current_path else "Root"
        response = await self.prompt_llm(
            prompt=f"Path: {path_str}\\nOptions: {available_labels}",
            file_data=file_data,  # Gemini reads PDFs directly
            mime_type=mime_type,
        )
        return response.get("category")  # str or None
```

```bash
# Step 3: Validate the plugin
bizsupply validate invoice_classifier/invoice_classifier.py
```

## That's It!

Your plugin is now available on the bizSupply platform.

## Key Benefits

1. **Simpler code** - Just implement business logic
2. **Engine handles persistence** - No manual database calls
3. **Automatic state management** - For source plugins
4. **Better error handling** - Engine manages retries
5. **Multimodal support** - Gemini reads PDFs directly via file_data

## Need Help?

- Documentation: https://bizsupply.readme.io/docs
- Plugin Interface: https://bizsupply.readme.io/docs/plugin-interface
"""


def tutorial_command(
    step: int = typer.Option(
        0,
        "--step",
        "-s",
        help="Show specific step (1=init, 2=validate, 0=all)",
        min=0,
        max=2,
    ),
    interactive: bool = typer.Option(
        True,
        "--interactive/--no-interactive",
        "-i/-n",
        help="Interactive mode with prompts",
    ),
) -> None:
    """Show the plugin development workflow tutorial.

    Example:
        bizsupply tutorial              # Interactive walkthrough
        bizsupply tutorial --step 1     # Show only Step 1: Init
        bizsupply tutorial -n           # Non-interactive (show all)
    """
    sections = [
        (WORKFLOW_INTRO, "Introduction"),
        (STEP_1_INIT, "Step 1: Create a Plugin"),
        (STEP_2_VALIDATE, "Step 2: Validate Your Plugin"),
        (COMPLETE_EXAMPLE, "Complete Example"),
    ]

    if step > 0:
        # Show specific step
        console.print(Markdown(sections[step][0]))
        return

    if not interactive:
        # Show everything at once
        for content, _ in sections:
            console.print(Markdown(content))
            console.print()
        return

    # Interactive mode
    for i, (content, title) in enumerate(sections):
        console.print(Markdown(content))
        console.print()

        if i < len(sections) - 1:
            if not Confirm.ask(f"[dim]Continue to {sections[i + 1][1]}?[/dim]", default=True):
                console.print("\n[dim]Tutorial paused. Run `bizsupply tutorial` to resume.[/dim]")
                raise typer.Exit(0)
            console.print()

    console.print(
        Panel(
            "[green]+[/green] Tutorial complete!\n\n"
            "Ready to create your first plugin? Run:\n"
            "[cyan]bizsupply init classification --name my-plugin[/cyan]",
            title="Done",
            border_style="green",
        )
    )
