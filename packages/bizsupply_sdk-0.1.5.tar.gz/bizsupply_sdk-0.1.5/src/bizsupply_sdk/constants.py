"""Shared data size constants for the bizSupply platform.

These constants are the single source of truth for field size limits
shared between the SDK (public models) and the app (internal models).

SDK models and app models both import from here to stay in sync.
App-only constants (internal DB fields, benchmark tier, etc.) live
in app/components/validation/data_sizes.py.
"""

# =============================================================================
# COMMON FIELD SIZES
# =============================================================================

# Resource names (plugins, ontologies, prompts, pipelines)
MAX_NAME_LENGTH = 50

# Descriptions (all resource descriptions)
MAX_DESCRIPTION_LENGTH = 2000

# Original filenames (filesystem limit)
MAX_FILENAME_LENGTH = 255

# =============================================================================
# LABELS
# =============================================================================

# Maximum length of each label string
MAX_LABEL_LENGTH = 50

# Maximum number of labels in document labels array
MAX_DOCUMENT_LABELS = 10

# =============================================================================
# JSONB SIZE LIMITS (bytes)
# =============================================================================

JSONB_METADATA_MAX_BYTES = 64 * 1024          # 64 KB - documents.metadata
JSONB_DOCUMENT_DATA_MAX_BYTES = 1024 * 1024   # 1 MB - documents.data

# =============================================================================
# ONTOLOGY TREE LIMITS
# =============================================================================

MAX_ONTOLOGY_FIELDS_PER_NODE = 100
MAX_ONTOLOGY_CHILDREN_PER_NODE = 50

# =============================================================================
# FIELD TYPE SIZES
# =============================================================================

# Ontology field dtype: "string", "int", "float", "date", "boolean"
MAX_FIELD_DTYPE_LENGTH = 20
