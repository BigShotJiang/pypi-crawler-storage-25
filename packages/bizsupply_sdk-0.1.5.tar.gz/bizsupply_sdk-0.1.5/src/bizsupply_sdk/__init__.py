"""bizSupply Plugin SDK - The official SDK for developing bizSupply plugins.

This SDK provides:
- Base classes for all plugin types (Source, Classification, Extraction)
- Models for documents, contexts, and ontologies
- Result models for plugin lifecycle contracts
- Configuration models for plugin parameters and credentials
- Protocol definitions for service implementations
- Testing utilities with mock services
- CLI tools for validation and testing

Quick Start:
    from bizsupply_sdk import (
        ClassificationPlugin,
        Document,
    )

    class MyClassifier(ClassificationPlugin):
        configurable_parameters = [
            {"parameter_name": "classification_prompt", "parameter_type": "str", ...},
        ]

        async def classify(
            self,
            document: Document,
            file_data: bytes | None,
            mime_type: str | None,
            available_labels: list[str],
            current_path: list[str],
            configs: dict[str, Any],
        ) -> str | None:
            # Get prompt from configs
            prompt_id = configs.get("classification_prompt")

            # Just pick from available_labels - Engine handles traversal
            # Gemini reads PDFs directly via file_data - no OCR needed
            path_str = " > ".join(current_path) if current_path else "Root"
            response = await self.prompt_llm(
                prompt=f"Path: {path_str}\\nOptions: {available_labels}",
                file_data=file_data,
                mime_type=mime_type,
            )
            return response.get("category")  # str or None

For more information, visit: https://bizsupply.readme.io/docs/plugin-interface
"""

# Plugin base classes
from bizsupply_sdk.core.base_plugins import (
    BasePlugin,
    SourcePlugin,
    ClassificationPlugin,
    ExtractionPlugin,
)

# Configuration models (for plugin class attributes)
from bizsupply_sdk.core.base_plugins import ConfigurableParameter

# Core models
from bizsupply_sdk.core.plugin_type import PluginType
from bizsupply_sdk.core.document import Document
from bizsupply_sdk.core.source_state import BaseSourceState
from bizsupply_sdk.core.credentials import DynamicCredential

# Result models
from bizsupply_sdk.core.results import (
    DocumentInput,
    ClassificationResult,
    ExtractionResult,
)

# Ontology models
from bizsupply_sdk.core.ontology import (
    OntologyField,
    OntologyNode,
    OntologyManifest,
)

# Benchmark models
from bizsupply_sdk.core.base_benchmark import BaseBenchmark
from bizsupply_sdk.core.document import ExtendedDocument, ScoredDocument

# Aggregation models
from bizsupply_sdk.core.aggregation import MatchCondition, MatchRule

# Protocol (for type hints and custom implementations)
from bizsupply_sdk.protocols import PluginServicesProtocol

# Constants (shared with app)
from bizsupply_sdk import constants

# Exceptions (ValueError subclasses, Pydantic-compatible)
from bizsupply_sdk.exceptions import (
    SDKValidationError,
    FieldSizeExceededError,
    JsonbSizeExceededError,
    InvalidOperatorError,
    MissingFieldError,
    InvalidParameterError,
    MissingParameterError,
)

# Validators (shared with app)
from bizsupply_sdk import validators

# Version
__version__ = "0.1.5"

# Public API
__all__ = [
    # Version
    "__version__",
    # Constants
    "constants",
    # Plugin Base Classes
    "BasePlugin",
    "SourcePlugin",
    "ClassificationPlugin",
    "ExtractionPlugin",
    # Configuration Models
    "ConfigurableParameter",
    # Core Models
    "PluginType",
    "Document",
    "BaseSourceState",
    "DynamicCredential",
    # Result Models
    "DocumentInput",
    "ClassificationResult",
    "ExtractionResult",
    # Ontology Models
    "OntologyField",
    "OntologyNode",
    "OntologyManifest",
    # Benchmark Models
    "BaseBenchmark",
    "ExtendedDocument",
    "ScoredDocument",
    # Aggregation Models
    "MatchCondition",
    "MatchRule",
    # Protocol
    "PluginServicesProtocol",
    # Exceptions
    "SDKValidationError",
    "FieldSizeExceededError",
    "JsonbSizeExceededError",
    "InvalidOperatorError",
    "MissingFieldError",
    "InvalidParameterError",
    "MissingParameterError",
    # Validators
    "validators",
]
