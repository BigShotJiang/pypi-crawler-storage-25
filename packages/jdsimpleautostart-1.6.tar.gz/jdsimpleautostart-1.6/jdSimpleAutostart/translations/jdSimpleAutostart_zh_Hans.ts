<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="zh_Hans">
<context>
    <name>AddEditDialog</name>
    <message>
        <location filename="../AddEditDialog.py" line="34"/>
        <source>Add new autostart entry</source>
        <translation>添加新的自动启动项</translation>
    </message>
    <message>
        <location filename="../AddEditDialog.py" line="45"/>
        <source>Edit {{Name}}</source>
        <translation>编辑 {{Name}}</translation>
    </message>
    <message>
        <location filename="../ui/AddEditDialog.ui" line="0"/>
        <source>Name:</source>
        <translation>名称：</translation>
    </message>
    <message>
        <location filename="../ui/AddEditDialog.ui" line="0"/>
        <source>Comment:</source>
        <translation>注释：</translation>
    </message>
    <message>
        <location filename="../ui/AddEditDialog.ui" line="0"/>
        <source>Icon:</source>
        <translation>图标：</translation>
    </message>
    <message>
        <location filename="../ui/AddEditDialog.ui" line="0"/>
        <source>Exec:</source>
        <translation>执行：</translation>
    </message>
</context>
<context>
    <name>AddMenuDialog</name>
    <message>
        <location filename="../AddMenuDialog.py" line="27"/>
        <source>Office</source>
        <translation>办公</translation>
    </message>
    <message>
        <location filename="../AddMenuDialog.py" line="28"/>
        <source>Utilities</source>
        <translation>实用工具</translation>
    </message>
    <message>
        <location filename="../AddMenuDialog.py" line="29"/>
        <source>Settings</source>
        <translation>设置</translation>
    </message>
    <message>
        <location filename="../AddMenuDialog.py" line="30"/>
        <source>Development</source>
        <translation>开发</translation>
    </message>
    <message>
        <location filename="../AddMenuDialog.py" line="31"/>
        <source>Graphics</source>
        <translation>图形</translation>
    </message>
    <message>
        <location filename="../AddMenuDialog.py" line="32"/>
        <source>Internet</source>
        <translation>互联网</translation>
    </message>
    <message>
        <location filename="../AddMenuDialog.py" line="33"/>
        <source>Multimedia</source>
        <translation>多媒体</translation>
    </message>
    <message>
        <location filename="../AddMenuDialog.py" line="34"/>
        <source>Games</source>
        <translation>游戏</translation>
    </message>
    <message>
        <location filename="../AddMenuDialog.py" line="35"/>
        <source>System</source>
        <translation>系统</translation>
    </message>
    <message>
        <location filename="../AddMenuDialog.py" line="54"/>
        <source>Other</source>
        <translation>其他</translation>
    </message>
    <message>
        <location filename="../ui/AddMenuDialog.ui" line="0"/>
        <source>Add from Menu</source>
        <translation>从菜单添加</translation>
    </message>
    <message>
        <location filename="../ui/AddMenuDialog.ui" line="0"/>
        <source>You can add Programs from your Menu to your Autostart</source>
        <translation>您可以从菜单中将程序添加到自动启动中</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../MainWindow.py" line="23"/>
        <source>Error loading autostart entries</source>
        <translation>加载自动启动项时出错</translation>
    </message>
    <message>
        <location filename="../MainWindow.py" line="23"/>
        <source>One or more autostart entries could not be loaded due to an error. It is possible that these are symbolic links that can cause problems.</source>
        <translation>由于错误，无法加载一个或多个自动启动项。这些可能是会导致问题的符号链接。</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>In the List below you see all programs in the Autostart of your Desktop</source>
        <translation>在下方列表中，您可以看到桌面的所有自动启动程序</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>You can enable and disable them with the Checkbox</source>
        <translation>您可以通过复选框启用和禁用它们</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>You can only remove Entries, that you have added, not Entries from your System</source>
        <translation>您只能移除自己添加的项，不能移除系统项</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>Show System Entries</source>
        <translation>显示系统项</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>Add</source>
        <translation>添加</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>Add from Menu</source>
        <translation>从菜单添加</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>Edit</source>
        <translation>编辑</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>Remove</source>
        <translation>移除</translation>
    </message>
</context>
<context>
    <name>jdSimpleAutostart</name>
    <message>
        <location filename="../__init__.py" line="35"/>
        <source>No autostart directories found</source>
        <translation>未找到自动启动目录</translation>
    </message>
    <message>
        <location filename="../__init__.py" line="35"/>
        <source>No autostart directories were found. Maybe your Desktop Environment don&apos;t support the autostart specification.</source>
        <translation>未找到自动启动目录。您的桌面环境可能不支持自动启动规范。</translation>
    </message>
</context>
</TS>
