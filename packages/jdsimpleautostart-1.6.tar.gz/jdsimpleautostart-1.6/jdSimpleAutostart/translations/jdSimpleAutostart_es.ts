<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es">
<context>
    <name>AddEditDialog</name>
    <message>
        <location filename="../AddEditDialog.py" line="34"/>
        <source>Add new autostart entry</source>
        <translation>Añadir una nueva entrada de inicio automático</translation>
    </message>
    <message>
        <location filename="../AddEditDialog.py" line="45"/>
        <source>Edit {{Name}}</source>
        <translation>Editar {{Name}}</translation>
    </message>
    <message>
        <location filename="../ui/AddEditDialog.ui" line="0"/>
        <source>Name:</source>
        <translation>Nombre:</translation>
    </message>
    <message>
        <location filename="../ui/AddEditDialog.ui" line="0"/>
        <source>Comment:</source>
        <translation>Comentario:</translation>
    </message>
    <message>
        <location filename="../ui/AddEditDialog.ui" line="0"/>
        <source>Icon:</source>
        <translation>Icono:</translation>
    </message>
    <message>
        <location filename="../ui/AddEditDialog.ui" line="0"/>
        <source>Exec:</source>
        <translation>Línea de comandos:</translation>
    </message>
</context>
<context>
    <name>AddMenuDialog</name>
    <message>
        <location filename="../AddMenuDialog.py" line="27"/>
        <source>Office</source>
        <translation>Programas ofimáticos</translation>
    </message>
    <message>
        <location filename="../AddMenuDialog.py" line="28"/>
        <source>Utilities</source>
        <translation>Utilidades</translation>
    </message>
    <message>
        <location filename="../AddMenuDialog.py" line="29"/>
        <source>Settings</source>
        <translation>Ajustes</translation>
    </message>
    <message>
        <location filename="../AddMenuDialog.py" line="30"/>
        <source>Development</source>
        <translation>Desarrollo</translation>
    </message>
    <message>
        <location filename="../AddMenuDialog.py" line="31"/>
        <source>Graphics</source>
        <translation>Gráficos</translation>
    </message>
    <message>
        <location filename="../AddMenuDialog.py" line="32"/>
        <source>Internet</source>
        <translation>Internet</translation>
    </message>
    <message>
        <location filename="../AddMenuDialog.py" line="33"/>
        <source>Multimedia</source>
        <translation>Multimedia</translation>
    </message>
    <message>
        <location filename="../AddMenuDialog.py" line="34"/>
        <source>Games</source>
        <translation>Juegos</translation>
    </message>
    <message>
        <location filename="../AddMenuDialog.py" line="35"/>
        <source>System</source>
        <translation>Sistema</translation>
    </message>
    <message>
        <location filename="../AddMenuDialog.py" line="54"/>
        <source>Other</source>
        <translation>Otros</translation>
    </message>
    <message>
        <location filename="../ui/AddMenuDialog.ui" line="0"/>
        <source>Add from Menu</source>
        <translation>Añadir del menú</translation>
    </message>
    <message>
        <location filename="../ui/AddMenuDialog.ui" line="0"/>
        <source>You can add Programs from your Menu to your Autostart</source>
        <translation>Puedes agregar programas de tu menú a tu inicio automático</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../MainWindow.py" line="23"/>
        <source>Error loading autostart entries</source>
        <translation>Error al cargar las entradas del inicio automático</translation>
    </message>
    <message>
        <location filename="../MainWindow.py" line="23"/>
        <source>One or more autostart entries could not be loaded due to an error. It is possible that these are symbolic links that can cause problems.</source>
        <translation>Una o más entradas del inicio automático no pudieron cargarse debido a un error. Es posible que sean enlaces simbólicos que puedan causar problemas.</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>In the List below you see all programs in the Autostart of your Desktop</source>
        <translation>En la siguiente lista puedes ver todos los programas que se ejecutan automáticamente al iniciar el escritorio</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>You can enable and disable them with the Checkbox</source>
        <translation>Puedes activarlas y desactivarlas mediante la casilla de verificación</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>You can only remove Entries, that you have added, not Entries from your System</source>
        <translation>Solo puedes eliminar las entradas que hayas añadido tú mismo, no las entradas que ya están en tu sistema</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>Show System Entries</source>
        <translation>Mostrar entradas del sistema</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>Add</source>
        <translation>Añadir</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>Add from Menu</source>
        <translation>Añadir del menú</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>Edit</source>
        <translation>Editar</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>Remove</source>
        <translation>Quitar</translation>
    </message>
</context>
<context>
    <name>jdSimpleAutostart</name>
    <message>
        <location filename="../__init__.py" line="35"/>
        <source>No autostart directories found</source>
        <translation>No se encontraron directorios en el inicio automático</translation>
    </message>
    <message>
        <location filename="../__init__.py" line="35"/>
        <source>No autostart directories were found. Maybe your Desktop Environment don&apos;t support the autostart specification.</source>
        <translation>No se han encontrado directorios en el inicio automático. Es posible que tu entorno de escritorio no sea compatible con la especificación del inicio automático.</translation>
    </message>
</context>
</TS>
