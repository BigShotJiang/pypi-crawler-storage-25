<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="et">
<context>
    <name>AddEditDialog</name>
    <message>
        <location filename="../AddEditDialog.py" line="34"/>
        <source>Add new autostart entry</source>
        <translation>Lisa uus automaatselt käivitatav objekt</translation>
    </message>
    <message>
        <location filename="../AddEditDialog.py" line="45"/>
        <source>Edit {{Name}}</source>
        <translation>Muuda: {{Name}}</translation>
    </message>
    <message>
        <location filename="../ui/AddEditDialog.ui" line="0"/>
        <source>Name:</source>
        <translation>Nimi:</translation>
    </message>
    <message>
        <location filename="../ui/AddEditDialog.ui" line="0"/>
        <source>Comment:</source>
        <translation>Kommentaar:</translation>
    </message>
    <message>
        <location filename="../ui/AddEditDialog.ui" line="0"/>
        <source>Icon:</source>
        <translation>Ikoon:</translation>
    </message>
    <message>
        <location filename="../ui/AddEditDialog.ui" line="0"/>
        <source>Exec:</source>
        <translation>Käsurida:</translation>
    </message>
</context>
<context>
    <name>AddMenuDialog</name>
    <message>
        <location filename="../AddMenuDialog.py" line="27"/>
        <source>Office</source>
        <translation>Kontoritöö</translation>
    </message>
    <message>
        <location filename="../AddMenuDialog.py" line="28"/>
        <source>Utilities</source>
        <translation>Tööriistad ja tarvikud</translation>
    </message>
    <message>
        <location filename="../AddMenuDialog.py" line="29"/>
        <source>Settings</source>
        <translation>Seadistused</translation>
    </message>
    <message>
        <location filename="../AddMenuDialog.py" line="30"/>
        <source>Development</source>
        <translation>Arendus</translation>
    </message>
    <message>
        <location filename="../AddMenuDialog.py" line="31"/>
        <source>Graphics</source>
        <translation>Graafika</translation>
    </message>
    <message>
        <location filename="../AddMenuDialog.py" line="32"/>
        <source>Internet</source>
        <translation>Internet</translation>
    </message>
    <message>
        <location filename="../AddMenuDialog.py" line="33"/>
        <source>Multimedia</source>
        <translation>Multimeedia</translation>
    </message>
    <message>
        <location filename="../AddMenuDialog.py" line="34"/>
        <source>Games</source>
        <translation>Mängud</translation>
    </message>
    <message>
        <location filename="../AddMenuDialog.py" line="35"/>
        <source>System</source>
        <translation>Süsteem</translation>
    </message>
    <message>
        <location filename="../AddMenuDialog.py" line="54"/>
        <source>Other</source>
        <translation>Muud ja tundmatud</translation>
    </message>
    <message>
        <location filename="../ui/AddMenuDialog.ui" line="0"/>
        <source>Add from Menu</source>
        <translation>Lisa menüüst</translation>
    </message>
    <message>
        <location filename="../ui/AddMenuDialog.ui" line="0"/>
        <source>You can add Programs from your Menu to your Autostart</source>
        <translation>Võid menüüs leiduvaid programme/rakendusi lisada automaatselt käivitatavaks</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../MainWindow.py" line="23"/>
        <source>Error loading autostart entries</source>
        <translation>Viga automaatselt käivitatavate objektide laadimisel</translation>
    </message>
    <message>
        <location filename="../MainWindow.py" line="23"/>
        <source>One or more autostart entries could not be loaded due to an error. It is possible that these are symbolic links that can cause problems.</source>
        <translation>Ühe või enama automaatselt käivitatava objekti laadimine ei õnnestunud vea tõttu. On võimalik, et tegemist on sümbollinkidega ja see võib vigu põhjustada.</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>In the List below you see all programs in the Autostart of your Desktop</source>
        <translation>Järgnevas loendis näed kõiki oma töölauakeskkonnas automaatselt käivitatavaid programme/rakendusi</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>You can enable and disable them with the Checkbox</source>
        <translation>Märkeruudust saad neid sisse/välja lülitada</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>You can only remove Entries, that you have added, not Entries from your System</source>
        <translation>Eemaldada saad vaid kirjeid, mille oled ise lisanud. Süsteemi poolt lisatud kirjeid eemaldada ei saa</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>Show System Entries</source>
        <translation>Näita süsteemi poolt lisatud kirjeid</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>Add</source>
        <translation>Lisa</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>Add from Menu</source>
        <translation>Lisa menüüst</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>Edit</source>
        <translation>Muuda</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>Remove</source>
        <translation>Eemalda</translation>
    </message>
</context>
<context>
    <name>jdSimpleAutostart</name>
    <message>
        <location filename="../__init__.py" line="35"/>
        <source>No autostart directories found</source>
        <translation>Automaatselt käivitatavate objektide kaustu ei leidu</translation>
    </message>
    <message>
        <location filename="../__init__.py" line="35"/>
        <source>No autostart directories were found. Maybe your Desktop Environment don&apos;t support the autostart specification.</source>
        <translation>Ühtegi automaatselt käivitatavate objektide kausta ei leidu. Võib-olla sinu kasutatav töölauakeskkond ei toeta vastavat spetsifikatsiooni.</translation>
    </message>
</context>
</TS>
