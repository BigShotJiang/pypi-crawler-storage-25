from PyQt6.QtCore import QTranslator, QLocale, QLibraryInfo, QCoreApplication
from .Functions import get_system_autostart_path, get_user_autostart_path
from PyQt6.QtWidgets import QApplication, QMessageBox
from PyQt6.QtGui import QIcon
import pathlib
import sys
import os


def main():
    program_dir = os.path.dirname(__file__)

    if not os.path.isdir(os.path.join(program_dir, "ui_compiled")):
        print("Could not find compiled ui files. Please run tools/CompileUI.py first.", file=sys.stderr)
        sys.exit(1)

    if len(list(pathlib.Path(os.path.join(program_dir, "translations")).glob("*.qm"))) == 0:
        print("No compiled translations found. Please run tools/BuildTranslations to build the Translations.py.")

    app = QApplication(sys.argv)

    icon = QIcon(os.path.join(program_dir, "Icon.png"))

    app.setDesktopFileName("page.codeberg.JakobDev.jdSimpleAutostart")
    app.setApplicationName("jdSimpleAutostart")
    app.setWindowIcon(icon)

    qt_translator = QTranslator()
    app_translator = QTranslator()
    app_translator.load(QLocale(), "jdSimpleAutostart", "_", os.path.join(program_dir, "translations"))
    qt_translator.load(QLocale(), "qt", "_", QLibraryInfo.path(QLibraryInfo.LibraryPath.TranslationsPath))
    app.installTranslator(app_translator)
    app.installTranslator(qt_translator)

    if not os.path.isdir(get_system_autostart_path()) and not os.path.isdir(get_user_autostart_path()):
        QMessageBox.critical(None, QCoreApplication.translate("jdSimpleAutostart", "No autostart directories found"), QCoreApplication.translate("jdSimpleAutostart", "No autostart directories were found. Maybe your Desktop Environment don't support the autostart specification."))
        sys.exit(0)

    from .MainWindow import MainWindow

    w = MainWindow(icon)
    w.show()

    sys.exit(app.exec())
