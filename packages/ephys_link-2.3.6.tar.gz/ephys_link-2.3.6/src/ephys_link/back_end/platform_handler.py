"""Manipulator platform handler.

Responsible for performing the various manipulator commands.
Instantiates the appropriate bindings based on the platform type and uses them to perform the commands.

Usage:
    Instantiate PlatformHandler with the platform type and call the desired command.
"""
import asyncio
from typing import final

from vbl_aquarium.models.ephys_link import (
    AngularResponse,
    BooleanStateResponse,
    GetManipulatorsResponse,
    PlatformInfo,
    PositionalResponse,
    SetDepthRequest,
    SetDepthResponse,
    SetInsideBrainRequest,
    SetPositionRequest,
    ShankCountResponse,
)

from ephys_link.front_end.console import Console
from ephys_link.utils.base_binding import BaseBinding
from ephys_link.utils.constants import (
    EMERGENCY_STOP_MESSAGE,
    NO_SET_POSITION_WHILE_INSIDE_BRAIN_ERROR,
    did_not_reach_target_depth_error,
    did_not_reach_target_position_error,
)
from ephys_link.utils.converters import vector4_to_array


@final
class PlatformHandler:
    """Handler for platform commands."""

    def __init__(self, binding: BaseBinding, console: Console) -> None:
        """Initialize platform handler.

        Args:
            binding: Binding instance for the platform.
            console: Console instance.
        """
        # Store the console.
        self._console = console

        # Emergency stop flag for closed-loop jackhammering.
        self._abort_closed_loop = False

        # Define bindings based on platform type.
        self._bindings = binding

        # Record which IDs are inside the brain.
        self._inside_brain: set[str] = set()

    # Platform metadata.

    def get_display_name(self) -> str:
        """Get the display name for the platform.

        Returns:
            Display name for the platform.
        """
        return self._bindings.get_display_name()

    async def get_platform_info(self) -> PlatformInfo:
        """Get the manipulator platform type connected to Ephys Link.

        Returns:
            Platform type config identifier (see CLI options for examples).
        """
        return PlatformInfo(
            name=self._bindings.get_display_name(),
            cli_name=self._bindings.get_cli_name(),
            axes_count=await self._bindings.get_axes_count(),
            dimensions=self._bindings.get_dimensions(),
        )

    # Manipulator commands.

    async def get_manipulators(self) -> GetManipulatorsResponse:
        """Get a list of available manipulators on the current handler.

        Returns:
            List of manipulator IDs or an error message if any.
        """
        try:
            manipulators = await self._bindings.get_manipulators()
        except Exception as e:  # noqa: BLE001
            self._console.exception_error_print("Get Manipulators", e)
            return GetManipulatorsResponse(error=self._console.pretty_exception(e))
        else:
            return GetManipulatorsResponse(manipulators=manipulators)

    async def get_position(self, manipulator_id: str) -> PositionalResponse:
        """Get the current translation position of a manipulator in unified coordinates (mm).

        Args:
            manipulator_id: Manipulator ID.

        Returns:
            Current position of the manipulator and an error message if any.
        """
        try:
            unified_position = self._bindings.platform_space_to_unified_space(
                await self._bindings.get_position(manipulator_id)
            )
        except Exception as e:  # noqa: BLE001
            self._console.exception_error_print("Get Position", e)
            return PositionalResponse(error=self._console.pretty_exception(e))
        else:
            return PositionalResponse(position=unified_position)

    async def get_angles(self, manipulator_id: str) -> AngularResponse:
        """Get the current rotation angles of a manipulator in Yaw, Pitch, Roll (degrees).

        Args:
            manipulator_id: Manipulator ID.

        Returns:
            Current angles of the manipulator and an error message if any.
        """
        try:
            angles = await self._bindings.get_angles(manipulator_id)
        except Exception as e:  # noqa: BLE001
            self._console.exception_error_print("Get Angles", e)
            return AngularResponse(error=self._console.pretty_exception(e))
        else:
            return AngularResponse(angles=angles)

    async def get_shank_count(self, manipulator_id: str) -> ShankCountResponse:
        """Get the number of shanks on a manipulator.

        Args:
            manipulator_id: Manipulator ID.

        Returns:
            Number of shanks on the manipulator and an error message if any.
        """
        try:
            shank_count = await self._bindings.get_shank_count(manipulator_id)
        except Exception as e:  # noqa: BLE001
            self._console.exception_error_print("Get Shank Count", e)
            return ShankCountResponse(error=self._console.pretty_exception(e))
        else:
            return ShankCountResponse(shank_count=shank_count)

    async def set_position(self, request: SetPositionRequest) -> PositionalResponse:
        """Move a manipulator to a specified translation position in unified coordinates (mm).

        Args:
            request: Request to move a manipulator to a specified position.

        Returns:
            Final position of the manipulator and an error message if any.
        """
        try:
            # Disallow setting manipulator position while inside the brain.
            if request.manipulator_id in self._inside_brain:
                self._console.error_print("Set Position", NO_SET_POSITION_WHILE_INSIDE_BRAIN_ERROR)
                return PositionalResponse(error=NO_SET_POSITION_WHILE_INSIDE_BRAIN_ERROR)

            # Move to the new position.
            final_platform_position = await self._bindings.set_position(
                manipulator_id=request.manipulator_id,
                position=self._bindings.unified_space_to_platform_space(request.position),
                speed=request.speed,
            )
            final_unified_position = self._bindings.platform_space_to_unified_space(final_platform_position)

            # Return error if movement did not reach target within tolerance.
            for index, axis in enumerate(vector4_to_array(final_unified_position - request.position)):
                # End once index is the number of axes.
                if index == await self._bindings.get_axes_count():
                    break

                # Check if the axis is within the movement tolerance.
                if abs(axis) > self._bindings.get_movement_tolerance():
                    error_message = did_not_reach_target_position_error(request, index, final_unified_position)
                    self._console.error_print("Set Position", error_message)
                    return PositionalResponse(error=error_message)
        except Exception as e:  # noqa: BLE001
            self._console.exception_error_print("Set Position", e)
            return PositionalResponse(error=self._console.pretty_exception(e))
        else:
            return PositionalResponse(position=final_unified_position)

    async def set_depth(self, request: SetDepthRequest) -> SetDepthResponse:
        """Move a manipulator's depth translation stage to a specific value (mm).

        Args:
            request: Request to move a manipulator to a specified depth.

        Returns:
            Final depth of the manipulator and an error message if any.
        """
        try:
            # Move to the new depth.
            final_depth = await self._bindings.set_depth(
                manipulator_id=request.manipulator_id,
                depth=request.depth,
                speed=request.speed,
            )

            # Return error if movement did not reach target within tolerance.
            if abs(final_depth - request.depth) > self._bindings.get_movement_tolerance():
                error_message = did_not_reach_target_depth_error(request, final_depth)
                self._console.error_print("Set Depth", error_message)
                return SetDepthResponse(error=error_message)
        except Exception as e:  # noqa: BLE001
            self._console.exception_error_print("Set Depth", e)
            return SetDepthResponse(error=self._console.pretty_exception(e))
        else:
            return SetDepthResponse(depth=final_depth)

    async def set_inside_brain(self, request: SetInsideBrainRequest) -> BooleanStateResponse:
        """Mark a manipulator as inside the brain or not.

        This should restrict the manipulator's movement to just the depth axis.

        Args:
            request: Request to set

        Returns:
            Inside brain state of the manipulator and an error message if any.
        """
        if request.inside:
            self._inside_brain.add(request.manipulator_id)
        else:
            self._inside_brain.discard(request.manipulator_id)
        return BooleanStateResponse(state=request.inside)
    
    # Stop closed loop jackhammer if abort flag is set(emergency button pressed)
    async def abort_jackhammer(self) -> None:
        """Abort closed loop jackhammer."""
        self._abort_closed_loop = True

    async def jackhammer(
        self,
        manipulator_id: str,
        axis: int,
        iterations: int,
        phase1_steps: int,
        phase1_pulses: int,
        phase2_steps: int,
        phase2_pulses: int,
        closed_loop: bool = False,
        target_um: float = 0.0,
        max_iterations: int = 50,
    ) -> dict:
        """Perform jackhammer motion to break through dura.

        Args:
            manipulator_id: Manipulator ID.
            axis: Axis to move (0=X, 1=Y, 2=Z, 3=W/Depth).
            iterations: Number of jackhammer cycles (ignored if closed_loop=True).
            phase1_steps: Number of steps in phase 1.
            phase1_pulses: Pulse count for phase 1.
            phase2_steps: Number of steps in phase 2.
            phase2_pulses: Pulse count for phase 2.
            closed_loop: If True, run closed-loop until target reached.
            target_um: Target advancement in micrometers (required if closed_loop=True).

        Returns:
            Dictionary with position, error, and iterations_used (if closed_loop).
        """
        # Closed-loop constants
        MAX_BACKWARD_UM = 250.0

          # Auto-detect axis if -1: uMp-4 uses W (axis 3), uMp-3 uses X (axis 0)
        # Auto-detect depth axis if -1
        if axis == -1:
            axis = self._bindings.get_depth_axis()

        # Helper to get depth based on manipulator type
        def get_depth(pos) -> float:
            """Get depth value based on axis (mm)."""
            if axis == 3:
                return pos.w
            elif axis == 0:
                return pos.x
            elif axis == 1:
                return pos.y
            else:
                return pos.z

        try:
            if closed_loop:
                # Get starting position
                start_pos = await self._bindings.get_position(manipulator_id)
                start_depth = start_pos.w  # mm

                total_backward_count = 0
                consecutive_backward_count = 0
                iterations_used = 0
                last_depth = start_depth

                for i in range(max_iterations):
                    # Check for abort
                    if self._abort_closed_loop:
                        self._abort_closed_loop = False
                        final_pos = await self._bindings.get_position(manipulator_id)
                        final_position = self._bindings.platform_space_to_unified_space(final_pos)
                        total_delta_um = (final_pos.w - start_depth) * 1000
                        return {
                            "position": final_position,
                            "error": "",
                            "iterations_used": iterations_used,
                            "stop_reason": "aborted",
                            "advancement_um": total_delta_um,
                        }

                    # Run single iteration
                    await self._bindings.jackhammer(
                        manipulator_id, axis, 1, phase1_steps, phase1_pulses, phase2_steps, phase2_pulses
                    )
                    iterations_used = i + 1
                    
                    await asyncio.sleep(0.1)  # Let hardware settle before reading position

                    # Get current position
                    current_pos = await self._bindings.get_position(manipulator_id)
                    current_depth = current_pos.w  # mm

                    # Calculate deltas
                    total_delta_um = (current_depth - start_depth) * 1000
                    iteration_delta_um = (current_depth - last_depth) * 1000
                    
                    # Log progress
                    self._console.info_print(
                        "Jackhammer", f"Iteration {iterations_used}: this={iteration_delta_um:+.1f} µm, total={total_delta_um:.1f} µm"
                    )

                    # Check if 90% of target reached
                    if total_delta_um >= target_um * 0.9:
                        final_position = self._bindings.platform_space_to_unified_space(current_pos)
                        return {
                            "position": final_position,
                            "error": "",
                            "iterations_used": iterations_used,
                            "stop_reason": "target_reached",
                            "advancement_um": total_delta_um,
                        }

                    # Check for backward movement this iteration
                    if iteration_delta_um < -MAX_BACKWARD_UM:
                        total_backward_count += 1
                        consecutive_backward_count += 1
                    else:
                        consecutive_backward_count = 0

                    # Stop if too many backward movements
                    if total_backward_count >= 3 or consecutive_backward_count >= 2:
                        final_position = self._bindings.platform_space_to_unified_space(current_pos)
                        return {
                            "position": final_position,
                            "error": "",
                            "iterations_used": iterations_used,
                            "stop_reason": "backward_movement",
                            "advancement_um": total_delta_um,
                        }

                    last_depth = current_depth

                # Max iterations reached
                final_pos = await self._bindings.get_position(manipulator_id)
                final_position = self._bindings.platform_space_to_unified_space(final_pos)
                total_delta_um = (final_pos.w - start_depth) * 1000
                return {
                    "position": final_position,
                    "error": "",
                    "iterations_used": iterations_used,
                    "stop_reason": "max_iterations",
                    "advancement_um": total_delta_um,
                }

            else:
                # Open-loop: run all iterations at once
                await self._bindings.jackhammer(
                    manipulator_id, axis, iterations, phase1_steps, phase1_pulses, phase2_steps, phase2_pulses
                )
                await asyncio.sleep(0.5)  # wait for movement to settle
                final_position = self._bindings.platform_space_to_unified_space(
                    await self._bindings.get_position(manipulator_id)
                )
                return {
                    "position": final_position,
                    "error": "",
                }

        except Exception as e:  # noqa: BLE001
            self._console.exception_error_print("Jackhammer", e)
            return {
                "position": None,
                "error": self._console.pretty_exception(e),
            }
    async def stop(self, manipulator_id: str) -> str:
        """Stop a manipulator.

        Args:
            manipulator_id: Manipulator ID.

        Returns:
            Error message if any.
        """
        try:
            await self._bindings.stop(manipulator_id)
        except Exception as e:  # noqa: BLE001
            self._console.exception_error_print("Stop", e)
            return self._console.pretty_exception(e)
        else:
            return ""

    async def stop_all(self) -> str:
        """Stop all manipulators.

        Returns:
            Error message if any.
        """
        try:
            for manipulator_id in await self._bindings.get_manipulators():
                await self._bindings.stop(manipulator_id)
        except Exception as e:  # noqa: BLE001
            self._console.exception_error_print("Stop All", e)
            return self._console.pretty_exception(e)
        else:
            return ""

    async def emergency_stop(self) -> None:
        """Stops all manipulators with a message."""
        self._console.critical_print(EMERGENCY_STOP_MESSAGE)
        _ = await self.stop_all()
