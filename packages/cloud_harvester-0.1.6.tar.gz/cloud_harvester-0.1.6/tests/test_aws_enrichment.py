import unittest

from cloud_harvester.domain.enums import AwsResource, Provider, ResourceKind
from cloud_harvester.domain.models import Resource
from cloud_harvester.infrastructure.providers.aws.enrichment import (
    enrich_aws_relationships,
)


class AwsEnrichmentTests(unittest.TestCase):
    def test_attached_ebs_volume_inherits_ec2_placement(self) -> None:
        instance = Resource(
            id="i-123",
            provider=Provider.AWS.value,
            kind=ResourceKind.COMPUTE.value,
            resource=AwsResource.EC2.value,
            network_id="vpc-1",
            subnetwork_id="subnet-1",
        )
        volume = Resource(
            id="vol-123",
            provider=Provider.AWS.value,
            kind=ResourceKind.STORAGE.value,
            resource=AwsResource.EBS.value,
            attached_to="i-123",
            raw={"Attachments": [{"InstanceId": "i-123"}]},
        )

        enrich_aws_relationships([instance, volume])

        self.assertEqual(volume.network_id, "vpc-1")
        self.assertEqual(volume.subnetwork_id, "subnet-1")

    def test_documentdb_cluster_inherits_security_group_placement(self) -> None:
        security_group = Resource(
            id="sg-123",
            provider=Provider.AWS.value,
            kind=ResourceKind.SECURITY.value,
            resource=AwsResource.SECURITY_GROUP.value,
            network_id="vpc-1",
        )
        cluster = Resource(
            id="docdb-123",
            provider=Provider.AWS.value,
            kind=ResourceKind.DATABASE.value,
            resource=AwsResource.DOCUMENTDB.value,
            raw={"VpcSecurityGroups": [{"VpcSecurityGroupId": "sg-123"}]},
        )

        enrich_aws_relationships([security_group, cluster])

        self.assertEqual(cluster.security_group_ids, ["sg-123"])
        self.assertEqual(cluster.network_id, "vpc-1")

    def test_elastic_ip_inherits_nat_gateway_placement_by_allocation_id(self) -> None:
        nat_gateway = Resource(
            id="nat-123",
            provider=Provider.AWS.value,
            kind=ResourceKind.NETWORK.value,
            resource=AwsResource.NAT_GATEWAY.value,
            network_id="vpc-1",
            subnetwork_id="subnet-1",
            raw={
                "NatGatewayAddresses": [
                    {
                        "AllocationId": "eipalloc-123",
                        "AssociationId": "eipassoc-123",
                        "NetworkInterfaceId": "eni-123",
                        "PublicIp": "203.0.113.10",
                    }
                ]
            },
        )
        eip = Resource(
            id="eipalloc-123",
            provider=Provider.AWS.value,
            kind=ResourceKind.NETWORK.value,
            resource=AwsResource.ELASTIC_IP.value,
            raw={"AllocationId": "eipalloc-123", "PublicIp": "203.0.113.10"},
        )

        enrich_aws_relationships([nat_gateway, eip])

        self.assertEqual(eip.attached_to, "nat-123")
        self.assertEqual(eip.network_id, "vpc-1")
        self.assertEqual(eip.subnetwork_id, "subnet-1")

    def test_elastic_ip_inherits_ec2_placement_by_attached_instance(self) -> None:
        instance = Resource(
            id="i-123",
            provider=Provider.AWS.value,
            kind=ResourceKind.COMPUTE.value,
            resource=AwsResource.EC2.value,
            network_id="vpc-1",
            subnetwork_id="subnet-1",
        )
        eip = Resource(
            id="eipalloc-123",
            provider=Provider.AWS.value,
            kind=ResourceKind.NETWORK.value,
            resource=AwsResource.ELASTIC_IP.value,
            attached_to="i-123",
            raw={"AllocationId": "eipalloc-123", "InstanceId": "i-123"},
        )

        enrich_aws_relationships([instance, eip])

        self.assertEqual(eip.network_id, "vpc-1")
        self.assertEqual(eip.subnetwork_id, "subnet-1")

    def test_elastic_ip_attached_to_load_balancer_address(self) -> None:
        load_balancer = Resource(
            id="arn:aws:elasticloadbalancing:eu-west-1:123:loadbalancer/net/lb/abc",
            provider=Provider.AWS.value,
            kind=ResourceKind.NETWORK.value,
            resource=AwsResource.ELB.value,
            raw={
                "VpcId": "vpc-1",
                "DNSName": "lb.example.com",
                "AvailabilityZones": [
                    {
                        "ZoneName": "eu-west-1a",
                        "SubnetId": "subnet-1",
                        "LoadBalancerAddresses": [
                            {
                                "AllocationId": "eipalloc-123",
                                "IpAddress": "54.247.10.182",
                            }
                        ],
                    }
                ],
            },
        )
        eip = Resource(
            id="eipalloc-123",
            provider=Provider.AWS.value,
            kind=ResourceKind.NETWORK.value,
            resource=AwsResource.ELASTIC_IP.value,
            raw={"AllocationId": "eipalloc-123", "PublicIp": "54.247.10.182"},
        )

        enrich_aws_relationships([load_balancer, eip])

        self.assertEqual(eip.network_id, "vpc-1")
        self.assertEqual(eip.subnetwork_id, "subnet-1")
        self.assertEqual(eip.placements[0].zone, "eu-west-1a")
        self.assertEqual(eip.relationships[0].type, "attached_to")
        self.assertEqual(eip.relationships[0].target_resource, AwsResource.ELB.value)
        self.assertEqual(eip.addresses[0].value, "54.247.10.182")

    def test_multi_subnet_elb_gets_all_placements(self) -> None:
        load_balancer = Resource(
            id="lb-123",
            provider=Provider.AWS.value,
            kind=ResourceKind.NETWORK.value,
            resource=AwsResource.ELB.value,
            network_id="vpc-1",
            subnetwork_id="subnet-2",
            raw={
                "VpcId": "vpc-1",
                "AvailabilityZones": [
                    {"ZoneName": "eu-west-1a", "SubnetId": "subnet-1"},
                    {"ZoneName": "eu-west-1b", "SubnetId": "subnet-2"},
                    {"ZoneName": "eu-west-1c", "SubnetId": "subnet-3"},
                ],
            },
        )

        enrich_aws_relationships([load_balancer])

        self.assertEqual(
            {placement.subnetwork_id for placement in load_balancer.placements},
            {"subnet-1", "subnet-2", "subnet-3"},
        )
        primary = next(p for p in load_balancer.placements if p.primary)
        self.assertEqual(primary.subnetwork_id, "subnet-2")

    def test_attached_ebs_prefers_networked_ec2_over_ssm_same_id(self) -> None:
        instance = Resource(
            id="i-123",
            provider=Provider.AWS.value,
            kind=ResourceKind.COMPUTE.value,
            resource=AwsResource.EC2.value,
            network_id="vpc-1",
            subnetwork_id="subnet-1",
        )
        ssm = Resource(
            id="i-123",
            provider=Provider.AWS.value,
            kind=ResourceKind.MANAGEMENT.value,
            resource=AwsResource.SYSTEMS_MANAGER.value,
        )
        volume = Resource(
            id="vol-123",
            provider=Provider.AWS.value,
            kind=ResourceKind.STORAGE.value,
            resource=AwsResource.EBS.value,
            attached_to="i-123",
            raw={"Attachments": [{"InstanceId": "i-123"}]},
        )

        enrich_aws_relationships([ssm, instance, volume])

        self.assertEqual(volume.network_id, "vpc-1")
        self.assertEqual(volume.subnetwork_id, "subnet-1")
        self.assertEqual(volume.relationships[0].target_resource, AwsResource.EC2.value)

    def test_elasticache_uses_subnet_group_and_security_groups(self) -> None:
        security_group = Resource(
            id="sg-123",
            provider=Provider.AWS.value,
            kind=ResourceKind.SECURITY.value,
            resource=AwsResource.SECURITY_GROUP.value,
            network_id="vpc-1",
        )
        cache = Resource(
            id="cache-123",
            provider=Provider.AWS.value,
            kind=ResourceKind.DATABASE.value,
            resource=AwsResource.ELASTICACHE.value,
            raw={
                "SecurityGroups": [{"SecurityGroupId": "sg-123"}],
                "_CacheSubnetGroup": {
                    "VpcId": "vpc-1",
                    "Subnets": [
                        {
                            "SubnetIdentifier": "subnet-1",
                            "SubnetAvailabilityZone": {"Name": "eu-west-1a"},
                        }
                    ],
                },
            },
        )

        enrich_aws_relationships([security_group, cache])

        self.assertEqual(cache.network_id, "vpc-1")
        self.assertEqual(cache.subnetwork_id, "subnet-1")
        self.assertEqual(cache.security_group_ids, ["sg-123"])
        self.assertEqual(cache.relationships[0].type, "protected_by")

    def test_efs_uses_mount_targets_and_kms_relationship(self) -> None:
        efs = Resource(
            id="efs-123",
            provider=Provider.AWS.value,
            kind=ResourceKind.STORAGE.value,
            resource=AwsResource.EFS.value,
            raw={
                "KmsKeyId": "arn:aws:kms:eu-west-1:123:key/key-123",
                "_MountTargets": [
                    {
                        "SubnetId": "subnet-1",
                        "VpcId": "vpc-1",
                        "AvailabilityZoneName": "eu-west-1a",
                        "IpAddress": "10.0.0.10",
                        "SecurityGroups": ["sg-123"],
                    }
                ],
            },
        )

        enrich_aws_relationships([efs])

        self.assertEqual(efs.network_id, "vpc-1")
        self.assertEqual(efs.subnetwork_id, "subnet-1")
        self.assertEqual(efs.security_group_ids, ["sg-123"])
        self.assertEqual(efs.addresses[0].value, "10.0.0.10")
        self.assertEqual(efs.relationships[0].type, "encrypted_by")


if __name__ == "__main__":
    unittest.main()
