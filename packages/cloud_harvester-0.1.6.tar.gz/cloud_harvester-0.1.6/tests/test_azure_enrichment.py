import unittest

from cloud_harvester.domain.enums import AzureResource, Provider, ResourceKind
from cloud_harvester.domain.models import Resource
from cloud_harvester.infrastructure.providers.azure.enrichment import (
    enrich_azure_relationships,
)


class AzureEnrichmentTests(unittest.TestCase):
    def test_managed_disk_inherits_vm_placement(self) -> None:
        vm_id = "/subscriptions/sub/resourceGroups/rg/providers/Microsoft.Compute/virtualMachines/vm1"
        vm = Resource(
            id=vm_id,
            provider=Provider.AZURE.value,
            kind=ResourceKind.COMPUTE.value,
            resource=AzureResource.VM.value,
            network_id="/subscriptions/sub/resourceGroups/rg/providers/Microsoft.Network/virtualNetworks/vnet1",
            subnetwork_id="/subscriptions/sub/resourceGroups/rg/providers/Microsoft.Network/virtualNetworks/vnet1/subnets/subnet1",
        )
        disk = Resource(
            id="/subscriptions/sub/resourceGroups/rg/providers/Microsoft.Compute/disks/disk1",
            provider=Provider.AZURE.value,
            kind=ResourceKind.STORAGE.value,
            resource=AzureResource.MANAGED_DISK.value,
            attached_to=vm_id,
            raw={"managedBy": vm_id},
        )

        enrich_azure_relationships([vm, disk])

        self.assertEqual(disk.network_id, vm.network_id)
        self.assertEqual(disk.subnetwork_id, vm.subnetwork_id)
        self.assertEqual(disk.relationships[0].type, "attached_to")
        self.assertEqual(disk.relationships[0].target_resource, AzureResource.VM.value)

    def test_public_ip_inherits_nic_ip_configuration_placement(self) -> None:
        subnet_id = "/subscriptions/sub/resourceGroups/rg/providers/Microsoft.Network/virtualNetworks/vnet1/subnets/subnet1"
        nic_id = "/subscriptions/sub/resourceGroups/rg/providers/Microsoft.Network/networkInterfaces/nic1"
        ip_config_id = f"{nic_id}/ipConfigurations/ipconfig1"
        public_ip_id = "/subscriptions/sub/resourceGroups/rg/providers/Microsoft.Network/publicIPAddresses/pip1"
        nic = Resource(
            id=nic_id,
            provider=Provider.AZURE.value,
            kind=ResourceKind.NETWORK.value,
            resource=AzureResource.NETWORK_INTERFACE.value,
            raw={
                "properties": {
                    "ipConfigurations": [
                        {
                            "id": ip_config_id,
                            "properties": {
                                "primary": True,
                                "privateIPAddress": "10.0.0.4",
                                "publicIPAddress": {"id": public_ip_id},
                                "subnet": {"id": subnet_id},
                            },
                        }
                    ]
                }
            },
        )
        public_ip = Resource(
            id=public_ip_id,
            provider=Provider.AZURE.value,
            kind=ResourceKind.NETWORK.value,
            resource=AzureResource.PUBLIC_IP.value,
            raw={
                "properties": {
                    "ipAddress": "203.0.113.10",
                    "dnsSettings": {"fqdn": "pip1.example.cloudapp.azure.com"},
                    "ipConfiguration": {"id": ip_config_id},
                }
            },
        )

        enrich_azure_relationships([nic, public_ip])

        self.assertEqual(public_ip.subnetwork_id, subnet_id)
        self.assertEqual(public_ip.addresses[0].value, "203.0.113.10")
        self.assertEqual(public_ip.relationships[0].type, "attached_to")
        self.assertEqual(
            public_ip.relationships[0].target_resource,
            AzureResource.NETWORK_INTERFACE.value,
        )
        self.assertEqual(nic.relationships[0].target_id, public_ip_id)

    def test_delegated_subnet_database_gets_placement_and_private_dns(self) -> None:
        subnet_id = "/subscriptions/sub/resourceGroups/rg/providers/Microsoft.Network/virtualNetworks/vnet1/subnets/db"
        dns_id = "/subscriptions/sub/resourceGroups/rg/providers/Microsoft.Network/privateDnsZones/db.local"
        database = Resource(
            id="/subscriptions/sub/resourceGroups/rg/providers/Microsoft.DBforPostgreSQL/flexibleServers/db1",
            provider=Provider.AZURE.value,
            kind=ResourceKind.DATABASE.value,
            resource=AzureResource.POSTGRESQL.value,
            raw={
                "properties": {
                    "network": {
                        "delegatedSubnetResourceId": subnet_id,
                        "privateDnsZoneArmResourceId": dns_id,
                    }
                }
            },
        )

        enrich_azure_relationships([database])

        self.assertEqual(database.subnetwork_id, subnet_id)
        self.assertEqual(database.relationships[0].target_id, dns_id)
        self.assertEqual(database.relationships[0].label, "private-dns-zone")


if __name__ == "__main__":
    unittest.main()
