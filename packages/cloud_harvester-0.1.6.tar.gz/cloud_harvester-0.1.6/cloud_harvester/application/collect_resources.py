from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor, as_completed
import logging
import os
from typing import Callable, Dict, Iterable, List, Optional, Sequence, Tuple

from cloud_harvester.domain.enums import Provider
from cloud_harvester.domain.models import Resource
from cloud_harvester.infrastructure.providers import aws as aws_provider
from cloud_harvester.infrastructure.providers import azure as azure_provider
from cloud_harvester.infrastructure.providers.aws.auth import (
    get_account_id,
    get_configured_regions,
)
from cloud_harvester.infrastructure.providers.aws.enrichment import (
    enrich_aws_relationships,
)
from cloud_harvester.infrastructure.providers.azure.clients import get_subscription_id
from cloud_harvester.infrastructure.providers.azure.enrichment import (
    enrich_azure_relationships,
)

CollectorFn = Callable[..., List[Resource]]
logger = logging.getLogger(__name__)


def collect_resources(
    providers: Optional[Sequence[str]] = None,
    aws_session=None,
    aws_regions: Optional[Sequence[str]] = None,
    azure_credential=None,
    azure_subscription_id: Optional[str] = None,
    max_workers: Optional[int] = None,
    collectors: Optional[Dict[str, Iterable[CollectorFn]]] = None,
) -> List[Resource]:
    """
    Application use case: gather cloud resources from multiple providers.

    Dependency injection:
        collectors: optional mapping of provider -> iterable of collector callables.
                    Defaults to built-in collectors.
        aws_session: forwarded to AWS collectors to reuse auth/config.
        aws_regions: optional explicit AWS regions. Defaults to all enabled regions.
        max_workers: maximum concurrent collector calls. Defaults to 16.
    """
    selected = (
        {p.lower() for p in providers}
        if providers
        else {Provider.AWS.value, Provider.AZURE.value}
    )
    all_collectors = collectors or _default_collectors()
    worker_count = _resolve_max_workers(max_workers)

    logger.info(
        "Starting cloud resource collection for providers: %s with max_workers=%d",
        sorted(selected),
        worker_count,
    )
    resources: List[Resource] = []
    for provider in selected:
        provider_collectors = all_collectors.get(provider)
        if not provider_collectors:
            logger.warning("No collectors configured for provider '%s'", provider)
            continue

        logger.info("Starting %s collection", provider)
        provider_resources: List[Resource] = []
        if provider == Provider.AWS.value:
            provider_resources.extend(
                _collect_aws_resources(
                    provider_collectors,
                    aws_session=aws_session,
                    aws_regions=aws_regions,
                    max_workers=worker_count,
                    split_default_collectors=collectors is None,
                )
            )
        else:
            provider_resources.extend(
                _collect_provider_resources(
                    provider,
                    provider_collectors,
                    max_workers=worker_count,
                    credential=azure_credential,
                    subscription_id=azure_subscription_id,
                )
            )

        _inject_account_id(
            provider, provider_resources, aws_session, azure_subscription_id
        )
        if provider == Provider.AZURE.value:
            provider_resources = enrich_azure_relationships(provider_resources)
        resources.extend(provider_resources)
        logger.info(
            "Finished %s collection with %d resources",
            provider,
            len(provider_resources),
        )

    logger.info("Finished cloud resource collection with %d resources", len(resources))
    return resources


def _collect_aws_resources(
    provider_collectors: Iterable[CollectorFn],
    aws_session=None,
    aws_regions: Optional[Sequence[str]] = None,
    max_workers: int = 16,
    split_default_collectors: bool = True,
) -> List[Resource]:
    regions = get_configured_regions(session=aws_session, regions=aws_regions)
    if not regions:
        logger.warning("No AWS regions resolved; skipping AWS collection")
        return []

    if split_default_collectors:
        global_collectors = tuple(aws_provider.AWS_GLOBAL_COLLECTORS)
        regional_collectors = tuple(aws_provider.AWS_REGIONAL_COLLECTORS)
    else:
        global_collectors = ()
        regional_collectors = tuple(provider_collectors)

    logger.info(
        "AWS collection will scan %d regions: %s",
        len(regions),
        ", ".join(regions),
    )
    logger.info(
        "AWS collector plan: %d global collectors, %d regional collectors, max_workers=%d",
        len(global_collectors),
        len(regional_collectors),
        max_workers,
    )

    resources: List[Resource] = []
    discovery_region = regions[0]
    if global_collectors:
        global_resources = _collect_provider_resources(
            Provider.AWS.value,
            global_collectors,
            max_workers=max_workers,
            session=aws_session,
            region=discovery_region,
        )
        resources.extend(global_resources)
        logger.info(
            "Finished AWS global collectors with %d resources",
            len(global_resources),
        )

    regional_tasks: List[Tuple[CollectorFn, dict]] = []
    for region in regions:
        for collector in regional_collectors:
            regional_tasks.append(
                (collector, {"session": aws_session, "region": region})
            )

    regional_resources = _run_collector_tasks(
        Provider.AWS.value,
        regional_tasks,
        max_workers=max_workers,
    )
    resources.extend(regional_resources)
    logger.info(
        "Finished AWS regional collectors with %d resources",
        len(regional_resources),
    )

    deduped = _dedupe_resources(resources)
    removed = len(resources) - len(deduped)
    if removed:
        logger.info("Removed %d duplicate AWS resources", removed)
    return enrich_aws_relationships(deduped)


def _collect_provider_resources(
    provider: str,
    provider_collectors: Iterable[CollectorFn],
    max_workers: int,
    **kwargs,
) -> List[Resource]:
    tasks = [(collector, kwargs) for collector in provider_collectors]
    return _run_collector_tasks(provider, tasks, max_workers=max_workers)


def _run_collector_tasks(
    provider: str,
    tasks: Iterable[Tuple[CollectorFn, dict]],
    max_workers: int,
) -> List[Resource]:
    task_list = list(tasks)
    if not task_list:
        return []

    if max_workers <= 1 or len(task_list) == 1:
        resources: List[Resource] = []
        for collector, kwargs in task_list:
            resources.extend(_run_collector(provider, collector, **kwargs))
        return resources

    resources = []
    with ThreadPoolExecutor(max_workers=min(max_workers, len(task_list))) as executor:
        futures = [
            executor.submit(_run_collector, provider, collector, **kwargs)
            for collector, kwargs in task_list
        ]
        for future in as_completed(futures):
            resources.extend(future.result())
    return resources


def _resolve_max_workers(max_workers: Optional[int]) -> int:
    if max_workers is not None:
        return max(1, max_workers)

    env_value = os.getenv("CLOUD_HARVESTER_MAX_WORKERS")
    if env_value:
        try:
            return max(1, int(env_value))
        except ValueError:
            logger.warning(
                "Ignoring invalid CLOUD_HARVESTER_MAX_WORKERS value: %s", env_value
            )

    return 16


def _run_collector(provider: str, collector: CollectorFn, **kwargs) -> List[Resource]:
    collector_name = getattr(collector, "__name__", str(collector))
    region = kwargs.get("region")
    region_suffix = f" in {region}" if region else ""
    logger.info(
        "Collecting resources via %s/%s%s", provider, collector_name, region_suffix
    )
    try:
        collected = collector(**kwargs)
        logger.info(
            "Collector %s/%s%s returned %d resources",
            provider,
            collector_name,
            region_suffix,
            len(collected),
        )
        return collected
    except Exception as exc:  # pragma: no cover - logging path
        logger.error(
            "Collector %s/%s%s failed: %s",
            provider,
            collector_name,
            region_suffix,
            exc,
            exc_info=False,
        )
        return []


def _dedupe_resources(resources: Iterable[Resource]) -> List[Resource]:
    deduped: List[Resource] = []
    seen: set[Tuple[str, Optional[str], Optional[str]]] = set()
    for resource in resources:
        key = (resource.provider, resource.resource, resource.id)
        if key in seen:
            continue
        seen.add(key)
        deduped.append(resource)
    return deduped


def _inject_account_id(
    provider: str,
    resources: List[Resource],
    aws_session=None,
    azure_subscription_id=None,
) -> None:
    """Stamp account_id on every resource that doesn't already have one."""
    if not resources:
        return

    if provider == Provider.AWS.value:
        account_id = get_account_id(session=aws_session)
    else:
        try:
            account_id = get_subscription_id(azure_subscription_id)
        except ValueError:
            account_id = None

    if not account_id:
        return

    for resource in resources:
        if resource.account_id is None:
            resource.account_id = account_id


def _default_collectors() -> Dict[str, Iterable[CollectorFn]]:
    return {
        Provider.AWS.value: aws_provider.AWS_COLLECTORS,
        Provider.AZURE.value: azure_provider.AZURE_COLLECTORS,
    }
