from __future__ import annotations

from typing import List, Optional

from cloud_harvester.domain.enums import AzureResource, Provider, ResourceKind
from cloud_harvester.domain.models import Resource
from cloud_harvester.infrastructure.providers.azure.clients import get_network_client
from cloud_harvester.infrastructure.providers.azure.resource_graph import (
    collect_from_resource_graph,
)
from cloud_harvester.infrastructure.providers.azure.utils import (
    extract_network_info,
    resource_group_from_id,
)


def _resource_group_from_id(resource_id: str) -> str:
    parts = resource_id.split("/")
    for idx, part in enumerate(parts):
        if part.lower() == "resourcegroups" and idx + 1 < len(parts):
            return parts[idx + 1]
    raise ValueError(f"Unable to parse resource group from id: {resource_id}")


def collect_vnet(
    credential=None,
    subscription_id: Optional[str] = None,
    network_client=None,
) -> List[Resource]:
    """Collect Azure Virtual Networks and map them to the unified Resource model."""

    network_client = network_client or get_network_client(
        credential=credential, subscription_id=subscription_id
    )
    vnets = network_client.virtual_networks.list_all()

    resources: List[Resource] = []
    for vnet in vnets:
        tags = vnet.tags or {}
        raw = vnet.as_dict() if hasattr(vnet, "as_dict") else vnet.__dict__
        network_id, subnetwork_id = extract_network_info(raw)
        resources.append(
            Resource(
                id=vnet.id,
                provider=Provider.AZURE.value,
                kind=ResourceKind.NETWORK.value,
                resource=AzureResource.VNET.value,
                name=vnet.name,
                region=vnet.location,
                resource_group=resource_group_from_id(vnet.id),
                network_id=network_id,
                subnetwork_id=subnetwork_id,
                status=getattr(vnet, "provisioning_state", None),
                tags=tags,
                raw=raw,
            )
        )
    return resources


def collect_subnets(
    credential=None,
    subscription_id: Optional[str] = None,
    network_client=None,
) -> List[Resource]:
    """Collect Azure Subnets by iterating all VNets."""

    network_client = network_client or get_network_client(
        credential=credential, subscription_id=subscription_id
    )

    resources: List[Resource] = []
    for vnet in network_client.virtual_networks.list_all():
        rg = _resource_group_from_id(vnet.id)
        for subnet in network_client.subnets.list(rg, vnet.name):
            raw = subnet.as_dict() if hasattr(subnet, "as_dict") else subnet.__dict__
            resources.append(
                Resource(
                    id=subnet.id,
                    provider=Provider.AZURE.value,
                    kind=ResourceKind.NETWORK.value,
                    resource=AzureResource.SUBNET.value,
                    name=subnet.name,
                    region=vnet.location,
                    resource_group=resource_group_from_id(vnet.id),
                    network_id=vnet.id,
                    subnetwork_id=subnet.id,
                    status=getattr(subnet, "provisioning_state", None),
                    tags={},
                    raw=raw,
                )
            )
    return resources


def collect_nsgs(
    credential=None, subscription_id: Optional[str] = None
) -> List[Resource]:
    return collect_from_resource_graph(
        resource_types=["microsoft.network/networksecuritygroups"],
        azure_resource=AzureResource.NSG,
        resource_kind=ResourceKind.SECURITY,
        credential=credential,
        subscription_id=subscription_id,
    )


def collect_public_ips(
    credential=None, subscription_id: Optional[str] = None
) -> List[Resource]:
    return collect_from_resource_graph(
        resource_types=["microsoft.network/publicipaddresses"],
        azure_resource=AzureResource.PUBLIC_IP,
        resource_kind=ResourceKind.NETWORK,
        credential=credential,
        subscription_id=subscription_id,
    )


def collect_private_endpoints(
    credential=None, subscription_id: Optional[str] = None
) -> List[Resource]:
    return collect_from_resource_graph(
        resource_types=["microsoft.network/privateendpoints"],
        azure_resource=AzureResource.PRIVATE_ENDPOINT,
        resource_kind=ResourceKind.NETWORK,
        credential=credential,
        subscription_id=subscription_id,
    )


def collect_vpn_gateways(
    credential=None, subscription_id: Optional[str] = None
) -> List[Resource]:
    return collect_from_resource_graph(
        resource_types=["microsoft.network/virtualnetworkgateways"],
        azure_resource=AzureResource.VPN_GATEWAY,
        resource_kind=ResourceKind.NETWORK,
        credential=credential,
        subscription_id=subscription_id,
    )


def collect_azure_firewalls(
    credential=None, subscription_id: Optional[str] = None
) -> List[Resource]:
    return collect_from_resource_graph(
        resource_types=["microsoft.network/azurefirewalls"],
        azure_resource=AzureResource.FIREWALL,
        resource_kind=ResourceKind.SECURITY,
        credential=credential,
        subscription_id=subscription_id,
    )


def collect_load_balancers(
    credential=None, subscription_id: Optional[str] = None
) -> List[Resource]:
    return collect_from_resource_graph(
        resource_types=["microsoft.network/loadbalancers"],
        azure_resource=AzureResource.LOAD_BALANCER,
        resource_kind=ResourceKind.NETWORK,
        credential=credential,
        subscription_id=subscription_id,
    )


def collect_network_interfaces(
    credential=None, subscription_id: Optional[str] = None
) -> List[Resource]:
    return collect_from_resource_graph(
        resource_types=["microsoft.network/networkinterfaces"],
        azure_resource=AzureResource.NETWORK_INTERFACE,
        resource_kind=ResourceKind.NETWORK,
        credential=credential,
        subscription_id=subscription_id,
    )


def collect_application_gateways(
    credential=None, subscription_id: Optional[str] = None
) -> List[Resource]:
    return collect_from_resource_graph(
        resource_types=["microsoft.network/applicationgateways"],
        azure_resource=AzureResource.APPLICATION_GATEWAY,
        resource_kind=ResourceKind.NETWORK,
        credential=credential,
        subscription_id=subscription_id,
    )


def collect_traffic_manager_profiles(
    credential=None, subscription_id: Optional[str] = None
) -> List[Resource]:
    return collect_from_resource_graph(
        resource_types=["microsoft.network/trafficmanagerprofiles"],
        azure_resource=AzureResource.TRAFFIC_MANAGER,
        resource_kind=ResourceKind.NETWORK,
        credential=credential,
        subscription_id=subscription_id,
    )


def collect_api_management_services(
    credential=None, subscription_id: Optional[str] = None
) -> List[Resource]:
    return collect_from_resource_graph(
        resource_types=["microsoft.apimanagement/service"],
        azure_resource=AzureResource.API_MANAGEMENT,
        resource_kind=ResourceKind.NETWORK,
        credential=credential,
        subscription_id=subscription_id,
    )


def collect_dns_zones(
    credential=None, subscription_id: Optional[str] = None
) -> List[Resource]:
    return collect_from_resource_graph(
        resource_types=["microsoft.network/dnszones"],
        azure_resource=AzureResource.DNS,
        resource_kind=ResourceKind.NETWORK,
        credential=credential,
        subscription_id=subscription_id,
    )


def collect_front_door_instances(
    credential=None, subscription_id: Optional[str] = None
) -> List[Resource]:
    return collect_from_resource_graph(
        resource_types=["microsoft.network/frontdoors"],
        azure_resource=AzureResource.FRONT_DOOR,
        resource_kind=ResourceKind.NETWORK,
        credential=credential,
        subscription_id=subscription_id,
    )


def collect_cdn_profiles(
    credential=None, subscription_id: Optional[str] = None
) -> List[Resource]:
    return collect_from_resource_graph(
        resource_types=["microsoft.cdn/profiles"],
        azure_resource=AzureResource.CDN,
        resource_kind=ResourceKind.NETWORK,
        credential=credential,
        subscription_id=subscription_id,
    )
