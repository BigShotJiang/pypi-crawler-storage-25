from __future__ import annotations

from typing import Any, Iterable, NamedTuple, Optional

from cloud_harvester.domain.enums import AzureResource, Provider
from cloud_harvester.domain.graph import (
    add_address,
    add_placement,
    add_relationship,
    finalize_graph_fields,
)
from cloud_harvester.domain.models import Placement, Resource


class _PlacementTarget(NamedTuple):
    resource: Resource
    network_id: Optional[str]
    subnetwork_id: Optional[str]
    zone: Optional[str]
    label: Optional[str]


def enrich_azure_relationships(resources: Iterable[Resource]) -> list[Resource]:
    """Infer Azure graph fields from ARM properties and cross-resource refs."""
    items = list(resources)
    by_resource_id = {
        item.id.lower(): item
        for item in items
        if item.provider == Provider.AZURE.value and item.id
    }

    for item in items:
        if item.provider != Provider.AZURE.value:
            continue
        _add_raw_addresses(item)
        _add_raw_placements(item)
        _add_raw_relationships(item)
        finalize_graph_fields(item)

    placement_by_ref = _placement_refs(items, by_resource_id)

    for item in items:
        if item.provider != Provider.AZURE.value:
            continue

        target = _target_from_attachment(item, placement_by_ref)
        if target is not None:
            _inherit_placement_from_target(item, target)
            add_relationship(
                item,
                relationship_type="attached_to",
                target_id=target.resource.id,
                target_kind=target.resource.kind,
                target_resource=target.resource.resource,
                label=target.label,
            )

        finalize_graph_fields(item)

    return items


def _placement_refs(
    items: Iterable[Resource], by_resource_id: dict[str, Resource]
) -> dict[str, _PlacementTarget]:
    refs = {
        item_id: _target_for_resource(item, label=None)
        for item_id, item in by_resource_id.items()
    }
    for item in items:
        if item.provider != Provider.AZURE.value:
            continue
        for child_id, placement in _child_placement_refs(item):
            refs[child_id.lower()] = _PlacementTarget(
                resource=item,
                network_id=placement.network_id,
                subnetwork_id=placement.subnetwork_id,
                zone=placement.zone,
                label="ip-configuration",
            )
    return refs


def _target_for_resource(item: Resource, label: Optional[str]) -> _PlacementTarget:
    primary = next(
        (placement for placement in item.placements if placement.primary),
        item.placements[0] if item.placements else None,
    )
    return _PlacementTarget(
        resource=item,
        network_id=primary.network_id if primary else item.network_id,
        subnetwork_id=primary.subnetwork_id if primary else item.subnetwork_id,
        zone=primary.zone if primary else item.zone,
        label=label,
    )


def _target_from_attachment(
    item: Resource, placement_by_ref: dict[str, _PlacementTarget]
) -> Optional[_PlacementTarget]:
    for ref in _raw_refs(item):
        target = placement_by_ref.get(ref.lower())
        if target is not None and target.resource.id != item.id:
            if not item.attached_to:
                item.attached_to = target.resource.id
            return target
    return None


def _inherit_placement_from_target(item: Resource, target: _PlacementTarget) -> None:
    item.network_id = item.network_id or target.network_id
    item.subnetwork_id = item.subnetwork_id or target.subnetwork_id
    item.zone = item.zone or target.zone
    add_placement(
        item,
        network_id=target.network_id,
        subnetwork_id=target.subnetwork_id,
        zone=target.zone,
        primary=not any(placement.primary for placement in item.placements),
    )


def _add_raw_addresses(item: Resource) -> None:
    props = _properties(item.raw)
    add_address(item, address_type="public", value=props.get("ipAddress"))
    add_address(item, address_type="private", value=props.get("privateIPAddress"))
    dns_settings = props.get("dnsSettings") or {}
    if isinstance(dns_settings, dict):
        add_address(item, address_type="dns", value=dns_settings.get("fqdn"))

    for ip_config in _ip_configurations(props):
        ip_props = _properties(ip_config)
        add_address(
            item, address_type="private", value=ip_props.get("privateIPAddress")
        )
        public_ip = _id_ref(ip_props.get("publicIPAddress"))
        if public_ip:
            add_relationship(
                item,
                relationship_type="uses",
                target_id=public_ip,
                target_kind="network",
                target_resource=AzureResource.PUBLIC_IP.value,
                label="public-ip",
            )

    for dns_config in props.get("customDnsConfigs") or []:
        if not isinstance(dns_config, dict):
            continue
        for fqdn in dns_config.get("fqdns") or []:
            add_address(item, address_type="dns", value=fqdn)


def _add_raw_placements(item: Resource) -> None:
    props = _properties(item.raw)
    zones = _zones(item.raw)
    resource_type = _normalized_type(item.resource)

    for ip_config in _ip_configurations(props):
        ip_props = _properties(ip_config)
        subnet_id = _id_ref(ip_props.get("subnet"))
        add_placement(
            item,
            network_id=_network_id_from_subnet_id(subnet_id),
            subnetwork_id=subnet_id,
            zone=_first_zone(ip_config.get("zones")) or _first_zone(zones),
            primary=bool(ip_props.get("primary")),
        )

    for subnet_id in _delegated_subnet_ids(props):
        add_placement(
            item,
            network_id=_network_id_from_subnet_id(subnet_id),
            subnetwork_id=subnet_id,
            zone=_first_zone(zones),
        )

    if resource_type == AzureResource.SUBNET.value and item.id:
        add_placement(
            item,
            network_id=_network_id_from_subnet_id(item.id),
            subnetwork_id=item.id,
            zone=_first_zone(zones),
            primary=True,
        )


def _add_raw_relationships(item: Resource) -> None:
    props = _properties(item.raw)
    nsg_id = _id_ref(props.get("networkSecurityGroup"))
    add_relationship(
        item,
        relationship_type="protected_by",
        target_id=nsg_id,
        target_kind="security",
        target_resource=AzureResource.NSG.value,
        label="network-security-group",
    )

    for private_link in props.get("privateLinkServiceConnections") or []:
        if not isinstance(private_link, dict):
            continue
        link_props = _properties(private_link)
        add_relationship(
            item,
            relationship_type="uses",
            target_id=link_props.get("privateLinkServiceId"),
            label="private-link-service",
        )

    for private_dns_zone_id in _private_dns_zone_ids(props):
        add_relationship(
            item,
            relationship_type="uses",
            target_id=private_dns_zone_id,
            target_kind="network",
            target_resource="private-dns-zone",
            label="private-dns-zone",
        )

    encryption_target = _encryption_target(props)
    add_relationship(
        item,
        relationship_type="encrypted_by",
        target_id=encryption_target,
        target_kind="security",
        target_resource="key",
        label="encryption-key",
    )


def _child_placement_refs(item: Resource) -> list[tuple[str, Any]]:
    refs: list[tuple[str, Any]] = []
    props = _properties(item.raw)
    for ip_config in _ip_configurations(props):
        child_id = _id_ref(ip_config)
        if not child_id:
            continue
        ip_props = _properties(ip_config)
        subnet_id = _id_ref(ip_props.get("subnet"))
        refs.append(
            (
                child_id,
                Placement(
                    network_id=_network_id_from_subnet_id(subnet_id),
                    subnetwork_id=subnet_id,
                    zone=_first_zone(ip_config.get("zones")),
                ),
            )
        )
    return refs


def _raw_refs(item: Resource) -> list[str]:
    props = _properties(item.raw)
    refs: list[str] = []
    refs.extend(_string_refs(item.attached_to, item.raw.get("managedBy")))
    refs.extend(_string_refs(_id_ref(props.get("ipConfiguration"))))
    for ref in _walk_id_refs(props):
        refs.append(ref)
    return list(dict.fromkeys(refs))


def _ip_configurations(props: dict[str, Any]) -> list[dict[str, Any]]:
    values: list[dict[str, Any]] = []
    for key in (
        "ipConfigurations",
        "frontendIPConfigurations",
        "gatewayIPConfigurations",
    ):
        for item in props.get(key) or []:
            if isinstance(item, dict):
                values.append(item)

    network_profile = props.get("networkProfile") or {}
    if isinstance(network_profile, dict):
        for agent_pool in network_profile.get("agentPoolProfiles") or []:
            if isinstance(agent_pool, dict) and agent_pool.get("vnetSubnetID"):
                values.append(
                    {"properties": {"subnet": {"id": agent_pool["vnetSubnetID"]}}}
                )

    for agent_pool in props.get("agentPoolProfiles") or []:
        if isinstance(agent_pool, dict) and agent_pool.get("vnetSubnetID"):
            values.append(
                {"properties": {"subnet": {"id": agent_pool["vnetSubnetID"]}}}
            )

    vm_profile = props.get("virtualMachineProfile") or {}
    network_profile = (
        vm_profile.get("networkProfile") if isinstance(vm_profile, dict) else {}
    )
    for nic_config in (network_profile or {}).get(
        "networkInterfaceConfigurations"
    ) or []:
        nic_props = _properties(nic_config)
        values.extend(
            ip_config
            for ip_config in nic_props.get("ipConfigurations") or []
            if isinstance(ip_config, dict)
        )
    return values


def _delegated_subnet_ids(props: dict[str, Any]) -> list[str]:
    subnet_ids = []
    network = props.get("network") or {}
    if isinstance(network, dict):
        subnet_ids.extend(
            _string_refs(
                network.get("delegatedSubnetResourceId"),
                network.get("subnetResourceId"),
            )
        )
    subnet_ids.extend(_string_refs(props.get("subnetId")))
    return subnet_ids


def _private_dns_zone_ids(props: dict[str, Any]) -> list[str]:
    network = props.get("network") or {}
    if not isinstance(network, dict):
        return []
    return _string_refs(network.get("privateDnsZoneArmResourceId"))


def _encryption_target(props: dict[str, Any]) -> Optional[str]:
    encryption = props.get("encryption") or {}
    if isinstance(encryption, dict):
        disk_encryption_set_id = encryption.get("diskEncryptionSetId")
        if isinstance(disk_encryption_set_id, str):
            return disk_encryption_set_id
    data_encryption = props.get("dataEncryption") or {}
    if isinstance(data_encryption, dict):
        return data_encryption.get("primaryKeyURI") or data_encryption.get(
            "geoBackupKeyURI"
        )
    active_key = props.get("activeKey") or {}
    if isinstance(active_key, dict):
        return active_key.get("keyUrl") or _id_ref(active_key.get("sourceVault"))
    return None


def _properties(value: dict[str, Any]) -> dict[str, Any]:
    props = value.get("properties") if isinstance(value, dict) else None
    return props if isinstance(props, dict) else {}


def _id_ref(value: Any) -> Optional[str]:
    if isinstance(value, str):
        return value
    if isinstance(value, dict) and isinstance(value.get("id"), str):
        return value["id"]
    return None


def _walk_id_refs(value: Any) -> list[str]:
    refs: list[str] = []
    stack = [value]
    seen = set()
    while stack:
        current = stack.pop()
        if id(current) in seen:
            continue
        seen.add(id(current))
        if isinstance(current, dict):
            ref = _id_ref(current)
            if ref:
                refs.append(ref)
            stack.extend(
                nested
                for nested in current.values()
                if isinstance(nested, (dict, list, tuple))
            )
        elif isinstance(current, (list, tuple)):
            stack.extend(current)
    return refs


def _network_id_from_subnet_id(subnet_id: Optional[str]) -> Optional[str]:
    if not subnet_id:
        return None
    marker = "/subnets/"
    idx = subnet_id.lower().find(marker)
    if idx == -1:
        return None
    return subnet_id[:idx]


def _zones(raw: dict[str, Any]) -> list[str]:
    zones = raw.get("zones") or []
    return [str(zone) for zone in zones if zone]


def _first_zone(zones: Any) -> Optional[str]:
    if isinstance(zones, list) and zones:
        return str(zones[0])
    if isinstance(zones, str):
        return zones
    return None


def _string_refs(*values: Any) -> list[str]:
    refs = []
    for value in values:
        if isinstance(value, str) and value:
            refs.append(value)
    return refs


def _normalized_type(value: object) -> str:
    return str(value or "").lower().replace("_", "-").replace(" ", "-")
