import logging
import os
import threading
from typing import List, Optional, Sequence

import boto3

logger = logging.getLogger(__name__)
_SESSION_CLIENT_LOCK = threading.Lock()


class _RegionScopedSession:
    """Proxy a boto3 session and default clients/resources to one region."""

    def __init__(self, session, region: str):
        self._session = session
        self.region_name = region

    def client(self, service_name, *args, **kwargs):
        kwargs.setdefault("region_name", self.region_name)
        with _SESSION_CLIENT_LOCK:
            return self._session.client(service_name, *args, **kwargs)

    def resource(self, service_name, *args, **kwargs):
        kwargs.setdefault("region_name", self.region_name)
        with _SESSION_CLIENT_LOCK:
            return self._session.resource(service_name, *args, **kwargs)

    def __getattr__(self, name):
        return getattr(self._session, name)


def get_boto3_session(session=None, region: Optional[str] = None):
    """
    Return a boto3 Session using default credential chain with optional overrides.

    Credentials are resolved in this order:
    1) Provided session
    2) CLOUD_HARVESTER_AWS_PROFILE or AWS_PROFILE (profile-based)
    3) Environment/EC2/ECS/SSO defaults handled by boto3
    """
    if session and region:
        return _RegionScopedSession(session, region)
    if session:
        return session

    profile = os.getenv("CLOUD_HARVESTER_AWS_PROFILE") or os.getenv("AWS_PROFILE")
    return boto3.Session(profile_name=profile, region_name=region)


def get_enabled_regions(
    session=None,
    service_name: str = "ec2",
) -> List[str]:
    """Return enabled AWS regions for the account/session."""
    boto_session = get_boto3_session(session=session)
    discovery_region = boto_session.region_name or "us-east-1"
    logger.info(
        "Discovering enabled AWS regions via %s in %s",
        service_name,
        discovery_region,
    )
    client = boto_session.client(service_name, region_name=discovery_region)
    try:
        response = client.describe_regions(AllRegions=False)
        regions = sorted(
            region_info["RegionName"]
            for region_info in response.get("Regions", [])
            if region_info.get("RegionName")
        )
        logger.info("Discovered %d enabled AWS regions", len(regions))
        return regions
    except Exception:
        regions = boto_session.get_available_regions(service_name)
        logger.warning(
            "Unable to discover enabled AWS regions; falling back to %d SDK regions",
            len(regions),
        )
        return regions


def get_configured_regions(
    session=None,
    regions: Optional[Sequence[str]] = None,
) -> List[str]:
    """
    Resolve AWS collection regions.

    If regions is omitted, discovers all enabled account regions.
    """
    configured = list(regions or [])
    if not configured:
        env_regions = os.getenv("CLOUD_HARVESTER_AWS_REGIONS")
        if env_regions:
            configured = [
                part.strip() for part in env_regions.split(",") if part.strip()
            ]
            logger.info(
                "Using %d AWS regions from CLOUD_HARVESTER_AWS_REGIONS",
                len(configured),
            )

    if not configured:
        logger.info("No AWS regions configured; discovering all enabled regions")
        return get_enabled_regions(session=session)

    resolved = list(dict.fromkeys(configured))
    logger.info("Using %d explicitly configured AWS regions", len(resolved))
    return resolved


def get_account_id(session=None) -> Optional[str]:
    """Return the AWS account ID for the given session via STS."""
    try:
        boto_session = get_boto3_session(session=session)
        return boto_session.client("sts").get_caller_identity()["Account"]
    except Exception:
        return None
