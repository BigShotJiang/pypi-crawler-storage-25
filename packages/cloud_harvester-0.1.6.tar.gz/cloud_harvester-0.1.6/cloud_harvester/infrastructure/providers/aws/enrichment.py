from __future__ import annotations

from typing import Any, Iterable, List, NamedTuple, Optional

from cloud_harvester.domain.enums import AwsResource, Provider
from cloud_harvester.domain.graph import (
    add_address,
    add_placement,
    add_relationship,
    finalize_graph_fields,
)
from cloud_harvester.domain.models import Resource


class _PlacementTarget(NamedTuple):
    resource: Resource
    network_id: Optional[str]
    subnetwork_id: Optional[str]
    zone: Optional[str]
    label: Optional[str]


def enrich_aws_relationships(resources: Iterable[Resource]) -> List[Resource]:
    """Infer AWS graph fields from related resources and raw payload refs."""
    items = list(resources)
    by_resource_id = _index_preferred_resources(items)
    subnet_by_id = {
        item.id: item
        for item in items
        if item.provider == Provider.AWS.value and item.id and _is_subnet(item)
    }
    security_groups_by_id = {
        item.id: item
        for item in items
        if item.provider == Provider.AWS.value and item.id and _is_security_group(item)
    }

    for item in items:
        if item.provider != Provider.AWS.value:
            continue
        _add_raw_security_groups(item)
        _add_raw_addresses(item)
        _add_raw_placements(item, subnet_by_id)
        _add_encryption_relationships(item)
        finalize_graph_fields(item)

    placement_by_ref = _placement_refs(items, by_resource_id)

    for item in items:
        if item.provider != Provider.AWS.value:
            continue

        _add_security_group_relationships(item, security_groups_by_id)

        target = _target_from_attachment(item, placement_by_ref)
        if target is not None:
            _inherit_placement_from_target(item, target)
            add_relationship(
                item,
                relationship_type="attached_to",
                target_id=target.resource.id,
                target_kind=target.resource.kind,
                target_resource=target.resource.resource,
                label=target.label,
            )

        if not item.network_id:
            _inherit_placement_from_security_group(item, security_groups_by_id)

        finalize_graph_fields(item)

    return items


def _index_preferred_resources(items: Iterable[Resource]) -> dict[str, Resource]:
    indexed: dict[str, Resource] = {}
    for item in items:
        if item.provider != Provider.AWS.value or not item.id:
            continue
        current = indexed.get(item.id)
        if current is None or _resource_preference(item) > _resource_preference(
            current
        ):
            indexed[item.id] = item
    return indexed


def _resource_preference(item: Resource) -> tuple[int, int]:
    has_placement = 1 if any((item.network_id, item.subnetwork_id, item.zone)) else 0
    is_compute = 1 if _normalized_type(item.kind) == "compute" else 0
    return has_placement, is_compute


def _placement_refs(
    items: Iterable[Resource], by_resource_id: dict[str, Resource]
) -> dict[str, _PlacementTarget]:
    refs = {
        item_id: _target_for_resource(item, label=None)
        for item_id, item in by_resource_id.items()
    }
    for item in items:
        if item.provider != Provider.AWS.value:
            continue
        for ref in _nat_gateway_address_refs(item.raw):
            refs[ref] = _target_for_resource(item, label="nat-gateway-address")
        for ref, network_id, subnetwork_id, zone in _load_balancer_address_refs(item):
            refs[ref] = _PlacementTarget(
                resource=item,
                network_id=network_id,
                subnetwork_id=subnetwork_id,
                zone=zone,
                label="load-balancer-address",
            )
    return refs


def _target_for_resource(item: Resource, label: Optional[str]) -> _PlacementTarget:
    primary = next(
        (placement for placement in item.placements if placement.primary),
        item.placements[0] if item.placements else None,
    )
    return _PlacementTarget(
        resource=item,
        network_id=primary.network_id if primary else item.network_id,
        subnetwork_id=primary.subnetwork_id if primary else item.subnetwork_id,
        zone=primary.zone if primary else item.zone,
        label=label,
    )


def _target_from_attachment(
    item: Resource, placement_by_ref: dict[str, _PlacementTarget]
) -> Optional[_PlacementTarget]:
    if item.attached_to:
        target = placement_by_ref.get(item.attached_to)
        if target is not None and target.resource.id != item.id:
            return target

    for ref in _raw_placement_refs(item.raw):
        target = placement_by_ref.get(ref)
        if target is not None and target.resource.id != item.id:
            if not item.attached_to:
                item.attached_to = target.resource.id
            return target

    return None


def _inherit_placement_from_target(item: Resource, target: _PlacementTarget) -> None:
    if target.network_id:
        item.network_id = item.network_id or target.network_id
    if target.subnetwork_id:
        item.subnetwork_id = item.subnetwork_id or target.subnetwork_id
    if target.zone:
        item.zone = item.zone or target.zone
    add_placement(
        item,
        network_id=target.network_id,
        subnetwork_id=target.subnetwork_id,
        zone=target.zone,
        primary=not any(placement.primary for placement in item.placements),
    )


def _inherit_placement_from_security_group(
    item: Resource, security_groups_by_id: dict[str, Resource]
) -> None:
    for security_group_id in item.security_group_ids:
        security_group = security_groups_by_id.get(security_group_id)
        if security_group is not None and security_group.network_id:
            item.network_id = security_group.network_id
            item.subnetwork_id = security_group.subnetwork_id
            add_placement(
                item,
                network_id=security_group.network_id,
                subnetwork_id=security_group.subnetwork_id,
                zone=security_group.zone,
                primary=not any(placement.primary for placement in item.placements),
            )
            return


def _add_raw_security_groups(item: Resource) -> None:
    if not item.security_group_ids:
        item.security_group_ids = _raw_security_group_ids(item.raw)


def _add_security_group_relationships(
    item: Resource, security_groups_by_id: dict[str, Resource]
) -> None:
    for security_group_id in item.security_group_ids:
        security_group = security_groups_by_id.get(security_group_id)
        add_relationship(
            item,
            relationship_type="protected_by",
            target_id=security_group_id,
            target_kind=security_group.kind if security_group else "security",
            target_resource=security_group.resource
            if security_group
            else "security-group",
            label="security-group",
        )


def _add_encryption_relationships(item: Resource) -> None:
    raw = item.raw
    key_id = (
        raw.get("KmsKeyId")
        or raw.get("KmsKeyArn")
        or raw.get("KMSKeyId")
        or raw.get("KmsMasterKeyId")
    )
    add_relationship(
        item,
        relationship_type="encrypted_by",
        target_id=str(key_id) if key_id else None,
        target_kind="security",
        target_resource=AwsResource.KMS.value,
        label="kms-key",
    )


def _add_raw_addresses(item: Resource) -> None:
    raw = item.raw
    add_address(item, address_type="public", value=raw.get("PublicIp"))
    add_address(item, address_type="private", value=raw.get("PrivateIpAddress"))
    add_address(item, address_type="private", value=raw.get("IpAddress"))
    add_address(item, address_type="dns", value=raw.get("DNSName"))
    for address in raw.get("Addresses") or []:
        if isinstance(address, dict):
            add_address(item, address_type="public", value=address.get("PublicIp"))
            add_address(item, address_type="private", value=address.get("PrivateIp"))
    for mount_target in raw.get("_MountTargets") or []:
        if isinstance(mount_target, dict):
            add_address(
                item,
                address_type="private",
                value=mount_target.get("IpAddress"),
            )


def _add_raw_placements(item: Resource, subnet_by_id: dict[str, Resource]) -> None:
    raw = item.raw
    resource_type = _normalized_type(item.resource)
    if resource_type in {AwsResource.ELB.value, AwsResource.CLASSIC_ELB.value}:
        _add_load_balancer_placements(item, subnet_by_id)
    elif resource_type == AwsResource.EKS.value:
        config = raw.get("resourcesVpcConfig") or {}
        _add_subnet_id_placements(
            item,
            config.get("subnetIds") or [],
            network_id=config.get("vpcId"),
            subnet_by_id=subnet_by_id,
        )
    elif resource_type == AwsResource.RDS.value:
        subnet_group = raw.get("DBSubnetGroup") or {}
        for subnet in subnet_group.get("Subnets") or []:
            if isinstance(subnet, dict):
                zone = subnet.get("SubnetAvailabilityZone") or {}
                _add_subnet_placement(
                    item,
                    subnet.get("SubnetIdentifier"),
                    network_id=subnet_group.get("VpcId"),
                    zone=zone.get("Name") if isinstance(zone, dict) else None,
                    subnet_by_id=subnet_by_id,
                )
    elif resource_type == AwsResource.OPENSEARCH.value:
        vpc_options = raw.get("VPCOptions") or {}
        _add_subnet_id_placements(
            item,
            vpc_options.get("SubnetIds") or [],
            network_id=vpc_options.get("VPCId"),
            subnet_by_id=subnet_by_id,
        )
    elif resource_type == AwsResource.ELASTICACHE.value:
        subnet_group = raw.get("_CacheSubnetGroup") or {}
        _add_subnet_group_placements(item, subnet_group, subnet_by_id)
    elif resource_type == AwsResource.EFS.value:
        for mount_target in raw.get("_MountTargets") or []:
            if isinstance(mount_target, dict):
                _add_subnet_placement(
                    item,
                    mount_target.get("SubnetId"),
                    network_id=mount_target.get("VpcId"),
                    zone=mount_target.get("AvailabilityZoneName"),
                    subnet_by_id=subnet_by_id,
                )
                for security_group_id in mount_target.get("SecurityGroups") or []:
                    if security_group_id not in item.security_group_ids:
                        item.security_group_ids.append(security_group_id)


def _add_load_balancer_placements(
    item: Resource, subnet_by_id: dict[str, Resource]
) -> None:
    raw = item.raw
    network_id = raw.get("VpcId") or raw.get("VPCId")
    for az in raw.get("AvailabilityZones") or []:
        if isinstance(az, dict):
            _add_subnet_placement(
                item,
                az.get("SubnetId"),
                network_id=network_id,
                zone=az.get("ZoneName"),
                subnet_by_id=subnet_by_id,
            )
    _add_subnet_id_placements(
        item,
        raw.get("Subnets") or [],
        network_id=network_id,
        subnet_by_id=subnet_by_id,
    )


def _add_subnet_group_placements(
    item: Resource, subnet_group: dict[str, Any], subnet_by_id: dict[str, Resource]
) -> None:
    for subnet in subnet_group.get("Subnets") or []:
        if not isinstance(subnet, dict):
            continue
        az = subnet.get("SubnetAvailabilityZone") or {}
        _add_subnet_placement(
            item,
            subnet.get("SubnetIdentifier"),
            network_id=subnet_group.get("VpcId"),
            zone=az.get("Name") if isinstance(az, dict) else None,
            subnet_by_id=subnet_by_id,
        )


def _add_subnet_id_placements(
    item: Resource,
    subnet_ids: Iterable[str],
    *,
    network_id: Optional[str],
    subnet_by_id: dict[str, Resource],
) -> None:
    for subnet_id in subnet_ids:
        _add_subnet_placement(
            item,
            subnet_id,
            network_id=network_id,
            zone=None,
            subnet_by_id=subnet_by_id,
        )


def _add_subnet_placement(
    item: Resource,
    subnet_id: Optional[str],
    *,
    network_id: Optional[str],
    zone: Optional[str],
    subnet_by_id: dict[str, Resource],
) -> None:
    if not subnet_id:
        return
    subnet = subnet_by_id.get(subnet_id)
    add_placement(
        item,
        network_id=network_id or (subnet.network_id if subnet else None),
        subnetwork_id=subnet_id,
        zone=zone or (subnet.zone if subnet else None),
    )


def _is_subnet(resource: Resource) -> bool:
    normalized_resource = _normalized_type(resource.resource)
    normalized_kind = _normalized_type(resource.kind)
    return AwsResource.SUBNET.value in {normalized_resource, normalized_kind}


def _is_security_group(resource: Resource) -> bool:
    normalized_resource = _normalized_type(resource.resource)
    normalized_kind = _normalized_type(resource.kind)
    return AwsResource.SECURITY_GROUP.value in {
        normalized_resource,
        normalized_kind,
    }


def _normalized_type(value: object) -> str:
    return str(value or "").lower().replace("_", "-").replace(" ", "-")


def _raw_security_group_ids(raw: dict[str, Any]) -> list[str]:
    ids: list[str] = []
    for key in ("SecurityGroupIds", "VpcSecurityGroupIds"):
        value = raw.get(key)
        if isinstance(value, list):
            ids.extend(item for item in value if isinstance(item, str) and item)

    for group in raw.get("VpcSecurityGroups") or []:
        if isinstance(group, dict) and group.get("VpcSecurityGroupId"):
            ids.append(str(group["VpcSecurityGroupId"]))

    for group in raw.get("SecurityGroups") or []:
        if not isinstance(group, dict):
            continue
        if group.get("GroupId"):
            ids.append(str(group["GroupId"]))
        if group.get("SecurityGroupId"):
            ids.append(str(group["SecurityGroupId"]))

    return list(dict.fromkeys(ids))


def _nat_gateway_address_refs(raw: dict[str, Any]) -> list[str]:
    refs: list[str] = []
    for address in raw.get("NatGatewayAddresses") or []:
        if not isinstance(address, dict):
            continue
        refs.extend(
            _string_values(
                address.get("AllocationId"),
                address.get("AssociationId"),
                address.get("NetworkInterfaceId"),
                address.get("PublicIp"),
            )
        )
    return refs


def _load_balancer_address_refs(
    item: Resource,
) -> list[tuple[str, Optional[str], Optional[str], Optional[str]]]:
    refs: list[tuple[str, Optional[str], Optional[str], Optional[str]]] = []
    network_id = item.raw.get("VpcId") or item.raw.get("VPCId") or item.network_id
    for az in item.raw.get("AvailabilityZones") or []:
        if not isinstance(az, dict):
            continue
        subnetwork_id = az.get("SubnetId")
        zone = az.get("ZoneName")
        for address in az.get("LoadBalancerAddresses") or []:
            if not isinstance(address, dict):
                continue
            for ref in _string_values(
                address.get("AllocationId"),
                address.get("IpAddress"),
                address.get("PrivateIPv4Address"),
                address.get("IPv6Address"),
            ):
                refs.append((ref, network_id, subnetwork_id, zone))
    return refs


def _raw_placement_refs(raw: dict[str, Any]) -> list[str]:
    refs = _string_values(
        raw.get("AllocationId"),
        raw.get("AssociationId"),
        raw.get("InstanceId"),
        raw.get("NetworkInterfaceId"),
        raw.get("PublicIp"),
    )
    for attachment in raw.get("Attachments") or []:
        if isinstance(attachment, dict):
            refs.extend(
                _string_values(
                    attachment.get("InstanceId"),
                    attachment.get("NetworkInterfaceId"),
                )
            )
    return refs


def _string_values(*values: object) -> list[str]:
    result: list[str] = []
    for value in values:
        if isinstance(value, str) and value:
            result.append(value)
        elif isinstance(value, list):
            result.extend(item for item in value if isinstance(item, str) and item)
    return result
