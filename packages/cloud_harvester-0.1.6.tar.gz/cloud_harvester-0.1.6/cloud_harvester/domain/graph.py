from __future__ import annotations

from typing import Optional

from cloud_harvester.domain.models import Address, Placement, Relationship, Resource


def add_placement(
    resource: Resource,
    *,
    network_id: Optional[str] = None,
    subnetwork_id: Optional[str] = None,
    zone: Optional[str] = None,
    primary: bool = False,
) -> None:
    """Add a placement without duplicating the same network/subnet/zone tuple."""
    if not any((network_id, subnetwork_id, zone)):
        return

    for placement in resource.placements:
        if (
            placement.network_id == network_id
            and placement.subnetwork_id == subnetwork_id
            and placement.zone == zone
        ):
            placement.primary = placement.primary or primary
            return

    resource.placements.append(
        Placement(
            network_id=network_id,
            subnetwork_id=subnetwork_id,
            zone=zone,
            primary=primary,
        )
    )


def add_relationship(
    resource: Resource,
    *,
    relationship_type: str,
    target_id: Optional[str],
    target_kind: Optional[str] = None,
    target_resource: Optional[str] = None,
    label: Optional[str] = None,
) -> None:
    """Add a typed relationship edge when a target exists."""
    if not target_id:
        return

    for relationship in resource.relationships:
        if (
            relationship.type == relationship_type
            and relationship.target_id == target_id
            and relationship.label == label
        ):
            if relationship.target_kind is None:
                relationship.target_kind = target_kind
            if relationship.target_resource is None:
                relationship.target_resource = target_resource
            return

    resource.relationships.append(
        Relationship(
            type=relationship_type,
            target_id=target_id,
            target_kind=target_kind,
            target_resource=target_resource,
            label=label,
        )
    )


def add_address(
    resource: Resource,
    *,
    address_type: str,
    value: Optional[str],
    port: Optional[int] = None,
) -> None:
    """Add a public, private, or DNS address without duplicates."""
    if not value:
        return

    for address in resource.addresses:
        if (
            address.type == address_type
            and address.value == value
            and address.port == port
        ):
            return

    resource.addresses.append(Address(type=address_type, value=value, port=port))


def finalize_graph_fields(resource: Resource) -> None:
    """Backfill scalar placement fields and compute a coarse scope."""
    if any((resource.network_id, resource.subnetwork_id, resource.zone)):
        add_placement(
            resource,
            network_id=resource.network_id,
            subnetwork_id=resource.subnetwork_id,
            zone=resource.zone,
            primary=not any(placement.primary for placement in resource.placements),
        )

    if resource.placements and not any(
        placement.primary for placement in resource.placements
    ):
        resource.placements[0].primary = True

    primary = next(
        (placement for placement in resource.placements if placement.primary),
        resource.placements[0] if resource.placements else None,
    )
    if primary is not None:
        resource.network_id = resource.network_id or primary.network_id
        resource.subnetwork_id = resource.subnetwork_id or primary.subnetwork_id
        resource.zone = resource.zone or primary.zone

    resource.scope = resource.scope or infer_scope(resource)


def infer_scope(resource: Resource) -> str:
    """Return the narrowest generic scope visible on the resource."""
    if resource.subnetwork_id:
        return "subnetwork"
    if resource.network_id:
        return "network"
    if resource.zone:
        return "region"
    if resource.region and resource.region != "global":
        return "region"
    if resource.region == "global":
        return "global"
    if resource.account_id:
        return "account"
    return "resource"
