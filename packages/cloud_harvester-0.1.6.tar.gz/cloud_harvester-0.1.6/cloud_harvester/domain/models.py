from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any, Dict, List, Optional


@dataclass
class Placement:
    """Network placement for resources that can span multiple subnets/zones."""

    network_id: Optional[str] = None
    subnetwork_id: Optional[str] = None
    zone: Optional[str] = None
    primary: bool = False


@dataclass
class Relationship:
    """Typed edge to another cloud resource."""

    type: str
    target_id: str
    target_kind: Optional[str] = None
    target_resource: Optional[str] = None
    label: Optional[str] = None


@dataclass
class Address:
    """Address exposed by a resource."""

    type: str
    value: str
    port: Optional[int] = None


@dataclass
class Resource:
    """Unified cloud resource representation."""

    id: str
    provider: str
    kind: str
    resource: Optional[str] = None
    name: Optional[str] = None
    region: Optional[str] = None
    zone: Optional[str] = None
    account_id: Optional[str] = None
    resource_group: Optional[str] = None
    network_id: Optional[str] = None
    subnetwork_id: Optional[str] = None
    security_group_ids: List[str] = field(default_factory=list)
    attached_to: Optional[str] = None
    iam_role: Optional[str] = None
    status: Optional[str] = None
    tags: Dict[str, str] = field(default_factory=dict)
    raw: Dict[str, Any] = field(default_factory=dict)
    scope: Optional[str] = None
    placements: List[Placement] = field(default_factory=list)
    relationships: List[Relationship] = field(default_factory=list)
    addresses: List[Address] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        """Return a plain dict for serialization or logging."""
        return {
            "id": self.id,
            "provider": self.provider,
            "kind": self.kind,
            "resource": self.resource,
            "name": self.name,
            "region": self.region,
            "zone": self.zone,
            "account_id": self.account_id,
            "resource_group": self.resource_group,
            "network_id": self.network_id,
            "subnetwork_id": self.subnetwork_id,
            "security_group_ids": self.security_group_ids,
            "attached_to": self.attached_to,
            "iam_role": self.iam_role,
            "status": self.status,
            "tags": self.tags,
            "raw": self.raw,
            "scope": self.scope,
            "placements": [_to_dict(item) for item in self.placements],
            "relationships": [_to_dict(item) for item in self.relationships],
            "addresses": [_to_dict(item) for item in self.addresses],
        }


def _to_dict(value: Any) -> Dict[str, Any]:
    if isinstance(value, (Placement, Relationship, Address)):
        return asdict(value)
    if isinstance(value, dict):
        return dict(value)
    return dict(value)
