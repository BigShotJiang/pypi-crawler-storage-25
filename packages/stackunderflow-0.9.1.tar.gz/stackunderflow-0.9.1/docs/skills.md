# Claude Code skills

StackUnderflow ships **Claude Code skills** — markdown files that teach Claude Code *when* to invoke StackUnderflow's discovery commands. With these installed, Claude Code automatically surfaces prior session context at the right moments: starting work in a known project, touching a specific file, or recalling a past decision. The store stops being passive and becomes a reflex.

> **What's a skill?** A skill is a directory under `~/.claude/skills/<name>/` containing a `SKILL.md` file with YAML frontmatter (`name`, `description`) and a markdown body. Claude Code reads the descriptions of every installed skill at session start and decides which to invoke based on the user's request. Skills are documented at <https://code.claude.com/docs/en/skills>.

## What ships

Three skills, one directory each, under `stackunderflow/skills/` in this repo:

| Skill | Trigger | What it runs |
|---|---|---|
| `check-prior-work` | First substantive coding task in a project | `stackunderflow find-sessions-in-path "$(pwd)" --format json --limit 5 --since 30d` |
| `find-related-sessions` | User mentions a specific file path | `stackunderflow find-sessions-touching-file <path> --format json --limit 5 --mode any` |
| `recall-past-decisions` | User references a past decision or rationale | `stackunderflow search-past-decisions "<query>" --format json --limit 10` |

Each skill body documents both the JSON form (for the agent to consume internally) and the human-readable `--format text` form (for when the user asks Claude Code to *show* them the result).

## Where Claude Code looks for skills

Claude Code discovers skills from two locations, in order:

1. **User-level**: `~/.claude/skills/<name>/SKILL.md` — applies to every Claude Code session on this machine. **Recommended for StackUnderflow skills** since the store is per-machine anyway.
2. **Project-level**: `<repo>/.claude/skills/<name>/SKILL.md` — applies only when Claude Code is run from inside that repo. Useful for project-specific skills, but redundant for StackUnderflow's, which apply to every project.

Project-level skills override user-level skills with the same name.

## Install

The recommended path is the bundled installer flag — `stackunderflow init` will copy the three shipped `SKILL.md` files into `~/.claude/skills/` for you:

```bash
stackunderflow init --install-skills
```

The install is idempotent — byte-identical files are skipped silently on re-run, and a destination file that differs from the shipped copy is preserved unless you pass `--skills-force`. Useful flags:

- `--install-skills` — copy the three skills into `~/.claude/skills/` before starting the dashboard.
- `--skills-dest <path>` — override the destination directory (defaults to `~/.claude/skills/`). Handy for testing or non-standard Claude Code setups.
- `--skills-force` — overwrite a destination `SKILL.md` that differs from the shipped copy. Default behaviour preserves local edits with a warning.

Verify the install:

```bash
ls ~/.claude/skills/check-prior-work/SKILL.md
ls ~/.claude/skills/find-related-sessions/SKILL.md
ls ~/.claude/skills/recall-past-decisions/SKILL.md
```

Restart Claude Code (or start a fresh session) and the skills are picked up. Confirm by checking the skill list at session start (Claude Code prints available skills when running with verbose output, or skills are listed in the system prompt context).

### Manual install (alternative)

If you prefer to do the copy yourself — for example to inspect the files first, or to install into a layout the CLI doesn't support — the source files live under `stackunderflow/skills/` in the repo:

```bash
# from the repo root
mkdir -p ~/.claude/skills
cp -r stackunderflow/skills/* ~/.claude/skills/
```

Same files, same destination — just without the idempotency + warning behaviour of the bundled installer.

### Prerequisites

The skills assume `stackunderflow` is on `PATH` and the local store is populated. If you haven't already:

```bash
# Install the package (editable for dev, or pip install for production)
pip install -e .

# Populate the store from existing Claude / Codex / Cursor session files
stackunderflow etl backfill
```

Once `stackunderflow etl status` shows your usage_events count > 0, the skills have data to query.

## Example transcripts

### `check-prior-work` in action

```
User: Add a /api/projects/<slug>/timeline endpoint that returns events ordered by timestamp.

[Claude Code recognizes this as new feature work in an existing project, fires check-prior-work]

[Claude Code runs: stackunderflow find-sessions-in-path "$(pwd)" --format json --limit 5 --since 30d]

Claude Code: Before I dive in, I checked recent sessions on this project:
  - 2026-05-04: "add session export to /api/sessions" (merged)
  - 2026-05-02: "wire up timeline view in frontend" — interesting, this looks
    related. The session worked on the UI side; the backend route doesn't
    exist yet, which matches your request.

I'll proceed with the new endpoint. The existing /api/sessions/<id>/messages
helper has a similar shape — I'll model the timeline route after it.
```

The user gets free continuity: prior frontend work surfaces, the agent uses the same patterns as the prior session, and there's no risk of duplicating effort.

### `find-related-sessions` in action

```
User: Why is stackunderflow/store/queries.py so long? Can we split it up?

[Claude Code recognizes a specific file reference, fires find-related-sessions]

[Claude Code runs: stackunderflow find-sessions-touching-file stackunderflow/store/queries.py --format json --limit 5 --mode any]

Claude Code: I checked the recent sessions on queries.py. The last write was
on 2026-04-30 (session abc123…) — the "Wave 4 mart migration" PR added
the bulk_get_session_costs and bulk_project_summaries helpers there.

The file is long because it's the single SQL home for every read path —
that's a deliberate choice from that session ("one place for all SQL"
in the docstring). Splitting it would mean picking a split axis (by
mart? by route?) and breaking the convention.

Worth talking through before I refactor. What's prompting the question
— readability, test isolation, or something else?
```

The agent doesn't blindly refactor — the prior session's intent surfaces and the user gets a chance to confirm before the new direction overrides the old one.

### `recall-past-decisions` in action

```
User: Wait, didn't we decide to keep watchfiles instead of inotify?

[Claude Code recognizes a past-decision reference, fires recall-past-decisions]

[Claude Code runs: stackunderflow search-past-decisions "watchfiles inotify" --format json --limit 10]

Claude Code: Yes — on 2026-04-25 (session def456…) you and the prior session
landed on watchfiles. The reasoning recorded was:

  "watchfiles is Rust-backed and cross-platform; raw inotify would mean
   a separate macOS path via FSEvents. The watcher is non-critical-path
   so the slight overhead is fine."

So I'll stick with watchfiles for the new feature. Cancel my last suggestion
to swap in inotify.
```

The agent corrects itself with a verifiable citation. If the recall is wrong, the user can open the linked session and check.

### Semantic recall (optional)

`recall-past-decisions` runs over plain `LIKE` substrings by default. If the original conversation used different wording from the user's recall ("watchfiles" vs. "file watching library"), the substring match misses. Install the optional sentence-transformers extra and the skill / CLI / MCP tool can re-rank the substring-matched candidate set by cosine similarity:

```
pip install 'stackunderflow[embeddings]'
stackunderflow search-past-decisions "file watching library" --use-embeddings
```

Each result gains an `embedding_score` in `[0, 1]`; the substring filter still runs first (`--use-embeddings` only re-orders, never widens). Default model is `sentence-transformers/all-MiniLM-L6-v2` (90 MB, 384-dim) and loads lazily on the first call; override via `STACKUNDERFLOW_EMBED_MODEL` or `--embed-model`. The MCP `search_past_decisions` tool takes the matching `use_embeddings: bool` and `embed_model: str` args.

## Optional: project-specific overrides

If you want different behavior per repo (e.g. tighter `--since` window for a fast-moving project), drop a project-level override:

```bash
mkdir -p .claude/skills
cp -r ~/.claude/skills/check-prior-work .claude/skills/
# edit .claude/skills/check-prior-work/SKILL.md to taste
```

Project-level wins over user-level for the same skill name.

## Auto-generated skills

The three skills above are **static** — they teach Claude Code *how* to query the store, and ship with the package. StackUnderflow can also **mine your local store for the workflows specific to one project** and emit `SKILL.md` files for them: "always run `pytest tests/ -q` after editing `stackunderflow/`", "lint with `ruff check --fix`", "never `pkill` — use a graceful SIGTERM first", "never modify `~/.stackunderflow/store.db`". These are derived from ground truth (what actually happened across your sessions), not from `CLAUDE.md` vibes.

```bash
# Mine the project the current directory belongs to; write to ./.claude/skills/auto-*/
stackunderflow skills generate

# Preview without writing
stackunderflow skills generate --dry-run --format json

# Tune the bar / window / scope
stackunderflow skills generate --project -Users-you-dev-foo --min-occurrences 8 --window 60d

# See what's been generated
stackunderflow skills list

# Remove generated skills (only auto-* dirs marked auto_generated: true — never your own)
stackunderflow skills clean --older-than 30d   # preview; add --yes to delete
```

What gets mined (pattern kinds): `canonical-test-command`, `always-runs-X-after-Y` (a command that reliably follows edits), `uses-tool-flag-combo` (a flag combo this project favours), `avoids-X` (a command the user keeps correcting away from), `never-touches-paths` (a file the user keeps steering edits away from). Restrict with `--kind` (repeatable).

### Guardrails (these are deliberate, not optional)

- **Project-scoped by default.** `stackunderflow skills generate` mines exactly one project — the one the current directory belongs to, or `--project SLUG`. There is no `--all-projects` flag. Cross-project mining is opt-in via `--scope user --projects A,B,C` (an explicit allowlist), which writes global skills to `~/.claude/skills/`.
- **Never written into the package, never released.** Generated skills land under `<project>/.claude/skills/auto-*/SKILL.md` (or `~/.claude/skills/` with `--scope user`) — never into `stackunderflow/skills/`. `.gitignore` ignores `.claude/skills/auto-*/`; the wheel/sdist build explicitly excludes `**/auto-*/SKILL.md`.
- **Labelled.** Directory prefix `auto-`, frontmatter `auto_generated: true` + `pattern_kind` + `pattern_id` + `evidence_count`, and the body opens with a `<!-- Generated by stackunderflow skills generate at <ts> from <N> sessions -->` marker.
- **Idempotent + non-destructive.** Re-running overwrites in place (the previous `SKILL.md` is backed up to `SKILL.md.bak` first) and never touches a hand-authored skill — writing skips any target directory whose `SKILL.md` isn't marked `auto_generated: true`. The directory name is derived deterministically from the pattern; the rare slug collision gets a `-<hash>` suffix so it's explicit, not silent.
- **Pure-regex synthesis, no network.** No LLM call — patterns come from parsing `messages` in the local SQLite store. (An opt-in `--use-llm` refinement pass is a possible future addition.)

The synthesis lives in `stackunderflow/services/skill_synth.py`; the bulk-load helper it uses is `stackunderflow.services.discovery.load_messages_for_project`.

## Future work

`stackunderflow init --install-skills` covers the idempotent install of the three static skills today; there's no longer a manual-only path. Possible follow-ups: a `stackunderflow skills update` subcommand that diffs the destination against the shipped copy without writing anything (preview), or a per-skill opt-out flag (`--skip-skill <name>`) for users who want only a subset of the three.

## Validation

The repo has a smoke test (`tests/test_skills.py`) that verifies each shipped `SKILL.md` parses as valid YAML frontmatter + non-empty body. Run it after editing skill files:

```bash
pytest tests/test_skills.py -q
```

## Troubleshooting

**Skill descriptions not appearing in Claude Code's skill list.** Check the file lives at `~/.claude/skills/<name>/SKILL.md` (not `~/.claude/skills/<name>.md`). The directory layout is required.

**Skill fires but the CLI command fails.** `stackunderflow` not on `PATH`, or the store is empty. Run `which stackunderflow` and `stackunderflow etl status`. If the store has zero events, run `stackunderflow etl backfill` first.

**Skill never fires.** The `description` frontmatter is the trigger surface — Claude Code reads it and decides. If the skill is too narrow ("only use when user says X verbatim"), it won't fire on paraphrases. The shipped descriptions are tuned with example phrasings; if you customize, keep them example-driven.

**Wrong skill fires.** Two skills with overlapping triggers can both match; Claude Code picks one. Tighten the descriptions to disambiguate (e.g. add explicit "Do NOT fire for X" sections in the body).
