"""Claude Code session adapter.

Handles two on-disk formats:
1. Modern per-project JSONL files at ~/.claude/projects/<slug>/<uuid>.jsonl
2. Legacy centralised ~/.claude/history.jsonl for projects that pre-date
   the per-project format (directories with only .continuation_cache.json).

Defensive sizing: JSONL files larger than ``MAX_SESSION_FILE_BYTES``
(128 MB; see ``stackunderflow/adapters/_streaming.py``) are **skipped
with a logged warning** rather than parsed. Smaller files stream
line-by-line so peak memory stays bounded.
"""

from __future__ import annotations

import logging
import os
import sqlite3
from collections.abc import Iterable
from datetime import UTC
from pathlib import Path

import orjson

from ._streaming import iter_jsonl_lines
from .base import Record, SessionRef

_log = logging.getLogger(__name__)


class ClaudeAdapter:
    name = "claude"

    # Variants Anthropic ships under separate XDG-style homes — Opus,
    # Sonnet, Haiku, and the GLM (Anthropic's local-model preview)
    # build. Empty on a default install; included here so the watcher
    # picks them up automatically once the user installs one.
    _VARIANT_HOMES = (
        ".claude-opus",
        ".claude-sonnet",
        ".claude-haiku",
        ".claude-glm",
    )

    def watch_paths(self) -> list[Path]:
        """Return the on-disk roots whose JSONL writes the watcher should
        pick up.

        Always includes ``~/.claude/projects``; conditionally adds each
        ``~/.claude-{opus,sonnet,haiku,glm}/projects`` that exists. The
        watcher filters again on ``Path.exists()`` before handing them
        to ``watchfiles``, so missing roots here are a clean no-op.
        """
        home = Path.home()
        roots: list[Path] = [home / ".claude" / "projects"]
        for variant in self._VARIANT_HOMES:
            candidate = home / variant / "projects"
            if candidate.is_dir():
                roots.append(candidate)
        return roots

    def enumerate(self) -> Iterable[SessionRef]:
        root = Path.home() / ".claude" / "projects"
        if not root.is_dir():
            return

        for project_dir in root.iterdir():
            if not project_dir.is_dir():
                continue

            jsonl_files = sorted(project_dir.glob("*.jsonl"))
            if jsonl_files:
                yield from self._refs_from_jsonl(project_dir, jsonl_files)
            elif (project_dir / ".continuation_cache.json").exists():
                yield from self._refs_from_history(project_dir)

    def read(self, ref: SessionRef, *, since_offset: int = 0) -> Iterable[Record]:
        if ref.session_id.startswith("legacy-"):
            yield from self._read_history(ref)
            return
        yield from self._read_jsonl(ref, since_offset=since_offset)

    def materialize_metadata(self, conn: sqlite3.Connection) -> None:
        """Post-ingest hook: index Claude Code agent-team metadata.

        Scans ``~/.claude/teams/`` + ``~/.claude/tasks/`` and writes the
        team graph into the schema (``agent_teams`` rows + the ``sessions``
        team columns) so the dashboard's Agents tab can JOIN instead of
        re-parsing ``raw_json`` on every render. Idempotent and cheap; a
        machine with no agent-teams activity is a no-op. ``run_ingest``
        calls this after the per-file ingest sweep — wrapped in its own
        try/except there so a hiccup here can never break ingest.
        """
        from .claude_teams import materialize_team_metadata

        materialize_team_metadata(conn, provider=self.name)

    # ── internals ─────────────────────────────────────────────────────

    def _refs_from_jsonl(self, project_dir: Path, files: list[Path]) -> Iterable[SessionRef]:
        for fp in files:
            stat = fp.stat()
            yield SessionRef(
                provider=self.name,
                project_slug=project_dir.name,
                session_id=fp.stem,
                file_path=fp,
                file_mtime=stat.st_mtime,
                file_size=stat.st_size,
            )

    def _refs_from_history(self, project_dir: Path) -> Iterable[SessionRef]:
        # One synthetic ref per legacy project; all history entries for that
        # project get yielded by read() as one pseudo-session.
        history_file = Path.home() / ".claude" / "history.jsonl"
        if not history_file.is_file():
            return
        stat = history_file.stat()
        yield SessionRef(
            provider=self.name,
            project_slug=project_dir.name,
            session_id=f"legacy-{project_dir.name}",
            file_path=history_file,
            file_mtime=stat.st_mtime,
            file_size=stat.st_size,
        )

    # ── reading modern JSONL ──────────────────────────────────────────

    def _read_jsonl(self, ref: SessionRef, *, since_offset: int) -> Iterable[Record]:
        """Yield records strictly past ``since_offset``.

        ``seq`` and ``since_offset`` share the same units (byte position
        of the line start). We seek to ``since_offset`` and then yield
        only records whose ``seq`` is strictly greater than the floor —
        ``since_offset == 0`` is treated specially (yield all records,
        starting from the file head).

        Files larger than ``adapters._streaming.MAX_SESSION_FILE_BYTES``
        (128 MB) are skipped with a warning rather than parsed.
        """
        for line_offset, raw_line in iter_jsonl_lines(
            ref.file_path, since_offset=since_offset,
        ):
            # `since_offset == 0` means "fresh read, yield everything".
            # Otherwise, the caller already saw the record at exactly
            # `since_offset`, so skip it.
            if since_offset > 0 and line_offset <= since_offset:
                continue
            stripped = raw_line.strip()
            if not stripped:
                continue
            try:
                obj = orjson.loads(stripped)
            except (orjson.JSONDecodeError, ValueError):
                continue
            record = self._parse_line(obj, ref=ref, seq=line_offset)
            if record is not None:
                yield record

    def _parse_line(self, obj: dict, *, ref: SessionRef, seq: int) -> Record | None:
        msg = obj.get("message") if isinstance(obj.get("message"), dict) else {}
        role = _role_from(obj, msg)
        if role is None:
            return None
        usage = msg.get("usage", {}) if isinstance(msg, dict) else {}
        return Record(
            provider=self.name,
            session_id=obj.get("sessionId") or ref.session_id,
            seq=seq,
            timestamp=str(obj.get("timestamp", "")),
            role=role,
            model=_model_from(msg),
            input_tokens=int(usage.get("input_tokens", 0) or 0),
            output_tokens=int(usage.get("output_tokens", 0) or 0),
            cache_create_tokens=int(usage.get("cache_creation_input_tokens", 0) or 0),
            cache_read_tokens=int(usage.get("cache_read_input_tokens", 0) or 0),
            content_text=_text_from(msg),
            tools=_tools_from(msg),
            cwd=obj.get("cwd") or None,
            is_sidechain=bool(obj.get("isSidechain", False)),
            uuid=obj.get("uuid", ""),
            parent_uuid=obj.get("parentUuid"),
            raw=obj,
            speed=_speed_from(usage),
        )

    def _read_history(self, ref: SessionRef) -> Iterable[Record]:
        if not ref.file_path.is_file():
            return
        # ``iter_jsonl_lines`` enforces the 128 MB cap defensively (yields
        # nothing for oversize files) and streams line-by-line, so a
        # multi-MB legacy log never lands fully in memory.
        target_slug = ref.project_slug
        seq = 0
        for _line_offset, raw_line in iter_jsonl_lines(ref.file_path):
            stripped = raw_line.strip()
            if not stripped:
                continue
            try:
                obj = orjson.loads(stripped)
            except (orjson.JSONDecodeError, ValueError):
                continue
            project = obj.get("project", "")
            if not project:
                continue
            if _slug_for(project) != target_slug:
                continue
            display = obj.get("display", "")
            ts_ms = int(obj.get("timestamp", 0))
            if not ts_ms:
                continue
            ts_iso = _epoch_ms_to_iso(ts_ms)
            session_id = obj.get("sessionId") or ref.session_id
            yield Record(
                provider=self.name,
                session_id=session_id,
                seq=seq,
                timestamp=ts_iso,
                role="user",
                model=None,
                input_tokens=0,
                output_tokens=0,
                cache_create_tokens=0,
                cache_read_tokens=0,
                content_text=display,
                tools=(),
                cwd=None,
                is_sidechain=False,
                uuid="",
                parent_uuid=None,
                raw=obj,
            )
            seq += 1


def _slug_for(project_path: str) -> str:
    return (
        os.path.abspath(project_path)
        .rstrip(os.sep)
        .replace(os.sep, "-")
        .replace("_", "-")
    )


def _epoch_ms_to_iso(ts_ms: int) -> str:
    from datetime import datetime
    return datetime.fromtimestamp(ts_ms / 1000, tz=UTC).isoformat()


def _role_from(obj: dict, msg: dict) -> str | None:
    raw_type = obj.get("type", "")
    if raw_type == "user":
        return "user"
    if raw_type == "assistant":
        return "assistant"
    if raw_type in ("summary", "compact_summary"):
        return None  # not a conversational record
    if isinstance(msg, dict):
        role = msg.get("role")
        if role in ("user", "assistant"):
            return role
    return None


def _model_from(msg: dict) -> str | None:
    """Extract the model id, dropping Claude Code's ``"<synthetic>"`` sentinel.

    Claude Code itself stamps ``message.model = "<synthetic>"`` on locally
    generated placeholder records — API errors ("Rate limit reached",
    "ECONNRESET", "Not logged in"), invalid-request stubs, and the
    "No response requested." marker. Those rows carry zero tokens and zero
    cost, so propagating the literal string as the model id only pollutes
    user-facing surfaces (e.g. ``stackunderflow compare`` showed it as a
    distinct row alongside real models). Treat it as "no model recorded"
    so downstream cost/compare paths skip the row the same way they skip
    any other ``model IS NULL`` record.
    """
    if not isinstance(msg, dict):
        return None
    raw = msg.get("model")
    if not raw or raw == "<synthetic>":
        return None
    return raw


def _text_from(msg: dict) -> str:
    if not isinstance(msg, dict):
        return ""
    body = msg.get("content", "")
    if isinstance(body, str):
        return body
    if not isinstance(body, list):
        return ""
    pieces: list[str] = []
    for blk in body:
        if isinstance(blk, dict) and blk.get("type") == "text":
            pieces.append(blk.get("text", ""))
        elif isinstance(blk, str):
            pieces.append(blk)
    return "\n".join(pieces)


def _speed_from(usage: dict) -> str:
    """Map Anthropic's ``service_tier`` field to our 2-value enum.

    Anthropic's documented ``service_tier`` values are ``"standard"``,
    ``"priority"`` (priority/fast tier — bills at ~6× standard for Opus),
    and ``"batch"``. The field also appears as ``null`` on records that
    pre-date the tier rollout. Anything other than ``"priority"`` is
    treated as standard so we never *over-charge* a session: getting
    Opus billed at 1× when it should have been 6× under-reports spend
    (the reason this feature exists), but the inverse — billing
    standard records at 6× — would be a far worse failure mode.
    """
    if not isinstance(usage, dict):
        return "standard"
    tier = usage.get("service_tier")
    if tier == "priority":
        return "fast"
    return "standard"


def _tools_from(msg: dict) -> tuple[str, ...]:
    if not isinstance(msg, dict):
        return ()
    body = msg.get("content")
    if not isinstance(body, list):
        return ()
    names: list[str] = []
    for blk in body:
        if isinstance(blk, dict) and blk.get("type") == "tool_use":
            name = blk.get("name", "")
            if name:
                names.append(name)
    return tuple(names)
