"""Project management routes."""

import os
from collections import defaultdict
from pathlib import Path
from typing import Annotated

from fastapi import APIRouter, HTTPException, Query
from fastapi.responses import JSONResponse

import stackunderflow.deps as deps
from stackunderflow.infra.currency import active_currency_payload
from stackunderflow.infra.discovery import locate_logs as find_claude_logs
from stackunderflow.store import db, mart_queries, queries

router = APIRouter()


# Set project endpoint
@router.post("/api/project")
async def set_project(data: dict[str, str]):
    """Set the project path to analyze"""
    project_path = data.get("project_path")
    if not project_path:
        raise HTTPException(status_code=400, detail="Project path is required")

    # Validate project path exists
    if not os.path.exists(project_path):
        raise HTTPException(status_code=400, detail=f"Project path does not exist: {project_path}")

    # Find Claude logs for this project
    log_path = find_claude_logs(project_path)
    if not log_path or not os.path.exists(log_path):
        raise HTTPException(
            status_code=404,
            detail=f"Claude logs not found for project: {project_path}. "
            f"Make sure you have used Claude with this project.",
        )

    deps.current_project_path = project_path
    deps.current_log_path = log_path

    return JSONResponse(
        {
            "status": "success",
            "project_path": project_path,
            "log_path": log_path,
            "message": "Project set successfully. You can now view the dashboard.",
        }
    )


# Get current project
@router.get("/api/project")
async def get_current_project():
    """Get the current project being analyzed"""
    if not deps.current_project_path:
        return JSONResponse({"status": "no_project", "message": "No project selected"})

    return JSONResponse(
        {
            "status": "active",
            "project_path": deps.current_project_path,
            "log_path": deps.current_log_path,
            "log_dir_name": Path(deps.current_log_path).name if deps.current_log_path else None,
        }
    )


# Set project by log directory name
@router.post("/api/project-by-dir")
async def set_project_by_dir(data: dict[str, str]):
    """Set the project by log directory name"""
    dir_name = data.get("dir_name")
    if not dir_name:
        raise HTTPException(status_code=400, detail="Directory name is required")

    # Build the log path
    claude_base = Path.home() / ".claude" / "projects"
    log_path = (claude_base / dir_name).resolve()
    if not str(log_path).startswith(str(claude_base.resolve()) + os.sep):
        raise HTTPException(status_code=400, detail="Invalid path")

    if not log_path.exists() or not log_path.is_dir():
        raise HTTPException(status_code=404, detail=f"Log directory not found: {dir_name}")

    # Check if it has log files
    log_files = list(log_path.glob("*.jsonl"))
    if not log_files:
        raise HTTPException(status_code=404, detail=f"No log files found in directory: {dir_name}")

    # Try to convert back to project path (best effort)
    if dir_name.startswith("-"):
        project_path = dir_name[1:].replace("-", "/")
    else:
        project_path = dir_name

    deps.current_project_path = project_path
    deps.current_log_path = str(log_path)

    # Index for search/QA in background (search and QA services use store data)
    try:
        if deps.search_service is not None:
            conn = db.connect(deps.store_path)
            try:
                project_row = queries.get_project(conn, slug=dir_name)
                if project_row is not None:
                    queries.list_sessions(conn, project_id=project_row.id)
            finally:
                conn.close()
    except Exception:  # noqa: S110
        pass

    return JSONResponse(
        {
            "status": "success",
            "project_path": project_path,
            "log_path": str(log_path),
            "log_dir_name": dir_name,
            "message": f"Now analyzing logs from: {dir_name}",
        }
    )


# Get recent projects from store
@router.get("/api/recent-projects")
async def get_recent_projects():
    """Get list of recent projects from session store"""
    try:
        conn = db.connect(deps.store_path)
        try:
            project_rows = queries.list_projects(conn)
        finally:
            conn.close()

        projects = [
            {
                "dir_name": p.slug,
                "log_path": p.path or "",
                "last_modified": p.last_modified,
                "file_count": 0,  # not tracked in store
            }
            for p in project_rows
        ]

        return JSONResponse({"projects": projects[:20]})

    except Exception as e:
        return JSONResponse({"projects": [], "error": str(e)})


# Comprehensive projects endpoint for global stats
@router.get("/api/projects")
async def get_projects(
    include_stats: bool = False,
    sort_by: str = "last_modified",
    limit: int | None = None,
    offset: int = 0,
    provider: Annotated[list[str] | None, Query()] = None,
):
    """
    Get all available Claude projects with metadata.

    Args:
        include_stats: Include statistics for each project (may be slower)
        sort_by: Sort field (last_modified, first_seen, size, name)
        limit: Maximum number of projects to return
        offset: Offset for pagination
        provider: Optional repeated query param (``?provider=cursor&provider=cline``)
            scoping the project list to those providers. Empty = "all".
            Case-insensitive on read, lowercased before comparison.

    Returns:
        JSON with projects list and metadata
    """
    # Normalise provider filter: lowercase + drop empties so callers that
    # pass `?provider=Cursor` work without round-tripping through the URL
    # canonicalisation in `services/filters.tsx`.
    provider_filter: set[str] | None = None
    if provider:
        normed = {p.strip().lower() for p in provider if p and p.strip()}
        if normed:
            provider_filter = normed

    try:
        conn = db.connect(deps.store_path)
        try:
            project_rows = queries.list_projects(conn)
            if provider_filter is not None:
                project_rows = [
                    p for p in project_rows
                    if (p.provider or "").lower() in provider_filter
                ]

            # Wave 3A: prefer ``project_mart`` for the stats payload —
            # one indexed scan over the materialised totals beats the
            # bulk-aggregate pass (PR #65) which still touches every
            # message row. The bulk helpers stay as the fallback so
            # stores that haven't run the ETL pipeline keep working.
            session_counts = queries.bulk_session_counts(conn)

            mart_rows: dict[int, dict] = {}
            if include_stats:
                for row in mart_queries.list_project_mart(conn):
                    mart_rows[int(row["project_id"])] = row

            # Project ids whose mart row is missing fall back to the
            # bulk SQL helpers — keeps the response shape stable while
            # an in-flight ETL backfill is still working through the
            # store.
            uncovered_ids = {
                p.id for p in project_rows if p.id not in mart_rows
            }
            if include_stats and uncovered_ids:
                lite_stats = queries.bulk_project_lite_stats(conn)
                cost_by_pid = queries.bulk_project_cost(conn)
            else:
                lite_stats = {}
                cost_by_pid = {}

            # Schema has UNIQUE(provider, slug) — same project used through
            # multiple providers (e.g. claude + codex) yields multiple rows.
            # Merge them so the user-facing list has one entry per slug.
            slug_groups: dict[str, list] = defaultdict(list)
            for p in project_rows:
                slug_groups[p.slug].append(p)

            projects = []
            for slug, group in slug_groups.items():
                primary = max(group, key=lambda p: p.last_modified)
                log_path = _resolve_log_dir(primary.path, slug)
                projects.append(
                    {
                        "dir_name": slug,
                        "log_path": log_path,
                        "file_count": sum(
                            session_counts.get(p.id, 0) for p in group
                        ),
                        "total_size_mb": _dir_size_mb(log_path),
                        "last_modified": max(p.last_modified for p in group),
                        "first_seen": min(p.first_seen for p in group),
                        "display_name": primary.display_name,
                        "in_cache": False,
                        "url_slug": slug,
                        "stats": None,
                        "provider": primary.provider,
                        "providers": sorted({p.provider for p in group}),
                        "_ids": [p.id for p in group],
                    }
                )

            if sort_by == "last_modified":
                projects.sort(key=lambda x: x["last_modified"], reverse=True)
            elif sort_by == "first_seen":
                projects.sort(key=lambda x: x["first_seen"])
            elif sort_by == "size":
                projects.sort(key=lambda x: x["total_size_mb"], reverse=True)
            elif sort_by == "name":
                projects.sort(key=lambda x: x["display_name"])

            total_count = len(projects)
            if limit:
                projects = projects[offset : offset + limit]

            if include_stats:
                for proj in projects:
                    proj["stats"] = _stats_for_ids(
                        proj["_ids"],
                        mart_rows=mart_rows,
                        lite_stats=lite_stats,
                        cost_by_pid=cost_by_pid,
                    )

            for proj in projects:
                proj.pop("_ids", None)
        finally:
            conn.close()

        currency = active_currency_payload()
        rate = currency["rate_from_usd"]
        if rate != 1.0 and include_stats:
            for proj in projects:
                stats = proj.get("stats")
                if isinstance(stats, dict) and "total_cost" in stats:
                    stats["total_cost"] = float(stats["total_cost"]) * rate

        return JSONResponse(
            {
                "projects": projects,
                "total_count": total_count,
                "has_more": offset + limit < total_count if limit else False,
                "cache_status": {
                    "cached_count": 0,
                    "total_projects": total_count,
                },
                "currency": currency,
            }
        )

    except Exception as e:
        import traceback

        traceback.print_exc()
        return JSONResponse({"error": f"Failed to get projects: {str(e)}"}, status_code=500)


def _resolve_log_dir(path: str | None, slug: str) -> str:
    if path:
        return path
    return str(Path.home() / ".claude" / "projects" / slug)


# Per-(path, mtime) cache so the project list doesn't re-glob the
# filesystem for 188 directories on every list request. mtime-keyed
# entries auto-invalidate when files are added/removed.
_dir_size_cache: dict[tuple[str, float], float] = {}


def _dir_size_mb(log_dir: str) -> float:
    p = Path(log_dir)
    try:
        st = p.stat()
    except OSError:
        return 0.0
    if not Path(log_dir).is_dir():
        return 0.0
    key = (log_dir, st.st_mtime)
    if key in _dir_size_cache:
        return _dir_size_cache[key]
    try:
        total = sum(f.stat().st_size for f in p.glob("*.jsonl"))
    except OSError:
        return 0.0
    mb = round(total / (1024 * 1024), 2)
    _dir_size_cache[key] = mb
    return mb


def _stats_for_ids(
    project_ids: list[int],
    *,
    mart_rows: dict[int, dict],
    lite_stats: dict[int, dict],
    cost_by_pid: dict[int, float],
) -> dict:
    """Resolve per-project stats — mart-first, bulk-SQL fallback.

    For each project id we prefer the materialised ``project_mart`` row
    when present, otherwise fall back to the bulk SQL helpers (PR #65).
    Provider-duplicates of one slug get summed/min'd/max'd via the
    same rules ``_bulk_lite_merge`` already applied so the UI shape is
    independent of the data source.
    """
    pre_mart_ids = [pid for pid in project_ids if pid not in mart_rows]
    mart_present_ids = [pid for pid in project_ids if pid in mart_rows]

    if not mart_present_ids:
        return _bulk_lite_merge(pre_mart_ids, lite_stats, cost_by_pid)

    # mixed case: combine mart rows + lite-stats fallback rows. Both
    # produce the same UI shape so we can sum across them safely.
    parts: list[dict] = []
    for pid in mart_present_ids:
        parts.append(_mart_row_to_stats(mart_rows[pid]))
    if pre_mart_ids:
        parts.append(_bulk_lite_merge(pre_mart_ids, lite_stats, cost_by_pid))

    if len(parts) == 1:
        return parts[0]
    starts = [p["first_message_date"] for p in parts if p["first_message_date"]]
    ends = [p["last_message_date"] for p in parts if p["last_message_date"]]
    return {
        "total_input_tokens": sum(p["total_input_tokens"] for p in parts),
        "total_output_tokens": sum(p["total_output_tokens"] for p in parts),
        "total_cache_read": sum(p["total_cache_read"] for p in parts),
        "total_cache_write": sum(p["total_cache_write"] for p in parts),
        "total_commands": sum(p["total_commands"] for p in parts),
        "avg_tokens_per_command": 0,
        "avg_steps_per_command": 0,
        "compact_summary_count": 0,
        "first_message_date": min(starts) if starts else None,
        "last_message_date": max(ends) if ends else None,
        "total_cost": sum(p["total_cost"] for p in parts),
    }


def _mart_row_to_stats(row: dict) -> dict:
    """Project ``project_mart`` row → ProjectStats UI shape.

    Aggregator-only fields (avg_tokens_per_command, etc.) default to
    zero/None — same as ``bulk_project_lite_stats``. The list view
    doesn't surface them and the per-project detail view runs the full
    aggregator separately.
    """
    return {
        "total_input_tokens": int(row.get("total_input_tokens", 0) or 0),
        "total_output_tokens": int(row.get("total_output_tokens", 0) or 0),
        "total_cache_read": int(row.get("total_cache_read", 0) or 0),
        "total_cache_write": int(row.get("total_cache_create", 0) or 0),
        "total_commands": 0,
        "avg_tokens_per_command": 0,
        "avg_steps_per_command": 0,
        "compact_summary_count": 0,
        "first_message_date": row.get("first_ts"),
        "last_message_date": row.get("last_ts"),
        "total_cost": float(row.get("total_cost_usd", 0.0) or 0.0),
    }


def _bulk_lite_merge(
    project_ids: list[int],
    lite_stats: dict[int, dict],
    cost_by_pid: dict[int, float],
) -> dict:
    """Merge bulk-lite per-pid totals across provider-duplicates of one slug.

    Fallback path for stores where ``project_mart`` hasn't been
    populated yet — mirrors PR #65's contract verbatim so the UI shape
    is stable regardless of which path produces the row.
    """
    parts = [lite_stats[pid] for pid in project_ids if pid in lite_stats]
    if not parts:
        return {
            "total_input_tokens": 0,
            "total_output_tokens": 0,
            "total_cache_read": 0,
            "total_cache_write": 0,
            "total_commands": 0,
            "avg_tokens_per_command": 0,
            "avg_steps_per_command": 0,
            "compact_summary_count": 0,
            "first_message_date": None,
            "last_message_date": None,
            "total_cost": 0.0,
        }
    starts = [p["first_message_date"] for p in parts if p["first_message_date"]]
    ends = [p["last_message_date"] for p in parts if p["last_message_date"]]
    return {
        "total_input_tokens": sum(p["total_input_tokens"] for p in parts),
        "total_output_tokens": sum(p["total_output_tokens"] for p in parts),
        "total_cache_read": sum(p["total_cache_read"] for p in parts),
        "total_cache_write": sum(p["total_cache_write"] for p in parts),
        "total_commands": sum(p["total_commands"] for p in parts),
        "avg_tokens_per_command": 0,
        "avg_steps_per_command": 0,
        "compact_summary_count": 0,
        "first_message_date": min(starts) if starts else None,
        "last_message_date": max(ends) if ends else None,
        "total_cost": sum(cost_by_pid.get(pid, 0.0) for pid in project_ids),
    }


def _merge_stats_for_ui(conn, project_ids: list[int]) -> dict:
    """Sum / max / min ProjectStats across provider-duplicates of one slug.

    Kept for callers that still need full per-project aggregator output
    (none currently — the list endpoint moved to ``_bulk_lite_merge``).
    """
    parts = [_project_stats_for_ui(conn, pid) for pid in project_ids]
    if len(parts) == 1:
        return parts[0]
    total_commands = sum(p["total_commands"] for p in parts)
    starts = [p["first_message_date"] for p in parts if p["first_message_date"]]
    ends = [p["last_message_date"] for p in parts if p["last_message_date"]]
    return {
        "total_input_tokens": sum(p["total_input_tokens"] for p in parts),
        "total_output_tokens": sum(p["total_output_tokens"] for p in parts),
        "total_cache_read": sum(p["total_cache_read"] for p in parts),
        "total_cache_write": sum(p["total_cache_write"] for p in parts),
        "total_commands": total_commands,
        "avg_tokens_per_command": (
            sum(p["total_commands"] * p["avg_tokens_per_command"] for p in parts) / total_commands
            if total_commands
            else 0
        ),
        "avg_steps_per_command": (
            sum(p["total_commands"] * p["avg_steps_per_command"] for p in parts) / total_commands
            if total_commands
            else 0
        ),
        "compact_summary_count": sum(p["compact_summary_count"] for p in parts),
        "first_message_date": min(starts) if starts else None,
        "last_message_date": max(ends) if ends else None,
        "total_cost": sum(p["total_cost"] for p in parts),
    }


def _project_stats_for_ui(conn, project_id: int) -> dict:
    """Flatten aggregator output into the ProjectStats shape the UI expects."""
    _, stats = queries.get_project_stats(conn, project_id=project_id)
    if not stats:
        return {
            "total_input_tokens": 0,
            "total_output_tokens": 0,
            "total_cache_read": 0,
            "total_cache_write": 0,
            "total_commands": 0,
            "avg_tokens_per_command": 0,
            "avg_steps_per_command": 0,
            "compact_summary_count": 0,
            "first_message_date": None,
            "last_message_date": None,
            "total_cost": 0.0,
        }
    overview = stats.get("overview") or {}
    tokens = overview.get("total_tokens") or {}
    ui = stats.get("user_interactions") or {}
    kinds = overview.get("message_types") or {}
    date_range = overview.get("date_range") or {}
    return {
        "total_input_tokens": int(tokens.get("input", 0)),
        "total_output_tokens": int(tokens.get("output", 0)),
        "total_cache_read": int(tokens.get("cache_read", 0)),
        "total_cache_write": int(tokens.get("cache_creation", 0)),
        "total_commands": int(ui.get("user_commands_analyzed", 0)),
        "avg_tokens_per_command": ui.get("avg_tokens_per_command", 0),
        "avg_steps_per_command": ui.get("avg_steps_per_command", 0),
        "compact_summary_count": int(kinds.get("compact_summary", 0)) + int(kinds.get("summary", 0)),
        "first_message_date": date_range.get("start"),
        "last_message_date": date_range.get("end"),
        "total_cost": float(overview.get("total_cost", 0.0)),
    }



@router.get("/api/providers")
async def get_providers():
    """List every provider currently active in the store.

    Powers the dashboard's `FilterBar` chip row. Returns one entry per
    distinct ``projects.provider`` value with project + session counts so
    the UI can render counts inline (the user wants to know "how much
    Cursor data am I about to scope to?" before they click).

    Cheap query — single GROUP BY over the projects table plus a join
    onto sessions for the count column. Empty stores return an empty
    array, never a 500.
    """
    try:
        conn = db.connect(deps.store_path)
        try:
            rows = conn.execute(
                "SELECT projects.provider AS provider, "
                "       COUNT(DISTINCT projects.id) AS project_count, "
                "       COUNT(DISTINCT sessions.id) AS session_count "
                "FROM projects "
                "LEFT JOIN sessions ON sessions.project_id = projects.id "
                "GROUP BY projects.provider "
                "ORDER BY project_count DESC"
            ).fetchall()
        finally:
            conn.close()
        providers = [
            {
                "provider": (r["provider"] or "unknown").lower(),
                "project_count": int(r["project_count"] or 0),
                "session_count": int(r["session_count"] or 0),
            }
            for r in rows
        ]
        return JSONResponse({"providers": providers})
    except Exception as e:
        return JSONResponse(
            {"providers": [], "error": f"Failed to list providers: {str(e)}"},
            status_code=500,
        )


@router.get("/api/global-stats")
async def get_global_stats():
    """Aggregated statistics across all projects, backed by the session store."""
    try:
        conn = db.connect(deps.store_path)
        try:
            stats = queries.get_global_stats(conn)
        finally:
            conn.close()
        stats["config"] = {"max_date_range_days": deps.config.get("max_date_range_days")}
        return JSONResponse(stats)
    except Exception as e:
        return JSONResponse(
            {"error": f"Failed to get global stats: {str(e)}"},
            status_code=500,
        )
