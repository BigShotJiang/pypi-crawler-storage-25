"""Dedicated to validation."""
