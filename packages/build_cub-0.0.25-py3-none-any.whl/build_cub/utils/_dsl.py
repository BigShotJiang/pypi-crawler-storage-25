"""The MVP for a safe and limited DSL to configure Bear Build."""

from __future__ import annotations

import ast
from contextlib import suppress
from pathlib import Path  # noqa: TC003
from types import SimpleNamespace as Namespace
from typing import TYPE_CHECKING, Any, Final, Literal, overload

from build_cub.validation._models import ValidationResult

if TYPE_CHECKING:
    from collections.abc import Sequence

type ASTMode = Literal["eval", "exec"]
type ValidationType = Literal["condition", "action", "validation"]
EVAL: Final[str] = "eval"
EXEC: Final[str] = "exec"
BUILTINS: Final[str] = "__builtins__"

SAFE_BUILTINS: Final[dict[str, Any]] = {
    "len": len,
    "str": str,
    "int": int,
    "bool": bool,
    "float": float,
    "tuple": tuple,
    "list": list,
    "dict": dict,
    "set": set,
    "all": all,
    "any": any,
    "isinstance": isinstance,
    "type": type,
    "True": True,
    "False": False,
    "None": None,
}

# fmt: off
CONDITIONAL_NODES: Final[set[type]] = {
    ast.Expression, ast.Module, ast.In,
    ast.BoolOp, ast.And, ast.Or, ast.Compare, ast.Expr, ast.Load,
    ast.Eq, ast.NotEq, ast.Lt, ast.LtE, ast.Gt, ast.GtE,
    ast.Name, ast.Constant, ast.List, ast.Tuple,
    ast.Subscript, ast.Attribute, ast.Dict,
}
# fmt: on

ACTION_NODES: Final[set[type]] = {*CONDITIONAL_NODES, ast.Call}

VALIDATION_NODES: Final[set[type]] = {*ACTION_NODES, ast.Assign, ast.Store}

VALIDATION_MAP: dict[ValidationType, set[type]] = {
    "condition": CONDITIONAL_NODES,
    "action": ACTION_NODES,
    "validation": VALIDATION_NODES,
}


def get_nodes(node_type: ValidationType | None) -> set[type]:
    if node_type is None:
        return CONDITIONAL_NODES
    return VALIDATION_MAP.get(node_type, CONDITIONAL_NODES)


def build_namespace(obj: object, keys: Sequence[str]) -> Namespace:
    from operator import attrgetter

    namespace: Namespace = Namespace()
    for key in keys:
        with suppress(AttributeError):
            value = attrgetter(key)(obj)
            parts: list[str] = key.split(".")
            current = namespace.__dict__
            for part in parts[:-1]:
                if part not in current:
                    current[part] = Namespace()
                current = current[part].__dict__
            current[parts[-1]] = value
    return namespace


def extract_assignments(tree: ast.Module) -> dict[str, object]:
    namespace = {}
    for node in tree.body:
        if not isinstance(node, ast.Assign):
            continue
        for target in node.targets:
            if not isinstance(target, ast.Name):
                continue
            with suppress(ValueError, TypeError):
                namespace[target.id] = ast.literal_eval(node.value)
    return namespace


class DSLParser:
    def __init__(
        self,
        builtins: dict[str, Any] | None = None,
        namespace: dict[str, Any] | None = None,
        validation: ValidationType | None = None,
    ) -> None:
        """Create the DSL parser with optional custom builtins."""
        self.builtins: dict[str, Any] = builtins or SAFE_BUILTINS
        self.namespace: dict[str, Any] = namespace or {}
        self.validation: set[type] = get_nodes(validation)

    def set_namespace(self, namespace: dict[str, Any] | ast.Module) -> None:
        """Set the evaluation namespace."""
        if isinstance(namespace, ast.AST):
            namespace = extract_assignments(namespace)
        self.namespace = namespace

    def set_mode(self, validation: ValidationType) -> None:
        self.validation = get_nodes(validation)

    @overload
    def parse(self, expression: str, mode: Literal["eval"], validation: ValidationType) -> ast.Expression: ...
    @overload
    def parse(self, expression: str, mode: Literal["exec"], validation: ValidationType) -> ast.Module: ...

    def parse(self, expression: str, mode: ASTMode, validation: ValidationType) -> ast.AST:
        def _validate(tree: ast.AST) -> ast.AST:
            nodes: set[type] = VALIDATION_MAP.get(validation, CONDITIONAL_NODES)
            for node in ast.walk(tree):
                if type(node) not in nodes:
                    raise ValueError(f"Forbidden: {type(node).__name__}")
                if isinstance(node, ast.Attribute) and node.attr.startswith("_"):
                    raise ValueError(f"Access to private attribute '{node.attr}' is not allowed.")
            return tree

        try:
            match mode:
                case "eval":
                    tree = ast.parse(expression, mode=EVAL)
                case "exec":
                    tree = ast.parse(expression, mode=EXEC)
                case _:
                    tree = ast.parse(expression)
            return _validate(tree)
        except SyntaxError as e:
            raise SyntaxError(f"Syntax error in expression: {expression}") from e
        except ValueError as e:
            raise ValueError(f"Invalid expression: {expression}") from e

    def eval_true(self, expr: str) -> bool:
        tree: ast.Expression = self.parse(expr, EVAL, "condition")  # ty:ignore
        return bool(eval(compile(tree, "<condition>", EVAL), {BUILTINS: self.builtins}, self.namespace))

    def eval_validation(self, expr: str) -> bool:
        """Evaluate a validation expression (allows function calls like len(), isinstance())."""
        tree: ast.Expression = self.parse(expr, EVAL, "validation")  # ty:ignore
        return bool(eval(compile(tree, "<validation>", EVAL), {BUILTINS: self.builtins}, self.namespace))

    def exec_action(self, expr: str) -> None:
        tree: ast.Module = self.parse(expr, EXEC, "action")  # ty: ignore
        exec(compile(tree, "<action>", EXEC), {BUILTINS: self.builtins}, self.namespace)


def syntax_error_result(e: SyntaxError, path: Path) -> ValidationResult:
    """Create ValidationResult from a SyntaxError."""
    return ValidationResult.with_path(
        path=path,
        success=False,
        msg="Python syntax error in generated file",
        details=[
            f"Line {e.lineno}: {e.msg}",
            f"Text: {e.text.strip() if e.text else 'N/A'}",
            "Hint: This usually means a template variable didn't render correctly",
        ],
        exception=e,
    )


# ruff: noqa: S307, S102
