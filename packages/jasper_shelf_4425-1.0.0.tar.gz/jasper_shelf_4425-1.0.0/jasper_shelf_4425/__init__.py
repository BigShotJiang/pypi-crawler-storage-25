"""Moss Step for Log"""
__version__ = "1.0.0"
