# -*- coding: utf-8 -*-
"""
Module for matrix operations.
"""

##### IMPORTS #####
# Standard imports
from pathlib import Path
from typing import Optional, Any, Literal
import math

# Third party imports
import polars as pl  # type: ignore
import numpy as np
import numba as nb #  type: ignore
from dbfread import DBF  # type: ignore

# Local imports
from sysame import omx

##### CONSTANTS #####

##### CLASSES #####


##### FUNCTIONS #####
def read_dbf_to_polars(
    dbf_file_path: Path,
    columns: Optional[list[str]] = None,
) -> pl.DataFrame:
    """Read DBF file into a Polars DataFrame.

    Parameters
    ----------
    dbf_file_path : Path
        Path to the DBF file
    columns : Optional[list[str]], optional
        List of column names to extract. If None, all columns are extracted.

    Returns
    -------
    pl.DataFrame
        DataFrame containing the DBF data
    """
    # Load DBF file data
    dbf_table = DBF(dbf_file_path)

    if columns is None:
        # Extract all columns
        dbf_df = pl.DataFrame(list(dbf_table))
    else:
        # Extract only specified columns
        # First, get field names from the DBF table to validate columns exist
        available_fields = {field for field in dbf_table.field_names}

        # Validate that requested columns exist
        missing_cols = set(columns) - available_fields
        if missing_cols:
            raise ValueError(f"Column(s) not found in DBF file: {missing_cols}")

        # Extract only the specified columns efficiently
        selected_data = []
        for record in dbf_table:
            row_data = {col: record[col] for col in columns}
            selected_data.append(row_data)

        dbf_df = pl.DataFrame(selected_data)

    return dbf_df


def write_polars_to_dbf(
    df: pl.DataFrame,
    dbf_file_path: Path,
) -> None:
    """Write a Polars DataFrame to a DBF file.

    Parameters
    ----------
    df : pl.DataFrame
        DataFrame to write to the DBF file
    dbf_file_path : Path
        Path to the output DBF file. Will be created or overwritten.

    Returns
    -------
    None
    """
    import struct
    import datetime

    _INT_DTYPES = (pl.Int8, pl.Int16, pl.Int32, pl.Int64, pl.UInt8, pl.UInt16, pl.UInt32, pl.UInt64)
    _FLOAT_DTYPES = (pl.Float32, pl.Float64)

    # Map Polars dtypes to DBF field specs: (name, type, length, decimal_count)
    field_specs: list[tuple[str, str, int, int]] = []
    for col_name, dtype in zip(df.columns, df.dtypes):
        name = col_name[:10].upper()  # DBF field names are at most 10 chars
        if isinstance(dtype, _INT_DTYPES):
            field_specs.append((name, "N", 18, 0))
        elif isinstance(dtype, _FLOAT_DTYPES):
            field_specs.append((name, "N", 20, 6))
        elif dtype == pl.Boolean:
            field_specs.append((name, "L", 1, 0))
        elif dtype == pl.Date:
            field_specs.append((name, "D", 8, 0))
        else:
            # String or other type — compute max byte length across all values
            if df.height > 0:
                max_len = int(
                    df[col_name].cast(pl.String).str.len_bytes().max() or 1
                )
            else:
                max_len = 1
            max_len = max(1, min(max_len, 254))
            field_specs.append((name, "C", max_len, 0))

    num_records = df.height
    header_size = 32 + 32 * len(field_specs) + 1  # +1 for 0x0D terminator byte
    record_size = 1 + sum(length for _, _, length, _ in field_specs)  # +1 deletion flag

    # File header — 32 bytes
    today = datetime.date.today()
    file_header = struct.pack(
        "<BBBBIHH20x",
        0x03,              # dBase III without memo
        today.year % 100,  # last-update year (2-digit)
        today.month,
        today.day,
        num_records,
        header_size,
        record_size,
    )

    # Field descriptors — 32 bytes each
    field_descs = bytearray()
    for name, ftype, length, decimal in field_specs:
        name_bytes = name.encode("ascii").ljust(11, b"\x00")
        field_descs.extend(
            struct.pack("<11sc4xBB14x", name_bytes, ftype.encode("ascii"), length, decimal)
        )

    dbf_file_path = Path(dbf_file_path)
    with dbf_file_path.open("wb") as f:
        f.write(file_header)
        f.write(bytes(field_descs))
        f.write(b"\x0d")  # header terminator

        for row in df.iter_rows():
            f.write(b"\x20")  # deletion flag — record is active
            for (_, ftype, length, decimal), value in zip(field_specs, row):
                if ftype == "N":
                    if value is None:
                        f.write(b" " * length)
                    elif decimal == 0:
                        f.write(f"{int(value):>{length}d}".encode("ascii"))
                    else:
                        f.write(f"{float(value):>{length}.{decimal}f}".encode("ascii"))
                elif ftype == "C":
                    if value is None:
                        f.write(b" " * length)
                    else:
                        val_bytes = str(value).encode("ascii", errors="replace")
                        f.write(val_bytes[:length].ljust(length, b" "))
                elif ftype == "L":
                    f.write(b"?" if value is None else (b"T" if value else b"F"))
                elif ftype == "D":
                    if isinstance(value, datetime.date):
                        f.write(value.strftime("%Y%m%d").encode("ascii"))
                    else:
                        f.write(b" " * 8)

        f.write(b"\x1a")  # EOF marker


@nb.jit(nopython=True, cache=True, parallel=False, fastmath=True)
def _furness_numba_double(
    matrix: np.ndarray,
    productions: np.ndarray,
    attractions: np.ndarray,
    max_iterations: int,
    tolerance: float,
) -> tuple[np.ndarray, list[str]]:
    """Numba-accelerated core for double constraint"""
    n_rows, n_cols = matrix.shape
    convergence_track = []

    for i in range(max_iterations):
        # Row adjustment with fused operations
        row_sum_acc = 0.0
        max_row_error = 0.0

        for r in range(n_rows):
            row_sum = 0.0
            # Compute row sum
            for c in range(n_cols):
                row_sum += matrix[r, c]

            # Apply factor and track error simultaneously
            if row_sum > 0:
                factor = productions[r] / row_sum
                row_sum_acc = 0.0
                for c in range(n_cols):
                    matrix[r, c] *= factor
                    row_sum_acc += matrix[r, c]
            else:
                row_sum_acc = row_sum

            # Track max error
            error = abs(row_sum_acc - productions[r])
            if error > max_row_error:
                max_row_error = error

        # Column adjustment with fused operations
        max_col_error = 0.0
        for c in range(n_cols):
            col_sum = 0.0
            # Compute column sum
            for r in range(n_rows):
                col_sum += matrix[r, c]

            # Apply factor and track error simultaneously
            if col_sum > 0:
                factor = attractions[c] / col_sum
                col_sum_acc = 0.0
                for r in range(n_rows):
                    matrix[r, c] *= factor
                    col_sum_acc += matrix[r, c]
            else:
                col_sum_acc = col_sum

            # Track max error
            error = abs(col_sum_acc - attractions[c])
            if error > max_col_error:
                max_col_error = error

        # Store convergence info
        convergence_track.append(
            f"Its: {i}, Row: {max_row_error:.6e}, Col: {max_col_error:.6e}"
        )

        if max_row_error < tolerance and max_col_error < tolerance:
            break

    return matrix, convergence_track


@nb.jit(nopython=True, cache=True, parallel=False, fastmath=True)
def _furness_numba_single_prod(
    matrix: np.ndarray, productions: np.ndarray, max_iterations: int, tolerance: float
) -> tuple[np.ndarray, list[str]]:
    """Numba-accelerated core for production-only constraint"""
    n_rows, n_cols = matrix.shape
    convergence_track = []

    for i in range(max_iterations):
        max_row_error = 0.0

        for r in range(n_rows):
            row_sum = 0.0
            # Compute row sum
            for c in range(n_cols):
                row_sum += matrix[r, c]

            # Apply factor and track error
            if row_sum > 0:
                factor = productions[r] / row_sum
                row_sum_acc = 0.0
                for c in range(n_cols):
                    matrix[r, c] *= factor
                    row_sum_acc += matrix[r, c]
            else:
                row_sum_acc = row_sum

            error = abs(row_sum_acc - productions[r])
            if error > max_row_error:
                max_row_error = error

        convergence_track.append(f"Its: {i}, Row: {max_row_error:.6e}")

        if max_row_error < tolerance:
            break

    return matrix, convergence_track


@nb.jit(nopython=True, cache=True, parallel=False, fastmath=True)
def _furness_numba_single_attr(
    matrix: np.ndarray, attractions: np.ndarray, max_iterations: int, tolerance: float
) -> tuple[np.ndarray, list[str]]:
    """Numba-accelerated core for attraction-only constraint"""
    n_rows, n_cols = matrix.shape
    convergence_track = []

    for i in range(max_iterations):
        max_col_error = 0.0

        for c in range(n_cols):
            col_sum = 0.0
            # Compute column sum
            for r in range(n_rows):
                col_sum += matrix[r, c]

            # Apply factor and track error
            if col_sum > 0:
                factor = attractions[c] / col_sum
                col_sum_acc = 0.0
                for r in range(n_rows):
                    matrix[r, c] *= factor
                    col_sum_acc += matrix[r, c]
            else:
                col_sum_acc = col_sum

            error = abs(col_sum_acc - attractions[c])
            if error > max_col_error:
                max_col_error = error

        convergence_track.append(f"Its: {i}, Col: {max_col_error:.6e}")

        if max_col_error < tolerance:
            break

    return matrix, convergence_track


# Fallback numpy implementation if numba not available
def _furness_numpy_double(
    matrix: np.ndarray,
    productions: np.ndarray,
    attractions: np.ndarray,
    max_iterations: int,
    tolerance: float,
) -> tuple[np.ndarray, list[str]]:
    """NumPy fallback for double constraint"""
    convergence_track = []

    for i in range(max_iterations):
        # Row adjustment
        row_sums = matrix.sum(axis=1, keepdims=True)
        row_mask = row_sums != 0
        row_factors = np.divide(
            productions[:, None], row_sums, where=row_mask, out=np.ones_like(row_sums)
        )
        np.multiply(matrix, row_factors, out=matrix)

        # Column adjustment
        col_sums = matrix.sum(axis=0, keepdims=True)
        col_mask = col_sums != 0
        col_factors = np.divide(
            attractions[None, :], col_sums, where=col_mask, out=np.ones_like(col_sums)
        )
        np.multiply(matrix, col_factors, out=matrix)

        # Check convergence (compute once, reuse)
        final_row_sums = matrix.sum(axis=1)
        final_col_sums = matrix.sum(axis=0)

        row_error = np.abs(final_row_sums - productions).max()
        col_error = np.abs(final_col_sums - attractions).max()

        convergence_track.append(
            f"Its: {i}, Row: {row_error:.6e}, Col: {col_error:.6e}"
        )

        if row_error < tolerance and col_error < tolerance:
            break

    return matrix, convergence_track


def _furness_numpy_single_prod(
    matrix: np.ndarray, productions: np.ndarray, max_iterations: int, tolerance: float
) -> tuple[np.ndarray, list[str]]:
    """NumPy fallback for production-only constraint"""
    convergence_track = []

    for i in range(max_iterations):
        # Row adjustment
        row_sums = matrix.sum(axis=1, keepdims=True)
        row_mask = row_sums != 0
        row_factors = np.divide(
            productions[:, None], row_sums, where=row_mask, out=np.ones_like(row_sums)
        )
        np.multiply(matrix, row_factors, out=matrix)

        # Check convergence
        final_row_sums = matrix.sum(axis=1)
        row_error = np.abs(final_row_sums - productions).max()

        convergence_track.append(f"Its: {i}, Row: {row_error:.6e}")

        if row_error < tolerance:
            break

    return matrix, convergence_track


def _furness_numpy_single_attr(
    matrix: np.ndarray, attractions: np.ndarray, max_iterations: int, tolerance: float
) -> tuple[np.ndarray, list[str]]:
    """NumPy fallback for attraction-only constraint"""
    convergence_track = []

    for i in range(max_iterations):
        # Column adjustment
        col_sums = matrix.sum(axis=0, keepdims=True)
        col_mask = col_sums != 0
        col_factors = np.divide(
            attractions[None, :], col_sums, where=col_mask, out=np.ones_like(col_sums)
        )
        np.multiply(matrix, col_factors, out=matrix)

        # Check convergence
        final_col_sums = matrix.sum(axis=0)
        col_error = np.abs(final_col_sums - attractions).max()

        convergence_track.append(f"Its: {i}, Col: {col_error:.6e}")

        if col_error < tolerance:
            break

    return matrix, convergence_track


def furness(
    matrix: np.ndarray,
    productions: Optional[np.ndarray] = None,
    attractions: Optional[np.ndarray] = None,
    constraint: Literal["both", "production", "attraction"] = "both",
    max_iterations: int = 1_000,
    tolerance: float = 1e-15,
    use_numba: bool = True,
    dtype: np.dtype = np.float64,
) -> tuple[np.ndarray, list[str]]:
    """
    Furness method for matrix adjustment.

    Options for double constraint (both productions and attractions),
    or single constraint (production or attraction only).

    Parameters
    ----------
    matrix : np.ndarray
        The input matrix to be adjusted.
    productions : np.ndarray, optional
        The production values for each row.
    attractions : np.ndarray, optional
        The attraction values for each column.
    constraint : {'both', 'production', 'attraction'}, optional
        Type of constraint to apply.
    max_iterations : int, optional
        Maximum iterations (default 1,000).
    tolerance : float, optional
        Convergence tolerance (default 1e-15).
    use_numba : bool, optional
        Use Numba JIT compilation if available (default True).
    dtype : np.dtype, optional
        Data type for computations (default np.float64).

    Returns
    -------
    matrix: np.ndarray
        The adjusted matrix.
    convergence_track: list[str]
        Track of convergence stats per iteration.
    """
    # Ultra-fast input validation and conversion
    matrix = np.ascontiguousarray(matrix, dtype=dtype)

    if constraint == "both":
        if productions is None or attractions is None:
            raise ValueError(
                "Both productions and attractions required for 'both' constraint"
            )
        productions = np.ascontiguousarray(productions, dtype=dtype)
        attractions = np.ascontiguousarray(attractions, dtype=dtype)

        # Try Numba first if requested
        if use_numba:
            try:
                return _furness_numba_double(
                    matrix, productions, attractions, max_iterations, tolerance
                )
            except:
                # Fall back to NumPy
                pass

        return _furness_numpy_double(
            matrix, productions, attractions, max_iterations, tolerance
        )

    elif constraint == "production":
        if productions is None:
            raise ValueError("Productions required for 'production' constraint")
        productions = np.ascontiguousarray(productions, dtype=dtype)

        if use_numba:
            try:
                return _furness_numba_single_prod(
                    matrix, productions, max_iterations, tolerance
                )
            except:
                pass

        return _furness_numpy_single_prod(
            matrix, productions, max_iterations, tolerance
        )

    else:  # attraction
        if attractions is None:
            raise ValueError("Attractions required for 'attraction' constraint")
        attractions = np.ascontiguousarray(attractions, dtype=dtype)

        if use_numba:
            try:
                return _furness_numba_single_attr(
                    matrix, attractions, max_iterations, tolerance
                )
            except:
                pass

        return _furness_numpy_single_attr(
            matrix, attractions, max_iterations, tolerance
        )


def expand_matrix(
    mx_df: pl.DataFrame,
    zones_no: int,
) -> pl.DataFrame:
    """Expand matrix to all possible movements (zones x zones).

    Parameters
    ----------
    mx_df : pl.DataFrame
        matrix
    zones_no: int
        number of model zones

    Returns
    -------
    expanded_mx : pl.DataFrame
        expanded matrix

    Examples
    --------
    >>> import polars as pl
    >>> import itertools
    >>> mx_df = pl.DataFrame({"origin": [1, 2], "destination": [3, 4], "value": [5, 6]})
    >>> expanded_mx.shape
    shape: (2, 3)
    >>> zones_no = 5
    >>> expanded_mx = expand_matrix(mx_df, zones_no)
    >>> expanded_mx.shape
    shape: (25, 3)
    """
    o_col, d_col = mx_df.columns[0], mx_df.columns[1]

    # Normalise dtypes and drop null keys once.
    mx_df = mx_df.with_columns(
        [
            pl.col(o_col).cast(pl.Int32),
            pl.col(d_col).cast(pl.Int32),
        ]
    ).filter(pl.col(o_col).is_not_null() & pl.col(d_col).is_not_null())

    # Generate full origin-destination grid.
    zones = pl.DataFrame(
        {"_zone": pl.arange(1, zones_no + 1, eager=True, dtype=pl.Int32)}
    )
    expanded_mx = (
        zones.rename({"_zone": o_col})
        .join(zones.rename({"_zone": d_col}), how="cross")
        .join(mx_df, on=[o_col, d_col], how="left")
        .fill_null(strategy="zero")
        .sort([o_col, d_col])
    )

    return expanded_mx


def long_mx_2_wide_mx(
    mx_df: pl.DataFrame,
    zones_no: int,
) -> np.ndarray[Any, Any]:
    """Convert polars long matrix to numpy wide matrix.

    Assumes that the long matrix is in the format of [origin, destination, value].

    Parameters
    ----------
    mx_df : pl.DataFrame
        polars long matrix dataframe to convert
    zones_no: int
        number of model zones

    Returns
    -------
    np_mx : np.ndarray
        numpy wide matrix

    Examples
    --------
    >>> import polars as pl
    >>> import itertools
    >>> mx_df = pl.DataFrame({"origin": [1, 2], "destination": [3, 4], "value": [5, 6]})
    >>> zones_no = 5
    >>> np_mx = long_mx_2_wide_mx(mx_df, zones_no)
    >>> np_mx.shape
    (5, 5)
    """
    # Extract column names (assumes 1st: origins, 2nd: destinations, 3rd: values)
    o_col, d_col, v_col = mx_df.columns[0], mx_df.columns[1], mx_df.columns[2]

    # Select relevant columns and remove rows with null origin/destination values
    mx_df = mx_df.select([o_col, d_col, v_col]).drop_nulls([o_col, d_col])
    # Convert to numpy arrays and convert to 0-based indexing
    origins = mx_df[o_col].cast(pl.Int32).to_numpy() - 1
    destinations = mx_df[d_col].cast(pl.Int32).to_numpy() - 1
    values = mx_df[v_col].to_numpy()

    # Create empty matrix with same dtype as values
    np_mx = np.zeros((zones_no, zones_no), dtype=values.dtype)
    # Populate matrix using advanced indexing
    np.add.at(np_mx, (origins, destinations), values)

    return np_mx


def wide_mx_2_long_mx(
    mx_array: np.ndarray,
    o_col: str = "o",
    d_col: str = "d",
    v_col: str = "v",
) -> pl.DataFrame:
    """Convert numpy wide matrix to polars long matrix.

    Parameters
    ----------
    mx_array : np.array
        wide numpy matrix array
    o_col : str, optional
        name of origin/production column, by default "o"
    d_col : str, optional
        name of destination/attraction column, by default "d"
    v_col : str, optional
        name of values column, by default "v"

    Returns
    -------
    mx_df : pl.DataFrame
        polars long matrix

    Examples
    --------
    >>> import numpy as np
    >>> mx_array = np.array([[1, 2, 3], [4, 5, 6], [7, 8, 9]])
    >>> mx_df = wide_mx_2_long_mx(mx_array)
    >>> mx_df.shape
    shape: (3, 3)
    """
    num_rows, num_cols = mx_array.shape

    # Flatten matrix to 1D array of all values
    values = mx_array.ravel()
    # Create row indices
    rows = np.repeat(np.arange(num_rows, dtype=np.int32), num_cols)
    # Create column indices
    cols = np.tile(np.arange(num_cols, dtype=np.int32), num_rows)
    # Convert to 1-based indexing for zones/spatial modeling convention
    rows += 1
    cols += 1

    # Create polars DataFrame with origin, destination, and values columns
    mx_df = pl.DataFrame({o_col: rows, d_col: cols, v_col: values})

    return mx_df


def read_omx_to_polars(
    omx_file_path: Path,
    o_col: str = "o",
    d_col: str = "d",
    limited_tabs: Optional[list[str]] = None,
    stack: bool = False,
    clean_omx: bool = False,
    data_group: str = "data",
    lookup_group: str = "lookup",
) -> pl.DataFrame:
    """Read OMX file to polars dataframe.

    Parameters
    ----------
    omx_file_path : Path
        full path to the .OMX file
    o_col : str, optional
        name of origin/production vector header, by default "o"
    d_col : str, optional
        name of destination/attraction vector header, by default "d"
    limited_tabs : list[str], optional
        if only specific tabs are needed from the omx
    stack : bool, optional
        if stack then the matrices will be stacked in one vector with
        an additional vector referring to each mx tab
    clean_omx : bool, optional
        whether or not to remove the omx after being read
    data_group : str, optional
        name of the HDF5 group that holds matrix CArrays, by default "data"
    lookup_group : str, optional
        name of the HDF5 group that holds mapping arrays, by default "lookup"

    Returns
    -------
    matrix_df : pl.DataFrame
        matrix as polars dataframe
    """
    # Create an empty list if limited_tabs is None
    tab_list: list[str] = [] if limited_tabs is None else limited_tabs

    matrix_df = pl.DataFrame()
    # open omx
    with omx.open_file(omx_file_path, data_group=data_group, lookup_group=lookup_group) as omx_mat:
        # get matrices
        omx_tabs = omx_mat.list_matrices()
        if len(tab_list) == 0:
            for i, mat_lvl in enumerate(omx_tabs):
                # get matrix level into a polars df
                mx_lvl_df = wide_mx_2_long_mx(
                    np.array(omx_mat[mat_lvl]),
                    o_col,
                    d_col,
                    mat_lvl,
                )
                if stack:
                    mx_lvl_df = mx_lvl_df.with_columns(pl.lit(mat_lvl).alias("mx"))
                    mx_lvl_df = mx_lvl_df.rename({mat_lvl: "value"})
                    mx_lvl_df = mx_lvl_df.select([o_col, d_col, "mx", "value"])
                    matrix_df = pl.concat([matrix_df, mx_lvl_df])
                else:
                    if i == 0:
                        matrix_df = pl.concat([matrix_df, mx_lvl_df])
                    else:
                        matrix_df = matrix_df.join(
                            mx_lvl_df, on=[o_col, d_col], how="full"
                        )
                        matrix_df = matrix_df.drop(f"{o_col}_right", f"{d_col}_right")
        else:
            counter = 0
            for i, mat_lvl in enumerate(omx_mat.list_matrices()):
                if mat_lvl in tab_list:
                    # get matrix level into a polars df
                    mx_lvl_df = wide_mx_2_long_mx(
                        np.array(omx_mat[mat_lvl]),
                        o_col,
                        d_col,
                        mat_lvl,
                    )
                    if stack:
                        mx_lvl_df = mx_lvl_df.with_columns(pl.lit(mat_lvl).alias("mx"))
                        mx_lvl_df = mx_lvl_df.rename({mat_lvl: "value"})
                        mx_lvl_df = mx_lvl_df.select([o_col, d_col, "mx", "value"])
                        matrix_df = pl.concat([matrix_df, mx_lvl_df])
                    else:
                        if counter == 0:
                            matrix_df = pl.concat([matrix_df, mx_lvl_df])
                        else:
                            matrix_df = matrix_df.join(
                                mx_lvl_df, on=[o_col, d_col], how="full"
                            )
                            matrix_df = matrix_df.drop(
                                f"{o_col}_right", f"{d_col}_right"
                            )
                counter = counter + 1
    # if removing the omx is needed
    if clean_omx:
        omx_file_path.unlink()

    return matrix_df


def read_omx_to_numpy(
    omx_file_path: Path,
    limited_tabs: Optional[list[str]] = None,
    data_group: str = "data",
    lookup_group: str = "lookup",
) -> dict[str, np.ndarray]:
    """Read OMX file to numpy arrays.

    Parameters
    ----------
    omx_file_path : Path
        full path to the .OMX file
    limited_tabs : list[str], optional
        if only specific tabs are needed from the omx
    data_group : str, optional
        name of the HDF5 group that holds matrix CArrays, by default "data"
    lookup_group : str, optional
        name of the HDF5 group that holds mapping arrays, by default "lookup"

    Returns
    -------
    matrix_arrays : dict[str, np.ndarray]
        dictionary of numpy arrays with tab names as keys
    """
    # Create an empty list if limited_tabs is None
    tab_list: list[str] = [] if limited_tabs is None else limited_tabs
    # mx_arrays dictionary
    matrix_arrays: dict[str, np.ndarray] = {}

    # open omx
    with omx.open_file(omx_file_path, data_group=data_group, lookup_group=lookup_group) as omx_mat:
        # get matrices
        omx_tabs = omx_mat.list_matrices()
        if len(tab_list) == 0:
            tab_list = omx_tabs

        for i, mat_lvl in enumerate(tab_list):
            # get matrix level into a polars df
            matrix_arrays[mat_lvl] = np.array(omx_mat[mat_lvl])

    return matrix_arrays


def split_dataframe_into_chunks(
    pl_df: pl.DataFrame,
    chunk_size: int,
) -> list[pl.DataFrame]:
    """Function splits a dataframe to equal size dataframes.

    Parameters
    ----------
    df : pl.DataFrame
        given dataframe to split
    chunk_size : int
        size of each chunk

    Returns
    -------
    chunks : list[pl.DataFrame]
        list of chunk dataframes
    """
    if chunk_size <= 0:
        raise ValueError("chunk_size must be a positive integer")
    # round up to avoid floats
    chunk_size = math.ceil(chunk_size)
    # split dataframe to equal sizes (= chunk_size)
    chunks = [
        pl_df[i : i + round(chunk_size)]
        for i in range(0, pl_df.shape[0], round(chunk_size))
    ]

    return chunks
