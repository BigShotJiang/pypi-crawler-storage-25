# -*- coding: utf-8 -*-
"""
Module for Cube processes.
"""

##### IMPORTS #####
# Standard imports
import re
import ast
import shutil
import subprocess
import tempfile
import contextlib
from warnings import warn
from copy import deepcopy
from pathlib import Path
from collections import Counter
from typing import Optional, Any, Union, Callable, Iterable, Sequence, Union

# Third party imports
import numpy as np
import pandas as pd  # type: ignore
import polars as pl

# Local imports
from sysame import omx
from sysame.matrix import mx

##### CONSTANTS #####


##### CLASSES #####
ProgramMap = Sequence[tuple[int, int]]
ProgramList = Sequence[int]

class Node:
    """
    Simple node class for representing network nodes.

    Parameters
    ----------
    string : str or int
        String representation of the node.
    **kwargs : dict
        Additional attributes to be assigned to the node.

    Attributes
    ----------
    id : int
        Node identifier, absolute value from string.
    stopping : bool
        Whether the node is a stopping point.
    _string : str
        Internal storage of the original string representation.
    """

    def __init__(self, string: Union[str, int], **kwargs: Any) -> None:
        self._string = str(string)
        self.id = abs(int(self._string.strip()))
        self.__dict__.update(**kwargs)

        if self._string.strip().startswith("-"):
            self.stopping = False
        else:
            self.stopping = True

    @property
    def attrs(self) -> dict[str, Any]:
        """
        Returns a dictionary with user-defined attributes.

        Returns
        -------
        Dict[str, Any]
            Dictionary of custom attributes excluding internal ones.
        """
        return {
            k: v
            for k, v in self.__dict__.items()
            if not k.startswith("_") and "id" != k and "ID" != k and "stopping" != k
        }

    def __repr__(self) -> str:
        """
        Object's summary representation.

        Returns
        -------
        str
            String representation of the node.
        """
        return f"{'-' if not self.stopping else ''}{self.id}, {self.attrs}"

    def __str__(
        self,
        node_attrs: Optional[list[str]] = None,
        exclude_node_attrs: Optional[list[str]] = None,
    ) -> str:
        """
        String representation of the node.

        Parameters
        ----------
        node_attrs : list of str, optional
            List of node attributes to include.
        exclude_node_attrs : list of str, optional
            List of node attributes to omit.

        Returns
        -------
        str
            String representation of the node with selected attributes.
        """
        txt_node = f"{'-' if not self.stopping else ''}{self.id}"

        if self.attrs:
            if node_attrs:
                attrs = {k: v for k, v in self.attrs.items() if k in node_attrs}
            else:
                attrs = self.attrs

            if exclude_node_attrs:
                attrs = {k: v for k, v in attrs.items() if k not in exclude_node_attrs}

            formatted_attrs = [f"{k}={v}" for k, v in attrs.items()]

            txt_attrs = ", ".join(formatted_attrs)

            if txt_attrs:
                txt_node = ", ".join([txt_node, txt_attrs])

        return txt_node

    def copy(self) -> "Node":
        """
        Create a deep copy of the node.

        Returns
        -------
        Node
            A new instance that is a deep copy of this node.
        """
        return deepcopy(self)


class Line:
    """
    Simple line class representing a sequence of nodes.

    A line is a sequence of nodes with its own properties.

    Parameters
    ----------
    nodes : list of Node
        List of node objects that form the line.
    **kwargs : dict
        Additional attributes to be assigned to the line.

    Attributes
    ----------
    nodes : list of Node
        List of nodes that form the line.
    name : str
        Name of the line (set via kwargs).
    unquoted : list of str
        Class variable that defines values that should not be quoted.
    NodeLabel : str
        Label to identify nodes in string representation.
    """

    # Class variables
    unquoted = ["T", "F"]
    NodeLabel = "N"  # Or 'NODE'

    def __init__(self, nodes: list[Node], **kwargs: Any) -> None:
        """
        Initialise a line object.

        Parameters
        ----------
        nodes : list[Node]
            List of node objects that form the line.
        **kwargs : dict
            Additional attributes to be assigned to the line.
        """
        self.nodes = nodes  # a list of node objects
        self.name = kwargs.get("NAME", "")  # Use NAME if present, empty string if not

        # Remove NAME from kwargs to avoid duplication
        if "NAME" in kwargs:
            del kwargs["NAME"]

        self.__dict__.update(**kwargs)

    @property
    def attrs(self) -> dict[str, Any]:
        """
        Returns a dictionary with user-defined attributes.

        Returns
        -------
        Dict[str, Any]
            Dictionary of line attributes excluding nodes and internal ones.
        """
        return {
            k: v
            for k, v in self.__dict__.items()
            if "nodes" != k and "name" != k and not k.startswith("_")
        }

    @property
    def stops(self) -> list[Node]:
        """
        Returns a list of the nodes that are actual stops.

        Returns
        -------
        list[Node]
            List of nodes marked as stopping points.
        """
        return [node for node in self.nodes if node.stopping]

    def __repr__(self) -> str:
        """
        Object's summary representation.

        Returns
        -------
        str
            String summary of the line including node count and attributes.
        """
        txt = (
            f"Line with {len(self.nodes)} nodes (of which {len(self.stops)} are stops)."
        )
        txt += f"\n{self.attrs}"
        return txt

    def __str__(
        self,
        line_attrs: Optional[list[str]] = None,
        exclude_line_attrs: Optional[list[str]] = None,
        node_attrs: Optional[list[str]] = None,
        exclude_node_attrs: Optional[list[str]] = None,
        max_line_length: Optional[int] = None,
    ) -> str:
        """
        String representation of the line.

        Parameters
        ----------
        line_attrs : list of str, optional
            List of line attributes to include.
        exclude_line_attrs : list of str, optional
            List of line attributes to omit.
        node_attrs : list of str, optional
            List of node attributes to include.
        exclude_node_attrs : list of str, optional
            List of node attributes to omit.
        max_line_length : int, optional
            Maximum line length for wrapping. If None, no wrapping is applied.

        Returns
        -------
        str
            String representation of the line with selected attributes.
        """
        # String attributes are quoted, with exceptions
        formatted_attrs = []

        # Add NAME attribute first (uppercase)
        if self.name:
            if isinstance(self.name, str) and self.name not in self.unquoted:
                # Use double quotes by replacing single quotes from repr
                name_str = repr(self.name).replace("'", '"')
                formatted_attrs.append(f"NAME={name_str}")
            else:
                formatted_attrs.append(f"NAME={self.name}")

        if line_attrs:
            l_attrs = {k: v for k, v in self.attrs.items() if k in line_attrs}
        else:
            l_attrs = self.attrs

        if exclude_line_attrs:
            l_attrs = {k: v for k, v in l_attrs.items() if k not in exclude_line_attrs}

        for k, v in l_attrs.items():
            if isinstance(v, str) and v not in self.unquoted:
                f = repr(v).replace("'", '"')  # Use double quotes
            else:
                f = v
            formatted_attrs.append(f"{k}={f}")

        txt_attrs = ", ".join(formatted_attrs)

        # First nodes, and nodes after attributes, are labeled
        formatted_nodes = []
        first_node = True
        for n in self.nodes:
            n_str = (
                n.__str__()
                if node_attrs is None and exclude_node_attrs is None
                else n.__str__(node_attrs, exclude_node_attrs)
            )
            if first_node:
                formatted_nodes.append(f"{self.NodeLabel}={n_str}")
                first_node = False
            else:
                formatted_nodes.append(n_str)

            if node_attrs:
                n_attrs = {k: v for k, v in n.attrs.items() if k in node_attrs}
            else:
                n_attrs = n.attrs

            if exclude_node_attrs:
                n_attrs = {
                    k: v for k, v in n_attrs.items() if k not in exclude_node_attrs
                }

            if n_attrs:
                # node has attributes printed, reset the flag:
                first_node = True

        txt_nodes = ", ".join(formatted_nodes)

        txt = f"LINE {', '.join([txt_attrs, txt_nodes])}"
        txt = txt.replace(", TF=", ",\n\tTF=")  # prettify

        # Apply line wrapping if max_line_length is specified
        if max_line_length:
            txt = self._wrap_line(txt, max_line_length)

        return txt

    @staticmethod
    def _wrap_line(text: str, max_length: int) -> str:
        """
        Wrap a line at commas to fit within max_length characters.

        Parameters
        ----------
        text : str
            The text to wrap.
        max_length : int
            Maximum length for each line.

        Returns
        -------
        str
            Wrapped text with lines broken at commas.
        """
        lines = []

        # Split by existing newlines first (preserve TF= formatting)
        for segment in text.split("\n"):
            if segment.startswith("\t"):
                # Keep indented lines as-is (like TF=)
                lines.append(segment)
            else:
                # Process the segment for wrapping
                if len(segment) <= max_length:
                    lines.append(segment)
                else:
                    # Split by commas while keeping the comma with the preceding element
                    parts = []
                    current_part = ""

                    # Split at ", " but keep track of the parts
                    tokens = segment.split(", ")

                    for i, token in enumerate(tokens):
                        # Add comma back except for the last token
                        if i < len(tokens) - 1:
                            token_with_comma = token + ","
                        else:
                            token_with_comma = token

                        # Check if adding this token would exceed max_length
                        test_line = (
                            current_part
                            + (" " if current_part else "")
                            + token_with_comma
                        )

                        if len(test_line) <= max_length or not current_part:
                            # Add to current line
                            current_part = test_line
                        else:
                            # Start a new line
                            parts.append(current_part)
                            current_part = "\t" + token_with_comma

                    # Add the last part
                    if current_part:
                        parts.append(current_part)

                    lines.extend(parts)

        return "\n".join(lines)

    def is_node(self, n: Union[Node, int]) -> bool:
        """
        Returns True if n is one of the line's nodes.

        Parameters
        ----------
        n : Node or int
            Node or node ID to check.

        Returns
        -------
        bool
            True if the node is part of the line, False otherwise.
        """
        if isinstance(n, Node):
            node_id = n.id
        else:
            node_id = n
        return node_id in [n.id for n in self.nodes]

    def is_stop(self, n: Union[Node, int]) -> bool:
        """
        Returns True if line stops at n.

        Parameters
        ----------
        n : Node or int
            Node or node ID to check.

        Returns
        -------
        bool
            True if the node is a stopping point on the line, False otherwise.
        """
        if isinstance(n, Node):
            node_id = n.id
        else:
            node_id = n
        return node_id in [n.id for n in self.stops]

    @property
    def stop_seq(self, sep: str = "_") -> str:
        """
        Returns a concatenation of line's stops.

        Parameters
        ----------
        sep : str, default="_"
            Separator to use between stop IDs.

        Returns
        -------
        str
            Concatenated string of stop IDs.
        """
        return sep.join([str(n.id) for n in self.stops])

    @staticmethod
    def from_string(string: str, potential_seps: Optional[list[str]] = None) -> "Line":
        """
        Parse a string representation into a line object.

        Parameters
        ----------
        string : str
            String to parse.
        potential_seps : Optional[list[str]], default=None
            List of potential separators to detect.

        Returns
        -------
        Line
            Parsed line object.

        Raises
        ------
        AssertionError
            If invalid node declarations are found.
        """
        if potential_seps is None:
            potential_seps = [" ", "\t", ","]

        # Guess the separator as the most common of potential separators:
        formatted = re.sub(r"[=,][\s\n\t]+", ",", string)  # clean
        # Accounts for multiple separators.
        seps_count = [len(re.findall(f"{sep}+", formatted)) for sep in potential_seps]
        sep = potential_seps[seps_count.index(max(seps_count))]

        # Clean:
        string = string.replace("\n", "")
        string = string.replace("\x1a", "")  # EOF windows >_>
        string = re.sub(r"\ALINE\s+", "", string)
        string = re.sub(r"[\s,]*\Z", "", string)
        if sep == " ":
            string = re.sub(f"{sep}*={sep}*", "=", string)

        # src for this amazing magic:
        # https://stackoverflow.com/a/16710842/2802352
        parts_pat = (
            f"""(?:["](?:\\.|[^"])*["]|['](?:\\.|[^'])*[']|[^{sep}"]|[^{sep}'])+"""
        )
        parts = re.findall(parts_pat, string)

        node_label_pat = r"\A\s*N(?:ODES)?\b"

        nodes = []
        line_attrs = {}
        node_attrs = {}

        n = None
        attrs_section = True

        while parts:
            p = parts.pop(0)

            # Clean:
            p = re.sub(r"[\s,]*\Z", "", p)
            k, _, v = [part.strip() for part in p.partition("=")]

            try:
                # For numbers
                v = ast.literal_eval(v)
            except (ValueError, SyntaxError):
                v = str(v)

            if bool(re.search(f"{node_label_pat}\s*=\s*", p)):
                attrs_section = False

            if attrs_section:
                # Check if k exists and v is not empty string (allow 0, False, etc.)
                if k and v != "":
                    line_attrs.update({k: v})

            else:
                # Replace the node label
                p = re.sub(f"{node_label_pat}\s*=\s*", "", p)

                if "=" in p:
                    if bool(re.search(f"{node_label_pat}", k)):
                        msg = f'Node declaration in attribute "{k}: {v}"'
                        msg += f"in node {n}, line:\n{line_attrs}"
                        raise AssertionError(msg)

                    # Still has '=', must be an attribute:
                    # Check if k exists and v is not empty string (allow 0, False, etc.)
                    if k and v != "":
                        node_attrs.update({k: v})

                else:
                    # It is a node:
                    if n:
                        # Add the previous node, with the attrs read so far
                        nodes.append(Node(n, **node_attrs))
                        node_attrs = {}  # reset

                    n = p  # Set the new node for future attrs to be read

        # Add the last node (if it is not empty)
        if n:
            nodes.append(Node(n, **node_attrs))

        ln = Line(nodes, **line_attrs)

        return ln

    @property
    def nodes_df(self) -> pd.DataFrame:
        """
        Returns a DataFrame with node sequence and their attributes.

        Returns
        -------
        pd.DataFrame
            DataFrame where each row represents a node with its attributes.
            Includes 'id', 'stopping', and all custom node attributes.
        """
        data = []
        for i, node in enumerate(self.nodes, 1):
            node_data = {
                "sequence": i,
                "id": node.id,
                "stopping": node.stopping,
            }
            # Add all custom attributes
            node_data.update(node.attrs)
            data.append(node_data)

        df = pd.DataFrame(data)

        return df

    def has_dwell_c(self) -> bool:
        """
        Check if any node in the line has a DWELL_C attribute.

        Returns
        -------
        bool
            True if at least one node has DWELL_C, False otherwise.
        """
        return any(hasattr(node, "DWELL_C") for node in self.nodes)

    def convert_dwell_c_to_dwell(self) -> "Line":
        """
        Convert DWELL_C attributes to DWELL by distributing to subsequent stops.

        DWELL_C applies to the preceding stop node and all subsequent stop nodes
        until another DWELL or DWELL_C is specified.

        Returns
        -------
        Line
            A new line with DWELL_C converted to DWELL.
        """
        # check it has dwell c
        if not self.has_dwell_c():
            return self
        # Create a deep copy to avoid modifying the original
        new_line = self.copy()

        current_dwell_c = None
        dwell_c_is_active = False

        for i, node in enumerate(new_line.nodes):
            # Check if this node has DWELL_C (explicitly check for attribute existence)
            if hasattr(node, "DWELL_C"):
                current_dwell_c = node.DWELL_C
                # Convert DWELL_C to DWELL for this node if it's a stop
                if node.stopping:
                    node.DWELL = current_dwell_c  # type: ignore[attr-defined]
                # Remove DWELL_C attribute
                delattr(node, "DWELL_C")
                # If DWELL_C is 0, stop propagation immediately
                if current_dwell_c == 0:
                    dwell_c_is_active = False
                else:
                    dwell_c_is_active = True

            # If we have an active DWELL_C and this is a stopping node
            elif dwell_c_is_active and node.stopping:
                # Check if this node already has DWELL (which would reset)
                if hasattr(node, "DWELL"):
                    dwell_c_is_active = False  # Reset DWELL_C propagation
                else:
                    # Apply the DWELL_C value as DWELL
                    node.DWELL = current_dwell_c  # type: ignore[attr-defined]

        return new_line

    def copy(self) -> "Line":
        """
        Create a deep copy of the line.

        Returns
        -------
        Line
            A new instance that is a deep copy of this line.
        """
        return deepcopy(self)


class LineFile:
    """
    Class representing a file of lines.

    A LineFile is a collection of line objects and comments.

    Parameters
    ----------
    content : list of (Line or str), optional
        List of line objects and comment strings.

    Attributes
    ----------
    content : list of (Line or str)
        List containing line objects and comment strings.
    """

    def __init__(self, content: Optional[list[Union[Line, str]]] = None) -> None:
        if content:
            self.content = content
        else:
            self.content = []

    def _warn_if_duplicates(self, additional_info: Optional[str] = None) -> None:
        """
        Raises a warning if there are lines with duplicated NAME in the LineFile.

        Parameters
        ----------
        additional_info : str, optional
            Additional information to include in the warning message.
        """
        if not self.name_unique:
            msg = "Several lines have the same NAME."
            if additional_info:
                msg += f" {additional_info}"
            warn(msg)

    @property
    def content_duplicates_renamed(self) -> list[Union[Line, str]]:
        """
        Returns the LineFile's content with duplicated NAMEs renamed.

        Returns
        -------
        list
            Copy of content with renamed lines.
        """
        renamed_content = []
        counts = Counter(self.line_names)
        suffixes = {k: 1 for k in counts}

        for x in self.content:
            if isinstance(x, Line):
                name = str(x.name)  # Treats int = str
                if counts[name] > 1:
                    x = x.copy()
                    newname = f"{name}_{suffixes[name]}"
                    suffixes[name] += 1
                    x.name = newname
            renamed_content.append(x)

        # re-test (recursive)
        ren_sys = LineFile(renamed_content)
        if not ren_sys.name_unique:
            renamed_content = ren_sys.content_duplicates_renamed

        return renamed_content

    def rename_duplicates(self) -> None:
        """
        Changes the LineFile's content to avoid lines with duplicated NAMEs.
        """
        self.content = self.content_duplicates_renamed

    @property
    def name_unique(self) -> bool:
        """
        Returns True if lines' property "NAME" is a unique identifier.

        Returns
        -------
        bool
            True if all line names are unique, False otherwise.
        """
        names = self.line_names
        if not names:
            return True
        _, count = Counter(names).most_common(1)[0]
        return not count > 1

    @property
    def comments(self) -> list[str]:
        """
        Returns the list of comments in the file.

        Returns
        -------
        list of str
            All comments in the file.
        """
        return [x for x in self.content if isinstance(x, str)]

    @property
    def lines(self) -> dict[str, Line]:
        """
        Returns a dictionary of lines by NAME.

        Returns
        -------
        Dict[str, Line]
            Dictionary of lines with NAME as key.
        """
        msg = "Only the latest line is displayed for conflicting NAMEs."
        self._warn_if_duplicates(additional_info=msg)
        return {x.name: x for x in self.content if isinstance(x, Line)}

    @property
    def lines_duplicates_renamed(self) -> dict[str, Line]:
        """
        Returns a dictionary of lines with duplicated NAMEs renamed.

        Returns
        -------
        Dict[str, Line]
            Dictionary of lines with NAME as key, duplicates renamed.
        """
        return {
            x.name: x for x in self.content_duplicates_renamed if isinstance(x, Line)
        }

    @property
    def line_names(self) -> list[str]:
        """
        Returns a list of line names as strings.

        Preserves order. May contain duplicates.

        Returns
        -------
        list[str]
            List of line names.
        """
        return [str(x.name) for x in self.content if isinstance(x, Line)]

    def __repr__(self) -> str:
        """
        Object's summary representation.

        Returns
        -------
        str
            String representation summarising the LineFile.
        """
        self._warn_if_duplicates()
        # Using self.line_names avoids triggering further warnings:
        txt = f"LineFile with {len(self.line_names)} lines, "
        txt += f"and {len(self.comments)} comments."
        txt += "\nLines:\n"
        txt += ", ".join([str(k) for k in self.line_names])  # if int NAMEs
        txt += "\nComments:\n"
        txt += "\n".join(self.comments)
        return txt

    def __str__(
        self,
        sort: bool = False,
        comments: bool = True,
        rename_duplicates: bool = False,
        max_line_length: Optional[int] = None,
        **kwargs: Any,
    ) -> str:
        """
        Representation as the file itself.

        Parameters
        ----------
        sort : bool, default=False
            If False, output is sorted with the same structure as input content.
            If True, comments are first, then all lines in NAME order.
        comments : bool, default=True
            Output comments only if True.
        rename_duplicates : bool, default=False
            Rename duplicated NAMEs if True.
        max_line_length : int, optional
            Maximum line length for wrapping. If None, no wrapping is applied.
        **kwargs : dict
            Additional keyword arguments to pass to the line.__str__ method.

        Returns
        -------
        str
            String representation of the LineFile.
        """
        if not rename_duplicates:
            self._warn_if_duplicates()

        # Add max_line_length to kwargs
        if max_line_length is not None:
            kwargs["max_line_length"] = max_line_length

        if sort:
            lines = self.lines
            # Use only if there are duplicates. Makes code more compact:
            if rename_duplicates and not self.name_unique:
                lines = self.lines_duplicates_renamed

            # Use str() instead of .__str__() directly
            sorted_lines = [lines[ln].__str__(**kwargs) for ln in sorted(lines)]
            txt_lines = "\n".join(sorted_lines)

            if comments:
                txt_comments = "\n".join([c for c in self.comments])
                txt = "\n".join([txt_comments, txt_lines])
            else:
                txt = txt_lines

        else:
            content = self.content
            # Use only if there are duplicates. Makes code more compact:
            if rename_duplicates and not self.name_unique:
                content = self.content_duplicates_renamed

            if comments:
                txt_content = [
                    x.__str__(**kwargs) if not isinstance(x, str) else str(x)
                    for x in content
                ]
            else:
                txt_content = [
                    x.__str__(**kwargs) for x in content if not isinstance(x, str)
                ]

            txt = "\n".join(txt_content)

        return txt

    def save(
        self,
        path: Path | str,
        sort: bool = False,
        comments: bool = True,
        node_attrs: Optional[list[str]] = None,
        exclude_node_attrs: Optional[list[str]] = None,
        line_attrs: Optional[list[str]] = None,
        exclude_line_attrs: Optional[list[str]] = None,
        rename_duplicates: bool = True,
        max_line_length: int = 70,
    ) -> None:
        """
        Save the LineFile to a file.

        Parameters
        ----------
        path : Path | str
            Path to the output file.
        sort : bool, default=False
            If True, sorts the output.
        comments : bool, default=True
            If True, includes comments in the output.
        node_attrs : list of str, optional
            List of node attributes to include.
        exclude_node_attrs : list of str, optional
            List of node attributes to omit.
        line_attrs : list of str, optional
            List of line attributes to include.
        exclude_line_attrs : list of str, optional
            List of line attributes to omit.
        rename_duplicates : bool, default=True
            If True, renames duplicate line names.
        max_line_length : int, default=70
            Maximum line length for wrapping. Set to None to disable wrapping.
        """
        if not self.name_unique and rename_duplicates:
            msg = "Duplicated NAMES will be renamed."
            self._warn_if_duplicates(additional_info=msg)

        with open(path, "w", encoding="utf-8") as ofile:
            # Use the method directly instead of the str() built-in
            output = self.__str__(
                sort=sort,
                comments=comments,
                node_attrs=node_attrs,
                exclude_node_attrs=exclude_node_attrs,
                line_attrs=line_attrs,
                exclude_line_attrs=exclude_line_attrs,
                rename_duplicates=rename_duplicates,
                max_line_length=max_line_length,
            )
            ofile.write(output)

    def update_line(self, name: str, updated_line: Line) -> None:
        """
        Update a line in place by its NAME.

        Parameters
        ----------
        name : str
            Name of the line to update.
        updated_line : Line
            The updated line object to replace the existing one.

        Raises
        ------
        KeyError
            If no line with the specified name exists.
        """
        found = False
        for i, item in enumerate(self.content):
            if isinstance(item, Line) and str(item.name) == str(name):
                self.content[i] = updated_line
                found = True
                break

        if not found:
            raise KeyError(f"Line with NAME '{name}' not found in LineFile.")

    def lines_by_attr(self, attr: str, val: Any) -> list[Line]:
        """
        Returns a list of lines having a specific value in an attribute.

        Parameters
        ----------
        attr : str
            Attribute name to check.
        val : Any
            Value to match.

        Returns
        -------
        list[Line]
            List of lines that match the criteria.
        """
        lines = [ln for ln in self.lines.values() if getattr(ln, attr) == val]
        return lines

    def lines_query(self, qry: str) -> list[Line]:
        """
        Returns a list of lines meeting a SQL-like query.

        This relies on pandas DataFrame query:
            https://pandas.pydata.org/pandas-docs/stable/generated/pandas.DataFrame.query.html

        Parameters
        ----------
        qry : str
            SQL-like query string.

        Returns
        -------
        list[Line]
            List of lines that match the query.
        """
        lns_names = self.df.query(qry)["NAME"].tolist()

        if lns_names:
            lns = [self.lines[n] for n in lns_names]
            return lns
        else:
            return []

    @property
    def df(self) -> pd.DataFrame:
        """
        Returns a dataframe with the attributes for each line.

        Returns
        -------
        pd.DataFrame
            DataFrame containing line attributes as columns.
        """
        # Assume lines start on 1:
        data = {i: ln.attrs for i, ln in enumerate(self.lines.values(), 1)}
        df = pd.DataFrame.from_records(data).T

        # stops and nodes are objects!
        additional_attrs = "stop_seq stops nodes".split()
        for attr in additional_attrs:
            df[attr] = [getattr(ln, attr) for ln in self.lines.values()]

        return df

    @staticmethod
    def _extract_blocks(
        string: str,
        block_pat: str = r"(?s)(?:(;.*?|\n\s*)\n|LINE\s+(.*?)(?=\n\s*LINE|\n\s*;|\Z))",
    ) -> list[tuple[str, str]]:
        """
        Returns a list of tuples [(comment, line), (), ...] for each record.

        Parameters
        ----------
        string : str
            Input string to parse.
        block_pat : str, default regex pattern
            Regex pattern to extract blocks.

        Returns
        -------
        List[Tuple[str, str]]
            List of tuples containing (comment, line) pairs.
        """
        block_re = re.compile(block_pat)
        blocks = block_re.findall(string)
        return blocks

    @staticmethod
    def from_string(string: str) -> "LineFile":
        """
        Create a LineFile from a string.

        Parameters
        ----------
        string : str
            String representation of a line file.

        Returns
        -------
        LineFile
            Parsed LineFile object.
        """
        blocks = LineFile._extract_blocks(string)

        content: list[Union[str, Line]] = []
        for comment_txt, line_txt in blocks:
            if comment_txt:
                content.append(comment_txt)

            if line_txt:
                ln = Line.from_string(line_txt)
                content.append(ln)

        s = LineFile(content)

        return s

    @staticmethod
    def read_file(path: Path | str) -> "LineFile":
        """
        Read a line file from disk.

        Parameters
        ----------
        path : Path | str
            Path to the file.

        Returns
        -------
        LineFile
            Parsed LineFile object from the file.
        """
        with open(path, "r", encoding="utf-8") as ifile:
            content = ifile.read()

        s = LineFile.from_string(content)

        return s


##### FUNCTIONS #####
@contextlib.contextmanager
def _temp_run_dir(parent: Path, stem: str, keep: bool = False):
    """
    Context manager for a temporary Voyager run directory.

    Parameters
    ----------
    parent : Path
        Parent directory where the temp folder will be created.
    stem : str
        Prefix / stem for the temp folder name.
    keep : bool
        If True, directory is kept (for debugging).
    """
    if keep:
        path = Path(tempfile.mkdtemp(prefix=f"{stem}_", dir=parent))
        try:
            yield path
        finally:
            # caller decides when to delete
            pass
    else:
        with tempfile.TemporaryDirectory(prefix=f"{stem}_", dir=parent) as td:
            yield Path(td)


def _run_voyager(
    voyager_exe: Path,
    parent_dir: Path,
    script_name: str,
    script_lines: list[str],
    keep_temp: bool = False,
    raise_on_code: int = 2,
) -> subprocess.CompletedProcess:
    """
    Write a Voyager script into a temp directory, execute it, handle cleanup.

    Parameters
    ----------
    voyager_exe : Path
        Path to voyager executable.
    parent_dir : Path
        Directory under which temp folder will be created.
    script_name : str
        Script filename (e.g. 'ParseRoutes.S').
    script_lines : list[str]
        Script body lines.
    keep_temp : bool
        Keep temp directory (debug).
    raise_on_code : int
        Return code that triggers RuntimeError.

    Returns
    -------
    subprocess.CompletedProcess
    """
    # Create temp directory
    stem = Path(script_name).stem
    with _temp_run_dir(parent_dir, stem, keep=keep_temp) as tmp:
        script_path = tmp / script_name
        script_path.write_text("\n".join(script_lines), encoding="utf-8")
        # Execute Voyager
        args = [
            str(voyager_exe.resolve()),
            str(script_path.resolve()),
            "-Pvdmi",
            "/Start",
            "/Hide",
            "/HideScript",
        ]
        proc = subprocess.run(args, capture_output=True, check=False)
        # Check for errors
        if proc.returncode == raise_on_code:
            prn = script_path.with_suffix(".PRN")
            msg = f"Voyager failed (returncode {proc.returncode}). Check: {prn}"
            if not keep_temp:
                # Optionally dump stdout/stderr somewhere else if needed
                pass
            raise RuntimeError(msg)

        return proc


def process_cube_routes(
    voyager_exe: Path,
    routes_print_file: Path,
    outputs_routes_file: Path | None = None,
    keep_temp: bool = False,
) -> None:
    """Parse and format Cube routes.

    Parameters
    ----------
    voyager_exe : Path
        Path to voyager executable
    routes_print_file: Path
        Path to Cube routes file
    outputs_routes_file: Path | None
        Output (CSV/DBF) base path. Defaults to same folder/name as routes_print_file.
    keep_temp : bool
        Keep temp directory (for debugging).
    """
    if outputs_routes_file:
        outputs_part = [
            f'FILEO PRINTO[1] = "{outputs_routes_file.with_suffix(".CSV")}"',
            f'FILEO RECO[1] = "{outputs_routes_file.with_suffix(".DBF")}"',
            "      FIELDS=from_zone_id, to_zone_id, userclass, "
            "count, bundle, L, probability(6.4),",
            "             a_node, b_node, mode, WaitA(6.2), TimeA(6.2), Actual(6.2), "
            "BXFerPen(6.2), Percvd(6.2), LegDist(6.2), TotDist(6.2)",
        ]
    else:
        base = routes_print_file.parent / routes_print_file.stem
        outputs_part = [
            f'FILEO PRINTO[1] = "{base}.CSV"',
            f'FILEO RECO[1] = "{base}.DBF"',
            "      FIELDS=from_zone_id, to_zone_id, userclass, "
            "count, bundle, L, probability(6.4),",
            "             a_node, b_node, mode, WaitA(6.2), TimeA(6.2), Actual(6.2), "
            "BXFerPen(6.2), Percvd(6.2), LegDist(6.2), TotDist(6.2)",
        ]

    script_lines = (
        [
            f'RUN PGM=MATRIX PRNFILE="ParseRoutes_{routes_print_file.stem}.PRN"',
            "; Outputs",
        ]
        + outputs_part
        + [
            "; Inputs",
            f'FILEI RECI = "{routes_print_file}"',
            "",
            "; Process",
            "",
            "MAXSTRINGS=1000",
            "ARRAY TYPE=C999 _LINE_LIST=100",
            "ARRAY _NODE_LIST=100 _MODE_LIST=100 _WAITA_LIST=100 _TimeA_LIST=100 _Actual_LIST=100",
            "ARRAY _BXferPen_LIST=100 _Percvd_LIST=100 _Dist_LIST=100 _Total_LIST=100",
            "",
            "IF(Reci.RecNo=1)",
            "  PRINT  PRINTO=1, CSV=T, LIST='from_stn_zone_id', 'to_stn_zone_id', "
            "'bundle', 'L', 'probability', 'a_node', 'b_node',",
            "                               'mode', 'WaitActual', 'TimeActual', "
            "'TotalActual', 'BrdXFerPen', 'PercvdTime', 'LegDistance', 'TotDistance', 'Services'",
            "ENDIF",
            "",
            "IF (STRPOS('User',RECI)=1)",
            "    _UserClass = _UserClass + 1",
            "    IF(_UserClass > 1)",
            "      _UserClass = 1",
            "    ENDIF",
            "ENDIF",
            "",
            "IF (STRPOS('N:',RECI)=1)",
            "    _COUNTN=1",
            "    _NODE_LIST[_COUNTN]=VAL(TRIM(LTRIM(SUBSTR(RECI,3, STRPOS('Mode',RECI)-3))))",
            "    _ROUTEBUNDLE=_ROUTEBUNDLE+1",
            "ENDIF",
            "IF (STRPOS('->',RECI)=1)",
            "    _COUNTN=_COUNTN+1",
            "    _NODE_LIST[_COUNTN]=VAL(SUBSTR(RECI,3,6))",
            "    _MODE_LIST[_COUNTN]=VAL(SUBSTR(RECI,9,5))",
            "    _WAITA_LIST[_COUNTN]=VAL(SUBSTR(RECI,14,7))",
            "    _TimeA_LIST[_COUNTN]=VAL(SUBSTR(RECI,21,7))",
            "    _Actual_LIST[_COUNTN]=VAL(SUBSTR(RECI,28,7))",
            "    _BXferPen_LIST[_COUNTN]=VAL(SUBSTR(RECI,35,7))",
            "    _Percvd_LIST[_COUNTN]=VAL(SUBSTR(RECI,42,7))",
            "    _Dist_LIST[_COUNTN]=VAL(SUBSTR(RECI,49,7))",
            "    _Total_LIST[_COUNTN]=VAL(SUBSTR(RECI,56,7))",
            "    _LINE_LIST[_COUNTN]=LTRIM(SUBSTR(RECI,65,800))",
            "ENDIF",
            "",
            "IF (STRPOS('Probability=', RECI)=1)",
            "    _ProbTemp = VAL(SUBSTR(RECI,13,800))",
            "",
            "    IF(_ProbTemp>0)",
            "",
            "      RO.probability=VAL(SUBSTR(RECI,13,800))",
            "      LOOP L=1,_COUNTN-1",
            "          RO.from_stn_zone_id=_NODE_LIST[1]",
            "          RO.to_stn_zone_id=_NODE_LIST[_COUNTN]",
            "          RO.userclass = _UserClass",
            "          RO.count = _COUNTN",
            "          RO.bundle=_ROUTEBUNDLE",
            "          RO.a_node=_NODE_LIST[L]",
            "          RO.b_node=_NODE_LIST[L+1]",
            "          RO.mode=_MODE_LIST[L+1]",
            "          RO.WAITA=_WAITA_LIST[L+1]",
            "          RO.TimeA=_TimeA_LIST[L+1]",
            "          RO.Actual=_Actual_LIST[L+1]",
            "          RO.BXFerPen=_BXferPen_LIST[L+1]",
            "          RO.Percvd=_Percvd_LIST[L+1]",
            "          RO.LegDist=_Dist_LIST[L+1]",
            "          RO.TotDist=_Total_LIST[L+1]",
            "          WRITE RECO=1",
            "          PRINT CSV=T, LIST=RO.from_stn_zone_id(5.0L), RO.to_stn_zone_id(5.0L), "
            "RO.bundle(5.0L), L(5.0), RO.probability(6.4L), RO.a_node(6.0L), RO.b_node(6.0L),",
            "                          RO.mode(3.0L), RO.WaitA(12.2L), RO.TimeA(12.2L), "
            "RO.Actual(12.2L), RO.BXFerPen(12.2L), RO.Percvd(12.2L), RO.LegDist(12.2L), RO.TotDist(12.2L),",
            "                          _LINE_LIST[L+1](L999) PRINTO=1",
            "      ENDLOOP",
            "    ENDIF",
            "    _COUNTN=0",
            "ENDIF",
            "",
            "IF (STRPOS('REval Route(s)', RECI)>0)",
            "    _ROUTEBUNDLE=0",
            "ENDIF",
            "ENDRUN",
        ]
    )

    _run_voyager(
        voyager_exe=voyager_exe,
        parent_dir=routes_print_file.parent,
        script_name=f"ParseRoutes_{routes_print_file.stem}.S",
        script_lines=script_lines,
        keep_temp=keep_temp,
    )


def network_to_shapefile(
    voyager_exe: Path,
    network_file: Path,
    nodes_file: Path | None = None,
    links_file: Path | None = None,
    projection_string: Optional[str] = None,
    keep_temp: bool = False,
) -> None:
    """Export Cube network to Links and Nodes shapefiles.

    Parameters
    ----------
    voyager_exe : Path
        Path to voyager executable
    network_file: Path
        Path to run folder
    nodes_file: Path | None
        Path to nodes shapefile
    links_file: Path | None
        Path to links shapefile
    projection_string: Optional[str]
        projection string to use for shapefiles
    keep_temp: bool
        whether to keep temporary files

    Raises
    ------
    RuntimeError
        When Cube fails
    """
    if nodes_file:
        nodes_file_str = f"{nodes_file.with_suffix('')}.SHP"
    else:
        nodes_file_str = f"{network_file.with_suffix('')}_Nodes.SHP"
    if links_file:
        links_file_str = f"{links_file.with_suffix('')}.SHP"
    else:
        links_file_str = f"{network_file.with_suffix('')}_Links.SHP"

    script_lines = [
        f'RUN PGM=NETWORK PRNFILE="ConvertNetwork_{network_file.stem}.PRN"',
        "; Outputs",
        f'FILEO NODEO = "{nodes_file_str}",',
        "     FORMAT=SHP",
        f'FILEO LINKO = "{links_file_str}",',
        "     FORMAT=SHP",
        "; Inputs",
        f'FILEI LINKI[1] = "{network_file.resolve()}"',
        "; Process",
        "",
        "PROCESS PHASE = NODEMERGE",
        "   GEOMETRYSOURCE=1",
        "ENDPROCESS",
        "",
        "PROCESS PHASE = LINKMERGE",
        "   GEOMETRYSOURCE=1",
        "ENDPROCESS",
        "",
        "ENDRUN",
    ]

    _run_voyager(
        voyager_exe=voyager_exe,
        parent_dir=network_file.parent,
        script_name=f"ConvertNetwork_{network_file.stem}.S",
        script_lines=script_lines,
        keep_temp=keep_temp,
    )

    if projection_string:
        (network_file.parent / f"{Path(nodes_file_str).stem}.PRJ").write_text(
            projection_string, encoding="utf-8"
        )
        (network_file.parent / f"{Path(links_file_str).stem}.PRJ").write_text(
            projection_string, encoding="utf-8"
        )


def network_to_csvs(
    voyager_exe: Path,
    network_file: Path,
    nodes_file: Path | None = None,
    links_file: Path | None = None,
    keep_temp: bool = False,
) -> None:
    """Export Cube network to Links and Nodes CSVs.

    Parameters
    ----------
    voyager_exe : Path
        Path to voyager executable
    network_file: Path
        Path to run folder
    nodes_file: Path | None
        Path to nodes CSV
    links_file: Path | None
        Path to links CSV
    keep_temp: bool = False
        whether to keep temporary files

    Raises
    ------
    RuntimeError
        When Cube fails
    """
    if nodes_file:
        nodes_file_str = f"{nodes_file.with_suffix('')}.CSV"
    else:
        nodes_file_str = f"{network_file.with_suffix('')}_Nodes.CSV"
    if links_file:
        links_file_str = f"{links_file.with_suffix('')}.CSV"
    else:
        links_file_str = f"{network_file.with_suffix('')}_Links.CSV"

    script_lines = [
        f'RUN PGM=NETWORK PRNFILE="ConvertNetwork_{network_file.stem}.PRN"',
        "; Outputs",
        f'FILEO NODEO = "{nodes_file_str}",',
        '     FORMAT=TXT, DELIMITER=","',
        f'FILEO LINKO = "{links_file_str}",',
        '     FORMAT=TXT, DELIMITER=","',
        "; Inputs",
        f'FILEI LINKI[1] = "{network_file.resolve()}"',
        "; Process",
        "",
        "ENDRUN",
    ]

    _run_voyager(
        voyager_exe=voyager_exe,
        parent_dir=network_file.parent,
        script_name=f"ConvertNetwork_{network_file.stem}.S",
        script_lines=script_lines,
        keep_temp=keep_temp,
    )


def build_network_from_csvs(
    voyager_exe: Path,
    links_file: Path,
    nodes_file: Path,
    network_path: Path,
    links_var: list[str],
    nodes_var: list[str],
    keep_temp: bool = False,
) -> None:
    """Build Cube network from links and nodes CSVs.

    Parameters
    ----------
    voyager_exe : Path
        Path to voyager executable
    links_file: Path
        Path to links CSV
    nodes_file: Path
        Path to nodes CSV
    network_path: Path
        Path to network folder
    links_var: list[str]
        List of Links csv variables, must include "A" and "B"
    nodes_var: list[str]
        List of Nodes csv variables, must include "N", "X" and "Y"
    keep_temp: bool = False
        whether to keep temporary files

    Raises
    ------
    RuntimeError
        When Cube fails
    """
    script_lines = [
        f'RUN PGM=NETWORK PRNFILE="CreateNetwork_{network_path.stem}.PRN"',
        "; Outputs",
        f'FILEO NETO = "{network_path.with_suffix(".NET")}"',
        "; Inputs",
        f'FILEI LINKI[1] = "{links_file.with_suffix(".CSV")}",',
        f"      VAR={', '.join([f'"{item}"' for item in links_var])}",
        f'FILEI NODEI[1] = "{nodes_file.with_suffix(".CSV")}",',
        f"      VAR={', '.join([f'"{item}"' for item in nodes_var])}",
        "; Process",
        "",
        "ENDRUN",
    ]

    _run_voyager(
        voyager_exe=voyager_exe,
        parent_dir=network_path.parent,
        script_name=f"CreateNetwork_{network_path.stem}.S",
        script_lines=script_lines,
        keep_temp=keep_temp,
    )


def omx_to_mat(
    voyager_exe: Path,
    omx_path: Path,
    mat_path: Path | None = None,
    keep_temp: bool = False,
) -> None:
    """Convert OMX Matrix to Cube MAT matrix.

    Parameters
    ----------
    voyager_exe : Path
        Path to voyager executable
    omx_path : Path
        Path to OMX matrix file
    mat_path: Path | None
        Path to Cube MAT matrix
    keep_temp: bool = False
        whether to keep temporary files

    Raises
    ------
    RuntimeError
        When Cube fails
    """
    if omx_path.suffix == "":
        omx_path = omx_path.with_suffix(".omx")
    if mat_path is None:
        mat_path = omx_path.with_suffix(".mat")
    elif mat_path.suffix == "":
        mat_path = mat_path.with_suffix(".mat")

    script_lines = [
        f'CONVERTMAT FROM="{omx_path.resolve()}" TO="{mat_path.resolve()}" FORMAT=TPP COMPRESSION=0'
    ]

    _run_voyager(
        voyager_exe=voyager_exe,
        parent_dir=omx_path.parent,
        script_name=f"Convert_OMX2MAT_{omx_path.stem}.S",
        script_lines=script_lines,
        keep_temp=keep_temp,
    )


def mat_to_omx(
    voyager_exe: Path,
    mat_path: Path,
    omx_path: Path | None = None,
    compression: int = 0,
    keep_temp: bool = False,
) -> None:
    """Convert Cube .MAT to OMX Matrix

    Parameters
    ----------
    voyager_exe : Path
        Path to voyager executable
    mat_path: Path
        Path to Cube MAT matrix
    omx_path : Path | None
        Path to OMX matrix file
    compression: int, default 0
        Compression level of output matrix
    keep_temp: bool = False
        whether to keep temporary files

    Raises
    ------
    RuntimeError
        When Cube fails
    """
    if mat_path.suffix == "":
        mat_path = mat_path.with_suffix(".mat")
    if omx_path is None:
        omx_path = mat_path.with_suffix(".omx")
    elif omx_path.suffix == "":
        omx_path = omx_path.with_suffix(".omx")

    script_lines = [
        f'CONVERTMAT FROM="{mat_path.resolve()}" TO="{omx_path.resolve()}" FORMAT=OMX COMPRESSION={compression}'
    ]

    _run_voyager(
        voyager_exe=voyager_exe,
        parent_dir=mat_path.parent,
        script_name=f"Convert_MAT2OMX_{mat_path.stem}.S",
        script_lines=script_lines,
        keep_temp=keep_temp,
    )


def parse_cube_zones_character(
    cube_range: str,
) -> list[Any]:
    """Parse Cube format list of zones/ranges into list of zones

    Parameters
    ----------
    cube_range : str
        range of Cube style list/range of zones

    Returns
    -------
    zones_list : list[Any]
        list of individual zones
    """
    # remove white space
    cube_range = cube_range.replace(" ", "")
    zones = cube_range.split(",")
    zones_list: list[Any] = []

    for zone in zones:
        if "-" in zone:
            # split range
            start, end = map(int, zone.split("-"))
            # create inclusive range
            zones_list.extend(range(start, end + 1))
        else:
            try:
                zones_list.append(int(zone))
            except ValueError:
                zones_list.append(str(zone))

    return zones_list


def parse_sqex_file(
    sqex_file: Path,
    level: str,
    sectors: str,
) -> pl.DataFrame:
    """Read Cube's SQEX file and create a lookup dataframe between zones and sectors.

    NOTE: The function currently assumes a full weighting zones<>sectors.
    i.e. if a zone is split weighted across multiple sectors then the function will
    ignore that and take first appearance.

    Parameters
    ----------
    sqex_file : Path
        path to the sqex file
    level : str
        the zone level either "stn" or "zone"
    sectors : str
        number of sectors

    Returns
    -------
    sqex_df : pl.DataFrame
        stn/zone to sectors lookup
    """
    # read sqex file into a dataframe
    sqex_df = pl.read_csv(
        sqex_file,
        columns=[0, 1],
        has_header=False,
        new_columns=[f"{level}_zone_id", f"Sectors_{sectors}"],
        dtypes=[pl.Int32, pl.Int32],
    )  # type: ignore
    # drop duplicates to remove split weights
    sqex_df = sqex_df.unique()

    return sqex_df

def dfs_to_mat(
    voyager_exe: Path,
    dfs: dict[str, pl.DataFrame | pd.DataFrame],
    mat_path: Path,
    zones: Optional[int] = None,
    keep_temp: bool = False,
) -> None:
    """Convert DataFrames to CUBE's .MAT format.
    DataFrames should have 3 columns: origin, destination and trips, in that order, but header names are optional.

    Parameters
    ----------
    voyager_exe : Path
        Path to Cube Voyager executable.
    zones : int, optional
        Number of zones in the matrix. If None, auto-detected from the data.
    dfs : dict[str, pl.DataFrame | pd.DataFrame]
        Dictionary containing the DataFrames. The key will be used as the matrix tab name.
    mat_path : Path
        Output CUBE .mat file to create.
    keep_temp : bool, optional
        Whether or not to keep temporary files after conversion,
        by default False

    Raises
    ------
    FileNotFoundError
        If Mat path parent folder doesn't exist.
    RuntimeError
        If there is an error converting CSV to CUBE .mat.
    """
    # Check mat path parent exists
    if not mat_path.parent.is_dir():
        raise FileNotFoundError(f"cannot find folder: {mat_path.parent}")
    
    if mat_path.suffix.lower() != ".mat":
        mat_path = mat_path.with_suffix(".mat")
    
    # Auto-detect zones if not provided
    if zones is None:
        max_zone = 0
        for mat_df in dfs.values():
            if isinstance(mat_df, pl.DataFrame):
                col0_max = mat_df[mat_df.columns[0]].max()
                col1_max = mat_df[mat_df.columns[1]].max()
                # Handle None values and ensure numeric types
                if col0_max is not None and col1_max is not None:
                    assert isinstance(col0_max, (int, float)), "Expected numeric value"
                    assert isinstance(col1_max, (int, float)), "Expected numeric value"
                    csv_max = max(int(col0_max), int(col1_max))
                    max_zone = max(max_zone, csv_max)
            else:
                cols = mat_df.columns
                col0_max = mat_df[cols[0]].max()
                col1_max = mat_df[cols[1]].max()
                # Handle potential None/NaN values from pandas max()
                if pd.notna(col0_max) and pd.notna(col1_max):
                    df_max = max(int(col0_max), int(col1_max))
                    max_zone = max(max_zone, df_max)
        zones = int(max_zone)
    
    # Create temp folder, ensuring it does not exist
    with _temp_run_dir(mat_path.parent, f"DFS2MAT_{mat_path.stem}", keep=keep_temp) as temp_dir:
        csvs: list[str | Path] = []
        for name, mat_df in dfs.items():
            csv_path = temp_dir / f"{name}.csv"
            if isinstance(mat_df, pl.DataFrame):
                mat_df = mat_df.sort(mat_df.columns[0], mat_df.columns[1])
                mat_df.write_csv(csv_path, include_header=False)
            else:

                cols = mat_df.columns
                mat_df = mat_df.sort_values(by=[cols[0], cols[1]])
                mat_df.to_csv(csv_path, index=False, header=False)
            csvs.append(csv_path)

        csv_to_mat(voyager_exe=voyager_exe, zones=zones, csvs=csvs,
               mat_path=mat_path, keep_temp=keep_temp)

    if not mat_path.is_file():
        raise RuntimeError("error converting CSV to CUBE .mat")
    
    if not keep_temp:
        try:
            shutil.rmtree(temp_dir)
        except Exception:
            pass
            
            
def csv_to_mat(
    voyager_exe: Path,
    csvs: list[str | Path],
    mat_path: Path,
    zones: Optional[int] = None,
    remove_csvs: bool = True,
    keep_temp: bool = False,
) -> None:
    """Convert CSVs to CUBE's .MAT format.
    CSVs should have 3 columns: origin, destination and trips,
    with no header row.

    Parameters
    ----------
    voyager_exe : Path
        Path to voyager executable.
    csvs : list[str | Path]
        List of lists containing the CSV file names and paths.
    mat_path : Path
        Output CUBE .mat file to create.
    zones : int, optional
        Number of zones in the matrix. If None, auto-detected from the data.
    remove_csvs : bool, optional
        Whether or not to remove the input CSVs after conversion,
        by default True
    keep_temp : bool, optional
        Whether or not to keep temporary files after conversion,
        by default False

    Raises
    ------
    FileNotFoundError
        If any of the input CSVs don't exist.
    """
    for csv in csvs:
        if not Path(csv).is_file():  # type: ignore
            raise FileNotFoundError(f"cannot find CSV: {csv}")

    if mat_path.suffix.lower() != ".mat":
        mat_path = mat_path.with_suffix(".mat")
    
    # Auto-detect zones if not provided
    if zones is None:
        max_zone = 0
        for csv in csvs:
            df = pl.read_csv(csv, has_header=False, n_rows=None)
            col0_max = df[df.columns[0]].max()
            col1_max = df[df.columns[1]].max()
            # Handle None values and ensure numeric types
            if col0_max is not None and col1_max is not None:
                assert isinstance(col0_max, (int, float)), "Expected numeric value"
                assert isinstance(col1_max, (int, float)), "Expected numeric value"
                csv_max = max(int(col0_max), int(col1_max))
                max_zone = max(max_zone, csv_max)
        zones = int(max_zone)
    
    script_lines: list[str] = [
        "RUN PGM=MATRIX",
        f'FILEO MATO[1]="{mat_path.resolve()}",',
        f"      mo=1-{len(csvs)},dec={len(csvs)}*d,name="
        + ", ".join(Path(nm).stem for nm in csvs),
    ]
    for n, csv in enumerate(csvs, start=1):
        script_lines.append(f'FILEI MATI[{n}]="{Path(csv).resolve()}",')
        script_lines.append("      fields=#1,2,3, pattern=ij:v")
    script_lines += ["", f"zones={zones}", "fillmw"]
    script_lines += [f"mw[{n}]=mi.{n}.1" for n in range(1, len(csvs) + 1)]
    script_lines += ["", "ENDRUN"]

    _run_voyager(
        voyager_exe=voyager_exe,
        parent_dir=mat_path.parent,
        script_name=f"CSV2MAT_{mat_path.stem}.S",
        script_lines=script_lines,
        keep_temp=keep_temp,
    )

    if not mat_path.is_file():
        raise RuntimeError("error converting CSV to CUBE .mat")

    if remove_csvs:
        for csv in csvs:
            try:
                Path(csv).unlink(missing_ok=True)
            except Exception:
                pass


def sqex_matrix(
    voyager_exe: Path,
    matrix_file: Path,
    sqex_file: Path,
    output_file: Optional[Path] = None,
    keep_temp: bool = False,
    data_group: str = "data",
    lookup_group: str = "lookup",
) -> None:
    """Sqex Cube matrix.

    Parameters
    ----------
    voyager_exe : Path
        Path to Cube Voyager executable.
    matrix_file : Path
        Path to Cube .mat file.
    sqex_file : Path
        Path to Cube .sqex file.
    output_file : Path, optional
        Path to output .mat file, by default None
    keep_temp : bool, optional
        Whether or not to keep temporary files, by default False
    data_group : str, optional
        Name of the HDF5 group that holds matrix CArrays, by default "data"
    lookup_group : str, optional
        Name of the HDF5 group that holds mapping arrays, by default "lookup"

    Raises
    ------
    FileNotFoundError
        If any of files is not found.
    """
    # check if files exist
    if not matrix_file.is_file():
        raise FileNotFoundError(f"cannot find matrix file: {matrix_file}")
    if not sqex_file.is_file():
        raise FileNotFoundError(f"cannot find sqex file: {sqex_file}")

    # set output path
    if output_file is None:
        output_file = matrix_file.parent / f"{matrix_file.stem}_{sqex_file.stem}.mat"
    if output_file.is_file():
        # warn user if output file already exists
        print("WARNING: output file already exists!")
        print(f"    Overwriting {output_file}")

    # Get matrix info
    mat_to_omx(
        voyager_exe=voyager_exe,
        mat_path=matrix_file,
    )
    with omx.open_file(matrix_file.with_suffix(".omx"), data_group=data_group, lookup_group=lookup_group) as omx_mat:
        mat_tabs: list[str] = omx_mat.list_matrices()

    script_lines: list[str] = [
        "RUN PGM=MATRIX",
        f'FILEO MATO[1]="{output_file.resolve()}",',
        f"      MO=1-{len(mat_tabs)},DEC={len(mat_tabs)}*D,NAME="
        + ",".join(str(tab) for tab in mat_tabs),
        f'FILEI MATI[1]="{matrix_file.resolve()}"',
        f'RENUMBER FILE = "{sqex_file.resolve()}",',
        "MISSINGZI=W, MISSINGZO=W",
    ]
    for n, tab in enumerate(mat_tabs, start=1):
        script_lines.append(f"MW[{n}]=MI.1.{tab}")
    script_lines += ["", "ENDRUN"]

    _run_voyager(
        voyager_exe=voyager_exe,
        parent_dir=matrix_file.parent,
        script_name=f"CSV2MAT_{matrix_file.stem}.S",
        script_lines=script_lines,
        keep_temp=keep_temp,
    )

    if not output_file.is_file():
        raise RuntimeError(f"error sqexing matrix {matrix_file}")

    # Remove omx
    matrix_file.with_suffix(".omx").unlink(missing_ok=True)


def rename_mat_tabs(
    voyager_exe: Path,
    mat_path: Path,
    new_tab_names: list[str],
    output_mat: Path | None = None,
    keep_temp: bool = False,
    overwrite_input: bool = False,
) -> Path:
    """
    Rewrite a MAT with new tab names (by index order).

    Parameters
    ----------
    voyager_exe : Path
        Path to Voyager executable.
    mat_path : Path
        Input MAT file with tabs to rename.
    new_tab_names : list[str]
        Names to assign to tabs in order; length must match tab count.
    output_mat : Path | None
        Output MAT path; defaults to "<stem>_renamed.mat".
    keep_temp : bool
        Keep temporary files.
    overwrite_input : bool, optional
        Whether to overwrite the input MAT file.

    Returns
    -------
    Path
        Path to the renamed MAT.
    """
    if mat_path.suffix.lower() != ".mat":
        mat_path = mat_path.with_suffix(".mat")
    if output_mat is None:
        output_mat = mat_path.with_name(f"{mat_path.stem}_renamed.mat")

    tab_count = len(new_tab_names)
    name_clause = ",".join(new_tab_names)

    script_lines = [
        f'RUN PGM=MATRIX PRNFILE="RenameTabs_{mat_path.stem}.PRN"',
        "; Outputs",
        f'FILEO MATO[1] = "{output_mat.resolve()}",',
        f"      MO=1-{tab_count},DEC={tab_count}*D,NAME={name_clause}",
        "; Inputs",
        f'FILEI MATI[1] = "{mat_path.resolve()}"',
        "; Process",
        "",
    ]
    for i in range(1, tab_count + 1):
        script_lines.append(f"MW[{i}] = MI.1.{i}")
    script_lines += ["", "ENDRUN"]

    _run_voyager(
        voyager_exe=voyager_exe,
        parent_dir=mat_path.parent,
        script_name=f"RenameTabs_{mat_path.stem}.S",
        script_lines=script_lines,
        keep_temp=keep_temp,
    )

    if not output_mat.is_file():
        raise RuntimeError(f"failed to rename tabs for {mat_path}")

    if overwrite_input:
        output_mat.replace(mat_path)
        
    return output_mat


def get_mat_stats(
    mat_file: Path,
    voyager_exe: Optional[Path] = None,
    precision: int = 5,
    data_group: str = "data",
    lookup_group: str = "lookup",
) -> pl.DataFrame:
    """Get stats from Cube .MAT or .OMX file.

    Parameters
    ----------
    mat_file : Path
        Path to Cube .MAT file or .OMX file
    voyager_exe : Optional[Path], optional
        Path to Cube Voyager executable, by default None
        Needed only if the file is .MAT
        and needs to be converted to .OMX
    precision : int, optional
        Number of decimal places to round the stats, by default 5
    data_group : str, optional
        Name of the HDF5 group that holds matrix CArrays, by default "data"
    lookup_group : str, optional
        Name of the HDF5 group that holds mapping arrays, by default "lookup"

    Returns
    -------
    stats_df: pl.DataFrame
        Stats from Cube .MAT file with statistics as columns and tabs as rows

    Examples
    --------
    >>> voyager_exe = Path("path/to/voyager.exe")
    >>> mat_file = Path("path/to/matrix.MAT")
    >>> stats_df = get_mat_stats(mat_file, voyager_exe)
    """
    # Ensure mat_file is Path
    mat_file = Path(mat_file)
    # Check if the file might be a .MAT file and ensure voyager_exe is provided
    if mat_file.suffix.upper() == ".MAT" or (
        mat_file.suffix == "" and Path(f"{mat_file}.MAT").exists()
    ):
        if voyager_exe is None:
            raise ValueError("voyager_exe must be provided for .MAT files")
    # If file has no extension, check for both .MAT and .OMX extensions
    if mat_file.suffix == "":
        mat_file_with_mat = mat_file.with_suffix(".MAT")
        mat_file_with_omx = mat_file.with_suffix(".OMX")

        if mat_file_with_mat.exists():
            mat_file = mat_file_with_mat
            mat_to_omx(
                voyager_exe=voyager_exe if voyager_exe is not None else Path(),
                mat_path=mat_file,
                omx_path=mat_file.with_suffix(".OMX"),
            )
        elif mat_file_with_omx.exists():
            mat_file = mat_file_with_omx
        else:
            raise ValueError(
                f"Neither .MAT nor .OMX file for {mat_file} exists. Please check the file path."
            )

    # Handle .MAT file
    elif mat_file.suffix.upper() == ".MAT":
        if not mat_file.exists():
            raise ValueError(
                f"MAT file {mat_file} does not exist. Please check the file path."
            )
        mat_to_omx(
            voyager_exe=voyager_exe if voyager_exe is not None else Path(),
            mat_path=mat_file,
            omx_path=mat_file.with_suffix(".OMX"),
        )

    # Handle .OMX file
    elif mat_file.suffix.upper() == ".OMX":
        if not mat_file.exists():
            raise ValueError(
                f"OMX file {mat_file} does not exist. Please check the file path."
            )

    # Handle case where the file extension is not .MAT or .OMX
    else:
        raise ValueError(
            f"File {mat_file} is not a .MAT or .OMX file. Please check the file path."
        )

    # Read omx
    with omx.open_file(mat_file.with_suffix(".OMX"), data_group=data_group, lookup_group=lookup_group) as file:
        tabs = file.list_matrices()
        stats: dict[str, dict[str, Any]] = {}
        for tab in tabs:
            matrix = np.array(file[tab][:])
            stats[tab] = {}
            stats[tab]["Shape"] = matrix.shape
            stats[tab]["Total"] = round(matrix.sum(), precision)
            stats[tab]["Intras."] = round(np.sum(np.diag(matrix)), precision)
            stats[tab]["Min."] = round(matrix.min(), precision)
            stats[tab]["Mean"] = round(matrix.mean(), precision)
            stats[tab]["Max."] = round(matrix.max(), precision)
            stats[tab]["Std."] = round(matrix.std(), precision)

            # Handle Min > 0, Max > 0, and Std. when there are no positive values
            positive_values = matrix[matrix > 0]
            if positive_values.size > 0:
                stats[tab]["Min > 0"] = round(positive_values.min(), precision)
                stats[tab]["Mean > 0"] = round(positive_values.mean(), precision)
                stats[tab]["Max > 0"] = round(positive_values.max(), precision)
                stats[tab]["Std. > 0"] = round(positive_values.std(), precision)
            else:
                stats[tab]["Min > 0"] = 0
                stats[tab]["Mean > 0"] = 0
                stats[tab]["Max > 0"] = 0
                stats[tab]["Std. > 0"] = 0

    # Create df
    # First, get all statistic names from the first tab
    stat_names = list(next(iter(stats.values())).keys())

    # Create a dictionary with statistics data
    df_data = {"tab": list(stats.keys())}
    for stat_name in stat_names:
        df_data[stat_name] = [stats[tab][stat_name] for tab in stats.keys()]

    # Create df with strict=False to allow mixed types
    stats_df = pl.DataFrame(df_data, strict=False)
    
    # Remove omx file if it was created from a .MAT file
    if mat_file.suffix.upper() == ".MAT":
        mat_file.with_suffix(".OMX").unlink(missing_ok=True)


    return stats_df


def read_mat_to_polars(
    voyager_exe: Path,
    mat_file: Path,
    o_col: str = "o",
    d_col: str = "d",
    limited_tabs: Optional[list[Any]] = None,
    stack: bool = False,
    clean_omx: bool = True,
    data_group: str = "data",
    lookup_group: str = "lookup",
) -> pl.DataFrame:
    """Read Cube .MAT file into polars dataframe.

    Conversion is done through OMX

    Parameters
    ----------
    voyager_exe : Path
        path to voyager executable
    mat_file : Path
        path to Cube matrix file
    o_col : str, optional
        name of origin/production vector header, by default "o"
    d_col : str, optional
        name of destination/attraction vector header, by default "d"
    limited_tabs : list, optional
        if only specific tabs are needed from the omx
    stack : bool, optional
        if stack then the matrices will be stacked in one vector with
        an additional vector referring to each mx tab
    clean_omx : bool, optional
        whether or not to remove the omx after being read, by default True
    data_group : str, optional
        name of the HDF5 group that holds matrix CArrays, by default "data"
    lookup_group : str, optional
        name of the HDF5 group that holds mapping arrays, by default "lookup"

    Returns
    -------
    matrix_df : pl.DataFrame
        matrix polars dataframe
    """
    # Create an empty list if limited_tabs is None
    tab_list = [] if limited_tabs is None else limited_tabs

    # convert mat to omx
    mat_to_omx(
        voyager_exe,
        mat_file,
        mat_file.parent / f"{mat_file.stem}.omx",
    )

    matrix_df = mx.read_omx_to_polars(
        omx_file_path=mat_file.parent / f"{mat_file.stem}.omx",
        o_col=o_col,
        d_col=d_col,
        limited_tabs=tab_list,
        stack=stack,
        clean_omx=clean_omx,
        data_group=data_group,
        lookup_group=lookup_group,
    )

    d_type_mapping = {
        o_col: pl.Int32,
        d_col: pl.Int32,
    }

    # Convert columns to the specified data types using the apply function
    for col, d_type in d_type_mapping.items():
        matrix_df = matrix_df.with_columns(matrix_df[col].cast(d_type))

    return matrix_df


def read_mat_to_array(
    voyager_exe: Path,
    mat_file: Path,
    limited_tabs: Optional[list] = None,
    clean_omx: bool = True,
    data_group: str = "data",
    lookup_group: str = "lookup",
) -> dict[Any, np.ndarray]:
    """Read .MAT into a dictionary of arrays

    Parameters
    ----------
    mat_file : Path
        matrix path
    voyager_exe : Path
        path to cube voyager executable
    limited_tabs : list[str], optional
        if only specific tabs are needed from the omx, by default None
        matrix tabs to read in
    clean_omx : bool, optional
       whether or not to remove the omx after being read, by default True
    data_group : str, optional
        name of the HDF5 group that holds matrix CArrays, by default "data"
    lookup_group : str, optional
        name of the HDF5 group that holds mapping arrays, by default "lookup"

    Returns
    -------
    array_dict: dict[Any : np.ndarray]
        dictionary of matrices in array format
    """
    if limited_tabs is None:
        limited_tabs = []  # Create a new list if it's None
    # convert mat to omx
    mat_to_omx(
        voyager_exe,
        mat_file,
        mat_file.parent / f"{mat_file.stem}.omx",
    )
    # create an empty dictionary
    array_dict: dict[Any, np.ndarray] = {}
    # open omx
    omx_path = mat_file.parent / f"{mat_file.stem}.omx"
    with omx.open_file(omx_path, data_group=data_group, lookup_group=lookup_group) as omx_mat:
        # get matrices
        if len(limited_tabs) == 0:
            tab_list = omx_mat.list_matrices()
        else:
            tab_list = limited_tabs

        for tab in tab_list:
            array_dict[tab] = np.array(omx_mat[tab])

    # if removing the omx is needed
    if clean_omx:
        omx_path.unlink()

    return array_dict


def copy_app_descriptions(
    source_path: str,
    target_path: str,
    out_path: Optional[str] = None,
    *,
    prefix: str = "",
    suffix: str = "",
    replace_map: Optional[dict[str, str]] = None,
    transform: Optional[Callable[[str], str]] = None,
    markers: Iterable[str] = ("INFIL", "OUTFIL"),
    programs: Optional[ProgramList] = None,
    program_map: Optional[ProgramMap] = None,
) -> tuple[int, int]:
    """Copy app description lines between Cube script files.

    This utility reads a source Cube script and copies the description line
    associated with matching file markers (e.g., ``#INFIL1``/``#OUTFIL2``)
    into a target script. The description line is assumed to appear two lines
    after the marker. Optional text edits can be applied to the copied text,
    and updates can be restricted or mapped between program numbers.

    Parameters
    ----------
    source_path : str
        Path to the source script file to read descriptions from.
    target_path : str
        Path to the target script file to update.
    out_path : str, optional
        Output path for the updated target. If None, overwrite ``target_path``.
    prefix : str, optional
        Text to prepend to each copied description.
    suffix : str, optional
        Text to append to each copied description.
    replace_map : dict[str, str], optional
        Mapping of text replacements applied to copied descriptions.
    transform : Callable[[str], str], optional
        Function applied to the copied description after prefix/suffix edits.
    markers : Iterable[str], optional
        Marker names to match (e.g., ``("INFIL", "OUTFIL")``).
    programs : ProgramList, optional
        Program numbers to copy; only updates matching program numbers.
        Mutually exclusive with ``program_map``.
    program_map : ProgramMap, optional
        Mapping of source program numbers to target program numbers.
        Mutually exclusive with ``programs``.

    Returns
    -------
    tuple[int, int]
        ``(updated, skipped)`` counts of description lines updated or skipped.

    Raises
    ------
    ValueError
        If both ``programs`` and ``program_map`` are provided.
    """
    marker_re = re.compile(r"^#(" + "|".join(markers) + r")(\d+)\s*$")
    program_re = re.compile(r"^#PROGRAM(\d+)\s*$")

    # Build mapping from source program -> target program(s)
    if programs is not None and program_map is not None:
        raise ValueError("Provide either programs or program_map, not both.")
    if programs is not None:
        prog_map: dict[int, set] = {p: {p} for p in programs}
    elif program_map is not None:
        prog_map = {}
        for src_p, tgt_p in program_map:
            prog_map.setdefault(src_p, set()).add(tgt_p)
    else:
        prog_map = {}  # empty means "all programs"

    def apply_edits(text: str) -> str:
        """Apply prefix/suffix, replacement map, and transform to text."""
        has_edits = bool(prefix or suffix or replace_map or transform)
        if not has_edits:
            return text
        if replace_map:
            for old, new in replace_map.items():
                text = text.replace(old, new)
        text = f"{prefix}{text}{suffix}"
        if transform:
            text = transform(text)
        return text

    with open(source_path, "r", encoding="utf-8") as f:
        src_lines = f.readlines()
    with open(target_path, "r", encoding="utf-8") as f:
        tgt_lines = f.readlines()

    # Map: (program, marker, index) -> description_line
    src_map: dict[tuple[int, str, int], str] = {}
    current_program = -1
    for i, line in enumerate(src_lines):
        m_prog = program_re.match(line.strip())
        if m_prog:
            current_program = int(m_prog.group(1))
            continue
        m = marker_re.match(line.strip())
        if not m:
            continue
        key = (current_program, m.group(1), int(m.group(2)))
        desc_idx = i + 2
        if 0 <= desc_idx < len(src_lines):
            src_map[key] = src_lines[desc_idx].rstrip("\r\n")

    updated = 0
    skipped = 0
    current_program = -1

    for i, line in enumerate(tgt_lines):
        m_prog = program_re.match(line.strip())
        if m_prog:
            current_program = int(m_prog.group(1))
            continue
        m = marker_re.match(line.strip())
        if not m:
            continue

        marker = m.group(1)
        idx = int(m.group(2))

        if prog_map:
            # Only update if current target program is mapped from some source program
            matched = False
            for src_prog, tgt_set in prog_map.items():
                if current_program in tgt_set:
                    key = (src_prog, marker, idx)
                    if key in src_map:
                        new_text = apply_edits(src_map[key])
                        desc_idx = i + 2
                        if 0 <= desc_idx < len(tgt_lines):
                            tgt_lines[desc_idx] = new_text + "\n"
                            updated += 1
                        else:
                            skipped += 1
                        matched = True
                        break
            if not matched:
                skipped += 1
            continue

        # Default: program number must match
        key = (current_program, marker, idx)
        desc_idx = i + 2
        if key in src_map and 0 <= desc_idx < len(tgt_lines):
            new_text = apply_edits(src_map[key])
            tgt_lines[desc_idx] = new_text + "\n"
            updated += 1
        else:
            skipped += 1

    out_file = out_path or target_path
    with open(out_file, "w", encoding="utf-8") as f:
        f.writelines(tgt_lines)

    return updated, skipped