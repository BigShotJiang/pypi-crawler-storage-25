"""
Module for parsing MATSim plans xml file.
"""

##### IMPORTS #####
from __future__ import annotations

# Standard imports
import math
import gzip
import logging
from concurrent.futures import ProcessPoolExecutor, as_completed
from os import PathLike
from pathlib import Path
from dataclasses import dataclass
from typing import Any, Literal, Optional, Union

# Third party imports
import polars as pl
from lxml import etree as ET  # type: ignore

# Local imports

##### CONSTANTS #####
# Only these tags are ever meaningful; all others are skipped immediately.
_KNOWN_TAGS: frozenset = frozenset(
    {"person", "plan", "activity", "leg", "route", "attributes", "attribute"}
)

_EMPTY_TABLE_SCHEMAS: dict[str, dict[str, list[Any]]] = {
    "persons": {"person_id": [], "selected_plan_indices": []},
    "person_attrs": {"person_id": []},
    "plans": {
        "person_id": [],
        "plan_index": [],
        "plan_uid": [],
        "score": [],
        "selected": [],
        "attributes": [],
    },
    "elements": {
        "person_id": [],
        "plan_index": [],
        "elem_index": [],
        "elem_type": [],
        "ref_index": [],
    },
    "activities": {
        "person_id": [],
        "plan_index": [],
        "act_index": [],
        "type": [],
        "x": [],
        "y": [],
        "link": [],
        "facility": [],
        "start_time": [],
        "end_time": [],
        "attributes": [],
    },
    "legs": {
        "person_id": [],
        "plan_index": [],
        "leg_index": [],
        "mode": [],
        "dep_time": [],
        "arr_time": [],
        "trav_time_min": [],
        "euclid_dist_m": [],
        "route_type": [],
        "route_start_link": [],
        "route_end_link": [],
        "route_trav_time": [],
        "route_distance_m": [],
        "route_links": [],
        "route_raw": [],
        "attributes": [],
    },
    "plan_summary": {
        "person_id": [],
        "plan_index": [],
        "plan_uid": [],
        "score": [],
        "selected": [],
        "activities": [],
        "modes": [],
        "points": [],
        "leg_times_min": [],
        "leg_euclid_dists_m": [],
        "leg_route_dists_m": [],
        "total_time_min": [],
        "total_euclid_dist_m": [],
        "total_route_dist_m": [],
    },
}

logger = logging.getLogger(__name__)


##### CLASSES #####
@dataclass
class _EagerParsedPlans:
    """
    Container for all normalised dataframes produced by ``parse_matsim_plans``.

    Each dataframe is a Polars DataFrame.  All dataframes share the composite key
    `(person_id, plan_index)` so they can be joined freely.

    When parsed from an iterations folder (via ``parse_matsim_iterations``), an extra
    ``iteration`` (int) column is prepended to every dataframe so results from
    multiple iterations can be stacked and distinguished.

    Attributes
    ----------
    persons : pl.DataFrame
        One row per person.  Columns: `person_id` (str),
        `selected_plan_indices` (list[int]).
    person_attrs : pl.DataFrame
        One row per person, one column per person-level attribute declared in
        the `<attributes>` block.  All attribute values are stored as strings;
        cast individual columns as needed.  Always contains `person_id`.
    plans : pl.DataFrame
        One row per plan.  Columns: `person_id`, `plan_index` (int),
        `plan_uid` (str, `"<person_id>#<plan_index>"`), `score` (float),
        `selected` (bool), `attributes` (dict or None).
    elements : pl.DataFrame
        Ordered sequence of activities and legs within each plan.  Columns:
        `person_id`, `plan_index`, `elem_index` (0-based position),
        `elem_type` (`"activity"` or `"leg"`), `ref_index` (index into
        the `activities` or `legs` table).
    activities : pl.DataFrame
        One row per activity.  Columns: `person_id`, `plan_index`,
        `act_index` (int), `type` (str), `x` (float), `y` (float),
        `link` (str), `facility` (str), `start_time` (`HH:MM:SS` str),
        `end_time` (`HH:MM:SS` str), `attributes` (dict or None).
    legs : pl.DataFrame
        One row per leg.  Columns: `person_id`, `plan_index`,
        `leg_index` (int), `mode` (str), `dep_time` (`HH:MM:SS` str),
        `arr_time` (`HH:MM:SS` str), `trav_time_min` (float),
        `euclid_dist_m` (float), `route_type` (str), `route_start_link`
        (str), `route_end_link` (str), `route_trav_time` (`HH:MM:SS`
        str), `route_distance_m` (float), `route_links` (list[str] or
        None), `route_raw` (str), `attributes` (dict or None).
    plan_summary : pl.DataFrame
        One row per plan with pre-aggregated travel statistics.  Columns:
        `person_id`, `plan_index`, `plan_uid`, `score`, `selected`,
        `activities` (list[str] of activity types), `modes` (list[str]),
        `points` (list[dict] of `{"x": float, "y": float}`),
        `leg_times_min` (list[float]), `leg_euclid_dists_m` (list[float]),
        `leg_route_dists_m` (list[float|None]), `total_time_min` (float),
        `total_euclid_dist_m` (float), `total_route_dist_m` (float).

    Methods
    -------
    travel_stats(plan_set) : pl.DataFrame
        Per-person travel statistics (n_trips, total_time_min,
        total_euclid_dist_m, total_route_dist_m, avg_speed_kmh) averaged
        over the chosen plan set.
    travel_stats_by(attr_name, agg, plan_set) : pl.DataFrame
        Same statistics grouped by a person attribute.
    plan_logsum(lambda_scale, plan_set) : pl.DataFrame
        Per-person logsum (inclusive value) over plan utilities.
    logsum_by(attr_name, agg, lambda_scale, plan_set) : pl.DataFrame
        Logsum aggregated by a person attribute.
    persons_wide() : pl.DataFrame
        ``persons`` left-joined to all person attribute columns.
    """

    persons: pl.DataFrame
    person_attrs: pl.DataFrame
    plans: pl.DataFrame
    elements: pl.DataFrame
    activities: pl.DataFrame
    legs: pl.DataFrame
    plan_summary: pl.DataFrame

    def _plans_for_logsum(
        self, plan_set: Literal["all", "selected", "best", "average"]
    ) -> pl.DataFrame:
        """
        Return the subset of `self.plans` to use for logsum computation.

        Parameters
        ----------
        plan_set : {"all", "selected", "best", "average"}
            Which plans to include:

            * `"all"`      : every plan for each person.
            * `"selected"` : only plans where `selected` is `True`
              (i.e. the executed plan at the stored iteration).
            * `"best"`     : only the highest-score plan per person
              (ties broken by ascending `plan_index`).
            * `"average"` : a single synthetic plan per person whose
              score is the mean of all plan scores (null scores
              excluded from the average).

        Returns
        -------
        pl.DataFrame
            Filtered (or full) `plans` DataFrame.

        Raises
        ------
        ValueError
            If `plan_set` is not one of the accepted values.
        """
        if plan_set == "all":
            return self.plans
        if plan_set == "selected":
            return self.plans.filter(pl.col("selected"))
        if plan_set == "best":
            return (
                self.plans.sort(
                    by=["person_id", "score", "plan_index"],
                    descending=[False, True, False],
                    nulls_last=True,
                )
                .group_by("person_id")
                .head(1)
            )
        if plan_set == "average":
            return self.plans.group_by("person_id").agg(pl.col("score").mean())
        raise ValueError(
            "plan_set must be one of: 'all', 'selected', 'best', 'average'"
        )

    def plan_logsum(
        self,
        lambda_scale: float = 1.0,
        plan_set: Literal["all", "selected", "best", "average"] = "all",
    ) -> pl.DataFrame:
        """
        Compute the per-person inclusive value (logsum) over plan utilities.

        Uses the standard discrete-choice logsum formula:

        .. math::

            IV_i = \\frac{1}{\\lambda} \\ln\\left(\\sum_{j} e^{\\lambda V_{ij}}\\right)

        where :math:`V_{ij}` is the utility (`score`) of plan *j* for
        person *i* and :math:`\\lambda` is the scale parameter.
        Plans with a null score are excluded from the exponential sum;
        persons where *all* scores are null receive a null logsum.

        Parameters
        ----------
        lambda_scale : float, default 1.0
            Scale parameter :math:`\\lambda`.  Must be non-zero.
        plan_set : {"all", "selected", "best", "average"}, default "all"
            Which plans to include per person before computing the logsum:

            * `"all"`      : every stored plan.
            * `"selected"` : only plans marked as selected/executed.
            * `"best"`     : only the plan with the highest score.
            * `"average"` : a single synthetic plan whose score is the
              mean of all plan scores (equivalent to returning the
              average score directly as the logsum value).

        Returns
        -------
        pl.DataFrame
            Columns: `person_id` (str), `logsum` (float),
            `n_plans` (int, count of plans in the chosen set).

        Raises
        ------
        ValueError
            If `lambda_scale` is 0.
        """
        if lambda_scale == 0:
            raise ValueError("lambda_scale must be non-zero")

        plans = self._plans_for_logsum(plan_set)

        return plans.group_by("person_id").agg(
            pl.when(pl.col("score").is_not_null().any())
            .then(
                (pl.col("score").drop_nulls() * lambda_scale).exp().sum().log(math.e)
                / lambda_scale
            )
            .otherwise(None)
            .alias("logsum"),
            pl.len().alias("n_plans"),
        )

    def logsum_by(
        self,
        attr_name: str,
        agg: str = "mean",
        lambda_scale: float = 1.0,
        plan_set: Literal["all", "selected", "best", "average"] = "all",
    ) -> pl.DataFrame:
        """
        Aggregate per-person logsum values grouped by a person attribute.

        Computes ``plan_logsum`` for every person, then joins to
        ``person_attrs`` and groups by the requested attribute column.
        If the attribute is absent from ``person_attrs`` the attribute
        column is filled with ``None`` so the result still contains all
        persons.

        Parameters
        ----------
        attr_name : str
            Name of the `person_attrs` column to group by
            (e.g. `"subpopulation"`, `"income_group"`).
        agg : {"mean", "sum", "median"}, default "mean"
            Aggregation function applied to logsum values within each
            group.  Any unrecognised value falls back to `"mean"`.
        lambda_scale : float, default 1.0
            Scale parameter :math:`\\lambda` passed through to
            ``plan_logsum``.
        plan_set : {"all", "selected", "best", "average"}, default "all"
            Which plans to include per person before computing the logsum.

        Returns
        -------
        pl.DataFrame
            Columns: ``<attr_name>`` (str), ``logsum`` (float),
            ``n_persons`` (int).  Sorted ascending by ``<attr_name>``.

        Examples
        --------
        >>> parsed.logsum_by("subpopulation")
        >>> parsed.logsum_by("income_group", agg="sum", lambda_scale=0.5)
        """
        ls = self.plan_logsum(
            lambda_scale=lambda_scale,
            plan_set=plan_set,
        ).select(["person_id", "logsum"])

        if self.person_attrs.is_empty() or attr_name not in self.person_attrs.columns:
            attr = self.persons.select("person_id").with_columns(
                pl.lit(None).alias(attr_name)
            )
        else:
            attr = self.person_attrs.select(["person_id", pl.col(attr_name)])

        agg_map = {
            "mean": pl.col("logsum").mean(),
            "sum": pl.col("logsum").sum(),
            "median": pl.col("logsum").median(),
        }
        return (
            ls.join(attr, on="person_id", how="left")
            .group_by(attr_name)
            .agg(
                agg_map.get(agg, pl.col("logsum").mean()).alias("logsum"),
                pl.col("person_id").count().alias("n_persons"),
            )
            .sort(attr_name)
        )

    def persons_wide(self) -> pl.DataFrame:
        """
        Return `persons` left-joined to all person attribute columns.

        Equivalent to ``persons.join(person_attrs, on="person_id", how="left")``
        but handles the case where ``person_attrs`` is empty.
        Attribute values are stored as strings; cast individual columns as
        needed.  Useful for exploration and for building custom segmentations.

        Returns
        -------
        pl.DataFrame
            One row per person with ``person_id``, ``selected_plan_indices``,
            and one additional column per person attribute.  Persons with no
            recorded attributes still appear (attribute columns are ``None``).
        """
        if self.person_attrs.is_empty():
            return self.persons
        return self.persons.join(self.person_attrs, on="person_id", how="left")

    def travel_stats(
        self,
        plan_set: Literal["all", "selected", "best", "average"] = "selected",
    ) -> pl.DataFrame:
        """
        Compute per-person travel statistics aggregated over the chosen plan set.

        For single-plan selectors (``"selected"``, ``"best"``) this returns
        the statistics for that one plan.  For ``"all"`` and ``"average"``
        the statistics are averaged across all plans for each person.

        Parameters
        ----------
        plan_set : {"all", "selected", "best", "average"}, default "selected"
            Which plans to include per person:

            * ``"all"``      — average statistics across every stored plan.
            * ``"selected"`` — statistics for the executed/selected plan only.
            * ``"best"``     — statistics for the highest-score plan only.
            * ``"average"``  — same as ``"all"`` (averages across all plans).

        Returns
        -------
        pl.DataFrame
            One row per person.  Columns:

            * ``person_id`` (str)
            * ``n_trips`` (float) — mean number of legs in the plan(s).
            * ``total_time_min`` (float) — mean total in-vehicle/travel time
              across legs, in minutes.
            * ``total_euclid_dist_m`` (float) — mean sum of straight-line
              distances between consecutive activity locations, in metres.
            * ``total_route_dist_m`` (float or None) — mean sum of route
              distances reported in the XML, in metres.  ``None`` when no
              route distance is available.
            * ``avg_speed_kmh`` (float or None) — derived from
              ``total_route_dist_m / total_time_min``; ``None`` when either
              component is unavailable.
            * ``n_plans`` (int) — number of plans that entered the average.

        Examples
        --------
        >>> parsed.travel_stats()                          # selected plan
        >>> parsed.travel_stats(plan_set="all")            # mean across all plans
        >>> parsed.travel_stats(plan_set="best")           # best-score plan
        """
        # "average" has no plan_index in _plans_for_logsum; treat like "all"
        if plan_set in ("average", "all"):
            plan_keys = self.plans.select(["person_id", "plan_index"])
        else:
            plan_keys = self._plans_for_logsum(plan_set).select(
                ["person_id", "plan_index"]
            )

        summary = self.plan_summary.with_columns(
            pl.col("leg_times_min").list.len().alias("n_trips")
        )

        return (
            plan_keys.join(summary, on=["person_id", "plan_index"], how="left")
            .group_by("person_id")
            .agg(
                pl.col("n_trips").mean(),
                pl.col("total_time_min").mean(),
                pl.col("total_euclid_dist_m").mean(),
                pl.col("total_route_dist_m").mean(),
                pl.len().alias("n_plans"),
            )
            .with_columns(
                pl.when(
                    pl.col("total_route_dist_m").is_not_null()
                    & (pl.col("total_time_min") > 0)
                )
                .then(
                    pl.col("total_route_dist_m")
                    / 1000.0
                    / (pl.col("total_time_min") / 60.0)
                )
                .otherwise(None)
                .alias("avg_speed_kmh"),
            )
        )

    def travel_stats_by(
        self,
        attr_name: str,
        agg: str = "mean",
        plan_set: Literal["all", "selected", "best", "average"] = "selected",
    ) -> pl.DataFrame:
        """
        Aggregate per-person travel statistics grouped by a person attribute.

        Computes ``travel_stats`` for every person, then joins to
        ``person_attrs`` and groups by the requested attribute column.
        If the attribute is absent from ``person_attrs`` the attribute
        column is filled with ``None`` so the result still contains all
        persons.

        Parameters
        ----------
        attr_name : str
            Name of the ``person_attrs`` column to group by
            (e.g. ``"subpopulation"``, ``"income_group"``).
        agg : {"mean", "sum", "median"}, default "mean"
            Aggregation function applied to each statistic within each
            group.  Unrecognised values fall back to ``"mean"``.
        plan_set : {"all", "selected", "best", "average"}, default "selected"
            Which plans to include per person before computing statistics.

        Returns
        -------
        pl.DataFrame
            Columns: ``<attr_name>`` (str), ``n_trips`` (float),
            ``total_time_min`` (float), ``total_euclid_dist_m`` (float),
            ``total_route_dist_m`` (float), ``avg_speed_kmh`` (float),
            ``n_persons`` (int).  Sorted ascending by ``<attr_name>``.

        Examples
        --------
        >>> parsed.travel_stats_by("subpopulation")
        >>> parsed.travel_stats_by("income_group", agg="median", plan_set="all")
        """
        stat_cols = [
            "n_trips",
            "total_time_min",
            "total_euclid_dist_m",
            "total_route_dist_m",
            "avg_speed_kmh",
        ]
        stats = self.travel_stats(plan_set=plan_set).select(["person_id"] + stat_cols)

        if self.person_attrs.is_empty() or attr_name not in self.person_attrs.columns:
            attr = self.persons.select("person_id").with_columns(
                pl.lit(None).alias(attr_name)
            )
        else:
            attr = self.person_attrs.select(["person_id", pl.col(attr_name)])

        agg_fn = agg if agg in ("mean", "sum", "median") else "mean"

        return (
            stats.join(attr, on="person_id", how="left")
            .group_by(attr_name)
            .agg(
                *[getattr(pl.col(c), agg_fn)().alias(c) for c in stat_cols],
                pl.col("person_id").count().alias("n_persons"),
            )
            .sort(attr_name)
        )


class LazyParsedPlans:
    """
    Lazy MATSim plans container backed by native payload columns.

    DataFrames are created only when a table property is accessed.
    """

    def __init__(self, payload: dict[str, Any]):
        self._payload = payload
        self._df_cache: dict[str, pl.DataFrame] = {}

    def _df(self, key: str) -> pl.DataFrame:
        if key not in self._df_cache:
            self._df_cache[key] = _coerce_native_dataframe(
                self._payload,
                key,
                _EMPTY_TABLE_SCHEMAS[key],
            )
        return self._df_cache[key]

    @property
    def persons(self) -> pl.DataFrame:
        return self._df("persons")

    @property
    def person_attrs(self) -> pl.DataFrame:
        return self._df("person_attrs")

    @property
    def plans(self) -> pl.DataFrame:
        return self._df("plans")

    @property
    def elements(self) -> pl.DataFrame:
        return self._df("elements")

    @property
    def activities(self) -> pl.DataFrame:
        return self._df("activities")

    @property
    def legs(self) -> pl.DataFrame:
        return self._df("legs")

    @property
    def plan_summary(self) -> pl.DataFrame:
        return self._df("plan_summary")

    def to_parsed_plans(self) -> _EagerParsedPlans:
        return _EagerParsedPlans(
            persons=self.persons,
            person_attrs=self.person_attrs,
            plans=self.plans,
            elements=self.elements,
            activities=self.activities,
            legs=self.legs,
            plan_summary=self.plan_summary,
        )

    def _plans_for_logsum(
        self, plan_set: Literal["all", "selected", "best", "average"]
    ) -> pl.DataFrame:
        if plan_set == "all":
            return self.plans
        if plan_set == "selected":
            return self.plans.filter(pl.col("selected"))
        if plan_set == "best":
            return (
                self.plans.sort(
                    by=["person_id", "score", "plan_index"],
                    descending=[False, True, False],
                    nulls_last=True,
                )
                .group_by("person_id")
                .head(1)
            )
        if plan_set == "average":
            return self.plans.group_by("person_id").agg(pl.col("score").mean())
        raise ValueError(
            "plan_set must be one of: 'all', 'selected', 'best', 'average'"
        )

    def plan_logsum(
        self,
        lambda_scale: float = 1.0,
        plan_set: Literal["all", "selected", "best", "average"] = "all",
    ) -> pl.DataFrame:
        if lambda_scale == 0:
            raise ValueError("lambda_scale must be non-zero")

        plans = self._plans_for_logsum(plan_set)
        return plans.group_by("person_id").agg(
            pl.when(pl.col("score").is_not_null().any())
            .then(
                (pl.col("score").drop_nulls() * lambda_scale).exp().sum().log(math.e)
                / lambda_scale
            )
            .otherwise(None)
            .alias("logsum"),
            pl.len().alias("n_plans"),
        )

    def logsum_by(
        self,
        attr_name: str,
        agg: str = "mean",
        lambda_scale: float = 1.0,
        plan_set: Literal["all", "selected", "best", "average"] = "all",
    ) -> pl.DataFrame:
        ls = self.plan_logsum(
            lambda_scale=lambda_scale,
            plan_set=plan_set,
        ).select(["person_id", "logsum"])

        if self.person_attrs.is_empty() or attr_name not in self.person_attrs.columns:
            attr = self.persons.select("person_id").with_columns(
                pl.lit(None).alias(attr_name)
            )
        else:
            attr = self.person_attrs.select(["person_id", pl.col(attr_name)])

        agg_map = {
            "mean": pl.col("logsum").mean(),
            "sum": pl.col("logsum").sum(),
            "median": pl.col("logsum").median(),
        }
        return (
            ls.join(attr, on="person_id", how="left")
            .group_by(attr_name)
            .agg(
                agg_map.get(agg, pl.col("logsum").mean()).alias("logsum"),
                pl.col("person_id").count().alias("n_persons"),
            )
            .sort(attr_name)
        )

    def persons_wide(self) -> pl.DataFrame:
        if self.person_attrs.is_empty():
            return self.persons
        return self.persons.join(self.person_attrs, on="person_id", how="left")

    def travel_stats(
        self,
        plan_set: Literal["all", "selected", "best", "average"] = "selected",
    ) -> pl.DataFrame:
        if plan_set in ("average", "all"):
            plan_keys = self.plans.select(["person_id", "plan_index"])
        else:
            plan_keys = self._plans_for_logsum(plan_set).select(
                ["person_id", "plan_index"]
            )

        summary = self.plan_summary.with_columns(
            pl.col("leg_times_min").list.len().alias("n_trips")
        )

        return (
            plan_keys.join(summary, on=["person_id", "plan_index"], how="left")
            .group_by("person_id")
            .agg(
                pl.col("n_trips").mean(),
                pl.col("total_time_min").mean(),
                pl.col("total_euclid_dist_m").mean(),
                pl.col("total_route_dist_m").mean(),
                pl.len().alias("n_plans"),
            )
            .with_columns(
                pl.when(
                    pl.col("total_route_dist_m").is_not_null()
                    & (pl.col("total_time_min") > 0)
                )
                .then(
                    pl.col("total_route_dist_m")
                    / 1000.0
                    / (pl.col("total_time_min") / 60.0)
                )
                .otherwise(None)
                .alias("avg_speed_kmh"),
            )
        )

    def travel_stats_by(
        self,
        attr_name: str,
        agg: str = "mean",
        plan_set: Literal["all", "selected", "best", "average"] = "selected",
    ) -> pl.DataFrame:
        stat_cols = [
            "n_trips",
            "total_time_min",
            "total_euclid_dist_m",
            "total_route_dist_m",
            "avg_speed_kmh",
        ]
        stats = self.travel_stats(plan_set=plan_set).select(["person_id"] + stat_cols)

        if self.person_attrs.is_empty() or attr_name not in self.person_attrs.columns:
            attr = self.persons.select("person_id").with_columns(
                pl.lit(None).alias(attr_name)
            )
        else:
            attr = self.person_attrs.select(["person_id", pl.col(attr_name)])

        agg_fn = agg if agg in ("mean", "sum", "median") else "mean"

        return (
            stats.join(attr, on="person_id", how="left")
            .group_by(attr_name)
            .agg(
                *[getattr(pl.col(c), agg_fn)().alias(c) for c in stat_cols],
                pl.col("person_id").count().alias("n_persons"),
            )
            .sort(attr_name)
        )


# Default parser contract: ParsedPlans now uses the lazy implementation.
class ParsedPlans(LazyParsedPlans):
    pass


##### FUNCTIONS #####
def _open_xml_source(path: str | PathLike[str]):
    """
    Return a context manager yielding a binary file-like object for *path*.

    Transparently handles both plain ``.xml`` files and gzip-compressed
    ``.xml.gz`` files.  Detection is based on the file extension (case-
    insensitive).

    Parameters
    ----------
    path : str or PathLike[str]
        Path to the XML source file.

    Returns
    -------
    context manager
        Yields a binary-mode file object suitable for ``lxml.etree.iterparse``.

    Raises
    ------
    OSError
        If the file cannot be opened.
    """

    class _Ctx:
        """
        Internal context manager that opens and closes the file handle.

        Parameters
        ----------
        p : str or PathLike[str]
            Path to the XML source file.
        """

        def __init__(self, p: str | PathLike[str]):
            self.p = p
            self.f = None

        def __enter__(self):
            """
            Open the file and return the file object.

            Returns
            -------
            file object
                Binary-mode file handle (plain or gzip-decompressed).
            """
            path_str = str(self.p)
            if path_str.lower().endswith(".gz"):
                self.f = gzip.open(self.p, "rb")
            else:
                self.f = open(self.p, "rb")
            return self.f

        def __exit__(self, exc_type, exc, tb):
            """
            Close the file handle, suppressing any close-time errors.

            Parameters
            ----------
            exc_type : type or None
                Exception type, if an exception occurred.
            exc : BaseException or None
                Exception instance.
            tb : traceback or None
                Traceback object.
            """
            try:
                if self.f is not None:
                    self.f.close()
            finally:
                self.f = None

    return _Ctx(path)


def _parse_time_to_seconds(s: Optional[str]) -> Optional[int]:
    """
    Parse a MATSim time string to a total number of seconds.

    Accepts either ``HH:MM:SS`` format or a bare integer/float string
    representing seconds.

    Parameters
    ----------
    s : str or None
        Time string to parse.  Returns ``None`` for empty or ``None`` input.

    Returns
    -------
    int or None
        Total seconds, or ``None`` if the input is empty or unparsable.
    """
    if not s:
        return None
    t = s.strip()
    try:
        if ":" in t:
            hh, mm, ss = t.split(":")
            return int(hh) * 3600 + int(mm) * 60 + int(ss)
        return int(float(t))
    except Exception:
        return None


def _normalise_hms(s: Optional[str]) -> Optional[str]:
    """
    Normalise a MATSim time value to ``"HH:MM:SS"`` string format.

    Takes the fast path (zero parsing) when the value already contains a
    colon — the overwhelmingly common case in MATSim output(?).  Falls back to
    parsing as a pure-seconds integer for the rare alternative representation.

    Parameters
    ----------
    s : str or None
        Raw time string from an XML attribute, or ``None``.

    Returns
    -------
    str or None
        Time formatted as ``"HH:MM:SS"``, or ``None`` if *s* is empty/``None``.
        Values that cannot be parsed are returned unchanged.
    """
    if not s:
        return None
    t = s.strip()
    if ":" in t:
        return t  # already HH:MM:SS — zero extra work
    # Pure-seconds integer fallback
    try:
        total = int(float(t))
        hh, rem = divmod(total, 3600)
        mm, sec = divmod(rem, 60)
        return f"{hh:02d}:{mm:02d}:{sec:02d}"
    except Exception:
        return t


def _cast_attr_value(java_class: Optional[str], text: Optional[str]) -> Any:
    """
    Convert a MATSim XML attribute text value to an appropriate Python type.

    Uses the ``class`` attribute of ``<attribute>`` elements (the Java class
    name) to determine the target type.  Falls back to heuristic type
    inference (bool → float → int → str) when no class hint is available.

    Parameters
    ----------
    java_class : str or None
        Value of the ``class`` XML attribute, e.g.
        ``"java.lang.Integer"`` or ``"java.lang.Double"``.  May be ``None``.
    text : str or None
        Raw text content of the ``<attribute>`` element.

    Returns
    -------
    int, float, bool, str, or None
        Typed value, or ``None`` if *text* is ``None``.
    """
    if text is None:
        return None
    t = text.strip()
    if java_class:
        jc = java_class.rsplit(".", 1)[-1].lower()
        if jc in ("integer", "int", "long"):
            try:
                return int(t)
            except Exception:
                return t
        if jc in ("double", "float", "bigdecimal"):
            try:
                return float(t)
            except Exception:
                return t
        if jc in ("boolean",):
            return t.lower() in ("true", "1", "yes")
        return t
    if t.lower() in ("true", "false"):
        return t.lower() == "true"
    try:
        if "." in t:
            return float(t)
        return int(t)
    except Exception:
        return t


def _euclidean(p1, p2) -> float:
    """
    Compute the Euclidean distance between two 2-D points.

    Parameters
    ----------
    p1 : tuple[float, float]
        ``(x, y)`` coordinates of the first point.
    p2 : tuple[float, float]
        ``(x, y)`` coordinates of the second point.

    Returns
    -------
    float
        Straight-line distance in the same units as the input coordinates
        (typically metres for MATSim projected coordinate systems).
    """
    return math.hypot(p2[0] - p1[0], p2[1] - p1[1])


def _resolve_plans_file(
    iteration_dir: Path, scenario: str, iteration_number: int
) -> Path:
    """
    Locate the plans file inside a single iteration directory.

    Tries the known filename stems in order (``<scenario>.plans.xml.gz``
    first, then ``<scenario>.plans.xml``).  Falls back to scanning the
    directory for any file matching ``*.plans.xml.gz`` or ``*.plans.xml``.

    Parameters
    ----------
    iteration_dir : Path
        Directory for a single iteration (e.g. ``…/it.42``).
    scenario : str
        Scenario name used to build the expected filename
        (e.g. ``"kelheim-v3.1-25pct"``).

    Returns
    -------
    Path
        Resolved path to the plans file.

    Raises
    ------
    FileNotFoundError
        If no plans file can be found in *iteration_dir*.
    """
    # Try the exact names derived from the scenario
    for suffix in (f"{iteration_number}.plans.xml.gz", f"{iteration_number}.plans.xml"):
        candidate = iteration_dir / (scenario + suffix)
        if candidate.exists():
            return candidate

    # Fall back: scan for any plans file (gz preferred)
    for suffix in (".plans.xml.gz", ".plans.xml"):
        found = sorted(iteration_dir.glob(f"*{suffix}"))
        if found:
            return found[0]

    raise FileNotFoundError(
        f"No plans file found in {iteration_dir} for scenario '{scenario}'"
    )


def _coerce_native_dataframe(
    payload: Any, key: str, empty_schema: dict[str, list[Any]]
) -> pl.DataFrame:
    """
    Coerce a native payload entry into a Polars DataFrame.

    Parameters
    ----------
    payload : Any
        Native parser payload object.
    key : str
        Payload key expected to hold one table.
    empty_schema : dict[str, list[Any]]
        Empty schema fallback for this table.

    Returns
    -------
    pl.DataFrame
        Parsed dataframe for ``key``.

    Raises
    ------
    TypeError
        If the payload entry cannot be converted to a dataframe.
    """
    if not isinstance(payload, dict) or key not in payload or payload[key] is None:
        return pl.DataFrame(empty_schema)

    value = payload[key]
    if isinstance(value, pl.DataFrame):
        return value
    if isinstance(value, dict):
        return pl.DataFrame(value)
    if isinstance(value, (list, tuple)):
        return pl.DataFrame(value)

    raise TypeError(
        f"Native payload field '{key}' has unsupported type: {type(value)!r}"
    )


def _discover_iteration_dirs(iterations_root: Path) -> list[tuple[int, Path]]:
    """
    Find all ``it.<N>`` sub-directories under *iterations_root*.

    Parameters
    ----------
    iterations_root : Path
        Root folder that contains ``it.0``, ``it.1``, … sub-directories.

    Returns
    -------
    list of (iteration_number, Path)
        Sorted ascending by iteration number.

    Raises
    ------
    FileNotFoundError
        If no ``it.*`` directories are found.
    """
    found: list[tuple[int, Path]] = []
    for child in iterations_root.iterdir():
        if child.is_dir() and child.name.startswith("it."):
            try:
                n = int(child.name[3:])
                found.append((n, child))
            except ValueError:
                pass  # Ignore malformed names like "it.abc"

    if not found:
        raise FileNotFoundError(
            f"No 'it.<N>' iteration directories found under {iterations_root}"
        )
    return sorted(found, key=lambda x: x[0])


def _select_iterations(
    all_iterations: list[tuple[int, Path]],
    iterations: Union[Literal["all", "last"], int, list[int]],
) -> list[tuple[int, Path]]:
    """
    Filter *all_iterations* according to the *iterations* selector.

    Parameters
    ----------
    all_iterations : list of (int, Path)
        Sorted list from ``_discover_iteration_dirs``.
    iterations : "all" | "last" | int | list[int]
        Which iterations to keep:

        * ``"all"``    – return every discovered iteration.
        * ``"last"``   – return only the highest-numbered iteration.
        * ``int``      – return the single iteration with that number.
        * ``list[int]``– return the iterations with those numbers
          (order follows *all_iterations*, not the list order).

    Returns
    -------
    list of (int, Path)
        Filtered, sorted subset.

    Raises
    ------
    ValueError
        If a requested iteration number is not found.
    """
    if iterations == "all":
        return all_iterations

    if iterations == "last":
        return [all_iterations[-1]]

    # Normalise to a set of ints
    if isinstance(iterations, int):
        requested = {iterations}
    else:
        requested = set(iterations)

    available = {n: p for n, p in all_iterations}
    missing = requested - available.keys()
    if missing:
        raise ValueError(
            f"Requested iteration(s) not found: {sorted(missing)}. "
            f"Available: {sorted(available.keys())}"
        )

    return [(n, available[n]) for n in sorted(requested)]


def _parse_iteration_worker(args: tuple[int, Path, str]) -> tuple[int, ParsedPlans]:
    """
    Parse a single iteration and return ``(iteration_number, ParsedPlans)``.

    Designed to be called from a ``ProcessPoolExecutor``.

    Parameters
    ----------
    args : (iteration_number, iteration_dir, scenario)
        Packed arguments for the worker.

    Returns
    -------
    tuple[int, ParsedPlans]
        The iteration number together with the parsed result.
    """
    iteration_number, iteration_dir, scenario = args
    plans_file = _resolve_plans_file(iteration_dir, scenario, iteration_number)
    logger.debug("Parsing iteration %d from %s", iteration_number, plans_file)
    result = parse_matsim_plans(plans_file)
    return iteration_number, result


def parse_matsim_iterations(
    iterations_folder: str | PathLike[str],
    scenario: str,
    iterations: Union[Literal["all", "last"], int, list[int]] = "last",
    max_workers: Optional[int] = None,
) -> dict[int, ParsedPlans]:
    """
    Parse MATSim plans files from an iterations folder.

    Discovers all ``it.<N>`` sub-directories under *iterations_folder*, selects
    the requested subset, and parses each one.  When more than one iteration is
    requested the parsing runs concurrently using a ``ProcessPoolExecutor`` so
    that multiple CPU cores can decompress and parse simultaneously.

    Memory notes
    ------------
    Each worker process parses one iteration independently and returns a
    ``ParsedPlans`` object (a set of Polars DataFrames).  The results are
    collected into a dict keyed by iteration number; no single in-memory
    accumulator holds data from all iterations at once.  Polars DataFrames use
    columnar Arrow memory, so the per-row overhead is low compared to
    row-oriented structures.

    Parameters
    ----------
    iterations_folder : str or PathLike[str]
        Path to the folder that contains ``it.0``, ``it.1``, … sub-directories.
    scenario : str
        Scenario stem used to locate the plans file inside each iteration
        directory (e.g. ``"kelheim-v3.1-25pct"``).  The parser will look
        for ``<scenario>.plans.xml.gz`` and ``<scenario>.plans.xml`` in that
        order, then fall back to scanning for any ``*.plans.xml.gz`` /
        ``*.plans.xml`` file.
    iterations : "all" | "last" | int | list[int], default "last"
        Which iterations to parse:

        * ``"all"``    - every ``it.<N>`` directory found.
        * ``"last"``   - only the highest-numbered iteration (default).
        * ``int``      - a single iteration by number.
        * ``list[int]``- an explicit list of iteration numbers.
    max_workers : int or None, default None
        Maximum number of worker processes for concurrent parsing.
        ``None`` lets ``ProcessPoolExecutor`` choose (typically one per CPU
        core).  Pass ``1`` to force sequential execution (useful for
        debugging or when memory is very tight).

    Returns
    -------
    dict[int, ParsedPlans]
        Mapping from iteration number to its ``ParsedPlans`` result,
        sorted ascending by iteration number.

    Raises
    ------
    FileNotFoundError
        If *iterations_folder* does not exist, contains no ``it.*``
        directories, or a plans file cannot be found for a given iteration.
    ValueError
        If a requested iteration number is not present.

    Examples
    --------
    Parse only the final iteration (default):

    >>> results = parse_matsim_iterations("/path/to/ITERS", "kelheim-v3.1-25pct")
    >>> last = results[max(results)]

    Parse all iterations concurrently:

    >>> all_results = parse_matsim_iterations(
    ...     "/path/to/ITERS",
    ...     "kelheim-v3.1-25pct",
    ...     iterations="all",
    ... )

    Parse a specific subset of iterations sequentially:

    >>> subset = parse_matsim_iterations(
    ...     "/path/to/ITERS",
    ...     "kelheim-v3.1-25pct",
    ...     iterations=[0, 50, 100, 150, 200],
    ...     max_workers=1,
    ... )
    """
    root = Path(iterations_folder)
    if not root.exists():
        raise FileNotFoundError(f"iterations_folder does not exist: {root}")

    all_iters = _discover_iteration_dirs(root)
    selected = _select_iterations(all_iters, iterations)

    logger.info(
        "Parsing %d iteration(s): %s",
        len(selected),
        [n for n, _ in selected],
    )

    results: dict[int, ParsedPlans] = {}

    if len(selected) == 1 or max_workers == 1:
        # Sequential path — avoids process-spawn overhead for single iterations
        # and makes debugging much easier.
        for n, it_dir in selected:
            _, parsed = _parse_iteration_worker((n, it_dir, scenario))
            results[n] = parsed
    else:
        work_items = [(n, it_dir, scenario) for n, it_dir in selected]
        with ProcessPoolExecutor(max_workers=max_workers) as pool:
            futures = {
                pool.submit(_parse_iteration_worker, item): item[0]
                for item in work_items
            }
            for future in as_completed(futures):
                n = futures[future]
                try:
                    _, parsed = future.result()
                    results[n] = parsed
                    logger.debug("Completed iteration %d", n)
                except Exception as exc:
                    logger.error("Iteration %d failed: %s", n, exc)
                    raise

    return dict(sorted(results.items()))


def parse_matsim_plans(path: str | PathLike[str]) -> ParsedPlans:
    """
    Stream-parse a MATSim plans file into a set of normalised Polars dataframes.

    Reads ``.xml`` and ``.xml.gz`` formats.  Uses ``lxml.etree.iterparse``
    for constant-memory streaming so that very large files (millions of
    persons) can be processed without loading the entire DOM.

    Columnar storage (one Python list per column) is used during parsing
    to minimise allocations.

    Parameters
    ----------
    path : str or PathLike[str]
        Path to the MATSim plans XML file, optionally gzip-compressed
        (detected by a ``.gz`` extension).

    Returns
    -------
    ParsedPlans
        Lazy container over parsed columnar payloads. Tables are materialised
        to Polars DataFrames only when accessed.

        * **persons** : ``(person_id, selected_plan_indices)``
        * **person_attrs** : ``(person_id, <one column per attribute>)``
        * **plans** : ``(person_id, plan_index, plan_uid, score, selected,
          attributes)``
        * **elements** : ``(person_id, plan_index, elem_index, elem_type,
          ref_index)`` — ordered activity/leg sequence within each plan
        * **activities** : ``(person_id, plan_index, act_index, type, x, y,
          link, facility, start_time, end_time, attributes)``
        * **legs** : ``(person_id, plan_index, leg_index, mode, dep_time,
          arr_time, trav_time_min, euclid_dist_m, route_type,
          route_start_link, route_end_link, route_trav_time,
          route_distance_m, route_links, route_raw, attributes)``
        * **plan_summary** : ``(person_id, plan_index, plan_uid, score,
          selected, activities, modes, points, leg_times_min,
          leg_euclid_dists_m, leg_route_dists_m, total_time_min,
          total_euclid_dist_m, total_route_dist_m)``

    Notes
    -----
    Time columns use the following conventions:

    * Absolute times (``dep_time``, ``arr_time``, ``start_time``,
      ``end_time``, ``route_trav_time``) are ``HH:MM:SS`` strings.
    * Travel durations (``trav_time_min``, ``leg_times_min``,
      ``total_time_min``) are stored in **minutes** as floats.
    * Euclidean distances are derived from the ``x``/``y`` coordinates of
      consecutive activities.  Route distances come directly from the XML
      ``distance`` attribute.

    Raises
    ------
    OSError
        If the file cannot be opened or read.
    lxml.etree.XMLSyntaxError
        If the XML is malformed.
    """
    per_cols: dict[str, list[Any]] = {"person_id": [], "selected_plan_indices": []}
    # person_attrs has dynamic/unknown columns so list-of-dicts is kept here.
    person_attr_records: list[dict[str, Any]] = []
    pl_cols: dict[str, list[Any]] = {
        "person_id": [],
        "plan_index": [],
        "plan_uid": [],
        "score": [],
        "selected": [],
        "attributes": [],
    }
    el_cols: dict[str, list[Any]] = {
        "person_id": [],
        "plan_index": [],
        "elem_index": [],
        "elem_type": [],
        "ref_index": [],
    }
    ac_cols: dict[str, list[Any]] = {
        "person_id": [],
        "plan_index": [],
        "act_index": [],
        "type": [],
        "x": [],
        "y": [],
        "link": [],
        "facility": [],
        "start_time": [],
        "end_time": [],
        "attributes": [],
    }
    lg_cols: dict[str, list[Any]] = {
        "person_id": [],
        "plan_index": [],
        "leg_index": [],
        "mode": [],
        "dep_time": [],
        "arr_time": [],
        "trav_time_min": [],
        "euclid_dist_m": [],
        "route_type": [],
        "route_start_link": [],
        "route_end_link": [],
        "route_trav_time": [],
        "route_distance_m": [],
        "route_links": [],
        "route_raw": [],
        "attributes": [],
    }
    ps_cols: dict[str, list[Any]] = {
        "person_id": [],
        "plan_index": [],
        "plan_uid": [],
        "score": [],
        "selected": [],
        "activities": [],
        "modes": [],
        "points": [],
        "leg_times_min": [],
        "leg_euclid_dists_m": [],
        "leg_route_dists_m": [],
        "total_time_min": [],
        "total_euclid_dist_m": [],
        "total_route_dist_m": [],
    }

    # Streaming context
    iterparse_kwargs: dict[str, Any] = {
        "events": ("start", "end"),
        # Filter at the C level
        "tag": list(_KNOWN_TAGS),
        "load_dtd": False,
        "resolve_entities": False,
        "huge_tree": True,
    }

    with _open_xml_source(path) as _src:
        context = ET.iterparse(_src, **iterparse_kwargs)

        # Person state
        current_person_id = None
        person_attrs: dict[str, Any] = {}
        selected_plan_idxs_for_person: list[int] = []

        # Plan state
        in_plan = False
        plan_index = -1
        plan_score = None
        plan_selected = False
        plan_attrs: dict[str, Any] = {}
        elem_index = -1

        # Activity state
        in_activity = False
        act_index = -1
        current_activity_attrs: dict[str, Any] = {}

        # Leg state
        in_leg = False
        leg_index = -1
        current_leg_attrs: dict[str, Any] = {}
        leg_route_ctx: dict[str, Any] = {}

        # For euclidean distances
        last_activity_point = None
        pending_leg_row_idx = None

        # Per-plan summary accumulators
        summary_act_types: list[str] = []
        summary_modes: list[str] = []
        summary_points: list[Any] = []
        summary_leg_times: list[Optional[float]] = []
        summary_leg_euclid_dists: list[float] = []
        summary_leg_route_dists: list[Optional[float]] = []

        # Attribute collection target stack
        attr_target_stack: list[dict[str, Any]] = []

        def finish_plan() -> None:
            """
            Flush accumulators for the current plan into the columnar stores.

            Called at the ``</plan>`` end event.  Aligns the per-leg distance
            lists to the same length as ``summary_leg_times``, computes
            aggregate totals, and appends one row to both ``pl_cols`` (the
            plans table) and ``ps_cols`` (the plan-summary table).

            Modifies ``pl_cols`` and ``ps_cols`` in the enclosing scope.
            """
            nonlocal \
                summary_leg_euclid_dists, \
                summary_leg_route_dists, \
                summary_leg_times
            # Align arrays
            n_legs = len(summary_leg_times)
            if len(summary_leg_euclid_dists) < n_legs:
                summary_leg_euclid_dists += [0.0] * (
                    n_legs - len(summary_leg_euclid_dists)
                )
            if len(summary_leg_route_dists) < n_legs:
                summary_leg_route_dists += [None] * (
                    n_legs - len(summary_leg_route_dists)
                )

            # summary_leg_times holds minutes (float); sum directly
            total_time_min = sum(t for t in summary_leg_times if t is not None)
            total_euclid = float(sum(summary_leg_euclid_dists))
            total_route_vals = [
                d
                for d in summary_leg_route_dists
                if isinstance(d, (int, float)) and not math.isnan(d)
            ]
            total_route = float(sum(total_route_vals)) if total_route_vals else None

            plan_uid = f"{current_person_id}#{plan_index}"

            pl_cols["person_id"].append(current_person_id)
            pl_cols["plan_index"].append(plan_index)
            pl_cols["plan_uid"].append(plan_uid)
            pl_cols["score"].append(plan_score)
            pl_cols["selected"].append(plan_selected)
            pl_cols["attributes"].append(dict(plan_attrs) if plan_attrs else None)

            ps_cols["person_id"].append(current_person_id)
            ps_cols["plan_index"].append(plan_index)
            ps_cols["plan_uid"].append(plan_uid)
            ps_cols["score"].append(plan_score)
            ps_cols["selected"].append(plan_selected)
            ps_cols["activities"].append(list(summary_act_types))
            ps_cols["modes"].append(list(summary_modes))
            ps_cols["points"].append(list(summary_points))
            ps_cols["leg_times_min"].append(list(summary_leg_times))
            ps_cols["leg_euclid_dists_m"].append(list(summary_leg_euclid_dists))
            ps_cols["leg_route_dists_m"].append(list(summary_leg_route_dists))
            ps_cols["total_time_min"].append(
                total_time_min if total_time_min > 0 else None
            )
            ps_cols["total_euclid_dist_m"].append(
                total_euclid if total_euclid > 0 else None
            )
            ps_cols["total_route_dist_m"].append(total_route)

        for event, elem in context:
            tag = elem.tag
            # lxml's tag filter (set in iterparse_kwargs) already guarantees only
            # known tags reach here; strip any XML namespace prefix if present.
            if "}" in tag:
                tag = tag.split("}", 1)[1]

            if event == "start":
                if tag == "person":
                    current_person_id = elem.attrib.get("id")
                    person_attrs = {}
                    selected_plan_idxs_for_person = []
                    plan_index = -1

                elif tag == "plan" and current_person_id is not None:
                    attrib = elem.attrib
                    in_plan = True
                    plan_index += 1
                    plan_score = None
                    plan_selected = False
                    plan_attrs = {}
                    elem_index = -1
                    in_activity = False
                    in_leg = False
                    act_index = -1
                    leg_index = -1
                    last_activity_point = None
                    pending_leg_row_idx = None
                    summary_act_types = []
                    summary_modes = []
                    summary_points = []
                    summary_leg_times = []
                    summary_leg_euclid_dists = []
                    summary_leg_route_dists = []

                    score_raw = attrib.get("score")
                    if score_raw is not None:
                        try:
                            plan_score = float(score_raw)
                        except Exception:
                            plan_score = None
                    sel_raw = attrib.get("selected", "no").lower()
                    plan_selected = sel_raw in ("yes", "true", "1")
                    if plan_selected:
                        selected_plan_idxs_for_person.append(plan_index)

                elif tag == "activity" and in_plan:
                    attrib = elem.attrib
                    in_activity = True
                    elem_index += 1
                    act_index += 1
                    current_activity_attrs = {}

                    act_type = attrib.get("type", "")
                    x = attrib.get("x")
                    y = attrib.get("y")
                    link = attrib.get("link")
                    facility = attrib.get("facility")
                    start_time = _normalise_hms(attrib.get("start_time"))
                    end_time = _normalise_hms(attrib.get("end_time"))

                    if x is not None and y is not None:
                        try:
                            px, py = float(x), float(y)
                        except Exception:
                            px, py = float("nan"), float("nan")
                    else:
                        px, py = float("nan"), float("nan")

                    summary_act_types.append(act_type)
                    summary_points.append({"x": px, "y": py})

                    # Resolve pending leg euclidean distance
                    if (
                        pending_leg_row_idx is not None
                        and last_activity_point is not None
                    ):
                        eu = _euclidean(last_activity_point, (px, py))
                        lg_cols["euclid_dist_m"][pending_leg_row_idx] = eu
                        summary_leg_euclid_dists.append(eu)
                        pending_leg_row_idx = None

                    if not math.isnan(px) and not math.isnan(py):
                        last_activity_point = (px, py)

                    # Append activity columns; attributes patched in-place at end event
                    ac_cols["person_id"].append(current_person_id)
                    ac_cols["plan_index"].append(plan_index)
                    ac_cols["act_index"].append(act_index)
                    ac_cols["type"].append(act_type)
                    ac_cols["x"].append(px)
                    ac_cols["y"].append(py)
                    ac_cols["link"].append(link)
                    ac_cols["facility"].append(facility)
                    ac_cols["start_time"].append(start_time)
                    ac_cols["end_time"].append(end_time)
                    ac_cols["attributes"].append(None)

                    # Ordered elements
                    el_cols["person_id"].append(current_person_id)
                    el_cols["plan_index"].append(plan_index)
                    el_cols["elem_index"].append(elem_index)
                    el_cols["elem_type"].append("activity")
                    el_cols["ref_index"].append(act_index)

                elif tag == "leg" and in_plan:
                    attrib = elem.attrib
                    in_leg = True
                    elem_index += 1
                    leg_index += 1
                    current_leg_attrs = {}
                    leg_route_ctx = {}

                    mode = attrib.get("mode", "")
                    trav_time_s = _parse_time_to_seconds(
                        attrib.get("trav_time") or attrib.get("travel_time")
                    )
                    trav_time_min = (
                        (trav_time_s / 60.0) if trav_time_s is not None else None
                    )

                    summary_modes.append(mode)
                    summary_leg_times.append(trav_time_min)

                    # Append leg columns; route/euclid/attrs patched in-place later
                    lg_cols["person_id"].append(current_person_id)
                    lg_cols["plan_index"].append(plan_index)
                    lg_cols["leg_index"].append(leg_index)
                    lg_cols["mode"].append(mode)
                    lg_cols["dep_time"].append(
                        _normalise_hms(
                            attrib.get("dep_time") or attrib.get("departure_time")
                        )
                    )
                    lg_cols["arr_time"].append(
                        _normalise_hms(
                            attrib.get("arr_time") or attrib.get("arrival_time")
                        )
                    )
                    lg_cols["trav_time_min"].append(trav_time_min)
                    lg_cols["euclid_dist_m"].append(None)
                    lg_cols["route_type"].append(None)
                    lg_cols["route_start_link"].append(None)
                    lg_cols["route_end_link"].append(None)
                    lg_cols["route_trav_time"].append(None)
                    lg_cols["route_distance_m"].append(None)
                    lg_cols["route_links"].append(None)
                    lg_cols["route_raw"].append(None)
                    lg_cols["attributes"].append(None)

                    pending_leg_row_idx = len(lg_cols["person_id"]) - 1

                    # Ordered elements
                    el_cols["person_id"].append(current_person_id)
                    el_cols["plan_index"].append(plan_index)
                    el_cols["elem_index"].append(elem_index)
                    el_cols["elem_type"].append("leg")
                    el_cols["ref_index"].append(leg_index)

                elif tag == "route" and in_leg:
                    attrib = elem.attrib
                    route_type = attrib.get("type")
                    dist_raw = attrib.get("distance")
                    route_dist: Optional[float] = None
                    if dist_raw is not None:
                        try:
                            v = float(dist_raw)
                            if not math.isnan(v):
                                route_dist = v
                        except Exception:
                            pass
                    leg_route_ctx = {
                        "route_type": route_type,
                        "route_start_link": attrib.get("start_link")
                        or attrib.get("startLinkId"),
                        "route_end_link": attrib.get("end_link")
                        or attrib.get("endLinkId"),
                        "route_trav_time": _normalise_hms(
                            attrib.get("trav_time") or attrib.get("travel_time")
                        ),
                        "route_distance_m": route_dist,
                    }

                elif tag == "attributes":
                    if in_activity:
                        attr_target_stack.append(current_activity_attrs)
                    elif in_leg:
                        attr_target_stack.append(current_leg_attrs)
                    elif in_plan:
                        attr_target_stack.append(plan_attrs)
                    elif current_person_id is not None:
                        attr_target_stack.append(person_attrs)
                    else:
                        # population-level attributes ignored
                        attr_target_stack.append({})

            # End events
            elif tag == "route" and in_leg:
                raw_text = (elem.text or "").strip()
                rtype = (leg_route_ctx.get("route_type") or "").lower()
                route_links = (
                    [tok for tok in raw_text.split() if tok]
                    if rtype == "links" and raw_text
                    else None
                )
                if lg_cols["person_id"]:
                    lg_cols["route_type"][-1] = leg_route_ctx.get("route_type")
                    lg_cols["route_start_link"][-1] = leg_route_ctx.get(
                        "route_start_link"
                    )
                    lg_cols["route_end_link"][-1] = leg_route_ctx.get("route_end_link")
                    lg_cols["route_trav_time"][-1] = leg_route_ctx.get(
                        "route_trav_time"
                    )
                    lg_cols["route_distance_m"][-1] = leg_route_ctx.get(
                        "route_distance_m"
                    )
                    lg_cols["route_links"][-1] = route_links
                    lg_cols["route_raw"][-1] = raw_text if raw_text else None
                    summary_leg_route_dists.append(
                        leg_route_ctx.get("route_distance_m")
                    )
                elem.clear()

            elif tag == "activity" and in_activity:
                ac_cols["attributes"][-1] = (
                    dict(current_activity_attrs) if current_activity_attrs else None
                )
                in_activity = False
                current_activity_attrs = {}
                elem.clear()

            elif tag == "leg" and in_leg:
                if lg_cols["person_id"]:
                    lg_cols["attributes"][-1] = (
                        dict(current_leg_attrs) if current_leg_attrs else None
                    )
                    # If no <route> was present, still align route distances
                    if len(summary_leg_route_dists) < len(summary_leg_times):
                        summary_leg_route_dists.append(lg_cols["route_distance_m"][-1])
                in_leg = False
                current_leg_attrs = {}
                leg_route_ctx = {}
                elem.clear()

            elif tag == "plan" and in_plan:
                # If a leg is pending without closing activity, pad distance
                if pending_leg_row_idx is not None:
                    lg_cols["euclid_dist_m"][pending_leg_row_idx] = 0.0
                    summary_leg_euclid_dists.append(0.0)
                    pending_leg_row_idx = None
                finish_plan()
                in_plan = False
                plan_attrs = {}
                elem.clear()

            elif tag == "person" and current_person_id is not None:
                per_cols["person_id"].append(current_person_id)
                per_cols["selected_plan_indices"].append(
                    list(selected_plan_idxs_for_person)
                )
                person_attr_records.append(
                    {
                        "person_id": current_person_id,
                        **{
                            _attr_name: (
                                str(_attr_val) if _attr_val is not None else None
                            )
                            for _attr_name, _attr_val in person_attrs.items()
                        },
                    }
                )
                current_person_id = None
                person_attrs = {}
                selected_plan_idxs_for_person = []
                elem.clear()

            elif tag == "attributes":
                if attr_target_stack:
                    attr_target_stack.pop()
                elem.clear()

            elif tag == "attribute":
                if attr_target_stack:
                    attrib = elem.attrib
                    name = attrib.get("name")
                    cls = attrib.get("class")
                    val = _cast_attr_value(cls, elem.text)
                    if name:
                        attr_target_stack[-1][name] = val
                elem.clear()

            else:
                elem.clear()

    return ParsedPlans(
        {
            "persons": per_cols,
            "person_attrs": person_attr_records,
            "plans": pl_cols,
            "elements": el_cols,
            "activities": ac_cols,
            "legs": lg_cols,
            "plan_summary": ps_cols,
        }
    )
