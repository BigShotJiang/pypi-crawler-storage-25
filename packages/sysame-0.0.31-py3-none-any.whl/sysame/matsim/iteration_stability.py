"""
Iteration-level stability analysis for MATSim plans.

Core functions
--------------
``parse_iteration_metrics``
    Parse a single iteration from an iterations folder and return a flat
    per-person metrics DataFrame covering logsums, travel times, trip counts,
    and route distances.

``compute_stability``
    Accept any number of per-iteration metrics DataFrames and return a
    per-person summary of standard deviation and variance for every metric
    across the supplied iterations.

Plotting helpers
----------------
``plot_stability_distributions``
    Subplot grid of per-person std-deviation histograms — one panel per metric.

``plot_stability_convergence``
    Multi-line chart of population-mean metric values per iteration.

Typical usage
-------------
>>> from sysame.matsim.iteration_stability import (
...     parse_iteration_metrics,
...     compute_stability,
...     plot_stability_convergence,
...     plot_stability_distributions,
... )

>>> # Collect one DataFrame per iteration
>>> frames = [
...     parse_iteration_metrics("/path/to/ITERS", "kelheim-v3.1-25pct", i)
...     for i in range(0, 51, 5)
... ]

>>> # Variance / std per person across those iterations
>>> stability = compute_stability(frames)

>>> # Visualise
>>> plot_stability_convergence(frames)
>>> plot_stability_distributions(stability)
"""

from __future__ import annotations

import logging
import math as _math
from os import PathLike
from pathlib import Path
from typing import Any, Optional, Union

import polars as pl

from sysame.matsim.plan_parser import parse_matsim_plans
from sysame.matsim.plan_parser import (
    _resolve_plans_file,  # type: ignore[attr-defined]
)
from sysame.plotting.plotting import plot_histogram, plot_line

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Metric column names → human-readable display labels (display order matters)
# ---------------------------------------------------------------------------
_METRIC_LABELS: dict[str, str] = {
    "logsum_selected": "Logsum — executed plan",
    "logsum_all": "Logsum — all plans",
    "logsum_average": "Logsum — average plan",
    "travel_time_selected_min": "Travel time (min) — executed plan",
    "travel_time_all_min": "Travel time (min) — all plans (mean)",
    "n_trips_selected": "No. trips — executed plan",
    "n_trips_all": "No. trips — all plans (mean)",
    "route_dist_selected_m": "Route distance (m) — executed plan",
    "route_dist_all_m": "Route distance (m) — all plans (mean)",
}

_METRIC_COLS: list[str] = list(_METRIC_LABELS.keys())

_METRIC_FAMILIES: dict[str, list[str]] = {
    "logsum": ["logsum_selected", "logsum_all", "logsum_average"],
    "travel_time": ["travel_time_selected_min", "travel_time_all_min"],
    "trip_count": ["n_trips_selected", "n_trips_all"],
    "route_distance": ["route_dist_selected_m", "route_dist_all_m"],
}

_METRIC_FAMILY_TITLES: dict[str, str] = {
    "logsum": "Logsum Metrics",
    "travel_time": "Travel Time Metrics",
    "trip_count": "Trip Count Metrics",
    "route_distance": "Route Distance Metrics",
    "other": "Other Metrics",
}


# ---------------------------------------------------------------------------
# Public API – function 1
# ---------------------------------------------------------------------------


def parse_iteration_metrics(
    iterations_folder: str | PathLike[str],
    scenario: str,
    iteration: int,
    lambda_scale: float = 1.0,
) -> pl.DataFrame:
    """
    Parse a set of MATSim iteration folders and compute per-person metrics.

    For each iteration, four metrics are computed per person:

    * ``logsum_selected``          — logsum over the executed plan only.
    Parse a single MATSim iteration and return a flat per-person metrics DataFrame.

    Locates the plans file for *iteration* inside *iterations_folder* /
    ``it.<iteration>``, parses it, and derives the following per-person metrics:

    ========================== ==============================================
    Column                     Description
    ========================== ==============================================
    ``logsum_selected``        Logsum of the executed (selected) plan.
    ``logsum_all``             Logsum pooling every stored plan.
    ``logsum_average``         Logsum of the synthetic "average" plan (whose
                               utility equals the mean utility across all
                               plans for that person).
    ``travel_time_selected_min`` Total in-vehicle travel time of the executed
                               plan (minutes).
    ``travel_time_all_min``    Mean total travel time across all stored plans
                               (minutes).
    ``n_trips_selected``       Number of legs (trips) in the executed plan.
    ``n_trips_all``            Mean number of legs across all stored plans.
    ``route_dist_selected_m``  Sum of route distances in the executed plan
                               (metres).  ``None`` when no route distances are
                               present in the XML.
    ``route_dist_all_m``       Mean sum of route distances across all stored
                               plans (metres).
    ========================== ==============================================

    Parameters
    ----------
    iterations_folder : str or PathLike[str]
        Root folder that contains ``it.0``, ``it.1``, … sub-directories.
    scenario : str
        Scenario stem used to build the plans filename, e.g.
        ``"kelheim-v3.1-25pct"``.  The parser looks for
        ``<scenario><iteration>.plans.xml.gz`` first, then
        ``<scenario><iteration>.plans.xml``.
    iteration : int
        The iteration number to parse (e.g. ``50`` → ``it.50/``).
    lambda_scale : float, default 1.0
        Scale parameter :math:`\\lambda` for the logsum formula:

        .. math::

            LS_i = \\frac{1}{\\lambda}
                   \\ln\\!\\left(\\sum_j e^{\\lambda V_{ij}}\\right)

    Returns
    -------
    pl.DataFrame
        One row per person.  Columns (in order):

        ``person_id``, ``iteration``,
        ``logsum_selected``, ``logsum_all``, ``logsum_average``,
        ``travel_time_selected_min``, ``travel_time_all_min``,
        ``n_trips_selected``, ``n_trips_all``,
        ``route_dist_selected_m``, ``route_dist_all_m``.

    Raises
    ------
    FileNotFoundError
        If *iterations_folder* or the ``it.<iteration>`` sub-directory does
        not exist, or if no plans file can be found for the given scenario and
        iteration number.

    Examples
    --------
    >>> df = parse_iteration_metrics("/path/to/ITERS", "kelheim-v3.1-25pct", 50)
    >>> print(df.head())
    """
    root = Path(iterations_folder)
    it_dir = root / f"it.{iteration}"
    if not it_dir.exists():
        raise FileNotFoundError(f"Iteration directory not found: {it_dir}")

    plans_file = _resolve_plans_file(it_dir, scenario, iteration)
    logger.info("Parsing iteration %d from %s", iteration, plans_file)
    parsed = parse_matsim_plans(plans_file)

    # --- logsums ---
    ls_sel = parsed.plan_logsum(lambda_scale=lambda_scale, plan_set="selected").select(
        ["person_id", pl.col("logsum").alias("logsum_selected")]
    )
    ls_all = parsed.plan_logsum(lambda_scale=lambda_scale, plan_set="all").select(
        ["person_id", pl.col("logsum").alias("logsum_all")]
    )
    ls_avg = parsed.plan_logsum(lambda_scale=lambda_scale, plan_set="average").select(
        ["person_id", pl.col("logsum").alias("logsum_average")]
    )

    # --- travel stats for the executed plan ---
    ts_sel = parsed.travel_stats(plan_set="selected").select(
        [
            "person_id",
            pl.col("total_time_min").alias("travel_time_selected_min"),
            pl.col("n_trips").alias("n_trips_selected"),
            pl.col("total_route_dist_m").alias("route_dist_selected_m"),
        ]
    )

    # --- travel stats averaged across all plans ---
    ts_all = parsed.travel_stats(plan_set="all").select(
        [
            "person_id",
            pl.col("total_time_min").alias("travel_time_all_min"),
            pl.col("n_trips").alias("n_trips_all"),
            pl.col("total_route_dist_m").alias("route_dist_all_m"),
        ]
    )

    return (
        ls_sel.join(ls_all, on="person_id", how="left")
        .join(ls_avg, on="person_id", how="left")
        .join(ts_sel, on="person_id", how="left")
        .join(ts_all, on="person_id", how="left")
        .with_columns(pl.lit(iteration).cast(pl.Int32).alias("iteration"))
        .select(["person_id", "iteration"] + _METRIC_COLS)
    )


# ---------------------------------------------------------------------------
# Public API – function 2
# ---------------------------------------------------------------------------


def compute_stability(metrics_dfs: list[pl.DataFrame]) -> pl.DataFrame:
    """
    Compute per-person standard deviation and variance for each metric.

    Concatenates any number of per-iteration DataFrames produced by
    :func:`parse_iteration_metrics` and, for each person, calculates the
    standard deviation and variance of every metric column across the supplied
    iterations.

    A standard deviation close to zero means the measure barely changes
    between iterations for that person (stable / converged).  A large value
    indicates that the simulation has not yet converged for that person.

    Parameters
    ----------
    metrics_dfs : list[pl.DataFrame]
        List of DataFrames, each the output of
        :func:`parse_iteration_metrics` (typically one per iteration).
        They are concatenated row-wise before aggregation.

    Returns
    -------
    pl.DataFrame
        One row per person.  Columns:

        * ``person_id`` (str)
        * ``n_iterations`` (int) — number of iteration rows per person.
        * For each metric ``<m>`` in :data:`_METRIC_COLS`:

          - ``std_<m>`` (float or None) — standard deviation with Bessel's
            correction (``ddof=1``).  ``None`` when fewer than 2 observations.
          - ``var_<m>`` (float or None) — variance (same correction).

    Raises
    ------
    ValueError
        If no DataFrames are supplied.

    Examples
    --------
    >>> frames = [
    ...     parse_iteration_metrics("/path/to/ITERS", "kelheim-v3.1-25pct", i)
    ...     for i in range(0, 51, 5)
    ... ]
    >>> stability = compute_stability(frames)
    >>> print(stability.sort("std_logsum_selected", descending=True).head())
    """
    if not metrics_dfs:
        raise ValueError("At least one metrics DataFrame must be supplied.")

    combined = pl.concat(metrics_dfs)

    agg_exprs: list[pl.Expr] = [pl.len().alias("n_iterations")]
    for col in _METRIC_COLS:
        if col in combined.columns:
            agg_exprs.append(pl.col(col).std().alias(f"std_{col}"))
            agg_exprs.append(pl.col(col).var().alias(f"var_{col}"))

    return combined.group_by("person_id").agg(*agg_exprs)


# ---------------------------------------------------------------------------
# Plotting helpers
# ---------------------------------------------------------------------------


def plot_stability_distributions(
    stability: pl.DataFrame,
    metrics: Optional[list[str]] = None,
    bins: Union[int, str] = 40,
    show_mean: bool = True,
    show_median: bool = True,
    show_kde: bool = False,
    rows: Optional[int] = None,
    cols: Optional[int] = None,
    figsize: Optional[tuple[int, int]] = None,
    plot_save_path: Optional[Path] = None,
) -> None:
    """
    Plot per-person std-deviation histograms for each metric.

    Produces one subplot figure per metric family (logsum, travel time,
    trip count, route distance). This avoids cross-family scale distortion
    when very different units are plotted together. Within each family figure,
    one panel is shown per metric.

    Parameters
    ----------
    stability : pl.DataFrame
        Output of :func:`compute_stability`.
    metrics : list[str] or None, default None
        Subset of metric names to plot (e.g.
        ``["logsum_selected", "travel_time_selected_min"]``).
        ``None`` plots all nine metrics.
    bins : int or str, default 40
        Number of histogram bins or a NumPy bin-edge strategy string.
    show_mean : bool, default True
        Overlay a vertical line at the mean std.
    show_median : bool, default True
        Overlay a vertical line at the median std.
    show_kde : bool, default False
        Overlay a KDE curve.
    rows : int or None, default None
        Subplot grid rows; inferred automatically when ``None``.
    cols : int or None, default None
        Subplot grid columns; inferred automatically when ``None``.
    figsize : tuple[int, int] or None, default None
        Figure size in inches; chosen automatically when ``None``.
    plot_save_path : Path or None, default None
        Save to this path instead of displaying. If multiple family figures are
        produced, a family suffix is inserted into the filename stem
        (e.g. ``stability_logsum.png``, ``stability_travel_time.png``).
    """
    selected = metrics or _METRIC_COLS
    grouped_metrics: dict[str, list[str]] = {}

    for family, family_metrics in _METRIC_FAMILIES.items():
        matched = [m for m in selected if m in family_metrics]
        if matched:
            grouped_metrics[family] = matched

    remaining = [
        m
        for m in selected
        if m not in {fm for family in grouped_metrics.values() for fm in family}
    ]
    if remaining:
        grouped_metrics["other"] = remaining

    if not grouped_metrics:
        raise ValueError("No metric columns selected for stability distributions.")

    single_group = len(grouped_metrics) == 1

    for family, family_metrics in grouped_metrics.items():
        data_arrays: list[Any] = []
        group_labels: list[str] = []

        for col in family_metrics:
            std_col = f"std_{col}"
            arr: list[float] = (
                stability[std_col].drop_nulls().to_list()
                if std_col in stability.columns
                else []
            )
            data_arrays.append(arr)
            group_labels.append(_METRIC_LABELS.get(col, col))

        n = len(family_metrics)
        local_rows = rows
        local_cols = cols
        if local_rows is None and local_cols is None:
            local_cols = min(3, n)
            local_rows = _math.ceil(n / local_cols)

        family_title = _METRIC_FAMILY_TITLES.get(
            family, family.replace("_", " ").title()
        )
        title = (
            "Iteration Stability — "
            f"{family_title} Per-Person Std. Deviation Distribution"
        )

        family_save_path: Optional[Path] = None
        if plot_save_path is not None:
            if single_group:
                family_save_path = plot_save_path
            else:
                family_save_path = plot_save_path.with_name(
                    f"{plot_save_path.stem}_{family}{plot_save_path.suffix}"
                )

        plot_histogram(
            data=data_arrays,
            group_labels=group_labels,
            bins=bins,
            x_label="Std. deviation across iterations",
            y_label="Number of persons",
            title=title,
            show_mean=show_mean,
            show_median=show_median,
            show_kde=show_kde,
            subplots=True,
            rows=local_rows,
            cols=local_cols,
            figsize=figsize,
            plot_save_path=family_save_path,
        )


def plot_stability_convergence(
    metrics_dfs: Union[list[pl.DataFrame], pl.DataFrame],
    selected_metrics: Optional[list[str]] = None,
    figsize: Optional[tuple[int, int]] = None,
    plot_save_path: Optional[Path] = None,
) -> None:
    """
    Plot population-mean metric values per iteration as a convergence chart.

    Each selected metric is drawn as a separate line.  The x-axis is the
    iteration number; the y-axis is the population mean at that iteration.
    Flat, non-drifting lines indicate convergence.

    Parameters
    ----------
    metrics_dfs : list[pl.DataFrame] or pl.DataFrame
        One or more DataFrames from :func:`parse_iteration_metrics`, or a
        single already-concatenated DataFrame.
    selected_metrics : list[str] or None, default None
        Subset of metric column names to plot.  ``None`` plots all nine.
    figsize : tuple[int, int] or None, default None
        Figure size in inches.
    plot_save_path : Path or None, default None
        Save to this path instead of displaying.

    Raises
    ------
    ValueError
        If the provided dataframe(s) do not contain an ``iteration`` column.
    """
    combined = pl.concat(metrics_dfs) if isinstance(metrics_dfs, list) else metrics_dfs

    if "iteration" not in combined.columns:
        raise ValueError(
            "plot_stability_convergence expects per-iteration metrics with an "
            "'iteration' column (from parse_iteration_metrics). "
            "It cannot be used with compute_stability output. "
            "Use plot_stability_distributions for stability tables instead."
        )

    plot_cols = selected_metrics or _METRIC_COLS
    summary = (
        combined.group_by("iteration")
        .agg(*[pl.col(c).mean().alias(c) for c in plot_cols if c in combined.columns])
        .sort("iteration")
    )

    x_data = summary["iteration"].to_list()
    y_data: list[Any] = [
        summary[c].to_list() for c in plot_cols if c in summary.columns
    ]
    labels = [_METRIC_LABELS.get(c, c) for c in plot_cols if c in summary.columns]

    plot_line(
        x_data=x_data,
        y_data=y_data,
        group_labels=labels,
        x_label="Iteration",
        y_label="Population mean",
        title="Convergence — Mean Metric Values by Iteration",
        sort_data=False,
        plot_save_path=plot_save_path,
    )
