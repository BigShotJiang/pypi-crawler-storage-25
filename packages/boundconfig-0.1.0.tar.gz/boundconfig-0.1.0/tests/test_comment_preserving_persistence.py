from __future__ import annotations

import textwrap
from pathlib import Path

from boundconfig.cli import main


def _write_toml(tmp_path: Path, name: str, content: str) -> Path:
    path = tmp_path / name
    path.write_text(textwrap.dedent(content).strip(), encoding="utf-8")
    return path


def _assert_comment_preserving_update(rendered: str) -> None:
    assert "# file comment" in rendered
    assert "[service] # managed section comment" in rendered
    assert "# managed key comment" in rendered
    assert 'enabled = "true" # inline managed comment' in rendered
    assert 'extra = "user"' in rendered
    assert "retries = 3" in rendered
    assert "[custom] # user section comment" in rendered
    assert "feature = true # user inline comment" in rendered
    assert '[ui]\ntheme = "dark"' in rendered
    assert rendered.index("[custom] # user section comment") < rendered.index("[ui]")


def test_cli_init_round_trips_comments_during_managed_update(tmp_path: Path) -> None:
    defaults_path = _write_toml(
        tmp_path,
        "defaults.toml",
        """
        [service]
        enabled = true
        retries = 3

        [ui]
        theme = "dark"
        """,
    )
    config_path = _write_toml(
        tmp_path,
        "config.toml",
        """
        # file comment

        [service] # managed section comment
        # managed key comment
        enabled = "true" # inline managed comment
        extra = "user"

        [custom] # user section comment
        feature = true # user inline comment
        """,
    )

    exit_code = main(
        [
            "init",
            "--config",
            str(config_path),
            "--defaults",
            str(defaults_path),
        ]
    )

    assert exit_code == 0
    _assert_comment_preserving_update(config_path.read_text(encoding="utf-8"))


def test_cli_init_repeated_runs_are_comment_preserving_and_stable(tmp_path: Path) -> None:
    defaults_path = _write_toml(
        tmp_path,
        "defaults.toml",
        """
        [service]
        enabled = true
        retries = 3

        [ui]
        theme = "dark"
        """,
    )
    config_path = _write_toml(
        tmp_path,
        "config.toml",
        """
        # file comment

        [service] # managed section comment
        # managed key comment
        enabled = "true" # inline managed comment
        extra = "user"

        [custom] # user section comment
        feature = true # user inline comment
        """,
    )

    first_exit_code = main(
        [
            "init",
            "--config",
            str(config_path),
            "--defaults",
            str(defaults_path),
        ]
    )

    assert first_exit_code == 0
    first_rendered = config_path.read_text(encoding="utf-8")
    _assert_comment_preserving_update(first_rendered)

    second_exit_code = main(
        [
            "init",
            "--config",
            str(config_path),
            "--defaults",
            str(defaults_path),
        ]
    )

    assert second_exit_code == 0
    assert config_path.read_text(encoding="utf-8") == first_rendered


def test_cli_init_dry_run_leaves_comment_rich_config_unchanged(tmp_path: Path) -> None:
    defaults_path = _write_toml(
        tmp_path,
        "defaults.toml",
        """
        [service]
        enabled = true
        retries = 3

        [ui]
        theme = "dark"
        """,
    )
    config_path = _write_toml(
        tmp_path,
        "config.toml",
        """
        # file comment

        [service] # managed section comment
        # managed key comment
        enabled = "true" # inline managed comment
        extra = "user"

        [custom] # user section comment
        feature = true # user inline comment
        """,
    )
    original = config_path.read_text(encoding="utf-8")

    exit_code = main(
        [
            "init",
            "--config",
            str(config_path),
            "--defaults",
            str(defaults_path),
            "--dry-run",
        ]
    )

    assert exit_code == 0
    assert config_path.read_text(encoding="utf-8") == original


def test_cli_validate_leaves_comment_rich_config_unchanged(tmp_path: Path) -> None:
    defaults_path = _write_toml(
        tmp_path,
        "defaults.toml",
        """
        [service]
        enabled = true
        retries = 3

        [ui]
        theme = "dark"
        """,
    )
    config_path = _write_toml(
        tmp_path,
        "config.toml",
        """
        # file comment

        [service] # managed section comment
        # managed key comment
        enabled = "true" # inline managed comment
        extra = "user"

        [custom] # user section comment
        feature = true # user inline comment
        """,
    )
    original = config_path.read_text(encoding="utf-8")

    exit_code = main(
        [
            "validate",
            "--config",
            str(config_path),
            "--defaults",
            str(defaults_path),
        ]
    )

    assert exit_code == 1
    assert config_path.read_text(encoding="utf-8") == original
