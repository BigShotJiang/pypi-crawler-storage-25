from __future__ import annotations

from pathlib import Path

from boundconfig import BoundConfig, register_validator
from boundconfig.validators import InMemoryValidatorRegistry, get_shared_validator_registry


def _write_toml(tmp_path: Path, name: str, content: str) -> Path:
    path = tmp_path / name
    path.write_text(content.strip(), encoding="utf-8")
    return path


def test_in_memory_validator_registry_registers_and_looks_up_validators() -> None:
    registry = InMemoryValidatorRegistry()

    def _validator(value: object) -> str | None:
        return None

    registry.register("named-check", _validator)

    assert registry.get("named-check") is _validator
    assert registry.get("missing-check") is None


def test_bound_config_defaults_to_the_shared_top_level_validator_registry(
    tmp_path: Path,
) -> None:
    defaults_path = _write_toml(
        tmp_path,
        "defaults.toml",
        """
        [service]
        name = { _default_value = "BoundConfig", _validator = "shared-no-spaces" }
        """,
    )
    config_path = _write_toml(
        tmp_path,
        "config.toml",
        """
        [service]
        name = "BoundConfig"
        """,
    )

    register_validator(
        "shared-no-spaces",
        lambda value: "must not contain spaces" if " " in value else None,
    )
    bound_config = BoundConfig(
        config_path=config_path,
        defaults_paths=(defaults_path,),
    )

    assert bound_config.validator_registry is get_shared_validator_registry()
    assert bound_config.validate().is_valid
