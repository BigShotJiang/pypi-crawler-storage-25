from __future__ import annotations

import textwrap
from pathlib import Path
from typing import Any

import pytest

from boundconfig import BoundConfig
from boundconfig.adapters import TomlAdapter
from boundconfig.exceptions import UnknownValidatorError
from boundconfig.repair import TomlRepairEngine
from boundconfig.schema import TomlSchemaLoader
from boundconfig.validation import TomlValidationEngine
from boundconfig.validators import InMemoryValidatorRegistry


def _write_toml(tmp_path: Path, name: str, content: str) -> Path:
    path = tmp_path / name
    path.write_text(textwrap.dedent(content).strip(), encoding="utf-8")
    return path


def _unwrap(value: Any) -> Any:
    if hasattr(value, "unwrap"):
        return value.unwrap()

    return value


def _load_repaired_document(
    tmp_path: Path,
    *,
    defaults: str,
    config: str,
    repair_engine: TomlRepairEngine | None = None,
):
    defaults_path = _write_toml(tmp_path, "defaults.toml", defaults)
    config_path = _write_toml(tmp_path, "config.toml", config)
    schema = TomlSchemaLoader().load_schema([defaults_path])
    document = TomlAdapter().load_document(config_path)
    return (repair_engine or TomlRepairEngine()).repair(schema, document)


def test_toml_repair_engine_repairs_invalid_and_missing_keys_preserving_unknown_content(
    tmp_path: Path,
) -> None:
    repaired = _load_repaired_document(
        tmp_path,
        defaults="""
        [service]
        enabled = true
        retries = 3
        mode = { _default_value = "INFO", _allowed_values = ["DEBUG", "INFO"] }
        point = { x = 1, y = 2 }
        """,
        config="""
        [service]
        enabled = "true"
        mode = "DEBUG"
        point = 7
        extra = "user"

        [custom]
        feature = true
        """,
    )

    assert _unwrap(repaired["service"]["enabled"]) is True
    assert _unwrap(repaired["service"]["retries"]) == 3
    assert _unwrap(repaired["service"]["mode"]) == "DEBUG"
    assert _unwrap(repaired["service"]["point"]) == {"x": 1, "y": 2}
    assert _unwrap(repaired["service"]["extra"]) == "user"
    assert _unwrap(repaired["custom"]["feature"]) is True

    rendered = repaired.as_string()
    assert "point = {x = 1, y = 2}" in rendered
    assert "[service.point]" not in rendered


def test_toml_repair_engine_repairs_custom_validator_failures_to_defaults(tmp_path: Path) -> None:
    registry = InMemoryValidatorRegistry()
    registry.register(
        "no-spaces",
        lambda value: "must not contain spaces" if " " in value else None,
    )

    repaired = _load_repaired_document(
        tmp_path,
        defaults="""
        [service]
        name = { _default_value = "BoundConfig", _validator = "no-spaces" }
        """,
        config="""
        [service]
        name = "Bound Config"
        """,
        repair_engine=TomlRepairEngine(
            validation_engine=TomlValidationEngine(validator_registry=registry)
        ),
    )

    assert _unwrap(repaired["service"]["name"]) == "BoundConfig"


def test_toml_repair_engine_raises_for_unknown_validator_names(tmp_path: Path) -> None:
    with pytest.raises(UnknownValidatorError) as excinfo:
        _load_repaired_document(
            tmp_path,
            defaults="""
            [service]
            name = { _default_value = "BoundConfig", _validator = "missing-validator" }
            """,
            config="""
            [service]
            name = "BoundConfig"
            """,
            repair_engine=TomlRepairEngine(
                validation_engine=TomlValidationEngine(
                    validator_registry=InMemoryValidatorRegistry()
                )
            ),
        )

    assert excinfo.value.validator_name == "missing-validator"
    assert excinfo.value.location == ("service", "name")


def test_toml_repair_engine_replaces_invalid_managed_sections_with_default_table(
    tmp_path: Path,
) -> None:
    repaired = _load_repaired_document(
        tmp_path,
        defaults="""
        [service]
        enabled = true
        retries = 3
        """,
        config="""
        service = "bad"

        [custom]
        feature = true
        """,
    )

    assert _unwrap(repaired["service"]["enabled"]) is True
    assert _unwrap(repaired["service"]["retries"]) == 3
    assert _unwrap(repaired["custom"]["feature"]) is True

    rendered = repaired.as_string()
    assert "service = \"bad\"" not in rendered
    assert "[service]\nenabled = true\nretries = 3" in rendered


def test_toml_repair_engine_preserves_unknown_top_level_keys(tmp_path: Path) -> None:
    repaired = _load_repaired_document(
        tmp_path,
        defaults="""
        [service]
        enabled = true
        retries = 3
        """,
        config="""
        title = "user-defined"

        [service]
        enabled = "true"
        """,
    )

    assert _unwrap(repaired["title"]) == "user-defined"
    assert _unwrap(repaired["service"]["enabled"]) is True
    assert _unwrap(repaired["service"]["retries"]) == 3

    rendered = repaired.as_string()
    assert 'title = "user-defined"' in rendered
    assert rendered.index('title = "user-defined"') < rendered.index("[service]")


def test_bound_config_repair_writes_comment_preserving_update(tmp_path: Path) -> None:
    defaults_path = _write_toml(
        tmp_path,
        "defaults.toml",
        """
        [service]
        enabled = true
        retries = 3

        [ui]
        theme = "dark"
        """,
    )
    config_path = _write_toml(
        tmp_path,
        "config.toml",
        """
        # file comment

        [service] # managed section comment
        enabled = "true"
        extra = "user"

        [custom] # user section comment
        feature = true # user inline comment
        """,
    )

    repaired_document = BoundConfig(
        config_path=config_path,
        defaults_paths=(defaults_path,),
    ).repair()

    assert _unwrap(repaired_document["service"]["enabled"]) is True
    assert _unwrap(repaired_document["service"]["retries"]) == 3

    rendered = config_path.read_text(encoding="utf-8")
    assert "# file comment" in rendered
    assert "[service] # managed section comment" in rendered
    assert 'enabled = true' in rendered
    assert 'extra = "user"' in rendered
    assert "[custom] # user section comment" in rendered
    assert "feature = true # user inline comment" in rendered
    assert '[ui]\ntheme = "dark"' in rendered
    assert rendered.index("[custom] # user section comment") < rendered.index("[ui]")


def test_bound_config_repair_uses_its_configured_validator_registry(tmp_path: Path) -> None:
    defaults_path = _write_toml(
        tmp_path,
        "defaults.toml",
        """
        [service]
        name = { _default_value = "BoundConfig", _validator = "no-spaces" }
        """,
    )
    config_path = _write_toml(
        tmp_path,
        "config.toml",
        """
        [service]
        name = "Bound Config"
        """,
    )
    registry = InMemoryValidatorRegistry()
    bound_config = BoundConfig(
        config_path=config_path,
        defaults_paths=(defaults_path,),
        validator_registry=registry,
    )
    bound_config.register_validator(
        "no-spaces",
        lambda value: "must not contain spaces" if " " in value else None,
    )

    repaired_document = bound_config.repair(dry_run=True)

    assert _unwrap(repaired_document["service"]["name"]) == "BoundConfig"


def test_bound_config_repair_dry_run_does_not_write_changes(tmp_path: Path) -> None:
    defaults_path = _write_toml(
        tmp_path,
        "defaults.toml",
        """
        [service]
        enabled = true
        retries = 3
        """,
    )
    config_path = _write_toml(
        tmp_path,
        "config.toml",
        """
        [service]
        enabled = "true"
        """,
    )
    original = config_path.read_text(encoding="utf-8")

    repaired_document = BoundConfig(
        config_path=config_path,
        defaults_paths=(defaults_path,),
    ).repair(dry_run=True)

    assert _unwrap(repaired_document["service"]["enabled"]) is True
    assert _unwrap(repaired_document["service"]["retries"]) == 3
    assert config_path.read_text(encoding="utf-8") == original
