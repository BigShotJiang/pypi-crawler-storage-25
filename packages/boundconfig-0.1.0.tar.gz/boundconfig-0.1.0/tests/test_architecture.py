from __future__ import annotations

import importlib
import inspect

import pytest

ARCHITECTURE_EXPORTS = [
    ("boundconfig.adapters", "DocumentAdapter", "boundconfig.adapters.base"),
    ("boundconfig.schema", "SchemaLoader", "boundconfig.schema.loader"),
    ("boundconfig.merge", "MergeEngine", "boundconfig.merge.engine"),
    ("boundconfig.validation", "ValidationEngine", "boundconfig.validation.engine"),
    ("boundconfig.repair", "RepairEngine", "boundconfig.repair.engine"),
    ("boundconfig.validators", "ValidatorRegistry", "boundconfig.validators.registry"),
]

ABSTRACT_METHODS = {
    "DocumentAdapter": frozenset({"load_document", "dump_document"}),
    "SchemaLoader": frozenset({"load_schema"}),
    "MergeEngine": frozenset({"merge"}),
    "ValidationEngine": frozenset({"validate"}),
    "RepairEngine": frozenset({"repair"}),
    "ValidatorRegistry": frozenset({"register", "get"}),
}


@pytest.mark.parametrize(("module_name", "symbol_name", "defining_module"), ARCHITECTURE_EXPORTS)
def test_architecture_exports_are_available(
    module_name: str,
    symbol_name: str,
    defining_module: str,
) -> None:
    module = importlib.import_module(module_name)
    symbol = getattr(module, symbol_name)

    assert symbol.__name__ == symbol_name
    assert symbol.__module__ == defining_module


@pytest.mark.parametrize(("module_name", "symbol_name", "_"), ARCHITECTURE_EXPORTS)
def test_architecture_interfaces_are_abstract(
    module_name: str,
    symbol_name: str,
    _: str,
) -> None:
    module = importlib.import_module(module_name)
    interface = getattr(module, symbol_name)

    assert inspect.isabstract(interface)
    assert interface.__abstractmethods__ == ABSTRACT_METHODS[symbol_name]
