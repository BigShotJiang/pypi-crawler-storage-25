from __future__ import annotations

from pathlib import Path

from boundconfig.adapters import TomlAdapter


def test_toml_adapter_is_exported() -> None:
    assert TomlAdapter.__name__ == "TomlAdapter"


def test_toml_adapter_round_trips_without_reformatting(tmp_path: Path) -> None:
    source = (
        "# file comment\n"
        'title = "BoundConfig"\n'
        "\n"
        "[ui] # section comment\n"
        "# key comment\n"
        "show_toasts = true # inline comment\n"
    )
    source_path = tmp_path / "config.toml"
    output_path = tmp_path / "roundtrip.toml"
    source_path.write_text(source, encoding="utf-8")

    adapter = TomlAdapter()
    document = adapter.load_document(source_path)
    adapter.dump_document(document, output_path)

    assert output_path.read_text(encoding="utf-8") == source


def test_toml_adapter_preserves_comments_and_order_on_write(tmp_path: Path) -> None:
    source = (
        "# file comment\n"
        'title = "BoundConfig"\n'
        "\n"
        "[ui] # section comment\n"
        "# key comment\n"
        "show_toasts = true # inline comment\n"
    )
    source_path = tmp_path / "config.toml"
    output_path = tmp_path / "updated.toml"
    source_path.write_text(source, encoding="utf-8")

    adapter = TomlAdapter()
    document = adapter.load_document(source_path)
    document["title"] = "BoundConfig Next"
    adapter.dump_document(document, output_path)

    rendered = output_path.read_text(encoding="utf-8")

    assert "# file comment" in rendered
    assert "[ui] # section comment" in rendered
    assert "# key comment" in rendered
    assert "show_toasts = true # inline comment" in rendered
    assert rendered.index('# file comment') < rendered.index('title = "BoundConfig Next"')
    assert rendered.index('title = "BoundConfig Next"') < rendered.index("[ui] # section comment")
