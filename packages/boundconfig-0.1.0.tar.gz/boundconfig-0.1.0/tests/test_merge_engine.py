from __future__ import annotations

from pathlib import Path
from typing import Any

from boundconfig.adapters import TomlAdapter
from boundconfig.merge.engine import TomlMergeEngine
from boundconfig.schema import TomlSchemaLoader


def _write_toml(tmp_path: Path, name: str, content: str) -> Path:
    path = tmp_path / name
    path.write_text(content.strip(), encoding="utf-8")
    return path


def _unwrap(value: Any) -> Any:
    if hasattr(value, "unwrap"):
        return value.unwrap()

    return value


def _load_merged_document(tmp_path: Path, *, defaults: str, config: str):
    defaults_path = _write_toml(tmp_path, "defaults.toml", defaults)
    config_path = _write_toml(tmp_path, "config.toml", config)
    schema = TomlSchemaLoader().load_schema([defaults_path])
    document = TomlAdapter().load_document(config_path)
    return TomlMergeEngine().merge(schema, document)


def test_toml_merge_engine_adds_missing_managed_content_and_preserves_unknown_user_content(
    tmp_path: Path,
) -> None:
    merged = _load_merged_document(
        tmp_path,
        defaults="""
        [logging]
        level = "INFO"
        retries = 3

        [ui]
        show_toasts = true
        point = { x = 1, y = 2 }
        """,
        config="""
        [logging]
        level = "DEBUG"
        extra = "user"

        [extra]
        enabled = true
        """,
    )

    assert _unwrap(merged["logging"]["level"]) == "DEBUG"
    assert _unwrap(merged["logging"]["retries"]) == 3
    assert _unwrap(merged["logging"]["extra"]) == "user"
    assert _unwrap(merged["extra"]["enabled"]) is True
    assert _unwrap(merged["ui"]["show_toasts"]) is True
    assert _unwrap(merged["ui"]["point"]) == {"x": 1, "y": 2}

    rendered = merged.as_string()
    assert "point = {x = 1, y = 2}" in rendered
    assert "[ui.point]" not in rendered


def test_toml_merge_engine_does_not_repair_existing_invalid_managed_values(
    tmp_path: Path,
) -> None:
    merged = _load_merged_document(
        tmp_path,
        defaults="""
        [service]
        enabled = true
        retries = 3
        point = { x = 1, y = 2 }
        """,
        config="""
        [service]
        enabled = "true"
        point = 7
        """,
    )

    assert _unwrap(merged["service"]["enabled"]) == "true"
    assert _unwrap(merged["service"]["point"]) == 7
    assert _unwrap(merged["service"]["retries"]) == 3

    rendered = merged.as_string()
    assert 'enabled = "true"' in rendered
    assert "point = 7" in rendered


def test_toml_merge_engine_preserves_unknown_top_level_keys(tmp_path: Path) -> None:
    merged = _load_merged_document(
        tmp_path,
        defaults="""
        [logging]
        level = "INFO"
        retries = 3
        """,
        config="""
        title = "user-defined"

        [logging]
        level = "DEBUG"
        """,
    )

    assert _unwrap(merged["title"]) == "user-defined"
    assert _unwrap(merged["logging"]["level"]) == "DEBUG"
    assert _unwrap(merged["logging"]["retries"]) == 3

    rendered = merged.as_string()
    assert 'title = "user-defined"' in rendered
    assert rendered.index('title = "user-defined"') < rendered.index("[logging]")


def test_toml_merge_engine_leaves_invalid_managed_sections_untouched(tmp_path: Path) -> None:
    merged = _load_merged_document(
        tmp_path,
        defaults="""
        [logging]
        level = "INFO"
        retries = 3
        """,
        config='logging = "user-defined"',
    )

    assert _unwrap(merged["logging"]) == "user-defined"
    assert merged.as_string().strip() == 'logging = "user-defined"'
