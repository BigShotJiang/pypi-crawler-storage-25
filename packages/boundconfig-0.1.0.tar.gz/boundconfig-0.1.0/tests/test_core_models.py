from __future__ import annotations

from boundconfig.exceptions import (
    DuplicateDefinitionError,
    DuplicateFieldDefinitionError,
    DuplicateSectionDefinitionError,
    InvalidSchemaDeclarationError,
    ReservedNameError,
    ReservedSectionNameError,
    SchemaError,
    UnknownReservedKeyError,
    UnknownValidatorError,
    ValidationFailure,
    ValidatorExecutionError,
)
from boundconfig.schema import BoundSchema, DeclarationKind, SchemaField, SchemaSection
from boundconfig.validation import ValidationIssue, ValidationReport, ValidationWarning


def test_schema_models_capture_sections_fields_and_reserved_name_policy() -> None:
    field = SchemaField(
        name="level",
        default_value="INFO",
        declaration_kind=DeclarationKind.ENHANCED,
        declared_type="str",
        allowed_values=["DEBUG", "INFO", "WARN", "ERROR"],
        validator_name="named-check",
    )
    section = SchemaSection(name="logging", fields=[field])
    schema = BoundSchema(sections=[section])

    assert schema.section_names == ("logging",)
    assert schema.get_section("logging") == section
    assert section.field_names == ("level",)
    assert section.get_field("level") == field
    assert field.allowed_values == ("DEBUG", "INFO", "WARN", "ERROR")
    assert field.validator_name == "named-check"

    policy = schema.reserved_name_policy
    assert policy.is_reserved_section("__metadata__")
    assert policy.is_reserved_key("_default_value")
    assert policy.is_known_declaration_key("_default_value")
    assert policy.is_known_declaration_key("_validator")
    assert policy.unknown_reserved_keys(["_default_value", "_custom", "level"]) == ("_custom",)

    extended_policy = policy.with_reserved_sections({"internal"})
    assert extended_policy.is_reserved_section("internal")
    assert not policy.is_reserved_section("internal")


def test_validation_report_tracks_issues_and_warnings() -> None:
    issue = ValidationIssue(
        code="missing-managed-key",
        message="Managed key is missing.",
        location=["logging", "level"],
    )
    warning = ValidationWarning(
        code="unknown-user-key",
        message="Unknown key will be preserved.",
        location=["logging", "extra"],
    )
    report = ValidationReport(issues=[issue], warnings=[warning])

    assert issue.dotted_path == "logging.level"
    assert warning.dotted_path == "logging.extra"
    assert report.issue_count == 1
    assert report.warning_count == 1
    assert not report.is_valid


def test_exception_hierarchy_preserves_context() -> None:
    duplicate_section = DuplicateSectionDefinitionError("logging")
    duplicate_field = DuplicateFieldDefinitionError("logging", "level")
    invalid_declaration = InvalidSchemaDeclarationError(
        "Declaration must provide a default value.",
        section_name="logging",
        field_name="level",
    )
    unknown_reserved_key = UnknownReservedKeyError(
        "_custom_validator",
        section_name="logging",
        field_name="level",
    )
    unknown_validator = UnknownValidatorError(
        "named-check",
        section_name="logging",
        field_name="level",
    )
    reserved_section = ReservedSectionNameError("__metadata__")
    report = ValidationReport(
        issues=[
            ValidationIssue(
                code="invalid-type",
                message="Expected int.",
                location=["server", "port"],
            )
        ]
    )
    failure = ValidationFailure(report)
    validator_error = ValidatorExecutionError(
        "named-check",
        section_name="logging",
        field_name="level",
        reason="raised RuntimeError: boom",
    )

    assert isinstance(duplicate_section, DuplicateDefinitionError)
    assert isinstance(duplicate_field, DuplicateDefinitionError)
    assert isinstance(invalid_declaration, SchemaError)
    assert invalid_declaration.location == ("logging", "level")
    assert isinstance(unknown_reserved_key, InvalidSchemaDeclarationError)
    assert unknown_reserved_key.key_name == "_custom_validator"
    assert isinstance(unknown_validator, InvalidSchemaDeclarationError)
    assert unknown_validator.validator_name == "named-check"
    assert isinstance(reserved_section, ReservedNameError)
    assert failure.report is report
    assert str(failure) == "Validation failed with 1 issue(s)."
    assert "logging.level" in str(validator_error)
