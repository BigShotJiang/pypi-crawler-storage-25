from __future__ import annotations

from pathlib import Path

import pytest

from boundconfig.adapters import TomlAdapter
from boundconfig.exceptions import (
    InvalidSchemaDeclarationError,
    UnknownValidatorError,
    ValidatorExecutionError,
)
from boundconfig.schema import TomlSchemaLoader
from boundconfig.validation import TomlValidationEngine
from boundconfig.validators import InMemoryValidatorRegistry


def _write_toml(tmp_path: Path, name: str, content: str) -> Path:
    path = tmp_path / name
    path.write_text(content.strip(), encoding="utf-8")
    return path


def _load_report(
    tmp_path: Path,
    *,
    defaults: str,
    config: str,
    validation_engine: TomlValidationEngine | None = None,
):
    defaults_path = _write_toml(tmp_path, "defaults.toml", defaults)
    config_path = _write_toml(tmp_path, "config.toml", config)
    schema = TomlSchemaLoader().load_schema([defaults_path])
    document = TomlAdapter().load_document(config_path)
    return (validation_engine or TomlValidationEngine()).validate(schema, document)


def test_toml_validation_engine_reports_unknown_user_keys_and_sections_as_warnings(
    tmp_path: Path,
) -> None:
    report = _load_report(
        tmp_path,
        defaults="""
        [logging]
        level = { _default_value = "INFO", _allowed_values = ["DEBUG", "INFO", "WARN"] }
        retries = { _default_value = 3, _min = 1, _max = 5 }
        """,
        config="""
        [logging]
        level = "INFO"
        retries = 3
        extra = "user"

        [extra]
        enabled = true
        """,
    )

    assert report.is_valid
    assert [(warning.code, warning.location) for warning in report.warnings] == [
        ("unknown-user-key", ("logging", "extra")),
        ("unknown-user-section", ("extra",)),
    ]


def test_toml_validation_engine_reports_unknown_top_level_keys_as_warnings(
    tmp_path: Path,
) -> None:
    report = _load_report(
        tmp_path,
        defaults="""
        [logging]
        level = "INFO"
        """,
        config="""
        title = "user-defined"

        [logging]
        level = "INFO"
        """,
    )

    assert report.is_valid
    assert [(warning.code, warning.location) for warning in report.warnings] == [
        ("unknown-user-key", ("title",)),
    ]


def test_toml_validation_engine_reports_missing_managed_keys(tmp_path: Path) -> None:
    report = _load_report(
        tmp_path,
        defaults="""
        [logging]
        level = "INFO"
        retries = 3

        [ui]
        show_toasts = true
        """,
        config="""
        [logging]
        level = "INFO"
        """,
    )

    assert not report.is_valid
    assert [(issue.code, issue.location) for issue in report.issues] == [
        ("missing-managed-key", ("logging", "retries")),
        ("missing-managed-key", ("ui", "show_toasts")),
    ]


def test_toml_validation_engine_validates_core_types_and_constraints(tmp_path: Path) -> None:
    report = _load_report(
        tmp_path,
        defaults="""
        [service]
        name = { _default_value = "BoundConfig", _min_length = 3, _max_length = 12 }
        mode = { _default_value = "INFO", _allowed_values = ["DEBUG", "INFO"] }
        port = { _default_value = 8080, _min = 1, _max = 65535 }
        ratio = 0.5
        enabled = true
        tags = { _default_value = ["stable"], _min_length = 1, _max_length = 3 }
        """,
        config="""
        [service]
        name = "no"
        mode = "TRACE"
        port = 70000
        ratio = 1
        enabled = "true"
        tags = []
        """,
    )

    assert not report.is_valid
    assert [(issue.code, issue.location) for issue in report.issues] == [
        ("value-too-short", ("service", "name")),
        ("disallowed-value", ("service", "mode")),
        ("value-above-maximum", ("service", "port")),
        ("invalid-type", ("service", "ratio")),
        ("invalid-type", ("service", "enabled")),
        ("value-too-short", ("service", "tags")),
    ]


def test_toml_validation_engine_runs_registered_custom_validators_after_builtin_checks(
    tmp_path: Path,
) -> None:
    registry = InMemoryValidatorRegistry()
    registry.register(
        "no-spaces",
        lambda value: "must not contain spaces" if " " in value else None,
    )

    report = _load_report(
        tmp_path,
        defaults="""
        [service]
        name = { _default_value = "BoundConfig", _min_length = 3, _validator = "no-spaces" }
        """,
        config="""
        [service]
        name = "Bound Config"
        """,
        validation_engine=TomlValidationEngine(validator_registry=registry),
    )

    assert not report.is_valid
    assert [(issue.code, issue.location) for issue in report.issues] == [
        ("custom-validator-failed", ("service", "name")),
    ]
    assert "must not contain spaces" in report.issues[0].message


def test_toml_validation_engine_accepts_values_that_pass_custom_validation(tmp_path: Path) -> None:
    registry = InMemoryValidatorRegistry()
    registry.register(
        "no-spaces",
        lambda value: "must not contain spaces" if " " in value else None,
    )

    report = _load_report(
        tmp_path,
        defaults="""
        [service]
        name = { _default_value = "BoundConfig", _min_length = 3, _validator = "no-spaces" }
        """,
        config="""
        [service]
        name = "BoundConfig"
        """,
        validation_engine=TomlValidationEngine(validator_registry=registry),
    )

    assert report.is_valid
    assert report.issues == ()
    assert report.warnings == ()


def test_toml_validation_engine_raises_for_unknown_validator_name(tmp_path: Path) -> None:
    with pytest.raises(UnknownValidatorError) as excinfo:
        _load_report(
            tmp_path,
            defaults="""
            [service]
            name = { _default_value = "BoundConfig", _validator = "missing-validator" }
            """,
            config="""
            [service]
            name = "BoundConfig"
            """,
            validation_engine=TomlValidationEngine(
                validator_registry=InMemoryValidatorRegistry()
            ),
        )

    assert excinfo.value.validator_name == "missing-validator"
    assert excinfo.value.location == ("service", "name")


def test_toml_validation_engine_raises_when_custom_validator_raises(tmp_path: Path) -> None:
    registry = InMemoryValidatorRegistry()

    def _explode(value: object) -> str | None:
        raise RuntimeError("boom")

    registry.register("explode", _explode)

    with pytest.raises(ValidatorExecutionError, match="boom") as excinfo:
        _load_report(
            tmp_path,
            defaults="""
            [service]
            name = { _default_value = "BoundConfig", _validator = "explode" }
            """,
            config="""
            [service]
            name = "BoundConfig"
            """,
            validation_engine=TomlValidationEngine(validator_registry=registry),
        )

    assert excinfo.value.validator_name == "explode"
    assert excinfo.value.section_name == "service"
    assert excinfo.value.field_name == "name"


def test_toml_validation_engine_validates_temporal_scalar_types_and_constraints(
    tmp_path: Path,
) -> None:
    report = _load_report(
        tmp_path,
        defaults="\n".join(
            [
                "[release]",
                (
                    'published_at = { _default_value = 1979-05-27T07:32:00Z, '
                    '_type = "offset_datetime", _min = 1979-05-27T00:00:00Z, '
                    "_max = 1979-05-28T00:00:00Z, _allowed_values = "
                    "[1979-05-27T07:32:00Z, 1979-05-27T08:32:00Z] }"
                ),
                (
                    'scheduled_at = { _default_value = 1979-05-27T07:32:00, '
                    '_type = "local_datetime", _min = 1979-05-27T07:00:00, '
                    "_max = 1979-05-27T08:00:00 }"
                ),
                (
                    "release_date = { _default_value = 1979-05-27, "
                    '_type = "local_date", _allowed_values = '
                    "[1979-05-27, 1979-05-28] }"
                ),
                (
                    "alarm_at = { _default_value = 07:32:00, "
                    '_type = "local_time", _min = 07:00:00, _max = 08:00:00 }'
                ),
            ]
        ),
        config="""
        [release]
        published_at = 1979-05-27T08:32:00Z
        scheduled_at = 1979-05-27T07:45:00
        release_date = 1979-05-28
        alarm_at = 07:45:00
        """,
    )

    assert report.is_valid
    assert report.issues == ()
    assert report.warnings == ()


def test_toml_validation_engine_does_not_coerce_strings_to_temporal_values(
    tmp_path: Path,
) -> None:
    report = _load_report(
        tmp_path,
        defaults="\n".join(
            [
                "[release]",
                (
                    'published_at = { _default_value = 1979-05-27T07:32:00Z, '
                    '_type = "offset_datetime", _allowed_values = '
                    "[1979-05-27T07:32:00Z] }"
                ),
                (
                    'scheduled_at = { _default_value = 1979-05-27T07:32:00, '
                    '_type = "local_datetime", _max = 1979-05-27T08:00:00 }'
                ),
                (
                    "release_date = { _default_value = 1979-05-27, "
                    '_type = "local_date", _allowed_values = '
                    "[1979-05-27, 1979-05-28] }"
                ),
                (
                    "alarm_at = { _default_value = 07:32:00, "
                    '_type = "local_time", _max = 08:00:00 }'
                ),
            ]
        ),
        config="""
        [release]
        published_at = "1979-05-27T07:32:00Z"
        scheduled_at = 1979-05-27T08:30:00
        release_date = 1979-05-29
        alarm_at = 08:30:00
        """,
    )

    assert not report.is_valid
    assert [(issue.code, issue.location) for issue in report.issues] == [
        ("invalid-type", ("release", "published_at")),
        ("value-above-maximum", ("release", "scheduled_at")),
        ("disallowed-value", ("release", "release_date")),
        ("value-above-maximum", ("release", "alarm_at")),
    ]


def test_toml_validation_engine_rejects_mixed_aware_and_naive_datetime_constraints(
    tmp_path: Path,
) -> None:
    with pytest.raises(InvalidSchemaDeclarationError, match="same temporal kind") as excinfo:
        _load_report(
            tmp_path,
            defaults="\n".join(
                [
                    "[release]",
                    (
                        "published_at = { _default_value = 1979-05-27T07:32:00Z, "
                        '_type = "offset_datetime", _min = 1979-05-27T07:00:00 }'
                    ),
                ]
            ),
            config="""
            [release]
            published_at = 1979-05-27T07:32:00Z
            """,
        )

    assert excinfo.value.location == ("release", "published_at")


def test_toml_validation_engine_rejects_temporal_allowed_values_with_mismatched_kind(
    tmp_path: Path,
) -> None:
    with pytest.raises(InvalidSchemaDeclarationError, match="_allowed_values") as excinfo:
        _load_report(
            tmp_path,
            defaults="\n".join(
                [
                    "[release]",
                    (
                        "release_date = { _default_value = 1979-05-27, "
                        '_type = "local_date", _allowed_values = '
                        "[1979-05-27T07:32:00] }"
                    ),
                ]
            ),
            config="""
            [release]
            release_date = 1979-05-27
            """,
        )

    assert excinfo.value.location == ("release", "release_date")


def test_toml_validation_engine_rejects_obvious_inline_table_type_mismatches(
    tmp_path: Path,
) -> None:
    report = _load_report(
        tmp_path,
        defaults="""
        [ui]
        point = { x = 1, y = 2 }
        """,
        config="""
        [ui]
        point = 7
        """,
    )

    assert [(issue.code, issue.location) for issue in report.issues] == [
        ("invalid-type", ("ui", "point")),
    ]


def test_toml_validation_engine_only_checks_inline_tables_shallowly_for_now(
    tmp_path: Path,
) -> None:
    report = _load_report(
        tmp_path,
        defaults="""
        [ui]
        point = { x = 1, y = 2 }
        """,
        config="""
        [ui]
        point = { x = "bad", y = [] }
        """,
    )

    assert report.is_valid
    assert report.issues == ()
    assert report.warnings == ()


def test_toml_validation_engine_rejects_inline_table_range_constraints_until_recursive_support(
    tmp_path: Path,
) -> None:
    with pytest.raises(InvalidSchemaDeclarationError, match="future work") as excinfo:
        _load_report(
            tmp_path,
            defaults="""
            [geometry]
            point = { _default_value = { x = 1, y = 2 }, _min = { x = 0, y = 0 } }
            """,
            config="""
            [geometry]
            point = { x = 5, y = 5 }
            """,
        )

    assert excinfo.value.location == ("geometry", "point")
