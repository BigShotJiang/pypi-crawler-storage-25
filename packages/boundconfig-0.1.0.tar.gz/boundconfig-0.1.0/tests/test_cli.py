from __future__ import annotations

import argparse
import os
import subprocess
import sys
import textwrap
from pathlib import Path

import pytest

from boundconfig.cli import build_parser, main


def _write_toml(tmp_path: Path, name: str, content: str) -> Path:
    path = tmp_path / name
    path.write_text(textwrap.dedent(content).strip(), encoding="utf-8")
    return path


def test_parser_uses_boundconfig_program_name() -> None:
    parser = build_parser()

    assert parser.prog == "boundconfig"


def test_cli_surface_does_not_change_for_custom_validator_registry_step() -> None:
    parser = build_parser()
    subparsers_action = next(
        action for action in parser._actions if isinstance(action, argparse._SubParsersAction)
    )

    assert set(subparsers_action.choices) == {"init", "validate"}
    for subcommand in ("init", "validate"):
        option_strings = {
            option
            for action in subparsers_action.choices[subcommand]._actions
            for option in action.option_strings
        }
        assert option_strings == {
            "-h",
            "--help",
            "--config",
            "--defaults",
            "--dry-run",
            "--verbose",
            "--suppress-warnings",
        }


def test_help_exits_cleanly(capsys: pytest.CaptureFixture[str]) -> None:
    with pytest.raises(SystemExit) as excinfo:
        main(["--help"])

    assert excinfo.value.code == 0
    assert "boundconfig" in capsys.readouterr().out


def test_module_entrypoint_help_runs() -> None:
    project_root = Path(__file__).resolve().parents[1]
    env = os.environ.copy()
    existing_pythonpath = env.get("PYTHONPATH")
    env["PYTHONPATH"] = str(project_root / "src")
    if existing_pythonpath:
        env["PYTHONPATH"] = os.pathsep.join([env["PYTHONPATH"], existing_pythonpath])

    result = subprocess.run(
        [sys.executable, "-m", "boundconfig", "--help"],
        capture_output=True,
        check=False,
        cwd=project_root,
        env=env,
        text=True,
    )

    assert result.returncode == 0
    assert "boundconfig" in result.stdout


def test_cli_init_creates_missing_config_from_multiple_defaults(tmp_path: Path) -> None:
    defaults_a = _write_toml(
        tmp_path,
        "defaults-a.toml",
        """
        [logging]
        level = "INFO"
        """,
    )
    defaults_b = _write_toml(
        tmp_path,
        "defaults-b.toml",
        """
        [ui]
        show_toasts = true
        """,
    )
    config_path = tmp_path / "nested" / "app.toml"

    exit_code = main(
        [
            "init",
            "--config",
            str(config_path),
            "--defaults",
            str(defaults_a),
            str(defaults_b),
        ]
    )

    assert exit_code == 0
    assert config_path.exists()

    rendered = config_path.read_text(encoding="utf-8")
    assert '[logging]\nlevel = "INFO"' in rendered
    assert "[ui]\nshow_toasts = true" in rendered


def test_cli_init_preserves_existing_invalid_managed_values_and_unknown_user_content(
    tmp_path: Path,
) -> None:
    defaults_path = _write_toml(
        tmp_path,
        "defaults.toml",
        """
        [service]
        enabled = true
        retries = 3
        point = { x = 1, y = 2 }
        """,
    )
    config_path = _write_toml(
        tmp_path,
        "config.toml",
        """
        [service]
        enabled = "true"
        point = 7
        extra = "user"

        [custom]
        feature = true
        """,
    )

    exit_code = main(
        [
            "init",
            "--config",
            str(config_path),
            "--defaults",
            str(defaults_path),
        ]
    )

    assert exit_code == 0

    rendered = config_path.read_text(encoding="utf-8")
    assert 'enabled = "true"' in rendered
    assert "retries = 3" in rendered
    assert "point = 7" in rendered
    assert 'extra = "user"' in rendered
    assert "[custom]\nfeature = true" in rendered


def test_cli_init_dry_run_does_not_write_config(
    tmp_path: Path,
    capsys: pytest.CaptureFixture[str],
) -> None:
    defaults_path = _write_toml(
        tmp_path,
        "defaults.toml",
        """
        [service]
        retries = 3
        """,
    )
    config_path = tmp_path / "generated" / "config.toml"

    exit_code = main(
        [
            "init",
            "--config",
            str(config_path),
            "--defaults",
            str(defaults_path),
            "--dry-run",
        ]
    )

    assert exit_code == 0
    assert not config_path.exists()
    assert capsys.readouterr() == ("", "")


@pytest.mark.parametrize(
    ("extra_args", "expected_message"),
    [
        ([], "Initialized"),
        (["--dry-run"], "Dry run completed for"),
    ],
)
def test_cli_init_verbose_reports_summary(
    tmp_path: Path,
    capsys: pytest.CaptureFixture[str],
    extra_args: list[str],
    expected_message: str,
) -> None:
    defaults_path = _write_toml(
        tmp_path,
        "defaults.toml",
        """
        [service]
        retries = 3
        """,
    )
    config_path = tmp_path / "generated" / "config.toml"

    exit_code = main(
        [
            "init",
            "--config",
            str(config_path),
            "--defaults",
            str(defaults_path),
            "--verbose",
            *extra_args,
        ]
    )

    assert exit_code == 0
    captured = capsys.readouterr()
    assert expected_message in captured.out
    assert captured.err == ""


def test_cli_validate_reports_issues_and_warnings_by_default(
    tmp_path: Path,
    capsys: pytest.CaptureFixture[str],
) -> None:
    defaults_path = _write_toml(
        tmp_path,
        "defaults.toml",
        """
        [logging]
        level = "INFO"
        retries = 3
        """,
    )
    config_path = _write_toml(
        tmp_path,
        "config.toml",
        """
        [logging]
        level = "INFO"
        extra = "user"

        [custom]
        enabled = true
        """,
    )

    exit_code = main(
        [
            "validate",
            "--config",
            str(config_path),
            "--defaults",
            str(defaults_path),
        ]
    )

    assert exit_code == 1
    captured = capsys.readouterr()
    assert captured.out == ""
    assert "error [missing-managed-key]" in captured.err
    assert "Managed key 'logging.retries' is missing." in captured.err
    assert "warning [unknown-user-key]" in captured.err
    assert "warning [unknown-user-section]" in captured.err


def test_cli_validate_suppress_warnings_hides_warning_output(
    tmp_path: Path,
    capsys: pytest.CaptureFixture[str],
) -> None:
    defaults_path = _write_toml(
        tmp_path,
        "defaults.toml",
        """
        [logging]
        level = "INFO"
        retries = 3
        """,
    )
    config_path = _write_toml(
        tmp_path,
        "config.toml",
        """
        [logging]
        level = "INFO"
        extra = "user"
        """,
    )

    exit_code = main(
        [
            "validate",
            "--config",
            str(config_path),
            "--defaults",
            str(defaults_path),
            "--suppress-warnings",
        ]
    )

    assert exit_code == 1
    captured = capsys.readouterr()
    assert "error [missing-managed-key]" in captured.err
    assert "warning [unknown-user-key]" not in captured.err


def test_cli_validate_verbose_reports_failure_to_stderr(
    tmp_path: Path,
    capsys: pytest.CaptureFixture[str],
) -> None:
    defaults_path = _write_toml(
        tmp_path,
        "defaults.toml",
        """
        [logging]
        level = "INFO"
        retries = 3
        """,
    )
    config_path = _write_toml(
        tmp_path,
        "config.toml",
        """
        [logging]
        level = "INFO"
        """,
    )

    exit_code = main(
        [
            "validate",
            "--config",
            str(config_path),
            "--defaults",
            str(defaults_path),
            "--verbose",
        ]
    )

    assert exit_code == 1
    captured = capsys.readouterr()
    assert captured.out == ""
    assert "error [missing-managed-key]" in captured.err
    assert "Validation failed for" in captured.err
    assert "with 1 issue(s)." in captured.err


def test_cli_validate_verbose_reports_success(
    tmp_path: Path,
    capsys: pytest.CaptureFixture[str],
) -> None:
    defaults_path = _write_toml(
        tmp_path,
        "defaults.toml",
        """
        [logging]
        level = "INFO"
        retries = 3
        """,
    )
    config_path = _write_toml(
        tmp_path,
        "config.toml",
        """
        [logging]
        level = "INFO"
        retries = 3
        """,
    )

    exit_code = main(
        [
            "validate",
            "--config",
            str(config_path),
            "--defaults",
            str(defaults_path),
            "--verbose",
        ]
    )

    assert exit_code == 0
    captured = capsys.readouterr()
    assert "Validation passed for" in captured.out
    assert captured.err == ""


def test_cli_returns_error_for_duplicate_sections_across_defaults(
    tmp_path: Path,
    capsys: pytest.CaptureFixture[str],
) -> None:
    defaults_a = _write_toml(
        tmp_path,
        "defaults-a.toml",
        """
        [logging]
        level = "INFO"
        """,
    )
    defaults_b = _write_toml(
        tmp_path,
        "defaults-b.toml",
        """
        [logging]
        retries = 3
        """,
    )
    config_path = tmp_path / "config.toml"

    exit_code = main(
        [
            "init",
            "--config",
            str(config_path),
            "--defaults",
            str(defaults_a),
            str(defaults_b),
        ]
    )

    assert exit_code == 1
    assert not config_path.exists()
    captured = capsys.readouterr()
    assert captured.out == ""
    assert "error: Duplicate section definition for 'logging'." in captured.err
