from __future__ import annotations

from boundconfig import BoundConfig, __version__, register_validator


def test_public_api_exports_bound_config_and_register_validator() -> None:
    assert isinstance(BoundConfig(), BoundConfig)
    assert callable(register_validator)


def test_package_version_is_a_string() -> None:
    assert isinstance(__version__, str)
    assert __version__
