from __future__ import annotations

from datetime import date, datetime, time, timezone
from pathlib import Path

import pytest
from tomlkit.exceptions import KeyAlreadyPresent

from boundconfig.exceptions import (
    DuplicateSectionDefinitionError,
    InvalidSchemaDeclarationError,
    ReservedSectionNameError,
    UnknownReservedKeyError,
)
from boundconfig.schema import DeclarationKind, TomlSchemaLoader


def _write_defaults(tmp_path: Path, content: str, *, name: str = "defaults.toml") -> Path:
    defaults_path = tmp_path / name
    defaults_path.write_text(content.strip(), encoding="utf-8")
    return defaults_path


def test_toml_schema_loader_parses_shorthand_and_enhanced_defaults(tmp_path: Path) -> None:
    defaults_path = _write_defaults(
        tmp_path,
        "\n".join(
            [
                "[ui]",
                "show_toasts = true",
                "point = { x = 1, y = 2 }",
                "",
                "[logging]",
                (
                    'level = { _default_value = "INFO", _type = "str", '
                    '_allowed_values = ["DEBUG", "INFO", "WARN"], '
                    '_min_length = 4, _max_length = 5, _validator = "log-level" }'
                ),
                'retries = { _default_value = 3, _min = 1, _max = 5 }',
            ]
        ),
    )

    schema = TomlSchemaLoader().load_schema([defaults_path])

    assert schema.section_names == ("ui", "logging")

    ui = schema.get_section("ui")
    assert ui is not None

    show_toasts = ui.get_field("show_toasts")
    assert show_toasts is not None
    assert show_toasts.declaration_kind is DeclarationKind.SHORTHAND
    assert show_toasts.default_value is True

    point = ui.get_field("point")
    assert point is not None
    assert point.declaration_kind is DeclarationKind.SHORTHAND
    assert point.default_value == {"x": 1, "y": 2}

    logging = schema.get_section("logging")
    assert logging is not None

    level = logging.get_field("level")
    assert level is not None
    assert level.declaration_kind is DeclarationKind.ENHANCED
    assert level.default_value == "INFO"
    assert level.declared_type == "str"
    assert level.min_length == 4
    assert level.max_length == 5
    assert level.allowed_values == ("DEBUG", "INFO", "WARN")
    assert level.validator_name == "log-level"

    retries = logging.get_field("retries")
    assert retries is not None
    assert retries.declaration_kind is DeclarationKind.ENHANCED
    assert retries.default_value == 3
    assert retries.minimum == 1
    assert retries.maximum == 5


def test_toml_schema_loader_parses_temporal_enhanced_defaults(tmp_path: Path) -> None:
    defaults_path = _write_defaults(
        tmp_path,
        "\n".join(
            [
                "[release]",
                (
                    'published_at = { _default_value = 1979-05-27T07:32:00Z, '
                    '_type = "offset_datetime", _min = 1979-05-27T00:00:00Z, '
                    "_max = 1979-05-28T00:00:00Z, _allowed_values = "
                    "[1979-05-27T07:32:00Z, 1979-05-27T08:32:00Z] }"
                ),
                (
                    'scheduled_at = { _default_value = 1979-05-27T07:32:00, '
                    '_type = "local_datetime" }'
                ),
                (
                    "release_date = { _default_value = 1979-05-27, "
                    '_type = "local_date", _allowed_values = '
                    "[1979-05-27, 1979-05-28] }"
                ),
                (
                    "alarm_at = { _default_value = 07:32:00, "
                    '_type = "local_time", _min = 07:00:00, _max = 08:00:00 }'
                ),
            ]
        ),
    )

    schema = TomlSchemaLoader().load_schema([defaults_path])
    release = schema.get_section("release")

    assert release is not None

    published_at = release.get_field("published_at")
    assert published_at is not None
    assert published_at.default_value == datetime(1979, 5, 27, 7, 32, tzinfo=timezone.utc)
    assert published_at.declared_type == "offset_datetime"
    assert published_at.minimum == datetime(1979, 5, 27, 0, 0, tzinfo=timezone.utc)
    assert published_at.maximum == datetime(1979, 5, 28, 0, 0, tzinfo=timezone.utc)
    assert published_at.allowed_values == (
        datetime(1979, 5, 27, 7, 32, tzinfo=timezone.utc),
        datetime(1979, 5, 27, 8, 32, tzinfo=timezone.utc),
    )

    scheduled_at = release.get_field("scheduled_at")
    assert scheduled_at is not None
    assert scheduled_at.default_value == datetime(1979, 5, 27, 7, 32)
    assert scheduled_at.declared_type == "local_datetime"

    release_date = release.get_field("release_date")
    assert release_date is not None
    assert release_date.default_value == date(1979, 5, 27)
    assert release_date.declared_type == "local_date"
    assert release_date.allowed_values == (date(1979, 5, 27), date(1979, 5, 28))

    alarm_at = release.get_field("alarm_at")
    assert alarm_at is not None
    assert alarm_at.default_value == time(7, 32)
    assert alarm_at.declared_type == "local_time"
    assert alarm_at.minimum == time(7, 0)
    assert alarm_at.maximum == time(8, 0)


def test_toml_schema_loader_requires_default_value_for_enhanced_defaults(tmp_path: Path) -> None:
    defaults_path = _write_defaults(
        tmp_path,
        """
        [logging]
        level = { _type = "str" }
        """,
    )

    with pytest.raises(InvalidSchemaDeclarationError, match="_default_value") as excinfo:
        TomlSchemaLoader().load_schema([defaults_path])

    assert excinfo.value.location == ("logging", "level")


def test_toml_schema_loader_requires_validator_name_to_be_a_string(tmp_path: Path) -> None:
    defaults_path = _write_defaults(
        tmp_path,
        """
        [logging]
        level = { _default_value = "INFO", _validator = 7 }
        """,
    )

    with pytest.raises(InvalidSchemaDeclarationError, match="_validator") as excinfo:
        TomlSchemaLoader().load_schema([defaults_path])

    assert excinfo.value.location == ("logging", "level")


def test_toml_schema_loader_rejects_blank_validator_names(tmp_path: Path) -> None:
    defaults_path = _write_defaults(
        tmp_path,
        """
        [logging]
        level = { _default_value = "INFO", _validator = "   " }
        """,
    )

    with pytest.raises(InvalidSchemaDeclarationError, match="_validator") as excinfo:
        TomlSchemaLoader().load_schema([defaults_path])

    assert excinfo.value.location == ("logging", "level")


def test_toml_schema_loader_rejects_unknown_reserved_keys(tmp_path: Path) -> None:
    defaults_path = _write_defaults(
        tmp_path,
        """
        [logging]
        level = { _default_value = "INFO", _custom_validator = "named-check" }
        """,
    )

    with pytest.raises(UnknownReservedKeyError) as excinfo:
        TomlSchemaLoader().load_schema([defaults_path])

    assert excinfo.value.key_name == "_custom_validator"
    assert excinfo.value.location == ("logging", "level")


def test_toml_schema_loader_rejects_non_reserved_keys_in_enhanced_declarations(
    tmp_path: Path,
) -> None:
    defaults_path = _write_defaults(
        tmp_path,
        """
        [logging]
        level = { _default_value = "INFO", label = "info" }
        """,
    )

    with pytest.raises(InvalidSchemaDeclarationError, match="only contain reserved") as excinfo:
        TomlSchemaLoader().load_schema([defaults_path])

    assert excinfo.value.location == ("logging", "level")


def test_toml_schema_loader_rejects_reserved_sections(tmp_path: Path) -> None:
    defaults_path = _write_defaults(
        tmp_path,
        """
        [__metadata__]
        schema_version = 1
        """,
    )

    with pytest.raises(ReservedSectionNameError) as excinfo:
        TomlSchemaLoader().load_schema([defaults_path])

    assert excinfo.value.section_name == "__metadata__"


def test_toml_schema_loader_rejects_duplicate_sections_across_defaults_files(
    tmp_path: Path,
) -> None:
    first_defaults_path = _write_defaults(
        tmp_path,
        """
        [logging]
        level = "INFO"
        """,
        name="defaults-a.toml",
    )
    second_defaults_path = _write_defaults(
        tmp_path,
        """
        [logging]
        retries = 3
        """,
        name="defaults-b.toml",
    )

    with pytest.raises(DuplicateSectionDefinitionError) as excinfo:
        TomlSchemaLoader().load_schema([first_defaults_path, second_defaults_path])

    assert excinfo.value.section_name == "logging"


def test_toml_schema_loader_preserves_duplicate_field_rejection_from_toml_parser(
    tmp_path: Path,
) -> None:
    defaults_path = _write_defaults(
        tmp_path,
        """
        [logging]
        level = "INFO"
        level = "DEBUG"
        """,
    )

    with pytest.raises(KeyAlreadyPresent, match='Key "level" already exists'):
        TomlSchemaLoader().load_schema([defaults_path])


def test_toml_schema_loader_rejects_top_level_non_section_entries(tmp_path: Path) -> None:
    defaults_path = _write_defaults(
        tmp_path,
        """
        title = "BoundConfig"
        """,
    )

    with pytest.raises(InvalidSchemaDeclarationError, match="top-level TOML sections") as excinfo:
        TomlSchemaLoader().load_schema([defaults_path])

    assert excinfo.value.location == ("title",)


def test_toml_schema_loader_rejects_nested_tables_in_defaults(tmp_path: Path) -> None:
    defaults_path = _write_defaults(
        tmp_path,
        """
        [geometry]

        [geometry.point]
        x = 1
        """,
    )

    with pytest.raises(InvalidSchemaDeclarationError, match="Nested tables") as excinfo:
        TomlSchemaLoader().load_schema([defaults_path])

    assert excinfo.value.location == ("geometry", "point")


def test_toml_schema_loader_rejects_arrays_of_tables_in_defaults(tmp_path: Path) -> None:
    defaults_path = _write_defaults(
        tmp_path,
        """
        [logging]
        level = "INFO"

        [[logging.sinks]]
        name = "stdout"
        """,
    )

    with pytest.raises(InvalidSchemaDeclarationError, match="Arrays of tables") as excinfo:
        TomlSchemaLoader().load_schema([defaults_path])

    assert excinfo.value.location == ("logging", "sinks")
