from __future__ import annotations

from pathlib import Path

from boundconfig import BoundConfig
from boundconfig.validators import InMemoryValidatorRegistry

PROJECT_ROOT = Path(__file__).resolve().parents[1]
SAMPLES_DIR = PROJECT_ROOT / "samples"


def _read(path: Path) -> str:
    return path.read_text(encoding="utf-8").strip()


def test_basic_sample_init_matches_documented_output() -> None:
    defaults_path = SAMPLES_DIR / "basic" / "defaults.toml"
    config_path = SAMPLES_DIR / "basic" / "config.before.toml"
    expected_path = SAMPLES_DIR / "basic" / "config.after-init.toml"

    rendered = BoundConfig(
        config_path=config_path,
        defaults_paths=(defaults_path,),
    ).init(dry_run=True).as_string().strip()

    assert rendered == _read(expected_path)


def test_basic_sample_repair_matches_documented_output() -> None:
    defaults_path = SAMPLES_DIR / "basic" / "defaults.toml"
    config_path = SAMPLES_DIR / "basic" / "config.before.toml"
    expected_path = SAMPLES_DIR / "basic" / "config.after-repair.toml"

    rendered = BoundConfig(
        config_path=config_path,
        defaults_paths=(defaults_path,),
    ).repair(dry_run=True).as_string().strip()

    assert rendered == _read(expected_path)


def test_basic_sample_validate_matches_documented_findings() -> None:
    defaults_path = SAMPLES_DIR / "basic" / "defaults.toml"
    config_path = SAMPLES_DIR / "basic" / "config.before.toml"

    report = BoundConfig(
        config_path=config_path,
        defaults_paths=(defaults_path,),
    ).validate()

    assert [(issue.code, issue.location) for issue in report.issues] == [
        ("invalid-type", ("service", "enabled")),
        ("missing-managed-key", ("service", "retries")),
        ("missing-managed-key", ("service", "point")),
        ("missing-managed-key", ("ui", "theme")),
    ]
    assert [(warning.code, warning.location) for warning in report.warnings] == [
        ("unknown-user-key", ("service", "extra")),
        ("unknown-user-section", ("custom",)),
    ]


def test_custom_validator_samples_match_current_python_api_behavior() -> None:
    defaults_path = SAMPLES_DIR / "custom-validator" / "defaults.toml"
    invalid_config_path = SAMPLES_DIR / "custom-validator" / "config.invalid.toml"
    valid_config_path = SAMPLES_DIR / "custom-validator" / "config.valid.toml"
    registry = InMemoryValidatorRegistry()

    invalid_bound_config = BoundConfig(
        config_path=invalid_config_path,
        defaults_paths=(defaults_path,),
        validator_registry=registry,
    )
    invalid_bound_config.register_validator(
        "no-spaces",
        lambda value: "must not contain spaces" if " " in value else None,
    )
    invalid_report = invalid_bound_config.validate()

    valid_bound_config = BoundConfig(
        config_path=valid_config_path,
        defaults_paths=(defaults_path,),
        validator_registry=registry,
    )
    valid_report = valid_bound_config.validate()

    assert [(issue.code, issue.location) for issue in invalid_report.issues] == [
        ("custom-validator-failed", ("service", "name")),
    ]
    assert valid_report.is_valid
    assert valid_report.issues == ()
    assert valid_report.warnings == ()


def test_temporal_samples_match_current_validation_behavior() -> None:
    defaults_path = SAMPLES_DIR / "temporal" / "defaults.toml"
    config_path = SAMPLES_DIR / "temporal" / "config.valid.toml"

    report = BoundConfig(
        config_path=config_path,
        defaults_paths=(defaults_path,),
    ).validate()

    assert report.is_valid
    assert report.issues == ()
    assert report.warnings == ()