from __future__ import annotations

import argparse
import sys
from collections.abc import Sequence
from pathlib import Path

from ._api import BoundConfig
from ._version import __version__
from .exceptions import BoundConfigError
from .validation import ValidationReport
from .validation.models import ValidationMessage


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="boundconfig",
        description="Schema-bound configuration engine for human-edited application config files.",
    )
    parser.add_argument(
        "--version",
        action="version",
        version=f"%(prog)s {__version__}",
    )

    command_parser = argparse.ArgumentParser(add_help=False)
    command_parser.add_argument(
        "--config",
        type=Path,
        required=True,
        help="Path to the working TOML config file.",
    )
    command_parser.add_argument(
        "--defaults",
        dest="defaults_paths",
        action="append",
        nargs="+",
        type=Path,
        required=True,
        help="One or more managed defaults TOML files.",
    )
    command_parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Run without writing init changes to disk.",
    )
    command_parser.add_argument(
        "--verbose",
        action="store_true",
        help="Print an operation summary.",
    )
    command_parser.add_argument(
        "--suppress-warnings",
        action="store_true",
        help="Hide non-fatal validation warnings.",
    )

    subparsers = parser.add_subparsers(dest="command", required=True)

    init_parser = subparsers.add_parser(
        "init",
        parents=[command_parser],
        help="Merge missing managed defaults into the working config.",
    )
    init_parser.set_defaults(handler=_run_init)

    validate_parser = subparsers.add_parser(
        "validate",
        parents=[command_parser],
        help="Validate the working config without writing changes.",
    )
    validate_parser.set_defaults(handler=_run_validate)

    return parser


def main(argv: Sequence[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)

    try:
        return args.handler(args)
    except (BoundConfigError, OSError, ValueError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1


def _run_init(args: argparse.Namespace) -> int:
    bound_config = _build_bound_config(args)
    bound_config.init(dry_run=args.dry_run)

    if args.verbose:
        action = "Dry run completed for" if args.dry_run else "Initialized"
        print(f"{action} {bound_config.config_path}.")

    return 0


def _run_validate(args: argparse.Namespace) -> int:
    bound_config = _build_bound_config(args)
    report = bound_config.validate()
    _emit_report(report, suppress_warnings=args.suppress_warnings)

    if args.verbose:
        summary = (
            f"Validation passed for {bound_config.config_path}."
            if report.is_valid
            else (
                f"Validation failed for {bound_config.config_path} "
                f"with {report.issue_count} issue(s)."
            )
        )
        output = sys.stdout if report.is_valid else sys.stderr
        print(summary, file=output)

    return 0 if report.is_valid else 1


def _build_bound_config(args: argparse.Namespace) -> BoundConfig:
    return BoundConfig(
        config_path=args.config,
        defaults_paths=tuple(path for group in args.defaults_paths for path in group),
    )


def _emit_report(report: ValidationReport, *, suppress_warnings: bool) -> None:
    for issue in report.issues:
        _emit_message("error", issue)

    if suppress_warnings:
        return

    for warning in report.warnings:
        _emit_message("warning", warning)


def _emit_message(level: str, message: ValidationMessage) -> None:
    print(f"{level} [{message.code}] {message.message}", file=sys.stderr)
