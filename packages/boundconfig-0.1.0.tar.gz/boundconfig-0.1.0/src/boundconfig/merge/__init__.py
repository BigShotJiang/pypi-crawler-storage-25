"""Merge engine interfaces."""

from .engine import MergeEngine

__all__ = ["MergeEngine"]
