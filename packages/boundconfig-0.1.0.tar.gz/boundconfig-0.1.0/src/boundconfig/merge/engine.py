from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Generic, TypeVar

from tomlkit import TOMLDocument
from tomlkit.items import Table

from ..adapters import TomlAdapter
from ..schema import BoundSchema, SchemaSection

SchemaT = TypeVar("SchemaT")
DocumentT = TypeVar("DocumentT")


class MergeEngine(ABC, Generic[SchemaT, DocumentT]):
    """Apply managed defaults to an existing config document."""

    @abstractmethod
    def merge(self, schema: SchemaT, document: DocumentT) -> DocumentT:
        """Merge schema-managed content into a document."""


class TomlMergeEngine(MergeEngine[BoundSchema, TOMLDocument]):
    """Apply missing managed TOML defaults without repairing invalid existing values."""

    def __init__(self, *, adapter: TomlAdapter | None = None) -> None:
        self._adapter = adapter or TomlAdapter()

    @property
    def adapter(self) -> TomlAdapter:
        return self._adapter

    @adapter.setter
    def adapter(self, adapter: TomlAdapter) -> None:
        self._adapter = adapter

    def merge(self, schema: BoundSchema, document: TOMLDocument) -> TOMLDocument:
        for section in schema.sections:
            raw_section = document.get(section.name)
            if raw_section is None:
                document.append(section.name, self._build_section(section))
                continue

            if not isinstance(raw_section, Table):
                # Existing invalid managed sections are left untouched during init-style merges.
                continue

            for field in section.fields:
                if field.name in raw_section:
                    continue

                raw_section.append(field.name, self._adapter.build_item(field.default_value))

        return document

    def _build_section(self, section: SchemaSection) -> Table:
        return self._adapter.build_table(
            (field.name, field.default_value) for field in section.fields
        )
