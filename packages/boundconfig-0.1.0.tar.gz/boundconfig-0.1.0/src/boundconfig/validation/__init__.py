"""Validation engine interfaces and TOML validation support."""

from .models import ValidationIssue, ValidationReport, ValidationWarning

__all__ = [
    "TomlValidationEngine",
    "ValidationEngine",
    "ValidationIssue",
    "ValidationReport",
    "ValidationWarning",
]


def __getattr__(name: str):
    if name in {"TomlValidationEngine", "ValidationEngine"}:
        from .engine import TomlValidationEngine, ValidationEngine

        return {
            "TomlValidationEngine": TomlValidationEngine,
            "ValidationEngine": ValidationEngine,
        }[name]

    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")