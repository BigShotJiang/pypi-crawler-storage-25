﻿from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class ValidationMessage:
    """Base value object for validation diagnostics."""

    code: str
    message: str
    location: tuple[str, ...] = ()

    def __post_init__(self) -> None:
        object.__setattr__(self, "location", tuple(self.location))

    @property
    def dotted_path(self) -> str:
        """Return the location rendered as a dotted config path."""
        return ".".join(self.location)


@dataclass(frozen=True, slots=True)
class ValidationIssue(ValidationMessage):
    """A validation error that makes the config invalid."""


@dataclass(frozen=True, slots=True)
class ValidationWarning(ValidationMessage):
    """A non-fatal validation finding."""


@dataclass(frozen=True, slots=True)
class ValidationReport:
    """Immutable validation result container for issues and warnings."""

    issues: tuple[ValidationIssue, ...] = ()
    warnings: tuple[ValidationWarning, ...] = ()

    def __post_init__(self) -> None:
        object.__setattr__(self, "issues", tuple(self.issues))
        object.__setattr__(self, "warnings", tuple(self.warnings))

    @property
    def is_valid(self) -> bool:
        """Return whether the report contains any validation issues."""
        return not self.issues

    @property
    def issue_count(self) -> int:
        """Return the number of validation issues."""
        return len(self.issues)

    @property
    def warning_count(self) -> int:
        """Return the number of validation warnings."""
        return len(self.warnings)
