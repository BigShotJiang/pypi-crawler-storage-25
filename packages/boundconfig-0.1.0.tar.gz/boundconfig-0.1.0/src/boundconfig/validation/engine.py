from __future__ import annotations

from abc import ABC, abstractmethod
from datetime import date, datetime, time
from typing import Any, Generic, TypeVar

from tomlkit import TOMLDocument
from tomlkit.items import AoT, Table

from ..exceptions import (
    InvalidSchemaDeclarationError,
    UnknownValidatorError,
    ValidatorExecutionError,
)
from ..schema import BoundSchema, SchemaField, SchemaSection
from ..validators import CustomValidator, ValidatorRegistry, get_shared_validator_registry
from .models import ValidationIssue, ValidationReport, ValidationWarning

SchemaT = TypeVar("SchemaT")
DocumentT = TypeVar("DocumentT")
ValidationResultT = TypeVar("ValidationResultT")


class ValidationEngine(ABC, Generic[SchemaT, DocumentT, ValidationResultT]):
    """Validate a config document against a managed schema."""

    @abstractmethod
    def validate(self, schema: SchemaT, document: DocumentT) -> ValidationResultT:
        """Validate a document and return a report object."""


_DECLARED_TYPE_NAMES = {
    "str": "string",
    "int": "int",
    "float": "float",
    "bool": "bool",
    "array": "array",
    "offset_datetime": "offset datetime",
    "local_datetime": "local datetime",
    "local_date": "local date",
    "local_time": "local time",
}

_TEMPORAL_KIND_NAMES = frozenset(
    {"offset datetime", "local datetime", "local date", "local time"}
)


class TomlValidationEngine(ValidationEngine[BoundSchema, TOMLDocument, ValidationReport]):
    """Validate TOML config documents against the managed schema surface."""

    def __init__(
        self,
        *,
        validator_registry: ValidatorRegistry[CustomValidator] | None = None,
    ) -> None:
        self._validator_registry = validator_registry or get_shared_validator_registry()

    @property
    def validator_registry(self) -> ValidatorRegistry[CustomValidator]:
        return self._validator_registry

    @validator_registry.setter
    def validator_registry(
        self,
        validator_registry: ValidatorRegistry[CustomValidator],
    ) -> None:
        self._validator_registry = validator_registry

    def validate(self, schema: BoundSchema, document: TOMLDocument) -> ValidationReport:
        issues: list[ValidationIssue] = []
        warnings: list[ValidationWarning] = []

        for section in schema.sections:
            raw_section = document.get(section.name)
            if raw_section is None:
                issues.extend(self._missing_section_issues(section))
                continue

            if not isinstance(raw_section, Table):
                issues.append(
                    ValidationIssue(
                        code="invalid-type",
                        message=f"Managed section '{section.name}' must be a TOML table.",
                        location=(section.name,),
                    )
                )
                continue

            issues.extend(self._validate_section(section, raw_section))
            warnings.extend(self._unknown_key_warnings(section, raw_section))

        warnings.extend(self._unknown_top_level_warnings(schema, document))
        return ValidationReport(issues=tuple(issues), warnings=tuple(warnings))

    def _validate_section(
        self,
        section: SchemaSection,
        raw_section: Table,
    ) -> list[ValidationIssue]:
        issues: list[ValidationIssue] = []

        for field in section.fields:
            self._prepare_field_validation(section_name=section.name, field=field)
            if field.name not in raw_section:
                issues.append(
                    ValidationIssue(
                        code="missing-managed-key",
                        message=f"Managed key '{section.name}.{field.name}' is missing.",
                        location=(section.name, field.name),
                    )
                )
                continue

            issues.extend(
                self._validate_field_value(
                    section_name=section.name,
                    field=field,
                    raw_value=raw_section[field.name],
                )
            )

        return issues

    def _validate_field_value(
        self,
        *,
        section_name: str,
        field: SchemaField,
        raw_value: Any,
    ) -> list[ValidationIssue]:
        expected_kind, custom_validator = self._prepare_field_validation(
            section_name=section_name,
            field=field,
        )

        value = self._unwrap_value(raw_value)
        if not self._value_matches_kind(expected_kind, raw_value, value):
            article = self._indefinite_article(expected_kind)
            return [
                ValidationIssue(
                    code="invalid-type",
                    message=(
                        f"Managed key '{section_name}.{field.name}' must be {article} "
                        f"{expected_kind}, found {self._describe_value_type(raw_value, value)}."
                    ),
                    location=(section_name, field.name),
                )
            ]

        issues: list[ValidationIssue] = []
        if field.allowed_values and value not in field.allowed_values:
            issues.append(
                ValidationIssue(
                    code="disallowed-value",
                    message=(
                        f"Managed key '{section_name}.{field.name}' must be one of the "
                        "declared allowed values."
                    ),
                    location=(section_name, field.name),
                )
            )

        if field.minimum is not None and value < field.minimum:
            issues.append(
                ValidationIssue(
                    code="value-below-minimum",
                    message=(
                        f"Managed key '{section_name}.{field.name}' must be greater than or "
                        f"equal to {field.minimum}."
                    ),
                    location=(section_name, field.name),
                )
            )

        if field.maximum is not None and value > field.maximum:
            issues.append(
                ValidationIssue(
                    code="value-above-maximum",
                    message=(
                        f"Managed key '{section_name}.{field.name}' must be less than or equal "
                        f"to {field.maximum}."
                    ),
                    location=(section_name, field.name),
                )
            )

        if field.min_length is not None and len(value) < field.min_length:
            issues.append(
                ValidationIssue(
                    code="value-too-short",
                    message=(
                        f"Managed key '{section_name}.{field.name}' must have length greater than "
                        f"or equal to {field.min_length}."
                    ),
                    location=(section_name, field.name),
                )
            )

        if field.max_length is not None and len(value) > field.max_length:
            issues.append(
                ValidationIssue(
                    code="value-too-long",
                    message=(
                        f"Managed key '{section_name}.{field.name}' must have length less than "
                        f"or equal to {field.max_length}."
                    ),
                    location=(section_name, field.name),
                )
            )

        if issues or custom_validator is None:
            return issues

        custom_issue = self._run_custom_validator(
            section_name=section_name,
            field=field,
            validator=custom_validator,
            value=value,
        )
        if custom_issue is not None:
            issues.append(custom_issue)

        return issues

    def _prepare_field_validation(
        self,
        *,
        section_name: str,
        field: SchemaField,
    ) -> tuple[str, CustomValidator | None]:
        expected_kind = self._resolve_expected_kind(section_name, field)
        self._validate_constraint_usage(section_name, field, expected_kind)
        return expected_kind, self._resolve_custom_validator(section_name=section_name, field=field)

    def _resolve_custom_validator(
        self,
        *,
        section_name: str,
        field: SchemaField,
    ) -> CustomValidator | None:
        if field.validator_name is None:
            return None

        validator = self._validator_registry.get(field.validator_name)
        if validator is None:
            raise UnknownValidatorError(
                field.validator_name,
                section_name=section_name,
                field_name=field.name,
            )

        return validator

    def _run_custom_validator(
        self,
        *,
        section_name: str,
        field: SchemaField,
        validator: CustomValidator,
        value: Any,
    ) -> ValidationIssue | None:
        try:
            message = validator(value)
        except Exception as exc:
            raise ValidatorExecutionError(
                field.validator_name or "<unknown>",
                section_name=section_name,
                field_name=field.name,
                reason=f"raised {type(exc).__name__}: {exc}",
            ) from exc

        if message is None:
            return None

        if not isinstance(message, str) or not message:
            raise ValidatorExecutionError(
                field.validator_name or "<unknown>",
                section_name=section_name,
                field_name=field.name,
                reason="must return None or a non-empty string",
            )

        return ValidationIssue(
            code="custom-validator-failed",
            message=(
                f"Managed key '{section_name}.{field.name}' failed custom validator "
                f"'{field.validator_name}': {message}"
            ),
            location=(section_name, field.name),
        )

    def _resolve_expected_kind(self, section_name: str, field: SchemaField) -> str:
        inferred_kind = self._infer_kind(
            field.default_value,
            section_name=section_name,
            field_name=field.name,
        )
        if field.declared_type is None:
            return inferred_kind

        expected_kind = _DECLARED_TYPE_NAMES.get(field.declared_type)
        if expected_kind is None:
            raise InvalidSchemaDeclarationError(
                f"Unsupported declared type '{field.declared_type}' for v1 validation.",
                section_name=section_name,
                field_name=field.name,
            )

        if expected_kind != inferred_kind:
            raise InvalidSchemaDeclarationError(
                "Declared type does not match the managed field default value.",
                section_name=section_name,
                field_name=field.name,
            )

        return expected_kind

    def _infer_kind(self, value: Any, *, section_name: str, field_name: str) -> str:
        kind = self._classify_value_kind(value)
        if kind == "offset time":
            raise InvalidSchemaDeclarationError(
                "Managed field defaults must use TOML-native local time values in v1.",
                section_name=section_name,
                field_name=field_name,
            )
        if kind is not None:
            return kind

        raise InvalidSchemaDeclarationError(
            "Managed field defaults must use v1 core scalar types, arrays, inline tables, "
            "or TOML-native temporal scalars.",
            section_name=section_name,
            field_name=field_name,
        )

    def _validate_constraint_usage(
        self,
        section_name: str,
        field: SchemaField,
        expected_kind: str,
    ) -> None:
        if expected_kind in {"int", "float"}:
            self._validate_numeric_constraints(section_name, field)
            if field.min_length is not None or field.max_length is not None:
                raise InvalidSchemaDeclarationError(
                    "Length constraints are only supported for strings and arrays in v1.",
                    section_name=section_name,
                    field_name=field.name,
                )
            return

        if expected_kind in {"string", "array"}:
            if field.minimum is not None or field.maximum is not None:
                raise InvalidSchemaDeclarationError(
                    "`_min` and `_max` are only supported for numeric fields in v1.",
                    section_name=section_name,
                    field_name=field.name,
                )
            self._validate_length_constraints(section_name, field)
            return

        if expected_kind == "bool":
            if any(
                constraint is not None
                for constraint in (field.minimum, field.maximum, field.min_length, field.max_length)
            ):
                raise InvalidSchemaDeclarationError(
                    "Boolean fields only support `_allowed_values` in v1.",
                    section_name=section_name,
                    field_name=field.name,
                )
            return

        if expected_kind in _TEMPORAL_KIND_NAMES:
            self._validate_temporal_constraints(section_name, field, expected_kind)
            if field.min_length is not None or field.max_length is not None:
                raise InvalidSchemaDeclarationError(
                    "Temporal fields do not support length constraints in v1.",
                    section_name=section_name,
                    field_name=field.name,
                )
            return

        if expected_kind == "table":
            if field.minimum is not None or field.maximum is not None:
                raise InvalidSchemaDeclarationError(
                    "Managed inline-table fields only support shallow table validation in v1. "
                    "Recursive `_min` and `_max` validation is future work.",
                    section_name=section_name,
                    field_name=field.name,
                )
            if field.min_length is not None or field.max_length is not None:
                raise InvalidSchemaDeclarationError(
                    "Managed inline-table fields do not support length constraints in v1.",
                    section_name=section_name,
                    field_name=field.name,
                )
            return

        raise InvalidSchemaDeclarationError(
            "Managed field uses an unsupported v1 validation type.",
            section_name=section_name,
            field_name=field.name,
        )

    def _validate_numeric_constraints(self, section_name: str, field: SchemaField) -> None:
        for constraint_name, constraint_value in (("_min", field.minimum), ("_max", field.maximum)):
            if constraint_value is None:
                continue

            if not self._is_numeric_value(constraint_value):
                raise InvalidSchemaDeclarationError(
                    f"{constraint_name} must be numeric for v1 numeric validation.",
                    section_name=section_name,
                    field_name=field.name,
                )

    def _validate_length_constraints(self, section_name: str, field: SchemaField) -> None:
        for constraint_name, constraint_value in (
            ("_min_length", field.min_length),
            ("_max_length", field.max_length),
        ):
            if constraint_value is None:
                continue

            if not self._is_int_value(constraint_value):
                raise InvalidSchemaDeclarationError(
                    f"{constraint_name} must be an integer for v1 length validation.",
                    section_name=section_name,
                    field_name=field.name,
                )

    def _validate_temporal_constraints(
        self,
        section_name: str,
        field: SchemaField,
        expected_kind: str,
    ) -> None:
        for constraint_name, constraint_value in (("_min", field.minimum), ("_max", field.maximum)):
            if constraint_value is None:
                continue

            if self._infer_constraint_kind(
                constraint_value,
                section_name=section_name,
                field_name=field.name,
                constraint_name=constraint_name,
            ) != expected_kind:
                raise InvalidSchemaDeclarationError(
                    f"{constraint_name} must use the same temporal kind as "
                    "the managed default value.",
                    section_name=section_name,
                    field_name=field.name,
                )

        for allowed_value in field.allowed_values:
            if self._infer_constraint_kind(
                allowed_value,
                section_name=section_name,
                field_name=field.name,
                constraint_name="_allowed_values",
            ) != expected_kind:
                raise InvalidSchemaDeclarationError(
                    "`_allowed_values` entries must use the same temporal kind as the "
                    "managed default value.",
                    section_name=section_name,
                    field_name=field.name,
                )

    def _infer_constraint_kind(
        self,
        value: Any,
        *,
        section_name: str,
        field_name: str,
        constraint_name: str,
    ) -> str:
        kind = self._classify_value_kind(value)
        if kind == "offset time":
            raise InvalidSchemaDeclarationError(
                f"{constraint_name} must use TOML-native local time values in v1.",
                section_name=section_name,
                field_name=field_name,
            )
        if kind is not None:
            return kind

        raise InvalidSchemaDeclarationError(
            f"{constraint_name} uses an unsupported v1 value type.",
            section_name=section_name,
            field_name=field_name,
        )

    def _missing_section_issues(self, section: SchemaSection) -> list[ValidationIssue]:
        issues: list[ValidationIssue] = []
        for field in section.fields:
            self._prepare_field_validation(section_name=section.name, field=field)
            issues.append(
                ValidationIssue(
                    code="missing-managed-key",
                    message=f"Managed key '{section.name}.{field.name}' is missing.",
                    location=(section.name, field.name),
                )
            )
        return issues

    def _unknown_key_warnings(
        self,
        section: SchemaSection,
        raw_section: Table,
    ) -> list[ValidationWarning]:
        managed_field_names = set(section.field_names)

        return [
            ValidationWarning(
                code="unknown-user-key",
                message=(
                    f"Unknown user key '{section.name}.{key_name}' will be preserved during "
                    "managed operations."
                ),
                location=(section.name, str(key_name)),
            )
            for key_name, _ in raw_section.items()
            if str(key_name) not in managed_field_names
        ]

    def _unknown_top_level_warnings(
        self,
        schema: BoundSchema,
        document: TOMLDocument,
    ) -> list[ValidationWarning]:
        managed_section_names = set(schema.section_names)
        warnings: list[ValidationWarning] = []

        for key_name, raw_value in document.items():
            key_name_str = str(key_name)
            if key_name_str in managed_section_names:
                continue

            if isinstance(raw_value, Table):
                warnings.append(
                    ValidationWarning(
                        code="unknown-user-section",
                        message=(
                            f"Unknown user section '{key_name_str}' will be preserved during "
                            "managed operations."
                        ),
                        location=(key_name_str,),
                    )
                )
                continue

            warnings.append(
                ValidationWarning(
                    code="unknown-user-key",
                    message=(
                        f"Unknown top-level key '{key_name_str}' will be preserved during "
                        "managed operations."
                    ),
                    location=(key_name_str,),
                )
            )

        return warnings

    @staticmethod
    def _unwrap_value(value: Any) -> Any:
        if hasattr(value, "unwrap"):
            return value.unwrap()

        return value

    @staticmethod
    def _value_matches_kind(expected_kind: str, raw_value: Any, value: Any) -> bool:
        if expected_kind == "array":
            return not isinstance(raw_value, AoT) and isinstance(value, list)
        return TomlValidationEngine._classify_value_kind(value) == expected_kind

    @staticmethod
    def _describe_value_type(raw_value: Any, value: Any) -> str:
        if isinstance(raw_value, AoT):
            return "array-of-tables"
        if isinstance(raw_value, Table):
            return "table"
        return TomlValidationEngine._classify_value_kind(value) or type(value).__name__

    @staticmethod
    def _is_numeric_value(value: Any) -> bool:
        return isinstance(value, (int, float)) and not isinstance(value, bool)

    @staticmethod
    def _is_int_value(value: Any) -> bool:
        return isinstance(value, int) and not isinstance(value, bool)

    @staticmethod
    def _classify_value_kind(value: Any) -> str | None:
        if isinstance(value, bool):
            return "bool"
        if isinstance(value, int):
            return "int"
        if isinstance(value, float):
            return "float"
        if isinstance(value, str):
            return "string"
        if isinstance(value, datetime):
            return "offset datetime" if value.tzinfo is not None else "local datetime"
        if isinstance(value, date):
            return "local date"
        if isinstance(value, time):
            return "offset time" if value.tzinfo is not None else "local time"
        if isinstance(value, list):
            return "array"
        if isinstance(value, dict):
            return "table"

        return None

    @staticmethod
    def _indefinite_article(value_type: str) -> str:
        return "an" if value_type[:1].lower() in {"a", "e", "i", "o", "u"} else "a"
