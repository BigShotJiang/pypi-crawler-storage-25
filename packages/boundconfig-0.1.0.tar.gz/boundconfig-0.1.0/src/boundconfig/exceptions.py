from __future__ import annotations

from collections.abc import Iterable

from .validation.models import ValidationIssue, ValidationReport, ValidationWarning


class BoundConfigError(Exception):
    """Base exception for BoundConfig errors."""


class SchemaError(BoundConfigError):
    """Base exception for managed schema failures."""


class DuplicateDefinitionError(SchemaError):
    """Base exception for duplicate schema definitions."""

    def __init__(self, message: str, *, name: str) -> None:
        super().__init__(message)
        self.name = name


class DuplicateSectionDefinitionError(DuplicateDefinitionError):
    """Raised when the same managed section is declared more than once."""

    def __init__(self, section_name: str) -> None:
        super().__init__(
            f"Duplicate section definition for '{section_name}'.",
            name=section_name,
        )
        self.section_name = section_name


class DuplicateFieldDefinitionError(DuplicateDefinitionError):
    """Raised when the same managed field is declared more than once in a section."""

    def __init__(self, section_name: str, field_name: str) -> None:
        super().__init__(
            f"Duplicate field definition for '{section_name}.{field_name}'.",
            name=field_name,
        )
        self.section_name = section_name
        self.field_name = field_name


class InvalidSchemaDeclarationError(SchemaError):
    """Raised when a defaults declaration cannot be represented as a valid schema field."""

    def __init__(
        self,
        message: str,
        *,
        section_name: str | None = None,
        field_name: str | None = None,
    ) -> None:
        super().__init__(message)
        self.section_name = section_name
        self.field_name = field_name

    @property
    def location(self) -> tuple[str, ...]:
        """Return the schema location associated with the invalid declaration."""
        return tuple(part for part in (self.section_name, self.field_name) if part is not None)


class UnknownReservedKeyError(InvalidSchemaDeclarationError):
    """Raised when a declaration uses an unsupported reserved `_...` key."""

    def __init__(
        self,
        key_name: str,
        *,
        section_name: str | None = None,
        field_name: str | None = None,
    ) -> None:
        location = ".".join(part for part in (section_name, field_name) if part is not None)
        message = f"Unknown reserved declaration key '{key_name}'."
        if location:
            message = f"{message} Found in '{location}'."

        super().__init__(
            message,
            section_name=section_name,
            field_name=field_name,
        )
        self.key_name = key_name


class UnknownValidatorError(InvalidSchemaDeclarationError):
    """Raised when a declaration references a validator name that is not registered."""

    def __init__(
        self,
        validator_name: str,
        *,
        section_name: str | None = None,
        field_name: str | None = None,
    ) -> None:
        location = ".".join(part for part in (section_name, field_name) if part is not None)
        message = f"Unknown validator '{validator_name}'."
        if location:
            message = f"{message} Found in '{location}'."

        super().__init__(
            message,
            section_name=section_name,
            field_name=field_name,
        )
        self.validator_name = validator_name


class ReservedNameError(SchemaError):
    """Raised when a schema element violates the reserved-name policy."""

    def __init__(self, message: str, *, name: str) -> None:
        super().__init__(message)
        self.name = name


class ReservedSectionNameError(ReservedNameError):
    """Raised when a managed section uses a reserved name."""

    def __init__(self, section_name: str) -> None:
        super().__init__(
            f"Section name '{section_name}' is reserved and cannot be managed.",
            name=section_name,
        )
        self.section_name = section_name


class ValidationFailure(BoundConfigError):
    """Raised when validation produces one or more issues."""

    def __init__(
        self,
        issues: Iterable[ValidationIssue] | ValidationReport,
        *,
        warnings: Iterable[ValidationWarning] = (),
        message: str | None = None,
    ) -> None:
        if isinstance(issues, ValidationReport):
            report = issues
        else:
            report = ValidationReport(issues=tuple(issues), warnings=tuple(warnings))

        if message is None:
            message = f"Validation failed with {report.issue_count} issue(s)."

        super().__init__(message)
        self.report = report


class ValidatorExecutionError(BoundConfigError):
    """Raised when a custom validator raises or returns an unsupported result."""

    def __init__(
        self,
        validator_name: str,
        *,
        section_name: str,
        field_name: str,
        reason: str,
    ) -> None:
        super().__init__(
            f"Custom validator '{validator_name}' for managed key "
            f"'{section_name}.{field_name}' {reason}."
        )
        self.validator_name = validator_name
        self.section_name = section_name
        self.field_name = field_name

