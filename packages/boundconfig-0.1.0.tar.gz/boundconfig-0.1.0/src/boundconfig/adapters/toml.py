from __future__ import annotations

from collections.abc import Iterable
from pathlib import Path
from typing import Any

from tomlkit import (
    TOMLDocument,
    array,
    document,
    dumps,
    inline_table,
    item,
    parse,
    table,
)
from tomlkit.items import Table

from .base import DocumentAdapter


class TomlAdapter(DocumentAdapter[TOMLDocument]):
    """TOML document adapter backed by tomlkit's round-trip document model."""

    def empty_document(self) -> TOMLDocument:
        """Create an empty round-trip TOML document."""
        return document()

    def build_item(self, value: Any) -> Any:
        """Build tomlkit items without expanding managed dict defaults into tables."""
        if isinstance(value, dict):
            inline = inline_table()
            for key_name, child_value in value.items():
                inline.append(key_name, self.build_item(child_value))

            return inline

        if isinstance(value, (list, tuple)):
            built_array = array()
            for child_value in value:
                built_array.append(self.build_item(child_value))

            return built_array

        return item(value)

    def build_table(self, values: Iterable[tuple[str, Any]]) -> Table:
        """Build a TOML table from managed key/value pairs."""
        built_table = table()
        for key_name, value in values:
            built_table.append(key_name, self.build_item(value))

        return built_table

    def load_document(self, path: Path) -> TOMLDocument:
        """Load a TOML document from disk without discarding formatting trivia."""
        return parse(path.read_text(encoding="utf-8"))

    def dump_document(self, document: TOMLDocument, path: Path) -> None:
        """Persist a TOML document using tomlkit's serializer."""
        path.write_text(dumps(document), encoding="utf-8")
