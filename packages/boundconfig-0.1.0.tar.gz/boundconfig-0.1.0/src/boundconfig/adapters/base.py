from __future__ import annotations

from abc import ABC, abstractmethod
from pathlib import Path
from typing import Generic, TypeVar

DocumentT = TypeVar("DocumentT")


class DocumentAdapter(ABC, Generic[DocumentT]):
    """Translate config files to and from the internal document model."""

    @abstractmethod
    def load_document(self, path: Path) -> DocumentT:
        """Load a config document from disk."""

    @abstractmethod
    def dump_document(self, document: DocumentT, path: Path) -> None:
        """Persist a config document to disk."""
