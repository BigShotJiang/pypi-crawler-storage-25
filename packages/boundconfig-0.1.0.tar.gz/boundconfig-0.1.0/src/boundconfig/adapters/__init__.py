"""Adapter interfaces and concrete document adapters."""

from .base import DocumentAdapter
from .toml import TomlAdapter

__all__ = ["DocumentAdapter", "TomlAdapter"]
