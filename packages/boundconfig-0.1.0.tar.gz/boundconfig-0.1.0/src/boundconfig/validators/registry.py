from __future__ import annotations

from abc import ABC, abstractmethod
from collections.abc import Callable
from typing import Any, Generic, TypeVar

CustomValidator = Callable[[Any], str | None]
ValidatorT = TypeVar("ValidatorT", bound=Callable[..., object])


class ValidatorRegistry(ABC, Generic[ValidatorT]):
    """Register and resolve named validator callables."""

    @abstractmethod
    def register(self, name: str, validator: ValidatorT) -> None:
        """Register a named validator."""

    @abstractmethod
    def get(self, name: str) -> ValidatorT | None:
        """Look up a named validator."""


class InMemoryValidatorRegistry(ValidatorRegistry[CustomValidator]):
    """Concrete in-memory registry for Python-defined custom validators."""

    def __init__(self) -> None:
        self._validators: dict[str, CustomValidator] = {}

    def register(self, name: str, validator: CustomValidator) -> None:
        if not isinstance(name, str) or not name.strip():
            raise ValueError("Validator names must be non-empty strings.")
        if not callable(validator):
            raise TypeError("Validator must be callable.")

        self._validators[name] = validator

    def get(self, name: str) -> CustomValidator | None:
        return self._validators.get(name)


_SHARED_VALIDATOR_REGISTRY = InMemoryValidatorRegistry()


def get_shared_validator_registry() -> InMemoryValidatorRegistry:
    """Return the shared process-wide registry used by default BoundConfig APIs."""
    return _SHARED_VALIDATOR_REGISTRY
