from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Generic, TypeVar

from tomlkit import TOMLDocument
from tomlkit.items import Table

from ..adapters import TomlAdapter
from ..schema import BoundSchema, SchemaField, SchemaSection
from ..validation import TomlValidationEngine

SchemaT = TypeVar("SchemaT")
DocumentT = TypeVar("DocumentT")


class RepairEngine(ABC, Generic[SchemaT, DocumentT]):
    """Repair missing or invalid managed content in a config document."""

    @abstractmethod
    def repair(self, schema: SchemaT, document: DocumentT) -> DocumentT:
        """Return a repaired document."""


class TomlRepairEngine(RepairEngine[BoundSchema, TOMLDocument]):
    """Repair missing or invalid managed TOML content to declared defaults."""

    def __init__(
        self,
        *,
        adapter: TomlAdapter | None = None,
        validation_engine: TomlValidationEngine | None = None,
    ) -> None:
        self._adapter = adapter or TomlAdapter()
        self._validation_engine = validation_engine or TomlValidationEngine()

    @property
    def adapter(self) -> TomlAdapter:
        return self._adapter

    @adapter.setter
    def adapter(self, adapter: TomlAdapter) -> None:
        self._adapter = adapter

    @property
    def validation_engine(self) -> TomlValidationEngine:
        return self._validation_engine

    @validation_engine.setter
    def validation_engine(self, validation_engine: TomlValidationEngine) -> None:
        self._validation_engine = validation_engine

    def repair(self, schema: BoundSchema, document: TOMLDocument) -> TOMLDocument:
        for section in schema.sections:
            raw_section = document.get(section.name)
            if raw_section is None:
                self._prepare_section_validation(section)
                document.append(section.name, self._build_section(section))
                continue

            if not isinstance(raw_section, Table):
                self._prepare_section_validation(section)
                document[section.name] = self._build_section(section)
                continue

            for field in section.fields:
                self._validation_engine._prepare_field_validation(
                    section_name=section.name,
                    field=field,
                )
                if field.name not in raw_section:
                    raw_section.append(field.name, self._adapter.build_item(field.default_value))
                    continue

                if self._is_invalid_field_value(
                    section_name=section.name,
                    field=field,
                    raw_value=raw_section[field.name],
                ):
                    raw_section[field.name] = self._adapter.build_item(field.default_value)

        return document

    def _build_section(self, section: SchemaSection) -> Table:
        return self._adapter.build_table(
            (field.name, field.default_value) for field in section.fields
        )

    def _prepare_section_validation(self, section: SchemaSection) -> None:
        for field in section.fields:
            self._validation_engine._prepare_field_validation(
                section_name=section.name,
                field=field,
            )

    def _is_invalid_field_value(
        self,
        *,
        section_name: str,
        field: SchemaField,
        raw_value: object,
    ) -> bool:
        return bool(
            self._validation_engine._validate_field_value(
                section_name=section_name,
                field=field,
                raw_value=raw_value,
            )
        )
