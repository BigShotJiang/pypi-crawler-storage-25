from __future__ import annotations

from abc import ABC, abstractmethod
from collections.abc import Sequence
from pathlib import Path
from typing import Generic, TypeVar

SchemaT = TypeVar("SchemaT")


class SchemaLoader(ABC, Generic[SchemaT]):
    """Load schema definitions from one or more defaults files."""

    @abstractmethod
    def load_schema(self, defaults_paths: Sequence[Path]) -> SchemaT:
        """Load schema data from defaults files."""
