from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Iterable

DEFAULT_RESERVED_SECTION_NAMES = frozenset({"__metadata__"})
DEFAULT_RESERVED_DECLARATION_KEYS = frozenset(
    {
        "_default_value",
        "_type",
        "_min",
        "_max",
        "_min_length",
        "_max_length",
        "_allowed_values",
        "_validator",
    }
)


class DeclarationKind(Enum):
    """Supported declaration forms for managed fields."""

    SHORTHAND = "shorthand"
    ENHANCED = "enhanced"


@dataclass(frozen=True, slots=True)
class ReservedNamePolicy:
    """Policy object for reserved schema names and declaration keys."""

    reserved_sections: frozenset[str] = field(
        default_factory=lambda: DEFAULT_RESERVED_SECTION_NAMES
    )
    reserved_declaration_keys: frozenset[str] = field(
        default_factory=lambda: DEFAULT_RESERVED_DECLARATION_KEYS
    )
    reserved_prefix: str = "_"

    def __post_init__(self) -> None:
        object.__setattr__(self, "reserved_sections", frozenset(self.reserved_sections))
        object.__setattr__(
            self,
            "reserved_declaration_keys",
            frozenset(self.reserved_declaration_keys),
        )

    def is_reserved_section(self, name: str) -> bool:
        """Return whether a section name is reserved."""
        return name in self.reserved_sections

    def is_reserved_key(self, name: str) -> bool:
        """Return whether a declaration key belongs to the reserved namespace."""
        return name.startswith(self.reserved_prefix)

    def is_known_declaration_key(self, name: str) -> bool:
        """Return whether a reserved declaration key is part of the supported v1 surface."""
        return name in self.reserved_declaration_keys

    def unknown_reserved_keys(self, keys: Iterable[str]) -> tuple[str, ...]:
        """Return reserved keys that are not part of the supported v1 schema surface."""
        return tuple(
            sorted(
                key
                for key in keys
                if self.is_reserved_key(key) and not self.is_known_declaration_key(key)
            )
        )

    def with_reserved_sections(self, names: Iterable[str]) -> ReservedNamePolicy:
        """Return a copy with additional reserved section names."""
        return ReservedNamePolicy(
            reserved_sections=self.reserved_sections.union(names),
            reserved_declaration_keys=self.reserved_declaration_keys,
            reserved_prefix=self.reserved_prefix,
        )


@dataclass(frozen=True, slots=True)
class SchemaField:
    """Managed field definition parsed from defaults."""

    name: str
    default_value: Any
    declaration_kind: DeclarationKind = DeclarationKind.SHORTHAND
    declared_type: str | None = None
    minimum: Any | None = None
    maximum: Any | None = None
    min_length: int | None = None
    max_length: int | None = None
    allowed_values: tuple[Any, ...] = ()
    validator_name: str | None = None

    def __post_init__(self) -> None:
        object.__setattr__(self, "allowed_values", tuple(self.allowed_values))


@dataclass(frozen=True, slots=True)
class SchemaSection:
    """Managed section definition composed of one or more managed fields."""

    name: str
    fields: tuple[SchemaField, ...] = ()

    def __post_init__(self) -> None:
        object.__setattr__(self, "fields", tuple(self.fields))

    def get_field(self, name: str) -> SchemaField | None:
        """Return a field by name if it exists in the section."""
        return next((field for field in self.fields if field.name == name), None)

    @property
    def field_names(self) -> tuple[str, ...]:
        """Return the ordered field names for this section."""
        return tuple(field.name for field in self.fields)


@dataclass(frozen=True, slots=True)
class BoundSchema:
    """Top-level managed schema assembled from one or more defaults files."""

    sections: tuple[SchemaSection, ...] = ()
    reserved_name_policy: ReservedNamePolicy = field(default_factory=ReservedNamePolicy)

    def __post_init__(self) -> None:
        object.__setattr__(self, "sections", tuple(self.sections))

    def get_section(self, name: str) -> SchemaSection | None:
        """Return a managed section by name if present."""
        return next((section for section in self.sections if section.name == name), None)

    @property
    def section_names(self) -> tuple[str, ...]:
        """Return the ordered managed section names."""
        return tuple(section.name for section in self.sections)
