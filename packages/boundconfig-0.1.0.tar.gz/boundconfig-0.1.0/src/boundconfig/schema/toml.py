from __future__ import annotations

from collections.abc import Sequence
from pathlib import Path
from typing import Any

from tomlkit.items import AoT, InlineTable, Table

from ..adapters import TomlAdapter
from ..exceptions import (
    DuplicateFieldDefinitionError,
    DuplicateSectionDefinitionError,
    InvalidSchemaDeclarationError,
    ReservedSectionNameError,
    UnknownReservedKeyError,
)
from .loader import SchemaLoader
from .models import BoundSchema, DeclarationKind, ReservedNamePolicy, SchemaField, SchemaSection


class TomlSchemaLoader(SchemaLoader[BoundSchema]):
    """Load managed schema declarations from TOML defaults files."""

    def __init__(
        self,
        *,
        adapter: TomlAdapter | None = None,
        reserved_name_policy: ReservedNamePolicy | None = None,
    ) -> None:
        self._adapter = adapter or TomlAdapter()
        self._reserved_name_policy = reserved_name_policy or ReservedNamePolicy()

    def load_schema(self, defaults_paths: Sequence[Path]) -> BoundSchema:
        """Parse one or more defaults files into the internal schema model."""
        sections: list[SchemaSection] = []
        seen_section_names: set[str] = set()

        for defaults_path in defaults_paths:
            document = self._adapter.load_document(defaults_path)
            for section in self._parse_document(document):
                if section.name in seen_section_names:
                    raise DuplicateSectionDefinitionError(section.name)

                seen_section_names.add(section.name)
                sections.append(section)

        return BoundSchema(
            sections=tuple(sections),
            reserved_name_policy=self._reserved_name_policy,
        )

    def _parse_document(self, document: Any) -> tuple[SchemaSection, ...]:
        sections: list[SchemaSection] = []

        for section_name, raw_section in document.items():
            if not isinstance(raw_section, Table):
                raise InvalidSchemaDeclarationError(
                    "Defaults files must define managed fields inside top-level TOML sections.",
                    field_name=str(section_name),
                )

            sections.append(self._parse_section(str(section_name), raw_section))

        return tuple(sections)

    def _parse_section(self, section_name: str, raw_section: Table) -> SchemaSection:
        if self._reserved_name_policy.is_reserved_section(section_name):
            raise ReservedSectionNameError(section_name)

        fields: list[SchemaField] = []
        seen_field_names: set[str] = set()

        for field_name, raw_value in raw_section.items():
            field_name_str = str(field_name)

            if field_name_str in seen_field_names:
                raise DuplicateFieldDefinitionError(section_name, field_name_str)

            seen_field_names.add(field_name_str)

            if isinstance(raw_value, Table):
                raise InvalidSchemaDeclarationError(
                    "Nested tables are outside the v1 managed schema scope.",
                    section_name=section_name,
                    field_name=field_name_str,
                )

            if isinstance(raw_value, AoT):
                raise InvalidSchemaDeclarationError(
                    "Arrays of tables are outside the v1 managed schema scope.",
                    section_name=section_name,
                    field_name=field_name_str,
                )

            fields.append(self._parse_field(section_name, field_name_str, raw_value))

        return SchemaSection(name=section_name, fields=tuple(fields))

    def _parse_field(self, section_name: str, field_name: str, raw_value: Any) -> SchemaField:
        if not isinstance(raw_value, InlineTable):
            return SchemaField(
                name=field_name,
                default_value=self._unwrap_value(raw_value),
                declaration_kind=DeclarationKind.SHORTHAND,
            )

        reserved_keys = tuple(
            str(key_name)
            for key_name, _ in raw_value.items()
            if self._reserved_name_policy.is_reserved_key(str(key_name))
        )
        if not reserved_keys:
            return SchemaField(
                name=field_name,
                default_value=self._unwrap_value(raw_value),
                declaration_kind=DeclarationKind.SHORTHAND,
            )

        unknown_reserved_keys = self._reserved_name_policy.unknown_reserved_keys(reserved_keys)
        if unknown_reserved_keys:
            raise UnknownReservedKeyError(
                unknown_reserved_keys[0],
                section_name=section_name,
                field_name=field_name,
            )

        declaration_keys = tuple(str(key_name) for key_name, _ in raw_value.items())
        invalid_keys = tuple(
            key_name
            for key_name in declaration_keys
            if not self._reserved_name_policy.is_reserved_key(key_name)
        )
        if invalid_keys:
            raise InvalidSchemaDeclarationError(
                "Enhanced declarations may only contain reserved `_...` schema keys.",
                section_name=section_name,
                field_name=field_name,
            )

        if "_default_value" not in raw_value:
            raise InvalidSchemaDeclarationError(
                "Enhanced declarations must define `_default_value`.",
                section_name=section_name,
                field_name=field_name,
            )

        return SchemaField(
            name=field_name,
            default_value=self._unwrap_value(raw_value["_default_value"]),
            declaration_kind=DeclarationKind.ENHANCED,
            declared_type=self._get_optional_metadata(raw_value, "_type"),
            minimum=self._get_optional_metadata(raw_value, "_min"),
            maximum=self._get_optional_metadata(raw_value, "_max"),
            min_length=self._get_optional_metadata(raw_value, "_min_length"),
            max_length=self._get_optional_metadata(raw_value, "_max_length"),
            allowed_values=self._get_allowed_values(raw_value),
            validator_name=self._get_validator_name(
                declaration=raw_value,
                section_name=section_name,
                field_name=field_name,
            ),
        )

    @staticmethod
    def _unwrap_value(value: Any) -> Any:
        if hasattr(value, "unwrap"):
            return value.unwrap()

        return value

    def _get_optional_metadata(self, declaration: InlineTable, key_name: str) -> Any | None:
        if key_name not in declaration:
            return None

        return self._unwrap_value(declaration[key_name])

    def _get_allowed_values(self, declaration: InlineTable) -> tuple[Any, ...]:
        if "_allowed_values" not in declaration:
            return ()

        raw_allowed_values = self._unwrap_value(declaration["_allowed_values"])
        return tuple(raw_allowed_values)

    def _get_validator_name(
        self,
        *,
        declaration: InlineTable,
        section_name: str,
        field_name: str,
    ) -> str | None:
        if "_validator" not in declaration:
            return None

        validator_name = self._unwrap_value(declaration["_validator"])
        if not isinstance(validator_name, str) or not validator_name.strip():
            raise InvalidSchemaDeclarationError(
                "`_validator` must be a non-empty string validator name.",
                section_name=section_name,
                field_name=field_name,
            )

        return validator_name
