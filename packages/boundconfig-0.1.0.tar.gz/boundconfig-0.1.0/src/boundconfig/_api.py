from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

from tomlkit import TOMLDocument

from .adapters import TomlAdapter
from .merge.engine import TomlMergeEngine
from .repair.engine import TomlRepairEngine
from .schema import BoundSchema, TomlSchemaLoader
from .validation import TomlValidationEngine, ValidationReport
from .validators import CustomValidator, ValidatorRegistry, get_shared_validator_registry


def register_validator(
    name: str,
    validator: CustomValidator,
    *,
    registry: ValidatorRegistry[CustomValidator] | None = None,
) -> None:
    """Register a named custom validator in the shared or provided registry."""
    target_registry = registry or get_shared_validator_registry()
    target_registry.register(name, validator)


@dataclass(slots=True)
class BoundConfig:
    """Thin public API over the TOML schema, merge, validation, and repair components."""

    config_path: Path | None = None
    defaults_paths: tuple[Path, ...] = field(default_factory=tuple)
    adapter: TomlAdapter = field(default_factory=TomlAdapter)
    schema_loader: TomlSchemaLoader = field(default_factory=TomlSchemaLoader)
    merge_engine: TomlMergeEngine = field(default_factory=TomlMergeEngine)
    validation_engine: TomlValidationEngine = field(default_factory=TomlValidationEngine)
    repair_engine: TomlRepairEngine = field(default_factory=TomlRepairEngine)
    validator_registry: ValidatorRegistry[CustomValidator] = field(
        default_factory=get_shared_validator_registry
    )

    def __post_init__(self) -> None:
        if self.config_path is not None:
            object.__setattr__(self, "config_path", Path(self.config_path))

        object.__setattr__(
            self,
            "defaults_paths",
            tuple(Path(defaults_path) for defaults_path in self.defaults_paths),
        )

        if isinstance(self.merge_engine, TomlMergeEngine):
            self.merge_engine.adapter = self.adapter

        if isinstance(self.validation_engine, TomlValidationEngine):
            self.validation_engine.validator_registry = self.validator_registry

        if isinstance(self.repair_engine, TomlRepairEngine):
            self.repair_engine.adapter = self.adapter
            self.repair_engine.validation_engine = self.validation_engine

    def register_validator(self, name: str, validator: CustomValidator) -> None:
        """Register a named custom validator in this instance's configured registry."""
        self.validator_registry.register(name, validator)

    def load_schema(self) -> BoundSchema:
        """Load the managed schema from the configured defaults files."""
        return self.schema_loader.load_schema(self._require_defaults_paths())

    def init(self, *, dry_run: bool = False) -> TOMLDocument:
        """Merge missing managed content into the working config document."""
        schema = self.load_schema()
        merged_document = self.merge_engine.merge(schema, self._load_document_or_empty())

        if not dry_run:
            config_path = self._require_config_path()
            config_path.parent.mkdir(parents=True, exist_ok=True)
            self.adapter.dump_document(merged_document, config_path)

        return merged_document

    def validate(self) -> ValidationReport:
        """Validate the working config document against the managed schema."""
        schema = self.load_schema()
        return self.validation_engine.validate(schema, self._load_document_or_empty())

    def repair(self, *, dry_run: bool = False) -> TOMLDocument:
        """Repair missing or invalid managed content in the working config document."""
        schema = self.load_schema()
        repaired_document = self.repair_engine.repair(schema, self._load_document_or_empty())

        if not dry_run:
            config_path = self._require_config_path()
            config_path.parent.mkdir(parents=True, exist_ok=True)
            self.adapter.dump_document(repaired_document, config_path)

        return repaired_document

    def _load_document_or_empty(self) -> TOMLDocument:
        config_path = self._require_config_path()
        if not config_path.exists():
            return self.adapter.empty_document()

        return self.adapter.load_document(config_path)

    def _require_config_path(self) -> Path:
        if self.config_path is None:
            raise ValueError("A config path is required.")

        return self.config_path

    def _require_defaults_paths(self) -> tuple[Path, ...]:
        if not self.defaults_paths:
            raise ValueError("At least one defaults path is required.")

        return self.defaults_paths
