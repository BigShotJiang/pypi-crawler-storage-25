# -*- coding:utf-8 -*-
#####################
# BACKEND FUNCTIONS #
#####################
# FORKED FROM CMD ATE DATA READER
from abc import ABC
import numpy as np
import matplotlib
from mpl_toolkits.mplot3d import Axes3D

matplotlib.use('Agg')
import matplotlib.pyplot as plt
import pandas as pd
from decimal import Decimal
import os

# IMPORTANT DOCUMENTATION I NEED TO FILL OUT TO MAKE SURE PEOPLE KNOW WHAT THE HELL IS GOING ON

# ~~~~~~~~~~ Data definition explanations (in functions) ~~~~~~~~~~ #
#                                                                   #
# test_tuple --> ['test_number', 'test_name']                       #
#   Structure for associating a test's name with its test number    #
#                                                                   #
# test_list --> List of test_tuple                                  #
#   find_test_of_number() returns this                              #
#   list_of_test_numbers in main() is the complete list of this     #
#                                                                   #
# num_of_sites --> number of testing sites for each test run        #
#   number_of_sites = int(sdr_parse[3]) in main()                   #
#                                                                   #
# test_info_list --> list of sets of site_data                      #
#   (sorted in the same order as corresponding tests in test_list)  #
#                                                                   #
# site_data --> array of float data points number_of_sites long     #
#   raw data for a single corresponding test_tuple                  #
#                                                                   #
# test_list and test_info_list are the same length                  #
#                                                                   #
# minimum, maximum --> floats                                       #
#   lower and upper extremes for a site_data from a corresponding   #
#       test_tuple. These are found in the ptr_data (data), which   #
#       has the values located in one of the columns for the first  #
#       test site in the first data point in a test.                #
#   returned by get_plot_extremes() abstraction                     #
# units --> string                                                  #
#   Gathered virtually identically to minimum and maximum.          #
#       Represents units for plotting and post calculations on      #
#       data sets.                                                  #
#                                                                   #
# ~~~~~~~~~~~~ Parsed text file structure explanation ~~~~~~~~~~~~~ #
# The PySTDF library parses the data really non-intuitively,        #
#   although it can be viewed somewhat more clearly if you use the  #
#   toExcel() function (I recommend doing this for figuring out the #
#   way the file is formatted). Basically, each '|' separates the   #
#   information in columns, and the first column determines the     #
#   "page" you are dealing with. The only ones I found particularly #
#   useful were SDR (for the number of sites) and PTR (where all    #
#   the data is actually contained).                                #
# The way the PTR data is parsed is very non-intuitive still, with  #
#   the data broken into chunks num_of_sites lines long, meaning    #
#   each chunk of num_of_sites lines contain a corresponding        #
#   test_tuple that can be extracted, as well as a data point       #
#   result for each test site. This is then done for every single   #
#   test_tuple combination. After all that is done, the process is  #
#   repeated for every single run of the test, creating a new data  #
#   point for each site in each test tuple for however many numbers #
#   of tests there are.                                             #
# It's very not obvious at first, so I strongly recommend creating  #
#   an excel file first to look at it yourself and reverse-engineer #
#   it like I did if you really want to try and figure out the file #
#   format yourself. I'm sorry the library sucks but I didn't       #
#   design it :/ . Good luck!                                       #
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ #


# This is horrible design and I'm so sorry, but here's a huge library full of static methods for processing the data
# These were all taken virtually verbatim from the previous program so have mercy on me
class Backend(ABC):

    # Plots the results of everything from one test
    @staticmethod
    def plot_everything_from_one_test(test_data, sdr_parse, data, num_of_sites, test_tuple, fail_limit, group_by_file):

        # Find the limits
        low_lim = Backend.get_plot_min(data, test_tuple, num_of_sites)
        hi_lim = Backend.get_plot_max(data, test_tuple, num_of_sites)
        units = Backend.get_units(data, test_tuple, num_of_sites)

        print(test_tuple)

        # if low_lim == float('-inf'):
        #
        #     if min(np.concatenate(test_data)) < 0:
        #         low_lim = min(np.concatenate(test_data, axis=0))
        # 
        #     else:
        #         low_lim = 0
        #
        # if hi_lim == float('inf') or low_lim > hi_lim:
        #     hi_lim = max(np.concatenate(test_data, axis=0))

        # Title for everything
        plt.suptitle(
            str("Test: " + test_tuple[0] + " - " + test_tuple[1] + " - Units: " + units))

        # Plots the table of results, showing a max of 16 sites at once, plus all the collective data
        table = Backend.table_of_results(test_data, sdr_parse, low_lim, hi_lim, units)
        # cell_text = table.copy()
        plt.subplot2grid((2, 3), (1, 2))
        cell_text = []
        for row in range(len(table)):
            cell_text.append([table.index[row]] + table.iloc[row].to_list())

        plt.table(cellText=cell_text, loc='center')
        plt.axis('off')
        # else:
        # Plots the trendline
        plt.subplot2grid((2, 3), (0, 0), colspan=3)
        Backend.plot_full_test_trend(test_data, low_lim, hi_lim, fail_limit, sdr_parse, group_by_file)
        plt.xlabel("Trials")
        plt.ylabel(units)
        plt.title("Trendline")
        plt.grid(color='0.9', linestyle='--', linewidth=1)

        # Plots the histogram
        ax = plt.subplot2grid((2, 3), (1, 0), colspan=2, projection='3d')
        Backend.plot_full_test_hist(test_data, low_lim, hi_lim, fail_limit, ax)
        ax.set_xlabel(units)
        # ax.set_xticklabels(units, rotation=45)
        ax.set_ylabel('Site')
        ax.set_zlabel("Trials")
        # ax.legend(loc='best')
        # plt.xlabel(units)
        # plt.xticks(rotation=45)  # Tilted 45 degree angle
        # plt.ylabel("Trials")
        # plt.title("Histogram")
        # plt.grid(color='0.9', linestyle='--', linewidth=1, axis='y')
        # plt.legend(loc='best')

    # TestNumber (string) + ListOfTests (list of tuples) -> ListOfTests with TestNumber as the 0th index (list of tuples)
    # Takes a string representing a test number and returns any test names associated with that test number
    #   e.g. one test number may be 1234 and might have 40 tests run on it, but it may be 20 tests under
    #   the name "device_test_20kHz" and then another 20 tests under the name "device_test_100kHz", meaning
    #   there were two unique tests run under the same test number.
    @staticmethod
    def find_tests_of_number(test_number, test_list):
        tests_of_number = []
        for i in range(0, len(test_list)):
            if test_list[i][0] == test_number:
                tests_of_number.append(test_list[i])

        return tests_of_number

    # Returns the lower allowed limit of a set of data
    @staticmethod
    def get_plot_min(data, test_tuple, num_of_sites):
        minimum = Backend.get_plot_extremes(data, test_tuple, num_of_sites)[0]
        try:

            smallboi = float(minimum)

        except ValueError:

            smallboi = float('-inf') #'n/a'

        return smallboi

    # Returns the upper allowed limit of a set of data
    @staticmethod
    def get_plot_max(data, test_tuple, num_of_sites):

        maximum = Backend.get_plot_extremes(data, test_tuple, num_of_sites)[1]

        try:

            bigboi = float(maximum)

        except ValueError:

            bigboi = float('inf') #'n/a'

        return bigboi

    # Returns the units for a set of data
    @staticmethod
    def get_units(data, test_tuple, num_of_sites):
        return Backend.get_plot_extremes(data, test_tuple, num_of_sites)[2]

    # Abstraction of above 3 functions, returns tuple with min and max
    @staticmethod
    def get_plot_extremes(data, test_tuple, num_of_sites):
        minimum_test = 0
        maximum_test = 1
        units = ''
        temp = 0
        not_found = True
        while not_found:
            # try:
            # if data[temp].split("|")[1] == test_tuple[0]:
            #     minimum_test = (data[temp].split("|")[13])
            #     maximum_test = (data[temp].split("|")[14])
            #     units = (data[temp].split("|")[15])
            #     not_found = False

            # Check data out with TNUM&TNAME
            if data[temp][4] == test_tuple[0] and data[temp][0] == test_tuple[1]:
                minimum_test = data[temp][2]
                maximum_test = data[temp][1]
                units = data[temp][3]
                not_found = False
            temp += 1  # num_of_sites
            # except IndexError:
            #     os.system('pause')
        return [minimum_test, maximum_test, units]

    # Plots the results of all sites from one test
    @staticmethod
    def plot_full_test_trend(test_data, minimum, maximum, fail_limit, label_list, group_by_file):

        data_min = min(np.concatenate(test_data, axis=0))
        data_max = max(np.concatenate(test_data, axis=0))

        # in case of (-inf,inf)
        if (minimum == float('-inf')) or (maximum == float('inf')):
            minimum = data_min
            maximum = data_max

        expand = max([abs(minimum), abs(maximum)])

        # Plots each site one at a time
        for i in range(0, len(test_data)):
            Backend.plot_single_site_trend(test_data[i], group_by_file, label_list, i)
        plt.legend()

        # Plots the minimum and maximum barriers
        if fail_limit:
            if minimum == float('-inf'):
                plt.plot(range(0, len(test_data[0])), [
                    0] * len(test_data[0]), color="red", linewidth=3.0)
                plt.plot(range(0, len(test_data[0])), [
                    maximum] * len(test_data[0]), color="red", linewidth=3.0)

            elif maximum == float('inf'):
                plt.plot(range(0, len(test_data[0])), [
                    minimum] * len(test_data[0]), color="red", linewidth=3.0)
                plt.plot(range(0, len(test_data[0])), [max(np.concatenate(
                    test_data, axis=0))] * len(test_data[0]), color="red", linewidth=3.0)

            else:
                plt.plot(range(0, len(test_data[0])), [
                    minimum] * len(test_data[0]), color="red", linewidth=3.0)
                plt.plot(range(0, len(test_data[0])), [
                    maximum] * len(test_data[0]), color="red", linewidth=3.0)

        if fail_limit:

            # My feeble attempt to get pretty dynamic limits
            if minimum == maximum:
                plt.ylim(ymin=minimum - abs(0.05 * expand))
                # try:
                plt.ylim(ymax=maximum + abs(0.05 * expand))
                # except ValueError:
                #     # print(type(maximum))
                #     print(max(maximum + abs(0.05 * expand), 1.05))
                #     os.system('pause')
            else:
                # try:
                plt.ylim(ymin=minimum - abs(0.05 * expand))
                # except ValueError:
                #     print(type(minimum))
                #     print(minimum)
                plt.ylim(ymax=maximum + abs(0.05 * expand))
        else:
            if minimum == maximum:
                plt.ylim(ymin=minimum - abs(0.05 * expand))
                plt.ylim(ymax=maximum + abs(0.05 * expand))
            else:
                plt.ylim(ymin=(min(data_min, minimum - abs(0.05 * expand))))
                # try:
                plt.ylim(ymax=(max(data_max, maximum + abs(0.05 * expand))))
                # except BaseException:
                #     print(min(data_min, minimum - abs(0.05 * expand)))
                #     print(max(data_max, maximum + abs(0.05 * expand)))
                #     os.system('pause')

    # Returns the table of the results of all the tests to visualize the data
    @staticmethod
    def table_of_results(test_data, sdr_parse, minimum, maximum, units):
        parameters = ['Site', 'Units', 'Runs', 'Fails', 'LowLimit', 'HiLimit',
                      'Min', 'Mean', 'Max', 'Range', 'STD', 'Cp', 'Cpl', 'Cpu', 'Cpk']

        # Clarification
        if 'db' in units.lower():
            parameters[7] = 'STD (%)'

        all_data = np.concatenate(test_data, axis=0)

        test_results = [Backend.site_array(
            all_data, minimum, maximum, 'ALL', units)]

        for i in range(0, len(sdr_parse)):
            test_results.append(Backend.site_array(
                test_data[i], minimum, maximum, sdr_parse[i], units))

        table = pd.DataFrame(test_results, columns=parameters).T

        return table

    # Returns an array a site's final test results
    @staticmethod
    def site_array(site_data, minimum, maximum, site_number, units):

        high_limit = maximum
        low_limit = minimum
        if units.startswith('Unnamed'):
            units = ''
        # if minimum == 'n/a' and maximum == 'n/a':
        #     minimum = 0
        #     maximum = 0

        # if (minimum == float('-inf')) or (maximum == float('inf')):
        #     minimum = 0
        #     maximum = 0

        if (minimum is None) and (maximum is None):
            minimum = 0
            maximum = 0
        # Big boi initialization
        site_results = []

        if len(site_data) == 0:
            return site_results

        # Not actually volts, it's actually % if it's db technically but who cares
        volt_data = []

        # Pass/fail data is stupid
        if minimum == maximum or min(site_data) == max(site_data) or \
                ((minimum == float('-inf')) or (maximum == float('inf'))):
            mean_result = np.mean(site_data)
            std_string = str(np.std(site_data))
            cp_result = 'n/a'
            cpl_result = 'n/a'
            cpu_result = 'n/a'
            cpk_result = 'n/a'

        # The struggles of logarithmic data
        elif 'db' in units.lower():

            for i in range(0, len(site_data)):
                volt_data.append(Backend.db2v(site_data[i]))

            mean_result = Backend.v2db(np.mean(volt_data))
            standard_deviation = np.std(
                volt_data) * 100  # *100 for converting to %
            std_string = str('%.3E' % (Decimal(standard_deviation)))

            cp_result = float(Decimal(Backend.cp(volt_data, Backend.db2v(
                minimum), Backend.db2v(maximum))).quantize(Decimal('0.001')))
            cpl_result = str(Decimal(Backend.cpl(
                volt_data, Backend.db2v(minimum))).quantize(Decimal('0.001')))
            cpu_result = str(Decimal(Backend.cpu(
                volt_data, Backend.db2v(maximum))).quantize(Decimal('0.001')))
            cpk_result = float(Decimal(Backend.cpk(volt_data, Backend.db2v(
                minimum), Backend.db2v(maximum))).quantize(Decimal('0.001')))

        # Yummy linear data instead
        else:
            mean_result = np.mean(site_data)
            # try:
            std_string = str(
                Decimal(np.std(site_data)).quantize(Decimal('0.001')))
            cp_result = float(
                Decimal(Backend.cp(site_data, minimum, maximum)).quantize(Decimal('0.001')))
            cpl_result = str(
                Decimal(Backend.cpl(site_data, minimum)).quantize(Decimal('0.001')))
            cpu_result = str(
                Decimal(Backend.cpu(site_data, maximum)).quantize(Decimal('0.001')))
            cpk_result = float(
                Decimal(Backend.cpk(site_data, minimum, maximum)).quantize(Decimal('0.001')))
            # except Exception as e:
            #     print(type(minimum))
            #     print(minimum)
            #     print(maximum)
            #     os.system("pause")
            # raise UnexpectedSymbol(minimum, maximum)

        # Appending all the important results weow!
        site_results.append(str(site_number))
        site_results.append(units)
        site_results.append(str(len(site_data)))
        site_results.append(
            str(Backend.calculate_fails(site_data, minimum, maximum)))
        # try:
        if low_limit == None or low_limit == float('inf') or low_limit == float('-inf') or low_limit == 'n/a':
            site_results.append(str(low_limit))
        else:
            site_results.append(str(Decimal(low_limit).quantize(Decimal('0.000000001'))))
        if high_limit == None or high_limit == float('inf') or high_limit == float('-inf') or low_limit == 'n/a':
            site_results.append(str(high_limit))
        else:
            site_results.append(str(Decimal(high_limit).quantize(Decimal('0.000000001'))))


        # site_results.append(
        #     str(Decimal(float(min(site_data))).quantize(Decimal('0.000001'))))
        site_results.append(Backend.format_large_number(np.min(site_data)))

        # try:
        #     site_results.append(
        #         str(Decimal(mean_result).quantize(Decimal('0.000001'))))
        # except Exception as e:
        #     site_results.append(str(mean_result))
        #     print(e)
        #     #os.system('pause')
        site_results.append(Backend.format_large_number(mean_result))
        # site_results.append(
        #     str(Decimal(float(max(site_data))).quantize(Decimal('0.000001'))))
        site_results.append(Backend.format_large_number(np.max(site_data)))
        # site_results.append(
        #     str(Decimal(float(np.max(site_data) - np.min(site_data))).quantize(Decimal('0.000001'))))
        site_results.append(Backend.format_large_number(np.max(site_data) - np.min(site_data)))

        site_results.append(std_string)
        site_results.append(cp_result)
        site_results.append(cpl_result)
        site_results.append(cpu_result)
        site_results.append(cpk_result)

        return site_results

    @staticmethod
    def format_large_number(value):
        try:
            if abs(value) > 1e6:
                return "{:.6e}".format(float(value))  # 科学计数法
            else:
                return "{:.9f}".format(float(value))  # 普通小数
        except (TypeError, ValueError):
            return str(value)  # 保底处理

    # Converts to decibels
    @staticmethod
    def v2db(v):
        return 20 * np.log10(abs(v))

    # Converts from decibels
    @staticmethod
    def db2v(db):
        return 10 ** (db / 20)

    # Function to convert from mW to dBm
    @staticmethod
    def mW2dBm(mW):
        return 10. * np.log10(mW)

    # Function to convert from dBm to mW
    @staticmethod
    def dBm2mW(dBm):
        return 10 ** ((dBm) / 10.)

    # Counts the number of fails in a data set
    @staticmethod
    def calculate_fails(site_data, minimum, maximum):
        fails_count = 0
        if (minimum != float('-inf') or maximum != float('inf')) and (minimum != 'n/a' and maximum != 'n/a'):
            # Increase a fails counter for every data point that exceeds an extreme
            for i in range(0, len(site_data)):
                if site_data[i] > float(maximum) or site_data[i] < float(minimum):
                    fails_count += 1

        return fails_count

    # Plots the historgram results of all sites from one test
    @staticmethod
    def plot_full_test_hist(test_data, minimum, maximum, fail_limit, ax):

        # in case of inf
        if minimum == float('-inf'):
            new_minimum = min(np.concatenate(test_data, axis=0))
        else:
            new_minimum = min(min(np.concatenate(test_data, axis=0)), minimum)
        if maximum == float('inf'):
            new_maximum = max(np.concatenate(test_data, axis=0))
        else:
            new_maximum = max(max(np.concatenate(test_data, axis=0)), maximum)

        # if (minimum == float('-inf')) or (maximum == float('inf')):
        #     minimum = 0
        #     maximum = 0

        # Plots each site one at a time
        for i in range(0, len(test_data)):
            Backend.plot_single_site_hist(
                test_data[i], new_minimum, new_maximum, test_data, i, ax)

        if fail_limit == False:

            # My attempt to get pretty dynamic limits
            if minimum == maximum:
                expand = abs(20.0 * minimum)
                # plt.xlim(xmin=minimum - abs(0.25 * minimum))
                # plt.xlim(xmax=minimum + abs(0.25 * minimum))

            elif minimum == float('-inf') and maximum != float('inf'):
                expand = abs(maximum)
                # plt.xlim(xmin=new_minimum - abs(0.05 * expand))
                # plt.xlim(xmax=new_maximum + abs(0.05 * expand))

            elif maximum == float('inf') and minimum != float('-inf'):
                expand = abs(minimum)
                # plt.xlim(xmin=new_minimum - abs(0.05 * expand))
                # plt.xlim(xmax=new_maximum + abs(0.05 * expand))

            elif maximum == float('inf') and minimum == float('-inf'):
                expand = max([abs(new_minimum), abs(new_maximum)])
                # plt.xlim(xmin=new_minimum - abs(0.05 * expand))
                # plt.xlim(xmax=new_maximum + abs(0.05 * expand))
            else:
                expand = max([abs(minimum), abs(maximum)])
                # plt.xlim(xmin=new_minimum - abs(0.05 * expand))
                # plt.xlim(xmax=new_maximum + abs(0.05 * expand))
            ax.set_xlim(new_minimum - abs(0.05 * expand), new_maximum + abs(0.05 * expand))

        else:

            if minimum == maximum:
                # plt.axvline(x=minimum, linestyle="--")
                # plt.axvline(x=minimum, linestyle="--")
                # plt.xlim(xmin=minimum - 1)
                # plt.xlim(xmax=minimum + 1)
                expand = abs(20.0 * minimum)

            elif minimum == float('-inf') and maximum != float('inf'):
                expand = abs(maximum)
                # plt.axvline(x=maximum, linestyle="--")
                # plt.xlim(xmin=new_minimum - abs(0.1 * expand))
                # plt.xlim(xmax=new_maximum + abs(0.1 * expand))

            elif maximum == float('inf') and minimum != float('-inf'):
                expand = abs(minimum)
                # plt.axvline(x=minimum, linestyle="--")
                # plt.xlim(xmin=new_minimum - abs(0.1 * expand))
                # plt.xlim(xmax=new_maximum + abs(0.1 * expand))

            elif maximum == float('inf') and minimum == float('-inf'):
                expand = 20 # max([abs(new_minimum), abs(new_maximum)])
                # plt.xlim(xmin=new_minimum - 1)
                # plt.xlim(xmax=new_maximum + 1)
            else:
                expand = max([abs(minimum), abs(maximum)])
                # ax.axvline(x=minimum, linestyle="--")
                # ax.axvline(x=maximum, linestyle="--")
            ax.set_xlim(new_minimum - abs(0.05 * expand), new_maximum + abs(0.05 * expand))
        # Nop this command for the figure may shift out of sight when the values too close
        #ax.get_proj = lambda: np.dot(Axes3D.get_proj(ax), np.diag([1.2, 1, 1, 1]))

        # ax.set_zlim(0,len(test_data[0]))

    # Plots a single site's results
    @staticmethod
    def plot_single_site_trend(site_data, group_by_file, label_list, i):
        marker_list = ['o','+','x','*','.','v','s','p','D','d','^','1']
        if group_by_file:
            plt.scatter(range(0, len(site_data)), site_data, marker=marker_list[i], alpha=0.6, label=label_list[i])
        else:
            plt.plot(range(0, len(site_data)), site_data, marker=marker_list[i % 12], alpha=0.6, label='site ' + str(label_list[i]))

    # Plots a single site's results as a histogram
    @staticmethod
    def plot_single_site_hist(site_data, minimum, maximum, test_data, site_num, ax):

        # if (minimum == float('-inf')) or (maximum == float('inf')):
        #     minimum = 0
        #     maximum = 0

        # At the moment the bins are the same as they are in the previous program's results. Will add fail bin later.

        # Damn pass/fail data exceptions everywhere
        if minimum == maximum:
            binboi = np.linspace(minimum - 1, maximum + 1, 51)

        elif minimum > maximum:
            binboi = np.linspace(minimum, max(
                np.concatenate(test_data, axis=0)), 51)

        elif minimum == float('-inf'):
            binboi = np.linspace(0, maximum, 51)

        elif maximum == float('inf'):
            binboi = np.linspace(minimum, max(
                np.concatenate(test_data, axis=0)), 51)

        else:
            binboi = np.linspace(minimum, maximum, 51)
        # try:
        # plt.hist(site_data, bins=binboi, edgecolor='white', linewidth=0.5, label='site ' + str(site_num))
        hist, bins = np.histogram(site_data, bins=binboi)
        xs = (bins[:-1] + bins[1:]) / 2
        X, Y = np.meshgrid(minimum, np.linspace(0, np.max(hist), 10))
        ax.bar(xs, hist, zs=site_num, zdir='y', alpha=0.8,
               width=np.diff(binboi).mean())  # , label='site ' + str(site_num))
        ax.plot(xs=X.reshape(10), ys=Y.reshape(10), zs=site_num, zdir='y', color='red', linestyle='--')
        X, Y = np.meshgrid(maximum, np.linspace(0, np.max(hist), 10))
        ax.plot(xs=X.reshape(10), ys=Y.reshape(10), zs=site_num, zdir='y', color='red', linestyle='--')
        # except ValueError:
        #     print(binboi)
        #     print(type(minimum))
        #     print(minimum)
        # np.clip(site_data, binboi[0], binboi[-1])

    # Creates an array of arrays that has the raw data for each test site in one particular test
    # expect a 2D array with each row being the reran test results for each of the sites in a particular test
    @staticmethod
    def single_test_data(num_of_sites, extracted_ptr):

        # Me being bad at initializing arrays again, hush
        single_test = []

        # Runs through once for each of the sites in the test, incrementing by 1
        for i in range(0, num_of_sites):

            single_site = []

            # Runs through once for each of the loops of the test, incrementing by the number of test sites until all test
            # loops are covered for the individual testing site. The incremented i offsets it so that it moves on to the
            # next testing site
            for j in range(i, len(extracted_ptr), num_of_sites):
                single_site.append(float(extracted_ptr[j][6]))

            single_test.append(single_site)

        return single_test

    # For the four following functions, site_data is a list of raw floating point data, minimum is the lower limit and
    # maximum is the upper limit

    # CP AND CPK FUNCTIONS
    # Credit to: countrymarmot on github gist:  https://gist.github.com/countrymarmot/8413981
    @staticmethod
    def cp(site_data, minimum, maximum):
        if minimum == float('-inf') or maximum == float('inf'):
            return 'n/a'
        else:
            sigma = np.std(site_data)
            cp_value = float(maximum - minimum) / (6 * sigma)
            return cp_value

    @staticmethod
    def cpk(site_data, minimum, maximum):
        if minimum == float('-inf') or maximum == float('inf'):
            return 'n/a'
        else:
            sigma = np.std(site_data)
            m = np.mean(site_data)
            cpu_value = float(maximum - m) / (3 * sigma)
            cpl_value = float(m - minimum) / (3 * sigma)
            cpk_value = np.min([cpu_value, cpl_value])
            return cpk_value

    # One sided calculations (cpl/cpu)
    @staticmethod
    def cpl(site_data, minimum):
        if minimum == float('-inf'):
            return 'n/a'
        else:
            sigma = np.std(site_data)
            m = np.mean(site_data)
            cpl_value = float(m - minimum) / (3 * sigma)
            return cpl_value

    @staticmethod
    def cpu(site_data, maximum):
        if maximum == float('inf'):
            return 'n/a'
        else:
            sigma = np.std(site_data)
            m = np.mean(site_data)
            cpu_value = float(maximum - m) / (3 * sigma)
            return cpu_value

###################################################
