
# Getting Started with USPS API

## Introduction

Contact Us: [USPS API Support](https://emailus.usps.com/s/usps-APIs) | [Terms of Service](https://about.usps.com/termsofuse.htm)

The Addresses API validates and corrects address information to improve package delivery service and pricing. This suite of APIs provides different utilities for addressing components. The ZIP Code&#8482; lookup finds valid ZIP Code&#8482;(s) for a City and State. The City/State lookup provides the valid cities and states for a provided ZIP Code&#8482;. The Address Standardization API validates and standardizes USPS&#174; domestic addresses, city and state names, and ZIP Code&#8482; in accordance with USPS&#174; addressing standards. The USPS&#174; address standard includes the ZIP + 4&#174;, signifying a USPS&#174; delivery point, given a street address, a city and a state.

## Install the Package

The package is compatible with Python versions `3.7+`.
Install the package from PyPi using the following pip command:

```bash
pip install apimatic-usps-sdk==1.0.0
```

You can also view the package at:
https://pypi.python.org/pypi/apimatic-usps-sdk/1.0.0

## Initialize the API Client

**_Note:_** Documentation for the client can be found [here.](doc/client.md)

The following parameters are configurable for the API Client:

| Parameter | Type | Description |
|  --- | --- | --- |
| environment | [`Environment`](README.md#environments) | The API environment. <br> **Default: `Environment.PRODUCTION`** |
| http_client_instance | `Union[Session, HttpClientProvider]` | The Http Client passed from the sdk user for making requests |
| override_http_client_configuration | `bool` | The value which determines to override properties of the passed Http Client from the sdk user |
| http_call_back | `HttpCallBack` | The callback value that is invoked before and after an HTTP call is made to an endpoint |
| timeout | `float` | The value to use for connection timeout. <br> **Default: 30** |
| max_retries | `int` | The number of times to retry an endpoint call if it fails. <br> **Default: 0** |
| backoff_factor | `float` | A backoff factor to apply between attempts after the second try. <br> **Default: 2** |
| retry_statuses | `Array of int` | The http statuses on which retry is to be done. <br> **Default: [408, 413, 429, 500, 502, 503, 504, 521, 522, 524]** |
| retry_methods | `Array of string` | The http methods on which retry is to be done. <br> **Default: ["GET", "PUT"]** |
| proxy_settings | [`ProxySettings`](doc/proxy-settings.md) | Optional proxy configuration to route HTTP requests through a proxy server. |
| logging_configuration | [`LoggingConfiguration`](doc/logging-configuration.md) | The SDK logging configuration for API calls |
| oauth_authorization_code_credentials | [`OauthAuthorizationCodeCredentials`](__base_path/auth/oauth-2-authorization-code-grant.md) | The credential object for OAuth 2 Authorization Code Grant |
| oauth_client_credentials_credentials | [`OauthClientCredentialsCredentials`](__base_path/auth/oauth-2-client-credentials-grant.md) | The credential object for OAuth 2 Client Credentials Grant |
| basic_auth_credentials | [`BasicAuthCredentials`](__base_path/auth/basic-authentication.md) | The credential object for Basic Authentication |
| bearer_token_auth_credentials | [`BearerTokenAuthCredentials`](__base_path/auth/oauth-2-bearer-token.md) | The credential object for OAuth 2 Bearer token |

The API client can be initialized as follows:

### Code-Based Client Initialization

```python
import logging

from uspsapi.configuration import Environment
from uspsapi.http.auth.basic_auth import BasicAuthCredentials
from uspsapi.http.auth.bearer_token_auth import BearerTokenAuthCredentials
from uspsapi.http.auth.oauth_authorization_code import OauthAuthorizationCodeCredentials
from uspsapi.http.auth.oauth_client_credentials import OauthClientCredentialsCredentials
from uspsapi.logging.configuration.api_logging_configuration import LoggingConfiguration
from uspsapi.logging.configuration.api_logging_configuration import RequestLoggingConfiguration
from uspsapi.logging.configuration.api_logging_configuration import ResponseLoggingConfiguration
from uspsapi.models.oauth_scope_oauth_authorization_code import OauthScopeOauthAuthorizationCode
from uspsapi.models.oauth_scope_oauth_client_credentials import OauthScopeOauthClientCredentials
from uspsapi.uspsapi_client import UspsapiClient

client = UspsapiClient(
    oauth_authorization_code_credentials=OauthAuthorizationCodeCredentials(
        oauth_client_id='OAuthClientId',
        oauth_client_secret='OAuthClientSecret',
        oauth_redirect_uri='OAuthRedirectUri',
        oauth_scopes=[
            OauthScopeOauthAuthorizationCode.ADDRESSES,
            OauthScopeOauthAuthorizationCode.ADJUSTMENTS
        ]
    ),
    oauth_client_credentials_credentials=OauthClientCredentialsCredentials(
        oauth_client_id='OAuthClientId',
        oauth_client_secret='OAuthClientSecret',
        oauth_scopes=[
            OauthScopeOauthClientCredentials.ADDRESSES,
            OauthScopeOauthClientCredentials.ADJUSTMENTS
        ]
    ),
    basic_auth_credentials=BasicAuthCredentials(
        username='Username',
        password='Password'
    ),
    bearer_token_auth_credentials=BearerTokenAuthCredentials(
        access_token='AccessToken'
    ),
    environment=Environment.PRODUCTION,
    logging_configuration=LoggingConfiguration(
        log_level=logging.INFO,
        request_logging_config=RequestLoggingConfiguration(
            log_body=True
        ),
        response_logging_config=ResponseLoggingConfiguration(
            log_headers=True
        )
    )
)
```

### Environment-Based Client Initialization

```python
from uspsapi.uspsapi_client import UspsapiClient

# Specify the path to your .env file if it’s located outside the project’s root directory.
client = UspsapiClient.from_environment(dotenv_path='/path/to/.env')
```

See the [Environment-Based Client Initialization](doc/environment-based-client-initialization.md) section for details.

## Environments

The SDK can be configured to use a different environment for making API calls. Available environments are:

### Fields

| Name | Description |
|  --- | --- |
| PRODUCTION | **Default** |
| TESTING | - |

## Authorization

This API uses the following authentication schemes.

* [`OAuth_authorization_code (OAuth 2 Authorization Code Grant)`](__base_path/auth/oauth-2-authorization-code-grant.md)
* [`OAuth_client_credentials (OAuth 2 Client Credentials Grant)`](__base_path/auth/oauth-2-client-credentials-grant.md)
* [`BasicAuth (Basic Authentication)`](__base_path/auth/basic-authentication.md)
* [`BearerTokenAuth (OAuth 2 Bearer token)`](__base_path/auth/oauth-2-bearer-token.md)

## List of APIs

* [Listener URL Specification](doc/controllers/listener-url-specification.md)
* [Resources](doc/controllers/resources.md)
* [Files](doc/controllers/files.md)

## SDK Infrastructure

### Configuration

* [ProxySettings](doc/proxy-settings.md)
* [Environment-Based Client Initialization](doc/environment-based-client-initialization.md)
* [AbstractLogger](doc/abstract-logger.md)
* [LoggingConfiguration](doc/logging-configuration.md)
* [RequestLoggingConfiguration](doc/request-logging-configuration.md)
* [ResponseLoggingConfiguration](doc/response-logging-configuration.md)

### HTTP

* [HttpResponse](doc/http-response.md)
* [HttpRequest](doc/http-request.md)

### Utilities

* [ApiResponse](doc/api-response.md)
* [ApiHelper](doc/api-helper.md)
* [HttpDateTime](doc/http-date-time.md)
* [RFC3339DateTime](doc/rfc3339-date-time.md)
* [UnixDateTime](doc/unix-date-time.md)

