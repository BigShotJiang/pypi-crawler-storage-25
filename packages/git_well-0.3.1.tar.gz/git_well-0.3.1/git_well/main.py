#!/usr/bin/env python3
# PYTHON_ARGCOMPLETE_OK
from __future__ import annotations

import scriptconfig as scfg


class GitWellModalCLI(scfg.ModalCLI):
    # When adding a new top-level CLI, need to update:
    # ~/code/git_well/pyproject.toml
    from git_well.git_squash_streaks import __cli__ as squash_streaks
    from git_well.git_squash import __cli__ as squash
    from git_well.git_branch_upgrade import __cli__ as branch_upgrade
    from git_well.git_sync import __cli__ as sync
    from git_well.git_branch_cleanup import __cli__ as branch_cleanup
    from git_well.git_track_upstream import __cli__ as track_upstream
    from git_well.git_rebase_add_continue import __cli__ as rebase_add_continue
    from git_well.git_remote_protocol import __cli__ as remote_protocol
    from git_well.git_discover_remote import __cli__ as discover_remote
    from git_well.git_autoconf_gpgsign import __cli__ as autoconf_gpgsign
    from git_well.git_url_components import __cli__ as url
    from git_well.git_archive_source import __cli__ as archive_source
    from git_well.ipfs import __cli__ as ipfs
    from git_well.patchdir.patchdir_modal import __cli__ as patchdir


def main() -> None:
    from git_well import __version__

    modal = GitWellModalCLI(version=__version__)
    modal.main()


if __name__ == '__main__':
    """
    CommandLine:
        python ~/code/git_well/git_well/main.py --help
    """
    main()
