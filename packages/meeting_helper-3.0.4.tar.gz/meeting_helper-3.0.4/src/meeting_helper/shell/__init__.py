"""New native shell process for the web-based UI.

Replaces `meeting_helper.flet_gui` as the rendering host. Owns the pywebview
window; reuses the existing daemon (HTTP + WS) for all behavior.
"""
