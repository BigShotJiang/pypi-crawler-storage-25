"""Helpers for the shell to find and wait for the daemon HTTP server."""

from __future__ import annotations

import asyncio
import logging
import time
from typing import Any

import aiohttp

logger = logging.getLogger(__name__)


def resolve_url(config: Any) -> str:
    """Build the daemon's local URL from an AppConfig-like object."""
    return f"http://127.0.0.1:{int(config.port)}/"


async def wait_for_health(
    base_url: str,
    timeout: float = 10.0,
    interval: float = 0.25,
) -> bool:
    """Poll `<base_url>health` until it responds 200, up to `timeout` seconds.

    Returns True on the first successful response, False on timeout. Network
    errors (refused connection, DNS failure) are treated as "not ready yet"
    and the loop keeps polling.
    """
    health_url = base_url.rstrip("/") + "/health"
    deadline = time.monotonic() + timeout

    async with aiohttp.ClientSession() as session:
        while time.monotonic() < deadline:
            try:
                async with session.get(
                    health_url, timeout=aiohttp.ClientTimeout(total=interval * 4)
                ) as resp:
                    if resp.status == 200:
                        return True
            except (aiohttp.ClientError, asyncio.TimeoutError):
                pass
            await asyncio.sleep(interval)

    logger.warning("daemon /health unreachable at %s after %.1fs", health_url, timeout)
    return False
