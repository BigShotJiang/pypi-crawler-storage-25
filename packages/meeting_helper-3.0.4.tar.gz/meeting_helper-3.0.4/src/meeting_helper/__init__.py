"""Meeting Helper — AI meeting assistant for macOS."""

__version__ = "3.0.4"
