"""Diagnostic bundle collector — `meeting-helper diag`.

When transcription lags / behaves weirdly during a meeting, the right move is
to grab a self-contained snapshot of the daemon + system + WS traffic + log
so the issue is reproducible from data. This module is that bundler.

What it captures (each in its own file inside the bundle):

  system.txt          macOS / hw / power / network proxy state
  daemon.txt          meta.json, /health, /provider, sanitised workspace config
  timeseries.csv      daemon CPU/RSS + host CPU + load + free mem, every 5 s
  ws_events.jsonl     every WebSocket message the daemon emitted during the run
  ws_stats.txt        per-role inter-arrival + interim→final latency stats
  daemon.log.tail     last 5000 lines of ~/.meeting-helper.log
  daemon.log.errors   ↑ filtered for Drop / reconnect / watchdog / errors
  network_start.txt   ping + curl-timing to Deepgram (+ whisper_host) at start
  network_end.txt     same probes at end (so you can spot a degradation)
  summary.txt         auto-computed red-flag findings + best-guess diagnosis
  README.md           what each file means

The bundle is tar.gz'd onto your Desktop (override with `--out`).  Send the
whole .tar.gz for analysis.

Defaults: 1-hour capture window (covers a typical meeting end-to-end), no
audio captured (privacy), API keys redacted, log included verbatim (it may
contain transcript text — use `--scrub-text` to strip transcript content
but keep timing). Lower the window with `--duration N` if you don't need
the whole meeting; just be sure the capture overlaps the lag.
"""

from __future__ import annotations

import asyncio
import csv
import json
import logging
import os
import re
import shutil
import statistics
import subprocess
import sys
import tarfile
import threading
import time
import urllib.request
from datetime import datetime, timezone
from pathlib import Path

logger = logging.getLogger(__name__)

HOME = Path.home()
META_FILE = HOME / ".meeting-helper.meta.json"
LOG_FILE = HOME / ".meeting-helper.log"
CFG_DIR = HOME / ".config" / "meeting-helper"

# Keys whose values we redact in any captured JSON. Keep the *key* so it's
# obvious the field is configured, but never write the secret to disk.
SECRET_KEYS = {
    "deepgram_api_key", "anthropic_api_key", "google_api_key",
    "openai_api_key", "claude_api_key",
}


# --------------------------------------------------------------------------- shell helper

def _run(cmd, *, timeout: float = 5.0) -> str:
    """Run a subprocess and return stdout (+ stderr appended). Never raises —
    timeouts / missing binaries / errors are stringified into the output so a
    single bad probe can't tank the whole bundle."""
    shell = isinstance(cmd, str)
    try:
        r = subprocess.run(
            cmd, shell=shell, timeout=timeout, check=False,
            capture_output=True, text=True,
        )
        out = r.stdout or ""
        if r.stderr:
            out += "\n[stderr]\n" + r.stderr
        return out
    except subprocess.TimeoutExpired:
        return f"(timeout after {timeout}s)"
    except FileNotFoundError:
        return f"(command not found: {cmd!r})"
    except Exception as e:
        return f"(error: {e})"


def _sanitize(obj):
    """Recursively redact secret keys. `{"deepgram_api_key": "abc"}` becomes
    `{"deepgram_api_key": "<redacted len=3>"}` so you can still see whether the
    field is configured without leaking the value."""
    if isinstance(obj, dict):
        out = {}
        for k, v in obj.items():
            if k.lower() in SECRET_KEYS and v:
                out[k] = f"<redacted len={len(str(v))}>"
            else:
                out[k] = _sanitize(v)
        return out
    if isinstance(obj, list):
        return [_sanitize(v) for v in obj]
    return obj


# --------------------------------------------------------------------------- snapshots

def snap_system(outdir: Path) -> None:
    """One-shot dump of OS / hw / network proxy / power state. The CPU / RSS
    *trend* over time lives in timeseries.csv — this file is the static frame."""
    with (outdir / "system.txt").open("w") as f:
        f.write("=== uname ===\n" + _run(["uname", "-a"]))
        f.write("\n=== sw_vers ===\n" + _run(["sw_vers"]))
        f.write("\n=== hw / cpu ===\n" + _run(
            "sysctl machdep.cpu.brand_string hw.ncpu hw.physicalcpu hw.memsize hw.cpufrequency 2>/dev/null"))
        f.write("\n=== uptime ===\n" + _run(["uptime"]))
        f.write("\n=== top (1 sample, top 15) ===\n" + _run(
            ["top", "-l", "1", "-n", "15", "-stats", "pid,command,cpu,mem,state"], timeout=4))
        f.write("\n=== vm_stat ===\n" + _run(["vm_stat"]))
        f.write("\n=== memory_pressure ===\n" + _run(["memory_pressure"], timeout=2))
        # Power: throttling state + battery — relevant to "fine for 10min then lags"
        f.write("\n=== pmset -g batt ===\n" + _run(["pmset", "-g", "batt"]))
        f.write("\n=== pmset -g therm ===\n" + _run(["pmset", "-g", "therm"]))
        f.write("\n=== pmset -g ===\n" + _run(["pmset", "-g"], timeout=2))
        # Network proxy: corporate TLS-inspecting proxies show up here
        f.write("\n=== scutil --proxies ===\n" + _run(["scutil", "--proxies"]))
        f.write("\n=== proxy env vars ===\n" + _run("env | grep -iE 'proxy|no_proxy' || echo '(none)'"))
        f.write("\n=== route to api.deepgram.com ===\n" + _run(
            "route -n get api.deepgram.com 2>&1 | head -20"))


def snap_daemon(outdir: Path) -> dict:
    """Read meta.json + hit the daemon's HTTP endpoints + sanitise the active
    workspace config. Returns a dict the rest of the run uses (pid, port,
    whisper_host)."""
    info = {"pid": None, "port": 7891, "ok": False, "meta": {},
            "health": None, "provider": None, "whisper_host": ""}
    try:
        info["meta"] = json.loads(META_FILE.read_text())
        info["pid"] = info["meta"].get("pid")
        info["port"] = info["meta"].get("port", 7891)
    except Exception as e:
        info["meta"] = {"_error": f"meta.json unreadable: {e}"}

    def fetch(path: str):
        try:
            with urllib.request.urlopen(
                f"http://127.0.0.1:{info['port']}{path}", timeout=2,
            ) as r:
                return json.loads(r.read().decode())
        except Exception as e:
            return {"_error": f"fetch {path}: {e}"}

    info["health"] = fetch("/health")
    info["provider"] = fetch("/provider")
    info["ok"] = bool(info["pid"]) and not (
        isinstance(info["health"], dict) and "_error" in info["health"]
    )

    # Active workspace config (sanitised)
    active = "default"
    ws_cfg: dict = {}
    try:
        active = (json.loads((CFG_DIR / "state.json").read_text())
                  .get("active_workspace") or "default")
    except Exception:
        pass
    try:
        ws_cfg = json.loads((CFG_DIR / "workspaces" / f"{active}.json").read_text())
        info["whisper_host"] = (ws_cfg.get("whisper_host") or "").strip()
    except Exception as e:
        ws_cfg = {"_error": f"workspace JSON unreadable: {e}"}

    with (outdir / "daemon.txt").open("w") as f:
        f.write("=== ~/.meeting-helper.meta.json ===\n")
        f.write(json.dumps(info["meta"], indent=2, default=str))
        f.write("\n\n=== GET /health ===\n")
        f.write(json.dumps(info["health"], indent=2, default=str))
        f.write("\n\n=== GET /provider ===\n")
        f.write(json.dumps(info["provider"], indent=2, default=str))
        f.write(f"\n\n=== active workspace: {active} (sanitised) ===\n")
        f.write(json.dumps(_sanitize(ws_cfg), indent=2, default=str))
    return info


def snap_network(outdir: Path, suffix: str, whisper_host: str = "") -> None:
    """Latency snapshot. Run twice (start + end) so a degradation over the
    capture window is visible in the diff."""
    fname = outdir / f"network_{suffix}.txt"
    with fname.open("w") as f:
        f.write("=== ping api.deepgram.com (3 packets, 2s timeout) ===\n" + _run(
            ["ping", "-c", "3", "-W", "2000", "api.deepgram.com"], timeout=8))
        f.write("\n=== curl timing https://api.deepgram.com/v1/projects ===\n" + _run(
            ["curl", "-s", "-o", "/dev/null", "--max-time", "6", "-w",
             "dns=%{time_namelookup}s connect=%{time_connect}s appconn=%{time_appconnect}s "
             "ttfb=%{time_starttransfer}s total=%{time_total}s http_code=%{http_code}\n",
             "https://api.deepgram.com/v1/projects"], timeout=8))
        if whisper_host:
            try:
                from urllib.parse import urlparse
                host = urlparse(whisper_host).hostname or ""
                if host:
                    f.write(f"\n=== ping {host} (whisper_host) ===\n" + _run(
                        ["ping", "-c", "3", "-W", "2000", host], timeout=8))
                f.write(f"\n=== curl timing {whisper_host}/health ===\n" + _run(
                    ["curl", "-s", "-o", "/dev/null", "--max-time", "6", "-w",
                     "dns=%{time_namelookup}s connect=%{time_connect}s ttfb=%{time_starttransfer}s "
                     "total=%{time_total}s http_code=%{http_code}\n",
                     f"{whisper_host}/health"], timeout=8))
            except Exception as e:
                f.write(f"\n(whisper_host probe error: {e})\n")


# --------------------------------------------------------------------------- time-series

def sample_timeseries(outdir: Path, stop_event: threading.Event, pid, interval: float = 5.0) -> None:
    """Background thread: writes one CSV row every `interval` seconds with
    daemon CPU%, daemon RSS (MB), host CPU breakdown, load1, free memory.
    Flushes each row so a Ctrl-C still leaves a usable file."""
    path = outdir / "timeseries.csv"
    with path.open("w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["t_sec", "wall_time", "daemon_pcpu", "daemon_rss_mb",
                    "host_cpu_user", "host_cpu_sys", "host_cpu_idle",
                    "load1", "mem_free_mb", "swapins"])
        start = time.time()
        while not stop_event.is_set():
            t = time.time() - start
            wall = datetime.now().strftime("%H:%M:%S")
            daemon_cpu = daemon_rss = ""
            if pid:
                out = _run(["ps", "-p", str(pid), "-o", "pcpu=,rss="], timeout=1).strip()
                parts = out.split()
                if len(parts) >= 2:
                    daemon_cpu = parts[0]
                    try:
                        daemon_rss = str(int(parts[1]) // 1024)  # KB -> MB
                    except ValueError:
                        pass
            top = _run(["top", "-l", "1", "-n", "0"], timeout=2)
            cpu_u = cpu_s = cpu_i = load1 = ""
            for line in top.splitlines():
                if line.startswith("CPU usage:"):
                    m = re.findall(r"([\d.]+)%", line)
                    if len(m) >= 3:
                        cpu_u, cpu_s, cpu_i = m[0], m[1], m[2]
                elif line.startswith("Load Avg:"):
                    m = re.findall(r"[\d.]+", line)
                    if m:
                        load1 = m[0]
            vm = _run(["vm_stat"], timeout=2)
            free_mb = swapins = ""
            for line in vm.splitlines():
                if line.startswith("Pages free:"):
                    try:
                        free_mb = str(int(line.split()[-1].rstrip(".")) * 4096 // (1024 * 1024))
                    except ValueError:
                        pass
                elif line.startswith("Swapins:"):
                    try:
                        swapins = line.split()[-1].rstrip(".")
                    except IndexError:
                        pass
            w.writerow([f"{t:.1f}", wall, daemon_cpu, daemon_rss,
                        cpu_u, cpu_s, cpu_i, load1, free_mb, swapins])
            f.flush()
            stop_event.wait(interval)


# --------------------------------------------------------------------------- websocket tap

async def tap_ws(outdir: Path, port: int, duration: float, scrub_text: bool) -> dict:
    """Subscribe to the daemon's /ws and record every message, with local
    arrival timestamp. Compute per-role inter-arrival and interim→final
    latency for the auto-summary."""
    out_path = outdir / "ws_events.jsonl"
    stats_path = outdir / "ws_stats.txt"

    try:
        import websockets
    except ImportError:
        stats_path.write_text(
            "(websockets not installed in the runtime running this diag — "
            "no live capture done. Install with `pip install websockets`.)\n"
        )
        return {}

    last: dict[str, float] = {}
    interim_seen: dict[str, float] = {}
    arrivals: dict[str, list[float]] = {"self": [], "other": []}
    final_lag: dict[str, list[float]] = {"self": [], "other": []}
    counts: dict[str, dict[str, int]] = {"self": {"i": 0, "f": 0},
                                          "other": {"i": 0, "f": 0}}
    deadline = time.monotonic() + duration
    url = f"ws://127.0.0.1:{port}/ws"

    try:
        async with websockets.connect(url, max_size=2**22) as ws:
            print(f"[diag] WS tapping {url} for {int(duration)}s — start your meeting; "
                  f"let both 'self' and 'other' talk", flush=True)
            with out_path.open("w") as fout:
                last_progress = time.monotonic()
                while time.monotonic() < deadline:
                    try:
                        raw = await asyncio.wait_for(ws.recv(), timeout=1.0)
                    except asyncio.TimeoutError:
                        raw = None
                    if raw is not None:
                        try:
                            msg = json.loads(raw)
                        except Exception:
                            continue
                        now = time.monotonic()
                        msg["_recv_ts"] = round(now, 3)
                        if scrub_text and msg.get("type") == "transcript":
                            # Keep timing but drop the words
                            text = msg.get("text") or ""
                            msg["text"] = f"<{len(text)} chars>"
                        fout.write(json.dumps(msg) + "\n")
                        fout.flush()
                        if msg.get("type") == "transcript":
                            role = msg.get("role", "self")
                            interim = bool(msg.get("interim"))
                            counts.setdefault(role, {"i": 0, "f": 0})["i" if interim else "f"] += 1
                            if role in last:
                                arrivals.setdefault(role, []).append((now - last[role]) * 1000)
                            last[role] = now
                            if interim:
                                interim_seen.setdefault(role, now)
                            else:
                                # interim → final latency: how long after the first
                                # interim for this utterance did the final arrive?
                                if role in interim_seen:
                                    final_lag.setdefault(role, []).append(
                                        (now - interim_seen[role]) * 1000
                                    )
                                    del interim_seen[role]
                    # progress ping every 30s so the user knows it's alive
                    now = time.monotonic()
                    if now - last_progress >= 30:
                        remaining = max(0, int(deadline - now))
                        print(f"[diag] {remaining}s remaining — events so far: "
                              f"self {counts['self']['i']}i/{counts['self']['f']}f, "
                              f"other {counts['other']['i']}i/{counts['other']['f']}f",
                              flush=True)
                        last_progress = now
    except Exception as e:
        stats_path.write_text(f"WS tap failed: {e}\n")
        return {}

    def stats(lags: list[float]) -> dict:
        if not lags:
            return {"n": 0}
        lags = sorted(lags)
        n = len(lags)
        return {
            "n": n,
            "median": round(statistics.median(lags), 1),
            "p95": round(lags[min(int(n * 0.95), n - 1)], 1),
            "max": round(lags[-1], 1),
        }

    summary: dict[str, dict] = {}
    for role in ("self", "other"):
        summary[role] = {
            "events": counts.get(role, {"i": 0, "f": 0}),
            "inter_arrival_ms": stats(arrivals.get(role, [])),
            "interim_to_final_ms": stats(final_lag.get(role, [])),
        }

    with stats_path.open("w") as f:
        f.write(json.dumps(summary, indent=2))
        f.write("\n\n=== per-role summary ===\n")
        for role in ("self", "other"):
            r = summary[role]
            f.write(f"  [{role:5s}] interims={r['events']['i']:4d}  "
                    f"finals={r['events']['f']:4d}\n")
            ia = r["inter_arrival_ms"]
            if ia.get("n"):
                f.write(f"          inter-arrival ms: median={ia['median']:>6.0f}  "
                        f"p95={ia['p95']:>6.0f}  max={ia['max']:>6.0f}  (n={ia['n']})\n")
            else:
                f.write("          inter-arrival ms: (no data)\n")
            itf = r["interim_to_final_ms"]
            if itf.get("n"):
                f.write(f"          interim→final ms: median={itf['median']:>6.0f}  "
                        f"p95={itf['p95']:>6.0f}  max={itf['max']:>6.0f}  (n={itf['n']})\n")
    return summary


# --------------------------------------------------------------------------- log tail

def tail_log(outdir: Path, last_n: int = 5000, scrub_text: bool = False) -> dict:
    """Last N lines of the daemon log, plus a filtered-down red-flag file."""
    if not LOG_FILE.exists():
        (outdir / "daemon.log.tail").write_text("(no ~/.meeting-helper.log)\n")
        return {}
    lines = LOG_FILE.read_text(errors="replace").splitlines()[-last_n:]
    if scrub_text:
        # Cheap heuristic: replace anything that looks like a transcript line.
        # Daemon log has lines like:
        #   "Deepgram final: <text>" / "Whisper final: <text>" / "Remote Whisper final: <text>"
        pat = re.compile(r"((?:Deepgram|Whisper|Remote Whisper)\s+(?:final|interim):\s*).+", re.I)
        lines = [pat.sub(r"\1<scrubbed>", l) for l in lines]
    (outdir / "daemon.log.tail").write_text("\n".join(lines) + "\n")
    pat = re.compile(
        r"Drop\s+\d+|reconnect|watchdog|backoff|too old|keep-?alive|"
        r"\bERROR\b|\bWARNING\b|Traceback|stalled|fell back|crashed|"
        r"transcriber_dead|swap_transcriber",
        re.I,
    )
    interesting = [l for l in lines if pat.search(l)]
    (outdir / "daemon.log.errors").write_text("\n".join(interesting) + "\n")
    return {
        "tail_lines": len(lines),
        "interesting_lines": len(interesting),
        "drop_lines": sum(1 for l in lines if re.search(r"Drop\s+\d+", l)),
        "reconnect_lines": sum(1 for l in lines if re.search(r"reconnect", l, re.I)),
        "watchdog_lines": sum(1 for l in lines if re.search(r"watchdog", l, re.I)),
        "error_lines": sum(1 for l in lines if re.search(r"\bERROR\b|Traceback", l)),
    }


# --------------------------------------------------------------------------- summary

def write_readme(outdir: Path) -> None:
    (outdir / "README.md").write_text("""\
# meeting-helper diagnostic bundle

| File | What's in it |
|------|--------------|
| `summary.txt` | auto-computed red flags + headline numbers |
| `system.txt` | macOS / hw / power / network proxy state |
| `daemon.txt` | meta.json, `/health`, `/provider`, sanitised workspace config |
| `timeseries.csv` | daemon CPU%/RSS + host CPU + load1 + free mem, every 5s |
| `ws_events.jsonl` | every WS message the daemon sent during the run |
| `ws_stats.txt` | per-role inter-arrival + interim→final latency stats |
| `daemon.log.tail` | last 5000 lines of `~/.meeting-helper.log` |
| `daemon.log.errors` | ↑ filtered for Drop / reconnect / watchdog / errors |
| `network_start.txt` | ping + curl-timing at start of window |
| `network_end.txt` | same probes at end (so a worsening shows in the diff) |

API keys are redacted; no raw audio is captured.  Run with `--scrub-text` to
replace transcript text with `<N chars>` placeholders (timing stays intact).

Send this `.tar.gz` for analysis.
""")


def write_summary(outdir: Path, daemon: dict, log_stats: dict, ws: dict, duration: float) -> None:
    """Heuristic auto-diagnosis. Computes a small set of red flags from the
    other files so the bundle is readable at a glance. Never the *final word*,
    just the headline."""
    flags: list[str] = []
    notes: list[str] = []

    if log_stats.get("drop_lines"):
        flags.append(
            f"⚠ {log_stats['drop_lines']} 'Drop N chunks' lines in the log "
            "— audio queue is dropping (capture is faster than the transcriber drain)"
        )
    if log_stats.get("reconnect_lines"):
        flags.append(
            f"⚠ {log_stats['reconnect_lines']} reconnect events — Deepgram/Whisper WS unstable"
        )
    if log_stats.get("watchdog_lines"):
        flags.append(
            f"⚠ {log_stats['watchdog_lines']} watchdog events — long silence / stall detected"
        )

    self_ia = (ws.get("self") or {}).get("inter_arrival_ms") or {}
    other_ia = (ws.get("other") or {}).get("inter_arrival_ms") or {}
    if self_ia.get("n") and other_ia.get("n"):
        if other_ia.get("p95", 0) > 2 * (self_ia.get("p95") or 1):
            flags.append(
                f"⚠ asymmetry confirmed: 'other' p95 inter-arrival "
                f"{other_ia['p95']:.0f} ms vs 'self' {self_ia['p95']:.0f} ms "
                "— system-audio capture lag or proxy buffering"
            )
    if not ws:
        notes.append("(WS tap captured no data — was a meeting recording during the run?)")

    # RSS growth from the time series
    rss_trend = ""
    ts_csv = outdir / "timeseries.csv"
    if ts_csv.exists():
        rss_vals: list[int] = []
        try:
            with ts_csv.open() as f:
                next(f, None)
                for line in f:
                    parts = line.rstrip().split(",")
                    if len(parts) > 3 and parts[3]:
                        try:
                            rss_vals.append(int(parts[3]))
                        except ValueError:
                            pass
            if len(rss_vals) >= 3:
                first, last = rss_vals[0], rss_vals[-1]
                growth = last - first
                rss_trend = (
                    f"daemon RSS: {first} MB → {last} MB ({growth:+d} MB over {duration:.0f}s)"
                )
                if growth >= 200:
                    flags.append(
                        f"⚠ daemon RSS grew {growth} MB over the run — possible memory accumulation"
                    )
        except Exception:
            pass

    with (outdir / "summary.txt").open("w") as f:
        f.write("MEETING-HELPER DIAGNOSTIC SUMMARY\n")
        f.write("=" * 60 + "\n")
        f.write(f"captured: {datetime.now(timezone.utc).isoformat()}\n")
        f.write(f"window:   {duration:.0f}s\n")
        m = daemon.get("meta") or {}
        if isinstance(m, dict):
            f.write(f"daemon:   pid={m.get('pid')} port={m.get('port')}  "
                    f"started_at={m.get('started_at')}\n")
            f.write(f"transcriber: {m.get('transcriber','?')}\n")
            f.write(f"ai: {m.get('ai_provider','?')} / {m.get('ai_model','?')}\n")
            if m.get("whisper_host"):
                f.write(f"whisper_host: {m['whisper_host']}\n")
        f.write("\n--- red flags ---\n")
        if flags:
            for fl in flags:
                f.write(f"  {fl}\n")
        else:
            f.write("  (none auto-detected — still send the bundle for review)\n")
        if rss_trend:
            f.write(f"\n--- resource trend ---\n  {rss_trend}\n")
        for n in notes:
            f.write(f"  {n}\n")
        f.write("\n--- WS per-role stats ---\n")
        for role in ("self", "other"):
            r = ws.get(role) or {}
            ev = r.get("events") or {}
            f.write(f"  [{role:5s}] interims={ev.get('i', 0):4d}  finals={ev.get('f', 0):4d}\n")
            ia = r.get("inter_arrival_ms") or {}
            if ia.get("n"):
                f.write(f"          inter-arrival ms: median={ia['median']:.0f} "
                        f"p95={ia['p95']:.0f} max={ia['max']:.0f}\n")
        f.write("\n--- log signals ---\n")
        for k, v in (log_stats or {}).items():
            f.write(f"  {k}: {v}\n")


# --------------------------------------------------------------------------- bundling

def _bundle(bundle_dir: Path) -> Path:
    """tar.gz the bundle directory and remove the original."""
    tarpath = bundle_dir.with_suffix(".tar.gz")
    with tarfile.open(tarpath, "w:gz") as t:
        t.add(bundle_dir, arcname=bundle_dir.name)
    try:
        shutil.rmtree(bundle_dir)
    except Exception:
        pass
    return tarpath


# --------------------------------------------------------------------------- orchestrator

async def run(duration: int = 3600, out_dir: Path | None = None,
              quick: bool = False, scrub_text: bool = False) -> Path:
    """Run the diagnostic collection. Returns the path to the tar.gz bundle."""
    out_root = out_dir or (HOME / "Desktop")
    out_root.mkdir(parents=True, exist_ok=True)

    ts = datetime.now().strftime("%Y%m%dT%H%M%S")
    host = (os.uname().nodename or "host").split(".")[0]
    bundle = out_root / f"mh-diag-{host}-{ts}"
    bundle.mkdir()
    print(f"[diag] writing to {bundle}")

    print("[diag] system snapshot …", flush=True)
    snap_system(bundle)

    print("[diag] daemon snapshot …", flush=True)
    daemon = snap_daemon(bundle)
    if not daemon["ok"]:
        print("[diag] WARNING: daemon not reachable — snapshot will be partial",
              flush=True)

    print("[diag] network probes (start) …", flush=True)
    snap_network(bundle, "start", whisper_host=daemon.get("whisper_host", ""))

    write_readme(bundle)

    ws_stats: dict = {}
    if not quick and daemon["ok"]:
        # Time-series sampler runs in the background for the duration of the WS tap.
        stop = threading.Event()
        t = threading.Thread(
            target=sample_timeseries, args=(bundle, stop, daemon["pid"], 5.0),
            daemon=True,
        )
        t.start()
        try:
            ws_stats = await tap_ws(bundle, port=daemon["port"],
                                    duration=float(duration), scrub_text=scrub_text)
        finally:
            stop.set()
            t.join(timeout=10)

        print("[diag] network probes (end) …", flush=True)
        snap_network(bundle, "end", whisper_host=daemon.get("whisper_host", ""))
    else:
        if quick:
            print("[diag] --quick: skipping time-series + WS tap")

    print("[diag] log tail …", flush=True)
    log_stats = tail_log(bundle, scrub_text=scrub_text)

    write_summary(bundle, daemon, log_stats, ws_stats, duration if not quick else 0)

    path = _bundle(bundle)
    print(f"\n✅ bundle: {path}")
    print(f"   summary preview:\n")
    try:
        # Re-extract just summary.txt for a quick preview
        with tarfile.open(path, "r:gz") as t:
            for member in t.getmembers():
                if member.name.endswith("/summary.txt"):
                    fobj = t.extractfile(member)
                    if fobj is not None:
                        sys.stdout.write(fobj.read().decode())
                    break
    except Exception:
        pass
    print(f"\n   Send the .tar.gz above for analysis.")
    return path


def main(duration: int = 3600, out: str | None = None,
         quick: bool = False, scrub_text: bool = False) -> int:
    """Sync entry point used by the CLI subcommand."""
    out_dir = Path(out).expanduser() if out else None
    try:
        asyncio.run(run(duration=duration, out_dir=out_dir,
                        quick=quick, scrub_text=scrub_text))
        return 0
    except KeyboardInterrupt:
        print("\n[diag] interrupted — partial bundle may be on Desktop", file=sys.stderr)
        return 130
    except Exception as exc:
        print(f"[diag] failed: {exc}", file=sys.stderr)
        logger.exception("diag failed")
        return 1


if __name__ == "__main__":
    # Allow `python -m meeting_helper.diag` for quick testing.
    import argparse
    p = argparse.ArgumentParser(description="meeting-helper diagnostic bundle")
    p.add_argument("--duration", type=int, default=3600,
                   help="seconds to capture WS + time-series (default 3600 = 1 hour)")
    p.add_argument("--out", default=None, help="output directory (default ~/Desktop)")
    p.add_argument("--quick", action="store_true",
                   help="snapshot only; skip the timed capture window")
    p.add_argument("--scrub-text", action="store_true",
                   help="redact transcript text in WS log and daemon log (timing preserved)")
    a = p.parse_args()
    sys.exit(main(duration=a.duration, out=a.out, quick=a.quick, scrub_text=a.scrub_text))
