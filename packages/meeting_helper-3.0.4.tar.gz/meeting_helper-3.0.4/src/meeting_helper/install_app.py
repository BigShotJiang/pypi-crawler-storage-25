"""Build & install a Meeting Helper.app bundle into /Applications.

The bundle is a tiny shell-script wrapper around `meeting-helper gui` — no
py2app, no bundled Python. Spotlight indexes /Applications automatically,
so once installed the user can Cmd+Space → "Meeting Helper" to launch.
"""

from __future__ import annotations

import logging
import shutil
import stat
from pathlib import Path

APP_NAME = "Meeting Helper"
BUNDLE_ID = "com.victor.meeting-helper"

# Sentinel file recording that we've performed the one-time first-launch
# install of the .app bundle for this user. Stored under DEFAULT_CONFIG_DIR
# so it survives package upgrades. Users who want to opt back in can delete
# this file; users who uninstall the bundle keep it in place so we don't
# silently recreate it.
APP_INSTALLED_MARKER_FILENAME = ".app-installed"

logger = logging.getLogger(__name__)


def _resource_path(*parts: str) -> Path:
    """Locate a file under src/meeting_helper/resources/."""
    return Path(__file__).resolve().parent / "resources" / Path(*parts)


def _user_install_path() -> Path:
    """Per-user Applications path so we don't need sudo."""
    return Path.home() / "Applications" / f"{APP_NAME}.app"


def _system_install_path() -> Path:
    return Path("/Applications") / f"{APP_NAME}.app"


def build_app(dest: Path, *, version: str | None = None) -> Path:
    """Build a fresh Meeting Helper.app at `dest`. Returns the bundle path."""
    if version is None:
        from meeting_helper import __version__ as version

    template_dir = _resource_path("app_template")
    if not template_dir.is_dir():
        raise FileNotFoundError(
            f"Missing app template at {template_dir}. "
            "Reinstall meeting-helper."
        )
    icon_path = _resource_path("icon.icns")
    if not icon_path.is_file():
        raise FileNotFoundError(
            f"Missing icon at {icon_path}. "
            "Reinstall meeting-helper."
        )

    # Remove any existing bundle at dest so we always ship a fresh launcher
    # script (older bundles may search a stale PATH list).
    if dest.exists():
        shutil.rmtree(dest)

    # Copy the template tree.
    shutil.copytree(template_dir, dest)

    # Drop the icon into Resources/.
    resources = dest / "Contents" / "Resources"
    resources.mkdir(parents=True, exist_ok=True)
    shutil.copy2(icon_path, resources / "icon.icns")

    # Replace version placeholders in Info.plist if any.
    info_plist = dest / "Contents" / "Info.plist"
    if info_plist.exists():
        text = info_plist.read_text()
        text = text.replace("3.0.0", version)
        info_plist.write_text(text)

    # Ensure launcher is executable (chmod may be lost when shipped via pip).
    launcher = dest / "Contents" / "MacOS" / "MeetingHelper"
    launcher.chmod(launcher.stat().st_mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)

    return dest


def install_to_applications(*, system: bool = False) -> Path:
    """Build the bundle and copy it to ~/Applications or /Applications.

    Returns the installed bundle path. Raises PermissionError if `system=True`
    and the user lacks write access to /Applications.
    """
    dest = _system_install_path() if system else _user_install_path()
    dest.parent.mkdir(parents=True, exist_ok=True)
    build_app(dest)

    # Tell mds-stores to index it immediately so Spotlight finds it fast.
    try:
        import subprocess
        subprocess.run(
            ["mdimport", str(dest)],
            check=False,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            timeout=5,
        )
    except Exception:
        pass

    return dest


def _marker_path() -> Path:
    """Per-user marker file recording that we installed the bundle once.

    Located under DEFAULT_CONFIG_DIR so it survives package upgrades but
    can be cleaned up by users who want fresh-install behavior.
    """
    from meeting_helper.config import DEFAULT_CONFIG_DIR
    return DEFAULT_CONFIG_DIR / APP_INSTALLED_MARKER_FILENAME


def ensure_app_bundle_installed() -> Path | None:
    """Install the .app bundle once per user, idempotently.

    Returns the install path on first call, None on subsequent calls.
    Respects user uninstall: if the marker exists, never reinstalls even
    if the bundle has since been removed.

    Safe to call from daemon startup and auto-update success paths.
    Failures are swallowed so a broken install can't wedge the daemon.
    """
    # Allow opting out via config without a UI toggle: the marker file is
    # the primary lever, but a `auto_install_app: false` in the workspace
    # config also disables the behavior on every start.
    try:
        from meeting_helper.config import get_config
        cfg = get_config()
        if not bool(cfg._data.get("auto_install_app", True)):
            return None
    except Exception:
        # If config can't be read, fall through to default-on behavior.
        pass

    marker = _marker_path()
    if marker.exists():
        return None  # already done; respect user's choice

    try:
        dest = install_to_applications(system=False)
    except Exception as exc:
        logger.warning("first-launch .app install failed: %s", exc)
        return None

    # Write the marker AFTER successful install. Store the version we
    # installed so a future migration can detect "this was installed by
    # v3.x" if needed.
    try:
        from meeting_helper import __version__
        marker.parent.mkdir(parents=True, exist_ok=True)
        marker.write_text(__version__)
    except Exception as exc:
        # Marker write failed but bundle is installed. Next start would
        # try to reinstall — that's a benign retry, but log it.
        logger.warning("failed to write .app marker (%s): %s", marker, exc)

    logger.info("installed Meeting Helper.app at %s (first-launch)", dest)
    return dest
