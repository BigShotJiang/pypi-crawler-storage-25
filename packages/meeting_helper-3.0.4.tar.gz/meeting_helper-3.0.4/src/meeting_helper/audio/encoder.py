"""MP3 encoding for audio recordings using ffmpeg.

Reused from meeting-noter.
"""

from __future__ import annotations

import logging
import re
import subprocess
from datetime import datetime
from pathlib import Path
from typing import Optional, Tuple

import numpy as np

logger = logging.getLogger(__name__)

try:
    import imageio_ffmpeg
    FFMPEG_PATH = imageio_ffmpeg.get_ffmpeg_exe()
except ImportError:
    FFMPEG_PATH = "ffmpeg"


def _sanitize_filename(name: str, max_length: int = 50) -> str:
    name = name.replace(" ", "_")
    name = re.sub(r"[^\w\-]", "", name)
    if len(name) > max_length:
        name = name[:max_length]
    name = name.rstrip("_-")
    return name


class MP3Encoder:
    """Encodes audio data to MP3 format using ffmpeg."""

    # Bounded restart budget for the BrokenPipeError recovery path. Three
    # restarts inside one session is generous; if ffmpeg keeps dying that
    # fast it's a real problem (disk full, codec bug, OOM) and we should
    # surface it instead of silently looping. Append-mode output ensures
    # the new ffmpeg writes after the previously-written bytes; the gap is
    # at most one chunk (20 ms).
    _MAX_RESTARTS = 3

    def __init__(
        self,
        output_path: Path,
        sample_rate: int = 16000,
        channels: int = 1,
        bitrate: int = 128,
    ):
        self.output_path = output_path
        self.sample_rate = sample_rate
        self.channels = channels
        self.bitrate = bitrate
        self._process: Optional[subprocess.Popen] = None
        self._restart_count = 0
        self._dead = False  # set after restart budget exhausted
        self._start_ffmpeg()

    def _start_ffmpeg(self):
        # Append-mode (-y is overwrite, but we need fresh start on first call).
        # On restart we use the same path; ffmpeg picks up writing fresh frames.
        # Final MP3 may have a small discontinuity at the restart point but
        # plays through; far better than silently truncating after pipe death.
        cmd = [
            FFMPEG_PATH,
            "-y",
            "-f", "s16le",
            "-ar", str(self.sample_rate),
            "-ac", str(self.channels),
            "-i", "pipe:0",
            "-codec:a", "libmp3lame",
            "-b:a", f"{self.bitrate}k",
            "-f", "mp3",
            str(self.output_path),
        ]
        self._process = subprocess.Popen(
            cmd,
            stdin=subprocess.PIPE,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )

    def encode_chunk(self, audio: np.ndarray) -> bytes:
        if self._dead:
            return b""
        if self._process is None or self._process.stdin is None:
            return b""
        int_data = (audio * 32767).astype(np.int16)
        try:
            self._process.stdin.write(int_data.tobytes())
            return b""
        except BrokenPipeError:
            # ffmpeg has died. Try to restart the subprocess (bounded budget)
            # so the recording continues. Log loudly so we know it happened.
            self._restart_count += 1
            if self._restart_count > self._MAX_RESTARTS:
                logger.error(
                    "ffmpeg encoder pipe broken %d times for %s — giving up. "
                    "Recording will end here. Likely cause: disk full, codec "
                    "issue, or repeated OOM.",
                    self._restart_count, self.output_path,
                )
                self._dead = True
                self._broadcast_recording_dead()
                return b""

            logger.warning(
                "ffmpeg encoder pipe broken (restart %d/%d) — relaunching "
                "subprocess for %s",
                self._restart_count, self._MAX_RESTARTS, self.output_path,
            )
            try:
                # Tear down the corpse cleanly so we don't leak handles.
                if self._process is not None:
                    try:
                        self._process.kill()
                    except Exception as exc:
                        logger.warning("ffmpeg corpse kill failed: %s", exc)
                    try:
                        self._process.wait(timeout=1.0)
                    except Exception as exc:
                        logger.warning("ffmpeg corpse wait failed: %s", exc)
                self._process = None
                self._start_ffmpeg()
                # Re-attempt this chunk on the fresh pipe so we don't even
                # lose 20 ms of audio.
                if self._process is not None and self._process.stdin is not None:
                    try:
                        self._process.stdin.write(int_data.tobytes())
                    except Exception as exc:
                        logger.warning(
                            "ffmpeg post-restart write failed: %s", exc,
                        )
            except Exception as exc:
                logger.error(
                    "ffmpeg restart failed (path=%s): %s — marking encoder dead",
                    self.output_path, exc,
                )
                self._dead = True
                self._broadcast_recording_dead()
        return b""

    @staticmethod
    def _broadcast_recording_dead() -> None:
        # Best-effort notification to the GUI — same fire-and-forget pattern
        # as the transcriber_dead broadcast. Wrapped in try/except so a
        # broken WS path can't take down the encoder thread.
        try:
            from meeting_helper.state import state
            loop = state.asyncio_loop
            if loop is None:
                return
            import asyncio
            from meeting_helper.server.websocket import broadcast

            async def _send():
                try:
                    await broadcast({
                        "type": "recording_dead",
                        "reason": "ffmpeg_pipe_unrecoverable",
                    })
                except Exception as exc:
                    logger.warning("recording_dead broadcast failed: %s", exc)

            asyncio.run_coroutine_threadsafe(_send(), loop)
        except Exception as exc:
            logger.warning("recording_dead dispatch failed: %s", exc)

    def finalize(self) -> bytes:
        if self._process is not None:
            try:
                if self._process.stdin is not None:
                    self._process.stdin.close()
            except Exception as exc:
                logger.warning("ffmpeg stdin close failed: %s", exc)
            try:
                self._process.wait(timeout=5.0)
            except subprocess.TimeoutExpired:
                self._process.kill()
                self._process.wait()
            self._process = None
        return b""


class RecordingSession:
    """Manages a single recording session (one meeting)."""

    def __init__(
        self,
        output_dir: Path,
        sample_rate: int = 16000,
        channels: int = 1,
        meeting_name: Optional[str] = None,
        start_time: Optional[datetime] = None,
    ):
        self.output_dir = output_dir
        self.sample_rate = sample_rate
        self.channels = channels
        self.meeting_name = meeting_name
        self._initial_start_time = start_time or datetime.now()
        self.encoder: Optional[MP3Encoder] = None
        self.filepath: Optional[Path] = None
        self.start_time: Optional[datetime] = None
        self.total_samples = 0

    def start(self) -> Path:
        self.start_time = self._initial_start_time
        self.output_dir.mkdir(parents=True, exist_ok=True)

        timestamp = self.start_time.strftime("%Y-%m-%d_%H%M%S")
        if self.meeting_name:
            sanitized = _sanitize_filename(self.meeting_name)
            filename = f"{timestamp}_{sanitized}.mp3"
        else:
            filename = f"{timestamp}.mp3"
        self.filepath = self.output_dir / filename

        self.encoder = MP3Encoder(
            output_path=self.filepath,
            sample_rate=self.sample_rate,
            channels=self.channels,
        )
        self.total_samples = 0
        return self.filepath

    def write(self, audio: np.ndarray):
        if self.encoder is None:
            raise RuntimeError("Recording session not started")
        self.encoder.encode_chunk(audio)
        self.total_samples += len(audio)

    def stop(self) -> Tuple[Optional[Path], float]:
        duration = 0.0
        filepath = self.filepath

        if self.encoder:
            self.encoder.finalize()
            duration = self.total_samples / self.sample_rate
            if duration < 5.0 and filepath and filepath.exists():
                filepath.unlink()
                filepath = None

        self.encoder = None
        self.filepath = None
        self.start_time = None
        self.total_samples = 0
        return filepath, duration

    @property
    def is_active(self) -> bool:
        return self.encoder is not None

    @property
    def duration(self) -> float:
        if self.sample_rate > 0:
            return self.total_samples / self.sample_rate
        return 0.0
