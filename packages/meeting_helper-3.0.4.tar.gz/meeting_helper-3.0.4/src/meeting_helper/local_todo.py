"""Async client for the local-todo MCP server.

The daemon spawns the configured MCP command as a stdio JSON-RPC subprocess,
keeps the session alive for the daemon's lifetime, and exposes a small
typed surface for the meeting-helper's needs.
"""

from __future__ import annotations

import asyncio
import json
import logging
from contextlib import AsyncExitStack
from typing import Any, Optional

logger = logging.getLogger(__name__)


def _parse_tool_result(result: Any) -> Any:
    """MCP call_tool() returns a result with .content (list of TextContent).
    For local-todo we expect a single text block of JSON. Parse it; on
    failure return None so callers can detect parse errors distinctly from
    valid empty results."""
    try:
        if not getattr(result, "content", None):
            return None
        text = result.content[0].text
        return json.loads(text)
    except (AttributeError, IndexError, ValueError, json.JSONDecodeError) as exc:
        logger.warning("local-todo parse error: %s", exc)
        return None


class LocalTodoClient:
    """Async wrapper around the local-todo MCP server.

    Lazy: the subprocess is spawned on the first call and kept alive thereafter.
    Auto-restart is NOT in this version — if the subprocess dies, the next call
    will fail and the user must restart the daemon. (Acceptable for v1; revisit
    if it becomes a real pain.)
    """

    def __init__(self, mcp_config: dict) -> None:
        if not mcp_config:
            raise ValueError("LocalTodoClient: mcp_config must be non-empty")
        self._type = (mcp_config.get("type") or "stdio").strip().lower()
        if self._type not in ("stdio", "http"):
            raise ValueError(f"LocalTodoClient: unknown type {self._type!r} (expected 'stdio' or 'http')")
        if self._type == "stdio":
            command = str(mcp_config.get("command", "")).strip()
            if not command:
                raise ValueError("LocalTodoClient: stdio config requires non-empty command")
            self._command = command
            self._args = list(mcp_config.get("args", []) or [])
            self._env = dict(mcp_config.get("env", {}) or {})
            self._url = ""
            self._headers: dict[str, str] = {}
        else:
            url = str(mcp_config.get("url", "")).strip()
            if not url:
                raise ValueError("LocalTodoClient: http config requires non-empty url")
            self._command = ""
            self._args = []
            self._env = {}
            self._url = url
            self._headers = dict(mcp_config.get("headers", {}) or {})
        self._stack: Optional[AsyncExitStack] = None
        self._session: Any = None  # mcp.client.session.ClientSession when started
        self._lock = asyncio.Lock()
        self._cached_boards: Optional[list[dict]] = None

    async def _ensure_started(self) -> None:
        async with self._lock:
            if self._session is not None:
                return
            from mcp.client.session import ClientSession

            stack = AsyncExitStack()
            try:
                if self._type == "stdio":
                    from mcp.client.stdio import stdio_client, StdioServerParameters
                    params = StdioServerParameters(
                        command=self._command,
                        args=list(self._args),
                        env=dict(self._env) if self._env else None,
                    )
                    read, write = await stack.enter_async_context(stdio_client(params))
                    logger.info("local-todo MCP started (stdio): %s %s",
                                self._command, " ".join(self._args))
                else:
                    from mcp.client.streamable_http import streamablehttp_client
                    headers = dict(self._headers) if self._headers else None
                    read, write, _get_sid = await stack.enter_async_context(
                        streamablehttp_client(self._url, headers=headers)
                    )
                    logger.info("local-todo MCP started (http): %s", self._url)

                session = await stack.enter_async_context(ClientSession(read, write))
                await session.initialize()
                self._stack = stack
                self._session = session
            except Exception:
                await stack.aclose()
                raise

    async def close(self) -> None:
        async with self._lock:
            if self._stack is not None:
                try:
                    await self._stack.aclose()
                finally:
                    self._stack = None
                    self._session = None
                    logger.info("local-todo MCP closed")

    def _record(self, action: str) -> None:
        """Bump live counters so the GUI can show what the daemon is doing."""
        try:
            from meeting_helper.state import state
            state.record_local_todo_call(action)
        except Exception:
            pass

    # Per-board column cache. Columns rarely change during a meeting (the
    # user reorders them in their PM tool maybe a few times a quarter),
    # but /topics polls every 8 s. Without a cache, that's 8/sec × N
    # boards of MCP traffic for invariant data. 60 s TTL is generous
    # enough that a real reorder takes effect on the next poll while
    # eliminating the redundant fan-out.
    _COLUMNS_CACHE_TTL_SEC = 60.0

    async def list_board_columns(
        self,
        board_id: int,
        *,
        force_refresh: bool = False,
    ) -> list[dict]:
        """Return the configured columns (statuses) for a board, in
        position order. Each column has::

            {key, name, kind, color, position}

        Used by /topics to render status sections in the order the user
        configured on their board — not a hardcoded order. ``kind`` is the
        coarse category (todo / in_progress / done); ``key`` and ``name``
        are user-customizable.

        Cached for ~60 s per board. Pass ``force_refresh=True`` to
        bypass the cache (e.g. after a user-triggered "Refresh" action).
        """
        import time as _time
        # Lazy-init the cache so __init__ doesn't have to know about it.
        if not hasattr(self, "_columns_cache"):
            self._columns_cache: dict[int, tuple[float, list[dict]]] = {}

        if not force_refresh:
            entry = self._columns_cache.get(board_id)
            if entry is not None:
                cached_at, cols = entry
                if _time.time() - cached_at < self._COLUMNS_CACHE_TTL_SEC:
                    return cols

        self._record(f"list_board_columns {board_id}")
        await self._ensure_started()
        result = await self._session.call_tool(
            "list_board_columns", {"board_id": board_id}
        )
        parsed = _parse_tool_result(result)
        cols = parsed if isinstance(parsed, list) else []
        # Sort by position so we render in the user's configured order.
        cols.sort(key=lambda c: c.get("position", 0))
        self._columns_cache[board_id] = (_time.time(), cols)
        return cols

    async def list_boards(self) -> list[dict]:
        """Return all authorized boards. Cached for the client's lifetime.

        Each board: {"board_id": int, "name": str, "effective_permission": str, ...}.
        """
        if self._cached_boards is not None:
            return self._cached_boards
        self._record("list_boards")
        await self._ensure_started()
        result = await self._session.call_tool("list_boards", {})
        parsed = _parse_tool_result(result)
        boards = parsed if isinstance(parsed, list) else []
        # Filter to only boards we can read
        boards = [b for b in boards if b.get("effective_permission") in ("read", "write")]
        self._cached_boards = boards
        return boards

    async def search(self, query: str, limit: int = 5) -> list[dict]:
        """Search tasks + docs across all authorized boards. Returns top-K
        normalized records.

        Each record is the raw task/doc object from local-todo, plus:
          - "kind": "task" | "doc"
          - "board_id": int (which board it came from)
          - "board_name": str
        """
        if not query.strip():
            return []
        self._record(f"search '{query[:32]}'")
        await self._ensure_started()

        boards = await self.list_boards()
        if not boards:
            return []

        # Issue per-board task + doc searches in parallel
        per_board_calls: list = []
        for b in boards:
            bid = b["board_id"]
            per_board_calls.append(self._session.call_tool(
                "search_tasks", {"board_id": bid, "q": query, "limit": limit}
            ))
            per_board_calls.append(self._session.call_tool(
                "search_docs", {"board_id": bid, "q": query, "limit": limit}
            ))

        results = await asyncio.gather(*per_board_calls, return_exceptions=True)

        records: list[dict] = []
        # Results come in (tasks, docs) pairs per board
        for i, b in enumerate(boards):
            tasks_res = results[i * 2]
            docs_res = results[i * 2 + 1]
            board_meta = {"board_id": b["board_id"], "board_name": b.get("name", "")}

            if not isinstance(tasks_res, Exception):
                payload = _parse_tool_result(tasks_res)
                if isinstance(payload, list):
                    for t in payload:
                        records.append({"kind": "task", **board_meta, **t})

            if not isinstance(docs_res, Exception):
                payload = _parse_tool_result(docs_res)
                if isinstance(payload, list):
                    for d in payload:
                        records.append({"kind": "doc", **board_meta, **d})

        return records[:limit]

    async def my_active_tasks(self, limit: int = 20) -> list[dict]:
        """Return tasks in the active sprint of every authorized board.

        Each task is the raw object from local-todo plus:
          - "board_id": int
          - "board_name": str
          - "sprint_name": str (resolved from list_sprints.active.name)
        """
        self._record("my_active_tasks")
        await self._ensure_started()

        boards = await self.list_boards()
        if not boards:
            return []

        # First: list_sprints per board to find the active sprint name
        sprint_calls = [
            self._session.call_tool("list_sprints", {"board_id": b["board_id"]})
            for b in boards
        ]
        sprint_results = await asyncio.gather(*sprint_calls, return_exceptions=True)

        # active_sprints[board_id] = {"id": "...", "name": "..."} or None
        active_sprints: dict[int, Optional[dict]] = {}
        for b, res in zip(boards, sprint_results):
            if isinstance(res, Exception):
                active_sprints[b["board_id"]] = None
                continue
            payload = _parse_tool_result(res)
            if isinstance(payload, dict):
                active_sprints[b["board_id"]] = payload.get("active") or None
            else:
                active_sprints[b["board_id"]] = None

        # Second: search_tasks(scope="active") per board where there IS an active sprint
        task_calls = []
        boards_with_active = []
        for b in boards:
            sprint = active_sprints.get(b["board_id"])
            if sprint:
                boards_with_active.append(b)
                task_calls.append(self._session.call_tool(
                    "search_tasks", {"board_id": b["board_id"]}  # default scope=active
                ))

        if not task_calls:
            return []

        task_results = await asyncio.gather(*task_calls, return_exceptions=True)

        records: list[dict] = []
        for b, res in zip(boards_with_active, task_results):
            if isinstance(res, Exception):
                continue
            payload = _parse_tool_result(res)
            if not isinstance(payload, list):
                continue
            sprint = active_sprints.get(b["board_id"]) or {}
            board_meta = {
                "board_id": b["board_id"],
                "board_name": b.get("name", ""),
                "sprint_name": sprint.get("name", ""),
            }
            for t in payload:
                records.append({**board_meta, **t})

        return records[:limit]

    async def my_active_tasks_enriched(
        self,
        limit: int = 20,
        max_subtasks: int = 20,
        max_history: int = 6,
        max_comments: int = 5,
        body_chars: int = 1500,
        subtask_body_chars: int = 400,
        comment_chars: int = 400,
    ) -> list[dict]:
        """Active tasks enriched with subtasks, recent comments, recent history,
        and linked-doc stubs — one round-trip per task in parallel.

        Used by /brief so Claude can write by topic instead of by isolated row.
        Aggressive trimming keeps the JSON we hand to the model bounded even
        when a topic has dozens of long subtasks or a multi-month comment log.
        """
        self._record("my_active_tasks_enriched")
        base_tasks = await self.my_active_tasks(limit=limit)
        if not base_tasks:
            return []

        await self._ensure_started()

        async def _fetch_full(task: dict) -> Optional[dict]:
            try:
                res = await self._session.call_tool(
                    "get_task",
                    {
                        "board_id": task["board_id"],
                        "id": str(task["id"]),
                        "include_subtasks": True,
                    },
                )
                parsed = _parse_tool_result(res)
                return parsed if isinstance(parsed, dict) else None
            except Exception as exc:
                logger.warning(
                    "my_active_tasks_enriched: get_task(%s) failed: %s",
                    task.get("id"), exc,
                )
                return None

        full_results = await asyncio.gather(*[_fetch_full(t) for t in base_tasks])

        enriched: list[dict] = []
        for base, full in zip(base_tasks, full_results):
            if not full:
                enriched.append(base)
                continue

            subtasks = [
                {
                    "id": s.get("id"),
                    "title": s.get("title"),
                    "status": s.get("status"),
                    "priority": s.get("priority"),
                    "body_md": (s.get("body_md") or "")[:subtask_body_chars],
                }
                for s in (full.get("subtasks") or [])[:max_subtasks]
            ]

            comments = [
                {
                    "at": c.get("at"),
                    "author": c.get("actor_user_id") or c.get("author"),
                    "body": (c.get("body") or "")[:comment_chars],
                }
                for c in (full.get("comments") or [])[-max_comments:]
            ]

            history = [
                {
                    "at": h.get("at"),
                    "kind": h.get("kind"),
                    "from_value": (h.get("from_value") or "")[:160] or None,
                    "to_value": (h.get("to_value") or "")[:160] or None,
                }
                for h in (full.get("history") or [])
                if h.get("kind") in ("body_change", "status_change", "comment", "comment_added")
            ][-max_history:]

            linked_docs = [
                {"id": d.get("id"), "title": d.get("title"), "url": d.get("url")}
                for d in (full.get("linked_docs") or [])
            ]

            enriched.append({
                **base,
                "body_md": (full.get("body_md") or base.get("body_md") or "")[:body_chars],
                "subtasks": subtasks,
                "subtasks_summary": full.get("subtasks_summary") or {},
                "recent_comments": comments,
                "recent_history": history,
                "linked_docs": linked_docs,
            })

        return enriched

    async def get(self, kind: str, id: str, board_id: int) -> dict:
        """Fetch a full record by kind ('task' or 'doc'), id, and board_id.

        Returns the parsed record dict, or {} on failure.
        """
        if kind not in ("task", "doc"):
            raise ValueError(f"kind must be 'task' or 'doc', got {kind!r}")
        self._record(f"get {kind} {id}")
        await self._ensure_started()
        tool_name = "get_task" if kind == "task" else "get_doc"
        result = await self._session.call_tool(
            tool_name, {"board_id": board_id, "id": id}
        )
        parsed = _parse_tool_result(result)
        return parsed if isinstance(parsed, dict) else {}
