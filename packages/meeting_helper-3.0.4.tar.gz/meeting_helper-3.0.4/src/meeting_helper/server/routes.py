"""HTTP routes: health, config, transcribe, summarize."""

from __future__ import annotations

import asyncio
import json
import logging
import re
import subprocess
import time
from dataclasses import asdict
from pathlib import Path

from aiohttp import web

from meeting_helper.state import state
from meeting_helper.server.websocket import ws_handler, slim_card_for_broadcast

logger = logging.getLogger(__name__)


def _hot_moment_window_sec(request) -> float:
    """Resolve the configured Hot Moment window in seconds.

    Reads hot_moment_window_minutes from the request app config.
    Returns 0 if no config is reachable (arm_hot_moment becomes a no-op).
    """
    try:
        cfg = request.app.get("config")
        if cfg is not None:
            return cfg.hot_moment_window_minutes * 60.0
    except Exception:
        pass
    return 0.0



try:
    from anthropic import AsyncAnthropic
except ImportError:
    AsyncAnthropic = None  # tests patch this


def _parse_brief_script_to_sentences(script: str) -> list[str]:
    """Extract first-person bullet sentences from the brief markdown script.

    Each bullet line (lines starting with '-' or '*') is treated as one
    sentence. Section headers (**Today**, etc.) are skipped.
    """
    sentences: list[str] = []
    for raw in script.splitlines():
        line = raw.strip()
        if not line:
            continue
        # Skip section headers
        if line.startswith("**") and line.endswith("**"):
            continue
        # Bullets
        if line.startswith("- ") or line.startswith("* "):
            text = line[2:].strip()
            if text:
                sentences.append(text)
    return sentences


def _ticket_ids_in(text: str) -> list[str]:
    """Extract unique ticket IDs (e.g. PROJ-123) preserving first-occurrence order."""
    seen: list[str] = []
    for m in re.finditer(r"[A-Z]{2,}-\d+", text):
        tid = m.group(0)
        if tid not in seen:
            seen.append(tid)
    return seen


def _seed_warm_cache_from_brief(script: str, brief_cards: list[dict]) -> dict:
    """After /brief succeeds, seed state.self_buffer + state.current_topic +
    state.current_topic_cards so subsequent queries have grounded context.

    Returns the seeded `current_topic` dict (also assigned to state).
    """
    sentences = _parse_brief_script_to_sentences(script)
    if state.self_buffer is not None:
        for s in sentences:
            state.self_buffer.append_final(s)

    # Pick the first "Today" bullet as the primary topic statement.
    # The script's structure is:
    #   **Today**
    #   - I'm working on PROJ-123 ...
    #   **Yesterday**
    #   - I finished PROJ-111 ...
    today_bullet = ""
    section = None
    for raw in script.splitlines():
        line = raw.strip()
        if not line:
            continue
        if line.startswith("**") and line.endswith("**"):
            header = line.strip("*").strip().lower()
            section = header
            continue
        if section == "today" and (line.startswith("- ") or line.startswith("* ")):
            today_bullet = line[2:].strip()
            break  # take the FIRST today bullet

    last_user_statement = today_bullet or (sentences[0] if sentences else "")
    # The brief script no longer prints raw ticket ids (they sound bad read
    # aloud), so harvest them from the source card titles instead.
    ticket_ids: list[str] = []
    for c in (brief_cards or []):
        for tid in _ticket_ids_in(str(c.get("title", ""))):
            if tid not in ticket_ids:
                ticket_ids.append(tid)
    # Fallback: still scan the script in case the model slipped one in.
    for tid in _ticket_ids_in(script):
        if tid not in ticket_ids:
            ticket_ids.append(tid)
    # Topic = a short noun phrase from the today bullet, falling back to the bullet itself
    topic = ""
    if today_bullet:
        # Strip leading first-person "I'm working on " etc.
        cleaned = re.sub(
            r"^(I['’]m\s+(working on|continuing|focused on|on)|I am\s+(working on|continuing|focused on|on))\s+",
            "",
            today_bullet,
            flags=re.IGNORECASE,
        )
        # Take up to the first em-dash or "—" or first 80 chars
        for sep in [" — ", " - ", ": ", ". "]:
            if sep in cleaned:
                topic = cleaned.split(sep, 1)[0].strip()
                break
        if not topic:
            topic = cleaned[:80].strip()

    # Search query — best-effort keywords from the topic
    search_query = topic.lower() if topic else " ".join(ticket_ids[:2])

    current_topic = {
        "topic": topic,
        "ticket_ids": ticket_ids,
        "search_query": search_query,
        "last_user_statement": last_user_statement,
    }
    state.current_topic = current_topic
    state.current_topic_cards = list(brief_cards or [])
    return current_topic


async def health_handler(request: web.Request) -> web.Response:
    meeting_name = ""
    if state.meeting_info:
        meeting_name = getattr(state.meeting_info, "meeting_name", "") or ""
    now = time.time()

    def _age(ts: float):
        return round(now - ts, 1) if ts else None

    aq = state.active_query
    active_query = bool(aq is not None and not aq.done())

    return web.Response(
        text=json.dumps({
            "status": "ok",
            "meeting": meeting_name,
            "session_active": state.session_active,
            "summarizing": state.summarizing,
            "uptime": round(now - state.started_at) if state.started_at else 0,
            "stats": {
                "ai_calls": state.ai_call_count,
                "ai_calls_by_kind": dict(state.ai_calls_by_kind),
                "local_todo_calls": state.local_todo_call_count,
                "local_todo_calls_by_kind": dict(state.local_todo_calls_by_kind),
                "last_local_todo_action": state.last_local_todo_action,
                "last_local_todo_at": state.last_local_todo_at,
            },
            "health": {
                "last_ai_call_at": state.last_ai_call_at or None,
                "last_ai_call_kind": state.last_ai_call_kind,
                "last_ai_call_age_sec": _age(state.last_ai_call_at),
                "active_query": active_query,
                "active_query_age_sec": (
                    _age(state.active_query_started_at) if active_query else None
                ),
                "event_loop_lag_ms": round(state.event_loop_lag_ms, 1),
                "cpu_percent": round(state.proc_cpu_percent, 1),
                "host_cpu_percent": round(state.host_cpu_percent, 1),
                "rss_mb": round(state.proc_rss_mb, 1),
            },
        }),
        content_type="application/json",
    )


async def workspace_handler(request: web.Request) -> web.Response:
    """Return the active workspace name and the daemon's bound port."""
    from meeting_helper.config import get_config, load_state
    state_data = load_state()
    cfg = get_config()
    return web.Response(
        text=json.dumps({
            "name": state_data["active_workspace"],
            "port": cfg.port,
        }),
        content_type="application/json",
    )


async def launcher_command_handler(request: web.Request) -> web.Response:
    """GET /launcher.command — serve the double-click launcher script.

    Returns the bash script bundled in ``meeting_helper.launcher_script``
    with a ``Content-Disposition: attachment`` header so browsers/webview
    save it as ``Meeting Helper.command``. The old Flet sidebar exposed
    this as a download icon; the new sidebar links to this endpoint
    directly via an `<a download>` element.
    """
    from meeting_helper.launcher_script import LAUNCHER_SCRIPT
    return web.Response(
        text=LAUNCHER_SCRIPT,
        content_type="text/x-shellscript",
        headers={
            "Content-Disposition": 'attachment; filename="Meeting Helper.command"',
        },
    )


async def logs_tail_handler(request: web.Request) -> web.Response:
    """GET /logs/tail?n=20 — return the last N lines of the daemon log.

    Used by the workspace-switch failure dialog so the user can see what
    actually broke without hunting through `~/.meeting-helper.log`. We clamp
    `n` to [1, 500] so a stray `?n=999999` cannot blow up the response.
    Missing log files return an empty list rather than 404 — fresh installs
    haven't written one yet.
    """
    from meeting_helper.config import LOG_FILE
    try:
        n = int(request.query.get("n", "20"))
    except ValueError:
        n = 20
    n = max(1, min(500, n))
    try:
        lines = LOG_FILE.read_text(errors="replace").splitlines()[-n:]
    except FileNotFoundError:
        lines = []
    except OSError as exc:
        return web.json_response({"error": str(exc)}, status=500)
    return web.json_response({"lines": lines, "path": str(LOG_FILE)})


async def version_handler(request: web.Request) -> web.Response:
    """GET /version — daemon runtime version vs on-disk installed vs PyPI latest.

    Three versions, each meaningful:
      version            daemon's in-process __version__ (what's RUNNING)
      installed_version  importlib.metadata version (what's on DISK — pipx may
                         have already swapped this without restarting the daemon)
      latest             latest on PyPI (best-effort, None on fetch failure)

    Two flags the UI acts on:
      restart_needed     daemon < installed → just restart, no download needed
      outdated           installed < latest → pipx upgrade would help

    The old "outdated = version < latest" lumped both into one orange dot,
    which is what made the UI show "update available" even right after a
    successful pipx upgrade — the user had ALREADY updated, they just
    needed to restart. Splitting the two states lets the UI offer the
    right action for each.

    Old keys (`version`, `latest`, `outdated`) are preserved for any
    consumer that still reads them.
    """
    from meeting_helper import __version__ as daemon_version

    installed_version = daemon_version
    try:
        from importlib.metadata import PackageNotFoundError, version as _pkg_version
        try:
            installed_version = _pkg_version("meeting-helper")
        except PackageNotFoundError:
            # Editable / source checkout — metadata not registered. Fall back
            # to in-process __version__ so we don't flag a false restart.
            pass
    except Exception as exc:  # pragma: no cover - defensive
        logger.warning("version_handler: installed_version probe failed: %s", exc)

    latest: str | None = None
    restart_needed = False
    outdated = False
    try:
        from meeting_helper.auto_updater import _is_outdated, fetch_latest_version
        latest = await asyncio.to_thread(fetch_latest_version)
        if latest:
            outdated = _is_outdated(installed_version, latest)
        restart_needed = _is_outdated(daemon_version, installed_version)
    except Exception as exc:  # pragma: no cover - defensive
        logger.warning("version_handler: latest-version probe failed: %s", exc)

    return web.json_response({
        "version": daemon_version,
        "daemon_version": daemon_version,
        "installed_version": installed_version,
        "latest": latest,
        "latest_version": latest,
        "outdated": outdated,
        "update_available": outdated,
        "restart_needed": restart_needed,
    })


async def daemon_restart_handler(request: web.Request) -> web.Response:
    """POST /daemon/restart — gracefully exit so the supervisor respawns us.

    The shell process (pywebview) runs a daemon supervisor that respawns the
    daemon any time it goes down. We just SIGTERM ourselves after a short
    delay so the HTTP response can flush, then let the supervisor pick up
    fresh code from the just-installed package.

    Returns 202 immediately so the UI can start polling /version for the
    new daemon_version.
    """
    import os
    import signal

    async def _die_after_grace() -> None:
        # 250 ms is plenty to flush the response and tear down the connection
        # before the SIGTERM lands. The supervisor's 8 s cooldown means a
        # double-click on the restart button is harmless.
        await asyncio.sleep(0.25)
        try:
            os.kill(os.getpid(), signal.SIGTERM)
        except Exception as exc:  # pragma: no cover - defensive
            logger.warning("daemon_restart_handler: SIGTERM self failed: %s", exc)

    asyncio.create_task(_die_after_grace())
    return web.json_response({"ok": True, "restarting": True}, status=202)


async def install_app_handler(request: web.Request) -> web.Response:
    """POST /install-app — build and install the Meeting Helper.app bundle.

    Always installs to ~/Applications (no sudo required, Spotlight-indexed).
    Returns {ok, path, version}. The UI uses this to surface a one-click
    install affordance in Settings → General.
    """
    from meeting_helper import __version__
    from meeting_helper.install_app import install_to_applications
    try:
        dest = await asyncio.to_thread(install_to_applications, system=False)
    except Exception as exc:
        return web.json_response({"error": str(exc)}, status=500)
    return web.json_response({"ok": True, "path": str(dest), "version": __version__})


async def install_app_status_handler(request: web.Request) -> web.Response:
    """GET /install-app/status — whether the .app bundle is installed + its version.

    Returns {installed: bool, path: str|null, version: str|null, current_version: str}.
    `version` is whatever the Info.plist says (may be stale if the user upgraded
    pipx but didn't reinstall the bundle). `current_version` is the running
    daemon's version so the UI can show "Reinstall (out of date)" when they differ.
    """
    import plistlib
    from meeting_helper import __version__
    from meeting_helper.install_app import _user_install_path, _system_install_path

    candidates = [_user_install_path(), _system_install_path()]
    for path in candidates:
        if path.is_dir():
            info_plist = path / "Contents" / "Info.plist"
            installed_version = None
            try:
                with open(info_plist, "rb") as fh:
                    data = plistlib.load(fh)
                installed_version = data.get("CFBundleShortVersionString")
            except Exception:
                pass
            return web.json_response({
                "installed": True,
                "path": str(path),
                "version": installed_version,
                "current_version": __version__,
            })

    return web.json_response({
        "installed": False,
        "path": None,
        "version": None,
        "current_version": __version__,
    })


async def shutdown_handler(request: web.Request) -> web.Response:
    """Trigger graceful daemon shutdown via SIGTERM (handled in run_daemon)."""
    import os
    import signal
    asyncio.get_event_loop().call_later(
        0.1, lambda: os.kill(os.getpid(), signal.SIGTERM)
    )
    return web.Response(
        text=json.dumps({"ok": True}),
        content_type="application/json",
    )


async def workspaces_handler(request: web.Request) -> web.Response:
    """GET /workspaces — list every workspace on disk + the active one.

    Powers the new shell's workspace switcher dropdown. The Flet GUI did this
    by reading `config.list_workspaces()` + `config.load_state()` in-process;
    the web UI doesn't have that affordance so we surface it over HTTP.
    """
    from meeting_helper.config import list_workspaces, load_state
    return web.json_response({
        "active": load_state()["active_workspace"],
        "available": list_workspaces(),
    })


async def workspace_create_handler(request: web.Request) -> web.Response:
    """POST /workspace/create — create a new workspace.

    Body: ``{"name": "alpha", "copy_from": "default" | null}``.
    `copy_from` is optional; when provided we deep-copy that workspace's
    settings JSON so the new workspace starts with the user's tuned
    transcriber/AI provider/MCP choices instead of stock defaults.
    """
    try:
        body = await request.json()
    except Exception:
        return web.json_response({"error": "invalid JSON"}, status=400)
    name = str(body.get("name") or "").strip()
    if not name:
        return web.json_response({"error": "name required"}, status=400)
    copy_from = body.get("copy_from")
    try:
        from meeting_helper.config import create_workspace
        create_workspace(name, copy_from=copy_from if copy_from else None)
    except ValueError as exc:
        return web.json_response({"error": str(exc)}, status=400)
    return web.json_response({"ok": True, "name": name})


async def workspace_rename_handler(request: web.Request) -> web.Response:
    """POST /workspace/rename — rename an existing workspace.

    Body: ``{"old": "alpha", "new": "alpha-prod"}``. Active-workspace renames
    are handled by ``rename_workspace`` (it updates state.json so the active
    pointer follows along).
    """
    try:
        body = await request.json()
    except Exception:
        return web.json_response({"error": "invalid JSON"}, status=400)
    old = str(body.get("old") or "").strip()
    new = str(body.get("new") or "").strip()
    if not old or not new:
        return web.json_response({"error": "old and new required"}, status=400)
    try:
        from meeting_helper.config import rename_workspace
        rename_workspace(old, new)
    except ValueError as exc:
        return web.json_response({"error": str(exc)}, status=400)
    return web.json_response({"ok": True, "name": new})


async def workspace_delete_handler(request: web.Request) -> web.Response:
    """POST /workspace/delete — delete a workspace by name.

    Refuses the active workspace and the last remaining workspace (both raise
    ``ValueError`` from ``config.delete_workspace``). The shell-side dialog
    also enforces these as a UX safeguard, but the daemon is the source of
    truth.
    """
    try:
        body = await request.json()
    except Exception:
        return web.json_response({"error": "invalid JSON"}, status=400)
    name = str(body.get("name") or "").strip()
    if not name:
        return web.json_response({"error": "name required"}, status=400)
    try:
        from meeting_helper.config import delete_workspace
        delete_workspace(name)
    except ValueError as exc:
        return web.json_response({"error": str(exc)}, status=400)
    return web.json_response({"ok": True})


async def workspace_activate_handler(request: web.Request) -> web.Response:
    """POST /workspace/activate — switch active workspace and self-restart.

    Mirrors ``meeting_helper.workspace_switch.switch_workspace``: refuses
    while a session is live, updates state.json via ``set_active_workspace``
    (which also clears the cached Config), then schedules a delayed
    self-SIGTERM so the HTTP response can flush before the daemon dies.
    The shell's daemon supervisor (`shell/__main__.py`) respawns it.
    """
    import os
    import signal
    from meeting_helper.config import set_active_workspace, list_workspaces

    try:
        body = await request.json()
    except Exception:
        return web.json_response({"error": "invalid JSON"}, status=400)

    name = str(body.get("name") or "").strip()
    if not name:
        return web.json_response({"error": "name required"}, status=400)
    if name not in list_workspaces():
        return web.json_response(
            {"error": f"unknown workspace {name!r}"}, status=404,
        )
    if state.session_active:
        return web.json_response(
            {"error": "stop the current recording before switching"},
            status=409,
        )
    try:
        set_active_workspace(name)
    except ValueError as exc:
        return web.json_response({"error": str(exc)}, status=400)

    # Schedule SIGTERM so the response returns first; the shell will respawn
    # the daemon via its supervisor thread.
    asyncio.get_event_loop().call_later(
        0.5, lambda: os.kill(os.getpid(), signal.SIGTERM)
    )
    return web.json_response({"ok": True, "active": name, "restarting": True})


async def config_get_handler(request: web.Request) -> web.Response:
    """Return the full live AppConfig snapshot the Settings UI hydrates from.

    Plan 2's Settings tabs render a single form driven by `useConfigForm`,
    which expects every field declared in `web/lib/config-schema.ts` to be
    present on the response — missing keys leave Zod- / hand-typed reads
    pointing at `undefined` and crash the client. We therefore mirror the
    full `AppConfig` dataclass shape (including `recordings_dir` coerced
    to a string so it survives JSON round-tripping). Fields the UI doesn't
    yet write are still safe to expose; the POST handler ignores keys it
    doesn't know about.
    """
    config = request.app["config"]

    # Menubar / autostart toggles live on the disk-backed Config (workspace
    # JSON), not on the live AppConfig dataclass — they only matter on
    # menubar/launchd setup and aren't part of the runtime hot path. Read
    # them via `get_config()._data` for the GET payload so the UI hydrates
    # with the user's persisted choice.
    from meeting_helper.config import get_config
    disk = get_config()

    def _g(name: str, default):
        v = getattr(config, name, default)
        return v if v is not None else default

    payload = {
        "anthropic_api_key": _g("anthropic_api_key", ""),
        "google_api_key": _g("google_api_key", ""),
        "deepgram_api_key": _g("deepgram_api_key", ""),
        "port": int(_g("port", 7891)),
        "recordings_dir": str(_g("recordings_dir", "")),
        "kb_artifacts": list(_g("kb_artifacts", []) or []),
        "kb_max_results": int(_g("kb_max_results", 3)),
        "auto_summarize_on_end": bool(_g("auto_summarize_on_end", False)),
        "auto_rename_on_end": bool(_g("auto_rename_on_end", False)),
        "auto_add_to_kb": bool(_g("auto_add_to_kb", True)),
        "sentence_window": int(_g("sentence_window", 5)),
        "max_history_turns": int(_g("max_history_turns", 5)),
        "claude_model": _g("claude_model", ""),
        "claude_model_alias": _g("claude_model_alias", "sonnet"),
        "gemini_model": _g("gemini_model", ""),
        "gemini_model_alias": _g("gemini_model_alias", "flash"),
        "max_tokens": int(_g("max_tokens", 2048)),
        "transcription_language": _g("transcription_language", "en"),
        "silence_timeout": int(_g("silence_timeout", 30)),
        "hot_moment_window_minutes": float(_g("hot_moment_window_minutes", 10.0)),
        "proactive_answers": bool(_g("proactive_answers", False)),
        "preferred_provider": _g("preferred_provider", ""),
        "ai_provider_order": list(_g("ai_provider_order", []) or []),
        "ai_failover_delay_ms": int(_g("ai_failover_delay_ms", 2000)),
        "ollama_host": _g("ollama_host", ""),
        "local_model": _g("local_model", ""),
        "preferred_transcriber": _g("preferred_transcriber", ""),
        "whisper_host": _g("whisper_host", ""),
        "auto_start_record": bool(_g("auto_start_record", True)),
        "system_prompt": _g("system_prompt", ""),
        "local_todo_mcp": dict(_g("local_todo_mcp", {}) or {}),
        "show_menubar_icon": bool(disk._data.get("show_menubar_icon", True)),
        "menubar_icon": str(disk._data.get("menubar_icon", "MH")),
        "autostart_on_login": bool(disk._data.get("autostart_on_login", False)),
    }
    return web.Response(
        text=json.dumps(payload),
        content_type="application/json",
    )


async def config_post_handler(request: web.Request) -> web.Response:
    """Update live-tunable workspace config mid-session.

    Accepts every field the new Settings UI writes: API keys, recordings dir,
    auto-on-end toggles, AI provider/model, transcriber settings, hot-moment
    window, MCP config, Ollama host, menubar visibility, and the AI system
    prompt. The daemon caches its `AppConfig` at startup, so without this the
    GUI's saved changes were silently ignored until a full daemon restart —
    here we mutate the in-memory config and, if a session is running, hot-swap
    the transcribers (same path as `/provider`).
    """
    try:
        body = await request.json()
    except Exception:
        return web.Response(status=400, text='{"error": "invalid JSON"}',
                            content_type="application/json")

    config = request.app["config"]

    # Load the disk-backed Config once; mirror writes here. Save at the end
    # so a single POST is one fsync rather than one per field. Without this
    # mirror, every field below would only update the in-memory AppConfig
    # snapshot and revert on the next daemon restart.
    from meeting_helper.config import get_config
    disk = get_config()
    disk_dirty = False

    if "hot_moment_window_minutes" in body:
        # Live tunable. Mirror it onto `state` so every Hot Moment armer
        # (TopicWorker on self-speech, query, brief) picks up the change on
        # the next event — `state` is what they read, not this snapshot.
        minutes = float(body["hot_moment_window_minutes"])
        if minutes != config.hot_moment_window_minutes:
            config.hot_moment_window_minutes = minutes
            disk.hot_moment_window_minutes = minutes
            disk_dirty = True
        state.hot_moment_window_sec = minutes * 60.0
    if "local_todo_mcp" in body:
        # MCP config changed — close existing client and rebuild against new endpoint.
        new_mcp = dict(body["local_todo_mcp"] or {})
        config.local_todo_mcp = new_mcp
        disk.local_todo_mcp = new_mcp
        disk_dirty = True
        if state.local_todo is not None:
            try:
                await state.local_todo.close()
            except Exception as exc:
                logger.warning("local-todo close error during reconfig: %s", exc)
            state.local_todo = None
        kind = (new_mcp.get("type") or "stdio").strip().lower()
        configured = bool(new_mcp.get("url")) if kind == "http" else bool(new_mcp.get("command"))
        if configured:
            try:
                from meeting_helper.local_todo import LocalTodoClient
                state.local_todo = LocalTodoClient(mcp_config=new_mcp)
                logger.info(
                    "local-todo MCP rewired (%s %s)",
                    kind,
                    new_mcp.get("url") if kind == "http" else new_mcp.get("command"),
                )
            except Exception as exc:
                logger.warning("local-todo rewire failed: %s", exc)
                state.local_todo = None
        else:
            logger.info("local-todo MCP cleared via /config")
        # Push fresh info so Brief-button visibility flips without polling delay.
        from meeting_helper.server.websocket import broadcast_info
        asyncio.ensure_future(broadcast_info())

    # Transcriber settings — the daemon's AppConfig snapshot would otherwise
    # only pick these up on a full restart. Mutate it in place and, if a
    # session is live, hot-swap the transcribers (reuses session.swap_transcriber,
    # the same machinery the /provider toolbar dropdown uses). Only act on
    # values that actually changed so an unrelated settings-save doesn't tear
    # down and rebuild the transcribers mid-meeting.
    _trans_changed = False
    if "preferred_transcriber" in body:
        v = (body["preferred_transcriber"] or "").strip()
        if v != config.preferred_transcriber:
            config.preferred_transcriber = v
            disk.preferred_transcriber = v
            disk_dirty = True
            _trans_changed = True
    if "whisper_host" in body:
        v = (body["whisper_host"] or "").strip()
        if v != config.whisper_host:
            config.whisper_host = v
            disk.whisper_host = v
            disk_dirty = True
            _trans_changed = True
    if "deepgram_api_key" in body:
        v = (body["deepgram_api_key"] or "").strip()
        if v != config.deepgram_api_key:
            config.deepgram_api_key = v
            disk.deepgram_api_key = v
            disk_dirty = True
            _trans_changed = True
    if "transcription_language" in body:
        v = (body["transcription_language"] or "auto").strip()
        if v != config.transcription_language:
            config.transcription_language = v
            disk.transcription_language = v
            disk_dirty = True
            _trans_changed = True
    if _trans_changed:
        if state.session_active and state.meeting_session is not None:
            try:
                t_name = await asyncio.to_thread(
                    state.meeting_session.swap_transcriber,
                    config.preferred_transcriber, config,
                )
                state.transcriber_name = t_name
                logger.info("Transcriber reconfigured live via /config -> %s", t_name)
            except Exception as exc:
                logger.warning("live transcriber swap failed: %s", exc)
        else:
            logger.info("Transcriber config updated via /config (no active session)")
        from meeting_helper.server.websocket import broadcast_info as _bi
        await _bi()

    # Provider credentials, recordings dir, auto-on-end toggles, and other
    # settings the Settings UI writes. Mutates the in-memory AppConfig so
    # downstream readers (LLM clients, recording sink, session lifecycle hooks)
    # pick up the new values without a daemon restart.
    if "anthropic_api_key" in body:
        v = str(body["anthropic_api_key"] or "")
        if v != config.anthropic_api_key:
            config.anthropic_api_key = v
            disk.anthropic_api_key = v
            disk_dirty = True
    if "google_api_key" in body:
        v = str(body["google_api_key"] or "")
        if v != config.google_api_key:
            config.google_api_key = v
            disk.google_api_key = v
            disk_dirty = True
    if "recordings_dir" in body:
        v = str(body["recordings_dir"] or "")
        if v:
            config.recordings_dir = v
            disk.recordings_dir = v
            disk_dirty = True
    if "auto_summarize_on_end" in body:
        v = bool(body["auto_summarize_on_end"])
        if v != config.auto_summarize_on_end:
            config.auto_summarize_on_end = v
            disk.auto_summarize_on_end = v
            disk_dirty = True
    if "auto_rename_on_end" in body:
        v = bool(body["auto_rename_on_end"])
        if v != config.auto_rename_on_end:
            config.auto_rename_on_end = v
            disk.auto_rename_on_end = v
            disk_dirty = True
    if "auto_add_to_kb" in body:
        v = bool(body["auto_add_to_kb"])
        if v != config.auto_add_to_kb:
            config.auto_add_to_kb = v
            disk.auto_add_to_kb = v
            disk_dirty = True
    if "auto_start_record" in body:
        v = bool(body["auto_start_record"])
        if v != config.auto_start_record:
            config.auto_start_record = v
            disk.auto_start_record = v
            disk_dirty = True
    if "ollama_host" in body:
        v = str(body["ollama_host"] or "")
        if v != config.ollama_host:
            config.ollama_host = v
            disk.ollama_host = v
            disk_dirty = True
    if "claude_model_alias" in body:
        v = str(body["claude_model_alias"] or "")
        if v and v != config.claude_model_alias:
            config.claude_model_alias = v
            # Config stores the alias under the `claude_model` key, same
            # pattern the /provider handler uses (routes.py ~1453).
            disk.claude_model = v
            disk_dirty = True
    if "gemini_model_alias" in body:
        v = str(body["gemini_model_alias"] or "")
        if v and v != config.gemini_model_alias:
            config.gemini_model_alias = v
            disk.gemini_model = v
            disk_dirty = True
    if "system_prompt" in body:
        # `system_prompt` is built dynamically by `Config.to_app_config` from
        # `build_system_prompt("")` and is not persisted in the workspace
        # JSON. Update the in-memory snapshot so the current daemon process
        # picks it up; on restart it'll regenerate from the prompts module.
        v = str(body["system_prompt"] or "")
        if v != config.system_prompt:
            config.system_prompt = v

    # Menubar visibility / glyph and macOS LaunchAgent autostart. These live
    # only on `disk._data` (not the runtime AppConfig dataclass) because they
    # affect a sibling process (`meeting_helper.menubar`) and an OS-level
    # plist, not the daemon's own hot path. Old Flet (`screens/settings.py:
    # _autosave + _restart_menubar + _update_autostart`) did the same dance:
    # write the JSON, then kill/respawn the menubar PID and write/remove the
    # `~/Library/LaunchAgents/com.meeting-helper.menubar.plist` file.
    _menubar_state_changed = False
    _autostart_changed_to: bool | None = None
    if "show_menubar_icon" in body:
        v = bool(body["show_menubar_icon"])
        cur = bool(disk._data.get("show_menubar_icon", True))
        if v != cur:
            disk._data["show_menubar_icon"] = v
            disk_dirty = True
            _menubar_state_changed = True
    if "menubar_icon" in body:
        v = str(body["menubar_icon"] or "MH")
        cur = str(disk._data.get("menubar_icon", "MH"))
        if v != cur:
            disk._data["menubar_icon"] = v
            disk_dirty = True
            _menubar_state_changed = True
    if "autostart_on_login" in body:
        v = bool(body["autostart_on_login"])
        cur = bool(disk._data.get("autostart_on_login", False))
        if v != cur:
            disk._data["autostart_on_login"] = v
            disk_dirty = True
            _autostart_changed_to = v

    # AI provider / model — same story: cached at daemon startup, so a Settings
    # change to these used to need a daemon restart. Queries read `config` fresh,
    # so mutating the in-memory snapshot is enough (no transcriber-style swap).
    _ai_changed = False
    if "preferred_provider" in body:
        v = (body["preferred_provider"] or "").strip()
        if v != config.preferred_provider:
            config.preferred_provider = v
            disk.preferred_provider = v
            disk_dirty = True
            _ai_changed = True
    if "claude_model" in body:
        from meeting_helper.config import CLAUDE_MODELS
        alias = (body["claude_model"] or "").strip()
        if alias and alias != config.claude_model_alias:
            config.claude_model_alias = alias
            config.claude_model = CLAUDE_MODELS.get(alias, alias)
            disk.claude_model = alias
            disk_dirty = True
            _ai_changed = True
    if "gemini_model" in body:
        from meeting_helper.config import GEMINI_MODELS
        alias = (body["gemini_model"] or "").strip()
        if alias and alias != config.gemini_model_alias:
            config.gemini_model_alias = alias
            config.gemini_model = GEMINI_MODELS.get(alias, alias)
            disk.gemini_model = alias
            disk_dirty = True
            _ai_changed = True
    if "local_model" in body:
        v = (body["local_model"] or "").strip()
        if v != config.local_model:
            config.local_model = v
            disk.local_model = v
            disk_dirty = True
            _ai_changed = True
    if "ai_provider_order" in body:
        v = body["ai_provider_order"] or []
        if isinstance(v, list):
            normalized = [str(p).strip().lower() for p in v]
            if normalized != list(config.ai_provider_order):
                config.ai_provider_order = normalized
                disk.ai_provider_order = normalized
                disk_dirty = True
                _ai_changed = True
    if "ai_failover_delay_ms" in body:
        try:
            v = max(0, int(body["ai_failover_delay_ms"]))
        except (TypeError, ValueError):
            v = config.ai_failover_delay_ms
        if v != config.ai_failover_delay_ms:
            config.ai_failover_delay_ms = v
            disk.ai_failover_delay_ms = v
            disk_dirty = True
            _ai_changed = True
    if _ai_changed:
        state.ai_provider = config.preferred_provider or "claude"
        state.ai_model = _resolve_ai_model(config)
        logger.info("AI provider/model reconfigured live via /config -> %s / %s",
                    state.ai_provider, state.ai_model)
        from meeting_helper.server.websocket import broadcast_info as _bi2
        await _bi2()

    # Persist all dataclass-mirrored field writes to the workspace JSON in a
    # single fsync. Without this the in-memory AppConfig snapshot drifts from
    # disk and any saved Settings revert on daemon restart.
    if disk_dirty:
        try:
            disk.save()
        except Exception as exc:
            logger.warning("config disk save failed: %s", exc)

    # Side-effects that must happen *after* disk.save() so the new state is
    # what the menubar (a separate process) reads on respawn.
    if _menubar_state_changed:
        _restart_menubar_process(disk)
    if _autostart_changed_to is not None:
        _apply_autostart_setting(bool(_autostart_changed_to))

    return web.Response(
        text=json.dumps({"ok": True}),
        content_type="application/json",
    )


def _restart_menubar_process(disk) -> None:
    """Kill the existing menubar PID and respawn iff the icon is enabled.

    Same flow as old Flet's `_restart_menubar` in
    `flet_gui/screens/settings.py`. The menubar reads its glyph from disk
    on startup, so toggling either `show_menubar_icon` or `menubar_icon`
    requires the relaunch — otherwise the bar shows the previous glyph
    until next daemon restart.
    """
    import os
    import signal
    import sys
    from meeting_helper.config import MENUBAR_PID_FILE
    if MENUBAR_PID_FILE.exists():
        try:
            pid = int(MENUBAR_PID_FILE.read_text().strip())
            os.kill(pid, signal.SIGTERM)
        except (ValueError, ProcessLookupError, FileNotFoundError):
            pass
        except Exception as exc:
            logger.warning("menubar kill failed: %s", exc)
        try:
            MENUBAR_PID_FILE.unlink(missing_ok=True)
        except Exception:
            pass
    if disk._data.get("show_menubar_icon", True):
        try:
            subprocess.Popen(
                [sys.executable, "-m", "meeting_helper.menubar"],
                start_new_session=True,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                stdin=subprocess.DEVNULL,
            )
        except Exception as exc:
            logger.warning("menubar respawn failed: %s", exc)


def _apply_autostart_setting(enabled: bool) -> None:
    """Write or remove the macOS LaunchAgent plist for the menubar.

    Mirrors old Flet's `_update_autostart`: writes
    `~/Library/LaunchAgents/com.meeting-helper.menubar.plist` and runs
    `launchctl load` when enabled; unloads + deletes it when disabled.
    No-op on non-Darwin (launchctl absent — Popen will surface that).
    """
    import shutil
    import sys
    plist_path = Path.home() / "Library" / "LaunchAgents" / "com.meeting-helper.menubar.plist"
    if enabled:
        cli = shutil.which("meeting-helper") or str(Path(sys.executable).parent / "meeting-helper")
        plist_content = (
            '<?xml version="1.0" encoding="UTF-8"?>\n'
            '<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" '
            '"http://www.apple.com/DTDs/PropertyList-1.0.dtd">\n'
            '<plist version="1.0">\n'
            '<dict>\n'
            '    <key>Label</key>\n'
            '    <string>com.meeting-helper.menubar</string>\n'
            '    <key>ProgramArguments</key>\n'
            '    <array>\n'
            f'        <string>{cli}</string>\n'
            '        <string>menubar</string>\n'
            '    </array>\n'
            '    <key>RunAtLoad</key>\n'
            '    <true/>\n'
            '    <key>KeepAlive</key>\n'
            '    <false/>\n'
            '</dict>\n'
            '</plist>'
        )
        try:
            plist_path.parent.mkdir(parents=True, exist_ok=True)
            plist_path.write_text(plist_content)
            subprocess.run(
                ["launchctl", "load", str(plist_path)],
                capture_output=True,
            )
        except Exception as exc:
            logger.warning("autostart enable failed: %s", exc)
    else:
        if plist_path.exists():
            try:
                subprocess.run(
                    ["launchctl", "unload", str(plist_path)],
                    capture_output=True,
                )
                plist_path.unlink(missing_ok=True)
            except Exception as exc:
                logger.warning("autostart disable failed: %s", exc)


async def transcript_handler_get(request: web.Request) -> web.Response:
    """GET /transcript — return the last N sentences from the buffer."""
    n = int(request.query.get("n", "10"))
    sentences = []
    if state.sentence_buffer is not None:
        sentences = state.sentence_buffer.get_last_n(n)
    interim = None
    if state.sentence_buffer is not None:
        interim = state.sentence_buffer.get_interim()
    return web.Response(
        text=json.dumps({"sentences": sentences, "interim": interim}),
        content_type="application/json",
    )


async def transcript_clear_handler(request: web.Request) -> web.Response:
    """POST /transcript/clear — clear the accumulated transcript buffer."""
    if state.sentence_buffer is not None:
        state.sentence_buffer.clear()
    return web.Response(
        text=json.dumps({"ok": True}),
        content_type="application/json",
    )


async def last_response_handler(request: web.Request) -> web.Response:
    """GET /last_response — return the last AI response text."""
    return web.Response(
        text=json.dumps({"text": state.last_response or ""}),
        content_type="application/json",
    )


async def last_cards_handler(request: web.Request) -> web.Response:
    """GET /last_cards — returns the last query's local-todo source cards."""
    return web.Response(
        text=json.dumps({"items": state.last_cards or []}),
        content_type="application/json",
    )


async def current_topic_handler(request: web.Request) -> web.Response:
    """GET /current_topic — current topic + warm-cache info from TopicWorker.

    The `manual` flag is folded into the topic object so the UI can tell
    whether TopicWorker is in AUTO mode (auto-detect on each utterance) or
    MANUAL mode (user pinned a specific ticket). This drives the AUTO/MANUAL
    toggle pill in the topic strip — without it, the UI defaults to "Active"
    even when the daemon is in pinned mode.
    """
    topic = state.current_topic or {
        "topic": "", "ticket_ids": [], "search_query": "", "last_user_statement": "",
    }
    # Make a shallow copy so we don't mutate state.current_topic in-place.
    topic = {**topic, "manual": bool(state.topic_manual_mode)}
    return web.Response(
        text=json.dumps({
            "topic": topic,
            "cards_count": len(state.current_topic_cards or []),
            "cards": state.current_topic_cards or [],
        }),
        content_type="application/json",
    )


async def topics_handler(request: web.Request) -> web.Response:
    """GET /topics — list every top-level task in active sprints across boards.

    Powers the Topics tab in the Copilot side panel: the user picks one to
    set as the current conversation topic, overriding TopicWorker's
    automatic detection for a brief window.

    Slim payload — no subtasks/comments/history (the TopicsPanel only needs
    enough to render a card and call /topic/set on click).
    """
    if state.local_todo is None:
        return web.json_response(
            {"topics": [], "columns": [], "error": "local-todo MCP not configured"},
            status=503,
        )
    # Server timeout intentionally tighter than the GUI's 8s poll cadence
    # AND tighter than the GUI's 3s urlopen timeout. With a 15s server
    # timeout, a single slow MCP would have the GUI bail at 3s, the next
    # poll fire at 8s while the server still chews for 7 more seconds —
    # producing concurrent my_active_tasks() calls hitting the same MCP
    # subprocess. 5s caps the overlap window at zero.
    try:
        tasks = await asyncio.wait_for(
            state.local_todo.my_active_tasks(), timeout=5.0,
        )
    except asyncio.TimeoutError:
        logger.warning("topics: my_active_tasks timed out (5s)")
        return web.json_response(
            {"topics": [], "columns": [], "error": "timeout"}, status=504,
        )
    except Exception as exc:
        logger.warning("topics: my_active_tasks failed: %s", exc)
        return web.json_response(
            {"topics": [], "columns": [], "error": str(exc)}, status=502,
        )

    # Slim each task to the fields TopicsPanel renders.
    slimmed = [
        {
            "id": str(t.get("id") or ""),
            "title": t.get("title") or "",
            "status": (t.get("status") or "todo").lower(),
            "priority": (t.get("priority") or "").lower(),
            "board_id": t.get("board_id"),
            "board_name": t.get("board_name") or "",
            "sprint_name": t.get("sprint_name") or "",
            "url": t.get("url") or "",
        }
        for t in tasks
        if (t.get("title") or "").strip()
    ]

    # Fetch column metadata per distinct board in parallel so the GUI can
    # render status sections in the user's configured order with their
    # configured names + colors. Without this we hardcode (todo,
    # in_progress, in_review, done) and miss anything the user added on
    # their board (e.g. "blocked"). MCP `list_board_columns` returns
    # `key, name, kind, color, position` per column.
    board_ids: list[int] = sorted({
        t.get("board_id") for t in slimmed
        if isinstance(t.get("board_id"), int)
    })
    columns: list[dict] = []
    if board_ids:
        col_calls = [
            state.local_todo.list_board_columns(bid) for bid in board_ids
        ]
        try:
            results = await asyncio.wait_for(
                asyncio.gather(*col_calls, return_exceptions=True),
                timeout=3.0,
            )
        except asyncio.TimeoutError:
            logger.warning("topics: column fetch timed out (3s)")
            results = []

        # Merge: dedupe by (board_id, key) so multiple boards don't
        # collide on shared status keys; preserve each board's position.
        seen: set[tuple[int, str]] = set()
        for board_id, res in zip(board_ids, results):
            if isinstance(res, Exception):
                logger.warning(
                    "topics: list_board_columns(%d) failed: %s", board_id, res,
                )
                continue
            for c in res or []:
                key = (c.get("key") or "").lower()
                if not key:
                    continue
                marker = (board_id, key)
                if marker in seen:
                    continue
                seen.add(marker)
                columns.append({
                    "board_id": board_id,
                    "key": key,
                    "name": c.get("name") or key.replace("_", " ").title(),
                    "kind": (c.get("kind") or "").lower(),
                    "color": c.get("color") or "",
                    "position": c.get("position", 0),
                })

    return web.json_response({"topics": slimmed, "columns": columns})


async def topic_set_handler(request: web.Request) -> web.Response:
    """POST /topic/set — manually pin the current topic.

    Body: {ticket_id: str, title: str, board_id?: int}

    Side effects:
    - state.current_topic is updated.
    - state.topic_manual_mode is set to True so TopicWorker won't
      overwrite it until the user explicitly toggles back to AUTO.
    - WS broadcast fires so the TopicStrip on top + the active-topic
      highlight in TopicsPanel update immediately.
    """
    try:
        body = await request.json()
    except Exception:
        return web.json_response({"error": "invalid JSON"}, status=400)

    ticket_id = str(body.get("ticket_id") or "").strip()
    title = (body.get("title") or "").strip()
    board_id = body.get("board_id")
    if not title:
        return web.json_response({"error": "title required"}, status=400)

    # MANUAL mode is sticky — stays on until the user explicitly toggles
    # back to AUTO via POST /topic/auto (or by clicking the indicator pill
    # in the GUI). No countdown.
    state.current_topic = {
        "topic": title,
        "ticket_ids": [ticket_id] if ticket_id else [],
        "search_query": title,
        "last_user_statement": "",
        "manual": True,
    }
    state.topic_manual_mode = True

    # Hydrate the picked card so the AI's `_format_cards_markdown` has the
    # real ticket body + comments to ground its answers in. Without this,
    # the user pins a topic and the AI knows the title only — every
    # follow-up question lands without context. One get_task call (~100-
    # 300 ms via local-todo MCP) is the entire cost; no LLM round-trip.
    # Cached in state.current_topic_cards for the 90 s pin window so
    # subsequent /query calls reuse it for free.
    hydrated_cards: list[dict] = []
    if state.local_todo is not None and ticket_id and board_id is not None:
        try:
            hydrated = await asyncio.wait_for(
                state.local_todo.get("task", ticket_id, int(board_id)),
                timeout=10.0,
            )
            if hydrated:
                hydrated_cards = [hydrated]
                logger.info(
                    "topic/set: hydrated card %s (board=%s, body=%d chars, "
                    "%d comments, %d subtasks)",
                    ticket_id, board_id,
                    len(hydrated.get("body_md") or ""),
                    len(hydrated.get("comments") or []),
                    len(hydrated.get("subtasks") or []),
                )
        except asyncio.TimeoutError:
            logger.warning(
                "topic/set: hydrate get_task(%s, board=%s) timed out — "
                "falling back to thin card", ticket_id, board_id,
            )
        except Exception as exc:
            logger.warning(
                "topic/set: hydrate get_task(%s, board=%s) failed: %s — "
                "falling back to thin card", ticket_id, board_id, exc,
            )

    if not hydrated_cards:
        # Fall back to a thin card so the AI at least sees the ticket id +
        # title. Cards markdown handles thin cards gracefully (title only).
        thin_card: dict = {"id": ticket_id, "title": title}
        if board_id is not None:
            thin_card["board_id"] = board_id
        hydrated_cards = [thin_card]

    state.current_topic_cards = hydrated_cards

    # Broadcast so all connected GUIs reflect the change immediately.
    # MANUAL mode is binary now — no countdown payload. The GUI flips its
    # AUTO/MANUAL pill until the user toggles it back.
    try:
        from meeting_helper.server.websocket import broadcast
        await broadcast({
            "type": "topic",
            "topic": title,
            "ticket_ids": [ticket_id] if ticket_id else [],
            "last_user_statement": "",
            "cards": [],
            "manual": True,
            "hot_moment": {
                "active": state.is_hot_moment(),
                "until_wallclock": state.hot_moment_until_wallclock(),
            },
        })
    except Exception as exc:
        logger.warning("topic/set broadcast failed: %s", exc)

    logger.info(
        "topic/set: pinned ticket_id=%s title=%r indefinite",
        ticket_id, title[:80],
    )
    return web.json_response({
        "ok": True,
        "ticket_id": ticket_id,
        "title": title,
        "manual": True,
    })


async def topic_auto_handler(request: web.Request) -> web.Response:
    """POST /topic/auto — clear the manual topic pin and let TopicWorker
    resume auto-picking. Idempotent.
    """
    state.topic_manual_mode = False
    # Clear the pinned topic so TopicWorker's next pick takes over cleanly.
    state.current_topic = {}
    state.current_topic_cards = []
    state.last_cards = []
    # Broadcast so the GUI updates immediately.
    try:
        from meeting_helper.server.websocket import broadcast
        await broadcast({"type": "topic", "manual": False, "current_topic": {}})
    except Exception as exc:
        logger.warning("topic/auto broadcast failed: %s", exc)
    logger.info("topic/auto: cleared manual pin")
    return web.json_response({"ok": True})


async def topic_manual_handler(request: web.Request) -> web.Response:
    """POST /topic/manual — flip into MANUAL mode without changing the
    current topic. TopicWorker stops auto-picking; the displayed topic
    stays as-is. Idempotent.
    """
    state.topic_manual_mode = True
    from meeting_helper.server.websocket import broadcast
    try:
        await broadcast({"type": "topic", "manual": True})
    except Exception as exc:
        logger.warning("topic/manual broadcast failed: %s", exc)
    logger.info("topic/manual: switched to MANUAL")
    return web.json_response({"ok": True})


async def hot_moment_cancel_handler(request: web.Request) -> web.Response:
    """POST /hot_moment/cancel — disarm the current hot moment immediately.

    Sets hot_moment_until to 0 so state.is_hot_moment() returns False
    on the next tick. Idempotent.
    """
    state.hot_moment_until = 0.0
    from meeting_helper.server.websocket import broadcast
    try:
        await broadcast({"type": "hot_moment", "active": False, "until_wallclock": 0})
    except Exception as exc:
        logger.warning("hot_moment/cancel broadcast failed: %s", exc)
    logger.info("hot_moment/cancel: disarmed")
    return web.json_response({"ok": True})


async def query_handler(request: web.Request) -> web.Response:
    """POST /query — send a manual text query to Claude."""
    state.arm_hot_moment(window_sec=_hot_moment_window_sec(request))
    try:
        body = await request.json()
    except Exception:
        return web.Response(status=400, text='{"error": "invalid JSON"}',
                            content_type="application/json")

    text = body.get("text", "").strip()
    if not text:
        return web.Response(status=400, text='{"error": "text required"}',
                            content_type="application/json")

    from meeting_helper.ai.client import handle_manual_query
    config = request.app["config"]

    try:
        await handle_manual_query(state, config, text)
        return web.Response(
            text=json.dumps({"ok": True}),
            content_type="application/json",
        )
    except Exception as exc:
        return web.Response(
            status=500,
            text=json.dumps({"error": str(exc)}),
            content_type="application/json",
        )


async def trigger_query_handler(request: web.Request) -> web.Response:
    """POST /query/trigger — context-only query, equivalent to the 2xCmd hotkey.

    Calls handle_query(state, config) without any user-typed text — the AI
    responds based on current transcript + topic context.
    """
    state.arm_hot_moment(window_sec=_hot_moment_window_sec(request))
    from meeting_helper.ai.client import handle_query
    config = request.app["config"]
    try:
        await handle_query(state, config)
        return web.Response(
            text=json.dumps({"ok": True}),
            content_type="application/json",
        )
    except Exception as exc:
        return web.Response(
            status=500,
            text=json.dumps({"error": str(exc)}),
            content_type="application/json",
        )


async def transcribe_handler(request: web.Request) -> web.Response:
    """POST /transcribe — transcribe an MP3 file with Whisper."""
    try:
        body = await request.json()
    except Exception:
        return web.Response(status=400, text='{"error": "invalid JSON"}',
                            content_type="application/json")

    mp3_path = body.get("mp3_path", "")
    if not mp3_path:
        return web.Response(status=400, text='{"error": "mp3_path required"}',
                            content_type="application/json")

    from meeting_helper.ai.client import transcribe_audio_file
    config = request.app["config"]

    try:
        transcript = await asyncio.to_thread(transcribe_audio_file, mp3_path, config)
        return web.Response(
            text=json.dumps({"ok": True, "transcript": transcript}),
            content_type="application/json",
        )
    except Exception as exc:
        return web.Response(
            status=500,
            text=json.dumps({"error": str(exc)}),
            content_type="application/json",
        )


async def summarize_handler(request: web.Request) -> web.Response:
    """POST /summarize — summarize a transcript with Claude."""
    try:
        body = await request.json()
    except Exception:
        return web.Response(status=400, text='{"error": "invalid JSON"}',
                            content_type="application/json")

    transcript_path = body.get("transcript_path", "")
    if not transcript_path:
        return web.Response(status=400, text='{"error": "transcript_path required"}',
                            content_type="application/json")

    from meeting_helper.ai.client import summarize_transcript
    config = request.app["config"]

    try:
        summary = await summarize_transcript(transcript_path, config)
        return web.Response(
            text=json.dumps({"ok": True, "summary": summary}),
            content_type="application/json",
        )
    except Exception as exc:
        return web.Response(
            status=500,
            text=json.dumps({"error": str(exc)}),
            content_type="application/json",
        )


async def extract_task_handler(request: web.Request) -> web.Response:
    """POST /extract-task — extract new action items from the in-memory transcript."""
    from meeting_helper.ai.client import extract_tasks
    from meeting_helper.server.websocket import broadcast

    config = request.app["config"]
    try:
        added = await extract_tasks(state, config)
    except Exception as exc:
        return web.Response(
            status=500,
            text=json.dumps({"error": str(exc)}),
            content_type="application/json",
        )

    await broadcast({"type": "tasks_extracted", "added": len(added)})
    await broadcast({"type": "tasks", "tasks": list(state.session_tasks)})

    return web.Response(
        text=json.dumps({"added": len(added), "total": len(state.session_tasks)}),
        content_type="application/json",
    )


async def tasks_get_handler(request: web.Request) -> web.Response:
    """GET /tasks — return the current session's extracted tasks."""
    return web.Response(
        text=json.dumps({"tasks": list(state.session_tasks)}),
        content_type="application/json",
    )


async def brief_handler(request: web.Request) -> web.Response:
    """POST /brief — generate a first-person standup script + source cards from local-todo."""
    state.arm_hot_moment(window_sec=_hot_moment_window_sec(request))
    from meeting_helper.ai.prompts import BRIEF_SYSTEM_PROMPT
    import httpx

    config = request.app.get("config")
    logger.info("brief: start")
    if state.local_todo is None:
        logger.warning("brief: local_todo not configured — early-exit 503")
        return web.json_response(
            {"error": "local-todo MCP not configured"}, status=503,
        )
    if not getattr(config, "anthropic_api_key", ""):
        logger.warning("brief: anthropic key missing — early-exit 503")
        return web.json_response(
            {"error": "Anthropic API key not configured"}, status=503,
        )

    # Generous timeouts — first MCP call cold-starts the subprocess + does
    # list_boards + N parallel list_sprints + N parallel search_tasks + N
    # parallel get_task(include_subtasks=true). On a heavily loaded machine
    # 15s is too tight; 90s leaves headroom but still caps a wedged MCP call.
    # The enriched fetch adds one round-trip per active task; for ~10 active
    # tasks that's typically <2s on top of the base call.
    try:
        logger.info("brief: fetching my_active_tasks_enriched…")
        active_tasks = await asyncio.wait_for(
            state.local_todo.my_active_tasks_enriched(), timeout=90.0,
        )
        logger.info(
            "brief: got %d active topics (with subtasks/comments/history)",
            len(active_tasks),
        )
    except asyncio.TimeoutError:
        logger.warning("brief: my_active_tasks_enriched timed out after 90s")
        return web.json_response({"error": "local-todo timed out (90s)"}, status=504)
    except Exception as exc:
        logger.warning("brief: my_active_tasks_enriched failed: %s", exc)
        return web.json_response({"error": f"local-todo error: {exc}"}, status=502)

    if not active_tasks:
        logger.warning("brief: no active tasks — skipping LLM call")
        return web.json_response(
            {"error": "No active tasks in any sprint — nothing to summarize"},
            status=502,
        )

    user_msg = (
        "## My active topics (top-level tasks in active sprints, with their "
        "subtasks, recent comments, and recent history nested inline):\n"
        + json.dumps(active_tasks, indent=2)
        + "\n\nGenerate the standup script as JSON."
    )

    # Explicit timeout — without this, the Anthropic call could hang
    # indefinitely on a slow/wedged network (the GUI eventually gives up
    # at 30s but the daemon would still be holding the request open).
    client = AsyncAnthropic(
        api_key=config.anthropic_api_key,
        http_client=httpx.AsyncClient(verify=False, timeout=httpx.Timeout(30.0)),
    )
    state.record_ai_call("brief")
    try:
        logger.info("brief: calling Claude (haiku) with %d tasks…", len(active_tasks))
        msg = await asyncio.wait_for(
            client.messages.create(
                model="claude-haiku-4-5-20251001",
                max_tokens=getattr(config, "max_tokens", 800),
                system=BRIEF_SYSTEM_PROMPT,
                messages=[{"role": "user", "content": user_msg}],
            ),
            timeout=30.0,
        )
        logger.info("brief: Claude responded")
    except asyncio.TimeoutError:
        logger.warning("brief: Claude call timed out after 30s")
        return web.json_response({"error": "Claude API timed out (30s)"}, status=504)
    except Exception as exc:
        logger.warning("brief: Claude call failed: %s", exc)
        return web.json_response({"error": f"Claude call failed: {exc}"}, status=502)

    raw = msg.content[0].text.strip()
    match = re.search(r"\{.*\}", raw, re.DOTALL)
    if not match:
        logger.warning("brief: AI returned non-JSON (%d chars)", len(raw))
        return web.json_response({"error": "AI returned non-JSON", "raw": raw[:500]}, status=502)
    try:
        parsed = json.loads(match.group())
    except json.JSONDecodeError as exc:
        logger.warning("brief: JSON parse failed: %s", exc)
        return web.json_response({"error": f"JSON parse: {exc}", "raw": raw[:500]}, status=502)

    script = parsed.get("script", "").strip()
    card_ids = parsed.get("card_ids", []) or []
    logger.info("brief: parsed (script=%d chars, %d card_ids)", len(script), len(card_ids))
    if not script and not card_ids:
        logger.warning("brief: AI returned empty script and no card_ids — likely no active tasks")
        return web.json_response(
            {"error": "Brief came back empty — no active tasks to summarize"},
            status=502,
        )

    # Build id → board_id lookup from active_tasks (since task ids are scoped per board)
    id_to_board: dict[str, int] = {}
    for t in active_tasks:
        tid = str(t.get("id", ""))
        bid = t.get("board_id")
        if tid and bid is not None:
            id_to_board[tid] = bid

    cards: list[dict] = []
    for cid in card_ids:
        cid = str(cid)
        bid = id_to_board.get(cid)
        if bid is None:
            # Card id not in our active set — skip or try first available board
            logger.warning("brief: card_id %s not in active task set; skipping backfill", cid)
            continue
        record = None
        try:
            record = await asyncio.wait_for(
                state.local_todo.get("task", cid, board_id=bid), timeout=15.0,
            )
            if record:
                record.setdefault("kind", "task")
                record.setdefault("board_id", bid)
        except asyncio.TimeoutError:
            logger.warning("brief: backfill task %s timed out", cid)
            record = None
        except Exception:
            record = None
        if not record:
            try:
                record = await asyncio.wait_for(
                    state.local_todo.get("doc", cid, board_id=bid), timeout=15.0,
                )
                if record:
                    record.setdefault("kind", "doc")
                    record.setdefault("board_id", bid)
            except asyncio.TimeoutError:
                logger.warning("brief: backfill doc %s timed out", cid)
                continue
            except Exception as exc:
                logger.warning("brief: failed to backfill %s: %s", cid, exc)
                continue
        if record:
            cards.append(record)
    logger.info("brief: backfill done (%d/%d cards resolved)", len(cards), len(card_ids))

    # Slim cards before broadcasting (full records can blow the WS frame).
    # Full `cards` list is still passed to _seed_warm_cache_from_brief below
    # so AI queries keep their grounding context.
    slim_cards = [slim_card_for_broadcast(c) for c in cards]
    payload = {"script": script, "cards": slim_cards}

    # Seed warm cache so subsequent /query calls have grounded context
    # even before the user speaks aloud.
    try:
        seeded_topic = _seed_warm_cache_from_brief(script, cards)
        try:
            from meeting_helper.server.websocket import broadcast
            # NOTE: don't include `cards` here. The full card payload (with
            # comment threads etc.) can be large enough to disconnect WS
            # clients on the topic broadcast, *before* the brief broadcast
            # below ever lands. The brief broadcast carries cards for the
            # GUI, and the overlay only used `cards` here to compute a
            # count — pass the count instead.
            await broadcast({
                "type": "topic",
                "topic": seeded_topic.get("topic", ""),
                "ticket_ids": seeded_topic.get("ticket_ids", []),
                "last_user_statement": seeded_topic.get("last_user_statement", ""),
                "warm_cards_count": len(cards),
            })
            logger.info("brief: topic broadcast sent")
        except Exception as exc:
            logger.warning("brief: topic broadcast failed: %s", exc)
    except Exception as exc:
        logger.warning("brief: warm-cache seeding failed: %s", exc)

    try:
        from meeting_helper.server.websocket import broadcast
        n_clients = len(state.ws_clients)
        await broadcast({"type": "brief", **payload})
        logger.info("brief: brief broadcast sent to %d ws clients", n_clients)
    except Exception as exc:
        logger.warning("brief: brief broadcast failed: %s", exc)

    logger.info("brief: done")
    return web.json_response(payload)


async def debug_say_handler(request: web.Request) -> web.Response:
    """POST /debug/say — inject a sentence into self_buffer or other_buffer
    for testing without a mic. Body: {"text": "...", "role": "self"|"other"}.
    """
    try:
        body = await request.json()
    except Exception:
        return web.json_response({"error": "invalid JSON"}, status=400)

    text = (body.get("text") or "").strip()
    if not text:
        return web.json_response({"error": "text required"}, status=400)
    role = (body.get("role") or "self").strip().lower()
    if role not in ("self", "other"):
        return web.json_response({"error": "role must be 'self' or 'other'"}, status=400)

    buf = state.self_buffer if role == "self" else state.other_buffer
    if buf is None:
        return web.json_response(
            {"error": f"{role}_buffer not initialized — start a session first"},
            status=409,
        )

    buf.append_final(text)
    logger.info("debug/say: injected '%s' into %s_buffer", text[:80], role)
    return web.json_response({"ok": True, "role": role, "text": text})


async def conversations_handler(request: web.Request) -> web.Response:
    """GET /conversations?repo=<path> — list past Claude Code conversations for a repo."""
    repo = request.query.get("repo", "").strip()
    if not repo:
        return web.Response(
            status=400,
            text=json.dumps({"error": "repo query param required"}),
            content_type="application/json",
        )
    from meeting_helper.claude_history import list_conversations
    convs = await asyncio.to_thread(list_conversations, repo)
    return web.Response(
        text=json.dumps({"conversations": convs}),
        content_type="application/json",
    )


async def conversation_attach_handler(request: web.Request) -> web.Response:
    """POST /conversation/attach — attach a past Claude Code conversation as primary context.

    Body: {"repo": "<absolute path>", "session_id": "<uuid>"}
    """
    try:
        body = await request.json()
    except Exception:
        return web.Response(
            status=400,
            text='{"error": "invalid JSON"}',
            content_type="application/json",
        )

    repo = (body.get("repo") or "").strip()
    session_id = (body.get("session_id") or "").strip()
    if not repo or not session_id:
        return web.Response(
            status=400,
            text='{"error": "repo and session_id required"}',
            content_type="application/json",
        )

    from meeting_helper.claude_history import reconstruct_conversation
    from meeting_helper.ai.prompts import build_system_prompt, build_conversation_context_block
    from pathlib import Path

    try:
        conv = await asyncio.to_thread(reconstruct_conversation, repo, session_id)
    except FileNotFoundError as exc:
        return web.Response(
            status=404,
            text=json.dumps({"error": str(exc)}),
            content_type="application/json",
        )
    except Exception as exc:
        return web.Response(
            status=500,
            text=json.dumps({"error": str(exc)}),
            content_type="application/json",
        )

    repo_name = Path(repo).expanduser().resolve().name
    context_block = build_conversation_context_block(
        title=conv["title"],
        repo_name=repo_name,
        body=conv["body"],
        truncated=conv["truncated"],
    )
    state.system_prompt = build_system_prompt(context_block)
    # Clear any prior Q&A turns so answers grounded in the OLD context don't
    # leak into answers for the NEW conversation. Safe whether this is the
    # first attach or a switch from another conversation.
    state.conversation_history = []
    state.attached_conversation = {
        "session_id": conv["session_id"],
        "title": conv["title"],
        "repo": conv["repo"],
        "attached_at": time.time(),
        "chars": conv["chars"],
        "truncated": conv["truncated"],
        "turn_count": conv["turn_count"],
    }

    from meeting_helper.server.websocket import broadcast
    await broadcast({
        "type": "conversation_attached",
        "session_id": conv["session_id"],
        "title": conv["title"],
        "repo": conv["repo"],
        "chars": conv["chars"],
        "truncated": conv["truncated"],
        "turn_count": conv["turn_count"],
    })

    return web.Response(
        text=json.dumps({
            "ok": True,
            "title": conv["title"],
            "chars": conv["chars"],
            "truncated": conv["truncated"],
            "turn_count": conv["turn_count"],
        }),
        content_type="application/json",
    )


async def conversation_detach_handler(request: web.Request) -> web.Response:
    """POST /conversation/detach — clear an attached Claude Code conversation.

    Drops to a bare system prompt — the repos/knowledge auto-context layer
    has been removed (see Phase 2 of "Learn From Conversations").
    """
    if state.attached_conversation is None:
        return web.Response(
            text=json.dumps({"ok": True, "was_attached": False}),
            content_type="application/json",
        )

    state.attached_conversation = None
    # Clear Q&A turns grounded in the conversation we're detaching from.
    state.conversation_history = []

    from meeting_helper.ai.prompts import build_system_prompt
    state.system_prompt = build_system_prompt("")

    from meeting_helper.server.websocket import broadcast
    await broadcast({"type": "conversation_detached"})

    return web.Response(
        text=json.dumps({"ok": True, "was_attached": True}),
        content_type="application/json",
    )


async def session_start_handler(request: web.Request) -> web.Response:
    """POST /session/start — manually start a full recording session."""
    if state.session_active:
        return web.Response(
            text=json.dumps({"ok": True, "already_active": True}),
            content_type="application/json",
        )
    session = state.meeting_session
    if session is None:
        return web.Response(status=400, text='{"error": "no session manager"}',
                            content_type="application/json")
    session.manual_start()
    return web.Response(
        text=json.dumps({"ok": True}),
        content_type="application/json",
    )


async def session_stop_handler(request: web.Request) -> web.Response:
    """POST /session/stop — manually stop the current recording session."""
    if not state.session_active:
        return web.Response(
            text=json.dumps({"ok": True, "was_active": False}),
            content_type="application/json",
        )
    session = state.meeting_session
    if session is None:
        return web.Response(status=400, text='{"error": "no session manager"}',
                            content_type="application/json")
    session.manual_stop()
    return web.Response(
        text=json.dumps({"ok": True}),
        content_type="application/json",
    )


async def proactive_handler(request: web.Request) -> web.Response:
    """POST /proactive — enable or disable proactive answers for current session."""
    try:
        body = await request.json()
    except Exception:
        return web.Response(status=400, text='{"error": "invalid JSON"}', content_type="application/json")

    enabled = bool(body.get("enabled", True))
    monitor = state.proactive_monitor
    if monitor is not None:
        monitor.set_enabled(enabled)

    return web.Response(
        text=json.dumps({"ok": True, "enabled": enabled, "monitor_active": monitor is not None}),
        content_type="application/json",
    )


async def proactive_status_handler(request: web.Request) -> web.Response:
    """GET /proactive — return current proactive enabled state."""
    monitor = state.proactive_monitor
    enabled = monitor.is_enabled() if monitor is not None else False
    return web.Response(
        text=json.dumps({"enabled": enabled, "monitor_active": monitor is not None}),
        content_type="application/json",
    )


def _resolve_ai_model(config) -> str:
    """Return the display model string for the current provider config."""
    if config.preferred_provider == "local":
        return config.local_model
    if config.preferred_provider == "gemini":
        return config.gemini_model
    return config.claude_model


async def provider_get_handler(request: web.Request) -> web.Response:
    """GET /provider — return current provider/model/transcriber state.

    Also reports whether the workspace has the prerequisites the GUI needs to
    decide which controls to surface (`local_todo_configured`,
    `provider_configured`). Without these the GUI would have to read the
    daemon's config another way.
    """
    config = request.app["config"]
    return web.Response(
        text=json.dumps({
            "provider": config.preferred_provider or "claude",
            "claude_model": config.claude_model_alias,
            "gemini_model": config.gemini_model_alias,
            "local_model": config.local_model,
            "transcriber": config.preferred_transcriber or "whisper",
            # Runtime transcriber display name — e.g. "Whisper (remote: …)" /
            # "Whisper (local)" / "Deepgram" — so the toolbar chip shows what's
            # actually running, not just the configured mode. Empty until a
            # session has started.
            "transcriber_name": state.transcriber_name,
            "ai_model": state.ai_model,
            "local_todo_configured": config.local_todo_configured,
            "provider_configured": config.provider_configured,
        }),
        content_type="application/json",
    )


async def provider_post_handler(request: web.Request) -> web.Response:
    """POST /provider — switch AI provider, model, or transcriber at runtime."""
    try:
        body = await request.json()
    except Exception:
        return web.Response(status=400, text='{"error": "invalid JSON"}',
                            content_type="application/json")

    config = request.app["config"]
    changed = False

    # AI provider switch
    if "provider" in body:
        config.preferred_provider = body["provider"]
        changed = True
    if "claude_model" in body:
        from meeting_helper.config import CLAUDE_MODELS
        alias = body["claude_model"]
        config.claude_model_alias = alias
        config.claude_model = CLAUDE_MODELS.get(alias, alias)
        changed = True
    if "gemini_model" in body:
        from meeting_helper.config import GEMINI_MODELS
        alias = body["gemini_model"]
        config.gemini_model_alias = alias
        config.gemini_model = GEMINI_MODELS.get(alias, alias)
        changed = True
    if "local_model" in body:
        config.local_model = body["local_model"]
        changed = True

    # Transcriber switch
    transcriber_changed = False
    if "transcriber" in body:
        config.preferred_transcriber = body["transcriber"]
        transcriber_changed = True
        changed = True

    if transcriber_changed and state.session_active:
        session = state.meeting_session
        if session is not None:
            t_name = await asyncio.to_thread(
                session.swap_transcriber, body["transcriber"], config
            )
            state.transcriber_name = t_name

    # Update displayed AI provider + model
    if changed:
        state.ai_provider = config.preferred_provider or "claude"
        state.ai_model = _resolve_ai_model(config)

        # Broadcast info update to overlay/dashboard
        from meeting_helper.server.websocket import broadcast_info
        await broadcast_info()

        # Persist to disk config
        from meeting_helper.config import get_config
        disk = get_config()
        disk.preferred_provider = config.preferred_provider
        disk.claude_model = config.claude_model_alias
        disk.gemini_model = config.gemini_model_alias
        disk.local_model = config.local_model
        disk.preferred_transcriber = config.preferred_transcriber
        disk.save()

    return web.Response(
        text=json.dumps({"ok": True}),
        content_type="application/json",
    )


async def library_get_handler(request: web.Request) -> web.Response:
    """GET /library — list past meetings + notes for the new web Library screen.

    Wraps `library_retrieval.list_artifacts` (which the Flet Library tab
    already used). The serialized shape mirrors the LibraryItem dataclass
    field-for-field so the UI can treat the daemon list as the source of
    truth without per-row enrichment calls.
    """
    from meeting_helper.library_retrieval import list_artifacts
    from meeting_helper.config import get_config

    cfg = request.app["config"]
    disk = get_config()
    items = list_artifacts(
        recordings_dir=Path(cfg.recordings_dir), config=disk,
    )
    return web.json_response({"items": [asdict(it) for it in items]})


async def library_reveal_handler(request: web.Request) -> web.Response:
    """POST /library/reveal — open a library file in Finder via `open -R`.

    Body: `{ "filename": "<basename>" }`. The daemon resolves the basename
    against `recordings_dir`; absolute paths and any `..`/separator segments
    are rejected up front so the client API itself can't smuggle paths
    outside the recordings directory. The post-resolve `relative_to` check
    is belt-and-braces in case `expanduser` ever surfaces a surprise.
    """
    try:
        body = await request.json()
    except Exception:
        return web.json_response({"error": "invalid JSON"}, status=400)

    filename = str(body.get("filename", "")).strip()
    if not filename:
        return web.json_response({"error": "filename required"}, status=400)

    # Reject absolute paths and traversal segments. The basename of a real
    # library item never contains a slash.
    if "/" in filename or "\\" in filename or ".." in filename:
        return web.json_response(
            {"error": "filename must be a basename within recordings_dir"},
            status=400,
        )

    cfg = request.app["config"]
    rec_dir = Path(cfg.recordings_dir).expanduser().resolve()
    target = (rec_dir / filename).resolve()
    try:
        target.relative_to(rec_dir)
    except ValueError:
        return web.json_response(
            {"error": "filename resolved outside recordings_dir"},
            status=400,
        )

    if not target.exists():
        return web.json_response({"error": "not found"}, status=404)

    subprocess.run(["open", "-R", str(target)], check=False)
    return web.json_response({"ok": True})


# ---------------------------------------------------------------------------
# Library full feature set — item details, transcribe/summarize, rename,
# delete, favorite, kb, note CRUD, audio stream. Plan 5 — replaces the
# in-process file mutations the Flet Library screen used to do.
# ---------------------------------------------------------------------------

# Read cap for inline file payloads on GET /library/item. 512 KB keeps
# huge transcripts (multi-hour meetings) from blowing the WS-adjacent
# HTTP response budget; the UI shows a "...truncated" marker and the
# user can still reveal the file in Finder.
_LIBRARY_ITEM_READ_LIMIT = 512 * 1024


def _safe_filename(filename: str) -> str:
    """Reject any filename that isn't a bare basename within recordings_dir.

    Mirrors the inline guard in `library_reveal_handler` but raises so the
    handlers below can share one path-traversal check. The post-resolve
    `relative_to` check still happens at each call site after joining
    against `recordings_dir`.
    """
    if not filename or "/" in filename or "\\" in filename or ".." in filename:
        raise ValueError("invalid filename")
    return filename


def _resolve_under_recordings(filename: str, cfg) -> Path:
    """Resolve `filename` against the active recordings_dir or raise ValueError."""
    _safe_filename(filename)
    rec_dir = Path(cfg.recordings_dir).expanduser().resolve()
    target = (rec_dir / filename).resolve()
    try:
        target.relative_to(rec_dir)
    except ValueError as exc:
        raise ValueError("filename resolved outside recordings_dir") from exc
    return target


def _read_capped(path: Path) -> str | None:
    """Read a text file up to `_LIBRARY_ITEM_READ_LIMIT`. Returns None if missing."""
    if not path.is_file():
        return None
    try:
        raw = path.read_text(errors="ignore")
    except OSError:
        return None
    if len(raw) > _LIBRARY_ITEM_READ_LIMIT:
        return raw[:_LIBRARY_ITEM_READ_LIMIT] + "\n...truncated"
    return raw


def _timestamp_prefix(stem: str) -> str:
    """Return '<date>_<HHMMSS>_' if stem starts with that pattern, else ''.

    Mirrors `_timestamp_prefix` from the old Flet library so meeting ids
    keep their leading timestamp when the user types a new label.
    """
    parts = stem.split("_", 2)
    if len(parts) >= 2 and len(parts[0]) == 10 and "-" in parts[0]:
        return f"{parts[0]}_{parts[1]}_"
    return ""


def _slug_for_note(title: str, recordings_dir: Path) -> str:
    """Sanitize `title` to a kebab-case slug. Append -2/-3... on collision.

    Matches the old Flet `_slug_for_note`: non-alphanumeric runs collapse
    to a single hyphen, leading/trailing hyphens are stripped, empty
    fallback is 'note'.
    """
    base = re.sub(r"[^a-zA-Z0-9]+", "-", title.strip().lower()).strip("-") or "note"
    candidate = base
    n = 2
    while (recordings_dir / f"{candidate}.note.md").exists():
        candidate = f"{base}-{n}"
        n += 1
    return candidate


async def library_item_handler(request: web.Request) -> web.Response:
    """GET /library/item?id=<id>&kind=<meeting|note> — full row + file bodies.

    Reads file contents up to `_LIBRARY_ITEM_READ_LIMIT` so the UI can
    render the detail pane without a second roundtrip per file. Larger
    files are truncated with a marker; the user can still reveal/download.
    """
    from meeting_helper.library_retrieval import list_artifacts
    from meeting_helper.config import get_config

    item_id = (request.query.get("id") or "").strip()
    kind = (request.query.get("kind") or "").strip().lower()
    if not item_id:
        return web.json_response({"error": "id required"}, status=400)
    if kind not in ("meeting", "note"):
        return web.json_response({"error": "kind must be meeting or note"}, status=400)

    cfg = request.app["config"]
    rec_dir = Path(cfg.recordings_dir).expanduser().resolve()
    items = list_artifacts(recordings_dir=rec_dir)
    match = next((it for it in items if it.id == item_id and it.kind == kind), None)
    if match is None:
        return web.json_response({"error": "not found"}, status=404)

    disk = get_config()
    payload: dict = {
        "id": match.id,
        "kind": match.kind,
        "title": match.title,
        "date": match.date,
        "summary_filename": match.summary_filename,
        "note_filename": match.note_filename,
        "has_mp3": match.has_mp3,
        "has_live": match.has_live,
        "has_transcript": match.has_transcript,
        "has_summary": match.has_summary,
        "summary_text": None,
        "transcript_text": None,
        "live_text": None,
        "note_body": None,
    }

    if kind == "meeting":
        mp3_name = f"{match.id}.mp3"
        summary_name = f"{match.id}.summary.txt"
        payload["favorited"] = disk.is_favorite(mp3_name)
        payload["in_kb"] = disk.is_kb(summary_name)
        payload["summary_text"] = _read_capped(rec_dir / summary_name)
        payload["transcript_text"] = _read_capped(rec_dir / f"{match.id}.transcript.txt")
        payload["live_text"] = _read_capped(rec_dir / f"{match.id}.live.txt")
    else:
        note_name = match.note_filename
        payload["favorited"] = disk.is_favorite(note_name)
        payload["in_kb"] = disk.is_kb(note_name)
        payload["note_body"] = _read_capped(rec_dir / note_name)

    return web.json_response(payload)


async def library_transcribe_handler(request: web.Request) -> web.Response:
    """POST /library/transcribe — run Whisper on a stored meeting mp3.

    Body: `{"id": "<meeting_id>"}`. Runs `transcribe_audio_file` in a
    thread (it's CPU-bound + sync). Returns the relative transcript filename
    so the UI can refresh the row without re-listing the whole library.
    """
    try:
        body = await request.json()
    except Exception:
        return web.json_response({"error": "invalid JSON"}, status=400)

    item_id = str(body.get("id") or "").strip()
    if not item_id:
        return web.json_response({"error": "id required"}, status=400)

    cfg = request.app["config"]
    try:
        mp3_path = _resolve_under_recordings(f"{item_id}.mp3", cfg)
    except ValueError as exc:
        return web.json_response({"error": str(exc)}, status=400)
    if not mp3_path.is_file():
        return web.json_response({"error": "mp3 not found"}, status=404)

    from meeting_helper.ai.client import transcribe_audio_file
    try:
        await asyncio.to_thread(transcribe_audio_file, str(mp3_path), cfg)
    except Exception as exc:
        logger.warning("library/transcribe failed: %s", exc)
        return web.json_response({"error": str(exc)}, status=500)
    return web.json_response({"ok": True, "transcript_path": f"{item_id}.transcript.txt"})


async def library_summarize_handler(request: web.Request) -> web.Response:
    """POST /library/summarize — Claude-summarize a meeting's transcript.

    Body: `{"id": "<meeting_id>"}`. Prefers `<id>.transcript.txt`; falls
    back to `<id>.live.txt` so meetings whose transcript never ran can
    still summarize from the live captions.
    """
    try:
        body = await request.json()
    except Exception:
        return web.json_response({"error": "invalid JSON"}, status=400)

    item_id = str(body.get("id") or "").strip()
    if not item_id:
        return web.json_response({"error": "id required"}, status=400)

    cfg = request.app["config"]
    try:
        transcript_path = _resolve_under_recordings(f"{item_id}.transcript.txt", cfg)
        live_path = _resolve_under_recordings(f"{item_id}.live.txt", cfg)
    except ValueError as exc:
        return web.json_response({"error": str(exc)}, status=400)

    if transcript_path.is_file():
        source = transcript_path
    elif live_path.is_file():
        source = live_path
    else:
        return web.json_response({"error": "no transcript or live text"}, status=404)

    from meeting_helper.ai.client import summarize_transcript
    try:
        await summarize_transcript(str(source), cfg)
    except Exception as exc:
        logger.warning("library/summarize failed: %s", exc)
        return web.json_response({"error": str(exc)}, status=500)
    return web.json_response({"ok": True, "summary_path": f"{item_id}.summary.txt"})


async def library_rename_handler(request: web.Request) -> web.Response:
    """POST /library/rename — rename a meeting (all sibling files) or note.

    Body: `{"id": "...", "kind": "meeting|note", "new_name": "..."}`. For
    meetings, the leading `<date>_<HHMMSS>_` timestamp prefix is preserved
    and `new_name` becomes the trailing label (spaces → underscores). For
    notes, the title is slugified to kebab-case and appended `.note.md`.
    Workspace KB + favorite entries are migrated under the new filename.
    """
    try:
        body = await request.json()
    except Exception:
        return web.json_response({"error": "invalid JSON"}, status=400)

    item_id = str(body.get("id") or "").strip()
    kind = str(body.get("kind") or "").strip().lower()
    new_name = str(body.get("new_name") or "").strip()
    if not item_id or kind not in ("meeting", "note") or not new_name:
        return web.json_response(
            {"error": "id, kind, and new_name required"}, status=400,
        )

    cfg = request.app["config"]
    rec_dir = Path(cfg.recordings_dir).expanduser().resolve()
    from meeting_helper.config import get_config
    disk = get_config()

    if kind == "meeting":
        try:
            _safe_filename(f"{item_id}.mp3")
        except ValueError as exc:
            return web.json_response({"error": str(exc)}, status=400)
        prefix = _timestamp_prefix(item_id)
        new_label = new_name.replace(" ", "_")
        new_stem = f"{prefix}{new_label}" if prefix else new_label
        # Belt-and-braces: the synthesized stem could include path
        # separators if a caller smuggled them through `new_name`. Reject.
        try:
            _safe_filename(f"{new_stem}.mp3")
        except ValueError as exc:
            return web.json_response({"error": str(exc)}, status=400)

        old_mp3 = rec_dir / f"{item_id}.mp3"
        new_mp3 = rec_dir / f"{new_stem}.mp3"
        if new_mp3.exists() and new_mp3 != old_mp3:
            return web.json_response({"error": "name taken"}, status=409)

        for suffix in (".mp3", ".live.txt", ".transcript.txt", ".summary.txt"):
            src = rec_dir / f"{item_id}{suffix}"
            dst = rec_dir / f"{new_stem}{suffix}"
            if src.is_file():
                src.rename(dst)

        old_summary = f"{item_id}.summary.txt"
        new_summary = f"{new_stem}.summary.txt"
        if disk.is_kb(old_summary):
            disk.remove_kb(old_summary)
            disk.add_kb(new_summary)
        old_mp3_name = f"{item_id}.mp3"
        new_mp3_name = f"{new_stem}.mp3"
        if disk.is_favorite(old_mp3_name):
            disk.remove_favorite(old_mp3_name)
            disk.add_favorite(new_mp3_name)
        disk.save()
        return web.json_response({"ok": True, "new_id": new_stem})

    # kind == "note"
    try:
        _safe_filename(item_id)
    except ValueError as exc:
        return web.json_response({"error": str(exc)}, status=400)
    old_filename = item_id if item_id.endswith(".note.md") else f"{item_id}.note.md"
    try:
        old_path = _resolve_under_recordings(old_filename, cfg)
    except ValueError as exc:
        return web.json_response({"error": str(exc)}, status=400)
    if not old_path.is_file():
        return web.json_response({"error": "note not found"}, status=404)

    slug = _slug_for_note(new_name, rec_dir)
    new_filename = f"{slug}.note.md"
    new_path = rec_dir / new_filename
    if new_path.exists() and new_path != old_path:
        return web.json_response({"error": "name taken"}, status=409)

    old_path.rename(new_path)
    if disk.is_kb(old_filename):
        disk.remove_kb(old_filename)
        disk.add_kb(new_filename)
    if disk.is_favorite(old_filename):
        disk.remove_favorite(old_filename)
        disk.add_favorite(new_filename)
    disk.save()
    return web.json_response({
        "ok": True, "new_id": slug, "new_filename": new_filename,
    })


async def library_delete_handler(request: web.Request) -> web.Response:
    """POST /library/delete — remove a meeting's sibling files or a note.

    Body: `{"id": "...", "kind": "meeting|note", "note_filename"?: "..."}`.
    For meetings, removes mp3 + live.txt + transcript.txt + summary.txt if
    present. For notes, deletes `<note_filename>`. KB + favorite entries
    are cleaned up alongside the files.
    """
    try:
        body = await request.json()
    except Exception:
        return web.json_response({"error": "invalid JSON"}, status=400)

    item_id = str(body.get("id") or "").strip()
    kind = str(body.get("kind") or "").strip().lower()
    if not item_id or kind not in ("meeting", "note"):
        return web.json_response({"error": "id and kind required"}, status=400)

    cfg = request.app["config"]
    rec_dir = Path(cfg.recordings_dir).expanduser().resolve()
    from meeting_helper.config import get_config
    disk = get_config()

    deleted = 0
    if kind == "meeting":
        try:
            _safe_filename(f"{item_id}.mp3")
        except ValueError as exc:
            return web.json_response({"error": str(exc)}, status=400)
        for suffix in (".mp3", ".live.txt", ".transcript.txt", ".summary.txt"):
            p = rec_dir / f"{item_id}{suffix}"
            if p.is_file():
                try:
                    p.unlink()
                    deleted += 1
                except OSError as exc:
                    logger.warning("library/delete: %s failed: %s", p.name, exc)
        summary_name = f"{item_id}.summary.txt"
        mp3_name = f"{item_id}.mp3"
        if disk.is_kb(summary_name):
            disk.remove_kb(summary_name)
        if disk.is_favorite(mp3_name):
            disk.remove_favorite(mp3_name)
        disk.save()
        return web.json_response({"ok": True, "deleted": deleted})

    # kind == "note"
    note_filename = str(body.get("note_filename") or "").strip()
    if not note_filename:
        # Fall back to deriving from the id when the UI didn't supply one.
        note_filename = item_id if item_id.endswith(".note.md") else f"{item_id}.note.md"
    try:
        path = _resolve_under_recordings(note_filename, cfg)
    except ValueError as exc:
        return web.json_response({"error": str(exc)}, status=400)
    if path.is_file():
        try:
            path.unlink()
            deleted = 1
        except OSError as exc:
            logger.warning("library/delete note %s failed: %s", note_filename, exc)
    if disk.is_kb(note_filename):
        disk.remove_kb(note_filename)
    if disk.is_favorite(note_filename):
        disk.remove_favorite(note_filename)
    disk.save()
    return web.json_response({"ok": True, "deleted": deleted})


async def library_favorite_handler(request: web.Request) -> web.Response:
    """POST /library/favorite — toggle the favorites flag on a library item.

    Body: `{"id": "...", "kind": "meeting|note", "value": bool,
    "note_filename"?: "..."}`. The favorite key is `<id>.mp3` for meetings
    or `<note_filename>` (or `<id>.note.md` as fallback) for notes.
    """
    try:
        body = await request.json()
    except Exception:
        return web.json_response({"error": "invalid JSON"}, status=400)

    item_id = str(body.get("id") or "").strip()
    kind = str(body.get("kind") or "").strip().lower()
    if not item_id or kind not in ("meeting", "note"):
        return web.json_response({"error": "id and kind required"}, status=400)
    value = bool(body.get("value", True))

    if kind == "meeting":
        key = f"{item_id}.mp3"
    else:
        note_filename = str(body.get("note_filename") or "").strip()
        if not note_filename:
            note_filename = item_id if item_id.endswith(".note.md") else f"{item_id}.note.md"
        key = note_filename
    try:
        _safe_filename(key)
    except ValueError as exc:
        return web.json_response({"error": str(exc)}, status=400)

    from meeting_helper.config import get_config
    disk = get_config()
    if value:
        disk.add_favorite(key)
    else:
        disk.remove_favorite(key)
    disk.save()
    return web.json_response({"ok": True, "favorited": value})


async def library_kb_handler(request: web.Request) -> web.Response:
    """POST /library/kb — toggle the KB-include flag on a library item.

    Body: `{"id": "...", "kind": "meeting|note", "value": bool,
    "note_filename"?: "..."}`. For meetings the key is `<id>.summary.txt`;
    if `value=true` and the summary file doesn't yet exist we return
    409 so the UI can prompt the user to run `/library/summarize` first
    rather than KB-flagging a file that won't load.
    """
    try:
        body = await request.json()
    except Exception:
        return web.json_response({"error": "invalid JSON"}, status=400)

    item_id = str(body.get("id") or "").strip()
    kind = str(body.get("kind") or "").strip().lower()
    if not item_id or kind not in ("meeting", "note"):
        return web.json_response({"error": "id and kind required"}, status=400)
    value = bool(body.get("value", True))

    cfg = request.app["config"]
    rec_dir = Path(cfg.recordings_dir).expanduser().resolve()
    if kind == "meeting":
        key = f"{item_id}.summary.txt"
        try:
            _safe_filename(key)
        except ValueError as exc:
            return web.json_response({"error": str(exc)}, status=400)
        if value and not (rec_dir / key).is_file():
            return web.json_response(
                {"error": "no summary; run /library/summarize first"}, status=409,
            )
    else:
        note_filename = str(body.get("note_filename") or "").strip()
        if not note_filename:
            note_filename = item_id if item_id.endswith(".note.md") else f"{item_id}.note.md"
        key = note_filename
        try:
            _safe_filename(key)
        except ValueError as exc:
            return web.json_response({"error": str(exc)}, status=400)

    from meeting_helper.config import get_config
    disk = get_config()
    if value:
        disk.add_kb(key)
    else:
        disk.remove_kb(key)
    disk.save()
    return web.json_response({"ok": True, "in_kb": value})


async def library_note_handler(request: web.Request) -> web.Response:
    """POST /library/note — create a new note or update an existing one.

    Two modes (selected by presence of `id` in the body):
    - Create: `{"title": "...", "body": "..."}` → slugs the title via
      `_slug_for_note` (with -2/-3 collision suffix), writes
      `<slug>.note.md` and returns the resulting id/filename.
    - Update: `{"id": "<existing_slug>", "body": "..."}` → overwrites
      `<id>.note.md`. Returns 404 when the file doesn't exist.
    """
    try:
        body = await request.json()
    except Exception:
        return web.json_response({"error": "invalid JSON"}, status=400)

    cfg = request.app["config"]
    rec_dir = Path(cfg.recordings_dir).expanduser().resolve()
    rec_dir.mkdir(parents=True, exist_ok=True)

    existing_id = str(body.get("id") or "").strip()
    note_body = body.get("body")
    if note_body is None:
        return web.json_response({"error": "body required"}, status=400)
    note_body = str(note_body)

    if existing_id:
        filename = existing_id if existing_id.endswith(".note.md") else f"{existing_id}.note.md"
        try:
            path = _resolve_under_recordings(filename, cfg)
        except ValueError as exc:
            return web.json_response({"error": str(exc)}, status=400)
        if not path.is_file():
            return web.json_response({"error": "note not found"}, status=404)
        path.write_text(note_body)
        return web.json_response({"ok": True})

    # Create mode
    title = str(body.get("title") or "").strip()
    if not title:
        return web.json_response({"error": "title required"}, status=400)
    slug = _slug_for_note(title, rec_dir)
    filename = f"{slug}.note.md"
    try:
        path = _resolve_under_recordings(filename, cfg)
    except ValueError as exc:
        return web.json_response({"error": str(exc)}, status=400)
    path.write_text(note_body)
    return web.json_response({"ok": True, "id": slug, "filename": filename})


async def library_text_post_handler(request: web.Request) -> web.Response:
    """POST /library/text — save summary / transcript / live text for a meeting.

    Body: {id: meeting_id, which: "summary"|"transcript"|"live", body: text}
    """
    try:
        body = await request.json()
    except Exception:
        return web.json_response({"error": "invalid JSON"}, status=400)

    item_id = str(body.get("id") or "").strip()
    which = str(body.get("which") or "").strip()
    text = body.get("body", "")

    SUFFIX_BY_KIND = {
        "summary": ".summary.txt",
        "transcript": ".transcript.txt",
        "live": ".live.txt",
    }
    if which not in SUFFIX_BY_KIND:
        return web.json_response(
            {"error": "which must be summary|transcript|live"}, status=400,
        )
    if not item_id:
        return web.json_response({"error": "id required"}, status=400)
    if not isinstance(text, str):
        return web.json_response({"error": "body must be a string"}, status=400)

    cfg = request.app["config"]
    try:
        target = _resolve_under_recordings(f"{item_id}{SUFFIX_BY_KIND[which]}", cfg)
    except ValueError as exc:
        return web.json_response({"error": str(exc)}, status=400)

    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(text)
    return web.json_response({"ok": True, "filename": target.name})


async def library_audio_handler(request: web.Request) -> web.Response:
    """GET /library/audio?id=<id> — stream a meeting mp3 with Range support.

    Returns a `FileResponse` so aiohttp handles HTTP Range requests
    automatically (the web `<audio>` element seeks via Range). Content-Type
    is set explicitly because aiohttp's mimetypes fallback can return
    `application/octet-stream` for unknown systems.
    """
    item_id = (request.query.get("id") or "").strip()
    if not item_id:
        return web.json_response({"error": "id required"}, status=400)
    cfg = request.app["config"]
    try:
        mp3_path = _resolve_under_recordings(f"{item_id}.mp3", cfg)
    except ValueError as exc:
        return web.json_response({"error": str(exc)}, status=400)
    if not mp3_path.is_file():
        return web.json_response({"error": "mp3 not found"}, status=404)
    return web.FileResponse(
        mp3_path,
        headers={"Content-Type": "audio/mpeg"},
    )


async def transcriber_whisper_health_handler(request: web.Request) -> web.Response:
    """GET /transcriber/whisper/health?host=... — proxy-pings a Whisper /health URL.

    Returns {ok: bool, host: str, error?: str}. Used by Settings → Transcription
    to show "● Connected" / "● Not reachable" status next to the host input.
    """
    import urllib.error
    import urllib.request

    host = (request.query.get("host") or "http://localhost:8000").strip().rstrip("/")
    url = f"{host}/health"

    def _check() -> bool:
        with urllib.request.urlopen(url, timeout=3) as resp:
            return resp.status == 200

    try:
        # Block in a thread so we don't tie up the event loop with a sync open.
        ok = await asyncio.to_thread(_check)
        return web.json_response({"ok": ok, "host": host})
    except (urllib.error.URLError, OSError, TimeoutError) as exc:
        return web.json_response({"ok": False, "host": host, "error": str(exc)})


async def transcriber_ollama_health_handler(request: web.Request) -> web.Response:
    """GET /transcriber/ollama/health?host=... — proxy-pings Ollama via /api/tags.

    Returns {ok: bool, host: str, error?: str}. Used by Settings → Local model
    to show "● Connected" / "● Not reachable" status next to the host input.
    Mirrors the old Flet `_check_ollama_connection` behavior.
    """
    import urllib.error
    import urllib.request

    host = (request.query.get("host") or "http://localhost:11434").strip().rstrip("/")
    url = f"{host}/api/tags"

    def _check() -> bool:
        with urllib.request.urlopen(url, timeout=3) as resp:
            return resp.status == 200

    try:
        ok = await asyncio.to_thread(_check)
        return web.json_response({"ok": ok, "host": host})
    except (urllib.error.URLError, OSError, TimeoutError) as exc:
        return web.json_response({"ok": False, "host": host, "error": str(exc)})


async def ollama_models_handler(request: web.Request) -> web.Response:
    """GET /ollama/models?host=... — proxies Ollama's /api/tags and returns
    just the installed model names. Used by Settings → Local model to surface
    the currently-installed models in a dropdown instead of a free-text field.

    Returns {ok: bool, host: str, models: list[str], error?: str}.
    """
    import urllib.error
    import urllib.request

    host = (request.query.get("host") or "http://localhost:11434").strip().rstrip("/")
    url = f"{host}/api/tags"

    def _fetch() -> list[str]:
        with urllib.request.urlopen(url, timeout=3) as resp:
            payload = json.loads(resp.read().decode("utf-8"))
        models = payload.get("models") or []
        # Ollama returns objects like `{"name": "qwen2.5-coder:3b", ...}`.
        # Surface just the names for the dropdown.
        names: list[str] = []
        for m in models:
            name = (m or {}).get("name") if isinstance(m, dict) else None
            if isinstance(name, str) and name:
                names.append(name)
        return names

    try:
        names = await asyncio.to_thread(_fetch)
        return web.json_response({"ok": True, "host": host, "models": names})
    except (urllib.error.URLError, OSError, TimeoutError, ValueError) as exc:
        return web.json_response(
            {"ok": False, "host": host, "models": [], "error": str(exc)},
        )


def setup_routes(app: web.Application) -> None:
    app.router.add_get("/health", health_handler)
    app.router.add_get(
        "/transcriber/whisper/health",
        transcriber_whisper_health_handler,
    )
    app.router.add_get(
        "/transcriber/ollama/health",
        transcriber_ollama_health_handler,
    )
    app.router.add_get("/ollama/models", ollama_models_handler)
    app.router.add_get("/config", config_get_handler)
    app.router.add_post("/config", config_post_handler)
    app.router.add_get("/transcript", transcript_handler_get)
    app.router.add_post("/transcript/clear", transcript_clear_handler)
    app.router.add_get("/last_response", last_response_handler)
    app.router.add_get("/last_cards", last_cards_handler)
    app.router.add_get("/current_topic", current_topic_handler)
    app.router.add_get("/topics", topics_handler)
    app.router.add_post("/topic/set", topic_set_handler)
    app.router.add_post("/topic/auto", topic_auto_handler)
    app.router.add_post("/topic/manual", topic_manual_handler)
    app.router.add_post("/hot_moment/cancel", hot_moment_cancel_handler)
    app.router.add_post("/query", query_handler)
    app.router.add_post("/query/trigger", trigger_query_handler)
    app.router.add_post("/transcribe", transcribe_handler)
    app.router.add_post("/summarize", summarize_handler)
    app.router.add_post("/extract-task", extract_task_handler)
    app.router.add_get("/tasks", tasks_get_handler)
    app.router.add_post("/brief", brief_handler)
    app.router.add_post("/debug/say", debug_say_handler)
    app.router.add_get("/conversations", conversations_handler)
    app.router.add_post("/conversation/attach", conversation_attach_handler)
    app.router.add_post("/conversation/detach", conversation_detach_handler)
    app.router.add_post("/proactive", proactive_handler)
    app.router.add_get("/proactive", proactive_status_handler)
    app.router.add_post("/session/start", session_start_handler)
    app.router.add_post("/session/stop", session_stop_handler)
    app.router.add_get("/provider", provider_get_handler)
    app.router.add_post("/provider", provider_post_handler)
    app.router.add_get("/workspace", workspace_handler)
    app.router.add_get("/workspaces", workspaces_handler)
    app.router.add_post("/workspace/activate", workspace_activate_handler)
    app.router.add_post("/workspace/create", workspace_create_handler)
    app.router.add_post("/workspace/rename", workspace_rename_handler)
    app.router.add_post("/workspace/delete", workspace_delete_handler)
    app.router.add_get("/version", version_handler)
    app.router.add_post("/daemon/restart", daemon_restart_handler)
    app.router.add_get("/logs/tail", logs_tail_handler)
    app.router.add_get("/launcher.command", launcher_command_handler)
    app.router.add_post("/install-app", install_app_handler)
    app.router.add_get("/install-app/status", install_app_status_handler)
    app.router.add_post("/shutdown", shutdown_handler)
    app.router.add_get("/library", library_get_handler)
    app.router.add_post("/library/reveal", library_reveal_handler)
    app.router.add_get("/library/item", library_item_handler)
    app.router.add_post("/library/transcribe", library_transcribe_handler)
    app.router.add_post("/library/summarize", library_summarize_handler)
    app.router.add_post("/library/rename", library_rename_handler)
    app.router.add_post("/library/delete", library_delete_handler)
    app.router.add_post("/library/favorite", library_favorite_handler)
    app.router.add_post("/library/kb", library_kb_handler)
    app.router.add_post("/library/note", library_note_handler)
    app.router.add_post("/library/text", library_text_post_handler)
    app.router.add_get("/library/audio", library_audio_handler)
    app.router.add_get("/ws", ws_handler)
