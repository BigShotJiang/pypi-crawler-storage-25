"""aiohttp application factory."""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

from aiohttp import web

from meeting_helper.server.routes import setup_routes

if TYPE_CHECKING:
    from meeting_helper.config import AppConfig


WEB_DIST = Path(__file__).resolve().parent.parent / "web" / "dist"


def create_app(config: "AppConfig") -> web.Application:
    app = web.Application()
    app["config"] = config
    setup_routes(app)
    _setup_static(app)
    return app


def _setup_static(app: web.Application) -> None:
    """Mount the Next.js bundle at `/` and add an SPA fallback.

    Must run AFTER `setup_routes(app)` so API routes win over the static
    catch-all. The fallback returns `index.html` for any unknown GET that
    accepts text/html, so client-side routes (e.g. /settings/providers)
    resolve on hard refresh.

    A single catch-all handler is used instead of `add_static` + a separate
    fallback route because aiohttp's `add_static` returns a 404 itself on
    file-miss — it does NOT fall through to subsequently registered routes.
    Combining both behaviors into one handler lets us serve real bundle
    assets, return index.html for unknown HTML routes, and 404 cleanly for
    everything else (e.g. JSON API misses).
    """
    if not WEB_DIST.exists():
        # Source checkout without a built bundle — skip static registration
        # entirely so the daemon still serves the API. Plan 2's release
        # script ensures the bundle is present in published wheels.
        return

    index_path = WEB_DIST / "index.html"
    web_dist_resolved = WEB_DIST.resolve()

    async def index_handler(_: web.Request) -> web.StreamResponse:
        return web.FileResponse(index_path)

    async def static_or_spa_fallback(request: web.Request) -> web.StreamResponse:
        # Strip leading slash to get path relative to web/dist.
        rel = request.match_info.get("tail", "").lstrip("/")
        candidate = (web_dist_resolved / rel).resolve() if rel else web_dist_resolved
        # Defend against `..` traversal: candidate must stay inside web_dist.
        try:
            candidate.relative_to(web_dist_resolved)
        except ValueError:
            raise web.HTTPNotFound()
        if rel and candidate.is_file():
            return web.FileResponse(candidate)
        # Directory match: Next's static export with `trailingSlash: true`
        # emits `<route>/index.html`, so serve that when the path resolves
        # to a directory with an `index.html` inside. This makes
        # `/settings/ai` and `/settings/ai/` both load the AI tab on hard
        # refresh, instead of falling back to the root SPA shell.
        if candidate.is_dir():
            dir_index = candidate / "index.html"
            if dir_index.is_file():
                return web.FileResponse(dir_index)
        # No matching file — SPA fallback only for HTML navigations.
        accept = request.headers.get("Accept", "")
        if "text/html" in accept:
            return web.FileResponse(index_path)
        raise web.HTTPNotFound()

    # Root handler explicitly serves index.html — handled separately from the
    # catch-all so a bare "/" request never depends on the Accept header.
    app.router.add_get("/", index_handler)
    # Catch-all GET for everything else under "/". API routes registered by
    # `setup_routes` are tried first because they were registered earlier.
    app.router.add_get("/{tail:.*}", static_or_spa_fallback)
