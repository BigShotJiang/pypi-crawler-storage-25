"""Static assets for the new web-based UI.

The contents of `web/dist/` are produced by the Next.js build (Plan 2+).
This package is intentionally code-free — it only ships static files via
setuptools `package-data`.
"""
