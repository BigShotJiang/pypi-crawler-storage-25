"""Force-stop helper for the meeting-helper daemon.

Used by both the Flet GUI Stop button and the macOS menubar Stop action.
The user explicitly asked: when I hit Stop, kill the daemon if it's wedged
and bring up a fresh one — don't leave a zombie session running.

Flow:
1. Try POST /session/stop with a short timeout. Most of the time this is
   sufficient; the daemon's session loop tears down and respawns itself.
2. Wait briefly. If the daemon process is still alive AND not making
   progress, SIGTERM it.
3. If still alive after another grace, SIGKILL.
4. Spawn a fresh daemon via the `meeting-helper start` CLI.

This replaces the previous per-caller pattern of "POST /session/stop and
hope" — which left users staring at a stuck UI when the daemon was
wedged on a slow MCP, a half-dead Deepgram WS, or a stuck PyObjC SCK
callback.
"""

from __future__ import annotations

import logging
import os
import signal
import subprocess
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path
from typing import Optional

from meeting_helper.config import PID_FILE

logger = logging.getLogger(__name__)


def _read_daemon_pid() -> Optional[int]:
    try:
        return int(PID_FILE.read_text().strip())
    except (FileNotFoundError, ValueError, OSError) as exc:
        logger.debug("force_stop: pid read failed: %s", exc)
        return None


def _process_alive(pid: int) -> bool:
    """Return True if the process exists. `os.kill(pid, 0)` raises
    ProcessLookupError if it doesn't and PermissionError if we can't signal
    it — both are answers we can act on."""
    try:
        os.kill(pid, 0)
        return True
    except ProcessLookupError:
        return False
    except PermissionError:
        # Process exists but we can't signal it — treat as alive so we
        # don't try to "spawn a fresh daemon" alongside it.
        return True
    except Exception as exc:
        logger.warning("force_stop: process_alive(%d) check failed: %s", pid, exc)
        return False


def _cli_path() -> str:
    """Find the meeting-helper CLI binary. Mirrors the pattern in
    flet_gui/app.py:_cli_path so we behave consistently across both
    callers."""
    import shutil
    p = Path(sys.executable).parent / "meeting-helper"
    if p.exists():
        return str(p)
    return shutil.which("meeting-helper") or "meeting-helper"


def _try_graceful_stop(port: int, timeout: float = 3.0) -> bool:
    """POST /session/stop. Returns True if it returned 2xx, False on
    error or timeout. Either result still continues to the kill path —
    the graceful attempt is best-effort."""
    try:
        req = urllib.request.Request(
            f"http://127.0.0.1:{port}/session/stop",
            data=b"{}",
            headers={"Content-Type": "application/json"},
        )
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            ok = 200 <= resp.status < 300
            logger.info("force_stop: graceful /session/stop returned %d", resp.status)
            return ok
    except urllib.error.HTTPError as exc:
        logger.warning("force_stop: graceful /session/stop HTTP %d", exc.code)
        return False
    except Exception as exc:
        logger.warning("force_stop: graceful /session/stop failed: %s", exc)
        return False


def _kill_daemon(pid: int) -> None:
    """SIGTERM, wait, SIGKILL escalation. Best-effort — exceptions logged
    not raised so the caller's flow always continues to the respawn step."""
    try:
        logger.warning("force_stop: SIGTERM daemon pid=%d", pid)
        os.kill(pid, signal.SIGTERM)
    except ProcessLookupError:
        return  # already dead
    except Exception as exc:
        logger.warning("force_stop: SIGTERM(%d) failed: %s", pid, exc)
        return

    # Wait up to 2 s for graceful exit on SIGTERM.
    for _ in range(20):
        if not _process_alive(pid):
            logger.info("force_stop: daemon pid=%d exited on SIGTERM", pid)
            return
        time.sleep(0.1)

    # Escalate.
    try:
        logger.warning("force_stop: SIGKILL daemon pid=%d (didn't exit on SIGTERM)", pid)
        os.kill(pid, signal.SIGKILL)
    except ProcessLookupError:
        return
    except Exception as exc:
        logger.warning("force_stop: SIGKILL(%d) failed: %s", pid, exc)
        return

    # Brief grace for the OS to reap.
    for _ in range(10):
        if not _process_alive(pid):
            return
        time.sleep(0.1)
    logger.error("force_stop: daemon pid=%d still alive after SIGKILL", pid)


def _spawn_fresh_daemon() -> None:
    """Start a new daemon via the CLI. Detached so this caller doesn't
    own its lifecycle."""
    cli = _cli_path()
    try:
        subprocess.Popen(
            [cli, "start"],
            start_new_session=True,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            stdin=subprocess.DEVNULL,
        )
        logger.info("force_stop: spawned fresh daemon via %s start", cli)
    except Exception as exc:
        logger.error("force_stop: spawn fresh daemon failed: %s", exc)


def force_stop_session(port: int, *, kill_grace_sec: float = 2.0) -> None:
    """Stop the current session, force-kill if wedged, then spawn a fresh
    daemon. Safe to call when no session is active — the kill path is a
    no-op if the daemon is already gone, and the spawn step ensures we
    have a fresh one regardless.

    This runs synchronously and can take ~5-7 s in the worst case
    (3 s POST + 2 s SIGTERM grace + 1 s SIGKILL grace). Callers should
    invoke it from a worker thread, not the asyncio loop or the UI thread.
    """
    logger.info("force_stop: requested for port=%d", port)

    # 1. Try the graceful shutdown. If it succeeds and the daemon
    #    naturally respawns (session.py:_restart_daemon does this on a
    #    clean session end), we may not even need to kill anything.
    graceful_ok = _try_graceful_stop(port)

    # 2. Brief grace for the daemon's own respawn pattern. If it's
    #    healthy it should have started exiting by now.
    time.sleep(kill_grace_sec)

    # 3. Read the (possibly-new) pid and decide if a force-kill is needed.
    pid = _read_daemon_pid()
    if pid is None:
        logger.info("force_stop: no pid file — assume daemon already gone")
    elif not _process_alive(pid):
        logger.info("force_stop: daemon pid=%d already exited (graceful=%s)",
                    pid, graceful_ok)
    else:
        # Daemon still alive after the grace. If graceful succeeded but
        # the daemon hasn't respawned yet, this is just slow shutdown —
        # but waiting more risks the user thinking nothing happened.
        # SIGTERM-then-SIGKILL escalation handles both "wedged" and
        # "graceful but slow" cases.
        _kill_daemon(pid)

    # 4. Always spawn a fresh daemon so the user lands on a clean state
    #    when they hit Stop. Idempotent — if a fresh daemon is already
    #    coming up via the graceful-respawn path, the second one will
    #    fail to bind the port and exit harmlessly.
    _spawn_fresh_daemon()
    logger.info("force_stop: complete")
