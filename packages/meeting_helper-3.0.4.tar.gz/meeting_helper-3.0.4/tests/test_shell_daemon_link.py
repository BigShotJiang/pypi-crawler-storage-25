"""Tests for shell.daemon_link — URL resolution + health-check polling."""

from __future__ import annotations

import asyncio
from unittest.mock import patch

import pytest

from meeting_helper.shell import daemon_link


def test_resolve_url_uses_config_port():
    """resolve_url returns http://127.0.0.1:<port>/ from the config."""

    class _Cfg:
        port = 8765

    assert daemon_link.resolve_url(_Cfg()) == "http://127.0.0.1:8765/"


async def test_wait_for_health_returns_true_when_daemon_responds(aiohttp_client):
    """wait_for_health polls /health and returns True on first success."""
    from aiohttp import web

    async def health(_: web.Request) -> web.Response:
        return web.json_response({"ok": True})

    app = web.Application()
    app.router.add_get("/health", health)
    client = await aiohttp_client(app)
    base = str(client.make_url("/"))

    ok = await daemon_link.wait_for_health(
        base_url=base, timeout=1.0, interval=0.05
    )
    assert ok is True


async def test_wait_for_health_times_out_when_unreachable():
    """wait_for_health returns False after `timeout` seconds with no response."""
    # Port 1 is reliably refused on macOS — no server can bind there.
    ok = await daemon_link.wait_for_health(
        base_url="http://127.0.0.1:1/", timeout=0.2, interval=0.05
    )
    assert ok is False
