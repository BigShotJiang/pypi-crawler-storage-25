"""Tests for Config.provider_configured: must reflect workspace intent, not env vars."""

from __future__ import annotations

import os
import json
from unittest.mock import patch

from meeting_helper.config import Config


def test_provider_configured_false_when_workspace_empty_even_if_env_set(tmp_path):
    """Env vars must NOT make provider_configured True for visibility purposes."""
    cfg_path = tmp_path / "config.json"
    cfg_path.write_text(json.dumps({
        "anthropic_api_key": "",
        "google_api_key": "",
    }))
    with patch.dict(os.environ, {"ANTHROPIC_API_KEY": "sk-real-key", "GOOGLE_API_KEY": "real-key"}):
        cfg = Config(cfg_path)
        # API key getters DO see the env-var fallback (runtime path):
        assert cfg.anthropic_api_key == "sk-real-key"
        # But provider_configured stays False because the workspace itself is empty:
        assert cfg.provider_configured is False


def test_provider_configured_true_when_workspace_has_key(tmp_path):
    cfg_path = tmp_path / "config.json"
    cfg_path.write_text(json.dumps({
        "anthropic_api_key": "sk-workspace-key",
    }))
    cfg = Config(cfg_path)
    assert cfg.provider_configured is True


def test_provider_configured_true_for_explicit_local(tmp_path):
    cfg_path = tmp_path / "config.json"
    cfg_path.write_text(json.dumps({
        "anthropic_api_key": "",
        "preferred_provider": "local",
    }))
    cfg = Config(cfg_path)
    assert cfg.provider_configured is True
