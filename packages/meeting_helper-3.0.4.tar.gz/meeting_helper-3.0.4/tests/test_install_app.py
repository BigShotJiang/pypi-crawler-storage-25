"""Tests for ensure_app_bundle_installed() — one-time first-launch install.

These tests must NEVER touch the real ~/Applications or ~/.config dirs:
- DEFAULT_CONFIG_DIR is monkeypatched to a tmp_path.
- install_to_applications is mocked so no actual .app is written.
"""

from __future__ import annotations

from pathlib import Path
from unittest.mock import patch

import pytest

from meeting_helper import install_app


@pytest.fixture
def fake_config_dir(tmp_path, monkeypatch):
    """Redirect the marker location to a tmp dir for the duration of the test."""
    cfg_dir = tmp_path / "config"
    cfg_dir.mkdir()
    import meeting_helper.config as cfg_module
    monkeypatch.setattr(cfg_module, "DEFAULT_CONFIG_DIR", cfg_dir)
    return cfg_dir


def test_installs_when_marker_missing(fake_config_dir, tmp_path):
    """First call with no marker installs the bundle and writes the marker."""
    fake_dest = tmp_path / "Applications" / "Meeting Helper.app"

    with patch.object(install_app, "install_to_applications", return_value=fake_dest) as install:
        result = install_app.ensure_app_bundle_installed()

    install.assert_called_once_with(system=False)
    assert result == fake_dest

    marker = fake_config_dir / install_app.APP_INSTALLED_MARKER_FILENAME
    assert marker.exists()
    # Marker should contain the version string so future migrations can
    # detect "installed by v3.x".
    from meeting_helper import __version__
    assert marker.read_text() == __version__


def test_noop_when_marker_exists(fake_config_dir, tmp_path):
    """Second call (marker present) returns None and does NOT reinstall."""
    marker = fake_config_dir / install_app.APP_INSTALLED_MARKER_FILENAME
    marker.write_text("3.0.0")

    with patch.object(install_app, "install_to_applications") as install:
        result = install_app.ensure_app_bundle_installed()

    install.assert_not_called()
    assert result is None


def test_noop_when_marker_exists_but_bundle_removed(fake_config_dir, tmp_path):
    """Respect user-uninstall: marker present + no bundle => still no-op."""
    marker = fake_config_dir / install_app.APP_INSTALLED_MARKER_FILENAME
    marker.write_text("3.0.0")
    # No bundle anywhere — the user deleted it. We must not recreate it.

    with patch.object(install_app, "install_to_applications") as install:
        result = install_app.ensure_app_bundle_installed()

    install.assert_not_called()
    assert result is None


def test_install_failure_returns_none_and_marker_not_written(fake_config_dir):
    """If install_to_applications raises, return None and don't write the marker."""
    with patch.object(
        install_app, "install_to_applications", side_effect=PermissionError("nope")
    ):
        result = install_app.ensure_app_bundle_installed()

    assert result is None
    marker = fake_config_dir / install_app.APP_INSTALLED_MARKER_FILENAME
    assert not marker.exists()


def test_marker_write_failure_does_not_crash(fake_config_dir, tmp_path):
    """If install succeeded but marker write fails, return the dest and don't crash."""
    fake_dest = tmp_path / "Applications" / "Meeting Helper.app"

    with patch.object(install_app, "install_to_applications", return_value=fake_dest), \
         patch.object(Path, "write_text", side_effect=OSError("readonly fs")):
        result = install_app.ensure_app_bundle_installed()

    # Install succeeded — we return the dest even though the marker failed.
    assert result == fake_dest


def test_config_opt_out_skips_install(fake_config_dir):
    """`auto_install_app: false` in workspace config disables the auto-install."""
    from meeting_helper.config import get_config
    cfg = get_config()
    original = cfg._data.get("auto_install_app", True)
    cfg._data["auto_install_app"] = False
    try:
        with patch.object(install_app, "install_to_applications") as install:
            result = install_app.ensure_app_bundle_installed()
        install.assert_not_called()
        assert result is None
        # Marker must NOT be written when opted out — so a later opt-in
        # (config flip back to true) will still trigger the install.
        marker = fake_config_dir / install_app.APP_INSTALLED_MARKER_FILENAME
        assert not marker.exists()
    finally:
        cfg._data["auto_install_app"] = original


def test_marker_path_uses_default_config_dir(fake_config_dir):
    """Sanity: _marker_path() points inside the (monkeypatched) DEFAULT_CONFIG_DIR."""
    assert install_app._marker_path().parent == fake_config_dir
    assert install_app._marker_path().name == install_app.APP_INSTALLED_MARKER_FILENAME
