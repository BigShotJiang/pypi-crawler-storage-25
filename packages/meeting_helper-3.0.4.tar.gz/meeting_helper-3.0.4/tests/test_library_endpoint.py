"""Tests for /library and /library/reveal daemon endpoints.

These endpoints back the new Next.js Library screen (Plan 4). The list
endpoint serializes the existing `library_retrieval.list_artifacts` output
into a JSON shape the UI consumes; the reveal endpoint shells out to
`open -R` so the user can jump from a library row to the file in Finder.

The reveal handler is constrained to paths under `recordings_dir` —
without that guard, a curl-able daemon endpoint could open arbitrary
paths in Finder for any client on localhost.
"""

from __future__ import annotations

from pathlib import Path
from unittest.mock import patch

import pytest

from meeting_helper.config import AppConfig
from meeting_helper.server.app import create_app


@pytest.fixture
async def app_client(aiohttp_client, tmp_path: Path):
    cfg = AppConfig()
    cfg.recordings_dir = tmp_path
    app = create_app(cfg)
    return await aiohttp_client(app)


async def test_library_get_returns_empty_for_empty_dir(app_client):
    resp = await app_client.get("/library")
    assert resp.status == 200
    body = await resp.json()
    assert body == {"items": []}


async def test_library_get_serializes_artifacts(app_client, tmp_path: Path):
    # Create a fake meeting mp3 + summary so list_artifacts has something to
    # surface. `library_retrieval.list_artifacts` keys off .mp3 presence and
    # looks for the adjacent .summary.txt file.
    (tmp_path / "2026-05-14_100000_test-meeting.mp3").write_bytes(b"\x00" * 8)
    (tmp_path / "2026-05-14_100000_test-meeting.summary.txt").write_text("# Test summary")

    resp = await app_client.get("/library")
    assert resp.status == 200
    body = await resp.json()
    assert isinstance(body["items"], list)
    assert len(body["items"]) >= 1
    item = body["items"][0]
    # Required fields the UI consumes:
    for key in ("id", "kind", "title", "date", "sort_key"):
        assert key in item, f"library item missing {key}: {item!r}"
    # Meeting-specific affordance flags must also round-trip so the UI
    # knows which files exist alongside the mp3.
    for key in ("has_mp3", "has_live", "has_transcript", "has_summary",
                "summary_filename", "note_filename",
                "favorited", "in_kb"):
        assert key in item, f"library item missing {key}: {item!r}"
    assert item["kind"] == "meeting"
    assert item["has_mp3"] is True
    assert item["has_summary"] is True


async def test_library_reveal_calls_open_R(app_client, tmp_path: Path):
    f = tmp_path / "demo.mp3"
    f.write_bytes(b"\x00" * 8)
    with patch("subprocess.run") as run_mock:
        resp = await app_client.post(
            "/library/reveal", json={"filename": "demo.mp3"}
        )
        assert resp.status == 200
        run_mock.assert_called_once()
        called_args = run_mock.call_args.args[0]
        assert called_args[0] == "open"
        assert called_args[1] == "-R"
        assert called_args[2] == str(f.resolve())


async def test_library_reveal_rejects_filename_with_slash(app_client):
    """Path-traversal guard — refuse anything but a basename."""
    resp = await app_client.post(
        "/library/reveal", json={"filename": "../../etc/passwd"}
    )
    assert resp.status == 400


async def test_library_reveal_404_for_missing_file(app_client):
    resp = await app_client.post(
        "/library/reveal", json={"filename": "nonexistent.mp3"}
    )
    assert resp.status == 404
