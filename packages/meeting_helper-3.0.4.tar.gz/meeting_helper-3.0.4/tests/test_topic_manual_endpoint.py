"""Regression tests for the new /topic/manual and /hot_moment/cancel endpoints."""

from __future__ import annotations

import time as _time
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from aiohttp import web


@pytest.fixture(autouse=True)
def _reset_global_state():
    """Reset shared module-level state between tests so a stale flag from
    a previous test can't bleed into the next one."""
    from meeting_helper.state import state as global_state
    yield
    global_state.topic_manual_mode = False
    global_state.current_topic_cards = []
    global_state.current_topic = {}
    global_state.last_cards = []
    global_state.local_todo = None
    global_state.hot_moment_until = 0.0


def _make_app() -> web.Application:
    """Construct a minimal aiohttp app with the topic routes wired up."""
    from meeting_helper.server.routes import setup_routes

    class FakeConfig:
        anthropic_api_key = "x"
        hot_moment_window_minutes = 5

    app = web.Application()
    app["config"] = FakeConfig()
    setup_routes(app)
    return app


@pytest.mark.asyncio
async def test_topic_manual_handler_flips_flag(aiohttp_client):
    """POST /topic/manual must flip topic_manual_mode to True without
    touching the currently-displayed topic."""
    from meeting_helper.state import state as global_state

    global_state.topic_manual_mode = False
    # Pre-populate a topic to confirm we DON'T clear it.
    global_state.current_topic = {"topic": "keep me", "ticket_ids": ["42"]}
    global_state.current_topic_cards = [{"id": "42"}]

    client = await aiohttp_client(_make_app())
    with patch("meeting_helper.server.websocket.broadcast", new=AsyncMock()):
        resp = await client.post("/topic/manual", json={})

    assert resp.status == 200
    body = await resp.json()
    assert body == {"ok": True}
    assert global_state.topic_manual_mode is True
    # Existing topic is preserved — only the mode flag flips.
    assert global_state.current_topic == {"topic": "keep me", "ticket_ids": ["42"]}
    assert global_state.current_topic_cards == [{"id": "42"}]


@pytest.mark.asyncio
async def test_topic_manual_is_idempotent(aiohttp_client):
    """Calling /topic/manual twice in a row is a no-op the second time."""
    from meeting_helper.state import state as global_state

    global_state.topic_manual_mode = False

    client = await aiohttp_client(_make_app())
    with patch("meeting_helper.server.websocket.broadcast", new=AsyncMock()):
        resp1 = await client.post("/topic/manual", json={})
        resp2 = await client.post("/topic/manual", json={})

    assert resp1.status == 200
    assert resp2.status == 200
    assert global_state.topic_manual_mode is True


@pytest.mark.asyncio
async def test_hot_moment_cancel_handler_clears(aiohttp_client):
    """POST /hot_moment/cancel must zero out hot_moment_until."""
    from meeting_helper.state import state as global_state

    global_state.hot_moment_until = _time.monotonic() + 600

    client = await aiohttp_client(_make_app())
    with patch("meeting_helper.server.websocket.broadcast", new=AsyncMock()):
        resp = await client.post("/hot_moment/cancel", json={})

    assert resp.status == 200
    body = await resp.json()
    assert body == {"ok": True}
    assert global_state.hot_moment_until == 0.0
    assert global_state.is_hot_moment() is False


@pytest.mark.asyncio
async def test_hot_moment_cancel_is_idempotent(aiohttp_client):
    """Cancelling when already idle must not error."""
    from meeting_helper.state import state as global_state

    global_state.hot_moment_until = 0.0

    client = await aiohttp_client(_make_app())
    with patch("meeting_helper.server.websocket.broadcast", new=AsyncMock()):
        resp = await client.post("/hot_moment/cancel", json={})

    assert resp.status == 200
    assert global_state.hot_moment_until == 0.0


@pytest.mark.asyncio
async def test_topic_manual_handler_direct():
    """Direct call (no aiohttp client) — confirms the symbol is importable
    and behaves correctly when invoked with a bare request."""
    from meeting_helper.server.routes import topic_manual_handler
    from meeting_helper.state import state as global_state

    global_state.topic_manual_mode = False
    fake_request = MagicMock()
    with patch("meeting_helper.server.websocket.broadcast", new=AsyncMock()):
        resp = await topic_manual_handler(fake_request)
    assert global_state.topic_manual_mode is True
    assert resp.status == 200


@pytest.mark.asyncio
async def test_hot_moment_cancel_handler_direct():
    """Direct call — confirms the symbol is importable."""
    from meeting_helper.server.routes import hot_moment_cancel_handler
    from meeting_helper.state import state as global_state

    global_state.hot_moment_until = _time.monotonic() + 600
    fake_request = MagicMock()
    with patch("meeting_helper.server.websocket.broadcast", new=AsyncMock()):
        resp = await hot_moment_cancel_handler(fake_request)
    assert global_state.hot_moment_until == 0.0
    assert resp.status == 200
