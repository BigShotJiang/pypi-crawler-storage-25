"""/health must expose AI-call age, active-query age, loop lag, CPU, memory."""

from __future__ import annotations

import json
import time

import pytest
from aiohttp import web
from aiohttp.test_utils import make_mocked_request

from meeting_helper.server.routes import health_handler
from meeting_helper.state import state as global_state


@pytest.mark.asyncio
async def test_health_payload_shape(monkeypatch):
    # Seed state.
    global_state.last_ai_call_at = 0.0
    global_state.last_ai_call_kind = ""
    global_state.active_query = None
    global_state.active_query_started_at = 0.0
    global_state.proc_cpu_percent = 12.5
    global_state.host_cpu_percent = 40.0
    global_state.proc_rss_mb = 321.0
    global_state.event_loop_lag_ms = 8.0

    req = make_mocked_request("GET", "/health")
    resp = await health_handler(req)
    data = json.loads(resp.text)

    assert data["status"] == "ok"
    assert "health" in data
    h = data["health"]
    assert h["last_ai_call_at"] is None       # 0.0 → null
    assert h["last_ai_call_kind"] == ""
    assert h["last_ai_call_age_sec"] is None
    assert h["active_query"] is False
    assert h["active_query_age_sec"] is None
    assert h["event_loop_lag_ms"] == 8.0
    assert h["cpu_percent"] == 12.5
    assert h["host_cpu_percent"] == 40.0
    assert h["rss_mb"] == 321.0

    # Now simulate a call + an in-flight query.
    global_state.last_ai_call_at = time.time() - 3
    global_state.last_ai_call_kind = "query"
    global_state.active_query_started_at = time.time() - 5
    class _T:  # fake task that isn't done
        def done(self): return False
    global_state.active_query = _T()
    resp = await health_handler(make_mocked_request("GET", "/health"))
    h = json.loads(resp.text)["health"]
    assert h["last_ai_call_kind"] == "query"
    assert 2 <= h["last_ai_call_age_sec"] <= 6
    assert h["active_query"] is True
    assert 4 <= h["active_query_age_sec"] <= 7
    global_state.active_query = None  # cleanup for other tests
