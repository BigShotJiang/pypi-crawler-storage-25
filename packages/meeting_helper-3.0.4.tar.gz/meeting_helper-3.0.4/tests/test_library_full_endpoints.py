"""Tests for the full Library backend (Plan 5).

These endpoints back the new Next.js Library screen — item details,
transcribe/summarize, rename/delete, favorite/KB toggles, note CRUD,
and audio streaming. They mutate the workspace JSON (KB list + favorites)
and the recordings directory, so the fixture below points every
config-module global at a tmp dir and resets the `_config` cache before
each test. Without this isolation, a single test could re-pollute the
real workspace JSON (this is the bug `test_config_post_extended.py`
hit earlier on this branch — see commit `3e63db6`).
"""

from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import patch

import pytest

from meeting_helper import config as config_mod
from meeting_helper.config import AppConfig
from meeting_helper.server.app import create_app


@pytest.fixture
def isolated_workspace(tmp_path, monkeypatch):
    """Point Config at a tmp workspace dir and reset its cache.

    Same pattern as `test_workspaces_endpoint.py` / `test_config_post_persistence.py`.
    Mutating the cached global between tests would otherwise let one test's
    KB additions leak into the next (or worse: the user's real workspace).
    """
    ws_dir = tmp_path / "workspaces"
    ws_dir.mkdir(parents=True, exist_ok=True)
    (ws_dir / "default.json").write_text(json.dumps({}))
    (tmp_path / "state.json").write_text(json.dumps({
        "active_workspace": "default",
        "workspace_order": ["default"],
    }))
    monkeypatch.setattr(config_mod, "DEFAULT_CONFIG_DIR", tmp_path)
    monkeypatch.setattr(config_mod, "WORKSPACES_DIR", ws_dir)
    monkeypatch.setattr(config_mod, "STATE_FILE", tmp_path / "state.json")
    monkeypatch.setattr(
        config_mod, "LEGACY_CONFIG_FILE", tmp_path / "config.json.legacy"
    )
    monkeypatch.setattr(config_mod, "LEGACY_BACKUP", tmp_path / "config.bak")
    monkeypatch.setattr(config_mod, "_config", None)
    yield ws_dir / "default.json"
    monkeypatch.setattr(config_mod, "_config", None)


@pytest.fixture
def recordings_dir(tmp_path):
    rec = tmp_path / "recordings"
    rec.mkdir(parents=True, exist_ok=True)
    return rec


@pytest.fixture
async def app_client(aiohttp_client, isolated_workspace, recordings_dir):
    cfg = AppConfig()
    cfg.recordings_dir = recordings_dir
    app = create_app(cfg)
    return await aiohttp_client(app)


def _load_disk(ws_file):
    assert ws_file.exists(), f"workspace JSON missing at {ws_file}"
    return json.loads(ws_file.read_text())


# ---------------------------------------------------------------------------
# GET /library/item
# ---------------------------------------------------------------------------

async def test_library_item_returns_meeting_details(app_client, recordings_dir):
    """A meeting row returns its date/title plus inline file bodies so the
    UI can render the detail pane without a per-file roundtrip."""
    stem = "2026-05-14_120000_test-meeting"
    (recordings_dir / f"{stem}.mp3").write_bytes(b"\x00" * 16)
    (recordings_dir / f"{stem}.summary.txt").write_text("Summary body")
    (recordings_dir / f"{stem}.transcript.txt").write_text("Transcript body")
    (recordings_dir / f"{stem}.live.txt").write_text("Live captions")

    resp = await app_client.get(f"/library/item?id={stem}&kind=meeting")
    assert resp.status == 200
    body = await resp.json()
    assert body["id"] == stem
    assert body["kind"] == "meeting"
    assert body["summary_text"] == "Summary body"
    assert body["transcript_text"] == "Transcript body"
    assert body["live_text"] == "Live captions"
    assert body["favorited"] is False
    assert body["in_kb"] is False


async def test_library_item_returns_note_body(app_client, recordings_dir):
    (recordings_dir / "roadmap.note.md").write_text("# Roadmap\n- ship it")

    resp = await app_client.get("/library/item?id=roadmap.note.md&kind=note")
    assert resp.status == 200
    body = await resp.json()
    assert body["kind"] == "note"
    assert body["note_body"] == "# Roadmap\n- ship it"
    assert body["note_filename"] == "roadmap.note.md"


async def test_library_item_404_for_unknown_id(app_client):
    resp = await app_client.get("/library/item?id=does-not-exist&kind=meeting")
    assert resp.status == 404


# ---------------------------------------------------------------------------
# POST /library/transcribe & /library/summarize  (stubbed)
# ---------------------------------------------------------------------------

async def test_library_transcribe_invokes_whisper(app_client, recordings_dir, monkeypatch):
    """Stub `transcribe_audio_file` so the test runs without faster-whisper.
    Confirms the handler resolves the mp3 path under recordings_dir and
    hands it through to the AI helper."""
    stem = "2026-05-14_130000_call"
    (recordings_dir / f"{stem}.mp3").write_bytes(b"\x00" * 8)

    called: dict = {}

    def fake_transcribe(mp3_path, config):
        called["path"] = mp3_path
        # Write a fake transcript so a follow-up call could find it.
        Path(mp3_path).with_suffix(".transcript.txt").write_text("fake transcript")
        return "fake transcript"

    from meeting_helper.ai import client as ai_client
    monkeypatch.setattr(ai_client, "transcribe_audio_file", fake_transcribe)

    resp = await app_client.post("/library/transcribe", json={"id": stem})
    assert resp.status == 200
    body = await resp.json()
    assert body["ok"] is True
    assert body["transcript_path"] == f"{stem}.transcript.txt"
    assert called["path"].endswith(f"{stem}.mp3")


async def test_library_transcribe_404_when_mp3_missing(app_client):
    resp = await app_client.post("/library/transcribe", json={"id": "ghost"})
    assert resp.status == 404


async def test_library_summarize_invokes_summarizer(app_client, recordings_dir, monkeypatch):
    stem = "2026-05-14_140000_call"
    (recordings_dir / f"{stem}.transcript.txt").write_text("transcript text")

    called: dict = {}

    async def fake_summarize(transcript_path, config):
        called["path"] = transcript_path
        # Write a fake summary so list_artifacts picks it up later.
        Path(transcript_path).with_name(f"{stem}.summary.txt").write_text("sum")
        return "sum"

    from meeting_helper.ai import client as ai_client
    monkeypatch.setattr(ai_client, "summarize_transcript", fake_summarize)

    resp = await app_client.post("/library/summarize", json={"id": stem})
    assert resp.status == 200
    body = await resp.json()
    assert body["summary_path"] == f"{stem}.summary.txt"
    assert called["path"].endswith(f"{stem}.transcript.txt")


async def test_library_summarize_404_when_no_transcript_or_live(app_client):
    resp = await app_client.post("/library/summarize", json={"id": "ghost"})
    assert resp.status == 404


# ---------------------------------------------------------------------------
# POST /library/rename
# ---------------------------------------------------------------------------

async def test_library_rename_meeting_moves_all_siblings(app_client, recordings_dir):
    stem = "2026-05-14_150000_Original_Name"
    for suffix in (".mp3", ".live.txt", ".transcript.txt", ".summary.txt"):
        (recordings_dir / f"{stem}{suffix}").write_text("x")

    resp = await app_client.post(
        "/library/rename",
        json={"id": stem, "kind": "meeting", "new_name": "New Title"},
    )
    assert resp.status == 200
    body = await resp.json()
    new_stem = "2026-05-14_150000_New_Title"
    assert body["new_id"] == new_stem
    for suffix in (".mp3", ".live.txt", ".transcript.txt", ".summary.txt"):
        assert not (recordings_dir / f"{stem}{suffix}").exists(), \
            f"old {suffix} still present"
        assert (recordings_dir / f"{new_stem}{suffix}").is_file(), \
            f"new {suffix} missing"


async def test_library_rename_409_when_target_exists(app_client, recordings_dir):
    src_stem = "2026-05-14_160000_aaa"
    dst_stem = "2026-05-14_160000_bbb"
    (recordings_dir / f"{src_stem}.mp3").write_bytes(b"")
    (recordings_dir / f"{dst_stem}.mp3").write_bytes(b"")

    resp = await app_client.post(
        "/library/rename",
        json={"id": src_stem, "kind": "meeting", "new_name": "bbb"},
    )
    assert resp.status == 409


async def test_library_rename_note_slugifies(app_client, recordings_dir):
    (recordings_dir / "old-name.note.md").write_text("body")

    resp = await app_client.post(
        "/library/rename",
        json={"id": "old-name.note.md", "kind": "note", "new_name": "Brand New!"},
    )
    assert resp.status == 200
    body = await resp.json()
    assert body["new_filename"] == "brand-new.note.md"
    assert (recordings_dir / "brand-new.note.md").is_file()
    assert not (recordings_dir / "old-name.note.md").exists()


# ---------------------------------------------------------------------------
# POST /library/delete
# ---------------------------------------------------------------------------

async def test_library_delete_meeting(app_client, recordings_dir):
    stem = "2026-05-14_170000_doomed"
    for suffix in (".mp3", ".live.txt", ".summary.txt"):
        (recordings_dir / f"{stem}{suffix}").write_text("x")

    resp = await app_client.post(
        "/library/delete", json={"id": stem, "kind": "meeting"},
    )
    assert resp.status == 200
    body = await resp.json()
    assert body["deleted"] == 3
    for suffix in (".mp3", ".live.txt", ".summary.txt"):
        assert not (recordings_dir / f"{stem}{suffix}").exists()


# ---------------------------------------------------------------------------
# POST /library/favorite
# ---------------------------------------------------------------------------

async def test_library_favorite_toggle_persists(app_client, recordings_dir, isolated_workspace):
    stem = "2026-05-14_180000_fav"
    (recordings_dir / f"{stem}.mp3").write_bytes(b"")

    # Add
    resp = await app_client.post(
        "/library/favorite",
        json={"id": stem, "kind": "meeting", "value": True},
    )
    assert resp.status == 200
    assert (await resp.json())["favorited"] is True
    disk = _load_disk(isolated_workspace)
    assert f"{stem}.mp3" in disk.get("favorites", [])

    # Remove
    resp = await app_client.post(
        "/library/favorite",
        json={"id": stem, "kind": "meeting", "value": False},
    )
    assert resp.status == 200
    assert (await resp.json())["favorited"] is False
    disk = _load_disk(isolated_workspace)
    assert f"{stem}.mp3" not in disk.get("favorites", [])


# ---------------------------------------------------------------------------
# POST /library/kb
# ---------------------------------------------------------------------------

async def test_library_kb_409_when_summary_missing(app_client, recordings_dir):
    """Adding a meeting to KB requires a .summary.txt to exist — the UI
    must trigger /library/summarize first."""
    stem = "2026-05-14_190000_meeting"
    (recordings_dir / f"{stem}.mp3").write_bytes(b"")
    # No summary file.

    resp = await app_client.post(
        "/library/kb",
        json={"id": stem, "kind": "meeting", "value": True},
    )
    assert resp.status == 409
    body = await resp.json()
    assert "summary" in body["error"].lower()


async def test_library_kb_toggle_persists(app_client, recordings_dir, isolated_workspace):
    stem = "2026-05-14_193000_meeting"
    (recordings_dir / f"{stem}.summary.txt").write_text("sum")

    resp = await app_client.post(
        "/library/kb",
        json={"id": stem, "kind": "meeting", "value": True},
    )
    assert resp.status == 200
    disk = _load_disk(isolated_workspace)
    assert f"{stem}.summary.txt" in disk.get("kb_artifacts", [])


# ---------------------------------------------------------------------------
# POST /library/note
# ---------------------------------------------------------------------------

async def test_library_note_create_writes_file(app_client, recordings_dir):
    resp = await app_client.post(
        "/library/note", json={"title": "Roadmap!! 2026", "body": "# Plans"},
    )
    assert resp.status == 200
    body = await resp.json()
    assert body["filename"].endswith(".note.md")
    assert (recordings_dir / body["filename"]).read_text() == "# Plans"


async def test_library_note_update_overwrites(app_client, recordings_dir):
    (recordings_dir / "roadmap.note.md").write_text("OLD")

    resp = await app_client.post(
        "/library/note", json={"id": "roadmap", "body": "NEW"},
    )
    assert resp.status == 200
    assert (recordings_dir / "roadmap.note.md").read_text() == "NEW"


# ---------------------------------------------------------------------------
# POST /library/text
# ---------------------------------------------------------------------------

async def test_library_text_saves_new_summary(app_client, recordings_dir):
    stem = "2026-05-14_210000_meeting"
    (recordings_dir / f"{stem}.mp3").write_bytes(b"")

    resp = await app_client.post(
        "/library/text",
        json={"id": stem, "which": "summary", "body": "Hello summary"},
    )
    assert resp.status == 200
    body = await resp.json()
    assert body["ok"] is True
    assert body["filename"] == f"{stem}.summary.txt"
    assert (recordings_dir / f"{stem}.summary.txt").read_text() == "Hello summary"


async def test_library_text_overwrites_existing_summary(app_client, recordings_dir):
    stem = "2026-05-14_211000_meeting"
    (recordings_dir / f"{stem}.summary.txt").write_text("OLD")

    resp = await app_client.post(
        "/library/text",
        json={"id": stem, "which": "summary", "body": "NEW"},
    )
    assert resp.status == 200
    assert (recordings_dir / f"{stem}.summary.txt").read_text() == "NEW"


async def test_library_text_rejects_invalid_which(app_client):
    resp = await app_client.post(
        "/library/text",
        json={"id": "anything", "which": "bogus", "body": "x"},
    )
    assert resp.status == 400


async def test_library_text_rejects_path_traversal(app_client):
    resp = await app_client.post(
        "/library/text",
        json={"id": "../etc/passwd", "which": "summary", "body": "x"},
    )
    assert resp.status == 400


# ---------------------------------------------------------------------------
# GET /library/audio
# ---------------------------------------------------------------------------

async def test_library_audio_streams_file(app_client, recordings_dir):
    stem = "2026-05-14_200000_audio"
    audio_bytes = b"FAKEMP3DATA" * 32
    (recordings_dir / f"{stem}.mp3").write_bytes(audio_bytes)

    resp = await app_client.get(f"/library/audio?id={stem}")
    assert resp.status == 200
    assert resp.headers.get("Content-Type") == "audio/mpeg"
    assert (await resp.read()) == audio_bytes


async def test_library_audio_rejects_traversal(app_client):
    resp = await app_client.get("/library/audio?id=../etc/passwd")
    assert resp.status == 400
