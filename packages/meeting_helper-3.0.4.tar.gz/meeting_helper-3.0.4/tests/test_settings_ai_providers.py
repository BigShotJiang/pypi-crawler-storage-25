"""Saving the AI-providers settings writes ai_provider_order + ai_failover_delay_ms."""

from __future__ import annotations

import json

from meeting_helper.config import Config


def test_provider_order_round_trip_via_config(tmp_path):
    p = tmp_path / "config.json"
    cfg = Config(p)
    cfg.ai_provider_order = ["google", "anthropic"]
    cfg.ai_failover_delay_ms = 0
    # Keep preferred_provider mirrored to the primary, for back-compat with the
    # rest of the app (the Settings screen does this on save):
    cfg.preferred_provider = "gemini"   # google → "gemini" in legacy vocab
    cfg.save()
    raw = json.loads(p.read_text())
    assert raw["ai_provider_order"] == ["google", "anthropic"]
    assert raw["ai_failover_delay_ms"] == 0
    assert raw["preferred_provider"] == "gemini"
