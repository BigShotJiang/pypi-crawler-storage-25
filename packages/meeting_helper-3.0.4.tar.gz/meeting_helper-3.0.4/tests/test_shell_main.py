"""Tests for shell.__main__ — entry-point orchestration.

We don't actually start pywebview's event loop in tests. We patch out
`webview.start` and verify that:
  - the daemon URL is resolved from the loaded config
  - wait_for_health is awaited before the window opens
  - create_window receives the resolved URL
  - webview.start() is called exactly once
"""

from __future__ import annotations

from unittest.mock import MagicMock

import pytest


@pytest.fixture
def fake_webview(monkeypatch):
    fw = MagicMock()
    monkeypatch.setitem(__import__("sys").modules, "webview", fw)
    return fw


@pytest.fixture
def _bypass_single_instance(monkeypatch):
    """For tests of main(), bypass the single-instance guard so we don't touch
    the real GUI_PID_FILE. Tests that exercise _enforce_single_instance
    directly should NOT request this fixture.
    """
    from meeting_helper.shell import __main__ as shell_main
    monkeypatch.setattr(shell_main, "_enforce_single_instance", lambda: True)


def test_main_resolves_url_waits_for_health_and_starts(
    fake_webview, _bypass_single_instance, monkeypatch
):
    from meeting_helper.shell import __main__ as shell_main

    monkeypatch.setattr(
        shell_main,
        "get_config",
        lambda: type("Cfg", (), {"port": 9999})(),
    )

    async def _ok(*_a, **_kw):
        return True

    monkeypatch.setattr(shell_main.daemon_link, "wait_for_health", _ok)

    shell_main.main()

    fake_webview.create_window.assert_called_once()
    args, kwargs = fake_webview.create_window.call_args
    expected_url = "http://127.0.0.1:9999/"
    assert (len(args) >= 2 and args[1] == expected_url) or (
        kwargs.get("url") == expected_url
    )
    fake_webview.start.assert_called_once()


def test_main_aborts_with_clear_error_if_daemon_never_healthy(
    fake_webview, _bypass_single_instance, monkeypatch, capsys
):
    from meeting_helper.shell import __main__ as shell_main

    monkeypatch.setattr(
        shell_main,
        "get_config",
        lambda: type("Cfg", (), {"port": 9999})(),
    )

    async def _never(*_a, **_kw):
        return False

    monkeypatch.setattr(shell_main.daemon_link, "wait_for_health", _never)

    rc = shell_main.main()
    assert rc == 1
    fake_webview.create_window.assert_not_called()
    fake_webview.start.assert_not_called()
    err = capsys.readouterr().err
    assert "daemon" in err.lower()
    assert "meeting-helper start" in err


def test_main_uses_dev_url_when_mh_shell_dev_env_set(
    fake_webview, _bypass_single_instance, monkeypatch
):
    """When MH_SHELL_DEV=1, the window points at the dev server, not the daemon."""
    from meeting_helper.shell import __main__ as shell_main

    monkeypatch.setattr(
        shell_main,
        "get_config",
        lambda: type("Cfg", (), {"port": 9999})(),
    )

    async def _ok(*_a, **_kw):
        return True

    monkeypatch.setattr(shell_main.daemon_link, "wait_for_health", _ok)
    monkeypatch.setenv("MH_SHELL_DEV", "1")

    shell_main.main()

    fake_webview.create_window.assert_called_once()
    args, kwargs = fake_webview.create_window.call_args
    expected_url = "http://localhost:3000/"
    assert (len(args) >= 2 and args[1] == expected_url) or (
        kwargs.get("url") == expected_url
    )


# --- Single-instance enforcement -------------------------------------------------


def test_enforce_single_instance_writes_pid_when_no_existing_file(
    tmp_path, monkeypatch
):
    """With no pid file, returns True and writes our own PID."""
    from meeting_helper.shell import __main__ as shell_main

    pid_file = tmp_path / "shell.pid"
    monkeypatch.setattr(shell_main, "GUI_PID_FILE", pid_file)

    assert shell_main._enforce_single_instance() is True
    assert pid_file.exists()
    import os as _os
    assert pid_file.read_text().strip() == str(_os.getpid())


def test_enforce_single_instance_overwrites_stale_pid_file(tmp_path, monkeypatch):
    """A pid file pointing at a dead process is treated as stale."""
    from meeting_helper.shell import __main__ as shell_main

    pid_file = tmp_path / "shell.pid"
    pid_file.write_text("424242")  # not alive
    monkeypatch.setattr(shell_main, "GUI_PID_FILE", pid_file)

    def _kill(pid, _sig):
        raise ProcessLookupError()

    monkeypatch.setattr(shell_main.os, "kill", _kill)

    assert shell_main._enforce_single_instance() is True
    import os as _os
    assert pid_file.read_text().strip() == str(_os.getpid())


def test_enforce_single_instance_refuses_when_live_pid_present(
    tmp_path, monkeypatch, capsys
):
    """A live PID in the file causes the function to return False (caller exits)."""
    from meeting_helper.shell import __main__ as shell_main

    pid_file = tmp_path / "shell.pid"
    pid_file.write_text("99999")
    monkeypatch.setattr(shell_main, "GUI_PID_FILE", pid_file)

    # Pretend the recorded PID is alive.
    def _kill(_pid, _sig):
        return None

    monkeypatch.setattr(shell_main.os, "kill", _kill)

    # Stub the AppKit import path so we exercise the "focused it" branch.
    fake_app = MagicMock()
    fake_app.activateWithOptions_ = MagicMock()
    fake_nsrunning = MagicMock()
    fake_nsrunning.runningApplicationWithProcessIdentifier_ = MagicMock(
        return_value=fake_app
    )
    fake_appkit = MagicMock(
        NSRunningApplication=fake_nsrunning,
        NSApplicationActivateIgnoringOtherApps=1 << 1,
    )
    monkeypatch.setitem(__import__("sys").modules, "AppKit", fake_appkit)

    assert shell_main._enforce_single_instance() is False
    # Existing pid file unchanged — we did not overwrite the live owner.
    assert pid_file.read_text().strip() == "99999"
    fake_app.activateWithOptions_.assert_called_once()
    err = capsys.readouterr().err
    assert "already running" in err


def test_is_launched_from_app_bundle_reads_env(monkeypatch):
    from meeting_helper.shell import __main__ as shell_main

    monkeypatch.delenv("__CFBundleIdentifier", raising=False)
    assert shell_main._is_launched_from_app_bundle() is False

    monkeypatch.setenv("__CFBundleIdentifier", "com.victor.meeting-helper")
    assert shell_main._is_launched_from_app_bundle() is True

    monkeypatch.setenv("__CFBundleIdentifier", "com.apple.Terminal")
    assert shell_main._is_launched_from_app_bundle() is False


def test_enforce_single_instance_evicts_when_launched_from_app_bundle(
    tmp_path, monkeypatch, capsys
):
    """The .app launch path must NOT focus-and-exit — that's what makes the
    dock icon vanish ~60ms after launch. It must kill the stale shell and
    take over so the new process anchors the .app lifecycle."""
    from meeting_helper.shell import __main__ as shell_main

    pid_file = tmp_path / "shell.pid"
    pid_file.write_text("99999")
    monkeypatch.setattr(shell_main, "GUI_PID_FILE", pid_file)
    monkeypatch.setenv("__CFBundleIdentifier", "com.victor.meeting-helper")

    # Pretend the recorded PID is alive for the initial kill(pid, 0) probe;
    # _evict_existing_shell is stubbed to a no-op so the test doesn't actually
    # SIGTERM anything.
    monkeypatch.setattr(shell_main.os, "kill", lambda _pid, _sig: None)
    evicted: list[int] = []
    monkeypatch.setattr(
        shell_main,
        "_evict_existing_shell",
        lambda pid: evicted.append(pid),
    )

    assert shell_main._enforce_single_instance() is True
    assert evicted == [99999]
    import os as _os
    assert pid_file.read_text().strip() == str(_os.getpid())
    err = capsys.readouterr().err
    assert "replacing stale shell" in err
    assert "launched from .app" in err


def test_enforce_single_instance_terminal_launch_still_focuses(
    tmp_path, monkeypatch, capsys
):
    """Terminal/menubar launches keep the focus-and-exit courtesy — only
    .app launches do the eviction. Without __CFBundleIdentifier we hit the
    legacy branch."""
    from meeting_helper.shell import __main__ as shell_main

    pid_file = tmp_path / "shell.pid"
    pid_file.write_text("99999")
    monkeypatch.setattr(shell_main, "GUI_PID_FILE", pid_file)
    monkeypatch.delenv("__CFBundleIdentifier", raising=False)
    monkeypatch.setattr(shell_main.os, "kill", lambda _pid, _sig: None)

    fake_app = MagicMock()
    fake_nsrunning = MagicMock()
    fake_nsrunning.runningApplicationWithProcessIdentifier_ = MagicMock(
        return_value=fake_app
    )
    fake_appkit = MagicMock(
        NSRunningApplication=fake_nsrunning,
        NSApplicationActivateIgnoringOtherApps=1 << 1,
    )
    monkeypatch.setitem(__import__("sys").modules, "AppKit", fake_appkit)

    assert shell_main._enforce_single_instance() is False
    assert pid_file.read_text().strip() == "99999"  # untouched
    fake_app.activateWithOptions_.assert_called_once()
    err = capsys.readouterr().err
    assert "already running" in err


def test_main_returns_zero_when_another_shell_is_running(
    fake_webview, monkeypatch
):
    """When _enforce_single_instance returns False, main() exits 0 without UI."""
    from meeting_helper.shell import __main__ as shell_main

    monkeypatch.setattr(shell_main, "_enforce_single_instance", lambda: False)

    rc = shell_main.main()
    assert rc == 0
    fake_webview.create_window.assert_not_called()
    fake_webview.start.assert_not_called()


def test_main_sets_macos_activation_policy_regular(
    fake_webview, _bypass_single_instance, monkeypatch
):
    """main() flips NSApp to Regular so the dock displays the real app icon."""
    from meeting_helper.shell import __main__ as shell_main

    monkeypatch.setattr(
        shell_main,
        "get_config",
        lambda: type("Cfg", (), {"port": 9999})(),
    )

    async def _ok(*_a, **_kw):
        return True

    monkeypatch.setattr(shell_main.daemon_link, "wait_for_health", _ok)

    fake_ns_app_instance = MagicMock()
    fake_ns_app_cls = MagicMock()
    fake_ns_app_cls.sharedApplication = MagicMock(return_value=fake_ns_app_instance)
    sentinel_policy = 7777  # NSApplicationActivationPolicyRegular sentinel
    fake_appkit = MagicMock(
        NSApplication=fake_ns_app_cls,
        NSApplicationActivationPolicyRegular=sentinel_policy,
    )
    monkeypatch.setitem(__import__("sys").modules, "AppKit", fake_appkit)

    shell_main.main()

    fake_ns_app_cls.sharedApplication.assert_called_once()
    fake_ns_app_instance.setActivationPolicy_.assert_called_once_with(sentinel_policy)


def test_set_macos_activation_policy_swallows_errors(monkeypatch):
    """A missing/broken AppKit must not crash startup."""
    from meeting_helper.shell import __main__ as shell_main

    fake_appkit = MagicMock()
    fake_appkit.NSApplication.sharedApplication.side_effect = RuntimeError("nope")
    monkeypatch.setitem(__import__("sys").modules, "AppKit", fake_appkit)

    # Should not raise.
    shell_main._set_macos_activation_policy()


# --- _kill_stale_shells ----------------------------------------------------


def test_kill_stale_shells_sigterms_other_shell_processes(monkeypatch):
    """A sibling `meeting_helper.shell` process is SIGTERM'd; the current one isn't."""
    from meeting_helper.shell import __main__ as shell_main
    import psutil
    import signal as _signal
    import os as _os

    self_pid = _os.getpid()
    sibling = MagicMock()
    sibling.info = {
        "pid": self_pid + 1,
        "cmdline": ["python", "-m", "meeting_helper.shell"],
    }
    me = MagicMock()
    me.info = {
        "pid": self_pid,
        "cmdline": ["python", "-m", "meeting_helper.shell"],
    }
    unrelated = MagicMock()
    unrelated.info = {
        "pid": self_pid + 2,
        "cmdline": ["python", "-m", "some.other.module"],
    }

    monkeypatch.setattr(
        psutil,
        "process_iter",
        lambda attrs=None: iter([sibling, me, unrelated]),
    )

    shell_main._kill_stale_shells()

    sibling.send_signal.assert_called_once_with(_signal.SIGTERM)
    me.send_signal.assert_not_called()
    unrelated.send_signal.assert_not_called()


def test_kill_stale_shells_ignores_dead_or_denied(monkeypatch):
    """psutil errors on individual processes must not abort the sweep."""
    from meeting_helper.shell import __main__ as shell_main
    import psutil
    import os as _os

    self_pid = _os.getpid()
    gone = MagicMock()
    gone.info = {
        "pid": self_pid + 1,
        "cmdline": ["python", "-m", "meeting_helper.shell"],
    }
    gone.send_signal.side_effect = psutil.NoSuchProcess(pid=self_pid + 1)

    survivor = MagicMock()
    survivor.info = {
        "pid": self_pid + 2,
        "cmdline": ["python", "-m", "meeting_helper.shell"],
    }

    monkeypatch.setattr(
        psutil,
        "process_iter",
        lambda attrs=None: iter([gone, survivor]),
    )

    # Should not raise.
    shell_main._kill_stale_shells()
    # The survivor was still signalled even after the gone process raised.
    survivor.send_signal.assert_called_once()


def test_main_calls_kill_stale_shells(
    fake_webview, _bypass_single_instance, monkeypatch
):
    from meeting_helper.shell import __main__ as shell_main

    monkeypatch.setattr(
        shell_main,
        "get_config",
        lambda: type("Cfg", (), {"port": 9999})(),
    )

    async def _ok(*_a, **_kw):
        return True

    monkeypatch.setattr(shell_main.daemon_link, "wait_for_health", _ok)

    called = MagicMock()
    monkeypatch.setattr(shell_main, "_kill_stale_shells", called)

    shell_main.main()
    called.assert_called_once()
