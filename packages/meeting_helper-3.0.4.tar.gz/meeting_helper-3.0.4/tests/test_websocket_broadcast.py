"""Tests for WebSocket broadcast — per-client timeout + concurrent send."""

from __future__ import annotations

import asyncio
import json
from unittest.mock import AsyncMock, MagicMock

import pytest


@pytest.mark.asyncio
async def test_broadcast_sends_to_all_clients():
    """Happy path: every connected client gets the JSON-serialized message."""
    from meeting_helper.server.websocket import broadcast
    from meeting_helper.state import state

    ws_a = MagicMock()
    ws_a.send_str = AsyncMock()
    ws_b = MagicMock()
    ws_b.send_str = AsyncMock()
    state.ws_clients = {ws_a, ws_b}

    try:
        await broadcast({"type": "ping"})
        for ws in (ws_a, ws_b):
            ws.send_str.assert_awaited_once()
            sent = ws.send_str.call_args.args[0]
            assert json.loads(sent) == {"type": "ping"}
    finally:
        state.ws_clients = set()


@pytest.mark.asyncio
async def test_broadcast_drops_slow_client_via_timeout(caplog):
    """One stalled client must not block the broadcast for others.
    With asyncio.gather + per-client wait_for, the slow client's timeout
    fires in parallel and other clients still receive within ~timeout."""
    import logging
    from meeting_helper.server import websocket as ws_mod
    from meeting_helper.server.websocket import broadcast
    from meeting_helper.state import state

    fast = MagicMock()
    fast.send_str = AsyncMock()

    slow = MagicMock()

    async def slow_send(_data):
        await asyncio.sleep(10)  # exceeds the 2s timeout

    slow.send_str = AsyncMock(side_effect=slow_send)

    state.ws_clients = {fast, slow}
    # Tighten timeout to keep the test fast.
    original_timeout = ws_mod._SEND_TIMEOUT_SEC
    ws_mod._SEND_TIMEOUT_SEC = 0.1

    try:
        with caplog.at_level(logging.WARNING):
            await broadcast({"type": "ping"})
        # Fast client got the message.
        fast.send_str.assert_awaited_once()
        # Slow client was dropped from the set.
        assert slow not in state.ws_clients
        assert fast in state.ws_clients
        # Failure was logged.
        assert any("timed out" in rec.message for rec in caplog.records)
    finally:
        ws_mod._SEND_TIMEOUT_SEC = original_timeout
        state.ws_clients = set()


@pytest.mark.asyncio
async def test_broadcast_drops_failing_client():
    """Errors during send must drop the client without affecting others."""
    from meeting_helper.server.websocket import broadcast
    from meeting_helper.state import state

    good = MagicMock()
    good.send_str = AsyncMock()
    bad = MagicMock()
    bad.send_str = AsyncMock(side_effect=ConnectionResetError("dead"))

    state.ws_clients = {good, bad}

    try:
        await broadcast({"type": "ping"})
        good.send_str.assert_awaited_once()
        assert bad not in state.ws_clients
        assert good in state.ws_clients
    finally:
        state.ws_clients = set()


@pytest.mark.asyncio
async def test_broadcast_no_clients_short_circuits():
    """Empty client set: no work, no errors."""
    from meeting_helper.server.websocket import broadcast
    from meeting_helper.state import state

    state.ws_clients = set()
    # Should not raise.
    await broadcast({"type": "ping"})
