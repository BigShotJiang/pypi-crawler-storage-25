"""Tests for shell.window — verify the pywebview create_window call shape."""

from __future__ import annotations

from unittest.mock import MagicMock, patch


def test_create_window_passes_expected_args():
    """create_window is invoked with the daemon URL, title, and sizing."""
    fake_webview = MagicMock()
    with patch.dict("sys.modules", {"webview": fake_webview}):
        from meeting_helper.shell import window

        window.create_window(url="http://127.0.0.1:9876/")

    fake_webview.create_window.assert_called_once()
    args, kwargs = fake_webview.create_window.call_args
    # First positional is the window title.
    assert args[0] == "Meeting Helper"
    # The URL is passed either positionally or as `url=`.
    assert (len(args) >= 2 and args[1] == "http://127.0.0.1:9876/") or (
        kwargs.get("url") == "http://127.0.0.1:9876/"
    )
    assert kwargs.get("width") == 1200
    assert kwargs.get("height") == 800
    assert kwargs.get("min_size") == (900, 600)
    assert kwargs.get("resizable") is True
    assert kwargs.get("text_select") is True


def test_create_window_centers_when_appkit_available():
    """When AppKit's mainScreen returns a frame, the window is centered."""
    fake_webview = MagicMock()

    class _FrameSize:
        width = 2000
        height = 1200

    class _Frame:
        size = _FrameSize()

    fake_screen = MagicMock()
    fake_screen.frame = MagicMock(return_value=_Frame())
    fake_nsscreen = MagicMock()
    fake_nsscreen.mainScreen = MagicMock(return_value=fake_screen)
    fake_appkit = MagicMock(NSScreen=fake_nsscreen)

    with patch.dict("sys.modules", {"webview": fake_webview, "AppKit": fake_appkit}):
        from meeting_helper.shell import window

        window.create_window(url="http://127.0.0.1:1/")

    _args, kwargs = fake_webview.create_window.call_args
    # Centered: (2000-1200)/2 = 400 ; (1200-800)/2 = 200
    assert kwargs.get("x") == 400
    assert kwargs.get("y") == 200


def test_create_window_skips_centering_when_screen_is_none():
    """If AppKit returns no main screen, x/y are omitted (pywebview defaults)."""
    fake_webview = MagicMock()
    fake_nsscreen = MagicMock()
    fake_nsscreen.mainScreen = MagicMock(return_value=None)
    fake_appkit = MagicMock(NSScreen=fake_nsscreen)

    with patch.dict("sys.modules", {"webview": fake_webview, "AppKit": fake_appkit}):
        from meeting_helper.shell import window

        window.create_window(url="http://127.0.0.1:1/")

    _args, kwargs = fake_webview.create_window.call_args
    assert "x" not in kwargs
    assert "y" not in kwargs
