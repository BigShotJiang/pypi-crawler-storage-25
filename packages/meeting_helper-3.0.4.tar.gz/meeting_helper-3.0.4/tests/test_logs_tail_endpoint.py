"""Tests for /logs/tail — backs the workspace-switch error dialog."""

from __future__ import annotations

import pytest

from meeting_helper import config as config_mod
from meeting_helper.config import AppConfig
from meeting_helper.server.app import create_app


@pytest.fixture
async def app_client(aiohttp_client, tmp_path, monkeypatch):
    log_file = tmp_path / "meeting-helper.log"
    monkeypatch.setattr(config_mod, "LOG_FILE", log_file)
    return await aiohttp_client(create_app(AppConfig())), log_file


async def test_logs_tail_returns_last_n_lines(app_client):
    client, log_file = app_client
    log_file.write_text("\n".join(f"line-{i}" for i in range(50)))
    resp = await client.get("/logs/tail?n=5")
    assert resp.status == 200
    body = await resp.json()
    assert body["lines"] == [f"line-{i}" for i in range(45, 50)]
    assert body["path"] == str(log_file)


async def test_logs_tail_default_n_is_20(app_client):
    client, log_file = app_client
    log_file.write_text("\n".join(f"l-{i}" for i in range(100)))
    resp = await client.get("/logs/tail")
    body = await resp.json()
    assert len(body["lines"]) == 20
    assert body["lines"][-1] == "l-99"


async def test_logs_tail_empty_when_missing(app_client):
    client, _log_file = app_client
    resp = await client.get("/logs/tail?n=10")
    assert resp.status == 200
    body = await resp.json()
    assert body["lines"] == []


async def test_logs_tail_clamps_invalid_n(app_client):
    client, log_file = app_client
    log_file.write_text("only one line")
    resp = await client.get("/logs/tail?n=not-a-number")
    assert resp.status == 200
    body = await resp.json()
    # falls back to default-20 behaviour and returns the single line
    assert body["lines"] == ["only one line"]


async def test_logs_tail_clamps_huge_n(app_client):
    client, log_file = app_client
    log_file.write_text("\n".join(f"l-{i}" for i in range(800)))
    resp = await client.get("/logs/tail?n=10000")
    body = await resp.json()
    # Hard cap of 500.
    assert len(body["lines"]) == 500
