"""Tests for transcriber lifecycle: reconnect, watchdog, dead broadcast.

Avoids real Deepgram. We exercise the public surfaces (start/stop) and
internal helpers (_reconnect_inline) by mocking the Deepgram SDK.
"""

from __future__ import annotations

import threading
import time
from unittest.mock import MagicMock, patch

import pytest


def _make_transcriber():
    """Build a DeepgramTranscriber with stub buffer + capture."""
    from meeting_helper.audio.transcriber import DeepgramTranscriber

    capture = MagicMock()
    capture.get_transcriber_audio = MagicMock(return_value=None)
    buffer = MagicMock()
    buffer.role = "self"
    return DeepgramTranscriber(
        audio_capture=capture,
        transcript_buffer=buffer,
        api_key="test-key",
        language="en",
    )


def test_on_error_signals_needs_reconnect_no_thread_spawn():
    """_on_error used to spawn a reconnect thread directly. Now it just
    sets the Event so the feed loop owns reconnect — single-flight by
    construction."""
    t = _make_transcriber()
    assert not t._needs_reconnect.is_set()
    t._on_error(None, error="test")
    assert t._needs_reconnect.is_set()


def test_on_close_signals_needs_reconnect_idempotent():
    """_on_close + _on_error firing for the same drop must not race —
    both just set the same Event, idempotent."""
    t = _make_transcriber()
    t._on_error(None, error="x")
    t._on_close(None, close="y")
    assert t._needs_reconnect.is_set()


def test_reconnect_inline_aborts_on_stop_event():
    """_stop_event interrupts the back-off wait immediately. Without
    interruptible sleep, stop() blocked up to 30s during reconnect."""
    t = _make_transcriber()
    t._stop_event.set()
    result = t._reconnect_inline()
    assert result is False  # gave up because stop was set


def test_reconnect_inline_returns_true_on_first_success():
    """If _start_connection succeeds, _reconnect_inline returns True
    immediately so the feed loop resumes."""
    t = _make_transcriber()
    with patch.object(t, "_start_connection", return_value=True):
        # Patch _stop_event.wait so the back-off doesn't actually sleep.
        with patch.object(t._stop_event, "wait", return_value=False):
            result = t._reconnect_inline()
    assert result is True


def test_reconnect_inline_gives_up_after_max_attempts():
    """After _reconnect_max_attempts failures, return False AND broadcast
    transcriber_dead so the GUI sees the failure."""
    t = _make_transcriber()
    t._reconnect_max_attempts = 3  # tighten for the test
    with patch.object(t, "_start_connection", return_value=False), \
         patch.object(t._stop_event, "wait", return_value=False), \
         patch.object(t, "_broadcast_dead") as mock_dead:
        result = t._reconnect_inline()
    assert result is False
    mock_dead.assert_called_once()


def test_broadcast_dead_dispatches_to_event_loop():
    """_broadcast_dead must use _schedule_threadsafe so the GUI gets the
    transcriber_dead event."""
    t = _make_transcriber()
    # state is imported function-locally inside _broadcast_dead, so patch
    # the source module rather than the transcriber module.
    from meeting_helper import state as state_module
    fake_loop = MagicMock()
    with patch.object(state_module.state, "asyncio_loop", fake_loop), \
         patch("meeting_helper.audio.transcriber._schedule_threadsafe") as mock_schedule:
        t._broadcast_dead()
    mock_schedule.assert_called_once()
    # The label arg (3rd positional) tells us which broadcast it was.
    args, _ = mock_schedule.call_args
    assert "transcriber_dead" in args[2]


def test_stop_returns_within_short_timeout():
    """stop() must NOT block 35s (old timeout). With interruptible
    _stop_event.wait, 5s is plenty."""
    t = _make_transcriber()
    fake_thread = MagicMock()
    fake_thread.is_alive = MagicMock(return_value=False)
    t._thread = fake_thread
    start = time.monotonic()
    t.stop()
    duration = time.monotonic() - start
    assert duration < 1.0  # mock thread; should return immediately
    fake_thread.join.assert_called_once()
    # And the timeout passed should be 5s (Phase 4a fix).
    assert fake_thread.join.call_args.kwargs["timeout"] == 5.0
