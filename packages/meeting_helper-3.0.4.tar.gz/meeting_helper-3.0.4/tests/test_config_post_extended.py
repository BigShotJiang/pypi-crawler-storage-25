"""POST /config must accept every field the new Settings UI writes.

Plan 2 hooked the Next.js Settings tabs up to a single ``/config`` POST, but
the daemon's handler historically only branched on a small subset of keys —
everything else silently dropped. This regression test pins the full set of
new fields: each is POSTed with a non-default value and then read back via
GET to confirm the daemon both ingested it and exposes it in the snapshot
the UI re-hydrates from.

We use a parametrized test instead of one-per-field so adding the next batch
of fields stays a one-line change rather than a new copy-pasted async def.
"""

from __future__ import annotations

import json

import pytest

from meeting_helper import config as config_mod
from meeting_helper.config import AppConfig
from meeting_helper.server.app import create_app


@pytest.fixture
async def app_client(aiohttp_client, tmp_path, monkeypatch):
    """Isolate the workspace config from the real `~/.config/meeting-helper`.

    The /config POST handler writes through to disk via `get_config().save()`.
    Without this isolation, every test run overwrote the user's real workspace
    JSON. Mirror the monkeypatching from `test_config_post_persistence.py`.
    """
    ws_dir = tmp_path / "workspaces"
    ws_dir.mkdir(parents=True, exist_ok=True)
    (ws_dir / "default.json").write_text(json.dumps({}))
    (tmp_path / "state.json").write_text(
        json.dumps({"active_workspace": "default", "workspace_order": ["default"]})
    )

    monkeypatch.setattr(config_mod, "DEFAULT_CONFIG_DIR", tmp_path)
    monkeypatch.setattr(config_mod, "WORKSPACES_DIR", ws_dir)
    monkeypatch.setattr(config_mod, "STATE_FILE", tmp_path / "state.json")
    monkeypatch.setattr(
        config_mod, "LEGACY_CONFIG_FILE", tmp_path / "config.json.legacy"
    )
    monkeypatch.setattr(config_mod, "LEGACY_BACKUP", tmp_path / "config.bak")
    monkeypatch.setattr(config_mod, "_config", None)

    app = create_app(AppConfig())
    return await aiohttp_client(app)


# (field_name, value_to_post, expected_value_back)
# expected_value_back is usually equal to value_to_post, but the GET handler
# coerces a few fields (recordings_dir → str), so we keep them explicit.
ROUNDTRIP_FIELDS = [
    ("anthropic_api_key", "sk-test-anthropic-roundtrip", "sk-test-anthropic-roundtrip"),
    ("google_api_key", "AIza-test-google-roundtrip", "AIza-test-google-roundtrip"),
    ("recordings_dir", "/tmp/mh-test-recordings", "/tmp/mh-test-recordings"),
    ("auto_summarize_on_end", True, True),
    ("auto_rename_on_end", True, True),
    ("auto_add_to_kb", False, False),
    ("auto_start_record", False, False),
    ("ollama_host", "http://localhost:99999", "http://localhost:99999"),
    ("claude_model_alias", "opus", "opus"),
    ("gemini_model_alias", "pro", "pro"),
    ("system_prompt", "Custom test prompt body.", "Custom test prompt body."),
    ("show_menubar_icon", False, False),
    ("menubar_icon", "◆", "◆"),
]


@pytest.mark.parametrize("field,value,expected", ROUNDTRIP_FIELDS)
async def test_config_post_roundtrips_field(app_client, field, value, expected):
    """POST {field: value} -> GET should reflect `expected`."""
    resp = await app_client.post("/config", json={field: value})
    assert resp.status == 200, f"POST failed for {field}: {await resp.text()}"

    got = await (await app_client.get("/config")).json()
    assert got[field] == expected, (
        f"field {field!r} did not round-trip: posted {value!r}, "
        f"GET returned {got[field]!r}, expected {expected!r}"
    )


async def test_config_post_multiple_fields_at_once(app_client):
    """A single POST with several new fields must persist them all.

    The Settings UI submits the entire form in one request, so the handler
    must handle a multi-field body without any field shadowing another.
    """
    payload = {
        "anthropic_api_key": "sk-multi",
        "auto_rename_on_end": True,
        "auto_add_to_kb": False,
        "ollama_host": "http://multi-host:11434",
        "system_prompt": "Multi-field prompt.",
    }
    resp = await app_client.post("/config", json=payload)
    assert resp.status == 200

    got = await (await app_client.get("/config")).json()
    for k, v in payload.items():
        assert got[k] == v, f"{k!r} did not persist in multi-field POST"
