"""Tests for force_stop_session — the helper that backs the GUI/menubar
Stop buttons. Mocks subprocess + os.kill so we can drive each branch
without touching a real daemon.
"""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest


def test_graceful_stop_succeeds_no_kill_needed(tmp_path):
    """Happy path: /session/stop returns 200, daemon exits cleanly inside
    the grace window. No SIGTERM/SIGKILL sent. Fresh daemon spawned."""
    from meeting_helper import force_stop

    # No pid file → "daemon already gone" branch.
    fake_pid_file = tmp_path / "pid"
    with patch.object(force_stop, "PID_FILE", fake_pid_file), \
         patch.object(force_stop, "_try_graceful_stop", return_value=True), \
         patch.object(force_stop, "_kill_daemon") as kill_mock, \
         patch.object(force_stop, "_spawn_fresh_daemon") as spawn_mock, \
         patch("meeting_helper.force_stop.time.sleep"):
        force_stop.force_stop_session(port=7891, kill_grace_sec=0)

    kill_mock.assert_not_called()
    spawn_mock.assert_called_once()


def test_wedged_daemon_gets_force_killed(tmp_path):
    """If the daemon is still alive after the graceful attempt, SIGTERM/
    SIGKILL escalation runs."""
    from meeting_helper import force_stop

    fake_pid_file = tmp_path / "pid"
    fake_pid_file.write_text("12345")

    with patch.object(force_stop, "PID_FILE", fake_pid_file), \
         patch.object(force_stop, "_try_graceful_stop", return_value=False), \
         patch.object(force_stop, "_process_alive", return_value=True), \
         patch.object(force_stop, "_kill_daemon") as kill_mock, \
         patch.object(force_stop, "_spawn_fresh_daemon") as spawn_mock, \
         patch("meeting_helper.force_stop.time.sleep"):
        force_stop.force_stop_session(port=7891, kill_grace_sec=0)

    kill_mock.assert_called_once_with(12345)
    spawn_mock.assert_called_once()


def test_kill_daemon_escalates_sigterm_then_sigkill():
    """Verify the SIGTERM → SIGKILL escalation pattern."""
    import signal
    from meeting_helper import force_stop

    sent: list[tuple[int, int]] = []

    def fake_kill(pid: int, sig: int) -> None:
        sent.append((pid, sig))

    # Process stays alive after SIGTERM, dies after SIGKILL.
    alive_calls = {"n": 0}

    def fake_alive(pid: int) -> bool:
        alive_calls["n"] += 1
        # First 20 SIGTERM-loop checks: alive. After SIGKILL: dead.
        return alive_calls["n"] <= 20

    with patch.object(force_stop.os, "kill", side_effect=fake_kill), \
         patch.object(force_stop, "_process_alive", side_effect=fake_alive), \
         patch("meeting_helper.force_stop.time.sleep"):
        force_stop._kill_daemon(99999)

    sigs_sent = [s for _, s in sent]
    assert signal.SIGTERM in sigs_sent
    assert signal.SIGKILL in sigs_sent


def test_force_stop_handles_pid_file_missing(tmp_path):
    """No pid file (daemon never started, or file removed) → skip kill,
    still spawn a fresh daemon. No exception."""
    from meeting_helper import force_stop

    fake_pid_file = tmp_path / "doesnt-exist"

    with patch.object(force_stop, "PID_FILE", fake_pid_file), \
         patch.object(force_stop, "_try_graceful_stop", return_value=False), \
         patch.object(force_stop, "_kill_daemon") as kill_mock, \
         patch.object(force_stop, "_spawn_fresh_daemon") as spawn_mock, \
         patch("meeting_helper.force_stop.time.sleep"):
        force_stop.force_stop_session(port=7891, kill_grace_sec=0)

    kill_mock.assert_not_called()
    spawn_mock.assert_called_once()
