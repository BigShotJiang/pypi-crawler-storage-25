"""Tests for auto-updater post-update restart logic."""

from __future__ import annotations

from unittest.mock import patch

from meeting_helper import auto_updater


def test_resolve_cli_prefers_sys_executable_neighbor(tmp_path):
    cli_path = tmp_path / "meeting-helper"
    cli_path.write_text("#!/bin/sh\n")
    cli_path.chmod(0o755)
    fake_executable = tmp_path / "python3"
    fake_executable.write_text("")

    with patch("meeting_helper.auto_updater.sys") as fake_sys:
        fake_sys.executable = str(fake_executable)
        assert auto_updater._resolve_cli() == str(cli_path)


def test_resolve_cli_falls_back_to_path_lookup(tmp_path):
    fake_executable = tmp_path / "python3"
    fake_executable.write_text("")

    with patch("meeting_helper.auto_updater.sys") as fake_sys, \
         patch("meeting_helper.auto_updater.shutil.which", return_value="/usr/local/bin/meeting-helper"):
        fake_sys.executable = str(fake_executable)
        assert auto_updater._resolve_cli() == "/usr/local/bin/meeting-helper"


def test_trigger_post_update_restart_skips_when_cli_unresolved(tmp_path):
    """If CLI can't be resolved we must NOT self-SIGTERM (would leave no daemon)."""
    from meeting_helper import config as cfg_module
    fake_pid_file = tmp_path / "menubar.pid"  # does not exist
    with patch("meeting_helper.auto_updater._resolve_cli", return_value=None), \
         patch("meeting_helper.auto_updater.os.kill") as fake_kill, \
         patch("meeting_helper.auto_updater.subprocess.Popen") as fake_popen, \
         patch("meeting_helper.auto_updater.time.sleep"), \
         patch.object(cfg_module, "MENUBAR_PID_FILE", fake_pid_file):
        auto_updater._trigger_post_update_restart("9.9.9")
        fake_popen.assert_not_called()
        fake_kill.assert_not_called()


def test_trigger_post_update_restart_does_not_kill_self_when_daemon_spawn_fails(tmp_path):
    """If spawning the new daemon fails, do NOT self-SIGTERM."""
    from meeting_helper import config as cfg_module
    fake_pid_file = tmp_path / "menubar.pid"  # does not exist
    with patch("meeting_helper.auto_updater._resolve_cli", return_value="/fake/cli"), \
         patch("meeting_helper.auto_updater.subprocess.Popen", side_effect=OSError("nope")), \
         patch("meeting_helper.auto_updater.time.sleep"), \
         patch("meeting_helper.auto_updater.os.kill") as fake_kill, \
         patch("meeting_helper.auto_updater.os.getpid", return_value=12345), \
         patch.object(cfg_module, "MENUBAR_PID_FILE", fake_pid_file):
        auto_updater._trigger_post_update_restart("9.9.9")
    # Self-SIGTERM (12345) must NOT have fired. Menubar kill might have
    # — that's fine; assert only on the self-kill not happening.
    assert (12345, 15) not in [c.args for c in fake_kill.call_args_list]


def test_trigger_post_update_restart_happy_path_spawns_then_kills(tmp_path):
    from meeting_helper import config as cfg_module
    fake_pid_file = tmp_path / "menubar.pid"  # does not exist
    with patch("meeting_helper.auto_updater._resolve_cli", return_value="/fake/cli"), \
         patch("meeting_helper.auto_updater.subprocess.Popen") as fake_popen, \
         patch("meeting_helper.auto_updater.time.sleep"), \
         patch("meeting_helper.auto_updater.os.kill") as fake_kill, \
         patch("meeting_helper.auto_updater.os.getpid", return_value=12345), \
         patch.object(cfg_module, "MENUBAR_PID_FILE", fake_pid_file):
        auto_updater._trigger_post_update_restart("9.9.9")
        # Two Popen calls: `start` and `gui`
        assert fake_popen.call_count == 2
        cmds = [call.args[0] for call in fake_popen.call_args_list]
        assert ["/fake/cli", "start"] in cmds
        assert ["/fake/cli", "gui"] in cmds
        fake_kill.assert_called_once_with(12345, 15)  # SIGTERM = 15


def test_trigger_post_update_restart_kills_old_menubar_and_spawns_gui(tmp_path):
    """Happy path: menubar is killed, new daemon + GUI both spawned, self-SIGTERM fires."""
    from meeting_helper import config as cfg_module
    fake_pid_file = tmp_path / "menubar.pid"
    fake_pid_file.write_text("99999")

    with patch("meeting_helper.auto_updater._resolve_cli", return_value="/fake/cli"), \
         patch("meeting_helper.auto_updater.subprocess.Popen") as fake_popen, \
         patch("meeting_helper.auto_updater.time.sleep"), \
         patch("meeting_helper.auto_updater.os.kill") as fake_kill, \
         patch("meeting_helper.auto_updater.os.getpid", return_value=12345), \
         patch.object(cfg_module, "MENUBAR_PID_FILE", fake_pid_file):
        auto_updater._trigger_post_update_restart("9.9.9")

    # Two Popen calls: `start` and `gui`
    assert fake_popen.call_count == 2
    cmds = [call.args[0] for call in fake_popen.call_args_list]
    assert ["/fake/cli", "start"] in cmds
    assert ["/fake/cli", "gui"] in cmds

    # os.kill called twice: once for the old menubar (99999, SIGTERM=15)
    # and once for self (12345, SIGTERM=15).
    kill_calls = [call.args for call in fake_kill.call_args_list]
    assert (99999, 15) in kill_calls
    assert (12345, 15) in kill_calls

    # PID file should be wiped.
    assert not fake_pid_file.exists()


def test_version_tuple_parsing():
    from meeting_helper.auto_updater import _version_tuple
    assert _version_tuple("2.7.5") == (2, 7, 5)
    assert _version_tuple("2.10.0") == (2, 10, 0)
    assert _version_tuple(" 1.0 ") == (1, 0)
    # Non-numeric components (pre-releases, dev builds) -> unparseable
    assert _version_tuple("2.7.5rc1") is None
    assert _version_tuple("2.7.5.dev0") is None
    assert _version_tuple("") is None


def test_is_outdated_uses_numeric_comparison_and_never_downgrades():
    from meeting_helper.auto_updater import _is_outdated
    assert _is_outdated("2.7.5", "2.7.6") is True
    assert _is_outdated("2.7.5", "2.7.5") is False
    # A local build ahead of PyPI must NOT be flagged for "upgrade".
    assert _is_outdated("2.7.6", "2.7.5") is False
    # Numeric, not lexical: 10 > 9.
    assert _is_outdated("2.9.0", "2.10.0") is True
    # Unparseable version -> conservative fall back to inequality.
    assert _is_outdated("2.7.5", "2.7.5.dev0") is True


def test_attempt_update_logs_editable_notice_once(tmp_path):
    """The editable-install notice is INFO once, then DEBUG — not spammed every tick."""
    import logging
    from meeting_helper import auto_updater

    auto_updater._editable_notice_logged = False
    with patch.object(
        auto_updater, "is_editable_install", return_value=(True, "/some/dev/path")
    ):
        with patch.object(auto_updater.logger, "info") as info, \
             patch.object(auto_updater.logger, "debug") as debug:
            assert auto_updater.attempt_update() is None
            assert auto_updater.attempt_update() is None
            assert auto_updater.attempt_update() is None
    assert info.call_count == 1
    assert debug.call_count == 2
    # Reset module state so other tests aren't affected.
    auto_updater._editable_notice_logged = False


def test_upgrade_to_latest_retries_through_index_lag():
    """First pipx runs are no-ops (new wheel not on the simple index yet);
    once the on-disk version finally advances we return it."""
    from meeting_helper import auto_updater

    versions = iter(["2.7.8", "2.7.8", "2.7.9"])  # 3rd pipx run finally lands it
    with patch.object(auto_updater, "run_pipx_upgrade", return_value=(True, "ok")), \
         patch.object(auto_updater, "_installed_version", side_effect=lambda: next(versions)), \
         patch.object(auto_updater.time, "sleep") as sleep:
        assert auto_updater.upgrade_to_latest("2.7.9", "2.7.8") == "2.7.9"
        assert sleep.call_count == 2  # slept before the 2nd and 3rd attempts


def test_upgrade_to_latest_gives_up_when_version_never_advances():
    from meeting_helper import auto_updater

    with patch.object(auto_updater, "run_pipx_upgrade", return_value=(True, "ok")), \
         patch.object(auto_updater, "_installed_version", return_value="2.7.8"), \
         patch.object(auto_updater.time, "sleep"):
        assert auto_updater.upgrade_to_latest("2.7.9", "2.7.8") is None


def test_upgrade_to_latest_falls_back_to_target_when_probe_fails():
    """If we can't read the on-disk version, trust pipx's exit code (old
    behaviour) rather than getting stuck."""
    from meeting_helper import auto_updater

    with patch.object(auto_updater, "run_pipx_upgrade", return_value=(True, "ok")), \
         patch.object(auto_updater, "_installed_version", return_value=None), \
         patch.object(auto_updater.time, "sleep"):
        assert auto_updater.upgrade_to_latest("2.7.9", "2.7.8") == "2.7.9"


def test_attempt_update_skips_restart_when_upgrade_never_lands():
    """`pipx upgrade` keeps exiting 0 without installing anything — we must
    NOT tear down our processes; the next tick will retry."""
    from meeting_helper import auto_updater

    auto_updater._editable_notice_logged = False
    with patch.object(auto_updater, "is_editable_install", return_value=(False, None)), \
         patch.object(auto_updater, "fetch_latest_version", return_value="2.7.9"), \
         patch.object(auto_updater, "__version__", "2.7.8"), \
         patch.object(auto_updater, "upgrade_to_latest", return_value=None), \
         patch.object(auto_updater, "_trigger_post_update_restart") as restart:
        assert auto_updater.attempt_update() is None
        restart.assert_not_called()


def test_attempt_update_restarts_with_verified_version():
    from meeting_helper import auto_updater

    auto_updater._editable_notice_logged = False
    with patch.object(auto_updater, "is_editable_install", return_value=(False, None)), \
         patch.object(auto_updater, "fetch_latest_version", return_value="2.7.9"), \
         patch.object(auto_updater, "__version__", "2.7.8"), \
         patch.object(auto_updater, "upgrade_to_latest", return_value="2.7.9"), \
         patch.object(auto_updater, "_refresh_or_install_app_bundle"), \
         patch.object(auto_updater, "_trigger_post_update_restart") as restart:
        assert auto_updater.attempt_update() == "2.7.9"
        restart.assert_called_once_with("2.7.9")


def test_refresh_app_bundle_rebuilds_when_installed(tmp_path):
    """If the bundle already exists, the auto-updater rebuilds it with the new version."""
    from meeting_helper import auto_updater

    fake_bundle = tmp_path / "Applications" / "Meeting Helper.app"
    fake_bundle.mkdir(parents=True)

    with patch("sys.platform", "darwin"), \
         patch("meeting_helper.install_app._user_install_path", return_value=fake_bundle), \
         patch("meeting_helper.install_app.build_app") as build, \
         patch("meeting_helper.install_app.ensure_app_bundle_installed") as ensure:
        auto_updater._refresh_or_install_app_bundle("9.9.9")
    build.assert_called_once_with(fake_bundle, version="9.9.9")
    # Existing-bundle branch must NOT also call ensure_app_bundle_installed.
    ensure.assert_not_called()


def test_refresh_app_bundle_installs_when_missing_and_marker_absent(tmp_path):
    """No bundle on disk + no marker => one-time install via ensure_app_bundle_installed."""
    from meeting_helper import auto_updater

    fake_bundle = tmp_path / "Applications" / "Meeting Helper.app"
    # Intentionally do not mkdir.
    installed_dest = tmp_path / "Applications" / "Meeting Helper.app"

    with patch("sys.platform", "darwin"), \
         patch("meeting_helper.install_app._user_install_path", return_value=fake_bundle), \
         patch("meeting_helper.install_app.build_app") as build, \
         patch(
             "meeting_helper.install_app.ensure_app_bundle_installed",
             return_value=installed_dest,
         ) as ensure:
        auto_updater._refresh_or_install_app_bundle("9.9.9")
    # Existing-bundle build path NOT taken (no dir).
    build.assert_not_called()
    # First-launch helper IS called and reports it installed.
    ensure.assert_called_once_with()


def test_refresh_app_bundle_respects_marker_when_user_uninstalled(tmp_path):
    """Bundle missing + marker present => ensure_app_bundle_installed returns
    None and we do NOT call build_app. The user opted out by deleting the bundle."""
    from meeting_helper import auto_updater

    fake_bundle = tmp_path / "Applications" / "Meeting Helper.app"
    # Intentionally do not mkdir — bundle is gone.

    with patch("sys.platform", "darwin"), \
         patch("meeting_helper.install_app._user_install_path", return_value=fake_bundle), \
         patch("meeting_helper.install_app.build_app") as build, \
         patch(
             "meeting_helper.install_app.ensure_app_bundle_installed",
             return_value=None,
         ) as ensure:
        auto_updater._refresh_or_install_app_bundle("9.9.9")
    build.assert_not_called()
    ensure.assert_called_once_with()


def test_refresh_app_bundle_swallows_errors(tmp_path):
    """A broken bundle rebuild must not crash the auto-updater path."""
    from meeting_helper import auto_updater

    fake_bundle = tmp_path / "Applications" / "Meeting Helper.app"
    fake_bundle.mkdir(parents=True)

    with patch("sys.platform", "darwin"), \
         patch("meeting_helper.install_app._user_install_path", return_value=fake_bundle), \
         patch(
             "meeting_helper.install_app.build_app",
             side_effect=RuntimeError("disk full"),
         ):
        # Should not raise.
        auto_updater._refresh_or_install_app_bundle("9.9.9")


def test_refresh_app_bundle_skipped_on_non_darwin(tmp_path):
    """Linux/Windows daemons must not try to install the macOS-only .app bundle."""
    from meeting_helper import auto_updater

    with patch("meeting_helper.auto_updater.sys") as fake_sys, \
         patch("meeting_helper.install_app._user_install_path") as user_path, \
         patch("meeting_helper.install_app.ensure_app_bundle_installed") as ensure:
        fake_sys.platform = "linux"
        auto_updater._refresh_or_install_app_bundle("9.9.9")
    user_path.assert_not_called()
    ensure.assert_not_called()


def test_attempt_update_refreshes_bundle_before_restart():
    """The refresh happens before the restart broadcast so the new processes
    inherit a fresh bundle on launch."""
    from meeting_helper import auto_updater

    auto_updater._editable_notice_logged = False
    call_order: list[str] = []
    with patch.object(auto_updater, "is_editable_install", return_value=(False, None)), \
         patch.object(auto_updater, "fetch_latest_version", return_value="2.7.9"), \
         patch.object(auto_updater, "__version__", "2.7.8"), \
         patch.object(auto_updater, "upgrade_to_latest", return_value="2.7.9"), \
         patch.object(
             auto_updater,
             "_refresh_or_install_app_bundle",
             side_effect=lambda v: call_order.append(f"refresh:{v}"),
         ), \
         patch.object(
             auto_updater,
             "_trigger_post_update_restart",
             side_effect=lambda v: call_order.append(f"restart:{v}"),
         ):
        assert auto_updater.attempt_update() == "2.7.9"
    assert call_order == ["refresh:2.7.9", "restart:2.7.9"]
