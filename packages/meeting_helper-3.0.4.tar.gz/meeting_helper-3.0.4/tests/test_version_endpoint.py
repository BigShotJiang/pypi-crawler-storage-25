"""Tests for /version — daemon vs installed vs PyPI latest.

The sidebar footer renders this. We monkeypatch the auto-updater so the
test never actually hits PyPI, and the importlib.metadata lookup so we
can simulate "pipx upgrade has happened, daemon not yet restarted".
"""

from __future__ import annotations

import json

import pytest
from aiohttp.test_utils import make_mocked_request

from meeting_helper.server.routes import version_handler


def _patch_installed(monkeypatch, value: str) -> None:
    """Force importlib.metadata.version('meeting-helper') to return `value`."""
    import importlib.metadata as md

    monkeypatch.setattr(md, "version", lambda name: value)


@pytest.mark.asyncio
async def test_version_handler_returns_daemon_and_installed(monkeypatch):
    from meeting_helper import auto_updater
    monkeypatch.setattr(auto_updater, "fetch_latest_version", lambda: None)
    req = make_mocked_request("GET", "/version")
    resp = await version_handler(req)
    data = json.loads(resp.text)
    import meeting_helper
    assert data["version"] == meeting_helper.__version__
    assert data["daemon_version"] == meeting_helper.__version__
    assert data["installed_version"] == meeting_helper.__version__
    assert data["latest"] is None
    assert data["latest_version"] is None
    assert data["outdated"] is False
    assert data["update_available"] is False
    assert data["restart_needed"] is False


@pytest.mark.asyncio
async def test_version_handler_marks_outdated_when_pypi_is_newer(monkeypatch):
    from meeting_helper import auto_updater
    import meeting_helper
    monkeypatch.setattr(meeting_helper, "__version__", "1.0.0")
    _patch_installed(monkeypatch, "1.0.0")
    monkeypatch.setattr(auto_updater, "fetch_latest_version", lambda: "1.0.1")
    req = make_mocked_request("GET", "/version")
    resp = await version_handler(req)
    data = json.loads(resp.text)
    assert data["daemon_version"] == "1.0.0"
    assert data["installed_version"] == "1.0.0"
    assert data["latest_version"] == "1.0.1"
    assert data["outdated"] is True
    assert data["update_available"] is True
    assert data["restart_needed"] is False


@pytest.mark.asyncio
async def test_version_handler_flags_restart_when_daemon_behind_installed(monkeypatch):
    """The bug: pipx already upgraded the package on disk, but the daemon
    is still running the old code. UI should offer Restart, not Update."""
    from meeting_helper import auto_updater
    import meeting_helper
    monkeypatch.setattr(meeting_helper, "__version__", "2.8.8")
    _patch_installed(monkeypatch, "3.0.2")
    monkeypatch.setattr(auto_updater, "fetch_latest_version", lambda: "3.0.2")
    req = make_mocked_request("GET", "/version")
    resp = await version_handler(req)
    data = json.loads(resp.text)
    assert data["daemon_version"] == "2.8.8"
    assert data["installed_version"] == "3.0.2"
    assert data["latest_version"] == "3.0.2"
    # NOT outdated — installed_version matches PyPI. Only the running
    # daemon is stale, which is a restart-needed state, not an update-needed state.
    assert data["outdated"] is False
    assert data["update_available"] is False
    assert data["restart_needed"] is True


@pytest.mark.asyncio
async def test_version_handler_handles_same_version(monkeypatch):
    from meeting_helper import auto_updater
    import meeting_helper
    monkeypatch.setattr(meeting_helper, "__version__", "2.0.0")
    _patch_installed(monkeypatch, "2.0.0")
    monkeypatch.setattr(auto_updater, "fetch_latest_version", lambda: "2.0.0")
    req = make_mocked_request("GET", "/version")
    resp = await version_handler(req)
    data = json.loads(resp.text)
    assert data["latest"] == "2.0.0"
    assert data["outdated"] is False
    assert data["restart_needed"] is False


@pytest.mark.asyncio
async def test_version_handler_swallows_pypi_failure(monkeypatch):
    from meeting_helper import auto_updater

    def _boom() -> str:
        raise RuntimeError("network down")

    monkeypatch.setattr(auto_updater, "fetch_latest_version", _boom)
    req = make_mocked_request("GET", "/version")
    resp = await version_handler(req)
    data = json.loads(resp.text)
    import meeting_helper
    assert data["version"] == meeting_helper.__version__
    assert data["latest"] is None
    assert data["outdated"] is False
    assert data["restart_needed"] is False


@pytest.mark.asyncio
async def test_version_handler_falls_back_when_metadata_missing(monkeypatch):
    """Editable installs (source checkout) have no package metadata; we
    must fall back to the daemon's in-process __version__ so the UI
    doesn't show a phantom restart prompt during development."""
    from meeting_helper import auto_updater
    import meeting_helper
    from importlib.metadata import PackageNotFoundError
    import importlib.metadata as md
    monkeypatch.setattr(meeting_helper, "__version__", "9.9.9")

    def _missing(_name: str) -> str:
        raise PackageNotFoundError("meeting-helper")

    monkeypatch.setattr(md, "version", _missing)
    monkeypatch.setattr(auto_updater, "fetch_latest_version", lambda: None)
    req = make_mocked_request("GET", "/version")
    resp = await version_handler(req)
    data = json.loads(resp.text)
    assert data["installed_version"] == "9.9.9"
    assert data["restart_needed"] is False
