"""End-to-end meeting simulation — no hardware, no real Deepgram.

Drives the SAME data flow the real session uses (transcriber → buffer →
listeners → live transcript file + WS broadcast), with every external
dependency mocked. A regression in any of the wiring blows up here
instead of waiting for a live meeting to surface it.

What's simulated:
- Audio capture (synthetic numpy chunks pushed into queues).
- Deepgram transcription (we invoke `_on_message` directly with fake
  `result` objects, exactly the shape the real Deepgram SDK delivers).
- WS broadcast (captured into a list so we can assert what GUI clients
  would have seen).

What's real:
- `SentenceBuffer`, `LiveTranscriptWriter`, the listener wiring, the
  `_broadcast_transcript` coroutine path, `CombinedAudioCapture._process_audio_loop`.

The point is to give the human reviewer (and CI) a single test that
fails loudly if any link in the live-meeting chain breaks.
"""

from __future__ import annotations

import asyncio
import threading
import time
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import AsyncMock, MagicMock, patch

import numpy as np
import pytest


# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------

def _fake_deepgram_result(transcript: str, *, is_final: bool):
    """Build an object shaped like the Deepgram SDK's LiveTranscriptionResponse,
    just with the fields _on_message reads."""
    alt = SimpleNamespace(transcript=transcript)
    channel = SimpleNamespace(alternatives=[alt])
    return SimpleNamespace(channel=channel, is_final=is_final)


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

def test_full_meeting_simulation_buffers_and_live_transcript(tmp_path: Path):
    """Simulate ~30 s of meeting traffic. Verify finalized sentences land in
    SentenceBuffer AND in the .live.txt file in chronological order."""
    from meeting_helper.audio.transcriber import DeepgramTranscriber
    from meeting_helper.buffer import SentenceBuffer
    from meeting_helper.live_transcript import LiveTranscriptWriter

    # Real buffers + writer (the modules we want to exercise).
    self_buf = SentenceBuffer(role="self")
    other_buf = SentenceBuffer(role="other")
    transcript_path = tmp_path / "meeting.live.txt"

    # Deterministic clock so timestamps in .live.txt are predictable.
    clock_state = {"t": 0.0}
    def fake_clock() -> float:
        return clock_state["t"]

    writer = LiveTranscriptWriter(
        transcript_path, t0=0.0, clock=fake_clock,
    )
    self_buf.add_sentence_listener(lambda s: writer.append("SELF", s))
    other_buf.add_sentence_listener(lambda s: writer.append("OTHER", s))

    # Build two transcribers (one per role) but never call .start() — we
    # exercise their public surface (_on_message) directly with fake results.
    capture = MagicMock()
    capture.get_transcriber_audio = MagicMock(return_value=None)
    self_t = DeepgramTranscriber(
        audio_capture=capture, transcript_buffer=self_buf,
        api_key="fake-key", language="en",
    )
    other_t = DeepgramTranscriber(
        audio_capture=capture, transcript_buffer=other_buf,
        api_key="fake-key", language="en",
    )

    # Capture broadcast calls. The real `_broadcast_transcript` is invoked
    # via `_schedule_threadsafe` which posts to an asyncio loop. For the
    # test we cut out the threadsafe hop entirely and capture the message
    # the coroutine WOULD have awaited — same observable signal, no event
    # loop drama.
    broadcasts: list[dict] = []

    def capture_schedule(coro, _loop, _label):
        # _broadcast_transcript is a small coroutine that awaits broadcast(msg).
        # Inspect its frame to grab the args without running it (avoids the
        # "coroutine never awaited" warning AND lets us assert the payload).
        # Easier: build a fresh loop per call and run the coroutine to
        # completion with `broadcast` patched.
        async def _runner():
            try:
                await coro
            except Exception:
                pass
        # Use a brand new loop each time so prior-test loop state can't
        # leak in.
        loop = asyncio.new_event_loop()
        try:
            loop.run_until_complete(_runner())
        finally:
            loop.close()

    async def fake_broadcast(message: dict) -> None:
        broadcasts.append(message)

    # The script: list of (clock_time, role_transcriber, transcript, is_final)
    script = [
        (1.0, self_t, "Hey team", False),
        (1.2, self_t, "Hey team, how's it going?", True),
        (3.5, other_t, "Pretty good", False),
        (3.8, other_t, "Pretty good, just shipped the migration.", True),
        (8.0, self_t, "Nice. Any rollback issues?", True),
        (12.0, other_t, "None so far. We're watching the dashboards.", True),
    ]

    from meeting_helper import state as state_module
    fake_loop = MagicMock()
    with patch("meeting_helper.server.websocket.broadcast", side_effect=fake_broadcast), \
         patch("meeting_helper.audio.transcriber._schedule_threadsafe", side_effect=capture_schedule), \
         patch.object(state_module.state, "asyncio_loop", fake_loop):
        for t, transcriber, text, final in script:
            clock_state["t"] = t
            transcriber._on_message(
                None, result=_fake_deepgram_result(text, is_final=final),
            )

    writer.close()

    # ---- Assertions ----
    # SentenceBuffer captured the FINAL sentences only.
    self_finals = self_buf.get_last_n()
    other_finals = other_buf.get_last_n()
    assert self_finals == [
        "Hey team, how's it going?",
        "Nice. Any rollback issues?",
    ]
    assert other_finals == [
        "Pretty good, just shipped the migration.",
        "None so far. We're watching the dashboards.",
    ]

    # .live.txt was written with the right timestamps and roles.
    content = transcript_path.read_text()
    assert "[00:01] SELF: Hey team, how's it going?" in content
    assert "[00:03] OTHER: Pretty good, just shipped the migration." in content
    assert "[00:08] SELF: Nice. Any rollback issues?" in content
    assert "[00:12] OTHER: None so far. We're watching the dashboards." in content

    # Broadcast was fired for every message (interim + final, both roles).
    transcript_broadcasts = [b for b in broadcasts if b.get("type") == "transcript"]
    assert len(transcript_broadcasts) == len(script)
    finals_broadcast = [b for b in transcript_broadcasts if not b["interim"]]
    assert len(finals_broadcast) == 4
    interims_broadcast = [b for b in transcript_broadcasts if b["interim"]]
    assert len(interims_broadcast) == 2
    # Roles are correctly tagged.
    assert {b["role"] for b in transcript_broadcasts} == {"self", "other"}


def test_audio_pump_pushes_synthetic_chunks_to_transcribe_queues():
    """Drive `CombinedAudioCapture._process_audio_loop` directly: push
    synthetic mic + system frames into its source queues, run the loop
    briefly, assert chunks land in the per-role transcribe queues with
    the right shape and ratio."""
    from meeting_helper.audio.capture import CombinedAudioCapture

    cap = CombinedAudioCapture(sample_rate=16000)
    # Fake the underlying capture sources so the loop can read from them.
    fake_mic = MagicMock()
    fake_sys = MagicMock()
    fake_sys.is_running = True

    # Pre-load each source with 320 samples × 5 = 100 ms of audio per role.
    mic_frames = [np.full(320, 0.5, dtype=np.float32) for _ in range(5)]
    sys_frames = [np.full(320, 0.3, dtype=np.float32) for _ in range(5)]

    mic_queue: list = list(mic_frames)
    sys_queue: list = list(sys_frames)

    def mic_get_audio(timeout: float = 0):
        return mic_queue.pop(0) if mic_queue else None

    def sys_get_audio(timeout: float = 0):
        return sys_queue.pop(0) if sys_queue else None

    fake_mic.get_audio = mic_get_audio
    fake_sys.get_audio = sys_get_audio
    cap._mic_capture = fake_mic
    cap._system_capture = fake_sys
    cap._has_system_audio = True

    # Run the loop in a thread for ~150 ms then signal stop. That's enough
    # iterations to drain the pre-loaded frames into chunks.
    t = threading.Thread(target=cap._process_audio_loop, daemon=True)
    t.start()
    time.sleep(0.15)
    cap.stop_event.set()
    t.join(timeout=1.0)

    # Each role had 5×320 = 1600 samples; chunk_size=320; so 5 chunks each.
    assert cap._mic_transcribe_q.qsize() == 5
    assert cap._sys_transcribe_q.qsize() == 5
    # Chunks have the right shape.
    sample = cap._mic_transcribe_q.get_nowait()
    assert sample.shape == (320,)
    assert sample.dtype == np.float32
    # Mixed audio also got dispatched to recording queue.
    assert cap.audio_queue.qsize() == 5


def test_health_monitor_detects_dead_transcriber_thread():
    """If a transcriber's feed thread dies, the health monitor's
    is_alive() check is the trigger for respawn. This test verifies the
    check works against a real `threading.Thread` that has exited."""
    from meeting_helper.audio.transcriber import DeepgramTranscriber

    capture = MagicMock()
    capture.get_transcriber_audio = MagicMock(return_value=None)
    buf = MagicMock()
    buf.role = "self"
    t = DeepgramTranscriber(
        audio_capture=capture, transcript_buffer=buf,
        api_key="fake-key", language="en",
    )
    # Simulate a thread that already exited.
    dead_thread = threading.Thread(target=lambda: None)
    dead_thread.start()
    dead_thread.join()
    t._thread = dead_thread
    # The health monitor pattern:
    assert t._thread is not None
    assert t._thread.is_alive() is False


def test_deepgram_message_path_invariant():
    """Sanity: the shape of the fake Deepgram result we use in the e2e
    test must match what `_on_message` actually consumes."""
    from meeting_helper.audio.transcriber import DeepgramTranscriber
    from meeting_helper.buffer import SentenceBuffer

    capture = MagicMock()
    buf = SentenceBuffer(role="self")
    tr = DeepgramTranscriber(
        audio_capture=capture, transcript_buffer=buf,
        api_key="x", language="en",
    )

    fake = _fake_deepgram_result("test sentence", is_final=True)
    # Patch the threadsafe scheduler so we don't depend on a loop here.
    from meeting_helper import state as state_module
    with patch("meeting_helper.audio.transcriber._schedule_threadsafe"), \
         patch.object(state_module.state, "asyncio_loop", MagicMock()):
        tr._on_message(None, result=fake)

    assert buf.get_last_n() == ["test sentence"]
