"""Tests for /transcriber/whisper/health, /transcriber/ollama/health, /ollama/models.

These daemon endpoints proxy-ping remote services (Whisper /health, Ollama
/api/tags) and surface a connectivity badge in Settings. We mock the upstream
by spinning a tiny aiohttp app on a random port — same shape as the real
Whisper/Ollama services. The unreachable cases use a guaranteed-closed port
(port 1) so we don't depend on filesystem state or external network.
"""

from __future__ import annotations

import json

import pytest
from aiohttp import web

from meeting_helper.config import AppConfig
from meeting_helper.server.app import create_app


@pytest.fixture
async def app_client(aiohttp_client):
    return await aiohttp_client(create_app(AppConfig()))


async def _start_upstream(aiohttp_server, handler_map: dict[str, web.Application]):
    """Spin a local aiohttp server with the given route → handler map. Returns
    the bound server (use `.make_url("/path")` to fetch the host base)."""
    app = web.Application()
    for path, handler in handler_map.items():
        app.router.add_get(path, handler)
    return await aiohttp_server(app)


async def test_whisper_health_ok(app_client, aiohttp_server):
    async def whisper_health(_req: web.Request) -> web.Response:
        return web.json_response({"status": "ok"})

    upstream = await _start_upstream(aiohttp_server, {"/health": whisper_health})
    host = f"http://{upstream.host}:{upstream.port}"

    resp = await app_client.get("/transcriber/whisper/health", params={"host": host})
    assert resp.status == 200
    body = await resp.json()
    assert body["ok"] is True
    assert body["host"] == host


async def test_whisper_health_unreachable(app_client):
    # Port 1 is reserved (tcpmux) and not listening on dev machines — the
    # connection refuses immediately, exercising the OSError path.
    resp = await app_client.get(
        "/transcriber/whisper/health", params={"host": "http://127.0.0.1:1"}
    )
    assert resp.status == 200
    body = await resp.json()
    assert body["ok"] is False
    assert body["host"] == "http://127.0.0.1:1"
    assert "error" in body and body["error"]


async def test_ollama_health_ok(app_client, aiohttp_server):
    async def ollama_tags(_req: web.Request) -> web.Response:
        return web.json_response({"models": []})

    upstream = await _start_upstream(aiohttp_server, {"/api/tags": ollama_tags})
    host = f"http://{upstream.host}:{upstream.port}"

    resp = await app_client.get("/transcriber/ollama/health", params={"host": host})
    assert resp.status == 200
    body = await resp.json()
    assert body["ok"] is True
    assert body["host"] == host


async def test_ollama_health_unreachable(app_client):
    resp = await app_client.get(
        "/transcriber/ollama/health", params={"host": "http://127.0.0.1:1"}
    )
    assert resp.status == 200
    body = await resp.json()
    assert body["ok"] is False
    assert body["host"] == "http://127.0.0.1:1"
    assert "error" in body and body["error"]


async def test_ollama_models_lists_installed(app_client, aiohttp_server):
    payload = {
        "models": [
            {"name": "qwen2.5-coder:3b", "size": 0},
            {"name": "llama3.2:1b", "size": 0},
            # Bogus shapes — handler should silently skip these instead of
            # blowing up on the dropdown rendering side.
            {"no_name_field": True},
            "not-a-dict",
            None,
        ]
    }

    async def ollama_tags(_req: web.Request) -> web.Response:
        return web.json_response(payload)

    upstream = await _start_upstream(aiohttp_server, {"/api/tags": ollama_tags})
    host = f"http://{upstream.host}:{upstream.port}"

    resp = await app_client.get("/ollama/models", params={"host": host})
    assert resp.status == 200
    body = await resp.json()
    assert body["ok"] is True
    assert body["host"] == host
    assert body["models"] == ["qwen2.5-coder:3b", "llama3.2:1b"]


async def test_ollama_models_unreachable(app_client):
    resp = await app_client.get(
        "/ollama/models", params={"host": "http://127.0.0.1:1"}
    )
    assert resp.status == 200
    body = await resp.json()
    assert body["ok"] is False
    assert body["models"] == []
    assert "error" in body and body["error"]


async def test_ollama_models_invalid_json_upstream(app_client, aiohttp_server):
    async def bogus(_req: web.Request) -> web.Response:
        return web.Response(text="not json", content_type="application/json")

    upstream = await _start_upstream(aiohttp_server, {"/api/tags": bogus})
    host = f"http://{upstream.host}:{upstream.port}"

    resp = await app_client.get("/ollama/models", params={"host": host})
    assert resp.status == 200
    body = await resp.json()
    assert body["ok"] is False
    assert body["models"] == []
    assert "error" in body and body["error"]
