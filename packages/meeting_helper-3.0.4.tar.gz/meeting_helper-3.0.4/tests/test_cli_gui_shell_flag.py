"""Tests for the `meeting-helper gui` command after Plan 4 cutover."""

from __future__ import annotations

from unittest.mock import patch

from click.testing import CliRunner

from meeting_helper.cli import cli


def test_gui_launches_shell():
    runner = CliRunner()
    with patch("subprocess.Popen") as popen, patch(
        "meeting_helper.cli._ensure_menubar"
    ):
        result = runner.invoke(cli, ["gui"])
    assert result.exit_code == 0, result.output
    args_list = [call.args[0] for call in popen.call_args_list]
    cmds = [a for a in args_list if isinstance(a, list)]
    assert any("meeting_helper.shell" in " ".join(cmd) for cmd in cmds)
    assert not any("meeting_helper.flet_gui" in " ".join(cmd) for cmd in cmds)


def test_gui_foreground_runs_shell_main_inline():
    runner = CliRunner()
    with patch("meeting_helper.cli._ensure_menubar"), \
         patch("meeting_helper.shell.__main__.main", return_value=0) as shell_main, \
         patch("subprocess.Popen") as popen:
        result = runner.invoke(cli, ["gui", "--foreground"])
    # --foreground should call shell_main directly, NOT spawn a subprocess.
    assert result.exit_code == 0
    shell_main.assert_called_once()
    popen.assert_not_called()


def test_gui_without_foreground_uses_subprocess():
    runner = CliRunner()
    with patch("meeting_helper.cli._ensure_menubar"), \
         patch("subprocess.Popen") as popen, \
         patch("meeting_helper.shell.__main__.main") as shell_main:
        result = runner.invoke(cli, ["gui"])
    assert result.exit_code == 0
    popen.assert_called_once()
    shell_main.assert_not_called()
