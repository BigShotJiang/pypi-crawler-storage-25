"""POST /config must write each accepted field to the workspace JSON on disk.

Plan 2 hooked the Next.js Settings tabs up to `/config`, and a prior round
plumbed every field through the in-memory ``AppConfig`` snapshot. That fixed
the same-session experience but the daemon caches its `AppConfig` at startup
and reloads from disk — so without a disk mirror, every saved Setting reverts
on the next daemon restart. These tests pin the disk-side persistence by
re-reading the workspace JSON file directly after each POST.

We point `WORKSPACES_DIR`/`STATE_FILE`/etc. at a tmp dir, then read
``workspaces/default.json`` through the filesystem (NOT through the in-memory
snapshot) so the assertion only passes if `.save()` was actually invoked.
"""

from __future__ import annotations

import json

import pytest

from meeting_helper import config as config_mod
from meeting_helper.config import AppConfig
from meeting_helper.server.app import create_app


@pytest.fixture
def isolated_config(tmp_path, monkeypatch):
    """Point the Config module at a tmp workspace dir and reset its cache.

    Without resetting `_config`, the module-level cache from a previous test
    (or the session-scoped reload fixture) would short-circuit `get_config()`
    in the handler and we'd write to the wrong file.
    """
    ws_dir = tmp_path / "workspaces"
    monkeypatch.setattr(config_mod, "DEFAULT_CONFIG_DIR", tmp_path)
    monkeypatch.setattr(config_mod, "WORKSPACES_DIR", ws_dir)
    monkeypatch.setattr(config_mod, "STATE_FILE", tmp_path / "state.json")
    monkeypatch.setattr(
        config_mod, "LEGACY_CONFIG_FILE", tmp_path / "config.json.legacy"
    )
    monkeypatch.setattr(
        config_mod, "LEGACY_BACKUP", tmp_path / "config.bak"
    )
    monkeypatch.setattr(config_mod, "_config", None)
    yield ws_dir / "default.json"
    # Reset the cache so the next test doesn't inherit a Config bound to tmp.
    monkeypatch.setattr(config_mod, "_config", None)


@pytest.fixture
async def app_client(aiohttp_client, isolated_config):
    app = create_app(AppConfig())
    return await aiohttp_client(app)


def _load_disk(ws_file):
    """Read the workspace JSON straight off disk — bypasses any cache."""
    assert ws_file.exists(), (
        f"workspace JSON missing at {ws_file}; /config POST never called .save()"
    )
    return json.loads(ws_file.read_text())


async def test_config_post_persists_anthropic_api_key(app_client, isolated_config):
    sentinel = "sk-persist-test-anthropic"
    resp = await app_client.post("/config", json={"anthropic_api_key": sentinel})
    assert resp.status == 200

    disk = _load_disk(isolated_config)
    assert disk["anthropic_api_key"] == sentinel


async def test_config_post_persists_recordings_dir(app_client, isolated_config):
    target = "/tmp/mh-persist-recordings"
    resp = await app_client.post("/config", json={"recordings_dir": target})
    assert resp.status == 200

    disk = _load_disk(isolated_config)
    assert disk["recordings_dir"] == target


async def test_config_post_persists_auto_rename_bool(app_client, isolated_config):
    resp = await app_client.post("/config", json={"auto_rename_on_end": True})
    assert resp.status == 200

    disk = _load_disk(isolated_config)
    assert disk["auto_rename_on_end"] is True


async def test_config_post_persists_ai_provider_order_list(
    app_client, isolated_config,
):
    order = ["google", "anthropic"]
    resp = await app_client.post("/config", json={"ai_provider_order": order})
    assert resp.status == 200

    disk = _load_disk(isolated_config)
    assert disk["ai_provider_order"] == order


async def test_config_post_persists_local_todo_mcp_dict(
    app_client, isolated_config,
):
    mcp = {
        "type": "stdio",
        "command": "persist-test-cmd",
        "args": ["--persist"],
        "env": {"TEST": "1"},
        "url": "",
        "headers": {},
    }
    resp = await app_client.post("/config", json={"local_todo_mcp": mcp})
    assert resp.status == 200

    disk = _load_disk(isolated_config)
    assert disk["local_todo_mcp"]["command"] == "persist-test-cmd"
    assert disk["local_todo_mcp"]["args"] == ["--persist"]
    assert disk["local_todo_mcp"]["env"] == {"TEST": "1"}


async def test_config_post_persists_claude_model_alias_under_claude_model_key(
    app_client, isolated_config,
):
    """The Config layer stores aliases under the bare-name key (`claude_model`),
    same convention the /provider handler relies on.
    """
    resp = await app_client.post("/config", json={"claude_model_alias": "opus"})
    assert resp.status == 200

    disk = _load_disk(isolated_config)
    assert disk["claude_model"] == "opus"


async def test_config_post_persists_multiple_fields_in_one_save(
    app_client, isolated_config,
):
    """A single POST with several fields should produce one consistent JSON
    file with all of them, not partial writes from any per-field save races.
    """
    payload = {
        "anthropic_api_key": "sk-multi-persist",
        "google_api_key": "AIza-multi-persist",
        "auto_summarize_on_end": True,
        "ollama_host": "http://persist-host:11434",
        "ai_failover_delay_ms": 750,
    }
    resp = await app_client.post("/config", json=payload)
    assert resp.status == 200

    disk = _load_disk(isolated_config)
    assert disk["anthropic_api_key"] == "sk-multi-persist"
    assert disk["google_api_key"] == "AIza-multi-persist"
    assert disk["auto_summarize_on_end"] is True
    assert disk["ollama_host"] == "http://persist-host:11434"
    assert disk["ai_failover_delay_ms"] == 750
