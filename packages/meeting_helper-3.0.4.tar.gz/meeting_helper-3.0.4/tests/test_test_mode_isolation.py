"""TEST_MODE must redirect every state path off the prod locations."""

from __future__ import annotations

import importlib
import os


def _reload_config(monkeypatch, *, test_mode: bool, home):
    monkeypatch.setenv("HOME", str(home))
    if test_mode:
        monkeypatch.setenv("TEST_MODE", "true")
    else:
        monkeypatch.delenv("TEST_MODE", raising=False)
    import meeting_helper.config as cfg
    return importlib.reload(cfg)


def test_session_baseline_has_test_mode_off(monkeypatch):
    """Sanity: the session-autouse conftest unsets TEST_MODE for the suite,
    so reading cfg as-is (no per-test reload) gives prod paths."""
    import meeting_helper.config as cfg
    # Do NOT touch env here — we want to observe the session baseline state.
    assert cfg._TEST_MODE is False
    assert cfg._SUFFIX == ""
    assert cfg._PORT_OFFSET == 0


def test_test_mode_redirects_paths(tmp_path, monkeypatch):
    cfg = _reload_config(monkeypatch, test_mode=True, home=tmp_path)
    assert "meeting-helper-test" in str(cfg.DEFAULT_CONFIG_DIR)
    assert str(cfg.PID_FILE).endswith("-test.pid") or "-test" in cfg.PID_FILE.name
    assert "-test" in cfg.LOG_FILE.name
    assert "-test" in cfg.META_FILE.name
    assert cfg.WORKSPACES_DIR == cfg.DEFAULT_CONFIG_DIR / "workspaces"


def test_no_test_mode_uses_prod_paths(tmp_path, monkeypatch):
    cfg = _reload_config(monkeypatch, test_mode=False, home=tmp_path)
    assert cfg.DEFAULT_CONFIG_DIR == tmp_path / ".config" / "meeting-helper"
    assert cfg.PID_FILE == tmp_path / ".meeting-helper.pid"


def test_bootstrap_copies_prod_dir(tmp_path, monkeypatch):
    # Lay down a fake prod config dir.
    prod = tmp_path / ".config" / "meeting-helper"
    (prod / "workspaces").mkdir(parents=True)
    (prod / "workspaces" / "default.json").write_text('{"port": 7891}')
    (prod / "state.json").write_text(
        '{"active_workspace": "default", "workspace_order": ["default"]}'
    )

    cfg = _reload_config(monkeypatch, test_mode=True, home=tmp_path)
    assert not cfg.DEFAULT_CONFIG_DIR.exists()
    cfg.bootstrap_test_config_dir()
    assert (cfg.DEFAULT_CONFIG_DIR / "workspaces" / "default.json").exists()
    # Idempotent: a second call does not raise / does not re-copy over edits.
    (cfg.DEFAULT_CONFIG_DIR / "workspaces" / "default.json").write_text('{"port": 7991}')
    cfg.bootstrap_test_config_dir()
    assert '"port": 7991' in (cfg.DEFAULT_CONFIG_DIR / "workspaces" / "default.json").read_text()


def test_port_offset_in_test_mode(tmp_path, monkeypatch):
    prod = tmp_path / ".config" / "meeting-helper"
    (prod / "workspaces").mkdir(parents=True)
    (prod / "workspaces" / "default.json").write_text('{"port": 7891}')
    (prod / "state.json").write_text(
        '{"active_workspace": "default", "workspace_order": ["default"]}'
    )
    cfg = _reload_config(monkeypatch, test_mode=True, home=tmp_path)
    cfg.bootstrap_test_config_dir()
    c = cfg.Config()  # active workspace
    assert c.port == 7991   # 7891 + 100 offset applied in TEST_MODE


# Cleanup: reload config without TEST_MODE so other tests see prod constants.
def teardown_module(module):
    os.environ.pop("TEST_MODE", None)
    import meeting_helper.config as cfg
    importlib.reload(cfg)
