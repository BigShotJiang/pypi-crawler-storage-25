"""Tests for /launcher.command — sidebar 'Download launcher' link."""

from __future__ import annotations

import pytest

from meeting_helper.config import AppConfig
from meeting_helper.server.app import create_app


@pytest.fixture
async def app_client(aiohttp_client):
    return await aiohttp_client(create_app(AppConfig()))


async def test_launcher_command_returns_script_with_attachment_headers(app_client):
    resp = await app_client.get("/launcher.command")
    assert resp.status == 200
    assert resp.headers["Content-Type"].startswith("text/x-shellscript")
    cd = resp.headers["Content-Disposition"]
    assert "attachment" in cd
    assert "Meeting Helper.command" in cd
    body = await resp.text()
    assert body.startswith("#!/bin/bash")
    assert "meeting-helper" in body
