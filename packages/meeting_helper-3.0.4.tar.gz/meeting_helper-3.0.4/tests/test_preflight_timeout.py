"""handle_query must not hang if the pre-flight topic refresh stalls."""

from __future__ import annotations

import asyncio
import pytest

from meeting_helper.config import AppConfig
from meeting_helper.state import AppState


@pytest.mark.asyncio
async def test_preflight_timeout_does_not_block_answer(monkeypatch):
    from meeting_helper.ai import client as c

    async def _hang(*args, **kwargs):
        await asyncio.sleep(60)

    monkeypatch.setattr(c, "_pre_flight_topic_refresh", _hang)

    # Make _stream_ai a no-op that records it ran.
    ran = {"v": False}
    async def _fake_stream_ai(state, config, messages, system_prompt, *, kind="stream"):
        ran["v"] = True
        return "answer"
    monkeypatch.setattr(c, "_stream_ai", _fake_stream_ai)

    # Silence broadcasts.
    import meeting_helper.server.websocket as ws
    async def _noop(_m): pass
    monkeypatch.setattr(ws, "broadcast", _noop)

    state = AppState()
    config = AppConfig(anthropic_api_key="x", ai_failover_delay_ms=100)
    # local_todo None makes _pre_flight skip in real life, but we've replaced it
    # with a hang to prove the wait_for guard fires regardless.
    await asyncio.wait_for(c.handle_query(state, config), timeout=5)
    assert ran["v"] is True
