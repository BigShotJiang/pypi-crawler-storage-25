"""Unit tests for library_retrieval — tokenize, score, retrieve_kb_cards."""

from __future__ import annotations

from datetime import datetime, timedelta, timezone

from meeting_helper.library_retrieval import (
    _STOPWORDS,
    score_artifact,
    tokenize,
)


def test_tokenize_lowercases_and_splits():
    assert tokenize("Hello, World! It's 2026.") == {"hello", "world", "2026"}


def test_tokenize_drops_stopwords():
    tokens = tokenize("the metrics migration is in flight")
    assert "metrics" in tokens and "migration" in tokens and "flight" in tokens
    assert "the" not in tokens and "is" not in tokens and "in" not in tokens


def test_tokenize_drops_short_tokens():
    # 1- and 2-letter tokens are too noisy to score on
    tokens = tokenize("we go on a B C trip")
    assert "trip" in tokens
    assert "go" not in tokens
    assert "b" not in tokens


def test_score_pure_overlap():
    blob = "metrics migration phase one"
    body = "Discussed the metrics migration phase one rollout."
    score = score_artifact(blob_tokens=tokenize(blob), body=body, age_days=100)
    # 4 token overlap: metrics, migration, phase, one. Recency is 0 at age=100.
    assert score >= 4.0


def test_score_recency_boost_is_secondary():
    blob_tokens = tokenize("metrics migration")
    fresh = score_artifact(blob_tokens=blob_tokens, body="metrics migration", age_days=0)
    stale = score_artifact(blob_tokens=blob_tokens, body="metrics migration", age_days=365)
    assert fresh > stale  # fresher artifact ranks higher
    # but stale still has the overlap signal
    assert stale > 0


def test_score_zero_overlap_is_zero():
    blob_tokens = tokenize("payments billing")
    score = score_artifact(blob_tokens=blob_tokens, body="metrics migration", age_days=0)
    assert score == 0.0


def test_stopwords_set_present():
    # Sanity that the constant exists so downstream code can extend it
    assert "the" in _STOPWORDS


def test_load_artifacts_includes_only_kb_flagged(tmp_path):
    from meeting_helper.library_retrieval import load_artifacts

    (tmp_path / "2026-05-08_193029.summary.txt").write_text("topic alpha body")
    (tmp_path / "2026-05-07_120000.summary.txt").write_text("topic beta body")
    (tmp_path / "architecture-overview.note.md").write_text("# Architecture\n\nmonolith")

    arts = load_artifacts(
        recordings_dir=tmp_path,
        kb_filenames=[
            "2026-05-08_193029.summary.txt",
            "architecture-overview.note.md",
            # 2026-05-07 deliberately omitted
        ],
    )
    by_id = {a.id: a for a in arts}
    assert set(by_id.keys()) == {
        "2026-05-08_193029.summary.txt",
        "architecture-overview.note.md",
    }
    meeting = by_id["2026-05-08_193029.summary.txt"]
    assert meeting.kind == "meeting"
    assert meeting.date == "2026-05-08"
    assert meeting.title == "2026-05-08_193029"
    assert "topic alpha body" in meeting.body

    note = by_id["architecture-overview.note.md"]
    assert note.kind == "note"
    assert note.title == "architecture overview"  # de-kebabed for display
    assert "monolith" in note.body


def test_load_artifacts_named_meeting_keeps_label(tmp_path):
    from meeting_helper.library_retrieval import load_artifacts

    (tmp_path / "2026-05-08_193029_Daily_Standup.summary.txt").write_text("notes")
    arts = load_artifacts(
        recordings_dir=tmp_path,
        kb_filenames=["2026-05-08_193029_Daily_Standup.summary.txt"],
    )
    assert arts[0].title == "Daily Standup"  # the human label after the timestamp
    assert arts[0].date == "2026-05-08"


def test_load_artifacts_skips_missing_files(tmp_path):
    from meeting_helper.library_retrieval import load_artifacts

    arts = load_artifacts(
        recordings_dir=tmp_path,
        kb_filenames=["does-not-exist.summary.txt"],
    )
    assert arts == []


import asyncio
from datetime import date, datetime, timedelta


def _today_iso():
    return date.today().isoformat()


def _yesterday_iso():
    return (date.today() - timedelta(days=1)).isoformat()


def _make_config(tmp_path, kb_filenames, max_results=3):
    from unittest.mock import MagicMock
    cfg = MagicMock()
    cfg.recordings_dir = tmp_path
    cfg.kb_artifacts = list(kb_filenames)
    cfg.kb_max_results = max_results
    return cfg


def test_retrieve_returns_top_n_by_score(tmp_path):
    from meeting_helper.library_retrieval import retrieve_kb_cards

    today = _today_iso()
    (tmp_path / f"{today}_120000.summary.txt").write_text(
        "metrics migration phase one"
    )
    (tmp_path / f"{today}_130000.summary.txt").write_text(
        "payments billing rollout"
    )
    (tmp_path / "design.note.md").write_text("metrics architecture overview")

    cfg = _make_config(tmp_path, [
        f"{today}_120000.summary.txt",
        f"{today}_130000.summary.txt",
        "design.note.md",
    ], max_results=2)

    result = asyncio.run(retrieve_kb_cards(
        query_text="what's blocking metrics migration?",
        self_buffer_text="we were discussing metrics",
        other_buffer_text="",
        config=cfg,
    ))
    ids = [c.id for c in result]
    assert len(ids) == 2
    # The two metrics-overlapping artifacts should rank above the payments one
    assert f"{today}_130000.summary.txt" not in ids
    # Highest score first
    assert result[0].score >= result[1].score


def test_retrieve_drops_zero_overlap(tmp_path):
    from meeting_helper.library_retrieval import retrieve_kb_cards

    today = _today_iso()
    (tmp_path / f"{today}_120000.summary.txt").write_text("payments billing")
    cfg = _make_config(tmp_path, [f"{today}_120000.summary.txt"])

    result = asyncio.run(retrieve_kb_cards(
        query_text="metrics migration",
        self_buffer_text="",
        other_buffer_text="",
        config=cfg,
    ))
    assert result == []


def test_retrieve_returns_empty_when_no_kb_flagged(tmp_path):
    from meeting_helper.library_retrieval import retrieve_kb_cards

    cfg = _make_config(tmp_path, [])
    result = asyncio.run(retrieve_kb_cards(
        query_text="anything",
        self_buffer_text="",
        other_buffer_text="",
        config=cfg,
    ))
    assert result == []


def test_retrieve_failure_is_isolated(tmp_path):
    """If anything in the retrieval path raises, retrieve returns [] — never raises."""
    from unittest.mock import MagicMock
    from meeting_helper.library_retrieval import retrieve_kb_cards

    cfg = MagicMock()
    cfg.recordings_dir = tmp_path
    # Force an exception during attribute access on kb_artifacts
    type(cfg).kb_artifacts = property(lambda self: (_ for _ in ()).throw(RuntimeError("boom")))
    cfg.kb_max_results = 3

    # Must not raise
    result = asyncio.run(retrieve_kb_cards(
        query_text="x",
        self_buffer_text="",
        other_buffer_text="",
        config=cfg,
    ))
    assert result == []


def test_list_artifacts_unified(tmp_path):
    from meeting_helper.library_retrieval import list_artifacts

    (tmp_path / "2026-05-08_193029.mp3").write_bytes(b"\x00")
    (tmp_path / "2026-05-08_193029.live.txt").write_text("[00:00] hi")
    (tmp_path / "2026-05-08_193029.summary.txt").write_text("body")
    (tmp_path / "2026-05-07_120000.mp3").write_bytes(b"\x00")
    (tmp_path / "architecture.note.md").write_text("# arch")

    items = list_artifacts(recordings_dir=tmp_path)
    by_id = {i.id: i for i in items}

    # Three rows: two meetings + one note
    assert set(by_id) == {
        "2026-05-08_193029",       # meeting (the canonical id is the stem)
        "2026-05-07_120000",
        "architecture.note.md",
    }
    meeting1 = by_id["2026-05-08_193029"]
    assert meeting1.kind == "meeting"
    assert meeting1.has_mp3 is True
    assert meeting1.has_live is True
    assert meeting1.has_summary is True
    assert meeting1.has_transcript is False

    meeting2 = by_id["2026-05-07_120000"]
    assert meeting2.has_summary is False
    assert meeting2.has_mp3 is True

    note = by_id["architecture.note.md"]
    assert note.kind == "note"
    assert note.has_mp3 is False


def test_list_artifacts_empty_dir(tmp_path):
    from meeting_helper.library_retrieval import list_artifacts
    assert list_artifacts(recordings_dir=tmp_path) == []


def test_list_artifacts_sorted_newest_first(tmp_path):
    from meeting_helper.library_retrieval import list_artifacts

    (tmp_path / "2026-05-01_100000.mp3").write_bytes(b"\x00")
    (tmp_path / "2026-05-08_100000.mp3").write_bytes(b"\x00")
    (tmp_path / "alpha.note.md").write_text("body")  # mtime is "now"
    items = list_artifacts(recordings_dir=tmp_path)
    # Notes are sorted by mtime, meetings by their date stamp;
    # combined list is in date-desc order with notes interleaved by mtime.
    dates = [i.sort_key for i in items]
    assert dates == sorted(dates, reverse=True)


def test_list_artifacts_attaches_favorited_and_in_kb(tmp_path):
    """When a config is passed, each row carries the workspace favorite/KB flags."""
    from meeting_helper.library_retrieval import list_artifacts

    stem = "2026-05-14_120000_call"
    (tmp_path / f"{stem}.mp3").write_bytes(b"\x00")
    (tmp_path / f"{stem}.summary.txt").write_text("sum")
    (tmp_path / "roadmap.note.md").write_text("body")

    class FakeConfig:
        def __init__(self):
            self.favs = {f"{stem}.mp3", "roadmap.note.md"}
            self.kb = {f"{stem}.summary.txt"}

        def is_favorite(self, name: str) -> bool:
            return name in self.favs

        def is_kb(self, name: str) -> bool:
            return name in self.kb

    items = list_artifacts(recordings_dir=tmp_path, config=FakeConfig())
    by_id = {i.id: i for i in items}

    meeting = by_id[stem]
    assert meeting.favorited is True
    assert meeting.in_kb is True

    note = by_id["roadmap.note.md"]
    assert note.favorited is True
    assert note.in_kb is False


def test_list_artifacts_without_config_defaults_to_false(tmp_path):
    from meeting_helper.library_retrieval import list_artifacts

    (tmp_path / "2026-05-14_120000.mp3").write_bytes(b"\x00")
    items = list_artifacts(recordings_dir=tmp_path)
    assert items[0].favorited is False
    assert items[0].in_kb is False


def test_list_artifacts_populates_duration_when_ffprobe_available(
    tmp_path, monkeypatch,
):
    from meeting_helper import library_retrieval

    (tmp_path / "2026-05-14_120000.mp3").write_bytes(b"\x00")

    monkeypatch.setattr(
        library_retrieval, "_ffprobe_path", lambda: "/usr/bin/ffprobe",
    )
    monkeypatch.setattr(
        library_retrieval, "_probe_duration", lambda mp3, ffprobe: 263.5,
    )
    # Clear the module-level cache so the stub _probe_duration is reached.
    library_retrieval._duration_cache.clear()

    items = library_retrieval.list_artifacts(recordings_dir=tmp_path)
    assert items[0].duration_sec == 263.5


def test_list_artifacts_duration_none_when_ffprobe_missing(tmp_path, monkeypatch):
    from meeting_helper import library_retrieval

    (tmp_path / "2026-05-14_120000.mp3").write_bytes(b"\x00")

    monkeypatch.setattr(library_retrieval, "_ffprobe_path", lambda: None)
    library_retrieval._duration_cache.clear()

    items = library_retrieval.list_artifacts(recordings_dir=tmp_path)
    assert items[0].duration_sec is None


def test_list_artifacts_duration_cache_short_circuits_probe(
    tmp_path, monkeypatch,
):
    """Second list_artifacts call must reuse cached duration without probing."""
    from meeting_helper import library_retrieval

    mp3 = tmp_path / "2026-05-14_120000.mp3"
    mp3.write_bytes(b"\x00")

    calls = {"n": 0}

    def fake_probe(mp3_path, ffprobe):
        calls["n"] += 1
        # Mirror the real implementation by writing to the cache so the
        # second pass through list_artifacts hits the cached branch.
        key = (str(mp3_path), mp3_path.stat().st_mtime)
        library_retrieval._duration_cache[key] = 42.0
        return 42.0

    monkeypatch.setattr(
        library_retrieval, "_ffprobe_path", lambda: "/usr/bin/ffprobe",
    )
    monkeypatch.setattr(library_retrieval, "_probe_duration", fake_probe)
    library_retrieval._duration_cache.clear()

    items1 = library_retrieval.list_artifacts(recordings_dir=tmp_path)
    items2 = library_retrieval.list_artifacts(recordings_dir=tmp_path)
    assert items1[0].duration_sec == 42.0
    assert items2[0].duration_sec == 42.0
    assert calls["n"] == 1, "duration should only be probed once per mtime"
