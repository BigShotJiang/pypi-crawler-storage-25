"""Integration test: handle_manual_query uses KB cards when KB is configured."""

from __future__ import annotations

import asyncio
from datetime import date
from unittest.mock import AsyncMock, MagicMock, patch

import pytest


@pytest.mark.asyncio
async def test_kb_cards_appear_in_system_prompt(tmp_path):
    today = date.today().isoformat()
    (tmp_path / f"{today}_120000.summary.txt").write_text(
        "## Topics covered\n\nDiscussed metrics migration, including phase one rollout."
    )

    captured = {}

    async def fake_stream_ai(state, config, messages, system_prompt, kind):
        captured["system_prompt"] = system_prompt
        return ""

    state = MagicMock()
    state.active_query = None
    state.proactive_monitor = None
    state.self_buffer = None
    state.other_buffer = None
    state.current_topic = {}
    state.current_topic_cards = []
    state.last_query_at = 0
    state.conversation_history = []
    state.audio_active = False
    state.last_response = ""
    state.auto_context_index = ""

    config = MagicMock()
    config.recordings_dir = tmp_path
    config.kb_artifacts = [f"{today}_120000.summary.txt"]
    config.kb_max_results = 3
    config.sentence_window = 5
    config.max_history_turns = 5

    with patch("meeting_helper.ai.client._stream_ai", side_effect=fake_stream_ai), \
         patch("meeting_helper.ai.client._pre_flight_topic_refresh", new=AsyncMock()), \
         patch("meeting_helper.server.websocket.broadcast", new=AsyncMock()), \
         patch("meeting_helper.server.websocket.slim_card_for_broadcast", side_effect=lambda x: x):
        from meeting_helper.ai.client import handle_manual_query
        await handle_manual_query(state, config, "what about the metrics migration?")

    assert "Past meetings and notes" in captured["system_prompt"]
    assert "metrics migration" in captured["system_prompt"]
