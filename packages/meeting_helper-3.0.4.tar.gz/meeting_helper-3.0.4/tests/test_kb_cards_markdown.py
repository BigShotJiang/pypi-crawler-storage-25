"""Unit test for _format_kb_cards_markdown."""

from __future__ import annotations

from meeting_helper.ai.client import _format_kb_cards_markdown
from meeting_helper.library_retrieval import KbCard


def test_renders_with_header():
    cards = [
        KbCard(id="2026-05-08.summary.txt", kind="meeting", title="Daily",
               date="2026-05-08", body="discussed metrics", score=4.0),
    ]
    md = _format_kb_cards_markdown(cards)
    assert "Past meetings and notes" in md
    assert "2026-05-08" in md
    assert "Daily" in md
    assert "discussed metrics" in md


def test_empty_returns_empty_string():
    assert _format_kb_cards_markdown([]) == ""


def test_renders_note_kind():
    cards = [KbCard(id="x.note.md", kind="note", title="x", date="",
                    body="hello world", score=2.0)]
    md = _format_kb_cards_markdown(cards)
    assert "Note" in md
    assert "hello world" in md
