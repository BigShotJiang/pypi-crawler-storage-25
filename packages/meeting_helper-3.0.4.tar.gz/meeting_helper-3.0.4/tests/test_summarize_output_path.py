"""Tests for the summary output-path helper that handles compound .live.txt / .transcript.txt suffixes."""

from __future__ import annotations

from pathlib import Path

from meeting_helper.ai.client import _summary_output_path


def test_strips_live_txt():
    assert _summary_output_path(Path("/m/2026-05-08_193029.live.txt")) == Path(
        "/m/2026-05-08_193029.summary.txt"
    )


def test_strips_transcript_txt():
    assert _summary_output_path(Path("/m/2026-05-08_193029.transcript.txt")) == Path(
        "/m/2026-05-08_193029.summary.txt"
    )


def test_falls_back_for_other_suffix():
    # An unexpected single-suffix .txt — still produces *.summary.txt next to it.
    assert _summary_output_path(Path("/m/notes.txt")) == Path("/m/notes.summary.txt")


def test_handles_named_meetings():
    assert _summary_output_path(Path("/m/2026-05-08_193029_Daily.live.txt")) == Path(
        "/m/2026-05-08_193029_Daily.summary.txt"
    )
