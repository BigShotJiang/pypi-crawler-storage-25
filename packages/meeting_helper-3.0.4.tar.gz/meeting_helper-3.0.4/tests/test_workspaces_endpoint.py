"""Tests for /workspaces and /workspace/activate.

These endpoints back the new shell's workspace switcher dropdown. We point
WORKSPACES_DIR/STATE_FILE/etc. at a tmp dir (same monkeypatch pattern as
test_config_post_persistence.py) so the activate POST mutates an isolated
state.json, not the real one in ~/.config.
"""

from __future__ import annotations

import json

import pytest

from meeting_helper import config as config_mod
from meeting_helper.config import AppConfig
from meeting_helper.server.app import create_app


@pytest.fixture
async def app_client(aiohttp_client, tmp_path, monkeypatch):
    ws_dir = tmp_path / "workspaces"
    ws_dir.mkdir(parents=True, exist_ok=True)
    for name in ("default", "alpha", "beta"):
        (ws_dir / f"{name}.json").write_text(json.dumps({}))
    (tmp_path / "state.json").write_text(json.dumps({
        "active_workspace": "default",
        "workspace_order": ["default", "alpha", "beta"],
    }))
    monkeypatch.setattr(config_mod, "DEFAULT_CONFIG_DIR", tmp_path)
    monkeypatch.setattr(config_mod, "WORKSPACES_DIR", ws_dir)
    monkeypatch.setattr(config_mod, "STATE_FILE", tmp_path / "state.json")
    monkeypatch.setattr(
        config_mod, "LEGACY_CONFIG_FILE", tmp_path / "config.json.legacy"
    )
    monkeypatch.setattr(config_mod, "LEGACY_BACKUP", tmp_path / "config.bak")
    monkeypatch.setattr(config_mod, "_config", None)
    return await aiohttp_client(create_app(AppConfig()))


async def test_workspaces_get(app_client):
    resp = await app_client.get("/workspaces")
    assert resp.status == 200
    body = await resp.json()
    assert body["active"] == "default"
    assert set(body["available"]) == {"default", "alpha", "beta"}


async def test_workspace_activate_switches(app_client, monkeypatch):
    # Stub the SIGTERM so the test process doesn't actually die.
    import os
    monkeypatch.setattr(os, "kill", lambda pid, sig: None)
    resp = await app_client.post("/workspace/activate", json={"name": "alpha"})
    assert resp.status == 200
    body = await resp.json()
    assert body["active"] == "alpha"
    # Verify state.json reflects the switch.
    from meeting_helper.config import load_state
    assert load_state()["active_workspace"] == "alpha"


async def test_workspace_activate_unknown_404(app_client):
    resp = await app_client.post("/workspace/activate", json={"name": "ghost"})
    assert resp.status == 404


async def test_workspace_activate_no_name_400(app_client):
    resp = await app_client.post("/workspace/activate", json={})
    assert resp.status == 400


async def test_workspace_activate_blocks_during_recording(app_client, monkeypatch):
    from meeting_helper.state import state as live_state
    monkeypatch.setattr(live_state, "session_active", True)
    resp = await app_client.post("/workspace/activate", json={"name": "alpha"})
    assert resp.status == 409


# --- /workspace/create -----------------------------------------------------


async def test_workspace_create_new(app_client):
    resp = await app_client.post("/workspace/create", json={"name": "gamma"})
    assert resp.status == 200
    body = await resp.json()
    assert body == {"ok": True, "name": "gamma"}
    from meeting_helper.config import list_workspaces
    assert "gamma" in list_workspaces()


async def test_workspace_create_with_copy_from(app_client):
    # Seed source workspace JSON so the copy has something to copy.
    from meeting_helper.config import workspace_path
    workspace_path("alpha").write_text('{"port": 9999, "anthropic_api_key": "abc"}')
    resp = await app_client.post(
        "/workspace/create",
        json={"name": "alpha-copy", "copy_from": "alpha"},
    )
    assert resp.status == 200
    body = await resp.json()
    assert body == {"ok": True, "name": "alpha-copy"}
    # Copied file content matches source.
    copied = workspace_path("alpha-copy").read_text()
    assert "9999" in copied


async def test_workspace_create_duplicate_returns_400(app_client):
    resp = await app_client.post("/workspace/create", json={"name": "alpha"})
    assert resp.status == 400
    body = await resp.json()
    assert "already exists" in body["error"]


async def test_workspace_create_missing_name_returns_400(app_client):
    resp = await app_client.post("/workspace/create", json={})
    assert resp.status == 400


async def test_workspace_create_invalid_json_returns_400(app_client):
    resp = await app_client.post(
        "/workspace/create",
        data="not-json",
        headers={"Content-Type": "application/json"},
    )
    assert resp.status == 400


# --- /workspace/rename -----------------------------------------------------


async def test_workspace_rename(app_client):
    resp = await app_client.post(
        "/workspace/rename", json={"old": "alpha", "new": "alpha-prod"}
    )
    assert resp.status == 200
    body = await resp.json()
    assert body == {"ok": True, "name": "alpha-prod"}
    from meeting_helper.config import list_workspaces
    assert "alpha-prod" in list_workspaces()
    assert "alpha" not in list_workspaces()


async def test_workspace_rename_target_exists_400(app_client):
    resp = await app_client.post(
        "/workspace/rename", json={"old": "alpha", "new": "beta"}
    )
    assert resp.status == 400
    body = await resp.json()
    assert "already exists" in body["error"]


async def test_workspace_rename_missing_fields_400(app_client):
    resp = await app_client.post("/workspace/rename", json={"old": "alpha"})
    assert resp.status == 400


# --- /workspace/delete -----------------------------------------------------


async def test_workspace_delete(app_client):
    resp = await app_client.post("/workspace/delete", json={"name": "alpha"})
    assert resp.status == 200
    body = await resp.json()
    assert body == {"ok": True}
    from meeting_helper.config import list_workspaces
    assert "alpha" not in list_workspaces()


async def test_workspace_delete_active_returns_400(app_client):
    resp = await app_client.post("/workspace/delete", json={"name": "default"})
    assert resp.status == 400
    body = await resp.json()
    assert "active" in body["error"].lower()


async def test_workspace_delete_unknown_returns_200_idempotent(app_client):
    # delete_workspace returns silently when the file is already gone (state
    # is still mutated, but the call doesn't raise). Confirm we get 200.
    resp = await app_client.post("/workspace/delete", json={"name": "ghost"})
    # ghost wasn't in workspace_order so this is a noop; status should still be ok.
    assert resp.status == 200


async def test_workspace_delete_last_remaining_returns_400(app_client):
    # Delete two so only `default` remains, then try to delete it.
    await app_client.post("/workspace/delete", json={"name": "alpha"})
    await app_client.post("/workspace/delete", json={"name": "beta"})
    resp = await app_client.post("/workspace/delete", json={"name": "default"})
    assert resp.status == 400
    body = await resp.json()
    assert "last" in body["error"].lower() or "active" in body["error"].lower()


async def test_workspace_delete_missing_name_400(app_client):
    resp = await app_client.post("/workspace/delete", json={})
    assert resp.status == 400
