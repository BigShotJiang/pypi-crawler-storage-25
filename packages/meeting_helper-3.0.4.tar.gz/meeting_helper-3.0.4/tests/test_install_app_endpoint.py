"""Tests for /install-app and /install-app/status — desktop bundle install endpoints.

Mocks out the filesystem-mutating bits (`install_to_applications`,
`_user_install_path`, `_system_install_path`) so the suite never touches
the real `~/Applications/Meeting Helper.app`.
"""

from __future__ import annotations

import plistlib
from unittest.mock import patch

import pytest

from meeting_helper.config import AppConfig
from meeting_helper.server.app import create_app


@pytest.fixture
async def app_client(aiohttp_client):
    return await aiohttp_client(create_app(AppConfig()))


async def test_status_when_not_installed(app_client, tmp_path):
    """Status returns installed=false when neither user nor system path exists."""
    missing_user = tmp_path / "Applications" / "Meeting Helper.app"
    missing_system = tmp_path / "system" / "Meeting Helper.app"
    with patch(
        "meeting_helper.install_app._user_install_path",
        return_value=missing_user,
    ), patch(
        "meeting_helper.install_app._system_install_path",
        return_value=missing_system,
    ):
        resp = await app_client.get("/install-app/status")
    assert resp.status == 200
    body = await resp.json()
    assert body["installed"] is False
    assert body["path"] is None
    assert body["version"] is None
    assert isinstance(body["current_version"], str)
    assert body["current_version"]  # non-empty


async def test_status_when_installed_reads_info_plist(app_client, tmp_path):
    """Status returns installed=true with the version pulled from Info.plist."""
    bundle = tmp_path / "Applications" / "Meeting Helper.app"
    contents = bundle / "Contents"
    contents.mkdir(parents=True)
    plist_path = contents / "Info.plist"
    with open(plist_path, "wb") as fh:
        plistlib.dump({"CFBundleShortVersionString": "1.2.3"}, fh)

    missing_system = tmp_path / "system" / "Meeting Helper.app"
    with patch(
        "meeting_helper.install_app._user_install_path",
        return_value=bundle,
    ), patch(
        "meeting_helper.install_app._system_install_path",
        return_value=missing_system,
    ):
        resp = await app_client.get("/install-app/status")
    assert resp.status == 200
    body = await resp.json()
    assert body["installed"] is True
    assert body["path"] == str(bundle)
    assert body["version"] == "1.2.3"
    assert body["current_version"]


async def test_status_when_installed_but_plist_unreadable(app_client, tmp_path):
    """A bundle present but with an unreadable Info.plist still reports installed=true."""
    bundle = tmp_path / "Applications" / "Meeting Helper.app"
    (bundle / "Contents").mkdir(parents=True)
    # No Info.plist written intentionally.
    missing_system = tmp_path / "system" / "Meeting Helper.app"
    with patch(
        "meeting_helper.install_app._user_install_path",
        return_value=bundle,
    ), patch(
        "meeting_helper.install_app._system_install_path",
        return_value=missing_system,
    ):
        resp = await app_client.get("/install-app/status")
    body = await resp.json()
    assert body["installed"] is True
    assert body["path"] == str(bundle)
    assert body["version"] is None


async def test_install_returns_path_and_version_on_success(app_client, tmp_path):
    """POST /install-app returns ok=true plus the resolved bundle path + version."""
    fake_dest = tmp_path / "Applications" / "Meeting Helper.app"

    def fake_install(*, system: bool = False):
        # Don't actually write anything — the endpoint only cares about the
        # return value. Asserting system=False guards against an accidental
        # /Applications install slipping in.
        assert system is False
        return fake_dest

    with patch(
        "meeting_helper.install_app.install_to_applications",
        side_effect=fake_install,
    ):
        resp = await app_client.post("/install-app")
    assert resp.status == 200
    body = await resp.json()
    assert body["ok"] is True
    assert body["path"] == str(fake_dest)
    assert isinstance(body["version"], str) and body["version"]


async def test_install_returns_500_on_raise(app_client):
    """POST /install-app surfaces the error message as 500 instead of crashing."""
    with patch(
        "meeting_helper.install_app.install_to_applications",
        side_effect=PermissionError("nope"),
    ):
        resp = await app_client.post("/install-app")
    assert resp.status == 500
    body = await resp.json()
    assert "nope" in body["error"]
