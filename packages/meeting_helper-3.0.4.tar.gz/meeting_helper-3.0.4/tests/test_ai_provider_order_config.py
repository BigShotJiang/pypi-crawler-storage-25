"""Tests for ai_provider_order / ai_failover_delay_ms config keys + migration."""

from __future__ import annotations

import json

from meeting_helper.config import Config


def test_defaults_when_absent(tmp_path):
    cfg = Config(tmp_path / "config.json")
    assert cfg.ai_provider_order == ["anthropic", "google"]
    assert cfg.ai_failover_delay_ms == 2000


def test_migrate_from_preferred_provider_gemini(tmp_path):
    p = tmp_path / "config.json"
    p.write_text(json.dumps({"preferred_provider": "gemini"}))
    cfg = Config(p)
    assert cfg.ai_provider_order == ["google", "anthropic"]


def test_migrate_from_preferred_provider_claude_default(tmp_path):
    p = tmp_path / "config.json"
    p.write_text(json.dumps({"preferred_provider": ""}))
    cfg = Config(p)
    assert cfg.ai_provider_order == ["anthropic", "google"]


def test_migrate_from_preferred_provider_local(tmp_path):
    p = tmp_path / "config.json"
    p.write_text(json.dumps({"preferred_provider": "local"}))
    cfg = Config(p)
    assert cfg.ai_provider_order == ["anthropic", "google"]


def test_explicit_order_is_preserved(tmp_path):
    p = tmp_path / "config.json"
    p.write_text(json.dumps({"ai_provider_order": ["google"], "ai_failover_delay_ms": 0}))
    cfg = Config(p)
    assert cfg.ai_provider_order == ["google"]
    assert cfg.ai_failover_delay_ms == 0


def test_setters_round_trip(tmp_path):
    p = tmp_path / "config.json"
    cfg = Config(p)
    cfg.ai_provider_order = ["google", "anthropic"]
    cfg.ai_failover_delay_ms = 1500
    cfg.save()
    cfg2 = Config(p)
    assert cfg2.ai_provider_order == ["google", "anthropic"]
    assert cfg2.ai_failover_delay_ms == 1500


def test_app_config_carries_fields(tmp_path):
    p = tmp_path / "config.json"
    p.write_text(json.dumps({"ai_provider_order": ["google", "anthropic"], "ai_failover_delay_ms": 750}))
    app = Config(p).to_app_config()
    assert app.ai_provider_order == ["google", "anthropic"]
    assert app.ai_failover_delay_ms == 750
