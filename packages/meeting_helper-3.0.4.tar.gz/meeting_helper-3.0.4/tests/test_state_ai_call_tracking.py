"""record_ai_call must stamp last_ai_call_at / last_ai_call_kind."""

from __future__ import annotations

import time

from meeting_helper.state import AppState


def test_record_ai_call_stamps_time_and_kind():
    s = AppState()
    assert s.last_ai_call_at == 0.0
    assert s.last_ai_call_kind == ""
    before = time.time()
    s.record_ai_call("query")
    assert s.last_ai_call_kind == "query"
    assert s.last_ai_call_at >= before
    assert s.ai_call_count == 1


def test_active_query_started_at_default_zero():
    s = AppState()
    assert s.active_query_started_at == 0.0
