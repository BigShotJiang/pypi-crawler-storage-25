"""Tests for POST /daemon/restart.

The endpoint schedules a SIGTERM-to-self so the shell supervisor will
respawn us with whatever code is now on disk. We never actually want
the test process to die, so the SIGTERM call is monkeypatched and we
inspect the scheduled task.
"""

from __future__ import annotations

import asyncio
import json

import pytest
from aiohttp.test_utils import make_mocked_request

from meeting_helper.server.routes import daemon_restart_handler


@pytest.mark.asyncio
async def test_daemon_restart_returns_202_and_schedules_sigterm(monkeypatch):
    sigterm_calls: list[tuple[int, int]] = []

    def _fake_kill(pid: int, sig: int) -> None:
        sigterm_calls.append((pid, sig))

    monkeypatch.setattr("os.kill", _fake_kill)

    req = make_mocked_request("POST", "/daemon/restart")
    resp = await daemon_restart_handler(req)
    assert resp.status == 202
    data = json.loads(resp.text)
    assert data == {"ok": True, "restarting": True}

    # The handler doesn't kill synchronously — it schedules a background
    # task with a 250 ms grace so the response can flush. Wait for it.
    assert sigterm_calls == []
    await asyncio.sleep(0.4)
    assert len(sigterm_calls) == 1
    import os
    import signal
    pid, sig = sigterm_calls[0]
    assert pid == os.getpid()
    assert sig == signal.SIGTERM


@pytest.mark.asyncio
async def test_daemon_restart_swallows_kill_failure(monkeypatch):
    """If something blocks SIGTERM (sandbox, weird permission), we don't
    want the error to bubble up and crash the event loop — the supervisor
    will still notice we're alive on next health check."""

    def _boom(pid: int, sig: int) -> None:
        raise PermissionError("nope")

    monkeypatch.setattr("os.kill", _boom)
    req = make_mocked_request("POST", "/daemon/restart")
    resp = await daemon_restart_handler(req)
    assert resp.status == 202
    # Let the scheduled task run and confirm it doesn't propagate.
    await asyncio.sleep(0.4)
