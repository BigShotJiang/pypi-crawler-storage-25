"""End-to-end-ish tests for the audio capture → transcribe → record pipeline.

Avoids real audio devices and real Deepgram. Each test isolates one
concrete failure mode the round-2 audit flagged so a regression brings the
specific test down with a clear message — instead of the user seeing a
silent recording loss after the fact.
"""

from __future__ import annotations

import threading
import time
from pathlib import Path
from queue import Empty
from unittest.mock import MagicMock, patch

import numpy as np
import pytest


# ---------------------------------------------------------------------------
# Capture: bounded transcribe queue with drop-oldest
# ---------------------------------------------------------------------------

def test_transcribe_queue_drops_oldest_when_full():
    """A stalled transcriber must NOT cause unbounded memory growth.
    The bounded queue + drop-oldest helper enforces this; without it a
    multi-minute Deepgram outage filled the queue with every chunk and
    the daemon eventually OOM'd."""
    from meeting_helper.audio.capture import (
        CombinedAudioCapture,
        TRANSCRIBE_QUEUE_MAX,
    )

    capture = CombinedAudioCapture(sample_rate=16000)
    chunk = np.zeros(320, dtype=np.float32)

    # Fill past capacity. Each put_drop_oldest call must succeed even when
    # the queue is full (drop the oldest item to make room for the new one).
    for i in range(TRANSCRIBE_QUEUE_MAX + 100):
        capture._put_drop_oldest(capture._mic_transcribe_q, chunk, "mic")

    assert capture._mic_transcribe_q.qsize() <= TRANSCRIBE_QUEUE_MAX
    # Drop counter should reflect ~100 overflowed items.
    assert capture._mic_drop_count >= 100


def test_transcribe_queue_does_not_drop_until_full():
    """No drop while there's capacity."""
    from meeting_helper.audio.capture import CombinedAudioCapture

    capture = CombinedAudioCapture(sample_rate=16000)
    chunk = np.zeros(320, dtype=np.float32)
    for _ in range(100):
        capture._put_drop_oldest(capture._mic_transcribe_q, chunk, "mic")
    assert capture._mic_drop_count == 0
    assert capture._mic_transcribe_q.qsize() == 100


# ---------------------------------------------------------------------------
# Encoder: ffmpeg restart on broken pipe
# ---------------------------------------------------------------------------

def test_mp3_encoder_restarts_ffmpeg_on_broken_pipe(tmp_path: Path):
    """When ffmpeg dies mid-recording, the encoder must restart it
    (bounded budget) instead of silently dropping the rest of the meeting.
    Without this, every BrokenPipeError left the user with a truncated MP3."""
    from meeting_helper.audio.encoder import MP3Encoder

    out = tmp_path / "test.mp3"
    encoder = MP3Encoder(out, sample_rate=16000, channels=1)

    # Force the next write to raise BrokenPipeError, then succeed afterwards.
    fake_stdin = MagicMock()
    call_state = {"broke": False}

    def write_side_effect(data: bytes) -> None:
        if not call_state["broke"]:
            call_state["broke"] = True
            raise BrokenPipeError("ffmpeg died")

    fake_stdin.write = MagicMock(side_effect=write_side_effect)
    encoder._process.stdin = fake_stdin

    # The first write triggers BrokenPipeError → encoder calls _start_ffmpeg
    # to spawn a fresh subprocess + retries the chunk on the new pipe.
    # We patch _start_ffmpeg to record that it was called.
    with patch.object(encoder, "_start_ffmpeg") as mock_restart:
        # _start_ffmpeg should re-init self._process. Simulate that by
        # reassigning a working stdin.
        def _restart_side_effect():
            encoder._process = MagicMock()
            encoder._process.stdin = MagicMock()
            encoder._process.stdin.write = MagicMock()  # succeeds

        mock_restart.side_effect = _restart_side_effect
        chunk = np.zeros(320, dtype=np.float32)
        encoder.encode_chunk(chunk)
        assert mock_restart.called
        assert encoder._restart_count == 1
        assert encoder._dead is False

    # Cleanup
    encoder._dead = True  # don't try to write more


def test_mp3_encoder_gives_up_after_max_restarts(tmp_path: Path):
    """If ffmpeg keeps dying, the encoder must mark itself dead so the
    session loop stops trying instead of looping forever on the same crash."""
    from meeting_helper.audio.encoder import MP3Encoder

    out = tmp_path / "test.mp3"
    encoder = MP3Encoder(out, sample_rate=16000, channels=1)

    # Fail every restart attempt.
    chunk = np.zeros(320, dtype=np.float32)
    fake_stdin = MagicMock()
    fake_stdin.write = MagicMock(side_effect=BrokenPipeError("dead"))
    encoder._process.stdin = fake_stdin

    with patch.object(encoder, "_start_ffmpeg") as mock_restart, \
         patch.object(encoder, "_broadcast_recording_dead"):
        # Each restart re-installs the same broken pipe.
        def _broken_restart():
            encoder._process = MagicMock()
            encoder._process.stdin = fake_stdin

        mock_restart.side_effect = _broken_restart
        for _ in range(MP3Encoder._MAX_RESTARTS + 2):
            encoder.encode_chunk(chunk)

    assert encoder._dead is True
    assert encoder._restart_count > MP3Encoder._MAX_RESTARTS


# ---------------------------------------------------------------------------
# Live transcript writer
# ---------------------------------------------------------------------------

def test_live_transcript_writer_close_returns_within_timeout(tmp_path: Path):
    """close() must return within ~5s even on a wedged disk — session
    teardown shouldn't block forever waiting on file I/O."""
    from meeting_helper.live_transcript import LiveTranscriptWriter

    path = tmp_path / "x.live.txt"
    writer = LiveTranscriptWriter(path, t0=0.0, clock=lambda: 0.0)
    writer.append("SELF", "hello")

    start = time.monotonic()
    writer.close()
    duration = time.monotonic() - start
    # 2+2 = 4s upper bound on close. Healthy disk should be << 100ms.
    assert duration < 5.0


# ---------------------------------------------------------------------------
# Buffer: listener locking and callback isolation
# ---------------------------------------------------------------------------

def test_sentence_listener_exception_is_logged_not_swallowed(caplog):
    """A misbehaving listener used to silently disable per-sentence side
    effects with no log. Phase 2 added logger.exception so it's visible."""
    import logging
    from meeting_helper.buffer import SentenceBuffer

    buf = SentenceBuffer(role="self")

    def bad_listener(text: str) -> None:
        raise RuntimeError("listener intentionally fails")

    def good_listener(text: str) -> None:
        good_listener.calls.append(text)

    good_listener.calls = []

    buf.add_sentence_listener(bad_listener)
    buf.add_sentence_listener(good_listener)

    with caplog.at_level(logging.ERROR):
        buf.append_final("test sentence")

    # bad_listener raised but good_listener should still fire.
    assert good_listener.calls == ["test sentence"]
    # Exception should be logged with traceback.
    assert any("listener" in rec.message.lower() for rec in caplog.records)


def test_sentence_listener_add_and_remove_concurrent_safe():
    """add/remove must be safe against concurrent append_final iterations."""
    from meeting_helper.buffer import SentenceBuffer

    buf = SentenceBuffer(role="self")
    received = []

    def listener(text: str) -> None:
        received.append(text)
        # Re-entering add_sentence_listener from inside a callback used to
        # be a deadlock risk. Phase 2 ensures the lock is released before
        # callbacks fire.
        buf.add_sentence_listener(lambda _t: None)

    buf.add_sentence_listener(listener)
    buf.append_final("first")
    # Should not deadlock. listener was called.
    assert received == ["first"]


# ---------------------------------------------------------------------------
# Meeting detector: false-end-of-meeting protection
# ---------------------------------------------------------------------------

def test_mic_in_use_returns_true_on_coreaudio_error():
    """Bias to True ('assume in use') so a transient CoreAudio glitch
    doesn't fire false end-of-meeting and kill an active session."""
    from meeting_helper import meeting_detector

    with patch.object(meeting_detector, "_init_coreaudio", return_value=False):
        # CoreAudio unavailable → must return True, not False.
        assert meeting_detector.is_mic_in_use_by_another_app() is True


# ---------------------------------------------------------------------------
# Capture: AudioCapture.resume() returns bool, doesn't raise
# ---------------------------------------------------------------------------

def test_audio_capture_resume_returns_bool_on_failure():
    """resume() used to let InputStream() exceptions propagate up to the
    session loop's bare except, killing the session. Now it returns False
    instead so MicProbe can handle the failure without ending the session."""
    from meeting_helper.audio.capture import AudioCapture

    # Construct without starting (bypasses the real audio device).
    with patch("meeting_helper.audio.capture.sd") as fake_sd:
        fake_sd.default.device = (1, 1)
        fake_sd.query_devices.return_value = {"max_input_channels": 1, "name": "fake"}
        cap = AudioCapture(device=1, sample_rate=16000)
        cap.stream = None  # nothing to pause
        # Make InputStream raise on next call.
        fake_sd.InputStream = MagicMock(side_effect=RuntimeError("no device"))
        ok = cap.resume()
    assert ok is False


# ---------------------------------------------------------------------------
# Process_audio death sets stop_event
# ---------------------------------------------------------------------------

def test_process_audio_crash_sets_stop_event():
    """If _process_audio_loop raises uncaught, _process_audio sets
    stop_event so the session loop can detect the death instead of
    spinning forever on empty get_audio() calls."""
    from meeting_helper.audio.capture import CombinedAudioCapture

    cap = CombinedAudioCapture(sample_rate=16000)
    with patch.object(cap, "_process_audio_loop", side_effect=RuntimeError("boom")):
        cap._process_audio()
    assert cap.stop_event.is_set()
