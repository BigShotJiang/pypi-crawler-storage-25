"""FastMCP server v0.2 — delega todo al endpoint HTTP /api/mcp/v1/invoke.

Las 4 tools v0.2 con dotted naming (`<dominio>.<acción>`):
    catalog_list          → lista datasets publicados
    catalog_get           → metadata completa + schema + example_queries
    data_snapshot_url     → signed URL al snapshot productivo completo (R2)
    data_query            → ejecuta SQL contra Postgres data_* (datos completos)

El client Python ya NO toca Postgres ni R2 directo. Todo el compute y
security pasa por el web server. Beneficios:
    - Cero credenciales en el cliente (solo ALMANAC_API_KEY)
    - Schema discovery + AI metadata viven server-side y se actualizan sin
      bump de versión del client
    - Telemetry centralizado en mcp_invocations
"""

from __future__ import annotations

import logging
import platform
from typing import Any

from mcp.server.fastmcp import FastMCP

from almanac_mcp import __version__
from almanac_mcp.client import MCPHttpClient
from almanac_mcp.settings import Settings

log = logging.getLogger(__name__)


def _client_info() -> dict[str, str]:
    """Metadata del client para telemetry server-side."""
    return {
        "client": "almanac-mcp",
        "version": __version__,
        "os": platform.system().lower(),
    }


def build_server(settings: Settings | None = None) -> FastMCP:
    """Construye el server MCP con las 4 tools registradas."""
    if settings is None:
        settings = Settings.from_env()

    mcp = FastMCP("almanac")
    client = MCPHttpClient(settings)

    @mcp.tool(name="catalog_list")
    def catalog_list() -> list[dict[str, Any]]:
        """Lista los datasets publicados del Almanac (BCRA, CNV, INDEC, SEC, etc).

        Cada item trae: dataset_id, name, source, description, frequency,
        historical_depth. Para metadata completa + schema de columnas + queries
        de ejemplo, usar catalog_get(dataset_id).
        """
        return client.invoke("catalog_list", {}, client_info=_client_info()).result

    @mcp.tool(name="catalog_get")
    def catalog_get(dataset_id: str) -> dict[str, Any]:
        """Devuelve metadata completa + schema de la tabla Postgres del dataset.

        Incluye:
            - Descripción + business_questions + methodology_notes + gotchas
            - example_queries (templates SQL listos para usar)
            - mcp.table_name: nombre exacto de la tabla en Postgres (data_*)
            - mcp.columns: lista de (name, type, nullable) para armar SQL
            - mcp.queryable_via_sql: bool — si False, usar data_snapshot_url

        Args:
            dataset_id: Identificador formato {fuente}.{categoria}.{nombre},
                ej: 'bcra.monetarias.indicadores'.
        """
        return client.invoke(
            "catalog_get",
            {"dataset_id": dataset_id},
            client_info=_client_info(),
        ).result

    @mcp.tool(name="data_snapshot_url")
    def data_snapshot_url(dataset_id: str, format: str = "parquet") -> dict[str, Any]:
        """Devuelve una URL firmada R2 de 10 minutos al snapshot productivo completo.

        Útil cuando el cliente quiere bajar el dataset completo y trabajarlo
        localmente (DuckDB, polars, pandas, R, etc). Para queries SQL rápidas
        sobre los datos completos sin descarga, usar `data_query`.

        Args:
            dataset_id: Identificador del dataset.
            format: 'parquet' (recomendado) o 'csv'.

        Returns:
            { url, expires_in_seconds, dataset_id, format,
              snapshot: { snapshot_at, rows_count, file_size_bytes } }
        """
        return client.invoke(
            "data_snapshot_url",
            {"dataset_id": dataset_id, "format": format},
            client_info=_client_info(),
        ).result

    @mcp.tool(name="data_query")
    def data_query(sql: str) -> dict[str, Any]:
        """Ejecuta una query SQL SELECT/WITH/EXPLAIN sobre las tablas de Almanac.

        Las tablas disponibles tienen prefijo `data_*` (ver catalog_get →
        mcp.table_name por dataset). Soporta JOINs cross-dataset entre BCRA,
        INDEC, CNV, SEC. Solo lectura — DDL/DML rechazados.

        Constraints server-side:
            - statement_timeout: 30s
            - cap de filas: 10.000 (truncated=true si excede)
            - work_mem: 32 MB

        Args:
            sql: Query SQL válida. Ej:
                "SELECT fecha, valor FROM data_bcra_monetarias_indicadores
                 WHERE id_variable = 1 AND fecha >= '2024-01-01'
                 ORDER BY fecha DESC LIMIT 100"

        Returns:
            { rows: list[dict], row_count: int, truncated: bool,
              columns: list[str] }
        """
        return client.invoke(
            "data_query",
            {"sql": sql},
            client_info=_client_info(),
        ).result

    return mcp
