"""MCP server for the Almanac argentino."""

__version__ = "0.3.0"
