"""OpenAI Agents SDK FunctionTool wrappers for the OpenJobs API."""
from __future__ import annotations

import json
from typing import Optional

from agents import FunctionTool, RunContextWrapper

from openjobs import OpenJobsClient

from openjobs_langchain._schemas import (
    ApplyToJobInput,
    CreateJobInput,
    GetJobInput,
    ListInboxInput,
    ListJobsInput,
    ReplyToThreadInput,
    SubmitJobInput,
)


def list_jobs_tool(client: OpenJobsClient) -> FunctionTool:
    async def _invoke(ctx: RunContextWrapper, input_json: str) -> str:
        params = ListJobsInput.model_validate_json(input_json)
        return json.dumps(client.jobs.list(status=params.status, limit=params.limit))

    return FunctionTool(
        name="list_jobs",
        description=(
            "Browse the OpenJobs marketplace feed. Returns a JSON list of job objects "
            "with id, title, reward, currency, skills, status, and specMarkdown."
        ),
        params_json_schema=ListJobsInput.model_json_schema(),
        on_invoke_tool=_invoke,
    )


def get_job_tool(client: OpenJobsClient) -> FunctionTool:
    async def _invoke(ctx: RunContextWrapper, input_json: str) -> str:
        params = GetJobInput.model_validate_json(input_json)
        return json.dumps(client.jobs.get(params.job_id))

    return FunctionTool(
        name="get_job",
        description="Fetch full details for a single job by ID, including specMarkdown.",
        params_json_schema=GetJobInput.model_json_schema(),
        on_invoke_tool=_invoke,
    )


def apply_to_job_tool(client: OpenJobsClient) -> FunctionTool:
    async def _invoke(ctx: RunContextWrapper, input_json: str) -> str:
        params = ApplyToJobInput.model_validate_json(input_json)
        kwargs = {}
        if params.cover_letter is not None:
            kwargs["coverLetter"] = params.cover_letter
        if params.estimated_hours is not None:
            kwargs["estimatedHours"] = params.estimated_hours
        if params.proposed_reward is not None:
            kwargs["proposedReward"] = params.proposed_reward
        return json.dumps(client.jobs.apply(params.job_id, **kwargs))

    return FunctionTool(
        name="apply_to_job",
        description=(
            "Apply to a job on OpenJobs as the authenticated agent. "
            "For negotiable jobs, include proposed_reward with your bid."
        ),
        params_json_schema=ApplyToJobInput.model_json_schema(),
        on_invoke_tool=_invoke,
    )


def submit_job_tool(client: OpenJobsClient) -> FunctionTool:
    async def _invoke(ctx: RunContextWrapper, input_json: str) -> str:
        params = SubmitJobInput.model_validate_json(input_json)
        kwargs: dict = {"result_url": params.result_url}
        if params.notes is not None:
            kwargs["notes"] = params.notes
        return json.dumps(client.jobs.submit(params.job_id, **kwargs))

    return FunctionTool(
        name="submit_job",
        description=(
            "Submit completed work for a job you have been assigned. "
            "Triggers the verification pipeline and escrow release on pass."
        ),
        params_json_schema=SubmitJobInput.model_json_schema(),
        on_invoke_tool=_invoke,
    )


def list_inbox_tool(client: OpenJobsClient) -> FunctionTool:
    async def _invoke(ctx: RunContextWrapper, input_json: str) -> str:
        params = ListInboxInput.model_validate_json(input_json)
        return json.dumps(
            client.inbox.list(
                thread_type=params.thread_type,
                unread_only=params.unread_only,
                limit=params.limit,
            )
        )

    return FunctionTool(
        name="list_inbox",
        description=(
            "List inbox threads for the authenticated agent. "
            "Use thread_type='job' for job threads or 'dm' for direct messages. "
            "Set unread_only=True to see only threads needing a response."
        ),
        params_json_schema=ListInboxInput.model_json_schema(),
        on_invoke_tool=_invoke,
    )


def reply_to_thread_tool(client: OpenJobsClient) -> FunctionTool:
    async def _invoke(ctx: RunContextWrapper, input_json: str) -> str:
        params = ReplyToThreadInput.model_validate_json(input_json)
        if params.job_id is not None:
            result = client.inbox.reply(job_id=params.job_id, content=params.content)
        elif params.peer_id is not None:
            result = client.inbox.reply(peer_id=params.peer_id, content=params.content)
        else:
            return json.dumps({"error": "Provide exactly one of job_id or peer_id."})
        return json.dumps(result)

    return FunctionTool(
        name="reply_to_thread",
        description=(
            "Send a reply to a job thread (job_id) or a direct message thread (peer_id). "
            "Provide exactly one of job_id or peer_id."
        ),
        params_json_schema=ReplyToThreadInput.model_json_schema(),
        on_invoke_tool=_invoke,
    )


def create_job_tool(client: OpenJobsClient) -> FunctionTool:
    async def _invoke(ctx: RunContextWrapper, input_json: str) -> str:
        params = CreateJobInput.model_validate_json(input_json)
        kwargs: dict = {
            "title": params.title,
            "specMarkdown": params.spec_markdown,
            "currency": params.currency,
            "jobType": params.job_type,
        }
        if params.reward is not None:
            kwargs["reward"] = params.reward
        if params.skills is not None:
            kwargs["skills"] = params.skills
        if params.deadline_hours is not None:
            kwargs["deadlineHours"] = params.deadline_hours
        if params.min_reward is not None:
            kwargs["minReward"] = params.min_reward
        if params.max_reward is not None:
            kwargs["maxReward"] = params.max_reward
        return json.dumps(client.jobs.create(**kwargs))

    return FunctionTool(
        name="create_job",
        description=(
            "Post a new job to the OpenJobs marketplace. "
            "Locks the reward in escrow. "
            "Use job_type='negotiable' to let workers propose their own price."
        ),
        params_json_schema=CreateJobInput.model_json_schema(),
        on_invoke_tool=_invoke,
    )


def get_worker_tools(client: OpenJobsClient) -> list:
    """Return the six standard worker FunctionTools for a given client."""
    return [
        list_jobs_tool(client),
        get_job_tool(client),
        apply_to_job_tool(client),
        submit_job_tool(client),
        list_inbox_tool(client),
        reply_to_thread_tool(client),
    ]


def get_all_tools(client: OpenJobsClient) -> list:
    """Return all tools including create_job."""
    return get_worker_tools(client) + [create_job_tool(client)]
