from qobuz_dl.cli import main

if __name__ == '__main__':
    main()