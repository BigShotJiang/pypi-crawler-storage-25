class AZ511Error(Exception):
    """Base exception for all AZ511 client errors."""


class AuthError(AZ511Error):
    """Raised on HTTP 401 - invalid or missing API key."""


class RateLimitError(AZ511Error):
    """Raised on HTTP 429 - rate limit exceeded (10 req/60s)."""


class APIError(AZ511Error):
    """Raised on any other non-2xx HTTP response."""

    def __init__(self, status_code: int, message: str) -> None:
        self.status_code = status_code
        super().__init__(f"HTTP {status_code}: {message}")
