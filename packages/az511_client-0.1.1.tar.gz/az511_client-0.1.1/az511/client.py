import os
from typing import Any, Dict, List, Optional

import requests
from dotenv import load_dotenv

from .constants import BASE_URL, WZDX_URL
from .exceptions import APIError, AuthError, RateLimitError
from .models import (
    Alert,
    Camera,
    Event,
    MessageBoard,
    RestArea,
    WeatherStation,
    WZDxFeatureCollection,
)

class AZ511Client:
    """Client for the Arizona 511 traveler information API.

    Usage::

        client = AZ511Client()          # reads AZ511_API_KEY from environment
        client = AZ511Client(api_key="your_key")  # explicit key

    All list-returning methods raise:
        AuthError       on HTTP 401
        RateLimitError  on HTTP 429
        APIError        on any other non-2xx response
    """

    def __init__(
        self, api_key: Optional[str] = None, timeout: int = 30
    ) -> None:
        load_dotenv()
        self.api_key = api_key or os.environ["AZ511_API_KEY"]
        self.timeout = timeout
        self._session = requests.Session()

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _get(
        self, endpoint: str, extra_params: Optional[Dict[str, Any]] = None
    ) -> Any:
        """Authenticated GET to the v2 API; returns parsed JSON."""
        params: dict[str, Any] = {"key": self.api_key, "format": "json"}
        if extra_params:
            params.update(extra_params)
        url = f"{BASE_URL}/{endpoint}"
        response = self._session.get(url, params=params, timeout=self.timeout)
        self._raise_for_status(response)
        return response.json()

    def _get_unauthenticated(self, url: str) -> Any:
        """Unauthenticated GET (WZDx endpoint); returns parsed JSON."""
        response = self._session.get(url, timeout=self.timeout)
        self._raise_for_status(response)
        return response.json()

    @staticmethod
    def _raise_for_status(response: requests.Response) -> None:
        if response.status_code == 401:
            raise AuthError("Invalid or missing API key")
        if response.status_code == 429:
            raise RateLimitError("Rate limit exceeded (10 req/60s)")
        if not response.ok:
            raise APIError(response.status_code, response.text[:200])

    # ------------------------------------------------------------------
    # Stage 1: Cameras
    # ------------------------------------------------------------------

    def get_cameras(self) -> List[Camera]:
        """Return all traffic cameras."""
        data = self._get("cameras")
        return [Camera.model_validate(item) for item in data]

    # ------------------------------------------------------------------
    # Stage 2: Weather Stations
    # ------------------------------------------------------------------

    def get_weather_stations(self) -> List[WeatherStation]:
        """Return all weather stations."""
        data = self._get("weatherstations")
        return [WeatherStation.model_validate(item) for item in data]

    # ------------------------------------------------------------------
    # Stage 3: Alerts
    # ------------------------------------------------------------------

    def get_alerts(self) -> List[Alert]:
        """Return all active alerts."""
        data = self._get("alerts")
        return [Alert.model_validate(item) for item in data]

    # ------------------------------------------------------------------
    # Stage 4: Rest Areas
    # ------------------------------------------------------------------

    def get_rest_areas(self) -> List[RestArea]:
        """Return all rest areas."""
        data = self._get("restareas")
        return [RestArea.model_validate(item) for item in data]

    # ------------------------------------------------------------------
    # Stage 5: Events
    # ------------------------------------------------------------------

    def get_events(self) -> List[Event]:
        """Return all traffic events."""
        data = self._get("event")
        return [Event.model_validate(item) for item in data]

    # ------------------------------------------------------------------
    # Stage 6: Message Boards
    # ------------------------------------------------------------------

    def get_message_boards(self) -> List[MessageBoard]:
        """Return all variable message signs (VMS / message boards)."""
        data = self._get("messagesigns")
        return [MessageBoard.model_validate(item) for item in data]

    # ------------------------------------------------------------------
    # Stage 7: WZDx
    # ------------------------------------------------------------------

    def get_wzdx(self) -> WZDxFeatureCollection:
        """Return work zone data as a GeoJSON FeatureCollection (WZDx 4.x)."""
        data = self._get_unauthenticated(WZDX_URL)
        return WZDxFeatureCollection.model_validate(data)
