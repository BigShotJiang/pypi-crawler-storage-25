BASE_URL = "https://az511.com/api/v2/get"
WZDX_URL = "https://az511.com/api/wzdx"

RATE_LIMIT_CALLS = 10
RATE_LIMIT_PERIOD_SECONDS = 60
