from datetime import datetime, timezone
from typing import List, Optional

from pydantic import BaseModel, ConfigDict, Field, field_validator


class Alert(BaseModel):
    model_config = ConfigDict(extra="ignore", populate_by_name=True)

    id: int = Field(alias="Id")
    message: str = Field(alias="Message")
    # may contain raw HTML
    notes: Optional[str] = Field(alias="Notes", default=None)
    start_time: Optional[datetime] = Field(alias="StartTime", default=None)
    end_time: Optional[datetime] = Field(alias="EndTime", default=None)
    regions: List[str] = Field(alias="Regions", default_factory=list)
    high_importance: bool = Field(alias="HighImportance", default=False)
    send_notification: bool = Field(alias="SendNotification", default=False)

    @field_validator("start_time", "end_time", mode="before")
    @classmethod
    def parse_unix_timestamp(cls, v) -> Optional[datetime]:
        if v is None:
            return None
        return datetime.fromtimestamp(float(v), tz=timezone.utc)
