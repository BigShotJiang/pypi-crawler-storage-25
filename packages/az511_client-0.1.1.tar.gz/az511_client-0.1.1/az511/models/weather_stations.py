from datetime import datetime, timezone
from typing import Optional

from pydantic import BaseModel, ConfigDict, Field, field_validator


class WeatherStation(BaseModel):
    model_config = ConfigDict(extra="ignore", populate_by_name=True)

    id: int = Field(alias="Id")
    camera_source: Optional[str] = Field(alias="CameraSource", default=None)
    camera_source_id: Optional[str] = Field(
        alias="CameraSourceId", default=None
    )
    latitude: float = Field(alias="Latitude")
    longitude: float = Field(alias="Longitude")
    air_temperature: Optional[float] = Field(
        alias="AirTemperature", default=None
    )
    surface_temperature: Optional[float] = Field(
        alias="SurfaceTemperature", default=None
    )
    wind_speed: Optional[float] = Field(alias="WindSpeed", default=None)
    wind_direction: Optional[str] = Field(alias="WindDirection", default=None)
    relative_humidity: Optional[float] = Field(
        alias="RelativeHumidity", default=None
    )
    level_of_grip: Optional[str] = Field(alias="LevelOfGrip", default=None)
    max_wind_speed: Optional[float] = Field(alias="MaxWindSpeed", default=None)
    last_updated: Optional[datetime] = Field(alias="LastUpdated", default=None)

    @field_validator("last_updated", mode="before")
    @classmethod
    def parse_unix_timestamp(cls, v) -> Optional[datetime]:
        if v is None:
            return None
        return datetime.fromtimestamp(float(v), tz=timezone.utc)
