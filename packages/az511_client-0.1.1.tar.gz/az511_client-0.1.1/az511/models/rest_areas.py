from typing import Optional

from pydantic import BaseModel, ConfigDict, Field, field_validator


class RestArea(BaseModel):
    model_config = ConfigDict(extra="ignore", populate_by_name=True)

    id: int = Field(alias="Id")
    latitude: float = Field(alias="Latitude")
    longitude: float = Field(alias="Longitude")
    name: str = Field(alias="Name")
    status: str = Field(alias="Status")
    location: Optional[str] = Field(alias="Location", default=None)
    city: Optional[str] = Field(alias="City", default=None)
    restroom: bool = Field(alias="Restroom", default=False)
    ramada: bool = Field(alias="Ramada", default=False)
    visitor_center: bool = Field(alias="VisitorCenter", default=False)
    travel_information: bool = Field(alias="TravelInformation", default=False)
    vending_machine: bool = Field(alias="VendingMachine", default=False)
    total_truck_spaces: Optional[int] = Field(
        alias="TotalTruckSpaces", default=None
    )
    available_truck_spaces: Optional[int] = Field(
        alias="AvailableTruckSpaces", default=None
    )

    @field_validator(
        "restroom", "ramada", "visitor_center",
        "travel_information", "vending_machine",
        mode="before",
    )
    @classmethod
    def parse_yes_no_bool(cls, v) -> bool:
        if isinstance(v, bool):
            return v
        if isinstance(v, int):
            return bool(v)
        if isinstance(v, str):
            return v.strip().lower() in ("yes", "true", "1")
        return False

    @field_validator("total_truck_spaces", "available_truck_spaces", mode="before")
    @classmethod
    def parse_truck_spaces(cls, v) -> Optional[int]:
        if v is None:
            return None
        try:
            return int(v)
        except (ValueError, TypeError):
            return None
