from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Union

from pydantic import BaseModel, ConfigDict, Field, field_validator


class EventRestrictions(BaseModel):
    model_config = ConfigDict(extra="ignore")

    width: Optional[float] = Field(alias="Width", default=None)
    height: Optional[float] = Field(alias="Height", default=None)
    length: Optional[float] = Field(alias="Length", default=None)
    weight: Optional[float] = Field(alias="Weight", default=None)
    speed: Optional[float] = Field(alias="Speed", default=None)


class Event(BaseModel):
    model_config = ConfigDict(extra="ignore", populate_by_name=True)

    id: Optional[int] = Field(alias="ID", default=None)
    source_id: Optional[str] = Field(alias="SourceId", default=None)
    organization: Optional[str] = Field(alias="Organization", default=None)
    roadway_name: Optional[str] = Field(alias="RoadwayName", default=None)
    direction_of_travel: Optional[str] = Field(
        alias="DirectionOfTravel", default=None
    )
    description: Optional[str] = Field(alias="Description", default=None)
    reported: Optional[datetime] = Field(alias="Reported", default=None)
    last_updated: Optional[datetime] = Field(alias="LastUpdated", default=None)
    start_date: Optional[datetime] = Field(alias="StartDate", default=None)
    planned_end_date: Optional[datetime] = Field(
        alias="PlannedEndDate", default=None
    )
    lanes_affected: Optional[str] = Field(alias="LanesAffected", default=None)
    latitude: Optional[float] = Field(alias="Latitude", default=None)
    longitude: Optional[float] = Field(alias="Longitude", default=None)
    latitude_secondary: Optional[float] = Field(
        alias="LatitudeSecondary", default=None
    )
    longitude_secondary: Optional[float] = Field(
        alias="LongitudeSecondary", default=None
    )
    event_type: Optional[str] = Field(alias="EventType", default=None)
    event_sub_type: Optional[str] = Field(alias="EventSubType", default=None)
    is_full_closure: Optional[bool] = Field(
        alias="IsFullClosure", default=None
    )
    severity: Optional[str] = Field(alias="Severity", default=None)
    encoded_polyline: Optional[str] = Field(
        alias="EncodedPolyline", default=None
    )
    restrictions: Optional[EventRestrictions] = Field(
        alias="Restrictions", default=None
    )
    detour_polyline: Optional[str] = Field(
        alias="DetourPolyline", default=None
    )
    detour_instructions: Optional[Any] = Field(
        alias="DetourInstructions", default=None
    )
    recurrence: Optional[str] = Field(alias="Recurrence", default=None)
    recurrence_schedules: Optional[Any] = Field(
        alias="RecurrenceSchedules", default=None
    )
    details: Optional[str] = Field(alias="Details", default=None)
    lane_count: Optional[int] = Field(alias="LaneCount", default=None)

    @field_validator(
        "reported", "last_updated", "start_date", "planned_end_date",
        mode="before",
    )
    @classmethod
    def parse_unix_timestamp(cls, v) -> Optional[datetime]:
        if v is None:
            return None
        try:
            return datetime.fromtimestamp(float(v), tz=timezone.utc)
        except (OSError, OverflowError, ValueError):
            # Sentinel values like 35659335599 (year ~3099) overflow on Windows
            return None
