from datetime import datetime, timezone
from typing import List, Optional

from pydantic import BaseModel, ConfigDict, Field, field_validator


class MessageBoard(BaseModel):
    model_config = ConfigDict(extra="ignore", populate_by_name=True)

    id: str = Field(alias="Id")
    name: str = Field(alias="Name")
    roadway: str = Field(alias="Roadway")
    direction_of_travel: str = Field(alias="DirectionOfTravel")
    messages: List[str] = Field(alias="Messages", default_factory=list)
    latitude: float = Field(alias="Latitude")
    longitude: float = Field(alias="Longitude")
    last_updated: Optional[datetime] = Field(alias="LastUpdated", default=None)

    @field_validator("last_updated", mode="before")
    @classmethod
    def parse_unix_timestamp(cls, v) -> Optional[datetime]:
        if v is None:
            return None
        try:
            return datetime.fromtimestamp(float(v), tz=timezone.utc)
        except (OSError, OverflowError, ValueError):
            return None
