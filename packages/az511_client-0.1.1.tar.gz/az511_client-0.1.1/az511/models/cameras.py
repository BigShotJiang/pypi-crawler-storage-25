from typing import List

from pydantic import BaseModel, ConfigDict, Field


class CameraView(BaseModel):
    model_config = ConfigDict(extra="ignore")

    id: int = Field(alias="Id")
    url: str = Field(alias="Url")
    status: str = Field(alias="Status")
    description: str = Field(alias="Description")


class Camera(BaseModel):
    model_config = ConfigDict(extra="ignore", populate_by_name=True)

    id: int = Field(alias="Id")
    source: str = Field(alias="Source")
    source_id: str = Field(alias="SourceId")
    roadway: str = Field(alias="Roadway")
    direction: str = Field(alias="Direction")
    latitude: float = Field(alias="Latitude")
    longitude: float = Field(alias="Longitude")
    location: str = Field(alias="Location")
    sort_order: int = Field(alias="SortOrder")
    views: List[CameraView] = Field(alias="Views", default_factory=list)
