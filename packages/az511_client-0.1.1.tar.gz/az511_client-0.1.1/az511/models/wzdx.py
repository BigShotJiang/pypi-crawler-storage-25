from typing import Any, Dict, List, Optional

from pydantic import BaseModel, ConfigDict, Field


class WZDxProperties(BaseModel):
    """Properties from a WZDx 4.x road event feature."""

    model_config = ConfigDict(extra="ignore")

    road_name: Optional[str] = Field(default=None)
    road_number: Optional[str] = Field(default=None)
    direction: Optional[str] = Field(default=None)
    beginning_milepost: Optional[float] = Field(default=None)
    ending_milepost: Optional[float] = Field(default=None)
    start_date: Optional[str] = Field(default=None)
    end_date: Optional[str] = Field(default=None)
    start_date_accuracy: Optional[str] = Field(default=None)
    end_date_accuracy: Optional[str] = Field(default=None)
    event_status: Optional[str] = Field(default=None)
    vehicle_impact: Optional[str] = Field(default=None)
    description: Optional[str] = Field(default=None)
    creation_date: Optional[str] = Field(default=None)
    update_date: Optional[str] = Field(default=None)


class WZDxFeature(BaseModel):
    """A single GeoJSON Feature in a WZDx FeatureCollection."""

    model_config = ConfigDict(extra="ignore")

    type: str
    geometry: Dict[str, Any]
    properties: WZDxProperties


class WZDxFeatureCollection(BaseModel):
    """Top-level GeoJSON FeatureCollection returned by the WZDx endpoint."""

    model_config = ConfigDict(extra="ignore")

    type: str
    features: List[WZDxFeature] = Field(default_factory=list)
