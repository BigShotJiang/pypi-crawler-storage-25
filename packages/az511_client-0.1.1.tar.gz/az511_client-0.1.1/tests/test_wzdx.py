"""Stage 7: Tests for the WZDx endpoint (GeoJSON FeatureCollection)."""

import pytest
import responses as rsps

from az511.client import AZ511Client
from az511.exceptions import APIError
from az511.models import WZDxFeature, WZDxFeatureCollection

WZDX_URL = "https://az511.com/api/wzdx"

FIXTURE = {
    "type": "FeatureCollection",
    "features": [
        {
            "type": "Feature",
            "geometry": {
                "type": "LineString",
                "coordinates": [[-112.074, 33.448], [-112.075, 33.449]],
            },
            "properties": {
                "road_name": "I-10",
                "direction": "eastbound",
                "beginning_milepost": 145.0,
                "ending_milepost": 146.2,
                "start_date": "2023-11-01T00:00:00Z",
                "end_date": "2023-12-01T00:00:00Z",
                "event_status": "active",
                "vehicle_impact": "some-lanes-closed",
                "description": "Lane closure for bridge repair",
            },
        }
    ],
}


@rsps.activate
def test_get_wzdx_returns_feature_collection(client: AZ511Client) -> None:
    rsps.add(rsps.GET, WZDX_URL, json=FIXTURE, status=200)
    result = client.get_wzdx()
    assert isinstance(result, WZDxFeatureCollection)
    assert result.type == "FeatureCollection"
    assert len(result.features) == 1


@rsps.activate
def test_get_wzdx_feature_structure(client: AZ511Client) -> None:
    rsps.add(rsps.GET, WZDX_URL, json=FIXTURE, status=200)
    feature = client.get_wzdx().features[0]
    assert isinstance(feature, WZDxFeature)
    assert feature.type == "Feature"
    assert feature.geometry["type"] == "LineString"
    assert len(feature.geometry["coordinates"]) == 2


@rsps.activate
def test_get_wzdx_properties(client: AZ511Client) -> None:
    rsps.add(rsps.GET, WZDX_URL, json=FIXTURE, status=200)
    props = client.get_wzdx().features[0].properties
    assert props.road_name == "I-10"
    assert props.direction == "eastbound"
    assert props.beginning_milepost == 145.0
    assert props.ending_milepost == 146.2
    assert props.event_status == "active"
    assert props.vehicle_impact == "some-lanes-closed"


@rsps.activate
def test_get_wzdx_empty_features(client: AZ511Client) -> None:
    rsps.add(rsps.GET, WZDX_URL, json={"type": "FeatureCollection", "features": []}, status=200)
    result = client.get_wzdx()
    assert result.features == []


@rsps.activate
def test_get_wzdx_no_api_key_sent(client: AZ511Client) -> None:
    """WZDx requests must NOT include the key param."""
    rsps.add(rsps.GET, WZDX_URL, json=FIXTURE, status=200)
    client.get_wzdx()
    assert len(rsps.calls) == 1
    request_url = rsps.calls[0].request.url
    assert "key=" not in request_url


@rsps.activate
def test_get_wzdx_server_error(client: AZ511Client) -> None:
    rsps.add(rsps.GET, WZDX_URL, status=500, body="Internal Server Error")
    with pytest.raises(APIError) as exc_info:
        client.get_wzdx()
    assert exc_info.value.status_code == 500


@rsps.activate
def test_get_wzdx_extra_fields_ignored(client: AZ511Client) -> None:
    fixture = {**FIXTURE, "feed_info": {"publisher": "AZDOT", "version": "4.1"}}
    rsps.add(rsps.GET, WZDX_URL, json=fixture, status=200)
    result = client.get_wzdx()
    assert result.type == "FeatureCollection"


@rsps.activate
def test_get_wzdx_property_extra_fields_ignored(client: AZ511Client) -> None:
    feature = {
        **FIXTURE["features"][0],
        "properties": {
            **FIXTURE["features"][0]["properties"],
            "core_details": {"data_source_id": "abc", "event_type": "work-zone"},
        },
    }
    fixture = {"type": "FeatureCollection", "features": [feature]}
    rsps.add(rsps.GET, WZDX_URL, json=fixture, status=200)
    result = client.get_wzdx()
    assert result.features[0].properties.road_name == "I-10"
