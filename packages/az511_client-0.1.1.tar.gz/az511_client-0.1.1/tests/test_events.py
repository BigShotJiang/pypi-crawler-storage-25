"""Stage 5: Tests for the /event endpoint."""

from datetime import datetime, timezone

import pytest
import responses as rsps

from az511.client import AZ511Client
from az511.exceptions import APIError, AuthError, RateLimitError
from az511.models import Event

EVENTS_URL = "https://az511.com/api/v2/get/event"

FIXTURE = [
    {
        "ID": 5001,
        "SourceId": "1162",
        "Organization": "TRAVELIQ",
        "RoadwayName": "I-10",
        "DirectionOfTravel": "Both",
        "Description": "Lane closure for bridge repair.",
        "Reported": 1724364840,
        "LastUpdated": 1724364909,
        "StartDate": 1724364840,
        "PlannedEndDate": 1787436840,
        "LanesAffected": "Left Lane",
        "Latitude": 33.4484,
        "Longitude": -112.0740,
        "LatitudeSecondary": 33.4490,
        "LongitudeSecondary": -112.0750,
        "EventType": "roadwork",
        "EventSubType": "Road widening",
        "IsFullClosure": False,
        "Severity": "Major",
        "EncodedPolyline": "ay|iEpfbiT",
        "Restrictions": {
            "Width": None,
            "Height": None,
            "Length": None,
            "Weight": None,
            "Speed": None,
        },
        "DetourPolyline": "",
        "DetourInstructions": "",
        "Recurrence": "Active all day",
        "RecurrenceSchedules": "",
        "Details": "",
        "LaneCount": None,
    }
]


@rsps.activate
def test_get_events_returns_list(client: AZ511Client) -> None:
    rsps.add(rsps.GET, EVENTS_URL, json=FIXTURE, status=200)
    result = client.get_events()
    assert len(result) == 1
    event = result[0]
    assert isinstance(event, Event)
    assert event.id == 5001
    assert event.organization == "TRAVELIQ"
    assert event.roadway_name == "I-10"
    assert event.direction_of_travel == "Both"
    assert event.event_type == "roadwork"
    assert event.severity == "Major"
    assert event.is_full_closure is False
    assert event.latitude == 33.4484
    assert event.longitude == -112.0740


@rsps.activate
def test_get_events_timestamps_converted(client: AZ511Client) -> None:
    rsps.add(rsps.GET, EVENTS_URL, json=FIXTURE, status=200)
    event = client.get_events()[0]
    assert isinstance(event.reported, datetime)
    assert event.reported.tzinfo == timezone.utc
    assert isinstance(event.start_date, datetime)
    assert isinstance(event.planned_end_date, datetime)


@rsps.activate
def test_get_events_restrictions(client: AZ511Client) -> None:
    rsps.add(rsps.GET, EVENTS_URL, json=FIXTURE, status=200)
    event = client.get_events()[0]
    assert event.restrictions is not None
    assert event.restrictions.width is None
    assert event.restrictions.speed is None


@rsps.activate
def test_get_events_all_none_fields(client: AZ511Client) -> None:
    """Model must not crash when all Optional fields are absent."""
    rsps.add(rsps.GET, EVENTS_URL, json=[{}], status=200)
    result = client.get_events()
    assert len(result) == 1
    assert result[0].id is None


@rsps.activate
def test_get_events_empty_list(client: AZ511Client) -> None:
    rsps.add(rsps.GET, EVENTS_URL, json=[], status=200)
    assert client.get_events() == []


@rsps.activate
def test_get_events_auth_error(client: AZ511Client) -> None:
    rsps.add(rsps.GET, EVENTS_URL, status=401)
    with pytest.raises(AuthError):
        client.get_events()


@rsps.activate
def test_get_events_rate_limit(client: AZ511Client) -> None:
    rsps.add(rsps.GET, EVENTS_URL, status=429)
    with pytest.raises(RateLimitError):
        client.get_events()


@rsps.activate
def test_get_events_server_error(client: AZ511Client) -> None:
    rsps.add(rsps.GET, EVENTS_URL, status=500, body="Internal Server Error")
    with pytest.raises(APIError) as exc_info:
        client.get_events()
    assert exc_info.value.status_code == 500


@rsps.activate
def test_get_events_extra_fields_ignored(client: AZ511Client) -> None:
    fixture = [{**FIXTURE[0], "UnexpectedNewField": "surprise"}]
    rsps.add(rsps.GET, EVENTS_URL, json=fixture, status=200)
    result = client.get_events()
    assert result[0].id == 5001
