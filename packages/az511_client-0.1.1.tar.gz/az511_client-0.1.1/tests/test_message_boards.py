"""Stage 6: Tests for the /messagesigns endpoint."""

from datetime import datetime, timezone

import pytest
import responses as rsps

from az511.client import AZ511Client
from az511.exceptions import APIError, AuthError, RateLimitError
from az511.models import MessageBoard

MESSAGE_BOARDS_URL = "https://az511.com/api/v2/get/messagesigns"

FIXTURE = [
    {
        "Id": "AZ--ab15977e-939f-4552-b756-98aef65830b0",
        "Name": "I-10 EB @ 35th Ave",
        "Roadway": "I-10",
        "DirectionOfTravel": "Eastbound",
        "Messages": [
            "MINUTES TO AIRPORT\r\nVIA I-10        11\r\nVIA I-17        10"
        ],
        "Latitude": 33.4625873310001,
        "Longitude": -112.13473724,
        "LastUpdated": 1700000000,
    }
]


@rsps.activate
def test_get_message_boards_returns_list(client: AZ511Client) -> None:
    rsps.add(rsps.GET, MESSAGE_BOARDS_URL, json=FIXTURE, status=200)
    result = client.get_message_boards()
    assert len(result) == 1
    mb = result[0]
    assert isinstance(mb, MessageBoard)
    assert mb.id == "AZ--ab15977e-939f-4552-b756-98aef65830b0"
    assert mb.name == "I-10 EB @ 35th Ave"
    assert mb.roadway == "I-10"
    assert mb.direction_of_travel == "Eastbound"
    assert mb.latitude == 33.4625873310001
    assert mb.longitude == -112.13473724


@rsps.activate
def test_get_message_boards_messages_list(client: AZ511Client) -> None:
    rsps.add(rsps.GET, MESSAGE_BOARDS_URL, json=FIXTURE, status=200)
    mb = client.get_message_boards()[0]
    assert len(mb.messages) == 1
    assert "AIRPORT" in mb.messages[0]


@rsps.activate
def test_get_message_boards_timestamp_conversion(client: AZ511Client) -> None:
    rsps.add(rsps.GET, MESSAGE_BOARDS_URL, json=FIXTURE, status=200)
    mb = client.get_message_boards()[0]
    assert isinstance(mb.last_updated, datetime)
    assert mb.last_updated.tzinfo == timezone.utc
    expected = datetime(2023, 11, 14, 22, 13, 20, tzinfo=timezone.utc)
    assert mb.last_updated == expected


@rsps.activate
def test_get_message_boards_null_timestamp(client: AZ511Client) -> None:
    fixture = [{**FIXTURE[0], "LastUpdated": None}]
    rsps.add(rsps.GET, MESSAGE_BOARDS_URL, json=fixture, status=200)
    assert client.get_message_boards()[0].last_updated is None


@rsps.activate
def test_get_message_boards_empty_messages(client: AZ511Client) -> None:
    fixture = [{**FIXTURE[0], "Messages": []}]
    rsps.add(rsps.GET, MESSAGE_BOARDS_URL, json=fixture, status=200)
    assert client.get_message_boards()[0].messages == []


@rsps.activate
def test_get_message_boards_empty_list(client: AZ511Client) -> None:
    rsps.add(rsps.GET, MESSAGE_BOARDS_URL, json=[], status=200)
    assert client.get_message_boards() == []


@rsps.activate
def test_get_message_boards_auth_error(client: AZ511Client) -> None:
    rsps.add(rsps.GET, MESSAGE_BOARDS_URL, status=401)
    with pytest.raises(AuthError):
        client.get_message_boards()


@rsps.activate
def test_get_message_boards_rate_limit(client: AZ511Client) -> None:
    rsps.add(rsps.GET, MESSAGE_BOARDS_URL, status=429)
    with pytest.raises(RateLimitError):
        client.get_message_boards()


@rsps.activate
def test_get_message_boards_server_error(client: AZ511Client) -> None:
    rsps.add(rsps.GET, MESSAGE_BOARDS_URL, status=500,
             body="Internal Server Error")
    with pytest.raises(APIError) as exc_info:
        client.get_message_boards()
    assert exc_info.value.status_code == 500


@rsps.activate
def test_get_message_boards_extra_fields_ignored(client: AZ511Client) -> None:
    fixture = [{**FIXTURE[0], "UnexpectedNewField": "surprise"}]
    rsps.add(rsps.GET, MESSAGE_BOARDS_URL, json=fixture, status=200)
    result = client.get_message_boards()
    assert result[0].name == "I-10 EB @ 35th Ave"
