"""Stage 1: Tests for the /cameras endpoint."""

import responses as rsps

from az511.client import AZ511Client
from az511.exceptions import APIError, AuthError, RateLimitError
from az511.models import Camera

CAMERAS_URL = "https://az511.com/api/v2/get/cameras"

FIXTURE = [
    {
        "Id": 1001,
        "Source": "ADOT",
        "SourceId": "CAM001",
        "Roadway": "I-10",
        "Direction": "Eastbound",
        "Latitude": 33.4484,
        "Longitude": -112.0740,
        "Location": "I-10 @ 7th Ave",
        "SortOrder": 1,
        "Views": [
            {
                "Id": 1,
                "Url": "https://example.com/cam1.jpg",
                "Status": "active",
                "Description": "Overview",
            }
        ],
    }
]


@rsps.activate
def test_get_cameras_returns_camera_list(client: AZ511Client) -> None:
    rsps.add(rsps.GET, CAMERAS_URL, json=FIXTURE, status=200)
    result = client.get_cameras()
    assert len(result) == 1
    cam = result[0]
    assert isinstance(cam, Camera)
    assert cam.id == 1001
    assert cam.source == "ADOT"
    assert cam.source_id == "CAM001"
    assert cam.roadway == "I-10"
    assert cam.direction == "Eastbound"
    assert cam.latitude == 33.4484
    assert cam.longitude == -112.0740
    assert cam.location == "I-10 @ 7th Ave"
    assert cam.sort_order == 1


@rsps.activate
def test_get_cameras_nested_views(client: AZ511Client) -> None:
    rsps.add(rsps.GET, CAMERAS_URL, json=FIXTURE, status=200)
    cam = client.get_cameras()[0]
    assert len(cam.views) == 1
    view = cam.views[0]
    assert view.id == 1
    assert view.url == "https://example.com/cam1.jpg"
    assert view.status == "active"
    assert view.description == "Overview"


@rsps.activate
def test_get_cameras_empty_list(client: AZ511Client) -> None:
    rsps.add(rsps.GET, CAMERAS_URL, json=[], status=200)
    result = client.get_cameras()
    assert result == []


@rsps.activate
def test_get_cameras_no_views_defaults_to_empty(client: AZ511Client) -> None:
    fixture = [{**FIXTURE[0], "Views": []}]
    rsps.add(rsps.GET, CAMERAS_URL, json=fixture, status=200)
    cam = client.get_cameras()[0]
    assert cam.views == []


@rsps.activate
def test_get_cameras_auth_error(client: AZ511Client) -> None:
    rsps.add(rsps.GET, CAMERAS_URL, status=401)
    import pytest
    with pytest.raises(AuthError):
        client.get_cameras()


@rsps.activate
def test_get_cameras_rate_limit_error(client: AZ511Client) -> None:
    rsps.add(rsps.GET, CAMERAS_URL, status=429)
    import pytest
    with pytest.raises(RateLimitError):
        client.get_cameras()


@rsps.activate
def test_get_cameras_server_error(client: AZ511Client) -> None:
    rsps.add(rsps.GET, CAMERAS_URL, status=500, body="Internal Server Error")
    import pytest
    with pytest.raises(APIError) as exc_info:
        client.get_cameras()
    assert exc_info.value.status_code == 500


@rsps.activate
def test_get_cameras_extra_fields_ignored(client: AZ511Client) -> None:
    """Unknown fields from the API must not raise a validation error."""
    extra = {"NewUnknownField": "surprise", "AnotherField": 42}
    fixture = [{**FIXTURE[0], **extra}]
    rsps.add(rsps.GET, CAMERAS_URL, json=fixture, status=200)
    result = client.get_cameras()
    assert result[0].id == 1001
