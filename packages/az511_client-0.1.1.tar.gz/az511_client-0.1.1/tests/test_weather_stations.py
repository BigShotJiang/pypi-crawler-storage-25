"""Stage 2: Tests for the /weatherstations endpoint."""

from datetime import datetime, timezone

import pytest
import responses as rsps

from az511.client import AZ511Client
from az511.exceptions import APIError, AuthError, RateLimitError
from az511.models import WeatherStation

WEATHER_URL = "https://az511.com/api/v2/get/weatherstations"

FIXTURE = [
    {
        "Id": 2001,
        "CameraSource": "ADOT",
        "CameraSourceId": "WS001",
        "Latitude": 34.0489,
        "Longitude": -111.0937,
        "AirTemperature": 72.5,
        "SurfaceTemperature": 80.1,
        "WindSpeed": 12.3,
        "WindDirection": "NW",
        "RelativeHumidity": 25.0,
        "LevelOfGrip": "Good",
        "MaxWindSpeed": 18.7,
        "LastUpdated": 1700000000,
    }
]


@rsps.activate
def test_get_weather_stations_returns_list(client: AZ511Client) -> None:
    rsps.add(rsps.GET, WEATHER_URL, json=FIXTURE, status=200)
    result = client.get_weather_stations()
    assert len(result) == 1
    ws = result[0]
    assert isinstance(ws, WeatherStation)
    assert ws.id == 2001
    assert ws.camera_source == "ADOT"
    assert ws.latitude == 34.0489
    assert ws.longitude == -111.0937
    assert ws.air_temperature == 72.5
    assert ws.surface_temperature == 80.1
    assert ws.wind_speed == 12.3
    assert ws.wind_direction == "NW"
    assert ws.relative_humidity == 25.0
    assert ws.level_of_grip == "Good"
    assert ws.max_wind_speed == 18.7


@rsps.activate
def test_get_weather_stations_timestamp_conversion(client: AZ511Client) -> None:
    """LastUpdated unix int must be converted to a timezone-aware datetime."""
    rsps.add(rsps.GET, WEATHER_URL, json=FIXTURE, status=200)
    ws = client.get_weather_stations()[0]
    assert isinstance(ws.last_updated, datetime)
    assert ws.last_updated.tzinfo == timezone.utc
    expected = datetime(2023, 11, 14, 22, 13, 20, tzinfo=timezone.utc)
    assert ws.last_updated == expected


@rsps.activate
def test_get_weather_stations_null_timestamp(client: AZ511Client) -> None:
    fixture = [{**FIXTURE[0], "LastUpdated": None}]
    rsps.add(rsps.GET, WEATHER_URL, json=fixture, status=200)
    ws = client.get_weather_stations()[0]
    assert ws.last_updated is None


@rsps.activate
def test_get_weather_stations_nullable_sensor_fields(
    client: AZ511Client,
) -> None:
    """Sensor fields may be absent; model must default to None."""
    minimal = {"Id": 9, "Latitude": 33.0, "Longitude": -112.0}
    rsps.add(rsps.GET, WEATHER_URL, json=[minimal], status=200)
    ws = client.get_weather_stations()[0]
    assert ws.air_temperature is None
    assert ws.wind_speed is None
    assert ws.last_updated is None


@rsps.activate
def test_get_weather_stations_empty_list(client: AZ511Client) -> None:
    rsps.add(rsps.GET, WEATHER_URL, json=[], status=200)
    assert client.get_weather_stations() == []


@rsps.activate
def test_get_weather_stations_auth_error(client: AZ511Client) -> None:
    rsps.add(rsps.GET, WEATHER_URL, status=401)
    with pytest.raises(AuthError):
        client.get_weather_stations()


@rsps.activate
def test_get_weather_stations_rate_limit(client: AZ511Client) -> None:
    rsps.add(rsps.GET, WEATHER_URL, status=429)
    with pytest.raises(RateLimitError):
        client.get_weather_stations()


@rsps.activate
def test_get_weather_stations_server_error(client: AZ511Client) -> None:
    rsps.add(rsps.GET, WEATHER_URL, status=500, body="Internal Server Error")
    with pytest.raises(APIError) as exc_info:
        client.get_weather_stations()
    assert exc_info.value.status_code == 500


@rsps.activate
def test_get_weather_stations_extra_fields_ignored(
    client: AZ511Client,
) -> None:
    fixture = [{**FIXTURE[0], "FutureField": "value"}]
    rsps.add(rsps.GET, WEATHER_URL, json=fixture, status=200)
    result = client.get_weather_stations()
    assert result[0].id == 2001
