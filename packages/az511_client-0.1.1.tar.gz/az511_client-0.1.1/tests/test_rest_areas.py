"""Stage 4: Tests for the /restareas endpoint."""

import pytest
import responses as rsps

from az511.client import AZ511Client
from az511.exceptions import APIError, AuthError, RateLimitError
from az511.models import RestArea

REST_AREAS_URL = "https://az511.com/api/v2/get/restareas"

FIXTURE = [
    {
        "Id": 4001,
        "Latitude": 33.1234,
        "Longitude": -111.5678,
        "Name": "Sacaton Rest Area",
        "Status": "Open",
        "Location": "I-10 / MP 175",
        "City": "Sacaton",
        "Restroom": True,
        "Ramada": True,
        "VisitorCenter": False,
        "TravelInformation": True,
        "VendingMachine": False,
        "TotalTruckSpaces": 20,
        "AvailableTruckSpaces": 7,
    }
]


@rsps.activate
def test_get_rest_areas_returns_list(client: AZ511Client) -> None:
    rsps.add(rsps.GET, REST_AREAS_URL, json=FIXTURE, status=200)
    result = client.get_rest_areas()
    assert len(result) == 1
    ra = result[0]
    assert isinstance(ra, RestArea)
    assert ra.id == 4001
    assert ra.name == "Sacaton Rest Area"
    assert ra.status == "Open"
    assert ra.location == "I-10 / MP 175"
    assert ra.city == "Sacaton"
    assert ra.latitude == 33.1234
    assert ra.longitude == -111.5678


@rsps.activate
def test_get_rest_areas_boolean_fields_true(client: AZ511Client) -> None:
    rsps.add(rsps.GET, REST_AREAS_URL, json=FIXTURE, status=200)
    ra = client.get_rest_areas()[0]
    assert ra.restroom is True
    assert ra.ramada is True
    assert ra.visitor_center is False
    assert ra.travel_information is True
    assert ra.vending_machine is False


@rsps.activate
def test_get_rest_areas_yes_no_boolean_strings(client: AZ511Client) -> None:
    """API may return 'Yes'/'No' strings instead of booleans."""
    fixture = [
        {
            **FIXTURE[0],
            "Restroom": "Yes",
            "Ramada": "No",
            "VisitorCenter": "Yes",
            "TravelInformation": "No",
            "VendingMachine": "Yes",
        }
    ]
    rsps.add(rsps.GET, REST_AREAS_URL, json=fixture, status=200)
    ra = client.get_rest_areas()[0]
    assert ra.restroom is True
    assert ra.ramada is False
    assert ra.visitor_center is True
    assert ra.travel_information is False
    assert ra.vending_machine is True


@rsps.activate
def test_get_rest_areas_truck_spaces(client: AZ511Client) -> None:
    rsps.add(rsps.GET, REST_AREAS_URL, json=FIXTURE, status=200)
    ra = client.get_rest_areas()[0]
    assert ra.total_truck_spaces == 20
    assert ra.available_truck_spaces == 7


@rsps.activate
def test_get_rest_areas_nullable_truck_spaces(client: AZ511Client) -> None:
    fixture = [{**FIXTURE[0], "TotalTruckSpaces": None,
                "AvailableTruckSpaces": None}]
    rsps.add(rsps.GET, REST_AREAS_URL, json=fixture, status=200)
    ra = client.get_rest_areas()[0]
    assert ra.total_truck_spaces is None
    assert ra.available_truck_spaces is None


@rsps.activate
def test_get_rest_areas_empty_list(client: AZ511Client) -> None:
    rsps.add(rsps.GET, REST_AREAS_URL, json=[], status=200)
    assert client.get_rest_areas() == []


@rsps.activate
def test_get_rest_areas_auth_error(client: AZ511Client) -> None:
    rsps.add(rsps.GET, REST_AREAS_URL, status=401)
    with pytest.raises(AuthError):
        client.get_rest_areas()


@rsps.activate
def test_get_rest_areas_rate_limit(client: AZ511Client) -> None:
    rsps.add(rsps.GET, REST_AREAS_URL, status=429)
    with pytest.raises(RateLimitError):
        client.get_rest_areas()


@rsps.activate
def test_get_rest_areas_server_error(client: AZ511Client) -> None:
    rsps.add(rsps.GET, REST_AREAS_URL, status=500,
             body="Internal Server Error")
    with pytest.raises(APIError) as exc_info:
        client.get_rest_areas()
    assert exc_info.value.status_code == 500


@rsps.activate
def test_get_rest_areas_extra_fields_ignored(client: AZ511Client) -> None:
    fixture = [{**FIXTURE[0], "FutureField": "value"}]
    rsps.add(rsps.GET, REST_AREAS_URL, json=fixture, status=200)
    result = client.get_rest_areas()
    assert result[0].id == 4001
