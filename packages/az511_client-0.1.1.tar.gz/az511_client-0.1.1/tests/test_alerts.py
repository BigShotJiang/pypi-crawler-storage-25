"""Stage 3: Tests for the /alerts endpoint."""

from datetime import datetime, timezone

import pytest
import responses as rsps

from az511.client import AZ511Client
from az511.exceptions import APIError, AuthError, RateLimitError
from az511.models import Alert

ALERTS_URL = "https://az511.com/api/v2/get/alerts"

FIXTURE = [
    {
        "Id": 3001,
        "Message": "Road closure on I-17",
        "Notes": "<p>I-17 northbound closed at MP 195 due to accident.</p>",
        "StartTime": 1700000000,
        "EndTime": 1700086400,
        "Regions": ["Maricopa", "Yavapai"],
        "HighImportance": True,
        "SendNotification": False,
    }
]


@rsps.activate
def test_get_alerts_returns_list(client: AZ511Client) -> None:
    rsps.add(rsps.GET, ALERTS_URL, json=FIXTURE, status=200)
    result = client.get_alerts()
    assert len(result) == 1
    alert = result[0]
    assert isinstance(alert, Alert)
    assert alert.id == 3001
    assert alert.message == "Road closure on I-17"
    assert alert.high_importance is True
    assert alert.send_notification is False


@rsps.activate
def test_get_alerts_timestamps_converted(client: AZ511Client) -> None:
    """StartTime and EndTime unix ints must become timezone-aware datetimes."""
    rsps.add(rsps.GET, ALERTS_URL, json=FIXTURE, status=200)
    alert = client.get_alerts()[0]
    assert isinstance(alert.start_time, datetime)
    assert alert.start_time.tzinfo == timezone.utc
    assert alert.start_time == datetime(2023, 11, 14, 22, 13, 20, tzinfo=timezone.utc)
    assert isinstance(alert.end_time, datetime)
    assert alert.end_time == datetime(2023, 11, 15, 22, 13, 20, tzinfo=timezone.utc)


@rsps.activate
def test_get_alerts_null_timestamps(client: AZ511Client) -> None:
    fixture = [{**FIXTURE[0], "StartTime": None, "EndTime": None}]
    rsps.add(rsps.GET, ALERTS_URL, json=fixture, status=200)
    alert = client.get_alerts()[0]
    assert alert.start_time is None
    assert alert.end_time is None


@rsps.activate
def test_get_alerts_html_notes_preserved(client: AZ511Client) -> None:
    """HTML in notes must be stored as-is, not stripped or escaped."""
    rsps.add(rsps.GET, ALERTS_URL, json=FIXTURE, status=200)
    alert = client.get_alerts()[0]
    assert "<p>" in alert.notes
    assert "I-17" in alert.notes


@rsps.activate
def test_get_alerts_regions_list(client: AZ511Client) -> None:
    rsps.add(rsps.GET, ALERTS_URL, json=FIXTURE, status=200)
    alert = client.get_alerts()[0]
    assert alert.regions == ["Maricopa", "Yavapai"]


@rsps.activate
def test_get_alerts_missing_notes_defaults_none(client: AZ511Client) -> None:
    fixture = [{**FIXTURE[0]}]
    del fixture[0]["Notes"]
    rsps.add(rsps.GET, ALERTS_URL, json=fixture, status=200)
    alert = client.get_alerts()[0]
    assert alert.notes is None


@rsps.activate
def test_get_alerts_empty_regions_defaults(client: AZ511Client) -> None:
    fixture = [{**FIXTURE[0], "Regions": []}]
    rsps.add(rsps.GET, ALERTS_URL, json=fixture, status=200)
    alert = client.get_alerts()[0]
    assert alert.regions == []


@rsps.activate
def test_get_alerts_empty_list(client: AZ511Client) -> None:
    rsps.add(rsps.GET, ALERTS_URL, json=[], status=200)
    assert client.get_alerts() == []


@rsps.activate
def test_get_alerts_auth_error(client: AZ511Client) -> None:
    rsps.add(rsps.GET, ALERTS_URL, status=401)
    with pytest.raises(AuthError):
        client.get_alerts()


@rsps.activate
def test_get_alerts_rate_limit(client: AZ511Client) -> None:
    rsps.add(rsps.GET, ALERTS_URL, status=429)
    with pytest.raises(RateLimitError):
        client.get_alerts()


@rsps.activate
def test_get_alerts_server_error(client: AZ511Client) -> None:
    rsps.add(rsps.GET, ALERTS_URL, status=500, body="Internal Server Error")
    with pytest.raises(APIError) as exc_info:
        client.get_alerts()
    assert exc_info.value.status_code == 500


@rsps.activate
def test_get_alerts_extra_fields_ignored(client: AZ511Client) -> None:
    fixture = [{**FIXTURE[0], "FutureField": "value"}]
    rsps.add(rsps.GET, ALERTS_URL, json=fixture, status=200)
    result = client.get_alerts()
    assert result[0].id == 3001
