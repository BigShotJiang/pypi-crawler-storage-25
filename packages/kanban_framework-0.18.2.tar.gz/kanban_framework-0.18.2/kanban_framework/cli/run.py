from __future__ import annotations
import time
from pathlib import Path
from kanban_framework.infra.filesystem import Filesystem
from kanban_framework.infra.config import Config
from kanban_framework.infra.git import Git, GitError
from kanban_framework.infra.worktree import Worktree, WorktreeError
from kanban_framework.domain.task import TaskManager, TaskNotFoundError
from kanban_framework.domain.workflow import WorkflowEngine, TransitionError
from kanban_framework.domain.guard import Guard, CheckResult
from kanban_framework.domain.nlp import parse_nlp
from kanban_framework.domain.recovery import recover_list, recover_check_timeout, resume_task, rollback_task
from kanban_framework.types import Phase
from kanban_framework.infra.scheduler import Scheduler


class GuardError(Exception):
    pass


def _validate_fsm_state(task, tm) -> dict | None:
    """Validate task's FSM state before executing CLI commands.
    Returns error dict if state is inconsistent, None if OK."""
    order = Scheduler.LIGHTWEIGHT_PHASE_ORDER if task.lightweight else Scheduler.PHASE_ORDER
    completed_phases = {
        h["phase"] for h in task.history
        if h.get("status") == "completed"
    }
    current_phase = task.phase

    # Check if current phase is valid
    if current_phase not in order:
        return {
            "error": f"phase '{current_phase.value}' not in {'lightweight' if task.lightweight else 'full'} phase order",
            "current_phase": current_phase.value,
            "expected_order": [p.value for p in order],
            "fix": "kanban workflow next-step " + task.id,
        }

    # Check for skipped phases before current
    current_idx = order.index(current_phase)
    for i in range(current_idx):
        if order[i].value not in completed_phases:
            return {
                "error": f"phase '{order[i].value}' was skipped (expected before '{current_phase.value}')",
                "skipped_phase": order[i].value,
                "current_phase": current_phase.value,
                "completed_phases": sorted(completed_phases),
                "fix": "kanban workflow next-step " + task.id,
            }

    return None


def _get_agents_for_phase(fs: Filesystem, phase_id: str,
                          task_description: str = "",
                          lightweight: bool = False) -> list[dict]:
    cfg = Config(fs)
    workflow = cfg.workflow
    for p in workflow.get("phases", []):
        if p.get("id") == phase_id:
            agents = p.get("agents", [])
            # Lightweight evaluate: override with QA only
            if lightweight and phase_id == "evaluate":
                from kanban_framework.infra.scheduler import Scheduler
                return Scheduler.eval_roles(lightweight=True)
            if lightweight and phase_id == "retrospective":
                from kanban_framework.infra.scheduler import Scheduler
                return Scheduler.retrospective_roles(lightweight=True)
            return _apply_trigger_conditions(agents, task_description)
    if phase_id == "evaluate":
        from kanban_framework.infra.scheduler import Scheduler
        return Scheduler.eval_roles(lightweight)
    if phase_id == "retrospective" and lightweight:
        from kanban_framework.infra.scheduler import Scheduler
        return Scheduler.retrospective_roles(lightweight)
    return []


def _apply_trigger_conditions(agents: list[dict],
                               description: str) -> list[dict]:
    """Filter agents: required ones always pass; optional ones are skipped
    unless their trigger_condition keywords match the task description."""
    result = []
    for agent in agents:
        if agent.get("required", True):
            result.append(agent)
            continue
        trigger = agent.get("trigger_condition")
        if not trigger:
            continue  # optional + no trigger → skip (#116)
        keywords = trigger.get("keywords", [])
        match_field = trigger.get("match_field", "description")
        if match_field == "description" and keywords:
            desc_lower = description.lower()
            if any(kw.lower() in desc_lower for kw in keywords):
                result.append(agent)
    return result


_BRAINSTORMING_ELEMENTS = [
    ("技术栈选型", "tech_stack"),
    ("核心功能清单", "feature_list"),
    ("验收标准", "acceptance_criteria"),
    ("约束条件", "constraints"),
]

_KEYWORDS_MAP = {
    "tech_stack": ["技术栈", "tech stack", "使用 python", "使用 react", "使用 node", "使用 go",
                   "使用 rust", "使用 typescript", "用 python", "用 react", "用 node"],
    "feature_list": ["功能清单", "功能列表", "feature list", "包含以下", "支持以下",
                     "实现以下", "功能需求", "核心功能"],
    "acceptance_criteria": ["验收标准", "acceptance criteria", "预期行为", "shall",
                            "must", "通过标准", "验收条件"],
    "constraints": ["约束条件", "限制条件", "constraint", "代码放在", "必须放在",
                    "禁止", "不得超过", "不低于"],
}


def _track_phase_time(task_id: str, phase: str, action: str) -> None:
    """Record phase start/end time to time_tracking.json."""
    try:
        root = Filesystem.find_project_root()
        reports_dir = root / ".kanban" / "reports"
        from kanban_framework.infra.time_tracking import TimeTracker
        tracker = TimeTracker(reports_dir / "time_tracking.json")
        if action == "start":
            tracker.start_phase(task_id, phase)
        elif action == "end":
            tracker.end_phase(task_id, phase)
    except (OSError, json.JSONDecodeError, KeyError) as exc:
        import logging
        logging.getLogger("kanban").warning("time_tracking %s/%s failed: %s", task_id, phase, exc)


def _move_to_archive(fs: Filesystem, task_id: str) -> None:
    """Move entire task directory to archive."""
    import shutil
    archive_task_dir = fs.archive_dir() / task_id

    # Remove existing archive if present
    if archive_task_dir.exists():
        shutil.rmtree(archive_task_dir)

    # Move entire task directory (includes task.json, inbox.md, iteration data, etc.)
    task_dir = fs.task_dir(task_id)
    if task_dir.exists():
        fs.ensure_dir(archive_task_dir.parent)
        task_dir.rename(archive_task_dir)
    else:
        # Old flat format: move the individual task JSON file
        src_file = fs.task_file(task_id)
        if fs.file_exists(src_file):
            fs.ensure_dir(archive_task_dir)
            src_file.rename(fs.archive_task_file(task_id))


def _knowledge_health_on_archive(task_id: str) -> None:
    """Run knowledge health check on archive — mark stale, report gaps.

    Archive also migrates any task-level knowledge-log.md into DB (#166).
    """
    try:
        root = Filesystem.find_project_root()
        fs = Filesystem(root=root)
        from kanban_framework.domain.knowledge import KnowledgeManager
        km = KnowledgeManager(fs)
        # Import task-level knowledge into DB
        migrated = km.migrate_legacy_log()
        if migrated:
            import sys
            print(f"KNOWLEDGE: {migrated} entries migrated to DB for {task_id}", file=sys.stderr)
        stale_ids = km.mark_stale_entries()
        gaps = km.get_knowledge_gap_report()
        if stale_ids:
            import sys
            print(f"KNOWLEDGE HEALTH: {len(stale_ids)} stale entries marked for {task_id}", file=sys.stderr)
        if gaps:
            import sys
            print(f"KNOWLEDGE HEALTH: knowledge gaps detected for {task_id}: {list(gaps.keys())}", file=sys.stderr)
        # Skills auto-evolution: extract improvements from framework_assessment
        from kanban_framework.domain.skills import SkillManager
        sm = SkillManager(fs.kanban_dir)
        archive_dir = fs.archive_dir()
        candidates = sm.process_assessment(task_id, archive_dir)
        if candidates:
            import sys
            print(f"SKILLS EVOLUTION: {len(candidates)} candidate(s) from {task_id}", file=sys.stderr)
    except Exception as exc:
        import sys
        print(f"WARNING: knowledge health check failed for {task_id}: {exc}", file=sys.stderr)


def _fmt_duration(seconds: float) -> str:
    if seconds < 60:
        return f"{seconds:.0f}s"
    m, s = divmod(int(seconds), 60)
    if m < 60:
        return f"{m}m {s}s"
    h, m = divmod(m, 60)
    return f"{h}h {m}m {s}s"


def _get_time_summary(task_id: str) -> dict:
    try:
        root = Filesystem.find_project_root()
        fs = Filesystem(root=root)
        from kanban_framework.infra.time_tracking import TimeTracker
        tracker = TimeTracker(fs.kanban_dir / "reports" / "time_tracking.json")
        data = tracker.report(task_id)
        phases = data.get("phases", {})
        total = data.get("total_seconds", 0)
        return {
            "total_seconds": round(total, 1),
            "total_human": _fmt_duration(total),
            "phases": {
                name: {
                    "elapsed_seconds": round(info.get("elapsed_seconds", 0), 1),
                    "elapsed_human": _fmt_duration(info.get("elapsed_seconds", 0)),
                }
                for name, info in sorted(phases.items())
            },
        }
    except Exception:
        return {"total_seconds": 0, "total_human": "unknown", "phases": {}}


def _append_time_token_to_retrospective(task_id: str) -> None:
    """Append time/token consumption summary to retrospective.md at archive time.

    Called during archive as a safety net — the knowledge-manager agent should
    already include this data, but this ensures it's always present.
    """
    try:
        root = Filesystem.find_project_root()
        fs = Filesystem(root=root)
        retro_path = fs.archive_dir() / task_id / "retrospective.md"
        # Also check task dir (before move) if archive doesn't have it yet
        if not retro_path.is_file():
            retro_path = fs.task_dir(task_id) / "retrospective.md"
        if not retro_path.is_file():
            return

        from kanban_framework.infra.time_tracking import TimeTracker
        from kanban_framework.infra.token_tracking import TokenTracker
        import os

        reports_dir = fs.kanban_dir / "reports"
        time_tracker = TimeTracker(reports_dir / "time_tracking.json")
        token_tracker = TokenTracker(reports_dir / "token_tracking.json")

        time_data = time_tracker.report(task_id)
        token_data = token_tracker.report(task_id)

        existing = retro_path.read_text(encoding="utf-8")

        # Skip if time/token sections already exist
        if "## 时间消耗" in existing or "## Token 消耗" in existing:
            return

        lines = []
        # Time section
        total_seconds = time_data.get("total_seconds", 0)
        phases = time_data.get("phases", {})
        if total_seconds > 0:
            lines.append("\n## 时间消耗")
            lines.append("| 阶段 | 耗时 |")
            lines.append("|------|------|")
            for phase_name, info in sorted(phases.items()):
                elapsed = info.get("elapsed_seconds", 0)
                lines.append(f"| {phase_name} | {_fmt_duration(elapsed)} |")
            lines.append(f"\n- **总计**: {_fmt_duration(total_seconds)}")

        # Token section
        total_tokens = token_data.get("total_tokens", 0)
        by_phase = token_data.get("by_phase", {})
        if total_tokens > 0:
            lines.append("\n## Token 消耗")
            lines.append("| 阶段 | Token |")
            lines.append("|------|-------|")
            for phase_name, tokens in sorted(by_phase.items()):
                lines.append(f"| {phase_name} | {tokens:,} |")
            budget_status = "within budget" if token_data.get("within_budget", True) else "over budget"
            lines.append(f"\n- **总计**: {total_tokens:,} tokens ({budget_status})")

        if lines:
            retro_path.write_text(existing + "\n".join(lines) + "\n", encoding="utf-8")
    except (OSError, json.JSONDecodeError, KeyError) as exc:
        import logging
        logging.getLogger("kanban").warning("retrospective time/token append failed: %s", exc)


def _collect_iteration_artifacts(fs: Filesystem, task_id: str) -> dict:
    """Collect execution artifacts from all iteration directories for archive summarization.

    Returns a dict mapping artifact names to lists of (iteration, content) pairs.
    The orchestrator uses this to LLM-summarize across all iterations.
    """
    task = TaskManager(fs, Config(fs)).show(task_id)
    artifacts = {}
    for it in range(1, task.iteration + 1):
        it_dir = fs.iteration_dir(task_id, it)
        if not it_dir.exists():
            continue
        for fname in ["execution_summary.md", "execution_pitfalls.md", "execution_decisions.md"]:
            fpath = it_dir / fname
            if fs.file_exists(fpath):
                artifacts.setdefault(fname, []).append({
                    "iteration": it,
                    "path": str(fpath),
                    "content": fpath.read_text(encoding="utf-8"),
                })
    return artifacts


def _check_brainstorming_gate(description: str) -> dict:
    """IR-16: Check if task description has all 4 required elements for pass-through."""
    desc = (description or "").lower()
    missing = []
    for label, key in _BRAINSTORMING_ELEMENTS:
        if not any(kw in desc for kw in _KEYWORDS_MAP[key]):
            missing.append({"label": label, "key": key})
    return {"passed": len(missing) == 0, "missing": missing}


def _resolve() -> tuple[Filesystem, Config, TaskManager, WorkflowEngine]:
    root = Filesystem.find_project_root()
    fs = Filesystem(root=root)
    cfg = Config(fs)
    tm = TaskManager(fs, cfg)
    guard = Guard(fs, cfg)
    we = WorkflowEngine(fs, cfg, guard=guard)
    return fs, cfg, tm, we


def _resolve_worktree() -> tuple[Git, Worktree]:
    root = Filesystem.find_project_root()
    fs = Filesystem(root=root)
    cfg = Config(fs)
    g = Git(repo_root=root)
    wt_base = cfg.worktree_base_dir
    wt = Worktree(git=g, repo_root=root, worktree_base=wt_base)
    return g, wt


# ── run ──────────────────────────────────────────────────────────

def cmd_run(args: list[str]) -> dict:
    if not args:
        return {"error": "task_id required"}
    task_id = args[0]
    fs, cfg, tm, we = _resolve()
    task = tm.show(task_id)
    # FSM state validation (skip for --lightweight override, which changes mode)
    lightweight_requested = "--lightweight" in args
    if not lightweight_requested:
        validation = _validate_fsm_state(task, tm)
        if validation:
            return validation
    # Set lightweight BEFORE transition (fix #147)
    lw = task.lightweight or lightweight_requested
    if lightweight_requested and not task.lightweight:
        task = tm.update(task_id, lightweight=True, mode="lightweight")
    if len(args) > 2 and args[1] == "--phase":
        target = Phase(args[2])
    elif len(args) > 3 and args[2] == "--phase":
        target = Phase(args[3])
    else:
        next_p = Scheduler.next_phase(task.phase, lightweight=lw)
        if next_p is None:
            return {
                "task_id": task_id,
                "phase": task.phase.value,
                "message": "already at terminal phase",
            }
        target = next_p

    # IR-16: brainstorming gate before plan → plan_review
    brainstorming = None
    if task.phase == Phase.PLAN and target == Phase.PLAN_REVIEW:
        brainstorming = _check_brainstorming_gate(task.description)
        if not brainstorming["passed"]:
            return {
                "task_id": task_id,
                "phase": task.phase.value,
                "message": (
                    "brainstorming gate blocked: task description lacks "
                    + ", ".join(m["label"] for m in brainstorming["missing"])
                ),
                "brainstorming_gate": brainstorming,
                "required_action": (
                    "complete Plan Step A (superpowers:brainstorming) to "
                    "produce spec.md before transitioning to plan_review"
                ),
            }

    try:
        new_phase = we.transition(task, target)
    except TransitionError as e:
        return {
            "task_id": task_id,
            "phase": task.phase.value,
            "message": str(e),
        }
    tm.update(task_id, phase=new_phase.value, history=task.history)
    _track_phase_time(task_id, new_phase.value, "start")
    lw = task.lightweight or lightweight_requested
    agents = _get_agents_for_phase(fs, new_phase.value,
                                     task_description=task.description,
                                     lightweight=lw)
    result = {
        "task_id": task_id,
        "phase": new_phase.value,
        "message": f"entered {new_phase.value} phase",
        "guard": {"passed": True},
        "agents_to_spawn": agents,
        "agent_count": len(agents),
    }
    if brainstorming is not None:
        result["brainstorming_gate"] = brainstorming

    # Mode handling: custom (lightweight already set before transition)
    if task.mode == "custom" and task.custom_fsm:
        result["mode"] = "custom"
        custom_phases = task.custom_fsm.get("phases", [])
        custom_eval_agents = task.custom_fsm.get("evaluate_agents", [])
        result["phase_order"] = custom_phases
        result["message"] = (
            f"自定义模式: {' → '.join(custom_phases)}, "
            f"评估 Agent: {', '.join(a['name'] for a in custom_eval_agents) if custom_eval_agents else '无'}"
        )

    if task.lightweight or task.mode == "lightweight":
        result["lightweight"] = True
        result["phase_order"] = [p.value for p in Scheduler.LIGHTWEIGHT_PHASE_ORDER]
        result["message"] = (
            "轻量模式: Plan → Execute → Evaluate(QA only) → Archive, 跳过 Plan Review/QA Spec/Spec Review/Retrospective"
        )

    # Subagent dispatch info
    for agent in agents:
        if agent.get("subagent_required"):
            result.setdefault("subagent_required", []).append(agent["role"])

    return result


# ── decide ───────────────────────────────────────────────────────

def cmd_decide(args: list[str]) -> dict:
    if not args:
        return {"error": "task_id required"}
    task_id = args[0]
    action = "approve_and_archive"
    if len(args) > 2 and args[1] == "--action":
        action = args[2]
    fs, _, tm, we = _resolve()
    task = tm.show(task_id)
    valid_actions = {"approve_and_archive", "abort", "restart_from_plan", "restart_from_execute"}
    if action not in valid_actions:
        return {"error": f"unknown action: {action}", "valid_actions": sorted(valid_actions)}

    # Phase validation (Issue #111)
    allowed_phases = {Phase.USER_DECISION, Phase.EVALUATE, Phase.RETROSPECTIVE}
    if task.phase not in allowed_phases:
        return {
            "error": f"cannot decide at phase {task.phase.value}",
            "expected_phases": sorted(p.value for p in allowed_phases),
        }

    tm.record_decision(task_id, action)
    tm.update(task_id, user_decision={"action": action})

    # Execute the action (fix #82)
    if action == "approve_and_archive":
        tm.update(task_id, phase="archive", status="archived")
        time_summary = _get_time_summary(task_id)
        _move_to_archive(fs, task_id)
        # Append time/token summary to retrospective (safety net)
        _append_time_token_to_retrospective(task_id)
        # Knowledge already extracted in Retrospective phase — archive only runs health check
        _knowledge_health_on_archive(task_id)
        # Auto-archive inbox items (Issue #108)
        from kanban_framework.cli.inbox import archive_on_task_completion
        inbox_result = archive_on_task_completion(task_id)
        result = {
            "task_id": task_id,
            "action": action,
            "message": f"user decision: {action} — executed",
            "time": time_summary,
        }
        if inbox_result.get("archived_count", 0) > 0:
            result["inbox_archived"] = inbox_result.get("archived_count")
        return result
    elif action == "abort":
        tm.update(task_id, phase="archive", status="cancelled")
        time_summary = _get_time_summary(task_id)
        _move_to_archive(fs, task_id)
        return {
            "task_id": task_id,
            "action": action,
            "message": f"user decision: {action} — executed",
            "time": time_summary,
        }
    elif action == "restart_from_plan":
        tm.update(task_id, phase="plan", status="in_progress", iteration=task.iteration + 1)
    elif action == "restart_from_execute":
        tm.update(task_id, phase="execute", status="in_progress", iteration=task.iteration + 1)

    return {
        "task_id": task_id,
        "action": action,
        "message": f"user decision: {action} — executed",
    }


# ── guard ────────────────────────────────────────────────────────

def cmd_guard(args: list[str]) -> dict:
    if not args:
        return {"error": "subcommand required"}
    sub = args[0]
    fs, cfg, tm, _ = _resolve()
    guard = Guard(fs, cfg)

    if sub == "check-artifacts":
        if len(args) < 2:
            return {"error": "task_id required"}
        task = tm.show(args[1])
        phase = Phase(args[2]) if len(args) > 2 else task.phase
        result = guard.check_artifacts(task, phase, lightweight=task.lightweight)
        return {
            "subcommand": sub,
            "task_id": task.id,
            "phase": phase.value,
            "passed": result.passed,
            "failures": result.failures,
            "warnings": result.warnings,
        }

    if sub == "check-evaluation":
        if len(args) < 2:
            return {"error": "task_id required"}
        task = tm.show(args[1])
        iteration = int(args[2]) if len(args) > 2 else task.iteration
        result = guard.check_evaluation(task, iteration, lightweight=task.lightweight)
        return {
            "subcommand": sub,
            "task_id": task.id,
            "iteration": iteration,
            "passed": result.passed,
            "failures": result.failures,
        }

    if sub == "check-plan-quality":
        if len(args) < 2:
            return {"error": "task_id required"}
        task = tm.show(args[1])
        report_dir = fs.report_dir(task.id, task.iteration)
        result = guard.check_plan_quality(task, report_dir)
        return {
            "subcommand": sub,
            "task_id": task.id,
            "passed": result.passed,
            "failures": result.failures,
        }

    if sub == "check-inbox":
        if len(args) < 2:
            return {"error": "task_id required"}
        task = tm.show(args[1])
        inbox_path = fs.task_dir(task.id) / "inbox.md"
        pending = []
        unverified = []  # checked [x] but no verification tag
        if fs.file_exists(inbox_path):
            content = inbox_path.read_text(encoding="utf-8")
            import re
            _tag_done = re.compile(r'done:(\S+)')
            _tag_migrated = re.compile(r'migrated:(\S+)')
            _tag_wontfix = re.compile(r'wontfix:(.+?)(?:-->|$)')
            for line in content.split("\n"):
                stripped = line.strip()
                # Layer 1: unchecked / natural-language items
                if (stripped and
                    not stripped.startswith("#") and
                    not stripped.startswith("<!--") and
                    not stripped.startswith("---") and
                    not stripped.startswith("**") and
                    not stripped.startswith("- [x]") and
                    not stripped.startswith("* [x]")):
                    pending.append(stripped)
                # Layer 2: checked but no verification tag
                if stripped.startswith("- [x]") or stripped.startswith("* [x]"):
                    has_tag = bool(_tag_done.search(stripped) or
                                   _tag_migrated.search(stripped) or
                                   _tag_wontfix.search(stripped))
                    if not has_tag:
                        unverified.append(stripped)
        can_archive = len(pending) == 0 and len(unverified) == 0
        return {
            "subcommand": sub,
            "task_id": task.id,
            "has_pending": len(pending) > 0,
            "pending_count": len(pending),
            "pending": pending,
            "has_unverified": len(unverified) > 0,
            "unverified_count": len(unverified),
            "unverified": unverified,
            "can_archive": can_archive,
        }

    if sub == "check-spec":
        if len(args) < 2:
            return {"error": "task_id required"}
        task = tm.show(args[1])
        result = guard.check_spec(task, fs.report_dir(task.id, task.iteration))
        return {
            "subcommand": sub,
            "task_id": task.id,
            "passed": result.passed,
            "failures": result.failures,
        }

    if sub == "check-parallel-conflicts":
        if len(args) < 2:
            return {"error": "task_id required"}
        task = tm.show(args[1])
        result = guard.check_parallel_conflicts(task)
        return {
            "subcommand": sub,
            "task_id": task.id,
            "passed": result.passed,
            "failures": result.failures,
        }

    if sub == "check-cross-task-conflicts":
        result = guard.check_cross_task_conflicts()
        return {
            "subcommand": sub,
            "passed": result.passed,
            "failures": result.failures,
            "warnings": result.warnings,
        }

    if sub == "check-phase-completeness":
        if len(args) < 2:
            return {"error": "task_id required"}
        task = tm.show(args[1])
        result = guard.check_phase_completeness(task, lightweight=task.lightweight)
        return {
            "subcommand": sub,
            "task_id": task.id,
            "current_phase": task.phase.value,
            "passed": result.passed,
            "failures": result.failures,
        }

    if sub == "batch-check":
        if len(args) < 2:
            return {"error": "task_id required"}
        task = tm.show(args[1])
        report_dir = fs.report_dir(task.id, task.iteration)
        result = guard.batch_check_combined(task, report_dir)
        return {
            "subcommand": sub,
            "task_id": task.id,
            "passed": result.passed,
            "failures": result.failures,
            "warnings": result.warnings,
        }

    if sub == "check-archive-stray":
        if len(args) < 2:
            return {"error": "task_id required"}
        task = tm.show(args[1])
        project_root = Filesystem.find_project_root()
        stray_archive = project_root / "archive"
        stray_task = stray_archive / task.id
        if stray_task.is_dir():
            # Stray archive found in project root — clean it up
            import shutil
            shutil.rmtree(stray_task)
            # If stray archive is now empty, remove it too
            if stray_archive.is_dir() and not list(stray_archive.iterdir()):
                stray_archive.rmdir()
            return {
                "subcommand": sub,
                "task_id": task.id,
                "stray_found": True,
                "cleaned": str(stray_task),
                "message": "Stray archive/ directory in project root cleaned up. Use .kanban/archive/ instead.",
            }
        return {
            "subcommand": sub,
            "task_id": task.id,
            "stray_found": False,
        }

    return {"error": f"unknown guard subcommand: {sub}"}


# ── workflow ─────────────────────────────────────────────────────

def cmd_workflow(args: list[str]) -> dict:
    if not args:
        return {"error": "subcommand required"}
    sub = args[0]
    _, _, tm, we = _resolve()

    if sub == "transition":
        if len(args) < 3:
            return {"error": "task_id and target phase required"}
        task = tm.show(args[1])
        # FSM state validation
        validation = _validate_fsm_state(task, tm)
        if validation:
            return validation
        from_phase = task.phase.value
        target = Phase(args[2])
        new_phase = we.transition(task, target)
        # transition() now sets task.phase + adds history entries internally
        tm.update(task.id, phase=task.phase.value, history=task.history)
        return {"task_id": task.id, "from": from_phase, "to": new_phase.value}

    if sub == "complete-phase":
        if len(args) < 2:
            return {"error": "task_id required"}
        fs, cfg, tm, _ = _resolve()
        task = tm.show(args[1])
        # FSM state validation
        validation = _validate_fsm_state(task, tm)
        if validation:
            return validation
        guard = Guard(fs, cfg)
        guard_result = guard.check_artifacts(task, task.phase, lightweight=task.lightweight)
        if not guard_result.passed:
            raise GuardError(
                f"guard check failed for {task.id} at {task.phase.value}: "
                + "; ".join(guard_result.failures)
            )
        # Verify no phases were skipped
        phase_check = guard.check_phase_completeness(task, lightweight=task.lightweight)
        if not phase_check.passed:
            raise GuardError(
                f"phase completeness check failed for {task.id}: "
                + "; ".join(phase_check.failures)
            )
        # IR-17: Evaluate phase score gate — prevent skipping self-improve
        if task.phase == Phase.EVALUATE:
            # Auto-sync scores from report files (#182)
            from kanban_framework.cli.evaluator import _record_score
            sync_result = _record_score(fs, tm, args[1])
            if sync_result.get("recorded"):
                task = tm.show(args[1])  # Refresh task after score update
            score_check = guard.check_evaluation_score(task)
            if not score_check.passed:
                raise GuardError(
                    f"evaluation score gate failed for {task.id}: "
                    + "; ".join(score_check.failures)
                )
        # Auto-import knowledge entries after retrospective (issue #176)
        knowledge_result = {}
        if task.phase == Phase.RETROSPECTIVE:
            import json as _json
            from kanban_framework.domain.knowledge import KnowledgeManager
            km = KnowledgeManager(fs)
            iter_dir = fs.task_dir(task.id) / f"iteration-{task.iteration}"
            ke_file = iter_dir / "knowledge_extracted.json"
            if ke_file.exists():
                try:
                    data = _json.loads(ke_file.read_text(encoding="utf-8"))
                    entries = data.get("entries", [])
                    added = []
                    skipped = 0
                    for e in entries:
                        title = e.get("title", "")
                        content = e.get("content", "")
                        if not title.strip() and not content.strip():
                            skipped += 1
                            continue
                        entry = km.add_entry(
                            domain=e.get("domain", "infra"),
                            category=e.get("category", "general"),
                            title=title,
                            content=content,
                            tags=e.get("tags", []),
                            severity=e.get("severity", "medium"),
                            source=e.get("source", {}),
                        )
                        added.append(entry["id"])
                    knowledge_result = {"knowledge_imported": len(added), "knowledge_ids": added}
                    if skipped:
                        knowledge_result["knowledge_skipped_empty"] = skipped
                except Exception:
                    knowledge_result = {"knowledge_imported": 0, "knowledge_warning": "import failed"}
            else:
                knowledge_result = {"knowledge_imported": 0, "knowledge_warning": "no knowledge_extracted.json found"}
        _track_phase_time(task.id, task.phase.value, "end")
        # Auto-mark all remaining steps in this phase as completed
        from kanban_framework.domain.state_machine import mark_step, _get_steps
        steps_map = _get_steps("lightweight" if task.lightweight else "full")
        for step_def in steps_map.get(task.phase.value, []):
            mark_step(fs, task.id, step_def.id, "completed")
        updated = we.complete_phase(task)
        tm.update(task.id, phase=updated.phase.value, history=updated.history)
        result = {"task_id": task.id, "phase": updated.phase.value}
        result.update(knowledge_result)
        return result

    if sub == "self-improve-check":
        if len(args) < 2:
            return {"error": "task_id required"}
        task = tm.show(args[1])
        # Parse --avg-score flag (or positional fallback for backward compat)
        avg_score = None
        for i, arg in enumerate(args):
            if arg == "--avg-score" and i + 1 < len(args):
                try:
                    avg_score = float(args[i + 1])
                except (ValueError, TypeError):
                    return {"error": f"invalid --avg-score value: {args[i+1]}"}
                break
        if avg_score is None and len(args) >= 3:
            # Backward compat: positional avg_score as args[2]
            try:
                avg_score = float(args[2])
            except (ValueError, TypeError):
                return {"error": f"invalid avg_score value: {args[2]}"}
        if avg_score is None:
            if task.score_history:
                latest = task.score_history[-1]
                avg_score = latest.get("average", 0.0)
            else:
                return {"error": "no avg_score provided and no score_history in task"}
        result = we.self_improve_check(task, avg_score)
        return {"task_id": task.id, **result}

    if sub == "get-roles" or sub == "get-phase-agents":
        phase_str = args[1] if len(args) > 1 else "evaluate"
        cfg = Config(Filesystem(root=Filesystem.find_project_root()))
        workflow = cfg.workflow
        phase_config = None
        for p in workflow.get("phases", []):
            if p.get("id") == phase_str:
                phase_config = p
                break
        agents = phase_config.get("agents", []) if phase_config else []
        if not agents and phase_str == "evaluate":
            from kanban_framework.infra.scheduler import Scheduler
            agents = Scheduler.eval_roles()

        # Include scheduling config (timeout, parallelism) from config.json
        raw = cfg.raw
        timeout = raw.get("timeout", {})
        scheduler_cfg = raw.get("scheduler", {})
        scheduling = {
            "single_agent_seconds": timeout.get("single_agent_seconds", 180),
            "phase_timeout_seconds": timeout.get(f"{phase_str}_seconds"),
            "max_parallel": scheduler_cfg.get("max_parallel", 3),
            "poll_interval_seconds": scheduler_cfg.get("poll_interval_seconds", 30),
        }
        return {"phase": phase_str, "agents": agents, "scheduling": scheduling}

    if sub == "next-phase":
        if len(args) < 2:
            return {"error": "task_id required"}
        task = tm.show(args[1])
        next_p = we.next_phase(task.phase)
        return {
            "task_id": task.id,
            "current": task.phase.value,
            "next": next_p.value if next_p else None,
        }

    if sub == "start-iteration":
        if len(args) < 3:
            return {"error": "task_id and type (hot/full) required"}
        task_id = args[1]
        itype = args[2]
        if itype not in ("hot", "full"):
            return {"error": "iteration type must be hot or full"}

        fs2, _, tm2, _ = _resolve()
        task = tm2.show(task_id)
        old_iter = task.iteration
        new_iter = old_iter + 1
        task_dir = fs2.task_dir(task_id)

        # Move execution artifacts from task root to iteration-{N}/ for isolation
        for fname in ["execution_summary.md", "execution_pitfalls.md", "execution_decisions.md"]:
            src = task_dir / fname
            if fs2.file_exists(src):
                dest_dir = fs2.iteration_dir(task_id, old_iter)
                fs2.ensure_dir(dest_dir)
                src.rename(dest_dir / fname)

        # Set phase and increment iteration
        target_phase = Phase.EXECUTE if itype == "hot" else Phase.PLAN
        tm2.update(task_id, phase=target_phase.value, iteration=new_iter)
        return {
            "task_id": task_id,
            "type": itype,
            "iteration": new_iter,
            "phase": target_phase.value,
        }

    if sub == "collect-iteration-artifacts":
        if len(args) < 2:
            return {"error": "task_id required"}
        fs3, _, _, _ = _resolve()
        return {"task_id": args[1], "artifacts": _collect_iteration_artifacts(fs3, args[1])}

    if sub == "next-step":
        if len(args) < 2:
            return {"error": "task_id required"}
        fs, cfg, _, _ = _resolve()
        task = tm.show(args[1])
        from kanban_framework.domain.state_machine import next_step, next_step_to_dict
        result = next_step(fs, cfg, task)
        return next_step_to_dict(result)

    if sub == "mark-step":
        if len(args) < 3:
            return {"error": "task_id and step_id required"}
        fs, _, _, _ = _resolve()
        status = "completed"
        if len(args) >= 4:
            status = args[3]
        from kanban_framework.domain.state_machine import mark_step, load_progress
        progress = mark_step(fs, args[1], args[2], status)
        return {"task_id": args[1], "step_id": args[2], "status": status, "progress": progress}

    if sub == "progress":
        if len(args) < 2:
            return {"error": "task_id required"}
        fs, _, _, _ = _resolve()
        from kanban_framework.domain.state_machine import load_progress
        return {"task_id": args[1], "progress": load_progress(fs, args[1])}

    if sub == "replan":
        if len(args) < 2:
            return {"error": "task_id required"}
        fs, _, tm, _ = _resolve()
        task = tm.show(args[1])
        # Only allow replan if not already archived
        if task.status.value in ("archived", "cancelled"):
            return {"error": "cannot replan an archived task"}
        old_phase = task.phase.value
        # Reset to plan phase, keep iteration counter, preserve completed subtask history
        tm.update(args[1], phase="plan")
        # Clear plan-phase step progress so they rerun
        from kanban_framework.domain.state_machine import load_progress, _get_steps
        progress = load_progress(fs, args[1])
        steps = progress.get("steps", {})
        for step_id in list(steps.keys()):
            if step_id.startswith("plan"):
                steps[step_id] = {"status": "pending"}
        progress["steps"] = steps
        # Save updated progress
        import json as _json
        progress_path = fs.task_dir(args[1]) / "progress.json"
        progress_path.write_text(_json.dumps(progress, ensure_ascii=False, indent=2), encoding="utf-8")
        return {
            "task_id": args[1],
            "action": "replan",
            "from_phase": old_phase,
            "to_phase": "plan",
            "message": (
                "Task reset to plan phase. plan-phase steps will rerun. "
                "Completed subtask records are preserved. "
                "Run `kanban workflow next-step {}` to continue.'.format(args[1])"
            ),
        }

    return {"error": f"unknown workflow subcommand: {sub}"}


# ── worktree ─────────────────────────────────────────────────────

def cmd_worktree(args: list[str]) -> dict:
    if not args:
        return {"error": "subcommand required"}
    sub = args[0]
    g, wt = _resolve_worktree()

    if sub == "create":
        if len(args) < 2:
            return {"error": "task_id required"}
        task_id = args[1]
        branch = f"task/{task_id}"
        try:
            path = wt.create(task_id, branch)
            # Persist worktree path to task.json
            fs3, _, tm3, _ = _resolve()
            try:
                tm3.update(task_id, worktree_path=str(path))
            except TaskNotFoundError:
                pass
            return {
                "subcommand": sub,
                "task_id": task_id,
                "branch": branch,
                "path": str(path),
            }
        except WorktreeError as e:
            return {"error": str(e)}

    if sub == "remove":
        if len(args) < 2:
            return {"error": "task_id required"}
        task_id = args[1]
        force = "--force" in args
        try:
            wt.remove(task_id, force=force)
            return {"subcommand": sub, "task_id": task_id, "removed": True}
        except WorktreeError as e:
            return {"error": str(e)}

    if sub == "exists":
        if len(args) < 2:
            return {"error": "task_id required"}
        return {"subcommand": sub, "task_id": args[1], "exists": wt.exists(args[1])}

    if sub == "list":
        return {"subcommand": sub, "worktrees": wt.list_all()}

    if sub == "merge":
        if len(args) < 2:
            return {"error": "task_id required"}
        task_id = args[1]
        branch = f"task/{task_id}"
        try:
            g._run(["checkout", g.current_branch()])
            # Check if already merged (#191)
            merged_branches = g._run(["branch", "--merged", "HEAD"], check=False).strip().splitlines()
            already_merged = any(branch in line.strip() for line in merged_branches)
            if already_merged:
                return {"subcommand": sub, "task_id": task_id, "merged": True, "already_merged": True}
            g._run(["merge", branch, "--no-ff", "-m", f"merge: {task_id}"])
            g.push()
            return {"subcommand": sub, "task_id": task_id, "merged": True}
        except GitError as e:
            return {"error": str(e)}

    if sub == "cleanup":
        if len(args) < 2:
            return {"error": "task_id required"}
        task_id = args[1]
        branch = f"task/{task_id}"
        try:
            wt.remove(task_id, force=True)
            try:
                g._run(["branch", "-D", branch], check=False)
            except GitError:
                pass
            return {"subcommand": sub, "task_id": task_id, "cleaned": True}
        except WorktreeError as e:
            return {"error": str(e)}

    return {"error": f"unknown worktree subcommand: {sub}"}


# ── nlp ──────────────────────────────────────────────────────────

def cmd_nlp(args: list[str]) -> dict:
    """Return available commands + raw input for LLM interpretation.

    No keyword matching — the orchestrator (Claude Code) uses its LLM
    to map natural language to the exact command from the list below.
    """
    text = " ".join(args)
    from kanban_framework.domain.nlp import extract_task_id, detect_work_intent
    work_intent = detect_work_intent(text)
    return {
        "input": text,
        "task_id": extract_task_id(text),
        "interpret_by_llm": True,
        "routing_guidance": {
            "intent": work_intent["intent"],
            "suggested_command": work_intent["suggested_command"],
            "has_task_id": work_intent["has_task_id"],
            "rule": (
                "If intent=work and has_task_id=false → use 'create' to create a task first, then 'run' it. "
                "If intent=work and has_task_id=true → use 'run' to continue the task. "
                "If intent=query → use 'status' or 'show'. "
                "NEVER execute work directly — always route through create+run."
            ),
        },
        "available_commands": [
            {"command": "init",                  "example": "/kanban init"},
            {"command": "create",                "example": '/kanban create "<title>" [--desc "<desc>"] [--auto-mode <brainstorm|iteration|lightweight|archive|all>]'},
            {"command": "status",                "example": "/kanban status"},
            {"command": "show",                  "example": "/kanban show <task_id>"},
            {"command": "run",                   "example": "/kanban run <task_id> [--phase <phase>]"},
            {"command": "decide",                "example": "/kanban decide <task_id> --action approve_and_archive|abort|restart_from_plan|restart_from_execute"},
            {"command": "score",                 "example": "/kanban score <task_id>"},
            {"command": "summary",               "example": "/kanban summary <task_id>"},
            {"command": "recover",               "example": "/kanban recover [<task_id>]"},
            {"command": "resume",                "example": "/kanban resume <task_id>"},
            {"command": "rollback",              "example": "/kanban rollback <task_id>"},
            {"command": "clean",                 "example": "/kanban clean [<task_id>|--all|--before <date>]"},
            {"command": "time",                  "example": "/kanban time [<task_id>]"},
            {"command": "tokens",                "example": "/kanban tokens <task_id>"},
            {"command": "progress",              "example": "/kanban progress <task_id>"},
            {"command": "subtask",               "example": "/kanban subtask start|done <task_id> <subtask_id>"},
            {"command": "dashboard",             "example": "/kanban dashboard [start|stop|status|restart]"},
            {"command": "version",               "example": "/kanban version list|record"},
            {"command": "knowledge",             "example": "/kanban knowledge search <keyword>"},
            {"command": "feedback",              "example": "/kanban feedback <task_id>"},
            {"command": "evolve-skills",         "example": "/kanban evolve-skills"},
            {"command": "check-env",             "example": "/kanban check-env"},
        ],
    }


# ── recover / rollback / resume ──────────────────────────────────

def cmd_recover(args: list[str]) -> dict:
    if args:
        task_id = args[0]
        if "--check-timeout" in args:
            result = recover_check_timeout(task_id)
            return {"task_id": task_id, "timeout": result}
        return {"task_id": task_id, "action": "recover"}
    return {"action": "recover", "interrupted_tasks": recover_list()}


def cmd_rollback(args: list[str]) -> dict:
    if not args:
        return {"error": "task_id required"}
    task_id = args[0]
    result = rollback_task(task_id)
    return {"task_id": task_id, "action": "rollback", "result": result}


def cmd_resume(args: list[str]) -> dict:
    if not args:
        return {"error": "task_id required"}
    task_id = args[0]
    result = resume_task(task_id)
    return {"task_id": task_id, "action": "resume", "result": result}
