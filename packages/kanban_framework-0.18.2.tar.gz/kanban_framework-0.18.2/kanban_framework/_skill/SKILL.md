---
name: kanban
description: "使用 /kanban 命令管理看板任务的全生命周期：初始化看板、创建 TASK-NNN 任务、执行阶段（plan/execute/evaluate）、归档完成、查看状态/进度、恢复中断任务、多迭代工作流。当用户提到 kanban、看板、TASK-NNN、/kanban 命令、任务创建/归档/恢复、或任何看板任务管理意图时使用此技能。"
---

# Kanban 多 Agent 编排系统

基于 FSM 的任务编排框架。编排器不直接管理流程，全部由状态机驱动。

## 命令约定

优先检测 `kanban` CLI（pip 安装），不可用时回退 `python3 -m kanban_framework`（需 PYTHONPATH）。

## 命令路由

**精确命令** 直接匹配，**自然语言** 通过 `kanban nlp` 解析后路由。

| 意图 | 条件 | 路由 |
|------|------|------|
| `work` | 有 task_id | `run` |
| `work` | 无 task_id 且无活跃任务 | 先 `create` 再 `run` |
| `work` | 无 task_id 但有活跃任务 | `run <active_task_id>`（关联到已有任务） |
| `query` | 含查询动词 | `status` / `show` |

**工作意图路由步骤：**
1. `kanban nlp "<用户输入>"` → 获取 intent / task_id / needs_active_task_check
2. 如果 `needs_active_task_check` 为 true → `kanban status` 检查是否有活跃任务
3. 有活跃任务 → 展示当前任务给用户确认，用户同意后 `kanban run <id>`
4. 无活跃任务或用户明确要新建 → `kanban create` + `kanban run`

**硬性约束：** `intent == "work"` 时禁止跳过 FSM 直接调用 skill。所有工作必须通过 `kanban create`/`kanban run` 进入框架。

### 常用命令

```
/kanban init                        # 初始化（首次使用必须执行）
                                     #   1. 询问用户工号 → 写入 task_id_base
                                     #   2. 工号如 6696 → TASK-669601 起始
/kanban create "<title>"            # 创建任务（自动推荐模式）
/kanban task edit <id> --mode full  # 切换模式
/kanban task edit <id> --auto-mode all  # 全自动模式
/kanban run <id>                    # 执行当前阶段
/kanban status                      # 看板状态
/kanban show <id>                   # 任务详情
/kanban decide <id> --action <act>  # 用户决策
/kanban workflow next-step <id>     # 获取下一步指令（状态机驱动）
/kanban workflow mark-step <id> <step_id>  # 标记步骤完成
/kanban workflow progress <id>      # 查看子步骤进度
/kanban clean <id>|--all            # 清理归档任务
/kanban recover [<id>]              # 崩溃恢复
```

---

## 核心编排循环（唯一流程控制方式）

编排器不做任何流程决策。所有决策由状态机 `next-step` 返回。

**上下文恢复：** 压缩后或新会话，先调用 `kanban workflow next-step <task_id>` 恢复状态，不凭记忆。

```
循环开始:
  1. result = kanban workflow next-step <task_id>
  2. 根据 result 执行:
     - 有 interactive → 编排器直接处理，在主对话中与用户多轮交互（如 brainstorming）
     - 有 spawn_prompt → 用 Agent tool 启动 subagent，prompt 使用 result.spawn_prompt 的内容
     - 有 user_action → 展示信息给用户，等待用户操作
     - 有 actions → 按顺序执行 CLI 命令
  3. kanban workflow mark-step <task_id> result.step_id
  4. 如 result.phase_complete → kanban workflow complete-phase <task_id>
  5. 如 result.all_complete → 结束
  6. 否则 → 回到 1
```

**编排器禁止行为：**
- 禁止跳过 next-step 自行决定下一步
- 禁止修改 subagent 的 spawn_prompt 内容
- 禁止在 subagent 完成后跟随其建议的后续步骤（subagent 只负责产出发配的文件）
- 禁止直接修改 task.json 的 phase 字段

**轻量模式说明：** 任务创建时自动检测模式。full 模式走完整阶段（含 Plan Review/QA Spec/Spec Review），lightweight 模式跳过这些阶段直接 Plan → Execute → Evaluate(QA only) → Archive。模式由 `next-step` 自动适配，编排器无需关注。

**FSM 校验：** `run`/`transition`/`complete-phase` 命令执行前会自动验证 FSM 状态，检测跳步。如果状态不一致会返回错误和修正指令，按修正指令操作即可。

## spawn_prompt 变量

`next-step` 返回的 `spawn_prompt` 中可能包含以下变量，编排器无需替换（已由状态机处理）：

| 变量 | 含义 |
|------|------|
| `$task_id` | 任务 ID |
| `$task_dir` | 任务目录路径 |
| `$report_dir` | 当前迭代报告目录路径 |
| `$iteration` | 当前迭代编号 |
