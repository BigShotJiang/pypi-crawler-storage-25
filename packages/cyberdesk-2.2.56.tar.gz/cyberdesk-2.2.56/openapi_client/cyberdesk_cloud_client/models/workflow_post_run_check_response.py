from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar, cast
from uuid import UUID

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..models.post_run_check_file_target_mode import PostRunCheckFileTargetMode
from ..models.post_run_check_type import PostRunCheckType
from ..types import UNSET, Unset

T = TypeVar("T", bound="WorkflowPostRunCheckResponse")


@_attrs_define
class WorkflowPostRunCheckResponse:
    """Workflow response shape for post-run checks, including workflow-specific order.

    Attributes:
        name (str):
        type_ (PostRunCheckType):
        id (UUID):
        organization_id (str):
        order (int):
        created_at (datetime.datetime):
        updated_at (datetime.datetime):
        description (None | str | Unset):
        file_target_mode (None | PostRunCheckFileTargetMode | Unset):
        file_names (list[str] | None | Unset):
        file_name_regex (None | str | Unset):
        expected_match_count (int | None | Unset):
        expected_match_count_ref (None | str | Unset):
        loop_input (None | str | Unset):
        loop_item_filename_template (None | str | Unset):
        allow_missing_loop_attachments (Unset | bool):
        check_prompt (None | str | Unset):
        model (None | Unset | UUID): Optional ModelConfiguration id override for agentic post-run checks.
        user_id (None | Unset | UUID):
    """

    name: str
    type_: PostRunCheckType
    id: UUID
    organization_id: str
    order: int
    created_at: datetime.datetime
    updated_at: datetime.datetime
    description: None | str | Unset = UNSET
    file_target_mode: None | PostRunCheckFileTargetMode | Unset = UNSET
    file_names: list[str] | None | Unset = UNSET
    file_name_regex: None | str | Unset = UNSET
    expected_match_count: int | None | Unset = UNSET
    expected_match_count_ref: None | str | Unset = UNSET
    loop_input: None | str | Unset = UNSET
    loop_item_filename_template: None | str | Unset = UNSET
    allow_missing_loop_attachments: Unset | bool = UNSET
    check_prompt: None | str | Unset = UNSET
    model: None | Unset | UUID = UNSET
    user_id: None | Unset | UUID = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        name = self.name

        type_ = self.type_.value

        id = str(self.id)

        organization_id = self.organization_id

        order = self.order

        created_at = self.created_at.isoformat()

        updated_at = self.updated_at.isoformat()

        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description

        file_target_mode: None | str | Unset
        if isinstance(self.file_target_mode, Unset):
            file_target_mode = UNSET
        elif isinstance(self.file_target_mode, PostRunCheckFileTargetMode):
            file_target_mode = self.file_target_mode.value
        else:
            file_target_mode = self.file_target_mode

        file_names: list[str] | None | Unset
        if isinstance(self.file_names, Unset):
            file_names = UNSET
        elif isinstance(self.file_names, list):
            file_names = self.file_names

        else:
            file_names = self.file_names

        file_name_regex: None | str | Unset
        if isinstance(self.file_name_regex, Unset):
            file_name_regex = UNSET
        else:
            file_name_regex = self.file_name_regex

        expected_match_count: int | None | Unset
        if isinstance(self.expected_match_count, Unset):
            expected_match_count = UNSET
        else:
            expected_match_count = self.expected_match_count

        expected_match_count_ref: None | str | Unset
        if isinstance(self.expected_match_count_ref, Unset):
            expected_match_count_ref = UNSET
        else:
            expected_match_count_ref = self.expected_match_count_ref

        loop_input: None | str | Unset
        if isinstance(self.loop_input, Unset):
            loop_input = UNSET
        else:
            loop_input = self.loop_input

        loop_item_filename_template: None | str | Unset
        if isinstance(self.loop_item_filename_template, Unset):
            loop_item_filename_template = UNSET
        else:
            loop_item_filename_template = self.loop_item_filename_template

        allow_missing_loop_attachments = self.allow_missing_loop_attachments

        check_prompt: None | str | Unset
        if isinstance(self.check_prompt, Unset):
            check_prompt = UNSET
        else:
            check_prompt = self.check_prompt

        model: None | str | Unset
        if isinstance(self.model, Unset):
            model = UNSET
        elif isinstance(self.model, UUID):
            model = str(self.model)
        else:
            model = self.model

        user_id: None | str | Unset
        if isinstance(self.user_id, Unset):
            user_id = UNSET
        elif isinstance(self.user_id, UUID):
            user_id = str(self.user_id)
        else:
            user_id = self.user_id

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "name": name,
                "type": type_,
                "id": id,
                "organization_id": organization_id,
                "order": order,
                "created_at": created_at,
                "updated_at": updated_at,
            }
        )
        if description is not UNSET:
            field_dict["description"] = description
        if file_target_mode is not UNSET:
            field_dict["file_target_mode"] = file_target_mode
        if file_names is not UNSET:
            field_dict["file_names"] = file_names
        if file_name_regex is not UNSET:
            field_dict["file_name_regex"] = file_name_regex
        if expected_match_count is not UNSET:
            field_dict["expected_match_count"] = expected_match_count
        if expected_match_count_ref is not UNSET:
            field_dict["expected_match_count_ref"] = expected_match_count_ref
        if loop_input is not UNSET:
            field_dict["loop_input"] = loop_input
        if loop_item_filename_template is not UNSET:
            field_dict["loop_item_filename_template"] = loop_item_filename_template
        if allow_missing_loop_attachments is not UNSET:
            field_dict["allow_missing_loop_attachments"] = allow_missing_loop_attachments
        if check_prompt is not UNSET:
            field_dict["check_prompt"] = check_prompt
        if model is not UNSET:
            field_dict["model"] = model
        if user_id is not UNSET:
            field_dict["user_id"] = user_id

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        name = d.pop("name")

        type_ = PostRunCheckType(d.pop("type"))

        id = UUID(d.pop("id"))

        organization_id = d.pop("organization_id")

        order = d.pop("order")

        created_at = isoparse(d.pop("created_at"))

        updated_at = isoparse(d.pop("updated_at"))

        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))

        def _parse_file_target_mode(data: object) -> None | PostRunCheckFileTargetMode | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                file_target_mode_type_0 = PostRunCheckFileTargetMode(data)

                return file_target_mode_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | PostRunCheckFileTargetMode | Unset, data)

        file_target_mode = _parse_file_target_mode(d.pop("file_target_mode", UNSET))

        def _parse_file_names(data: object) -> list[str] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                file_names_type_0 = cast(list[str], data)

                return file_names_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[str] | None | Unset, data)

        file_names = _parse_file_names(d.pop("file_names", UNSET))

        def _parse_file_name_regex(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        file_name_regex = _parse_file_name_regex(d.pop("file_name_regex", UNSET))

        def _parse_expected_match_count(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        expected_match_count = _parse_expected_match_count(d.pop("expected_match_count", UNSET))

        def _parse_expected_match_count_ref(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        expected_match_count_ref = _parse_expected_match_count_ref(d.pop("expected_match_count_ref", UNSET))

        def _parse_loop_input(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        loop_input = _parse_loop_input(d.pop("loop_input", UNSET))

        def _parse_loop_item_filename_template(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        loop_item_filename_template = _parse_loop_item_filename_template(d.pop("loop_item_filename_template", UNSET))

        def _parse_allow_missing_loop_attachments(data: object) -> Unset | bool:
            if isinstance(data, Unset):
                return data
            return cast(Unset | bool, data)

        allow_missing_loop_attachments = _parse_allow_missing_loop_attachments(
            d.pop("allow_missing_loop_attachments", UNSET)
        )

        def _parse_check_prompt(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        check_prompt = _parse_check_prompt(d.pop("check_prompt", UNSET))

        def _parse_model(data: object) -> None | Unset | UUID:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                model_type_0 = UUID(data)

                return model_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Unset | UUID, data)

        model = _parse_model(d.pop("model", UNSET))

        def _parse_user_id(data: object) -> None | Unset | UUID:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                user_id_type_0 = UUID(data)

                return user_id_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Unset | UUID, data)

        user_id = _parse_user_id(d.pop("user_id", UNSET))

        workflow_post_run_check_response = cls(
            name=name,
            type_=type_,
            id=id,
            organization_id=organization_id,
            order=order,
            created_at=created_at,
            updated_at=updated_at,
            description=description,
            file_target_mode=file_target_mode,
            file_names=file_names,
            file_name_regex=file_name_regex,
            expected_match_count=expected_match_count,
            expected_match_count_ref=expected_match_count_ref,
            loop_input=loop_input,
            loop_item_filename_template=loop_item_filename_template,
            allow_missing_loop_attachments=allow_missing_loop_attachments,
            check_prompt=check_prompt,
            model=model,
            user_id=user_id,
        )

        workflow_post_run_check_response.additional_properties = d
        return workflow_post_run_check_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
