from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar, cast
from uuid import UUID

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..models.post_run_check_file_target_mode import PostRunCheckFileTargetMode
from ..models.post_run_check_status import PostRunCheckStatus
from ..models.post_run_check_type import PostRunCheckType
from ..types import UNSET, Unset

T = TypeVar("T", bound="RunPostRunCheckSnapshot")


@_attrs_define
class RunPostRunCheckSnapshot:
    """Version-tolerant run-level snapshot/result for one post-run check invocation.

    Attributes:
        status (PostRunCheckStatus):
        id (None | Unset | UUID):
        post_run_check_id (None | Unset | UUID):
        snapshot_version (int | None | Unset):
        name (None | str | Unset):
        description (None | str | Unset):
        type_ (None | PostRunCheckType | Unset):
        order (int | None | Unset):
        file_target_mode (None | PostRunCheckFileTargetMode | Unset):
        file_names (list[str] | None | Unset):
        file_name_regex (None | str | Unset):
        expected_match_count (int | None | Unset):
        expected_match_count_ref (None | str | Unset):
        loop_input (None | str | Unset):
        loop_item_filename_template (None | str | Unset):
        allow_missing_loop_attachments (bool | Unset):
        check_prompt (None | str | Unset):
        model (None | Unset | UUID):
        started_at (datetime.datetime | None | Unset):
        ended_at (datetime.datetime | None | Unset):
        error_message (None | str | Unset):
        messages (list[str] | None | Unset):
        matched_filenames (list[str] | None | Unset):
    """

    status: PostRunCheckStatus
    id: None | Unset | UUID = UNSET
    post_run_check_id: None | Unset | UUID = UNSET
    snapshot_version: int | None | Unset = UNSET
    name: None | str | Unset = UNSET
    description: None | str | Unset = UNSET
    type_: None | PostRunCheckType | Unset = UNSET
    order: int | None | Unset = UNSET
    file_target_mode: None | PostRunCheckFileTargetMode | Unset = UNSET
    file_names: list[str] | None | Unset = UNSET
    file_name_regex: None | str | Unset = UNSET
    expected_match_count: int | None | Unset = UNSET
    expected_match_count_ref: None | str | Unset = UNSET
    loop_input: None | str | Unset = UNSET
    loop_item_filename_template: None | str | Unset = UNSET
    allow_missing_loop_attachments: bool | Unset = UNSET
    check_prompt: None | str | Unset = UNSET
    model: None | Unset | UUID = UNSET
    started_at: datetime.datetime | None | Unset = UNSET
    ended_at: datetime.datetime | None | Unset = UNSET
    error_message: None | str | Unset = UNSET
    messages: list[str] | None | Unset = UNSET
    matched_filenames: list[str] | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        status = self.status.value

        id: None | str | Unset
        if isinstance(self.id, Unset):
            id = UNSET
        elif isinstance(self.id, UUID):
            id = str(self.id)
        else:
            id = self.id

        post_run_check_id: None | str | Unset
        if isinstance(self.post_run_check_id, Unset):
            post_run_check_id = UNSET
        elif isinstance(self.post_run_check_id, UUID):
            post_run_check_id = str(self.post_run_check_id)
        else:
            post_run_check_id = self.post_run_check_id

        snapshot_version: int | None | Unset
        if isinstance(self.snapshot_version, Unset):
            snapshot_version = UNSET
        else:
            snapshot_version = self.snapshot_version

        name: None | str | Unset
        if isinstance(self.name, Unset):
            name = UNSET
        else:
            name = self.name

        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description

        type_: None | str | Unset
        if isinstance(self.type_, Unset):
            type_ = UNSET
        elif isinstance(self.type_, PostRunCheckType):
            type_ = self.type_.value
        else:
            type_ = self.type_

        order: int | None | Unset
        if isinstance(self.order, Unset):
            order = UNSET
        else:
            order = self.order

        file_target_mode: None | str | Unset
        if isinstance(self.file_target_mode, Unset):
            file_target_mode = UNSET
        elif isinstance(self.file_target_mode, PostRunCheckFileTargetMode):
            file_target_mode = self.file_target_mode.value
        else:
            file_target_mode = self.file_target_mode

        file_names: list[str] | None | Unset
        if isinstance(self.file_names, Unset):
            file_names = UNSET
        elif isinstance(self.file_names, list):
            file_names = self.file_names

        else:
            file_names = self.file_names

        file_name_regex: None | str | Unset
        if isinstance(self.file_name_regex, Unset):
            file_name_regex = UNSET
        else:
            file_name_regex = self.file_name_regex

        expected_match_count: int | None | Unset
        if isinstance(self.expected_match_count, Unset):
            expected_match_count = UNSET
        else:
            expected_match_count = self.expected_match_count

        expected_match_count_ref: None | str | Unset
        if isinstance(self.expected_match_count_ref, Unset):
            expected_match_count_ref = UNSET
        else:
            expected_match_count_ref = self.expected_match_count_ref

        loop_input: None | str | Unset
        if isinstance(self.loop_input, Unset):
            loop_input = UNSET
        else:
            loop_input = self.loop_input

        loop_item_filename_template: None | str | Unset
        if isinstance(self.loop_item_filename_template, Unset):
            loop_item_filename_template = UNSET
        else:
            loop_item_filename_template = self.loop_item_filename_template

        allow_missing_loop_attachments = self.allow_missing_loop_attachments

        check_prompt: None | str | Unset
        if isinstance(self.check_prompt, Unset):
            check_prompt = UNSET
        else:
            check_prompt = self.check_prompt

        model: None | str | Unset
        if isinstance(self.model, Unset):
            model = UNSET
        elif isinstance(self.model, UUID):
            model = str(self.model)
        else:
            model = self.model

        started_at: None | str | Unset
        if isinstance(self.started_at, Unset):
            started_at = UNSET
        elif isinstance(self.started_at, datetime.datetime):
            started_at = self.started_at.isoformat()
        else:
            started_at = self.started_at

        ended_at: None | str | Unset
        if isinstance(self.ended_at, Unset):
            ended_at = UNSET
        elif isinstance(self.ended_at, datetime.datetime):
            ended_at = self.ended_at.isoformat()
        else:
            ended_at = self.ended_at

        error_message: None | str | Unset
        if isinstance(self.error_message, Unset):
            error_message = UNSET
        else:
            error_message = self.error_message

        messages: list[str] | None | Unset
        if isinstance(self.messages, Unset):
            messages = UNSET
        elif isinstance(self.messages, list):
            messages = self.messages

        else:
            messages = self.messages

        matched_filenames: list[str] | None | Unset
        if isinstance(self.matched_filenames, Unset):
            matched_filenames = UNSET
        elif isinstance(self.matched_filenames, list):
            matched_filenames = self.matched_filenames

        else:
            matched_filenames = self.matched_filenames

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "status": status,
            }
        )
        if id is not UNSET:
            field_dict["id"] = id
        if post_run_check_id is not UNSET:
            field_dict["post_run_check_id"] = post_run_check_id
        if snapshot_version is not UNSET:
            field_dict["snapshot_version"] = snapshot_version
        if name is not UNSET:
            field_dict["name"] = name
        if description is not UNSET:
            field_dict["description"] = description
        if type_ is not UNSET:
            field_dict["type"] = type_
        if order is not UNSET:
            field_dict["order"] = order
        if file_target_mode is not UNSET:
            field_dict["file_target_mode"] = file_target_mode
        if file_names is not UNSET:
            field_dict["file_names"] = file_names
        if file_name_regex is not UNSET:
            field_dict["file_name_regex"] = file_name_regex
        if expected_match_count is not UNSET:
            field_dict["expected_match_count"] = expected_match_count
        if expected_match_count_ref is not UNSET:
            field_dict["expected_match_count_ref"] = expected_match_count_ref
        if loop_input is not UNSET:
            field_dict["loop_input"] = loop_input
        if loop_item_filename_template is not UNSET:
            field_dict["loop_item_filename_template"] = loop_item_filename_template
        if allow_missing_loop_attachments is not UNSET:
            field_dict["allow_missing_loop_attachments"] = allow_missing_loop_attachments
        if check_prompt is not UNSET:
            field_dict["check_prompt"] = check_prompt
        if model is not UNSET:
            field_dict["model"] = model
        if started_at is not UNSET:
            field_dict["started_at"] = started_at
        if ended_at is not UNSET:
            field_dict["ended_at"] = ended_at
        if error_message is not UNSET:
            field_dict["error_message"] = error_message
        if messages is not UNSET:
            field_dict["messages"] = messages
        if matched_filenames is not UNSET:
            field_dict["matched_filenames"] = matched_filenames

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        status = PostRunCheckStatus(d.pop("status"))

        def _parse_id(data: object) -> None | Unset | UUID:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                id_type_0 = UUID(data)

                return id_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Unset | UUID, data)

        id = _parse_id(d.pop("id", UNSET))

        def _parse_post_run_check_id(data: object) -> None | Unset | UUID:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                post_run_check_id_type_0 = UUID(data)

                return post_run_check_id_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Unset | UUID, data)

        post_run_check_id = _parse_post_run_check_id(d.pop("post_run_check_id", UNSET))

        def _parse_snapshot_version(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        snapshot_version = _parse_snapshot_version(d.pop("snapshot_version", UNSET))

        def _parse_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        name = _parse_name(d.pop("name", UNSET))

        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))

        def _parse_type_(data: object) -> None | PostRunCheckType | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                type_type_0 = PostRunCheckType(data)

                return type_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | PostRunCheckType | Unset, data)

        type_ = _parse_type_(d.pop("type", UNSET))

        def _parse_order(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        order = _parse_order(d.pop("order", UNSET))

        def _parse_file_target_mode(data: object) -> None | PostRunCheckFileTargetMode | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                file_target_mode_type_0 = PostRunCheckFileTargetMode(data)

                return file_target_mode_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | PostRunCheckFileTargetMode | Unset, data)

        file_target_mode = _parse_file_target_mode(d.pop("file_target_mode", UNSET))

        def _parse_file_names(data: object) -> list[str] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                file_names_type_0 = cast(list[str], data)

                return file_names_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[str] | None | Unset, data)

        file_names = _parse_file_names(d.pop("file_names", UNSET))

        def _parse_file_name_regex(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        file_name_regex = _parse_file_name_regex(d.pop("file_name_regex", UNSET))

        def _parse_expected_match_count(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        expected_match_count = _parse_expected_match_count(d.pop("expected_match_count", UNSET))

        def _parse_expected_match_count_ref(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        expected_match_count_ref = _parse_expected_match_count_ref(d.pop("expected_match_count_ref", UNSET))

        def _parse_loop_input(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        loop_input = _parse_loop_input(d.pop("loop_input", UNSET))

        def _parse_loop_item_filename_template(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        loop_item_filename_template = _parse_loop_item_filename_template(d.pop("loop_item_filename_template", UNSET))

        def _parse_allow_missing_loop_attachments(data: object) -> bool | Unset:
            if isinstance(data, Unset):
                return data
            return cast(bool | Unset, data)

        allow_missing_loop_attachments = _parse_allow_missing_loop_attachments(
            d.pop("allow_missing_loop_attachments", UNSET)
        )

        def _parse_check_prompt(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        check_prompt = _parse_check_prompt(d.pop("check_prompt", UNSET))

        def _parse_model(data: object) -> None | Unset | UUID:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                model_type_0 = UUID(data)

                return model_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Unset | UUID, data)

        model = _parse_model(d.pop("model", UNSET))

        def _parse_started_at(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                started_at_type_0 = isoparse(data)

                return started_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        started_at = _parse_started_at(d.pop("started_at", UNSET))

        def _parse_ended_at(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                ended_at_type_0 = isoparse(data)

                return ended_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        ended_at = _parse_ended_at(d.pop("ended_at", UNSET))

        def _parse_error_message(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        error_message = _parse_error_message(d.pop("error_message", UNSET))

        def _parse_messages(data: object) -> list[str] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                messages_type_0 = cast(list[str], data)

                return messages_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[str] | None | Unset, data)

        messages = _parse_messages(d.pop("messages", UNSET))

        def _parse_matched_filenames(data: object) -> list[str] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                matched_filenames_type_0 = cast(list[str], data)

                return matched_filenames_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[str] | None | Unset, data)

        matched_filenames = _parse_matched_filenames(d.pop("matched_filenames", UNSET))

        run_post_run_check_snapshot = cls(
            status=status,
            id=id,
            post_run_check_id=post_run_check_id,
            snapshot_version=snapshot_version,
            name=name,
            description=description,
            type_=type_,
            order=order,
            file_target_mode=file_target_mode,
            file_names=file_names,
            file_name_regex=file_name_regex,
            expected_match_count=expected_match_count,
            expected_match_count_ref=expected_match_count_ref,
            loop_input=loop_input,
            loop_item_filename_template=loop_item_filename_template,
            allow_missing_loop_attachments=allow_missing_loop_attachments,
            check_prompt=check_prompt,
            model=model,
            started_at=started_at,
            ended_at=ended_at,
            error_message=error_message,
            messages=messages,
            matched_filenames=matched_filenames,
        )

        run_post_run_check_snapshot.additional_properties = d
        return run_post_run_check_snapshot

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
