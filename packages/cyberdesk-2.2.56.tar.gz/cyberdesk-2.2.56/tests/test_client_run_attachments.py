from pathlib import Path
from types import SimpleNamespace

import pytest

from cyberdesk.client import ApiResponse, RunAttachmentsAPI


def _build_run_attachments_api(
    filename: str,
    payload: bytes = b"attachment-bytes",
) -> RunAttachmentsAPI:
    api = RunAttachmentsAPI(client=None)

    async def _get(_attachment_id: str) -> ApiResponse[SimpleNamespace]:
        return ApiResponse(data=SimpleNamespace(filename=filename))

    async def _download(_attachment_id: str) -> ApiResponse[bytes]:
        return ApiResponse(data=payload)

    setattr(api, "get", _get)
    setattr(
        api,
        "get_sync",
        lambda _attachment_id: ApiResponse(data=SimpleNamespace(filename=filename)),
    )
    setattr(api, "download", _download)
    setattr(api, "download_sync", lambda _attachment_id: ApiResponse(data=payload))
    return api


@pytest.mark.unit
def test_save_to_file_sync_uses_safe_basename_for_absolute_filename(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.chdir(tmp_path)
    api = _build_run_attachments_api("/etc/passwd")

    response = api.save_to_file_sync("attachment-id")

    assert response.error is None
    assert response.data == {"path": "passwd", "size": len(b"attachment-bytes")}
    assert (tmp_path / "passwd").read_bytes() == b"attachment-bytes"


@pytest.mark.unit
def test_save_to_file_sync_keeps_relative_traversal_inside_output_dir(
    tmp_path: Path,
) -> None:
    api = _build_run_attachments_api("../../stolen.txt")

    response = api.save_to_file_sync(
        "attachment-id",
        output_path=tmp_path,
        use_original_filename=True,
    )

    assert response.error is None
    assert response.data == {
        "path": str(tmp_path / "stolen.txt"),
        "size": len(b"attachment-bytes"),
    }
    assert (tmp_path / "stolen.txt").read_bytes() == b"attachment-bytes"


@pytest.mark.unit
@pytest.mark.asyncio
async def test_save_to_file_strips_windows_path_components(
    tmp_path: Path,
) -> None:
    api = _build_run_attachments_api(r"..\..\secrets.txt")

    response = await api.save_to_file(
        "attachment-id",
        output_path=tmp_path,
        use_original_filename=True,
    )

    assert response.error is None
    assert response.data == {
        "path": str(tmp_path / "secrets.txt"),
        "size": len(b"attachment-bytes"),
    }
    assert (tmp_path / "secrets.txt").read_bytes() == b"attachment-bytes"


@pytest.mark.unit
def test_save_to_file_sync_rejects_dotdot_filename(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.chdir(tmp_path)
    api = _build_run_attachments_api("..")

    response = api.save_to_file_sync("attachment-id")

    assert isinstance(response.error, ValueError)
    assert "Unsafe attachment filename" in str(response.error)
    assert list(tmp_path.iterdir()) == []
