import json
from http import HTTPStatus

import pytest

from cyberdesk.client import CyberdeskClient, RunBulkCreate, RunField
from openapi_client.cyberdesk_cloud_client.types import Response


RUN_PAYLOAD = {
    "workflow_id": "00000000-0000-0000-0000-000000000001",
    "machine_id": None,
    "id": "00000000-0000-0000-0000-000000000002",
    "status": "scheduling",
    "created_at": "2026-04-04T01:10:42.560368Z",
}


@pytest.mark.unit
def test_runs_list_sync_parses_success_payload(monkeypatch: pytest.MonkeyPatch) -> None:
    from cyberdesk import client as client_module

    def _fake_sync_detailed(**_kwargs):
        return Response(
            status_code=HTTPStatus.OK,
            content=json.dumps(
                {
                    "items": [RUN_PAYLOAD],
                    "total": 1,
                    "skip": 0,
                    "limit": 100,
                }
            ).encode("utf-8"),
            headers={},
            parsed=None,
        )

    monkeypatch.setattr(client_module.list_runs_v1_runs_get, "sync_detailed", _fake_sync_detailed)

    sdk = CyberdeskClient("test-key", base_url="https://example.invalid")
    try:
        response = sdk.runs.list_sync(fields=[RunField.ERROR])
    finally:
        sdk.close()

    assert response.error is None
    assert response.data is not None
    assert response.data.total == 1
    assert str(response.data.items[0].id) == RUN_PAYLOAD["id"]


@pytest.mark.unit
def test_runs_bulk_create_sync_parses_success_payload(monkeypatch: pytest.MonkeyPatch) -> None:
    from cyberdesk import client as client_module

    def _fake_sync_detailed(**_kwargs):
        return Response(
            status_code=HTTPStatus.CREATED,
            content=json.dumps(
                {
                    "created_runs": [RUN_PAYLOAD],
                    "failed_count": 0,
                    "errors": [],
                }
            ).encode("utf-8"),
            headers={},
            parsed=None,
        )

    monkeypatch.setattr(
        client_module.bulk_create_runs_v1_runs_bulk_post,
        "sync_detailed",
        _fake_sync_detailed,
    )

    sdk = CyberdeskClient("test-key", base_url="https://example.invalid")
    try:
        response = sdk.runs.bulk_create_sync(
            RunBulkCreate(
                workflow_id=RUN_PAYLOAD["workflow_id"],
                count=1,
            )
        )
    finally:
        sdk.close()

    assert response.error is None
    assert response.data is not None
    assert response.data.failed_count == 0
    assert str(response.data.created_runs[0].id) == RUN_PAYLOAD["id"]
