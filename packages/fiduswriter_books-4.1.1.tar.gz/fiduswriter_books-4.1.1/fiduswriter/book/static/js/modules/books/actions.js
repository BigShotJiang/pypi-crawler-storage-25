import {
    ContentMenu,
    Dialog,
    FileSelector,
    activateWait,
    addAlert,
    deactivateWait,
    escapeText,
    findTarget,
    longFilePath,
    post,
    postJson
} from "../common"
import {ImageSelectionDialog} from "../images/selection_dialog"
import {NativeBookImporter} from "./importer/native"
import {exportMenuModel} from "./menu"
import {bookSanityCheck} from "./sanity_check"
import {
    bookBasicInfoTemplate,
    bookBibliographyDataTemplate,
    bookChapterDialogTemplate,
    bookChapterListTemplate,
    bookDOCXDataRowTemplate,
    bookDOCXDataTemplate,
    bookDialogChaptersTemplate,
    bookDialogTemplate,
    bookEpubDataCoverTemplate,
    bookEpubDataTemplate,
    bookODTDataRowTemplate,
    bookODTDataTemplate,
    bookPrintDataTemplate,
    bookSanityCheckTemplate
} from "./templates"

function emptyMetadata() {
    return {
        author: "",
        subtitle: "",
        version: "",
        publisher: "",
        copyright: "",
        keywords: "",
        description: "",
        isbn: "",
        publication_date: "",
        series_title: "",
        series_position: ""
    }
}

export class BookActions {
    constructor(bookOverview) {
        bookOverview.mod.actions = this
        this.bookOverview = bookOverview
        this.exportMenu = exportMenuModel()
        this.onSave = []
        this.dialogParts = [
            {
                title: gettext("Basic info"),
                description: gettext("Basic book information"),
                template: bookBasicInfoTemplate
            },
            {
                title: gettext("Chapters"),
                description: gettext("Documents assigned as chapters"),
                template: bookDialogChaptersTemplate
            },
            {
                title: gettext("Bibliography"),
                description: gettext("Bibliography related settings"),
                template: bookBibliographyDataTemplate
            },
            {
                title: gettext("Epub"),
                description: gettext("Epub related settings"),
                template: bookEpubDataTemplate
            },
            {
                title: gettext("DOCX"),
                description: gettext("DOCX related settings"),
                template: bookDOCXDataTemplate
            },
            {
                title: gettext("ODT"),
                description: gettext("ODT related settings"),
                template: bookODTDataTemplate
            },
            {
                title: gettext("Print/PDF"),
                description: gettext("Print related settings"),
                template: bookPrintDataTemplate
            },
            {
                title: gettext("Sanity check"),
                description: gettext("Perform sanity check on book"),
                template: bookSanityCheckTemplate
            }
        ]
    }

    deleteBook(id) {
        const book = this.bookOverview.bookList.find(book => book.id === id)
        if (!book) {
            return Promise.return()
        }

        return post("/api/book/delete/", {id})
            .catch(error => {
                addAlert(
                    "error",
                    `${gettext("Could not delete book")}: '${longFilePath(
                        book.title,
                        book.path
                    )}'`
                )
                throw error
            })
            .then(() => {
                addAlert(
                    "success",
                    `${gettext("Book has been deleted")}: '${longFilePath(
                        book.title,
                        book.path
                    )}'`
                )
                this.bookOverview.bookList = this.bookOverview.bookList.filter(
                    book => book.id !== id
                )
                this.bookOverview.initTable()
            })
    }

    deleteBookDialog(ids) {
        const bookPaths = ids.map(id => {
            const book = this.bookOverview.bookList.find(book => book.id === id)
            return escapeText(longFilePath(book.title, book.path))
        })
        const buttons = [
            {
                type: "close"
            },
            {
                text: gettext("Delete"),
                classes: "fw-dark",
                click: () => {
                    Promise.all(ids.map(id => this.deleteBook(id))).then(() => {
                        dialog.close()
                        this.bookOverview.initTable()
                    })
                }
            }
        ]

        const dialog = new Dialog({
            title: gettext("Confirm deletion"),
            id: "confirmdeletion",
            icon: "exclamation-triangle",
            height: Math.min(50 + 15 * ids.length, 500),
            body: `<p>${
                ids.length > 1
                    ? gettext(
                          "Do you really want to delete the following books?"
                      )
                    : gettext(
                          "Do you really want to delete the following book?"
                      )
            }</p>
            <p>
                ${bookPaths.join("<br>")}
            </p>`,
            buttons
        })
        dialog.open()
    }

    editChapterDialog(chapter, book) {
        const doc = this.bookOverview.documentList.find(
            doc => doc.id === chapter.text
        )
        let docTitle = doc.title
        if (!docTitle.length) {
            docTitle = gettext("Untitled")
        }

        const buttons = [
            {
                type: "cancel"
            },
            {
                text: gettext("Submit"),
                classes: "fw-dark",
                click: () => {
                    chapter.part =
                        document.getElementById("book-chapter-part").value
                    document.getElementById("book-chapter-list").innerHTML =
                        bookChapterListTemplate({
                            book,
                            documentList: this.bookOverview.documentList
                        })
                    dialog.close()
                }
            }
        ]

        const dialog = new Dialog({
            title: `${gettext("Edit Chapter")}: ${chapter.number}. ${docTitle}`,
            body: bookChapterDialogTemplate({chapter}),
            width: 300,
            height: 100,
            buttons
        })
        dialog.open()
    }

    saveBook(book, oldBookId = false) {
        const oldBook = oldBookId
            ? this.bookOverview.bookList.find(book => book.id === oldBookId)
            : false
        if (book.rights !== "write") {
            return Promise.resolve()
        }
        book.title = document.getElementById("book-title").value
        book.metadata.author = document.getElementById(
            "book-metadata-author"
        ).value
        book.metadata.subtitle = document.getElementById(
            "book-metadata-subtitle"
        ).value
        book.metadata.version = document.getElementById(
            "book-metadata-version"
        ).value
        book.metadata.copyright = document.getElementById(
            "book-metadata-copyright"
        ).value
        book.metadata.publisher = document.getElementById(
            "book-metadata-publisher"
        ).value
        book.metadata.keywords = document.getElementById(
            "book-metadata-keywords"
        ).value
        book.metadata.description = document.getElementById(
            "book-metadata-description"
        ).value
        book.metadata.isbn = document.getElementById("book-metadata-isbn").value
        book.metadata.publication_date = document.getElementById(
            "book-metadata-publication-date"
        ).value
        book.metadata.series_title = document.getElementById(
            "book-metadata-series-title"
        ).value
        book.metadata.series_position = document.getElementById(
            "book-metadata-series-position"
        ).value
        book.settings.language = document.getElementById(
            "book-settings-language"
        ).value
        book.path = oldBook?.path || this.bookOverview.path
        const bookData = Object.assign({}, book)
        delete bookData.cover_image_data

        return postJson("/api/book/save/", {book: bookData})
            .catch(error => {
                addAlert("error", gettext("The book could not be saved"))
                throw error
            })
            .then(({status, json}) => {
                if (status == 201) {
                    book.id = json.id
                    book.added = json.added
                }
                book.updated = json.updated
                if (oldBookId) {
                    this.bookOverview.bookList =
                        this.bookOverview.bookList.filter(
                            book => book.id !== oldBookId
                        )
                }
                this.bookOverview.bookList.push(book)
                this.bookOverview.initTable()
                return Promise.all(this.onSave.map(method => method(book)))
            })
    }

    copyBook(oldBook) {
        const book = Object.assign({}, oldBook)
        book.is_owner = true
        book.owner = this.bookOverview.user
        book.rights = "write"
        const path = longFilePath(
            oldBook.title,
            oldBook.path,
            `${gettext("Copy of")} `
        )
        return postJson("/api/book/copy/", {id: book.id, path})
            .catch(error => {
                addAlert("error", gettext("The book could not be copied"))
                throw error
            })
            .then(({json}) => {
                book.id = json["id"]
                book.path = json["path"]
                this.bookOverview.bookList.push(book)
                this.bookOverview.initTable()
            })
    }

    /**
     * Open a dialog to let the user pick a .fidusbook file and import it.
     * Creates all chapter documents on the server, uploads the cover image
     * (if present), and finally creates the book record.
     */
    importBook() {
        const overview = this.bookOverview
        const e2eeMode = overview.app.settings.E2EE_MODE
        const e2eeRequired = e2eeMode === "required"
        const e2eeOptional = e2eeMode === "enabled"

        // Extra UI inside the dialog body for E2EE modes.
        const e2eeNote = e2eeRequired
            ? `<p class="fw-note" style="margin-top:10px;">
                <i class="fas fa-lock"></i>
                ${gettext("Chapters will be imported as encrypted (E2EE) documents.")}
               </p>`
            : ""
        const e2eeCheckbox = e2eeOptional
            ? `<p style="margin-top:10px;">
                <label>
                    <input type="checkbox" id="fidusbook-import-e2ee" style="margin-right:6px;">
                    ${gettext("Import chapters as encrypted (E2EE) documents")}
                </label>
               </p>`
            : ""

        const importDialog = new Dialog({
            id: "import_fidusbook",
            title: gettext("Import a book"),
            body: `<p>
                <label class="fw-document-list-item fw-large" for="fidusbook-uploader">
                    ${gettext("Select a .fidusbook file:")}
                </label>
            </p>
            <p>
                <input type="file"
                       id="fidusbook-uploader"
                       accept=".fidusbook"
                       style="display:block;margin-top:8px;">
            </p>
            ${e2eeNote}
            ${e2eeCheckbox}`,
            height: e2eeRequired || e2eeOptional ? 230 : 180,
            buttons: [
                {
                    text: gettext("Import"),
                    classes: "fw-dark",
                    click: () => {
                        const fileInput =
                            document.getElementById("fidusbook-uploader")
                        if (!fileInput || fileInput.files.length === 0) {
                            return
                        }
                        const file = fileInput.files[0]
                        if (file.size > 524288000) {
                            // 500 MB hard limit
                            addAlert("error", gettext("File too large"))
                            return
                        }
                        const useE2EE =
                            e2eeRequired ||
                            (e2eeOptional &&
                                !!document.getElementById(
                                    "fidusbook-import-e2ee"
                                )?.checked)
                        importDialog.close()
                        activateWait(true)

                        const importer = new NativeBookImporter(
                            file,
                            overview.user,
                            overview.path,
                            useE2EE
                        )
                        importer
                            .init()
                            .then(({ok, statusText}) => {
                                deactivateWait()
                                if (ok) {
                                    addAlert("info", statusText)
                                    // Refresh the book list from the server
                                    // so the newly-imported book appears.
                                    overview.getBookListData()
                                } else {
                                    addAlert("error", statusText)
                                }
                            })
                            .catch(() => {
                                deactivateWait()
                            })
                    }
                },
                {
                    type: "cancel"
                }
            ]
        })
        importDialog.open()
    }

    createBookDialog(bookId, imageDB) {
        let title, book, oldBookId
        const bookImageDB = {db: {}}

        if (bookId === 0) {
            title = gettext("Create Book")
            book = {
                title: "",
                id: 0,
                chapters: [],
                is_owner: true,
                owner: this.bookOverview.user,
                rights: "write",
                metadata: emptyMetadata(),
                settings: {
                    bibliography_header: gettext("Bibliography"),
                    citationstyle: "apa",
                    book_style: this.bookOverview.styles[0]
                        ? this.bookOverview.styles[0].slug
                        : false,
                    papersize: "octavo",
                    language: "en-US"
                }
            }
        } else {
            const oldBook = this.bookOverview.bookList.find(
                book => book.id === bookId
            )
            book = Object.assign({}, oldBook)
            book.metadata = Object.assign(emptyMetadata(), oldBook.metadata)
            oldBookId = oldBook.id

            if (book.cover_image && !imageDB.db[book.cover_image]) {
                // The cover image is not in the current user's image DB --
                // it was either deleted or another user originally added
                // it. As we don't do anything fancy with it, we simply add
                // the current cover image to the DB locally so that image
                // selection works as expected.
                bookImageDB.db[book.cover_image] = book.cover_image_data
            }
            title = gettext("Edit Book")
        }
        const body = bookDialogTemplate({
            title,
            dialogParts: this.dialogParts,
            bookInfo: {
                book,
                documentList: this.bookOverview.documentList,
                citationStyles: this.bookOverview.citationStyles,
                bookStyleList: this.bookOverview.styles,
                imageDB: {db: Object.assign({}, imageDB.db, bookImageDB.db)}
            }
        })

        const buttons = []
        buttons.push({
            text: gettext("Export"),
            dropdown: true,
            classes: "fw-dark",
            click: event => {
                const contentMenu = new ContentMenu({
                    page: {
                        saveBook: () => this.saveBook(book, oldBookId),
                        book,
                        overview: this.bookOverview
                    },
                    menu: this.exportMenu,
                    menuPos: {X: event.pageX, Y: event.pageY},
                    width: 250
                })
                return contentMenu.open()
            }
        })
        if (book.rights === "write") {
            buttons.push({
                text: gettext("Submit"),
                classes: "fw-dark",
                click: () => {
                    return this.saveBook(book, oldBookId).then(() =>
                        dialog.close()
                    )
                }
            })
            buttons.push({type: "cancel"})
        } else {
            buttons.push({type: "close"})
        }

        const dialog = new Dialog({
            width: 840,
            height: 520,
            title,
            body,
            buttons
        })
        dialog.open()

        dialog.dialogEl
            .querySelectorAll("#bookoptions-tab .tab-content")
            .forEach((el, index) => {
                if (index) {
                    el.style.display = "none"
                }
            })
        let fileSelector
        if (book.rights === "write") {
            fileSelector = new FileSelector({
                dom: dialog.dialogEl.querySelector("#book-document-list"),
                files: this.bookOverview.documentList,
                multiSelect: true,
                selectFolders: false
            })
            fileSelector.init()

            dialog.dialogEl
                .querySelector("#input-docx-template")
                .addEventListener("change", event => {
                    const file = event.target.files[0]
                    return this.saveBook(book)
                        .then(() =>
                            postJson(
                                "/api/book/docx_template/save/",
                                {
                                    id: book.id
                                },
                                {file}
                            )
                        )
                        .then(({status, json}) => {
                            if (status !== 200) {
                                return
                            }
                            book.docx_template = json.docx_template
                            const docxTemplateRow =
                                document.getElementById("docx-template-row")
                            if (docxTemplateRow) {
                                docxTemplateRow.innerHTML =
                                    bookDOCXDataRowTemplate({book})
                            }
                        })
                })

            dialog.dialogEl
                .querySelector("#input-odt-template")
                .addEventListener("change", event => {
                    const file = event.target.files[0]
                    return this.saveBook(book)
                        .then(() =>
                            postJson(
                                "/api/book/odt_template/save/",
                                {
                                    id: book.id
                                },
                                {file}
                            )
                        )
                        .then(({status, json}) => {
                            if (status !== 200) {
                                return
                            }
                            book.odt_template = json.odt_template
                            const odtTemplateRow =
                                document.getElementById("odt-template-row")
                            if (odtTemplateRow) {
                                odtTemplateRow.innerHTML =
                                    bookODTDataRowTemplate({book})
                            }
                        })
                })
        }

        // Handle tab link clicking
        dialog.dialogEl
            .querySelectorAll("#bookoptions-tab .tab-link a")
            .forEach(el =>
                el.addEventListener("click", event => {
                    event.preventDefault()

                    el.parentNode.parentNode
                        .querySelectorAll(".tab-link.current-tab")
                        .forEach(el => el.classList.remove("current-tab"))
                    el.parentNode.classList.add("current-tab")

                    const link = el.getAttribute("href")
                    dialog.dialogEl
                        .querySelectorAll("#bookoptions-tab .tab-content")
                        .forEach(el => {
                            if (el.matches(link)) {
                                el.style.display = ""
                            } else {
                                el.style.display = "none"
                            }
                        })
                })
            )

        dialog.dialogEl.addEventListener("click", event => {
            const el = {}
            let chapterId, chapter

            // Helper: add or remove the encrypted-chapters notice that lives
            // alongside #book-chapter-list. Called after any operation that
            // changes book.chapters so the notice stays in sync.
            const updateChapterNotice = () => {
                const chapterListEl =
                    document.getElementById("book-chapter-list")
                if (!chapterListEl) {
                    return
                }
                const container = chapterListEl.closest(".fw-ar-container")
                if (!container) {
                    return
                }
                const existingNotice = container.querySelector(
                    ".e2ee-chapter-notice"
                )
                const hasEncrypted = book.chapters.some(
                    ch =>
                        this.bookOverview.documentList.find(
                            doc => doc.id === ch.text
                        )?.e2ee
                )
                if (hasEncrypted && !existingNotice) {
                    container.insertAdjacentHTML(
                        "beforeend",
                        `<p class="fw-note e2ee-chapter-notice">
                            <i class="fas fa-lock"></i>
                            ${gettext("This book contains encrypted chapters. A personal passphrase is required to export or run a sanity check on this book.")}
                        </p>`
                    )
                } else if (!hasEncrypted && existingNotice) {
                    existingNotice.remove()
                }
            }

            switch (true) {
                case findTarget(event, ".book-sort-up", el): {
                    chapterId = Number.parseInt(el.target.dataset.id)
                    chapter = book.chapters.find(
                        chapter => chapter.text === chapterId
                    )

                    const higherChapter = book.chapters.find(
                        bChapter => bChapter.number === chapter.number - 1
                    )
                    chapter.number--
                    higherChapter.number++
                    document.getElementById("book-chapter-list").innerHTML =
                        bookChapterListTemplate({
                            book,
                            documentList: this.bookOverview.documentList
                        })
                    updateChapterNotice()
                    break
                }
                case findTarget(event, ".book-sort-down", el): {
                    chapterId = Number.parseInt(el.target.dataset.id)
                    chapter = book.chapters.find(
                        chapter => chapter.text === chapterId
                    )

                    const lowerChapter = book.chapters.find(
                        bChapter => bChapter.number === chapter.number + 1
                    )

                    chapter.number++
                    lowerChapter.number--
                    document.getElementById("book-chapter-list").innerHTML =
                        bookChapterListTemplate({
                            book,
                            documentList: this.bookOverview.documentList
                        })
                    updateChapterNotice()
                    break
                }
                case findTarget(event, ".delete-chapter", el):
                    chapterId = Number.parseInt(el.target.dataset.id)
                    chapter = book.chapters.find(
                        chapter => chapter.text === chapterId
                    )

                    book.chapters.forEach(bChapter => {
                        if (bChapter.number > chapter.number) {
                            bChapter.number--
                        }
                    })

                    book.chapters = book.chapters.filter(
                        bChapter => bChapter !== chapter
                    )

                    document.getElementById("book-chapter-list").innerHTML =
                        bookChapterListTemplate({
                            book,
                            documentList: this.bookOverview.documentList
                        })
                    updateChapterNotice()

                    break
                case findTarget(event, "#add-chapter", el): {
                    fileSelector.selected.forEach(entry => {
                        const chapNums = book.chapters.map(
                                chapter => chapter.number
                            ),
                            number = chapNums.length
                                ? Math.max(...chapNums) + 1
                                : 1
                        book.chapters.push({
                            text: entry.file.id,
                            number,
                            part: ""
                        })
                    })
                    fileSelector.deselectAll()

                    document.getElementById("book-chapter-list").innerHTML =
                        bookChapterListTemplate({
                            book,
                            documentList: this.bookOverview.documentList
                        })
                    updateChapterNotice()
                    break
                }
                case findTarget(event, ".edit-chapter", el):
                    chapterId = Number.parseInt(el.target.dataset.id)
                    chapter = book.chapters.find(
                        chapter => chapter.text === chapterId
                    )
                    this.editChapterDialog(chapter, book)
                    break
                case findTarget(event, "#select-cover-image-button", el): {
                    const imageSelection = new ImageSelectionDialog(
                        bookImageDB,
                        imageDB,
                        book.cover_image,
                        this.bookOverview
                    )

                    imageSelection.init().then(image => {
                        if (!image) {
                            delete book.cover_image
                        } else {
                            book.cover_image = image.id
                            book.cover_image_data =
                                image.db === "user"
                                    ? imageDB.db[image.id]
                                    : bookImageDB.db[image.id]
                        }
                        const coverPreviewRow =
                            document.getElementById("cover-preview-row")
                        if (coverPreviewRow) {
                            coverPreviewRow.innerHTML =
                                bookEpubDataCoverTemplate({
                                    book,
                                    imageDB: {
                                        db: Object.assign(
                                            {},
                                            imageDB.db,
                                            bookImageDB.db
                                        )
                                    }
                                })
                        }
                    })
                    break
                }
                case findTarget(event, "#select-docx-template", el): {
                    const fileSelector = document.querySelector(
                        "#input-docx-template"
                    )
                    fileSelector.click()
                    break
                }
                case findTarget(event, "#select-odt-template", el): {
                    const fileSelector = document.querySelector(
                        "#input-odt-template"
                    )
                    fileSelector.click()
                    break
                }
                case findTarget(event, "#remove-cover-image-button", el): {
                    delete book.cover_image
                    const coverPreviewRow =
                        document.getElementById("cover-preview-row")
                    if (coverPreviewRow) {
                        coverPreviewRow.innerHTML = bookEpubDataCoverTemplate({
                            book,
                            imageDB: {db: {}} // We just deleted the cover image, so we don't need a full DB
                        })
                    }
                    break
                }
                case findTarget(event, "#remove-docx-template-button", el): {
                    delete book.docx_template
                    const docxTemplateRow =
                        document.getElementById("docx-template-row")
                    if (docxTemplateRow) {
                        docxTemplateRow.innerHTML = bookDOCXDataRowTemplate({
                            book
                        })
                    }
                    break
                }
                case findTarget(event, "#remove-odt-template-button", el): {
                    delete book.odt_template
                    const odtTemplateRow =
                        document.getElementById("odt-template-row")
                    if (odtTemplateRow) {
                        odtTemplateRow.innerHTML = bookODTDataRowTemplate({
                            book
                        })
                    }
                    break
                }
                case findTarget(event, "#perform-sanity-check-button", el): {
                    this.saveBook(book, oldBookId)
                        .then(() =>
                            bookSanityCheck(
                                book,
                                this.bookOverview.documentList,
                                this.bookOverview.schema
                            )
                        )
                        .then(sanityCheckOutputHTML => {
                            const sanityCheckOutput = document.getElementById(
                                "sanity-check-output"
                            )
                            if (sanityCheckOutput) {
                                sanityCheckOutput.innerHTML =
                                    sanityCheckOutputHTML
                            }
                        })
                    break
                }
                default:
                    break
            }
        })

        dialog.dialogEl
            .querySelector("#book-settings-citationstyle")
            .addEventListener("change", event => {
                book.settings.citationstyle = event.target.value
            })

        dialog.dialogEl
            .querySelector("#book-settings-bookstyle")
            .addEventListener("change", event => {
                book.settings.book_style = event.target.value
            })

        dialog.dialogEl
            .querySelector("#book-settings-papersize")
            .addEventListener("change", event => {
                book.settings.papersize = event.target.value
            })
    }
}
