"""Domain module."""
