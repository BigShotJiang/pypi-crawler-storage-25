from pydantic import BaseModel, Field
from typing import Annotated, Generic
from nexo.types.dict import OptStrToAnyDict
from nexo.types.enum import StrEnumT
from .enums import Origin, Layer, Target


class Component(BaseModel, Generic[StrEnumT]):
    type: StrEnumT = Field(..., description="Component's type")
    details: Annotated[
        OptStrToAnyDict, Field(None, description="Component's details")
    ] = None


class Context(BaseModel):
    origin: Annotated[Component[Origin], Field(..., description="Operation's origin")]
    layer: Annotated[Component[Layer], Field(..., description="Operation's layer")]
    target: Annotated[Component[Target], Field(..., description="Operation's target")]


class ContextMixin(BaseModel):
    context: Context = Field(..., description="Operation's context")


UTILITY_OPERATION_CONTEXT = Context(
    origin=Component[Origin](type=Origin.UTILITY, details=None),
    layer=Component[Layer](type=Layer.INTERNAL, details=None),
    target=Component[Target](type=Target.INTERNAL, details=None),
)


def generate(
    origin: Origin,
    layer: Layer,
    target: Target = Target.INTERNAL,
    origin_details: OptStrToAnyDict = None,
    layer_details: OptStrToAnyDict = None,
    target_details: OptStrToAnyDict = None,
) -> Context:
    return Context(
        origin=Component[Origin](type=origin, details=origin_details),
        layer=Component[Layer](type=layer, details=layer_details),
        target=Component[Target](type=target, details=target_details),
    )
