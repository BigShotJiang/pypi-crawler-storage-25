"""Voice interface for Cade.

Provides speech-to-text (STT) and text-to-speech (TTS) capabilities
using locally-running MLX models on Apple Silicon. STT is powered by
mlx-whisper and TTS by mlx-audio (Kokoro).
"""

import warnings

# Suppress pkg_resources deprecation warning from webrtcvad and other packages
# that haven't migrated to importlib.resources yet
warnings.filterwarnings(
    "ignore",
    message=".*pkg_resources is deprecated.*",
    category=DeprecationWarning,
)
warnings.filterwarnings(
    "ignore",
    message=".*Deprecated call to.*",
    category=DeprecationWarning,
)

from cadecoder.voice.cleanup import strip_for_speech  # noqa: E402
from cadecoder.voice.session import VoiceChatSession, run_voice_session  # noqa: E402

__all__ = [
    "VoiceChatSession",
    "run_voice_session",
    "strip_for_speech",
]
