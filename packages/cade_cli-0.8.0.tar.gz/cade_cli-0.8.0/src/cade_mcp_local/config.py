"""Runtime configuration for the local MCP server.

Configuration is resolved lazily at runtime, not at import time.
This allows proper testing and correct behavior when installed as a package.
"""

import os
import pathlib
from functools import lru_cache


@lru_cache(maxsize=1)
def get_project_root() -> pathlib.Path:
    """Get the project root directory.

    Resolution order:
    1. CADE_PROJECT_ROOT environment variable (set by parent process)
    2. Current working directory

    This is cached for performance but can be reset with reset_config().

    Returns:
        Resolved path to the project root directory.
    """
    if root := os.environ.get("CADE_PROJECT_ROOT"):
        return pathlib.Path(root).resolve()
    return pathlib.Path.cwd().resolve()


def reset_config() -> None:
    """Clear cached configuration.

    Call this when:
    - The working directory has changed
    - CADE_PROJECT_ROOT environment variable has changed
    - During testing to ensure isolation
    """
    get_project_root.cache_clear()


# Default ignore patterns for file listings and searches
DEFAULT_IGNORE_PATTERNS: list[str] = [
    ".git",
    "__pycache__",
    "node_modules",
    ".venv",
    "venv",
    ".mypy_cache",
    ".pytest_cache",
    "*.pyc",
    ".DS_Store",
    "*.egg-info",
    "dist",
    "build",
    ".tox",
    ".coverage",
    "htmlcov",
    ".idea",
    ".vscode",
    ".cursor",
    ".claude",
]

# File operation limits
MAX_LIST_DEPTH: int = 10
MAX_LIST_RESULTS: int = 1000
MAX_PREVIEW_BYTES: int = 100_000
DEFAULT_TIMEOUT: int = 60
