from dataclasses import dataclass
from typing import Optional


@dataclass
class Project:
    id: Optional[int]
    project_name: str = ""
    fatigue_rate: float = 1.0
    fatigue_total: int = 156
    project_status: int = 0
