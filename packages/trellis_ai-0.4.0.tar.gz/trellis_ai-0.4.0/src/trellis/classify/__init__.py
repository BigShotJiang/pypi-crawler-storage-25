"""Classification layer for Trellis."""
