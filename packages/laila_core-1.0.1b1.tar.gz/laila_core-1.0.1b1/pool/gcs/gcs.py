"""Google Cloud Storage pool implementation."""
from __future__ import annotations

from typing import Optional, Any, Iterable, Iterator
from pydantic import Field, PrivateAttr
from urllib.parse import quote, unquote
import json

from ..schema.base import _LAILA_IDENTIFIABLE_POOL
from ...entry.compdata.transformation import TransformationSequence
from ...entry import transformation_base64

try:
    from google.cloud import storage
    from google.oauth2 import service_account
    from google.api_core.exceptions import NotFound
except ImportError:
    storage = None  # type: ignore
    service_account = None  # type: ignore
    NotFound = Exception  # type: ignore


class GCSPool(_LAILA_IDENTIFIABLE_POOL):
    """Google Cloud Storage-backed pool.

    Entries are stored as JSON objects in a GCS bucket.  Authentication
    can use explicit service-account info or Application Default Credentials.
    """

    service_account_info: Optional[dict[str, Any]] = Field(default=None)
    project_id: Optional[str] = Field(default=None)
    bucket_name: str = Field(...)
    transformations: Optional[TransformationSequence] = Field(default=transformation_base64)

    _client: Any = PrivateAttr(default=None)
    _bucket: Any = PrivateAttr(default=None)

    class Config:
        arbitrary_types_allowed = True

    def _get_client(self):
        """Return the GCS ``storage.Client``, creating it on first call."""
        if self._client is not None:
            return self._client
        if storage is None or service_account is None:
            raise ImportError("google-cloud-storage is required for GCSPool")

        kwargs: dict[str, Any] = {}
        if self.service_account_info is not None:
            credentials = service_account.Credentials.from_service_account_info(
                self.service_account_info
            )
            kwargs["credentials"] = credentials
            if self.project_id is None:
                self.project_id = self.service_account_info.get("project_id")

        if self.project_id is not None:
            kwargs["project"] = self.project_id

        self._client = storage.Client(**kwargs)
        return self._client

    def _get_bucket(self):
        """Return the GCS bucket handle."""
        if self._bucket is None:
            self._bucket = self._get_client().bucket(self.bucket_name)
        return self._bucket

    def _object_key(self, key: str) -> str:
        """URL-encode a logical key for GCS."""
        return quote(key, safe="")

    def _logical_key(self, object_key: str) -> str:
        """Decode a GCS object name back to the logical key."""
        return unquote(object_key)

    def close(self) -> None:
        """Release client references."""
        self._client = None
        self._bucket = None

    def _read(self, key: str) -> Optional[Any]:
        """Retrieve the JSON value for *key*, or ``None`` if absent."""
        with self.atomic():
            blob = self._get_bucket().blob(self._object_key(key))
            try:
                raw = blob.download_as_text()
            except NotFound:
                return None
        return json.loads(raw)

    def _write(self, key: str, entry: Any) -> None:
        """Store *entry* as a JSON blob under *key*."""
        value = entry
        if isinstance(value, dict):
            value = json.dumps(value)
        if not isinstance(value, str):
            raise TypeError("GCSPool expects a serialized JSON string.")

        with self.atomic():
            blob = self._get_bucket().blob(self._object_key(key))
            blob.upload_from_string(value, content_type="application/json")

    def _delete(self, key: str) -> None:
        """Delete the blob for *key*; no-op if absent."""
        with self.atomic():
            blob = self._get_bucket().blob(self._object_key(key))
            try:
                blob.delete()
            except NotFound:
                return

    def _empty(self) -> None:
        """Remove all blobs from the bucket."""
        with self.atomic():
            blobs = list(self._get_client().list_blobs(self.bucket_name))
            for blob in blobs:
                blob.delete()

    def _exists(self, key: str) -> bool:
        """Return ``True`` if a blob for *key* exists."""
        with self.atomic():
            blob = self._get_bucket().blob(self._object_key(key))
            return bool(blob.exists(self._get_client()))

    def __contains__(self, key: str) -> bool:
        """Check membership, delegates to :meth:`_exists`."""
        return self._exists(key)

    def _keys(self, as_generator: bool = False) -> Iterable[str]:
        """Return all keys in the bucket.

        Parameters
        ----------
        as_generator : bool, optional
            If ``True``, return a lazy iterator instead of a list.

        Returns
        -------
        Iterable[str]
            Pool keys.
        """
        def _iter_keys() -> Iterator[str]:
            for blob in self._get_client().list_blobs(self.bucket_name):
                yield self._logical_key(blob.name)

        if not as_generator:
            with self.atomic():
                return list(_iter_keys())
        return _iter_keys()
