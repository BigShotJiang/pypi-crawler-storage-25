"""Communication schema package."""
