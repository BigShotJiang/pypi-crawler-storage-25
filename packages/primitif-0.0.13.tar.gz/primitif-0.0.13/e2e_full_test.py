"""Full E2E test suite for Primitif — Mail + Approval.

Uses the new simplified SDK import path throughout.
"""

import os
import time
import sys

TOKEN = os.environ.get("PRIMITIF_API_KEY", "ns_live_64fb2389789b7e7569436085b7e34ebe")
os.environ["PRIMITIF_API_KEY"] = TOKEN

from primitif import mail, approval, Mailbox
from primitif.approval import require_approval

# Reset cached clients so they use the current PRIMITIF_API_KEY
mail._admin = None
approval._admin = None

passed = 0
failed = 0
total = 0


def test(name):
    global total
    total += 1
    print(f"\n{'='*60}")
    print(f"  TEST {total}: {name}")
    print(f"{'='*60}")


def ok(msg=""):
    global passed
    passed += 1
    print(f"  ✓ PASS {msg}")


def fail(msg):
    global failed
    failed += 1
    print(f"  ✗ FAIL {msg}")


# ── MAIL TESTS ──

mb = None
mb_info = None

test("Create mailbox")
try:
    mb = mail.create_mailbox(name=f"e2e-{int(time.time())}", ttl=600)
    assert mb.address.endswith("@mail.primitif.ai") or "@" in mb.address, f"Bad address: {mb.address}"
    mb_info = mb.info()
    assert mb_info.id.startswith("mb_"), f"Bad id: {mb_info.id}"
    assert mb.token, "No token returned"
    ok(f"address={mb.address}, id={mb_info.id}")
except Exception as e:
    fail(str(e))

test("Reconnect with token")
try:
    mb2 = Mailbox(token=mb.token)
    info2 = mb2.info()
    assert info2.id == mb_info.id, "Token reconnect returned different mailbox"
    mb2.close()
    ok(f"reconnected to {info2.address}")
except Exception as e:
    fail(str(e))

test("List mailboxes")
try:
    mailboxes = mail.list_mailboxes()
    ids = [m.id for m in mailboxes]
    assert mb_info.id in ids, f"Mailbox {mb_info.id} not in list"
    ok(f"found {len(mailboxes)} mailbox(es)")
except Exception as e:
    fail(str(e))

test("Account info")
try:
    acct = mail.account()
    assert acct.plan, "No plan"
    ok(f"plan={acct.plan}, mailboxes={acct.mailbox_count}")
except Exception as e:
    fail(str(e))

test("Send email (positional args)")
try:
    result = mb.send("test@example.com", "E2E test email", "Hello from E2E test")
    assert result.message_id, "No message_id"
    assert result.thread_id, "No thread_id"
    ok(f"message_id={result.message_id}, thread_id={result.thread_id}")
except Exception as e:
    fail(str(e))

test("Send self-email")
try:
    self_result = mb.send(mb.address, "Self-test", "Testing inbox receipt")
    ok(f"sent to self: message_id={self_result.message_id}")
except Exception as e:
    fail(str(e))

test("Wait and check inbox")
messages = []
try:
    time.sleep(5)
    inbox = mb.inbox()
    messages = inbox.items
    if len(messages) == 0:
        time.sleep(10)
        inbox = mb.inbox()
        messages = inbox.items
    ok(f"inbox has {len(messages)} message(s)")
except Exception as e:
    fail(str(e))

test("Read message (accepts object)")
try:
    if messages:
        detail = mb.read(messages[0])
        assert detail.subject, "No subject"
        assert detail.body_text is not None, "No body_text"
        ok(f"subject='{detail.subject}', from={detail.from_address}")
    else:
        ok("skipped — no inbound messages yet")
except Exception as e:
    fail(str(e))

test("Reply (accepts object)")
try:
    if messages:
        reply_result = mb.reply(messages[0], "E2E reply test")
        assert reply_result.message_id, "No reply message_id"
        ok(f"replied: message_id={reply_result.message_id}")
    else:
        ok("skipped — no messages to reply to")
except Exception as e:
    fail(str(e))

test("Threads with participants")
try:
    thread_list = mb.threads()
    ok(f"found {len(thread_list.items)} threads")
    if thread_list.items:
        t = thread_list.items[0]
        assert hasattr(t, "participants"), "No participants field"
        detail = mb.thread(t)  # accepts ThreadSummary object
        assert hasattr(detail, "messages"), "No messages in thread detail"
        ok(f"thread '{t.subject}': {t.message_count} msgs, participants={t.participants}")
except Exception as e:
    fail(str(e))

test("Attachments")
try:
    if messages:
        atts = mb.list_attachments(messages[0])
        ok(f"found {len(atts)} attachment(s)")
        if atts:
            assert atts[0].message_id, "No message_id on AttachmentInfo"
            data = mb.download(atts[0])
            assert len(data) > 0, "Empty attachment"
            ok(f"downloaded {atts[0].filename} ({len(data)} bytes)")
    else:
        ok("skipped — no messages")
except Exception as e:
    fail(str(e))

test("Allowlist")
try:
    entries = mb.get_allowlist()
    ok(f"current allowlist: {len(entries)} entries")

    entry = mb.add_allowlist("e2e-test@example.com")
    assert entry.sender_address == "e2e-test@example.com"
    ok(f"added: {entry.sender_address}")

    mb.remove_allowlist(entry.id)
    ok("removed allowlist entry")
except Exception as e:
    fail(str(e))

test("Wildcard allowlist")
try:
    wildcard = mb.add_allowlist("*")
    assert wildcard.sender_address == "*"
    ok("added wildcard")

    mb.remove_allowlist(wildcard.id)
    ok("removed wildcard")
except Exception as e:
    fail(str(e))

test("Protected recipients")
try:
    recipients = mail.list_protected_recipients()
    ok(f"current protected: {len(recipients)} entries")

    # Use a unique pattern to avoid conflicts from previous runs
    pattern = f"e2e-{int(time.time())}@example.com"
    pr = mail.add_protected_recipient(pattern)
    assert pr.pattern == pattern
    ok(f"added: {pr.pattern}")
except Exception as e:
    fail(str(e))

test("Webhooks")
try:
    wh = mb.set_webhook("https://example.com/e2e-hook")
    assert wh.secret, "No webhook secret"
    ok(f"set webhook, secret={wh.secret[:12]}...")

    wh_info = mb.webhook()
    assert wh_info.url == "https://example.com/e2e-hook"
    ok(f"verified webhook url={wh_info.url}")

    mb.delete_webhook()
    ok("deleted webhook")
except Exception as e:
    fail(str(e))

# ── APPROVAL TESTS ──

test("Create approval request (module-level)")
req = None
try:
    req = approval.create_request(
        "E2E test action",
        context={"test_run": "full_suite", "timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ")},
    )
    assert req.id, "No request ID"
    assert req.status == "pending", f"Expected pending, got {req.status}"
    assert req.approval_url, "No approval URL"
    ok(f"id={req.id}, status={req.status}")
except Exception as e:
    fail(str(e))

test("Get approval request (module-level)")
try:
    if req:
        fetched = approval.get_request(req.id)
        assert fetched.id == req.id
        assert fetched.status == "pending"
        ok(f"status={fetched.status}")
    else:
        fail("skipped — no request created")
except Exception as e:
    fail(str(e))

test("List approval requests (module-level)")
try:
    reqs = approval.list_requests()
    if req:
        ids = [r.id for r in reqs]
        assert req.id in ids, f"Request {req.id} not in list"
    ok(f"found {len(reqs)} requests")
except Exception as e:
    fail(str(e))

test("@require_approval decorator + registry")
try:
    @require_approval
    def e2e_test_action(user_id, reason):
        return f"executed: {user_id} - {reason}"

    decorator_req = e2e_test_action(user_id="usr_123", reason="E2E test")
    assert decorator_req.status == "pending"
    assert decorator_req.approval_url
    ok(f"decorator: id={decorator_req.id}, status={decorator_req.status}")

    # Verify it's in the registry
    from primitif.approval import _registry
    assert "E2e test action" in _registry, f"Not in registry: {list(_registry.keys())}"
    ok(f"registered in _registry as 'E2e test action'")
except Exception as e:
    fail(str(e))

# ── CLEANUP ──

test("Delete mailbox")
try:
    mb.delete()
    ok("mailbox deleted")
except Exception as e:
    fail(str(e))

test("Verify mailbox deleted")
try:
    remaining = mail.list_mailboxes()
    ids = [m.id for m in remaining]
    assert mb_info.id not in ids, "Mailbox still exists after delete"
    ok("confirmed deleted")
except Exception as e:
    fail(str(e))

# ── SUMMARY ──

print(f"\n{'='*60}")
print(f"  RESULTS: {passed}/{total} passed, {failed} failed")
print(f"{'='*60}")

if failed > 0:
    sys.exit(1)
