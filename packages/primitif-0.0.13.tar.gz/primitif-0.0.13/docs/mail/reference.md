# Mail API Reference

## Module functions

::: primitif.mail.create_mailbox
::: primitif.mail.list_mailboxes
::: primitif.mail.delete_mailbox
::: primitif.mail.account
::: primitif.mail.add_protected_recipient
::: primitif.mail.list_protected_recipients

## Mailbox

::: primitif.mail.client.Mailbox
    options:
      members:
        - send
        - reply
        - inbox
        - read
        - threads
        - thread
        - list_attachments
        - download
        - download_attachment
        - get_allowlist
        - add_allowlist
        - remove_allowlist
        - set_webhook
        - webhook
        - delete_webhook
        - info
        - address
        - token
        - delete
        - close

## Models

::: primitif.mail.models.InboxMessage
::: primitif.mail.models.MessageDetail
::: primitif.mail.models.SendResult
::: primitif.mail.models.ThreadSummary
::: primitif.mail.models.ThreadDetail
::: primitif.mail.models.AttachmentInfo
::: primitif.mail.models.MailboxInfo
::: primitif.mail.models.MailboxListItem
::: primitif.mail.models.AllowlistEntry
::: primitif.mail.models.WebhookCreated
::: primitif.mail.models.WebhookInfo
::: primitif.mail.models.ProtectedRecipient
::: primitif.mail.models.AccountInfo
