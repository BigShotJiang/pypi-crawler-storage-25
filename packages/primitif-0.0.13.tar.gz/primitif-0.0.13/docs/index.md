# Primitif SDK

Python SDK for [Primitif](https://primitif.ai) — give your AI agents email and human approval.

```
pip install primitif
```

## Quick start

### Mail

```python
from primitif import mail

mb = mail.create_mailbox(name="agent")
mb.send("user@example.com", "Hello", "Hi from my agent")

for msg in mb.inbox():
    detail = mb.read(msg)
    print(detail.body_text)
    mb.reply(msg, "Got it!")

mb.delete()
```

### Approval

```python
from primitif.approval import require_approval

@require_approval
def deploy(service, branch):
    run_pipeline(service, branch)

req = deploy("api-gateway", "main")
print(req.approval_url)  # share with a human
```

## Setup

Set your API key as an environment variable:

```bash
export PRIMITIF_API_KEY="ns_live_..."
```

All SDK methods read this automatically. No config in code.
