# Error Handling

All errors inherit from `PrimitifError`, so you can catch broadly or narrowly.

```python
from primitif import PrimitifError, AuthError, NetworkError
from primitif.mail import MailRateLimitError

try:
    mb.send("user@test.com", "Hi", "Hello")
except MailRateLimitError as e:
    print(f"Slow down — retry after {e.retry_after}s")
except NetworkError:
    print("Network issue — timeout or DNS failure")
except AuthError:
    print("Bad credentials")
except PrimitifError:
    print("Something went wrong")
```

## Hierarchy

```
PrimitifError
├── AuthError          # 401 — invalid API key or token
├── NotFoundError      # 404 — resource doesn't exist
├── ConflictError      # 409 — duplicate resource
├── ValidationError    # 422 — invalid input
├── RateLimitError     # 429 — too many requests
├── ServerError        # 5xx — server error
├── NetworkError       # connection failure
└── InvalidSignature   # webhook signature mismatch
```

Product-specific exceptions (e.g. `MailAuthError`, `ApprovalNotFoundError`) inherit from both the product base and the generic error, so you can catch at either level.

## Reference

::: primitif._exceptions.PrimitifError
::: primitif._exceptions.AuthError
::: primitif._exceptions.NotFoundError
::: primitif._exceptions.ConflictError
::: primitif._exceptions.ValidationError
::: primitif._exceptions.RateLimitError
::: primitif._exceptions.ServerError
::: primitif._exceptions.NetworkError
::: primitif._exceptions.InvalidSignature
