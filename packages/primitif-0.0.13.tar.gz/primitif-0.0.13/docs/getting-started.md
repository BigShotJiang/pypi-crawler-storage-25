# Getting Started

## Install

```
pip install primitif
```

## Set your API key

```bash
export PRIMITIF_API_KEY="ns_live_..."
```

Get your key from [dash.primitif.ai](https://dash.primitif.ai) under Settings.

## Send your first email

```python
from primitif import mail

mb = mail.create_mailbox()
mb.send("you@example.com", "Hello", "Sent from my agent!")
print(f"Sent from {mb.address}")
mb.delete()
```

## Gate a function behind approval

```python
from primitif.approval import require_approval

@require_approval
def send_invoice(client, amount):
    billing.send(client, amount)

req = send_invoice("Acme", 45000)
print(req.approval_url)  # human reviews here
```

## Reconnect to a mailbox

Save the token for crash recovery:

```python
mb = mail.create_mailbox(name="agent")
save_to_db(mb.token)

# Later:
from primitif import Mailbox
mb = Mailbox(token=load_from_db())
```

## MCP Server

Add to `~/.claude.json`:

```json
{
  "mcpServers": {
    "primitif": {
      "type": "http",
      "url": "https://mcp.primitif.ai/mcp",
      "headers": {
        "Authorization": "Bearer ns_live_..."
      }
    }
  }
}
```
