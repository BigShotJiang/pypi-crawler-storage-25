# Approval API Reference

## Module functions

::: primitif.approval.require_approval
::: primitif.approval.create_request
::: primitif.approval.get_request
::: primitif.approval.list_requests
::: primitif.approval.dispatch

## Models

::: primitif.approval.models.ApprovalRequest
