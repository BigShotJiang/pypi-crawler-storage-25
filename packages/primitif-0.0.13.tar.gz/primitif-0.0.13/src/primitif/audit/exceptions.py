"""Audit-specific exceptions with diamond inheritance."""

from primitif._exceptions import (
    AuthError,
    NetworkError,
    NotFoundError,
    PrimitifError,
    RateLimitError,
    ServerError,
    ValidationError,
)


class AuditError(PrimitifError):
    """Base exception for all Audit errors."""


class AuditAuthError(AuditError, AuthError):
    """401 — invalid or missing audit credentials."""


class AuditNotFoundError(AuditError, NotFoundError):
    """404 — audit resource not found."""


class AuditValidationError(AuditError, ValidationError):
    """422 — invalid audit request payload."""


class AuditRateLimitError(AuditError, RateLimitError):
    """429 — audit rate limit exceeded."""


class AuditServerError(AuditError, ServerError):
    """5xx — audit server error."""


class AuditNetworkError(AuditError, NetworkError):
    """Network-level failure during an audit request."""
