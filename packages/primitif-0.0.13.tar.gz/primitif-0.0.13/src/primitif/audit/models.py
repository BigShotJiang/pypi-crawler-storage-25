"""Audit SDK response types."""

from __future__ import annotations

from datetime import datetime
from typing import Any

from pydantic import BaseModel


class AuditEvent(BaseModel):
    id: str
    org_id: str
    namespace_id: str | None = None
    action: str | None = None
    resource_type: str | None = None
    resource_id: str | None = None
    source: str = "primitif"
    product: str | None = None
    status: str = "ok"
    duration_ms: int | None = None
    error: str | None = None
    metadata: dict[str, Any] | None = None
    request_id: str | None = None
    created_at: datetime
