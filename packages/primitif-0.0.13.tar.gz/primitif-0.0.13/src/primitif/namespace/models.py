"""Namespace SDK response types."""

from __future__ import annotations

from datetime import datetime

from pydantic import BaseModel


class Namespace(BaseModel):
    id: str
    name: str
    is_default: bool
    created_at: datetime


class NamespaceWithToken(BaseModel):
    id: str
    name: str
    is_default: bool
    token: str
    created_at: datetime
