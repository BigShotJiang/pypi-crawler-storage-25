"""Primitif Python SDK — Mail and Approval APIs for AI agents.

Quick start::

    from primitif import mail

    mb = mail.create_mailbox(name="agent")
    mb.send(to="user@example.com", subject="Hi", body_text="Hello")

    from primitif import approval

    req = approval.create_request("Send contract", context={"client": "Acme"})

For the decorator pattern::

    from primitif.approval import require_approval

    @require_approval
    def deploy(service, branch):
        run_pipeline(service, branch)
"""

from primitif import approval, mail
from primitif._exceptions import (
    AuthError,
    ConflictError,
    InvalidSignature,
    NetworkError,
    NotFoundError,
    PrimitifError,
    RateLimitError,
    ServerError,
    ValidationError,
)
from primitif._models import PaginatedList
from primitif._version import __version__
from primitif._webhook import verify_webhook
from primitif.approval import require_approval
from primitif.client import Primitif
from primitif.mail.client import Mailbox

__all__ = [
    "__version__",
    # Product modules — the primary API
    "mail",
    "approval",
    # Classes
    "Primitif",
    "Mailbox",
    # Utilities
    "PaginatedList",
    "verify_webhook",
    "require_approval",
    # Exceptions
    "PrimitifError",
    "AuthError",
    "NotFoundError",
    "ConflictError",
    "ValidationError",
    "RateLimitError",
    "ServerError",
    "NetworkError",
    "InvalidSignature",
]
