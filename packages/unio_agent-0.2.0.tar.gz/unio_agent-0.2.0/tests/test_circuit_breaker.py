"""Tests for circuit breaker state machine."""
from unio.circuit_breaker import CircuitBreaker, State


class TestCircuitBreakerStates:
    def test_starts_closed(self):
        cb = CircuitBreaker()
        assert not cb.is_open("svc")

    def test_three_failures_opens_circuit(self):
        cb = CircuitBreaker(failure_threshold=3)
        cb.record_failure("svc")
        cb.record_failure("svc")
        cb.record_failure("svc")
        assert cb.is_open("svc")

    def test_success_resets_to_closed(self):
        cb = CircuitBreaker(failure_threshold=3)
        for _ in range(3):
            cb.record_failure("svc")
        cb.record_success("svc")
        assert not cb.is_open("svc")

    def test_half_open_after_timeout(self):
        cb = CircuitBreaker(failure_threshold=3, recovery_timeout=0.0)
        for _ in range(3):
            cb.record_failure("svc")
        # With 0 timeout, should transition to HALF_OPEN on next check
        assert not cb.is_open("svc")  # now HALF_OPEN, not OPEN

    def test_half_open_failure_reopens(self):
        import time
        cb = CircuitBreaker(failure_threshold=3, recovery_timeout=0.05)
        for _ in range(3):
            cb.record_failure("svc")
        # Wait for recovery timeout to transition to HALF_OPEN
        time.sleep(0.06)
        assert not cb.is_open("svc")  # HALF_OPEN now
        cb.record_failure("svc")
        # Should be OPEN again (with fresh timer)
        assert cb.is_open("svc")

    def test_half_open_success_closes(self):
        cb = CircuitBreaker(failure_threshold=3, recovery_timeout=0.0)
        for _ in range(3):
            cb.record_failure("svc")
        # Now HALF_OPEN
        cb.record_success("svc")
        assert not cb.is_open("svc")

    def test_independent_per_service(self):
        cb = CircuitBreaker(failure_threshold=3)
        for _ in range(3):
            cb.record_failure("svc_a")
        assert cb.is_open("svc_a")
        assert not cb.is_open("svc_b")
