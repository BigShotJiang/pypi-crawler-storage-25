"""Tests for UnioAgent — init, find, onboard, call."""
import pytest
from unittest.mock import AsyncMock, MagicMock, patch
from nacl.signing import SigningKey

from unio.agent import (
    UnioAgent, ServiceResult,
    InsufficientTrustError, InsufficientReputationError,
    CircuitOpenError, UnioCallError,
)
from unio.circuit_breaker import CircuitBreaker


def _make_agent(trust_level=0, reputation_score=50) -> UnioAgent:
    sk = SigningKey.generate()
    pub_b64 = __import__("base64").b64encode(sk.verify_key.encode()).decode()
    return UnioAgent(
        agent_id="ag_test",
        signing_key=sk,
        public_key_b64=pub_b64,
        unio_token="test-jwt-token",
        trust_level=trust_level,
        reputation_score=reputation_score,
        contact_email="test@test.com",
        unio_api_base="https://api.test.unio",
    )


class TestAgentInit:
    @patch("unio.agent.get_identity")
    @patch("unio.agent.save_identity")
    @patch("unio.agent.httpx.AsyncClient")
    async def test_registers_new_agent(self, mock_client_cls, mock_save, mock_get):
        """When no identity in keychain, generates keypair and registers."""
        mock_get.return_value = None
        mock_client = AsyncMock()
        mock_client.post.return_value = MagicMock(
            status_code=200,
            json=lambda: {"agent_id": "ag_new", "unio_token": "new-token", "trust_level": 0, "reputation_score": 50},
            raise_for_status=lambda: None,
        )
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=False)
        mock_client_cls.return_value = mock_client

        agent = await UnioAgent.init(agent_name="test", contact_email="t@t.com", unio_api_base="https://api.test.unio")
        assert agent.agent_id == "ag_new"
        mock_save.assert_called_once()

    @patch("unio.agent.get_identity")
    async def test_loads_existing_identity(self, mock_get):
        """When identity exists in keychain, loads it without registering."""
        sk = SigningKey.generate()
        import base64
        sk_b64 = base64.b64encode(sk.encode()).decode()
        pub_b64 = base64.b64encode(sk.verify_key.encode()).decode()
        mock_get.return_value = {
            "agent_id": "ag_existing",
            "private_key_b64": sk_b64,
            "public_key_b64": pub_b64,
            "unio_token": "existing-token",
            "trust_level": 1,
            "reputation_score": 70,
        }
        agent = await UnioAgent.init(contact_email="t@t.com", unio_api_base="https://api.test.unio")
        assert agent.agent_id == "ag_existing"
        assert agent.trust_level == 1


class TestAgentFind:
    @patch.object(UnioAgent, "_get_manifest", new_callable=AsyncMock)
    async def test_filters_by_trust_level(self, mock_manifest):
        """find() only returns services where min_trust <= agent.trust_level."""
        agent = _make_agent(trust_level=0)
        # Mock registry search
        agent._registry = MagicMock()
        agent._registry.search = AsyncMock(return_value=[
            {"service_id": "svc_low", "name": "Low Trust", "description": "", "category": "", "tags": [], "trust_score": 0, "unio_verified": False},
            {"service_id": "svc_high", "name": "High Trust", "description": "", "category": "", "tags": [], "trust_score": 0, "unio_verified": False},
        ])
        agent._registry.get_service = AsyncMock(side_effect=[
            {"service_id": "svc_low", "manifest_snapshot": {"security": {"min_trust_level_required": 0}}},
            {"service_id": "svc_high", "manifest_snapshot": {"security": {"min_trust_level_required": 1}}},
        ])

        results = await agent.find("email")
        ids = [r.service_id for r in results]
        assert "svc_low" in ids
        assert "svc_high" not in ids


class TestAgentOnboard:
    async def test_raises_insufficient_trust(self):
        agent = _make_agent(trust_level=0)
        agent._manifest_cache["svc"] = {
            "security": {"min_trust_level_required": 1, "reputation_threshold": 0},
            "agent_onboarding": {"signup_endpoint": "https://api.svc.com/unio/signup"},
        }
        with patch("unio.agent.get_credential", return_value=None):
            with pytest.raises(InsufficientTrustError):
                await agent.onboard("svc")

    async def test_raises_insufficient_reputation(self):
        agent = _make_agent(trust_level=3, reputation_score=10)
        agent._manifest_cache["svc"] = {
            "security": {"min_trust_level_required": 0, "reputation_threshold": 30},
            "agent_onboarding": {"signup_endpoint": "https://api.svc.com/unio/signup"},
        }
        with patch("unio.agent.get_credential", return_value=None):
            with pytest.raises(InsufficientReputationError):
                await agent.onboard("svc")

    @patch("unio.agent.save_credential")
    @patch("unio.agent.get_credential", return_value=None)
    @patch("unio.agent.httpx.AsyncClient")
    async def test_successful_onboard(self, mock_client_cls, mock_get_cred, mock_save_cred):
        agent = _make_agent(trust_level=0, reputation_score=50)
        agent._manifest_cache["svc"] = {
            "security": {"min_trust_level_required": 0, "reputation_threshold": 0},
            "agent_onboarding": {"signup_endpoint": "https://api.svc.com/unio/signup"},
        }
        mock_client = AsyncMock()
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.return_value = {"credential": "svc-api-key", "credential_type": "api_key"}
        mock_resp.raise_for_status = MagicMock()
        mock_client.post.return_value = mock_resp
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=False)
        mock_client_cls.return_value = mock_client

        cred = await agent.onboard("svc")
        assert cred == "svc-api-key"
        mock_save_cred.assert_called_once()

    @patch("unio.agent.get_credential", return_value="cached-key")
    async def test_returns_cached_credential(self, mock_get_cred):
        agent = _make_agent()
        cred = await agent.onboard("svc")
        assert cred == "cached-key"


class TestCircuitBreaker:
    def test_transitions_to_open(self):
        cb = CircuitBreaker(failure_threshold=3, recovery_timeout=60)
        for _ in range(3):
            cb.record_failure("svc")
        assert cb.is_open("svc")

    def test_stays_closed_below_threshold(self):
        cb = CircuitBreaker(failure_threshold=3)
        cb.record_failure("svc")
        cb.record_failure("svc")
        assert not cb.is_open("svc")

    def test_resets_on_success(self):
        cb = CircuitBreaker(failure_threshold=3)
        cb.record_failure("svc")
        cb.record_failure("svc")
        cb.record_success("svc")
        assert not cb.is_open("svc")
