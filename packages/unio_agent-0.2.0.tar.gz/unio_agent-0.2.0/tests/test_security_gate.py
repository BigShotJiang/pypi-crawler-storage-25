"""Tests for trust_level security gates in agent onboard flow."""
import pytest
from unittest.mock import patch, AsyncMock, MagicMock
from nacl.signing import SigningKey

from unio.agent import UnioAgent, InsufficientTrustError, InsufficientReputationError


def _make_agent(trust_level=0, reputation_score=50) -> UnioAgent:
    sk = SigningKey.generate()
    import base64
    pub_b64 = base64.b64encode(sk.verify_key.encode()).decode()
    return UnioAgent(
        agent_id="ag_test",
        signing_key=sk,
        public_key_b64=pub_b64,
        unio_token="test-jwt-token",
        trust_level=trust_level,
        reputation_score=reputation_score,
        contact_email="test@test.com",
        unio_api_base="https://api.test.unio",
    )


class TestTrustLevelGate:
    async def test_trust_0_cannot_onboard_trust_1_service(self):
        agent = _make_agent(trust_level=0)
        agent._manifest_cache["restricted-svc"] = {
            "security": {"min_trust_level_required": 1, "reputation_threshold": 0},
            "agent_onboarding": {"signup_endpoint": "https://api.svc.com/unio/signup"},
        }
        with patch("unio.agent.get_credential", return_value=None):
            with pytest.raises(InsufficientTrustError) as exc_info:
                await agent.onboard("restricted-svc")
            assert "0" in str(exc_info.value) and "1" in str(exc_info.value)

    async def test_trust_1_can_onboard_trust_1_service(self):
        agent = _make_agent(trust_level=1)
        agent._manifest_cache["restricted-svc"] = {
            "security": {"min_trust_level_required": 1, "reputation_threshold": 0},
            "agent_onboarding": {"signup_endpoint": "https://api.svc.com/unio/signup"},
        }
        with patch("unio.agent.get_credential", return_value=None), \
             patch("unio.agent.httpx.AsyncClient") as mock_client_cls:
            mock_client = AsyncMock()
            mock_resp = MagicMock()
            mock_resp.json.return_value = {"credential": "key"}
            mock_resp.raise_for_status = MagicMock()
            mock_client.post.return_value = mock_resp
            mock_client.__aenter__ = AsyncMock(return_value=mock_client)
            mock_client.__aexit__ = AsyncMock(return_value=False)
            mock_client_cls.return_value = mock_client
            cred = await agent.onboard("restricted-svc")
            assert cred == "key"

    async def test_reputation_below_threshold(self):
        agent = _make_agent(trust_level=3, reputation_score=20)
        agent._manifest_cache["svc"] = {
            "security": {"min_trust_level_required": 0, "reputation_threshold": 50},
            "agent_onboarding": {"signup_endpoint": "https://api.svc.com/unio/signup"},
        }
        with patch("unio.agent.get_credential", return_value=None):
            with pytest.raises(InsufficientReputationError):
                await agent.onboard("svc")
