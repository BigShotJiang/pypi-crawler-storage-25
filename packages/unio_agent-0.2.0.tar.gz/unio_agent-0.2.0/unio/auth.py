"""Ed25519 keypair operations for agent identity."""
from __future__ import annotations

import base64

from nacl.signing import SigningKey, VerifyKey


def generate_keypair() -> tuple[SigningKey, str]:
    """Generate an Ed25519 keypair. Returns (signing_key, public_key_b64)."""
    sk = SigningKey.generate()
    pub_b64 = base64.b64encode(sk.verify_key.encode()).decode()
    return sk, pub_b64


def sign_message(signing_key: SigningKey, message: bytes) -> str:
    """Sign a message with the signing key. Returns base64-encoded signature."""
    signed = signing_key.sign(message)
    return base64.b64encode(signed.signature).decode()


def verify_public_key(public_key_b64: str) -> bool:
    """Validate that a base64 string is a valid Ed25519 public key."""
    try:
        key_bytes = base64.b64decode(public_key_b64)
        VerifyKey(key_bytes)
        return True
    except Exception:
        return False


def private_key_to_b64(signing_key: SigningKey) -> str:
    """Encode a signing key to base64 for storage."""
    return base64.b64encode(signing_key.encode()).decode()


def b64_to_private_key(b64: str) -> SigningKey:
    """Decode a base64 signing key from storage."""
    return SigningKey(base64.b64decode(b64))
