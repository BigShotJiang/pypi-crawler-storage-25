"""Token bucket throttle — reads manifest limits, self-throttles."""
from __future__ import annotations

import asyncio
import time


class Throttle:
    """Per-service token bucket rate limiter."""

    def __init__(self) -> None:
        self._buckets: dict[str, tuple[float, float, float]] = {}  # (tokens, max, last_refill)

    def _ensure_bucket(self, service_id: str, rpm: int) -> None:
        if service_id not in self._buckets:
            self._buckets[service_id] = (float(rpm), float(rpm), time.monotonic())

    async def acquire(self, service_id: str, rpm: int) -> None:
        """Wait until a token is available for the given service."""
        self._ensure_bucket(service_id, rpm)
        tokens, max_tokens, last_refill = self._buckets[service_id]

        # Refill tokens based on elapsed time
        now = time.monotonic()
        elapsed = now - last_refill
        refill = elapsed * (max_tokens / 60.0)  # tokens per second
        tokens = min(max_tokens, tokens + refill)

        if tokens >= 1.0:
            tokens -= 1.0
            self._buckets[service_id] = (tokens, max_tokens, now)
            return

        # Wait for next token
        wait_time = (1.0 - tokens) / (max_tokens / 60.0)
        await asyncio.sleep(wait_time)
        self._buckets[service_id] = (0.0, max_tokens, time.monotonic())
