"""UnioAgent — the main agent SDK class."""
from __future__ import annotations

import asyncio
import os
import json
import time
from dataclasses import dataclass, field
from typing import Any

import httpx
import jwt as pyjwt
from nacl.signing import SigningKey

from .auth import generate_keypair, sign_message, private_key_to_b64, b64_to_private_key
from .credentials import get_identity, save_identity, get_credential, save_credential
from .registry import RegistryClient
from .circuit_breaker import CircuitBreaker
from .throttle import Throttle
from .session_logger import log_session


class InsufficientTrustError(Exception):
    """Agent's trust level is below the service's minimum requirement."""
    pass


class InsufficientReputationError(Exception):
    """Agent's reputation score is below the service's threshold."""
    pass


class CircuitOpenError(Exception):
    """Circuit breaker is OPEN — calls to this service are blocked."""
    pass


class UnioCallError(Exception):
    """A call to a provider service failed."""
    pass


class UnioRefreshError(Exception):
    """Failed to refresh the agent's unio_token."""
    pass


@dataclass
class ServiceResult:
    """A ranked search result from the registry."""
    service_id: str
    name: str
    description: str
    category: str
    tags: list[str]
    trust_score: int
    unio_verified: bool
    min_trust_required: int
    manifest: dict[str, Any] = field(default_factory=dict)


class UnioAgent:
    """Unio Agent SDK — register, discover, onboard, and call services."""

    def __init__(
        self,
        agent_id: str,
        signing_key: SigningKey,
        public_key_b64: str,
        unio_token: str,
        trust_level: int,
        reputation_score: int,
        contact_email: str,
        unio_api_base: str | None = None,
    ) -> None:
        self.agent_id = agent_id
        self.signing_key = signing_key
        # Resolve in priority: explicit arg → UNIO_API_BASE env var → live API.
        # The live URL is the deployed AWS API Gateway endpoint; it will be
        # replaced with a custom domain once one is in place.
        unio_api_base = (
            unio_api_base
            or os.environ.get("UNIO_API_BASE")
            or "https://xza0g37re9.execute-api.ap-south-1.amazonaws.com/prod"
        )
        self.public_key_b64 = public_key_b64
        self.unio_token = unio_token
        self.trust_level = trust_level
        self.reputation_score = reputation_score
        self.contact_email = contact_email
        self.unio_api_base = unio_api_base

        self._registry = RegistryClient(base_url=unio_api_base)
        self._circuit = CircuitBreaker()
        self._throttle = Throttle()
        self._manifest_cache: dict[str, dict] = {}

    @classmethod
    async def init(
        cls,
        agent_name: str = "",
        contact_email: str = "",
        unio_api_base: str | None = None,
    ) -> UnioAgent:
        """Initialize an agent — load from keychain or register new."""
        # Same precedence as the constructor: explicit arg → env var → live.
        unio_api_base = (
            unio_api_base
            or os.environ.get("UNIO_API_BASE")
            or "https://xza0g37re9.execute-api.ap-south-1.amazonaws.com/prod"
        )
        identity = get_identity()

        if identity is not None:
            agent_id = identity["agent_id"]
            signing_key = b64_to_private_key(identity["private_key_b64"])
            public_key_b64 = identity["public_key_b64"]
            unio_token = identity["unio_token"]
            trust_level = identity.get("trust_level", 0)
            reputation_score = identity.get("reputation_score", 50)

            # Check JWT expiry — refresh if expiring within 7 days
            try:
                payload = pyjwt.decode(unio_token, options={"verify_signature": False})
                exp = payload.get("exp", 0)
                if exp - time.time() < 7 * 24 * 3600:
                    unio_token = await cls._refresh_token(unio_api_base, unio_token)
                    save_identity({
                        "agent_id": agent_id,
                        "private_key_b64": private_key_to_b64(signing_key),
                        "public_key_b64": public_key_b64,
                        "unio_token": unio_token,
                        "trust_level": trust_level,
                        "reputation_score": reputation_score,
                    })
            except Exception:
                pass  # If decode fails, keep using existing token

            return cls(
                agent_id=agent_id,
                signing_key=signing_key,
                public_key_b64=public_key_b64,
                unio_token=unio_token,
                trust_level=trust_level,
                reputation_score=reputation_score,
                contact_email=contact_email,
                unio_api_base=unio_api_base,
            )

        # Generate new keypair and register
        signing_key, public_key_b64 = generate_keypair()

        async with httpx.AsyncClient(timeout=10.0) as client:
            resp = await client.post(
                f"{unio_api_base}/v1/auth/agents/register",
                json={
                    "public_key_b64": public_key_b64,
                    "contact_email": contact_email,
                    "agent_name": agent_name,
                },
            )
            resp.raise_for_status()
            data = resp.json()

        agent_id = data["agent_id"]
        unio_token = data["unio_token"]
        trust_level = data.get("trust_level", 0)
        reputation_score = data.get("reputation_score", 50)

        save_identity({
            "agent_id": agent_id,
            "private_key_b64": private_key_to_b64(signing_key),
            "public_key_b64": public_key_b64,
            "unio_token": unio_token,
            "trust_level": trust_level,
            "reputation_score": reputation_score,
        })

        return cls(
            agent_id=agent_id,
            signing_key=signing_key,
            public_key_b64=public_key_b64,
            unio_token=unio_token,
            trust_level=trust_level,
            reputation_score=reputation_score,
            contact_email=contact_email,
            unio_api_base=unio_api_base,
        )

    @staticmethod
    async def _refresh_token(unio_api_base: str, current_token: str) -> str:
        """Refresh the unio_token by re-registering or calling verify."""
        async with httpx.AsyncClient(timeout=10.0) as client:
            resp = await client.post(
                f"{unio_api_base}/v1/auth/verify",
                json={"unio_token": current_token},
            )
            if resp.status_code == 200:
                data = resp.json()
                if data.get("valid"):
                    return current_token  # still valid
        # If verify fails, we need a new token — re-register
        raise UnioRefreshError("Token expired and refresh failed")

    async def find(self, intent: str, limit: int = 10) -> list[ServiceResult]:
        """Search the registry and filter by trust level."""
        results = await self._registry.search(intent, limit=limit)
        filtered = []
        for r in results:
            # Get full service details to check min_trust_level
            service = await self._registry.get_service(r.get("service_id", r.get("id", "")))
            if service is None:
                continue
            manifest = service.get("manifest_snapshot", {})
            security = manifest.get("security", {})
            min_trust = security.get("min_trust_level_required", 0)

            # Only return services the agent can access
            if min_trust <= self.trust_level:
                # Cache manifest for later use
                svc_id = service.get("service_id", service.get("id", ""))
                self._manifest_cache[svc_id] = manifest

                filtered.append(ServiceResult(
                    service_id=svc_id,
                    name=r.get("name", service.get("name", "")),
                    description=r.get("description", service.get("description", "")),
                    category=r.get("category", service.get("category", "")),
                    tags=r.get("tags", service.get("tags", [])),
                    trust_score=r.get("trust_score", service.get("trust_score", 0)),
                    unio_verified=r.get("unio_verified", service.get("unio_verified", False)),
                    min_trust_required=min_trust,
                    manifest=manifest,
                ))
        return filtered

    async def _get_manifest(self, service_id: str) -> dict:
        """Get manifest from cache or fetch from registry."""
        if service_id in self._manifest_cache:
            return self._manifest_cache[service_id]
        service = await self._registry.get_service(service_id)
        if service is None:
            raise UnioCallError(f"Service {service_id} not found")
        manifest = service.get("manifest_snapshot", {})
        self._manifest_cache[service_id] = manifest
        return manifest

    async def onboard(self, service_id: str) -> str:
        """Onboard to a provider — returns credential string."""
        # Check keychain for cached credential
        cached = get_credential(self.agent_id, service_id)
        if cached is not None:
            return cached

        manifest = await self._get_manifest(service_id)
        security = manifest.get("security", {})

        # Trust level gate
        min_trust = security.get("min_trust_level_required", 0)
        if self.trust_level < min_trust:
            raise InsufficientTrustError(
                f"Trust level {self.trust_level} < required {min_trust} for {service_id}"
            )

        # Reputation gate
        rep_threshold = security.get("reputation_threshold", 0)
        if self.reputation_score < rep_threshold:
            raise InsufficientReputationError(
                f"Reputation {self.reputation_score} < threshold {rep_threshold} for {service_id}"
            )

        # POST to provider's signup endpoint
        onboarding = manifest.get("agent_onboarding", {})
        signup_endpoint = onboarding.get("signup_endpoint", "")
        if not signup_endpoint:
            raise UnioCallError(f"No signup endpoint in manifest for {service_id}")

        body = {
            "agent_id": self.agent_id,
            "agent_public_key_b64": self.public_key_b64,
            "contact_email": self.contact_email,
            "trust_level": self.trust_level,
            "reputation_score": self.reputation_score,
        }

        body_json = json.dumps(body, sort_keys=True)
        signature = sign_message(self.signing_key, body_json.encode())

        async with httpx.AsyncClient(timeout=15.0) as client:
            resp = await client.post(
                signup_endpoint,
                json=body,
                headers={
                    "Authorization": f"Bearer {self.unio_token}",
                    "X-Unio-Signature": signature,
                    "Content-Type": "application/json",
                },
            )
            resp.raise_for_status()
            data = resp.json()

        credential = data.get("credential", "")
        if credential:
            save_credential(self.agent_id, service_id, credential)
        return credential

    async def call(
        self,
        service_id: str,
        capability_id: str,
        payload: dict[str, Any],
        fallback_service: str | None = None,
    ) -> dict[str, Any]:
        """Call a provider capability with circuit breaker, throttle, and session logging."""
        # Circuit breaker check
        if self._circuit.is_open(service_id):
            if fallback_service:
                # Auto-onboard fallback and retry
                await self.onboard(fallback_service)
                return await self.call(fallback_service, capability_id, payload)
            raise CircuitOpenError(f"Circuit open for {service_id}")

        manifest = await self._get_manifest(service_id)
        api = manifest.get("api", {})
        limits = manifest.get("limits", {})
        capabilities = manifest.get("capabilities", [])

        # Find the capability
        cap = None
        for c in capabilities:
            if c.get("id") == capability_id:
                cap = c
                break
        if cap is None:
            raise UnioCallError(f"Capability {capability_id} not found in {service_id}")

        # Throttle
        rpm = limits.get("rate_limit_requests_per_minute", 100)
        await self._throttle.acquire(service_id, rpm)

        # Build request
        base_url = api.get("base_url", "")
        url = base_url.rstrip("/") + cap["path"]
        auth_header = api.get("auth_header", "Authorization")
        auth_scheme = api.get("auth_scheme", "Bearer")

        credential = get_credential(self.agent_id, service_id)
        headers = {auth_header: f"{auth_scheme} {credential}"} if credential else {}

        start = time.monotonic()
        try:
            async with httpx.AsyncClient(timeout=30.0) as client:
                method = cap.get("method", "POST").lower()
                if method == "get":
                    resp = await client.get(url, params=payload, headers=headers)
                elif method == "post":
                    resp = await client.post(url, json=payload, headers=headers)
                elif method == "put":
                    resp = await client.put(url, json=payload, headers=headers)
                elif method == "patch":
                    resp = await client.patch(url, json=payload, headers=headers)
                elif method == "delete":
                    resp = await client.delete(url, headers=headers)
                else:
                    resp = await client.post(url, json=payload, headers=headers)

            duration_ms = int((time.monotonic() - start) * 1000)

            if resp.status_code >= 500:
                self._circuit.record_failure(service_id)
                outcome = "error"
            elif resp.status_code >= 400:
                outcome = "client_error"
            else:
                self._circuit.record_success(service_id)
                outcome = "success"

            # Fire-and-forget session log
            asyncio.create_task(log_session(
                self.unio_api_base, self.unio_token,
                service_id, capability_id, outcome, duration_ms,
            ))

            if resp.status_code >= 400:
                raise UnioCallError(f"Call failed: {resp.status_code} {resp.text}")

            return resp.json()

        except httpx.HTTPError as e:
            duration_ms = int((time.monotonic() - start) * 1000)
            self._circuit.record_failure(service_id)
            asyncio.create_task(log_session(
                self.unio_api_base, self.unio_token,
                service_id, capability_id, "error", duration_ms,
            ))
            raise UnioCallError(f"HTTP error: {e}") from e

    async def subscribe(
        self,
        intent: str,
        notify_on: list[str],
        delivery_method: str = "poll",
        webhook_url: str | None = None,
    ) -> str:
        """Subscribe this agent to capability-change events matching ``intent``.

        Args:
            intent: Free-text description of what kinds of services the agent
                cares about. Server-side, this is embedded with Bedrock Titan
                so newly listed services can be scored against it.
            notify_on: Event types to subscribe to, e.g.
                ``["new_service_listed"]``.
            delivery_method: Either ``"poll"`` (default) — fetch via
                :py:meth:`get_notifications` — or ``"webhook"``, in which case
                ``webhook_url`` must be supplied.
            webhook_url: HTTPS endpoint to POST notifications to when
                ``delivery_method="webhook"``.

        Returns:
            The newly created ``subscription_id``.
        """
        if delivery_method not in ("poll", "webhook"):
            raise ValueError("delivery_method must be 'poll' or 'webhook'")
        if delivery_method == "webhook" and not webhook_url:
            raise ValueError("webhook_url is required when delivery_method='webhook'")

        body: dict = {
            "intent": intent,
            "notify_on": list(notify_on),
            "delivery_method": delivery_method,
        }
        if webhook_url:
            body["webhook_url"] = webhook_url

        async with httpx.AsyncClient(timeout=10.0) as client:
            try:
                resp = await client.post(
                    f"{self.unio_api_base}/v1/auth/agents/{self.agent_id}/subscriptions",
                    json=body,
                    headers={"Authorization": f"Bearer {self.unio_token}"},
                )
            except httpx.HTTPError as exc:
                raise UnioCallError(f"subscribe HTTP error: {exc}") from exc

        if resp.status_code != 200:
            raise UnioCallError(f"subscribe failed: {resp.status_code} {resp.text}")
        return resp.json()["subscription_id"]

    async def get_notifications(self) -> list[dict]:
        """Fetch unread notifications for this agent (server marks them read).

        Returns:
            A list of notification dicts. Each contains at least
            ``notification_id``, ``type``, ``service_id``, ``message``,
            ``created_at``, and ``match_score``. The list is empty when there
            is nothing unread.
        """
        async with httpx.AsyncClient(timeout=10.0) as client:
            try:
                resp = await client.get(
                    f"{self.unio_api_base}/v1/auth/agents/{self.agent_id}/notifications",
                    headers={"Authorization": f"Bearer {self.unio_token}"},
                )
            except httpx.HTTPError as exc:
                raise UnioCallError(f"get_notifications HTTP error: {exc}") from exc

        if resp.status_code != 200:
            raise UnioCallError(f"get_notifications failed: {resp.status_code} {resp.text}")
        return resp.json().get("notifications", [])
