"""Registry HTTP client for searching and fetching manifests."""
from __future__ import annotations

from typing import Any

import httpx


class RegistryClient:
    """HTTP client for the Unio Registry API."""

    def __init__(self, base_url: str | None = None) -> None:
        import os
        # Caller-provided URL wins; otherwise read UNIO_API_BASE; final
        # fallback is the live AWS API Gateway URL. Will swap to a custom
        # domain once one is in place.
        base_url = (
            base_url
            or os.environ.get("UNIO_API_BASE")
            or "https://xza0g37re9.execute-api.ap-south-1.amazonaws.com/prod"
        )
        self.base_url = base_url.rstrip("/")

    async def search(self, query: str, limit: int = 10) -> list[dict[str, Any]]:
        """Search the registry. Returns list of result dicts."""
        async with httpx.AsyncClient(timeout=10.0) as client:
            resp = await client.get(
                f"{self.base_url}/v1/registry/search",
                params={"q": query, "limit": limit},
            )
            resp.raise_for_status()
            data = resp.json()
            return data.get("results", [])

    async def get_service(self, service_id: str) -> dict[str, Any] | None:
        """Get full service details including manifest."""
        async with httpx.AsyncClient(timeout=10.0) as client:
            resp = await client.get(
                f"{self.base_url}/v1/registry/services/{service_id}",
            )
            if resp.status_code == 404:
                return None
            resp.raise_for_status()
            return resp.json()
