"""Fire-and-forget session logging to Unio Auth."""
from __future__ import annotations
import httpx


async def log_session(unio_api_base: str, unio_token: str, service_id: str,
                      capability_id: str, outcome: str, duration_ms: int) -> None:
    """Post session log — fire-and-forget, never awaits response."""
    try:
        async with httpx.AsyncClient(timeout=3.0) as client:
            await client.post(
                f"{unio_api_base}/v1/auth/session",
                json={"service_id": service_id, "capability_id": capability_id,
                      "outcome": outcome, "duration_ms": duration_ms},
                headers={"Authorization": f"Bearer {unio_token}"},
            )
    except Exception:
        pass  # fire-and-forget
