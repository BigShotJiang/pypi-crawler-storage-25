"""Per-service circuit breaker state machine."""
from __future__ import annotations

import time
from enum import Enum


class State(Enum):
    CLOSED = "closed"
    OPEN = "open"
    HALF_OPEN = "half_open"


class CircuitBreaker:
    """Circuit breaker with CLOSED → OPEN → HALF_OPEN → CLOSED cycle."""

    def __init__(self, failure_threshold: int = 3, recovery_timeout: float = 60.0) -> None:
        self.failure_threshold = failure_threshold
        self.recovery_timeout = recovery_timeout
        self._states: dict[str, State] = {}
        self._failure_counts: dict[str, int] = {}
        self._opened_at: dict[str, float] = {}

    def _get_state(self, service_id: str) -> State:
        state = self._states.get(service_id, State.CLOSED)
        if state == State.OPEN:
            opened_at = self._opened_at.get(service_id, 0)
            if time.monotonic() - opened_at >= self.recovery_timeout:
                self._states[service_id] = State.HALF_OPEN
                return State.HALF_OPEN
        return state

    def is_open(self, service_id: str) -> bool:
        """Check if the circuit is OPEN (calls should be rejected)."""
        return self._get_state(service_id) == State.OPEN

    def record_success(self, service_id: str) -> None:
        """Record a successful call — resets to CLOSED."""
        self._failure_counts[service_id] = 0
        self._states[service_id] = State.CLOSED

    def record_failure(self, service_id: str) -> None:
        """Record a failed call — may transition to OPEN."""
        count = self._failure_counts.get(service_id, 0) + 1
        self._failure_counts[service_id] = count
        state = self._get_state(service_id)
        if state == State.HALF_OPEN:
            self._states[service_id] = State.OPEN
            self._opened_at[service_id] = time.monotonic()
        elif count >= self.failure_threshold:
            self._states[service_id] = State.OPEN
            self._opened_at[service_id] = time.monotonic()
