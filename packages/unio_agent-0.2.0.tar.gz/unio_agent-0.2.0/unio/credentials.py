"""OS keychain credential storage via keyring."""
from __future__ import annotations

import json
from typing import Any

try:
    import keyring
    _HAS_KEYRING = True
except ImportError:
    _HAS_KEYRING = False

_SERVICE_NAME = "unio-agent"


def _check() -> None:
    if not _HAS_KEYRING:
        raise RuntimeError("keyring package is required for credential storage")


def get_identity() -> dict[str, str] | None:
    """Load agent identity from keychain. Returns None if not found."""
    _check()
    data = keyring.get_password(_SERVICE_NAME, "identity")
    if data is None:
        return None
    return json.loads(data)


def save_identity(identity: dict[str, str]) -> None:
    """Save agent identity to keychain."""
    _check()
    keyring.set_password(_SERVICE_NAME, "identity", json.dumps(identity))


def get_credential(agent_id: str, service_id: str) -> str | None:
    """Get a stored credential for an agent+service pair."""
    _check()
    return keyring.get_password(_SERVICE_NAME, f"{agent_id}:{service_id}")


def save_credential(agent_id: str, service_id: str, credential: str) -> None:
    """Save a credential for an agent+service pair."""
    _check()
    keyring.set_password(_SERVICE_NAME, f"{agent_id}:{service_id}", credential)
