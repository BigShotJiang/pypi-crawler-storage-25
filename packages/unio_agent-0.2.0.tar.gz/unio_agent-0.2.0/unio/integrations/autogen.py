"""AutoGen function_map format — stub for future implementation."""
