"""Vercel AI SDK tool() format — stub for future implementation."""
