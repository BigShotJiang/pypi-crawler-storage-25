"""LangChain/LangGraph @tool integration for UnioAgent."""
from __future__ import annotations

from typing import Any, TYPE_CHECKING

if TYPE_CHECKING:
    from ..agent import UnioAgent


class UnioToolkit:
    """Wraps an UnioAgent to expose capabilities as LangChain @tool functions."""

    def __init__(self, agent: UnioAgent) -> None:
        self.agent = agent

    def get_tool(self, service_id: str, capability_id: str):
        """Return a LangChain @tool-decorated async function for a capability.

        The tool's docstring is the capability description (LLM reads this).
        The tool name is f"{service_id}__{capability_id}".
        """
        agent = self.agent

        async def _unio_tool(**kwargs) -> dict[str, Any]:
            return await agent.call(service_id, capability_id, kwargs)

        _unio_tool.__name__ = f"{service_id}__{capability_id}"
        _unio_tool.__qualname__ = f"{service_id}__{capability_id}"

        # We'll set the docstring dynamically when the tool is first called
        # since we need the manifest. For now, set a placeholder.
        _unio_tool.__doc__ = f"Call {service_id}/{capability_id} via Unio"

        return _unio_tool

    async def get_tools_for_service(self, service_id: str) -> list:
        """Get all tools for a service from its manifest."""
        manifest = await self.agent._get_manifest(service_id)
        capabilities = manifest.get("capabilities", [])
        tools = []
        for cap in capabilities:
            cap_id = cap.get("id", "")
            tool = self.get_tool(service_id, cap_id)

            # Set proper docstring from capability description
            description = cap.get("description", cap.get("name", cap_id))
            tool.__doc__ = description

            tools.append(tool)
        return tools
