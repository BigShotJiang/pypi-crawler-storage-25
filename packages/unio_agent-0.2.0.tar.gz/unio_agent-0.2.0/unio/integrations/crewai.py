"""CrewAI Tool class wrappers — stub for future implementation."""
