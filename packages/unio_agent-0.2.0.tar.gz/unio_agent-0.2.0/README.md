# unio-agent

SDK for building AI agents on the Unio network.

## Quick Start (5 lines)

```python
from unio import UnioAgent
import asyncio

async def main():
    agent = await UnioAgent.init(agent_name="my-bot", contact_email="you@example.com")
    services = await agent.find("send email")
    cred = await agent.onboard(services[0].service_id)
    result = await agent.call(services[0].service_id, "send_email", {"to": "user@test.com", "subject": "Hi"})

asyncio.run(main())
```

## LangGraph Example

```python
from unio import UnioAgent, UnioToolkit
from langgraph.prebuilt import create_react_agent

agent = await UnioAgent.init(agent_name="email-bot", contact_email="you@example.com")
toolkit = UnioToolkit(agent)
tools = await toolkit.get_tools_for_service("resend")

llm = ChatOpenAI(model="gpt-4o")
graph = create_react_agent(llm, tools)
```

## Installation

```bash
pip install unio-agent
```

## Features

- **Auto-registration** — Generates Ed25519 keypair, registers with Unio, stores in OS keychain
- **Trust-level filtering** — `find()` only returns services you can actually access
- **Onboarding with signing** — Requests signed with Ed25519, trust/reputation gates enforced
- **Circuit breaker** — 3 consecutive failures → OPEN, auto-recovers after 60s
- **Token bucket throttle** — Reads manifest limits, self-throttles to avoid 429s
- **Session logging** — Fire-and-forget logs to Unio Auth for reputation tracking
- **LangChain integration** — `UnioToolkit.get_tool()` returns `@tool`-compatible async functions

## License

Apache-2.0
