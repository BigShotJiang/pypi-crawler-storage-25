"""
Copyright (C) 2024-2026 The ONNXIFIER Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
"""

import inspect
import traceback
from collections import OrderedDict, defaultdict
from collections.abc import Mapping, Sequence, Set
from functools import partial
from itertools import chain
from typing import Any

import networkx as nx
from onnx import FunctionProto, NodeProto, ValueInfoProto
from onnx.helper import make_function, make_value_info
from tabulate import tabulate
from termcolor import colored

from .graph import OnnxGraph
from .logger import debug, error, warning
from .passes import L1, L2, L3, PASSES
from .passes.utils import extract_function
from .traits import RewriterInterface


def _can_specify_node_names(rewriter) -> bool:
    """Return True when ``rewriter`` is a callable that can accept the
    ``_specify_node_names`` argument.
    """

    # is either a plain function or a `functools.partial` object that wraps a function.
    is_partial_func = False
    if isinstance(rewriter, partial) and inspect.isfunction(rewriter.func):
        is_partial_func = True
    is_plain_func = inspect.isfunction(rewriter)

    if is_plain_func:
        sig = inspect.signature(rewriter)
    elif is_partial_func:
        sig = inspect.signature(rewriter.func)
    else:
        # must be Rewriter subclass
        return True
    for k, v in sig.parameters.items():
        if v.kind in (v.KEYWORD_ONLY, v.POSITIONAL_OR_KEYWORD) and k in (
            "_specify_node_names",
        ):
            return True
        elif v.kind == v.VAR_KEYWORD:
            return True
    return False


def _apply_pass(rewriter, g, specify_node_names):
    if not _can_specify_node_names(rewriter) or specify_node_names is None:
        g = rewriter(g)
    else:
        g = rewriter(g, _specify_node_names=specify_node_names)
    return g


# graph name: (domain, graph, graph callers)
type _GraphLevel = dict[str, tuple[str, OnnxGraph, list[str]]]


class PassManager:
    """Ordered optimization pass list.

    Args:
        include (List[str | RewriterInterface], Optional): a list of pattern to
            select passes. Defaults to select L1, L2 and L3 passes.
        exclude (List[str], Optional): a list of pattern to deselect passes.
            Defaults to None.
        configs (Dict[str, Any], Optional): a dictionary of pass configurations.
            Defaults to None.
    """

    def __init__(
        self,
        include: Sequence[str | RewriterInterface] | None = None,
        exclude: Sequence[str] | None = None,
        configs: dict[str, Any] | None = None,
    ) -> None:
        passes: list[str | RewriterInterface]
        if include is None:
            passes = [i for i in chain(L1, L2, L3)]
        else:
            passes = [i for i in include]
        if exclude:
            passes = list(filter(lambda i: i not in exclude, passes))
        activated: list[RewriterInterface] = []
        for i in passes:
            if isinstance(i, str):
                if i in PASSES:
                    activated.append(PASSES[i])
                else:
                    warning(f"{i} is not registered as a pass, ignore it.")
            else:
                activated.append(i)
        self.activated: list[RewriterInterface] = activated
        if configs:
            self._assign_config_to_pass(configs)

    def _assign_config_to_pass(self, configs: dict[str, Any]):
        for key, config in configs.items():
            index = -1
            if ":" in key:
                key, index_str = key.split(":", 2)
                index = int(index_str)
            if not isinstance(config, Mapping):
                warning(f"config {key}:{index} must be a dict, but got {type(config)}")
                continue
            candidates = [i for i in self.activated if key == i.__NAME__]
            if index >= 0 and index >= len(candidates):
                warning(
                    f"config {key}:{index} exceeds the boundary. "
                    f"Number of {key} is {len(candidates)}"
                )
                continue
            if index >= 0:
                candidates = [candidates[index]]
            for func in candidates:
                pos = self.activated.index(func)
                self.activated[pos] = partial(func, **config)  # type: ignore
                self.activated[pos].__NAME__ = key
                self.activated[pos].__DEPS__ = func.__DEPS__
                self.activated[pos].__PATCHES__ = func.__PATCHES__

    def _expand(self, nodes, priv_member):
        root: nx.DiGraph = nx.DiGraph()  # type: ignore
        leaves = [(i, n) for i, n in enumerate(nodes)]
        root.add_nodes_from(leaves)
        # a shallow graph to check cyclic dependencies
        shallow: nx.DiGraph = nx.DiGraph()  # type: ignore
        shallow.add_nodes_from(nodes)
        ind = len(leaves)
        while leaves:
            leaf = leaves.pop(0)
            leaf_pass = leaf[1]
            children = getattr(PASSES.get_type(leaf_pass), priv_member, [])
            shallow.add_edges_from([(leaf_pass, child) for child in children])
            try:
                cycles = nx.find_cycle(shallow, leaf_pass)
            except nx.NetworkXNoCycle:
                children = [(ind + i, c) for i, c in enumerate(children)]
                ind += len(children)
                root.add_edges_from([(leaf, child) for child in children])
                leaves.extend(children)
            else:
                error(f"Cyclic dependencies found!: {cycles}")
                raise RuntimeError("Cyclic dependencies found!")
        return root

    def _expand_deps(self, deps):
        root = self._expand(deps, "__DEPS__")
        for i in nx.traversal.dfs_postorder_nodes(root):
            yield i[1]

    def _expand_patches(self, nodes):
        root = self._expand(nodes, "__PATCHES__")
        for i in nx.traversal.dfs_preorder_nodes(root):
            yield i[1]

    def optimize(
        self,
        graph: OnnxGraph,
        strict: bool = False,
        recursive: bool = False,
        specify_node_names: Set[str] | None = None,
    ) -> OnnxGraph:
        """Invoke passes on the input graph.

        Args:
            graph (OnnxGraph): See :class:`OnnxGraph`.
            strict (bool): Break if any pass fails.
            recursive (bool): Recursively apply passes to functions.
            specify_node_names (set[str], optional): Only optimize nodes with these
                names. Defaults to None.
        """
        graphs: _GraphLevel = {"": ("", graph, [])}  # let "" be the main graph
        if recursive:
            graphs.update(self._make_subgraph_from_functions(graph))
        for opt in self.activated:
            for name, (d, g, parents) in graphs.items():
                try:
                    for deps in self._expand_deps(opt.__DEPS__):
                        if rewriter := PASSES.get(deps):
                            debug(f"Applying dependency pass: {deps} to {name}")
                            g = _apply_pass(rewriter, g, specify_node_names)
                    debug(f"Applying pass: {opt.__NAME__} to {name}")
                    g = _apply_pass(opt, g, specify_node_names)
                    for patch in self._expand_patches(opt.__PATCHES__):
                        debug(f"Applying patch pass: {patch} to {name}")
                        if rewriter := PASSES.get(patch):
                            g = _apply_pass(rewriter, g, specify_node_names)
                    graphs[name] = (d, g, parents)
                    if name:
                        old_func = graphs[""][1].functions[name]
                        function = self._make_function_from_subgraph(name, d, g)
                        graphs[""][1].onnx_add_function(function, force=True)
                        # sync parent graph caller nodes to match new signature
                        self._update_parent_graph(parents, old_func, function, graphs)
                except Exception as ex:  # pylint: disable=broad-exception-caught
                    error(f"{opt.__NAME__} failed at {name}: {ex}")
                    debug("\n".join(traceback.format_exception(ex)))
                    if strict:
                        raise
        return graphs[""][1]

    def _make_subgraph_from_functions(self, graph: OnnxGraph):
        users: dict[str, list[NodeProto]] = defaultdict(list)
        iter_order: dict[str, OnnxGraph] = {}  # ordered hashset
        parents: dict[str, list[str]] = defaultdict(list)  # func -> parent keys
        # graph.functions may not topologically sorted
        bfs: dict[str, None] = OrderedDict()  # used as ordered set
        for n in graph:
            node: NodeProto = graph.nodes[n]["pb"]
            if node.op_type in graph.functions:
                users[node.op_type].append(node)
                iter_order[node.op_type] = graph
                bfs[node.op_type] = None
                parents[node.op_type].append("")  # called from main graph
        while bfs:
            top_key = next(iter(bfs))
            f = graph.functions[top_key]
            del bfs[top_key]
            for node in f.node:
                if node.op_type in graph.functions:
                    users[node.op_type].append(node)
                    bfs[node.op_type] = None
                    parents[node.op_type].append(top_key)
                    iter_order[node.op_type] = extract_function(
                        graph,
                        f.node,
                        [(i, j) for i, j in zip(users[f.name][0].input, f.input)],
                        [(i, j) for i, j in zip(users[f.name][0].output, f.output)],
                    )
        extended_value_info: list[ValueInfoProto] = []
        for name, parent in iter_order.items():
            if len(users[name]) != 1:
                # Currently only function for a single node is OK to optimize
                # Otherwise we can't figure out how to do a general optimization
                # across different nodes.
                continue
            node = users[name][0]
            f = graph.functions[name]
            # pylint: disable=protected-access
            parent._value_info.extend(extended_value_info)
            model = extract_function(
                parent,
                f.node,
                [(i, j) for i, j in zip(node.input, f.input)],
                [(i, j) for i, j in zip(node.output, f.output)],
            )
            for i in chain(model.input, model.output):
                extended_value_info.append(make_value_info(i.name, i.type))
            yield name, (f.domain, model, parents[name])

    @staticmethod
    def _update_parent_graph(
        parents: list[str],
        old_func: FunctionProto,
        new_func: FunctionProto,
        graphs: "_GraphLevel",
    ) -> None:
        """Sync caller nodes in parent graphs after a child function's I/O changes.

        When an optimization pass adds or removes inputs/outputs of a function
        subgraph, the caller nodes in the parent graph(s) must be updated so
        that their ``input`` / ``output`` lists stay positionally aligned with
        the new function signature.
        """
        old_inputs = list(old_func.input)
        old_outputs = list(old_func.output)
        new_inputs = list(new_func.input)
        new_outputs = list(new_func.output)

        if old_inputs == new_inputs and old_outputs == new_outputs:
            return  # nothing changed
        new_value_info = {v.name: v for v in new_func.value_info}

        for parent_key in parents:
            if parent_key not in graphs:
                continue
            _, parent_graph, _ = graphs[parent_key]

            # find caller nodes whose op_type matches the function name
            for n in list(parent_graph.nodes):
                caller: NodeProto = parent_graph.nodes[n]["pb"]
                if caller.op_type != new_func.name or caller.domain != new_func.domain:
                    continue
                remove_in = set(old_inputs) - set(new_inputs)
                for i in remove_in:
                    caller.input.remove(i)
                    if i not in parent_graph.inputs:
                        raise RuntimeError(
                            f"Input {i} removed from function {caller.name} "
                            "is used in other op!"
                        )
                    parent_graph.remove_input(i)
                extra_in = set(new_inputs) - set(old_inputs)
                # keep in order
                extra_in = [i for i in new_inputs if i in extra_in]
                for i in extra_in:
                    caller.input.append(i)
                    parent_graph.set_value_info(i, value_info=new_value_info[i])
                    # add input to graph
                    parent_graph.set_input(caller, i)
                remove_out = set(old_outputs) - set(new_outputs)
                for o in remove_out:
                    caller.output.remove(o)
                    if o not in parent_graph.outputs:
                        raise RuntimeError(
                            f"Output {o} removed from function {caller.name} "
                            "is used in other op!"
                        )
                    parent_graph.remove_output(o)
                extra_out = set(new_outputs) - set(old_outputs)
                extra_out = [o for o in new_outputs if o in extra_out]
                for o in extra_out:
                    caller.output.append(o)
                    parent_graph.set_value_info(o, value_info=new_value_info[o])
                    # add output to graph
                    parent_graph.set_output(caller, o)

                # refresh parent graph internal state for this node
                parent_graph.add_onnx_node(caller)

    def _make_function_from_subgraph(self, name: str, domain: str, model: OnnxGraph):
        # pylint: disable=protected-access
        model._keep_value_info = True
        # set inputs/outputs to value info
        for i in model.input:
            # FIXME WA: for undefined data type, defaults to float32
            if i.type.tensor_type.elem_type == 0:
                i.type.tensor_type.elem_type = 1
            model.set_value_info(i.name, value_info=i)
        for o in model.output:
            if o.type.tensor_type.elem_type == 0:
                o.type.tensor_type.elem_type = 1
            model.set_value_info(o.name, value_info=o)
        h = model.model
        function = make_function(
            domain,
            name,
            list(model.inputs),
            list(model.outputs),
            h.graph.node,
            opset_imports=h.opset_import,
            value_info=h.graph.value_info,
        )
        return function

    @classmethod
    def print_all(cls):
        """Print the name of all passes."""
        print(PASSES, flush=True)

    @classmethod
    def print_l1(cls):
        """Print the name of all L1 passes."""
        print(L1, flush=True)

    @classmethod
    def print_l2(cls):
        """Print the name of all L2 passes."""
        print(L2, flush=True)

    @classmethod
    def print_l3(cls):
        """Print the name of all L3 passes."""
        print(L3, flush=True)

    @classmethod
    def print(cls, names: str | list[str]):
        """Print a specific pass or a set of passes."""
        print(PASSES.child(names), flush=True)

    def __repr__(self) -> str:
        return tabulate(
            [[i.__NAME__, i] for i in self.activated], ["PASS", "Func"], "grid"
        )


def print_pass_simple(pm: PassManager):
    """Print activated passes of a PassManager in a simple format."""

    msg = ""
    for n, i in enumerate(pm.activated):
        deps = []
        post = []
        # pylint: disable=protected-access
        for j in pm._expand_deps(i.__DEPS__):
            if j in PASSES:
                deps.append(j)
        for j in pm._expand_patches(i.__PATCHES__):
            if j in PASSES:
                post.append(j)
        msg += f"\n{n:<2} "
        if deps:
            msg += "[" + colored(",".join(deps), "yellow") + "] "
        msg += i.__NAME__
        if post:
            msg += " [" + colored(",".join(post), "magenta") + "]"
    if msg:
        print(f"Activated passes ([deps] pass [patches]):{msg}")
