"""
Copyright (C) 2024 The ONNXIFIER Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
"""

from openvino import Model
from openvino.opset1 import constant, parameter, result
from openvino.opset11 import topk

from . import convert_xml


def test_topk_opset11():
    p = parameter([1, 1000])
    k = constant(10, dtype=int)
    t = topk(p, k, axis=1, mode="max", sort="value")
    r0 = result(t.output(0))
    r1 = result(t.output(1))
    m = Model([r0, r1], [p])
    convert_xml(m)
