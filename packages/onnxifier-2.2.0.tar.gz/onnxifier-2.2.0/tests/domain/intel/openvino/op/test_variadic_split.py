"""
Copyright (C) 2025 The ONNXIFIER Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
"""

# pylint: disable=missing-function-docstring

from openvino import Model
from openvino.opset1 import parameter, result, variadic_split

from . import convert_xml


def test_variadic_split_opset1():
    p = parameter([1, 32, 8, 8])
    s = variadic_split(p, 1, [2, 4, 26])
    r0 = result(s.output(0))
    r1 = result(s.output(1))
    r2 = result(s.output(2))
    model = Model([r0, r1, r2], [p])
    convert_xml(model)


def test_variadic_split_negative_values_opset1():
    p = parameter([32, 8, 8])
    s = variadic_split(p, 0, [30, -1])
    r0 = result(s.output(0))
    r1 = result(s.output(1))
    model = Model([r0, r1], [p])
    convert_xml(model)
