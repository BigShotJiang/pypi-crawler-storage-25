"""Tools resource -- search, execute, and lookup tools."""

from __future__ import annotations

from typing import Any
from uuid import UUID

from mcpgateway_sdk._http import HTTPClient
from mcpgateway_sdk.models.tool import ToolExecuteResult, ToolLookup, ToolSearchResult

_ENDPOINTS = {
    "get_by_name": ("GET", "/api/v1/tools/by-name"),
    "search": ("POST", "/api/v1/tools/search"),
    "execute": ("POST", "/api/v1/tools/execute"),
}


class ToolsResource:
    """Interact with tools registered on the MCP Gateway."""

    _endpoints = _ENDPOINTS

    def __init__(self, http: HTTPClient) -> None:
        self._http = http

    async def get_by_name(self, server_name: str, tool_name: str) -> ToolLookup:
        """Resolve a tool by its exact name on a specific server.

        Args:
            server_name: The name of the server that hosts the tool.
            tool_name: The registered name of the tool.

        Returns:
            A ToolLookup with the tool metadata and input schema.
        """
        data = await self._http.request(
            "GET",
            "/api/v1/tools/by-name",
            params={"server_name": server_name, "tool_name": tool_name},
        )
        return ToolLookup.model_validate(data)

    async def search(
        self,
        query: str,
        limit: int = 5,
        *,
        bundle_id: str | UUID | None = None,
        agent_id: str | UUID | None = None,
        server_ids: list[str | UUID] | None = None,
    ) -> list[ToolSearchResult]:
        """Semantic search for tools matching a natural-language query.

        Args:
            query: Natural-language description of the desired capability.
            limit: Maximum number of results to return (default 5).
            bundle_id: Scope search to tools in a specific bundle.
            agent_id: Scope search to tools assigned to an agent's bundle.
            server_ids: Scope search to tools on specific servers.

        Returns:
            A list of ToolSearchResult sorted by relevance score.
        """
        body: dict[str, Any] = {"query": query, "limit": limit}
        if bundle_id is not None:
            body["bundle_id"] = str(bundle_id)
        if agent_id is not None:
            body["agent_id"] = str(agent_id)
        if server_ids is not None:
            body["server_ids"] = [str(sid) for sid in server_ids]
        data = await self._http.request("POST", "/api/v1/tools/search", json=body)
        return [ToolSearchResult.model_validate(r) for r in data.get("tools", [])]

    async def execute(
        self,
        tool_name: str,
        arguments: dict[str, Any] | None = None,
        *,
        server_id: str | UUID | None = None,
        server_name: str | None = None,
        bundle_id: str | UUID | None = None,
        agent_id: str | UUID | None = None,
    ) -> ToolExecuteResult:
        """Execute a tool on the gateway.

        Exactly one of ``server_id`` or ``server_name`` must be provided so the
        gateway knows which server hosts the tool.

        Args:
            tool_name: Name of the tool to execute.
            arguments: Input arguments for the tool. Defaults to empty dict.
            server_id: UUID of the server that hosts the tool.
            server_name: Name of the server that hosts the tool.
            bundle_id: Optional bundle for credential resolution.
            agent_id: Optional agent for credential resolution.

        Returns:
            A ToolExecuteResult with the output and execution metadata.

        Raises:
            ValueError: If both or neither of server_id/server_name are given.
        """
        if server_id is not None and server_name is not None:
            raise ValueError("Provide exactly one of server_id or server_name, not both")
        if server_id is None and server_name is None:
            raise ValueError("Provide exactly one of server_id or server_name")

        body: dict[str, Any] = {
            "tool_name": tool_name,
            "arguments": arguments or {},
        }
        if server_id is not None:
            body["server_id"] = str(server_id)
        if server_name is not None:
            body["server_name"] = server_name
        if bundle_id is not None:
            body["bundle_id"] = str(bundle_id)
        if agent_id is not None:
            body["agent_id"] = str(agent_id)

        data = await self._http.request(
            "POST",
            "/api/v1/tools/execute",
            json=body,
        )
        return ToolExecuteResult.model_validate(data)
