# hyperlight-sandbox-javascript-guest

Packaged Hyperlight Wasm JavaScript guest exposed as javascript_guest.path
