from functools import wraps
from dataclasses import dataclass
from typing import Callable, Awaitable


@dataclass(slots=True)
class Ok[T, E=str]:
    """
    Represents the success result wrapping a value of type T.

    Type Parameters:
        T: The type of the success value.
        E: The type of the error value, defaults to str.

    Args:
        value: The success value.
    """
    value: T
    
    def unwrap_or[U](self, default: U) -> T: # type: ignore
        return self.value


@dataclass(slots=True)
class Err[E](Exception):
    """
    Represents the failed result wrapping an error of type E.
    Err is a terminal state: once reached, no operation can convert it back to Ok.

    Type Parameters:
        E: The type of the error value.

    Args:
        error: The error value.
    """
    error: E
    
    def unwrap_or[U](self, default: U) -> U:
        return default


type Result[T, E] = Ok[T, E] | Err[E]
"""A type alias for the result monad representing either a successful Ok[T, E] state or a failed Err[E] state."""


def safe[T](function: Callable[..., T]) -> Callable[..., Result[T, Exception]]:
    """
    Decorator that wraps a sync function in a try/except block.
    Returns Ok on success, Err on any exception.

    Args:
        function: The sync function to wrap.

    Returns:
        A wrapped function returning Result[T, Exception].

    Example:
        >>> @safe
        ... def divide(a: float, b: float) -> float:
        ...     return a / b

        Handle both cases with match:
        >>> match divide(10, 2):
        ...     case Ok(value): print(value)
        ...     case Err(error): print(error)
        5.0

        Or provide a default value with unwrap_or:
        >>> divide(10, 2).unwrap_or(0.0)
        5.0
        >>> divide(10, 0).unwrap_or(0.0)
        0.0
    """
    @wraps(function)
    def result_wrapper(*args, **kwargs) -> Result[T, Exception]:
        try:
            return Ok(function(*args, **kwargs))
        except Exception as e:
            return Err(e)
    return result_wrapper


def safe_async[T](function: Callable[..., Awaitable[T]]) -> Callable[..., Awaitable[Result[T, Exception]]]:
    """
    Decorator that wraps an async function in a try/except block.
    Returns Ok on success, Err on any exception.

    Args:
        function: The async function to wrap.

    Returns:
        A wrapped async function returning Result[T, Exception].

    Example:
        >>> @safe_async
        ... async def get_username(user_id: int) -> str:
        ...     async with ClientSession() as session:
        ...         async with session.get(f"/users/{user_id}") as response:
        ...             data = await response.json()
        ...             return data["username"]

        Handle both cases with match:
        >>> match await get_username(1):
        ...     case Ok(value): print(value)
        ...     case Err(error): print(error)
        'john_doe'

        Or provide a default value with unwrap_or:
        >>> (await get_username(1)).unwrap_or("anonymous")
        'john_doe'
        >>> (await get_username(-1)).unwrap_or("anonymous")
        'anonymous'
    """
    @wraps(function)
    async def result_wrapper(*args, **kwargs) -> Result[T, Exception]:
        try:
            return Ok(await function(*args, **kwargs))
        except Exception as e:
            return Err(e)
    return result_wrapper