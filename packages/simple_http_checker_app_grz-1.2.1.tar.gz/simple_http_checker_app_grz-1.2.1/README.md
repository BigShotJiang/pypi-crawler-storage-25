# Python for DevOps: CI/CD for Python Projects

This repo contains the code for the CI/CD section of Python for DevOps course.

## What we implement in this repository

[X] Implement the project (code files) - Complete Python package with proper structure
[X] Add a simple GHA workflow - Basic GitHub Actions setup and execution
[X] Add linting (ruff) and format checks (black) - Code quality automation
[X] Add typing (mypy) and security checks (bandit) - Static analysis and security scanning
[X] Add test automation - Comprehensive test suite with pytest
[X] Build our Python project - Automated package building
[] Publish the project to both TestPyPI and PyPI when a new release is published