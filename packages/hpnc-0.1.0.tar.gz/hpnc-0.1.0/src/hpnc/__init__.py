"""HPNC — Human-Planned Night Crew."""

__version__ = "0.1.0"

__all__ = ["__version__"]
