"""Claude Code CLI executor — invokes Claude Code for implementation/review.

All CLI-specific behavior is isolated here (NFR26).
Agent credentials are never logged or stored (NFR20).

CLI reference: claude --bare -p "prompt" --output-format text
"""

from __future__ import annotations

import subprocess
from collections.abc import Iterator
from pathlib import Path
from typing import TYPE_CHECKING

from hpnc.agents.base import ExitStatus
from hpnc.infra.errors import ConnectivityError

if TYPE_CHECKING:
    from hpnc.infra.config import Config

__all__ = ["ClaudeCodeExecutor"]


class ClaudeCodeExecutor:
    """Executes tasks via Claude Code CLI (FR69-FR73).

    Launches Claude Code in non-interactive mode (-p) within the task's worktree.
    Uses --bare to skip auto-discovery for consistent behavior across worktrees.
    """

    @staticmethod
    def check_connectivity() -> None:
        """Verify Claude Code CLI is installed and reachable (FR2).

        Raises:
            ConnectivityError: If Claude Code is not found or not responding.
        """
        try:
            result = subprocess.run(
                ["claude", "--version"],
                capture_output=True,
                text=True,
            )
            if result.returncode != 0:
                raise ConnectivityError(
                    what="Claude Code CLI not responding",
                    why=result.stderr.strip() or f"Exit code {result.returncode}",
                    action="Verify Claude Code is installed and authenticated",
                )
        except FileNotFoundError as e:
            raise ConnectivityError(
                what="Claude Code CLI not found",
                why="'claude' command not found on PATH",
                action="Install Claude Code: https://claude.ai/code",
            ) from e

    @staticmethod
    def preflight_check(worktree: Path) -> None:
        """Verify Claude Code can authenticate, edit files, and run commands.

        Runs a minimal prompt that creates a file and executes a command.
        Call this before the night run to catch auth/permission issues early.

        Args:
            worktree: Directory to run the preflight check in.

        Raises:
            ConnectivityError: If any capability check fails.
        """
        marker = worktree / ".hpnc-preflight-test"
        prompt = (
            "Do these two things:\n"
            "1. Create a file called .hpnc-preflight-test containing: PREFLIGHT_OK\n"
            "2. Run this shell command: echo COMMAND_OK"
        )
        try:
            result = subprocess.run(
                [
                    "claude", "-p", prompt,
                    "--dangerously-skip-permissions",
                    "--output-format", "text",
                    "--max-turns", "5",
                    "--no-session-persistence",
                ],
                stdin=subprocess.DEVNULL,
                capture_output=True,
                text=True,
                cwd=str(worktree),
                timeout=120,
            )
            if result.returncode != 0:
                raise ConnectivityError(
                    what="Claude Code preflight failed",
                    why=result.stdout.strip() or result.stderr.strip() or "Non-zero exit",
                    action="Check Claude Code authentication: run 'claude' interactively",
                )
            if not marker.exists():
                raise ConnectivityError(
                    what="Claude Code cannot edit files",
                    why="Preflight prompt ran but no file was created",
                    action="Verify Claude Code has file editing permissions (Write/Edit tools)",
                )
            if "COMMAND_OK" not in result.stdout:
                raise ConnectivityError(
                    what="Claude Code cannot execute commands",
                    why="Preflight prompt ran but shell command output not found",
                    action="Verify Claude Code has Bash tool permissions",
                )
        except FileNotFoundError as e:
            raise ConnectivityError(
                what="Claude Code CLI not found",
                why="'claude' command not found on PATH",
                action="Install Claude Code: https://claude.ai/code",
            ) from e
        except subprocess.TimeoutExpired as e:
            raise ConnectivityError(
                what="Claude Code preflight timed out",
                why="Preflight check did not complete within 120 seconds",
                action="Check network connectivity and API access",
            ) from e
        finally:
            if marker.exists():
                marker.unlink()

    def start(
        self,
        story: Path,
        config: Config,
        instructions: Path,
    ) -> subprocess.Popen[str]:
        """Start Claude Code with the story content as prompt.

        Uses -p (non-interactive), --bare (no auto-discovery),
        and --append-system-prompt-file for executor instructions.

        Args:
            story: Path to the story markdown file.
            config: Project configuration.
            instructions: Path to executor instructions file.

        Returns:
            Running Claude Code subprocess.
        """
        worktree = story.parent
        prompt = story.read_text(encoding="utf-8")

        cmd = [
            "claude",
            "-p", prompt,
            "--dangerously-skip-permissions",
            "--output-format", "text",
            "--max-turns", str(config.max_turns),
            "--no-session-persistence",
        ]
        # Use executor_model or reviewer_model depending on role
        model = config.executor_model or config.reviewer_model
        if model:
            cmd.extend(["--model", model])
        if instructions.exists():
            cmd.extend(["--append-system-prompt-file", str(instructions)])

        return subprocess.Popen(
            cmd,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            cwd=str(worktree),
        )

    def stream_output(
        self, process: subprocess.Popen[str]
    ) -> Iterator[str]:
        """Stream output lines from Claude Code (FR70).

        Args:
            process: The running Claude Code subprocess.

        Yields:
            Output lines.
        """
        if process.stdout is not None:
            for line in process.stdout:
                yield line.rstrip("\n")

    def get_exit_status(
        self, process: subprocess.Popen[str]
    ) -> ExitStatus:
        """Map Claude Code exit code to ExitStatus (FR71).

        Exit 0 = success, anything else = failure.

        Args:
            process: The completed Claude Code subprocess.

        Returns:
            ExitStatus based on exit code.
        """
        process.wait()
        if process.returncode == 0:
            return ExitStatus.SUCCESS
        return ExitStatus.FAILURE
