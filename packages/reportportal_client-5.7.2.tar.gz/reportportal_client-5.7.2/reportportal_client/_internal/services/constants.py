#  Copyright (c) 2023 EPAM Systems
#  Licensed under the Apache License, Version 2.0 (the "License");
#  you may not use this file except in compliance with the License.
#  You may obtain a copy of the License at
#
#  https://www.apache.org/licenses/LICENSE-2.0
#
#  Unless required by applicable law or agreed to in writing, software
#  distributed under the License is distributed on an "AS IS" BASIS,
#  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#  See the License for the specific language governing permissions and
#  limitations under the License

"""This module contains constants for the external services."""

import base64
import os


def _decode_string(text: str) -> str:
    """Decode value of the given string.

    :param text: Encoded string
    :return:     Decoded value
    """
    base64_bytes = text.encode("ascii")
    message_bytes = base64.b64decode(base64_bytes)
    return message_bytes.decode("ascii")


CLIENT_INFO: str = _decode_string("Ry1XUDU3UlNHOFhMOm5Ib3dqRjJQUVotNDFJbzBPcDRoZlE=")
ENDPOINT: str = "https://www.google-analytics.com/mp/collect"
CLIENT_ID_PROPERTY: str = "client.id"
RP_FOLDER_PATH: str = os.path.join(os.path.expanduser("~"), ".rp")
RP_PROPERTIES_FILE_PATH: str = os.path.join(RP_FOLDER_PATH, "rp.properties")
