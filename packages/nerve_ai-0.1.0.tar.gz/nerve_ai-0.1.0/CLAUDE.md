# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

Nerve is an AI-powered security auditor for AI systems ("AI tests AI") built by BreachLine Labs. It uses a multi-agent swarm architecture (via ReactSwarm) to autonomously discover and test LLM endpoints, MCP servers, vector databases, and AI infrastructure for vulnerabilities.

## Commands

```bash
# Install (editable, with all optional deps + dev tools)
pip install -e ".[all,dev]"

# Run all tests
pytest

# Run a single test file
pytest tests/unit/test_config.py

# Run with coverage
pytest --cov=nerve

# Lint
ruff check nerve/ tests/

# Lint with auto-fix
ruff check --fix nerve/ tests/

# Format
ruff format nerve/ tests/

# CLI entry point
nerve scan --target http://localhost:11434
nerve discover --target http://localhost:11434
nerve probe --target http://localhost:11434
nerve mcpscan --mcp-url http://localhost:3000
nerve ragscan --target http://localhost:6333
nerve report --input scan-results.json --format html
```

## Architecture

### Three-Phase Scan Pipeline

```
main.py (Typer CLI) → NerveConfig.load() → NerveOrchestrator.run_scan()
  Phase 1: DiscoveryAgent (sequential — find AI services)
  Phase 2: ModelProbe + MCPAudit + InfraAudit + RAGAudit (parallel)
  Phase 3: ChainAuditorAgent (sequential — multi-hop kill chains)
  → ReportEngine.generate() → JSON / HTML / SARIF
```

### Key Modules

- **`nerve/agents/base.py`** — `NerveAgent` extends ReactSwarm's `LoopAgent`. Overrides `reason()` to inject custom system prompts on iteration 1, parses findings from LLM output, and shares findings via `IntelligencePool`.
- **`nerve/agents/prompts.py`** — Prompt builders for each agent, injecting knowledge base context (techniques, OWASP, MITRE ATLAS, CWEs).
- **`nerve/orchestrator.py`** — Coordinates the 3-phase scan lifecycle, agent handoffs, and parallel execution.
- **`nerve/llm_bridge.py`** — `LLMRouter` with provider fallback chain. Bridges ReactSwarm's `llm_call_fn` to Anthropic/Google/OpenAI/Ollama APIs via HTTP.
- **`nerve/config.py`** — Merges YAML (`nerve.yaml`) + env vars (`NERVE_*`) + CLI flags into `NerveConfig`.
- **`nerve/tools/registry.py`** — `create_tool_registry()` factory registers all 24 tools with ReactSwarm's `ToolRegistry`.
- **`nerve/knowledge/`** — Static security methodology: OWASP Top 10 for LLM & MCP, MITRE ATLAS, CVE database, CWE mapping, and 20+ attack technique definitions.
- **`nerve/models/`** — Pydantic v2 models: `Finding` (with severity, evidence, OWASP/MITRE/CWE refs), `ScanResult`, `Target`.
- **`nerve/report/engine.py`** — `ReportEngine` generates JSON, dark-themed HTML (with kill chain visualization), and SARIF (GitHub Code Scanning).

### Extension Points

When adding functionality, follow the patterns in `docs/extending.md`:

- **New tools**: async function in `nerve/tools/`, register in `registry.py` via `registry.register()`.
- **New agents**: extend `NerveAgent` in `nerve/agents/`, wire into `orchestrator.py`.
- **New techniques**: add to `TECHNIQUE_LIBRARY` in `nerve/knowledge/techniques.py` with OWASP/MITRE/CWE mapping.
- **New CVEs**: append to `CVE_DATABASE` in `nerve/knowledge/cve_db.py`.

### Conventions

- Python 3.11+. Ruff linter: rules E, F, I, N, W, UP. Line length 100.
- Async throughout — tools use `httpx.AsyncClient`, agents use `anyio` for concurrency.
- Findings are emitted by agents in `FINDING: {json}` format and parsed by `NerveAgent._parse_findings()`.
- Tests use `pytest-asyncio` with `asyncio_mode = "auto"`. Fixtures in `tests/conftest.py`.
- Configuration priority: CLI flags > env vars (`NERVE_*`) > `nerve.yaml` > defaults.
