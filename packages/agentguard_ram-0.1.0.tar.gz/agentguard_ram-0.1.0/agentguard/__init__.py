"""AgentGuard — AI agent cost observability SDK."""

from .tracker import AgentGuardTracker
from .models import AgentEvent

try:
    from .callbacks import AgentGuardCallback
except ImportError:
    AgentGuardCallback = None  # type: ignore


class AgentGuard(AgentGuardTracker):
    """
    Main entry point.

    Usage::

        guard = AgentGuard(
            api_key="ag_...",
            agent_id="my-sales-agent",
            cost_threshold=10.0,
            slack_webhook="https://hooks.slack.com/...",
        )

        # LangChain / LangGraph
        chain = my_chain.with_config(callbacks=[guard.callback])

        # Custom agent
        @guard.track
        def run_my_agent():
            ...
    """

    @property
    def callback(self):
        if AgentGuardCallback is None:
            raise ImportError("Install langchain-core to use guard.callback")
        return AgentGuardCallback(self)


__all__ = ["AgentGuard", "AgentGuardTracker", "AgentEvent", "AgentGuardCallback"]
__version__ = "0.1.0"
