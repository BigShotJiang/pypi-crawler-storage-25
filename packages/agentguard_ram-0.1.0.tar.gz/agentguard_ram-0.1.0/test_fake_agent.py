"""
Fake agent test — validates SDK → backend flow without LangChain.

Usage (from agentguard/sdk/ directory):
    uv pip install -e .
    AGENTGUARD_API_KEY=ag_test uv run python test_fake_agent.py

Or with custom backend:
    AGENTGUARD_BACKEND_URL=http://localhost:8000 \
    AGENTGUARD_API_KEY=ag_test \
    uv run python test_fake_agent.py
"""

import os
import sys
import time

# Allow running without installing the package (local dev)
sys.path.insert(0, os.path.dirname(__file__))
from agentguard import AgentGuard

guard = AgentGuard(
    api_key=os.environ.get("AGENTGUARD_API_KEY", "ag_test"),
    agent_id="fake-test-agent",
    backend_url=os.environ.get("AGENTGUARD_BACKEND_URL", "http://localhost:8000"),
    cost_threshold=1.0,  # low threshold for testing
    slack_webhook=os.environ.get("SLACK_WEBHOOK_URL"),
)


@guard.track
def fake_agent():
    from agentguard.models import AgentEvent

    # Simulate 3 LLM calls
    for i in range(3):
        print(f"  [call {i+1}] sending llm_call event…")
        alive = guard.send_event(
            AgentEvent(
                agent_id="fake-test-agent",
                event_type="llm_call",
                model="gpt-4o",
                input_tokens=500,
                output_tokens=300,
                metadata={"step": i + 1},
            )
        )
        if not alive:
            print("  !! Agent paused by AgentGuard — stopping.")
            return
        time.sleep(0.3)

    print("  Agent finished normally.")


if __name__ == "__main__":
    print("Running fake agent…")
    fake_agent()
    print(f"Final paused state: {guard.is_paused}")
