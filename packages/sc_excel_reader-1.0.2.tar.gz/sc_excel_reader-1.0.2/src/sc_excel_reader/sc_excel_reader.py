"""ExcelReader class for extracting data from Excel files."""

from __future__ import annotations

import datetime as dt
import warnings
import zipfile
from pathlib import Path
from typing import Any

import openpyxl
from openpyxl import load_workbook, workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter, range_boundaries
from openpyxl.utils.exceptions import InvalidFileException


def _prepare_value(value: Any) -> Any:
    """Ensure cell values are Excel-compatible.

    Args:
        value: Raw cell value from a data row.

    Returns:
        The value unchanged, except that ``datetime.date`` instances are
        converted to ``datetime.datetime`` (required by openpyxl).
    """
    if isinstance(value, dt.datetime):
        return value
    if isinstance(value, dt.date):
        # openpyxl needs datetime for date cells to format correctly.
        return dt.datetime(value.year, value.month, value.day)  # noqa: DTZ001
    return value


class ExcelReader:
    """A class to read and extract data from Excel files (.xlsx, .xlsm, .xlsb).

    This class provides methods to load workbooks, extract data from sheets,
    tables, and named ranges, with robust error handling.
    """

    def __init__(self, file_path: Path | str, file_mode: str = "read") -> None:
        """Initialize the ExcelReader with the path to the Excel file.

        Warning: file_mode must be set to 'write' to use the write_table method.

        Args:
            file_path: Path to the Excel file, specified as a Path object or string.
            file_mode: Mode of operation, either 'read' (default) or 'write'.

        Raises:
            ImportError: If the file does not exist, is not a valid Excel file.
            RuntimeError: If file_mode is not 'read' or 'write'.
        """
        # Validate file_mode
        if file_mode not in {"read", "write"}:
            msg = f"Invalid file_mode '{file_mode}'. Must be 'read' or 'write'."
            raise RuntimeError(msg)

        if isinstance(file_path, str):
            file_path = Path(file_path)

        # If read mode, check if file exists and is a valid Excel file
        if file_mode == "read":
            if not file_path.is_file():
                msg = f"File {file_path} does not exist or is not a valid file."
                raise ImportError(msg)

            # Check extension to see if it's an Excel file
            if file_path.suffix.lower() not in {".xlsx", ".xlsm", ".xlsb"}:
                msg = f"File {file_path} is not a valid Excel file."
                raise ImportError(msg)

        self.file_mode = file_mode
        self.file_path = file_path

    def load_excel_workbook(self, *, data_only: bool = True, read_only: bool = False) -> workbook.Workbook:
        """Load an Excel workbook with robust error handling.

        Args:
            data_only: Whether to return cell values (not formulas).
            read_only: Use openpyxl's read-only mode for large files.

        Returns:
            workbook (workbook.Workbook): Workbook object.

        Raises:
            ImportError: If the file cannot be loaded due to various reasons.
        """
        warnings.filterwarnings("ignore", category=UserWarning, module="openpyxl")
        try:
            wb = load_workbook(
                filename=self.file_path, data_only=data_only, read_only=read_only
            )
        except FileNotFoundError:
            msg = f"File not found: {self.file_path}"
        except PermissionError:
            msg = f"Permission denied: {self.file_path}"
        except InvalidFileException:
            msg = f"Invalid Excel file format: {self.file_path}"
        except zipfile.BadZipFile:
            msg = f"Corrupt Excel file (not a valid ZIP): {self.file_path}"
        except OSError as e:
            msg = f"Unexpected error loading Excel file {self.file_path}: {e}"
        else:
            if wb is None:
                msg = f"Failed to load workbook from {self.file_path}. The file may be corrupted or not a valid Excel file."
            else:
                return wb

        raise ImportError(msg)

    def extract_data(self, source_name: str, source_type: str) -> list[dict]:
        """Extract data from an Excel file based on the source type and name.

        Expected the specified source type to be either:
        - An entire worksheet with the header in the first row (sheet)
        - A named range (range)
        - An Excel table (table)

        Args:
            source_name: Name of the sheet, table, or range to extract.
            source_type: Type of source ('sheet', 'table', or 'range').

        Returns:
            Data extracted as a list of dictionaries.

        Raises:
            ImportError: If the source type is invalid or if there are issues extracting data.
        """
        if source_type == "sheet":
            return self.extract_from_sheet(source_name)
        if source_type == "table":
            return self.extract_from_table(source_name)
        if source_type == "range":
            return self.extract_from_range(source_name)

        msg = f"Invalid source type '{source_type}'. Must be 'sheet', 'table', or 'range'."
        raise ImportError(msg)

    def extract_from_sheet(self, sheet_name: str) -> list[dict]:
        """Extract a sheet from an Excel file and return it as a list of dictionaries.

        Args:
            sheet_name: Name of the sheet to extract.

        Returns:
            A list containing the sheet data as dictionaries.

        Raises:
            ImportError: If the sheet cannot be loaded or if there are issues with the file.
        """
        try:
            wb = self.load_excel_workbook(data_only=True, read_only=True)

            if sheet_name not in wb.sheetnames:
                msg = f"Sheet '{sheet_name}' not found in Excel file {self.file_path}."
                raise ImportError(msg)  # noqa: TRY301

            ws = wb[sheet_name]

            # Get all data from the sheet
            data = []
            rows = list(ws.iter_rows(values_only=True))

            if not rows:
                return data

            # First row is header
            header = [str(cell).strip() if cell is not None else "" for cell in rows[0]]

            # Convert remaining rows to dictionaries
            for row in rows[1:]:
                # Skip empty rows
                if all(cell is None or not str(cell).strip() for cell in row):
                    continue

                row_dict = {}
                for i, cell in enumerate(row):
                    if i < len(header):
                        row_dict[header[i]] = cell
                data.append(row_dict)

        except ImportError:
            raise
        except Exception as e:
            msg = f"Error loading sheet '{sheet_name}' from Excel file {self.file_path}: {e}"
            raise ImportError(msg) from e

        return data

    def extract_from_table(self, table_name: str) -> list[dict]:
        """Extract a table from an Excel file and return it as a list of dictionaries.

        Args:
            table_name: Name of the table to extract.

        Returns:
            A list containing the table data as dictionaries.

        Raises:
            ImportError: If the table cannot be loaded or if there are issues with the file.
        """
        wb = self.load_excel_workbook(data_only=True, read_only=False)
        found = False
        selected_sheet = None
        table_range = None

        for sheet_name in wb.sheetnames:
            ws = wb[sheet_name]
            if table_name in ws.tables:
                table = ws.tables[table_name]
                table_range = table.ref  # e.g., "B3:F12"
                selected_sheet = sheet_name
                found = True
                break

        if not found:
            msg = f"Table '{table_name}' not found in any worksheet of the Excel file {self.file_path}."
            raise ImportError(msg)

        try:
            min_col, min_row, max_col, max_row = range_boundaries(table_range)  # pyright: ignore[reportArgumentType]

            if min_col is None or max_col is None or max_row is None or min_row is None:
                msg = f"Invalid table range boundaries for table '{table_name}' in file {self.file_path}."
                raise ImportError(msg)  # noqa: TRY301

            ws = wb[selected_sheet]  # pyright: ignore[reportArgumentType]

            # Extract data from the table range
            data = []
            rows = list(
                ws.iter_rows(
                    min_row=min_row,
                    max_row=max_row,
                    min_col=min_col,
                    max_col=max_col,
                    values_only=True,
                )
            )

            if not rows:
                return data

            # First row is header
            header = [str(cell).strip() if cell is not None else "" for cell in rows[0]]

            # Convert remaining rows to dictionaries
            for row in rows[1:]:
                # Skip empty rows
                if all(cell is None or not str(cell).strip() for cell in row):
                    continue

                row_dict = {}
                for i, cell in enumerate(row):
                    if i < len(header):
                        row_dict[header[i]] = cell
                data.append(row_dict)

        except Exception as e:
            msg = f"Error loading table '{table_name}' from Excel file {self.file_path}: {e}"
            raise ImportError(msg) from e

        return data

    def extract_from_range(self, range_name: str) -> list[dict]:  # noqa: PLR0914
        """Extract a named range from an Excel file and return it as a list of dictionaries.

        Args:
            range_name: Name of the range to extract.

        Returns:
            A list containing the range data as dictionaries.

        Raises:
            ImportError: If the range cannot be loaded or if there are issues with the file.
        """
        wb = self.load_excel_workbook(data_only=True, read_only=True)
        found = False
        sheet_name = None
        ref = None

        for defined_name in wb.defined_names:
            if defined_name == range_name:
                dn = wb.defined_names[defined_name]
                destinations = list(dn.destinations)
                if len(destinations) != 1:
                    msg = f"Range '{range_name}' refers to multiple areas, which is unsupported."
                    raise ImportError(msg)

                sheet_name, ref = destinations[0]
                found = True
                break

        if not found:
            msg = f"Range '{range_name}' not found in any worksheet of the Excel file {self.file_path}."
            raise ImportError(msg)

        try:
            min_col, min_row, max_col, max_row = range_boundaries(ref)  # pyright: ignore[reportArgumentType]

            if min_col is None or max_col is None or max_row is None or min_row is None:
                msg = f"Invalid range boundaries for range '{range_name}' in file {self.file_path}."
                raise ImportError(msg)  # noqa: TRY301

            ws = wb[sheet_name]  # pyright: ignore[reportArgumentType]

            # Extract data from the named range
            data = []
            rows = list(
                ws.iter_rows(
                    min_row=min_row,
                    max_row=max_row,
                    min_col=min_col,
                    max_col=max_col,
                    values_only=True,
                )
            )

            if not rows:
                return data

            # First row is header
            header = [str(cell).strip() if cell is not None else "" for cell in rows[0]]

            # Convert remaining rows to dictionaries
            for row in rows[1:]:
                # Skip empty rows
                if all(cell is None or not str(cell).strip() for cell in row):
                    continue

                row_dict = {}
                for i, cell in enumerate(row):
                    if i < len(header):
                        row_dict[header[i]] = cell
                data.append(row_dict)

        except Exception as e:
            msg = f"Error loading data range '{range_name}' from Excel file {self.file_path}: {e}"
            raise ImportError(msg) from e

        return data

    def write_table(
        self,
        sheet_name: str,
        table_name: str,
        columns: list[str],
        rows: list[list[Any]],
        *,
        freeze_header: bool = True,
    ) -> None:
        """Write a list of rows to an Excel file as a formatted table.

        If the file already exists, it will be overwritten. The method creates a new workbook and a
        new sheet with the specified name and writes the data as an Excel Table (ListObject) with
        the given table name.

        See the test_write_table() test case for an example of how to use this method.

        Args:
            sheet_name:  Name of the worksheet.
            table_name:  Name of the Excel Table (ListObject) created on the sheet.
            columns:     List of column header strings.
            rows:        List of row data (each row is a list aligned with columns).
            freeze_header: Whether to freeze the first row.

        Raises:
            RuntimeError: If the ExcelReader instance is not in 'write' mode.
        """
        if self.file_mode != "write":
            msg = f"ExcelReader instance initialized in '{self.file_mode}' mode. Cannot write to file."
            raise RuntimeError(msg)
        self.file_path.parent.mkdir(parents=True, exist_ok=True)

        wb = openpyxl.Workbook()
        ws = wb.active
        assert ws is not None
        ws.title = sheet_name

        # Write header row.
        header_fill = PatternFill("solid", fgColor="4472C4")
        header_font = Font(bold=True, color="FFFFFF")
        for col_idx, col_name in enumerate(columns, start=1):
            cell = ws.cell(row=1, column=col_idx, value=col_name)
            cell.fill = header_fill
            cell.font = header_font
            cell.alignment = Alignment(horizontal="center")

        # Write data rows.
        for row_idx, row in enumerate(rows, start=2):
            for col_idx, value in enumerate(row, start=1):
                cell = ws.cell(row=row_idx, column=col_idx, value=_prepare_value(value))
                cell.alignment = Alignment(horizontal="left")

        # Create an Excel Table.
        if rows:
            last_col = get_column_letter(len(columns))
            last_row = len(rows) + 1
            table_ref = f"A1:{last_col}{last_row}"
            table = openpyxl.worksheet.table.Table(displayName=table_name, ref=table_ref)  # pyright: ignore[reportAttributeAccessIssue]
            table.tableStyleInfo = openpyxl.worksheet.table.TableStyleInfo(  # pyright: ignore[reportAttributeAccessIssue]
                name="TableStyleMedium9", showFirstColumn=False,
                showLastColumn=False, showRowStripes=True, showColumnStripes=False,
            )
            ws.add_table(table)

        # Auto-size columns (approximate).
        for col_idx, col_name in enumerate(columns, start=1):
            col_letter = get_column_letter(col_idx)
            max_len = len(col_name)
            for row_idx in range(2, min(len(rows) + 2, 202)):  # sample first 200 rows
                val = ws.cell(row=row_idx, column=col_idx).value
                if val is not None:
                    max_len = max(max_len, len(str(val)))
            ws.column_dimensions[col_letter].width = min(max_len + 2, 40)

        if freeze_header:
            ws.freeze_panes = "A2"

        wb.save(self.file_path)
