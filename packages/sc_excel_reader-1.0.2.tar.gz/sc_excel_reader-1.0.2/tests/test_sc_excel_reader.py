import sys

from sc_excel_reader import ExcelReader

EXCEL_FILE = "tests/test_excel.xlsx"
EXCEL_WRITE_FILE = "tests/test_excel_write.xlsx"


def sum_list_values(data: list[dict]) -> float:
    """
    Helper function to sum values in a dictionary.

    Args:
        data (dict): The data to sum values from.

    Returns:
        int: The sum of all numeric values in the dictionary.
    """
    sum_value = sum(
        value
        for row in data
        for value in row.values()
        if isinstance(value, (int, float))
    )
    return sum_value


def test_load_sheet():
    """Test the ExcelReader class reading from a workheet."""
    # Create an instance of ExcelReader
    excel_reader = ExcelReader(EXCEL_FILE)

    # Read a specific sheet
    try:
        sheet_data = excel_reader.extract_data(source_name="Sheet", source_type="sheet")
        print(f"Extracted sheet data: {sheet_data}")
    except ImportError as e:
        print(f"Error reading sheet: {e}")
        sys.exit(1)
    else:
        assert isinstance(sheet_data, list), "Sheet data should be a list"
        assert len(sheet_data) > 0, "Sheet data should not be empty"
        assert sum_list_values(sheet_data) == 42, "Sum of values in the sheet should be 42"


def test_load_table():
    """Test the ExcelReader class reading from a table."""
    # Create an instance of ExcelReader
    excel_reader = ExcelReader(EXCEL_FILE)

    # Read a specific sheet
    try:
        sheet_data = excel_reader.extract_data(source_name="Table1", source_type="table")
        print(f"Extracted table data: {sheet_data}")
    except ImportError as e:
        print(f"Error reading sheet: {e}")
        sys.exit(1)
    else:
        assert isinstance(sheet_data, list), "Sheet data should be a list"
        assert len(sheet_data) > 0, "Sheet data should not be empty"
        assert sum_list_values(sheet_data) == 42, "Sum of values in the sheet should be 42"


def test_load_range():
    """Test the ExcelReader class reading from a range."""
    # Create an instance of ExcelReader
    excel_reader = ExcelReader(EXCEL_FILE)

    # Read a specific sheet
    try:
        sheet_data = excel_reader.extract_data(source_name="RangeTable1", source_type="range")
        print(f"Extracted range data: {sheet_data}")
    except ImportError as e:
        print(f"Error reading sheet: {e}")
        sys.exit(1)
    else:
        assert isinstance(sheet_data, list), "Sheet data should be a list"
        assert len(sheet_data) > 0, "Sheet data should not be empty"
        assert sum_list_values(sheet_data) == 42, "Sum of values in the sheet should be 42"


def test_write_table():
    """Test the ExcelReader class writing to a table."""
    # First read the TableComplex table from EXCEL_FILE to verify it exists and is read correctly
    # Create an instance of ExcelReader
    excel_reader = ExcelReader(EXCEL_FILE)

    # Read a specific sheet
    try:
        rows = excel_reader.extract_data(source_name="TableComplex", source_type="table")
    except ImportError as e:
        print(f"Error reading sheet: {e}")
        sys.exit(1)

    # Columns expected: Symbol, Date, Name, Currency, Price
    columns = ["Symbol", "Date", "Name", "Currency", "Price"]

    # Now write to a new file
    try:
        excel_writer = ExcelReader(EXCEL_WRITE_FILE, file_mode="write")
        excel_writer.write_table(sheet_name="Sheet 1", table_name="Table1", columns=columns, rows=[list(r.values()) for r in rows], freeze_header=True)
        print("Data written successfully to Table1.")
    except ImportError as e:
        print(f"Error writing to table: {e}")
        sys.exit(1)
    else:
        # Read back the data to verify it was written correctly
        try:
            sheet_data = excel_writer.extract_data(source_name="Table1", source_type="table")
        except ImportError as e:
            print(f"Error reading sheet after writing: {e}")
            sys.exit(1)
        else:
            assert isinstance(sheet_data, list), "Sheet data should be a list"
            assert len(sheet_data) > 0, "Sheet data should not be empty"
            assert sheet_data[0] == dict(zip(columns, list(rows[0].values()), strict=False)), "First row of written data should match the original data"


# test_load_sheet()
# test_load_table()
# test_load_range()
# test_write_table()
