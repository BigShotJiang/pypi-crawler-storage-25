def hi(name: str) -> str:
    return f"Hello, {name}!"

print(f"{__file__}, imported")