from __future__ import annotations

from datetime import datetime, timedelta
from typing import Any

import click

from azure_jobs.cli import main
from azure_jobs.core.record import read_records
from azure_jobs.utils.ui import show_jobs_table


@main.group(name="job")
def job_group() -> None:
    """View and manage Azure ML jobs."""


# ---------------------------------------------------------------------------
# Cloud job commands
# ---------------------------------------------------------------------------


@job_group.command(name="list")
@click.option(
    "-n", "--last", default=30, show_default=True,
    help="Number of jobs to show",
)
@click.option(
    "-s", "--status", default=None,
    type=click.Choice(
        ["Running", "Completed", "Failed", "Canceled", "Queued"],
        case_sensitive=False,
    ),
    help="Filter by job status (client-side)",
)
@click.option(
    "-e", "--experiment", default=None,
    help="Filter by experiment name (client-side)",
)
@click.option(
    "-T", "--type", "job_type", default=None,
    type=click.Choice(
        ["Command", "Pipeline", "Sweep", "AutoML"],
        case_sensitive=False,
    ),
    help="Filter by job type (server-side)",
)
@click.option("--tag", default=None, help="Filter by tag key (server-side)")
@click.option(
    "-a", "--archived", is_flag=True, default=False,
    help="Include archived jobs",
)
@click.option("--ws", "ws_name", default=None, help="Workspace name override")
def job_list(
    last: int,
    status: str | None,
    experiment: str | None,
    job_type: str | None,
    tag: str | None,
    archived: bool,
    ws_name: str | None,
) -> None:
    """List recent jobs in the cloud workspace."""
    from azure_jobs.core.rest_client import create_rest_client
    from azure_jobs.utils.ui import console, show_cloud_jobs_table

    client = create_rest_client(ws_name=ws_name)
    all_jobs: list[dict[str, Any]] = []
    next_link = None
    scanned = 0
    filtering = bool(status or experiment)
    max_scan = last * 5 if filtering else last
    view_type = "All" if archived else "ActiveOnly"

    with console.status("[bold cyan]Fetching jobs…[/bold cyan]", spinner="dots") as st:
        while len(all_jobs) < last and scanned < max_scan:
            jobs, next_link = client.list_jobs_page(
                next_link=next_link,
                top=last,
                list_view_type=view_type,
                job_type=job_type or "",
                tag=tag or "",
            )
            if not jobs:
                break
            for j in jobs:
                if status and j.get("status", "").lower() != status.lower():
                    continue
                if experiment and j.get("experiment", "") != experiment:
                    continue
                all_jobs.append(j)
                if len(all_jobs) >= last:
                    break
            scanned += len(jobs)
            st.update(
                f"[bold cyan]Fetching… {len(all_jobs)}/{last} jobs"
                + (f" ({scanned} scanned)" if filtering else "")
                + "[/bold cyan]"
            )
            if not next_link:
                break

    show_cloud_jobs_table(all_jobs[:last])


def _fetch_and_show_job(job_id: str, ws_name: str | None = None) -> None:
    """Resolve *job_id*, fetch via REST, and display details."""
    from requests.exceptions import HTTPError

    from azure_jobs.core.rest_client import create_rest_client
    from azure_jobs.utils.ui import console, error, show_job_detail

    name = _resolve_job_id(job_id)
    client = create_rest_client(ws_name=ws_name)

    try:
        with console.status("[bold cyan]Fetching job…[/bold cyan]", spinner="dots"):
            job = client.get_job(name)
    except HTTPError as exc:
        if exc.response is not None and exc.response.status_code == 404:
            error(f"Job not found: [bold]{name}[/bold]")
        else:
            error(f"Failed to fetch job: {exc}")
        raise SystemExit(1)

    show_job_detail(job)


@job_group.command(name="show")
@click.argument("name")
@click.option("--ws", "ws_name", default=None, help="Workspace name override")
def job_show(name: str, ws_name: str | None) -> None:
    """Show detailed info for a job.

    NAME can be the short aj ID (e.g. f8e7eb32) or the full Azure job name.
    """
    _fetch_and_show_job(name, ws_name=ws_name)


# ---------------------------------------------------------------------------
# Existing commands (status, cancel, logs)
# ---------------------------------------------------------------------------


@job_group.command(name="status")
@click.argument("job_id")
def job_status(job_id: str) -> None:
    """Query the status of a submitted job.

    JOB_ID can be the short aj ID (e.g. f8e7eb32) or the full Azure job name.
    """
    _fetch_and_show_job(job_id)


@job_group.command(name="cancel")
@click.argument("job_id")
def job_cancel(job_id: str) -> None:
    """Cancel a running job.

    JOB_ID can be the short aj ID or the full Azure job name.
    """
    from azure_jobs.core.rest_client import create_rest_client
    from azure_jobs.utils.ui import console, success, warning

    azure_name = _resolve_job_id(job_id)
    client = create_rest_client()

    # Check current status first
    with console.status("[bold cyan]Checking job…[/bold cyan]", spinner="dots"):
        job = client.get_job(azure_name)

    current = job.get("status", "")
    if current in ("Completed", "Failed", "Canceled"):
        warning(f"Job {job_id} already {current.lower()}")
        return

    with console.status("[bold cyan]Cancelling job…[/bold cyan]", spinner="dots"):
        client.cancel_job(azure_name)
        # Fetch updated status
        job = client.get_job(azure_name)

    final = job.get("status", "?")
    if final in ("Canceled", "CancelRequested"):
        success(f"Job {job_id} cancelled")
    else:
        warning(f"Job {job_id} status: {final}")


@job_group.command(name="logs")
@click.argument("job_id")
def job_logs(job_id: str) -> None:
    """Show logs from a job.

    Downloads log files directly (fast, works for running jobs too).
    JOB_ID can be the short aj ID or the full Azure job name.
    """
    from azure_jobs.core.rest_client import create_rest_client
    from azure_jobs.utils.ui import console

    _NO_LOG_STATUSES = ("Queued", "NotStarted", "Provisioning", "Preparing")

    azure_name = _resolve_job_id(job_id)

    # Phase 1: fast REST status check
    with console.status("[bold cyan]Checking job status…[/bold cyan]", spinner="dots"):
        client = create_rest_client()
        job = client.get_job(azure_name)

    status = job.get("status", "")
    display = job.get("display_name") or azure_name

    # Show header
    from azure_jobs.utils.ui import icon_style, short_portal_url

    icon, sty = icon_style(status)
    portal = job.get("portal_url", "") or f"ml.azure.com/runs/{azure_name}"
    console.print()
    console.print(f"[bold]Job Logs[/bold]  {display}  [{sty}]{icon} {status}[/{sty}]")
    console.print(f"[dim]Portal  {short_portal_url(portal)}[/dim]")
    console.print()

    if status in _NO_LOG_STATUSES:
        console.print(
            f"[yellow]Job is {status.lower()} — no logs available yet.[/yellow]"
        )
        return

    # Phase 2: download log files (fast, no polling)
    from azure_jobs.core.log_download import download_job_logs

    with console.status("[bold cyan]Downloading logs…[/bold cyan]", spinner="dots"):
        content, error_msg = download_job_logs(
            azure_name, status=status, rest_client=client,
        )

    if content:
        console.print(content)
        console.print()

    if error_msg:
        from rich.panel import Panel
        console.print(Panel(
            f"[red]{error_msg}[/red]",
            title="[bold red]Error[/bold red]",
            border_style="red",
        ))

    if not content and not error_msg:
        console.print("[dim]No logs available for this job.[/dim]")


# ---------------------------------------------------------------------------
# Job statistics
# ---------------------------------------------------------------------------


def _fetch_jobs_for_stats(
    n: int,
    ws_name: str | None,
    *,
    cutoff_utc: datetime | None = None,
) -> list[dict[str, Any]]:
    """Fetch up to *n* jobs for statistics.  Stops early if *cutoff_utc* is
    set and the page contains only jobs older than the cutoff."""
    from azure_jobs.core.rest_client import create_rest_client
    from azure_jobs.utils.ui import console

    client = create_rest_client(ws_name=ws_name)
    with console.status(
        "[bold cyan]Fetching jobs…[/bold cyan]", spinner="dots",
    ) as status_ctx:
        def _on_progress(count: int) -> None:
            status_ctx.update(f"[bold cyan]Fetching jobs… {count} loaded[/bold cyan]")
        return _fetch_jobs_from_client(
            client, n, cutoff_utc=cutoff_utc, console=console,
            on_progress=_on_progress,
        )


def _fetch_jobs_all_ws(
    n_per_ws: int,
    *,
    cutoff_utc: datetime | None = None,
) -> list[dict[str, Any]]:
    """Fetch jobs from all discovered workspaces."""
    from azure_jobs.core.rest_client import AzureARMClient, AzureMLJobsClient
    from azure_jobs.utils.ui import console, warning

    arm = AzureARMClient()
    with console.status(
        "[bold cyan]Discovering workspaces…[/bold cyan]", spinner="dots",
    ):
        workspaces = arm.list_ml_workspaces()

    if not workspaces:
        warning("No workspaces found")
        return []

    all_jobs: list[dict[str, Any]] = []
    for idx, ws in enumerate(workspaces, 1):
        ws_name = ws.get("name", "")
        with console.status(
            f"[bold cyan]Fetching jobs ({idx}/{len(workspaces)}) {ws_name}…[/bold cyan]",
            spinner="dots",
        ):
            try:
                client = AzureMLJobsClient(
                    subscription_id=ws["subscriptionId"],
                    resource_group=ws["resourceGroup"],
                    workspace_name=ws_name,
                )
                jobs = _fetch_jobs_from_client(
                    client, n_per_ws, cutoff_utc=cutoff_utc,
                    label=ws_name,
                )
                # Tag each job with its workspace for display
                for j in jobs:
                    j["_workspace"] = ws_name
                all_jobs.extend(jobs)
            except Exception:
                pass  # skip workspaces we can't access
    return all_jobs


def _fetch_jobs_from_client(
    client: Any,
    n: int,
    *,
    cutoff_utc: datetime | None = None,
    console: Any = None,
    label: str = "",
    on_progress: Any = None,
) -> list[dict[str, Any]]:
    """Fetch up to *n* jobs from one workspace client, stopping at *cutoff_utc*."""
    from azure_jobs.utils.time import _parse_utc

    jobs: list[dict[str, Any]] = []
    next_link = None

    while len(jobs) < n:
        page, next_link = client.list_jobs_page(
            next_link=next_link, top=n, list_view_type="ActiveOnly",
        )
        if not page:
            break

        past_cutoff = False
        for j in page:
            if cutoff_utc:
                raw = j.get("created_utc", "")
                if raw:
                    try:
                        if _parse_utc(raw) < cutoff_utc:
                            past_cutoff = True
                            break
                    except ValueError:
                        pass
            jobs.append(j)
            if len(jobs) >= n:
                break

        if on_progress:
            on_progress(len(jobs))

        if past_cutoff or not next_link:
            break
    return jobs[:n]


def _median(vals: list[int]) -> int:
    """Return the median of a sorted list of ints."""
    if not vals:
        return 0
    s = sorted(vals)
    mid = len(s) // 2
    if len(s) % 2 == 0:
        return (s[mid - 1] + s[mid]) // 2
    return s[mid]


@job_group.command(name="stats")
@click.option(
    "-n", "--last", default=None, type=int,
    help="Max jobs to analyse (per workspace with --all)",
)
@click.option(
    "-d", "--days", default=7, show_default=True, type=int,
    help="Only include jobs from the last N days (0 = no limit)",
)
@click.option(
    "-a", "--all", "all_ws", is_flag=True, default=False,
    help="Aggregate across all workspaces",
)
@click.option("--ws", "ws_name", default=None, help="Workspace name override")
def job_stats(
    last: int | None,
    days: int,
    all_ws: bool,
    ws_name: str | None,
) -> None:
    """Show statistics for recent jobs."""
    from collections import defaultdict
    from datetime import datetime as dt
    from datetime import timezone as tz

    from rich.box import ROUNDED
    from rich.panel import Panel
    from rich.table import Table

    from azure_jobs.utils.time import format_duration
    from azure_jobs.utils.ui import console, print_table

    cutoff: datetime | None = None
    if days:
        cutoff = dt.now(tz.utc) - timedelta(days=days)

    # Without -n and without --days, default to a reasonable scan limit
    max_jobs = last if last is not None else 10000

    if all_ws:
        jobs = _fetch_jobs_all_ws(max_jobs, cutoff_utc=cutoff)
    else:
        jobs = _fetch_jobs_for_stats(max_jobs, ws_name, cutoff_utc=cutoff)

    # Apply cutoff filter to collected jobs (in case a partial page slipped)
    if cutoff:
        from azure_jobs.utils.time import _parse_utc
        filtered = []
        for j in jobs:
            raw = j.get("created_utc", "")
            if raw:
                try:
                    if _parse_utc(raw) < cutoff:
                        continue
                except ValueError:
                    pass
            filtered.append(j)
        jobs = filtered

    if not jobs:
        console.print("[dim]No jobs found.[/dim]")
        return

    # ── Classify statuses ─────────────────────────────────────────────
    _TERMINAL = {"Completed", "Failed", "Canceled", "CancelRequested"}
    _RUNNING = {"Running", "Starting", "Preparing",
                "Provisioning", "Finalizing", "NotStarted"}
    _QUEUED = {"Queued"}

    total = len(jobs)
    by_status: dict[str, int] = defaultdict(int)
    for j in jobs:
        by_status[j.get("status", "Unknown")] += 1

    completed = by_status.get("Completed", 0)
    failed = by_status.get("Failed", 0)
    canceled = by_status.get("Canceled", 0) + by_status.get("CancelRequested", 0)
    active = sum(by_status[s] for s in _RUNNING if s in by_status)
    queued = sum(by_status[s] for s in _QUEUED if s in by_status)

    # Success rate = completed / (completed + failed)
    decided = completed + failed
    rate = f"{completed / decided * 100:.1f}%" if decided else "N/A"

    # Overall duration / queue aggregation (terminal jobs only)
    all_gpu_secs: list[int] = []
    all_queue: list[int] = []
    for j in jobs:
        if j.get("status") not in _TERMINAL:
            continue
        d = j.get("duration_secs")
        if d is not None and d > 0:
            nodes = j.get("nodes") or 1
            all_gpu_secs.append(d * nodes)
        q = j.get("queue_secs")
        if q is not None and q >= 0:
            all_queue.append(q)

    def _fmt_gpu_hours(secs: int) -> str:
        h = secs / 3600
        if h >= 100:
            return f"{h:,.0f}h"
        return f"{h:,.1f}h"

    total_gpu = _fmt_gpu_hours(sum(all_gpu_secs)) if all_gpu_secs else "—"
    avg_gpu = _fmt_gpu_hours(sum(all_gpu_secs) // len(all_gpu_secs)) if all_gpu_secs else "—"
    avg_queue = format_duration(sum(all_queue) // len(all_queue)) if all_queue else "—"
    med_queue = format_duration(_median(all_queue)) if all_queue else "—"

    # ── Overview panel ────────────────────────────────────────────────
    scope = f"last {days}d" if days else f"last {total}"
    if all_ws:
        ws_count = len({j.get("_workspace", "") for j in jobs})
        scope += f", {ws_count} workspace{'s' if ws_count != 1 else ''}"

    grid = Table.grid(padding=(0, 2))
    grid.add_column(style="key", justify="right")
    grid.add_column(style="value")

    grid.add_row("Jobs", str(total))
    grid.add_row("Completed", f"[green]{completed}[/green]")
    grid.add_row("Failed", f"[red]{failed}[/red]")
    grid.add_row("Canceled", str(canceled))
    if active:
        grid.add_row("Running", f"[cyan]{active}[/cyan]")
    if queued:
        grid.add_row("Queued", f"[yellow]{queued}[/yellow]")
    grid.add_row("Success Rate", rate)
    grid.add_row("GPU Hours", f"{total_gpu}  (avg {avg_gpu})")
    grid.add_row("Avg Queue", f"{avg_queue}  (median {med_queue})")

    console.print()
    console.print(Panel(
        grid,
        title=f"[bold]Job Statistics[/bold]  ({scope})",
        border_style="cyan",
        expand=False,
    ))

    # ── By experiment ─────────────────────────────────────────────────
    exp_stats: dict[str, dict[str, Any]] = defaultdict(
        lambda: {"total": 0, "completed": 0, "failed": 0, "canceled": 0,
                 "active": 0, "queued": 0, "gpu_secs": 0, "queue": []}
    )
    for j in jobs:
        exp = j.get("experiment") or "Default"
        es = exp_stats[exp]
        es["total"] += 1
        st = j.get("status", "")
        if st == "Completed":
            es["completed"] += 1
        elif st == "Failed":
            es["failed"] += 1
        elif st in ("Canceled", "CancelRequested"):
            es["canceled"] += 1
        if st in _RUNNING:
            es["active"] += 1
        if st in _QUEUED:
            es["queued"] += 1
        d = j.get("duration_secs")
        if d is not None and d > 0 and st in _TERMINAL:
            nodes = j.get("nodes") or 1
            es["gpu_secs"] += d * nodes
        q = j.get("queue_secs")
        if q is not None and q >= 0 and st in _TERMINAL:
            es["queue"].append(q)

    sorted_exps = sorted(exp_stats.items(), key=lambda x: x[1]["gpu_secs"], reverse=True)

    tbl = Table(title="By Experiment", box=ROUNDED, title_style="bold",
                header_style="bold", pad_edge=True)
    tbl.add_column("Experiment", style="cyan")
    tbl.add_column("Jobs", justify="right")
    tbl.add_column("▶", justify="right", style="cyan")
    tbl.add_column("⏳", justify="right", style="yellow")
    tbl.add_column("✓", justify="right", style="green")
    tbl.add_column("✗", justify="right", style="red")
    tbl.add_column("Rate", justify="right")
    tbl.add_column("GPU Hours", justify="right")

    for exp_name, es in sorted_exps:
        dec = es["completed"] + es["failed"]
        exp_rate = f"{es['completed'] / dec * 100:.0f}%" if dec else "—"
        exp_gpu = _fmt_gpu_hours(es["gpu_secs"]) if es["gpu_secs"] else "—"

        tbl.add_row(
            exp_name, str(es["total"]),
            str(es["active"]), str(es["queued"]),
            str(es["completed"]), str(es["failed"]),
            exp_rate, exp_gpu,
        )

    print_table(tbl)

    # ── By compute ────────────────────────────────────────────────────
    compute_stats: dict[str, dict[str, Any]] = defaultdict(
        lambda: {"total": 0, "completed": 0, "failed": 0,
                 "active": 0, "queued": 0, "gpu_secs": 0, "queue": []}
    )
    for j in jobs:
        comp = j.get("compute") or "unknown"
        cs = compute_stats[comp]
        cs["total"] += 1
        st = j.get("status", "")
        if st == "Completed":
            cs["completed"] += 1
        elif st == "Failed":
            cs["failed"] += 1
        if st in _RUNNING:
            cs["active"] += 1
        if st in _QUEUED:
            cs["queued"] += 1
        d = j.get("duration_secs")
        if d is not None and d > 0 and st in _TERMINAL:
            nodes = j.get("nodes") or 1
            cs["gpu_secs"] += d * nodes
        q = j.get("queue_secs")
        if q is not None and q >= 0 and st in _TERMINAL:
            cs["queue"].append(q)

    sorted_computes = sorted(
        compute_stats.items(), key=lambda x: x[1]["gpu_secs"], reverse=True,
    )

    tbl2 = Table(title="By Compute", box=ROUNDED, title_style="bold",
                 header_style="bold", pad_edge=True)
    tbl2.add_column("Compute", style="cyan")
    tbl2.add_column("Jobs", justify="right")
    tbl2.add_column("▶", justify="right", style="cyan")
    tbl2.add_column("⏳", justify="right", style="yellow")
    tbl2.add_column("✓", justify="right", style="green")
    tbl2.add_column("✗", justify="right", style="red")
    tbl2.add_column("Avg Queue", justify="right")
    tbl2.add_column("P50 Queue", justify="right")
    tbl2.add_column("Max Queue", justify="right")
    tbl2.add_column("GPU Hours", justify="right")

    for comp_name, cs in sorted_computes:
        q_avg = format_duration(sum(cs["queue"]) // len(cs["queue"])) if cs["queue"] else "—"
        q_p50 = format_duration(_median(cs["queue"])) if cs["queue"] else "—"
        q_max = format_duration(max(cs["queue"])) if cs["queue"] else "—"
        c_gpu = _fmt_gpu_hours(cs["gpu_secs"]) if cs["gpu_secs"] else "—"

        tbl2.add_row(
            comp_name, str(cs["total"]),
            str(cs["active"]), str(cs["queued"]),
            str(cs["completed"]), str(cs["failed"]),
            q_avg, q_p50, q_max, c_gpu,
        )

    print_table(tbl2)

    # ── By workspace (only with --all) ────────────────────────────────
    if all_ws:
        ws_stats: dict[str, dict[str, Any]] = defaultdict(
            lambda: {"total": 0, "completed": 0, "failed": 0,
                     "active": 0, "queued": 0, "gpu_secs": 0}
        )
        for j in jobs:
            wsn = j.get("_workspace") or "unknown"
            ws = ws_stats[wsn]
            ws["total"] += 1
            st = j.get("status", "")
            if st == "Completed":
                ws["completed"] += 1
            elif st == "Failed":
                ws["failed"] += 1
            if st in _RUNNING:
                ws["active"] += 1
            if st in _QUEUED:
                ws["queued"] += 1
            d = j.get("duration_secs")
            if d is not None and d > 0 and st in _TERMINAL:
                nodes = j.get("nodes") or 1
                ws["gpu_secs"] += d * nodes

        sorted_ws = sorted(ws_stats.items(), key=lambda x: x[1]["gpu_secs"], reverse=True)
        tbl_ws = Table(title="By Workspace", box=ROUNDED, title_style="bold",
                       header_style="bold", pad_edge=True)
        tbl_ws.add_column("Workspace", style="cyan")
        tbl_ws.add_column("Jobs", justify="right")
        tbl_ws.add_column("▶", justify="right", style="cyan")
        tbl_ws.add_column("⏳", justify="right", style="yellow")
        tbl_ws.add_column("✓", justify="right", style="green")
        tbl_ws.add_column("✗", justify="right", style="red")
        tbl_ws.add_column("Rate", justify="right")
        tbl_ws.add_column("GPU Hours", justify="right")

        for wsn, wst in sorted_ws:
            dec = wst["completed"] + wst["failed"]
            w_rate = f"{wst['completed'] / dec * 100:.0f}%" if dec else "—"
            w_gpu = _fmt_gpu_hours(wst["gpu_secs"]) if wst["gpu_secs"] else "—"
            tbl_ws.add_row(wsn, str(wst["total"]),
                           str(wst["active"]), str(wst["queued"]),
                           str(wst["completed"]),
                           str(wst["failed"]), w_rate, w_gpu)
        print_table(tbl_ws)

    # ── By user ───────────────────────────────────────────────────────
    user_counts: dict[str, dict[str, Any]] = defaultdict(
        lambda: {"total": 0, "completed": 0, "failed": 0,
                 "active": 0, "queued": 0, "gpu_secs": 0}
    )
    for j in jobs:
        user = j.get("created_by") or "unknown"
        if "@" in user:
            user = user.split("@")[0]
        uc = user_counts[user]
        uc["total"] += 1
        st = j.get("status", "")
        if st == "Completed":
            uc["completed"] += 1
        elif st == "Failed":
            uc["failed"] += 1
        if st in _RUNNING:
            uc["active"] += 1
        if st in _QUEUED:
            uc["queued"] += 1
        d = j.get("duration_secs")
        if d is not None and d > 0 and st in _TERMINAL:
            nodes = j.get("nodes") or 1
            uc["gpu_secs"] += d * nodes

    if len(user_counts) > 1:
        sorted_users = sorted(
            user_counts.items(), key=lambda x: x[1]["gpu_secs"], reverse=True,
        )
        tbl3 = Table(title="By User", box=ROUNDED, title_style="bold",
                     header_style="bold", pad_edge=True)
        tbl3.add_column("User", style="cyan")
        tbl3.add_column("Jobs", justify="right")
        tbl3.add_column("▶", justify="right", style="cyan")
        tbl3.add_column("⏳", justify="right", style="yellow")
        tbl3.add_column("✓", justify="right", style="green")
        tbl3.add_column("✗", justify="right", style="red")
        tbl3.add_column("Rate", justify="right")
        tbl3.add_column("GPU Hours", justify="right")

        for uname, uc in sorted_users:
            dec = uc["completed"] + uc["failed"]
            u_rate = f"{uc['completed'] / dec * 100:.0f}%" if dec else "—"
            u_gpu = _fmt_gpu_hours(uc["gpu_secs"]) if uc["gpu_secs"] else "—"
            tbl3.add_row(uname, str(uc["total"]),
                         str(uc["active"]), str(uc["queued"]),
                         str(uc["completed"]),
                         str(uc["failed"]), u_rate, u_gpu)
        print_table(tbl3)


# ---------------------------------------------------------------------------
# Local records (accessible via ``aj list``)
# ---------------------------------------------------------------------------


def _show_local_records(
    last: int, template: str | None, status: str | None,
) -> None:
    """Display local submission records."""
    records = read_records(last=last * 3 if (template or status) else last)
    if template:
        records = [r for r in records if r.get("template") == template]
    if status:
        records = [r for r in records if r.get("status") == status.lower()]
    records = records[:last]
    show_jobs_table(records)


@main.command(name="list")
@click.option("-n", "--last", default=20, show_default=True,
              help="Number of recent records to show")
@click.option("-t", "--template", default=None, help="Filter by template")
@click.option("-s", "--status", default=None,
              type=click.Choice(["success", "failed"], case_sensitive=False))
def list_local(last: int, template: str | None, status: str | None) -> None:
    """Show recent local job submissions."""
    _show_local_records(last, template, status)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _resolve_job_id(job_id: str) -> str:
    """Resolve a short aj ID to the Azure job name via record.jsonl."""
    records = read_records()
    for r in records:
        if r.get("id") == job_id:
            return r.get("azure_name") or job_id
    return job_id


# ---------------------------------------------------------------------------
# Top-level shortcuts
# ---------------------------------------------------------------------------

@main.command(name="js", hidden=True)
@click.argument("job_id")
def _alias_js(job_id: str) -> None:
    """Shortcut for ``aj job status``."""
    job_status.callback(job_id)


@main.command(name="jl", hidden=True)
@click.option("-n", "--last", default=30)
@click.option("-s", "--status", default=None)
@click.option("-e", "--experiment", default=None)
@click.option("-T", "--type", "job_type", default=None)
@click.option("--tag", default=None)
@click.option("-a", "--archived", is_flag=True, default=False)
@click.option("--ws", "ws_name", default=None)
def _alias_jl(
    last: int, status: str | None, experiment: str | None,
    job_type: str | None, tag: str | None, archived: bool,
    ws_name: str | None,
) -> None:
    """Shortcut for ``aj job list`` (cloud)."""
    job_list.callback(last, status, experiment, job_type, tag, archived, ws_name)


@main.command(name="jc", hidden=True)
@click.argument("job_id")
def _alias_jc(job_id: str) -> None:
    """Shortcut for ``aj job cancel``."""
    job_cancel.callback(job_id)


@main.command(name="jlogs", hidden=True)
@click.argument("job_id")
def _alias_jlogs(job_id: str) -> None:
    """Shortcut for ``aj job logs``."""
    job_logs.callback(job_id)
