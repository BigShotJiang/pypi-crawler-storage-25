from decimal import Decimal, getcontext

def calcular_pi(precisao_minima):
    """
    Calcula Pi com precisão suficiente para garantir que os saltos 
    do algoritmo não fiquem sem dígitos.
    """
    # Garantimos uma folga confortável de dígitos para os saltos dinâmicos
    prec = max(precisao_minima + 2000, precisao_minima * 3)
    getcontext().prec = prec + 5
    
    one = Decimal(1)
    two = Decimal(2)
    a = one
    b = one / two.sqrt()
    t = Decimal(1) / Decimal(4)
    p = one
    
    # Executa iterações suficientes para preencher a precisão
    for _ in range(int(prec ** 0.5) + 5):
        an = (a + b) / two
        b = (a * b).sqrt()
        t -= p * (a - an) * (a - an)
        a = an
        p *= two
        
    pi = (a + b) * (a + b) / (4 * t)
    # Retorna apenas a parte decimal (remove o "3.")
    return str(pi)[2:]

def letra_para_num(letra):
    return ord(letra) - ord('A') + 1

def num_para_letra(num):
    # O operador % lida nativamente com números negativos na descriptografia
    return chr(((num - 1) % 26) + ord('A'))

def criptografar(texto, casa_inicial):
    # Geramos uma boa quantidade de decimais a partir da casa inicial
    decimais = calcular_pi(casa_inicial)
    
    # Em Python, strings começam no índice 0. Se o usuário quer a 5ª casa, ela está no índice 4.
    ponteiro = casa_inicial - 1 
    
    resultado = []
    texto = texto.upper()
    primeira_letra = True
    
    for letra in texto:
        if letra.isalpha():
            valor_letra = letra_para_num(letra)
            
            if primeira_letra:
                # 1ª Regra: Pega apenas 1 algarismo
                deslocamento = int(decimais[ponteiro])
                ponteiro += 1  # Avança 1 casa para a próxima letra
                primeira_letra = False
            else:
                # 2ª Regra (A partir da 2ª letra): Pega 2 algarismos
                deslocamento = int(decimais[ponteiro : ponteiro + 2])
                
                # Avança o ponteiro somando o valor da própria letra atual (Regra do Salto Dinâmico)
                ponteiro += valor_letra
            
            novo_valor = valor_letra + deslocamento
            resultado.append(num_para_letra(novo_valor))
        else:
            # Mantém espaços e pontuações intactos
            resultado.append(letra)
            
    return "".join(resultado)

def descriptografar(texto, casa_inicial):
    decimais = calcular_pi(casa_inicial)
    ponteiro = casa_inicial - 1
    
    resultado = []
    texto = texto.upper()
    primeira_letra = True
    
    for letra in texto:
        if letra.isalpha():
            valor_cripto = letra_para_num(letra)
            
            if primeira_letra:
                deslocamento = int(decimais[ponteiro])
                ponteiro += 1
                primeira_letra = False
            else:
                deslocamento = int(decimais[ponteiro : ponteiro + 2])
                
                # Na descriptografia, para saber o quanto saltar, precisamos primeiro
                # descobrir qual era a letra original correspondente a este caractere criptografado.
                valor_original = valor_cripto - deslocamento
                letra_original_num = ((valor_original - 1) % 26) + 1
                
                # O salto deve ser baseado no valor da letra original (que foi usada na criptografia)
                ponteiro += letra_original_num
            
            original_valor = valor_cripto - deslocamento
            resultado.append(num_para_letra(original_valor))
        else:
            resultado.append(letra)
            
    return "".join(resultado)

def main():
    while True:
        print("\n=== MENU ===")
        print("1 - Criptografar")
        print("2 - Descriptografar")
        print("0 - Sair")
        
        escolha = input("Digite sua opção: ")

        if escolha == "1":
            print("\n--- CRIPTOGRAFAR ---")
            texto = input("Digite o texto a ser criptografado: ")
            
            # Validação simples para o usuário não digitar letras na casa decimal
            try:
                casa = int(input("Digite a casa decimal inicial de Pi (Ex: 5): "))
                if casa < 1:
                    print("Por favor, digite um número maior ou igual a 1.")
                    continue
            except ValueError:
                print("Entrada inválida! Digite um número inteiro.")
                continue
                
            criptografado = criptografar(texto, casa)
            print(f"\nTexto criptografado:\n{criptografado}")
            print("-" * 20)

        elif escolha == "2":
            print("\n--- DESCRIPTOGRAFAR ---")
            texto = input("Digite o texto criptografado: ")
            
            try:
                casa = int(input("Digite a casa decimal inicial de Pi: "))
                if casa < 1:
                    print("Por favor, digite um número maior ou igual a 1.")
                    continue
            except ValueError:
                print("Entrada inválida! Digite um número inteiro.")
                continue
                
            original = descriptografar(texto, casa)
            print(f"\nTexto original:\n{original}")
            print("-" * 20)

        elif escolha == "0":
            print("\nSaindo... Até a próxima, meu amigo!")
            break  # Quebra o loop e encerra o programa de forma limpa

        else:
            print("\nOpção inválida! Escolha 1, 2 ou 0.")

if __name__ == "__main__":
    main()
