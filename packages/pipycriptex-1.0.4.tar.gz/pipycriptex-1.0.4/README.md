# 🥧 PiPycryptex (O Caos das Casas Decimais de Pi)

Bem-vindo ao **pipycryptex**, um desafio científico de criptografia polialfabética dinâmica criado do zero! 

Este projeto nasceu de uma provocação entre eu e um amigo chamado Kaue que também curte criptografia: *Como transformar a expansão decimal infinita do número Pi em um fluxo caótico de criptografia que destrói qualquer tentativa de análise de frequência tradicional?*

O resultado é um CLI em Python que utiliza ponteiros dinâmicos e autocifra (autokey) para gerar textos cifrados onde uma mesma letra nunca se repete com o mesmo caractere.

---

## 🧠 Como Funciona o Algoritmo? (O Raio-X do Caos)

Diferente de uma Cifra de César comum, que usa um deslocamento fixo, o **pipycryptex** caminha pela expansão de Pi (`1415926535...`) de forma viva. O alfabeto funciona de forma circular ($A=1$ até $Z=26$, voltando ao $A$ via operação de módulo).

Imagine que queremos criptografar a palavra **CASA** ($C=3, A=1, S=19, A=1$) escolhendo a **5ª casa decimal de Pi** como ponto de partida:

### 1ª Letra (C = 3):
* O algoritmo vai até a 5ª casa decimal de Pi (que é o número `9`).
* **Regra da 1ª Letra:** Pega apenas **1 algarismo**.
* **Operação:** $3 \text{ (C)} + 9 = 12 \rightarrow$ **L**
* O ponteiro avança 1 casa no Pi.

### 2ª Letra (A = 1):
* O ponteiro está na 6ª casa. 
* **Regra Geral (Daqui até o fim):** Pega sempre **2 algarismos** juntos.
* Na 6ª e 7ª casa de Pi, encontramos os números `2` e `6` $\rightarrow$ formando o número `26`.
* **Operação:** $1 \text{ (A)} + 26 = 27$. Aplicando o módulo do alfabeto, $27 \pmod{26} = 1 \rightarrow$ **A**
* O ponteiro agora dá um **Salto Dinâmico Autoguiado**: ele avança somando o valor da própria letra atual ($+1$).

### 3ª Letra (S = 19):
* O ponteiro saltou para a frente baseando-se na letra anterior. Ele lê os próximos 2 algarismos (vamos supor que sejam `8` e `3` $\rightarrow$ `83`).
* **Operação:** $19 \text{ (S)} + 83 = 102 \pmod{26} = 24 \rightarrow$ **X**
* **O Efeito Cascata:** Se um atacante errar uma única letra na descriptografia, o ponteiro dele vai para o lugar errado no Pi e todo o resto do texto vira estática pura.

---

## 🔐 O Futuro: Constantes Privadas e Multicamadas Mentais Dinâmicas

O verdadeiro potencial de defesa do **pipycryptex** aponta para um futuro revolucionário na segurança: a criação de **Constantes Irracionais e Transcendentais Privadas**. 

Hoje, a expansão do Pi é pública, o que permite ataques de força bruta testando posições sequenciais. Mas e se você descobrisse ou gerasse uma constante matemática própria? Uma sequência infinita, não periódica e **totalmente privada**, cuja fórmula de geração é conhecida apenas por você e pelo receptor. Sem um banco de dados público dessas casas decimais, a engenharia reversa e a força bruta se tornam matematicamente impossíveis.

A partir dessa constante privada, o algoritmo permite re-criptografar o texto múltiplas vezes usando uma **Chave Mental Fracionada**. Cada palavra de uma frase ou poema memorizado por você se transforma em uma camada independente de criptografia em cascata.

A vantagem definitiva? Essa estrutura de camadas fica guardada apenas na sua mente. É uma senha fácil de lembrar (você jamais esqueceria), mas que gera um labirinto geométrico no Pi que nunca toca o disco rígido, ficando 100% imune a malwares ou spywares.

### 💡 A Lógica da Frase "Meu Amor"

Imagine que você escolheu a frase mental `"meu amor"`. Ela é composta por duas palavras, o que significa que o seu texto passará por **mais duas camadas consecutivas de criptografia** além da constante principal. 

O sistema converte cada palavra em uma sequência numérica baseada na posição das letras no alfabeto:
1. **Palavra "MEU":** Letras $M=13, E=5, U=21 \rightarrow$ vira o número **13521**.
2. **Palavra "AMOR":** Letras $A=1, M=13, O=15, R=18 \rightarrow$ vira o número **1131518**.

#### O Processo em Cascata:
* **Camada Base:** Você criptografa o livro original usando a sua constante secreta na casa inicial desejada.
* **Camada 2 (Palavra "MEU"):** Você pega o resultado da camada anterior e aplica o algoritmo novamente, mas usando o número **13521** como a nova casa inicial do Pi. O ponteiro vai saltar de forma totalmente diferente.
* **Camada 3 (Palavra "AMOR"):** Você pega o resultado da Camada 2 e passa a faca mais uma vez, aplicando o algoritmo com a casa inicial **1131518**.

### 🎼 O Limite é a Sua Imaginação: Criptografia por Soneto ou poesias faceis de memorizar 

Se duas palavras já geram um nível de caos absurdo, imagine usar **um soneto inteiro de poesia**. 

Cada palavra do poema será processada na ordem exata em que aparece. Se o soneto tiver 100 palavras, e você quiser criptografar um livro de 500 páginas, o seu livro de 500 páginas será criptografado **100 vezes seguidas**, alternando o ponto de partida e a dinâmica de saltos no Pi 100 vezes! 

Para um criptoanalista, tentar desatar esse nó estatístico sem saber qual poema você tem na cabeça (e em qual ordem) é uma tarefa virtualmente impossível. Você destrói qualquer resquício de estrutura da linguagem original.

---

## ⚡ E que se foda a quantidade de RAM! 💻🔥

Uma das partes mais insanas e divertidas desse algoritmo é o seu custo computacional para chaves colossais. Como o gerador precisa calcular Pi de forma global e sequencial para achar a casa inicial desejada, o consumo de hardware escala de forma brutal.

Imagine criar uma criptografia que precisou de **10 Terabytes de memória RAM** só para gerar o fluxo de dígitos de uma camada? E aí você vai lá e faz isso três vezes, criando três camadas consecutivas de puro caos de hardware. É a união da segurança lógica com o estresse absoluto de silício! Se o atacante não tiver um supercomputador de um centro de dados inteiro, ele não consegue nem começar a processar a busca.

---

## 🛠️ Como Instalar e Rodar
pip install pipycryptex 

basta escolher um texto qualquer e alguma casa decimal de pi para começar a testar a criptografia
