# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at https://prosperitylicense.com/versions/3.0.0
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: https://github.com/CoReason-AI/coreason-ecosystem

import asyncio
import importlib.metadata
import json
from pathlib import Path


async def execute_init(
    project_name: str,
    topology: str = "base",
    lang: str = "python",
) -> None:
    """Synthesize a mathematically verified Swarm workspace scaffolding."""
    if "/" in project_name or "\\" in project_name:
        raise ValueError("Project name cannot contain path separators")

    project_path = Path(project_name).resolve()
    cwd = Path.cwd().resolve()
    if not project_path.is_relative_to(cwd) or project_path == cwd:
        raise ValueError(
            "Project path must be a subdirectory of the current working directory"
        )

    project_path.mkdir(parents=True, exist_ok=True)

    vscode_dir = project_path / ".vscode"
    vscode_dir.mkdir(parents=True, exist_ok=True)
    settings = {
        "coreason.isEpistemicWorkspace": True,
        "coreason.telemetry.meshPort": 8000,
        "editor.formatOnSave": True,
    }
    with (vscode_dir / "settings.json").open("w") as f:
        json.dump(settings, f, indent=4)

    if lang == "rust":
        # Rust Scaffolding
        src_dir = project_path / "src"
        src_dir.mkdir(parents=True, exist_ok=True)

        cargo_toml_content = f"""[package]
name = "{project_name}"
version = "0.1.0"
edition = "2021"

[lib]
crate-type = ["cdylib"]

[dependencies]
extism-pdk = "1.0"
"""
        (project_path / "Cargo.toml").write_text(cargo_toml_content)

        rust_template = """use extism_pdk::*;

#[plugin_fn]
pub fn execute(input: String) -> FnResult<String> {
    Ok("Capability Executed Successfully!".to_string())
}
"""
        (src_dir / "lib.rs").write_text(rust_template)

        tasks = {
            "version": "2.0.0",
            "tasks": [
                {
                    "label": "Crystallize Capabilities",
                    "command": "cargo build --target wasm32-unknown-unknown --release && cp target/wasm32-unknown-unknown/release/*.wasm .coreason/bin/",
                    "type": "shell",
                },
                {"label": "Ignite Swarm", "command": "coreason up", "type": "shell"},
            ],
        }
        with (vscode_dir / "tasks.json").open("w") as f:
            json.dump(tasks, f, indent=4)

    elif lang == "go":
        # Go Scaffolding
        go_mod = f"""module {project_name}

go 1.21

require github.com/extism/go-pdk v1.0.0
"""
        (project_path / "go.mod").write_text(go_mod)

        go_template = """package main

import (
\t"github.com/extism/go-pdk"
)

//export execute
func execute() int32 {
\tpdk.OutputString("Capability Executed Successfully!")
\treturn 0
}

func main() {}
"""
        (project_path / "main.go").write_text(go_template)

        tasks = {
            "version": "2.0.0",
            "tasks": [
                {
                    "label": "Crystallize Capabilities",
                    "command": "tinygo build -o .coreason/bin/capability.wasm -target wasi main.go",
                    "type": "shell",
                },
                {"label": "Ignite Swarm", "command": "coreason up", "type": "shell"},
            ],
        }
        with (vscode_dir / "tasks.json").open("w") as f:
            json.dump(tasks, f, indent=4)

    else:
        # 1. Directory Genesis
        package_name = project_name.replace("-", "_")
        package_dir = project_path / "src" / package_name
        (package_dir / "agents").mkdir(parents=True, exist_ok=True)
        (package_dir / "agents" / "__init__.py").touch()
        (package_dir / "capabilities").mkdir(parents=True, exist_ok=True)
        (package_dir / "capabilities" / "__init__.py").touch()
        (package_dir / "intents").mkdir(parents=True, exist_ok=True)
        (package_dir / "intents" / "__init__.py").touch()
        (package_dir / "__init__.py").touch()

        # 2. Dependency Locking
        def get_version(pkg_name: str) -> str:
            try:
                return importlib.metadata.version(pkg_name)
            except importlib.metadata.PackageNotFoundError:
                return "0.1.0"  # Fallback

        runtime_version = get_version("coreason-runtime")
        manifest_version = get_version("coreason-manifest")
        ecosystem_version = get_version("coreason-ecosystem")

        pyproject_toml_content = f"""[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"

[project]
name = "{project_name}"
version = "0.1.0"
description = "Autopoietically generated CoReason Swarm Workspace"
requires-python = ">=3.14"
dependencies = [
    "coreason-runtime>={runtime_version}",
    "coreason-manifest>={manifest_version}",
    "coreason-ecosystem>={ecosystem_version}",
    "componentize-py<0.14",
    "python-pdk"
]

[tool.hatch.build.targets.wheel]
packages = ["src/{package_name}"]

[dependency-groups]
dev = [
    "pre-commit"
]

[tool.uv]
required-environments = ["sys_platform == 'linux' and platform_machine == 'x86_64'"]

[tool.uv.sources]
python-pdk = {{ git = "https://github.com/extism/python-pdk" }}
"""
        (project_path / "pyproject.toml").write_text(pyproject_toml_content)

        # 4. Topological Routing
        cap_dir = package_dir / "capabilities"
        cap_template = """# Copyright (c) 2026 CoReason, Inc.
# Licensed under the Prosperity Public License 3.0

import extism_pdk
import json

@extism_pdk.plugin_fn
def execute():
    input_data = extism_pdk.input()
    extism_pdk.output("Capability Executed Successfully!")
"""
        if topology == "medallion":
            (cap_dir / "bronze_ingest.py").write_text(cap_template)
            (cap_dir / "silver_cleanse.py").write_text(cap_template)
            (cap_dir / "gold_route.py").write_text(cap_template)
        elif topology == "rag":
            (cap_dir / "embed_document.py").write_text(cap_template)
            (cap_dir / "retrieve_context.py").write_text(cap_template)
        else:  # base
            (cap_dir / "example_tool.py").write_text(cap_template)

        tasks = {
            "version": "2.0.0",
            "tasks": [
                {
                    "label": "Crystallize Capabilities",
                    "command": "coreason build",
                    "type": "shell",
                },
                {"label": "Ignite Swarm", "command": "coreason up", "type": "shell"},
            ],
        }
        with (vscode_dir / "tasks.json").open("w") as f:
            json.dump(tasks, f, indent=4)

        # 6. Local Immunological System
        pre_commit_config = """repos:
  - repo: local
    hooks:
      - id: epistemic-seal-check
        name: Epistemic Seal Check
        entry: coreason registry audit
        language: system
        pass_filenames: false
"""
        (project_path / ".pre-commit-config.yaml").write_text(pre_commit_config)

    process = await asyncio.create_subprocess_exec("git", "init", cwd=str(project_path))
    await process.communicate()
