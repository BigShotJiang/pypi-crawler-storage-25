# Server Guardian MCP

The most comprehensive server management MCP tool available. **47 tools**, **8 connection types**, anomaly detection, auto-remediation playbooks, live web dashboard, compliance reports, team RBAC, PagerDuty/Telegram/OpsGenie integrations — all through Claude.

> **"Check the health of production, restart failed services, show me what happened last night, and generate a compliance report."** — One conversation. Done.

## Live Dashboard

```bash
python -m server_guardian_mcp dashboard           # start on port 8080
python -m server_guardian_mcp dashboard --port 9090
```

Real-time web UI with auto-refresh every 30 seconds. Dark theme, Chart.js charts, active alerts feed, incident timeline.

## Why Server Guardian?

| What you say to Claude | What happens |
|------------------------|-------------|
| "Is my server okay?" | SSH in, check CPU/RAM/disk/temp, detect anomalies vs baseline |
| "Why is production slow?" | Check processes, disk, logs, identify the bottleneck |
| "Restart all failed services" | Find failed services, restart each, verify recovery |
| "What happened overnight?" | Generate incident narrative from alerts, service events, playbook runs |
| "Is anything unusual?" | Compare current metrics against statistical baselines, flag anomalies |
| "Fix it automatically" | Run playbooks: clear disk, restart services, renew SSL certs |
| "Generate a security report" | Run 10-point audit, produce branded HTML report (SOC2/ISO prep) |
| "Deploy latest code" | Git pull on server, verify branch, show last commit |
| "Show me the dashboard" | Launch real-time web UI with charts and alerts |

## Benchmarks vs Alternatives

| Feature | Server Guardian | ssh-mcp | mcp-ssh-manager | HomeButler |
|---------|:-:|:-:|:-:|:-:|
| **Total tools** | **47** | 2 | 37 | 20 |
| **Connection types** | **8** | 1 | 1 | 1 |
| Smart anomaly detection | **Yes** | - | - | - |
| Auto-remediation playbooks | **Yes** | - | - | - |
| Live web dashboard (Chart.js) | **Yes** | - | - | - |
| Compliance report generation | **Yes** | - | - | - |
| Incident replay narratives | **Yes** | - | - | - |
| Team RBAC (admin/operator/viewer) | **Yes** | - | - | - |
| PagerDuty / Telegram / OpsGenie | **Yes** | - | - | - |
| Database queries | **MySQL/PG/SQLite** | - | MySQL/PG/Mongo | - |
| SSL certificate monitoring | **Yes** | - | - | - |
| HTTP endpoint checks | **Yes** | - | - | - |
| 10-point security audit | **Yes** | - | - | - |
| Cron job management | **Yes** | - | - | - |
| User & SSH key management | **Yes** | - | - | - |
| Package management (apt/yum) | **Yes** | - | - | - |
| Nginx management | **Yes** | - | - | - |
| Git deploy (pull/switch/log) | **Yes** | - | - | - |
| Firewall management (UFW) | **Yes** | - | - | - |
| Disk usage forecasting | **Yes** | - | - | - |
| Background watchdog daemon | **Yes** | - | - | Yes |
| Email/Slack/Discord alerts | **Yes** | - | - | Yes |
| SQLite monitoring history | **Yes** | - | - | - |
| Multi-cloud (AWS/GCP/Azure) | **Yes** | - | - | - |
| Docker container management | **Yes** | - | Yes | Yes |
| Shell injection prevention | **Yes** | - | - | - |
| Rate limiting & audit log | **Yes** | - | - | - |

## Quick Install

### Claude Code (recommended)
```bash
claude mcp add server-guardian -- uvx server-guardian-mcp
```

### pip
```bash
pip install server-guardian-mcp
claude mcp add server-guardian -- python -m server_guardian_mcp
```

### From source
```bash
git clone https://github.com/MdNazishArmanShorthillsAI/server-guardian-mcp
cd server-guardian-mcp
pip install -e .
claude mcp add server-guardian -- python -m server_guardian_mcp
```

## Setup (2 minutes)

### 1. Create your .env
```bash
cp .env.example .env
```

### 2. Add your servers

**8 connection types supported:**

```env
# SSH (Linux/Mac servers — most common)
SERVER_PROD=ssh,203.0.113.10,22,deploy,key,~/.ssh/prod_key,Production
SERVER_DEV=ssh,192.168.1.50,2222,root,password,changeme,Dev Box

# Local machine (your own computer, no network)
SERVER_LOCAL=local,,,,,My Machine

# Docker containers
SERVER_APP=docker,my-container,,,,App Container

# Windows servers (requires: pip install pywinrm)
SERVER_WIN=winrm,10.0.0.50,5985,admin,password,P@ssw0rd,Windows Server

# Kubernetes pods
SERVER_POD=k8s,my-pod/my-namespace,,,,K8s Pod

# AWS EC2 via SSM (no SSH needed, requires aws CLI)
SERVER_AWS=aws-ssm,i-0abc123def,,us-east-1,,my-profile,AWS Production

# GCP Compute Engine (requires gcloud CLI)
SERVER_GCP=gcloud,my-instance,,us-central1-a,,my-project,GCP Server

# Azure VMs (requires az CLI)
SERVER_AZURE=azure,my-vm,,my-resource-group,,,Azure Server
```

Backward compatible — old format without type field still works:
```env
SERVER_LEGACY=10.0.0.5,,root,key,~/.ssh/id_rsa,Home Lab
```

### 3. Auto-discover existing servers
Already have servers in `~/.ssh/config`? Just ask Claude:
> "Discover my SSH servers"

It reads your SSH config and shows you ready-to-paste `.env` lines.

### 4. Add aliases (optional)
```env
SERVER_ALIASES=prod:PROD,stg:STAGING,dev:DEV
```
Now say "check health of prod" instead of "check health of PROD".

## All 47 Tools

### Core Server Management (6)
| Tool | What it does |
|------|-------------|
| `list_all_servers` | Show all servers with online/offline status and latency |
| `check_server_health` | Full snapshot: CPU, RAM, disk, swap, temp, load, top processes, network |
| `run_shell_commands` | Run one or more shell commands on any server |
| `run_shell_script` | Run multi-line bash scripts with shared variables |
| `fetch_system_logs` | Fetch dmesg/syslog/journal/auth/nginx/custom logs with grep filter |
| `list_running_processes` | Processes sorted by CPU or memory, with name filter |

### Service Management (5)
| Tool | What it does |
|------|-------------|
| `manage_systemd_service` | Start/stop/restart/enable/disable/status/logs for any systemd service |
| `list_all_services` | List ALL systemd services, filter by running/failed/inactive |
| `find_failed_services` | Find every crashed/failed service in one call |
| `restart_failed_services` | Bulk restart failed services — pass names or "ALL_FAILED" |
| `watch_service_status` | Quick is-active + is-enabled check for specific services |

### Monitoring & Alerting (5)
| Tool | What it does |
|------|-------------|
| `check_ssl_certificate` | SSL cert expiry, chain, issuer for any domain (no SSH) |
| `check_http_endpoint` | HTTP status, response time, headers for any URL (no SSH) |
| `monitor_server_health` | Health check + store in SQLite + auto-alert on thresholds |
| `monitor_endpoints` | Check HTTP/SSL targets + store + alert on failures |
| `get_active_alerts` | Show unresolved alerts grouped by severity |

### Docker (2)
| Tool | What it does |
|------|-------------|
| `list_docker_containers` | Containers with CPU, memory, network, block I/O stats |
| `fetch_docker_logs` | Container logs with grep filter and time range |

### Disk & Network (2)
| Tool | What it does |
|------|-------------|
| `analyze_disk_usage` | Find largest items, files >100MB, inode usage, rotated logs |
| `inspect_network` | Listening ports, active connections, interfaces, DNS, routing |

### File Operations (3)
| Tool | What it does |
|------|-------------|
| `read_remote_file` | Read files on server (tail/head/all) with metadata |
| `upload_file_to_server` | SFTP upload with size verification |
| `download_file_from_server` | SFTP download |

### Security & Compliance (3)
| Tool | What it does |
|------|-------------|
| `run_security_audit` | 10-point check: SSH config, firewall, failed logins, updates, sudo, world-writable files |
| `manage_firewall` | UFW/iptables: status, allow, deny, delete rules, enable/disable |
| `generate_compliance_report_tool` | Branded HTML security report with score (A-F), suitable for SOC2/ISO |

### Multi-Server (2)
| Tool | What it does |
|------|-------------|
| `run_on_all_servers` | Same commands on multiple servers — pass ["ALL"] for all |
| `compare_across_servers` | Spot config drift: same command, side-by-side results |

### Database (1)
| Tool | What it does |
|------|-------------|
| `query_database` | Run SQL queries on MySQL, PostgreSQL, or SQLite on any server |

### System Administration (4)
| Tool | What it does |
|------|-------------|
| `manage_cron_jobs` | List, add, remove cron jobs on any server |
| `manage_users` | List users, user info, add SSH keys, list keys, who is logged in |
| `manage_packages` | List/install/remove/upgrade packages (apt, yum, dnf, apk auto-detected) |
| `manage_nginx` | Status, list sites, show config, test, reload, restart, access/error logs |

### Git Deploy (1)
| Tool | What it does |
|------|-------------|
| `git_deploy` | Status, pull, log, branch, switch, stash, diff on server git repos |

### Discovery (1)
| Tool | What it does |
|------|-------------|
| `discover_ssh_servers` | Auto-discover servers from ~/.ssh/config with ready-to-paste .env lines |

### Dashboard & Analytics (6)
| Tool | What it does |
|------|-------------|
| `multi_server_dashboard` | One-call summary of ALL servers: health, CPU, RAM, disk, failed services |
| `get_monitoring_history` | Query health trends, service events, endpoint checks from SQLite |
| `get_incident_timeline` | Chronological event log: "what happened on PROD in the last 6 hours?" |
| `forecast_disk_usage` | Predict when disk will be full based on growth rate |
| `generate_html_dashboard` | Self-contained HTML status page — open in any browser |
| `resolve_alert` | Mark an alert as resolved |

### Intelligence & Automation (3)
| Tool | What it does |
|------|-------------|
| `detect_anomalies_tool` | Statistical anomaly detection — flags metrics >2.5 sigma from baseline |
| `replay_incident` | Generate chronological narrative from alerts, service events, playbook runs |
| `manage_playbooks` | Auto-remediation: disk cleanup, service restart, SSL renewal, custom playbooks |

### Team & Integrations (3)
| Tool | What it does |
|------|-------------|
| `team_manage` | RBAC user management: admin/operator/viewer roles with API keys |
| `check_integrations` | Status and test for PagerDuty, Telegram, OpsGenie |
| `live_dashboard_info` | How to start the live web dashboard and available API endpoints |

## Smart Anomaly Detection

Server Guardian learns what "normal" looks like for each server and flags deviations.

```
Tell Claude: "detect anomalies on PROD"
```

- Builds baselines per metric (CPU, RAM, disk, temp) grouped by hour and day of week
- Flags values >2.5 standard deviations from the mean
- No ML dependencies — pure statistics from SQLite data
- Minimum 5 samples before trusting a baseline

## Auto-Remediation Playbooks

Define conditions and actions. When a trigger fires, the playbook runs automatically.

**5 built-in playbooks:**
| Playbook | Trigger | Action |
|----------|---------|--------|
| `disk_cleanup` | Disk > 90% | Clear journal, /tmp, old logs, package cache |
| `restart_failed_services` | Failed services detected | Restart each failed service |
| `high_memory_cleanup` | Memory > 95% | Drop filesystem caches |
| `high_cpu_investigation` | CPU load > 3x cores | Log top CPU consumers |
| `ssl_renewal` | SSL cert < 7 days | Run certbot renew, reload nginx |

**Custom playbooks:** Drop JSON files in `~/.server-guardian-mcp/playbooks/`:
```json
{
  "name": "custom_cleanup",
  "trigger": {"metric": "disk_used_pct", "operator": ">", "value": 85},
  "actions": [
    {"type": "command", "run": "find /tmp -type f -mtime +3 -delete 2>&1 || true"},
    {"type": "command", "run": "df -h / | tail -1"}
  ],
  "cooldown_minutes": 60
}
```

## Compliance Reports

Generate branded HTML security reports from the 10-point audit:

```
Tell Claude: "generate a compliance report for PROD"
```

- Security score (0-100) with letter grade (A-F)
- Detailed check results with status badges
- Active alerts section
- Print-friendly, works in any browser
- Suitable for SOC2/ISO prep and client deliverables

## Team Mode (RBAC)

Enable multi-user access with role-based permissions:

```env
GUARDIAN_TEAM_MODE=true
GUARDIAN_API_KEY=sg_your_api_key_here
```

| Role | Permissions |
|------|------------|
| **admin** | Full access — all tools, user management |
| **operator** | Run commands, restart services, deploy — no user management |
| **viewer** | Read-only — view health, logs, alerts, dashboards |

```
Tell Claude: "create a team user nazish with operator role"
```

## External Integrations

Route alerts to your existing tools:

```env
# PagerDuty
PAGERDUTY_ROUTING_KEY=your-routing-key

# Telegram
TELEGRAM_BOT_TOKEN=your-bot-token
TELEGRAM_CHAT_ID=your-chat-id

# OpsGenie
OPSGENIE_API_KEY=your-api-key
```

```
Tell Claude: "check integrations" / "test integrations"
```

## Background Watchdog

The watchdog runs independently of Claude — no AI, no API cost. Monitors 24/7 and sends alerts.

### Start the watchdog
```bash
# Run forever (production)
python -m server_guardian_mcp watchdog

# Run once (testing)
python -m server_guardian_mcp watchdog --once
```

### Configure alerts in .env
```env
# Check interval (default 5 minutes)
WATCHDOG_INTERVAL=300

# What to check
WATCHDOG_HEALTH_ENABLED=true
WATCHDOG_SERVICES_ENABLED=true
WATCHDOG_ENDPOINTS_ENABLED=true
WATCHDOG_AUTO_RESTART=false

# HTTP/SSL endpoints to monitor
WATCHDOG_ENDPOINTS=https://myapp.com/health,https://api.myapp.com,myapp.com

# Email alerts (Gmail example)
ALERT_EMAIL=you@example.com
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=you@gmail.com
SMTP_PASSWORD=your-app-password

# Slack alerts
ALERT_WEBHOOK=https://hooks.slack.com/services/T.../B.../xxx

# Discord alerts
ALERT_DISCORD_WEBHOOK=https://discord.com/api/webhooks/123/abc
```

### What triggers alerts
| Condition | Severity |
|-----------|----------|
| Disk usage > 90% | Critical |
| Disk usage > 80% | Warning |
| CPU load > 2x core count | Warning |
| Temperature > 85C | Warning |
| Server unreachable | Critical |
| Failed systemd services | Warning |
| HTTP endpoint down | Critical |
| SSL cert < 7 days | Critical |
| SSL cert < 30 days | Warning |

Alerts are **deduplicated** — the same issue won't spam your inbox.

## Connection Types

| Type | Connects to | Requires | File transfer |
|------|------------|----------|:---:|
| `ssh` | Linux/Mac servers | paramiko (included) | SFTP |
| `local` | Your own machine | nothing | cp |
| `docker` | Docker containers | docker CLI | docker cp |
| `winrm` | Windows servers | `pip install pywinrm` | - |
| `k8s` | Kubernetes pods | kubectl CLI | kubectl cp |
| `aws-ssm` | AWS EC2 instances | aws CLI | - |
| `gcloud` | GCP Compute Engine | gcloud CLI | gcloud scp |
| `azure` | Azure VMs | az CLI | - |

## Security

### Built-in protections
- **Command blocklist** — blocks `rm -rf /`, fork bombs, reverse shells, `wget|curl|bash`
- **Sensitive file protection** — blocks `.pem`, `.key`, `.env`, `/etc/shadow`
- **SQL safety** — read-only by default, blocks DROP/DELETE/ALTER
- **Read-only mode** — set `GUARDIAN_MODE=readonly` to disable all mutating tools
- **Rate limiting** — 30 calls/minute per tool (configurable via `GUARDIAN_RATE_LIMIT`)
- **Audit logging** — all tool invocations logged to SQLite with sensitive param redaction
- **Shell injection prevention** — `shlex.quote()` on all user inputs
- **Output capped at 512KB** per command to prevent memory exhaustion

### Override flags (use with caution)
| Flag | What it unlocks |
|------|----------------|
| `GUARDIAN_ALLOW_DANGEROUS=true` | Allow blocked commands (rm -rf, mkfs, etc.) |
| `GUARDIAN_ALLOW_SENSITIVE=true` | Allow reading sensitive files (.pem, .env, etc.) |
| `GUARDIAN_SQL_WRITE=true` | Allow write SQL queries (DROP, DELETE, etc.) |
| `GUARDIAN_MODE=readwrite` | Enable all mutating tools (default) |

## Architecture

- **47 MCP tools** with security infrastructure
- **8 connection adapters** (SSH, Local, Docker, WinRM, K8s, AWS SSM, GCloud, Azure)
- **Background watchdog** daemon with multi-channel alerts
- **SQLite persistence** with 8 tables (health, services, endpoints, alerts, audit, baselines, playbooks, users)
- **Live web dashboard** (Starlette + Chart.js)
- **Anomaly detection** engine (statistical baselines)
- **Auto-remediation** playbook engine
- **Team RBAC** (admin/operator/viewer)
- **External integrations** (PagerDuty, Telegram, OpsGenie)
- **Compliance report** generator

## Configuration Reference

### Server Profile Format
```
SERVER_<NAME>=type,host,port,user,auth_method,credential,label
```

| Field | Description | Example |
|-------|-------------|---------|
| `type` | Connection type | `ssh`, `local`, `docker`, `winrm`, `k8s`, `aws-ssm`, `gcloud`, `azure` |
| `host` | IP/hostname/container/pod | `203.0.113.10`, `my-container`, `my-pod/default` |
| `port` | Port (empty = default) | `22`, `5985` |
| `user` | Username (or zone/region for cloud) | `deploy`, `us-east-1` |
| `auth_method` | `password` or `key` (SSH) | `key` |
| `credential` | Password, key path, or profile | `~/.ssh/prod_key`, `my-aws-profile` |
| `label` | Friendly display name | `Production` |

### Global Settings
| Variable | Default | Description |
|----------|---------|-------------|
| `OWNER_NAME` | `Admin` | Your name (shown in MCP instructions) |
| `DEFAULT_SSH_PORT` | `22` | Fallback SSH port |
| `DEFAULT_SSH_USER` | `root` | Fallback SSH user |
| `DEFAULT_SSH_AUTH` | `password` | Fallback auth method |
| `DEFAULT_CMD_TIMEOUT` | `30` | Per-command timeout (seconds) |
| `DEFAULT_SCRIPT_TIMEOUT` | `120` | Script timeout (seconds) |
| `SSH_CONNECT_TIMEOUT` | `10` | SSH connection timeout (seconds) |
| `GUARDIAN_RATE_LIMIT` | `30` | Max calls per tool per minute |
| `GUARDIAN_PLAYBOOKS` | `true` | Enable/disable auto-remediation |
| `GUARDIAN_TEAM_MODE` | `false` | Enable multi-user RBAC |

## Requirements

- Python 3.10+
- `mcp>=1.0.0`
- `paramiko>=3.0.0`
- `uvicorn>=0.27.0`
- `starlette>=0.36.0`
- Optional: `pywinrm` (for Windows servers)
- Optional: `docker`, `kubectl`, `aws`, `gcloud`, `az` CLIs (for respective adapters)

## License

MIT

## Author

**Md Nazish Arman**
