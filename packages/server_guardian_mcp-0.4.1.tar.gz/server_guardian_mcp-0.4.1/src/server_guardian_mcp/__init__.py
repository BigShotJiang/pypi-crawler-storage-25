"""Server Guardian MCP — Monitor and manage remote Linux servers via SSH."""
__version__ = "0.4.1"
