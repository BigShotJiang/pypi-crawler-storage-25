"""
Server Guardian MCP Server
Monitor and manage remote Linux servers via SSH.
Health checks, logs, Docker, SSL, services, multi-server commands.

All config is loaded from .env — see .env.example for setup.
"""

import fnmatch
import functools
import json
import os
import re
import shlex
import socket
import ssl
import time
import urllib.request
import urllib.error
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path

from mcp.server.fastmcp import FastMCP

from . import db as _db


# ---------------------------------------------------------------------------
# Input sanitization — prevent shell injection
# ---------------------------------------------------------------------------
_SAFE_NAME_RE = re.compile(r"^[a-zA-Z0-9_.@:/-]+$")


def _shell_quote(value: str) -> str:
    """Safely quote a value for shell interpolation using shlex.quote."""
    return shlex.quote(value)


def _validate_name(value: str, label: str = "value") -> str | None:
    """Validate that a value contains only safe characters for shell use.
    Returns an error string if invalid, None if safe."""
    if not value or not value.strip():
        return f"{label} cannot be empty"
    if not _SAFE_NAME_RE.match(value.strip()):
        return f"{label} contains invalid characters: {value!r}. Only alphanumeric, dots, hyphens, underscores, @, colons, and slashes are allowed."
    return None


def _validate_positive_int(value: int, label: str = "value", max_val: int = 100000) -> str | None:
    """Validate an integer is positive and within range. Returns error or None."""
    if value < 0:
        return f"{label} must be non-negative, got {value}"
    if value > max_val:
        return f"{label} too large: {value} (max {max_val})"
    return None

# ---------------------------------------------------------------------------
# Security: command blocklist
# ---------------------------------------------------------------------------
_COMMAND_BLOCKLIST = [
    re.compile(p, re.IGNORECASE) for p in [
        r"\brm\s+(-[a-zA-Z]*f[a-zA-Z]*\s+)?/\s",  # rm -rf /
        r"\brm\s+(-[a-zA-Z]*f[a-zA-Z]*\s+)?/\s*$",  # rm -rf / at end
        r"\bmkfs\b",                                   # format disk
        r"\bdd\s+if=",                                 # disk destroyer
        r":\s*\(\)\s*\{",                              # fork bomb
        r"\bbash\s+-i\s+>&\s*/dev/tcp",               # reverse shell
        r"/dev/tcp/",                                  # reverse shell variant
        r"/dev/udp/",                                  # reverse shell variant
        r"\bnc\s+.*-e\b",                             # netcat reverse shell
        r"\bncat\s+.*-e\b",                           # ncat reverse shell
        r"\bshutdown\b",                               # shutdown system
        r"\breboot\b",                                 # reboot system
        r"\bpoweroff\b",                               # power off
        r"\bhalt\b",                                   # halt system
        r"\bkill\s+-9\s+-1\b",                        # kill all processes
        r">\s*/dev/sd[a-z]",                           # overwrite disk device
        r"\bchmod\s+777\s+/",                         # chmod 777 root
        r"\biptables\s+-F\b",                          # flush all firewall rules
        r"\bufw\s+reset\b",                            # reset firewall
        r"\bufw\s+disable\b",                          # disable firewall
        r"\bsystemctl\s+isolate\b",                    # change system state
        r"\bwget\s+.*\|\s*bash",                       # download and execute
        r"\bcurl\s+.*\|\s*bash",                       # download and execute
        r"\bcurl\s+.*\|\s*sh",                         # download and execute
    ]
]


def _check_command_blocklist(text: str) -> str | None:
    """Return error message if text contains a blocked command pattern, else None."""
    for pattern in _COMMAND_BLOCKLIST:
        if pattern.search(text):
            return (f"BLOCKED: command matches dangerous pattern '{pattern.pattern}'. "
                    "This operation is not allowed for safety. "
                    "Set GUARDIAN_ALLOW_DANGEROUS=true to override.")
    return None


def _is_dangerous_allowed() -> bool:
    """Check if dangerous commands are explicitly allowed."""
    return os.environ.get("GUARDIAN_ALLOW_DANGEROUS", "").lower() == "true"


# ---------------------------------------------------------------------------
# Security: read-only mode
# ---------------------------------------------------------------------------
_MUTATING_TOOLS = {
    "manage_systemd_service", "manage_packages", "manage_firewall",
    "run_shell_commands", "run_shell_script", "manage_cron_jobs",
    "manage_users", "manage_nginx", "git_deploy", "upload_file_to_server",
    "query_database", "restart_failed_services", "run_on_all_servers",
    "resolve_alert", "manage_playbooks", "team_manage",
}


def _is_readonly_mode() -> bool:
    """Check if guardian is running in read-only mode."""
    return os.environ.get("GUARDIAN_MODE", "").lower() == "readonly"


def _check_readonly(tool_name: str) -> str | None:
    """Return error if tool is mutating and we're in read-only mode."""
    if _is_readonly_mode() and tool_name in _MUTATING_TOOLS:
        return json.dumps({
            "error": f"BLOCKED: '{tool_name}' is disabled in read-only mode. "
                     "Set GUARDIAN_MODE=readwrite to enable."
        })
    return None


# ---------------------------------------------------------------------------
# Security: sensitive file protection
# ---------------------------------------------------------------------------
_SENSITIVE_FILE_PATTERNS = [
    "*.pem", "*.key", "*.p12", "*.pfx", "*.jks",
    "id_rsa", "id_rsa.*", "id_ed25519", "id_ed25519.*", "id_ecdsa", "id_ecdsa.*",
    ".env", ".env.*",
    "shadow", "gshadow",
    "*credentials*", "*secret*",
    "*.keystore", "*.kdbx",
]

_SENSITIVE_PATH_PATTERNS = [
    "/proc/*/environ",
    "/etc/shadow",
    "/etc/gshadow",
    "*.aws/credentials",
    "*.kube/config",
]


def _check_sensitive_file(file_path: str) -> str | None:
    """Return error if file matches a sensitive pattern, else None."""
    if os.environ.get("GUARDIAN_ALLOW_SENSITIVE", "").lower() == "true":
        return None
    basename = file_path.rsplit("/", 1)[-1] if "/" in file_path else file_path
    for pat in _SENSITIVE_FILE_PATTERNS:
        if fnmatch.fnmatch(basename, pat) or fnmatch.fnmatch(basename.lower(), pat):
            return (f"BLOCKED: '{file_path}' matches sensitive file pattern '{pat}'. "
                    "Reading credentials/keys is not allowed for safety. "
                    "Set GUARDIAN_ALLOW_SENSITIVE=true to override.")
    for pat in _SENSITIVE_PATH_PATTERNS:
        if fnmatch.fnmatch(file_path, pat):
            return (f"BLOCKED: '{file_path}' matches sensitive path pattern '{pat}'. "
                    "Set GUARDIAN_ALLOW_SENSITIVE=true to override.")
    return None


# ---------------------------------------------------------------------------
# Security: SQL safety
# ---------------------------------------------------------------------------
_DESTRUCTIVE_SQL = re.compile(
    r"\b(DROP|DELETE|TRUNCATE|ALTER|INSERT|UPDATE|CREATE|GRANT|REVOKE)\b",
    re.IGNORECASE,
)


def _check_sql_safety(query: str) -> str | None:
    """Block destructive SQL unless GUARDIAN_SQL_WRITE=true."""
    if os.environ.get("GUARDIAN_SQL_WRITE", "").lower() == "true":
        return None
    if _DESTRUCTIVE_SQL.search(query):
        return (f"BLOCKED: query contains destructive SQL keyword. "
                "Only SELECT queries are allowed by default. "
                "Set GUARDIAN_SQL_WRITE=true to enable write queries.")
    return None


# ---------------------------------------------------------------------------
# Security: rate limiting
# ---------------------------------------------------------------------------
_rate_limit_store: dict[str, list[float]] = defaultdict(list)
_RATE_LIMIT = int(os.environ.get("GUARDIAN_RATE_LIMIT", "30"))


def _check_rate_limit(tool_name: str) -> str | None:
    """Enforce per-tool rate limiting (calls per minute). Returns error or None."""
    if _RATE_LIMIT <= 0:
        return None
    now = time.time()
    window = _rate_limit_store[tool_name]
    # Prune entries older than 60 seconds
    _rate_limit_store[tool_name] = [t for t in window if now - t < 60]
    if len(_rate_limit_store[tool_name]) >= _RATE_LIMIT:
        return (f"RATE LIMITED: '{tool_name}' exceeded {_RATE_LIMIT} calls/minute. "
                "Wait before retrying. Configure via GUARDIAN_RATE_LIMIT env var.")
    _rate_limit_store[tool_name].append(now)
    return None


# ---------------------------------------------------------------------------
# Security: audit logging decorator
# ---------------------------------------------------------------------------
_SENSITIVE_PARAMS = {"db_password", "password", "credential", "secret", "token"}


def _audit_log(tool_name: str, server_name: str | None, params: dict,
               result_summary: str, success: bool = True) -> None:
    """Safely record an audit entry — never crashes the tool."""
    try:
        # Redact sensitive params
        safe_params = {}
        for k, v in params.items():
            if k in _SENSITIVE_PARAMS:
                safe_params[k] = "***REDACTED***"
            else:
                safe_params[k] = v
        _db.record_audit(tool_name, server_name, safe_params, result_summary, success)
    except Exception:
        pass  # Audit failure must never block tool execution


def _with_audit(func):
    """Decorator that adds rate limiting, readonly checks, and audit logging to MCP tools."""
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        tool_name = func.__name__
        server_name = kwargs.get("server") or (args[0] if args else None)
        if isinstance(server_name, list):
            server_name = ",".join(server_name[:3])

        # Rate limit check
        rate_err = _check_rate_limit(tool_name)
        if rate_err:
            _audit_log(tool_name, server_name, kwargs, rate_err, success=False)
            return json.dumps({"error": rate_err})

        # Read-only mode check
        ro_err = _check_readonly(tool_name)
        if ro_err:
            _audit_log(tool_name, server_name, kwargs, "blocked:readonly", success=False)
            return ro_err

        # Execute the tool
        try:
            result = func(*args, **kwargs)
            summary = result[:500] if isinstance(result, str) else str(result)[:500]
            _audit_log(tool_name, server_name, kwargs, summary, success=True)
            return result
        except Exception as exc:
            _audit_log(tool_name, server_name, kwargs, str(exc)[:500], success=False)
            raise
    return wrapper


# ---------------------------------------------------------------------------
# Load .env — checks: current dir, home dir, then package dir
# ---------------------------------------------------------------------------
_SCRIPT_DIR = Path(__file__).resolve().parent
_ENV_SEARCH_PATHS = [
    Path.cwd() / ".env",
    Path.home() / ".server-guardian-mcp.env",
    Path.home() / ".env",
    _SCRIPT_DIR / ".env",
]
_ENV_FILE = next((p for p in _ENV_SEARCH_PATHS if p.exists()), _SCRIPT_DIR / ".env")


def _load_env(path: Path) -> None:
    """Minimal .env loader — no external dependency needed."""
    if not path.exists():
        return
    try:
        with open(path) as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                if "=" not in line:
                    continue
                key, _, value = line.partition("=")
                key = key.strip()
                value = value.strip()
                if not os.environ.get(key):
                    os.environ[key] = value
    except (PermissionError, OSError):
        pass  # silently skip unreadable .env files


_load_env(_ENV_FILE)

# Initialize SQLite database
try:
    _db.init_db()
except Exception:
    pass  # DB init failure should not prevent server startup


def _env(key: str, default: str = "") -> str:
    return os.environ.get(key, default)


def _env_int(key: str, default: int = 0) -> int:
    try:
        return int(_env(key, str(default)))
    except ValueError:
        return default


# ---------------------------------------------------------------------------
# Configuration from .env
# ---------------------------------------------------------------------------
OWNER_NAME = _env("OWNER_NAME", "Admin")
DEFAULT_SSH_PORT = _env_int("DEFAULT_SSH_PORT", 22)
DEFAULT_SSH_USER = _env("DEFAULT_SSH_USER", "root")
DEFAULT_SSH_AUTH = _env("DEFAULT_SSH_AUTH", "password")
DEFAULT_SSH_PASSWORD = _env("DEFAULT_SSH_PASSWORD", "")
DEFAULT_SSH_KEY_PATH = _env("DEFAULT_SSH_KEY_PATH", "~/.ssh/id_rsa")
DEFAULT_CMD_TIMEOUT = _env_int("DEFAULT_CMD_TIMEOUT", 30)
DEFAULT_SCRIPT_TIMEOUT = _env_int("DEFAULT_SCRIPT_TIMEOUT", 120)
SSH_CONNECT_TIMEOUT = _env_int("SSH_CONNECT_TIMEOUT", 10)


# ---------------------------------------------------------------------------
# Server profile loader
# ---------------------------------------------------------------------------
_RESERVED_KEYS = {"SERVER_ALIASES"}


def _load_server_profiles() -> dict:
    """Load SERVER_* entries from env.
    New format: SERVER_<NAME>=type,host,port,user,auth_method,credential,label
    Old format: SERVER_<NAME>=host,port,user,auth_method,credential,label (defaults to ssh)

    Backward compatible: if first field looks like an IP/hostname, treats as old format."""
    from .adapters import _ADAPTER_TYPES

    profiles = {}
    for key, value in os.environ.items():
        if key in _RESERVED_KEYS:
            continue
        if key.startswith("SERVER_") and "," in value:
            name = key[len("SERVER_"):]
            parts = [p.strip() for p in value.split(",")]
            if len(parts) < 2:
                continue

            # Detect format: new (type,host,...) vs old (host,port,...)
            first = parts[0].lower()
            if first in _ADAPTER_TYPES:
                # New format: type,host,port,user,auth,credential,label
                server_type = first
                host = parts[1] if len(parts) > 1 else ""
                try:
                    port = int(parts[2]) if len(parts) > 2 and parts[2] else DEFAULT_SSH_PORT
                except ValueError:
                    port = DEFAULT_SSH_PORT
                user = parts[3] if len(parts) > 3 and parts[3] else DEFAULT_SSH_USER
                auth = parts[4] if len(parts) > 4 and parts[4] else DEFAULT_SSH_AUTH
                credential = parts[5] if len(parts) > 5 and parts[5] else ""
                label = parts[6] if len(parts) > 6 and parts[6] else name.lower()
            else:
                # Old format: host,port,user,auth,credential,label (default ssh)
                server_type = "ssh"
                host = parts[0]
                if not host:
                    continue
                if len(parts) < 4:
                    continue
                try:
                    port = int(parts[1]) if parts[1] else DEFAULT_SSH_PORT
                except ValueError:
                    port = DEFAULT_SSH_PORT
                user = parts[2] if parts[2] else DEFAULT_SSH_USER
                auth = parts[3] if parts[3] else DEFAULT_SSH_AUTH
                credential = parts[4] if len(parts) > 4 and parts[4] else ""
                label = parts[5] if len(parts) > 5 and parts[5] else name.lower()

            # For local/docker/k8s, host can be empty or container/pod name
            if server_type == "ssh" and not host:
                continue

            profiles[name.upper()] = {
                "type": server_type,
                "host": host,
                "port": port,
                "user": user,
                "auth": auth,
                "credential": credential,
                "label": label,
            }
    return profiles


def _load_server_aliases() -> dict:
    """Load SERVER_ALIASES. Format: alias1:NAME1,alias2:NAME2"""
    aliases = {}
    raw = _env("SERVER_ALIASES", "")
    for pair in raw.split(","):
        pair = pair.strip()
        if ":" in pair:
            alias, name = pair.split(":", 1)
            aliases[alias.strip().upper()] = name.strip().upper()
    return aliases


SERVER_PROFILES = _load_server_profiles()
SERVER_ALIASES = _load_server_aliases()


# ---------------------------------------------------------------------------
# Build dynamic MCP instructions from config
# ---------------------------------------------------------------------------
_server_names = ", ".join(
    f"{name} ({p['label']})" for name, p in sorted(SERVER_PROFILES.items())
) if SERVER_PROFILES else "none configured"

mcp = FastMCP(
    "server-guardian",
    instructions=(
        f"Monitors and manages remote Linux servers for {OWNER_NAME}. "
        f"Configured servers: {_server_names}.\n\n"
        "TOOL SELECTION GUIDE:\n"
        "- list_all_servers: overview of all servers and whether they are online\n"
        "- check_server_health: full health snapshot (CPU, RAM, disk, uptime, load)\n"
        "- run_shell_commands: execute one or more shell commands on a server\n"
        "- run_shell_script: execute a multi-line bash script on a server\n"
        "- fetch_system_logs: read system/kernel/auth/custom log files\n"
        "- list_running_processes: see what processes are consuming resources\n"
        "- manage_systemd_service: start/stop/restart/status of systemd services\n"
        "- run_on_all_servers: execute commands across multiple or all servers at once\n"
        "- check_ssl_certificate: verify SSL cert expiry for any domain (no SSH)\n"
        "- check_http_endpoint: test if a URL is responding (no SSH)\n"
        "- list_docker_containers: see Docker containers and resource usage\n"
        "- fetch_docker_logs: read logs from a Docker container\n"
        "- analyze_disk_usage: find what is consuming disk space\n"
        "- inspect_network: see open ports, active connections, interfaces\n"
        "- read_remote_file: read a file on a server\n"
        "- upload_file_to_server: push a local file to a server via SFTP\n"
        "- download_file_from_server: pull a file from a server via SFTP\n"
        "- run_security_audit: check for common security misconfigurations\n"
        "- compare_across_servers: run same command on multiple servers, spot differences\n\n"
        "SERVICE DISCOVERY:\n"
        "- list_all_services: list all systemd services, filter by running/failed/inactive\n"
        "- find_failed_services: find all crashed or failed services\n"
        "- restart_failed_services: bulk restart failed services\n"
        "- watch_service_status: quick is-active check for specific services\n\n"
        "MONITORING (stores data in local SQLite DB):\n"
        "- monitor_server_health: health check + store metrics + auto-alert on thresholds\n"
        "- monitor_endpoints: check HTTP/SSL targets + store results + alert on failures\n"
        "- get_monitoring_history: query stored health trends and service events\n"
        "- get_active_alerts: show unresolved alerts grouped by severity\n"
        "- resolve_alert: mark an alert as resolved\n\n"
        "ADVANCED TOOLS:\n"
        "- discover_ssh_servers: auto-discover servers from ~/.ssh/config\n"
        "- query_database: run SQL queries (MySQL/PostgreSQL/SQLite) on a server\n"
        "- manage_cron_jobs: list, add, remove cron jobs\n"
        "- manage_users: list users, manage SSH keys, check who is logged in\n"
        "- manage_packages: install, remove, upgrade system packages (apt/yum/dnf)\n"
        "- manage_nginx: status, config, reload, restart, logs for Nginx\n"
        "- git_deploy: git status, pull, log, switch branches on server repos\n"
        "- manage_firewall: UFW/iptables rules — status, allow, deny, delete\n"
        "- multi_server_dashboard: one-call summary of ALL servers with health status\n"
        "- get_incident_timeline: chronological event log for a server\n"
        "- forecast_disk_usage: predict when disk will be full\n"
        "- generate_html_dashboard: create a visual HTML status page\n\n"
        "INTELLIGENCE & AUTOMATION:\n"
        "- detect_anomalies_tool: smart anomaly detection using statistical baselines\n"
        "- replay_incident: generate chronological incident narrative from stored data\n"
        "- manage_playbooks: auto-remediation playbooks (disk cleanup, service restart, SSL renewal)\n"
        "- generate_compliance_report_tool: branded HTML security report (SOC2/ISO prep)\n\n"
        "TEAM & INTEGRATIONS:\n"
        "- team_manage: RBAC user management (admin/operator/viewer roles)\n"
        "- check_integrations: PagerDuty, Telegram, OpsGenie alert routing\n"
        "- live_dashboard_info: real-time web dashboard with charts\n\n"
        "SERVER NAMING: Use the server name (e.g. 'PROD', 'STAGING'), its label "
        "(e.g. 'production'), or an alias. Case-insensitive."
    ),
)


# ---------------------------------------------------------------------------
# Server resolution
# ---------------------------------------------------------------------------
def _resolve_server(server: str) -> dict:
    """Resolve server name/alias/label to connection details.
    Returns {host, port, user, auth, credential, label, name} or {error}."""
    lookup = server.strip().upper()

    # 1. Direct match
    if lookup in SERVER_PROFILES:
        return {**SERVER_PROFILES[lookup], "name": lookup}

    # 2. Alias match
    if lookup in SERVER_ALIASES:
        resolved = SERVER_ALIASES[lookup]
        if resolved in SERVER_PROFILES:
            return {**SERVER_PROFILES[resolved], "name": resolved}

    # 3. Label match (case-insensitive)
    for name, profile in SERVER_PROFILES.items():
        if profile["label"].upper() == lookup:
            return {**profile, "name": name}

    available = ", ".join(sorted(SERVER_PROFILES.keys()))
    return {"error": f"Unknown server '{server}'. Available: {available}"}


def _resolve_server_list(servers: list[str]) -> list[dict]:
    """Resolve a list of server names. Expands 'ALL' to all profiles."""
    if len(servers) == 1 and servers[0].strip().upper() == "ALL":
        return [{**p, "name": n} for n, p in sorted(SERVER_PROFILES.items())]
    results = []
    for s in servers:
        resolved = _resolve_server(s)
        results.append(resolved)
    return results


# ---------------------------------------------------------------------------
# Execution helpers — dispatch to the appropriate adapter
# ---------------------------------------------------------------------------
from .adapters import get_adapter


def _ssh_exec(info: dict, commands: list[str],
              per_cmd_timeout: int = 0) -> list[dict]:
    """Execute commands on a server via the appropriate adapter (SSH, local, Docker, etc.).
    Returns a list of {command, stdout, stderr, exit_code, truncated} dicts."""
    adapter = get_adapter(info)
    return adapter.execute_commands(commands, per_cmd_timeout or DEFAULT_CMD_TIMEOUT)


def _ssh_exec_script(info: dict, script: str, timeout: int = 0) -> dict:
    """Execute a multi-line script on a server via the appropriate adapter.
    Returns {stdout, stderr, exit_code}."""
    adapter = get_adapter(info)
    return adapter.execute_script(script, timeout or DEFAULT_SCRIPT_TIMEOUT)


def _sftp_push(info: dict, local_path: str, remote_path: str) -> dict:
    """Upload a file to a server via the appropriate adapter.
    Returns {success, ...} or {success, error}."""
    adapter = get_adapter(info)
    return adapter.push_file(local_path, remote_path)


def _sftp_pull(info: dict, remote_path: str, local_path: str) -> dict:
    """Download a file from a server via the appropriate adapter.
    Returns {success, ...} or {success, error}."""
    adapter = get_adapter(info)
    return adapter.pull_file(remote_path, local_path)


def _check_reachable(info: dict) -> tuple[bool, float]:
    """Check if a server is reachable via its adapter.
    Returns (reachable: bool, latency_ms: float)."""
    adapter = get_adapter(info)
    return adapter.check_reachable()


def _parse_sections(raw: str) -> dict:
    """Parse ===SECTION=== delimited output into a dict of {section_name: content}."""
    sections = {}
    current_key = None
    current_lines = []
    for line in raw.splitlines():
        if line.startswith("===") and line.endswith("==="):
            if current_key:
                sections[current_key] = "\n".join(current_lines).strip()
            current_key = line.strip("=")
            current_lines = []
        else:
            current_lines.append(line)
    if current_key:
        sections[current_key] = "\n".join(current_lines).strip()
    return sections


def _server_meta(info: dict) -> dict:
    """Extract standard metadata fields from a resolved server info dict."""
    return {
        "server": info["name"],
        "label": info["label"],
        "host": info["host"],
    }


# ---------------------------------------------------------------------------
# Reusable scripts and helpers
# ---------------------------------------------------------------------------
_HEALTH_SCRIPT = r"""
echo "===UNAME==="
uname -a
echo "===UPTIME==="
uptime
echo "===CPU==="
echo "cores: $(nproc 2>/dev/null || grep -c processor /proc/cpuinfo)"
grep "model name" /proc/cpuinfo 2>/dev/null | head -1 | sed 's/model name\s*: //' || echo "unknown"
echo "===MEMORY==="
free -h 2>/dev/null || cat /proc/meminfo | head -5
echo "===SWAP==="
swapon --show 2>/dev/null || echo "no swap info"
echo "===DISK==="
df -h / /tmp /home /var 2>/dev/null
echo "===TEMPERATURE==="
if [ -d /sys/class/thermal ]; then
    for z in /sys/class/thermal/thermal_zone*/temp; do
        zone=$(basename $(dirname "$z"))
        temp=$(cat "$z" 2>/dev/null)
        if [ -n "$temp" ]; then echo "$zone: $((temp/1000))C"; fi
    done
else
    echo "no thermal data"
fi
echo "===LOAD==="
cat /proc/loadavg
echo "===TOP_PROCESSES==="
ps aux --sort=-%cpu 2>/dev/null | head -8 || ps -ef | head -8
echo "===NETWORK==="
ip -4 addr show 2>/dev/null | grep -E "inet |state" | head -12 || ifconfig 2>/dev/null | head -20
echo "===KERNEL==="
uname -r
"""


def _do_ssl_check(domain: str, port: int = 443) -> dict:
    """Check SSL cert for a domain. Returns a dict (not JSON string)."""
    try:
        ctx = ssl.create_default_context()
        raw_sock = socket.create_connection((domain, port), timeout=10)
        with ctx.wrap_socket(raw_sock, server_hostname=domain) as s:
            cert = s.getpeercert()
            protocol = s.version()

        not_after = cert.get("notAfter", "")
        not_before = cert.get("notBefore", "")

        expiry = datetime.strptime(not_after, "%b %d %H:%M:%S %Y %Z")
        now_utc = datetime.utcnow()
        days_left = (expiry - now_utc).days

        sans = [v for t, v in cert.get("subjectAltName", []) if t == "DNS"]

        issuer_parts = []
        for rdn in cert.get("issuer", []):
            for attr_type, attr_value in rdn:
                issuer_parts.append(f"{attr_type}={attr_value}")

        subject_parts = []
        for rdn in cert.get("subject", []):
            for attr_type, attr_value in rdn:
                subject_parts.append(f"{attr_type}={attr_value}")

        if days_left < 0:
            status = "EXPIRED"
        elif days_left <= 7:
            status = "CRITICAL"
        elif days_left <= 30:
            status = "WARNING"
        else:
            status = "OK"

        return {
            "domain": domain, "port": port, "status": status,
            "days_until_expiry": days_left,
            "subject": ", ".join(subject_parts),
            "issuer": ", ".join(issuer_parts),
            "valid_from": not_before, "valid_until": not_after,
            "san_domains": sans, "protocol": protocol,
            "serial_number": cert.get("serialNumber", ""),
        }
    except ssl.SSLCertVerificationError as e:
        return {"domain": domain, "port": port, "status": "INVALID",
                "error": f"Certificate verification failed: {e}"}
    except Exception as e:
        return {"domain": domain, "port": port, "status": "ERROR", "error": str(e)}


def _do_http_check(url: str, method: str = "GET",
                   expected_status: int = 200, timeout: int = 10) -> dict:
    """Check an HTTP endpoint. Returns a dict (not JSON string)."""
    try:
        req = urllib.request.Request(url, method=method)
        req.add_header("User-Agent", "ServerGuardianMCP/0.2")
        t0 = time.time()
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            elapsed_ms = round((time.time() - t0) * 1000)
            status = resp.status
            headers = dict(resp.headers)
            body = resp.read(2048).decode("utf-8", errors="replace")
        status_ok = (expected_status == 0) or (status == expected_status)
        return {
            "url": url, "method": method, "status_code": status,
            "expected_status": expected_status if expected_status else None,
            "status_match": status_ok,
            "response_time_ms": elapsed_ms,
            "headers": {
                "content-type": headers.get("Content-Type", ""),
                "server": headers.get("Server", ""),
                "content-length": headers.get("Content-Length", ""),
            },
            "body_preview": body[:500],
            "result": "PASS" if status_ok else "FAIL",
        }
    except urllib.error.HTTPError as e:
        status_ok = (expected_status == 0) or (e.code == expected_status)
        return {"url": url, "method": method, "status_code": e.code,
                "expected_status": expected_status if expected_status else None,
                "status_match": status_ok, "error": str(e.reason),
                "result": "PASS" if status_ok else "FAIL"}
    except urllib.error.URLError as e:
        return {"url": url, "status_code": None,
                "error": f"Connection failed: {e.reason}", "result": "FAIL"}
    except Exception as e:
        return {"url": url, "status_code": None, "error": str(e), "result": "FAIL"}


# ===========================================================================
# PHASE 1: MVP TOOLS (8 tools)
# ===========================================================================

# ---------------------------------------------------------------------------
# 1. list_all_servers
# ---------------------------------------------------------------------------
@mcp.tool()
@_with_audit
def list_all_servers() -> str:
    """Show every server configured in .env along with its current online/offline
    status and connection latency. Call this first to see what servers are available
    before running any other commands.

    Returns for each server: name, label, host, port, user, auth method, online
    status, and latency in milliseconds.

    No arguments needed — reads directly from the .env configuration file.
    """
    if not SERVER_PROFILES:
        return json.dumps({
            "servers": [],
            "count": 0,
            "message": "No servers configured. Add SERVER_<NAME>=... entries to your .env file.",
        }, indent=2)

    servers = []
    for name, profile in sorted(SERVER_PROFILES.items()):
        reachable, latency_ms = _check_reachable(profile)
        servers.append({
            "name": name,
            "label": profile["label"],
            "host": profile["host"],
            "port": profile["port"],
            "user": profile["user"],
            "auth_method": profile["auth"],
            "status": "online" if reachable else "offline",
            "latency_ms": latency_ms if reachable else None,
        })

    online = sum(1 for s in servers if s["status"] == "online")
    return json.dumps({
        "servers": servers,
        "count": len(servers),
        "online": online,
        "offline": len(servers) - online,
    }, indent=2)


# ---------------------------------------------------------------------------
# 2. check_server_health
# ---------------------------------------------------------------------------
@mcp.tool()
@_with_audit
def check_server_health(server: str) -> str:
    """SSH into a server and collect a full health snapshot in one call.

    Collects: OS info (uname), uptime, CPU count and model, RAM usage (free -h),
    disk usage on / /tmp /home, CPU temperature (if available), system load average,
    top 8 processes by CPU, and network interface IPs.

    Use this as the first diagnostic step when a server feels slow or unresponsive.

    Args:
        server: Server name, label, or alias — e.g. "PROD", "production", "prod"
    """
    info = _resolve_server(server)
    if "error" in info:
        return json.dumps(info, indent=2)

    t0 = time.time()
    result = _ssh_exec_script(info, _HEALTH_SCRIPT, timeout=30)
    sections = _parse_sections(result.get("stdout", ""))

    return json.dumps({
        **_server_meta(info),
        "health": sections,
        "ssh_stderr": result.get("stderr", "") or None,
        "duration": f"{time.time() - t0:.1f}s",
    }, indent=2)


# ---------------------------------------------------------------------------
# 3. run_shell_commands
# ---------------------------------------------------------------------------
@mcp.tool()
@_with_audit
def run_shell_commands(server: str, commands: list[str],
                       per_cmd_timeout: int = 0) -> str:
    """SSH into a server and run one or more shell commands sequentially.

    Each command executes independently in the same SSH session. Use this for
    quick checks like 'uname -a', 'ls /var/log', 'df -h', 'systemctl status nginx'.

    For multi-line scripts where commands depend on each other (shared variables,
    cd + run, loops), use run_shell_script instead.

    Args:
        server: Server name, label, or alias — e.g. "PROD", "production", "prod"
        commands: List of shell commands to run — e.g. ["uname -a", "df -h", "free -h"]
        per_cmd_timeout: Max seconds to wait per command before killing it (default: 30)
    """
    info = _resolve_server(server)
    if "error" in info:
        return json.dumps(info, indent=2)

    t0 = time.time()
    results = _ssh_exec(info, commands, per_cmd_timeout)

    return json.dumps({
        **_server_meta(info),
        "command_results": results,
        "commands_run": len(commands),
        "commands_succeeded": sum(1 for r in results if r.get("exit_code") == 0),
        "duration": f"{time.time() - t0:.1f}s",
    }, indent=2)


# ---------------------------------------------------------------------------
# 4. run_shell_script
# ---------------------------------------------------------------------------
@mcp.tool()
@_with_audit
def run_shell_script(server: str, script: str, timeout: int = 0) -> str:
    """SSH into a server and run a multi-line bash script as a single unit.

    The entire script is piped to 'bash -s' over SSH, so commands share state:
    variables persist, 'cd' affects subsequent commands, and you can use loops,
    conditionals, and pipes freely.

    Use this when commands depend on each other. For simple independent commands,
    use run_shell_commands instead.

    Example script: "cd /var/log\\ngrep -c ERROR app.log\\ndu -sh ."

    Args:
        server: Server name, label, or alias — e.g. "PROD", "production", "prod"
        script: Multi-line bash script content (use \\n for newlines)
        timeout: Max seconds for the entire script to complete (default: 120)
    """
    info = _resolve_server(server)
    if "error" in info:
        return json.dumps(info, indent=2)

    t0 = time.time()
    result = _ssh_exec_script(info, script, timeout)

    return json.dumps({
        **_server_meta(info),
        "script_result": result,
        "success": result.get("exit_code") == 0,
        "duration": f"{time.time() - t0:.1f}s",
    }, indent=2)


# ---------------------------------------------------------------------------
# 5. fetch_system_logs
# ---------------------------------------------------------------------------
@mcp.tool()
@_with_audit
def fetch_system_logs(server: str, log_source: str = "journal",
                      lines: int = 100, grep_filter: str = "") -> str:
    """Fetch recent log entries from a server. Supports multiple log sources:

    Built-in sources:
    - "journal" — systemd journal (journalctl), the most common on modern Linux
    - "syslog" — /var/log/syslog or /var/log/messages
    - "dmesg" — kernel ring buffer (hardware, driver, boot messages)
    - "auth" — /var/log/auth.log or /var/log/secure (SSH logins, sudo, failures)
    - "nginx" — /var/log/nginx/error.log

    Custom: pass any file path like "/var/log/myapp/app.log" and it will tail that file.

    Optionally filter output with a grep pattern (case-insensitive).

    Args:
        server: Server name, label, or alias — e.g. "PROD", "production", "prod"
        log_source: Which logs to fetch — "journal", "syslog", "dmesg", "auth", "nginx",
                    or a custom file path like "/var/log/app.log"
        lines: How many recent lines to fetch from the end (default: 100)
        grep_filter: Only show lines matching this pattern — e.g. "error", "Failed password",
                     "OOM", "timeout" (case-insensitive grep)
    """
    # Validate lines parameter
    err = _validate_positive_int(lines, "lines", 10000)
    if err:
        return json.dumps({"error": err}, indent=2)

    info = _resolve_server(server)
    if "error" in info:
        return json.dumps(info, indent=2)

    log_cmds = {
        "dmesg": f"dmesg | tail -n {lines}",
        "syslog": (
            f"tail -n {lines} /var/log/syslog 2>/dev/null || "
            f"tail -n {lines} /var/log/messages 2>/dev/null || "
            "echo 'No syslog found at /var/log/syslog or /var/log/messages'"
        ),
        "journal": f"journalctl -n {lines} --no-pager 2>/dev/null || echo 'journalctl not available'",
        "auth": (
            f"tail -n {lines} /var/log/auth.log 2>/dev/null || "
            f"tail -n {lines} /var/log/secure 2>/dev/null || "
            "echo 'No auth log found at /var/log/auth.log or /var/log/secure'"
        ),
        "nginx": (
            f"tail -n {lines} /var/log/nginx/error.log 2>/dev/null || "
            "echo 'No nginx error log at /var/log/nginx/error.log'"
        ),
    }
    if log_source in log_cmds:
        cmd = log_cmds[log_source]
    else:
        # Custom file path — validate and quote
        err = _validate_name(log_source, "log_source path")
        if err:
            return json.dumps({"error": err}, indent=2)
        cmd = f"tail -n {lines} {_shell_quote(log_source)}"

    if grep_filter:
        cmd += f" | grep -i {_shell_quote(grep_filter)}"

    results = _ssh_exec(info, [cmd], per_cmd_timeout=30)

    return json.dumps({
        **_server_meta(info),
        "log_source": log_source,
        "lines_requested": lines,
        "grep_filter": grep_filter or None,
        "output": results[0] if results else {},
    }, indent=2)


# ---------------------------------------------------------------------------
# 6. list_running_processes
# ---------------------------------------------------------------------------
@mcp.tool()
@_with_audit
def list_running_processes(server: str, filter_name: str = "",
                           sort_by: str = "cpu") -> str:
    """List running processes on a server, sorted by resource consumption.

    By default shows the top 30 processes sorted by CPU usage. Optionally filter
    to only show processes matching a name (e.g. "nginx", "python", "java").

    Useful for diagnosing: "what is consuming CPU?", "is nginx running?",
    "how many node processes are active?".

    Args:
        server: Server name, label, or alias — e.g. "PROD", "production", "prod"
        filter_name: Only show processes whose command line contains this string
                     (case-insensitive) — e.g. "nginx", "python", "java", "docker"
        sort_by: Sort processes by "cpu" (default) or "mem" (memory usage)
    """
    info = _resolve_server(server)
    if "error" in info:
        return json.dumps(info, indent=2)

    sort_flag = "-%mem" if sort_by == "mem" else "-%cpu"
    cmd = f"ps aux --sort={sort_flag} 2>/dev/null || ps -ef"
    if filter_name:
        cmd += f" | grep -i {_shell_quote(filter_name)} | grep -v grep"
    else:
        cmd += " | head -31"

    results = _ssh_exec(info, [cmd], per_cmd_timeout=15)

    return json.dumps({
        **_server_meta(info),
        "filter": filter_name or None,
        "sort_by": sort_by,
        "output": results[0] if results else {},
    }, indent=2)


# ---------------------------------------------------------------------------
# 7. manage_systemd_service
# ---------------------------------------------------------------------------
@mcp.tool()
@_with_audit
def manage_systemd_service(server: str, service_name: str,
                           action: str = "status") -> str:
    """Manage a systemd service on a remote server.

    Supported actions:
    - "status" — check if the service is running, show recent output
    - "start" — start the service
    - "stop" — stop the service
    - "restart" — restart the service (stop + start)
    - "enable" — enable auto-start on boot
    - "disable" — disable auto-start on boot
    - "logs" — show the last 50 journal entries for this service

    After start/stop/restart/enable/disable, also reports the service's current
    active state so you can confirm the action took effect.

    Args:
        server: Server name, label, or alias — e.g. "PROD", "production", "prod"
        service_name: The systemd unit name — e.g. "nginx", "docker", "postgresql",
                      "sshd", "my-app.service"
        action: What to do — "status", "start", "stop", "restart", "enable",
                "disable", or "logs"
    """
    valid_actions = {"start", "stop", "restart", "status", "enable", "disable", "logs"}
    if action not in valid_actions:
        return json.dumps({
            "error": f"Invalid action '{action}'. Must be one of: {', '.join(sorted(valid_actions))}",
        }, indent=2)

    # Validate service name to prevent injection
    err = _validate_name(service_name, "service_name")
    if err:
        return json.dumps({"error": err}, indent=2)

    info = _resolve_server(server)
    if "error" in info:
        return json.dumps(info, indent=2)

    svc = _shell_quote(service_name)
    if action == "logs":
        cmd = (
            f"journalctl -u {svc} -n 50 --no-pager 2>/dev/null || "
            f"echo 'journalctl not available'"
        )
    elif action == "status":
        cmd = f"systemctl status {svc} --no-pager 2>&1"
    else:
        cmd = (
            f"systemctl {action} {svc} 2>&1; "
            f"echo '--- current state ---'; "
            f"systemctl is-active {svc} 2>&1; "
            f"systemctl is-enabled {svc} 2>&1"
        )

    results = _ssh_exec(info, [cmd], per_cmd_timeout=30)

    # Record service actions to DB
    if action in ("start", "stop", "restart", "enable", "disable"):
        try:
            new_status = "unknown"
            if results and results[0].get("stdout"):
                for line in results[0]["stdout"].split("\n"):
                    line = line.strip()
                    if line in ("active", "inactive", "failed", "dead"):
                        new_status = line
                        break
            _db.record_service_event(info["name"], service_name, "unknown", new_status, action)
        except Exception:
            pass

    return json.dumps({
        **_server_meta(info),
        "service": service_name,
        "action": action,
        "result": results[0] if results else {},
    }, indent=2)


# ---------------------------------------------------------------------------
# 8. list_all_services
# ---------------------------------------------------------------------------
@mcp.tool()
@_with_audit
def list_all_services(server: str, filter_status: str = "all") -> str:
    """List ALL systemd services installed on a server with their current status.

    Shows every service unit with its load state, active state, sub-state, and
    description. Filter to see only running, failed, inactive, or dead services.

    Use this to discover what services exist on a server before managing them.

    Args:
        server: Server name, label, or alias — e.g. "PROD", "production", "prod"
        filter_status: Filter by status — "all" (default), "running", "failed",
                       "inactive", "dead", "exited"
    """
    valid_filters = {"all", "running", "failed", "inactive", "dead", "exited"}
    if filter_status not in valid_filters:
        return json.dumps({"error": f"Invalid filter '{filter_status}'. Use: {sorted(valid_filters)}"}, indent=2)

    info = _resolve_server(server)
    if "error" in info:
        return json.dumps(info, indent=2)

    cmd = "systemctl list-units --type=service --all --no-pager --no-legend 2>&1"
    results = _ssh_exec(info, [cmd], per_cmd_timeout=15)

    raw = results[0].get("stdout", "") if results else ""
    services = []
    for line in raw.splitlines():
        line = line.strip()
        if not line:
            continue
        # Strip leading bullet (● or *)
        if line and line[0] in ("●", "*", "\u25cf"):
            line = line[1:].strip()
        parts = line.split(None, 4)
        if len(parts) >= 4:
            svc = {
                "unit": parts[0],
                "load": parts[1],
                "active": parts[2],
                "sub": parts[3],
                "description": parts[4] if len(parts) > 4 else "",
            }
            if filter_status == "all" or svc["active"] == filter_status or svc["sub"] == filter_status:
                services.append(svc)

    return json.dumps({
        **_server_meta(info),
        "filter": filter_status,
        "services": services,
        "total": len(services),
    }, indent=2)


# ---------------------------------------------------------------------------
# 9. find_failed_services
# ---------------------------------------------------------------------------
@mcp.tool()
@_with_audit
def find_failed_services(server: str) -> str:
    """Find all systemd services that are currently in a failed state on a server.

    This is the fastest way to answer "is anything broken?" — it only returns
    services that have crashed or failed to start.

    If no services are failed, returns count=0 with a reassuring message.

    Args:
        server: Server name, label, or alias — e.g. "PROD", "production", "prod"
    """
    info = _resolve_server(server)
    if "error" in info:
        return json.dumps(info, indent=2)

    cmd = "systemctl --failed --no-pager --no-legend 2>&1"
    results = _ssh_exec(info, [cmd], per_cmd_timeout=15)

    raw = results[0].get("stdout", "") if results else ""
    failed = []
    for line in raw.splitlines():
        line = line.strip()
        if not line or "0 loaded" in line.lower():
            continue
        if line and line[0] in ("●", "*", "\u25cf"):
            line = line[1:].strip()
        parts = line.split(None, 4)
        if len(parts) >= 4:
            failed.append({
                "unit": parts[0],
                "load": parts[1],
                "active": parts[2],
                "sub": parts[3],
                "description": parts[4] if len(parts) > 4 else "",
            })

    result = {
        **_server_meta(info),
        "failed_services": failed,
        "count": len(failed),
    }
    if not failed:
        result["message"] = "No failed services — all healthy."
    return json.dumps(result, indent=2)


# ---------------------------------------------------------------------------
# 10. restart_failed_services
# ---------------------------------------------------------------------------
@mcp.tool()
@_with_audit
def restart_failed_services(server: str, services: list[str]) -> str:
    """Bulk restart one or more failed services on a server.

    Pass specific service names or ["ALL_FAILED"] to automatically detect and
    restart every failed service.

    For each service: attempts restart, then checks the new status. Reports
    per-service success/failure so you know exactly what recovered and what didn't.

    Args:
        server: Server name, label, or alias — e.g. "PROD", "production", "prod"
        services: List of service unit names to restart — e.g. ["nginx", "redis"],
                  or ["ALL_FAILED"] to restart all currently failed services
    """
    info = _resolve_server(server)
    if "error" in info:
        return json.dumps(info, indent=2)

    # Resolve ALL_FAILED to actual service names
    if len(services) == 1 and services[0].upper() == "ALL_FAILED":
        detect_cmd = "systemctl --failed --no-pager --no-legend 2>&1"
        detect_results = _ssh_exec(info, [detect_cmd], per_cmd_timeout=15)
        raw = detect_results[0].get("stdout", "") if detect_results else ""
        services = []
        for line in raw.splitlines():
            line = line.strip()
            if not line or "0 loaded" in line.lower():
                continue
            if line and line[0] in ("●", "*", "\u25cf"):
                line = line[1:].strip()
            parts = line.split(None, 1)
            if parts:
                services.append(parts[0])
        if not services:
            return json.dumps({
                **_server_meta(info),
                "message": "No failed services found — nothing to restart.",
                "restarted": [],
            }, indent=2)

    # Validate all service names
    for svc in services:
        err = _validate_name(svc, "service name")
        if err:
            return json.dumps({"error": err}, indent=2)

    # Build restart script
    script_lines = []
    for svc in services:
        s = _shell_quote(svc)
        script_lines.append(f'echo "===SVC:{svc}==="')
        script_lines.append(f"systemctl restart {s} 2>&1; echo EXIT:$?")
        script_lines.append(f"systemctl is-active {s} 2>&1")
    script = "\n".join(script_lines)

    result = _ssh_exec_script(info, script, timeout=60)
    raw = result.get("stdout", "")

    # Parse results
    restart_results = []
    for svc in services:
        marker = f"===SVC:{svc}==="
        idx = raw.find(marker)
        if idx < 0:
            restart_results.append({"service": svc, "restart_success": False, "new_status": "unknown"})
            continue
        chunk = raw[idx + len(marker):]
        next_marker = chunk.find("===SVC:")
        if next_marker > 0:
            chunk = chunk[:next_marker]
        lines = [l.strip() for l in chunk.strip().splitlines() if l.strip()]
        exit_code = -1
        new_status = "unknown"
        for line in lines:
            if line.startswith("EXIT:"):
                try:
                    exit_code = int(line.split(":")[1])
                except ValueError:
                    pass
            elif line in ("active", "inactive", "failed", "activating", "deactivating", "dead"):
                new_status = line

        success = exit_code == 0 and new_status == "active"
        restart_results.append({
            "service": svc,
            "restart_success": success,
            "new_status": new_status,
        })

        # Record to DB
        try:
            _db.record_service_event(info["name"], svc, "failed", new_status, "restarted")
        except Exception:
            pass

    succeeded = sum(1 for r in restart_results if r["restart_success"])
    return json.dumps({
        **_server_meta(info),
        "restarted": restart_results,
        "total": len(restart_results),
        "succeeded": succeeded,
        "failed": len(restart_results) - succeeded,
    }, indent=2)


# ---------------------------------------------------------------------------
# 11. watch_service_status
# ---------------------------------------------------------------------------
@mcp.tool()
@_with_audit
def watch_service_status(server: str, services: list[str]) -> str:
    """Lightweight status check for specific services on a server.

    For each service, returns: is it active, is it enabled for boot, and when
    it was last started. Much faster than checking full systemctl status for each.

    Use this to quickly verify: "are nginx and redis running?" without the noise
    of full status output.

    Args:
        server: Server name, label, or alias — e.g. "PROD", "production", "prod"
        services: List of service names to check — e.g. ["nginx", "redis", "docker", "sshd"]
    """
    if not services:
        return json.dumps({"error": "No services specified."}, indent=2)

    for svc in services:
        err = _validate_name(svc, "service name")
        if err:
            return json.dumps({"error": err}, indent=2)

    info = _resolve_server(server)
    if "error" in info:
        return json.dumps(info, indent=2)

    script_lines = []
    for svc in services:
        s = _shell_quote(svc)
        script_lines.append(f'echo "===SVC:{svc}==="')
        script_lines.append(f"systemctl is-active {s} 2>&1")
        script_lines.append('echo "---"')
        script_lines.append(f"systemctl is-enabled {s} 2>&1")
        script_lines.append('echo "---"')
        script_lines.append(f"systemctl show {s} --property=ActiveEnterTimestamp --no-pager 2>&1")
    script = "\n".join(script_lines)

    result = _ssh_exec_script(info, script, timeout=30)
    raw = result.get("stdout", "")

    statuses = []
    for svc in services:
        marker = f"===SVC:{svc}==="
        idx = raw.find(marker)
        if idx < 0:
            statuses.append({"service": svc, "is_active": "unknown", "is_enabled": "unknown", "active_since": ""})
            continue
        chunk = raw[idx + len(marker):]
        next_marker = chunk.find("===SVC:")
        if next_marker > 0:
            chunk = chunk[:next_marker]
        parts = chunk.strip().split("---")
        is_active = parts[0].strip() if len(parts) > 0 else "unknown"
        is_enabled = parts[1].strip() if len(parts) > 1 else "unknown"
        active_since = parts[2].strip().replace("ActiveEnterTimestamp=", "") if len(parts) > 2 else ""

        statuses.append({
            "service": svc,
            "is_active": is_active,
            "is_enabled": is_enabled,
            "active_since": active_since,
        })

    all_active = all(s["is_active"] == "active" for s in statuses)
    return json.dumps({
        **_server_meta(info),
        "services": statuses,
        "total": len(statuses),
        "all_active": all_active,
    }, indent=2)


# ---------------------------------------------------------------------------
# 12. run_on_all_servers
# ---------------------------------------------------------------------------
@mcp.tool()
@_with_audit
def run_on_all_servers(servers: list[str], commands: list[str],
                       per_cmd_timeout: int = 0) -> str:
    """Run the same shell commands on multiple servers and collect all results.

    Pass ["ALL"] as servers to target every configured server at once. Otherwise
    pass a list of specific server names, labels, or aliases.

    Each server is contacted sequentially. Results include per-server command
    output, exit codes, and timing.

    Useful for: "check disk space on all servers", "what kernel version is each
    server running?", "is nginx running everywhere?".

    Args:
        servers: Which servers to target — e.g. ["PROD", "STAGING"] or ["ALL"] for all
        commands: Shell commands to run on each server — e.g. ["df -h /", "uname -r"]
        per_cmd_timeout: Max seconds per command per server (default: 30)
    """
    if not servers:
        return json.dumps({"error": "No servers specified. Pass server names or ['ALL']."}, indent=2)

    resolved = _resolve_server_list(servers)
    all_results = []

    for info in resolved:
        if "error" in info:
            all_results.append({"server": "unknown", "error": info["error"]})
            continue

        t0 = time.time()
        results = _ssh_exec(info, commands, per_cmd_timeout)
        all_results.append({
            **_server_meta(info),
            "command_results": results,
            "duration": f"{time.time() - t0:.1f}s",
        })

    succeeded = sum(1 for r in all_results if "error" not in r)
    return json.dumps({
        "results": all_results,
        "server_count": len(all_results),
        "succeeded": succeeded,
        "failed": len(all_results) - succeeded,
    }, indent=2)


# ===========================================================================
# PHASE 2: DIFFERENTIATOR TOOLS (6 tools)
# ===========================================================================

# ---------------------------------------------------------------------------
# 9. check_ssl_certificate
# ---------------------------------------------------------------------------
@mcp.tool()
@_with_audit
def check_ssl_certificate(domain: str, port: int = 443) -> str:
    """Check the SSL/TLS certificate of any domain without needing SSH access.
    Connects directly from this machine to the domain on the specified port.

    Reports: subject, issuer, validity dates, days until expiry, SAN domains,
    serial number, and a status of OK / WARNING (< 30 days) / EXPIRED.

    Use this to monitor certificate expiry before it causes outages.

    Args:
        domain: Domain name to check — e.g. "example.com", "api.myapp.com",
                "staging.company.io"
        port: The HTTPS port to connect on (default: 443)
    """
    return json.dumps(_do_ssl_check(domain, port), indent=2)


# ---------------------------------------------------------------------------
# 10. check_http_endpoint
# ---------------------------------------------------------------------------
@mcp.tool()
@_with_audit
def check_http_endpoint(url: str, method: str = "GET",
                        expected_status: int = 200, timeout: int = 10) -> str:
    """Check if an HTTP/HTTPS URL is responding. No SSH needed — connects directly
    from this machine.

    Reports: HTTP status code, response time in milliseconds, key headers
    (content-type, server), and the first 500 characters of the response body.

    Also checks whether the actual status code matches your expected status code
    and reports pass/fail accordingly.

    Use this to verify: "is my API up?", "is the health endpoint returning 200?",
    "how fast is the homepage loading?".

    Args:
        url: Full URL to check — e.g. "https://example.com/health",
             "http://myapp.com:8080/api/v1/status"
        method: HTTP method — "GET" (default), "HEAD", "POST"
        expected_status: Expected HTTP status code (default: 200). Set to 0 to skip check.
        timeout: Request timeout in seconds (default: 10)
    """
    return json.dumps(_do_http_check(url, method, expected_status, timeout), indent=2)


# ---------------------------------------------------------------------------
# 11. list_docker_containers
# ---------------------------------------------------------------------------
@mcp.tool()
@_with_audit
def list_docker_containers(server: str, include_stopped: bool = False) -> str:
    """List all Docker containers running on a server with their status, image,
    ports, and live resource usage (CPU%, memory, network I/O, block I/O).

    Shows running containers by default. Set include_stopped=True to also show
    stopped/exited containers.

    Args:
        server: Server name, label, or alias — e.g. "PROD", "production", "prod"
        include_stopped: Also show stopped/exited containers (default: False)
    """
    info = _resolve_server(server)
    if "error" in info:
        return json.dumps(info, indent=2)

    flag = " -a" if include_stopped else ""
    script = f"""
if ! command -v docker &>/dev/null; then
    echo "===ERROR==="
    echo "Docker is not installed on this server"
    exit 0
fi
echo "===CONTAINERS==="
docker ps{flag} --format 'table {{{{.ID}}}}\\t{{{{.Names}}}}\\t{{{{.Image}}}}\\t{{{{.Status}}}}\\t{{{{.Ports}}}}' 2>&1
echo "===STATS==="
docker stats --no-stream --format 'table {{{{.Name}}}}\\t{{{{.CPUPerc}}}}\\t{{{{.MemUsage}}}}\\t{{{{.MemPerc}}}}\\t{{{{.NetIO}}}}\\t{{{{.BlockIO}}}}' 2>&1
echo "===COUNT==="
echo "running: $(docker ps -q 2>/dev/null | wc -l)"
echo "total: $(docker ps -aq 2>/dev/null | wc -l)"
"""

    result = _ssh_exec_script(info, script, timeout=30)
    sections = _parse_sections(result.get("stdout", ""))

    if "ERROR" in sections:
        return json.dumps({
            **_server_meta(info),
            "error": sections["ERROR"],
        }, indent=2)

    return json.dumps({
        **_server_meta(info),
        "containers": sections.get("CONTAINERS", ""),
        "resource_usage": sections.get("STATS", ""),
        "counts": sections.get("COUNT", ""),
    }, indent=2)


# ---------------------------------------------------------------------------
# 12. fetch_docker_logs
# ---------------------------------------------------------------------------
@mcp.tool()
@_with_audit
def fetch_docker_logs(server: str, container: str, lines: int = 100,
                      grep_filter: str = "", since: str = "") -> str:
    """Fetch recent logs from a Docker container on a remote server.

    Shows the last N lines from the container's stdout/stderr. Optionally filter
    with a grep pattern or limit to logs since a certain time.

    Args:
        server: Server name, label, or alias — e.g. "PROD", "production", "prod"
        container: Docker container name or ID — e.g. "my-app", "redis", "abc123"
        lines: Number of recent lines to fetch (default: 100)
        grep_filter: Only show lines matching this pattern (case-insensitive) —
                     e.g. "error", "timeout", "connection refused"
        since: Only show logs since this time — e.g. "1h" (last hour), "30m",
               "2024-01-15T10:00:00" (empty = no time filter)
    """
    # Validate container name
    err = _validate_name(container, "container")
    if err:
        return json.dumps({"error": err}, indent=2)
    if since:
        err = _validate_name(since, "since")
        if err:
            return json.dumps({"error": err}, indent=2)
    err = _validate_positive_int(lines, "lines", 10000)
    if err:
        return json.dumps({"error": err}, indent=2)

    info = _resolve_server(server)
    if "error" in info:
        return json.dumps(info, indent=2)

    since_flag = f" --since {_shell_quote(since)}" if since else ""
    cmd = f"docker logs --tail {lines}{since_flag} {_shell_quote(container)} 2>&1"
    if grep_filter:
        cmd += f" | grep -i {_shell_quote(grep_filter)}"

    results = _ssh_exec(info, [cmd], per_cmd_timeout=30)

    return json.dumps({
        **_server_meta(info),
        "container": container,
        "lines_requested": lines,
        "grep_filter": grep_filter or None,
        "since": since or None,
        "output": results[0] if results else {},
    }, indent=2)


# ---------------------------------------------------------------------------
# 13. analyze_disk_usage
# ---------------------------------------------------------------------------
@mcp.tool()
@_with_audit
def analyze_disk_usage(server: str, path: str = "/") -> str:
    """Analyze disk usage on a server to find what is consuming space.

    For a given path, shows:
    1. Filesystem info — total size, used, available, use percentage (df -h)
    2. Top 20 largest items — subdirectories and files sorted by size (du -sh)
    3. Inode usage — in case you're running out of inodes, not space

    Use this when a server reports "disk full" or when you need to find large
    files to clean up.

    Args:
        server: Server name, label, or alias — e.g. "PROD", "production", "prod"
        path: Directory to analyze — e.g. "/" (whole disk), "/var/log" (just logs),
              "/home" (user data), "/tmp" (temp files)
    """
    # Validate path
    err = _validate_name(path, "path")
    if err:
        return json.dumps({"error": err}, indent=2)

    info = _resolve_server(server)
    if "error" in info:
        return json.dumps(info, indent=2)

    p = _shell_quote(path)
    script = f"""
echo "===FILESYSTEM==="
df -h {p} 2>/dev/null || echo "Cannot stat {p}"
echo "===LARGEST_ITEMS==="
du -sh {p}/* 2>/dev/null | sort -rh | head -20
echo "===LARGE_FILES==="
find {p} -maxdepth 3 -type f -size +100M -exec ls -lh {{}} \\; 2>/dev/null | sort -k5 -rh | head -10
echo "===INODES==="
df -i {p} 2>/dev/null || echo "No inode data"
echo "===OLD_LOGS==="
find /var/log -name "*.gz" -o -name "*.old" -o -name "*.[0-9]" 2>/dev/null | wc -l
echo "rotated log files found"
"""

    result = _ssh_exec_script(info, script, timeout=30)
    sections = _parse_sections(result.get("stdout", ""))

    return json.dumps({
        **_server_meta(info),
        "path": path,
        "filesystem": sections.get("FILESYSTEM", ""),
        "largest_items": sections.get("LARGEST_ITEMS", ""),
        "large_files_over_100mb": sections.get("LARGE_FILES", ""),
        "inodes": sections.get("INODES", ""),
        "rotated_logs": sections.get("OLD_LOGS", ""),
    }, indent=2)


# ---------------------------------------------------------------------------
# 14. inspect_network
# ---------------------------------------------------------------------------
@mcp.tool()
@_with_audit
def inspect_network(server: str) -> str:
    """Inspect the network configuration and activity of a server.

    Shows three things:
    1. Listening ports — all TCP ports this server has open, with the process
       that owns each one (ss -tlnp)
    2. Active connections — current established TCP connections (top 30)
    3. Network interfaces — all interfaces with their IP addresses

    Use this to answer: "what ports are open?", "is port 443 listening?",
    "what's connecting to this server?", "what IPs does this server have?".

    Args:
        server: Server name, label, or alias — e.g. "PROD", "production", "prod"
    """
    info = _resolve_server(server)
    if "error" in info:
        return json.dumps(info, indent=2)

    script = """
echo "===LISTENING_PORTS==="
ss -tlnp 2>/dev/null || netstat -tlnp 2>/dev/null || echo "Neither ss nor netstat available"
echo "===ACTIVE_CONNECTIONS==="
ss -tnp state established 2>/dev/null | head -30 || netstat -tnp 2>/dev/null | grep ESTABLISHED | head -30
echo "===INTERFACES==="
ip -4 addr show 2>/dev/null || ifconfig 2>/dev/null
echo "===DNS==="
cat /etc/resolv.conf 2>/dev/null | grep -v "^#" | grep -v "^$"
echo "===ROUTING==="
ip route show default 2>/dev/null || route -n 2>/dev/null | head -5
"""

    result = _ssh_exec_script(info, script, timeout=15)
    sections = _parse_sections(result.get("stdout", ""))

    return json.dumps({
        **_server_meta(info),
        "listening_ports": sections.get("LISTENING_PORTS", ""),
        "active_connections": sections.get("ACTIVE_CONNECTIONS", ""),
        "interfaces": sections.get("INTERFACES", ""),
        "dns_servers": sections.get("DNS", ""),
        "default_route": sections.get("ROUTING", ""),
    }, indent=2)


# ===========================================================================
# PHASE 3: POLISH TOOLS (5 tools)
# ===========================================================================

# ---------------------------------------------------------------------------
# 15. read_remote_file
# ---------------------------------------------------------------------------
@mcp.tool()
@_with_audit
def read_remote_file(server: str, file_path: str, lines: int = 50,
                     mode: str = "tail") -> str:
    """Read the contents of a file on a remote server without downloading it.

    Three modes:
    - "tail" (default) — last N lines, like 'tail -n 50'. Best for log files.
    - "head" — first N lines, like 'head -n 50'. Best for config files.
    - "all" — entire file contents (use with caution on large files).

    Use this to quickly inspect config files, check log tails, or read small
    scripts on the server.

    Args:
        server: Server name, label, or alias — e.g. "PROD", "production", "prod"
        file_path: Absolute path to the file on the server — e.g. "/etc/nginx/nginx.conf",
                   "/var/log/app.log", "/home/deploy/.env"
        lines: Number of lines to read (default: 50, ignored when mode is "all")
        mode: "tail" (last N lines), "head" (first N lines), or "all" (entire file)
    """
    # Validate inputs
    err = _validate_name(file_path, "file_path")
    if err:
        return json.dumps({"error": err}, indent=2)
    err = _validate_positive_int(lines, "lines", 10000)
    if err:
        return json.dumps({"error": err}, indent=2)
    if mode not in ("tail", "head", "all"):
        return json.dumps({"error": f"Invalid mode '{mode}'. Use 'tail', 'head', or 'all'."}, indent=2)

    info = _resolve_server(server)
    if "error" in info:
        return json.dumps(info, indent=2)

    fp = _shell_quote(file_path)
    if mode == "head":
        cmd = f"head -n {lines} {fp} 2>&1"
    elif mode == "all":
        cmd = f"cat {fp} 2>&1"
    else:
        cmd = f"tail -n {lines} {fp} 2>&1"

    # Also get file metadata
    meta_cmd = f"ls -lh {fp} 2>/dev/null && wc -l < {fp} 2>/dev/null"

    results = _ssh_exec(info, [cmd, meta_cmd], per_cmd_timeout=15)

    output = results[0] if results else {}
    file_info = results[1].get("stdout", "") if len(results) > 1 else ""

    return json.dumps({
        **_server_meta(info),
        "file_path": file_path,
        "mode": mode,
        "lines_requested": lines if mode != "all" else "all",
        "file_info": file_info,
        "content": output,
    }, indent=2)


# ---------------------------------------------------------------------------
# 16. upload_file_to_server
# ---------------------------------------------------------------------------
@mcp.tool()
@_with_audit
def upload_file_to_server(server: str, local_path: str, remote_path: str) -> str:
    """Upload a file from your local machine to a remote server using SFTP.

    The remote directory must already exist. If it doesn't, use run_shell_commands
    first to create it with 'mkdir -p /path/to/dir'.

    After upload, verifies the file arrived by comparing sizes.

    Args:
        server: Server name, label, or alias — e.g. "PROD", "production", "prod"
        local_path: Path to the file on your local machine — e.g. "C:/temp/config.yaml",
                    "/home/user/deploy/app.tar.gz"
        remote_path: Full destination path on the server — e.g. "/etc/app/config.yaml",
                     "/tmp/app.tar.gz"
    """
    if not os.path.exists(local_path):
        return json.dumps({"error": f"Local file not found: {local_path}"}, indent=2)
    if os.path.isdir(local_path):
        return json.dumps({"error": f"Path is a directory, not a file: {local_path}. Use tar/zip first."}, indent=2)

    info = _resolve_server(server)
    if "error" in info:
        return json.dumps(info, indent=2)

    t0 = time.time()
    result = _sftp_push(info, local_path, remote_path)
    elapsed = time.time() - t0

    size_match = result.get("bytes_transferred") == result.get("remote_size") if result.get("success") else False

    return json.dumps({
        **_server_meta(info),
        **result,
        "size_verified": size_match,
        "duration": f"{elapsed:.1f}s",
    }, indent=2)


# ---------------------------------------------------------------------------
# 17. download_file_from_server
# ---------------------------------------------------------------------------
@mcp.tool()
@_with_audit
def download_file_from_server(server: str, remote_path: str, local_path: str) -> str:
    """Download a file from a remote server to your local machine using SFTP.

    The local directory must already exist.

    Args:
        server: Server name, label, or alias — e.g. "PROD", "production", "prod"
        remote_path: Full path of the file on the server — e.g. "/var/log/app.log",
                     "/tmp/database-backup.sql.gz"
        local_path: Where to save the file locally — e.g. "C:/temp/app.log",
                    "/home/user/downloads/backup.sql.gz"
    """
    local_dir = os.path.dirname(local_path)
    if local_dir and not os.path.isdir(local_dir):
        return json.dumps({"error": f"Local directory does not exist: {local_dir}"}, indent=2)

    info = _resolve_server(server)
    if "error" in info:
        return json.dumps(info, indent=2)

    t0 = time.time()
    result = _sftp_pull(info, remote_path, local_path)

    return json.dumps({
        **_server_meta(info),
        **result,
        "duration": f"{time.time() - t0:.1f}s",
    }, indent=2)


# ---------------------------------------------------------------------------
# 18. run_security_audit
# ---------------------------------------------------------------------------
@mcp.tool()
@_with_audit
def run_security_audit(server: str) -> str:
    """Run a basic security audit on a server to check for common misconfigurations.

    Checks performed:
    1. SSH config — PermitRootLogin, PasswordAuthentication, MaxAuthTries settings
    2. Open ports — all TCP ports accepting connections, with process names
    3. Firewall — UFW or iptables status and rules
    4. Pending updates — packages that need security updates
    5. Failed SSH logins — last 10 failed password attempts (brute-force detection)
    6. Root processes — count of processes running as root
    7. World-writable files — files in /etc that anyone can modify (dangerous)
    8. Recent logins — last 10 user login sessions
    9. Sudo users — users with sudo/root privileges
    10. Unattended upgrades — whether automatic security updates are enabled

    Returns all findings in structured sections for easy review.

    Args:
        server: Server name, label, or alias — e.g. "PROD", "production", "prod"
    """
    info = _resolve_server(server)
    if "error" in info:
        return json.dumps(info, indent=2)

    script = r"""
echo "===SSH_CONFIG==="
echo "--- /etc/ssh/sshd_config ---"
grep -E "^\s*(PermitRootLogin|PasswordAuthentication|PubkeyAuthentication|Port |MaxAuthTries|PermitEmptyPasswords|X11Forwarding|AllowUsers|AllowGroups)" /etc/ssh/sshd_config 2>/dev/null || echo "Cannot read sshd_config"

echo "===OPEN_PORTS==="
ss -tlnp 2>/dev/null | grep LISTEN || netstat -tlnp 2>/dev/null | grep LISTEN || echo "Cannot list ports"

echo "===FIREWALL==="
if command -v ufw &>/dev/null; then
    echo "--- UFW ---"
    ufw status verbose 2>/dev/null
elif command -v firewall-cmd &>/dev/null; then
    echo "--- firewalld ---"
    firewall-cmd --list-all 2>/dev/null
else
    echo "--- iptables ---"
    iptables -L -n --line-numbers 2>/dev/null | head -30 || echo "No firewall detected"
fi

echo "===PENDING_UPDATES==="
if command -v apt &>/dev/null; then
    apt list --upgradable 2>/dev/null | tail -n +2 | head -15
    echo "---"
    echo "$(apt list --upgradable 2>/dev/null | tail -n +2 | wc -l) packages can be upgraded"
elif command -v yum &>/dev/null; then
    yum check-update --quiet 2>/dev/null | head -15
elif command -v dnf &>/dev/null; then
    dnf check-update --quiet 2>/dev/null | head -15
else
    echo "Unknown package manager"
fi

echo "===FAILED_LOGINS==="
grep "Failed password" /var/log/auth.log 2>/dev/null | tail -10 || \
grep "Failed password" /var/log/secure 2>/dev/null | tail -10 || \
echo "No failed login data found"

echo "===ROOT_PROCESSES==="
root_count=$(ps aux 2>/dev/null | awk '$1=="root"' | wc -l)
echo "$root_count processes running as root"
ps aux 2>/dev/null | awk '$1=="root"' | sort -k3 -rn | head -5

echo "===WORLD_WRITABLE==="
writable=$(find /etc -maxdepth 2 -perm -o+w -type f 2>/dev/null)
if [ -n "$writable" ]; then
    echo "$writable" | head -10
    echo "---"
    echo "$(echo "$writable" | wc -l) world-writable files in /etc (RISK)"
else
    echo "No world-writable files in /etc (good)"
fi

echo "===RECENT_LOGINS==="
last -n 10 2>/dev/null || echo "No login history"

echo "===SUDO_USERS==="
grep -E "^[^#].*ALL.*ALL" /etc/sudoers 2>/dev/null | head -10
getent group sudo 2>/dev/null || getent group wheel 2>/dev/null || echo "No sudo group info"

echo "===AUTO_UPDATES==="
if [ -f /etc/apt/apt.conf.d/20auto-upgrades ]; then
    cat /etc/apt/apt.conf.d/20auto-upgrades
elif command -v dnf &>/dev/null; then
    dnf needs-restarting --reboothint 2>/dev/null || echo "Unknown"
else
    echo "Auto-update status unknown"
fi
"""

    t0 = time.time()
    result = _ssh_exec_script(info, script, timeout=60)
    sections = _parse_sections(result.get("stdout", ""))

    return json.dumps({
        **_server_meta(info),
        "audit": sections,
        "checks_performed": len(sections),
        "duration": f"{time.time() - t0:.1f}s",
    }, indent=2)


# ---------------------------------------------------------------------------
# 19. compare_across_servers
# ---------------------------------------------------------------------------
@mcp.tool()
@_with_audit
def compare_across_servers(servers: list[str], command: str) -> str:
    """Run the same command on multiple servers and display results side by side
    to spot differences.

    Automatically detects if all servers returned identical output. This is useful
    for verifying consistency across your fleet: "do all servers have the same
    kernel version?", "is the config file identical everywhere?", "same disk usage?".

    Pass ["ALL"] as servers to compare every configured server.

    Args:
        servers: Which servers to compare — e.g. ["PROD", "STAGING"] or ["ALL"]
        command: Single shell command to run on each — e.g. "uname -r",
                 "cat /etc/app/version.txt", "docker --version", "df -h /"
    """
    if not servers:
        return json.dumps({"error": "No servers specified. Pass server names or ['ALL']."}, indent=2)

    resolved = _resolve_server_list(servers)
    comparison = []
    outputs = []

    for info in resolved:
        if "error" in info:
            comparison.append({"server": "unknown", "error": info["error"]})
            continue

        results = _ssh_exec(info, [command], per_cmd_timeout=DEFAULT_CMD_TIMEOUT)
        output = results[0].get("stdout", "") if results else ""
        exit_code = results[0].get("exit_code", -1) if results else -1
        outputs.append(output)
        comparison.append({
            "server": info["name"],
            "label": info["label"],
            "exit_code": exit_code,
            "output": output,
        })

    # Detect if all outputs are identical
    unique_outputs = set(outputs)
    identical = len(unique_outputs) <= 1 and len(outputs) > 0

    return json.dumps({
        "command": command,
        "comparison": comparison,
        "server_count": len(comparison),
        "all_identical": identical,
        "unique_outputs": len(unique_outputs),
    }, indent=2)


# ===========================================================================
# PHASE 4: MONITORING TOOLS WITH SQLITE (5 tools)
# ===========================================================================

# ---------------------------------------------------------------------------
# 24. monitor_server_health
# ---------------------------------------------------------------------------
@mcp.tool()
@_with_audit
def monitor_server_health(server: str) -> str:
    """Check server health AND store the results in the local database for trend
    tracking. Also auto-generates alerts if thresholds are exceeded:
    - Disk usage >90% → critical alert
    - Disk usage >80% → warning alert
    - CPU load > 2x core count → warning alert
    - Temperature >85°C → warning alert

    Use this instead of check_server_health when you want to build up a history
    of health data over time. Call it periodically to track trends.

    Args:
        server: Server name, label, or alias — e.g. "PROD", "production", "prod"
    """
    info = _resolve_server(server)
    if "error" in info:
        return json.dumps(info, indent=2)

    t0 = time.time()
    result = _ssh_exec_script(info, _HEALTH_SCRIPT, timeout=30)
    sections = _parse_sections(result.get("stdout", ""))

    # Store in DB and check thresholds
    row_id = 0
    alerts_generated = 0
    try:
        row_id, alerts_generated = _db.record_health(info["name"], sections)
    except Exception:
        pass

    return json.dumps({
        **_server_meta(info),
        "health": sections,
        "stored": row_id > 0,
        "snapshot_id": row_id,
        "alerts_generated": alerts_generated,
        "ssh_stderr": result.get("stderr", "") or None,
        "duration": f"{time.time() - t0:.1f}s",
    }, indent=2)


# ---------------------------------------------------------------------------
# 25. monitor_endpoints
# ---------------------------------------------------------------------------
@mcp.tool()
@_with_audit
def monitor_endpoints(targets: list[str]) -> str:
    """Check multiple HTTP URLs and SSL domains in one call, store all results
    in the database, and auto-generate alerts for failures.

    For each target:
    - If it starts with http:// or https:// → runs an HTTP check
    - Otherwise → treats it as a domain and checks its SSL certificate

    Alerts are generated for:
    - HTTP endpoints that fail or return unexpected status
    - SSL certificates expiring within 30 days or already expired

    Args:
        targets: List of URLs and/or domains to check — e.g.
                 ["https://myapp.com/health", "api.example.com", "http://staging:8080"]
    """
    if not targets:
        return json.dumps({"error": "No targets specified."}, indent=2)

    results = []
    alerts_generated = 0

    for target in targets:
        target = target.strip()
        if target.startswith("http://") or target.startswith("https://"):
            # HTTP check
            check = _do_http_check(target)
            check_type = "http"
            status = check.get("result", "FAIL")
            response_time = check.get("response_time_ms")

            try:
                _db.record_endpoint_check(target, check_type, status, response_time, check)
            except Exception:
                pass

            if status == "FAIL":
                try:
                    _db.record_alert(target, "critical", "endpoint_down",
                                     f"HTTP check failed for {target}: {check.get('error', 'non-200 status')}")
                    alerts_generated += 1
                except Exception:
                    pass
        else:
            # SSL check
            domain = target.split(":")[0]
            port = 443
            if ":" in target:
                try:
                    port = int(target.split(":")[1])
                except ValueError:
                    pass
            check = _do_ssl_check(domain, port)
            check_type = "ssl"
            status = check.get("status", "ERROR")
            response_time = None

            try:
                _db.record_endpoint_check(domain, check_type, status, response_time, check)
            except Exception:
                pass

            if status in ("EXPIRED", "CRITICAL", "INVALID"):
                severity = "critical"
                try:
                    _db.record_alert(domain, severity, "ssl_expiring",
                                     f"SSL cert for {domain}: {status} (expires in {check.get('days_until_expiry', '?')} days)")
                    alerts_generated += 1
                except Exception:
                    pass
            elif status == "WARNING":
                try:
                    _db.record_alert(domain, "warning", "ssl_expiring",
                                     f"SSL cert for {domain}: expires in {check.get('days_until_expiry', '?')} days")
                    alerts_generated += 1
                except Exception:
                    pass

        results.append({"target": target, "type": check_type, "status": status, "details": check})

    return json.dumps({
        "results": results,
        "checked": len(results),
        "alerts_generated": alerts_generated,
    }, indent=2)


# ---------------------------------------------------------------------------
# 26. get_monitoring_history
# ---------------------------------------------------------------------------
@mcp.tool()
@_with_audit
def get_monitoring_history(server: str, hours: int = 24) -> str:
    """Query stored monitoring data from the local database to see trends over time.

    Returns health snapshots, service events, and endpoint checks from the last
    N hours. Also computes trends by comparing the oldest and newest health
    snapshots (e.g. "disk went from 60% to 90%").

    Data is only available if you've been calling monitor_server_health and
    monitor_endpoints periodically.

    Args:
        server: Server name to query — e.g. "PROD", "production", "prod"
        hours: How far back to look in hours (default: 24)
    """
    err = _validate_positive_int(hours, "hours", 8760)
    if err:
        return json.dumps({"error": err}, indent=2)

    # Resolve server name for DB lookup
    info = _resolve_server(server)
    server_name = info.get("name", server.upper()) if "error" not in info else server.upper()

    try:
        health = _db.get_health_history(server_name, hours)
        events = _db.get_service_events(server_name, hours)
        endpoints = _db.get_all_endpoint_history(hours)
    except Exception as e:
        return json.dumps({"error": f"Database query failed: {e}"}, indent=2)

    # Compute trends from health snapshots
    trends = {}
    if len(health) >= 2:
        newest = health[0]
        oldest = health[-1]
        for key in ("cpu_load", "memory_used_pct", "disk_used_pct", "temperature_c"):
            old_val = oldest.get(key)
            new_val = newest.get(key)
            if old_val is not None and new_val is not None:
                diff = round(new_val - old_val, 1)
                direction = "up" if diff > 0 else "down" if diff < 0 else "stable"
                trends[key] = {"old": old_val, "new": new_val, "change": diff, "direction": direction}

    return json.dumps({
        "server": server_name,
        "period_hours": hours,
        "health_snapshots": health,
        "health_snapshot_count": len(health),
        "service_events": events,
        "service_event_count": len(events),
        "endpoint_checks": endpoints,
        "endpoint_check_count": len(endpoints),
        "trends": trends,
    }, indent=2)


# ---------------------------------------------------------------------------
# 27. get_active_alerts
# ---------------------------------------------------------------------------
@mcp.tool()
@_with_audit
def get_active_alerts(server: str = "") -> str:
    """Show all unresolved alerts from the monitoring database, grouped by severity.

    Alerts are auto-generated by monitor_server_health (disk full, high CPU, high
    temp) and monitor_endpoints (HTTP failures, SSL cert expiring).

    Pass a server name to filter alerts for that server, or leave empty to see
    alerts across all servers.

    Args:
        server: Optional server name to filter by — leave empty for all servers
    """
    try:
        server_name = None
        if server:
            info = _resolve_server(server)
            server_name = info.get("name", server.upper()) if "error" not in info else server.upper()
        alerts = _db.get_alerts(server_name=server_name, resolved=False)
    except Exception as e:
        return json.dumps({"error": f"Database query failed: {e}"}, indent=2)

    by_severity = {"critical": 0, "warning": 0, "info": 0}
    for a in alerts:
        sev = a.get("severity", "info")
        by_severity[sev] = by_severity.get(sev, 0) + 1

    return json.dumps({
        "alerts": alerts,
        "total": len(alerts),
        "by_severity": by_severity,
    }, indent=2)


# ---------------------------------------------------------------------------
# 28. resolve_alert
# ---------------------------------------------------------------------------
@mcp.tool()
@_with_audit
def resolve_alert(alert_id: int) -> str:
    """Mark a specific alert as resolved in the monitoring database.

    Use get_active_alerts first to see alert IDs, then resolve them once the
    issue has been fixed.

    Args:
        alert_id: The numeric ID of the alert to resolve (from get_active_alerts output)
    """
    err = _validate_positive_int(alert_id, "alert_id", 999999999)
    if err:
        return json.dumps({"error": err}, indent=2)

    try:
        resolved = _db.resolve_alert(alert_id)
    except Exception as e:
        return json.dumps({"error": f"Database update failed: {e}"}, indent=2)

    if resolved:
        return json.dumps({
            "alert_id": alert_id,
            "resolved": True,
            "resolved_at": datetime.now(timezone.utc).isoformat(),
        }, indent=2)
    else:
        return json.dumps({
            "alert_id": alert_id,
            "resolved": False,
            "message": "Alert not found or already resolved.",
        }, indent=2)


# ===========================================================================
# PHASE 5: ADVANCED TOOLS — Auto-discover, Database, Cron, Users, Packages,
#           Nginx, Git, Firewall, Dashboard, Timeline, Forecasting
# ===========================================================================

# ---------------------------------------------------------------------------
# 29. discover_ssh_servers
# ---------------------------------------------------------------------------
@mcp.tool()
@_with_audit
def discover_ssh_servers() -> str:
    """Auto-discover SSH servers from your ~/.ssh/config file and show them
    alongside the servers already configured in .env.

    Parses Host entries from ~/.ssh/config, extracts HostName, User, Port,
    and IdentityFile for each. Marks which ones are already in your .env
    and which are new (can be added).

    No arguments needed.
    """
    ssh_config_path = Path.home() / ".ssh" / "config"
    if not ssh_config_path.exists():
        return json.dumps({"error": "No ~/.ssh/config file found.", "path": str(ssh_config_path)}, indent=2)

    try:
        content = ssh_config_path.read_text(encoding="utf-8", errors="replace")
    except Exception as e:
        return json.dumps({"error": f"Cannot read SSH config: {e}"}, indent=2)

    # Parse SSH config
    discovered = []
    current = {}
    for line in content.splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        parts = line.split(None, 1)
        if len(parts) < 2:
            continue
        key, value = parts[0].lower(), parts[1]

        if key == "host":
            if current and current.get("host") and "*" not in current["host"]:
                discovered.append(current)
            current = {"host": value, "hostname": "", "user": "", "port": "22", "identity_file": ""}
        elif key == "hostname":
            current["hostname"] = value
        elif key == "user":
            current["user"] = value
        elif key == "port":
            current["port"] = value
        elif key == "identityfile":
            current["identity_file"] = value

    if current and current.get("host") and "*" not in current["host"]:
        discovered.append(current)

    # Check which are already in .env
    existing_hosts = {p.get("host", "").lower() for p in SERVER_PROFILES.values()}
    for entry in discovered:
        hostname = entry.get("hostname") or entry.get("host", "")
        entry["already_configured"] = hostname.lower() in existing_hosts
        entry["env_line"] = (
            f"SERVER_{entry['host'].upper().replace('-', '_').replace('.', '_')}="
            f"ssh,{hostname},{entry['port']},{entry['user'] or 'root'},key,"
            f"{entry['identity_file'] or '~/.ssh/id_rsa'},{entry['host']}"
        )

    new_count = sum(1 for d in discovered if not d["already_configured"])
    return json.dumps({
        "ssh_config_path": str(ssh_config_path),
        "discovered": discovered,
        "total": len(discovered),
        "already_configured": len(discovered) - new_count,
        "new_servers": new_count,
    }, indent=2)


# ---------------------------------------------------------------------------
# 30. query_database
# ---------------------------------------------------------------------------
@mcp.tool()
@_with_audit
def query_database(server: str, query: str, db_type: str = "auto",
                   db_name: str = "", db_user: str = "", db_password: str = "") -> str:
    """Run a SQL query or database command on a server's database.

    Supports MySQL/MariaDB, PostgreSQL, and SQLite. Auto-detects which database
    is installed if db_type is "auto".

    Returns query results as structured text. For safety, SELECT queries are
    recommended. Write queries (INSERT/UPDATE/DELETE) work but use with caution.

    Args:
        server: Server name, label, or alias
        query: SQL query or command — e.g. "SELECT * FROM users LIMIT 10",
               "SHOW DATABASES", "\\dt" (psql), "SHOW TABLES"
        db_type: "auto" (detect), "mysql", "postgresql"/"psql", or "sqlite"
        db_name: Database name to connect to (required for mysql/psql)
        db_user: Database username (defaults to 'root' for mysql, 'postgres' for psql)
        db_password: Database password (optional, uses server credential if empty)
    """
    info = _resolve_server(server)
    if "error" in info:
        return json.dumps(info, indent=2)

    if db_type == "auto":
        # Detect which DB is installed
        detect = _ssh_exec(info, [
            "which mysql 2>/dev/null && echo 'FOUND:mysql' || true; "
            "which psql 2>/dev/null && echo 'FOUND:psql' || true; "
            "which sqlite3 2>/dev/null && echo 'FOUND:sqlite3' || true"
        ], per_cmd_timeout=10)
        detect_out = detect[0].get("stdout", "") if detect else ""
        if "FOUND:mysql" in detect_out:
            db_type = "mysql"
        elif "FOUND:psql" in detect_out:
            db_type = "postgresql"
        elif "FOUND:sqlite3" in detect_out:
            db_type = "sqlite"
        else:
            return json.dumps({**_server_meta(info),
                               "error": "No database client (mysql/psql/sqlite3) found on server."}, indent=2)

    safe_query = query.replace("'", "'\\''")

    if db_type == "mysql":
        user = db_user or "root"
        pw_flag = f" -p'{db_password or info.get('credential', '')}'" if (db_password or info.get("credential")) else ""
        db_flag = f" {db_name}" if db_name else ""
        cmd = f"mysql -u {_shell_quote(user)}{pw_flag}{db_flag} -e '{safe_query}' 2>&1"
    elif db_type in ("postgresql", "psql"):
        user = db_user or "postgres"
        db_flag = f" -d {_shell_quote(db_name)}" if db_name else ""
        pw_prefix = f"PGPASSWORD='{db_password or ''}' " if db_password else ""
        cmd = f"{pw_prefix}psql -U {_shell_quote(user)}{db_flag} -c '{safe_query}' 2>&1"
    elif db_type == "sqlite":
        if not db_name:
            return json.dumps({"error": "SQLite requires db_name (path to .db file)"}, indent=2)
        cmd = f"sqlite3 {_shell_quote(db_name)} '{safe_query}' 2>&1"
    else:
        return json.dumps({"error": f"Unknown db_type: {db_type}. Use mysql, postgresql, or sqlite."}, indent=2)

    results = _ssh_exec(info, [cmd], per_cmd_timeout=30)

    return json.dumps({
        **_server_meta(info),
        "db_type": db_type,
        "db_name": db_name or "(default)",
        "query": query,
        "result": results[0] if results else {},
    }, indent=2)


# ---------------------------------------------------------------------------
# 31. manage_cron_jobs
# ---------------------------------------------------------------------------
@mcp.tool()
@_with_audit
def manage_cron_jobs(server: str, action: str = "list",
                     user: str = "", schedule: str = "", command: str = "",
                     line_number: int = 0) -> str:
    """Manage cron jobs on a server. List, add, or remove scheduled tasks.

    Actions:
    - "list" — show all cron jobs for a user (default: current SSH user)
    - "add" — add a new cron job (requires schedule + command)
    - "remove" — remove a cron job by line number (use list first to see numbers)

    Schedule format: "* * * * *" (min hour day month weekday)
    Common patterns: "0 * * * *" (hourly), "0 0 * * *" (daily midnight),
    "*/5 * * * *" (every 5 min), "0 2 * * 0" (weekly Sunday 2AM)

    Args:
        server: Server name, label, or alias
        action: "list", "add", or "remove"
        user: Cron user (empty = current SSH user, "root" for system crons)
        schedule: Cron schedule for 'add' — e.g. "0 * * * *"
        command: Command to run for 'add' — e.g. "/usr/bin/backup.sh"
        line_number: Line to remove for 'remove' (from list output)
    """
    info = _resolve_server(server)
    if "error" in info:
        return json.dumps(info, indent=2)

    user_flag = f" -u {_shell_quote(user)}" if user else ""

    if action == "list":
        cmd = f"crontab{user_flag} -l 2>&1 | cat -n; echo '---'; ls -la /etc/cron.d/ 2>/dev/null"
        results = _ssh_exec(info, [cmd], per_cmd_timeout=10)
        return json.dumps({
            **_server_meta(info), "action": "list", "user": user or "(current)",
            "crontab": results[0] if results else {},
        }, indent=2)

    elif action == "add":
        if not schedule or not command:
            return json.dumps({"error": "Both 'schedule' and 'command' required for add."}, indent=2)
        new_line = f"{schedule} {command}"
        script = f'(crontab{user_flag} -l 2>/dev/null; echo "{new_line}") | crontab{user_flag} - 2>&1 && echo "SUCCESS" || echo "FAILED"'
        results = _ssh_exec(info, [script], per_cmd_timeout=10)
        return json.dumps({
            **_server_meta(info), "action": "add", "added": new_line,
            "result": results[0] if results else {},
        }, indent=2)

    elif action == "remove":
        if line_number <= 0:
            return json.dumps({"error": "line_number required for remove (use list to see numbers)."}, indent=2)
        script = f"crontab{user_flag} -l 2>/dev/null | sed '{line_number}d' | crontab{user_flag} - 2>&1 && echo 'SUCCESS' || echo 'FAILED'"
        results = _ssh_exec(info, [script], per_cmd_timeout=10)
        return json.dumps({
            **_server_meta(info), "action": "remove", "removed_line": line_number,
            "result": results[0] if results else {},
        }, indent=2)

    return json.dumps({"error": f"Unknown action: {action}. Use list, add, or remove."}, indent=2)


# ---------------------------------------------------------------------------
# 32. manage_users
# ---------------------------------------------------------------------------
@mcp.tool()
@_with_audit
def manage_users(server: str, action: str = "list",
                 username: str = "", ssh_key: str = "") -> str:
    """Manage system users and SSH keys on a server.

    Actions:
    - "list" — list all human users (UID >= 1000) with their groups and shell
    - "info" — detailed info about a specific user
    - "add_key" — add an SSH public key to a user's authorized_keys
    - "list_keys" — show authorized SSH keys for a user
    - "who" — show who is currently logged in

    Args:
        server: Server name, label, or alias
        action: "list", "info", "add_key", "list_keys", or "who"
        username: Target username (required for info, add_key, list_keys)
        ssh_key: SSH public key string for add_key — e.g. "ssh-rsa AAAA... user@host"
    """
    info = _resolve_server(server)
    if "error" in info:
        return json.dumps(info, indent=2)

    if action == "list":
        cmd = "awk -F: '$3 >= 1000 && $3 < 65534 {print $1, $3, $6, $7}' /etc/passwd 2>&1"
        results = _ssh_exec(info, [cmd], per_cmd_timeout=10)
        return json.dumps({**_server_meta(info), "action": "list", "users": results[0] if results else {}}, indent=2)

    elif action == "info":
        if not username:
            return json.dumps({"error": "username required for info."}, indent=2)
        err = _validate_name(username, "username")
        if err:
            return json.dumps({"error": err}, indent=2)
        script = f"""
echo "===USER==="
id {_shell_quote(username)} 2>&1
echo "===GROUPS==="
groups {_shell_quote(username)} 2>&1
echo "===HOME==="
eval echo ~{_shell_quote(username)}
echo "===LAST_LOGIN==="
last -n 3 {_shell_quote(username)} 2>/dev/null
echo "===SUDO==="
sudo -l -U {_shell_quote(username)} 2>/dev/null | tail -5
"""
        result = _ssh_exec_script(info, script, timeout=15)
        sections = _parse_sections(result.get("stdout", ""))
        return json.dumps({**_server_meta(info), "action": "info", "username": username, "details": sections}, indent=2)

    elif action == "add_key":
        if not username or not ssh_key:
            return json.dumps({"error": "Both username and ssh_key required for add_key."}, indent=2)
        err = _validate_name(username, "username")
        if err:
            return json.dumps({"error": err}, indent=2)
        safe_key = ssh_key.replace("'", "'\\''")
        script = f"""
USER_HOME=$(eval echo ~{_shell_quote(username)})
mkdir -p "$USER_HOME/.ssh"
echo '{safe_key}' >> "$USER_HOME/.ssh/authorized_keys"
chmod 700 "$USER_HOME/.ssh"
chmod 600 "$USER_HOME/.ssh/authorized_keys"
chown -R {_shell_quote(username)}: "$USER_HOME/.ssh"
echo "Key added successfully"
wc -l < "$USER_HOME/.ssh/authorized_keys"
echo "total keys"
"""
        result = _ssh_exec_script(info, script, timeout=15)
        return json.dumps({**_server_meta(info), "action": "add_key", "username": username,
                           "result": result}, indent=2)

    elif action == "list_keys":
        if not username:
            return json.dumps({"error": "username required for list_keys."}, indent=2)
        err = _validate_name(username, "username")
        if err:
            return json.dumps({"error": err}, indent=2)
        cmd = f"cat $(eval echo ~{_shell_quote(username)})/.ssh/authorized_keys 2>/dev/null || echo 'No authorized_keys file'"
        results = _ssh_exec(info, [cmd], per_cmd_timeout=10)
        return json.dumps({**_server_meta(info), "action": "list_keys", "username": username,
                           "keys": results[0] if results else {}}, indent=2)

    elif action == "who":
        cmd = "who -u 2>/dev/null; echo '---'; w 2>/dev/null | head -15"
        results = _ssh_exec(info, [cmd], per_cmd_timeout=10)
        return json.dumps({**_server_meta(info), "action": "who", "logged_in": results[0] if results else {}}, indent=2)

    return json.dumps({"error": f"Unknown action: {action}. Use list, info, add_key, list_keys, or who."}, indent=2)


# ---------------------------------------------------------------------------
# 33. manage_packages
# ---------------------------------------------------------------------------
@mcp.tool()
@_with_audit
def manage_packages(server: str, action: str = "list_upgradable",
                    package: str = "") -> str:
    """Manage system packages (apt/yum/dnf) on a server.

    Actions:
    - "list_upgradable" — show packages that can be upgraded
    - "list_installed" — show all installed packages (or search if package name given)
    - "info" — show detailed info about a specific package
    - "install" — install a package (requires package name)
    - "remove" — remove a package (requires package name)
    - "update" — update package lists (apt update / yum check-update)
    - "upgrade" — upgrade all packages (apt upgrade -y)

    Args:
        server: Server name, label, or alias
        action: "list_upgradable", "list_installed", "info", "install", "remove", "update", "upgrade"
        package: Package name for info/install/remove, or search term for list_installed
    """
    info = _resolve_server(server)
    if "error" in info:
        return json.dumps(info, indent=2)

    if package:
        err = _validate_name(package, "package")
        if err:
            return json.dumps({"error": err}, indent=2)

    pkg_q = _shell_quote(package) if package else ""

    # Build command based on action — auto-detect package manager
    script = f"""
if command -v apt &>/dev/null; then
    PM=apt
elif command -v dnf &>/dev/null; then
    PM=dnf
elif command -v yum &>/dev/null; then
    PM=yum
elif command -v apk &>/dev/null; then
    PM=apk
else
    echo "ERROR: No supported package manager found"
    exit 1
fi
echo "PM=$PM"
"""
    if action == "list_upgradable":
        script += """
if [ "$PM" = "apt" ]; then apt list --upgradable 2>/dev/null | tail -n +2 | head -50
elif [ "$PM" = "dnf" ] || [ "$PM" = "yum" ]; then $PM check-update --quiet 2>/dev/null | head -50
elif [ "$PM" = "apk" ]; then apk list -u 2>/dev/null | head -50; fi
"""
    elif action == "list_installed":
        if package:
            script += f"""
if [ "$PM" = "apt" ]; then dpkg -l | grep -i {pkg_q} | head -30
elif [ "$PM" = "dnf" ] || [ "$PM" = "yum" ]; then $PM list installed 2>/dev/null | grep -i {pkg_q} | head -30
elif [ "$PM" = "apk" ]; then apk list -I 2>/dev/null | grep -i {pkg_q} | head -30; fi
"""
        else:
            script += """
if [ "$PM" = "apt" ]; then dpkg -l | tail -n +6 | wc -l; echo "packages installed"; dpkg -l | tail -n +6 | head -30
elif [ "$PM" = "dnf" ] || [ "$PM" = "yum" ]; then $PM list installed 2>/dev/null | wc -l; echo "packages"; $PM list installed 2>/dev/null | head -30
elif [ "$PM" = "apk" ]; then apk list -I 2>/dev/null | wc -l; echo "packages"; apk list -I 2>/dev/null | head -30; fi
"""
    elif action == "info":
        if not package:
            return json.dumps({"error": "package name required for info."}, indent=2)
        script += f"""
if [ "$PM" = "apt" ]; then apt show {pkg_q} 2>/dev/null
elif [ "$PM" = "dnf" ] || [ "$PM" = "yum" ]; then $PM info {pkg_q} 2>/dev/null
elif [ "$PM" = "apk" ]; then apk info {pkg_q} 2>/dev/null; fi
"""
    elif action == "install":
        if not package:
            return json.dumps({"error": "package name required for install."}, indent=2)
        script += f"""
if [ "$PM" = "apt" ]; then DEBIAN_FRONTEND=noninteractive apt install -y {pkg_q} 2>&1
elif [ "$PM" = "dnf" ]; then dnf install -y {pkg_q} 2>&1
elif [ "$PM" = "yum" ]; then yum install -y {pkg_q} 2>&1
elif [ "$PM" = "apk" ]; then apk add {pkg_q} 2>&1; fi
"""
    elif action == "remove":
        if not package:
            return json.dumps({"error": "package name required for remove."}, indent=2)
        script += f"""
if [ "$PM" = "apt" ]; then apt remove -y {pkg_q} 2>&1
elif [ "$PM" = "dnf" ]; then dnf remove -y {pkg_q} 2>&1
elif [ "$PM" = "yum" ]; then yum remove -y {pkg_q} 2>&1
elif [ "$PM" = "apk" ]; then apk del {pkg_q} 2>&1; fi
"""
    elif action == "update":
        script += """
if [ "$PM" = "apt" ]; then apt update 2>&1 | tail -5
elif [ "$PM" = "dnf" ]; then dnf check-update 2>&1 | tail -5
elif [ "$PM" = "yum" ]; then yum check-update 2>&1 | tail -5
elif [ "$PM" = "apk" ]; then apk update 2>&1; fi
"""
    elif action == "upgrade":
        script += """
if [ "$PM" = "apt" ]; then DEBIAN_FRONTEND=noninteractive apt upgrade -y 2>&1 | tail -20
elif [ "$PM" = "dnf" ]; then dnf upgrade -y 2>&1 | tail -20
elif [ "$PM" = "yum" ]; then yum update -y 2>&1 | tail -20
elif [ "$PM" = "apk" ]; then apk upgrade 2>&1; fi
"""
    else:
        return json.dumps({"error": f"Unknown action: {action}"}, indent=2)

    result = _ssh_exec_script(info, script, timeout=120)
    return json.dumps({
        **_server_meta(info), "action": action, "package": package or None,
        "result": result,
    }, indent=2)


# ---------------------------------------------------------------------------
# 34. manage_nginx
# ---------------------------------------------------------------------------
@mcp.tool()
@_with_audit
def manage_nginx(server: str, action: str = "status",
                 site: str = "") -> str:
    """Manage Nginx web server on a remote server.

    Actions:
    - "status" — show Nginx running status and config test result
    - "list_sites" — list all enabled and available sites
    - "show_config" — show main nginx.conf or a specific site config
    - "test" — test Nginx config for syntax errors
    - "reload" — reload Nginx config without downtime
    - "restart" — full restart of Nginx
    - "access_log" — last 30 lines of access log
    - "error_log" — last 30 lines of error log

    Args:
        server: Server name, label, or alias
        action: "status", "list_sites", "show_config", "test", "reload",
                "restart", "access_log", "error_log"
        site: Site config name for show_config — e.g. "default", "myapp.conf"
    """
    info = _resolve_server(server)
    if "error" in info:
        return json.dumps(info, indent=2)

    if action == "status":
        script = """
echo "===SERVICE==="
systemctl is-active nginx 2>&1
echo "===CONFIG_TEST==="
nginx -t 2>&1
echo "===VERSION==="
nginx -v 2>&1
echo "===WORKERS==="
ps aux | grep "[n]ginx" | wc -l
echo "nginx processes"
"""
    elif action == "list_sites":
        script = """
echo "===ENABLED==="
ls -la /etc/nginx/sites-enabled/ 2>/dev/null || ls -la /etc/nginx/conf.d/ 2>/dev/null || echo "No sites directory found"
echo "===AVAILABLE==="
ls -la /etc/nginx/sites-available/ 2>/dev/null || echo "No sites-available directory"
"""
    elif action == "show_config":
        if site:
            err = _validate_name(site, "site")
            if err:
                return json.dumps({"error": err}, indent=2)
            script = f"""
cat /etc/nginx/sites-enabled/{_shell_quote(site)} 2>/dev/null || \
cat /etc/nginx/sites-available/{_shell_quote(site)} 2>/dev/null || \
cat /etc/nginx/conf.d/{_shell_quote(site)} 2>/dev/null || \
echo "Site config not found: {site}"
"""
        else:
            script = "cat /etc/nginx/nginx.conf 2>&1"
    elif action == "test":
        script = "nginx -t 2>&1"
    elif action == "reload":
        script = "nginx -t 2>&1 && systemctl reload nginx 2>&1 && echo 'Reload OK' || echo 'Reload FAILED'"
    elif action == "restart":
        script = "systemctl restart nginx 2>&1 && systemctl is-active nginx 2>&1"
    elif action == "access_log":
        script = "tail -n 30 /var/log/nginx/access.log 2>/dev/null || echo 'No access log found'"
    elif action == "error_log":
        script = "tail -n 30 /var/log/nginx/error.log 2>/dev/null || echo 'No error log found'"
    else:
        return json.dumps({"error": f"Unknown action: {action}"}, indent=2)

    result = _ssh_exec_script(info, script, timeout=15)
    sections = _parse_sections(result.get("stdout", "")) if "===" in result.get("stdout", "") else {}

    return json.dumps({
        **_server_meta(info), "action": action, "site": site or None,
        "result": sections if sections else result,
    }, indent=2)


# ---------------------------------------------------------------------------
# 35. git_deploy
# ---------------------------------------------------------------------------
@mcp.tool()
@_with_audit
def git_deploy(server: str, repo_path: str, action: str = "status",
               branch: str = "", remote: str = "origin") -> str:
    """Manage git repositories on a server for deployment.

    Actions:
    - "status" — show current branch, status, last commit, remote URL
    - "pull" — pull latest changes from remote (git pull)
    - "log" — show last 10 commits
    - "branch" — list branches, show current
    - "switch" — switch to a different branch (requires branch name)
    - "stash" — stash local changes before pulling
    - "diff" — show uncommitted changes

    Args:
        server: Server name, label, or alias
        repo_path: Absolute path to the git repo on the server — e.g. "/var/www/myapp", "/home/deploy/api"
        action: "status", "pull", "log", "branch", "switch", "stash", "diff"
        branch: Branch name for 'switch' action
        remote: Git remote name (default: "origin")
    """
    err = _validate_name(repo_path, "repo_path")
    if err:
        return json.dumps({"error": err}, indent=2)

    info = _resolve_server(server)
    if "error" in info:
        return json.dumps(info, indent=2)

    rp = _shell_quote(repo_path)
    remote_q = _shell_quote(remote)

    if action == "status":
        script = f"""cd {rp} 2>/dev/null || {{ echo "ERROR: {repo_path} not found"; exit 1; }}
echo "===BRANCH==="
git branch --show-current
echo "===STATUS==="
git status --short
echo "===LAST_COMMIT==="
git log -1 --oneline --format="%h %s (%cr by %an)"
echo "===REMOTE==="
git remote -v
echo "===BEHIND==="
git fetch {remote_q} --dry-run 2>&1 | head -5
"""
    elif action == "pull":
        script = f"cd {rp} && git pull {remote_q} 2>&1"
    elif action == "log":
        script = f"cd {rp} && git log --oneline -10 --format='%h %s (%cr by %an)' 2>&1"
    elif action == "branch":
        script = f"cd {rp} && git branch -a 2>&1"
    elif action == "switch":
        if not branch:
            return json.dumps({"error": "branch name required for switch."}, indent=2)
        err = _validate_name(branch, "branch")
        if err:
            return json.dumps({"error": err}, indent=2)
        script = f"cd {rp} && git checkout {_shell_quote(branch)} 2>&1 && git branch --show-current"
    elif action == "stash":
        script = f"cd {rp} && git stash 2>&1 && echo 'Stash OK'"
    elif action == "diff":
        script = f"cd {rp} && git diff --stat 2>&1; echo '---'; git diff 2>&1 | head -100"
    else:
        return json.dumps({"error": f"Unknown action: {action}"}, indent=2)

    result = _ssh_exec_script(info, script, timeout=60)
    sections = _parse_sections(result.get("stdout", "")) if "===" in result.get("stdout", "") else {}

    return json.dumps({
        **_server_meta(info), "repo_path": repo_path, "action": action,
        "branch": branch or None,
        "result": sections if sections else result,
    }, indent=2)


# ---------------------------------------------------------------------------
# 36. manage_firewall
# ---------------------------------------------------------------------------
@mcp.tool()
@_with_audit
def manage_firewall(server: str, action: str = "status",
                    rule: str = "") -> str:
    """Manage firewall rules (UFW or iptables) on a server.

    Actions:
    - "status" — show firewall status and all rules
    - "allow" — allow a port/service (requires rule) — e.g. "80", "443/tcp", "ssh", "from 10.0.0.0/8"
    - "deny" — deny a port/service (requires rule)
    - "delete" — delete a rule (requires rule — use exact rule from status output)
    - "enable" — enable the firewall
    - "disable" — disable the firewall
    - "reset" — reset all rules to default (DANGEROUS)

    Args:
        server: Server name, label, or alias
        action: "status", "allow", "deny", "delete", "enable", "disable", "reset"
        rule: Firewall rule for allow/deny/delete — e.g. "80", "443/tcp", "22/tcp",
              "from 10.0.0.0/8 to any port 22"
    """
    info = _resolve_server(server)
    if "error" in info:
        return json.dumps(info, indent=2)

    if action == "status":
        script = """
if command -v ufw &>/dev/null; then
    echo "===FIREWALL_TYPE==="
    echo "ufw"
    echo "===STATUS==="
    ufw status verbose 2>&1
    echo "===RULES==="
    ufw status numbered 2>&1
elif command -v firewall-cmd &>/dev/null; then
    echo "===FIREWALL_TYPE==="
    echo "firewalld"
    echo "===STATUS==="
    firewall-cmd --state 2>&1
    echo "===RULES==="
    firewall-cmd --list-all 2>&1
else
    echo "===FIREWALL_TYPE==="
    echo "iptables"
    echo "===RULES==="
    iptables -L -n --line-numbers 2>&1
fi
"""
    elif action in ("allow", "deny"):
        if not rule:
            return json.dumps({"error": f"rule required for {action}."}, indent=2)
        safe_rule = rule  # UFW handles its own parsing
        script = f"""
if command -v ufw &>/dev/null; then
    ufw {action} {safe_rule} 2>&1
    echo "---"
    ufw status numbered 2>&1
else
    echo "Only UFW is supported for add/remove. Use iptables commands directly via run_shell_commands."
fi
"""
    elif action == "delete":
        if not rule:
            return json.dumps({"error": "rule required for delete."}, indent=2)
        script = f"""
if command -v ufw &>/dev/null; then
    ufw delete {rule} 2>&1
    echo "---"
    ufw status numbered 2>&1
else
    echo "Only UFW is supported. Use iptables commands directly."
fi
"""
    elif action == "enable":
        script = "ufw --force enable 2>&1 && ufw status 2>&1"
    elif action == "disable":
        script = "ufw disable 2>&1"
    elif action == "reset":
        script = "ufw --force reset 2>&1 && echo 'Firewall reset to defaults'"
    else:
        return json.dumps({"error": f"Unknown action: {action}"}, indent=2)

    result = _ssh_exec_script(info, script, timeout=15)
    sections = _parse_sections(result.get("stdout", "")) if "===" in result.get("stdout", "") else {}

    return json.dumps({
        **_server_meta(info), "action": action, "rule": rule or None,
        "result": sections if sections else result,
    }, indent=2)


# ---------------------------------------------------------------------------
# 37. multi_server_dashboard
# ---------------------------------------------------------------------------
@mcp.tool()
@_with_audit
def multi_server_dashboard() -> str:
    """Generate a comprehensive status summary of ALL configured servers in one call.

    For each server: checks reachability, collects quick health metrics (load, memory,
    disk), counts failed services, and reports overall status.

    Returns a summary table ideal for answering "how are all my servers doing?"

    No arguments needed.
    """
    if not SERVER_PROFILES:
        return json.dumps({"error": "No servers configured."}, indent=2)

    dashboard = []
    quick_script = r"""
echo "$(cat /proc/loadavg | awk '{print $1}')"
echo "$(free | awk '/Mem:/ {printf "%.0f", $3/$2*100}')"
echo "$(df / | tail -1 | awk '{print $5}' | tr -d '%')"
echo "$(systemctl --failed --no-pager --no-legend 2>/dev/null | grep -c '.')"
echo "$(uptime -s 2>/dev/null || echo 'unknown')"
"""

    for name, profile in sorted(SERVER_PROFILES.items()):
        entry = {
            "server": name, "label": profile["label"],
            "type": profile.get("type", "ssh"), "host": profile.get("host", ""),
        }
        info = {**profile, "name": name}
        reachable, latency = _check_reachable(info)
        entry["status"] = "online" if reachable else "offline"
        entry["latency_ms"] = latency

        if reachable:
            try:
                result = _ssh_exec_script(info, quick_script, timeout=10)
                lines = result.get("stdout", "").strip().splitlines()
                if len(lines) >= 4:
                    try:
                        entry["cpu_load"] = float(lines[0])
                    except ValueError:
                        entry["cpu_load"] = None
                    try:
                        entry["memory_pct"] = int(lines[1])
                    except ValueError:
                        entry["memory_pct"] = None
                    try:
                        entry["disk_pct"] = int(lines[2])
                    except ValueError:
                        entry["disk_pct"] = None
                    try:
                        entry["failed_services"] = int(lines[3])
                    except ValueError:
                        entry["failed_services"] = 0
                    entry["up_since"] = lines[4] if len(lines) > 4 else "unknown"
                    # Determine health
                    if entry.get("disk_pct", 0) > 90 or entry.get("failed_services", 0) > 3:
                        entry["health"] = "critical"
                    elif entry.get("disk_pct", 0) > 80 or entry.get("failed_services", 0) > 0:
                        entry["health"] = "warning"
                    else:
                        entry["health"] = "healthy"
            except Exception:
                entry["health"] = "error"
        else:
            entry["health"] = "offline"

        dashboard.append(entry)

    healthy = sum(1 for d in dashboard if d.get("health") == "healthy")
    warning = sum(1 for d in dashboard if d.get("health") == "warning")
    critical = sum(1 for d in dashboard if d.get("health") in ("critical", "offline", "error"))

    return json.dumps({
        "dashboard": dashboard,
        "total_servers": len(dashboard),
        "healthy": healthy,
        "warning": warning,
        "critical": critical,
        "timestamp": datetime.now(timezone.utc).isoformat(),
    }, indent=2)


# ---------------------------------------------------------------------------
# 38. get_incident_timeline
# ---------------------------------------------------------------------------
@mcp.tool()
@_with_audit
def get_incident_timeline(server: str = "", hours: int = 6) -> str:
    """Show a chronological timeline of everything that happened on a server:
    health snapshots, service events, alerts — all merged and sorted by time.

    This answers: "what happened on PROD in the last 6 hours?"

    Pass empty server to see events across ALL servers.

    Args:
        server: Server name (empty for all servers)
        hours: How far back to look (default: 6 hours)
    """
    err = _validate_positive_int(hours, "hours", 8760)
    if err:
        return json.dumps({"error": err}, indent=2)

    server_name = None
    if server:
        info = _resolve_server(server)
        server_name = info.get("name", server.upper()) if "error" not in info else server.upper()

    try:
        health = _db.get_health_history(server_name, hours) if server_name else []
        events = _db.get_service_events(server_name, hours)
        alerts = _db.get_alerts(server_name, resolved=False) + _db.get_alerts(server_name, resolved=True)
    except Exception as e:
        return json.dumps({"error": f"DB query failed: {e}"}, indent=2)

    # Build unified timeline
    timeline = []
    for h in health:
        timeline.append({
            "timestamp": h.get("timestamp", ""),
            "type": "health_check",
            "server": h.get("server_name", ""),
            "summary": f"CPU={h.get('cpu_load')}, Mem={h.get('memory_used_pct')}%, Disk={h.get('disk_used_pct')}%",
        })
    for e in events:
        timeline.append({
            "timestamp": e.get("timestamp", ""),
            "type": "service_event",
            "server": e.get("server_name", ""),
            "summary": f"{e.get('service_name')}: {e.get('old_status')} → {e.get('new_status')} ({e.get('action')})",
        })
    for a in alerts:
        timeline.append({
            "timestamp": a.get("timestamp", ""),
            "type": "alert",
            "server": a.get("server_name", ""),
            "severity": a.get("severity", ""),
            "summary": a.get("message", ""),
            "resolved": bool(a.get("resolved")),
        })

    # Sort by timestamp descending
    timeline.sort(key=lambda x: x.get("timestamp", ""), reverse=True)

    return json.dumps({
        "server": server_name or "ALL",
        "period_hours": hours,
        "events": timeline[:100],
        "total_events": len(timeline),
    }, indent=2)


# ---------------------------------------------------------------------------
# 39. forecast_disk_usage
# ---------------------------------------------------------------------------
@mcp.tool()
@_with_audit
def forecast_disk_usage(server: str) -> str:
    """Predict when disk will be full based on historical growth rate.

    Uses health snapshots stored in the database to calculate the rate of disk
    usage increase, then projects when it will hit 90% and 100%.

    Requires at least 2 health snapshots taken at different times (use
    monitor_server_health periodically to build up data).

    Args:
        server: Server name, label, or alias
    """
    info = _resolve_server(server)
    server_name = info.get("name", server.upper()) if "error" not in info else server.upper()

    try:
        history = _db.get_health_history(server_name, hours=168)  # last 7 days
    except Exception as e:
        return json.dumps({"error": f"DB query failed: {e}"}, indent=2)

    if len(history) < 2:
        return json.dumps({
            "server": server_name,
            "error": f"Need at least 2 health snapshots for forecasting. Found {len(history)}. "
                     "Run monitor_server_health periodically to build data.",
        }, indent=2)

    # Get disk usage over time
    points = []
    for h in reversed(history):  # oldest first
        disk = h.get("disk_used_pct")
        ts = h.get("timestamp")
        if disk is not None and ts:
            try:
                dt = datetime.fromisoformat(ts)
                points.append((dt, disk))
            except ValueError:
                pass

    if len(points) < 2:
        return json.dumps({"server": server_name, "error": "Not enough disk data points."}, indent=2)

    # Calculate growth rate (linear regression)
    first_time, first_disk = points[0]
    last_time, last_disk = points[-1]
    hours_elapsed = (last_time - first_time).total_seconds() / 3600

    if hours_elapsed < 0.1:
        return json.dumps({"server": server_name, "error": "Snapshots too close together. Wait and collect more data."}, indent=2)

    growth_per_hour = (last_disk - first_disk) / hours_elapsed
    growth_per_day = growth_per_hour * 24

    result = {
        "server": server_name,
        "current_disk_pct": last_disk,
        "oldest_snapshot_disk_pct": first_disk,
        "measurement_period_hours": round(hours_elapsed, 1),
        "data_points": len(points),
        "growth_per_day_pct": round(growth_per_day, 2),
    }

    if growth_per_day <= 0:
        result["forecast"] = "Disk usage is stable or decreasing. No concern."
        result["days_until_90pct"] = None
        result["days_until_100pct"] = None
    else:
        if last_disk < 90:
            days_to_90 = (90 - last_disk) / growth_per_day
            result["days_until_90pct"] = round(days_to_90, 1)
        else:
            result["days_until_90pct"] = 0
        days_to_100 = (100 - last_disk) / growth_per_day
        result["days_until_100pct"] = round(days_to_100, 1)

        if result.get("days_until_100pct", 999) < 7:
            result["forecast"] = f"CRITICAL: Disk will be full in ~{result['days_until_100pct']} days!"
        elif result.get("days_until_90pct", 999) < 14:
            result["forecast"] = f"WARNING: Disk will reach 90% in ~{result['days_until_90pct']} days."
        else:
            result["forecast"] = f"OK: At current growth ({growth_per_day:.2f}%/day), disk is fine for now."

    return json.dumps(result, indent=2)


# ---------------------------------------------------------------------------
# 40. generate_html_dashboard
# ---------------------------------------------------------------------------
@mcp.tool()
@_with_audit
def generate_html_dashboard(output_path: str = "") -> str:
    """Generate a self-contained HTML status dashboard for all servers.

    Creates a single HTML file with:
    - Server status cards (green/yellow/red)
    - CPU, memory, disk metrics per server
    - Failed service count
    - Recent alerts
    - Last check timestamp
    - Auto-refresh meta tag (refreshes every 60 seconds if served)

    The HTML file is fully self-contained (inline CSS, no external dependencies)
    and can be opened in any browser or served via nginx/python http.server.

    Args:
        output_path: Where to save the HTML file. Defaults to ~/.server-guardian-mcp/dashboard.html
    """
    if not output_path:
        output_path = str(Path.home() / ".server-guardian-mcp" / "dashboard.html")

    # Collect data from all servers
    dashboard_json = json.loads(multi_server_dashboard())
    servers = dashboard_json.get("dashboard", [])

    # Get recent alerts
    try:
        alerts = _db.get_alerts(resolved=False)
    except Exception:
        alerts = []

    timestamp = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")

    # Build server cards HTML
    cards = ""
    for s in servers:
        health = s.get("health", "offline")
        color = {"healthy": "#28a745", "warning": "#fd7e14", "critical": "#dc3545",
                 "offline": "#6c757d", "error": "#dc3545"}.get(health, "#6c757d")
        bg = {"healthy": "#d4edda", "warning": "#fff3cd", "critical": "#f8d7da",
              "offline": "#e2e3e5", "error": "#f8d7da"}.get(health, "#e2e3e5")

        metrics_html = ""
        if s.get("status") == "online":
            cpu = s.get("cpu_load", "—")
            mem = s.get("memory_pct", "—")
            disk = s.get("disk_pct", "—")
            failed = s.get("failed_services", 0)
            disk_color = "#dc3545" if isinstance(disk, (int, float)) and disk > 80 else "#212529"
            metrics_html = f"""
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 8px; margin-top: 12px;">
              <div><span style="color: #6c757d; font-size: 11px;">CPU Load</span><br><strong>{cpu}</strong></div>
              <div><span style="color: #6c757d; font-size: 11px;">Memory</span><br><strong>{mem}%</strong></div>
              <div><span style="color: #6c757d; font-size: 11px;">Disk</span><br><strong style="color: {disk_color};">{disk}%</strong></div>
              <div><span style="color: #6c757d; font-size: 11px;">Failed Svcs</span><br><strong style="color: {'#dc3545' if failed else '#28a745'};">{failed}</strong></div>
            </div>
            <div style="margin-top: 8px; font-size: 11px; color: #6c757d;">Up since: {s.get('up_since', '—')}</div>"""
        else:
            metrics_html = '<div style="margin-top: 12px; color: #6c757d;">Server is unreachable</div>'

        cards += f"""
    <div style="background: {bg}; border-left: 4px solid {color}; border-radius: 8px; padding: 16px; box-shadow: 0 1px 3px rgba(0,0,0,0.1);">
      <div style="display: flex; justify-content: space-between; align-items: center;">
        <div>
          <h3 style="margin: 0; font-size: 16px;">{s['server']}</h3>
          <span style="color: #6c757d; font-size: 12px;">{s.get('label', '')} &bull; {s.get('type', 'ssh')} &bull; {s.get('host', '')}</span>
        </div>
        <span style="background: {color}; color: white; padding: 4px 12px; border-radius: 12px; font-size: 12px; font-weight: bold;">{health.upper()}</span>
      </div>
      {metrics_html}
    </div>"""

    # Build alerts HTML
    alerts_html = ""
    if alerts:
        for a in alerts[:10]:
            sev_color = {"critical": "#dc3545", "warning": "#fd7e14", "info": "#0d6efd"}.get(a.get("severity", ""), "#6c757d")
            alerts_html += f"""
    <div style="padding: 8px 12px; border-left: 3px solid {sev_color}; background: white; margin-bottom: 8px; border-radius: 4px; font-size: 13px;">
      <strong style="color: {sev_color};">{a.get('severity', '').upper()}</strong> &mdash; {a.get('server_name', '')}
      <br><span style="color: #495057;">{a.get('message', '')[:120]}</span>
      <br><span style="color: #adb5bd; font-size: 11px;">{a.get('timestamp', '')[:19]}</span>
    </div>"""
    else:
        alerts_html = '<div style="color: #28a745; padding: 12px;">No active alerts</div>'

    # Summary bar
    total = dashboard_json.get("total_servers", 0)
    healthy = dashboard_json.get("healthy", 0)
    warning = dashboard_json.get("warning", 0)
    critical = dashboard_json.get("critical", 0)

    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta http-equiv="refresh" content="60">
  <title>Server Guardian Dashboard</title>
</head>
<body style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background: #f5f5f5; margin: 0; padding: 20px;">
  <div style="max-width: 1000px; margin: 0 auto;">
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px;">
      <h1 style="margin: 0; font-size: 24px;">Server Guardian Dashboard</h1>
      <span style="color: #6c757d; font-size: 12px;">Last updated: {timestamp}</span>
    </div>

    <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 12px; margin-bottom: 24px;">
      <div style="background: white; border-radius: 8px; padding: 16px; text-align: center; box-shadow: 0 1px 3px rgba(0,0,0,0.1);">
        <div style="font-size: 28px; font-weight: bold;">{total}</div>
        <div style="color: #6c757d; font-size: 12px;">Total Servers</div>
      </div>
      <div style="background: #d4edda; border-radius: 8px; padding: 16px; text-align: center;">
        <div style="font-size: 28px; font-weight: bold; color: #28a745;">{healthy}</div>
        <div style="color: #6c757d; font-size: 12px;">Healthy</div>
      </div>
      <div style="background: #fff3cd; border-radius: 8px; padding: 16px; text-align: center;">
        <div style="font-size: 28px; font-weight: bold; color: #fd7e14;">{warning}</div>
        <div style="color: #6c757d; font-size: 12px;">Warning</div>
      </div>
      <div style="background: #f8d7da; border-radius: 8px; padding: 16px; text-align: center;">
        <div style="font-size: 28px; font-weight: bold; color: #dc3545;">{critical}</div>
        <div style="color: #6c757d; font-size: 12px;">Critical</div>
      </div>
    </div>

    <h2 style="font-size: 18px; margin-bottom: 12px;">Servers</h2>
    <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 16px; margin-bottom: 24px;">
      {cards}
    </div>

    <h2 style="font-size: 18px; margin-bottom: 12px;">Active Alerts ({len(alerts)})</h2>
    <div style="margin-bottom: 24px;">
      {alerts_html}
    </div>

    <div style="text-align: center; color: #adb5bd; font-size: 11px; padding: 16px;">
      Server Guardian MCP &mdash; Auto-refreshes every 60 seconds
    </div>
  </div>
</body>
</html>"""

    # Write file
    try:
        Path(output_path).parent.mkdir(parents=True, exist_ok=True)
        Path(output_path).write_text(html, encoding="utf-8")
    except Exception as e:
        return json.dumps({"error": f"Failed to write dashboard: {e}"}, indent=2)

    return json.dumps({
        "dashboard_path": output_path,
        "servers": len(servers),
        "alerts": len(alerts),
        "status": {"healthy": healthy, "warning": warning, "critical": critical},
        "message": f"Dashboard generated. Open in browser: file:///{output_path.replace(chr(92), '/')}",
    }, indent=2)


# ===========================================================================
# PHASE 7: ENHANCED FEATURES (new tools)
# ===========================================================================

from .anomaly import detect_anomalies, rebuild_baselines, get_server_baselines_summary
from .playbooks import get_all_playbooks, evaluate_and_run, save_custom_playbook
from .auth import (
    is_team_mode_enabled, check_permission, create_team_user,
    list_team_users, update_team_user_role, delete_team_user, get_role_info,
)
from .integrations import dispatch_alert, get_configured_integrations
from .compliance import generate_compliance_report


# ---------------------------------------------------------------------------
# 41. replay_incident
# ---------------------------------------------------------------------------
@mcp.tool()
@_with_audit
def replay_incident(server: str = "", hours: int = 24) -> str:
    """Generate a chronological incident narrative from stored data.

    Weaves together health snapshots, service events, alerts, and playbook runs
    into a human-readable timeline that tells the story of what happened.

    Args:
        server: Server name (optional — all servers if empty)
        hours: How far back to look (default: 24 hours)
    """
    events = []

    # Gather alerts
    alerts = _db.get_alerts(server_name=server if server else None, resolved=False)
    resolved = _db.get_alerts(server_name=server if server else None, resolved=True)
    for a in alerts + resolved:
        events.append({
            "time": a["timestamp"],
            "type": "alert",
            "severity": a["severity"],
            "text": f"[{a['severity'].upper()}] {a['server_name']}: {a['message']}",
            "resolved": bool(a.get("resolved")),
        })

    # Gather service events
    svc_events = _db.get_service_events(server_name=server if server else None, hours=hours)
    for e in svc_events:
        events.append({
            "time": e["timestamp"],
            "type": "service",
            "text": f"{e['server_name']}: {e['service_name']} changed {e['old_status']} -> {e['new_status']} ({e['action']})",
        })

    # Gather playbook runs
    pb_runs = _db.get_playbook_runs(server_name=server if server else None, hours=hours)
    for r in pb_runs:
        status = "succeeded" if r.get("success") else "FAILED"
        events.append({
            "time": r["timestamp"],
            "type": "playbook",
            "text": f"{r['server_name']}: playbook '{r['playbook_name']}' {status} (trigger: {r['trigger_condition'][:80]})",
        })

    # Gather health transitions (significant changes)
    if server:
        snapshots = _db.get_health_history(server, hours=hours)
        prev = None
        for snap in reversed(snapshots):
            if prev:
                for metric in ("cpu_load", "memory_used_pct", "disk_used_pct"):
                    old_val = prev.get(metric)
                    new_val = snap.get(metric)
                    if old_val is not None and new_val is not None:
                        diff = abs(new_val - old_val)
                        if diff > 15:  # Only significant changes
                            direction = "rose" if new_val > old_val else "dropped"
                            events.append({
                                "time": snap["timestamp"],
                                "type": "health",
                                "text": f"{server}: {metric} {direction} from {old_val:.1f} to {new_val:.1f} ({'+' if new_val > old_val else ''}{new_val - old_val:.1f})",
                            })
            prev = snap

    # Sort chronologically
    events.sort(key=lambda e: e["time"])

    if not events:
        return json.dumps({
            "server": server or "all",
            "hours": hours,
            "narrative": "No incidents found in this period. All quiet.",
            "events": 0,
        }, indent=2)

    # Build narrative
    lines = [f"Incident timeline for {server or 'all servers'} (last {hours}h):", ""]
    for e in events:
        ts = e["time"][:19] if len(e["time"]) >= 19 else e["time"]
        prefix = {"alert": "ALERT", "service": "SVC", "playbook": "AUTO", "health": "METRIC"}.get(e["type"], "EVENT")
        resolved_tag = " [RESOLVED]" if e.get("resolved") else ""
        lines.append(f"  [{ts}] {prefix}: {e['text']}{resolved_tag}")

    lines.append(f"\nTotal events: {len(events)}")

    return json.dumps({
        "server": server or "all",
        "hours": hours,
        "narrative": "\n".join(lines),
        "event_count": len(events),
        "breakdown": {
            "alerts": sum(1 for e in events if e["type"] == "alert"),
            "service_events": sum(1 for e in events if e["type"] == "service"),
            "playbook_runs": sum(1 for e in events if e["type"] == "playbook"),
            "health_changes": sum(1 for e in events if e["type"] == "health"),
        },
    }, indent=2)


# ---------------------------------------------------------------------------
# 42. detect_anomalies_tool
# ---------------------------------------------------------------------------
@mcp.tool()
@_with_audit
def detect_anomalies_tool(server: str) -> str:
    """Detect anomalous metrics on a server by comparing current values to historical baselines.

    Uses rolling averages + standard deviation to identify unusual CPU, memory, disk,
    or temperature patterns. First run builds baselines; subsequent runs detect anomalies.

    Args:
        server: Server name to check
    """
    info = _resolve_server(server)
    if "error" in info:
        return json.dumps(info, indent=2)

    server_name = info["name"]

    # First, rebuild baselines from recent data
    baseline_result = rebuild_baselines(server_name, hours=168)

    # Get current health
    try:
        result = _ssh_exec_script(info, _HEALTH_SCRIPT, timeout=30)
        sections = _parse_sections(result.get("stdout", ""))
        metrics = _db._parse_health_metrics(sections)
    except Exception as e:
        return json.dumps({"error": f"Failed to get current health: {e}"}, indent=2)

    # Detect anomalies
    anomalies = detect_anomalies(server_name, metrics)

    # Store health and generate alerts for anomalies
    _db.record_health(server_name, sections)
    for a in anomalies:
        _db.record_alert(server_name, a["severity"], f"anomaly_{a['metric']}", a["message"])

    return json.dumps({
        "server": server_name,
        "current_metrics": {k: round(v, 2) if v else None for k, v in metrics.items()},
        "baselines": baseline_result,
        "anomalies": anomalies,
        "anomaly_count": len(anomalies),
        "status": "anomalies detected" if anomalies else "all normal",
    }, indent=2)


# ---------------------------------------------------------------------------
# 43. manage_playbooks
# ---------------------------------------------------------------------------
@mcp.tool()
@_with_audit
def manage_playbooks(action: str = "list", playbook_name: str = "",
                     server: str = "") -> str:
    """Manage auto-remediation playbooks.

    Playbooks define conditions (disk > 90%, service failed, etc.) and automatic
    actions (clear logs, restart service, renew SSL, etc.) that execute when triggered.

    Args:
        action: list | run | history | create_example
        playbook_name: Name of specific playbook (for run action)
        server: Server to run playbook on (for run action)
    """
    if action == "list":
        playbooks = get_all_playbooks()
        return json.dumps({
            "playbooks": [
                {
                    "name": p["name"],
                    "description": p.get("description", ""),
                    "trigger": p.get("trigger", {}),
                    "actions_count": len(p.get("actions", [])),
                    "cooldown_minutes": p.get("cooldown_minutes", 30),
                }
                for p in playbooks
            ],
            "total": len(playbooks),
        }, indent=2)

    elif action == "history":
        runs = _db.get_playbook_runs(
            server_name=server if server else None,
            hours=168,
        )
        return json.dumps({"runs": runs, "total": len(runs)}, indent=2)

    elif action == "run":
        if not server:
            return json.dumps({"error": "server is required for run action"})
        info = _resolve_server(server)
        if "error" in info:
            return json.dumps(info, indent=2)

        # Get current metrics
        try:
            result = _ssh_exec_script(info, _HEALTH_SCRIPT, timeout=30)
            sections = _parse_sections(result.get("stdout", ""))
            metrics = _db._parse_health_metrics(sections)
        except Exception as e:
            return json.dumps({"error": f"Failed to get metrics: {e}"}, indent=2)

        # Get failed services
        try:
            cmd = "systemctl --failed --no-pager --no-legend 2>&1"
            ssh_results = _ssh_exec(info, [cmd], per_cmd_timeout=15)
            raw = ssh_results[0].get("stdout", "") if ssh_results else ""
            failed_svcs = []
            for line in raw.splitlines():
                line = line.strip()
                if not line or "0 loaded" in line.lower():
                    continue
                if line and line[0] in ("\u25cf", "*"):
                    line = line[1:].strip()
                parts = line.split(None, 1)
                if parts:
                    failed_svcs.append(parts[0])
        except Exception:
            failed_svcs = []

        results = evaluate_and_run(info, metrics, failed_services=failed_svcs)
        return json.dumps({
            "server": info["name"],
            "playbooks_triggered": len(results),
            "results": results,
        }, indent=2)

    elif action == "create_example":
        example = {
            "name": "custom_cleanup",
            "description": "Example custom playbook — clean temp files when disk > 85%",
            "trigger": {"metric": "disk_used_pct", "operator": ">", "value": 85},
            "actions": [
                {"type": "command", "run": "find /tmp -type f -mtime +3 -delete 2>&1 || true"},
                {"type": "command", "run": "df -h / | tail -1"},
            ],
            "cooldown_minutes": 60,
        }
        path = save_custom_playbook(example)
        return json.dumps({
            "created": path,
            "playbook": example,
            "note": "Edit this file to customize. Place .json files in ~/.server-guardian-mcp/playbooks/",
        }, indent=2)

    return json.dumps({"error": f"Unknown action '{action}'. Use: list, run, history, create_example"})


# ---------------------------------------------------------------------------
# 44. team_manage
# ---------------------------------------------------------------------------
@mcp.tool()
@_with_audit
def team_manage(action: str = "status", username: str = "",
                role: str = "viewer") -> str:
    """Manage team users and RBAC (multi-tenant mode).

    Enable with GUARDIAN_TEAM_MODE=true. Supports roles: admin, operator, viewer.
    Each user gets an API key for authentication.

    Args:
        action: status | list_users | create_user | update_role | delete_user | roles
        username: Username (for create/update/delete)
        role: Role to assign (admin, operator, viewer)
    """
    if action == "status":
        return json.dumps({
            "team_mode": is_team_mode_enabled(),
            "roles": get_role_info(),
            "note": "Set GUARDIAN_TEAM_MODE=true and GUARDIAN_API_KEY=<key> to enable.",
        }, indent=2)

    elif action == "roles":
        return json.dumps({"roles": get_role_info()}, indent=2)

    elif action == "list_users":
        users = list_team_users()
        return json.dumps({"users": users, "total": len(users)}, indent=2)

    elif action == "create_user":
        if not username:
            return json.dumps({"error": "username is required"})
        result = create_team_user(username, role)
        return json.dumps(result, indent=2)

    elif action == "update_role":
        if not username:
            return json.dumps({"error": "username is required"})
        result = update_team_user_role(username, role)
        return json.dumps(result, indent=2)

    elif action == "delete_user":
        if not username:
            return json.dumps({"error": "username is required"})
        result = delete_team_user(username)
        return json.dumps(result, indent=2)

    return json.dumps({"error": f"Unknown action '{action}'. Use: status, list_users, create_user, update_role, delete_user, roles"})


# ---------------------------------------------------------------------------
# 45. check_integrations
# ---------------------------------------------------------------------------
@mcp.tool()
@_with_audit
def check_integrations(action: str = "status",
                       test_message: str = "") -> str:
    """Check and test external alert integrations.

    Supports PagerDuty, Telegram, OpsGenie. Shows configuration status
    and can send test alerts to verify connectivity.

    Args:
        action: status | test
        test_message: Message to send when testing (default: "Test alert from Server Guardian")
    """
    if action == "status":
        integrations = get_configured_integrations()
        return json.dumps({"integrations": integrations}, indent=2)

    elif action == "test":
        msg = test_message or "Test alert from Server Guardian MCP"
        result = dispatch_alert(
            subject="Test Alert",
            body=msg,
            severity="info",
            details={"test": True, "source": "manual_test"},
        )
        return json.dumps(result, indent=2)

    return json.dumps({"error": f"Unknown action '{action}'. Use: status, test"})


# ---------------------------------------------------------------------------
# 46. generate_compliance_report_tool
# ---------------------------------------------------------------------------
@mcp.tool()
@_with_audit
def generate_compliance_report_tool(server: str,
                                    company_name: str = "",
                                    output_path: str = "") -> str:
    """Generate an HTML security compliance report for a server.

    Runs a full security audit and produces a branded, downloadable HTML report
    suitable for SOC2/ISO prep, client deliverables, or internal review.
    Includes a security score (A-F grade), detailed findings, and recommendations.

    Args:
        server: Server to audit
        company_name: Company name for branding (default: "Server Guardian")
        output_path: Where to save the report (default: ~/.server-guardian-mcp/)
    """
    info = _resolve_server(server)
    if "error" in info:
        return json.dumps(info, indent=2)

    server_name = info["name"]

    # Run security audit (reuse the existing run_security_audit logic)
    audit_json = json.loads(run_security_audit(server))
    if "error" in audit_json:
        return json.dumps(audit_json, indent=2)

    # Convert audit dict sections into a list of check results
    audit_data = audit_json.get("audit", {})
    checks = []
    for section_name, section_content in audit_data.items():
        # Determine pass/fail from content
        content_str = str(section_content) if section_content else ""
        content_lower = content_str.lower()
        if any(w in content_lower for w in ("no firewall", "inactive", "failed", "root login", "permitroot")):
            status = "WARNING"
        elif "error" in content_lower or "not found" in content_lower:
            status = "FAIL"
        else:
            status = "PASS"

        friendly_name = section_name.replace("_", " ").title()
        checks.append({
            "check": friendly_name,
            "status": status,
            "details": content_str[:300],
            "recommendation": "",
        })

    # Generate report
    result = generate_compliance_report(
        audit_results=checks,
        server_name=server_name,
        company_name=company_name,
        output_path=output_path,
    )

    return json.dumps(result, indent=2)


# ---------------------------------------------------------------------------
# 47. live_dashboard_info
# ---------------------------------------------------------------------------
@mcp.tool()
@_with_audit
def live_dashboard_info() -> str:
    """Get info about the live web dashboard.

    The live dashboard is a real-time web UI with auto-refreshing charts.
    Start it with: python -m server_guardian_mcp dashboard

    This tool returns the dashboard status and URL.
    """
    return json.dumps({
        "how_to_start": "python -m server_guardian_mcp dashboard",
        "custom_port": "python -m server_guardian_mcp dashboard --port 9090",
        "default_url": "http://localhost:8080",
        "features": [
            "Real-time server health cards",
            "CPU / Memory / Disk charts (Chart.js)",
            "Active alerts feed",
            "Incident timeline",
            "Auto-refresh every 30 seconds",
            "Dark theme, responsive design",
        ],
        "api_endpoints": [
            "GET /api/health/latest — latest health for all servers",
            "GET /api/health/history?server=X&hours=24 — health trends",
            "GET /api/alerts — active alerts",
            "GET /api/events?hours=24 — recent events",
            "GET /api/endpoints — endpoint check results",
            "GET /api/services/events — service events",
            "GET /api/playbooks/runs — playbook execution history",
        ],
    }, indent=2)


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    mcp.run()
