# coding: utf-8

from huaweicloudsdkcore.sdk_response import SdkResponse
from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ShowClusterEnterpriseProjectsResponse(SdkResponse):

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'sys_tags': 'list[SysTags]'
    }

    attribute_map = {
        'sys_tags': 'sys_tags'
    }

    def __init__(self, sys_tags=None):
        r"""ShowClusterEnterpriseProjectsResponse

        The model defined in huaweicloud sdk

        :param sys_tags: 企业项目列表
        :type sys_tags: list[:class:`huaweicloudsdkcdm.v1.SysTags`]
        """
        
        super().__init__()

        self._sys_tags = None
        self.discriminator = None

        if sys_tags is not None:
            self.sys_tags = sys_tags

    @property
    def sys_tags(self):
        r"""Gets the sys_tags of this ShowClusterEnterpriseProjectsResponse.

        企业项目列表

        :return: The sys_tags of this ShowClusterEnterpriseProjectsResponse.
        :rtype: list[:class:`huaweicloudsdkcdm.v1.SysTags`]
        """
        return self._sys_tags

    @sys_tags.setter
    def sys_tags(self, sys_tags):
        r"""Sets the sys_tags of this ShowClusterEnterpriseProjectsResponse.

        企业项目列表

        :param sys_tags: The sys_tags of this ShowClusterEnterpriseProjectsResponse.
        :type sys_tags: list[:class:`huaweicloudsdkcdm.v1.SysTags`]
        """
        self._sys_tags = sys_tags

    def to_dict(self):
        import warnings
        warnings.warn("ShowClusterEnterpriseProjectsResponse.to_dict() is deprecated and no longer maintained, "
                      "use to_json_object() to get the response content.", DeprecationWarning)
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ShowClusterEnterpriseProjectsResponse):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
