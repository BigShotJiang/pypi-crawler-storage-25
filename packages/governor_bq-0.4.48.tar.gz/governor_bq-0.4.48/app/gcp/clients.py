from __future__ import annotations

import logging
import re
from dataclasses import dataclass
from decimal import Decimal
from datetime import datetime
from typing import TYPE_CHECKING

import google.auth  # noqa: F401
from google.api_core.exceptions import GoogleAPIError
from google.auth.exceptions import DefaultCredentialsError
from google.cloud.exceptions import GoogleCloudError
from google.cloud.resourcemanager_v3 import ProjectsClient

from app.setup.runtime import resolve_gcp_credentials

if TYPE_CHECKING:
    from google.cloud import bigquery, storage

logger = logging.getLogger("app.gcp")

_BQ_PRICE_PER_TIB = Decimal("6.25")
_BQ_BYTES_PER_TIB = Decimal(str(1024**4))
_BQ_PRICE_PER_BYTE = _BQ_PRICE_PER_TIB / _BQ_BYTES_PER_TIB


def _normalize_information_schema_job_row(row) -> dict:
    """Convert an INFORMATION_SCHEMA row into the BigQueryJob payload shape."""
    job_dict = dict(row.items())

    if (
        job_dict.get("duration_ms") is None
        and job_dict.get("start_time")
        and job_dict.get("end_time")
    ):
        start = job_dict["start_time"]
        end = job_dict["end_time"]
        job_dict["duration_ms"] = int((end - start).total_seconds() * 1000)

    if job_dict.get("total_cost") is None and job_dict.get("total_bytes_billed"):
        job_dict["total_cost"] = (job_dict["total_bytes_billed"] / float(2**40)) * 6.25

    return job_dict


class GCPCredentialsError(RuntimeError):
    """Raised when GCP Application Default Credentials cannot be resolved."""


def get_resource_manager_client() -> ProjectsClient:
    """Create a Resource Manager ProjectsClient using ADC.

    Raises GCPCredentialsError with actionable guidance if credentials
    are not configured.
    """
    try:
        credentials, _ = resolve_gcp_credentials()
    except DefaultCredentialsError as exc:
        msg = (
            "GCP credentials not configured. "
            "Set GOOGLE_APPLICATION_CREDENTIALS to a service account JSON path, "
            "or run 'gcloud auth application-default login'."
        )
        logger.error(msg)
        raise GCPCredentialsError(msg) from exc

    return ProjectsClient(credentials=credentials)


# ---------------------------------------------------------------------------
# Shared GCP project listing (used by verification checks and configurations)
# ---------------------------------------------------------------------------


def list_gcp_projects() -> list[dict[str, str]]:
    """List all GCP projects accessible via the service account.

    Returns a list of dicts with ``project_id`` and ``display_name`` keys.
    Raises :class:`GCPCredentialsError` if ADC is not configured.
    Re-raises ``PermissionDenied`` / ``Forbidden`` from the API.
    """
    from google.api_core.exceptions import Forbidden, PermissionDenied

    client = get_resource_manager_client()
    try:
        return [
            {
                "project_id": project.project_id,
                "display_name": project.display_name or "",
            }
            for project in client.search_projects()
        ]
    except PermissionDenied, Forbidden:
        raise
    except GCPCredentialsError:
        raise


# ---------------------------------------------------------------------------
# GCS storage client and manifest validation
# ---------------------------------------------------------------------------


def get_storage_client() -> storage.Client:
    """Create a Google Cloud Storage client using ADC.

    Raises :class:`GCPCredentialsError` if credentials are not configured.
    """
    from google.cloud import storage

    try:
        credentials, _ = resolve_gcp_credentials()
    except DefaultCredentialsError as exc:
        msg = (
            "GCP credentials not configured. "
            "Set GOOGLE_APPLICATION_CREDENTIALS to a service account JSON path, "
            "or run 'gcloud auth application-default login'."
        )
        logger.error(msg)
        raise GCPCredentialsError(msg) from exc

    return storage.Client(credentials=credentials)


@dataclass
class GCSValidationResult:
    """Result of validating a GCS manifest location."""

    valid: bool
    error: str | None = None


def validate_gcs_manifest(
    bucket_name: str,
    path_prefix: str,
    object_name: str,
) -> GCSValidationResult:
    """Validate that a GCS bucket is accessible and the manifest file exists.

    Returns a :class:`GCSValidationResult` with ``valid=True`` on success,
    or ``valid=False`` with a human-readable ``error`` message.
    """
    try:
        client = get_storage_client()
    except GCPCredentialsError:
        return GCSValidationResult(
            valid=False,
            error="GCP credentials not configured. Cannot validate GCS access.",
        )

    try:
        bucket = client.bucket(bucket_name)
        if not bucket.exists():
            return GCSValidationResult(
                valid=False,
                error=f"Bucket '{bucket_name}' does not exist or is not accessible.",
            )
    except GoogleCloudError as exc:
        logger.warning("GCS bucket check failed for %s: %s", bucket_name, exc)
        return GCSValidationResult(
            valid=False,
            error=f"Cannot access bucket '{bucket_name}': {type(exc).__name__}",
        )

    blob_path = f"{path_prefix}/{object_name}" if path_prefix else object_name
    try:
        blob = bucket.blob(blob_path)
        if not blob.exists():
            return GCSValidationResult(
                valid=False,
                error=f"Manifest file '{blob_path}' not found in bucket '{bucket_name}'.",
            )
    except GoogleCloudError as exc:
        logger.warning(
            "GCS blob check failed for %s/%s: %s", bucket_name, blob_path, exc
        )
        return GCSValidationResult(
            valid=False,
            error=f"Cannot check manifest file '{blob_path}': {type(exc).__name__}",
        )

    return GCSValidationResult(valid=True)


# ---------------------------------------------------------------------------
# GCS browsing — bucket listing and prefix/object enumeration
# ---------------------------------------------------------------------------


def list_gcs_buckets(project_id: str) -> list[str]:
    """List GCS buckets accessible in the given project.

    Returns bucket names sorted alphabetically.
    Raises :class:`GCPCredentialsError` if ADC is not configured.
    """
    client = get_storage_client()
    try:
        return sorted(b.name for b in client.list_buckets(project=project_id))
    except GoogleCloudError as exc:
        logger.warning("Failed to list GCS buckets for project %s: %s", project_id, exc)
        return []


def list_gcs_path(
    bucket_name: str,
    prefix: str = "",
) -> dict[str, list[str]]:
    """List prefixes (folders) and objects (files) under a GCS path.

    Uses ``delimiter='/'`` so GCS returns virtual folder structure.

    Returns ``{"prefixes": [...], "objects": [...]}``.
    """
    client = get_storage_client()
    bucket = client.bucket(bucket_name)

    # Ensure prefix ends with / if non-empty (for folder browsing)
    if prefix and not prefix.endswith("/"):
        prefix += "/"

    blobs = client.list_blobs(bucket, prefix=prefix, delimiter="/")

    objects: list[str] = []
    for blob in blobs:
        # Strip the prefix to get just the filename
        name = blob.name
        if prefix:
            name = name[len(prefix) :]
        if name:  # skip the prefix itself
            objects.append(name)

    # prefixes are the "folders"
    prefixes: list[str] = []
    for p in blobs.prefixes:
        # Strip the parent prefix and trailing /
        folder = p
        if prefix:
            folder = p[len(prefix) :]
        folder = folder.rstrip("/")
        if folder:
            prefixes.append(folder)

    return {"prefixes": sorted(prefixes), "objects": sorted(objects)}


# ---------------------------------------------------------------------------
# BigQuery client and INFORMATION_SCHEMA queries
# ---------------------------------------------------------------------------


def get_bigquery_client(project_id: str | None = None) -> bigquery.Client:
    """Create a BigQuery client using ADC.

    Args:
        project_id: Optional GCP project ID to use. If not provided, uses the
            project from ADC or the service account's project.

    Raises :class:`GCPCredentialsError` if credentials are not configured.
    """
    import os
    from google.cloud import bigquery

    # Log which credentials source is being used
    creds_path = os.environ.get("GOOGLE_APPLICATION_CREDENTIALS")
    logger.info(
        "BigQuery client: GOOGLE_APPLICATION_CREDENTIALS=%s",
        creds_path or "(not set - using ADC)",
    )

    try:
        credentials, default_project = resolve_gcp_credentials()
    except DefaultCredentialsError as exc:
        msg = (
            "GCP credentials not configured. "
            "Set GOOGLE_APPLICATION_CREDENTIALS to a service account JSON path, "
            "or run 'gcloud auth application-default login'."
        )
        logger.error(msg)
        raise GCPCredentialsError(msg) from exc

    # Log the identity being used
    service_account_email = getattr(credentials, "service_account_email", None)
    logger.info(
        "BigQuery client: Using identity=%s, default_project=%s",
        service_account_email or "(user credentials)",
        default_project,
    )

    # Use provided project_id, or fall back to ADC project
    effective_project = project_id or default_project
    logger.info(
        "Creating BigQuery client with project=%s (provided=%s, default=%s)",
        effective_project,
        project_id,
        default_project,
    )
    return bigquery.Client(credentials=credentials, project=effective_project)


@dataclass
class DryRunResult:
    """Result of a BigQuery dry run."""

    valid: bool
    total_bytes_processed: int = 0
    estimated_cost_usd: float = 0.0
    referenced_tables: list[str] | None = None
    error: str | None = None


def dry_run_query(project_id: str, sql: str) -> DryRunResult:
    """Execute a BigQuery dry run to validate SQL and estimate cost.

    A dry run validates query syntax and returns estimated bytes processed
    without actually running the query. No cost is incurred.

    Args:
        project_id: GCP project ID.
        sql: SQL query to dry-run.

    Returns:
        DryRunResult with validation status and cost estimates.
    """
    from google.cloud import bigquery

    try:
        client = get_bigquery_client(project_id=project_id)
    except GCPCredentialsError:
        return DryRunResult(valid=False, error="GCP credentials not configured")

    job_config = bigquery.QueryJobConfig(dry_run=True, use_query_cache=False)

    try:
        query_job = client.query(sql, job_config=job_config)

        bytes_processed = query_job.total_bytes_processed or 0
        cost_usd = Decimal(str(bytes_processed)) * _BQ_PRICE_PER_BYTE

        ref_tables = []
        if query_job.referenced_tables:
            for t in query_job.referenced_tables:
                ref_tables.append(f"{t.project}.{t.dataset_id}.{t.table_id}")

        return DryRunResult(
            valid=True,
            total_bytes_processed=bytes_processed,
            estimated_cost_usd=round(float(cost_usd), 6),
            referenced_tables=ref_tables,
        )
    except GoogleAPIError as exc:
        # Expected for invalid candidate SQL during solution generation.
        logger.debug("Dry run failed for project %s: %s", project_id, exc)
        return DryRunResult(valid=False, error=str(exc))


def dry_run_partition_cluster_ddl(
    project_id: str,
    dataset: str,
    select_sql: str,
    partition_by: dict | None = None,
    cluster_by: list[str] | None = None,
) -> DryRunResult:
    """Validate partition/cluster config by dry-running the DDL BigQuery would execute.

    Constructs a CREATE TABLE ... PARTITION BY ... CLUSTER BY ... AS (SELECT ...)
    statement and dry-runs it. This catches type mismatches (e.g. partitioning
    a TIMESTAMP column with data_type='date') that a SELECT-only dry run would miss.

    Uses a random temp table name to avoid conflicts; dry run never creates it.

    Args:
        project_id: GCP project ID.
        dataset: BigQuery dataset for the temp table reference.
        select_sql: The compiled SELECT query from the dbt model.
        partition_by: dbt-style partition_by dict with 'field', 'data_type',
            and optionally 'granularity'.
        cluster_by: List of column names for CLUSTER BY.

    Returns:
        DryRunResult. If valid=False, error contains the BigQuery error message.
    """
    import uuid

    if not partition_by and not cluster_by:
        return DryRunResult(valid=True)

    temp_table = f"`{project_id}.{dataset}.__governor_dry_run_{uuid.uuid4().hex[:8]}`"

    # Build PARTITION BY expression matching dbt-bigquery's logic
    partition_clause = ""
    if partition_by:
        field = partition_by.get("field", "")
        data_type = partition_by.get("data_type", "date").lower()
        granularity = partition_by.get("granularity", "").lower()

        if data_type == "date" and not granularity:
            partition_clause = f"PARTITION BY {field}"
        elif data_type == "date" and granularity in ("month", "year"):
            partition_clause = (
                f"PARTITION BY DATE_TRUNC({field}, {granularity.upper()})"
            )
        elif data_type == "timestamp":
            gran = granularity.upper() if granularity else "DAY"
            partition_clause = f"PARTITION BY TIMESTAMP_TRUNC({field}, {gran})"
        elif data_type == "datetime":
            gran = granularity.upper() if granularity else "DAY"
            partition_clause = f"PARTITION BY DATETIME_TRUNC({field}, {gran})"
        elif data_type == "int64":
            partition_clause = (
                f"PARTITION BY RANGE_BUCKET({field}, GENERATE_ARRAY(0, 1000000, 1000))"
            )
        else:
            partition_clause = f"PARTITION BY {field}"

    cluster_clause = ""
    if cluster_by:
        cluster_clause = f"CLUSTER BY {', '.join(cluster_by)}"

    # Strip dbt config blocks that may leak through when the SQL was
    # synthesized from manifest compiled SQL instead of a full dbt compile.
    clean_sql = _strip_dbt_config_blocks(select_sql).strip()
    if _contains_dbt_jinja(clean_sql):
        return DryRunResult(
            valid=False,
            error=(
                "DDL validation received uncompiled dbt SQL containing Jinja markers. "
                "Expected compiled SQL but found raw dbt template syntax."
            ),
        )

    ddl = f"CREATE TABLE {temp_table}\n"
    if partition_clause:
        ddl += f"{partition_clause}\n"
    if cluster_clause:
        ddl += f"{cluster_clause}\n"
    ddl += f"AS (\n{clean_sql}\n)"

    logger.debug("DDL dry-run validation:\n%s", ddl[:500])
    return dry_run_query(project_id, ddl)


def _strip_dbt_config_blocks(sql: str) -> str:
    """Remove any leading dbt ``{{ config(...) }}`` blocks from SQL."""
    from app.solutions.templates.config_parser import parse_config_block

    stripped_sql = sql
    while True:
        block = parse_config_block(stripped_sql)
        if block is None:
            return stripped_sql
        stripped_sql = stripped_sql[: block.start] + stripped_sql[block.end :]


def _contains_dbt_jinja(sql: str) -> bool:
    """Whether SQL still contains dbt/Jinja template markers."""
    return any(marker in sql for marker in ("{{", "{%", "{#"))


def query_table_storage(
    project_id: str,
    region: str = "us",
) -> list[dict]:
    """Query INFORMATION_SCHEMA.TABLE_STORAGE for all tables in the project.

    Args:
        project_id: GCP project ID
        region: BigQuery region (default "us")

    Returns:
        List of dicts with per-table storage byte counts.

    Raises:
        GCPCredentialsError: If ADC not configured
        google.api_core.exceptions.GoogleAPIError: On BigQuery API errors
    """
    client = get_bigquery_client(project_id=project_id)

    query = f"""
        SELECT
            project_id,
            table_schema,
            table_name,
            creation_time,
            table_type,
            total_rows,
            total_partitions,
            total_logical_bytes,
            active_logical_bytes,
            long_term_logical_bytes,
            total_physical_bytes,
            active_physical_bytes,
            long_term_physical_bytes,
            time_travel_physical_bytes,
            fail_safe_physical_bytes
        FROM `{project_id}`.`region-{region}`.INFORMATION_SCHEMA.TABLE_STORAGE
        WHERE deleted = false
          AND table_type IN ('BASE TABLE', 'MATERIALIZED VIEW')
    """

    try:
        query_job = client.query(query)
        results = query_job.result()
        rows = [dict(row.items()) for row in results]
        logger.info(
            "Retrieved %d table storage records from BigQuery for project %s",
            len(rows),
            project_id,
        )
        return rows
    except GoogleAPIError as exc:
        logger.error(
            "Failed to query TABLE_STORAGE for project %s: %s",
            project_id,
            exc,
        )
        raise


def query_billing_models(
    project_id: str,
    region: str = "us",
) -> dict[str, str]:
    """Query INFORMATION_SCHEMA.SCHEMATA_OPTIONS for dataset billing models.

    Args:
        project_id: GCP project ID
        region: BigQuery region (default "us")

    Returns:
        Dict mapping dataset_name -> billing_model ("LOGICAL" or "PHYSICAL").
        Datasets not in the result default to "LOGICAL".

    Raises:
        GCPCredentialsError: If ADC not configured
        google.api_core.exceptions.GoogleAPIError: On BigQuery API errors
    """
    client = get_bigquery_client(project_id=project_id)

    query = f"""
        SELECT
            schema_name,
            option_value AS billing_model
        FROM `{project_id}`.`region-{region}`.INFORMATION_SCHEMA.SCHEMATA_OPTIONS
        WHERE option_name = 'storage_billing_model'
    """

    try:
        query_job = client.query(query)
        results = query_job.result()
        billing_models = {}
        for row in results:
            billing_models[row["schema_name"]] = row["billing_model"]
        logger.info(
            "Retrieved billing models for %d datasets in project %s",
            len(billing_models),
            project_id,
        )
        return billing_models
    except GoogleAPIError as exc:
        logger.error(
            "Failed to query SCHEMATA_OPTIONS for project %s: %s",
            project_id,
            exc,
        )
        raise


def query_table_columns(
    project_id: str,
    region: str = "us",
) -> list[dict]:
    """Query INFORMATION_SCHEMA.COLUMNS for all table columns in the project.

    Args:
        project_id: GCP project ID
        region: BigQuery region (default "us")

    Returns:
        List of dicts with column metadata (dataset_name, table_name,
        column_name, data_type, ordinal_position).

    Raises:
        GCPCredentialsError: If ADC not configured
        google.api_core.exceptions.GoogleAPIError: On BigQuery API errors
    """
    client = get_bigquery_client(project_id=project_id)

    region_normalized = (region or "us").strip().lower()
    if not re.fullmatch(r"[a-z0-9-]+", region_normalized):
        raise ValueError(f"Invalid BigQuery region: {region!r}")

    query = f"""
        SELECT
            table_schema AS dataset_name,
            table_name,
            column_name,
            data_type,
            ordinal_position
        FROM `{project_id}`.`region-{region_normalized}`.INFORMATION_SCHEMA.COLUMNS
        WHERE NOT STARTS_WITH(table_schema, '_')
    """

    try:
        query_job = client.query(query)
        results = query_job.result()
        rows = [dict(row.items()) for row in results]
        logger.info(
            "Retrieved %d column metadata records from BigQuery for project %s",
            len(rows),
            project_id,
        )
        return rows
    except GoogleAPIError as exc:
        logger.error(
            "Failed to query INFORMATION_SCHEMA.COLUMNS for project %s: %s",
            project_id,
            exc,
        )
        raise


def query_information_schema_jobs(
    project_id: str,
    dbt_tables: list[str],
    last_sync_timestamp=None,
    region: str = "us",
    start_time: datetime | None = None,
    end_time: datetime | None = None,
) -> list[dict]:
    """Query BigQuery INFORMATION_SCHEMA.JOBS for dbt-related jobs.

    **CRITICAL**: This function filters to ONLY jobs that interact with dbt-managed
    tables (FR-013), using destination_table or referenced_tables matching.

    Args:
        project_id: GCP project ID to query
        dbt_tables: List of fully qualified table names from dbt manifests
            (format: "project.dataset.table")
        last_sync_timestamp: Optional datetime for incremental sync. If None,
            queries last 180 days unless an explicit start/end window is provided.
        region: BigQuery region for INFORMATION_SCHEMA jobs query (default "us").
        start_time: Optional explicit lower bound for creation_time.
        end_time: Optional explicit upper bound for creation_time.

    Returns:
        List of job dicts with all required fields including:
        - job_id, user_email, query, creation_time, start_time, end_time
        - duration_ms, total_slot_ms, total_bytes_processed, total_bytes_billed
        - total_cost, input_record_count, output_record_count
        - slots_used, slots_available, job_state, job_type
        - error_result, total_modified_partitions
        - cache_hit, destination_table, referenced_tables
        - statement_type, bi_engine_mode, bi_engine_reasons
        - performance_insights, query_hashes, timeline

    Raises:
        GCPCredentialsError: If ADC not configured
        google.api_core.exceptions.GoogleAPIError: On BigQuery API errors
    """
    from google.cloud import bigquery

    # Create client with the target project so INFORMATION_SCHEMA queries work
    client = get_bigquery_client(project_id=project_id)

    # Build time filter
    if start_time and end_time:
        time_filter = (
            f"creation_time >= TIMESTAMP('{start_time.isoformat()}') "
            f"AND creation_time <= TIMESTAMP('{end_time.isoformat()}')"
        )
    elif start_time:
        time_filter = f"creation_time >= TIMESTAMP('{start_time.isoformat()}')"
    elif end_time:
        time_filter = f"creation_time <= TIMESTAMP('{end_time.isoformat()}')"
    elif last_sync_timestamp:
        time_filter = f"creation_time > TIMESTAMP('{last_sync_timestamp.isoformat()}')"
    else:
        time_filter = (
            "creation_time >= TIMESTAMP_SUB(CURRENT_TIMESTAMP(), INTERVAL 180 DAY)"
        )

    # Build dbt tables filter
    # Method 1: destination_table matching (jobs that WRITE to dbt tables)
    # Method 2: referenced_tables matching (jobs that READ FROM dbt tables)
    if not dbt_tables:
        # No dbt tables means no jobs to sync (FR-013)
        logger.warning("No dbt tables provided, returning empty job list")
        return []

    # Escape table names for SQL and build filter clauses
    dbt_tables_escaped = [f"'{table}'" for table in dbt_tables]
    dbt_tables_list = ", ".join(dbt_tables_escaped)
    region_normalized = (region or "us").strip().lower()
    if not re.fullmatch(r"[a-z0-9-]+", region_normalized):
        raise ValueError(f"Invalid BigQuery region: {region!r}")

    query = f"""
        SELECT
            job_id,
            user_email,
            query,
            creation_time,
            start_time,
            end_time,
            TIMESTAMP_DIFF(end_time, start_time, MILLISECOND) as duration_ms,
            total_slot_ms,
            total_bytes_processed,
            total_bytes_billed,
            (total_bytes_billed / POW(2, 40)) * 6.25 as total_cost,
            total_modified_partitions,
            bi_engine_statistics.bi_engine_mode,
            bi_engine_statistics.bi_engine_reasons,
            cache_hit,
            destination_table.project_id || '.' || destination_table.dataset_id || '.' || destination_table.table_id as destination_table,
            ARRAY(
                SELECT ref.project_id || '.' || ref.dataset_id || '.' || ref.table_id
                FROM UNNEST(referenced_tables) as ref
            ) as referenced_tables,
            statement_type,
            job_type,
            state as job_state,
            error_result,
            query_info.performance_insights,
            query_info.query_hashes,
            timeline
        FROM `region-{region_normalized}.INFORMATION_SCHEMA.JOBS`
        WHERE {time_filter}
            AND project_id = @project_id
            AND (
                destination_table IS NULL
                OR NOT STARTS_WITH(destination_table.dataset_id, '_')
            )
            AND (
                -- Method 1: Jobs that write to dbt tables
                CONCAT(
                    destination_table.project_id, '.',
                    destination_table.dataset_id, '.',
                    destination_table.table_id
                ) IN ({dbt_tables_list})
                OR
                -- Method 2: Jobs that read from dbt tables
                EXISTS (
                    SELECT 1
                    FROM UNNEST(referenced_tables) AS ref
                    WHERE CONCAT(ref.project_id, '.', ref.dataset_id, '.', ref.table_id)
                          IN ({dbt_tables_list})
                )
            )
        ORDER BY creation_time DESC
        LIMIT 100000
    """

    job_config = bigquery.QueryJobConfig(
        query_parameters=[
            bigquery.ScalarQueryParameter("project_id", "STRING", project_id),
        ]
    )

    try:
        query_job = client.query(query, job_config=job_config)
        results = query_job.result()

        jobs = []
        for row in results:
            jobs.append(_normalize_information_schema_job_row(row))

        logger.info(
            "Retrieved %d dbt-related jobs from BigQuery for project %s",
            len(jobs),
            project_id,
        )
        return jobs

    except GoogleAPIError as exc:
        logger.error(
            "Failed to query BigQuery INFORMATION_SCHEMA for project %s: %s",
            project_id,
            exc,
        )
        raise


def query_information_schema_jobs_by_ids(
    project_id: str,
    job_ids: list[str],
    region: str = "us",
) -> list[dict]:
    """Query BigQuery INFORMATION_SCHEMA.JOBS for an explicit list of job IDs."""
    from google.cloud import bigquery

    if not job_ids:
        return []

    client = get_bigquery_client(project_id=project_id)
    region_normalized = (region or "us").strip().lower()
    if not re.fullmatch(r"[a-z0-9-]+", region_normalized):
        raise ValueError(f"Invalid BigQuery region: {region!r}")

    query = f"""
        SELECT
            job_id,
            user_email,
            query,
            creation_time,
            start_time,
            end_time,
            TIMESTAMP_DIFF(end_time, start_time, MILLISECOND) as duration_ms,
            total_slot_ms,
            total_bytes_processed,
            total_bytes_billed,
            (total_bytes_billed / POW(2, 40)) * 6.25 as total_cost,
            total_modified_partitions,
            bi_engine_statistics.bi_engine_mode,
            bi_engine_statistics.bi_engine_reasons,
            cache_hit,
            destination_table.project_id || '.' || destination_table.dataset_id || '.' || destination_table.table_id as destination_table,
            ARRAY(
                SELECT ref.project_id || '.' || ref.dataset_id || '.' || ref.table_id
                FROM UNNEST(referenced_tables) as ref
            ) as referenced_tables,
            statement_type,
            job_type,
            state as job_state,
            error_result,
            query_info.performance_insights,
            query_info.query_hashes,
            timeline
        FROM `region-{region_normalized}.INFORMATION_SCHEMA.JOBS`
        WHERE project_id = @project_id
          AND job_id IN UNNEST(@job_ids)
        ORDER BY creation_time DESC
    """

    job_config = bigquery.QueryJobConfig(
        query_parameters=[
            bigquery.ScalarQueryParameter("project_id", "STRING", project_id),
            bigquery.ArrayQueryParameter("job_ids", "STRING", job_ids),
        ]
    )

    try:
        results = client.query(query, job_config=job_config).result()
        jobs = [_normalize_information_schema_job_row(row) for row in results]
        logger.info(
            "Retrieved %d exact-matched jobs from BigQuery for project %s",
            len(jobs),
            project_id,
        )
        return jobs
    except GoogleAPIError as exc:
        logger.error(
            "Failed to query BigQuery INFORMATION_SCHEMA by job_id for project %s: %s",
            project_id,
            exc,
        )
        raise
