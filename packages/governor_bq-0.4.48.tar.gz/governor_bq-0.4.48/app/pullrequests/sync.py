"""Periodic sync of pull request statuses from GitHub.

Polls all open PR records, checks their status via the GitHub API,
and updates both the PR record and the parent opportunity accordingly.
"""

from __future__ import annotations

import logging
from datetime import datetime, timezone

from dateutil.parser import isoparse
from sqlalchemy.orm import Session

from sqlalchemy.exc import SQLAlchemyError

from app.github.client import (
    GitHubAppClient,
    GitHubAuthenticationError,
    GitHubConnectionError,
    GitHubRateLimitError,
    GitHubTokenClient,
)
from app.opportunities.models import Opportunity
from app.pullrequests.models import PullRequestRecord
from app.solutions.models import Solution, SolutionJob

logger = logging.getLogger("app.pullrequests.sync")


def _parse_merged_at(raw: str | None) -> datetime | None:
    """Parse GitHub's merged_at ISO string to a timezone-aware datetime."""
    if not raw:
        return None
    try:
        dt = isoparse(raw)
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt
    except (ValueError, TypeError):
        return None


def sync_open_prs(
    db: Session, github_client: GitHubAppClient | GitHubTokenClient
) -> dict:
    """Check all open PR records against GitHub and update statuses.

    Args:
        db: Active database session.
        github_client: Authenticated GitHub client.

    Returns:
        Dict with counts: {"checked": N, "merged": N, "closed": N, "errors": N}
    """
    open_prs = (
        db.query(PullRequestRecord).filter(PullRequestRecord.status == "open").all()
    )

    if not open_prs:
        logger.debug("No open PR records to sync")
        return {"checked": 0, "merged": 0, "closed": 0, "errors": 0}

    counts = {"checked": len(open_prs), "merged": 0, "closed": 0, "errors": 0}

    for pr_record in open_prs:
        try:
            pr_data = github_client.get_pull_request(
                pr_record.repository, pr_record.pr_number
            )

            if pr_data["merged"]:
                pr_record.status = "merged"
                pr_record.merged_at = _parse_merged_at(
                    pr_data.get("merged_at")
                ) or datetime.now(timezone.utc)
                counts["merged"] += 1

                # Transition opportunity to resolved and start cost tracking
                opportunity = (
                    db.query(Opportunity)
                    .filter(Opportunity.id == pr_record.opportunity_id)
                    .one_or_none()
                )
                if opportunity and opportunity.status in (
                    "pr_pending",
                    "active",
                    "clearing",
                ):
                    opportunity.status = "resolved"
                    opportunity.resolved_at = pr_record.merged_at
                    opportunity.verified_savings_status = "pending"
                    logger.info(
                        "Opportunity %s resolved (PR #%d merged at %s) — "
                        "cost tracking initiated",
                        opportunity.id,
                        pr_record.pr_number,
                        pr_record.merged_at,
                    )

                    # Clear solutions for downstream opportunities in the
                    # same config — the upstream fix may resolve them too.
                    _clear_downstream_solutions(db, opportunity)

                logger.info(
                    "PR #%d in %s merged — record %s updated",
                    pr_record.pr_number,
                    pr_record.repository,
                    pr_record.id,
                )

            elif pr_data["state"] == "closed":
                pr_record.status = "closed"
                counts["closed"] += 1

                # Revert opportunity to active so user can create a new PR
                opportunity = (
                    db.query(Opportunity)
                    .filter(Opportunity.id == pr_record.opportunity_id)
                    .one_or_none()
                )
                if opportunity and opportunity.status == "pr_pending":
                    opportunity.status = "active"
                    logger.info(
                        "Opportunity %s reverted to active (PR #%d closed)",
                        opportunity.id,
                        pr_record.pr_number,
                    )

                logger.info(
                    "PR #%d in %s closed — record %s updated",
                    pr_record.pr_number,
                    pr_record.repository,
                    pr_record.id,
                )

            # state == "open" → no change needed

        except (GitHubAuthenticationError, GitHubConnectionError, GitHubRateLimitError, SQLAlchemyError, KeyError) as exc:
            counts["errors"] += 1
            logger.warning(
                "Failed to sync PR #%d in %s: %s",
                pr_record.pr_number,
                pr_record.repository,
                exc,
            )

    db.commit()

    logger.info(
        "PR status sync complete: checked=%d, merged=%d, closed=%d, errors=%d",
        counts["checked"],
        counts["merged"],
        counts["closed"],
        counts["errors"],
    )
    return counts


def _clear_downstream_solutions(db: Session, merged_opportunity: Opportunity) -> None:
    """Clear solutions for sibling opportunities that may be resolved by an upstream fix.

    When a PR merges for one opportunity, downstream models in the same config
    may also be fixed. Delete their solutions so stale fixes aren't shown while
    we wait for the next detection run to confirm.
    """
    sibling_ids = [
        row[0]
        for row in db.query(Opportunity.id)
        .filter(
            Opportunity.config_id == merged_opportunity.config_id,
            Opportunity.id != merged_opportunity.id,
            Opportunity.status.in_(["active", "clearing"]),
        )
        .all()
    ]
    if not sibling_ids:
        return

    # Cancel pending solution jobs
    cancelled = (
        db.query(SolutionJob)
        .filter(
            SolutionJob.opportunity_id.in_(sibling_ids),
            SolutionJob.status.in_(["queued", "in_progress"]),
        )
        .update(
            {
                "status": "failed",
                "error_message": "Cancelled: upstream PR merged, awaiting re-detection",
                "completed_at": datetime.now(timezone.utc),
            },
            synchronize_session="fetch",
        )
    )

    # Delete solutions
    deleted = (
        db.query(Solution)
        .filter(Solution.opportunity_id.in_(sibling_ids))
        .delete(synchronize_session="fetch")
    )

    # Clear cached dry-run costs
    if deleted:
        db.query(Opportunity).filter(Opportunity.id.in_(sibling_ids)).update(
            {
                "latest_solution_dry_run_original_cost": None,
                "latest_solution_dry_run_modified_cost": None,
            },
            synchronize_session="fetch",
        )

    if cancelled or deleted:
        logger.info(
            "Cleared downstream solutions after PR merge for opportunity %s: "
            "%d solutions deleted, %d jobs cancelled across %d siblings",
            merged_opportunity.id,
            deleted,
            cancelled,
            len(sibling_ids),
        )


def execute_pr_status_sync() -> None:
    """APScheduler callback — opens DB session, syncs PR statuses.

    Imports SessionLocal directly to avoid pickling issues with
    APScheduler's SQLAlchemy job store.
    """
    from app.db.session import SessionLocal

    from app.pullrequests.collection import collect_prs
    from app.setup.runtime import create_github_client

    session = SessionLocal()
    try:
        github_client = create_github_client()
        if github_client is None:
            logger.debug("GitHub integration not configured, skipping PR status sync")
            return

        # Run collection first to discover any missing PR records
        try:
            collect_prs(session, github_client)
        except (GitHubAuthenticationError, GitHubConnectionError, GitHubRateLimitError, SQLAlchemyError):
            logger.exception("Error in PR collection (continuing with status sync)")
            session.rollback()

        sync_open_prs(session, github_client)

        # Apply clearing status on opportunities affected by recent merged PRs
        try:
            from app.pullrequests.clearing import apply_clearing_status

            apply_clearing_status(session, github_client)
        except (GitHubAuthenticationError, GitHubConnectionError, GitHubRateLimitError, SQLAlchemyError):
            logger.exception("Error applying clearing status (non-fatal)")
            session.rollback()

    except (GitHubAuthenticationError, GitHubConnectionError, GitHubRateLimitError, SQLAlchemyError):
        logger.exception("Error in PR status sync")
        session.rollback()
    finally:
        session.close()
