"""Exceptions for pull request creation."""

from __future__ import annotations


class PRCreationError(RuntimeError):
    """Raised when pull request creation fails for any reason."""


class FileDriftError(PRCreationError):
    """Raised when the source file has changed since the solution was generated."""


class DuplicatePRError(PRCreationError):
    """Raised when a pull request already exists for the opportunity."""

    def __init__(self, pr_url: str) -> None:
        self.pr_url = pr_url
        super().__init__(f"A pull request already exists: {pr_url}")
