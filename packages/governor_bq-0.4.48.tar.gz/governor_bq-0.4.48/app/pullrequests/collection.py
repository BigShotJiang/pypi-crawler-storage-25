"""PR history collection — discovers Governor PRs from GitHub and imports them.

Scans configured repositories for PRs with the ``governor/`` branch prefix,
matches them to opportunities via PR body metadata, and creates
PullRequestRecord entries for any PRs not already tracked in the database.
"""

from __future__ import annotations

import logging
import re
import uuid
from datetime import datetime, timezone

from dateutil.parser import isoparse
from sqlalchemy.orm import Session

from app.configurations.models import ManifestConfiguration
from app.github.client import (
    GitHubAppClient,
    GitHubAuthenticationError,
    GitHubConnectionError,
    GitHubRateLimitError,
)
from app.opportunities.models import Opportunity
from app.pullrequests.models import PullRequestRecord

logger = logging.getLogger("app.pullrequests.collection")

# Regex to extract opportunity ID from PR body footer.
# Matches: Opportunity: `{uuid}`
_OPPORTUNITY_RE = re.compile(r"Opportunity:\s*`([0-9a-f\-]{36})`", re.IGNORECASE)

# Also check the commit-message style footer: Governor-Opportunity: {uuid}
_GOVERNOR_OPP_RE = re.compile(
    r"Governor-Opportunity:\s*([0-9a-f\-]{36})", re.IGNORECASE
)


def _extract_opportunity_id(body: str) -> str | None:
    """Extract opportunity UUID from a PR body string."""
    match = _OPPORTUNITY_RE.search(body)
    if match:
        return match.group(1)
    match = _GOVERNOR_OPP_RE.search(body)
    if match:
        return match.group(1)
    return None


def _parse_iso_datetime(raw: str | None) -> datetime | None:
    """Parse an ISO 8601 string into a timezone-aware datetime."""
    if not raw:
        return None
    try:
        dt = isoparse(raw)
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt
    except (ValueError, TypeError):
        return None


def _pr_status(pr_data: dict) -> str:
    """Derive a normalised status string from GitHub PR data."""
    if pr_data.get("merged"):
        return "merged"
    if pr_data.get("state") == "closed":
        return "closed"
    return "open"


def collect_prs(db: Session, github_client: GitHubAppClient) -> dict:
    """Discover Governor PRs on GitHub and import missing ones.

    Args:
        db: Active database session.
        github_client: Authenticated GitHub client.

    Returns:
        Dict with summary counts:
          repos_scanned, prs_discovered, prs_imported,
          prs_skipped, prs_orphaned, errors.
    """
    counts = {
        "repos_scanned": 0,
        "prs_discovered": 0,
        "prs_imported": 0,
        "prs_skipped": 0,
        "prs_orphaned": 0,
        "errors": 0,
    }

    # 1. Discover repos from active manifest configurations
    repos = _get_configured_repos(db)
    if not repos:
        logger.debug("No configured repos for PR collection")
        return counts

    # 2. Collect existing (repo, pr_number) pairs to skip duplicates
    existing_keys = _get_existing_pr_keys(db)

    for repo in repos:
        counts["repos_scanned"] += 1
        try:
            pr_list = github_client.list_pull_requests(repo, state="all")
        except (GitHubAuthenticationError, GitHubConnectionError, GitHubRateLimitError) as exc:
            counts["errors"] += 1
            logger.warning("Failed to list PRs in %s: %s", repo, exc)
            continue

        for pr_data in pr_list:
            counts["prs_discovered"] += 1
            key = (repo, pr_data["number"])

            if key in existing_keys:
                counts["prs_skipped"] += 1
                continue

            # Try to match to an opportunity
            opp_id = _extract_opportunity_id(pr_data.get("body", ""))
            opportunity_id = None
            if opp_id:
                exists = (
                    db.query(Opportunity.id)
                    .filter(Opportunity.id == opp_id)
                    .one_or_none()
                )
                if exists:
                    opportunity_id = opp_id
                else:
                    counts["prs_orphaned"] += 1
            else:
                counts["prs_orphaned"] += 1

            status = _pr_status(pr_data)
            merged_at = _parse_iso_datetime(pr_data.get("merged_at"))
            opened_at = _parse_iso_datetime(pr_data.get("created_at"))

            pr_record = PullRequestRecord(
                id=str(uuid.uuid4()),
                opportunity_id=opportunity_id,
                solution_id=None,
                repository=repo,
                branch_name=pr_data["head_ref"],
                pr_number=pr_data["number"],
                pr_url=pr_data["html_url"],
                commit_sha=pr_data["head_sha"],
                base_branch=pr_data["base_ref"],
                status=status,
                created_by=None,
                created_at=opened_at or datetime.now(timezone.utc),
                merged_at=merged_at,
            )
            db.add(pr_record)
            existing_keys.add(key)
            counts["prs_imported"] += 1

    if counts["prs_imported"]:
        db.commit()

    logger.info(
        "PR collection complete: repos=%d, discovered=%d, imported=%d, "
        "skipped=%d, orphaned=%d, errors=%d",
        counts["repos_scanned"],
        counts["prs_discovered"],
        counts["prs_imported"],
        counts["prs_skipped"],
        counts["prs_orphaned"],
        counts["errors"],
    )
    return counts


def _get_configured_repos(db: Session) -> list[str]:
    """Return distinct github_repo values from active ManifestConfigurations."""
    rows = (
        db.query(ManifestConfiguration.github_repo)
        .filter(
            ManifestConfiguration.status == "active",
            ManifestConfiguration.github_repo.isnot(None),
        )
        .distinct()
        .all()
    )
    return [r[0] for r in rows if r[0]]


def _get_existing_pr_keys(db: Session) -> set[tuple[str, int]]:
    """Return set of (repository, pr_number) for all existing PR records."""
    rows = db.query(PullRequestRecord.repository, PullRequestRecord.pr_number).all()
    return {(r[0], r[1]) for r in rows}
