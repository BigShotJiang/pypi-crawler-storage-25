from __future__ import annotations

import concurrent.futures
import logging
from collections.abc import Callable

from app.verification.checks.base import CheckResult, CheckStatus, CheckType
from app.verification.checks.gcp_projects import run_gcp_projects_check
from app.verification.checks.github import run_github_check
from app.verification.checks.postgres import run_postgres_check

logger = logging.getLogger("app.verification")

CHECK_TIMEOUT_SECONDS = 30

ALL_CHECKS: list[Callable[[], CheckResult]] = [
    run_gcp_projects_check,
    run_postgres_check,
    run_github_check,
]

_FUNCTION_CHECK_TYPE: dict[str, CheckType] = {
    "run_gcp_projects_check": CheckType.GCP_PROJECTS,
    "run_postgres_check": CheckType.POSTGRESQL,
    "run_github_check": CheckType.GITHUB,
}


def _run_check_with_timeout(
    check_fn: Callable[[], CheckResult],
) -> CheckResult:
    """Execute a single check with a timeout."""
    executor = concurrent.futures.ThreadPoolExecutor(max_workers=1)
    future = executor.submit(check_fn)
    try:
        return future.result(timeout=CHECK_TIMEOUT_SECONDS)
    except concurrent.futures.TimeoutError:
        future.cancel()
        return CheckResult(
            check_type=_FUNCTION_CHECK_TYPE.get(
                check_fn.__name__, CheckType.GCP_PROJECTS
            ),
            status=CheckStatus.ERROR,
            message=f"Check timed out after {CHECK_TIMEOUT_SECONDS} seconds.",
            remediation="Check network connectivity and service availability.",
        )
    finally:
        executor.shutdown(wait=False, cancel_futures=True)


def _get_active_checks() -> list[Callable[[], CheckResult]]:
    """Return the checks to run, skipping GitHub in local mode if not configured."""
    from app.core.config import is_local_mode
    from app.setup.runtime import resolve_github_configuration

    if is_local_mode() and resolve_github_configuration() is None:
        return [c for c in ALL_CHECKS if c is not run_github_check]
    return list(ALL_CHECKS)


def run_all_checks() -> list[CheckResult]:
    """Execute all verification checks and return results."""
    results: list[CheckResult] = []
    for check_fn in _get_active_checks():
        try:
            result = _run_check_with_timeout(check_fn)
        except (TimeoutError, RuntimeError, OSError) as exc:
            logger.exception("Unexpected error running check %s", check_fn.__name__)
            result = CheckResult(
                check_type=_FUNCTION_CHECK_TYPE.get(
                    check_fn.__name__, CheckType.GCP_PROJECTS
                ),
                status=CheckStatus.ERROR,
                message=f"Check execution failed: {type(exc).__name__}",
                remediation="Review application logs for details.",
            )
        results.append(result)
    return results


def compute_overall_status(results: list[CheckResult]) -> str:
    """Compute aggregate status from individual check results.

    Skip-status checks are excluded from the pass/fail determination (FR-005).
    """
    active_results = [r for r in results if r.status != CheckStatus.SKIP]

    if not active_results:
        return "ready"

    if any(r.status == CheckStatus.ERROR for r in active_results):
        return "error"

    if any(r.status == CheckStatus.FAIL for r in active_results):
        return "not_ready"

    if all(r.status == CheckStatus.PASS for r in active_results):
        return "ready"

    return "not_ready"
