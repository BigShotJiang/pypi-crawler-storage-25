from __future__ import annotations

from datetime import datetime
from enum import StrEnum

from pydantic import BaseModel

from app.verification.checks.base import CheckResult


class OverallStatus(StrEnum):
    RUNNING = "running"
    READY = "ready"
    NOT_READY = "not_ready"
    ERROR = "error"


class SystemReadiness(StrEnum):
    READY = "ready"
    NOT_READY = "not_ready"
    UNKNOWN = "unknown"


class VerificationRunResult(BaseModel):
    id: str
    overall_status: OverallStatus
    started_at: datetime
    completed_at: datetime | None = None
    environment: str
    checks: list[CheckResult]


class SystemStatus(BaseModel):
    status: SystemReadiness
    last_checked_at: datetime | None = None
