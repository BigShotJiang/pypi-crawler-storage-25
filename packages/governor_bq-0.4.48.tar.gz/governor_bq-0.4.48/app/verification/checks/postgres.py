from __future__ import annotations

import logging
import time

from sqlalchemy import text
from sqlalchemy.exc import OperationalError, ProgrammingError, SQLAlchemyError

from app.db.session import SessionLocal
from app.verification.checks.base import CheckResult, CheckStatus, CheckType

logger = logging.getLogger("app.verification")


def run_postgres_check() -> CheckResult:
    """Verify PostgreSQL connectivity using the application's configured engine."""
    start = time.monotonic()
    try:
        db = SessionLocal()
        try:
            db.execute(text("SELECT 1"))
        finally:
            db.close()

        elapsed_ms = int((time.monotonic() - start) * 1000)
        return CheckResult(
            check_type=CheckType.POSTGRESQL,
            status=CheckStatus.PASS,
            message="PostgreSQL connection verified.",
            duration_ms=elapsed_ms,
        )

    except OperationalError as exc:
        elapsed_ms = int((time.monotonic() - start) * 1000)
        err_str = str(exc.orig) if exc.orig else str(exc)

        if "authentication" in err_str.lower() or "password" in err_str.lower():
            return CheckResult(
                check_type=CheckType.POSTGRESQL,
                status=CheckStatus.FAIL,
                message="PostgreSQL authentication failed.",
                remediation="Check DATABASE_URL credentials (username/password).",
                duration_ms=elapsed_ms,
            )

        return CheckResult(
            check_type=CheckType.POSTGRESQL,
            status=CheckStatus.FAIL,
            message="PostgreSQL connection failed.",
            remediation=(
                "Check DATABASE_URL for correct host, port, and database name. "
                "Verify the database server is running and accessible."
            ),
            duration_ms=elapsed_ms,
        )

    except ProgrammingError:
        elapsed_ms = int((time.monotonic() - start) * 1000)
        return CheckResult(
            check_type=CheckType.POSTGRESQL,
            status=CheckStatus.FAIL,
            message="PostgreSQL query execution error.",
            remediation="Check DATABASE_URL for correct database name and schema configuration.",
            duration_ms=elapsed_ms,
        )

    except SQLAlchemyError as exc:
        elapsed_ms = int((time.monotonic() - start) * 1000)
        logger.exception("Unexpected error during PostgreSQL check")
        return CheckResult(
            check_type=CheckType.POSTGRESQL,
            status=CheckStatus.ERROR,
            message=f"PostgreSQL check failed: {type(exc).__name__}",
            remediation="Check DATABASE_URL configuration and network connectivity.",
            duration_ms=elapsed_ms,
        )
