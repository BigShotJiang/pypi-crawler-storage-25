from __future__ import annotations

from enum import StrEnum
from typing import Any

from pydantic import BaseModel


class CheckType(StrEnum):
    GCP_PROJECTS = "gcp_projects"
    POSTGRESQL = "postgresql"
    GITHUB = "github"


class CheckStatus(StrEnum):
    PASS = "pass"
    FAIL = "fail"
    SKIP = "skip"
    ERROR = "error"


class CheckResult(BaseModel):
    check_type: CheckType
    status: CheckStatus
    message: str
    details: dict[str, Any] | None = None
    remediation: str | None = None
    duration_ms: int | None = None
