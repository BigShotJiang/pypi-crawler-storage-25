"""CLI config file management (~/.governor/config.json)."""

from __future__ import annotations

import json
import os
import secrets
from pathlib import Path
from typing import Any

CONFIG_DIR = Path.home() / ".governor"
CONFIG_FILE = CONFIG_DIR / "config.json"
PID_FILE = CONFIG_DIR / "server.pid"


def ensure_config_dir() -> Path:
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    return CONFIG_DIR


def load_config() -> dict[str, Any]:
    if not CONFIG_FILE.exists():
        return {}
    try:
        return json.loads(CONFIG_FILE.read_text())
    except (json.JSONDecodeError, OSError):
        return {}


def save_config(data: dict[str, Any]) -> None:
    ensure_config_dir()
    CONFIG_FILE.write_text(json.dumps(data, indent=2) + "\n")


def update_config(**kwargs: Any) -> dict[str, Any]:
    cfg = load_config()
    cfg.update(kwargs)
    save_config(cfg)
    return cfg


def read_pid() -> int | None:
    if not PID_FILE.exists():
        return None
    try:
        return int(PID_FILE.read_text().strip())
    except (ValueError, OSError):
        return None


def write_pid(pid: int) -> None:
    ensure_config_dir()
    PID_FILE.write_text(str(pid))


def clear_pid() -> None:
    if PID_FILE.exists():
        PID_FILE.unlink(missing_ok=True)


def load_env_from_config() -> None:
    """Set all required environment variables from saved config.

    This is the key function that makes `governor start` work from any
    directory without the user setting env vars manually.
    """
    cfg = load_config()

    # DATABASE_URL — required
    if cfg.get("database_url"):
        os.environ.setdefault("DATABASE_URL", cfg["database_url"])

    # SECRET_KEY — auto-generate and persist if missing
    secret_key = cfg.get("secret_key")
    if not secret_key:
        secret_key = secrets.token_urlsafe(32)
        update_config(secret_key=secret_key)
    os.environ.setdefault("SECRET_KEY", secret_key)

    # Sensible defaults for local dev
    os.environ.setdefault("APP_ENV", "development")
    os.environ.setdefault("LOG_LEVEL", "INFO")
    os.environ.setdefault("WORKER_ENABLED", "true")
    os.environ.setdefault("SCHEDULER_ENABLED", "true")
    os.environ.setdefault("SESSION_COOKIE_SECURE", "false")

    # BigQuery region from config
    if cfg.get("bigquery_region"):
        os.environ.setdefault("BIGQUERY_REGION", cfg["bigquery_region"])

    # Local mode flag — tells the server to simplify the setup wizard
    if cfg.get("local_mode"):
        os.environ["GOVERNOR_LOCAL_MODE"] = "true"
