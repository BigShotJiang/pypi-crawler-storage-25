"""Step 1: Database setup — Docker auto-provision or manual URL."""

from __future__ import annotations

import os

from app.cli import config as cli_config
from app.cli import display, docker


def run(*, database_url: str | None = None, yes: bool = False) -> str:
    """Set up database and run migrations. Returns DATABASE_URL."""
    # Non-interactive: use provided URL
    if database_url:
        os.environ["DATABASE_URL"] = database_url
        _run_migrations()
        cli_config.update_config(database_url=database_url, docker_managed=False)
        display.success(f"Using database: {_mask_url(database_url)}")
        return database_url

    # Check saved config
    saved = cli_config.load_config()
    if saved.get("database_url"):
        saved_url = saved["database_url"]
        if saved.get("docker_managed"):
            status = docker.container_status()
            if status == "running":
                os.environ["DATABASE_URL"] = saved_url
                _run_migrations()
                display.success("Existing Docker database is running")
                return saved_url
            if status == "exited":
                docker.start_existing_container()
                port = docker.get_container_port() or docker.DEFAULT_PORT
                if docker.wait_for_ready(port):
                    os.environ["DATABASE_URL"] = saved_url
                    _run_migrations()
                    display.success("Restarted existing Docker database")
                    return saved_url

    # Try Docker
    if docker.is_docker_available():
        status = docker.container_status()
        if status == "running":
            port = docker.get_container_port() or docker.DEFAULT_PORT
            url = docker.build_database_url(port)
            os.environ["DATABASE_URL"] = url
            _run_migrations()
            cli_config.update_config(database_url=url, docker_managed=True)
            display.success(f"PostgreSQL running on port {port}")
            return url

        if status == "exited":
            docker.start_existing_container()
            port = docker.get_container_port() or docker.DEFAULT_PORT
            if docker.wait_for_ready(port):
                url = docker.build_database_url(port)
                os.environ["DATABASE_URL"] = url
                _run_migrations()
                cli_config.update_config(database_url=url, docker_managed=True)
                display.success(f"Restarted PostgreSQL on port {port}")
                return url

        # Create new container
        if not yes:
            proceed = display.confirm("Docker detected. Start PostgreSQL container?")
            if not proceed:
                return _prompt_manual_url()

        port = docker.find_free_port()
        with display.spinner("Starting PostgreSQL container..."):
            url = docker.start_container(port)
            if not docker.wait_for_ready(port):
                display.error("PostgreSQL failed to become ready within 30 seconds")
                return _prompt_manual_url()

        os.environ["DATABASE_URL"] = url
        _run_migrations()
        cli_config.update_config(
            database_url=url, docker_managed=True, docker_port=port
        )
        display.success(f"PostgreSQL running on port {port}")
        return url

    # Check if Postgres is already running on default port
    if docker.is_port_in_use(5432):
        display.info("PostgreSQL detected on port 5432")
        if yes or display.confirm("Use existing PostgreSQL on port 5432?"):
            url = "postgresql+psycopg://postgres:postgres@127.0.0.1:5432/governor"
            os.environ["DATABASE_URL"] = url
            _run_migrations()
            cli_config.update_config(database_url=url, docker_managed=False)
            display.success("Using existing PostgreSQL on port 5432")
            return url

    # Fallback: manual URL
    display.warn("Docker not available and no PostgreSQL detected")
    return _prompt_manual_url()


def _prompt_manual_url() -> str:
    url = display.ask(
        "DATABASE_URL",
        default="postgresql+psycopg://postgres:postgres@127.0.0.1:5432/governor",
    )
    os.environ["DATABASE_URL"] = url
    _run_migrations()
    cli_config.update_config(database_url=url, docker_managed=False)
    display.success("Database configured")
    return url


def _run_migrations() -> None:
    import os as _os
    from pathlib import Path

    from alembic import command
    from alembic.config import Config

    # Find alembic.ini: prefer repo root (source install), fall back to
    # constructing a config programmatically (pip install from PyPI).
    ini_path = Path("alembic.ini")
    if not ini_path.exists():
        # Installed as a package — migrations are inside the app package
        app_pkg = Path(__file__).resolve().parent.parent.parent
        ini_candidate = app_pkg.parent / "alembic.ini"
        if ini_candidate.exists():
            ini_path = ini_candidate

    if ini_path.exists():
        alembic_cfg = Config(str(ini_path))
    else:
        # No alembic.ini anywhere — build config programmatically
        alembic_cfg = Config()
        migrations_dir = Path(__file__).resolve().parent.parent.parent / "migrations"
        alembic_cfg.set_main_option("script_location", str(migrations_dir))

    # Always use the DATABASE_URL from the environment
    db_url = _os.environ.get("DATABASE_URL", "")
    if db_url:
        alembic_cfg.set_main_option("sqlalchemy.url", db_url)

    with display.spinner("Running migrations..."):
        command.upgrade(alembic_cfg, "head")
    display.success("Migrations applied")


def _mask_url(url: str) -> str:
    """Mask password in DATABASE_URL for display."""
    if "@" in url and ":" in url:
        parts = url.split("@", 1)
        prefix = parts[0].rsplit(":", 1)[0]
        return f"{prefix}:***@{parts[1]}"
    return url
