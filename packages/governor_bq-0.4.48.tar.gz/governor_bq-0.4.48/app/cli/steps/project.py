"""Step 4: Project configuration — create config, upload manifest, queue sync."""

from __future__ import annotations

from pathlib import Path

from sqlalchemy.exc import SQLAlchemyError

from app.cli import display
from app.github.client import (
    GitHubAuthenticationError,
    GitHubConfigurationError,
    GitHubConnectionError,
    GitHubRateLimitError,
)


def run(
    *,
    database_url: str,
    gcp_result: dict,
    github_result: dict,
    manifest_path: str | None = None,
    github_repo: str | None = None,
    project_path: str | None = None,
    yes: bool = False,
) -> dict | None:
    """Create a project configuration. Returns {config_id, config_name} or None if skipped."""
    display.step_header(4, 5, "Project Configuration")

    project_id = gcp_result["project_id"]

    # Auto-detect dbt project from the selected path or CWD (spec 084)
    local_project_path: str | None = None
    workspace_info = _detect_local_workspace(project_path)
    run_results: dict | None = None

    # Manifest source
    manifest_bytes: bytes | None = None
    manifest_source = "manual_upload"

    if workspace_info and workspace_info.has_manifest and not manifest_path:
        # Auto-detected dbt project with compiled manifest
        local_project_path = workspace_info.project_path
        manifest_path = str(Path(local_project_path) / "target" / "manifest.json")
        display.success(
            f"Auto-detected dbt project: {workspace_info.dbt_project_name or local_project_path}"
        )
        if workspace_info.git_branch:
            display.info(f"  Branch: {workspace_info.git_branch}")
        if workspace_info.git_repo:
            display.info(f"  Repository: {workspace_info.git_repo}")

        # Auto-set github_repo from Git remote if not provided
        if not github_repo and workspace_info.git_repo:
            github_repo = workspace_info.git_repo

        # Read run_results if available
        if workspace_info.has_run_results:
            from app.workspace.detection import read_local_run_results

            run_results = read_local_run_results(local_project_path)
            if run_results:
                display.success("Loaded run_results.json")

    if manifest_path:
        path = Path(manifest_path).expanduser()
        if not path.exists():
            display.error(f"Manifest file not found: {path}")
            raise SystemExit(4)
        manifest_bytes = path.read_bytes()
        display.success(f"Loaded manifest from {path.name}")
    elif not yes:
        choice = display.choose(
            "dbt manifest source:",
            ["Local file (target/manifest.json)", "GCS bucket", "Skip for now"],
        )
        if choice.startswith("Local"):
            path_str = display.ask("Manifest path", default="target/manifest.json")
            path = Path(path_str).expanduser()
            if path.exists():
                manifest_bytes = path.read_bytes()
                display.success(f"Loaded manifest from {path.name}")
                # Infer local_project_path from manifest location
                if not local_project_path:
                    potential_root = path.resolve().parent.parent
                    if (potential_root / "dbt_project.yml").exists():
                        local_project_path = str(potential_root)
            else:
                display.warn(f"File not found: {path}. Skipping manifest upload.")
        elif choice.startswith("GCS"):
            manifest_source = "gcs"
        else:
            display.dim("Manifest skipped — you can upload one later from the web UI")
            manifest_bytes = None

    # GitHub repo
    repo = github_repo
    if not repo and not github_result.get("skipped") and not yes:
        repos = _try_list_repos()
        if repos:
            display.info("Available repositories:")
            for i, r in enumerate(repos[:10]):
                display.info(f"  {i + 1}. {r['full_name']}")
            choice = display.ask("Repository (number or owner/repo)")
            try:
                idx = int(choice) - 1
                if 0 <= idx < len(repos):
                    repo = repos[idx]["full_name"]
            except ValueError:
                if "/" in choice:
                    repo = choice.strip()
        if not repo:
            repo = display.ask("GitHub repository (owner/repo)", default="")

    # Create configuration
    import os

    os.environ.setdefault("DATABASE_URL", database_url)

    from sqlalchemy.orm import Session

    from sqlalchemy import create_engine

    from app.configurations.schemas import ManifestConfigurationCreate
    from app.configurations.service import ManifestConfigurationService

    engine = create_engine(database_url, pool_pre_ping=True)
    with Session(engine) as db:
        service = ManifestConfigurationService(db)
        data = ManifestConfigurationCreate(
            gcp_project_id=project_id,
            github_repo=repo or "",
            manifest_source=manifest_source,
            bucket_name=""
            if manifest_source == "manual_upload"
            else display.ask("GCS bucket name"),
            path_prefix=""
            if manifest_source == "manual_upload"
            else display.ask("Path prefix", default=""),
            object_name=""
            if manifest_source == "manual_upload"
            else display.ask("Object name", default="manifest.json"),
            local_project_path=local_project_path,
        )

        with display.spinner("Creating configuration..."):
            config = service.create_configuration(data, user_id=_get_admin_user_id(db))

        if manifest_bytes and manifest_source == "manual_upload":
            with display.spinner("Uploading manifest..."):
                service.store_uploaded_manifest(
                    config_id=config.id,
                    manifest_bytes=manifest_bytes,
                    user_id=config.created_by_id or _get_admin_user_id(db),
                )

        display.success(f"Configuration created: {config.name}")

        # Queue sync
        try:
            from app.sync.service import DuplicateSyncError, SyncService

            SyncService(db).create_sync_operation(
                config.id,
                config.created_by_id or _get_admin_user_id(db),
            )
            display.success("First sync queued")
        except DuplicateSyncError:
            display.dim("First sync is already queued or in progress")
        except SQLAlchemyError, OSError:
            display.dim("Sync will start when the server launches")

    return {"config_id": config.id, "config_name": config.name}


def _detect_local_workspace(project_path: str | None = None):
    """Try to auto-detect a dbt project from a selected path or CWD."""
    try:
        import os

        from app.workspace.detection import detect_workspace

        return detect_workspace(project_path or os.getcwd())
    except ImportError, OSError:
        return None


def _try_list_repos() -> list[dict]:
    try:
        from app.setup.runtime import create_github_client

        client = create_github_client()
        if client:
            return client.list_installation_repos()
    except (
        GitHubConfigurationError,
        GitHubAuthenticationError,
        GitHubConnectionError,
        GitHubRateLimitError,
    ):
        pass
    return []


def _get_admin_user_id(db) -> str:
    from app.auth.models import User

    user = db.query(User).first()
    if user:
        return user.id
    return "cli-setup"
