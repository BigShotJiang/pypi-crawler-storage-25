"""Step 2: Google Cloud authentication — ADC, gcloud browser, or JSON file."""

from __future__ import annotations

import json
import shutil
import subprocess
from pathlib import Path

import google.auth.exceptions
from google.api_core.exceptions import GoogleAPIError
from google.cloud.exceptions import GoogleCloudError

from app.cli import display


def run(
    *,
    gcp_credentials: str | None = None,
    gcp_project: str | None = None,
    bigquery_region: str = "us",
    yes: bool = False,
    no_browser: bool = False,
) -> dict:
    """Authenticate with Google Cloud. Returns {auth_method, project_id, region, credentials_json}."""
    display.step_header(2, 5, "Google Cloud")

    credentials_json: str | None = None
    auth_method = "adc"

    # Non-interactive: JSON file path provided
    if gcp_credentials:
        path = Path(gcp_credentials).expanduser()
        if not path.exists():
            display.error(f"Credentials file not found: {path}")
            raise SystemExit(3)
        credentials_json = path.read_text()
        try:
            json.loads(credentials_json)
        except json.JSONDecodeError:
            display.error("Invalid JSON in credentials file")
            raise SystemExit(3)
        auth_method = "json"
        display.success(f"Loaded credentials from {path}")

    # Try existing ADC
    if not credentials_json:
        identity = _detect_adc_identity()
        if identity:
            if yes or display.confirm(
                f"Found Google credentials for {identity}. Use these?"
            ):
                auth_method = "adc"
                display.success(f"Using existing credentials ({identity})")
            else:
                credentials_json, auth_method = _authenticate_interactive(no_browser)
        else:
            credentials_json, auth_method = _authenticate_interactive(no_browser)

    # Get project ID
    project_id = gcp_project
    if not project_id:
        project_id = _select_project(auth_method, credentials_json)

    # Get region
    region = bigquery_region
    if not gcp_project and not yes:
        region = display.ask("BigQuery region", default=bigquery_region)

    # Validate BigQuery access
    _validate_bigquery_access(project_id, region, auth_method, credentials_json)

    return {
        "auth_method": auth_method,
        "project_id": project_id,
        "region": region,
        "credentials_json": credentials_json,
    }


def _detect_adc_identity() -> str | None:
    """Detect existing ADC credentials and return the identity."""
    try:
        import google.auth

        credentials, _ = google.auth.default(
            scopes=["https://www.googleapis.com/auth/cloud-platform"]
        )
        if hasattr(credentials, "service_account_email"):
            return credentials.service_account_email
        if hasattr(credentials, "client_id") and credentials.client_id:
            return credentials.client_id
        return "default credentials"
    except google.auth.exceptions.DefaultCredentialsError:
        return None


def _authenticate_interactive(no_browser: bool) -> tuple[str | None, str]:
    """Run interactive authentication. Returns (credentials_json, auth_method)."""
    gcloud_path = shutil.which("gcloud")
    if gcloud_path and not no_browser:
        display.info("Launching Google Cloud login in browser...")
        try:
            subprocess.run(
                [gcloud_path, "auth", "application-default", "login"],
                check=True,
                timeout=300,
            )
            display.success("Google Cloud authentication complete")
            return None, "adc"
        except (subprocess.CalledProcessError, subprocess.TimeoutExpired):
            display.warn("Browser login failed or timed out")

    # Fallback: JSON file path
    display.info("Provide a service account JSON key file path")
    path_str = display.ask("Path to service account JSON")
    path = Path(path_str).expanduser()
    if not path.exists():
        display.error(f"File not found: {path}")
        raise SystemExit(3)
    credentials_json = path.read_text()
    try:
        json.loads(credentials_json)
    except json.JSONDecodeError:
        display.error("Invalid JSON in file")
        raise SystemExit(3)
    display.success(f"Loaded credentials from {path.name}")
    return credentials_json, "json"


def _select_project(
    auth_method: str, credentials_json: str | None
) -> str:
    """Select or enter a GCP project ID."""
    projects = _try_list_projects()
    if projects:
        display.info("Available BigQuery projects:")
        for i, p in enumerate(projects[:10]):
            display.info(f"  {i + 1}. {p['project_id']} ({p.get('display_name', '')})")
        choice = display.ask("Project ID (number or type manually)")
        try:
            idx = int(choice) - 1
            if 0 <= idx < len(projects):
                project_id = projects[idx]["project_id"]
                display.success(f"Selected project: {project_id}")
                return project_id
        except ValueError:
            pass
        if choice.strip():
            return choice.strip()

    return display.ask("BigQuery project ID")


def _try_list_projects() -> list[dict]:
    """Try listing GCP projects. Returns empty list on failure."""
    try:
        from app.gcp.clients import GCPCredentialsError, list_gcp_projects

        return list_gcp_projects()
    except (GCPCredentialsError, GoogleCloudError, GoogleAPIError):
        return []


def _validate_bigquery_access(
    project_id: str,
    region: str,
    auth_method: str,
    credentials_json: str | None,
) -> None:
    """Probe BigQuery to validate access."""
    with display.spinner(f"Validating BigQuery access for {project_id}..."):
        try:
            from google.cloud import bigquery

            if auth_method == "json" and credentials_json:
                import json as json_mod

                from google.oauth2 import service_account

                info = json_mod.loads(credentials_json)
                creds = service_account.Credentials.from_service_account_info(
                    info,
                    scopes=["https://www.googleapis.com/auth/cloud-platform"],
                )
                client = bigquery.Client(project=project_id, credentials=creds)
            else:
                client = bigquery.Client(project=project_id)

            query = f"SELECT 1 FROM `{project_id}`.`region-{region}`.INFORMATION_SCHEMA.JOBS LIMIT 1"
            list(client.query(query).result())
            display.success("BigQuery access verified")
        except (GoogleCloudError, GoogleAPIError, google.auth.exceptions.DefaultCredentialsError) as exc:
            display.warn(f"BigQuery probe failed: {exc}")
            display.info("You can proceed, but sync may fail until access is granted")
