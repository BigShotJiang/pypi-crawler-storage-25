"""Step 3: GitHub authentication — device flow, PAT paste, or skip."""

from __future__ import annotations

import time
import webbrowser

import httpx

from app.cli import display

# GitHub OAuth App client ID for the Governor CLI device flow.
# This is a public client ID (standard practice for CLI tools).
# Replace with your registered OAuth App's client ID.
GITHUB_CLIENT_ID = "Ov23lifFYfTJPS559046"
DEVICE_FLOW_SCOPES = "repo"


def run(
    *,
    github_token: str | None = None,
    yes: bool = False,
    no_browser: bool = False,
) -> dict:
    """Authenticate with GitHub. Returns {token, login, skipped}."""
    display.step_header(3, 5, "GitHub")

    # Non-interactive: token provided
    if github_token:
        login = _verify_token(github_token)
        if login:
            display.success(f"Authenticated as @{login}")
            return {"token": github_token, "login": login, "skipped": False}
        display.error("GitHub token verification failed")
        raise SystemExit(3)

    # Interactive: choose method
    choices = ["Browser login (recommended)", "Paste existing token", "Skip for now"]
    choice = display.choose("How would you like to authenticate with GitHub?", choices)

    if choice == choices[2]:
        display.dim("GitHub skipped — PR creation will be disabled")
        return {"token": None, "login": None, "skipped": True}

    if choice == choices[1]:
        return _paste_token_flow()

    # Device flow
    return _device_flow(no_browser=no_browser)


def _device_flow(*, no_browser: bool = False) -> dict:
    """Run GitHub device flow authentication."""
    import httpx

    # Step 1: Request device code
    try:
        resp = httpx.post(
            "https://github.com/login/device/code",
            data={"client_id": GITHUB_CLIENT_ID, "scope": DEVICE_FLOW_SCOPES},
            headers={"Accept": "application/json"},
            timeout=15,
        )
        resp.raise_for_status()
        data = resp.json()
    except httpx.HTTPError as exc:
        display.error(f"Failed to initiate device flow: {exc}")
        display.dim("This can happen if the OAuth App doesn't have Device Flow enabled.")
        display.info("Falling back to personal access token...")
        return _paste_token_flow()

    user_code = data["user_code"]
    device_code = data["device_code"]
    verification_uri = data["verification_uri"]
    interval = data.get("interval", 5)
    expires_in = data.get("expires_in", 900)

    # Step 2: Display code and open browser
    display.info(f"Open [bold]{verification_uri}[/] and enter code: [bold blue]{user_code}[/]")
    if not no_browser:
        try:
            webbrowser.open(verification_uri)
        except OSError:
            pass

    # Step 3: Poll for authorization
    deadline = time.time() + expires_in
    with display.spinner("Waiting for authorization..."):
        while time.time() < deadline:
            time.sleep(interval)
            try:
                token_resp = httpx.post(
                    "https://github.com/login/oauth/access_token",
                    data={
                        "client_id": GITHUB_CLIENT_ID,
                        "device_code": device_code,
                        "grant_type": "urn:ietf:params:oauth:grant-type:device_code",
                    },
                    headers={"Accept": "application/json"},
                    timeout=15,
                )
                token_data = token_resp.json()
            except httpx.HTTPError:
                continue

            if "access_token" in token_data:
                token = token_data["access_token"]
                login = _verify_token(token)
                if login:
                    display.success(f"Authenticated as @{login}")
                    return {"token": token, "login": login, "skipped": False}

            error = token_data.get("error")
            if error == "authorization_pending":
                continue
            if error == "slow_down":
                interval = token_data.get("interval", interval + 5)
                continue
            if error == "expired_token":
                break
            if error == "access_denied":
                display.error("Authorization denied by user")
                return _offer_retry_or_skip()

    display.warn("Device flow timed out")
    return _offer_retry_or_skip()


def _paste_token_flow() -> dict:
    """Prompt for a GitHub personal access token."""
    display.dim("Create a token at: https://github.com/settings/tokens")
    display.dim("Select scope: repo (full control of private repositories)")
    display.dim("Press Enter with no token to skip GitHub for now")
    token = display.ask("GitHub personal access token")
    if not token:
        display.dim("GitHub skipped — PR creation will be disabled")
        return {"token": None, "login": None, "skipped": True}
    login = _verify_token(token)
    if login:
        display.success(f"Authenticated as @{login}")
        return {"token": token, "login": login, "skipped": False}
    display.error("Token verification failed")
    if display.confirm("Try again?"):
        return _paste_token_flow()
    return {"token": None, "login": None, "skipped": True}


def _offer_retry_or_skip() -> dict:
    if display.confirm("Try again?", default=False):
        return _device_flow()
    display.dim("GitHub skipped — PR creation will be disabled")
    return {"token": None, "login": None, "skipped": True}


def _verify_token(token: str) -> str | None:
    """Verify a token and return the login name, or None on failure."""
    try:
        from app.github.client import (
            GitHubAuthenticationError,
            GitHubConfigurationError,
            GitHubConnectionError,
            GitHubRateLimitError,
            GitHubTokenClient,
        )

        client = GitHubTokenClient(token)
        info = client.verify_token_connectivity()
        return info.login
    except (
        GitHubAuthenticationError,
        GitHubConfigurationError,
        GitHubConnectionError,
        GitHubRateLimitError,
    ):
        return None
