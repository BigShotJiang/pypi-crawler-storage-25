"""Step 5: Launch — save setup state, start server, open browser."""

from __future__ import annotations

import os
import subprocess
import sys
import webbrowser

from app.cli import config as cli_config
from app.cli import display


def run(
    *,
    database_url: str,
    gcp_result: dict,
    github_result: dict,
    port: int = 8000,
    no_browser: bool = False,
    foreground: bool = True,
) -> None:
    """Save setup state, start server, and open browser."""
    display.step_header(5, 5, "Launch")

    os.environ.setdefault("DATABASE_URL", database_url)

    # Save setup state to DB
    with display.spinner("Saving setup state..."):
        _save_setup_state(database_url, gcp_result, github_result)
    display.success("Setup state saved")

    url = f"http://localhost:{port}"

    if foreground:
        display.success(f"Starting Governor on {url}")
        if not no_browser:
            display.info("Opening browser...")
            try:
                webbrowser.open(url)
            except OSError:
                pass

        # Run uvicorn in foreground (blocks)
        os.environ["DATABASE_URL"] = database_url
        try:
            import uvicorn

            uvicorn.run(
                "app.main:create_app",
                host="0.0.0.0",
                port=port,
                factory=True,
            )
        except KeyboardInterrupt:
            display.info("Server stopped")
    else:
        _start_background(database_url, port)
        display.success(f"Server started on {url}")
        if not no_browser:
            try:
                webbrowser.open(url)
            except OSError:
                pass
        display.info(f"Run [bold]governor stop[/] to stop the server")


def _save_setup_state(
    database_url: str, gcp_result: dict, github_result: dict
) -> None:
    """Write setup state to DB through existing SetupService."""
    from sqlalchemy import create_engine
    from sqlalchemy.orm import Session

    from app.setup.loader import load_setup_state
    from app.setup.service import SetupService

    engine = create_engine(database_url, pool_pre_ping=True)
    with Session(engine) as db:
        svc = SetupService(db)
        state = svc.get_state()
        if state is None:
            # Create minimal state — step1 requires admin user
            from app.auth.models import User

            user = db.query(User).first()
            admin_id = user.id if user else None
            if admin_id:
                svc.create_step1(admin_id)

        # Save GCP
        svc.save_step2(
            gcp_credentials_json=gcp_result.get("credentials_json"),
            auth_method=gcp_result.get("auth_method", "adc"),
            installation_mode="local_dev",
        )

        # Save region
        svc.save_step3(gcp_result.get("region", "us"))

        # Save GitHub
        if github_result.get("skipped"):
            svc.skip_step4()
        elif github_result.get("token"):
            svc.save_step4_personal_token(github_result["token"])

        # Skip LLM for now
        svc.skip_step5()

        # Skip GCS bucket
        svc.skip_step6()

        # Complete
        svc.complete()

        # Load into runtime
        load_setup_state(db)


def _start_background(database_url: str, port: int) -> None:
    """Start uvicorn as a background process."""
    proc = subprocess.Popen(
        [
            sys.executable,
            "-m",
            "uvicorn",
            "app.main:create_app",
            "--host",
            "0.0.0.0",
            "--port",
            str(port),
            "--factory",
        ],
        env={**os.environ, "DATABASE_URL": database_url},
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        start_new_session=True,
    )
    cli_config.write_pid(proc.pid)
    cli_config.update_config(server_port=port)
