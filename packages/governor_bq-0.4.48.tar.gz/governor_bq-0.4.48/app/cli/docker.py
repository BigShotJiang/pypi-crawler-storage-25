"""Docker subprocess helpers for PostgreSQL container management."""

from __future__ import annotations

import shutil
import socket
import subprocess
import time

CONTAINER_NAME = "governor-postgres"
IMAGE = "postgres:16-alpine"
VOLUME_NAME = "governor-data"
DEFAULT_PORT = 5432
DB_NAME = "governor"
DB_PASSWORD = "governor"
DB_USER = "postgres"


def is_docker_available() -> bool:
    if not shutil.which("docker"):
        return False
    try:
        result = subprocess.run(
            ["docker", "info"],
            capture_output=True,
            timeout=10,
        )
        return result.returncode == 0
    except (subprocess.TimeoutExpired, OSError):
        return False


def container_status() -> str | None:
    """Return container status: 'running', 'exited', or None if not found."""
    try:
        result = subprocess.run(
            [
                "docker",
                "inspect",
                "--format",
                "{{.State.Status}}",
                CONTAINER_NAME,
            ],
            capture_output=True,
            text=True,
            timeout=10,
        )
        if result.returncode == 0:
            return result.stdout.strip()
    except (subprocess.TimeoutExpired, OSError):
        pass
    return None


def find_free_port(start: int = DEFAULT_PORT) -> int:
    for port in range(start, start + 100):
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.bind(("127.0.0.1", port))
                return port
        except OSError:
            continue
    raise RuntimeError(f"No free port found in range {start}-{start + 99}")


def is_port_in_use(port: int) -> bool:
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.bind(("127.0.0.1", port))
            return False
    except OSError:
        return True


def start_container(port: int = DEFAULT_PORT) -> str:
    """Start a new PostgreSQL container. Returns the DATABASE_URL."""
    subprocess.run(
        [
            "docker",
            "run",
            "-d",
            "--name",
            CONTAINER_NAME,
            "-p",
            f"127.0.0.1:{port}:5432",
            "-e",
            f"POSTGRES_DB={DB_NAME}",
            "-e",
            f"POSTGRES_PASSWORD={DB_PASSWORD}",
            "-v",
            f"{VOLUME_NAME}:/var/lib/postgresql/data",
            IMAGE,
        ],
        capture_output=True,
        text=True,
        check=True,
        timeout=60,
    )
    return _build_url(port)


def start_existing_container() -> None:
    subprocess.run(
        ["docker", "start", CONTAINER_NAME],
        capture_output=True,
        check=True,
        timeout=30,
    )


def stop_container() -> None:
    subprocess.run(
        ["docker", "stop", CONTAINER_NAME],
        capture_output=True,
        timeout=30,
    )


def get_container_port() -> int | None:
    """Get the host port mapped to 5432 for the running container."""
    try:
        result = subprocess.run(
            [
                "docker",
                "inspect",
                "--format",
                '{{(index (index .NetworkSettings.Ports "5432/tcp") 0).HostPort}}',
                CONTAINER_NAME,
            ],
            capture_output=True,
            text=True,
            timeout=10,
        )
        if result.returncode == 0:
            return int(result.stdout.strip())
    except (subprocess.TimeoutExpired, OSError, ValueError):
        pass
    return None


def wait_for_ready(port: int, timeout: int = 30) -> bool:
    """Wait until PostgreSQL accepts connections."""
    pg_isready = shutil.which("pg_isready")
    deadline = time.time() + timeout
    while time.time() < deadline:
        if pg_isready:
            try:
                result = subprocess.run(
                    ["pg_isready", "-h", "127.0.0.1", "-p", str(port)],
                    capture_output=True,
                    timeout=5,
                )
                if result.returncode == 0:
                    return True
            except (subprocess.TimeoutExpired, OSError):
                pass
        else:
            try:
                with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                    s.settimeout(2)
                    s.connect(("127.0.0.1", port))
                    return True
            except OSError:
                pass
        time.sleep(1)
    return False


def build_database_url(port: int = DEFAULT_PORT) -> str:
    return _build_url(port)


def _build_url(port: int) -> str:
    return f"postgresql+psycopg://{DB_USER}:{DB_PASSWORD}@127.0.0.1:{port}/{DB_NAME}"
