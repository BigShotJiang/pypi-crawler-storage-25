"""Rich console display helpers for the Governor CLI."""

from __future__ import annotations

from rich.console import Console
from rich.panel import Panel
from rich.text import Text

console = Console()

BRAND = "bold blue"
SUCCESS = "bold green"
ERROR = "bold red"
WARN = "bold yellow"
DIM = "dim"


def banner() -> None:
    console.print()
    console.print(
        Panel(
            Text("Governor", style="bold blue", justify="center"),
            subtitle="BigQuery Cost Optimizer",
            border_style="blue",
            width=50,
        )
    )
    console.print()


def step_header(number: int, total: int, title: str) -> None:
    console.print(f"\n  [{BRAND}]Step {number}/{total}: {title}[/]")


def success(message: str) -> None:
    console.print(f"    [green]✓[/] {message}")


def error(message: str) -> None:
    console.print(f"    [red]✗[/] {message}")


def warn(message: str) -> None:
    console.print(f"    [yellow]![/] {message}")


def info(message: str) -> None:
    console.print(f"    {message}")


def dim(message: str) -> None:
    console.print(f"    [{DIM}]{message}[/]")


def spinner(message: str):
    """Return a Rich status context manager for a spinner."""
    return console.status(f"    {message}", spinner="dots")


def confirm(prompt: str, default: bool = True) -> bool:
    suffix = " [Y/n]" if default else " [y/N]"
    response = console.input(f"    [bold]?[/] {prompt}{suffix}: ").strip().lower()
    if not response:
        return default
    return response in ("y", "yes")


def ask(prompt: str, default: str = "") -> str:
    default_hint = f" [{default}]" if default else ""
    response = console.input(f"    [bold]?[/] {prompt}{default_hint}: ").strip()
    return response or default


def choose(prompt: str, choices: list[str], default: int = 0) -> str:
    console.print(f"    [bold]?[/] {prompt}")
    for i, choice in enumerate(choices):
        marker = ">" if i == default else " "
        console.print(f"      {marker} {choice}")
    response = console.input(f"    Choice [{default + 1}]: ").strip()
    if not response:
        return choices[default]
    try:
        idx = int(response) - 1
        if 0 <= idx < len(choices):
            return choices[idx]
    except ValueError:
        pass
    return choices[default]
