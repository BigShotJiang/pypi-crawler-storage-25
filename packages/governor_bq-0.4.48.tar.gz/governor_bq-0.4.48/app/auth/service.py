from __future__ import annotations

from datetime import datetime, timedelta, timezone
from typing import Optional

from sqlalchemy.orm import Session

from app.auth import hashing, models
from app.core.config import get_settings


def _ensure_utc(dt: datetime | None) -> datetime | None:
    if dt is None:
        return dt
    if dt.tzinfo is None:
        return dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(timezone.utc)


class AuthService:
    def __init__(self, db: Session) -> None:
        self.db = db
        self.settings = get_settings()

    def verify_credentials(self, password: str, password_hash: str) -> bool:
        return hashing.verify_password(password, password_hash)

    def build_session_expiry(self) -> datetime:
        return datetime.now(timezone.utc) + timedelta(
            hours=self.settings.session_ttl_hours
        )

    def find_user_by_email(self, email: str) -> Optional[models.User]:
        return (
            self.db.query(models.User).filter(models.User.email == email).one_or_none()
        )

    def authenticate(self, email: str, password: str) -> Optional[models.User]:
        user = self.find_user_by_email(email)
        if not user or user.status != "active":
            return None
        if not self.verify_credentials(password, user.password_hash):
            return None
        return user

    def create_session(
        self,
        user: models.User,
        ip_address: str | None,
        user_agent: str | None,
    ) -> models.Session:
        now = datetime.now(timezone.utc)
        session = models.Session(
            user_id=user.id,
            created_at=now,
            last_activity_at=now,
            expires_at=self.build_session_expiry(),
        )
        self.db.add(session)
        self.record_audit_event(user.id, "login", "success", ip_address, user_agent)
        self.db.commit()
        self.db.refresh(session)
        return session

    def refresh_session(self, session: models.Session) -> None:
        now = datetime.now(timezone.utc)
        refresh_interval = timedelta(
            minutes=max(1, self.settings.session_refresh_interval_minutes)
        )
        last_activity_at = _ensure_utc(session.last_activity_at)
        expires_at = _ensure_utc(session.expires_at)

        if (
            last_activity_at is not None
            and expires_at is not None
            and last_activity_at + refresh_interval > now
            and expires_at - now > refresh_interval
        ):
            return

        session.last_activity_at = now
        session.expires_at = self.build_session_expiry()
        self.db.commit()

    def revoke_session(
        self,
        session: models.Session,
        ip_address: str | None,
        user_agent: str | None,
    ) -> None:
        session.revoked_at = datetime.now(timezone.utc)
        self.record_audit_event(
            session.user_id, "logout", "success", ip_address, user_agent
        )
        self.db.commit()

    def record_audit_event(
        self,
        user_id: str | None,
        event_type: str,
        outcome: str,
        ip_address: str | None,
        user_agent: str | None,
    ) -> None:
        event = models.AuditEvent(
            user_id=user_id,
            event_type=event_type,
            outcome=outcome,
            ip_address=ip_address,
            user_agent=user_agent,
        )
        self.db.add(event)

    def cleanup_audit_events(self) -> int:
        cutoff = datetime.now(timezone.utc) - timedelta(
            days=self.settings.audit_retention_days
        )
        deleted = (
            self.db.query(models.AuditEvent)
            .filter(models.AuditEvent.event_at < cutoff)
            .delete()
        )
        self.db.commit()
        return deleted

    def revoke_other_sessions(self, user_id: str, current_session_id: str) -> int:
        """Revoke all sessions for a user except the specified session.

        Returns:
            Count of sessions revoked
        """
        now = datetime.now(timezone.utc)
        count = (
            self.db.query(models.Session)
            .filter(
                models.Session.user_id == user_id,
                models.Session.id != current_session_id,
                models.Session.revoked_at.is_(None),
            )
            .update({"revoked_at": now})
        )
        return count

    def change_password(
        self,
        user: models.User,
        current_password: str,
        new_password: str,
        current_session_id: str,
        ip_address: str | None,
        user_agent: str | None,
    ) -> tuple[bool, str | None]:
        """Change user's password, invalidate other sessions.

        Returns:
            (True, None) on success
            (False, error_message) on failure
        """
        # Verify current password
        if not self.verify_credentials(current_password, user.password_hash):
            self.record_audit_event(
                user.id, "password_change", "failure", ip_address, user_agent
            )
            self.db.commit()
            return (False, "Current password is incorrect.")

        # Update password hash
        user.password_hash = hashing.hash_password(new_password)

        # Revoke other sessions
        self.revoke_other_sessions(user.id, current_session_id)

        # Audit success
        self.record_audit_event(
            user.id, "password_change", "success", ip_address, user_agent
        )
        self.db.commit()
        return (True, None)
