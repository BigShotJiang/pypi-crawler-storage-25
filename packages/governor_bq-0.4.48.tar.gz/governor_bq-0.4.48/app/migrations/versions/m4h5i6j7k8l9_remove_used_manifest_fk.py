"""remove used_manifest_version_id foreign key constraint

Revision ID: m4h5i6j7k8l9
Revises: l3g4h5i6j7k8
Create Date: 2026-02-17
"""

from alembic import op

revision = "m4h5i6j7k8l9"
down_revision = "l3g4h5i6j7k8"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.drop_constraint(
        "fk_sync_ops_used_manifest_version", "sync_operations", type_="foreignkey"
    )


def downgrade() -> None:
    op.create_foreign_key(
        "fk_sync_ops_used_manifest_version",
        "sync_operations",
        "manifest_versions",
        ["used_manifest_version_id"],
        ["id"],
        ondelete="SET NULL",
    )
