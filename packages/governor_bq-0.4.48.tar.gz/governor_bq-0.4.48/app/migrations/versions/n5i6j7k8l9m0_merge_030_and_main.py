"""Merge 030-guaranteed-safe-changes and main migration heads.

Revision ID: n5i6j7k8l9m0
Revises: k2f3g4h5i6j7_030, m4h5i6j7k8l9
Create Date: 2026-02-17
"""

revision = "n5i6j7k8l9m0"
down_revision = ("k2f3g4h5i6j7_030", "m4h5i6j7k8l9")
branch_labels = None
depends_on = None


def upgrade() -> None:
    pass


def downgrade() -> None:
    pass
