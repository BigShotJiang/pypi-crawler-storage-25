"""Add table_storage_metrics table.

Revision ID: o6j7k8l9m0n1
Revises: n5i6j7k8l9m0
Create Date: 2026-02-19
"""

from alembic import op
import sqlalchemy as sa


revision = "o6j7k8l9m0n1"
down_revision = "n5i6j7k8l9m0"
branch_labels = None
depends_on = None


def upgrade():
    op.create_table(
        "table_storage_metrics",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column(
            "config_id",
            sa.String(36),
            sa.ForeignKey("manifest_configurations.id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column(
            "sync_id",
            sa.String(36),
            sa.ForeignKey("sync_operations.id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column("project_id", sa.String(256), nullable=False),
        sa.Column("dataset_name", sa.String(256), nullable=False),
        sa.Column("table_name", sa.String(256), nullable=False),
        sa.Column("table_type", sa.String(64), nullable=False),
        sa.Column(
            "billing_model",
            sa.String(16),
            nullable=False,
            server_default="LOGICAL",
        ),
        sa.Column("total_rows", sa.BigInteger, nullable=True),
        sa.Column("total_partitions", sa.Integer, nullable=True, server_default="0"),
        sa.Column(
            "total_logical_bytes", sa.BigInteger, nullable=False, server_default="0"
        ),
        sa.Column(
            "active_logical_bytes", sa.BigInteger, nullable=False, server_default="0"
        ),
        sa.Column(
            "long_term_logical_bytes",
            sa.BigInteger,
            nullable=False,
            server_default="0",
        ),
        sa.Column(
            "total_physical_bytes", sa.BigInteger, nullable=False, server_default="0"
        ),
        sa.Column(
            "active_physical_bytes", sa.BigInteger, nullable=False, server_default="0"
        ),
        sa.Column(
            "long_term_physical_bytes",
            sa.BigInteger,
            nullable=False,
            server_default="0",
        ),
        sa.Column(
            "time_travel_physical_bytes",
            sa.BigInteger,
            nullable=False,
            server_default="0",
        ),
        sa.Column(
            "fail_safe_physical_bytes",
            sa.BigInteger,
            nullable=False,
            server_default="0",
        ),
        sa.Column("compression_ratio", sa.Float, nullable=True),
        sa.Column("synced_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.CheckConstraint(
            "billing_model IN ('LOGICAL', 'PHYSICAL')", name="ck_tsm_billing_model"
        ),
        sa.UniqueConstraint(
            "config_id",
            "project_id",
            "dataset_name",
            "table_name",
            name="uq_tsm_project_dataset_table",
        ),
    )
    op.create_index(
        "ix_tsm_config_dataset",
        "table_storage_metrics",
        ["config_id", "dataset_name"],
    )
    op.create_index(
        "ix_tsm_config_sync",
        "table_storage_metrics",
        ["config_id", "sync_id"],
    )
    op.create_index(
        "ix_tsm_billing_model",
        "table_storage_metrics",
        ["billing_model"],
    )


def downgrade():
    op.drop_index("ix_tsm_billing_model")
    op.drop_index("ix_tsm_config_sync")
    op.drop_index("ix_tsm_config_dataset")
    op.drop_table("table_storage_metrics")
