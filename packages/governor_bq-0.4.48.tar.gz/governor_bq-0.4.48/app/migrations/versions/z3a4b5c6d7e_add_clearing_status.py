"""Add clearing status to opportunities.

Revision ID: z3a4b5c6d7e
Revises: y2z3a4b5c6d
Create Date: 2026-03-18

"""

from alembic import op

revision = "z3a4b5c6d7e"
down_revision = "y2z3a4b5c6d"
branch_labels = None
depends_on = None


def upgrade() -> None:
    # Drop and recreate the check constraint to add 'clearing' status
    op.drop_constraint("ck_opp_status", "opportunities", type_="check")
    op.create_check_constraint(
        "ck_opp_status",
        "opportunities",
        "status IN ('active', 'resolved', 'pr_pending', 'clearing')",
    )


def downgrade() -> None:
    # Revert clearing opportunities back to active before restoring constraint
    op.execute("UPDATE opportunities SET status = 'active' WHERE status = 'clearing'")
    op.drop_constraint("ck_opp_status", "opportunities", type_="check")
    op.create_check_constraint(
        "ck_opp_status",
        "opportunities",
        "status IN ('active', 'resolved', 'pr_pending')",
    )
