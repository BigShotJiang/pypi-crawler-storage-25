"""Add opportunity_savings_estimates table.

Revision ID: x1y2z3a4b5c
Revises: w7x8y9z0a1b
Create Date: 2026-03-16
"""

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

revision = "x1y2z3a4b5c"
down_revision = "a1b2c3d4e5f"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "opportunity_savings_estimates",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column(
            "opportunity_id",
            sa.String(36),
            sa.ForeignKey("opportunities.id", ondelete="CASCADE"),
            nullable=False,
            unique=True,
            index=True,
        ),
        sa.Column("recommendation_type", sa.String(32), nullable=False),
        sa.Column("partition_column", sa.String(256), nullable=True),
        sa.Column("cluster_columns", postgresql.JSONB(), nullable=True),
        sa.Column("jobs_analyzed", sa.Integer(), nullable=False, server_default="0"),
        sa.Column(
            "jobs_with_filters", sa.Integer(), nullable=False, server_default="0"
        ),
        sa.Column(
            "total_bytes_scanned", sa.BigInteger(), nullable=False, server_default="0"
        ),
        sa.Column(
            "total_bytes_saved", sa.BigInteger(), nullable=False, server_default="0"
        ),
        sa.Column(
            "total_cost_saved",
            sa.Numeric(18, 6),
            nullable=False,
            server_default="0",
        ),
        sa.Column(
            "per_run_savings",
            sa.Numeric(18, 6),
            nullable=False,
            server_default="0",
        ),
        sa.Column(
            "monthly_projection",
            sa.Numeric(18, 6),
            nullable=False,
            server_default="0",
        ),
        sa.Column("confidence", sa.String(16), nullable=False, server_default="low"),
        sa.Column(
            "filter_coverage_pct",
            sa.Numeric(5, 2),
            nullable=False,
            server_default="0",
        ),
        sa.Column("partition_stats_json", postgresql.JSONB(), nullable=True),
        sa.Column(
            "estimated_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.text("now()"),
        ),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.text("now()"),
        ),
        sa.Column(
            "updated_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.text("now()"),
        ),
        sa.CheckConstraint(
            "recommendation_type IN ('partition', 'cluster', 'both')",
            name="ck_savings_est_rec_type",
        ),
        sa.CheckConstraint(
            "confidence IN ('high', 'medium', 'low')",
            name="ck_savings_est_confidence",
        ),
    )


def downgrade() -> None:
    op.drop_table("opportunity_savings_estimates")
