"""add project data sync tables

Revision ID: c4d5e6f7a8b9
Revises: b3c4d5e6f7a8
Create Date: 2026-02-03 00:00:00.000000

"""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

revision: str = "c4d5e6f7a8b9"
down_revision: Union[str, None] = "b3c4d5e6f7a8"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # Create sync_operations table
    op.create_table(
        "sync_operations",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column(
            "config_id",
            sa.String(36),
            sa.ForeignKey("project_sync_configurations.id"),
            nullable=False,
        ),
        sa.Column("status", sa.String(16), nullable=False, server_default="queued"),
        sa.Column(
            "queued_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.func.now(),
        ),
        sa.Column("started_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("completed_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column(
            "jobs_retrieved_count", sa.Integer, nullable=False, server_default="0"
        ),
        sa.Column(
            "manifests_updated_count", sa.Integer, nullable=False, server_default="0"
        ),
        sa.Column(
            "initiated_by_id",
            sa.String(36),
            sa.ForeignKey("users.id"),
            nullable=False,
        ),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.func.now(),
        ),
        sa.Column(
            "updated_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.func.now(),
        ),
    )
    op.create_index(
        "ix_sync_ops_config_status", "sync_operations", ["config_id", "status"]
    )
    op.create_index(
        "ix_sync_ops_status_queued_at", "sync_operations", ["status", "queued_at"]
    )
    op.create_index("ix_sync_ops_completed_at", "sync_operations", ["completed_at"])

    # Create sync_errors table
    op.create_table(
        "sync_errors",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column(
            "sync_id",
            sa.String(36),
            sa.ForeignKey("sync_operations.id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column(
            "error_timestamp",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.func.now(),
        ),
        sa.Column("error_type", sa.String(64), nullable=False),
        sa.Column("error_message", sa.Text, nullable=False),
        sa.Column("step_context", sa.String(128), nullable=False),
        sa.Column("related_entity_id", sa.String(36), nullable=True),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.func.now(),
        ),
    )
    op.create_index("ix_sync_errors_sync_id", "sync_errors", ["sync_id"])
    op.create_index("ix_sync_errors_timestamp", "sync_errors", ["error_timestamp"])

    # Create bigquery_jobs table
    op.create_table(
        "bigquery_jobs",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column(
            "config_id",
            sa.String(36),
            sa.ForeignKey("project_sync_configurations.id"),
            nullable=False,
        ),
        sa.Column(
            "sync_id",
            sa.String(36),
            sa.ForeignKey("sync_operations.id"),
            nullable=False,
        ),
        sa.Column("job_id", sa.String(1024), nullable=False, unique=True),
        sa.Column("user_email", sa.String(320), nullable=False),
        sa.Column("query", sa.Text, nullable=True),
        sa.Column("creation_time", sa.DateTime(timezone=True), nullable=False),
        sa.Column("start_time", sa.DateTime(timezone=True), nullable=True),
        sa.Column("end_time", sa.DateTime(timezone=True), nullable=True),
        sa.Column("duration_ms", sa.BigInteger, nullable=True),
        sa.Column("total_slot_ms", sa.BigInteger, nullable=True),
        sa.Column("total_bytes_processed", sa.BigInteger, nullable=True),
        sa.Column("total_bytes_billed", sa.BigInteger, nullable=True),
        sa.Column("total_cost", sa.Numeric(10, 4), nullable=True),
        sa.Column("input_record_count", sa.BigInteger, nullable=True),
        sa.Column("output_record_count", sa.BigInteger, nullable=True),
        sa.Column("slots_used", sa.Integer, nullable=True),
        sa.Column("slots_available", sa.Integer, nullable=True),
        sa.Column("job_state", sa.String(32), nullable=False),
        sa.Column("job_type", sa.String(32), nullable=True),
        sa.Column("error_result", postgresql.JSONB, nullable=True),
        sa.Column("total_modified_partitions", sa.BigInteger, nullable=True),
        sa.Column("cache_hit", sa.Boolean, nullable=True),
        sa.Column("destination_table", sa.String(1024), nullable=True),
        sa.Column("referenced_tables", postgresql.JSONB, nullable=True),
        sa.Column("statement_type", sa.String(64), nullable=True),
        sa.Column("bi_engine_mode", sa.String(32), nullable=True),
        sa.Column("bi_engine_reasons", postgresql.JSONB, nullable=True),
        sa.Column("performance_insights", postgresql.JSONB, nullable=True),
        sa.Column("query_hashes", postgresql.JSONB, nullable=True),
        sa.Column("timeline", postgresql.JSONB, nullable=True),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.func.now(),
        ),
        sa.Column(
            "updated_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.func.now(),
        ),
    )
    op.create_index("ix_bq_jobs_config_id", "bigquery_jobs", ["config_id"])
    op.create_index("ix_bq_jobs_creation_time", "bigquery_jobs", ["creation_time"])
    op.create_index("ix_bq_jobs_sync_id", "bigquery_jobs", ["sync_id"])
    op.create_index("ix_bq_jobs_user_email", "bigquery_jobs", ["user_email"])
    op.create_index("ix_bq_jobs_cache_hit", "bigquery_jobs", ["cache_hit"])
    op.create_index("ix_bq_jobs_statement_type", "bigquery_jobs", ["statement_type"])
    op.create_index(
        "ix_bq_jobs_performance_insights",
        "bigquery_jobs",
        ["performance_insights"],
        postgresql_using="gin",
    )

    # Create manifest_versions table
    op.create_table(
        "manifest_versions",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column(
            "manifest_location_id",
            sa.String(36),
            sa.ForeignKey("manifest_locations.id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column(
            "sync_id",
            sa.String(36),
            sa.ForeignKey("sync_operations.id"),
            nullable=False,
        ),
        sa.Column("content_hash", sa.String(128), nullable=False),
        sa.Column("content", postgresql.JSONB, nullable=False),
        sa.Column("retrieved_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.func.now(),
        ),
    )
    op.create_index(
        "ix_manifest_versions_location_id",
        "manifest_versions",
        ["manifest_location_id"],
    )
    op.create_index(
        "ix_manifest_versions_retrieved_at", "manifest_versions", ["retrieved_at"]
    )
    op.create_index("ix_manifest_versions_sync_id", "manifest_versions", ["sync_id"])
    op.create_index(
        "ix_manifest_versions_hash",
        "manifest_versions",
        ["manifest_location_id", "content_hash"],
    )

    # Create sync_manifest_versions junction table
    op.create_table(
        "sync_manifest_versions",
        sa.Column(
            "sync_id",
            sa.String(36),
            sa.ForeignKey("sync_operations.id", ondelete="CASCADE"),
            primary_key=True,
        ),
        sa.Column(
            "manifest_version_id",
            sa.String(36),
            sa.ForeignKey("manifest_versions.id", ondelete="CASCADE"),
            primary_key=True,
        ),
    )
    op.create_index(
        "ix_sync_manifest_versions_manifest",
        "sync_manifest_versions",
        ["manifest_version_id"],
    )


def downgrade() -> None:
    op.drop_table("sync_manifest_versions")
    op.drop_table("manifest_versions")
    op.drop_table("bigquery_jobs")
    op.drop_table("sync_errors")
    op.drop_table("sync_operations")
