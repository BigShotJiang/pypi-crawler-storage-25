"""Make sync_operations.initiated_by_id nullable for scheduled syncs.

Revision ID: l3g4h5i6j7k8
Revises: k2f3g4h5i6j7
Create Date: 2026-02-16
"""

from alembic import op
import sqlalchemy as sa


revision = "l3g4h5i6j7k8"
down_revision = "k2f3g4h5i6j7"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.alter_column(
        "sync_operations",
        "initiated_by_id",
        existing_type=sa.String(36),
        nullable=True,
    )


def downgrade() -> None:
    # Backfill any NULL values before restoring NOT NULL
    op.execute(
        "UPDATE sync_operations SET initiated_by_id = ("
        "  SELECT mc.created_by_id FROM manifest_configurations mc"
        "  WHERE mc.id = sync_operations.config_id"
        ") WHERE initiated_by_id IS NULL"
    )
    op.alter_column(
        "sync_operations",
        "initiated_by_id",
        existing_type=sa.String(36),
        nullable=False,
    )
