"""084: local workspace awareness

Add local_project_path to manifest_configurations and
run_results_json to sync_operations.

Revision ID: h2i3j4k5l6m7
Revises: g1h2i3j4k5l6
Create Date: 2026-04-10
"""

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects.postgresql import JSONB

revision = "h2i3j4k5l6m7"
down_revision = "g1h2i3j4k5l6"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column(
        "manifest_configurations",
        sa.Column("local_project_path", sa.String(1024), nullable=True),
    )
    op.add_column(
        "sync_operations",
        sa.Column("run_results_json", JSONB, nullable=True),
    )


def downgrade() -> None:
    op.drop_column("sync_operations", "run_results_json")
    op.drop_column("manifest_configurations", "local_project_path")
