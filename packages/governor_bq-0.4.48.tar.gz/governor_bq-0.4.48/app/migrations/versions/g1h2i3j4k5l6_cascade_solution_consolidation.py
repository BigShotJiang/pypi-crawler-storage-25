"""082: cascade solution consolidation

Add cascade fields to opportunities for lineage-aware solution grouping.

Revision ID: g1h2i3j4k5l6
Revises: f5g6h7i8j9k0
Create Date: 2026-04-09
"""

from alembic import op
import sqlalchemy as sa

revision = "g1h2i3j4k5l6"
down_revision = "f5g6h7i8j9k0"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column(
        "opportunities",
        sa.Column("cascade_group_id", sa.String(36), nullable=True),
    )
    op.add_column(
        "opportunities",
        sa.Column(
            "cascade_root_id",
            sa.String(36),
            sa.ForeignKey("opportunities.id", ondelete="SET NULL"),
            nullable=True,
        ),
    )
    op.add_column(
        "opportunities",
        sa.Column("cascade_status", sa.String(20), nullable=True),
    )
    op.create_index(
        "ix_opportunities_cascade_group",
        "opportunities",
        ["cascade_group_id"],
    )
    op.create_index(
        "ix_opportunities_cascade_root",
        "opportunities",
        ["cascade_root_id"],
    )
    op.create_check_constraint(
        "ck_opp_cascade_status",
        "opportunities",
        "cascade_status IN ('root', 'delegated') OR cascade_status IS NULL",
    )


def downgrade() -> None:
    op.drop_constraint("ck_opp_cascade_status", "opportunities", type_="check")
    op.drop_index("ix_opportunities_cascade_root", "opportunities")
    op.drop_index("ix_opportunities_cascade_group", "opportunities")
    op.drop_column("opportunities", "cascade_status")
    op.drop_column("opportunities", "cascade_root_id")
    op.drop_column("opportunities", "cascade_group_id")
