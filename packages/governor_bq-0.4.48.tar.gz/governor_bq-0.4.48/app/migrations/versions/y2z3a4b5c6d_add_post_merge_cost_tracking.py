"""Add post-merge cost tracking columns.

Adds merged_at to pull_request_records and verified savings
columns to opportunities for tracking actual cost impact after
PR merge.

Revision ID: y2z3a4b5c6d
Revises: x1y2z3a4b5c
Create Date: 2026-03-17
"""

from alembic import op
import sqlalchemy as sa

revision = "y2z3a4b5c6d"
down_revision = "x1y2z3a4b5c"
branch_labels = None
depends_on = None


def upgrade() -> None:
    # pull_request_records: add merged_at
    op.add_column(
        "pull_request_records",
        sa.Column("merged_at", sa.DateTime(timezone=True), nullable=True),
    )

    # opportunities: add verified savings columns
    op.add_column(
        "opportunities",
        sa.Column("verified_savings", sa.Numeric(18, 6), nullable=True),
    )
    op.add_column(
        "opportunities",
        sa.Column("verified_savings_status", sa.String(20), nullable=True),
    )
    op.add_column(
        "opportunities",
        sa.Column(
            "verified_savings_calculated_at",
            sa.DateTime(timezone=True),
            nullable=True,
        ),
    )
    op.add_column(
        "opportunities",
        sa.Column("pre_merge_avg_cost", sa.Numeric(18, 6), nullable=True),
    )
    op.add_column(
        "opportunities",
        sa.Column("post_merge_avg_cost", sa.Numeric(18, 6), nullable=True),
    )
    op.add_column(
        "opportunities",
        sa.Column("pre_merge_job_count", sa.Integer(), nullable=True),
    )
    op.add_column(
        "opportunities",
        sa.Column("post_merge_job_count", sa.Integer(), nullable=True),
    )


def downgrade() -> None:
    op.drop_column("opportunities", "post_merge_job_count")
    op.drop_column("opportunities", "pre_merge_job_count")
    op.drop_column("opportunities", "post_merge_avg_cost")
    op.drop_column("opportunities", "pre_merge_avg_cost")
    op.drop_column("opportunities", "verified_savings_calculated_at")
    op.drop_column("opportunities", "verified_savings_status")
    op.drop_column("opportunities", "verified_savings")
    op.drop_column("pull_request_records", "merged_at")
