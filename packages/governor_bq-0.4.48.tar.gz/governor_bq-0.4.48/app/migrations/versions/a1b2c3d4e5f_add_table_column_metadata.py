"""Add table_column_metadata table for INFORMATION_SCHEMA.COLUMNS sync.

Revision ID: a1b2c3d4e5f
Revises: w7x8y9z0a1b
Create Date: 2026-03-13 10:00:00.000000
"""

from __future__ import annotations

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = "a1b2c3d4e5f"
down_revision = "w7x8y9z0a1b"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "table_column_metadata",
        sa.Column("id", sa.String(length=36), primary_key=True),
        sa.Column(
            "config_id",
            sa.String(length=36),
            sa.ForeignKey("manifest_configurations.id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column(
            "sync_id",
            sa.String(length=36),
            sa.ForeignKey("sync_operations.id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column("project_id", sa.String(length=256), nullable=False),
        sa.Column("dataset_name", sa.String(length=256), nullable=False),
        sa.Column("table_name", sa.String(length=256), nullable=False),
        sa.Column("column_name", sa.String(length=256), nullable=False),
        sa.Column("data_type", sa.String(length=1024), nullable=False),
        sa.Column("ordinal_position", sa.Integer(), nullable=False),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.func.now(),
        ),
        sa.Column(
            "updated_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.func.now(),
        ),
    )
    op.create_unique_constraint(
        "uq_tcm_config_table_column",
        "table_column_metadata",
        ["config_id", "project_id", "dataset_name", "table_name", "column_name"],
    )
    op.create_index(
        "ix_tcm_config_dataset_table",
        "table_column_metadata",
        ["config_id", "dataset_name", "table_name"],
    )
    op.create_index(
        "ix_tcm_config_sync",
        "table_column_metadata",
        ["config_id", "sync_id"],
    )


def downgrade() -> None:
    op.drop_table("table_column_metadata")
