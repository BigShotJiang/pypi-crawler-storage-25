"""create verification tables

Revision ID: a1b2c3d4e5f6
Revises: 5ac0da518320
Create Date: 2026-01-28 00:00:00.000000

"""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa

revision: str = "a1b2c3d4e5f6"
down_revision: Union[str, None] = "5ac0da518320"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.create_table(
        "verification_runs",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column(
            "admin_user_id",
            sa.String(36),
            sa.ForeignKey("users.id"),
            nullable=False,
        ),
        sa.Column(
            "started_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.func.now(),
        ),
        sa.Column("completed_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column(
            "overall_status",
            sa.String(16),
            nullable=False,
            server_default="running",
        ),
        sa.Column("environment", sa.String(64), nullable=False),
    )
    op.create_index(
        "ix_verification_runs_started_at",
        "verification_runs",
        [sa.text("started_at DESC")],
    )
    op.create_index(
        "ix_verification_runs_admin_user_id",
        "verification_runs",
        ["admin_user_id"],
    )

    op.create_table(
        "verification_checks",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column(
            "run_id",
            sa.String(36),
            sa.ForeignKey("verification_runs.id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column("check_type", sa.String(32), nullable=False),
        sa.Column("status", sa.String(16), nullable=False),
        sa.Column("message", sa.Text, nullable=False),
        sa.Column("details", sa.JSON, nullable=True),
        sa.Column("remediation", sa.Text, nullable=True),
        sa.Column("duration_ms", sa.Integer, nullable=True),
        sa.Column(
            "executed_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.func.now(),
        ),
    )
    op.create_index(
        "ix_verification_checks_run_id",
        "verification_checks",
        ["run_id"],
    )


def downgrade() -> None:
    op.drop_table("verification_checks")
    op.drop_table("verification_runs")
