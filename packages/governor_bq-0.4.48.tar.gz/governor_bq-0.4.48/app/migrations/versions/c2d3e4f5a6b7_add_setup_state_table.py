"""Add setup_state table for first-run installation wizard.

Revision ID: c2d3e4f5a6b7
Revises: b1c2d3e4f5a6
Create Date: 2026-03-31
"""

from __future__ import annotations

import sqlalchemy as sa
from alembic import op

revision = "c2d3e4f5a6b7"
down_revision = "b1c2d3e4f5a6"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "setup_state",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column("is_complete", sa.Boolean(), nullable=False, server_default="false"),
        sa.Column("step_reached", sa.Integer(), nullable=False, server_default="1"),
        sa.Column("gcp_credentials_json", sa.Text(), nullable=True),
        sa.Column("bigquery_region", sa.String(64), nullable=True),
        sa.Column("github_app_id", sa.String(64), nullable=True),
        sa.Column("github_installation_id", sa.String(64), nullable=True),
        sa.Column("github_private_key", sa.Text(), nullable=True),
        sa.Column("github_skipped", sa.Boolean(), nullable=False, server_default="false"),
        sa.Column("llm_api_key", sa.String(256), nullable=True),
        sa.Column("llm_skipped", sa.Boolean(), nullable=False, server_default="false"),
        sa.Column("gcs_bucket_path", sa.String(512), nullable=True),
        sa.Column("gcs_skipped", sa.Boolean(), nullable=False, server_default="false"),
        sa.Column("admin_user_id", sa.String(36), sa.ForeignKey("users.id"), nullable=True),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.text("now()"),
        ),
        sa.Column(
            "updated_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.text("now()"),
        ),
    )


def downgrade() -> None:
    op.drop_table("setup_state")
