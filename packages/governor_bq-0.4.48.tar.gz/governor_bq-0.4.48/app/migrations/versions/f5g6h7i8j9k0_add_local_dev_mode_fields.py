"""Add local dev mode fields for setup and manifest configurations.

Revision ID: f5g6h7i8j9k0
Revises: e4f5a6b7c8d9
Create Date: 2026-04-02
"""

from alembic import op
import sqlalchemy as sa


revision = "f5g6h7i8j9k0"
down_revision = "e4f5a6b7c8d9"
branch_labels = None
depends_on = None


def upgrade():
    op.add_column(
        "setup_state",
        sa.Column(
            "installation_mode",
            sa.String(length=16),
            nullable=False,
            server_default="cloud",
        ),
    )
    op.add_column(
        "setup_state",
        sa.Column(
            "github_auth_mode",
            sa.String(length=32),
            nullable=False,
            server_default="app",
        ),
    )
    op.add_column(
        "setup_state",
        sa.Column("github_personal_access_token", sa.Text(), nullable=True),
    )
    op.alter_column("setup_state", "installation_mode", server_default=None)
    op.alter_column("setup_state", "github_auth_mode", server_default=None)

    op.add_column(
        "manifest_configurations",
        sa.Column(
            "manifest_source",
            sa.String(length=32),
            nullable=False,
            server_default="gcs",
        ),
    )
    op.alter_column("manifest_configurations", "manifest_source", server_default=None)
    op.alter_column("manifest_configurations", "bucket_name", nullable=True)
    op.alter_column("manifest_configurations", "path_prefix", nullable=True)
    op.alter_column("manifest_configurations", "object_name", nullable=True)


def downgrade():
    op.execute(
        """
        UPDATE manifest_configurations
        SET
            bucket_name = 'manual-upload-' || substring(id from 1 for 8),
            path_prefix = '',
            object_name = 'manifest.json'
        WHERE bucket_name IS NULL
        """
    )
    op.alter_column("manifest_configurations", "object_name", nullable=False)
    op.alter_column("manifest_configurations", "path_prefix", nullable=False)
    op.alter_column("manifest_configurations", "bucket_name", nullable=False)
    op.drop_column("manifest_configurations", "manifest_source")

    op.drop_column("setup_state", "github_personal_access_token")
    op.drop_column("setup_state", "github_auth_mode")
    op.drop_column("setup_state", "installation_mode")
