"""Add process_cost_usd to opportunities.

Tracks the LLM API cost incurred generating a solution for each opportunity.
Used to compute net savings (gross dry-run savings minus process overhead).

Revision ID: a0b1c2d3e4f5
Revises: z3a4b5c6d7e
Create Date: 2026-03-30

"""

from alembic import op
import sqlalchemy as sa

revision = "a0b1c2d3e4f5"
down_revision = "z3a4b5c6d7e"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column(
        "opportunities",
        sa.Column("process_cost_usd", sa.Numeric(12, 6), nullable=True),
    )


def downgrade() -> None:
    op.drop_column("opportunities", "process_cost_usd")
