"""Add workload kind to bigquery jobs.

Revision ID: d7e8f9a0b1c2
Revises: c6d7e8f9a0b1
Create Date: 2026-03-24

"""

import sqlalchemy as sa
from alembic import op

revision = "d7e8f9a0b1c2"
down_revision = "c6d7e8f9a0b1"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column(
        "bigquery_jobs",
        sa.Column("workload_kind", sa.String(length=16), nullable=True),
    )
    op.create_check_constraint(
        "ck_bq_jobs_workload_kind",
        "bigquery_jobs",
        "workload_kind IS NULL OR workload_kind IN ('build', 'consumption')",
    )
    op.create_index(
        "ix_bigquery_jobs_workload_kind",
        "bigquery_jobs",
        ["workload_kind"],
        unique=False,
    )
    op.create_index(
        "ix_bq_jobs_config_workload_kind_creation_time",
        "bigquery_jobs",
        ["config_id", "workload_kind", "creation_time"],
        unique=False,
    )


def downgrade() -> None:
    op.drop_index(
        "ix_bq_jobs_config_workload_kind_creation_time", table_name="bigquery_jobs"
    )
    op.drop_index("ix_bigquery_jobs_workload_kind", table_name="bigquery_jobs")
    op.drop_constraint("ck_bq_jobs_workload_kind", "bigquery_jobs", type_="check")
    op.drop_column("bigquery_jobs", "workload_kind")
