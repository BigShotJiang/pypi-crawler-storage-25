"""fix used_manifest_version_id cascade

Revision ID: i0d1e2f3g4h5
Revises: h9c0d1e2f3g4
Create Date: 2026-02-10
"""

from alembic import op

revision = "i0d1e2f3g4h5"
down_revision = "h9c0d1e2f3g4"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.drop_constraint(
        "fk_sync_ops_used_manifest_version", "sync_operations", type_="foreignkey"
    )
    op.create_foreign_key(
        "fk_sync_ops_used_manifest_version",
        "sync_operations",
        "manifest_versions",
        ["used_manifest_version_id"],
        ["id"],
        ondelete="SET NULL",
    )


def downgrade() -> None:
    op.drop_constraint(
        "fk_sync_ops_used_manifest_version", "sync_operations", type_="foreignkey"
    )
    op.create_foreign_key(
        "fk_sync_ops_used_manifest_version",
        "sync_operations",
        "manifest_versions",
        ["used_manifest_version_id"],
        ["id"],
    )
