"""add_theme_preference_to_users

Revision ID: c1669eec184e
Revises: c4d5e6f7a8b9
Create Date: 2026-02-04 17:54:24.425335

"""

from __future__ import annotations

from alembic import op
import sqlalchemy as sa


revision = "c1669eec184e"
down_revision = "c4d5e6f7a8b9"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column(
        "users",
        sa.Column(
            "theme_preference",
            sa.String(length=16),
            nullable=False,
            server_default="auto",
        ),
    )


def downgrade() -> None:
    op.drop_column("users", "theme_preference")
