"""Add compiled_after_sql to solutions table.

Stores the real dbt-compiled output of after_content so the opportunity
detail page can display the true "Optimized SQL" without relying on the
fragile apply_diff_to_compiled() heuristic.

Revision ID: r9m0n1o2p3q4
Revises: q8l9m0n1o2p3
Create Date: 2026-03-03
"""

from alembic import op
import sqlalchemy as sa


revision = "r9m0n1o2p3q4"
down_revision = "q8l9m0n1o2p3"
branch_labels = None
depends_on = None


def upgrade():
    op.add_column(
        "solutions",
        sa.Column("compiled_after_sql", sa.Text(), nullable=True),
    )


def downgrade():
    op.drop_column("solutions", "compiled_after_sql")
