"""Add watched_rule_types to manifest_configurations.

Revision ID: s0p1q2r3s4t5
Revises: r9m0n1o2p3q4
Create Date: 2026-03-04
"""

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql


revision = "s0p1q2r3s4t5"
down_revision = "r9m0n1o2p3q4"
branch_labels = None
depends_on = None


def upgrade():
    op.add_column(
        "manifest_configurations",
        sa.Column(
            "watched_rule_types",
            postgresql.JSONB(astext_type=sa.Text()),
            nullable=True,
        ),
    )


def downgrade():
    op.drop_column("manifest_configurations", "watched_rule_types")
