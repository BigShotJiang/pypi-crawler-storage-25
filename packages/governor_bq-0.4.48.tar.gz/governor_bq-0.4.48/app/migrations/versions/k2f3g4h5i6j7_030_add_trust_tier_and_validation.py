"""Add trust_tier and validation_report columns.

Adds trust_tier (String(16), nullable) and validation_report (JSONB, nullable)
to the solutions table. Adds trust_tier (String(16), nullable) to the
solution_jobs table. Updates error_stage CHECK to include 'validation'.

Revision ID: k2f3g4h5i6j7_030
Revises: j1e2f3g4h5i6
Create Date: 2026-02-16
"""

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects.postgresql import JSONB

revision = "k2f3g4h5i6j7_030"
down_revision = "j1e2f3g4h5i6"
branch_labels = None
depends_on = None


def upgrade() -> None:
    # --- solutions table ---
    op.add_column("solutions", sa.Column("trust_tier", sa.String(16), nullable=True))
    op.add_column("solutions", sa.Column("validation_report", JSONB(), nullable=True))
    op.create_check_constraint(
        "ck_sol_trust_tier",
        "solutions",
        "trust_tier IS NULL OR trust_tier IN ('guaranteed_safe', 'validated', 'requires_review')",
    )
    op.create_index("ix_sol_trust_tier", "solutions", ["trust_tier"])

    # --- solution_jobs table ---
    op.add_column(
        "solution_jobs", sa.Column("trust_tier", sa.String(16), nullable=True)
    )
    op.create_check_constraint(
        "ck_sj_trust_tier",
        "solution_jobs",
        "trust_tier IS NULL OR trust_tier IN ('guaranteed_safe', 'validated', 'requires_review')",
    )
    op.create_index("ix_sj_trust_tier", "solution_jobs", ["trust_tier"])

    # Update error_stage CHECK to include 'validation'
    op.drop_constraint("ck_sj_error_stage", "solution_jobs", type_="check")
    op.create_check_constraint(
        "ck_sj_error_stage",
        "solution_jobs",
        "error_stage IS NULL OR error_stage IN ('github_retrieval', 'llm_request', 'response_parsing', 'storage', 'validation')",
    )


def downgrade() -> None:
    # Revert error_stage CHECK
    op.drop_constraint("ck_sj_error_stage", "solution_jobs", type_="check")
    op.create_check_constraint(
        "ck_sj_error_stage",
        "solution_jobs",
        "error_stage IS NULL OR error_stage IN ('github_retrieval', 'llm_request', 'response_parsing', 'storage')",
    )

    # --- solution_jobs table ---
    op.drop_index("ix_sj_trust_tier", "solution_jobs")
    op.drop_constraint("ck_sj_trust_tier", "solution_jobs", type_="check")
    op.drop_column("solution_jobs", "trust_tier")

    # --- solutions table ---
    op.drop_index("ix_sol_trust_tier", "solutions")
    op.drop_constraint("ck_sol_trust_tier", "solutions", type_="check")
    op.drop_column("solutions", "validation_report")
    op.drop_column("solutions", "trust_tier")
