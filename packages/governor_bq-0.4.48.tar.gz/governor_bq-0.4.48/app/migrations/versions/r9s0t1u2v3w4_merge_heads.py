"""Merge migration heads.

Revision ID: r9s0t1u2v3w4
Revises: j3k4l5m6n7o8, q8r9s0t1u2v3
Create Date: 2026-04-14
"""

from collections.abc import Sequence

from alembic import op

revision: str = "r9s0t1u2v3w4"
down_revision: tuple[str, ...] = ("j3k4l5m6n7o8", "q8r9s0t1u2v3")
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


def upgrade() -> None:
    pass


def downgrade() -> None:
    pass
