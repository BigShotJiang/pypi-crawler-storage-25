"""Add pull_request_records table and extend opportunity status.

Revision ID: j1e2f3g4h5i6
Revises: 90a5d984842e
Create Date: 2026-02-12
"""

from alembic import op
import sqlalchemy as sa

revision = "j1e2f3g4h5i6"
down_revision = "90a5d984842e"
branch_labels = None
depends_on = None


def upgrade() -> None:
    # --- pull_request_records table ---
    op.create_table(
        "pull_request_records",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column(
            "opportunity_id",
            sa.String(36),
            sa.ForeignKey("opportunities.id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column(
            "solution_id",
            sa.String(36),
            sa.ForeignKey("solutions.id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column("repository", sa.String(256), nullable=False),
        sa.Column("branch_name", sa.String(256), nullable=False),
        sa.Column("pr_number", sa.Integer, nullable=False),
        sa.Column("pr_url", sa.String(1024), nullable=False),
        sa.Column("commit_sha", sa.String(40), nullable=False),
        sa.Column("base_branch", sa.String(256), nullable=False),
        sa.Column("status", sa.String(16), nullable=False, server_default="open"),
        sa.Column(
            "created_by",
            sa.String(36),
            sa.ForeignKey("users.id"),
            nullable=False,
        ),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.func.now(),
        ),
        sa.Column(
            "updated_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.func.now(),
        ),
        sa.UniqueConstraint("opportunity_id", name="uq_pr_opportunity_id"),
        sa.CheckConstraint(
            "status IN ('open', 'merged', 'closed')",
            name="ck_pr_status",
        ),
    )
    op.create_index(
        "ix_pr_opportunity_id", "pull_request_records", ["opportunity_id"], unique=True
    )
    op.create_index("ix_pr_status", "pull_request_records", ["status"])

    # --- Extend opportunity status constraint ---
    op.drop_constraint("ck_opp_status", "opportunities", type_="check")
    op.create_check_constraint(
        "ck_opp_status",
        "opportunities",
        "status IN ('active', 'resolved', 'pr_pending')",
    )


def downgrade() -> None:
    # Revert opportunity status constraint
    op.drop_constraint("ck_opp_status", "opportunities", type_="check")
    op.create_check_constraint(
        "ck_opp_status",
        "opportunities",
        "status IN ('active', 'resolved')",
    )

    # Drop pull_request_records table
    op.drop_index("ix_pr_status", table_name="pull_request_records")
    op.drop_index("ix_pr_opportunity_id", table_name="pull_request_records")
    op.drop_table("pull_request_records")
