"""Add clearing_until column to opportunities.

Revision ID: b5c6d7e8f9a
Revises: a4b5c6d7e8f
Create Date: 2026-03-20

"""

import sqlalchemy as sa
from alembic import op

revision = "b5c6d7e8f9a"
down_revision = "a4b5c6d7e8f"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column(
        "opportunities",
        sa.Column("clearing_until", sa.DateTime(timezone=True), nullable=True),
    )
    op.add_column(
        "opportunities",
        sa.Column("clearing_pr_number", sa.Integer(), nullable=True),
    )
    op.add_column(
        "opportunities",
        sa.Column("clearing_repository", sa.String(512), nullable=True),
    )


def downgrade() -> None:
    op.drop_column("opportunities", "clearing_repository")
    op.drop_column("opportunities", "clearing_pr_number")
    op.drop_column("opportunities", "clearing_until")
