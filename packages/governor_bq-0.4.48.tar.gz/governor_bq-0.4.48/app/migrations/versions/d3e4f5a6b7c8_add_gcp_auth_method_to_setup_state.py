"""Add gcp_auth_method column to setup_state table.

Revision ID: d3e4f5a6b7c8
Revises: c2d3e4f5a6b7
Create Date: 2026-03-31
"""

from __future__ import annotations

import sqlalchemy as sa
from alembic import op

revision = "d3e4f5a6b7c8"
down_revision = "c2d3e4f5a6b7"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column(
        "setup_state",
        sa.Column(
            "gcp_auth_method",
            sa.String(16),
            nullable=False,
            server_default="json",
        ),
    )


def downgrade() -> None:
    op.drop_column("setup_state", "gcp_auth_method")
