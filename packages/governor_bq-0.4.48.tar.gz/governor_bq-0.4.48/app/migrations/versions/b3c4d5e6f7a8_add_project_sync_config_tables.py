"""add project sync config tables

Revision ID: b3c4d5e6f7a8
Revises: a1b2c3d4e5f6
Create Date: 2026-01-29 00:00:00.000000

"""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa

revision: str = "b3c4d5e6f7a8"
down_revision: Union[str, None] = "a1b2c3d4e5f6"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.create_table(
        "project_sync_configurations",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column("name", sa.String(255), nullable=False),
        sa.Column("gcp_project_id", sa.String(128), nullable=False),
        sa.Column("gcp_project_name", sa.String(255), nullable=True),
        sa.Column("github_repo", sa.String(512), nullable=True),
        sa.Column("status", sa.String(16), nullable=False, server_default="active"),
        sa.Column("version", sa.Integer, nullable=False, server_default="1"),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.func.now(),
        ),
        sa.Column(
            "created_by_id",
            sa.String(36),
            sa.ForeignKey("users.id"),
            nullable=False,
        ),
        sa.Column(
            "updated_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.func.now(),
        ),
        sa.Column(
            "updated_by_id",
            sa.String(36),
            sa.ForeignKey("users.id"),
            nullable=False,
        ),
    )
    op.create_index(
        "ix_psc_gcp_project_id",
        "project_sync_configurations",
        ["gcp_project_id"],
        unique=True,
    )
    op.create_index(
        "ix_psc_status",
        "project_sync_configurations",
        ["status"],
    )

    op.create_table(
        "manifest_locations",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column(
            "config_id",
            sa.String(36),
            sa.ForeignKey("project_sync_configurations.id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column("bucket_name", sa.String(222), nullable=False),
        sa.Column("path_prefix", sa.String(1024), nullable=False, server_default=""),
        sa.Column(
            "object_name",
            sa.String(255),
            nullable=False,
            server_default="manifest.json",
        ),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.func.now(),
        ),
        sa.Column(
            "created_by_id",
            sa.String(36),
            sa.ForeignKey("users.id"),
            nullable=False,
        ),
        sa.Column(
            "updated_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.func.now(),
        ),
        sa.Column(
            "updated_by_id",
            sa.String(36),
            sa.ForeignKey("users.id"),
            nullable=False,
        ),
    )
    op.create_index("ix_ml_config_id", "manifest_locations", ["config_id"])
    op.create_unique_constraint(
        "uq_ml_location",
        "manifest_locations",
        ["config_id", "bucket_name", "path_prefix", "object_name"],
    )


def downgrade() -> None:
    op.drop_table("manifest_locations")
    op.drop_table("project_sync_configurations")
