"""040 add dry run columns to solutions

Revision ID: d729508382f8
Revises: o6j7k8l9m0n1
Create Date: 2026-02-23 11:07:04.690486

"""

from __future__ import annotations

from alembic import op
import sqlalchemy as sa

from sqlalchemy.dialects import postgresql

revision = "d729508382f8"
down_revision = "o6j7k8l9m0n1"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column(
        "solutions",
        sa.Column(
            "dry_run_original", postgresql.JSONB(astext_type=sa.Text()), nullable=True
        ),
    )
    op.add_column(
        "solutions",
        sa.Column(
            "dry_run_modified", postgresql.JSONB(astext_type=sa.Text()), nullable=True
        ),
    )


def downgrade() -> None:
    op.drop_column("solutions", "dry_run_modified")
    op.drop_column("solutions", "dry_run_original")
