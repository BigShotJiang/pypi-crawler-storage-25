"""add rolling observation window

Revision ID: g8h9i0j1k2l3
Revises: f7a8b9c0d1e2
Create Date: 2026-02-10

Add rolling observation window support:
- Create opportunity_detection_history table
- Add occurrence_count, last_detected_at, consecutive_clean_days to opportunities
- Add lookback_window_days, resolution_period_days to manifest_configurations
"""

from __future__ import annotations

from alembic import op
import sqlalchemy as sa


revision = "g8h9i0j1k2l3"
down_revision = "f7a8b9c0d1e2"
branch_labels = None
depends_on = None


def upgrade() -> None:
    # =========================================================================
    # Step 1: Create opportunity_detection_history table
    # =========================================================================
    op.create_table(
        "opportunity_detection_history",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column(
            "opportunity_id",
            sa.String(36),
            sa.ForeignKey("opportunities.id"),
            nullable=False,
        ),
        sa.Column(
            "detection_job_id",
            sa.String(36),
            sa.ForeignKey("detection_jobs.id"),
            nullable=False,
        ),
        sa.Column("detected_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.func.now(),
        ),
    )
    op.create_index(
        "ix_odh_opportunity_id",
        "opportunity_detection_history",
        ["opportunity_id"],
    )
    op.create_index(
        "ix_odh_detected_at",
        "opportunity_detection_history",
        ["detected_at"],
    )
    op.create_index(
        "ix_odh_opp_detected",
        "opportunity_detection_history",
        ["opportunity_id", "detected_at"],
    )

    # =========================================================================
    # Step 2: Add rolling window fields to opportunities
    # =========================================================================
    op.add_column(
        "opportunities",
        sa.Column("occurrence_count", sa.Integer, nullable=False, server_default="0"),
    )
    op.add_column(
        "opportunities",
        sa.Column("last_detected_at", sa.DateTime(timezone=True), nullable=True),
    )
    op.add_column(
        "opportunities",
        sa.Column(
            "consecutive_clean_days", sa.Integer, nullable=False, server_default="0"
        ),
    )

    # Backfill last_detected_at for existing active opportunities
    op.execute(
        "UPDATE opportunities SET last_detected_at = updated_at WHERE status = 'active'"
    )

    # =========================================================================
    # Step 3: Add detection settings to manifest_configurations
    # =========================================================================
    op.add_column(
        "manifest_configurations",
        sa.Column("lookback_window_days", sa.Integer, nullable=True),
    )
    op.add_column(
        "manifest_configurations",
        sa.Column("resolution_period_days", sa.Integer, nullable=True),
    )


def downgrade() -> None:
    # Drop manifest_configurations columns
    op.drop_column("manifest_configurations", "resolution_period_days")
    op.drop_column("manifest_configurations", "lookback_window_days")

    # Drop opportunities columns
    op.drop_column("opportunities", "consecutive_clean_days")
    op.drop_column("opportunities", "last_detected_at")
    op.drop_column("opportunities", "occurrence_count")

    # Drop opportunity_detection_history table
    op.drop_index("ix_odh_opp_detected", table_name="opportunity_detection_history")
    op.drop_index("ix_odh_detected_at", table_name="opportunity_detection_history")
    op.drop_index("ix_odh_opportunity_id", table_name="opportunity_detection_history")
    op.drop_table("opportunity_detection_history")
