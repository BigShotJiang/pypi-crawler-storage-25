"""merge 005 opportunity detection with main theme preference

Revision ID: 58cd0a92e7e6
Revises: c1669eec184e, d5e6f7a8b9c0
Create Date: 2026-02-08 21:49:04.513004

"""

from __future__ import annotations


revision = "58cd0a92e7e6"
down_revision = ("c1669eec184e", "d5e6f7a8b9c0")
branch_labels = None
depends_on = None


def upgrade() -> None:
    pass


def downgrade() -> None:
    pass
