"""Merge process_cost branch with pr_fields branch.

Merges:
- a0b1c2d3e4f5 (add process_cost_usd to opportunities)
- d7e8f9a0b1c2 (add bigquery job workload kind, end of pr-fields branch)

Revision ID: b1c2d3e4f5a6
Revises: a0b1c2d3e4f5, d7e8f9a0b1c2
Create Date: 2026-03-30

"""

revision = "b1c2d3e4f5a6"
down_revision = ("a0b1c2d3e4f5", "d7e8f9a0b1c2")
branch_labels = None
depends_on = None


def upgrade() -> None:
    pass


def downgrade() -> None:
    pass
