"""Add sync scheduling columns to manifest_configurations and sync_operations.

Revision ID: k2f3g4h5i6j7
Revises: j1e2f3g4h5i6
Create Date: 2026-02-16
"""

from alembic import op
import sqlalchemy as sa


revision = "k2f3g4h5i6j7"
down_revision = "j1e2f3g4h5i6"
branch_labels = None
depends_on = None


def upgrade() -> None:
    # Add schedule columns to manifest_configurations
    op.add_column(
        "manifest_configurations",
        sa.Column(
            "schedule_type", sa.String(16), nullable=False, server_default="interval"
        ),
    )
    op.add_column(
        "manifest_configurations",
        sa.Column(
            "schedule_value", sa.String(128), nullable=False, server_default="24"
        ),
    )
    op.add_column(
        "manifest_configurations",
        sa.Column(
            "schedule_enabled",
            sa.Boolean(),
            nullable=False,
            server_default=sa.text("true"),
        ),
    )
    op.add_column(
        "manifest_configurations",
        sa.Column("schedule_last_run_at", sa.DateTime(timezone=True), nullable=True),
    )

    # Add triggered_by column to sync_operations
    op.add_column(
        "sync_operations",
        sa.Column(
            "triggered_by", sa.String(16), nullable=False, server_default="manual"
        ),
    )

    # Create indexes
    op.create_index(
        "ix_mc_schedule_enabled", "manifest_configurations", ["schedule_enabled"]
    )
    op.create_index("ix_sync_ops_triggered_by", "sync_operations", ["triggered_by"])

    # Data migration: set existing configs to disabled schedules (FR-015)
    op.execute(
        "UPDATE manifest_configurations SET schedule_type = 'interval', "
        "schedule_value = '24', schedule_enabled = false"
    )

    # Backfill existing sync operations
    op.execute("UPDATE sync_operations SET triggered_by = 'manual'")


def downgrade() -> None:
    op.drop_index("ix_sync_ops_triggered_by", table_name="sync_operations")
    op.drop_index("ix_mc_schedule_enabled", table_name="manifest_configurations")
    op.drop_column("sync_operations", "triggered_by")
    op.drop_column("manifest_configurations", "schedule_last_run_at")
    op.drop_column("manifest_configurations", "schedule_enabled")
    op.drop_column("manifest_configurations", "schedule_value")
    op.drop_column("manifest_configurations", "schedule_type")
