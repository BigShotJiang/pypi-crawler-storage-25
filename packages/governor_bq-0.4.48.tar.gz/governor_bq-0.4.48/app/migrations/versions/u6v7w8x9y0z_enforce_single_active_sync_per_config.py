"""Enforce a single active sync per configuration.

Revision ID: u6v7w8x9y0z
Revises: t1u2v3w4x5y
Create Date: 2026-03-10
"""

from alembic import op
import sqlalchemy as sa


revision = "u6v7w8x9y0z"
down_revision = "t1u2v3w4x5y"
branch_labels = None
depends_on = None


def upgrade():
    op.execute(
        """
        WITH ranked_active_syncs AS (
            SELECT
                id,
                ROW_NUMBER() OVER (
                    PARTITION BY config_id
                    ORDER BY
                        CASE status WHEN 'in_progress' THEN 0 ELSE 1 END,
                        COALESCE(started_at, queued_at) DESC,
                        queued_at DESC,
                        id DESC
                ) AS row_num
            FROM sync_operations
            WHERE status IN ('queued', 'in_progress')
        )
        UPDATE sync_operations
        SET
            status = 'failed',
            completed_at = COALESCE(completed_at, CURRENT_TIMESTAMP),
            updated_at = CURRENT_TIMESTAMP
        WHERE id IN (
            SELECT id
            FROM ranked_active_syncs
            WHERE row_num > 1
        )
        """
    )

    op.create_index(
        "uq_sync_ops_single_active_per_config",
        "sync_operations",
        ["config_id"],
        unique=True,
        postgresql_where=sa.text("status IN ('queued', 'in_progress')"),
        sqlite_where=sa.text("status IN ('queued', 'in_progress')"),
    )


def downgrade():
    op.drop_index("uq_sync_ops_single_active_per_config", table_name="sync_operations")
