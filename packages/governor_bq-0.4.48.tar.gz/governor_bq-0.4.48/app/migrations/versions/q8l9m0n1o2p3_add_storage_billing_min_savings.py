"""Add storage_billing_min_savings_usd to manifest_configurations.

Revision ID: q8l9m0n1o2p3
Revises: 9ab13d588378
Create Date: 2026-03-02
"""

from alembic import op
import sqlalchemy as sa


revision = "q8l9m0n1o2p3"
down_revision = "9ab13d588378"
branch_labels = None
depends_on = None


def upgrade():
    op.add_column(
        "manifest_configurations",
        sa.Column(
            "storage_billing_min_savings_usd",
            sa.Numeric(precision=12, scale=2),
            nullable=True,
        ),
    )


def downgrade():
    op.drop_column("manifest_configurations", "storage_billing_min_savings_usd")
