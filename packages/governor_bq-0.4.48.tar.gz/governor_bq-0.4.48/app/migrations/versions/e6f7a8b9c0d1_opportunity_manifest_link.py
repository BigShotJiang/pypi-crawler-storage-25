"""opportunity manifest link

Revision ID: e6f7a8b9c0d1
Revises: 58cd0a92e7e6
Create Date: 2026-02-09

Replace config_id on opportunities with manifest_location_id (NOT NULL)
and manifest_version_id (nullable). Includes data migration to map
existing opportunities to their manifest locations.
"""

from __future__ import annotations

from alembic import op
import sqlalchemy as sa


revision = "e6f7a8b9c0d1"
down_revision = "58cd0a92e7e6"
branch_labels = None
depends_on = None


def upgrade() -> None:
    # Step 1: Add new columns (nullable initially for data migration)
    op.add_column(
        "opportunities",
        sa.Column("manifest_location_id", sa.String(36), nullable=True),
    )
    op.add_column(
        "opportunities",
        sa.Column("manifest_version_id", sa.String(36), nullable=True),
    )

    # Step 2: Data migration — map config_id → manifest_location_id
    # For each opportunity, find the manifest_location via config_id
    op.execute(
        """
        UPDATE opportunities o
        SET manifest_location_id = (
            SELECT ml.id
            FROM manifest_locations ml
            WHERE ml.config_id = o.config_id
            ORDER BY ml.created_at ASC
            LIMIT 1
        )
        WHERE o.manifest_location_id IS NULL
        """
    )

    # Step 3: Set manifest_location_id to NOT NULL
    op.alter_column(
        "opportunities",
        "manifest_location_id",
        nullable=False,
    )

    # Step 4: Add FK constraints
    op.create_foreign_key(
        "fk_opp_manifest_location",
        "opportunities",
        "manifest_locations",
        ["manifest_location_id"],
        ["id"],
    )
    op.create_foreign_key(
        "fk_opp_manifest_version",
        "opportunities",
        "manifest_versions",
        ["manifest_version_id"],
        ["id"],
    )

    # Step 5: Drop old unique constraint
    op.drop_constraint("uq_opp_type_table_config", "opportunities", type_="unique")

    # Step 6: Add new unique constraint
    op.create_unique_constraint(
        "uq_opp_type_table_manifest",
        "opportunities",
        ["opportunity_type", "affected_table", "manifest_location_id"],
    )

    # Step 7: Drop old index, create new index
    op.drop_index("ix_opp_config_id", table_name="opportunities")
    op.create_index(
        "ix_opp_manifest_location_id",
        "opportunities",
        ["manifest_location_id"],
    )

    # Step 8: Drop config_id column
    op.drop_constraint(
        "opportunities_config_id_fkey",
        "opportunities",
        type_="foreignkey",
    )
    op.drop_column("opportunities", "config_id")


def downgrade() -> None:
    # Step 1: Add config_id back (nullable initially)
    op.add_column(
        "opportunities",
        sa.Column(
            "config_id",
            sa.String(36),
            nullable=True,
        ),
    )

    # Step 2: Data migration — derive config_id from manifest_location
    op.execute(
        """
        UPDATE opportunities o
        SET config_id = (
            SELECT ml.config_id
            FROM manifest_locations ml
            WHERE ml.id = o.manifest_location_id
        )
        """
    )

    # Step 3: Set config_id to NOT NULL
    op.alter_column("opportunities", "config_id", nullable=False)

    # Step 4: Restore FK on config_id
    op.create_foreign_key(
        "opportunities_config_id_fkey",
        "opportunities",
        "project_sync_configurations",
        ["config_id"],
        ["id"],
    )

    # Step 5: Restore old index
    op.create_index("ix_opp_config_id", "opportunities", ["config_id"])

    # Step 6: Drop new unique constraint, restore old one
    op.drop_constraint("uq_opp_type_table_manifest", "opportunities", type_="unique")
    op.create_unique_constraint(
        "uq_opp_type_table_config",
        "opportunities",
        ["opportunity_type", "affected_table", "config_id"],
    )

    # Step 7: Drop new index
    op.drop_index("ix_opp_manifest_location_id", table_name="opportunities")

    # Step 8: Drop new FK constraints
    op.drop_constraint("fk_opp_manifest_location", "opportunities", type_="foreignkey")
    op.drop_constraint("fk_opp_manifest_version", "opportunities", type_="foreignkey")

    # Step 9: Drop new columns
    op.drop_column("opportunities", "manifest_version_id")
    op.drop_column("opportunities", "manifest_location_id")
