"""Add local sync evidence metadata

Revision ID: j3k4l5m6n7o8
Revises: h2i3j4k5l6m7
Create Date: 2026-04-12
"""

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects.postgresql import JSONB

revision = "j3k4l5m6n7o8"
down_revision = "h2i3j4k5l6m7"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column(
        "sync_operations",
        sa.Column("local_evidence_mode", sa.String(32), nullable=True),
    )
    op.add_column(
        "sync_operations",
        sa.Column("matched_local_job_ids", JSONB, nullable=True),
    )
    op.add_column(
        "sync_operations",
        sa.Column("unmatched_local_job_ids", JSONB, nullable=True),
    )
    op.create_index(
        "ix_sync_operations_local_evidence_mode",
        "sync_operations",
        ["local_evidence_mode"],
        unique=False,
    )


def downgrade() -> None:
    op.drop_index("ix_sync_operations_local_evidence_mode", table_name="sync_operations")
    op.drop_column("sync_operations", "unmatched_local_job_ids")
    op.drop_column("sync_operations", "matched_local_job_ids")
    op.drop_column("sync_operations", "local_evidence_mode")
