"""Add solution_jobs and solutions tables for LLM-powered solution generation.

Revision ID: g8b9c0d1e2f3
Revises: f7a8b9c0d1e2
Create Date: 2026-02-10
"""

from alembic import op
import sqlalchemy as sa

revision = "g8b9c0d1e2f3"
down_revision = "g8h9i0j1k2l3"
branch_labels = None
depends_on = None


def upgrade() -> None:
    # --- solution_jobs table ---
    op.create_table(
        "solution_jobs",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column(
            "opportunity_id",
            sa.String(36),
            sa.ForeignKey("opportunities.id"),
            nullable=False,
        ),
        sa.Column(
            "detection_job_id",
            sa.String(36),
            sa.ForeignKey("detection_jobs.id"),
            nullable=True,
        ),
        sa.Column(
            "config_id",
            sa.String(36),
            sa.ForeignKey("manifest_configurations.id"),
            nullable=False,
        ),
        sa.Column("status", sa.String(16), nullable=False, server_default="queued"),
        sa.Column("resolution_category", sa.String(32), nullable=True),
        sa.Column(
            "queued_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.func.now(),
        ),
        sa.Column("started_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("completed_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("retry_count", sa.Integer(), nullable=False, server_default="0"),
        sa.Column(
            "lifetime_retry_count", sa.Integer(), nullable=False, server_default="0"
        ),
        sa.Column(
            "max_lifetime_retries", sa.Integer(), nullable=False, server_default="10"
        ),
        sa.Column("error_message", sa.Text(), nullable=True),
        sa.Column("error_stage", sa.String(32), nullable=True),
        sa.Column("llm_provider", sa.String(32), nullable=True),
        sa.Column("llm_model", sa.String(64), nullable=True),
        sa.Column("prompt_tokens", sa.Integer(), nullable=True),
        sa.Column("completion_tokens", sa.Integer(), nullable=True),
        sa.Column("llm_latency_ms", sa.Integer(), nullable=True),
        sa.Column(
            "solutions_generated_count",
            sa.Integer(),
            nullable=False,
            server_default="0",
        ),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.func.now(),
        ),
        sa.Column(
            "updated_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.func.now(),
        ),
        sa.CheckConstraint(
            "status IN ('queued', 'in_progress', 'completed', 'failed')",
            name="ck_sj_status",
        ),
        sa.CheckConstraint(
            "retry_count >= 0 AND retry_count <= 5",
            name="ck_sj_retry_count",
        ),
        sa.CheckConstraint(
            "resolution_category IS NULL OR resolution_category IN ('dbt_project_change', 'bigquery_infrastructure')",
            name="ck_sj_resolution_category",
        ),
        sa.CheckConstraint(
            "error_stage IS NULL OR error_stage IN ('github_retrieval', 'llm_request', 'response_parsing', 'storage')",
            name="ck_sj_error_stage",
        ),
    )
    op.create_index("ix_sj_status_queued_at", "solution_jobs", ["status", "queued_at"])
    op.create_index(
        "ix_solution_jobs_opportunity_id", "solution_jobs", ["opportunity_id"]
    )
    op.create_index("ix_solution_jobs_config_id", "solution_jobs", ["config_id"])
    op.create_index(
        "ix_solution_jobs_detection_job_id", "solution_jobs", ["detection_job_id"]
    )

    # --- solutions table ---
    op.create_table(
        "solutions",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column(
            "opportunity_id",
            sa.String(36),
            sa.ForeignKey("opportunities.id"),
            nullable=False,
        ),
        sa.Column(
            "solution_job_id",
            sa.String(36),
            sa.ForeignKey("solution_jobs.id"),
            nullable=False,
        ),
        sa.Column(
            "manifest_version_id",
            sa.String(36),
            sa.ForeignKey("manifest_versions.id"),
            nullable=True,
        ),
        sa.Column("resolution_category", sa.String(32), nullable=False),
        sa.Column("version_number", sa.Integer(), nullable=False, server_default="1"),
        # dbt project change fields
        sa.Column("file_path", sa.String(512), nullable=True),
        sa.Column("change_type", sa.String(32), nullable=True),
        sa.Column("before_content", sa.Text(), nullable=True),
        sa.Column("after_content", sa.Text(), nullable=True),
        sa.Column("repository", sa.String(256), nullable=True),
        sa.Column("commit_sha", sa.String(40), nullable=True),
        # BigQuery infrastructure fields
        sa.Column("current_setting_value", sa.Text(), nullable=True),
        sa.Column("recommended_setting_value", sa.Text(), nullable=True),
        sa.Column("affected_resource", sa.String(512), nullable=True),
        # Common fields
        sa.Column("explanation", sa.Text(), nullable=False),
        sa.Column("risk_level", sa.String(16), nullable=False),
        sa.Column("risk_justification", sa.Text(), nullable=False),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.func.now(),
        ),
        sa.Column(
            "updated_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.func.now(),
        ),
        sa.CheckConstraint(
            "resolution_category IN ('dbt_project_change', 'bigquery_infrastructure')",
            name="ck_sol_resolution_category",
        ),
        sa.CheckConstraint(
            "risk_level IN ('low', 'medium', 'high')",
            name="ck_sol_risk_level",
        ),
        sa.CheckConstraint(
            "change_type IS NULL OR change_type IN ('sql_change', 'project_config_change', 'schema_change')",
            name="ck_sol_change_type",
        ),
    )
    op.create_index("ix_solutions_opportunity_id", "solutions", ["opportunity_id"])
    op.create_index("ix_solutions_solution_job_id", "solutions", ["solution_job_id"])
    op.create_index(
        "ix_sol_opportunity_file_version",
        "solutions",
        ["opportunity_id", "file_path", "version_number"],
    )
    op.create_index("ix_sol_resolution_category", "solutions", ["resolution_category"])


def downgrade() -> None:
    op.drop_table("solutions")
    op.drop_table("solution_jobs")
