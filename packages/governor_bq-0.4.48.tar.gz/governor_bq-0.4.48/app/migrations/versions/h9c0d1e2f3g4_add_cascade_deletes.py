"""add cascade delete to foreign keys

Revision ID: h9c0d1e2f3g4
Revises: g8b9c0d1e2f3
Create Date: 2026-02-10
"""

from alembic import op

revision = "h9c0d1e2f3g4"
down_revision = "g8b9c0d1e2f3"
branch_labels = None
depends_on = None


# (table, constraint_name, column, referenced_table, on_delete)
FK_CHANGES = [
    # sync_operations.config_id -> manifest_configurations.id
    (
        "sync_operations",
        "sync_operations_config_id_fkey",
        ["config_id"],
        "manifest_configurations",
        ["id"],
        "CASCADE",
    ),
    # bigquery_jobs.config_id -> manifest_configurations.id
    (
        "bigquery_jobs",
        "bigquery_jobs_config_id_fkey",
        ["config_id"],
        "manifest_configurations",
        ["id"],
        "CASCADE",
    ),
    # bigquery_jobs.sync_id -> sync_operations.id
    (
        "bigquery_jobs",
        "bigquery_jobs_sync_id_fkey",
        ["sync_id"],
        "sync_operations",
        ["id"],
        "CASCADE",
    ),
    # manifest_versions.config_id -> manifest_configurations.id
    (
        "manifest_versions",
        "fk_mv_config",
        ["config_id"],
        "manifest_configurations",
        ["id"],
        "CASCADE",
    ),
    # manifest_versions.sync_id -> sync_operations.id
    (
        "manifest_versions",
        "manifest_versions_sync_id_fkey",
        ["sync_id"],
        "sync_operations",
        ["id"],
        "CASCADE",
    ),
    # detection_jobs.config_id -> manifest_configurations.id
    (
        "detection_jobs",
        "detection_jobs_config_id_fkey",
        ["config_id"],
        "manifest_configurations",
        ["id"],
        "CASCADE",
    ),
    # detection_jobs.sync_id -> sync_operations.id
    (
        "detection_jobs",
        "detection_jobs_sync_id_fkey",
        ["sync_id"],
        "sync_operations",
        ["id"],
        "CASCADE",
    ),
    # opportunities.config_id -> manifest_configurations.id
    (
        "opportunities",
        "fk_opp_config",
        ["config_id"],
        "manifest_configurations",
        ["id"],
        "CASCADE",
    ),
    # opportunities.manifest_version_id -> manifest_versions.id
    (
        "opportunities",
        "fk_opp_manifest_version",
        ["manifest_version_id"],
        "manifest_versions",
        ["id"],
        "SET NULL",
    ),
    # solution_jobs.opportunity_id -> opportunities.id
    (
        "solution_jobs",
        "solution_jobs_opportunity_id_fkey",
        ["opportunity_id"],
        "opportunities",
        ["id"],
        "CASCADE",
    ),
    # solution_jobs.detection_job_id -> detection_jobs.id
    (
        "solution_jobs",
        "solution_jobs_detection_job_id_fkey",
        ["detection_job_id"],
        "detection_jobs",
        ["id"],
        "SET NULL",
    ),
    # solution_jobs.config_id -> manifest_configurations.id
    (
        "solution_jobs",
        "solution_jobs_config_id_fkey",
        ["config_id"],
        "manifest_configurations",
        ["id"],
        "CASCADE",
    ),
    # solutions.opportunity_id -> opportunities.id
    (
        "solutions",
        "solutions_opportunity_id_fkey",
        ["opportunity_id"],
        "opportunities",
        ["id"],
        "CASCADE",
    ),
    # solutions.solution_job_id -> solution_jobs.id
    (
        "solutions",
        "solutions_solution_job_id_fkey",
        ["solution_job_id"],
        "solution_jobs",
        ["id"],
        "CASCADE",
    ),
    # solutions.manifest_version_id -> manifest_versions.id
    (
        "solutions",
        "solutions_manifest_version_id_fkey",
        ["manifest_version_id"],
        "manifest_versions",
        ["id"],
        "SET NULL",
    ),
]


def upgrade() -> None:
    for table, constraint, columns, ref_table, ref_columns, on_delete in FK_CHANGES:
        op.drop_constraint(constraint, table, type_="foreignkey")
        op.create_foreign_key(
            constraint,
            table,
            ref_table,
            columns,
            ref_columns,
            ondelete=on_delete,
        )


def downgrade() -> None:
    for table, constraint, columns, ref_table, ref_columns, _on_delete in FK_CHANGES:
        op.drop_constraint(constraint, table, type_="foreignkey")
        op.create_foreign_key(
            constraint,
            table,
            ref_table,
            columns,
            ref_columns,
        )
