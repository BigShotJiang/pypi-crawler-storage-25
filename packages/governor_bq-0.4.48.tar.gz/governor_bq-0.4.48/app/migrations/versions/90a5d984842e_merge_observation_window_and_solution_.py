"""merge observation window and solution tables branches

Revision ID: 90a5d984842e
Revises: g8h9i0j1k2l3, i0d1e2f3g4h5
Create Date: 2026-02-10 23:46:50.503726

"""

from __future__ import annotations


revision = "90a5d984842e"
down_revision = ("g8h9i0j1k2l3", "i0d1e2f3g4h5")
branch_labels = None
depends_on = None


def upgrade() -> None:
    pass


def downgrade() -> None:
    pass
