"""add opportunity detection tables

Revision ID: d5e6f7a8b9c0
Revises: c4d5e6f7a8b9
Create Date: 2026-02-04 00:00:00.000000

"""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

revision: str = "d5e6f7a8b9c0"
down_revision: Union[str, None] = "c4d5e6f7a8b9"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # Create detection_jobs table first (opportunities references it)
    op.create_table(
        "detection_jobs",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column(
            "config_id",
            sa.String(36),
            sa.ForeignKey("project_sync_configurations.id"),
            nullable=False,
        ),
        sa.Column(
            "sync_id",
            sa.String(36),
            sa.ForeignKey("sync_operations.id"),
            nullable=False,
            unique=True,
        ),
        sa.Column("status", sa.String(16), nullable=False, server_default="queued"),
        sa.Column(
            "queued_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.func.now(),
        ),
        sa.Column("started_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("completed_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column(
            "opportunities_found_count", sa.Integer, nullable=False, server_default="0"
        ),
        sa.Column(
            "opportunities_updated_count",
            sa.Integer,
            nullable=False,
            server_default="0",
        ),
        sa.Column(
            "opportunities_resolved_count",
            sa.Integer,
            nullable=False,
            server_default="0",
        ),
        sa.Column("retry_count", sa.Integer, nullable=False, server_default="0"),
        sa.Column("error_message", sa.Text, nullable=True),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.func.now(),
        ),
        sa.Column(
            "updated_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.func.now(),
        ),
        sa.CheckConstraint(
            "status IN ('queued', 'in_progress', 'completed', 'failed')",
            name="ck_det_status",
        ),
        sa.CheckConstraint(
            "retry_count >= 0 AND retry_count <= 3", name="ck_det_retry_count"
        ),
    )
    op.create_index("ix_det_config_id", "detection_jobs", ["config_id"])
    op.create_index(
        "ix_det_status_queued_at", "detection_jobs", ["status", "queued_at"]
    )
    op.create_index("ix_det_completed_at", "detection_jobs", ["completed_at"])

    # Create opportunities table
    op.create_table(
        "opportunities",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column(
            "config_id",
            sa.String(36),
            sa.ForeignKey("project_sync_configurations.id"),
            nullable=False,
        ),
        sa.Column("opportunity_type", sa.String(64), nullable=False),
        sa.Column("affected_table", sa.String(1024), nullable=False),
        sa.Column("status", sa.String(16), nullable=False, server_default="active"),
        sa.Column("severity_score", sa.Integer, nullable=False),
        sa.Column("evidence_snapshot", postgresql.JSONB, nullable=False),
        sa.Column("current_cost_estimate", sa.Numeric(10, 4), nullable=False),
        sa.Column("expected_savings", sa.Numeric(10, 4), nullable=False),
        sa.Column("explanation", sa.Text, nullable=False),
        sa.Column("related_job_ids", postgresql.JSONB, nullable=False),
        sa.Column("dbt_model_name", sa.String(256), nullable=True),
        sa.Column(
            "first_detection_job_id",
            sa.String(36),
            sa.ForeignKey("detection_jobs.id"),
            nullable=False,
        ),
        sa.Column(
            "last_detection_job_id",
            sa.String(36),
            sa.ForeignKey("detection_jobs.id"),
            nullable=True,
        ),
        sa.Column("resolved_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.func.now(),
        ),
        sa.Column(
            "updated_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.func.now(),
        ),
        sa.UniqueConstraint(
            "opportunity_type",
            "affected_table",
            "config_id",
            name="uq_opp_type_table_config",
        ),
        sa.CheckConstraint("status IN ('active', 'resolved')", name="ck_opp_status"),
        sa.CheckConstraint(
            "severity_score >= 1 AND severity_score <= 100",
            name="ck_opp_severity_range",
        ),
    )
    op.create_index("ix_opp_config_id", "opportunities", ["config_id"])
    op.create_index("ix_opp_status", "opportunities", ["status"])
    op.create_index("ix_opp_severity", "opportunities", ["severity_score"])
    op.create_index("ix_opp_resolved_at", "opportunities", ["resolved_at"])
    op.create_index(
        "ix_opp_evidence",
        "opportunities",
        ["evidence_snapshot"],
        postgresql_using="gin",
    )


def downgrade() -> None:
    op.drop_table("opportunities")
    op.drop_table("detection_jobs")
