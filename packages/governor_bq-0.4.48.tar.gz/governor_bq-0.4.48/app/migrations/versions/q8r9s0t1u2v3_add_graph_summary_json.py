"""Add graph_summary_json to sync_operations.

Revision ID: q8r9s0t1u2v3
Revises: p7k8l9m0n1o2
Create Date: 2026-04-13
"""

from collections.abc import Sequence

import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

from alembic import op

revision: str = "q8r9s0t1u2v3"
down_revision: str = "p7k8l9m0n1o2"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


def upgrade() -> None:
    op.add_column(
        "sync_operations",
        sa.Column("graph_summary_json", postgresql.JSONB, nullable=True),
    )


def downgrade() -> None:
    op.drop_column("sync_operations", "graph_summary_json")
