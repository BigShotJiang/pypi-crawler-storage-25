"""Add pr_lineage_impacts table for downstream lineage cost impact caching.

Revision ID: e4f5a6b7c8d9
Revises: d3e4f5a6b7c8
Create Date: 2026-03-31

"""

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects.postgresql import JSONB

revision = "e4f5a6b7c8d9"
down_revision = "d3e4f5a6b7c8"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "pr_lineage_impacts",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column(
            "pr_id",
            sa.String(36),
            sa.ForeignKey("pull_request_records.id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column(
            "manifest_version_id",
            sa.String(36),
            sa.ForeignKey("manifest_versions.id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column("affected_model_name", sa.String(512), nullable=False),
        sa.Column("affected_column", sa.String(256), nullable=False),
        sa.Column("change_type", sa.String(16), nullable=False),
        sa.Column(
            "total_estimated_savings",
            sa.Numeric(12, 4),
            nullable=False,
            server_default="0",
        ),
        sa.Column(
            "beneficiary_count", sa.Integer(), nullable=False, server_default="0"
        ),
        sa.Column(
            "total_downstream_count",
            sa.Integer(),
            nullable=False,
            server_default="0",
        ),
        sa.Column(
            "impact_results", JSONB(), nullable=False, server_default="[]"
        ),
        sa.Column("computed_at", sa.DateTime(timezone=True), nullable=False),
        sa.UniqueConstraint(
            "pr_id", "manifest_version_id", name="uq_pr_lineage_pr_manifest"
        ),
    )
    op.create_index(
        "ix_pr_lineage_impacts_pr_id", "pr_lineage_impacts", ["pr_id"]
    )


def downgrade() -> None:
    op.drop_index("ix_pr_lineage_impacts_pr_id", table_name="pr_lineage_impacts")
    op.drop_table("pr_lineage_impacts")
