"""Allow detection reruns against the latest completed sync.

Revision ID: v1w2x3y4z5a
Revises: u6v7w8x9y0z
Create Date: 2026-03-10
"""

from alembic import op
import sqlalchemy as sa


revision = "v1w2x3y4z5a"
down_revision = "u6v7w8x9y0z"
branch_labels = None
depends_on = None


def upgrade():
    bind = op.get_bind()
    inspector = sa.inspect(bind)
    for constraint in inspector.get_unique_constraints("detection_jobs"):
        columns = tuple(constraint.get("column_names") or ())
        if columns == ("sync_id",) and constraint.get("name"):
            op.drop_constraint(
                constraint["name"],
                "detection_jobs",
                type_="unique",
            )

    op.create_index(
        "uq_det_jobs_active_sync",
        "detection_jobs",
        ["sync_id"],
        unique=True,
        postgresql_where=sa.text("status IN ('queued', 'in_progress')"),
        sqlite_where=sa.text("status IN ('queued', 'in_progress')"),
    )


def downgrade():
    op.drop_index("uq_det_jobs_active_sync", table_name="detection_jobs")
    op.create_unique_constraint(
        "detection_jobs_sync_id_key",
        "detection_jobs",
        ["sync_id"],
    )
