"""Add allowed_solution_policy_tags to manifest_configurations.

Revision ID: t1u2v3w4x5y
Revises: s0p1q2r3s4t5
Create Date: 2026-03-04
"""

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql


revision = "t1u2v3w4x5y"
down_revision = "s0p1q2r3s4t5"
branch_labels = None
depends_on = None


def upgrade():
    op.add_column(
        "manifest_configurations",
        sa.Column(
            "allowed_solution_policy_tags",
            postgresql.JSONB(astext_type=sa.Text()),
            nullable=True,
        ),
    )


def downgrade():
    op.drop_column("manifest_configurations", "allowed_solution_policy_tags")
