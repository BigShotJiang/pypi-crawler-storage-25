"""Make PR record fields nullable for collected PRs.

Revision ID: a4b5c6d7e8f
Revises: z3a4b5c6d7e
Create Date: 2026-03-20

"""

from alembic import op
import sqlalchemy as sa

revision = "a4b5c6d7e8f"
down_revision = "z3a4b5c6d7e"
branch_labels = None
depends_on = None


def upgrade() -> None:
    # Make opportunity_id, solution_id, created_by nullable
    op.alter_column(
        "pull_request_records",
        "opportunity_id",
        existing_type=sa.String(36),
        nullable=True,
    )
    op.alter_column(
        "pull_request_records",
        "solution_id",
        existing_type=sa.String(36),
        nullable=True,
    )
    op.alter_column(
        "pull_request_records",
        "created_by",
        existing_type=sa.String(36),
        nullable=True,
    )

    # Drop the old unique constraint on opportunity_id
    op.drop_constraint("uq_pr_opportunity_id", "pull_request_records", type_="unique")
    op.drop_index("ix_pr_opportunity_id", table_name="pull_request_records")

    # Add partial unique index on opportunity_id (only non-null values)
    op.execute(
        "CREATE UNIQUE INDEX ix_pr_opportunity_id ON pull_request_records (opportunity_id) "
        "WHERE opportunity_id IS NOT NULL"
    )

    # Add unique constraint on (repository, pr_number)
    op.create_unique_constraint(
        "uq_pr_repo_number",
        "pull_request_records",
        ["repository", "pr_number"],
    )


def downgrade() -> None:
    op.drop_constraint("uq_pr_repo_number", "pull_request_records", type_="unique")
    op.drop_index("ix_pr_opportunity_id", table_name="pull_request_records")
    op.create_index(
        "ix_pr_opportunity_id",
        "pull_request_records",
        ["opportunity_id"],
        unique=True,
    )
    op.create_unique_constraint(
        "uq_pr_opportunity_id",
        "pull_request_records",
        ["opportunity_id"],
    )
    op.alter_column(
        "pull_request_records",
        "created_by",
        existing_type=sa.String(36),
        nullable=False,
    )
    op.alter_column(
        "pull_request_records",
        "solution_id",
        existing_type=sa.String(36),
        nullable=False,
    )
    op.alter_column(
        "pull_request_records",
        "opportunity_id",
        existing_type=sa.String(36),
        nullable=False,
    )
