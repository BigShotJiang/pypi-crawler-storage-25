"""merge 036 and 040 heads

Revision ID: 9ab13d588378
Revises: d729508382f8, p7k8l9m0n1o2
Create Date: 2026-02-24 11:55:58.443436

"""

from __future__ import annotations


revision = "9ab13d588378"
down_revision = ("d729508382f8", "p7k8l9m0n1o2")
branch_labels = None
depends_on = None


def upgrade() -> None:
    pass


def downgrade() -> None:
    pass
