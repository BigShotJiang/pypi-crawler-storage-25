"""flatten manifest configuration

Revision ID: f7a8b9c0d1e2
Revises: e6f7a8b9c0d1
Create Date: 2026-02-09

Flatten the hierarchical model (ProjectSyncConfiguration + ManifestLocation)
into a single ManifestConfiguration entity.

- Add bucket_name, path_prefix, object_name columns to project_sync_configurations
- Populate manifest fields from primary ManifestLocation per config
- Insert new rows for secondary ManifestLocations (using ML.id as new row ID)
- Update opportunities.manifest_location_id for primary MLs to point to parent PSC.id
- Add used_manifest_version_id column to sync_operations
- Rename manifest_location_id -> config_id on opportunities and manifest_versions
- Set status=disabled where github_repo is null
- Rename table project_sync_configurations -> manifest_configurations
- Drop manifest_locations table
- Drop sync_manifest_versions table
- Remove unique constraint on gcp_project_id
- Add unique constraint on (bucket_name, path_prefix, object_name)
"""

from __future__ import annotations

from alembic import op
import sqlalchemy as sa


revision = "f7a8b9c0d1e2"
down_revision = "e6f7a8b9c0d1"
branch_labels = None
depends_on = None


def upgrade() -> None:
    # =========================================================================
    # Step 1: Add manifest fields to project_sync_configurations
    # =========================================================================
    op.add_column(
        "project_sync_configurations",
        sa.Column("bucket_name", sa.String(222), nullable=True),
    )
    op.add_column(
        "project_sync_configurations",
        sa.Column("path_prefix", sa.String(1024), nullable=True, server_default=""),
    )
    op.add_column(
        "project_sync_configurations",
        sa.Column(
            "object_name", sa.String(255), nullable=True, server_default="manifest.json"
        ),
    )

    # =========================================================================
    # Step 2: Populate manifest fields from primary ManifestLocation
    # (first ML per config, ordered by created_at)
    # =========================================================================
    op.execute(
        """
        UPDATE project_sync_configurations psc
        SET bucket_name = ml.bucket_name,
            path_prefix = ml.path_prefix,
            object_name = ml.object_name
        FROM (
            SELECT DISTINCT ON (config_id) config_id, bucket_name, path_prefix, object_name
            FROM manifest_locations
            ORDER BY config_id, created_at ASC
        ) ml
        WHERE psc.id = ml.config_id
        """
    )

    # =========================================================================
    # Step 3: Insert new rows for secondary ManifestLocations
    # Each secondary ML becomes its own config row with ML.id as the new row ID
    # =========================================================================
    op.execute(
        """
        INSERT INTO project_sync_configurations (
            id, name, gcp_project_id, gcp_project_name, github_repo,
            bucket_name, path_prefix, object_name,
            status, version, created_at, created_by_id, updated_at, updated_by_id
        )
        SELECT
            ml.id,
            psc.name || ' / ' || ml.path_prefix,
            psc.gcp_project_id,
            psc.gcp_project_name,
            psc.github_repo,
            ml.bucket_name,
            ml.path_prefix,
            ml.object_name,
            CASE WHEN psc.github_repo IS NULL THEN 'disabled' ELSE psc.status END,
            1,
            ml.created_at,
            ml.created_by_id,
            ml.updated_at,
            ml.updated_by_id
        FROM manifest_locations ml
        JOIN project_sync_configurations psc ON ml.config_id = psc.id
        WHERE ml.id NOT IN (
            SELECT DISTINCT ON (config_id) id
            FROM manifest_locations
            ORDER BY config_id, created_at ASC
        )
        """
    )

    # =========================================================================
    # Step 3b: Drop FK constraints that reference manifest_locations BEFORE
    # updating data, so that re-pointing IDs to PSC.id doesn't violate FKs
    # =========================================================================
    op.drop_constraint("fk_opp_manifest_location", "opportunities", type_="foreignkey")
    op.drop_constraint(
        "manifest_versions_manifest_location_id_fkey",
        "manifest_versions",
        type_="foreignkey",
    )

    # =========================================================================
    # Step 4: Update opportunities.manifest_location_id for PRIMARY MLs
    # Primary ML's opportunities need to point to the parent PSC.id
    # (since the primary ML's fields were absorbed into the parent PSC row)
    # =========================================================================
    op.execute(
        """
        UPDATE opportunities o
        SET manifest_location_id = ml.config_id
        FROM (
            SELECT DISTINCT ON (config_id) id, config_id
            FROM manifest_locations
            ORDER BY config_id, created_at ASC
        ) ml
        WHERE o.manifest_location_id = ml.id
        """
    )

    # =========================================================================
    # Step 5: Update manifest_versions.manifest_location_id for PRIMARY MLs
    # Same logic: primary ML versions now belong to the parent config
    # =========================================================================
    op.execute(
        """
        UPDATE manifest_versions mv
        SET manifest_location_id = ml.config_id
        FROM (
            SELECT DISTINCT ON (config_id) id, config_id
            FROM manifest_locations
            ORDER BY config_id, created_at ASC
        ) ml
        WHERE mv.manifest_location_id = ml.id
        """
    )

    # =========================================================================
    # Step 6: Add used_manifest_version_id to sync_operations
    # Populate from sync_manifest_versions junction table
    # =========================================================================
    op.add_column(
        "sync_operations",
        sa.Column("used_manifest_version_id", sa.String(36), nullable=True),
    )
    # Populate from junction table (take the first/only manifest version per sync)
    op.execute(
        """
        UPDATE sync_operations so
        SET used_manifest_version_id = smv.manifest_version_id
        FROM (
            SELECT DISTINCT ON (sync_id) sync_id, manifest_version_id
            FROM sync_manifest_versions
            ORDER BY sync_id
        ) smv
        WHERE so.id = smv.sync_id
        """
    )
    # Add FK after populating
    op.create_foreign_key(
        "fk_sync_ops_used_manifest_version",
        "sync_operations",
        "manifest_versions",
        ["used_manifest_version_id"],
        ["id"],
    )

    # =========================================================================
    # Step 7: Handle configs without manifest locations
    # Set empty manifest fields and disable
    # =========================================================================
    op.execute(
        """
        UPDATE project_sync_configurations
        SET bucket_name = '',
            path_prefix = '',
            object_name = 'manifest.json',
            status = 'disabled'
        WHERE bucket_name IS NULL
        """
    )

    # =========================================================================
    # Step 8: Set status=disabled for configs without github_repo
    # =========================================================================
    op.execute(
        """
        UPDATE project_sync_configurations
        SET status = 'disabled'
        WHERE github_repo IS NULL OR github_repo = ''
        """
    )

    # =========================================================================
    # Step 9: Make manifest fields NOT NULL
    # =========================================================================
    op.alter_column("project_sync_configurations", "bucket_name", nullable=False)
    op.alter_column("project_sync_configurations", "path_prefix", nullable=False)
    op.alter_column("project_sync_configurations", "object_name", nullable=False)

    # =========================================================================
    # Step 10: Rename FK columns on opportunities and manifest_versions
    # manifest_location_id -> config_id
    # =========================================================================

    # -- opportunities --
    # FK already dropped in Step 3b; drop old index and unique constraint
    op.drop_index("ix_opp_manifest_location_id", table_name="opportunities")
    op.drop_constraint("uq_opp_type_table_manifest", "opportunities", type_="unique")

    # Rename column
    op.alter_column(
        "opportunities",
        "manifest_location_id",
        new_column_name="config_id",
    )

    # Create new FK, index, and unique constraint
    op.create_foreign_key(
        "fk_opp_config",
        "opportunities",
        "project_sync_configurations",
        ["config_id"],
        ["id"],
    )
    op.create_index("ix_opp_config_id", "opportunities", ["config_id"])
    op.create_unique_constraint(
        "uq_opp_type_table_config",
        "opportunities",
        ["opportunity_type", "affected_table", "config_id"],
    )

    # -- manifest_versions --
    # FK already dropped in Step 3b; drop old indexes
    op.drop_index("ix_manifest_versions_location_id", table_name="manifest_versions")
    op.drop_index("ix_manifest_versions_hash", table_name="manifest_versions")

    # Rename column
    op.alter_column(
        "manifest_versions",
        "manifest_location_id",
        new_column_name="config_id",
    )

    # Create new FK, index
    op.create_foreign_key(
        "fk_mv_config",
        "manifest_versions",
        "project_sync_configurations",
        ["config_id"],
        ["id"],
        ondelete="CASCADE",
    )
    op.create_index(
        "ix_manifest_versions_config_id", "manifest_versions", ["config_id"]
    )
    op.create_index(
        "ix_manifest_versions_hash",
        "manifest_versions",
        ["config_id", "content_hash"],
    )

    # =========================================================================
    # Step 11: Drop sync_manifest_versions junction table
    # =========================================================================
    op.drop_table("sync_manifest_versions")

    # =========================================================================
    # Step 12: Drop manifest_locations table
    # =========================================================================
    op.drop_table("manifest_locations")

    # =========================================================================
    # Step 13: Remove unique constraint on gcp_project_id
    # =========================================================================
    op.drop_index("ix_psc_gcp_project_id", table_name="project_sync_configurations")
    op.create_index(
        "ix_mc_gcp_project_id",
        "project_sync_configurations",
        ["gcp_project_id"],
    )

    # =========================================================================
    # Step 14: Rename table project_sync_configurations -> manifest_configurations
    # =========================================================================
    # Drop old status index first (will recreate with new name)
    op.drop_index("ix_psc_status", table_name="project_sync_configurations")

    op.rename_table("project_sync_configurations", "manifest_configurations")

    # Recreate indexes with new naming convention
    op.create_index("ix_mc_status", "manifest_configurations", ["status"])

    # =========================================================================
    # Step 15: Add unique constraint on manifest location
    # =========================================================================
    op.create_unique_constraint(
        "uq_mc_manifest_location",
        "manifest_configurations",
        ["bucket_name", "path_prefix", "object_name"],
    )

    # =========================================================================
    # Step 16: Update FK references to point to renamed table
    # sync_operations.config_id, bigquery_jobs.config_id, detection_jobs.config_id
    # These FKs automatically follow the table rename in PostgreSQL.
    # The opportunities and manifest_versions FKs were already recreated above.
    # =========================================================================


def downgrade() -> None:
    # =========================================================================
    # Reverse Step 15: Drop unique constraint on manifest location
    # =========================================================================
    op.drop_constraint(
        "uq_mc_manifest_location", "manifest_configurations", type_="unique"
    )

    # =========================================================================
    # Reverse Step 14: Rename table back
    # =========================================================================
    op.drop_index("ix_mc_status", table_name="manifest_configurations")
    op.rename_table("manifest_configurations", "project_sync_configurations")
    op.create_index("ix_psc_status", "project_sync_configurations", ["status"])

    # =========================================================================
    # Reverse Step 13: Restore unique index on gcp_project_id
    # =========================================================================
    op.drop_index("ix_mc_gcp_project_id", table_name="project_sync_configurations")
    op.create_index(
        "ix_psc_gcp_project_id",
        "project_sync_configurations",
        ["gcp_project_id"],
        unique=True,
    )

    # =========================================================================
    # Reverse Step 12: Recreate manifest_locations table
    # =========================================================================
    op.create_table(
        "manifest_locations",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column(
            "config_id",
            sa.String(36),
            sa.ForeignKey("project_sync_configurations.id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column("bucket_name", sa.String(222), nullable=False),
        sa.Column("path_prefix", sa.String(1024), nullable=False, server_default=""),
        sa.Column(
            "object_name",
            sa.String(255),
            nullable=False,
            server_default="manifest.json",
        ),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.func.now(),
        ),
        sa.Column(
            "created_by_id",
            sa.String(36),
            sa.ForeignKey("users.id"),
            nullable=False,
        ),
        sa.Column(
            "updated_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.func.now(),
        ),
        sa.Column(
            "updated_by_id",
            sa.String(36),
            sa.ForeignKey("users.id"),
            nullable=False,
        ),
    )
    op.create_index("ix_ml_config_id", "manifest_locations", ["config_id"])
    op.create_unique_constraint(
        "uq_ml_location",
        "manifest_locations",
        ["config_id", "bucket_name", "path_prefix", "object_name"],
    )

    # =========================================================================
    # Reverse Step 11: Recreate sync_manifest_versions junction table
    # =========================================================================
    op.create_table(
        "sync_manifest_versions",
        sa.Column(
            "sync_id",
            sa.String(36),
            sa.ForeignKey("sync_operations.id", ondelete="CASCADE"),
            primary_key=True,
        ),
        sa.Column(
            "manifest_version_id",
            sa.String(36),
            sa.ForeignKey("manifest_versions.id", ondelete="CASCADE"),
            primary_key=True,
        ),
    )
    op.create_index(
        "ix_sync_manifest_versions_manifest",
        "sync_manifest_versions",
        ["manifest_version_id"],
    )

    # =========================================================================
    # Reverse Step 10: Rename config_id back to manifest_location_id
    # =========================================================================

    # -- manifest_versions --
    op.drop_constraint("fk_mv_config", "manifest_versions", type_="foreignkey")
    op.drop_index("ix_manifest_versions_config_id", table_name="manifest_versions")
    op.drop_index("ix_manifest_versions_hash", table_name="manifest_versions")

    op.alter_column(
        "manifest_versions",
        "config_id",
        new_column_name="manifest_location_id",
    )

    op.create_foreign_key(
        "manifest_versions_manifest_location_id_fkey",
        "manifest_versions",
        "manifest_locations",
        ["manifest_location_id"],
        ["id"],
        ondelete="CASCADE",
    )
    op.create_index(
        "ix_manifest_versions_location_id",
        "manifest_versions",
        ["manifest_location_id"],
    )
    op.create_index(
        "ix_manifest_versions_hash",
        "manifest_versions",
        ["manifest_location_id", "content_hash"],
    )

    # -- opportunities --
    op.drop_constraint("fk_opp_config", "opportunities", type_="foreignkey")
    op.drop_index("ix_opp_config_id", table_name="opportunities")
    op.drop_constraint("uq_opp_type_table_config", "opportunities", type_="unique")

    op.alter_column(
        "opportunities",
        "config_id",
        new_column_name="manifest_location_id",
    )

    op.create_foreign_key(
        "fk_opp_manifest_location",
        "opportunities",
        "manifest_locations",
        ["manifest_location_id"],
        ["id"],
    )
    op.create_index(
        "ix_opp_manifest_location_id",
        "opportunities",
        ["manifest_location_id"],
    )
    op.create_unique_constraint(
        "uq_opp_type_table_manifest",
        "opportunities",
        ["opportunity_type", "affected_table", "manifest_location_id"],
    )

    # =========================================================================
    # Reverse Step 9: Make manifest fields nullable again (for drop)
    # =========================================================================
    # No need — we're about to drop the columns

    # =========================================================================
    # Reverse Step 6: Drop used_manifest_version_id from sync_operations
    # (populate junction table from it first)
    # =========================================================================
    op.execute(
        """
        INSERT INTO sync_manifest_versions (sync_id, manifest_version_id)
        SELECT id, used_manifest_version_id
        FROM sync_operations
        WHERE used_manifest_version_id IS NOT NULL
        """
    )
    op.drop_constraint(
        "fk_sync_ops_used_manifest_version",
        "sync_operations",
        type_="foreignkey",
    )
    op.drop_column("sync_operations", "used_manifest_version_id")

    # =========================================================================
    # Reverse Steps 1-5: Create ManifestLocations from flattened configs
    # For primary configs: create ML with config_id = PSC.id
    # For secondary configs (expanded from MLs): move their rows back
    # NOTE: Perfect reversal is complex. This creates one ML per config.
    # =========================================================================
    op.execute(
        """
        INSERT INTO manifest_locations (
            id, config_id, bucket_name, path_prefix, object_name,
            created_at, created_by_id, updated_at, updated_by_id
        )
        SELECT
            id, id, bucket_name, path_prefix, object_name,
            created_at, created_by_id, updated_at, updated_by_id
        FROM project_sync_configurations
        WHERE bucket_name IS NOT NULL AND bucket_name != ''
        """
    )

    # Update opportunities to point to manifest_locations
    op.execute(
        """
        UPDATE opportunities
        SET manifest_location_id = config_id
        WHERE manifest_location_id IS NOT NULL
        """
    )

    # Update manifest_versions to point to manifest_locations
    op.execute(
        """
        UPDATE manifest_versions
        SET manifest_location_id = config_id
        WHERE manifest_location_id IS NOT NULL
        """
    )

    # =========================================================================
    # Reverse Step 1: Drop manifest fields from project_sync_configurations
    # =========================================================================
    op.drop_column("project_sync_configurations", "object_name")
    op.drop_column("project_sync_configurations", "path_prefix")
    op.drop_column("project_sync_configurations", "bucket_name")

    # =========================================================================
    # Delete secondary config rows (expanded from ManifestLocations)
    # These have IDs that now exist in manifest_locations
    # NOTE: In a perfect downgrade, we'd identify and remove them.
    # For safety, we leave them — the downgrade is best-effort.
    # =========================================================================
