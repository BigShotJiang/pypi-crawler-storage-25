"""Enforce active solution job uniqueness and preserve PR history.

Revision ID: c6d7e8f9a0b1
Revises: b5c6d7e8f9a
Create Date: 2026-03-23

"""

from alembic import op
import sqlalchemy as sa


revision = "c6d7e8f9a0b1"
down_revision = "b5c6d7e8f9a"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.execute(
        """
        WITH ranked_active_jobs AS (
            SELECT
                id,
                ROW_NUMBER() OVER (
                    PARTITION BY opportunity_id
                    ORDER BY
                        CASE status WHEN 'in_progress' THEN 0 ELSE 1 END,
                        COALESCE(started_at, queued_at) DESC,
                        queued_at DESC,
                        id DESC
                ) AS row_num
            FROM solution_jobs
            WHERE status IN ('queued', 'in_progress')
        )
        UPDATE solution_jobs
        SET
            status = 'failed',
            error_message = COALESCE(
                error_message,
                'Marked failed during migration to enforce one active job per opportunity.'
            ),
            error_stage = COALESCE(error_stage, 'storage'),
            completed_at = COALESCE(completed_at, CURRENT_TIMESTAMP),
            updated_at = CURRENT_TIMESTAMP
        WHERE id IN (
            SELECT id
            FROM ranked_active_jobs
            WHERE row_num > 1
        )
        """
    )

    op.create_index(
        "uq_solution_jobs_active_opportunity",
        "solution_jobs",
        ["opportunity_id"],
        unique=True,
        postgresql_where=sa.text("status IN ('queued', 'in_progress')"),
        sqlite_where=sa.text("status IN ('queued', 'in_progress')"),
    )

    op.drop_constraint(
        "pull_request_records_opportunity_id_fkey",
        "pull_request_records",
        type_="foreignkey",
    )
    op.drop_constraint(
        "pull_request_records_solution_id_fkey",
        "pull_request_records",
        type_="foreignkey",
    )
    op.create_foreign_key(
        "pull_request_records_opportunity_id_fkey",
        "pull_request_records",
        "opportunities",
        ["opportunity_id"],
        ["id"],
        ondelete="SET NULL",
    )
    op.create_foreign_key(
        "pull_request_records_solution_id_fkey",
        "pull_request_records",
        "solutions",
        ["solution_id"],
        ["id"],
        ondelete="SET NULL",
    )


def downgrade() -> None:
    op.drop_constraint(
        "pull_request_records_solution_id_fkey",
        "pull_request_records",
        type_="foreignkey",
    )
    op.drop_constraint(
        "pull_request_records_opportunity_id_fkey",
        "pull_request_records",
        type_="foreignkey",
    )
    op.create_foreign_key(
        "pull_request_records_opportunity_id_fkey",
        "pull_request_records",
        "opportunities",
        ["opportunity_id"],
        ["id"],
        ondelete="CASCADE",
    )
    op.create_foreign_key(
        "pull_request_records_solution_id_fkey",
        "pull_request_records",
        "solutions",
        ["solution_id"],
        ["id"],
        ondelete="CASCADE",
    )

    op.drop_index("uq_solution_jobs_active_opportunity", table_name="solution_jobs")
