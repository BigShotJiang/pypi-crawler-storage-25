"""Add cached latest-solution snapshot fields to opportunities.

Revision ID: w7x8y9z0a1b
Revises: v1w2x3y4z5a
Create Date: 2026-03-11 22:55:00.000000
"""

from __future__ import annotations

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = "w7x8y9z0a1b"
down_revision = "v1w2x3y4z5a"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column(
        "opportunities",
        sa.Column("latest_solution_id", sa.String(length=36), nullable=True),
    )
    op.add_column(
        "opportunities",
        sa.Column("latest_solution_risk_level", sa.String(length=16), nullable=True),
    )
    op.add_column(
        "opportunities",
        sa.Column("latest_solution_trust_tier", sa.String(length=16), nullable=True),
    )
    op.add_column(
        "opportunities",
        sa.Column(
            "latest_solution_dry_run_original_cost",
            sa.Numeric(precision=18, scale=6),
            nullable=True,
        ),
    )
    op.add_column(
        "opportunities",
        sa.Column(
            "latest_solution_dry_run_modified_cost",
            sa.Numeric(precision=18, scale=6),
            nullable=True,
        ),
    )
    op.add_column(
        "opportunities",
        sa.Column(
            "latest_solution_cached_at", sa.DateTime(timezone=True), nullable=True
        ),
    )
    op.create_index(
        "ix_opportunities_latest_solution_id",
        "opportunities",
        ["latest_solution_id"],
        unique=False,
    )
    op.create_foreign_key(
        "fk_opportunities_latest_solution_id",
        "opportunities",
        "solutions",
        ["latest_solution_id"],
        ["id"],
        ondelete="SET NULL",
    )

    op.execute(
        """
        WITH ranked AS (
            SELECT
                s.opportunity_id,
                s.id,
                s.risk_level,
                s.trust_tier,
                CAST(s.dry_run_original->>'estimated_cost_usd' AS NUMERIC(18, 6)) AS dry_run_original_cost,
                CAST(s.dry_run_modified->>'estimated_cost_usd' AS NUMERIC(18, 6)) AS dry_run_modified_cost,
                ROW_NUMBER() OVER (
                    PARTITION BY s.opportunity_id
                    ORDER BY
                        s.version_number DESC,
                        s.created_at DESC,
                        s.updated_at DESC,
                        s.id DESC
                ) AS rn
            FROM solutions AS s
        )
        UPDATE opportunities AS o
        SET
            latest_solution_id = ranked.id,
            latest_solution_risk_level = ranked.risk_level,
            latest_solution_trust_tier = ranked.trust_tier,
            latest_solution_dry_run_original_cost = ranked.dry_run_original_cost,
            latest_solution_dry_run_modified_cost = ranked.dry_run_modified_cost,
            latest_solution_cached_at = NOW()
        FROM ranked
        WHERE o.id = ranked.opportunity_id
          AND ranked.rn = 1
        """
    )


def downgrade() -> None:
    op.drop_constraint(
        "fk_opportunities_latest_solution_id",
        "opportunities",
        type_="foreignkey",
    )
    op.drop_index("ix_opportunities_latest_solution_id", table_name="opportunities")
    op.drop_column("opportunities", "latest_solution_cached_at")
    op.drop_column("opportunities", "latest_solution_dry_run_modified_cost")
    op.drop_column("opportunities", "latest_solution_dry_run_original_cost")
    op.drop_column("opportunities", "latest_solution_trust_tier")
    op.drop_column("opportunities", "latest_solution_risk_level")
    op.drop_column("opportunities", "latest_solution_id")
