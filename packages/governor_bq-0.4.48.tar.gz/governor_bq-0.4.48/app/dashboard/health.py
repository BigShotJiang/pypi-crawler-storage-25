"""Health score calculation for project optimization views.

Implements a weighted penalty formula:
  score = 100 - penalty
  penalty = severity_penalty (60%) + cost_risk_penalty (30%) + critical_penalty (10%)

Thresholds:
  - 80-100: good (green)
  - 50-79: moderate (amber)
  - 0-49: poor (red)
"""

from __future__ import annotations

from decimal import Decimal


def calculate_health_score(
    opportunities: list[dict],
    cost_at_risk: Decimal,
    total_spend: Decimal,
) -> int:
    """Calculate a health score (0-100) for a project.

    Args:
        opportunities: List of dicts with 'severity_score' (int 1-100).
        cost_at_risk: Sum of current_cost_estimate for active opportunities.
        total_spend: Total BigQuery spend for the project in the time window.

    Returns:
        Integer score clamped to 0-100.
    """
    if not opportunities:
        return 100

    # Severity penalty (60%): average severity normalised to 0-60
    avg_severity = sum(o["severity_score"] for o in opportunities) / len(opportunities)
    severity_penalty = (avg_severity / 100) * 60

    # Cost-at-risk penalty (30%): ratio of cost_at_risk to total_spend * 30
    cost_ratio = 0.0
    if total_spend > 0:
        cost_ratio = float(cost_at_risk / total_spend)
    cost_risk_penalty = min(cost_ratio, 1.0) * 30

    # Critical issues penalty (10%): proportion of critical issues (severity >= 70)
    critical_count = sum(1 for o in opportunities if o["severity_score"] >= 70)
    critical_ratio = critical_count / len(opportunities)
    critical_penalty = critical_ratio * 10

    penalty = severity_penalty + cost_risk_penalty + critical_penalty
    score = 100 - penalty

    return max(0, min(100, round(score)))


def get_status(score: int) -> str:
    """Map a health score to a status label.

    Returns:
        'good' (80-100), 'moderate' (50-79), or 'poor' (0-49).
    """
    if score >= 80:
        return "good"
    if score >= 50:
        return "moderate"
    return "poor"
