"""
Cost Analytics Dashboard module.

Provides aggregated views of BigQuery costs, trends, and optimization opportunities.
"""

from app.dashboard.service import DashboardService
from app.dashboard.formatters import format_usd

__all__ = ["DashboardService", "format_usd"]
