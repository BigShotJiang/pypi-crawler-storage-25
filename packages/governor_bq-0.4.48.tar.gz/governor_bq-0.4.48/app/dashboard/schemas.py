"""
Pydantic schemas for dashboard data transfer objects.
"""

from __future__ import annotations

from datetime import date, datetime
from decimal import Decimal
from typing import Any

from pydantic import BaseModel, Field


class DashboardSummary(BaseModel):
    """Aggregated cost metrics for the selected date range."""

    total_spend: Decimal = Field(default=Decimal("0"))
    build_spend: Decimal = Field(default=Decimal("0"))
    consumption_spend: Decimal = Field(default=Decimal("0"))
    job_count: int = Field(default=0)
    avg_cost_per_job: Decimal = Field(default=Decimal("0"))
    date_range_start: datetime | None = None
    date_range_end: datetime | None = None
    data_coverage_days: int = Field(default=0)
    storage_monthly_cost: Decimal | None = None
    storage_potential_savings: Decimal | None = None
    storage_latest_synced_at: datetime | None = None


class DailySpend(BaseModel):
    """Time-series data point for trend visualization."""

    date: date
    total_cost: Decimal = Field(default=Decimal("0"))
    build_cost: Decimal = Field(default=Decimal("0"))
    consumption_cost: Decimal = Field(default=Decimal("0"))
    job_count: int = Field(default=0)


class CostDriver(BaseModel):
    """Ranked cost attribution item."""

    rank: int
    identifier: str
    identifier_type: str = Field(description="'model' or 'table'")
    total_spend: Decimal
    percentage_of_total: float
    job_count: int
    detail_url: str = ""


class ProjectBreakdown(BaseModel):
    """Cost aggregation by GCP project."""

    config_id: str = ""
    project_id: str
    project_name: str
    total_spend: Decimal
    percentage_of_total: float
    job_count: int
    detail_url: str = ""


class EnvironmentBreakdown(BaseModel):
    """Cost aggregation by dbt environment."""

    environment: str
    total_spend: Decimal
    percentage_of_total: float
    job_count: int


class OpportunitySummary(BaseModel):
    """Aggregated opportunity metrics."""

    cost_at_risk: Decimal = Field(default=Decimal("0"))
    potential_savings: Decimal = Field(default=Decimal("0"))
    issue_density: float = Field(default=0.0)
    total_opportunities: int = Field(default=0)
    critical_count: int = Field(default=0)
    by_type: dict[str, int] = Field(default_factory=dict)
    by_type_detail: dict[str, dict[str, Any]] = Field(default_factory=dict)
    detail_url: str = "/opportunities"


class DateRange(BaseModel):
    """Date range for dashboard filtering."""

    start: datetime
    end: datetime
    days: int | None = None
    display: str = ""


class DailyProjectStats(BaseModel):
    """Time-series data point for project-level statistics."""

    date: date
    total_cost: Decimal = Field(default=Decimal("0"))
    build_cost: Decimal = Field(default=Decimal("0"))
    consumption_cost: Decimal = Field(default=Decimal("0"))
    job_count: int = Field(default=0)
    total_bytes_billed: int = Field(default=0)
    total_slot_ms: int = Field(default=0)


class LocalModelRunPoint(BaseModel):
    """Single model datapoint for the latest local run chart."""

    model_name: str
    unique_id: str | None = None
    materialization: str | None = None
    total_cost: Decimal = Field(default=Decimal("0"))
    total_bytes_billed: int = Field(default=0)
    duration_ms: int = Field(default=0)
    execution_time_s: float | None = None
    job_state: str = Field(default="UNKNOWN")


class LocalModelDriver(BaseModel):
    """Model-level dashboard driver row for local mode."""

    model_name: str
    unique_id: str | None = None
    materialization: str | None = None
    total_cost: Decimal = Field(default=Decimal("0"))
    total_bytes_billed: int = Field(default=0)
    duration_ms: int = Field(default=0)
    execution_time_s: float | None = None
    issue_count: int = Field(default=0)
    enhancement_count: int = Field(default=0)
    score: int = Field(default=100, ge=0, le=100)
    opportunity_count: int = Field(default=0)
    opportunity_url: str | None = None
    job_state: str = Field(default="UNKNOWN")


class ManifestHealthScore(BaseModel):
    """Health score for a single manifest version."""

    manifest_version_id: str
    manifest_hash: str
    score: int = Field(ge=0, le=100)
    status: str
    opportunity_count: int = Field(default=0)
    critical_count: int = Field(default=0)
    avg_severity: float = Field(default=0.0)


class ProjectHealthScore(BaseModel):
    """Aggregated health score for a project."""

    config_id: str
    overall_score: int = Field(ge=0, le=100)
    overall_status: str
    manifest_scores: list[ManifestHealthScore] = Field(default_factory=list)
    total_opportunities: int = Field(default=0)
    cost_at_risk: Decimal = Field(default=Decimal("0"))
    total_spend: Decimal = Field(default=Decimal("0"))


class EnrichedCostDriver(BaseModel):
    """Cost driver enriched with project context and opportunity data."""

    rank: int
    config_id: str
    config_name: str
    table_name: str
    display_name: str
    total_spend: Decimal
    percentage_of_total: float
    job_count: int
    opportunity_count: int = Field(default=0)
    max_severity: int | None = None
    project_url: str
    opportunities_url: str | None = None


class ProjectDriver(BaseModel):
    """Project-level cost driver for the dashboard drivers table."""

    config_id: str
    config_name: str
    total_spend: Decimal = Field(default=Decimal("0"))
    percentage_of_total: float = Field(default=0.0)
    unique_job_count: int = Field(default=0)
    total_slot_ms: int = Field(default=0)
    total_bytes_billed: int = Field(default=0)
    total_duration_ms: int = Field(default=0)
    opportunity_count: int = Field(default=0)
    potential_savings: Decimal = Field(default=Decimal("0"))
    project_url: str = ""
    storage_latest_synced_at: datetime | None = None
    storage_dataset_count: int = Field(default=0)
    storage_logical_bytes: int = Field(default=0)
    storage_physical_bytes: int = Field(default=0)


class DatasetStorageSummary(BaseModel):
    """Per-dataset storage cost breakdown."""

    dataset_name: str
    billing_model: str = "LOGICAL"
    table_count: int = Field(default=0)
    total_logical_bytes: int = Field(default=0)
    total_physical_bytes: int = Field(default=0)
    compression_ratio: float = Field(default=0.0)
    monthly_cost: Decimal = Field(default=Decimal("0"))
    potential_savings: Decimal = Field(default=Decimal("0"))


# Keep alias for backwards compatibility with any imports
TableStorageSummary = DatasetStorageSummary


class StorageSummary(BaseModel):
    """Aggregated storage cost summary for a project."""

    total_monthly_cost: Decimal = Field(default=Decimal("0"))
    total_potential_savings: Decimal = Field(default=Decimal("0"))
    dataset_count: int = Field(default=0)
    total_logical_bytes: int = Field(default=0)
    total_physical_bytes: int = Field(default=0)
    latest_synced_at: datetime | None = None
    datasets: list[DatasetStorageSummary] = Field(default_factory=list)
