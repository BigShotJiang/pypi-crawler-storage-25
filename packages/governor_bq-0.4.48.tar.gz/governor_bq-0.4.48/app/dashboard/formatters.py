"""
Formatting utilities for dashboard display.

Per FR-010: 2 decimal places for values under $10,000,
abbreviated for values at or above $10,000 (e.g., "$12.3k").

Supports a global cost display multiplier for presentation scaling.
"""

from __future__ import annotations

from decimal import Decimal

# ---------------------------------------------------------------------------
# Cost display multiplier (presentation scaling)
# ---------------------------------------------------------------------------

_cost_multiplier: float = 1.0


def set_cost_multiplier(value: float) -> None:
    """Set the global cost display multiplier."""
    global _cost_multiplier
    _cost_multiplier = max(float(value), 0.01)


def get_cost_multiplier() -> float:
    """Return the current cost display multiplier."""
    return _cost_multiplier


def apply_cost_multiplier(value: Decimal | float | int | None) -> float:
    """Multiply a raw numeric value by the current cost multiplier."""
    return float(value or 0) * _cost_multiplier


def format_bytes(value: int | None) -> str:
    """Format byte count to human-readable string (PB/TB/GB/MB/KB/B)."""
    if value is None or value == 0:
        return "0 B"

    units = [
        (1024**5, "PB"),
        (1024**4, "TB"),
        (1024**3, "GB"),
        (1024**2, "MB"),
        (1024, "KB"),
    ]
    for threshold, unit in units:
        if value >= threshold:
            return f"{value / threshold:.1f} {unit}"
    return f"{value} B"


def format_slot_hours(slot_ms: int | None) -> str:
    """Convert slot-milliseconds to slot-hours with 1 decimal place."""
    if slot_ms is None or slot_ms == 0:
        return "0.0 slot-hrs"
    slot_hours = slot_ms / 3_600_000
    return f"{slot_hours:.1f} slot-hrs"


def format_duration(duration_ms: int | None) -> str:
    """Convert milliseconds to human-readable time (e.g., '4.5 hrs', '23.0 min')."""
    if duration_ms is None or duration_ms == 0:
        return "0 ms"
    if duration_ms >= 3_600_000:
        return f"{duration_ms / 3_600_000:.1f} hrs"
    if duration_ms >= 60_000:
        return f"{duration_ms / 60_000:.1f} min"
    if duration_ms >= 1_000:
        return f"{duration_ms / 1_000:.1f} sec"
    return "0 ms"


def format_usd(value: Decimal | float | int | None) -> str:
    """
    Format a monetary value as USD string.

    Applies the global cost display multiplier automatically.

    Args:
        value: The monetary value to format

    Returns:
        Formatted USD string (e.g., "$1,234.56" or "$12.3k")
    """
    if value is None:
        return "$0.00"

    # Apply cost display multiplier
    amount = float(value) * _cost_multiplier

    if amount >= 10_000_000:
        # Millions: $12.3M
        return f"${amount / 1_000_000:.1f}M"
    elif amount >= 10_000:
        # Thousands: $12.3k
        return f"${amount / 1_000:.1f}k"
    else:
        # Full precision: $1,234.56
        return f"${amount:,.2f}"
