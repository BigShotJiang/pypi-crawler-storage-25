"""Pagination context for paginated views."""

from __future__ import annotations

from dataclasses import dataclass

DEFAULT_PAGE_SIZE = 10


@dataclass
class PaginationContext:
    """Pagination state for template rendering."""

    page: int
    page_size: int
    total_items: int

    @property
    def total_pages(self) -> int:
        if self.total_items == 0:
            return 1
        return (self.total_items + self.page_size - 1) // self.page_size

    @property
    def has_prev(self) -> bool:
        return self.page > 1

    @property
    def has_next(self) -> bool:
        return self.page < self.total_pages

    @property
    def start_index(self) -> int:
        if self.total_items == 0:
            return 0
        return (self.page - 1) * self.page_size + 1

    @property
    def end_index(self) -> int:
        return min(self.page * self.page_size, self.total_items)

    def page_range(self, window: int = 2) -> list[int]:
        """Return page numbers to display around the current page."""
        start = max(1, self.page - window)
        end = min(self.total_pages, self.page + window)
        return list(range(start, end + 1))
