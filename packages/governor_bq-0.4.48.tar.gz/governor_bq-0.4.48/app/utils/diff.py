"""Diff utility for generating code diffs from before/after content."""

from __future__ import annotations

import difflib


def generate_code_diff(
    before: str,
    after: str,
    context_lines: int = 3,
) -> list[dict]:
    """Generate a structured diff from before/after text content.

    Uses stdlib difflib.unified_diff to produce diff lines categorised
    as 'hunk', 'add', 'delete', or 'context'.

    Args:
        before: Original content.
        after: Modified content.
        context_lines: Number of context lines around changes.

    Returns:
        List of dicts with keys: type ('hunk'|'add'|'delete'|'context'),
        content (str).
    """
    before_lines = before.splitlines(keepends=True)
    after_lines = after.splitlines(keepends=True)

    diff = difflib.unified_diff(
        before_lines,
        after_lines,
        lineterm="",
        n=context_lines,
    )

    result: list[dict] = []
    for line in diff:
        # Strip trailing newline for display
        content = line.rstrip("\n").rstrip("\r")

        if line.startswith("@@"):
            result.append({"type": "hunk", "content": content})
        elif line.startswith("---") or line.startswith("+++"):
            # Skip file headers from unified diff
            continue
        elif line.startswith("+"):
            result.append({"type": "add", "content": content[1:]})
        elif line.startswith("-"):
            result.append({"type": "delete", "content": content[1:]})
        else:
            # Context line (may start with a space)
            result.append({"type": "context", "content": content.lstrip(" ")})

    return result


def parse_github_patch(patch: str) -> list[dict]:
    """Parse a GitHub API patch string into structured diff lines.

    GitHub's ``patch`` field on PR file objects is a unified diff without
    the ``---``/``+++`` file headers. Lines use standard unified diff
    prefixes: ``@@`` for hunks, ``+`` for additions, ``-`` for deletions,
    and a leading space for context.

    Returns the same format as :func:`generate_code_diff`.
    """
    if not patch:
        return []

    result: list[dict] = []
    for line in patch.splitlines():
        if line.startswith("@@"):
            result.append({"type": "hunk", "content": line})
        elif line.startswith("+"):
            result.append({"type": "add", "content": line[1:]})
        elif line.startswith("-"):
            result.append({"type": "delete", "content": line[1:]})
        else:
            result.append({"type": "context", "content": line.lstrip(" ")})

    return result
