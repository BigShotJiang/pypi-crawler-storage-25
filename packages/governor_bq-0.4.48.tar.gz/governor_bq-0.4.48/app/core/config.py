from __future__ import annotations

import os
from dataclasses import dataclass
from functools import lru_cache

from dotenv import load_dotenv

# Load .env file early, before any settings are read
load_dotenv()


@dataclass(frozen=True)
class Settings:
    app_env: str
    database_url: str
    secret_key: str
    session_cookie_name: str
    session_cookie_secure: bool
    session_ttl_hours: int
    session_refresh_interval_minutes: int
    audit_retention_days: int
    service_name: str
    log_level: str
    # GitHub App settings (optional - required for GitHub verification)
    github_app_id: str | None
    github_app_private_key: str | None
    github_app_installation_id: str | None
    # LLM provider settings (optional - required for solution generation)
    llm_provider: str
    llm_api_key: str | None
    llm_model: str
    llm_temperature: float
    llm_max_tokens: int
    llm_timeout_ms: int
    llm_max_retries: int
    llm_max_lifetime_retries: int
    solution_queue_detection_limit: int
    solution_concurrency_limit: int
    solution_job_stale_timeout_minutes: int
    # ADK routing model for specialist context gathering (spec 052)
    gemini_routing_model: str
    # dbt compile settings (uv venv-based)
    dbt_compile_timeout: int
    dbt_compile_enabled: bool
    dry_run_validation_enabled: bool
    dbt_default_version: str
    dbt_venv_base_dir: str
    dbt_profiles_dir: str | None
    dbt_target_name: str | None
    bigquery_region: str
    worker_enabled: bool
    scheduler_enabled: bool


def is_local_mode() -> bool:
    """Return True if Governor was launched via `governor init` (local dev mode)."""
    return os.environ.get("GOVERNOR_LOCAL_MODE", "").lower() == "true"


def _get_env(name: str, default: str) -> str:
    return os.environ.get(name, default)


def _get_optional_env(name: str) -> str | None:
    """Get an optional environment variable, returning None if not set or empty."""
    value = os.environ.get(name)
    return value if value else None


@lru_cache
def get_settings() -> Settings:
    return Settings(
        app_env=_get_env("APP_ENV", "development"),
        database_url=_get_env(
            "DATABASE_URL",
            "postgresql+psycopg://localhost:5432/governor",
        ),
        secret_key=_get_env("SECRET_KEY", "dev-secret-change-me"),
        session_cookie_name=_get_env("SESSION_COOKIE_NAME", "governor_session"),
        session_cookie_secure=_get_env(
            "SESSION_COOKIE_SECURE",
            "false" if _get_env("APP_ENV", "development") in ("test", "development") else "true",
        ).lower()
        == "true",
        session_ttl_hours=int(_get_env("SESSION_TTL_HOURS", "24")),
        session_refresh_interval_minutes=int(
            _get_env("SESSION_REFRESH_INTERVAL_MINUTES", "5")
        ),
        audit_retention_days=int(_get_env("AUDIT_RETENTION_DAYS", "90")),
        service_name=_get_env("SERVICE_NAME", "governor"),
        log_level=_get_env("LOG_LEVEL", "INFO"),
        github_app_id=_get_optional_env("GITHUB_APP_ID"),
        github_app_private_key=_get_optional_env("GITHUB_APP_PRIVATE_KEY"),
        github_app_installation_id=_get_optional_env("GITHUB_APP_INSTALLATION_ID"),
        llm_provider=_get_env("LLM_PROVIDER", "gemini"),
        llm_api_key=_get_optional_env("LLM_API_KEY"),
        llm_model=_get_env("LLM_MODEL", "gemini-3.1-pro-preview"),
        gemini_routing_model=_get_env("GEMINI_ROUTING_MODEL", "gemini-3-flash-preview"),
        llm_temperature=float(_get_env("LLM_TEMPERATURE", "0.2")),
        llm_max_tokens=int(_get_env("LLM_MAX_TOKENS", "65536")),
        llm_timeout_ms=int(_get_env("LLM_TIMEOUT_MS", "120000")),
        llm_max_retries=int(_get_env("LLM_MAX_RETRIES", "5")),
        llm_max_lifetime_retries=int(_get_env("LLM_MAX_LIFETIME_RETRIES", "10")),
        solution_queue_detection_limit=int(
            _get_env("SOLUTION_QUEUE_DETECTION_LIMIT", "10")
        ),
        solution_concurrency_limit=int(_get_env("SOLUTION_CONCURRENCY_LIMIT", "4")),
        solution_job_stale_timeout_minutes=int(
            _get_env("SOLUTION_JOB_STALE_TIMEOUT_MINUTES", "30")
        ),
        dbt_compile_timeout=int(_get_env("DBT_COMPILE_TIMEOUT", "120")),
        dbt_compile_enabled=_get_env("DBT_COMPILE_ENABLED", "true").lower() == "true",
        dry_run_validation_enabled=_get_env(
            "DRY_RUN_VALIDATION_ENABLED", "true"
        ).lower()
        == "true",
        dbt_default_version=_get_env("DBT_DEFAULT_VERSION", "1.9.0"),
        dbt_venv_base_dir=_get_env("DBT_VENV_BASE_DIR", "~/.cache/governor/dbt-venvs"),
        dbt_profiles_dir=_get_optional_env("DBT_PROFILES_DIR"),
        dbt_target_name=_get_optional_env("DBT_TARGET_NAME"),
        bigquery_region=_get_env("BIGQUERY_REGION", "us"),
        worker_enabled=_get_env("WORKER_ENABLED", "true").lower() == "true",
        scheduler_enabled=_get_env("SCHEDULER_ENABLED", "true").lower() == "true",
    )
