from __future__ import annotations

import json
import logging
import time
from contextvars import ContextVar
from typing import Any

from opentelemetry import trace

request_id_var: ContextVar[str | None] = ContextVar("request_id", default=None)
request_path_var: ContextVar[str | None] = ContextVar("request_path", default=None)
request_method_var: ContextVar[str | None] = ContextVar("request_method", default=None)
client_ip_var: ContextVar[str | None] = ContextVar("client_ip", default=None)


class JsonFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:
        message = record.getMessage()
        payload: dict[str, Any] = {
            "timestamp": time.strftime(
                "%Y-%m-%dT%H:%M:%SZ", time.gmtime(record.created)
            ),
            "level": record.levelname,
            "logger": record.name,
            "message": message,
        }
        request_id = request_id_var.get()
        if request_id:
            payload["request_id"] = request_id
        request_path = request_path_var.get()
        if request_path:
            payload["path"] = request_path
        request_method = request_method_var.get()
        if request_method:
            payload["method"] = request_method
        client_ip = client_ip_var.get()
        if client_ip:
            payload["client_ip"] = client_ip
        for field in ("status_code", "duration_ms", "email", "user_id"):
            if field in record.__dict__:
                payload[field] = record.__dict__[field]
        span = trace.get_current_span()
        span_context = span.get_span_context()
        if span_context and span_context.is_valid:
            payload["trace_id"] = f"{span_context.trace_id:032x}"
            payload["span_id"] = f"{span_context.span_id:016x}"
        if record.exc_info:
            payload["exc_info"] = self.formatException(record.exc_info)
        return json.dumps(payload, default=str)


def configure_logging(log_level: str) -> None:
    handler = logging.StreamHandler()
    handler.setFormatter(JsonFormatter())

    root_logger = logging.getLogger()
    root_logger.handlers = []
    root_logger.addHandler(handler)
    root_logger.setLevel(log_level)

    for logger_name in ("uvicorn", "uvicorn.error", "uvicorn.access"):
        logging.getLogger(logger_name).handlers = [handler]
        logging.getLogger(logger_name).propagate = False
        logging.getLogger(logger_name).setLevel(log_level)

    for logger_name in ("app.request", "app.auth", "app.error"):
        logger = logging.getLogger(logger_name)
        logger.handlers = [handler]
        logger.propagate = False
        logger.setLevel(log_level)

    if log_level.upper() == "DEBUG":
        sqlalchemy_logger = logging.getLogger("sqlalchemy.engine")
        sqlalchemy_logger.handlers = [handler]
        sqlalchemy_logger.propagate = False
        sqlalchemy_logger.setLevel(logging.INFO)


def bind_request_context(
    request_id: str, path: str, method: str, client_ip: str | None
) -> None:
    request_id_var.set(request_id)
    request_path_var.set(path)
    request_method_var.set(method)
    client_ip_var.set(client_ip)


def clear_request_context() -> None:
    request_id_var.set(None)
    request_path_var.set(None)
    request_method_var.set(None)
    client_ip_var.set(None)
