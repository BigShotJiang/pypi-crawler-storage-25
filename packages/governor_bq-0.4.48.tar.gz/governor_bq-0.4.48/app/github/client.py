"""GitHub App client for authentication and API interactions."""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from github import Github

logger = logging.getLogger("app.github")


# ---------------------------------------------------------------------------
# Custom Exceptions
# ---------------------------------------------------------------------------


class GitHubConfigurationError(RuntimeError):
    """Raised when GitHub App configuration is missing or invalid."""


class GitHubAuthenticationError(RuntimeError):
    """Raised when GitHub App authentication fails (invalid credentials)."""


class GitHubAppSuspendedError(RuntimeError):
    """Raised when the GitHub App has been suspended."""


class GitHubRateLimitError(RuntimeError):
    """Raised when GitHub API rate limit is exceeded."""


class GitHubConnectionError(RuntimeError):
    """Raised when connection to GitHub API fails (network/timeout)."""


class GitHubFileNotFoundError(RuntimeError):
    """Raised when a requested file does not exist in the repository."""


# ---------------------------------------------------------------------------
# Data Models
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class GitHubAppInfo:
    """Information about the authenticated GitHub App."""

    id: int
    name: str
    slug: str
    owner: str


@dataclass(frozen=True)
class GitHubTokenInfo:
    """Information about the authenticated GitHub user/token."""

    id: int
    login: str
    name: str


# ---------------------------------------------------------------------------
# GitHub App Client
# ---------------------------------------------------------------------------


class GitHubAppClient:
    """Client for GitHub App authentication and API operations.

    Wraps PyGithub's GithubIntegration to provide a simplified interface
    for Governor's GitHub integration needs.
    """

    def __init__(
        self,
        app_id: str,
        private_key: str,
        installation_id: str,
    ) -> None:
        """Initialize the GitHub App client.

        Args:
            app_id: The GitHub App ID (numeric string).
            private_key: The PEM-encoded RSA private key.
            installation_id: The installation ID for the organization.

        Raises:
            GitHubConfigurationError: If private key format is invalid.
        """
        from github import Auth, GithubIntegration

        self._app_id = app_id
        self._installation_id = installation_id

        # Validate private key format before attempting authentication
        if not private_key.strip().startswith("-----BEGIN"):
            raise GitHubConfigurationError(
                "GitHub App private key is malformed. "
                "Key must be PEM-encoded and start with '-----BEGIN RSA PRIVATE KEY-----' or '-----BEGIN PRIVATE KEY-----'."
            )

        try:
            auth = Auth.AppAuth(int(app_id), private_key)
            self._integration = GithubIntegration(auth=auth)
        except ValueError as exc:
            # PyGithub raises ValueError for invalid key format
            raise GitHubConfigurationError(
                f"GitHub App private key is malformed: {exc}"
            ) from exc

    def verify_app_connectivity(self) -> GitHubAppInfo:
        """Verify connectivity by fetching the authenticated app's metadata.

        Returns:
            GitHubAppInfo with app details on success.

        Raises:
            GitHubAuthenticationError: If credentials are invalid (401).
            GitHubAppSuspendedError: If the app is suspended (403).
            GitHubRateLimitError: If rate limited (403 with rate limit header).
            GitHubConnectionError: If network/timeout error occurs.
        """
        import socket
        from urllib.error import URLError

        from github import (
            BadCredentialsException,
            GithubException,
            RateLimitExceededException,
        )

        try:
            app = self._integration.get_app()
            owner_login = ""
            if app.owner:
                owner_login = app.owner.login

            return GitHubAppInfo(
                id=app.id,
                name=app.name,
                slug=app.slug,
                owner=owner_login,
            )
        except BadCredentialsException as exc:
            raise GitHubAuthenticationError(
                "GitHub App authentication failed. "
                "Verify GITHUB_APP_ID matches your app and regenerate GITHUB_APP_PRIVATE_KEY if needed."
            ) from exc
        except RateLimitExceededException as exc:
            raise GitHubRateLimitError(
                "GitHub API rate limit exceeded. "
                "Wait for the rate limit to reset or check for other processes using this App ID."
            ) from exc
        except GithubException as exc:
            if exc.status == 403:
                # Check if it's a suspension vs other 403
                error_message = str(exc.data) if exc.data else ""
                if "suspended" in error_message.lower():
                    raise GitHubAppSuspendedError(
                        "GitHub App is suspended. "
                        "Reactivate your GitHub App in organization settings."
                    ) from exc
                # Generic 403 - could be permissions or other issues
                raise GitHubAuthenticationError(
                    f"GitHub API access denied: {error_message or 'Unknown error'}"
                ) from exc
            # Re-raise other GitHub exceptions
            raise GitHubConnectionError(f"GitHub API error: {exc}") from exc
        except (URLError, socket.timeout, TimeoutError, OSError) as exc:
            raise GitHubConnectionError(
                "Unable to connect to GitHub API. "
                "Check network connectivity and firewall rules for api.github.com:443."
            ) from exc

    def _get_installation_github(self) -> Github:
        """Get an authenticated GitHub instance for the installation."""
        return self._integration.get_github_for_installation(int(self._installation_id))

    def list_installation_repos(self) -> list[dict[str, str]]:
        """List repositories accessible to this GitHub App installation.

        Returns:
            List of dicts with ``full_name`` and ``description`` keys,
            sorted by full_name.

        Raises:
            GitHubAuthenticationError: If credentials are invalid.
            GitHubConnectionError: If network/API error occurs.
        """
        import socket
        from urllib.error import URLError

        from github import BadCredentialsException, GithubException
        from github.Installation import Installation

        try:
            gh = self._get_installation_github()
            inst = Installation(
                requester=gh.requester,
                headers={},
                attributes={"id": int(self._installation_id)},
            )
            repos = []
            for repo in inst.get_repos():
                repos.append(
                    {
                        "full_name": repo.full_name,
                        "description": repo.description or "",
                    }
                )
            return sorted(repos, key=lambda r: r["full_name"])
        except BadCredentialsException as exc:
            raise GitHubAuthenticationError(
                "GitHub authentication failed when listing repos."
            ) from exc
        except GithubException as exc:
            raise GitHubConnectionError(
                f"GitHub API error listing installation repos: {exc}"
            ) from exc
        except (URLError, socket.timeout, TimeoutError, OSError) as exc:
            raise GitHubConnectionError(
                "Network error listing installation repos."
            ) from exc

    def get_file_content(self, repo: str, path: str, ref: str | None = None) -> str:
        """Retrieve a single file's decoded content from a GitHub repository.

        Args:
            repo: Repository in 'owner/repo' format.
            path: File path within the repository.
            ref: Commit SHA, branch, or tag. Defaults to repo's default branch.

        Returns:
            Decoded file content as a string.

        Raises:
            GitHubFileNotFoundError: If the file does not exist.
            GitHubAuthenticationError: If credentials are invalid.
            GitHubRateLimitError: If rate limited.
            GitHubConnectionError: If network/timeout error occurs.
        """
        import socket
        from urllib.error import URLError

        from github import (
            BadCredentialsException,
            GithubException,
            RateLimitExceededException,
            UnknownObjectException,
        )

        try:
            gh = self._get_installation_github()
            repository = gh.get_repo(repo)
            kwargs = {"ref": ref} if ref else {}
            content_file = repository.get_contents(path, **kwargs)
            if isinstance(content_file, list):
                raise GitHubFileNotFoundError(
                    f"Path '{path}' is a directory, not a file, in {repo}"
                )
            return content_file.decoded_content.decode("utf-8")
        except UnknownObjectException as exc:
            raise GitHubFileNotFoundError(
                f"File '{path}' not found in {repo}"
                + (f" at ref '{ref}'" if ref else "")
            ) from exc
        except BadCredentialsException as exc:
            raise GitHubAuthenticationError(
                f"GitHub authentication failed when accessing {repo}"
            ) from exc
        except RateLimitExceededException as exc:
            raise GitHubRateLimitError(
                "GitHub API rate limit exceeded during file retrieval."
            ) from exc
        except GithubException as exc:
            raise GitHubConnectionError(
                f"GitHub API error retrieving {path} from {repo}: {exc}"
            ) from exc
        except (URLError, socket.timeout, TimeoutError, OSError) as exc:
            raise GitHubConnectionError(
                f"Network error retrieving {path} from {repo}"
            ) from exc

    def get_directory_listing(
        self, repo: str, path: str, ref: str | None = None
    ) -> list[str]:
        """List files in a directory of a GitHub repository.

        Args:
            repo: Repository in 'owner/repo' format.
            path: Directory path within the repository.
            ref: Commit SHA, branch, or tag. Defaults to repo's default branch.

        Returns:
            List of file paths in the directory.

        Raises:
            GitHubFileNotFoundError: If the directory does not exist.
            GitHubAuthenticationError: If credentials are invalid.
            GitHubRateLimitError: If rate limited.
            GitHubConnectionError: If network/timeout error occurs.
        """
        import socket
        from urllib.error import URLError

        from github import (
            BadCredentialsException,
            GithubException,
            RateLimitExceededException,
            UnknownObjectException,
        )

        try:
            gh = self._get_installation_github()
            repository = gh.get_repo(repo)
            kwargs = {"ref": ref} if ref else {}
            contents = repository.get_contents(path, **kwargs)
            if not isinstance(contents, list):
                return [contents.path]
            return [item.path for item in contents]
        except UnknownObjectException as exc:
            raise GitHubFileNotFoundError(
                f"Directory '{path}' not found in {repo}"
                + (f" at ref '{ref}'" if ref else "")
            ) from exc
        except BadCredentialsException as exc:
            raise GitHubAuthenticationError(
                f"GitHub authentication failed when accessing {repo}"
            ) from exc
        except RateLimitExceededException as exc:
            raise GitHubRateLimitError(
                "GitHub API rate limit exceeded during directory listing."
            ) from exc
        except GithubException as exc:
            raise GitHubConnectionError(
                f"GitHub API error listing {path} in {repo}: {exc}"
            ) from exc
        except (URLError, socket.timeout, TimeoutError, OSError) as exc:
            raise GitHubConnectionError(
                f"Network error listing {path} in {repo}"
            ) from exc

    def download_repo_archive(
        self, repo: str, dest_dir: str, ref: str | None = None
    ) -> str:
        """Download and extract a repository archive to a local directory.

        Uses GitHub's zipball endpoint (single API call) to get the full repo.
        Extracts contents so that project files sit directly in dest_dir.

        Args:
            repo: Repository in 'owner/repo' format.
            dest_dir: Local directory to extract files into.
            ref: Commit SHA, branch, or tag. Defaults to repo's default branch.

        Returns:
            Path to the extracted project root (same as dest_dir).

        Raises:
            GitHubAuthenticationError: If credentials are invalid.
            GitHubConnectionError: If network/timeout error occurs.
        """
        import io
        import socket
        import zipfile
        from pathlib import Path
        from urllib.error import URLError
        from urllib.request import Request, urlopen

        from github import BadCredentialsException, GithubException

        try:
            gh = self._get_installation_github()
            repository = gh.get_repo(repo)
            archive_url = repository.get_archive_link("zipball", ref=ref or "")

            # Download the zip archive using the token-authenticated redirect URL
            req = Request(archive_url)
            with urlopen(req, timeout=60) as response:
                zip_bytes = response.read()

            # Extract zip contents
            dest = Path(dest_dir)
            with zipfile.ZipFile(io.BytesIO(zip_bytes)) as zf:
                # GitHub zipballs have a top-level directory like "owner-repo-sha/"
                # We need to strip that prefix so files land directly in dest_dir
                top_dirs = {name.split("/")[0] for name in zf.namelist() if "/" in name}
                prefix = top_dirs.pop() + "/" if len(top_dirs) == 1 else ""

                for member in zf.infolist():
                    if member.is_dir():
                        continue
                    # Strip the top-level directory prefix
                    rel_path = member.filename
                    if prefix and rel_path.startswith(prefix):
                        rel_path = rel_path[len(prefix) :]
                    if not rel_path:
                        continue

                    target = dest / rel_path
                    target.parent.mkdir(parents=True, exist_ok=True)
                    target.write_bytes(zf.read(member.filename))

            return str(dest)

        except BadCredentialsException as exc:
            raise GitHubAuthenticationError(
                f"GitHub authentication failed when downloading {repo}"
            ) from exc
        except GithubException as exc:
            raise GitHubConnectionError(
                f"GitHub API error downloading archive for {repo}: {exc}"
            ) from exc
        except (URLError, socket.timeout, TimeoutError, OSError) as exc:
            raise GitHubConnectionError(
                f"Network error downloading archive for {repo}"
            ) from exc

    def get_default_branch(self, repo: str) -> str:
        """Return the repository's default branch name.

        Args:
            repo: Repository in 'owner/repo' format.

        Returns:
            Branch name (e.g. "main").
        """
        import socket
        from urllib.error import URLError

        from github import BadCredentialsException, GithubException

        try:
            gh = self._get_installation_github()
            repository = gh.get_repo(repo)
            return repository.default_branch
        except BadCredentialsException as exc:
            raise GitHubAuthenticationError(
                f"GitHub authentication failed when accessing {repo}"
            ) from exc
        except GithubException as exc:
            raise GitHubConnectionError(
                f"GitHub API error getting default branch for {repo}: {exc}"
            ) from exc
        except (URLError, socket.timeout, TimeoutError, OSError) as exc:
            raise GitHubConnectionError(
                f"Network error getting default branch for {repo}"
            ) from exc

    def get_branch_head_sha(self, repo: str, branch: str) -> str:
        """Return the HEAD commit SHA of a branch.

        Args:
            repo: Repository in 'owner/repo' format.
            branch: Branch name.

        Returns:
            Commit SHA string.
        """
        import socket
        from urllib.error import URLError

        from github import BadCredentialsException, GithubException

        try:
            gh = self._get_installation_github()
            repository = gh.get_repo(repo)
            branch_obj = repository.get_branch(branch)
            return branch_obj.commit.sha
        except BadCredentialsException as exc:
            raise GitHubAuthenticationError(
                f"GitHub authentication failed when accessing {repo}"
            ) from exc
        except GithubException as exc:
            raise GitHubConnectionError(
                f"GitHub API error getting branch HEAD for {repo}/{branch}: {exc}"
            ) from exc
        except (URLError, socket.timeout, TimeoutError, OSError) as exc:
            raise GitHubConnectionError(
                f"Network error getting branch HEAD for {repo}/{branch}"
            ) from exc

    def create_branch(self, repo: str, branch_name: str, source_sha: str) -> str:
        """Create a new branch in the repository.

        Args:
            repo: Repository in 'owner/repo' format.
            branch_name: New branch name (without refs/heads/ prefix).
            source_sha: SHA to branch from.

        Returns:
            The SHA of the created ref.
        """
        import socket
        from urllib.error import URLError

        from github import BadCredentialsException, GithubException

        try:
            gh = self._get_installation_github()
            repository = gh.get_repo(repo)
            ref = repository.create_git_ref(
                ref=f"refs/heads/{branch_name}",
                sha=source_sha,
            )
            return ref.object.sha
        except BadCredentialsException as exc:
            raise GitHubAuthenticationError(
                f"GitHub authentication failed when accessing {repo}"
            ) from exc
        except GithubException as exc:
            raise GitHubConnectionError(
                f"GitHub API error creating branch {branch_name} in {repo}: {exc}"
            ) from exc
        except (URLError, socket.timeout, TimeoutError, OSError) as exc:
            raise GitHubConnectionError(
                f"Network error creating branch {branch_name} in {repo}"
            ) from exc

    def create_file_commit(
        self,
        repo: str,
        branch: str,
        file_changes: list[dict[str, str]],
        message: str,
    ) -> str:
        """Create an atomic commit with one or more file changes.

        Uses the Git Data API (trees/commits/refs) to support multi-file
        atomic commits in a single operation.

        Args:
            repo: Repository in 'owner/repo' format.
            branch: Branch name to commit to.
            file_changes: List of dicts with 'path' and 'content' keys.
            message: Commit message.

        Returns:
            The new commit SHA.
        """
        import socket
        from urllib.error import URLError

        from github import BadCredentialsException, GithubException, InputGitTreeElement

        try:
            gh = self._get_installation_github()
            repository = gh.get_repo(repo)

            # Get the current HEAD of the branch
            ref = repository.get_git_ref(f"heads/{branch}")
            base_sha = ref.object.sha
            base_commit = repository.get_git_commit(base_sha)
            base_tree = base_commit.tree

            # Build tree elements for each file change
            tree_elements = []
            for fc in file_changes:
                tree_elements.append(
                    InputGitTreeElement(
                        path=fc["path"],
                        mode="100644",
                        type="blob",
                        content=fc["content"],
                    )
                )

            # Create new tree and commit
            new_tree = repository.create_git_tree(tree_elements, base_tree)
            new_commit = repository.create_git_commit(
                message=message,
                tree=new_tree,
                parents=[base_commit],
            )

            # Update branch ref to point to new commit
            ref.edit(sha=new_commit.sha)
            return new_commit.sha

        except BadCredentialsException as exc:
            raise GitHubAuthenticationError(
                f"GitHub authentication failed when accessing {repo}"
            ) from exc
        except GithubException as exc:
            raise GitHubConnectionError(
                f"GitHub API error creating commit on {repo}/{branch}: {exc}"
            ) from exc
        except (URLError, socket.timeout, TimeoutError, OSError) as exc:
            raise GitHubConnectionError(
                f"Network error creating commit on {repo}/{branch}"
            ) from exc

    def create_pull_request(
        self,
        repo: str,
        head: str,
        base: str,
        title: str,
        body: str,
        draft: bool = False,
    ) -> dict:
        """Open a pull request.

        Args:
            repo: Repository in 'owner/repo' format.
            head: Source branch name.
            base: Target branch name.
            title: PR title.
            body: PR description (markdown).
            draft: Create as draft PR (default False).

        Returns:
            Dict with 'number', 'url', and 'html_url' keys.
        """
        import socket
        from urllib.error import URLError

        from github import BadCredentialsException, GithubException

        try:
            gh = self._get_installation_github()
            repository = gh.get_repo(repo)
            pr = repository.create_pull(
                title=title,
                body=body,
                base=base,
                head=head,
                draft=draft,
            )
            return {
                "number": pr.number,
                "url": pr.url,
                "html_url": pr.html_url,
            }
        except BadCredentialsException as exc:
            raise GitHubAuthenticationError(
                f"GitHub authentication failed when accessing {repo}"
            ) from exc
        except GithubException as exc:
            raise GitHubConnectionError(
                f"GitHub API error creating pull request in {repo}: {exc}"
            ) from exc
        except (URLError, socket.timeout, TimeoutError, OSError) as exc:
            raise GitHubConnectionError(
                f"Network error creating pull request in {repo}"
            ) from exc

    def get_pull_request_files(self, repo: str, pr_number: int) -> list[dict]:
        """Get the list of changed files for a pull request with their patches.

        Args:
            repo: Repository in 'owner/repo' format.
            pr_number: The pull request number.

        Returns:
            List of dicts with 'filename', 'status' (added/modified/removed),
            'patch' (unified diff text), 'additions', 'deletions'.
        """
        import socket
        from urllib.error import URLError

        from github import (
            BadCredentialsException,
            GithubException,
            UnknownObjectException,
        )

        try:
            gh = self._get_installation_github()
            repository = gh.get_repo(repo)
            pr = repository.get_pull(pr_number)
            files = []
            for f in pr.get_files():
                files.append(
                    {
                        "filename": f.filename,
                        "status": f.status,
                        "patch": f.patch or "",
                        "additions": f.additions,
                        "deletions": f.deletions,
                    }
                )
            return files
        except UnknownObjectException as exc:
            raise GitHubConnectionError(
                f"Pull request #{pr_number} not found in {repo}"
            ) from exc
        except BadCredentialsException as exc:
            raise GitHubAuthenticationError(
                f"GitHub authentication failed when accessing {repo}"
            ) from exc
        except GithubException as exc:
            raise GitHubConnectionError(
                f"GitHub API error getting files for PR #{pr_number} in {repo}: {exc}"
            ) from exc
        except (URLError, socket.timeout, TimeoutError, OSError) as exc:
            raise GitHubConnectionError(
                f"Network error getting files for PR #{pr_number} in {repo}"
            ) from exc

    def list_pull_requests(self, repo: str, state: str = "all") -> list[dict]:
        """List pull requests from a repository, filtered to Governor branches.

        Only returns PRs whose head branch starts with ``governor/``.
        Handles pagination internally to return all matching PRs.

        Args:
            repo: Repository in 'owner/repo' format.
            state: PR state filter ('open', 'closed', 'all').

        Returns:
            List of dicts with PR metadata (number, title, state, merged,
            merged_at, html_url, head_ref, head_sha, base_ref, body,
            created_at, updated_at).
        """
        import socket
        from urllib.error import URLError

        from github import (
            BadCredentialsException,
            GithubException,
            RateLimitExceededException,
        )

        try:
            gh = self._get_installation_github()
            repository = gh.get_repo(repo)
            pulls = repository.get_pulls(state=state, sort="created", direction="desc")

            results = []
            for pr in pulls:
                # Filter to Governor-created PRs by branch prefix
                if not pr.head.ref.startswith("governor/"):
                    continue
                results.append(
                    {
                        "number": pr.number,
                        "title": pr.title,
                        "state": pr.state,
                        "merged": pr.merged,
                        "merged_at": (
                            pr.merged_at.isoformat() if pr.merged_at else None
                        ),
                        "html_url": pr.html_url,
                        "head_ref": pr.head.ref,
                        "head_sha": pr.head.sha,
                        "base_ref": pr.base.ref,
                        "body": pr.body or "",
                        "created_at": (
                            pr.created_at.isoformat() if pr.created_at else None
                        ),
                        "updated_at": (
                            pr.updated_at.isoformat() if pr.updated_at else None
                        ),
                    }
                )
            return results
        except BadCredentialsException as exc:
            raise GitHubAuthenticationError(
                f"GitHub authentication failed when listing PRs in {repo}"
            ) from exc
        except RateLimitExceededException as exc:
            raise GitHubRateLimitError(
                "GitHub API rate limit exceeded during PR listing."
            ) from exc
        except GithubException as exc:
            raise GitHubConnectionError(
                f"GitHub API error listing PRs in {repo}: {exc}"
            ) from exc
        except (URLError, socket.timeout, TimeoutError, OSError) as exc:
            raise GitHubConnectionError(f"Network error listing PRs in {repo}") from exc

    def get_pull_request(self, repo: str, pr_number: int) -> dict:
        """Get the current state of a pull request.

        Args:
            repo: Repository in 'owner/repo' format.
            pr_number: The pull request number.

        Returns:
            Dict with 'state' ('open' or 'closed'), 'merged' (bool),
            and 'merged_at' (ISO string or None).
        """
        import socket
        from urllib.error import URLError

        from github import (
            BadCredentialsException,
            GithubException,
            UnknownObjectException,
        )

        try:
            gh = self._get_installation_github()
            repository = gh.get_repo(repo)
            pr = repository.get_pull(pr_number)
            return {
                "state": pr.state,
                "merged": pr.merged,
                "merged_at": pr.merged_at.isoformat() if pr.merged_at else None,
            }
        except UnknownObjectException as exc:
            raise GitHubConnectionError(
                f"Pull request #{pr_number} not found in {repo}"
            ) from exc
        except BadCredentialsException as exc:
            raise GitHubAuthenticationError(
                f"GitHub authentication failed when accessing {repo}"
            ) from exc
        except GithubException as exc:
            raise GitHubConnectionError(
                f"GitHub API error getting PR #{pr_number} in {repo}: {exc}"
            ) from exc
        except (URLError, socket.timeout, TimeoutError, OSError) as exc:
            raise GitHubConnectionError(
                f"Network error getting PR #{pr_number} in {repo}"
            ) from exc


class GitHubTokenClient(GitHubAppClient):
    """GitHub client authenticated with a personal access token."""

    def __init__(self, token: str) -> None:
        from github import Auth, Github

        if not token.strip():
            raise GitHubConfigurationError("GitHub personal access token is required.")

        self._token = token
        self._app_id = None
        self._installation_id = None
        self._integration = None
        self._github = Github(auth=Auth.Token(token))

    def _get_installation_github(self) -> Github:
        return self._github

    def verify_token_connectivity(self) -> GitHubTokenInfo:
        """Verify connectivity by fetching the authenticated user."""
        import socket
        from urllib.error import URLError

        from github import (
            BadCredentialsException,
            GithubException,
            RateLimitExceededException,
        )

        try:
            user = self._github.get_user()
            return GitHubTokenInfo(
                id=user.id,
                login=user.login,
                name=user.name or "",
            )
        except BadCredentialsException as exc:
            raise GitHubAuthenticationError(
                "GitHub personal access token authentication failed."
            ) from exc
        except RateLimitExceededException as exc:
            raise GitHubRateLimitError("GitHub API rate limit exceeded.") from exc
        except GithubException as exc:
            raise GitHubConnectionError(
                f"GitHub API error verifying personal access token: {exc}"
            ) from exc
        except (URLError, socket.timeout, TimeoutError, OSError) as exc:
            raise GitHubConnectionError(
                "Unable to connect to GitHub API. "
                "Check network connectivity and firewall rules for api.github.com:443."
            ) from exc

    def list_installation_repos(self) -> list[dict[str, str]]:
        """List repositories accessible to the authenticated user/token."""
        import socket
        from urllib.error import URLError

        from github import BadCredentialsException, GithubException

        try:
            user = self._github.get_user()
            repos = []
            for repo in user.get_repos():
                repos.append(
                    {
                        "full_name": repo.full_name,
                        "description": repo.description or "",
                    }
                )
            return sorted(repos, key=lambda r: r["full_name"])
        except BadCredentialsException as exc:
            raise GitHubAuthenticationError(
                "GitHub authentication failed when listing repos."
            ) from exc
        except GithubException as exc:
            raise GitHubConnectionError(
                f"GitHub API error listing accessible repos: {exc}"
            ) from exc
        except (URLError, socket.timeout, TimeoutError, OSError) as exc:
            raise GitHubConnectionError(
                "Network error listing accessible repos."
            ) from exc
