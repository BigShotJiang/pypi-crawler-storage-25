"""GitHub integration package for GitHub App authentication."""

from __future__ import annotations
