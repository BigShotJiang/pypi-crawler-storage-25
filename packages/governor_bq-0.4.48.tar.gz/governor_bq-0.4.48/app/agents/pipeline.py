"""ADK-based solution generation pipeline.

ADKPipeline assembles the agent tree once at construction time and exposes
a single async `run(request)` method that:
1. Converts a PipelineRequest to a flat ADK session state dict
2. Creates a fresh InMemorySession pre-seeded with all opportunity context
3. Runs runner.run_async() to drive the OpportunityRouter → specialist dispatch
4. Reads the final session state and converts it to a GenerationResult

The pipeline is stateless — a new session is created for each call, so
concurrent calls are safe.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from app.agents.finalizer import PipelineRequest
    from app.llm.base import LLMProvider
    from app.solutions.generator import GenerationResult

logger = logging.getLogger("app.agents.pipeline")

_APP_NAME = "governor-solutions"
_USER_ID = "solution-generator"


class ADKPipeline:
    """Stateless ADK pipeline for solution generation.

    Constructs the full agent tree once in __init__ and reuses it across
    calls. Each call to run() creates a fresh ADK session so that sessions
    are isolated and can run concurrently.

    Args:
        llm_provider: Injected into GeneralSolver for LLM API calls.
        github_client: Optional — injected into session state for tool
                       functions (Phase 4+ context gathering tools).
        db_session:    Optional — injected into session state for tool
                       functions (Phase 4+ context gathering tools).
    """

    def __init__(
        self,
        llm_provider: "LLMProvider",
        github_client: Any = None,
        db_session: Any = None,
        db_session_factory: Any = None,
    ) -> None:
        from google.adk.runners import Runner
        from google.adk.sessions import InMemorySessionService

        from app.agents.router import OpportunityRouter
        from app.agents.specialists.general import GeneralSolver
        from app.agents.specialists.join_explosion import build_join_explosion_pipeline
        from app.agents.specialists.partition_pruning import (
            build_partition_pruning_pipeline,
        )
        from app.agents.specialists.shuffle_spill import build_shuffle_spill_pipeline
        from app.agents.specialists.slot_contention import (
            build_slot_contention_pipeline,
        )
        from app.agents.specialists.storage_billing import StorageBillingSolver

        self._github_client = github_client
        self._db_session = db_session
        self._db_session_factory = db_session_factory

        # Build fallback and deterministic specialist agents
        general_solver = GeneralSolver(
            name="GeneralSolver",
            llm_provider=llm_provider,
        )
        storage_billing_solver = StorageBillingSolver(
            name="StorageBillingSolver",
        )

        # Build focused specialist pipelines (Phase 4)
        join_explosion_pipeline = build_join_explosion_pipeline(
            llm_provider,
            github_client=github_client,
            db_session=db_session,
            db_session_factory=db_session_factory,
        )
        shuffle_spill_pipeline = build_shuffle_spill_pipeline(
            llm_provider,
            github_client=github_client,
            db_session=db_session,
            db_session_factory=db_session_factory,
        )
        partition_pruning_pipeline = build_partition_pruning_pipeline(
            llm_provider,
            github_client=github_client,
            db_session=db_session,
            db_session_factory=db_session_factory,
        )
        slot_contention_pipeline = build_slot_contention_pipeline(
            llm_provider,
            github_client=github_client,
            db_session=db_session,
            db_session_factory=db_session_factory,
        )

        # All agents that appear in the router dispatch must be in sub_agents
        all_specialists = [
            general_solver,
            storage_billing_solver,
            join_explosion_pipeline,
            shuffle_spill_pipeline,
            partition_pruning_pipeline,
            slot_contention_pipeline,
        ]

        # Build router with all specialists registered as sub_agents
        router = OpportunityRouter(
            name="OpportunityRouter",
            general_solver=general_solver,
            storage_billing_solver=storage_billing_solver,
            join_explosion_pipeline=join_explosion_pipeline,
            shuffle_spill_pipeline=shuffle_spill_pipeline,
            partition_pruning_pipeline=partition_pruning_pipeline,
            slot_contention_pipeline=slot_contention_pipeline,
            sub_agents=all_specialists,
        )
        # Tell ADK this router belongs to the explicit runner app name so it
        # doesn't infer the generic "agents" name from the module path.
        object.__setattr__(router, "_adk_origin_app_name", _APP_NAME)
        object.__setattr__(router, "_adk_origin_path", Path(__file__).resolve().parent)

        # Keep a reference to the router for observability and testing
        self._router = router

        # Build session service and runner (reused across calls)
        self._session_service = InMemorySessionService()
        self._runner = Runner(
            agent=router,
            session_service=self._session_service,
            app_name=_APP_NAME,
        )

    async def run(self, request: "PipelineRequest") -> "GenerationResult":
        """Run the ADK pipeline for a single opportunity.

        Creates a fresh session, runs the agent tree, reads final state,
        and converts it to a GenerationResult.

        Args:
            request: Fully-populated PipelineRequest with all context.

        Returns:
            GenerationResult with solutions and metadata.

        Raises:
            LLMResponseValidationError: If the pipeline completes without
                                         writing a valid solution to state.
        """
        from google.genai import types

        from app.agents.finalizer import _request_to_state, _state_to_generation_result

        # Convert request to flat, JSON-serializable state dict.
        # NOTE: _github_client and _db_session are NOT placed in state here.
        # InMemorySessionService.create_session() calls copy.deepcopy(session),
        # which fails for PyGithub and SQLAlchemy objects (hold module references).
        # Context gatherer agents receive these dependencies as constructor args
        # and inject them into a transient tool context (never persisted in state).
        # github_client is also passed directly to _state_to_generation_result().
        state = _request_to_state(request)

        # Create a fresh session pre-seeded with all opportunity context
        session = await self._session_service.create_session(
            app_name=_APP_NAME,
            user_id=_USER_ID,
            state=state,
        )
        session_id = session.id

        # Trigger message — agents read from state, not from message content
        trigger = types.Content(
            role="user",
            parts=[types.Part(text="Generate solution")],
        )

        # Drive the agent tree; consume all events
        event_count = 0
        async for event in self._runner.run_async(
            user_id=_USER_ID,
            session_id=session_id,
            new_message=trigger,
        ):
            event_count += 1
            logger.debug(
                "ADK event #%d from agent=%s",
                event_count,
                event.author,
            )

        logger.info("ADK pipeline completed after %d events", event_count)

        # Read the final session state after the pipeline has run
        final_session = await self._session_service.get_session(
            app_name=_APP_NAME,
            user_id=_USER_ID,
            session_id=session_id,
        )

        if final_session is None:
            from app.solutions.exceptions import LLMResponseValidationError

            raise LLMResponseValidationError(
                "ADK pipeline session not found after run — session was lost"
            )

        return _state_to_generation_result(
            final_session.state, github_client=self._github_client
        )
