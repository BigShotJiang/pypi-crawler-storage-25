"""Pydantic output schemas for ADK CodeGeneratorAgent.

Mirrors app/llm/schemas.SolutionResponse but defined here to avoid
circular imports between app/agents/ and app/llm/.
"""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel


class FileChangeSchema(BaseModel):
    """A single file modification proposed by the code generator."""

    file_path: str
    change_type: Literal["sql_change", "project_config_change", "schema_change"]
    before_content: str | None = None
    after_content: str


class SettingRecommendationSchema(BaseModel):
    """A BigQuery infrastructure setting recommendation."""

    current_value: str
    recommended_value: str
    affected_resource: str


class SolutionResponseSchema(BaseModel):
    """Structured output from the LLM code generator.

    Used as output_schema for LlmAgent — ADK serialises the agent's
    final response as a JSON string matching this schema and stores it
    at output_key in session state.
    """

    resolution_category: Literal["dbt_project_change", "bigquery_infrastructure"]
    explanation: str
    risk_level: Literal["low", "medium", "high"]
    risk_justification: str
    file_changes: list[FileChangeSchema] | None = None
    setting_recommendation: SettingRecommendationSchema | None = None
