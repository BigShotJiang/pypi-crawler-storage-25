"""Opportunity type router for the ADK solution generation pipeline.

OpportunityRouter reads opportunity_type from ADK session state and dispatches
to the appropriate specialist agent. Passes all events from the chosen
specialist back to the caller.

Phase 3 supports:
    - storage_billing_optimization → StorageBillingSolver (deterministic DDL)
    - all other types             → GeneralSolver (LLM-based fallback)

Phase 4 adds join_explosion, shuffle_spill, partition_pruning, slot_contention
specialists (each with a ParallelContextGatherer + focused instruction pipeline).
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any

from google.adk.agents import BaseAgent

from app.agents.specialists.general import GeneralSolver
from app.agents.specialists.storage_billing import StorageBillingSolver

if TYPE_CHECKING:
    from google.adk.agents.invocation_context import InvocationContext

logger = logging.getLogger("app.agents.router")

# Opportunity types handled by deterministic specialists (no LLM needed)
_STORAGE_BILLING_TYPES = frozenset({"storage_billing_optimization"})

# Opportunity types with dedicated focused specialists (Phase 4)
_SPECIALIST_TYPES = frozenset(
    {"join_explosion", "shuffle_spill", "partition_pruning", "slot_contention"}
)


class OpportunityRouter(BaseAgent):
    """Routes opportunities to the appropriate specialist pipeline.

    Dispatches based on opportunity_type read from ADK session state:
    - storage_billing_optimization → StorageBillingSolver
    - join_explosion               → JoinExplosionPipeline specialist
    - shuffle_spill                → ShuffleSpillPipeline specialist
    - partition_pruning            → PartitionPruningPipeline specialist
    - slot_contention              → SlotContentionPipeline specialist
    - all other types              → GeneralSolver (fallback)

    Typed instance attributes are declared as Pydantic fields and must also
    appear in sub_agents to register them in the ADK agent tree.
    """

    model_config = {"arbitrary_types_allowed": True, "extra": "forbid"}

    general_solver: GeneralSolver
    storage_billing_solver: StorageBillingSolver
    # Phase 4 specialist pipelines (optional — None when not yet instantiated)
    join_explosion_pipeline: Any = None
    shuffle_spill_pipeline: Any = None
    partition_pruning_pipeline: Any = None
    slot_contention_pipeline: Any = None

    async def _run_async_impl(self, ctx: "InvocationContext"):
        opportunity_type: str = ctx.session.state.get("opportunity_type", "")

        if opportunity_type in _STORAGE_BILLING_TYPES:
            specialist = self.storage_billing_solver
            logger.info(
                "Routing opportunity_type=%r → StorageBillingSolver", opportunity_type
            )
        elif (
            opportunity_type == "join_explosion"
            and self.join_explosion_pipeline is not None
        ):
            specialist = self.join_explosion_pipeline
            logger.info(
                "Routing opportunity_type=%r → JoinExplosionPipeline", opportunity_type
            )
        elif (
            opportunity_type == "shuffle_spill"
            and self.shuffle_spill_pipeline is not None
        ):
            specialist = self.shuffle_spill_pipeline
            logger.info(
                "Routing opportunity_type=%r → ShuffleSpillPipeline", opportunity_type
            )
        elif (
            opportunity_type == "partition_pruning"
            and self.partition_pruning_pipeline is not None
        ):
            specialist = self.partition_pruning_pipeline
            logger.info(
                "Routing opportunity_type=%r → PartitionPruningPipeline",
                opportunity_type,
            )
        elif (
            opportunity_type == "slot_contention"
            and self.slot_contention_pipeline is not None
        ):
            specialist = self.slot_contention_pipeline
            logger.info(
                "Routing opportunity_type=%r → SlotContentionPipeline", opportunity_type
            )
        else:
            specialist = self.general_solver
            logger.info(
                "Routing opportunity_type=%r → GeneralSolver (fallback)",
                opportunity_type,
            )

        async for event in specialist.run_async(ctx):
            yield event
