"""Specialist agent implementations."""
