"""General-purpose solution solver using the existing GeminiProvider.

GeneralSolver is the fallback specialist for all opportunity types that don't
have a dedicated specialist pipeline. It replicates the existing monolithic
LLM behaviour by reading all context from ADK session state, building a
SolutionRequest, and calling the injected LLMProvider synchronously via
asyncio.to_thread() to remain non-blocking in the ADK async event loop.
"""

from __future__ import annotations

import asyncio
import json
import logging
from typing import TYPE_CHECKING, Any

from google.adk.agents import BaseAgent
from google.adk.events import Event, EventActions

from app.solutions.exceptions import LLMRequestError, LLMResponseValidationError

if TYPE_CHECKING:
    from google.adk.agents.invocation_context import InvocationContext

logger = logging.getLogger("app.agents.specialists.general")


class GeneralSolver(BaseAgent):
    """Fallback specialist that calls the existing GeminiProvider.

    Reads all context from ADK session state, builds a SolutionRequest,
    calls the injected LLMProvider, and writes solution_json and
    generation_metadata_json to session state via EventActions.state_delta.
    """

    model_config = {"arbitrary_types_allowed": True, "extra": "forbid"}

    # LLMProvider typed as Any to avoid Pydantic serialization issues with ABC
    llm_provider: Any

    async def _run_async_impl(self, ctx: "InvocationContext"):
        state = ctx.session.state

        # Build SolutionRequest from session state
        request = _build_request_from_state(state)

        # Call LLM provider via thread to avoid blocking the ADK event loop
        try:
            response, metadata = await asyncio.to_thread(
                self.llm_provider.generate, request
            )
        except (LLMRequestError, LLMResponseValidationError) as exc:
            logger.error("GeneralSolver LLM call failed: %s", exc)
            raise

        # Serialize response and metadata to JSON strings for state storage
        solution_json = response.model_dump_json()
        metadata_json = metadata.model_dump_json()

        logger.info(
            "GeneralSolver completed: category=%s, tokens=%d",
            response.resolution_category,
            metadata.total_tokens,
        )

        # Persist to session state via EventActions (ensures state survives invocation)
        yield Event(
            invocation_id=ctx.invocation_id,
            author=self.name,
            actions=EventActions(
                state_delta={
                    "raw_solution_json": solution_json,
                    "solution_json": solution_json,
                    "generation_metadata_json": metadata_json,
                }
            ),
        )


def _build_request_from_state(state: dict[str, Any]) -> Any:
    """Reconstruct a SolutionRequest from ADK session state.

    Decodes all JSON-encoded fields back to their native Python types.
    Returns a SolutionRequest ready for LLMProvider.generate().
    """
    from app.llm.schemas import SolutionRequest

    def _load_json(key: str, default: Any = None) -> Any:
        raw = state.get(key)
        if not raw:
            return default
        try:
            return json.loads(raw)
        except (json.JSONDecodeError, TypeError):
            return default

    return SolutionRequest(
        opportunity_type=state.get("opportunity_type", ""),
        affected_table=state.get("affected_table", ""),
        severity_score=state.get("severity_score", 0),
        evidence_snapshot=_load_json("evidence_snapshot_json", {}),
        explanation=state.get("explanation", ""),
        dbt_model_name=state.get("dbt_model_name"),
        source_files=_load_json("source_files_json"),
        manifest_metadata=_load_json("manifest_metadata_json"),
        compiled_sql=state.get("compiled_sql") or None,
        upstream_models=_load_json("upstream_models_json"),
        bigquery_job_samples=_load_json("job_samples_json"),
        dry_run_baseline=_load_json("dry_run_baseline_json"),
        lineage_candidates=_load_json("lineage_candidates_json"),
        lineage_notes=_load_json("lineage_notes_json"),
        column_types=_load_json("column_types_json"),
        allowed_solution_policy_tags=_load_json("allowed_solution_policy_tags_json"),
    )
