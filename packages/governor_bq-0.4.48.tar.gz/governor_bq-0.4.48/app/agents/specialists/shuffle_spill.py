"""Shuffle spill specialist pipeline (spec 052)."""

from __future__ import annotations

from typing import Any

from google.adk.agents import SequentialAgent


def build_shuffle_spill_pipeline(
    llm_provider: Any,
    github_client: Any = None,
    db_session: Any = None,
    db_session_factory: Any = None,
) -> SequentialAgent:
    """Build the ShuffleSpillPipeline specialist."""
    from app.agents.prompts.shuffle_spill import SHUFFLE_SPILL_INSTRUCTION
    from app.agents.specialists.base import build_specialist_pipeline

    return build_specialist_pipeline(
        name="ShuffleSpillPipeline",
        specialist_instruction=SHUFFLE_SPILL_INSTRUCTION,
        llm_provider=llm_provider,
        github_client=github_client,
        db_session=db_session,
        db_session_factory=db_session_factory,
    )
