"""Storage billing optimization specialist — deterministic DDL generator.

StorageBillingSolver produces the ALTER SCHEMA DDL for switching dataset
storage billing from LOGICAL to PHYSICAL, using identical logic to
SwitchStorageBillingTemplate. No LLM invocation — fully deterministic.
"""

from __future__ import annotations

import json
import logging
from typing import TYPE_CHECKING

from google.adk.agents import BaseAgent
from google.adk.events import Event, EventActions

if TYPE_CHECKING:
    from google.adk.agents.invocation_context import InvocationContext

logger = logging.getLogger("app.agents.specialists.storage_billing")


class StorageBillingSolver(BaseAgent):
    """Deterministic DDL generator for storage billing optimization.

    Generates ALTER SCHEMA ... SET OPTIONS(storage_billing_model='PHYSICAL')
    DDL from evidence data in session state — no LLM call needed.
    Output is written to solution_json and generation_metadata_json in state.
    Produces the same result as SwitchStorageBillingTemplate for identical input.
    """

    async def _run_async_impl(self, ctx: "InvocationContext"):
        state = ctx.session.state

        evidence: dict = {}
        raw = state.get("evidence_snapshot_json")
        if raw:
            try:
                evidence = json.loads(raw)
            except (json.JSONDecodeError, TypeError):
                evidence = {}

        affected_table: str = state.get("affected_table", "")
        dataset = evidence.get("dataset", affected_table)
        dataset_short = dataset.split(".")[-1] if "." in dataset else dataset

        # Build the same explanation as SwitchStorageBillingTemplate
        compression_ratio = evidence.get("compression_ratio", "N/A")
        logical_cost = evidence.get("logical_cost_monthly", 0)
        physical_cost = evidence.get("physical_cost_monthly", 0)
        monthly_savings = evidence.get("monthly_savings", 0)
        annual_savings = evidence.get("annual_savings", 0)
        savings_pct = evidence.get("savings_percentage", 0)
        table_count = evidence.get("table_count")
        table_count_text = f" ({table_count} tables)" if table_count else ""

        ddl = f"ALTER SCHEMA `{dataset_short}` SET OPTIONS (storage_billing_model = 'PHYSICAL')"
        rollback_ddl = f"ALTER SCHEMA `{dataset_short}` SET OPTIONS (storage_billing_model = 'LOGICAL')"

        explanation = (
            f"Switch dataset '{dataset_short}'{table_count_text} from logical to physical storage billing.\n\n"
            f"**Current cost**: ${logical_cost}/month (logical billing)\n"
            f"**Projected cost**: ${physical_cost}/month (physical billing)\n"
            f"**Monthly savings**: ${monthly_savings}/month ({savings_pct}% reduction)\n"
            f"**Annual savings**: ${annual_savings}/year\n"
            f"**Compression ratio**: {compression_ratio}:1\n\n"
            f"**DDL command**:\n```sql\n{ddl}\n```\n\n"
            f"This change does not affect query performance or data access. "
            f"It only changes how storage is billed. The change is fully reversible."
        )

        solution = {
            "resolution_category": "bigquery_infrastructure",
            "explanation": explanation,
            "risk_level": "low",
            "risk_justification": (
                "Generated from pre-validated template. "
                "Deterministic DDL change, fully reversible."
            ),
            "setting_recommendation": {
                "current_value": "LOGICAL",
                "recommended_value": "PHYSICAL",
                "affected_resource": dataset,
            },
            # Store rollback DDL in evidence for later reference
            "_rollback_ddl": rollback_ddl,
        }

        metadata = {
            "provider": "template",
            "model": "switch_storage_billing",
            "prompt_tokens": 0,
            "completion_tokens": 0,
            "total_tokens": 0,
            "latency_ms": 0,
        }

        logger.info(
            "StorageBillingSolver generated DDL for dataset '%s'", dataset_short
        )

        yield Event(
            invocation_id=ctx.invocation_id,
            author=self.name,
            actions=EventActions(
                state_delta={
                    "solution_json": json.dumps(solution),
                    "generation_metadata_json": json.dumps(metadata),
                }
            ),
        )
