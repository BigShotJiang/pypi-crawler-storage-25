"""Specialist agent prompt instructions."""
