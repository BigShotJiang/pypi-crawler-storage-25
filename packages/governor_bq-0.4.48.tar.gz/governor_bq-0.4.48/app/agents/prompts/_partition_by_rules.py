"""Shared partition_by data-type rules injected into every specialist prompt.

Any specialist that might add partition_by or incremental filters MUST include
these rules so the LLM generates the correct dbt config for BigQuery.
"""

from __future__ import annotations

PARTITION_BY_RULES = """
## CRITICAL: partition_by data type must match the ACTUAL output column type
BigQuery rejects partition configs when the data type is wrong. You MUST check the actual column data type and use the correct dbt partition_by format:

- **DATE column** → `partition_by={"field": "col", "data_type": "date"}`
- **TIMESTAMP column** → `partition_by={"field": "col", "data_type": "timestamp", "granularity": "day"}`
- **DATETIME column** → `partition_by={"field": "col", "data_type": "datetime", "granularity": "day"}`

NEVER use `"data_type": "date"` on a TIMESTAMP or DATETIME column — BigQuery will reject it with:
> PARTITION BY expression must be DATE(...), TIMESTAMP_TRUNC(...), etc.

### Aliasing does NOT change the type
`timestamp_col AS new_name` produces a TIMESTAMP, not a DATE. If you want to partition by DATE on a TIMESTAMP source column, you MUST explicitly cast it:
```sql
DATE(timestamp_col) as date_col
```
Then use `partition_by={"field": "date_col", "data_type": "date"}`.

### Incremental filters must also match types
BigQuery rejects `TIMESTAMP >= DATE` comparisons. When adding `{% if is_incremental() %}` filters, ensure BOTH sides have the same type:
- If the source column is TIMESTAMP: `and timestamp_col >= TIMESTAMP(DATE_SUB(CURRENT_DATE(), INTERVAL 7 DAY))`
- If the partition column was cast to DATE: `and DATE(timestamp_col) >= DATE_SUB(CURRENT_DATE(), INTERVAL 7 DAY)`
- NEVER compare a TIMESTAMP column directly to `DATE_SUB(CURRENT_DATE(), ...)` or `max(date_column)` without casting.
""".strip()

__all__ = ["PARTITION_BY_RULES"]
