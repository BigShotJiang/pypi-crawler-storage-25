"""General-purpose solution generation prompt instructions.

Re-exports SYSTEM_INSTRUCTION and build_prompt from app.solutions.prompts
so that app/agents/ code uses a stable import path while the original
module remains as the single source of truth.
"""

from __future__ import annotations

from app.solutions.prompts import (
    SYSTEM_INSTRUCTION,
    VERIFICATION_INSTRUCTION,
    build_prompt,
    build_verification_prompt,
)

__all__ = [
    "SYSTEM_INSTRUCTION",
    "VERIFICATION_INSTRUCTION",
    "build_prompt",
    "build_verification_prompt",
]
