"""ADK tool functions for the solution generation pipeline.

Tool functions are plain Python callables registered with LlmAgent(tools=[...]).
Each tool reads input from tool_context.state, calls existing Governor services,
and writes results back to tool_context.state.

Tools are not called directly by this module — they are registered with
LlmAgent instances in app/agents/specialists/.

Two categories:
  - Context-gathering tools: fetch data and write to state
  - Validation tool: validate draft solution and signal loop exit
"""

from __future__ import annotations

import json
import logging
from contextlib import contextmanager
from typing import TYPE_CHECKING, Any

import yaml
from google.cloud.exceptions import GoogleCloudError
from sqlalchemy.exc import SQLAlchemyError
from sqlglot.errors import SqlglotError

from app.github.client import (
    GitHubAuthenticationError,
    GitHubConnectionError,
    GitHubRateLimitError,
)
from app.solutions.validation.ast_validator import ParseError

if TYPE_CHECKING:
    from app.github.client import GitHubAppClient

logger = logging.getLogger("app.agents.tools")

# Maximum file size to store in session state (matches existing behaviour)
_MAX_FILE_BYTES = 20 * 1024  # 20KB per file
_MAX_SQL_BYTES = 10 * 1024  # 10KB for compiled SQL


@contextmanager
def _db_session_scope(tool_context: Any):
    """Open a fresh DB session per tool invocation when a factory is available."""
    db_session_factory = tool_context.state.get("_db_session_factory")
    db_session = tool_context.state.get("_db_session")

    if db_session_factory is None:
        yield db_session
        return

    session = db_session_factory()
    try:
        yield session
    finally:
        session.close()


# ---------------------------------------------------------------------------
# Context-gathering tool functions
# These receive a ToolContext (or MockToolContext in tests) as their last arg.
# ADK passes tool_context automatically when the function is registered as a tool.
# ---------------------------------------------------------------------------


def fetch_source_files(file_paths_json: str, tool_context: Any) -> dict:
    """Retrieve source files from GitHub for the dbt model.

    Args:
        file_paths_json: JSON-encoded list[str] of relative file paths.
        tool_context: ADK context; reads repo_slug, commit_sha, dbt_prefix from state.
                      Also reads _github_client from state (injected by context gatherer).

    Returns:
        {"status": "success", "file_count": int} on success.
        {"status": "error", "message": str} on GitHub failure (non-fatal).
    Side effect: writes source_files_json to tool_context.state.
    """
    try:
        file_paths: list[str] = json.loads(file_paths_json) if file_paths_json else []
    except (json.JSONDecodeError, TypeError):
        file_paths = []

    repo_slug: str | None = tool_context.state.get("repo_slug")
    commit_sha: str | None = tool_context.state.get("commit_sha")
    dbt_prefix: str = tool_context.state.get("dbt_prefix") or ""

    github_client: "GitHubAppClient | None" = tool_context.state.get("_github_client")

    if not github_client or not repo_slug or not file_paths:
        tool_context.state["source_files_json"] = json.dumps({})
        return {"status": "success", "file_count": 0}

    from app.github.client import GitHubFileNotFoundError

    result: dict[str, str] = {}
    for path in file_paths:
        prefixed = f"{dbt_prefix}/{path}" if dbt_prefix else path
        try:
            content = github_client.get_file_content(
                repo_slug, prefixed, ref=commit_sha
            )
            # Truncate large files to avoid bloating session state
            if len(content.encode("utf-8")) > _MAX_FILE_BYTES:
                content = content[:_MAX_FILE_BYTES] + "\n# [truncated]"
            result[path] = content
        except GitHubFileNotFoundError:
            logger.warning(
                "File not found in repo, skipping: %s/%s", repo_slug, prefixed
            )
            continue
        except (
            GitHubConnectionError,
            GitHubAuthenticationError,
            GitHubRateLimitError,
        ) as exc:
            error_msg = f"Failed to retrieve {prefixed} from {repo_slug}: {exc}"
            logger.error(error_msg)
            return {"status": "error", "message": error_msg}

    tool_context.state["source_files_json"] = json.dumps(result)
    return {"status": "success", "file_count": len(result)}


def fetch_compiled_sql(tool_context: Any) -> dict:
    """Retrieve compiled SQL for the affected dbt model from the manifest.

    Args:
        tool_context: reads manifest_version_id, dbt_model_name, config_id from state.
                      Also reads _db_session from state (injected by context gatherer).

    Returns:
        {"status": "success", "has_sql": bool}
    Side effect: writes compiled_sql to tool_context.state.
    """
    manifest_version_id: str | None = tool_context.state.get("manifest_version_id")
    dbt_model_name: str | None = tool_context.state.get("dbt_model_name")
    config_id: str | None = tool_context.state.get("config_id")
    project_id: str | None = tool_context.state.get("project_id")

    if not manifest_version_id or not dbt_model_name:
        tool_context.state["compiled_sql"] = ""
        return {"status": "success", "has_sql": False}

    with _db_session_scope(tool_context) as db_session:
        if not db_session:
            tool_context.state["compiled_sql"] = ""
            return {"status": "success", "has_sql": False}

        try:
            from app.dbt.context_builder import build_enriched_context

            ctx = build_enriched_context(
                db=db_session,
                manifest_version_id=manifest_version_id,
                dbt_model_name=dbt_model_name,
                config_id=config_id,
                gcp_project=project_id,
            )
            sql = ctx.compiled_sql if ctx else None
            if sql and len(sql.encode("utf-8")) > _MAX_SQL_BYTES:
                sql = sql[:_MAX_SQL_BYTES] + "\n-- [truncated]"
            tool_context.state["compiled_sql"] = sql or ""
            return {"status": "success", "has_sql": bool(sql)}
        except (SQLAlchemyError, KeyError, TypeError) as exc:
            logger.warning("fetch_compiled_sql failed: %s", exc)
            tool_context.state["compiled_sql"] = ""
            return {"status": "success", "has_sql": False}


def fetch_upstream_models(tool_context: Any) -> dict:
    """Run lineage analysis to find upstream fix candidates.

    Args:
        tool_context: reads manifest_version_id, dbt_model_name,
                      opportunity_type, compiled_sql from state.
                      Also reads _db_session from state (injected by context gatherer).

    Returns:
        {"status": "success", "candidate_count": int}
    Side effect: writes upstream_models_json to tool_context.state.
    """
    manifest_version_id: str | None = tool_context.state.get("manifest_version_id")
    dbt_model_name: str | None = tool_context.state.get("dbt_model_name")
    opportunity_type: str = tool_context.state.get("opportunity_type", "")
    compiled_sql: str | None = tool_context.state.get("compiled_sql")

    _UPSTREAM_FIX_TYPES = frozenset(
        {"shuffle_spill", "join_explosion", "slot_contention"}
    )
    if not dbt_model_name or opportunity_type not in _UPSTREAM_FIX_TYPES:
        # No lineage analysis for this opportunity type
        return {"status": "success", "candidate_count": 0}

    if not manifest_version_id:
        return {"status": "success", "candidate_count": 0}

    with _db_session_scope(tool_context) as db_session:
        if not db_session:
            return {"status": "success", "candidate_count": 0}

        try:
            from app.dbt.lineage_analyzer import analyze_upstream

            # Get manifest content from DB
            from app.sync.models import ManifestVersion
            import json as _json

            mv = db_session.get(ManifestVersion, manifest_version_id)
            if not mv:
                return {"status": "success", "candidate_count": 0}

            manifest_content: dict = {}
            if hasattr(mv, "content") and mv.content:
                manifest_content = (
                    _json.loads(mv.content)
                    if isinstance(mv.content, str)
                    else mv.content
                )

            if not manifest_content:
                return {"status": "success", "candidate_count": 0}

            # Build column lookup from INFORMATION_SCHEMA data
            _column_lookup = None
            config_id: str | None = tool_context.state.get("config_id")
            if config_id:
                try:
                    from app.dbt.column_lookup import make_column_lookup

                    _column_lookup = make_column_lookup(
                        db=db_session,
                        config_id=config_id,
                    )
                except (SQLAlchemyError, ValueError, TypeError):
                    pass

            # Build column quality lookup for join key profiling (spec 065)
            _quality_lookup = None
            project_id: str | None = tool_context.state.get("project_id")
            if project_id:
                try:
                    from app.dbt.column_profiler import make_column_quality_lookup

                    _quality_lookup = make_column_quality_lookup(
                        project_id=project_id,
                    )
                except (GoogleCloudError, ValueError, TypeError):
                    pass

            lineage_result = analyze_upstream(
                manifest_content=manifest_content,
                affected_model_name=dbt_model_name,
                opportunity_type=opportunity_type,
                compiled_sql=compiled_sql or None,
                column_lookup=_column_lookup,
                column_quality_lookup=_quality_lookup,
            )

            candidates = [
                {
                    "name": c.name,
                    "unique_id": c.unique_id,
                    "original_file_path": c.original_file_path,
                    "materialized": c.materialized,
                    "current_cluster_by": c.current_cluster_by,
                    "current_partition_by": c.current_partition_by,
                    "suggested_cluster_columns": c.suggested_cluster_columns,
                    "reason": c.reason,
                    **(
                        {"column_quality": c.column_quality}
                        if getattr(c, "column_quality", None)
                        else {}
                    ),
                }
                for c in lineage_result.candidates
            ]
            tool_context.state["upstream_models_json"] = json.dumps(candidates)

            for note in lineage_result.analysis_notes:
                logger.debug("Lineage note: %s", note)

            return {"status": "success", "candidate_count": len(candidates)}
        except (SQLAlchemyError, json.JSONDecodeError, KeyError, TypeError, ValueError) as exc:
            logger.warning("fetch_upstream_models failed: %s", exc)
            return {"status": "success", "candidate_count": 0}


def fetch_manifest_metadata(tool_context: Any) -> dict:
    """Extract manifest metadata for the affected model.

    Args:
        tool_context: reads manifest_version_id, dbt_model_name from state.
                      Also reads _db_session from state.

    Returns:
        {"status": "success"}
    Side effect: writes manifest_metadata_json to tool_context.state.
    """
    manifest_version_id: str | None = tool_context.state.get("manifest_version_id")
    dbt_model_name: str | None = tool_context.state.get("dbt_model_name")

    if not manifest_version_id or not dbt_model_name:
        tool_context.state["manifest_metadata_json"] = json.dumps(None)
        return {"status": "success"}

    with _db_session_scope(tool_context) as db_session:
        if not db_session:
            tool_context.state["manifest_metadata_json"] = json.dumps(None)
            return {"status": "success"}

        try:
            from app.sync.models import ManifestVersion
            import json as _json

            mv = db_session.get(ManifestVersion, manifest_version_id)
            if not mv:
                tool_context.state["manifest_metadata_json"] = json.dumps(None)
                return {"status": "success"}

            manifest_content: dict = {}
            if hasattr(mv, "content") and mv.content:
                manifest_content = (
                    _json.loads(mv.content)
                    if isinstance(mv.content, str)
                    else mv.content
                )

            metadata = _extract_manifest_metadata(dbt_model_name, manifest_content)
            tool_context.state["manifest_metadata_json"] = json.dumps(
                metadata, default=str
            )
            return {"status": "success"}
        except (SQLAlchemyError, json.JSONDecodeError, KeyError, TypeError) as exc:
            logger.warning("fetch_manifest_metadata failed: %s", exc)
            tool_context.state["manifest_metadata_json"] = json.dumps(None)
            return {"status": "success"}


def fetch_column_types(tool_context: Any) -> dict:
    """Fetch BigQuery column types from INFORMATION_SCHEMA for the affected model.

    Reads config_id and dbt_model_name from state and queries
    TableColumnMetadata to build a {column_name: BQ_DATA_TYPE} map.

    Side effect: writes column_types_json to tool_context.state.
    """
    config_id: str | None = tool_context.state.get("config_id")
    affected_table: str | None = tool_context.state.get("affected_table")

    if not config_id or not affected_table:
        tool_context.state["column_types_json"] = json.dumps(None)
        return {"status": "success", "column_count": 0}

    with _db_session_scope(tool_context) as db_session:
        if not db_session:
            tool_context.state["column_types_json"] = json.dumps(None)
            return {"status": "success", "column_count": 0}

        try:
            from app.sync.models import TableColumnMetadata

            # affected_table is "project.dataset.table"
            parts = affected_table.split(".")
            if len(parts) >= 3:
                dataset = parts[-2]
                table_name = parts[-1]
            elif len(parts) == 2:
                dataset, table_name = parts
            else:
                tool_context.state["column_types_json"] = json.dumps(None)
                return {"status": "success", "column_count": 0}

            rows = (
                db_session.query(
                    TableColumnMetadata.column_name, TableColumnMetadata.data_type
                )
                .filter(
                    TableColumnMetadata.config_id == config_id,
                    TableColumnMetadata.dataset_name == dataset,
                    TableColumnMetadata.table_name == table_name,
                )
                .all()
            )

            if not rows:
                tool_context.state["column_types_json"] = json.dumps(None)
                return {"status": "success", "column_count": 0}

            col_types = {row[0]: row[1].upper() for row in rows}
            tool_context.state["column_types_json"] = json.dumps(col_types)
            logger.info(
                "Fetched %d column types for %s.%s",
                len(col_types),
                dataset,
                table_name,
            )
            return {"status": "success", "column_count": len(col_types)}
        except (SQLAlchemyError, KeyError, TypeError) as exc:
            logger.warning("fetch_column_types failed: %s", exc)
            tool_context.state["column_types_json"] = json.dumps(None)
            return {"status": "success", "column_count": 0}


def fetch_job_samples(tool_context: Any) -> dict:
    """Retrieve BigQuery job samples for the affected model from the DB.

    Args:
        tool_context: reads opportunity_id from state.
                      Also reads _db_session from state.

    Returns:
        {"status": "success", "sample_count": int}
    Side effect: writes job_samples_json to tool_context.state.
    """
    opportunity_id: str | None = tool_context.state.get("opportunity_id")

    if not opportunity_id:
        tool_context.state["job_samples_json"] = json.dumps([])
        return {"status": "success", "sample_count": 0}

    with _db_session_scope(tool_context) as db_session:
        if not db_session:
            tool_context.state["job_samples_json"] = json.dumps([])
            return {"status": "success", "sample_count": 0}

        try:
            from app.dbt.context_builder import build_enriched_context

            manifest_version_id: str | None = tool_context.state.get(
                "manifest_version_id"
            )
            dbt_model_name: str | None = tool_context.state.get("dbt_model_name")
            config_id: str | None = tool_context.state.get("config_id")
            project_id: str | None = tool_context.state.get("project_id")

            ctx = build_enriched_context(
                db=db_session,
                manifest_version_id=manifest_version_id,
                dbt_model_name=dbt_model_name,
                config_id=config_id,
                gcp_project=project_id,
            )
            samples = ctx.job_samples if ctx else []
            tool_context.state["job_samples_json"] = json.dumps(samples, default=str)
            return {"status": "success", "sample_count": len(samples)}
        except (SQLAlchemyError, KeyError, TypeError) as exc:
            logger.warning("fetch_job_samples failed: %s", exc)
            tool_context.state["job_samples_json"] = json.dumps([])
            return {"status": "success", "sample_count": 0}


# ---------------------------------------------------------------------------
# Validation tool
# ---------------------------------------------------------------------------


def validate_and_maybe_exit(tool_context: Any) -> dict:
    """Validate the draft solution in state and signal loop exit if valid.

    Reads raw_solution_json and source_files_json from state.
    Runs compare_sql() / compare_yaml() from app.solutions.validation.
    If valid:
      - Sets tool_context.actions.escalate = True (exits LoopAgent)
      - Writes validation_passed = True, validation_report_json to state
      - Copies raw_solution_json → solution_json
    If invalid:
      - Writes validation_passed = False, validation_feedback to state
      - Increments retry_count in state

    Returns:
        {"status": "valid" | "invalid", "issues": list[str]}
    """
    raw_solution_json: str | None = tool_context.state.get("raw_solution_json")
    if not raw_solution_json:
        tool_context.state["validation_passed"] = False
        tool_context.state["validation_feedback"] = (
            "No solution was generated (raw_solution_json missing)."
        )
        tool_context.state["retry_count"] = tool_context.state.get("retry_count", 0) + 1
        return {"status": "invalid", "issues": ["raw_solution_json missing"]}

    try:
        solution_dict = json.loads(raw_solution_json)
    except (json.JSONDecodeError, TypeError) as exc:
        feedback = f"Solution JSON is malformed: {exc}"
        tool_context.state["validation_passed"] = False
        tool_context.state["validation_feedback"] = feedback
        tool_context.state["retry_count"] = tool_context.state.get("retry_count", 0) + 1
        return {"status": "invalid", "issues": [feedback]}

    source_files_raw = tool_context.state.get("source_files_json")
    source_files: dict[str, str] = {}
    if source_files_raw:
        try:
            source_files = json.loads(source_files_raw)
        except (json.JSONDecodeError, TypeError):
            pass

    opportunity_type: str = tool_context.state.get("opportunity_type", "")
    issues: list[str] = []

    # Validate each file change
    file_changes = solution_dict.get("file_changes") or []
    for fc in file_changes:
        file_path = fc.get("file_path", "")
        after_content = fc.get("after_content", "")
        before_content = fc.get("before_content") or source_files.get(file_path)

        if not after_content:
            issues.append(f"{file_path}: after_content is empty")
            continue

        if not before_content:
            # No original to compare against — accept as-is
            continue

        if before_content == after_content:
            issues.append(
                f"{file_path}: after_content is identical to before_content (no change)"
            )
            continue

        file_issues = _validate_file_change(
            file_path, before_content, after_content, opportunity_type
        )
        issues.extend(file_issues)

    from app.solutions.validation.report import build_validation_report, make_step

    if issues:
        report = build_validation_report(
            steps=[make_step("ast_validation", "failure", issues=issues)],
            tier="invalid",
        )
        feedback = "Validation failed:\n" + "\n".join(f"- {i}" for i in issues)
        tool_context.state["validation_passed"] = False
        tool_context.state["validation_feedback"] = feedback
        tool_context.state["validation_report_json"] = json.dumps(report)
        tool_context.state["retry_count"] = tool_context.state.get("retry_count", 0) + 1
        return {"status": "invalid", "issues": issues}

    # Valid — escalate to exit the LoopAgent
    report = build_validation_report(
        steps=[make_step("ast_validation", "success")],
        tier="validated",
    )
    tool_context.state["validation_passed"] = True
    tool_context.state["validation_report_json"] = json.dumps(report)
    tool_context.state["solution_json"] = raw_solution_json
    tool_context.actions.escalate = True
    return {"status": "valid", "issues": []}


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _validate_file_change(
    file_path: str, before: str, after: str, opportunity_type: str
) -> list[str]:
    """Run AST/YAML validation on a single file change.

    Returns a list of issue strings (empty = valid).
    """
    issues: list[str] = []

    is_yaml = file_path.endswith((".yml", ".yaml"))
    is_sql = file_path.endswith(".sql")

    if is_yaml:
        try:
            from app.solutions.validation.yaml_validator import compare_yaml

            compare_yaml(before, after)
        except (ParseError, yaml.YAMLError) as exc:
            issues.append(f"{file_path}: YAML parse error — {exc}")
    elif is_sql:
        try:
            from app.solutions.validation.ast_validator import ParseError, compare_sql
            from app.solutions.validation.classifier import classify_change

            comparison = compare_sql(before, after)
            classification = classify_change(comparison, opportunity_type)

            from app.solutions.validation.classifier import ChangeClassification

            if classification == ChangeClassification.DESTRUCTIVE:
                issues.append(
                    f"{file_path}: destructive SQL change detected "
                    f"(columns_removed={comparison.columns_removed})"
                )
        except ParseError:
            # Jinja control flow ({% if is_incremental() %}, etc.) prevents
            # clean AST comparison.  This is expected for incremental models
            # and not fixable by the LLM — skip rather than trigger a retry.
            # The post-processing AST step (Step 8) handles this gracefully.
            pass
        except (SqlglotError, ValueError) as exc:
            issues.append(f"{file_path}: SQL parse error — {exc}")

    return issues


def _extract_manifest_metadata(
    dbt_model_name: str, manifest_content: dict
) -> dict | None:
    """Extract essential manifest metadata for a given model name.

    Only includes fields the LLM needs for solution generation — full config
    is stripped to materialization-relevant keys and columns are reduced to
    names only (column types come from INFORMATION_SCHEMA separately).
    """
    if not manifest_content or not dbt_model_name:
        return None

    # Essential config keys the LLM needs for solution generation
    _ESSENTIAL_CONFIG_KEYS = frozenset(
        {
            "materialized",
            "partition_by",
            "cluster_by",
            "incremental_strategy",
            "unique_key",
            "on_schema_change",
            "tags",
            "pre_hook",
            "post_hook",
        }
    )

    nodes = manifest_content.get("nodes", {})
    for node_key, node_data in nodes.items():
        if node_data.get("name") == dbt_model_name:
            full_config = node_data.get("config", {})
            trimmed_config = {
                k: v for k, v in full_config.items() if k in _ESSENTIAL_CONFIG_KEYS
            }

            # Only include column names — types come from INFORMATION_SCHEMA
            columns = node_data.get("columns", {})
            column_names = sorted(columns.keys()) if columns else []

            # Trim depends_on to just model references (skip macros)
            depends_on = node_data.get("depends_on", {})
            trimmed_deps = {
                "nodes": depends_on.get("nodes", []),
            }

            return {
                "unique_id": node_key,
                "name": node_data.get("name"),
                "resource_type": node_data.get("resource_type"),
                "original_file_path": node_data.get("original_file_path"),
                "config": trimmed_config,
                "depends_on": trimmed_deps,
                "column_names": column_names,
            }
    return None
