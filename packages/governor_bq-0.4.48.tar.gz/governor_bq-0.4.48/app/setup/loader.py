from __future__ import annotations

import logging

from sqlalchemy.orm import Session

from app.setup.runtime import (
    RuntimeSetupState,
    clear_runtime_setup_state,
    set_runtime_setup_state,
)

logger = logging.getLogger("app.setup")


def load_setup_state(app: object, db: Session) -> None:
    """Populate app.state with setup completion flag and cached credentials.

    Called once at lifespan startup.  Uses the DB session provided by the
    caller (not a request-scoped session).
    """
    from app.setup.models import SetupState

    state = db.query(SetupState).first()

    if state is None or not state.is_complete:
        app.state.setup_complete = False  # type: ignore[attr-defined]
        app.state.setup_step_reached = 1 if state is None else state.step_reached  # type: ignore[attr-defined]
        app.state.setup_installation_mode = "cloud"  # type: ignore[attr-defined]
        app.state.setup_gcp_auth_method = None  # type: ignore[attr-defined]
        app.state.setup_gcp_credentials = None  # type: ignore[attr-defined]
        app.state.setup_bigquery_region = None  # type: ignore[attr-defined]
        app.state.setup_github_auth_mode = None  # type: ignore[attr-defined]
        app.state.setup_github_app_id = None  # type: ignore[attr-defined]
        app.state.setup_github_installation_id = None  # type: ignore[attr-defined]
        app.state.setup_github_private_key = None  # type: ignore[attr-defined]
        app.state.setup_github_personal_access_token = None  # type: ignore[attr-defined]
        app.state.setup_llm_api_key = None  # type: ignore[attr-defined]
        clear_runtime_setup_state()
        logger.info("Setup state loaded: complete=False, step_reached=%s", app.state.setup_step_reached)
        return

    app.state.setup_complete = True  # type: ignore[attr-defined]
    app.state.setup_step_reached = state.step_reached  # type: ignore[attr-defined]
    app.state.setup_installation_mode = state.installation_mode  # type: ignore[attr-defined]

    # GCP credentials — None means "use ADC / Workload Identity at call time"
    app.state.setup_gcp_auth_method = state.gcp_auth_method  # type: ignore[attr-defined]
    if state.gcp_auth_method == "adc":
        app.state.setup_gcp_credentials = None  # type: ignore[attr-defined]
    elif state.gcp_credentials_json:
        try:
            import json

            from google.oauth2 import service_account

            info = json.loads(state.gcp_credentials_json)
            app.state.setup_gcp_credentials = (  # type: ignore[attr-defined]
                service_account.Credentials.from_service_account_info(
                    info,
                    scopes=["https://www.googleapis.com/auth/cloud-platform"],
                )
            )
        except (ValueError, KeyError, json.JSONDecodeError):
            logger.warning("Failed to build GCP credentials from setup_state")
            app.state.setup_gcp_credentials = None  # type: ignore[attr-defined]
    else:
        app.state.setup_gcp_credentials = None  # type: ignore[attr-defined]

    app.state.setup_bigquery_region = state.bigquery_region  # type: ignore[attr-defined]
    app.state.setup_github_auth_mode = state.github_auth_mode  # type: ignore[attr-defined]
    app.state.setup_github_app_id = state.github_app_id  # type: ignore[attr-defined]
    app.state.setup_github_installation_id = state.github_installation_id  # type: ignore[attr-defined]
    app.state.setup_github_private_key = state.github_private_key  # type: ignore[attr-defined]
    app.state.setup_github_personal_access_token = (  # type: ignore[attr-defined]
        state.github_personal_access_token
    )
    app.state.setup_llm_api_key = state.llm_api_key  # type: ignore[attr-defined]
    set_runtime_setup_state(
        RuntimeSetupState(
            setup_complete=bool(state.is_complete),
            installation_mode=state.installation_mode,
            gcp_auth_method=state.gcp_auth_method,
            gcp_credentials_json=state.gcp_credentials_json,
            bigquery_region=state.bigquery_region,
            github_auth_mode=state.github_auth_mode,
            github_app_id=state.github_app_id,
            github_installation_id=state.github_installation_id,
            github_private_key=state.github_private_key,
            github_personal_access_token=state.github_personal_access_token,
            llm_api_key=state.llm_api_key,
        )
    )

    logger.info("Setup state loaded: complete=%s", state.is_complete)


