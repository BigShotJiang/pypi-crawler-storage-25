from __future__ import annotations

import json
import logging

logger = logging.getLogger("app.setup")

# Maps human-readable role names to representative IAM permissions used for
# testIamPermissions checks.  These permissions are representative of what
# each role grants; testIamPermissions returns the subset the caller has.
_ROLE_PERMISSIONS: dict[str, str] = {
    "roles/bigquery.resourceViewer": "bigquery.jobs.listAll",
    "roles/bigquery.jobUser": "bigquery.jobs.create",
    "roles/storage.objectViewer": "storage.objects.get",
    "roles/resourcemanager.projectViewer": "resourcemanager.projects.get",
}


def verify_gcp_roles(credentials_json: str) -> dict[str, bool]:
    """Check whether a service account has the four required IAM roles.

    Args:
        credentials_json: Raw service account JSON string.

    Returns:
        Dict mapping each role name to True (granted) or False (missing).

    Raises:
        ValueError: If ``credentials_json`` is not valid JSON or is missing
            required fields.
        RuntimeError: If the GCP API call fails (network error, etc.).
    """
    try:
        info = json.loads(credentials_json)
    except json.JSONDecodeError as exc:
        raise ValueError(f"Invalid JSON: {exc}") from exc

    required = ("type", "project_id", "client_email")
    missing = [f for f in required if not info.get(f)]
    if missing:
        raise ValueError(
            f"Service account JSON is missing required fields: {', '.join(missing)}"
        )

    if info.get("type") != "service_account":
        raise ValueError(
            f"Expected a service_account JSON, got type={info.get('type')!r}"
        )

    project_id = info["project_id"]

    try:
        from google.oauth2 import service_account

        credentials = service_account.Credentials.from_service_account_info(
            info,
            scopes=["https://www.googleapis.com/auth/cloud-platform"],
        )
    except (ValueError, KeyError) as exc:
        raise ValueError(f"Cannot build credentials from JSON: {exc}") from exc

    permissions_to_test = list(_ROLE_PERMISSIONS.values())

    try:
        from google.api_core.exceptions import GoogleAPIError
        from google.cloud.resourcemanager_v3 import ProjectsClient
        from google.iam.v1 import iam_policy_pb2

        client = ProjectsClient(credentials=credentials)
        request = iam_policy_pb2.TestIamPermissionsRequest(
            resource=f"projects/{project_id}",
            permissions=permissions_to_test,
        )
        response = client.test_iam_permissions(request=request)
        granted_permissions = set(response.permissions)
    except GoogleAPIError as exc:
        raise RuntimeError(
            f"GCP API call failed while checking IAM permissions: {exc}"
        ) from exc

    return {
        role: (permission in granted_permissions)
        for role, permission in _ROLE_PERMISSIONS.items()
    }


def verify_gcp_roles_adc() -> dict[str, bool]:
    """Check whether the runtime's Application Default Credentials have the
    four required IAM roles.

    Suitable for Cloud Run with Workload Identity or any environment where
    ADC is pre-configured (GOOGLE_APPLICATION_CREDENTIALS env var, gcloud
    auth application-default login, metadata server, etc.).

    Returns:
        Dict mapping each role name to True (granted) or False (missing).

    Raises:
        RuntimeError: If the GCP API call fails or ADC is not available.
    """
    try:
        import google.auth
        from google.auth.exceptions import DefaultCredentialsError

        credentials, project_id = google.auth.default(
            scopes=["https://www.googleapis.com/auth/cloud-platform"]
        )
    except DefaultCredentialsError as exc:
        raise RuntimeError(
            f"No Application Default Credentials available: {exc}"
        ) from exc

    if not project_id:
        raise RuntimeError(
            "Could not determine GCP project from ADC. "
            "Set the GOOGLE_CLOUD_PROJECT environment variable."
        )

    permissions_to_test = list(_ROLE_PERMISSIONS.values())

    try:
        from google.api_core.exceptions import GoogleAPIError
        from google.cloud.resourcemanager_v3 import ProjectsClient
        from google.iam.v1 import iam_policy_pb2

        client = ProjectsClient(credentials=credentials)
        request = iam_policy_pb2.TestIamPermissionsRequest(
            resource=f"projects/{project_id}",
            permissions=permissions_to_test,
        )
        response = client.test_iam_permissions(request=request)
        granted_permissions = set(response.permissions)
    except GoogleAPIError as exc:
        raise RuntimeError(
            f"GCP API call failed while checking IAM permissions: {exc}"
        ) from exc

    return {
        role: (permission in granted_permissions)
        for role, permission in _ROLE_PERMISSIONS.items()
    }
