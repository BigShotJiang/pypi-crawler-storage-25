"""Gemini LLM provider implementation using google-genai SDK."""

from __future__ import annotations

import json
import logging
import time
from types import ModuleType
from typing import TYPE_CHECKING

from tenacity import (
    retry,
    retry_if_exception,
    stop_after_attempt,
    wait_exponential_jitter,
)

from google.genai import errors as genai_errors
from pydantic import ValidationError

from app.core.config import get_settings
from app.google_sdk_compat import apply_google_sdk_py314_compat
from app.llm.base import LLMProvider
from app.llm.schemas import (
    DDLFixResult,
    LLMMetadata,
    SolutionRequest,
    SolutionResponse,
    VerificationResult,
)
from app.solutions.exceptions import LLMRequestError, LLMResponseValidationError

if TYPE_CHECKING:
    from google import genai
    from google.genai import types as genai_types

logger = logging.getLogger("app.llm.gemini")

apply_google_sdk_py314_compat()


def _is_retryable(exc: BaseException) -> bool:
    """Check if an exception is retryable (rate limit or server error)."""
    if isinstance(exc, genai_errors.ClientError):
        return getattr(exc, "code", 0) == 429
    if isinstance(exc, genai_errors.ServerError):
        return True
    return False


class GeminiProvider(LLMProvider):
    """Gemini LLM provider using google-genai SDK with structured JSON output."""

    def __init__(
        self,
        api_key: str,
        model: str | None = None,
        temperature: float | None = None,
        max_tokens: int | None = None,
        timeout_ms: int | None = None,
        max_retries: int | None = None,
    ) -> None:
        from google import genai

        settings = get_settings()
        self._model = model or settings.llm_model
        self._temperature = (
            temperature if temperature is not None else settings.llm_temperature
        )
        self._max_tokens = max_tokens or settings.llm_max_tokens
        self._timeout_ms = timeout_ms or settings.llm_timeout_ms
        self._max_retries = max_retries or settings.llm_max_retries

        self._api_key = api_key
        self._client = genai.Client(api_key=api_key)

    def _build_http_options(self, types: ModuleType) -> genai_types.HttpOptions:
        """Build per-request HTTP options so SDK calls honor Governor timeouts."""
        return types.HttpOptions(timeout=self._timeout_ms)

    def generate(
        self, request: SolutionRequest
    ) -> tuple[SolutionResponse, LLMMetadata]:
        """Generate a solution using Gemini with structured JSON output."""
        from google.genai import types

        response_schema = SolutionResponse.model_json_schema()

        config = types.GenerateContentConfig(
            http_options=self._build_http_options(types),
            temperature=self._temperature,
            max_output_tokens=self._max_tokens,
            response_mime_type="application/json",
            response_schema=response_schema,
        )

        prompt = self._build_prompt(request)

        start_ms = time.monotonic()
        try:
            response = self._call_with_retry(prompt, config)
        except genai_errors.APIError as exc:
            raise LLMRequestError(
                f"Gemini API request failed after {self._max_retries} retries: {exc}"
            ) from exc
        latency_ms = int((time.monotonic() - start_ms) * 1000)

        # Parse response
        try:
            text = response.text
            if not text:
                raise LLMResponseValidationError("Gemini returned empty response text")
            solution = SolutionResponse.model_validate_json(text)
        except LLMResponseValidationError:
            raise
        except (json.JSONDecodeError, ValidationError, ValueError, KeyError) as exc:
            raise LLMResponseValidationError(
                f"Failed to parse Gemini response as SolutionResponse: {exc}"
            ) from exc

        # Extract token usage
        prompt_tokens = 0
        completion_tokens = 0
        total_tokens = 0
        if response.usage_metadata:
            prompt_tokens = response.usage_metadata.prompt_token_count or 0
            completion_tokens = response.usage_metadata.candidates_token_count or 0
            total_tokens = response.usage_metadata.total_token_count or 0

        metadata = LLMMetadata(
            provider="gemini",
            model=self._model,
            prompt_tokens=prompt_tokens,
            completion_tokens=completion_tokens,
            total_tokens=total_tokens,
            latency_ms=latency_ms,
        )

        logger.info(
            "Gemini generation completed",
            extra={
                "model": self._model,
                "prompt_tokens": prompt_tokens,
                "completion_tokens": completion_tokens,
                "latency_ms": latency_ms,
                "resolution_category": solution.resolution_category,
            },
        )

        return solution, metadata

    def _call_with_retry(self, prompt: str, config: genai_types.GenerateContentConfig, client: genai.Client | None = None) -> genai_types.GenerateContentResponse:
        """Call Gemini API with tenacity retry on 429/5xx errors."""
        api_client = client or self._client

        @retry(
            retry=retry_if_exception(_is_retryable),
            wait=wait_exponential_jitter(initial=1, max=60),
            stop=stop_after_attempt(self._max_retries),
            reraise=True,
        )
        def _call():
            return api_client.models.generate_content(
                model=self._model,
                contents=prompt,
                config=config,
            )

        return _call()

    def verify(
        self,
        file_path: str,
        before_content: str,
        after_content: str,
        change_context: str,
    ) -> VerificationResult:
        """Verify a proposed change using Gemini.

        Creates a fresh genai.Client to avoid stale httpx/event-loop
        state left over from the generate() call.
        """
        from google import genai
        from google.genai import types

        from app.solutions.prompts import (
            VERIFICATION_INSTRUCTION,
            build_verification_prompt,
        )

        response_schema = VerificationResult.model_json_schema()

        config = types.GenerateContentConfig(
            http_options=self._build_http_options(types),
            temperature=0.0,  # Deterministic for review
            max_output_tokens=1024,  # Verification responses are short
            response_mime_type="application/json",
            response_schema=response_schema,
            system_instruction=VERIFICATION_INSTRUCTION,
        )

        prompt = build_verification_prompt(
            file_path, before_content, after_content, change_context
        )

        verify_client = genai.Client(api_key=self._api_key)

        start_ms = time.monotonic()
        try:
            response = self._call_with_retry(prompt, config, client=verify_client)
        except genai_errors.APIError as exc:
            logger.warning(
                "Verification API call failed for %s, defaulting to unsafe: %s",
                file_path,
                exc,
            )
            return VerificationResult(
                safe=False,
                issues=[f"Verification failed: {exc}"],
            )
        latency_ms = int((time.monotonic() - start_ms) * 1000)

        try:
            text = response.text
            if not text:
                return VerificationResult(
                    safe=False, issues=["Verification returned empty response"]
                )
            result = VerificationResult.model_validate_json(text)
        except (json.JSONDecodeError, ValidationError, ValueError, KeyError) as exc:
            logger.warning(
                "Failed to parse verification response for %s: %s", file_path, exc
            )
            return VerificationResult(
                safe=False, issues=[f"Could not parse verification: {exc}"]
            )

        logger.info(
            "Verification completed for %s: safe=%s, issues=%d, latency=%dms",
            file_path,
            result.safe,
            len(result.issues),
            latency_ms,
        )
        return result

    _DDL_FIX_INSTRUCTION = (
        "You are a BigQuery dbt specialist. A proposed dbt model file failed "
        "BigQuery DDL validation (CREATE TABLE ... PARTITION BY / CLUSTER BY). "
        "Your job is to fix the file so the DDL dry-run passes.\n\n"
        "## Common errors and fixes\n"
        "- `PARTITION BY expression must be DATE/TIMESTAMP/DATETIME/INT64`: "
        "The partition_by data_type does not match the actual column type. "
        "If the column is TIMESTAMP, use `data_type: 'timestamp', granularity: 'day'` "
        "NOT `data_type: 'date'`.\n"
        "- `No matching signature for operator >= for argument types: TIMESTAMP, DATE`: "
        "An incremental filter compares TIMESTAMP to DATE. Cast both sides to the same type.\n"
        "- Aliasing (`col AS new_name`) does NOT change the BigQuery data type.\n\n"
        "## Rules\n"
        "- Return the COMPLETE corrected file content — never omit or truncate.\n"
        "- Only change what is necessary to fix the DDL error.\n"
        "- Keep all existing business logic, comments, and formatting intact.\n"
    )

    def fix_ddl_error(
        self,
        file_path: str,
        file_content: str,
        ddl_error: str,
        opportunity_type: str,
    ) -> DDLFixResult:
        """Fix a DDL validation error using Gemini."""
        from google import genai
        from google.genai import types

        response_schema = DDLFixResult.model_json_schema()

        config = types.GenerateContentConfig(
            http_options=self._build_http_options(types),
            temperature=0.0,
            max_output_tokens=self._max_tokens,
            response_mime_type="application/json",
            response_schema=response_schema,
            system_instruction=self._DDL_FIX_INSTRUCTION,
        )

        prompt = (
            f"## File: {file_path}\n"
            f"## Opportunity type: {opportunity_type}\n\n"
            f"## BigQuery DDL error\n```\n{ddl_error}\n```\n\n"
            f"## Current file content (needs fix)\n```\n{file_content}\n```\n\n"
            "Fix the file so the DDL dry-run passes. Return the complete corrected file."
        )

        fix_client = genai.Client(api_key=self._api_key)

        start_ms = time.monotonic()
        try:
            response = self._call_with_retry(prompt, config, client=fix_client)
        except genai_errors.APIError as exc:
            logger.warning(
                "DDL fix API call failed for %s: %s",
                file_path,
                exc,
            )
            return DDLFixResult(
                fixed_content=file_content,
                explanation=f"LLM fix failed: {exc}",
            )
        latency_ms = int((time.monotonic() - start_ms) * 1000)

        try:
            text = response.text
            if not text:
                return DDLFixResult(
                    fixed_content=file_content,
                    explanation="LLM returned empty response",
                )
            result = DDLFixResult.model_validate_json(text)
        except (json.JSONDecodeError, ValidationError, ValueError, KeyError) as exc:
            logger.warning(
                "Failed to parse DDL fix response for %s: %s",
                file_path,
                exc,
            )
            return DDLFixResult(
                fixed_content=file_content,
                explanation=f"Could not parse fix response: {exc}",
            )

        logger.info(
            "DDL fix completed for %s: latency=%dms, explanation=%s",
            file_path,
            latency_ms,
            result.explanation[:200],
        )
        return result

    # Maximum prompt size in bytes before we start stripping sections
    _PROMPT_BUDGET_BYTES = 150 * 1024  # 150KB

    def _build_prompt(self, request: SolutionRequest) -> str:
        """Build a prompt string from a SolutionRequest.

        Uses a budget system: core sections are always included, then
        optional sections are added in priority order until the budget is
        reached.  If the full prompt exceeds the budget, low-priority
        sections (macros, upstream SQL, lineage details) are stripped.
        """
        parts = self._build_core_parts(request)
        prompt = "\n".join(parts)

        if len(prompt.encode("utf-8")) <= self._PROMPT_BUDGET_BYTES:
            return prompt

        # Over budget — rebuild without low-priority sections
        logger.warning(
            "Prompt size %d bytes exceeds budget %d — stripping optional sections",
            len(prompt.encode("utf-8")),
            self._PROMPT_BUDGET_BYTES,
        )
        parts = self._build_core_parts(request, slim=True)
        return "\n".join(parts)

    def _build_core_parts(
        self, request: SolutionRequest, *, slim: bool = False
    ) -> list[str]:
        """Build prompt parts list.

        When slim=True, strips: upstream raw/compiled SQL (keeps summaries),
        macros, downstream dependents, and job samples to reduce size.
        """
        parts = []

        # Prepend specialist-focused instruction when provided (spec 052)
        if request.specialist_instruction:
            parts.append(request.specialist_instruction)
            parts.append("")  # blank line separator

        parts += [
            f"Opportunity Type: {request.opportunity_type}",
            f"Affected Table: {request.affected_table}",
            f"Severity Score: {request.severity_score}/100",
            f"Explanation: {request.explanation}",
            f"Evidence: {request.evidence_snapshot}",
        ]

        if request.dbt_model_name:
            parts.append(f"dbt Model Name: {request.dbt_model_name}")

        if request.source_files:
            parts.append("\n--- Source Files ---")
            for path, content in request.source_files.items():
                parts.append(f"\n### {path}\n```\n{content}\n```")

        if request.manifest_metadata:
            parts.append(f"\nManifest Metadata: {request.manifest_metadata}")

        # Job samples — skip in slim mode
        if request.bigquery_job_samples and not slim:
            parts.append(f"\nBigQuery Job Samples: {request.bigquery_job_samples}")

        # Column types from INFORMATION_SCHEMA (spec 066)
        if request.column_types:
            type_lines = "\n".join(
                f"  {col}: {dtype}"
                for col, dtype in sorted(request.column_types.items())
            )
            parts.append(
                f"\n--- BigQuery Column Types (from INFORMATION_SCHEMA) ---\n"
                f"Use these ACTUAL data types when setting partition_by. "
                f"Do NOT guess from SQL aliases.\n"
                f"```\n{type_lines}\n```"
            )

        # Enriched context fields (spec 050)
        if request.compiled_sql:
            parts.append(
                f"\n--- Compiled SQL (What BigQuery Actually Executes) ---\n"
                f"```sql\n{request.compiled_sql}\n```"
            )

        # Upstream models — summarize instead of full SQL
        if request.upstream_models:
            parts.append("\n--- Upstream Models (Direct Dependencies) ---")
            for model in request.upstream_models:
                name = model.get("name", "unknown")
                materialized = model.get("materialized", "unknown")
                config = model.get("config", {})
                partition_by = config.get("partition_by") if config else None
                cluster_by = config.get("cluster_by") if config else None

                summary = f"\n### {name} (materialized: {materialized})"
                if partition_by:
                    summary += f"\n  partition_by: {partition_by}"
                if cluster_by:
                    summary += f"\n  cluster_by: {cluster_by}"
                parts.append(summary)

                # Include SQL only in full mode, not slim
                if not slim:
                    if model.get("raw_sql"):
                        parts.append(f"```sql\n{model['raw_sql']}\n```")
                    if model.get("compiled_sql"):
                        parts.append(
                            f"Compiled:\n```sql\n{model['compiled_sql']}\n```"
                        )

        # Downstream dependents — skip in slim mode
        if request.downstream_dependents and not slim:
            parts.append("\n--- Downstream Dependents ---")
            for dep in request.downstream_dependents:
                name = dep.get("name", "unknown")
                materialized = dep.get("materialized", "unknown")
                parts.append(f"- {name} (materialized: {materialized})")

        if request.dry_run_baseline:
            bytes_processed = request.dry_run_baseline.get("total_bytes_processed", 0)
            cost_usd = request.dry_run_baseline.get("estimated_cost_usd", 0)
            parts.append(
                f"\n--- Dry-Run Baseline ---\n"
                f"Current cost: {bytes_processed:,} bytes (${cost_usd:.2f})"
            )

        # Macros — skip in slim mode
        if request.macro_summary and not slim:
            parts.append("\n--- Available Project Macros ---")
            for macro in request.macro_summary:
                name = macro.get("name", "")
                args = macro.get("arguments", [])
                args_str = ", ".join(args) if args else ""
                parts.append(f"- {name}({args_str})")

        # Lineage analysis context (spec 051)
        if request.lineage_candidates:
            parts.append("\n--- Lineage Analysis (Upstream Fix Candidates) ---")
            parts.append(
                "The following upstream models are candidates for config changes:"
            )
            for cand in request.lineage_candidates:
                name = cand.get("name", "unknown")
                materialized = cand.get("materialized", "unknown")
                suggested = cand.get("suggested_cluster_columns", [])
                current = cand.get("current_cluster_by")
                file_path = cand.get("original_file_path", "")
                reason = cand.get("reason", "")
                entry = f"\n- {name} (materialized: {materialized}"
                if current:
                    entry += f", current cluster_by: {current}"
                entry += ")"
                if suggested:
                    entry += f"\n  Suggested: cluster_by = {suggested}"
                if file_path:
                    entry += f"\n  File: {file_path}"
                if reason:
                    entry += f"\n  Reason: {reason}"
                parts.append(entry)
            parts.append(
                "\nConsider applying cluster_by to the upstream model(s) above. "
                "The fix should target the upstream model's file."
            )

        if request.allowed_solution_policy_tags is not None:
            allowed_tags = request.allowed_solution_policy_tags
            parts.extend(
                [
                    "\n--- Solution Guardrails ---",
                    f"Allowed policy tags: {allowed_tags}",
                    "You must only propose changes that stay within this allow-list.",
                ]
            )
            if "sql_change" not in allowed_tags:
                parts.append(
                    "Do not change SQL query logic, expressions, joins, filters, or selected columns."
                )
            if "dbt_config_change" not in allowed_tags:
                parts.append(
                    "Do not change dbt config-only settings such as cluster_by, partition_by, or require_partition_filter."
                )
            if "materialization_change" not in allowed_tags:
                parts.append(
                    "Do not change dbt materialization semantics such as table, view, incremental, ephemeral, or materialized config values."
                )
            if "schema_change" not in allowed_tags:
                parts.append(
                    "Do not change schema YAML, source YAML, or model property YAML files."
                )
            if "bigquery_infrastructure" not in allowed_tags:
                parts.append(
                    "Do not propose BigQuery infrastructure or non-dbt setting changes."
                )

        return parts
