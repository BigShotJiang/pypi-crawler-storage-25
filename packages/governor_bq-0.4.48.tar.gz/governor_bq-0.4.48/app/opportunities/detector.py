"""
Detection engine for cost optimization opportunities.

Orchestrates detection rules and processes detection jobs.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import TYPE_CHECKING

from opentelemetry import trace
from sqlalchemy.exc import SQLAlchemyError

from app.opportunities.catalog import (
    EffectiveRuleSelection,
    build_effective_rule_selection,
    clear_registered_rule_classes,
    get_detection_rule_catalog,
    get_registered_rule_types,
    register_detection_rule_class,
    unregister_detection_rule_class,
)
from app.opportunities.rules.base import BaseDetectionRule, OpportunityCandidate

if TYPE_CHECKING:
    from app.configurations.models import ManifestConfiguration
    from sqlalchemy.orm import Session

    from app.opportunities.models import DetectionJob
    from app.sync.models import BigQueryJob

logger = logging.getLogger(__name__)
tracer = trace.get_tracer(__name__)


@dataclass
class DetectionResult:
    """
    Result of a detection job execution.

    Contains counts and any errors encountered during detection.
    """

    found_count: int = 0
    updated_count: int = 0
    resolved_count: int = 0
    duration_ms: int = 0
    errors: list[str] = field(default_factory=list)


@dataclass(frozen=True)
class SelectedRulesForConfig:
    mode: str
    configured_rule_types: list[str]
    unknown_rule_types: list[str]
    unavailable_rule_types: list[str]
    effective_rule_types: list[str]
    effective_rules: list[BaseDetectionRule]


def select_rules_for_config(
    rules: list[BaseDetectionRule],
    config: ManifestConfiguration | None,
) -> SelectedRulesForConfig:
    watched_rule_types = config.watched_rule_types if config else None
    selection: EffectiveRuleSelection = build_effective_rule_selection(
        watched_rule_types
    )
    effective_types = set(selection.effective_rule_types)
    effective_rules = [rule for rule in rules if rule.rule_type in effective_types]
    return SelectedRulesForConfig(
        mode=selection.mode,
        configured_rule_types=selection.configured_rule_types,
        unknown_rule_types=selection.unknown_rule_types,
        unavailable_rule_types=selection.unavailable_rule_types,
        effective_rule_types=selection.effective_rule_types,
        effective_rules=effective_rules,
    )


class DetectionEngine:
    """
    Orchestrates detection rules and processes detection jobs.

    Responsible for:
    - Loading and running enabled detection rules
    - Collecting opportunities from all rules
    - Tracking detection metrics
    - Emitting OpenTelemetry spans
    """

    def __init__(self) -> None:
        """Initialize the detection engine."""
        self._rules: list[BaseDetectionRule] = []
        self._load_rules()

    def _load_rules(self) -> None:
        """Load and instantiate all enabled detection rules."""
        self._rules = []
        for entry in get_detection_rule_catalog():
            if not entry.enabled:
                logger.info("Rule %s is disabled, skipping", entry.rule_type)
                continue
            rule = entry.rule_class()
            self._rules.append(rule)
            logger.debug("Loaded rule: %s", rule.rule_type)

        logger.info("Loaded %s detection rules", len(self._rules))

    def get_enabled_rules(self) -> list[BaseDetectionRule]:
        """
        Return list of enabled detection rules.

        Returns:
            List of rule instances
        """
        return self._rules

    def run_detection(
        self,
        detection_job: DetectionJob,
        jobs: list[BigQueryJob],
        manifest_content: dict | None,
        config_id: str,
        manifest_version_id: str | None,
        db: Session,
    ) -> DetectionResult:
        """
        Execute all detection rules for a detection job.

        Manifest context is passed through to persist_opportunity() for
        manifest-scoped deduplication and traceability.
        mark_resolved() is called per config_id, not per config_id.

        Args:
            detection_job: Detection job to process
            jobs: BigQuery job records for the project
            manifest_content: dbt manifest JSON (may be None)
            config_id: Manifest location (stable identity)
            manifest_version_id: Manifest version active at detection time
            db: Database session

        Returns:
            DetectionResult with counts and errors
        """
        from app.configurations.models import ManifestConfiguration
        from app.opportunities.models import DetectionJob as DetectionJobModel
        from app.opportunities.service import OpportunityService

        start_time = datetime.now(timezone.utc)
        result = DetectionResult()
        all_candidates: list[OpportunityCandidate] = []
        detected_keys: set[tuple[str, str]] = set()

        with tracer.start_as_current_span("detection_job.process") as span:
            span.set_attribute("detection_job.id", detection_job.id)
            span.set_attribute("detection_job.config_id", detection_job.config_id)
            span.set_attribute("detection_job.config_id", config_id)
            span.set_attribute("detection_job.jobs_count", len(jobs))

            # Read rolling window settings from ManifestConfiguration
            config = db.get(ManifestConfiguration, config_id)
            lookback_window_days = 30
            resolution_period_days = 10
            if config:
                lookback_window_days = config.lookback_window_days or 30
                resolution_period_days = config.resolution_period_days or 10

            selected_rules = select_rules_for_config(self._rules, config)

            span.set_attribute(
                "detection_job.lookback_window_days", lookback_window_days
            )
            span.set_attribute(
                "detection_job.resolution_period_days", resolution_period_days
            )
            span.set_attribute("detection_job.watched_rules_mode", selected_rules.mode)
            span.set_attribute(
                "detection_job.configured_rule_types",
                ",".join(selected_rules.configured_rule_types),
            )
            span.set_attribute(
                "detection_job.effective_rule_types",
                ",".join(selected_rules.effective_rule_types),
            )
            span.set_attribute(
                "detection_job.unavailable_rule_types",
                ",".join(selected_rules.unavailable_rule_types),
            )
            span.set_attribute(
                "detection_job.unknown_rule_types",
                ",".join(selected_rules.unknown_rule_types),
            )

            service = OpportunityService(db)

            # Detect first-sync condition: no prior completed detection jobs for this config
            # We check now but run the backfill AFTER persist so opportunities exist
            from sqlalchemy import select

            is_first_sync = (
                db.execute(
                    select(DetectionJobModel).where(
                        DetectionJobModel.config_id == config_id,
                        DetectionJobModel.status == "completed",
                        DetectionJobModel.id != detection_job.id,
                    )
                )
                .scalars()
                .first()
                is None
            )
            local_run_scoped = bool(config and config.local_project_path)

            # On first sync, broaden detection to ALL historical jobs within the
            # lookback window so that every rule's opportunities are created before
            # backfill tries to attach history entries to them.
            if is_first_sync and not local_run_scoped:
                from datetime import timedelta

                from app.sync.models import BigQueryJob

                cutoff = datetime.now(timezone.utc) - timedelta(
                    days=lookback_window_days
                )
                jobs = list(
                    db.execute(
                        select(BigQueryJob).where(
                            BigQueryJob.config_id == config_id,
                            BigQueryJob.creation_time >= cutoff,
                        )
                    )
                    .scalars()
                    .all()
                )
                span.set_attribute("detection_job.first_sync_jobs_count", len(jobs))
                logger.info(
                    f"First sync for config {config_id}: broadened detection to "
                    f"{len(jobs)} jobs within {lookback_window_days}-day lookback window"
                )
            elif is_first_sync and local_run_scoped:
                logger.info(
                    "First sync for local config %s: keeping detection scoped to the triggering sync only",
                    config_id,
                )

            # Load storage metrics for StorageBillingRule
            from app.sync.models import (
                SyncOperation,
                TableColumnMetadata,
                TableStorageMetric,
            )

            storage_metrics = list(
                db.execute(
                    select(TableStorageMetric).where(
                        TableStorageMetric.config_id == config_id,
                    )
                )
                .scalars()
                .all()
            )
            span.set_attribute(
                "detection_job.storage_metrics_count", len(storage_metrics)
            )

            sync_operation = db.get(SyncOperation, detection_job.sync_id)
            run_results_json = (
                sync_operation.run_results_json if sync_operation is not None else None
            )
            local_evidence_mode = (
                sync_operation.local_evidence_mode
                if sync_operation is not None
                else None
            )
            table_columns = list(
                db.execute(
                    select(TableColumnMetadata).where(
                        TableColumnMetadata.config_id == config_id,
                    )
                )
                .scalars()
                .all()
            )
            span.set_attribute(
                "detection_job.has_run_results",
                bool(run_results_json),
            )
            span.set_attribute(
                "detection_job.local_evidence_mode",
                local_evidence_mode or "none",
            )
            span.set_attribute(
                "detection_job.table_column_count",
                len(table_columns),
            )

            # Run each detection rule
            logger.info(
                "Detection rule selection for config %s: mode=%s configured=%s effective=%s unavailable=%s unknown=%s",
                config_id,
                selected_rules.mode,
                selected_rules.configured_rule_types,
                selected_rules.effective_rule_types,
                selected_rules.unavailable_rule_types,
                selected_rules.unknown_rule_types,
            )

            for rule in selected_rules.effective_rules:
                with tracer.start_as_current_span(
                    f"detection_rule.{rule.rule_type}"
                ) as rule_span:
                    rule_span.set_attribute("rule.type", rule.rule_type)
                    rule_span.set_attribute("rule.jobs_analyzed", len(jobs))

                    try:
                        thresholds = rule.get_thresholds()
                        # Inject storage metrics and per-config threshold for StorageBillingRule
                        if rule.rule_type == "storage_billing_optimization":
                            thresholds["_storage_metrics"] = storage_metrics
                            if (
                                config
                                and config.storage_billing_min_savings_usd is not None
                            ):
                                thresholds["min_monthly_savings_usd"] = float(
                                    config.storage_billing_min_savings_usd
                                )
                        thresholds["_run_results"] = run_results_json
                        thresholds["_table_columns"] = table_columns
                        thresholds["_local_evidence_mode"] = local_evidence_mode
                        candidates = rule.detect(jobs, manifest_content, thresholds)
                        rule_span.set_attribute(
                            "rule.opportunities_found", len(candidates)
                        )

                        all_candidates.extend(candidates)
                        for c in candidates:
                            detected_keys.add((c.opportunity_type, c.affected_table))

                        logger.info(
                            f"Rule {rule.rule_type} found {len(candidates)} opportunities"
                        )

                    except (SQLAlchemyError, ValueError, TypeError, KeyError) as e:
                        error_msg = f"Rule {rule.rule_type} failed: {str(e)}"
                        result.errors.append(error_msg)
                        logger.exception(error_msg)
                        rule_span.set_attribute("rule.error", str(e))

            # Persist opportunities
            for candidate in all_candidates:
                try:
                    _, action = service.persist_opportunity(
                        config_id=config_id,
                        manifest_version_id=manifest_version_id,
                        detection_job_id=detection_job.id,
                        candidate=candidate,
                        lookback_window_days=lookback_window_days,
                    )
                    if action == "created":
                        result.found_count += 1
                    elif action in ("updated", "reactivated"):
                        result.updated_count += 1
                except SQLAlchemyError as e:
                    error_msg = f"Failed to persist opportunity: {str(e)}"
                    result.errors.append(error_msg)
                    logger.exception(error_msg)

            # First sync — backfill detection history from historical data
            # Runs AFTER persist so that opportunity rows exist for history entries
            if is_first_sync:
                try:
                    backfill_count = service.backfill_detection_history(
                        config_id=config_id,
                        detection_job_id=detection_job.id,
                        lookback_window_days=lookback_window_days,
                    )
                    span.set_attribute("detection_job.backfill_entries", backfill_count)
                    logger.info(
                        f"First-sync backfill for config {config_id}: "
                        f"{backfill_count} history entries created"
                    )
                except SQLAlchemyError as e:
                    error_msg = f"Backfill failed: {str(e)}"
                    result.errors.append(error_msg)
                    logger.exception(error_msg)

            # Evaluate resolution using consecutive-day threshold
            # BUT only if we actually had jobs to analyze
            if len(jobs) > 0:
                try:
                    result.resolved_count = service.evaluate_resolution(
                        config_id=config_id,
                        detected_keys=detected_keys,
                        resolution_period_days=resolution_period_days,
                    )
                except SQLAlchemyError as e:
                    error_msg = f"Failed to evaluate resolution: {str(e)}"
                    result.errors.append(error_msg)
                    logger.exception(error_msg)
            else:
                logger.info(
                    f"Skipping evaluate_resolution for detection job {detection_job.id} - "
                    "no jobs to analyze"
                )

            # Run workload-based savings estimation for estimable opportunities
            try:
                from app.configurations.models import ManifestConfiguration
                from app.gcp.clients import GCPCredentialsError, get_bigquery_client
                from app.opportunities.savings_service import (
                    run_estimation_after_detection,
                )

                config_for_estimation = db.get(ManifestConfiguration, config_id)
                bq_client = None
                if (
                    config_for_estimation is not None
                    and config_for_estimation.gcp_project_id
                ):
                    try:
                        bq_client = get_bigquery_client(
                            project_id=config_for_estimation.gcp_project_id
                        )
                    except GCPCredentialsError:
                        logger.info(
                            "Skipping BigQuery-backed savings metadata for config %s: credentials unavailable",
                            config_id,
                        )
                    except (ValueError, RuntimeError, OSError) as _bq_init_err:
                        logger.warning(
                            "Failed to initialize BigQuery client for config %s",
                            config_id,
                            exc_info=True,
                        )

                est_count = run_estimation_after_detection(db, config_id, bq_client)
                if est_count > 0:
                    span.set_attribute("detection_job.savings_estimates", est_count)
            except (SQLAlchemyError, ValueError, TypeError, ZeroDivisionError) as e:
                logger.warning("Savings estimation failed (non-blocking): %s", str(e))

            # Calculate duration
            end_time = datetime.now(timezone.utc)
            result.duration_ms = int((end_time - start_time).total_seconds() * 1000)

            # Set final span attributes
            span.set_attribute("detection_job.opportunities_found", result.found_count)
            span.set_attribute(
                "detection_job.opportunities_updated", result.updated_count
            )
            span.set_attribute(
                "detection_job.opportunities_resolved", result.resolved_count
            )
            span.set_attribute("detection_job.duration_ms", result.duration_ms)
            span.set_attribute("detection_job.errors_count", len(result.errors))

            logger.info(
                f"Detection job {detection_job.id} completed: "
                f"found={result.found_count}, updated={result.updated_count}, "
                f"resolved={result.resolved_count}, duration={result.duration_ms}ms"
            )

        return result


def register_detection_rule(
    rule_class: type[BaseDetectionRule],
    default_thresholds: dict | None = None,
) -> None:
    """
    Register a custom detection rule dynamically.

    This allows adding new detection rules without modifying the core
    DetectionEngine code. Registered rules are loaded alongside built-in
    rules when DetectionEngine is instantiated.

    Args:
        rule_class: A class that extends BaseDetectionRule
        default_thresholds: Optional default thresholds for the rule
                          (if not provided, uses rule's default_thresholds property)

    Example:
        from app.opportunities.detector import register_detection_rule
        from my_rules.custom_rule import CustomRule

        # Register the rule
        register_detection_rule(CustomRule)

        # Or with custom thresholds
        register_detection_rule(
            CustomRule,
            default_thresholds={"min_job_cost_usd": Decimal("0.50")}
        )

    Raises:
        ValueError: If rule is already registered
        TypeError: If rule_class doesn't extend BaseDetectionRule
    """
    register_detection_rule_class(rule_class, default_thresholds)


def unregister_detection_rule(rule_type: str) -> bool:
    """
    Unregister a previously registered detection rule.

    Args:
        rule_type: The rule type identifier to unregister

    Returns:
        True if rule was found and removed, False otherwise
    """
    return unregister_detection_rule_class(rule_type)


def get_registered_rules() -> list[str]:
    """
    Get list of dynamically registered rule types.

    Returns:
        List of rule type identifiers
    """
    return get_registered_rule_types()


def clear_registered_rules() -> None:
    """
    Clear all dynamically registered rules.

    Primarily useful for testing.
    """
    clear_registered_rule_classes()
