"""
SQLAlchemy ORM models for Cost Optimization Opportunity Detection.

Defines database tables for detection jobs and opportunities with proper
relationships, indexes, and constraints.
"""

from __future__ import annotations

import uuid
from datetime import datetime, timezone
from decimal import Decimal

from sqlalchemy import (
    BigInteger,
    CheckConstraint,
    DateTime,
    ForeignKey,
    Index,
    Integer,
    Numeric,
    String,
    Text,
    UniqueConstraint,
    text,
)
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.base import Base


def _utcnow() -> datetime:
    """Return current UTC time with timezone."""
    return datetime.now(timezone.utc)


def _uuid() -> str:
    """Generate new UUID string."""
    return str(uuid.uuid4())


class DetectionJob(Base):
    """
    A queued detection job triggered after sync completion.

    Processed sequentially by the worker. Status transitions:
    queued -> in_progress -> completed/failed
    """

    __tablename__ = "detection_jobs"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    config_id: Mapped[str] = mapped_column(
        String(36),
        ForeignKey("manifest_configurations.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    sync_id: Mapped[str] = mapped_column(
        String(36),
        ForeignKey("sync_operations.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    status: Mapped[str] = mapped_column(String(16), nullable=False, default="queued")
    queued_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, default=_utcnow
    )
    started_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    completed_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True, index=True
    )
    opportunities_found_count: Mapped[int] = mapped_column(
        Integer, nullable=False, default=0
    )
    opportunities_updated_count: Mapped[int] = mapped_column(
        Integer, nullable=False, default=0
    )
    opportunities_resolved_count: Mapped[int] = mapped_column(
        Integer, nullable=False, default=0
    )
    retry_count: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    error_message: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, default=_utcnow
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, default=_utcnow, onupdate=_utcnow
    )

    # Relationships
    opportunities_first_detected: Mapped[list["Opportunity"]] = relationship(
        "Opportunity",
        foreign_keys="[Opportunity.first_detection_job_id]",
        back_populates="first_detection_job",
    )
    opportunities_last_updated: Mapped[list["Opportunity"]] = relationship(
        "Opportunity",
        foreign_keys="[Opportunity.last_detection_job_id]",
        back_populates="last_detection_job",
    )

    __table_args__ = (
        CheckConstraint(
            "status IN ('queued', 'in_progress', 'completed', 'failed')",
            name="ck_det_status",
        ),
        CheckConstraint(
            "retry_count >= 0 AND retry_count <= 3",
            name="ck_det_retry_count",
        ),
        Index("ix_det_status_queued_at", "status", "queued_at"),
        Index(
            "uq_det_jobs_active_sync",
            "sync_id",
            unique=True,
            postgresql_where=text("status IN ('queued', 'in_progress')"),
            sqlite_where=text("status IN ('queued', 'in_progress')"),
        ),
    )


class Opportunity(Base):
    """
    A detected cost optimization opportunity.

    Uniquely identified by (opportunity_type, affected_table, config_id).
    Status transitions: active -> resolved (soft-delete)
    """

    __tablename__ = "opportunities"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    config_id: Mapped[str] = mapped_column(
        String(36),
        ForeignKey("manifest_configurations.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    manifest_version_id: Mapped[str | None] = mapped_column(
        String(36),
        ForeignKey("manifest_versions.id", ondelete="SET NULL"),
        nullable=True,
    )
    opportunity_type: Mapped[str] = mapped_column(String(64), nullable=False)
    affected_table: Mapped[str] = mapped_column(String(1024), nullable=False)
    status: Mapped[str] = mapped_column(
        String(16), nullable=False, default="active", index=True
    )
    severity_score: Mapped[int] = mapped_column(Integer, nullable=False)
    evidence_snapshot: Mapped[dict] = mapped_column(JSONB, nullable=False)
    current_cost_estimate: Mapped[Decimal] = mapped_column(
        Numeric(10, 4), nullable=False
    )
    expected_savings: Mapped[Decimal] = mapped_column(Numeric(10, 4), nullable=False)
    latest_solution_id: Mapped[str | None] = mapped_column(
        String(36),
        ForeignKey(
            "solutions.id",
            ondelete="SET NULL",
            use_alter=True,
            name="fk_opportunities_latest_solution_id",
        ),
        nullable=True,
        index=True,
    )
    latest_solution_risk_level: Mapped[str | None] = mapped_column(
        String(16), nullable=True
    )
    latest_solution_trust_tier: Mapped[str | None] = mapped_column(
        String(16), nullable=True
    )
    latest_solution_dry_run_original_cost: Mapped[Decimal | None] = mapped_column(
        Numeric(18, 6), nullable=True
    )
    latest_solution_dry_run_modified_cost: Mapped[Decimal | None] = mapped_column(
        Numeric(18, 6), nullable=True
    )
    latest_solution_cached_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    explanation: Mapped[str] = mapped_column(Text, nullable=False)
    related_job_ids: Mapped[list] = mapped_column(JSONB, nullable=False)
    dbt_model_name: Mapped[str | None] = mapped_column(String(256), nullable=True)
    first_detection_job_id: Mapped[str] = mapped_column(
        String(36),
        ForeignKey("detection_jobs.id"),
        nullable=False,
    )
    last_detection_job_id: Mapped[str | None] = mapped_column(
        String(36),
        ForeignKey("detection_jobs.id"),
        nullable=True,
    )
    resolved_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True, index=True
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, default=_utcnow
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, default=_utcnow, onupdate=_utcnow
    )

    # Relationships
    configuration: Mapped["ManifestConfiguration"] = relationship(  # noqa: F821
        "ManifestConfiguration",
        back_populates="opportunities",
    )
    manifest_version: Mapped["ManifestVersion | None"] = relationship(  # noqa: F821
        "ManifestVersion",
    )
    first_detection_job: Mapped["DetectionJob"] = relationship(
        "DetectionJob",
        foreign_keys=[first_detection_job_id],
        back_populates="opportunities_first_detected",
    )
    last_detection_job: Mapped["DetectionJob | None"] = relationship(
        "DetectionJob",
        foreign_keys=[last_detection_job_id],
        back_populates="opportunities_last_updated",
    )

    # Post-merge cost tracking (spec 068)
    verified_savings: Mapped[Decimal | None] = mapped_column(
        Numeric(18, 6), nullable=True
    )
    verified_savings_status: Mapped[str | None] = mapped_column(
        String(20), nullable=True
    )
    verified_savings_calculated_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    pre_merge_avg_cost: Mapped[Decimal | None] = mapped_column(
        Numeric(18, 6), nullable=True
    )
    post_merge_avg_cost: Mapped[Decimal | None] = mapped_column(
        Numeric(18, 6), nullable=True
    )
    pre_merge_job_count: Mapped[int | None] = mapped_column(Integer, nullable=True)
    post_merge_job_count: Mapped[int | None] = mapped_column(Integer, nullable=True)

    # Process cost (LLM API overhead for solution generation)
    process_cost_usd: Mapped[Decimal | None] = mapped_column(
        Numeric(12, 6), nullable=True
    )

    # Clearing status fields (set when a merged PR affects this model)
    clearing_until: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    clearing_pr_number: Mapped[int | None] = mapped_column(Integer, nullable=True)
    clearing_repository: Mapped[str | None] = mapped_column(
        String(512), nullable=True
    )

    # Cascade solution consolidation (spec 082)
    cascade_group_id: Mapped[str | None] = mapped_column(
        String(36), nullable=True, index=True
    )
    cascade_root_id: Mapped[str | None] = mapped_column(
        String(36),
        ForeignKey("opportunities.id", ondelete="SET NULL"),
        nullable=True,
        index=True,
    )
    cascade_status: Mapped[str | None] = mapped_column(String(20), nullable=True)

    # Rolling observation window fields
    occurrence_count: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    last_detected_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    consecutive_clean_days: Mapped[int] = mapped_column(
        Integer, nullable=False, default=0
    )

    # Cascade relationships (spec 082)
    cascade_root: Mapped["Opportunity | None"] = relationship(
        "Opportunity",
        remote_side="Opportunity.id",
        foreign_keys=[cascade_root_id],
    )

    # Detection history relationship
    detection_history: Mapped[list["OpportunityDetectionHistory"]] = relationship(
        "OpportunityDetectionHistory",
        back_populates="opportunity",
        cascade="all, delete-orphan",
    )

    __table_args__ = (
        UniqueConstraint(
            "opportunity_type",
            "affected_table",
            "config_id",
            name="uq_opp_type_table_config",
        ),
        CheckConstraint(
            "status IN ('active', 'resolved', 'pr_pending', 'clearing')",
            name="ck_opp_status",
        ),
        CheckConstraint(
            "severity_score >= 1 AND severity_score <= 100",
            name="ck_opp_severity_range",
        ),
        Index("ix_opp_severity", "severity_score"),
        Index("ix_opp_evidence", "evidence_snapshot", postgresql_using="gin"),
        CheckConstraint(
            "cascade_status IN ('root', 'delegated') OR cascade_status IS NULL",
            name="ck_opp_cascade_status",
        ),
    )


class OpportunityDetectionHistory(Base):
    """
    A record of a positive detection event for an opportunity.

    One entry per detection job that finds an opportunity. Non-detection
    is inferred by the absence of a history entry.
    """

    __tablename__ = "opportunity_detection_history"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    opportunity_id: Mapped[str] = mapped_column(
        String(36),
        ForeignKey("opportunities.id"),
        nullable=False,
        index=True,
    )
    detection_job_id: Mapped[str] = mapped_column(
        String(36),
        ForeignKey("detection_jobs.id"),
        nullable=False,
        index=True,
    )
    detected_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, default=_utcnow
    )

    # Relationships
    opportunity: Mapped["Opportunity"] = relationship(
        "Opportunity",
        back_populates="detection_history",
    )
    detection_job: Mapped["DetectionJob"] = relationship(
        "DetectionJob",
    )

    __table_args__ = (Index("ix_odh_opp_detected", "opportunity_id", "detected_at"),)


class OpportunitySavingsEstimate(Base):
    """
    Workload-based savings estimate for a partition/cluster opportunity.

    Stores the result of analysing BigQuery job SQL to estimate how much
    data would be pruned by the recommended partitioning or clustering.
    """

    __tablename__ = "opportunity_savings_estimates"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    opportunity_id: Mapped[str] = mapped_column(
        String(36),
        ForeignKey("opportunities.id", ondelete="CASCADE"),
        nullable=False,
        unique=True,
        index=True,
    )
    recommendation_type: Mapped[str] = mapped_column(
        String(32), nullable=False
    )  # partition, cluster, both
    partition_column: Mapped[str | None] = mapped_column(String(256), nullable=True)
    cluster_columns: Mapped[list | None] = mapped_column(JSONB, nullable=True)
    jobs_analyzed: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    jobs_with_filters: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    total_bytes_scanned: Mapped[int] = mapped_column(
        BigInteger, nullable=False, default=0
    )
    total_bytes_saved: Mapped[int] = mapped_column(
        BigInteger, nullable=False, default=0
    )
    total_cost_saved: Mapped[Decimal] = mapped_column(
        Numeric(18, 6), nullable=False, default=Decimal("0")
    )
    per_run_savings: Mapped[Decimal] = mapped_column(
        Numeric(18, 6), nullable=False, default=Decimal("0")
    )
    monthly_projection: Mapped[Decimal] = mapped_column(
        Numeric(18, 6), nullable=False, default=Decimal("0")
    )
    confidence: Mapped[str] = mapped_column(String(16), nullable=False, default="low")
    filter_coverage_pct: Mapped[Decimal] = mapped_column(
        Numeric(5, 2), nullable=False, default=Decimal("0")
    )
    partition_stats_json: Mapped[dict | None] = mapped_column(JSONB, nullable=True)
    estimated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, default=_utcnow
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, default=_utcnow
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, default=_utcnow, onupdate=_utcnow
    )

    # Relationship
    opportunity: Mapped["Opportunity"] = relationship(
        "Opportunity",
        foreign_keys=[opportunity_id],
    )

    __table_args__ = (
        CheckConstraint(
            "recommendation_type IN ('partition', 'cluster', 'both')",
            name="ck_savings_est_rec_type",
        ),
        CheckConstraint(
            "confidence IN ('high', 'medium', 'low')",
            name="ck_savings_est_confidence",
        ),
    )
