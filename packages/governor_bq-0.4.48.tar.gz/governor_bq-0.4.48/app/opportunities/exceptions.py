"""
Custom exceptions for Cost Optimization Opportunity Detection.

Provides specific exception types for error handling in the detection system.
"""


class DetectionJobExistsError(Exception):
    """Detection job already exists for this sync."""

    def __init__(self, sync_id: str):
        self.sync_id = sync_id
        super().__init__(f"Detection job already exists for sync_id: {sync_id}")


class ActiveDetectionJobExistsError(Exception):
    """An active detection job already exists for this sync/config."""

    def __init__(self, config_id: str, sync_id: str):
        self.config_id = config_id
        self.sync_id = sync_id
        super().__init__(
            "A detection job is already queued or in progress for "
            f"config {config_id} and sync {sync_id}."
        )


class SyncNotCompletedError(Exception):
    """Referenced sync is not in completed status."""

    def __init__(self, sync_id: str, status: str):
        self.sync_id = sync_id
        self.status = status
        super().__init__(f"Sync {sync_id} is not completed (current status: {status})")


class LatestCompletedSyncNotFoundError(Exception):
    """No completed sync exists for the configuration."""

    def __init__(self, config_id: str):
        self.config_id = config_id
        super().__init__(f"No completed sync found for config: {config_id}")


class DetectionJobNotFoundError(Exception):
    """Detection job not found."""

    def __init__(self, job_id: str):
        self.job_id = job_id
        super().__init__(f"Detection job not found: {job_id}")


class DetectionRuleError(Exception):
    """Error during detection rule execution."""

    def __init__(self, rule_type: str, message: str):
        self.rule_type = rule_type
        super().__init__(f"Detection rule '{rule_type}' error: {message}")


class OpportunityNotFoundError(Exception):
    """Opportunity not found."""

    def __init__(self, opportunity_id: str):
        self.opportunity_id = opportunity_id
        super().__init__(f"Opportunity not found: {opportunity_id}")
