"""
Pydantic schemas for Cost Optimization Opportunity Detection.

Defines request/response models for API endpoints and internal data transfer.
"""

from datetime import datetime
from decimal import Decimal
from typing import Any

from pydantic import BaseModel, ConfigDict, Field


class OpportunityOut(BaseModel):
    """Full opportunity details for API response."""

    id: str
    config_id: str
    manifest_version_id: str | None
    opportunity_type: str
    affected_table: str
    status: str
    severity_score: int = Field(ge=1, le=100)
    evidence_snapshot: dict[str, Any]
    current_cost_estimate: Decimal
    expected_savings: Decimal
    explanation: str
    related_job_ids: list[str]
    dbt_model_name: str | None
    first_detection_job_id: str
    last_detection_job_id: str | None
    resolved_at: datetime | None
    created_at: datetime
    updated_at: datetime

    model_config = ConfigDict(from_attributes=True)


class OpportunitySummary(BaseModel):
    """Summary for lists and dashboards."""

    id: str
    opportunity_type: str
    affected_table: str
    status: str
    severity_score: int
    expected_savings: Decimal
    dbt_model_name: str | None
    updated_at: datetime

    model_config = ConfigDict(from_attributes=True)


class DetectionJobOut(BaseModel):
    """Detection job details for API response."""

    id: str
    config_id: str
    sync_id: str
    status: str
    queued_at: datetime
    started_at: datetime | None
    completed_at: datetime | None
    opportunities_found_count: int
    opportunities_updated_count: int
    opportunities_resolved_count: int
    retry_count: int
    error_message: str | None

    model_config = ConfigDict(from_attributes=True)


class DetectionJobSummary(BaseModel):
    """Summary for lists."""

    id: str
    status: str
    queued_at: datetime
    completed_at: datetime | None
    opportunities_found_count: int

    model_config = ConfigDict(from_attributes=True)


def format_occurrence_frequency(
    occurrence_count: int, lookback_window_days: int
) -> str:
    """
    Format occurrence frequency as a human-readable string.

    Args:
        occurrence_count: Number of distinct days detected in the lookback window
        lookback_window_days: Size of the lookback window in days

    Returns:
        Formatted string like "detected in 3 of the last 30 days"
    """
    if occurrence_count == 0:
        return f"not detected in the last {lookback_window_days} days"
    return f"detected in {occurrence_count} of the last {lookback_window_days} days"
