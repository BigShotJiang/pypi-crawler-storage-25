"""
Persistence and orchestration for workload-based savings estimates.

Provides functions to:
- Run the estimation pipeline for a single opportunity
- Save/load estimates from the database
- Trigger estimation after detection or before solution generation
"""

from __future__ import annotations

import logging
from datetime import datetime, timedelta, timezone

from google.cloud.exceptions import GoogleCloudError
from sqlalchemy import select
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.orm import Session

from app.opportunities.models import (
    Opportunity,
    OpportunitySavingsEstimate as EstimateModel,
)
from app.opportunities.recommendation_resolver import resolve_recommendation_context
from app.opportunities.savings_estimator import estimate_opportunity_savings
from app.opportunities.savings_models import (
    ColumnStats,
    OpportunitySavingsEstimate,
)
from app.sync.models import BigQueryJob

logger = logging.getLogger(__name__)

# Opportunity types eligible for workload-based estimation
_ESTIMABLE_TYPES = frozenset(
    {
        "shuffle_spill",
        "slot_contention",
        "join_explosion",
        "partition_pruning",
    }
)


def _load_related_jobs(
    db: Session,
    opportunity: Opportunity,
    lookback_days: int = 30,
) -> list[dict]:
    """Load BigQuery jobs related to this opportunity within the lookback window."""
    job_ids = opportunity.related_job_ids or []
    if not job_ids:
        return []

    cutoff = datetime.now(timezone.utc) - timedelta(days=lookback_days)

    rows = db.execute(
        select(
            BigQueryJob.job_id,
            BigQueryJob.query,
            BigQueryJob.total_bytes_billed,
            BigQueryJob.total_cost,
            BigQueryJob.referenced_tables,
        ).where(
            BigQueryJob.job_id.in_(job_ids),
            BigQueryJob.creation_time >= cutoff,
            BigQueryJob.query.isnot(None),
            BigQueryJob.total_bytes_billed.isnot(None),
            BigQueryJob.total_bytes_billed > 0,
        )
    ).all()

    return [
        {
            "job_id": r.job_id,
            "query": r.query,
            "total_bytes_billed": r.total_bytes_billed,
            "total_cost": r.total_cost,
            "referenced_tables": r.referenced_tables or [],
        }
        for r in rows
    ]


def run_estimation_for_opportunity(
    db: Session,
    opportunity: Opportunity,
    bq_client=None,
    lookback_days: int = 30,
) -> OpportunitySavingsEstimate | None:
    """Run the full estimation pipeline for a single opportunity.

    Args:
        db: Database session.
        opportunity: The opportunity to estimate.
        bq_client: Optional BigQuery client for partition stats.
        lookback_days: How many days of jobs to analyse.

    Returns:
        OpportunitySavingsEstimate or None if not estimable.
    """
    if opportunity.opportunity_type not in _ESTIMABLE_TYPES:
        return None

    jobs = _load_related_jobs(db, opportunity, lookback_days)

    if not jobs:
        logger.debug("No related jobs found for opportunity %s", opportunity.id)
        return None

    resolved = resolve_recommendation_context(db, opportunity, jobs)
    if resolved is None:
        logger.debug(
            "No recommendation extractable from opportunity %s", opportunity.id
        )
        return None

    recommendation = resolved.recommendation
    target_table = resolved.target_table
    if resolved.evidence_updates:
        updated_evidence = dict(opportunity.evidence_snapshot or {})
        changed = False
        for key, value in resolved.evidence_updates.items():
            if updated_evidence.get(key) != value:
                updated_evidence[key] = value
                changed = True
        if changed:
            opportunity.evidence_snapshot = updated_evidence

    # Fetch partition stats if we have a BQ client and a partition recommendation
    partition_stats = None
    table_stats = None

    if bq_client and recommendation.partition_column:
        try:
            from app.opportunities.partition_stats import (
                fetch_partition_stats,
                fetch_table_stats,
            )

            parts = target_table.split(".")
            if len(parts) >= 3:
                project_id, dataset, table_name = parts[0], parts[1], parts[2]
            elif len(parts) == 2:
                dataset, table_name = parts[0], parts[1]
                project_id = bq_client.project
            else:
                table_name = parts[0]
                dataset = ""
                project_id = bq_client.project

            if dataset:
                partition_stats = fetch_partition_stats(
                    bq_client, project_id, dataset, table_name
                )
                if partition_stats:
                    partition_stats.partition_column = recommendation.partition_column

                table_stats = fetch_table_stats(
                    bq_client, project_id, dataset, table_name
                )
        except GoogleCloudError:
            logger.warning(
                "Failed to fetch BigQuery metadata for %s", target_table, exc_info=True
            )

    # Load column stats from existing profiling data (spec 065)
    column_stats = _load_column_stats(db, opportunity)

    estimate = estimate_opportunity_savings(
        opportunity_id=opportunity.id,
        recommendation=recommendation,
        jobs=jobs,
        target_table=target_table,
        partition_stats=partition_stats,
        table_stats=table_stats,
        column_stats=column_stats,
        observation_days=lookback_days,
    )

    return estimate


def _load_column_stats(
    db: Session,
    opportunity: Opportunity,
) -> dict[str, ColumnStats] | None:
    """Load column quality data from evidence snapshot if available."""
    evidence = opportunity.evidence_snapshot or {}
    quality_data = evidence.get("column_quality") or evidence.get("column_profiles")

    if not quality_data or not isinstance(quality_data, dict):
        return None

    stats: dict[str, ColumnStats] = {}
    for col_name, data in quality_data.items():
        if isinstance(data, dict):
            stats[col_name.lower()] = ColumnStats(
                column_name=col_name,
                approx_distinct=int(data.get("approx_distinct", 1000)),
                null_ratio=float(data.get("null_ratio", 0.0)),
            )
    return stats or None


def save_estimate(
    db: Session,
    estimate: OpportunitySavingsEstimate,
) -> EstimateModel:
    """Upsert a savings estimate into the database."""
    existing = db.execute(
        select(EstimateModel).where(
            EstimateModel.opportunity_id == estimate.opportunity_id
        )
    ).scalar_one_or_none()

    if existing:
        existing.recommendation_type = estimate.recommendation_type
        existing.partition_column = estimate.partition_column
        existing.cluster_columns = estimate.cluster_columns
        existing.jobs_analyzed = estimate.jobs_analyzed
        existing.jobs_with_filters = max(
            estimate.jobs_with_partition_filter, estimate.jobs_with_cluster_filter
        )
        existing.total_bytes_scanned = estimate.total_bytes_scanned
        existing.total_bytes_saved = estimate.total_bytes_saved
        existing.total_cost_saved = estimate.total_cost_saved
        existing.per_run_savings = estimate.per_run_savings
        existing.monthly_projection = estimate.monthly_projection
        existing.confidence = estimate.confidence
        existing.filter_coverage_pct = estimate.filter_coverage_pct
        existing.estimated_at = datetime.now(timezone.utc)
        db.flush()
        return existing

    record = EstimateModel(
        opportunity_id=estimate.opportunity_id,
        recommendation_type=estimate.recommendation_type,
        partition_column=estimate.partition_column,
        cluster_columns=estimate.cluster_columns,
        jobs_analyzed=estimate.jobs_analyzed,
        jobs_with_filters=max(
            estimate.jobs_with_partition_filter, estimate.jobs_with_cluster_filter
        ),
        total_bytes_scanned=estimate.total_bytes_scanned,
        total_bytes_saved=estimate.total_bytes_saved,
        total_cost_saved=estimate.total_cost_saved,
        per_run_savings=estimate.per_run_savings,
        monthly_projection=estimate.monthly_projection,
        confidence=estimate.confidence,
        filter_coverage_pct=estimate.filter_coverage_pct,
    )
    db.add(record)
    db.flush()
    return record


def get_estimate(
    db: Session,
    opportunity_id: str,
) -> EstimateModel | None:
    """Load the latest savings estimate for an opportunity."""
    return db.execute(
        select(EstimateModel).where(EstimateModel.opportunity_id == opportunity_id)
    ).scalar_one_or_none()


def run_estimation_after_detection(
    db: Session,
    config_id: str,
    bq_client=None,
) -> int:
    """Run estimation for all active estimable opportunities in a config.

    Called after detection completes. Returns count of estimates produced.
    """
    opps = (
        db.execute(
            select(Opportunity).where(
                Opportunity.config_id == config_id,
                Opportunity.status == "active",
                Opportunity.opportunity_type.in_(_ESTIMABLE_TYPES),
            )
        )
        .scalars()
        .all()
    )

    count = 0
    mutated = False
    for opp in opps:
        try:
            estimate = run_estimation_for_opportunity(db, opp, bq_client)
            if estimate and estimate.jobs_analyzed > 0:
                save_estimate(db, estimate)
                count += 1
                mutated = True
            elif db.is_modified(opp, include_collections=False):
                mutated = True
        except (SQLAlchemyError, ValueError, TypeError, ZeroDivisionError) as _est_err:
            logger.warning(
                "Estimation failed for opportunity %s", opp.id, exc_info=True
            )

    if mutated:
        db.commit()
    if count > 0:
        logger.info("Produced %d savings estimates for config %s", count, config_id)

    return count
