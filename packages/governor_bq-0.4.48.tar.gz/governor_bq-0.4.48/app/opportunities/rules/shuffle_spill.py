"""
Shuffle Spill Detection Rule.

Detects clustering-oriented optimization opportunities from:
- direct BigQuery shuffle spill signals
- conservative run_results-driven build hotspot heuristics
"""

from __future__ import annotations

from decimal import Decimal
from typing import TYPE_CHECKING, Any

from app.opportunities.run_results_heuristics import (
    build_table_column_type_index,
    compiled_sql_for_hotspot,
    columns_for_relation,
    evidence_source_with_run_results,
    extract_cluster_candidate_columns,
    extract_existing_cluster_columns,
    extract_run_results_hotspots,
    job_ids,
    node_supports_config_heuristics,
    related_jobs_for_table,
    relation_name_for_node,
    total_bytes_processed,
    total_job_cost,
)
from app.opportunities.rules.base import BaseDetectionRule, OpportunityCandidate
from app.opportunities.scoring import calculate_severity, estimate_savings_from_cost

if TYPE_CHECKING:
    from app.sync.models import BigQueryJob


class ShuffleSpillRule(BaseDetectionRule):
    """
    Detect shuffle-spill and clustering opportunities for dbt build models.

    The heuristic path intentionally avoids inventing new solution classes: it
    only proposes clustering columns when a real run-results hotspot lines up
    with compiled SQL JOIN/GROUP BY structure on a model that is not already
    clustered on those keys.
    """

    @property
    def rule_type(self) -> str:
        return "shuffle_spill"

    @property
    def display_name(self) -> str:
        return "Shuffle Spill"

    @property
    def description(self) -> str:
        return "Detect queries that spill shuffle data to disk due to memory pressure or runtime hotspots that suggest cluster_by would improve data locality."

    @property
    def default_thresholds(self) -> dict[str, Any]:
        return {
            "min_job_cost_usd": Decimal("0"),
            "run_results_min_execution_time_s": 30.0,
        }

    def detect(
        self,
        jobs: list[BigQueryJob],
        manifest_content: dict | None,
        thresholds: dict[str, Any],
    ) -> list[OpportunityCandidate]:
        """
        Analyze jobs for shuffle spill and run-results clustering issues.

        Trigger paths:
        - ``insufficient_shuffle_quota == true`` for direct BigQuery evidence
        - run_results build hotspots + compiled SQL cluster heuristics
        """
        min_cost = thresholds.get("min_job_cost_usd", Decimal("0.10"))
        candidates_by_table: dict[str, OpportunityCandidate] = {}
        table_jobs: dict[str, list[BigQueryJob]] = {}

        for job in jobs:
            if not job.destination_table:
                continue
            if job.total_cost is None or job.total_cost < min_cost:
                continue
            if not self._has_shuffle_spill(job):
                continue

            table_jobs.setdefault(job.destination_table, []).append(job)

        for table, affected_jobs in table_jobs.items():
            candidate = self._create_jobs_candidate(
                table,
                affected_jobs,
                manifest_content,
            )
            if candidate:
                candidates_by_table[candidate.affected_table.lower()] = candidate

        heuristic_candidates = self._detect_from_run_results(
            jobs=jobs,
            manifest_content=manifest_content,
            thresholds=thresholds,
        )
        for candidate in heuristic_candidates:
            table_key = candidate.affected_table.lower()
            existing = candidates_by_table.get(table_key)
            if existing is None:
                candidates_by_table[table_key] = candidate
                continue

            existing.evidence_snapshot = {
                **existing.evidence_snapshot,
                **candidate.evidence_snapshot,
                "evidence_source": evidence_source_with_run_results(
                    str(existing.evidence_snapshot.get("evidence_source") or "")
                ),
            }
            if candidate.explanation not in existing.explanation:
                existing.explanation = (
                    f"{existing.explanation} {candidate.explanation}"
                ).strip()
            existing.related_job_ids = list(
                dict.fromkeys(existing.related_job_ids + candidate.related_job_ids)
            )
            existing.current_cost_estimate = max(
                existing.current_cost_estimate,
                candidate.current_cost_estimate,
            )
            existing.expected_savings = max(
                existing.expected_savings,
                candidate.expected_savings,
            )
            existing.severity_score = max(
                existing.severity_score,
                candidate.severity_score,
            )
            existing.confidence = max(existing.confidence, candidate.confidence)

        return list(candidates_by_table.values())

    def _has_shuffle_spill(self, job: BigQueryJob) -> bool:
        """Check if job has insufficient_shuffle_quota signal."""
        if not job.performance_insights:
            return False

        insights = job.performance_insights
        stages = insights.get("stage_performance_standalone_insights", [])

        for stage in stages:
            if stage.get("insufficient_shuffle_quota") is True:
                return True

        return False

    def _get_spill_stages(self, job: BigQueryJob) -> list[dict]:
        """Get stages with shuffle spill."""
        if not job.performance_insights:
            return []

        insights = job.performance_insights
        stages = insights.get("stage_performance_standalone_insights", [])
        spill_stages = []

        for stage in stages:
            if stage.get("insufficient_shuffle_quota") is True:
                spill_stages.append(
                    {
                        "stage_id": stage.get("stage_id"),
                        "insufficient_shuffle_quota": True,
                    }
                )

        return spill_stages

    def _create_jobs_candidate(
        self,
        table: str,
        jobs: list[BigQueryJob],
        manifest_content: dict | None,
    ) -> OpportunityCandidate | None:
        """Create opportunity candidate for a table with direct shuffle spill."""
        if not jobs:
            return None

        total_cost = sum(job.total_cost or Decimal("0") for job in jobs)
        total_bytes = sum(job.total_bytes_processed or 0 for job in jobs)
        total_slot_ms = sum(job.total_slot_ms or 0 for job in jobs)

        representative = max(jobs, key=lambda job: job.total_cost or Decimal("0"))
        spill_stages = self._get_spill_stages(representative)
        expected_savings = estimate_savings_from_cost(total_cost, 25.0)
        severity = calculate_severity(
            estimated_savings=expected_savings,
            confidence=1.0,
            frequency=len(jobs),
        )

        evidence = {
            "stage_id": spill_stages[0]["stage_id"] if spill_stages else None,
            "insufficient_shuffle_quota": True,
            "total_slot_ms": total_slot_ms,
            "total_bytes_processed_gb": round(total_bytes / (1024**3), 2),
            "job_cost_usd": float(total_cost),
            "affected_job_count": len(jobs),
            "sample_job_ids": [job.job_id for job in jobs[:5]],
            "evidence_source": "jobs_insights",
        }

        stage_info = f"at stage {spill_stages[0]['stage_id']}" if spill_stages else ""
        explanation = (
            f"Query on table '{table}' experienced shuffle spill to disk "
            f"(insufficient shuffle quota) {stage_info}. This indicates memory "
            "pressure during shuffle operations, resulting in slower execution "
            "and higher costs. Consider: reducing data processed per query, "
            "adding filters earlier, or clustering on frequently joined/grouped keys."
        )
        dbt_model = self.correlate_dbt_model(table, manifest_content)

        return OpportunityCandidate(
            opportunity_type=self.rule_type,
            affected_table=table,
            severity_score=severity,
            evidence_snapshot=evidence,
            current_cost_estimate=total_cost,
            expected_savings=expected_savings,
            explanation=explanation,
            related_job_ids=[job.job_id for job in jobs],
            dbt_model_name=dbt_model,
            confidence=1.0,
        )

    def _detect_from_run_results(
        self,
        *,
        jobs: list[BigQueryJob],
        manifest_content: dict | None,
        thresholds: dict[str, Any],
    ) -> list[OpportunityCandidate]:
        run_results_json = thresholds.get("_run_results")
        min_execution_time_s = float(
            thresholds.get("run_results_min_execution_time_s", 30.0) or 30.0
        )
        hotspots = extract_run_results_hotspots(
            run_results_json,
            manifest_content,
            min_execution_time_s=min_execution_time_s,
        )
        if not hotspots:
            return []

        column_type_index = build_table_column_type_index(
            thresholds.get("_table_columns")
        )
        candidates: list[OpportunityCandidate] = []

        for hotspot in hotspots:
            node = hotspot.node
            if not node_supports_config_heuristics(node):
                continue

            relation_name = relation_name_for_node(node)
            if not relation_name:
                continue

            existing_cluster_columns = extract_existing_cluster_columns(node)
            valid_columns = columns_for_relation(column_type_index, relation_name)
            compiled_sql = compiled_sql_for_hotspot(hotspot)
            recommended_columns = extract_cluster_candidate_columns(
                compiled_sql=compiled_sql,
                valid_columns=valid_columns,
                existing_cluster_columns=existing_cluster_columns,
            )
            if not recommended_columns:
                continue

            related_jobs = related_jobs_for_table(jobs, relation_name)
            total_cost = total_job_cost(related_jobs)
            expected_savings = estimate_savings_from_cost(total_cost, 15.0)
            confidence = 0.62
            severity = calculate_severity(
                estimated_savings=expected_savings,
                confidence=confidence,
                frequency=max(len(related_jobs), 1),
            )
            evidence = {
                "evidence_source": "run_results",
                "run_results_hotspot": {
                    "unique_id": hotspot.unique_id,
                    "model_name": hotspot.model_name,
                    "status": hotspot.status,
                    "execution_time_s": round(hotspot.execution_time_s, 3),
                },
                "run_results_detection": True,
                "heuristic_basis": "run_results_hotspot",
                "recommended_cluster_columns": recommended_columns,
                "existing_cluster_columns": existing_cluster_columns,
                "job_cost_usd": float(total_cost),
                "related_job_count": len(related_jobs),
                "related_job_ids": job_ids(related_jobs, limit=25),
                "total_bytes_processed_gb": round(
                    total_bytes_processed(related_jobs) / (1024**3), 2
                ),
            }
            candidates.append(
                OpportunityCandidate(
                    opportunity_type=self.rule_type,
                    affected_table=relation_name,
                    severity_score=severity,
                    evidence_snapshot=evidence,
                    current_cost_estimate=total_cost,
                    expected_savings=expected_savings,
                    explanation=(
                        f"dbt run_results marked model '{hotspot.model_name}' as a build hotspot "
                        f"({hotspot.execution_time_s:.1f}s, status={hotspot.status}). "
                        f"Governor recommends clustering this model on {recommended_columns} because the compiled SQL "
                        "repeatedly joins or groups on those keys, which is a safe existing dbt config-only improvement path."
                    ),
                    related_job_ids=job_ids(related_jobs, limit=25),
                    dbt_model_name=hotspot.model_name,
                    confidence=confidence,
                )
            )

        return candidates
