"""
Join Explosion Detection Rule.

Detects queries where joins produce unexpectedly large intermediate results
using BigQuery's `high_cardinality_joins` signal in performance_insights.
"""

from __future__ import annotations

from decimal import Decimal
from typing import TYPE_CHECKING, Any

from app.opportunities.rules.base import BaseDetectionRule, OpportunityCandidate
from app.opportunities.scoring import calculate_severity, estimate_savings_from_cost

if TYPE_CHECKING:
    from app.sync.models import BigQueryJob


class JoinExplosionRule(BaseDetectionRule):
    """
    Detects join explosion opportunities from BigQuery performance insights.

    Signal: performance_insights.stage_performance_standalone_insights[].high_cardinality_joins[]
    Confidence: HIGH - BigQuery explicitly identifies problematic joins with exact row counts
    """

    @property
    def rule_type(self) -> str:
        return "join_explosion"

    @property
    def display_name(self) -> str:
        return "Join Explosion"

    @property
    def description(self) -> str:
        return "Detect joins that multiply rows unexpectedly and inflate query cost."

    @property
    def default_thresholds(self) -> dict[str, Any]:
        return {
            "row_multiplication_threshold": 10,  # output_rows > left_rows * 10
            "min_job_cost_usd": Decimal("0"),  # BigQuery ML signals are high-confidence
            "min_output_rows": 100000,  # Ignore small result sets
        }

    def detect(
        self,
        jobs: list[BigQueryJob],
        manifest_content: dict | None,
        thresholds: dict[str, Any],
    ) -> list[OpportunityCandidate]:
        """
        Analyze jobs for join explosion issues.

        Trigger: high_cardinality_joins array is non-empty AND output_rows > left_rows * threshold
        """
        multiplication_threshold = thresholds.get("row_multiplication_threshold", 10)
        min_cost = thresholds.get("min_job_cost_usd", Decimal("0.10"))
        min_output_rows = thresholds.get("min_output_rows", 100000)

        candidates: list[OpportunityCandidate] = []
        table_jobs: dict[
            str, list[tuple[BigQueryJob, dict]]
        ] = {}  # (job, worst_join_info)

        for job in jobs:
            # Skip jobs without destination table
            if not job.destination_table:
                continue

            # Skip low-cost jobs
            if job.total_cost is None or job.total_cost < min_cost:
                continue

            # Check for high cardinality joins
            join_info = self._get_worst_join_explosion(
                job, multiplication_threshold, min_output_rows
            )
            if not join_info:
                continue

            # Group by table
            table = job.destination_table
            if table not in table_jobs:
                table_jobs[table] = []
            table_jobs[table].append((job, join_info))

        # Create opportunity for each affected table
        for table, job_data in table_jobs.items():
            candidate = self._create_candidate(
                table, job_data, manifest_content, thresholds
            )
            if candidate:
                candidates.append(candidate)

        return candidates

    def _get_worst_join_explosion(
        self,
        job: BigQueryJob,
        multiplication_threshold: int,
        min_output_rows: int,
    ) -> dict | None:
        """
        Get the worst join explosion from a job.

        Returns join info dict or None if no qualifying explosions.
        """
        if not job.performance_insights:
            return None

        insights = job.performance_insights
        stages = insights.get("stage_performance_standalone_insights", [])

        worst_join = None
        worst_ratio = 0.0

        for stage in stages:
            joins = stage.get("high_cardinality_joins", [])
            for join in joins:
                left_rows = join.get("left_rows", 0)
                right_rows = join.get("right_rows", 0)
                output_rows = join.get("output_rows", 0)

                # Skip small result sets
                if output_rows < min_output_rows:
                    continue

                # Calculate multiplication ratio
                if left_rows > 0:
                    ratio = output_rows / left_rows
                else:
                    ratio = 0

                # Check threshold
                if ratio >= multiplication_threshold and ratio > worst_ratio:
                    worst_ratio = ratio
                    worst_join = {
                        "stage_id": stage.get("stage_id"),
                        "step_index": join.get("step_index"),
                        "left_rows": left_rows,
                        "right_rows": right_rows,
                        "output_rows": output_rows,
                        "multiplication_ratio": round(ratio, 1),
                    }

        return worst_join

    def _create_candidate(
        self,
        table: str,
        job_data: list[tuple[BigQueryJob, dict]],  # (job, join_info)
        manifest_content: dict | None,
        thresholds: dict[str, Any],
    ) -> OpportunityCandidate | None:
        """Create opportunity candidate for a table with join explosion."""
        if not job_data:
            return None

        jobs = [j for j, _ in job_data]
        join_infos = [info for _, info in job_data]

        # Aggregate metrics
        total_cost = sum(j.total_cost or Decimal("0") for j in jobs)

        # Get worst join across all jobs
        worst_join = max(join_infos, key=lambda x: x.get("multiplication_ratio", 0))
        max_ratio = worst_join.get("multiplication_ratio", 0)

        # Estimate savings based on ratio (higher ratio = more potential savings)
        # Join explosions can be catastrophic - estimate 50-80% savings
        savings_percent = min(80, 50 + (max_ratio / 10) * 3)
        expected_savings = estimate_savings_from_cost(total_cost, savings_percent)

        # Calculate severity
        severity = calculate_severity(
            estimated_savings=expected_savings,
            confidence=1.0,  # Direct BigQuery signal
            frequency=len(jobs),
        )

        # Build evidence snapshot
        evidence = {
            "stage_id": worst_join.get("stage_id"),
            "left_rows": worst_join.get("left_rows"),
            "right_rows": worst_join.get("right_rows"),
            "output_rows": worst_join.get("output_rows"),
            "multiplication_ratio": max_ratio,
            "job_cost_usd": float(total_cost),
            "affected_job_count": len(jobs),
            "sample_job_ids": [j.job_id for j in jobs[:5]],
        }

        # Generate explanation
        left_rows = worst_join.get("left_rows", 0)
        right_rows = worst_join.get("right_rows", 0)
        output_rows = worst_join.get("output_rows", 0)

        explanation = (
            f"Query on table '{table}' produced {output_rows:,} rows from a join of "
            f"{left_rows:,} × {right_rows:,} rows (a {max_ratio}x multiplication). "
            f"This often indicates a missing or incorrect join condition, "
            f"duplicate join keys, or unintended cross join. "
            f"Review join conditions and ensure appropriate key uniqueness."
        )

        # Correlate with dbt model
        dbt_model = self.correlate_dbt_model(table, manifest_content)

        return OpportunityCandidate(
            opportunity_type=self.rule_type,
            affected_table=table,
            severity_score=severity,
            evidence_snapshot=evidence,
            current_cost_estimate=total_cost,
            expected_savings=expected_savings,
            explanation=explanation,
            related_job_ids=[j.job_id for j in jobs],
            dbt_model_name=dbt_model,
            confidence=1.0,
        )
