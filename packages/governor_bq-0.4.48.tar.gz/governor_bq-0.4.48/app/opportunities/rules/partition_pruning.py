"""
Partition Pruning Detection Rule.

Detects partition-pruning opportunities from two sources:
- direct BigQuery performance insights when available
- conservative run_results-driven heuristics for local build hotspots
"""

from __future__ import annotations

from decimal import Decimal
from typing import TYPE_CHECKING, Any

from app.dbt.column_lookup import resolve_bq_partition_data_type
from app.opportunities.run_results_heuristics import (
    build_table_column_type_index,
    choose_partition_column,
    compiled_sql_for_hotspot,
    evidence_source_with_run_results,
    extract_existing_partition_field,
    extract_run_results_hotspots,
    job_ids,
    node_supports_config_heuristics,
    partitionable_columns_for_relation,
    related_jobs_for_table,
    relation_name_for_node,
    total_job_cost,
)
from app.opportunities.rules.base import BaseDetectionRule, OpportunityCandidate
from app.opportunities.scoring import calculate_severity, estimate_savings_from_cost

if TYPE_CHECKING:
    from app.sync.models import BigQueryJob


class PartitionPruningRule(BaseDetectionRule):
    """
    Detect partition-pruning opportunities from jobs insights and run results.

    The run-results path is intentionally conservative: it only proposes
    recommendations when a dbt model is a real runtime hotspot and Governor can
    map that hotspot to an existing supported config-only recommendation.
    """

    @property
    def rule_type(self) -> str:
        return "partition_pruning"

    @property
    def display_name(self) -> str:
        return "Partition Pruning"

    @property
    def description(self) -> str:
        return "Detect scans of partitioned tables where partition filters or partition config changes could reduce bytes processed."

    @property
    def default_thresholds(self) -> dict[str, Any]:
        return {
            "min_job_cost_usd": Decimal("0"),
            "enabled": True,
            "run_results_min_execution_time_s": 30.0,
        }

    def detect(
        self,
        jobs: list[BigQueryJob],
        manifest_content: dict | None,
        thresholds: dict[str, Any],
    ) -> list[OpportunityCandidate]:
        """
        Analyze jobs and local run results for partition-pruning issues.

        Trigger paths:
        - direct BigQuery ``partition_skew`` insights
        - run_results hotspots + manifest/column heuristics
        """
        if not thresholds.get("enabled", True):
            return []

        min_cost = thresholds.get("min_job_cost_usd", Decimal("0.10"))
        candidates_by_table: dict[str, OpportunityCandidate] = {}
        table_jobs: dict[str, list[tuple[BigQueryJob, dict]]] = {}

        for job in jobs:
            if not job.destination_table:
                continue
            if job.total_cost is None or job.total_cost < min_cost:
                continue

            skew_info = self._get_partition_skew_info(job)
            if not skew_info:
                continue

            table = job.destination_table
            table_jobs.setdefault(table, []).append((job, skew_info))

        for table, job_data in table_jobs.items():
            candidate = self._create_jobs_candidate(table, job_data, manifest_content)
            if candidate:
                candidates_by_table[candidate.affected_table.lower()] = candidate

        heuristic_candidates = self._detect_from_run_results(
            jobs=jobs,
            manifest_content=manifest_content,
            thresholds=thresholds,
        )
        for candidate in heuristic_candidates:
            table_key = candidate.affected_table.lower()
            existing = candidates_by_table.get(table_key)
            if existing is None:
                candidates_by_table[table_key] = candidate
                continue

            existing.evidence_snapshot = {
                **existing.evidence_snapshot,
                **candidate.evidence_snapshot,
                "evidence_source": evidence_source_with_run_results(
                    str(existing.evidence_snapshot.get("evidence_source") or "")
                ),
            }
            if candidate.explanation not in existing.explanation:
                existing.explanation = (
                    f"{existing.explanation} {candidate.explanation}"
                ).strip()
            existing.related_job_ids = list(
                dict.fromkeys(existing.related_job_ids + candidate.related_job_ids)
            )
            existing.expected_savings = max(
                existing.expected_savings, candidate.expected_savings
            )
            existing.current_cost_estimate = max(
                existing.current_cost_estimate,
                candidate.current_cost_estimate,
            )
            existing.severity_score = max(
                existing.severity_score,
                candidate.severity_score,
            )
            existing.confidence = max(existing.confidence, candidate.confidence)

        return list(candidates_by_table.values())

    def _get_partition_skew_info(self, job: BigQueryJob) -> dict | None:
        """Check if job has partition_skew signal."""
        if not job.performance_insights:
            return None

        insights = job.performance_insights
        stages = insights.get("stage_performance_standalone_insights", [])

        for stage in stages:
            partition_skew = stage.get("partition_skew")
            if partition_skew is not None:
                return {
                    "stage_id": stage.get("stage_id"),
                    "partition_skew": partition_skew,
                }

        return None

    def _create_jobs_candidate(
        self,
        table: str,
        job_data: list[tuple[BigQueryJob, dict]],
        manifest_content: dict | None,
    ) -> OpportunityCandidate | None:
        """Create opportunity candidate for a table with direct partition issues."""
        if not job_data:
            return None

        jobs = [job for job, _ in job_data]
        skew_infos = [info for _, info in job_data]

        total_cost = sum(job.total_cost or Decimal("0") for job in jobs)
        total_bytes = sum(job.total_bytes_processed or 0 for job in jobs)
        representative_skew = skew_infos[0] if skew_infos else {}
        expected_savings = estimate_savings_from_cost(total_cost, 50.0)
        severity = calculate_severity(
            estimated_savings=expected_savings,
            confidence=0.7,
            frequency=len(jobs),
        )

        evidence = {
            "table_name": table,
            "partition_skew_detected": True,
            "partition_skew_info": representative_skew,
            "total_bytes_processed_gb": round(total_bytes / (1024**3), 2),
            "job_cost_usd": float(total_cost),
            "affected_job_count": len(jobs),
            "sample_job_ids": [job.job_id for job in jobs[:5]],
            "evidence_source": "jobs_insights",
        }

        explanation = (
            f"Query on table '{table}' may be scanning more partitions than necessary. "
            "BigQuery detected partition skew in the query execution. Consider adding "
            "filters on partition columns or tightening partition-compatible predicates "
            "with direct comparisons such as date = '2026-01-01'."
        )
        dbt_model = self.correlate_dbt_model(table, manifest_content)

        return OpportunityCandidate(
            opportunity_type=self.rule_type,
            affected_table=table,
            severity_score=severity,
            evidence_snapshot=evidence,
            current_cost_estimate=total_cost,
            expected_savings=expected_savings,
            explanation=explanation,
            related_job_ids=[job.job_id for job in jobs],
            dbt_model_name=dbt_model,
            confidence=0.7,
        )

    def _detect_from_run_results(
        self,
        *,
        jobs: list[BigQueryJob],
        manifest_content: dict | None,
        thresholds: dict[str, Any],
    ) -> list[OpportunityCandidate]:
        run_results_json = thresholds.get("_run_results")
        min_execution_time_s = float(
            thresholds.get("run_results_min_execution_time_s", 30.0) or 30.0
        )
        hotspots = extract_run_results_hotspots(
            run_results_json,
            manifest_content,
            min_execution_time_s=min_execution_time_s,
        )
        if not hotspots:
            return []

        column_type_index = build_table_column_type_index(
            thresholds.get("_table_columns")
        )
        candidates: list[OpportunityCandidate] = []

        for hotspot in hotspots:
            node = hotspot.node
            if not node_supports_config_heuristics(node):
                continue

            relation_name = relation_name_for_node(node)
            if not relation_name:
                continue

            config = node.get("config") or {}
            existing_partition_field = extract_existing_partition_field(node)
            require_partition_filter = config.get("require_partition_filter")
            related_jobs = related_jobs_for_table(jobs, relation_name)
            total_cost = total_job_cost(related_jobs)
            compiled_sql = compiled_sql_for_hotspot(hotspot)
            expected_savings = Decimal("0")
            confidence = 0.66
            evidence: dict[str, Any] = {
                "evidence_source": "run_results",
                "run_results_hotspot": {
                    "unique_id": hotspot.unique_id,
                    "model_name": hotspot.model_name,
                    "status": hotspot.status,
                    "execution_time_s": round(hotspot.execution_time_s, 3),
                },
                "run_results_detection": True,
                "heuristic_basis": "run_results_hotspot",
            }

            if existing_partition_field:
                if require_partition_filter is True:
                    continue

                related_job_ids = job_ids(related_jobs, limit=25)
                bq_type = partitionable_columns_for_relation(
                    column_type_index, relation_name
                ).get(existing_partition_field.lower())
                if bq_type:
                    evidence["partition_data_type"] = bq_type
                evidence.update(
                    {
                        "recommended_partition_column": existing_partition_field,
                        "current_partition_column": existing_partition_field,
                        "recommended_require_partition_filter": True,
                        "partition_already_configured": True,
                        "job_cost_usd": float(total_cost),
                        "related_job_count": len(related_jobs),
                    }
                )
                expected_savings = estimate_savings_from_cost(total_cost, 8.0)
                severity = calculate_severity(
                    estimated_savings=expected_savings,
                    confidence=confidence,
                    frequency=max(len(related_jobs), 1),
                )
                candidates.append(
                    OpportunityCandidate(
                        opportunity_type=self.rule_type,
                        affected_table=relation_name,
                        severity_score=severity,
                        evidence_snapshot=evidence,
                        current_cost_estimate=total_cost,
                        expected_savings=expected_savings,
                        explanation=(
                            f"dbt run_results marked model '{hotspot.model_name}' as a build hotspot "
                            f"({hotspot.execution_time_s:.1f}s, status={hotspot.status}). "
                            f"The table is already partitioned on '{existing_partition_field}' but does not "
                            "enforce require_partition_filter, so downstream queries can still trigger broad scans."
                        ),
                        related_job_ids=related_job_ids,
                        dbt_model_name=hotspot.model_name,
                        confidence=confidence,
                    )
                )
                continue

            eligible_columns = partitionable_columns_for_relation(
                column_type_index, relation_name
            )
            column_name, heuristic_reason, inferred_bq_type = choose_partition_column(
                relation_name=relation_name,
                eligible_columns=eligible_columns,
                jobs=related_jobs,
                compiled_sql=compiled_sql,
            )
            if not column_name:
                continue

            bq_type = eligible_columns.get(column_name) or inferred_bq_type
            if not bq_type:
                continue
            dbt_partition_type, granularity = resolve_bq_partition_data_type(bq_type)
            evidence.update(
                {
                    "recommended_partition_column": column_name,
                    "partition_data_type": bq_type,
                    "recommended_partition_config": {
                        "field": column_name,
                        "data_type": dbt_partition_type,
                        **(
                            {"granularity": granularity}
                            if granularity is not None
                            else {}
                        ),
                    },
                    "partition_heuristic_reason": heuristic_reason,
                    "job_cost_usd": float(total_cost),
                    "related_job_count": len(related_jobs),
                    "related_job_ids": job_ids(related_jobs, limit=25),
                }
            )
            expected_savings = estimate_savings_from_cost(total_cost, 18.0)
            severity = calculate_severity(
                estimated_savings=expected_savings,
                confidence=confidence,
                frequency=max(len(related_jobs), 1),
            )
            reason_copy = (
                "downstream query predicates repeatedly filter that column"
                if heuristic_reason == "predicate_usage"
                else "the compiled SQL uses that temporal predicate directly"
                if heuristic_reason == "sql_temporal_predicate"
                else "the table exposes a strong temporal column name pattern"
            )
            candidates.append(
                OpportunityCandidate(
                    opportunity_type=self.rule_type,
                    affected_table=relation_name,
                    severity_score=severity,
                    evidence_snapshot=evidence,
                    current_cost_estimate=total_cost,
                    expected_savings=expected_savings,
                    explanation=(
                        f"dbt run_results marked model '{hotspot.model_name}' as a build hotspot "
                        f"({hotspot.execution_time_s:.1f}s, status={hotspot.status}). "
                        f"Governor recommends partitioning this model on '{column_name}' because {reason_copy}, "
                        "and that change stays within the existing allowed dbt config-only optimization set."
                    ),
                    related_job_ids=job_ids(related_jobs, limit=25),
                    dbt_model_name=hotspot.model_name,
                    confidence=confidence,
                )
            )

        return candidates
