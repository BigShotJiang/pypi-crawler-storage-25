"""Unused aggregation output detection rule."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from app.dbt.column_analyzer import (
    IntraModelAnalysis,
    analyze_intra_model_dead_outputs_by_category,
)
from app.opportunities.rules.base import BaseDetectionRule, OpportunityCandidate
from app.opportunities.scoring import (
    calculate_severity,
    estimate_cost_from_bytes_processed,
)

if TYPE_CHECKING:
    from app.sync.models import BigQueryJob

_CONFIDENCE = 0.68


def _build_suppressed_dead_column_finding(
    analysis: IntraModelAnalysis,
) -> list[dict[str, Any]]:
    items = [
        f"{cte.cte_name}.{col}"
        for cte in analysis.cte_dead_columns
        for col in cte.dead_columns
    ]
    if not items:
        return []

    return [
        {
            "rule_type": "dead_column",
            "display_name": "Dead Column",
            "count": len(items),
            "reason": (
                "Hidden because Unused Aggregation Output is the more specific "
                "rule for these unused aggregate expressions."
            ),
            "items": items,
            "ctes": sorted({cte.cte_name for cte in analysis.cte_dead_columns}),
        }
    ]


class UnusedAggregationOutputRule(BaseDetectionRule):
    """Detect aggregate outputs that are computed but never consumed downstream."""

    @property
    def rule_type(self) -> str:
        return "unused_aggregation_output"

    @property
    def display_name(self) -> str:
        return "Unused Aggregation Output"

    @property
    def description(self) -> str:
        return "Detect aggregate expressions in dbt model CTEs that are computed but never referenced downstream."

    @property
    def default_thresholds(self) -> dict[str, Any]:
        return {
            "enabled": False,
            "min_dead_columns": 1,
            "excluded_column_patterns": [],
        }

    def detect(
        self,
        jobs: list[BigQueryJob],
        manifest_content: dict | None,
        thresholds: dict[str, Any],
    ) -> list[OpportunityCandidate]:
        if not manifest_content:
            return []

        min_dead = thresholds.get("min_dead_columns", 1)
        excluded = thresholds.get("excluded_column_patterns", [])
        jobs_by_table: dict[str, list[BigQueryJob]] = {}
        for job in jobs:
            if job.destination_table:
                jobs_by_table.setdefault(job.destination_table, []).append(job)

        analyses = analyze_intra_model_dead_outputs_by_category(
            manifest_content=manifest_content,
            target_category="aggregate",
            min_dead_columns=min_dead,
            excluded_patterns=excluded,
        )
        candidates: list[OpportunityCandidate] = []
        for analysis in analyses:
            candidate = self._build_candidate(analysis, jobs_by_table)
            if candidate is not None:
                candidates.append(candidate)
        return candidates

    def _build_candidate(
        self,
        analysis: IntraModelAnalysis,
        jobs_by_table: dict[str, list[BigQueryJob]],
    ) -> OpportunityCandidate | None:
        table_jobs = jobs_by_table.get(analysis.affected_table, [])
        byte_samples = [
            job.total_bytes_processed
            for job in table_jobs
            if job.total_bytes_processed is not None
        ]
        avg_bytes = sum(byte_samples) / len(byte_samples) if byte_samples else 0.0

        dead_aggregations = [
            col for cte in analysis.cte_dead_columns for col in cte.dead_columns
        ]
        all_cols_count = sum(len(cte.all_columns) for cte in analysis.cte_dead_columns)
        dead_count = len(dead_aggregations)
        dead_fraction = dead_count / max(all_cols_count, 1)

        avg_cost_per_run = estimate_cost_from_bytes_processed(avg_bytes)
        cost_saved = estimate_cost_from_bytes_processed(avg_bytes * dead_fraction)
        severity = calculate_severity(
            estimated_savings=cost_saved,
            confidence=_CONFIDENCE,
            frequency=len(table_jobs),
        )

        cte_details = [
            {
                "cte_name": cte.cte_name,
                "dead_columns": cte.dead_columns,
                "all_columns": cte.all_columns,
                "dead_column_categories": cte.dead_column_categories,
            }
            for cte in analysis.cte_dead_columns
        ]

        explanation = (
            f"Model '{analysis.model_name}' computes {dead_count} aggregate output(s) "
            "that are never referenced by later CTEs or the final SELECT: "
            f"{', '.join(f'`{col}`' for col in dead_aggregations)}. Removing them "
            "eliminates unnecessary aggregation work without changing the model's "
            f"visible output (confidence: {_CONFIDENCE:.2f})."
        )

        evidence: dict[str, Any] = {
            "unused_aggregation_outputs": dead_aggregations,
            "dead_columns": dead_aggregations,
            "cte_dead_columns": cte_details,
            "total_columns": all_cols_count,
            "dead_count": dead_count,
            "model_cte_count": len(analysis.cte_dead_columns),
            "estimated_bytes_saved_per_run": round(avg_bytes * dead_fraction),
            "sample_job_count": len(table_jobs),
            "sample_job_count_with_bytes": len(byte_samples),
            "suppressed_findings": _build_suppressed_dead_column_finding(analysis),
        }

        return OpportunityCandidate(
            opportunity_type=self.rule_type,
            affected_table=analysis.affected_table,
            severity_score=severity,
            evidence_snapshot=evidence,
            current_cost_estimate=avg_cost_per_run,
            expected_savings=cost_saved,
            explanation=explanation,
            related_job_ids=[job.job_id for job in table_jobs[:10]],
            dbt_model_name=analysis.model_name,
            confidence=_CONFIDENCE,
        )
