"""Unused join detection rule."""

from __future__ import annotations

from decimal import Decimal
from typing import TYPE_CHECKING, Any

from app.dbt.column_analyzer import UnusedJoinAnalysis, analyze_unused_joins
from app.opportunities.rules.base import BaseDetectionRule, OpportunityCandidate
from app.opportunities.scoring import (
    calculate_severity,
    estimate_cost_from_bytes_processed,
)

if TYPE_CHECKING:
    from app.sync.models import BigQueryJob

_CONFIDENCE = 0.58


class UnusedJoinRule(BaseDetectionRule):
    """Detect conservatively removable LEFT JOINs inside CTEs."""

    @property
    def rule_type(self) -> str:
        return "unused_join"

    @property
    def display_name(self) -> str:
        return "Unused Join"

    @property
    def description(self) -> str:
        return "Detect LEFT JOINs in dbt model CTEs whose right side is unused and structurally unique on the join keys."

    @property
    def default_thresholds(self) -> dict[str, Any]:
        return {"enabled": False, "min_unused_joins": 1}

    def detect(
        self,
        jobs: list[BigQueryJob],
        manifest_content: dict | None,
        thresholds: dict[str, Any],
    ) -> list[OpportunityCandidate]:
        if not manifest_content:
            return []

        min_unused = thresholds.get("min_unused_joins", 1)
        jobs_by_table: dict[str, list[BigQueryJob]] = {}
        for job in jobs:
            if job.destination_table:
                jobs_by_table.setdefault(job.destination_table, []).append(job)

        analyses = analyze_unused_joins(
            manifest_content=manifest_content,
            min_unused_joins=min_unused,
        )
        candidates: list[OpportunityCandidate] = []
        for analysis in analyses:
            candidate = self._build_candidate(analysis, jobs_by_table)
            if candidate is not None:
                candidates.append(candidate)
        return candidates

    def _build_candidate(
        self,
        analysis: UnusedJoinAnalysis,
        jobs_by_table: dict[str, list[BigQueryJob]],
    ) -> OpportunityCandidate | None:
        table_jobs = jobs_by_table.get(analysis.affected_table, [])
        byte_samples = [
            job.total_bytes_processed
            for job in table_jobs
            if job.total_bytes_processed is not None
        ]
        avg_bytes = sum(byte_samples) / len(byte_samples) if byte_samples else 0.0
        unused_fraction = len(analysis.unused_joins) / max(analysis.total_join_count, 1)

        avg_cost_per_run = estimate_cost_from_bytes_processed(avg_bytes)
        cost_saved = estimate_cost_from_bytes_processed(
            avg_bytes * unused_fraction
        ) * Decimal("0.30")
        severity = calculate_severity(
            estimated_savings=cost_saved,
            confidence=_CONFIDENCE,
            frequency=len(table_jobs),
        )

        evidence: dict[str, Any] = {
            "unused_joins": [
                {
                    "cte_name": item.cte_name,
                    "join_alias": item.join_alias,
                    "joined_source_name": item.joined_source_name,
                    "join_keys": item.join_keys,
                }
                for item in analysis.unused_joins
            ],
            "unused_join_count": len(analysis.unused_joins),
            "total_join_count": analysis.total_join_count,
            "estimated_bytes_saved_per_run": round(avg_bytes * unused_fraction * 0.30),
            "sample_job_count": len(table_jobs),
            "sample_job_count_with_bytes": len(byte_samples),
        }

        explanation = (
            f"Model '{analysis.model_name}' contains LEFT JOIN(s) whose right-hand "
            "side is unused and structurally unique on the join keys, so the join "
            "can be removed without changing row retention. Affected joins: "
            + ", ".join(
                f"`{item.cte_name}` -> `{item.join_alias}`"
                for item in analysis.unused_joins
            )
            + f". Confidence: {_CONFIDENCE:.2f}."
        )

        return OpportunityCandidate(
            opportunity_type=self.rule_type,
            affected_table=analysis.affected_table,
            severity_score=severity,
            evidence_snapshot=evidence,
            current_cost_estimate=avg_cost_per_run,
            expected_savings=cost_saved,
            explanation=explanation,
            related_job_ids=[job.job_id for job in table_jobs[:10]],
            dbt_model_name=analysis.model_name,
            confidence=_CONFIDENCE,
        )
