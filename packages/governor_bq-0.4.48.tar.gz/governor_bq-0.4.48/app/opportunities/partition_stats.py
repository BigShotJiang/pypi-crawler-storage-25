"""Fetch partition and table storage statistics from BigQuery INFORMATION_SCHEMA."""

from __future__ import annotations

import logging

from google.cloud.exceptions import GoogleCloudError

from app.opportunities.savings_models import PartitionInfo, PartitionStats, TableStats

logger = logging.getLogger(__name__)


def fetch_partition_stats(
    bq_client,
    project_id: str,
    dataset: str,
    table: str,
) -> PartitionStats | None:
    """Query INFORMATION_SCHEMA.PARTITIONS for partition-level byte distribution.

    Returns None if the table is not partitioned or on error.
    """
    query = f"""
        SELECT
            partition_id,
            total_rows,
            total_logical_bytes
        FROM `{project_id}.{dataset}.INFORMATION_SCHEMA.PARTITIONS`
        WHERE table_name = @table_name
          AND partition_id IS NOT NULL
          AND partition_id != '__NULL__'
        ORDER BY partition_id
    """
    from google.cloud.bigquery import QueryJobConfig, ScalarQueryParameter

    job_config = QueryJobConfig(
        query_parameters=[
            ScalarQueryParameter("table_name", "STRING", table),
        ]
    )

    try:
        rows = list(bq_client.query(query, job_config=job_config).result())
    except GoogleCloudError:
        logger.warning(
            "Failed to fetch partition stats for %s.%s.%s",
            project_id,
            dataset,
            table,
            exc_info=True,
        )
        return None

    if not rows:
        return None

    partitions: dict[str, PartitionInfo] = {}
    total_rows = 0
    total_bytes = 0

    for row in rows:
        pid = str(row.partition_id)
        r = int(row.total_rows or 0)
        b = int(row.total_logical_bytes or 0)
        partitions[pid] = PartitionInfo(
            partition_id=pid,
            total_rows=r,
            total_logical_bytes=b,
        )
        total_rows += r
        total_bytes += b

    # Infer partition type from partition_id format
    sample_id = next(iter(partitions))
    if len(sample_id) == 8 and sample_id.isdigit():
        partition_type = "DAY"
    elif len(sample_id) == 6 and sample_id.isdigit():
        partition_type = "MONTH"
    elif len(sample_id) == 4 and sample_id.isdigit():
        partition_type = "YEAR"
    elif len(sample_id) == 10 and sample_id.isdigit():
        partition_type = "HOUR"
    else:
        partition_type = "INTEGER_RANGE"

    # We don't know the partition column name from PARTITIONS view alone.
    # Caller must supply it from opportunity evidence or table DDL.
    return PartitionStats(
        partition_column="",  # Caller sets this
        partition_type=partition_type,
        partitions=partitions,
        total_rows=total_rows,
        total_bytes=total_bytes,
    )


def fetch_table_stats(
    bq_client,
    project_id: str,
    dataset: str,
    table: str,
) -> TableStats | None:
    """Query INFORMATION_SCHEMA.TABLE_STORAGE for table-level byte counts.

    Returns None on error.
    """
    query = f"""
        SELECT
            total_rows,
            total_logical_bytes,
            total_billable_bytes
        FROM `{project_id}.{dataset}.INFORMATION_SCHEMA.TABLE_STORAGE`
        WHERE table_name = @table_name
        LIMIT 1
    """
    from google.cloud.bigquery import QueryJobConfig, ScalarQueryParameter

    job_config = QueryJobConfig(
        query_parameters=[
            ScalarQueryParameter("table_name", "STRING", table),
        ]
    )

    try:
        rows = list(bq_client.query(query, job_config=job_config).result())
    except GoogleCloudError:
        logger.warning(
            "Failed to fetch table stats for %s.%s.%s",
            project_id,
            dataset,
            table,
            exc_info=True,
        )
        return None

    if not rows:
        return None

    row = rows[0]
    return TableStats(
        project_id=project_id,
        dataset=dataset,
        table_name=table,
        total_rows=int(row.total_rows or 0),
        total_logical_bytes=int(row.total_logical_bytes or 0),
        total_billable_bytes=int(row.total_billable_bytes or 0),
    )
