"""Recommendation state resolution for opportunities.

Replaces the catch-all "Pending" label with specific, actionable states
that tell users exactly what is happening with each opportunity's solution.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class StateInfo:
    """Display metadata for a recommendation state."""

    key: str
    label: str  # Short label for explorer SOLUTION column
    detail_label: str  # Longer label for detail page metric card
    explanation: str  # 1-2 sentence explanation for detail page
    dot_color: str  # Tailwind color name: "emerald", "brand", "teal", "red", "slate"
    pulse: bool = False


_STATES: dict[str, StateInfo] = {
    "ready": StateInfo(
        key="ready",
        label="",  # Overridden by risk level rendering
        detail_label="",  # Overridden by savings amount
        explanation="A solution has been generated and is ready for review.",
        dot_color="emerald",
    ),
    "generating": StateInfo(
        key="generating",
        label="Generating",
        detail_label="Generating solution",
        explanation="The AI engine is analyzing this opportunity and generating a fix.",
        dot_color="brand",
        pulse=True,
    ),
    "upstream_fix": StateInfo(
        key="upstream_fix",
        label="Upstream fix",
        detail_label="Resolved by upstream fix",
        explanation="",  # Dynamic — includes root model name at render time
        dot_color="teal",
    ),
    "failed": StateInfo(
        key="failed",
        label="Failed",
        detail_label="Generation failed",
        explanation="Solution generation failed. Click Regenerate to retry.",
        dot_color="red",
    ),
    "awaiting": StateInfo(
        key="awaiting",
        label="Awaiting",
        detail_label="Awaiting analysis",
        explanation="This opportunity will be analyzed during the next sync cycle.",
        dot_color="slate",
    ),
}


def resolve_state(
    *,
    opportunity_status: str,
    cascade_status: str | None,
    cascade_root_has_solution: bool = False,
    solution_job_status: str | None,
    has_solutions: bool,
    has_pr: bool,
    job_permanently_failed: bool = False,
) -> StateInfo:
    """Compute the recommendation state for an opportunity.

    Precedence (highest to lowest):
    1. Existing terminal states (clearing, pr_open) — handled by existing UI
    2. Solution exists → ready
    3. Job queued/running → generating
    4. Cascade-delegated → upstream_fix
    5. Job permanently failed → failed
    6. Default → awaiting
    """
    # Existing states handled by current UI — return sentinel for completeness
    if opportunity_status == "clearing":
        return _STATES["ready"]  # Clearing UI already renders its own state
    if has_pr:
        return _STATES["ready"]  # PR Open UI already renders its own state
    if has_solutions:
        return _STATES["ready"]
    if solution_job_status in ("queued", "in_progress"):
        return _STATES["generating"]
    if cascade_status == "delegated":
        return _STATES["upstream_fix"]
    if job_permanently_failed:
        return _STATES["failed"]
    return _STATES["awaiting"]


def get_state(key: str) -> StateInfo:
    """Look up state metadata by key."""
    return _STATES[key]
