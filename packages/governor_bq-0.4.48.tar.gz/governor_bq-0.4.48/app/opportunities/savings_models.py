"""
Dataclasses for the partition & cluster savings estimation engine.

These are pure data containers used by the savings estimator — they are
intentionally separate from the SQLAlchemy persistence model.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from decimal import Decimal


@dataclass(frozen=True)
class Predicate:
    """A parsed WHERE/JOIN predicate targeting a specific column."""

    column: str
    operator: str  # eq, gt, gte, lt, lte, between, in, is_null, is_not_null
    values: list[str | None] = field(default_factory=list)
    is_partition_compatible: bool = True  # False if column is function-wrapped


@dataclass(frozen=True)
class PartitionInfo:
    """Metadata for a single partition."""

    partition_id: str
    total_rows: int
    total_logical_bytes: int


@dataclass
class PartitionStats:
    """Partition-level distribution for a table."""

    partition_column: str
    partition_type: str  # DAY, MONTH, YEAR, HOUR, INTEGER_RANGE
    partitions: dict[str, PartitionInfo] = field(default_factory=dict)
    total_rows: int = 0
    total_bytes: int = 0


@dataclass
class TableStats:
    """Table-level storage statistics."""

    project_id: str
    dataset: str
    table_name: str
    total_rows: int = 0
    total_logical_bytes: int = 0
    total_billable_bytes: int = 0


@dataclass(frozen=True)
class ColumnStats:
    """Column cardinality info (from spec 065 profiling or cache)."""

    column_name: str
    approx_distinct: int
    null_ratio: float = 0.0


@dataclass(frozen=True)
class PartitionEstimate:
    """Result of partition pruning estimation for a single query."""

    pruned_bytes: int
    total_bytes: int
    pruned_fraction: float  # 0.0 – 1.0
    filter_found: bool  # True if a filter on the partition column was present
    partition_compatible: bool  # False if filter was function-wrapped


@dataclass(frozen=True)
class ClusterEstimate:
    """Result of cluster pruning estimation for a single query."""

    pruned_bytes: int
    total_bytes: int
    pruned_fraction: float  # 0.0 – 1.0
    filter_found: bool


@dataclass(frozen=True)
class SavingsRecommendation:
    """What we recommend for a given opportunity."""

    partition_column: str | None = None
    partition_type: str | None = None  # DAY, MONTH, etc.
    cluster_columns: list[str] = field(default_factory=list)
    cluster_position_offset: int = 0


@dataclass
class JobSavingsDetail:
    """Per-job savings breakdown."""

    job_id: str
    job_cost: Decimal
    bytes_billed: int
    partition_savings_usd: Decimal = Decimal("0")
    cluster_savings_usd: Decimal = Decimal("0")
    total_savings_usd: Decimal = Decimal("0")
    has_partition_filter: bool = False
    has_cluster_filter: bool = False


@dataclass
class OpportunitySavingsEstimate:
    """Aggregated savings estimate for an opportunity."""

    opportunity_id: str
    recommendation_type: str = "cluster"  # partition, cluster, both
    partition_column: str | None = None
    cluster_columns: list[str] = field(default_factory=list)
    jobs_analyzed: int = 0
    jobs_with_partition_filter: int = 0
    jobs_with_cluster_filter: int = 0
    total_bytes_scanned: int = 0
    total_bytes_saved: int = 0
    total_cost_saved: Decimal = Decimal("0")
    per_run_savings: Decimal = Decimal("0")
    monthly_projection: Decimal = Decimal("0")
    confidence: str = "low"  # high, medium, low
    filter_coverage_pct: Decimal = Decimal("0")
    observation_days: int = 0
    job_details: list[JobSavingsDetail] = field(default_factory=list)

    # Pricing constant: BigQuery on-demand = $6.25 per TiB
    BQ_PRICE_PER_BYTE: Decimal = Decimal("6.25") / Decimal(str(1024**4))
