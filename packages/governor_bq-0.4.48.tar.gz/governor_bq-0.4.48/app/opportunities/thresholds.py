"""
Threshold configuration for detection rules.

Provides centralized threshold management with support for:
- Default thresholds per rule type
- Configuration overrides from settings
- Runtime threshold customization
"""

from __future__ import annotations

import logging
from decimal import Decimal
from typing import Any

from app.core.config import get_settings

logger = logging.getLogger(__name__)

# Default thresholds for each rule type
# These are the baseline values used when no override is configured
DEFAULT_THRESHOLDS: dict[str, dict[str, Any]] = {
    "shuffle_spill": {
        "enabled": True,
        "min_job_cost_usd": Decimal("0.10"),
        "description": "Detect queries with shuffle spill to disk",
    },
    "slot_contention": {
        "enabled": True,
        "min_job_cost_usd": Decimal("0.10"),
        "queue_time_ratio_threshold": Decimal("0.30"),  # 30% of total time in queue
        "min_duration_seconds": 60,  # Minimum 1 minute total duration
        "description": "Detect queries experiencing slot contention or queue delays",
    },
    "join_explosion": {
        "enabled": True,
        "min_job_cost_usd": Decimal("0.10"),
        "row_multiplication_threshold": 10,  # 10x row increase
        "description": "Detect queries with excessive row multiplication from joins",
    },
    "partition_pruning": {
        "enabled": True,
        "min_job_cost_usd": Decimal("0.10"),
        "description": "Detect queries not using partition filters effectively",
    },
    "dead_cte": {
        "enabled": False,
        "description": "Detect CTEs defined but never referenced downstream",
    },
    "dead_column": {
        "enabled": False,
        "description": "Detect projected columns never referenced downstream",
    },
    "dead_window_expression": {
        "enabled": False,
        "description": "Detect window-function outputs never referenced downstream",
    },
    "unused_aggregation_output": {
        "enabled": False,
        "description": "Detect aggregate expressions never referenced downstream",
    },
    "redundant_order_by": {
        "enabled": False,
        "description": "Detect ORDER BY inside CTEs that has no downstream effect",
    },
    "unused_join": {
        "enabled": False,
        "description": "Detect LEFT JOINs whose right side is unused",
    },
    "storage_billing_optimization": {
        "enabled": True,
        "description": "Detect datasets where physical billing would reduce costs",
    },
}


def get_rule_thresholds(rule_type: str) -> dict[str, Any]:
    """
    Get thresholds for a specific rule type.

    Merges default thresholds with any configured overrides from settings.

    Args:
        rule_type: The rule type identifier (e.g., 'shuffle_spill')

    Returns:
        Dictionary of threshold values for the rule
    """
    # Start with defaults
    defaults = DEFAULT_THRESHOLDS.get(rule_type, {})

    # Get overrides from settings if available
    settings = get_settings()
    overrides = _get_threshold_overrides(settings, rule_type)

    # Merge defaults with overrides (overrides win)
    thresholds = {**defaults, **overrides}

    logger.debug(f"Thresholds for {rule_type}: {thresholds}")
    return thresholds


def _get_threshold_overrides(settings: Any, rule_type: str) -> dict[str, Any]:
    """
    Extract threshold overrides from settings.

    Settings can define thresholds via environment variables:
    - OPPORTUNITY_SHUFFLE_SPILL_ENABLED=false
    - OPPORTUNITY_SHUFFLE_SPILL_MIN_COST=0.50
    - OPPORTUNITY_SLOT_CONTENTION_QUEUE_RATIO=0.20

    Args:
        settings: Application settings object
        rule_type: The rule type identifier

    Returns:
        Dictionary of override values
    """
    overrides = {}

    # Construct attribute names from rule type
    # e.g., "shuffle_spill" -> "opportunity_shuffle_spill_*"
    prefix = f"opportunity_{rule_type}_"

    # Check for common override patterns
    enabled_attr = f"{prefix}enabled"
    min_cost_attr = f"{prefix}min_cost"

    if hasattr(settings, enabled_attr):
        value = getattr(settings, enabled_attr, None)
        if value is not None:
            overrides["enabled"] = value

    if hasattr(settings, min_cost_attr):
        value = getattr(settings, min_cost_attr, None)
        if value is not None:
            overrides["min_job_cost_usd"] = Decimal(str(value))

    return overrides


def get_all_rule_thresholds() -> dict[str, dict[str, Any]]:
    """
    Get thresholds for all registered rule types.

    Returns:
        Dictionary mapping rule_type -> thresholds
    """
    return {
        rule_type: get_rule_thresholds(rule_type) for rule_type in DEFAULT_THRESHOLDS
    }


def is_rule_enabled(rule_type: str) -> bool:
    """
    Check if a rule is enabled.

    Args:
        rule_type: The rule type identifier

    Returns:
        True if rule is enabled, False otherwise
    """
    thresholds = get_rule_thresholds(rule_type)
    return thresholds.get("enabled", True)


def update_default_thresholds(rule_type: str, thresholds: dict[str, Any]) -> None:
    """
    Update default thresholds for a rule type at runtime.

    This is primarily useful for testing or dynamic configuration.

    Args:
        rule_type: The rule type identifier
        thresholds: New threshold values to merge with existing defaults
    """
    if rule_type not in DEFAULT_THRESHOLDS:
        DEFAULT_THRESHOLDS[rule_type] = {}

    DEFAULT_THRESHOLDS[rule_type].update(thresholds)
    logger.info(f"Updated default thresholds for {rule_type}: {thresholds}")


def register_rule_thresholds(rule_type: str, thresholds: dict[str, Any]) -> None:
    """
    Register thresholds for a new rule type.

    Used when adding new detection rules dynamically.

    Args:
        rule_type: Unique rule type identifier
        thresholds: Default threshold configuration

    Raises:
        ValueError: If rule_type already exists
    """
    if rule_type in DEFAULT_THRESHOLDS:
        raise ValueError(f"Rule type '{rule_type}' already registered")

    DEFAULT_THRESHOLDS[rule_type] = thresholds
    logger.info(f"Registered thresholds for new rule: {rule_type}")
