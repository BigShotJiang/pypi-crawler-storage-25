"""Resolve partition and cluster recommendations for savings estimation.

This module bridges the gap between coarse detection evidence and the richer
metadata already available in synced manifests and INFORMATION_SCHEMA-derived
column metadata.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from decimal import Decimal
from typing import Any

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.opportunities.savings_estimator import extract_table_predicates
from app.opportunities.savings_models import SavingsRecommendation
from app.sync.models import ManifestVersion

_CLUSTER_OPPORTUNITY_TYPES = frozenset(
    {"shuffle_spill", "slot_contention", "join_explosion"}
)
_PARTITIONABLE_BQ_TYPES = frozenset({"DATE", "TIMESTAMP", "DATETIME", "INT64"})


@dataclass(frozen=True)
class ResolvedRecommendationContext:
    """Recommendation data ready for workload estimation."""

    recommendation: SavingsRecommendation
    target_table: str
    evidence_updates: dict[str, Any] = field(default_factory=dict)


def resolve_recommendation_context(
    db: Session,
    opportunity,
    jobs: list[dict],
) -> ResolvedRecommendationContext | None:
    """Resolve the best available recommendation and target table."""

    manifest_content = _load_manifest_content(db, opportunity)

    if opportunity.opportunity_type in _CLUSTER_OPPORTUNITY_TYPES:
        resolved = _resolve_cluster_context(db, opportunity, manifest_content)
        if resolved is not None:
            return resolved

    if opportunity.opportunity_type == "partition_pruning":
        resolved = _resolve_partition_context(db, opportunity, jobs, manifest_content)
        if resolved is not None:
            return resolved

    return _resolve_evidence_fallback(opportunity)


def _resolve_cluster_context(
    db: Session,
    opportunity,
    manifest_content: dict | None,
) -> ResolvedRecommendationContext | None:
    if not manifest_content or not opportunity.dbt_model_name:
        return _resolve_evidence_fallback(opportunity)

    from app.dbt.column_lookup import make_column_lookup
    from app.dbt.lineage_analyzer import analyze_upstream

    nodes = manifest_content.get("nodes", {})
    target_node = _find_node_by_name(nodes, opportunity.dbt_model_name)
    if target_node is None:
        return _resolve_evidence_fallback(opportunity)

    compiled_sql = target_node.get("compiled_code")
    column_lookup = make_column_lookup(db=db, config_id=opportunity.config_id)
    lineage_result = analyze_upstream(
        manifest_content=manifest_content,
        affected_model_name=opportunity.dbt_model_name,
        opportunity_type=opportunity.opportunity_type,
        compiled_sql=compiled_sql,
        column_lookup=column_lookup,
        column_quality_lookup=None,
    )

    for candidate in lineage_result.candidates:
        if not candidate.suggested_cluster_columns:
            continue

        node = nodes.get(candidate.unique_id)
        target_table = (
            _relation_for_node(node, opportunity.affected_table)
            if isinstance(node, dict)
            else opportunity.affected_table
        )
        suggested_columns = list(candidate.suggested_cluster_columns[:4])
        evidence_updates = {
            "recommended_cluster_columns": suggested_columns,
            "recommended_target_table": target_table,
        }
        if candidate.current_cluster_by:
            evidence_updates["existing_cluster_columns"] = list(
                candidate.current_cluster_by
            )
        if candidate.column_quality:
            evidence_updates["column_quality"] = candidate.column_quality

        return ResolvedRecommendationContext(
            recommendation=SavingsRecommendation(
                cluster_columns=suggested_columns,
                cluster_position_offset=len(candidate.current_cluster_by or []),
            ),
            target_table=target_table,
            evidence_updates=evidence_updates,
        )

    return _resolve_evidence_fallback(opportunity)


def _resolve_partition_context(
    db: Session,
    opportunity,
    jobs: list[dict],
    manifest_content: dict | None,
) -> ResolvedRecommendationContext | None:
    evidence_fallback = _resolve_evidence_fallback(opportunity)
    if not manifest_content:
        return evidence_fallback

    from app.dbt.column_lookup import make_column_type_lookup

    nodes = manifest_content.get("nodes", {})
    type_lookup = make_column_type_lookup(db=db, config_id=opportunity.config_id)
    candidate_nodes = _collect_partition_candidate_nodes(
        nodes,
        opportunity,
        jobs,
    )

    best_candidate: tuple[Decimal, dict, str, str, str] | None = None

    for node in candidate_nodes:
        column_types = type_lookup(node)
        if not column_types:
            continue

        target_table = _relation_for_node(node, opportunity.affected_table)
        partition_field = _manifest_partition_field(node)
        if partition_field and partition_field.lower() in column_types:
            bq_type = column_types[partition_field.lower()]
            if bq_type in _PARTITIONABLE_BQ_TYPES:
                return ResolvedRecommendationContext(
                    recommendation=SavingsRecommendation(
                        partition_column=partition_field,
                    ),
                    target_table=target_table,
                    evidence_updates={
                        "recommended_partition_column": partition_field,
                        "partition_data_type": bq_type,
                        "recommended_target_table": target_table,
                    },
                )

        eligible_columns = {
            name: bq_type
            for name, bq_type in column_types.items()
            if bq_type in _PARTITIONABLE_BQ_TYPES
        }
        if not eligible_columns:
            continue

        weighted_scores = _score_partition_columns(
            jobs,
            target_table,
            list(eligible_columns.keys()),
        )
        if not weighted_scores:
            continue

        column_name, score = max(
            weighted_scores.items(),
            key=lambda item: (item[1], item[0]),
        )
        bq_type = eligible_columns[column_name]
        candidate = (
            score,
            node,
            target_table,
            column_name,
            bq_type,
        )
        if best_candidate is None or candidate[0] > best_candidate[0]:
            best_candidate = candidate

    if best_candidate is None:
        return evidence_fallback

    _, _, target_table, column_name, bq_type = best_candidate
    return ResolvedRecommendationContext(
        recommendation=SavingsRecommendation(partition_column=column_name),
        target_table=target_table,
        evidence_updates={
            "recommended_partition_column": column_name,
            "partition_data_type": bq_type,
            "recommended_target_table": target_table,
        },
    )


def _resolve_evidence_fallback(opportunity) -> ResolvedRecommendationContext | None:
    evidence = opportunity.evidence_snapshot or {}
    opp_type = opportunity.opportunity_type

    partition_column = evidence.get("recommended_partition_column")
    cluster_columns: list[str] = []

    if opp_type == "partition_pruning":
        cluster_columns = list(evidence.get("recommended_cluster_columns") or [])
    elif opp_type in ("shuffle_spill", "slot_contention"):
        cluster_columns = list(
            evidence.get("recommended_cluster_columns")
            or evidence.get("cluster_columns")
            or evidence.get("top_shuffle_keys")
            or []
        )
    elif opp_type == "join_explosion":
        cluster_columns = list(
            evidence.get("recommended_cluster_columns")
            or evidence.get("join_key_columns")
            or []
        )

    if not partition_column and not cluster_columns:
        return None

    existing_cluster_columns = evidence.get("existing_cluster_columns") or []
    return ResolvedRecommendationContext(
        recommendation=SavingsRecommendation(
            partition_column=partition_column,
            cluster_columns=cluster_columns[:4],
            cluster_position_offset=len(existing_cluster_columns),
        ),
        target_table=(
            evidence.get("recommended_target_table") or opportunity.affected_table
        ),
        evidence_updates={},
    )


def _collect_partition_candidate_nodes(
    nodes: dict[str, Any],
    opportunity,
    jobs: list[dict],
) -> list[dict]:
    ordered: list[dict] = []
    seen: set[str] = set()

    def add_node(node: dict | None) -> None:
        if not isinstance(node, dict):
            return
        unique_id = str(node.get("unique_id") or id(node))
        if unique_id in seen:
            return
        seen.add(unique_id)
        ordered.append(node)

    add_node(_find_node_by_name(nodes, opportunity.dbt_model_name))
    add_node(_find_node_by_relation(nodes, opportunity.affected_table))

    for table_name in _referenced_tables_by_weight(jobs):
        add_node(_find_node_by_relation(nodes, table_name))

    return ordered


def _score_partition_columns(
    jobs: list[dict],
    target_table: str,
    eligible_columns: list[str],
) -> dict[str, Decimal]:
    scores: dict[str, Decimal] = {}

    for job in jobs:
        sql = job.get("query") or ""
        if not sql:
            continue

        bytes_billed = int(job.get("total_bytes_billed") or 0)
        weight = Decimal(str(max(bytes_billed, 1)))
        predicates = extract_table_predicates(sql, target_table, eligible_columns)

        for predicate in predicates:
            if not predicate.is_partition_compatible:
                continue
            multiplier = _partition_predicate_weight(
                predicate.operator,
                predicate.values,
            )
            if multiplier <= 0:
                continue
            scores[predicate.column] = scores.get(predicate.column, Decimal("0")) + (
                weight * multiplier
            )

    return scores


def _partition_predicate_weight(
    operator: str,
    values: list[str | None],
) -> Decimal:
    if operator == "eq":
        return Decimal("1.0")
    if operator == "in":
        value_count = max(sum(1 for value in values if value is not None), 1)
        return Decimal("1.0") / Decimal(str(value_count))
    if operator == "between":
        return Decimal("0.7")
    if operator in {"gt", "gte", "lt", "lte"}:
        return Decimal("0.6")
    if operator == "is_null":
        return Decimal("0.1")
    return Decimal("0")


def _load_manifest_content(db: Session, opportunity) -> dict | None:
    manifest_version = None
    if opportunity.manifest_version_id:
        manifest_version = db.get(ManifestVersion, opportunity.manifest_version_id)

    if manifest_version is None:
        manifest_version = (
            db.execute(
                select(ManifestVersion)
                .where(ManifestVersion.config_id == opportunity.config_id)
                .order_by(ManifestVersion.retrieved_at.desc())
            )
            .scalars()
            .first()
        )

    if manifest_version is None or not manifest_version.content:
        return None

    if isinstance(manifest_version.content, str):
        try:
            return json.loads(manifest_version.content)
        except json.JSONDecodeError:
            return None

    return manifest_version.content


def _find_node_by_name(nodes: dict[str, Any], model_name: str | None) -> dict | None:
    if not model_name:
        return None

    for node_id, node in nodes.items():
        if node_id.startswith("model.") and isinstance(node, dict):
            if node.get("name") == model_name:
                return node
    return None


def _find_node_by_relation(
    nodes: dict[str, Any], table_name: str | None
) -> dict | None:
    if not table_name:
        return None

    target = _normalize_table_name(table_name)
    target_parts = target.split(".")

    for node_id, node in nodes.items():
        if not node_id.startswith("model.") or not isinstance(node, dict):
            continue

        for relation in _node_relation_variants(node):
            normalized = _normalize_table_name(relation)
            if normalized == target:
                return node
            relation_parts = normalized.split(".")
            if len(relation_parts) >= 2 and len(target_parts) >= 2:
                if relation_parts[-2:] == target_parts[-2:]:
                    return node
    return None


def _node_relation_variants(node: dict) -> list[str]:
    relation_names: list[str] = []

    relation_name = node.get("relation_name")
    if relation_name:
        relation_names.append(str(relation_name))

    database = str(node.get("database") or "").strip()
    schema = str(node.get("schema") or "").strip()
    identifier = str(
        node.get("identifier") or node.get("alias") or node.get("name") or ""
    ).strip()

    if database and schema and identifier:
        relation_names.append(f"{database}.{schema}.{identifier}")
    if schema and identifier:
        relation_names.append(f"{schema}.{identifier}")
    if identifier:
        relation_names.append(identifier)

    deduped: list[str] = []
    seen: set[str] = set()
    for relation in relation_names:
        normalized = _normalize_table_name(relation)
        if normalized in seen:
            continue
        seen.add(normalized)
        deduped.append(relation)
    return deduped


def _relation_for_node(node: dict | None, fallback: str) -> str:
    if not isinstance(node, dict):
        return fallback

    relation_names = _node_relation_variants(node)
    return relation_names[0] if relation_names else fallback


def _manifest_partition_field(node: dict) -> str | None:
    config = node.get("config") or {}
    partition_by = config.get("partition_by")
    if isinstance(partition_by, dict):
        field_name = partition_by.get("field")
        return str(field_name) if field_name else None
    if isinstance(partition_by, str):
        return partition_by
    return None


def _referenced_tables_by_weight(jobs: list[dict]) -> list[str]:
    weighted_tables: dict[str, Decimal] = {}
    for job in jobs:
        weight = Decimal(str(max(int(job.get("total_bytes_billed") or 0), 1)))
        for table in job.get("referenced_tables") or []:
            if not isinstance(table, str):
                continue
            normalized = _normalize_table_name(table)
            if not normalized:
                continue
            weighted_tables[normalized] = (
                weighted_tables.get(
                    normalized,
                    Decimal("0"),
                )
                + weight
            )

    return [
        table_name
        for table_name, _ in sorted(
            weighted_tables.items(),
            key=lambda item: (item[1], item[0]),
            reverse=True,
        )
    ]


def _normalize_table_name(table_name: str) -> str:
    return table_name.replace("`", "").strip().lower()
