"""
Severity score calculation for cost optimization opportunities.

Implements the 1-100 severity scale with dollar savings as the primary factor.
"""

from decimal import Decimal

_BQ_ON_DEMAND_PRICE_PER_TIB = Decimal("6.25")
_BYTES_PER_TIB = Decimal(str(1024**4))
_BQ_ON_DEMAND_PRICE_PER_BYTE = _BQ_ON_DEMAND_PRICE_PER_TIB / _BYTES_PER_TIB


def calculate_severity(
    estimated_savings: Decimal,
    confidence: float = 1.0,
    frequency: int = 1,
) -> int:
    """
    Calculate severity score (1-100) with dollar savings as primary factor.

    Args:
        estimated_savings: Estimated dollar savings if issue is fixed
        confidence: Detection confidence (0.0-1.0), defaults to 1.0
        frequency: How often this issue occurs (occurrence count)

    Returns:
        Severity score between 1 and 100

    Formula:
        - Base score from savings tiers:
            - $0-10:     1-20  (low impact)
            - $10-100:   21-50 (moderate impact)
            - $100-1000: 51-80 (high impact)
            - $1000+:    81-100 (critical impact)
        - Adjusted by confidence: score * max(0.5, confidence)
        - Frequency boost: +5 for recurring issues

    Examples:
        >>> calculate_severity(Decimal("5.00"))
        10
        >>> calculate_severity(Decimal("50.00"))
        35
        >>> calculate_severity(Decimal("500.00"))
        65
        >>> calculate_severity(Decimal("5000.00"))
        89
    """
    # Ensure positive values
    savings = max(Decimal("0"), estimated_savings)
    conf = max(0.0, min(1.0, confidence))

    # Calculate base score from savings tier
    if savings < 10:
        # $0-10 → 1-20
        base = 1 + int((float(savings) / 10) * 19)
    elif savings < 100:
        # $10-100 → 21-50
        base = 21 + int(((float(savings) - 10) / 90) * 29)
    elif savings < 1000:
        # $100-1000 → 51-80
        base = 51 + int(((float(savings) - 100) / 900) * 29)
    else:
        # $1000+ → 81-100
        base = 81 + min(19, int(((float(savings) - 1000) / 9000) * 19))

    # Apply confidence adjustment (minimum 50% to avoid zero scores)
    adjusted = int(base * max(0.5, conf))

    # Frequency boost for recurring issues
    if frequency > 1:
        adjusted = min(100, adjusted + 5)

    # Clamp to valid range
    return max(1, min(100, adjusted))


def estimate_savings_from_cost(
    current_cost: Decimal,
    reduction_percent: float,
) -> Decimal:
    """
    Estimate potential savings from a percentage reduction.

    Args:
        current_cost: Current cost of the operation (USD)
        reduction_percent: Expected percentage reduction (0-100)

    Returns:
        Estimated savings in USD
    """
    reduction = max(0.0, min(100.0, reduction_percent)) / 100
    return current_cost * Decimal(str(reduction))


def estimate_cost_from_bytes_processed(
    bytes_processed: Decimal | float | int,
) -> Decimal:
    """Estimate BigQuery on-demand cost from bytes processed using TiB pricing."""
    billed_bytes = max(Decimal("0"), Decimal(str(bytes_processed)))
    return billed_bytes * _BQ_ON_DEMAND_PRICE_PER_BYTE
