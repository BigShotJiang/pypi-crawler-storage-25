from __future__ import annotations

import os

from opentelemetry import trace
from opentelemetry.sdk.resources import Resource
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import BatchSpanProcessor, ConsoleSpanExporter
from opentelemetry.instrumentation.fastapi import FastAPIInstrumentor
from opentelemetry.instrumentation.sqlalchemy import SQLAlchemyInstrumentor

_fastapi_instrumented = False
_sqlalchemy_instrumented = False


def configure_tracing(service_name: str) -> TracerProvider:
    current_provider = trace.get_tracer_provider()
    if isinstance(current_provider, TracerProvider):
        return current_provider

    resource = Resource.create({"service.name": service_name})
    provider = TracerProvider(resource=resource)
    trace.set_tracer_provider(provider)

    if os.environ.get("OTEL_EXPORTER", "").lower() == "console":
        provider.add_span_processor(BatchSpanProcessor(ConsoleSpanExporter()))

    return provider


def instrument_fastapi(app) -> None:
    global _fastapi_instrumented
    if _fastapi_instrumented:
        return
    FastAPIInstrumentor.instrument_app(app)
    _fastapi_instrumented = True


def instrument_sqlalchemy(engine) -> None:
    global _sqlalchemy_instrumented
    if _sqlalchemy_instrumented:
        return
    SQLAlchemyInstrumentor().instrument(engine=engine)
    _sqlalchemy_instrumented = True
