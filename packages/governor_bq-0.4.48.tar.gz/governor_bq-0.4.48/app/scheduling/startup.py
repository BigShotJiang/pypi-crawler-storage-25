from __future__ import annotations

import logging

from apscheduler.executors.pool import ThreadPoolExecutor
from apscheduler.jobstores.sqlalchemy import SQLAlchemyJobStore
from apscheduler.schedulers.asyncio import AsyncIOScheduler

from app.scheduling.service import SchedulingService

logger = logging.getLogger("app.scheduling")


def init_scheduler(engine) -> AsyncIOScheduler:
    """Create and configure the APScheduler instance.

    Args:
        engine: SQLAlchemy engine (shared with the application)

    Returns:
        Configured AsyncIOScheduler (not yet started)
    """
    jobstores = {
        "default": SQLAlchemyJobStore(engine=engine),
    }
    executors = {
        "default": ThreadPoolExecutor(max_workers=5),
    }
    job_defaults = {
        "coalesce": True,
        "misfire_grace_time": None,
    }

    scheduler = AsyncIOScheduler(
        jobstores=jobstores,
        executors=executors,
        job_defaults=job_defaults,
        timezone="UTC",
    )
    return scheduler


def load_schedules(scheduler) -> int:
    """Load all enabled schedules from the database into APScheduler.

    Args:
        scheduler: Running AsyncIOScheduler

    Returns:
        Number of schedules loaded
    """
    from app.configurations.models import ManifestConfiguration
    from app.db.session import SessionLocal

    session = SessionLocal()
    try:
        configs = (
            session.query(ManifestConfiguration)
            .filter(
                ManifestConfiguration.schedule_enabled.is_(True),
                ManifestConfiguration.status == "active",
            )
            .all()
        )

        count = 0
        for config in configs:
            try:
                SchedulingService.register_schedule(scheduler, config)
                count += 1
            except (ValueError, RuntimeError):
                logger.exception(
                    "Failed to register schedule for config %s (%s)",
                    config.id,
                    config.name,
                )

        logger.info("Loaded %d schedules from database", count)
        return count
    finally:
        session.close()


def register_pr_status_sync(scheduler) -> None:
    """Register periodic PR status sync job (every 5 minutes).

    Polls all open PR records against the GitHub API and updates
    their status when merged or closed.  Also runs PR collection
    to discover any Governor PRs on GitHub that are not yet tracked.

    The first run fires immediately on startup so that PR history
    is restored as soon as the server starts.
    """
    from datetime import datetime, timezone

    from apscheduler.triggers.interval import IntervalTrigger

    from app.pullrequests.sync import execute_pr_status_sync

    scheduler.add_job(
        execute_pr_status_sync,
        trigger=IntervalTrigger(minutes=5, timezone="UTC"),
        id="pr-status-sync",
        next_run_time=datetime.now(timezone.utc),
        replace_existing=True,
        coalesce=True,
        misfire_grace_time=None,
    )
    logger.info("Registered PR status sync job (every 5 minutes, immediate first run)")


def register_post_merge_savings_calculation(scheduler) -> None:
    """Register periodic post-merge savings calculation job (every 6 hours).

    Recalculates verified savings for all resolved opportunities
    with pending or collecting status.
    """
    from apscheduler.triggers.interval import IntervalTrigger

    from app.pullrequests.savings import execute_savings_calculation

    scheduler.add_job(
        execute_savings_calculation,
        trigger=IntervalTrigger(hours=6, timezone="UTC"),
        id="post-merge-savings-calculation",
        replace_existing=True,
        coalesce=True,
        misfire_grace_time=None,
    )
    logger.info("Registered post-merge savings calculation job (every 6 hours)")


def shutdown_scheduler(scheduler) -> None:
    """Gracefully shut down the scheduler."""
    try:
        scheduler.shutdown(wait=True)
        logger.info("Scheduler shut down gracefully")
    except (ValueError, RuntimeError):
        logger.exception("Error shutting down scheduler")
