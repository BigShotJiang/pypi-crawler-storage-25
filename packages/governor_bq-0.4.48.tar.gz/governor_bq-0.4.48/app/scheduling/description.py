from __future__ import annotations

from cron_descriptor import get_description, Options


def describe_schedule(schedule_type: str, schedule_value: str) -> str:
    """Return human-readable English description of a schedule.

    Args:
        schedule_type: "interval" or "cron"
        schedule_value: hours string for interval, cron expression for cron

    Returns:
        "Every 24 hours" or "At 02:00, every day, UTC"
    """
    if schedule_type == "interval":
        try:
            hours = int(schedule_value)
        except (ValueError, TypeError):
            return f"Every {schedule_value} hours"
        if hours == 1:
            return "Every 1 hour"
        return f"Every {hours} hours"

    if schedule_type == "cron":
        try:
            options = Options()
            options.use_24hour_time_format = True
            options.casing_type = 0  # Sentence
            desc = get_description(schedule_value, options)
            return f"{desc}, UTC"
        except (ValueError, AttributeError):
            return schedule_value

    return schedule_value
