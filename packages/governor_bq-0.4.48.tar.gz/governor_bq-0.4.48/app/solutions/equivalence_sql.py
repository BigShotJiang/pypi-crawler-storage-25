"""BigQuery SQL generator for manual original-vs-optimized output verification."""

from __future__ import annotations

import re
from dataclasses import dataclass
from textwrap import indent
from typing import Literal

from app.dashboard.formatters import apply_cost_multiplier, get_cost_multiplier

VerificationProfile = Literal["core", "strict"]
VerificationOutputMode = Literal["summary", "audit"]

_DEFAULT_PROFILE: VerificationProfile = "core"
_VALID_PROFILES: tuple[VerificationProfile, ...] = ("core", "strict")
_DEFAULT_OUTPUT_MODE: VerificationOutputMode = "summary"
_VALID_OUTPUT_MODES: tuple[VerificationOutputMode, ...] = ("summary", "audit")
_DEFAULT_NUMERIC_TOLERANCE_ABS = 1e-8
_DEFAULT_NUMERIC_TOLERANCE_PCT = 1e-12
_DEFAULT_MISMATCH_SAMPLE_LIMIT = 50
_MAX_MISMATCH_SAMPLE_LIMIT = 500
_DEFAULT_NULL_RATE_TOLERANCE = 1e-12

_VOLATILE_PATTERNS: tuple[tuple[re.Pattern[str], str], ...] = (
    (re.compile(r"\brand\s*\(", re.IGNORECASE), "RAND()"),
    (
        re.compile(r"\bcurrent_timestamp\s*\(", re.IGNORECASE),
        "CURRENT_TIMESTAMP()",
    ),
    (
        re.compile(r"\bcurrent_datetime\s*\(", re.IGNORECASE),
        "CURRENT_DATETIME()",
    ),
    (re.compile(r"\bcurrent_date\s*\(", re.IGNORECASE), "CURRENT_DATE()"),
    (re.compile(r"\bcurrent_time\s*\(", re.IGNORECASE), "CURRENT_TIME()"),
    (re.compile(r"\bgenerate_uuid\s*\(", re.IGNORECASE), "GENERATE_UUID()"),
)


@dataclass(frozen=True)
class VerificationSqlRequest:
    original_sql: str
    optimized_sql: str
    profile: VerificationProfile = _DEFAULT_PROFILE
    output_mode: VerificationOutputMode = _DEFAULT_OUTPUT_MODE
    primary_key_columns: list[str] | None = None
    compare_columns: list[str] | None = None
    numeric_tolerance_abs: float = _DEFAULT_NUMERIC_TOLERANCE_ABS
    numeric_tolerance_pct: float = _DEFAULT_NUMERIC_TOLERANCE_PCT
    mismatch_sample_limit: int = _DEFAULT_MISMATCH_SAMPLE_LIMIT
    original_dry_run: object | None = None
    optimized_dry_run: object | None = None


@dataclass(frozen=True)
class VerificationWarning:
    code: str
    message: str


@dataclass(frozen=True)
class VerificationCheckProfile:
    profile_id: VerificationProfile
    enabled_checks: tuple[str, ...]
    description: str


@dataclass(frozen=True)
class VerificationSqlArtifact:
    sql_text: str | None
    profile: VerificationProfile
    output_mode: VerificationOutputMode
    source_label: str
    warnings: list[VerificationWarning]
    unavailable_reason: str | None


@dataclass(frozen=True)
class VerificationPerformanceSnapshot:
    valid: bool
    total_bytes_processed: int | None
    estimated_cost_usd_raw: float | None
    estimated_cost_usd_display: float | None
    cost_display_multiplier: float
    error: str | None


_PROFILE_CATALOG: dict[VerificationProfile, VerificationCheckProfile] = {
    "core": VerificationCheckProfile(
        profile_id="core",
        enabled_checks=(
            "row_count_equal",
            "column_set_equal",
            "bag_equivalence",
            "null_rate_delta",
            "numeric_aggregate_delta",
        ),
        description=(
            "Core equivalence profile with row count, column set, bag comparison, "
            "null-rate deltas, and numeric aggregate checks."
        ),
    ),
    "strict": VerificationCheckProfile(
        profile_id="strict",
        enabled_checks=(
            "row_count_equal",
            "column_set_equal",
            "bag_equivalence",
            "null_rate_delta",
            "numeric_aggregate_delta",
        ),
        description=(
            "Strict profile placeholder. Uses core checks in v1 with the same SQL "
            "shape and deterministic output."
        ),
    ),
}


def get_verification_profile(profile: str | None) -> VerificationCheckProfile:
    normalized = normalize_verification_profile(profile)
    return _PROFILE_CATALOG[normalized]


def normalize_verification_profile(profile: str | None) -> VerificationProfile:
    if not profile:
        return _DEFAULT_PROFILE
    lowered = profile.strip().lower()
    if lowered in _VALID_PROFILES:
        return lowered  # type: ignore[return-value]
    return _DEFAULT_PROFILE


def normalize_verification_output_mode(
    output_mode: str | None,
) -> VerificationOutputMode:
    if not output_mode:
        return _DEFAULT_OUTPUT_MODE
    lowered = output_mode.strip().lower()
    if lowered in _VALID_OUTPUT_MODES:
        return lowered  # type: ignore[return-value]
    return _DEFAULT_OUTPUT_MODE


def build_verification_sql_artifact(
    *,
    original_sql: str | None,
    optimized_sql: str | None,
    source_label: str | None = None,
    profile: str | None = None,
    output_mode: str | None = None,
    primary_key_columns: list[str] | None = None,
    compare_columns: list[str] | None = None,
    numeric_tolerance_abs: float = _DEFAULT_NUMERIC_TOLERANCE_ABS,
    numeric_tolerance_pct: float = _DEFAULT_NUMERIC_TOLERANCE_PCT,
    mismatch_sample_limit: int = _DEFAULT_MISMATCH_SAMPLE_LIMIT,
    original_dry_run: object | None = None,
    optimized_dry_run: object | None = None,
) -> VerificationSqlArtifact:
    """Build verification SQL + metadata for the solution page."""

    normalized_profile = normalize_verification_profile(profile)
    normalized_output_mode = normalize_verification_output_mode(output_mode)
    source = source_label or "Original SQL baseline"
    warnings: list[VerificationWarning] = []

    unavailable_reason = _build_unavailable_reason(original_sql, optimized_sql)
    if unavailable_reason:
        return VerificationSqlArtifact(
            sql_text=None,
            profile=normalized_profile,
            output_mode=normalized_output_mode,
            source_label=source,
            warnings=warnings,
            unavailable_reason=unavailable_reason,
        )

    request = VerificationSqlRequest(
        original_sql=(original_sql or "").strip(),
        optimized_sql=(optimized_sql or "").strip(),
        profile=normalized_profile,
        output_mode=normalized_output_mode,
        primary_key_columns=primary_key_columns,
        compare_columns=compare_columns,
        numeric_tolerance_abs=numeric_tolerance_abs,
        numeric_tolerance_pct=numeric_tolerance_pct,
        mismatch_sample_limit=mismatch_sample_limit,
        original_dry_run=original_dry_run,
        optimized_dry_run=optimized_dry_run,
    )
    sql_text, generation_warnings = build_equivalence_verification_sql(request)
    warnings.extend(generation_warnings)

    if source.strip().lower().startswith("latest executed sql"):
        warnings.append(
            VerificationWarning(
                code="fallback_baseline_used",
                message=(
                    "Original baseline came from latest executed BigQuery job SQL "
                    "instead of manifest compiled SQL."
                ),
            )
        )
    if normalized_output_mode == "audit" and not _sanitize_identifier_list(
        primary_key_columns
    ):
        warnings.append(
            VerificationWarning(
                code="missing_primary_key_fallback",
                message=(
                    "Audit mode is running without primary key columns; "
                    "classification falls back to full-row fingerprints, which "
                    "reduces modified-row diagnostics."
                ),
            )
        )

    return VerificationSqlArtifact(
        sql_text=sql_text,
        profile=normalized_profile,
        output_mode=normalized_output_mode,
        source_label=source,
        warnings=warnings,
        unavailable_reason=None,
    )


def build_equivalence_verification_sql(
    request: VerificationSqlRequest,
) -> tuple[str, list[VerificationWarning]]:
    """Build deterministic BigQuery SQL for output-equivalence checks."""

    normalized_profile = normalize_verification_profile(request.profile)
    normalized_output_mode = normalize_verification_output_mode(request.output_mode)
    profile = _PROFILE_CATALOG[normalized_profile]

    original_sql = request.original_sql.strip()
    optimized_sql = request.optimized_sql.strip()

    if not original_sql or not optimized_sql:
        raise ValueError(
            "Both original_sql and optimized_sql are required to generate "
            "verification SQL."
        )

    mismatch_sample_limit = min(
        max(int(request.mismatch_sample_limit), 1), _MAX_MISMATCH_SAMPLE_LIMIT
    )
    numeric_tolerance_abs = max(float(request.numeric_tolerance_abs), 0.0)
    numeric_tolerance_pct = max(float(request.numeric_tolerance_pct), 0.0)

    warnings: list[VerificationWarning] = []
    warnings.extend(_detect_volatile_warnings(original_sql, optimized_sql))
    original_dry_run = _normalize_dry_run_snapshot(request.original_dry_run)
    optimized_dry_run = _normalize_dry_run_snapshot(request.optimized_dry_run)

    header_comment = _build_header_comment(
        profile=profile,
        output_mode=normalized_output_mode,
        numeric_tolerance_abs=numeric_tolerance_abs,
        numeric_tolerance_pct=numeric_tolerance_pct,
        mismatch_sample_limit=mismatch_sample_limit,
        original_dry_run=original_dry_run,
        optimized_dry_run=optimized_dry_run,
    )
    performance_rows_sql = _build_performance_rows_sql(
        original_dry_run=original_dry_run,
        optimized_dry_run=optimized_dry_run,
        include_result_type=normalized_output_mode == "audit",
    )
    if normalized_output_mode == "audit":
        sql = _build_audit_sql(
            header_comment=header_comment,
            original_sql=original_sql,
            optimized_sql=optimized_sql,
            mismatch_sample_limit=mismatch_sample_limit,
            primary_key_columns=request.primary_key_columns,
            compare_columns=request.compare_columns,
            performance_rows_sql=performance_rows_sql,
        )
        return sql.strip() + "\n", warnings

    sql = f"""{header_comment}
WITH
original_query AS (
{_indent_sql_block(original_sql)}
),
optimized_query AS (
{_indent_sql_block(optimized_sql)}
),
original_rows AS (
  SELECT TO_JSON_STRING(t) AS row_json
  FROM original_query AS t
),
optimized_rows AS (
  SELECT TO_JSON_STRING(t) AS row_json
  FROM optimized_query AS t
),
row_counts AS (
  SELECT
    (SELECT COUNT(*) FROM original_query) AS original_count,
    (SELECT COUNT(*) FROM optimized_query) AS optimized_count
),
original_bag AS (
  SELECT row_json, COUNT(*) AS row_count
  FROM original_rows
  GROUP BY row_json
),
optimized_bag AS (
  SELECT row_json, COUNT(*) AS row_count
  FROM optimized_rows
  GROUP BY row_json
),
bag_diffs AS (
  SELECT
    COALESCE(o.row_json, m.row_json) AS row_json,
    IFNULL(o.row_count, 0) AS original_count,
    IFNULL(m.row_count, 0) AS optimized_count
  FROM original_bag AS o
  FULL OUTER JOIN optimized_bag AS m USING (row_json)
  WHERE IFNULL(o.row_count, 0) != IFNULL(m.row_count, 0)
),
original_keys AS (
  SELECT ARRAY_AGG(DISTINCT key ORDER BY key) AS keys
  FROM original_rows AS r
  CROSS JOIN UNNEST(
    JSON_KEYS(PARSE_JSON(r.row_json, wide_number_mode => 'round'))
  ) AS key
),
optimized_keys AS (
  SELECT ARRAY_AGG(DISTINCT key ORDER BY key) AS keys
  FROM optimized_rows AS r
  CROSS JOIN UNNEST(
    JSON_KEYS(PARSE_JSON(r.row_json, wide_number_mode => 'round'))
  ) AS key
),
key_sets AS (
  SELECT
    COALESCE((SELECT keys FROM original_keys), ARRAY<STRING>[]) AS original_keys,
    COALESCE((SELECT keys FROM optimized_keys), ARRAY<STRING>[]) AS optimized_keys
),
key_diffs AS (
  SELECT
    ARRAY(
      SELECT key FROM UNNEST(original_keys) AS key
      EXCEPT DISTINCT
      SELECT key FROM UNNEST(optimized_keys) AS key
    ) AS only_original,
    ARRAY(
      SELECT key FROM UNNEST(optimized_keys) AS key
      EXCEPT DISTINCT
      SELECT key FROM UNNEST(original_keys) AS key
    ) AS only_optimized,
    ARRAY(
      SELECT key FROM UNNEST(original_keys) AS key
      INTERSECT DISTINCT
      SELECT key FROM UNNEST(optimized_keys) AS key
    ) AS shared_keys
  FROM key_sets
),
all_inferred_keys AS (
  SELECT DISTINCT key_name
  FROM key_sets
  CROSS JOIN UNNEST(
    ARRAY(
      SELECT key FROM UNNEST(original_keys) AS key
      UNION DISTINCT
      SELECT key FROM UNNEST(optimized_keys) AS key
    )
  ) AS key_name
),
null_counts_original AS (
  SELECT
    k.key_name,
    COUNT(*) AS total_count,
    COUNTIF(
      REGEXP_CONTAINS(
        r.row_json,
        FORMAT(
          r'"%s"\\s*:\\s*null',
          REGEXP_REPLACE(
            k.key_name,
            r'([\\\\.\\^\\$\\*\\+\\?\\(\\)\\[\\]\\{{\\}}\\|\\-])',
            r'\\\\\\1'
          )
        )
      )
    ) AS null_count
  FROM all_inferred_keys AS k
  CROSS JOIN original_rows AS r
  GROUP BY k.key_name
),
null_counts_optimized AS (
  SELECT
    k.key_name,
    COUNT(*) AS total_count,
    COUNTIF(
      REGEXP_CONTAINS(
        r.row_json,
        FORMAT(
          r'"%s"\\s*:\\s*null',
          REGEXP_REPLACE(
            k.key_name,
            r'([\\\\.\\^\\$\\*\\+\\?\\(\\)\\[\\]\\{{\\}}\\|\\-])',
            r'\\\\\\1'
          )
        )
      )
    ) AS null_count
  FROM all_inferred_keys AS k
  CROSS JOIN optimized_rows AS r
  GROUP BY k.key_name
),
null_rate_diffs AS (
  SELECT
    k.key_name,
    IFNULL(o.total_count, 0) AS original_total_count,
    IFNULL(m.total_count, 0) AS optimized_total_count,
    IFNULL(o.null_count, 0) AS original_null_count,
    IFNULL(m.null_count, 0) AS optimized_null_count,
    SAFE_DIVIDE(
      IFNULL(o.null_count, 0),
      NULLIF(IFNULL(o.total_count, 0), 0)
    ) AS original_null_rate,
    SAFE_DIVIDE(
      IFNULL(m.null_count, 0),
      NULLIF(IFNULL(m.total_count, 0), 0)
    ) AS optimized_null_rate,
    ABS(IFNULL(o.null_count, 0) - IFNULL(m.null_count, 0)) AS null_count_delta,
    ABS(
      SAFE_DIVIDE(
        IFNULL(o.null_count, 0),
        NULLIF(IFNULL(o.total_count, 0), 0)
      ) - SAFE_DIVIDE(
        IFNULL(m.null_count, 0),
        NULLIF(IFNULL(m.total_count, 0), 0)
      )
    ) AS rate_delta
  FROM all_inferred_keys AS k
  LEFT JOIN null_counts_original AS o USING (key_name)
  LEFT JOIN null_counts_optimized AS m USING (key_name)
),
numeric_values_original AS (
  SELECT
    k.key_name,
    SAFE_CAST(
      REGEXP_EXTRACT(
        r.row_json,
        FORMAT(
          r'"%s"\\s*:\\s*(-?(?:\\d+\\.?\\d*|\\.\\d+)(?:[eE][+-]?\\d+)?)',
          REGEXP_REPLACE(
            k.key_name,
            r'([\\\\.\\^\\$\\*\\+\\?\\(\\)\\[\\]\\{{\\}}\\|\\-])',
            r'\\\\\\1'
          )
        )
      ) AS FLOAT64
    ) AS numeric_value
  FROM all_inferred_keys AS k
  CROSS JOIN original_rows AS r
),
numeric_values_optimized AS (
  SELECT
    k.key_name,
    SAFE_CAST(
      REGEXP_EXTRACT(
        r.row_json,
        FORMAT(
          r'"%s"\\s*:\\s*(-?(?:\\d+\\.?\\d*|\\.\\d+)(?:[eE][+-]?\\d+)?)',
          REGEXP_REPLACE(
            k.key_name,
            r'([\\\\.\\^\\$\\*\\+\\?\\(\\)\\[\\]\\{{\\}}\\|\\-])',
            r'\\\\\\1'
          )
        )
      ) AS FLOAT64
    ) AS numeric_value
  FROM all_inferred_keys AS k
  CROSS JOIN optimized_rows AS r
),
numeric_stats_original AS (
  SELECT
    key_name,
    COUNTIF(numeric_value IS NOT NULL) AS numeric_count,
    SUM(numeric_value) AS sum_value,
    MIN(numeric_value) AS min_value,
    MAX(numeric_value) AS max_value,
    AVG(numeric_value) AS avg_value
  FROM numeric_values_original
  GROUP BY key_name
),
numeric_stats_optimized AS (
  SELECT
    key_name,
    COUNTIF(numeric_value IS NOT NULL) AS numeric_count,
    SUM(numeric_value) AS sum_value,
    MIN(numeric_value) AS min_value,
    MAX(numeric_value) AS max_value,
    AVG(numeric_value) AS avg_value
  FROM numeric_values_optimized
  GROUP BY key_name
),
numeric_compare AS (
  SELECT
    COALESCE(o.key_name, m.key_name) AS key_name,
    IFNULL(o.numeric_count, 0) AS original_numeric_count,
    IFNULL(m.numeric_count, 0) AS optimized_numeric_count,
    o.sum_value AS original_sum,
    m.sum_value AS optimized_sum,
    o.min_value AS original_min,
    m.min_value AS optimized_min,
    o.max_value AS original_max,
    m.max_value AS optimized_max,
    o.avg_value AS original_avg,
    m.avg_value AS optimized_avg
  FROM numeric_stats_original AS o
  FULL OUTER JOIN numeric_stats_optimized AS m USING (key_name)
  WHERE IFNULL(o.numeric_count, 0) > 0 OR IFNULL(m.numeric_count, 0) > 0
),
numeric_compare_scored AS (
  SELECT
    key_name,
    original_numeric_count,
    optimized_numeric_count,
    original_sum,
    optimized_sum,
    original_min,
    optimized_min,
    original_max,
    optimized_max,
    original_avg,
    optimized_avg,
    ABS(IFNULL(original_sum, 0.0) - IFNULL(optimized_sum, 0.0)) AS sum_abs_delta,
    ABS(IFNULL(original_min, 0.0) - IFNULL(optimized_min, 0.0)) AS min_abs_delta,
    ABS(IFNULL(original_max, 0.0) - IFNULL(optimized_max, 0.0)) AS max_abs_delta,
    ABS(IFNULL(original_avg, 0.0) - IFNULL(optimized_avg, 0.0)) AS avg_abs_delta
  FROM numeric_compare
),
numeric_compare_eval AS (
  SELECT
    *,
    (
      sum_abs_delta <= {numeric_tolerance_abs}
      OR sum_abs_delta <= GREATEST(ABS(IFNULL(original_sum, 0.0)), 1e-12) * {numeric_tolerance_pct}
    ) AS sum_pass,
    (
      min_abs_delta <= {numeric_tolerance_abs}
      OR min_abs_delta <= GREATEST(ABS(IFNULL(original_min, 0.0)), 1e-12) * {numeric_tolerance_pct}
    ) AS min_pass,
    (
      max_abs_delta <= {numeric_tolerance_abs}
      OR max_abs_delta <= GREATEST(ABS(IFNULL(original_max, 0.0)), 1e-12) * {numeric_tolerance_pct}
    ) AS max_pass,
    (
      avg_abs_delta <= {numeric_tolerance_abs}
      OR avg_abs_delta <= GREATEST(ABS(IFNULL(original_avg, 0.0)), 1e-12) * {numeric_tolerance_pct}
    ) AS avg_pass
  FROM numeric_compare_scored
),
check_rows AS (
  SELECT
    'row_count_equal' AS check_id,
    'Row count equality' AS check_name,
    CASE
      WHEN rc.original_count = rc.optimized_count THEN 'pass'
      ELSE 'fail'
    END AS status,
    CAST(ABS(rc.original_count - rc.optimized_count) AS STRING) AS metric_value,
    TO_JSON_STRING(
      STRUCT(
        rc.original_count AS original_count,
        rc.optimized_count AS optimized_count,
        ABS(rc.original_count - rc.optimized_count) AS delta_count
      )
    ) AS details_json
  FROM row_counts AS rc

  UNION ALL

  SELECT
    'column_set_equal' AS check_id,
    'Inferred column set equality' AS check_name,
    CASE
      WHEN rc.original_count = 0 AND rc.optimized_count = 0 THEN 'warn'
      WHEN ARRAY_LENGTH(kd.only_original) = 0
           AND ARRAY_LENGTH(kd.only_optimized) = 0 THEN 'pass'
      ELSE 'fail'
    END AS status,
    CAST(ARRAY_LENGTH(kd.only_original) + ARRAY_LENGTH(kd.only_optimized) AS STRING) AS metric_value,
    TO_JSON_STRING(
      STRUCT(
        kd.only_original AS only_original,
        kd.only_optimized AS only_optimized,
        kd.shared_keys AS shared_keys,
        CASE
          WHEN rc.original_count = 0 AND rc.optimized_count = 0
            THEN 'Both sides returned zero rows; inferred key set may be incomplete.'
          ELSE NULL
        END AS warning
      )
    ) AS details_json
  FROM key_diffs AS kd
  CROSS JOIN row_counts AS rc

  UNION ALL

  SELECT
    'bag_equivalence' AS check_id,
    'Row bag equivalence (multiplicity-aware)' AS check_name,
    CASE
      WHEN mismatch_count = 0 THEN 'pass'
      ELSE 'fail'
    END AS status,
    CAST(mismatch_count AS STRING) AS metric_value,
    TO_JSON_STRING(
      STRUCT(
        mismatch_count AS mismatched_signatures,
        mismatch_sample AS mismatch_sample
      )
    ) AS details_json
  FROM (
    SELECT
      COUNT(*) AS mismatch_count,
      ARRAY(
        SELECT AS STRUCT row_json, original_count, optimized_count
        FROM bag_diffs
        ORDER BY row_json
        LIMIT {mismatch_sample_limit}
      ) AS mismatch_sample
    FROM bag_diffs
  )

  UNION ALL

  SELECT
    'null_rate_delta' AS check_id,
    'Null-rate delta by inferred key' AS check_name,
    CASE
      WHEN key_count = 0 THEN 'warn'
      WHEN max_null_count_delta = 0
           AND max_rate_delta <= {_DEFAULT_NULL_RATE_TOLERANCE} THEN 'pass'
      ELSE 'fail'
    END AS status,
    CAST(max_null_count_delta AS STRING) AS metric_value,
    TO_JSON_STRING(
        STRUCT(
        key_count AS inferred_key_count,
        max_null_count_delta AS max_null_count_delta,
        max_rate_delta AS max_null_rate_delta,
        top_deltas AS top_deltas,
        {_DEFAULT_NULL_RATE_TOLERANCE} AS tolerance_abs,
        CASE
          WHEN key_count = 0 THEN 'no_inferred_keys'
          WHEN max_null_count_delta = 0
               AND max_rate_delta <= {_DEFAULT_NULL_RATE_TOLERANCE} THEN 'precision_noise_or_equal'
          ELSE 'null_count_mismatch'
        END AS reason_code,
        CASE
          WHEN max_null_count_delta = 0 THEN 'No null-count differences; tiny rate deltas are numeric precision noise.'
          ELSE 'Null-count differences detected for one or more inferred keys.'
        END AS interpretation
      )
    ) AS details_json
  FROM (
    SELECT
      COUNT(*) AS key_count,
      IFNULL(MAX(null_count_delta), 0) AS max_null_count_delta,
      IFNULL(MAX(rate_delta), 0.0) AS max_rate_delta,
      ARRAY(
        SELECT AS STRUCT
          key_name,
          original_null_count,
          optimized_null_count,
          null_count_delta,
          original_null_rate,
          optimized_null_rate,
          rate_delta
        FROM null_rate_diffs
        ORDER BY null_count_delta DESC, rate_delta DESC, key_name
        LIMIT {mismatch_sample_limit}
      ) AS top_deltas
    FROM null_rate_diffs
  )

  UNION ALL

  SELECT
    'numeric_aggregate_delta' AS check_id,
    'Numeric aggregate delta (sum/min/max/avg)' AS check_name,
    CASE
      WHEN numeric_key_count = 0 THEN 'warn'
      WHEN failed_keys = 0 THEN 'pass'
      ELSE 'fail'
    END AS status,
    CAST(max_abs_delta AS STRING) AS metric_value,
    TO_JSON_STRING(
      STRUCT(
        numeric_key_count AS numeric_key_count,
        failed_keys AS failed_keys,
        max_abs_delta AS max_abs_delta,
        tolerance_abs AS tolerance_abs,
        tolerance_pct AS tolerance_pct,
        top_deltas AS top_deltas,
        CASE
          WHEN numeric_key_count = 0 THEN 'no_numeric_keys'
          WHEN failed_keys = 0 THEN 'within_tolerance'
          ELSE 'exceeds_tolerance'
        END AS reason_code,
        CASE
          WHEN failed_keys = 0 THEN 'All numeric aggregates are within tolerance.'
          ELSE 'One or more numeric aggregate deltas exceeded configured tolerance.'
        END AS interpretation
      )
    ) AS details_json
  FROM (
    SELECT
      COUNT(*) AS numeric_key_count,
      COUNTIF(NOT (sum_pass AND min_pass AND max_pass AND avg_pass)) AS failed_keys,
      IFNULL(MAX(GREATEST(sum_abs_delta, min_abs_delta, max_abs_delta, avg_abs_delta)), 0.0) AS max_abs_delta,
      {numeric_tolerance_abs} AS tolerance_abs,
      {numeric_tolerance_pct} AS tolerance_pct,
      ARRAY(
        SELECT AS STRUCT
          key_name,
          original_numeric_count,
          optimized_numeric_count,
          sum_abs_delta,
          min_abs_delta,
          max_abs_delta,
          avg_abs_delta,
          sum_pass,
          min_pass,
          max_pass,
          avg_pass
        FROM numeric_compare_eval
        ORDER BY GREATEST(sum_abs_delta, min_abs_delta, max_abs_delta, avg_abs_delta) DESC, key_name
        LIMIT {mismatch_sample_limit}
      ) AS top_deltas
    FROM numeric_compare_eval
  )
)
SELECT check_id, check_name, status, metric_value, details_json
FROM check_rows
{performance_rows_sql}
ORDER BY check_id
"""
    return sql.strip() + "\n", warnings


def _build_unavailable_reason(
    original_sql: str | None, optimized_sql: str | None
) -> str | None:
    original_missing = not (original_sql and original_sql.strip())
    optimized_missing = not (optimized_sql and optimized_sql.strip())

    if not original_missing and not optimized_missing:
        return None
    if original_missing and optimized_missing:
        return (
            "Verification SQL unavailable because both original and optimized SQL "
            "are missing for this solution version."
        )
    if original_missing:
        return (
            "Verification SQL unavailable because the original SQL baseline is "
            "missing (manifest compiled SQL and latest executed SQL fallback were "
            "both unavailable)."
        )
    return (
        "Verification SQL unavailable because optimized compiled SQL is missing "
        "for this solution version."
    )


def _detect_volatile_warnings(
    original_sql: str, optimized_sql: str
) -> list[VerificationWarning]:
    warnings: list[VerificationWarning] = []
    found: set[str] = set()
    combined = f"{original_sql}\n{optimized_sql}"
    for pattern, label in _VOLATILE_PATTERNS:
        if pattern.search(combined):
            found.add(label)

    if found:
        warnings.append(
            VerificationWarning(
                code="volatile_function_detected",
                message=(
                    "Detected potentially non-deterministic functions: "
                    + ", ".join(sorted(found))
                    + ". Result comparisons may vary between runs."
                ),
            )
        )
    return warnings


def _sanitize_identifier_list(columns: list[str] | None) -> list[str]:
    if not columns:
        return []
    valid: list[str] = []
    seen: set[str] = set()
    for raw in columns:
        value = (raw or "").strip()
        if not value:
            continue
        if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", value):
            continue
        lowered = value.lower()
        if lowered in seen:
            continue
        valid.append(value)
        seen.add(lowered)
    return valid


def _build_primary_key_expr(alias: str, primary_key_columns: list[str]) -> str:
    if not primary_key_columns:
        return f"TO_HEX(SHA256(TO_JSON_STRING({alias})))"
    struct_items = ", ".join(
        f"{alias}.`{column}` AS `{column}`" for column in primary_key_columns
    )
    return f"TO_JSON_STRING(STRUCT({struct_items}))"


def _build_compare_columns_literal(compare_columns: list[str]) -> str:
    if not compare_columns:
        return "ARRAY<STRING>[]"
    quoted = ", ".join(f"'{column}'" for column in compare_columns)
    return f"[{quoted}]"


def _build_audit_sql(
    *,
    header_comment: str,
    original_sql: str,
    optimized_sql: str,
    mismatch_sample_limit: int,
    primary_key_columns: list[str] | None,
    compare_columns: list[str] | None,
    performance_rows_sql: str,
) -> str:
    safe_pk_columns = _sanitize_identifier_list(primary_key_columns)
    safe_compare_columns = _sanitize_identifier_list(compare_columns)
    primary_key_expr_original = _build_primary_key_expr("t", safe_pk_columns)
    primary_key_expr_optimized = _build_primary_key_expr("t", safe_pk_columns)
    compare_columns_array = _build_compare_columns_literal(safe_compare_columns)
    has_explicit_compare_columns = "TRUE" if safe_compare_columns else "FALSE"
    key_strategy = (
        "configured_primary_keys" if safe_pk_columns else "row_fingerprint_fallback"
    )

    return f"""{header_comment}
-- output_mode=audit; key_strategy={key_strategy}
WITH
original_query AS (
{_indent_sql_block(original_sql)}
),
optimized_query AS (
{_indent_sql_block(optimized_sql)}
),
original_rows AS (
  SELECT
    {primary_key_expr_original} AS primary_key_json,
    TO_JSON_STRING(t) AS row_json
  FROM original_query AS t
),
optimized_rows AS (
  SELECT
    {primary_key_expr_optimized} AS primary_key_json,
    TO_JSON_STRING(t) AS row_json
  FROM optimized_query AS t
),
quick_hash_original AS (
  SELECT
    COUNT(*) AS row_count,
    COALESCE(
      SUM(CAST(FARM_FINGERPRINT(row_json) AS BIGNUMERIC)),
      CAST(0 AS BIGNUMERIC)
    ) AS hash_sum,
    COALESCE(BIT_XOR(FARM_FINGERPRINT(row_json)), 0) AS hash_xor
  FROM original_rows
),
quick_hash_optimized AS (
  SELECT
    COUNT(*) AS row_count,
    COALESCE(
      SUM(CAST(FARM_FINGERPRINT(row_json) AS BIGNUMERIC)),
      CAST(0 AS BIGNUMERIC)
    ) AS hash_sum,
    COALESCE(BIT_XOR(FARM_FINGERPRINT(row_json)), 0) AS hash_xor
  FROM optimized_rows
),
quick_identical AS (
  SELECT
    o.row_count AS original_row_count,
    m.row_count AS optimized_row_count,
    o.hash_sum AS original_hash_sum,
    m.hash_sum AS optimized_hash_sum,
    o.hash_xor AS original_hash_xor,
    m.hash_xor AS optimized_hash_xor,
    (
      o.row_count = m.row_count
      AND o.hash_sum = m.hash_sum
      AND o.hash_xor = m.hash_xor
    ) AS are_queries_identical
  FROM quick_hash_original AS o
  CROSS JOIN quick_hash_optimized AS m
),
original_grouped AS (
  SELECT
    primary_key_json,
    COUNT(*) AS row_count_a,
    ARRAY_AGG(row_json ORDER BY row_json) AS rows_a
  FROM original_rows
  GROUP BY primary_key_json
),
optimized_grouped AS (
  SELECT
    primary_key_json,
    COUNT(*) AS row_count_b,
    ARRAY_AGG(row_json ORDER BY row_json) AS rows_b
  FROM optimized_rows
  GROUP BY primary_key_json
),
classification_base AS (
  SELECT
    COALESCE(a.primary_key_json, b.primary_key_json) AS primary_key_json,
    a.row_count_a,
    b.row_count_b,
    a.rows_a,
    b.rows_b,
    a.primary_key_json IS NOT NULL AS present_in_original,
    b.primary_key_json IS NOT NULL AS present_in_optimized,
    CASE
      WHEN a.primary_key_json IS NULL THEN 'added'
      WHEN b.primary_key_json IS NULL THEN 'removed'
      WHEN a.row_count_a = b.row_count_b
           AND TO_JSON_STRING(a.rows_a) = TO_JSON_STRING(b.rows_b) THEN 'identical'
      ELSE 'modified'
    END AS row_status
  FROM original_grouped AS a
  FULL OUTER JOIN optimized_grouped AS b
    ON a.primary_key_json = b.primary_key_json
),
classification_ranked AS (
  SELECT
    *,
    COUNT(*) OVER (PARTITION BY row_status) AS rows_in_status,
    ROW_NUMBER() OVER (
      PARTITION BY row_status
      ORDER BY primary_key_json
    ) AS sample_number
  FROM classification_base
),
classification_samples AS (
  SELECT
    primary_key_json,
    present_in_original,
    present_in_optimized,
    row_status,
    rows_in_status,
    sample_number,
    rows_a[SAFE_OFFSET(0)] AS row_original_json,
    rows_b[SAFE_OFFSET(0)] AS row_optimized_json
  FROM classification_ranked
  WHERE row_status != 'identical'
    AND sample_number <= {mismatch_sample_limit}
),
status_summary AS (
  SELECT
    row_status AS status,
    COUNT(*) AS status_count,
    SAFE_DIVIDE(COUNT(*), SUM(COUNT(*)) OVER()) AS percent_of_total
  FROM classification_base
  GROUP BY row_status
),
all_inferred_columns AS (
  SELECT DISTINCT column_name
  FROM (
    SELECT key AS column_name
    FROM original_rows AS r
    CROSS JOIN UNNEST(
      JSON_KEYS(PARSE_JSON(r.row_json, wide_number_mode => 'round'))
    ) AS key
    UNION DISTINCT
    SELECT key AS column_name
    FROM optimized_rows AS r
    CROSS JOIN UNNEST(
      JSON_KEYS(PARSE_JSON(r.row_json, wide_number_mode => 'round'))
    ) AS key
  )
),
columns_to_compare AS (
  SELECT column_name
  FROM UNNEST({compare_columns_array}) AS column_name
  WHERE {has_explicit_compare_columns}
  UNION DISTINCT
  SELECT column_name
  FROM all_inferred_columns
  WHERE NOT {has_explicit_compare_columns}
),
shared_key_rows AS (
  SELECT
    primary_key_json,
    rows_a[SAFE_OFFSET(0)] AS row_original_json,
    rows_b[SAFE_OFFSET(0)] AS row_optimized_json
  FROM classification_base
  WHERE present_in_original AND present_in_optimized
),
column_diffs AS (
  SELECT
    c.column_name,
    COUNT(*) AS compared_keys,
    COUNTIF(
      REGEXP_EXTRACT(
        s.row_original_json,
        FORMAT(
          r'"%s"\\s*:\\s*(null|true|false|-?(?:\\d+\\.?\\d*|\\.\\d+)(?:[eE][+-]?\\d+)?|"(?:[^"\\\\]|\\\\.)*")',
          REGEXP_REPLACE(
            c.column_name,
            r'([\\\\.\\^\\$\\*\\+\\?\\(\\)\\[\\]\\{{\\}}\\|\\-])',
            r'\\\\\\1'
          )
        )
      ) IS DISTINCT FROM REGEXP_EXTRACT(
        s.row_optimized_json,
        FORMAT(
          r'"%s"\\s*:\\s*(null|true|false|-?(?:\\d+\\.?\\d*|\\.\\d+)(?:[eE][+-]?\\d+)?|"(?:[^"\\\\]|\\\\.)*")',
          REGEXP_REPLACE(
            c.column_name,
            r'([\\\\.\\^\\$\\*\\+\\?\\(\\)\\[\\]\\{{\\}}\\|\\-])',
            r'\\\\\\1'
          )
        )
      )
    ) AS difference_count
  FROM columns_to_compare AS c
  CROSS JOIN shared_key_rows AS s
  GROUP BY c.column_name
),
status_counts AS (
  SELECT
    IFNULL(SUM(CASE WHEN status = 'identical' THEN status_count ELSE 0 END), 0) AS identical_count,
    IFNULL(SUM(CASE WHEN status = 'added' THEN status_count ELSE 0 END), 0) AS added_count,
    IFNULL(SUM(CASE WHEN status = 'removed' THEN status_count ELSE 0 END), 0) AS removed_count,
    IFNULL(SUM(CASE WHEN status = 'modified' THEN status_count ELSE 0 END), 0) AS modified_count
  FROM status_summary
),
column_diff_summary AS (
  SELECT
    IFNULL(MAX(compared_keys), 0) AS compared_keys,
    COUNTIF(difference_count > 0) AS changed_columns
  FROM column_diffs
),
overall_verdict AS (
  SELECT
    q.original_row_count,
    q.optimized_row_count,
    CASE
      WHEN sc.added_count = 0
           AND sc.removed_count = 0
           AND sc.modified_count = 0
           AND cds.changed_columns = 0
           AND q.are_queries_identical THEN 'pass'
      ELSE 'fail'
    END AS status,
    CASE
      WHEN q.original_row_count = 0 AND q.optimized_row_count = 0 THEN 'both_queries_empty'
      WHEN sc.added_count > 0 OR sc.removed_count > 0 THEN 'row_presence_mismatch'
      WHEN sc.modified_count > 0 THEN 'row_value_mismatch'
      WHEN cds.changed_columns > 0 THEN 'column_diff_detected'
      WHEN NOT q.are_queries_identical THEN 'quick_hash_mismatch'
      ELSE 'equivalent'
    END AS reason_code,
    CASE
      WHEN sc.added_count > 0 OR sc.removed_count > 0 THEN FORMAT(
        'Found row-presence mismatch: %d key(s) only in optimized output and %d key(s) only in original output. Inspect result_type=classification rows.',
        sc.added_count,
        sc.removed_count
      )
      WHEN sc.modified_count > 0 THEN FORMAT(
        'Found value mismatch on %d shared key(s). Inspect result_type=classification and result_type=column_diff rows.',
        sc.modified_count
      )
      WHEN cds.changed_columns > 0 THEN FORMAT(
        'Found %d changed column(s) across shared keys. Inspect result_type=column_diff rows.',
        cds.changed_columns
      )
      WHEN q.original_row_count = 0 AND q.optimized_row_count = 0 THEN 'Both queries returned zero rows. This is considered equivalent.'
      WHEN NOT q.are_queries_identical THEN 'Quick hash mismatch detected. Re-run with explicit primary_key_columns to improve diagnostics.'
      ELSE 'All checks passed: row counts, row content, and compared columns are equivalent.'
    END AS summary_message,
    sc.identical_count,
    sc.added_count,
    sc.removed_count,
    sc.modified_count,
    cds.compared_keys,
    cds.changed_columns,
    q.are_queries_identical
  FROM status_counts AS sc
  CROSS JOIN column_diff_summary AS cds
  CROSS JOIN quick_identical AS q
)
SELECT
  'summary' AS result_type,
  'overall_verdict' AS check_id,
  'Overall equivalence verdict' AS check_name,
  ov.status AS status,
  ov.summary_message AS status_explanation,
  ov.status AS metric_value,
  TO_JSON_STRING(
    STRUCT(
      ov.identical_count AS identical_count,
      ov.added_count AS added_count,
      ov.removed_count AS removed_count,
      ov.modified_count AS modified_count,
      ov.original_row_count AS original_row_count,
      ov.optimized_row_count AS optimized_row_count,
      ov.compared_keys AS compared_keys,
      ov.changed_columns AS changed_columns,
      ov.are_queries_identical AS quick_hash_match,
      ov.reason_code AS reason_code,
      ov.summary_message AS summary_message,
      '{key_strategy}' AS key_strategy
    )
  ) AS details_json
FROM overall_verdict AS ov

UNION ALL

SELECT
  'summary' AS result_type,
  'quick_are_queries_identical' AS check_id,
  'Quick identical hash check' AS check_name,
  CASE WHEN q.are_queries_identical THEN 'pass' ELSE 'fail' END AS status,
  CASE
    WHEN q.are_queries_identical THEN 'Quick hash signatures match.'
    ELSE 'Quick hash signatures differ; inspect detailed checks.'
  END AS status_explanation,
  CAST(q.are_queries_identical AS STRING) AS metric_value,
  TO_JSON_STRING(
    STRUCT(
      q.original_row_count AS original_row_count,
      q.optimized_row_count AS optimized_row_count,
      q.original_hash_sum AS original_hash_sum,
      q.optimized_hash_sum AS optimized_hash_sum,
      q.original_hash_xor AS original_hash_xor,
      q.optimized_hash_xor AS optimized_hash_xor,
      CASE
        WHEN q.are_queries_identical THEN 'quick_hash_match'
        ELSE 'quick_hash_mismatch'
      END AS reason_code,
      '{key_strategy}' AS key_strategy
    )
  ) AS details_json
FROM quick_identical AS q

UNION ALL

SELECT
  'summary' AS result_type,
  'key_metrics' AS check_id,
  'Key comparison metrics' AS check_name,
  ov.status AS status,
  CASE
    WHEN ov.original_row_count = 0 AND ov.optimized_row_count = 0 THEN 'No rows produced by either query.'
    WHEN ov.added_count > 0 OR ov.removed_count > 0 OR ov.modified_count > 0 THEN 'Key-level mismatches detected.'
    ELSE 'All classified keys are identical.'
  END AS status_explanation,
  CAST(ov.identical_count AS STRING) AS metric_value,
  TO_JSON_STRING(
    STRUCT(
      ov.identical_count AS identical_count,
      ov.added_count AS added_count,
      ov.removed_count AS removed_count,
      ov.modified_count AS modified_count,
      (ov.identical_count + ov.added_count + ov.removed_count + ov.modified_count) AS total_classified_keys,
      SAFE_DIVIDE(
        ov.identical_count,
        NULLIF(
          ov.identical_count + ov.added_count + ov.removed_count + ov.modified_count,
          0
        )
      ) AS identical_ratio
    )
  ) AS details_json
FROM overall_verdict AS ov

UNION ALL

SELECT
  'summary' AS result_type,
  'column_diff_summary' AS check_id,
  'Column difference summary' AS check_name,
  CASE
    WHEN cds.compared_keys = 0
         AND ov.original_row_count = 0
         AND ov.optimized_row_count = 0 THEN 'pass'
    WHEN cds.compared_keys = 0 THEN 'warn'
    WHEN cds.changed_columns = 0 THEN 'pass'
    ELSE 'fail'
  END AS status,
  CASE
    WHEN cds.compared_keys = 0
         AND ov.original_row_count = 0
         AND ov.optimized_row_count = 0 THEN 'No shared keys because both queries returned zero rows.'
    WHEN cds.compared_keys = 0 THEN 'No shared keys; column-level diff could not run.'
    WHEN cds.changed_columns = 0 THEN 'No column-level differences found across shared keys.'
    ELSE FORMAT('Detected %d changed column(s).', cds.changed_columns)
  END AS status_explanation,
  CAST(cds.changed_columns AS STRING) AS metric_value,
  TO_JSON_STRING(
    STRUCT(
      cds.compared_keys AS compared_keys,
      cds.changed_columns AS changed_columns,
      CASE
        WHEN cds.compared_keys = 0 THEN 'no_shared_keys'
        WHEN cds.changed_columns = 0 THEN 'column_equal'
        ELSE 'column_diff_detected'
      END AS reason_code,
      '{key_strategy}' AS key_strategy
    )
  ) AS details_json
FROM column_diff_summary AS cds
CROSS JOIN overall_verdict AS ov

UNION ALL

SELECT
  'classification' AS result_type,
  'compare_and_classify_query_results' AS check_id,
  'Row classification sample' AS check_name,
  CASE
    WHEN row_status = 'identical' THEN 'pass'
    WHEN row_status = 'modified' THEN 'fail'
    ELSE 'warn'
  END AS status,
  CASE
    WHEN row_status = 'modified' THEN FORMAT(
      'Value mismatch for key sample #%d.',
      sample_number
    )
    WHEN row_status = 'added' THEN FORMAT(
      'Key exists only in optimized output (sample #%d).',
      sample_number
    )
    WHEN row_status = 'removed' THEN FORMAT(
      'Key exists only in original output (sample #%d).',
      sample_number
    )
    ELSE FORMAT('Identical row sample #%d.', sample_number)
  END AS status_explanation,
  row_status AS metric_value,
  TO_JSON_STRING(
    STRUCT(
      row_status AS row_status,
      CASE
        WHEN row_status = 'identical' THEN 'row_identical'
        WHEN row_status = 'modified' THEN 'row_modified'
        WHEN row_status = 'added' THEN 'row_added'
        ELSE 'row_removed'
      END AS reason_code,
      primary_key_json AS primary_key_json,
      present_in_original AS present_in_original,
      present_in_optimized AS present_in_optimized,
      rows_in_status AS rows_in_status,
      sample_number AS sample_number,
      row_original_json AS row_original_json,
      row_optimized_json AS row_optimized_json
    )
  ) AS details_json
FROM classification_samples

UNION ALL

SELECT
  'column_diff' AS result_type,
  'compare_which_query_columns_differ' AS check_id,
  'Column difference matrix' AS check_name,
  CASE
    WHEN compared_keys = 0 THEN 'warn'
    WHEN difference_count = 0 THEN 'pass'
    ELSE 'fail'
  END AS status,
  CASE
    WHEN compared_keys = 0 THEN FORMAT(
      'Column `%s`: no shared keys to compare.',
      column_name
    )
    WHEN difference_count = 0 THEN FORMAT(
      'Column `%s`: no differences.',
      column_name
    )
    ELSE FORMAT(
      'Column `%s`: %d differing shared key(s).',
      column_name,
      difference_count
    )
  END AS status_explanation,
  CAST(difference_count AS STRING) AS metric_value,
  TO_JSON_STRING(
    STRUCT(
      CASE
        WHEN compared_keys = 0 THEN 'no_shared_keys'
        WHEN difference_count = 0 THEN 'column_equal'
        ELSE 'column_diff_detected'
      END AS reason_code,
      column_name AS column_name,
      compared_keys AS compared_keys,
      difference_count AS difference_count,
      '{key_strategy}' AS key_strategy
    )
  ) AS details_json
FROM column_diffs
WHERE difference_count > 0
{performance_rows_sql}
ORDER BY result_type, check_id, status
"""


def _build_header_comment(
    *,
    profile: VerificationCheckProfile,
    output_mode: VerificationOutputMode,
    numeric_tolerance_abs: float,
    numeric_tolerance_pct: float,
    mismatch_sample_limit: int,
    original_dry_run: VerificationPerformanceSnapshot | None,
    optimized_dry_run: VerificationPerformanceSnapshot | None,
) -> str:
    checks = ", ".join(profile.enabled_checks)
    lines = [
        "-- Governor verification SQL (manual execution)",
        "-- Purpose: compare original vs optimized query outputs.",
        "-- This script is read-only and intended for BigQuery Standard SQL.",
        "-- NOTE: costs depend on scanned data volume; use LIMIT/sample wrappers",
        "--       in original_query / optimized_query for low-cost exploratory checks.",
        f"-- output_mode={output_mode}",
        f"-- profile={profile.profile_id}; checks={checks}",
        f"-- numeric_tolerance_abs={numeric_tolerance_abs}; numeric_tolerance_pct={numeric_tolerance_pct}",
        f"-- mismatch_sample_limit={mismatch_sample_limit}",
    ]
    lines.extend(
        _build_performance_comment_lines(
            original_dry_run=original_dry_run,
            optimized_dry_run=optimized_dry_run,
        )
    )
    return "\n".join(lines)


def _indent_sql_block(sql: str) -> str:
    return indent(sql.strip(), "  ")


def _normalize_dry_run_snapshot(
    payload: object | None,
) -> VerificationPerformanceSnapshot | None:
    if payload is None:
        return None

    if isinstance(payload, dict):
        valid = bool(payload.get("valid"))
        bytes_processed = payload.get("total_bytes_processed")
        estimated_cost = payload.get("estimated_cost_usd")
        error = payload.get("error")
    else:
        valid = bool(getattr(payload, "valid", False))
        bytes_processed = getattr(payload, "total_bytes_processed", None)
        estimated_cost = getattr(payload, "estimated_cost_usd", None)
        error = getattr(payload, "error", None)

    raw_cost = float(estimated_cost) if estimated_cost is not None else None
    cost_display_multiplier = get_cost_multiplier()

    return VerificationPerformanceSnapshot(
        valid=valid,
        total_bytes_processed=(
            int(bytes_processed) if bytes_processed is not None else None
        ),
        estimated_cost_usd_raw=raw_cost,
        estimated_cost_usd_display=(
            apply_cost_multiplier(raw_cost) if raw_cost is not None else None
        ),
        cost_display_multiplier=cost_display_multiplier,
        error=str(error) if error else None,
    )


def _build_performance_comment_lines(
    *,
    original_dry_run: VerificationPerformanceSnapshot | None,
    optimized_dry_run: VerificationPerformanceSnapshot | None,
) -> list[str]:
    if original_dry_run is None and optimized_dry_run is None:
        return []

    multiplier = (
        original_dry_run.cost_display_multiplier
        if original_dry_run is not None
        else optimized_dry_run.cost_display_multiplier
        if optimized_dry_run is not None
        else 1.0
    )
    lines = [
        "-- performance_source=cached_bigquery_dry_run",
        f"-- cost_display_multiplier={multiplier:.6f}",
    ]
    lines.extend(
        [
            _format_performance_comment_line("original", original_dry_run),
            _format_performance_comment_line("optimized", optimized_dry_run),
        ]
    )

    if (
        original_dry_run is not None
        and optimized_dry_run is not None
        and original_dry_run.valid
        and optimized_dry_run.valid
        and original_dry_run.estimated_cost_usd_raw is not None
        and optimized_dry_run.estimated_cost_usd_raw is not None
        and original_dry_run.estimated_cost_usd_display is not None
        and optimized_dry_run.estimated_cost_usd_display is not None
    ):
        raw_cost_delta = (
            optimized_dry_run.estimated_cost_usd_raw
            - original_dry_run.estimated_cost_usd_raw
        )
        display_cost_delta = (
            optimized_dry_run.estimated_cost_usd_display
            - original_dry_run.estimated_cost_usd_display
        )
        lines.append(
            f"-- dry_run_cost_delta_usd_display={display_cost_delta:.6f}; "
            f"dry_run_cost_delta_usd_raw={raw_cost_delta:.6f}"
        )

    return lines


def _format_performance_comment_line(
    label: str, snapshot: VerificationPerformanceSnapshot | None
) -> str:
    if snapshot is None:
        return f"-- {label}_dry_run=unavailable"
    if not snapshot.valid:
        return f"-- {label}_dry_run=invalid" + (
            f"; error={_sanitize_sql_comment_value(snapshot.error)}"
            if snapshot.error
            else ""
        )
    return (
        f"-- {label}_dry_run=valid"
        f"; bytes_processed={snapshot.total_bytes_processed or 0}"
        f"; estimated_cost_usd_display="
        f"{(snapshot.estimated_cost_usd_display or 0.0):.6f}"
        f"; estimated_cost_usd_raw="
        f"{(snapshot.estimated_cost_usd_raw or 0.0):.6f}"
    )


def _build_performance_rows_sql(
    *,
    original_dry_run: VerificationPerformanceSnapshot | None,
    optimized_dry_run: VerificationPerformanceSnapshot | None,
    include_result_type: bool,
) -> str:
    if original_dry_run is None and optimized_dry_run is None:
        return ""

    rows = [
        _build_single_performance_row_sql(
            result_type="performance" if include_result_type else None,
            check_id="original_dry_run_estimate",
            check_name="Original dry-run estimate",
            status=_performance_status(original_dry_run),
            status_explanation=_performance_explanation("original", original_dry_run),
            metric_value=(
                f"{(original_dry_run.estimated_cost_usd_display or 0.0):.6f}"
                if original_dry_run and original_dry_run.valid
                else "unavailable"
            ),
            details_json_sql=_build_single_performance_details_sql(
                label="original",
                snapshot=original_dry_run,
            ),
        ),
        _build_single_performance_row_sql(
            result_type="performance" if include_result_type else None,
            check_id="optimized_dry_run_estimate",
            check_name="Optimized dry-run estimate",
            status=_performance_status(optimized_dry_run),
            status_explanation=_performance_explanation("optimized", optimized_dry_run),
            metric_value=(
                f"{(optimized_dry_run.estimated_cost_usd_display or 0.0):.6f}"
                if optimized_dry_run and optimized_dry_run.valid
                else "unavailable"
            ),
            details_json_sql=_build_single_performance_details_sql(
                label="optimized",
                snapshot=optimized_dry_run,
            ),
        ),
    ]

    delta_snapshot = _build_performance_delta_snapshot(
        original_dry_run=original_dry_run,
        optimized_dry_run=optimized_dry_run,
    )
    rows.append(
        _build_single_performance_row_sql(
            result_type="performance" if include_result_type else None,
            check_id="dry_run_cost_comparison",
            check_name="Dry-run cost comparison",
            status=delta_snapshot["status"],
            status_explanation=delta_snapshot["status_explanation"],
            metric_value=delta_snapshot["metric_value"],
            details_json_sql=delta_snapshot["details_json_sql"],
        )
    )
    return "\n\nUNION ALL\n\n" + "\n\nUNION ALL\n\n".join(rows)


def _build_single_performance_row_sql(
    *,
    result_type: str | None,
    check_id: str,
    check_name: str,
    status: str,
    status_explanation: str,
    metric_value: str,
    details_json_sql: str,
) -> str:
    if result_type is None:
        return f"""SELECT
  '{check_id}' AS check_id,
  '{check_name}' AS check_name,
  '{status}' AS status,
  '{metric_value}' AS metric_value,
  {details_json_sql} AS details_json"""

    return f"""SELECT
  '{result_type}' AS result_type,
  '{check_id}' AS check_id,
  '{check_name}' AS check_name,
  '{status}' AS status,
  '{status_explanation}' AS status_explanation,
  '{metric_value}' AS metric_value,
  {details_json_sql} AS details_json"""


def _build_single_performance_details_sql(
    *,
    label: str,
    snapshot: VerificationPerformanceSnapshot | None,
) -> str:
    if snapshot is None:
        return """TO_JSON_STRING(
    STRUCT(
      'cached_bigquery_dry_run' AS source,
      'missing' AS availability,
      FALSE AS valid,
      CAST(NULL AS INT64) AS total_bytes_processed,
      CAST(NULL AS FLOAT64) AS estimated_cost_usd,
      CAST(NULL AS STRING) AS error,
      'dry_run_not_available' AS reason_code,
      'No cached dry-run estimate was available.' AS summary_message
    )
  )"""

    if not snapshot.valid:
        return f"""TO_JSON_STRING(
    STRUCT(
      'cached_bigquery_dry_run' AS source,
      'available' AS availability,
      FALSE AS valid,
      CAST(NULL AS INT64) AS total_bytes_processed,
      CAST(NULL AS FLOAT64) AS estimated_cost_usd_display,
      CAST(NULL AS FLOAT64) AS estimated_cost_usd_raw,
      CAST(NULL AS FLOAT64) AS cost_display_multiplier,
      {_sql_string_literal(snapshot.error)} AS error,
      'dry_run_invalid' AS reason_code,
      {
            _sql_string_literal(
                f"The {label} dry-run validation failed; no performance estimate is available."
            )
        } AS summary_message
    )
  )"""

    return f"""TO_JSON_STRING(
    STRUCT(
      'cached_bigquery_dry_run' AS source,
      'available' AS availability,
      TRUE AS valid,
      {snapshot.total_bytes_processed or 0} AS total_bytes_processed,
      {
        _sql_float_literal(snapshot.estimated_cost_usd_display)
    } AS estimated_cost_usd_display,
      {_sql_float_literal(snapshot.estimated_cost_usd_raw)} AS estimated_cost_usd_raw,
      {_sql_float_literal(snapshot.cost_display_multiplier)} AS cost_display_multiplier,
      CAST(NULL AS STRING) AS error,
      'dry_run_valid' AS reason_code,
      {
        _sql_string_literal(f"Cached dry-run estimate for the {label} query.")
    } AS summary_message
    )
  )"""


def _build_performance_delta_snapshot(
    *,
    original_dry_run: VerificationPerformanceSnapshot | None,
    optimized_dry_run: VerificationPerformanceSnapshot | None,
) -> dict[str, str]:
    if (
        original_dry_run is None
        or optimized_dry_run is None
        or not original_dry_run.valid
        or not optimized_dry_run.valid
        or original_dry_run.estimated_cost_usd_raw is None
        or optimized_dry_run.estimated_cost_usd_raw is None
        or original_dry_run.estimated_cost_usd_display is None
        or optimized_dry_run.estimated_cost_usd_display is None
    ):
        return {
            "status": "warn",
            "status_explanation": (
                "Dry-run cost delta is unavailable because one or both dry runs are "
                "missing or invalid."
            ),
            "metric_value": "unavailable",
            "details_json_sql": """TO_JSON_STRING(
    STRUCT(
      'cached_bigquery_dry_run' AS source,
      FALSE AS comparable,
      CAST(NULL AS FLOAT64) AS original_estimated_cost_usd_display,
      CAST(NULL AS FLOAT64) AS optimized_estimated_cost_usd_display,
      CAST(NULL AS FLOAT64) AS cost_delta_usd_display,
      CAST(NULL AS FLOAT64) AS original_estimated_cost_usd_raw,
      CAST(NULL AS FLOAT64) AS optimized_estimated_cost_usd_raw,
      CAST(NULL AS FLOAT64) AS cost_delta_usd_raw,
      CAST(NULL AS FLOAT64) AS cost_display_multiplier,
      CAST(NULL AS FLOAT64) AS bytes_delta_pct,
      'comparison_unavailable' AS reason_code,
      'Dry-run comparison unavailable because one or both dry-run estimates are missing or invalid.' AS summary_message
    )
  )""",
        }

    raw_cost_delta = (
        optimized_dry_run.estimated_cost_usd_raw
        - original_dry_run.estimated_cost_usd_raw
    )
    display_cost_delta = (
        optimized_dry_run.estimated_cost_usd_display
        - original_dry_run.estimated_cost_usd_display
    )
    original_bytes = original_dry_run.total_bytes_processed or 0
    optimized_bytes = optimized_dry_run.total_bytes_processed or 0
    bytes_delta = optimized_bytes - original_bytes
    bytes_delta_pct = (bytes_delta / original_bytes * 100) if original_bytes else 0.0

    if display_cost_delta < 0:
        status = "pass"
        explanation = "Optimized query is cheaper than the original query in cached dry-run estimates."
        reason_code = "cost_reduction"
        metric_value = f"{abs(display_cost_delta):.6f}"
        summary_message = "Optimized query reduces estimated dry-run cost."
    elif display_cost_delta > 0:
        status = "warn"
        explanation = "Optimized query is more expensive than the original query in cached dry-run estimates."
        reason_code = "cost_increase"
        metric_value = f"{display_cost_delta:.6f}"
        summary_message = "Optimized query increases estimated dry-run cost."
    else:
        status = "pass"
        explanation = (
            "Original and optimized queries have the same cached dry-run cost estimate."
        )
        reason_code = "cost_unchanged"
        metric_value = "0.000000"
        summary_message = (
            "Original and optimized queries have the same estimated dry-run cost."
        )

    details_json_sql = f"""TO_JSON_STRING(
    STRUCT(
      'cached_bigquery_dry_run' AS source,
      TRUE AS comparable,
      {_sql_float_literal(original_dry_run.estimated_cost_usd_display)} AS original_estimated_cost_usd_display,
      {_sql_float_literal(optimized_dry_run.estimated_cost_usd_display)} AS optimized_estimated_cost_usd_display,
      {display_cost_delta:.6f} AS cost_delta_usd_display,
      {_sql_float_literal(original_dry_run.estimated_cost_usd_raw)} AS original_estimated_cost_usd_raw,
      {_sql_float_literal(optimized_dry_run.estimated_cost_usd_raw)} AS optimized_estimated_cost_usd_raw,
      {raw_cost_delta:.6f} AS cost_delta_usd_raw,
      {_sql_float_literal(original_dry_run.cost_display_multiplier)} AS cost_display_multiplier,
      {original_bytes} AS original_total_bytes_processed,
      {optimized_bytes} AS optimized_total_bytes_processed,
      {bytes_delta} AS bytes_delta,
      {bytes_delta_pct:.6f} AS bytes_delta_pct,
      '{reason_code}' AS reason_code,
      {_sql_string_literal(summary_message)} AS summary_message
    )
  )"""
    return {
        "status": status,
        "status_explanation": explanation,
        "metric_value": metric_value,
        "details_json_sql": details_json_sql,
    }


def _performance_status(snapshot: VerificationPerformanceSnapshot | None) -> str:
    if snapshot is None:
        return "warn"
    if not snapshot.valid:
        return "warn"
    return "pass"


def _performance_explanation(
    label: str, snapshot: VerificationPerformanceSnapshot | None
) -> str:
    if snapshot is None:
        return f"No cached dry-run estimate was available for the {label} query."
    if not snapshot.valid:
        return f"The {label} dry-run validation failed; no performance estimate is available."
    return f"Cached BigQuery dry-run estimate for the {label} query."


def _sql_string_literal(value: str | None) -> str:
    if value is None:
        return "CAST(NULL AS STRING)"
    escaped = value.replace("\\", "\\\\").replace("'", "\\'")
    return f"'{escaped}'"


def _sql_float_literal(value: float | None) -> str:
    if value is None:
        return "CAST(NULL AS FLOAT64)"
    return f"{float(value):.6f}"


def _sanitize_sql_comment_value(value: str | None) -> str:
    if not value:
        return ""
    normalized = re.sub(r"\s+", " ", value).strip()
    return normalized[:200]
