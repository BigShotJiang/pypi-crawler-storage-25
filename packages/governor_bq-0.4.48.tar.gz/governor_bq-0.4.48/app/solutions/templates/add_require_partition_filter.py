"""Template: add require_partition_filter config to a dbt model."""

from __future__ import annotations

import logging
from typing import Any

from app.solutions.templates.base import BaseTemplate, TemplateResult
from app.solutions.templates.config_parser import (
    get_config_property,
    has_config_property,
    insert_config_property,
)

logger = logging.getLogger("app.solutions.templates.add_require_partition_filter")


class AddRequirePartitionFilterTemplate(BaseTemplate):
    """Adds require_partition_filter=true to a dbt model config block.

    Applicable to partition_pruning opportunities where the table is
    already partitioned but lacks the partition filter requirement.
    """

    template_id = "add_require_partition_filter"
    applicable_types = {"partition_pruning"}
    required_params = []

    def matches(
        self,
        opportunity,
        source_files: dict[str, str],
        manifest_metadata: dict[str, Any] | None,
    ) -> bool:
        if opportunity.opportunity_type not in self.applicable_types:
            return False

        if not source_files:
            return False

        model_path = self._find_model_path(source_files, manifest_metadata)
        if not model_path:
            return False

        content = source_files.get(model_path, "")

        # Only applies if partition_by is already configured
        if not has_config_property(content, "partition_by"):
            return False

        # Check if require_partition_filter already set
        if has_config_property(content, "require_partition_filter"):
            existing = get_config_property(content, "require_partition_filter")
            if existing and existing.strip().lower() in ("true", "True"):
                return False  # Already enabled
            # Existing but set to false — skip, let LLM handle
            logger.info(
                "require_partition_filter explicitly set to false in %s, skipping template",
                model_path,
            )
            return False

        return True

    def apply(
        self,
        opportunity,
        source_files: dict[str, str],
        manifest_metadata: dict[str, Any] | None,
    ) -> TemplateResult | None:
        model_path = self._find_model_path(source_files, manifest_metadata)
        if not model_path or model_path not in source_files:
            return None

        before_content = source_files[model_path]

        after_content = insert_config_property(
            before_content, "require_partition_filter", "true"
        )
        if after_content is None:
            return None

        return TemplateResult(
            template_id=self.template_id,
            file_path=model_path,
            before_content=before_content,
            after_content=after_content,
            change_type="project_config_change",
            explanation=(
                "Added require_partition_filter=true to enforce partition "
                "pruning on all queries against this table. This prevents "
                "accidental full-table scans by requiring a partition filter "
                "in every query."
            ),
            policy_tags=["dbt_config_change"],
            parameters={},
            rollback=self.rollback_instructions(),
        )

    def rollback_instructions(self) -> str:
        return (
            "Remove the require_partition_filter property from the model's "
            "config block, or set it to false."
        )

    def _find_model_path(
        self,
        source_files: dict[str, str],
        manifest_metadata: dict[str, Any] | None,
    ) -> str | None:
        """Find the SQL model file path from source files."""
        if manifest_metadata:
            original_path = manifest_metadata.get("original_file_path")
            if original_path and original_path in source_files:
                return original_path

        for path in source_files:
            if path.endswith(".sql") and not path.endswith("dbt_project.yml"):
                return path

        return None
