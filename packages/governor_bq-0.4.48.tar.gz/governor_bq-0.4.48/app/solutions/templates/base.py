"""Base template class and result types for safe change templates."""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any


@dataclass
class TemplateResult:
    """Result of applying a safe change template."""

    template_id: str
    file_path: str
    before_content: str
    after_content: str
    change_type: str  # e.g. "project_config_change"
    explanation: str
    policy_tags: list[str] = field(default_factory=list)
    parameters: dict[str, Any] = field(default_factory=dict)
    rollback: str = ""


class BaseTemplate(ABC):
    """Abstract base class for safe change templates.

    Each template maps a specific opportunity type to a deterministic
    code change pattern. Templates are tried in registry order; the first
    match wins.
    """

    template_id: str = ""
    applicable_types: set[str] = set()
    required_params: list[str] = []

    @abstractmethod
    def matches(
        self,
        opportunity,
        source_files: dict[str, str],
        manifest_metadata: dict[str, Any] | None,
    ) -> bool:
        """Check if this template can handle this opportunity.

        Args:
            opportunity: Opportunity ORM model.
            source_files: Dict mapping file path to content.
            manifest_metadata: Parsed manifest node data.

        Returns:
            True if this template applies to the opportunity.
        """

    @abstractmethod
    def apply(
        self,
        opportunity,
        source_files: dict[str, str],
        manifest_metadata: dict[str, Any] | None,
    ) -> TemplateResult | None:
        """Apply the template and return before/after content.

        Returns TemplateResult or None if application fails (e.g. parameter
        extraction error). Returning None signals the caller to fall back
        to LLM generation.
        """

    @abstractmethod
    def rollback_instructions(self) -> str:
        """Human-readable rollback steps."""
