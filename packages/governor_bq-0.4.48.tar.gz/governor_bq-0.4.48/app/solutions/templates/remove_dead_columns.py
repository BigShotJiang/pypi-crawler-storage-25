"""Deterministic solution template for dead_column opportunities.

Removes unused columns from CTE SELECT clauses within a dbt model by:
  1. Locating each affected CTE by name using balanced-paren matching.
  2. Finding the line containing the dead column (as alias or bare name).
  3. Removing just that line and adjusting trailing commas if needed.

All other formatting, Jinja refs, and surrounding SQL are left byte-for-byte
identical. No sqlglot regeneration — only surgical line removal.

No LLM invocation needed — the exact columns to remove per CTE are already
known from the evidence_snapshot produced by the dead_column detection rule.
"""

from __future__ import annotations

import logging
import re
from typing import Any

from app.solutions.templates.base import BaseTemplate, TemplateResult

logger = logging.getLogger("app.solutions.templates.remove_dead_columns")


def _find_cte_boundaries(sql: str, cte_name: str) -> tuple[int, int] | None:
    """Find the start/end of a CTE's body (between its outer parentheses).

    Returns (body_start, body_end) where sql[body_start:body_end] is the CTE
    body text (exclusive of the surrounding parens).
    Returns None if the CTE definition cannot be found.
    """
    pattern = re.compile(
        r"\b" + re.escape(cte_name) + r"\s+as\s*\(",
        re.IGNORECASE,
    )
    m = pattern.search(sql)
    if not m:
        return None

    open_pos = m.end() - 1  # index of the opening '('
    depth = 0
    for i in range(open_pos, len(sql)):
        c = sql[i]
        if c == "(":
            depth += 1
        elif c == ")":
            depth -= 1
            if depth == 0:
                return open_pos + 1, i

    return None  # unmatched parenthesis


def _remove_dead_col_line(cte_body: str, col_name: str) -> str | None:
    """Remove the line that selects a dead column from a CTE body.

    Matches lines where col_name appears as:
    - An alias:             ``expr AS col_name [,]``
    - A bare column:        ``col_name [,]``
    - A qualified column:   ``table.col_name [,]``

    Adjusts the trailing comma on the preceding non-blank line if the removed
    line was the last SELECT expression (had no trailing comma of its own).

    Returns the modified cte_body, or None if the column line was not found.
    """
    # Pattern 1: col_name used as alias  →  ... AS col_name [,]
    alias_re = re.compile(
        r"^(.*)\bas\s+" + re.escape(col_name) + r"(\s*,?\s*)$",
        re.IGNORECASE,
    )
    # Pattern 2: bare or table-qualified column  →  [table.]col_name [,]
    bare_re = re.compile(
        r"^\s+(?:[\w]+\.)?" + re.escape(col_name) + r"\s*,?\s*$",
        re.IGNORECASE,
    )

    lines = cte_body.splitlines(keepends=True)
    dead_idx: int | None = None

    for i, line in enumerate(lines):
        content = line.rstrip("\n\r")
        m = alias_re.match(content)
        if m:
            # Safety: if prefix has unmatched open parens the expression started
            # on a previous line (e.g. CASE ... END AS col) — skip.
            prefix = m.group(1)
            if prefix.count("(") != prefix.count(")"):
                logger.debug(
                    "Dead column %s appears to be part of a multi-line expression — skipping",
                    col_name,
                )
                return None
            dead_idx = i
            break
        if bare_re.match(content):
            dead_idx = i
            break

    if dead_idx is None:
        logger.debug("Could not find line for dead column %s", col_name)
        return None

    dead_content = lines[dead_idx].rstrip("\n\r").rstrip()
    had_trailing_comma = dead_content.endswith(",")

    new_lines = [line for i, line in enumerate(lines) if i != dead_idx]

    # If the removed column was the last one (no trailing comma), remove the
    # trailing comma from the previous non-blank line so the SELECT remains valid.
    if not had_trailing_comma:
        for i in range(dead_idx - 1, -1, -1):
            raw = new_lines[i]
            stripped = raw.rstrip("\n\r").rstrip()
            if stripped:
                if stripped.endswith(","):
                    eol = raw[len(raw.rstrip("\n\r")) :]
                    new_lines[i] = stripped[:-1] + eol
                break

    return "".join(new_lines)


def _rebuild_cte_in_sql(sql: str, cte_name: str, dead_cols: set[str]) -> str | None:
    """Find the named CTE and remove dead columns from its body via line removal.

    All Jinja expressions, FROM clauses, and surrounding SQL are left intact.
    Returns the modified SQL string, or None if nothing was changed.
    """
    boundaries = _find_cte_boundaries(sql, cte_name)
    if boundaries is None:
        logger.debug("Could not locate CTE %s in SQL", cte_name)
        return None

    body_start, body_end = boundaries
    body = sql[body_start:body_end]

    removed_count = 0
    for col_name in dead_cols:
        new_body = _remove_dead_col_line(body, col_name)
        if new_body is not None:
            body = new_body
            removed_count += 1
        else:
            logger.debug("Could not remove column %s from CTE %s", col_name, cte_name)

    if removed_count == 0:
        return None

    return sql[:body_start] + body + sql[body_end:]


class RemoveDeadColumnsTemplate(BaseTemplate):
    """Deterministic template that removes dead columns from CTE SELECT clauses."""

    template_id = "remove_dead_columns"
    applicable_types = {
        "dead_column",
        "dead_window_expression",
        "unused_aggregation_output",
    }

    def matches(
        self,
        opportunity,
        source_files: dict[str, str],
        manifest_metadata: dict[str, Any] | None,
    ) -> bool:
        evidence = opportunity.evidence_snapshot or {}
        # Intra-model format: must have cte_dead_columns list
        cte_dead = evidence.get("cte_dead_columns", [])
        if not cte_dead:
            return False

        file_path = (manifest_metadata or {}).get("original_file_path", "")
        if not file_path:
            return False

        return bool(source_files.get(file_path))

    def apply(
        self,
        opportunity,
        source_files: dict[str, str],
        manifest_metadata: dict[str, Any] | None,
    ) -> TemplateResult | None:
        evidence = opportunity.evidence_snapshot or {}
        cte_dead_list: list[dict] = evidence.get("cte_dead_columns", [])

        file_path = (manifest_metadata or {}).get("original_file_path", "")
        before_content = source_files.get(file_path, "")
        if not before_content:
            return None

        # Apply each CTE fix sequentially
        content = before_content
        total_removed = 0
        modified_ctes: list[str] = []

        for cte_entry in cte_dead_list:
            cte_name = cte_entry["cte_name"]
            dead_cols = {c.lower() for c in cte_entry["dead_columns"]}

            new_content = _rebuild_cte_in_sql(content, cte_name, dead_cols)
            if new_content is not None:
                content = new_content
                total_removed += len(cte_entry["dead_columns"])
                modified_ctes.append(cte_name)

        if content == before_content:
            return None

        model_name = (manifest_metadata or {}).get("name", opportunity.affected_table)
        all_dead_cols: list[str] = evidence.get("dead_columns", [])

        cte_summaries = []
        for entry in cte_dead_list:
            if entry["cte_name"] in modified_ctes:
                col_list = "\n".join(f"  - `{c}`" for c in entry["dead_columns"])
                cte_summaries.append(f"**CTE `{entry['cte_name']}`:**\n{col_list}")

        noun_phrase = "unused column(s)"
        heading = "Dead columns removed"
        if opportunity.opportunity_type == "dead_window_expression":
            noun_phrase = "unused window expression output(s)"
            heading = "Dead window outputs removed"
        elif opportunity.opportunity_type == "unused_aggregation_output":
            noun_phrase = "unused aggregation output(s)"
            heading = "Unused aggregation outputs removed"

        explanation = (
            f"Removed {total_removed} {noun_phrase} from CTE(s) in `{model_name}`.\n\n"
            f"**{heading}:**\n" + "\n\n".join(cte_summaries) + "\n\n"
            "**What changed:** Only the dead column lines were removed from the CTE "
            "SELECT lists. All other formatting, FROM clauses, JOINs, Jinja refs "
            "(`{{ ref(...) }}`), and upstream logic are untouched byte-for-byte."
        )

        return TemplateResult(
            template_id=self.template_id,
            file_path=file_path,
            before_content=before_content,
            after_content=content,
            change_type="sql_change",
            explanation=explanation,
            policy_tags=["sql_change"],
            parameters={
                "dead_columns": all_dead_cols,
                "modified_ctes": modified_ctes,
                "model_name": model_name,
                "cte_dead_columns": cte_dead_list,
            },
            rollback=(
                f"Re-add the removed columns to the CTE SELECT clauses in `{file_path}`. "
                f"The removed columns were: {', '.join(all_dead_cols)}."
            ),
        )

    def rollback_instructions(self) -> str:
        return "Re-add the removed columns to the CTE SELECT clauses of the dbt model file."
