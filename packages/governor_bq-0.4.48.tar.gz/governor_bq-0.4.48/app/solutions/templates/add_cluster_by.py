"""Template: add cluster_by config to a dbt model for shuffle_spill opportunities."""

from __future__ import annotations

import logging
from typing import Any

from app.solutions.templates.base import BaseTemplate, TemplateResult
from app.solutions.templates.config_parser import (
    has_config_property,
    insert_config_property,
    merge_config_list,
)

logger = logging.getLogger("app.solutions.templates.add_cluster_by")


class AddClusterByTemplate(BaseTemplate):
    """Adds cluster_by configuration to a dbt model SQL file.

    Applicable to shuffle_spill opportunities where evidence data
    contains recommended clustering columns.
    """

    template_id = "add_cluster_by"
    applicable_types = {"shuffle_spill"}
    required_params = ["columns"]

    def matches(
        self,
        opportunity,
        source_files: dict[str, str],
        manifest_metadata: dict[str, Any] | None,
    ) -> bool:
        if opportunity.opportunity_type not in self.applicable_types:
            return False

        # Need source files and evidence with clustering columns
        if not source_files:
            return False

        columns = self._extract_columns(opportunity)
        if not columns:
            return False

        # Need a SQL model file
        model_path = self._find_model_path(source_files, manifest_metadata)
        return model_path is not None

    def apply(
        self,
        opportunity,
        source_files: dict[str, str],
        manifest_metadata: dict[str, Any] | None,
    ) -> TemplateResult | None:
        columns = self._extract_columns(opportunity)
        if not columns:
            return None

        model_path = self._find_model_path(source_files, manifest_metadata)
        if not model_path or model_path not in source_files:
            return None

        before_content = source_files[model_path]

        # Check for existing cluster_by
        if has_config_property(before_content, "cluster_by"):
            # Try to merge new columns into existing list
            after_content = merge_config_list(before_content, "cluster_by", columns)
            if after_content is None:
                # All columns already present — no change needed
                logger.info(
                    "cluster_by already contains all recommended columns for %s",
                    model_path,
                )
                return None
        else:
            # Insert new cluster_by property
            value = "[" + ", ".join(f'"{col}"' for col in columns) + "]"
            after_content = insert_config_property(before_content, "cluster_by", value)
            if after_content is None:
                return None

        return TemplateResult(
            template_id=self.template_id,
            file_path=model_path,
            before_content=before_content,
            after_content=after_content,
            change_type="project_config_change",
            explanation=(
                f"Added cluster_by configuration with columns {columns} "
                f"to reduce shuffle spill. Clustering the table by these columns "
                f"will allow BigQuery to co-locate related rows, reducing data "
                f"movement during joins and aggregations."
            ),
            policy_tags=["dbt_config_change"],
            parameters={"columns": columns},
            rollback=self.rollback_instructions(),
        )

    def rollback_instructions(self) -> str:
        return (
            "Remove the cluster_by property from the model's config block. "
            "If cluster_by existed before with different columns, restore "
            "the original column list."
        )

    def _extract_columns(self, opportunity) -> list[str]:
        """Extract recommended clustering columns from evidence data."""
        evidence = getattr(opportunity, "evidence_snapshot", None)
        if not evidence or not isinstance(evidence, dict):
            return []

        # Look for clustering columns in evidence
        columns = evidence.get("recommended_cluster_columns", [])
        if columns:
            return columns

        # Fallback: look for join/group by columns from the evidence
        columns = evidence.get("cluster_columns", [])
        if columns:
            return columns

        # Try to extract from top shuffle keys
        shuffle_keys = evidence.get("top_shuffle_keys", [])
        if shuffle_keys:
            return shuffle_keys[:4]  # BigQuery supports up to 4 clustering columns

        return []

    def _find_model_path(
        self,
        source_files: dict[str, str],
        manifest_metadata: dict[str, Any] | None,
    ) -> str | None:
        """Find the SQL model file path from source files."""
        # Use manifest metadata if available
        if manifest_metadata:
            original_path = manifest_metadata.get("original_file_path")
            if original_path and original_path in source_files:
                return original_path

        # Fallback: find first .sql file
        for path in source_files:
            if path.endswith(".sql") and not path.endswith("dbt_project.yml"):
                return path

        return None
