"""Deterministic solution template for redundant_order_by opportunities."""

from __future__ import annotations

import logging
import re
from typing import Any

from app.solutions.templates.base import BaseTemplate, TemplateResult

logger = logging.getLogger("app.solutions.templates.remove_redundant_order_bys")


def _find_cte_boundaries(sql: str, cte_name: str) -> tuple[int, int] | None:
    """Find the body span of a named CTE."""
    pattern = re.compile(
        r"\b" + re.escape(cte_name) + r"\s+as\s*\(",
        re.IGNORECASE,
    )
    match = pattern.search(sql)
    if not match:
        return None

    open_pos = match.end() - 1
    depth = 0
    for idx in range(open_pos, len(sql)):
        char = sql[idx]
        if char == "(":
            depth += 1
        elif char == ")":
            depth -= 1
            if depth == 0:
                return open_pos + 1, idx
    return None


def _is_word_char(char: str) -> bool:
    return char.isalnum() or char == "_"


def _find_top_level_order_by(cte_body: str) -> int | None:
    """Return the index of the first top-level ORDER BY clause."""
    depth = 0
    quote: str | None = None
    line_comment = False
    block_comment = False
    idx = 0

    while idx < len(cte_body):
        char = cte_body[idx]
        next_two = cte_body[idx : idx + 2]

        if line_comment:
            if char == "\n":
                line_comment = False
            idx += 1
            continue

        if block_comment:
            if next_two == "*/":
                block_comment = False
                idx += 2
            else:
                idx += 1
            continue

        if quote is not None:
            if char == "\\" and idx + 1 < len(cte_body):
                idx += 2
                continue
            if char == quote:
                quote = None
            idx += 1
            continue

        if next_two == "--":
            line_comment = True
            idx += 2
            continue
        if next_two == "/*":
            block_comment = True
            idx += 2
            continue
        if char in {"'", '"', "`"}:
            quote = char
            idx += 1
            continue
        if char == "(":
            depth += 1
            idx += 1
            continue
        if char == ")":
            depth = max(depth - 1, 0)
            idx += 1
            continue

        if depth == 0 and cte_body[idx : idx + 5].lower() == "order":
            prev_char = cte_body[idx - 1] if idx > 0 else ""
            if prev_char and _is_word_char(prev_char):
                idx += 1
                continue

            probe = idx + 5
            while probe < len(cte_body) and cte_body[probe].isspace():
                probe += 1
            if cte_body[probe : probe + 2].lower() != "by":
                idx += 1
                continue

            next_char = cte_body[probe + 2] if probe + 2 < len(cte_body) else ""
            if next_char and _is_word_char(next_char):
                idx += 1
                continue

            return idx

        idx += 1

    return None


def _remove_top_level_order_by(cte_body: str) -> str | None:
    """Remove the top-level ORDER BY block from a CTE body."""
    order_start = _find_top_level_order_by(cte_body)
    if order_start is None:
        return None

    line_start = cte_body.rfind("\n", 0, order_start) + 1
    remove_start = (
        line_start if not cte_body[line_start:order_start].strip() else order_start
    )

    trailing_ws_match = re.search(r"\s*$", cte_body)
    trailing_ws = trailing_ws_match.group(0) if trailing_ws_match else ""
    prefix = cte_body[:remove_start].rstrip()
    return prefix + trailing_ws


def _remove_order_by_from_cte(sql: str, cte_name: str) -> str | None:
    """Remove the redundant ORDER BY from one named CTE."""
    boundaries = _find_cte_boundaries(sql, cte_name)
    if boundaries is None:
        logger.debug("Could not locate CTE %s while removing ORDER BY", cte_name)
        return None

    body_start, body_end = boundaries
    updated_body = _remove_top_level_order_by(sql[body_start:body_end])
    if updated_body is None:
        return None

    return sql[:body_start] + updated_body + sql[body_end:]


class RemoveRedundantOrderBysTemplate(BaseTemplate):
    """Deterministic template that removes redundant CTE ORDER BY clauses."""

    template_id = "remove_redundant_order_bys"
    applicable_types = {"redundant_order_by"}

    def matches(
        self,
        opportunity,
        source_files: dict[str, str],
        manifest_metadata: dict[str, Any] | None,
    ) -> bool:
        evidence = opportunity.evidence_snapshot or {}
        ctes = evidence.get("redundant_order_bys", [])
        file_path = (manifest_metadata or {}).get("original_file_path", "")
        return bool(ctes and file_path and source_files.get(file_path))

    def apply(
        self,
        opportunity,
        source_files: dict[str, str],
        manifest_metadata: dict[str, Any] | None,
    ) -> TemplateResult | None:
        evidence = opportunity.evidence_snapshot or {}
        redundant_order_bys: list[str] = evidence.get("redundant_order_bys", [])
        file_path = (manifest_metadata or {}).get("original_file_path", "")
        before_content = source_files.get(file_path, "")
        if not before_content or not redundant_order_bys:
            return None

        content = before_content
        modified_ctes: list[str] = []
        for cte_name in redundant_order_bys:
            updated = _remove_order_by_from_cte(content, cte_name)
            if updated is not None:
                content = updated
                modified_ctes.append(cte_name)

        if content == before_content or not modified_ctes:
            return None

        model_name = (manifest_metadata or {}).get("name", opportunity.affected_table)
        cte_list = "\n".join(f"  - `{cte}`" for cte in modified_ctes)
        explanation = (
            f"Removed redundant top-level ORDER BY clause(s) from `{model_name}`.\n\n"
            f"**CTEs updated:**\n{cte_list}\n\n"
            "**What changed:** Only the top-level ORDER BY clauses inside the listed "
            "CTEs were removed. SELECT expressions, FROM/JOIN logic, Jinja refs, "
            "and downstream query structure were left intact."
        )

        return TemplateResult(
            template_id=self.template_id,
            file_path=file_path,
            before_content=before_content,
            after_content=content,
            change_type="sql_change",
            explanation=explanation,
            policy_tags=["sql_change"],
            parameters={
                "modified_ctes": modified_ctes,
                "model_name": model_name,
                "redundant_order_bys": modified_ctes,
            },
            rollback=(
                f"Re-add the removed ORDER BY clauses to the affected CTEs in "
                f"`{file_path}`. The updated CTEs were: {', '.join(modified_ctes)}."
            ),
        )

    def rollback_instructions(self) -> str:
        return "Re-add the removed ORDER BY clauses to the affected CTEs."
