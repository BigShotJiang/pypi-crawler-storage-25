"""Safe change template catalog for deterministic solution generation.

Templates are tried in registry order. First match wins.
If no template matches, returns None (proceed to LLM).

Spec 051: ``match_upstream_template`` applies cluster_by / partition_by
config changes to *upstream* models identified by lineage analysis.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any

from app.solutions.templates.base import BaseTemplate, TemplateResult
from app.solutions.templates.config_parser import (
    has_config_property,
    insert_config_property,
    merge_config_list,
)

if TYPE_CHECKING:
    from app.dbt.lineage_analyzer import UpstreamCandidate

logger = logging.getLogger("app.solutions.templates")

_TEMPLATE_REGISTRY: list[BaseTemplate] = []


def register_template(template: BaseTemplate) -> None:
    """Register a template in the catalog."""
    _TEMPLATE_REGISTRY.append(template)
    logger.debug("Registered template: %s", template.template_id)


def match_template(
    opportunity,
    source_files: dict[str, str] | None,
    manifest_metadata: dict[str, Any] | None,
) -> TemplateResult | None:
    """Try all registered templates and return the first match.

    Args:
        opportunity: Opportunity ORM model.
        source_files: Dict mapping file path to content, or None.
        manifest_metadata: Parsed manifest node data, or None.

    Returns:
        TemplateResult if a template matched and was applied successfully,
        None if no template applies (caller should proceed to LLM).
    """
    effective_source_files = source_files or {}

    for template in _TEMPLATE_REGISTRY:
        if opportunity.opportunity_type not in template.applicable_types:
            continue

        try:
            if template.matches(opportunity, effective_source_files, manifest_metadata):
                result = template.apply(
                    opportunity, effective_source_files, manifest_metadata
                )
                if result is not None:
                    logger.info(
                        "Template %s matched for opportunity %s",
                        template.template_id,
                        getattr(opportunity, "id", "?"),
                    )
                    return result
        except (ValueError, KeyError, RuntimeError):
            logger.exception(
                "Template %s failed for opportunity %s, skipping",
                template.template_id,
                getattr(opportunity, "id", "?"),
            )

    return None


def match_upstream_template(
    opportunity,
    candidate: UpstreamCandidate,
    upstream_source_files: dict[str, str],
) -> TemplateResult | None:
    """Apply a cluster_by config change to an upstream model (spec 051).

    Uses the lineage analyzer's UpstreamCandidate (which already has the
    columns to cluster on) and the upstream model's source file to produce
    a deterministic config change.

    Args:
        opportunity: Opportunity ORM model.
        candidate: UpstreamCandidate from lineage analysis.
        upstream_source_files: Dict mapping file path to content.

    Returns:
        TemplateResult targeting the upstream model, or None if the
        config change cannot be applied.
    """
    file_path = candidate.original_file_path
    if file_path not in upstream_source_files:
        logger.debug(
            "Upstream file %s not found in source files, skipping template",
            file_path,
        )
        return None

    before_content = upstream_source_files[file_path]
    columns = candidate.suggested_cluster_columns
    if not columns:
        return None

    quality_map = candidate.column_quality or {}
    excluded_columns = [
        col
        for col, details in quality_map.items()
        if details.get("classification") == "poor" and col not in columns
    ]

    # Apply cluster_by config change
    if has_config_property(before_content, "cluster_by"):
        after_content = merge_config_list(before_content, "cluster_by", columns)
        if after_content is None:
            logger.info(
                "Upstream %s already clustered on all suggested columns",
                candidate.name,
            )
            return None
    else:
        value = "[" + ", ".join(f'"{col}"' for col in columns) + "]"
        after_content = insert_config_property(before_content, "cluster_by", value)
        if after_content is None:
            logger.debug(
                "Could not insert cluster_by into upstream model %s",
                candidate.name,
            )
            return None

    col_list = ", ".join(columns)
    explanation = (
        f"Added cluster_by = [{col_list}] to upstream model '{candidate.name}' "
        f"to fix {opportunity.opportunity_type} in downstream model "
        f"'{getattr(opportunity, 'dbt_model_name', 'unknown')}'. "
        f"{candidate.reason}"
    )
    if excluded_columns:
        excluded_summary = ", ".join(excluded_columns)
        explanation += (
            f" Excluded poor-quality join keys from clustering: {excluded_summary}."
        )

    return TemplateResult(
        template_id="upstream_cluster_by",
        file_path=file_path,
        before_content=before_content,
        after_content=after_content,
        change_type="project_config_change",
        explanation=explanation,
        policy_tags=["dbt_config_change"],
        parameters={
            "columns": columns,
            "upstream_model": candidate.name,
            "affected_model": getattr(opportunity, "dbt_model_name", None),
            **({"column_quality": quality_map} if quality_map else {}),
            **({"excluded_columns": excluded_columns} if excluded_columns else {}),
        },
        rollback=(
            "Remove the cluster_by property from the upstream model's config block. "
            "If cluster_by existed before with different columns, restore "
            "the original column list."
        ),
    )


def get_registry() -> list[BaseTemplate]:
    """Return the current template registry (for testing)."""
    return list(_TEMPLATE_REGISTRY)


# Register built-in templates
# Note: AddClusterByTemplate and AddJoinKeyClusterTemplate remain disabled
# for direct (self-targeting) use (spec 039). Upstream-targeting cluster_by
# is handled by match_upstream_template() above (spec 051).
# from app.solutions.templates.add_cluster_by import AddClusterByTemplate  # noqa: E402
# from app.solutions.templates.add_join_key_cluster import (  # noqa: E402
#     AddJoinKeyClusterTemplate,
# )
# Disabled (spec 047): partition_by self-targeting.
# from app.solutions.templates.add_partition_by import AddPartitionByTemplate  # noqa: E402
# from app.solutions.templates.add_require_partition_filter import (  # noqa: E402
#     AddRequirePartitionFilterTemplate,
# )

from app.solutions.templates.switch_storage_billing import (  # noqa: E402
    SwitchStorageBillingTemplate,
)
from app.solutions.templates.remove_dead_ctes import (  # noqa: E402
    RemoveDeadCtesTemplate,
)
from app.solutions.templates.remove_dead_columns import (  # noqa: E402
    RemoveDeadColumnsTemplate,
)
from app.solutions.templates.remove_redundant_order_bys import (  # noqa: E402
    RemoveRedundantOrderBysTemplate,
)
from app.solutions.templates.remove_unused_joins import (  # noqa: E402
    RemoveUnusedJoinsTemplate,
)

register_template(SwitchStorageBillingTemplate())
register_template(RemoveDeadCtesTemplate())
register_template(RemoveDeadColumnsTemplate())
register_template(RemoveRedundantOrderBysTemplate())
register_template(RemoveUnusedJoinsTemplate())
