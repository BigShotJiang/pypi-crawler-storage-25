"""Template: add cluster_by on JOIN key columns for join_explosion opportunities.

Parses the model's SQL with sqlglot to extract column names from JOIN ON
clauses, then adds cluster_by on those columns. This is a safe,
semantics-preserving config change that helps BigQuery optimize join
operations by co-locating rows with the same key values.
"""

from __future__ import annotations

import logging
from typing import Any

import sqlglot
from sqlglot import exp

from app.solutions.templates.base import BaseTemplate, TemplateResult
from app.solutions.templates.config_parser import (
    has_config_property,
    insert_config_property,
    merge_config_list,
)
from app.solutions.validation.jinja_strip import strip_jinja

logger = logging.getLogger("app.solutions.templates.add_join_key_cluster")

_MAX_CLUSTER_COLUMNS = 4  # BigQuery limit


class AddJoinKeyClusterTemplate(BaseTemplate):
    """Adds cluster_by on JOIN key columns for join_explosion opportunities.

    Parses the model's SQL to find JOIN ON clauses, extracts the column
    names used in join conditions, and adds them as cluster_by columns.
    """

    template_id = "add_join_key_cluster"
    applicable_types = {"join_explosion"}
    required_params = ["columns"]

    def matches(
        self,
        opportunity,
        source_files: dict[str, str],
        manifest_metadata: dict[str, Any] | None,
    ) -> bool:
        if opportunity.opportunity_type not in self.applicable_types:
            return False

        if not source_files:
            return False

        model_path = self._find_model_path(source_files, manifest_metadata)
        if not model_path or model_path not in source_files:
            return False

        columns = self._extract_join_columns(source_files[model_path])
        return len(columns) > 0

    def apply(
        self,
        opportunity,
        source_files: dict[str, str],
        manifest_metadata: dict[str, Any] | None,
    ) -> TemplateResult | None:
        model_path = self._find_model_path(source_files, manifest_metadata)
        if not model_path or model_path not in source_files:
            return None

        before_content = source_files[model_path]
        columns = self._extract_join_columns(before_content)
        if not columns:
            return None

        # Check for existing cluster_by and merge or insert
        if has_config_property(before_content, "cluster_by"):
            after_content = merge_config_list(before_content, "cluster_by", columns)
            if after_content is None:
                # All columns already present
                logger.info(
                    "cluster_by already contains all join key columns for %s",
                    model_path,
                )
                return None
        else:
            value = "[" + ", ".join(f'"{col}"' for col in columns) + "]"
            after_content = insert_config_property(before_content, "cluster_by", value)
            if after_content is None:
                return None

        return TemplateResult(
            template_id=self.template_id,
            file_path=model_path,
            before_content=before_content,
            after_content=after_content,
            change_type="project_config_change",
            explanation=(
                f"Added cluster_by configuration with columns {columns} "
                f"extracted from JOIN conditions. Clustering by join key "
                f"columns helps BigQuery co-locate related rows, improving "
                f"join performance and reducing data shuffling."
            ),
            policy_tags=["dbt_config_change"],
            parameters={"columns": columns},
            rollback=self.rollback_instructions(),
        )

    def rollback_instructions(self) -> str:
        return (
            "Remove the cluster_by property from the model's config block. "
            "If cluster_by existed before with different columns, restore "
            "the original column list."
        )

    def _extract_join_columns(self, sql: str) -> list[str]:
        """Extract column names from JOIN ON clauses via sqlglot AST.

        Strips Jinja first, then parses with sqlglot. Returns a deduplicated
        list of column names (up to 4) found in JOIN conditions.
        """
        strip_result = strip_jinja(sql)
        if not strip_result.success:
            return []

        try:
            ast = sqlglot.parse_one(strip_result.sql, dialect="bigquery")
        except sqlglot.errors.SqlglotError:
            logger.debug("Failed to parse SQL for join key extraction")
            return []

        columns: list[str] = []
        seen: set[str] = set()

        for join in ast.find_all(exp.Join):
            on_clause = join.args.get("on")
            if on_clause is None:
                continue

            for col in on_clause.find_all(exp.Column):
                name = col.name
                if name and name not in seen:
                    seen.add(name)
                    columns.append(name)

        return columns[:_MAX_CLUSTER_COLUMNS]

    def _find_model_path(
        self,
        source_files: dict[str, str],
        manifest_metadata: dict[str, Any] | None,
    ) -> str | None:
        """Find the SQL model file path from source files."""
        if manifest_metadata:
            original_path = manifest_metadata.get("original_file_path")
            if original_path and original_path in source_files:
                return original_path

        for path in source_files:
            if path.endswith(".sql") and not path.endswith("dbt_project.yml"):
                return path

        return None
