"""Deterministic solution template for storage billing optimization.

Generates ALTER SCHEMA DDL to switch dataset billing model from LOGICAL
to PHYSICAL. No LLM invocation needed — fully deterministic.
"""

from __future__ import annotations

from typing import Any

from app.solutions.templates.base import BaseTemplate, TemplateResult


class SwitchStorageBillingTemplate(BaseTemplate):
    """Template that generates ALTER SCHEMA DDL for billing model switch."""

    template_id = "switch_storage_billing"
    applicable_types = {"storage_billing_optimization"}

    def matches(
        self,
        opportunity,
        source_files: dict[str, str],
        manifest_metadata: dict[str, Any] | None,
    ) -> bool:
        """Returns True if opportunity type is storage_billing_optimization."""
        return opportunity.opportunity_type == "storage_billing_optimization"

    def apply(
        self,
        opportunity,
        source_files: dict[str, str],
        manifest_metadata: dict[str, Any] | None,
    ) -> TemplateResult | None:
        """Generate ALTER SCHEMA DDL for billing model switch.

        Returns TemplateResult with infrastructure change data.
        The generator converts this to a bigquery_infrastructure solution.
        """
        evidence = opportunity.evidence_snapshot or {}
        dataset = evidence.get("dataset", opportunity.affected_table)

        # Extract dataset name (strip project prefix if present)
        dataset_short = dataset.split(".")[-1] if "." in dataset else dataset

        ddl = f"ALTER SCHEMA `{dataset_short}` SET OPTIONS (storage_billing_model = 'PHYSICAL')"
        rollback_ddl = f"ALTER SCHEMA `{dataset_short}` SET OPTIONS (storage_billing_model = 'LOGICAL')"

        compression_ratio = evidence.get("compression_ratio", "N/A")
        logical_cost = evidence.get("logical_cost_monthly", 0)
        physical_cost = evidence.get("physical_cost_monthly", 0)
        monthly_savings = evidence.get("monthly_savings", 0)
        annual_savings = evidence.get("annual_savings", 0)
        savings_pct = evidence.get("savings_percentage", 0)
        table_count = evidence.get("table_count")
        table_count_text = f" ({table_count} tables)" if table_count else ""

        explanation = (
            f"Switch dataset '{dataset_short}'{table_count_text} from logical to physical storage billing.\n\n"
            f"**Current cost**: ${logical_cost}/month (logical billing)\n"
            f"**Projected cost**: ${physical_cost}/month (physical billing)\n"
            f"**Monthly savings**: ${monthly_savings}/month ({savings_pct}% reduction)\n"
            f"**Annual savings**: ${annual_savings}/year\n"
            f"**Compression ratio**: {compression_ratio}:1\n\n"
            f"**DDL command**:\n```sql\n{ddl}\n```\n\n"
            f"This change does not affect query performance or data access. "
            f"It only changes how storage is billed. The change is fully reversible."
        )

        return TemplateResult(
            template_id=self.template_id,
            file_path="",  # No file change — infrastructure DDL
            before_content="",
            after_content="",
            change_type="",
            explanation=explanation,
            policy_tags=["bigquery_infrastructure"],
            parameters={
                "resolution_category": "bigquery_infrastructure",
                "dataset": dataset,
                "dataset_short": dataset_short,
                "ddl": ddl,
                "rollback_ddl": rollback_ddl,
                "current_setting_value": "LOGICAL",
                "recommended_setting_value": "PHYSICAL",
                "affected_resource": dataset,
            },
            rollback=rollback_ddl,
        )

    def rollback_instructions(self) -> str:
        """Return generic rollback instruction."""
        return (
            "ALTER SCHEMA `{dataset}` SET OPTIONS (storage_billing_model = 'LOGICAL')"
        )
