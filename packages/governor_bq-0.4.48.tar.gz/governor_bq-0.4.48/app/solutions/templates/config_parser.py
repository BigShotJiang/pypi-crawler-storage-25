"""dbt config block parser using balanced-delimiter matching.

Parses {{ config(...) }} blocks in dbt SQL files and provides
operations to insert, merge, and detect config properties.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field


@dataclass
class ConfigBlock:
    """Parsed representation of a {{ config(...) }} block."""

    start: int  # Position of the opening '{' of '{{ config('
    end: int  # Position after the closing '}}'
    content: str  # Raw text of the config block including {{ }}
    properties: dict[str, str] = field(default_factory=dict)  # name → raw value text


def parse_config_block(sql: str) -> ConfigBlock | None:
    """Find and parse {{ config(...) }} in a dbt SQL file.

    Uses balanced-delimiter matching (not regex) to handle nested
    dicts and lists inside config properties.

    Returns ConfigBlock or None if no config block found.
    """
    # Find the start of {{ config(
    match = re.search(r"\{\{\s*config\s*\(", sql)
    if not match:
        return None

    block_start = match.start()
    paren_start = match.end() - 1  # Position of the opening '('

    # Walk forward from the opening '(' counting balanced delimiters
    inner_start = paren_start + 1
    paren_end = _find_balanced_close(sql, paren_start, "(", ")")
    if paren_end is None:
        return None

    # Find the closing '}}' after the ')'
    rest = sql[paren_end + 1 :]
    close_match = re.match(r"\s*\}\}", rest)
    if not close_match:
        return None

    block_end = paren_end + 1 + close_match.end()
    block_content = sql[block_start:block_end]

    # Parse properties from the inner content
    inner = sql[inner_start:paren_end].strip()
    properties = _parse_properties(inner)

    return ConfigBlock(
        start=block_start,
        end=block_end,
        content=block_content,
        properties=properties,
    )


def insert_config_property(
    sql: str, property_name: str, property_value: str
) -> str | None:
    """Insert a new property into an existing config block.

    If no config block exists, prepend one.
    If the property already exists, return None (caller decides merge vs skip).

    Returns the modified SQL or None if property already exists.
    """
    block = parse_config_block(sql)

    if block is None:
        # No config block — prepend one
        config_line = f"{{{{ config(\n    {property_name}={property_value}\n) }}}}\n\n"
        return config_line + sql

    # Check if property already exists
    if property_name in block.properties:
        return None

    # Insert the property into the existing config block
    # Find the content between config( and )
    match = re.search(r"\{\{\s*config\s*\(", sql)
    paren_start = match.end() - 1
    paren_end = _find_balanced_close(sql, paren_start, "(", ")")

    inner = sql[paren_start + 1 : paren_end].rstrip()

    # Detect indentation from existing properties
    indent = _detect_indent(inner)

    # Add trailing comma to existing content if needed
    stripped_inner = inner.rstrip()
    if stripped_inner and not stripped_inner.endswith(","):
        inner = stripped_inner + ","

    # Build the new property line
    new_prop = f"\n{indent}{property_name}={property_value}"

    # Reconstruct
    new_inner = inner + new_prop + "\n"
    new_sql = sql[: paren_start + 1] + new_inner + sql[paren_end:]
    return new_sql


def merge_config_list(sql: str, property_name: str, new_items: list[str]) -> str | None:
    """Merge items into an existing list property (e.g., append to cluster_by).

    If the property doesn't exist, inserts it as a new list.
    If all items already exist, returns None (no change needed).

    Returns the modified SQL or None if no changes needed.
    """
    block = parse_config_block(sql)

    if block is None or property_name not in block.properties:
        # Property doesn't exist — insert the whole list
        value = "[" + ", ".join(f'"{item}"' for item in new_items) + "]"
        return insert_config_property(sql, property_name, value)

    # Parse existing list value
    existing_value = block.properties[property_name].strip()
    existing_items = _parse_list_value(existing_value)

    # Determine which items to add
    items_to_add = [item for item in new_items if item not in existing_items]
    if not items_to_add:
        return None  # All items already present

    # Build the new list value
    all_items = existing_items + items_to_add
    new_value = "[" + ", ".join(f'"{item}"' for item in all_items) + "]"

    # Replace the old property value in the SQL
    return _replace_property_value(sql, property_name, new_value)


def has_config_property(sql: str, property_name: str) -> bool:
    """Check if a config property exists in the SQL file."""
    block = parse_config_block(sql)
    if block is None:
        return False
    return property_name in block.properties


def get_config_property(sql: str, property_name: str) -> str | None:
    """Get the raw value of a config property."""
    block = parse_config_block(sql)
    if block is None:
        return None
    return block.properties.get(property_name)


def _find_balanced_close(
    text: str, start: int, open_char: str, close_char: str
) -> int | None:
    """Find the position of the balanced closing delimiter.

    Starts at `start` (which should be the position of the open_char).
    Ignores characters inside string literals (single or double quoted).

    Returns the position of the matching close_char or None.
    """
    depth = 0
    i = start
    in_string = None

    while i < len(text):
        ch = text[i]

        # Handle string literals
        if ch in ('"', "'") and (i == 0 or text[i - 1] != "\\"):
            if in_string is None:
                in_string = ch
            elif in_string == ch:
                in_string = None
            i += 1
            continue

        if in_string is not None:
            i += 1
            continue

        # Handle nested delimiters (all types)
        if ch in ("(", "[", "{"):
            depth += 1
        elif ch in (")", "]", "}"):
            depth -= 1
            if depth == 0 and ch == close_char:
                return i

        i += 1

    return None


def _parse_properties(inner: str) -> dict[str, str]:
    """Parse config properties from the inner content of config().

    Handles nested dicts, lists, and string values.
    Returns dict mapping property name to raw value text.
    """
    properties: dict[str, str] = {}
    i = 0
    n = len(inner)

    while i < n:
        # Skip whitespace and commas
        while i < n and inner[i] in (" ", "\t", "\n", "\r", ","):
            i += 1

        if i >= n:
            break

        # Read property name
        name_start = i
        while i < n and inner[i] not in ("=", " ", "\t", "\n"):
            i += 1

        name = inner[name_start:i].strip()
        if not name:
            break

        # Skip whitespace and '='
        while i < n and inner[i] in (" ", "\t", "\n", "\r"):
            i += 1
        if i < n and inner[i] == "=":
            i += 1
        while i < n and inner[i] in (" ", "\t", "\n", "\r"):
            i += 1

        # Read value (may be a string, number, list, dict, or identifier)
        value_start = i
        if i < n and inner[i] in ("[", "{"):
            # Balanced-delimiter value
            end = _find_balanced_close(
                inner, i, inner[i], "]" if inner[i] == "[" else "}"
            )
            if end is not None:
                i = end + 1
            else:
                # Malformed — take rest
                i = n
        elif i < n and inner[i] in ('"', "'"):
            # String value
            quote = inner[i]
            i += 1
            while i < n and inner[i] != quote:
                if inner[i] == "\\":
                    i += 1  # Skip escaped char
                i += 1
            if i < n:
                i += 1  # Skip closing quote
        else:
            # Simple value (True, False, number, identifier)
            while i < n and inner[i] not in (",", "\n", "\r", " ", "\t", ")"):
                i += 1

        value = inner[value_start:i].strip()
        if name:
            properties[name] = value

    return properties


def _detect_indent(inner: str) -> str:
    """Detect the indentation used for config properties."""
    for line in inner.split("\n"):
        stripped = line.lstrip()
        if stripped and not stripped.startswith("#"):
            indent = line[: len(line) - len(stripped)]
            if indent:
                return indent
    return "    "  # default 4 spaces


def _parse_list_value(value: str) -> list[str]:
    """Parse a list literal like '["col1", "col2"]' into Python list."""
    # Strip brackets
    inner = value.strip()
    if inner.startswith("["):
        inner = inner[1:]
    if inner.endswith("]"):
        inner = inner[:-1]
    inner = inner.strip()

    if not inner:
        return []

    items: list[str] = []
    for part in inner.split(","):
        part = part.strip().strip('"').strip("'")
        if part:
            items.append(part)
    return items


def _replace_property_value(sql: str, property_name: str, new_value: str) -> str:
    """Replace the value of an existing config property in-place."""
    block = parse_config_block(sql)
    if block is None or property_name not in block.properties:
        return sql

    # Find the property in the raw config block content
    match = re.search(r"\{\{\s*config\s*\(", sql)
    paren_start = match.end() - 1
    paren_end = _find_balanced_close(sql, paren_start, "(", ")")
    inner = sql[paren_start + 1 : paren_end]

    # Find the property name=value pattern within inner
    prop_pattern = re.compile(rf"({re.escape(property_name)}\s*=\s*)", re.DOTALL)
    prop_match = prop_pattern.search(inner)
    if not prop_match:
        return sql

    # Find the value extent after the '='
    val_start = prop_match.end()
    val_abs_start = paren_start + 1 + val_start
    old_value = block.properties[property_name]

    # Find where the old value ends in the original SQL
    # Search for the old value starting at val_abs_start
    val_end = val_abs_start + len(old_value)

    return sql[:val_abs_start] + new_value + sql[val_end:]
