"""Service layer for solution job management and solution CRUD."""

from __future__ import annotations

import logging
import uuid
from datetime import datetime, timedelta, timezone
from decimal import Decimal

from sqlalchemy import func, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from app.core.config import get_settings
from app.opportunities.models import Opportunity
from app.opportunities.presentation import sync_opportunity_solution_snapshots
from app.solutions.exceptions import (
    LLMNotConfiguredError,
    SolutionJobExistsError,
)
from app.solutions.models import Solution, SolutionJob

logger = logging.getLogger("app.solutions.service")

# Approximate LLM pricing per million tokens (input, output) in USD.
# Used to compute process cost per solution job.
_LLM_PRICES_PER_MILLION: dict[str, tuple[float, float]] = {
    "gemini-2.0-flash": (0.075, 0.30),
    "gemini-2.0-flash-001": (0.075, 0.30),
    "gemini-1.5-flash": (0.075, 0.30),
    "gemini-1.5-flash-001": (0.075, 0.30),
    "gemini-1.5-pro": (1.25, 5.00),
    "gemini-1.5-pro-001": (1.25, 5.00),
}
_LLM_DEFAULT_PRICES = (0.50, 1.50)  # conservative fallback


def _estimate_llm_cost(
    prompt_tokens: int | None,
    completion_tokens: int | None,
    model: str | None,
) -> Decimal:
    """Return estimated LLM API cost in USD for one solution job invocation."""
    if not prompt_tokens and not completion_tokens:
        return Decimal("0")
    input_price, output_price = _LLM_PRICES_PER_MILLION.get(
        (model or "").lower(), _LLM_DEFAULT_PRICES
    )
    cost = (
        (prompt_tokens or 0) * input_price
        + (completion_tokens or 0) * output_price
    ) / 1_000_000
    return Decimal(str(round(cost, 6)))


def get_solution_job_stale_cutoff() -> datetime:
    """Return the timestamp before which in-progress jobs are considered stale."""
    settings = get_settings()
    return datetime.now(timezone.utc) - timedelta(
        minutes=max(1, settings.solution_job_stale_timeout_minutes)
    )


class SolutionService:
    """Service for solution job lifecycle and solution storage."""

    def __init__(self, db: Session) -> None:
        self._db = db

    def reclaim_stale_in_progress_jobs(
        self, *, opportunity_id: str | None = None
    ) -> int:
        """Mark stale in-progress jobs as failed so they stop blocking work."""
        cutoff = get_solution_job_stale_cutoff()
        query = self._db.query(SolutionJob).filter(
            SolutionJob.status == "in_progress",
            SolutionJob.started_at.isnot(None),
            SolutionJob.started_at < cutoff,
        )
        if opportunity_id:
            query = query.filter(SolutionJob.opportunity_id == opportunity_id)

        stale_jobs = query.all()
        if not stale_jobs:
            return 0

        completed_at = datetime.now(timezone.utc)
        for job in stale_jobs:
            job.status = "failed"
            job.completed_at = completed_at
            job.error_stage = "storage"
            job.error_message = (
                "Marked failed after exceeding the in-progress timeout. "
                "The worker likely exited before completing the job."
            )

        self._db.commit()
        logger.warning(
            "Marked %d stale in-progress solution job(s) as failed",
            len(stale_jobs),
        )
        return len(stale_jobs)

    # ------------------------------------------------------------------
    # Solution Job CRUD (US1)
    # ------------------------------------------------------------------

    def create_solution_job(
        self,
        opportunity_id: str,
        config_id: str,
        detection_job_id: str | None = None,
    ) -> SolutionJob:
        """Queue a solution generation job for an opportunity.

        Raises:
            SolutionJobExistsError: If a queued/in_progress job already exists.
            LLMNotConfiguredError: If LLM is not configured.
            ValueError: If opportunity not found or not active.
        """
        from app.llm import is_llm_configured

        if not is_llm_configured():
            raise LLMNotConfiguredError(
                "LLM provider is not configured. Set LLM_API_KEY to enable."
            )

        self.reclaim_stale_in_progress_jobs(opportunity_id=opportunity_id)

        opp = self._db.get(Opportunity, opportunity_id)
        if not opp:
            raise ValueError(f"Opportunity {opportunity_id} not found")
        if opp.status != "active":
            raise ValueError(f"Opportunity {opportunity_id} is not active")

        # Check for existing queued/in_progress job
        existing = (
            self._db.query(SolutionJob)
            .filter(
                SolutionJob.opportunity_id == opportunity_id,
                SolutionJob.status.in_(["queued", "in_progress"]),
            )
            .first()
        )
        if existing:
            raise SolutionJobExistsError(
                f"Solution job already exists for opportunity {opportunity_id}"
            )

        job = SolutionJob(
            id=str(uuid.uuid4()),
            opportunity_id=opportunity_id,
            detection_job_id=detection_job_id,
            config_id=config_id,
            status="queued",
        )
        self._db.add(job)
        try:
            self._db.commit()
        except IntegrityError as exc:
            self._db.rollback()
            raise SolutionJobExistsError(
                f"Solution job already exists for opportunity {opportunity_id}"
            ) from exc
        self._db.refresh(job)

        logger.info(
            "Created solution job %s for opportunity %s", job.id, opportunity_id
        )
        return job

    def get_pending_solution_job(self) -> SolutionJob | None:
        """FIFO poll for the next queued solution job.

        Uses SELECT ... FOR UPDATE SKIP LOCKED for safe concurrent access.
        Returns the oldest queued job, or None.
        """
        self.reclaim_stale_in_progress_jobs()
        dialect = self._db.bind.dialect.name if self._db.bind else "sqlite"

        if dialect == "postgresql":
            stmt = (
                select(SolutionJob)
                .where(SolutionJob.status == "queued")
                .order_by(SolutionJob.queued_at.asc())
                .limit(1)
                .with_for_update(skip_locked=True)
            )
        else:
            # SQLite doesn't support FOR UPDATE SKIP LOCKED
            stmt = (
                select(SolutionJob)
                .where(SolutionJob.status == "queued")
                .order_by(SolutionJob.queued_at.asc())
                .limit(1)
            )

        return self._db.scalars(stmt).first()

    def claim_solution_job(self, job_id: str) -> bool:
        """Atomically claim a job (queued -> in_progress).

        Returns True if claimed, False if already claimed or not found.
        """
        job = self._db.get(SolutionJob, job_id)
        if not job or job.status != "queued":
            return False

        job.status = "in_progress"
        job.started_at = datetime.now(timezone.utc)
        self._db.commit()
        return True

    def complete_solution_job(
        self,
        job_id: str,
        solutions_count: int,
        llm_metadata: dict | None = None,
        resolution_category: str | None = None,
        trust_tier: str | None = None,
    ) -> None:
        """Mark a solution job as completed with metrics."""
        job = self._db.get(SolutionJob, job_id)
        if not job:
            return

        job.status = "completed"
        job.completed_at = datetime.now(timezone.utc)
        job.solutions_generated_count = solutions_count
        job.resolution_category = resolution_category
        job.trust_tier = trust_tier

        if llm_metadata:
            job.llm_provider = llm_metadata.get("provider")
            job.llm_model = llm_metadata.get("model")
            job.prompt_tokens = llm_metadata.get("prompt_tokens")
            job.completion_tokens = llm_metadata.get("completion_tokens")
            job.llm_latency_ms = llm_metadata.get("latency_ms")

            # Accumulate LLM process cost onto the opportunity
            llm_cost = _estimate_llm_cost(
                job.prompt_tokens, job.completion_tokens, job.llm_model
            )
            if llm_cost > 0 and job.opportunity_id:
                opp = self._db.get(Opportunity, job.opportunity_id)
                if opp is not None:
                    existing = opp.process_cost_usd or Decimal("0")
                    opp.process_cost_usd = existing + llm_cost

        self._db.commit()

    def fail_solution_job(
        self,
        job_id: str,
        error_message: str,
        error_stage: str,
    ) -> None:
        """Mark a solution job as failed. Increments lifetime_retry_count."""
        job = self._db.get(SolutionJob, job_id)
        if not job:
            return

        job.status = "failed"
        job.completed_at = datetime.now(timezone.utc)
        job.error_message = error_message[:2000]  # Truncate long error messages
        job.error_stage = error_stage
        job.lifetime_retry_count = job.lifetime_retry_count + 1

        self._db.commit()

    def queue_solutions_for_detection(
        self,
        detection_job_id: str,
        config_id: str,
    ) -> list[SolutionJob]:
        """After detection completes, queue solution jobs for qualifying opportunities.

        Finds active opportunities for the config, filters out those with:
        - Current solutions (matching latest manifest version)
        - Pending solution jobs (queued/in_progress)
        - Permanently failed jobs (lifetime_retry_count >= max)
        """
        from app.core.config import get_settings
        from app.llm import is_llm_configured

        if not is_llm_configured():
            logger.info("LLM not configured, skipping solution job queueing")
            return []

        settings = get_settings()
        max_lifetime = settings.llm_max_lifetime_retries
        queue_limit = max(0, settings.solution_queue_detection_limit)

        self.reclaim_stale_in_progress_jobs()

        if queue_limit == 0:
            logger.info(
                "Solution queue detection limit is 0, skipping solution job queueing"
            )
            return []

        # Rank by current cost first so the default queue focuses on the
        # most expensive unresolved opportunities for this detection.
        # Skip cascade-delegated opportunities — their root cause gets
        # the solution job instead (spec 082).
        from sqlalchemy import or_

        opportunities = (
            self._db.query(Opportunity)
            .filter(
                Opportunity.config_id == config_id,
                Opportunity.status == "active",
                or_(
                    Opportunity.cascade_status.is_(None),
                    Opportunity.cascade_status == "root",
                ),
            )
            .order_by(
                Opportunity.current_cost_estimate.desc(),
                Opportunity.expected_savings.desc(),
                Opportunity.created_at.asc(),
            )
            .all()
        )

        created_jobs: list[SolutionJob] = []

        for opp in opportunities:
            if len(created_jobs) >= queue_limit:
                break

            # Skip if there's a pending solution job
            has_pending = (
                self._db.query(SolutionJob)
                .filter(
                    SolutionJob.opportunity_id == opp.id,
                    SolutionJob.status.in_(["queued", "in_progress"]),
                )
                .first()
            )
            if has_pending:
                continue

            # Skip if permanently failed
            last_failed = (
                self._db.query(SolutionJob)
                .filter(
                    SolutionJob.opportunity_id == opp.id,
                    SolutionJob.status == "failed",
                )
                .order_by(SolutionJob.created_at.desc())
                .first()
            )
            if last_failed and last_failed.lifetime_retry_count >= max_lifetime:
                continue

            # Check if current solution exists for latest manifest version
            if opp.manifest_version_id:
                has_current = (
                    self._db.query(Solution)
                    .filter(
                        Solution.opportunity_id == opp.id,
                        Solution.manifest_version_id == opp.manifest_version_id,
                    )
                    .first()
                )
                if has_current:
                    continue

            # Queue the job
            job = SolutionJob(
                id=str(uuid.uuid4()),
                opportunity_id=opp.id,
                detection_job_id=detection_job_id,
                config_id=config_id,
                status="queued",
            )
            self._db.add(job)
            created_jobs.append(job)

        if created_jobs:
            self._db.commit()
            for job in created_jobs:
                self._db.refresh(job)
            logger.info(
                "Queued %d solution jobs for detection %s (limit=%d)",
                len(created_jobs),
                detection_job_id,
                queue_limit,
            )

        return created_jobs

    # ------------------------------------------------------------------
    # Solution CRUD (US4)
    # ------------------------------------------------------------------

    def store_solution(
        self,
        opportunity_id: str,
        solution_job_id: str,
        manifest_version_id: str | None,
        solution_data: dict,
    ) -> Solution:
        """Store a generated solution with version management.

        Determines version_number, creates Solution record, purges oldest
        if count exceeds 3 for (opportunity_id, file_path).
        """
        resolution_category = solution_data["resolution_category"]
        file_path = solution_data.get("file_path")

        # Category-specific validation
        # dbt_project_change with file_changes requires all fields;
        # without file_changes (no source code) only explanation is needed.
        if resolution_category == "dbt_project_change" and solution_data.get(
            "file_path"
        ):
            for field in (
                "file_path",
                "before_content",
                "after_content",
                "change_type",
            ):
                if not solution_data.get(field):
                    raise ValueError(f"dbt_project_change requires non-null {field}")
        elif resolution_category == "bigquery_infrastructure":
            for field in (
                "current_setting_value",
                "recommended_setting_value",
                "affected_resource",
            ):
                if not solution_data.get(field):
                    raise ValueError(
                        f"bigquery_infrastructure requires non-null {field}"
                    )

        # Determine version number
        max_version = (
            self._db.query(func.max(Solution.version_number))
            .filter(
                Solution.opportunity_id == opportunity_id,
                Solution.file_path == file_path
                if file_path
                else Solution.file_path.is_(None),
            )
            .scalar()
        )
        version_number = (max_version or 0) + 1

        solution = Solution(
            id=str(uuid.uuid4()),
            opportunity_id=opportunity_id,
            solution_job_id=solution_job_id,
            manifest_version_id=manifest_version_id,
            resolution_category=resolution_category,
            version_number=version_number,
            file_path=file_path,
            change_type=solution_data.get("change_type"),
            before_content=solution_data.get("before_content"),
            after_content=solution_data.get("after_content"),
            repository=solution_data.get("repository"),
            commit_sha=solution_data.get("commit_sha"),
            current_setting_value=solution_data.get("current_setting_value"),
            recommended_setting_value=solution_data.get("recommended_setting_value"),
            affected_resource=solution_data.get("affected_resource"),
            explanation=solution_data["explanation"],
            risk_level=solution_data["risk_level"],
            risk_justification=solution_data["risk_justification"],
            trust_tier=solution_data.get("trust_tier"),
            validation_report=solution_data.get("validation_report"),
            dry_run_original=solution_data.get("dry_run_original"),
            dry_run_modified=solution_data.get("dry_run_modified"),
            compiled_after_sql=solution_data.get("compiled_after_sql"),
        )
        self._db.add(solution)
        self._db.flush()

        # Purge oldest if count exceeds 3
        self._purge_old_versions(opportunity_id, file_path, max_keep=3)

        sync_opportunity_solution_snapshots(self._db, [opportunity_id])

        self._db.commit()
        self._db.refresh(solution)
        return solution

    def get_solutions_for_opportunity(
        self,
        opportunity_id: str,
        latest_only: bool = True,
    ) -> list[Solution]:
        """Retrieve solutions for an opportunity.

        Args:
            opportunity_id: The opportunity ID.
            latest_only: If True, return only the highest version per file/setting.

        Returns:
            List of Solution records ordered by file_path, version_number DESC.
        """
        query = (
            self._db.query(Solution)
            .filter(Solution.opportunity_id == opportunity_id)
            .order_by(Solution.file_path, Solution.version_number.desc())
        )

        if latest_only:
            # Subquery: max version per file_path for this opportunity
            subq = (
                self._db.query(
                    Solution.file_path,
                    func.max(Solution.version_number).label("max_version"),
                )
                .filter(Solution.opportunity_id == opportunity_id)
                .group_by(Solution.file_path)
                .subquery()
            )

            query = (
                self._db.query(Solution)
                .join(
                    subq,
                    (Solution.file_path == subq.c.file_path)
                    & (Solution.version_number == subq.c.max_version),
                )
                .filter(Solution.opportunity_id == opportunity_id)
                .order_by(Solution.file_path, Solution.version_number.desc())
            )

        return query.all()

    def _purge_old_versions(
        self, opportunity_id: str, file_path: str | None, max_keep: int = 3
    ) -> None:
        """Delete oldest versions beyond max_keep for a given (opportunity_id, file_path)."""
        if file_path:
            condition = Solution.file_path == file_path
        else:
            condition = Solution.file_path.is_(None)

        versions = (
            self._db.query(Solution)
            .filter(
                Solution.opportunity_id == opportunity_id,
                condition,
            )
            .order_by(Solution.version_number.desc())
            .all()
        )

        if len(versions) > max_keep:
            for old in versions[max_keep:]:
                self._db.delete(old)

    # ------------------------------------------------------------------
    # Dashboard (US5)
    # ------------------------------------------------------------------

    def get_solution_jobs_dashboard(self) -> dict:
        """Return solution job counts for the queue dashboard."""
        now = datetime.now(timezone.utc)
        day_ago = now - timedelta(hours=24)

        pending = (
            self._db.query(func.count(SolutionJob.id))
            .filter(SolutionJob.status == "queued")
            .scalar()
            or 0
        )
        running = (
            self._db.query(func.count(SolutionJob.id))
            .filter(SolutionJob.status == "in_progress")
            .scalar()
            or 0
        )
        completed_24h = (
            self._db.query(func.count(SolutionJob.id))
            .filter(
                SolutionJob.status == "completed",
                SolutionJob.completed_at >= day_ago,
            )
            .scalar()
            or 0
        )
        failed_24h = (
            self._db.query(func.count(SolutionJob.id))
            .filter(
                SolutionJob.status == "failed",
                SolutionJob.completed_at >= day_ago,
            )
            .scalar()
            or 0
        )

        return {
            "pending": pending,
            "running": running,
            "completed_24h": completed_24h,
            "failed_24h": failed_24h,
        }

    def cancel_solution_job(self, job_id: str) -> bool:
        """Cancel a queued solution job (queued -> failed).

        Returns True if cancelled, False if not found or not queued.
        """
        job = self._db.get(SolutionJob, job_id)
        if not job or job.status != "queued":
            return False

        job.status = "failed"
        job.error_message = "Cancelled by administrator"
        job.completed_at = datetime.now(timezone.utc)
        self._db.commit()
        return True

    def requeue_opportunity_solution(self, opportunity_id: str) -> SolutionJob:
        """Delete existing solutions for one opportunity and re-queue a job.

        Returns:
            The newly created SolutionJob.

        Raises:
            LLMNotConfiguredError: If LLM is not configured.
            ValueError: If opportunity not found or not active.
        """
        from app.llm import is_llm_configured

        if not is_llm_configured():
            raise LLMNotConfiguredError(
                "LLM provider is not configured. Set LLM_API_KEY to enable."
            )

        opp = self._db.get(Opportunity, opportunity_id)
        if not opp:
            raise ValueError(f"Opportunity {opportunity_id} not found")
        if opp.status not in ("active", "pr_pending"):
            raise ValueError(f"Opportunity {opportunity_id} is not in active state")

        # Delete existing solutions
        self._db.query(Solution).filter(
            Solution.opportunity_id == opportunity_id
        ).delete(synchronize_session="fetch")

        self._mark_active_solution_jobs_failed(
            opportunity_ids=[opportunity_id],
            error_message="Superseded by regeneration request",
        )

        # Create new queued job
        job = SolutionJob(
            id=str(uuid.uuid4()),
            opportunity_id=opportunity_id,
            config_id=opp.config_id,
            status="queued",
        )
        self._db.add(job)
        self._db.commit()
        self._db.refresh(job)

        logger.info(
            "Re-queued solution job %s for opportunity %s",
            job.id,
            opportunity_id,
        )
        return job

    def requeue_all_solutions(self) -> int:
        """Delete existing solutions and re-queue jobs for all active opportunities.

        This is useful when the solution generator logic has been fixed and
        you want to regenerate all solutions from scratch.

        Returns:
            Number of solution jobs queued.
        """
        from app.llm import is_llm_configured

        if not is_llm_configured():
            raise LLMNotConfiguredError(
                "LLM provider is not configured. Set LLM_API_KEY to enable."
            )

        # Find all active opportunities
        opportunities = (
            self._db.query(Opportunity).filter(Opportunity.status == "active").all()
        )

        if not opportunities:
            return 0

        opp_ids = [opp.id for opp in opportunities]

        # Delete existing solutions for these opportunities
        self._db.query(Solution).filter(Solution.opportunity_id.in_(opp_ids)).delete(
            synchronize_session="fetch"
        )

        self._mark_active_solution_jobs_failed(
            opportunity_ids=opp_ids,
            error_message="Superseded by bulk regeneration request",
        )

        # Create new queued jobs
        created = 0
        for opp in opportunities:
            job = SolutionJob(
                id=str(uuid.uuid4()),
                opportunity_id=opp.id,
                config_id=opp.config_id,
                status="queued",
            )
            self._db.add(job)
            created += 1

        self._db.commit()
        logger.info("Re-queued %d solution jobs for regeneration", created)
        return created

    def _mark_active_solution_jobs_failed(
        self,
        *,
        opportunity_ids: list[str],
        error_message: str,
    ) -> int:
        """Preserve job history while clearing any active work for re-queueing."""
        if not opportunity_ids:
            return 0

        completed_at = datetime.now(timezone.utc)
        updated = (
            self._db.query(SolutionJob)
            .filter(
                SolutionJob.opportunity_id.in_(opportunity_ids),
                SolutionJob.status.in_(["queued", "in_progress"]),
            )
            .update(
                {
                    "status": "failed",
                    "error_message": error_message,
                    "error_stage": "storage",
                    "completed_at": completed_at,
                },
                synchronize_session="fetch",
            )
        )
        return updated

    # ------------------------------------------------------------------
    # Version history (US7)
    # ------------------------------------------------------------------

    def get_solution_versions(
        self, opportunity_id: str, file_path: str
    ) -> list[Solution]:
        """Return all versions for a specific file, ordered by version DESC."""
        return (
            self._db.query(Solution)
            .filter(
                Solution.opportunity_id == opportunity_id,
                Solution.file_path == file_path,
            )
            .order_by(Solution.version_number.desc())
            .all()
        )
