"""Jinja2 pre-processor for SQL files before AST parsing.

Strips dbt-specific Jinja2 expressions from SQL to produce
parseable SQL for sqlglot. Falls back gracefully when complex
Jinja2 control flow prevents clean stripping.
"""

from __future__ import annotations

import re
from dataclasses import dataclass


@dataclass
class JinjaStripResult:
    """Result of Jinja2 stripping."""

    sql: str
    expressions_replaced: int
    unparseable_blocks: int
    success: bool  # True if clean strip, False if residual Jinja2 detected


# Pattern for {{ config(...) }} — balanced-paren aware removal
_CONFIG_RE = re.compile(r"\{\{-?\s*config\s*\(.*?\)\s*-?\}\}", re.DOTALL)

# Pattern for {{ ref('model_name') }} or {{ ref("model_name") }}
_REF_RE = re.compile(r"\{\{-?\s*ref\s*\(\s*['\"]([^'\"]+)['\"]\s*\)\s*-?\}\}")

# Pattern for {{ source('source_name', 'table_name') }}
_SOURCE_RE = re.compile(
    r"\{\{-?\s*source\s*\(\s*['\"][^'\"]+['\"]\s*,\s*['\"]([^'\"]+)['\"]\s*\)\s*-?\}\}"
)

# Pattern for {% ... %} block tags (for, if, endif, endfor, set, macro, etc.)
_BLOCK_TAG_RE = re.compile(r"\{%-?\s*.*?\s*-?%\}", re.DOTALL)

# Pattern for remaining {{ ... }} expressions
_EXPR_RE = re.compile(r"\{\{-?\s*(.*?)\s*-?\}\}", re.DOTALL)


def strip_jinja(sql: str) -> JinjaStripResult:
    """Strip Jinja2 expressions from SQL for AST parsing.

    Replacement rules:
    - {{ config(...) }} → removed entirely
    - {{ ref('model_name') }} → model_name
    - {{ source('src', 'table') }} → table
    - {% ... %} block tags → removed
    - {{ other_expression }} → __jinja_expr__

    After stripping, checks for residual Jinja2 markers.
    If found, marks result as not fully parseable.
    """
    result = sql
    count = 0
    unparseable = 0

    # 1. Remove config blocks (these can span multiple lines)
    result, n = _CONFIG_RE.subn("", result)
    count += n

    # 2. Replace ref() calls with the model name
    result, n = _REF_RE.subn(r"\1", result)
    count += n

    # 3. Replace source() calls with the table name
    result, n = _SOURCE_RE.subn(r"\1", result)
    count += n

    # 4. Remove block tags ({% if %}, {% for %}, {% endif %}, etc.)
    block_matches = _BLOCK_TAG_RE.findall(result)
    unparseable = _count_control_flow_blocks(block_matches)
    result, n = _BLOCK_TAG_RE.subn("", result)
    count += n

    # 5. Replace remaining expressions with placeholder
    result, n = _EXPR_RE.subn("__jinja_expr__", result)
    count += n

    # 6. Check for residual Jinja2 markers
    has_residual = "{%" in result or "{{" in result

    # Clean up extra blank lines from removals
    result = re.sub(r"\n\s*\n\s*\n", "\n\n", result)

    return JinjaStripResult(
        sql=result.strip(),
        expressions_replaced=count,
        unparseable_blocks=unparseable,
        success=not has_residual and unparseable == 0,
    )


def _count_control_flow_blocks(block_tags: list[str]) -> int:
    """Count control flow blocks that may affect SQL structure.

    Simple set/macro blocks are harmless. But {% if %}/{% for %}
    wrapping SQL clauses can produce unparseable results after stripping.
    """
    control_flow_count = 0
    for tag in block_tags:
        tag_lower = tag.lower()
        # These control flow blocks can wrap SQL clauses
        if any(
            kw in tag_lower
            for kw in ("{% if", "{%- if", "{% for", "{%- for", "{% elif", "{%- elif")
        ):
            control_flow_count += 1
    return control_flow_count
