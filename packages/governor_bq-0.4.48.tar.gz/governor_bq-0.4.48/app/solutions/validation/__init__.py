"""AST-based validation engine for LLM-generated solutions."""
