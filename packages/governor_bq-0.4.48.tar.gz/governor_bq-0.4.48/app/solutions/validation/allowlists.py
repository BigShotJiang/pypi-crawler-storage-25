"""Per-opportunity-type allowlists for AST change classification.

Defines which categories of structural changes are considered safe
(additive and allowlisted) for each opportunity type. Changes that
fall outside the allowlist for a given opportunity type are classified
as "additive but not allowlisted" and require manual review.

The allowlists are intentionally conservative. For example, adding a
new JOIN is never on any allowlist because JOINs can multiply row
counts unpredictably. Config property additions (like cluster_by or
partition_by) are safe for most opportunity types because they do not
change query logic or output.
"""

from __future__ import annotations

from enum import Enum


class ChangeCategory(str, Enum):
    """Categories of structural changes detected by AST comparison.

    Each category maps to a type of AST node addition. These are used
    by the classifier to determine whether an additive change is on
    the per-opportunity-type allowlist.
    """

    CONFIG_PROPERTY_ADDITION = "config_property_addition"
    COLUMN_ADDITION = "column_addition"
    FILTER_ADDITION = "filter_addition"
    JOIN_ADDITION = "join_addition"
    SUBQUERY_ADDITION = "subquery_addition"
    CTE_ADDITION = "cte_addition"


ALLOWLISTS: dict[str, set[ChangeCategory]] = {
    "shuffle_spill": {
        ChangeCategory.CONFIG_PROPERTY_ADDITION,
    },
    "slot_contention": {
        ChangeCategory.CONFIG_PROPERTY_ADDITION,
        ChangeCategory.FILTER_ADDITION,
    },
    "join_explosion": {
        ChangeCategory.CONFIG_PROPERTY_ADDITION,
        ChangeCategory.FILTER_ADDITION,
    },
    "partition_pruning": {
        ChangeCategory.CONFIG_PROPERTY_ADDITION,
        ChangeCategory.FILTER_ADDITION,
    },
}
