"""Change classification engine for AST-validated solutions.

Classifies structural comparisons (from ast_validator and yaml_validator)
into trust tiers based on whether changes are additive, modifications,
or destructive, and whether additive changes fall within the per-opportunity-type
allowlist.

Classification hierarchy (highest priority first):
1. DESTRUCTIVE - any removals detected -> blocked at caller level
2. MODIFICATION - any modifications detected -> requires_review
3. ADDITIVE_NOT_ALLOWLISTED - additions outside allowlist -> requires_review
4. ADDITIVE_ALLOWLISTED - all additions on allowlist -> validated
"""

from __future__ import annotations

from enum import Enum

from app.solutions.validation.allowlists import ALLOWLISTS, ChangeCategory
from app.solutions.validation.ast_validator import StructuralComparison
from app.solutions.validation.yaml_validator import YamlComparison


class ChangeClassification(str, Enum):
    """Classification of a structural change."""

    ADDITIVE_ALLOWLISTED = "additive_allowlisted"  # -> validated
    ADDITIVE_NOT_ALLOWLISTED = "additive_not_allowlisted"  # -> requires_review
    MODIFICATION = "modification"  # -> requires_review
    DESTRUCTIVE = "destructive"  # -> BLOCKED


def classify_change(
    comparison: StructuralComparison, opportunity_type: str
) -> ChangeClassification:
    """Classify a SQL structural comparison based on the opportunity-type allowlist.

    Classification logic (evaluated in priority order):
    1. If anything was removed (columns, CTEs, joins) -> DESTRUCTIVE
    2. If anything was modified (columns, WHERE, GROUP BY, ORDER BY) -> MODIFICATION
    3. If only additions exist -> check each addition category against the allowlist:
       - If ALL addition categories are in the allowlist -> ADDITIVE_ALLOWLISTED
       - If ANY addition category is NOT in the allowlist -> ADDITIVE_NOT_ALLOWLISTED
    4. If no changes detected (no-op) -> ADDITIVE_ALLOWLISTED

    Args:
        comparison: Structural comparison from compare_sql().
        opportunity_type: The opportunity type string (e.g., "shuffle_spill").

    Returns:
        ChangeClassification enum value.
    """
    # 1. Check for destructive changes (removals)
    if (
        comparison.columns_removed
        or comparison.ctes_removed
        or comparison.joins_removed
    ):
        return ChangeClassification.DESTRUCTIVE

    # 2. Check for modifications
    if (
        comparison.columns_modified
        or comparison.where_changed
        or comparison.group_by_changed
        or comparison.order_by_changed
    ):
        return ChangeClassification.MODIFICATION

    # 3. Check for additions
    addition_categories = _get_addition_categories(comparison)

    if not addition_categories:
        # No changes detected at all — treat as safe (no-op)
        return ChangeClassification.ADDITIVE_ALLOWLISTED

    # Look up the allowlist for this opportunity type
    allowed = ALLOWLISTS.get(opportunity_type, set())

    # Check if ALL addition categories are in the allowlist
    if addition_categories <= allowed:
        return ChangeClassification.ADDITIVE_ALLOWLISTED
    else:
        return ChangeClassification.ADDITIVE_NOT_ALLOWLISTED


def classify_yaml_change(comparison: YamlComparison) -> ChangeClassification:
    """Classify a YAML structural comparison.

    YAML classification is simpler than SQL — there is no per-opportunity-type
    allowlist for YAML changes. The logic is:
    1. If anything was removed -> DESTRUCTIVE
    2. If anything was modified -> MODIFICATION
    3. If only additions -> ADDITIVE_NOT_ALLOWLISTED (YAML additions always
       require review since they can change model behavior)
    4. If no changes -> ADDITIVE_ALLOWLISTED (no-op)

    Args:
        comparison: YAML comparison from compare_yaml().

    Returns:
        ChangeClassification enum value.
    """
    # 1. Removals are destructive
    if comparison.keys_removed:
        return ChangeClassification.DESTRUCTIVE

    # 2. Modifications require review
    if comparison.keys_modified:
        return ChangeClassification.MODIFICATION

    # 3. Additions in YAML always require review
    if comparison.keys_added:
        return ChangeClassification.ADDITIVE_NOT_ALLOWLISTED

    # 4. No changes
    return ChangeClassification.ADDITIVE_ALLOWLISTED


def classification_to_trust_tier(classification: ChangeClassification) -> str:
    """Map a change classification to its trust tier string.

    Trust tier mapping:
    - ADDITIVE_ALLOWLISTED -> "validated"
    - ADDITIVE_NOT_ALLOWLISTED -> "requires_review"
    - MODIFICATION -> "requires_review"
    - DESTRUCTIVE -> "requires_review" (blocking happens at the caller level)

    Note: DESTRUCTIVE maps to "requires_review" here rather than a separate
    blocked tier because the blocking logic (refusing to store the solution)
    is handled by the caller. The trust tier is a display/storage concern.

    Args:
        classification: ChangeClassification enum value.

    Returns:
        Trust tier string: "validated" or "requires_review".
    """
    if classification == ChangeClassification.ADDITIVE_ALLOWLISTED:
        return "validated"
    # All other classifications map to requires_review.
    # DESTRUCTIVE solutions are blocked at the caller level and never stored,
    # but if they were, they would be requires_review.
    return "requires_review"


def _get_addition_categories(
    comparison: StructuralComparison,
) -> set[ChangeCategory]:
    """Determine which addition categories are present in a structural comparison.

    Maps the structural comparison fields to ChangeCategory enum values.

    Args:
        comparison: Structural comparison from compare_sql().

    Returns:
        Set of ChangeCategory values representing the types of additions found.
    """
    categories: set[ChangeCategory] = set()

    if comparison.config_changes:
        categories.add(ChangeCategory.CONFIG_PROPERTY_ADDITION)

    if comparison.columns_added:
        categories.add(ChangeCategory.COLUMN_ADDITION)

    if comparison.joins_added:
        categories.add(ChangeCategory.JOIN_ADDITION)

    if comparison.ctes_added:
        categories.add(ChangeCategory.CTE_ADDITION)

    return categories
