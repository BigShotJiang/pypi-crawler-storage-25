"""Validation report builder utility.

Constructs consistent structured validation reports with timestamps
for both template matching and AST validation code paths.
"""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Any


def extract_template_id(report: dict[str, Any] | None) -> str | None:
    """Return the first template_id found in a validation report."""
    if not report:
        return None

    template_id = report.get("template_id")
    if isinstance(template_id, str) and template_id:
        return template_id

    for step in report.get("steps", []):
        if not isinstance(step, dict):
            continue

        step_template_id = step.get("template_id")
        if isinstance(step_template_id, str) and step_template_id:
            return step_template_id

        for container_key in ("parameters", "details"):
            container = step.get(container_key)
            if isinstance(container, dict):
                nested_template_id = container.get("template_id")
                if isinstance(nested_template_id, str) and nested_template_id:
                    return nested_template_id

    return None


def has_blocking_dbt_verification_issue(report: dict[str, Any] | None) -> bool:
    """Return True when dbt verification did not succeed for a solution."""
    if not report:
        return False

    parse_report = report.get("dbt_parse")
    if isinstance(parse_report, dict):
        return parse_report.get("success") is False

    compile_report = report.get("dbt_compile")
    if not isinstance(compile_report, dict):
        return False

    return compile_report.get("success") is False


def build_validation_report(
    steps: list[dict[str, Any]],
    tier: str,
    warnings: list[str] | None = None,
    error: str | None = None,
) -> dict[str, Any]:
    """Build a structured validation report.

    Args:
        steps: List of validation step dicts (each with type, result, etc.)
        tier: The overall trust tier classification.
        warnings: Optional list of warning messages.
        error: Optional error message if validation failed.

    Returns:
        Structured report dict for JSONB storage.
    """
    timestamp = datetime.now(timezone.utc).isoformat()
    template_id = extract_template_id({"steps": steps})

    return {
        "steps": steps,
        "tier": tier,
        "overall_tier": tier,
        "warnings": warnings or [],
        "error": error,
        "timestamp": timestamp,
        "template_id": template_id,
    }


def make_step(
    step_type: str,
    result: str,
    **details: Any,
) -> dict[str, Any]:
    """Create a validation step entry with timestamp.

    Args:
        step_type: Step type (e.g., "template_match", "ast_parse").
        result: Step result (e.g., "matched", "success", "failure").
        **details: Additional step-specific key-value pairs.

    Returns:
        Step dict with type, result, timestamp, and details.
    """
    step: dict[str, Any] = {
        "type": step_type,
        "result": result,
        "timestamp": datetime.now(timezone.utc).isoformat(),
    }
    step.update(details)
    return step
