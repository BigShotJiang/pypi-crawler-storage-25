"""LLM prompt templates for solution generation."""

from __future__ import annotations

from typing import Any

SYSTEM_INSTRUCTION = """You are an expert dbt developer, SQL performance engineer, and Google BigQuery infrastructure specialist.

Your task is to analyze BigQuery cost optimization opportunities and generate concrete, actionable solutions.

You will receive:
- An opportunity description with evidence data from BigQuery job analysis
- The opportunity type and severity score
- Source code from the dbt project (when available)
- Manifest metadata describing the dbt model configuration

You must respond with a JSON object matching the provided schema exactly. Your response should include:
1. A resolution_category classifying whether this is a "dbt_project_change" (code fix) or "bigquery_infrastructure" (settings change)
2. Concrete before/after changes (for code) or setting recommendations (for infrastructure)
3. A clear explanation of what the change does and why
4. A risk assessment (low/medium/high) with justification

Guidelines:
- For dbt project changes: after_content MUST contain the COMPLETE file from top to bottom — every config block, CTE, column, join, filter, and expression from the original file must be present. Do NOT omit, abbreviate, or summarise any part of the file with comments like "-- rest of query unchanged". Copy the entire original file first, then apply your targeted changes.
- For SQL changes: the output must be syntactically valid and complete. It must start with any {{ config(...) }} block if the original has one, include every WITH clause/CTE, and end with the final SELECT.
- For schema changes: maintain proper YAML formatting
- For infrastructure changes: specify the exact resource and setting values
- Be conservative with risk assessments — prefer "medium" over "low" when uncertain
- The after_content MUST be different from the original source file
- CRITICAL: A truncated or partial file will be rejected by the verification system. Always output the FULL file.
"""


def build_prompt(
    opportunity_type: str,
    affected_table: str,
    severity_score: int,
    explanation: str,
    evidence_snapshot: dict[str, Any],
    dbt_model_name: str | None = None,
    source_files: dict[str, str] | None = None,
    manifest_metadata: dict[str, Any] | None = None,
    bigquery_job_samples: list[dict[str, Any]] | None = None,
    # Enriched context fields (spec 050)
    compiled_sql: str | None = None,
    upstream_models: list[dict] | None = None,
    downstream_dependents: list[dict] | None = None,
    macro_summary: list[dict] | None = None,
    dry_run_baseline: dict | None = None,
    # Lineage analysis context (spec 051)
    lineage_candidates: list[dict] | None = None,
    lineage_notes: list[str] | None = None,
    # Column type info from INFORMATION_SCHEMA (spec 066)
    column_types: dict[str, str] | None = None,
) -> str:
    """Build a complete prompt for solution generation.

    Selects the appropriate template based on whether source code is available.
    """
    parts = [
        "## Cost Optimization Opportunity\n",
        f"**Type**: {opportunity_type}",
        f"**Affected Table**: {affected_table}",
        f"**Severity**: {severity_score}/100",
        f"**Explanation**: {explanation}",
        f"\n### Evidence\n```json\n{_format_dict(evidence_snapshot)}\n```",
    ]

    if dbt_model_name:
        parts.append(f"\n**dbt Model**: {dbt_model_name}")

    if source_files:
        parts.append("\n## Source Code\n")
        parts.append(
            "The following files are from the dbt project. "
            "Use them to understand the current implementation and propose changes.\n"
        )
        for path, content in source_files.items():
            parts.append(f"### `{path}`\n```\n{content}\n```\n")

    if manifest_metadata:
        parts.append(
            f"\n## Manifest Metadata\n```json\n{_format_dict(manifest_metadata)}\n```"
        )

    if bigquery_job_samples:
        parts.append("\n## BigQuery Job Samples\n")
        for i, sample in enumerate(bigquery_job_samples[:3], 1):
            parts.append(f"### Job {i}\n```json\n{_format_dict(sample)}\n```\n")

    # Column types from INFORMATION_SCHEMA (spec 066)
    if column_types:
        type_lines = "\n".join(
            f"  {col}: {dtype}" for col, dtype in sorted(column_types.items())
        )
        parts.append(
            "\n## BigQuery Column Types (from INFORMATION_SCHEMA)\n"
            "Use these ACTUAL data types when setting partition_by. "
            "Do NOT guess from SQL aliases.\n"
            f"```\n{type_lines}\n```"
        )

    # Enriched context sections (spec 050)
    if compiled_sql:
        parts.append(
            "\n## Compiled SQL (What BigQuery Actually Executes)\n"
            f"```sql\n{compiled_sql}\n```"
        )

    if upstream_models:
        parts.append("\n## Upstream Models (Direct Dependencies)\n")
        for model in upstream_models:
            name = model.get("name", "unknown")
            materialized = model.get("materialized", "unknown")
            header = f"### model: {name} (materialized: {materialized}"
            partition_by = model.get("partition_by")
            cluster_by = model.get("cluster_by")
            if partition_by:
                field = (
                    partition_by.get("field", "")
                    if isinstance(partition_by, dict)
                    else str(partition_by)
                )
                header += f", partitioned: {field}"
            if cluster_by:
                header += f", clustered: {', '.join(cluster_by)}"
            header += ")\n"
            parts.append(header)

    if downstream_dependents:
        parts.append("\n## Downstream Dependents (Models That Consume This Model)\n")
        for dep in downstream_dependents:
            name = dep.get("name", "unknown")
            materialized = dep.get("materialized", "unknown")
            info = f"- {name} (materialized: {materialized}"
            partition_by = dep.get("partition_by")
            cluster_by = dep.get("cluster_by")
            if partition_by:
                field = (
                    partition_by.get("field", "")
                    if isinstance(partition_by, dict)
                    else str(partition_by)
                )
                info += f", partitioned: {field}"
            if cluster_by:
                info += f", clustered: {', '.join(cluster_by)}"
            info += ")"
            parts.append(info)

    if dry_run_baseline:
        parts.append("\n## Dry-Run Baseline\n")
        bytes_processed = dry_run_baseline.get("total_bytes_processed", 0)
        cost_usd = dry_run_baseline.get("estimated_cost_usd", 0)
        parts.append(
            f"- Current compiled SQL dry-run: {bytes_processed:,} bytes (${cost_usd:.2f})"
        )

    if macro_summary:
        parts.append("\n## Available Project Macros\n")
        for macro in macro_summary:
            name = macro.get("name", "")
            args = macro.get("arguments", [])
            args_str = ", ".join(args) if args else ""
            parts.append(f"- {name}({args_str})")

    # Lineage analysis context (spec 051)
    if lineage_candidates:
        parts.append("\n## Lineage Analysis (Upstream Fix Candidates)\n")
        parts.append(
            "The following upstream models were identified as candidates for "
            "config changes to fix this downstream issue:\n"
        )
        for cand in lineage_candidates:
            name = cand.get("name", "unknown")
            materialized = cand.get("materialized", "unknown")
            suggested = cand.get("suggested_cluster_columns", [])
            current = cand.get("current_cluster_by")
            file_path = cand.get("original_file_path", "")
            reason = cand.get("reason", "")
            entry = f"- **{name}** (materialized: {materialized}"
            if current:
                entry += f", current cluster_by: {current}"
            entry += ")"
            if suggested:
                entry += f"\n  Suggested: cluster_by = {suggested}"
            if file_path:
                entry += f"\n  File: `{file_path}`"
            if reason:
                entry += f"\n  Reason: {reason}"
            parts.append(entry)
        if lineage_notes:
            parts.append("\n**Analysis notes:**")
            for note in lineage_notes:
                parts.append(f"- {note}")
        parts.append(
            "\nConsider applying cluster_by or partition_by to the upstream model(s) "
            "listed above. The fix should target the upstream model's file, "
            "not the affected model's file."
        )

    if source_files:
        parts.append(
            "\n## Instructions\n"
            "Based on the evidence and source code above, generate a solution. "
            "If the issue can be fixed by modifying dbt project files (SQL, config, schema), "
            "classify as 'dbt_project_change' and provide file_changes with after_content containing the COMPLETE modified file — "
            "every line from the original must be present (config blocks, all CTEs, all columns, all joins). "
            "Do NOT truncate, abbreviate, or omit any part of the file. Copy the full original and apply only the targeted optimization. "
            "You do not need to provide before_content — the system already has the original files. "
            "If the issue requires BigQuery infrastructure changes (slots, reservations, settings), "
            "classify as 'bigquery_infrastructure' and provide a setting_recommendation."
        )
    else:
        parts.append(
            "\n## Instructions\n"
            "Based on the evidence above, generate a solution. "
            "Since no source code is available, focus on BigQuery infrastructure recommendations "
            "if applicable, or provide general dbt project change guidance."
        )

    return "\n".join(parts)


VERIFICATION_INSTRUCTION = """You are a senior code reviewer specializing in dbt projects and BigQuery SQL.

Your task is to review a proposed file modification and determine if it is SAFE to apply as a pull request.

You will receive:
- The original file content (before)
- The proposed modified file content (after)
- Context explaining why the change is being made

You must check ALL of the following:

1. **Completeness**: The proposed file must be a COMPLETE file, not a truncated or partial version. Every CTE, subquery, column, and expression from the original must be present in the modified version unless the change explicitly and intentionally removes it.

2. **Business logic preservation**: All business logic, computed columns, CASE expressions, filters, joins, and transformations from the original file must be preserved unless the optimization requires changing them.

3. **Syntactic validity**: The modified SQL/YAML must be syntactically valid — matching parentheses, proper commas, correct Jinja2 syntax, etc.

4. **Minimal change**: The modification should only change what is necessary for the stated optimization. It should NOT remove columns, CTEs, or logic unrelated to the optimization.

5. **No data loss**: The change must not reduce the output columns or rows in a way that would break downstream consumers.

Respond with a JSON object: {"safe": true/false, "issues": ["description of each issue found"]}.
If the file is safe, issues should be an empty list.
If the file is NOT safe, list every problem found."""


def build_verification_prompt(
    file_path: str,
    before_content: str,
    after_content: str,
    change_context: str,
) -> str:
    """Build a prompt for the verification agent."""
    return (
        f"## File: `{file_path}`\n\n"
        f"### Change Context\n{change_context}\n\n"
        f"### Original File (before)\n```\n{before_content}\n```\n\n"
        f"### Proposed File (after)\n```\n{after_content}\n```\n\n"
        "Review this change and determine if it is safe to apply."
    )


def _format_dict(d: dict | list) -> str:
    """Format a dict/list as indented JSON string."""
    import json

    return json.dumps(d, indent=2, default=str)
