"""Pydantic schemas for solution generation API responses."""

from __future__ import annotations

from datetime import datetime

from pydantic import BaseModel, ConfigDict


class SolutionJobSummary(BaseModel):
    """Summary view of a solution generation job for list displays."""

    model_config = ConfigDict(from_attributes=True)

    id: str
    opportunity_id: str
    config_id: str
    status: str
    resolution_category: str | None = None
    queued_at: datetime
    started_at: datetime | None = None
    completed_at: datetime | None = None
    solutions_generated_count: int = 0
    error_message: str | None = None
    error_stage: str | None = None


class SolutionJobOut(BaseModel):
    """Full detail view of a solution generation job."""

    model_config = ConfigDict(from_attributes=True)

    id: str
    opportunity_id: str
    detection_job_id: str | None = None
    config_id: str
    status: str
    resolution_category: str | None = None
    queued_at: datetime
    started_at: datetime | None = None
    completed_at: datetime | None = None
    retry_count: int = 0
    lifetime_retry_count: int = 0
    max_lifetime_retries: int = 10
    error_message: str | None = None
    error_stage: str | None = None
    llm_provider: str | None = None
    llm_model: str | None = None
    prompt_tokens: int | None = None
    completion_tokens: int | None = None
    llm_latency_ms: int | None = None
    solutions_generated_count: int = 0
    created_at: datetime
    updated_at: datetime


class SolutionSummary(BaseModel):
    """Summary view of a generated solution."""

    model_config = ConfigDict(from_attributes=True)

    id: str
    opportunity_id: str
    resolution_category: str
    version_number: int
    file_path: str | None = None
    change_type: str | None = None
    risk_level: str
    explanation: str
    created_at: datetime


class SolutionOut(BaseModel):
    """Full detail view of a generated solution."""

    model_config = ConfigDict(from_attributes=True)

    id: str
    opportunity_id: str
    solution_job_id: str
    manifest_version_id: str | None = None
    resolution_category: str
    version_number: int
    # dbt project change fields
    file_path: str | None = None
    change_type: str | None = None
    before_content: str | None = None
    after_content: str | None = None
    repository: str | None = None
    commit_sha: str | None = None
    # BigQuery infrastructure fields
    current_setting_value: str | None = None
    recommended_setting_value: str | None = None
    affected_resource: str | None = None
    # Common fields
    explanation: str
    risk_level: str
    risk_justification: str
    created_at: datetime
    updated_at: datetime
