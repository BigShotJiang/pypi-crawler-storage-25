"""Custom exceptions for solution generation."""

from __future__ import annotations


class SolutionJobExistsError(RuntimeError):
    """Raised when a solution job already exists for an opportunity."""


class LLMNotConfiguredError(RuntimeError):
    """Raised when LLM provider configuration is absent."""


class GitHubRetrievalError(RuntimeError):
    """Raised when source code retrieval from GitHub fails."""


class LLMRequestError(RuntimeError):
    """Raised when an LLM API call fails after retries."""


class LLMResponseValidationError(RuntimeError):
    """Raised when an LLM response fails structural validation."""


class NoChangesError(RuntimeError):
    """Raised when LLM returns identical before/after content."""


class DestructiveChangeError(RuntimeError):
    """Raised when AST validation detects destructive changes."""
