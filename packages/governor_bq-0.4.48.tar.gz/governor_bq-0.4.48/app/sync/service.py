"""
Project Data Sync service layer.

Handles sync operation management, BigQuery job retrieval, and manifest processing.
"""

from __future__ import annotations

import logging
import re
from collections.abc import Sequence
from typing import TYPE_CHECKING

from sqlalchemy import ColumnElement, or_
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session, joinedload

from app.sync.models import SyncOperation

if TYPE_CHECKING:
    from app.sync.models import BigQueryJob

logger = logging.getLogger("app.sync")

WORKLOAD_KIND_BUILD = "build"
WORKLOAD_KIND_CONSUMPTION = "consumption"
VALID_WORKLOAD_KINDS = frozenset({WORKLOAD_KIND_BUILD, WORKLOAD_KIND_CONSUMPTION})


# ---------------------------------------------------------------------------
# Service exceptions
# ---------------------------------------------------------------------------


class SyncError(Exception):
    """Base error for sync operations."""


class DuplicateSyncError(SyncError):
    """Raised when a duplicate sync is attempted while one is active."""


class NotFoundError(SyncError):
    """Raised when a sync operation is not found."""


# ---------------------------------------------------------------------------
# SyncService
# ---------------------------------------------------------------------------


class SyncService:
    """Service layer for sync operation management.

    Handles creating sync operations with duplicate prevention,
    retrieving sync details, and querying sync history.
    """

    def __init__(self, db: Session) -> None:
        self._db = db

    def create_sync_operation(
        self, config_id: str, user_id: str | None, triggered_by: str = "manual"
    ) -> SyncOperation:
        """Create a new sync operation with duplicate prevention.

        Args:
            config_id: ID of the project sync configuration
            user_id: ID of the user initiating the sync

        Returns:
            Newly created SyncOperation with status='queued'

        Raises:
            DuplicateSyncError: If a queued or in_progress sync already exists for this config

        Specification Reference:
            FR-003: System MUST prevent duplicate concurrent syncs for the same configuration.
            Only one queued or in_progress sync allowed per config at any time.
        """
        # Check for existing active sync (queued or in_progress)
        existing = (
            self._db.query(SyncOperation)
            .filter(
                SyncOperation.config_id == config_id,
                or_(
                    SyncOperation.status == "queued",
                    SyncOperation.status == "in_progress",
                ),
            )
            .one_or_none()
        )

        if existing:
            raise DuplicateSyncError(
                f"A sync operation is already {existing.status} for this configuration. "
                f"Wait for sync {existing.id} to complete before starting a new one."
            )

        # Create new sync operation
        sync = SyncOperation(
            config_id=config_id,
            status="queued",
            triggered_by=triggered_by,
            initiated_by_id=user_id,
        )
        self._db.add(sync)
        try:
            self._db.commit()
        except IntegrityError as exc:
            self._db.rollback()
            existing = (
                self._db.query(SyncOperation)
                .filter(
                    SyncOperation.config_id == config_id,
                    or_(
                        SyncOperation.status == "queued",
                        SyncOperation.status == "in_progress",
                    ),
                )
                .one_or_none()
            )
            if existing:
                raise DuplicateSyncError(
                    f"A sync operation is already {existing.status} for this "
                    f"configuration. Wait for sync {existing.id} to complete before "
                    "starting a new one."
                ) from exc
            raise
        self._db.refresh(sync)

        logger.info(
            "Created sync operation %s for config %s by user %s",
            sync.id,
            config_id,
            user_id,
        )
        return sync

    def get_sync_operation(self, sync_id: str) -> SyncOperation | None:
        """Retrieve a sync operation by ID with errors loaded.

        Args:
            sync_id: ID of the sync operation to retrieve

        Returns:
            SyncOperation with errors relationship loaded, or None if not found
        """
        return (
            self._db.query(SyncOperation)
            .options(joinedload(SyncOperation.errors))
            .filter(SyncOperation.id == sync_id)
            .one_or_none()
        )

    def get_syncs_for_config(
        self, config_id: str, limit: int = 50, offset: int = 0
    ) -> list[SyncOperation]:
        """Retrieve sync history for a configuration.

        Args:
            config_id: ID of the project sync configuration
            limit: Maximum number of syncs to return (default: 50)
            offset: Number of syncs to skip (default: 0)

        Returns:
            List of SyncOperations ordered by queued_at descending (newest first)

        Used by User Story 4 (Sync History) to display past sync operations.
        """
        return (
            self._db.query(SyncOperation)
            .filter(SyncOperation.config_id == config_id)
            .order_by(SyncOperation.queued_at.desc())
            .limit(limit)
            .offset(offset)
            .all()
        )

    def get_bigquery_jobs(
        self,
        config_id: str,
        limit: int = 50,
        offset: int = 0,
        destination_table: str | None = None,
        workload_kind: str | None = None,
        start_date: str | None = None,
        end_date: str | None = None,
    ) -> list[BigQueryJob]:
        """Retrieve BigQuery jobs for a configuration with filtering support.

        Args:
            config_id: ID of the project sync configuration
            limit: Maximum number of jobs to return (default: 50)
            offset: Number of jobs to skip (default: 0)
            destination_table: Filter by destination table name (partial match)
            workload_kind: Filter by persisted workload classification
            start_date: Filter jobs created on or after this date (ISO format)
            end_date: Filter jobs created on or before this date (ISO format)

        Returns:
            List of BigQueryJob records ordered by creation_time descending

        Used by User Story 5 (View Stored Job Data).
        """
        from datetime import datetime as dt

        from app.sync.models import BigQueryJob

        query = self._db.query(BigQueryJob).filter(BigQueryJob.config_id == config_id)

        # Apply filters
        if destination_table:
            query = query.filter(
                BigQueryJob.destination_table.ilike(f"%{destination_table}%")
            )
        if workload_kind in VALID_WORKLOAD_KINDS:
            query = query.filter(BigQueryJob.workload_kind == workload_kind)
        if start_date:
            try:
                start = dt.fromisoformat(start_date.replace("Z", "+00:00"))
                query = query.filter(BigQueryJob.creation_time >= start)
            except ValueError:
                pass  # Ignore invalid date format
        if end_date:
            try:
                end = dt.fromisoformat(end_date.replace("Z", "+00:00"))
                query = query.filter(BigQueryJob.creation_time <= end)
            except ValueError:
                pass  # Ignore invalid date format

        return (
            query.order_by(BigQueryJob.creation_time.desc())
            .limit(limit)
            .offset(offset)
            .all()
        )

    def get_bigquery_jobs_count(
        self,
        config_id: str,
        destination_table: str | None = None,
        workload_kind: str | None = None,
        start_date: str | None = None,
        end_date: str | None = None,
    ) -> int:
        """Count BigQuery jobs for a configuration with filtering support.

        Args match get_bigquery_jobs for consistent filtering.

        Returns:
            Total count of matching jobs
        """
        from datetime import datetime as dt

        from sqlalchemy import func

        from app.sync.models import BigQueryJob

        query = self._db.query(func.count(BigQueryJob.id)).filter(
            BigQueryJob.config_id == config_id
        )

        # Apply same filters as get_bigquery_jobs
        if destination_table:
            query = query.filter(
                BigQueryJob.destination_table.ilike(f"%{destination_table}%")
            )
        if workload_kind in VALID_WORKLOAD_KINDS:
            query = query.filter(BigQueryJob.workload_kind == workload_kind)
        if start_date:
            try:
                start = dt.fromisoformat(start_date.replace("Z", "+00:00"))
                query = query.filter(BigQueryJob.creation_time >= start)
            except ValueError:
                pass
        if end_date:
            try:
                end = dt.fromisoformat(end_date.replace("Z", "+00:00"))
                query = query.filter(BigQueryJob.creation_time <= end)
            except ValueError:
                pass

        return query.scalar() or 0

    def _build_job_filters(
        self,
        config_id: str,
        destination_table: str | None = None,
        workload_kind: str | None = None,
        start_date: str | None = None,
        end_date: str | None = None,
    ) -> list[ColumnElement[bool]]:
        """Build SQLAlchemy filter conditions for BigQuery job queries."""
        from datetime import datetime as dt

        from app.sync.models import BigQueryJob

        filters = [BigQueryJob.config_id == config_id]
        if destination_table:
            filters.append(
                BigQueryJob.destination_table.ilike(f"%{destination_table}%")
            )
        if workload_kind in VALID_WORKLOAD_KINDS:
            filters.append(BigQueryJob.workload_kind == workload_kind)
        if start_date:
            try:
                start = dt.fromisoformat(start_date.replace("Z", "+00:00"))
                filters.append(BigQueryJob.creation_time >= start)
            except ValueError:
                pass
        if end_date:
            try:
                end = dt.fromisoformat(end_date.replace("Z", "+00:00"))
                filters.append(BigQueryJob.creation_time <= end)
            except ValueError:
                pass
        return filters

    def get_bigquery_jobs_grouped(
        self,
        config_id: str,
        limit: int = 50,
        offset: int = 0,
        destination_table: str | None = None,
        workload_kind: str | None = None,
        start_date: str | None = None,
        end_date: str | None = None,
        sort_by: str = "cost",
        sort_direction: str = "desc",
    ) -> list[dict]:
        """Return BigQuery jobs grouped by destination table with aggregated stats.

        Each group contains: destination_table, job_count, total_cost,
        total_bytes, latest_run, and a list of individual jobs.
        Groups are ordered by the specified sort column.
        """
        from sqlalchemy import func

        from app.sync.models import BigQueryJob

        filters = self._build_job_filters(
            config_id, destination_table, workload_kind, start_date, end_date
        )

        # Sort column mapping for grouped aggregates
        sort_col_map = {
            "table": BigQueryJob.destination_table,
            "runs": func.count(BigQueryJob.id),
            "cost": func.coalesce(func.sum(BigQueryJob.total_cost), 0),
            "data": func.coalesce(func.sum(BigQueryJob.total_bytes_billed), 0),
            "latest": func.max(BigQueryJob.creation_time),
        }
        order_col = sort_col_map.get(sort_by, sort_col_map["cost"])
        order_clause = order_col.asc() if sort_direction == "asc" else order_col.desc()

        # Query 1: aggregated stats per destination table
        groups = (
            self._db.query(
                BigQueryJob.destination_table,
                func.count(BigQueryJob.id).label("job_count"),
                func.coalesce(func.sum(BigQueryJob.total_cost), 0).label("total_cost"),
                func.coalesce(func.sum(BigQueryJob.total_bytes_billed), 0).label(
                    "total_bytes"
                ),
                func.max(BigQueryJob.creation_time).label("latest_run"),
            )
            .filter(*filters)
            .group_by(BigQueryJob.destination_table)
            .order_by(order_clause)
            .limit(limit)
            .offset(offset)
            .all()
        )

        if not groups:
            return []

        table_names = [g.destination_table for g in groups]

        # Query 2: individual jobs for these tables
        jobs = (
            self._db.query(BigQueryJob)
            .filter(*filters, BigQueryJob.destination_table.in_(table_names))
            .order_by(BigQueryJob.creation_time.desc())
            .all()
        )

        # Group individual jobs by destination_table
        jobs_by_table: dict[str | None, list] = {}
        for job in jobs:
            jobs_by_table.setdefault(job.destination_table, []).append(job)

        return [
            {
                "destination_table": g.destination_table,
                "job_count": g.job_count,
                "total_cost": float(g.total_cost) if g.total_cost else 0.0,
                "total_bytes": int(g.total_bytes) if g.total_bytes else 0,
                "latest_run": g.latest_run,
                "jobs": jobs_by_table.get(g.destination_table, []),
            }
            for g in groups
        ]

    def get_bigquery_jobs_group_count(
        self,
        config_id: str,
        destination_table: str | None = None,
        workload_kind: str | None = None,
        start_date: str | None = None,
        end_date: str | None = None,
    ) -> int:
        """Count distinct destination tables for pagination of grouped view."""
        from sqlalchemy import func

        from app.sync.models import BigQueryJob

        filters = self._build_job_filters(
            config_id, destination_table, workload_kind, start_date, end_date
        )

        subq = (
            self._db.query(BigQueryJob.destination_table)
            .filter(*filters)
            .group_by(BigQueryJob.destination_table)
            .subquery()
        )
        return self._db.query(func.count()).select_from(subq).scalar() or 0

    def get_queue_dashboard(self) -> dict:
        """Get global queue dashboard data grouped by status.

        Returns all pending and running syncs, plus completed and failed syncs
        from the last 24 hours.

        Returns:
            Dict with keys: pending, running, completed, failed (lists of syncs),
            and summary (counts per category)

        Used by User Story 6 (Queue Dashboard).
        """
        from datetime import datetime, timedelta, timezone

        from sqlalchemy.orm import joinedload

        from app.configurations.models import ManifestConfiguration

        now = datetime.now(timezone.utc)
        last_24h = now - timedelta(hours=24)

        # Get pending syncs (FIFO order)
        pending = (
            self._db.query(SyncOperation)
            .options(joinedload(SyncOperation.errors))
            .filter(SyncOperation.status == "queued")
            .order_by(SyncOperation.queued_at.asc())
            .all()
        )

        # Get running syncs (longest running first)
        running = (
            self._db.query(SyncOperation)
            .options(joinedload(SyncOperation.errors))
            .filter(SyncOperation.status == "in_progress")
            .order_by(SyncOperation.started_at.asc())
            .all()
        )

        # Get completed syncs (last 24h, most recent first)
        completed = (
            self._db.query(SyncOperation)
            .options(joinedload(SyncOperation.errors))
            .filter(
                SyncOperation.status == "completed",
                SyncOperation.completed_at >= last_24h,
            )
            .order_by(SyncOperation.completed_at.desc())
            .all()
        )

        # Get failed syncs (last 24h, most recent first)
        failed = (
            self._db.query(SyncOperation)
            .options(joinedload(SyncOperation.errors))
            .filter(
                SyncOperation.status == "failed",
                SyncOperation.completed_at >= last_24h,
            )
            .order_by(SyncOperation.completed_at.desc())
            .all()
        )

        # Get config names for all syncs
        all_sync_ids = [s.config_id for s in pending + running + completed + failed]
        config_names = {}
        if all_sync_ids:
            configs = (
                self._db.query(ManifestConfiguration.id, ManifestConfiguration.name)
                .filter(ManifestConfiguration.id.in_(set(all_sync_ids)))
                .all()
            )
            config_names = {c.id: c.name for c in configs}

        # Attach config names to syncs
        for sync in pending + running + completed + failed:
            sync.config_name = config_names.get(sync.config_id, "Unknown")

        return {
            "pending": pending,
            "running": running,
            "completed": completed,
            "failed": failed,
            "summary": {
                "pending_count": len(pending),
                "running_count": len(running),
                "completed_count": len(completed),
                "failed_count": len(failed),
            },
        }

    def _get_manifest_table_set_for_sync(
        self,
        sync_operation: SyncOperation,
        manifest_tables_by_version_id: dict[str, set[str]],
        latest_manifest_id_by_config: dict[str, str | None],
    ) -> tuple[set[str], bool]:
        """Resolve the manifest-managed table set for a sync.

        Returns a tuple of ``(table_set, used_fallback_manifest)``.
        """
        from app.sync.models import ManifestVersion

        manifest_version_id = sync_operation.used_manifest_version_id
        if manifest_version_id:
            if manifest_version_id not in manifest_tables_by_version_id:
                manifest_version = (
                    self._db.query(ManifestVersion)
                    .filter(ManifestVersion.id == manifest_version_id)
                    .one_or_none()
                )
                if manifest_version:
                    manifest_tables_by_version_id[manifest_version_id] = (
                        build_manifest_table_set(
                            extract_dbt_tables(manifest_version.content)
                        )
                    )
            manifest_tables = manifest_tables_by_version_id.get(manifest_version_id)
            if manifest_tables:
                return manifest_tables, False

        if sync_operation.config_id not in latest_manifest_id_by_config:
            latest_manifest_id_by_config[sync_operation.config_id] = (
                self._db.query(ManifestVersion.id)
                .filter(ManifestVersion.config_id == sync_operation.config_id)
                .order_by(ManifestVersion.retrieved_at.desc())
                .limit(1)
                .scalar()
            )

        latest_manifest_id = latest_manifest_id_by_config[sync_operation.config_id]
        if not latest_manifest_id:
            return set(), True

        if latest_manifest_id not in manifest_tables_by_version_id:
            latest_manifest = (
                self._db.query(ManifestVersion)
                .filter(ManifestVersion.id == latest_manifest_id)
                .one_or_none()
            )
            if latest_manifest:
                manifest_tables_by_version_id[latest_manifest_id] = (
                    build_manifest_table_set(
                        extract_dbt_tables(latest_manifest.content)
                    )
                )

        return manifest_tables_by_version_id.get(latest_manifest_id, set()), True

    def backfill_bigquery_job_workload_kind(
        self,
        config_id: str | None = None,
        batch_size: int = 500,
    ) -> dict[str, int]:
        """Backfill persisted workload_kind values for historical BigQuery jobs."""
        from app.sync.models import BigQueryJob

        total_processed = 0
        jobs_updated = 0
        jobs_skipped = 0
        fallback_manifest_count = 0
        manifest_tables_by_version_id: dict[str, set[str]] = {}
        latest_manifest_id_by_config: dict[str, str | None] = {}

        while True:
            query = self._db.query(BigQueryJob).filter(
                BigQueryJob.workload_kind.is_(None)
            )
            if config_id:
                query = query.filter(BigQueryJob.config_id == config_id)

            jobs = (
                query.order_by(BigQueryJob.creation_time.asc(), BigQueryJob.id.asc())
                .limit(batch_size)
                .all()
            )

            if not jobs:
                break

            sync_rows = (
                self._db.query(SyncOperation)
                .filter(SyncOperation.id.in_({job.sync_id for job in jobs}))
                .all()
            )
            manifest_tables_by_sync: dict[str, set[str]] = {}

            for sync in sync_rows:
                manifest_tables, used_fallback = self._get_manifest_table_set_for_sync(
                    sync,
                    manifest_tables_by_version_id=manifest_tables_by_version_id,
                    latest_manifest_id_by_config=latest_manifest_id_by_config,
                )
                manifest_tables_by_sync[sync.id] = manifest_tables
                if used_fallback:
                    fallback_manifest_count += 1

            for job in jobs:
                total_processed += 1
                manifest_tables = manifest_tables_by_sync.get(job.sync_id, set())
                workload_kind = classify_bigquery_job_workload(
                    destination_table=job.destination_table,
                    referenced_tables=job.referenced_tables,
                    manifest_tables=manifest_tables,
                )

                if workload_kind:
                    job.workload_kind = workload_kind
                    jobs_updated += 1
                else:
                    jobs_skipped += 1

            self._db.commit()

            if len(jobs) < batch_size:
                break

        if fallback_manifest_count:
            logger.info(
                "Backfilled workload_kind with latest-manifest fallback for %d syncs",
                fallback_manifest_count,
            )

        return {
            "processed": total_processed,
            "updated": jobs_updated,
            "skipped": jobs_skipped,
            "fallback_manifest_count": fallback_manifest_count,
        }


# ---------------------------------------------------------------------------
# Helper functions
# ---------------------------------------------------------------------------


def normalize_bigquery_table_name(table_name: str | None) -> str | None:
    """Normalize a BigQuery fully qualified table name for comparisons."""
    if not table_name:
        return None

    normalized = table_name.strip().strip("`").lower()
    return normalized or None


def build_manifest_table_set(table_names: Sequence[str]) -> set[str]:
    """Normalize manifest-managed table names into a comparable set."""
    manifest_tables: set[str] = set()
    for table_name in table_names:
        normalized = normalize_bigquery_table_name(table_name)
        if normalized:
            manifest_tables.add(normalized)
    return manifest_tables


def classify_bigquery_job_workload(
    destination_table: str | None,
    referenced_tables: Sequence[str] | None,
    manifest_tables: Sequence[str] | set[str],
) -> str | None:
    """Classify a stored BigQuery job as build or consumption."""
    manifest_table_set = (
        manifest_tables
        if isinstance(manifest_tables, set)
        else build_manifest_table_set(manifest_tables)
    )
    if not manifest_table_set:
        return None

    normalized_destination = normalize_bigquery_table_name(destination_table)
    if normalized_destination and normalized_destination in manifest_table_set:
        return WORKLOAD_KIND_BUILD

    for referenced_table in referenced_tables or []:
        normalized_reference = normalize_bigquery_table_name(referenced_table)
        if normalized_reference and normalized_reference in manifest_table_set:
            return WORKLOAD_KIND_CONSUMPTION

    return None


def extract_dbt_tables(manifest_content: dict) -> list[str]:
    """Extract fully qualified table names from a dbt manifest.

    Parses the manifest's nodes section and extracts database.schema.name for
    all nodes where resource_type='model'. Handles missing fields gracefully.

    Args:
        manifest_content: Parsed dbt manifest JSON (dict with 'nodes' key)

    Returns:
        List of fully qualified table names (e.g., ["project.dataset.table", ...])
        Returns empty list if no models found or manifest is malformed.

    Example:
        >>> manifest = {"nodes": {
        ...     "model.my_project.customers": {
        ...         "resource_type": "model",
        ...         "database": "analytics",
        ...         "schema": "prod",
        ...         "name": "customers"
        ...     }
        ... }}
        >>> extract_dbt_tables(manifest)
        ['analytics.prod.customers']
    """
    dbt_tables = []

    nodes = manifest_content.get("nodes", {})
    if not isinstance(nodes, dict):
        logger.warning("Manifest 'nodes' is not a dict, returning empty table list")
        return []

    for node_key, node_value in nodes.items():
        if not isinstance(node_value, dict):
            logger.debug("Skipping non-dict node: %s", node_key)
            continue

        # Only extract models (skip tests, sources, snapshots, etc.)
        if node_value.get("resource_type") != "model":
            continue

        # Extract table components
        database = node_value.get("database")
        schema = node_value.get("schema")
        name = node_value.get("identifier") or node_value.get("name")

        # All three components required for valid table name
        if database and schema and name:
            full_table_name = f"{database}.{schema}.{name}"
            dbt_tables.append(full_table_name)
        else:
            logger.debug(
                "Skipping model %s with incomplete table info (database=%s, schema=%s, name=%s)",
                node_key,
                database,
                schema,
                name,
            )

    logger.info("Extracted %d dbt table names from manifest", len(dbt_tables))
    return dbt_tables


def sanitize_error_message(error_msg: str) -> str:
    """Remove sensitive information from error messages.

    Sanitizes error messages to prevent credential leakage in stored errors.
    Replaces sensitive patterns with [REDACTED] placeholder.

    Removes:
    - Password/secret/token/key parameters (e.g., password=abc123)
    - GCS URLs with query parameters (potential auth tokens)
    - Bearer tokens from Authorization headers
    - Connection strings with embedded credentials

    Args:
        error_msg: Raw error message string

    Returns:
        Sanitized error message with sensitive information replaced

    Specification Reference:
        FR-055: System MUST NOT expose sensitive information (credentials,
        secrets, tokens) in stored or displayed error messages.

    Example:
        >>> sanitize_error_message("Connection failed: password=secret123")
        'Connection failed: [REDACTED]'
    """
    patterns = [
        # Password/secret/token/key parameters
        (r"(?i)(password|secret|token|key|api_key|apikey)=[^&\s]+", r"\1=[REDACTED]"),
        # GCS URLs with query parameters (may contain auth tokens)
        (r"gs://[^/]+/[^?]*\?[^\s]+", "gs://[REDACTED]?[REDACTED]"),
        # Bearer tokens
        (r"Bearer [A-Za-z0-9\-._~+/]+=*", "Bearer [REDACTED]"),
        # Connection strings with user:pass format
        (r"://[^:]+:[^@]+@", "://[REDACTED]:[REDACTED]@"),
    ]

    sanitized = error_msg
    for pattern, replacement in patterns:
        sanitized = re.sub(pattern, replacement, sanitized)

    return sanitized
