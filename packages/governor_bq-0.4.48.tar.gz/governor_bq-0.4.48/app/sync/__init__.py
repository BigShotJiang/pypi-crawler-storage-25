"""
Project Data Sync module.

Handles on-demand synchronization of BigQuery job history and dbt manifest files
for configured projects.
"""
