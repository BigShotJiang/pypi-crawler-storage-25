"""
Pydantic schemas for Sync API responses.

Defines output schemas for sync operations, errors, jobs, and manifests.
"""

from __future__ import annotations

from datetime import datetime
from decimal import Decimal

from pydantic import BaseModel, ConfigDict


# ---------------------------------------------------------------------------
# Output schemas
# ---------------------------------------------------------------------------


class SyncErrorOut(BaseModel):
    """Output schema for sync error details."""

    id: str
    error_timestamp: datetime
    error_type: str
    error_message: str
    step_context: str
    related_entity_id: str | None

    model_config = ConfigDict(from_attributes=True)


class SyncOperationOut(BaseModel):
    """Output schema for full sync operation details with errors."""

    id: str
    config_id: str
    status: str
    queued_at: datetime
    started_at: datetime | None
    completed_at: datetime | None
    jobs_retrieved_count: int
    manifests_updated_count: int
    initiated_by_id: str
    errors: list[SyncErrorOut]

    model_config = ConfigDict(from_attributes=True)


class SyncOperationSummary(BaseModel):
    """Output schema for sync operation summary (used in lists)."""

    id: str
    config_id: str
    config_name: str
    status: str
    queued_at: datetime
    started_at: datetime | None
    completed_at: datetime | None
    duration_seconds: int | None

    model_config = ConfigDict(from_attributes=True)


class BigQueryJobOut(BaseModel):
    """Output schema for BigQuery job details."""

    id: str
    job_id: str
    user_email: str
    query: str | None
    creation_time: datetime
    start_time: datetime | None
    end_time: datetime | None
    duration_ms: int | None
    total_bytes_processed: int | None
    total_bytes_billed: int | None
    total_cost: Decimal | None
    job_state: str
    error_result: dict | None
    workload_kind: str | None

    model_config = ConfigDict(from_attributes=True)


class ManifestVersionOut(BaseModel):
    """Output schema for manifest version details."""

    id: str
    config_id: str
    content_hash: str
    retrieved_at: datetime

    model_config = ConfigDict(from_attributes=True)
