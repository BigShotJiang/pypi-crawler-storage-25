"""Governor application package."""

from app.google_sdk_compat import apply_google_sdk_py314_compat

apply_google_sdk_py314_compat()
