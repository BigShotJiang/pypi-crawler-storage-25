"""Extract the partition or cluster column affected by a dbt model diff.

Pure-function module — no DB access, no side effects.

Compares before/after SQL (dbt source with Jinja2) to detect whether a
partition_by or cluster_by config was added or changed, and returns the
affected column name and change type.
"""

from __future__ import annotations

import re

# Match partition_by={"field": "col_name", ...} inside {{ config(...) }}
_PARTITION_FIELD_RE = re.compile(
    r"""partition_by\s*=\s*\{[^{}]*['"]field['"]\s*:\s*['"](\w+)['"][^{}]*\}""",
    re.DOTALL | re.IGNORECASE,
)

# Match cluster_by=["col1", "col2"] inside {{ config(...) }}
_CLUSTER_BY_RE = re.compile(
    r"""cluster_by\s*=\s*\[([^\]]*)\]""",
    re.DOTALL | re.IGNORECASE,
)

# Fallback regex for partition field (looser, for non-standard formats)
_PARTITION_FIELD_FALLBACK_RE = re.compile(
    r"""partition_by.*?field.*?['"]([\w]+)['"]""",
    re.DOTALL | re.IGNORECASE,
)


def extract_affected_partition_cluster_column(
    before_sql: str,
    after_sql: str,
) -> tuple[str, str] | None:
    """Detect a partition or cluster column change between two dbt SQL files.

    Compares partition_by and cluster_by config blocks in the before and after
    SQL (which may contain Jinja2 templating). Returns (column_name, change_type)
    where change_type is 'partition' or 'cluster', or None if no relevant change
    is detected.

    Args:
        before_sql: Original dbt model SQL (with Jinja2 macros).
        after_sql: Modified dbt model SQL (with Jinja2 macros).

    Returns:
        A tuple (column_name, 'partition' | 'cluster'), or None.
    """
    try:
        return _detect_change(before_sql or "", after_sql or "")
    except (re.error, TypeError, AttributeError):
        return None


def _detect_change(before_sql: str, after_sql: str) -> tuple[str, str] | None:
    # --- Partition change ---
    before_partition = _extract_partition_column(before_sql)
    after_partition = _extract_partition_column(after_sql)

    if after_partition and after_partition != before_partition:
        return (after_partition, "partition")

    # --- Cluster change ---
    before_cluster_cols = _extract_cluster_columns(before_sql)
    after_cluster_cols = _extract_cluster_columns(after_sql)

    if after_cluster_cols:
        new_cols = [c for c in after_cluster_cols if c not in before_cluster_cols]
        if new_cols:
            # Return first newly added cluster column
            return (new_cols[0], "cluster")
        if not before_cluster_cols and after_cluster_cols:
            return (after_cluster_cols[0], "cluster")

    return None


def _extract_partition_column(sql: str) -> str | None:
    """Extract partition column name from dbt config in SQL."""
    if not sql:
        return None

    m = _PARTITION_FIELD_RE.search(sql)
    if m:
        return m.group(1).lower()

    # Fallback: looser regex
    m = _PARTITION_FIELD_FALLBACK_RE.search(sql)
    if m:
        return m.group(1).lower()

    return None


def _extract_cluster_columns(sql: str) -> list[str]:
    """Extract ordered list of cluster column names from dbt config in SQL."""
    if not sql:
        return []

    m = _CLUSTER_BY_RE.search(sql)
    if not m:
        return []

    columns_str = m.group(1)
    cols = re.findall(r"['\"](\w+)['\"]", columns_str)
    return [c.lower() for c in cols]
