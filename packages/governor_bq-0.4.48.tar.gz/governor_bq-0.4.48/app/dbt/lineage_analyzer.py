"""Lineage-aware upstream model analysis for solution generation.

Traverses the dbt manifest DAG to identify upstream models that should
receive clustering or partitioning config changes to fix downstream
join_explosion, shuffle_spill, or slot_contention issues.

Pure functions — operates on manifest dicts with no DB or API calls.
"""

from __future__ import annotations

import logging
from collections import deque
from collections.abc import Callable
from dataclasses import dataclass, field

import sqlglot
from sqlglot import exp
from sqlglot.errors import SqlglotError

from app.solutions.validation.jinja_strip import strip_jinja

logger = logging.getLogger("app.dbt.lineage_analyzer")

_MAX_CLUSTER_COLUMNS = 4  # BigQuery limit
_MATERIALIZABLE = frozenset({"table", "incremental"})


@dataclass
class UpstreamCandidate:
    """An upstream model eligible for config modification."""

    name: str
    unique_id: str
    original_file_path: str
    materialized: str
    current_cluster_by: list[str] | None
    current_partition_by: dict | None
    suggested_cluster_columns: list[str]
    reason: str
    column_quality: dict | None = None  # col_name → ColumnQuality dict


@dataclass
class LineageResult:
    """Result of upstream lineage analysis."""

    candidates: list[UpstreamCandidate] = field(default_factory=list)
    analysis_notes: list[str] = field(default_factory=list)


def analyze_upstream(
    manifest_content: dict,
    affected_model_name: str,
    opportunity_type: str,
    compiled_sql: str | None = None,
    max_depth: int = 2,
    column_lookup: Callable[[dict], set[str] | None] | None = None,
    column_quality_lookup: Callable[[dict, list[str]], dict | None] | None = None,
) -> LineageResult:
    """Traverse the manifest DAG and identify upstream fix candidates.

    Args:
        manifest_content: Parsed manifest.json dict.
        affected_model_name: The dbt model name where the issue was detected.
        opportunity_type: One of shuffle_spill, join_explosion, slot_contention.
        compiled_sql: Compiled SQL of the affected model (for column extraction).
        max_depth: Maximum DAG levels to traverse.
        column_lookup: Optional callable that takes a manifest node dict and
            returns a set of lowercase column names from INFORMATION_SCHEMA,
            or None if no data is available. Used to validate that suggested
            columns actually exist in the upstream BigQuery table.
        column_quality_lookup: Optional callable that takes a manifest node dict
            and a list of column names, profiles them in BigQuery, and returns
            a dict mapping column name → ColumnQuality object, or None if
            profiling is unavailable. Used to filter out poor-quality columns.

    Returns:
        LineageResult with ranked upstream candidates and analysis notes.
    """
    result = LineageResult()
    nodes = manifest_content.get("nodes", {})
    project_name = manifest_content.get("metadata", {}).get("project_name", "")

    # Find the affected model node
    target_node = _find_node_by_name(nodes, affected_model_name)
    if not target_node:
        result.analysis_notes.append(
            f"Model '{affected_model_name}' not found in manifest"
        )
        return result

    # Extract join/group-by columns from the affected model's compiled SQL
    relevant_columns = _extract_relevant_columns(compiled_sql, opportunity_type)
    if relevant_columns:
        result.analysis_notes.append(
            f"Extracted columns from compiled SQL: {relevant_columns}"
        )
    else:
        result.analysis_notes.append(
            "No columns extracted from compiled SQL — "
            "will suggest clustering based on upstream model columns"
        )

    # BFS traversal up the DAG
    visited: set[str] = set()
    queue: deque[tuple[str, int]] = deque()  # (unique_id, depth)

    target_unique_id = target_node.get("unique_id")
    if not target_unique_id:
        for node_key, node_data in nodes.items():
            if node_data is target_node:
                target_unique_id = node_key
                break

    if not target_unique_id:
        result.analysis_notes.append("Could not determine unique_id for target model")
        return result

    # Seed BFS with direct dependencies
    depends_on = target_node.get("depends_on", {})
    upstream_refs = depends_on.get("nodes", [])
    for ref_id in upstream_refs:
        if ref_id.startswith("model."):
            queue.append((ref_id, 1))

    while queue:
        node_id, depth = queue.popleft()

        if node_id in visited:
            continue
        visited.add(node_id)

        if depth > max_depth:
            continue

        node = nodes.get(node_id)
        if not node or not isinstance(node, dict):
            continue

        # Skip external packages
        node_pkg = node.get("package_name", "")
        if node_pkg and node_pkg != project_name:
            result.analysis_notes.append(
                f"Skipping {node.get('name', node_id)}: external package '{node_pkg}'"
            )
            continue

        config = node.get("config", {})
        materialized = config.get("materialized", "")

        # If this node is ephemeral or view, traverse deeper
        if materialized not in _MATERIALIZABLE:
            parent_deps = node.get("depends_on", {}).get("nodes", [])
            for parent_id in parent_deps:
                if parent_id.startswith("model.") and parent_id not in visited:
                    queue.append((parent_id, depth + 1))
            result.analysis_notes.append(
                f"Skipping {node.get('name', node_id)}: "
                f"materialized='{materialized}' (not table/incremental), "
                f"traversing deeper"
            )
            continue

        # This is a materialized upstream model — check if it needs clustering
        existing_cluster = config.get("cluster_by")
        if isinstance(existing_cluster, str):
            existing_cluster = [existing_cluster]
        existing_cluster = existing_cluster or []

        file_path = node.get("original_file_path")
        if not file_path:
            continue

        # Resolve real columns from INFORMATION_SCHEMA if lookup available
        real_columns: set[str] | None = None
        if column_lookup is not None:
            try:
                real_columns = column_lookup(node)
            except (KeyError, ValueError, TypeError):
                logger.debug(
                    "Column lookup failed for %s, falling back to manifest",
                    node.get("name", node_id),
                )

        # Determine which columns to suggest
        suggested = _suggest_cluster_columns(
            relevant_columns,
            existing_cluster,
            node,
            opportunity_type,
            valid_columns=real_columns,
        )

        if not suggested:
            result.analysis_notes.append(
                f"Skipping {node.get('name', node_id)}: "
                f"already clustered on all relevant columns or no columns to suggest"
            )
            continue

        # Check BigQuery 4-column limit
        total_after = len(existing_cluster) + len(suggested)
        if total_after > _MAX_CLUSTER_COLUMNS:
            suggested = suggested[: _MAX_CLUSTER_COLUMNS - len(existing_cluster)]
            if not suggested:
                result.analysis_notes.append(
                    f"Skipping {node.get('name', node_id)}: "
                    f"already has {len(existing_cluster)} cluster columns (max 4)"
                )
                continue

        # Profile column quality if lookup is available (spec 065)
        quality_data: dict | None = None
        if column_quality_lookup is not None:
            try:
                quality_data = column_quality_lookup(node, suggested)
            except (KeyError, ValueError, TypeError):
                logger.debug(
                    "Column quality lookup failed for %s, skipping quality filter",
                    node.get("name", node_id),
                )

        # Filter out poor-quality columns from cluster_by suggestions
        if quality_data:
            good_columns = []
            for col in suggested:
                cq = quality_data.get(col)
                if cq is None:
                    good_columns.append(col)  # No data = keep
                    continue
                classification = getattr(cq, "classification", "good")
                if classification == "poor":
                    reason_text = getattr(cq, "reason", "poor quality")
                    result.analysis_notes.append(
                        f"Column '{col}' on {node.get('name', node_id)} "
                        f"excluded from cluster_by: {reason_text}"
                    )
                else:
                    good_columns.append(col)
            suggested = good_columns

        if not suggested:
            result.analysis_notes.append(
                f"Skipping {node.get('name', node_id)}: "
                f"all suggested columns have poor quality "
                f"(high NULL ratio or low cardinality)"
            )
            # Still add as candidate with empty suggestions so ADK can
            # suggest root-cause fixes (NULL filters, alternative join keys)
            if quality_data:
                result.candidates.append(
                    UpstreamCandidate(
                        name=node.get("name", ""),
                        unique_id=node_id,
                        original_file_path=file_path,
                        materialized=materialized,
                        current_cluster_by=existing_cluster or None,
                        current_partition_by=config.get("partition_by"),
                        suggested_cluster_columns=[],
                        reason=_build_quality_reason(
                            opportunity_type,
                            affected_model_name,
                            node.get("name", ""),
                            quality_data,
                        ),
                        column_quality={
                            col: _quality_to_dict(cq)
                            for col, cq in quality_data.items()
                        },
                    )
                )
            continue

        reason = _build_reason(
            opportunity_type, affected_model_name, node.get("name", ""), suggested
        )

        result.candidates.append(
            UpstreamCandidate(
                name=node.get("name", ""),
                unique_id=node_id,
                original_file_path=file_path,
                materialized=materialized,
                current_cluster_by=existing_cluster or None,
                current_partition_by=config.get("partition_by"),
                suggested_cluster_columns=suggested,
                reason=reason,
                column_quality=(
                    {col: _quality_to_dict(cq) for col, cq in quality_data.items()}
                    if quality_data
                    else None
                ),
            )
        )

    # Rank candidates: direct dependencies first, table > incremental,
    # fewer existing cluster columns preferred
    result.candidates.sort(
        key=lambda c: (
            # Direct dependency first (depth 1 = node in upstream_refs)
            0 if c.unique_id in upstream_refs else 1,
            # table preferred over incremental
            0 if c.materialized == "table" else 1,
            # Fewer existing cluster columns = more room
            len(c.current_cluster_by or []),
        )
    )

    return result


def _find_node_by_name(nodes: dict, model_name: str) -> dict | None:
    """Find a manifest node by dbt model name."""
    for node_data in nodes.values():
        if isinstance(node_data, dict) and node_data.get("name") == model_name:
            return node_data
    return None


def _extract_relevant_columns(
    compiled_sql: str | None,
    opportunity_type: str,
) -> list[str]:
    """Extract columns relevant to the opportunity type from compiled SQL.

    For join_explosion: extract JOIN ON columns.
    For shuffle_spill: extract JOIN ON + GROUP BY columns.
    For slot_contention: extract JOIN ON + GROUP BY columns.
    """
    if not compiled_sql:
        return []

    strip_result = strip_jinja(compiled_sql)
    if not strip_result.success:
        # Try anyway — compiled SQL usually has no Jinja
        pass

    sql_to_parse = strip_result.sql if strip_result.sql else compiled_sql

    try:
        ast = sqlglot.parse_one(sql_to_parse, dialect="bigquery")
    except SqlglotError:
        logger.debug("Failed to parse compiled SQL for column extraction")
        return []

    columns: list[str] = []
    seen: set[str] = set()

    # Extract JOIN ON columns (relevant for all three types)
    for join in ast.find_all(exp.Join):
        on_clause = join.args.get("on")
        if on_clause is None:
            continue
        for col in on_clause.find_all(exp.Column):
            name = col.name
            if name and name not in seen:
                seen.add(name)
                columns.append(name)

    # For shuffle_spill and slot_contention, also extract GROUP BY columns
    if opportunity_type in ("shuffle_spill", "slot_contention"):
        for group in ast.find_all(exp.Group):
            for col in group.find_all(exp.Column):
                name = col.name
                if name and name not in seen:
                    seen.add(name)
                    columns.append(name)

    return columns[:_MAX_CLUSTER_COLUMNS]


def _suggest_cluster_columns(
    relevant_columns: list[str],
    existing_cluster: list[str],
    upstream_node: dict,
    opportunity_type: str,
    valid_columns: set[str] | None = None,
) -> list[str]:
    """Determine which columns to suggest for clustering on the upstream model.

    Filters relevant_columns to those that actually exist in the upstream
    model's BigQuery table. Uses INFORMATION_SCHEMA column data (valid_columns)
    as the authoritative source; falls back to manifest columns dict if
    INFORMATION_SCHEMA data is not available.

    Args:
        relevant_columns: Columns extracted from downstream SQL (JOIN/GROUP BY).
        existing_cluster: Columns already in cluster_by config.
        upstream_node: Manifest node dict for the upstream model.
        opportunity_type: One of shuffle_spill, join_explosion, slot_contention.
        valid_columns: Set of lowercase column names from INFORMATION_SCHEMA.COLUMNS,
            or None if not available. This is the authoritative source for
            validating that columns actually exist in the BigQuery table.
    """
    # Determine which column set to validate against:
    # Priority 1: INFORMATION_SCHEMA columns (authoritative, handles SELECT *)
    # Priority 2: Manifest columns dict (only if devs wrote schema.yml)
    # Priority 3: No validation (pass through)
    known_columns: set[str] | None = valid_columns

    if known_columns is None:
        # Fall back to manifest columns dict
        upstream_columns = upstream_node.get("columns", {})
        if upstream_columns and isinstance(upstream_columns, dict):
            known_columns = {
                col_data.get("name", key).lower()
                for key, col_data in upstream_columns.items()
                if isinstance(col_data, dict)
            }

    # Filter relevant columns to those in the upstream model
    suggested: list[str] = []
    existing_lower = {c.lower() for c in existing_cluster}
    filtered_out: list[str] = []

    for col in relevant_columns:
        if col.lower() in existing_lower:
            continue  # Already clustered on this column

        # Validate the column exists if we have column data
        if known_columns is not None and col.lower() not in known_columns:
            filtered_out.append(col)
            continue

        suggested.append(col)

    if filtered_out:
        logger.debug(
            "Filtered out columns not found in upstream model '%s': %s",
            upstream_node.get("name", "unknown"),
            filtered_out,
        )

    # If we couldn't match any columns from compiled SQL and
    # the upstream has no clustering at all, try the upstream's own
    # compiled SQL to find commonly used columns
    if not suggested and not existing_cluster and not relevant_columns:
        upstream_compiled = upstream_node.get("compiled_code")
        if upstream_compiled:
            upstream_cols = _extract_relevant_columns(
                upstream_compiled, opportunity_type
            )
            # Also validate these against known columns
            if known_columns is not None:
                upstream_cols = [c for c in upstream_cols if c.lower() in known_columns]
            suggested = upstream_cols[:_MAX_CLUSTER_COLUMNS]

    return suggested[:_MAX_CLUSTER_COLUMNS]


def _build_reason(
    opportunity_type: str,
    affected_model: str,
    upstream_model: str,
    columns: list[str],
) -> str:
    """Build a human-readable reason for the upstream fix."""
    col_list = ", ".join(columns)

    if opportunity_type == "join_explosion":
        return (
            f"Model '{affected_model}' experiences join explosion when "
            f"joining data from '{upstream_model}'. Clustering '{upstream_model}' "
            f"by [{col_list}] will co-locate rows with the same join key values, "
            f"reducing data shuffling and join multiplication."
        )
    elif opportunity_type == "shuffle_spill":
        return (
            f"Model '{affected_model}' experiences shuffle spill when processing "
            f"data from '{upstream_model}'. Clustering '{upstream_model}' "
            f"by [{col_list}] will co-locate related rows, reducing the volume "
            f"of data shuffled across BigQuery slots."
        )
    else:  # slot_contention
        return (
            f"Model '{affected_model}' experiences slot contention when processing "
            f"data from '{upstream_model}'. Clustering '{upstream_model}' "
            f"by [{col_list}] will improve data locality and reduce slot usage."
        )


def _build_quality_reason(
    opportunity_type: str,
    affected_model: str,
    upstream_model: str,
    quality_data: dict,
) -> str:
    """Build a reason string when all columns have poor quality."""
    issues = []
    for col_name, cq in quality_data.items():
        reason = getattr(cq, "reason", "poor quality")
        issues.append(f"  - {col_name}: {reason}")
    issue_list = "\n".join(issues)

    return (
        f"Model '{affected_model}' experiences {opportunity_type} when joining "
        f"data from '{upstream_model}', but the join key columns have poor data "
        f"quality — clustering won't help:\n{issue_list}\n"
        f"Consider filtering NULLs before the join or using higher-cardinality "
        f"join keys."
    )


def _quality_to_dict(cq) -> dict:
    """Convert a ColumnQuality dataclass to a plain dict for serialisation."""
    if hasattr(cq, "__dataclass_fields__"):
        from dataclasses import asdict

        return asdict(cq)
    if isinstance(cq, dict):
        return cq
    return {"classification": "unknown"}
