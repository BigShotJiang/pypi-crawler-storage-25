"""dbt profiles.yml generation for Docker-based compile and parse.

Generates real BQ credentials profiles for compile, or stub profiles for parse.
"""

from __future__ import annotations

import logging
import tempfile
from pathlib import Path

import yaml

logger = logging.getLogger("app.dbt.profiles")


class ProfilesGenerator:
    """Generate profiles.yml files for dbt Docker operations."""

    @staticmethod
    def generate_compile_profiles(
        profile_name: str,
        gcp_project: str,
        dataset: str,
        keyfile_path: str | None = None,
    ) -> str:
        """Create a temp directory containing profiles.yml with real BQ credentials.

        Returns absolute path to the temp directory.
        Caller is responsible for cleanup (tempfile.mkdtemp pattern).

        If keyfile_path is not provided, reads from GOOGLE_APPLICATION_CREDENTIALS
        environment variable.
        """
        import os

        if keyfile_path is None:
            keyfile_path = os.environ.get("GOOGLE_APPLICATION_CREDENTIALS", "")

        profiles = {
            profile_name: {
                "target": "governor",
                "outputs": {
                    "governor": {
                        "type": "bigquery",
                        "method": "service-account",
                        "keyfile": keyfile_path,
                        "project": gcp_project,
                        "dataset": dataset,
                        "threads": 1,
                    }
                },
            }
        }

        tmpdir = tempfile.mkdtemp(prefix="governor-dbt-profiles-")
        profiles_path = Path(tmpdir) / "profiles.yml"
        profiles_path.write_text(yaml.dump(profiles, default_flow_style=False))

        return tmpdir

    @staticmethod
    def generate_parse_profiles(
        profile_name: str,
    ) -> str:
        """Create a temp directory containing stub profiles.yml (fake credentials).

        Returns absolute path to the temp directory.
        Parse never connects to BigQuery, so credentials are not needed.
        """
        profiles = {
            profile_name: {
                "target": "governor",
                "outputs": {
                    "governor": {
                        "type": "bigquery",
                        "method": "oauth",
                        "project": "stub-project",
                        "dataset": "stub_dataset",
                        "threads": 1,
                    }
                },
            }
        }

        tmpdir = tempfile.mkdtemp(prefix="governor-dbt-profiles-")
        profiles_path = Path(tmpdir) / "profiles.yml"
        profiles_path.write_text(yaml.dump(profiles, default_flow_style=False))

        return tmpdir

    @staticmethod
    def extract_profile_name(dbt_project_yml_content: str) -> str:
        """Parse dbt_project.yml YAML content and return the 'profile' key value.

        Raises ValueError if 'profile' key is not found.
        """
        parsed = yaml.safe_load(dbt_project_yml_content)
        if not isinstance(parsed, dict):
            raise ValueError("dbt_project.yml is not a valid YAML mapping")

        profile_name = parsed.get("profile")
        if not profile_name:
            raise ValueError("'profile' key not found in dbt_project.yml")

        return str(profile_name)
