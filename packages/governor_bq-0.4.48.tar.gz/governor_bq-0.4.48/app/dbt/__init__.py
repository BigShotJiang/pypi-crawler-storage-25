"""dbt project integration module.

Provides uv venv-based dbt compile/parse, context enrichment from GCS manifest,
and profiles.yml generation for solution generation pipeline.
"""
