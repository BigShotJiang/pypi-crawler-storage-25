"""Build enriched LLM context from GCS manifest and BigQuery jobs.

Extracts compiled SQL, upstream models, downstream dependents, macro summaries,
and job samples to provide richer context for solution generation.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field

from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.orm import Session

logger = logging.getLogger("app.dbt.context_builder")

_UPSTREAM_SQL_MAX_BYTES = 50 * 1024  # 50KB cap for upstream SQL
_MAX_MACROS = 50
_MAX_JOB_SAMPLES = 2


@dataclass
class UpstreamModel:
    """Context for a direct parent model."""

    name: str
    unique_id: str
    raw_sql: str | None = None
    compiled_sql: str | None = None
    materialized: str | None = None
    partition_by: dict | None = None
    cluster_by: list[str] | None = None
    columns: dict | None = None


@dataclass
class DownstreamDependent:
    """Minimal info about a consumer of the target model."""

    name: str
    unique_id: str
    materialized: str | None = None
    partition_by: dict | None = None
    cluster_by: list[str] | None = None


@dataclass
class MacroSummary:
    """Summary of a project-local macro."""

    name: str
    package_name: str
    arguments: list[str] = field(default_factory=list)


@dataclass
class EnrichedContext:
    """Top-level container for all enriched LLM context."""

    compiled_sql: str | None = None
    upstream_models: list[UpstreamModel] = field(default_factory=list)
    downstream_dependents: list[DownstreamDependent] = field(default_factory=list)
    macro_summary: list[MacroSummary] = field(default_factory=list)
    job_samples: list[dict] = field(default_factory=list)
    dry_run_baseline: dict | None = None


def build_enriched_context(
    db: Session,
    manifest_version_id: str | None,
    dbt_model_name: str | None,
    config_id: str | None,
    gcp_project: str | None,
) -> EnrichedContext:
    """Extract enriched context from the GCS-synced manifest.

    Returns EnrichedContext with all fields populated from GCS manifest + BigQuery jobs.
    Never raises — returns empty/None fields on failure.
    """
    context = EnrichedContext()

    if not manifest_version_id or not dbt_model_name:
        return context

    try:
        manifest_content = _load_manifest(db, manifest_version_id)
        if not manifest_content:
            return context

        nodes = manifest_content.get("nodes", {})
        target_node = _find_target_node(nodes, dbt_model_name)

        if target_node:
            context.compiled_sql = _extract_compiled_sql(target_node)
            context.upstream_models = _extract_upstream_models(
                nodes, target_node, manifest_content
            )
            context.downstream_dependents = _extract_downstream_dependents(
                nodes, target_node, manifest_content
            )

        # Extract macro summary from manifest
        context.macro_summary = _extract_macro_summary(manifest_content)

        # Extract job samples from BigQuery jobs table
        if config_id:
            context.job_samples = _extract_job_samples(db, config_id, dbt_model_name)

    except (SQLAlchemyError, KeyError, TypeError) as exc:
        logger.warning("Failed to build enriched context: %s", exc)

    return context


def _load_manifest(db: Session, manifest_version_id: str) -> dict | None:
    """Load manifest content from the database."""
    from app.sync.models import ManifestVersion

    mv = (
        db.query(ManifestVersion)
        .filter(ManifestVersion.id == manifest_version_id)
        .one_or_none()
    )
    if not mv or not mv.content:
        return None
    return mv.content


def _find_target_node(nodes: dict, dbt_model_name: str) -> dict | None:
    """Find the manifest node matching the dbt model name."""
    for node_key, node_data in nodes.items():
        if not isinstance(node_data, dict):
            continue
        if node_data.get("name") == dbt_model_name:
            return node_data
    return None


def _extract_compiled_sql(target_node: dict) -> str | None:
    """Extract compiled_code from the target node."""
    return target_node.get("compiled_code")


def _extract_upstream_models(
    nodes: dict,
    target_node: dict,
    manifest_content: dict,
) -> list[UpstreamModel]:
    """Extract direct upstream models (1 level of depends_on.nodes).

    Enforces 50KB total cap on upstream SQL content.
    """
    depends_on = target_node.get("depends_on", {})
    upstream_refs = depends_on.get("nodes", [])

    upstreams: list[UpstreamModel] = []
    total_sql_bytes = 0

    for ref_id in upstream_refs:
        # Only include model nodes (not sources, seeds, etc.)
        if not ref_id.startswith("model."):
            continue

        node = nodes.get(ref_id)
        if not node or not isinstance(node, dict):
            continue

        config = node.get("config", {})
        raw_sql = node.get("raw_code") or node.get("raw_sql")
        compiled_sql = node.get("compiled_code")

        # Check SQL size cap
        raw_size = len(raw_sql.encode("utf-8")) if raw_sql else 0
        compiled_size = len(compiled_sql.encode("utf-8")) if compiled_sql else 0

        if total_sql_bytes + raw_size + compiled_size > _UPSTREAM_SQL_MAX_BYTES:
            # Truncate: omit SQL but still include model metadata
            remaining = len(upstream_refs) - len(upstreams)
            logger.info(
                "Upstream SQL cap reached (50KB), omitting SQL for remaining %d models",
                remaining,
            )
            upstreams.append(
                UpstreamModel(
                    name=node.get("name", ""),
                    unique_id=ref_id,
                    raw_sql=None,
                    compiled_sql=None,
                    materialized=config.get("materialized"),
                    partition_by=config.get("partition_by"),
                    cluster_by=config.get("cluster_by"),
                    columns=node.get("columns"),
                )
            )
            break

        total_sql_bytes += raw_size + compiled_size

        upstreams.append(
            UpstreamModel(
                name=node.get("name", ""),
                unique_id=ref_id,
                raw_sql=raw_sql,
                compiled_sql=compiled_sql,
                materialized=config.get("materialized"),
                partition_by=config.get("partition_by"),
                cluster_by=config.get("cluster_by"),
                columns=node.get("columns"),
            )
        )

    return upstreams


def _extract_downstream_dependents(
    nodes: dict,
    target_node: dict,
    manifest_content: dict,
) -> list[DownstreamDependent]:
    """Reverse the manifest's parent_map to find child models.

    Returns names + configs only (no SQL) to keep prompt manageable.
    """
    target_unique_id = target_node.get("unique_id")
    if not target_unique_id:
        # Try to find it from nodes dict
        for node_key, node_data in nodes.items():
            if node_data is target_node:
                target_unique_id = node_key
                break

    if not target_unique_id:
        return []

    # Build child_map by reversing parent references
    dependents: list[DownstreamDependent] = []

    # Check child_map if available in manifest
    child_map = manifest_content.get("child_map", {})
    if child_map and target_unique_id in child_map:
        children = child_map[target_unique_id]
        for child_id in children:
            if not child_id.startswith("model."):
                continue
            node = nodes.get(child_id)
            if not node or not isinstance(node, dict):
                continue
            config = node.get("config", {})
            dependents.append(
                DownstreamDependent(
                    name=node.get("name", ""),
                    unique_id=child_id,
                    materialized=config.get("materialized"),
                    partition_by=config.get("partition_by"),
                    cluster_by=config.get("cluster_by"),
                )
            )
        return dependents

    # Fallback: scan all nodes for depends_on references to target
    for node_key, node_data in nodes.items():
        if not isinstance(node_data, dict):
            continue
        if not node_key.startswith("model."):
            continue
        deps = node_data.get("depends_on", {}).get("nodes", [])
        if target_unique_id in deps:
            config = node_data.get("config", {})
            dependents.append(
                DownstreamDependent(
                    name=node_data.get("name", ""),
                    unique_id=node_key,
                    materialized=config.get("materialized"),
                    partition_by=config.get("partition_by"),
                    cluster_by=config.get("cluster_by"),
                )
            )

    return dependents


def _extract_macro_summary(manifest_content: dict) -> list[MacroSummary]:
    """Extract project-local macro summaries from manifest.

    Filters by package_name matching the project name (excludes dbt-core, dbt-utils, etc.).
    Sorted alphabetically, limited to 50 entries.
    """
    macros = manifest_content.get("macros", {})
    if not macros:
        return []

    # Determine the project name from metadata
    metadata = manifest_content.get("metadata", {})
    project_name = metadata.get("project_name") or metadata.get("project_id")

    # If no project_name in metadata, try to infer from dbt_project.yml in nodes
    if not project_name:
        # Look at the first node to get package_name
        nodes = manifest_content.get("nodes", {})
        for node_data in nodes.values():
            if isinstance(node_data, dict) and node_data.get("package_name"):
                project_name = node_data["package_name"]
                break

    if not project_name:
        return []

    summaries: list[MacroSummary] = []
    for macro_key, macro_data in macros.items():
        if not isinstance(macro_data, dict):
            continue

        pkg = macro_data.get("package_name", "")
        if pkg != project_name:
            continue

        # Extract argument names
        arguments: list[str] = []
        macro_args = macro_data.get("arguments", [])
        for arg in macro_args:
            if isinstance(arg, dict):
                arg_name = arg.get("name", "")
                if arg_name:
                    arguments.append(arg_name)
            elif isinstance(arg, str):
                arguments.append(arg)

        summaries.append(
            MacroSummary(
                name=macro_data.get("name", ""),
                package_name=pkg,
                arguments=arguments,
            )
        )

    # Sort alphabetically and limit
    summaries.sort(key=lambda m: m.name)
    return summaries[:_MAX_MACROS]


def _extract_job_samples(
    db: Session,
    config_id: str,
    dbt_model_name: str,
) -> list[dict]:
    """Query representative BigQuery jobs for the target model.

    Uses config_id to scope to the right project and filters by
    destination_table containing the model name.
    """
    from app.sync.models import BigQueryJob

    try:
        # Query jobs associated with this config, filtering by destination_table
        # that matches the model name pattern
        jobs = (
            db.query(BigQueryJob)
            .filter(
                BigQueryJob.config_id == config_id,
                BigQueryJob.destination_table.ilike(f"%{dbt_model_name}%"),
                BigQueryJob.job_state == "DONE",
            )
            .order_by(BigQueryJob.creation_time.desc())
            .limit(_MAX_JOB_SAMPLES)
            .all()
        )

        return [
            {
                "total_bytes_processed": j.total_bytes_processed,
                "total_slot_ms": j.total_slot_ms,
                "query_cost": float(j.total_cost) if j.total_cost else None,
                "creation_time": j.creation_time.isoformat()
                if j.creation_time
                else None,
                "cache_hit": j.cache_hit,
            }
            for j in jobs
        ]
    except SQLAlchemyError as exc:
        logger.warning("Failed to extract job samples: %s", exc)
        return []
