from __future__ import annotations

from sqlalchemy.orm import DeclarativeBase


class Base(DeclarativeBase):
    pass


# Import all models so Base.metadata is complete for table creation.
# This ensures Alembic autogenerate and test fixtures see every table.
def _import_all_models() -> None:
    from app.auth import models as _auth  # noqa: F401
    from app.configurations import models as _cfg  # noqa: F401
    from app.opportunities import models as _opp  # noqa: F401
    from app.pullrequests import models as _pr  # noqa: F401
    from app.solutions import models as _sol  # noqa: F401
    from app.settings import models as _settings  # noqa: F401
    from app.sync import models as _sync  # noqa: F401
    from app.verification import models as _verify  # noqa: F401
    from app.setup import models as _setup  # noqa: F401


_import_all_models()
