from __future__ import annotations

import logging

from fastapi import APIRouter, Depends, Request
from fastapi.responses import JSONResponse, RedirectResponse
from sqlalchemy.orm import Session
from starlette.responses import Response

from app.auth.dependencies import get_current_user, require_role
from app.auth.models import User
from app.db.session import get_session
from app.verification.runner import compute_overall_status, run_all_checks
from app.verification.schemas import SystemStatus
from app.verification.service import VerificationService

logger = logging.getLogger("app.verification")

router = APIRouter()


# ---------------------------------------------------------------------------
# 301 Redirects: Old admin verification URLs → new settings URLs
# ---------------------------------------------------------------------------


@router.get("/admin/verification")
def verification_dashboard_redirect(request: Request) -> RedirectResponse:
    return RedirectResponse("/settings/verification", status_code=301)


@router.post("/admin/verification/run")
def verification_run_redirect(request: Request) -> RedirectResponse:
    return RedirectResponse("/settings/verification/run", status_code=308)


@router.get("/admin/verification/history")
def verification_history_redirect(request: Request) -> RedirectResponse:
    return RedirectResponse("/settings/verification", status_code=301)


@router.get("/admin/verification/run/{run_id}")
def verification_run_detail_redirect(run_id: str, request: Request) -> RedirectResponse:
    return RedirectResponse(f"/settings/verification/run/{run_id}", status_code=301)


# ---------------------------------------------------------------------------
# JSON API routes (unchanged)
# ---------------------------------------------------------------------------


@router.post("/api/verification/run", response_class=JSONResponse)
def run_verification_api(
    user: User = Depends(require_role("admin")),
    db: Session = Depends(get_session),
) -> dict:
    service = VerificationService(db)
    run = service.create_run(admin_user_id=user.id, environment="production")

    results = run_all_checks()
    for result in results:
        service.save_check_result(run, result)

    overall = compute_overall_status(results)
    service.complete_run(run, overall)
    db.refresh(run)

    return service.run_to_result(run).model_dump(mode="json")


@router.get("/api/verification/status", response_class=JSONResponse)
def verification_status(
    user: User = Depends(get_current_user),
    db: Session = Depends(get_session),
) -> dict:
    service = VerificationService(db)
    status: SystemStatus = service.get_system_status()
    return status.model_dump(mode="json")
