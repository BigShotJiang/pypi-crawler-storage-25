from __future__ import annotations

import json
import logging
import re
from datetime import timezone

from fastapi import APIRouter, Depends, Form, Request, UploadFile, status
from fastapi.responses import HTMLResponse, RedirectResponse
from google.cloud.exceptions import GoogleCloudError
from sqlalchemy.orm import Session
from starlette.responses import Response

from app.auth import hashing
from app.auth.models import Role, User, UserRole
from app.auth.service import AuthService
from app.core.config import get_settings
from app.db.session import get_session
from app.setup.service import SetupService

router = APIRouter()
logger = logging.getLogger("app.setup")

_BIGQUERY_REGIONS = [
    "us",
    "eu",
    "us-central1",
    "us-east1",
    "us-east4",
    "us-west1",
    "us-west2",
    "us-west3",
    "us-west4",
    "northamerica-northeast1",
    "northamerica-northeast2",
    "southamerica-east1",
    "europe-north1",
    "europe-west1",
    "europe-west2",
    "europe-west3",
    "europe-west4",
    "europe-west6",
    "europe-central2",
    "asia-east1",
    "asia-east2",
    "asia-northeast1",
    "asia-northeast2",
    "asia-northeast3",
    "asia-south1",
    "asia-south2",
    "asia-southeast1",
    "asia-southeast2",
    "australia-southeast1",
    "australia-southeast2",
]


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _templates(request: Request) -> object:
    return request.app.state.templates


def _redirect_step(step: int) -> RedirectResponse:
    return RedirectResponse(url=f"/setup/{step}", status_code=status.HTTP_302_FOUND)


def _is_setup_complete(request: Request) -> bool:
    return getattr(request.app.state, "setup_complete", False)


def _get_step_reached(db: Session) -> int:
    state = SetupService(db).get_state()
    return state.step_reached if state else 1


def _step_context(step: int, state=None) -> dict:
    from app.core.config import is_local_mode

    local_mode = is_local_mode()

    if local_mode:
        steps = [
            "GCP Credentials",
            "LLM API Key",
        ]
        total = 2
    else:
        steps = [
            "Admin Account",
            "GCP Credentials",
            "BigQuery Region",
            "GitHub App",
            "LLM API Key",
            "GCS Bucket",
        ]
        total = 6

    # In local mode, steps 1 (admin) and 3 (region) are skipped.
    # URL steps 2 and 5 map to display steps 1 and 2.
    if local_mode:
        step_map = {2: 1, 5: 2}
        display_step = step_map.get(step, step)
    else:
        display_step = step

    return {
        "current_step": display_step,
        "step_labels": steps,
        "total_steps": total,
        "show_sidebar": False,
        "state": state,
        "local_mode": local_mode,
    }


# ---------------------------------------------------------------------------
# GET /setup/2/detect-sa — return the ADC service account email (for UI display)
# ---------------------------------------------------------------------------


@router.get("/setup/2/detect-sa")
def setup_detect_sa(request: Request) -> Response:
    """Return the service account email the runtime ADC will use.

    Called by the step 2 UI when the user selects Workload Identity mode.
    """
    from fastapi.responses import JSONResponse

    try:
        import google.auth
        import google.auth.exceptions
        import google.auth.transport.requests

        credentials, _ = google.auth.default(
            scopes=["https://www.googleapis.com/auth/cloud-platform"]
        )
        # service_account_email is populated after a token refresh on GCE/Cloud Run
        if not getattr(credentials, "service_account_email", None):
            credentials.refresh(google.auth.transport.requests.Request())
        email = getattr(credentials, "service_account_email", None)
        return JSONResponse({"email": email or "unknown"})
    except (ValueError, google.auth.exceptions.GoogleAuthError) as exc:
        return JSONResponse({"email": None, "error": str(exc)})


# ---------------------------------------------------------------------------
# GET /setup/complete — must be before /setup/{step} to avoid int parse error
# ---------------------------------------------------------------------------


@router.get("/setup/complete", response_class=HTMLResponse)
def setup_complete_get(
    request: Request,
    db: Session = Depends(get_session),
) -> Response:
    if _is_setup_complete(request):
        return RedirectResponse(url="/login", status_code=status.HTTP_302_FOUND)

    svc = SetupService(db)
    state = svc.get_state()
    if state is None or state.step_reached < 7:
        return _redirect_step(state.step_reached if state else 1)

    ctx = {
        **_step_context(7),
        "state": state,
    }
    return _templates(request).TemplateResponse(request, "setup/complete.html", ctx)


# ---------------------------------------------------------------------------
# GET /setup/{step}
# ---------------------------------------------------------------------------


@router.get("/setup/{step}", response_class=HTMLResponse)
def setup_step_get(
    step: int,
    request: Request,
    db: Session = Depends(get_session),
) -> Response:
    from app.core.config import is_local_mode

    # setup_complete is enforced by middleware; this is a safety guard
    if _is_setup_complete(request):
        return RedirectResponse(url="/login", status_code=status.HTTP_302_FOUND)

    svc = SetupService(db)
    state = svc.get_state()
    step_reached = state.step_reached if state else 1
    local_mode = is_local_mode()

    # No state yet: only step 1 is reachable
    if state is None and step != 1:
        return _redirect_step(1)

    # Step 4 is removed from the local setup flow. If an older local setup state
    # still points there, advance it past the deprecated GitHub step.
    if local_mode and step == 4 and state is not None:
        if step_reached < 5:
            state = svc.skip_step4()
            step_reached = state.step_reached
        return _redirect_step(5)

    # Prevent skipping ahead
    if step > step_reached:
        return _redirect_step(step_reached)

    ctx = _step_context(step, state)
    templates = _templates(request)
    return templates.TemplateResponse(request, f"setup/step{step}.html", ctx)


# ---------------------------------------------------------------------------
# POST /setup/1 — Create admin account
# ---------------------------------------------------------------------------


@router.post("/setup/1", response_class=HTMLResponse)
def setup_step1_post(
    request: Request,
    email: str = Form(...),
    password: str = Form(""),
    password_confirm: str = Form(""),
    db: Session = Depends(get_session),
) -> Response:
    if _is_setup_complete(request):
        return RedirectResponse(url="/login", status_code=status.HTTP_302_FOUND)

    errors: dict[str, str] = {}

    email = email.strip().lower()
    if not re.match(r"^[^@\s]+@[^@\s]+\.[^@\s]+$", email):
        errors["email"] = "Enter a valid email address."

    if len(password) < 8:
        errors["password"] = "Password must be at least 8 characters."
    elif password != password_confirm:
        errors["password_confirm"] = "Passwords do not match."

    # Check if account already exists with this email
    existing_user = db.query(User).filter(User.email == email).one_or_none()
    if existing_user and not errors.get("email"):
        errors["email"] = "An account with this email already exists."

    if errors:
        ctx = {
            **_step_context(1),
            "errors": errors,
            "email": email,
        }
        return _templates(request).TemplateResponse(
            request, "setup/step1.html", ctx, status_code=422
        )

    # Create admin role if needed
    role = db.query(Role).filter(Role.name == "admin").one_or_none()
    if role is None:
        role = Role(name="admin")
        db.add(role)
        db.flush()

    # Create user
    user = User(
        email=email,
        display_name="Admin",
        password_hash=hashing.hash_password(password),
        status="active",
    )
    db.add(user)
    db.flush()

    user_role = UserRole(user_id=user.id, role_id=role.id)
    db.add(user_role)
    db.commit()
    db.refresh(user)

    # Check if setup_state already exists (concurrent attempt)
    svc = SetupService(db)
    if svc.get_state() is None:
        svc.create_step1(admin_user_id=user.id)
    # else: concurrent setup already started, continue to step 2

    logger.info("setup step 1 complete: admin user created", extra={"user_id": user.id})
    return RedirectResponse(url="/setup/2", status_code=status.HTTP_302_FOUND)


# ---------------------------------------------------------------------------
# POST /setup/2 — GCP service account
# ---------------------------------------------------------------------------


def _after_step2(svc) -> RedirectResponse:
    """Advance from GCP setup into the next relevant setup step."""
    from app.core.config import is_local_mode

    if is_local_mode():
        svc.save_step3("us")
        svc.skip_step4()
        return RedirectResponse(url="/setup/5", status_code=status.HTTP_302_FOUND)
    return RedirectResponse(url="/setup/3", status_code=status.HTTP_302_FOUND)


@router.post("/setup/2", response_class=HTMLResponse)
async def setup_step2_post(
    request: Request,
    installation_mode: str = Form("cloud"),
    auth_method: str = Form("json"),
    credentials_json: str = Form(""),
    credentials_file: UploadFile | None = None,
    db: Session = Depends(get_session),
) -> Response:
    if _is_setup_complete(request):
        return RedirectResponse(url="/login", status_code=status.HTTP_302_FOUND)

    svc = SetupService(db)
    state = svc.get_state()
    if state is None:
        return _redirect_step(1)

    from app.setup.gcp_verify import verify_gcp_roles, verify_gcp_roles_adc

    installation_mode = installation_mode.strip() or "cloud"
    if installation_mode not in {"cloud", "local_dev"}:
        installation_mode = "cloud"

    if auth_method == "adc":
        try:
            role_results = verify_gcp_roles_adc()
        except RuntimeError as exc:
            ctx = {
                **_step_context(2, state),
                "errors": {"network": str(exc)},
                "role_results": {},
                "auth_method": "adc",
                "installation_mode": installation_mode,
                "retry": True,
            }
            return _templates(request).TemplateResponse(
                request, "setup/step2.html", ctx, status_code=422
            )

        if not all(role_results.values()):
            ctx = {
                **_step_context(2, state),
                "errors": {},
                "role_results": role_results,
                "auth_method": "adc",
                "installation_mode": installation_mode,
                "all_roles_pass": False,
            }
            return _templates(request).TemplateResponse(
                request, "setup/step2.html", ctx, status_code=422
            )

        svc.save_step2(
            gcp_credentials_json=None,
            auth_method="adc",
            installation_mode=installation_mode,
        )
        return _after_step2(svc)

    # --- JSON mode ---
    raw_json = credentials_json.strip()
    if credentials_file and credentials_file.filename:
        content = await credentials_file.read()
        raw_json = content.decode("utf-8", errors="replace").strip()

    if not raw_json:
        ctx = {
            **_step_context(2, state),
            "errors": {
                "credentials": "Paste your service account JSON or upload the file."
            },
            "role_results": {},
            "auth_method": "json",
            "installation_mode": installation_mode,
        }
        return _templates(request).TemplateResponse(
            request, "setup/step2.html", ctx, status_code=422
        )

    try:
        role_results = verify_gcp_roles(raw_json)
    except ValueError as exc:
        ctx = {
            **_step_context(2, state),
            "errors": {"credentials": str(exc)},
            "role_results": {},
            "auth_method": "json",
            "installation_mode": installation_mode,
        }
        return _templates(request).TemplateResponse(
            request, "setup/step2.html", ctx, status_code=422
        )
    except RuntimeError as exc:
        ctx = {
            **_step_context(2, state),
            "errors": {"network": str(exc)},
            "role_results": {},
            "auth_method": "json",
            "installation_mode": installation_mode,
            "retry": True,
        }
        return _templates(request).TemplateResponse(
            request, "setup/step2.html", ctx, status_code=422
        )

    if not all(role_results.values()):
        ctx = {
            **_step_context(2, state),
            "errors": {},
            "role_results": role_results,
            "auth_method": "json",
            "installation_mode": installation_mode,
            "all_roles_pass": False,
        }
        return _templates(request).TemplateResponse(
            request, "setup/step2.html", ctx, status_code=422
        )

    svc.save_step2(
        gcp_credentials_json=raw_json,
        auth_method="json",
        installation_mode=installation_mode,
    )
    return _after_step2(svc)


# ---------------------------------------------------------------------------
# POST /setup/3 — BigQuery region
# ---------------------------------------------------------------------------


@router.post("/setup/3", response_class=HTMLResponse)
def setup_step3_post(
    request: Request,
    region: str = Form(""),
    db: Session = Depends(get_session),
) -> Response:
    if _is_setup_complete(request):
        return RedirectResponse(url="/login", status_code=status.HTTP_302_FOUND)

    svc = SetupService(db)
    state = svc.get_state()
    if state is None:
        return _redirect_step(1)

    region = region.strip()
    if not region:
        ctx = {
            **_step_context(3, state),
            "errors": {"region": "Select or enter a BigQuery region."},
            "regions": _BIGQUERY_REGIONS,
        }
        return _templates(request).TemplateResponse(
            request, "setup/step3.html", ctx, status_code=422
        )

    svc.save_step3(region)
    return RedirectResponse(url="/setup/4", status_code=status.HTTP_302_FOUND)


# ---------------------------------------------------------------------------
# POST /setup/4 — GitHub App (optional)
# ---------------------------------------------------------------------------


@router.post("/setup/4", response_class=HTMLResponse)
def setup_step4_post(
    request: Request,
    auth_mode: str = Form("app"),
    app_id: str = Form(""),
    installation_id: str = Form(""),
    private_key: str = Form(""),
    personal_access_token: str = Form(""),
    skip: str = Form(""),
    db: Session = Depends(get_session),
) -> Response:
    if _is_setup_complete(request):
        return RedirectResponse(url="/login", status_code=status.HTTP_302_FOUND)

    svc = SetupService(db)
    state = svc.get_state()
    if state is None:
        return _redirect_step(1)

    def _after_step4() -> RedirectResponse:
        """In local mode, skip only GCS (step 6) — LLM is still needed."""
        return RedirectResponse(url="/setup/5", status_code=status.HTTP_302_FOUND)

    if skip:
        svc.skip_step4()
        return _after_step4()

    auth_mode = auth_mode.strip() or "app"
    if auth_mode not in {"app", "personal_token", "disabled"}:
        auth_mode = "app"

    if auth_mode == "disabled":
        svc.skip_step4()
        return _after_step4()

    if auth_mode == "personal_token":
        if not personal_access_token.strip():
            ctx = {
                **_step_context(4, state),
                "errors": {
                    "personal_access_token": "GitHub personal access token is required."
                },
                "auth_mode": auth_mode,
            }
            return _templates(request).TemplateResponse(
                request, "setup/step4.html", ctx, status_code=422
            )

        from app.github.client import (
            GitHubAuthenticationError,
            GitHubConfigurationError,
            GitHubConnectionError,
            GitHubRateLimitError,
            GitHubTokenClient,
        )

        try:
            client = GitHubTokenClient(personal_access_token.strip())
            client.verify_token_connectivity()
        except (GitHubConfigurationError, GitHubAuthenticationError) as exc:
            ctx = {
                **_step_context(4, state),
                "errors": {"github": str(exc)},
                "auth_mode": auth_mode,
            }
            return _templates(request).TemplateResponse(
                request, "setup/step4.html", ctx, status_code=422
            )
        except GitHubRateLimitError as exc:
            ctx = {
                **_step_context(4, state),
                "errors": {"github": str(exc)},
                "auth_mode": auth_mode,
                "retry": True,
            }
            return _templates(request).TemplateResponse(
                request, "setup/step4.html", ctx, status_code=422
            )
        except GitHubConnectionError as exc:
            ctx = {
                **_step_context(4, state),
                "errors": {"network": str(exc)},
                "auth_mode": auth_mode,
                "retry": True,
            }
            return _templates(request).TemplateResponse(
                request, "setup/step4.html", ctx, status_code=422
            )

        svc.save_step4_personal_token(personal_access_token.strip())
        return _after_step4()

    errors: dict[str, str] = {}
    if not app_id.strip():
        errors["app_id"] = "GitHub App ID is required."
    if not installation_id.strip():
        errors["installation_id"] = "Installation ID is required."
    if not private_key.strip():
        errors["private_key"] = "Private key PEM is required."

    if errors:
        ctx = {
            **_step_context(4, state),
            "errors": errors,
            "app_id": app_id,
            "installation_id": installation_id,
            "auth_mode": auth_mode,
        }
        return _templates(request).TemplateResponse(
            request, "setup/step4.html", ctx, status_code=422
        )

    from app.github.client import (
        GitHubAppClient,
        GitHubAuthenticationError,
        GitHubConfigurationError,
        GitHubConnectionError,
    )

    try:
        client = GitHubAppClient(
            app_id=app_id.strip(),
            private_key=private_key.strip(),
            installation_id=installation_id.strip(),
        )
        client.verify_app_connectivity()
    except (GitHubConfigurationError, GitHubAuthenticationError) as exc:
        ctx = {
            **_step_context(4, state),
            "errors": {"github": str(exc)},
            "app_id": app_id,
            "installation_id": installation_id,
            "auth_mode": auth_mode,
        }
        return _templates(request).TemplateResponse(
            request, "setup/step4.html", ctx, status_code=422
        )
    except GitHubConnectionError as exc:
        ctx = {
            **_step_context(4, state),
            "errors": {"network": str(exc)},
            "app_id": app_id,
            "installation_id": installation_id,
            "auth_mode": auth_mode,
            "retry": True,
        }
        return _templates(request).TemplateResponse(
            request, "setup/step4.html", ctx, status_code=422
        )
    except (ValueError, RuntimeError) as exc:
        ctx = {
            **_step_context(4, state),
            "errors": {"github": f"Connectivity check failed: {exc}"},
            "app_id": app_id,
            "installation_id": installation_id,
            "auth_mode": auth_mode,
        }
        return _templates(request).TemplateResponse(
            request, "setup/step4.html", ctx, status_code=422
        )

    svc.save_step4(app_id.strip(), installation_id.strip(), private_key.strip())
    return _after_step4()


# ---------------------------------------------------------------------------
# POST /setup/5 — LLM API key (optional)
# ---------------------------------------------------------------------------


@router.post("/setup/5", response_class=HTMLResponse)
def setup_step5_post(
    request: Request,
    api_key: str = Form(""),
    skip: str = Form(""),
    db: Session = Depends(get_session),
) -> Response:
    if _is_setup_complete(request):
        return RedirectResponse(url="/login", status_code=status.HTTP_302_FOUND)

    svc = SetupService(db)
    state = svc.get_state()
    if state is None:
        return _redirect_step(1)

    def _after_step5() -> RedirectResponse:
        from app.core.config import is_local_mode

        if is_local_mode():
            svc.skip_step6()
            return RedirectResponse(
                url="/setup/complete", status_code=status.HTTP_302_FOUND
            )
        return RedirectResponse(url="/setup/6", status_code=status.HTTP_302_FOUND)

    if skip:
        svc.skip_step5()
        return _after_step5()

    api_key = api_key.strip()
    if not api_key:
        ctx = {
            **_step_context(5, state),
            "errors": {"api_key": "API key is required."},
        }
        return _templates(request).TemplateResponse(
            request, "setup/step5.html", ctx, status_code=422
        )

    # Minimal test call to confirm the key works
    try:
        from google import genai

        client = genai.Client(api_key=api_key)
        response = client.models.generate_content(
            model="gemini-2.0-flash",
            contents="Reply with the single word: ok",
        )
        _ = response.text  # Will raise if auth failed
    except (ValueError, RuntimeError, ConnectionError, OSError) as exc:
        err_str = str(exc).lower()
        if (
            "api_key" in err_str
            or "unauthorized" in err_str
            or "401" in err_str
            or "403" in err_str
            or "invalid" in err_str
        ):
            msg = "Authentication failure: the API key is invalid or lacks access."
        else:
            msg = f"LLM test call failed: {exc}"
        ctx = {
            **_step_context(5, state),
            "errors": {"api_key": msg},
        }
        return _templates(request).TemplateResponse(
            request, "setup/step5.html", ctx, status_code=422
        )

    svc.save_step5(api_key)
    return _after_step5()


# ---------------------------------------------------------------------------
# POST /setup/6 — GCS bucket path (optional)
# ---------------------------------------------------------------------------


@router.post("/setup/6", response_class=HTMLResponse)
def setup_step6_post(
    request: Request,
    bucket_path: str = Form(""),
    skip: str = Form(""),
    db: Session = Depends(get_session),
) -> Response:
    if _is_setup_complete(request):
        return RedirectResponse(url="/login", status_code=status.HTTP_302_FOUND)

    svc = SetupService(db)
    state = svc.get_state()
    if state is None:
        return _redirect_step(1)

    if skip:
        svc.skip_step6()
        return RedirectResponse(
            url="/setup/complete", status_code=status.HTTP_302_FOUND
        )

    bucket_path = bucket_path.strip()
    if not bucket_path:
        ctx = {
            **_step_context(6, state),
            "errors": {"bucket_path": "Enter the GCS bucket path."},
        }
        return _templates(request).TemplateResponse(
            request, "setup/step6.html", ctx, status_code=422
        )

    # Parse gs://bucket/prefix
    if not bucket_path.startswith("gs://"):
        ctx = {
            **_step_context(6, state),
            "errors": {"bucket_path": "Path must start with gs://"},
        }
        return _templates(request).TemplateResponse(
            request, "setup/step6.html", ctx, status_code=422
        )

    path_part = bucket_path[5:]  # strip gs://
    parts = path_part.split("/", 1)
    bucket_name = parts[0]
    prefix = parts[1] if len(parts) > 1 else ""

    # Verify read access using GCP credentials from step 2
    try:
        from google.cloud import storage

        if state.gcp_auth_method == "adc" or not state.gcp_credentials_json:
            gcs_client = storage.Client()
        else:
            from google.oauth2 import service_account

            info = json.loads(state.gcp_credentials_json)
            credentials = service_account.Credentials.from_service_account_info(
                info, scopes=["https://www.googleapis.com/auth/cloud-platform"]
            )
            gcs_client = storage.Client(credentials=credentials)
        bucket = gcs_client.bucket(bucket_name)
        # Try listing — will raise Forbidden if no access
        next(iter(gcs_client.list_blobs(bucket, prefix=prefix, max_results=1)), None)
    except (ValueError, GoogleCloudError) as exc:
        err_str = str(exc).lower()
        if "403" in err_str or "forbidden" in err_str or "permission" in err_str:
            msg = (
                "Access denied. The service account is missing "
                "storage.objects.get / roles/storage.objectViewer on this bucket."
            )
        elif "404" in err_str or "not found" in err_str:
            msg = f"Bucket {bucket_name!r} not found or is in a different project."
        else:
            msg = f"Could not access bucket: {exc}"
        ctx = {
            **_step_context(6, state),
            "errors": {"bucket_path": msg},
            "bucket_path": bucket_path,
        }
        return _templates(request).TemplateResponse(
            request, "setup/step6.html", ctx, status_code=422
        )

    svc.save_step6(bucket_path)
    return RedirectResponse(url="/setup/complete", status_code=status.HTTP_302_FOUND)


# ---------------------------------------------------------------------------
# POST /setup/complete — Finalize
# ---------------------------------------------------------------------------


@router.post("/setup/complete", response_class=HTMLResponse)
def setup_complete_post(
    request: Request,
    db: Session = Depends(get_session),
) -> Response:
    if _is_setup_complete(request):
        return RedirectResponse(url="/login", status_code=status.HTTP_302_FOUND)

    svc = SetupService(db)
    state = svc.get_state()
    if state is None or state.step_reached < 7:
        return _redirect_step(state.step_reached if state else 1)

    # Mark complete
    state = svc.complete()

    # Refresh app.state cache
    from app.setup.loader import load_setup_state

    load_setup_state(request.app, db)

    # Create session for the admin user
    admin_user = db.query(User).filter(User.id == state.admin_user_id).one_or_none()
    if admin_user is None:
        logger.error(
            "setup complete: admin_user_id not found", extra={"state_id": state.id}
        )
        return RedirectResponse(url="/login", status_code=status.HTTP_302_FOUND)

    auth_service = AuthService(db)
    session = auth_service.create_session(
        admin_user,
        request.client.host if request.client else None,
        request.headers.get("user-agent"),
    )

    settings = get_settings()
    cookie_expires = session.expires_at
    if cookie_expires is not None:
        if cookie_expires.tzinfo is None:
            cookie_expires = cookie_expires.replace(tzinfo=timezone.utc)
        else:
            cookie_expires = cookie_expires.astimezone(timezone.utc)

    from app.core.config import is_local_mode

    redirect_url = "/admin/configurations/new" if is_local_mode() else "/dashboard"
    response = RedirectResponse(url=redirect_url, status_code=status.HTTP_302_FOUND)
    response.set_cookie(
        settings.session_cookie_name,
        session.id,
        httponly=True,
        samesite="lax",
        secure=settings.session_cookie_secure,
        max_age=settings.session_ttl_hours * 3600,
        expires=cookie_expires,
    )
    logger.info("setup complete: admin logged in", extra={"user_id": admin_user.id})
    return response
