from __future__ import annotations

import logging
from datetime import datetime, timedelta, timezone

from fastapi import APIRouter, Depends, Query, Request
from fastapi.responses import HTMLResponse, RedirectResponse
from sqlalchemy import func
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.orm import Session
from starlette.responses import Response

from app.auth import models
from app.auth.dependencies import get_active_session
from app.auth.service import AuthService
from app.db.session import get_session
from app.routes import errors
from app.routes.app import _build_solution_view_model, _build_validation_reference_context
from app.routes.helpers import get_flash_message, redirect_with_message
from app.utils.pagination import PaginationContext

logger = logging.getLogger("app.routes.solutions_admin")

router = APIRouter()


def _get_authenticated_user(request: Request, db: Session, auth_session) -> models.User | None:
    """Validate session and return the current user or None."""
    if not auth_session:
        return None
    user = (
        db.query(models.User)
        .filter(models.User.id == auth_session.user_id)
        .one_or_none()
    )
    if not user:
        return None
    return user


def _require_admin_user(request: Request, db: Session, auth_session) -> tuple[models.User | None, Response | None]:
    """Return the authenticated admin user or an error response."""
    user = _get_authenticated_user(request, db, auth_session)
    if not user:
        return None, redirect_with_message(
            "/login",
            "Please sign in to continue.",
            "warning",
        )

    if any(role.name == "admin" for role in user.roles):
        return user, None

    auth_service = AuthService(db)
    auth_service.record_audit_event(
        user.id,
        "access_denied",
        "failure",
        request.client.host if request.client else None,
        request.headers.get("user-agent"),
    )
    db.commit()
    templates = request.app.state.templates
    return None, errors.render_error(
        templates,
        request,
        "Admin access required.",
        status_code=403,
    )


def _admin_solution_filter_label(job_status: str, window: str) -> str:
    if job_status == "queued":
        label = "Queued solution jobs"
    elif job_status == "in_progress":
        label = "Running solution jobs"
    elif job_status == "failed":
        label = "Failed solution jobs"
    else:
        label = "Completed solutions"

    if window == "24h":
        label += " (last 24h)"
    return label


@router.get("/admin/solutions", response_class=HTMLResponse)
def admin_solutions(
    request: Request,
    db: Session = Depends(get_session),
    auth_session=Depends(get_active_session),
    page: int = Query(default=1, ge=1),
    page_size: int = Query(default=10, ge=1, le=100),
    sort: str = Query(default="created_at"),
    direction: str = Query(default="desc"),
    job_status: str = Query(default="completed"),
    window: str = Query(default="all"),
) -> Response:
    """Admin solutions queue and completed-solution detail page."""
    from app.opportunities.models import Opportunity
    from app.solutions.models import Solution, SolutionJob

    user, error_response = _require_admin_user(request, db, auth_session)
    if error_response:
        return error_response

    allowed_statuses = {"all", "queued", "in_progress", "completed", "failed"}
    allowed_windows = {"all", "24h"}
    job_status_filter = job_status if job_status in allowed_statuses else "completed"
    window_filter = window if window in allowed_windows else "all"
    show_solution_jobs = job_status_filter in {"queued", "in_progress", "failed"}
    cutoff = datetime.now(timezone.utc) - timedelta(hours=24)

    metric_rows = (
        db.query(SolutionJob.status, func.count(SolutionJob.id))
        .group_by(SolutionJob.status)
        .all()
    )
    solution_metrics = {
        "pending": 0,
        "running": 0,
        "completed": 0,
        "failed": 0,
    }
    for status_value, count in metric_rows:
        if status_value == "queued":
            solution_metrics["pending"] = count
        elif status_value == "in_progress":
            solution_metrics["running"] = count
        elif status_value == "completed":
            solution_metrics["completed"] = count
        elif status_value == "failed":
            solution_metrics["failed"] = count

    templates = request.app.state.templates
    active_filter_label = _admin_solution_filter_label(
        job_status_filter,
        window_filter,
    )

    if show_solution_jobs:
        job_query = (
            db.query(SolutionJob, Opportunity)
            .join(Opportunity, SolutionJob.opportunity_id == Opportunity.id)
            .filter(SolutionJob.status == job_status_filter)
        )
        if window_filter == "24h":
            job_query = job_query.filter(SolutionJob.completed_at >= cutoff)

        total_items = job_query.count()
        job_pagination = PaginationContext(
            page=page,
            page_size=page_size,
            total_items=total_items,
        )
        offset = (job_pagination.page - 1) * page_size
        job_rows = (
            job_query.order_by(
                SolutionJob.completed_at.desc(),
                SolutionJob.queued_at.desc(),
            )
            .offset(offset)
            .limit(page_size)
            .all()
        )

        solution_jobs = []
        for job, opportunity in job_rows:
            solution_jobs.append(
                {
                    "id": job.id,
                    "status": job.status,
                    "status_label": job.status.replace("_", " "),
                    "queued_at": job.queued_at.strftime("%d/%m/%Y %H:%M")
                    if job.queued_at
                    else None,
                    "started_at": job.started_at.strftime("%d/%m/%Y %H:%M")
                    if job.started_at
                    else None,
                    "completed_at": job.completed_at.strftime("%d/%m/%Y %H:%M")
                    if job.completed_at
                    else None,
                    "resolution_category": job.resolution_category,
                    "retry_count": job.retry_count,
                    "lifetime_retry_count": job.lifetime_retry_count,
                    "solutions_generated_count": job.solutions_generated_count,
                    "llm_model": job.llm_model,
                    "error_stage": job.error_stage,
                    "error_message": job.error_message,
                    "opportunity_type": (
                        opportunity.opportunity_type if opportunity else "Unknown"
                    ),
                    "affected_table": (
                        opportunity.affected_table if opportunity else "Unknown"
                    ),
                    "config_id": opportunity.config_id if opportunity else None,
                    "opp_id": job.opportunity_id,
                }
            )

        return templates.TemplateResponse(
            request,
            "project/solutions.html",
            {
                "title": "Solutions",
                "flash": get_flash_message(request),
                "user": user,
                "solution_metrics": solution_metrics,
                "active_filter_label": active_filter_label,
                "show_solution_jobs": True,
                "solution_jobs": solution_jobs,
                "job_pagination": job_pagination,
                "solutions": [],
                "pagination": PaginationContext(
                    page=1,
                    page_size=page_size,
                    total_items=0,
                ),
                "sort": sort,
                "direction": direction,
                "job_status_filter": job_status_filter,
                "window_filter": window_filter,
            },
        )

    solution_query = (
        db.query(Solution, Opportunity, SolutionJob)
        .join(Opportunity, Solution.opportunity_id == Opportunity.id)
        .join(SolutionJob, Solution.solution_job_id == SolutionJob.id)
        .filter(SolutionJob.status == "completed")
    )
    if window_filter == "24h":
        solution_query = solution_query.filter(SolutionJob.completed_at >= cutoff)

    sort_map = {
        "created_at": Solution.created_at,
        "risk_level": Solution.risk_level,
        "resolution_category": Solution.resolution_category,
    }
    sort_column = sort_map.get(sort, Solution.created_at)
    order = sort_column.asc() if direction == "asc" else sort_column.desc()

    total_items = solution_query.count()
    pagination = PaginationContext(
        page=page,
        page_size=page_size,
        total_items=total_items,
    )
    offset = (pagination.page - 1) * page_size
    solution_rows = (
        solution_query.order_by(order, Solution.id.desc())
        .offset(offset)
        .limit(page_size)
        .all()
    )

    compiled_original_cache: dict[str, tuple[str | None, str | None]] = {}
    config_cache: dict[str, object] = {}
    solutions = []
    cached_dry_runs_updated = False
    for solution, opportunity, solution_job in solution_rows:
        sol, updated = _build_solution_view_model(
            db,
            solution,
            opportunity=opportunity,
            solution_job=solution_job,
            compiled_original_cache=compiled_original_cache,
            config_cache=config_cache,
        )
        cached_dry_runs_updated = cached_dry_runs_updated or updated
        solutions.append(sol)

    if cached_dry_runs_updated:
        db.commit()

    return templates.TemplateResponse(
        request,
        "project/solutions.html",
        {
            "title": "Solutions",
            "flash": get_flash_message(request),
            "user": user,
            "solution_metrics": solution_metrics,
            "active_filter_label": active_filter_label,
            "show_solution_jobs": False,
            "solutions": solutions,
            "pagination": pagination,
            "solution_jobs": [],
            "job_pagination": PaginationContext(
                page=1,
                page_size=page_size,
                total_items=0,
            ),
            "sort": sort,
            "direction": direction,
            "job_status_filter": job_status_filter,
            "window_filter": window_filter,
        },
    )


@router.post("/admin/solutions/regenerate")
def app_solutions_regenerate(
    request: Request,
    db: Session = Depends(get_session),
    auth_session=Depends(get_active_session),
) -> RedirectResponse:
    """Delete existing solutions and re-queue jobs for all active opportunities."""
    from app.solutions.service import SolutionService

    _, error_response = _require_admin_user(request, db, auth_session)
    if error_response:
        return error_response

    svc = SolutionService(db)
    try:
        count = svc.requeue_all_solutions()
        return redirect_with_message(
            "/admin/solutions",
            f"Re-queued {count} solution jobs. The worker will process them shortly.",
            "success",
        )
    except (ValueError, RuntimeError, SQLAlchemyError) as exc:
        logging.getLogger("app.routes.app").warning(
            "failed to requeue all solutions",
            exc_info=exc,
        )
        return redirect_with_message(
            "/admin/solutions",
            "Failed to re-queue solutions. Please try again.",
            "error",
        )


# ---------------------------------------------------------------------------
# Validation & Safety reference page (spec 030)
# ---------------------------------------------------------------------------


@router.get("/admin/validation", response_class=HTMLResponse)
def admin_validation_safety(
    request: Request,
    db: Session = Depends(get_session),
    auth_session=Depends(get_active_session),
) -> Response:
    """Production validation & safety reference page."""
    user, error_response = _require_admin_user(request, db, auth_session)
    if error_response:
        return error_response

    validation_reference = _build_validation_reference_context()
    templates = request.app.state.templates
    return templates.TemplateResponse(
        request,
        "admin/validation_safety.html",
        {
            "title": "Validation & Safety",
            "flash": get_flash_message(request),
            "user": user,
            **validation_reference,
        },
    )

