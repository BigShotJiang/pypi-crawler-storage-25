from __future__ import annotations

from collections.abc import Generator, Mapping
import logging
from typing import Any

from fastapi import APIRouter, Depends, File, HTTPException, Query, Request, UploadFile
from fastapi.responses import HTMLResponse, JSONResponse, StreamingResponse
from google.cloud.exceptions import GoogleCloudError
from starlette.responses import Response
from pydantic import ValidationError
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.orm import Session

from app.auth.dependencies import require_role
from app.auth.models import User
from app.configurations.schemas import (
    ManifestConfigurationCreate,
    ManifestConfigurationUpdate,
)
from app.configurations.service import (
    ConcurrencyError,
    ConfigurationError,
    DuplicateLocationError,
    EnableWithoutGithubError,
    GCSValidationError,
    ManualManifestUploadError,
    ManifestConfigurationService,
    NotFoundError,
)
from app.core.config import is_local_mode
from app.db.session import get_session
from app.gcp.clients import GCPCredentialsError, validate_gcs_manifest
from app.github.client import GitHubAuthenticationError, GitHubConnectionError
from app.opportunities.exceptions import (
    ActiveDetectionJobExistsError,
    LatestCompletedSyncNotFoundError,
)
from app.dashboard.formatters import get_cost_multiplier, set_cost_multiplier
from app.opportunities.catalog import (
    build_effective_rule_selection,
    get_detection_analysis_surfaces,
    get_detection_rule_catalog,
    get_grouped_detection_rule_catalog,
)
from app.routes.helpers import (
    get_flash_message,
    redirect_local_mode_feature,
    redirect_with_message,
)
from app.solutions.policy import (
    build_effective_solution_policy,
    get_solution_policy_catalog,
)
from app.workspace.picker import (
    FolderPickerCancelledError,
    FolderPickerError,
    FolderPickerUnsupportedError,
    pick_local_project_folder,
)

logger = logging.getLogger("app.configurations")

router = APIRouter()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _service_error_to_context(
    exc: Exception,
    form_data: dict,
) -> dict:
    """Convert service-layer exceptions to template error context."""
    errors: dict[str, list[str]] = {}

    if isinstance(exc, DuplicateLocationError):
        errors["manifest_location"] = [str(exc)]
    elif isinstance(exc, GCSValidationError):
        errors["manifest_location"] = [exc.message]
    elif isinstance(exc, ConcurrencyError):
        errors["_concurrency"] = [str(exc)]
    elif isinstance(exc, EnableWithoutGithubError):
        errors["github_repo"] = [str(exc)]
    elif isinstance(exc, ManualManifestUploadError):
        errors["manifest_upload"] = [str(exc)]
    elif isinstance(exc, ConfigurationError):
        errors["schedule_value"] = [str(exc)]
    elif isinstance(exc, ValidationError):
        for err in exc.errors():
            field = ".".join(str(loc) for loc in err["loc"])
            errors.setdefault(field, []).append(err["msg"])
    else:
        errors["_general"] = [str(exc)]

    return {"errors": errors, "form_data": form_data}


def _form_to_template_data(form: Any) -> dict[str, Any]:
    """Convert FormData into a template-friendly dict preserving repeated keys."""
    data: dict[str, Any] = {}
    for key in form.keys():
        values = form.getlist(key)
        data[key] = values if len(values) > 1 else values[0]
    return data


def _coerce_to_str_list(value: Any) -> list[str]:
    if value is None:
        return []
    if isinstance(value, list):
        items = value
    else:
        items = [value]
    result: list[str] = []
    seen: set[str] = set()
    for item in items:
        text = str(item).strip()
        if not text or text in seen:
            continue
        result.append(text)
        seen.add(text)
    return result


def _normalize_creation_mode(mode: Any) -> str | None:
    if mode is None:
        return None
    value = str(mode).strip().lower()
    if value in {"local", "local_dev"}:
        return "local"
    if value == "cloud":
        return "cloud"
    return None


def _build_new_configuration_form_context(
    *,
    user: User,
    gcp_projects: list[Any],
    form_data: Mapping[str, Any] | None = None,
    errors: Mapping[str, list[str]] | None = None,
) -> dict[str, Any]:
    normalized_form_data = dict(form_data or {})
    creation_mode = _normalize_creation_mode(normalized_form_data.get("creation_mode"))
    if creation_mode is None:
        manifest_source = str(
            normalized_form_data.get("manifest_source", "gcs")
        ).strip()
        creation_mode = (
            "local" if manifest_source in {"manual_upload", "local"} else "cloud"
        )

    normalized_form_data["creation_mode"] = creation_mode
    normalized_form_data.setdefault(
        "manifest_source",
        "manual_upload" if creation_mode == "local" else "gcs",
    )

    return {
        "title": "New Configuration",
        "user": user,
        "gcp_projects": gcp_projects,
        "errors": dict(errors or {}),
        "form_data": normalized_form_data,
        "creation_mode": creation_mode,
        "cost_display_multiplier": get_cost_multiplier(),
        **_build_rule_selector_context(form_data=normalized_form_data),
        **_build_solution_policy_selector_context(form_data=normalized_form_data),
    }


def _build_rule_selector_context(
    config=None,
    form_data: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    catalog = get_detection_rule_catalog()
    grouped_catalog = get_grouped_detection_rule_catalog(catalog)

    if form_data is None:
        watched_rule_types = getattr(config, "watched_rule_types", None)
        watched_rules_mode = "all" if watched_rule_types is None else "custom"
    else:
        watched_rules_mode = str(form_data.get("watched_rules_mode", "all")).strip()
        if watched_rules_mode not in {"all", "custom"}:
            watched_rules_mode = "all"
        watched_rule_types = (
            None
            if watched_rules_mode == "all"
            else _coerce_to_str_list(form_data.get("watched_rule_types"))
        )

    selection = build_effective_rule_selection(watched_rule_types, catalog)
    selected_watched_rule_types = (
        selection.configured_rule_types if watched_rules_mode == "custom" else []
    )

    return {
        "detection_analysis_surfaces": get_detection_analysis_surfaces(),
        "detection_rule_catalog": catalog,
        "detection_rule_groups": grouped_catalog,
        "watched_rules_mode": watched_rules_mode,
        "selected_watched_rule_types": selected_watched_rule_types,
        "disabled_rule_types": [
            entry.rule_type for entry in catalog if not entry.enabled
        ],
        "unknown_watched_rule_types": selection.unknown_rule_types,
    }


def _build_solution_policy_selector_context(
    config=None,
    form_data: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    catalog = get_solution_policy_catalog()

    if form_data is None:
        allowed_solution_policy_tags = getattr(
            config,
            "allowed_solution_policy_tags",
            None,
        )
        solution_guardrails_mode = (
            "all" if allowed_solution_policy_tags is None else "custom"
        )
    else:
        solution_guardrails_mode = str(
            form_data.get("solution_guardrails_mode", "all")
        ).strip()
        if solution_guardrails_mode not in {"all", "custom"}:
            solution_guardrails_mode = "all"
        allowed_solution_policy_tags = (
            None
            if solution_guardrails_mode == "all"
            else _coerce_to_str_list(form_data.get("allowed_solution_policy_tags"))
        )

    selection = build_effective_solution_policy(
        allowed_solution_policy_tags,
        catalog,
    )
    selected_solution_policy_tags = (
        selection.configured_policy_tags if solution_guardrails_mode == "custom" else []
    )

    return {
        "solution_policy_catalog": catalog,
        "solution_guardrails_mode": solution_guardrails_mode,
        "selected_solution_policy_tags": selected_solution_policy_tags,
        "unknown_solution_policy_tags": selection.unknown_policy_tags,
    }


def _redirect_local_sync_management(config_id: str | None = None) -> Response:
    target_url = (
        f"/admin/configurations/{config_id}" if config_id else "/admin/configurations"
    )
    return redirect_local_mode_feature(
        target_url,
        feature_name="Sync history and queue pages",
        guidance="Local mode focuses on configuration, manifest upload, and opportunity review.",
    )


def _get_sync_context(db: Session, config_id: str) -> dict:
    """Get sync-related context variables for detail page template.

    Returns context dict with:
    - active_sync: Most recent sync (any status)
    - sync_history: Paginated list (first page only for error views)
    - sync_history_page: Current page number
    - sync_history_total_pages: Total pages
    - last_completed_sync: Most recent completed sync
    - last_jobs_sync_at: Timestamp of last sync with jobs
    - last_manifest_change_at: Timestamp of last sync with manifests
    """
    from sqlalchemy import func
    from sqlalchemy.orm import joinedload

    from app.sync.models import SyncOperation

    # Get most recent sync (any status)
    active_sync = (
        db.query(SyncOperation)
        .options(joinedload(SyncOperation.errors))
        .filter(SyncOperation.config_id == config_id)
        .order_by(SyncOperation.queued_at.desc())
        .first()
    )

    # Get first page of sync history
    page_size = 10
    total_count = (
        db.query(func.count(SyncOperation.id))
        .filter(SyncOperation.config_id == config_id)
        .scalar()
    )
    total_pages = max(1, (total_count + page_size - 1) // page_size)

    sync_history = (
        db.query(SyncOperation)
        .options(joinedload(SyncOperation.errors))
        .filter(SyncOperation.config_id == config_id)
        .order_by(SyncOperation.queued_at.desc())
        .limit(page_size)
        .all()
    )

    # Get most recent completed sync
    last_completed_sync = (
        db.query(SyncOperation)
        .filter(
            SyncOperation.config_id == config_id,
            SyncOperation.status == "completed",
        )
        .order_by(SyncOperation.completed_at.desc())
        .first()
    )

    # Get last jobs sync timestamp
    last_jobs_result = (
        db.query(SyncOperation.completed_at)
        .filter(
            SyncOperation.config_id == config_id,
            SyncOperation.status == "completed",
            SyncOperation.jobs_retrieved_count > 0,
        )
        .order_by(SyncOperation.completed_at.desc())
        .first()
    )
    last_jobs_sync_at = last_jobs_result[0] if last_jobs_result else None

    # Get last manifest change timestamp
    last_manifest_result = (
        db.query(SyncOperation.completed_at)
        .filter(
            SyncOperation.config_id == config_id,
            SyncOperation.status == "completed",
            SyncOperation.manifests_updated_count > 0,
        )
        .order_by(SyncOperation.completed_at.desc())
        .first()
    )
    last_manifest_change_at = last_manifest_result[0] if last_manifest_result else None

    return {
        "active_sync": active_sync,
        "sync_history": sync_history,
        "sync_history_page": 1,
        "sync_history_total_pages": total_pages,
        "sync_history_total_count": total_count,
        "last_completed_sync": last_completed_sync,
        "last_jobs_sync_at": last_jobs_sync_at,
        "last_manifest_change_at": last_manifest_change_at,
    }


# ---------------------------------------------------------------------------
# Local helper endpoints
# ---------------------------------------------------------------------------


@router.post(
    "/admin/configurations/pick-local-folder",
    response_class=JSONResponse,
)
def pick_configuration_local_folder(
    user: User = Depends(require_role("admin")),
) -> JSONResponse:
    del user  # route is admin-only; the object is not otherwise used here

    if not is_local_mode():
        raise HTTPException(
            status_code=404,
            detail="Folder picker is only available in local mode.",
        )

    try:
        selected_path = pick_local_project_folder()
    except FolderPickerCancelledError as exc:
        return JSONResponse({"error": str(exc)}, status_code=400)
    except FolderPickerUnsupportedError as exc:
        return JSONResponse({"error": str(exc)}, status_code=501)
    except FolderPickerError as exc:
        return JSONResponse({"error": str(exc)}, status_code=500)

    return JSONResponse({"path": selected_path})


# ---------------------------------------------------------------------------
# US3: List configurations
# ---------------------------------------------------------------------------


@router.get("/admin/configurations", response_class=HTMLResponse)
def list_configurations(
    request: Request,
    page: int = 1,
    sort: str = "name",
    direction: str = "asc",
    user: User = Depends(require_role("admin")),
    db: Session = Depends(get_session),
) -> Response:
    from sqlalchemy import func as sa_func
    from app.configurations.models import ManifestConfiguration
    from app.utils.pagination import PaginationContext

    valid_sorts = {"name", "gcp_project", "status", "created_at"}
    if sort not in valid_sorts:
        sort = "name"
    if direction not in ("asc", "desc"):
        direction = "asc"
    if page < 1:
        page = 1

    sort_col_map = {
        "name": ManifestConfiguration.name,
        "gcp_project": ManifestConfiguration.gcp_project_id,
        "status": ManifestConfiguration.status,
        "created_at": ManifestConfiguration.created_at,
    }
    col = sort_col_map.get(sort, ManifestConfiguration.name)
    order = col.asc() if direction == "asc" else col.desc()

    total = db.query(sa_func.count(ManifestConfiguration.id)).scalar() or 0
    page_size = 10
    pagination = PaginationContext(page=page, page_size=page_size, total_items=total)
    if pagination.page > pagination.total_pages:
        pagination = PaginationContext(
            page=pagination.total_pages, page_size=page_size, total_items=total
        )

    configs = (
        db.query(ManifestConfiguration)
        .order_by(order)
        .offset((pagination.page - 1) * page_size)
        .limit(page_size)
        .all()
    )

    flash = get_flash_message(request)
    templates = request.app.state.templates
    return templates.TemplateResponse(
        request,
        "configurations/index.html",
        {
            "title": "Configurations",
            "user": user,
            "configurations": configs,
            "pagination": pagination,
            "sort": sort,
            "direction": direction,
            "flash": flash,
        },
    )


# ---------------------------------------------------------------------------
# Datastar SSE: Validate manifest location
# NOTE: Must be defined BEFORE parameterized routes like {config_id}
# ---------------------------------------------------------------------------


@router.post("/admin/configurations/validate-manifest")
async def validate_manifest_sse(
    request: Request,
    user: User = Depends(require_role("admin")),
) -> StreamingResponse:
    from datastar_py import SSE_HEADERS
    from datastar_py.consts import ElementPatchMode
    from datastar_py.sse import ServerSentEventGenerator as SSEGenerator

    form = dict(await request.form())

    bucket_name = form.get("bucket_name", "").strip()
    path_prefix = form.get("path_prefix", "").strip()
    object_name = form.get("object_name", "").strip()

    # Defaults
    if not object_name:
        object_name = "manifest.json"

    target_id = "validation-result"

    def _generate() -> Generator[str, None, None]:
        result = validate_gcs_manifest(bucket_name, path_prefix, object_name)
        templates = request.app.state.templates
        html = templates.get_template("configurations/_validation_result.html").render(
            result=result, target_id=target_id
        )

        yield str(
            SSEGenerator.patch_elements(
                html,
                selector=f"#{target_id}",
                mode=ElementPatchMode.OUTER,
            )
        )

    return StreamingResponse(_generate(), headers=SSE_HEADERS)


# ---------------------------------------------------------------------------
# Datastar SSE: Search buckets dropdown
# NOTE: Must be defined BEFORE parameterized routes like {config_id}
# ---------------------------------------------------------------------------


@router.get("/admin/configurations/search-buckets")
async def search_buckets_sse(
    request: Request,
    user: User = Depends(require_role("admin")),
    db: Session = Depends(get_session),
) -> StreamingResponse:
    from datastar_py import SSE_HEADERS
    from datastar_py.consts import ElementPatchMode
    from datastar_py.fastapi import read_signals
    from datastar_py.sse import ServerSentEventGenerator as SSEGenerator

    signals = await read_signals(request)
    query = (signals or {}).get("bucketSearch", "")
    current_value = (signals or {}).get("bucketCurrentValue", None)

    service = ManifestConfigurationService(db)
    try:
        results = service.search_buckets(query)
        if not query:
            results = results[:10]
        error = None
    except (GCPCredentialsError, GoogleCloudError) as exc:
        logger.warning("Bucket search failed: %s", exc)
        results = []
        error = str(exc)

    def _generate() -> Generator[str, None, None]:
        templates = request.app.state.templates
        html = templates.get_template("configurations/_bucket_results.html").render(
            results=results,
            query=query,
            error=error,
            current_value=current_value,
        )
        yield str(
            SSEGenerator.patch_elements(
                html,
                selector="#bucket-results",
                mode=ElementPatchMode.OUTER,
            )
        )

    return StreamingResponse(_generate(), headers=SSE_HEADERS)


# ---------------------------------------------------------------------------
# Datastar SSE: Search repos dropdown
# NOTE: Must be defined BEFORE parameterized routes like {config_id}
# ---------------------------------------------------------------------------


@router.get("/admin/configurations/search-repos")
async def search_repos_sse(
    request: Request,
    user: User = Depends(require_role("admin")),
    db: Session = Depends(get_session),
) -> StreamingResponse:
    from datastar_py import SSE_HEADERS
    from datastar_py.consts import ElementPatchMode
    from datastar_py.fastapi import read_signals
    from datastar_py.sse import ServerSentEventGenerator as SSEGenerator

    signals = await read_signals(request)
    query = (signals or {}).get("repoSearch", "")
    current_value = (signals or {}).get("repoCurrentValue", None)

    service = ManifestConfigurationService(db)
    github_configured = service.is_github_configured()

    if not github_configured:
        results = []
        error = None
    else:
        try:
            results = service.search_repos(query)
            if not query:
                results = results[:10]
            error = None
        except (GitHubAuthenticationError, GitHubConnectionError) as exc:
            logger.warning("Repo search failed: %s", exc)
            results = []
            error = str(exc)

    def _generate() -> Generator[str, None, None]:
        templates = request.app.state.templates
        html = templates.get_template("configurations/_repo_results.html").render(
            results=results,
            query=query,
            error=error,
            github_configured=github_configured,
            current_value=current_value,
        )
        yield str(
            SSEGenerator.patch_elements(
                html,
                selector="#repo-results",
                mode=ElementPatchMode.OUTER,
            )
        )

    return StreamingResponse(_generate(), headers=SSE_HEADERS)


# ---------------------------------------------------------------------------
# Datastar SSE: Search GCS paths dropdown
# NOTE: Must be defined BEFORE parameterized routes like {config_id}
# ---------------------------------------------------------------------------


@router.get("/admin/configurations/search-gcs-paths")
async def search_gcs_paths_sse(
    request: Request,
    user: User = Depends(require_role("admin")),
) -> StreamingResponse:
    from datastar_py import SSE_HEADERS
    from datastar_py.consts import ElementPatchMode
    from datastar_py.fastapi import read_signals
    from datastar_py.sse import ServerSentEventGenerator as SSEGenerator

    signals = await read_signals(request)
    bucket_value = (signals or {}).get("bucketValue", "")
    path_search = (signals or {}).get("pathSearch", "")

    def _generate() -> Generator[str, None, None]:
        templates = request.app.state.templates

        if not bucket_value:
            html = templates.get_template("configurations/_path_results.html").render(
                has_bucket=False
            )
        else:
            result = ManifestConfigurationService.search_gcs_paths(
                bucket_value, path_search
            )
            error = result.get("error")
            html = templates.get_template("configurations/_path_results.html").render(
                has_bucket=True,
                prefixes=result["prefixes"],
                current_prefix=result["current_prefix"],
                parent_prefix=result.get("parent_prefix", ""),
                bucket=bucket_value,
                error=error,
            )

        yield str(
            SSEGenerator.patch_elements(
                html,
                selector="#path-results",
                mode=ElementPatchMode.OUTER,
            )
        )

    return StreamingResponse(_generate(), headers=SSE_HEADERS)


# ---------------------------------------------------------------------------
# Sync status fragment
# NOTE: Must be defined BEFORE parameterized routes like {config_id}
# ---------------------------------------------------------------------------


@router.get(
    "/admin/configurations/{config_id}/sync-status", response_class=HTMLResponse
)
def get_sync_status_fragment(
    config_id: str,
    request: Request,
    user: User = Depends(require_role("admin")),
    db: Session = Depends(get_session),
) -> Response:
    if is_local_mode():
        return _redirect_local_sync_management(config_id)

    """Return the sync status fragment for auto-refresh."""
    from sqlalchemy.orm import joinedload
    from app.sync.models import SyncOperation

    # Get most recent sync (any status)
    sync = (
        db.query(SyncOperation)
        .options(joinedload(SyncOperation.errors))
        .filter(SyncOperation.config_id == config_id)
        .order_by(SyncOperation.queued_at.desc())
        .first()
    )

    templates = request.app.state.templates
    return templates.TemplateResponse(
        request,
        "sync/_sync_status_container.html",
        {
            "sync": sync,
            "config_id": config_id,
        },
    )


def _sync_history_order_by(sort: str, direction: str) -> object:
    """Return SQLAlchemy ORDER BY clause for sync history."""
    from app.sync.models import SyncOperation

    col_map = {
        "status": SyncOperation.status,
        "queued_at": SyncOperation.queued_at,
        "started_at": SyncOperation.started_at,
        "completed_at": SyncOperation.completed_at,
        "jobs": SyncOperation.jobs_retrieved_count,
        "manifests": SyncOperation.manifests_updated_count,
    }
    col = col_map.get(sort, SyncOperation.queued_at)
    return col.asc() if direction == "asc" else col.desc()


@router.get(
    "/admin/configurations/{config_id}/sync-history", response_class=HTMLResponse
)
def get_sync_history_fragment(
    config_id: str,
    request: Request,
    page: int = 1,
    sort: str = "queued_at",
    direction: str = "desc",
    user: User = Depends(require_role("admin")),
    db: Session = Depends(get_session),
) -> Response:
    if is_local_mode():
        return _redirect_local_sync_management(config_id)

    """Return paginated sync history fragment."""
    from sqlalchemy import func
    from sqlalchemy.orm import joinedload
    from app.sync.models import SyncOperation

    # Verify configuration exists
    service = ManifestConfigurationService(db)
    config = service.get_configuration(config_id)
    if not config:
        raise HTTPException(status_code=404, detail="Configuration not found.")

    # Pagination settings
    page_size = 10
    if page < 1:
        page = 1

    # Validate sort params
    valid_sorts = {
        "status",
        "queued_at",
        "started_at",
        "completed_at",
        "jobs",
        "manifests",
    }
    if sort not in valid_sorts:
        sort = "queued_at"
    if direction not in ("asc", "desc"):
        direction = "desc"

    # Get total count for pagination
    total_count = (
        db.query(func.count(SyncOperation.id))
        .filter(SyncOperation.config_id == config_id)
        .scalar()
    )
    total_pages = max(1, (total_count + page_size - 1) // page_size)

    # Get paginated sync history
    sync_history = (
        db.query(SyncOperation)
        .options(joinedload(SyncOperation.errors))
        .filter(SyncOperation.config_id == config_id)
        .order_by(_sync_history_order_by(sort, direction))
        .offset((page - 1) * page_size)
        .limit(page_size)
        .all()
    )

    templates = request.app.state.templates
    return templates.TemplateResponse(
        request,
        "sync/_sync_history.html",
        {
            "sync_history": sync_history,
            "config_id": config_id,
            "page": page,
            "total_pages": total_pages,
            "total_count": total_count,
            "sort": sort,
            "direction": direction,
        },
    )


# ---------------------------------------------------------------------------
# US7: View sync operation details with errors
# ---------------------------------------------------------------------------


@router.get("/admin/sync/{sync_id}", response_class=HTMLResponse)
def view_sync_detail(
    sync_id: str,
    request: Request,
    user: User = Depends(require_role("admin")),
    db: Session = Depends(get_session),
) -> Response:
    if is_local_mode():
        return _redirect_local_sync_management()

    """View detailed sync operation with errors (US7)."""
    from app.sync.service import SyncService

    sync_service = SyncService(db)
    sync = sync_service.get_sync_operation(sync_id)
    if not sync:
        raise HTTPException(status_code=404, detail="Sync operation not found.")

    # Get configuration for display
    service = ManifestConfigurationService(db)
    config = service.get_configuration(sync.config_id)

    templates = request.app.state.templates
    return templates.TemplateResponse(
        request,
        "sync/detail.html",
        {
            "title": f"Sync - {config.name if config else 'Unknown'}",
            "user": user,
            "sync": sync,
            "config": config,
        },
    )


# ---------------------------------------------------------------------------
# US5: View BigQuery jobs for configuration
# ---------------------------------------------------------------------------


@router.get("/admin/configurations/{config_id}/jobs", response_class=HTMLResponse)
def view_configuration_jobs(
    config_id: str,
    request: Request,
    page: int = 1,
    sort: str = "cost",
    direction: str = "desc",
    destination_table: str | None = None,
    workload_kind: str | None = None,
    start_date: str | None = None,
    end_date: str | None = None,
    user: User = Depends(require_role("admin")),
    db: Session = Depends(get_session),
) -> Response:
    """View BigQuery jobs for a configuration with filtering (US5)."""
    from app.sync.service import SyncService

    service = ManifestConfigurationService(db)
    config = service.get_configuration(config_id)
    if not config:
        raise HTTPException(status_code=404, detail="Configuration not found.")

    # Normalize empty strings to None for cleaner filter handling
    destination_table = destination_table.strip() if destination_table else None
    workload_kind = workload_kind.strip() if workload_kind else None
    start_date = start_date.strip() if start_date else None
    end_date = end_date.strip() if end_date else None
    if workload_kind not in {"build", "consumption"}:
        workload_kind = None

    # Validate sort params
    valid_sorts = {"table", "runs", "cost", "data", "latest"}
    if sort not in valid_sorts:
        sort = "cost"
    if direction not in ("asc", "desc"):
        direction = "desc"

    # Pagination settings
    page_size = 10
    if page < 1:
        page = 1

    sync_service = SyncService(db)

    # Get total count of table groups for pagination
    total_groups = sync_service.get_bigquery_jobs_group_count(
        config_id,
        destination_table=destination_table,
        workload_kind=workload_kind,
        start_date=start_date,
        end_date=end_date,
    )
    total_pages = max(1, (total_groups + page_size - 1) // page_size)

    # Get grouped jobs
    groups = sync_service.get_bigquery_jobs_grouped(
        config_id,
        limit=page_size,
        offset=(page - 1) * page_size,
        destination_table=destination_table,
        workload_kind=workload_kind,
        start_date=start_date,
        end_date=end_date,
        sort_by=sort,
        sort_direction=direction,
    )

    # Build filters dict for template
    filters = {
        "destination_table": destination_table or "",
        "workload_kind": workload_kind or "",
        "start_date": start_date or "",
        "end_date": end_date or "",
    }

    templates = request.app.state.templates
    return templates.TemplateResponse(
        request,
        "sync/jobs.html",
        {
            "title": f"Jobs - {config.name}",
            "user": user,
            "config": config,
            "groups": groups,
            "total_groups": total_groups,
            "page": page,
            "total_pages": total_pages,
            "filters": filters,
            "sort": sort,
            "direction": direction,
        },
    )


# ---------------------------------------------------------------------------
# US1: Create new configuration
# ---------------------------------------------------------------------------


@router.get("/admin/configurations/new", response_class=HTMLResponse)
def new_configuration(
    request: Request,
    mode: str | None = Query(None),
    user: User = Depends(require_role("admin")),
    db: Session = Depends(get_session),
) -> Response:
    creation_mode = _normalize_creation_mode(mode)
    templates = request.app.state.templates

    # In local mode, skip the mode selector — always use local
    if creation_mode is None and is_local_mode():
        creation_mode = "local"

    if creation_mode is None:
        return templates.TemplateResponse(
            request,
            "configurations/new_mode.html",
            {
                "title": "New Configuration",
                "user": user,
            },
        )

    service = ManifestConfigurationService(db)
    try:
        gcp_projects = service.get_available_gcp_projects()
    except (GCPCredentialsError, Exception) as exc:
        logger.warning("Failed to fetch GCP projects: %s", exc)
        gcp_projects = []

    return templates.TemplateResponse(
        request,
        "configurations/new.html",
        _build_new_configuration_form_context(
            user=user,
            gcp_projects=gcp_projects,
            form_data={"creation_mode": creation_mode},
        ),
    )


@router.post("/admin/configurations", response_class=HTMLResponse)
async def create_configuration(
    request: Request,
    user: User = Depends(require_role("admin")),
    db: Session = Depends(get_session),
) -> Response:
    form = await request.form()
    form_data = _form_to_template_data(form)
    creation_mode = _normalize_creation_mode(form_data.get("creation_mode"))
    if creation_mode is None:
        manifest_source = str(form_data.get("manifest_source", "gcs")).strip()
        creation_mode = (
            "local" if manifest_source in {"manual_upload", "local"} else "cloud"
        )
    form_data["creation_mode"] = creation_mode
    uploaded_manifest = form.get("manifest_file")
    manifest_bytes: bytes | None = None

    try:
        schedule_enabled = form.get("schedule_enabled") in ("true", "on", "True")

        # Parse advanced detection settings — empty/blank values become None (use defaults)
        raw_lookback = form.get("lookback_window_days", "").strip()
        lookback_window_days = int(raw_lookback) if raw_lookback else None

        raw_resolution = form.get("resolution_period_days", "").strip()
        resolution_period_days = int(raw_resolution) if raw_resolution else None

        raw_auto_pr = form.get("auto_pr_trust_tier", "").strip()
        auto_pr_trust_tier = raw_auto_pr if raw_auto_pr else None

        watched_rules_mode = str(form.get("watched_rules_mode", "all")).strip()
        if watched_rules_mode not in {"all", "custom"}:
            watched_rules_mode = "all"
        watched_rule_types = (
            None
            if watched_rules_mode == "all"
            else _coerce_to_str_list(form.getlist("watched_rule_types"))
        )

        solution_guardrails_mode = str(
            form.get("solution_guardrails_mode", "all")
        ).strip()
        if solution_guardrails_mode not in {"all", "custom"}:
            solution_guardrails_mode = "all"
        allowed_solution_policy_tags = (
            None
            if solution_guardrails_mode == "all"
            else _coerce_to_str_list(form.getlist("allowed_solution_policy_tags"))
        )

        # Cost display multiplier (org-level setting)
        raw_multiplier_create = form.get("cost_display_multiplier", "").strip()

        if creation_mode == "local":
            local_project_path = form.get("local_project_path") or None
            if uploaded_manifest is not None and getattr(
                uploaded_manifest, "filename", ""
            ):
                _MAX_MANIFEST_BYTES = 50 * 1024 * 1024  # 50 MB
                manifest_bytes = await uploaded_manifest.read(_MAX_MANIFEST_BYTES + 1)
                if len(manifest_bytes) > _MAX_MANIFEST_BYTES:
                    raise ManualManifestUploadError(
                        "Manifest file exceeds the 50 MB size limit."
                    )
                if not manifest_bytes:
                    raise ManualManifestUploadError("Uploaded manifest file is empty.")
            elif local_project_path:
                from app.workspace.detection import read_local_manifest

                manifest_bytes = read_local_manifest(local_project_path)
                if not manifest_bytes:
                    raise ManualManifestUploadError(
                        "No target/manifest.json found in the local dbt project folder. "
                        "Run 'dbt compile' or 'dbt build' first."
                    )
            else:
                raise ManualManifestUploadError(
                    "Upload a manifest.json file or set a local dbt project folder "
                    "to create a local configuration."
                )

        data = ManifestConfigurationCreate(
            gcp_project_id=form.get("gcp_project_id", ""),
            name=form.get("name") or None,
            github_repo=form.get("github_repo", ""),
            manifest_source=form.get(
                "manifest_source",
                "manual_upload" if creation_mode == "local" else "gcs",
            ),
            bucket_name=form.get("bucket_name", ""),
            path_prefix=form.get("path_prefix", ""),
            object_name=form.get("object_name", "manifest.json"),
            schedule_type=form.get("schedule_type", "interval"),
            schedule_value=form.get("schedule_value", "24"),
            schedule_enabled=schedule_enabled,
            lookback_window_days=lookback_window_days,
            resolution_period_days=resolution_period_days,
            auto_pr_trust_tier=auto_pr_trust_tier,
            local_project_path=form.get("local_project_path") or None,
            watched_rule_types=watched_rule_types,
            allowed_solution_policy_tags=allowed_solution_policy_tags,
        )
    except (ValidationError, ValueError, ManualManifestUploadError) as exc:
        service = ManifestConfigurationService(db)
        try:
            gcp_projects = service.get_available_gcp_projects()
        except GCPCredentialsError, GoogleCloudError:
            gcp_projects = []

        ctx = _service_error_to_context(exc, form_data)
        templates = request.app.state.templates
        return templates.TemplateResponse(
            request,
            "configurations/new.html",
            _build_new_configuration_form_context(
                user=user,
                gcp_projects=gcp_projects,
                form_data=ctx["form_data"],
                errors=ctx["errors"],
            ),
        )

    service = ManifestConfigurationService(db)
    scheduler = getattr(request.app.state, "scheduler", None)
    try:
        config = service.create_configuration(data, user.id, scheduler=scheduler)
        if creation_mode == "local" and manifest_bytes is not None:
            service.store_uploaded_manifest(
                config_id=config.id,
                manifest_bytes=manifest_bytes,
                user_id=user.id,
            )
    except (DuplicateLocationError, GCSValidationError, ConfigurationError) as exc:
        try:
            gcp_projects = service.get_available_gcp_projects()
        except GCPCredentialsError, GoogleCloudError:
            gcp_projects = []

        ctx = _service_error_to_context(exc, form_data)
        templates = request.app.state.templates
        return templates.TemplateResponse(
            request,
            "configurations/new.html",
            _build_new_configuration_form_context(
                user=user,
                gcp_projects=gcp_projects,
                form_data=ctx["form_data"],
                errors=ctx["errors"],
            ),
        )
    except ManualManifestUploadError as exc:
        try:
            service.delete_configuration(config.id)
        except ConfigurationError, SQLAlchemyError:
            pass  # Best-effort cleanup; config exists but has no manifest
        try:
            gcp_projects = service.get_available_gcp_projects()
        except GCPCredentialsError, GoogleCloudError:
            gcp_projects = []

        ctx = _service_error_to_context(exc, form_data)
        templates = request.app.state.templates
        return templates.TemplateResponse(
            request,
            "configurations/new.html",
            _build_new_configuration_form_context(
                user=user,
                gcp_projects=gcp_projects,
                form_data=ctx["form_data"],
                errors=ctx["errors"],
            ),
        )

    # Save cost display multiplier as org setting
    if raw_multiplier_create:
        try:
            mult_val = float(raw_multiplier_create)
            if 1 <= mult_val <= 10000:
                from app.settings.service import OrganisationSettingsService

                org_service = OrganisationSettingsService(db)
                org_service.set("cost_display_multiplier", str(int(mult_val)), user.id)
                set_cost_multiplier(mult_val)
        except ValueError, TypeError:
            pass

    return redirect_with_message(
        f"/admin/configurations/{config.id}",
        "Configuration created successfully.",
        "success",
    )


# ---------------------------------------------------------------------------
# US2: View / Edit configuration
# ---------------------------------------------------------------------------


@router.get("/admin/configurations/{config_id}", response_class=HTMLResponse)
def view_configuration(
    config_id: str,
    request: Request,
    page: int = 1,
    sort: str = "queued_at",
    direction: str = "desc",
    user: User = Depends(require_role("admin")),
    db: Session = Depends(get_session),
) -> Response:
    from sqlalchemy import func
    from sqlalchemy.orm import joinedload
    from app.sync.models import SyncOperation

    service = ManifestConfigurationService(db)
    config = service.get_configuration(config_id)
    if not config:
        raise HTTPException(status_code=404, detail="Configuration not found.")

    # Get most recent sync (any status) to show current state
    latest_sync = (
        db.query(SyncOperation)
        .options(joinedload(SyncOperation.errors))
        .filter(SyncOperation.config_id == config_id)
        .order_by(SyncOperation.queued_at.desc())
        .first()
    )

    # Pagination settings for sync history
    page_size = 10
    if page < 1:
        page = 1

    # Validate sort params
    valid_sorts = {
        "status",
        "queued_at",
        "started_at",
        "completed_at",
        "jobs",
        "manifests",
    }
    if sort not in valid_sorts:
        sort = "queued_at"
    if direction not in ("asc", "desc"):
        direction = "desc"

    # Get total count for pagination
    total_count = (
        db.query(func.count(SyncOperation.id))
        .filter(SyncOperation.config_id == config_id)
        .scalar()
    )
    total_pages = max(1, (total_count + page_size - 1) // page_size)

    # Get paginated sync history
    sync_history = (
        db.query(SyncOperation)
        .options(joinedload(SyncOperation.errors))
        .filter(SyncOperation.config_id == config_id)
        .order_by(_sync_history_order_by(sort, direction))
        .offset((page - 1) * page_size)
        .limit(page_size)
        .all()
    )

    # Get most recent completed sync for accordion header display
    last_completed_sync = (
        db.query(SyncOperation)
        .filter(
            SyncOperation.config_id == config_id,
            SyncOperation.status == "completed",
        )
        .order_by(SyncOperation.completed_at.desc())
        .first()
    )

    # Get last BigQuery jobs sync timestamp (completed with jobs > 0)
    last_jobs_sync_result = (
        db.query(SyncOperation.completed_at)
        .filter(
            SyncOperation.config_id == config_id,
            SyncOperation.status == "completed",
            SyncOperation.jobs_retrieved_count > 0,
        )
        .order_by(SyncOperation.completed_at.desc())
        .first()
    )
    last_jobs_sync_at = last_jobs_sync_result[0] if last_jobs_sync_result else None

    # Get last manifest change timestamp (completed with manifests > 0)
    last_manifest_result = (
        db.query(SyncOperation.completed_at)
        .filter(
            SyncOperation.config_id == config_id,
            SyncOperation.status == "completed",
            SyncOperation.manifests_updated_count > 0,
        )
        .order_by(SyncOperation.completed_at.desc())
        .first()
    )
    last_manifest_change_at = last_manifest_result[0] if last_manifest_result else None

    # Schedule description and next run time
    from app.scheduling.description import describe_schedule
    from app.scheduling.service import SchedulingService

    schedule_description = describe_schedule(
        config.schedule_type, config.schedule_value
    )
    scheduler = getattr(request.app.state, "scheduler", None)
    next_run_time = (
        SchedulingService.get_next_run_time(scheduler, config.id) if scheduler else None
    )

    flash = get_flash_message(request)
    local_runtime_mode = is_local_mode()
    templates = request.app.state.templates
    return templates.TemplateResponse(
        request,
        "configurations/detail.html",
        {
            "title": config.name,
            "user": user,
            "config": config,
            "active_sync": latest_sync,
            "sync_history": sync_history,
            "sync_history_page": page,
            "sync_history_total_pages": total_pages,
            "sync_history_total_count": total_count,
            "sync_history_sort": sort,
            "sync_history_direction": direction,
            "last_completed_sync": last_completed_sync,
            "last_jobs_sync_at": last_jobs_sync_at,
            "last_manifest_change_at": last_manifest_change_at,
            "schedule_description": schedule_description,
            "next_run_time": next_run_time,
            "errors": {},
            "flash": flash,
            "local_runtime_mode": local_runtime_mode,
            "cost_display_multiplier": get_cost_multiplier(),
            **_build_rule_selector_context(config=config),
            **_build_solution_policy_selector_context(config=config),
        },
    )


@router.post("/admin/configurations/{config_id}", response_class=HTMLResponse)
async def update_configuration(
    config_id: str,
    request: Request,
    user: User = Depends(require_role("admin")),
    db: Session = Depends(get_session),
) -> Response:
    form = await request.form()
    form_data = _form_to_template_data(form)
    post_update_action = str(form.get("post_update_action", "save")).strip()

    try:
        version = int(form.get("version", "0"))

        # Parse advanced settings — empty/blank values become None (use defaults)
        raw_lookback = form.get("lookback_window_days", "").strip()
        lookback_window_days = int(raw_lookback) if raw_lookback else None

        raw_resolution = form.get("resolution_period_days", "").strip()
        resolution_period_days = int(raw_resolution) if raw_resolution else None

        raw_auto_pr = form.get("auto_pr_trust_tier", "").strip()
        auto_pr_trust_tier = raw_auto_pr if raw_auto_pr else None

        raw_min_savings = form.get("storage_billing_min_savings_usd", "").strip()
        storage_billing_min_savings_usd = (
            float(raw_min_savings) if raw_min_savings else None
        )

        watched_rules_mode = str(form.get("watched_rules_mode", "all")).strip()
        if watched_rules_mode not in {"all", "custom"}:
            watched_rules_mode = "all"
        watched_rule_types = (
            None
            if watched_rules_mode == "all"
            else _coerce_to_str_list(form.getlist("watched_rule_types"))
        )

        solution_guardrails_mode = str(
            form.get("solution_guardrails_mode", "all")
        ).strip()
        if solution_guardrails_mode not in {"all", "custom"}:
            solution_guardrails_mode = "all"
        allowed_solution_policy_tags = (
            None
            if solution_guardrails_mode == "all"
            else _coerce_to_str_list(form.getlist("allowed_solution_policy_tags"))
        )

        # Cost display multiplier (org-level setting)
        raw_multiplier = form.get("cost_display_multiplier", "").strip()

        schedule_enabled = form.get("schedule_enabled") in ("true", "on", "True")
        data = ManifestConfigurationUpdate(
            name=form.get("name") or None,
            github_repo=form.get("github_repo", ""),
            manifest_source=form.get("manifest_source", "gcs"),
            bucket_name=form.get("bucket_name", ""),
            path_prefix=form.get("path_prefix", ""),
            object_name=form.get("object_name", "manifest.json"),
            version=version,
            lookback_window_days=lookback_window_days,
            resolution_period_days=resolution_period_days,
            auto_pr_trust_tier=auto_pr_trust_tier,
            local_project_path=form.get("local_project_path") or None,
            storage_billing_min_savings_usd=storage_billing_min_savings_usd,
            watched_rule_types=watched_rule_types,
            allowed_solution_policy_tags=allowed_solution_policy_tags,
            schedule_type=form.get("schedule_type", "interval"),
            schedule_value=form.get("schedule_value", "24"),
            schedule_enabled=schedule_enabled,
        )
    except (ValidationError, ValueError) as exc:
        service = ManifestConfigurationService(db)
        config = service.get_configuration(config_id)
        if not config:
            raise HTTPException(status_code=404, detail="Configuration not found.")
        ctx = _service_error_to_context(exc, form_data)
        sync_ctx = _get_sync_context(db, config_id)
        templates = request.app.state.templates
        return templates.TemplateResponse(
            request,
            "configurations/detail.html",
            {
                "title": config.name,
                "user": user,
                "config": config,
                "cost_display_multiplier": get_cost_multiplier(),
                "local_runtime_mode": is_local_mode(),
                **ctx,
                **sync_ctx,
                **_build_rule_selector_context(config=config, form_data=form_data),
                **_build_solution_policy_selector_context(
                    config=config, form_data=form_data
                ),
            },
        )

    service = ManifestConfigurationService(db)
    scheduler = getattr(request.app.state, "scheduler", None)
    try:
        config = service.update_configuration(
            config_id, data, user.id, scheduler=scheduler
        )
    except (
        NotFoundError,
        ConcurrencyError,
        DuplicateLocationError,
        GCSValidationError,
        ConfigurationError,
    ) as exc:
        config = service.get_configuration(config_id)
        if not config:
            raise HTTPException(status_code=404, detail="Configuration not found.")
        ctx = _service_error_to_context(exc, form_data)
        sync_ctx = _get_sync_context(db, config_id)
        templates = request.app.state.templates
        return templates.TemplateResponse(
            request,
            "configurations/detail.html",
            {
                "title": config.name,
                "user": user,
                "config": config,
                "cost_display_multiplier": get_cost_multiplier(),
                "local_runtime_mode": is_local_mode(),
                **ctx,
                **sync_ctx,
                **_build_rule_selector_context(config=config, form_data=form_data),
                **_build_solution_policy_selector_context(
                    config=config, form_data=form_data
                ),
            },
        )

    # Save cost display multiplier as org setting
    if raw_multiplier:
        try:
            mult_val = float(raw_multiplier)
            if 1 <= mult_val <= 10000:
                from app.settings.service import OrganisationSettingsService

                org_service = OrganisationSettingsService(db)
                org_service.set("cost_display_multiplier", str(int(mult_val)), user.id)
                set_cost_multiplier(mult_val)
        except ValueError, TypeError:
            pass  # Ignore invalid values, keep existing multiplier

    message = "Configuration updated successfully."
    level = "success"
    if post_update_action == "save_rerun_detection":
        if config.status != "active":
            message = (
                "Configuration updated, but detection was not re-run because the "
                "configuration is disabled."
            )
            level = "warning"
        else:
            from app.opportunities.service import OpportunityService

            opportunity_service = OpportunityService(db)
            try:
                rerun_job = opportunity_service.queue_detection_rerun_for_latest_sync(
                    config.id
                )
                db.commit()
                message = (
                    "Configuration updated and detection re-run queued using the "
                    "latest completed sync data."
                )
                logger.info(
                    "Queued detection rerun %s for config %s via configuration update",
                    rerun_job.id,
                    config.id,
                )
            except LatestCompletedSyncNotFoundError:
                db.rollback()
                message = (
                    "Configuration updated, but detection was not re-run because "
                    "there is no completed sync data yet."
                )
                level = "warning"
            except ActiveDetectionJobExistsError:
                db.rollback()
                message = (
                    "Configuration updated, but detection was not re-run because "
                    "the latest sync data is already queued or being processed."
                )
                level = "warning"

    return redirect_with_message(
        f"/admin/configurations/{config.id}",
        message,
        level,
    )


@router.post(
    "/admin/configurations/{config_id}/manifest-upload", response_class=HTMLResponse
)
async def upload_manifest(
    config_id: str,
    manifest_file: UploadFile = File(...),
    user: User = Depends(require_role("admin")),
    db: Session = Depends(get_session),
) -> Response:
    service = ManifestConfigurationService(db)

    MAX_MANIFEST_UPLOAD_BYTES = 50 * 1024 * 1024  # 50 MB
    try:
        payload = await manifest_file.read(MAX_MANIFEST_UPLOAD_BYTES + 1)
        if len(payload) > MAX_MANIFEST_UPLOAD_BYTES:
            return redirect_with_message(
                f"/admin/configurations/{config_id}",
                "Manifest file exceeds the 50 MB size limit.",
                "error",
            )
        _, created_new_version = service.store_uploaded_manifest(
            config_id=config_id,
            manifest_bytes=payload,
            user_id=user.id,
        )
    except NotFoundError:
        raise HTTPException(status_code=404, detail="Configuration not found.")
    except ManualManifestUploadError as exc:
        return redirect_with_message(
            f"/admin/configurations/{config_id}",
            str(exc),
            "error",
        )

    message = (
        "Manifest uploaded successfully."
        if created_new_version
        else "Uploaded manifest matched the latest stored version, so the existing manifest was kept."
    )
    return redirect_with_message(
        f"/admin/configurations/{config_id}",
        message,
        "success",
    )


# ---------------------------------------------------------------------------
# US4: Disable / Enable / Delete
# ---------------------------------------------------------------------------


@router.post("/admin/configurations/{config_id}/disable", response_class=HTMLResponse)
def disable_configuration(
    config_id: str,
    user: User = Depends(require_role("admin")),
    db: Session = Depends(get_session),
) -> Response:
    service = ManifestConfigurationService(db)
    try:
        service.disable_configuration(config_id, user.id)
    except NotFoundError:
        raise HTTPException(status_code=404, detail="Configuration not found.")
    return redirect_with_message(
        f"/admin/configurations/{config_id}",
        "Configuration disabled.",
        "info",
    )


@router.post("/admin/configurations/{config_id}/enable", response_class=HTMLResponse)
def enable_configuration(
    config_id: str,
    user: User = Depends(require_role("admin")),
    db: Session = Depends(get_session),
) -> Response:
    service = ManifestConfigurationService(db)
    try:
        service.enable_configuration(config_id, user.id)
    except NotFoundError:
        raise HTTPException(status_code=404, detail="Configuration not found.")
    except EnableWithoutGithubError as exc:
        return redirect_with_message(
            f"/admin/configurations/{config_id}",
            str(exc),
            "error",
        )
    return redirect_with_message(
        f"/admin/configurations/{config_id}",
        "Configuration enabled.",
        "success",
    )


@router.post("/admin/configurations/{config_id}/delete", response_class=HTMLResponse)
def delete_configuration(
    config_id: str,
    request: Request,
    user: User = Depends(require_role("admin")),
    db: Session = Depends(get_session),
) -> Response:
    # Remove APScheduler job before deleting config
    scheduler = getattr(request.app.state, "scheduler", None)
    if scheduler:
        from app.scheduling.service import SchedulingService

        SchedulingService.remove_schedule(scheduler, config_id)

    service = ManifestConfigurationService(db)
    try:
        service.delete_configuration(config_id)
    except NotFoundError:
        raise HTTPException(status_code=404, detail="Configuration not found.")
    return redirect_with_message(
        "/admin/configurations",
        "Configuration deleted.",
        "info",
    )
