from __future__ import annotations

import logging
import time
import threading
from datetime import timezone

from fastapi import APIRouter, Depends, Form, Request, status
from fastapi.responses import HTMLResponse, RedirectResponse
from sqlalchemy.orm import Session
from starlette.responses import Response

from app.auth.dependencies import get_active_session
from app.auth.service import AuthService
from app.core.config import get_settings
from app.db.session import get_session
from app.routes.helpers import get_flash_message, redirect_with_message

router = APIRouter()

# ---------------------------------------------------------------------------
# Simple in-memory login rate limiter
# ---------------------------------------------------------------------------
_login_attempts: dict[str, list[float]] = {}
_login_lock = threading.Lock()
_MAX_ATTEMPTS = 5  # max attempts per window
_WINDOW_SECONDS = 300  # 5 minute window


def _is_rate_limited(key: str) -> bool:
    """Return True if the key has exceeded the login attempt limit."""
    now = time.monotonic()
    with _login_lock:
        attempts = _login_attempts.get(key, [])
        # Prune expired entries
        attempts = [t for t in attempts if now - t < _WINDOW_SECONDS]
        _login_attempts[key] = attempts
        if len(attempts) >= _MAX_ATTEMPTS:
            return True
        attempts.append(now)
        return False


@router.post("/login", response_class=HTMLResponse)
def login_submit(
    request: Request,
    email: str = Form(...),
    password: str = Form(...),
    db: Session = Depends(get_session),
) -> Response:
    from app.core.config import is_local_mode

    if is_local_mode():
        return RedirectResponse("/dashboard", status_code=302)

    templates = request.app.state.templates

    # Rate limit by IP address
    client_ip = request.client.host if request.client else "unknown"
    if _is_rate_limited(client_ip):
        logging.getLogger("app.auth").warning(
            "login rate limited", extra={"ip": client_ip, "email": email},
        )
        return templates.TemplateResponse(
            request,
            "login.html",
            {
                "title": "Sign in",
                "flash": get_flash_message(request),
                "error": "Too many login attempts. Please try again in a few minutes.",
                "show_sidebar": False,
            },
            status_code=status.HTTP_429_TOO_MANY_REQUESTS,
        )

    auth_service = AuthService(db)
    user = auth_service.authenticate(email, password)
    if not user:
        existing = auth_service.find_user_by_email(email)
        auth_service.record_audit_event(
            existing.id if existing else None,
            "login",
            "failure",
            request.client.host if request.client else None,
            request.headers.get("user-agent"),
        )
        db.commit()
        logging.getLogger("app.auth").warning(
            "login failed",
            extra={"email": email},
        )
        return templates.TemplateResponse(
            request,
            "login.html",
            {
                "title": "Sign in",
                "flash": get_flash_message(request),
                "error": "Invalid credentials.",
                "show_sidebar": False,
            },
            status_code=status.HTTP_401_UNAUTHORIZED,
        )

    session = auth_service.create_session(
        user,
        request.client.host if request.client else None,
        request.headers.get("user-agent"),
    )
    cookie_expires = session.expires_at
    if cookie_expires is not None:
        if cookie_expires.tzinfo is None:
            cookie_expires = cookie_expires.replace(tzinfo=timezone.utc)
        else:
            cookie_expires = cookie_expires.astimezone(timezone.utc)
    settings = get_settings()
    response = RedirectResponse(url="/dashboard", status_code=status.HTTP_302_FOUND)
    response.set_cookie(
        settings.session_cookie_name,
        session.id,
        httponly=True,
        samesite="lax",
        secure=settings.session_cookie_secure,
        max_age=settings.session_ttl_hours * 3600,
        expires=cookie_expires,
    )
    logging.getLogger("app.auth").info(
        "login success",
        extra={"email": user.email},
    )
    return response


@router.post("/logout")
def logout(
    request: Request,
    db: Session = Depends(get_session),
    auth_session=Depends(get_active_session),
) -> RedirectResponse:
    from app.core.config import is_local_mode

    if is_local_mode():
        return RedirectResponse("/dashboard", status_code=302)

    if auth_session:
        auth_service = AuthService(db)
        auth_service.revoke_session(
            auth_session,
            request.client.host if request.client else None,
            request.headers.get("user-agent"),
        )
        logging.getLogger("app.auth").info(
            "logout success",
            extra={"user_id": auth_session.user_id},
        )
    response = redirect_with_message("/", "You have been signed out.", "info")
    settings = get_settings()
    response.delete_cookie(
        settings.session_cookie_name,
        secure=settings.session_cookie_secure,
        samesite="lax",
    )
    return response
