"""
Queue dashboard API and HTML routes.

Provides endpoints for viewing global sync queue status across all projects.
"""

from __future__ import annotations

import asyncio
import logging
from typing import AsyncGenerator

from fastapi import APIRouter, Depends, Request
from fastapi.responses import HTMLResponse, JSONResponse, StreamingResponse
from sqlalchemy.orm import Session
from starlette.responses import Response

from app.auth.dependencies import require_role
from app.auth.models import User
from app.core.config import is_local_mode
from app.db.session import get_session
from app.routes.helpers import redirect_local_mode_feature
from app.solutions.service import SolutionService
from app.sync.service import SyncService

logger = logging.getLogger("app.queue")

router = APIRouter()


def _redirect_local_queue_management() -> Response:
    return redirect_local_mode_feature(
        "/opportunities",
        feature_name="The sync queue",
        guidance="Use configurations and opportunity pages for local runs instead.",
    )


# ---------------------------------------------------------------------------
# US6: Global Queue Dashboard
# ---------------------------------------------------------------------------


@router.get("/dashboard", response_class=JSONResponse)
def get_queue_dashboard(
    user: User = Depends(require_role("admin")),
    db: Session = Depends(get_session),
) -> dict:
    if is_local_mode():
        return _redirect_local_queue_management()

    """Get global queue dashboard data.

    Returns all pending and running syncs, plus completed and failed syncs
    from the last 24 hours, grouped by status.

    Args:
        user: Authenticated admin user
        db: Database session

    Returns:
        JSON object with pending, running, completed, failed arrays and summary counts

    Status Codes:
        200: Success with queue data

    Specification Reference:
        FR-043: System MUST provide a global queue dashboard showing all sync operations.
        FR-044: System MUST display sync jobs grouped by status.
        FR-045: System MUST show job counts per status category.
        FR-046a: Queue dashboard MUST show all pending and running jobs, plus
                 completed and failed jobs from the last 24 hours.
    """
    sync_service = SyncService(db)
    dashboard = sync_service.get_queue_dashboard()

    # Convert to JSON-serializable format
    def sync_to_dict(sync) -> dict:
        duration_seconds = None
        if sync.started_at and sync.completed_at:
            duration_seconds = int(
                (sync.completed_at - sync.started_at).total_seconds()
            )
        elif sync.started_at:
            from datetime import datetime, timezone

            duration_seconds = int(
                (datetime.now(timezone.utc) - sync.started_at).total_seconds()
            )

        return {
            "id": sync.id,
            "config_id": sync.config_id,
            "config_name": getattr(sync, "config_name", "Unknown"),
            "status": sync.status,
            "queued_at": sync.queued_at.isoformat() if sync.queued_at else None,
            "started_at": sync.started_at.isoformat() if sync.started_at else None,
            "completed_at": sync.completed_at.isoformat()
            if sync.completed_at
            else None,
            "duration_seconds": duration_seconds,
            "jobs_retrieved_count": sync.jobs_retrieved_count,
            "manifests_updated_count": sync.manifests_updated_count,
            "error_count": len(sync.errors) if sync.errors else 0,
        }

    solution_service = SolutionService(db)
    solution_dashboard = solution_service.get_solution_jobs_dashboard()

    return {
        "pending": [sync_to_dict(s) for s in dashboard["pending"]],
        "running": [sync_to_dict(s) for s in dashboard["running"]],
        "completed": [sync_to_dict(s) for s in dashboard["completed"]],
        "failed": [sync_to_dict(s) for s in dashboard["failed"]],
        "summary": dashboard["summary"],
        "solution": solution_dashboard,
    }


@router.get("/dashboard/stream")
async def queue_dashboard_stream(
    user: User = Depends(require_role("admin")),
    db: Session = Depends(get_session),
) -> StreamingResponse:
    if is_local_mode():
        return _redirect_local_queue_management()

    """Stream real-time queue updates via Server-Sent Events.

    Polls queue status every 5 seconds and streams updates.

    Args:
        user: Authenticated admin user
        db: Database session

    Returns:
        SSE stream with queue dashboard updates

    Status Codes:
        200: Stream started
    """
    from datastar_py import SSE_HEADERS

    async def _generate_updates() -> AsyncGenerator[str, None]:
        """Generate SSE queue updates."""
        import json

        while True:
            sync_service = SyncService(db)
            dashboard = sync_service.get_queue_dashboard()

            solution_service = SolutionService(db)
            solution_dashboard = solution_service.get_solution_jobs_dashboard()

            # Send summary update
            event_data = {
                "pending_count": dashboard["summary"]["pending_count"],
                "running_count": dashboard["summary"]["running_count"],
                "completed_count": dashboard["summary"]["completed_count"],
                "failed_count": dashboard["summary"]["failed_count"],
                "solution": solution_dashboard,
            }

            yield "event: queue_update\n"
            yield f"data: {json.dumps(event_data)}\n\n"

            # Poll every 5 seconds
            await asyncio.sleep(5)

    return StreamingResponse(
        _generate_updates(),
        media_type="text/event-stream",
        headers=SSE_HEADERS,
    )


# ---------------------------------------------------------------------------
# HTML Routes
# ---------------------------------------------------------------------------


_PAGE_SIZE = 10


def _query_queue_section(
    db: Session,
    status_filter: str | list[str],
    page: int,
    sort_col: str,
    direction: str,
    sort_col_map: dict,
    time_cutoff=None,
) -> tuple:
    """Query a queue section with DB-level sorting and pagination."""
    from sqlalchemy.orm import joinedload

    from app.configurations.models import ManifestConfiguration
    from app.sync.models import SyncOperation
    from app.utils.pagination import PaginationContext

    statuses = [status_filter] if isinstance(status_filter, str) else status_filter
    base = db.query(SyncOperation).options(joinedload(SyncOperation.errors))

    base = base.filter(SyncOperation.status.in_(statuses))
    if time_cutoff is not None:
        base = base.filter(SyncOperation.completed_at >= time_cutoff)

    total = base.count()

    # Resolve sort column to an ORM attribute
    order_attr = sort_col_map.get(sort_col, sort_col_map.get("default"))
    if order_attr is not None:
        order_clause = order_attr.desc() if direction == "desc" else order_attr.asc()
        base = base.order_by(order_clause)

    pagination = PaginationContext(
        page=max(1, page), page_size=_PAGE_SIZE, total_items=total
    )
    if pagination.page > pagination.total_pages and pagination.total_pages > 0:
        pagination = PaginationContext(
            page=pagination.total_pages, page_size=_PAGE_SIZE, total_items=total
        )

    offset = (pagination.page - 1) * _PAGE_SIZE
    items = base.offset(offset).limit(_PAGE_SIZE).all()

    # Attach config_name to each sync (batch lookup)
    config_ids = {s.config_id for s in items if s.config_id}
    if config_ids:
        config_names = dict(
            db.query(ManifestConfiguration.id, ManifestConfiguration.name)
            .filter(ManifestConfiguration.id.in_(config_ids))
            .all()
        )
    else:
        config_names = {}
    for s in items:
        s.config_name = config_names.get(s.config_id, "Unknown")

    return items, pagination, total


@router.get("", response_class=HTMLResponse)
def view_queue_dashboard(
    request: Request,
    user: User = Depends(require_role("admin")),
    db: Session = Depends(get_session),
) -> Response:
    if is_local_mode():
        return _redirect_local_queue_management()

    """Render the queue dashboard HTML page."""
    from datetime import datetime, timedelta, timezone

    from app.sync.models import SyncOperation

    solution_service = SolutionService(db)
    solution_dashboard = solution_service.get_solution_jobs_dashboard()

    last_24h = datetime.now(timezone.utc) - timedelta(hours=24)

    # Per-section pagination + sort query params
    rp = int(request.query_params.get("rp", "1"))
    rs = request.query_params.get("rs", "started_at")
    rd = request.query_params.get("rd", "desc")

    pp = int(request.query_params.get("pp", "1"))
    ps = request.query_params.get("ps", "queued_at")
    pd_ = request.query_params.get("pd", "asc")

    cp = int(request.query_params.get("cp", "1"))
    cs = request.query_params.get("cs", "completed_at")
    cd = request.query_params.get("cd", "desc")

    fp = int(request.query_params.get("fp", "1"))
    fs = request.query_params.get("fs", "completed_at")
    fd = request.query_params.get("fd", "desc")

    # Sort column maps — map user-facing names to ORM columns
    running_col_map = {
        "started_at": SyncOperation.started_at,
        "jobs": SyncOperation.jobs_retrieved_count,
        "manifests": SyncOperation.manifests_updated_count,
        "default": SyncOperation.started_at,
    }
    pending_col_map = {
        "queued_at": SyncOperation.queued_at,
        "default": SyncOperation.queued_at,
    }
    completed_col_map = {
        "completed_at": SyncOperation.completed_at,
        "jobs": SyncOperation.jobs_retrieved_count,
        "manifests": SyncOperation.manifests_updated_count,
        "default": SyncOperation.completed_at,
    }
    failed_col_map = {
        "completed_at": SyncOperation.completed_at,
        "default": SyncOperation.completed_at,
    }

    running_page, running_pg, running_total = _query_queue_section(
        db,
        "in_progress",
        rp,
        rs,
        rd,
        running_col_map,
    )
    pending_page, pending_pg, pending_total = _query_queue_section(
        db,
        "queued",
        pp,
        ps,
        pd_,
        pending_col_map,
    )
    completed_page, completed_pg, completed_total = _query_queue_section(
        db,
        "completed",
        cp,
        cs,
        cd,
        completed_col_map,
        time_cutoff=last_24h,
    )
    failed_page, failed_pg, failed_total = _query_queue_section(
        db,
        "failed",
        fp,
        fs,
        fd,
        failed_col_map,
        time_cutoff=last_24h,
    )

    # Build summary counts from the totals (avoids loading all rows)
    summary = {
        "pending_count": pending_total,
        "running_count": running_total,
        "completed_count": completed_total,
        "failed_count": failed_total,
    }

    templates = request.app.state.templates
    return templates.TemplateResponse(
        request,
        "sync/queue_dashboard.html",
        {
            "title": "Sync Queue Dashboard",
            "user": user,
            "running": running_page,
            "running_pg": running_pg,
            "running_total": running_total,
            "rs": rs,
            "rd": rd,
            "pending": pending_page,
            "pending_pg": pending_pg,
            "pending_total": pending_total,
            "ps": ps,
            "pd": pd_,
            "completed": completed_page,
            "completed_pg": completed_pg,
            "completed_total": completed_total,
            "cs": cs,
            "cd": cd,
            "failed": failed_page,
            "failed_pg": failed_pg,
            "failed_total": failed_total,
            "fs": fs,
            "fd": fd,
            "summary": summary,
            "solution": solution_dashboard,
        },
    )
