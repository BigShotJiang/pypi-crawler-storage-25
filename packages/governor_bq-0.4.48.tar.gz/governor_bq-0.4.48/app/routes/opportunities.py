"""
Routes for the cross-project Opportunity Explorer.

Provides the main /opportunities page load and SSE filter endpoint.
"""

from __future__ import annotations

from collections.abc import Generator
from datetime import datetime, timedelta, timezone

from fastapi import APIRouter, Depends, Query, Request
from fastapi.responses import HTMLResponse, JSONResponse, StreamingResponse
from sqlalchemy import func
from sqlalchemy.orm import Session
from starlette.responses import Response

from app.auth.dependencies import get_current_user
from app.auth.models import User
from app.configurations.models import ManifestConfiguration
from app.core.config import is_local_mode
from app.db.session import get_session
from app.opportunities.explorer_service import OpportunityExplorerService
from app.opportunities.models import Opportunity
from app.routes.helpers import get_flash_message
from app.solutions.models import Solution

router = APIRouter(tags=["opportunities"])

_TOP_OPPORTUNITIES_LIMIT = 10


def _parse_list(value: str) -> list[str]:
    """Split comma-separated string into a list, filtering empty strings."""
    return [v.strip() for v in value.split(",") if v.strip()] if value else []


def _normalize_filter_label(value: str) -> str:
    """Normalize a user-facing filter label for fallback matching."""
    return " ".join(value.strip().lower().replace("_", " ").split())


def _normalize_status_value(
    value: str, *, collapse_pending_states: bool = False
) -> str:
    """Normalize status values coming from URLs or select labels."""
    normalized = _normalize_filter_label(value)
    status_map = {
        "active": "active",
        "clearing": "pr_pending" if collapse_pending_states else "clearing",
        "resolved": "resolved",
        "pr pending": "pr_pending",
        "pr_pending": "pr_pending",
        "local change pending": "pr_pending",
        "pending verification": "pr_pending" if collapse_pending_states else "clearing",
        "all": "all",
    }
    return status_map.get(normalized, "all")


def _normalize_smart_view_value(value: str) -> str:
    """Normalize smart-view values from URLs or select labels."""
    normalized = _normalize_filter_label(value)
    view_map = {
        "": "",
        "all active": "",
        "all views": "",
        "quick wins": "quick-wins",
        "quick-wins": "quick-wins",
        "chronic issues": "chronic",
        "chronic": "chronic",
        "unaddressed": "unaddressed",
    }
    return view_map.get(normalized, "")


def _resolve_project_filters(db: Session, values: list[str]) -> list[str]:
    """Resolve project filter tokens as config IDs or config names."""
    if not values:
        return []

    project_rows = (
        db.query(ManifestConfiguration.id, ManifestConfiguration.name)
        .filter(ManifestConfiguration.status == "active")
        .all()
    )
    ids_by_name = {row.name.lower(): row.id for row in project_rows}
    valid_ids = {row.id for row in project_rows}

    resolved: list[str] = []
    for value in values:
        if value in valid_ids:
            resolved.append(value)
            continue
        normalized = value.strip().lower()
        if normalized in {"", "all projects"}:
            continue
        resolved_id = ids_by_name.get(normalized)
        if resolved_id:
            resolved.append(resolved_id)

    return list(dict.fromkeys(resolved))


def _resolve_type_filters(values: list[str], available_types: list[str]) -> list[str]:
    """Resolve type filter tokens as raw keys or display labels."""
    if not values:
        return []

    valid_types = set(available_types)
    types_by_label = {
        _normalize_filter_label(type_name): type_name for type_name in available_types
    }

    resolved: list[str] = []
    for value in values:
        if value in valid_types:
            resolved.append(value)
            continue
        normalized = _normalize_filter_label(value)
        if normalized in {"", "all types"}:
            continue
        resolved_type = types_by_label.get(normalized)
        if resolved_type:
            resolved.append(resolved_type)

    return list(dict.fromkeys(resolved))


def _parse_date_params(
    days: int, date_start: str, date_end: str
) -> tuple[datetime | None, datetime | None]:
    """Convert date parameters to datetime objects.

    Custom dates override days preset.
    """
    start_dt = None
    end_dt = None

    # Custom dates take priority
    if date_start:
        try:
            start_dt = datetime.fromisoformat(date_start).replace(tzinfo=timezone.utc)
        except ValueError:
            pass
    if date_end:
        try:
            end_dt = datetime.fromisoformat(date_end).replace(tzinfo=timezone.utc)
            # Set to end of day
            end_dt = end_dt.replace(hour=23, minute=59, second=59)
        except ValueError:
            pass

    # If no custom dates, check days preset
    if not start_dt and not end_dt and days and days > 0:
        start_dt = datetime.now(timezone.utc) - timedelta(days=days)

    return start_dt, end_dt


def _signal_or_query(
    *,
    signals: dict,
    request: Request,
    signal_name: str,
    default="",
    query_names: tuple[str, ...] = (),
) -> object:
    """Read a Datastar signal, with fallback to plain query params.

    The explorer UI should send Datastar JSON state, but accepting the raw
    query-string names makes the SSE endpoint resilient to request-shape drift.
    """
    if signal_name in signals:
        value = signals.get(signal_name)
        return default if value is None else value

    for query_name in query_names:
        if query_name in request.query_params:
            return request.query_params.get(query_name, default)

    return default


@router.get("/opportunities", response_class=HTMLResponse)
def opportunity_explorer(
    request: Request,
    db: Session = Depends(get_session),
    user: User = Depends(get_current_user),
    search: str = Query(default=""),
    status: str = Query(default="all"),
    projects: str = Query(default=""),
    types: str = Query(default=""),
    sort: str = Query(default="cost"),
    direction: str = Query(default="desc"),
    group: str = Query(default="flat"),
    view: str = Query(default=""),
    date_start: str = Query(default=""),
    date_end: str = Query(default=""),
    days: int = Query(default=0),
    page: int = Query(default=1, ge=1),
) -> Response:
    """Main Opportunity Explorer page."""
    svc = OpportunityExplorerService(db)
    local_runtime_mode = is_local_mode()

    # Parse filter parameters
    project_ids = _parse_list(projects)
    type_names = _parse_list(types)
    start_dt, end_dt = _parse_date_params(days, date_start, date_end)

    # Validate sort/direction/status
    if sort not in (
        "project",
        "type",
        "table",
        "severity",
        "cost",
        "savings",
        "status",
        "age",
        "occurrence",
    ):
        sort = "cost"
    if direction not in ("asc", "desc"):
        direction = "desc"
    status = _normalize_status_value(
        status,
        collapse_pending_states=local_runtime_mode,
    )
    if group not in ("flat", "project", "type"):
        group = "flat"

    # Get filter options
    available_projects = svc.get_available_projects()
    available_types = svc.get_available_types()
    project_ids = _resolve_project_filters(db, project_ids)
    type_names = _resolve_type_filters(type_names, available_types)
    view = _normalize_smart_view_value(view)

    # Common filter kwargs
    filter_kwargs = dict(
        search=search,
        status=status,
        project_ids=project_ids or None,
        type_names=type_names or None,
        smart_view=view,
        date_start=start_dt,
        date_end=end_dt,
        collapse_pending_states=local_runtime_mode,
    )

    # Summary cards
    summary = svc.get_summary_cards(**filter_kwargs)

    # Check for running background jobs (sync, detection, solution generation)
    from app.opportunities.models import DetectionJob
    from app.solutions.models import SolutionJob
    from app.sync.models import SyncOperation

    active_statuses = ["queued", "in_progress"]
    running_syncs = (
        db.query(func.count())
        .filter(SyncOperation.status.in_(active_statuses))
        .scalar()
        or 0
    )
    running_detections = (
        db.query(func.count()).filter(DetectionJob.status.in_(active_statuses)).scalar()
        or 0
    )
    running_solutions = (
        db.query(func.count()).filter(SolutionJob.status.in_(active_statuses)).scalar()
        or 0
    )
    background_jobs_running = running_syncs + running_detections + running_solutions

    # Content based on grouping mode
    if group in ("project", "type"):
        groups = svc.get_grouped_opportunities(
            group_by=group,
            sort_column=sort,
            sort_direction=direction,
            **filter_kwargs,
        )
        opportunities = None
        pagination = None
    else:
        opportunities, pagination = svc.query_opportunities(
            sort_column=sort,
            sort_direction=direction,
            page=page,
            **filter_kwargs,
        )
        groups = None

    context = {
        "title": "Opportunities",
        "user": user,
        "flash": get_flash_message(request),
        "available_projects": available_projects,
        "available_types": available_types,
        "opportunities": opportunities,
        "pagination": pagination,
        "groups": groups,
        "summary": summary,
        "running_solutions": running_solutions,
        "background_jobs_running": background_jobs_running,
        "running_syncs": running_syncs,
        "running_detections": running_detections,
        "signals": {
            "search": search,
            "status": status,
            "projects": projects,
            "types": types,
            "sort": sort,
            "direction": direction,
            "group": group,
            "smart_view": view,
            "date_start": date_start,
            "date_end": date_end,
            "days": days,
            "page": page,
        },
        "local_runtime_mode": local_runtime_mode,
    }

    templates = request.app.state.templates
    return templates.TemplateResponse(request, "opportunities/index.html", context)


@router.get("/opportunities/bg-jobs-status")
def bg_jobs_status(
    db: Session = Depends(get_session),
    user: User = Depends(get_current_user),
) -> JSONResponse:
    """Return JSON count of active background jobs for polling."""
    from sqlalchemy import func

    from app.opportunities.models import DetectionJob
    from app.solutions.models import SolutionJob
    from app.sync.models import SyncOperation

    active_statuses = ["queued", "in_progress"]
    syncs = (
        db.query(func.count())
        .filter(SyncOperation.status.in_(active_statuses))
        .scalar()
        or 0
    )
    detections = (
        db.query(func.count()).filter(DetectionJob.status.in_(active_statuses)).scalar()
        or 0
    )
    solutions = (
        db.query(func.count()).filter(SolutionJob.status.in_(active_statuses)).scalar()
        or 0
    )
    return JSONResponse(
        {
            "syncs": syncs,
            "detections": detections,
            "solutions": solutions,
            "total": syncs + detections + solutions,
        }
    )


@router.get("/opportunities/filter")
async def filter_opportunities_sse(
    request: Request,
    db: Session = Depends(get_session),
    user: User = Depends(get_current_user),
) -> StreamingResponse:
    """SSE endpoint for live filtering of opportunities."""
    from datastar_py import SSE_HEADERS
    from datastar_py.consts import ElementPatchMode
    from datastar_py.fastapi import read_signals
    from datastar_py.sse import ServerSentEventGenerator as SSEGenerator

    signals = await read_signals(request)
    signals = signals or {}
    local_runtime_mode = is_local_mode()

    # Extract signals with defaults
    search = str(
        _signal_or_query(
            signals=signals,
            request=request,
            signal_name="expSearch",
            default="",
            query_names=("expSearch", "search"),
        )
    ).strip()
    status = str(
        _signal_or_query(
            signals=signals,
            request=request,
            signal_name="expStatus",
            default="all",
            query_names=("expStatus", "status"),
        )
    )
    projects_str = str(
        _signal_or_query(
            signals=signals,
            request=request,
            signal_name="expProjects",
            default="",
            query_names=("expProjects", "projects"),
        )
    )
    types_str = str(
        _signal_or_query(
            signals=signals,
            request=request,
            signal_name="expTypes",
            default="",
            query_names=("expTypes", "types"),
        )
    )
    sort_col = str(
        _signal_or_query(
            signals=signals,
            request=request,
            signal_name="expSort",
            default="table",
            query_names=("expSort", "sort"),
        )
    )
    sort_dir = str(
        _signal_or_query(
            signals=signals,
            request=request,
            signal_name="expDirection",
            default="asc",
            query_names=("expDirection", "direction"),
        )
    )
    group_mode = str(
        _signal_or_query(
            signals=signals,
            request=request,
            signal_name="expGroup",
            default="flat",
            query_names=("expGroup", "group"),
        )
    )
    smart_view = str(
        _signal_or_query(
            signals=signals,
            request=request,
            signal_name="expSmartView",
            default="",
            query_names=("expSmartView", "view"),
        )
    )
    date_start_str = str(
        _signal_or_query(
            signals=signals,
            request=request,
            signal_name="expDateStart",
            default="",
            query_names=("expDateStart", "date_start"),
        )
    )
    date_end_str = str(
        _signal_or_query(
            signals=signals,
            request=request,
            signal_name="expDateEnd",
            default="",
            query_names=("expDateEnd", "date_end"),
        )
    )
    exp_page = _signal_or_query(
        signals=signals,
        request=request,
        signal_name="expPage",
        default=1,
        query_names=("expPage", "page"),
    )

    try:
        exp_days = int(
            _signal_or_query(
                signals=signals,
                request=request,
                signal_name="expDays",
                default=0,
                query_names=("expDays", "days"),
            )
        )
    except TypeError, ValueError:
        exp_days = 0

    try:
        exp_page = int(exp_page)
    except TypeError, ValueError:
        exp_page = 1
    if exp_page < 1:
        exp_page = 1

    # Parse filters
    project_ids = _parse_list(projects_str)
    type_names = _parse_list(types_str)
    start_dt, end_dt = _parse_date_params(exp_days, date_start_str, date_end_str)

    # Validate
    if sort_col not in (
        "project",
        "type",
        "table",
        "severity",
        "cost",
        "savings",
        "status",
        "age",
        "occurrence",
    ):
        sort_col = "cost"
    if sort_dir not in ("asc", "desc"):
        sort_dir = "desc"
    status = _normalize_status_value(
        status,
        collapse_pending_states=local_runtime_mode,
    )
    if group_mode not in ("flat", "project", "type"):
        group_mode = "flat"

    svc = OpportunityExplorerService(db)
    available_types = svc.get_available_types()
    project_ids = _resolve_project_filters(db, project_ids)
    type_names = _resolve_type_filters(type_names, available_types)
    smart_view = _normalize_smart_view_value(smart_view)

    filter_kwargs = dict(
        search=search,
        status=status,
        project_ids=project_ids or None,
        type_names=type_names or None,
        smart_view=smart_view,
        date_start=start_dt,
        date_end=end_dt,
        collapse_pending_states=local_runtime_mode,
    )

    # Summary cards
    summary = svc.get_summary_cards(**filter_kwargs)
    from app.solutions.models import SolutionJob

    running_solutions = (
        db.query(func.count())
        .filter(SolutionJob.status.in_(["queued", "in_progress"]))
        .scalar()
        or 0
    )

    # Content
    if group_mode in ("project", "type"):
        groups = svc.get_grouped_opportunities(
            group_by=group_mode,
            sort_column=sort_col,
            sort_direction=sort_dir,
            **filter_kwargs,
        )
        content_template = "opportunities/_grouped.html"
        content_context = {"groups": groups}
    else:
        opportunities, pagination = svc.query_opportunities(
            sort_column=sort_col,
            sort_direction=sort_dir,
            page=exp_page,
            **filter_kwargs,
        )
        content_template = "opportunities/_table.html"
        content_context = {"opportunities": opportunities, "pagination": pagination}

    def _generate() -> Generator[str, None, None]:
        templates = request.app.state.templates

        # Patch summary cards
        summary_html = templates.get_template(
            "opportunities/_summary_cards.html"
        ).render(
            summary=summary,
            running_solutions=running_solutions,
            local_runtime_mode=local_runtime_mode,
        )
        yield str(
            SSEGenerator.patch_elements(
                summary_html,
                selector="#explorer-summary",
                mode=ElementPatchMode.OUTER,
            )
        )

        # Patch content area
        content_html = templates.get_template(content_template).render(
            **content_context,
            local_runtime_mode=local_runtime_mode,
        )
        yield str(
            SSEGenerator.patch_elements(
                content_html,
                selector="#explorer-content",
                mode=ElementPatchMode.OUTER,
            )
        )

    return StreamingResponse(_generate(), headers=SSE_HEADERS)
