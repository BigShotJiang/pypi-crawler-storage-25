from __future__ import annotations

from fastapi import APIRouter, Depends, Request
from fastapi.responses import HTMLResponse, RedirectResponse
from starlette.responses import Response

from app.auth.dependencies import get_optional_user
from app.routes.helpers import get_flash_message

router = APIRouter()


@router.get("/", response_class=HTMLResponse)
def homepage(
    request: Request,
    user=Depends(get_optional_user),
) -> HTMLResponse:
    templates = request.app.state.templates
    return templates.TemplateResponse(
        request,
        "home.html",
        {
            "title": "Governor",
            "flash": get_flash_message(request),
            "user": user,
            "show_sidebar": False,
        },
    )


@router.get("/login", response_class=HTMLResponse)
def login_page(request: Request) -> Response:
    from app.core.config import is_local_mode

    if is_local_mode():
        return RedirectResponse("/dashboard", status_code=302)

    templates = request.app.state.templates
    return templates.TemplateResponse(
        request,
        "login.html",
        {
            "title": "Sign in",
            "flash": get_flash_message(request),
            "show_sidebar": False,
        },
    )
