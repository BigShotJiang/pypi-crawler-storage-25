from __future__ import annotations

import logging
from datetime import datetime, timedelta, timezone

from fastapi import APIRouter, Depends, Request
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse
from sqlalchemy import case, false, func, or_
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.orm import Session
from starlette.responses import Response

from app.auth import models
from app.auth.dependencies import get_active_session
from app.db.session import get_session
from app.routes.helpers import get_flash_message, redirect_with_message
from app.utils.pagination import PaginationContext

logger = logging.getLogger("app.routes.pull_requests")

router = APIRouter()


def _get_authenticated_user(
    request: Request, db: Session, auth_session
) -> models.User | None:
    """Validate session and return the current user or None."""
    if not auth_session:
        return None
    user = (
        db.query(models.User)
        .filter(models.User.id == auth_session.user_id)
        .one_or_none()
    )
    if not user:
        return None
    return user


def _redirect_local_pr_workflow() -> RedirectResponse:
    return redirect_with_message(
        "/opportunities",
        "Pull request pages are not used in local mode. Review and apply fixes from opportunity pages instead.",
        "info",
    )


@router.get("/prs", response_class=HTMLResponse)
def pull_requests(
    request: Request,
    db: Session = Depends(get_session),
    auth_session=Depends(get_active_session),
) -> Response:
    """Pull requests overview page."""
    from app.core.config import is_local_mode
    from app.pullrequests.models import PullRequestRecord

    user = _get_authenticated_user(request, db, auth_session)
    if not user:
        return redirect_with_message("/login", "Please sign in to continue.", "warning")
    if is_local_mode():
        return _redirect_local_pr_workflow()

    # Sort options
    sort_options = {
        "created_at": PullRequestRecord.created_at,
        "updated_at": PullRequestRecord.updated_at,
        "pr_number": PullRequestRecord.pr_number,
        "repository": PullRequestRecord.repository,
    }
    sort_by = request.query_params.get("sort", "created_at")
    sort_dir = request.query_params.get("dir", "desc")
    if sort_by not in sort_options:
        sort_by = "created_at"
    if sort_dir not in {"asc", "desc"}:
        sort_dir = "desc"

    # Project filter: map config_id → repo via ManifestConfiguration
    from app.configurations.models import ManifestConfiguration

    project_filter = request.query_params.get("project", "")
    projects = (
        db.query(
            ManifestConfiguration.id,
            ManifestConfiguration.name,
            ManifestConfiguration.github_repo,
        )
        .filter(
            ManifestConfiguration.github_repo.isnot(None),
            ManifestConfiguration.github_repo != "",
            ManifestConfiguration.status == "active",
        )
        .order_by(ManifestConfiguration.name)
        .all()
    )

    page = max(1, int(request.query_params.get("page", "1")))
    page_size = 10

    query = db.query(PullRequestRecord).filter(
        PullRequestRecord.status.in_(["merged", "open"])
    )

    if project_filter:
        # Find the repo for this config
        selected_config = (
            db.query(ManifestConfiguration.github_repo)
            .filter(ManifestConfiguration.id == project_filter)
            .scalar()
        )
        if selected_config:
            query = query.filter(PullRequestRecord.repository == selected_config)

    total = query.count()
    pagination = PaginationContext(page=page, page_size=page_size, total_items=total)
    if pagination.page > pagination.total_pages and pagination.total_pages > 0:
        pagination = PaginationContext(
            page=pagination.total_pages, page_size=page_size, total_items=total
        )

    sort_column = sort_options[sort_by]
    order_clause = sort_column.desc() if sort_dir == "desc" else sort_column.asc()
    status_priority = case(
        (PullRequestRecord.status == "merged", 0),
        (PullRequestRecord.status == "open", 1),
        else_=2,
    )
    rows = (
        query.order_by(status_priority.asc(), order_clause, PullRequestRecord.id.desc())
        .offset((pagination.page - 1) * page_size)
        .limit(page_size)
        .all()
    )

    pr_list = []
    for pr in rows:
        pr_list.append(
            {
                "id": pr.id,
                "pr_number": pr.pr_number,
                "pr_url": pr.pr_url,
                "repository": pr.repository,
                "branch_name": pr.branch_name,
                "status": pr.status,
                "created_at": pr.created_at,
                "updated_at": pr.updated_at,
                "merged_at": pr.merged_at,
            }
        )

    templates = request.app.state.templates
    return templates.TemplateResponse(
        request,
        "prs/list.html",
        {
            "title": "Pull Requests",
            "flash": get_flash_message(request),
            "user": user,
            "prs": pr_list,
            "sort_by": sort_by,
            "sort_dir": sort_dir,
            "pagination": pagination,
            "projects": [{"id": p.id, "name": p.name} for p in projects],
            "project_filter": project_filter,
        },
    )


def _build_pr_lineage_graph(
    manifest: dict,
    root_model_name: str,
    max_downstream: int = 4,
    include_upstream: bool = False,
) -> dict | None:
    """Build lineage graph data for PR visualization.

    By default this focuses on downstream impact: the changed model and its
    downstream dependents. Upstream lineage can be enabled for exploratory
    views, but it is omitted here because upstream costs are not directly
    impacted by the model change.
    Returns {nodes, edges, root_name, chart_height, counts} or None if trivial.
    """
    from collections import defaultdict, deque

    all_nodes = manifest.get("nodes", {})
    child_map = manifest.get("child_map", {})

    root_uid: str | None = None
    for uid, node in all_nodes.items():
        if uid.startswith("model.") and node.get("name") == root_model_name:
            root_uid = uid
            break
    if not root_uid:
        return None

    graph_nodes: dict[str, dict] = {}
    edge_list: list[dict] = []
    edge_set: set[tuple[str, str]] = set()

    def _upsert(uid: str, data: dict, depth: int, side: str, ntype: str) -> None:
        current = graph_nodes.get(uid)
        if current and current["depth"] <= depth and current["side"] == side:
            return
        graph_nodes[uid] = {
            "id": uid,
            "name": data.get("name") or uid.split(".")[-1],
            "model_name": data.get("name") or uid.split(".")[-1],
            "relation_name": data.get("relation_name") or "",
            "depth": depth,
            "side": side,
            "type": ntype,
        }

    def _add_edge(src: str, tgt: str) -> None:
        key = (src, tgt)
        if key not in edge_set:
            edge_set.add(key)
            edge_list.append({"source": src, "target": tgt})

    _upsert(root_uid, all_nodes[root_uid], 0, "root", "root")

    if include_upstream:
        # BFS upstream via depends_on (models + sources)
        upstream_queue: deque = deque([(root_uid, 0)])
        upstream_seen: dict[str, int] = {root_uid: 0}
        while upstream_queue:
            uid, depth = upstream_queue.popleft()
            if depth >= 3:
                continue
            node = all_nodes.get(uid) or {}
            for parent_uid in node.get("depends_on", {}).get("nodes", []):
                if not (
                    parent_uid.startswith("model.") or parent_uid.startswith("source.")
                ):
                    continue
                parent_data = all_nodes.get(parent_uid)
                if not parent_data:
                    continue
                parent_depth = depth + 1
                if upstream_seen.get(parent_uid, 10**9) <= parent_depth:
                    continue
                upstream_seen[parent_uid] = parent_depth
                parent_type = (
                    "source" if parent_uid.startswith("source.") else "upstream"
                )
                _upsert(parent_uid, parent_data, parent_depth, "upstream", parent_type)
                _add_edge(parent_uid, uid)
                if parent_uid.startswith("model."):
                    upstream_queue.append((parent_uid, parent_depth))

    # BFS downstream via child_map only
    queue: deque = deque([(root_uid, 0)])
    downstream_seen: dict[str, int] = {root_uid: 0}
    while queue:
        uid, depth = queue.popleft()
        if depth >= max_downstream:
            continue
        for child_uid in child_map.get(uid, []):
            if not child_uid.startswith("model."):
                continue
            child_data = all_nodes.get(child_uid)
            if not child_data:
                continue
            child_depth = depth + 1
            if downstream_seen.get(child_uid, 10**9) <= child_depth:
                continue
            downstream_seen[child_uid] = child_depth
            _upsert(child_uid, child_data, child_depth, "downstream", "downstream")
            _add_edge(uid, child_uid)
            queue.append((child_uid, child_depth))

    if len(graph_nodes) <= 1:
        return None

    # Assign x/y positions (left-to-right by depth, centered vertically per column)
    depth_groups: dict[tuple[str, int], list[str]] = defaultdict(list)
    for uid in graph_nodes:
        node = graph_nodes[uid]
        side = node["side"]
        depth_groups[(side, node["depth"])].append(uid)

    col_w, row_h = 220, 80
    for (side, depth), uids in depth_groups.items():
        n = len(uids)
        for j, uid in enumerate(uids):
            if side == "upstream":
                graph_nodes[uid]["x"] = -depth * col_w
            elif side == "downstream":
                graph_nodes[uid]["x"] = depth * col_w
            else:
                graph_nodes[uid]["x"] = 0
            graph_nodes[uid]["y"] = int((j - (n - 1) / 2.0) * row_h)

    max_per_col = max(len(v) for v in depth_groups.values())
    chart_height = max(280, max_per_col * row_h + 60)
    source_count = sum(1 for n in graph_nodes.values() if n["type"] == "source")
    upstream_count = sum(1 for n in graph_nodes.values() if n["side"] == "upstream")
    downstream_count = sum(1 for n in graph_nodes.values() if n["side"] == "downstream")

    return {
        "nodes": sorted(
            graph_nodes.values(),
            key=lambda n: (
                {"root": 0, "upstream": 1, "downstream": 2}.get(n["side"], 3),
                n["depth"],
                n["name"],
            ),
        ),
        "edges": sorted(edge_list, key=lambda e: (e["source"], e["target"])),
        "root_name": root_model_name,
        "chart_height": chart_height,
        "source_count": source_count,
        "upstream_count": upstream_count,
        "downstream_count": downstream_count,
    }


def _relation_name_match_clause(column, relation_name: str) -> object:
    """Return a SQLAlchemy filter matching a relation name robustly."""
    cleaned = relation_name.replace("`", "").strip().lower()
    if not cleaned:
        return false()

    clauses = [func.lower(column) == cleaned]
    if "." in cleaned:
        clauses.append(func.lower(column) == cleaned.replace(".", ":", 1))

    model_name = cleaned.split(".")[-1]
    if model_name:
        clauses.append(func.lower(column).like(f"%.{model_name}"))
        clauses.append(func.lower(column).like(f"%:{model_name}"))

    return or_(*clauses)


def _load_model_cost_trend(
    db: Session,
    config_id: str,
    relation_name: str,
    window_start: datetime,
    window_end: datetime,
) -> list[dict]:
    """Load per-run cost trend rows for a given model relation."""
    from decimal import Decimal

    from app.sync.models import BigQueryJob

    if not relation_name:
        return []

    jobs = (
        db.query(
            BigQueryJob.creation_time,
            BigQueryJob.total_bytes_billed,
            BigQueryJob.job_id,
        )
        .filter(
            BigQueryJob.config_id == config_id,
            _relation_name_match_clause(BigQueryJob.destination_table, relation_name),
            BigQueryJob.creation_time >= window_start,
            BigQueryJob.creation_time < window_end,
            BigQueryJob.job_state == "DONE",
            BigQueryJob.cache_hit.isnot(True),
            BigQueryJob.total_bytes_billed.isnot(None),
        )
        .order_by(BigQueryJob.creation_time)
        .all()
    )

    bq_cost_per_byte = Decimal("6.25") / Decimal(str(1024**4))
    return [
        {
            "date": job.creation_time.strftime("%Y-%m-%d %H:%M"),
            "day": job.creation_time.strftime("%Y-%m-%d"),
            "cost": round(
                float(Decimal(str(job.total_bytes_billed)) * bq_cost_per_byte), 6
            ),
        }
        for job in jobs
    ]


def _get_pr_trend_window(pr) -> tuple[datetime, datetime, str | None]:
    """Return the trend window used on the PR detail page."""
    merged_at_str = None
    merge_date = pr.merged_at
    if merge_date:
        if merge_date.tzinfo is None:
            merge_date = merge_date.replace(tzinfo=timezone.utc)
        merged_at_str = merge_date.strftime("%Y-%m-%d")
        return (
            merge_date - timedelta(days=30),
            min(merge_date + timedelta(days=30), datetime.now(timezone.utc)),
            merged_at_str,
        )

    window_end = datetime.now(timezone.utc)
    return window_end - timedelta(days=30), window_end, merged_at_str


def _resolve_relation_name_for_pr_model(
    db: Session, config_id: str, relation_name: str
) -> str:
    """Resolve a short model name to its manifest relation name when possible."""
    if "." in relation_name or relation_name.startswith("`"):
        return relation_name

    from app.sync.models import ManifestVersion

    manifest_version = (
        db.query(ManifestVersion)
        .filter(ManifestVersion.config_id == config_id)
        .order_by(ManifestVersion.retrieved_at.desc())
        .first()
    )
    if not manifest_version or not manifest_version.content:
        return relation_name

    nodes = manifest_version.content.get("nodes", {})
    for uid, node in nodes.items():
        if not uid.startswith("model."):
            continue
        if node.get("name") == relation_name and node.get("relation_name"):
            return str(node["relation_name"])
    return relation_name


@router.get("/prs/{pr_id}/model-cost-trend")
def pr_model_cost_trend(
    request: Request,
    pr_id: str,
    relation_name: str,
    db: Session = Depends(get_session),
    auth_session=Depends(get_active_session),
) -> JSONResponse:
    """Return merge-window cost trend JSON for a specific model relation."""
    from app.opportunities.models import Opportunity
    from app.pullrequests.models import PullRequestRecord

    user = _get_authenticated_user(request, db, auth_session)
    if not user:
        return JSONResponse({"error": "unauthorized"}, status_code=401)

    pr = db.query(PullRequestRecord).filter(PullRequestRecord.id == pr_id).one_or_none()
    if not pr or not pr.opportunity_id:
        return JSONResponse({"data": []})

    opp = (
        db.query(Opportunity).filter(Opportunity.id == pr.opportunity_id).one_or_none()
    )
    if not opp:
        return JSONResponse({"data": []})

    resolved_relation_name = _resolve_relation_name_for_pr_model(
        db, opp.config_id, relation_name
    )
    window_start, window_end, _ = _get_pr_trend_window(pr)
    data = _load_model_cost_trend(
        db,
        opp.config_id,
        resolved_relation_name,
        window_start,
        window_end,
    )
    model_name = resolved_relation_name.replace("`", "").strip().split(".")[-1]
    return JSONResponse({"data": data, "model_name": model_name})


@router.get("/prs/{pr_id}", response_class=HTMLResponse)
def pr_detail(
    request: Request,
    pr_id: str,
    db: Session = Depends(get_session),
    auth_session=Depends(get_active_session),
) -> Response:
    """PR detail page with cost trend chart."""
    from app.core.config import is_local_mode
    from app.configurations.models import ManifestConfiguration
    from app.opportunities.models import Opportunity
    from app.pullrequests.models import PullRequestRecord
    from app.sync.models import BigQueryJob

    user = _get_authenticated_user(request, db, auth_session)
    if not user:
        return redirect_with_message("/login", "Please sign in to continue.", "warning")
    if is_local_mode():
        return _redirect_local_pr_workflow()

    pr = db.query(PullRequestRecord).filter(PullRequestRecord.id == pr_id).one_or_none()
    if not pr:
        return redirect_with_message("/prs", "Pull request not found.", "warning")

    opp = None
    if pr.opportunity_id:
        opp = (
            db.query(Opportunity)
            .filter(Opportunity.id == pr.opportunity_id)
            .one_or_none()
        )

    # For collected PRs without a linked opportunity, try to match via changed file names
    # against known dbt model names in opportunities for the same repository
    pr_model_names: list[str] = []
    if not opp:
        import os
        import re

        try:
            from app.setup.runtime import create_github_client

            gh = create_github_client()
            if gh is not None:
                pr_files = gh.get_pull_request_files(pr.repository, pr.pr_number)
                # Extract model names from SQL file paths (e.g. models/staging/stg_foo.sql -> stg_foo)
                model_names = set()
                for f in pr_files:
                    fname = os.path.basename(f["filename"])
                    if fname.endswith(".sql"):
                        model_names.add(re.sub(r"\.sql$", "", fname))
                pr_model_names = sorted(model_names)

                if model_names:
                    # Find the first matching opportunity by dbt_model_name
                    matched = (
                        db.query(Opportunity)
                        .filter(Opportunity.dbt_model_name.in_(model_names))
                        .first()
                    )
                    if matched:
                        opp = matched
        except RuntimeError, SQLAlchemyError:
            pass  # Best-effort matching — fall through to no cost data

    repo_config_count = 0
    if not opp:
        repo_config_count = (
            db.query(func.count())
            .select_from(ManifestConfiguration)
            .filter(ManifestConfiguration.github_repo == pr.repository)
            .scalar()
            or 0
        )

    config = (
        db.query(ManifestConfiguration)
        .filter(ManifestConfiguration.id == opp.config_id)
        .one_or_none()
        if opp
        else None
    )

    # Build per-run cost trend data for the affected table
    cost_trend = []
    trend_window_start: datetime | None = None
    trend_window_end: datetime | None = None
    merged_at_str = None
    if opp and opp.affected_table:
        trend_window_start, trend_window_end, merged_at_str = _get_pr_trend_window(pr)

        cost_trend = _load_model_cost_trend(
            db,
            opp.config_id,
            opp.affected_table,
            trend_window_start,
            trend_window_end,
        )

    # Build verified savings info
    verified_data = None
    if opp and opp.verified_savings_status:
        verified_data = {
            "status": opp.verified_savings_status,
            "verified_savings": opp.verified_savings,
            "pre_merge_avg_cost": opp.pre_merge_avg_cost,
            "post_merge_avg_cost": opp.post_merge_avg_cost,
            "pre_merge_job_count": opp.pre_merge_job_count or 0,
            "post_merge_job_count": opp.post_merge_job_count or 0,
        }
    verified_comparison = None
    if (
        verified_data
        and verified_data["pre_merge_avg_cost"] is not None
        and verified_data["post_merge_avg_cost"] is not None
    ):
        pre_merge_avg = verified_data["pre_merge_avg_cost"]
        post_merge_avg = verified_data["post_merge_avg_cost"]
        verified_comparison = {
            "pre_label": "Pre-merge average",
            "post_label": "Post-merge average",
            "pre_cost": float(pre_merge_avg),
            "post_cost": float(post_merge_avg),
            "verified_savings": float(pre_merge_avg - post_merge_avg),
            "pre_job_count": verified_data["pre_merge_job_count"],
            "post_job_count": verified_data["post_merge_job_count"],
        }

    # Build cost history table with cumulative savings
    cost_history = []
    if cost_trend and merged_at_str:
        pre_merge_costs = [d["cost"] for d in cost_trend if d["day"] < merged_at_str]
        pre_merge_avg = (
            sum(pre_merge_costs) / len(pre_merge_costs) if pre_merge_costs else 0
        )
        cumulative_savings = 0.0
        for entry in cost_trend:
            row = {
                "date": entry["date"],
                "cost": entry["cost"],
                "is_post_merge": entry["day"] >= merged_at_str,
                "is_merge_date": entry["day"] == merged_at_str,
            }
            if entry["day"] >= merged_at_str:
                saving = pre_merge_avg - entry["cost"]
                cumulative_savings += saving
                row["saving"] = round(saving, 6)
                row["cumulative_savings"] = round(cumulative_savings, 6)
            cost_history.append(row)
    elif cost_trend:
        for entry in cost_trend:
            cost_history.append(
                {
                    "date": entry["date"],
                    "cost": entry["cost"],
                    "is_post_merge": False,
                    "is_merge_date": False,
                }
            )

    # Build diff data from linked solution(s) or fetch from GitHub
    from app.solutions.models import Solution
    from app.utils.diff import generate_code_diff, parse_github_patch

    solution_diffs = []
    diff_error = None
    if pr.solution_id:
        # Get all solutions for the same opportunity (multi-file PRs)
        solutions = (
            db.query(Solution)
            .filter(Solution.opportunity_id == pr.opportunity_id)
            .order_by(Solution.file_path)
            .all()
        )
        for sol in solutions:
            if sol.before_content and sol.after_content:
                diff_lines = generate_code_diff(sol.before_content, sol.after_content)
                solution_diffs.append(
                    {"file_path": sol.file_path, "diff_lines": diff_lines}
                )
            elif sol.after_content:
                # New file — show all as additions
                diff_lines = generate_code_diff("", sol.after_content)
                solution_diffs.append(
                    {"file_path": sol.file_path, "diff_lines": diff_lines}
                )
    else:
        # No local solution — fetch diff from GitHub API
        try:
            from app.setup.runtime import create_github_client

            github_client = create_github_client()
            if github_client is not None:
                pr_files = github_client.get_pull_request_files(
                    pr.repository, pr.pr_number
                )
                for f in pr_files:
                    if f["patch"]:
                        diff_lines = parse_github_patch(f["patch"])
                        solution_diffs.append(
                            {"file_path": f["filename"], "diff_lines": diff_lines}
                        )
        except RuntimeError as exc:
            import logging

            logging.getLogger("app.routes.app").warning(
                "Failed to fetch PR diff from GitHub for PR #%d: %s",
                pr.pr_number,
                exc,
            )
            diff_error = str(exc)

    # ── Downstream lineage cost impact ──────────────────────────────────────
    lineage_impact = None
    lineage_available = False
    lineage_unavailable_reason: str | None = None

    if pr.solution_id and opp:
        try:
            from app.dbt.affected_column import (
                extract_affected_partition_cluster_column,
            )
            from app.pullrequests.lineage_impact import (
                DownstreamLineageAnalyzer,
                build_summary,
                build_summary_from_results,
                results_to_json,
            )
            from app.pullrequests.models import PrLineageImpact
            from app.sync.models import BigQueryJob, ManifestVersion

            from app.solutions.models import Solution as _Solution

            primary_solution = db.get(_Solution, pr.solution_id)

            col_result = None
            if primary_solution:
                col_result = extract_affected_partition_cluster_column(
                    primary_solution.before_content or "",
                    primary_solution.after_content or "",
                )

            if col_result:
                affected_column, change_type = col_result

                # Get the latest manifest version for this config
                manifest_version = (
                    db.query(ManifestVersion)
                    .filter(ManifestVersion.config_id == opp.config_id)
                    .order_by(ManifestVersion.retrieved_at.desc())
                    .first()
                )

                if manifest_version:
                    # Check cache
                    cached = (
                        db.query(PrLineageImpact)
                        .filter_by(
                            pr_id=pr.id,
                            manifest_version_id=manifest_version.id,
                        )
                        .one_or_none()
                    )

                    if cached:
                        lineage_impact = build_summary(cached, pr)
                        lineage_available = True
                    else:
                        # Compute — wrap in OTel span if tracer available
                        def _query_jobs(relation_name: str) -> list[dict]:
                            from datetime import timedelta

                            cutoff = datetime.now(timezone.utc) - timedelta(days=90)
                            jobs = (
                                db.query(BigQueryJob)
                                .filter(
                                    BigQueryJob.config_id == opp.config_id,
                                    _relation_name_match_clause(
                                        BigQueryJob.destination_table,
                                        relation_name,
                                    ),
                                    BigQueryJob.job_state == "DONE",
                                    BigQueryJob.cache_hit.isnot(True),
                                    BigQueryJob.total_bytes_billed.isnot(None),
                                    BigQueryJob.query.isnot(None),
                                    BigQueryJob.creation_time >= cutoff,
                                )
                                .order_by(BigQueryJob.creation_time.desc())
                                .limit(200)
                                .all()
                            )
                            return [
                                {
                                    "job_id": j.job_id,
                                    "query": j.query,
                                    "total_bytes_billed": j.total_bytes_billed,
                                    "total_cost": float(j.total_cost)
                                    if j.total_cost
                                    else 0.0,
                                    "creation_time": j.creation_time,
                                }
                                for j in jobs
                            ]

                        analyzer = DownstreamLineageAnalyzer(
                            manifest_content=manifest_version.content,
                            bigquery_jobs_query=_query_jobs,
                        )

                        root_model_name = opp.dbt_model_name or ""
                        results = analyzer.compute(
                            root_model_name=root_model_name,
                            affected_column=affected_column,
                            change_type=change_type,
                        )

                        summary = build_summary_from_results(
                            pr=pr,
                            manifest_version=manifest_version,
                            results=results,
                            affected_column=affected_column,
                            change_type=change_type,
                            root_model_name=root_model_name,
                        )

                        # Persist cache entry
                        cache_entry = PrLineageImpact(
                            pr_id=pr.id,
                            manifest_version_id=manifest_version.id,
                            affected_model_name=root_model_name,
                            affected_column=affected_column,
                            change_type=change_type,
                            total_estimated_savings=summary.total_estimated_savings,
                            beneficiary_count=summary.beneficiary_count,
                            total_downstream_count=summary.total_downstream_count,
                            impact_results=results_to_json(results),
                        )
                        db.add(cache_entry)
                        db.commit()

                        lineage_impact = summary
                        lineage_available = True
                else:
                    lineage_unavailable_reason = (
                        "Manifest not configured or not yet synced"
                    )
            else:
                lineage_unavailable_reason = (
                    "No partition or cluster change detected in this PR"
                )
        except (SQLAlchemyError, ValueError, KeyError) as _lineage_exc:
            import logging as _logging

            _logging.getLogger("app.routes.app").debug(
                "Lineage impact computation failed for PR %s", pr.id, exc_info=True
            )
            lineage_unavailable_reason = "Lineage analysis unavailable"
    else:
        if not opp and pr_model_names:
            if repo_config_count > 0:
                lineage_unavailable_reason = (
                    "No matching Governor opportunity found for PR file(s): "
                    + ", ".join(pr_model_names)
                )
            else:
                lineage_unavailable_reason = (
                    f"No Governor configuration found for repository {pr.repository}"
                )
        elif not pr.solution_id:
            lineage_unavailable_reason = (
                lineage_unavailable_reason or "No linked solution — diff not available"
            )
        else:
            lineage_unavailable_reason = (
                lineage_unavailable_reason or "No linked opportunity"
            )

    # ── Visual lineage graph (shown for any PR with opportunity + manifest) ──
    lineage_graph = None
    if opp and opp.config_id and opp.dbt_model_name:
        try:
            from app.sync.models import ManifestVersion as _ManifestVersion

            _mv = (
                db.query(_ManifestVersion)
                .filter(_ManifestVersion.config_id == opp.config_id)
                .order_by(_ManifestVersion.retrieved_at.desc())
                .first()
            )
            if _mv and _mv.content:
                lineage_graph = _build_pr_lineage_graph(_mv.content, opp.dbt_model_name)
        except SQLAlchemyError, ValueError, KeyError:
            pass  # best-effort; graph section simply won't render

    model_cost_trends: list[dict] = []
    selected_trend_key = "root"
    if opp and opp.affected_table:
        root_label = opp.dbt_model_name or opp.affected_table.split(".")[-1]
        root_trend = cost_trend
        root_entry = {
            "key": "root",
            "model_name": root_label,
            "relation_name": opp.affected_table,
            "label": root_label,
            "is_root": True,
            "included": True,
            "depth": 0,
            "estimated_monthly_cost_usd": None,
            "trend": root_trend,
            "sample_count": len(root_trend),
            "latest_cost": root_trend[-1]["cost"] if root_trend else None,
            "max_cost": max((point["cost"] for point in root_trend), default=None),
            "min_cost": min((point["cost"] for point in root_trend), default=None),
        }
        model_cost_trends.append(root_entry)
        selected_trend_key = root_entry["key"]

        if lineage_impact:
            for result in lineage_impact.results:
                if not result.relation_name:
                    continue
                trend_rows = _load_model_cost_trend(
                    db,
                    opp.config_id,
                    result.relation_name,
                    trend_window_start
                    or datetime.now(timezone.utc) - timedelta(days=30),
                    trend_window_end or datetime.now(timezone.utc),
                )
                model_cost_trends.append(
                    {
                        "key": result.relation_name,
                        "model_name": result.model_name,
                        "relation_name": result.relation_name,
                        "label": result.model_name,
                        "is_root": False,
                        "included": result.included,
                        "depth": result.depth,
                        "estimated_monthly_cost_usd": (
                            float(result.estimated_monthly_cost_usd)
                            if result.estimated_monthly_cost_usd is not None
                            else None
                        ),
                        "confidence": result.confidence,
                        "trend": trend_rows,
                        "sample_count": len(trend_rows),
                        "latest_cost": trend_rows[-1]["cost"] if trend_rows else None,
                        "max_cost": max(
                            (point["cost"] for point in trend_rows), default=None
                        ),
                        "min_cost": min(
                            (point["cost"] for point in trend_rows), default=None
                        ),
                    }
                )

    templates = request.app.state.templates
    return templates.TemplateResponse(
        request,
        "prs/detail.html",
        {
            "title": f"PR #{pr.pr_number}",
            "flash": get_flash_message(request),
            "user": user,
            "pr": pr,
            "opportunity": opp,
            "config": config,
            "cost_trend": cost_trend,
            "cost_history": cost_history,
            "merged_at_str": merged_at_str,
            "verified_data": verified_data,
            "verified_comparison": verified_comparison,
            "solution_diffs": solution_diffs,
            "diff_error": diff_error,
            "lineage_impact": lineage_impact,
            "lineage_available": lineage_available,
            "lineage_unavailable_reason": lineage_unavailable_reason,
            "lineage_graph": lineage_graph,
            "model_cost_trends": model_cost_trends,
            "selected_trend_key": selected_trend_key,
        },
    )


@router.get("/admin/prs", response_class=HTMLResponse)
def admin_prs_redirect() -> RedirectResponse:
    """Backward-compat redirect: /admin/prs → /prs."""
    from app.core.config import is_local_mode

    if is_local_mode():
        return _redirect_local_pr_workflow()
    return RedirectResponse(url="/prs", status_code=301)


@router.get("/admin/prs/{pr_id}", response_class=HTMLResponse)
def admin_pr_detail_redirect(pr_id: str) -> RedirectResponse:
    """Backward-compat redirect: /admin/prs/{id} → /prs/{id}."""
    from app.core.config import is_local_mode

    if is_local_mode():
        return _redirect_local_pr_workflow()
    return RedirectResponse(url=f"/prs/{pr_id}", status_code=301)
