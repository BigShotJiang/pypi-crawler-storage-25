"""Compatibility shims for Google SDKs under newer Python versions."""

from __future__ import annotations

import sys
import typing


def apply_google_sdk_py314_compat() -> None:
    """Avoid google-genai's deprecated ``_UnionGenericAlias`` usage on Py3.14.

    google-genai currently evaluates ``typing._UnionGenericAlias`` during
    import, which raises a DeprecationWarning on Python 3.14+. Pointing that
    private alias at ``typing.Union`` preserves the SDK's runtime behaviour
    for our usage and removes the warning without filtering it.
    """
    if sys.version_info < (3, 14):
        return

    if getattr(typing, "_UnionGenericAlias", None) is not typing.Union:
        typing._UnionGenericAlias = typing.Union
