/**
 * Dashboard Charts - ECharts initialization for cost analytics.
 * Uses shared ChartUtils for colours, formatters, and axis styling.
 */

(function() {
  'use strict';

  // Initialize trend chart
  function initTrendChart() {
    var container = document.getElementById('trend-chart');
    if (!container) return null;

    var trendData = container.dataset.trend;
    if (!trendData) return null;

    var data;
    try {
      data = JSON.parse(trendData);
    } catch (e) {
      console.error('Failed to parse trend data:', e);
      return null;
    }

    if (!data || data.length === 0) return null;

    var existingChart = echarts.getInstanceByDom(container);
    if (existingChart) existingChart.dispose();

    var isDark = ChartUtils.isDarkMode();
    var theme = isDark ? 'dark' : null;
    var chart = echarts.init(container, theme, { renderer: 'canvas' });

    var axis = ChartUtils.getAxisStyle(isDark);
    var costColor = ChartUtils.getSeriesColor('cost');
    var emphasisColor = ChartUtils.getEmphasisColor();
    var secondaryColor = ChartUtils.BRAND_COLORS.secondary;
    var buildColor = ChartUtils.getSeriesColor('build');
    var consumptionColor = ChartUtils.getSeriesColor('consumption');
    var costLabel = container.dataset.costLabel || 'Spend';
    var buildLabel = container.dataset.buildLabel || 'Build Spend';
    var consumptionLabel = container.dataset.consumptionLabel || 'Consumption Spend';
    var jobLabel = container.dataset.jobLabel || 'Jobs';
    var selectedLens = container.dataset.lens || 'all';
    var isAllLens = selectedLens === 'all';

    var dates = data.map(function(d) { return d.date; });
    var costs = data.map(function(d) { return d.cost; });
    var buildCosts = data.map(function(d) { return d.build_cost || 0; });
    var consumptionCosts = data.map(function(d) { return d.consumption_cost || 0; });
    var jobs = data.map(function(d) { return d.jobs; });

    function findSeriesValue(params, name) {
      var match = params.find(function(item) { return item.seriesName === name; });
      return match ? Number(match.value || 0) : 0;
    }

    var option = {
      backgroundColor: 'transparent',
      tooltip: {
        trigger: 'axis',
        formatter: function(params) {
          var date = ChartUtils.formatDate(params[0].axisValue);
          var lines = ['<strong>' + date + '</strong>'];
          if (isAllLens) {
            var buildValue = findSeriesValue(params, buildLabel + ' ($)');
            var consumptionValue = findSeriesValue(params, consumptionLabel + ' ($)');
            var totalValue = buildValue + consumptionValue;
            var jobsValue = findSeriesValue(params, jobLabel);
            lines.push(buildLabel + ': ' + ChartUtils.formatCurrency(buildValue));
            lines.push(consumptionLabel + ': ' + ChartUtils.formatCurrency(consumptionValue));
            lines.push('Total Spend: ' + ChartUtils.formatCurrency(totalValue));
            lines.push(jobLabel + ': ' + ChartUtils.formatNumber(jobsValue));
            return lines.join('<br/>');
          }
          var cost = params[0] ? ChartUtils.formatCurrency(params[0].value) : '$0.00';
          var jobCount = params[1] ? ChartUtils.formatNumber(params[1].value) : '0';
          return '<strong>' + date + '</strong><br/>' + costLabel + ': ' + cost + '<br/>' + jobLabel + ': ' + jobCount;
        }
      },
      legend: {
        data: isAllLens
          ? [buildLabel + ' ($)', consumptionLabel + ' ($)', jobLabel]
          : [costLabel + ' ($)', jobLabel],
        textStyle: { color: axis.textColor, fontSize: 11 },
        top: 0
      },
      grid: { left: 50, right: 50, top: 35, bottom: 25 },
      xAxis: {
        type: 'category',
        data: dates,
        axisLabel: {
          fontSize: 10,
          color: axis.textColor,
          rotate: dates.length > 14 ? 45 : 0,
          formatter: function(value) { return ChartUtils.formatDate(value); }
        },
        axisLine: { lineStyle: { color: axis.lineColor } },
        splitLine: { show: false }
      },
      yAxis: [
        {
          type: 'value', name: costLabel + ' ($)',
          nameTextStyle: { color: axis.textColor, fontSize: 10 },
          axisLabel: { fontSize: 10, color: axis.textColor, formatter: function(v) { return ChartUtils.formatCurrency(v); } },
          splitLine: { lineStyle: { color: axis.splitColor } }
        },
        {
          type: 'value', name: jobLabel,
          nameTextStyle: { color: axis.textColor, fontSize: 10 },
          axisLabel: { fontSize: 10, color: axis.textColor },
          splitLine: { show: false }
        }
      ],
      animation: false,
      series: isAllLens
        ? [
            { name: buildLabel + ' ($)', type: 'bar', stack: 'spend', data: buildCosts, itemStyle: { color: buildColor }, emphasis: { itemStyle: { color: emphasisColor } }, barMaxWidth: 20, yAxisIndex: 0 },
            { name: consumptionLabel + ' ($)', type: 'bar', stack: 'spend', data: consumptionCosts, itemStyle: { color: consumptionColor }, emphasis: { itemStyle: { color: consumptionColor } }, barMaxWidth: 20, yAxisIndex: 0 },
            { name: jobLabel, type: 'line', data: jobs, smooth: true, symbol: 'none', lineStyle: { color: secondaryColor, width: 2 }, itemStyle: { color: secondaryColor }, yAxisIndex: 1 }
          ]
        : [
            { name: costLabel + ' ($)', type: 'bar', data: costs, itemStyle: { color: costColor }, emphasis: { itemStyle: { color: emphasisColor } }, barMaxWidth: 20, yAxisIndex: 0 },
            { name: jobLabel, type: 'line', data: jobs, smooth: true, symbol: 'none', lineStyle: { color: secondaryColor, width: 2 }, itemStyle: { color: secondaryColor }, yAxisIndex: 1 }
          ]
    };

    chart.setOption(option);
    return chart;
  }

  function initLocalModelRunChart() {
    var container = document.getElementById('local-model-run-chart');
    if (!container) return null;

    var rawData = container.dataset.models;
    if (!rawData) return null;

    var data;
    try {
      data = JSON.parse(rawData);
    } catch (e) {
      console.error('Failed to parse local model data:', e);
      return null;
    }

    if (!data || data.length === 0) return null;

    var existingChart = echarts.getInstanceByDom(container);
    if (existingChart) existingChart.dispose();

    var isDark = ChartUtils.isDarkMode();
    var theme = isDark ? 'dark' : null;
    var chart = echarts.init(container, theme, { renderer: 'canvas' });
    var axis = ChartUtils.getAxisStyle(isDark);
    var barColor = ChartUtils.getSeriesColor('build');
    var emphasisColor = ChartUtils.getEmphasisColor();

    var modelNames = data.map(function(item) { return item.model_name; });
    var maxCost = Math.max.apply(null, data.map(function(item) { return item.cost || 0; }));
    // Minimum visible value: 1.5% of max so zero-cost bars still show a sliver
    var minVisible = maxCost > 0 ? maxCost * 0.015 : 0.01;

    var failColor = isDark ? '#f87171' : '#ef4444';   // red-400 / red-500
    var skipColor = isDark ? '#94a3b8' : '#cbd5e1';    // slate-400 / slate-300

    var barData = data.map(function(item) {
      var cost = item.cost || 0;
      var state = (item.job_state || '').toUpperCase();
      var isFailed = state === 'FAILED' || state === 'ERROR';
      var isSkipped = state === 'SKIPPED' || state === 'SKIP';
      var color = isFailed ? failColor : isSkipped ? skipColor : barColor;
      return {
        value: Math.max(cost, minVisible),
        _realCost: cost,
        itemStyle: { color: color, borderRadius: 0 }
      };
    });

    chart.setOption({
      backgroundColor: 'transparent',
      textStyle: {
        fontFamily: 'Urbanist, ui-sans-serif, system-ui, sans-serif'
      },
      tooltip: {
        trigger: 'axis',
        formatter: function(params) {
          var item = data[params[0].dataIndex];
          var state = (item.job_state || 'UNKNOWN').toUpperCase();
          var lines = ['<strong>' + item.model_name + '</strong>'];
          lines.push('Materialization: ' + (item.materialization || 'unknown'));
          lines.push('Cost: ' + ChartUtils.formatCurrency(item.cost || 0));
          if (state !== 'SKIPPED' && state !== 'SKIP') {
            lines.push('Bytes: ' + (item.bytes_display || '0 B'));
          }
          lines.push('Execution: ' + (item.duration_display || '0s'));
          lines.push('State: ' + state);
          return lines.join('<br/>');
        }
      },
      grid: {
        left: '4%',
        right: '3%',
        bottom: '3%',
        top: '6%',
        containLabel: true
      },
      xAxis: {
        type: 'category',
        data: modelNames,
        axisLabel: {
          show: false
        },
        axisTick: {
          show: false
        },
        axisLine: {
          lineStyle: { color: axis.lineColor }
        }
      },
      yAxis: {
        type: 'value',
        name: 'Cost ($)',
        nameTextStyle: { color: axis.textColor, fontSize: 10 },
        axisLabel: {
          fontSize: 10,
          color: axis.textColor,
          formatter: function(value) {
            return ChartUtils.formatCurrency(value);
          }
        },
        splitLine: {
          lineStyle: { color: axis.splitColor }
        }
      },
      series: [{
        name: 'Model Cost ($)',
        type: 'bar',
        data: barData,
        barMaxWidth: 36,
        emphasis: {
          itemStyle: { color: emphasisColor }
        }
      }]
    });

    return chart;
  }

  // Initialize a single usage bar chart
  function initUsageBarChart(containerId, metric, seriesKey, tooltipFormatter, yAxisFormatter) {
    var container = document.getElementById(containerId);
    if (!container) return null;

    var usageData = container.dataset.usage;
    if (!usageData) return null;

    var data;
    try {
      data = JSON.parse(usageData);
    } catch (e) {
      console.error('Failed to parse usage data for ' + containerId + ':', e);
      return null;
    }

    if (!data || data.length === 0) return null;

    var existingChart = echarts.getInstanceByDom(container);
    if (existingChart) existingChart.dispose();

    var isDark = ChartUtils.isDarkMode();
    var theme = isDark ? 'dark' : null;
    var chart = echarts.init(container, theme, { renderer: 'canvas' });

    var axis = ChartUtils.getAxisStyle(isDark);
    var barColor = ChartUtils.getSeriesColor(seriesKey);
    var emphasisColor = ChartUtils.getEmphasisColor();

    var dates = data.map(function(d) { return d.date; });
    var values = data.map(function(d) { return d[metric]; });

      var seriesConfig = {
      type: 'bar',
      itemStyle: {
        color: barColor,
        borderRadius: [2, 2, 0, 0]
      },
      emphasis: {
        itemStyle: { color: emphasisColor }
      },
      data: values
    };

    var option = {
      backgroundColor: 'transparent',
      tooltip: {
        trigger: 'axis',
        formatter: function(params) {
          var dateStr = ChartUtils.formatDate(params[0].axisValue);
          return '<strong>' + dateStr + '</strong><br/>' +
                 tooltipFormatter(params[0].data);
        }
      },
      grid: {
        left: '3%',
        right: '4%',
        bottom: '3%',
        top: '8%',
        containLabel: true
      },
      xAxis: {
        type: 'category',
        data: dates,
        axisLabel: {
          fontSize: 9,
          color: axis.textColor,
          rotate: dates.length > 14 ? 45 : 0,
          formatter: function(value) {
            return ChartUtils.formatDate(value);
          }
        },
        axisLine: {
          lineStyle: { color: axis.lineColor }
        }
      },
      yAxis: {
        type: 'value',
        axisLabel: {
          fontSize: 9,
          color: axis.textColor,
          formatter: yAxisFormatter
        },
        splitLine: {
          lineStyle: { color: axis.splitColor }
        }
      },
      series: [seriesConfig]
    };

    chart.setOption(option);
    return chart;
  }

  // Initialize all three usage charts with per-metric colours
  function initUsageCharts() {
    var charts = [];

    var runsChart = initUsageBarChart(
      'usage-runs-chart', 'runs', 'cost',
      function(val) { return 'Runs: ' + ChartUtils.formatNumber(val); },
      function(val) { return ChartUtils.formatNumber(val); }
    );
    if (runsChart) charts.push(runsChart);

    var bytesChart = initUsageBarChart(
      'usage-bytes-chart', 'bytes', 'bytes',
      function(val) { return 'Bytes: ' + ChartUtils.formatBytesValue(val); },
      function(val) { return ChartUtils.formatBytesValue(val); }
    );
    if (bytesChart) charts.push(bytesChart);

    var slotsChart = initUsageBarChart(
      'usage-slots-chart', 'slots', 'slots',
      function(val) { return 'Slots: ' + ChartUtils.formatSlotHours(val); },
      function(val) { return ChartUtils.formatSlotHours(val); }
    );
    if (slotsChart) charts.push(slotsChart);

    return charts;
  }

  function initHorizontalBarChart(containerId, formatter, seriesName, seriesKey) {
    var container = document.getElementById(containerId);
    if (!container) return null;

    var rawData = container.dataset.breakdown;
    if (!rawData) return null;

    var data;
    try {
      data = JSON.parse(rawData);
    } catch (e) {
      console.error('Failed to parse breakdown data for ' + containerId + ':', e);
      return null;
    }

    if (!data || data.length === 0) return null;

    var existingChart = echarts.getInstanceByDom(container);
    if (existingChart) existingChart.dispose();

    var isDark = ChartUtils.isDarkMode();
    var theme = isDark ? 'dark' : null;
    var chart = echarts.init(container, theme, { renderer: 'canvas' });

    var axis = ChartUtils.getAxisStyle(isDark);
    var barColor = ChartUtils.getSeriesColor(seriesKey || 'cost');
    var emphasisColor = ChartUtils.getEmphasisColor();
    var labels = data.map(function(item) { return item.label || item.environment; });
    var values = data.map(function(item) {
      return item.count !== undefined ? item.count : item.spend_raw;
    });

    chart.setOption({
      backgroundColor: 'transparent',
      tooltip: {
        trigger: 'axis',
        axisPointer: { type: 'shadow' },
        formatter: function(params) {
          var point = data[params[0].dataIndex];
          return '<strong>' + labels[params[0].dataIndex] + '</strong><br/>' + formatter(point);
        }
      },
      grid: {
        left: '6%',
        right: '5%',
        bottom: '3%',
        top: '2%',
        containLabel: true
      },
      xAxis: {
        type: 'value',
        axisLabel: {
          fontSize: 10,
          color: axis.textColor,
          formatter: function(value) {
            return formatter({ count: value, spend_raw: value, compact: true });
          }
        },
        splitLine: {
          lineStyle: { color: axis.splitColor }
        }
      },
      yAxis: {
        type: 'category',
        data: labels,
        axisLabel: {
          fontSize: 11,
          color: axis.textColor
        },
        axisLine: {
          lineStyle: { color: axis.lineColor }
        }
      },
      series: [{
        name: seriesName,
        type: 'bar',
        data: values,
        itemStyle: {
          color: barColor,
          borderRadius: [0, 4, 4, 0]
        },
        emphasis: {
          itemStyle: { color: emphasisColor }
        }
      }]
    });

    return chart;
  }

  function initOpportunityMixChart() {
    var container = document.getElementById('opportunity-mix-chart');
    if (!container) return null;

    var rawData = container.dataset.breakdown;
    if (!rawData) return null;

    var data;
    try {
      data = JSON.parse(rawData);
    } catch (e) {
      console.error('Failed to parse breakdown data for opportunity-mix-chart:', e);
      return null;
    }

    if (!data || data.length === 0) return null;

    var existingChart = echarts.getInstanceByDom(container);
    if (existingChart) existingChart.dispose();

    var isDark = ChartUtils.isDarkMode();
    var theme = isDark ? 'dark' : null;
    var chart = echarts.init(container, theme, { renderer: 'canvas' });

    var axis = ChartUtils.getAxisStyle(isDark);
    var barColor = ChartUtils.getSeriesColor('cost');
    var emphasisColor = ChartUtils.getEmphasisColor();
    var labels = data.map(function(item) { return item.label; });
    var values = data.map(function(item) { return item.count; });

    function wrapLabel(label) {
      if (!label || label.length <= 14) return label;
      var words = label.split(' ');
      var lines = [];
      var line = '';
      words.forEach(function(word) {
        var candidate = line ? line + ' ' + word : word;
        if (candidate.length > 14 && line) {
          lines.push(line);
          line = word;
        } else {
          line = candidate;
        }
      });
      if (line) lines.push(line);
      return lines.slice(0, 3).join('\n');
    }

    chart.setOption({
      backgroundColor: 'transparent',
      tooltip: {
        trigger: 'axis',
        axisPointer: { type: 'shadow' },
        formatter: function(params) {
          var point = data[params[0].dataIndex];
          return '<strong>' + point.label + '</strong><br/>' +
            'Active opportunities: ' + ChartUtils.formatNumber(point.count);
        }
      },
      grid: {
        left: '5%',
        right: '4%',
        bottom: '18%',
        top: '4%',
        containLabel: true
      },
      xAxis: {
        type: 'category',
        data: labels,
        axisLabel: {
          fontSize: 10,
          color: axis.textColor,
          interval: 0,
          formatter: wrapLabel
        },
        axisLine: {
          lineStyle: { color: axis.lineColor }
        }
      },
      yAxis: {
        type: 'value',
        axisLabel: {
          fontSize: 10,
          color: axis.textColor,
          formatter: function(value) {
            return ChartUtils.formatNumber(value);
          }
        },
        splitLine: {
          lineStyle: { color: axis.splitColor }
        }
      },
      series: [{
        name: 'Active Opportunities',
        type: 'bar',
        data: values,
        barMaxWidth: 48,
        itemStyle: {
          color: barColor,
          borderRadius: [4, 4, 0, 0]
        },
        emphasis: {
          itemStyle: { color: emphasisColor }
        }
      }]
    });

    return chart;
  }

  // Initialize all charts
  var localModelRunChart = null;
  var trendChart = null;
  var usageCharts = [];
  var opportunityMixChart = null;

  function initCharts() {
    localModelRunChart = initLocalModelRunChart();
    trendChart = initTrendChart();
    usageCharts = initUsageCharts();
    opportunityMixChart = initOpportunityMixChart();

    var allCharts = [];
    if (localModelRunChart) allCharts.push(localModelRunChart);
    if (trendChart) allCharts.push(trendChart);
    allCharts = allCharts.concat(usageCharts);
    if (opportunityMixChart) allCharts.push(opportunityMixChart);
    ChartUtils.setupChartResize(allCharts);
  }

  // Initialize when DOM is ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function() {
      initCharts();
      ChartUtils.setupThemeWatcher(initCharts);
    });
  } else {
    initCharts();
    ChartUtils.setupThemeWatcher(initCharts);
  }
})();
