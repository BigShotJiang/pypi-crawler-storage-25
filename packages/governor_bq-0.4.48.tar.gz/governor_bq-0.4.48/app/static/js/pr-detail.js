/**
 * PR Detail Charts
 * - downstream-focused lineage graph
 * - selected model cost trend chart
 */
(function() {
  'use strict';

  function parseJsonAttribute(el, attr, fallback) {
    var raw = el.getAttribute(attr);
    if (!raw) return fallback;
    try {
      return JSON.parse(raw);
    } catch (err) {
      console.error('Failed to parse ' + attr + ':', err);
      return fallback;
    }
  }

  function getTheme() {
    return ChartUtils.isDarkMode() ? 'dark' : null;
  }

  function getTrendLookup(trends) {
    var lookup = {};
    trends.forEach(function(item) {
      lookup[item.key] = item;
      if (item.relation_name) {
        lookup[item.relation_name] = item;
      }
      if (item.model_name) {
        lookup[item.model_name] = item;
      }
    });
    return lookup;
  }

  function getActiveTrendItem(lookup, key) {
    if (!key) return null;
    return lookup[key] || null;
  }

  function uniqueStrings(values) {
    var seen = {};
    var out = [];
    values.forEach(function(value) {
      if (!value) return;
      var key = String(value);
      if (seen[key]) return;
      seen[key] = true;
      out.push(key);
    });
    return out;
  }

  function getTrendKeyCandidates(key) {
    var cleaned = String(key || '').replace(/`/g, '').trim();
    if (!cleaned) return [];

    var parts = cleaned.split('.');
    var candidates = [cleaned];
    if (parts.length > 1) {
      candidates.push(parts[parts.length - 1]);
    }
    return uniqueStrings(candidates);
  }

  function getPrId() {
    var el = document.getElementById('pr-lineage-graph');
    return el ? el.getAttribute('data-pr-id') : null;
  }

  function fetchTrendMeta(relationName) {
    var prId = getPrId();
    var candidates = getTrendKeyCandidates(relationName);
    if (!prId || !candidates.length) return Promise.resolve(null);

    function tryCandidate(index) {
      if (index >= candidates.length) return Promise.resolve(null);

      var candidate = candidates[index];
      return fetch('/prs/' + prId + '/model-cost-trend?relation_name=' + encodeURIComponent(candidate))
        .then(function(response) { return response.json(); })
        .then(function(payload) {
          var data = payload.data || [];
          if (!data.length && index < candidates.length - 1) {
            return tryCandidate(index + 1);
          }
          return {
            key: candidate,
            model_name: payload.model_name || candidate.split('.').pop(),
            relation_name: candidate,
            label: payload.model_name || candidate.split('.').pop(),
            is_root: false,
            included: false,
            trend: data
          };
        })
        .catch(function() {
          return index < candidates.length - 1 ? tryCandidate(index + 1) : null;
        });
    }

    return tryCandidate(0);
  }

  function setTrendHeader(meta) {
    var titleEl = document.getElementById('cost-trend-title');
    var subtitleEl = document.getElementById('cost-trend-subtitle');
    if (titleEl) {
      titleEl.textContent = meta ? meta.label + ' — Cost Trend' : 'Cost Trend';
    }
    if (subtitleEl) {
      if (!meta) {
        subtitleEl.textContent = 'Click a lineage node to inspect spend.';
      } else if (meta.is_root) {
        subtitleEl.textContent = 'Selected model from the PR diff.';
      } else {
        subtitleEl.textContent = meta.included
          ? 'Included in downstream savings analysis.'
          : 'Observed in lineage, but excluded from savings total.';
      }
    }
  }

  function buildTrendOption(trendData, options) {
    if (!trendData || !trendData.length) return null;

    options = options || {};
    var isDark = ChartUtils.isDarkMode();
    var axis = ChartUtils.getAxisStyle(isDark);
    var costColor = ChartUtils.getSeriesColor('cost');
    var emphasisColor = ChartUtils.getEmphasisColor();
    var dates = trendData.map(function(row) { return row.date; });
    var costs = trendData.map(function(row) { return Number(row.cost || 0); });
    var label = options.label || 'Run cost';
    var compact = !!options.compact;
    var mergedAt = options.mergedAt || null;

    function findSeriesValue(params, name) {
      var match = params.find(function(item) { return item.seriesName === name; });
      return match ? Number(match.value || 0) : 0;
    }

    var series = [{
      name: label,
      type: 'line',
      data: costs,
      smooth: false,
      symbolSize: compact ? 4 : 6,
      showSymbol: !compact,
      lineStyle: { color: costColor, width: compact ? 1.6 : 2 },
      itemStyle: { color: costColor },
      emphasis: { itemStyle: { color: emphasisColor } },
      areaStyle: { color: ChartUtils.getAreaGradient(ChartUtils.BRAND_COLORS.primary, isDark) }
    }];

    if (mergedAt) {
      var mergeIdx = -1;
      for (var i = 0; i < dates.length; i++) {
        if (dates[i].substring(0, 10) >= mergedAt) {
          mergeIdx = i;
          break;
        }
      }
      if (mergeIdx === -1 && dates.length > 0) mergeIdx = dates.length - 1;
      if (mergeIdx >= 0) {
        series.push({
          name: 'PR Merged',
          type: 'line',
          markLine: {
            silent: true,
            symbol: 'none',
            lineStyle: {
              color: '#10B981',
              width: 2,
              type: 'dashed'
            },
            label: {
              formatter: 'PR Merged',
              position: 'insideStartTop',
              color: '#10B981',
              fontSize: 11,
              fontWeight: 'bold'
            },
            data: [{ xAxis: mergeIdx }]
          },
          data: []
        });
      }
    }

    return {
      backgroundColor: 'transparent',
      tooltip: {
        trigger: 'axis',
        axisPointer: compact ? { type: 'line' } : { type: 'cross', crossStyle: { color: '#6a7985' } },
        formatter: function(params) {
          var date = ChartUtils.formatDate(params[0].axisValue);
          var lines = ['<strong>' + date + '</strong>'];
          for (var i = 0; i < params.length; i++) {
            if (params[i].seriesType === 'line' && params[i].seriesName !== 'PR Merged') {
              lines.push(params[i].marker + ' ' + params[i].seriesName + ': ' + ChartUtils.formatCurrency(params[i].value));
            }
          }
          if (compact) {
            return lines.join('<br/>');
          }
          return lines.join('<br/>');
        }
      },
      legend: compact ? { show: false } : {
        show: false
      },
      grid: compact
        ? { left: 8, right: 8, top: 8, bottom: 8, containLabel: true }
        : { left: '3%', right: '4%', bottom: '3%', top: '10%', containLabel: true },
      xAxis: {
        type: 'category',
        boundaryGap: false,
        data: dates,
        axisLabel: {
          color: axis.textColor,
          fontSize: compact ? 9 : 10,
          rotate: dates.length > 20 ? 45 : 0,
          formatter: compact ? function(value) { return value.substring(5, 10); } : function(value) {
            return ChartUtils.formatDate(value);
          }
        },
        axisLine: { lineStyle: { color: axis.lineColor } },
        splitLine: { show: false }
      },
      yAxis: {
        type: 'value',
        axisLabel: {
          color: axis.textColor,
          fontSize: compact ? 8 : 10,
          formatter: function(v) { return ChartUtils.formatCurrency(v); }
        },
        axisLine: { lineStyle: { color: axis.lineColor } },
        splitLine: { lineStyle: { color: axis.splitColor } }
      },
      series: series,
      animation: false
    };
  }

  function renderTrendChart(el, meta, mergedAt, compact) {
    var trendData = meta ? (meta.trend || []) : [];
    var existingChart = echarts.getInstanceByDom(el);
    if (existingChart) existingChart.dispose();

    if (!trendData.length) {
      el.innerHTML = '<div class="flex h-full items-center justify-center text-xs text-slate-500 dark:text-slate-400">No job cost data available.</div>';
      return null;
    }

    var chart = echarts.init(el, getTheme(), { renderer: 'canvas' });
    chart.setOption(buildTrendOption(trendData, {
      label: meta && meta.is_root ? 'Run cost' : (meta && meta.label ? meta.label + ' cost' : 'Run cost'),
      mergedAt: mergedAt,
      compact: compact
    }));
    return chart;
  }

  function initMainTrendChart() {
    var el = document.getElementById('pr-cost-chart');
    if (!el || typeof echarts === 'undefined') return null;

    var trends = parseJsonAttribute(el, 'data-model-trends', []);
    if (!trends.length) return null;

    var selectedKey = el.getAttribute('data-selected-model-key') || trends[0].key;
    var mergedAt = parseJsonAttribute(el, 'data-merged-at', null);
    var lookup = getTrendLookup(trends);
    var chart = null;

    function applyMeta(meta) {
      if (!meta) return;
      var existingChart = echarts.getInstanceByDom(el);
      if (existingChart) existingChart.dispose();
      chart = echarts.init(el, getTheme(), { renderer: 'canvas' });
      var option = buildTrendOption(meta.trend || [], {
        label: meta.is_root ? 'Run cost' : (meta.label ? meta.label + ' cost' : 'Run cost'),
        mergedAt: mergedAt,
        compact: false
      });
      if (!option) {
        el.innerHTML = '<div class="flex h-full items-center justify-center rounded-xl border border-dashed border-slate-200 dark:border-slate-800 text-sm text-slate-500 dark:text-slate-400">No job cost data available for this model yet.</div>';
        window.prCostChartInstance = null;
        window.prSelectedTrendMeta = meta;
        window.prTrendLookup = lookup;
        setTrendHeader(meta);
        return;
      }
      chart.setOption(option);
      window.prCostChartInstance = chart;
      window.prSelectedTrendMeta = meta;
      window.prTrendLookup = lookup;
      setTrendHeader(meta);
    }

    function setByKey(key) {
      var currentLookup = window.prTrendLookup || lookup;
      var meta = getActiveTrendItem(currentLookup, key);
      if (meta && meta.trend && meta.trend.length) {
        applyMeta(meta);
        return;
      }
      if (key !== 'root') {
        fetchTrendMeta((meta && (meta.relation_name || meta.model_name || meta.label)) || key).then(function(fetchedMeta) {
          var baseMeta = meta || {};
          var nextMeta = fetchedMeta
            ? Object.assign({}, baseMeta, fetchedMeta, {
                included: fetchedMeta.included !== undefined && fetchedMeta.included !== null ? fetchedMeta.included : (baseMeta.included || false),
                confidence: fetchedMeta.confidence !== undefined && fetchedMeta.confidence !== null ? fetchedMeta.confidence : (baseMeta.confidence || null),
                depth: fetchedMeta.depth !== undefined && fetchedMeta.depth !== null ? fetchedMeta.depth : (baseMeta.depth || null),
                estimated_monthly_cost_usd: fetchedMeta.estimated_monthly_cost_usd !== undefined && fetchedMeta.estimated_monthly_cost_usd !== null
                  ? fetchedMeta.estimated_monthly_cost_usd
                  : (baseMeta.estimated_monthly_cost_usd || null)
              })
            : meta;
          if (!nextMeta) return;
          if (!window.prTrendLookup) window.prTrendLookup = {};
          window.prTrendLookup[key] = nextMeta;
          if (nextMeta.relation_name) {
            window.prTrendLookup[nextMeta.relation_name] = nextMeta;
          }
          if (nextMeta.model_name) {
            window.prTrendLookup[nextMeta.model_name] = nextMeta;
          }
          applyMeta(nextMeta);
        });
        return;
      }

      if (!meta) return;
      applyMeta(meta);
    }

    window.prSetTrendByKey = setByKey;
    window.prTrendLookup = lookup;
    window.prTrendMergedAt = mergedAt;
    window.prCostChartInstance = chart;
    applyMeta(getActiveTrendItem(lookup, selectedKey) || trends[0]);

    return chart;
  }

  function initLineageGraph() {
    var el = document.getElementById('pr-lineage-graph');
    if (!el) return null;

    var graphData = parseJsonAttribute(el, 'data-graph', null);
    if (!graphData || !graphData.nodes || !graphData.nodes.length) return null;

    if (typeof cytoscape === 'undefined') {
      return initLineageGraphFallback();
    }

    var prId = el.getAttribute('data-pr-id');
    var isDark = ChartUtils.isDarkMode();
    var isCompact = el.clientWidth < 900;
    var bgColor = isDark ? '#020617' : '#ffffff';
    var nodeColors = {
      root: '#ea580c',
      source: '#16a34a',
      upstream: '#0891b2',
      downstream: '#7c3aed'
    };

    function computeWidth(label) {
      return Math.max(150, Math.min(label.length * 9 + 48, 300));
    }

    var elements = graphData.nodes.map(function(n) {
      var label = n.name || n.id.split('.').pop();
      return {
        data: {
          id: n.id,
          label: label,
          relation_name: n.relation_name || '',
          model_name: n.model_name || label,
          trendKey: n.type === 'root' ? 'root' : (n.relation_name || n.model_name || label || n.id),
          type: n.type,
          side: n.side,
          depth: n.depth,
          width: computeWidth(label),
          height: 40
        },
        position: {
          x: Number(n.x || 0),
          y: Number(n.y || 0)
        },
        classes: n.type
      };
    }).concat(graphData.edges.map(function(edge) {
      return {
        data: {
          id: edge.source + '__' + edge.target,
          source: edge.source,
          target: edge.target
        }
      };
    }));

    function focusNode(cy, nodeId) {
      var node = cy.getElementById(nodeId);
      if (!node || node.empty()) return;
      cy.elements().removeClass('selected faded');
      cy.elements().addClass('faded');
      node.removeClass('faded').addClass('selected');
      node.closedNeighborhood().removeClass('faded');
    }

    var cy = cytoscape({
      container: el,
      elements: elements,
      style: [
        {
          selector: 'core',
          style: {
            'background-color': bgColor
          }
        },
        {
          selector: 'node',
          style: {
            'shape': 'round-rectangle',
            'width': 'data(width)',
            'height': 'data(height)',
            'background-color': '#475569',
            'label': 'data(label)',
            'color': '#ffffff',
            'font-family': 'ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, Liberation Mono, monospace',
            'font-size': 12,
            'text-valign': 'center',
            'text-halign': 'center',
            'text-wrap': 'wrap',
            'text-max-width': 240,
            'padding': '10px',
            'border-width': 0,
            'overlay-opacity': 0,
            'transition-property': 'opacity, border-width, border-color, background-color, text-opacity',
            'transition-duration': '160ms'
          }
        },
        { selector: 'node.root', style: { 'background-color': nodeColors.root, 'border-width': 2, 'border-color': isDark ? '#fdba74' : '#c2410c' } },
        { selector: 'node.source', style: { 'background-color': nodeColors.source } },
        { selector: 'node.upstream', style: { 'background-color': nodeColors.upstream } },
        { selector: 'node.downstream', style: { 'background-color': nodeColors.downstream } },
        {
          selector: 'node.selected',
          style: {
            'border-width': 2.5,
            'border-color': isDark ? '#f8fafc' : '#0f172a',
            'shadow-blur': 18,
            'shadow-color': isDark ? '#0f172a' : '#94a3b8',
            'shadow-opacity': 0.18,
            'shadow-offset-x': 0,
            'shadow-offset-y': 4,
            'z-index': 10,
            'opacity': 1,
            'text-opacity': 1
          }
        },
        {
          selector: 'edge',
          style: {
            'curve-style': 'bezier',
            'line-color': isDark ? '#475569' : '#cbd5e1',
            'target-arrow-shape': 'triangle',
            'target-arrow-color': isDark ? '#475569' : '#cbd5e1',
            'width': 1.5,
            'arrow-scale': 0.8,
            'opacity': 0.8,
            'transition-property': 'opacity, width, line-color, target-arrow-color',
            'transition-duration': '160ms'
          }
        },
        {
          selector: '.faded',
          style: {
            'opacity': 0.18,
            'text-opacity': 0.18,
            'line-opacity': 0.18,
            'border-opacity': 0.18
          }
        }
      ],
      layout: { name: 'preset' },
      wheelSensitivity: 0.2,
      minZoom: 0.45,
      maxZoom: 2.2
    });

    var layoutOptions = {
      name: 'dagre',
      rankDir: 'LR',
      nodeSep: isCompact ? 40 : 56,
      rankSep: isCompact ? 90 : 125,
      edgeSep: 18,
      fit: true,
      padding: 32,
      nodeDimensionsIncludeLabels: true
    };
    try {
      cy.layout(layoutOptions).run();
    } catch (err) {
      cy.layout({ name: 'preset', fit: true, padding: 32 }).run();
    }

    var rootNode = graphData.nodes.find(function(n) { return n.type === 'root'; }) || graphData.nodes[0];
    if (rootNode) {
      focusNode(cy, rootNode.id);
    }

    cy.on('tap', function(evt) {
      if (evt.target === cy && rootNode) {
        focusNode(cy, rootNode.id);
      }
    });

    cy.on('tap', 'node', function(evt) {
      var node = evt.target;
      focusNode(cy, node.id());

      var data = node.data();
      if (window.prSetTrendByKey && (data.trendKey || data.relation_name || data.model_name || data.name || data.id)) {
        window.prSetTrendByKey(
          data.trendKey || data.relation_name || data.model_name || data.name || data.id
        );
      }
    });

    var resizeHandler = function() { cy.resize(); };
    window.addEventListener('resize', resizeHandler);
    cy._governorResizeHandler = resizeHandler;

    return cy;
  }

  function initLineageGraphFallback() {
    var el = document.getElementById('pr-lineage-graph');
    if (!el || typeof echarts === 'undefined') return null;

    var graphData = parseJsonAttribute(el, 'data-graph', null);
    if (!graphData || !graphData.nodes || !graphData.nodes.length) return null;

    var prId = el.getAttribute('data-pr-id');
    var isDark = ChartUtils.isDarkMode();
    var bgColor = isDark ? '#020617' : '#ffffff';
    var labelColor = '#ffffff';

    var typeColors = {
      root: '#ea580c',
      source: '#16a34a',
      upstream: '#0891b2',
      downstream: '#7c3aed'
    };

    var graph = echarts.init(el, null, { renderer: 'canvas' });
    var nodeState = graphData.nodes.map(function(n) {
      return {
        id: n.id,
        name: n.name,
        x: n.x,
        y: n.y,
        side: n.side,
        type: n.type,
        relation_name: n.relation_name,
        model_name: n.model_name || n.name,
        trendKey: n.type === 'root' ? 'root' : (n.relation_name || n.model_name || n.name || n.id),
        symbolSize: [Math.max(n.name.length * 9 + 24, 90), 36],
        symbol: 'roundRect',
        itemStyle: {
          color: typeColors[n.type] || '#475569',
          borderWidth: n.type === 'root' ? 1.5 : 0,
          borderColor: n.type === 'root' ? '#fdba74' : 'transparent'
        },
        label: {
          show: true,
          color: labelColor,
          fontSize: 12,
          fontFamily: 'monospace',
          overflow: 'truncate',
          width: Math.max(n.name.length * 9 + 24, 90) - 12
        }
      };
    });

    function highlightNode(selectedId) {
      var updated = nodeState.map(function(n) {
        var isSelected = n.id === selectedId;
        return {
          id: n.id,
          name: n.name,
          x: n.x,
          y: n.y,
          side: n.side,
          type: n.type,
          relation_name: n.relation_name,
          model_name: n.model_name,
          trendKey: n.trendKey,
          symbolSize: n.symbolSize,
          symbol: n.symbol,
          itemStyle: Object.assign({}, n.itemStyle, {
            opacity: isSelected ? 1 : 0.35
          }),
          label: Object.assign({}, n.label, {
            opacity: isSelected ? 1 : 0.35
          })
        };
      });
      graph.setOption({ series: [{ data: updated }] });
    }

    graph.setOption({
      backgroundColor: bgColor,
      tooltip: {
        trigger: 'item',
        formatter: function(params) {
          if (params.dataType !== 'node') return '';
          var node = params.data;
          var lines = ['<b>' + node.name + '</b>'];
          if (node.relation_name) {
            lines.push('<span style="font-size:11px;color:#94a3b8">' + node.relation_name + '</span>');
          }
          lines.push('<span style="font-size:11px;color:#94a3b8">' + node.type + '</span>');
          return lines.join('<br/>');
        }
      },
      series: [{
        type: 'graph',
        layout: 'none',
        roam: true,
        data: nodeState,
        edges: graphData.edges.map(function(edge) {
          return {
            source: edge.source,
            target: edge.target,
            lineStyle: {
              color: isDark ? '#475569' : '#94a3b8',
              width: 1.5,
              curveness: 0.25
            },
            symbol: ['none', 'arrow'],
            symbolSize: [5, 8]
          };
        }),
        emphasis: {
          focus: 'adjacency',
          lineStyle: { width: 2.5 }
        },
        cursor: 'pointer'
      }]
    });

    var resizeHandler = function() { graph.resize(); };
    window.addEventListener('resize', resizeHandler);
    graph._governorResizeHandler = resizeHandler;

    graph.on('click', function(params) {
      if (params.dataType !== 'node') return;
      highlightNode(params.data.id);

      var node = params.data;
      if (window.prSetTrendByKey && (node.trendKey || node.relation_name || node.model_name || node.name || node.id)) {
        window.prSetTrendByKey(
          node.trendKey || node.relation_name || node.model_name || node.name || node.id
        );
      }
    });

    return graph;
  }

  function cleanupPreviousInstances() {
    // Remove resize listeners from previous page loads
    if (window._governorPrCleanup) {
      window._governorPrCleanup.forEach(function(fn) { fn(); });
    }
    window._governorPrCleanup = [];

    // Dispose existing ECharts instances
    ['pr-cost-chart', 'pr-lineage-graph'].forEach(function(id) {
      var el = document.getElementById(id);
      if (el && typeof echarts !== 'undefined') {
        var existing = echarts.getInstanceByDom(el);
        if (existing) {
          if (existing._governorResizeHandler) {
            window.removeEventListener('resize', existing._governorResizeHandler);
          }
          existing.dispose();
        }
      }
    });
  }

  function trackCleanup(instance) {
    if (!instance || !instance._governorResizeHandler) return;
    window._governorPrCleanup.push(function() {
      window.removeEventListener('resize', instance._governorResizeHandler);
    });
  }

  function initPage() {
    cleanupPreviousInstances();
    var chart = initMainTrendChart();
    trackCleanup(chart);
    var graph = initLineageGraph();
    trackCleanup(graph);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initPage);
  } else {
    initPage();
  }
})();
