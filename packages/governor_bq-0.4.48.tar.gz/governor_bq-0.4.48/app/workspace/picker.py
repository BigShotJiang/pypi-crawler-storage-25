"""Native local folder picker helpers for local Governor workflows."""

from __future__ import annotations

import platform
from pathlib import Path, PureWindowsPath
import subprocess


class FolderPickerError(RuntimeError):
    """Base error for native folder picker failures."""


class FolderPickerCancelledError(FolderPickerError):
    """Raised when the user dismisses the picker without choosing a folder."""


class FolderPickerUnsupportedError(FolderPickerError):
    """Raised when the current OS does not support the native picker."""


def pick_local_project_folder(prompt: str = "Select your dbt project folder") -> str:
    """Open a native folder chooser and return the selected absolute path."""
    system = platform.system()

    if system == "Darwin":
        command = _build_macos_command(prompt)
    elif system == "Windows":
        command = _build_windows_command(prompt)
    else:
        raise FolderPickerUnsupportedError(
            f"Native folder picking is not supported on {system or 'this platform'}."
        )

    try:
        result = subprocess.run(
            command,
            capture_output=True,
            text=True,
            timeout=120,
            check=False,
        )
    except FileNotFoundError as exc:
        raise FolderPickerError(
            "Native folder picking is unavailable on this machine."
        ) from exc
    except subprocess.TimeoutExpired as exc:
        raise FolderPickerError("Folder selection timed out.") from exc
    except OSError as exc:
        raise FolderPickerError("Failed to open the native folder picker.") from exc

    if _is_cancelled(result):
        raise FolderPickerCancelledError("Folder selection was cancelled.")

    selected_path = result.stdout.strip()
    if result.returncode != 0:
        message = result.stderr.strip() or "Failed to open the native folder picker."
        raise FolderPickerError(message)

    if not selected_path:
        raise FolderPickerCancelledError("Folder selection was cancelled.")

    return _normalize_selected_path(selected_path, system)


def _build_macos_command(prompt: str) -> list[str]:
    escaped_prompt = prompt.replace("\\", "\\\\").replace('"', '\\"')
    script = f'POSIX path of (choose folder with prompt "{escaped_prompt}")'
    return ["osascript", "-e", script]


def _build_windows_command(prompt: str) -> list[str]:
    escaped_prompt = prompt.replace("'", "''")
    script = f"""
Add-Type -AssemblyName System.Windows.Forms
$dialog = New-Object System.Windows.Forms.FolderBrowserDialog
$dialog.Description = '{escaped_prompt}'
$dialog.ShowNewFolderButton = $false
if ($dialog.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {{
    [Console]::Out.Write($dialog.SelectedPath)
}} else {{
    exit 2
}}
""".strip()
    return ["powershell.exe", "-NoProfile", "-STA", "-Command", script]


def _is_cancelled(result: subprocess.CompletedProcess[str]) -> bool:
    stderr = (result.stderr or "").strip().lower()
    stdout = (result.stdout or "").strip().lower()
    return (
        result.returncode == 2
        or "user canceled" in stderr
        or "user cancelled" in (stderr + stdout)
    )


def _normalize_selected_path(path_text: str, system: str) -> str:
    cleaned = path_text.strip().strip("\x00")
    if system == "Windows":
        return str(PureWindowsPath(cleaned))
    return str(Path(cleaned).expanduser().resolve(strict=False))
