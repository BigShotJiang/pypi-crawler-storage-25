"""Helpers for local git actions scoped to a configured workspace."""

from __future__ import annotations

import subprocess
from pathlib import Path


def commit_local_file(project_path: str, relative_path: str, message: str) -> str:
    """Stage a changed file and create a git commit in the local repository.

    Returns the new commit SHA.
    """
    project_root = Path(project_path).resolve()
    target = (project_root / relative_path).resolve()
    if not str(target).startswith(str(project_root)):
        raise ValueError(
            f"Path traversal detected: {relative_path} resolves outside project root"
        )

    _run_git(project_root, "rev-parse", "--show-toplevel")
    _run_git(project_root, "add", "--", relative_path)
    _run_git(project_root, "commit", "-m", message)
    return _run_git(project_root, "rev-parse", "HEAD")


def _run_git(project_root: Path, *args: str) -> str:
    completed = subprocess.run(
        ["git", *args],
        cwd=str(project_root),
        capture_output=True,
        text=True,
        encoding="utf-8",
        timeout=15,
    )
    if completed.returncode != 0:
        stderr = (completed.stderr or "").strip()
        stdout = (completed.stdout or "").strip()
        detail = stderr or stdout or "git command failed"
        raise RuntimeError(detail)
    return (completed.stdout or "").strip()
