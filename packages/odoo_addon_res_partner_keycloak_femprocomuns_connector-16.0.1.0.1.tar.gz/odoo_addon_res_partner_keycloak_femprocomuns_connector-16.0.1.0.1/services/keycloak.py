import base64
import logging
import re

from keycloak import KeycloakAdmin, KeycloakOpenIDConnection
from keycloak.exceptions import KeycloakPostError, KeycloakPutError

_logger = logging.getLogger(__name__)

COLLECTIVE_GROUP_NAME = "Collectives"
MANAGERS_COLLECTIVE_GROUP_NAME = "Collectives Managers"


class KeycloakService:
    def __init__(self, company):
        _logger.debug("Create Admin connection with Keycloak...")
        self.quota = company.keycloak_user_default_quota
        keycloak_connection = KeycloakOpenIDConnection(
            server_url=company.keycloak_url,
            username=company.keycloak_admin_user,
            password=company.keycloak_admin_password,
            user_realm_name=company.keycloak_user_realm_name,
            realm_name=company.keycloak_realm_name,
            client_id=company.keycloak_client_id,
            client_secret_key=company.keycloak_client_secret,
            verify=True,
        )
        self.keycloak_admin = KeycloakAdmin(connection=keycloak_connection)
        _logger.debug("Admin connection created.")

    def _group_name_from_id(self, groups_ids):
        group_id = groups_ids.split(",")[0]
        group = self.keycloak_admin.get_group(group_id)
        return group["name"]

    def remove_special_characters(self, text):
        """
        Remove special characters from a string
        Respect the accents and dieresis
        """
        return re.sub(r"[^A-Za-zÁÉÍÓÚÜáéíóúüÑñÇç\s]", "", text)

    def _group_name(self, record):
        # TODO: Review the validation of SR. We don't use the parent_id field.
        if record.other_contact_ids:
            name = record.other_contact_ids[0].parent_id.display_name
        else:
            name = record.display_name
        return self.remove_special_characters(name)

    def _get_locale(self, record):
        """
        Get the locale of the partner. Split the lang field and return the first part.
        For example, if the lang field is "es_ES", the function will return "es".
        """
        return record.lang.split("_")[0]

    def get_or_create_keycloak_groups(self, record):
        if record.keycloak_group_id:
            groups_ids = record.keycloak_group_id.split(",")
            return groups_ids

        if record.other_contact_ids:
            record = record.other_contact_ids[0].parent_id

        general_collective_group = self.keycloak_admin.get_groups(
            {"search": COLLECTIVE_GROUP_NAME}
        )
        if not general_collective_group:
            raise KeycloakGroupNotFound("Collectives group not found")
        general_collective_group = general_collective_group[0]
        general_managers_collective_group = self.keycloak_admin.get_groups(
            {"search": MANAGERS_COLLECTIVE_GROUP_NAME}
        )
        if not general_managers_collective_group:
            raise KeycloakGroupNotFound("Collectives Managers group not found")
        general_managers_collective_group = general_managers_collective_group[0]

        group_name = self._group_name(record)
        collective_group = None
        managers_collective_group = None

        _logger.debug(f"Check if the group exists for partner {record.display_name}")
        try:
            collective_group = self._get_subgroup(general_collective_group, group_name)
            if self._is_manager(record):
                managers_collective_group = self._get_subgroup(
                    general_managers_collective_group, group_name
                )
        except KeycloakGroupNotFound:
            collective_group = None
            managers_collective_group = None

        groups_ids = []
        if collective_group:
            groups_ids.append(collective_group["id"])
        if managers_collective_group:
            groups_ids.append(managers_collective_group["id"])
        if len(groups_ids) == 0:
            return self._create_groups(
                group_name,
                general_collective_group["id"],
                general_managers_collective_group["id"],
                record.id,
            )
        return groups_ids

    def _create_groups(
        self, group_name, collectives_group_id, managers_group_id, odoo_id
    ):
        _logger.debug(f"Create the group {group_name}")
        payload = {
            "name": group_name,
            "attributes": {"OdooID": [odoo_id]},
        }
        try:
            collective_group = self.keycloak_admin.create_group(
                payload=payload,
                parent=collectives_group_id,
                skip_exists=False,
            )
            managers_collective_group = self.keycloak_admin.create_group(
                payload=payload,
                parent=managers_group_id,
                skip_exists=False,
            )
            _logger.debug(f"Groups created for {group_name}")
            return [collective_group, managers_collective_group]
        except KeycloakPostError as err:
            raise KeycloakGroupNotFound(f"Group {group_name} already exists") from err

    def _get_subgroup(self, group, group_name):
        subgroup = [c for c in group.get("subGroups", []) if c["name"] == group_name]
        if not subgroup:
            raise KeycloakGroupNotFound(f"Group {group_name} not found")
        return subgroup[0]

    def add_user_to_groups(self, user_id, group_ids):
        for group_id in group_ids:
            # We need to retry the operation in case of KeycloakPutError
            try:
                self.keycloak_admin.group_user_add(user_id, group_id)
            except KeycloakPutError:
                self.keycloak_admin.group_user_add(user_id, group_id)

    def create_keycloak_user(self, record):
        groups_ids = self.get_or_create_keycloak_groups(record)
        _logger.debug(f"Create the user for username {record.somnuvol_account_name}")
        user = self.keycloak_admin.create_user(
            {
                "email": record.email,
                "username": record.somnuvol_account_name,
                "firstName": record.firstname,
                "lastName": record.lastname,
                "enabled": True,
                "emailVerified": False,
                "requiredActions": ["UPDATE_PASSWORD", "VERIFY_EMAIL"],
                "attributes": {
                    "OdooID": record.id,
                    "locale": [self._get_locale(record)],
                    "o": (
                        self._group_name(record)
                        if not record.keycloak_group_id
                        else self._group_name_from_id(record.keycloak_group_id)
                    ),
                    "quota": self.quota,
                    "description": "-",
                    "Photo": self._get_image(),
                },
            },
            exist_ok=True,
        )
        # Update the password
        self.keycloak_admin.send_update_account(
            user_id=user, payload=["UPDATE_PASSWORD"]
        )
        _logger.debug(f"User created for username {record.somnuvol_account_name}")
        self.add_user_to_groups(user, groups_ids)

    def _get_image(self):
        """Get default image and convert to base64 string."""
        default_image_path = "/opt/odoo/odoo/addons/base/static/img/avatar_grey.png"
        with open(default_image_path, "rb") as image_file:
            encoded_string = base64.b64encode(image_file.read())
        return encoded_string.decode("utf-8")

    def _is_manager(self, record):
        """
        Check if the partner is a manager.
        If is a partner without other contacts, it is a manager, else if has other contacts
        and the first contact is a manager, it is a manager.
        """
        if not record.other_contact_ids:
            return True

        return record.other_contact_ids[0].function == "manager"


class KeycloakGroupNotFound(Exception):
    pass
