from mock import patch

from odoo.tests.common import TransactionCase

from ...services.keycloak import KeycloakService


@patch(
    "odoo.addons.res_partner_keycloak_femprocomuns_connector.services.keycloak.KeycloakOpenIDConnection"  # noqa
)
@patch(
    "odoo.addons.res_partner_keycloak_femprocomuns_connector.services.keycloak.KeycloakAdmin"
)
class TestKeycloak(TransactionCase):
    def test_remove_special_characters(self, _, __):
        """Test the creation of the groups in Keycloak"""
        keycloak = KeycloakService(self.env.company)

        name = "Name with accents ÁÉÍÓÚÜáéíóúüÑñÇç"
        processed_name = keycloak.remove_special_characters(name)

        self.assertEqual(name, processed_name)

        name = (
            "Name with accents ÁÉÍÓÚÜáéíóúüÑñÇç and other special characters *&%$---£"
        )
        processed_name = keycloak.remove_special_characters(name)

        self.assertNotEqual(name, processed_name)
