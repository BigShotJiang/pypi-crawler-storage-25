import logging

from odoo.addons.component.core import Component

_logger = logging.getLogger(__name__)


class PartnerListener(Component):
    _name = "partner.listener"
    _inherit = "base.event.listener"
    _apply_on = ["res.partner"]

    def on_record_create(self, record, fields=None):
        _logger.debug("Check if is needed create a user in Keycloak...")
        if (
            not self.env.company.keycloak_connector_enabled
            or record.is_company
            or not record.somnuvol_account_name
            or self.env.context.get("skip_create_listeners")
        ):
            _logger.debug("Skip create user in Keycloak...")
            return
        _logger.debug("Creating user in Keycloak...")
        record.with_delay().create_keycloak_user()
