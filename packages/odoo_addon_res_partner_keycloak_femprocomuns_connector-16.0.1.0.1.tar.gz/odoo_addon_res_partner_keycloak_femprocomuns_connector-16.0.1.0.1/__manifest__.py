# Copyright 2022-Coopdevs Treball SCCL (<https://coopdevs.org>)
# - César López Ramírez - <cesar.lopez@coopdevs.org>
# License AGPL-3.0 or later (https://www.gnu.org/licenses/agpl.html).
{
    "name": "ResPartner Keycloak connector",
    "version": "16.0.1.0.1",
    "depends": ["base", "component_event", "femprocomuns", "queue_job"],
    "author": "Coopdevs Treball SCCL",
    "category": "",
    "website": "https://git.coopdevs.org/coopdevs/odoo/odoo-addons/odoo-femprocomuns",
    "license": "AGPL-3",
    "summary": """
        Connector to create users in Keycloak when a new customer is created.
    """,
    "data": [
        "view/res_company.xml",
        "view/res_partner.xml",
    ],
    "installable": True,
    "external_dependencies": {"python": ["keycloak"]},
}
