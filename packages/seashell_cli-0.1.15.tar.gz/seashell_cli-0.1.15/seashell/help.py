"""Help text for the Seashell CLI."""

HELP_TEXT = """
QUERY COMMANDS
  LIST PATIENTS                                            List all patients in your institution
  LIST GENES                                               List all gene symbols in the database
  LIST ANNOTATIONS                                         Loaded reference DB versions (gnomAD/dbSNP/constraint)
  COUNT VARIANTS WHERE patient=id                          Total variant count for a patient
  COUNT VARIANTS WHERE patient=id AND gnomad_af<0.001      Rare variants (sub-millisecond fast path)
  COUNT VARIANTS WHERE patient=id AND lof=true             Loss-of-function variants (sub-ms fast path)
  COUNT PATIENTS WHERE gene=BRCA1                          Patients matching criteria
  FIND VARIANTS WHERE patient=id AND gene=BRCA1            Variants in a gene for a patient
  FIND VARIANTS WHERE patient=id AND consequence=missense_variant   Per-VEP-consequence filter
  FIND VARIANTS WHERE patient=id AND gnomad_af<0.001 AND consequence=missense_variant
                                                           Rare missense variants (canonical rare-disease query)
  FIND PATIENTS WHERE gene=BRCA1 AND significance=pathogenic   Carriers of a variant
  FIND SIMILAR TO patient=id                               Genetically similar patients
  COMPARE PATIENTS id1 AND id2                             Jaccard similarity (fast)
  DIFF PATIENTS id1 AND id2                                Exact variant differences
  PCA PATIENTS                                             Principal component analysis
  COVERAGE PATIENT id REGION chr22:28600000-28700000       Coverage statistics in a region
  QC PATIENT id                                            Quality-control metrics
  FLAGSTAT PATIENT id                                      samtools flagstat (byte-identical, no decompression)
  CYCLE_QUALITY PATIENT id                                 Per-cycle base quality decay (FastQC plot, O(1))
  INSERT_SIZE PATIENT id                                   Insert size distribution (samtools stats / Picard CISM)
  SEXCHECK PATIENT id                                      Infer biological sex from chrX/chrY coverage (peddy-style)
  KINSHIP COHORT [UNEXPECTED] [LIMIT N]                    Pairwise sketch-Jaccard kinship pre-screen
  KINSHIP TRIO mom_id dad_id child_id                      Validate a declared trio (3 pairs + warnings)
  CONTAMINATION PATIENT id                                 Sample-swap / contamination pre-screen
  ANCESTRY PATIENT id                                      Predict super-population (EUR/EAS/SAS/AFR/AMR)
  MENDELIAN TRIO mom_id dad_id child_id                    De novo + inheritance partition for a trio
  PILEUP PATIENT id POSITION chr22:28698027                Per-base pileup at one position

UPLOAD
  UPLOAD PATIENT id CRAM s3://P001.cram VCF s3://P001.vcf.gz       Upload from CRAM/BAM
  UPLOAD PATIENT id VCF s3://P001.vcf.gz                           Upload VCF-only (variant queries, no read export)
  UPLOAD PATIENT id FASTQ s3://R1.fastq.gz s3://R2.fastq.gz        Upload from FASTQ
  UPLOAD PATIENT id FASTQ s3://R1.fastq.gz s3://R2.fastq.gz --with-bqsr   FASTQ + BQSR
  UPLOAD BATCH s3://bucket/manifest.json                           Batch upload

EXPORT
  EXPORT PATIENT id FORMAT VCF                             Export variants as VCF (fast, in-memory)
  EXPORT PATIENT id FORMAT CRAM                            Export as CRAM (requires CRAM upload)
  EXPORT PATIENT id FORMAT BAM                             Export as BAM (requires CRAM upload)
  EXPORT PATIENT id FORMAT VCF REGION chr17:43044295-43125483    Export variants in region
  EXPORT PATIENT id FORMAT BAM REGION chr17:43044295-43125483    Export reads in region
  EXPORT PATIENTS NA12878, HG00096 FORMAT VCF              Export multi-sample VCF
  EXPORT PATIENTS WHERE gene=BRCA1 FORMAT VCF LIMIT 300    Export cohort VCF by criteria
  EXPORT PATIENTS WHERE gene=BRCA1 FORMAT CRAM LIMIT 300   Export CRAMs by criteria

MANAGEMENT
  DELETE PATIENT id                                        Remove a patient

FILTER KEYS
  Genetic:    patient= gene= significance= chromosome= region= variant= genotype=
  Annotation: gnomad_af< gnomad_popmax< consequence= lof=true rsid= novel=true pli> loeuf<
  Phenotype:  age> sex= ancestry= diagnosis= institution=
  Operators:  = > < >= <= !=

CLI COMMANDS
  help          Show this message
  status        Connection info and patient count
  more          Show next page of cached results (after a paginated query)
  logout        Clear saved credentials and log out
  exit          Quit Seashell
""".strip()


# ANSI color codes (work on macOS, Linux, and most Windows terminals)
CYAN = "\033[36m"
BOLD = "\033[1m"
DIM = "\033[2m"
RESET = "\033[0m"
WHITE = "\033[97m"
BLUE = "\033[34m"


def welcome_banner():
    """Return the colored welcome banner."""
    lines = []
    lines.append("")
    lines.append(BOLD + WHITE + "  Welcome to Seashell" + RESET)
    lines.append("")
    return "\n".join(lines)
