# daqopen/calc.py

"""Module for calculation functions and classes.

This module provides classes and functions for basis calculations.
"""

import numpy as np

def estimate_frequency(input_signal, sr, fMax=10000):
    """
    Calc Frequency According to "A high resolution fundamental fundamental 
    frequency determination based on phase changes of the Fourier transform" from
    Judith C. Brown and Miller S. Puckette 1993
    """
    N = input_signal.size
    signalFFT_0 = np.fft.rfft(input_signal)
    df = 1.0*sr/input_signal.size
    kMax = int(fMax/df)
    
    fullRms = np.sqrt(np.sum(np.power(np.abs(signalFFT_0[1:]),2))/(N*N/2))
    fullRms = np.sqrt(np.power(np.abs(signalFFT_0[0]/N),2)+np.power(np.abs(fullRms),2))
    
    k = np.argmax(np.abs(signalFFT_0)[0:kMax])
    if k == 0:
        singleRms = np.sqrt(np.power(np.abs(signalFFT_0[k])/N,2))
        phi_0 =0
        phi_1 =0
    else:
    # Calc Full RMS Value
        singleRms = np.sqrt((np.power(np.abs(signalFFT_0[k-1])/N,2) + 
                    np.power(np.abs(signalFFT_0[k])/N,2) +
                    np.power(np.abs(signalFFT_0[k+1])/N,2))*2)
        X_H_1 = 0.5 * np.exp(2j*np.pi*k/N) * (signalFFT_0[k] - 
                0.5 * np.exp(2j*np.pi/N) *signalFFT_0[k+1] - 
                0.5 * np.exp(-2j*np.pi/N) *signalFFT_0[k-1])
        X_H_0 = 0.5 * (signalFFT_0[k] - 0.5 * signalFFT_0[k+1] - 0.5 * signalFFT_0[k-1])
        phi_0 = np.arctan2(np.imag(X_H_0),np.real(X_H_0))
        phi_1 = np.arctan2(np.imag(X_H_1),np.real(X_H_1))
    
    phiDiff =  phi_1-phi_0 
    
    if phiDiff < -np.pi:
        phiDiff += 2*np.pi
    f = phiDiff/(2*np.pi)*sr
    return f, fullRms, singleRms