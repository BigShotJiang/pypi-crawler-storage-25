# DaqOpen Examples

This directory contains reference applications for visualizing and recording live data streams using the DaqOpen ZMQ protocol.

## Main Application: `daq-zmq-viewer.py`

The **Multi-Trace Viewer & Recorder** is a powerful GUI application built with PyQt6 and Pyqtgraph. It is designed to monitor DAQ data in real-time and record it with high efficiency.

### Features
* **Dual-Graph Layout:** Two independent oscilloscope views (e.g., for Voltage and Current) with synchronized time axes.
* **Multi-Trace Selection:** A sidebar allows you to toggle any number of channels per graph using checkboxes.
* **Real-time Analysis:** Automatically calculates Mean, RMS, Peak values, and Fundamental Frequency for every visible channel.
* **Hybrid Recording Strategy:**
    * **During Measurement:** Fast, crash-safe writing to binary `.npy` files.
    * **Post-Processing:** Automatic conversion to the high-performance **Apache Parquet** format using **Polars** once recording stops.

## Installation

### Method 1:

This method clones the code locally to be simple edited in local folder:

```bash
git clone https://codeberg.org/DaqOpen/daqopen-lib.git
cd daqopen-lib
python -m venv .venv
pip install -e .[examples]
```

### Method 2:

This method installs the package from PyPi:

```bash
mkdir daqopen-playground
cd daqopen-playground
python -m venv .venv
pip install daqopen-lib[examples]
```

Method 3: 

Use this method, if daqopen-lib is already installed in your environment

```bash
pip install PyQt6 pyqtgraph polars
```

## Workflow: Recording and Analysis

### Start Recording

1. Run `python -m daqzmqviewer.py`  
2. Enter the Hostname and Port of your ZMQ publisher and click Start Transfer.
3. Click Start Recording. Data will be stored in a new folder named m_YYYYMMDD_HHMM.

### Stop and Convert

Click Stop Recording. The application will automatically:

1. Close the binary raw data streams.
2. Merge the data chunks into a consistent timeline.
3. Save the result as data.parquet inside the recording folder.
4. Delete the temporary .npy files to save disk space.

## Data Analysis (Best Practice)

Thanks to Polars and Parquet, loading data is extremely fast. We recommend using the following pattern for your analysis scripts:

```python
import polars as pl
from pathlib import Path

def load_daq_data(folder_path):
    """Loads the parquet recording from the specified folder."""
    path = Path(folder_path) / "data.parquet"
    return pl.read_parquet(path)

# Example Usage:
df = load_daq_data("m_20260329_1045")
print(df.head())
```



## Directory Structure

- `daqzmqviewer.py`: The main GUI application.