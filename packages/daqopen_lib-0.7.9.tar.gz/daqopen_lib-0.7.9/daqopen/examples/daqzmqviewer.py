"""
App: daq-zmq-viewer.py (Integrated with Recording & Dual Graphs)
Description: app for reading the data from zmq, displaying it in gui, and recording to npy

Author: Michael Oberhofer (Modified)
Created on: 2024-03-13
Last Updated: 2026-03-29

License: MIT
"""

import sys
import numpy as np
from PyQt6.QtCore import QLocale
from PyQt6.QtWidgets import QApplication, QMainWindow, QVBoxLayout, QWidget, QPushButton, QGridLayout, QLabel, QHBoxLayout, QComboBox, QLineEdit
from PyQt6.QtGui import QIntValidator, QDoubleValidator
from pyqtgraph import PlotWidget
import zmq
import tomllib
import tomli_w
import datetime
from pathlib import Path
import polars as pl
from platformdirs import user_config_dir

from daqopen.channelbuffer import AcqBufferPool
from daqopen.daqzmq import DaqSubscriber
from daqopen.calc import estimate_frequency


class GuiWithZmq(QMainWindow):
    """ GUI Class for Testing the DueDaq with a separate Acquisition Process
    """

    def __init__(self):
        super().__init__()

        config_dir = Path(user_config_dir("daqopen"))
        config_dir.mkdir(parents=True, exist_ok=True)
        self.config_path = config_dir / "daq-zmq-viewer.toml"
        self.config = self.load_or_create_config()

        self.setWindowTitle("DAQ Dual Viewer & Recorder")
        self.setGeometry(100, 100, 900, 800)

        self.central_widget = QWidget(self)
        self.setCentralWidget(self.central_widget)

        # Main application Layout
        self.main_layout = QVBoxLayout(self.central_widget)

        # Connection Input fields
        self.connect_layout = QHBoxLayout()
        self.lbl_hostname = QLabel("Hostname: ")
        self.connect_layout.addWidget(self.lbl_hostname)
        self.le_zmq_hostname = QLineEdit(self.config["zmq_server"]["host"])
        self.le_zmq_hostname.editingFinished.connect(self.set_zmq_hostname)
        self.connect_layout.addWidget(self.le_zmq_hostname)
        self.lbl_zmq_port = QLabel("Port: ")
        self.connect_layout.addWidget(self.lbl_zmq_port)
        self.le_zmq_port = QLineEdit(str(self.config["zmq_server"]["port"]))
        port_num_validator = QIntValidator(1000, 65535, self)
        self.le_zmq_port.setValidator(port_num_validator)
        self.connect_layout.addWidget(self.le_zmq_port)
        self.le_zmq_port.editingFinished.connect(self.set_zmq_port)
        self.main_layout.addLayout(self.connect_layout)

        # --- Graph 1 ---
        self.graphWidget1 = PlotWidget()
        self.main_layout.addWidget(self.graphWidget1)
        self.graphWidget1.setLabel('left', 'Value 1')
        self.graphWidget1.showGrid(x=True, y=True)
        
        self.layout_g1_controls = QHBoxLayout()
        self.cb_channel_selector_1 = QComboBox()
        self.lbl_value_1 = QLabel("0.0")
        self.layout_g1_controls.addWidget(self.cb_channel_selector_1, 0)
        self.layout_g1_controls.addWidget(self.lbl_value_1, 1)
        self.main_layout.addLayout(self.layout_g1_controls)

        # --- Graph 2 ---
        self.graphWidget2 = PlotWidget()
        self.main_layout.addWidget(self.graphWidget2)
        self.graphWidget2.setLabel('left', 'Value 2')
        self.graphWidget2.setLabel('bottom', 'Time (s)')
        self.graphWidget2.showGrid(x=True, y=True)
        self.graphWidget2.setXLink(self.graphWidget1) # Link X-axis zooming/panning!

        self.layout_g2_controls = QHBoxLayout()
        self.cb_channel_selector_2 = QComboBox()
        self.lbl_value_2 = QLabel("0.0")
        self.layout_g2_controls.addWidget(self.cb_channel_selector_2, 0)
        self.layout_g2_controls.addWidget(self.lbl_value_2, 1)
        self.main_layout.addLayout(self.layout_g2_controls)

        # --- Global Controls (TimeSpan, Transfer, Recording) ---
        self.global_layout = QGridLayout()
        
        self.lbl_timespan = QLabel("Time Span (s):")
        self.global_layout.addWidget(self.lbl_timespan, 0, 0)
        
        self.le_time_span = QLineEdit("0.1")
        self.le_time_span.setMaximumWidth(100)
        time_span_validator = QDoubleValidator(0.01, 1, 2, self)
        time_span_validator.setLocale(QLocale("EN_en"))
        self.le_time_span.setValidator(time_span_validator)
        self.le_time_span.editingFinished.connect(self.set_window_time_span)
        self.global_layout.addWidget(self.le_time_span, 0, 1)

        self.window_time_span_sec = 0.1
        self.max_time_span_sec = 0.1

        # Transfer Buttons
        self.btn_acq_start = QPushButton('Start Transfer', self)
        self.global_layout.addWidget(self.btn_acq_start, 1, 0)
        self.btn_acq_start.clicked.connect(self.start_transfer)

        self.btn_acq_stop = QPushButton('Stop Transfer', self)
        self.global_layout.addWidget(self.btn_acq_stop, 1, 1)
        self.btn_acq_stop.clicked.connect(self.stop_transfer)

        # Recording Buttons
        self.btn_rec_start = QPushButton('Start Recording', self)
        self.global_layout.addWidget(self.btn_rec_start, 2, 0)
        self.btn_rec_start.clicked.connect(self.start_recording)
        self.btn_rec_start.setEnabled(False)

        self.btn_rec_stop = QPushButton('Stop Recording', self)
        self.global_layout.addWidget(self.btn_rec_stop, 2, 1)
        self.btn_rec_stop.clicked.connect(self.stop_recording)
        self.btn_rec_stop.setEnabled(False)

        self.main_layout.addLayout(self.global_layout)

        # Plot Data Init
        self.x_data = np.arange(0, 10, 0.1)
        self.y_data_dummy = np.sin(self.x_data)
        self.sample_count = 0
        
        self.data_line1 = self.graphWidget1.plot(self.x_data, self.y_data_dummy, pen='y') # yellow line
        self.data_line2 = self.graphWidget2.plot(self.x_data, self.y_data_dummy, pen='c') # cyan line

        # States
        self.data_update_timer = self.startTimer(100)
        self.daq_sub = None
        
        # Recording States
        self.is_recording = False
        self.out_files = {}
        self.last_stored_sidx = 0

    def load_or_create_config(self):
        """Lädt die Config oder erstellt Standardwerte, falls keine existiert."""
        default_config = {
            "zmq_server": {
                "host": "pqopen-0039",
                "port": 50001
            }
        }

        try:
            with open(self.config_path, "rb") as f:
                return tomllib.load(f)
        except Exception as e:
            print(f"Error loading config: {e}. Using defaults.")
            return default_config
        
    def save_config(self):
        self.config["zmq_server"]["host"] = self.le_zmq_hostname.text()
        self.config["zmq_server"]["port"] = int(self.le_zmq_port.text() or 50001)
        with open(self.config_path, "wb") as f: tomli_w.dump(self.config, f)
        
    def start_transfer(self):
        # Create DaqSubscriber Instance
        self.daq_sub = DaqSubscriber(self.config["zmq_server"]["host"], self.config["zmq_server"]["port"], connect_timeout=1.0)
        print("Daq Connected")
        
        # Create DAQ Buffer Object
        self.daq_buffer = AcqBufferPool(daq_info=self.daq_sub.daq_info, 
                                        data_columns=self.daq_sub.data_columns,                                        
                                        start_timestamp_us=int(self.daq_sub.timestamp*1e6))
        
        channels = list(self.daq_sub.daq_info.channel.keys())
        
        # Populate Combobox 1
        self.cb_channel_selector_1.clear()
        self.cb_channel_selector_1.addItems(channels)
        
        # Populate Combobox 2
        self.cb_channel_selector_2.clear()
        self.cb_channel_selector_2.addItems(channels)
        # Set second combobox to the second channel by default (if available)
        if len(channels) > 1:
            self.cb_channel_selector_2.setCurrentIndex(1)
            
        self.sample_count = 0
        #self.graphWidget1.enableAutoRange()
        #self.graphWidget2.enableAutoRange()
        self.max_time_span_sec = self.daq_buffer._buffer_size/self.daq_sub.daq_info.board.samplerate
        
        self.btn_rec_start.setEnabled(True)

    def stop_transfer(self):
        if self.is_recording:
            self.stop_recording()
            
        if isinstance(self.daq_sub, DaqSubscriber):
            self.daq_sub.terminate()
            self.daq_sub = None
            
        self.btn_rec_start.setEnabled(False)

    def start_recording(self):
        if not isinstance(self.daq_sub, DaqSubscriber):
            print("No transfer active. Start transfer before recording")
            return

        folder_name = f"m_{datetime.datetime.now().strftime('%Y%m%d_%H%M')}"
        Path(folder_name).mkdir(exist_ok=True)

        samplerate = self.daq_sub.daq_info.board.samplerate
        self.out_files = {}
        
        for channel_name in self.daq_buffer.channel.keys():
            self.out_files[channel_name] = open(f"{folder_name}/{channel_name}_{samplerate:.2f}.npy", 'wb')
        self.out_files["time"] = open(f"{folder_name}/time_{samplerate:.2f}.npy", 'wb')
        
        self.last_stored_sidx = self.daq_buffer.actual_sidx
        self.is_recording = True

        self.btn_rec_start.setEnabled(False)
        self.btn_rec_stop.setEnabled(True)
        print(f"Recording started. Store in folder: {folder_name}")

    def stop_recording(self):
        if not self.is_recording:
            return
        
        self._save_recording_chunk()
        self.is_recording = False
        
        for channel_name in self.out_files:
            self.out_files[channel_name].close()
        # Remember path
        recording_folder = Path(list(self.out_files.values())[0].name).parent
        self.out_files = {}

        # Conversion to parquet
        self.convert_to_parquet(recording_folder)

        self.btn_rec_start.setEnabled(True)
        self.btn_rec_stop.setEnabled(False)
        print(f"Recording stopped and converted to parquet: {recording_folder}")

    def convert_to_parquet(self, folder_path: Path):
        """ Liest die npy-Daten mit Polars und speichert sie als Parquet """
        print("Convert data to Parquet...")
        try:
            # 1. Zeitstempel laden
            time_file = list(folder_path.glob("time_*.npy"))[0]
            time_chunks = []
            with open(time_file, 'rb') as f:
                while True:
                    try: time_chunks.append(np.load(f))
                    except (EOFError, ValueError): break
            
            # Zeit-Series erstellen
            time_series = pl.Series("time_s", np.concatenate(time_chunks))

            # 2. Kanäle laden und Spalten-Liste vorbereiten
            columns = [time_series]
            
            for file in folder_path.glob("*.npy"):
                if "time_" in file.name: continue
                ch_name = file.name.split("_")[0]
                
                chunks = []
                with open(file, 'rb') as f:
                    while True:
                        try: chunks.append(np.load(f))
                        except (EOFError, ValueError): break
                
                if chunks:
                    data_array = np.concatenate(chunks)
                    columns.append(pl.Series(ch_name, data_array))

            # 3. DataFrame aus den Series erstellen
            df = pl.DataFrame(columns)

            # 4. Speichern (Polars nutzt standardmäßig ZSTD-Kompression, was sehr effizient ist)
            parquet_path = folder_path / "data.parquet"
            df.write_parquet(parquet_path)
            
            # Aufräumen: npy Dateien löschen
            for file in folder_path.glob("*.npy"):
                file.unlink()
            
            print(f"Conversion suceeded (Polars): {parquet_path}")
            
        except Exception as e:
            print(f"Error converting data: {e}")

    def _save_recording_chunk(self):
        if self.daq_buffer.actual_sidx > self.last_stored_sidx:
            for channel_name in self.daq_buffer.channel.keys():
                data_to_save = self.daq_buffer.channel[channel_name].read_data_by_index(self.last_stored_sidx, self.daq_buffer.actual_sidx)
                np.save(self.out_files[channel_name], data_to_save)
            
            time_to_save = self.daq_buffer.time.read_data_by_index(self.last_stored_sidx, self.daq_buffer.actual_sidx)
            np.save(self.out_files["time"], time_to_save.astype(np.float64)/1e6)
            
            self.last_stored_sidx = self.daq_buffer.actual_sidx

    def set_window_time_span(self):
        self.window_time_span_sec = min(self.max_time_span_sec, float(self.le_time_span.text()))
        self.le_time_span.setText(f"{self.window_time_span_sec:.2f}")
    
    def set_zmq_hostname(self):
        self.config["zmq_server"]["host"] = self.le_zmq_hostname.text()

    def set_zmq_port(self):
        self.config["zmq_server"]["port"] = int(self.le_zmq_port.text())

    def timerEvent(self, event):
        """ Update data in both graphs and process recording """
        if not isinstance(self.daq_sub, DaqSubscriber):
            return None
            
        new_data = False
        # Read all data from queue
        while self.daq_sub.sock.poll(10) == zmq.POLLIN:
            m_data = self.daq_sub.recv_data().copy()
            self.sample_count += m_data.shape[0]
            self.daq_buffer.put_data_with_timestamp(m_data, int(self.daq_sub.timestamp*1e6))
            new_data = True
            
        if not new_data:
            return None

        # --- Recording Logic ---
        if self.is_recording:
            if (self.daq_buffer.actual_sidx - self.last_stored_sidx) >= (self.daq_buffer._buffer_size / 2):
                self._save_recording_chunk()

        # --- GUI/Plot Logic ---
        start_sample_idx = int(self.sample_count - self.window_time_span_sec*self.daq_sub.daq_info.board.samplerate)
        if start_sample_idx <= 0:
            return None
        start_sample_idx = max(self.daq_buffer.actual_sidx-self.daq_buffer._buffer_size+1, start_sample_idx)
        
        self.x_data = np.arange(start_sample_idx, self.sample_count-1)/self.daq_sub.daq_info.board.samplerate
        
        # --- Update Graph 1 ---
        ch1 = self.cb_channel_selector_1.currentText()
        if ch1:
            y1_data = self.daq_buffer.channel[ch1].read_data_by_index(start_sample_idx, self.sample_count - 1)
            if y1_data.size > 0:
                self.data_line1.setData(self.x_data, y1_data)
                f1, trms1, frms1 = estimate_frequency(y1_data, self.daq_sub.daq_info.board.samplerate)
                trms1 = np.sqrt(np.mean(np.power(y1_data, 2)))
                self.lbl_value_1.setText(f"mean: {y1_data.mean():.3f}  min: {y1_data.min():.3f}  max: {y1_data.max():.3f}  rms: {trms1:.3f}  fund_rms: {frms1:.3f}  freq: {f1:.3f}")

        # --- Update Graph 2 ---
        ch2 = self.cb_channel_selector_2.currentText()
        if ch2:
            y2_data = self.daq_buffer.channel[ch2].read_data_by_index(start_sample_idx, self.sample_count - 1)
            if y2_data.size > 0:
                self.data_line2.setData(self.x_data, y2_data)
                f2, trms2, frms2 = estimate_frequency(y2_data, self.daq_sub.daq_info.board.samplerate)
                trms2 = np.sqrt(np.mean(np.power(y2_data, 2)))
                self.lbl_value_2.setText(f"mean: {y2_data.mean():.3f}  min: {y2_data.min():.3f}  max: {y2_data.max():.3f}  rms: {trms2:.3f}  fund_rms: {frms2:.3f}  freq: {f2:.3f}")

    def closeEvent(self, event):
        self.stop_transfer()
        print("Worker Stopped")
        self.save_config()
        event.accept()

def main():
    app = QApplication(sys.argv)
    window = GuiWithZmq()
    window.show()
    sys.exit(app.exec())

if __name__ == "__main__":
    main()