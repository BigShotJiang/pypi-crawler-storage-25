"""Type stubs for the native _luci extension module.

The native module only exposes the engine primitives (Index,
Transaction, SearchResults, SearchHit, set_num_threads). All query,
aggregation, and search builders are pure Python in ``luci.query``,
``luci.agg``, and ``luci.search``.
"""

from typing import Any, Self

from pydantic import BaseModel

def set_num_threads(num_threads: int) -> None:
    """Configure parallel search threads.

    Must be called before any search. Once per process.
    """

class Index:
    @staticmethod
    def create(
        path: str,
        mapping: dict[str, Any] | None = None,
        memory_budget: int | None = None,
        write_timeout: float | None = None,
    ) -> Index:
        """Create a new index."""

    @staticmethod
    def open(
        path: str,
        memory_budget: int | None = None,
        write_timeout: float | None = None,
    ) -> Index:
        """Open an existing index. Mappings are loaded from the index file."""

    def add(
        self,
        doc: dict[str, Any],
        write_timeout: float | None = None,
    ) -> None:
        """Add a single document. Auto-commits."""

    def bulk(
        self,
        docs: list[dict[str, Any]],
        write_timeout: float | None = None,
    ) -> dict[str, Any]:
        """Add multiple documents. Returns ``{"took": ms, "count": n}``."""

    @property
    def admin(self) -> IndexAdmin:
        """Admin namespace for segment-level maintenance operations."""

    def search(
        self,
        query: BaseModel | dict[str, Any],
        size: int = 10,
    ) -> SearchResults:
        """Search the index.

        ``query`` is either a ``SearchExpression`` / ``QueryExpression``
        Pydantic model from ``luci.query`` / ``luci.search``, or a raw
        dict in the Luci query DSL.
        """

    def get(self, id: str) -> dict[str, Any] | None:
        """Get a document by its _id. Returns None if not found."""

    def delete(self, id: str) -> bool:
        """Delete a document by its _id. Returns True if found."""

    def update(self, id: str, doc: dict[str, Any]) -> bool:
        """Update a document by its _id with a partial doc merge."""

    def delete_by_query(self, query: dict[str, Any]) -> int:
        """Delete all documents matching a query. Returns count deleted."""

    def count(self, query: dict[str, Any]) -> int:
        """Count documents matching a query."""

    def buffered_doc_count(self) -> int:
        """Return the number of buffered (uncommitted) documents."""

    def set_write_timeout(self, timeout_secs: float = 5.0) -> None:
        """Set the cross-process write lock timeout in seconds."""

    def transaction(self) -> Transaction:
        """Create a transaction for batched writes with explicit commit."""

class IndexAdmin:
    """Admin namespace for ``Index`` maintenance operations.

    Segment-level operations live here rather than on ``Index`` itself —
    segments are an engine implementation detail and routine code should
    not reason about them.
    """

    def force_merge(self, max_segments: int = 1) -> None:
        """Compact the index to at most ``max_segments`` segments.

        Expensive and blocking. Do not call during normal operation;
        Luci merges segments automatically via its merge policy.
        """

class Transaction:
    """Sync transaction context manager for batched writes."""

    def add(self, doc: dict[str, object]) -> None:
        """Add a document to the transaction buffer."""

    def __enter__(self) -> Self: ...
    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: object,
    ) -> bool: ...

class SearchResults:
    """Lazy search results with method-based access."""

    @property
    def hits(self) -> list[SearchHit]: ...
    @property
    def total_hits(self) -> dict[str, Any]: ...
    @property
    def aggregations(self) -> dict[str, Any]: ...
    def __len__(self) -> int: ...

class SearchHit:
    """A single search hit with lazy content access.

    Every accessor is lazy: the columnar read / analyser run / scorer
    reconstruction happens on first access and the result is cached.
    """

    @property
    def score(self) -> float: ...
    @property
    def id(self) -> str | None: ...
    @property
    def source(self) -> dict[str, Any] | None: ...
    @property
    def fields(self) -> dict[str, Any] | None: ...
    @property
    def sort(self) -> list[Any] | None: ...
    @property
    def explain(self) -> dict[str, Any] | None: ...
    @property
    def inner_hits(self) -> dict[str, Any] | None: ...
    @property
    def collapse_key(self) -> Any | None: ...  # noqa: ANN401
    def highlight(self, field: str) -> list[Highlight] | None: ...
    def highlight_with_config(
        self,
        config: dict[str, Any],
    ) -> dict[str, list[Highlight]] | None: ...

class Highlight:
    """A single match span within a field's text.

    Structured — no tag wrapping, no fragment concatenation. The
    consumer decides how to render matches. See
    [[feature-search-highlight]].
    """

    @property
    def text(self) -> str: ...
    @property
    def start(self) -> int: ...
    @property
    def end(self) -> int: ...
