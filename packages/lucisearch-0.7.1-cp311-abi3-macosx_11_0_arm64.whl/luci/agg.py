"""Typed aggregation builders for the Luci search engine.

Each aggregation type is a frozen Pydantic ``BaseModel`` with a custom
``@model_serializer`` producing the Luci aggregation JSON dict.
Bucket aggregations accept sub-aggregations via the ``aggs`` kwarg.

See [[feature-typed-search-api]].
"""

from typing import Any

from pydantic import BaseModel, ConfigDict, Field, model_serializer

from luci.query import ScoringExpression

# Engine defaults for optional aggregation parameters. The serializer
# omits these when they match the default to keep the JSON minimal.
_DEFAULT_CARDINALITY_PRECISION = 3000
_DEFAULT_TDIGEST_COMPRESSION = 100.0


class AggregationExpression(BaseModel):
    """Base class for all aggregation types."""

    model_config = ConfigDict(frozen=True, extra="forbid")


def _with_sub_aggs(
    body: dict[str, Any],
    sub: dict[str, AggregationExpression],
) -> dict[str, Any]:
    """Attach sub-aggregations to a bucket agg's serialized body."""
    if sub:
        body["aggs"] = {name: a.model_dump() for name, a in sub.items()}
    return body


# ===========================================================================
# Metric aggregations
# ===========================================================================


class AvgAgg(AggregationExpression):
    """Average metric aggregation."""

    field: str

    @model_serializer
    def _serialize(self) -> dict[str, Any]:
        return {"avg": {"field": self.field}}


class SumAgg(AggregationExpression):
    """Sum metric aggregation."""

    field: str

    @model_serializer
    def _serialize(self) -> dict[str, Any]:
        return {"sum": {"field": self.field}}


class MinAgg(AggregationExpression):
    """Min metric aggregation."""

    field: str

    @model_serializer
    def _serialize(self) -> dict[str, Any]:
        return {"min": {"field": self.field}}


class MaxAgg(AggregationExpression):
    """Max metric aggregation."""

    field: str

    @model_serializer
    def _serialize(self) -> dict[str, Any]:
        return {"max": {"field": self.field}}


class StatsAgg(AggregationExpression):
    """Stats aggregation: count, min, max, avg, sum."""

    field: str

    @model_serializer
    def _serialize(self) -> dict[str, Any]:
        return {"stats": {"field": self.field}}


class ExtendedStatsAgg(AggregationExpression):
    """Extended stats aggregation: adds variance, std_deviation, bounds."""

    field: str

    @model_serializer
    def _serialize(self) -> dict[str, Any]:
        return {"extended_stats": {"field": self.field}}


class ValueCountAgg(AggregationExpression):
    """Value count aggregation."""

    field: str

    @model_serializer
    def _serialize(self) -> dict[str, Any]:
        return {"value_count": {"field": self.field}}


class CardinalityAgg(AggregationExpression):
    """Cardinality aggregation (approximate distinct count via HyperLogLog)."""

    field: str
    precision_threshold: int = Field(default=_DEFAULT_CARDINALITY_PRECISION, gt=0)

    @model_serializer
    def _serialize(self) -> dict[str, Any]:
        body: dict[str, Any] = {"field": self.field}
        if self.precision_threshold != _DEFAULT_CARDINALITY_PRECISION:
            body["precision_threshold"] = self.precision_threshold
        return {"cardinality": body}


class PercentilesAgg(AggregationExpression):
    """Percentiles aggregation (approximate via t-digest)."""

    field: str
    percents: list[float] | None = None
    compression: float = Field(default=_DEFAULT_TDIGEST_COMPRESSION, gt=0.0)

    @model_serializer
    def _serialize(self) -> dict[str, Any]:
        body: dict[str, Any] = {"field": self.field}
        if self.percents is not None:
            body["percents"] = self.percents
        if self.compression != _DEFAULT_TDIGEST_COMPRESSION:
            body["tdigest"] = {"compression": self.compression}
        return {"percentiles": body}


class GeoBoundsAgg(AggregationExpression):
    """Geographic bounds metric aggregation."""

    field: str

    @model_serializer
    def _serialize(self) -> dict[str, Any]:
        return {"geo_bounds": {"field": self.field}}


class GeoCentroidAgg(AggregationExpression):
    """Geographic centroid metric aggregation."""

    field: str

    @model_serializer
    def _serialize(self) -> dict[str, Any]:
        return {"geo_centroid": {"field": self.field}}


class TopHitsAgg(AggregationExpression):
    """Top hits aggregation — returns top N matching documents per bucket."""

    size: int = Field(default=3, gt=0)

    @model_serializer
    def _serialize(self) -> dict[str, Any]:
        return {"top_hits": {"size": self.size}}


# ===========================================================================
# Bucket aggregations
# ===========================================================================


class TermsAgg(AggregationExpression):
    """Terms bucket aggregation."""

    field: str
    size: int = Field(default=10, gt=0)
    aggs: dict[str, AggregationExpression] = Field(default_factory=dict)

    @model_serializer
    def _serialize(self) -> dict[str, Any]:
        body: dict[str, Any] = {
            "terms": {"field": self.field, "size": self.size},
        }
        return _with_sub_aggs(body, self.aggs)


class HistogramAgg(AggregationExpression):
    """Histogram bucket aggregation."""

    field: str
    interval: float = Field(gt=0.0)
    aggs: dict[str, AggregationExpression] = Field(default_factory=dict)

    @model_serializer
    def _serialize(self) -> dict[str, Any]:
        body: dict[str, Any] = {
            "histogram": {
                "field": self.field,
                "interval": self.interval,
            },
        }
        return _with_sub_aggs(body, self.aggs)


class DateHistogramAgg(AggregationExpression):
    """Date histogram bucket aggregation.

    Specify exactly one of ``calendar_interval`` or ``fixed_interval``.
    """

    field: str
    calendar_interval: str | None = None
    fixed_interval: str | None = None
    aggs: dict[str, AggregationExpression] = Field(default_factory=dict)

    def model_post_init(self, _context: Any, /) -> None:  # noqa: ANN401
        """Validate that exactly one of calendar_interval/fixed_interval is set.

        ``_context`` is a Pydantic-supplied parameter whose type is
        deliberately ``Any`` (see Pydantic v2 ``model_post_init`` signature).
        """
        if self.calendar_interval is None and self.fixed_interval is None:
            msg = "DateHistogramAgg requires calendar_interval or fixed_interval"
            raise ValueError(msg)
        if self.calendar_interval is not None and self.fixed_interval is not None:
            msg = (
                "DateHistogramAgg: specify only one of "
                "calendar_interval / fixed_interval"
            )
            raise ValueError(msg)

    @model_serializer
    def _serialize(self) -> dict[str, Any]:
        inner: dict[str, Any] = {"field": self.field}
        if self.calendar_interval is not None:
            inner["calendar_interval"] = self.calendar_interval
        else:
            inner["fixed_interval"] = self.fixed_interval
        body: dict[str, Any] = {"date_histogram": inner}
        return _with_sub_aggs(body, self.aggs)


class RangeAgg(AggregationExpression):
    """Range bucket aggregation."""

    field: str
    ranges: list[dict[str, Any]] = Field(min_length=1)
    aggs: dict[str, AggregationExpression] = Field(default_factory=dict)

    @model_serializer
    def _serialize(self) -> dict[str, Any]:
        body: dict[str, Any] = {
            "range": {"field": self.field, "ranges": self.ranges},
        }
        return _with_sub_aggs(body, self.aggs)


class DateRangeAgg(AggregationExpression):
    """Date range bucket aggregation."""

    field: str
    ranges: list[dict[str, Any]] = Field(min_length=1)
    aggs: dict[str, AggregationExpression] = Field(default_factory=dict)

    @model_serializer
    def _serialize(self) -> dict[str, Any]:
        body: dict[str, Any] = {
            "date_range": {"field": self.field, "ranges": self.ranges},
        }
        return _with_sub_aggs(body, self.aggs)


class FilterAgg(AggregationExpression):
    """Filter bucket aggregation.

    The Rust parser expects ``{"filter": <query_dict>, "aggs": ...}``
    where the query is the raw query body.
    """

    query: ScoringExpression
    aggs: dict[str, AggregationExpression] = Field(default_factory=dict)

    @model_serializer
    def _serialize(self) -> dict[str, Any]:
        body: dict[str, Any] = {"filter": self.query.model_dump()}
        return _with_sub_aggs(body, self.aggs)


class FiltersAgg(AggregationExpression):
    """Named filters aggregation — one bucket per named query."""

    filters: dict[str, ScoringExpression]
    aggs: dict[str, AggregationExpression] = Field(default_factory=dict)

    @model_serializer
    def _serialize(self) -> dict[str, Any]:
        body: dict[str, Any] = {
            "filters": {
                "filters": {name: q.model_dump() for name, q in self.filters.items()},
            },
        }
        return _with_sub_aggs(body, self.aggs)


class NestedAgg(AggregationExpression):
    """Nested bucket aggregation — aggregate over nested documents."""

    path: str
    aggs: dict[str, AggregationExpression] = Field(default_factory=dict)

    @model_serializer
    def _serialize(self) -> dict[str, Any]:
        body: dict[str, Any] = {"nested": {"path": self.path}}
        return _with_sub_aggs(body, self.aggs)


class ReverseNestedAgg(AggregationExpression):
    """Reverse-nested bucket aggregation — step back out of a nested context."""

    aggs: dict[str, AggregationExpression] = Field(default_factory=dict)

    @model_serializer
    def _serialize(self) -> dict[str, Any]:
        body: dict[str, Any] = {"reverse_nested": {}}
        return _with_sub_aggs(body, self.aggs)


class GeohashGridAgg(AggregationExpression):
    """Geohash grid bucket aggregation."""

    field: str
    precision: int = Field(default=5, ge=1, le=12)
    size: int = Field(default=10000, gt=0)
    aggs: dict[str, AggregationExpression] = Field(default_factory=dict)

    @model_serializer
    def _serialize(self) -> dict[str, Any]:
        body: dict[str, Any] = {
            "geohash_grid": {
                "field": self.field,
                "precision": self.precision,
                "size": self.size,
            },
        }
        return _with_sub_aggs(body, self.aggs)
