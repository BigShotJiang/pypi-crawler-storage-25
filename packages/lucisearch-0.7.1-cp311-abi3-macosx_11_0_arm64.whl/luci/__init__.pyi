"""Type stubs for the luci package.

Query/aggregation/search builders are pure Python in ``luci.query``,
``luci.agg``, ``luci.search`` — type checkers read those directly.
Only the package-level re-exports, Rust-sourced types, and helpers
live here.
"""

from typing import Any, Self

from luci._luci import (
    Highlight as Highlight,
)
from luci._luci import (
    Index as Index,
)
from luci._luci import (
    IndexAdmin as IndexAdmin,
)
from luci._luci import (
    SearchHit as SearchHit,
)
from luci._luci import (
    SearchResults as SearchResults,
)
from luci._luci import (
    Transaction as Transaction,
)
from luci._luci import (
    set_num_threads as set_num_threads,
)
from luci.agg import (
    AggregationExpression as AggregationExpression,
)
from luci.agg import (
    AvgAgg as AvgAgg,
)
from luci.agg import (
    CardinalityAgg as CardinalityAgg,
)
from luci.agg import (
    DateHistogramAgg as DateHistogramAgg,
)
from luci.agg import (
    DateRangeAgg as DateRangeAgg,
)
from luci.agg import (
    ExtendedStatsAgg as ExtendedStatsAgg,
)
from luci.agg import (
    FilterAgg as FilterAgg,
)
from luci.agg import (
    FiltersAgg as FiltersAgg,
)
from luci.agg import (
    GeoBoundsAgg as GeoBoundsAgg,
)
from luci.agg import (
    GeoCentroidAgg as GeoCentroidAgg,
)
from luci.agg import (
    GeohashGridAgg as GeohashGridAgg,
)
from luci.agg import (
    HistogramAgg as HistogramAgg,
)
from luci.agg import (
    MaxAgg as MaxAgg,
)
from luci.agg import (
    MinAgg as MinAgg,
)
from luci.agg import (
    NestedAgg as NestedAgg,
)
from luci.agg import (
    PercentilesAgg as PercentilesAgg,
)
from luci.agg import (
    RangeAgg as RangeAgg,
)
from luci.agg import (
    ReverseNestedAgg as ReverseNestedAgg,
)
from luci.agg import (
    StatsAgg as StatsAgg,
)
from luci.agg import (
    SumAgg as SumAgg,
)
from luci.agg import (
    TermsAgg as TermsAgg,
)
from luci.agg import (
    TopHitsAgg as TopHitsAgg,
)
from luci.agg import (
    ValueCountAgg as ValueCountAgg,
)
from luci.query import (
    BoolQuery as BoolQuery,
)
from luci.query import (
    BoostingQuery as BoostingQuery,
)
from luci.query import (
    ConstantScoreQuery as ConstantScoreQuery,
)
from luci.query import (
    DisMaxQuery as DisMaxQuery,
)
from luci.query import (
    ExistsQuery as ExistsQuery,
)
from luci.query import (
    FieldValueFactor as FieldValueFactor,
)
from luci.query import (
    FieldValueModifier as FieldValueModifier,
)
from luci.query import (
    FunctionBoostMode as FunctionBoostMode,
)
from luci.query import (
    FunctionScoreMode as FunctionScoreMode,
)
from luci.query import (
    FunctionScoreQuery as FunctionScoreQuery,
)
from luci.query import (
    FusionMethod as FusionMethod,
)
from luci.query import (
    FusionQuery as FusionQuery,
)
from luci.query import (
    FuzzyQuery as FuzzyQuery,
)
from luci.query import (
    GeoBoundingBoxQuery as GeoBoundingBoxQuery,
)
from luci.query import (
    GeoDistanceQuery as GeoDistanceQuery,
)
from luci.query import (
    GeoShapeQuery as GeoShapeQuery,
)
from luci.query import (
    KnnQuery as KnnQuery,
)
from luci.query import (
    MatchAllQuery as MatchAllQuery,
)
from luci.query import (
    MatchBoolPrefixQuery as MatchBoolPrefixQuery,
)
from luci.query import (
    MatchNoneQuery as MatchNoneQuery,
)
from luci.query import (
    MatchPhraseQuery as MatchPhraseQuery,
)
from luci.query import (
    MatchQuery as MatchQuery,
)
from luci.query import (
    MultiMatchQuery as MultiMatchQuery,
)
from luci.query import (
    NestedQuery as NestedQuery,
)
from luci.query import (
    PrefixQuery as PrefixQuery,
)
from luci.query import (
    QueryExpression as QueryExpression,
)
from luci.query import (
    RandomScoreFunction as RandomScoreFunction,
)
from luci.query import (
    RangeQuery as RangeQuery,
)
from luci.query import (
    RankingExpression as RankingExpression,
)
from luci.query import (
    RegexpQuery as RegexpQuery,
)
from luci.query import (
    ScoreFunction as ScoreFunction,
)
from luci.query import (
    ScoringExpression as ScoringExpression,
)
from luci.query import (
    ScriptScoreQuery as ScriptScoreQuery,
)
from luci.query import (
    SpanExpression as SpanExpression,
)
from luci.query import (
    SpanFirstQuery as SpanFirstQuery,
)
from luci.query import (
    SpanNearQuery as SpanNearQuery,
)
from luci.query import (
    SpanNotQuery as SpanNotQuery,
)
from luci.query import (
    SpanTermQuery as SpanTermQuery,
)
from luci.query import (
    SpatialRelation as SpatialRelation,
)
from luci.query import (
    TermQuery as TermQuery,
)
from luci.query import (
    TermsQuery as TermsQuery,
)
from luci.query import (
    WeightFunction as WeightFunction,
)
from luci.query import (
    WildcardQuery as WildcardQuery,
)
from luci.search import (
    SearchExpression as SearchExpression,
)
from luci.search import (
    Sort as Sort,
)
from luci.search import (
    SortOrder as SortOrder,
)

class LuciError(Exception):
    """Base exception for all Luci errors."""

class TransactionActiveError(LuciError):
    """Write attempted on Index while a transaction is active on this thread."""

class IndexLockedError(LuciError):
    """Index is already open for writing by another process."""

class InvalidQueryError(LuciError):
    """Query DSL is malformed or references unknown fields."""

class UnsupportedQueryError(InvalidQueryError):
    feature: str
    planned: bool
    def __init__(self, feature: str, *, planned: bool = True) -> None: ...

class QueryBehaviorDifferenceError(InvalidQueryError):
    feature: str
    difference: str
    def __init__(self, feature: str, difference: str) -> None: ...

class AsyncTransaction:
    """Async transaction context manager for batched writes."""

    def __init__(self, index: Index) -> None: ...
    def add(self, doc: dict[str, Any]) -> None: ...
    async def __aenter__(self) -> Self: ...
    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: object,
    ) -> bool: ...

__version__: str
__all__: list[str] = []
