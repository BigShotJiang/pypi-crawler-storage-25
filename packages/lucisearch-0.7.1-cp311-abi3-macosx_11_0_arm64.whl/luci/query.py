"""Typed query builders for the Luci search engine.

Each query type is a frozen Pydantic ``BaseModel`` with a custom
``@model_serializer`` that produces the Luci query JSON dict.
Operator overloading (``&``, ``|``, ``~``) composes queries into
BoolQuery trees. Pydantic validates field types at construction.

Type hierarchy mirrors the Rust engine:

- ``QueryExpression`` — top-level, accepted by ``Index.search()`` and
  ``Search.query``. Either a ``ScoringExpression`` or a
  ``RankingExpression``.
- ``ScoringExpression`` — per-document scoring queries (match, term,
  bool, knn, etc.). ``BoolQuery`` clauses only accept scoring
  expressions. Operators (``&``, ``|``, ``~``) are defined here.
- ``RankingExpression`` — result-set composition (``FusionQuery``).
  Sources may be any ``QueryExpression``, enabling nested fusion.

Inspired by Polars' expression composition and Pydantic AI's
type-safe model-based configuration.

See [[feature-typed-search-api]].
"""

from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field, model_serializer


class QueryExpression(BaseModel):
    """Top-level query — scoring or ranking.

    Accepted anywhere the engine expects a ``QueryExpression``:
    ``Index.search()``, ``Search.query()``, and ``FusionQuery.sources``.
    """

    model_config = ConfigDict(frozen=True, extra="forbid")


class ScoringExpression(QueryExpression):
    """Per-document scoring query.

    All scoring queries (match, term, range, bool, knn, etc.) derive
    from this class. Operators produce the simplest equivalent
    ``BoolQuery`` by merging compatible clauses.

    Only scoring expressions can appear in ``BoolQuery`` clauses.
    Use ``FusionQuery`` to combine scoring expressions under a
    ranking fusion method.

    Simplification rules
    --------------------
    ``a & b`` returns a single BoolQuery with both sides' clauses
    merged when safe — e.g. ``Bool(must=[A]) & Bool(must=[B])`` →
    ``Bool(must=[A, B])``, ``Bool(must=[A]) & Bool(should=[B])`` →
    ``Bool(must=[A], should=[B])``. Leaf queries are treated as
    ``Bool(must=[leaf])`` before merging. Merging falls back to
    wrapping (``Bool(must=[a, b])``) when sides carry conflicting
    ``minimum_should_match``, conflicting ``boost``, or when
    combining shoulds would change the ``msm`` semantics.

    ``a | b`` returns ``Bool(should=[a, b])``. When both sides are
    pure-should Bools (no other clauses, no msm/boost), their
    should-lists are merged.

    ``~q`` returns ``Bool(must_not=[q])``. When ``q`` is itself a
    pure-must_not Bool with exactly one clause, the inner clause is
    returned directly (``~~A`` cancels).
    """

    def __and__(self, other: ScoringExpression) -> BoolQuery:
        """Compose via AND, returning the simplest equivalent Bool."""
        if not isinstance(other, ScoringExpression):
            return NotImplemented
        return _merge_and(self, other)

    def __or__(self, other: ScoringExpression) -> BoolQuery:
        """Compose via OR, returning the simplest equivalent Bool."""
        if not isinstance(other, ScoringExpression):
            return NotImplemented
        return _merge_or(self, other)

    def __invert__(self) -> ScoringExpression:
        """Negate via ``must_not``: ``~q`` → ``BoolQuery(must_not=[q])``."""
        return BoolQuery(must_not=[self])


def _as_bool(
    q: ScoringExpression,
    default_clause: Literal["must", "should"],
) -> BoolQuery:
    """Wrap ``q`` as a BoolQuery if it isn't one, placing it in ``default_clause``."""
    if isinstance(q, BoolQuery):
        return q
    if default_clause == "must":
        return BoolQuery(must=[q])
    return BoolQuery(should=[q])


def _merge_and(a: ScoringExpression, b: ScoringExpression) -> BoolQuery:
    """Simplify ``a & b`` into one BoolQuery when safe.

    Normalizes leaves as ``Bool(must=[leaf])``, then merges every
    clause list. Falls back to ``Bool(must=[a, b])`` wrapping when
    either side carries semantics that can't be merged:

    - both sides have ``minimum_should_match`` set, OR
    - both sides have ``should`` clauses and either side has
      ``minimum_should_match`` set (merging would change what the
      msm applies to), OR
    - both sides have ``boost`` set.
    """
    a_bool = _as_bool(a, "must")
    b_bool = _as_bool(b, "must")
    a_msm, b_msm = a_bool.minimum_should_match, b_bool.minimum_should_match
    a_boost, b_boost = a_bool.boost, b_bool.boost

    both_have_shoulds = bool(a_bool.should) and bool(b_bool.should)
    msm_involved = a_msm is not None or b_msm is not None
    msm_conflict = a_msm is not None and b_msm is not None
    boost_conflict = a_boost is not None and b_boost is not None

    if msm_conflict or boost_conflict or (both_have_shoulds and msm_involved):
        return BoolQuery(must=[a, b])

    return BoolQuery(
        must=[*a_bool.must, *b_bool.must],
        should=[*a_bool.should, *b_bool.should],
        must_not=[*a_bool.must_not, *b_bool.must_not],
        filter=[*a_bool.filter, *b_bool.filter],
        minimum_should_match=a_msm if a_msm is not None else b_msm,
        boost=a_boost if a_boost is not None else b_boost,
    )


def _merge_or(a: ScoringExpression, b: ScoringExpression) -> BoolQuery:
    """Simplify ``a | b`` into one BoolQuery when safe.

    If both sides are pure-should Bools (only ``should`` populated,
    no ``minimum_should_match``, no ``boost``), their should-lists
    are concatenated. Otherwise each side becomes one element of a
    new ``Bool(should=[a, b])``.
    """
    if (
        isinstance(a, BoolQuery)
        and isinstance(b, BoolQuery)
        and _is_pure_should(a)
        and _is_pure_should(b)
    ):
        return BoolQuery(should=[*a.should, *b.should])
    return BoolQuery(should=[a, b])


def _is_pure_should(q: BoolQuery) -> bool:
    """Return True iff ``q`` has only ``should`` clauses and no msm/boost."""
    return (
        not q.must
        and not q.must_not
        and not q.filter
        and q.minimum_should_match is None
        and q.boost is None
    )


class RankingExpression(QueryExpression):
    """Result-set composition query (e.g. ``FusionQuery``).

    Ranking expressions combine multiple ranked result lists rather
    than scoring individual documents. Cannot appear in ``BoolQuery``
    clauses — use at the top level of a search, or as a nested source
    inside another ``FusionQuery``.
    """


class SpanExpression(ScoringExpression):
    """Position-aware query that yields spans — not arbitrary scoring hits.

    Span queries expose ``(doc, start, end)`` tuples that outer span
    operators (``SpanFirst``, ``SpanNot``, ``SpanNear``) compose over.
    Only subclasses of this are valid as the inner of ``SpanFirst`` or
    the sides of ``SpanNot``; the Pydantic type constraint enforces
    this at construction, so a non-span inner raises ``ValidationError``
    before the engine runs.

    Concrete subclasses: ``SpanTermQuery``, ``SpanNearQuery``,
    ``SpanNotQuery``, ``SpanFirstQuery``.
    """


# ===========================================================================
# Scoring expressions
# ===========================================================================


# --- Full-text queries ---


class MatchQuery(ScoringExpression):
    """Full-text match query."""

    field: str
    query: str
    analyzer: str | None = None
    boost: float | None = None

    @model_serializer
    def _serialize(self) -> dict[str, Any]:
        body: dict[str, Any] = {"query": self.query}
        if self.analyzer is not None:
            body["analyzer"] = self.analyzer
        if self.boost is not None:
            body["boost"] = self.boost
        return {"match": {self.field: body}}


class MatchPhraseQuery(ScoringExpression):
    """Phrase match query."""

    field: str
    query: str
    analyzer: str | None = None

    @model_serializer
    def _serialize(self) -> dict[str, Any]:
        body: dict[str, Any] = {"query": self.query}
        if self.analyzer is not None:
            body["analyzer"] = self.analyzer
        return {"match_phrase": {self.field: body}}


class MultiMatchQuery(ScoringExpression):
    """Multi-field match query."""

    fields: list[str] = Field(min_length=1)
    query: str
    analyzer: str | None = None
    tie_breaker: float = 0.0

    @model_serializer
    def _serialize(self) -> dict[str, Any]:
        body: dict[str, Any] = {
            "query": self.query,
            "fields": self.fields,
        }
        if self.analyzer is not None:
            body["analyzer"] = self.analyzer
        if self.tie_breaker != 0.0:
            body["tie_breaker"] = self.tie_breaker
        return {"multi_match": body}


class MatchBoolPrefixQuery(ScoringExpression):
    """Analyzed match with a prefix on the final token.

    All tokens become term queries except the last, which becomes a
    prefix query. Rewrites to a ``bool/should``.
    """

    field: str
    query: str
    analyzer: str | None = None

    @model_serializer
    def _serialize(self) -> dict[str, Any]:
        body: dict[str, Any] = {"query": self.query}
        if self.analyzer is not None:
            body["analyzer"] = self.analyzer
        return {"match_bool_prefix": {self.field: body}}


# --- Term-level queries ---


class TermQuery(ScoringExpression):
    """Exact term match (no analysis)."""

    field: str
    value: str
    boost: float | None = None

    @model_serializer
    def _serialize(self) -> dict[str, Any]:
        if self.boost is None:
            return {"term": {self.field: self.value}}
        return {
            "term": {
                self.field: {"value": self.value, "boost": self.boost},
            },
        }


class TermsQuery(ScoringExpression):
    """Match any of a set of exact values."""

    field: str
    values: list[str] = Field(min_length=1)

    @model_serializer
    def _serialize(self) -> dict[str, Any]:
        return {"terms": {self.field: self.values}}


class RangeQuery(ScoringExpression):
    """Numeric range query."""

    field: str
    gte: float | None = None
    gt: float | None = None
    lte: float | None = None
    lt: float | None = None

    @model_serializer
    def _serialize(self) -> dict[str, Any]:
        body: dict[str, Any] = {}
        if self.gte is not None:
            body["gte"] = self.gte
        if self.gt is not None:
            body["gt"] = self.gt
        if self.lte is not None:
            body["lte"] = self.lte
        if self.lt is not None:
            body["lt"] = self.lt
        return {"range": {self.field: body}}


class PrefixQuery(ScoringExpression):
    """Prefix match on a field's term dictionary."""

    field: str
    value: str

    @model_serializer
    def _serialize(self) -> dict[str, Any]:
        return {"prefix": {self.field: self.value}}


class FuzzyQuery(ScoringExpression):
    """Fuzzy match: terms within edit distance."""

    field: str
    value: str
    fuzziness: int = Field(default=1, ge=0, le=2)

    @model_serializer
    def _serialize(self) -> dict[str, Any]:
        body: dict[str, Any] = {
            "value": self.value,
            "fuzziness": self.fuzziness,
        }
        return {"fuzzy": {self.field: body}}


class WildcardQuery(ScoringExpression):
    """Wildcard match: ``*`` (any chars) and ``?`` (single char)."""

    field: str
    value: str

    @model_serializer
    def _serialize(self) -> dict[str, Any]:
        return {"wildcard": {self.field: self.value}}


class RegexpQuery(ScoringExpression):
    """Regular expression match on term dictionary."""

    field: str
    value: str

    @model_serializer
    def _serialize(self) -> dict[str, Any]:
        return {"regexp": {self.field: self.value}}


class ExistsQuery(ScoringExpression):
    """Field existence query."""

    field: str

    @model_serializer
    def _serialize(self) -> dict[str, Any]:
        return {"exists": {"field": self.field}}


# --- Terminal queries ---


class MatchAllQuery(ScoringExpression):
    """Match all documents."""

    @model_serializer
    def _serialize(self) -> dict[str, Any]:
        return {"match_all": {}}


class MatchNoneQuery(ScoringExpression):
    """Match no documents."""

    @model_serializer
    def _serialize(self) -> dict[str, Any]:
        return {"match_none": {}}


# --- Vector query ---


class KnnQuery(ScoringExpression):
    """Approximate k-nearest-neighbor search on a ``dense_vector`` field."""

    field: str
    query_vector: list[float] = Field(min_length=1)
    k: int = Field(default=10, gt=0)
    num_candidates: int | None = Field(default=None, gt=0)
    threshold: float | None = None

    @model_serializer
    def _serialize(self) -> dict[str, Any]:
        body: dict[str, Any] = {
            "field": self.field,
            "query_vector": self.query_vector,
            "k": self.k,
        }
        if self.num_candidates is not None:
            body["num_candidates"] = self.num_candidates
        if self.threshold is not None:
            body["threshold"] = self.threshold
        return {"knn": body}


# --- Compound queries ---


class BoolQuery(ScoringExpression):
    """Boolean combination of scoring sub-queries.

    Clauses accept only ``ScoringExpression`` instances. To combine
    with a ``RankingExpression`` (e.g. Fusion), use ``FusionQuery``
    at the top level.

    Direct construction::

        BoolQuery(
            must=[MatchQuery(field="title", query="hello")],
            filter=[TermQuery(field="tag", value="tech")],
        )

    Operator composition::

        MatchQuery(...) & TermQuery(...)

    Double negation cancels: ``~BoolQuery(must_not=[A])`` returns ``A``.
    """

    must: list[ScoringExpression] = Field(default_factory=list)
    should: list[ScoringExpression] = Field(default_factory=list)
    must_not: list[ScoringExpression] = Field(default_factory=list)
    filter: list[ScoringExpression] = Field(default_factory=list)
    minimum_should_match: int | None = None
    boost: float | None = None

    def __invert__(self) -> ScoringExpression:
        """Invert a BoolQuery.

        If this is a pure ``must_not`` Bool with a single clause,
        return that clause directly (double negation cancels).
        Otherwise wrap in a new BoolQuery.
        """
        if (
            self.must_not
            and not self.must
            and not self.should
            and not self.filter
            and self.minimum_should_match is None
            and len(self.must_not) == 1
        ):
            return self.must_not[0]
        return BoolQuery(must_not=[self])

    @model_serializer
    def _serialize(self) -> dict[str, Any]:
        body: dict[str, Any] = {}
        if self.must:
            body["must"] = [q.model_dump() for q in self.must]
        if self.should:
            body["should"] = [q.model_dump() for q in self.should]
        if self.must_not:
            body["must_not"] = [q.model_dump() for q in self.must_not]
        if self.filter:
            body["filter"] = [q.model_dump() for q in self.filter]
        if self.minimum_should_match is not None:
            body["minimum_should_match"] = self.minimum_should_match
        if self.boost is not None:
            body["boost"] = self.boost
        return {"bool": body}


class DisMaxQuery(ScoringExpression):
    """Disjunction max: score from best-matching sub-query."""

    queries: list[ScoringExpression] = Field(min_length=1)
    tie_breaker: float = 0.0
    boost: float | None = None

    @model_serializer
    def _serialize(self) -> dict[str, Any]:
        body: dict[str, Any] = {
            "queries": [q.model_dump() for q in self.queries],
        }
        if self.tie_breaker != 0.0:
            body["tie_breaker"] = self.tie_breaker
        if self.boost is not None:
            body["boost"] = self.boost
        return {"dis_max": body}


class BoostingQuery(ScoringExpression):
    """Positive query with score demotion for negative matches."""

    positive: ScoringExpression
    negative: ScoringExpression
    negative_boost: float = Field(default=0.2, ge=0.0)

    @model_serializer
    def _serialize(self) -> dict[str, Any]:
        return {
            "boosting": {
                "positive": self.positive.model_dump(),
                "negative": self.negative.model_dump(),
                "negative_boost": self.negative_boost,
            },
        }


class ConstantScoreQuery(ScoringExpression):
    """Wrap a query in filter context with constant score."""

    query: ScoringExpression
    boost: float = 1.0

    @model_serializer
    def _serialize(self) -> dict[str, Any]:
        body: dict[str, Any] = {"filter": self.query.model_dump()}
        if self.boost != 1.0:
            body["boost"] = self.boost
        return {"constant_score": body}


class InnerHits(BaseModel):
    """Configuration for ``inner_hits`` on a nested query.

    Returns the matched inner documents alongside the parent hit.
    """

    model_config = ConfigDict(frozen=True, extra="forbid")

    name: str | None = None
    size: int = Field(default=3, ge=0)
    from_: int = Field(default=0, ge=0)

    @model_serializer
    def _serialize(self) -> dict[str, Any]:
        body: dict[str, Any] = {"size": self.size}
        if self.name is not None:
            body["name"] = self.name
        if self.from_:
            body["from"] = self.from_
        return body


class NestedQuery(ScoringExpression):
    """Nested query: search within nested document arrays."""

    path: str
    query: ScoringExpression
    inner_hits: InnerHits | None = None

    @model_serializer
    def _serialize(self) -> dict[str, Any]:
        body: dict[str, Any] = {
            "path": self.path,
            "query": self.query.model_dump(),
        }
        if self.inner_hits is not None:
            body["inner_hits"] = self.inner_hits.model_dump()
        return {"nested": body}


# --- Geo queries ---


class GeoDistanceQuery(ScoringExpression):
    """Geographic distance query."""

    field: str
    lat: float = Field(ge=-90.0, le=90.0)
    lon: float = Field(ge=-180.0, le=180.0)
    distance: str

    @model_serializer
    def _serialize(self) -> dict[str, Any]:
        return {
            "geo_distance": {
                "distance": self.distance,
                self.field: {"lat": self.lat, "lon": self.lon},
            },
        }


class GeoBoundingBoxQuery(ScoringExpression):
    """Geographic bounding box query."""

    field: str
    top_left_lat: float = Field(ge=-90.0, le=90.0)
    top_left_lon: float = Field(ge=-180.0, le=180.0)
    bottom_right_lat: float = Field(ge=-90.0, le=90.0)
    bottom_right_lon: float = Field(ge=-180.0, le=180.0)

    @model_serializer
    def _serialize(self) -> dict[str, Any]:
        return {
            "geo_bounding_box": {
                self.field: {
                    "top_left": {
                        "lat": self.top_left_lat,
                        "lon": self.top_left_lon,
                    },
                    "bottom_right": {
                        "lat": self.bottom_right_lat,
                        "lon": self.bottom_right_lon,
                    },
                },
            },
        }


SpatialRelation = Literal[
    "intersects",
    "within",
    "contains",
    "disjoint",
    "touches",
    "crosses",
    "overlaps",
    "equals",
    "covers",
    "coveredby",
    "contains_properly",
]


class GeoShapeQuery(ScoringExpression):
    """Geographic shape query with spatial relation.

    ``shape`` is a GeoJSON object (``{"type": "polygon", "coordinates":
    [[...]]}`` etc.). ``relation`` defaults to ``"intersects"``.
    """

    field: str
    shape: dict[str, Any]
    relation: SpatialRelation = "intersects"

    @model_serializer
    def _serialize(self) -> dict[str, Any]:
        return {
            "geo_shape": {
                self.field: {
                    "shape": self.shape,
                    "relation": self.relation,
                },
            },
        }


# --- Span queries ---


class SpanTermQuery(SpanExpression):
    """Position-aware exact term match (used as a clause in span queries)."""

    field: str
    value: str

    @model_serializer
    def _serialize(self) -> dict[str, Any]:
        return {"span_term": {self.field: self.value}}


class SpanNearQuery(SpanExpression):
    """Terms within ``slop`` positions, optionally ordered.

    All clauses must be ``SpanTermQuery`` instances on the same field.
    """

    clauses: list[SpanTermQuery] = Field(min_length=1)
    slop: int = Field(default=0, ge=0)
    in_order: bool = True

    def model_post_init(self, _context: Any, /) -> None:  # noqa: ANN401
        """Validate that all clauses are on the same field.

        ``_context`` is a Pydantic-supplied parameter whose type is
        deliberately ``Any`` (see Pydantic v2 ``model_post_init`` signature).
        """
        fields = {c.field for c in self.clauses}
        if len(fields) > 1:
            msg = (
                f"SpanNearQuery: all clauses must be on the same field; "
                f"got {sorted(fields)}"
            )
            raise ValueError(msg)

    @model_serializer
    def _serialize(self) -> dict[str, Any]:
        body: dict[str, Any] = {
            "clauses": [c.model_dump() for c in self.clauses],
        }
        if self.slop != 0:
            body["slop"] = self.slop
        if not self.in_order:
            body["in_order"] = self.in_order
        return {"span_near": body}


class SpanNotQuery(SpanExpression):
    """Include query minus exclude query.

    Both sides must be span queries — ``SpanNot`` composes at the span
    level, not over arbitrary scoring queries. The type constraint
    enforces this at construction time.
    """

    include: SpanExpression
    exclude: SpanExpression

    @model_serializer
    def _serialize(self) -> dict[str, Any]:
        return {
            "span_not": {
                "include": self.include.model_dump(),
                "exclude": self.exclude.model_dump(),
            },
        }


class SpanFirstQuery(SpanExpression):
    """Match within the first ``end`` positions.

    ``match`` must be a span query — position-filtering is only
    meaningful over span-yielding inners. The type constraint enforces
    this at construction time; wrapping a non-span query here raises a
    Pydantic ``ValidationError`` before any engine code runs.
    """

    match: SpanExpression
    end: int = Field(gt=0)

    @model_serializer
    def _serialize(self) -> dict[str, Any]:
        return {
            "span_first": {
                "match": self.match.model_dump(),
                "end": self.end,
            },
        }


# --- Script / function scoring ---


class ScriptScoreQuery(ScoringExpression):
    """Custom scoring via a compiled expression.

    The inner ``query`` selects documents; ``script`` computes each
    matching document's score. ``params`` are numeric constants
    referenced in the script as ``params.<name>``.
    """

    query: ScoringExpression
    script: str
    params: dict[str, float] = Field(default_factory=dict)

    @model_serializer
    def _serialize(self) -> dict[str, Any]:
        script_body: dict[str, Any] = {"source": self.script}
        if self.params:
            script_body["params"] = self.params
        return {
            "script_score": {
                "query": self.query.model_dump(),
                "script": script_body,
            },
        }


FieldValueModifier = Literal[
    "none",
    "log1p",
    "log2p",
    "ln1p",
    "ln2p",
    "sqrt",
    "square",
    "reciprocal",
]

FunctionScoreMode = Literal["multiply", "sum", "avg", "first", "max", "min"]
FunctionBoostMode = Literal["multiply", "replace", "sum", "avg", "max", "min"]


class ScoreFunction(BaseModel):
    """Base class for ``FunctionScoreQuery`` scoring functions."""

    model_config = ConfigDict(frozen=True, extra="forbid")


class WeightFunction(ScoreFunction):
    """Multiply score by a constant weight."""

    weight: float

    @model_serializer
    def _serialize(self) -> dict[str, Any]:
        return {"weight": self.weight}


class FieldValueFactor(ScoreFunction):
    """Score contribution from a numeric field's value."""

    field: str
    factor: float = 1.0
    modifier: FieldValueModifier = "none"
    missing: float = 1.0

    @model_serializer
    def _serialize(self) -> dict[str, Any]:
        body: dict[str, Any] = {"field": self.field}
        if self.factor != 1.0:
            body["factor"] = self.factor
        if self.modifier != "none":
            body["modifier"] = self.modifier
        if self.missing != 1.0:
            body["missing"] = self.missing
        return {"field_value_factor": body}


class RandomScoreFunction(ScoreFunction):
    """Deterministic random score per seed + document."""

    seed: int = Field(default=0, ge=0)

    @model_serializer
    def _serialize(self) -> dict[str, Any]:
        return {"random_score": {"seed": self.seed}}


class FunctionScoreQuery(ScoringExpression):
    """Modify query scores with scoring functions.

    ``functions`` is applied to each document matching ``query``.
    ``score_mode`` combines multiple function results;
    ``boost_mode`` combines the function result with the query score.
    """

    query: ScoringExpression
    functions: list[ScoreFunction] = Field(default_factory=list)
    score_mode: FunctionScoreMode = "multiply"
    boost_mode: FunctionBoostMode = "multiply"

    @model_serializer
    def _serialize(self) -> dict[str, Any]:
        body: dict[str, Any] = {"query": self.query.model_dump()}
        if self.functions:
            body["functions"] = [f.model_dump() for f in self.functions]
        if self.score_mode != "multiply":
            body["score_mode"] = self.score_mode
        if self.boost_mode != "multiply":
            body["boost_mode"] = self.boost_mode
        return {"function_score": body}


# ===========================================================================
# Ranking expressions
# ===========================================================================


FusionMethod = Literal[
    "rrf",
    "sum",
    "arithmetic_mean",
    "harmonic_mean",
    "geometric_mean",
]

# Default rank constant for Reciprocal Rank Fusion (`score = sum(1/(k+rank))`).
# The value ``60`` matches the original RRF paper and the engine's default.
_DEFAULT_RRF_RANK_CONSTANT = 60.0


class FusionQuery(RankingExpression):
    """Fuse N query sources using a configurable method.

    Sources can be any ``QueryExpression`` — scoring queries or
    nested fusion expressions. Each source is executed independently,
    then results are combined using the specified fusion method.

    ::

        FusionQuery(
            sources=[
                MatchQuery(field="title", query="wireless"),
                KnnQuery(field="embedding", query_vector=vec, k=10),
            ],
            method="rrf",
            rank_constant=60.0,
        )
    """

    sources: list[QueryExpression] = Field(min_length=2)
    method: FusionMethod = "rrf"
    rank_constant: float = Field(default=_DEFAULT_RRF_RANK_CONSTANT, gt=0.0)
    rank_window_size: int | None = Field(default=None, gt=0)
    weights: list[float] | None = None

    @model_serializer
    def _serialize(self) -> dict[str, Any]:
        body: dict[str, Any] = {
            "sources": [s.model_dump() for s in self.sources],
            "method": self.method,
        }
        if self.rank_constant != _DEFAULT_RRF_RANK_CONSTANT:
            body["rank_constant"] = self.rank_constant
        if self.rank_window_size is not None:
            body["rank_window_size"] = self.rank_window_size
        if self.weights is not None:
            body["weights"] = self.weights
        return {"fusion": body}
