"""Search request builder for the Luci search engine.

Immutable — both direct construction and ``with_*`` fluent methods
produce ``SearchExpression`` instances. Inspired by Polars' lazy API:
build the plan, execute at ``index.search()``.

Exposes the search-level features the engine honors at parse time:
query, size, offset, sort, aggs, collapse, search_after,
track_total_hits, rescore, source filtering, fields. Scoring
explanation (``_explanation``) is always present in results for
scoring queries; highlighting is accessed via ``Hit.highlight(field)``
rather than a search-level option.

See [[feature-typed-search-api]].
"""

from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field, model_serializer

from luci.agg import AggregationExpression
from luci.query import QueryExpression, ScoringExpression

SortOrder = Literal["asc", "desc"]
MissingValue = Literal["_first", "_last"]
RescoreScoreMode = Literal["total", "multiply", "avg", "max", "min"]
# A single sort-cursor value — `null` is mapped to Python None.
SortCursorValue = float | int | str | bool | None


# ---------------------------------------------------------------------------
# Sort
# ---------------------------------------------------------------------------


class Sort(BaseModel):
    """A single sort specification.

    Serializes to ``{"field": {"order": "...", "missing": "..."}}``.
    """

    model_config = ConfigDict(frozen=True, extra="forbid")

    field: str
    order: SortOrder = "asc"
    missing: MissingValue = "_last"

    @model_serializer
    def _serialize(self) -> dict[str, Any]:
        body: dict[str, Any] = {"order": self.order}
        if self.missing != "_last":
            body["missing"] = self.missing
        return {self.field: body}


# ---------------------------------------------------------------------------
# Rescore
# ---------------------------------------------------------------------------


class Rescore(BaseModel):
    """Second-pass re-ranking over the top-N hits from the primary query.

    Serializes to the ``"rescore": {...}`` search body.
    """

    model_config = ConfigDict(frozen=True, extra="forbid")

    query: ScoringExpression
    window_size: int = Field(default=10, gt=0)
    query_weight: float = 1.0
    rescore_query_weight: float = 1.0
    score_mode: RescoreScoreMode = "total"

    @model_serializer
    def _serialize(self) -> dict[str, Any]:
        return {
            "window_size": self.window_size,
            "query": {
                "rescore_query": self.query.model_dump(),
                "query_weight": self.query_weight,
                "rescore_query_weight": self.rescore_query_weight,
                "score_mode": self.score_mode,
            },
        }


# ---------------------------------------------------------------------------
# Source filtering
# ---------------------------------------------------------------------------


class SourceFilter(BaseModel):
    """Source filtering: ``includes`` and/or ``excludes`` field paths."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    includes: list[str] = Field(default_factory=list)
    excludes: list[str] = Field(default_factory=list)

    @model_serializer
    def _serialize(self) -> dict[str, Any]:
        body: dict[str, Any] = {}
        if self.includes:
            body["includes"] = self.includes
        if self.excludes:
            body["excludes"] = self.excludes
        return body


# Source can be a bool (true=enabled, false=disabled), a list of
# field paths (include-only shorthand), or a SourceFilter object.
Source = bool | list[str] | SourceFilter


# ---------------------------------------------------------------------------
# Track total hits
# ---------------------------------------------------------------------------


# Accepted forms:
# - True → exact count (engine default)
# - False → disabled
# - int → upper-bound count (e.g. 1000)
TrackTotalHits = bool | int


# ---------------------------------------------------------------------------
# Search expression
# ---------------------------------------------------------------------------


class SearchExpression(BaseModel):
    """Immutable search request builder.

    Direct construction::

        search = SearchExpression(
            query=MatchQuery(field="title", query="hello"),
            size=10,
            sort=[Sort(field="price")],
            aggs={"avg_price": AvgAgg(field="price")},
        )

    Or fluent builder via ``with_*`` methods::

        search = (SearchExpression()
            .with_query(MatchQuery(field="title", query="hello"))
            .with_size(10)
            .with_sort("price")
            .with_agg("avg_price", AvgAgg(field="price"))
        )

    Both styles produce identical results.
    """

    model_config = ConfigDict(frozen=True, extra="forbid")

    query: QueryExpression | None = None
    size: int = Field(default=10, ge=0)
    offset: int = Field(default=0, ge=0)
    sort: list[Sort] = Field(default_factory=list)
    aggs: dict[str, AggregationExpression] = Field(default_factory=dict)
    collapse: str | None = None
    search_after: list[SortCursorValue] | None = None
    track_total_hits: TrackTotalHits = True
    rescore: Rescore | None = None
    source: Source | None = None
    fields: list[str] = Field(default_factory=list)

    # --- Fluent builder methods (return new instances) ---

    def with_query(self, q: QueryExpression) -> SearchExpression:
        """Return a new SearchExpression with ``query`` set."""
        return self.model_copy(update={"query": q})

    def with_size(self, n: int) -> SearchExpression:
        """Return a new SearchExpression with ``size`` set."""
        return self.model_copy(update={"size": n})

    def with_offset(self, n: int) -> SearchExpression:
        """Return a new SearchExpression with ``offset`` set."""
        return self.model_copy(update={"offset": n})

    def with_sort(
        self,
        field: str,
        *,
        order: SortOrder | None = None,
        missing: MissingValue = "_last",
    ) -> SearchExpression:
        """Append a sort field. Returns a new SearchExpression.

        Default order: ``desc`` for ``_score``, ``asc`` for everything else.
        """
        default: SortOrder = "desc" if field == "_score" else "asc"
        entry = Sort(field=field, order=order or default, missing=missing)
        return self.model_copy(update={"sort": [*self.sort, entry]})

    def with_agg(
        self,
        name: str,
        agg: AggregationExpression,
    ) -> SearchExpression:
        """Add a named aggregation. Returns a new SearchExpression."""
        return self.model_copy(
            update={"aggs": {**self.aggs, name: agg}},
        )

    def with_collapse(self, field: str) -> SearchExpression:
        """Set field collapse. Returns a new SearchExpression."""
        return self.model_copy(update={"collapse": field})

    def with_search_after(
        self,
        cursor: list[SortCursorValue],
    ) -> SearchExpression:
        """Set the keyset-pagination cursor. Returns a new SearchExpression."""
        return self.model_copy(update={"search_after": cursor})

    def with_track_total_hits(
        self,
        track: TrackTotalHits,
    ) -> SearchExpression:
        """Set total-hits tracking mode. Returns a new SearchExpression."""
        return self.model_copy(update={"track_total_hits": track})

    def with_rescore(self, rescore: Rescore) -> SearchExpression:
        """Attach a rescore spec. Returns a new SearchExpression."""
        return self.model_copy(update={"rescore": rescore})

    def with_source(self, source: Source) -> SearchExpression:
        """Set source filtering. Returns a new SearchExpression."""
        return self.model_copy(update={"source": source})

    def with_fields(self, fields: list[str]) -> SearchExpression:
        """Set the stored-fields list. Returns a new SearchExpression."""
        return self.model_copy(update={"fields": fields})

    # --- Serialization ---

    def _core_body(self) -> dict[str, Any]:
        """Serialize query, pagination, sort, aggs, and collapse."""
        body: dict[str, Any] = {}
        if self.query is not None:
            body["query"] = self.query.model_dump()
        body["size"] = self.size
        if self.offset:
            body["from"] = self.offset
        if self.sort:
            body["sort"] = [s.model_dump() for s in self.sort]
        if self.aggs:
            body["aggs"] = {name: a.model_dump() for name, a in self.aggs.items()}
        if self.collapse:
            body["collapse"] = {"field": self.collapse}
        return body

    def _extras_body(self) -> dict[str, Any]:
        """Serialize pagination cursor, total-hits tracking, rescore, retrieval."""
        body: dict[str, Any] = {}
        if self.search_after is not None:
            body["search_after"] = self.search_after
        # track_total_hits default is True; omit when it matches default.
        if self.track_total_hits is not True:
            body["track_total_hits"] = self.track_total_hits
        if self.rescore is not None:
            body["rescore"] = self.rescore.model_dump()
        if self.source is not None:
            if isinstance(self.source, SourceFilter):
                body["_source"] = self.source.model_dump()
            else:
                body["_source"] = self.source
        if self.fields:
            body["fields"] = self.fields
        return body

    @model_serializer
    def _serialize(self) -> dict[str, Any]:
        return {**self._core_body(), **self._extras_body()}
