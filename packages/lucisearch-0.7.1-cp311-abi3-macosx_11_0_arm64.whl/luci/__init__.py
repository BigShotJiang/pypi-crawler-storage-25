"""Luci — an embeddable, in-process search engine.

Text, vector, geo, and nested document search, written in Rust with
a typed Python SDK. The Python layer handles all query construction
ergonomics; the Rust engine executes.

Usage::

    import luci

    index = luci.Index.create("/tmp/my_index", {
        "properties": {
            "title": {"type": "text"},
            "tag": {"type": "keyword"},
        }
    })

    index.add({"title": "hello world", "tag": "greeting"})

    # Typed query API (Pydantic-validated)
    results = index.search(luci.MatchQuery(field="title", query="hello"))

    # Or raw dict
    results = index.search({"match": {"title": "hello"}})
"""

from typing import Any, Self

from luci._luci import (
    Highlight,
    Index,
    IndexAdmin,
    SearchHit,
    SearchResults,
    Transaction,
    set_num_threads,
)
from luci.agg import (
    AggregationExpression,
    AvgAgg,
    CardinalityAgg,
    DateHistogramAgg,
    DateRangeAgg,
    ExtendedStatsAgg,
    FilterAgg,
    FiltersAgg,
    GeoBoundsAgg,
    GeoCentroidAgg,
    GeohashGridAgg,
    HistogramAgg,
    MaxAgg,
    MinAgg,
    NestedAgg,
    PercentilesAgg,
    RangeAgg,
    ReverseNestedAgg,
    StatsAgg,
    SumAgg,
    TermsAgg,
    TopHitsAgg,
    ValueCountAgg,
)
from luci.query import (
    BoolQuery,
    BoostingQuery,
    ConstantScoreQuery,
    DisMaxQuery,
    ExistsQuery,
    FieldValueFactor,
    FieldValueModifier,
    FunctionBoostMode,
    FunctionScoreMode,
    FunctionScoreQuery,
    FusionMethod,
    FusionQuery,
    FuzzyQuery,
    GeoBoundingBoxQuery,
    GeoDistanceQuery,
    GeoShapeQuery,
    InnerHits,
    KnnQuery,
    MatchAllQuery,
    MatchBoolPrefixQuery,
    MatchNoneQuery,
    MatchPhraseQuery,
    MatchQuery,
    MultiMatchQuery,
    NestedQuery,
    PrefixQuery,
    QueryExpression,
    RandomScoreFunction,
    RangeQuery,
    RankingExpression,
    RegexpQuery,
    ScoreFunction,
    ScoringExpression,
    ScriptScoreQuery,
    SpanExpression,
    SpanFirstQuery,
    SpanNearQuery,
    SpanNotQuery,
    SpanTermQuery,
    SpatialRelation,
    TermQuery,
    TermsQuery,
    WeightFunction,
    WildcardQuery,
)
from luci.search import (
    MissingValue,
    Rescore,
    RescoreScoreMode,
    SearchExpression,
    Sort,
    SortCursorValue,
    SortOrder,
    Source,
    SourceFilter,
    TrackTotalHits,
)


class AsyncTransaction:
    """Async transaction context manager for batched writes.

    Wraps ``Index.transaction()`` for use with ``async with``.
    The blocking lock acquisition runs in a thread pool via
    ``asyncio.to_thread`` so the event loop is never blocked.

    Example::

        async with index.async_transaction() as txn:
            txn.add({"title": "doc 1"})
            txn.add({"title": "doc 2"})

    """

    def __init__(self, index: Index) -> None:
        """Create an async transaction for the given index."""
        self._index = index
        self._txn: Transaction | None = None

    def add(self, doc: dict[str, Any]) -> None:
        """Add a document to the transaction buffer."""
        if self._txn is None:
            msg = "transaction not active — use 'async with index.async_transaction()'"
            raise RuntimeError(msg)
        self._txn.add(doc)

    async def __aenter__(self) -> Self:
        """Acquire exclusive write access in a thread pool."""
        self._txn = self._index.transaction()
        self._txn.__enter__()
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: object,
    ) -> bool:
        """Commit or rollback."""
        assert self._txn is not None  # noqa: S101
        result = self._txn.__exit__(exc_type, exc_val, exc_tb)
        self._txn = None
        return result


def _async_transaction(self: Index) -> AsyncTransaction:
    """Create an async transaction context manager."""
    return AsyncTransaction(self)


Index.async_transaction = _async_transaction  # type: ignore[attr-defined]


# --- Exception hierarchy ---


class LuciError(Exception):
    """Base exception for all Luci errors."""


class TransactionActiveError(LuciError):
    """Write attempted on Index while a transaction is active on this thread."""


class IndexLockedError(LuciError):
    """Index is already open for writing by another process."""


class InvalidQueryError(LuciError):
    """Query DSL is malformed or references unknown fields."""


class UnsupportedQueryError(InvalidQueryError):
    """Query feature that Luci does not yet support."""

    def __init__(self, feature: str, *, planned: bool = True) -> None:
        """Create an UnsupportedQueryError for the given feature."""
        status = "not yet supported" if planned else "not supported"
        super().__init__(f"{feature} is {status} in Luci")
        self.feature = feature
        self.planned = planned


class QueryBehaviorDifferenceError(InvalidQueryError):
    """Query feature where Luci's behavior intentionally differs."""

    def __init__(self, feature: str, difference: str) -> None:
        """Create a QueryBehaviorDifferenceError for the given feature."""
        super().__init__(f"{feature}: {difference}")
        self.feature = feature
        self.difference = difference


__all__ = [
    # Core
    "AggregationExpression",
    "AsyncTransaction",
    "AvgAgg",
    "BoolQuery",
    "BoostingQuery",
    "CardinalityAgg",
    "ConstantScoreQuery",
    "DateHistogramAgg",
    "DateRangeAgg",
    "DisMaxQuery",
    "ExistsQuery",
    "ExtendedStatsAgg",
    "FieldValueFactor",
    "FieldValueModifier",
    "FilterAgg",
    "FiltersAgg",
    "FunctionBoostMode",
    "FunctionScoreMode",
    "FunctionScoreQuery",
    "FusionMethod",
    "FusionQuery",
    "FuzzyQuery",
    "GeoBoundingBoxQuery",
    "GeoBoundsAgg",
    "GeoCentroidAgg",
    "GeoDistanceQuery",
    "GeoShapeQuery",
    "GeohashGridAgg",
    "Highlight",
    "HistogramAgg",
    "Index",
    "IndexAdmin",
    "IndexLockedError",
    "InnerHits",
    "InvalidQueryError",
    "KnnQuery",
    "LuciError",
    "MatchAllQuery",
    "MatchBoolPrefixQuery",
    "MatchNoneQuery",
    "MatchPhraseQuery",
    "MatchQuery",
    "MaxAgg",
    "MinAgg",
    "MissingValue",
    "MultiMatchQuery",
    "NestedAgg",
    "NestedQuery",
    "PercentilesAgg",
    "PrefixQuery",
    "QueryBehaviorDifferenceError",
    "QueryExpression",
    "RandomScoreFunction",
    "RangeAgg",
    "RangeQuery",
    "RankingExpression",
    "RegexpQuery",
    "Rescore",
    "RescoreScoreMode",
    "ReverseNestedAgg",
    "ScoreFunction",
    "ScoringExpression",
    "ScriptScoreQuery",
    "SearchExpression",
    "SearchHit",
    "SearchResults",
    "Sort",
    "SortCursorValue",
    "SortOrder",
    "Source",
    "SourceFilter",
    "SpanExpression",
    "SpanFirstQuery",
    "SpanNearQuery",
    "SpanNotQuery",
    "SpanTermQuery",
    "SpatialRelation",
    "StatsAgg",
    "SumAgg",
    "TermQuery",
    "TermsAgg",
    "TermsQuery",
    "TopHitsAgg",
    "TrackTotalHits",
    "Transaction",
    "TransactionActiveError",
    "UnsupportedQueryError",
    "ValueCountAgg",
    "WeightFunction",
    "WildcardQuery",
    "set_num_threads",
]
__version__ = "0.6.2"
