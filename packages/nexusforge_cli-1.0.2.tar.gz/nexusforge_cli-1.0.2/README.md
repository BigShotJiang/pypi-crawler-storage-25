# NexusForge CLI

Enterprise AI Agent Orchestration Platform — setup and management CLI.

## Install

```bash
pip install nexusforge-cli
```

## Commands

```bash
nexusforge setup          # Full environment setup (Python, Node, Ollama, LLMs, Kiro)
nexusforge status         # Check all services status
nexusforge dev            # Start local dev environment
nexusforge tunnel         # Expose Ollama to Render via Cloudflare
nexusforge agents         # View 24 agent profiles with experience
nexusforge models         # Show LLM fallback chain
nexusforge kiro           # Generate/refresh Kiro specs
nexusforge rules          # Show work rules and guidelines
```

## What `nexusforge setup` installs

| Component | Purpose |
|-----------|---------|
| deepseek-r1:8b | Chat with visible thinking |
| qwen2.5-coder:7b | Code/JSON agents |
| llama3.1:8b | Language agents |
| gemma3:4b | Fast classification |
| nomic-embed-text | RAG embeddings |
| Kiro specs | Steering, memory, hooks |
| Backend deps | FastAPI, asyncpg, etc. |
| Frontend deps | React, Vite |

## Architecture

```
Local: Ollama (5 LLMs) + FastAPI + React
Cloud: Vercel + Render + PostgreSQL + Redis
LLM:   deepseek-r1 → Groq (free) → Claude (paid)
```

## Links

- Demo: https://nexusforge-two.vercel.app
- API: https://nexusforge-api.onrender.com
- Repo: https://github.com/christianescamilla15-cell/nexusforge-ai
