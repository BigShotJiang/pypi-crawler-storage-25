# Work Rules

## Critical Rules
1. NEVER use PUT on Render env-vars API without including ALL existing vars
2. NEVER modify existing encapsulated components — add new ones alongside
3. ALWAYS verify destructive API calls before executing
4. ALWAYS update memory after mistakes and key decisions
5. Quality over speed — do it right, not fast
6. ALWAYS build locally and verify before pushing

## Deployment
- Render service: srv-d75b2575r7bs73b22gp0
- Database: dpg-d75b1cpr0fns73blrtdg-a (nexusforge-db)
- Frontend: nexusforge-two.vercel.app (auto-deploy from master)
- Backend: nexusforge-api.onrender.com (auto-deploy from master)
- PUT /env-vars REPLACES ALL — always GET first, then PUT full list

## Development Flow
1. Read ALL affected files before changing anything
2. Plan the change mentally before writing code
3. Make the minimum change needed
4. Build locally (vite build, pytest)
5. Commit with descriptive message
6. Push and verify deploy
