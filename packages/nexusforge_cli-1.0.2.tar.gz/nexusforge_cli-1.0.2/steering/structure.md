# Project Structure

```
backend/
  app/
    agents/          — 24 agent implementations (base.py, capabilities.py, judge.py)
    auth/            — JWT, Google OAuth, middleware, billing, API keys
    config.py        — Settings (Pydantic v2)
    db/              — PostgreSQL client, migrations (35 applied)
    engine/          — DAG execution, state machine, retry policy
    healing/         — Circuit breaker, self-healing strategies
    integrations/    — Email (Resend), Slack, Notion, Drive, Gmail
    llm/             — Router, providers (Ollama, Groq, Claude), local_client
    main.py          — FastAPI app, middleware stack (CORS outermost)
    memory/          — Manager, episodic (Mongo), semantic (pgvector), working (Redis), orchestrator, experience
    models/          — Pydantic schemas (workflow, execution, document)
    rag/             — Embeddings (Voyage AI + nomic), indexer, retriever
    routes/          — 25+ API route files
    swarms/          — 6 topologies + local_council (second opinion)
  tests/             — 260+ pytest tests

frontend/
  src/
    features/
      chat-first/    — Main interface: ChatPanel (60%) + PreviewPanel (40%)
      chat/          — Floating guide chat (ChatAssistant, always Groq)
      dashboard/     — Classic KPIs (at /dashboard-classic)
      automations/   — Automation list, RunInputModal, OutputDestinations
      wizard/        — Step-by-step wizard (legacy, at /wizard)
      workflows/     — Builder, list, detail pages
      agents/        — Agent list with profiles
      auth/          — AuthPage with Google OAuth
    shared/
      components/    — Layout, Toast, ErrorBoundary, CommandPalette
      hooks/         — useLanguage, useToast, useRefreshOnFocus
    services/
      api.js         — fetchAPI, getApiUrl, checkBackendHealth
```
