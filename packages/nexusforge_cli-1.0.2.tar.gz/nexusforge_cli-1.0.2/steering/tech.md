# Tech Stack

## Backend
- Python 3.12, FastAPI, asyncpg, Pydantic v2
- PostgreSQL 16 + pgvector (semantic memory)
- MongoDB 7 (episodic memory)
- Redis 7 (working memory, cache, queue)

## Frontend
- React 18, Vite 8, vanilla CSS
- Chat-first dashboard (ChatPanel + PreviewPanel)
- Google OAuth + JWT auth

## LLM Infrastructure
- Ollama (local): deepseek-r1:8b, qwen2.5-coder:7b, llama3.1:8b, gemma3:4b, nomic-embed-text
- Groq API (free cloud): llama-3.3-70b-versatile
- Claude API (paid cloud): claude-sonnet-4
- Cloudflare tunnel: exposes local Ollama to Render

## Key Patterns
- Per-agent model routing (each agent gets dedicated LLM)
- 3-tier memory: working (Redis) → episodic (MongoDB) → semantic (pgvector)
- Circuit breaker for agent health
- ExperienceCollector records every execution
- OrchestratorMemory for system-wide knowledge
- CORS middleware must be outermost (wraps AuthMiddleware 401s)
