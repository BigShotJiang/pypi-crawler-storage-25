# Agent Profiles & Experience

## Classification Tier (gemma3:4b — fast)
| Agent | Success Rate | Avg Latency | Key Patterns |
|-------|-------------|-------------|--------------|
| ClassifierAgent | 97% | 800ms | Urgency keywords, invoice patterns, complaint detection |
| RouterAgent | 96% | 600ms | Route by category, load balancing |
| SentimentAgent | 95% | 600ms | Urgency scale (critical/high/medium/low), sarcasm detection |
| MonitorAgent | 94% | 500ms | Health metrics, threshold alerts |

## Structured Output Tier (qwen2.5-coder:7b)
| Agent | Success Rate | Avg Latency | Key Patterns |
|-------|-------------|-------------|--------------|
| ExtractorAgent | 94% | 1200ms | Multi-field extraction, JSON schema prompts |
| AnalyzerAgent | 92% | 1800ms | Trend detection, anomaly flagging |
| ValidatorAgent | 98% | 900ms | Duplicate hashing, format validation |
| NormalizerAgent | 95% | 1000ms | Data cleaning, format standardization |
| OCRAgent | 88% | 2500ms | PDF > image quality, table extraction |
| JudgeAgent | 95% | 1000ms | Weighted Borda Count, 3+ agent consensus |

## Language Tier (llama3.1:8b)
| Agent | Success Rate | Avg Latency | Key Patterns |
|-------|-------------|-------------|--------------|
| SummarizerAgent | 96% | 1500ms | 3-5 bullet executive summaries |
| ReporterAgent | 93% | 2000ms | Summary → KPIs → details → recommendations |
| TranslatorAgent | 97% | 1200ms | Multi-language, preserves formatting |
| ResearcherAgent | 91% | 3000ms | Web scraping, citation generation |
| KnowledgeAgent | 93% | 1500ms | RAG retrieval, context injection |

## Cloud Tier
| Agent | Provider | Success Rate | Use Case |
|-------|----------|-------------|----------|
| ComplianceAgent | Claude | 99% | Regulatory, PII detection, audit trail |
| PlannerAgent | Groq | 94% | Task decomposition, large context |
| CriticAgent | Groq | 92% | Quality critique, improvement suggestions |
