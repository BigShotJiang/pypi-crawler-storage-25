---
name: "nexusforge-ai"
displayName: "NexusForge AI"
description: "Enterprise AI Agent Orchestration Platform — 24 agents, 5 local LLMs, chat-first interface with visible thinking, Kiro specs, and full deployment management."
keywords: ["nexusforge", "agents", "orchestration", "automation", "workflow", "llm", "ollama", "deepseek", "tickets", "invoices", "reports", "dashboard"]
---

# Onboarding

## Step 1: Verify Python
Ensure Python 3.12+ is installed:
- **Python**: `python --version` or check `C:\Users\DANNY\AppData\Local\Programs\Python\Python312\python.exe`

## Step 2: Verify Ollama
Ensure Ollama is running with local models:
- **Ollama**: `ollama list` should show deepseek-r1:8b, qwen2.5-coder:7b, llama3.1:8b, gemma3:4b, nomic-embed-text

## Step 3: Verify NexusForge CLI
```bash
nexusforge status
```

## Step 4: Initialize Kiro specs
```bash
nexusforge kiro
```
This generates steering, memory, and hooks in `.kiro/`

# Agent Architecture

NexusForge has 24 specialized AI agents, each with a dedicated local LLM:

## Model Assignment
- **gemma3:4b** (fast) → ClassifierAgent, RouterAgent, SentimentAgent, MonitorAgent
- **qwen2.5-coder:7b** (structured) → ExtractorAgent, AnalyzerAgent, ValidatorAgent, OCRAgent, JudgeAgent
- **llama3.1:8b** (language) → SummarizerAgent, ReporterAgent, TranslatorAgent, ResearcherAgent
- **claude** (cloud) → ComplianceAgent (regulatory, high-stakes)
- **groq** (cloud) → PlannerAgent, CriticAgent (large context)

## LLM Fallback Chain
1. deepseek-r1:8b (local, free, thinking nativo)
2. Groq llama-3.3-70b (cloud, free, 24/7)
3. Claude API (cloud, paid, last resort)

# When to Load Steering Files
- Project structure and conventions → `steering/structure.md`
- Work rules and deployment → `steering/work-rules.md`
- Agent profiles and experience → `steering/agents.md`
- Tech stack details → `steering/tech.md`
