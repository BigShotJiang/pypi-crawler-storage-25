"""NexusForge CLI — setup, configure, and manage your AI orchestration platform."""

import os
import sys
import json
import subprocess
import platform

import click
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.progress import Progress, SpinnerColumn, TextColumn

console = Console()

REPO_URL = "https://github.com/christianescamilla15-cell/nexusforge-ai.git"
OLLAMA_MODELS = [
    ("deepseek-r1:8b", "Chat inteligente (thinking nativo)", "4.9GB"),
    ("qwen2.5-coder:7b", "Agentes de codigo/JSON", "4.7GB"),
    ("llama3.1:8b", "Agentes de lenguaje", "4.9GB"),
    ("gemma3:4b", "Clasificacion/routing rapido", "3.3GB"),
    ("nomic-embed-text", "Embeddings RAG", "274MB"),
]


def run(cmd, check=False, capture=True):
    """Run a shell command."""
    try:
        result = subprocess.run(cmd, shell=True, capture_output=capture, text=True, timeout=600)
        return result.returncode == 0, result.stdout.strip()
    except Exception as e:
        return False, str(e)


def get_python():
    """Find Python executable — checks PATH first, then common install locations."""
    for cmd in ["python", "python3", sys.executable]:
        ok, ver = run(f"{cmd} --version")
        if ok:
            return cmd, ver
    # Windows common paths
    for path in [
        os.path.expandvars(r"%LOCALAPPDATA%\Programs\Python\Python312\python.exe"),
        os.path.expandvars(r"%LOCALAPPDATA%\Programs\Python\Python313\python.exe"),
        r"C:\Python312\python.exe",
    ]:
        if os.path.exists(path):
            ok, ver = run(f'"{path}" --version')
            if ok:
                return path, ver
    return None, None


@click.group()
@click.version_option(version="1.0.0")
def cli():
    """NexusForge AI — Enterprise Agent Orchestration Platform CLI."""
    pass


@cli.command()
@click.option("--skip-models", is_flag=True, help="Skip downloading Ollama models")
@click.option("--skip-deps", is_flag=True, help="Skip installing project dependencies")
def setup(skip_models, skip_deps):
    """Full environment setup — installs everything from scratch."""
    console.print(Panel.fit(
        "[bold cyan]NexusForge AI — Full Environment Setup[/bold cyan]\n"
        "This will install Python deps, Node deps, Ollama, LLMs, and Kiro specs.",
        border_style="cyan",
    ))

    # 1. Check prerequisites
    console.print("\n[bold yellow][1/6] Checking prerequisites...[/bold yellow]")

    python_cmd, ver = get_python()
    if python_cmd:
        console.print(f"  [green]OK[/green] Python: {ver} ({python_cmd})")
    else:
        console.print("  [red]MISSING[/red] Python — install from python.org")
        return

    ok, ver = run("node --version")
    if ok:
        console.print(f"  [green]OK[/green] Node.js: {ver}")
    else:
        console.print("  [yellow]WARN[/yellow] Node.js not found — frontend won't build")

    ok, ver = run("git --version")
    if ok:
        console.print(f"  [green]OK[/green] Git: {ver}")
    else:
        console.print("  [red]MISSING[/red] Git — install from git-scm.com")
        return

    # 2. Ollama
    console.print("\n[bold yellow][2/6] Setting up Ollama...[/bold yellow]")
    ok, _ = run("ollama --version")
    if ok:
        console.print("  [green]OK[/green] Ollama installed")
    else:
        console.print("  [yellow]WARN[/yellow] Ollama not installed — download from ollama.com")
        console.print("  [dim]Local LLMs won't be available until Ollama is installed[/dim]")

    # Set env vars for tunnel support
    if platform.system() == "Windows":
        os.system('setx OLLAMA_ORIGINS "*" >nul 2>&1')
        os.system('setx OLLAMA_HOST "0.0.0.0" >nul 2>&1')
        console.print("  [green]OK[/green] OLLAMA_ORIGINS=* and OLLAMA_HOST=0.0.0.0 set")

    # 3. Pull models
    if not skip_models:
        console.print("\n[bold yellow][3/6] Pulling AI models...[/bold yellow]")
        ok, _ = run("ollama --version")
        if ok:
            for model, desc, size in OLLAMA_MODELS:
                console.print(f"  [dim]Pulling {model} ({size}) — {desc}[/dim]")
                run(f"ollama pull {model}")
                console.print(f"  [green]OK[/green] {model}")
        else:
            console.print("  [yellow]SKIP[/yellow] Ollama not available")
    else:
        console.print("\n[bold yellow][3/6] Skipping model downloads[/bold yellow]")

    # 4. Clone/update repo
    console.print("\n[bold yellow][4/6] Setting up NexusForge project...[/bold yellow]")
    project_dir = os.path.join(os.path.expanduser("~"), "Desktop", "portafolio-completo", "proyectos", "07-nexusforge-ai")

    if os.path.exists(os.path.join(project_dir, ".git")):
        console.print("  [green]OK[/green] Repo exists — pulling latest")
        run(f"cd {project_dir} && git pull origin master")
    else:
        console.print(f"  [dim]Cloning to {project_dir}...[/dim]")
        os.makedirs(os.path.dirname(project_dir), exist_ok=True)
        run(f"git clone {REPO_URL} {project_dir}")
        console.print("  [green]OK[/green] Repo cloned")

    # 5. Install dependencies
    if not skip_deps:
        console.print("\n[bold yellow][5/6] Installing dependencies...[/bold yellow]")
        backend_dir = os.path.join(project_dir, "backend")
        frontend_dir = os.path.join(project_dir, "frontend")

        if os.path.exists(os.path.join(backend_dir, "requirements.txt")):
            console.print("  [dim]Installing backend deps...[/dim]")
            run(f'cd {backend_dir} && "{python_cmd}" -m pip install -r requirements.txt -q')
            console.print("  [green]OK[/green] Backend dependencies")

        if os.path.exists(os.path.join(frontend_dir, "package.json")):
            console.print("  [dim]Installing frontend deps...[/dim]")
            run(f"cd {frontend_dir} && npm install --silent")
            console.print("  [green]OK[/green] Frontend dependencies")
    else:
        console.print("\n[bold yellow][5/6] Skipping dependency install[/bold yellow]")

    # 6. Generate Kiro specs
    console.print("\n[bold yellow][6/6] Generating Kiro specs + agent memory...[/bold yellow]")
    from .kiro_specs import generate_kiro_specs
    kiro_dir = generate_kiro_specs(project_dir)
    console.print(f"  [green]OK[/green] Kiro specs at {kiro_dir}")

    # Also init AIOS if available
    ok, _ = run("aios --version")
    if ok:
        run(f"cd {project_dir} && aios init")
        console.print("  [green]OK[/green] AIOS initialized")

    # Summary
    console.print("\n")
    console.print(Panel.fit(
        "[bold green]Setup Complete![/bold green]\n\n"
        "[cyan]Installed:[/cyan]\n"
        "  5 local LLMs (deepseek-r1, qwen, llama, gemma, nomic)\n"
        "  Kiro steering + memory + hooks\n"
        "  Backend + frontend dependencies\n\n"
        "[cyan]Next steps:[/cyan]\n"
        "  nexusforge status     — Check everything is running\n"
        "  nexusforge dev        — Start dev environment\n"
        "  nexusforge tunnel     — Expose Ollama to Render\n"
        "  nexusforge agents     — View agent profiles\n",
        border_style="green",
    ))


@cli.command()
def status():
    """Check status of all NexusForge services."""
    console.print(Panel.fit("[bold cyan]NexusForge AI — System Status[/bold cyan]", border_style="cyan"))

    table = Table(show_header=True, header_style="bold")
    table.add_column("Service", style="cyan")
    table.add_column("Status")
    table.add_column("Details", style="dim")

    # Python
    ok, ver = run("python --version")
    table.add_row("Python", "[green]OK[/green]" if ok else "[red]MISSING[/red]", ver if ok else "Install python.org")

    # Node
    ok, ver = run("node --version")
    table.add_row("Node.js", "[green]OK[/green]" if ok else "[yellow]WARN[/yellow]", ver if ok else "Install nodejs.org")

    # Ollama
    ok, _ = run("ollama --version")
    table.add_row("Ollama", "[green]OK[/green]" if ok else "[red]DOWN[/red]", "Local LLM server")

    # Models
    if ok:
        ok2, tags = run("ollama list")
        if ok2:
            model_count = len([l for l in tags.split("\n") if l.strip() and not l.startswith("NAME")])
            table.add_row("Local Models", f"[green]{model_count}[/green]", f"{model_count} models loaded")

    # Render backend
    try:
        import httpx
        r = httpx.get("https://nexusforge-api.onrender.com/api/health", timeout=10)
        data = r.json()
        db = data.get("components", {}).get("database", "?")
        table.add_row("Render Backend", "[green]OK[/green]", f"DB: {db}, Agents: {data.get('agent_count', '?')}")
    except Exception:
        table.add_row("Render Backend", "[yellow]SLEEPING[/yellow]", "Free tier — wakes on request")

    # Vercel frontend
    try:
        import httpx
        r = httpx.get("https://nexusforge-two.vercel.app/", timeout=10)
        table.add_row("Vercel Frontend", "[green]OK[/green]" if r.status_code == 200 else "[red]DOWN[/red]", "nexusforge-two.vercel.app")
    except Exception:
        table.add_row("Vercel Frontend", "[yellow]UNKNOWN[/yellow]", "Could not check")

    console.print(table)


@cli.command()
def agents():
    """View all agent profiles with experience data."""
    from .agents import AGENT_PROFILES

    console.print(Panel.fit("[bold cyan]NexusForge AI — Agent Profiles[/bold cyan]", border_style="cyan"))

    table = Table(show_header=True, header_style="bold")
    table.add_column("Agent", style="cyan", width=20)
    table.add_column("Model", style="yellow", width=18)
    table.add_column("Role", width=35)
    table.add_column("Success", justify="center", width=8)
    table.add_column("Runs", justify="center", width=6)

    for name, profile in AGENT_PROFILES.items():
        exp = profile.get("experience", {})
        rate = f"{exp.get('success_rate', 0) * 100:.0f}%"
        runs = str(exp.get("total_executions", 0))
        table.add_row(name, profile["model"], profile["role"][:35], rate, runs)

    console.print(table)


@cli.command()
def models():
    """Show LLM fallback chain and local model status."""
    from .agents import LLM_FALLBACK_CHAIN

    console.print(Panel.fit("[bold cyan]LLM Fallback Chain[/bold cyan]", border_style="cyan"))

    table = Table(show_header=True, header_style="bold")
    table.add_column("Priority", justify="center", width=8)
    table.add_column("Provider", style="cyan", width=12)
    table.add_column("Model", style="yellow", width=25)
    table.add_column("Role", width=20)
    table.add_column("Cost", width=6)

    for i, entry in enumerate(LLM_FALLBACK_CHAIN, 1):
        table.add_row(str(i), entry["provider"], entry["model"], entry["role"], entry["cost"])

    console.print(table)


@cli.command()
def dev():
    """Start local development environment (Ollama + backend + frontend)."""
    console.print(Panel.fit("[bold cyan]Starting NexusForge Dev Environment[/bold cyan]", border_style="cyan"))

    project_dir = os.path.join(os.path.expanduser("~"), "Desktop", "portafolio-completo", "proyectos", "07-nexusforge-ai")

    if not os.path.exists(project_dir):
        console.print("[red]Project not found. Run 'nexusforge setup' first.[/red]")
        return

    console.print("  [1] Starting Ollama...")
    subprocess.Popen("ollama serve", shell=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

    console.print("  [2] Starting backend (port 8000)...")
    subprocess.Popen(
        f"cd {project_dir}/backend && python -m uvicorn app.main:app --reload --port 8000",
        shell=True,
    )

    console.print("  [3] Starting frontend (port 5173)...")
    subprocess.Popen(
        f"cd {project_dir}/frontend && npm run dev",
        shell=True,
    )

    console.print("\n  [green]NexusForge running![/green]")
    console.print("  Frontend: http://localhost:5173")
    console.print("  Backend:  http://localhost:8000/docs")
    console.print("  Ollama:   http://localhost:11434")


@cli.command()
def tunnel():
    """Start Cloudflare tunnel to expose local Ollama to Render."""
    console.print(Panel.fit("[bold cyan]Ollama Tunnel[/bold cyan]", border_style="cyan"))

    # Check Ollama
    ok, _ = run("curl -s http://localhost:11434/api/tags")
    if not ok:
        console.print("[red]Ollama is not running. Start it first.[/red]")
        return

    # Find cloudflared
    cf_path = os.path.join(os.path.expanduser("~"), "Desktop", "cloudflared.exe")
    if not os.path.exists(cf_path):
        console.print("[yellow]cloudflared not found. Downloading...[/yellow]")
        run(f'curl -L -o "{cf_path}" https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-windows-amd64.exe')

    console.print("  Starting tunnel to localhost:11434...")
    console.print("  [dim]The tunnel URL will appear below. Copy it to Render as OLLAMA_TUNNEL_URL[/dim]")
    os.system(f'"{cf_path}" tunnel --url http://localhost:11434')


@cli.command()
def kiro():
    """Generate/refresh Kiro specs, steering, memory, and hooks."""
    from .kiro_specs import generate_kiro_specs

    project_dir = os.path.join(os.path.expanduser("~"), "Desktop", "portafolio-completo", "proyectos", "07-nexusforge-ai")

    if not os.path.exists(project_dir):
        console.print("[red]Project not found. Run 'nexusforge setup' first.[/red]")
        return

    kiro_dir = generate_kiro_specs(project_dir)
    console.print(f"[green]Kiro specs generated at {kiro_dir}[/green]")
    console.print("  steering/product.md — Product context")
    console.print("  steering/tech.md — Tech stack")
    console.print("  steering/structure.md — Project structure")
    console.print("  steering/work-rules.md — Work rules & deployment")
    console.print("  memory/ — Agent experience, risks, decisions")
    console.print("  hooks/ — Pre-commit, test-on-change, build-check")


@cli.command()
def rules():
    """Show work rules and critical guidelines."""
    from .kiro_specs import WORK_RULES
    console.print(Panel(WORK_RULES, title="[bold]Work Rules[/bold]", border_style="yellow"))


if __name__ == "__main__":
    cli()
