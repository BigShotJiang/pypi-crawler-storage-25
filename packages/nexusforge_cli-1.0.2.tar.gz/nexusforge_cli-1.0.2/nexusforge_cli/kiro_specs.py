"""Kiro specs generator — creates steering, memory, and hooks for NexusForge projects."""

import os
import json

# ── Kiro Steering Rules ─────────────────────────────────────────────────────

STEERING_PRODUCT = """# Product Context — NexusForge AI

## What is this?
Enterprise-grade AI Agent Orchestration Platform with:
- 24 specialized AI agents with dedicated local LLMs
- Chat-first interface with visible thinking (deepseek-r1)
- 6 swarm topologies for complex workflows
- Google OAuth + Stripe billing
- 12 integrations (Email, Slack, Notion, Drive, Sheets, Gmail, Webhook, API)
- Orchestrator memory system (agents learn from experience)
- LLM fallback chain: local (Ollama) → Groq (free) → Claude (paid)

## Target Users
- Business operators automating repetitive processes
- Teams processing tickets, invoices, emails, reports
- Enterprises needing compliance + audit trail

## Key Principles
1. Users should NEVER see technical details (JSON, agent names, topologies)
2. The chat guides step by step — ONE question at a time
3. Everything runs locally first (privacy), cloud as fallback
4. Every agent execution is recorded as experience for future learning
"""

STEERING_TECH = """# Tech Context — NexusForge AI

## Stack
- Backend: Python 3.12, FastAPI, asyncpg, asyncio
- Frontend: React 18, Vite 8, vanilla CSS (no Tailwind)
- Database: PostgreSQL 16 + pgvector, MongoDB 7 (episodic memory)
- Cache: Redis 7
- LLM: Ollama (5 models), Groq API, Claude API
- Embeddings: Voyage AI (512d) + nomic-embed-text (local)
- Deploy: Vercel (frontend), Render (backend)

## Architecture
- DAG-based workflow execution engine
- Per-agent model routing (gemma→routing, qwen→code, llama→language)
- 3-tier memory: working (Redis), episodic (MongoDB), semantic (pgvector)
- Circuit breaker pattern for agent health
- ExperienceCollector for agent learning
- OrchestratorMemory for system-wide knowledge

## Conventions
- English for code, Spanish for user-facing strings
- Pydantic v2 for all models
- Type hints on all functions
- Never modify existing encapsulated components — add new ones alongside
"""

STEERING_STRUCTURE = """# Project Structure

```
backend/
  app/
    agents/          — 24 agent implementations (base.py, capabilities.py)
    auth/            — JWT, OAuth, middleware, billing
    config.py        — Settings (Pydantic v2)
    db/              — PostgreSQL client, migrations
    engine/          — DAG execution, state machine, retry
    healing/         — Circuit breaker, self-healing
    integrations/    — Email, Slack, Notion, Drive, Gmail
    llm/             — Router, providers (Ollama, Groq, Claude)
    main.py          — FastAPI app, middleware stack
    memory/          — Manager, episodic, semantic, working, orchestrator
    models/          — Pydantic schemas
    rag/             — Embeddings, indexer, retriever
    routes/          — API endpoints
    swarms/          — Topologies (sequential, parallel, etc.)
  tests/             — 260+ pytest tests

frontend/
  src/
    features/
      chat-first/    — Main chat interface (ChatPanel, PreviewPanel)
      chat/          — Floating guide chat (ChatAssistant)
      dashboard/     — KPIs, metrics
      automations/   — Automation management
      wizard/        — Step-by-step wizard (legacy)
      workflows/     — Workflow builder
    shared/
      components/    — Layout, Toast, ErrorBoundary
      hooks/         — useLanguage, useToast, useRefreshOnFocus
      i18n/          — Translations (es/en)
    services/
      api.js         — fetchAPI, getApiUrl
```
"""

# ── Work Rules ───────────────────────────────────────────────────────────────

WORK_RULES = """# Work Rules — Christian Hernandez

## Critical Rules (NEVER break these)
1. NEVER use PUT on Render env-vars API without including ALL existing vars
2. NEVER modify existing encapsulated components — add new ones alongside
3. ALWAYS verify destructive API calls before executing
4. ALWAYS update memory after mistakes and key decisions
5. Quality over speed — do it right, not fast
6. ALWAYS build locally and verify before pushing

## Development Flow
1. Read ALL affected files before changing anything
2. Plan the change mentally before writing code
3. Make the minimum change needed
4. Build locally to verify (vite build, pytest)
5. Commit with descriptive message
6. Push and verify deploy

## LLM Architecture
- deepseek-r1:8b → Chat interface (native thinking)
- qwen2.5-coder:7b → Code agents, JSON generation
- llama3.1:8b → Language agents, summaries, reports
- gemma3:4b → Fast classification, routing
- Groq → Cloud fallback (free, 24/7)
- Claude → Last resort (paid)

## Render/Vercel Deploy
- Service ID: srv-d75b2575r7bs73b22gp0
- DB: dpg-d75b1cpr0fns73blrtdg-a (nexusforge-db)
- Frontend: nexusforge-two.vercel.app (auto-deploy from master)
- Backend: nexusforge-api.onrender.com (auto-deploy from master)
- PUT /env-vars REPLACES ALL — always GET first, then PUT full list

## Agent Model Assignment
- Gemma3:4b → ClassifierAgent, RouterAgent, SentimentAgent, MonitorAgent
- Qwen2.5-coder:7b → ExtractorAgent, AnalyzerAgent, ValidatorAgent, OCRAgent, JudgeAgent
- Llama3.1:8b → SummarizerAgent, ReporterAgent, TranslatorAgent, ResearcherAgent
- Claude (cloud) → ComplianceAgent (regulatory, high-stakes)
- Groq (cloud) → PlannerAgent, CriticAgent (need large context)
"""

# ── Kiro Hooks ───────────────────────────────────────────────────────────────

KIRO_HOOKS = {
    "pre-commit-lint": {
        "description": "Run linting before commit",
        "trigger": "pre-commit",
        "command": "cd backend && python -m py_compile app/main.py",
    },
    "test-on-agent-change": {
        "description": "Run agent tests when agent files change",
        "trigger": "on-save",
        "pattern": "backend/app/agents/*.py",
        "command": "cd backend && pytest tests/test_agents.py -x -q",
    },
    "build-check-frontend": {
        "description": "Verify frontend builds on change",
        "trigger": "on-save",
        "pattern": "frontend/src/**/*.jsx",
        "command": "cd frontend && npx vite build --mode production",
    },
}

# ── Kiro Memory Templates ────────────────────────────────────────────────────

KIRO_MEMORY = {
    "product_context": STEERING_PRODUCT,
    "tech_context": STEERING_TECH,
    "architecture_context": STEERING_STRUCTURE,
    "known_risks": """# Known Risks
- Render PUT /env-vars replaces ALL variables (caused outage 2026-04-06)
- Ollama needs OLLAMA_ORIGINS=* and OLLAMA_HOST=0.0.0.0 for tunnel access
- deepseek-r1 thinking comes in message.thinking field, NOT <think> tags
- JSX files in React must use .jsx extension, not .js (Vite 8 strict)
- Frontend .env.local is NOT committed — env vars must be set in Vercel dashboard
- sessionStorage used for chat persistence (not localStorage to avoid cross-tab issues)
""",
    "recent_decisions": """# Recent Decisions
- Chat-first dashboard as default view (inspired by Hercules.app)
- Two chat roles: builder (deepseek-r1) and guide (always Groq)
- Preview panel shows step progress during automation creation
- System prompt instructs AI to be friendly, ONE question at a time, no JSON
- Publish confirmation triggers real workflow + automation creation via API
""",
    "active_workstream": """# Active Workstream
- Chat-first interface deployed and functional
- Thinking display shows compact real-time reasoning
- Chat history persists in sessionStorage
- Publish creates real automations via /wizard/generate + /workflows/ + /automations/
- Next: improve preview panel reactivity, add more quick actions
""",
}


def generate_kiro_specs(project_dir: str):
    """Generate Kiro steering, memory, and hooks for a NexusForge project."""
    kiro_dir = os.path.join(project_dir, ".kiro")
    steering_dir = os.path.join(kiro_dir, "steering")
    memory_dir = os.path.join(kiro_dir, "memory")
    hooks_dir = os.path.join(kiro_dir, "hooks")

    for d in [steering_dir, memory_dir, hooks_dir]:
        os.makedirs(d, exist_ok=True)

    # Steering files
    with open(os.path.join(steering_dir, "product.md"), "w", encoding="utf-8") as f:
        f.write(STEERING_PRODUCT)
    with open(os.path.join(steering_dir, "tech.md"), "w", encoding="utf-8") as f:
        f.write(STEERING_TECH)
    with open(os.path.join(steering_dir, "structure.md"), "w", encoding="utf-8") as f:
        f.write(STEERING_STRUCTURE)
    with open(os.path.join(steering_dir, "work-rules.md"), "w", encoding="utf-8") as f:
        f.write(WORK_RULES)

    # Memory files
    for name, content in KIRO_MEMORY.items():
        with open(os.path.join(memory_dir, f"{name}.md"), "w", encoding="utf-8") as f:
            f.write(content)

    # Hooks
    for name, hook in KIRO_HOOKS.items():
        with open(os.path.join(hooks_dir, f"{name}.json"), "w", encoding="utf-8") as f:
            json.dump(hook, f, indent=2)

    return kiro_dir
