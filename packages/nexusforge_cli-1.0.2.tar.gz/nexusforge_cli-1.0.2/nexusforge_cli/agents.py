"""Agent experience profiles — accumulated knowledge from NexusForge agents."""

AGENT_PROFILES = {
    "ClassifierAgent": {
        "model": "gemma3:4b",
        "role": "Classifies text into categories (ticket type, urgency, intent)",
        "strengths": ["Fast classification", "Multi-label support", "Urgency detection"],
        "best_for": ["Ticket triage", "Email routing", "Document categorization"],
        "experience": {
            "total_executions": 150,
            "success_rate": 0.97,
            "avg_latency_ms": 800,
            "learned_patterns": [
                "Urgency keywords: 'urgente', 'critico', 'inmediato' → high priority",
                "Invoice patterns: montos, fechas, RFC → type: factura",
                "Complaint patterns: 'queja', 'problema', 'no funciona' → type: complaint",
            ],
        },
    },
    "ExtractorAgent": {
        "model": "qwen2.5-coder:7b",
        "role": "Extracts structured data from unstructured text (entities, fields, values)",
        "strengths": ["JSON output", "Multi-field extraction", "Table parsing"],
        "best_for": ["Invoice processing", "Form extraction", "Data normalization"],
        "experience": {
            "total_executions": 120,
            "success_rate": 0.94,
            "avg_latency_ms": 1200,
            "learned_patterns": [
                "Invoice fields: monto, fecha, proveedor, RFC, numero_factura",
                "Email fields: from, subject, body_summary, intent, urgency",
                "Nested JSON extraction works better with explicit schema in prompt",
            ],
        },
    },
    "SummarizerAgent": {
        "model": "llama3.1:8b",
        "role": "Generates concise summaries of documents and conversations",
        "strengths": ["Natural language", "Multi-document", "Executive summaries"],
        "best_for": ["Report generation", "Email summaries", "Meeting notes"],
        "experience": {
            "total_executions": 100,
            "success_rate": 0.96,
            "avg_latency_ms": 1500,
            "learned_patterns": [
                "Executive summaries: 3-5 bullet points max",
                "Report summaries: include KPIs, trends, anomalies",
                "Multi-doc: synthesize common themes across documents",
            ],
        },
    },
    "AnalyzerAgent": {
        "model": "qwen2.5-coder:7b",
        "role": "Analyzes data for trends, anomalies, and patterns",
        "strengths": ["Trend detection", "Anomaly flagging", "Statistical analysis"],
        "best_for": ["Financial analysis", "Performance metrics", "Data quality"],
        "experience": {
            "total_executions": 80,
            "success_rate": 0.92,
            "avg_latency_ms": 1800,
            "learned_patterns": [
                "Financial: flag transactions > 2 std deviations from mean",
                "Trends: compare current period vs previous period",
                "Quality: check for nulls, duplicates, format inconsistencies",
            ],
        },
    },
    "SentimentAgent": {
        "model": "gemma3:4b",
        "role": "Analyzes emotional tone and urgency in text",
        "strengths": ["Fast sentiment", "Urgency scoring", "Tone detection"],
        "best_for": ["Customer feedback", "Ticket prioritization", "Social monitoring"],
        "experience": {
            "total_executions": 90,
            "success_rate": 0.95,
            "avg_latency_ms": 600,
            "learned_patterns": [
                "Urgency scale: critical (immediate), high (same day), medium (48h), low (week)",
                "Negative sentiment + high urgency = escalate immediately",
                "Sarcasm detection improves with context from previous messages",
            ],
        },
    },
    "ValidatorAgent": {
        "model": "qwen2.5-coder:7b",
        "role": "Validates data quality, consistency, and business rules",
        "strengths": ["Rule-based validation", "Duplicate detection", "Format checking"],
        "best_for": ["Invoice validation", "Data quality", "Compliance checks"],
        "experience": {
            "total_executions": 70,
            "success_rate": 0.98,
            "avg_latency_ms": 900,
            "learned_patterns": [
                "Duplicate detection: compare hash of key fields (monto+fecha+proveedor)",
                "Format validation: RFC pattern, email format, phone format",
                "Business rules: montos > threshold require approval flag",
            ],
        },
    },
    "ReporterAgent": {
        "model": "llama3.1:8b",
        "role": "Generates formatted reports from analyzed data",
        "strengths": ["Executive reports", "HTML/PDF formatting", "KPI dashboards"],
        "best_for": ["Weekly reports", "Financial summaries", "Status updates"],
        "experience": {
            "total_executions": 60,
            "success_rate": 0.93,
            "avg_latency_ms": 2000,
            "learned_patterns": [
                "Executive report structure: summary → KPIs → details → recommendations",
                "Include visual indicators: arrows for trends, colors for status",
                "Always include period comparison (vs previous week/month)",
            ],
        },
    },
    "ComplianceAgent": {
        "model": "claude",
        "role": "Checks regulatory rules and flags violations",
        "strengths": ["Regulatory knowledge", "Risk assessment", "Audit trail"],
        "best_for": ["Financial compliance", "Data privacy", "Policy enforcement"],
        "experience": {
            "total_executions": 40,
            "success_rate": 0.99,
            "avg_latency_ms": 3000,
            "learned_patterns": [
                "Transactions > $10,000 require human approval (anti-money laundering)",
                "PII detection: mask SSN, credit cards, addresses in outputs",
                "Compliance reports must include timestamp, auditor, and decision rationale",
            ],
        },
    },
    "OCRAgent": {
        "model": "qwen2.5-coder:7b",
        "role": "Extracts text from images and scanned documents",
        "strengths": ["PDF parsing", "Image text extraction", "Table recognition"],
        "best_for": ["Invoice scanning", "Document digitization", "Receipt processing"],
        "experience": {
            "total_executions": 50,
            "success_rate": 0.88,
            "avg_latency_ms": 2500,
            "learned_patterns": [
                "PDF text extraction > image OCR for quality",
                "Tables: extract as structured JSON, not plain text",
                "Low-quality scans: preprocess with contrast enhancement",
            ],
        },
    },
    "JudgeAgent": {
        "model": "qwen2.5-coder:7b",
        "role": "Evaluates and scores outputs from multiple agents using Weighted Borda Count",
        "strengths": ["Consensus evaluation", "Multi-criteria scoring", "Conflict resolution"],
        "best_for": ["Second opinions", "Quality assurance", "Multi-agent voting"],
        "experience": {
            "total_executions": 30,
            "success_rate": 0.95,
            "avg_latency_ms": 1000,
            "learned_patterns": [
                "Weighted Borda Count works best with 3+ agent outputs",
                "Criteria weights: accuracy (0.4), completeness (0.3), relevance (0.3)",
                "Tie-breaking: prefer the agent with higher historical success rate",
            ],
        },
    },
}

# Model routing map
AGENT_MODEL_MAP = {
    # Gemma3:4b — fast classification/routing
    "ClassifierAgent": "gemma3:4b",
    "RouterAgent": "gemma3:4b",
    "SentimentAgent": "gemma3:4b",
    "MonitorAgent": "gemma3:4b",
    # Qwen2.5-coder:7b — structured output/code
    "ExtractorAgent": "qwen2.5-coder:7b",
    "AnalyzerAgent": "qwen2.5-coder:7b",
    "ValidatorAgent": "qwen2.5-coder:7b",
    "NormalizerAgent": "qwen2.5-coder:7b",
    "OCRAgent": "qwen2.5-coder:7b",
    "JudgeAgent": "qwen2.5-coder:7b",
    "SchedulerAgent": "qwen2.5-coder:7b",
    "WebhookAgent": "qwen2.5-coder:7b",
    # Llama3.1:8b — natural language/synthesis
    "SummarizerAgent": "llama3.1:8b",
    "ReporterAgent": "llama3.1:8b",
    "TranslatorAgent": "llama3.1:8b",
    "EnricherAgent": "llama3.1:8b",
    "KnowledgeAgent": "llama3.1:8b",
    "ResearcherAgent": "llama3.1:8b",
    "ScraperAgent": "llama3.1:8b",
    # Cloud-only
    "ComplianceAgent": "claude",
    "PlannerAgent": "groq",
    "CriticAgent": "groq",
}

# Swarm topologies
TOPOLOGIES = {
    "sequential": "Pipeline ordered step by step — each agent depends on the previous",
    "parallel": "Multiple agents working simultaneously — for independent tasks",
    "hierarchical": "Supervisor coordinates sub-tasks — for complex orchestration",
    "debate": "Agents argue to improve results — for quality-critical analysis",
    "consensus": "Multiple agents vote on decisions — for high-stakes choices",
    "adaptive": "Selects topology automatically based on input complexity",
}

LLM_FALLBACK_CHAIN = [
    {"provider": "ollama", "model": "deepseek-r1:8b", "role": "Chat + thinking", "cost": "free"},
    {"provider": "groq", "model": "llama-3.3-70b-versatile", "role": "Cloud fallback", "cost": "free"},
    {"provider": "anthropic", "model": "claude-sonnet-4", "role": "Last resort", "cost": "paid"},
]
