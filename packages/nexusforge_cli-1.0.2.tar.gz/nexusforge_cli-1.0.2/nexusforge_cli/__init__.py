"""NexusForge CLI — Enterprise AI Agent Orchestration Setup."""
__version__ = "1.0.2"
