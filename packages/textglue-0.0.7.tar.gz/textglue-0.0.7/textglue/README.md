
# TextGlue

TextGlue is a simple static templating
system with two tags: "file" and "template".

The file tag copies the file verbatim into the source,
while the template tag recursively evaluates the
referenced file as a template itself.
