"""Assemble a ``matplotlib.rcParams`` dict from a :class:`~plotstyle.specs.schema.JournalSpec`.

:func:`build_rcparams` is the single public entry point.  :data:`SAFETY_PARAMS`
always sets ``fonttype=42`` (TrueType embedding) regardless of caller overrides.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Final, Literal

from plotstyle.engine.fonts import select_best
from plotstyle.engine.latex import configure_latex, detect_latex
from plotstyle.specs.units import Dimension

if TYPE_CHECKING:
    from plotstyle.overlays.schema import StyleOverlay
    from plotstyle.specs.schema import JournalSpec

__all__: list[str] = [
    "SAFETY_PARAMS",
    "LatexNotFoundError",
    "apply_overlays",
    "build_rcparams",
]

# ---------------------------------------------------------------------------
# Module-level constants
# ---------------------------------------------------------------------------

#: rcParam keys that enforce TrueType font embedding; must not be downgraded.
SAFETY_PARAMS: Final[frozenset[str]] = frozenset(
    {
        "pdf.fonttype",
        "ps.fonttype",
    }
)

_GOLDEN_RATIO: Final[float] = (1.0 + 5.0**0.5) / 2.0
_DISPLAY_DPI: Final[int] = 100
_FONTTYPE_TRUETYPE: Final[int] = 42

_LatexMode = Literal[True, False, "auto"]

# ---------------------------------------------------------------------------
# Custom exceptions
# ---------------------------------------------------------------------------


class LatexNotFoundError(RuntimeError):
    """Raised when LaTeX rendering is explicitly requested but unavailable."""

    _DEFAULT_MESSAGE: Final[str] = (
        "No 'latex' binary was found on PATH. "
        "Install TeX Live or MiKTeX, or pass latex='auto' to fall back silently."
    )

    def __init__(self, message: str = _DEFAULT_MESSAGE) -> None:
        super().__init__(message)


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _resolve_latex_mode(latex: _LatexMode) -> bool:
    """Determine whether to enable LaTeX given the requested mode.

    Parameters
    ----------
    latex : _LatexMode
        LaTeX mode from :func:`build_rcparams`: ``True`` forces LaTeX
        (raises if unavailable), ``False`` disables it unconditionally,
        and ``"auto"`` enables it only if a binary is found.

    Returns
    -------
    bool
        ``True`` if LaTeX should be enabled, ``False`` otherwise.

    Raises
    ------
    LatexNotFoundError
        When ``latex=True`` and no ``latex`` binary is on ``PATH``.
    """
    if latex is False:
        return False

    latex_available = detect_latex()

    if latex is True and not latex_available:
        raise LatexNotFoundError()

    return latex_available


def _compute_figure_size(spec: JournalSpec) -> tuple[float, float] | None:
    """Return ``(width_in, height_in)`` for the spec's single-column width.

    Returns ``None`` when the journal does not publish column widths, so
    ``build_rcparams`` can skip ``figure.figsize`` rather than crashing.
    """
    if spec.dimensions.single_column_mm is None:
        return None
    width_in = Dimension(spec.dimensions.single_column_mm, "mm").to_inches()
    height_in = width_in / _GOLDEN_RATIO
    return width_in, height_in


def _compute_base_font_size(spec: JournalSpec) -> float:
    """Return the midpoint of the spec's permitted font-size range."""
    return (spec.typography.min_font_pt + spec.typography.max_font_pt) / 2.0


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def build_rcparams(
    spec: JournalSpec,
    *,
    latex: _LatexMode = False,
    detect_fonts: bool = True,
) -> dict[str, Any]:
    """Build a complete ``matplotlib.rcParams`` mapping from a journal spec.

    Parameters
    ----------
    spec : JournalSpec
        Journal specification to translate into rcParams.
    latex : _LatexMode
        Controls LaTeX-based text rendering:

        - ``False`` *(default)*: use Matplotlib's MathText engine.
        - ``True``: require LaTeX; raises :class:`LatexNotFoundError` if
          no ``latex`` binary is found on ``PATH``.
        - ``"auto"``: enable LaTeX when available, fall back to MathText.
    detect_fonts : bool
        When ``True`` *(default)*, probe the system font cache via
        :func:`~plotstyle.engine.fonts.select_best` to pick the best
        available font family.  When ``False``, skip probing and use
        ``spec.typography.font_fallback`` directly, useful for snapshot
        builds at import time where the filesystem overhead is unacceptable.
        Ignored when *latex* resolves to ``True``; LaTeX font selection is
        driven by the TeX preamble, so ``font_fallback`` is always used.

    Returns
    -------
    dict[str, Any]
        Ready for ``matplotlib.rcParams.update``.  Always includes
        :data:`SAFETY_PARAMS` set to ``42`` (TrueType embedding).

    Raises
    ------
    ValueError
        If *latex* is not ``True``, ``False``, or ``"auto"``.
    LatexNotFoundError
        If ``latex=True`` but no ``latex`` binary is found on ``PATH``.
    """
    if latex not in (True, False, "auto"):
        raise ValueError(f"Invalid latex value {latex!r}. Expected True, False, or 'auto'.")

    # Resolve LaTeX mode before font detection: raises LatexNotFoundError immediately
    # when latex=True but unavailable, and lets us skip font probing when LaTeX is active
    # (LaTeX font selection is driven by the TeX preamble, not matplotlib's font.family).
    use_latex = _resolve_latex_mode(latex)

    if use_latex:
        font_name = spec.typography.font_fallback
    elif detect_fonts:
        font_name, _ = select_best(spec)
    else:
        font_name = spec.typography.font_fallback

    figsize = _compute_figure_size(spec)
    font_size = _compute_base_font_size(spec)

    params: dict[str, Any] = {
        "pdf.fonttype": _FONTTYPE_TRUETYPE,
        "ps.fonttype": _FONTTYPE_TRUETYPE,
        "figure.dpi": _DISPLAY_DPI,
        "savefig.dpi": spec.export.min_dpi,
        "figure.constrained_layout.use": True,
    }
    if figsize is not None:
        params["figure.figsize"] = list(figsize)
    params.update(
        {
            "font.family": font_name,
            "font.size": font_size,
            "axes.titlesize": font_size,
            "axes.labelsize": font_size,
            "xtick.labelsize": font_size,
            "ytick.labelsize": font_size,
            "legend.fontsize": font_size,
            # Clamped to physically reproducible minimums; thinner lines vanish in print.
            "lines.linewidth": max(spec.line.min_weight_pt, 1.0),
            "axes.linewidth": max(spec.line.min_weight_pt, 0.5),
            # "none" keeps text editable in SVG; "path" converts to outlines (more portable).
            "svg.fonttype": "none" if spec.export.editable_text else "path",
            "axes.grid": False,
        }
    )

    if use_latex:
        params.update(configure_latex(spec))
    else:
        params["text.usetex"] = False

    # Re-enforce after configure_latex (or any future extension) to guarantee
    # TrueType embedding is never downgraded by the merge above.
    for key in SAFETY_PARAMS:
        params[key] = _FONTTYPE_TRUETYPE

    return params


def apply_overlays(base: dict[str, Any], overlays: list[StyleOverlay]) -> dict[str, Any]:
    """Merge overlay rcParams on top of *base*; last overlay wins on conflict.

    Parameters
    ----------
    base : dict[str, Any]
        Base rcParams dict (e.g. from :func:`build_rcparams`).
    overlays : list[StyleOverlay]
        Ordered list of overlays to apply.  Earlier overlays are applied
        first; later entries win on key conflicts.

    Returns
    -------
    dict[str, Any]
        New dict containing *base* with all overlay patches merged in.

    Notes
    -----
    Overlay TOML files may include a special ``_palette`` key (a list of hex
    colour strings) under ``[rcparams]``.  This is converted to a
    ``cycler('color', ...)`` object and stored under ``axes.prop_cycle``
    before merging.  This convention exists because TOML has no native type
    for matplotlib's ``cycler`` objects.

    Keys in :data:`SAFETY_PARAMS` (``pdf.fonttype``, ``ps.fonttype``) are
    silently stripped from every overlay before merging; overlays cannot
    downgrade TrueType font embedding.
    """
    from cycler import cycler

    result = {k: list(v) if isinstance(v, list) else v for k, v in base.items()}
    for overlay in overlays:
        rcparams = dict(overlay.rcparams)
        if "_palette" in rcparams:
            colors = rcparams.pop("_palette")
            rcparams["axes.prop_cycle"] = cycler("color", colors)
        # Overlays must never downgrade font-embedding safety keys.
        for key in SAFETY_PARAMS:
            rcparams.pop(key, None)
        result.update({k: list(v) if isinstance(v, list) else v for k, v in rcparams.items()})
    return result
