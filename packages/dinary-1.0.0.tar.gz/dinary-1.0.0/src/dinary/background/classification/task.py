"""Background task: drain receipt_classification_jobs queue.

See "Classification Layer" in specs/architecture/architecture.md.
"""

import asyncio
import contextlib
import logging
import sqlite3
from datetime import UTC, datetime

import httpx

from dinary.adapters.llmbroker import LLMBroker
from dinary.adapters.serbian_receipt_parser import (
    ParsedReceipt,
    ParserParseError,
    ParserRequestError,
    parse_receipt,
)
from dinary.background.classification.item_normalizer import normalize_item_name
from dinary.background.classification.persist import (
    RateMissingError,
    persist_classification_results,
    write_fetch_fallback_metadata,
)
from dinary.background.classification.receipt_classifier import (
    ClassificationResult,
    classify_receipt,
    load_categories,
    load_tags,
)
from dinary.background.classification.store_resolver import resolve_store
from dinary.config import settings
from dinary.db import storage
from dinary.db.classification_rules import RuleHit, classify_by_rules
from dinary.db.receipts import (
    ReceiptItemRow,
    ReceiptJobRow,
    claim_next_job,
    complete_job,
    get_receipt_items,
    poison_job,
    release_job,
    save_parsed_receipt,
)

logger = logging.getLogger(__name__)

_wakeup_event: asyncio.Event | None = None
_wakeup_loop: asyncio.AbstractEventLoop | None = None


def _register_wake_channel(
    event: asyncio.Event,
    loop: asyncio.AbstractEventLoop,
) -> None:
    global _wakeup_event, _wakeup_loop  # noqa: PLW0603
    _wakeup_event = event
    _wakeup_loop = loop


def _clear_wake_channel() -> None:
    global _wakeup_event, _wakeup_loop  # noqa: PLW0603
    _wakeup_event = None
    _wakeup_loop = None


def notify_new_receipt() -> None:
    """Signal the drain loop that a new receipt is ready.

    Thread-safe: safe to call from the event loop thread, from an
    asyncio.to_thread worker, or from a regular sync context.
    """
    ev = _wakeup_event
    loop = _wakeup_loop
    if ev is None or loop is None or loop.is_closed():
        return
    try:
        loop.call_soon_threadsafe(ev.set)
    except RuntimeError:
        return


async def receipt_classification_task(broker: LLMBroker) -> None:
    event = asyncio.Event()
    loop = asyncio.get_running_loop()
    _register_wake_channel(event, loop)
    try:
        if not settings.receipt_classification_enabled:
            return
        logger.info("Receipt classification drain started")

        await _drain_all_pending(broker)  # pick up jobs surviving a restart

        while True:
            with contextlib.suppress(TimeoutError):
                await asyncio.wait_for(event.wait(), timeout=300)
            event.clear()  # clear BEFORE drain so receipts arriving during drain re-set it
            await _drain_all_pending(broker)
    finally:
        _clear_wake_channel()


def _claim_all_pending() -> list[ReceiptJobRow]:
    with storage.connection() as conn:
        jobs: list[ReceiptJobRow] = []
        while True:
            job = claim_next_job(conn)
            if job is None:
                break
            jobs.append(job)
        return jobs


async def _drain_all_pending(broker: LLMBroker) -> None:
    jobs = await asyncio.to_thread(_claim_all_pending)
    if jobs:
        await asyncio.gather(
            *[_process_job(job, broker) for job in jobs],
            return_exceptions=True,
        )


async def _process_job(job: ReceiptJobRow, broker: LLMBroker) -> None:
    logger.info("Receipt drain: processing receipt_id=%s", job.receipt_id)
    try:
        if job.parsed_at is None:
            parsed = await parse_receipt(job.url)
            await asyncio.to_thread(_save_parsed, job.receipt_id, parsed)
            job = _with_parsed_data(job, parsed)

        store_info = await _ensure_store(job, broker)
        store_id = store_info[0] if store_info else None
        chain_id = store_info[1] if store_info else None

        items, should_skip = await asyncio.to_thread(_check_and_complete_if_done, job.receipt_id)
        if should_skip:
            return

        await _classify_and_persist(broker, job, items, store_id, chain_id)
        logger.info("Receipt drain: completed receipt_id=%s", job.receipt_id)

    except (ParserRequestError, OSError, RateMissingError) as exc:
        logger.warning(
            "Transient error for receipt_id=%s (%s) — releasing for retry",
            job.receipt_id,
            exc,
        )
        await asyncio.to_thread(_release, job.receipt_id, job.claim_token)
    except ParserParseError as exc:
        logger.error(
            "Permanent parse error for receipt_id=%s — poisoning: %s",
            job.receipt_id,
            exc,
        )
        await asyncio.to_thread(_poison, job.receipt_id, str(exc))
    except Exception as exc:
        logger.exception("Permanent error for receipt_id=%s — poisoning", job.receipt_id)
        await asyncio.to_thread(_poison, job.receipt_id, str(exc))


def _release(receipt_id: int, claim_token: str) -> None:
    with storage.connection() as conn:
        release_job(conn, receipt_id, claim_token)


def _poison(receipt_id: int, error: str) -> None:
    with storage.connection() as conn:
        poison_job(conn, receipt_id, error)


def _save_parsed(receipt_id: int, parsed: ParsedReceipt) -> None:
    with storage.connection() as conn:
        save_parsed_receipt(conn, receipt_id, parsed)
        if parsed.used_journal_fallback:
            write_fetch_fallback_metadata(conn, parsed.invoice_number, "journal fallback used")
        else:
            conn.execute(
                "DELETE FROM app_metadata WHERE key = 'receipt_fetch_fallback_last'",
            )

    if not parsed.total_ok:
        logger.warning(
            "receipt_id=%s total mismatch: items=%.2f receipt=%.2f",
            receipt_id,
            parsed.items_total,
            parsed.total_amount,
        )


def _with_parsed_data(job: ReceiptJobRow, parsed: ParsedReceipt) -> ReceiptJobRow:
    return ReceiptJobRow(
        receipt_id=job.receipt_id,
        url=job.url,
        store_name_raw=parsed.store_name,
        store_pib_raw=parsed.store_pib,
        invoice_number=parsed.invoice_number,
        parsed_at=datetime.now(UTC).isoformat(),
        used_journal_fallback=parsed.used_journal_fallback,
        claim_token=job.claim_token,
    )


def _check_store_already_resolved(receipt_id: int) -> tuple[int, int] | None:
    with storage.connection() as conn:
        existing = conn.execute(
            "SELECT store_id FROM receipts WHERE id = ?",
            [receipt_id],
        ).fetchone()
        if not (existing and existing[0]):
            return None
        store_id = int(existing[0])
        chain_row = conn.execute(
            "SELECT chain_id FROM stores WHERE id = ?",
            [store_id],
        ).fetchone()
        return store_id, int(chain_row[0])


def _save_store_to_receipt(receipt_id: int, store_id: int) -> None:
    with storage.connection() as conn:
        conn.execute(
            "UPDATE receipts SET store_id = ? WHERE id = ?",
            [store_id, receipt_id],
        )


async def _ensure_store(job: ReceiptJobRow, broker: LLMBroker) -> tuple[int, int] | None:
    if not job.store_name_raw and not job.store_pib_raw:
        return None

    result = await asyncio.to_thread(_check_store_already_resolved, job.receipt_id)
    if result is not None:
        return result

    try:
        store_id, chain_id = await resolve_store(broker, job.store_pib_raw, job.store_name_raw)
        await asyncio.to_thread(_save_store_to_receipt, job.receipt_id, store_id)
        return store_id, chain_id
    except (httpx.HTTPError, OSError):
        logger.warning(
            "Store resolution failed for receipt_id=%s",
            job.receipt_id,
            exc_info=True,
        )
        return None


def _run_rules_pass(
    conn: sqlite3.Connection,
    items: list[ReceiptItemRow],
    chain_id: int | None,
) -> tuple[dict[int, RuleHit], list[tuple[int, str]], dict[int, str]]:
    """Classify items by rules; return (rule_hits, llm_queue, norms) for remaining items."""
    rule_hits: dict[int, RuleHit] = {}
    llm_queue: list[tuple[int, str]] = []
    norms: dict[int, str] = {}
    for item in items:
        norm = normalize_item_name(item.name_raw)
        norms[item.id] = norm
        rule = classify_by_rules(conn, chain_id, norm)
        if rule and rule.confidence_level > 1:
            rule_hits[item.id] = rule
        else:
            llm_queue.append((item.id, norm))
    return rule_hits, llm_queue, norms


async def _run_llm_pass(
    broker: LLMBroker,
    job: ReceiptJobRow,
    llm_queue: list[tuple[int, str]],
    categories: dict[int, str],
    tags: dict[int, str],
) -> tuple[dict[int, ClassificationResult], bool]:
    """Call LLM for queued items; return (results keyed by item_id, used_fallback)."""
    if not llm_queue:
        return {}, False
    normalized_names = [name for _, name in llm_queue]
    results, used_fallback = await classify_receipt(
        broker,
        normalized_names,
        job.store_name_raw or "Unknown Store",
        categories,
        tags,
        context_id=job.receipt_id,
    )
    if len(results) != len(llm_queue):
        logger.warning(
            "LLM returned %d results for %d queued items for receipt_id=%s"
            " — trailing items will be unclassified",
            len(results),
            len(llm_queue),
            job.receipt_id,
        )
    return (
        {item_id: result for (item_id, _), result in zip(llm_queue, results, strict=False)},
        used_fallback,
    )


def _compute_classifications(
    items: list[ReceiptItemRow],
    rule_hits: dict[int, RuleHit],
    llm_results: dict[int, ClassificationResult],
    total_penalty: int,
) -> dict[int, tuple[int | None, int]]:
    """Merge rule and LLM results into {item_id: (category_id, confidence)}."""
    result: dict[int, tuple[int | None, int]] = {}
    for item in items:
        if item.id in rule_hits:
            hit = rule_hits[item.id]
            result[item.id] = (hit.category_id, hit.confidence_level)
        else:
            llm = llm_results.get(item.id)
            if llm is None:
                result[item.id] = (None, 1)
            else:
                conf = max(1, llm.confidence_level - total_penalty)
                result[item.id] = (llm.category_id, conf)
    return result


def _check_and_complete_if_done(receipt_id: int) -> tuple[list[ReceiptItemRow], bool]:
    with storage.connection() as conn:
        items = get_receipt_items(conn, receipt_id)
        if not items:
            logger.warning(
                "Receipt drain: no items for receipt_id=%s — completing job",
                receipt_id,
            )
            complete_job(conn, receipt_id)
            return [], True
        return items, False


async def _classify_and_persist(
    broker: LLMBroker,
    job: ReceiptJobRow,
    items: list[ReceiptItemRow],
    store_id: int | None,
    chain_id: int | None,
) -> None:
    with storage.connection() as conn:
        rule_hits, llm_queue, norms = _run_rules_pass(conn, items, chain_id)
        categories = load_categories(conn)
        tags = load_tags(conn)

    llm_results, used_failover = await _run_llm_pass(broker, job, llm_queue, categories, tags)
    total_penalty = (1 if job.used_journal_fallback else 0) + (1 if used_failover else 0)
    classifications = _compute_classifications(items, rule_hits, llm_results, total_penalty)

    await asyncio.to_thread(
        persist_classification_results,
        job,
        items,
        classifications,
        rule_hits,
        llm_results,
        store_id,
        chain_id,
        norms,
    )
