"""
BSL parser using tree-sitter.

Primary: tree-sitter-bsl (dedicated BSL grammar package).
Fallback: regex-based extraction if tree-sitter-bsl is not available.

Language notes (1C:Enterprise / BSL)
-----------------------------------
The BSL type system is **not** Java-style static typing: many checks are runtime.
Identifiers and keywords are **case-insensitive** at the language level; rules that
enforce «canonical» spelling of keywords (e.g. ``Процедура`` vs ``процедура``) are
**style** diagnostics, not a claim that the platform distinguishes case at runtime.

**BSL001 / ParseError** comes from the tree-sitter **concrete syntax tree** (ERROR
and MISSING nodes). It does not encode type information. Some constructs valid in
BSL still produce spurious ERROR tokens in the current grammar (parentheses in
multi-line assignments, ``Новый("…")``, parenthesised ``Если`` conditions); see
:meth:`BslParser._collect_errors` suppressions.
"""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

# Try to load tree-sitter with BSL grammar
_TS_AVAILABLE = False
_BSL_LANGUAGE = None

try:
    import tree_sitter_bsl as _ts_bsl
    from tree_sitter import Language
    from tree_sitter import Parser as _TsParser

    _BSL_LANGUAGE = Language(_ts_bsl.language())
    _TS_AVAILABLE = True
    logger.debug("tree-sitter BSL grammar loaded successfully")
except Exception as exc:  # pragma: no cover
    logger.warning("tree-sitter BSL grammar not available (%s). Using regex fallback.", exc)


@dataclass
class BslNode:
    """Lightweight representation of a tree-sitter node (or regex-parsed equivalent)."""

    type: str
    text: str
    start_point: tuple[int, int]  # (row, col) — 0-based
    end_point: tuple[int, int]
    children: list[BslNode] = field(default_factory=list)
    is_error: bool = False

    @property
    def start_line(self) -> int:
        """1-based line number."""
        return self.start_point[0] + 1

    @property
    def start_col(self) -> int:
        """0-based column."""
        return self.start_point[1]


class BslParser:
    """
    Parses BSL source files using tree-sitter (or regex fallback).

    Example::

        parser = BslParser()
        tree = parser.parse_file("/path/to/module.bsl")
        errors = parser.extract_errors(tree)
    """

    def __init__(self) -> None:
        self._ts_parser: Any = None
        if _TS_AVAILABLE:
            self._ts_parser = _TsParser(_BSL_LANGUAGE)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def parse_file(self, path: str | Path) -> Any:
        """
        Parse a .bsl file and return a Tree object.

        Returns a tree-sitter Tree when tree-sitter is available,
        or a _RegexTree stub when running in fallback mode.
        """
        content = Path(path).read_text(encoding="utf-8-sig", errors="replace")
        return self.parse_content(content, file_path=str(path))

    def parse_content(self, content: str, file_path: str = "<string>") -> Any:
        """
        Parse BSL source code from a string.

        Args:
            content: BSL source code.
            file_path: Used for error messages only.

        Returns:
            tree-sitter Tree or _RegexTree fallback.
        """
        if _TS_AVAILABLE and self._ts_parser is not None:
            try:
                tree = self._ts_parser.parse(content.encode("utf-8"))
                return tree
            except Exception as exc:  # pragma: no cover
                logger.warning(
                    "tree-sitter parse error for %s: %s. Using fallback.", file_path, exc
                )

        return _RegexTree(content, file_path=file_path)

    def extract_errors(self, tree: Any) -> list[dict]:
        """
        Extract syntax error nodes from a parsed tree.

        Returns a list of dicts with keys:
            - line (1-based)
            - column (0-based)
            - end_line (1-based)
            - end_column (0-based)
            - message
        """
        if isinstance(tree, _RegexTree):
            return tree.errors

        errors: list[dict] = []
        self._collect_errors(tree.root_node, errors)
        return errors

    def get_root_node(self, tree: Any) -> Any:
        """Return the root node of the tree (tree-sitter Node or _RegexNode)."""
        if isinstance(tree, _RegexTree):
            return tree.root_node
        return tree.root_node

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    # tree-sitter-bsl grammar bug: КонецЦикла; is rejected only inside
    # while_statement. BSL spec (1C docs) shows КонецЦикла; WITH semicolon.
    # Для/ДляКаждого loops already accept the trailing semicolon correctly.
    _WHILE_LOOP_NODE_TYPES = frozenset({"while_statement"})

    # tree-sitter-bsl grammar bug: parenthesised Если conditions are valid BSL:
    #   Если (А = Б) Тогда     — lone '(' and ')' ERROR nodes, parent = if_statement
    # The grammar only accepts bare expressions, not a leading '(' group.
    _IF_NODE_TYPES = frozenset({"if_statement", "elsif_clause"})
    # Multi-line parenthesised RHS is valid BSL, e.g. ``А = (Б И В`` + newline + ``)``;
    # lone '(' / ')' may appear as ERROR under assignment_statement (not only if_statement),
    # and also inside procedure/function call arguments, for-loop ranges, return values, etc.
    _ASSIGNMENT_SUPPRESS_PARENT = frozenset(
        {
            "assignment_statement",
            "call_statement",
            "return_statement",
            "for_statement",
            "foreach_statement",
            "arguments",
            "expression",
            "const_expression",
            "property_access",
        }
    )

    def _collect_errors(self, node: Any, errors: list[dict]) -> None:
        """Recursively collect ERROR and MISSING nodes from a tree-sitter tree."""
        if node.type in ("ERROR", "error") or node.is_missing:
            text = node.text if isinstance(node.text, bytes) else b""
            text_stripped = text.strip()
            # Suppress empty MISSING nodes — grammar artifact for optional constructs.
            # e.g. ВызватьИсключение; (bare rethrow): rise_error_statement produces
            # a MISSING identifier node with empty text when expression is omitted.
            if node.is_missing and text_stripped == b"":
                return
            # Suppress lone ';' that follows a while_statement — grammar bug.
            # КонецПроцедуры/КонецФункции have no trailing semicolon in BSL,
            # so those remain valid errors and must NOT be suppressed.
            # Also handle ';' after else_clause/elseif_clause that ends with while_statement.
            if text_stripped == b";" and self._prev_sibling_ends_with_while(node):
                for child in node.children:
                    self._collect_errors(child, errors)
                return
            # Suppress lone '(' and ')' ERROR nodes (including '((', '))' etc.) where
            # the grammar is incomplete but the source is valid BSL (see module docstring).
            if (
                text_stripped
                and (
                    all(c == ord("(") for c in text_stripped)
                    or all(c == ord(")") for c in text_stripped)
                )
                and self._should_suppress_lone_paren_error(node)
            ):
                for child in node.children:
                    self._collect_errors(child, errors)
                return
            # Suppress ERROR nodes inside member-access (access) nodes where the
            # first child is a BSL keyword used as a property name — valid 1C pattern
            # (e.g. Результат.Функция, Объект.Процедура) but rejected by the grammar.
            if node.type in ("ERROR", "error") and self._is_keyword_as_property_error(node):
                for child in node.children:
                    self._collect_errors(child, errors)
                return
            if node.type in ("ERROR", "error") and self._is_cascade_after_keyword_property_error(
                node
            ):
                for child in node.children:
                    self._collect_errors(child, errors)
                return
            if node.type in ("ERROR", "error") and self._is_keyword_property_call_wrapper_error(
                node
            ):
                for child in node.children:
                    self._collect_errors(child, errors)
                return
            if node.type in ("ERROR", "error") and self._is_identifier_with_yo_error(node):
                for child in node.children:
                    self._collect_errors(child, errors)
                return
            errors.append(
                {
                    "line": node.start_point[0] + 1,
                    "column": node.start_point[1],
                    "end_line": node.end_point[0] + 1,
                    "end_column": node.end_point[1],
                    "message": f"Syntax error near '{text.decode('utf-8', errors='replace')[:40]}'",
                }
            )
        for child in node.children:
            self._collect_errors(child, errors)

    @staticmethod
    def _is_identifier_with_yo_error(node: Any) -> bool:
        """tree-sitter-bsl currently splits valid identifiers containing ``ё``."""
        text = node.text if isinstance(node.text, bytes) else b""
        value = text.decode("utf-8", errors="replace").strip()
        if not value or "ё" not in value.casefold():
            return False
        first = value.split(None, 1)[0].rstrip(";,.")
        return bool(first and "ё" in first.casefold() and first.replace("_", "").isalnum())

    @staticmethod
    def _prev_sibling_type(node: Any) -> str:
        """Return the node type of the previous sibling in the parent, or ''."""
        parent = getattr(node, "parent", None)
        if parent is None:
            return ""
        children = list(parent.children)
        idx = next((i for i, c in enumerate(children) if c.id == node.id), -1)
        return children[idx - 1].type if idx > 0 else ""

    def _prev_sibling_ends_with_while(self, node: Any) -> bool:
        """Return True when the ';' ERROR should be suppressed as a КонецЦикла; artifact.

        Handles two cases:
        1. Previous sibling IS a while_statement (simple case).
        2. Previous sibling is a clause node (else_clause, elseif_clause, etc.)
           whose last statement is a while_statement.
        """
        parent = getattr(node, "parent", None)
        if parent is None:
            return False
        children = list(parent.children)
        idx = next((i for i, c in enumerate(children) if c.id == node.id), -1)
        if idx <= 0:
            return False
        prev = children[idx - 1]
        if prev.type in self._WHILE_LOOP_NODE_TYPES:
            return True
        # Check if prev is a clause that ends with a while_statement
        prev_children = [c for c in prev.children if c.type not in (";",)]
        if prev_children and prev_children[-1].type in self._WHILE_LOOP_NODE_TYPES:
            return True
        return False

    def _ancestor_is_if(self, node: Any) -> bool:
        """Return True if any ancestor node is an if_statement or elsif_clause."""
        current = getattr(node, "parent", None)
        while current is not None:
            if current.type in self._IF_NODE_TYPES:
                return True
            # Stop searching beyond procedure/function boundaries
            if current.type in ("procedure_definition", "function_definition", "module"):
                return False
            current = getattr(current, "parent", None)
        return False

    def _ancestor_has_type(self, node: Any, types: frozenset[str]) -> bool:
        """True if any ancestor (walking parents) has a type in ``types``."""
        current = getattr(node, "parent", None)
        while current is not None:
            if current.type in types:
                return True
            if current.type == "module":
                return False
            current = getattr(current, "parent", None)
        return False

    def _should_suppress_lone_paren_error(self, node: Any) -> bool:
        """Valid BSL often yields spurious '(' / ')' ERROR nodes; see _collect_errors."""
        if self._ancestor_is_if(node):
            return True
        return self._ancestor_has_type(node, self._ASSIGNMENT_SUPPRESS_PARENT)

    @staticmethod
    def _is_keyword_as_property_error(node: Any) -> bool:
        """Return True when an ERROR node represents a keyword used as a member-access
        property name — a valid 1C pattern the grammar rejects.

        Two structural signatures (tree-sitter-bsl):

        Case A — ERROR nested inside access / property_access:
          access | property_access
            ...
            .
            ERROR          ← node
              *_KEYWORD    ← first child ends with '_KEYWORD'
              ...

        Case B — ERROR node that contains a '.' immediately followed by a *_KEYWORD
        as direct children (grammar absorbed the member-access into a larger ERROR):
          ERROR              ← node
            ...
            access | identifier
            .                ← child[i]
            *_KEYWORD        ← child[i+1]
            ...

        Case C — ERROR node ending with '.' (dangling dot): the property name is a BSL
        keyword/constant that the grammar parsed separately as an expression:
          binary_expression
            ...
            ERROR            ← node
              access: МестоположенияМодуля
              .               ← last child
            expression: Неопределено   ← parsed outside the ERROR
        """
        children = list(node.children)
        if not children:
            return False

        # Case A: parent is a member-access node and first child is a keyword
        parent = getattr(node, "parent", None)
        if parent is not None and parent.type in ("access", "property_access"):
            return children[0].type.endswith("_KEYWORD")

        # Case B: '.' followed immediately by *_KEYWORD among direct children
        for i in range(len(children) - 1):
            if children[i].type == "." and children[i + 1].type.endswith("_KEYWORD"):
                return True

        # Case C: dangling dot — ERROR ends with '.' because the property name is a
        # BSL constant/keyword parsed by the grammar as a separate expression node.
        if children[-1].type == ".":
            return True

        return False

    @classmethod
    def _is_cascade_after_keyword_property_error(cls, node: Any) -> bool:
        """Suppress grammar cascades after valid member calls named like BSL keywords.

        Example: ``Поток.Перейти(Аргумент, Перечисление.Значение);`` may parse
        ``Перейти`` as ``GOTO_KEYWORD`` and then emit extra ERROR nodes for the
        remaining arguments/closing tokens. The original keyword-as-property
        ERROR is already suppressed; this catches the directly related cascade.
        """
        parent = getattr(node, "parent", None)
        if parent is None or parent.type not in (
            "assignment_statement",
            "call_statement",
            "property_access",
        ):
            return False
        text = node.text if isinstance(node.text, bytes) else b""
        stripped = text.strip()
        if not (stripped.startswith(b",") or stripped.startswith(b")")):
            return False
        for sibling in parent.children:
            if sibling.id == node.id:
                break
            if cls._node_contains_keyword_property_error(sibling):
                return True
        return False

    @classmethod
    def _is_keyword_property_call_wrapper_error(cls, node: Any) -> bool:
        text = node.text if isinstance(node.text, bytes) else b""
        if not text.strip().endswith(b";"):
            return False
        return cls._node_contains_keyword_property_error(node)

    @classmethod
    def _node_contains_keyword_property_error(cls, node: Any) -> bool:
        if getattr(node, "type", None) in ("ERROR", "error") and cls._is_keyword_as_property_error(
            node
        ):
            return True
        return any(cls._node_contains_keyword_property_error(child) for child in node.children)


# ---------------------------------------------------------------------------
# Regex-based fallback tree
# ---------------------------------------------------------------------------

# Patterns for BSL constructs
_RE_PROCEDURE = re.compile(
    r"^(?P<indent>\s*)(?P<kw>Процедура|Procedure|Функция|Function)\s+"
    r"(?P<name>\w+)\s*\((?P<params>[^)]*)\)\s*(?P<export>Экспорт|Export)?",
    re.IGNORECASE | re.MULTILINE,
)
_RE_END_PROCEDURE = re.compile(
    r"^\s*(?:КонецПроцедуры|EndProcedure|КонецФункции|EndFunction)\s*$",
    re.IGNORECASE | re.MULTILINE,
)
_RE_CALL = re.compile(
    r"\b(?P<name>\w+)\s*\(",
    re.IGNORECASE,
)
_RE_VAR = re.compile(
    r"^\s*(?:Перем|Var)\s+(?P<name>\w+)",
    re.IGNORECASE | re.MULTILINE,
)
_RE_REGION = re.compile(
    r"^\s*#(?:Область|Region)\s+(?P<name>.+)$",
    re.IGNORECASE | re.MULTILINE,
)


class _RegexNode:
    """Minimal node returned by the regex fallback tree."""

    def __init__(
        self,
        type: str,
        text: str,
        start_point: tuple[int, int],
        end_point: tuple[int, int],
        children: list[_RegexNode] | None = None,
    ) -> None:
        self.type = type
        self.text = text
        self.start_point = start_point
        self.end_point = end_point
        self.children: list[_RegexNode] = children or []
        self.is_missing = False


class _RegexTree:
    """
    Regex-based pseudo-tree used when tree-sitter is not available.

    This provides just enough structure for the analysis layer to
    extract symbols, calls, and basic diagnostics without full parsing.
    """

    def __init__(self, content: str, file_path: str = "<string>") -> None:
        self.content = content
        self.file_path = file_path
        self.errors: list[dict] = []
        self.root_node = self._build(content)

    def _build(self, content: str) -> _RegexNode:
        lines = content.splitlines()
        children: list[_RegexNode] = []

        for m in _RE_PROCEDURE.finditer(content):
            line_no = content[: m.start()].count("\n")
            node = _RegexNode(
                type="procedure_definition",
                text=m.group(0),
                start_point=(line_no, m.start(0) - content.rfind("\n", 0, m.start(0)) - 1),
                end_point=(line_no, m.end(0)),
                children=[
                    _RegexNode(
                        "identifier",
                        m.group("name"),
                        (line_no, 0),
                        (line_no, len(m.group("name"))),
                    )
                ],
            )
            children.append(node)

        for m in _RE_CALL.finditer(content):
            line_no = content[: m.start()].count("\n")
            children.append(
                _RegexNode(
                    "call_expression",
                    m.group(0),
                    (line_no, 0),
                    (line_no, len(m.group(0))),
                )
            )

        for m in _RE_VAR.finditer(content):
            line_no = content[: m.start()].count("\n")
            children.append(
                _RegexNode(
                    "var_statement",
                    m.group(0),
                    (line_no, 0),
                    (line_no, len(m.group(0))),
                )
            )

        for m in _RE_REGION.finditer(content):
            line_no = content[: m.start()].count("\n")
            children.append(
                _RegexNode(
                    "preprocessor_region",
                    m.group(0),
                    (line_no, 0),
                    (line_no, len(m.group(0))),
                )
            )

        total_lines = len(lines)
        return _RegexNode(
            type="module",
            text=content[:80],
            start_point=(0, 0),
            end_point=(total_lines, 0),
            children=children,
        )
