"""
Incremental BSL workspace indexer.

Uses ``git diff`` to detect changed files since the last indexed commit,
so only modified .bsl/.os files are re-parsed on each run.
"""

from __future__ import annotations

import hashlib
import logging
import os
import subprocess
import threading
from collections.abc import Callable
from contextlib import nullcontext
from pathlib import Path
from queue import Empty, Queue
from typing import Any

from rich.progress import BarColumn, MofNCompleteColumn, Progress, TextColumn, TimeElapsedColumn

from onec_hbk_bsl.analysis.semantic import extract_semantic_model
from onec_hbk_bsl.indexer.metadata_parser import (
    crawl_config,
    find_config_root,
    find_edt_configuration_marker,
)
from onec_hbk_bsl.indexer.metadata_registry import FOLDER_TO_KIND
from onec_hbk_bsl.indexer.symbol_index import SymbolIndex
from onec_hbk_bsl.parser.bsl_parser import BslParser

logger = logging.getLogger(__name__)

BSL_EXTENSIONS = {".bsl", ".os"}
_DEFAULT_EXCLUDED_DIRS = {
    ".agent",
    ".agents",
    ".cache",
    ".codex",
    ".cursor",
    ".git",
    ".hg",
    ".mypy_cache",
    ".pytest_cache",
    ".ruff_cache",
    ".svn",
    ".venv",
    "__pycache__",
    "build",
    "dist",
    "node_modules",
    "out",
    "target",
    "vendor",
}

# Upper bound for BSL_INDEX_PARSE_WORKERS — each worker holds a Tree-sitter parser
# and parsed AST payloads; unbounded queues previously allowed RAM to grow to 100+ GB
# on 30k+ file workspaces when parsing outran SQLite.
_MAX_PARSE_WORKERS = 32


def _parse_workers_from_env() -> int:
    raw = os.environ.get("BSL_INDEX_PARSE_WORKERS", "").strip()
    if raw:
        try:
            return max(1, min(int(raw), _MAX_PARSE_WORKERS))
        except ValueError:
            logger.warning("Invalid BSL_INDEX_PARSE_WORKERS=%r — using default", raw)
    cpu = os.cpu_count() or 4
    return max(1, min(4, cpu))


class IncrementalIndexer:
    """
    Indexes a BSL workspace into a :class:`SymbolIndex`.

    Args:
        db_path:    Path to the SQLite index database. ``None`` uses the same
            default as :class:`SymbolIndex`.
        index:      Existing SymbolIndex instance (overrides db_path).
        on_progress: Optional callback ``fn(current, total, file_path)`` for progress.
        quiet:      Suppress Rich progress bar output (set True when running inside
            the LSP server's background thread — stdout is the JSON-RPC pipe).
    """

    def __init__(
        self,
        db_path: str | None = None,
        index: SymbolIndex | None = None,
        on_progress: Callable[[int, int, str], None] | None = None,
        quiet: bool | None = None,
    ) -> None:
        self.index = index or SymbolIndex(db_path=db_path)
        # tree_sitter.Parser is not thread-safe — one BslParser per thread (see _get_parser).
        self._parser_tls = threading.local()
        self._on_progress = on_progress
        # Suppress Rich progress when quiet=True or when BSL_LSP_MODE env is set
        # (LSP stdio mode — stdout is the JSON-RPC pipe, any non-JSON output corrupts it).
        if quiet is None:
            quiet = os.environ.get("BSL_LSP_MODE", "") not in ("", "0", "false")
        self._quiet = quiet
        # Parsing can be parallelized; SQLite writes stay serialized in SymbolIndex.
        self._parse_workers = _parse_workers_from_env()
        # Single-flight guard for background metadata indexing.
        self._metadata_lock = threading.Lock()
        self._metadata_running = False
        self._metadata_pending = False
        self._metadata_pending_workspace: str | None = None

    def _get_parser(self) -> BslParser:
        """Return a thread-local :class:`BslParser` (required for parallel indexing)."""
        p: BslParser | None = getattr(self._parser_tls, "parser", None)
        if p is None:
            p = BslParser()
            self._parser_tls.parser = p
        return p

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def index_workspace(self, workspace: str, force: bool = False) -> dict:
        """
        Index (or incrementally update) a BSL workspace.

        Args:
            workspace: Absolute path to the workspace root.
            force:     If True, always perform a full reindex.

        Returns:
            Dict with ``indexed``, ``skipped``, ``errors`` counts.
        """
        workspace = str(Path(workspace).resolve())
        last_commit = None if force else self.index.get_last_commit()
        current_commit = self._get_current_commit(workspace)

        if not force and last_commit and last_commit == current_commit:
            logger.info("Index is up-to-date at %s. Nothing to do.", current_commit[:8])
            return {"indexed": 0, "skipped": 0, "errors": 0}

        if not force and last_commit:
            files = self.get_changed_files(since_commit=last_commit, workspace=workspace)
            logger.info(
                "Incremental index: %d changed files since %s",
                len(files),
                last_commit[:8],
            )
        else:
            files = self._find_all_bsl_files(workspace)
            logger.info("Full index: %d BSL files in %s", len(files), workspace)

        result = self._index_files(files, workspace)

        if current_commit:
            self.index.save_commit(current_commit, workspace_root=workspace)

        # Index 1C configuration metadata in background
        self._start_metadata_indexing(workspace)

        return result

    def index_metadata(
        self, workspace: str, config_root: str | None = None, *, force: bool = False
    ) -> dict:
        """
        Find and index 1C configuration metadata (XML export) within *workspace*.

        Returns:
            Dict with ``objects`` and ``members`` counts, or ``{"skipped": True}`` if no config found.
        """
        workspace = str(Path(workspace).resolve())
        resolved_config_root = (
            Path(config_root).resolve() if config_root else find_config_root(workspace)
        )
        if resolved_config_root is None:
            edt_mdo = find_edt_configuration_marker(workspace)
            if edt_mdo is not None:
                logger.debug(
                    "EDT project marker found at %s — XML crawl not applicable; export to files first",
                    edt_mdo,
                )
                return {
                    "skipped": True,
                    "reason": "edt_layout_detected",
                    "edt_configuration_mdo": str(edt_mdo),
                }
            logger.debug("No 1C config root found in %s — skipping metadata indexing", workspace)
            return {"skipped": True}

        config_root = str(resolved_config_root)
        fingerprint = self._metadata_fingerprint(config_root)
        if not force:
            cached_state = self.index.get_metadata_state(config_root)
            if cached_state is not None and cached_state.get("fingerprint") == fingerprint:
                logger.debug("Metadata index is up-to-date for %s", config_root)
                return {
                    "objects": int(cached_state.get("object_count") or 0),
                    "members": int(cached_state.get("member_count") or 0),
                    "skipped": True,
                    "reason": "metadata_unchanged",
                }

        logger.info("Indexing 1C metadata from %s", config_root)
        try:
            meta_objects = crawl_config(config_root)
            total_members = self.index.upsert_metadata(meta_objects)
            self.index.save_metadata_state(
                config_root=config_root,
                fingerprint=fingerprint,
                object_count=len(meta_objects),
                member_count=total_members,
            )
            logger.info(
                "Metadata indexed: %d objects, %d members",
                len(meta_objects),
                total_members,
            )
            return {"objects": len(meta_objects), "members": total_members}
        except Exception as exc:
            logger.error("Metadata indexing failed: %s", exc)
            return {"objects": 0, "members": 0, "error": str(exc)}

    @staticmethod
    def _metadata_fingerprint(config_root: str) -> str:
        """
        Return a cheap fingerprint for Designer XML metadata inputs.

        Uses relative XML paths plus size and nanosecond mtime. This avoids parsing
        10k+ XML files on every LSP/index warm path while still invalidating when
        the exported metadata tree changes.
        """
        root = Path(config_root)
        digest = hashlib.blake2b(digest_size=20)

        config_xml = root / "Configuration.xml"
        IncrementalIndexer._fingerprint_file(digest, root, config_xml)

        for folder_name in FOLDER_TO_KIND:
            folder = root / folder_name
            if not folder.is_dir():
                continue
            for xml_file in sorted(folder.glob("*.xml")):
                IncrementalIndexer._fingerprint_file(digest, root, xml_file)
                forms_dir = folder / xml_file.stem / "Forms"
                if not forms_dir.is_dir():
                    continue
                for form_xml in sorted(forms_dir.glob("*/Ext/Form.xml")):
                    IncrementalIndexer._fingerprint_file(digest, root, form_xml)
        return digest.hexdigest()

    @staticmethod
    def _fingerprint_file(digest: Any, root: Path, path: Path) -> None:
        try:
            stat = path.stat()
        except OSError:
            return
        try:
            rel = path.relative_to(root).as_posix()
        except ValueError:
            rel = str(path)
        digest.update(rel.encode("utf-8", errors="surrogateescape"))
        digest.update(b"\0")
        digest.update(str(stat.st_size).encode("ascii"))
        digest.update(b":")
        digest.update(str(stat.st_mtime_ns).encode("ascii"))
        digest.update(b"\n")

    def _start_metadata_indexing(self, workspace: str) -> None:
        """Start metadata indexing with single-flight + pending coalescing."""
        workspace = str(Path(workspace).resolve())
        with self._metadata_lock:
            if self._metadata_running:
                self._metadata_pending = True
                self._metadata_pending_workspace = workspace
                logger.debug("Metadata indexing already running; marked pending for %s", workspace)
                return
            self._metadata_running = True
            self._metadata_pending = False
            self._metadata_pending_workspace = None

        def _worker(initial_workspace: str) -> None:
            current_workspace = initial_workspace
            try:
                while True:
                    self.index_metadata(current_workspace)
                    with self._metadata_lock:
                        if self._metadata_pending:
                            self._metadata_pending = False
                            current_workspace = (
                                self._metadata_pending_workspace or current_workspace
                            )
                            self._metadata_pending_workspace = None
                            continue
                        self._metadata_running = False
                        break
            finally:
                with self._metadata_lock:
                    if self._metadata_running and not self._metadata_pending:
                        self._metadata_running = False

        threading.Thread(
            target=_worker,
            args=(workspace,),
            daemon=True,
            name="bsl-metadata-index",
        ).start()

    def get_changed_files(self, since_commit: str, workspace: str) -> list[str]:
        """
        Return absolute paths of .bsl/.os files changed since *since_commit*.

        Uses ``git diff --name-only`` against the current HEAD.
        Falls back to full scan if git is unavailable.
        """
        try:
            result = subprocess.run(
                ["git", "diff", "--name-only", since_commit, "HEAD"],
                capture_output=True,
                text=True,
                cwd=workspace,
                timeout=30,
            )
            if result.returncode != 0:
                logger.warning(
                    "git diff failed (rc=%d): %s. Falling back to full scan.",
                    result.returncode,
                    result.stderr.strip(),
                )
                return self._find_all_bsl_files(workspace)

            changed: list[str] = []
            for rel_path in result.stdout.splitlines():
                rel_path = rel_path.strip()
                if not rel_path:
                    continue
                if Path(rel_path).suffix.lower() in BSL_EXTENSIONS:
                    abs_path = str(Path(workspace) / rel_path)
                    changed.append(abs_path)
            return changed

        except (FileNotFoundError, subprocess.TimeoutExpired) as exc:
            logger.warning("git not available (%s). Falling back to full scan.", exc)
            return self._find_all_bsl_files(workspace)

    def index_file(self, path: str) -> dict:
        """
        Parse a single BSL file and upsert it into the index.

        Returns:
            Dict with ``symbols`` and ``calls`` counts, plus ``error`` if failed.
        """
        try:
            parsed = self._parse_file(path)
            if "error" in parsed:
                return {"symbols": 0, "calls": 0, "error": parsed["error"]}
            sym_dicts = parsed["symbols"]
            call_dicts = parsed["calls"]
            self.index.upsert_file(path, sym_dicts, call_dicts)
            return {"symbols": len(sym_dicts), "calls": len(call_dicts)}

        except Exception as exc:
            logger.error("Failed to index %s: %s", path, exc)
            return {"symbols": 0, "calls": 0, "error": str(exc)}

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _index_files(self, files: list[str], workspace: str) -> dict:
        indexed = 0
        skipped = 0
        errors = 0
        _ = workspace  # reserved for future workspace-scoped policies

        bulk_enabled = os.environ.get("BSL_INDEX_SQLITE_BULK", "1").strip().lower() not in (
            "0",
            "false",
            "no",
        )
        bulk_ctx = self.index.bulk_write if bulk_enabled and len(files) > 0 else nullcontext

        progress_ctx = (
            nullcontext()
            if self._quiet
            else Progress(
                TextColumn("[bold blue]{task.description}"),
                BarColumn(),
                MofNCompleteColumn(),
                TimeElapsedColumn(),
                transient=True,
            )
        )
        with progress_ctx as progress:
            task = (
                None
                if progress is None
                else progress.add_task("Indexing BSL files", total=len(files))
            )
            with bulk_ctx():
                existing: list[str] = []
                for path in files:
                    if not Path(path).exists():
                        # File was deleted — remove from index
                        self.index.remove_file(path)
                        skipped += 1
                        if self._on_progress:
                            self._on_progress(indexed + skipped + errors, len(files), path)
                        if progress is not None:
                            progress.advance(task)
                        continue
                    existing.append(path)

                if self._parse_workers <= 1 or len(existing) <= 1:
                    # Sequential mode.
                    for path in existing:
                        if progress is not None:
                            progress.update(task, description=f"[bold blue]{Path(path).name}")
                        parsed = self._parse_file(path)
                        if "error" in parsed:
                            errors += 1
                        else:
                            self.index.upsert_file(path, parsed["symbols"], parsed["calls"])
                            indexed += 1
                        if self._on_progress:
                            self._on_progress(indexed + skipped + errors, len(files), path)
                        if progress is not None:
                            progress.advance(task)
                else:
                    # Parallel parse with daemon workers to avoid stop-timeout regressions
                    # during LSP process shutdown.
                    work_q: Queue[str] = Queue()
                    worker_count = min(self._parse_workers, len(existing))
                    # Bound backpressure: main thread serializes SQLite writes; without a
                    # maxsize, producers could queue tens of thousands of parsed trees in RAM.
                    out_max = max(8, worker_count * 2)
                    out_q: Queue[tuple[str, dict[str, Any]]] = Queue(maxsize=out_max)
                    for path in existing:
                        work_q.put(path)

                    def _worker() -> None:
                        while True:
                            try:
                                p = work_q.get_nowait()
                            except Empty:
                                return
                            try:
                                out_q.put((p, self._parse_file(p)))
                            finally:
                                work_q.task_done()

                    workers: list[threading.Thread] = []
                    for i in range(worker_count):
                        t = threading.Thread(
                            target=_worker,
                            daemon=True,
                            name=f"bsl-index-parse-{i + 1}",
                        )
                        t.start()
                        workers.append(t)

                    processed = 0
                    while processed < len(existing):
                        path, parsed = out_q.get()
                        if progress is not None:
                            progress.update(task, description=f"[bold blue]{Path(path).name}")
                        if "error" in parsed:
                            errors += 1
                        else:
                            self.index.upsert_file(path, parsed["symbols"], parsed["calls"])
                            indexed += 1

                        if self._on_progress:
                            self._on_progress(indexed + skipped + errors, len(files), path)
                        if progress is not None:
                            progress.advance(task)
                        processed += 1

                    for t in workers:
                        t.join(timeout=0.1)

        logger.info(
            "Indexing complete: %d indexed, %d skipped, %d errors",
            indexed,
            skipped,
            errors,
        )
        return {"indexed": indexed, "skipped": skipped, "errors": errors}

    def _parse_file(self, path: str) -> dict[str, Any]:
        """Parse one file and return prepared symbol/call dict lists."""
        try:
            tree = self._get_parser().parse_file(path)
            semantic = extract_semantic_model(tree, file_path=path)
            return {
                "symbols": [_symbol_to_dict(s) for s in semantic.symbols],
                "calls": [_call_to_dict(c) for c in semantic.calls],
            }
        except Exception as exc:  # noqa: BLE001
            return {"error": str(exc)}

    @staticmethod
    def _find_all_bsl_files(workspace: str) -> list[str]:
        """Walk the workspace and return all .bsl/.os files.

        Uses a single ``os.walk`` pass instead of two ``Path.rglob`` traversals plus a
        full sort of the combined list — large workspaces (10k+ files) spend noticeable
        time just enumerating paths.
        """
        root = os.path.abspath(workspace)
        result: list[str] = []
        for dirpath, dirnames, filenames in os.walk(root, followlinks=False):
            dirnames[:] = [
                name
                for name in dirnames
                if name not in _DEFAULT_EXCLUDED_DIRS and not name.endswith(".egg-info")
            ]
            for name in filenames:
                suf = Path(name).suffix.lower()
                if suf in BSL_EXTENSIONS:
                    result.append(os.path.join(dirpath, name))
        result.sort()
        return result

    @staticmethod
    def _get_current_commit(workspace: str) -> str | None:
        """Return current HEAD commit hash, or None if not a git repo."""
        try:
            result = subprocess.run(
                ["git", "rev-parse", "HEAD"],
                capture_output=True,
                text=True,
                cwd=workspace,
                timeout=10,
            )
            return result.stdout.strip() if result.returncode == 0 else None
        except FileNotFoundError, subprocess.TimeoutExpired:
            return None


# ---------------------------------------------------------------------------
# Helper converters
# ---------------------------------------------------------------------------


def _symbol_to_dict(symbol: Any) -> dict:  # noqa: ANN401
    """Convert a Symbol dataclass to a plain dict for the index."""
    return {
        "name": symbol.name,
        "line": symbol.line,
        "character": symbol.character,
        "end_line": symbol.end_line,
        "end_character": symbol.end_character,
        "kind": symbol.kind,
        "is_export": symbol.is_export,
        "container": symbol.container,
        "signature": symbol.signature,
        "doc_comment": symbol.doc_comment,
    }


def _call_to_dict(call: Any) -> dict:  # noqa: ANN401
    """Convert a Call dataclass to a plain dict for the index."""
    return {
        "caller_line": call.caller_line,
        "caller_character": getattr(call, "caller_character", 0),
        "caller_name": call.caller_name,
        "callee_name": call.callee_name,
        "callee_args_count": call.callee_args_count,
    }
