# DevOps Employee — test-publish

## Config

- **trigger_branch**: main (initial), X.Y.x (version branches, set as default)
- **python_version**: "3.12"
- **package_manager**: pip + build
- **publish_target**: PyPI (via pypa/gh-action-pypi-publish)
- **versioning**: setuptools-scm (git tag-based, semver: X.Y.Z)
- **release_notes**: Claude Code CLI via z.ai (glm-5.1), English language
- **version_scheme**: X.Y.x branches — patch bumps on publish, new minor/major via workflow

## Workflow Registry

| Workflow | File | Trigger | Description |
|----------|------|---------|-------------|
| Open New Version | `new_version.yml` | workflow_dispatch (minor/major) | Creates X.Y.x branch, sets as default |
| Publish Release | `publish.yml` | workflow_dispatch | Calculates next patch, generates release notes, publishes to PyPI, creates GitHub Release |

## Version Branching Model

1. Start from `main`
2. **Open New Version** (major): creates `1.0.x`, `2.0.x` etc. — bumps MAJOR
3. **Open New Version** (minor): creates `1.1.x`, `1.2.x` etc. — bumps MINOR
4. **Publish Release** on `X.Y.x` branch: creates `vX.Y.0`, `vX.Y.1`, `vX.Y.2` — bumps PATCH

## Secrets Required

- `ZAI_TOKEN` — for AI release notes generation (z.ai Anthropic-compatible API)
- `PYPI_API_TOKEN` — for PyPI publishing
- `GH_TOKEN` — PAT with admin rights for changing default branch

## Lessons

| Problem | Why | How to prevent |
|---------|-----|----------------|
