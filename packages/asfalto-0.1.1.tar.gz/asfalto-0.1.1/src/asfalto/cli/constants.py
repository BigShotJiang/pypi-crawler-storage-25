from importlib.metadata import version


def get_version():
    try:
        return version("asfalto")
    except Exception:
        return None


header = rf"""
 █████╗ ███████╗███████╗ █████╗ ██╗  ████████╗ ██████╗ 
██╔══██╗██╔════╝██╔════╝██╔══██╗██║  ╚══██╔══╝██╔═══██╗
███████║███████╗█████╗  ███████║██║     ██║   ██║   ██║
██╔══██║╚════██║██╔══╝  ██╔══██║██║     ██║   ██║   ██║
██║  ██║███████║██║     ██║  ██║███████╗██║   ╚██████╔╝
╚═╝  ╚═╝╚══════╝╚═╝     ╚═╝  ╚═╝╚══════╝╚═╝    ╚═════╝ 

{get_version()}. Accelerating ontology creation for beamline data.
Copyright 2025 APS-XSD Argonne National Laboratory
"""
