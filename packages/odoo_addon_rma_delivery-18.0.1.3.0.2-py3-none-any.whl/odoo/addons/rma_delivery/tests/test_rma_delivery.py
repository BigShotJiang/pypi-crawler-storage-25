# Copyright 2022 Tecnativa - David Vidal
# Copyright 2026 Tecnativa - Víctor Martínez
# License AGPL-3.0 or later (https://www.gnu.org/licenses/agpl).
from odoo.tests import Form

from odoo.addons.rma.tests.test_rma import TestRma


class TestRmaDeliveryBase(TestRma):
    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        cls.carrier_product = cls.product_product.create(
            {"name": "Delivery product test 1", "type": "service"}
        )
        cls.replace_product = cls.product_product.create(
            {"name": "Replace product test 1", "type": "consu", "is_storable": True}
        )
        cls.carrier = cls.env["delivery.carrier"].create(
            {
                "name": "Test Fixed delivery method",
                "product_id": cls.carrier_product.id,
            }
        )
        cls.carrier_customer = cls.env["delivery.carrier"].create(
            {
                "name": "Test Customer delivery method",
                "product_id": cls.carrier_product.id,
            }
        )
        cls.partner.property_delivery_carrier_id = cls.carrier_customer
        cls.partner_shipping.property_delivery_carrier_id = False
        cls.company.rma_fixed_delivery_method = cls.carrier
        cls.company.rma_fixed_reception_strategy = cls.carrier

    def _return_to_customer(self, rma, delivery_type="return"):
        """Helper to return the rma"""
        delivery_form = Form(
            self.env["rma.delivery.wizard"].with_context(
                active_ids=rma.ids,
                rma_delivery_type=delivery_type,
            )
        )
        if delivery_type == "replace":
            delivery_form.product_id = self.replace_product
        delivery_form.product_uom_qty = 1
        delivery_wizard = delivery_form.save()
        delivery_wizard.action_deliver()
        return rma.delivery_move_ids.picking_id


class TestRmaDelivery(TestRmaDeliveryBase):
    def test_01_fixed_method(self):
        """Fixed method. RMA gets the company default carrier"""
        # Return picking
        rma = self._create_confirm_receive(
            self.partner_shipping, self.product, 1, self.rma_loc
        )
        self.company.rma_delivery_strategy = "fixed_method"
        picking = self._return_to_customer(rma)
        self.assertEqual(
            picking.carrier_id,
            self.carrier,
            "The carrier isn't the one set in the company as default",
        )
        # Replace picking
        rma = self._create_confirm_receive(
            self.partner_shipping, self.product, 1, self.rma_loc
        )
        picking = self._return_to_customer(rma, "replace")
        self.assertEqual(
            picking.carrier_id,
            self.carrier,
            "The carrier isn't the one set in the company as default",
        )

    def test_02_customer_method(self):
        """Customer method. RMA gets the carrier from the contact"""
        # Return picking
        rma = self._create_confirm_receive(
            self.partner_shipping, self.product, 1, self.rma_loc
        )
        self.company.rma_delivery_strategy = "customer_method"
        picking = self._return_to_customer(rma)
        self.assertEqual(
            picking.carrier_id,
            self.carrier_customer,
            "The carrier isn't the same one as in the commercial partner",
        )
        carrier_2 = self.env["delivery.carrier"].create(
            {"name": "Test delivery method", "product_id": self.carrier_product.id}
        )
        self.partner_shipping.property_delivery_carrier_id = carrier_2
        rma = self._create_confirm_receive(
            self.partner_shipping, self.product, 1, self.rma_loc
        )
        picking = self._return_to_customer(rma)
        self.assertEqual(
            picking.carrier_id,
            carrier_2,
            "The carrier isn't the same one as in the picking partner",
        )
        # Replace picking
        rma = self._create_confirm_receive(
            self.partner_shipping, self.product, 1, self.rma_loc
        )
        picking = self._return_to_customer(rma, "replace")
        self.assertEqual(
            picking.carrier_id,
            carrier_2,
            "The carrier isn't the same one as in the picking partner",
        )

    def test_03_mixed_method(self):
        """Mixed method. RMA gets the carrier from the contact otherwise the company
        default one"""
        # Return picking
        rma = self._create_confirm_receive(
            self.partner_shipping, self.product, 1, self.rma_loc
        )
        self.company.rma_delivery_strategy = "mixed_method"
        picking = self._return_to_customer(rma)
        self.assertEqual(
            picking.carrier_id,
            self.carrier_customer,
            "The carrier isn't the same one as in the commercial partner",
        )
        self.partner.property_delivery_carrier_id = False
        rma = self._create_confirm_receive(
            self.partner_shipping, self.product, 1, self.rma_loc
        )
        picking = self._return_to_customer(rma)
        self.assertEqual(
            picking.carrier_id,
            self.carrier,
            "The carrier isn't the one set in the company as default",
        )
        # Replace picking
        rma = self._create_confirm_receive(
            self.partner_shipping, self.product, 1, self.rma_loc
        )
        picking = self._return_to_customer(rma, "replace")
        self.assertEqual(
            picking.carrier_id,
            self.carrier,
            "The carrier isn't the one set in the company as default",
        )

    def test_04_rma_method(self):
        self.company.rma_delivery_strategy = "rma_method"
        rma = self._create_confirm_receive(
            self.partner_shipping, self.product, 1, self.rma_loc
        )
        rma.carrier_id = self.carrier
        picking = self._return_to_customer(rma)
        self.assertEqual(picking.carrier_id, self.carrier)
        # Replace picking
        rma = self._create_confirm_receive(
            self.partner_shipping, self.product, 1, self.rma_loc
        )
        rma.carrier_id = self.carrier
        picking = self._return_to_customer(rma, "replace")
        self.assertEqual(picking.carrier_id, self.carrier)

    def test_reception_01_fixed_method(self):
        self.company.rma_reception_strategy = "fixed_method"
        rma = self._create_rma(self.partner_shipping, self.product, 1, self.rma_loc)
        rma.action_confirm()
        self.assertEqual(rma.reception_move_id.picking_id.carrier_id, self.carrier)

    def test_reception_02_customer_method(self):
        self.company.rma_reception_strategy = "customer_method"
        rma = self._create_rma(self.partner_shipping, self.product, 1, self.rma_loc)
        rma.action_confirm()
        self.assertEqual(
            rma.reception_move_id.picking_id.carrier_id,
            self.carrier_customer,
        )
        carrier_2 = self.env["delivery.carrier"].create(
            {"name": "Test delivery method", "product_id": self.carrier_product.id}
        )
        self.partner_shipping.property_delivery_carrier_id = carrier_2
        rma2 = self._create_rma(self.partner_shipping, self.product, 1, self.rma_loc)
        rma2.action_confirm()
        self.assertEqual(
            rma2.reception_move_id.picking_id.carrier_id,
            carrier_2,
        )

    def test_reception_03_mixed_method(self):
        self.company.rma_reception_strategy = "mixed_method"
        rma = self._create_rma(self.partner_shipping, self.product, 1, self.rma_loc)
        rma.action_confirm()
        self.assertEqual(
            rma.reception_move_id.picking_id.carrier_id, self.carrier_customer
        )
        self.partner.property_delivery_carrier_id = False
        rma2 = self._create_rma(self.partner_shipping, self.product, 1, self.rma_loc)
        rma2.action_confirm()
        self.assertEqual(rma2.reception_move_id.picking_id.carrier_id, self.carrier)

    def test_reception_04_rma_method(self):
        self.company.rma_reception_strategy = "rma_method"
        rma = self._create_rma(self.partner_shipping, self.product, 1, self.rma_loc)
        rma.reception_carrier_id = self.carrier
        rma.action_confirm()
        self.assertEqual(rma.reception_move_id.picking_id.carrier_id, self.carrier)
        # Change reception carrier
        res = rma.action_open_choose_carrier_wizard()
        wizard_form = Form(self.env[res["res_model"]].with_context(**res["context"]))
        self.assertEqual(wizard_form.carrier_type, "reception")
        self.assertEqual(wizard_form.carrier_id, self.carrier)
        wizard_form.carrier_id = self.carrier_customer
        wizard = wizard_form.save()
        wizard.button_confirm()
        self.assertEqual(rma.reception_carrier_id, self.carrier_customer)
        self.assertEqual(
            rma.reception_move_id.picking_id.carrier_id, self.carrier_customer
        )
        rma.reception_move_id.picking_id.button_validate()
        rma.carrier_id = self.carrier
        self.company.rma_delivery_strategy = "rma_method"
        picking = self._return_to_customer(rma)
        self.assertEqual(picking.carrier_id, self.carrier)
        # Change delivery carrier
        res = rma.action_open_choose_carrier_wizard()
        wizard_form = Form(self.env[res["res_model"]].with_context(**res["context"]))
        self.assertEqual(wizard_form.carrier_type, "delivery")
        self.assertEqual(wizard_form.carrier_id, self.carrier)
        wizard_form.carrier_id = self.carrier_customer
        wizard = wizard_form.save()
        wizard.button_confirm()
        self.assertEqual(rma.carrier_id, self.carrier_customer)
        self.assertEqual(picking.carrier_id, self.carrier_customer)

    def test_reception_04_rma_method_picking_return(self):
        self.company.rma_reception_strategy = "rma_method"
        origin_delivery = self._create_delivery()
        origin_delivery.carrier_id = self.carrier
        stock_return_picking_form = Form(
            self.env["stock.return.picking"].with_context(
                active_ids=origin_delivery.ids,
                active_id=origin_delivery.id,
                active_model="stock.picking",
            )
        )
        stock_return_picking_form.create_rma = True
        stock_return_picking_form.rma_operation_id = self.operation
        self.assertEqual(stock_return_picking_form.reception_carrier_id, self.carrier)
        stock_return_picking_form.reception_carrier_id = self.carrier_customer
        return_wizard = stock_return_picking_form.save()
        for move in origin_delivery.move_ids_without_package:
            return_wizard.product_return_moves.filtered(
                lambda x, move=move: x.move_id == move
            ).quantity = move.quantity
        picking_action = return_wizard.action_create_returns()
        reception = self.env["stock.picking"].browse(picking_action["res_id"])
        self.assertEqual(reception.carrier_id, self.carrier_customer)
        reception_moves = reception.move_ids
        self.assertTrue(reception_moves.rma_receiver_ids)
        rma = reception_moves.rma_receiver_ids
        self.assertEqual(rma.reception_carrier_id, self.carrier_customer)
