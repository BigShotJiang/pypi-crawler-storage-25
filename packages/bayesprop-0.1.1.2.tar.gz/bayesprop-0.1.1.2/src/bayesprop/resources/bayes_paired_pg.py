"""Pooled Bernoulli logistic regression for paired A/B model comparison (Pólya-Gamma).

This module provides :class:`PairedBayesPropTestPG`, a class for fitting
a pooled Bayesian Bernoulli logistic model to paired binary scores using
exact Pólya-Gamma data augmentation (Gibbs sampling), performing hypothesis
testing via the Savage-Dickey density ratio, running posterior-predictive
diagnostics, and generating publication-ready plots.

Compared to the Laplace approximation in :mod:`bayesprop.resources.bayes_paired_laplace`,
the PG sampler provides exact (up to MCMC error) posterior inference and
multi-chain MCMC diagnostics (R-hat, ESS).

Typical workflow::

    from bayesprop.resources.bayes_paired_pg import PairedBayesPropTestPG

    model = PairedBayesPropTestPG(seed=42).fit(y_A, y_B)
    model.print_summary()
    model.plot_trace()
    model.plot_posterior_delta()

For multi-metric comparisons::

    results = {"Relevancy": model_rel, "Faithfulness": model_faith}
    PairedBayesPropTestPG.plot_forest(results, label_A="v2", label_B="v1")
"""

from __future__ import annotations

from typing import Any

import numpy as np
import numpy.typing as npt
import pandas as pd
from numpy.linalg import solve
from polyagamma import random_polyagamma
from scipy.stats import gaussian_kde, norm, t as student_t

from bayesprop.resources.base import BaseBayesPropTest
from bayesprop.resources.data_schemas import (
    CredibleInterval,
    DecisionRuleType,
    HypothesisDecision,
    MCMCDiagnostics,
    MCMCParamDiagnostic,
    PairedSummary,
    PosteriorProbH0Result,
    PPCStatistic,
    ROPEResult,
    SavageDickeyResult,
)
from bayesprop.utils.utils import binarize_if_needed


def sigmoid(x: npt.ArrayLike) -> np.ndarray:
    """Numerically stable element-wise sigmoid function."""
    x = np.asarray(x, dtype=float)
    return np.where(
        x >= 0,
        1.0 / (1.0 + np.exp(-x)),
        np.exp(x) / (1.0 + np.exp(x)),
    )


def _format_bf(value: float) -> str:
    """Format a Bayes Factor for human-readable display."""
    if value > 1e4:
        return f"10^{np.log10(value):.0f}"
    elif value < 1e-4 and value > 0:
        return f"10^{np.log10(value):.0f}"
    else:
        return f"{value:.2f}"


def _build_design_matrix(
    y_A: np.ndarray, y_B: np.ndarray
) -> tuple[np.ndarray, np.ndarray]:
    """Stack paired binary outcomes into a design matrix for logistic regression.

    Returns:
        (X, y) where X is (2n, 2) with columns [intercept, d_A]
        and y is (2n,) stacked binary outcomes.
    """
    n = len(y_A)
    X_A = np.column_stack([np.ones(n), np.ones(n)])  # intercept=1, d_A=1
    X_B = np.column_stack([np.ones(n), np.zeros(n)])  # intercept=1, d_A=0
    X = np.vstack([X_A, X_B])
    y = np.concatenate([y_A, y_B])
    return X, y


class PairedBayesPropTestPG(BaseBayesPropTest):
    """Pooled Bernoulli logistic model for paired A/B comparison (PG Gibbs).

    Uses Pólya-Gamma data augmentation for exact Gibbs sampling instead
    of Laplace approximation.

    Generative model (fixed priors, default)::

        μ      ~ N(0, σ_μ)            (overall intercept)
        δ_A    ~ N(0, σ_δ)            (model-A advantage)
        y_A,i  ~ Bernoulli(σ(μ + δ_A))
        y_B,i  ~ Bernoulli(σ(μ))

    Hierarchical variant (when *hyperprior_mu* and *hyperprior_delta*
    are supplied)::

        σ²_μ   ~ IG(a_μ, b_μ)
        σ²_δ   ~ IG(a_δ, b_δ)
        μ      ~ N(0, σ²_μ)
        δ_A    ~ N(0, σ²_δ)
        y_A,i  ~ Bernoulli(σ(μ + δ_A))
        y_B,i  ~ Bernoulli(σ(μ))

    In the hierarchical case the prior variances are *sampled* from
    their Inverse-Gamma full conditionals at each Gibbs iteration,
    yielding exact posterior inference over ``(μ, δ_A, σ²_μ, σ²_δ)``.

    Inference proceeds by augmenting with Pólya-Gamma latent variables
    ω_i ~ PG(1, x_i'β), which yields conjugate Gaussian conditionals
    for β = [μ, δ_A].

    Multiple independent chains are run for MCMC diagnostics (R-hat, ESS).

    Attributes:
        chains: Array of shape ``(n_chains, n_samples, 2)`` with posterior
            draws for ``[mu, delta_A]`` per chain (``None`` before :meth:`fit`).
        samples: Pooled posterior draws, shape ``(n_total, 2)``.
        summary: Dict with ``mean_delta``, ``ci_95``, ``P(A > B)``,
            and ``delta_A_posterior_mean`` on the probability scale.
        trace_summary: ``pandas.DataFrame`` with posterior summary
            for ``delta_A`` and ``mu`` including R-hat and ESS.
        delta_A_samples: 1-D array of pooled posterior draws for ``delta_A``
            (logit scale).
        y_A_obs: Observed binary scores for model A (set by :meth:`fit`).
        y_B_obs: Observed binary scores for model B (set by :meth:`fit`).
        sigma_sq_mu_samples: Pooled posterior draws for σ²_μ (hierarchical
            mode only, ``None`` otherwise).
        sigma_sq_delta_samples: Pooled posterior draws for σ²_δ (hierarchical
            mode only, ``None`` otherwise).
    """

    def __init__(
        self,
        prior_sigma_delta: float = 1.0,
        prior_sigma_mu: float = 2.0,
        seed: int = 0,
        n_iter: int = 1000,
        burn_in: int = 200,
        n_chains: int = 2,
        decision_rule: DecisionRuleType = "all",
        rope_epsilon: float = 0.02,
        threshold: float = 0.5,
        verbose: bool = False,
        hyperprior_mu: tuple[float, float] | None = None,
        hyperprior_delta: tuple[float, float] | None = None,
    ) -> None:
        """Initialise model configuration.

        Args:
            prior_sigma_delta: Standard deviation of the N(0, σ) prior
                on ``delta_A`` (logit scale).  When hyperpriors are active
                this serves as the initial value for σ_δ.
            prior_sigma_mu: Standard deviation of the N(0, σ) prior
                on ``mu`` (logit scale).  When hyperpriors are active
                this serves as the initial value for σ_μ.
            seed: Random seed for reproducibility.
            n_iter: Total Gibbs iterations per chain (including burn-in).
                The default (``1000``) is calibrated for the paired
                Bernoulli model with Pólya–Gamma augmentation, where the
                Gibbs chain is block-conjugate and reaches stationarity
                within ~50 iterations. Empirically R-hat ≈ 1.00 from
                ``n_iter ≥ 200`` on both small (``n = 10``) and realistic
                (``n ≥ 500``) data, and ``n_iter = 1000`` yields an ESS
                of ~1300 per chain — comfortable for posterior means,
                95 % credible intervals, and ROPE masses. Increase to
                ``n_iter = 2000–5000`` if you need stable Savage–Dickey
                BF estimates for very strong effects (BF tail behaviour
                is KDE-sensitive, not chain-sensitive).
            burn_in: Number of warm-up iterations to discard per chain.
                The default (``200``) is conservative — the conjugate
                Gibbs sampler typically needs ``≤ 50``.
            n_chains: Number of independent MCMC chains. Two chains are
                enough for R-hat convergence diagnostics on this
                block-conjugate sampler; raise to ``≥ 4`` if you want
                tighter ESS estimates or a more rigorous R-hat.
            decision_rule: Default decision framework — one of
                ``"bayes_factor"``, ``"posterior_null"``, ``"rope"``, or ``"all"``.
            rope_epsilon: Half-width of the ROPE interval (default 0.02 = 2 pp).
            threshold: Cutoff used to binarise continuous inputs in
                ``[0, 1]`` passed to :meth:`fit`. Already-binary inputs
                are left untouched. Defaults to ``0.5``.
            verbose: If ``True``, emit a one-line notice whenever
                continuous inputs are binarised.
            hyperprior_mu: ``(a, b)`` shape and scale of an
                Inverse-Gamma hyperprior on σ²_μ.  When set together
                with *hyperprior_delta* the model becomes hierarchical
                and both prior variances are sampled from their IG full
                conditionals at each Gibbs iteration.
                ``None`` (default) keeps σ_μ fixed.
            hyperprior_delta: ``(a, b)`` shape and scale of an
                Inverse-Gamma hyperprior on σ²_δ.  ``None`` (default)
                keeps σ_δ fixed at *prior_sigma_delta*.
        """
        if (hyperprior_mu is None) != (hyperprior_delta is None):
            raise ValueError(
                "hyperprior_mu and hyperprior_delta must both be set or both be None."
            )

        self.prior_sigma_delta: float = prior_sigma_delta
        self.prior_sigma_mu: float = prior_sigma_mu
        self.seed: int = seed
        self.n_iter: int = n_iter
        self.burn_in: int = burn_in
        self.n_chains: int = n_chains
        self.decision_rule: DecisionRuleType = decision_rule
        self.rope_epsilon: float = rope_epsilon
        self.threshold: float = threshold
        self.verbose: bool = verbose
        self.hyperprior_mu: tuple[float, float] | None = hyperprior_mu
        self.hyperprior_delta: tuple[float, float] | None = hyperprior_delta

        # --- Populated by .fit() ---
        self.chains: np.ndarray | None = None
        self.samples: np.ndarray | None = None
        self.summary: dict[str, Any] | None = None
        self.trace_summary: pd.DataFrame | None = None
        self.delta_A_samples: np.ndarray | None = None
        self.delta_samples: np.ndarray | None = None
        self.y_A_obs: np.ndarray | None = None
        self.y_B_obs: np.ndarray | None = None
        self.sigma_sq_mu_samples: np.ndarray | None = None
        self.sigma_sq_delta_samples: np.ndarray | None = None

    def __repr__(self) -> str:
        """Return an informative string representation."""
        cls = type(self).__name__
        mode = "hierarchical" if self.hyperprior_mu is not None else "fixed"
        header = (
            f"{cls}(n_iter={self.n_iter}, n_chains={self.n_chains}, "
            f"prior_\u03c3_\u03b4={self.prior_sigma_delta}, "
            f"mode={mode}, seed={self.seed})"
        )
        if self.summary is None:
            return header
        s = self.summary
        return (
            f"{header}\n"
            f"  \u03b8_A = {s.theta_A_mean:.4f},  \u03b8_B = {s.theta_B_mean:.4f}\n"
            f"  Mean \u0394 = {s.mean_delta:+.4f},  "
            f"95% CI = [{s.ci_95.lower:.4f}, {s.ci_95.upper:.4f}]\n"
            f"  P(A > B) = {s.p_A_greater_B:.4f}"
        )

    # ------------------------------------------------------------------ #
    #  Internal sampler
    # ------------------------------------------------------------------ #

    def _run_single_chain(
        self,
        X: np.ndarray,
        y: np.ndarray,
        rng: np.random.Generator,
    ) -> np.ndarray:
        """Run one PG Gibbs chain.

        Returns:
            Array of shape ``(n_iter - burn_in, 2)`` with posterior draws.
        """
        n, p = X.shape
        kappa = y - 0.5

        # Prior precision
        B0_inv = np.diag(
            [
                1.0 / self.prior_sigma_mu**2,
                1.0 / self.prior_sigma_delta**2,
            ]
        )
        b0 = np.zeros(p)

        beta = np.zeros(p)
        samples = []

        for it in range(self.n_iter):
            eta = X @ beta

            # Pólya-Gamma step: ω_i ~ PG(1, η_i)
            omega = random_polyagamma(1.0, eta, random_state=rng)

            # Posterior conditional: β | ω, y
            A = X.T @ np.diag(omega) @ X + B0_inv
            rhs = X.T @ kappa + B0_inv @ b0
            Sigma = solve(A, np.eye(p))
            mu_post = Sigma @ rhs

            beta = rng.multivariate_normal(mu_post, Sigma)

            if it >= self.burn_in:
                samples.append(beta.copy())

        return np.array(samples)

    def _run_single_chain_hierarchical(
        self,
        X: np.ndarray,
        y: np.ndarray,
        rng: np.random.Generator,
        hp_mu: tuple[float, float],
        hp_delta: tuple[float, float],
    ) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
        """Run one PG Gibbs chain with Inverse-Gamma hyperpriors on the prior variances.

        At each iteration the sampler performs three conjugate updates:

        1. **PG augmentation + β update** — identical to the fixed-prior
           case but with the current (sampled) prior precision.
        2. **σ²_μ | μ** — draw from
           ``IG(a_μ + 1/2, b_μ + μ²/2)``.
        3. **σ²_δ | δ_A** — draw from
           ``IG(a_δ + 1/2, b_δ + δ_A²/2)``.

        Args:
            X: Design matrix ``(2n, 2)``.
            y: Stacked binary outcomes ``(2n,)``.
            rng: NumPy random generator for this chain.
            hp_mu: ``(a, b)`` shape and scale of the IG hyperprior on σ²_μ.
            hp_delta: ``(a, b)`` shape and scale of the IG hyperprior on σ²_δ.

        Returns:
            Tuple ``(beta_samples, sigma_sq_mu_samples, sigma_sq_delta_samples)``
            where ``beta_samples`` has shape ``(n_iter - burn_in, 2)`` and the
            variance traces have shape ``(n_iter - burn_in,)``.
        """
        n, p = X.shape
        kappa = y - 0.5
        a_mu, b_mu = hp_mu
        a_delta, b_delta = hp_delta
        b0 = np.zeros(p)

        # Initialise prior variances from the constructor defaults.
        sigma_sq_mu = self.prior_sigma_mu**2
        sigma_sq_delta = self.prior_sigma_delta**2

        beta = np.zeros(p)
        beta_samples: list[np.ndarray] = []
        sigma_sq_mu_samples: list[float] = []
        sigma_sq_delta_samples: list[float] = []

        for it in range(self.n_iter):
            # --- 1. PG augmentation + β | ω, σ²_μ, σ²_δ ---
            eta = X @ beta
            omega = random_polyagamma(1.0, eta, random_state=rng)

            B0_inv = np.diag([1.0 / sigma_sq_mu, 1.0 / sigma_sq_delta])
            A = X.T @ np.diag(omega) @ X + B0_inv
            rhs = X.T @ kappa + B0_inv @ b0
            Sigma = solve(A, np.eye(p))
            mu_post = Sigma @ rhs

            beta = rng.multivariate_normal(mu_post, Sigma)

            # --- 2. σ²_μ | μ  ~  IG(a_μ + 1/2,  b_μ + μ²/2) ---
            shape_mu = a_mu + 0.5
            scale_mu = b_mu + 0.5 * beta[0] ** 2
            sigma_sq_mu = 1.0 / rng.gamma(shape_mu, 1.0 / scale_mu)

            # --- 3. σ²_δ | δ_A  ~  IG(a_δ + 1/2,  b_δ + δ²/2) ---
            shape_delta = a_delta + 0.5
            scale_delta = b_delta + 0.5 * beta[1] ** 2
            sigma_sq_delta = 1.0 / rng.gamma(shape_delta, 1.0 / scale_delta)

            if it >= self.burn_in:
                beta_samples.append(beta.copy())
                sigma_sq_mu_samples.append(sigma_sq_mu)
                sigma_sq_delta_samples.append(sigma_sq_delta)

        return (
            np.array(beta_samples),
            np.array(sigma_sq_mu_samples),
            np.array(sigma_sq_delta_samples),
        )

    # ------------------------------------------------------------------ #
    #  Fitting
    # ------------------------------------------------------------------ #

    def fit(self, y_A_obs: np.ndarray, y_B_obs: np.ndarray) -> PairedBayesPropTestPG:
        """Fit the model via PG Gibbs sampling with multiple chains.

        In hierarchical mode (when *hyperprior_mu* and *hyperprior_delta*
        are set) the prior variances σ²_μ and σ²_δ are sampled from
        their Inverse-Gamma full conditionals at every Gibbs iteration,
        giving exact posterior inference over
        ``(μ, δ_A, σ²_μ, σ²_δ)``.

        Args:
            y_A_obs: Observed scores for model A — either binary
                ``{0, 1}`` or continuous in ``[0, 1]``. Continuous inputs
                are binarised at ``self.threshold`` (default ``0.5``);
                values outside ``[0, 1]`` raise :class:`ValueError`.
            y_B_obs: Observed scores for model B — same conventions.

        Returns:
            self (for method chaining).
        """
        y_A_bin = binarize_if_needed(
            y_A_obs, self.threshold, name="y_A_obs", verbose=self.verbose
        )
        y_B_bin = binarize_if_needed(
            y_B_obs, self.threshold, name="y_B_obs", verbose=self.verbose
        )
        self.y_A_obs = y_A_bin.astype(int)
        self.y_B_obs = y_B_bin.astype(int)

        X, y = _build_design_matrix(self.y_A_obs, self.y_B_obs)

        # Run multiple chains with different seeds
        seed_seq = np.random.SeedSequence(self.seed)
        child_seeds = seed_seq.spawn(self.n_chains)

        hierarchical = self.hyperprior_mu is not None

        if hierarchical:
            assert self.hyperprior_mu is not None  # noqa: S101
            assert self.hyperprior_delta is not None  # noqa: S101
            chain_list: list[np.ndarray] = []
            sq_mu_chains: list[np.ndarray] = []
            sq_delta_chains: list[np.ndarray] = []
            for i in range(self.n_chains):
                rng = np.random.default_rng(child_seeds[i])
                beta_s, sq_mu_s, sq_delta_s = self._run_single_chain_hierarchical(
                    X,
                    y,
                    rng,
                    hp_mu=self.hyperprior_mu,
                    hp_delta=self.hyperprior_delta,
                )
                chain_list.append(beta_s)
                sq_mu_chains.append(sq_mu_s)
                sq_delta_chains.append(sq_delta_s)
            self.sigma_sq_mu_samples = np.concatenate(sq_mu_chains)
            self.sigma_sq_delta_samples = np.concatenate(sq_delta_chains)
            # Per-chain arrays for trace / ACF plots.
            self._variance_chains_mu = np.array(sq_mu_chains)  # (n_chains, n_samples)
            self._variance_chains_delta = np.array(sq_delta_chains)
        else:
            chain_list = []
            for i in range(self.n_chains):
                rng = np.random.default_rng(child_seeds[i])
                chain_list.append(self._run_single_chain(X, y, rng))

        self.chains = np.array(chain_list)  # (n_chains, n_samples, 2)
        self.samples = self.chains.reshape(-1, 2)  # pooled

        mu_s = self.samples[:, 0]
        delta_A_s = self.samples[:, 1]
        self.delta_A_samples = delta_A_s

        pA_s = sigmoid(mu_s + delta_A_s)
        pB_s = sigmoid(mu_s)
        Delta_s = pA_s - pB_s

        self.delta_samples = Delta_s

        self.summary = PairedSummary(
            mean_delta=float(Delta_s.mean()),
            ci_95=CredibleInterval(
                lower=float(np.quantile(Delta_s, 0.025)),
                upper=float(np.quantile(Delta_s, 0.975)),
            ),
            **{"P(A > B)": float((Delta_s > 0).mean())},
            theta_A_mean=float(pA_s.mean()),
            theta_B_mean=float(pB_s.mean()),
            delta_A_posterior_mean=float(delta_A_s.mean()),
        )

        # MCMC diagnostics
        diag = self.mcmc_diagnostics()

        self.trace_summary = pd.DataFrame(
            {
                "mean": [delta_A_s.mean(), mu_s.mean()],
                "sd": [delta_A_s.std(), mu_s.std()],
                "hdi_3%": [
                    np.quantile(delta_A_s, 0.03),
                    np.quantile(mu_s, 0.03),
                ],
                "hdi_97%": [
                    np.quantile(delta_A_s, 0.97),
                    np.quantile(mu_s, 0.97),
                ],
                "R-hat": [diag.delta_A.r_hat, diag.mu.r_hat],
                "ESS": [diag.delta_A.ess, diag.mu.ess],
            },
            index=["delta_A", "mu"],
        )

        return self

    def _check_fitted(self) -> None:
        """Raise RuntimeError if the model has not been fitted yet."""
        if self.samples is None:
            raise RuntimeError("Model has not been fitted yet. Call .fit() first.")

    # ------------------------------------------------------------------ #
    #  MCMC diagnostics
    # ------------------------------------------------------------------ #

    @staticmethod
    def _r_hat(chains: np.ndarray) -> float:
        """Gelman-Rubin R-hat for a single parameter.

        Args:
            chains: ``(n_chains, n_samples)`` array for one parameter.
        """
        m, n = chains.shape
        chain_means = chains.mean(axis=1)
        grand_mean = chain_means.mean()
        B = n / (m - 1) * np.sum((chain_means - grand_mean) ** 2)
        W = np.mean(chains.var(axis=1, ddof=1))
        var_hat = (n - 1) / n * W + B / n
        return float(np.sqrt(var_hat / W)) if W > 0 else float("nan")

    @staticmethod
    def _ess(chains: np.ndarray) -> float:
        """Effective sample size (FFT-based autocorrelation estimate).

        Args:
            chains: ``(n_chains, n_samples)`` array for one parameter.
        """
        m, n = chains.shape
        total = 0.0
        for chain in chains:
            x = chain - chain.mean()
            # FFT-based autocorrelation
            f = np.fft.fft(x, n=2 * n)
            acf = np.fft.ifft(f * np.conj(f)).real[:n]
            acf /= acf[0]
            # Sum pairs until negative
            for t in range(1, n - 1, 2):
                rho_pair = acf[t] + (acf[t + 1] if t + 1 < n else 0.0)
                if rho_pair < 0:
                    break
                total += rho_pair
            total += 1.0  # for lag 0
        avg_tau = total / m
        return float(m * n / (2 * avg_tau - 1)) if avg_tau > 0.5 else float(m * n)

    def mcmc_diagnostics(self) -> MCMCDiagnostics:
        """Compute R-hat and ESS for each parameter.

        Returns:
            :class:`MCMCDiagnostics` with R-hat and ESS per parameter.
        """
        self._check_fitted()
        param_names = ["mu", "delta_A"]
        param_diags: dict[str, MCMCParamDiagnostic] = {}
        for i, name in enumerate(param_names):
            param_chains = self.chains[:, :, i]
            param_diags[name] = MCMCParamDiagnostic(
                r_hat=self._r_hat(param_chains),
                ess=self._ess(param_chains),
            )
        return MCMCDiagnostics(**param_diags)

    # ------------------------------------------------------------------ #
    #  Hypothesis testing
    # ------------------------------------------------------------------ #

    def savage_dickey_test(self, null_value: float = 0.0) -> SavageDickeyResult:
        """Savage-Dickey density-ratio Bayes factor for H0: delta_A = *null_value*.

        In the fixed-prior case the prior on δ_A is ``N(0, σ_δ)``.
        In the hierarchical case the marginal prior on δ_A (integrating
        out σ²_δ) is a Student-*t* with ``ν = 2a_δ`` d.f. and scale
        ``√(b_δ / a_δ)``.

        Args:
            null_value: The point null hypothesis value for delta_A.

        Returns:
            Dict with keys ``BF_01``, ``BF_10``, ``posterior_density_at_0``,
            ``prior_density_at_0``, ``interpretation``, and ``decision``.
        """
        self._check_fitted()

        kde = gaussian_kde(self.delta_A_samples)
        posterior_at_null = float(kde(null_value)[0])

        if self.hyperprior_delta is not None:
            a_d, b_d = self.hyperprior_delta
            nu = 2.0 * a_d
            scale = np.sqrt(b_d / a_d)
            prior_at_null = float(student_t.pdf(null_value, df=nu, loc=0, scale=scale))
        else:
            prior_at_null = float(norm.pdf(null_value, 0, self.prior_sigma_delta))

        BF_01 = posterior_at_null / prior_at_null
        BF_10 = 1.0 / BF_01 if BF_01 > 0 else float("inf")

        if BF_10 > 100:
            interpretation = "Decisive evidence against H0"
        elif BF_10 > 30:
            interpretation = "Very strong evidence against H0"
        elif BF_10 > 10:
            interpretation = "Strong evidence against H0"
        elif BF_10 > 3:
            interpretation = "Moderate evidence against H0"
        elif BF_10 > 1:
            interpretation = "Anecdotal evidence against H0"
        elif BF_10 == 1:
            interpretation = "No evidence either way"
        elif BF_01 > 100:
            interpretation = "Decisive evidence for H0"
        elif BF_01 > 30:
            interpretation = "Very strong evidence for H0"
        elif BF_01 > 10:
            interpretation = "Strong evidence for H0"
        elif BF_01 > 3:
            interpretation = "Moderate evidence for H0"
        else:
            interpretation = "Anecdotal evidence for H0"

        decision = "Reject H0" if BF_10 > 3 else "Fail to reject H0"

        return SavageDickeyResult(
            BF_01=BF_01,
            BF_10=BF_10,
            posterior_density_at_0=posterior_at_null,
            prior_density_at_0=prior_at_null,
            interpretation=interpretation,
            decision=decision,
        )

    @staticmethod
    def posterior_probability_H0(
        BF_01: float, prior_H0: float = 0.5
    ) -> PosteriorProbH0Result:
        """Convert BF_01 to posterior probability of H0 (spike-and-slab).

        Args:
            BF_01: Bayes factor in favour of H0.
            prior_H0: Prior probability of H0 (default 0.5).

        Returns:
            Dict with keys ``P(H0|data)``, ``P(H1|data)``,
            ``prior_odds``, and ``posterior_odds``.
        """
        prior_odds = prior_H0 / (1 - prior_H0)
        posterior_odds = BF_01 * prior_odds
        P_H0 = posterior_odds / (1 + posterior_odds)
        P_H1 = 1 - P_H0

        if P_H1 > 0.95:
            decision = "Reject H0"
        elif P_H0 > 0.95:
            decision = "Fail to reject H0"
        else:
            decision = "Undecided"

        return PosteriorProbH0Result(
            **{"P(H0|data)": P_H0, "P(H1|data)": P_H1},
            prior_odds=prior_odds,
            posterior_odds=posterior_odds,
            decision=decision,
        )

    # ------------------------------------------------------------------ #
    #  ROPE analysis
    # ------------------------------------------------------------------ #

    def rope_test(
        self,
        rope: tuple[float, float] | None = None,
        ci_mass: float = 0.95,
    ) -> ROPEResult:
        """ROPE analysis on the posterior of Δ = p_A − p_B (probability scale).

        Args:
            rope: (lower, upper) ROPE bounds. Defaults to
                ``(-self.rope_epsilon, +self.rope_epsilon)``.
            ci_mass: Credible interval mass (default 95%).

        Returns:
            :class:`ROPEResult` with CI, ROPE overlap fractions, and
            decision.
        """
        self._check_fitted()
        if rope is None:
            rope = (-self.rope_epsilon, self.rope_epsilon)
        return ROPEResult.from_samples(self.delta_samples, rope=rope, ci_mass=ci_mass)

    # ------------------------------------------------------------------ #
    #  Composite decision
    # ------------------------------------------------------------------ #

    def decide(self, rule: DecisionRuleType | None = None) -> HypothesisDecision:
        """Run the chosen decision framework(s) and return a composite result.

        Args:
            rule: Override the default ``decision_rule``. One of
                ``"bayes_factor"``, ``"posterior_null"``, ``"rope"``,
                or ``"all"``.

        Returns:
            :class:`HypothesisDecision` with the requested sub-results
            populated.
        """
        self._check_fitted()
        rule = rule or self.decision_rule

        bf: SavageDickeyResult | None = None
        pn: PosteriorProbH0Result | None = None
        rp: ROPEResult | None = None

        if rule in ("bayes_factor", "posterior_null", "all"):
            bf = self.savage_dickey_test()
        if rule in ("posterior_null", "all"):
            assert bf is not None  # noqa: S101
            pn = self.posterior_probability_H0(bf.BF_01)
        if rule in ("rope", "all"):
            rp = self.rope_test()

        return HypothesisDecision(
            bayes_factor=bf, posterior_null=pn, rope=rp, rule=rule
        )

    # ------------------------------------------------------------------ #
    #  Diagnostics
    # ------------------------------------------------------------------ #

    def ppc_pvalues(self, seed: int | None = None) -> dict[str, PPCStatistic]:
        """Posterior predictive p-values for summary statistics.

        Returns:
            Dict mapping statistic name to ``{observed, p_value, status}``.
        """
        self._check_fitted()

        rng = np.random.default_rng(seed if seed is not None else self.seed)

        mu_s = self.samples[:, 0]
        delta_s = self.samples[:, 1]
        n = len(self.y_A_obs)

        p_A_s = sigmoid(mu_s + delta_s)
        p_B_s = sigmoid(mu_s)
        y_A_rep = (rng.random((len(p_A_s), n)) < p_A_s[:, None]).astype(int)
        y_B_rep = (rng.random((len(p_B_s), n)) < p_B_s[:, None]).astype(int)

        checks = {
            "mean(y_A)": (self.y_A_obs.mean(), y_A_rep.mean(axis=1)),
            "mean(y_B)": (self.y_B_obs.mean(), y_B_rep.mean(axis=1)),
            "mean(y_A-y_B)": (
                (self.y_A_obs - self.y_B_obs).mean(),
                (y_A_rep - y_B_rep).mean(axis=1),
            ),
            "std(y_A-y_B)": (
                (self.y_A_obs - self.y_B_obs).std(),
                (y_A_rep - y_B_rep).std(axis=1),
            ),
            "n_disagree": (
                float(np.sum(self.y_A_obs != self.y_B_obs)),
                np.sum(y_A_rep != y_B_rep, axis=1).astype(float),
            ),
        }

        results: dict[str, PPCStatistic] = {}
        for stat_name, (obs_val, rep_vals) in checks.items():
            p_val = min(
                2
                * min(
                    float((rep_vals >= obs_val).mean()),
                    float((rep_vals <= obs_val).mean()),
                ),
                1.0,
            )
            results[stat_name] = PPCStatistic(
                observed=float(obs_val),
                p_value=p_val,
                status="OK" if p_val > 0.05 else "WARN",
            )
        return results

    # ------------------------------------------------------------------ #
    #  Plotting
    # ------------------------------------------------------------------ #

    def plot_trace(self, **kwargs) -> None:
        """Trace plots and autocorrelation for all chains.

        In hierarchical mode, additional rows are shown for the learned
        prior standard deviations σ_μ and σ_δ (plotted on the σ scale,
        not σ²).
        """
        import matplotlib.pyplot as plt

        self._check_fitted()
        hierarchical = self.hyperprior_mu is not None

        # Build list of (name, per-chain array of shape (n_chains, n_samples)).
        panels: list[tuple[str, np.ndarray]] = [
            ("\u03bc", self.chains[:, :, 0]),
            ("\u03b4_A", self.chains[:, :, 1]),
        ]
        if hierarchical:
            # Show on the σ (std-dev) scale for readability.
            panels.append(("\u03c3_\u03bc", np.sqrt(self._variance_chains_mu)))
            panels.append(("\u03c3_\u03b4", np.sqrt(self._variance_chains_delta)))

        n_rows = len(panels)
        figsize = kwargs.pop("figsize", (14, 4 * n_rows))
        fig, axes = plt.subplots(n_rows, 2, figsize=figsize)
        if n_rows == 1:
            axes = axes[np.newaxis, :]  # ensure 2-D

        max_lag = min(100, self.chains.shape[1] // 2)

        for row, (name, chain_data) in enumerate(panels):
            # Trace plot
            ax = axes[row, 0]
            for c in range(self.n_chains):
                ax.plot(
                    chain_data[c],
                    alpha=0.6,
                    linewidth=0.5,
                    label=f"Chain {c + 1}",
                )
            ax.set_xlabel("Iteration (post burn-in)")
            ax.set_ylabel(name)
            ax.set_title(f"Trace: {name}", fontweight="bold")
            ax.legend(fontsize=7, loc="upper right")
            ax.grid(alpha=0.3)

            # ACF
            ax2 = axes[row, 1]
            for c in range(self.n_chains):
                x = chain_data[c]
                x = x - x.mean()
                acf_full = np.correlate(x, x, mode="full")
                acf_full = acf_full[len(x) - 1 :]
                acf_full /= acf_full[0]
                ax2.plot(acf_full[:max_lag], alpha=0.6, linewidth=0.8)
            ax2.axhline(0, color="gray", linestyle="--", alpha=0.5)
            ax2.set_xlabel("Lag")
            ax2.set_ylabel("ACF")
            ax2.set_title(f"Autocorrelation: {name}", fontweight="bold")
            ax2.grid(alpha=0.3)

        fig.suptitle(
            kwargs.pop("title", "MCMC Diagnostics (PG Gibbs)"),
            fontsize=13,
            fontweight="bold",
            y=1.02,
        )
        plt.tight_layout()
        plt.show()

    def plot_posteriors(self, **kwargs: Any) -> None:
        """Overlaid KDE posteriors of θ_A and θ_B (probability scale).

        The implied success probabilities ``θ_A = σ(μ + δ_A)`` and
        ``θ_B = σ(μ)`` are computed from the pooled MCMC posterior
        samples and displayed as overlaid KDE densities.

        Args:
            **kwargs: Accepts ``figsize`` (default ``(7, 5)``) and
                ``title`` (default ``"Posterior: θ_A and θ_B"``).
        """
        import matplotlib.pyplot as plt

        self._check_fitted()

        mu_s = self.samples[:, 0]
        delta_A_s = self.samples[:, 1]
        p_A_s = sigmoid(mu_s + delta_A_s)
        p_B_s = sigmoid(mu_s)

        figsize = kwargs.pop("figsize", (7, 5))
        fig, ax = plt.subplots(figsize=figsize)

        kde_A = gaussian_kde(p_A_s)
        kde_B = gaussian_kde(p_B_s)
        lo = min(p_A_s.min(), p_B_s.min())
        hi = max(p_A_s.max(), p_B_s.max())
        x = np.linspace(max(0, lo - 0.05), min(1, hi + 0.05), 500)

        pdf_A = kde_A(x)
        pdf_B = kde_B(x)
        ax.plot(
            x,
            pdf_A,
            color="#2196F3",
            linewidth=2,
            label=f"θ_A  mean={p_A_s.mean():.3f}",
        )
        ax.fill_between(x, pdf_A, alpha=0.15, color="#2196F3")
        ax.plot(
            x,
            pdf_B,
            color="#4CAF50",
            linewidth=2,
            label=f"θ_B  mean={p_B_s.mean():.3f}",
        )
        ax.fill_between(x, pdf_B, alpha=0.15, color="#4CAF50")

        ax.axvline(
            p_A_s.mean(), color="#2196F3", linestyle="--", linewidth=1, alpha=0.6
        )
        ax.axvline(
            p_B_s.mean(), color="#4CAF50", linestyle="--", linewidth=1, alpha=0.6
        )
        ax.set_xlabel("Success probability")
        ax.set_ylabel("Density")
        ax.set_title(
            kwargs.pop("title", "Posterior: θ_A and θ_B"),
            fontsize=12,
            fontweight="bold",
        )
        ax.legend(fontsize=9)
        ax.grid(alpha=0.3)
        plt.tight_layout()
        plt.show()

    def plot_posterior_delta(self, color: str = "#9C27B0", **kwargs: Any) -> None:
        """KDE posterior density of Δ = θ_A − θ_B (probability scale) with 95% CI.

        Args:
            color: Colour for the density curve and fill.
            **kwargs: Accepts ``figsize`` (default ``(7, 5)``),
                ``title`` (default ``"Posterior: Δ = θ_A − θ_B"``),
                ``xlabel``, ``ylabel``.
        """
        import matplotlib.pyplot as plt

        self._check_fitted()

        mu_s = self.samples[:, 0]
        delta_A_s = self.samples[:, 1]
        p_A_s = sigmoid(mu_s + delta_A_s)
        p_B_s = sigmoid(mu_s)
        Delta_s = p_A_s - p_B_s

        ci_low, ci_high = np.quantile(Delta_s, [0.025, 0.975])
        mean_val = float(Delta_s.mean())

        kde = gaussian_kde(Delta_s)
        x_grid = np.linspace(Delta_s.min() - 0.05, Delta_s.max() + 0.05, 500)
        density = kde(x_grid)

        figsize = kwargs.pop("figsize", (7, 5))
        fig, ax = plt.subplots(figsize=figsize)
        ax.plot(x_grid, density, color=color, linewidth=2)
        ax.fill_between(x_grid, density, alpha=0.15, color=color)
        mask = (x_grid >= ci_low) & (x_grid <= ci_high)
        ax.fill_between(
            x_grid[mask], density[mask], alpha=0.35, color=color, label="95% CI"
        )
        ax.axvline(
            mean_val,
            color=color,
            linestyle="-",
            linewidth=1.5,
            alpha=0.8,
            label=f"Mean = {mean_val:.4f}",
        )
        ax.axvline(
            0,
            color="gray",
            linestyle="--",
            linewidth=1,
            alpha=0.6,
            label="Δ = 0 (no difference)",
        )
        ax.set_xlabel(kwargs.pop("xlabel", "Δ = θ_A − θ_B"), fontsize=11)
        ax.set_ylabel(kwargs.pop("ylabel", "Density"), fontsize=11)
        ax.set_title(
            kwargs.pop("title", "Posterior: Δ = θ_A − θ_B"),
            fontsize=12,
            fontweight="bold",
        )
        ax.legend(fontsize=9, loc="upper right")
        ax.grid(axis="y", alpha=0.3)
        plt.tight_layout()
        plt.show()

    def plot_savage_dickey(self, color: str = "#2196F3", **kwargs) -> None:
        """Posterior vs prior density with Savage-Dickey BF annotation."""
        import matplotlib.pyplot as plt

        bf = self.savage_dickey_test()
        samples = self.delta_A_samples

        kde = gaussian_kde(samples)
        x_grid = np.linspace(samples.min() - 0.5, samples.max() + 0.5, 500)
        density = kde(x_grid)
        prior_density = norm.pdf(x_grid, 0, self.prior_sigma_delta)

        figsize = kwargs.pop("figsize", (7, 5))
        fig, ax = plt.subplots(figsize=figsize)
        ax.plot(x_grid, density, color=color, linewidth=2, label="Posterior")
        ax.fill_between(x_grid, density, alpha=0.15, color=color)
        ax.plot(
            x_grid,
            prior_density,
            color="gray",
            linewidth=1.5,
            linestyle="--",
            alpha=0.7,
            label=f"Prior N(0,{self.prior_sigma_delta})",
        )
        ax.plot(
            0,
            bf.posterior_density_at_0,
            "o",
            color="red",
            markersize=10,
            zorder=5,
            label=f"Post. at \u03b4=0: {bf.posterior_density_at_0:.2e}",
        )
        ax.plot(
            0,
            bf.prior_density_at_0,
            "s",
            color="gray",
            markersize=8,
            zorder=5,
            label=f"Prior at \u03b4=0: {bf.prior_density_at_0:.3f}",
        )

        bf10_label = _format_bf(bf.BF_10)
        log10_bf = np.log10(bf.BF_10)
        ax.text(
            0.02,
            0.97,
            f"$BF_{{10}}$ = {bf10_label}\n$\\log_{{10}}BF_{{10}}$ = {log10_bf:.1f}\n{bf.decision}",
            fontsize=10,
            fontweight="bold",
            color="darkred",
            transform=ax.transAxes,
            verticalalignment="top",
            bbox=dict(
                boxstyle="round,pad=0.3",
                facecolor="lightyellow",
                edgecolor="darkred",
                alpha=0.9,
            ),
        )
        ax.set_xlabel(kwargs.pop("xlabel", "\u03b4_A (logit scale)"), fontsize=11)
        ax.set_ylabel(kwargs.pop("ylabel", "Density"), fontsize=11)
        ax.set_title(
            kwargs.pop("title", "Savage-Dickey Test (PG Gibbs)"),
            fontsize=12,
            fontweight="bold",
        )
        ax.legend(fontsize=9, loc="upper right")
        ax.grid(axis="y", alpha=0.3)
        plt.tight_layout()
        plt.show()

    def plot_ppc(self, seed: int | None = None, **kwargs) -> None:
        """Three-column PPC plot: P(perfect) A, P(perfect) B, rate difference."""
        import matplotlib.pyplot as plt

        self._check_fitted()
        rng = np.random.default_rng(seed if seed is not None else self.seed)

        mu_s = self.samples[:, 0]
        delta_s = self.samples[:, 1]
        n = len(self.y_A_obs)

        p_A_s = sigmoid(mu_s + delta_s)
        p_B_s = sigmoid(mu_s)
        y_A_rep = (rng.random((len(p_A_s), n)) < p_A_s[:, None]).astype(int)
        y_B_rep = (rng.random((len(p_B_s), n)) < p_B_s[:, None]).astype(int)

        figsize = kwargs.pop("figsize", (18, 5))
        fig, axes = plt.subplots(1, 3, figsize=figsize)

        frac_A_rep = y_A_rep.mean(axis=1)
        frac_A_obs = self.y_A_obs.mean()
        ax = axes[0]
        ax.hist(
            frac_A_rep,
            bins=40,
            density=True,
            color="#2196F3",
            alpha=0.6,
            edgecolor="white",
            label="Replicated",
        )
        ax.axvline(
            frac_A_obs,
            color="#E53935",
            linewidth=2.5,
            label=f"Observed = {frac_A_obs:.3f}",
            zorder=10,
        )
        ax.set_xlabel("Fraction perfect (y=1)")
        ax.set_ylabel("Density")
        ax.set_title("PPC: P(perfect) Group A", fontsize=11, fontweight="bold")
        ax.legend(fontsize=9)
        ax.grid(alpha=0.3)

        frac_B_rep = y_B_rep.mean(axis=1)
        frac_B_obs = self.y_B_obs.mean()
        ax = axes[1]
        ax.hist(
            frac_B_rep,
            bins=40,
            density=True,
            color="#4CAF50",
            alpha=0.6,
            edgecolor="white",
            label="Replicated",
        )
        ax.axvline(
            frac_B_obs,
            color="#E53935",
            linewidth=2.5,
            label=f"Observed = {frac_B_obs:.3f}",
            zorder=10,
        )
        ax.set_xlabel("Fraction perfect (y=1)")
        ax.set_ylabel("Density")
        ax.set_title("PPC: P(perfect) Group B", fontsize=11, fontweight="bold")
        ax.legend(fontsize=9)
        ax.grid(alpha=0.3)

        diff_rep = frac_A_rep - frac_B_rep
        diff_obs = frac_A_obs - frac_B_obs
        ax = axes[2]
        ax.hist(
            diff_rep,
            bins=40,
            density=True,
            color="#9C27B0",
            alpha=0.6,
            edgecolor="white",
            label="Replicated",
        )
        ax.axvline(
            diff_obs,
            color="#E53935",
            linewidth=2.5,
            label=f"Observed = {diff_obs:.3f}",
            zorder=10,
        )
        ax.axvline(0, color="gray", linestyle="--", linewidth=1, alpha=0.6)
        ax.set_xlabel("P(perfect)_A \u2212 P(perfect)_B")
        ax.set_ylabel("Density")
        ax.set_title(
            "PPC: Rate Difference (A \u2212 B)", fontsize=11, fontweight="bold"
        )
        ax.legend(fontsize=9)
        ax.grid(alpha=0.3)

        fig.suptitle(
            kwargs.pop("title", "Posterior Predictive Checks (PG Gibbs)"),
            fontsize=14,
            fontweight="bold",
            y=1.02,
        )
        plt.tight_layout()
        plt.show()

    # ------------------------------------------------------------------ #
    #  Summary / reporting
    # ------------------------------------------------------------------ #

    def print_summary(self) -> None:
        """Print posterior summary, MCMC diagnostics, Savage-Dickey test, and PPC."""
        self._check_fitted()

        s = self.summary
        diag = self.mcmc_diagnostics()
        n_A, n_B = len(self.y_A_obs), len(self.y_B_obs)
        k_A, k_B = int(self.y_A_obs.sum()), int(self.y_B_obs.sum())
        verdict = (
            "A wins"
            if s.p_A_greater_B > 0.95
            else ("Tied" if s.p_A_greater_B > 0.5 else "B wins")
        )

        print("PG Gibbs posterior summary (Paired)")
        print("=" * 60)
        print(f"  \u03b8_A  mean={s.theta_A_mean:.4f}  " f"[n_A={n_A}, k_A={k_A}]")
        print(f"  \u03b8_B  mean={s.theta_B_mean:.4f}  " f"[n_B={n_B}, k_B={k_B}]")
        print(f"  Mean \u0394 (\u03b8_A \u2212 \u03b8_B):  {s.mean_delta:.4f}")
        print(f"  95% CI:              [{s.ci_95.lower:.4f}, {s.ci_95.upper:.4f}]")
        print(f"  P(A > B):            {s.p_A_greater_B:.4f}")
        print(f"  Verdict:             {verdict}")

        if self.hyperprior_mu is not None:
            assert self.sigma_sq_mu_samples is not None  # noqa: S101
            assert self.sigma_sq_delta_samples is not None  # noqa: S101
            print()
            print("Learned prior scales (hierarchical)")
            print("=" * 60)
            sig_mu = np.sqrt(self.sigma_sq_mu_samples)
            sig_delta = np.sqrt(self.sigma_sq_delta_samples)
            print(
                f"  σ_μ   posterior mean={sig_mu.mean():.4f}  "
                f"95% CI=[{np.quantile(sig_mu, 0.025):.4f}, "
                f"{np.quantile(sig_mu, 0.975):.4f}]"
            )
            print(
                f"  σ_δ   posterior mean={sig_delta.mean():.4f}  "
                f"95% CI=[{np.quantile(sig_delta, 0.025):.4f}, "
                f"{np.quantile(sig_delta, 0.975):.4f}]"
            )

        print()
        print("MCMC diagnostics")
        print("=" * 60)
        print(
            f"  Chains: {self.n_chains}, Iterations: {self.n_iter}, Burn-in: {self.burn_in}"
        )
        print(f"  Total post-warmup samples: {len(self.delta_A_samples)}")
        for name, d in diag.model_dump().items():
            r_hat = d["r_hat"]
            ess = d["ess"]
            status = "OK" if 0.99 <= r_hat <= 1.05 else "WARN"
            print(f"  {name}: R-hat={r_hat:.4f}, ESS={ess:.0f}  {status}")

        bf = self.savage_dickey_test()
        print()
        print("Savage-Dickey Bayes Factor: H0 (\u0394 = 0) vs H1 (\u0394 \u2260 0)")
        print("=" * 60)
        print(f"  Prior  density at \u03b4=0: {bf.prior_density_at_0:.6f}")
        print(f"  Post.  density at \u03b4=0: {bf.posterior_density_at_0:.2e}")
        print(f"  BF_01 (for H0):        {_format_bf(bf.BF_01)}")
        print(f"  BF_10 (against H0):    {_format_bf(bf.BF_10)}")
        print(f"  log\u2081\u2080(BF_10):          {np.log10(bf.BF_10):.1f}")
        print(f"  \u2192 {bf.interpretation}")
        print(f"  \u2192 Decision: {bf.decision}")

        post = self.posterior_probability_H0(bf.BF_01)
        print()
        print("Posterior model probabilities (prior P(H0) = 0.5)")
        print("=" * 60)
        print(f"  P(H0|data): {post.p_H0:.2e}")
        print(f"  P(H1|data): {post.p_H1:.6f}")

        ppc = self.ppc_pvalues()
        print()
        print("Posterior Predictive p-values")
        print("=" * 60)
        print(f"  {'Statistic':<20} {'Observed':>10} {'p-value':>10} {'Status':>8}")
        print("  " + "-" * 50)
        for stat, vals in ppc.items():
            print(
                f"  {stat:<20} {vals.observed:>10.4f} {vals.p_value:>10.3f} {vals.status:>8}"
            )

        print()
        print("Trace summary")
        print("=" * 60)
        print(self.trace_summary.to_string())

    # ------------------------------------------------------------------ #
    #  Multi-model comparison
    # ------------------------------------------------------------------ #

    @staticmethod
    def plot_forest(
        results: dict[str, "PairedBayesPropTestPG"],
        label_A: str = "Group A",
        label_B: str = "Group B",
        **kwargs,
    ) -> None:
        """Forest plot + P(A>B) bar chart for multiple metrics."""
        import matplotlib.patches as mpatches
        import matplotlib.pyplot as plt

        metrics = list(results.keys())
        means = [results[m].summary.mean_delta for m in metrics]
        ci_lows = [results[m].summary.ci_95.lower for m in metrics]
        ci_highs = [results[m].summary.ci_95.upper for m in metrics]
        probs = [results[m].summary.p_A_greater_B for m in metrics]

        colors = [
            "#2196F3" if p > 0.95 else "#FF9800" if p > 0.5 else "#F44336"
            for p in probs
        ]
        y_pos = np.arange(len(metrics))

        figsize = kwargs.pop("figsize", (14, max(4, 2 * len(metrics))))
        fig, axes = plt.subplots(1, 2, figsize=figsize)

        ax = axes[0]
        for i, (m, ci_l, ci_h, col) in enumerate(
            zip(means, ci_lows, ci_highs, colors, strict=False)
        ):
            ax.plot(
                [ci_l, ci_h],
                [i, i],
                color=col,
                linewidth=2.5,
                solid_capstyle="round",
            )
            ax.plot(m, i, "o", color=col, markersize=8, zorder=5)
        ax.axvline(0, color="gray", linestyle="--", linewidth=1, alpha=0.7)
        ax.set_yticks(y_pos)
        ax.set_yticklabels(metrics, fontsize=11)
        ax.set_xlabel(
            f"Mean \u0394 P(perfect)\n\u2190 {label_B} better | {label_A} better \u2192"
        )
        ax.set_title("Posterior Mean Difference with 95% CI", fontweight="bold")
        ax.invert_yaxis()
        ax.grid(axis="x", alpha=0.3)

        ax2 = axes[1]
        ax2.barh(y_pos, probs, color=colors, height=0.5, alpha=0.85)
        ax2.axvline(0.5, color="gray", linestyle="--", linewidth=1, alpha=0.7)
        ax2.set_yticks(y_pos)
        ax2.set_yticklabels(metrics, fontsize=11)
        ax2.set_xlabel(f"P({label_A} > {label_B})")
        ax2.set_title("Posterior Probability of Superiority", fontweight="bold")
        ax2.set_xlim(0, 1.05)
        ax2.invert_yaxis()
        ax2.grid(axis="x", alpha=0.3)
        for i, p in enumerate(probs):
            ax2.text(
                p + 0.02, i, f"{p:.2f}", va="center", fontsize=10, fontweight="bold"
            )

        legend_elements = [
            mpatches.Patch(color="#2196F3", label="Strong (P > 0.95)"),
            mpatches.Patch(color="#FF9800", label="Moderate (0.5 < P \u2264 0.95)"),
            mpatches.Patch(color="#F44336", label="Reversed (P \u2264 0.5)"),
        ]
        fig.legend(
            handles=legend_elements,
            loc="lower center",
            ncol=3,
            fontsize=9,
            bbox_to_anchor=(0.5, -0.02),
        )
        fig.suptitle(
            kwargs.pop(
                "title",
                f"{label_A} vs {label_B} \u2014 PG Gibbs Comparison",
            ),
            fontsize=14,
            fontweight="bold",
            y=1.02,
        )
        plt.tight_layout()
        plt.show()

    @staticmethod
    def print_comparison_table(
        results: dict[str, "PairedBayesPropTestPG"],
    ) -> None:
        """Print a formatted comparison table across metrics."""
        print("=" * 80)
        print(
            f"{'Metric':<25} {'Mean \u0394':>8} {'95% CI':>20} {'P(A>B)':>8} {'Verdict':>12}"
        )
        print("=" * 80)
        for m, model in results.items():
            s = model.summary
            verdict = (
                "A wins"
                if s.p_A_greater_B > 0.95
                else ("Tied" if s.p_A_greater_B > 0.5 else "B wins")
            )
            print(
                f"{m:<25} {s.mean_delta:>8.4f} "
                f"[{s.ci_95.lower:>7.4f}, {s.ci_95.upper:>7.4f}] "
                f"{s.p_A_greater_B:>8.4f} {verdict:>12}"
            )
        print("=" * 80)
