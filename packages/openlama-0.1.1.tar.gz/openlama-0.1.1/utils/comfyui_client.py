"""ComfyUI API client – health check, prompt submission, image upload, result polling."""

from __future__ import annotations

import asyncio
import json
import random
import uuid
from pathlib import Path
from typing import Optional

import httpx

from config import COMFY_BASE, COMFY_OUTPUT_DIR, COMFY_TIMEOUT_SEC


async def comfyui_alive() -> bool:
    """Check if ComfyUI backend is running."""
    try:
        async with httpx.AsyncClient(timeout=5) as client:
            r = await client.get(f"{COMFY_BASE}/system_stats")
            return r.status_code == 200
    except Exception:
        return False


async def submit_prompt(prompt_graph: dict, workflow_id: str = "") -> str:
    """Submit a workflow prompt to ComfyUI. Returns prompt_id."""
    payload = {
        "prompt": prompt_graph,
        "client_id": str(uuid.uuid4()),
    }
    if workflow_id:
        payload["extra_data"] = {"workflow_id": workflow_id}

    async with httpx.AsyncClient(timeout=30) as client:
        r = await client.post(f"{COMFY_BASE}/prompt", json=payload)
        r.raise_for_status()
        data = r.json()

    prompt_id = data.get("prompt_id")
    if not prompt_id:
        raise RuntimeError(f"ComfyUI did not return prompt_id: {data}")
    return prompt_id


async def poll_result(prompt_id: str, timeout: int = COMFY_TIMEOUT_SEC) -> dict:
    """Poll ComfyUI history until the prompt completes. Returns output dict."""
    deadline = asyncio.get_event_loop().time() + timeout

    async with httpx.AsyncClient(timeout=10) as client:
        while asyncio.get_event_loop().time() < deadline:
            try:
                r = await client.get(f"{COMFY_BASE}/history/{prompt_id}")
                r.raise_for_status()
                data = r.json()

                entry = data.get(prompt_id)
                if entry:
                    status = entry.get("status", {})
                    if status.get("completed") or status.get("status_str") == "success":
                        return entry
                    # Check for error
                    if status.get("status_str") == "error":
                        msgs = status.get("messages", [])
                        raise RuntimeError(f"ComfyUI execution error: {msgs}")
                    # Also check if outputs exist (some versions don't set status)
                    outputs = entry.get("outputs", {})
                    if outputs:
                        return entry
            except httpx.HTTPError:
                pass

            await asyncio.sleep(1.5)

    raise TimeoutError(f"ComfyUI prompt {prompt_id} timed out after {timeout}s")


def extract_image_paths(result: dict) -> list[str]:
    """Extract output image file paths from ComfyUI result."""
    paths = []
    outputs = result.get("outputs", {})
    for node_id, node_out in outputs.items():
        images = node_out.get("images", [])
        for img in images:
            filename = img.get("filename", "")
            subfolder = img.get("subfolder", "")
            if filename:
                if subfolder:
                    full_path = Path(COMFY_OUTPUT_DIR) / subfolder / filename
                else:
                    full_path = Path(COMFY_OUTPUT_DIR) / filename
                if full_path.exists():
                    paths.append(str(full_path))
    return paths


async def upload_image(image_path: str, name: Optional[str] = None) -> str:
    """Upload an image to ComfyUI input directory. Returns the uploaded filename."""
    p = Path(image_path)
    if not p.exists():
        raise FileNotFoundError(f"Image not found: {image_path}")

    upload_name = name or p.name
    file_bytes = p.read_bytes()

    # ComfyUI expects multipart form data
    async with httpx.AsyncClient(timeout=30) as client:
        files = {"image": (upload_name, file_bytes, "image/png")}
        data = {"type": "input", "overwrite": "true"}
        r = await client.post(f"{COMFY_BASE}/upload/image", files=files, data=data)
        r.raise_for_status()
        resp = r.json()

    returned_name = resp.get("name")
    if not returned_name:
        raise RuntimeError(f"ComfyUI upload did not return name: {resp}")
    return returned_name


def build_txt2img_workflow(
    prompt: str,
    width: int = 1024,
    height: int = 1024,
    steps: int = 4,
    cfg: float = 1.0,
    denoise: float = 1.0,
    seed: Optional[int] = None,
) -> dict:
    """Build a text-to-image workflow graph for ComfyUI."""
    if seed is None:
        seed = random.randint(1, 2**31)

    return {
        "30": {
            "class_type": "CLIPLoader",
            "inputs": {
                "clip_name": "qwen_3_4b.safetensors",
                "type": "lumina2",
                "device": "default",
            },
        },
        "29": {
            "class_type": "VAELoader",
            "inputs": {"vae_name": "ae.safetensors"},
        },
        "28": {
            "class_type": "UNETLoader",
            "inputs": {
                "unet_name": "z_image_turbo_bf16.safetensors",
                "weight_dtype": "default",
            },
        },
        "11": {
            "class_type": "ModelSamplingAuraFlow",
            "inputs": {"model": ["28", 0], "shift": 3},
        },
        "27": {
            "class_type": "CLIPTextEncode",
            "inputs": {"clip": ["30", 0], "text": prompt},
        },
        "33": {
            "class_type": "ConditioningZeroOut",
            "inputs": {"conditioning": ["27", 0]},
        },
        "13": {
            "class_type": "EmptySD3LatentImage",
            "inputs": {"width": width, "height": height, "batch_size": 1},
        },
        "3": {
            "class_type": "KSampler",
            "inputs": {
                "model": ["11", 0],
                "positive": ["27", 0],
                "negative": ["33", 0],
                "latent_image": ["13", 0],
                "seed": seed,
                "steps": steps,
                "cfg": cfg,
                "sampler_name": "res_multistep",
                "scheduler": "simple",
                "denoise": denoise,
            },
        },
        "8": {
            "class_type": "VAEDecode",
            "inputs": {"samples": ["3", 0], "vae": ["29", 0]},
        },
        "9": {
            "class_type": "SaveImage",
            "inputs": {"images": ["8", 0], "filename_prefix": "tg_gen"},
        },
    }


def build_img2img_workflow(
    uploaded_image_name: str,
    prompt: str,
    negative_prompt: str = "",
    steps: int = 4,
    cfg: float = 1.0,
    denoise: float = 1.0,
    seed: Optional[int] = None,
) -> dict:
    """Build an image-editing (img2img) workflow graph for ComfyUI."""
    if seed is None:
        seed = random.randint(1, 2**31)

    return {
        "1": {
            "class_type": "UnetLoaderGGUF",
            "inputs": {"unet_name": "Qwen-Image-Edit-2509-Q5_K_M.gguf"},
        },
        "2": {
            "class_type": "CLIPLoader",
            "inputs": {
                "clip_name": "qwen_2.5_vl_7b.safetensors",
                "type": "qwen_image",
                "device": "default",
            },
        },
        "3": {
            "class_type": "VAELoader",
            "inputs": {"vae_name": "qwen_image_vae.safetensors"},
        },
        "7": {
            "class_type": "LoraLoaderModelOnly",
            "inputs": {
                "model": ["1", 0],
                "lora_name": "Qwen-Image-Edit-2509-Lightning-4steps-V1.0-bf16.safetensors",
                "strength_model": 1.0,
            },
        },
        "4": {
            "class_type": "LoadImage",
            "inputs": {"image": uploaded_image_name},
        },
        "5": {
            "class_type": "ImageScaleToTotalPixels",
            "inputs": {
                "image": ["4", 0],
                "upscale_method": "lanczos",
                "megapixels": 1.28,
                "resolution_steps": 1,
            },
        },
        "6": {
            "class_type": "VAEEncode",
            "inputs": {"pixels": ["5", 0], "vae": ["3", 0]},
        },
        "10": {
            "class_type": "TextEncodeQwenImageEditPlus",
            "inputs": {
                "clip": ["2", 0],
                "vae": ["3", 0],
                "image1": ["4", 0],
                "prompt": prompt,
            },
        },
        "11": {
            "class_type": "TextEncodeQwenImageEditPlus",
            "inputs": {
                "clip": ["2", 0],
                "vae": ["3", 0],
                "image1": ["4", 0],
                "prompt": negative_prompt,
            },
        },
        "8": {
            "class_type": "ModelSamplingAuraFlow",
            "inputs": {"model": ["7", 0], "shift": 3.0},
        },
        "9": {
            "class_type": "CFGNorm",
            "inputs": {"model": ["8", 0], "strength": 1.0},
        },
        "12": {
            "class_type": "KSampler",
            "inputs": {
                "model": ["9", 0],
                "positive": ["10", 0],
                "negative": ["11", 0],
                "latent_image": ["6", 0],
                "seed": seed,
                "steps": steps,
                "cfg": cfg,
                "sampler_name": "euler",
                "scheduler": "simple",
                "denoise": denoise,
            },
        },
        "13": {
            "class_type": "VAEDecode",
            "inputs": {"samples": ["12", 0], "vae": ["3", 0]},
        },
        "14": {
            "class_type": "SaveImage",
            "inputs": {"images": ["13", 0], "filename_prefix": "tg_edit"},
        },
    }
