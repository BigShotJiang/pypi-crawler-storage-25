"""Admin handlers – /ollama server management."""

from __future__ import annotations

import json

from telegram import InlineKeyboardButton, InlineKeyboardMarkup, Update
from telegram.ext import ContextTypes

from auth import require_auth
from config import COMFY_BASE, OLLAMA_BASE
from ollama_client import (
    copy_model,
    ensure_ollama_running,
    get_model_capabilities,
    get_model_info,
    get_running_models,
    ollama_alive,
    pm2_restart_ollama,
)
from utils.comfyui_client import comfyui_alive


def ollama_menu_keyboard(show_install: bool = False) -> InlineKeyboardMarkup:
    rows = [
        [
            InlineKeyboardButton("📊 상태", callback_data="ollama:status"),
            InlineKeyboardButton("🖥 로드된 모델", callback_data="ollama:ps"),
        ],
        [
            InlineKeyboardButton("🔄 재시작", callback_data="ollama:restart"),
            InlineKeyboardButton("ℹ️ 모델 상세", callback_data="ollama:info_prompt"),
        ],
    ]
    if show_install:
        rows.append([InlineKeyboardButton("📥 Ollama 설치", callback_data="ollama:install")])
    rows.append([
        InlineKeyboardButton("📋 복사", callback_data="ollama:copy_prompt"),
        InlineKeyboardButton("🏠 메뉴", callback_data="cmd:menu"),
    ])
    return InlineKeyboardMarkup(rows)


async def ollama_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = await require_auth(update)
    if not user:
        return

    if not context.args:
        await update.message.reply_text(
            "🖥 <b>Ollama 서버 관리</b>",
            parse_mode="HTML",
            reply_markup=ollama_menu_keyboard(),
        )
        return

    sub = context.args[0].lower()

    if sub == "status":
        await _show_status(update)
    elif sub == "ps":
        await _show_ps(update)
    elif sub == "restart":
        await _do_restart(update)
    elif sub == "info" and len(context.args) > 1:
        model = context.args[1]
        await _show_info(update, model)
    elif sub == "copy" and len(context.args) > 2:
        src, dst = context.args[1], context.args[2]
        await _do_copy(update, src, dst)
    else:
        await update.message.reply_text(
            "사용법:\n"
            "/ollama status — 서버 상태\n"
            "/ollama ps — 로드된 모델\n"
            "/ollama restart — 재시작\n"
            "/ollama info <model> — 모델 상세\n"
            "/ollama copy <src> <dst> — 모델 복사"
        )


def _ollama_installed() -> bool:
    """Check if ollama binary exists."""
    import shutil
    return shutil.which("ollama") is not None


async def _show_status(update_or_query):
    installed = _ollama_installed()
    alive = await ollama_alive() if installed else False

    if not installed:
        status = "❌ 미설치"
    elif alive:
        status = "🟢 온라인"
    else:
        status = "🔴 오프라인"

    text = (
        f"🖥 <b>Ollama 서버 상태</b>\n\n"
        f"상태: {status}\n"
        f"주소: {OLLAMA_BASE}"
    )

    if not installed:
        text += (
            "\n\nOllama가 설치되어 있지 않습니다.\n"
            "아래 버튼으로 자동 설치하거나, 수동 설치하세요."
        )

    if alive:
        running = await get_running_models()
        if running:
            text += f"\n로드된 모델: {len(running)}개"
            for m in running:
                name = m.get("name", "?")
                size = m.get("size", 0)
                size_gb = f"{size / 1e9:.1f}GB" if size else "?"
                text += f"\n  • {name} ({size_gb})"
        else:
            text += "\n로드된 모델: 없음"

    kb = ollama_menu_keyboard(show_install=not installed)
    if hasattr(update_or_query, 'message') and update_or_query.message:
        await update_or_query.message.reply_text(text, parse_mode="HTML", reply_markup=kb)
    else:
        await update_or_query.edit_message_text(text, parse_mode="HTML", reply_markup=kb)


async def _show_ps(update_or_query):
    running = await get_running_models()
    if not running:
        text = "🖥 로드된 모델이 없습니다."
    else:
        lines = ["🖥 <b>현재 로드된 모델</b>\n"]
        for m in running:
            name = m.get("name", "?")
            size = m.get("size", 0)
            size_gb = f"{size / 1e9:.1f}GB" if size else "?"
            expires = m.get("expires_at", "?")
            lines.append(f"• <b>{name}</b> ({size_gb})\n  만료: {expires}")
        text = "\n".join(lines)

    if hasattr(update_or_query, 'message') and update_or_query.message:
        await update_or_query.message.reply_text(text, parse_mode="HTML", reply_markup=ollama_menu_keyboard())
    else:
        await update_or_query.edit_message_text(text, parse_mode="HTML", reply_markup=ollama_menu_keyboard())


async def _do_restart(update_or_query):
    ok, msg = pm2_restart_ollama()
    emoji = "✅" if ok else "❌"
    text = f"{emoji} {msg}"
    if hasattr(update_or_query, 'message') and update_or_query.message:
        await update_or_query.message.reply_text(text, reply_markup=ollama_menu_keyboard())
    else:
        await update_or_query.edit_message_text(text, reply_markup=ollama_menu_keyboard())


async def _show_info(update, model: str):
    try:
        info = await get_model_info(model)
    except Exception as e:
        await update.message.reply_text(f"모델 정보 조회 실패: {e}")
        return

    details = info.get("details", {})
    params = details.get("parameter_size", "?")
    quant = details.get("quantization_level", "?")
    family = details.get("family", "?")
    fmt = details.get("format", "?")

    caps = await get_model_capabilities(model)
    cap_text = ", ".join(caps) if caps else "없음"

    template = (info.get("template") or "")[:200]

    await update.message.reply_text(
        f"ℹ️ <b>모델 정보: {model}</b>\n\n"
        f"Family: {family}\n"
        f"Parameters: {params}\n"
        f"Quantization: {quant}\n"
        f"Format: {fmt}\n"
        f"Capabilities: {cap_text}\n\n"
        f"Template:\n<code>{template}</code>",
        parse_mode="HTML",
    )


async def _do_copy(update, src: str, dst: str):
    try:
        await copy_model(src, dst)
        await update.message.reply_text(f"✅ 모델 복사 완료: {src} → {dst}")
    except Exception as e:
        await update.message.reply_text(f"❌ 복사 실패: {e}")


# ── Callback processing (called from handlers/callbacks.py) ──

async def handle_ollama_callback(query, uid: int, data: str):
    if data == "ollama:status":
        await _show_status(query)
    elif data == "ollama:ps":
        await _show_ps(query)
    elif data == "ollama:restart":
        await _do_restart(query)
    elif data == "ollama:info_prompt":
        await query.edit_message_text(
            "ℹ️ 모델 상세 정보를 보려면:\n/ollama info <모델명>\n\n예: /ollama info gemma4:26b",
            reply_markup=ollama_menu_keyboard(),
        )
    elif data == "ollama:copy_prompt":
        await query.edit_message_text(
            "📋 모델을 복사하려면:\n/ollama copy <원본> <대상>\n\n예: /ollama copy gemma4:26b mymodel:latest",
            reply_markup=ollama_menu_keyboard(),
        )
    elif data == "ollama:install":
        await _install_ollama(query)


async def _install_ollama(query):
    """Install Ollama via official install script."""
    if _ollama_installed():
        await query.edit_message_text("✅ Ollama가 이미 설치되어 있습니다.", reply_markup=ollama_menu_keyboard())
        return

    await query.edit_message_text("📥 Ollama 설치 중... (1-2분 소요)")

    import asyncio
    import platform
    system = platform.system().lower()

    if system == "darwin":
        # macOS: brew install
        cmd = "brew install ollama 2>&1"
    elif system == "linux":
        # Linux: official install script
        cmd = "curl -fsSL https://ollama.com/install.sh | sh 2>&1"
    else:
        await query.edit_message_text(
            f"❌ 지원하지 않는 OS: {system}\nhttps://ollama.com 에서 수동 설치하세요.",
            reply_markup=ollama_menu_keyboard(),
        )
        return

    try:
        proc = await asyncio.create_subprocess_shell(
            cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=180)
        output = stdout.decode("utf-8", errors="replace")[-500:]

        if proc.returncode == 0 and _ollama_installed():
            await query.edit_message_text(
                f"✅ Ollama 설치 완료!\n\n<code>{output[-200:]}</code>\n\n"
                "Ollama를 시작하려면 서버에서 'ollama serve'를 실행하세요.",
                parse_mode="HTML",
                reply_markup=ollama_menu_keyboard(),
            )
        else:
            err = stderr.decode("utf-8", errors="replace")[-300:]
            await query.edit_message_text(
                f"❌ 설치 실패\n\n<code>{err or output}</code>",
                parse_mode="HTML",
                reply_markup=ollama_menu_keyboard(show_install=True),
            )
    except asyncio.TimeoutError:
        await query.edit_message_text("❌ 설치 시간 초과 (3분)", reply_markup=ollama_menu_keyboard(show_install=True))
    except Exception as e:
        await query.edit_message_text(f"❌ 설치 오류: {e}", reply_markup=ollama_menu_keyboard(show_install=True))


# ── ComfyUI Management ──────────────────────────────────


def comfyui_menu_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [
            InlineKeyboardButton("📊 상태 확인", callback_data="comfyui:status"),
            InlineKeyboardButton("🚀 시작", callback_data="comfyui:start"),
        ],
        [InlineKeyboardButton("🏠 메뉴", callback_data="cmd:menu")],
    ])


def _comfyui_installed() -> bool:
    """Check if ComfyUI is installed on this system."""
    from pathlib import Path
    return (
        Path("/Applications/ComfyUI.app").exists()
        or Path.home().joinpath("Documents", "ComfyUI").exists()
    )


async def show_comfyui_status(query):
    installed = _comfyui_installed()
    if not installed:
        await query.edit_message_text(
            "🎨 <b>ComfyUI 상태</b>\n\n"
            "상태: ❌ 미설치\n\n"
            "ComfyUI가 이 서버에 설치되어 있지 않습니다.\n"
            "이미지 생성/편집 기능을 사용하려면 ComfyUI를 별도로 설치해주세요.\n\n"
            "설치 가이드: https://github.com/comfyanonymous/ComfyUI",
            parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("🏠 메뉴", callback_data="cmd:menu")],
            ]),
        )
        return

    alive = await comfyui_alive()
    status = "🟢 실행 중" if alive else "🔴 꺼짐"

    text = (
        f"🎨 <b>ComfyUI 상태</b>\n\n"
        f"상태: {status}\n"
        f"주소: {COMFY_BASE}\n\n"
        f"이미지 생성/편집 도구에 필요합니다."
    )

    if alive:
        try:
            import httpx
            async with httpx.AsyncClient(timeout=5) as client:
                r = await client.get(f"{COMFY_BASE}/system_stats")
                if r.status_code == 200:
                    stats = r.json()
                    devices = stats.get("devices", [])
                    for d in devices:
                        name = d.get("name", "?")
                        vram_total = d.get("vram_total", 0)
                        vram_free = d.get("vram_free", 0)
                        vram_used = vram_total - vram_free
                        if vram_total > 0:
                            text += (
                                f"\n\n<b>GPU:</b> {name}\n"
                                f"VRAM: {vram_used / 1e9:.1f}GB / {vram_total / 1e9:.1f}GB "
                                f"({vram_used / vram_total * 100:.0f}%)"
                            )
        except Exception:
            pass

    await query.edit_message_text(text, parse_mode="HTML", reply_markup=comfyui_menu_keyboard())


async def _start_comfyui(query):
    """Start ComfyUI via shell command."""
    alive = await comfyui_alive()
    if alive:
        await query.edit_message_text("🟢 ComfyUI가 이미 실행 중입니다.", reply_markup=comfyui_menu_keyboard())
        return

    import asyncio
    start_cmd = (
        "cd ~/Documents/ComfyUI && "
        "nohup ./.venv/bin/python /Applications/ComfyUI.app/Contents/Resources/ComfyUI/main.py "
        "--listen 0.0.0.0 --port 8184 "
        "--front-end-root /Applications/ComfyUI.app/Contents/Resources/ComfyUI/web_custom_versions/desktop_app "
        "--user-directory ~/Documents/ComfyUI/user "
        "--input-directory ~/Documents/ComfyUI/input "
        "--output-directory ~/Documents/ComfyUI/output "
        "--base-directory ~/Documents/ComfyUI "
        "--database-url sqlite:////Users/macmini/Documents/ComfyUI/user/comfyui.db "
        "--extra-model-paths-config '/Users/macmini/Library/Application Support/ComfyUI/extra_models_config.yaml' "
        "--enable-manager > ~/Documents/ComfyUI/user/comfyui-nohup.log 2>&1 &"
    )

    try:
        proc = await asyncio.create_subprocess_shell(start_cmd)
        await proc.wait()

        # Wait for startup
        await query.edit_message_text("⏳ ComfyUI 시작 중... (최대 40�� 대기)", reply_markup=comfyui_menu_keyboard())
        for _ in range(20):
            await asyncio.sleep(2)
            if await comfyui_alive():
                await query.edit_message_text("✅ ComfyUI 시작 완료!", reply_markup=comfyui_menu_keyboard())
                return

        await query.edit_message_text("⚠️ ComfyUI 시작 요청 완료. 아직 응답 없음 — 잠시 후 상태를 확인하세요.", reply_markup=comfyui_menu_keyboard())
    except Exception as e:
        await query.edit_message_text(f"❌ ComfyUI 시작 실패: {e}", reply_markup=comfyui_menu_keyboard())


async def handle_comfyui_callback(query, uid: int, data: str):
    if data == "comfyui:status":
        await show_comfyui_status(query)
    elif data == "comfyui:start":
        await _start_comfyui(query)
