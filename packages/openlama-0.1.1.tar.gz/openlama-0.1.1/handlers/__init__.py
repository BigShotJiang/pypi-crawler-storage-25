"""Handler registration for the Telegram bot."""

from telegram.ext import (
    Application,
    CallbackQueryHandler,
    CommandHandler,
    MessageHandler,
    filters,
)


def register_all_handlers(app: Application):
    from handlers.commands import (
        start, login, logout, setpassword,
        models_cmd, model_cmd, pull_cmd, pullstatus_cmd, rm_cmd,
        status_cmd, clear_cmd, export_cmd, help_cmd,
    )
    from handlers.settings import systemprompt_cmd, think_cmd, settings_cmd
    from handlers.admin import ollama_cmd
    from handlers.callbacks import on_callback
    from handlers.chat import on_text, on_media, on_document

    # Commands
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("help", help_cmd))
    app.add_handler(CommandHandler("login", login))
    app.add_handler(CommandHandler("logout", logout))
    app.add_handler(CommandHandler("setpassword", setpassword))
    app.add_handler(CommandHandler("models", models_cmd))
    app.add_handler(CommandHandler("model", model_cmd))
    app.add_handler(CommandHandler("pull", pull_cmd))
    app.add_handler(CommandHandler("pullstatus", pullstatus_cmd))
    app.add_handler(CommandHandler("rm", rm_cmd))
    app.add_handler(CommandHandler("status", status_cmd))
    app.add_handler(CommandHandler("clear", clear_cmd))
    app.add_handler(CommandHandler("settings", settings_cmd))
    app.add_handler(CommandHandler("systemprompt", systemprompt_cmd))
    app.add_handler(CommandHandler("think", think_cmd))
    app.add_handler(CommandHandler("ollama", ollama_cmd))
    app.add_handler(CommandHandler("export", export_cmd))

    # Callbacks (inline keyboards)
    app.add_handler(CallbackQueryHandler(on_callback))

    # Media and documents
    app.add_handler(MessageHandler(
        (filters.PHOTO | filters.Document.IMAGE) & ~filters.COMMAND, on_media
    ))
    app.add_handler(MessageHandler(
        filters.Document.ALL & ~filters.Document.IMAGE & ~filters.COMMAND, on_document
    ))
    app.add_handler(MessageHandler(
        (filters.AUDIO | filters.VOICE) & ~filters.COMMAND, on_media
    ))
    app.add_handler(MessageHandler(
        (filters.VIDEO | filters.VIDEO_NOTE) & ~filters.COMMAND, on_media
    ))

    # Text (last – catch-all)
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, on_text))
