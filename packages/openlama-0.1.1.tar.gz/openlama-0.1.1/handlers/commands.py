"""Command handlers – /start, /login, /models, /pull, /help, etc."""

from __future__ import annotations

import asyncio
import json
import io

from telegram import BotCommand, InlineKeyboardButton, InlineKeyboardMarkup, Update
from telegram.ext import ContextTypes

from auth import hash_password, require_auth, verify_password
from config import (
    ADMIN_PASSWORD,
    DEFAULT_CONTEXT_TURNS,
    DEFAULT_CONTEXT_TTL_SEC,
    DEFAULT_MODEL,
    DEFAULT_SYSTEM_PROMPT,
    LOGIN_LOCK_SEC,
    LOGIN_MAX_FAILS,
    MODEL_PAGE_SIZE,
    SESSION_TTL_SEC,
)
from database import (
    UserState,
    clear_context,
    get_admin_password_hash,
    get_model_settings,
    get_user,
    init_db,
    is_authed,
    is_login_locked,
    load_context,
    now_ts,
    set_admin_password_hash,
    update_user,
)
from ollama_client import (
    delete_model,
    ensure_ollama_running,
    fetch_models,
    get_model_display_map,
    get_pull_state,
    model_supports_images,
    pull_model_stream,
    set_pull_state,
    unload_model,
)


# ── Keyboard builders ─────────────────────────────────────

def main_menu_keyboard(is_logged_in: bool = False) -> InlineKeyboardMarkup:
    """Build the main menu button keyboard."""
    if not is_logged_in:
        return InlineKeyboardMarkup([
            [InlineKeyboardButton("🔑 로그인", callback_data="cmd:login")],
            [InlineKeyboardButton("📖 도움말", callback_data="cmd:help")],
        ])

    return InlineKeyboardMarkup([
        [
            InlineKeyboardButton("🤖 모델 선택", callback_data="cmd:models"),
            InlineKeyboardButton("📊 현재 모델", callback_data="cmd:model"),
        ],
        [
            InlineKeyboardButton("⚙️ 설정", callback_data="cmd:settings"),
            InlineKeyboardButton("💬 시스템 프롬프트", callback_data="cmd:systemprompt"),
        ],
        [
            InlineKeyboardButton("🧠 Think 모드", callback_data="cmd:think_toggle"),
            InlineKeyboardButton("📊 컨텍스트", callback_data="cmd:context_status"),
        ],
        [
            InlineKeyboardButton("📥 모델 설치", callback_data="cmd:pull_prompt"),
            InlineKeyboardButton("🗂 모델 삭제", callback_data="cmd:rm"),
        ],
        [
            InlineKeyboardButton("🖥 Ollama 관리", callback_data="cmd:ollama"),
            InlineKeyboardButton("🎨 ComfyUI 관리", callback_data="cmd:comfyui"),
        ],
        [
            InlineKeyboardButton("📋 세션 관리", callback_data="cmd:session"),
            InlineKeyboardButton("📤 대화 내보내기", callback_data="cmd:export"),
        ],
        [
            InlineKeyboardButton("📖 도움말", callback_data="cmd:help"),
            InlineKeyboardButton("🔓 로그아웃", callback_data="cmd:logout"),
        ],
    ])


def model_keyboard(models: list[str], page: int = 0, display_map: dict | None = None) -> InlineKeyboardMarkup:
    total_pages = max(1, (len(models) + MODEL_PAGE_SIZE - 1) // MODEL_PAGE_SIZE)
    page = max(0, min(page, total_pages - 1))
    chunk = models[page * MODEL_PAGE_SIZE: (page + 1) * MODEL_PAGE_SIZE]

    rows = [
        [InlineKeyboardButton((display_map or {}).get(m, m), callback_data=f"model:{m}")]
        for m in chunk
    ]

    nav = []
    if page > 0:
        nav.append(InlineKeyboardButton("◀ 이전", callback_data=f"models_page:{page - 1}"))
    nav.append(InlineKeyboardButton(f"{page + 1}/{total_pages}", callback_data="noop"))
    if page < total_pages - 1:
        nav.append(InlineKeyboardButton("다음 ▶", callback_data=f"models_page:{page + 1}"))
    rows.append(nav)
    rows.append([
        InlineKeyboardButton("🗑 컨텍스트 초기화", callback_data="clear_ctx"),
        InlineKeyboardButton("🏠 메뉴", callback_data="cmd:menu"),
    ])
    return InlineKeyboardMarkup(rows)


def rm_model_keyboard(models: list[str], page: int = 0, selected_model: str = "", display_map: dict | None = None) -> InlineKeyboardMarkup:
    total_pages = max(1, (len(models) + MODEL_PAGE_SIZE - 1) // MODEL_PAGE_SIZE)
    page = max(0, min(page, total_pages - 1))
    chunk = models[page * MODEL_PAGE_SIZE: (page + 1) * MODEL_PAGE_SIZE]

    rows = []
    for m in chunk:
        label = (display_map or {}).get(m, m)
        if m == selected_model:
            label = f"✅ {label}"
        rows.append([InlineKeyboardButton(label, callback_data=f"rm_model:{m}")])

    nav = []
    if page > 0:
        nav.append(InlineKeyboardButton("◀ 이전", callback_data=f"rm_page:{page - 1}"))
    nav.append(InlineKeyboardButton(f"{page + 1}/{total_pages}", callback_data="noop"))
    if page < total_pages - 1:
        nav.append(InlineKeyboardButton("다음 ▶", callback_data=f"rm_page:{page + 1}"))
    rows.append(nav)
    rows.append([
        InlineKeyboardButton("취소", callback_data="rm_cancel"),
        InlineKeyboardButton("🏠 메뉴", callback_data="cmd:menu"),
    ])
    return InlineKeyboardMarkup(rows)


# ── Commands ──────────────────────────────────────────────

HELP_TEXT = """<b>📖 Ollama Telegram Bot 사용 가이드</b>

<b>🔐 인증</b>
• /login — 비밀번호 인증
• /logout — 로그아웃
• /setpassword — 관리자 비밀번호 변경

<b>🤖 모델 관리</b>
• /models — 모델 목록 / 선택
• /model — 현재 모델 정보
• /pull &lt;model&gt; — 모델 설치
• /pullstatus — 설치 진행상태
• /rm — 모델 삭제

<b>⚙️ 설정</b>
• /settings — 모델 파라미터 (각 항목 설명 포함)
• /systemprompt — 시스템 프롬프트
• /think — 추론 과정 표시 (on/off)
• /clear — 컨텍스트 초기화

<b>🖥 서버 관리</b>
• /ollama — Ollama 서버 상태/재시작
• 🎨 ComfyUI — 이미지 생성 엔진 관리
• 📋 세션 관리 — 인증 상태 확인/연장

<b>💡 사용법</b>
• 텍스트 → 선택된 모델이 답변
• 이미지 전송 → 분석 또는 편집 (👁 비전 모델)
• PDF/문서 전송 → 내용 분석
• 비디오 전송 → 프레임 추출 분석
• 모델별 지원 기능이 다릅니다 (선택 시 안내)

<b>🔧 사용 가능한 도구</b> (🔧 도구 지원 모델)
• 🔍 웹 검색 (DuckDuckGo)
• 💻 코드 실행 (Python/Node.js/Shell)
• 🌐 URL 내용 가져오기
• 🕐 현재 날짜/시간
• 🧮 수학 계산기
• 📁 파일 읽기/쓰기 (서버 전체)
• 🖥 셸 명령 실행
• 🔀 Git 저장소 관리
• 📊 프로세스/시스템 모니터링
• 🎨 이미지 생성 (ComfyUI)
• ✏️ 이미지 편집 (ComfyUI, 비전 모델)
• 📝 Obsidian 노트 관리 (읽기/생성/검색/편집)
"""


async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    uid = update.effective_user.id
    user = get_user(uid)
    logged_in = is_authed(user)
    await update.message.reply_text(
        "🤖 <b>Ollama Telegram Bot</b>\n\n"
        + ("✅ 인증됨\n아래 메뉴를 사용하세요." if logged_in else "🔑 /login 으로 인증하세요."),
        parse_mode="HTML",
        reply_markup=main_menu_keyboard(logged_in),
    )


async def help_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    uid = update.effective_user.id
    user = get_user(uid)
    logged_in = is_authed(user)
    await update.message.reply_text(
        HELP_TEXT,
        parse_mode="HTML",
        reply_markup=main_menu_keyboard(logged_in),
    )


async def login(update: Update, context: ContextTypes.DEFAULT_TYPE):
    uid = update.effective_user.id
    user = get_user(uid)
    if is_authed(user):
        await update.message.reply_text(
            "이미 인증되어 있습니다.",
            reply_markup=main_menu_keyboard(True),
        )
        return
    if is_login_locked(user):
        await update.message.reply_text(f"로그인 제한 중: {user.login_lock_until - now_ts()}초")
        return
    update_user(uid, state="await_password")
    await update.message.reply_text("🔑 관리자 비밀번호를 입력하세요.")


async def logout(update: Update, context: ContextTypes.DEFAULT_TYPE):
    uid = update.effective_user.id
    update_user(uid, auth_until=0, state="")
    clear_context(uid)
    await update.message.reply_text(
        "🔓 로그아웃 완료",
        reply_markup=main_menu_keyboard(False),
    )


async def setpassword(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = await require_auth(update)
    if not user:
        return
    update_user(user.telegram_id, state="await_current_password_for_change")
    await update.message.reply_text("현재 비밀번호를 입력하세요.")


async def models_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = await require_auth(update)
    if not user:
        return

    ok, msg = await ensure_ollama_running()
    if not ok:
        await update.message.reply_text(f"Ollama 연결 실패: {msg}")
        return

    try:
        models = await fetch_models()
    except Exception as e:
        await update.message.reply_text(f"모델 조회 실패: {e}")
        return

    if not models:
        await update.message.reply_text("설치된 모델이 없습니다. /pull 로 설치하세요.")
        return

    display_map = await get_model_display_map(models)
    await update.message.reply_text(
        "🤖 <b>모델 선택</b>\n"
        "👁 이미지 지원 | 🔧 도구 지원 | 💭 Think 지원 | 💬 텍스트 전용",
        parse_mode="HTML",
        reply_markup=model_keyboard(models, 0, display_map),
    )


async def model_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = await require_auth(update)
    if not user:
        return

    selected = user.selected_model or "(미선택)"
    if not user.selected_model:
        await update.message.reply_text(
            f"현재 모델: {selected}\n/models 로 모델을 선택하세요.",
            reply_markup=main_menu_keyboard(True),
        )
        return

    try:
        from ollama_client import get_model_capabilities
        caps = await get_model_capabilities(user.selected_model)
        cap_badges = []
        if any(c in caps for c in ("vision", "image", "multimodal")):
            cap_badges.append("👁 이미지 입력")
        if "tools" in caps:
            cap_badges.append("🔧 도구 호출")
        if "thinking" in caps:
            cap_badges.append("💭 Think 모드")
        if "audio" in caps:
            cap_badges.append("🎵 오디오 입력")
        cap_text = "\n".join(f"  • {b}" for b in cap_badges) if cap_badges else "  • 💬 텍스트 전용"

        ms = get_model_settings(user.telegram_id, user.selected_model)
        await update.message.reply_text(
            f"🤖 <b>현재 모델: {selected}</b>\n\n"
            f"<b>지원 기능:</b>\n{cap_text}\n\n"
            f"<b>파라미터:</b>\n"
            f"  • temperature: {ms.temperature}\n"
            f"  • num_ctx: {ms.num_ctx}\n"
            f"  • num_predict: {ms.num_predict}\n"
            f"  • think: {'ON' if user.think_mode else 'OFF'}",
            parse_mode="HTML",
            reply_markup=main_menu_keyboard(True),
        )
    except Exception:
        await update.message.reply_text(f"현재 모델: {selected}")


async def pull_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = await require_auth(update)
    if not user:
        return

    if not context.args:
        await update.message.reply_text(
            "📥 <b>모델 설치</b>\n\n"
            "사용법: /pull &lt;model&gt;\n\n"
            "예시:\n"
            "• /pull gemma4:26b\n"
            "• /pull gemma4:e4b\n"
            "• /pull llama3.1:8b\n"
            "• /pull qwen2.5:14b",
            parse_mode="HTML",
        )
        return

    model = " ".join(context.args).strip()
    uid = user.telegram_id

    st = get_pull_state(uid)
    if st and st.get("status") == "running":
        await update.message.reply_text(f"이미 설치 진행 중: {st.get('model')} /pullstatus")
        return

    set_pull_state(uid, status="queued", model=model, progress=0, detail="대기")
    asyncio.create_task(pull_model_stream(uid, model))
    await update.message.reply_text(f"📥 설치 시작: {model}\n진행 확인: /pullstatus")


async def pullstatus_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = await require_auth(update)
    if not user:
        return

    st = get_pull_state(user.telegram_id)
    if not st:
        await update.message.reply_text("진행 중인 설치 이력이 없습니다.")
        return

    status_emoji = {"queued": "⏳", "running": "⬇️", "done": "✅", "failed": "❌"}.get(st.get("status", ""), "❓")
    progress = st.get("progress", 0)
    bar_len = 20
    filled = int(bar_len * progress / 100)
    bar = "█" * filled + "░" * (bar_len - filled)

    await update.message.reply_text(
        f"{status_emoji} <b>모델 설치 상태</b>\n\n"
        f"모델: {st.get('model', '-')}\n"
        f"상태: {st.get('status', '-')}\n"
        f"진행: [{bar}] {progress}%\n"
        f"상세: {st.get('detail', '-')}",
        parse_mode="HTML",
    )


async def rm_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = await require_auth(update)
    if not user:
        return

    ok, msg = await ensure_ollama_running()
    if not ok:
        await update.message.reply_text(f"Ollama 연결 실패: {msg}")
        return

    if context.args:
        model = " ".join(context.args).strip()
        try:
            await delete_model(model)
        except Exception as e:
            await update.message.reply_text(f"삭제 실패: {e}")
            return
        if user.selected_model == model:
            update_user(user.telegram_id, selected_model="")
        await update.message.reply_text(f"🗑 삭제 완료: {model}")
        return

    try:
        models = await fetch_models()
    except Exception as e:
        await update.message.reply_text(f"모델 조회 실패: {e}")
        return

    if not models:
        await update.message.reply_text("삭제할 모델이 없습니다.")
        return

    display_map = await get_model_display_map(models)
    await update.message.reply_text(
        "🗑 <b>삭제할 모델을 선택하세요</b>\n✅ 현재 선택 중인 모델",
        parse_mode="HTML",
        reply_markup=rm_model_keyboard(models, 0, user.selected_model, display_map),
    )


async def status_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    uid = update.effective_user.id
    user = get_user(uid)
    auth_left = max(0, user.auth_until - now_ts())
    ms = get_model_settings(uid, user.selected_model) if user.selected_model else None

    text = (
        f"📋 <b>세션 상태</b>\n\n"
        f"인증: {'✅ 유효' if auth_left else '❌ 만료'} ({auth_left}s)\n"
        f"모델: {user.selected_model or '(미선택)'}\n"
        f"시스템 프롬프트: {'커스텀' if user.system_prompt else '기본값'}\n"
        f"Think 모드: {'ON 💭' if user.think_mode else 'OFF'}\n"
        f"컨텍스트: 최근 {user.context_turns}턴 / TTL {user.context_ttl_sec}s"
    )
    if ms:
        text += (
            f"\n\n<b>모델 파라미터:</b>\n"
            f"  temperature: {ms.temperature} | top_p: {ms.top_p}\n"
            f"  num_ctx: {ms.num_ctx} | num_predict: {ms.num_predict}"
        )

    await update.message.reply_text(
        text,
        parse_mode="HTML",
        reply_markup=main_menu_keyboard(is_authed(user)),
    )


async def clear_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    uid = update.effective_user.id
    clear_context(uid)
    await update.message.reply_text(
        "🗑 컨텍스트 초기화 완료",
        reply_markup=main_menu_keyboard(is_authed(get_user(uid))),
    )


async def export_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = await require_auth(update)
    if not user:
        return

    items = load_context(user.telegram_id, max_turns=0, ttl=999999999)
    if not items:
        await update.message.reply_text("내보낼 대화 기록이 없습니다.")
        return

    lines = []
    for i, item in enumerate(items, 1):
        lines.append(f"--- Turn {i} ---")
        lines.append(f"User: {item.get('u', '')}")
        lines.append(f"Assistant: {item.get('a', '')}")
        lines.append("")

    content = "\n".join(lines)
    buf = io.BytesIO(content.encode("utf-8"))
    buf.name = "conversation_export.txt"
    await update.message.reply_document(document=buf, caption="📤 대화 기록 내보내기")


# ── Post-init: register bot commands ─────────────────────

async def post_init(app):
    await app.bot.set_my_commands([
        BotCommand("start", "시작 / 메인 메뉴"),
        BotCommand("help", "사용 가이드"),
        BotCommand("login", "비밀번호 인증"),
        BotCommand("logout", "로그아웃"),
        BotCommand("models", "모델 목록 / 선택"),
        BotCommand("model", "현재 모델 정보"),
        BotCommand("pull", "모델 설치 (/pull 모델명)"),
        BotCommand("pullstatus", "설치 진행상태"),
        BotCommand("rm", "모델 삭제"),
        BotCommand("settings", "모델 파라미터 설정"),
        BotCommand("systemprompt", "시스템 프롬프트 설정"),
        BotCommand("think", "Think 모드 on/off"),
        BotCommand("clear", "컨텍스트 초기화"),
        BotCommand("status", "세션 상태 확인"),
        BotCommand("ollama", "Ollama 서버 관리"),
        BotCommand("export", "대화 기록 내보내기"),
        BotCommand("setpassword", "비밀번호 변경"),
    ])
