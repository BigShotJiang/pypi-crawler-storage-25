"""Callback query handler – inline keyboard button presses."""

from __future__ import annotations

from telegram import Update
from telegram.ext import ContextTypes

from auth import require_auth
from database import (
    clear_context,
    get_user,
    is_authed,
    update_user,
)
from ollama_client import (
    delete_model,
    ensure_ollama_running,
    fetch_models,
    get_model_display_map,
    unload_model,
)
from handlers.commands import (
    main_menu_keyboard,
    model_keyboard,
    rm_model_keyboard,
    HELP_TEXT,
)


async def on_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    if not q or not update.effective_user:
        return
    await q.answer()

    uid = update.effective_user.id
    data = q.data or ""

    if data == "noop":
        return

    # ── Login button (no auth required) ──
    if data == "cmd:login":
        user = get_user(uid)
        if is_authed(user):
            await q.edit_message_text("이미 인증되어 있습니다.", reply_markup=main_menu_keyboard(True))
            return
        update_user(uid, state="await_password")
        await q.edit_message_text("🔑 관리자 비밀번호를 입력하세요.")
        return

    if data == "cmd:help":
        user = get_user(uid)
        await q.edit_message_text(HELP_TEXT, parse_mode="HTML", reply_markup=main_menu_keyboard(is_authed(user)))
        return

    # ── Auth required callbacks ──
    user = get_user(uid)
    if not is_authed(user):
        await q.edit_message_text("인증 만료. /login", reply_markup=main_menu_keyboard(False))
        return

    # ── Menu ──
    if data == "cmd:menu":
        await q.edit_message_text(
            "🤖 <b>Ollama Telegram Bot</b>\n\n메뉴를 선택하세요.",
            parse_mode="HTML",
            reply_markup=main_menu_keyboard(True),
        )
        return

    # ── Clear context ──
    if data == "clear_ctx":
        clear_context(uid)
        await q.edit_message_text("🗑 컨텍스트 초기화 완료", reply_markup=main_menu_keyboard(True))
        return

    # ── Context status ──
    if data == "cmd:context_status":
        from handlers.context_status import build_context_status
        text, kb = await build_context_status(uid, user)
        await q.edit_message_text(text, parse_mode="HTML", reply_markup=kb)
        return

    # ── Context compress ──
    if data == "ctx:compress":
        from handlers.context_status import compress_context, build_context_status
        await q.edit_message_text("🗜 컨텍스트 압축 중...")
        result_text = await compress_context(uid, user)
        # Reload user for updated context
        user = get_user(uid)
        status_text, kb = await build_context_status(uid, user)
        await q.edit_message_text(
            f"{result_text}\n\n{'─' * 30}\n\n{status_text}",
            parse_mode="HTML",
            reply_markup=kb,
        )
        return

    # ── Model selection ──
    if data.startswith("model:"):
        model = data.split(":", 1)[1]
        old_model = user.selected_model
        update_user(uid, selected_model=model)
        if old_model and old_model != model:
            await unload_model(old_model)

        from ollama_client import get_model_capabilities, get_model_max_context
        caps = await get_model_capabilities(model)
        max_ctx = await get_model_max_context(model)

        cap_lines = []
        has_vision = any(c in caps for c in ("vision", "image", "multimodal"))
        has_tools = "tools" in caps
        has_thinking = "thinking" in caps

        if has_vision:
            cap_lines.append("  👁 이미지/PDF 분석, 이미지 편집")
        if has_tools:
            cap_lines.append("  🔧 도구 사용 (웹검색, 코드실행, 파일, Git, 이미지생성 등)")
        if has_thinking:
            cap_lines.append("  💭 추론 과정 표시 (Think 모드)")
        if "audio" in caps:
            cap_lines.append("  🎵 오디오 입력 분석")
        if not cap_lines:
            cap_lines.append("  💬 텍스트 대화 전용")

        # Capability warnings
        warnings = []
        if not has_tools:
            warnings.append("⚠️ 도구 미지원 — 웹검색/코드실행 등 사용 불가")
        if not has_vision:
            warnings.append("⚠️ 비전 미지원 — 이미지 분석/편집 불가")

        text = (
            f"✅ 선택 모델: <b>{model}</b>\n\n"
            f"<b>지원 기능:</b>\n" + "\n".join(cap_lines)
        )
        if max_ctx > 0:
            text += f"\n  📏 최대 컨텍스트: {max_ctx:,} tokens"
        if warnings:
            text += "\n\n" + "\n".join(warnings)
        text += "\n\n메시지를 보내면 해당 모델로 답변합니다."

        await q.edit_message_text(
            text,
            parse_mode="HTML",
            reply_markup=main_menu_keyboard(True),
        )
        return

    # ── Model pages ──
    if data.startswith("models_page:"):
        page = int(data.split(":", 1)[1])
        ok, msg = await ensure_ollama_running()
        if not ok:
            await q.edit_message_text(f"Ollama 연결 실패: {msg}")
            return
        models = await fetch_models()
        display_map = await get_model_display_map(models)
        await q.edit_message_text(
            "🤖 <b>모델 선택</b>\n"
            "👁 이미지 | 🔧 도구 | 💭 Think | 💬 텍스트",
            parse_mode="HTML",
            reply_markup=model_keyboard(models, page, display_map),
        )
        return

    # ── Delete model ──
    if data.startswith("rm_model:"):
        model = data.split(":", 1)[1]
        ok, msg = await ensure_ollama_running()
        if not ok:
            await q.edit_message_text(f"Ollama 연결 실패: {msg}")
            return
        try:
            await delete_model(model)
        except Exception as e:
            await q.edit_message_text(f"삭제 실패: {e}")
            return
        if user.selected_model == model:
            update_user(uid, selected_model="")
        await q.edit_message_text(f"🗑 삭제 완료: {model}", reply_markup=main_menu_keyboard(True))
        return

    if data.startswith("rm_page:"):
        page = int(data.split(":", 1)[1])
        ok, msg = await ensure_ollama_running()
        if not ok:
            await q.edit_message_text(f"Ollama 연결 실패: {msg}")
            return
        models = await fetch_models()
        display_map = await get_model_display_map(models)
        await q.edit_message_reply_markup(
            reply_markup=rm_model_keyboard(models, page, user.selected_model, display_map)
        )
        return

    if data == "rm_cancel":
        await q.edit_message_text("모델 삭제를 취소했습니다.", reply_markup=main_menu_keyboard(True))
        return

    # ── Command shortcuts ──
    if data == "cmd:models":
        ok, msg = await ensure_ollama_running()
        if not ok:
            await q.edit_message_text(f"Ollama 연결 실패: {msg}")
            return
        try:
            models = await fetch_models()
        except Exception as e:
            await q.edit_message_text(f"모델 조회 실패: {e}")
            return
        if not models:
            await q.edit_message_text("설치된 모델이 없습니다.", reply_markup=main_menu_keyboard(True))
            return
        display_map = await get_model_display_map(models)
        await q.edit_message_text(
            "🤖 <b>모델 선택</b>\n"
            "👁 이미지 | 🔧 도구 | 💭 Think | 💬 텍스트",
            parse_mode="HTML",
            reply_markup=model_keyboard(models, 0, display_map),
        )
        return

    if data == "cmd:model":
        selected = user.selected_model or "(미선택)"
        await q.edit_message_text(f"📊 현재 모델: {selected}", reply_markup=main_menu_keyboard(True))
        return

    if data == "cmd:settings":
        if not user.selected_model:
            await q.edit_message_text("먼저 모델을 선택하세요: /models", reply_markup=main_menu_keyboard(True))
            return
        from handlers.settings import settings_keyboard
        await q.edit_message_text(
            f"⚙️ <b>모델 설정: {user.selected_model}</b>",
            parse_mode="HTML",
            reply_markup=settings_keyboard(uid, user.selected_model),
        )
        return

    if data == "cmd:systemprompt":
        from config import DEFAULT_SYSTEM_PROMPT
        from telegram import InlineKeyboardButton, InlineKeyboardMarkup
        current = user.system_prompt or DEFAULT_SYSTEM_PROMPT
        is_custom = bool(user.system_prompt)
        await q.edit_message_text(
            f"💬 <b>시스템 프롬프트</b>\n\n"
            f"{'🔧 커스텀' if is_custom else '📌 기본값'}:\n<code>{current}</code>\n\n"
            f"변경: /systemprompt set &lt;내용&gt;\n"
            f"초기화: /systemprompt reset",
            parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("🔄 기본값으로 초기화", callback_data="systemprompt:reset")],
                [InlineKeyboardButton("🏠 메뉴", callback_data="cmd:menu")],
            ]),
        )
        return

    if data == "systemprompt:reset":
        update_user(uid, system_prompt="")
        await q.edit_message_text("✅ 시스템 프롬프트가 기본값으로 초기화되었습니다.", reply_markup=main_menu_keyboard(True))
        return

    if data == "cmd:think_toggle":
        new_val = 0 if user.think_mode else 1
        update_user(uid, think_mode=new_val)
        status = "ON 💭" if new_val else "OFF"
        await q.edit_message_text(f"💭 Think 모드: {status}", reply_markup=main_menu_keyboard(True))
        return

    if data == "cmd:think_on":
        update_user(uid, think_mode=1)
        await q.edit_message_text("💭 Think 모드 ON", reply_markup=main_menu_keyboard(True))
        return

    if data == "cmd:think_off":
        update_user(uid, think_mode=0)
        await q.edit_message_text("💭 Think 모드 OFF", reply_markup=main_menu_keyboard(True))
        return

    if data == "cmd:status":
        from database import get_model_settings, now_ts
        auth_left = max(0, user.auth_until - now_ts())
        await q.edit_message_text(
            f"📋 <b>세션 상태</b>\n\n"
            f"인증: {'✅ 유효' if auth_left else '❌ 만료'} ({auth_left}s)\n"
            f"모델: {user.selected_model or '(미선택)'}\n"
            f"Think: {'ON 💭' if user.think_mode else 'OFF'}\n"
            f"컨텍스트: {user.context_turns}턴 / {user.context_ttl_sec}s",
            parse_mode="HTML",
            reply_markup=main_menu_keyboard(True),
        )
        return

    if data == "cmd:logout":
        update_user(uid, auth_until=0, state="")
        clear_context(uid)
        await q.edit_message_text("🔓 로그아웃 완료", reply_markup=main_menu_keyboard(False))
        return

    if data == "cmd:export":
        from database import load_context
        import io
        items = load_context(uid, max_turns=0, ttl=999999999)
        if not items:
            await q.edit_message_text("내보낼 대화 기록이 없습니다.", reply_markup=main_menu_keyboard(True))
            return
        lines = []
        for i, item in enumerate(items, 1):
            lines.append(f"--- Turn {i} ---\nUser: {item.get('u', '')}\nAssistant: {item.get('a', '')}\n")
        content = "\n".join(lines)
        buf = io.BytesIO(content.encode("utf-8"))
        buf.name = "conversation_export.txt"
        await q.message.reply_document(document=buf, caption="📤 대화 기록")
        return

    if data == "cmd:pull_prompt":
        await q.edit_message_text(
            "📥 <b>모델 설치</b>\n\n"
            "/pull &lt;모델명&gt; 으로 설치하세요.\n\n"
            "예시:\n"
            "• /pull gemma4:26b\n"
            "• /pull gemma4:e4b\n"
            "• /pull llama3.1:8b",
            parse_mode="HTML",
            reply_markup=main_menu_keyboard(True),
        )
        return

    if data == "cmd:rm":
        ok, msg = await ensure_ollama_running()
        if not ok:
            await q.edit_message_text(f"Ollama 연결 실패: {msg}")
            return
        try:
            models = await fetch_models()
        except Exception as e:
            await q.edit_message_text(f"모델 조회 실패: {e}")
            return
        if not models:
            await q.edit_message_text("삭제할 모델이 없습니다.", reply_markup=main_menu_keyboard(True))
            return
        display_map = await get_model_display_map(models)
        await q.edit_message_text(
            "🗑 <b>삭제할 모델 선택</b>\n✅ 현재 선택 모델",
            parse_mode="HTML",
            reply_markup=rm_model_keyboard(models, 0, user.selected_model, display_map),
        )
        return

    if data == "cmd:ollama":
        from handlers.admin import ollama_menu_keyboard
        await q.edit_message_text(
            "🖥 <b>Ollama 서버 관리</b>",
            parse_mode="HTML",
            reply_markup=ollama_menu_keyboard(),
        )
        return

    # ── ComfyUI management ──
    if data == "cmd:comfyui":
        from handlers.admin import comfyui_menu_keyboard, show_comfyui_status
        await show_comfyui_status(q)
        return

    if data.startswith("comfyui:"):
        from handlers.admin import handle_comfyui_callback
        await handle_comfyui_callback(q, uid, data)
        return

    # ── Session management ──
    if data == "cmd:session":
        from telegram import InlineKeyboardButton, InlineKeyboardMarkup
        auth_left = max(0, user.auth_until - now_ts())
        hours = auth_left // 3600
        mins = (auth_left % 3600) // 60
        ms = None
        if user.selected_model:
            from database import get_model_settings as _gms
            ms = _gms(uid, user.selected_model)

        text = (
            f"📋 <b>세션 관리</b>\n\n"
            f"🔐 인증: {'✅ 유효' if auth_left > 0 else '❌ 만료'}\n"
            f"⏱ 남은 시간: {hours}시간 {mins}분\n"
            f"🤖 모델: {user.selected_model or '(미선택)'}\n"
            f"💬 시스템 프롬프트: {'커스텀' if user.system_prompt else '기본값'}\n"
            f"🧠 Think 모드: {'ON' if user.think_mode else 'OFF'}\n"
            f"📝 컨텍스트: {user.context_turns}턴 / TTL {user.context_ttl_sec}s"
        )
        if ms:
            text += (
                f"\n\n<b>모델 파라미터:</b>\n"
                f"  temperature: {ms.temperature} | top_p: {ms.top_p}\n"
                f"  num_ctx: {ms.num_ctx:,} | num_predict: {ms.num_predict:,}"
            )

        await q.edit_message_text(
            text,
            parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup([
                [
                    InlineKeyboardButton("🔄 세션 연장 (+24h)", callback_data="session:extend"),
                    InlineKeyboardButton("🗑 컨텍스트 초기화", callback_data="clear_ctx"),
                ],
                [InlineKeyboardButton("🏠 메뉴", callback_data="cmd:menu")],
            ]),
        )
        return

    if data == "session:extend":
        from config import SESSION_TTL_SEC
        new_until = now_ts() + SESSION_TTL_SEC
        update_user(uid, auth_until=new_until)
        hours = SESSION_TTL_SEC // 3600
        await q.edit_message_text(
            f"✅ 세션이 {hours}시간 연장되었습니다.",
            reply_markup=main_menu_keyboard(True),
        )
        return

    # ── Ollama admin callbacks ──
    if data.startswith("ollama:"):
        from handlers.admin import handle_ollama_callback
        await handle_ollama_callback(q, uid, data)
        return

    # ── Settings callbacks ──
    if data.startswith("set_"):
        from handlers.settings import handle_settings_callback
        await handle_settings_callback(q, uid, data, user)
        return
