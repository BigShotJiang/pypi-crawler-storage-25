"""Chat handler – text, image, document, audio, video message processing."""

from __future__ import annotations

import base64
import json
import re
import time
from typing import Optional

from telegram import Update
from telegram.ext import ContextTypes

from auth import hash_password, require_auth, verify_password
from config import (
    DEFAULT_MODEL,
    DEFAULT_SYSTEM_PROMPT,
    LOGIN_LOCK_SEC,
    LOGIN_MAX_FAILS,
    SESSION_TTL_SEC,
    TOOL_MAX_ITERATIONS,
)
from database import (
    clear_context,
    get_admin_password_hash,
    get_model_settings,
    get_user,
    is_authed,
    is_login_locked,
    load_context,
    now_ts,
    save_context,
    set_admin_password_hash,
    update_user,
)
from handlers.commands import main_menu_keyboard
from ollama_client import (
    chat_stream,
    chat_with_ollama,
    chat_with_ollama_full,
    ensure_ollama_running,
    fetch_models,
    get_model_capabilities,
    model_supports_images,
    model_supports_tools,
    model_supports_thinking,
    summarize_context,
)
from tools import execute_tool, format_tools_for_ollama
from utils.file_processor import (
    detect_file_type,
    process_audio,
    process_pdf,
    process_text_file,
    process_video,
)
from utils.formatting import reply_llm_answer
from utils.streaming import stream_response_to_message


# ── Helpers ───────────────────────────────────────────────

def _build_messages(
    system_prompt: str,
    ctx_items: list[dict],
    user_text: str,
    summary: str = "",
) -> list[dict]:
    """Build the messages array for Ollama."""
    messages = [{"role": "system", "content": system_prompt}]
    if summary:
        messages.append({"role": "system", "content": f"이전 대화 요약:\n{summary}"})
    for item in ctx_items:
        messages.append({"role": "user", "content": item.get("u", "")})
        messages.append({"role": "assistant", "content": item.get("a", "")})
    messages.append({"role": "user", "content": user_text})
    return messages


def _estimate_tokens(char_count: int) -> int:
    """Rough token estimate: ~3.5 chars per token for Korean/mixed."""
    return max(1, char_count // 3)


def _estimate_messages_tokens(system_prompt: str, ctx_items: list[dict], user_text: str, summary: str = "") -> int:
    """Estimate total tokens for the full message payload."""
    total = len(system_prompt)
    if summary:
        total += len(summary)
    for item in ctx_items:
        total += len(item.get("u", "")) + len(item.get("a", ""))
    total += len(user_text)
    return _estimate_tokens(total)


def _context_status_bar(used_tokens: int, max_tokens: int) -> str:
    """Build a compact context usage indicator."""
    if max_tokens <= 0:
        return ""
    pct = min(used_tokens / max_tokens * 100, 100)
    filled = int(pct / 10)
    bar = "█" * filled + "░" * (10 - filled)
    return f"📊 {bar} {pct:.0f}% ({used_tokens:,}/{max_tokens:,} tokens)"


async def _maybe_summarize(
    uid: int, model: str, ctx_items: list[dict],
    num_ctx: int = 8192, system_prompt: str = "", user_text: str = "",
) -> tuple[list[dict], str]:
    """If context approaches num_ctx limit, summarize older turns.

    Triggers when estimated tokens exceed 60% of num_ctx,
    leaving room for the model's response (num_predict).
    """
    if not ctx_items or len(ctx_items) < 3:
        return ctx_items, ""

    # Calculate threshold: 60% of num_ctx (reserve 40% for response + overhead)
    threshold = int(num_ctx * 0.6)
    est_tokens = _estimate_messages_tokens(system_prompt, ctx_items, user_text)

    print(f"[context] est_tokens={est_tokens}, threshold={threshold} (num_ctx={num_ctx})")

    if est_tokens < threshold:
        return ctx_items, ""

    # Split: summarize older 2/3, keep recent 1/3
    split_at = max(1, len(ctx_items) * 2 // 3)
    old_items = ctx_items[:split_at]
    recent_items = ctx_items[split_at:]

    old_text = "\n".join(
        f"User: {it.get('u', '')}\nAssistant: {it.get('a', '')}" for it in old_items
    )

    try:
        summary = await summarize_context(model, old_text)
        print(f"[context] compressed {len(old_items)} turns → summary ({len(summary)} chars), keeping {len(recent_items)} recent turns")
        return recent_items, summary
    except Exception as e:
        print(f"[context] summarize failed: {e}")
        return ctx_items, ""


async def _handle_tool_calls(
    uid: int,
    model: str,
    messages: list[dict],
    tool_calls: list[dict],
    settings,
    think: bool,
    tools: list[dict] | None = None,
    status_msg=None,
) -> tuple[str, list[str], dict]:
    """Execute tool calls in a multi-turn loop until the model produces a final text answer.

    The model may call tools multiple times (e.g. list → read → search) before
    composing a final response. We keep looping until:
      - The model returns text content without new tool_calls, OR
      - TOOL_MAX_ITERATIONS is reached.

    Returns: (answer_text, image_paths, usage_info)
    """
    current_messages = list(messages)
    image_paths: list[str] = []
    pending_tool_calls = tool_calls
    total_prompt_tokens = 0
    total_completion_tokens = 0

    for iteration in range(TOOL_MAX_ITERATIONS):
        if not pending_tool_calls:
            break

        # Execute each tool call in this round
        tool_names_this_round = []
        for tc in pending_tool_calls:
            func = tc.get("function", {})
            tool_name = func.get("name", "")
            tool_names_this_round.append(tool_name)
            try:
                tool_args = func.get("arguments", {})
                if isinstance(tool_args, str):
                    tool_args = json.loads(tool_args)
            except Exception:
                tool_args = {}

            # Inject user_id for tools that need it
            if tool_name in ("image_edit",):
                tool_args["_user_id"] = uid

            result = await execute_tool(tool_name, tool_args, uid)

            # Extract image paths from tool result
            for match in re.finditer(r"\[IMAGE:(.*?)\]", result):
                img_path = match.group(1).strip()
                if img_path:
                    image_paths.append(img_path)

            current_messages.append({
                "role": "assistant",
                "content": "",
                "tool_calls": [tc],
            })
            current_messages.append({
                "role": "tool",
                "content": result,
            })

        print(f"[chat] tool loop iteration {iteration + 1}: executed {tool_names_this_round}")

        # Update status message
        if status_msg:
            try:
                await status_msg.edit_text(
                    f"🔧 도구 실행 중... (라운드 {iteration + 1}, {', '.join(tool_names_this_round)})"
                )
            except Exception:
                pass

        # On the last iteration, omit tools to force a final text answer
        is_last = iteration >= TOOL_MAX_ITERATIONS - 1
        iter_tools = None if is_last else tools

        if is_last:
            # Add instruction to produce a final answer
            current_messages.append({
                "role": "system",
                "content": "지금까지 수집한 도구 결과를 종합하여 사용자 질문에 최종 답변을 작성하세요.",
            })
            print(f"[chat] tool loop: last iteration ({iteration + 1}), forcing final answer")

        # Ask model for next step (may be more tool calls or final answer)
        try:
            resp = await chat_with_ollama_full(
                model, current_messages, settings=settings, tools=iter_tools, think=think
            )
        except Exception as e:
            usage = {"prompt_tokens": total_prompt_tokens, "completion_tokens": total_completion_tokens}
            return f"도구 호출 후 응답 실패: {e}", image_paths, usage

        total_prompt_tokens += resp.get("prompt_tokens", 0)
        total_completion_tokens += resp.get("completion_tokens", 0)
        content = resp.get("content", "")
        new_tool_calls = resp.get("tool_calls", [])

        print(f"[chat] tool loop iteration {iteration + 1} result: content_len={len(content)}, new_tool_calls={len(new_tool_calls)}")

        if new_tool_calls and not is_last:
            # Model wants to call more tools — continue loop
            pending_tool_calls = new_tool_calls
            if content:
                current_messages.append({"role": "assistant", "content": content})
            continue

        # Final answer (either model chose to stop, or we forced it on last iteration)
        usage = {"prompt_tokens": total_prompt_tokens, "completion_tokens": total_completion_tokens}
        if content:
            return content, image_paths, usage

        # Model returned empty — use last tool result as fallback
        last_tool_msg = [m for m in current_messages if m.get("role") == "tool"]
        if last_tool_msg:
            return last_tool_msg[-1].get("content", "도구 결과를 확인하세요."), image_paths, usage
        return "도구 실행 완료 (모델 응답 없음)", image_paths, usage

    # Should not reach here, but safety net
    usage = {"prompt_tokens": total_prompt_tokens, "completion_tokens": total_completion_tokens}
    return "도구 실행 완료", image_paths, usage


# ── State machine handlers (password flows) ───────────────

async def _handle_password_flow(update: Update, user, text: str) -> bool:
    """Handle password-related state flows. Returns True if handled."""
    uid = user.telegram_id

    if user.state == "await_password":
        if is_login_locked(user):
            await update.message.reply_text(f"로그인 제한 중: {user.login_lock_until - now_ts()}초")
            return True

        stored_hash = get_admin_password_hash()
        if not stored_hash:
            await update.message.reply_text("서버 비밀번호 미설정")
            return True

        if verify_password(text, stored_hash):
            update_user(uid, auth_until=now_ts() + SESSION_TTL_SEC, state="", login_fail_count=0, login_lock_until=0)
            selected = user.selected_model
            if not selected:
                try:
                    ok, _ = await ensure_ollama_running()
                    if ok:
                        models = await fetch_models()
                        selected = DEFAULT_MODEL if DEFAULT_MODEL in models else (models[0] if models else "")
                        update_user(uid, selected_model=selected)
                except Exception:
                    pass
            await update.message.reply_text(
                f"✅ 인증 성공\n현재 모델: {selected or '(미선택)'}",
                reply_markup=main_menu_keyboard(True),
            )
        else:
            fail = user.login_fail_count + 1
            if fail >= LOGIN_MAX_FAILS:
                update_user(uid, state="", login_fail_count=0, login_lock_until=now_ts() + LOGIN_LOCK_SEC)
                await update.message.reply_text(f"❌ 실패 누적. {LOGIN_LOCK_SEC}초 잠금")
            else:
                update_user(uid, login_fail_count=fail)
                await update.message.reply_text(f"❌ 비밀번호 오류 ({fail}/{LOGIN_MAX_FAILS})")
        return True

    if user.state == "await_current_password_for_change":
        stored_hash = get_admin_password_hash()
        if not stored_hash or not verify_password(text, stored_hash):
            update_user(uid, state="")
            await update.message.reply_text("현재 비밀번호 불일치. /setpassword 재시도")
            return True
        update_user(uid, state="await_new_password")
        await update.message.reply_text("새 비밀번호 입력 (최소 8자)")
        return True

    if user.state == "await_new_password":
        if len(text) < 8:
            await update.message.reply_text("8자 이상 필요")
            return True
        set_admin_password_hash(hash_password(text))
        update_user(uid, state="")
        await update.message.reply_text("✅ 비밀번호 변경 완료")
        return True

    return False


# ── Main chat flow ────────────────────────────────────────

async def _do_chat(
    update: Update,
    user,
    user_text: str,
    images: Optional[list[str]] = None,
    file_context: str = "",
):
    """Core chat function – streaming + tools + think mode."""
    uid = user.telegram_id
    model = user.selected_model

    ok, msg = await ensure_ollama_running()
    if not ok:
        await update.message.reply_text(f"Ollama 연결 실패: {msg}")
        return

    # Build prompt
    if file_context:
        full_text = f"{file_context}\n\n{user_text}" if user_text else file_context
    else:
        full_text = user_text

    system_prompt = user.system_prompt or DEFAULT_SYSTEM_PROMPT
    settings = get_model_settings(uid, model)
    think = bool(user.think_mode) and await model_supports_thinking(model)

    # Context – auto-compact based on num_ctx
    ctx_items = load_context(uid, max_turns=user.context_turns, ttl=user.context_ttl_sec)
    ctx_items, summary = await _maybe_summarize(
        uid, model, ctx_items,
        num_ctx=settings.num_ctx,
        system_prompt=system_prompt,
        user_text=full_text,
    )

    # Tools – filter based on model capabilities
    tools = None
    has_tools = await model_supports_tools(model)
    if has_tools:
        caps = await get_model_capabilities(model)
        has_vision = any(c in caps for c in ("vision", "image", "multimodal"))
        all_tools = format_tools_for_ollama(admin=True)

        # Filter tools based on model capabilities
        tools = []
        for t in all_tools:
            tname = t["function"]["name"]
            # image_edit requires vision capability (model needs to see the image)
            if tname == "image_edit" and not has_vision:
                continue
            tools.append(t)

    print(f"[chat] model={model}, has_tools={has_tools}, tools_count={len(tools) if tools else 0}, think={think}")

    # Augment system prompt with tool instructions and current date
    final_system = system_prompt
    from datetime import datetime, timezone, timedelta
    kst = timezone(timedelta(hours=9))
    today = datetime.now(kst).strftime("%Y-%m-%d %H:%M KST")
    final_system += f"\n\nCurrent date/time: {today}"
    if has_tools:
        tool_names = [t["function"]["name"] for t in tools]
        final_system += (
            f"\n\nYou have access to the following tools: {', '.join(tool_names)}. "
            "When the user asks to search, look up, calculate, execute code, or perform "
            "any task that a tool can handle, you MUST use the appropriate tool. "
            "Do not try to answer real-time or current information questions from memory alone."
        )
        # Image tool prompt translation instruction
        if any(n in tool_names for n in ("image_generate", "image_edit")):
            final_system += (
                "\n\n[CRITICAL: Image Tool Prompt Translation Rule]\n"
                "When calling image_generate or image_edit, the 'prompt' parameter MUST ALWAYS be in English. "
                "If the user's request is in Korean or any non-English language, you MUST translate it to a detailed, "
                "descriptive English prompt before passing it to the tool. "
                "Example: user says '석양이 지는 해변 풍경 그려줘' → prompt: 'a beautiful sunset beach landscape with warm orange and pink sky, "
                "waves gently crashing on the shore, photorealistic, high detail'\n"
                "Always expand short requests into detailed descriptive English prompts for best image quality."
            )

    messages = _build_messages(final_system, ctx_items, full_text, summary)

    # Send placeholder
    placeholder = await update.message.reply_text("💬 생각 중...")

    try:
        # Stream response
        gen = chat_stream(model, messages, images=images, settings=settings, tools=tools, think=think)
        result = await stream_response_to_message(placeholder, gen, think_mode=think)

        answer = result["content"]
        thinking = result.get("thinking", "")
        tool_calls = result.get("tool_calls", [])
        prompt_tokens = result.get("prompt_tokens", 0)
        completion_tokens = result.get("completion_tokens", 0)
        print(f"[chat] stream result: content_len={len(answer)}, thinking_len={len(thinking)}, tool_calls={len(tool_calls)}, tokens={prompt_tokens}+{completion_tokens}")
        if tool_calls:
            print(f"[chat] tool_calls detail: {tool_calls}")

        # Handle tool calls (multi-turn loop)
        if tool_calls:
            await placeholder.edit_text("🔧 도구 실행 중...")
            messages_with_assistant = messages + [{"role": "assistant", "content": answer}]
            answer, tool_image_paths, tool_usage = await _handle_tool_calls(
                uid, model, messages_with_assistant, tool_calls, settings, think,
                tools=tools, status_msg=placeholder,
            )
            prompt_tokens += tool_usage.get("prompt_tokens", 0)
            completion_tokens += tool_usage.get("completion_tokens", 0)
            print(f"[chat] tool result answer_len={len(answer)}, total_tokens={prompt_tokens}+{completion_tokens}: {answer[:200]}")

            # Send generated images via Telegram
            from pathlib import Path as _Path
            for img_path in tool_image_paths:
                try:
                    p = _Path(img_path)
                    if p.exists() and p.stat().st_size > 0:
                        with open(p, "rb") as f:
                            await update.message.reply_photo(photo=f)
                        print(f"[chat] sent image: {img_path}")
                except Exception as img_err:
                    print(f"[chat] failed to send image {img_path}: {img_err}")

            # Display final answer (entity-based)
            from utils.formatting import convert_markdown, split_message, chunks
            try:
                text, entities = convert_markdown(answer)
                parts = split_message(text, entities)
                first_text, first_ents = parts[0]
                await placeholder.edit_text(first_text, entities=first_ents)
                for chunk_text, chunk_ents in parts[1:]:
                    await update.message.reply_text(chunk_text, entities=chunk_ents)
            except Exception:
                plain_parts = chunks(answer)
                await placeholder.edit_text(plain_parts[0])
                for part in plain_parts[1:]:
                    await update.message.reply_text(part)

        if not answer:
            answer = "응답이 비어 있습니다."

    except Exception as e:
        await placeholder.edit_text(f"모델 응답 실패: {e}")
        return

    # Save context
    ctx_entry = {"u": full_text[:2000], "a": answer[:2000]}
    if images:
        ctx_entry["u"] = f"[image] {user_text[:1000]}"
    ctx_items.append(ctx_entry)
    save_context(uid, ctx_items, max_turns=user.context_turns)

    # Show context usage bar
    # Line 1: Accumulated context tokens (what's stored for next turn)
    # Line 2: This response's actual Ollama token usage
    try:
        ctx_est = _estimate_messages_tokens(final_system, ctx_items, "", summary)
        status_bar = _context_status_bar(ctx_est, settings.num_ctx)
        used_tokens = prompt_tokens + completion_tokens
        if used_tokens > 0:
            status_bar += f"\n💬 이번 요청: {prompt_tokens:,} in + {completion_tokens:,} out = {used_tokens:,}"
        status_bar += f"  |  턴: {len(ctx_items)}/{user.context_turns}"
        if status_bar:
            await update.message.reply_text(status_bar)
    except Exception:
        pass


# ── Message handlers ──────────────────────────────────────

async def on_text(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not update.message or not update.effective_user:
        return

    uid = update.effective_user.id
    text = (update.message.text or "").strip()
    user = get_user(uid)

    # Password flows
    if await _handle_password_flow(update, user, text):
        return

    if not is_authed(user):
        await update.message.reply_text("인증 필요: /login", reply_markup=main_menu_keyboard(False))
        return

    if not user.selected_model:
        await update.message.reply_text("먼저 모델을 선택하세요: /models", reply_markup=main_menu_keyboard(True))
        return

    # Group chat: only respond if mentioned or replied to
    if update.message.chat.type in ("group", "supergroup"):
        bot_username = (await context.bot.get_me()).username
        is_mentioned = bot_username and f"@{bot_username}" in text
        is_reply = update.message.reply_to_message and update.message.reply_to_message.from_user and update.message.reply_to_message.from_user.is_bot
        if not is_mentioned and not is_reply:
            return
        if bot_username:
            text = text.replace(f"@{bot_username}", "").strip()

    await _do_chat(update, user, text)


async def on_media(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle images, audio, video."""
    if not update.message or not update.effective_user:
        return

    uid = update.effective_user.id
    user = get_user(uid)

    if not is_authed(user):
        await update.message.reply_text("인증 필요: /login")
        return
    if not user.selected_model:
        await update.message.reply_text("먼저 모델을 선택하세요: /models")
        return

    # Determine file type and get file
    file_id = None
    file_type = "unknown"

    if update.message.photo:
        file_id = update.message.photo[-1].file_id
        file_type = "image"
    elif update.message.audio:
        file_id = update.message.audio.file_id
        file_type = "audio"
    elif update.message.voice:
        file_id = update.message.voice.file_id
        file_type = "audio"
    elif update.message.video:
        file_id = update.message.video.file_id
        file_type = "video"
    elif update.message.video_note:
        file_id = update.message.video_note.file_id
        file_type = "video"
    elif update.message.document:
        file_id = update.message.document.file_id
        mime = update.message.document.mime_type or ""
        fname = update.message.document.file_name or ""
        if mime.startswith("image/"):
            file_type = "image"
        elif mime.startswith("audio/"):
            file_type = "audio"
        elif mime.startswith("video/"):
            file_type = "video"
        else:
            file_type = detect_file_type(mime, fname)

    if not file_id:
        await update.message.reply_text("파일을 찾지 못했습니다.")
        return

    caption = (update.message.caption or "").strip()

    # Check model capabilities
    if file_type == "image":
        supports, reason = await model_supports_images(user.selected_model)
        if not supports:
            await update.message.reply_text(
                f"현재 모델은 이미지를 지원하지 않습니다.\n"
                f"모델: {user.selected_model}\n사유: {reason}\n\n"
                f"👁 표시 모델을 /models 에서 선택하세요."
            )
            return

    try:
        tg_file = await context.bot.get_file(file_id)
        file_bytes = bytes(await tg_file.download_as_bytearray())
    except Exception as e:
        await update.message.reply_text(f"파일 다운로드 실패: {e}")
        return

    # Process by type
    if file_type == "image":
        image_b64 = base64.b64encode(file_bytes).decode("utf-8")
        prompt = caption or "이 이미지를 분석해줘."

        # Save to temp for image_edit tool to use later
        from config import UPLOAD_TEMP_DIR
        from pathlib import Path as _Path
        try:
            upload_dir = _Path(UPLOAD_TEMP_DIR)
            upload_dir.mkdir(parents=True, exist_ok=True)
            # Clean old files for this user
            for old in upload_dir.glob(f"{uid}_*"):
                old.unlink(missing_ok=True)
            ext = ".png"
            if file_bytes[:3] == b'\xff\xd8\xff':
                ext = ".jpg"
            elif file_bytes[:4] == b'\x89PNG':
                ext = ".png"
            elif file_bytes[:4] == b'RIFF':
                ext = ".webp"
            tmp_path = upload_dir / f"{uid}_{int(time.time())}{ext}"
            tmp_path.write_bytes(file_bytes)
            # Include path hint in prompt for the LLM
            prompt += f"\n[업로드된 이미지 경로: {tmp_path}]"
        except Exception as e:
            print(f"[media] failed to save temp image: {e}")

        await _do_chat(update, user, prompt, images=[image_b64])

    elif file_type == "audio":
        audio_b64 = process_audio(file_bytes)
        prompt = caption or "이 오디오의 내용을 분석해줘."
        # Try sending as image (some models handle audio via images field)
        await _do_chat(update, user, prompt, images=[audio_b64])

    elif file_type == "video":
        frames = process_video(file_bytes, max_frames=8)
        if not frames:
            await update.message.reply_text("비디오 프레임 추출 실패. ffmpeg가 설치되어 있는지 확인하세요.")
            return
        prompt = caption or f"이 비디오를 분석해줘. (총 {len(frames)}프레임)"
        await _do_chat(update, user, prompt, images=frames)

    else:
        await update.message.reply_text("지원하지 않는 파일 형식입니다.")


async def on_document(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle non-image documents (PDF, text, code files)."""
    if not update.message or not update.effective_user or not update.message.document:
        return

    uid = update.effective_user.id
    user = get_user(uid)

    if not is_authed(user):
        await update.message.reply_text("인증 필요: /login")
        return
    if not user.selected_model:
        await update.message.reply_text("먼저 모델을 선택하세요: /models")
        return

    doc = update.message.document
    mime = doc.mime_type or ""
    fname = doc.file_name or ""
    file_type = detect_file_type(mime, fname)
    caption = (update.message.caption or "").strip()

    # Image documents are handled by on_media
    if file_type == "image":
        await on_media(update, context)
        return

    try:
        tg_file = await context.bot.get_file(doc.file_id)
        file_bytes = bytes(await tg_file.download_as_bytearray())
    except Exception as e:
        await update.message.reply_text(f"파일 다운로드 실패: {e}")
        return

    if file_type == "pdf":
        supports_img, _ = await model_supports_images(user.selected_model)
        if supports_img:
            images = process_pdf(file_bytes, max_pages=10)
            if not images:
                await update.message.reply_text("PDF 처리 실패. PyMuPDF가 설치되어 있는지 확인하세요.")
                return
            prompt = caption or f"이 PDF 문서를 분석해줘. (총 {len(images)}페이지)"
            await _do_chat(update, user, prompt, images=images)
        else:
            # Fallback: extract text from PDF
            try:
                import fitz
                doc_pdf = fitz.open(stream=file_bytes, filetype="pdf")
                text_parts = []
                for page in doc_pdf:
                    text_parts.append(page.get_text())
                doc_pdf.close()
                pdf_text = "\n".join(text_parts)[:50000]
                file_context = f"[PDF 문서: {fname}]\n```\n{pdf_text}\n```"
                prompt = caption or "이 문서의 내용을 분석해줘."
                await _do_chat(update, user, prompt, file_context=file_context)
            except ImportError:
                await update.message.reply_text("PDF 처리에 PyMuPDF가 필요합니다.")
            except Exception as e:
                await update.message.reply_text(f"PDF 텍스트 추출 실패: {e}")
        return

    if file_type == "text":
        file_context = f"[파일: {fname}]\n{process_text_file(file_bytes, fname)}"
        prompt = caption or "이 파일의 내용을 분석해줘."
        await _do_chat(update, user, prompt, file_context=file_context)
        return

    if file_type == "audio":
        await on_media(update, context)
        return

    if file_type == "video":
        await on_media(update, context)
        return

    # Unknown file type – try as text
    try:
        text_content = file_bytes.decode("utf-8", errors="replace")[:30000]
        file_context = f"[파일: {fname}]\n```\n{text_content}\n```"
        prompt = caption or "이 파일의 내용을 확인해줘."
        await _do_chat(update, user, prompt, file_context=file_context)
    except Exception:
        await update.message.reply_text("지원하지 않는 파일 형식입니다.")
