"""Settings handlers – /settings, /systemprompt, /think."""

from __future__ import annotations

from telegram import InlineKeyboardButton, InlineKeyboardMarkup, Update
from telegram.ext import ContextTypes

from auth import require_auth
from config import DEFAULT_MODEL_PARAMS, DEFAULT_SYSTEM_PROMPT
from database import (
    get_model_settings,
    get_user,
    is_authed,
    reset_model_settings,
    set_model_setting,
    update_user,
)
from ollama_client import get_model_max_context


# ── Settings keyboard ────────────────────────────────────

PARAM_CONFIG = {
    "temperature": {
        "min": 0.0, "max": 2.0, "step": 0.1, "fmt": ".1f", "label": "🌡 Temperature",
        "desc": "창의성 조절. 낮을수록 일관적, 높을수록 다양한 답변",
    },
    "top_p": {
        "min": 0.0, "max": 1.0, "step": 0.05, "fmt": ".2f", "label": "🎯 Top P",
        "desc": "누적 확률 임계값. 낮을수록 확실한 단어만 선택",
    },
    "top_k": {
        "min": 1, "max": 200, "step": 5, "fmt": "d", "label": "🔢 Top K",
        "desc": "후보 단어 수. 낮을수록 집중적, 높을수록 다양",
    },
    "num_ctx": {
        "min": 1024, "max": 262144, "step": None, "fmt": "d", "label": "📏 Context Size",
        "presets": [2048, 4096, 8192, 16384, 32768, 65536, 131072],
        "desc": "입력 컨텍스트 크기 (토큰). 클수록 긴 대화 가능, VRAM 소모↑",
    },
    "num_predict": {
        "min": 128, "max": 16384, "step": None, "fmt": "d", "label": "📝 Max Tokens",
        "presets": [256, 512, 1024, 2048, 4096, 8192],
        "desc": "최대 응답 길이 (토큰). 길수록 상세한 답변 가능",
    },
    "repeat_penalty": {
        "min": 0.5, "max": 2.0, "step": 0.1, "fmt": ".1f", "label": "🔄 Repeat Penalty",
        "desc": "반복 억제. 1.0=없음, 높을수록 같은 말 반복 방지",
    },
    "seed": {
        "min": 0, "max": 999999, "step": 1, "fmt": "d", "label": "🎲 Seed",
        "desc": "난수 시드. 같은 값=같은 결과. 0=랜덤",
    },
}

CONTEXT_TURN_PRESETS = [2, 4, 6, 10, 20, 50]
CONTEXT_TTL_PRESETS = [300, 600, 900, 1800, 3600, 86400]


def settings_keyboard(uid: int, model: str) -> InlineKeyboardMarkup:
    ms = get_model_settings(uid, model)
    user = get_user(uid)
    rows = []

    for key, cfg in PARAM_CONFIG.items():
        val = getattr(ms, key)
        fmt = cfg["fmt"]
        label = cfg["label"]
        display = f"{val:{fmt}}" if isinstance(fmt, str) else str(val)

        if cfg.get("presets"):
            rows.append([InlineKeyboardButton(f"{label}: {display}", callback_data=f"set_preset:{key}")])
        else:
            rows.append([
                InlineKeyboardButton("➖", callback_data=f"set_dec:{key}"),
                InlineKeyboardButton(f"{label}: {display}", callback_data="noop"),
                InlineKeyboardButton("➕", callback_data=f"set_inc:{key}"),
            ])

    # Keep alive
    rows.append([InlineKeyboardButton(f"⏱ Keep Alive: {ms.keep_alive}", callback_data="set_preset:keep_alive")])

    # Context turns
    rows.append([InlineKeyboardButton(f"💬 컨텍스트 턴: {user.context_turns}", callback_data="set_preset:context_turns")])

    # Context TTL
    ttl_display = f"{user.context_ttl_sec}s"
    if user.context_ttl_sec >= 3600:
        ttl_display = f"{user.context_ttl_sec // 3600}h"
    elif user.context_ttl_sec >= 60:
        ttl_display = f"{user.context_ttl_sec // 60}m"
    rows.append([InlineKeyboardButton(f"⏰ 컨텍스트 TTL: {ttl_display}", callback_data="set_preset:context_ttl")])

    rows.append([
        InlineKeyboardButton("🔄 초기화", callback_data="set_reset"),
        InlineKeyboardButton("🏠 메뉴", callback_data="cmd:menu"),
    ])
    return InlineKeyboardMarkup(rows)


def _build_ctx_presets(max_ctx: int = 0) -> list[int]:
    """Build context size presets, adding model-specific large values."""
    base = [2048, 4096, 8192, 16384, 32768, 65536]
    if max_ctx > 65536:
        # Add larger presets up to model max
        candidates = [131072, 262144]
        for v in candidates:
            if v <= max_ctx and v not in base:
                base.append(v)
    return base


def preset_keyboard(param: str, max_ctx: int = 0) -> InlineKeyboardMarkup:
    if param == "num_ctx":
        presets = _build_ctx_presets(max_ctx)
        # Split into rows of 3-4
        rows = []
        for i in range(0, len(presets), 3):
            row = [InlineKeyboardButton(f"{v:,}", callback_data=f"set_val:num_ctx:{v}") for v in presets[i:i+3]]
            rows.append(row)
    elif param == "num_predict":
        presets = PARAM_CONFIG["num_predict"]["presets"]
        rows = [[InlineKeyboardButton(str(v), callback_data=f"set_val:num_predict:{v}") for v in presets[:3]],
                [InlineKeyboardButton(str(v), callback_data=f"set_val:num_predict:{v}") for v in presets[3:]]]
    elif param == "keep_alive":
        presets = ["0", "5m", "15m", "30m", "1h", "24h", "-1"]
        rows = [[InlineKeyboardButton(v, callback_data=f"set_val:keep_alive:{v}") for v in presets[:4]],
                [InlineKeyboardButton(v, callback_data=f"set_val:keep_alive:{v}") for v in presets[4:]]]
    elif param == "context_turns":
        rows = [[InlineKeyboardButton(str(v), callback_data=f"set_val:context_turns:{v}") for v in CONTEXT_TURN_PRESETS[:3]],
                [InlineKeyboardButton(str(v), callback_data=f"set_val:context_turns:{v}") for v in CONTEXT_TURN_PRESETS[3:]]]
    elif param == "context_ttl":
        labels = ["5분", "10분", "15분", "30분", "1시간", "24시간"]
        rows = [[InlineKeyboardButton(labels[i], callback_data=f"set_val:context_ttl:{v}") for i, v in enumerate(CONTEXT_TTL_PRESETS[:3])],
                [InlineKeyboardButton(labels[i+3], callback_data=f"set_val:context_ttl:{v}") for i, v in enumerate(CONTEXT_TTL_PRESETS[3:])]]
    else:
        return InlineKeyboardMarkup([[InlineKeyboardButton("⬅ 돌아가기", callback_data="cmd:settings")]])

    rows.append([InlineKeyboardButton("⬅ 돌아가기", callback_data="cmd:settings")])
    return InlineKeyboardMarkup(rows)


# ── Command handlers ──────────────────────────────────────

async def settings_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = await require_auth(update)
    if not user:
        return

    if not user.selected_model:
        await update.message.reply_text("먼저 모델을 선택하세요: /models")
        return

    # Build parameter description summary
    desc_lines = [f"⚙️ <b>모델 설정: {user.selected_model}</b>\n"]
    for key, cfg in PARAM_CONFIG.items():
        desc_lines.append(f"<b>{cfg['label']}</b>: {cfg.get('desc', '')}")
    desc_lines.append(f"\n<b>⏱ Keep Alive</b>: 모델 메모리 유지 시간 (0=즉시 해제, -1=영구)")
    desc_lines.append(f"<b>💬 컨텍스트 턴</b>: 기억할 최근 대화 수")
    desc_lines.append(f"<b>⏰ 컨텍스트 TTL</b>: 대화 기록 만료 시간")

    await update.message.reply_text(
        "\n".join(desc_lines),
        parse_mode="HTML",
        reply_markup=settings_keyboard(user.telegram_id, user.selected_model),
    )


async def systemprompt_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = await require_auth(update)
    if not user:
        return

    args_text = " ".join(context.args) if context.args else ""

    if not args_text:
        current = user.system_prompt or DEFAULT_SYSTEM_PROMPT
        is_custom = bool(user.system_prompt)
        await update.message.reply_text(
            f"💬 <b>시스템 프롬프트</b>\n\n"
            f"{'🔧 커스텀' if is_custom else '📌 기본값'}:\n<code>{current}</code>\n\n"
            f"변경: /systemprompt set &lt;내용&gt;\n"
            f"초기화: /systemprompt reset",
            parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("🔄 기본값으로 초기화", callback_data="systemprompt:reset")],
                [InlineKeyboardButton("🏠 메뉴", callback_data="cmd:menu")],
            ]),
        )
        return

    if args_text.startswith("reset"):
        update_user(user.telegram_id, system_prompt="")
        await update.message.reply_text("✅ 시스템 프롬프트가 기본값으로 초기화되었습니다.")
        return

    if args_text.startswith("set "):
        new_prompt = args_text[4:].strip()
        if not new_prompt:
            await update.message.reply_text("프롬프트 내용을 입력해주세요.")
            return
        update_user(user.telegram_id, system_prompt=new_prompt)
        await update.message.reply_text(
            f"✅ 시스템 프롬프트 설정 완료:\n<code>{new_prompt[:200]}</code>",
            parse_mode="HTML",
        )
        return

    # Treat entire args as a set command
    update_user(user.telegram_id, system_prompt=args_text)
    await update.message.reply_text(
        f"✅ 시스템 프롬프트 설정 완료:\n<code>{args_text[:200]}</code>",
        parse_mode="HTML",
    )


async def think_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = await require_auth(update)
    if not user:
        return

    arg = (context.args[0] if context.args else "").lower()
    uid = user.telegram_id

    if arg == "on":
        update_user(uid, think_mode=1)
        await update.message.reply_text("💭 Think 모드 ON\n추론 과정이 응답에 표시됩니다.")
    elif arg == "off":
        update_user(uid, think_mode=0)
        await update.message.reply_text("💭 Think 모드 OFF")
    else:
        current = "ON 💭" if user.think_mode else "OFF"
        await update.message.reply_text(
            f"💭 <b>Think 모드: {current}</b>\n\n"
            f"사용법:\n"
            f"• /think on — 추론 과정 표시\n"
            f"• /think off — 추론 과정 숨김",
            parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup([
                [
                    InlineKeyboardButton("💭 ON", callback_data="cmd:think_on"),
                    InlineKeyboardButton("💬 OFF", callback_data="cmd:think_off"),
                ],
                [InlineKeyboardButton("🏠 메뉴", callback_data="cmd:menu")],
            ]),
        )


# ── Callback processing (called from handlers/callbacks.py) ──

async def handle_settings_callback(query, uid: int, data: str, user):
    """Handle set_inc, set_dec, set_val, set_preset, set_reset callbacks."""
    model = user.selected_model
    if not model:
        await query.edit_message_text("먼저 모델을 선택하세요: /models")
        return

    if data == "set_reset":
        reset_model_settings(uid, model)
        await query.edit_message_text(
            f"⚙️ <b>모델 설정: {model}</b>\n🔄 초기화 완료",
            parse_mode="HTML",
            reply_markup=settings_keyboard(uid, model),
        )
        return

    if data.startswith("set_preset:"):
        param = data.split(":", 1)[1]
        extra_info = ""
        max_ctx = 0

        # Get parameter description
        cfg = PARAM_CONFIG.get(param)
        if cfg:
            extra_info = f"\n💡 {cfg.get('desc', '')}"

        # Special info for specific params
        if param == "num_ctx":
            try:
                max_ctx = await get_model_max_context(model)
                if max_ctx > 0:
                    extra_info += f"\n📌 모델 최대 컨텍스트: <b>{max_ctx:,}</b> tokens"
                else:
                    extra_info += "\n📌 모델 최대 컨텍스트: 정보 없음"
            except Exception:
                pass
        elif param == "keep_alive":
            extra_info = "\n💡 모델 메모리 유지 시간. 0=즉시 해제, -1=영구 유지"
        elif param == "context_turns":
            extra_info = "\n💡 기억할 최근 대화 수. 많을수록 맥락 유지, 토큰 소모↑"
        elif param == "context_ttl":
            extra_info = "\n💡 대화 기록 만료 시간. 초과 시 컨텍스트 자동 초기화"

        label = cfg["label"] if cfg else param
        await query.edit_message_text(
            f"⚙️ <b>{label} 값 선택</b>{extra_info}",
            parse_mode="HTML",
            reply_markup=preset_keyboard(param, max_ctx=max_ctx),
        )
        return

    if data.startswith("set_val:"):
        parts = data.split(":", 2)
        param, raw_val = parts[1], parts[2]

        if param == "keep_alive":
            set_model_setting(uid, model, "keep_alive", raw_val)
        elif param == "context_turns":
            update_user(uid, context_turns=int(raw_val))
        elif param == "context_ttl":
            update_user(uid, context_ttl_sec=int(raw_val))
        else:
            cfg = PARAM_CONFIG.get(param)
            if cfg:
                val = float(raw_val) if "." in cfg["fmt"] else int(raw_val)
                set_model_setting(uid, model, param, val)

        await query.edit_message_text(
            f"⚙️ <b>모델 설정: {model}</b>",
            parse_mode="HTML",
            reply_markup=settings_keyboard(uid, model),
        )
        return

    if data.startswith("set_inc:") or data.startswith("set_dec:"):
        action, param = data.split(":", 1)
        cfg = PARAM_CONFIG.get(param)
        if not cfg or not cfg.get("step"):
            return

        ms = get_model_settings(uid, model)
        current = getattr(ms, param)
        step = cfg["step"]

        if action == "set_inc":
            new_val = min(current + step, cfg["max"])
        else:
            new_val = max(current - step, cfg["min"])

        # Round to avoid float drift
        if isinstance(step, float):
            new_val = round(new_val, 2)

        set_model_setting(uid, model, param, new_val)
        await query.edit_message_text(
            f"⚙️ <b>모델 설정: {model}</b>",
            parse_mode="HTML",
            reply_markup=settings_keyboard(uid, model),
        )
