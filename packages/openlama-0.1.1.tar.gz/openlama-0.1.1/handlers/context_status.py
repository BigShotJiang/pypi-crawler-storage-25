"""Context status – detailed view + manual compress."""

from __future__ import annotations

from telegram import InlineKeyboardButton, InlineKeyboardMarkup

from database import get_model_settings, load_context, save_context
from ollama_client import summarize_context


def _estimate_tokens(char_count: int) -> int:
    return max(1, char_count // 3)


def _bar(pct: float, width: int = 20) -> str:
    filled = int(pct / 100 * width)
    return "█" * filled + "░" * (width - filled)


async def build_context_status(uid: int, user) -> tuple[str, InlineKeyboardMarkup]:
    """Build detailed context status text and keyboard."""
    model = user.selected_model or ""
    ms = get_model_settings(uid, model) if model else None
    num_ctx = ms.num_ctx if ms else 8192

    active_items = load_context(uid, max_turns=user.context_turns, ttl=user.context_ttl_sec)

    # Calculate tokens
    sys_prompt_len = len(user.system_prompt or "")
    sys_tokens = _estimate_tokens(sys_prompt_len) if sys_prompt_len else 0

    total_ctx_chars = 0
    turn_details = []
    for i, item in enumerate(active_items):
        u_text = item.get("u", "")
        a_text = item.get("a", "")
        u_tokens = _estimate_tokens(len(u_text))
        a_tokens = _estimate_tokens(len(a_text))
        turn_tokens = u_tokens + a_tokens
        total_ctx_chars += len(u_text) + len(a_text)

        preview = u_text[:40].replace("\n", " ")
        if len(u_text) > 40:
            preview += "…"

        turn_details.append({
            "index": i + 1,
            "u_tokens": u_tokens,
            "a_tokens": a_tokens,
            "total": turn_tokens,
            "preview": preview,
        })

    total_tokens = sys_tokens + _estimate_tokens(total_ctx_chars)
    pct = min(total_tokens / num_ctx * 100, 100) if num_ctx > 0 else 0

    # Build text
    lines = [
        f"📊 <b>컨텍스트 상태</b>\n",
        f"<b>모델:</b> {model or '(미선택)'}",
        f"<b>최대 컨텍스트:</b> {num_ctx:,} tokens",
        f"<b>사용 중 (추정):</b> ~{total_tokens:,} tokens ({pct:.1f}%)",
        f"<b>활성 턴:</b> {len(active_items)}/{user.context_turns} (TTL: {user.context_ttl_sec}s)",
        f"\n{_bar(pct)} {pct:.0f}%\n",
    ]

    if sys_tokens > 0:
        lines.append(f"  💬 시스템 프롬프트: ~{sys_tokens:,} tokens")

    if turn_details:
        lines.append("\n<b>턴 구조:</b>")
        for td in turn_details:
            lines.append(
                f"  {td['index']}. 👤{td['u_tokens']}t + 🤖{td['a_tokens']}t = <b>{td['total']}t</b>"
                f"\n      <code>{td['preview']}</code>"
            )
    else:
        lines.append("\n<i>저장된 컨텍스트 없음</i>")

    if pct >= 80:
        lines.append(f"\n⚠️ 컨텍스트 {pct:.0f}% 사용 — 자동 압축이 곧 실행됩니다")
    elif pct >= 60:
        lines.append(f"\n💡 컨텍스트 {pct:.0f}% — 압축 임계치(60%) 도달")

    text = "\n".join(lines)

    buttons = []
    if len(active_items) >= 2:
        buttons.append(InlineKeyboardButton("🗜 컨텍스트 압축", callback_data="ctx:compress"))
    buttons.append(InlineKeyboardButton("🗑 초기화", callback_data="clear_ctx"))
    kb = InlineKeyboardMarkup([
        buttons,
        [InlineKeyboardButton("🔄 새로고침", callback_data="cmd:context_status")],
        [InlineKeyboardButton("🏠 메뉴", callback_data="cmd:menu")],
    ])

    return text, kb


async def compress_context(uid: int, user) -> str:
    """Manually compress context: summarize older 2/3, keep recent 1/3."""
    model = user.selected_model
    if not model:
        return "모델이 선택되지 않았습니다."

    ctx_items = load_context(uid, max_turns=user.context_turns, ttl=user.context_ttl_sec)
    if len(ctx_items) < 2:
        return "압축할 컨텍스트가 부족합니다. (최소 2턴 필요)"

    split_at = max(1, len(ctx_items) * 2 // 3)
    old_items = ctx_items[:split_at]
    recent_items = ctx_items[split_at:]

    old_text = "\n".join(
        f"User: {it.get('u', '')}\nAssistant: {it.get('a', '')}" for it in old_items
    )

    before_tokens = _estimate_tokens(sum(len(it.get("u", "")) + len(it.get("a", "")) for it in ctx_items))

    try:
        summary = await summarize_context(model, old_text)
    except Exception as e:
        return f"압축 실패: {e}"

    # Save: summary as first turn + recent turns
    compressed = [{"u": "[컨텍스트 요약]", "a": summary}] + recent_items
    save_context(uid, compressed, max_turns=user.context_turns)

    after_tokens = _estimate_tokens(sum(len(it.get("u", "")) + len(it.get("a", "")) for it in compressed))
    saved = before_tokens - after_tokens

    return (
        f"🗜 컨텍스트 압축 완료\n\n"
        f"• 압축 전: {len(ctx_items)}턴, ~{before_tokens:,} tokens\n"
        f"• 압축 후: {len(compressed)}턴, ~{after_tokens:,} tokens\n"
        f"• 절약: ~{saved:,} tokens ({saved / max(before_tokens, 1) * 100:.0f}%)\n"
        f"• 요약된 턴: {len(old_items)}턴 → 1턴 요약\n"
        f"• 유지된 턴: {len(recent_items)}턴"
    )
