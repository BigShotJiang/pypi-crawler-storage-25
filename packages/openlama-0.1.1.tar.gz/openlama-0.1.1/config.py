"""Global configuration – all environment variables and constants."""

import os
from pathlib import Path

# ── Telegram ──────────────────────────────────────────────
BOT_TOKEN: str = os.environ.get("TELEGRAM_BOT_TOKEN", "")
ADMIN_PASSWORD: str = os.environ.get("BOT_ADMIN_PASSWORD", "")

# ── Database ──────────────────────────────────────────────
DB_PATH: Path = Path(
    os.environ.get(
        "BOT_DB_PATH",
        str(Path(__file__).resolve().parent / "bot.db"),
    )
)

# ── Ollama ────────────────────────────────────────────────
OLLAMA_BASE: str = os.environ.get("OLLAMA_BASE", "http://127.0.0.1:11434")
DEFAULT_MODEL: str = os.environ.get("DEFAULT_MODEL", "gemma4:26b")
OLLAMA_TIMEOUT_SEC: int = int(os.environ.get("OLLAMA_TIMEOUT_SEC", "120"))
OLLAMA_STARTUP_WAIT_SEC: int = int(os.environ.get("OLLAMA_STARTUP_WAIT_SEC", "30"))
PM2_BIN: str = os.environ.get("PM2_BIN", "pm2")

# ── Auth / Session ────────────────────────────────────────
SESSION_TTL_SEC: int = int(os.environ.get("SESSION_TTL_SEC", str(24 * 60 * 60)))
LOGIN_MAX_FAILS: int = int(os.environ.get("LOGIN_MAX_FAILS", "5"))
LOGIN_LOCK_SEC: int = int(os.environ.get("LOGIN_LOCK_SEC", "600"))

# ── Context ───────────────────────────────────────────────
DEFAULT_CONTEXT_TURNS: int = int(os.environ.get("CONTEXT_TURNS", "6"))
DEFAULT_CONTEXT_TTL_SEC: int = int(os.environ.get("CONTEXT_TTL_SEC", "900"))

# ── Streaming ─────────────────────────────────────────────
STREAMING_EDIT_INTERVAL: float = float(os.environ.get("STREAMING_EDIT_INTERVAL", "1.5"))
STREAMING_MIN_DELTA: int = int(os.environ.get("STREAMING_MIN_DELTA", "20"))

# ── Model display ─────────────────────────────────────────
MODEL_PAGE_SIZE: int = 8
MODEL_VISION_CACHE_TTL_SEC: int = int(os.environ.get("MODEL_VISION_CACHE_TTL_SEC", "3600"))

# ── Tool Calling ──────────────────────────────────────────
TOOL_SANDBOX_PATH: str = os.environ.get(
    "TOOL_SANDBOX_PATH",
    str(Path.home() / "workspace" / "sandbox"),
)
TOOL_SANDBOX_ENABLED: bool = os.environ.get("TOOL_SANDBOX_ENABLED", "true").lower() in ("true", "1", "yes")
CODE_EXECUTION_TIMEOUT: int = int(os.environ.get("CODE_EXECUTION_TIMEOUT", "30"))
TOOL_MAX_ITERATIONS: int = int(os.environ.get("TOOL_MAX_ITERATIONS", "20"))
DUCKDUCKGO_MAX_RESULTS: int = int(os.environ.get("DUCKDUCKGO_MAX_RESULTS", "5"))

# ── ComfyUI ───────────────────────────────────────────────
COMFY_BASE: str = os.environ.get("COMFY_BASE", "http://127.0.0.1:8184")
COMFY_TIMEOUT_SEC: int = int(os.environ.get("COMFY_TIMEOUT_SEC", "300"))
COMFY_OUTPUT_DIR: str = os.environ.get(
    "COMFY_OUTPUT_DIR",
    str(Path.home() / "Documents" / "ComfyUI" / "output"),
)
COMFY_STEPS: int = int(os.environ.get("COMFY_STEPS", "4"))
COMFY_CFG: float = float(os.environ.get("COMFY_CFG", "1.0"))
COMFY_DENOISE: float = float(os.environ.get("COMFY_DENOISE", "1.0"))

# Temp dir for user-uploaded images (used by image_edit tool)
UPLOAD_TEMP_DIR: str = os.environ.get(
    "UPLOAD_TEMP_DIR",
    str(Path(__file__).resolve().parent / "tmp_uploads"),
)

# ── Context summarization ─────────────────────────────────
SUMMARY_THRESHOLD_TOKENS: int = int(os.environ.get("SUMMARY_THRESHOLD_TOKENS", "100000"))
MAX_FILE_READ_CHARS: int = int(os.environ.get("MAX_FILE_READ_CHARS", "50000"))

# ── Telegram limits ────────────────────────────────────────
TELEGRAM_MAX_MSG: int = 4096

# ── Default system prompt ─────────────────────────────────
DEFAULT_SYSTEM_PROMPT: str = "짧고 명확하게 한국어로 답변하라."

# ── Default model parameters ───��──────────────────────────
DEFAULT_MODEL_PARAMS: dict = {
    "temperature": 0.7,
    "top_p": 0.95,
    "top_k": 64,
    "num_ctx": 8192,
    "num_predict": 4096,
    "repeat_penalty": 1.0,
    "seed": 0,
    "keep_alive": "30m",
}
