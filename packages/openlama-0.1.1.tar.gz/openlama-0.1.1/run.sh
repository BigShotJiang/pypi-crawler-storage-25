#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

if [[ -f .env ]]; then
  set -a
  source .env
  set +a
else
  echo "[오류] .env 파일이 없습니다. .env.example을 복사해 설정하세요." >&2
  exit 1
fi

source .venv/bin/activate
exec python3 -u bot.py
