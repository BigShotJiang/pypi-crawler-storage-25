"""Ollama API client – chat, streaming, model management, tool support."""

from __future__ import annotations

import asyncio
import json
import subprocess
import time
from typing import Any, AsyncGenerator, Optional

import httpx

from config import (
    DEFAULT_MODEL_PARAMS,
    MODEL_VISION_CACHE_TTL_SEC,
    OLLAMA_BASE,
    OLLAMA_STARTUP_WAIT_SEC,
    OLLAMA_TIMEOUT_SEC,
    PM2_BIN,
)
from database import ModelSettings, now_ts

# ── In-memory caches ─────────────────────────────────────

PULL_STATE: dict[int, dict] = {}
MODEL_VISION_CACHE: dict[str, dict] = {}
MODEL_CAPS_CACHE: dict[str, dict] = {}  # {model: {"caps": [...], "ts": int}}


# ── Health check / PM2 ───────────────────────────────────

async def ollama_alive() -> bool:
    try:
        async with httpx.AsyncClient(timeout=3) as client:
            r = await client.get(f"{OLLAMA_BASE}/api/tags")
            return r.status_code == 200
    except Exception:
        return False


def pm2_restart_ollama() -> tuple[bool, str]:
    try:
        out = subprocess.check_output([PM2_BIN, "jlist"], text=True, stderr=subprocess.STDOUT)
        arr = json.loads(out)
    except Exception as e:
        return False, f"pm2 접근 실패: {e}"

    candidates = []
    for p in arr:
        name = (p.get("name") or "").lower()
        script = (p.get("pm2_env", {}).get("pm_exec_path") or "").lower()
        if "ollama" in name or "ollama" in script:
            candidates.append(p)

    if not candidates:
        return False, "pm2에서 ollama 프로세스를 찾지 못함"

    for p in candidates:
        target = str(p.get("pm_id", p.get("name", "")))
        try:
            subprocess.check_output([PM2_BIN, "restart", target], text=True, stderr=subprocess.STDOUT)
            return True, f"pm2 restart 성공: {target}"
        except Exception as e:
            last_err = str(e)

    return False, f"pm2 restart 실패: {last_err}"


async def ensure_ollama_running() -> tuple[bool, str]:
    if await ollama_alive():
        return True, "alive"
    ok, msg = pm2_restart_ollama()
    if not ok:
        return False, msg
    deadline = time.time() + OLLAMA_STARTUP_WAIT_SEC
    while time.time() < deadline:
        if await ollama_alive():
            return True, msg
        await asyncio.sleep(1)
    return False, "ollama 재시작 후 응답 없음"


# ── Model listing ─────────────────────────────────────────

async def fetch_models() -> list[str]:
    async with httpx.AsyncClient(timeout=10) as client:
        r = await client.get(f"{OLLAMA_BASE}/api/tags")
        r.raise_for_status()
        data = r.json()
    models = [m.get("name", "") for m in data.get("models", []) if m.get("name")]
    models.sort()
    return models


async def fetch_models_detailed() -> list[dict]:
    async with httpx.AsyncClient(timeout=10) as client:
        r = await client.get(f"{OLLAMA_BASE}/api/tags")
        r.raise_for_status()
        data = r.json()
    return data.get("models", [])


async def get_running_models() -> list[dict]:
    try:
        async with httpx.AsyncClient(timeout=5) as client:
            r = await client.get(f"{OLLAMA_BASE}/api/ps")
            r.raise_for_status()
            return r.json().get("models", [])
    except Exception:
        return []


# ── Model capabilities ───────────────────────────────────

async def get_model_capabilities(model: str) -> list[str]:
    """Get model capabilities list (vision, tools, etc.)."""
    now = now_ts()
    cached = MODEL_CAPS_CACHE.get(model)
    if cached and (now - cached.get("ts", 0)) <= MODEL_VISION_CACHE_TTL_SEC:
        return cached.get("caps", [])

    caps = []
    try:
        async with httpx.AsyncClient(timeout=15) as client:
            r = await client.post(f"{OLLAMA_BASE}/api/show", json={"name": model})
            r.raise_for_status()
            data = r.json()

        raw_caps = data.get("capabilities")
        if isinstance(raw_caps, list):
            caps = [str(c).lower() for c in raw_caps]
        elif isinstance(raw_caps, dict):
            flat = json.dumps(raw_caps, ensure_ascii=False).lower()
            for kw in ("vision", "image", "multimodal", "tools", "thinking", "audio"):
                if kw in flat:
                    caps.append(kw)
    except Exception:
        pass

    MODEL_CAPS_CACHE[model] = {"caps": caps, "ts": now}
    return caps


async def model_supports_images(model: str) -> tuple[bool, str]:
    caps = await get_model_capabilities(model)
    if any(c in caps for c in ("vision", "image", "multimodal")):
        return True, "capabilities에서 vision 확인"

    # Probe fallback
    ok, reason = await _probe_model_image_support(model)
    if ok:
        cached = MODEL_CAPS_CACHE.get(model, {"caps": [], "ts": now_ts()})
        cached["caps"] = list(set(cached.get("caps", []) + ["vision"]))
        MODEL_CAPS_CACHE[model] = cached
    return ok, reason


async def model_supports_tools(model: str) -> bool:
    caps = await get_model_capabilities(model)
    return "tools" in caps


async def model_supports_thinking(model: str) -> bool:
    caps = await get_model_capabilities(model)
    return "thinking" in caps


async def _probe_model_image_support(model: str) -> tuple[bool, str]:
    tiny_png_b64 = "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO5Y6xkAAAAASUVORK5CYII="
    payload = {
        "model": model,
        "messages": [{"role": "user", "content": "Describe.", "images": [tiny_png_b64]}],
        "stream": False,
    }
    try:
        async with httpx.AsyncClient(timeout=15) as client:
            r = await client.post(f"{OLLAMA_BASE}/api/chat", json=payload)
            if r.status_code >= 400:
                msg = r.text.lower()
                if any(k in msg for k in ("does not support", "not support", "vision", "image")):
                    return False, "이미지 미지원"
                return False, f"probe 실패: http {r.status_code}"
            data = r.json()
            content = ((data.get("message") or {}).get("content") or "").strip()
            return (True, "probe 성공") if content else (False, "probe 응답 비어있음")
    except Exception as e:
        return False, f"probe 예외: {e}"


async def get_model_max_context(model: str) -> int:
    """Get model's maximum context length from Ollama model info."""
    try:
        info = await get_model_info(model)
        # Check model_info field (contains training parameters)
        model_info = info.get("model_info", {})
        for key, val in model_info.items():
            if "context_length" in key.lower() and isinstance(val, (int, float)):
                return int(val)
        # Fallback: check parameters string
        params_str = info.get("parameters", "")
        if params_str:
            for line in params_str.split("\n"):
                if "num_ctx" in line.lower():
                    parts = line.strip().split()
                    if len(parts) >= 2:
                        try:
                            return int(parts[-1])
                        except ValueError:
                            pass
    except Exception:
        pass
    return 0  # Unknown


async def get_model_display_map(models: list[str]) -> dict[str, str]:
    display: dict[str, str] = {}
    for m in models:
        caps = await get_model_capabilities(m)
        badges = []
        if any(c in caps for c in ("vision", "image", "multimodal")):
            badges.append("👁")
        if "tools" in caps:
            badges.append("🔧")
        if "thinking" in caps:
            badges.append("💭")
        if not badges:
            badges.append("💬")
        display[m] = f"{''.join(badges)} {m}"
    return display


# ── Chat ──────────────────────────────────────────────────

def _build_options(settings: ModelSettings) -> dict:
    opts = {}
    defaults = DEFAULT_MODEL_PARAMS
    if settings.temperature != defaults["temperature"]:
        opts["temperature"] = settings.temperature
    if settings.top_p != defaults["top_p"]:
        opts["top_p"] = settings.top_p
    if settings.top_k != defaults["top_k"]:
        opts["top_k"] = settings.top_k
    if settings.num_ctx != defaults["num_ctx"]:
        opts["num_ctx"] = settings.num_ctx
    if settings.num_predict != defaults["num_predict"]:
        opts["num_predict"] = settings.num_predict
    if settings.repeat_penalty != defaults["repeat_penalty"]:
        opts["repeat_penalty"] = settings.repeat_penalty
    if settings.seed != defaults["seed"]:
        opts["seed"] = settings.seed
    # Always include num_ctx and num_predict for explicit control
    opts.setdefault("num_ctx", settings.num_ctx)
    opts.setdefault("num_predict", settings.num_predict)
    return opts


async def chat_with_ollama(
    model: str,
    messages: list[dict],
    images: Optional[list[str]] = None,
    settings: Optional[ModelSettings] = None,
    tools: Optional[list[dict]] = None,
    think: bool = False,
) -> str:
    """Non-streaming chat. Returns response text."""
    payload_messages = [dict(m) for m in messages]
    if images:
        for i in range(len(payload_messages) - 1, -1, -1):
            if payload_messages[i].get("role") == "user":
                payload_messages[i]["images"] = images
                break

    payload: dict[str, Any] = {"model": model, "messages": payload_messages, "stream": False}
    if settings:
        opts = _build_options(settings)
        if opts:
            payload["options"] = opts
        if settings.keep_alive != DEFAULT_MODEL_PARAMS["keep_alive"]:
            payload["keep_alive"] = settings.keep_alive
    if tools:
        payload["tools"] = tools
    if think:
        payload["think"] = True

    async with httpx.AsyncClient(timeout=OLLAMA_TIMEOUT_SEC) as client:
        r = await client.post(f"{OLLAMA_BASE}/api/chat", json=payload)
        r.raise_for_status()
        data = r.json()

    msg = data.get("message") or {}
    return msg.get("content", "").strip()


async def chat_with_ollama_full(
    model: str,
    messages: list[dict],
    settings: Optional[ModelSettings] = None,
    tools: Optional[list[dict]] = None,
    think: bool = False,
) -> dict:
    """Non-streaming chat returning full message (content + tool_calls).

    Returns: {"content": str, "tool_calls": list}
    """
    payload_messages = [dict(m) for m in messages]
    payload: dict[str, Any] = {"model": model, "messages": payload_messages, "stream": False}
    if settings:
        opts = _build_options(settings)
        if opts:
            payload["options"] = opts
        if settings.keep_alive != DEFAULT_MODEL_PARAMS["keep_alive"]:
            payload["keep_alive"] = settings.keep_alive
    if tools:
        payload["tools"] = tools
    if think:
        payload["think"] = True

    async with httpx.AsyncClient(timeout=OLLAMA_TIMEOUT_SEC) as client:
        r = await client.post(f"{OLLAMA_BASE}/api/chat", json=payload)
        r.raise_for_status()
        data = r.json()

    msg = data.get("message") or {}
    return {
        "content": msg.get("content", "").strip(),
        "tool_calls": msg.get("tool_calls", []),
        "prompt_tokens": data.get("prompt_eval_count", 0),
        "completion_tokens": data.get("eval_count", 0),
    }


async def chat_stream(
    model: str,
    messages: list[dict],
    images: Optional[list[str]] = None,
    settings: Optional[ModelSettings] = None,
    tools: Optional[list[dict]] = None,
    think: bool = False,
) -> AsyncGenerator[dict, None]:
    """Streaming chat. Yields parsed JSON chunks."""
    payload_messages = [dict(m) for m in messages]
    if images:
        for i in range(len(payload_messages) - 1, -1, -1):
            if payload_messages[i].get("role") == "user":
                payload_messages[i]["images"] = images
                break

    payload: dict[str, Any] = {"model": model, "messages": payload_messages, "stream": True}
    if settings:
        opts = _build_options(settings)
        if opts:
            payload["options"] = opts
        if settings.keep_alive != DEFAULT_MODEL_PARAMS["keep_alive"]:
            payload["keep_alive"] = settings.keep_alive
    if tools:
        payload["tools"] = tools
    if think:
        payload["think"] = True

    timeout = httpx.Timeout(connect=10, read=None, write=30, pool=30)
    async with httpx.AsyncClient(timeout=timeout) as client:
        async with client.stream("POST", f"{OLLAMA_BASE}/api/chat", json=payload) as resp:
            resp.raise_for_status()
            async for line in resp.aiter_lines():
                if not line:
                    continue
                try:
                    yield json.loads(line)
                except Exception:
                    continue


# ── Model management ──────────────────────────────────────

async def get_model_info(model: str) -> dict:
    async with httpx.AsyncClient(timeout=15) as client:
        r = await client.post(f"{OLLAMA_BASE}/api/show", json={"name": model})
        r.raise_for_status()
        return r.json()


async def copy_model(source: str, dest: str):
    async with httpx.AsyncClient(timeout=30) as client:
        r = await client.post(f"{OLLAMA_BASE}/api/copy", json={"source": source, "destination": dest})
        r.raise_for_status()


async def delete_model(model: str):
    async with httpx.AsyncClient(timeout=30) as client:
        r = await client.request("DELETE", f"{OLLAMA_BASE}/api/delete", json={"name": model})
        if r.status_code == 405:
            r = await client.post(f"{OLLAMA_BASE}/api/delete", json={"name": model})
        r.raise_for_status()


async def unload_model(model: str):
    try:
        async with httpx.AsyncClient(timeout=10) as client:
            await client.post(
                f"{OLLAMA_BASE}/api/generate",
                json={"model": model, "keep_alive": 0},
            )
    except Exception:
        pass


# ── Pull (streaming progress) ────────────────────────────

def get_pull_state(uid: int) -> Optional[dict]:
    return PULL_STATE.get(uid)


def set_pull_state(uid: int, **kwargs):
    cur = PULL_STATE.get(uid, {})
    cur.update(kwargs)
    cur["updated_at"] = now_ts()
    PULL_STATE[uid] = cur


async def pull_model_stream(uid: int, model: str):
    set_pull_state(uid, status="running", model=model, progress=0, detail="시작", started_at=now_ts())
    try:
        ok, msg = await ensure_ollama_running()
        if not ok:
            set_pull_state(uid, status="failed", detail=f"Ollama 연결 실패: {msg}")
            return

        timeout = httpx.Timeout(connect=10, read=None, write=30, pool=30)
        async with httpx.AsyncClient(timeout=timeout) as client:
            async with client.stream("POST", f"{OLLAMA_BASE}/api/pull", json={"name": model, "stream": True}) as resp:
                resp.raise_for_status()
                async for line in resp.aiter_lines():
                    if not line:
                        continue
                    try:
                        obj = json.loads(line)
                    except Exception:
                        continue

                    if obj.get("error"):
                        set_pull_state(uid, status="failed", detail=str(obj.get("error")))
                        return

                    status = obj.get("status") or "진행 중"
                    total = obj.get("total")
                    completed = obj.get("completed")
                    progress = None
                    if isinstance(total, int) and total > 0 and isinstance(completed, int):
                        progress = max(0, min(100, int((completed / total) * 100)))

                    set_pull_state(
                        uid,
                        status="running",
                        detail=status,
                        progress=progress if progress is not None else PULL_STATE.get(uid, {}).get("progress", 0),
                    )

                    if obj.get("status") == "success":
                        set_pull_state(uid, status="done", detail="설치 완료", progress=100, finished_at=now_ts())
                        return

        st = get_pull_state(uid) or {}
        if st.get("status") == "running":
            set_pull_state(uid, status="done", detail="설치 완료", progress=100, finished_at=now_ts())
    except Exception as e:
        set_pull_state(uid, status="failed", detail=str(e)[:300])


# ── Context summarization ─────────────────────────────────

async def summarize_context(model: str, conversation_text: str) -> str:
    """Summarize a conversation for context compression."""
    messages = [
        {"role": "system", "content": "주어진 대화를 핵심 내용만 간결하게 요약하라. 중요한 사실, 결정, 코드, 지시사항을 보존하라. 300자 이내로 요약하라."},
        {"role": "user", "content": conversation_text},
    ]
    payload = {
        "model": model,
        "messages": messages,
        "stream": False,
        "options": {"num_predict": 512, "temperature": 0.3},
    }
    async with httpx.AsyncClient(timeout=OLLAMA_TIMEOUT_SEC) as client:
        r = await client.post(f"{OLLAMA_BASE}/api/chat", json=payload)
        r.raise_for_status()
        data = r.json()
    return (data.get("message") or {}).get("content", "").strip()
