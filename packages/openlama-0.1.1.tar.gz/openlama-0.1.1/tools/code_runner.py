"""Tool: code_execute – run code in Python, Node.js, or Shell."""

import asyncio
import subprocess
import tempfile
from pathlib import Path

from config import CODE_EXECUTION_TIMEOUT
from tools.registry import register_tool


async def _execute(args: dict) -> str:
    language = args.get("language", "python").lower()
    code = args.get("code", "").strip()
    if not code:
        return "실행할 코드를 입력해주세요."

    runners = {
        "python": ("python3", ".py"),
        "node": ("node", ".js"),
        "nodejs": ("node", ".js"),
        "javascript": ("node", ".js"),
        "js": ("node", ".js"),
        "shell": ("bash", ".sh"),
        "bash": ("bash", ".sh"),
        "sh": ("sh", ".sh"),
        "zsh": ("zsh", ".zsh"),
    }

    if language not in runners:
        return f"지원하지 않는 언어: {language}. 지원: python, node/js, shell/bash"

    cmd, ext = runners[language]

    try:
        with tempfile.NamedTemporaryFile(mode="w", suffix=ext, delete=False) as f:
            f.write(code)
            tmp_path = f.name

        proc = await asyncio.create_subprocess_exec(
            cmd, tmp_path,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            cwd=tempfile.gettempdir(),
        )

        try:
            stdout, stderr = await asyncio.wait_for(
                proc.communicate(), timeout=CODE_EXECUTION_TIMEOUT
            )
        except asyncio.TimeoutError:
            proc.kill()
            await proc.wait()
            return f"실행 시간 초과 ({CODE_EXECUTION_TIMEOUT}초)"

        Path(tmp_path).unlink(missing_ok=True)

        out = stdout.decode("utf-8", errors="replace")[:5000]
        err = stderr.decode("utf-8", errors="replace")[:2000]

        parts = []
        if out:
            parts.append(f"[stdout]\n{out}")
        if err:
            parts.append(f"[stderr]\n{err}")
        parts.append(f"[exit code: {proc.returncode}]")
        return "\n".join(parts) if parts else "(출력 없음)"

    except Exception as e:
        return f"코드 실행 오류: {e}"


register_tool(
    name="code_execute",
    description="코드를 실행하고 결과를 반환합니다. Python, Node.js, Shell(Bash) 을 지원합니다.",
    parameters={
        "type": "object",
        "properties": {
            "language": {
                "type": "string",
                "description": "프로그래밍 언어 (python, node/js, shell/bash)",
                "enum": ["python", "node", "javascript", "shell", "bash"],
            },
            "code": {
                "type": "string",
                "description": "실행할 코드",
            },
        },
        "required": ["language", "code"],
    },
    execute=_execute,
)
