"""Tool: process_manager – process and system management (admin only)."""

import asyncio

from config import CODE_EXECUTION_TIMEOUT
from tools.registry import register_tool


async def _run_cmd(cmd: str, timeout: int = CODE_EXECUTION_TIMEOUT) -> str:
    """Run a shell command and return output."""
    try:
        proc = await asyncio.create_subprocess_shell(
            cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        try:
            stdout, stderr = await asyncio.wait_for(
                proc.communicate(), timeout=timeout
            )
        except asyncio.TimeoutError:
            proc.kill()
            await proc.wait()
            return f"실행 시간 초과 ({timeout}초)"

        out = stdout.decode("utf-8", errors="replace")[:8000]
        err = stderr.decode("utf-8", errors="replace")[:2000]

        parts = []
        if out:
            parts.append(out)
        if err and proc.returncode != 0:
            parts.append(f"[stderr]\n{err}")
        parts.append(f"[exit code: {proc.returncode}]")
        return "\n".join(parts)

    except Exception as e:
        return f"명령 실행 오류: {e}"


async def _execute(args: dict) -> str:
    action = args.get("action", "").strip()
    target = args.get("target", "").strip()

    if not action:
        return "action을 지정해주세요 (ps, kill, top, df, free, uptime, netstat, systemctl, pm2, lsof)"

    if action == "ps":
        # Process listing
        extra = target or "aux"
        return await _run_cmd(f"ps {extra}")

    if action == "kill":
        if not target:
            return "종료할 프로세스 PID 또는 이름을 지정해주세요."
        signal = args.get("signal", "TERM")
        # If target is numeric, use kill directly
        if target.isdigit():
            return await _run_cmd(f"kill -{signal} {target}")
        # Otherwise use pkill
        return await _run_cmd(f"pkill -{signal} -f {target}")

    if action == "top":
        # One-shot snapshot
        return await _run_cmd("top -l 1 -n 15 2>/dev/null || top -b -n 1 | head -30")

    if action == "df":
        return await _run_cmd("df -h")

    if action == "free":
        # macOS doesn't have free, use vm_stat
        return await _run_cmd(
            "free -h 2>/dev/null || "
            "(echo '=== Memory ===' && vm_stat && echo '' && "
            "echo '=== Swap ===' && sysctl vm.swapusage 2>/dev/null)"
        )

    if action == "uptime":
        return await _run_cmd("uptime")

    if action == "netstat":
        extra = target or "-tlnp"
        return await _run_cmd(
            f"netstat {extra} 2>/dev/null || "
            f"lsof -i -P -n 2>/dev/null | head -50"
        )

    if action == "lsof":
        if target:
            return await _run_cmd(f"lsof -i :{target} 2>/dev/null || lsof -p {target} 2>/dev/null")
        return await _run_cmd("lsof -i -P -n | head -50")

    if action == "systemctl":
        if not target:
            return await _run_cmd("systemctl list-units --type=service --state=running 2>/dev/null || launchctl list | head -30")
        return await _run_cmd(f"systemctl {target} 2>/dev/null || echo 'systemctl not available (macOS?)'")

    if action == "pm2":
        extra = target or "list"
        return await _run_cmd(f"pm2 {extra}")

    if action == "sysinfo":
        return await _run_cmd(
            "echo '=== OS ===' && uname -a && "
            "echo '' && echo '=== Uptime ===' && uptime && "
            "echo '' && echo '=== Disk ===' && df -h / && "
            "echo '' && echo '=== CPU ===' && (nproc 2>/dev/null || sysctl -n hw.ncpu) && "
            "echo '' && echo '=== Memory ===' && "
            "(free -h 2>/dev/null || (vm_stat | head -5))"
        )

    # Fallback: run as direct command
    cmd = action
    if target:
        cmd += f" {target}"
    return await _run_cmd(cmd)


register_tool(
    name="process_manager",
    description=(
        "서버의 프로세스와 시스템 상태를 관리합니다. "
        "프로세스 목록 조회, 종료, 시스템 리소스 모니터링, PM2 관리 등을 수행합니다."
    ),
    parameters={
        "type": "object",
        "properties": {
            "action": {
                "type": "string",
                "description": (
                    "실행할 작업: ps (프로세스 목록), kill (프로세스 종료), top (실시간 상태), "
                    "df (디스크), free (메모리), uptime (가동 시간), netstat (네트워크), "
                    "lsof (포트/파일), systemctl (서비스), pm2 (PM2 관리), sysinfo (종합 정보)"
                ),
            },
            "target": {
                "type": "string",
                "description": "대상 (PID, 프로세스명, 포트 번호, 서비스명, PM2 하위 명령 등)",
            },
            "signal": {
                "type": "string",
                "description": "kill 시그널 (기본: TERM, 강제: KILL)",
                "default": "TERM",
            },
        },
        "required": ["action"],
    },
    execute=_execute,
    admin_only=True,
)
