"""Tool: shell_command – execute arbitrary shell commands (admin only)."""

import asyncio
import subprocess

from config import CODE_EXECUTION_TIMEOUT
from tools.registry import register_tool


async def _execute(args: dict) -> str:
    command = args.get("command", "").strip()
    if not command:
        return "실행할 명령어를 입력해주세요."

    try:
        proc = await asyncio.create_subprocess_shell(
            command,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )

        try:
            stdout, stderr = await asyncio.wait_for(
                proc.communicate(), timeout=CODE_EXECUTION_TIMEOUT
            )
        except asyncio.TimeoutError:
            proc.kill()
            await proc.wait()
            return f"실행 시간 초과 ({CODE_EXECUTION_TIMEOUT}초)"

        out = stdout.decode("utf-8", errors="replace")[:8000]
        err = stderr.decode("utf-8", errors="replace")[:2000]

        parts = []
        if out:
            parts.append(out)
        if err:
            parts.append(f"[stderr]\n{err}")
        parts.append(f"[exit code: {proc.returncode}]")
        return "\n".join(parts) if parts else "(출력 없음)"

    except Exception as e:
        return f"명령 실행 오류: {e}"


register_tool(
    name="shell_command",
    description="서버에서 Shell 명령어를 실행합니다. 시스템 상태 확인, 프로세스 관리, 파일 조작 등에 사용합니다.",
    parameters={
        "type": "object",
        "properties": {
            "command": {
                "type": "string",
                "description": "실행할 Shell 명령어 (예: 'ls -la', 'df -h', 'ps aux')",
            },
        },
        "required": ["command"],
    },
    execute=_execute,
    admin_only=True,
)
