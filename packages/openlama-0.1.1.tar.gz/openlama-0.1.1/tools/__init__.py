"""Tool registration – import all tools to trigger registration."""

from tools.registry import get_all_tools, get_tool, execute_tool, format_tools_for_ollama


def init_tools():
    """Import all tool modules to register them."""
    import tools.datetime_tool
    import tools.calculator
    import tools.web_search
    import tools.url_fetch
    import tools.code_runner
    import tools.shell_command
    import tools.file_read
    import tools.file_write
    import tools.image_generate
    import tools.image_edit
    import tools.git_tool
    import tools.process_manager
    import tools.obsidian_tool
