"""Tool: get_datetime – returns current date/time."""

from datetime import datetime, timezone, timedelta

from tools.registry import register_tool

KST = timezone(timedelta(hours=9))


async def _execute(args: dict) -> str:
    now = datetime.now(KST)
    return (
        f"현재 시간 (KST): {now.strftime('%Y-%m-%d %H:%M:%S')}\n"
        f"요일: {now.strftime('%A')}\n"
        f"ISO: {now.isoformat()}\n"
        f"Unix: {int(now.timestamp())}"
    )


register_tool(
    name="get_datetime",
    description="현재 날짜와 시간을 반환합니다 (한국 표준시 KST 기준)",
    parameters={
        "type": "object",
        "properties": {},
        "required": [],
    },
    execute=_execute,
)
