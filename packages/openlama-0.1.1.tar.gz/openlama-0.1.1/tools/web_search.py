"""Tool: web_search – DuckDuckGo web search."""

import asyncio
from functools import partial

from tools.registry import register_tool
from config import DUCKDUCKGO_MAX_RESULTS


def _search_sync(query: str, max_results: int) -> str:
    """Run DuckDuckGo search synchronously."""
    from duckduckgo_search import DDGS

    with DDGS() as ddgs:
        results = list(ddgs.text(query, max_results=max_results))

    if not results:
        return f"'{query}'에 대한 검색 결과가 없습니다."

    lines = [f"검색 결과: '{query}'\n"]
    for i, r in enumerate(results, 1):
        title = r.get("title", "")
        body = r.get("body", "")
        href = r.get("href", "")
        lines.append(f"{i}. {title}\n   {body}\n   URL: {href}\n")
    return "\n".join(lines)


async def _execute(args: dict) -> str:
    query = args.get("query", "").strip()
    if not query:
        return "검색어를 입력해주세요."

    max_results = args.get("max_results", DUCKDUCKGO_MAX_RESULTS)

    try:
        # DDGS v8+ is sync-only, run in thread pool
        loop = asyncio.get_running_loop()
        result = await loop.run_in_executor(
            None, partial(_search_sync, query, max_results)
        )
        return result
    except Exception as e:
        return f"검색 오류: {e}"


register_tool(
    name="web_search",
    description="DuckDuckGo를 사용하여 웹을 검색합니다. 최신 정보, 뉴스, 사실 확인에 사용합니다.",
    parameters={
        "type": "object",
        "properties": {
            "query": {
                "type": "string",
                "description": "검색 쿼리",
            },
            "max_results": {
                "type": "integer",
                "description": "최대 결과 수 (기본: 5)",
                "default": 5,
            },
        },
        "required": ["query"],
    },
    execute=_execute,
)
