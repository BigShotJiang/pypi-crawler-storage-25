"""Tool: image_generate – text-to-image generation via ComfyUI backend."""

from tools.registry import register_tool
from config import COMFY_CFG, COMFY_DENOISE, COMFY_STEPS
from utils.comfyui_client import (
    build_txt2img_workflow,
    comfyui_alive,
    extract_image_paths,
    poll_result,
    submit_prompt,
)

# Standard size presets
SIZE_PRESETS = {
    "1:1": (1024, 1024),
    "4:5": (1088, 1344),
    "3:4": (1024, 1344),
    "9:16": (1088, 1920),
    "16:9": (1920, 1088),
}


async def _execute(args: dict) -> str:
    prompt = args.get("prompt", "").strip()
    if not prompt:
        return "이미지 생성 프롬프트를 입력해주세요."

    # Check ComfyUI is running
    if not await comfyui_alive():
        return "ComfyUI 백엔드가 실행 중이 아닙니다. 서버 관리자에게 문의하세요."

    # Parse size
    aspect = args.get("aspect_ratio", "1:1")
    if aspect in SIZE_PRESETS:
        width, height = SIZE_PRESETS[aspect]
    else:
        width = args.get("width", 1024)
        height = args.get("height", 1024)
        # Clamp to valid range
        width = max(256, min(2048, width))
        height = max(256, min(2048, height))

    seed = args.get("seed")
    steps = args.get("steps", COMFY_STEPS)
    cfg = args.get("cfg", COMFY_CFG)

    try:
        # Build and submit workflow
        workflow = build_txt2img_workflow(
            prompt=prompt,
            width=width,
            height=height,
            steps=steps,
            cfg=cfg,
            denoise=COMFY_DENOISE,
            seed=seed,
        )

        prompt_id = await submit_prompt(workflow)
        print(f"[image_generate] submitted prompt_id={prompt_id}, {width}x{height}")

        # Poll for result
        result = await poll_result(prompt_id)
        image_paths = extract_image_paths(result)

        if not image_paths:
            return "이미지 생성은 완료되었으나 출력 파일을 찾을 수 없습니다."

        # Return special format that chat handler detects
        path = image_paths[0]
        return f"[IMAGE:{path}]\n이미지 생성 완료: {width}x{height}, prompt: {prompt[:100]}"

    except TimeoutError:
        return "이미지 생성 시간이 초과되었습니다. 다시 시도해주세요."
    except Exception as e:
        return f"이미지 생성 오류: {e}"


register_tool(
    name="image_generate",
    description=(
        "텍스트 프롬프트로 이미지를 생성합니다 (ComfyUI 백엔드). "
        "영어 프롬프트가 가장 좋은 결과를 냅니다. "
        "사용자가 한국어로 요청하면 영어로 번역하여 prompt에 전달하세요."
    ),
    parameters={
        "type": "object",
        "properties": {
            "prompt": {
                "type": "string",
                "description": "이미지 생성 프롬프트 (영어 권장)",
            },
            "aspect_ratio": {
                "type": "string",
                "description": "이미지 비율: 1:1, 4:5, 3:4, 9:16, 16:9",
                "enum": ["1:1", "4:5", "3:4", "9:16", "16:9"],
                "default": "1:1",
            },
            "width": {
                "type": "integer",
                "description": "직접 지정할 너비 (256-2048, aspect_ratio 미사용 시)",
            },
            "height": {
                "type": "integer",
                "description": "직접 지정할 높이 (256-2048, aspect_ratio 미사용 시)",
            },
            "seed": {
                "type": "integer",
                "description": "시드 값 (동일 시드 = 동일 결과, 미지정 시 랜덤)",
            },
            "steps": {
                "type": "integer",
                "description": "생성 스텝 수 (기본: 4, 높을수록 품질↑ 속도↓)",
            },
            "cfg": {
                "type": "number",
                "description": "CFG 스케일 (기본: 1.0)",
            },
        },
        "required": ["prompt"],
    },
    execute=_execute,
)
