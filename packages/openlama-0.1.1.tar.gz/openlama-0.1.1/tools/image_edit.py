"""Tool: image_edit – edit images using ComfyUI Qwen Image Edit backend."""

from pathlib import Path

from tools.registry import register_tool
from config import COMFY_CFG, COMFY_DENOISE, COMFY_STEPS, UPLOAD_TEMP_DIR
from utils.comfyui_client import (
    build_img2img_workflow,
    comfyui_alive,
    extract_image_paths,
    poll_result,
    submit_prompt,
    upload_image,
)


def _find_latest_upload(user_id: int) -> str | None:
    """Find the most recently uploaded image for this user."""
    upload_dir = Path(UPLOAD_TEMP_DIR)
    if not upload_dir.exists():
        return None
    # Look for files matching user_id pattern
    candidates = sorted(
        upload_dir.glob(f"{user_id}_*"),
        key=lambda p: p.stat().st_mtime,
        reverse=True,
    )
    return str(candidates[0]) if candidates else None


async def _execute(args: dict) -> str:
    prompt = args.get("prompt", "").strip()
    if not prompt:
        return "편집 프롬프트를 입력해주세요. (예: 'change the sky to sunset')"

    # Check ComfyUI
    if not await comfyui_alive():
        return "ComfyUI 백엔드가 실행 중이 아닙니다. 서버 관리자에게 문의하세요."

    # Find input image
    image_path = args.get("image_path", "").strip()
    user_id = args.get("_user_id", 0)

    if not image_path and user_id:
        image_path = _find_latest_upload(user_id) or ""

    if not image_path:
        return (
            "편집할 이미지가 없습니다. 먼저 이미지를 전송한 후 편집을 요청해주세요."
        )

    if not Path(image_path).exists():
        return f"이미지 파일을 찾을 수 없습니다: {image_path}"

    negative_prompt = args.get("negative_prompt", "")
    seed = args.get("seed")
    steps = args.get("steps", COMFY_STEPS)
    cfg = args.get("cfg", COMFY_CFG)

    try:
        # Upload image to ComfyUI
        uploaded_name = await upload_image(image_path)
        print(f"[image_edit] uploaded {image_path} → {uploaded_name}")

        # Build and submit workflow
        workflow = build_img2img_workflow(
            uploaded_image_name=uploaded_name,
            prompt=prompt,
            negative_prompt=negative_prompt,
            steps=steps,
            cfg=cfg,
            denoise=COMFY_DENOISE,
            seed=seed,
        )

        prompt_id = await submit_prompt(workflow)
        print(f"[image_edit] submitted prompt_id={prompt_id}")

        # Poll for result
        result = await poll_result(prompt_id)
        image_paths = extract_image_paths(result)

        if not image_paths:
            return "이미지 편집은 완료되었으나 출력 파일을 찾을 수 없습니다."

        path = image_paths[0]
        return f"[IMAGE:{path}]\n이미지 편집 완료: {prompt[:100]}"

    except TimeoutError:
        return "이미지 편집 시간이 초과되었습니다. 다시 시도해주세요."
    except Exception as e:
        return f"이미지 편집 오류: {e}"


register_tool(
    name="image_edit",
    description=(
        "기존 이미지를 편집합니다 (ComfyUI Qwen Image Edit 백엔드). "
        "사용자가 이미지를 보내고 편집을 요청할 때 사용합니다. "
        "영어 프롬프트가 가장 좋은 결과를 냅니다. "
        "사용자가 한국어로 요청하면 영어로 번역하여 prompt에 전달하세요."
    ),
    parameters={
        "type": "object",
        "properties": {
            "prompt": {
                "type": "string",
                "description": "이미지 편집 프롬프트 (영어 권장, 예: 'change the background to a beach')",
            },
            "image_path": {
                "type": "string",
                "description": "편집할 이미지 파일 경로 (미지정 시 사용자가 최근 업로드한 이미지 사용)",
            },
            "negative_prompt": {
                "type": "string",
                "description": "원하지 않는 요소 (예: 'blurry, low quality')",
            },
            "seed": {
                "type": "integer",
                "description": "시드 값 (동일 시드 = 동일 결과)",
            },
            "steps": {
                "type": "integer",
                "description": "편집 스텝 수 (기본: 4)",
            },
            "cfg": {
                "type": "number",
                "description": "CFG 스케일 (기본: 1.0)",
            },
        },
        "required": ["prompt"],
    },
    execute=_execute,
    admin_only=True,
)
