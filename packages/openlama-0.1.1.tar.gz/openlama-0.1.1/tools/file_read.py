"""Tool: file_read – read a file from the server filesystem."""

from pathlib import Path

from config import MAX_FILE_READ_CHARS, TOOL_SANDBOX_ENABLED, TOOL_SANDBOX_PATH
from tools.registry import register_tool


def _is_safe_path(path: str) -> bool:
    """Check if path is under allowed directories."""
    if not TOOL_SANDBOX_ENABLED:
        return True
    resolved = Path(path).resolve()
    allowed = [Path(TOOL_SANDBOX_PATH).resolve(), Path.home().resolve()]
    return any(str(resolved).startswith(str(a)) for a in allowed)


async def _execute(args: dict) -> str:
    path = args.get("path", "").strip()
    if not path:
        return "파일 경로를 입력해주세요."

    if not _is_safe_path(path):
        return f"접근이 허용되지 않는 경로입니다: {path}"

    p = Path(path)
    if not p.exists():
        return f"파일을 찾을 수 없습니다: {path}"
    if p.is_dir():
        items = sorted(p.iterdir())
        listing = "\n".join(
            f"{'[DIR] ' if i.is_dir() else ''}{i.name}" for i in items[:100]
        )
        return f"디렉토리: {path}\n\n{listing}"

    try:
        content = p.read_text(encoding="utf-8", errors="replace")
        if len(content) > MAX_FILE_READ_CHARS:
            content = content[:MAX_FILE_READ_CHARS] + f"\n... (truncated, total {p.stat().st_size} bytes)"
        return f"파일: {path}\n크기: {p.stat().st_size} bytes\n\n{content}"
    except Exception as e:
        return f"파일 읽기 오류: {e}"


register_tool(
    name="file_read",
    description="서버의 로컬 파일을 읽거나 디렉토리 내용을 나열합니다.",
    parameters={
        "type": "object",
        "properties": {
            "path": {
                "type": "string",
                "description": "읽을 파일 또는 디렉토리의 절대 경로",
            },
        },
        "required": ["path"],
    },
    execute=_execute,
    admin_only=True,
)
