"""Tool: git – Git repository operations (admin only)."""

import asyncio
import os

from config import CODE_EXECUTION_TIMEOUT
from tools.registry import register_tool


async def _run_git(args: list[str], cwd: str = None, timeout: int = CODE_EXECUTION_TIMEOUT) -> str:
    """Run a git command and return output."""
    cmd = ["git"] + args
    try:
        proc = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            cwd=cwd,
        )
        try:
            stdout, stderr = await asyncio.wait_for(
                proc.communicate(), timeout=timeout
            )
        except asyncio.TimeoutError:
            proc.kill()
            await proc.wait()
            return f"실행 시간 초과 ({timeout}초)"

        out = stdout.decode("utf-8", errors="replace")[:8000]
        err = stderr.decode("utf-8", errors="replace")[:2000]

        parts = []
        if out:
            parts.append(out)
        if err and proc.returncode != 0:
            parts.append(f"[stderr]\n{err}")
        parts.append(f"[exit code: {proc.returncode}]")
        return "\n".join(parts)

    except FileNotFoundError:
        return "git이 설치되어 있지 않습니다."
    except Exception as e:
        return f"Git 실행 오류: {e}"


async def _execute(args: dict) -> str:
    action = args.get("action", "").strip()
    repo_path = args.get("repo_path", "").strip() or None
    extra = args.get("args", "").strip()

    if not action:
        return "action을 지정해주세요 (status, log, diff, branch, commit, push, pull, checkout, add, stash)"

    # Map action to git subcommands
    safe_actions = {
        "status": ["status", "--short"],
        "log": ["log", "--oneline", "-20"],
        "diff": ["diff", "--stat"],
        "diff_full": ["diff"],
        "branch": ["branch", "-a"],
        "remote": ["remote", "-v"],
        "stash_list": ["stash", "list"],
        "show": ["show", "--stat", "HEAD"],
        "blame": ["blame"],
    }

    write_actions = {"commit", "push", "pull", "checkout", "add", "stash", "merge", "reset", "tag", "fetch"}

    if action in safe_actions:
        git_args = list(safe_actions[action])
        if extra:
            git_args.extend(extra.split())
        return await _run_git(git_args, cwd=repo_path)

    if action in write_actions:
        git_args = [action]
        if extra:
            git_args.extend(extra.split())
        return await _run_git(git_args, cwd=repo_path)

    # Fallback: pass action + extra directly
    git_args = [action]
    if extra:
        git_args.extend(extra.split())
    return await _run_git(git_args, cwd=repo_path)


register_tool(
    name="git",
    description=(
        "Git 저장소 작업을 수행합니다. status, log, diff, branch, commit, push, pull, "
        "checkout, add, stash, merge, fetch 등의 Git 명령을 실행합니다."
    ),
    parameters={
        "type": "object",
        "properties": {
            "action": {
                "type": "string",
                "description": (
                    "Git 명령: status, log, diff, diff_full, branch, commit, push, pull, "
                    "checkout, add, stash, stash_list, merge, fetch, remote, show, blame, reset, tag"
                ),
            },
            "repo_path": {
                "type": "string",
                "description": "Git 저장소 경로 (기본: 현재 디렉토리)",
            },
            "args": {
                "type": "string",
                "description": "추가 인자 (예: commit의 경우 '-m \"커밋 메시지\"', checkout의 경우 'branch-name')",
            },
        },
        "required": ["action"],
    },
    execute=_execute,
    admin_only=True,
)
