"""Tool: obsidian – Obsidian vault management via obsidian-cli."""

import asyncio

from config import CODE_EXECUTION_TIMEOUT
from tools.registry import register_tool


async def _run_obsidian(args: list[str], timeout: int = CODE_EXECUTION_TIMEOUT) -> str:
    """Run an obsidian-cli command and return output."""
    cmd = ["obsidian-cli"] + args
    try:
        proc = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        try:
            stdout, stderr = await asyncio.wait_for(
                proc.communicate(), timeout=timeout
            )
        except asyncio.TimeoutError:
            proc.kill()
            await proc.wait()
            return f"실행 시간 초과 ({timeout}초)"

        out = stdout.decode("utf-8", errors="replace")[:8000]
        err = stderr.decode("utf-8", errors="replace")[:2000]

        parts = []
        if out:
            parts.append(out)
        if err and proc.returncode != 0:
            parts.append(f"[오류] {err.strip()}")
            # Provide guidance for common errors
            if "Failed to access vault directory" in err:
                parts.append(
                    "[힌트] 경로가 존재하지 않습니다. "
                    "정확한 폴더/파일명을 확인하려면 상위 경로에서 list를 먼저 실행하세요. "
                    "폴더명은 한국어가 아닌 영어일 수 있습니다."
                )
            elif "path traversal" in err:
                parts.append("[힌트] '/' 대신 폴더명을 직접 지정하세요.")
        if proc.returncode != 0 and not parts:
            parts.append(f"[exit code: {proc.returncode}]")
        return "\n".join(parts) if parts else "(빈 결과)"

    except FileNotFoundError:
        return "obsidian-cli가 설치되어 있지 않습니다. brew install obsidian-cli"
    except Exception as e:
        return f"Obsidian CLI 실행 오류: {e}"


async def _execute(args: dict) -> str:
    action = args.get("action", "").strip()
    vault = args.get("vault", "").strip() or None
    note = args.get("note", "").strip() or None
    content = args.get("content", "").strip() or None
    destination = args.get("destination", "").strip() or None
    query = args.get("query", "").strip() or None
    key = args.get("key", "").strip() or None
    value = args.get("value", "").strip() or None

    if not action:
        return (
            "action을 지정해주세요:\n"
            "list, read, create, append, delete, move, search, "
            "search_content, daily, frontmatter_get, frontmatter_set, frontmatter_delete"
        )

    vault_args = ["-v", vault] if vault else []

    # ── List files/folders ──
    if action == "list":
        cmd = ["list"] + vault_args
        if note and note not in ("/", ".", "./", "root"):
            cmd.append(note)
        return await _run_obsidian(cmd)

    # ── Read note ──
    if action == "read":
        if not note:
            return "note 파라미터를 지정해주세요."
        cmd = ["print"] + vault_args + [note]
        return await _run_obsidian(cmd)

    # ── Create note ──
    if action == "create":
        if not note:
            return "note 파라미터를 지정해주세요. (예: '폴더/노트이름')"
        cmd = ["create"] + vault_args + [note]
        if content:
            cmd += ["-c", content]
        return await _run_obsidian(cmd)

    # ── Append to note ──
    if action == "append":
        if not note:
            return "note 파라미터를 지정해주세요."
        if not content:
            return "content 파라미터를 지정해주세요."
        cmd = ["create", "-a"] + vault_args + [note, "-c", content]
        return await _run_obsidian(cmd)

    # ── Delete note ──
    if action == "delete":
        if not note:
            return "note 파라미터를 지정해주세요."
        cmd = ["delete"] + vault_args + [note]
        return await _run_obsidian(cmd)

    # ── Move/rename note ──
    if action == "move":
        if not note:
            return "note 파라미터를 지정해주세요. (원본 노트)"
        if not destination:
            return "destination 파라미터를 지정해주세요. (대상 경로/이름)"
        cmd = ["move"] + vault_args + [note, destination]
        return await _run_obsidian(cmd)

    # ── Fuzzy search by name ──
    if action == "search":
        if not query:
            return "query 파라미터를 지정해주세요."
        cmd = ["search"] + vault_args + [query]
        return await _run_obsidian(cmd)

    # ── Search by content ──
    if action == "search_content":
        if not query:
            return "query 파라미터를 지정해주세요."
        cmd = ["search-content"] + vault_args + [query]
        return await _run_obsidian(cmd)

    # ── Daily note ──
    if action == "daily":
        cmd = ["daily"] + vault_args
        return await _run_obsidian(cmd)

    # ── Frontmatter get ──
    if action == "frontmatter_get":
        if not note:
            return "note 파라미터를 지정해주세요."
        cmd = ["frontmatter", "--print"] + vault_args + [note]
        return await _run_obsidian(cmd)

    # ── Frontmatter set ──
    if action == "frontmatter_set":
        if not note:
            return "note 파라미터를 지정해주세요."
        if not key:
            return "key 파라미터를 지정해주세요."
        if value is None:
            return "value 파라미터를 지정해주세요."
        cmd = ["frontmatter", "--edit", "-k", key, "--value", value] + vault_args + [note]
        return await _run_obsidian(cmd)

    # ── Frontmatter delete ──
    if action == "frontmatter_delete":
        if not note:
            return "note 파라미터를 지정해주세요."
        if not key:
            return "key 파라미터를 지정해주세요."
        cmd = ["frontmatter", "--delete", "-k", key] + vault_args + [note]
        return await _run_obsidian(cmd)

    return f"알 수 없는 action: {action}"


register_tool(
    name="obsidian",
    description=(
        "Obsidian 노트 관리 도구. 볼트의 노트를 조회, 읽기, 생성, 수정, 삭제, 이동, 검색할 수 있습니다. "
        "프론트매터(YAML) 조회/수정과 데일리 노트 생성도 지원합니다."
    ),
    parameters={
        "type": "object",
        "properties": {
            "action": {
                "type": "string",
                "description": (
                    "수행할 작업: list(파일 목록), read(노트 읽기), create(노트 생성), "
                    "append(노트에 내용 추가), delete(노트 삭제), move(노트 이동/이름변경), "
                    "search(이름 퍼지 검색), search_content(내용 검색), daily(데일리 노트), "
                    "frontmatter_get(프론트매터 조회), frontmatter_set(프론트매터 수정), "
                    "frontmatter_delete(프론트매터 키 삭제)"
                ),
            },
            "note": {
                "type": "string",
                "description": "노트 이름 또는 경로 (예: '000_INBOX/메모', 'MY_NOTE'). list에서는 폴더 경로로 사용",
            },
            "content": {
                "type": "string",
                "description": "노트 내용 (create, append 시 사용). 마크다운 지원",
            },
            "destination": {
                "type": "string",
                "description": "이동 대상 경로 (move 시 사용, 예: '400_ARCHIVE/old_note')",
            },
            "query": {
                "type": "string",
                "description": "검색어 (search, search_content 시 사용)",
            },
            "vault": {
                "type": "string",
                "description": "볼트 이름 (미지정 시 기본 볼트 사용)",
            },
            "key": {
                "type": "string",
                "description": "프론트매터 키 (frontmatter_set, frontmatter_delete 시 사용)",
            },
            "value": {
                "type": "string",
                "description": "프론트매터 값 (frontmatter_set 시 사용)",
            },
        },
        "required": ["action"],
    },
    execute=_execute,
    admin_only=True,
)
