"""Tool: file_write – write content to a file on the server."""

from pathlib import Path

from config import TOOL_SANDBOX_ENABLED, TOOL_SANDBOX_PATH
from tools.registry import register_tool


def _is_safe_path(path: str) -> bool:
    if not TOOL_SANDBOX_ENABLED:
        return True
    resolved = Path(path).resolve()
    allowed = [Path(TOOL_SANDBOX_PATH).resolve(), Path.home().resolve()]
    return any(str(resolved).startswith(str(a)) for a in allowed)


async def _execute(args: dict) -> str:
    path = args.get("path", "").strip()
    content = args.get("content", "")
    mode = args.get("mode", "write")

    if not path:
        return "파일 경로를 입력해주세요."
    if not _is_safe_path(path):
        return f"접근이 허용되지 않는 경로입니다: {path}"

    p = Path(path)
    try:
        p.parent.mkdir(parents=True, exist_ok=True)
        if mode == "append":
            with open(p, "a", encoding="utf-8") as f:
                f.write(content)
        else:
            p.write_text(content, encoding="utf-8")

        return f"파일 저장 완료: {path} ({len(content)} chars)"
    except Exception as e:
        return f"파일 쓰기 오류: {e}"


register_tool(
    name="file_write",
    description="서버의 로컬 파일에 내용을 작성합니다. 새 파일 생성 또는 기존 파일 덮어쓰기/추가가 가능합니다.",
    parameters={
        "type": "object",
        "properties": {
            "path": {
                "type": "string",
                "description": "파일의 절대 경로",
            },
            "content": {
                "type": "string",
                "description": "작성할 내용",
            },
            "mode": {
                "type": "string",
                "description": "쓰기 모드: 'write' (덮어쓰기) 또는 'append' (추가)",
                "enum": ["write", "append"],
                "default": "write",
            },
        },
        "required": ["path", "content"],
    },
    execute=_execute,
    admin_only=True,
)
