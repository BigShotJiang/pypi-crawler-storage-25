"""CLI chat channel -- stub for Phase 9."""
from openlama.channels.base import Channel


class CLIChannel(Channel):
    async def start(self):
        raise NotImplementedError("CLI chat will be implemented in Phase 9")

    async def stop(self):
        pass
