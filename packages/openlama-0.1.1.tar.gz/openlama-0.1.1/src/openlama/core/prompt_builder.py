"""Multi-prompt assembly — SYSTEM + SOUL + USERS + MEMORY."""
from __future__ import annotations

from pathlib import Path

from openlama.config import get_config, DEFAULT_SYSTEM_PROMPT
from openlama.tools.registry import get_all_tools
from openlama.core.skills import build_skills_section
from openlama.logger import get_logger

logger = get_logger("prompt")


def _prompts_dir() -> Path:
    return Path(get_config("prompts_dir"))


def _read_prompt(name: str) -> str:
    p = _prompts_dir() / name
    if p.exists():
        return p.read_text(encoding="utf-8").strip()
    return ""


def _has_real_content(path: Path) -> bool:
    """Check if file exists and has meaningful content (not just a header)."""
    if not path.exists():
        return False
    text = path.read_text(encoding="utf-8").strip()
    # Remove markdown header lines
    lines = [l.strip() for l in text.split("\n") if l.strip() and not l.strip().startswith("#")]
    # Need at least 10 chars of real content
    content = " ".join(lines)
    return len(content) >= 10


def is_profile_setup_done() -> bool:
    """Check if USERS.md and SOUL.md exist with meaningful content."""
    d = _prompts_dir()
    return _has_real_content(d / "USERS.md") and _has_real_content(d / "SOUL.md")


def save_prompt_file(name: str, content: str):
    d = _prompts_dir()
    d.mkdir(parents=True, exist_ok=True)
    (d / name).write_text(content, encoding="utf-8")
    logger.info("saved prompt: %s (%d chars)", name, len(content))


def generate_system_prompt() -> str:
    """Build SYSTEM.md from templates + current tool list."""
    tools = get_all_tools()
    tool_lines = "\n".join(f"- {t.name}: {t.description[:60]}" for t in tools)

    # Include MCP server tools
    try:
        from openlama.core.mcp_client import get_all_mcp_tools
        mcp_tools = get_all_mcp_tools()
        if mcp_tools:
            tool_lines += "\n" + "\n".join(
                f"- mcp_{t['server']}_{t['name']}: [MCP] {t['description'][:50]}"
                for t in mcp_tools
            )
    except Exception:
        pass

    soul = _read_prompt("SOUL.md")
    users = _read_prompt("USERS.md")
    memory = _read_prompt("MEMORY.md")

    system = f"""# System Prompt

## Reference Files
- Agent identity: SOUL.md
- User information: USERS.md
- Long-term memory: MEMORY.md

## Operating Rules
1. Always maintain the identity defined in SOUL.md.
2. Provide personalized responses based on user information in USERS.md.
3. Actively use tools to fulfill user requests.

## Available Tools
{tool_lines}

## Long-term Memory Rules
Save to memory using the memory tool in the following cases:
1. When the user says "remember this", "save to memory", "keep this in mind", etc.
2. When an important user preference is discovered.
3. When there is a key project decision.
Format: concise single line, date auto-included, max 50 items.

## Tool Usage Rules
- Using image_generate/image_edit tools will automatically start/stop ComfyUI. No manual check needed.
- Use tools directly without unnecessary pre-checks.
- Use multiple tools sequentially to fulfill user requests.

## Context Management
- Context is automatically compressed when it reaches 70% of max capacity.
- Save important information with the memory tool before compression.

## Skill System
- Skills are custom instruction sets that activate automatically based on trigger keywords.
- Use the `skill_creator` tool to create, list, update, or delete skills.
- When a user asks to create a skill, use the `skill_creator` tool with action "create".
- Skills are stored in the skills directory and listed below when available.
- When a skill is triggered by the user's message, its instructions are injected into this prompt.
"""
    # Append skills section if any exist
    skills_section = build_skills_section()
    if skills_section:
        system += f"\n{skills_section}\n"

    save_prompt_file("SYSTEM.md", system)
    return system


def build_full_system_prompt() -> str:
    """Assemble all prompt files into one system prompt."""
    parts = []

    # Always regenerate SYSTEM.md to include latest tools and skills
    system = generate_system_prompt()
    parts.append(system)

    # SOUL.md
    soul = _read_prompt("SOUL.md")
    if soul:
        parts.append(f"\n{soul}")

    # USERS.md
    users = _read_prompt("USERS.md")
    if users:
        parts.append(f"\n{users}")

    # MEMORY.md
    memory = _read_prompt("MEMORY.md")
    if memory:
        parts.append(f"\n{memory}")

    if not parts:
        return DEFAULT_SYSTEM_PROMPT

    return "\n".join(parts)
