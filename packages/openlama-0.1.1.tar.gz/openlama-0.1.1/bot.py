#!/usr/bin/env python3
"""Ollama Telegram Bot – entry point."""

import asyncio

from telegram import Update
from telegram.ext import Application

from config import ADMIN_PASSWORD, BOT_TOKEN
from database import get_admin_password_hash, init_db, set_setting
from auth import hash_password
from handlers import register_all_handlers
from handlers.commands import post_init
from tools import init_tools


def validate_env():
    if not BOT_TOKEN:
        raise RuntimeError("TELEGRAM_BOT_TOKEN 누락")


def setup_admin_password():
    """Initialize admin password hash on first run."""
    existing = get_admin_password_hash()
    if not existing and ADMIN_PASSWORD:
        set_setting("admin_password_hash", hash_password(ADMIN_PASSWORD))


def main():
    validate_env()
    init_db()
    setup_admin_password()
    init_tools()

    # Python 3.14 compat
    asyncio.set_event_loop(asyncio.new_event_loop())

    app = Application.builder().token(BOT_TOKEN).post_init(post_init).build()
    register_all_handlers(app)
    app.run_polling(allowed_updates=Update.ALL_TYPES)


if __name__ == "__main__":
    main()
