
import httpx
from typing import Optional, Union, Dict, Any
from .config import Config
from .exceptions import AuthenticationError, APIError, ForgeDefendError
from .logging import logger
from .security import mask_api_key, mask_payload

class ForgeDefendClient:
    """
    Client for interacting with the Velyana internal red teaming API.
    Provides exact pass-through of bodies with no mutation.
    """
    
    def __init__(
        self, 
        api_key: Optional[str] = None, 
        app_id: Optional[str] = None,
        api_version: str = "v1",
        timeout: Optional[float] = None,
        safe_mode: bool = True
    ):
        self.config = Config()
        if api_key:
            self.config.api_key = api_key
        if app_id:
            self.config.app_id = app_id
            
        self.config.api_version = api_version
        
        # Base URL for Forge Defend
        self.config.base_url = f"https://entry-service-prod.velyana.com/{self.config.api_version}"
        if timeout is not None:
            self.config.timeout = timeout
        self.config.safe_mode = safe_mode

        if not self.config.api_key:
            raise AuthenticationError("VELYANA_API_KEY is not set or provided.")
        if not self.config.app_id:
            raise AuthenticationError("VELYANA_APP_ID is not set or provided.")
        
        headers = {
            "X-API-Key": self.config.api_key,
            "X-App-ID": self.config.app_id,
            "User-Agent": "VelyanaForgeDefendSDK/0.1.0"
        }
        
        self._sync_client = httpx.Client(
            base_url=self.config.base_url, 
            headers=headers, 
            timeout=self.config.timeout
        )
        
        self._async_client = httpx.AsyncClient(
            base_url=self.config.base_url, 
            headers=headers, 
            timeout=self.config.timeout
        )
        
        logger.info(f"Initialized ForgeDefendClient (Key: {mask_api_key(self.config.api_key)})")

    def _prepare_request_kwargs(self, body: Any, headers: Optional[Dict[str, str]] = None) -> Dict[str, Any]:
        kwargs = {}
        if headers:
            kwargs["headers"] = headers
            
        if body is not None:
            if isinstance(body, (dict, list)):
                kwargs["json"] = body
            elif isinstance(body, str):
                kwargs["content"] = body.encode("utf-8")
            elif isinstance(body, bytes):
                kwargs["content"] = body
            else:
                kwargs["content"] = str(body).encode("utf-8")
        return kwargs
        
    def _handle_response(self, response: httpx.Response) -> httpx.Response:
        try:
            response.raise_for_status()
        except httpx.HTTPStatusError as e:
            logger.error(f"APIError: {e.response.status_code} - {e.response.text}")
            if response.status_code == 401:
                raise AuthenticationError(f"Authentication failed: {e.response.text}")
            raise APIError(
                message=f"Request failed with status {response.status_code}",
                status_code=response.status_code,
                response_body=response.text
            )
        except httpx.RequestError as e:
            logger.error(f"Request failed: {str(e)}")
            raise ForgeDefendError(f"Request failed: {str(e)}")
            
        return response

    def _request(self, method: str, endpoint: str, body: Optional[Any] = None, headers: Optional[Dict[str, str]] = None) -> httpx.Response:
        logger.debug(f"{method.upper()} {endpoint} Payload: {mask_payload(body, self.config.safe_mode)}")
        kwargs = self._prepare_request_kwargs(body, headers)
        response = self._sync_client.request(method, endpoint, **kwargs)
        return self._handle_response(response)

    async def _arequest(self, method: str, endpoint: str, body: Optional[Any] = None, headers: Optional[Dict[str, str]] = None) -> httpx.Response:
        logger.debug(f"ASYNC {method.upper()} {endpoint} Payload: {mask_payload(body, self.config.safe_mode)}")
        kwargs = self._prepare_request_kwargs(body, headers)
        response = await self._async_client.request(method, endpoint, **kwargs)
        return self._handle_response(response)

    def _get(self, endpoint: str, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None) -> httpx.Response:
        logger.debug(f"GET {endpoint} Params: {mask_payload(params, self.config.safe_mode)}")
        response = self._sync_client.get(endpoint, params=params, headers=headers)
        return self._handle_response(response)

    async def _aget(self, endpoint: str, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None) -> httpx.Response:
        logger.debug(f"ASYNC GET {endpoint} Params: {mask_payload(params, self.config.safe_mode)}")
        response = await self._async_client.get(endpoint, params=params, headers=headers)
        return self._handle_response(response)

    def _post(self, endpoint: str, body: Optional[Any] = None, headers: Optional[Dict[str, str]] = None) -> httpx.Response:
        return self._request("POST", endpoint, body=body, headers=headers)

    async def _apost(self, endpoint: str, body: Optional[Any] = None, headers: Optional[Dict[str, str]] = None) -> httpx.Response:
        return await self._arequest("POST", endpoint, body=body, headers=headers)

    # --- Public SDK Actions ---

    def validate(self, body: Optional[Any] = None, headers: Optional[Dict[str, str]] = None) -> httpx.Response:
        """
        Validates a prompt using the Forge Defend API.
        Internally triggers the /validate endpoint.
        """
        return self._post("/validate", body=body, headers=headers)

    async def avalidate(self, body: Optional[Any] = None, headers: Optional[Dict[str, str]] = None) -> httpx.Response:
        """
        Asynchronously validates a prompt using the Forge Defend API.
        """
        return await self._apost("/validate", body=body, headers=headers)
        
    # No remaining methods
        
    def close(self):
        self._sync_client.close()
        
    async def aclose(self):
        await self._async_client.aclose()
