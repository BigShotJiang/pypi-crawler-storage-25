
class ForgeDefendError(Exception):
    """Base exception for Velyana RedTeam SDK"""
    pass

class AuthenticationError(ForgeDefendError):
    """Raised when API key is invalid or missing"""
    pass

class APIError(ForgeDefendError):
    """Raised when the API returns an error response"""
    def __init__(self, message: str, status_code: int = None, response_body: str = None):
        super().__init__(message)
        self.status_code = status_code
        self.response_body = response_body
