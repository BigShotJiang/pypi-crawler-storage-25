
import os
from dataclasses import dataclass
from typing import Optional

@dataclass
class Config:
    api_key: Optional[str] = None
    app_id: Optional[str] = None
    api_version: str = "v1"
    base_url: str = "https://entry-service-prod.velyana.com/v1"
    timeout: float = 30.0
    safe_mode: bool = True
    
    def __post_init__(self):
        if not self.api_key:
            self.api_key = os.getenv("VELYANA_API_KEY")
        if not self.app_id:
            self.app_id = os.getenv("VELYANA_APP_ID")
