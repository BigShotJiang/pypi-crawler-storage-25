
def mask_api_key(api_key: str) -> str:
    """Masks the API key for safe logging."""
    if not api_key:
        return "None"
    if len(api_key) <= 8:
        return "****"
    return f"{api_key[:4]}****{api_key[-4:]}"

def mask_payload(payload: any, safe_mode: bool = True) -> str:
    """Safely represents payload for logging."""
    if not safe_mode:
        return str(payload)
    
    payload_str = str(payload)
    if len(payload_str) > 100:
        return f"{payload_str[:50]}...[TRUNCATED]...{payload_str[-50:]}"
    return payload_str
