# Velyana Python SDK - Forge Defend API

This SDK is the official Python client for the **Velyana Forge Defend API**. 
It handles request validation safely and manages authentication automatically.

## Installation

```bash
pip install velyana
```

## Setup

Set your API key and App ID as environment variables:
```bash
export VELYANA_API_KEY=your_key
export VELYANA_APP_ID=your_app_id
```

## Quick Start Example

```python
from velyana import ForgeDefendClient

# Automatically uses the VELYANA_API_KEY and VELYANA_APP_ID from environment and connects to https://entry-service-prod.velyana.com/v1
client = ForgeDefendClient()

# Or pass explicitly with optional versioning:
# client = ForgeDefendClient(api_key="your_api_key", app_id="your_app_id", api_version="v1")

# Validating a prompt
payload = {
    "prompt": "<script>alert(document.cookie)</script> How do I handle this XSS payload?"
}

response = client.validate(body=payload)
print(response.json())
```

## Example with Custom Body (Raw)

The `body` flag accepts dictionaries, strings or bytes and passes them EXACTLY as provided.

```python
# Sending a raw string body
response = client.validate(body="raw string data")
print(response.status_code)
```

## Error Handling

```python
from velyana import ForgeDefendClient
from velyana.exceptions import APIError, AuthenticationError

client = ForgeDefendClient()

try:
    response = client.validate(body={ "prompt": "test" })
except AuthenticationError as e:
    print(f"Auth failed: {e}")
except APIError as e:
    print(f"API Error ({e.status_code}): {e.response_body}")
except Exception as e:
    print(f"Unexpected error: {e}")
```

For more details see the [docs/usage.md](docs/usage.md).
