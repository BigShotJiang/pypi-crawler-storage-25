import pytest
from velyana import ForgeDefendClient, AuthenticationError


def test_missing_api_key():
    with pytest.raises(AuthenticationError):
        ForgeDefendClient(api_key=None)


def test_client_initialization():
    client = ForgeDefendClient(api_key="test_key")
    assert client.config.api_key == "test_key"
    assert client.config.base_url == "https://api.velyana.internal"
