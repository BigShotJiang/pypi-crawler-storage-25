from setuptools import setup, find_packages

setup(
    name="velyana",
    version="0.1.0",
    description="Velyana Python SDK - Forge Defend API",
    packages=find_packages(),
    install_requires=[
        "httpx>=0.24.0",
    ],
    extras_require={"dev": ["pytest>=7.0.0", "python-dotenv"]},
    python_requires=">=3.8",
)
