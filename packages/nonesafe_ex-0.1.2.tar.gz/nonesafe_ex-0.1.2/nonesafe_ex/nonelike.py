from __future__ import annotations
from typing import Any, NoReturn
from collections.abc import Iterator, KeysView, ValuesView, ItemsView


class NoneLikeType:
    """None 安全的哨兵对象：字符串化返回 ``"None"``，支持任意链式访问，布尔值为假。"""

    __slots__ = ()
    _instance: NoneLikeType | None = None

    def __new__(cls) -> NoneLikeType:
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    # ----- 链式访问 / 调用 ------------------------------------------------
    def __getattr__(self, _name: str) -> NoneLikeType:
        # 对调试器/序列化等场景常见的 dunder 属性，保持标准语义：不存在就抛 AttributeError。
        # 否则像 debugpy 这类工具在变量展开时可能拿到错误类型并触发异常。
        if _name.startswith("__") and _name.endswith("__"):
            raise AttributeError(_name)
        return self

    def __getitem__(self, _key: Any) -> NoneLikeType:
        return self

    def __call__(self, *_args: Any, **_kwargs: Any) -> NoneLikeType:
        return self

    # ----- 容器协议 --------------------------------------------------------
    def __iter__(self) -> Iterator[Any]:
        return iter(())

    def __len__(self) -> int:
        return 0

    def __contains__(self, _item: Any) -> bool:
        return False

    def __reversed__(self) -> Iterator[Any]:
        return iter(())

    # ----- dict 方法 -------------------------------------------------------
    def get(self, _key: Any, _default: Any = None) -> NoneLikeType:
        return self

    def keys(self) -> KeysView[Any]:
        return {}.keys()

    def values(self) -> ValuesView:
        return {}.values()

    def items(self) -> ItemsView[Any, Any]:
        return {}.items()

    def pop(self, _key: Any, _default: Any = None) -> NoneLikeType:
        return self

    def popitem(self) -> NoneLikeType:
        return self

    def setdefault(self, _key: Any, _default: Any = None) -> NoneLikeType:
        return self

    # ----- list 方法 -------------------------------------------------------
    def index(self, _value: Any, _start: Any = None, _stop: Any = None) -> NoReturn:
        raise ValueError("NoneLikeType object - value not found")

    # ----- list 方法 -------------------------------------------------------
    def count(self, _value: Any) -> int:
        return 0

    def pop_list(self, _index: int = -1) -> NoneLikeType:
        """list.pop 对应（避免与 dict.pop 冲突）。"""
        return self

    # ----- 运算符 / 内建 ---------------------------------------------------
    def __bool__(self) -> bool:
        return False

    def __eq__(self, other: Any) -> bool:
        return other is None or other is self

    def __ne__(self, other: Any) -> bool:
        return not self.__eq__(other)

    def __hash__(self) -> int:
        return hash(None)

    def __str__(self) -> str:
        return "None"

    def __repr__(self) -> str:
        return "None"

    def __neg__(self) -> NoneLikeType:
        return self

    def __pos__(self) -> NoneLikeType:
        return self

    def __abs__(self) -> NoneLikeType:
        return self

    def __invert__(self) -> NoneLikeType:
        return self

    # 数值运算（全部返回自身，避免 NoneType 运算抛异常）
    def __add__(self, _other: Any) -> NoneLikeType:
        return self

    def __radd__(self, _other: Any) -> NoneLikeType:
        return self

    def __sub__(self, _other: Any) -> NoneLikeType:
        return self

    def __rsub__(self, _other: Any) -> NoneLikeType:
        return self

    def __mul__(self, _other: Any) -> NoneLikeType:
        return self

    def __rmul__(self, _other: Any) -> NoneLikeType:
        return self

    def __truediv__(self, _other: Any) -> NoneLikeType:
        return self

    def __rtruediv__(self, _other: Any) -> NoneLikeType:
        return self

    def __floordiv__(self, _other: Any) -> NoneLikeType:
        return self

    def __rfloordiv__(self, _other: Any) -> NoneLikeType:
        return self

    def __mod__(self, _other: Any) -> NoneLikeType:
        return self

    def __rmod__(self, _other: Any) -> NoneLikeType:
        return self

    def __pow__(self, _other: Any) -> NoneLikeType:
        return self

    def __rpow__(self, _other: Any) -> NoneLikeType:
        return self

    # 比较运算（全部返回 False）
    def __lt__(self, _other: Any) -> bool:
        return False

    def __le__(self, _other: Any) -> bool:
        return False

    def __gt__(self, _other: Any) -> bool:
        return False

    def __ge__(self, _other: Any) -> bool:
        return False


NoneLike = NoneLikeType()
