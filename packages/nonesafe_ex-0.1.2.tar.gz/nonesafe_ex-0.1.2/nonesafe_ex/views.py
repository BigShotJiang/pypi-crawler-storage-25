from typing import Any
from collections.abc import Iterator, ValuesView, ItemsView
from nonesafe_ex.helpers import _wrap


class _WrappedValuesView(ValuesView):
    """迭代时自动包装每个 value 的 ValuesView。"""

    def __iter__(self) -> Iterator[Any]:
        return (_wrap(v) for v in self._mapping.values())

    def __contains__(self, value: Any) -> bool:
        return value in self._mapping.values()

    def __len__(self) -> int:
        return len(self._mapping)


class _WrappedItemsView(ItemsView):
    """迭代时只包装 value，保留 key 不变的 ItemsView。"""

    def __iter__(self) -> Iterator[tuple[Any, Any]]:
        return ((k, _wrap(v)) for k, v in self._mapping.items())

    def __contains__(self, item: Any) -> bool:
        return item in self._mapping.items()

    def __len__(self) -> int:
        return len(self._mapping)
