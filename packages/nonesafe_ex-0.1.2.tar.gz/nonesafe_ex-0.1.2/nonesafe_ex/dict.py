from __future__ import annotations
from typing import Any, Union
from collections.abc import Iterator, ValuesView, ItemsView
from nonesafe_ex.nonelike import NoneLike
from nonesafe_ex.helpers import _wrap
from nonesafe_ex.views import _WrappedValuesView, _WrappedItemsView


class NoneSafeDict(dict):
    """None 安全的 dict。

    访问不存在的键返回 ``NoneLike`` 而非抛出 ``KeyError``；
    值中包含的 dict / list 也会被自动包装。
    """

    # ---- 读 ---------------------------------------------------------------

    def __getitem__(self, key: Any) -> Any:
        if key not in self:
            return NoneLike
        return _wrap(super().__getitem__(key))

    def get(self, key: Any, default: Any = None) -> Any:
        if key not in self:
            return _wrap(default)
        return _wrap(super().get(key))

    # ---- 迭代相关 ----------------------------------------------------------

    def values(self) -> ValuesView:
        """返回迭代时自动包装每个 value 的视图。"""
        return _WrappedValuesView(self)

    def items(self) -> ItemsView:
        """返回迭代时自动包装每个 value 的视图（key 不变）。"""
        return _WrappedItemsView(self)

    # keys() 无需覆盖 — key 不需要包装

    def __iter__(self) -> Iterator[Any]:
        return super().__iter__()  # 遍历 key，不需要包装

    def iterkeys(self) -> Iterator[Any]:
        """显式 key 迭代接口。"""
        return iter(self.keys())

    def itervalues(self) -> Iterator[Any]:
        """显式 value 迭代接口（自动包装）。"""
        return iter(self.values())

    def iteritems(self) -> Iterator[tuple[Any, Any]]:
        """显式 items 迭代接口（value 自动包装）。"""
        return iter(self.items())

    def __reversed__(self) -> Iterator[Any]:
        return reversed(list(self.keys()))  # py3.8+

    # ---- 写（返回值也做包装） ----------------------------------------------

    def pop(self, key: Any, default: Any = None) -> Any:
        try:
            return _wrap(super().pop(key))
        except KeyError:
            return _wrap(default)

    def popitem(self) -> tuple[Any, Any]:
        try:
            k, v = super().popitem()
            return k, _wrap(v)
        except KeyError:
            return NoneLike, NoneLike

    def setdefault(self, key: Any, default: Any = None) -> Any:
        return _wrap(super().setdefault(key, default))

    # ---- 复制 --------------------------------------------------------------

    def copy(self) -> NoneSafeDict:
        return NoneSafeDict(super().copy())

    # ---- 取值辅助（避免拿到原生 dict/list/None） -----------------------------

    def unwrap_or(self, key: Any, default: Any = None) -> Any:
        """安全读取：缺失键返回包装后的 default。"""
        return self.get(key, default)

    def first(self, default: Any = None) -> Any:
        """返回第一个 value（自动包装），空 dict 返回包装后的 default。"""
        for value in self.values():
            return value
        return _wrap(default)

    # ---- 合并运算符 (py3.9+) -----------------------------------------------

    def __or__(self, other: Any) -> NoneSafeDict:
        return NoneSafeDict(super().__or__(other))

    def __ror__(self, other: Any) -> NoneSafeDict:
        return NoneSafeDict(super().__ror__(other))

    def __ior__(self, other: Any) -> NoneSafeDict:
        super().__ior__(other)
        return self
