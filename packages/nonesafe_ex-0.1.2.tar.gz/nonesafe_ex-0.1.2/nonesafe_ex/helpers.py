from typing import Any

from nonesafe_ex.nonelike import NoneLike


def _wrap(value: Any) -> Any:
    """将 None / 容器包装为 None 安全形式，其它类型原样返回。"""
    if value is None:
        return NoneLike
    if isinstance(value, dict):
        from nonesafe_ex.dict import NoneSafeDict

        if isinstance(value, NoneSafeDict):
            return value
        return NoneSafeDict(value)
    if isinstance(value, list):
        from nonesafe_ex.list import NoneSafeList

        if isinstance(value, NoneSafeList):
            return value
        return NoneSafeList(value)
    return value
