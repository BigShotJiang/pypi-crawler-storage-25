from __future__ import annotations
from typing import overload, Any
from collections.abc import Iterator
from nonesafe_ex.nonelike import NoneLike
from nonesafe_ex.helpers import _wrap


class NoneSafeList(list):
    """None 安全的 list。

    越界 / 非法下标返回 ``NoneLike``；内部 dict / list 自动包装。
    """

    # ---- 读 ---------------------------------------------------------------

    @overload
    def __getitem__(self, index: int) -> Any: ...
    @overload
    def __getitem__(self, index: slice) -> NoneSafeList: ...

    def __getitem__(self, index: Any) -> Any:
        try:
            value = super().__getitem__(index)
        except (IndexError, TypeError):
            return NoneLike

        if isinstance(index, slice):
            return NoneSafeList(value)
        return _wrap(value)

    # ---- 迭代 --------------------------------------------------------------

    def __iter__(self) -> Iterator[Any]:
        """迭代时自动包装每一项。"""
        return (_wrap(v) for v in super().__iter__())

    def __reversed__(self) -> Iterator[Any]:
        return (_wrap(v) for v in super().__reversed__())

    # ---- 写（返回值包装） --------------------------------------------------

    def pop(self, index: int = -1) -> Any:
        try:
            return _wrap(super().pop(index))
        except IndexError:
            return NoneLike

    # ---- 复制 --------------------------------------------------------------

    def copy(self) -> NoneSafeList:
        return NoneSafeList(super().copy())

    # ---- 取值辅助（避免拿到原生 dict/list/None） -----------------------------

    def first(self, default: Any = None) -> Any:
        """返回首项（自动包装），空列表返回包装后的 default。"""
        if not self:
            return _wrap(default)
        return _wrap(super().__getitem__(0))

    def last(self, default: Any = None) -> Any:
        """返回末项（自动包装），空列表返回包装后的 default。"""
        if not self:
            return _wrap(default)
        return _wrap(super().__getitem__(-1))
