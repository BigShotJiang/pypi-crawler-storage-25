"""
Files Namespace - B2 object storage operations.

Provides file upload, download, and management via B2 object storage.
"""
import base64
from typing import Any, Dict, List, Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from ..start import Dominus


class FilesNamespace:
    """
    Object storage namespace.

    File operations go through /api/b2/* endpoints.
    Factory reset uses the admin-worker proxy route /api/admin/factory-reset-storage.
    Supports compliance mode for files requiring audit trails and retention.

    Usage:
        # Upload a file
        result = await dominus.files.upload(
            data=file_bytes,
            filename="report.pdf",
            category="documents"
        )

        # Upload compliance file
        result = await dominus.files.upload(
            data=pdf_bytes,
            filename="consent.pdf",
            compliance=True,
            actor=current_user_id,
            retention_days=365 * 7
        )

        # Download file (get presigned URL)
        url_info = await dominus.files.download(file_id=result["id"])

        # Fetch file content directly
        content = await dominus.files.fetch(file_id=result["id"])
    """

    def __init__(self, client: "Dominus"):
        self._client = client

    async def upload(
        self,
        data: bytes,
        filename: str,
        content_type: Optional[str] = None,
        category: str = "general",
        path: Optional[str] = None,
        tags: Optional[Dict[str, str]] = None,
        compliance: bool = False,
        actor: Optional[str] = None,
        retention_days: int = 90,
        actor_context: Optional[Dict[str, str]] = None,
    ) -> Dict[str, Any]:
        """
        Upload a file to object storage.

        Args:
            data: File content as bytes
            filename: Original filename
            content_type: MIME type (auto-detected if not provided)
            category: File category (default: "general")
            path: Logical path within category (default: auto-generated)
            tags: Optional metadata tags
            compliance: If True, enables audit trail and retention
            actor: User ID or "machine" (required if compliance=True)
            retention_days: Retention period for compliance files (default: 90)

        Returns:
            Dict with file ID, path, size, and metadata
        """
        # Base64 encode the file content
        file_b64 = base64.b64encode(data).decode('utf-8')

        body = {
            "content_b64": file_b64,
            "filename": filename,
            "category": category,
            "path": path or filename,
            "content_type": content_type or "application/octet-stream",
        }

        if tags:
            body["tags"] = tags

        # Compliance mode
        if compliance:
            body["is_compliance"] = True
            body["retention_days"] = retention_days
            if actor:
                body["owner_user_id"] = actor

        return await self._client._request(
            endpoint="/api/b2/upload",
            body=body,
            actor=actor_context,
        )

    async def download(
        self,
        file_id: Optional[str] = None,
        category: Optional[str] = None,
        path: Optional[str] = None,
        actor: Optional[str] = None,
        expires_seconds: int = 3600
    ) -> Dict[str, Any]:
        """
        Get a presigned download URL for a file.

        Args:
            file_id: File UUID (preferred)
            category: File category (alternative lookup with path)
            path: Logical path (alternative lookup with category)
            actor: User ID for audit (required for compliance files)
            expires_seconds: URL expiration time (default: 1 hour)

        Returns:
            Dict with "download_url", "expires_at", and file metadata
        """
        body = {"expires_seconds": expires_seconds}

        if file_id:
            body["object_id"] = file_id
        if category:
            body["category"] = category
        if path:
            body["path"] = path
        if actor:
            body["actor_user_id"] = actor

        return await self._client._request(
            endpoint="/api/b2/download",
            body=body
        )

    async def fetch(
        self,
        file_id: Optional[str] = None,
        category: Optional[str] = None,
        path: Optional[str] = None,
        actor: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Fetch file content directly.

        Args:
            file_id: File UUID (preferred)
            category: File category (alternative lookup with path)
            path: Logical path (alternative lookup with category)
            actor: User ID for audit (required for compliance files)

        Returns:
            Dict with "data" (base64 encoded), "filename", "content_type"
        """
        body = {}

        body["return_data"] = True
        if file_id:
            body["object_id"] = file_id
        if category:
            body["category"] = category
        if path:
            body["path"] = path
        if actor:
            body["actor_user_id"] = actor

        return await self._client._request(
            endpoint="/api/b2/fetch",
            body=body
        )

    async def list(
        self,
        category: Optional[str] = None,
        prefix: Optional[str] = None,
        limit: int = 100,
        cursor: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        List files with optional filtering.

        Args:
            category: Filter by category
            prefix: Filter by path prefix
            limit: Maximum files to return (default: 100)
            cursor: Pagination cursor

        Returns:
            Dict with "objects" list, "cursor", "count"
        """
        body = {"limit": limit}

        if category:
            body["category"] = category
        if prefix:
            body["prefix"] = prefix
        if cursor:
            body["cursor"] = cursor

        return await self._client._request(
            endpoint="/api/b2/list",
            body=body
        )

    async def delete(
        self,
        file_id: Optional[str] = None,
        category: Optional[str] = None,
        path: Optional[str] = None,
        actor: Optional[str] = None,
        actor_context: Optional[Dict[str, str]] = None,
    ) -> Dict[str, Any]:
        """
        Delete a file.

        Args:
            file_id: File UUID (preferred)
            category: File category (alternative lookup with path)
            path: Logical path (alternative lookup with category)
            actor: User ID for audit

        Returns:
            Dict with "deleted" status
        """
        body = {}

        if file_id:
            body["object_id"] = file_id
        if category:
            body["category"] = category
        if path:
            body["path"] = path
        if actor:
            body["actor_user_id"] = actor

        return await self._client._request(
            endpoint="/api/b2/delete",
            body=body,
            actor=actor_context,
        )

    async def move(
        self,
        file_id: str,
        new_category: Optional[str] = None,
        new_path: Optional[str] = None,
        actor_context: Optional[Dict[str, str]] = None,
    ) -> Dict[str, Any]:
        """
        Move or rename a file.

        Args:
            file_id: File UUID
            new_category: New category (optional)
            new_path: New logical path (optional)

        Returns:
            Updated file metadata
        """
        body = {"object_id": file_id}

        if new_category:
            body["new_category"] = new_category
        if new_path:
            body["new_path"] = new_path

        return await self._client._request(
            endpoint="/api/b2/move",
            body=body,
            actor=actor_context,
        )

    async def update_meta(
        self,
        file_id: str,
        tags: Optional[Dict[str, str]] = None,
        description: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Update file metadata.

        Args:
            file_id: File UUID
            tags: New metadata tags (replaces existing)
            description: New description

        Returns:
            Updated file metadata
        """
        body = {"object_id": file_id}

        if tags is not None:
            body["tags"] = tags
        if description is not None:
            body["description"] = description

        return await self._client._request(
            endpoint="/api/b2/update",
            body=body
        )

    # ========================================
    # STORAGE BROWSER METHODS
    # ========================================

    async def browse(
        self,
        path: str = "/",
        category: Optional[str] = None,
        view: Optional[str] = None,
        limit: int = 100,
        cursor: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Browse files and folders at a path.

        Args:
            path: Directory path to browse (default: "/")
            category: Filter by category
            view: View name (e.g., "all", "compliance")
            limit: Maximum items to return (default: 100)
            cursor: Pagination cursor

        Returns:
            Dict with "path", "folders", "files", and optional "cursor"
        """
        body = {
            "path": path,
            "limit": limit
        }

        if category:
            body["category"] = category
        if view:
            body["view"] = view
        if cursor:
            body["cursor"] = cursor

        return await self._client._request(
            endpoint="/api/b2/browse",
            body=body
        )

    async def get_storage_stats(self) -> Dict[str, Any]:
        """
        Get storage statistics.

        Returns:
            Dict with "total_objects", "total_size_bytes", "by_category"
        """
        return await self._client._request(
            endpoint="/api/b2/stats",
            body={}
        )

    async def list_categories(self) -> Dict[str, Any]:
        """
        List all file categories.

        Returns:
            Dict with "categories" list containing name, object_count, total_size_bytes
        """
        return await self._client._request(
            endpoint="/api/b2/categories",
            body={}
        )

    async def list_views(
        self,
        user_scopes: Optional[List[str]] = None,
        active_tenant: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        List storage views filtered by user access.

        Args:
            user_scopes: User scopes (for example ["admin", "admin-view"])
            active_tenant: Active tenant slug for non-admin filtering

        Returns:
            Dict with "views" list, "total_views", "is_admin"
        """
        body = {
            "user_scopes": user_scopes or [],
            "active_tenant": active_tenant,
        }

        return await self._client._request(
            endpoint="/api/b2/views",
            body=body
        )

    async def list_categories_in_view(self, view: str) -> Dict[str, Any]:
        """
        List categories within a specific view.

        Args:
            view: View name

        Returns:
            Dict with "categories" list
        """
        return await self._client._request(
            endpoint="/api/b2/view-categories",
            body={"view": view}
        )

    async def create_folder(
        self,
        path: str,
        category: Optional[str] = None,
        actor_context: Optional[Dict[str, str]] = None,
    ) -> Dict[str, Any]:
        """
        Create a folder.

        Args:
            path: Folder path to create
            category: Category for the folder (optional)

        Returns:
            Dict with "created", "path", optional "placeholder_id", "message"
        """
        body = {"path": path}

        if category:
            body["category"] = category

        return await self._client._request(
            endpoint="/api/b2/folder",
            body=body,
            actor=actor_context,
        )

    async def delete_folder(
        self,
        path: str,
        category: Optional[str] = None,
        force: bool = False,
        actor_context: Optional[Dict[str, str]] = None,
    ) -> Dict[str, Any]:
        """
        Delete a folder.

        Args:
            path: Folder path to delete
            category: Category of the folder (optional)
            force: Force delete non-empty folders (default: False)

        Returns:
            Dict with "deleted", "path", "deleted_count", etc.
        """
        body = {
            "path": path,
            "force": force
        }

        if category:
            body["category"] = category

        return await self._client._request(
            endpoint="/api/b2/folder",
            method="DELETE",
            body=body,
            actor=actor_context,
        )

    async def factory_reset(
        self,
        force: bool = False,
        reinitialize_structure: bool = True,
        actor_context: Optional[Dict[str, str]] = None,
    ) -> Dict[str, Any]:
        """
        Factory reset storage (delete all objects in project/environment).

        WARNING: This is a destructive operation.

        Args:
            force: Hard delete compliance objects when True
            reinitialize_structure: Recreate default folder structure after reset

        Returns:
            Dict with reset/deletion counts
        """
        body = {
            "confirm": "FACTORY_RESET",
            "force": force,
            "reinitialize_structure": reinitialize_structure,
        }

        return await self._client._request(
            endpoint="/api/admin/factory-reset-storage",
            body=body,
            actor=actor_context,
        )
