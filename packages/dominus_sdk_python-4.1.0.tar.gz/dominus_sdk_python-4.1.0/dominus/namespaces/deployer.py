"""Thin Deployer control-plane namespace."""
from typing import Any, Dict, Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from ..start import Dominus


def _normalize_deployer_path(path: str) -> str:
    trimmed = path.strip()
    normalized = trimmed if trimmed.startswith("/") else f"/{trimmed}"
    if normalized == "/svc/deployer" or normalized.startswith("/svc/deployer/"):
        return normalized
    if normalized == "/api/deployer" or normalized.startswith("/api/deployer/"):
        return normalized
    return f"/svc/deployer{normalized}"


class DeployerNamespace:
    """Deployer operator control-plane routes used by Mothership and MCP."""

    def __init__(self, client: "Dominus"):
        self._client = client

    async def request(
        self,
        path: str,
        *,
        method: str = "GET",
        body: Any = None,
        headers: Optional[Dict[str, str]] = None,
        timeout: float = 30.0,
    ) -> Any:
        return await self._client.gateway_fetch(
            _normalize_deployer_path(path),
            method=method,
            body=body,
            headers=headers,
            timeout=timeout,
        )
