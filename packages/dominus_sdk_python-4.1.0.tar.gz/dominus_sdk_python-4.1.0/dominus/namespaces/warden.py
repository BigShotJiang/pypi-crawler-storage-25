"""Thin Warden control-plane namespace."""
from typing import Any, Dict, Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from ..start import Dominus


def _normalize_warden_path(path: str) -> str:
    trimmed = path.strip()
    normalized = trimmed if trimmed.startswith("/") else f"/{trimmed}"
    if normalized == "/svc/warden" or normalized.startswith("/svc/warden/"):
        return normalized
    if normalized == "/api/warden" or normalized.startswith("/api/warden/"):
        return normalized
    return f"/svc/warden{normalized}"


class WardenNamespace:
    """Warden operator control-plane routes used by Mothership and MCP."""

    def __init__(self, client: "Dominus"):
        self._client = client

    async def request(
        self,
        path: str,
        *,
        method: str = "GET",
        body: Any = None,
        headers: Optional[Dict[str, str]] = None,
        timeout: float = 30.0,
    ) -> Any:
        return await self._client.gateway_fetch(
            _normalize_warden_path(path),
            method=method,
            body=body,
            headers=headers,
            timeout=timeout,
        )
