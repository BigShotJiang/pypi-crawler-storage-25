import sys
from pathlib import Path

import pytest


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from dominus.namespaces.logs import LogsNamespace  # noqa: E402


class FakeClient:
    def __init__(self):
        self.calls = []

    async def _request(
        self,
        endpoint,
        method="POST",
        body=None,
        user_token=None,
        use_gateway=False,
        timeout=30.0,
    ):
        self.calls.append(
            {
                "endpoint": endpoint,
                "method": method,
                "body": body,
                "user_token": user_token,
                "use_gateway": use_gateway,
                "timeout": timeout,
            }
        )
        return {"events": [{"event_id": "log-1"}]}


@pytest.mark.asyncio
async def test_logs_tail_forwards_business_filters():
    client = FakeClient()
    namespace = LogsNamespace(client)

    events = await namespace.tail(
        limit=25,
        trace_id="trace-123",
        request_id="req-123",
        since="2026-04-11T08:33:00Z",
        until="2026-04-11T09:33:00Z",
        service="dominus-authority",
        level="error",
        company="carebridge-summit",
        subject="PCM47474562",
        run_id="run-123",
        deploy_id="deploy-123",
        installation_id="inst-123",
        artifact_ref="ar://carebridge/summit/production/company/report_snapshot_current",
    )

    assert len(events) == 1
    assert client.calls[0]["endpoint"] == (
        "/api/logs/tail?"
        "limit=25&trace_id=trace-123&request_id=req-123&since=2026-04-11T08%3A33%3A00Z"
        "&until=2026-04-11T09%3A33%3A00Z&service=dominus-authority&level=error&company=carebridge-summit"
        "&subject=PCM47474562&run_id=run-123&deploy_id=deploy-123"
        "&installation_id=inst-123&artifact_ref="
        "ar%3A%2F%2Fcarebridge%2Fsummit%2Fproduction%2Fcompany%2Freport_snapshot_current"
    )
    assert client.calls[0]["method"] == "GET"
    assert client.calls[0]["use_gateway"] is True


@pytest.mark.asyncio
async def test_logs_get_archive_status_forwards_filters():
    client = FakeClient()
    namespace = LogsNamespace(client)

    payload = await namespace.get_archive_status(
        all_scopes=True,
        target_org_id="org-123",
        target_env="production",
        use_shared=True,
        include_buffer=True,
        limit=5,
    )

    assert payload["events"][0]["event_id"] == "log-1"
    assert client.calls[0]["endpoint"] == (
        "/api/logs/archive-status?"
        "all_scopes=true&target_org_id=org-123&target_env=production&use_shared=true&include_buffer=true&limit=5"
    )
    assert client.calls[0]["method"] == "GET"
    assert client.calls[0]["use_gateway"] is True


@pytest.mark.asyncio
async def test_logs_archive_maintenance_helpers_forward_canonical_body():
    client = FakeClient()
    namespace = LogsNamespace(client)

    await namespace.repair_archive_manifests(
        since="2026-04-01T00:00:00Z",
        until="2026-04-02T00:00:00Z",
        target_org_id="org-123",
        target_env="production",
        use_shared=True,
    )
    await namespace.verify_archive_manifests(
        since="2026-04-01T00:00:00Z",
        until="2026-04-02T00:00:00Z",
        target_org_id="org-123",
        target_env="production",
        use_shared=True,
    )
    await namespace.prune_archive_retention(
        since="2026-01-01T00:00:00Z",
        until="2026-01-02T00:00:00Z",
        retention_days=90,
        dry_run=False,
        confirm="DELETE_EXPIRED_ARCHIVE_OBJECTS",
        target_org_id="org-123",
        target_env="production",
        use_shared=True,
    )
    await namespace.dry_run_archive_buffer_maintenance(
        sample_limit=25,
        max_archive_buckets=3,
        target_org_id="org-123",
        target_env="production",
        use_shared=True,
    )
    await namespace.run_archive_buffer_maintenance(
        dry_run=False,
        confirm="DELETE_ARCHIVE_BUFFER_RESIDUE",
        all_scopes=True,
        max_scopes=1,
        salvage_missing_archive=True,
        sample_limit=500,
        max_archive_buckets=24,
        batch_runs=5,
        stop_when_payload_fields_at_or_below=145000,
        max_runtime_ms=8000,
        target_org_id="org-123",
        target_env="production",
        use_shared=True,
    )

    assert client.calls[0]["endpoint"] == "/api/logs/archive-repair"
    assert client.calls[0]["method"] == "POST"
    assert client.calls[0]["body"] == {
        "since": "2026-04-01T00:00:00Z",
        "until": "2026-04-02T00:00:00Z",
        "target_org_id": "org-123",
        "target_env": "production",
        "use_shared": True,
    }
    assert client.calls[1]["endpoint"] == "/api/logs/archive-verify"
    assert client.calls[1]["body"]["target_org_id"] == "org-123"
    assert client.calls[1]["body"]["use_shared"] is True
    assert client.calls[2]["endpoint"] == "/api/logs/archive-prune"
    assert client.calls[2]["body"] == {
        "since": "2026-01-01T00:00:00Z",
        "until": "2026-01-02T00:00:00Z",
        "retention_days": 90,
        "dry_run": False,
        "confirm": "DELETE_EXPIRED_ARCHIVE_OBJECTS",
        "target_org_id": "org-123",
        "target_env": "production",
        "use_shared": True,
    }
    assert client.calls[3]["endpoint"] == "/api/logs/archive-buffer-maintenance"
    assert client.calls[3]["method"] == "POST"
    assert client.calls[3]["body"] == {
        "dry_run": True,
        "sample_limit": 25,
        "max_archive_buckets": 3,
        "target_org_id": "org-123",
        "target_env": "production",
        "use_shared": True,
    }
    assert client.calls[4]["endpoint"] == "/api/logs/archive-buffer-maintenance"
    assert client.calls[4]["method"] == "POST"
    assert client.calls[4]["body"] == {
        "dry_run": False,
        "confirm": "DELETE_ARCHIVE_BUFFER_RESIDUE",
        "all_scopes": True,
        "max_scopes": 1,
        "salvage_missing_archive": True,
        "sample_limit": 500,
        "max_archive_buckets": 24,
        "batch_runs": 5,
        "stop_when_payload_fields_at_or_below": 145000,
        "max_runtime_ms": 8000,
        "target_org_id": "org-123",
        "target_env": "production",
        "use_shared": True,
    }
