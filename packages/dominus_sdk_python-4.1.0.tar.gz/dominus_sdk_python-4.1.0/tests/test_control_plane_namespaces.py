import pytest

import dominus.start as start_module


@pytest.fixture()
def sdk(monkeypatch):
    monkeypatch.setattr(start_module, "_VALIDATION_ERROR", None)
    monkeypatch.setattr(start_module, "_TOKEN", "a" * 64)
    monkeypatch.setattr(start_module, "_VALIDATED", False)
    monkeypatch.setattr(start_module, "_BASE_URL", "https://gateway.example")
    monkeypatch.setattr(start_module, "_GATEWAY_URL", "https://gateway.example")
    return start_module.Dominus()


@pytest.mark.asyncio
async def test_deployer_namespace_uses_gateway_fetch(monkeypatch, sdk):
    calls = []

    async def fake_gateway_fetch(path, **kwargs):
        calls.append((path, kwargs))
        return {"ok": True}

    monkeypatch.setattr(sdk, "gateway_fetch", fake_gateway_fetch)

    result = await sdk.deployer.request("/deployments/active", method="GET")

    assert result == {"ok": True}
    assert calls == [
        ("/svc/deployer/deployments/active", {"method": "GET", "body": None, "headers": None, "timeout": 30.0})
    ]


@pytest.mark.asyncio
async def test_warden_namespace_preserves_explicit_service_path(monkeypatch, sdk):
    calls = []

    async def fake_gateway_fetch(path, **kwargs):
        calls.append((path, kwargs))
        return {"ok": True}

    monkeypatch.setattr(sdk, "gateway_fetch", fake_gateway_fetch)

    result = await sdk.warden.request("/svc/warden/users/example", method="DELETE")

    assert result == {"ok": True}
    assert calls == [
        ("/svc/warden/users/example", {"method": "DELETE", "body": None, "headers": None, "timeout": 30.0})
    ]
