import json
import sys
from pathlib import Path

import pytest


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import dominus.helpers.core as core_module  # noqa: E402
import dominus.namespaces.auth as auth_module  # noqa: E402
import dominus.start as start_module  # noqa: E402
from dominus.namespaces.auth import AuthNamespace  # noqa: E402


class FakeResponse:
    def __init__(self, text: str, *, status_code: int = 200):
        self.text = text
        self.status_code = status_code

    @property
    def is_error(self) -> bool:
        return self.status_code >= 400

    def raise_for_status(self):
        return None


class RequestClient:
    calls = []

    def __init__(self, *, base_url, headers, timeout):
        self.base_url = base_url
        self.headers = headers
        self.timeout = timeout

    async def __aenter__(self):
        return self

    async def __aexit__(self, exc_type, exc, tb):
        return False

    async def post(self, endpoint, content=None):
        self.calls.append(
            {
                "endpoint": endpoint,
                "content": content,
                "base_url": self.base_url,
                "headers": self.headers,
                "timeout": self.timeout,
            }
        )
        return FakeResponse(json.dumps({"success": True, "data": {"ok": True}}))


class UnwrappedRequestClient:
    calls = []

    def __init__(self, *, base_url, headers, timeout):
        self.base_url = base_url
        self.headers = headers
        self.timeout = timeout

    async def __aenter__(self):
        return self

    async def __aexit__(self, exc_type, exc, tb):
        return False

    async def get(self, endpoint):
        self.calls.append(
            {
                "endpoint": endpoint,
                "base_url": self.base_url,
                "headers": self.headers,
                "timeout": self.timeout,
            }
        )
        return FakeResponse(json.dumps({"secret": {"key": "PROVISION_REDIS_URL_REST", "value": "redis-url"}}))


class ServiceJwtClient:
    def __init__(self, *, base_url, headers, timeout, proxy):
        self.base_url = base_url
        self.headers = headers
        self.timeout = timeout
        self.proxy = proxy

    async def __aenter__(self):
        return self

    async def __aexit__(self, exc_type, exc, tb):
        return False

    async def post(self, path, content=None):
        return FakeResponse(json.dumps({"success": True, "data": {"access_token": "jwt-123"}}))


class SelectedScopeMintClient:
    def __init__(self, *, base_url, headers, timeout, proxy):
        self.base_url = base_url
        self.headers = headers
        self.timeout = timeout
        self.proxy = proxy

    async def __aenter__(self):
        return self

    async def __aexit__(self, exc_type, exc, tb):
        return False

    async def post(self, path, content=None):
        return FakeResponse(json.dumps({"success": True, "data": {"token": "selected-jwt"}}))


class JwksClient:
    calls = []

    def __init__(self, *, timeout):
        self.timeout = timeout

    async def __aenter__(self):
        return self

    async def __aexit__(self, exc_type, exc, tb):
        return False

    async def get(self, url, headers):
        self.calls.append({"url": url, "headers": headers, "timeout": self.timeout})
        return FakeResponse(json.dumps({"success": True, "data": {"keys": [{"kid": "key-1", "kty": "RSA"}]}}))


@pytest.fixture()
def sdk(monkeypatch):
    monkeypatch.setattr(start_module, "_VALIDATION_ERROR", None)
    monkeypatch.setattr(start_module, "_TOKEN", "a" * 64)
    monkeypatch.setattr(start_module, "_VALIDATED", False)
    monkeypatch.setattr(start_module, "_BASE_URL", "https://gateway.example")
    monkeypatch.setattr(start_module, "_GATEWAY_URL", "https://gateway.example")
    return start_module.Dominus()


@pytest.mark.asyncio
async def test_request_accepts_raw_json_success_envelope(monkeypatch, sdk):
    RequestClient.calls = []

    async def fake_ensure_valid_jwt(psk_token, base_url):
        return "jwt-abc"

    monkeypatch.setattr(core_module, "_ensure_valid_jwt", fake_ensure_valid_jwt)
    monkeypatch.setattr(start_module.httpx, "AsyncClient", RequestClient)

    result = await sdk._request("/api/health", body={"ping": True}, use_gateway=True)

    assert result == {"ok": True}
    assert RequestClient.calls[0]["endpoint"] == "/svc/health"


@pytest.mark.asyncio
async def test_request_accepts_unwrapped_control_plane_success(monkeypatch, sdk):
    UnwrappedRequestClient.calls = []

    async def fake_ensure_valid_jwt(psk_token, base_url):
        return "jwt-abc"

    monkeypatch.setattr(core_module, "_ensure_valid_jwt", fake_ensure_valid_jwt)
    monkeypatch.setattr(start_module.httpx, "AsyncClient", UnwrappedRequestClient)

    result = await sdk._request("/api/warden/secrets/PROVISION_REDIS_URL_REST", method="GET", use_gateway=True)

    assert result == {"secret": {"key": "PROVISION_REDIS_URL_REST", "value": "redis-url"}}
    assert UnwrappedRequestClient.calls[0]["endpoint"] == "/svc/warden/secrets/PROVISION_REDIS_URL_REST"


def test_dominus_constructor_accepts_gateway_context_keywords():
    sdk = start_module.Dominus(
        gateway_user_token="user-jwt",
        gateway_org_id="org-123",
        gateway_app_slug="carebridge",
        gateway_env="production",
    )

    assert sdk._gateway_user_token == "user-jwt"
    assert sdk._gateway_org_id == "org-123"
    assert sdk._gateway_app_slug == "carebridge"
    assert sdk._gateway_env == "production"


@pytest.mark.asyncio
async def test_service_jwt_mint_accepts_raw_json_envelope(monkeypatch):
    monkeypatch.setattr(core_module.httpx, "AsyncClient", ServiceJwtClient)
    monkeypatch.setattr(core_module.gateway_circuit_breaker, "can_execute", lambda: True)
    monkeypatch.setattr(core_module.gateway_circuit_breaker, "record_success", lambda: None)
    monkeypatch.setattr(core_module.gateway_circuit_breaker, "record_failure", lambda: None)
    monkeypatch.setattr(core_module.gateway_circuit_breaker, "_state", core_module.gateway_circuit_breaker.CLOSED)
    monkeypatch.setattr(core_module.gateway_circuit_breaker, "_failure_count", 0)

    from dominus.config import endpoints as endpoint_config

    monkeypatch.setattr(endpoint_config, "get_gateway_url", lambda: "https://gateway.example")
    monkeypatch.setattr(endpoint_config, "get_proxy_config", lambda: None)

    token = await core_module._get_service_jwt("psk-token", "https://ignored.example")
    assert token == "jwt-123"


@pytest.mark.asyncio
async def test_selected_scope_mint_accepts_raw_json_envelope(monkeypatch):
    monkeypatch.setattr(core_module.httpx, "AsyncClient", SelectedScopeMintClient)

    from dominus.config import endpoints as endpoint_config

    monkeypatch.setattr(endpoint_config, "get_gateway_url", lambda: "https://gateway.example")
    monkeypatch.setattr(endpoint_config, "get_proxy_config", lambda: None)

    token = await core_module.mint_selected_scope_jwt(
        "psk-token",
        target_org_id="org-123",
        target_app_slug="carebridge",
        target_env="production",
    )
    assert token == "selected-jwt"


@pytest.mark.asyncio
async def test_auth_namespace_get_jwks_accepts_raw_json_envelope(monkeypatch):
    JwksClient.calls = []
    monkeypatch.setattr(auth_module.httpx, "AsyncClient", JwksClient)
    monkeypatch.setattr(auth_module, "get_gateway_url", lambda: "https://gateway.example")
    monkeypatch.setattr(auth_module, "get_current_trace_id", lambda: "trace-1")
    monkeypatch.setattr(auth_module, "get_current_span_id", lambda: "span-1")

    namespace = AuthNamespace(object())
    result = await namespace.get_jwks()

    assert result == {"keys": [{"kid": "key-1", "kty": "RSA"}]}
    assert JwksClient.calls[0]["url"] == "https://gateway.example/jwt/jwks"
