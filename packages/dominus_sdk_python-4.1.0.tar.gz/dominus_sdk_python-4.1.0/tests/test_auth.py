import base64
import json
import sys
from pathlib import Path

import pytest


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import dominus.namespaces.auth as auth_module  # noqa: E402
from dominus.namespaces.auth import AuthNamespace  # noqa: E402


class FakeResponse:
    def __init__(self, payload):
        self.text = base64.b64encode(json.dumps(payload).encode("utf-8")).decode("utf-8")

    def raise_for_status(self):
        return None


class FakeAsyncClient:
    calls = []

    def __init__(self, *, timeout):
        self.timeout = timeout

    async def __aenter__(self):
        return self

    async def __aexit__(self, exc_type, exc, tb):
        return False

    async def get(self, url, headers):
        self.calls.append({"url": url, "headers": headers, "timeout": self.timeout})
        return FakeResponse({"success": True, "data": {"keys": [{"kid": "key-1", "kty": "RSA"}]}})


class FakeClient:
    def __init__(self):
        self.calls = []

    async def _request(self, **kwargs):
        self.calls.append(kwargs)
        return {"ok": True}


@pytest.mark.asyncio
async def test_get_jwks_uses_gateway_jwt_route_and_caches(monkeypatch):
    FakeAsyncClient.calls = []
    monkeypatch.setattr(auth_module.httpx, "AsyncClient", FakeAsyncClient)
    monkeypatch.setattr(auth_module, "get_gateway_url", lambda: "https://gateway.example")
    monkeypatch.setattr(auth_module, "get_current_trace_id", lambda: "trace-1")
    monkeypatch.setattr(auth_module, "get_current_span_id", lambda: "span-1")

    namespace = AuthNamespace(FakeClient())
    first = await namespace.get_jwks()
    second = await namespace.get_jwks()

    assert first == {"keys": [{"kid": "key-1", "kty": "RSA"}]}
    assert second == first
    assert len(FakeAsyncClient.calls) == 1
    assert FakeAsyncClient.calls[0]["url"] == "https://gateway.example/jwt/jwks"


@pytest.mark.asyncio
async def test_nav_item_helpers_write_guardian_navigation_path():
    client = FakeClient()
    namespace = AuthNamespace(client)

    await namespace.create_nav_item(
        title="Structured Reporting",
        path="/dashboard/radiologist/structured-reporting",
        page_id="page-1",
        icon="ListChecks",
    )
    await namespace.update_nav_item(
        "nav-1",
        path="/dashboard/radiologist/procedure-settings",
        page_id="page-2",
    )

    assert client.calls[0]["endpoint"] == "/api/guardian/nav-items"
    assert client.calls[0]["body"]["path"] == "/dashboard/radiologist/structured-reporting"
    assert client.calls[0]["body"]["page_id"] == "page-1"
    assert client.calls[1]["endpoint"] == "/api/guardian/nav-items/nav-1"
    assert client.calls[1]["method"] == "PUT"
    assert client.calls[1]["body"]["path"] == "/dashboard/radiologist/procedure-settings"
    assert client.calls[1]["body"]["page_id"] == "page-2"


@pytest.mark.asyncio
async def test_nav_item_helpers_preserve_positional_icon_compatibility():
    client = FakeClient()
    namespace = AuthNamespace(client)

    await namespace.create_nav_item("Structured Reporting", "ListChecks")
    await namespace.update_nav_item("nav-1", "Procedure Settings", "ClipboardList")

    assert client.calls[0]["body"]["icon"] == "ListChecks"
    assert "path" not in client.calls[0]["body"]
    assert client.calls[1]["body"]["title"] == "Procedure Settings"
    assert client.calls[1]["body"]["icon"] == "ClipboardList"
    assert "path" not in client.calls[1]["body"]
