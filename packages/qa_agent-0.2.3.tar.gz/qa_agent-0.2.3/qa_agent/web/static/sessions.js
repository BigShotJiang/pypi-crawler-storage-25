(function () {
  const container = document.getElementById('sessions-container');
  const activeJobsContainer = document.getElementById('active-jobs-container');
  const search = document.getElementById('search');

  const SEVERITY_ORDER = ['critical', 'high', 'medium', 'low', 'info'];

  function severityBadge(sev, count) {
    return count > 0
      ? `<span class="badge badge-${sev}" title="${sev}">${count}</span>`
      : '';
  }

  function formatDuration(secs) {
    if (!secs) return '—';
    if (secs < 60) return Math.round(secs) + 's';
    return Math.floor(secs / 60) + 'm ' + Math.round(secs % 60) + 's';
  }

  function formatDate(iso) {
    if (!iso) return '—';
    return new Date(iso).toLocaleString();
  }

  function renderSessions(sessions) {
    if (!sessions.length) {
      container.innerHTML = `<div class="empty-state">
        <p>No sessions found. <a href="/">Run a test</a> to get started.</p>
      </div>`;
      return;
    }

    const grouped = {};
    sessions.forEach(s => {
      (grouped[s.domain] = grouped[s.domain] || []).push(s);
    });

    let html = '';
    Object.keys(grouped).sort().forEach(domain => {
      html += `<details class="domain-group" open>
        <summary class="domain-title">
          <span class="domain-name">${domain}</span>
          <span class="domain-count">${grouped[domain].length} session${grouped[domain].length !== 1 ? 's' : ''}</span>
        </summary>
        <div class="session-list">`;

      grouped[domain].forEach(s => {
        const severityBadges = SEVERITY_ORDER
          .map(sev => severityBadge(sev, s.findings_by_severity?.[sev] || 0))
          .join('');
        const urls = (s.urls || []).map(u => `<span class="url-tag">${u}</span>`).join('');

        html += `<a class="session-card" href="/session/${s.domain}/${s.session_id}">
          <div class="session-card-main">
            <code class="session-id">${s.session_id}</code>
            <div class="session-urls">${urls}</div>
          </div>
          <div class="session-card-meta">
            <span class="text-muted">${formatDate(s.start_time)}</span>
            <span class="text-muted">${formatDuration(s.duration_seconds)}</span>
            <span class="findings-count ${s.total_findings > 0 ? 'has-findings' : ''}">${s.total_findings} finding${s.total_findings !== 1 ? 's' : ''}</span>
            <div class="severity-badges">${severityBadges}</div>
          </div>
        </a>`;
      });

      html += '</div></details>';
    });

    container.innerHTML = html;
  }

  const STATUS_LABELS = { queued: 'Queued', running: 'Running', stopping: 'Stopping', stopped: 'Stopped', completed: 'Completed', failed: 'Failed' };

  function renderActiveJobs(jobs) {
    const active = jobs.filter(j => !['completed', 'stopped', 'failed'].includes(j.status));
    if (!active.length) {
      activeJobsContainer.innerHTML = '';
      return;
    }

    let html = `<details class="domain-group" open>
      <summary class="domain-title">
        <span class="domain-name">Active Runs</span>
        <span class="domain-count">${active.length} in progress</span>
      </summary>
      <div class="session-list">`;

    active.forEach(j => {
      const domain = j.domain || '…';
      const statusCls = 'badge-' + (j.status === 'running' ? 'running' : 'queued');
      html += `<a class="session-card" href="/run/${j.job_id}">
        <div class="session-card-main">
          <code class="session-id">${j.job_id}</code>
          <span class="badge ${statusCls}">${STATUS_LABELS[j.status] || j.status}</span>
          <span class="text-muted" style="font-size:0.85rem">${domain}</span>
        </div>
        <div class="session-card-meta">
          <span class="text-muted">${j.pages_tested} page${j.pages_tested !== 1 ? 's' : ''} tested</span>
          <span class="findings-count ${j.total_findings > 0 ? 'has-findings' : ''}">${j.total_findings} finding${j.total_findings !== 1 ? 's' : ''}</span>
        </div>
      </a>`;
    });

    html += '</div></details>';
    activeJobsContainer.innerHTML = html;
  }

  function loadActiveJobs() {
    fetch('/api/jobs')
      .then(r => r.json())
      .then(data => renderActiveJobs(data.jobs || []))
      .catch(() => {});
  }

  function load(query) {
    const url = '/api/sessions?limit=200' + (query ? '&domain=' + encodeURIComponent(query) : '');
    fetch(url)
      .then(r => r.json())
      .then(data => {
        let sessions = data.sessions;
        if (query) {
          const q = query.toLowerCase();
          sessions = sessions.filter(s =>
            s.domain.toLowerCase().includes(q) ||
            (s.urls || []).some(u => u.toLowerCase().includes(q))
          );
        }
        renderSessions(sessions);
      })
      .catch(() => {
        container.innerHTML = '<div class="alert alert-error">Failed to load sessions.</div>';
      });
  }

  load();
  loadActiveJobs();

  const activeJobsInterval = setInterval(loadActiveJobs, 5000);
  window.addEventListener('unload', () => clearInterval(activeJobsInterval));

  let debounce;
  search.addEventListener('input', () => {
    clearTimeout(debounce);
    debounce = setTimeout(() => load(search.value.trim()), 300);
  });
}());
