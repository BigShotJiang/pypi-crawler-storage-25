from __future__ import annotations

import argparse
import sys
from pathlib import Path
from typing import Sequence

from .config import validate_mirage_config
from .httpx_client import MirageRunError, assert_mirage_run_clean, mirage_run_summary
from .runtime_paths import resolve_config_path


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Mirage run summary and CI gating tools.")
    subparsers = parser.add_subparsers(dest="command", required=True)

    summarize_parser = subparsers.add_parser(
        "summarize-run",
        help="Print a human-readable summary for one Mirage run.",
    )
    _add_run_arguments(summarize_parser)

    gate_parser = subparsers.add_parser(
        "gate-run",
        help="Exit non-zero when a Mirage run is risky or missing.",
    )
    _add_run_arguments(gate_parser)

    validate_parser = subparsers.add_parser(
        "validate-config",
        help="Validate Mirage mocks/policies before starting the proxy or CI run.",
    )
    validate_parser.add_argument(
        "--mocks-path",
        type=Path,
        default=None,
        help=(
            "Optional mocks config path. Defaults to MIRAGE_MOCKS_PATH, "
            "./mocks.yaml, or Mirage's bundled example mocks."
        ),
    )
    validate_parser.add_argument(
        "--policies-path",
        type=Path,
        default=None,
        help=(
            "Optional policies config path. Defaults to MIRAGE_POLICIES_PATH, "
            "./policies.yaml, or Mirage's bundled example policies."
        ),
    )

    gateway_parser = subparsers.add_parser(
        "gateway",
        help=(
            "Start the Mirage runtime gateway. Same policy file as CI, real "
            "upstream traffic, configurable enforcement."
        ),
    )
    gateway_parser.add_argument(
        "--upstream",
        required=True,
        help="Upstream base URL the gateway forwards requests to.",
    )
    gateway_parser.add_argument(
        "--mode",
        choices=["passthrough", "enforce"],
        default="passthrough",
        help=(
            "Enforcement mode. 'passthrough' forwards every request and logs "
            "policy decisions; 'enforce' blocks requests that fail policy with "
            "a 403. Default: passthrough."
        ),
    )
    gateway_parser.add_argument(
        "--policies-path",
        type=Path,
        default=None,
        help=(
            "Optional policies config path. Defaults to MIRAGE_POLICIES_PATH, "
            "./policies.yaml, or Mirage's bundled example policies."
        ),
    )
    gateway_parser.add_argument(
        "--host",
        default="127.0.0.1",
        help="Host for the gateway server (default: 127.0.0.1).",
    )
    gateway_parser.add_argument(
        "--port",
        type=int,
        default=8001,
        help="Port for the gateway server (default: 8001).",
    )
    gateway_parser.add_argument(
        "--artifact-root",
        type=Path,
        default=None,
        help="Optional Mirage trace directory override.",
    )

    return parser


def main(argv: Sequence[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)

    if args.command == "summarize-run":
        summary = mirage_run_summary(args.run_id, artifact_root=args.artifact_root)
        print(summary.to_text())
        return 0

    if args.command == "gate-run":
        try:
            summary = assert_mirage_run_clean(args.run_id, artifact_root=args.artifact_root)
        except MirageRunError as exc:
            print(str(exc))
            return 1
        print(summary.to_text())
        return 0

    if args.command == "validate-config":
        mocks_path, policies_path = _resolve_config_paths(
            mocks_path=args.mocks_path,
            policies_path=args.policies_path,
        )
        try:
            summary = validate_mirage_config(mocks_path, policies_path)
        except (FileNotFoundError, OSError, ValueError) as exc:
            print(f"Mirage config invalid: {exc}")
            return 1
        print(summary.to_text())
        return 0

    if args.command == "gateway":
        return _run_gateway(args)

    parser.error(f"Unsupported command: {args.command}")
    return 2


def _run_gateway(args: argparse.Namespace) -> int:
    import uvicorn

    from .gateway import MirageGateway, create_gateway_app

    gateway = MirageGateway(
        upstream_url=args.upstream,
        mode=args.mode,
        policies_path=args.policies_path,
        artifact_root=args.artifact_root,
    )
    app = create_gateway_app(gateway=gateway)

    print(
        f"Mirage gateway: mode={args.mode} upstream={args.upstream} "
        f"listening on http://{args.host}:{args.port}"
    )
    uvicorn.run(app, host=args.host, port=args.port, log_level="info")
    return 0


def _add_run_arguments(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--run-id", required=True, help="Stable Mirage run ID to summarize or gate.")
    parser.add_argument(
        "--artifact-root",
        type=Path,
        default=None,
        help="Optional Mirage trace directory override.",
    )


def _resolve_config_paths(
    *,
    mocks_path: Path | None,
    policies_path: Path | None,
) -> tuple[Path, Path]:
    return (
        resolve_config_path(
            explicit=mocks_path,
            env_var="MIRAGE_MOCKS_PATH",
            filename="mocks.yaml",
        ),
        resolve_config_path(
            explicit=policies_path,
            env_var="MIRAGE_POLICIES_PATH",
            filename="policies.yaml",
        ),
    )


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
