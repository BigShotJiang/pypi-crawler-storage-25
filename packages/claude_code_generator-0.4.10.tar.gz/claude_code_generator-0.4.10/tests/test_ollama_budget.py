"""Tests for Ollama per-cycle budget enforcement (issue #220).

TDD: Red → Green.

On the Ollama codepath (``effective_model`` is not ``None``) the orchestrator
substitutes non-negotiable #4's overage-abort with two explicit budgets:
turn count and wall-clock. The Anthropic Max path is untouched.

Turn accumulation reads from ``state.token_usage[<phase>].num_turns`` (or
``cycle.token_usage[<phase>].num_turns`` when a cycle is active), which
#204/#205 already populate on every phase run.
"""

from __future__ import annotations

import pytest

from code_generator import state as _state
from code_generator.orchestrator.ollama_budget import (
    OLLAMA_TURN_BUDGET,
    OLLAMA_WALLCLOCK_BUDGET_SECONDS,
    OllamaBudgetExceeded,
    OllamaBudgetTracker,
)
from code_generator.runner.types import TokenUsage

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------


class TestBudgetConstants:
    def test_turn_budget_default_is_200(self) -> None:
        assert OLLAMA_TURN_BUDGET == 200

    def test_wallclock_budget_default_is_3600_seconds(self) -> None:
        assert OLLAMA_WALLCLOCK_BUDGET_SECONDS == 3600


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


def _make_state_with_usage(
    turns_per_phase: dict[str, int], cycle_turns: dict[str, int] | None = None
) -> tuple[_state.State, _state.CycleState | None]:
    """Build a State (and optional CycleState) with given num_turns per phase."""
    st = _state.State(
        mode="multi-cycle",
        started_at="2026-01-01T00:00:00Z",
        updated_at="2026-01-01T00:00:00Z",
    )
    st.token_usage = {p: TokenUsage(num_turns=n) for p, n in turns_per_phase.items()}
    cycle: _state.CycleState | None = None
    if cycle_turns is not None:
        cycle = _state.CycleState(
            id=1,
            name="c1",
            milestone_number=1,
            milestone_title="c1",
            status="open",
            phase=None,
            issues=[],
            commit_sha=None,
        )
        cycle.token_usage = {p: TokenUsage(num_turns=n) for p, n in cycle_turns.items()}
    return st, cycle


# ---------------------------------------------------------------------------
# Turn-count budget
# ---------------------------------------------------------------------------


class TestTurnBudget:
    def test_under_budget_does_not_raise(self) -> None:
        """When total num_turns is below the budget, check() is a no-op."""
        st, cycle = _make_state_with_usage({}, cycle_turns={"phase1": 50, "phase2": 80})
        tracker = OllamaBudgetTracker(provider_is_ollama=True)

        tracker.check(st, cycle)  # must not raise

    def test_exactly_at_budget_does_not_raise(self) -> None:
        """The budget is strict-greater-than, so equal to the cap passes."""
        st, cycle = _make_state_with_usage({}, cycle_turns={"phase3_4": OLLAMA_TURN_BUDGET})
        tracker = OllamaBudgetTracker(provider_is_ollama=True)

        tracker.check(st, cycle)  # must not raise at ==

    def test_over_budget_raises_with_exact_message(self) -> None:
        """Exceeding the turn budget raises OllamaBudgetExceeded naming the budget."""
        st, cycle = _make_state_with_usage({}, cycle_turns={"phase3_4": OLLAMA_TURN_BUDGET + 1})
        tracker = OllamaBudgetTracker(provider_is_ollama=True)

        with pytest.raises(OllamaBudgetExceeded) as excinfo:
            tracker.check(st, cycle)

        msg = str(excinfo.value)
        assert "turn" in msg.lower()
        assert str(OLLAMA_TURN_BUDGET) in msg
        assert str(OLLAMA_TURN_BUDGET + 1) in msg

    def test_turns_aggregate_across_phases(self) -> None:
        """num_turns from every phase sum toward the per-cycle budget."""
        st, cycle = _make_state_with_usage(
            {},
            cycle_turns={
                "phase0": 50,
                "phase1": 30,
                "phase2": 30,
                "phase3_4": 60,
                "phase5": 20,
                "phase6": 10,
                "phase7": 5,
            },
        )
        # Sum = 205 > 200.
        tracker = OllamaBudgetTracker(provider_is_ollama=True)

        with pytest.raises(OllamaBudgetExceeded, match="205"):
            tracker.check(st, cycle)

    def test_single_mode_uses_state_token_usage_when_cycle_is_none(self) -> None:
        """When ``cycle`` is None, total turns come from state.token_usage."""
        st, _c = _make_state_with_usage({"phase0": OLLAMA_TURN_BUDGET + 5})
        tracker = OllamaBudgetTracker(provider_is_ollama=True)

        with pytest.raises(OllamaBudgetExceeded, match="turn"):
            tracker.check(st, cycle=None)


# ---------------------------------------------------------------------------
# Wall-clock budget
# ---------------------------------------------------------------------------


class TestWallclockBudget:
    def test_under_budget_does_not_raise(self) -> None:
        """Elapsed < budget → no raise."""
        st, cycle = _make_state_with_usage({}, cycle_turns={"phase0": 1})
        now = 1_000_000.0
        tracker = OllamaBudgetTracker(
            provider_is_ollama=True,
            clock=lambda: now,
        )
        tracker.start()
        # Simulate time passage below the budget.
        now += OLLAMA_WALLCLOCK_BUDGET_SECONDS - 10

        tracker.check(st, cycle)  # must not raise

    def test_over_budget_raises_with_exact_message(self) -> None:
        """Elapsed > budget → OllamaBudgetExceeded naming wall-clock."""
        st, cycle = _make_state_with_usage({}, cycle_turns={"phase0": 1})
        # Use a small mutable clock to simulate time moving forward.
        t = [1_000_000.0]

        def _clock() -> float:
            return t[0]

        tracker = OllamaBudgetTracker(provider_is_ollama=True, clock=_clock)
        tracker.start()
        t[0] += OLLAMA_WALLCLOCK_BUDGET_SECONDS + 1

        with pytest.raises(OllamaBudgetExceeded) as excinfo:
            tracker.check(st, cycle)

        msg = str(excinfo.value)
        assert "wall" in msg.lower() or "clock" in msg.lower()
        assert str(OLLAMA_WALLCLOCK_BUDGET_SECONDS) in msg

    def test_start_is_required_before_check(self) -> None:
        """check() without start() returns immediately on wall-clock (None start)."""
        st, cycle = _make_state_with_usage({}, cycle_turns={"phase0": 1})
        tracker = OllamaBudgetTracker(provider_is_ollama=True, clock=lambda: 1e12)

        # No start() call; wall-clock assertion must skip. Turn check still runs.
        tracker.check(st, cycle)  # must not raise (under turn budget, no start)


# ---------------------------------------------------------------------------
# Anthropic Max path — budgets do not fire
# ---------------------------------------------------------------------------


class TestAnthropicMaxUntouched:
    def test_anthropic_max_mode_skips_turn_budget(self) -> None:
        """provider_is_ollama=False → turn budget breach does not raise."""
        st, cycle = _make_state_with_usage({}, cycle_turns={"phase3_4": OLLAMA_TURN_BUDGET + 100})
        tracker = OllamaBudgetTracker(provider_is_ollama=False)

        tracker.check(st, cycle)  # must not raise

    def test_anthropic_max_mode_skips_wallclock_budget(self) -> None:
        """provider_is_ollama=False → wall-clock breach does not raise."""
        st, cycle = _make_state_with_usage({}, cycle_turns={"phase0": 1})
        t = [1_000_000.0]
        tracker = OllamaBudgetTracker(provider_is_ollama=False, clock=lambda: t[0])
        tracker.start()
        t[0] += OLLAMA_WALLCLOCK_BUDGET_SECONDS + 100

        tracker.check(st, cycle)  # must not raise


# ---------------------------------------------------------------------------
# Exception shape
# ---------------------------------------------------------------------------


class TestExceptionType:
    def test_ollama_budget_exceeded_is_runtime_error(self) -> None:
        """OllamaBudgetExceeded must subclass RuntimeError (no new hierarchy)."""
        assert issubclass(OllamaBudgetExceeded, RuntimeError)
