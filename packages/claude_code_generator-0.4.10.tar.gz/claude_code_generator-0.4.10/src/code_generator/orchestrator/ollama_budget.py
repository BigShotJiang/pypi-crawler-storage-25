"""Per-cycle safety budgets for the Ollama codepath (issue #220).

Ollama does not emit Anthropic's ``RateLimitEvent.info.overage_status``, so
non-negotiable #4 (abort on overage) cannot fire on the Ollama codepath.
This module substitutes the safety invariant with two explicit per-cycle
budgets — a turn-count cap and a wall-clock cap — whose breaches raise
:class:`OllamaBudgetExceeded` with a message naming which budget was hit.

These caps are defensive defaults. Operators who regularly exceed them on
real workloads should tune the module-level constants in one place rather
than editing phase internals.

Nothing is persisted in ``state.json`` — budgets are per-run enforcement,
not cross-resume accounting. A fresh ``OllamaBudgetTracker`` is created
for every cycle and discarded on abort or clean completion.
"""

from __future__ import annotations

import time
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from collections.abc import Callable

    from code_generator.state import CycleState, State

# ---------------------------------------------------------------------------
# Budget constants
# ---------------------------------------------------------------------------

OLLAMA_TURN_BUDGET = 200
"""Maximum num_turns allowed per cycle on the Ollama codepath."""

OLLAMA_WALLCLOCK_BUDGET_SECONDS = 3600
"""Maximum wall-clock elapsed (seconds) per cycle on the Ollama codepath (1 hour)."""


# ---------------------------------------------------------------------------
# Exception
# ---------------------------------------------------------------------------


class OllamaBudgetExceeded(RuntimeError):
    """Raised when the Ollama per-cycle turn or wall-clock budget is exceeded.

    Subclasses ``RuntimeError`` to match the existing safety-abort hierarchy
    (e.g. :class:`~code_generator.runner.types.OverageAbort`).
    """


# ---------------------------------------------------------------------------
# Tracker
# ---------------------------------------------------------------------------


class OllamaBudgetTracker:
    """Cheap per-cycle budget checker; a no-op on the Anthropic Max path."""

    def __init__(
        self,
        *,
        provider_is_ollama: bool,
        clock: Callable[[], float] | None = None,
    ) -> None:
        """Initialise a tracker; call :meth:`start` at cycle kickoff.

        Args:
            provider_is_ollama: When False every :meth:`check` call is a
                no-op so the Anthropic Max path stays byte-for-byte unchanged.
            clock: Injectable monotonic clock for deterministic tests;
                defaults to ``time.monotonic``.
        """
        self._active = provider_is_ollama
        self._clock = clock or time.monotonic
        self._start_time: float | None = None

    def start(self) -> None:
        """Record the cycle start time. Idempotent; only the first call matters."""
        if self._active and self._start_time is None:
            self._start_time = self._clock()

    def check(self, state: State, cycle: CycleState | None) -> None:
        """Raise :class:`OllamaBudgetExceeded` when either budget is breached."""
        if not self._active:
            return
        self._check_turn_budget(state, cycle)
        self._check_wallclock_budget()

    def _check_turn_budget(self, state: State, cycle: CycleState | None) -> None:
        total = _sum_num_turns(state, cycle)
        if total > OLLAMA_TURN_BUDGET:
            raise OllamaBudgetExceeded(
                f"Ollama turn-count budget exceeded: {total} > {OLLAMA_TURN_BUDGET}. "
                "Raise OLLAMA_TURN_BUDGET in code_generator.orchestrator.ollama_budget "
                "if real workloads need a higher cap."
            )

    def _check_wallclock_budget(self) -> None:
        if self._start_time is None:
            return
        elapsed = self._clock() - self._start_time
        if elapsed > OLLAMA_WALLCLOCK_BUDGET_SECONDS:
            raise OllamaBudgetExceeded(
                f"Ollama wall-clock budget exceeded: {elapsed:.0f}s > "
                f"{OLLAMA_WALLCLOCK_BUDGET_SECONDS}s. "
                "Raise OLLAMA_WALLCLOCK_BUDGET_SECONDS in "
                "code_generator.orchestrator.ollama_budget if real workloads "
                "need a higher cap."
            )


def _sum_num_turns(state: State, cycle: CycleState | None) -> int:
    """Sum ``num_turns`` across every phase of the active cycle (or state)."""
    source = cycle.token_usage if cycle is not None else state.token_usage
    return sum(usage.num_turns for usage in source.values())
