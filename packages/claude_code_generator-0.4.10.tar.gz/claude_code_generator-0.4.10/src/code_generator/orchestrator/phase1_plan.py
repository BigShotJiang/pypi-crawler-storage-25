"""Phase 1 — Planning: milestone creation and issue seeding.

Uses Opus 4.7 to read the requirements and create GitHub Issues
(via Bash tool calls inside the SDK session).

Non-negotiable #8: model is hard-coded to ``claude-opus-4-7``.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from code_generator import effort as _effort
from code_generator import gh
from code_generator import memory as _memory
from code_generator import state as _state
from code_generator.logging_setup import log_phase_usage, setup_phase_logger
from code_generator.orchestrator import cycle_prompts as _cycle_prompts
from code_generator.prompts import load_prompt
from code_generator.runner import rate_limit
from code_generator.runner._telemetry import accumulate_telemetry
from code_generator.runner.options import make_agent_options, max_turns_kwargs

if TYPE_CHECKING:
    import logging
    from pathlib import Path

    from code_generator.repo_info import RepoInfo
    from code_generator.runner.protocol import RunnerProtocol
    from code_generator.state import CycleState, State


class Phase1NoIssuesError(RuntimeError):
    """Phase 1 completed but created zero GitHub issues — abort the pipeline."""


def _deduplicate_by_title(issues: list[dict[str, Any]]) -> list[dict[str, Any]]:  # type: ignore[type-arg]
    """Return only the lowest-numbered issue per case-insensitive stripped title.

    Args:
        issues: List of issue dicts already sorted by number (ascending).

    Returns:
        Deduplicated list preserving the lowest-numbered entry per title.
    """
    seen: set[str] = set()
    unique: list[dict[str, Any]] = []  # type: ignore[type-arg]
    for issue in issues:
        key = issue.get("title", "").strip().lower()
        if key not in seen:
            seen.add(key)
            unique.append(issue)
    return unique


def _build_issue_states(raw_issues: list[dict[str, Any]]) -> list[_state.IssueState]:  # type: ignore[type-arg]
    """Convert raw gh issue dicts into IssueState objects.

    Deduplicates by title (case-insensitive, stripped) as a defense-in-depth
    measure: if the planning session created duplicate issues, only the
    lowest-numbered entry per title is kept.

    Args:
        raw_issues: List of dicts as returned by ``gh.list_issues()``.

    Returns:
        List of :class:`~code_generator.state.IssueState` instances.
    """
    sorted_issues = sorted(raw_issues, key=lambda i: i["number"])
    unique_issues = _deduplicate_by_title(sorted_issues)
    return [
        _state.IssueState(
            number=issue["number"],
            title=issue.get("title", ""),
            status="open",
            agent=gh.agent_from_labels(issue.get("labels", [])),
            labels=[lbl.get("name", "") for lbl in issue.get("labels", []) if lbl.get("name")],
        )
        for issue in unique_issues
    ]


def _fetch_existing_issues(
    repo: _state.RepoInfo | None,
    milestone_title: str | None,
) -> list[dict[str, Any]]:  # type: ignore[type-arg]
    """Fetch all issues in the given milestone, or return empty list for single-mode.

    Args:
        repo: Repository info; when ``None`` returns empty list.
        milestone_title: Milestone name, or ``None`` for single-cycle mode.

    Returns:
        List of raw issue dicts (may be empty).
    """
    if repo is None or milestone_title is None:
        return []
    return gh.list_issues(repo, milestone=milestone_title, state="all")


def _format_existing_issues(issues: list[dict[str, Any]]) -> str:  # type: ignore[type-arg]
    """Format a list of raw issue dicts as a readable string for prompt injection.

    Args:
        issues: Raw issue dicts as returned by ``gh.list_issues()``.

    Returns:
        A newline-separated list of ``#N: title`` entries, or ``"none"`` when empty.
    """
    if not issues:
        return "none"
    return "\n".join(f"- #{i['number']}: {i['title']}" for i in issues)


_PHASE1_DEFAULT_MODEL = "claude-opus-4-7"
# CLAUDE.md invariant #8; overridden via ``effective_model`` on Ollama — #219.


def _load_specialized_prompt(
    project_dir: Path,
    state: State,
    cycle: CycleState | None,
) -> str:
    """Return the cycle-specialized briefing, or a raw-requirements fallback.

    The preferred path reads
    ``.code-generator/cycles_prompts/<requirements_hash>/cycle_<id>.md`` —
    materialised by :mod:`code_generator.orchestrator.cycle_prompts` at the
    end of Phase 0 for multi-cycle runs.

    The fallback wraps ``.code-generator/requirements.md`` in a ``## Requirements``
    section so the downstream prompt never collapses into an empty volatile
    context block. The fallback fires in three cases:

    - Single-cycle mode (no ``cycle`` object is in scope).
    - Multi-cycle mode where ``requirements_hash`` is unset (should not happen
      in production but is handled defensively).
    - The specialized file is missing — e.g. the specializer call raised
      :class:`~code_generator.orchestrator.cycle_prompts.CyclePromptGenerationError`
      and Phase 0 swallowed the error.
    """
    requirements_path = project_dir / ".code-generator" / "requirements.md"

    if state.mode == "multi-cycle" and cycle is not None and state.requirements_hash is not None:
        try:
            return _cycle_prompts.load_cycle_prompt(project_dir, state.requirements_hash, cycle.id)
        except FileNotFoundError:
            pass

    try:
        requirements_content = requirements_path.read_text(encoding="utf-8")
    except FileNotFoundError:
        # In production the file always exists (optimize/init guarantee it); this
        # branch keeps unit tests green when they do not stage the file on disk.
        return f"- **Requirements path:** {requirements_path}"
    return f"## Requirements\n\n{requirements_content}"


async def run(
    state: State,
    cycle: CycleState | None,
    project_dir: Path,
    *,
    runner_module: RunnerProtocol,
    logger: logging.Logger | None = None,
    max_turns: int | None = None,
    effective_model: str | None = None,
) -> None:
    """Execute phase 1: planning.

    Seeds standard labels, optionally creates a milestone (multi-cycle),
    runs the planning prompt, then populates ``state.issues`` or
    ``cycle.issues`` from the newly-created GitHub issues.

    Args:
        state: Root state object (mutated in place).
        cycle: Active cycle (multi-cycle mode) or ``None`` (single mode).
        project_dir: Project root directory.
        runner_module: Runner module from ``get_runner()``.
        logger: Optional phase logger.
    """
    if logger is None:
        logger = setup_phase_logger("phase1", project_dir)

    state_path = project_dir / ".code-generator" / "state.json"

    # repo is populated by preflight before any phase runs; Phase 1 is
    # unreachable without a valid state.repo in production.
    repo = state.repo

    # Seed standard label taxonomy — idempotent.
    gh.ensure_standard_labels(repo)

    # Multi-cycle: create the milestone if not yet done.
    # Track whether the milestone was created in this run so we can clean it up on failure.
    milestone_title: str | None = None
    milestone_number_before: int | None = None
    if cycle is not None:
        milestone_title = cycle.milestone_title
        milestone_number_before = cycle.milestone_number
        if cycle.milestone_number is None:
            cycle.milestone_number = gh.create_milestone(
                repo,
                cycle.milestone_title,
                cycle.scope,
            )
            logger.info("Created milestone %r → #%d", cycle.milestone_title, cycle.milestone_number)

    try:
        # Determine completed cycle names for the prompt.
        completed_cycles: str = "none"
        if state.cycles:
            completed = [c.name for c in state.cycles if c.status == "completed"]
            if completed:
                completed_cycles = ", ".join(completed)

        # Pre-fetch existing issues so the model can skip them on --continue.
        existing_issues = _fetch_existing_issues(repo, milestone_title)

        memories_dir = project_dir / ".code-generator" / "memories"
        repo_map = _memory.read_cycle_repomap(memories_dir)
        prompt = load_prompt(
            "prompt-phase-1-planning.md",
            CYCLE_SPECIALIZED_PROMPT=_load_specialized_prompt(project_dir, state, cycle),
            CYCLE_SCOPE=(
                cycle.scope
                if cycle is not None
                else "single-cycle — implement all features from requirements.md"
            ),
            MILESTONE_TITLE=milestone_title if milestone_title is not None else "",
            COMPLETED_CYCLES=completed_cycles,
            EXISTING_ISSUES=_format_existing_issues(existing_issues),
            REPO_MAP=repo_map,
        )

        effort_level = _effort.resolve_effort(
            phase=1,
            complexity="",
            issue_labels=[],
            retry_count=0,
        )
        _effort.validate_effort(effort_level, "claude-opus-4-7")

        options = make_agent_options(
            model=effective_model or _PHASE1_DEFAULT_MODEL,
            effort=effort_level,
            allowed_tools=["Read", "Bash", "Glob", "Grep"],
            cwd=str(project_dir),
            **max_turns_kwargs(max_turns),
        )

        result = await rate_limit.main_loop(
            runner_module,
            prompt,
            options,
            state_path=state_path,
            logger=logger,
        )

        # Fetch all issues in the milestone (open + closed) to support deduplication.
        raw_issues = gh.list_issues(
            repo,
            milestone=milestone_title,
            state="all",
        )
        issue_states = _build_issue_states(raw_issues)

        if not issue_states:
            raise Phase1NoIssuesError(
                "Phase 1 finished without creating any GitHub issues. "
                "Opus likely misread the task (e.g. audited existing code instead "
                "of planning new work). Inspect .code-generator/logs/phase1.log, "
                "adjust prompt-phase-1-planning.md if needed, and re-run."
            )

        target = cycle if cycle is not None else state
        if cycle is not None:
            cycle.issues = issue_states
        else:
            state.issues = issue_states
        target.token_usage["phase1"] = result.usage
        if hasattr(target, "cache_telemetry"):
            accumulate_telemetry(target.cache_telemetry, result.usage, result.wall_seconds)

        _state.save_state(state_path, state)
        log_phase_usage(logger, 1, result.usage)
        logger.info("Phase 1: %d issues created.", len(issue_states))

    except Exception:
        _cleanup_orphaned_milestone(repo, cycle, milestone_number_before, logger)
        raise


def _cleanup_orphaned_milestone(
    repo: RepoInfo | None,
    cycle: CycleState | None,
    milestone_number_before: int | None,
    logger: logging.Logger,
) -> None:
    """Delete a milestone created in this run if Phase 1 fails before persisting issues.

    Only deletes if the milestone was created during this run (i.e., it was None before
    and is now set). Best-effort: logs a WARNING if deletion itself fails.

    Args:
        repo: Repository info; when ``None`` deletion is skipped.
        cycle: Active cycle, or None in single-cycle mode.
        milestone_number_before: The milestone number before this run started (None = just created).
        logger: Phase logger for WARNING output.
    """
    if (
        repo is None
        or cycle is None
        or cycle.milestone_number is None
        or milestone_number_before is not None
    ):
        return
    try:
        gh.delete_milestone(repo, cycle.milestone_number)
    except Exception as cleanup_exc:
        logger.warning(
            "Failed to delete orphaned milestone #%d during Phase 1 cleanup: %s",
            cycle.milestone_number,
            cleanup_exc,
        )
