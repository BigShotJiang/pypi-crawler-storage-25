"""
mysql_connector — A production-grade async MySQL connector with
LoopBack-style nested relation queries and typed model instances.

Quick start:
    from mysql_connector import MySQLConnector, MySQLModel, Field, Relation

    class User(MySQLModel):
        __table__ = "users"
        id:     int           = Field(primary_key=True)
        name:   str           = Field(max_length=100)
        email:  str           = Field(unique=True)
        orders: list["Order"] = Relation(type="hasMany", foreign_key="user_id")

    class Order(MySQLModel):
        __table__ = "orders"
        id:      int    = Field(primary_key=True)
        user_id: int    = Field(foreign_key="users.id")
        total:   float
        user:    "User" = Relation(type="belongsTo", foreign_key="user_id")

    connector = MySQLConnector(host="localhost", database="mydb",
                               user="root", password="secret")
    await connector.connect()

    users = await connector.find(User, {
        "where": {"active": True},
        "include": ["orders"],
        "limit": 10,
    })
"""

__version__ = "1.0.4"

from .connector import MySQLConnector
from .model     import MySQLModel
from .fields    import Field, Relation, JSONField
from .migrator  import Migrator
from .types     import FilterOptions, IncludeScope, RelationType
from .registry  import registry

from .exceptions import (
    ConnectorError,
    RelationNotLoadedError,
    ModelNotRegisteredError,
    RelationNotDefinedError,
    SchemaError,
    QueryError,
    ConnectionPoolError,
    ConfigurationError,
    TransactionError,
)

__all__ = [
    "__version__",
    # Core
    "MySQLConnector",
    "MySQLModel",
    "Field",
    "Relation",
    "JSONField",
    "Migrator",
    # Types / DSL
    "FilterOptions",
    "IncludeScope",
    "RelationType",
    # Registry
    "registry",
    # Exceptions
    "ConnectorError",
    "RelationNotLoadedError",
    "ModelNotRegisteredError",
    "RelationNotDefinedError",
    "SchemaError",
    "QueryError",
    "ConnectionPoolError",
    "ConfigurationError",
    "TransactionError",
]
