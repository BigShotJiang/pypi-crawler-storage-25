"""slop — Agentic code quality linter."""

__version__ = "0.2.0"
