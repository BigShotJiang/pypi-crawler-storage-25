"""Tool modules. Each registers tools on the shared FastMCP instance."""
