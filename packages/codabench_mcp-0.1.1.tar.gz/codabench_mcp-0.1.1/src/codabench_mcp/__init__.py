"""MCP server for the Codabench REST API."""

__version__ = "0.1.0"
