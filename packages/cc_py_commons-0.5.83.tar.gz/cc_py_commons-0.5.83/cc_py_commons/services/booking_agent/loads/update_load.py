import requests

from cc_py_commons.services.booking_agent.constants import BOOKING_AGENT_URL, BOOKING_AGENT_TOKEN
from cc_py_commons.utils import json_logger


def execute(load_dict, account_id=None):
    load_id = load_dict.get('id')
    if not load_id:
        json_logger.error(account_id, 'Invalid load_id in load_dict; cannot update', load_id=load_id)
        return None

    load_id = str(load_id)
    url = f"{BOOKING_AGENT_URL}/freight/{load_id}"
    token = f"Bearer {BOOKING_AGENT_TOKEN}"
    headers = {
        "Authorization": token
    }
    try:
        json_logger.debug(account_id, 'Updating load on booking-agent', url=url, load_id=load_id)
        response = requests.post(url, json=load_dict, headers=headers, timeout=30)
        if response.status_code not in (200, 201, 204):
            json_logger.warning(account_id, 'booking-agent update returned non-success status',
                                response_status_code=response.status_code,
                                response_text=response.text,
                                load_id=load_id,
                                load_dict=load_dict)
        else:
            json_logger.info(account_id, 'Successfully updated load on booking-agent',
                             load_id=load_id, response_status_code=response.status_code)
        return response
    except Exception as e:
        json_logger.error(account_id, 'Error calling booking-agent API for update',
                          error=str(e), load_id=load_id)
        return None
