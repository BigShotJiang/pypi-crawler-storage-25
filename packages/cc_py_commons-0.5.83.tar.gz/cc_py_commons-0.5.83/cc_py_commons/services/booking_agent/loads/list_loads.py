import traceback
import uuid

import requests

from cc_py_commons.loads.map_load_response import execute as map_load_response
from cc_py_commons.services.booking_agent.constants import BOOKING_AGENT_URL, BOOKING_AGENT_TOKEN
from cc_py_commons.utils import json_logger


def _stringify_uuids(value):
    if isinstance(value, uuid.UUID):
        return str(value)
    if isinstance(value, dict):
        return {k: _stringify_uuids(v) for k, v in value.items()}
    if isinstance(value, list):
        return [_stringify_uuids(v) for v in value]
    return value


def execute(parameters, account_id=None):
    """
    Returns a list of Load objects (possibly empty).
    Loads are retrieved from booking-agent using the specified attributes.
    View booking-agent LoadListController and LoadPredicates for valid filters.
    """
    parameters = _stringify_uuids(parameters)
    url = f"{BOOKING_AGENT_URL}/freight"
    token = f"Bearer {BOOKING_AGENT_TOKEN}"
    headers = {
        "Authorization": token
    }
    json_logger.debug(account_id, 'Requesting load list from booking-agent', url=url, parameters=parameters)
    response = requests.get(url, params=parameters, headers=headers)
    loads = []

    if response.status_code == 200:
        json_data = response.json()

        if not json_data.get('content'):
            return []

        for load_data in json_data['content']:
            try:
                load = map_load_response(load_data)
                loads.append(load)
            except Exception as e:
                load_id = load_data.get('id') if isinstance(load_data, dict) else None
                parameter_keys = sorted(parameters.keys()) if isinstance(parameters, dict) else None
                json_logger.warning(account_id, 'Unable to map booking-agent response to load',
                                    parameter_keys=parameter_keys, load_id=load_id,
                                    error=str(e), stack_trace=traceback.format_exc())

    return loads
