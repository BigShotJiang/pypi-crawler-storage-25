import requests

from cc_py_commons.services.booking_agent.constants import BOOKING_AGENT_URL, BOOKING_AGENT_TOKEN
from cc_py_commons.utils import json_logger


def execute(load_id, account_id=None):
    load_id = str(load_id) if load_id is not None else load_id
    url = f"{BOOKING_AGENT_URL}/freight/{load_id}/cancel"
    token = f"Bearer {BOOKING_AGENT_TOKEN}"
    headers = {
        "Authorization": token
    }
    json_logger.debug(account_id, 'Canceling load on booking-agent', url=url, load_id=load_id)
    return requests.get(url, headers=headers)
