"""
Unit tests for :class:`EquipmentNormalizer`.

Mocks all HTTP calls -- no network access. Mirrors the Java
EquipmentNormalizerTests in ``cargochief-commons-equipment-services``
so both languages exercise the same boundary cases (plan task #20).
"""

import json
import unittest
from unittest import mock

import requests

from cc_py_commons.equipment.normalizer import EquipmentNormalizer
from cc_py_commons.equipment.result import NormalizationResult


class _FakeResponse:
	"""
	Minimal stand-in for ``requests.Response`` so tests don't depend on a
	real HTTP layer. Set ``status_code``, ``ok``, and the JSON body.
	"""

	def __init__(self, status_code=200, body=None):
		self.status_code = status_code
		self.ok = 200 <= status_code < 400
		self._body = body if body is not None else {}

	def json(self):
		return self._body


def _single_match_payload(query, name):
	"""
	Replicate the current Mercury equipment lambda shape:
	``{"data": {"<query>": {"equipment_class_id": "...", "name": "...", "active": true}}, "status": "Ok"}``
	"""

	return {
		'data': {
			query: {
				'equipment_class_id': 'eqid-1',
				'name': name,
				'active': True,
			},
		},
		'status': 'Ok',
	}


def _multi_match_payload(query, names):
	"""
	Replicate the planned ``multiple_matches=true`` shape (plan task #19):
	``{"data": {"<query>": [{"name": ...}, {"name": ...}]}}``
	"""

	return {
		'data': {
			query: [
				{'equipment_class_id': f'eqid-{i}', 'name': name, 'active': True}
				for i, name in enumerate(names)
			],
		},
		'status': 'Ok',
	}


class EquipmentNormalizerTests(unittest.TestCase):

	def setUp(self):
		self.session = mock.Mock()
		self.normalizer = EquipmentNormalizer(
			lambda_url='http://fake-lambda/equipments',
			http_session=self.session,
		)

	# --- happy path ---------------------------------------------------------

	def test_known_alias_resolves_to_canonical_name(self):
		self.session.get.return_value = _FakeResponse(body=_single_match_payload('step_deck', 'Step_Deck'))

		result = self.normalizer.normalize('Step Deck')

		self.assertIsInstance(result, NormalizationResult)
		self.assertEqual(result.canonical_names, ['step_deck'])
		self.assertFalse(result.multiple_matches)
		self.assertFalse(result.cache_hit)
		self.assertFalse(result.fallback_used)
		self.assertIsNone(result.warning)
		# Confirm we sent the standardized key, not the raw input.
		self.session.get.assert_called_once()
		_, kwargs = self.session.get.call_args
		self.assertEqual(kwargs['params'], {'query': 'step_deck'})
		self.assertEqual(kwargs['timeout'], 5)

	# --- caching ------------------------------------------------------------

	def test_cache_hit_skips_http_layer_on_second_call(self):
		self.session.get.return_value = _FakeResponse(body=_single_match_payload('flatbed', 'Flatbed'))

		first = self.normalizer.normalize('FLATBED')
		second = self.normalizer.normalize('flatbed')

		self.assertEqual(self.session.get.call_count, 1)
		self.assertFalse(first.cache_hit)
		self.assertTrue(second.cache_hit)
		self.assertEqual(second.canonical_names, ['flatbed'])
		# Raw input is preserved per call.
		self.assertEqual(first.raw_input, 'FLATBED')
		self.assertEqual(second.raw_input, 'flatbed')

	# --- timeout / fallback -------------------------------------------------

	def test_lambda_timeout_falls_back_to_snapshot(self):
		self.session.get.side_effect = requests.exceptions.Timeout('boom')

		result = self.normalizer.normalize('step_deck')

		self.assertTrue(result.fallback_used)
		self.assertEqual(result.canonical_names, ['step_deck'])
		self.assertFalse(result.cache_hit)
		# 1 retry => 2 attempts total.
		self.assertEqual(self.session.get.call_count, 2)
		self.assertIn('fallback snapshot', result.warning or '')

	def test_lambda_failure_alias_missing_from_snapshot_returns_empty(self):
		self.session.get.side_effect = requests.exceptions.ConnectionError('down')

		result = self.normalizer.normalize('completely_unknown_alias_xyz')

		self.assertTrue(result.fallback_used)
		self.assertEqual(result.canonical_names, [])
		self.assertFalse(result.multiple_matches)
		self.assertEqual(result.warning, 'lambda unreachable, alias not in fallback snapshot')

	def test_documented_aliases_resolve_via_fallback_snapshot(self):
		"""
		Regression for CodeRabbit feedback on PR #290: the module docstring
		promises support for aliases like ``"STEPDECK"``. ``_standardize`` turns
		that into ``stepdeck``, so the snapshot must contain a ``stepdeck`` key
		mapping to ``step_deck`` (and similar non-canonical aliases) for the
		outage path to honor the documented contract.
		"""

		self.session.get.side_effect = requests.exceptions.Timeout('lambda down')

		# Each tuple is (raw_input, expected_canonical) -- the raw_input is what
		# a caller would actually pass; the snapshot must resolve it via the
		# normalizer's _standardize step plus the snapshot key lookup.
		documented_aliases = [
			('STEPDECK', 'step_deck'),
			('Step Deck', 'step_deck'),
			('flatbed', 'flatbed'),
			('Reefer', 'reefer'),
		]

		for raw_input, expected in documented_aliases:
			with self.subTest(raw_input=raw_input):
				# Clear the in-process cache between sub-tests so each lookup
				# re-exercises the lambda → fallback path rather than serving
				# the previous fallback result from cache.
				self.normalizer._cache.clear()
				result = self.normalizer.normalize(raw_input)
				self.assertTrue(
					result.fallback_used,
					f"{raw_input!r} should be served from fallback when lambda is down",
				)
				self.assertIn(
					expected,
					result.canonical_names,
					f"{raw_input!r} should resolve to canonical {expected!r} via the snapshot",
				)

	def test_fallback_snapshot_has_no_malformed_canonical_names(self):
		"""
		Regression for CodeRabbit feedback on PR #290: the snapshot must not
		contain entries where the canonical value is not a real equipment
		class name (e.g. '\".' from a psql echo line that snuck into the
		export). Catches export noise at test time so future regenerations
		fail loudly instead of shipping garbage.
		"""

		import json
		import string
		from pathlib import Path

		snapshot_path = Path(__file__).resolve().parent.parent / 'equipment_mapping_snapshot.json'

		with open(snapshot_path, encoding='utf-8') as f:
			snapshot = json.load(f)

		# Equipment class names contain only letters, digits, spaces, and
		# underscores. Anything else (quotes, dots, etc.) is junk.
		allowed = set(string.ascii_letters + string.digits + ' _')

		for key, value in snapshot.items():
			if key.startswith('_'):
				continue

			self.assertIsInstance(
				value,
				list,
				f"snapshot value for {key!r} must be a list of canonical names",
			)

			for canonical in value:
				bad_chars = {c for c in canonical if c not in allowed}
				self.assertFalse(
					bad_chars,
					f"snapshot key {key!r} maps to non-canonical value "
					f"{canonical!r} containing illegal chars {bad_chars}",
				)
				self.assertTrue(
					any(c.isalpha() for c in canonical),
					f"snapshot key {key!r} maps to canonical {canonical!r} "
					f"that has no letters (likely export noise)",
				)

	# --- input hygiene ------------------------------------------------------

	def test_empty_input_returns_empty_result_without_calling_lambda(self):
		result = self.normalizer.normalize('')

		self.assertEqual(result.canonical_names, [])
		self.assertFalse(result.cache_hit)
		self.assertFalse(result.fallback_used)
		self.session.get.assert_not_called()

	def test_none_input_returns_empty_result_without_raising(self):
		result = self.normalizer.normalize(None)

		self.assertEqual(result.canonical_names, [])
		self.assertEqual(result.raw_input, '')
		self.session.get.assert_not_called()

	def test_whitespace_only_input_returns_empty_result(self):
		result = self.normalizer.normalize('   ')

		self.assertEqual(result.canonical_names, [])
		self.session.get.assert_not_called()

	# --- case + whitespace + alias equivalence -----------------------------

	def test_case_and_whitespace_variants_share_cache(self):
		self.session.get.return_value = _FakeResponse(body=_single_match_payload('step_deck', 'Step_Deck'))

		first = self.normalizer.normalize('  Step Deck  ')
		second = self.normalizer.normalize('STEP_DECK')

		# Both standardize to "step_deck"; second call must hit cache.
		self.assertEqual(self.session.get.call_count, 1)
		self.assertEqual(first.canonical_names, ['step_deck'])
		self.assertEqual(second.canonical_names, ['step_deck'])
		self.assertTrue(second.cache_hit)

	def test_length_prefix_stripped_before_lookup(self):
		self.session.get.return_value = _FakeResponse(body=_single_match_payload('step_deck', 'Step_Deck'))

		# `53 ft step deck` and `48' STEP DECK` both standardize to `step_deck`
		# (length prefix stripped, lowercased, space->underscore). Second call
		# must hit the cache.
		first = self.normalizer.normalize('53 ft step deck')
		_, kwargs = self.session.get.call_args
		self.assertEqual(kwargs['params'], {'query': 'step_deck'})
		self.assertEqual(first.canonical_names, ['step_deck'])

		result = self.normalizer.normalize("48' STEP DECK")
		self.assertTrue(result.cache_hit)
		self.assertEqual(self.session.get.call_count, 1)

	def test_length_suffix_stripped_before_lookup(self):
		# `flatbed 48` standardizes to `flatbed` after the length-suffix strip.
		self.session.get.return_value = _FakeResponse(body=_single_match_payload('flatbed', 'Flatbed'))

		result = self.normalizer.normalize('flatbed 48')

		_, kwargs = self.session.get.call_args
		self.assertEqual(kwargs['params'], {'query': 'flatbed'})
		self.assertEqual(result.canonical_names, ['flatbed'])

	# --- multi-match awareness ---------------------------------------------

	def test_multi_match_payload_surfaces_multiple_matches_flag(self):
		self.session.get.return_value = _FakeResponse(
			body=_multi_match_payload('decks', ['Step_Deck', 'Double_Drop'])
		)

		result = self.normalizer.normalize('decks')

		self.assertEqual(result.canonical_names, ['step_deck', 'double_drop'])
		self.assertTrue(result.multiple_matches)
		self.assertFalse(result.fallback_used)

	# --- batch API ----------------------------------------------------------

	def test_normalize_all_returns_dict_keyed_by_raw_input(self):
		def fake_get(url, params=None, timeout=None):
			query = params['query']
			canonical = {'flatbed': 'Flatbed', 'reefer': 'Reefer'}.get(query, query)
			return _FakeResponse(body=_single_match_payload(query, canonical))

		self.session.get.side_effect = fake_get

		results = self.normalizer.normalize_all(['FLATBED', 'Reefer'])

		self.assertEqual(set(results.keys()), {'FLATBED', 'Reefer'})
		self.assertEqual(results['FLATBED'].canonical_names, ['flatbed'])
		self.assertEqual(results['Reefer'].canonical_names, ['reefer'])

	def test_normalize_all_handles_none_iterable(self):
		self.assertEqual(self.normalizer.normalize_all(None), {})

	# --- defensive: lambda 404 is a definitive miss, not a fallback trigger -

	def test_lambda_404_does_not_use_fallback_snapshot(self):
		self.session.get.return_value = _FakeResponse(status_code=404, body={'message': 'not found'})

		result = self.normalizer.normalize('mystery_alias')

		self.assertEqual(result.canonical_names, [])
		self.assertFalse(result.fallback_used)
		self.assertIsNotNone(result.warning)


if __name__ == '__main__':
	unittest.main()
