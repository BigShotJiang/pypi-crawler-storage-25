"""
Equipment normalization module.

Provides a single, shared client for resolving raw equipment-text strings
(e.g. ``STEPDECK``, ``Step Deck``, ``53 ft step deck``) into canonical
Mercury ``equipment_class.name`` values. This is the Python counterpart
to the Java ``EquipmentNormalizer`` in ``cargochief-commons-equipment-services``;
both produce byte-identical canonical strings so a service in either
language can compare results consistently.

Public surface:

* :class:`EquipmentNormalizer` -- thread-safe normalizer with caching
  and a static fallback snapshot.
* :class:`NormalizationResult` -- immutable result object with
  diagnostic flags (``cache_hit``, ``fallback_used``, etc).

See ``docs/plans/PLAN_stepdeck_capacity_search_fix.md`` (Phase 3, task #20).
"""

from cc_py_commons.equipment.normalizer import EquipmentNormalizer
from cc_py_commons.equipment.result import NormalizationResult

__all__ = ['EquipmentNormalizer', 'NormalizationResult']
