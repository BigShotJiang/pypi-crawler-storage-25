"""
Immutable result object returned by :class:`EquipmentNormalizer`.

The shape mirrors the Java ``NormalizationResult`` in
``cargochief-commons-equipment-services`` so callers in either language
can read the same diagnostic flags.
"""

from dataclasses import dataclass, field
from typing import List, Optional


@dataclass(frozen=True)
class NormalizationResult:
	"""
	Result of normalizing a single raw equipment string.

	Attributes:
	  raw_input: The exact string supplied by the caller (no trim/case fixes).
	  canonical_names: Zero, one, or multiple canonical Mercury class names.
	    Empty list means the alias could not be resolved.
	  multiple_matches: True when the lambda (or fallback) returned more than
	    one canonical match for the same alias. Callers that expect a single
	    canonical class should treat this as ambiguous.
	  cache_hit: True when the result was served from the in-process cache.
	  fallback_used: True when the lambda call failed and the static
	    snapshot was consulted instead.
	  warning: Optional human-readable note for log/observability use
	    (e.g. ``"lambda unreachable, alias not in fallback snapshot"``).
	"""

	raw_input: str
	canonical_names: List[str] = field(default_factory=list)
	multiple_matches: bool = False
	cache_hit: bool = False
	fallback_used: bool = False
	warning: Optional[str] = None
