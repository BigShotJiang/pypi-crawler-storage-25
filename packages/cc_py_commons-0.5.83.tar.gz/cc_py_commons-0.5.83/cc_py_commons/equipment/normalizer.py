"""
Shared equipment normalizer.

Resolves a raw equipment-text string (e.g. ``Step Deck``, ``STEPDECK``,
``53 ft step deck``) into the canonical Mercury ``equipment_class.name``
value (``step_deck``). Wraps the Mercury equipment-mapping lambda with:

* an in-process TTL cache (default 60s, max 1000 entries);
* a static JSON fallback snapshot for lambda outages;
* multi-match awareness so callers can detect ambiguous aliases.

The standardization rules and contract mirror the Java
``EquipmentNormalizer`` in ``cargochief-commons-equipment-services`` so
services in either language produce byte-identical canonical strings.
See ``docs/plans/PLAN_stepdeck_capacity_search_fix.md`` Phase 3.
"""

import json
import logging
import os
import re
import threading
from pathlib import Path
from typing import Dict, Iterable, List, Optional

import requests


logger = logging.getLogger(__name__)

_DEFAULT_LAMBDA_URL_ENV = 'EQUIPMENT_MAPPING_LAMBDA_URL'
_DEFAULT_TIMEOUT_SECONDS = 5
_DEFAULT_RETRIES = 1
_DEFAULT_CACHE_TTL_SECONDS = 60
_DEFAULT_CACHE_MAXSIZE = 1000
_FALLBACK_SNAPSHOT_FILENAME = 'equipment_mapping_snapshot.json'

# Standardization regexes (applied in the order documented in the plan, §3a).
_LENGTH_PREFIX_PATTERN = re.compile(r"^\d+\s*(ft|')\s+", re.IGNORECASE)
_LENGTH_SUFFIX_PATTERN = re.compile(r"\s+\d+(ft)?$", re.IGNORECASE)
_ORNAMENTATION_PATTERNS = [
	re.compile(r"\s+with\s+tarps?$", re.IGNORECASE),
	re.compile(r"\s+w/\s*tarps?$", re.IGNORECASE),
	re.compile(r"\s+air\s+ride$", re.IGNORECASE),
]
_INTERNAL_WHITESPACE_PATTERN = re.compile(r"\s+")


class _TTLCache:
	"""
	Tiny TTL cache used when ``cachetools`` is unavailable.

	Thread-safe per-key TTL with a hard maxsize. We prefer cachetools.TTLCache
	when installed; this fallback keeps the module importable in lightweight
	environments (e.g. Lambdas with slimmed-down requirements). Behavior matches
	cachetools closely enough for the normalizer's needs.
	"""

	def __init__(self, maxsize, ttl):
		self._maxsize = maxsize
		self._ttl = ttl
		self._data = {}
		self._lock = threading.Lock()

	def _now(self):
		# Indirected for test patching.
		import time
		return time.monotonic()

	def get(self, key):
		with self._lock:
			entry = self._data.get(key)
			if entry is None:
				return None
			value, expires_at = entry
			if expires_at <= self._now():
				self._data.pop(key, None)
				return None
			return value

	def set(self, key, value):
		with self._lock:
			if len(self._data) >= self._maxsize and key not in self._data:
				# Evict an arbitrary oldest-ish entry to bound memory.
				oldest_key = min(self._data, key=lambda k: self._data[k][1])
				self._data.pop(oldest_key, None)
			self._data[key] = (value, self._now() + self._ttl)

	def __contains__(self, key):
		return self.get(key) is not None

	def clear(self):
		with self._lock:
			self._data.clear()


def _build_cache(maxsize, ttl):
	"""
	Prefer cachetools.TTLCache when installed; fall back to the local TTL cache.
	The plan calls for cachetools but py-commons has historically run in
	stripped-down lambda envs, so we degrade gracefully.
	"""

	try:
		from cachetools import TTLCache as _CachetoolsTTLCache
	except ImportError:
		return _TTLCache(maxsize=maxsize, ttl=ttl)

	class _CachetoolsAdapter:

		def __init__(self):
			self._cache = _CachetoolsTTLCache(maxsize=maxsize, ttl=ttl)
			self._lock = threading.Lock()

		def get(self, key):
			with self._lock:
				return self._cache.get(key)

		def set(self, key, value):
			with self._lock:
				self._cache[key] = value

		def __contains__(self, key):
			with self._lock:
				return key in self._cache

		def clear(self):
			with self._lock:
				self._cache.clear()

	return _CachetoolsAdapter()


from cc_py_commons.equipment.result import NormalizationResult


class EquipmentNormalizer:
	"""
	Thread-safe client that normalizes raw equipment strings to canonical
	Mercury class names.

	Args:
	  lambda_url: Override for the equipment-mapping lambda URL. Defaults to
	    the value of the ``EQUIPMENT_MAPPING_LAMBDA_URL`` environment variable.
	  timeout_seconds: HTTP timeout for each lambda call (default 5s).
	  retries: Number of retry attempts on lambda failure (default 1).
	  cache_ttl_seconds: Cache entry TTL (default 60s).
	  cache_maxsize: Cache capacity (default 1000).
	  http_session: Optional ``requests.Session`` for connection reuse / tests.
	  fallback_snapshot_path: Override path to the static fallback JSON.

	Public methods:
	  * :meth:`normalize` -- normalize a single raw string.
	  * :meth:`normalize_all` -- batch normalize, returns a dict keyed by raw input.
	"""

	def __init__(
		self,
		lambda_url=None,
		timeout_seconds=_DEFAULT_TIMEOUT_SECONDS,
		retries=_DEFAULT_RETRIES,
		cache_ttl_seconds=_DEFAULT_CACHE_TTL_SECONDS,
		cache_maxsize=_DEFAULT_CACHE_MAXSIZE,
		http_session=None,
		fallback_snapshot_path=None,
	):
		self._lambda_url = lambda_url if lambda_url is not None else os.environ.get(_DEFAULT_LAMBDA_URL_ENV)
		self._timeout_seconds = timeout_seconds
		self._retries = max(0, int(retries))
		self._http_session = http_session
		self._cache = _build_cache(maxsize=cache_maxsize, ttl=cache_ttl_seconds)
		self._fallback_snapshot_path = fallback_snapshot_path or str(
			Path(__file__).resolve().parent / _FALLBACK_SNAPSHOT_FILENAME
		)
		self._fallback_snapshot = None
		self._fallback_lock = threading.Lock()

	# --- public API ----------------------------------------------------------

	def normalize(self, raw_input):
		"""
		Normalize a single raw equipment string.

		Returns a :class:`NormalizationResult`. Empty/None input returns a
		result with empty canonical names; the call never raises for caller-
		supplied input.
		"""

		if raw_input is None or not isinstance(raw_input, str) or not raw_input.strip():
			return NormalizationResult(
				raw_input=raw_input if isinstance(raw_input, str) else '',
				canonical_names=[],
				multiple_matches=False,
				cache_hit=False,
				fallback_used=False,
				warning='empty or null input',
			)

		standardized = self._standardize(raw_input)
		cache_key = standardized

		cached = self._cache.get(cache_key)
		if cached is not None:
			logger.debug('Equipment normalizer cache hit for %r (standardized=%r)', raw_input, standardized)
			return NormalizationResult(
				raw_input=raw_input,
				canonical_names=list(cached.canonical_names),
				multiple_matches=cached.multiple_matches,
				cache_hit=True,
				fallback_used=cached.fallback_used,
				warning=cached.warning,
			)

		logger.info(
			'Equipment normalizer cache miss; calling lambda for raw_input=%r standardized=%r',
			raw_input,
			standardized,
		)

		result = self._lookup_via_lambda(raw_input, standardized)
		if result is None:
			logger.warning(
				'Equipment-mapping lambda failed for raw_input=%r standardized=%r; consulting fallback snapshot',
				raw_input,
				standardized,
			)
			result = self._lookup_via_fallback(raw_input, standardized)

		self._cache.set(cache_key, result)
		return result

	def normalize_all(self, raw_inputs):
		"""
		Normalize a batch of raw equipment strings.

		Returns a dict keyed by the original raw input. Inputs that appear
		multiple times collapse into a single key (last write wins, but the
		result is the same since normalize() is deterministic per input).
		"""

		if raw_inputs is None:
			return {}

		results = {}
		for raw in raw_inputs:
			results[raw] = self.normalize(raw)
		return results

	# --- internals -----------------------------------------------------------

	@staticmethod
	def _standardize(raw_input):
		"""
		Apply the standardization pipeline from PLAN §3a steps 1-8.

		Step 9 (lambda lookup) and step 10 (return canonical lowercased) live
		in the calling code so callers can distinguish a lookup miss (return
		the post-step-8 string) from a successful lookup.
		"""

		value = raw_input.strip().lower()
		value = _INTERNAL_WHITESPACE_PATTERN.sub(' ', value)
		value = _LENGTH_PREFIX_PATTERN.sub('', value)
		value = _LENGTH_SUFFIX_PATTERN.sub('', value)
		for pattern in _ORNAMENTATION_PATTERNS:
			value = pattern.sub('', value)
		value = value.strip()
		value = value.replace(' ', '_')
		return value

	def _lookup_via_lambda(self, raw_input, standardized):
		"""
		Call the Mercury equipment-mapping lambda. Returns a ``NormalizationResult``
		on success, or ``None`` if the lambda is unreachable / returned an error
		so the caller can fall through to the snapshot.
		"""

		if not self._lambda_url:
			return None

		session = self._http_session if self._http_session is not None else requests
		params = {'query': standardized}
		attempts = self._retries + 1
		last_error = None
		for attempt in range(attempts):
			try:
				response = session.get(self._lambda_url, params=params, timeout=self._timeout_seconds)
			except requests.RequestException as exc:
				last_error = exc
				continue

			if response.status_code == 404:
				# Lambda explicitly says "no mapping" -- treat as a definitive
				# negative answer (do not fall through to snapshot, which is
				# only for outages).
				return NormalizationResult(
					raw_input=raw_input,
					canonical_names=[],
					multiple_matches=False,
					cache_hit=False,
					fallback_used=False,
					warning=f'no mapping found for {standardized!r}',
				)

			if response.status_code >= 500:
				last_error = RuntimeError(f'lambda returned HTTP {response.status_code}')
				continue

			if not response.ok:
				return NormalizationResult(
					raw_input=raw_input,
					canonical_names=[],
					multiple_matches=False,
					cache_hit=False,
					fallback_used=False,
					warning=f'lambda returned HTTP {response.status_code} for {standardized!r}',
				)

			try:
				payload = response.json()
			except ValueError as exc:
				last_error = exc
				continue

			canonical_names, multiple_matches = self._parse_lambda_payload(payload, standardized)
			return NormalizationResult(
				raw_input=raw_input,
				canonical_names=canonical_names,
				multiple_matches=multiple_matches,
				cache_hit=False,
				fallback_used=False,
				warning=None if canonical_names else f'no mapping found for {standardized!r}',
			)

		logger.warning(
			'Equipment-mapping lambda call failed after %d attempts for standardized=%r: %s',
			attempts,
			standardized,
			last_error,
		)
		return None

	@staticmethod
	def _parse_lambda_payload(payload, standardized):
		"""
		Tolerate both the current single-match shape and the planned multi-match
		shape. Returns ``(canonical_names, multiple_matches)``.

		Current shape (Mercury ``equipment/services/get_equipment.py``):
		  ``{"data": {"<query>": {"equipment_class_id": ..., "name": ..., "active": ...}}, "status": "Ok"}``

		Planned multi-match shape (plan task #19):
		  ``{"data": {"<query>": [{"name": ...}, {"name": ...}]}, "status": "Ok"}``

		We also accept a payload without the ``data`` envelope (just ``{<query>: ...}``)
		so callers that point at a mock or alternate gateway still parse cleanly.
		"""

		if not isinstance(payload, dict):
			return [], False

		body = payload.get('data') if 'data' in payload else payload
		if not isinstance(body, dict):
			return [], False

		# Pick the entry matching the standardized key when present; else take
		# the first value in the dict (lambda echoes the query as the key).
		entry = body.get(standardized)
		if entry is None and body:
			entry = next(iter(body.values()))

		if entry is None:
			return [], False

		if isinstance(entry, list):
			names = []
			for item in entry:
				name = _extract_name(item)
				if name and name not in names:
					names.append(name)
			return names, len(names) > 1

		name = _extract_name(entry)
		return ([name] if name else []), False

	def _lookup_via_fallback(self, raw_input, standardized):
		"""
		Look up the standardized key in the static JSON snapshot. Returns a
		``NormalizationResult`` with ``fallback_used=True`` either way.
		"""

		snapshot = self._load_fallback_snapshot()
		entry = snapshot.get(standardized)
		if entry is None:
			return NormalizationResult(
				raw_input=raw_input,
				canonical_names=[],
				multiple_matches=False,
				cache_hit=False,
				fallback_used=True,
				warning='lambda unreachable, alias not in fallback snapshot',
			)

		canonical_names = list(entry) if isinstance(entry, list) else [entry]
		return NormalizationResult(
			raw_input=raw_input,
			canonical_names=canonical_names,
			multiple_matches=len(canonical_names) > 1,
			cache_hit=False,
			fallback_used=True,
			warning='lambda unreachable, served from fallback snapshot',
		)

	def _load_fallback_snapshot(self):
		"""
		Load the JSON snapshot lazily, then cache it on the instance. Snapshot
		entries beginning with ``_`` are metadata and excluded from the lookup.
		"""

		if self._fallback_snapshot is not None:
			return self._fallback_snapshot

		with self._fallback_lock:
			if self._fallback_snapshot is not None:
				return self._fallback_snapshot
			try:
				with open(self._fallback_snapshot_path, 'r') as fh:
					raw = json.load(fh)
			except (OSError, ValueError) as exc:
				logger.warning('Failed to load equipment fallback snapshot at %s: %s', self._fallback_snapshot_path, exc)
				self._fallback_snapshot = {}
				return self._fallback_snapshot

			# Metadata keys (prefixed `_`) are stripped so they cannot be
			# accidentally matched as aliases.
			self._fallback_snapshot = {k: v for k, v in raw.items() if not k.startswith('_')}
			return self._fallback_snapshot


def _extract_name(item):
	"""
	Pull a canonical name from a lambda response item. Tolerates both the
	dict-with-``name`` shape and a bare string.
	"""

	if isinstance(item, dict):
		name = item.get('name')
		if isinstance(name, str) and name:
			# Mercury serializes the response as ``.title()`` for display
			# (``Step_Deck``); normalize back to lowercase for storage.
			return name.lower()
		return None
	if isinstance(item, str) and item:
		return item.lower()
	return None
