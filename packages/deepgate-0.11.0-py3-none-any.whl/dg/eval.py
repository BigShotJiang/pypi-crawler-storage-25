from typing import Any, Callable

import torch


def _accuracy_metric(output: torch.Tensor, target: torch.Tensor) -> int:
    """Per-batch count of top-1 correct predictions."""
    _, predictions = torch.max(output, 1)
    return (predictions == target).sum().cpu().item()


def get_acc(
    model: torch.nn.Module,
    dataset: torch.utils.data.Dataset,
    batch_size: int = 128,
    device: str = "cuda",
) -> torch.Tensor:
    """Compute top-1 classification accuracy of ``model`` on ``dataset``.

    Puts the model in ``eval`` mode for the pass and restores ``train`` mode
    before returning so the caller's training loop is unaffected.

    Args:
        model: Classifier returning logits of shape ``[batch, num_classes]``.
        dataset: Iterable yielding ``(data, target)`` pairs.
        batch_size: DataLoader batch size.
        device: Device to run evaluation on.

    Returns:
        Scalar ``torch.Tensor`` with the accuracy in ``[0, 1]``.
    """
    model.eval()
    scores = compute_metric(
        model, dataset, _accuracy_metric, batch_size=batch_size, device=device
    )
    model.train()
    return torch.sum(torch.Tensor(scores)) / len(dataset)


def compute_metric(
    model: torch.nn.Module,
    dataset: torch.utils.data.Dataset,
    metric: Callable[[torch.Tensor, torch.Tensor], float],
    batch_size: int = 128,
    device: str = "cuda",
    **kwargs: Any,
) -> list:
    """Evaluate ``metric(output, target)`` over ``dataset`` under ``torch.no_grad``.

    Args:
        model: Model to evaluate. Moved to ``device`` in-place.
        dataset: Iterable yielding ``(data, target)`` pairs.
        metric: Callable ``(output, target) -> value`` invoked once per batch.
        batch_size: DataLoader batch size.
        device: Device to run evaluation on.
        **kwargs: Extra keyword arguments forwarded to ``model(data, ...)``.

    Returns:
        List of per-batch metric values in dataset order.
    """
    metric_list = []
    data_loader = torch.utils.data.DataLoader(dataset, batch_size)
    model.to(device)

    with torch.no_grad():
        for data, target in data_loader:
            data = data.to(device)
            target = target.to(device)
            output = model(data, **kwargs) if kwargs else model(data)
            metric_list.append(metric(output, target))

    return metric_list
