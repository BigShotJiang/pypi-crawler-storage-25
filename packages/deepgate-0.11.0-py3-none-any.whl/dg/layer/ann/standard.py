import torch
import torch.nn as nn
import torch.nn.functional as F
import math
from typing import Any

from dg.dtype import DType
from dg.layer.base import BaseModule
from dg.layer.spec_utils import tensor_spec, scalar_spec


class Linear(BaseModule):
    """Fully-connected linear layer with an optional ReLU activation.

    Operates in FP32 on 2-D ``[B, N]`` tensors.

    Args:
        in_features: Number of input features.
        out_features: Number of output features.
        bias: Whether to include an additive bias term.
        device: Torch device for the wrapped linear layer.
        act_func: Either ``"relu"`` or ``None``.
    """

    def __init__(
        self,
        in_features: int,
        out_features: int,
        bias: bool,
        device: str = "cpu",
        act_func: str | None = None,
    ) -> None:
        super().__init__(dtype_in=DType.FLOAT32, dtype_out=DType.FLOAT32)
        assert act_func in [None, "relu"]
        self.linear = nn.Linear(in_features=in_features, out_features=out_features, bias=bias, device=device, dtype=torch.float32)
        self.act_func = act_func

    def get_module_specs(self) -> dict[str, Any]:
        return {
            "weights": tensor_spec(self.linear.weight.detach()),
            "bias": tensor_spec(self.linear.bias.detach()) if self.linear.bias is not None else None,
            "act_func": self.act_func,
        }

    def _forward(self, x: torch.Tensor) -> torch.Tensor:
        # x: [B, N]
        assert x.shape[-1] == self.linear.in_features, f"{x.shape[-1]} {self.linear.in_features}"
        assert x.dim() == 2, "Only support 2-dim"
        x = self.linear(x)

        if self.act_func == "relu":
            x = torch.relu(x)

        return x


def _init_triu_weight(weight: torch.Tensor, in_features: int) -> None:
    nn.init.kaiming_uniform_(weight, a=math.sqrt(5))
    with torch.no_grad():
        weight[:in_features].triu_()


def _init_tril_weight(weight: torch.Tensor, in_features: int, diagonal: int) -> None:
    nn.init.kaiming_uniform_(weight, a=math.sqrt(5))
    with torch.no_grad():
        out_features = weight.shape[0]
        start = max(0, out_features - in_features)
        weight[start:].tril_(diagonal)


def _make_triu_mask(out_features: int, in_features: int, device: str) -> torch.Tensor:
    mask = torch.ones(out_features, in_features, device=device)
    top = min(out_features, in_features)
    mask[:top] = torch.triu(mask[:top])
    return mask


def _make_tril_mask(out_features: int, in_features: int, device: str) -> torch.Tensor:
    mask = torch.ones(out_features, in_features, device=device)
    bottom = min(out_features, in_features)
    start = out_features - bottom
    diagonal = in_features - bottom
    mask[start:] = torch.tril(mask[start:], diagonal)
    return mask


class UpperTriangularLinear(BaseModule):
    """Linear layer with an upper-triangular weight, optionally extended with dense rows.

    Designed to support in-place inference with a buffer of size
    ``max(in_features, out_features)``:

    * When ``out <= in`` the weight is pure upper triangular.
    * When ``out > in`` the first ``in`` rows are upper triangular and the
      remaining ``out - in`` rows are fully dense.

    Args:
        in_features: Number of input features.
        out_features: Number of output features.
        bias: Whether to include an additive bias term.
        device: Torch device for the parameters.
        act_func: Either ``"relu"`` or ``None``.
    """

    def __init__(self, in_features: int, out_features: int, bias: bool = True, device: str = "cpu", act_func: str | None = None) -> None:
        super().__init__(dtype_in=DType.FLOAT32, dtype_out=DType.FLOAT32)
        assert act_func in [None, "relu"]
        self.in_features = in_features
        self.out_features = out_features
        self.weight = nn.Parameter(torch.empty(out_features, in_features, device=device))
        _init_triu_weight(self.weight, in_features)
        self.register_buffer("mask", _make_triu_mask(out_features, in_features, device))
        self.bias = nn.Parameter(torch.zeros(out_features, device=device)) if bias else None
        self.act_func = act_func

    def get_module_specs(self) -> dict[str, Any]:
        return {
            "weights": tensor_spec((self.weight * self.mask).detach()),
            "bias": tensor_spec(self.bias.detach()) if self.bias is not None else None,
            "act_func": self.act_func,
        }

    def _forward(self, x: torch.Tensor) -> torch.Tensor:
        # x: [B, N]
        assert x.shape[-1] == self.in_features, f"{x.shape[-1]} != {self.in_features}"
        assert x.dim() == 2, "Only support 2-dim"
        x = F.linear(x, self.weight * self.mask, self.bias)
        if self.act_func == "relu":
            x = torch.relu(x)
        return x


class LowerTriangularLinear(BaseModule):
    """Linear layer with a lower-triangular weight, optionally extended with dense rows.

    Designed to support in-place inference with a buffer of size
    ``max(in_features, out_features)``:

    * When ``out <= in`` the weight is lower triangular with the triangular
      block flush against the right edge.
    * When ``out > in`` the last ``in`` rows are lower triangular (a square
      block) and the first ``out - in`` rows are fully dense.

    Args:
        in_features: Number of input features.
        out_features: Number of output features.
        bias: Whether to include an additive bias term.
        device: Torch device for the parameters.
        act_func: Either ``"relu"`` or ``None``.
    """

    def __init__(self, in_features: int, out_features: int, bias: bool = True, device: str = "cpu", act_func: str | None = None) -> None:
        super().__init__(dtype_in=DType.FLOAT32, dtype_out=DType.FLOAT32)
        assert act_func in [None, "relu"]
        self.in_features = in_features
        self.out_features = out_features
        self.weight = nn.Parameter(torch.empty(out_features, in_features, device=device))
        bottom = min(out_features, in_features)
        diagonal = in_features - bottom
        _init_tril_weight(self.weight, in_features, diagonal)
        self.register_buffer("mask", _make_tril_mask(out_features, in_features, device))
        self.bias = nn.Parameter(torch.zeros(out_features, device=device)) if bias else None
        self.act_func = act_func

    def get_module_specs(self) -> dict[str, Any]:
        return {
            "weights": tensor_spec((self.weight * self.mask).detach()),
            "bias": tensor_spec(self.bias.detach()) if self.bias is not None else None,
            "act_func": self.act_func,
        }

    def _forward(self, x: torch.Tensor) -> torch.Tensor:
        # x: [B, N]
        assert x.shape[-1] == self.in_features, f"{x.shape[-1]} != {self.in_features}"
        assert x.dim() == 2, "Only support 2-dim"
        x = F.linear(x, self.weight * self.mask, self.bias)
        if self.act_func == "relu":
            x = torch.relu(x)
        return x


class Norm(BaseModule):
    """Element-wise ``(x - mean) / std`` normalization. Output is FP32.

    Args:
        mean: Mean subtracted from the input.
        std: Standard deviation used to scale the input.
        dtype_in: Declared input dtype.
    """

    def __init__(self, mean: float, std: float, dtype_in: str = DType.UINT8) -> None:
        super().__init__(dtype_in=dtype_in, dtype_out=DType.FLOAT32)
        self.mean = mean
        self.std = std
        self.inv_std = 1 / std

    def get_module_specs(self) -> dict[str, Any]:
        return {
            "mean": scalar_spec(self.mean, "float32"),
            "inv_std": scalar_spec(self.inv_std, "float32"),
        }

    def _forward(self, x: torch.Tensor) -> torch.Tensor:
        x = (x.float() - self.mean) * self.inv_std

        return x

    def _permute_input_to_compiler_layout(self, x: torch.Tensor) -> torch.Tensor:
        if len(x.shape) == 3:
            return x.permute(1, 2, 0)
        return x

    def _permute_output_to_compiler_layout(self, x: torch.Tensor) -> torch.Tensor:
        if len(x.shape) == 3:
            return x.permute(1, 2, 0)
        return x
