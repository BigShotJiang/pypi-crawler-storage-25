from .observers import MinMaxObserver
from .fake_quant import (
    FakeQuantizeAsymmetric,
    FakeQuantizeSymmetric,
    fake_quantize_asymmetric,
    fake_quantize_symmetric,
    dequantize,
    quantize,
)
from .utils import compute_requant_multiplier_shift
from .linear import QuantLinear
from .triangular import QuantUpperTriangularLinear, QuantLowerTriangularLinear
from .conv2d import QuantConv2d
from .depthwise_conv2d import QuantDepthwiseConv2d
from .avgpool2d import QuantAvgPool2d
from .residual import QuantResidualAdd
from .softmax import QuantSoftmax
