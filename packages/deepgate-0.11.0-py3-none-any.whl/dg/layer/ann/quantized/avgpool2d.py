from typing import Any, Callable

import torch
import torch.nn.functional as F

from dg.layer.spec_utils import scalar_spec

from .base import QuantBase
from .fake_quant import fake_quantize_asymmetric
from .observers import MinMaxObserver, ViewObserver


class QuantAvgPool2d(QuantBase):
    """Int8-quantized 2-D average pooling.

    Average pooling preserves the value range (outputs always lie within the
    min / max of inputs), so the input and output share a single scale and
    zero-point. The output observer is therefore a :class:`ViewObserver`
    over the input observer.

    Args:
        kernel_size: Pooling window size.
        stride: Pool stride. Defaults to ``kernel_size``.
        padding: Zero-padding. ``int`` or 2-tuple ``(pad_h, pad_w)`` or
            4-tuple ``(L, R, T, B)``.
    """

    def __init__(
        self,
        kernel_size: int | tuple[int, int],
        stride: int | tuple[int, int] | None = None,
        padding: int | tuple[int, int] | tuple[int, int, int, int] = 0,
        input_quant_op: Callable[..., torch.Tensor] = fake_quantize_asymmetric,
        output_quant_op: Callable[..., torch.Tensor] = fake_quantize_asymmetric,
    ) -> None:
        super().__init__(input_quant_op=input_quant_op, output_quant_op=output_quant_op, ema_constant=0.01)

        self.output_observer = ViewObserver(self.input_observer)

        self.kernel_size = self._normalize_pair(kernel_size)
        self.stride = self.kernel_size if stride is None else self._normalize_pair(stride)
        self.padding = self._normalize_padding(padding)

    def stitch_input(self, observer: MinMaxObserver) -> None:
        self.input_observer = observer
        self.output_observer = ViewObserver(observer)

    @property
    def pool_area(self) -> int:
        """Number of elements in the pooling window (``kH * kW``)."""
        return self.kernel_size[0] * self.kernel_size[1]

    def _quant_forward(self, x: torch.Tensor) -> torch.Tensor:
        if any(p > 0 for p in self.padding):
            x = F.pad(x, self.padding, mode='constant', value=0)

        x = F.avg_pool2d(x, self.kernel_size, self.stride, padding=0)

        return x

    def _compute_pool_div_params(self, shift: int = 16) -> tuple[int, int]:
        """Fixed-point parameters for division by :attr:`pool_area`.

        The returned pair satisfies ``sum / N ≈ (sum * multiplier) >> shift``.
        """
        n = self.pool_area
        multiplier = round((1 << shift) / n)
        return multiplier, shift

    def get_module_specs(self) -> dict[str, Any]:
        multiplier, shift = self._compute_pool_div_params()

        specs = {
            "scale": scalar_spec(self.input_scale.item(), "float32"),
            "zero_point": scalar_spec(int(self.input_zp.item()), "int32"),
            "input_no_quant": self.input_no_quant,
            "output_no_dequant": self.output_no_dequant,

            "kernel_size": list(self.kernel_size),
            "stride": list(self.stride),
            "padding": list(self.padding),

            "pool_div_multiplier": scalar_spec(multiplier, "int32"),
            "pool_div_shift": scalar_spec(shift, "int32"),
        }

        return specs
