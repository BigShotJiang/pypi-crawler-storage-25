from typing import Any, Callable

import torch
from dg.layer.base import BaseModule
from dg.dtype import DType
from .observers import MinMaxObserver
from .fake_quant import fake_quantize_asymmetric, dequantize, quantize
from .utils import compute_requant_multiplier_shift

_QUANT_OP_DTYPE = {
    dequantize: DType.INT8,
    fake_quantize_asymmetric: DType.FLOAT32,
    quantize: DType.INT8,
}


class QuantBase(BaseModule):
    """Base class for layers that simulate int8 quantization during training.

    Provides input and output :class:`MinMaxObserver` instances that learn
    quantization scale / zero-point, and applies fake quantization around the
    subclass-specific computation in :meth:`_quant_forward`.
    """

    def __init__(
        self,
        input_quant_op: Callable[..., torch.Tensor] = fake_quantize_asymmetric,
        output_quant_op: Callable[..., torch.Tensor] = fake_quantize_asymmetric,
        fix_output_zero: bool = False,
        ema_constant: float = 0.01,
        weight_per_tensor: bool = False,
    ) -> None:
        dtype_in = _QUANT_OP_DTYPE[input_quant_op]
        dtype_out = _QUANT_OP_DTYPE[output_quant_op]
        super().__init__(dtype_in=dtype_in, dtype_out=dtype_out)

        self.input_observer = MinMaxObserver(ema_constant, fix_zero=False)
        self.input_quant_op = input_quant_op

        self.output_observer = MinMaxObserver(ema_constant, fix_zero=fix_output_zero)
        self.output_quant_op = output_quant_op

        self.weight_per_tensor = weight_per_tensor

    @property
    def input_no_quant(self) -> bool:
        """``True`` if the input is already int8 (compiler skips quantization)."""
        return self.input_quant_op is dequantize

    @property
    def output_no_dequant(self) -> bool:
        """``True`` if the output stays int8 (compiler skips dequantization)."""
        return self.output_quant_op is quantize

    @property
    def input_scale(self) -> torch.Tensor:
        return self.input_observer.scale

    @property
    def input_zp(self) -> torch.Tensor:
        return self.input_observer.zero_point

    def _forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.input_observer(x)
        x = self.input_quant_op(x, self.input_observer.scale, self.input_observer.zero_point)

        x = self._quant_forward(x)

        x = self.output_observer(x)
        x = self.output_quant_op(x, self.output_observer.scale, self.output_observer.zero_point)

        return x

    def _quant_forward(self, x: torch.Tensor) -> torch.Tensor:
        """Subclass-specific quantized computation. Subclasses must override."""
        raise NotImplementedError("Subclasses must implement _quant_forward")

    def stitch_input(self, observer: MinMaxObserver) -> None:
        """Replace :attr:`input_observer` during model stitching."""
        self.input_observer = observer

    @staticmethod
    def _normalize_pair(value: int | tuple[int, int] | list[int]) -> tuple[int, int]:
        return (value, value) if isinstance(value, int) else tuple(value)

    @staticmethod
    def _normalize_padding(padding: int | tuple[int, int] | tuple[int, int, int, int] | list[int]) -> tuple[int, int, int, int]:
        if isinstance(padding, int):
            return (padding, padding, padding, padding)
        if len(padding) == 2:
            pad_h, pad_w = padding
            return (pad_w, pad_w, pad_h, pad_h)
        if len(padding) == 4:
            return tuple(padding)
        raise ValueError(f"padding must be int, 2-tuple, or 4-tuple, got {padding}")

    def _compute_weight_scales(self, weight: torch.Tensor) -> torch.Tensor:
        if self.weight_per_tensor:
            max_abs = weight.detach().abs().max().expand(weight.shape[0])
        else:
            max_abs = weight.detach().abs().flatten(1).max(dim=1).values
        return torch.clamp(max_abs, min=1e-8) / 127.0

    @staticmethod
    def _quantize_weights_int8(weight: torch.Tensor, weight_scales: torch.Tensor) -> torch.Tensor:
        scales = weight_scales
        for _ in range(weight.dim() - 1):
            scales = scales.unsqueeze(-1)
        return torch.clamp(torch.round(weight / scales), -127, 127).to(torch.int8)

    @staticmethod
    def _quantize_bias_int32(bias: torch.Tensor | None, input_scale: float, weight_scales: torch.Tensor) -> torch.Tensor | None:
        if bias is None:
            return None
        return torch.round(bias / (input_scale * weight_scales)).to(torch.int32)

    @staticmethod
    def _compute_requant_params(num_channels: int, input_scale: float, weight_scales: torch.Tensor, output_scale: float) -> tuple[torch.Tensor, torch.Tensor]:
        multipliers, shifts = [], []
        for c in range(num_channels):
            M = (input_scale * weight_scales[c].item()) / output_scale
            m0, s = compute_requant_multiplier_shift(M)
            multipliers.append(m0)
            shifts.append(s)
        return torch.tensor(multipliers, dtype=torch.int32), torch.tensor(shifts, dtype=torch.int32)

    def _permute_input_to_compiler_layout(self, x: torch.Tensor) -> torch.Tensor:
        return x.permute(1, 2, 0) if len(x.shape) == 3 else x

    def _permute_output_to_compiler_layout(self, x: torch.Tensor) -> torch.Tensor:
        return x.permute(1, 2, 0) if len(x.shape) == 3 else x
