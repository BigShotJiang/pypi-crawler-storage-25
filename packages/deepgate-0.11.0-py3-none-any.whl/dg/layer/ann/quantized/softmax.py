from typing import Any, Callable

import torch
import torch.nn.functional as F

from dg.layer.spec_utils import scalar_spec

from .base import QuantBase
from .fake_quant import fake_quantize_asymmetric
from .observers import StaticObserver


_SOFTMAX_OUTPUT_SCALE = 1.0 / 256.0
_SOFTMAX_OUTPUT_ZP = -128.0


class QuantSoftmax(QuantBase):
    """Int8-quantized softmax over a single axis.

    The output is normalised to ``[0, 1]`` by definition, so output
    quantization parameters are pinned to ``scale = 1/256`` and
    ``zero_point = -128`` (matching the int8 SOFTMAX convention used by
    TFLite Micro). The output observer is a :class:`StaticObserver` and
    therefore does not track input statistics.

    Inputs are fake-quantized using the standard asymmetric int8 path so
    QAT gradients flow through via the straight-through estimator.

    Args:
        dim: Axis to apply softmax over.
        ema_constant: EMA smoothing factor for the input observer.
    """

    def __init__(
        self,
        dim: int = -1,
        ema_constant: float = 0.01,
        input_quant_op: Callable[..., torch.Tensor] = fake_quantize_asymmetric,
        output_quant_op: Callable[..., torch.Tensor] = fake_quantize_asymmetric,
    ) -> None:
        super().__init__(
            input_quant_op=input_quant_op,
            output_quant_op=output_quant_op,
            ema_constant=ema_constant,
        )

        self.output_observer = StaticObserver(
            scale=_SOFTMAX_OUTPUT_SCALE,
            zero_point=_SOFTMAX_OUTPUT_ZP,
        )

        self.dim = dim

    def _quant_forward(self, x: torch.Tensor) -> torch.Tensor:
        return F.softmax(x, dim=self.dim)

    def get_module_specs(self) -> dict[str, Any]:
        return {
            "dim": int(self.dim),
            "input_scale": scalar_spec(self.input_scale.item(), "float32"),
            "input_zp": scalar_spec(int(self.input_zp.item()), "int32"),
            "input_no_quant": self.input_no_quant,
            "output_scale": scalar_spec(self.output_observer.scale.item(), "float32"),
            "output_zp": scalar_spec(int(self.output_observer.zero_point.item()), "int32"),
            "output_no_dequant": self.output_no_dequant,
        }
