from typing import Any

import torch
import torch.nn as nn


from dg.dtype import DType, str_to_torch


class BaseModule(nn.Module):
    """Abstract base for layers that export compiler schemas and testcases.

    Subclasses implement :meth:`_forward` (the tensor computation) and
    :meth:`get_module_specs` (layer-specific schema fields). Spatial layers
    additionally override :meth:`_permute_input_to_compiler_layout` and
    :meth:`_permute_output_to_compiler_layout` to convert PyTorch's ``CHW``
    tensors to the compiler's ``HWC`` layout for schema and testcase export.
    """

    def __init__(self, dtype_in: str | None = None, dtype_out: str | None = None) -> None:
        super().__init__()
        self.shape_in = None
        self.shape_out = None
        self.dtype_in = dtype_in
        self.dtype_out = dtype_out

    @property
    def has_dynamic_dtype(self) -> bool:
        """``True`` when the layer declares neither input nor output dtype."""
        return self.dtype_in is None and self.dtype_out is None

    def get_compiler_specs(self) -> dict[str, Any]:
        """Return the full compiler specification for this layer."""
        assert isinstance(self.get_module_specs(), dict)
        return {
            "module_name": self.__class__.__name__,
            "shape_in": self.shape_in,
            "shape_out": self.shape_out,
            "dtype_in": self.dtype_in,
            "dtype_out": self.dtype_out,
            "module_specs": self.get_module_specs()
        }

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        if self.shape_in is None:
            permuted_in = self._permute_input_to_compiler_layout(x[0])
            self.shape_in = self._jsonify_io_shape(list(permuted_in.shape))
        x = self._forward(x)
        if self.shape_out is None:
            permuted_out = self._permute_output_to_compiler_layout(x[0])
            self.shape_out = self._jsonify_io_shape(list(permuted_out.shape))

        return x

    def get_module_specs(self) -> dict[str, Any]:
        """Return layer-specific compiler spec fields. Subclasses must override."""
        raise NotImplementedError

    def _forward(self, x: torch.Tensor) -> torch.Tensor:
        """Layer-specific forward computation. Subclasses must override."""
        raise NotImplementedError

    def _permute_input_to_compiler_layout(self, x: torch.Tensor) -> torch.Tensor:
        """Permute an input sample from PyTorch layout to compiler layout.

        Spatial layers override this to convert ``CHW → HWC``. Used only for
        schema and testcase generation; normal forward passes keep data in
        PyTorch layout.
        """
        return x

    def _permute_output_to_compiler_layout(self, x: torch.Tensor) -> torch.Tensor:
        """Permute an output sample from PyTorch layout to compiler layout."""
        return x

    def _jsonify_io_shape(self, shape: list[int]) -> list[int]:
        shape = torch.Tensor(shape)
        shape = shape.int().tolist()
        return shape

    # -------------------------------------------------------------------------
    # Testcase Generation Protocol
    # -------------------------------------------------------------------------

    def build_testcase_outputs(self, x: torch.Tensor) -> tuple[torch.Tensor, list[dict]]:
        """Run the layer and produce testcase entries for compiler verification.

        Default behaviour returns a single entry for this layer's output.
        Compound layers (e.g. :class:`QuantResidualAdd`) override to emit
        entries for each sub-layer.
        """
        output = self(x)
        return output, [self._build_testcase_entry(output)]

    def _build_testcase_entry(self, x: torch.Tensor, layer_name: str | None = None) -> dict[str, Any]:
        x_sample = x[0].cpu()  # Remove batch dim
        x_permuted = self._permute_output_to_compiler_layout(x_sample)
        dtype = self.dtype_out
        return {
            "layer": layer_name or self.__class__.__name__,
            "dtype": dtype if dtype != DType.BIT else DType.BP32,
            "output": self._format_tensor_for_testcase(x_permuted, dtype),
            "shape": list(x_permuted.shape),
        }

    def _format_tensor_for_testcase(self, x: torch.Tensor, dtype: str) -> list[Any]:
        x = x.flatten()
        if dtype == DType.BIT:
            return self._bitpack(x).tolist()
        return x.to(str_to_torch(dtype)).tolist()

    def _bitpack(self, x: torch.Tensor) -> torch.Tensor:
        """Pack a 1-D binary tensor into uint32 words, 32 bits per word."""
        assert x.numel() % 32 == 0, f"Tensor size {x.numel()} not divisible by 32"
        x = x.view(-1, 32).to(torch.int64)
        powers = 2 ** torch.arange(32, dtype=torch.int64, device=x.device)
        return (x * powers).sum(dim=1)
