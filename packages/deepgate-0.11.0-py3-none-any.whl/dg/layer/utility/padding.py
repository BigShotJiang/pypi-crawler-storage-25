from typing import Any

import torch
import torch.nn.functional as F

from dg.layer.base import BaseModule


class Pad(BaseModule):
    """Right-pad the last dimension of a tensor with zeros.

    Args:
        pad_length: Number of zeros appended to the last dimension.
    """

    def __init__(self, pad_length: int) -> None:
        super().__init__()
        self.pad_length = pad_length

    def get_module_specs(self) -> dict[str, Any]:
        return {
            "pad_length": self.pad_length,
        }

    def _forward(self, x: torch.Tensor) -> torch.Tensor:
        # Only pad the last dimension (0 left, pad_right right)
        return F.pad(x, (0, self.pad_length), value=0)
