from typing import Any

import torch
import torch.nn.functional as F

from dg.layer.base import BaseModule


class MaxPool2d(BaseModule):
    """2-D max pooling layer.

    Args:
        kernel: Pooling window size.
        stride: Pool stride.
    """

    def __init__(self, kernel: int | tuple[int, int], stride: int | tuple[int, int]) -> None:
        super().__init__()
        self.kernel = (kernel, kernel) if isinstance(kernel, int) else tuple(kernel)
        self.stride = (stride, stride) if isinstance(stride, int) else tuple(stride)

    def get_module_specs(self) -> dict[str, Any]:
        return {
            "kernel": self.kernel,
            "stride": self.stride,
        }

    def _forward(self, x: torch.Tensor) -> torch.Tensor:
        return F.max_pool2d(x, kernel_size=self.kernel, stride=self.stride)

    def _permute_input_to_compiler_layout(self, x: torch.Tensor) -> torch.Tensor:
        if len(x.shape) == 3:
            return x.permute(1, 2, 0)
        return x

    def _permute_output_to_compiler_layout(self, x: torch.Tensor) -> torch.Tensor:
        if len(x.shape) == 3:
            return x.permute(1, 2, 0)
        return x
