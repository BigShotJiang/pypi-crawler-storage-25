from typing import Any

import torch

from dg.layer.base import BaseModule


class Expand(BaseModule):
    """Concatenate ``repeat`` full copies of the input along the last dimension.

    Args:
        repeat: Number of copies to tile along the last axis.
    """

    def __init__(self, repeat: int) -> None:
        super().__init__()
        self.repeat = repeat

    def get_module_specs(self) -> dict[str, Any]:
        return {
            "repeat": self.repeat,
        }

    def _forward(self, x: torch.Tensor) -> torch.Tensor:
        # x: [..., D]
        # repeat along last dim by concatenating full copies
        return x.repeat(*([1] * (x.dim() - 1)), self.repeat)
