from typing import Any

import torch

from dg.layer.base import BaseModule


class BlockShuffle(BaseModule):
    """Deterministic block permutation of a flat tensor.

    Splits the last dimension into contiguous blocks of size ``block_size``
    and permutes the blocks using a fixed seeded permutation.

    Args:
        block_size: Size of each block along the last dimension.
        seed: Seed used to generate the permutation.
    """

    def __init__(self, block_size: int, seed: int = 42) -> None:
        super().__init__()
        self.block_size = block_size
        self.seed = seed
        self.register_buffer("rand_idx", None, persistent=False)  # will hold indices

    def get_module_specs(self) -> dict[str, Any]:
        return {
            "block_size": self.block_size,
            "seed": self.seed,
        }

    def _forward(self, x: torch.Tensor) -> torch.Tensor:
        assert x.ndim == 2, f"BlockShuffle expects 2D input [B, N], got {x.ndim}D"
        B, N = x.shape
        assert N % self.block_size == 0, "N must be divisible by block_size"
        nb_blocks = N // self.block_size

        # Initialize rand_idx
        if self.rand_idx is None:
            torch.manual_seed(self.seed)
            self.rand_idx = torch.randperm(nb_blocks, device="cpu")

        # Reshape -> Shuffle -> Flatten back
        x = x.view(B, nb_blocks, self.block_size)
        x = x[:, self.rand_idx, :]
        return x.reshape(B, N)
