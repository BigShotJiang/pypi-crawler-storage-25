import sys
import time
import types
import logging
from typing import Any

import torch
import torch.nn as nn
import torch.nn.functional as F

from dg import eval as dg_eval


logger = logging.getLogger(__name__)
logging.basicConfig(stream=sys.stdout, level=logging.INFO)


def freeze_backbone(model: torch.nn.Module) -> torch.nn.Module:
    """Freeze all layers except the last (head) for finetuning.

    Sets requires_grad=False on backbone parameters and keeps backbone
    layers in eval mode (preventing observer updates). Overrides model.train()
    so the backbone stays frozen even when the Trainer calls model.train().
    """
    head_index = len(model.model_graph) - 1
    frozen = set(range(head_index))

    for i in frozen:
        for p in model.model_graph[i].parameters():
            p.requires_grad = False
        model.model_graph[i].eval()

    def _train(self: torch.nn.Module, mode: bool = True) -> torch.nn.Module:
        nn.Module.train(self, mode)
        if mode:
            for i in frozen:
                self.model_graph[i].eval()
        return self

    model.train = types.MethodType(_train, model)
    return model


class Trainer:
    """Orchestrates training over epochs.

    Classification (default): dataset yields ``(x, y)`` pairs, loss is
    cross-entropy, validation metric is accuracy.

    Custom loss / metrics: models can override the following hooks to supply
    their own behaviour (e.g. detection models yielding multi-target batches):

    * ``model.compute_loss(outputs, *targets)`` — loss function
    * ``model.build_validation_metric(device)`` — initial validation state
    * ``model.validation_update(state, outputs, *targets)`` — per-batch update
    * ``model.validation_compute(state)`` — finalise metrics dict

    When hooks are defined, Trainer unpacks each batch as
    ``inputs, *targets = batch`` and passes ``*targets`` through. Classification
    datasets yielding ``(x, y)`` still work unchanged (targets = ``(y,)``).

    Schedules: pass ``lr_schedule="cosine"`` for warmup+cosine, or any
    ``torch.optim.lr_scheduler`` class. ``warmup_epochs`` adds a linear warmup
    in front of a class-based schedule or modifies the cosine setup.
    """

    def __init__(
        self,
        model: torch.nn.Module,
        train_dataset: torch.utils.data.Dataset,
        val_dataset: torch.utils.data.Dataset | None = None,
        val_epoch: int = 5,
        epochs: int = 100,
        batch_size: int = 128,
        lr: float = 0.001,
        optimizer: type[torch.optim.Optimizer] = torch.optim.Adam,
        optimizer_kwargs: dict[str, Any] = {},
        lr_schedule: str | type[torch.optim.lr_scheduler.LRScheduler] | None = None,
        lr_schedule_kwargs: dict[str, Any] | None = None,
        warmup_epochs: int = 0,
        grad_clip: float | None = None,
        num_workers: int = 0,
        device: str = "cuda",
    ) -> None:
        self.model = model.to(device)
        self.model.train()
        self.device = device
        self.epochs = epochs
        self.batch_size = batch_size
        self.val_dataset = val_dataset
        self.val_epoch = val_epoch
        self.grad_clip = grad_clip

        # multiprocessing_context="fork" avoids Python 3.14's forkserver default
        # which re-imports the main module in workers and breaks editable installs.
        mp_ctx = "fork" if num_workers > 0 else None
        self.train_loader = torch.utils.data.DataLoader(
            train_dataset, batch_size, shuffle=True,
            num_workers=num_workers, pin_memory=(device != "cpu"), drop_last=True,
            multiprocessing_context=mp_ctx,
        )
        self.optimizer = optimizer(
            [p for p in model.parameters() if p.requires_grad], lr, **optimizer_kwargs
        )
        self.scheduler = _build_schedule(
            self.optimizer, lr_schedule, lr_schedule_kwargs, warmup_epochs, epochs, lr,
        )

    def train(self) -> None:
        for epoch in range(self.epochs):
            start = time.time()
            epoch_loss = self._train_epoch()
            duration = time.time() - start

            if self.scheduler is not None:
                self.scheduler.step()

            logger.info(
                f"Epoch {epoch} - loss: {epoch_loss:.2f} ({duration:.2f}s)"
            )

            if self.val_dataset and epoch % self.val_epoch == 0:
                if hasattr(self.model, "build_validation_metric"):
                    metrics = _run_custom_validation(
                        self.model, self.val_dataset, self.batch_size, self.device,
                    )
                    pretty = "  ".join(f"{k}={v:.3f}" for k, v in metrics.items())
                    logger.info(f"Epoch {epoch} - val: {pretty}")
                else:
                    acc = dg_eval.get_acc(
                        self.model, self.val_dataset,
                        batch_size=self.batch_size, device=self.device,
                    )
                    logger.info(f"Epoch {epoch} - val accuracy: {100 * acc:.2f}%")

    def _train_epoch(self) -> float:
        epoch_loss = 0
        use_custom_loss = hasattr(self.model, "compute_loss")
        for batch in self.train_loader:
            batch = [b.to(self.device, non_blocking=True) for b in batch]
            inputs, *targets = batch

            self.optimizer.zero_grad(set_to_none=True)
            output = self.model(inputs)
            if use_custom_loss:
                loss = self.model.compute_loss(output, *targets)
            else:
                loss = F.cross_entropy(output, targets[0].long(), reduction="mean")
            epoch_loss += loss.detach().item()
            loss.backward()
            if self.grad_clip is not None:
                torch.nn.utils.clip_grad_norm_(
                    self.model.parameters(), max_norm=self.grad_clip,
                )
            self.optimizer.step()
        return epoch_loss / len(self.train_loader)


def _build_schedule(
    optimizer: torch.optim.Optimizer,
    lr_schedule: str | type[torch.optim.lr_scheduler.LRScheduler] | None,
    lr_schedule_kwargs: dict[str, Any] | None,
    warmup_epochs: int,
    epochs: int,
    peak_lr: float,
) -> torch.optim.lr_scheduler.LRScheduler | None:
    """Return an LR scheduler or ``None``.

    Supported ``lr_schedule`` values:

    * ``None`` — no schedule (constant LR).
    * ``"cosine"`` — linear warmup (``warmup_epochs``) then cosine annealing to
      ``eta_min_ratio * peak_lr`` (default 0.0). ``lr_schedule_kwargs`` may set
      ``eta_min_ratio``.
    * A scheduler class — instantiated as
      ``lr_schedule(optimizer, **lr_schedule_kwargs)``. ``warmup_epochs`` is
      prepended as a ``LinearLR`` phase if > 0.
    """
    if lr_schedule is None:
        if warmup_epochs > 0:
            return torch.optim.lr_scheduler.LinearLR(
                optimizer, start_factor=1e-3, total_iters=warmup_epochs,
            )
        return None

    kwargs = dict(lr_schedule_kwargs or {})

    if lr_schedule == "cosine":
        eta_min_ratio = kwargs.pop("eta_min_ratio", 0.0)
        cosine = torch.optim.lr_scheduler.CosineAnnealingLR(
            optimizer,
            T_max=max(epochs - warmup_epochs, 1),
            eta_min=peak_lr * eta_min_ratio,
            **kwargs,
        )
        if warmup_epochs > 0:
            warmup = torch.optim.lr_scheduler.LinearLR(
                optimizer, start_factor=1e-3, total_iters=warmup_epochs,
            )
            return torch.optim.lr_scheduler.SequentialLR(
                optimizer, schedulers=[warmup, cosine], milestones=[warmup_epochs],
            )
        return cosine

    inner = lr_schedule(optimizer, **kwargs)
    if warmup_epochs > 0:
        warmup = torch.optim.lr_scheduler.LinearLR(
            optimizer, start_factor=1e-3, total_iters=warmup_epochs,
        )
        return torch.optim.lr_scheduler.SequentialLR(
            optimizer, schedulers=[warmup, inner], milestones=[warmup_epochs],
        )
    return inner


def _run_custom_validation(
    model: torch.nn.Module,
    dataset: torch.utils.data.Dataset,
    batch_size: int,
    device: str,
) -> dict[str, float]:
    model.eval()
    state = model.build_validation_metric(device)
    loader = torch.utils.data.DataLoader(dataset, batch_size)
    with torch.no_grad():
        for batch in loader:
            batch = [b.to(device, non_blocking=True) for b in batch]
            inputs, *targets = batch
            outputs = model(inputs)
            model.validation_update(state, outputs, *targets)
    model.train()
    return model.validation_compute(state)
