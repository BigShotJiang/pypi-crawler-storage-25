import json
import os
import sys
import importlib.util
import urllib.request
from pathlib import Path
from typing import Any

import torch

_HUB_URL = os.environ.get("DG_HUB_URL", "https://storage.googleapis.com/dg-public-models")


def from_pretrained(
    path_or_id: str | Path,
    device: str = "cpu",
    force_download: bool = False,
    finetune: bool = False,
    **kwargs: Any,
) -> torch.nn.Module:
    """Load a pretrained DG model from a local path or hub ID.

    Resolves ``path_or_id`` to a local artifact directory (downloading from
    the hub if necessary), imports its ``model.py``, instantiates ``Model``
    with the merged config, and loads weights from ``model.pt``.

    Caller-supplied ``**kwargs`` override values in ``config.json``. When
    caller kwargs are present, weights are loaded non-strictly and tensors
    whose shapes no longer match the instantiated model are silently dropped
    — this supports architectural tweaks (e.g. changing ``num_classes``) on
    top of pretrained backbones.

    Args:
        path_or_id: Path to a local artifact directory, or a hub model ID.
        device: Device string passed to ``torch.load`` and ``model.to``.
        force_download: Re-download the artifact even if cached.
        finetune: If True, call ``dg.train.freeze_backbone`` on the model
            before returning it.
        **kwargs: Overrides merged into the saved ``config.json``.

    Returns:
        The instantiated model, moved to ``device``, with
        ``_pretrained_path`` set to the resolved artifact directory.
    """
    path = _resolve_path(path_or_id, force_download=force_download)

    spec = importlib.util.spec_from_file_location("_dg_model", str(path / "model.py"))
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    sys.modules.pop("_dg_model", None)

    caller_kwargs = bool(kwargs)

    # Merge saved config (caller kwargs take precedence)
    config_path = path / "config.json"
    if config_path.exists():
        config = json.loads(config_path.read_text())
        for k, v in config.items():
            kwargs.setdefault(k, v)

    model = module.Model(**kwargs)

    state = torch.load(path / "model.pt", map_location=device, weights_only=True)
    if caller_kwargs:
        # Caller overrode constructor args — filter out shape mismatches
        model_state = model.state_dict()
        state = {k: v for k, v in state.items()
                 if k in model_state and v.shape == model_state[k].shape}
    model.load_state_dict(state, strict=not caller_kwargs)
    model.to(device)

    if finetune:
        from dg.train import freeze_backbone
        freeze_backbone(model)

    model._pretrained_path = path
    return model


def _resolve_path(path_or_id: str | Path, force_download: bool = False) -> Path:
    """Return a local artifact directory, downloading from the hub if needed."""
    if os.path.isdir(path_or_id) and os.path.isfile(os.path.join(path_or_id, "model.pt")):
        return Path(path_or_id)

    cache_dir = Path.home() / ".cache" / "dg" / "models" / path_or_id
    if force_download or not cache_dir.exists():
        _download_from_hub(path_or_id, cache_dir)
    return cache_dir


def _download_from_hub(model_id: str, cache_dir: Path) -> None:
    """Fetch ``model.py``, ``model.pt``, and ``config.json`` into ``cache_dir``."""
    cache_dir.mkdir(parents=True, exist_ok=True)
    for filename in ["model.py", "model.pt", "config.json"]:
        url = f"{_HUB_URL}/{model_id}/{filename}"
        urllib.request.urlretrieve(url, str(cache_dir / filename))
