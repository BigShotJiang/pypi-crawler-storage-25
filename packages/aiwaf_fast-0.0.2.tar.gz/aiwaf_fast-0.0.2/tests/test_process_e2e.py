"""Process-level executable script and live server integration tests."""

from __future__ import annotations

import importlib.util
import os
import socket
import subprocess
import sys
import time
from pathlib import Path
from urllib.error import URLError
from urllib.request import Request, urlopen

import pytest

ROOT = Path(__file__).resolve().parent.parent


pytestmark = pytest.mark.skipif(
    importlib.util.find_spec("uvicorn") is None,
    reason="uvicorn not installed",
)


def _wait_for_http(url: str, timeout: float = 20.0, headers: dict | None = None):
    deadline = time.time() + timeout
    last_error = None
    req = Request(url, headers=headers or {})
    while time.time() < deadline:
        try:
            with urlopen(req, timeout=2) as resp:
                return resp.status, resp.read().decode("utf-8", errors="ignore")
        except Exception as exc:  # pragma: no cover
            last_error = exc
            time.sleep(0.2)
    raise AssertionError(f"Server did not become ready: {url} ({last_error})")


def _free_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("127.0.0.1", 0))
        return int(s.getsockname()[1])


def _start_uvicorn(module_app: str, port: int) -> subprocess.Popen:
    return subprocess.Popen(
        [
            sys.executable,
            "-m",
            "uvicorn",
            module_app,
            "--host",
            "127.0.0.1",
            "--port",
            str(port),
            "--log-level",
            "warning",
        ],
        cwd=str(ROOT),
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
    )


def _stop_process(proc: subprocess.Popen, timeout: float = 10.0):
    if proc.poll() is not None:
        return
    proc.terminate()
    try:
        proc.wait(timeout=timeout)
    except subprocess.TimeoutExpired:
        proc.kill()
        proc.wait(timeout=timeout)


def test_real_uvicorn_server_startup_request_and_shutdown():
    port = _free_port()
    proc = _start_uvicorn("examples.simple_example:app", port)
    try:
        status, _ = _wait_for_http(f"http://127.0.0.1:{port}/")
        assert status == 200

        # Browser-like headers should pass AIWAF checks end-to-end over network.
        headers = {
            "User-Agent": (
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0 Safari/537.36"
            ),
            "Accept": "text/html,application/xml;q=0.9,*/*;q=0.8",
            "Accept-Language": "en-US,en;q=0.9",
            "Accept-Encoding": "gzip, deflate",
            "Connection": "keep-alive",
        }
        protected_status, _ = _wait_for_http(
            f"http://127.0.0.1:{port}/api/protected",
            headers=headers,
        )
        assert protected_status == 200
    finally:
        _stop_process(proc)

    # Confirm shutdown happened; exact return code is platform-dependent.
    assert proc.returncode is not None


def test_example_and_debug_apps_boot_as_executable_programs():
    programs = [
        "examples/example_app.py",
        "examples/config_example.py",
        "debug_server.py",
        "test_server.py",
    ]

    # These scripts have fixed ports in __main__. Start briefly and ensure process survives startup.
    for script in programs:
        proc = subprocess.Popen(
            [sys.executable, script],
            cwd=str(ROOT),
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
        )
        try:
            time.sleep(2.0)
            if proc.poll() is not None:
                out, err = proc.communicate(timeout=2)
                raise AssertionError(f"{script} exited early.\nSTDOUT:\n{out}\nSTDERR:\n{err}")
        finally:
            _stop_process(proc)


def test_demo_client_scripts_execute_against_live_example_app():
    # Demo clients are hardcoded to localhost:8000.
    port = 8000
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.bind(("127.0.0.1", port))
    except OSError:
        pytest.skip("Port 8000 is busy; skipping demo script execution test")

    server = _start_uvicorn("examples.example_app:app", port)
    try:
        _wait_for_http("http://127.0.0.1:8000/health")

        for script in ["debug_test.py", "test_aiwaf.py"]:
            env = os.environ.copy()
            env["PYTHONIOENCODING"] = "utf-8"
            completed = subprocess.run(
                [sys.executable, script],
                cwd=str(ROOT),
                capture_output=True,
                text=True,
                timeout=120,
                env=env,
            )
            assert completed.returncode == 0, (
                f"{script} failed\nSTDOUT:\n{completed.stdout}\nSTDERR:\n{completed.stderr}"
            )
    finally:
        _stop_process(server)
