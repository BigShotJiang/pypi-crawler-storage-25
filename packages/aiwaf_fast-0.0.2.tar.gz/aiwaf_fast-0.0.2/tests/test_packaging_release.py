"""Packaging, release metadata, and workflow smoke tests."""

from __future__ import annotations

import importlib.util
import re
import subprocess
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent


def test_requirements_pin_core_runtime_dependencies():
    content = (ROOT / "requirements.txt").read_text(encoding="utf-8")
    assert "fastapi" in content
    assert "starlette" in content
    assert "pydantic" in content
    assert "aiwaf-rust" in content


def test_setup_metadata_fields_present():
    setup_text = (ROOT / "setup.py").read_text(encoding="utf-8")

    assert "name=\"aiwaf-fast\"" in setup_text
    assert "version=\"0.0.1\"" in setup_text
    assert "python_requires=\">=3.7\"" in setup_text
    assert "Framework :: FastAPI" in setup_text


def test_setup_cli_exposes_expected_name_and_version():
    if importlib.util.find_spec("setuptools") is None:
        pytest.skip("setuptools is not installed in this environment")

    name = subprocess.check_output(
        [sys.executable, "setup.py", "--name"], cwd=str(ROOT), text=True
    ).strip()
    version = subprocess.check_output(
        [sys.executable, "setup.py", "--version"], cwd=str(ROOT), text=True
    ).strip()

    assert name == "aiwaf-fast"
    assert version == "0.0.1"


def test_github_publish_workflow_contains_release_steps():
    workflow_path = ROOT / ".github" / "workflows" / "python-publish.yml"
    assert workflow_path.exists()

    text = workflow_path.read_text(encoding="utf-8")
    assert re.search(r"name:\s*.+", text)
    assert "build" in text.lower()
    assert ("publish" in text.lower()) or ("pypi" in text.lower())


@pytest.mark.skipif(importlib.util.find_spec("build") is None, reason="build package not installed")
def test_build_sdist_and_wheel_artifacts(tmp_path):
    out_dir = tmp_path / "dist"
    out_dir.mkdir(parents=True, exist_ok=True)

    cmd = [sys.executable, "-m", "build", "--sdist", "--wheel", "--outdir", str(out_dir)]
    completed = subprocess.run(cmd, cwd=str(ROOT), capture_output=True, text=True, timeout=180)
    assert completed.returncode == 0, f"build failed:\n{completed.stdout}\n{completed.stderr}"

    built = [p.name for p in out_dir.iterdir()]
    assert any(name.endswith(".tar.gz") for name in built)
    assert any(name.endswith(".whl") for name in built)
