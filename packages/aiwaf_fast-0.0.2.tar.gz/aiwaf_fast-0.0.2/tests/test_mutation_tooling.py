"""Mutation testing tooling smoke checks."""

import subprocess
import sys

import pytest


@pytest.mark.mutation
def test_mutmut_cli_available_or_skip():
    probe = subprocess.run([sys.executable, "-m", "mutmut", "--help"], capture_output=True, text=True)
    if probe.returncode != 0:
        pytest.skip("mutmut is not installed")
    assert "usage" in probe.stdout.lower() or "usage" in probe.stderr.lower()


@pytest.mark.mutation
def test_mutation_scope_targets_aiwaf_package():
    # Structural guard to keep mutation runs focused on library code.
    import pathlib

    pkg = pathlib.Path(__file__).resolve().parent.parent / "aiwaf"
    assert pkg.exists()
    assert (pkg / "core.py").exists()
