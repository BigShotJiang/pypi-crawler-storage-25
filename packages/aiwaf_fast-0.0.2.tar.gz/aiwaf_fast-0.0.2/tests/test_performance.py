"""Performance regression guard tests."""

import os
import time

import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient

from aiwaf.core import AIWAF


@pytest.mark.perf
@pytest.mark.slow
def test_request_latency_under_threshold_for_basic_path():
    if os.getenv("AIWAF_RUN_PERF", "0") != "1":
        pytest.skip("Set AIWAF_RUN_PERF=1 to run perf tests")

    app = FastAPI()

    @app.get("/api/perf")
    async def perf_endpoint():
        return {"ok": True}

    AIWAF(app, header_validation={"enabled": False}, rate_limiting={"enabled": False})
    client = TestClient(app)

    n = 200
    start = time.perf_counter()
    for _ in range(n):
        resp = client.get("/api/perf")
        assert resp.status_code == 200
    elapsed = time.perf_counter() - start

    avg_ms = (elapsed / n) * 1000
    assert avg_ms < 20
