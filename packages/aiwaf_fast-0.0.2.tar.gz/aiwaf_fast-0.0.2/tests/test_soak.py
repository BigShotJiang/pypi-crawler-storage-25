"""Soak test for repeated live requests against ASGI app."""

import os
import time

import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient

from aiwaf.core import AIWAF


@pytest.mark.soak
@pytest.mark.slow
def test_short_soak_run_stability():
    if os.getenv("AIWAF_RUN_SOAK", "0") != "1":
        pytest.skip("Set AIWAF_RUN_SOAK=1 to run soak tests")

    app = FastAPI()

    @app.get("/api/soak")
    async def endpoint():
        return {"ok": True}

    AIWAF(app, header_validation={"enabled": False}, rate_limiting={"enabled": False})
    client = TestClient(app)

    deadline = time.time() + 20
    count = 0
    while time.time() < deadline:
        r = client.get("/api/soak")
        assert r.status_code == 200
        count += 1

    assert count > 100
