"""Install-and-import smoke tests for built artifacts."""

from __future__ import annotations

import importlib.util
import subprocess
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent


@pytest.mark.packaging
def test_pip_install_current_project_and_import_aiwaf(tmp_path):
    pip_cmd = [sys.executable, "-m", "pip", "--version"]
    if subprocess.run(pip_cmd, capture_output=True).returncode != 0:
        pytest.skip("pip unavailable")

    target = tmp_path / "pkg"
    target.mkdir(parents=True, exist_ok=True)

    install = subprocess.run(
        [sys.executable, "-m", "pip", "install", ".", "--target", str(target)],
        cwd=str(ROOT),
        capture_output=True,
        text=True,
        timeout=300,
    )
    if install.returncode != 0:
        pytest.skip(f"installation failed in this environment: {install.stderr[-400:]}")

    code = (
        "import sys; "
        f"sys.path.insert(0, r'{str(target)}'); "
        "import aiwaf; "
        "print(aiwaf.__version__)"
    )
    out = subprocess.run([sys.executable, "-c", code], capture_output=True, text=True, timeout=60)
    assert out.returncode == 0
    assert out.stdout.strip() == "1.0.0"
