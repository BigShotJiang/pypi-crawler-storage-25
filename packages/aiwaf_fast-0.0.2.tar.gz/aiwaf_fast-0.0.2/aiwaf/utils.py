"""
Core utility functions for AIWAF
"""
import ipaddress
from typing import Optional, Set, List
from fastapi import Request
import logging

logger = logging.getLogger(__name__)


def get_ip(request: Request) -> str:
    """
    Extract the real IP address from the request, considering proxy headers.
    """
    # Prefer direct client IP; only trust forwarded headers when the peer looks like a proxy.
    client_ip = request.client.host if hasattr(request, 'client') and request.client else None
    if client_ip and _is_valid_ip(client_ip) and not is_private_ip(client_ip):
        return client_ip

    # Check for forwarded headers in order of preference
    forwarded_headers = [
        'x-forwarded-for',
        'x-real-ip',
        'x-client-ip',
        'cf-connecting-ip',  # Cloudflare
        'x-forwarded',
        'forwarded-for',
        'forwarded'
    ]
    
    # Only look at forwarded headers if the direct peer is private/local (likely a proxy) or missing.
    if client_ip is None or is_private_ip(client_ip):
        for header in forwarded_headers:
            if header in request.headers:
                # X-Forwarded-For can contain multiple IPs, take the first one
                ip = request.headers[header].split(',')[0].strip()
                if _is_valid_ip(ip):
                    return ip
    
    # Fall back to client IP
    if client_ip:
        return client_ip
    
    return "unknown"


def _is_valid_ip(ip: str) -> bool:
    """Check if the provided string is a valid IP address."""
    try:
        ipaddress.ip_address(ip)
        return True
    except ValueError:
        return False


def is_private_ip(ip: str) -> bool:
    """Check if IP address is in private range."""
    try:
        ip_obj = ipaddress.ip_address(ip)
        return ip_obj.is_private
    except ValueError:
        return False


def is_exempt(request: Request, exempt_paths: Optional[Set[str]] = None) -> bool:
    """
    Check if a request should be exempt from AIWAF processing.
    
    Args:
        request: FastAPI Request object
        exempt_paths: Set of paths to exempt from processing
        
    Returns:
        True if request should be exempted
    """
    if exempt_paths is None:
        exempt_paths = {
            '/health',
            '/healthz', 
            '/status',
            '/ping',
            '/metrics',
            '/favicon.ico'
        }
    
    path = request.url.path
    
    # Check exact path matches
    if path in exempt_paths:
        return True
    
    # Check path prefixes for common patterns
    exempt_prefixes = [
        '/static/',
        '/assets/',
        '/media/',
        '/admin/jsi18n/',  # Django admin
        '/.well-known/',   # Well-known URIs
        '/api/health',
        '/api/status'
    ]
    
    for prefix in exempt_prefixes:
        if path.startswith(prefix):
            return True
    
    return False


def is_static_file(path: str) -> bool:
    """
    Check if the request is for a static file based on file extension.
    
    Args:
        path: Request path
        
    Returns:
        True if path appears to be a static file
    """
    static_extensions = {
        '.css', '.js', '.png', '.jpg', '.jpeg', '.gif', '.ico', '.svg',
        '.woff', '.woff2', '.ttf', '.eot', '.otf', '.map', '.json',
        '.xml', '.txt', '.pdf', '.zip', '.tar', '.gz', '.webp', '.avif'
    }
    
    path_lower = path.lower()
    
    # Check file extensions
    for ext in static_extensions:
        if path_lower.endswith(ext):
            return True
    
    return False


def sanitize_header_value(value: str, max_length: int = 500) -> str:
    """
    Sanitize header value for logging/storage.
    
    Args:
        value: Header value to sanitize
        max_length: Maximum allowed length
        
    Returns:
        Sanitized header value
    """
    if not value:
        return ""
    
    # Truncate if too long
    if len(value) > max_length:
        value = value[:max_length] + "..."
    
    # Remove any control characters but keep printable ones
    sanitized = ''.join(char for char in value if ord(char) >= 32 or char in '\t\n\r')
    
    return sanitized


def parse_user_agent(user_agent: str) -> dict:
    """
    Parse user agent string to extract basic information.
    
    Args:
        user_agent: User agent string
        
    Returns:
        Dictionary with parsed information
    """
    if not user_agent:
        return {"browser": "unknown", "version": "unknown", "os": "unknown"}
    
    ua_lower = user_agent.lower()
    result = {"browser": "unknown", "version": "unknown", "os": "unknown"}
    
    # Detect browser
    if "chrome" in ua_lower and "edg" not in ua_lower:
        result["browser"] = "chrome"
    elif "firefox" in ua_lower:
        result["browser"] = "firefox"
    elif "safari" in ua_lower and "chrome" not in ua_lower:
        result["browser"] = "safari"
    elif "edg" in ua_lower:
        result["browser"] = "edge"
    elif "opera" in ua_lower or "opr" in ua_lower:
        result["browser"] = "opera"
    
    # Detect OS
    if "windows" in ua_lower:
        result["os"] = "windows"
    elif "mac" in ua_lower or "darwin" in ua_lower:
        result["os"] = "macos"
    elif "linux" in ua_lower:
        result["os"] = "linux"
    elif "android" in ua_lower:
        result["os"] = "android"
    elif "iphone" in ua_lower or "ipad" in ua_lower:
        result["os"] = "ios"
    
    return result


def get_request_fingerprint(request: Request) -> str:
    """
    Generate a fingerprint for the request based on headers and other characteristics.
    
    Args:
        request: FastAPI Request object
        
    Returns:
        Fingerprint string
    """
    import hashlib
    
    # Collect fingerprinting data
    fingerprint_data = []
    
    # Add key headers
    key_headers = [
        'user-agent',
        'accept',
        'accept-language', 
        'accept-encoding',
        'connection'
    ]
    
    for header in key_headers:
        value = request.headers.get(header, '')
        fingerprint_data.append(f"{header}:{value}")
    
    # Add request method and path pattern
    fingerprint_data.append(f"method:{request.method}")
    
    # Create hash
    fingerprint_string = "|".join(fingerprint_data)
    return hashlib.md5(fingerprint_string.encode()).hexdigest()[:16]


class RateLimiter:
    """Simple in-memory rate limiter."""
    
    def __init__(self):
        self._requests = {}  # {ip: [(timestamp, path), ...]}
        self._cleanup_interval = 300  # 5 minutes
        self._last_cleanup = 0
    
    def is_rate_limited(self, ip: str, path: str, max_requests: int = 100, 
                       window_seconds: int = 300) -> bool:
        """
        Check if IP is rate limited.
        
        Args:
            ip: IP address
            path: Request path
            max_requests: Maximum requests allowed in window
            window_seconds: Time window in seconds
            
        Returns:
            True if rate limited
        """
        import time
        
        current_time = time.time()
        
        # Cleanup old entries periodically
        if current_time - self._last_cleanup > self._cleanup_interval:
            self._cleanup_old_entries(current_time, window_seconds * 2)
            self._last_cleanup = current_time
        
        # Get or create request list for this IP
        if ip not in self._requests:
            self._requests[ip] = []
        
        requests = self._requests[ip]
        
        # Remove old requests outside the window
        cutoff_time = current_time - window_seconds
        requests[:] = [(ts, p) for ts, p in requests if ts > cutoff_time]
        
        # Check if over limit
        if len(requests) >= max_requests:
            return True
        
        # Add current request
        requests.append((current_time, path))
        
        return False
    
    def _cleanup_old_entries(self, current_time: float, max_age: int):
        """Clean up old entries to prevent memory leak."""
        cutoff_time = current_time - max_age
        
        for ip in list(self._requests.keys()):
            requests = self._requests[ip]
            requests[:] = [(ts, p) for ts, p in requests if ts > cutoff_time]
            
            # Remove empty lists
            if not requests:
                del self._requests[ip]
