"""Backend interface and implementations for model inference."""

import json
import shutil
import socket
import subprocess
import threading
import time
import urllib.error
import urllib.request
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Iterator

from rich.console import Console

from .discovery import ModelInfo

console = Console()


class Backend(ABC):
    @abstractmethod
    def load(self, model_info: ModelInfo, device: str) -> None: ...

    @abstractmethod
    def generate_stream(
        self,
        messages: list[dict],
        temperature: float,
        max_tokens: int,
    ) -> Iterator[str]: ...

    @abstractmethod
    def unload(self) -> None: ...

    @property
    @abstractmethod
    def name(self) -> str: ...


class TransformersBackend(Backend):
    def __init__(self):
        self.model = None
        self.tokenizer = None

    @property
    def name(self) -> str:
        return "transformers"

    def load(self, model_info: ModelInfo, device: str) -> None:
        import warnings

        import torch
        # Suppress "fast path not available" warning from Qwen3.5 hybrid attention
        # (causal-conv1d / flash-linear-attention don't build on Windows/Python 3.14)
        warnings.filterwarnings("ignore", message=".*fast path is not available.*")
        from transformers import AutoConfig, AutoModelForCausalLM, AutoTokenizer

        def _auto_load(path, **kwargs):
            """Load model with the right auto class based on architecture."""
            cfg = AutoConfig.from_pretrained(path, trust_remote_code=True)
            archs = getattr(cfg, "architectures", []) or []
            # Multimodal / conditional generation models need a different auto class
            if any("ConditionalGeneration" in a for a in archs):
                from transformers import AutoModelForImageTextToText
                console.print(f"  [dim]Architecture:[/] multimodal ({', '.join(archs)})")
                return AutoModelForImageTextToText.from_pretrained(path, **kwargs)
            console.print(f"  [dim]Architecture:[/] {', '.join(archs) or 'unknown'}")
            return AutoModelForCausalLM.from_pretrained(path, **kwargs)

        dtype = torch.bfloat16 if torch.cuda.is_available() else torch.float32
        self._dev_label = "CUDA" if torch.cuda.is_available() else "CPU"
        if torch.cuda.is_available():
            gpu_name = torch.cuda.get_device_name(0)
            vram = torch.cuda.get_device_properties(0).total_memory / 1024**3
            console.print(f"  [dim]Device:[/] {gpu_name} ({vram:.1f} GB VRAM)")
        console.print(f"  [dim]Precision:[/] {dtype}")

        load_kwargs = dict(
            dtype=dtype,
            device_map=device,
            trust_remote_code=True,
        )

        if model_info.has_lora:
            self._load_lora(model_info, load_kwargs)
        else:
            console.print(f"  [cyan]\u27f3[/] Loading model: [bold]{model_info.name}[/]")
            t0 = time.time()
            self.model = _auto_load(str(model_info.path), **load_kwargs)
            console.print(f"  [green]\u2714[/] Model loaded [dim]({time.time() - t0:.1f}s)[/]")

        console.print("  [cyan]\u27f3[/] Loading tokenizer...")
        self.tokenizer = AutoTokenizer.from_pretrained(
            str(model_info.path), trust_remote_code=True
        )
        console.print("  [green]\u2714[/] Tokenizer loaded")

        param_count = sum(p.numel() for p in self.model.parameters()) / 1e9
        console.print(f"  [dim]Parameters:[/] {param_count:.1f}B  [dim]Backend:[/] {self._dev_label}")

    def _load_lora(self, model_info: ModelInfo, load_kwargs: dict):
        from huggingface_hub import snapshot_download
        from peft import PeftModel
        from transformers import AutoConfig, AutoModelForCausalLM

        base_id = model_info.lora_base_model or str(model_info.path)
        base_dir = model_info.path / "base_model"

        # Clean up partial/failed downloads
        if base_dir.exists():
            has_config = (base_dir / "config.json").exists()
            has_weights = (
                any(base_dir.glob("model*.safetensors"))
                or any(base_dir.glob("*.bin"))
            )
            if has_config and has_weights:
                console.print(f"  [green]\u2714[/] Base model found locally: [dim]{base_dir}[/]")
            else:
                console.print("  [yellow]\u26a0[/] Incomplete base model detected, cleaning up...")
                shutil.rmtree(base_dir)
                console.print(f"  [green]\u2714[/] Cleaned [dim]{base_dir}[/]")

        if not base_dir.exists():
            console.print(f"  [yellow]\u2193[/] Downloading base model: [bold]{base_id}[/]")
            console.print(f"    [dim]Saving to: {base_dir}[/]")
            console.print("    [dim]This is a one-time download. Progress bars below:[/]")
            t0 = time.time()
            snapshot_download(
                repo_id=base_id,
                local_dir=str(base_dir),
                ignore_patterns=["*.md", ".gitattributes"],
            )
            console.print(f"  [green]\u2714[/] Base model downloaded [dim]({time.time() - t0:.1f}s)[/]")

        console.print("  [cyan]\u27f3[/] Loading base model into memory...")
        t0 = time.time()

        # Auto-detect architecture (multimodal vs causal)
        cfg = AutoConfig.from_pretrained(str(base_dir), trust_remote_code=True)
        archs = getattr(cfg, "architectures", []) or []
        if any("ConditionalGeneration" in a for a in archs):
            from transformers import AutoModelForImageTextToText
            console.print(f"  [dim]Architecture:[/] multimodal ({', '.join(archs)})")
            base_model = AutoModelForImageTextToText.from_pretrained(str(base_dir), **load_kwargs)
        else:
            console.print(f"  [dim]Architecture:[/] {', '.join(archs) or 'unknown'}")
            base_model = AutoModelForCausalLM.from_pretrained(str(base_dir), **load_kwargs)
        console.print(f"  [green]\u2714[/] Base model loaded [dim]({time.time() - t0:.1f}s)[/]")

        console.print(f"  [cyan]\u27f3[/] Applying LoRA adapter: [dim]{model_info.name}[/]")
        t0 = time.time()
        self.model = PeftModel.from_pretrained(base_model, str(model_info.path))
        console.print(f"  [green]\u2714[/] LoRA adapter applied [dim]({time.time() - t0:.1f}s)[/]")

    def generate_stream(
        self,
        messages: list[dict],
        temperature: float,
        max_tokens: int,
    ) -> Iterator[str]:
        import torch
        from transformers import TextIteratorStreamer

        inputs = self.tokenizer.apply_chat_template(
            messages,
            return_tensors="pt",
            add_generation_prompt=True,
        )
        if isinstance(inputs, torch.Tensor):
            input_ids = inputs.to(self.model.device)
        else:
            input_ids = inputs["input_ids"].to(self.model.device)

        streamer = TextIteratorStreamer(
            self.tokenizer, skip_prompt=True, skip_special_tokens=True
        )

        # Build a comprehensive set of EOS token IDs so the model stops
        # at end-of-turn instead of looping into simulated user/assistant turns
        eos_ids = set()
        if self.tokenizer.eos_token_id is not None:
            eos_ids.add(self.tokenizer.eos_token_id)
        # Add common end-of-turn tokens used by chat models
        for tok_name in ["<|im_end|>", "<|im_start|>", "<|endoftext|>",
                         "<|eot_id|>", "<end_of_turn>", "</s>"]:
            tok_id = self.tokenizer.convert_tokens_to_ids(tok_name)
            # convert_tokens_to_ids returns unk_token_id for unknown tokens
            if tok_id is not None and tok_id != self.tokenizer.unk_token_id:
                eos_ids.add(tok_id)
        # Also check the model's generation_config if available
        if hasattr(self.model, "generation_config"):
            gc = self.model.generation_config
            if gc.eos_token_id is not None:
                if isinstance(gc.eos_token_id, int):
                    eos_ids.add(gc.eos_token_id)
                elif isinstance(gc.eos_token_id, list):
                    eos_ids.update(gc.eos_token_id)

        gen_kwargs = dict(
            input_ids=input_ids,
            streamer=streamer,
            max_new_tokens=max_tokens,
            do_sample=temperature > 0,
            eos_token_id=list(eos_ids) if eos_ids else None,
        )
        if temperature > 0:
            gen_kwargs["temperature"] = temperature

        thread = threading.Thread(
            target=self.model.generate, kwargs=gen_kwargs, daemon=True
        )
        thread.start()

        for chunk in streamer:
            yield chunk

        thread.join()

    def unload(self) -> None:
        if self.model is not None:
            del self.model
            del self.tokenizer
            self.model = None
            self.tokenizer = None
            try:
                import torch
                if torch.cuda.is_available():
                    torch.cuda.empty_cache()
            except ImportError:
                pass


def _find_llama_cli() -> str | None:
    """Search for a llama.cpp CLI executable on the system PATH."""
    candidates = ["llama-cli", "llama-cli.exe", "main", "main.exe"]
    for name in candidates:
        found = shutil.which(name)
        if found:
            return found
    # Check common install locations on Windows
    for extra_dir in [
        Path.home() / "llama.cpp" / "build" / "bin" / "Release",
        Path.home() / "llama.cpp" / "build" / "bin",
        Path.home() / "llama.cpp",
    ]:
        for name in candidates:
            exe = extra_dir / name
            if exe.is_file():
                return str(exe)
    return None


def _format_chat_prompt(messages: list[dict]) -> str:
    """Convert chat messages to a ChatML-style prompt string for llama-cli."""
    parts = []
    for msg in messages:
        role = msg["role"]
        content = msg["content"]
        parts.append(f"<|im_start|>{role}\n{content}<|im_end|>")
    parts.append("<|im_start|>assistant\n")
    return "\n".join(parts)


class LlamaCppBackend(Backend):
    """Runs GGUF models via llama-cli subprocess."""

    def __init__(self):
        self._exe: str | None = None
        self._gguf_path: Path | None = None
        self._process: subprocess.Popen | None = None
        self._gpu: bool = False

    @property
    def name(self) -> str:
        return "llama.cpp"

    def load(self, model_info: ModelInfo, device: str) -> None:
        exe = _find_llama_cli()
        if exe is None:
            raise FileNotFoundError(
                "Could not find llama-cli on PATH. "
                "Install llama.cpp and ensure llama-cli is on your PATH.\n"
                "  → https://github.com/ggerganov/llama.cpp"
            )
        self._exe = exe
        console.print(f"  [dim]Executable:[/] {exe}")

        # Find the GGUF file in the model directory
        gguf_files = sorted(model_info.path.glob("*.gguf"))
        if not gguf_files:
            raise FileNotFoundError(f"No .gguf files found in {model_info.path}")
        self._gguf_path = gguf_files[0]
        if len(gguf_files) > 1:
            console.print(f"  [dim]Multiple GGUF files found, using:[/] {self._gguf_path.name}")
        else:
            console.print(f"  [dim]Model file:[/] {self._gguf_path.name}")

        size_gb = self._gguf_path.stat().st_size / 1024**3
        console.print(f"  [dim]Size:[/] {size_gb:.1f} GB")

        self._gpu = device != "cpu"
        if self._gpu:
            console.print("  [dim]GPU offload:[/] enabled (all layers)")

        # Validate the executable works
        try:
            result = subprocess.run(
                [self._exe, "--version"],
                capture_output=True, text=True, timeout=10,
            )
            version_info = (result.stdout or result.stderr).strip().split("\n")[0]
            if version_info:
                console.print(f"  [dim]Version:[/] {version_info}")
        except (subprocess.TimeoutExpired, OSError):
            pass  # --version may not be supported on older builds

        console.print("  [bold green]\u2714 Ready![/]")

    def generate_stream(
        self,
        messages: list[dict],
        temperature: float,
        max_tokens: int,
    ) -> Iterator[str]:
        if self._exe is None or self._gguf_path is None:
            raise RuntimeError("Backend not loaded — call load() first")

        prompt = _format_chat_prompt(messages)

        cmd = [
            self._exe,
            "-m", str(self._gguf_path),
            "-p", prompt,
            "-n", str(max_tokens),
            "--temp", str(temperature),
            "--no-display-prompt",
            "-s", str(int(time.time())),  # random seed from timestamp
        ]
        if self._gpu:
            cmd.extend(["-ngl", "999"])

        self._process = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            text=True,
            encoding="utf-8",
            errors="replace",
            bufsize=1,
        )

        try:
            assert self._process.stdout is not None
            while True:
                char = self._process.stdout.read(1)
                if not char:
                    break
                yield char
        finally:
            self._process.wait()
            self._process = None

    def unload(self) -> None:
        if self._process is not None:
            self._process.terminate()
            try:
                self._process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                self._process.kill()
            self._process = None
        self._exe = None
        self._gguf_path = None


def _is_apple_silicon() -> bool:
    """Check if running on Apple Silicon (macOS ARM64)."""
    import platform
    return platform.system() == "Darwin" and platform.machine() == "arm64"


def _mlx_available() -> bool:
    """Check if mlx-lm is installed and importable."""
    try:
        import mlx_lm  # noqa: F401
        return True
    except ImportError:
        return False


def _find_vmlx_cli() -> str | None:
    """Search for the vmlx CLI executable on the system PATH."""
    return shutil.which("vmlx")


def _vmlx_available() -> bool:
    """Check if the vmlx CLI is installed and reachable."""
    return _find_vmlx_cli() is not None


class MLXBackend(Backend):
    """Runs models via Apple MLX on Apple Silicon Macs."""

    def __init__(self):
        self.model = None
        self.tokenizer = None

    @property
    def name(self) -> str:
        return "mlx"

    def load(self, model_info: ModelInfo, device: str) -> None:
        from mlx_lm import load as mlx_load

        console.print(f"  [cyan]\u27f3[/] Loading model with MLX: [bold]{model_info.name}[/]")
        console.print("  [dim]Device:[/] Apple Silicon (Metal)")

        t0 = time.time()
        self.model, self.tokenizer = mlx_load(str(model_info.path))
        console.print(f"  [green]\u2714[/] Model loaded [dim]({time.time() - t0:.1f}s)[/]")
        console.print("  [dim]Backend:[/] MLX")

    def generate_stream(
        self,
        messages: list[dict],
        temperature: float,
        max_tokens: int,
    ) -> Iterator[str]:
        if self.model is None or self.tokenizer is None:
            raise RuntimeError("Backend not loaded — call load() first")

        from mlx_lm import stream_generate
        from mlx_lm.sample_utils import make_sampler

        if hasattr(self.tokenizer, "apply_chat_template"):
            prompt = self.tokenizer.apply_chat_template(
                messages, add_generation_prompt=True, tokenize=False
            )
        else:
            # Fallback: simple concatenation
            parts = []
            for msg in messages:
                parts.append(f"{msg['role']}: {msg['content']}")
            parts.append("assistant:")
            prompt = "\n".join(parts)

        sampler = make_sampler(temp=temperature)

        for response in stream_generate(
            self.model,
            self.tokenizer,
            prompt=prompt,
            max_tokens=max_tokens,
            sampler=sampler,
        ):
            if response.text:
                yield response.text

    def unload(self) -> None:
        if self.model is not None:
            del self.model
            del self.tokenizer
            self.model = None
            self.tokenizer = None
            try:
                import mlx.core as mx
                mx.metal.reset_peak_memory()
            except (ImportError, AttributeError):
                pass


class VMLXBackend(Backend):
    """Runs JANG/unsupported-MLX models via a local vMLX OpenAI-compatible server."""

    def __init__(self):
        self._process: subprocess.Popen | None = None
        self._port: int | None = None
        self._base_url: str | None = None
        self._model_name: str | None = None
        self._log_file = None

    @property
    def name(self) -> str:
        return "vmlx"

    def _find_free_port(self) -> int:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
            sock.bind(("127.0.0.1", 0))
            sock.listen(1)
            return int(sock.getsockname()[1])

    def _parser_args_for_model(self, model_info: ModelInfo) -> list[str]:
        model_hints = " ".join(
            [model_info.model_type, model_info.name, *model_info.architectures]
        ).lower()

        if "gemma4" in model_hints or "gemma-4" in model_hints:
            return ["--tool-call-parser", "gemma4", "--reasoning-parser", "gemma4"]
        if "qwen3" in model_hints or "qwen-3" in model_hints:
            return ["--tool-call-parser", "qwen3", "--reasoning-parser", "qwen3"]
        if "deepseek" in model_hints:
            return ["--tool-call-parser", "deepseek", "--reasoning-parser", "deepseek_r1"]
        if "llama4" in model_hints or "llama-4" in model_hints:
            return ["--tool-call-parser", "llama4"]
        if "llama3" in model_hints or "llama-3" in model_hints:
            return ["--tool-call-parser", "llama3"]
        return []

    def _wait_until_ready(self, timeout: float = 60.0) -> None:
        assert self._base_url is not None
        deadline = time.time() + timeout
        last_error: Exception | None = None
        while time.time() < deadline:
            try:
                with urllib.request.urlopen(f"{self._base_url}/models", timeout=2) as resp:
                    data = json.loads(resp.read().decode("utf-8"))
                if data.get("data"):
                    return
            except (urllib.error.URLError, TimeoutError, json.JSONDecodeError, OSError) as exc:
                last_error = exc
                time.sleep(0.5)

            if self._process is not None and self._process.poll() is not None:
                raise RuntimeError("vMLX server exited before it became ready")

        raise RuntimeError(f"Timed out waiting for vMLX server to start: {last_error}")

    def load(self, model_info: ModelInfo, device: str) -> None:
        if not _is_apple_silicon():
            raise RuntimeError("vMLX backend requires Apple Silicon")

        vmlx = _find_vmlx_cli()
        if vmlx is None:
            raise FileNotFoundError(
                "Could not find vmlx on PATH. Install it with: pip install vmlx"
            )

        self.unload()

        port = self._find_free_port()
        self._port = port
        self._base_url = f"http://127.0.0.1:{port}/v1"
        self._model_name = model_info.name
        self._log_file = open(Path("/tmp") / f"froggy-vmlx-{port}.log", "w", encoding="utf-8")

        cmd = [
            vmlx,
            "serve",
            str(model_info.path),
            "--host",
            "127.0.0.1",
            "--port",
            str(port),
            "--served-model-name",
            model_info.name,
            *self._parser_args_for_model(model_info),
        ]

        console.print(f"  [cyan]\u27f3[/] Starting vMLX server for [bold]{model_info.name}[/]")
        console.print(f"  [dim]Executable:[/] {vmlx}")
        console.print(f"  [dim]Endpoint:[/] {self._base_url}")

        self._process = subprocess.Popen(
            cmd,
            stdout=self._log_file,
            stderr=subprocess.STDOUT,
            text=True,
        )
        try:
            self._wait_until_ready()
        except Exception:
            self.unload()
            raise

        console.print("  [bold green]\u2714 Ready![/]")

    def generate_stream(
        self,
        messages: list[dict],
        temperature: float,
        max_tokens: int,
    ) -> Iterator[str]:
        if self._base_url is None or self._model_name is None:
            raise RuntimeError("Backend not loaded — call load() first")

        body = json.dumps(
            {
                "model": self._model_name,
                "messages": messages,
                "stream": True,
                "temperature": temperature,
                "max_tokens": max_tokens,
            }
        ).encode()
        req = urllib.request.Request(
            f"{self._base_url}/chat/completions",
            data=body,
            headers={"Content-Type": "application/json"},
        )

        with urllib.request.urlopen(req) as resp:
            for raw_line in resp:
                line = raw_line.decode("utf-8").strip()
                if not line or not line.startswith("data:"):
                    continue
                payload = line[5:].strip()
                if payload == "[DONE]":
                    break
                chunk = json.loads(payload)
                delta = chunk.get("choices", [{}])[0].get("delta", {})
                content = delta.get("content")
                if content:
                    yield content

    def unload(self) -> None:
        if self._process is not None:
            self._process.terminate()
            try:
                self._process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                self._process.kill()
                self._process.wait(timeout=5)
            self._process = None
        if self._log_file is not None:
            self._log_file.close()
            self._log_file = None
        self._port = None
        self._base_url = None
        self._model_name = None


class OllamaBackend(Backend):
    """Communicates with a running Ollama server via its REST API."""

    def __init__(self, base_url: str = "http://localhost:11434"):
        self.base_url = base_url
        self._model_name: str | None = None
        self._model_size_gb: float = 0.0
        self._num_ctx: int = 8192  # sensible default, auto-tuned on load

    @property
    def name(self) -> str:
        return "ollama"

    def _get_system_memory_gb(self) -> float:
        """Get total system memory in GB."""
        try:
            import platform
            if platform.system() == "Darwin":
                import subprocess
                result = subprocess.run(
                    ["sysctl", "-n", "hw.memsize"],
                    capture_output=True, text=True, timeout=5,
                )
                return int(result.stdout.strip()) / (1024 ** 3)
        except Exception:
            pass
        return 0.0

    def _auto_tune_context(self, model_size_gb: float) -> int:
        """Pick the largest context window that fits comfortably in memory.

        On Apple Silicon unified memory, the model weights, KV cache, and OS
        all share the same RAM pool.  A 27B Q4_K_M (~16 GB) on a 32 GB machine
        leaves ~16 GB for KV cache + OS.  Each context token costs roughly
        0.5-1 MB for a 27B model, so 8192 ctx ≈ 4-8 GB — comfortably fits
        without swap thrashing.
        """
        total_ram = self._get_system_memory_gb()
        if total_ram <= 0:
            return 8192  # safe fallback

        headroom = total_ram - model_size_gb - 4.0  # 4 GB for OS + apps
        if headroom <= 0:
            return 2048  # extreme memory pressure

        # Rough KV cache estimate: ~0.5 MB per token with q8_0 KV cache for 27B
        # (regular fp16 KV is ~0.8 MB/tok, q8_0 halves it)
        mb_per_token = 0.5 if model_size_gb > 10 else 0.3
        max_ctx = int((headroom * 1024) / mb_per_token)

        # Clamp to power-of-2-ish sensible values
        # Prefer smaller ctx to leave more headroom and avoid swap thrashing
        for ctx in [16384, 8192, 4096, 2048]:
            if ctx <= max_ctx:
                return ctx
        return 2048

    def load(self, model_info: ModelInfo, device: str) -> None:
        console.print(f"  [dim]Server:[/] {self.base_url}")

        # Verify server is reachable and model exists
        with urllib.request.urlopen(f"{self.base_url}/api/tags") as resp:
            data = json.loads(resp.read())

        available = {m["name"]: m for m in data.get("models", [])}
        if model_info.name not in available:
            raise ValueError(
                f"Model '{model_info.name}' not found on Ollama server. "
                f"Available: {', '.join(available)}"
            )

        self._model_name = model_info.name
        model_data = available[model_info.name]
        self._model_size_gb = model_data.get("size", 0) / (1024 ** 3)

        # Auto-tune context window based on available memory
        self._num_ctx = self._auto_tune_context(self._model_size_gb)
        total_ram = self._get_system_memory_gb()

        console.print(f"  [dim]Model:[/] {self._model_name}")
        if self._model_size_gb > 0:
            console.print(f"  [dim]Model size:[/] {self._model_size_gb:.1f} GB")
        if total_ram > 0:
            console.print(f"  [dim]System RAM:[/] {total_ram:.0f} GB")
        console.print(f"  [dim]Context window:[/] {self._num_ctx} tokens (auto-tuned)")

        # Hint: for best performance, start Ollama with these env vars:
        #   OLLAMA_FLASH_ATTENTION=1 OLLAMA_KV_CACHE_TYPE=q8_0 ollama serve
        # This enables flash attention and quantized KV cache (50% less memory).
        import os
        if not os.environ.get("OLLAMA_FLASH_ATTENTION"):
            console.print(
                "  [yellow]\u26a0[/] Tip: restart Ollama with "
                "[bold]OLLAMA_FLASH_ATTENTION=1 OLLAMA_KV_CACHE_TYPE=q8_0[/] "
                "for faster inference"
            )

        # Pre-load the model into memory so first response is fast.
        # keep_alive=-1 means "keep loaded indefinitely" (no idle unload).
        console.print("  [cyan]\u27f3[/] Pre-loading model into memory...")
        t0 = time.time()
        try:
            preload_body = json.dumps({
                "model": self._model_name,
                "keep_alive": -1,
                "options": {
                    "num_ctx": self._num_ctx,
                    "num_gpu": 999,  # offload all layers to Metal GPU
                },
            }).encode()
            preload_req = urllib.request.Request(
                f"{self.base_url}/api/generate",
                data=preload_body,
                headers={"Content-Type": "application/json"},
            )
            with urllib.request.urlopen(preload_req, timeout=300) as preload_resp:
                preload_resp.read()  # consume response
            console.print(f"  [green]\u2714[/] Model loaded [dim]({time.time() - t0:.1f}s)[/]")
        except Exception as e:
            console.print(f"  [yellow]\u26a0[/] Pre-load failed ({e}), first response may be slow")

        console.print("  [bold green]\u2714 Ready![/]")

    def generate_stream(
        self,
        messages: list[dict],
        temperature: float,
        max_tokens: int,
    ) -> Iterator[str]:
        if self._model_name is None:
            raise RuntimeError("Backend not loaded — call load() first")

        body = json.dumps({
            "model": self._model_name,
            "messages": messages,
            "stream": True,
            "keep_alive": -1,  # don't unload between turns
            "options": {
                "temperature": temperature,
                "num_predict": max_tokens,
                "num_ctx": self._num_ctx,
                "num_gpu": 999,  # offload all layers to Metal GPU
            },
        }).encode()

        req = urllib.request.Request(
            f"{self.base_url}/api/chat",
            data=body,
            headers={"Content-Type": "application/json"},
        )

        with urllib.request.urlopen(req) as resp:
            for line in resp:
                if not line.strip():
                    continue
                chunk = json.loads(line)
                if chunk.get("done"):
                    # Extract and display performance stats
                    eval_count = chunk.get("eval_count", 0)
                    eval_duration = chunk.get("eval_duration", 0)
                    if eval_count > 0 and eval_duration > 0:
                        tps = eval_count / (eval_duration / 1e9)
                        self._last_tps = tps
                    break
                content = chunk.get("message", {}).get("content", "")
                if content:
                    yield content

    def unload(self) -> None:
        # Tell Ollama to unload the model from memory
        if self._model_name is not None:
            try:
                body = json.dumps({
                    "model": self._model_name,
                    "keep_alive": 0,
                }).encode()
                req = urllib.request.Request(
                    f"{self.base_url}/api/generate",
                    data=body,
                    headers={"Content-Type": "application/json"},
                )
                with urllib.request.urlopen(req, timeout=10) as resp:
                    resp.read()
            except Exception:
                pass
        self._model_name = None


BACKENDS: dict[str, type[Backend]] = {
    "transformers": TransformersBackend,
    "llama.cpp": LlamaCppBackend,
    "ollama": OllamaBackend,
    "mlx": MLXBackend,
    "vmlx": VMLXBackend,
}


def pick_backend(model_info: ModelInfo) -> Backend:
    """Auto-select the best backend for a given model."""
    if model_info.is_ollama:
        return OllamaBackend()
    if model_info.has_gguf:
        return LlamaCppBackend()
    if model_info.has_jang:
        return VMLXBackend()
    if _is_apple_silicon() and _mlx_available():
        return MLXBackend()
    return TransformersBackend()
