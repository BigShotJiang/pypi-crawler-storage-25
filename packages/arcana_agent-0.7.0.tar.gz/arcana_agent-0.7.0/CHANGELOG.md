# Changelog

All notable changes to Arcana will be documented in this file.

## [Unreleased]

### v0.7.0 — "The Cognitive Primitives Release"

Runtime services for the LLM's own reasoning state. The LLM can now invoke
two intercepted tools — `recall` and `pin` (with companion `unpin`) — to
work around the lossiness of working-set compression. See the user guide at
`docs/guide/cognitive-primitives.md` and Principle 9 in `CONSTITUTION.md`.

#### Added — Cognitive primitives
- **`recall(turn, include?)`** — retrieve an earlier turn's messages at
  full fidelity, bypassing any working-set compression. Supports
  `include="all"` (default) / `"assistant_only"` / `"tool_calls"` filters.
  Delegates to the live conversation log, falls back to the trace reader.
  Out-of-range / invalid turns return structured `RecallResult` with
  `found=False` and an actionable `note` — never exceptions (Principle 5).
- **`pin(content, label?, until_turn?)`** — protect specific content from
  compression in future working sets. Returns a `pin_id` the LLM uses with
  `unpin`. Idempotent by SHA-256 of content (duplicate pin returns the
  existing id). Budget-capped at
  `RuntimeConfig.pin_budget_fraction * total_window` (default 50%) —
  over-cap requests are rejected with a structured diagnosis that includes
  current usage, requested size, cap, and a remediation suggestion. The
  framework never auto-unpins or truncates existing pins.
- **`unpin(pin_id)`** — remove an earlier pin; always returns a structured
  result whether or not the id existed.
- **Pinned blocks render inside the Working layer** as independent
  `ContextBlock(pinned=True)` entries, excluded from
  `_compress_with_relevance` / `_aggressive_truncate`, and surfaced in
  `ContextDecision.decisions` with `outcome="kept"` and `reason="pinned"`.
  Principle 2's four-layer structure (Identity/Task/Working/External) is
  unchanged — no new layer.
- **`RuntimeConfig.cognitive_primitives: list[str] = []`** and
  **`RuntimeConfig.pin_budget_fraction: float = 0.5`** — opt-in per
  runtime; empty default means no behavioural change.
- **`EventType.COGNITIVE_PRIMITIVE`** — every primitive invocation emits
  a trace event with `{primitive, args, result}` metadata.

#### Added — Contracts
- New module `arcana.contracts.cognitive` — `RecallRequest/Result`,
  `PinRequest/Result`, `UnpinRequest/Result`, `PinEntry`, `PinState`.
- `ContextBlock.pinned: bool = False` — per-block flag.

#### Added — Runtime
- `arcana.runtime.cognitive.CognitiveHandler` — session-local handler
  that owns `PinState` and services interception, wired into
  `ConversationAgent._execute_tools` via the same mechanism as `ask_user`.
- `WorkingSetBuilder.set_pin_state(pin_state)` — attaches the session's
  pin state so active pins are rendered as independent messages in every
  working set build.

#### Added — CLI
- `arcana trace show <run_id> --cognitive` — filter to
  `COGNITIVE_PRIMITIVE` events with human-readable formatting per primitive.
- `arcana trace show <run_id> --context` — pinned entries are now flagged
  with a `[PIN]` prefix in the per-message decisions view.
- `arcana trace replay <run_id> --turn N` — appends an *Active pins at
  turn N* section reconstructed from the run's cognitive events.

#### Added — Documentation
- New user guide: `docs/guide/cognitive-primitives.md`.
- `CONSTITUTION.md` v3.0 — Principle 9 (Cognitive Primitives as Services)
  and two Chapter IV entries.

#### Constitutional guard (explicitly NOT done)
- Framework does not call a primitive on the LLM's behalf; every
  invocation is an explicit LLM tool call with a `tool_call_id` and trace
  record.
- No system-prompt hints such as *"consider using recall here"*.
- No auto-unpin, no pin truncation, no eviction on budget pressure — the
  LLM decides how to free budget when rejected.
- Default-off: empty `cognitive_primitives` list means zero behavioural
  change over v0.6.0.

#### Stats
- 1368 tests passing (+31 new): `test_cognitive_recall.py` (11) +
  `test_cognitive_pin.py` (19) + `test_context_decision_evidence.py` (+1
  pinned-block case).

### v0.6.0 — "The Explainability Release"

#### Added — Context Explainability
- **`MessageDecision` contract**: Structured per-message evidence for every context composition. Records index / role / outcome (kept / compressed / dropped / summarized) / fidelity level (L0–L3) / relevance score / token counts before/after / reason. One entry per input message.
- **`ContextDecision.decisions`**: Authoritative list of `MessageDecision` replacing the free-text-only explanation. Covers all 5 strategy paths (passthrough, tail_preserve head/tail/middle, aggressive_truncate, LLM summarize, no-summary-budget).
- **Stale tool result pruning visibility**: `_prune_stale_tool_results` now returns `pruning_info` mapping pruned indices to original token counts. Phase 0 pruning is visible in `decisions` with `reason="stale_tool_result"` (or merged with the downstream strategy reason).
- **`CONTEXT_DECISION` trace event**: metadata now carries the full `ContextDecision.model_dump()` and `ContextReport.model_dump()` — consumers can losslessly reconstruct either.

#### Added — Prompt Snapshots & Replay
- **`PromptSnapshot` contract**: Captures the exact `LLMRequest` (messages, tools, model, response_format, budget snapshot) sent to the provider for a single turn.
- **`EventType.PROMPT_SNAPSHOT`**: Emitted before each `gateway.generate()` / `gateway.stream()` when opted in.
- **`RuntimeConfig.trace_include_prompt_snapshots: bool = False`**: Opt-in flag. Default off to avoid PII/secret leakage and trace bloat.
- **`TraceReader.list_turns(run_id)`**: Enumerate turn numbers that have replay evidence.
- **`TraceReader.replay_prompt(run_id, turn)`**: Reconstruct `PromptReplay` for a single turn (prompt snapshot + context decision + context report + budget snapshot).
- **`arcana trace replay <run_id> --turn N`**: CLI subcommand for human-readable or JSON replay output. Supports `--prompt-only` / `--decision-only` / `--json` modes.

#### Constitutional guard (explicitly NOT done)
- Framework does not inject `MessageDecision` or relevance scores into the LLM prompt itself (would violate Prohibition 1 / P4)
- No automatic recovery, retry, or tool expansion based on decisions (decisions are retrospective evidence, not an input channel)
- Existing strategy selection / compression thresholds / fidelity logic unchanged (pure transparency layer)
- Prompt snapshots default off (anti context/trace hoarding, anti PII leakage)

#### Stats
- 1337 tests passing (+13 new): `test_context_decision_evidence.py` (5) + `test_trace_replay.py` (8)

### v0.5.0 — "The Resilience Release"

#### Added — Runtime OS Reliability
- **Phase 0 tool result pruning**: zero-cost compression stage before strategy-level compression. Old tool results (outside `tool_result_staleness_turns * 3` recent messages) replaced with summary placeholders. Error/failure results never pruned.
- **Iteration budget sharing**: `BudgetTracker.max_iterations` / `iterations_used`; `Budget.max_iterations` propagates to shared tracker; team agents share a global iteration cap.
- **MCP dynamic tool discovery**: `MCPConnection` listens for `notifications/tools/list_changed`; `MCPToolProvider` refreshes the registry on change.

#### Constitutional review decisions (from specs/v050-upgrade.md)
- **Rejected**: Parallel tool conflict detection — tool authors should self-protect (over-engineering, framework overreach)
- **Rejected**: Diagnosis → recovery loop — framework crossing into LLM strategy territory (violates Principle 6 boundary)
- **Rejected**: ChatSession persistence — application-layer concern, not Runtime OS

## [0.4.0] - 2026-04-11

### Added — Execution Isolation Architecture
- **`ExecutionBackend` protocol**: Pluggable abstraction for WHERE tools execute. Decouples tool logic from execution environment. Ships with `InProcessBackend` (default, zero overhead). Framework extension point for subprocess/container/remote backends
- **`ExecutionChannel` protocol**: Pluggable abstraction for HOW the agent loop communicates with tool execution. Enables future physical separation of Brain (reasoning) and Hands (tool execution). Ships with `LocalChannel` (wraps ToolGateway, zero overhead)
- **`ToolGateway.close()`**: Lifecycle method that invokes `backend.cleanup()`, ensuring non-default backends (socket, container, etc.) release resources properly
- **`Runtime.close()` chains to `ToolGateway.close()`**: Full resource cleanup cascade from Runtime → ToolGateway → ExecutionBackend
- **`ConversationAgent` channel routing**: `_execute_tools()` prefers `ExecutionChannel` when provided, falls back to `ToolGateway` otherwise. `ask_user` always bypasses the channel

### Stats
- All 1227 tests passing, 0 failures (+25 new tests)

## [0.3.3] - 2026-04-06

### Fixed — Provider Compatibility
- **Intent router bypasses structured output**: When `response_format` is set, the intent router no longer short-circuits to `direct_answer` (which didn't pass the format to the LLM). Structured output now always goes through the full ConversationAgent loop
- **Intent router ignores available tools**: `classify()` now receives `available_tools` from the tool registry, so "What is X? Use the calc tool" correctly routes to the agent loop instead of direct_answer
- **Structured output code fence stripping**: Providers that return JSON wrapped in markdown code fences (` ```json ... ``` `) are now auto-stripped before parsing. Fixes GLM and MiniMax structured output
- **Structured output schema prompt strengthened**: `json_object` fallback mode now includes exact field names, a concrete example, and "do not rename or omit" instruction. Fixes Kimi/GLM/MiniMax returning wrong field names
- **MiniMax auto-degraded to prompt-based tools**: MiniMax rejects native `tool_calls` with 400; `ProviderProfile` auto-degrades on first failure, subsequent calls use prompt-based fallback seamlessly

### Verified Providers
Real API verification for all accessible providers:
- **DeepSeek**: direct answer ✓, tool calling ✓, structured output ✓
- **OpenAI**: direct answer ✓, tool calling ✓, structured output ✓
- **Anthropic**: direct answer ✓, structured output ✓ (previously verified)
- **Kimi (Moonshot)**: direct answer ✓, tool calling ✓, structured output ✓ ← NEW
- **GLM (Zhipu)**: direct answer ✓, tool calling ✓, structured output ✓ ← NEW
- **MiniMax**: direct answer ✓, tool calling ✓ (auto-degraded), structured output ✓ ← NEW
- Gemini: blocked by region restriction (API key valid)
- Ollama: not tested (requires local deployment)

### Stats
- All 1202 tests passing, 0 failures (+18 new tests)

## [0.3.2] - 2026-04-06

### Changed — Architecture
- **ChatSession delegates to ConversationAgent**: `ChatSession.send()` now runs the full `ConversationAgent` turn loop internally, gaining all V2 features automatically (ask_user, lazy tools, diagnostics, fidelity compression, thinking assessment, streaming events). Removes ~300 lines of duplicated LLM/tool dispatch logic
- **Memory injection moved to first user message**: Memory context is now injected into the first user message instead of the system prompt, keeping the system prompt stable for provider prompt caching

### Added — Context Intelligence
- **Fidelity-graded compression**: Context compression now uses 4 fidelity levels instead of binary keep/compress:
  - **L0** (score ≥ 0.7): Original message preserved verbatim
  - **L1** (score ≥ 0.4): Condensed to key content
  - **L2** (score < 0.4): Single summary line
  - **L3**: Dropped entirely
  - `ContextReport.fidelity_distribution` tracks the distribution per turn
- **`StreamAccumulator`**: New utility class (`runtime/stream_accumulator.py`) for assembling streaming chunks into a complete `LLMResponse` — single state-management point for text, thinking, tool calls, and usage
- **`LazyToolRegistry.tool_token_estimate`**: Cached token estimate for current working set tools, auto-invalidated on expansion/reset
- **`Message.token_count` caching**: Token estimation now uses cached property on `Message` instead of re-computing from content text each call

### Fixed
- **Recall tool budgeting**: Fixed budget accounting for recall tool invocations
- **Zero-budget page table eviction**: Fixed edge case where zero remaining budget caused incorrect eviction behavior in context compression

### Removed
- **Virtual memory subsystem**: Added in Context OS commit, removed after evaluation — the fidelity spectrum approach achieves the same goals with less complexity

### Stats
- All 1184 tests passing, 0 failures

## [0.3.1] - 2026-04-05

### Added — Provider Compatibility
- **`ProviderProfile`**: Unified capability system per provider. Tracks `tool_calls`, `json_schema`, `json_mode`, `streaming`, `stream_options`. Known providers get pre-configured profiles; custom providers get conservative defaults
- **Auto-degradation**: When a provider returns 400 for tool_calls, the profile is updated automatically — subsequent calls skip native tools and use prompt-based fallback. Only fails once per capability
- **Custom provider registration**: `providers={"siliconflow": {"api_key": "...", "base_url": "...", "model": "...", "tool_calls": False}}` — any OpenAI-compatible API with explicit capability overrides
- **`ChatSession.send(message, images=[...])`**: Multimodal messages in chat sessions
- **`runtime.create_chat_session()`**: Returns ChatSession directly without requiring `async with`, for use across HTTP requests
- **`arcana.RuntimeConfig`**: Now exported from the top-level package

### Stats
- All 1173 tests passing, 0 failures

## [0.3.0] - 2026-04-04 — "The Context Release"

### Added — Context Transparency

- **`ContextReport`**: Every LLM call now produces a detailed report of how the context window was composed. Shows token allocation across layers (identity, task, tools, history, memory), compression metrics, and window utilization. Available on `RunResult.context_report` and `ChatResponse.context_report`
- **`ContextStrategy`**: Adaptive compression strategy system replaces one-size-fits-all compression. Four tiers:
  - **passthrough** (< 50% utilization): No compression, zero overhead
  - **tail_preserve** (50-75%): Compress middle history, keep recent turns verbatim
  - **llm_summarize** (75-90%): Use cheap LLM call for semantic summarization
  - **aggressive_truncate** (> 90%): Keep only system + last 2 turns
  - Configurable via `Runtime(context_strategy=ContextStrategy(...))` or shorthand `"off"` / `"always_compress"`
- **Structured stream events**: `runtime.stream()` and `ChatSession.stream()` now emit:
  - `TOOL_START` — tool name and arguments before execution
  - `TOOL_END` — tool result and duration after execution
  - `TURN_END` — token count and cost at end of each turn
  - `CONTEXT_REPORT` — full context composition report per turn
- **`StreamEventType` exported**: `arcana.StreamEventType` for `match` statements on stream events

### Stats
- Tests: 1142 → 1173 (+31 new tests for context features)
- All 1173 tests passing, 0 failures

## [0.2.2] - 2026-04-04

### Fixed — Core Reliability
- **asyncio.Lock replaces threading.Lock**: `Runtime._totals_lock` was a `threading.Lock` blocking the event loop in async code. Now uses `asyncio.Lock` for proper async concurrency
- **Tool gateway idempotency race**: Fixed TOCTOU race where two concurrent calls with the same idempotency key could both execute. Lock now covers the entire check→execute→cache window
- **Budget boundary off-by-one**: `BudgetTracker.check_budget()` used `>=` (triggers at exact limit), now uses `>` (allows using exactly the allocated budget). Same fix applied to `BudgetScope`
- **Provider close() isolation**: `ModelGatewayRegistry.close()` now catches exceptions per-provider — one failing provider no longer blocks cleanup of others
- **MCP reconnect serialization**: Added `asyncio.Lock` to `MCPConnection._reconnect()` preventing concurrent reconnect attempts from corrupting transport state
- **MCP disconnect_all resilience**: Individual server disconnect failures no longer abort the cleanup loop
- **Graph checkpointer blocking I/O**: `GraphCheckpointer.save()/load()/delete()` were fake-async (blocking file I/O). Now uses `asyncio.to_thread()` + atomic write (temp file + rename) to prevent corruption on crash
- **Trace reader token/cost accounting**: `TraceReader.summarize()` used `max()` instead of `+=` for tokens/cost, reporting peak values instead of totals
- **SSE line terminator**: MCP Streamable HTTP transport now handles `\r\n` and `\r` per SSE spec, not just `\n`
- **Silent hook/callback failures**: Bare `except: pass` in agent hooks and `on_parse_error` callback now logs to `logger.debug` for debuggability

### Added
- **`Runtime` as async context manager**: `async with Runtime(...) as rt:` ensures `close()` is called, preventing HTTP connection leaks
- **`BudgetTracker.can_afford(estimated_tokens, estimated_cost)`**: Now checks cost budget in addition to token budget

### Removed — Dead Code Cleanup
- **`orchestrator/`**: Entire module (Orchestrator, TaskScheduler, TaskGraph, ExecutorPool) — never used by runtime
- **`gateway/router.py`**: ModelRouter — never imported
- **`gateway/capabilities.py`**: CapabilityRegistry — never queried
- **`streaming/sse.py`**: SSE formatter — never called
- **`runtime/replay.py`**: ReplayEngine — never wired up
- **`tool_gateway/adapters/langchain.py`**: LangChain bridge — never loaded
- **`storage/postgres.py`**, **`storage/chroma.py`**: Production storage backends removed. Arcana provides the `StorageBackend`/`VectorStore` interfaces; users implement for their infrastructure
- Removed `chromadb` dev dependency

### Stats
- Tests: 1234 → 1142 (removed 92 tests for deleted dead code)
- All 1142 tests passing, 0 failures
- mypy strict: 8 errors (all pre-existing)

## [0.2.1] - 2026-03-28

### Fixed — Production High Availability
- **Provider connection leak**: `Runtime.close()` now cascades to all provider HTTP clients (AsyncOpenAI, AsyncAnthropic). Previously only closed MCP connections, leaking connection pools in long-running apps
- **Budget race condition**: `Runtime._total_tokens_used` and `_total_cost_usd` now protected by `threading.Lock`. Concurrent `run()` calls no longer corrupt cumulative budget counters
- **timeout_ms actually wired**: `ModelConfig.timeout_ms` now passed to provider SDK `create()` calls as per-request timeout. Previously the config existed but was silently ignored (SDK defaulted to 600s)
- **Cancellation safety**: `asyncio.CancelledError` and `KeyboardInterrupt` in `Runtime.run()` and `ConversationAgent` now record partial budget and leave state consistent before re-raising

### Added — Developer Experience
- **`arcana init`**: CLI scaffold command generates `main.py` + `.env.example` + `agent.yaml` for 30-second quickstart
- **`Runtime.on()` / `Runtime.off()`**: Event hook API for runtime lifecycle events (`run_start`, `run_end`, `error`). Supports sync and async callbacks, chainable
- **`ChatSession(max_history=N)`**: Sliding window on message history to prevent OOM in long conversations. System messages always preserved. `runtime.chat(max_history=100)`
- **LangChain adapter test suite**: 18 tests covering spec extraction, execution, error handling, protocol compliance
- **SECURITY.md**: Honest security model documentation — what Arcana secures and what it doesn't
- **CI coverage reporting**: pytest-cov + Codecov upload in GitHub Actions
- **Dynamic README badges**: PyPI version, CI status, coverage — no more stale static badges

### Changed
- Example 13 rewritten to use `runtime.chat()` / `ChatSession.send()` instead of manual LLM message management

### Stats
- Tests: 1164 → 1234 (+70 new tests)
- All 1234 tests passing, 0 failures

## [0.2.0] - 2026-03-27

### Fixed — Structured Output Reliability
- **`result.parsed` always returns `BaseModel | None`**: Fixed bug where `parsed` could be a raw `dict` when provider degrades to `json_object` mode. Now handles dict inputs, validates `on_parse_error` callback returns, and guarantees type consistency
- **Anthropic structured output**: `AnthropicProvider` now supports `response_format` — injects JSON schema into system prompt (same fallback strategy as DeepSeek/Ollama/Kimi). Works with and without tools

### Added — Batch API & Budget Granularity
- **`Runtime.run_batch(tasks, concurrency=5)`**: Run multiple independent tasks concurrently with `asyncio.Semaphore`. Individual failures don't crash the batch. Returns `BatchResult` with results, succeeded/failed counts, total tokens/cost
- **Provider-level `batch_generate()`**: `OpenAICompatibleProvider.batch_generate(requests, config, concurrency=5)` for concurrent LLM calls. Registry-level fallback when provider doesn't implement batch
- **`ChainStep.budget`**: Per-step budget in `chain()` pipelines. Each step can have its own budget cap, always capped by chain-level remaining budget. Steps without budget share the chain pool

### Stats
- Tests: 1164, all passing

## [0.1.0-beta.8] - 2026-03-27

### Added — Team Dual Mode
- **`runtime.team(mode="shared"|"session")`**: Two collaboration modes. `"shared"` (default) — all agents share one conversation history. `"session"` — each agent has an independent context; other agents' messages arrive as user messages

### Stats
- Tests: 1135, all passing

## [0.1.0-beta.7] - 2026-03-27

### Fixed — Provider Compatibility
- **Cost estimation**: `TokenUsage.cost_estimate` now uses realistic mid-range pricing ($0.15/M input, $0.60/M output) instead of placeholder values
- **Zero-token warning**: When a provider reports 0 tokens, the runtime estimates from response length and logs a warning instead of silently tracking $0
- **Structured output + json_schema auto-downgrade**: Providers that don't support `json_schema` response format (DeepSeek, Ollama, Kimi, GLM, MiniMax) automatically fall back to `json_object` with schema instructions injected into system prompt
- **Provider model config**: `providers` dict now accepts `{"provider": {"api_key": "...", "model": "..."}}` to override default model per provider
- **Tool call logging**: Debug-level logs for all tool calls and results (name, arguments, output)

## [0.1.0-beta.6] - 2026-03-26

### Added — Pipeline & Budget Control
- **Parallel chain branches**: `runtime.chain()` now accepts nested lists for parallel execution — `[ChainStep, [ChainStep, ChainStep], ChainStep]` runs the inner list concurrently with `asyncio.gather`
- **Per-run provider/model selection**: `runtime.run(provider="openai", model="gpt-4o")` overrides default provider/model for a single run. Also available on `runtime.stream()` and `ChainStep`
- **Budget scoping**: `async with runtime.budget_scope(max_cost_usd=0.50) as scoped:` isolates budget for a subset of runs
- **`on_parse_error` callback**: `runtime.run(response_format=MyModel, on_parse_error=fix_fn)` — fires on `json.JSONDecodeError` or `pydantic.ValidationError`, NOT on provider-level format rejection
- **`result.parsed` field**: `RunResult.parsed` holds the validated Pydantic model (separate from `result.output` for backward compatibility)
- **`Tool` class**: Non-decorator tool registration — `Tool(fn=my_func, when_to_use="...")` for when `@arcana.tool` is not practical

### Changed
- `ChainStep` now supports `provider`, `model`, and `on_parse_error` fields
- Tools and structured output coexist — agent uses tools during reasoning and returns structured output on the final turn
- `BudgetScope` exported from `arcana` package

## [0.1.0-beta.5] - 2026-03-25

### Fixed
- 8 user-reported issues: SDK `system` and `context` parameters, fallback chain logging, budget tracking across runs, `runtime.fallback_order` property, provider `get_fallback_chain()` method, Tool wrapper support in registry

### Added
- **`arcana.run(system=..., context=...)`**: System prompt and context injection available at SDK level
- **`runtime.budget_remaining_usd`** / **`runtime.tokens_used`**: Runtime-level cumulative budget tracking properties
- **Auto fallback chain**: Multiple providers automatically form a fallback chain based on registration order

## [0.1.0-beta.4] - 2026-03-24

### Fixed
- 14 mypy strict errors regressed after beta.3
- `ChatSession.send()` now uses `generate()` instead of `stream()` for reliable usage tracking
- CI lint errors (unused imports, import sorting, bare except)

### Added
- Automated PyPI publish workflow (CI)
- Integration verification tests for b7 features

## [0.1.0-beta.3] - 2026-03-24

### Added — LLM Capability Amplification
- **Parallel Tool Execution**: Multiple tool calls in a single turn now run concurrently via `asyncio.gather`, with order-preserving results and individual failure isolation
- **Prompt Caching**: Anthropic system prompt + tool schemas automatically tagged with `cache_control`; OpenAI `cached_tokens` tracked. Up to 90% input token savings on multi-turn runs
- **Thinking-Informed Assessment**: `_assess_turn` now analyzes extended thinking blocks for uncertainty, verification intent, and incomplete information signals. Adjusts confidence and completion accordingly
- **Structured Output**: `arcana.run(response_format=MyModel)` returns validated Pydantic instances. Provider-level `json_schema` mode for OpenAI-compatible APIs
- **Multimodal Input**: `arcana.run(images=[...])` accepts URLs, file paths, and data URIs. OpenAI ↔ Anthropic content block format auto-conversion
- **LLM-Driven Context Compression**: `WorkingSetBuilder` can use a cheap LLM to produce semantic summaries instead of keyword-based truncation. Async `abuild_conversation_context()` with graceful fallback

### Added — Interactive Capabilities
- **`ask_user` Built-in Tool**: LLM can ask clarifying questions mid-execution. Intercepted at runtime level (bypasses ToolGateway). Sync/async `input_handler` callback. Graceful fallback when no handler provided
- **`runtime.chat()`**: Multi-turn conversational sessions with persistent history, shared budget, context compression, and streaming support. `ChatSession.send()` / `ChatSession.stream()`
- **CLI `arcana chat`**: Interactive terminal chat with Rich formatting, per-turn token/cost stats, budget enforcement
- **Examples 13-14**: Interactive chat and ask_user demonstrations

### Changed — Constitution v2
- **Principle 2** expanded: context is modality-agnostic (text, images, structured data)
- **Principle 4** corollary: thinking is signal, not contract — runtime may listen but never constrain
- **Principle 8** added: agent autonomy in collaboration — framework provides coordination, never hierarchy
- **Chapter IV** expanded: User role defined (intent, information, judgment). Two new inviolable rules: user never forced to interact; LLM asks but never blocks
- **Contributor Compact**: Questions 8-9 added (agent autonomy, user optionality)

### Added — Documentation
- `docs/guide/quickstart.md` — Installation → Deployment guide
- `docs/guide/configuration.md` — Full configuration reference (16 sections)
- `docs/guide/providers.md` — 8 provider setup guides with fallback chains
- `docs/guide/api.md` — Public API reference (881 lines)

### Stats
- Tests: 878 → 1045 (+167 new tests)
- All 1045 tests passing, 0 failures
- 9 new features, 4 documentation files

## [0.1.0-beta.1] - 2026-03-18

### Added
- **Runtime + Session**: Long-lived resource container, create once use everywhere
- **Runtime.team()**: Multi-agent collaboration (constitutional — Runtime provides comm, agents decide strategy)
- **Runtime.stream()**: Async generator for streaming
- **Runtime.graph()**: StateGraph factory
- **Memory v2**: Relevance-based retrieval (keyword + recency + importance + token budget)
- **MCP Client**: stdio transport, MCPToolProvider → ToolGateway bridge
- **CLI**: `arcana run/trace/providers/version`
- **ConversationAgent (V2)**: TurnFacts/TurnAssessment separation, 51% token savings
- **108 new tests**: All user-facing modules now covered (713 total)
- **Actionable error messages**: 8 files improved
- **Intent Router**: Default on in ConversationAgent
- **Diagnostic Recovery**: Structured diagnosis in V2

### Changed
- `arcana.run()` delegates to Runtime, accepts `api_key` param
- Default engine is V2 ConversationAgent
- Hardcoded model IDs removed — user explicit > provider default > error
- README → "Agent Runtime for Production"

### Fixed
- AdaptivePolicy execution closure
- Memory injection through direct_answer fast path
- Tool results use native OpenAI format
- single_tool argument generation

## [0.1.0-alpha.2] - 2026-03-18

### Changed
- `arcana.run()` now accepts `api_key` parameter — no .env file needed
- Default engine switched to ConversationAgent (V2)
- `max_steps` renamed to `max_turns` in `arcana.run()`
- `engine="conversation"` (default) or `engine="adaptive"` (V1)

### Fixed
- SDK no longer forces environment variables for API keys
- OpenAI and Anthropic providers now work in `arcana.run()`
- Clear error message when no API key provided

## [0.1.0-alpha.1] - 2026-03-18

### Added

#### V2 Execution Engine
- **ConversationAgent**: LLM-native execution model with TurnFacts/TurnAssessment separation
- **TurnFacts**: Raw provider output, zero interpretation
- **TurnAssessment**: Runtime completion/failure judgment, separate from facts
- 13-step turn contract with 7 invariants
- Streaming via `ConversationAgent.astream()`

#### V2 Architecture
- **CONSTITUTION.md**: 7 design principles, 4 prohibitions
- **Intent Router**: Rule-based + LLM + Hybrid classifiers, 4 execution paths
- **Adaptive Policy**: 6 strategy types (direct_answer, single_tool, sequential, parallel, plan_and_execute, pivot)
- **Lazy Tool Loading**: Keyword-based tool selection, affordance fields on ToolSpec
- **Diagnostic Recovery**: 7 error categories, structured feedback, RecoveryTracker
- **Multi-Model Routing**: 5 model roles, complexity-based selection
- **Working Set Builder**: 4-layer context management (identity/task/working/external)

#### Provider Infrastructure
- **BaseProvider Protocol**: Replaces ABC, maps to Rust trait
- **AnthropicProvider**: Native Claude support with extended thinking
- **Chinese Providers**: Kimi (Moonshot), GLM (Zhipu), MiniMax factory functions
- **Capability Registry**: 22 capabilities across 8 providers
- **Error Hierarchy**: RateLimitError, AuthenticationError, ModelNotFoundError, ContentFilterError, ContextLengthError
- **StreamChunk**: Unified streaming data model

#### SDK
- `arcana.run()`: Zero-config entry point
- `@arcana.tool`: Decorator with affordance fields (when_to_use, what_to_expect, failure_meaning)
- `RunResult`: Structured result with output, steps, tokens, cost
- Budget tracking wired into SDK

#### Evaluation
- EvalMetrics: first_attempt_success, goal_achievement_rate, cost_per_success
- RuleJudge + LLMJudge + HybridJudge
- EvalRunnerV2 with suite reporting

#### Code Quality
- 605 tests, 0 failures
- Verified with real APIs: DeepSeek, OpenAI (gpt-4o-mini), Anthropic (claude-sonnet-4)
- AgentState immutable pattern
- ToolProvider ABC → Protocol
- asyncio.Lock replaces threading.Lock

### V1 (Preserved)
- Agent + AdaptivePolicy + StepExecutor + Reducer pipeline
- ReAct and PlanExecute policies
- Graph engine (StateGraph, CompiledGraph)
- Multi-agent orchestration (TeamOrchestrator)
- JSONL Trace system
- Budget tracking
- Checkpoint/Resume
