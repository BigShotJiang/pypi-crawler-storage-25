# pathutilx

[![GitHub license](https://img.shields.io/github/license/tutu-firmino/pathutilx)](https://github.com/tutu-firmino/pathutilx/blob/master/LICENSE)
[![PyPI version](https://badge.fury.io/py/pathutilx.svg)](https://badge.fury.io/py/pathutilx)
[![Python Versions](https://img.shields.io/pypi/pyversions/pathutilx.svg)](https://pypi.org/project/pathutilx/)
[![Downloads](https://img.shields.io/pypi/dm/pathutilx.svg)](https://pypistats.org/packages/pathutilx)
![Windows](https://img.shields.io/badge/Windows-stable-brightgreen)
![Linux](https://img.shields.io/badge/Linux-stable-brightgreen)
![macOS](https://img.shields.io/badge/macOS-stable-brightgreen)

A lightweight, cross-platform Python library for readable filesystem path helpers, inspired by `pathlib` and `os.path`. It exposes common user and system directories, path inspection helpers, filtered filesystem search, and a small CLI for day-to-day path lookups.

View it on [GitHub]!(https://github.com/tutu-firmino/pathutilx)

## What's New in 1.4.0

- Added first-class Linux and macOS root helpers alongside the Windows API.
- Added filtered search helpers with extension, substring, hidden-file, size, date, and case-sensitive matching.
- Added `walk(...)`, `find_one(...)`, `glob(...)`, and richer `describe(...)` output for quick filesystem inspection.
- Expanded the CLI with `info --json` and advanced `search` flags for scripted usage.
- Fixed path building when `base` points to a file and kept `cwd` dynamic so it follows `os.chdir()`.
- Optimized recursive search by using a fast `os.scandir()` traversal path for filtered queries.

## Quick Start

```bash
pip install pathutilx
```
Just a quick example. See more at my [documentation file](https://github.com/tutu-firmino/pathutilx/blob/master/DOCUMENTATION.md).

```python
import pathutilx as p

# Common paths
print(p.desktop)
print(p.documents / "notes.txt")

# Build paths
notes = p.build("notes.txt", base=p.desktop)

# List and search
print(p.listdir(p.documents))
print(p.search("*.py", p.desktop, recursive=True))

# Filtered search
print(p.search("*.log", p.home, extensions="log", min_size=1024))
print(p.find_one("*.json", p.appdata, name_contains="settings"))

# Metadata
print(p.describe(p.downloads))
```

## Features

- Common paths: `desktop`, `downloads`, `documents`, `appdata`, `home`, `temp`, `tmp`, `cwd`, and more.
- Cross-platform roots: `platform_root()`, `win_root()`, `windows_root()`, `linux_root()`, `mac_root()`.
- Path building: `build(*parts, base=None)` and `join(*parts, base=None)` with env-var and `~` expansion.
- Directory helpers: `listdir(...)`, `walk(...)`, `search(...)`, `glob(...)`, and `find_one(...)`.
- Search filters: `extensions`, `name_contains`, `include_files`, `include_dirs`, `hidden`, `min_size`, `max_size`, `newer_than`, `older_than`, and `case_sensitive`.
- Path checks: `exists(...)`, `is_file(...)`, `is_dir(...)`, `resolve_path(...)`, `parent_path(...)`, and `describe(...)`.
- `PathNode`: callable nodes, `/` path joining, and convenient `.exists()`, `.is_file()`, `.is_dir()`, `.parent`, and `.name` access.
- CLI: `pathutilx list`, `pathutilx resolve`, `pathutilx info`, and `pathutilx search`.

## Usage

You can see the documentation by clicking [here](https://github.com/tutu-firmino/pathutilx/blob/master/DOCUMENTATION.md).

## Installation and Build

```bash
pip install pathutilx
```

```bash
pip install build twine
python -m build
twine check dist/*
```

## License

[MPL-2.0](https://github.com/tutu-firmino/pathutilx/blob/master/LICENSE)