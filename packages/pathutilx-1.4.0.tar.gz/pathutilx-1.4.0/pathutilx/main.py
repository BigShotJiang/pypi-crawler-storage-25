from __future__ import annotations

import argparse
import fnmatch
import json
import os
from collections import deque
from datetime import datetime
from pathlib import Path
from typing import Iterable

from .finder import (
    CwdPathNode,
    PathNode,
    build_path,
    linux_root,
    listdir as _listdir,
    mac_root,
    parent_path as _parent_path,
    platform_root,
    resolve_path as _resolve_path,
    win_root,
    windows_root as _windows_root,
)


PathLike = str | os.PathLike[str] | PathNode

_platform = platform_root()


def _node_attr(name: str, fallback: PathLike) -> PathNode:
    value = getattr(_platform, name, None)
    if isinstance(value, PathNode):
        return value
    return PathNode(_coerce_path(fallback) or Path.cwd())


home = _node_attr("home", Path.home())
appdata = _node_attr("appdata", home.path / ".config")
cwd = _node_attr("cwd", Path.cwd())
contacts = _node_attr("contacts", home.path / "Contacts")
desktop = _node_attr("desktop", home.path / "Desktop")
documents = _node_attr("documents", home.path / "Documents")
downloads = _node_attr("downloads", home.path / "Downloads")
favorites = _node_attr("favorites", home.path)
links = _node_attr("links", home.path / "Links")
music = _node_attr("music", home.path / "Music")
pictures = _node_attr("pictures", home.path / "Pictures")
program_files = _node_attr("program_files", Path("/usr/local"))
program_files_x86 = _node_attr("program_files_x86", Path("/usr/local"))
program_data = _node_attr("program_data", Path("/var/lib"))
public = _node_attr("public", Path("/Users/Public") if os.name == "nt" else home.path / "Public")
saved_games = _node_attr("saved_games", home.path / "Saved Games")
system32 = _node_attr("system32", Path(os.environ.get("WINDIR", r"C:\Windows")) / "System32")
system_drive = _node_attr("system_drive", Path(os.environ.get("SystemDrive", "/")))
temp = _node_attr("temp", Path(os.environ.get("TMPDIR", Path.cwd())))
tmp = _node_attr("tmp", temp.path)
user_profile = _node_attr("user_profile", home.path)
videos = _node_attr("videos", home.path / "Videos")
windows_dir = _node_attr("windows_dir", Path(os.environ.get("WINDIR", r"C:\Windows")))


def _coerce_path(value: PathLike | None) -> Path | None:
    if value is None:
        return None
    if isinstance(value, PathNode):
        return value.path
    return Path(value)


def _normalize_patterns(pattern: str | Iterable[str]) -> list[str]:
    patterns = [pattern] if isinstance(pattern, str) else [str(item) for item in pattern]
    return patterns or ["*"]


def _normalize_strings(value: str | Iterable[str] | None, *, lower: bool) -> tuple[str, ...]:
    if value is None:
        return ()
    items = [value] if isinstance(value, str) else [str(item) for item in value]
    if lower:
        return tuple(item.lower() for item in items)
    return tuple(items)


def _normalize_extensions(value: str | Iterable[str] | None, *, lower: bool) -> tuple[str, ...]:
    normalized: list[str] = []
    for item in _normalize_strings(value, lower=lower):
        normalized.append(item if item.startswith(".") else f".{item}")
    return tuple(normalized)


def _normalize_datetime(value: datetime | str | int | float | None) -> float | None:
    if value is None:
        return None
    if isinstance(value, datetime):
        return value.timestamp()
    if isinstance(value, (int, float)):
        return float(value)
    return datetime.fromisoformat(value).timestamp()


def _is_hidden(entry: os.DirEntry[str]) -> bool:
    if entry.name.startswith("."):
        return True
    if os.name != "nt":
        return False
    try:
        attributes = entry.stat(follow_symlinks=False).st_file_attributes
    except (AttributeError, FileNotFoundError, OSError):
        return False
    return bool(attributes & 2)


def _iter_entries(root: Path, recursive: bool) -> Iterable[os.DirEntry[str]]:
    if not recursive:
        with os.scandir(root) as iterator:
            yield from iterator
        return

    pending = deque([os.fspath(root)])
    while pending:
        current = pending.pop()
        try:
            with os.scandir(current) as iterator:
                for entry in iterator:
                    yield entry
                    try:
                        if entry.is_dir(follow_symlinks=False):
                            pending.append(entry.path)
                    except OSError:
                        continue
        except OSError:
            continue


def _matches_name(name: str, patterns: tuple[str, ...], *, case_sensitive: bool) -> bool:
    if case_sensitive:
        return any(fnmatch.fnmatchcase(name, pattern) for pattern in patterns)
    lowered = name.lower()
    return any(fnmatch.fnmatch(lowered, pattern.lower()) for pattern in patterns)


def build(*parts, base=None):
    return build_path(*parts, base=base)


def join(*parts, base=None):
    return build(*parts, base=base)


def listdir(*parts, base=None):
    return _listdir(*parts, base=base)


def walk(*parts, base=None, recursive=True):
    root = build(*parts, base=base)
    if not root.exists():
        raise FileNotFoundError(root)
    if not root.is_dir():
        raise NotADirectoryError(root)
    return [Path(entry.path) for entry in _iter_entries(root, recursive=recursive)]


def search(
    pattern,
    *parts,
    base=None,
    recursive=True,
    include_files=True,
    include_dirs=True,
    hidden=None,
    extensions=None,
    name_contains=None,
    min_size=None,
    max_size=None,
    newer_than=None,
    older_than=None,
    case_sensitive=False,
):
    root = build(*parts, base=base)
    if not root.exists():
        raise FileNotFoundError(root)
    if not root.is_dir():
        raise NotADirectoryError(root)

    if not any((include_files, include_dirs)):
        return []

    patterns = tuple(_normalize_patterns(pattern))
    contains_filters = _normalize_strings(name_contains, lower=not case_sensitive)
    extension_filters = _normalize_extensions(extensions, lower=not case_sensitive)
    newer_than_ts = _normalize_datetime(newer_than)
    older_than_ts = _normalize_datetime(older_than)

    matches: list[Path] = []
    for entry in _iter_entries(root, recursive=recursive):
        try:
            is_dir = entry.is_dir(follow_symlinks=False)
            is_file = entry.is_file(follow_symlinks=False)
        except OSError:
            continue

        if is_dir and not include_dirs:
            continue
        if is_file and not include_files:
            continue
        if not is_dir and not is_file:
            continue
        if hidden is not None and _is_hidden(entry) is not hidden:
            continue
        if not _matches_name(entry.name, patterns, case_sensitive=case_sensitive):
            continue

        candidate_name = entry.name if case_sensitive else entry.name.lower()
        if contains_filters and not all(token in candidate_name for token in contains_filters):
            continue

        suffix = Path(entry.name).suffix if case_sensitive else Path(entry.name).suffix.lower()
        if extension_filters and suffix not in extension_filters:
            continue

        if min_size is not None or max_size is not None or newer_than_ts is not None or older_than_ts is not None:
            try:
                stat = entry.stat(follow_symlinks=False)
            except OSError:
                continue
            if min_size is not None and stat.st_size < min_size:
                continue
            if max_size is not None and stat.st_size > max_size:
                continue
            if newer_than_ts is not None and stat.st_mtime < newer_than_ts:
                continue
            if older_than_ts is not None and stat.st_mtime > older_than_ts:
                continue

        matches.append(Path(entry.path))

    return sorted(matches, key=lambda item: (str(item.parent).lower(), item.name.lower()))


def glob(pattern, *parts, base=None, recursive=True):
    return search(pattern, *parts, base=base, recursive=recursive)


def find_one(pattern, *parts, base=None, recursive=True, **filters):
    matches = search(pattern, *parts, base=base, recursive=recursive, **filters)
    return matches[0] if matches else None


def exists(value):
    return resolve_path(value).exists()


def is_file(value):
    return resolve_path(value).is_file()


def is_dir(value):
    return resolve_path(value).is_dir()


def resolve_path(value):
    return _resolve_path(value)


def parent_path(value):
    return _parent_path(value)


def describe(value):
    path = resolve_path(value)
    info = {
        "path": str(path),
        "name": path.name,
        "exists": path.exists(),
        "is_file": path.is_file(),
        "is_dir": path.is_dir(),
        "parent": str(path.parent),
    }
    if info["exists"]:
        stat = path.stat()
        info["size"] = stat.st_size
        info["modified"] = datetime.fromtimestamp(stat.st_mtime).isoformat()
    return info


def resolve(name, base, source=None):
    if callable(base) and not isinstance(base, PathNode):
        raise ValueError("resolve() only accepts a resolved base path, not a callable")
    return build(name, base=base)


def windows_root():
    return _windows_root()


def _parse_cli_datetime(value: str | None) -> str | None:
    if value is None:
        return None
    datetime.fromisoformat(value)
    return value


def _stringify_paths(paths: Iterable[Path]) -> list[str]:
    return [str(path) for path in paths]


def cli(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="pathutilx", description="Path helpers and filtered filesystem search.")
    subparsers = parser.add_subparsers(dest="command", required=True)

    list_parser = subparsers.add_parser("list", help="List directory contents.")
    list_parser.add_argument("path", nargs="?", default=".")

    resolve_parser = subparsers.add_parser("resolve", help="Resolve a path to an absolute path.")
    resolve_parser.add_argument("path")

    info_parser = subparsers.add_parser("info", help="Show metadata for a file or directory.")
    info_parser.add_argument("path")
    info_parser.add_argument("--json", action="store_true", dest="as_json")

    search_parser = subparsers.add_parser("search", help="Search for files and directories.")
    search_parser.add_argument("pattern")
    search_parser.add_argument("path", nargs="?", default=".")
    search_parser.add_argument("--non-recursive", action="store_true")
    search_parser.add_argument("--files-only", action="store_true")
    search_parser.add_argument("--dirs-only", action="store_true")
    search_parser.add_argument("--hidden", action="store_true")
    search_parser.add_argument("--extension", action="append", dest="extensions")
    search_parser.add_argument("--contains", action="append", dest="contains")
    search_parser.add_argument("--min-size", type=int)
    search_parser.add_argument("--max-size", type=int)
    search_parser.add_argument("--newer-than", type=_parse_cli_datetime)
    search_parser.add_argument("--older-than", type=_parse_cli_datetime)
    search_parser.add_argument("--case-sensitive", action="store_true")
    search_parser.add_argument("--json", action="store_true", dest="as_json")

    args = parser.parse_args(argv)

    if args.command == "list":
        for item in listdir(args.path):
            print(item)
        return 0

    if args.command == "resolve":
        print(resolve_path(args.path))
        return 0

    if args.command == "info":
        payload = describe(args.path)
        if args.as_json:
            print(json.dumps(payload, indent=2, sort_keys=True))
        else:
            for key, value in payload.items():
                print(f"{key}: {value}")
        return 0

    include_files = not args.dirs_only
    include_dirs = not args.files_only
    if not include_files and not include_dirs:
        parser.error("--files-only and --dirs-only cannot be used together")

    results = search(
        args.pattern,
        args.path,
        recursive=not args.non_recursive,
        include_files=include_files,
        include_dirs=include_dirs,
        hidden=True if args.hidden else None,
        extensions=args.extensions,
        name_contains=args.contains,
        min_size=args.min_size,
        max_size=args.max_size,
        newer_than=args.newer_than,
        older_than=args.older_than,
        case_sensitive=args.case_sensitive,
    )
    if args.as_json:
        print(json.dumps(_stringify_paths(results), indent=2))
    else:
        for item in results:
            print(item)
    return 0


def main(argv: list[str] | None = None) -> int:
    return cli(argv)


__all__ = [
    "PathNode",
    "CwdPathNode",
    "appdata",
    "build",
    "cli",
    "cwd",
    "contacts",
    "describe",
    "desktop",
    "documents",
    "downloads",
    "exists",
    "favorites",
    "find_one",
    "glob",
    "home",
    "is_dir",
    "is_file",
    "join",
    "links",
    "listdir",
    "linux_root",
    "mac_root",
    "main",
    "music",
    "parent_path",
    "pictures",
    "platform_root",
    "program_data",
    "program_files",
    "program_files_x86",
    "public",
    "resolve",
    "resolve_path",
    "saved_games",
    "search",
    "system32",
    "system_drive",
    "temp",
    "tmp",
    "user_profile",
    "videos",
    "walk",
    "windows_dir",
    "windows_root",
    "win_root",
]
