from __future__ import annotations
import fnmatch
import os
from pathlib import Path
from typing import Iterable, cast
import sys


PathLike = str | os.PathLike[str]


def _as_path(value: PathLike | "PathNode") -> Path:
    if isinstance(value, PathNode):
        return value.path
    return Path(value)


def _normalize_part(part: PathLike | "PathNode") -> Path:
    raw = os.fspath(_as_path(part))
    expanded = os.path.expandvars(os.path.expanduser(raw))
    return Path(expanded)


def build_path(
    *parts: PathLike | "PathNode",
    base: PathLike | "PathNode" | None = None,
) -> Path:
    if base is None and not parts:
        raise ValueError("build_path requires at least one path part or a base path")

    if base is not None:
        base_path = _normalize_part(base)
        if base_path.exists() and base_path.is_file():
            base_path = base_path.parent
        elif not base_path.exists() and base_path.suffix:
            base_path = base_path.parent
        path = base_path
    else:
        path = _normalize_part(parts[0])
    remaining_parts: Iterable[PathLike | PathNode] = parts if base is not None else parts[1:]

    for part in remaining_parts:
        path = path / _normalize_part(part)

    return path


def resolve_path(value: PathLike | "PathNode") -> Path:
    """Resolve a path-like value to an absolute path."""
    return _normalize_part(value).resolve()


def parent_path(value: PathLike | "PathNode") -> Path:
    """Return the parent directory of a path-like value."""
    return _normalize_part(value).parent


def listdir(
    *parts: PathLike | "PathNode",
    base: PathLike | "PathNode" | None = None,
) -> list[Path]:
    """List files and folders in a specified directory."""
    path = build_path(*parts, base=base)
    if not path.exists():
        raise FileNotFoundError(path)
    if not path.is_dir():
        raise NotADirectoryError(path)
    return sorted(path.iterdir(), key=lambda item: item.name.lower())


def search(
    pattern: str | Iterable[str],
    *parts: PathLike | "PathNode",
    base: PathLike | "PathNode" | None = None,
    recursive: bool = True,
) -> list[Path]:
    """Search for files and folders by name pattern in a specified directory."""
    path = build_path(*parts, base=base)
    if not path.exists():
        raise FileNotFoundError(path)
    if not path.is_dir():
        raise NotADirectoryError(path)

    patterns = [pattern] if isinstance(pattern, str) else [str(p) for p in pattern]
    matches: list[Path] = []
    iterator = path.rglob("*") if recursive else path.iterdir()

    for item in iterator:
        lowered_name = item.name.lower()
        if any(fnmatch.fnmatchcase(lowered_name, pat.lower()) for pat in patterns):
            matches.append(item)

    return sorted(matches, key=lambda item: (str(item.parent).lower(), item.name.lower()))


class PathNode:
    def __init__(self, path: PathLike, **children: "PathNode") -> None:
        self._path = _normalize_part(path)
        for name, child in children.items():
            setattr(self, name, child)

    @property
    def path(self) -> Path:
        return self._path

    @property
    def name(self) -> str:
        return self._path.name

    @property
    def parent(self) -> Path:
        return self._path.parent

    def build(self, *parts: PathLike | "PathNode") -> Path:
        return build_path(*parts, base=self)

    def joinpath(self, *parts: PathLike | "PathNode") -> Path:
        return self.build(*parts)

    def exists(self) -> bool:
        return self._path.exists()

    def is_dir(self) -> bool:
        return self._path.is_dir()

    def is_file(self) -> bool:
        return self._path.is_file()

    def __call__(self, *parts: PathLike | "PathNode") -> Path:
        return self.build(*parts)

    def __truediv__(self, other: PathLike | "PathNode") -> Path:
        return self._path / _normalize_part(other)

    def __fspath__(self) -> str:
        return os.fspath(self._path)

    def __str__(self) -> str:
        return str(self._path)

    def __repr__(self) -> str:
        return f"PathNode({self._path!s})"


class CwdPathNode(PathNode):
    @property
    def path(self) -> Path:
        return Path.cwd()


def _env_path(name: str, fallback: PathLike) -> Path:
    value = os.environ.get(name)
    if value:
        return Path(value)
    return _normalize_part(fallback)


from .linux import linux_root
from .macos import mac_root
from .windows import (
    win_root,
    windows_root,
)


def platform_root() -> PathNode:
    platform = cast(str, sys.platform)
    if platform == "win32":
        return win_root()
    if platform == "darwin":
        return mac_root()
    if platform == "linux":
        return linux_root()
    raise NotImplementedError(f"Unsupported platform: {platform}")


__all__ = [
    "PathNode",
    "CwdPathNode",
    "build_path",
    "platform_root",
    "win_root",
    "linux_root",
    "mac_root",
    "windows_root",
    "listdir",
    "search",
    "resolve_path",
    "parent_path",
]
