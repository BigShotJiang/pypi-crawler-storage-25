from __future__ import annotations
import tempfile
from pathlib import Path
from . import PathNode, CwdPathNode
from .windows import _env_path


def linux_root() -> PathNode:
    home = Path.home()
    cwd = Path.cwd()
    xdg_config = _env_path("XDG_CONFIG_HOME", home / ".config")
    xdg_data = _env_path("XDG_DATA_HOME", home / ".local" / "share")
    xdg_cache = _env_path("XDG_CACHE_HOME", home / ".cache")
    xdg_state = _env_path("XDG_STATE_HOME", home / ".local" / "state")
    desktop = home / "Desktop"
    documents = home / "Documents"
    downloads = home / "Downloads"
    pictures = home / "Pictures"
    videos = home / "Videos"
    music = home / "Music"
    templates = home / "Templates"
    temp = Path(tempfile.gettempdir())
    tmp = temp
    public = home / "Public"

    return PathNode(
        Path("/"),
        appdata=PathNode(
            xdg_config,
            config=PathNode(xdg_config),
            data=PathNode(xdg_data),
            cache=PathNode(xdg_cache),
        ),
        cache=PathNode(xdg_cache),
        config=PathNode(xdg_config),
        data=PathNode(xdg_data),
        contacts=PathNode(home),
        desktop=PathNode(desktop),
        documents=PathNode(documents),
        downloads=PathNode(downloads),
        favorites=PathNode(home),
        home=PathNode(home),
        cwd=CwdPathNode(cwd),
        links=PathNode(home),
        music=PathNode(music),
        pictures=PathNode(pictures),
        program_data=PathNode(xdg_state),
        program_files=PathNode(Path("/usr/local")),
        program_files_x86=PathNode(Path("/usr/local")),
        public=PathNode(public),
        saved_games=PathNode(home / ".local" / "share" / "games"),
        system_drive=PathNode(Path("/")),
        temp=PathNode(temp),
        tmp=PathNode(tmp),
        templates=PathNode(templates),
        user_profile=PathNode(home),
        videos=PathNode(videos),
        windows_dir=PathNode(Path("/")),
    )
