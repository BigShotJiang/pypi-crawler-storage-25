from __future__ import annotations
from . import CwdPathNode, PathNode
import os
from pathlib import Path


PathLike = str | os.PathLike[str]


def _as_path(value: PathLike | "PathNode") -> Path:
    if isinstance(value, PathNode):
        return value.path
    return Path(value)


def _normalize_part(part: PathLike | "PathNode") -> Path:
    raw = os.fspath(_as_path(part))
    expanded = os.path.expandvars(os.path.expanduser(raw))
    return Path(expanded)


def _env_path(name: str, fallback: PathLike) -> Path:
    value = os.environ.get(name)
    if value:
        return Path(value)
    return _normalize_part(fallback)


def win_root() -> PathNode:
    home = _env_path("USERPROFILE", Path.home())
    cwd = Path.cwd()
    appdata_roaming = _env_path("APPDATA", home / "AppData" / "Roaming")
    appdata_local = _env_path("LOCALAPPDATA", home / "AppData" / "Local")
    appdata_local_low = appdata_local.parent / "LocalLow"
    desktop = home / "Desktop"
    documents = home / "Documents"
    downloads = home / "Downloads"
    pictures = home / "Pictures"
    videos = home / "Videos"
    music = home / "Music"
    favorites = home / "Favorites"
    saved_games = home / "Saved Games"
    contacts = home / "Contacts"
    links = home / "Links"

    system_drive = _env_path("SystemDrive", r"C:")
    windows_dir = _env_path("WINDIR", system_drive / "Windows")
    system32 = windows_dir / "System32"
    temp = _env_path("TEMP", appdata_local / "Temp")
    tmp = _env_path("TMP", temp)
    program_files = _env_path("ProgramFiles", r"C:\Program Files")
    program_files_x86 = _env_path("ProgramFiles(x86)", r"C:\Program Files (x86)")
    program_data = _env_path("ProgramData", r"C:\ProgramData")
    public = _env_path("PUBLIC", system_drive / "Users" / "Public")
    onedrive = _env_path("OneDrive", home / "OneDrive")
    startup = appdata_roaming / "Microsoft" / "Windows" / "Start Menu" / "Programs" / "Startup"
    recent = appdata_roaming / "Microsoft" / "Windows" / "Recent"
    send_to = appdata_roaming / "Microsoft" / "Windows" / "SendTo"

    return PathNode(
        system_drive,
        appdata=PathNode(
            appdata_roaming,
            roaming=PathNode(appdata_roaming),
            local=PathNode(appdata_local),
            local_low=PathNode(appdata_local_low),
        ),
        contacts=PathNode(contacts),
        desktop=PathNode(desktop),
        documents=PathNode(documents),
        downloads=PathNode(downloads),
        favorites=PathNode(favorites),
        home=PathNode(home),
        cwd=CwdPathNode(cwd),
        links=PathNode(links),
        music=PathNode(music),
        pictures=PathNode(pictures),
        program_data=PathNode(program_data),
        program_files=PathNode(program_files),
        program_files_x86=PathNode(program_files_x86),
        public=PathNode(public),
        saved_games=PathNode(saved_games),
        send_to=PathNode(send_to),
        system32=PathNode(system32),
        system_drive=PathNode(system_drive),
        startup=PathNode(startup),
        temp=PathNode(temp),
        tmp=PathNode(tmp),
        user_profile=PathNode(home),
        videos=PathNode(videos),
        windows_dir=PathNode(windows_dir),
        windows_root=PathNode(system_drive),
        onedrive=PathNode(onedrive),
        recent=PathNode(recent),
    )


# backwards compatibility
windows_root = win_root

