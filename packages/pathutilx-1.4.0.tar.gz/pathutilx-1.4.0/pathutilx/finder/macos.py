from __future__ import annotations
import tempfile
from pathlib import Path
from . import PathNode, CwdPathNode
from .windows import _env_path


def mac_root() -> PathNode:
    home = Path.home()
    cwd = Path.cwd()
    app_support = _env_path("XDG_CONFIG_HOME", home / "Library" / "Application Support")
    cache = _env_path("XDG_CACHE_HOME", home / "Library" / "Caches")
    data = _env_path("XDG_DATA_HOME", home / "Library" / "Application Support")
    state = home / "Library" / "Application Support"
    desktop = home / "Desktop"
    documents = home / "Documents"
    downloads = home / "Downloads"
    pictures = home / "Pictures"
    videos = home / "Movies"
    music = home / "Music"
    templates = home / "Templates"
    temp = Path(tempfile.gettempdir())
    tmp = temp
    public = Path("/Users/Shared")

    return PathNode(
        Path("/"),
        appdata=PathNode(
            app_support,
            config=PathNode(app_support),
            data=PathNode(data),
            cache=PathNode(cache),
        ),
        cache=PathNode(cache),
        config=PathNode(app_support),
        data=PathNode(data),
        contacts=PathNode(home),
        desktop=PathNode(desktop),
        documents=PathNode(documents),
        downloads=PathNode(downloads),
        favorites=PathNode(home),
        home=PathNode(home),
        cwd=CwdPathNode(cwd),
        links=PathNode(home),
        music=PathNode(music),
        pictures=PathNode(pictures),
        program_data=PathNode(state),
        program_files=PathNode(Path("/Applications")),
        program_files_x86=PathNode(Path("/Applications")),
        public=PathNode(public),
        saved_games=PathNode(home / "Library" / "Application Support"),
        system_drive=PathNode(Path("/")),
        temp=PathNode(temp),
        tmp=PathNode(tmp),
        templates=PathNode(templates),
        user_profile=PathNode(home),
        videos=PathNode(videos),
        windows_dir=PathNode(Path("/")),
    )
