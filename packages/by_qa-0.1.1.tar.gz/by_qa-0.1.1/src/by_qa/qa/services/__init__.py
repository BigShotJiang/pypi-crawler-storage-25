"""QA-scoped service helpers."""
