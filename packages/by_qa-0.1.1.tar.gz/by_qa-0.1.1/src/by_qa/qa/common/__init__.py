"""Shared QA utilities."""
