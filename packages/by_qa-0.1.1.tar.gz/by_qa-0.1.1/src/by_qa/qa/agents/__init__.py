"""QA-scoped agent helpers."""
