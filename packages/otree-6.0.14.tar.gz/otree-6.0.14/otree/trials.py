# Copyright 2022 Christopher Wickens. All rights reserved.

from sqlalchemy import Column, ForeignKey
from sqlalchemy.ext.declarative import declared_attr
from sqlalchemy.orm import relationship
from sqlalchemy.sql import sqltypes as st

from otree.database import ExtraModel


class BaseTrial(ExtraModel):
    __abstract__ = True

    queue_position = Column(st.Integer)
    page_name = Column(st.String)

    @declared_attr
    def player_id(cls):
        app_name = cls.get_folder_name()
        return Column(st.Integer, ForeignKey(f'{app_name}_player.id'), nullable=True)

    @declared_attr
    def player(cls):
        return relationship(f'{cls.__module__}.Player')

    @classmethod
    def create(cls, **kwargs):
        return super().create(**kwargs)


async def trial_payload_function(participant_code, page_name, msg):
    pass


def encode_trial(trial, fields):
    return {}


def get_all_trials(Trial, player, page_name: str):
    return []


def get_current_trial(Trial, player, page_name):
    return None
