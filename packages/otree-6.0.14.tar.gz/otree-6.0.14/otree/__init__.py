__version__ = '6.0.14'
# don't import anything else here because setup.py imports this.
