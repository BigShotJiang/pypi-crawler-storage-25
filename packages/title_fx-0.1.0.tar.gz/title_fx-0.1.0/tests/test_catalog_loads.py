"""Tests for catalog loading and basic catalog structure."""

from __future__ import annotations

from title_fx import list_titles
from title_fx.styles.loader import load_catalog


def test_catalog_loads_59_effects():
    catalog = load_catalog()
    assert catalog["transition_count"] == 59


def test_44_active_15_deferred():
    active = list_titles()
    all_titles = list_titles(include_deferred=True)
    assert len(active) == 44
    assert len(all_titles) == 59


def test_unique_slugs():
    all_titles = list_titles(include_deferred=True)
    assert len(all_titles) == len(set(all_titles)), "Duplicate slugs found in catalog"


def test_three_categories():
    catalog = load_catalog()
    categories = catalog.get("categories", [])
    assert len(categories) == 3
