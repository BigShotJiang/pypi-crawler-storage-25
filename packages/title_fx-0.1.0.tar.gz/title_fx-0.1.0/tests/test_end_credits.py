"""Tests for the end_credits API."""

from __future__ import annotations

import yaml

from title_fx import end_credits


def test_end_credits_from_yaml_string(sample_crew_yaml, tmp_path):
    """Parse the YAML string and pass the resulting dict to end_credits."""
    crew_dict = yaml.safe_load(sample_crew_yaml)
    out = tmp_path / "credits_dict.mp4"
    result = end_credits(
        crew_data=crew_dict,
        duration=2.0,
        output=str(out),
    )
    assert result.exists(), f"Output file does not exist: {result}"
    assert result.stat().st_size > 0, "Output file is empty"


def test_end_credits_from_yaml_file(sample_crew_file, tmp_path):
    out = tmp_path / "credits_file.mp4"
    result = end_credits(
        crew_data=sample_crew_file,
        duration=2.0,
        output=str(out),
    )
    assert result.exists(), f"Output file does not exist: {result}"
    assert result.stat().st_size > 0, "Output file is empty"
