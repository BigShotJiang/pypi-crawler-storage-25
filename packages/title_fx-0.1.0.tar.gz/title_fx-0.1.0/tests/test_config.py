"""Tests for TitleConfig validation."""

from __future__ import annotations

import pytest
from pydantic import ValidationError

from title_fx.config import TitleConfig


def test_title_config_defaults():
    cfg = TitleConfig(style="trailer_gold_title")
    assert cfg.duration == 3.0
    assert cfg.position == "center"


def test_title_config_extra_raises():
    with pytest.raises(ValidationError):
        TitleConfig(style="trailer_gold_title", not_a_real_field="oops")


def test_title_config_position_invalid():
    with pytest.raises(ValidationError):
        TitleConfig(style="trailer_gold_title", position="invalid_position")
