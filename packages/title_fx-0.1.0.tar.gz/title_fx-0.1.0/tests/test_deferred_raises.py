"""Tests confirming deferred 3D styles raise NotImplementedError correctly."""

from __future__ import annotations

import pytest

from title_fx import apply_title, list_titles
from title_fx.styles.stub_3d import DEFERRED_3D_SLUGS

ACTIVE_SLUGS = set(list_titles(include_deferred=False))
DEFERRED_SLUGS = [s for s in list_titles(include_deferred=True) if s not in ACTIVE_SLUGS]


def test_15_deferred_slugs_known():
    assert len(DEFERRED_3D_SLUGS) == 15


@pytest.mark.parametrize("slug", DEFERRED_SLUGS)
def test_each_deferred_slug_raises_not_implemented(tiny_video, tmp_path, slug):
    out = tmp_path / f"{slug}_ignored.mp4"
    with pytest.raises(NotImplementedError):
        apply_title(
            video=str(tiny_video),
            text="X",
            style=slug,
            duration=1.0,
            output=str(out),
        )


@pytest.mark.parametrize("slug", DEFERRED_SLUGS)
def test_deferred_error_message_mentions_v02(tiny_video, tmp_path, slug):
    out = tmp_path / f"{slug}_v02.mp4"
    with pytest.raises(NotImplementedError) as exc_info:
        apply_title(
            video=str(tiny_video),
            text="X",
            style=slug,
            duration=1.0,
            output=str(out),
        )
    assert "v0.2" in str(exc_info.value)


@pytest.mark.parametrize("slug", DEFERRED_SLUGS)
def test_deferred_error_message_mentions_alternative(tiny_video, tmp_path, slug):
    out = tmp_path / f"{slug}_alt.mp4"
    with pytest.raises(NotImplementedError) as exc_info:
        apply_title(
            video=str(tiny_video),
            text="X",
            style=slug,
            duration=1.0,
            output=str(out),
        )
    msg = str(exc_info.value).lower()
    assert "try" in msg or "alternative" in msg, (
        f"Error for '{slug}' does not mention an alternative: {exc_info.value!r}"
    )
