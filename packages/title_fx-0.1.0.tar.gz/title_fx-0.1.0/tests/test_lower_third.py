"""Tests for the lower_third API."""

from __future__ import annotations

from title_fx import lower_third


def test_lower_third_produces_output(tiny_video, tmp_path):
    out = tmp_path / "lower_third.mp4"
    result = lower_third(
        video=str(tiny_video),
        name="Dr. Smith",
        title="Researcher",
        output=str(out),
    )
    assert result.exists(), f"Output file does not exist: {result}"
    assert result.stat().st_size > 0, "Output file is empty"


def test_lower_third_custom_style(tiny_video, tmp_path):
    out = tmp_path / "lower_third_news.mp4"
    result = lower_third(
        video=str(tiny_video),
        name="Jane Doe",
        title="Correspondent",
        style="news_headline_strap",
        duration=2.0,
        output=str(out),
    )
    assert result.exists(), f"Output file does not exist: {result}"
    assert result.stat().st_size > 0, "Output file is empty"
