"""Smoke tests for apply_title with representative active styles."""

from __future__ import annotations

from pathlib import Path

from title_fx import apply_title


def _assert_nonempty_video(path: Path) -> None:
    assert path.exists(), f"Output file does not exist: {path}"
    assert path.stat().st_size > 0, f"Output file is empty: {path}"


def test_apply_title_trailer_gold(tiny_video, tmp_path):
    out = tmp_path / "trailer_gold_title.mp4"
    result = apply_title(
        video=str(tiny_video),
        text="TITLE",
        style="trailer_gold_title",
        duration=1.0,
        output=str(out),
    )
    _assert_nonempty_video(result)


def test_apply_title_cinematic_fade_up(tiny_video, tmp_path):
    out = tmp_path / "cinematic_fade_up.mp4"
    result = apply_title(
        video=str(tiny_video),
        text="TITLE",
        style="cinematic_fade_up",
        duration=1.0,
        output=str(out),
    )
    _assert_nonempty_video(result)


def test_apply_title_dark_prestige(tiny_video, tmp_path):
    out = tmp_path / "dark_prestige_title.mp4"
    result = apply_title(
        video=str(tiny_video),
        text="TITLE",
        style="dark_prestige_title",
        duration=1.0,
        output=str(out),
    )
    _assert_nonempty_video(result)


def test_apply_title_stacked(tiny_video, tmp_path):
    out = tmp_path / "stacked_title.mp4"
    result = apply_title(
        video=str(tiny_video),
        text="TITLE",
        style="stacked_title",
        duration=1.0,
        output=str(out),
    )
    _assert_nonempty_video(result)


def test_apply_title_number_counter(tiny_video, tmp_path):
    out = tmp_path / "number_counter.mp4"
    result = apply_title(
        video=str(tiny_video),
        text="100",
        style="number_counter",
        duration=1.0,
        output=str(out),
    )
    _assert_nonempty_video(result)


def test_apply_title_output_default(tiny_video, tmp_path):
    """When output=None the returned path must exist (derived from input path)."""
    import shutil

    # copy tiny_video to tmp_path so the default output path also lands there
    src = tmp_path / "bg.mp4"
    shutil.copy(str(tiny_video), str(src))

    result = apply_title(
        video=str(src),
        text="TITLE",
        style="cinematic_fade_up",
        duration=1.0,
        output=None,
    )
    assert isinstance(result, Path)
    assert result.exists(), f"Default-output file does not exist: {result}"
