"""Tests for the crew YAML parser."""

from __future__ import annotations

import pytest

from title_fx.crew.parser import extract_roll_groups, parse_crew_string
from title_fx.exceptions import CrewParseError


def test_parse_crew_minimal(sample_crew_yaml):
    parsed = parse_crew_string(sample_crew_yaml)
    assert isinstance(parsed, dict)
    assert "roll_groups" in parsed


def test_parse_crew_with_cast_roles(sample_crew_yaml):
    parsed = parse_crew_string(sample_crew_yaml)
    groups = parsed["roll_groups"]
    # Find the CAST group
    cast_group = next((g for g in groups if g.get("heading") == "CAST"), None)
    assert cast_group is not None, "Expected a CAST roll_group"
    entries = cast_group["entries"]
    assert len(entries) >= 1
    first = entries[0]
    assert first["role"] == "Hero"
    assert first["actor"] == "John Doe"


def test_parse_crew_invalid_yaml_raises():
    with pytest.raises(CrewParseError):
        parse_crew_string(":")


def test_extract_roll_groups(sample_crew_yaml):
    parsed = parse_crew_string(sample_crew_yaml)
    groups = extract_roll_groups(parsed)
    assert isinstance(groups, list)
    assert len(groups) == 2
