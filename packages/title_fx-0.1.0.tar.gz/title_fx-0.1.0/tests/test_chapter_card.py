"""Tests for the chapter_card API."""

from __future__ import annotations

from title_fx import chapter_card


def test_chapter_card_black_bg(tmp_path):
    out = tmp_path / "chapter_black.mp4"
    result = chapter_card(
        text="CHAPTER ONE",
        background="#000000",
        duration=1.0,
        output=str(out),
    )
    assert result.exists(), f"Output file does not exist: {result}"
    assert result.stat().st_size > 0, "Output file is empty"


def test_chapter_card_hex_color(tmp_path):
    out = tmp_path / "chapter_hex.mp4"
    result = chapter_card(
        text="CHAPTER TWO",
        background="#1a1a2e",
        duration=1.0,
        output=str(out),
    )
    assert result.exists(), f"Output file does not exist: {result}"
    assert result.stat().st_size > 0, "Output file is empty"
