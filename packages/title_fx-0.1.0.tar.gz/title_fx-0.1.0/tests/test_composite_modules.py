"""Tests for composite sub-modules: textures, particles, light rays, grain."""

from __future__ import annotations

import pytest
from PIL import Image

from title_fx.composite.grain import render_grain_overlay
from title_fx.composite.light_rays import render_light_rays
from title_fx.composite.particles import render_dust, render_embers
from title_fx.composite.textures import apply_texture

_TEXTURE_NAMES = ["gold", "stone", "metal", "ice", "lava", "space"]


def test_texture_gold_returns_image():
    base = Image.new("RGBA", (100, 50), (255, 255, 255, 200))
    result = apply_texture(base, "gold")
    assert result.mode == "RGBA"
    assert result.size == (100, 50)


@pytest.mark.parametrize("name", _TEXTURE_NAMES)
def test_texture_all_names(name):
    base = Image.new("RGBA", (80, 40), (200, 200, 200, 180))
    result = apply_texture(base, name)
    assert result.mode == "RGBA"
    assert result.size == (80, 40)


def test_render_embers_returns_30_frames():
    frames = render_embers((320, 180))
    assert isinstance(frames, list)
    assert len(frames) == 30
    for frame in frames:
        assert isinstance(frame, Image.Image)
        assert frame.size == (320, 180)


def test_render_dust_returns_frames():
    frames = render_dust((320, 180))
    assert isinstance(frames, list)
    assert len(frames) > 0
    for frame in frames:
        assert isinstance(frame, Image.Image)


def test_light_rays_returns_frames():
    frames = render_light_rays((320, 180))
    assert isinstance(frames, list)
    assert len(frames) > 0
    for frame in frames:
        assert isinstance(frame, Image.Image)
        assert frame.size == (320, 180)


def test_grain_returns_frames():
    frames = render_grain_overlay((320, 180), amount=0.05)
    assert isinstance(frames, list)
    assert len(frames) == 30
    for frame in frames:
        assert isinstance(frame, Image.Image)
        assert frame.mode == "RGBA"
        assert frame.size == (320, 180)
