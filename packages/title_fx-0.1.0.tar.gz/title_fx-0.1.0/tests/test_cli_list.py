"""Tests for the title-fx CLI via subprocess."""

from __future__ import annotations

import json
import subprocess
import sys


def _run(*args: str) -> subprocess.CompletedProcess:
    return subprocess.run(
        [sys.executable, "-m", "title_fx.cli", *args],
        capture_output=True,
        text=True,
    )


def test_cli_list_returns_44_active():
    result = _run("list")
    assert result.returncode == 0, f"CLI exited {result.returncode}: {result.stderr}"
    lines = [ln for ln in result.stdout.strip().splitlines() if ln.strip()]
    assert len(lines) == 44, f"Expected 44 lines, got {len(lines)}: {lines}"


def test_cli_list_include_deferred_returns_59():
    result = _run("list", "--include-deferred")
    assert result.returncode == 0, f"CLI exited {result.returncode}: {result.stderr}"
    lines = [ln for ln in result.stdout.strip().splitlines() if ln.strip()]
    assert len(lines) == 59, f"Expected 59 lines, got {len(lines)}"


def test_cli_categories_returns_3():
    result = _run("categories")
    assert result.returncode == 0, f"CLI exited {result.returncode}: {result.stderr}"
    lines = [ln for ln in result.stdout.strip().splitlines() if ln.strip()]
    assert len(lines) == 3, f"Expected 3 category lines, got {len(lines)}: {lines}"
    assert set(lines) == {"cinematic_trailer", "typographic_layout", "advanced_3d"}


def test_cli_info_known_style():
    result = _run("info", "trailer_gold_title")
    assert result.returncode == 0, f"CLI exited {result.returncode}: {result.stderr}"
    data = json.loads(result.stdout)
    assert data["slug"] == "trailer_gold_title"
