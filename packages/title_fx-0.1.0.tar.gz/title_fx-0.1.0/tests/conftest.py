"""Shared fixtures for title-fx test suite."""

from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path

import pytest


@pytest.fixture(scope="session", autouse=True)
def ensure_venv_on_path():
    scripts_dir = str(Path(sys.executable).parent)
    current_path = os.environ.get("PATH", "")
    if scripts_dir not in current_path:
        os.environ["PATH"] = scripts_dir + os.pathsep + current_path


@pytest.fixture(scope="session")
def tiny_video(tmp_path_factory):
    """4-second 640x360 dark background video."""
    out = tmp_path_factory.mktemp("clips") / "bg.mp4"
    subprocess.run(
        [
            "ffmpeg",
            "-y",
            "-f",
            "lavfi",
            "-i",
            "color=black:s=640x360:d=4",
            "-c:v",
            "libx264",
            "-pix_fmt",
            "yuv420p",
            str(out),
        ],
        check=True,
        capture_output=True,
    )
    return out


@pytest.fixture(scope="session")
def sample_crew_yaml(tmp_path_factory):
    """A minimal crew YAML string."""
    return (
        'title: "Test Film"\n'
        "roll_groups:\n"
        "  - heading: DIRECTED BY\n"
        "    entries:\n"
        '      - "Jane Smith"\n'
        "  - heading: CAST\n"
        "    entries:\n"
        '      - role: "Hero"\n'
        '        actor: "John Doe"\n'
    )


@pytest.fixture(scope="session")
def sample_crew_file(tmp_path_factory, sample_crew_yaml):
    p = tmp_path_factory.mktemp("crew") / "credits.yaml"
    p.write_text(sample_crew_yaml, encoding="utf-8")
    return p
