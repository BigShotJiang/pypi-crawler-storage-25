"""Tests for the JSON Schema generator."""

from __future__ import annotations

import json

from title_fx.schema.generator import schema_json, title_schema
from title_fx.styles.stub_3d import DEFERRED_3D_SLUGS


def test_schema_has_59_slugs():
    schema = title_schema()
    enum = schema["properties"]["style"]["enum"]
    assert len(enum) == 59, f"Expected 59 slugs in schema enum, got {len(enum)}"


def test_schema_json_valid():
    raw = schema_json()
    parsed = json.loads(raw)
    assert isinstance(parsed, dict)
    assert "properties" in parsed


def test_schema_includes_deferred():
    schema = title_schema()
    enum_set = set(schema["properties"]["style"]["enum"])
    for slug in DEFERRED_3D_SLUGS:
        assert slug in enum_set, f"Deferred slug '{slug}' missing from schema enum"
