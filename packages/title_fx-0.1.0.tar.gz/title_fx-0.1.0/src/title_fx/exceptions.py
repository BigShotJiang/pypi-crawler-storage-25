# Filepath: title_fx/exceptions.py
# Condensed Description: Custom exception hierarchy for title-fx
# Architecture Layer: Library
# Environment: Both
# Script Hierarchy: TitleFxError, UnknownStyleError, DeferredStyleError, CompositionError, CrewParseError
# Dependencies: Internal: None; External: None
# Exposes: TitleFxError, UnknownStyleError, DeferredStyleError, CompositionError, CrewParseError
# Configuration: None
from __future__ import annotations


class TitleFxError(Exception):
    """Base exception for all title-fx errors."""


class UnknownStyleError(TitleFxError):
    """Raised when a requested title style slug is not found in the catalog."""

    def __init__(self, slug: str) -> None:
        super().__init__(
            f"Unknown title style: '{slug}'. Use list_titles() to see available styles."
        )
        self.slug = slug


class DeferredStyleError(TitleFxError):
    """Raised when a title style is deferred to a future version (v0.2 3D styles)."""

    def __init__(self, slug: str, message: str | None = None) -> None:
        default = (
            f"Title style '{slug}' is deferred to v0.2 (requires Blender Python integration). "
            f"Track at https://github.com/tomastimelock/title-fx/issues"
        )
        super().__init__(message or default)
        self.slug = slug


class CompositionError(TitleFxError):
    """Raised when a video composition or rendering step fails."""


class CrewParseError(TitleFxError):
    """Raised when crew YAML/data cannot be parsed or is malformed."""
