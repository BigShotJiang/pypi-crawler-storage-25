# Filepath: title_fx/config.py
# Condensed Description: Pydantic v2 configuration model for title-fx render requests
# Architecture Layer: Library
# Environment: Both
# Script Hierarchy: TitleConfig
# Dependencies: Internal: None; External: pydantic
# Exposes: TitleConfig
# Configuration: None
from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, ConfigDict


class TitleConfig(BaseModel):
    """Configuration for a title-fx render operation.

    Attributes:
        style: The title style slug to apply.
        start_time: Start offset in seconds within the target video.
        duration: Duration of the title animation in seconds.
        font_family: Optional font family name or path to a .ttf/.otf file.
        font_size: Font size in points. None uses the style default.
        line_height: Line height multiplier relative to font size.
        color: Primary text colour as a CSS hex string (e.g. "#FFFFFF").
        accent_color: Secondary or accent colour for multi-colour effects.
        background_color: Background fill colour for card/strap effects.
        smoke_intensity: Opacity multiplier for smoke particle effects (0.0–2.0).
        light_ray_intensity: Opacity multiplier for volumetric light rays (0.0–2.0).
        grain_amount: Film grain strength fraction (0.0–1.0).
        particle_count: Number of particles for ember/dust effects.
        bevel_depth: Pixel depth for bevel/emboss simulation.
        use_cut_fx_slam: Whether to attempt a cut-fx slam transition if installed.
        cut_fx_transition: The cut-fx transition slug to use for slam effects.
        position: Vertical anchor position for the title.
        position_custom: Pixel (x, y) for "custom" position mode.
        video_codec: FFmpeg codec identifier for output video.
    """

    model_config = ConfigDict(extra="forbid")

    style: str
    start_time: float = 0.0
    duration: float = 3.0
    font_family: str | None = None
    font_size: int | None = None
    line_height: float = 1.1
    color: str | None = None
    accent_color: str | None = None
    background_color: str | None = None
    smoke_intensity: float = 1.0
    light_ray_intensity: float = 1.0
    grain_amount: float = 0.1
    particle_count: int = 100
    bevel_depth: int = 4
    use_cut_fx_slam: bool = True
    cut_fx_transition: str = "hero_title_slam"
    position: Literal["center", "lower_third", "upper_third", "custom"] = "center"
    position_custom: tuple[int, int] | None = None
    video_codec: str = "libx264"
