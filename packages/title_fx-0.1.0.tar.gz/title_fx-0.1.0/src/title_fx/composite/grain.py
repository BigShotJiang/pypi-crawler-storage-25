# Filepath: title_fx/composite/grain.py
# Condensed Description: Film-grain noise overlay frame generator
# Architecture Layer: Library
# Environment: Both
# Script Hierarchy: render_grain_overlay
# Dependencies: Internal: None; External: PIL (Pillow), numpy
# Exposes: render_grain_overlay
# Configuration: None
from __future__ import annotations

import logging

import numpy as np
from PIL import Image

logger = logging.getLogger(__name__)


def render_grain_overlay(
    canvas_size: tuple[int, int],
    amount: float = 0.1,
    num_frames: int = 30,
    seed: int = 0,
) -> list[Image.Image]:
    """Return RGBA frames with film grain noise.

    Each frame is a luminance noise pattern rendered at the requested alpha
    level so that it can be composited over a video as a multiplicative or
    screen-blend grain layer.

    Args:
        canvas_size: (width, height) of each frame in pixels.
        amount: Grain opacity as a fraction of 255 (0.0–1.0).
        num_frames: Number of unique grain frames to generate.
        seed: RNG seed for reproducibility.

    Returns:
        List of ``num_frames`` RGBA PIL images.
    """
    w, h = canvas_size
    frames: list[Image.Image] = []
    rng = np.random.default_rng(seed)
    alpha = int(255 * max(0.0, min(1.0, amount)))

    for _ in range(num_frames):
        noise = rng.integers(0, 255, (h, w), dtype=np.uint8)
        alpha_channel = np.full((h, w), alpha, dtype=np.uint8)
        arr = np.stack([noise, noise, noise, alpha_channel], axis=2)
        frames.append(Image.fromarray(arr, "RGBA"))

    logger.debug("render_grain_overlay: generated %d frames (%dx%d)", len(frames), w, h)
    return frames
