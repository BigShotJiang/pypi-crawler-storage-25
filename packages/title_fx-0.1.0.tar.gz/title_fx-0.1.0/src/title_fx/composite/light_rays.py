# Filepath: title_fx/composite/light_rays.py
# Condensed Description: Procedural volumetric light-ray frame generator
# Architecture Layer: Library
# Environment: Both
# Script Hierarchy: render_light_rays
# Dependencies: Internal: None; External: PIL (Pillow), numpy
# Exposes: render_light_rays
# Configuration: None
from __future__ import annotations

import logging

import numpy as np
from PIL import Image, ImageDraw, ImageFilter

logger = logging.getLogger(__name__)


def render_light_rays(
    canvas_size: tuple[int, int],
    intensity: float = 1.0,
    color: str = "#FFFFFF",
    num_frames: int = 30,
    seed: int = 0,
) -> list[Image.Image]:
    """Return RGBA frames with volumetric light rays emanating from centre.

    Rays are drawn as semi-transparent lines from the canvas centre toward
    randomised directions, then Gaussian-blurred to produce a soft glow.

    Args:
        canvas_size: (width, height) of each frame in pixels.
        intensity: Opacity multiplier (0.0–2.0).
        color: Unused legacy parameter kept for API compatibility.
        num_frames: Number of animation frames to generate.
        seed: RNG seed for reproducibility.

    Returns:
        List of ``num_frames`` RGBA PIL images.
    """
    w, h = canvas_size
    cx, cy = w // 2, h // 2
    rng = np.random.default_rng(seed)
    ray_count = max(1, int(12 * intensity))
    frames: list[Image.Image] = []

    for _f in range(num_frames):
        img = Image.new("RGBA", (w, h), (0, 0, 0, 0))
        draw = ImageDraw.Draw(img)
        for _ in range(ray_count):
            angle = rng.uniform(0.0, 2.0 * np.pi)
            length = int(rng.integers(w // 4, w // 2))
            alpha = int(rng.integers(20, 60) * min(intensity, 2.0))
            ex = int(cx + np.cos(angle) * length)
            ey = int(cy + np.sin(angle) * length)
            draw.line([(cx, cy), (ex, ey)], fill=(255, 255, 220, alpha), width=2)
        frames.append(img.filter(ImageFilter.GaussianBlur(6)))

    logger.debug("render_light_rays: generated %d frames (%dx%d)", len(frames), w, h)
    return frames
