# Filepath: title_fx/composite/textures.py
# Condensed Description: Procedural texture generators for blending into RGBA title images
# Architecture Layer: Library
# Environment: Both
# Script Hierarchy: apply_texture
# Dependencies: Internal: None; External: PIL (Pillow), numpy
# Exposes: apply_texture
# Configuration: None
from __future__ import annotations

import logging

import numpy as np
from PIL import Image

logger = logging.getLogger(__name__)

_TINTS: dict[str, tuple[int, int, int]] = {
    "gold": (212, 175, 55),
    "stone": (105, 105, 105),
    "metal": (192, 192, 192),
    "ice": (173, 216, 230),
    "lava": (207, 16, 32),
    "space": (25, 25, 112),
}


def apply_texture(
    base: Image.Image,
    texture_name: str,
    intensity: float = 1.0,
) -> Image.Image:
    """Blend a named procedural texture effect onto a PIL RGBA image.

    The texture is generated synthetically using numpy noise so no external
    asset files are required. The tint colour is blended only into pixels
    where the source alpha is non-zero.

    Args:
        base: A PIL RGBA image to texture.
        texture_name: One of "gold", "stone", "metal", "ice", "lava", "space".
        intensity: Blend strength from 0.0 (no effect) to 2.0 (maximum).

    Returns:
        A new RGBA PIL image with the texture blended in.
    """
    if texture_name not in _TINTS:
        logger.warning(
            "Unknown texture '%s'; using fallback grey. Valid: %s",
            texture_name,
            ", ".join(_TINTS),
        )
    tint = _TINTS.get(texture_name, (200, 200, 200))

    arr = np.array(base, dtype=np.float32)
    h, w = arr.shape[:2]
    rng = np.random.default_rng(42)
    noise = rng.random((h, w)).astype(np.float32)

    alpha_mask = arr[:, :, 3] / 255.0
    blend = 0.4 * intensity

    for i, channel_value in enumerate(tint):
        noise_shift = noise * 40.0 * intensity
        arr[:, :, i] = (
            arr[:, :, i] * (1.0 - blend * alpha_mask)
            + (channel_value + noise_shift) * blend * alpha_mask
        ).clip(0.0, 255.0)

    return Image.fromarray(arr.clip(0.0, 255.0).astype(np.uint8), "RGBA")
