# Filepath: title_fx/composite/lens_flare.py
# Condensed Description: Procedural anamorphic horizontal lens-flare frame generator
# Architecture Layer: Library
# Environment: Both
# Script Hierarchy: render_lens_flare
# Dependencies: Internal: None; External: PIL (Pillow), numpy
# Exposes: render_lens_flare
# Configuration: None
from __future__ import annotations

import logging

from PIL import Image, ImageDraw

logger = logging.getLogger(__name__)


def render_lens_flare(
    canvas_size: tuple[int, int],
    intensity: float = 1.0,
    num_frames: int = 30,
) -> list[Image.Image]:
    """Return RGBA frames with an anamorphic horizontal lens flare.

    A horizontal streak fades from full opacity to transparent across
    ``num_frames`` frames to simulate a characteristic anamorphic lens bloom.

    Args:
        canvas_size: (width, height) of each frame in pixels.
        intensity: Peak alpha multiplier (0.0–2.0).
        num_frames: Number of animation frames to generate.

    Returns:
        List of ``num_frames`` RGBA PIL images.
    """
    w, h = canvas_size
    frames: list[Image.Image] = []

    for f in range(num_frames):
        img = Image.new("RGBA", (w, h), (0, 0, 0, 0))
        draw = ImageDraw.Draw(img)
        cy = h // 2
        fade = f / max(1, num_frames - 1)
        alpha = int(200 * min(intensity, 2.0) * (1.0 - fade))
        draw.line([(0, cy), (w, cy)], fill=(255, 240, 200, alpha), width=3)
        frames.append(img)

    logger.debug("render_lens_flare: generated %d frames (%dx%d)", len(frames), w, h)
    return frames
