# Filepath: title_fx/composite/particles.py
# Condensed Description: Procedural particle system generators (embers, dust, smoke) returning RGBA frame lists
# Architecture Layer: Library
# Environment: Both
# Script Hierarchy: render_embers, render_dust, render_smoke
# Dependencies: Internal: None; External: PIL (Pillow), numpy
# Exposes: render_embers, render_dust, render_smoke
# Configuration: None
from __future__ import annotations

import logging

import numpy as np
from PIL import Image, ImageDraw

logger = logging.getLogger(__name__)


def render_embers(
    canvas_size: tuple[int, int],
    count: int = 80,
    color: str = "#FFD700",
    seed: int = 42,
) -> list[Image.Image]:
    """Return a list of RGBA frames with animated ember particles.

    Each frame contains randomly positioned glowing dots. The positions are
    seeded deterministically so the animation is reproducible.

    Args:
        canvas_size: (width, height) of each frame.
        count: Approximate number of ember particles per frame.
        color: Unused legacy parameter kept for API compatibility.
        seed: RNG seed for reproducibility.

    Returns:
        List of 30 RGBA PIL images.
    """
    w, h = canvas_size
    frames: list[Image.Image] = []
    rng = np.random.default_rng(seed)
    particles_per_frame = max(1, count // 3)

    for _f in range(30):
        img = Image.new("RGBA", (w, h), (0, 0, 0, 0))
        draw = ImageDraw.Draw(img)
        for _ in range(particles_per_frame):
            x = int(rng.integers(0, w))
            y = int(rng.integers(0, h))
            r = int(rng.integers(2, 5))
            a = int(rng.integers(100, 220))
            draw.ellipse([x - r, y - r, x + r, y + r], fill=(255, 200, 50, a))
        frames.append(img)

    logger.debug("render_embers: generated %d frames (%dx%d)", len(frames), w, h)
    return frames


def render_dust(
    canvas_size: tuple[int, int],
    count: int = 50,
    seed: int = 43,
) -> list[Image.Image]:
    """Return a list of RGBA frames with drifting dust particles.

    Args:
        canvas_size: (width, height) of each frame.
        count: Number of dust specks per frame.
        seed: RNG seed for reproducibility.

    Returns:
        List of 30 RGBA PIL images.
    """
    w, h = canvas_size
    frames: list[Image.Image] = []
    rng = np.random.default_rng(seed)

    for _f in range(30):
        img = Image.new("RGBA", (w, h), (0, 0, 0, 0))
        draw = ImageDraw.Draw(img)
        for _ in range(count):
            x = int(rng.integers(0, w))
            y = int(rng.integers(0, h))
            draw.ellipse([x - 1, y - 1, x + 1, y + 1], fill=(220, 210, 190, 80))
        frames.append(img)

    logger.debug("render_dust: generated %d frames (%dx%d)", len(frames), w, h)
    return frames


def render_smoke(
    canvas_size: tuple[int, int],
    seed: int = 44,
) -> list[Image.Image]:
    """Return a list of RGBA frames with a soft smoke effect.

    The current implementation returns transparent frames as a placeholder;
    real smoke compositing requires external footage or a full fluid simulation.

    Args:
        canvas_size: (width, height) of each frame.
        seed: RNG seed (reserved for future procedural smoke).

    Returns:
        List of 30 fully transparent RGBA PIL images.
    """
    w, h = canvas_size
    frames: list[Image.Image] = []
    for _f in range(30):
        frames.append(Image.new("RGBA", (w, h), (0, 0, 0, 0)))

    logger.debug("render_smoke: generated %d placeholder frames (%dx%d)", len(frames), w, h)
    return frames
