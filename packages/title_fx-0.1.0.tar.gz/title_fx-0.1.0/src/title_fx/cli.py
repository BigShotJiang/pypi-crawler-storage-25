# Filepath: title_fx/cli.py
# Condensed Description: Command-line interface for title-fx
# Architecture Layer: CLI
# Environment: Both
# Script Hierarchy: main, _cmd_apply, _cmd_lower_third, _cmd_chapter, _cmd_credits,
#   _cmd_list, _cmd_info, _cmd_categories, _cmd_schema, _cmd_preview
# Dependencies: Internal: title_fx.api, title_fx.exceptions, title_fx.schema.generator;
#   External: argparse, sys, json, logging
# Exposes: main
# Configuration: None
from __future__ import annotations

import argparse
import json
import logging
import sys

logger = logging.getLogger(__name__)


def _build_parser() -> argparse.ArgumentParser:
    """Build and return the top-level argument parser.

    Returns:
        Configured ArgumentParser instance.
    """
    parser = argparse.ArgumentParser(
        prog="title-fx",
        description="Apply cinematic title styles to videos.",
    )
    parser.add_argument(
        "--verbose",
        "-v",
        action="store_true",
        help="Enable debug logging.",
    )
    sub = parser.add_subparsers(dest="command", required=True)

    # ------------------------------------------------------------------ apply
    p_apply = sub.add_parser("apply", help="Apply a title style to a video.")
    p_apply.add_argument("--video", required=True, help="Path to source video.")
    p_apply.add_argument("--text", required=True, help="Title text to render.")
    p_apply.add_argument("--style", required=True, help="Title style slug.")
    p_apply.add_argument("--duration", type=float, default=3.0, help="Duration in seconds.")
    p_apply.add_argument("--start", dest="start_time", type=float, default=0.0)
    p_apply.add_argument("--out", dest="output", default=None, help="Output path.")

    # ------------------------------------------------------------- lower-third
    p_lt = sub.add_parser("lower-third", help="Render a lower third overlay.")
    p_lt.add_argument("--video", required=True)
    p_lt.add_argument("--name", required=True, help="Primary name string.")
    p_lt.add_argument("--title", required=True, help="Secondary title/role string.")
    p_lt.add_argument("--style", default="documentary_lower_third")
    p_lt.add_argument("--duration", type=float, default=4.0)
    p_lt.add_argument("--start", dest="start_time", type=float, default=0.0)
    p_lt.add_argument("--out", dest="output", default=None)

    # --------------------------------------------------------------- chapter
    p_chap = sub.add_parser("chapter", help="Render a full-screen chapter card.")
    p_chap.add_argument("--text", required=True, help="Chapter title text.")
    p_chap.add_argument("--background", default="#000000", help="Background hex colour.")
    p_chap.add_argument("--duration", type=float, default=4.0)
    p_chap.add_argument("--out", dest="output", default=None)
    p_chap.add_argument("--width", type=int, default=1920, help="Canvas width (reserved).")
    p_chap.add_argument("--height", type=int, default=1080, help="Canvas height (reserved).")

    # --------------------------------------------------------------- credits
    p_cred = sub.add_parser("credits", help="Render scrolling end credits.")
    p_cred.add_argument("--crew", required=True, help="Path to crew YAML file.")
    p_cred.add_argument("--duration", type=float, default=60.0)
    p_cred.add_argument("--out", dest="output", default=None)
    p_cred.add_argument("--video", default=None, help="Optional base video path.")

    # ------------------------------------------------------------------ list
    p_list = sub.add_parser("list", help="List available title style slugs.")
    p_list.add_argument(
        "--include-deferred",
        action="store_true",
        help="Also include deferred v0.2 slugs.",
    )

    # ------------------------------------------------------------------ info
    p_info = sub.add_parser("info", help="Show catalog entry for a style.")
    p_info.add_argument("style", help="Style slug to describe.")

    # ------------------------------------------------------------ categories
    sub.add_parser("categories", help="List available style categories.")

    # --------------------------------------------------------------- schema
    p_schema = sub.add_parser("schema", help="Print the JSON Schema for title requests.")
    p_schema.add_argument("--pretty", action="store_true", help="Indent output.")

    # --------------------------------------------------------------- preview
    p_prev = sub.add_parser("preview", help="Preview a style on a blank background.")
    p_prev.add_argument("--style", required=True, help="Style slug to preview.")
    p_prev.add_argument("--text", default="Preview Text", help="Text to render.")
    p_prev.add_argument("--out", dest="output", default=None)
    p_prev.add_argument("--duration", type=float, default=3.0)
    p_prev.add_argument(
        "--bg-color",
        default="#000000",
        help="Background hex colour for preview canvas.",
    )

    return parser


def _cmd_apply(args: argparse.Namespace) -> int:
    """Handle the 'apply' sub-command.

    Args:
        args: Parsed argument namespace.

    Returns:
        Exit code (0 = success).
    """
    from title_fx.api import apply_title
    from title_fx.exceptions import TitleFxError

    try:
        out = apply_title(
            video=args.video,
            text=args.text,
            style=args.style,
            duration=args.duration,
            start_time=args.start_time,
            output=args.output,
        )
        print(str(out))
        return 0
    except NotImplementedError as exc:
        print(f"title-fx: deferred style — {exc}", file=sys.stderr)
        return 2
    except TitleFxError as exc:
        print(f"title-fx error: {exc}", file=sys.stderr)
        return 1


def _cmd_lower_third(args: argparse.Namespace) -> int:
    """Handle the 'lower-third' sub-command.

    Args:
        args: Parsed argument namespace.

    Returns:
        Exit code.
    """
    from title_fx.api import lower_third
    from title_fx.exceptions import TitleFxError

    try:
        out = lower_third(
            video=args.video,
            name=args.name,
            title=args.title,
            style=args.style,
            duration=args.duration,
            start_time=args.start_time,
            output=args.output,
        )
        print(str(out))
        return 0
    except TitleFxError as exc:
        print(f"title-fx error: {exc}", file=sys.stderr)
        return 1


def _cmd_chapter(args: argparse.Namespace) -> int:
    """Handle the 'chapter' sub-command.

    Args:
        args: Parsed argument namespace.

    Returns:
        Exit code.
    """
    from title_fx.api import chapter_card
    from title_fx.exceptions import TitleFxError

    try:
        out = chapter_card(
            text=args.text,
            duration=args.duration,
            background=args.background,
            output=args.output,
        )
        print(str(out))
        return 0
    except TitleFxError as exc:
        print(f"title-fx error: {exc}", file=sys.stderr)
        return 1


def _cmd_credits(args: argparse.Namespace) -> int:
    """Handle the 'credits' sub-command.

    Args:
        args: Parsed argument namespace.

    Returns:
        Exit code.
    """
    from title_fx.api import end_credits
    from title_fx.exceptions import TitleFxError

    try:
        out = end_credits(
            crew_data=args.crew,
            duration=args.duration,
            output=args.output,
            video=args.video,
        )
        print(str(out))
        return 0
    except TitleFxError as exc:
        print(f"title-fx error: {exc}", file=sys.stderr)
        return 1


def _cmd_list(args: argparse.Namespace) -> int:
    """Handle the 'list' sub-command.

    Args:
        args: Parsed argument namespace.

    Returns:
        Exit code.
    """
    from title_fx.api import list_titles

    slugs = list_titles(include_deferred=args.include_deferred)
    for slug in slugs:
        print(slug)
    return 0


def _cmd_info(args: argparse.Namespace) -> int:
    """Handle the 'info' sub-command.

    Args:
        args: Parsed argument namespace.

    Returns:
        Exit code.
    """
    from title_fx.api import get_title_info
    from title_fx.exceptions import UnknownStyleError

    try:
        info = get_title_info(args.style)
        print(json.dumps(info, indent=2))
        return 0
    except UnknownStyleError as exc:
        print(f"title-fx error: {exc}", file=sys.stderr)
        return 1


def _cmd_categories(_args: argparse.Namespace) -> int:
    """Handle the 'categories' sub-command.

    Args:
        _args: Parsed argument namespace (unused).

    Returns:
        Exit code.
    """
    from title_fx.styles.loader import load_catalog

    catalog = load_catalog()
    cats: list[str] = catalog.get("categories", [])
    for cat in cats:
        print(cat)
    return 0


def _cmd_schema(args: argparse.Namespace) -> int:
    """Handle the 'schema' sub-command.

    Args:
        args: Parsed argument namespace.

    Returns:
        Exit code.
    """
    from title_fx.schema.generator import schema_json

    print(schema_json(pretty=args.pretty))
    return 0


def _cmd_preview(args: argparse.Namespace) -> int:
    """Handle the 'preview' sub-command.

    Args:
        args: Parsed argument namespace.

    Returns:
        Exit code.
    """
    from title_fx.api import chapter_card
    from title_fx.exceptions import TitleFxError

    # chapter_card creates a bg video then overlays text — suitable for preview
    try:
        out = chapter_card(
            text=args.text,
            duration=args.duration,
            background=args.bg_color,
            output=args.output,
            style=args.style,
        )
        print(str(out))
        return 0
    except NotImplementedError as exc:
        print(f"title-fx: deferred style — {exc}", file=sys.stderr)
        return 2
    except TitleFxError as exc:
        print(f"title-fx error: {exc}", file=sys.stderr)
        return 1


_COMMAND_MAP = {
    "apply": _cmd_apply,
    "lower-third": _cmd_lower_third,
    "chapter": _cmd_chapter,
    "credits": _cmd_credits,
    "list": _cmd_list,
    "info": _cmd_info,
    "categories": _cmd_categories,
    "schema": _cmd_schema,
    "preview": _cmd_preview,
}


def main(argv: list[str] | None = None) -> int:
    """Entry point for the title-fx CLI.

    Args:
        argv: Argument list.  Defaults to sys.argv[1:] when None.

    Returns:
        Integer exit code (0 = success, 1 = error, 2 = deferred style).
    """
    parser = _build_parser()
    args = parser.parse_args(argv)

    logging.basicConfig(
        level=logging.DEBUG if args.verbose else logging.WARNING,
        format="%(levelname)s %(name)s: %(message)s",
    )

    handler = _COMMAND_MAP.get(args.command)
    if handler is None:  # pragma: no cover
        parser.print_help()
        return 1

    return handler(args)


if __name__ == "__main__":
    import sys

    sys.exit(main())
