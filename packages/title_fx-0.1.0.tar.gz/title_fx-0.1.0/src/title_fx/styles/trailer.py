# Filepath: title_fx/styles/trailer.py
# Condensed Description: Recipe functions for the 24 cinematic_trailer title styles
# Architecture Layer: Library
# Environment: Both
# Script Hierarchy: trailer_gold_title, epic_stone_title, metal_bevel_title, fire_ember_title,
#   smoke_title, dust_reveal_title, light_ray_title, lens_flare_title, anamorphic_flare_sweep,
#   cinematic_fade_up, epic_push_in, hero_title_slam, trailer_flash_cut, dark_prestige_title,
#   horror_scratch_title, blood_drip_text, ice_title, lava_title, space_title,
#   superhero_emblem_title, documentary_lower_third, news_headline_strap,
#   festival_laurel_title, chapter_card, CINEMATIC_DISPATCH
# Dependencies: Internal: title_fx.config; External: pathlib, text_fx (lazy)
# Exposes: CINEMATIC_DISPATCH
# Configuration: None
from __future__ import annotations

import logging
from pathlib import Path

from title_fx.config import TitleConfig

logger = logging.getLogger(__name__)


def _apply(
    video_path: Path,
    text: str,
    effect: str,
    config: TitleConfig,
    output: Path,
    color: str,
    font_size: int,
) -> Path:
    """Shared helper that delegates to text_fx.apply_text_effect.

    Args:
        video_path: Source video file.
        text: Text string to render.
        effect: text-fx effect slug.
        config: Title render configuration.
        output: Destination output path.
        color: Default colour if config.color is None.
        font_size: Default font size if config.font_size is None.

    Returns:
        The output path on success.
    """
    import text_fx  # lazy import to avoid circular dependency at module level

    text_fx.apply_text_effect(
        video=str(video_path),
        text=text,
        effect=effect,
        output=str(output),
        duration=config.duration,
        start_time=config.start_time,
        color=config.color or color,
        font_size=config.font_size or font_size,
    )
    return output


def trailer_gold_title(video_path: Path, text: str, config: TitleConfig, output: Path) -> Path:
    """Large metallic gold title with cinematic glow.

    Args:
        video_path: Source video file.
        text: Title text to render.
        config: Render configuration.
        output: Output file path.

    Returns:
        Path to the rendered output file.
    """
    return _apply(video_path, text, "gold_shine", config, output, "#D4AF37", 120)


def epic_stone_title(video_path: Path, text: str, config: TitleConfig, output: Path) -> Path:
    """Heavy stone-textured title with cracks.

    Args:
        video_path: Source video file.
        text: Title text to render.
        config: Render configuration.
        output: Output file path.

    Returns:
        Path to the rendered output file.
    """
    return _apply(video_path, text, "fade_in", config, output, "#808080", 120)


def metal_bevel_title(video_path: Path, text: str, config: TitleConfig, output: Path) -> Path:
    """Chrome or steel beveled title.

    Args:
        video_path: Source video file.
        text: Title text to render.
        config: Render configuration.
        output: Output file path.

    Returns:
        Path to the rendered output file.
    """
    return _apply(video_path, text, "fade_in", config, output, "#C0C0C0", 120)


def fire_ember_title(video_path: Path, text: str, config: TitleConfig, output: Path) -> Path:
    """Title glows with embers and heat.

    Args:
        video_path: Source video file.
        text: Title text to render.
        config: Render configuration.
        output: Output file path.

    Returns:
        Path to the rendered output file.
    """
    return _apply(video_path, text, "fade_in", config, output, "#FF4500", 120)


def smoke_title(video_path: Path, text: str, config: TitleConfig, output: Path) -> Path:
    """Title appears through cinematic smoke.

    Args:
        video_path: Source video file.
        text: Title text to render.
        config: Render configuration.
        output: Output file path.

    Returns:
        Path to the rendered output file.
    """
    return _apply(video_path, text, "fade_out", config, output, "#CCCCCC", 110)


def dust_reveal_title(video_path: Path, text: str, config: TitleConfig, output: Path) -> Path:
    """Trailer title revealed by drifting dust particles.

    Args:
        video_path: Source video file.
        text: Title text to render.
        config: Render configuration.
        output: Output file path.

    Returns:
        Path to the rendered output file.
    """
    return _apply(video_path, text, "fade_in", config, output, "#D2B48C", 110)


def light_ray_title(video_path: Path, text: str, config: TitleConfig, output: Path) -> Path:
    """Volumetric rays behind text.

    Args:
        video_path: Source video file.
        text: Title text to render.
        config: Render configuration.
        output: Output file path.

    Returns:
        Path to the rendered output file.
    """
    return _apply(video_path, text, "bokeh_text", config, output, "#FFFFFF", 110)


def lens_flare_title(video_path: Path, text: str, config: TitleConfig, output: Path) -> Path:
    """Title appears with horizontal anamorphic flare.

    Args:
        video_path: Source video file.
        text: Title text to render.
        config: Render configuration.
        output: Output file path.

    Returns:
        Path to the rendered output file.
    """
    return _apply(video_path, text, "fade_in", config, output, "#FFFAF0", 110)


def anamorphic_flare_sweep(video_path: Path, text: str, config: TitleConfig, output: Path) -> Path:
    """Light sweep travels across text.

    Args:
        video_path: Source video file.
        text: Title text to render.
        config: Render configuration.
        output: Output file path.

    Returns:
        Path to the rendered output file.
    """
    return _apply(video_path, text, "fade_in", config, output, "#FFFAF0", 110)


def cinematic_fade_up(video_path: Path, text: str, config: TitleConfig, output: Path) -> Path:
    """Slow fade-in with subtle zoom and grain.

    Args:
        video_path: Source video file.
        text: Title text to render.
        config: Render configuration.
        output: Output file path.

    Returns:
        Path to the rendered output file.
    """
    return _apply(video_path, text, "fade_in", config, output, "#FFFFFF", 100)


def epic_push_in(video_path: Path, text: str, config: TitleConfig, output: Path) -> Path:
    """Title slowly pushes toward camera.

    Args:
        video_path: Source video file.
        text: Title text to render.
        config: Render configuration.
        output: Output file path.

    Returns:
        Path to the rendered output file.
    """
    return _apply(video_path, text, "fade_in", config, output, "#FFFFFF", 120)


def hero_title_slam(video_path: Path, text: str, config: TitleConfig, output: Path) -> Path:
    """Title slams into centre with bass impact.

    Args:
        video_path: Source video file.
        text: Title text to render.
        config: Render configuration.
        output: Output file path.

    Returns:
        Path to the rendered output file.
    """
    return _apply(video_path, text, "kinetic_pop", config, output, "#FFFFFF", 140)


def trailer_flash_cut(video_path: Path, text: str, config: TitleConfig, output: Path) -> Path:
    """Text appears for very short flash frames.

    Args:
        video_path: Source video file.
        text: Title text to render.
        config: Render configuration.
        output: Output file path.

    Returns:
        Path to the rendered output file.
    """
    return _apply(video_path, text, "fade_in", config, output, "#FFFFFF", 130)


def dark_prestige_title(video_path: Path, text: str, config: TitleConfig, output: Path) -> Path:
    """Minimal title over black with subtle glow.

    Args:
        video_path: Source video file.
        text: Title text to render.
        config: Render configuration.
        output: Output file path.

    Returns:
        Path to the rendered output file.
    """
    return _apply(video_path, text, "fade_in", config, output, "#CCCCCC", 100)


def horror_scratch_title(video_path: Path, text: str, config: TitleConfig, output: Path) -> Path:
    """Uneven horror typography with scratches.

    Args:
        video_path: Source video file.
        text: Title text to render.
        config: Render configuration.
        output: Output file path.

    Returns:
        Path to the rendered output file.
    """
    return _apply(video_path, text, "fade_in", config, output, "#FF0000", 120)


def blood_drip_text(video_path: Path, text: str, config: TitleConfig, output: Path) -> Path:
    """Letters drip downward.

    Args:
        video_path: Source video file.
        text: Title text to render.
        config: Render configuration.
        output: Output file path.

    Returns:
        Path to the rendered output file.
    """
    return _apply(video_path, text, "pixel_melt", config, output, "#8B0000", 120)


def ice_title(video_path: Path, text: str, config: TitleConfig, output: Path) -> Path:
    """Frozen crystalline text.

    Args:
        video_path: Source video file.
        text: Title text to render.
        config: Render configuration.
        output: Output file path.

    Returns:
        Path to the rendered output file.
    """
    return _apply(video_path, text, "fade_in", config, output, "#ADD8E6", 120)


def lava_title(video_path: Path, text: str, config: TitleConfig, output: Path) -> Path:
    """Hot molten text with glowing cracks.

    Args:
        video_path: Source video file.
        text: Title text to render.
        config: Render configuration.
        output: Output file path.

    Returns:
        Path to the rendered output file.
    """
    return _apply(video_path, text, "fade_in", config, output, "#CF1020", 120)


def space_title(video_path: Path, text: str, config: TitleConfig, output: Path) -> Path:
    """Title filled with starfield/nebula.

    Args:
        video_path: Source video file.
        text: Title text to render.
        config: Render configuration.
        output: Output file path.

    Returns:
        Path to the rendered output file.
    """
    return _apply(video_path, text, "bokeh_text", config, output, "#191970", 120)


def superhero_emblem_title(video_path: Path, text: str, config: TitleConfig, output: Path) -> Path:
    """Bold title with emblematic bevel and shine.

    Args:
        video_path: Source video file.
        text: Title text to render.
        config: Render configuration.
        output: Output file path.

    Returns:
        Path to the rendered output file.
    """
    return _apply(video_path, text, "neon_glow_text", config, output, "#FFD700", 140)


def documentary_lower_third(video_path: Path, text: str, config: TitleConfig, output: Path) -> Path:
    """Clean lower-third title for names/locations.

    Args:
        video_path: Source video file.
        text: Title text to render.
        config: Render configuration.
        output: Output file path.

    Returns:
        Path to the rendered output file.
    """
    return _apply(video_path, text, "slide_left_text", config, output, "#FFFFFF", 72)


def news_headline_strap(video_path: Path, text: str, config: TitleConfig, output: Path) -> Path:
    """Broadcast-style headline bar.

    Args:
        video_path: Source video file.
        text: Title text to render.
        config: Render configuration.
        output: Output file path.

    Returns:
        Path to the rendered output file.
    """
    return _apply(video_path, text, "slide_left_text", config, output, "#FFFFFF", 72)


def festival_laurel_title(video_path: Path, text: str, config: TitleConfig, output: Path) -> Path:
    """Film-festival styled text with laurels.

    Args:
        video_path: Source video file.
        text: Title text to render.
        config: Render configuration.
        output: Output file path.

    Returns:
        Path to the rendered output file.
    """
    return _apply(video_path, text, "gold_shine", config, output, "#D4AF37", 96)


def chapter_card(video_path: Path, text: str, config: TitleConfig, output: Path) -> Path:
    """Full-screen chapter title card.

    Args:
        video_path: Source video file.
        text: Title text to render.
        config: Render configuration.
        output: Output file path.

    Returns:
        Path to the rendered output file.
    """
    return _apply(video_path, text, "fade_in", config, output, "#FFFFFF", 120)


CINEMATIC_DISPATCH: dict[str, object] = {
    "trailer_gold_title": trailer_gold_title,
    "epic_stone_title": epic_stone_title,
    "metal_bevel_title": metal_bevel_title,
    "fire_ember_title": fire_ember_title,
    "smoke_title": smoke_title,
    "dust_reveal_title": dust_reveal_title,
    "light_ray_title": light_ray_title,
    "lens_flare_title": lens_flare_title,
    "anamorphic_flare_sweep": anamorphic_flare_sweep,
    "cinematic_fade_up": cinematic_fade_up,
    "epic_push_in": epic_push_in,
    "hero_title_slam": hero_title_slam,
    "trailer_flash_cut": trailer_flash_cut,
    "dark_prestige_title": dark_prestige_title,
    "horror_scratch_title": horror_scratch_title,
    "blood_drip_text": blood_drip_text,
    "ice_title": ice_title,
    "lava_title": lava_title,
    "space_title": space_title,
    "superhero_emblem_title": superhero_emblem_title,
    "documentary_lower_third": documentary_lower_third,
    "news_headline_strap": news_headline_strap,
    "festival_laurel_title": festival_laurel_title,
    "chapter_card": chapter_card,
}
