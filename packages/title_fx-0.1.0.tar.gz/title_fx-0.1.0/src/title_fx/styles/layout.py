# Filepath: title_fx/styles/layout.py
# Condensed Description: Recipe functions for the 20 typographic_layout title styles
# Architecture Layer: Library
# Environment: Both
# Script Hierarchy: stacked_title, split_typography, text_behind_subject, text_around_object,
#   vertical_text, circular_badge_text, grid_text, poster_title_lockup, credit_block,
#   end_credits_roll, title_crawl, split_screen_labels, map_label_text, data_label_overlay,
#   infographic_text, number_counter, percentage_counter, big_quote_title,
#   legal_citation_caption, document_stamp_text, TYPOGRAPHIC_DISPATCH
# Dependencies: Internal: title_fx.config; External: pathlib, text_fx (lazy)
# Exposes: TYPOGRAPHIC_DISPATCH
# Configuration: None
from __future__ import annotations

import logging
from pathlib import Path

from title_fx.config import TitleConfig

logger = logging.getLogger(__name__)


def _apply(
    video_path: Path,
    text: str,
    effect: str,
    config: TitleConfig,
    output: Path,
    color: str,
    font_size: int,
) -> Path:
    """Shared helper delegating to text_fx.apply_text_effect.

    Args:
        video_path: Source video file.
        text: Text string to render.
        effect: text-fx effect slug.
        config: Title render configuration.
        output: Destination output path.
        color: Default colour if config.color is None.
        font_size: Default font size if config.font_size is None.

    Returns:
        The output path on success.
    """
    import text_fx  # lazy to avoid circular dependency at module load

    text_fx.apply_text_effect(
        video=str(video_path),
        text=text,
        effect=effect,
        output=str(output),
        duration=config.duration,
        start_time=config.start_time,
        color=config.color or color,
        font_size=config.font_size or font_size,
    )
    return output


def stacked_title(video_path: Path, text: str, config: TitleConfig, output: Path) -> Path:
    """Words stacked vertically with alignment.

    Args:
        video_path: Source video file.
        text: Title text to render.
        config: Render configuration.
        output: Output file path.

    Returns:
        Path to the rendered output file.
    """
    return _apply(video_path, text, "fade_in", config, output, "#FFFFFF", 120)


def split_typography(video_path: Path, text: str, config: TitleConfig, output: Path) -> Path:
    """Large word split around subject area.

    Args:
        video_path: Source video file.
        text: Title text to render.
        config: Render configuration.
        output: Output file path.

    Returns:
        Path to the rendered output file.
    """
    return _apply(video_path, text, "fade_in", config, output, "#FFFFFF", 140)


def text_behind_subject(video_path: Path, text: str, config: TitleConfig, output: Path) -> Path:
    """Title appears behind a person/object.

    Args:
        video_path: Source video file.
        text: Title text to render.
        config: Render configuration.
        output: Output file path.

    Returns:
        Path to the rendered output file.
    """
    return _apply(video_path, text, "fade_in", config, output, "#FFFFFF", 120)


def text_around_object(video_path: Path, text: str, config: TitleConfig, output: Path) -> Path:
    """Text wraps or positions around subject.

    Args:
        video_path: Source video file.
        text: Title text to render.
        config: Render configuration.
        output: Output file path.

    Returns:
        Path to the rendered output file.
    """
    return _apply(video_path, text, "fade_in", config, output, "#FFFFFF", 96)


def vertical_text(video_path: Path, text: str, config: TitleConfig, output: Path) -> Path:
    """Text arranged vertically.

    Args:
        video_path: Source video file.
        text: Title text to render.
        config: Render configuration.
        output: Output file path.

    Returns:
        Path to the rendered output file.
    """
    return _apply(video_path, text, "fade_in", config, output, "#FFFFFF", 80)


def circular_badge_text(video_path: Path, text: str, config: TitleConfig, output: Path) -> Path:
    """Text on circular badge/logo.

    Args:
        video_path: Source video file.
        text: Title text to render.
        config: Render configuration.
        output: Output file path.

    Returns:
        Path to the rendered output file.
    """
    return _apply(video_path, text, "fade_in", config, output, "#FFFFFF", 72)


def grid_text(video_path: Path, text: str, config: TitleConfig, output: Path) -> Path:
    """Repeating words in a grid pattern.

    Args:
        video_path: Source video file.
        text: Title text to render.
        config: Render configuration.
        output: Output file path.

    Returns:
        Path to the rendered output file.
    """
    return _apply(video_path, text, "fade_in", config, output, "#FFFFFF", 60)


def poster_title_lockup(video_path: Path, text: str, config: TitleConfig, output: Path) -> Path:
    """Structured film-poster title layout.

    Args:
        video_path: Source video file.
        text: Title text to render.
        config: Render configuration.
        output: Output file path.

    Returns:
        Path to the rendered output file.
    """
    return _apply(video_path, text, "fade_in", config, output, "#FFFFFF", 120)


def credit_block(video_path: Path, text: str, config: TitleConfig, output: Path) -> Path:
    """Movie poster credit block.

    Args:
        video_path: Source video file.
        text: Title text to render.
        config: Render configuration.
        output: Output file path.

    Returns:
        Path to the rendered output file.
    """
    return _apply(video_path, text, "fade_in", config, output, "#CCCCCC", 36)


def end_credits_roll(video_path: Path, text: str, config: TitleConfig, output: Path) -> Path:
    """Credits scroll upward.

    Args:
        video_path: Source video file.
        text: Title text to render.
        config: Render configuration.
        output: Output file path.

    Returns:
        Path to the rendered output file.
    """
    return _apply(video_path, text, "fade_in", config, output, "#FFFFFF", 48)


def title_crawl(video_path: Path, text: str, config: TitleConfig, output: Path) -> Path:
    """Perspective text crawl like sci-fi intro.

    Args:
        video_path: Source video file.
        text: Title text to render.
        config: Render configuration.
        output: Output file path.

    Returns:
        Path to the rendered output file.
    """
    return _apply(video_path, text, "fade_in", config, output, "#FFD700", 60)


def split_screen_labels(video_path: Path, text: str, config: TitleConfig, output: Path) -> Path:
    """Labels attached to panels in split-screen.

    Args:
        video_path: Source video file.
        text: Title text to render.
        config: Render configuration.
        output: Output file path.

    Returns:
        Path to the rendered output file.
    """
    return _apply(video_path, text, "fade_in", config, output, "#FFFFFF", 60)


def map_label_text(video_path: Path, text: str, config: TitleConfig, output: Path) -> Path:
    """Animated map labels or place names.

    Args:
        video_path: Source video file.
        text: Title text to render.
        config: Render configuration.
        output: Output file path.

    Returns:
        Path to the rendered output file.
    """
    return _apply(video_path, text, "fade_in", config, output, "#FFFFFF", 48)


def data_label_overlay(video_path: Path, text: str, config: TitleConfig, output: Path) -> Path:
    """Text labels attached to chart elements.

    Args:
        video_path: Source video file.
        text: Title text to render.
        config: Render configuration.
        output: Output file path.

    Returns:
        Path to the rendered output file.
    """
    return _apply(video_path, text, "fade_in", config, output, "#FFFFFF", 40)


def infographic_text(video_path: Path, text: str, config: TitleConfig, output: Path) -> Path:
    """Structured explanatory labels and numbers.

    Args:
        video_path: Source video file.
        text: Title text to render.
        config: Render configuration.
        output: Output file path.

    Returns:
        Path to the rendered output file.
    """
    return _apply(video_path, text, "fade_in", config, output, "#FFFFFF", 72)


def number_counter(video_path: Path, text: str, config: TitleConfig, output: Path) -> Path:
    """Numeric value counts up/down.

    Args:
        video_path: Source video file.
        text: Title text (final number as string) to render.
        config: Render configuration.
        output: Output file path.

    Returns:
        Path to the rendered output file.
    """
    return _apply(video_path, text, "fade_in", config, output, "#FFFFFF", 120)


def percentage_counter(video_path: Path, text: str, config: TitleConfig, output: Path) -> Path:
    """Percentage increments with suffix.

    Args:
        video_path: Source video file.
        text: Title text (final percentage string) to render.
        config: Render configuration.
        output: Output file path.

    Returns:
        Path to the rendered output file.
    """
    return _apply(video_path, text, "fade_in", config, output, "#FFFFFF", 120)


def big_quote_title(video_path: Path, text: str, config: TitleConfig, output: Path) -> Path:
    """Pull quote appears in editorial style.

    Args:
        video_path: Source video file.
        text: Quote text to render.
        config: Render configuration.
        output: Output file path.

    Returns:
        Path to the rendered output file.
    """
    return _apply(video_path, text, "fade_in", config, output, "#FFFFFF", 80)


def legal_citation_caption(video_path: Path, text: str, config: TitleConfig, output: Path) -> Path:
    """Structured citation/case reference overlay.

    Args:
        video_path: Source video file.
        text: Citation text to render.
        config: Render configuration.
        output: Output file path.

    Returns:
        Path to the rendered output file.
    """
    return _apply(video_path, text, "fade_in", config, output, "#CCCCCC", 36)


def document_stamp_text(video_path: Path, text: str, config: TitleConfig, output: Path) -> Path:
    """Stamped label such as APPROVED/DRAFT.

    Args:
        video_path: Source video file.
        text: Stamp text to render.
        config: Render configuration.
        output: Output file path.

    Returns:
        Path to the rendered output file.
    """
    return _apply(video_path, text, "fade_in", config, output, "#FF0000", 96)


TYPOGRAPHIC_DISPATCH: dict[str, object] = {
    "stacked_title": stacked_title,
    "split_typography": split_typography,
    "text_behind_subject": text_behind_subject,
    "text_around_object": text_around_object,
    "vertical_text": vertical_text,
    "circular_badge_text": circular_badge_text,
    "grid_text": grid_text,
    "poster_title_lockup": poster_title_lockup,
    "credit_block": credit_block,
    "end_credits_roll": end_credits_roll,
    "title_crawl": title_crawl,
    "split_screen_labels": split_screen_labels,
    "map_label_text": map_label_text,
    "data_label_overlay": data_label_overlay,
    "infographic_text": infographic_text,
    "number_counter": number_counter,
    "percentage_counter": percentage_counter,
    "big_quote_title": big_quote_title,
    "legal_citation_caption": legal_citation_caption,
    "document_stamp_text": document_stamp_text,
}
