# Filepath: title_fx/styles/loader.py
# Condensed Description: Catalog loader — reads title_catalog.json and provides lookup helpers
# Architecture Layer: Library
# Environment: Both
# Script Hierarchy: load_catalog, list_titles, get_title_info, is_deferred
# Dependencies: Internal: title_fx.exceptions; External: importlib.resources, json, logging
# Exposes: load_catalog, list_titles, get_title_info, is_deferred
# Configuration: None
from __future__ import annotations

import json
import logging

from title_fx.exceptions import UnknownStyleError

logger = logging.getLogger(__name__)

_CATALOG_CACHE: dict | None = None


def load_catalog() -> dict:
    """Return the full catalog dict loaded from title_catalog.json.

    Returns:
        The parsed catalog dictionary with a "transitions" list.
    """
    global _CATALOG_CACHE  # noqa: PLW0603
    if _CATALOG_CACHE is not None:
        return _CATALOG_CACHE

    try:
        from importlib.resources import files

        data_pkg = files("title_fx.data")
        catalog_text = (data_pkg / "title_catalog.json").read_text(encoding="utf-8")
    except Exception:
        # Fallback: locate via __file__
        import pathlib

        catalog_path = pathlib.Path(__file__).parent.parent / "data" / "title_catalog.json"
        catalog_text = catalog_path.read_text(encoding="utf-8")

    _CATALOG_CACHE = json.loads(catalog_text)
    logger.debug("Loaded title catalog: %d entries", len(_CATALOG_CACHE.get("transitions", [])))
    return _CATALOG_CACHE


def list_titles(include_deferred: bool = False) -> list[str]:
    """Return active (or all) title style slugs from the catalog.

    Args:
        include_deferred: When True, deferred v0.2 slugs are included.

    Returns:
        Alphabetically sorted list of slug strings.
    """
    catalog = load_catalog()
    slugs: list[str] = []
    for entry in catalog.get("transitions", []):
        if not include_deferred and entry.get("status") == "deferred_v0_2":
            continue
        slugs.append(entry["slug"])
    return sorted(slugs)


def get_title_info(slug: str) -> dict:
    """Return the catalog entry dict for the given slug.

    Args:
        slug: The effect slug to look up.

    Returns:
        The catalog entry dict.

    Raises:
        UnknownStyleError: If the slug is not present in the catalog.
    """
    catalog = load_catalog()
    for entry in catalog.get("transitions", []):
        if entry["slug"] == slug:
            return entry
    raise UnknownStyleError(slug)


def is_deferred(slug: str) -> bool:
    """Return True if the given slug is a deferred v0.2 effect.

    Args:
        slug: The effect slug to check.

    Returns:
        True if the slug status is "deferred_v0_2".

    Raises:
        UnknownStyleError: If the slug is not in the catalog at all.
    """
    entry = get_title_info(slug)
    return entry.get("status") == "deferred_v0_2"
