# Filepath: title_fx/styles/stub_3d.py
# Condensed Description: Stub functions for the 15 deferred advanced-3D title styles
# Architecture Layer: Library
# Environment: Both
# Script Hierarchy: extruded_3d_text, beveled_3d_text, fly_through_text_3d, flip_board_3d,
#   cube_text_3d, parallax_title, depth_of_field_title, ar_floating_label,
#   perspective_road_text, curved_surface_text, book_page_text, glass_refraction_text,
#   shadow_catcher_text, camera_tracked_title, lower_third_3d, DEFERRED_3D_SLUGS, DEFERRED_DISPATCH
# Dependencies: Internal: None; External: None
# Exposes: DEFERRED_3D_SLUGS, DEFERRED_DISPATCH
# Configuration: None
from __future__ import annotations

_ISSUES_URL = "https://github.com/tomastimelock/title-fx/issues"

DEFERRED_3D_SLUGS: list[str] = [
    "extruded_3d_text",
    "beveled_3d_text",
    "3d_fly_through_text",
    "3d_flip_board",
    "3d_cube_text",
    "parallax_title",
    "depth_of_field_title",
    "ar_floating_label",
    "perspective_road_text",
    "curved_surface_text",
    "book_page_text",
    "glass_refraction_text",
    "shadow_catcher_text",
    "camera_tracked_title",
    "3d_lower_third",
]

_ALTERNATIVES: dict[str, list[str]] = {
    "extruded_3d_text": ["superhero_emblem_title", "trailer_gold_title"],
    "beveled_3d_text": ["metal_bevel_title", "superhero_emblem_title"],
    "3d_fly_through_text": ["epic_push_in", "hero_title_slam"],
    "3d_flip_board": ["kinetic_pop", "bounce_text"],
    "3d_cube_text": ["kinetic_pop", "epic_push_in"],
    "parallax_title": ["stacked_title", "split_typography"],
    "depth_of_field_title": ["dark_prestige_title", "cinematic_fade_up"],
    "ar_floating_label": ["documentary_lower_third", "map_label_text"],
    "perspective_road_text": ["title_crawl", "stacked_title"],
    "curved_surface_text": ["circular_badge_text", "vertical_text"],
    "book_page_text": ["chapter_card", "big_quote_title"],
    "glass_refraction_text": ["cinematic_fade_up", "dark_prestige_title"],
    "shadow_catcher_text": ["dark_prestige_title", "cinematic_fade_up"],
    "camera_tracked_title": ["documentary_lower_third", "map_label_text"],
    "3d_lower_third": ["documentary_lower_third", "news_headline_strap"],
}


def _make_msg(slug: str, display_name: str) -> str:
    alts = _ALTERNATIVES.get(slug, [])
    alt_str = ", ".join(f"'{a}'" for a in alts[:2])
    return (
        f"title-fx style '{slug}' ({display_name}) requires Blender Python integration, "
        f"planned for v0.2. Track at {_ISSUES_URL}. "
        f"For v0.1 alternatives, try: {alt_str}."
    )


def extruded_3d_text(*args: object, **kwargs: object) -> None:
    """Deferred to v0.2: requires Blender Python integration."""
    raise NotImplementedError(_make_msg("extruded_3d_text", "Extruded 3D Text"))


def beveled_3d_text(*args: object, **kwargs: object) -> None:
    """Deferred to v0.2: requires Blender Python integration."""
    raise NotImplementedError(_make_msg("beveled_3d_text", "Beveled 3D Text"))


def fly_through_text_3d(*args: object, **kwargs: object) -> None:
    """Deferred to v0.2: requires Blender Python integration."""
    raise NotImplementedError(_make_msg("3d_fly_through_text", "3D Fly Through Text"))


def flip_board_3d(*args: object, **kwargs: object) -> None:
    """Deferred to v0.2: requires Blender Python integration."""
    raise NotImplementedError(_make_msg("3d_flip_board", "3D Flip Board"))


def cube_text_3d(*args: object, **kwargs: object) -> None:
    """Deferred to v0.2: requires Blender Python integration."""
    raise NotImplementedError(_make_msg("3d_cube_text", "3D Cube Text"))


def parallax_title(*args: object, **kwargs: object) -> None:
    """Deferred to v0.2: requires Blender Python integration."""
    raise NotImplementedError(_make_msg("parallax_title", "Parallax Title"))


def depth_of_field_title(*args: object, **kwargs: object) -> None:
    """Deferred to v0.2: requires Blender Python integration."""
    raise NotImplementedError(_make_msg("depth_of_field_title", "Depth of Field Title"))


def ar_floating_label(*args: object, **kwargs: object) -> None:
    """Deferred to v0.2: requires OpenCV tracking + Blender integration."""
    raise NotImplementedError(_make_msg("ar_floating_label", "AR Floating Label"))


def perspective_road_text(*args: object, **kwargs: object) -> None:
    """Deferred to v0.2: requires OpenCV homography / Blender."""
    raise NotImplementedError(_make_msg("perspective_road_text", "Perspective Road Text"))


def curved_surface_text(*args: object, **kwargs: object) -> None:
    """Deferred to v0.2: requires Blender cylinder/sphere geometry."""
    raise NotImplementedError(_make_msg("curved_surface_text", "Curved Surface Text"))


def book_page_text(*args: object, **kwargs: object) -> None:
    """Deferred to v0.2: requires Blender page-flip mesh animation."""
    raise NotImplementedError(_make_msg("book_page_text", "Book Page Text"))


def glass_refraction_text(*args: object, **kwargs: object) -> None:
    """Deferred to v0.2: requires Blender displacement/refraction shader."""
    raise NotImplementedError(_make_msg("glass_refraction_text", "Glass Refraction Text"))


def shadow_catcher_text(*args: object, **kwargs: object) -> None:
    """Deferred to v0.2: requires Blender shadow catcher integration."""
    raise NotImplementedError(_make_msg("shadow_catcher_text", "Shadow Catcher Text"))


def camera_tracked_title(*args: object, **kwargs: object) -> None:
    """Deferred to v0.2: requires camera tracking data export."""
    raise NotImplementedError(_make_msg("camera_tracked_title", "Camera Tracked Title"))


def lower_third_3d(*args: object, **kwargs: object) -> None:
    """Deferred to v0.2: requires Blender render pipeline."""
    raise NotImplementedError(_make_msg("3d_lower_third", "3D Lower Third"))


DEFERRED_DISPATCH: dict[str, object] = {
    "extruded_3d_text": extruded_3d_text,
    "beveled_3d_text": beveled_3d_text,
    "3d_fly_through_text": fly_through_text_3d,
    "3d_flip_board": flip_board_3d,
    "3d_cube_text": cube_text_3d,
    "parallax_title": parallax_title,
    "depth_of_field_title": depth_of_field_title,
    "ar_floating_label": ar_floating_label,
    "perspective_road_text": perspective_road_text,
    "curved_surface_text": curved_surface_text,
    "book_page_text": book_page_text,
    "glass_refraction_text": glass_refraction_text,
    "shadow_catcher_text": shadow_catcher_text,
    "camera_tracked_title": camera_tracked_title,
    "3d_lower_third": lower_third_3d,
}
