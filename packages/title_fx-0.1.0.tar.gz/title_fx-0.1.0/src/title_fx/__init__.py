# Filepath: title_fx/__init__.py
# Condensed Description: Public package surface for title-fx
# Architecture Layer: Library
# Environment: Both
# Script Hierarchy: __version__, apply_title, lower_third, end_credits, chapter_card,
#   list_titles, get_title_info
# Dependencies: Internal: title_fx.api; External: None
# Exposes: __version__, apply_title, lower_third, end_credits, chapter_card,
#   list_titles, get_title_info
# Configuration: None
from __future__ import annotations

__version__ = "0.1.0"

from title_fx.api import (
    apply_title,
    chapter_card,
    end_credits,
    get_title_info,
    list_titles,
    lower_third,
)

__all__ = [
    "__version__",
    "apply_title",
    "lower_third",
    "end_credits",
    "chapter_card",
    "list_titles",
    "get_title_info",
]
