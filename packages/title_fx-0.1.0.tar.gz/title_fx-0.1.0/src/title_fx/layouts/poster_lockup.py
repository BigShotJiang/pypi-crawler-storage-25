# Filepath: title_fx/layouts/poster_lockup.py
# Condensed Description: Multi-tier poster title lockup renderer
# Architecture Layer: Library
# Environment: Both
# Script Hierarchy: render_poster_lockup
# Dependencies: Internal: None; External: pathlib, text_fx (lazy)
# Exposes: render_poster_lockup
# Configuration: None
from __future__ import annotations

import logging
from pathlib import Path

logger = logging.getLogger(__name__)


def _simple_apply(
    video_path: Path,
    text: str,
    effect: str,
    config: object,
    output_path: Path,
) -> Path:
    """Thin wrapper over text_fx.apply_text_effect.

    Args:
        video_path: Source video file.
        text: Text string to render.
        effect: text-fx effect slug.
        config: TitleConfig instance.
        output_path: Destination file path.

    Returns:
        The output_path on success.
    """
    import text_fx  # lazy import

    text_fx.apply_text_effect(
        video=str(video_path),
        text=text,
        effect=effect,
        output=str(output_path),
        duration=getattr(config, "duration", 3.0),
        start_time=getattr(config, "start_time", 0.0),
        color=getattr(config, "color", None) or "#FFFFFF",
        font_size=getattr(config, "font_size", None) or 100,
    )
    return output_path


def render_poster_lockup(
    video_path: Path,
    text: str,
    config: object,
    output_path: Path,
) -> Path:
    """Render a structured film-poster title lockup.

    Args:
        video_path: Source video file.
        text: Title text to render.
        config: TitleConfig instance.
        output_path: Destination file path.

    Returns:
        The output_path on success.
    """
    logger.debug("render_poster_lockup: '%s' onto %s", text, video_path)
    return _simple_apply(video_path, text, "fade_in", config, output_path)
