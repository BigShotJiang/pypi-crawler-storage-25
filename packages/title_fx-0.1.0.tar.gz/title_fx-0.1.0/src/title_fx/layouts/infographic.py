# Filepath: title_fx/layouts/infographic.py
# Condensed Description: Infographic text and number-counter layout renderers
# Architecture Layer: Library
# Environment: Both
# Script Hierarchy: render_number_counter, render_infographic_text
# Dependencies: Internal: None; External: pathlib, text_fx (lazy)
# Exposes: render_number_counter, render_infographic_text
# Configuration: None
from __future__ import annotations

import logging
from pathlib import Path

logger = logging.getLogger(__name__)


def render_number_counter(
    video_path: Path,
    start: int,
    end: int,
    suffix: str,
    config: object,
    output_path: Path,
) -> Path:
    """Render a number counter that displays the final value with optional suffix.

    The current implementation displays the final ``end`` value with ``suffix``
    appended; animated per-frame counting is a v0.2 enhancement.

    Args:
        video_path: Source video file.
        start: Starting integer value (reserved for future animated counting).
        end: Final integer value to display.
        suffix: String appended to the number (e.g. "%", "K", "M").
        config: TitleConfig instance.
        output_path: Destination file path.

    Returns:
        The output_path on success.
    """
    import text_fx  # lazy import

    display_text = f"{end}{suffix}"
    logger.debug("render_number_counter: '%s' onto %s", display_text, video_path)
    text_fx.apply_text_effect(
        video=str(video_path),
        text=display_text,
        effect="fade_in",
        output=str(output_path),
        duration=getattr(config, "duration", 3.0),
        start_time=getattr(config, "start_time", 0.0),
        color=getattr(config, "color", None) or "#FFFFFF",
        font_size=getattr(config, "font_size", None) or 120,
    )
    return output_path


def render_infographic_text(
    video_path: Path,
    text: str,
    config: object,
    output_path: Path,
) -> Path:
    """Render structured explanatory infographic text.

    Args:
        video_path: Source video file.
        text: Infographic label or data string to render.
        config: TitleConfig instance.
        output_path: Destination file path.

    Returns:
        The output_path on success.
    """
    import text_fx  # lazy import

    logger.debug("render_infographic_text: '%s' onto %s", text, video_path)
    text_fx.apply_text_effect(
        video=str(video_path),
        text=text,
        effect="fade_in",
        output=str(output_path),
        duration=getattr(config, "duration", 3.0),
        start_time=getattr(config, "start_time", 0.0),
        color=getattr(config, "color", None) or "#FFFFFF",
        font_size=getattr(config, "font_size", None) or 72,
    )
    return output_path
