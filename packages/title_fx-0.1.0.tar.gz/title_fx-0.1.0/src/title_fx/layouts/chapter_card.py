# Filepath: title_fx/layouts/chapter_card.py
# Condensed Description: Full-screen chapter title card renderer backed by text-fx
# Architecture Layer: Library
# Environment: Both
# Script Hierarchy: render_chapter_card
# Dependencies: Internal: title_fx.exceptions; External: pathlib, tempfile, subprocess
# Exposes: render_chapter_card
# Configuration: None
from __future__ import annotations

import logging
import subprocess
import tempfile
from pathlib import Path

from title_fx.exceptions import CompositionError

logger = logging.getLogger(__name__)


def render_chapter_card(
    text: str,
    background: object,
    config: object,
    output_path: Path,
) -> Path:
    """Render a full-screen chapter title card.

    Creates a solid-colour background video then applies a text-fx overlay
    to produce the chapter card.  When ``background`` is a hex colour string
    it is used directly; otherwise black is used as a fallback.

    Args:
        text: Chapter title text.
        background: A CSS hex colour string ("#RRGGBB"), an image path, or a
            video path.  Non-hex values fall back to black.
        config: TitleConfig instance with duration, color, font_size, etc.
        output_path: Destination file path for the rendered card.

    Returns:
        The output_path on success.

    Raises:
        CompositionError: If the ffmpeg background-generation step fails.
    """
    import text_fx  # lazy import

    duration: float = getattr(config, "duration", 4.0)
    color: str = getattr(config, "color", None) or "#FFFFFF"
    font_size: int = getattr(config, "font_size", None) or 120

    if isinstance(background, str) and background.startswith("#"):
        bg_hex = background.lstrip("#")
    else:
        logger.debug("background value '%s' is not a hex colour; using black", background)
        bg_hex = "000000"

    w, h = 1920, 1080

    with tempfile.TemporaryDirectory() as td:
        td_path = Path(td)
        bg_video = td_path / "bg.mp4"

        bg_cmd = [
            "ffmpeg",
            "-y",
            "-f",
            "lavfi",
            "-i",
            f"color=c=0x{bg_hex}:size={w}x{h}:rate=30:duration={duration}",
            "-vcodec",
            "libx264",
            "-pix_fmt",
            "yuv420p",
            str(bg_video),
        ]
        logger.debug("Generating chapter-card background: %s", " ".join(bg_cmd))
        try:
            subprocess.run(bg_cmd, check=True, capture_output=True)
        except subprocess.CalledProcessError as exc:
            raise CompositionError(
                f"ffmpeg background generation failed: {exc.stderr.decode(errors='replace')}"
            ) from exc

        logger.debug("Applying text overlay for chapter card")
        text_fx.apply_text_effect(
            video=str(bg_video),
            text=text,
            effect="fade_in",
            output=str(output_path),
            duration=duration,
            color=color,
            font_size=font_size,
        )

    return output_path
