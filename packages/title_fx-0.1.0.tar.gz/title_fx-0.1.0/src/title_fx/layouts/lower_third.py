# Filepath: title_fx/layouts/lower_third.py
# Condensed Description: Documentary lower-third renderer using text-fx for name and title overlays
# Architecture Layer: Library
# Environment: Both
# Script Hierarchy: render_lower_third
# Dependencies: Internal: title_fx.config; External: pathlib, text_fx (lazy)
# Exposes: render_lower_third
# Configuration: None
from __future__ import annotations

import logging
from pathlib import Path

logger = logging.getLogger(__name__)


def render_lower_third(
    video_path: Path,
    name: str,
    title: str,
    config: object,
    output_path: Path,
) -> Path:
    """Render a documentary lower third with name and title text overlaid.

    Uses text-fx to position the name and title in the lower portion of the
    frame via successive apply_text_effect calls rather than drawing bars
    with a filter_complex pipeline.

    Args:
        video_path: Source video file path.
        name: Primary name string (e.g. person name).
        title: Secondary title or role string.
        config: TitleConfig instance with render parameters.
        output_path: Destination output file path.

    Returns:
        The output path after both overlays have been applied.
    """
    import text_fx  # lazy import

    duration: float = getattr(config, "duration", 4.0)
    start_time: float = getattr(config, "start_time", 0.0)
    color: str = getattr(config, "color", None) or "#FFFFFF"
    font_size: int = getattr(config, "font_size", None) or 72

    # First pass: overlay the name text
    import tempfile

    with tempfile.NamedTemporaryFile(suffix=".mp4", delete=False) as tmp:
        interim_path = Path(tmp.name)

    logger.debug("render_lower_third: applying name overlay to %s", video_path)
    text_fx.apply_text_effect(
        video=str(video_path),
        text=name,
        effect="slide_left_text",
        output=str(interim_path),
        duration=duration,
        start_time=start_time,
        color=color,
        font_size=font_size,
    )

    # Second pass: overlay the title text slightly smaller
    title_font_size = max(24, int(font_size * 0.65))
    logger.debug("render_lower_third: applying title overlay to %s", interim_path)
    text_fx.apply_text_effect(
        video=str(interim_path),
        text=title,
        effect="slide_left_text",
        output=str(output_path),
        duration=duration,
        start_time=start_time,
        color=color,
        font_size=title_font_size,
    )

    try:
        interim_path.unlink(missing_ok=True)
    except OSError as exc:
        logger.warning("Could not remove interim file %s: %s", interim_path, exc)

    return output_path
