# Filepath: title_fx/layouts/credit_roll.py
# Condensed Description: Scrolling end-credits renderer that encodes a long PIL canvas via ffmpeg
# Architecture Layer: Library
# Environment: Both
# Script Hierarchy: render_credit_roll
# Dependencies: Internal: title_fx.exceptions; External: pathlib, tempfile, subprocess,
#   PIL (Pillow), ffmpeg-python (lazy)
# Exposes: render_credit_roll
# Configuration: None
from __future__ import annotations

import logging
import subprocess
import tempfile
from pathlib import Path

from PIL import Image, ImageDraw

from title_fx.exceptions import CompositionError

logger = logging.getLogger(__name__)

_FPS = 30


def render_credit_roll(
    video_path: Path,
    crew_data: list[dict],
    config: object,
    output_path: Path,
) -> Path:
    """Render scrolling end credits over a base video.

    Builds a tall PIL canvas containing all credit groups, then encodes the
    scroll animation via ffmpeg using a frame-sequence approach.

    Args:
        video_path: Base video to composite credits onto.
        crew_data: List of group dicts with "heading" and "entries" keys.
        config: TitleConfig with duration, video_codec, etc.
        output_path: Destination file path for the composited video.

    Returns:
        The output_path on success.

    Raises:
        CompositionError: If the ffmpeg encode step fails.
    """
    w, h = 1920, 1080
    line_h = 60
    heading_h = 80

    total_lines = sum(1 + len(g.get("entries", [])) + 1 for g in crew_data) + 4
    total_h = max(h * 2, total_lines * line_h + heading_h * max(1, len(crew_data)))

    canvas = Image.new("RGBA", (w, total_h), (0, 0, 0, 0))
    draw = ImageDraw.Draw(canvas)
    y = h  # start entries below the first visible frame

    for group in crew_data:
        heading = group.get("heading", "")
        entries = group.get("entries", [])
        draw.text((w // 2, y), heading.upper(), fill=(255, 255, 255, 255), anchor="mm")
        y += heading_h
        for entry in entries:
            if isinstance(entry, dict):
                text = f"{entry.get('role', '')}  {entry.get('actor', '')}".strip()
            else:
                text = str(entry)
            draw.text((w // 2, y), text, fill=(200, 200, 200, 220), anchor="mm")
            y += line_h
        y += line_h

    duration: float = getattr(config, "duration", 60.0)
    video_codec: str = getattr(config, "video_codec", "libx264")
    frames_count = max(1, int(duration * _FPS))
    scroll_range = max(1, total_h - h)

    with tempfile.TemporaryDirectory() as td:
        td_path = Path(td)
        for i in range(frames_count):
            progress = i / max(1, frames_count - 1)
            offset = int(progress * scroll_range)
            frame = canvas.crop((0, offset, w, offset + h))
            frame.save(td_path / f"frame_{i:06d}.png")

        overlay_vid = td_path / "credits_overlay.webm"
        encode_cmd = [
            "ffmpeg",
            "-y",
            "-framerate",
            str(_FPS),
            "-i",
            str(td_path / "frame_%06d.png"),
            "-vcodec",
            "libvpx-vp9",
            "-pix_fmt",
            "yuva420p",
            "-an",
            str(overlay_vid),
        ]
        logger.debug("Encoding credits overlay: %s", " ".join(encode_cmd))
        try:
            subprocess.run(encode_cmd, check=True, capture_output=True)
        except subprocess.CalledProcessError as exc:
            raise CompositionError(
                f"ffmpeg encode of credits overlay failed: {exc.stderr.decode(errors='replace')}"
            ) from exc

        composite_cmd = [
            "ffmpeg",
            "-y",
            "-i",
            str(video_path),
            "-i",
            str(overlay_vid),
            "-filter_complex",
            "[0:v][1:v]overlay=0:0[outv]",
            "-map",
            "[outv]",
            "-map",
            "0:a?",
            "-c:v",
            video_codec,
            "-c:a",
            "copy",
            str(output_path),
        ]
        logger.debug("Compositing credits: %s", " ".join(composite_cmd))
        try:
            subprocess.run(composite_cmd, check=True, capture_output=True)
        except subprocess.CalledProcessError as exc:
            raise CompositionError(
                f"ffmpeg composite of credits failed: {exc.stderr.decode(errors='replace')}"
            ) from exc

    return output_path
