# Filepath: title_fx/layouts/headline_strap.py
# Condensed Description: Broadcast-style news headline strap renderer
# Architecture Layer: Library
# Environment: Both
# Script Hierarchy: render_headline_strap
# Dependencies: Internal: None; External: pathlib, text_fx (lazy)
# Exposes: render_headline_strap
# Configuration: None
from __future__ import annotations

import logging
from pathlib import Path

logger = logging.getLogger(__name__)


def render_headline_strap(
    video_path: Path,
    text: str,
    config: object,
    output_path: Path,
) -> Path:
    """Render a broadcast-style news headline strap overlay.

    Args:
        video_path: Source video file.
        text: Headline text to render.
        config: TitleConfig instance.
        output_path: Destination file path.

    Returns:
        The output_path on success.
    """
    import text_fx  # lazy import

    logger.debug("render_headline_strap: '%s' onto %s", text, video_path)
    text_fx.apply_text_effect(
        video=str(video_path),
        text=text,
        effect="slide_left_text",
        output=str(output_path),
        duration=getattr(config, "duration", 3.0),
        start_time=getattr(config, "start_time", 0.0),
        color=getattr(config, "color", None) or "#FFFFFF",
        font_size=getattr(config, "font_size", None) or 72,
    )
    return output_path
