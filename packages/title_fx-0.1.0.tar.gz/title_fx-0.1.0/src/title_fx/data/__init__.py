# Filepath: title_fx/data/__init__.py
# Condensed Description: Data sub-package initialiser; marks directory as a package resource
# Architecture Layer: Library
# Environment: Both
# Script Hierarchy: None
# Dependencies: Internal: None; External: None
# Exposes: Nothing
# Configuration: None
from __future__ import annotations
