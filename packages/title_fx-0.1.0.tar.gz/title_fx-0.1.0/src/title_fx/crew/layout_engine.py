# Filepath: title_fx/crew/layout_engine.py
# Condensed Description: PIL-based layout engine that builds a tall credits canvas from roll groups
# Architecture Layer: Library
# Environment: Both
# Script Hierarchy: build_credits_image
# Dependencies: Internal: None; External: PIL (Pillow)
# Exposes: build_credits_image
# Configuration: None
from __future__ import annotations

import logging

from PIL import Image, ImageDraw

logger = logging.getLogger(__name__)


def build_credits_image(
    roll_groups: list[dict],
    canvas_width: int = 1920,
    line_height: int = 60,
    heading_height: int = 80,
) -> Image.Image:
    """Build a tall PIL RGBA canvas with all credit groups stacked vertically.

    The canvas is at least 2160 pixels tall (two 1080-pixel screens) so that
    the scroll animation has a full-height run-up before any text appears.

    Args:
        roll_groups: List of group dicts, each with optional "heading" and
            "entries" keys.  An entry may be a plain string or a dict with
            "role" and "actor" keys.
        canvas_width: Width in pixels of the output canvas.
        line_height: Pixel height allocated for each credit line.
        heading_height: Pixel height allocated for each group heading.

    Returns:
        A tall RGBA PIL Image containing all formatted credits.
    """
    total_lines = sum(1 + len(g.get("entries", [])) + 1 for g in roll_groups) + 4
    total_h = max(1080 * 2, total_lines * line_height + heading_height * max(1, len(roll_groups)))

    canvas = Image.new("RGBA", (canvas_width, total_h), (0, 0, 0, 0))
    draw = ImageDraw.Draw(canvas)
    y = 1080  # start entries below the first visible frame

    for group in roll_groups:
        heading = group.get("heading", "")
        entries = group.get("entries", [])

        if heading:
            draw.text(
                (canvas_width // 2, y),
                heading.upper(),
                fill=(255, 255, 255, 255),
                anchor="mm",
            )
        y += heading_height

        for entry in entries:
            if isinstance(entry, dict):
                text = f"{entry.get('role', '')}  {entry.get('actor', '')}".strip()
            else:
                text = str(entry)
            draw.text(
                (canvas_width // 2, y),
                text,
                fill=(200, 200, 200, 220),
                anchor="mm",
            )
            y += line_height

        y += line_height  # inter-group gap

    logger.debug(
        "build_credits_image: canvas %dx%d, %d groups", canvas_width, total_h, len(roll_groups)
    )
    return canvas
