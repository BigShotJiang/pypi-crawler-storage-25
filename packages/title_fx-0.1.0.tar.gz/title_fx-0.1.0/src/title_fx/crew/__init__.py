# Filepath: title_fx/crew/__init__.py
# Condensed Description: Crew sub-package initialiser (empty)
# Architecture Layer: Library
# Environment: Both
# Script Hierarchy: None
# Dependencies: Internal: None; External: None
# Exposes: Nothing
# Configuration: None
from __future__ import annotations
