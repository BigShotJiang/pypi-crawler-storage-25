# Filepath: title_fx/crew/parser.py
# Condensed Description: YAML crew-data parser with structured error handling
# Architecture Layer: Library
# Environment: Both
# Script Hierarchy: parse_crew_file, parse_crew_string, extract_roll_groups
# Dependencies: Internal: title_fx.exceptions; External: yaml, pathlib
# Exposes: parse_crew_file, parse_crew_string, extract_roll_groups
# Configuration: None
from __future__ import annotations

import logging
from pathlib import Path

from title_fx.exceptions import CrewParseError

logger = logging.getLogger(__name__)


def parse_crew_file(path: str | Path) -> dict:
    """Parse a crew YAML file and return the parsed dictionary.

    Args:
        path: Path to the YAML crew file.

    Returns:
        The parsed crew data as a dict.

    Raises:
        CrewParseError: If the file cannot be read or the YAML is invalid.
    """
    import yaml  # lazy import — not always needed

    try:
        with open(path, encoding="utf-8") as fh:
            data = yaml.safe_load(fh)
    except Exception as exc:
        raise CrewParseError(f"Failed to parse crew YAML file '{path}': {exc}") from exc

    if not isinstance(data, dict):
        raise CrewParseError(
            f"Crew YAML '{path}' must be a mapping at the top level, got {type(data).__name__}"
        )

    logger.debug("Parsed crew file '%s' successfully", path)
    return data


def parse_crew_string(content: str) -> dict:
    """Parse a crew YAML string and return the parsed dictionary.

    Args:
        content: YAML text content.

    Returns:
        The parsed crew data as a dict.

    Raises:
        CrewParseError: If the YAML is invalid or not a mapping.
    """
    import yaml  # lazy import

    try:
        data = yaml.safe_load(content)
    except Exception as exc:
        raise CrewParseError(f"Failed to parse crew YAML string: {exc}") from exc

    if not isinstance(data, dict):
        raise CrewParseError(
            f"Crew YAML must be a mapping at the top level, got {type(data).__name__}"
        )

    logger.debug("Parsed crew YAML string successfully")
    return data


def extract_roll_groups(crew_data: dict) -> list[dict]:
    """Extract the roll_groups list from a parsed crew dictionary.

    Args:
        crew_data: A dict previously returned by parse_crew_file or parse_crew_string.

    Returns:
        The list of roll-group dicts, or an empty list if the key is absent.
    """
    groups: list[dict] = crew_data.get("roll_groups", [])
    logger.debug("extract_roll_groups: found %d groups", len(groups))
    return groups
