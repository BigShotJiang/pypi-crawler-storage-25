# Filepath: title_fx/schema/parser.py
# Condensed Description: Lightweight LLM response parser for title-fx JSON payloads
# Architecture Layer: Schema
# Environment: Both
# Script Hierarchy: parse_llm_response
# Dependencies: Internal: None; External: json
# Exposes: parse_llm_response
# Configuration: None
from __future__ import annotations

import json
import logging

logger = logging.getLogger(__name__)


def parse_llm_response(response: str | dict) -> dict:
    """Parse a JSON string or pre-parsed dict returned by an LLM.

    Args:
        response: Either a JSON string or a dict that matches the TitleRequest
            schema.

    Returns:
        The parsed dict.

    Raises:
        ValueError: If ``response`` is a string that cannot be decoded as JSON.
        TypeError: If the decoded value is not a dict.
    """
    if isinstance(response, str):
        try:
            decoded = json.loads(response)
        except json.JSONDecodeError as exc:
            raise ValueError(f"LLM response is not valid JSON: {exc}") from exc
        if not isinstance(decoded, dict):
            raise TypeError(f"Expected a JSON object but got {type(decoded).__name__}")
        logger.debug("parse_llm_response: decoded JSON string successfully")
        return decoded

    if not isinstance(response, dict):
        raise TypeError(f"Expected str or dict, got {type(response).__name__}")

    logger.debug("parse_llm_response: received pre-parsed dict")
    return response
