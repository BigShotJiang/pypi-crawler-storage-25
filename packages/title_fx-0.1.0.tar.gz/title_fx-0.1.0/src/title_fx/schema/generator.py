# Filepath: title_fx/schema/generator.py
# Condensed Description: JSON Schema generator for title-fx style requests
# Architecture Layer: Schema
# Environment: Both
# Script Hierarchy: title_schema, schema_json
# Dependencies: Internal: title_fx.styles.loader; External: json
# Exposes: title_schema, schema_json
# Configuration: None
from __future__ import annotations

import json
import logging

logger = logging.getLogger(__name__)


def title_schema() -> dict:
    """Return a JSON Schema dict describing a valid TitleRequest.

    The "style" enum is populated at call time from the live catalog so that
    it always includes all 59 slugs (active and deferred).

    Returns:
        A JSON Schema dict with "type", "properties", and "required" keys.
    """
    from title_fx.styles.loader import list_titles  # lazy to avoid circular import

    all_slugs = list_titles(include_deferred=True)
    logger.debug("title_schema: building schema with %d slugs", len(all_slugs))

    return {
        "type": "object",
        "title": "TitleRequest",
        "properties": {
            "style": {
                "type": "string",
                "enum": all_slugs,
                "description": "Title style slug",
            },
            "text": {
                "type": "string",
                "description": "Text content to render",
            },
            "duration": {
                "type": "number",
                "minimum": 0.5,
                "description": "Duration of the title animation in seconds",
            },
            "start_time": {
                "type": "number",
                "minimum": 0,
                "description": "Start offset within the video in seconds",
            },
        },
        "required": ["style", "text"],
        "additionalProperties": False,
    }


def schema_json(pretty: bool = False) -> str:
    """Return the title request JSON Schema as a JSON string.

    Args:
        pretty: When True, indent with 2 spaces for human readability.

    Returns:
        JSON string representation of the schema.
    """
    return json.dumps(title_schema(), indent=2 if pretty else None)
