# Filepath: title_fx/api.py
# Condensed Description: Public high-level API for applying title styles to videos
# Architecture Layer: Library
# Environment: Both
# Script Hierarchy: apply_title, lower_third, end_credits, chapter_card, list_titles, get_title_info
# Dependencies: Internal: title_fx.config, title_fx.exceptions, title_fx.styles.loader,
#   title_fx.styles.trailer, title_fx.styles.layout, title_fx.styles.stub_3d,
#   title_fx.layouts.lower_third, title_fx.layouts.credit_roll, title_fx.layouts.chapter_card,
#   title_fx.crew.parser;
#   External: pathlib, tempfile, subprocess, logging
# Exposes: apply_title, lower_third, end_credits, chapter_card, list_titles, get_title_info
# Configuration: None
from __future__ import annotations

import logging
import tempfile
from pathlib import Path

from title_fx.config import TitleConfig
from title_fx.exceptions import UnknownStyleError

logger = logging.getLogger(__name__)


def _resolve_output(
    source: str | Path | None,
    output: str | Path | None,
    suffix: str = "_title",
) -> Path:
    """Derive an output path from source path when output is not specified.

    Args:
        source: Input video path, used to build a default output name.
        output: Explicit output path; returned as-is when provided.
        suffix: String appended before the extension when deriving the name.

    Returns:
        A resolved output Path.
    """
    if output is not None:
        return Path(output)
    if source is not None:
        src = Path(source)
        return src.with_stem(f"{src.stem}{suffix}")
    # No input either — generate a temp path
    with tempfile.NamedTemporaryFile(suffix=".mp4", delete=False) as tmp:
        return Path(tmp.name)


def apply_title(
    video: str | Path,
    text: str,
    style: str,
    duration: float = 3.0,
    start_time: float = 0.0,
    output: str | Path | None = None,
    config: TitleConfig | None = None,
    **kwargs: object,
) -> Path:
    """Apply a named title style to a video and return the output path.

    Deferred 3D styles raise ``NotImplementedError`` directly — callers that
    want a user-friendly message should catch that and inspect the message text.

    Args:
        video: Path to the source video file.
        text: Title text string to render.
        style: Catalog slug identifying the desired title style.
        duration: Animation duration in seconds (overridden by config if provided).
        start_time: Start offset within the video in seconds (overridden by config).
        output: Output file path.  Derived from ``video`` when None.
        config: Pre-built TitleConfig; constructed from remaining kwargs when None.
        **kwargs: Extra keyword arguments forwarded to TitleConfig.

    Returns:
        Path to the rendered output file.

    Raises:
        UnknownStyleError: If the slug is not present in the catalog.
        NotImplementedError: If the slug is a deferred v0.2 3D style.
    """
    from title_fx.styles.layout import TYPOGRAPHIC_DISPATCH
    from title_fx.styles.loader import is_deferred
    from title_fx.styles.stub_3d import DEFERRED_DISPATCH
    from title_fx.styles.trailer import CINEMATIC_DISPATCH

    # Validate slug against catalog (raises UnknownStyleError if absent)
    deferred = is_deferred(style)

    if deferred:
        stub_fn = DEFERRED_DISPATCH[style]
        stub_fn()  # always raises NotImplementedError
        # Unreachable, but satisfies the type checker
        raise NotImplementedError(f"Deferred style: {style}")  # pragma: no cover

    if config is None:
        config = TitleConfig(
            style=style,
            duration=duration,
            start_time=start_time,
            **kwargs,
        )

    output_path = _resolve_output(video, output)
    video_path = Path(video)

    dispatch = {**CINEMATIC_DISPATCH, **TYPOGRAPHIC_DISPATCH}
    recipe_fn = dispatch.get(style)

    if recipe_fn is None:
        raise UnknownStyleError(style)

    logger.debug("apply_title: style='%s' text='%s' -> %s", style, text, output_path)
    return recipe_fn(video_path, text, config, output_path)  # type: ignore[operator]


def lower_third(
    video: str | Path,
    name: str,
    title: str,
    style: str = "documentary_lower_third",
    duration: float = 4.0,
    start_time: float = 0.0,
    output: str | Path | None = None,
    config: TitleConfig | None = None,
) -> Path:
    """Render a lower third with name and title text overlaid on the video.

    Args:
        video: Path to the source video file.
        name: Primary name string (e.g. person's name).
        title: Secondary title or role string.
        style: Title style slug (defaults to "documentary_lower_third").
        duration: Duration in seconds.
        start_time: Start offset in seconds.
        output: Output file path.
        config: Pre-built TitleConfig.

    Returns:
        Path to the rendered output file.
    """
    from title_fx.layouts.lower_third import render_lower_third

    if config is None:
        config = TitleConfig(
            style=style,
            duration=duration,
            start_time=start_time,
        )

    output_path = _resolve_output(video, output, suffix="_lower_third")
    logger.debug("lower_third: name='%s' title='%s' -> %s", name, title, output_path)
    return render_lower_third(Path(video), name, title, config, output_path)


def end_credits(
    crew_data: str | Path | dict,
    duration: float = 60.0,
    style: str = "end_credits_roll",
    output: str | Path | None = None,
    video: str | Path | None = None,
    config: TitleConfig | None = None,
) -> Path:
    """Render scrolling end credits and return the output path.

    When ``video`` is None a solid black background video is generated.

    Args:
        crew_data: Either a path to a YAML crew file, a raw YAML string, or a
            pre-parsed dict containing a "roll_groups" list.
        duration: Total scroll duration in seconds.
        style: Title style slug (reserved; currently ignored).
        output: Output file path.
        video: Optional base video to composite credits onto.
        config: Pre-built TitleConfig.

    Returns:
        Path to the rendered credits video.
    """
    import subprocess

    from title_fx.crew.parser import extract_roll_groups, parse_crew_file, parse_crew_string
    from title_fx.layouts.credit_roll import render_credit_roll

    if config is None:
        config = TitleConfig(style=style, duration=duration)

    # Parse crew data
    if isinstance(crew_data, dict):
        parsed = crew_data
    elif isinstance(crew_data, (str, Path)) and Path(str(crew_data)).exists():
        parsed = parse_crew_file(crew_data)
    else:
        parsed = parse_crew_string(str(crew_data))

    roll_groups = extract_roll_groups(parsed)

    output_path = _resolve_output(video, output, suffix="_credits")

    # If no base video is provided, generate a solid black background
    if video is None:
        with tempfile.NamedTemporaryFile(suffix=".mp4", delete=False) as tmp:
            bg_path = Path(tmp.name)
        bg_cmd = [
            "ffmpeg",
            "-y",
            "-f",
            "lavfi",
            "-i",
            f"color=c=black:size=1920x1080:rate=30:duration={duration}",
            "-vcodec",
            "libx264",
            "-pix_fmt",
            "yuv420p",
            str(bg_path),
        ]
        logger.debug("end_credits: generating black background video")
        subprocess.run(bg_cmd, check=True, capture_output=True)
        base_video = bg_path
    else:
        base_video = Path(video)

    logger.debug("end_credits: %d roll groups -> %s", len(roll_groups), output_path)
    return render_credit_roll(base_video, roll_groups, config, output_path)


def chapter_card(
    text: str,
    duration: float = 4.0,
    style: str = "chapter_card",
    background: str = "#000000",
    output: str | Path | None = None,
    config: TitleConfig | None = None,
) -> Path:
    """Render a full-screen chapter title card and return the output path.

    Args:
        text: Chapter title text.
        duration: Duration of the card in seconds.
        style: Title style slug (reserved for future variant support).
        background: Background colour as a CSS hex string.
        output: Output file path.
        config: Pre-built TitleConfig.

    Returns:
        Path to the rendered chapter card video.
    """
    from title_fx.layouts.chapter_card import render_chapter_card

    if config is None:
        config = TitleConfig(style=style, duration=duration)

    output_path = _resolve_output(None, output, suffix="_chapter")
    logger.debug("chapter_card: text='%s' background='%s' -> %s", text, background, output_path)
    return render_chapter_card(text, background, config, output_path)


def list_titles(include_deferred: bool = False) -> list[str]:
    """Return available title style slugs.

    Args:
        include_deferred: When True, deferred v0.2 slugs are included.

    Returns:
        Sorted list of slug strings.
    """
    from title_fx.styles.loader import list_titles as _list

    return _list(include_deferred=include_deferred)


def get_title_info(slug: str) -> dict:
    """Return the catalog entry for the given title style slug.

    Args:
        slug: The style slug to look up.

    Returns:
        The catalog entry dict.

    Raises:
        UnknownStyleError: If the slug is not in the catalog.
    """
    from title_fx.styles.loader import get_title_info as _get

    return _get(slug)
