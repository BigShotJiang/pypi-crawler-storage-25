# Scrapurrr Framework

Python library for building agentic web scraping and automation apps.

## Install

```bash
pip3 install scrapurrr
```

## Quick Start

```python
import asyncio
from pydantic import BaseModel
from scrapurrr import Scrapurrr

class Article(BaseModel):
    title: str
    author: str
    published: str

async def main():
    async with Scrapurrr(provider="gemini/gemini-2.0-flash", api_key="...") as scraper:
        article = await scraper.extract("https://example.com/article", Article)
        print(article.title)

asyncio.run(main())
```

## Extraction

### Single page

```python
class Product(BaseModel):
    name: str
    price: str
    rating: str

async with Scrapurrr(provider="ollama/llama3") as scraper:
    product = await scraper.extract("https://shop.com/item/42", Product)
```

### List of items

```python
async with Scrapurrr(provider="ollama/llama3") as scraper:
    jobs = await scraper.extract("https://jobs.example.com/python", list[Job])
```

### Batch (multiple URLs)

```python
async with Scrapurrr(provider="ollama/llama3") as scraper:
    products = await scraper.extract_many(
        urls, schema=Product, concurrency=10, deduplicate_by=["name"]
    )
```

### Paginated content

```python
async with Scrapurrr(provider="ollama/llama3") as scraper:
    all_products = await scraper.extract_all_pages(
        "https://shop.com/products?page=1",
        schema=list[Product],
        max_pages=20,
    )
```

### Custom CSS selectors

```python
from pydantic import BaseModel, Field

class Product(BaseModel):
    sku: str = Field(json_schema_extra={"css_selector": "[data-sku]"})
    title: str   # auto-detected
    price: str   # auto-detected
```

## Element Inspection

Extract CSS selectors, XPath, JS path, outerHTML, and computed styles for any element.

```python
async with Scrapurrr(provider="ollama/llama3") as scraper:
    # All elements
    elements = await scraper.extract_elements("https://shop.com")

    # Filter by tag or text
    buttons = await scraper.extract_elements("https://shop.com", tag="button")
    prices = await scraper.extract_elements("https://shop.com", text="price")

    # Single element
    el = await scraper.find_element("Add to Cart", url="https://shop.com")
    print(el.css)        # "button.add-to-cart"
    print(el.xpath)      # "//button[@class='add-to-cart']"
    print(el.full_xpath) # "/html/body/div[2]/main/button[3]"
    print(el.js_path)    # "document.querySelector('button.add-to-cart')"
    print(el.outer_html) # "<button class='add-to-cart'>Add to Cart</button>"
    print(el.styles)     # {"color": "white", "backgroundColor": "#1a73e8"}

    # Find by CSS or XPath
    el = await scraper.find_element(css="button.add-to-cart")
    el = await scraper.find_element(xpath="//button[@id='buy']")
```

### ElementCollection filtering

```python
elements = await scraper.extract_elements("https://shop.com")

elements.filter(tag="button")          # by tag
elements.filter(text="price")          # by text (substring, case-insensitive)
elements.filter(attr="data-testid")    # by attribute
elements.filter(tag="a", text="next")  # combined

elements.first()          # first element or None
elements.by_index(3)      # by element index
elements.to_list()        # list of dicts
len(elements)             # count
```

## Agent Mode

Autonomous navigation, clicking, scrolling, and form-filling across pages.

```python
class Flight(BaseModel):
    airline: str
    price: str
    departure: str

async with Scrapurrr(provider="gemini/gemini-2.0-flash", api_key="...") as scraper:
    flights = await scraper.agent(
        "find the 5 cheapest flights from Manila to Tokyo next week",
        schema=list[Flight],
        max_steps=30,
    )
```

### Streaming progress

```python
async for step in scraper.agent_stream(task="...", schema=list[Job], max_steps=25):
    print(f"Step {step.number}: {step.tool}({step.params})")
```

### Custom tools

```python
from pydantic import BaseModel, Field
from scrapurrr.agent.tools import Tool

class SearchParams(BaseModel):
    query: str = Field(description="Search query")

async def web_search(params: SearchParams) -> str:
    return f"Results for: {params.query}"

scraper.register_tool(Tool(
    name="web_search",
    description="Search the web",
    parameters=SearchParams,
    execute=web_search,
))
```

## Authentication

### Login

```python
await scraper.login(
    url="https://example.com/login",
    credentials={"email": "user@example.com", "password": "secret"},
)

# Custom selectors
await scraper.login(
    url="https://example.com/login",
    credentials={"username": "admin", "password": "secret"},
    username_selector="#email-field",
    password_selector="#pass-field",
    submit_selector="#login-btn",
)
```

### Cookies

```python
await scraper.set_cookies([
    {"name": "session", "value": "abc", "domain": "example.com", "path": "/"}
])
cookies = await scraper.get_cookies()
```

## Providers

Provider strings follow LiteLLM format: `provider/model`.

```python
# Cloud providers
scraper = Scrapurrr(provider="gemini/gemini-2.0-flash", api_key="...")
scraper = Scrapurrr(provider="openai/gpt-4o", api_key="sk-...")
scraper = Scrapurrr(provider="anthropic/claude-sonnet-4-20250514", api_key="sk-ant-...")
scraper = Scrapurrr(provider="groq/llama-3.1-70b-versatile", api_key="gsk_...")

# Local (no key)
scraper = Scrapurrr(provider="ollama/llama3")

# Self-hosted
scraper = Scrapurrr(provider="openai/mistral-7b", base_url="http://localhost:8000/v1")
```

## Configuration

### YAML config file

```yaml
llm:
  provider: gemini/gemini-2.0-flash
  api_key: env:GEMINI_API_KEY

browser:
  headless: true
  stealth: basic          # off | basic | full
  mode: auto              # auto | always | never
  timeout: 30000
  max_retries: 3
  requests_per_second: 2.0

extraction:
  strategy: auto          # auto | css | llm | vision

agent:
  max_steps: 20
  timeout: 300

cache:
  enabled: true
  ttl: 300

respect_robots: true
```

```python
from pathlib import Path
scraper = Scrapurrr(config_path=Path("scrapurrr.yaml"))
```

Constructor arguments override the config file. `env:` prefix reads from environment variables.

## CLI Commands

```bash
chatpurrr                                        # interactive chat
scrapurrr extract "https://..." -s models:Product
scrapurrr extract "https://..." -s models:Product -o result.csv --format csv
scrapurrr agent "Collect top 10 products" -s models:Product --max-steps 30
scrapurrr batch urls.txt -s models:Product --concurrency 10 -o results.json
scrapurrr serve                                  # start MCP server
```

## MCP Server

```bash
scrapurrr serve
```

```json
{
  "mcpServers": {
    "scrapurrr": {
      "command": "scrapurrr-mcp"
    }
  }
}
```

## Troubleshooting

| Problem | Fix |
|---|---|
| Ollama connection refused | `ollama serve` then `ollama pull llama3` |
| Model not found | `ollama pull <model>` or `/model` to switch |
| CSS extraction wrong data | Add `css_selector` hints or set `strategy: llm` |
| Agent stuck/loops | Increase `max_steps`, use stronger model |
| Rate limited | Lower `requests_per_second`, set `stealth: full` |
| Empty content | Set `browser.mode: always` |
