# Chatpurrr

Interactive web scraping from your terminal.

## Setup

```bash
pip3 install scrapurrr
chatpurrr
```

First run walks you through model selection and API key setup. Config saves to `~/.scrapurrr.yaml` so you only do this once.

## How it works

Type natural language or direct commands. The browser stays open between messages.

```
> go to https://shop.example.com
Navigated to https://shop.example.com

> find "price"
Found 3 elements matching "price":
  [0] span "$29.99"
      css: span.product-price
      xpath: //span[@class='product-price']

> get xpath of all buttons
  [0] //button[@class='add-to-cart']    "Add to Cart"
  [1] //button[@id='search']            "Search"

> what products are on this page?
There are 4 products listed...

> /screenshot products.png
Saved to products.png

> exit
```

Direct commands run instantly without calling the LLM. Everything else goes through the LLM with full page context.

## Direct Commands

| Command | Example |
|---|---|
| `go to <url>` | `go to https://example.com` |
| `open <url>` | `open https://shop.com` |
| `find "<text>"` | `find "price"` |
| `find <text>` | `find add to cart` |
| `get xpath of all <tag>` | `get xpath of all buttons` |
| `get css of all <tag>` | `get css of all links` |
| `get elements` | `get elements` |
| `click <selector>` | `click button.buy-now` |
| `scroll up/down` | `scroll down` |
| `back` | `back` |

## Slash Commands

### Model and Config

| Command | Description |
|---|---|
| `/help` | Show all commands |
| `/model` | Switch LLM model (interactive picker) |
| `/key` | Update API key |
| `/provider <string>` | Set provider directly, e.g. `/provider ollama/llama3` |
| `/config` | Show current config |

### Browser

| Command | Description |
|---|---|
| `/headless` | Toggle headless/headed browser |
| `/stealth <level>` | Set stealth: `off`, `basic`, or `full` |
| `/mode <mode>` | Set browser mode: `auto`, `always`, or `never` |
| `/proxy <url>` | Set proxy, or `/proxy off` to clear |
| `/timeout <ms>` | Set page load timeout in milliseconds |
| `/useragent` | Show current user agent string |
| `/cookies` | Show all browser cookies as JSON |

### Session

| Command | Description |
|---|---|
| `/url` | Show current page URL |
| `/history` | Show conversation history |
| `/clear` | Clear conversation history |
| `/reset` | Reset session with a new browser page |

### Inspection

| Command | Description |
|---|---|
| `/elements` | List all visible elements with CSS and XPath |
| `/xpath <tag>` | Get XPaths, e.g. `/xpath button`, `/xpath a` |
| `/css <tag>` | Get CSS selectors, e.g. `/css input` |

### Output

| Command | Description |
|---|---|
| `/screenshot <file>` | Save screenshot, default `screenshot.png` |
| `/html <file>` | Save page HTML, default `page.html` |
| `/js <code>` | Run JavaScript on current page |
| `/export <file>` | Export conversation, default `chat_export.txt` |

### Exit

`exit`, `quit`, Ctrl+C, or Ctrl+D.

## Config File

Saved at `~/.scrapurrr.yaml`. Created automatically on first run.

```yaml
llm:
  provider: gemini/gemini-2.0-flash
  api_key: your-key-here

browser:
  headless: true
  stealth: basic
  mode: auto
  timeout: 30000
```

Slash commands that change config save to this file automatically. Browser settings take effect after `/reset`.

## Examples

### Scrape product data

```
> go to https://shop.example.com/products
> find "price"
> get xpath of all buttons
> /screenshot products.png
```

### Inspect a login form

```
> go to https://app.example.com/login
> /elements
> /xpath input
> /css button
```

### Debug anti-bot detection

```
> /stealth full
> /reset
> go to https://protected-site.com
> /useragent
> /cookies
> /js document.querySelector('#challenge')
```

### Export your work

```
> /export session.txt
> /html page.html
> /screenshot result.png
```
