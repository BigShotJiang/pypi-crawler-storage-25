# Scrapurrr Design Spec

**Date:** 2026-04-05
**Status:** Draft
**Author:** Klyne Chrysler C. Dotarot

## Overview

Scrapurrr is a Python library (`pip install scrapurrr`) for agentic web scraping with pluggable LLM providers. It supports cloud APIs (OpenAI, Anthropic, Google, Groq) and local models (Ollama, vLLM) through a unified interface. All output is schema-driven via Pydantic — no unstructured returns.

## Goals

- **Library-first** — developers `import scrapurrr` and integrate into their own systems
- **LLM-agnostic** — swap providers with one string change, local models are first-class
- **Schema-always** — every extraction returns typed Pydantic models
- **Cost-aware** — try free CSS/XPath extraction before falling back to LLM
- **Extensible** — protocols for providers, browser engines, extraction strategies, agent tools

## Non-Goals (v1)

- CLI interface (trivial to add later)
- Full browser interaction (click, type, fill forms) — architecture supports it, not shipping in v1
- CAPTCHA solving — users plug in their own via hooks
- Vision-based extraction — future, protocol is ready

---

## Public API

Two first-class primitives sharing the same internals:

```python
from scrapurrr import Scrapurrr
from pydantic import BaseModel

class Product(BaseModel):
    name: str
    price: float
    url: str

# Initialize
scraper = Scrapurrr(provider="ollama/llama3")
scraper = Scrapurrr(provider="openai/gpt-4o", api_key="sk-...")
scraper = Scrapurrr()  # reads scrapurrr.yaml

# Extractor — single page, schema-driven
products = await scraper.extract(
    "https://shop.com/products",
    schema=list[Product],
)

# Agent — autonomous multi-page, ReAct loop
results = await scraper.agent(
    "find all running shoes under $100 on nike.com",
    schema=list[Product],
    max_steps=20,
)

# Context manager for auto-cleanup
async with Scrapurrr(provider="ollama/llama3") as scraper:
    products = await scraper.extract(url, schema=ProductList)
```

### Configuration

Code-first with optional YAML defaults:

```yaml
# scrapurrr.yaml
llm:
  provider: ollama/llama3
  # api_key: env:OPENAI_API_KEY

browser:
  headless: true
  stealth: basic       # off | basic | full
  proxy: null
  timeout: 30000

extraction:
  strategy: auto        # auto | css | llm

agent:
  max_steps: 20
  timeout: 300
```

Code overrides config file. Config file overrides defaults.

### Schema Handling

Both `extract()` and `agent()` accept `schema` as `type[BaseModel]` or generic types like `list[Product]`. Internally, `list[T]` is handled via Pydantic's `TypeAdapter` for validation, while the LLM prompt always receives the inner model's JSON Schema with instructions to return an array. The return type is always exactly what the user passed — `list[Product]` returns `list[Product]`, `Product` returns `Product`.

---

## Architecture

### Dual-Core Design

```
scrapurrr/
├── __init__.py              # Scrapurrr facade: extract(), agent()
├── config.py                # YAML loader + code overrides
├── exceptions.py            # Custom exception hierarchy
├── types.py                 # Shared protocols, frozen dataclasses
├── providers/
│   ├── __init__.py          # LLMProvider protocol
│   └── litellm.py           # LiteLLM wrapper (all providers)
├── browser/
│   ├── __init__.py          # BrowserEngine protocol
│   ├── engine.py            # Playwright lifecycle
│   └── stealth.py           # Header rotation, webdriver patch, delays
├── pipeline/
│   ├── __init__.py
│   ├── fetcher.py           # URL → raw HTML
│   ├── cleaner.py           # HTML → clean HTML
│   ├── markdown.py          # Clean HTML → markdown
│   └── chunker.py           # Markdown → chunks
├── extraction/
│   ├── __init__.py          # Strategy picker orchestrator
│   ├── css.py               # CSS/XPath rule-based (free, fast)
│   ├── llm.py               # LLM-based (schema → prompt → validate)
│   └── vision.py            # Screenshot + vision model (future stub)
├── agent/
│   ├── __init__.py          # Agent orchestrator
│   ├── loop.py              # ReAct: Think → Act → Observe
│   ├── tools.py             # Tool registry + built-in tools
│   └── memory.py            # Short-term memory per run
└── schemas/
    └── __init__.py           # Pydantic → JSON Schema → prompt utilities
```

### Data Flow — extract()

```
URL → Fetcher (Playwright) → Cleaner → Markdown → Chunker
  → Strategy Picker:
      ├─ CSS/XPath match? → Rule-based extract → Pydantic validate → return
      └─ No match → LLM extract per chunk → Merge → Pydantic validate → return
```

### Data Flow — agent()

```
Task + Schema → ReAct Loop:
  Think: LLM reasons about goal vs current state
  Act:   Execute chosen tool
  Observe: Update memory with result
  Loop until: schema populated OR max_steps OR stuck
→ Pydantic validate → return
```

The agent uses `extract()` as one of its tools — no duplication.

---

## Engineering Principles

### SOLID

- **Single Responsibility** — each module does one thing
- **Open/Closed** — extend via protocols, not modification
- **Liskov Substitution** — any LLMProvider implementation is interchangeable
- **Interface Segregation** — small focused protocols (LLMProvider, BrowserEngine, ExtractionStrategy)
- **Dependency Inversion** — high-level modules depend on protocols, wiring in Scrapurrr.__init__()

### Design Patterns

| Pattern | Where | Why |
|---|---|---|
| Facade | `Scrapurrr` class | Single entry point |
| Strategy | `extraction/` | CSS, LLM, Vision interchangeable |
| Chain of Responsibility | Pipeline stages | Fetcher → Cleaner → Markdown → Chunker |
| Registry | `agent/tools.py` | Dynamic tool discovery |
| Template Method | `agent/loop.py` | ReAct skeleton, customizable steps |
| Builder | Config loading | YAML → override → frozen config |

### Immutability

All pipeline data as frozen dataclasses:

```python
@dataclass(frozen=True)
class FetchResult:
    url: str
    html: str
    status: int
    headers: dict[str, str]

@dataclass(frozen=True)
class CleanResult:
    html: str
    markdown: str
    metadata: PageMetadata

@dataclass(frozen=True)
class ChunkResult:
    chunks: tuple[str, ...]
    source_url: str
```

No mutation in the pipeline. Each stage takes input, returns new output.

---

## LLM Provider System

### Protocol

```python
T = TypeVar("T", bound=BaseModel)

class LLMProvider(Protocol):
    async def extract_structured(
        self, content: str, schema: type[T], system_prompt: str | None = None,
    ) -> T: ...

    async def complete(
        self, prompt: str, system_prompt: str | None = None,
    ) -> str: ...

    @property
    def supports_vision(self) -> bool: ...

    async def extract_from_image(
        self, image: bytes, schema: type[T], system_prompt: str | None = None,
    ) -> T: ...
```

### Provider Strings (LiteLLM convention)

| Provider | String | Needs API Key |
|---|---|---|
| OpenAI | `openai/gpt-4o` | Yes |
| Anthropic | `anthropic/claude-3.5-sonnet` | Yes |
| Ollama | `ollama/llama3` | No |
| vLLM | `openai/model` + `base_url` | No |
| Groq | `groq/llama-3.1-70b` | Yes |
| Google | `gemini/gemini-1.5-pro` | Yes |
| AWS Bedrock | `bedrock/anthropic.claude-v2` | Via AWS creds |

### Schema → Prompt Strategy

1. Convert Pydantic → JSON Schema via `model_json_schema()`
2. Use provider's native structured output when available (OpenAI `response_format`, Anthropic tool use)
3. Fall back to prompt-based extraction + Pydantic validation for other providers
4. Retry once on validation failure with error fed back to LLM

---

## Browser Engine & Stealth

### Protocols

```python
class BrowserEngine(Protocol):
    async def launch(self) -> None: ...
    async def new_page(self) -> PageContext: ...
    async def close(self) -> None: ...

class PageContext(Protocol):
    async def navigate(self, url: str, wait_until: str = "domcontentloaded") -> None: ...
    async def get_html(self) -> str: ...
    async def screenshot(self) -> bytes: ...
    async def scroll(self, direction: str = "down") -> None: ...
    async def wait_for(self, selector: str, timeout: int = 10000) -> None: ...
    async def evaluate(self, js: str) -> Any: ...
```

### Stealth Levels

| Level | Behavior |
|---|---|
| `off` | Raw Playwright |
| `basic` (default) | Patch `navigator.webdriver`, random User-Agent, Accept-Language, randomized viewport |
| `full` | Basic + random delays, header rotation per request, WebGL/canvas fingerprint noise |

### Stealth Hooks (user-pluggable)

```python
class StealthHook(Protocol):
    async def on_before_navigate(self, page: PageContext, url: str) -> None: ...
    async def on_after_navigate(self, page: PageContext, url: str) -> None: ...
```

---

## Content Pipeline

### Stages

1. **Fetcher** — Playwright navigates to URL, returns raw HTML
2. **Cleaner** — strips `<script>`, `<style>`, `<nav>`, `<footer>`, ads, cookie banners. Preserves `<main>`, `<article>`, `<table>`
3. **Markdown** — HTML → markdown via markdownify. ~80% token reduction
4. **Chunker** — splits by headings (semantic), falls back to fixed-size with overlap. Only activates for large pages

### Extraction Strategies

**CSS Strategy** — field-name heuristics:
```python
FIELD_PATTERNS = {
    "price": ["[class*=price]", "[data-price]", ".cost", ".amount"],
    "title": ["h1", "h2", ".title", "[class*=title]", ".name"],
    "image": ["img[src]", "[class*=image] img"],
    "description": [".description", "[class*=desc]", "p.summary"],
    "rating": ["[class*=rating]", "[data-rating]"],
    "url": ["a[href]"],
}
```

If ALL schema fields matched with high confidence → extract without LLM (free, instant).
Otherwise → LLM extraction with schema prompt.

**LLM Strategy** — markdown + JSON Schema in prompt → structured output → Pydantic validate.

**Multi-chunk** — extract per chunk in parallel (`asyncio.gather`), merge, deduplicate, validate.

---

## Agent System

### ReAct Loop

```
Task + Schema → ReAct Loop:
  THINK:   LLM reasons (goal, memory, next action)
  ACT:     Execute chosen tool
  OBSERVE: Update memory
  CHECK:   schema populated? max_steps? stuck?
  └─ loop or return
```

### v1 Tools (read-only + extract)

| Tool | Description |
|---|---|
| `navigate` | Go to a URL |
| `scroll` | Scroll down/up |
| `extract` | Extract data from current page using schema |
| `wait` | Wait for selector or time |
| `read_page` | Get current page as markdown |
| `list_links` | Get all links with text |

### Custom Tool Registration

```python
scraper.register_tool(Tool(
    name="solve_captcha",
    description="Solve a CAPTCHA on the current page",
    parameters=CaptchaParams,
    execute=my_captcha_solver,
))
```

### Agent Memory

```python
@dataclass
class AgentMemory:
    goal: str
    schema: type[BaseModel]
    visited_urls: list[str]
    extracted_data: list[BaseModel]
    action_history: list[AgentAction]
    current_url: str | None
    current_page_summary: str | None
    step_count: int
```

Truncates older action history to stay within LLM context limits.

### Stuck Detection

- Same URL visited 3+ times
- Same tool + same params called 2+ times consecutively
- No new data extracted in last 5 steps

Raises `StuckError` with action history for debugging.

---

## Error Handling

```
ScrapurrError (base)
├── ConfigError
├── BrowserError
│   └── NavigationError
├── ExtractionError
│   ├── SchemaError
│   └── NoContentError
├── ProviderError
│   ├── RateLimitError
│   └── AuthError
└── AgentError
    ├── MaxStepsError
    └── StuckError
```

Retry with backoff at provider level only. Pipeline stages fail fast.

---

## Testing Strategy

- **Unit tests** — each module independently, mocked via protocols
- **Integration tests** — full pipeline with `pytest-httpserver` (local test server)
- **Contract tests** — LLM provider protocol compliance
- **Fixtures** — saved HTML pages + expected outputs for deterministic tests
- **Coverage** — 80%+ gate
- **Tools** — pytest, pytest-asyncio, ruff, mypy --strict

---

## Dependencies

### Core

```toml
dependencies = [
    "playwright>=1.40",
    "litellm>=1.0",
    "pydantic>=2.0",
    "pyyaml>=6.0",
    "markdownify>=0.13",
]
```

### Dev

```toml
[project.optional-dependencies]
dev = [
    "pytest>=8.0",
    "pytest-asyncio>=0.23",
    "ruff>=0.4",
    "mypy>=1.10",
    "coverage>=7.0",
    "pytest-httpserver>=1.0",
]
```

---

## Distribution

- **Install:** `pip install scrapurrr` then `playwright install chromium`
- **License:** MIT
- **Versioning:** SemVer, 0.x.y until API stable
- **Package layout:** `src/scrapurrr/` (src layout)
- **Single version source:** `pyproject.toml`
