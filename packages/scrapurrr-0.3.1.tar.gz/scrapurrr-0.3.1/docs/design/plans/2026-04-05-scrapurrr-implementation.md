# Scrapurrr Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Build scrapurrr — a Python library for agentic web scraping with pluggable LLM providers, schema-driven output, and a dual-core architecture (extractor + agent).

**Architecture:** Dual-core design with `extract()` for single-page schema-driven extraction and `agent()` for autonomous multi-page scraping via a ReAct loop. Both share a Playwright browser engine, LiteLLM provider layer, and content pipeline. All output is typed via Pydantic. Protocols enable swapping any component.

**Tech Stack:** Python 3.11+, Playwright, LiteLLM, Pydantic v2, PyYAML, markdownify, pytest, ruff, mypy

---

## File Map

| File | Responsibility |
|---|---|
| `pyproject.toml` | Package metadata, dependencies, tool config |
| `src/scrapurrr/__init__.py` | Public API: `Scrapurrr` facade class |
| `src/scrapurrr/exceptions.py` | Custom exception hierarchy |
| `src/scrapurrr/types.py` | Protocols (`LLMProvider`, `BrowserEngine`, `PageContext`, `ExtractionStrategy`, `StealthHook`), frozen dataclasses (`FetchResult`, `CleanResult`, `ChunkResult`, `PageMetadata`) |
| `src/scrapurrr/config.py` | `ScrapurrConfig` frozen dataclass, YAML loader, env var resolution, code overrides |
| `src/scrapurrr/schemas/__init__.py` | `SchemaHelper`: Pydantic → JSON Schema, list[T] handling via TypeAdapter, prompt generation |
| `src/scrapurrr/providers/__init__.py` | Re-export `LLMProvider` protocol |
| `src/scrapurrr/providers/litellm.py` | `LiteLLMProvider`: wraps litellm.acompletion, structured output, retry on validation failure |
| `src/scrapurrr/browser/__init__.py` | Re-export `BrowserEngine`, `PageContext` protocols |
| `src/scrapurrr/browser/engine.py` | `PlaywrightEngine`: launch, new_page, close. `PlaywrightPage`: navigate, get_html, screenshot, scroll, wait_for, evaluate |
| `src/scrapurrr/browser/stealth.py` | `StealthManager`: apply stealth patches per level (off/basic/full), run hooks |
| `src/scrapurrr/pipeline/__init__.py` | `Pipeline.run(url, page)` — orchestrates fetch→clean→markdown→chunk |
| `src/scrapurrr/pipeline/fetcher.py` | `fetch(page, url)` → `FetchResult` |
| `src/scrapurrr/pipeline/cleaner.py` | `clean(html)` → `CleanResult` |
| `src/scrapurrr/pipeline/markdown.py` | `to_markdown(html)` → `str` |
| `src/scrapurrr/pipeline/chunker.py` | `chunk(markdown, max_tokens)` → `ChunkResult` |
| `src/scrapurrr/extraction/__init__.py` | `Extractor`: strategy picker orchestrator |
| `src/scrapurrr/extraction/css.py` | `CSSExtractor`: field-name heuristic matching |
| `src/scrapurrr/extraction/llm.py` | `LLMExtractor`: prompt-based extraction with schema |
| `src/scrapurrr/agent/__init__.py` | Re-exports |
| `src/scrapurrr/agent/memory.py` | `AgentMemory` dataclass |
| `src/scrapurrr/agent/tools.py` | `ToolRegistry`, `Tool` dataclass, built-in tools |
| `src/scrapurrr/agent/loop.py` | `AgentLoop`: ReAct think→act→observe, stuck detection |
| `tests/conftest.py` | Shared fixtures: test HTML pages, mock providers, mock browser |
| `tests/fixtures/pages/` | Saved HTML files for deterministic tests |

---

### Task 1: Project Scaffold & pyproject.toml

**Files:**
- Create: `pyproject.toml`
- Create: `src/scrapurrr/__init__.py`
- Create: `src/scrapurrr/py.typed`
- Create: `tests/__init__.py`
- Create: `tests/conftest.py`
- Create: `.gitignore`

- [ ] **Step 1: Initialize git repo**

```bash
cd /Users/CK/Desktop/"P NO.16"/scrapurrr
git init
```

- [ ] **Step 2: Create .gitignore**

Create `.gitignore`:
```
__pycache__/
*.py[cod]
*$py.class
*.egg-info/
dist/
build/
.eggs/
*.egg
.venv/
venv/
.mypy_cache/
.pytest_cache/
.ruff_cache/
.coverage
htmlcov/
```

- [ ] **Step 3: Create pyproject.toml**

Create `pyproject.toml`:
```toml
[project]
name = "scrapurrr"
version = "0.1.0"
description = "Agentic web scraper with pluggable LLM providers and schema-driven output"
readme = "README.md"
license = "MIT"
requires-python = ">=3.11"
authors = [
    { name = "Klyne Chrysler C. Dotarot", email = "klyne@inventivlabs.io" },
]
classifiers = [
    "Development Status :: 3 - Alpha",
    "Intended Audience :: Developers",
    "License :: OSI Approved :: MIT License",
    "Programming Language :: Python :: 3.11",
    "Programming Language :: Python :: 3.12",
    "Programming Language :: Python :: 3.13",
    "Topic :: Internet :: WWW/HTTP :: Indexing/Search",
    "Typing :: Typed",
]
dependencies = [
    "playwright>=1.40",
    "litellm>=1.0",
    "pydantic>=2.0",
    "pyyaml>=6.0",
    "markdownify>=0.13",
    "beautifulsoup4>=4.12",
]

[project.optional-dependencies]
dev = [
    "pytest>=8.0",
    "pytest-asyncio>=0.23",
    "ruff>=0.4",
    "mypy>=1.10",
    "coverage>=7.0",
    "pytest-httpserver>=1.0",
]

[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"

[tool.hatch.build.targets.wheel]
packages = ["src/scrapurrr"]

[tool.pytest.ini_options]
testpaths = ["tests"]
asyncio_mode = "auto"

[tool.ruff]
target-version = "py311"
line-length = 100

[tool.ruff.lint]
select = ["E", "F", "I", "N", "W", "UP", "B", "SIM", "TCH"]

[tool.mypy]
python_version = "3.11"
strict = true
warn_return_any = true
warn_unused_configs = true
```

- [ ] **Step 4: Create src layout stubs**

Create `src/scrapurrr/__init__.py`:
```python
"""Scrapurrr — agentic web scraper with pluggable LLM providers."""

__version__ = "0.1.0"
```

Create `src/scrapurrr/py.typed` (empty marker file for PEP 561).

Create `tests/__init__.py` (empty).

Create `tests/conftest.py`:
```python
"""Shared test fixtures for scrapurrr."""
```

- [ ] **Step 5: Create venv, install deps, verify**

```bash
cd /Users/CK/Desktop/"P NO.16"/scrapurrr
python3 -m venv .venv
source .venv/bin/activate
pip install -e ".[dev]"
playwright install chromium
pytest --co -q
```

Expected: `no tests ran` (no test files yet), exit 0.

```bash
ruff check src/
mypy src/
```

Expected: both pass with no errors.

- [ ] **Step 6: Commit**

```bash
git add .gitignore pyproject.toml src/ tests/
git commit -m "add: project scaffold with pyproject.toml and src layout"
```

---

### Task 2: Exceptions & Types

**Files:**
- Create: `src/scrapurrr/exceptions.py`
- Create: `src/scrapurrr/types.py`
- Create: `tests/unit/__init__.py`
- Create: `tests/unit/test_exceptions.py`
- Create: `tests/unit/test_types.py`

- [ ] **Step 1: Write failing test for exceptions**

Create `tests/unit/__init__.py` (empty).

Create `tests/unit/test_exceptions.py`:
```python
"""Tests for scrapurrr exception hierarchy."""

from scrapurrr.exceptions import (
    AgentError,
    AuthError,
    BrowserError,
    ConfigError,
    ExtractionError,
    MaxStepsError,
    NavigationError,
    NoContentError,
    ProviderError,
    RateLimitError,
    SchemaError,
    ScrapurrError,
    StuckError,
)


def test_base_exception_is_exception() -> None:
    assert issubclass(ScrapurrError, Exception)


def test_config_error_inherits_base() -> None:
    err = ConfigError("bad config")
    assert isinstance(err, ScrapurrError)
    assert str(err) == "bad config"


def test_browser_error_hierarchy() -> None:
    assert issubclass(NavigationError, BrowserError)
    assert issubclass(BrowserError, ScrapurrError)


def test_extraction_error_hierarchy() -> None:
    assert issubclass(SchemaError, ExtractionError)
    assert issubclass(NoContentError, ExtractionError)
    assert issubclass(ExtractionError, ScrapurrError)


def test_provider_error_hierarchy() -> None:
    assert issubclass(RateLimitError, ProviderError)
    assert issubclass(AuthError, ProviderError)
    assert issubclass(ProviderError, ScrapurrError)


def test_agent_error_hierarchy() -> None:
    assert issubclass(MaxStepsError, AgentError)
    assert issubclass(StuckError, AgentError)
    assert issubclass(AgentError, ScrapurrError)
```

- [ ] **Step 2: Run test to verify it fails**

```bash
pytest tests/unit/test_exceptions.py -v
```

Expected: FAIL — `ModuleNotFoundError: No module named 'scrapurrr.exceptions'`

- [ ] **Step 3: Implement exceptions**

Create `src/scrapurrr/exceptions.py`:
```python
"""Custom exception hierarchy for scrapurrr."""


class ScrapurrError(Exception):
    """Base exception for all scrapurrr errors."""


class ConfigError(ScrapurrError):
    """Invalid configuration — bad YAML, missing provider."""


class BrowserError(ScrapurrError):
    """Browser operation failure — page load, timeout."""


class NavigationError(BrowserError):
    """Specific URL unreachable."""


class ExtractionError(ScrapurrError):
    """Data extraction failure."""


class SchemaError(ExtractionError):
    """LLM output did not match the Pydantic schema."""


class NoContentError(ExtractionError):
    """Page had no extractable content."""


class ProviderError(ScrapurrError):
    """LLM provider API failure."""


class RateLimitError(ProviderError):
    """Rate limit (429) from LLM provider."""


class AuthError(ProviderError):
    """Bad API key or authentication failure."""


class AgentError(ScrapurrError):
    """Agent loop failure."""


class MaxStepsError(AgentError):
    """Agent hit the maximum step limit."""


class StuckError(AgentError):
    """Agent detected it is looping or stuck."""
```

- [ ] **Step 4: Run test to verify it passes**

```bash
pytest tests/unit/test_exceptions.py -v
```

Expected: all 6 tests PASS.

- [ ] **Step 5: Write failing test for types**

Create `tests/unit/test_types.py`:
```python
"""Tests for scrapurrr shared types."""

from dataclasses import FrozenInstanceError

import pytest

from scrapurrr.types import ChunkResult, CleanResult, FetchResult, PageMetadata


def test_fetch_result_is_frozen() -> None:
    result = FetchResult(url="https://example.com", html="<h1>Hi</h1>", status=200, headers={})
    with pytest.raises(FrozenInstanceError):
        result.url = "other"  # type: ignore[misc]


def test_fetch_result_fields() -> None:
    result = FetchResult(
        url="https://example.com",
        html="<h1>Hi</h1>",
        status=200,
        headers={"content-type": "text/html"},
    )
    assert result.url == "https://example.com"
    assert result.html == "<h1>Hi</h1>"
    assert result.status == 200
    assert result.headers == {"content-type": "text/html"}


def test_clean_result_is_frozen() -> None:
    meta = PageMetadata(title="Test", language=None)
    result = CleanResult(html="<h1>Hi</h1>", markdown="# Hi", metadata=meta)
    with pytest.raises(FrozenInstanceError):
        result.html = "other"  # type: ignore[misc]


def test_chunk_result_is_frozen() -> None:
    result = ChunkResult(chunks=("chunk1", "chunk2"), source_url="https://example.com")
    with pytest.raises(FrozenInstanceError):
        result.source_url = "other"  # type: ignore[misc]


def test_chunk_result_uses_tuple() -> None:
    result = ChunkResult(chunks=("a", "b"), source_url="https://example.com")
    assert isinstance(result.chunks, tuple)
```

- [ ] **Step 6: Run test to verify it fails**

```bash
pytest tests/unit/test_types.py -v
```

Expected: FAIL — `ModuleNotFoundError: No module named 'scrapurrr.types'`

- [ ] **Step 7: Implement types**

Create `src/scrapurrr/types.py`:
```python
"""Shared protocols and frozen dataclasses for scrapurrr."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Protocol, TypeVar, runtime_checkable

from pydantic import BaseModel


T = TypeVar("T", bound=BaseModel)


@dataclass(frozen=True)
class PageMetadata:
    title: str | None
    language: str | None


@dataclass(frozen=True)
class FetchResult:
    url: str
    html: str
    status: int
    headers: dict[str, str]


@dataclass(frozen=True)
class CleanResult:
    html: str
    markdown: str
    metadata: PageMetadata


@dataclass(frozen=True)
class ChunkResult:
    chunks: tuple[str, ...]
    source_url: str


@runtime_checkable
class LLMProvider(Protocol):
    async def extract_structured(
        self,
        content: str,
        schema: type[T],
        system_prompt: str | None = None,
    ) -> T: ...

    async def complete(
        self,
        prompt: str,
        system_prompt: str | None = None,
    ) -> str: ...

    @property
    def supports_vision(self) -> bool: ...

    async def extract_from_image(
        self,
        image: bytes,
        schema: type[T],
        system_prompt: str | None = None,
    ) -> T: ...


@runtime_checkable
class PageContext(Protocol):
    async def navigate(self, url: str, wait_until: str = "domcontentloaded") -> None: ...
    async def get_html(self) -> str: ...
    async def screenshot(self) -> bytes: ...
    async def scroll(self, direction: str = "down") -> None: ...
    async def wait_for(self, selector: str, timeout: int = 10000) -> None: ...
    async def evaluate(self, js: str) -> Any: ...


@runtime_checkable
class BrowserEngine(Protocol):
    async def launch(self) -> None: ...
    async def new_page(self) -> PageContext: ...
    async def close(self) -> None: ...


@runtime_checkable
class ExtractionStrategy(Protocol):
    async def can_handle(self, html: str, schema: type[BaseModel]) -> bool: ...
    async def extract(self, content: str, schema: type[T]) -> T: ...


@runtime_checkable
class StealthHook(Protocol):
    async def on_before_navigate(self, page: PageContext, url: str) -> None: ...
    async def on_after_navigate(self, page: PageContext, url: str) -> None: ...
```

- [ ] **Step 8: Run test to verify it passes**

```bash
pytest tests/unit/test_types.py -v
```

Expected: all 5 tests PASS.

- [ ] **Step 9: Run full suite + linters**

```bash
pytest tests/ -v
ruff check src/
mypy src/
```

Expected: 11 tests PASS, ruff clean, mypy clean.

- [ ] **Step 10: Commit**

```bash
git add src/scrapurrr/exceptions.py src/scrapurrr/types.py tests/unit/
git commit -m "add: exception hierarchy and shared types with protocols"
```

---

### Task 3: Config System

**Files:**
- Create: `src/scrapurrr/config.py`
- Create: `tests/unit/test_config.py`

- [ ] **Step 1: Write failing test for config**

Create `tests/unit/test_config.py`:
```python
"""Tests for scrapurrr configuration system."""

import os
from pathlib import Path
from textwrap import dedent

import pytest

from scrapurrr.config import BrowserConfig, ExtractionConfig, AgentConfig, LLMConfig, ScrapurrConfig


def test_default_config() -> None:
    config = ScrapurrConfig()
    assert config.llm.provider == "ollama/llama3"
    assert config.llm.api_key is None
    assert config.browser.headless is True
    assert config.browser.stealth == "basic"
    assert config.browser.proxy is None
    assert config.browser.timeout == 30000
    assert config.extraction.strategy == "auto"
    assert config.agent.max_steps == 20
    assert config.agent.timeout == 300


def test_config_from_yaml(tmp_path: Path) -> None:
    yaml_file = tmp_path / "scrapurrr.yaml"
    yaml_file.write_text(dedent("""\
        llm:
          provider: openai/gpt-4o
          api_key: sk-test123
        browser:
          headless: false
          stealth: full
          timeout: 60000
        extraction:
          strategy: llm
        agent:
          max_steps: 50
          timeout: 600
    """))
    config = ScrapurrConfig.from_yaml(yaml_file)
    assert config.llm.provider == "openai/gpt-4o"
    assert config.llm.api_key == "sk-test123"
    assert config.browser.headless is False
    assert config.browser.stealth == "full"
    assert config.browser.timeout == 60000
    assert config.extraction.strategy == "llm"
    assert config.agent.max_steps == 50
    assert config.agent.timeout == 600


def test_config_env_var_resolution(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("TEST_API_KEY", "sk-from-env")
    yaml_file = tmp_path / "scrapurrr.yaml"
    yaml_file.write_text(dedent("""\
        llm:
          provider: openai/gpt-4o
          api_key: env:TEST_API_KEY
    """))
    config = ScrapurrConfig.from_yaml(yaml_file)
    assert config.llm.api_key == "sk-from-env"


def test_config_env_var_missing_raises(tmp_path: Path) -> None:
    yaml_file = tmp_path / "scrapurrr.yaml"
    yaml_file.write_text(dedent("""\
        llm:
          provider: openai/gpt-4o
          api_key: env:NONEXISTENT_KEY_12345
    """))
    with pytest.raises(Exception, match="NONEXISTENT_KEY_12345"):
        ScrapurrConfig.from_yaml(yaml_file)


def test_config_override() -> None:
    base = ScrapurrConfig()
    overridden = base.override(
        provider="anthropic/claude-3.5-sonnet",
        api_key="sk-ant-test",
        headless=False,
    )
    assert overridden.llm.provider == "anthropic/claude-3.5-sonnet"
    assert overridden.llm.api_key == "sk-ant-test"
    assert overridden.browser.headless is False
    # Original unchanged
    assert base.llm.provider == "ollama/llama3"
    assert base.browser.headless is True


def test_config_is_immutable() -> None:
    config = ScrapurrConfig()
    with pytest.raises(AttributeError):
        config.llm = LLMConfig(provider="other")  # type: ignore[misc]
```

- [ ] **Step 2: Run test to verify it fails**

```bash
pytest tests/unit/test_config.py -v
```

Expected: FAIL — `ModuleNotFoundError: No module named 'scrapurrr.config'`

- [ ] **Step 3: Implement config**

Create `src/scrapurrr/config.py`:
```python
"""Configuration system with YAML loading and code overrides."""

from __future__ import annotations

import os
from dataclasses import dataclass, replace
from pathlib import Path
from typing import Any, Literal

import yaml

from scrapurrr.exceptions import ConfigError


@dataclass(frozen=True)
class LLMConfig:
    provider: str = "ollama/llama3"
    api_key: str | None = None
    base_url: str | None = None


@dataclass(frozen=True)
class BrowserConfig:
    headless: bool = True
    stealth: Literal["off", "basic", "full"] = "basic"
    proxy: str | None = None
    timeout: int = 30000
    viewport_width: int | None = None
    viewport_height: int | None = None
    user_agent: str | None = None


@dataclass(frozen=True)
class ExtractionConfig:
    strategy: Literal["auto", "css", "llm"] = "auto"


@dataclass(frozen=True)
class AgentConfig:
    max_steps: int = 20
    timeout: int = 300


@dataclass(frozen=True)
class ScrapurrConfig:
    llm: LLMConfig = LLMConfig()
    browser: BrowserConfig = BrowserConfig()
    extraction: ExtractionConfig = ExtractionConfig()
    agent: AgentConfig = AgentConfig()

    @staticmethod
    def from_yaml(path: Path) -> ScrapurrConfig:
        try:
            raw = yaml.safe_load(path.read_text())
        except Exception as exc:
            raise ConfigError(f"Failed to load config from {path}: {exc}") from exc

        if not isinstance(raw, dict):
            raise ConfigError(f"Config file {path} must be a YAML mapping")

        llm_raw = raw.get("llm", {})
        browser_raw = raw.get("browser", {})
        extraction_raw = raw.get("extraction", {})
        agent_raw = raw.get("agent", {})

        # Resolve env: references
        if "api_key" in llm_raw and isinstance(llm_raw["api_key"], str):
            llm_raw["api_key"] = _resolve_env(llm_raw["api_key"])

        return ScrapurrConfig(
            llm=LLMConfig(**llm_raw),
            browser=BrowserConfig(**{k: v for k, v in browser_raw.items() if v is not None}),
            extraction=ExtractionConfig(**extraction_raw),
            agent=AgentConfig(**agent_raw),
        )

    def override(
        self,
        provider: str | None = None,
        api_key: str | None = None,
        base_url: str | None = None,
        headless: bool | None = None,
        stealth: Literal["off", "basic", "full"] | None = None,
        proxy: str | None = None,
    ) -> ScrapurrConfig:
        llm_updates: dict[str, Any] = {}
        if provider is not None:
            llm_updates["provider"] = provider
        if api_key is not None:
            llm_updates["api_key"] = api_key
        if base_url is not None:
            llm_updates["base_url"] = base_url

        browser_updates: dict[str, Any] = {}
        if headless is not None:
            browser_updates["headless"] = headless
        if stealth is not None:
            browser_updates["stealth"] = stealth
        if proxy is not None:
            browser_updates["proxy"] = proxy

        new_llm = replace(self.llm, **llm_updates) if llm_updates else self.llm
        new_browser = replace(self.browser, **browser_updates) if browser_updates else self.browser

        return replace(self, llm=new_llm, browser=new_browser)


def _resolve_env(value: str) -> str:
    if not value.startswith("env:"):
        return value
    var_name = value[4:]
    result = os.environ.get(var_name)
    if result is None:
        raise ConfigError(f"Environment variable '{var_name}' not set (referenced in config)")
    return result
```

- [ ] **Step 4: Run test to verify it passes**

```bash
pytest tests/unit/test_config.py -v
```

Expected: all 6 tests PASS.

- [ ] **Step 5: Commit**

```bash
git add src/scrapurrr/config.py tests/unit/test_config.py
git commit -m "add: config system with YAML loading and env var resolution"
```

---

### Task 4: Schema Utilities

**Files:**
- Create: `src/scrapurrr/schemas/__init__.py`
- Create: `tests/unit/test_schemas.py`

- [ ] **Step 1: Write failing test for schemas**

Create `tests/unit/test_schemas.py`:
```python
"""Tests for schema utilities."""

from pydantic import BaseModel

from scrapurrr.schemas import SchemaHelper


class Product(BaseModel):
    name: str
    price: float
    url: str


class Review(BaseModel):
    author: str
    rating: int
    text: str


def test_json_schema_from_model() -> None:
    schema = SchemaHelper.to_json_schema(Product)
    assert schema["type"] == "object"
    assert "name" in schema["properties"]
    assert "price" in schema["properties"]
    assert "url" in schema["properties"]


def test_json_schema_from_list_type() -> None:
    schema = SchemaHelper.to_json_schema(list[Product])
    assert schema["type"] == "array"
    assert "items" in schema


def test_is_list_schema() -> None:
    assert SchemaHelper.is_list_type(list[Product]) is True
    assert SchemaHelper.is_list_type(Product) is False


def test_build_extraction_prompt_single() -> None:
    prompt = SchemaHelper.build_extraction_prompt(Product)
    assert "name" in prompt
    assert "price" in prompt
    assert "url" in prompt
    assert "JSON" in prompt


def test_build_extraction_prompt_list() -> None:
    prompt = SchemaHelper.build_extraction_prompt(list[Product])
    assert "array" in prompt.lower() or "list" in prompt.lower()


def test_validate_single() -> None:
    data = {"name": "Widget", "price": 9.99, "url": "https://example.com"}
    result = SchemaHelper.validate(data, Product)
    assert isinstance(result, Product)
    assert result.name == "Widget"


def test_validate_list() -> None:
    data = [
        {"name": "Widget", "price": 9.99, "url": "https://a.com"},
        {"name": "Gadget", "price": 19.99, "url": "https://b.com"},
    ]
    result = SchemaHelper.validate(data, list[Product])
    assert isinstance(result, list)
    assert len(result) == 2
    assert all(isinstance(p, Product) for p in result)


def test_validate_invalid_raises() -> None:
    import pytest
    data = {"name": "Widget", "price": "not-a-number", "url": "https://example.com"}
    with pytest.raises(Exception):
        SchemaHelper.validate(data, Product)
```

- [ ] **Step 2: Run test to verify it fails**

```bash
pytest tests/unit/test_schemas.py -v
```

Expected: FAIL — `ModuleNotFoundError`

- [ ] **Step 3: Implement schema utilities**

Create `src/scrapurrr/schemas/__init__.py`:
```python
"""Schema utilities — Pydantic to JSON Schema, prompt generation, validation."""

from __future__ import annotations

import json
from typing import Any, TypeVar, get_args, get_origin

from pydantic import BaseModel, TypeAdapter


T = TypeVar("T")


class SchemaHelper:
    @staticmethod
    def is_list_type(schema: Any) -> bool:
        return get_origin(schema) is list

    @staticmethod
    def to_json_schema(schema: Any) -> dict[str, Any]:
        if SchemaHelper.is_list_type(schema):
            inner = get_args(schema)[0]
            inner_schema = inner.model_json_schema()
            return {
                "type": "array",
                "items": inner_schema,
            }
        return schema.model_json_schema()

    @staticmethod
    def build_extraction_prompt(schema: Any) -> str:
        json_schema = SchemaHelper.to_json_schema(schema)
        schema_str = json.dumps(json_schema, indent=2)

        if SchemaHelper.is_list_type(schema):
            return (
                "Extract data from the content below. "
                "Return a JSON array of objects matching this schema.\n\n"
                f"Schema:\n```json\n{schema_str}\n```\n\n"
                "Return ONLY valid JSON. No explanation, no markdown fences."
            )
        return (
            "Extract data from the content below. "
            "Return a single JSON object matching this schema.\n\n"
            f"Schema:\n```json\n{schema_str}\n```\n\n"
            "Return ONLY valid JSON. No explanation, no markdown fences."
        )

    @staticmethod
    def validate(data: Any, schema: Any) -> Any:
        adapter: TypeAdapter[Any] = TypeAdapter(schema)
        return adapter.validate_python(data)
```

- [ ] **Step 4: Run test to verify it passes**

```bash
pytest tests/unit/test_schemas.py -v
```

Expected: all 8 tests PASS.

- [ ] **Step 5: Commit**

```bash
git add src/scrapurrr/schemas/ tests/unit/test_schemas.py
git commit -m "add: schema utilities for JSON Schema generation and validation"
```

---

### Task 5: LLM Provider (LiteLLM)

**Files:**
- Create: `src/scrapurrr/providers/__init__.py`
- Create: `src/scrapurrr/providers/litellm.py`
- Create: `tests/unit/test_provider.py`

- [ ] **Step 1: Write failing test for provider**

Create `tests/unit/test_provider.py`:
```python
"""Tests for LiteLLM provider wrapper."""

from __future__ import annotations

import json
from typing import Any
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from pydantic import BaseModel

from scrapurrr.providers.litellm import LiteLLMProvider
from scrapurrr.exceptions import ProviderError, SchemaError


class Product(BaseModel):
    name: str
    price: float


@pytest.fixture
def provider() -> LiteLLMProvider:
    return LiteLLMProvider(model="openai/gpt-4o", api_key="sk-test")


@pytest.mark.asyncio
async def test_extract_structured_success(provider: LiteLLMProvider) -> None:
    mock_response = MagicMock()
    mock_response.choices = [MagicMock()]
    mock_response.choices[0].message.content = json.dumps({"name": "Widget", "price": 9.99})

    with patch("scrapurrr.providers.litellm.acompletion", new_callable=AsyncMock) as mock_complete:
        mock_complete.return_value = mock_response
        result = await provider.extract_structured("some content", Product)

    assert isinstance(result, Product)
    assert result.name == "Widget"
    assert result.price == 9.99


@pytest.mark.asyncio
async def test_extract_structured_retries_on_validation_failure(
    provider: LiteLLMProvider,
) -> None:
    bad_response = MagicMock()
    bad_response.choices = [MagicMock()]
    bad_response.choices[0].message.content = '{"name": "Widget"}'  # missing price

    good_response = MagicMock()
    good_response.choices = [MagicMock()]
    good_response.choices[0].message.content = json.dumps({"name": "Widget", "price": 9.99})

    with patch("scrapurrr.providers.litellm.acompletion", new_callable=AsyncMock) as mock_complete:
        mock_complete.side_effect = [bad_response, good_response]
        result = await provider.extract_structured("some content", Product)

    assert result.price == 9.99
    assert mock_complete.call_count == 2


@pytest.mark.asyncio
async def test_extract_structured_raises_after_retry_exhausted(
    provider: LiteLLMProvider,
) -> None:
    bad_response = MagicMock()
    bad_response.choices = [MagicMock()]
    bad_response.choices[0].message.content = '{"invalid": true}'

    with patch("scrapurrr.providers.litellm.acompletion", new_callable=AsyncMock) as mock_complete:
        mock_complete.return_value = bad_response
        with pytest.raises(SchemaError):
            await provider.extract_structured("some content", Product)


@pytest.mark.asyncio
async def test_complete_success(provider: LiteLLMProvider) -> None:
    mock_response = MagicMock()
    mock_response.choices = [MagicMock()]
    mock_response.choices[0].message.content = "The answer is 42"

    with patch("scrapurrr.providers.litellm.acompletion", new_callable=AsyncMock) as mock_complete:
        mock_complete.return_value = mock_response
        result = await provider.complete("What is the answer?")

    assert result == "The answer is 42"


@pytest.mark.asyncio
async def test_complete_api_failure_raises_provider_error(
    provider: LiteLLMProvider,
) -> None:
    with patch("scrapurrr.providers.litellm.acompletion", new_callable=AsyncMock) as mock_complete:
        mock_complete.side_effect = Exception("API connection failed")
        with pytest.raises(ProviderError, match="API connection failed"):
            await provider.complete("test")


def test_supports_vision_based_on_model() -> None:
    vision_provider = LiteLLMProvider(model="openai/gpt-4o")
    assert vision_provider.supports_vision is True

    text_provider = LiteLLMProvider(model="ollama/llama3")
    assert text_provider.supports_vision is False
```

- [ ] **Step 2: Run test to verify it fails**

```bash
pytest tests/unit/test_provider.py -v
```

Expected: FAIL — `ModuleNotFoundError`

- [ ] **Step 3: Implement provider**

Create `src/scrapurrr/providers/__init__.py`:
```python
"""LLM provider abstraction."""

from scrapurrr.types import LLMProvider

__all__ = ["LLMProvider"]
```

Create `src/scrapurrr/providers/litellm.py`:
```python
"""LiteLLM-based provider supporting 100+ LLM backends."""

from __future__ import annotations

import json
from typing import Any, TypeVar

from litellm import acompletion
from pydantic import BaseModel, ValidationError

from scrapurrr.exceptions import ProviderError, SchemaError
from scrapurrr.schemas import SchemaHelper


T = TypeVar("T", bound=BaseModel)

_VISION_KEYWORDS = ("gpt-4o", "gpt-4-vision", "claude-3", "gemini-1.5", "gemini-2")


class LiteLLMProvider:
    def __init__(
        self,
        model: str,
        api_key: str | None = None,
        base_url: str | None = None,
    ) -> None:
        self._model = model
        self._api_key = api_key
        self._base_url = base_url

    @property
    def supports_vision(self) -> bool:
        return any(kw in self._model for kw in _VISION_KEYWORDS)

    async def extract_structured(
        self,
        content: str,
        schema: type[T],
        system_prompt: str | None = None,
    ) -> T:
        extraction_prompt = SchemaHelper.build_extraction_prompt(schema)
        user_msg = f"{extraction_prompt}\n\nContent:\n{content}"
        last_error: Exception | None = None

        for attempt in range(2):
            raw = await self._call(user_msg, system_prompt)
            try:
                parsed = json.loads(raw)
                return SchemaHelper.validate(parsed, schema)
            except (json.JSONDecodeError, ValidationError) as exc:
                last_error = exc
                if attempt == 0:
                    user_msg = (
                        f"{extraction_prompt}\n\nContent:\n{content}\n\n"
                        f"Previous attempt failed with error: {exc}\n"
                        "Please fix the output and try again."
                    )

        raise SchemaError(
            f"Failed to extract valid data after 2 attempts: {last_error}"
        ) from last_error

    async def complete(
        self,
        prompt: str,
        system_prompt: str | None = None,
    ) -> str:
        return await self._call(prompt, system_prompt)

    async def extract_from_image(
        self,
        image: bytes,
        schema: type[T],
        system_prompt: str | None = None,
    ) -> T:
        raise NotImplementedError("Vision extraction is not yet implemented")

    async def _call(self, user_msg: str, system_prompt: str | None) -> str:
        messages: list[dict[str, str]] = []
        if system_prompt:
            messages.append({"role": "system", "content": system_prompt})
        messages.append({"role": "user", "content": user_msg})

        kwargs: dict[str, Any] = {"model": self._model, "messages": messages}
        if self._api_key:
            kwargs["api_key"] = self._api_key
        if self._base_url:
            kwargs["api_base"] = self._base_url

        try:
            response = await acompletion(**kwargs)
        except Exception as exc:
            raise ProviderError(str(exc)) from exc

        return response.choices[0].message.content
```

- [ ] **Step 4: Run test to verify it passes**

```bash
pytest tests/unit/test_provider.py -v
```

Expected: all 6 tests PASS.

- [ ] **Step 5: Commit**

```bash
git add src/scrapurrr/providers/ tests/unit/test_provider.py
git commit -m "add: LiteLLM provider with structured extraction and retry"
```

---

### Task 6: Content Pipeline (Fetcher, Cleaner, Markdown, Chunker)

**Files:**
- Create: `src/scrapurrr/pipeline/__init__.py`
- Create: `src/scrapurrr/pipeline/fetcher.py`
- Create: `src/scrapurrr/pipeline/cleaner.py`
- Create: `src/scrapurrr/pipeline/markdown.py`
- Create: `src/scrapurrr/pipeline/chunker.py`
- Create: `tests/unit/test_pipeline.py`
- Create: `tests/fixtures/pages/simple_product.html`

- [ ] **Step 1: Create test fixture HTML**

Create `tests/fixtures/__init__.py` (empty).
Create `tests/fixtures/pages/simple_product.html`:
```html
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Test Product Page</title>
    <script>var tracking = true;</script>
    <style>body { font-size: 14px; }</style>
</head>
<body>
    <nav><a href="/">Home</a><a href="/products">Products</a></nav>
    <div class="cookie-banner">We use cookies</div>
    <main>
        <article>
            <h1>Amazing Widget</h1>
            <p class="description">The best widget ever made.</p>
            <span class="price">$29.99</span>
            <div class="rating">4.5 stars</div>
            <table>
                <tr><th>Feature</th><th>Value</th></tr>
                <tr><td>Weight</td><td>100g</td></tr>
                <tr><td>Color</td><td>Blue</td></tr>
            </table>
        </article>
    </main>
    <footer>Copyright 2026</footer>
</body>
</html>
```

- [ ] **Step 2: Write failing test for cleaner**

Create `tests/unit/test_pipeline.py`:
```python
"""Tests for the content pipeline stages."""

from pathlib import Path

import pytest

from scrapurrr.pipeline.cleaner import clean
from scrapurrr.pipeline.markdown import to_markdown
from scrapurrr.pipeline.chunker import chunk


FIXTURES = Path(__file__).parent.parent / "fixtures" / "pages"


class TestCleaner:
    def test_removes_script_tags(self) -> None:
        html = "<html><body><script>alert(1)</script><p>Hello</p></body></html>"
        result = clean(html)
        assert "<script>" not in result.html
        assert "alert" not in result.html
        assert "Hello" in result.html

    def test_removes_style_tags(self) -> None:
        html = "<html><body><style>body{}</style><p>Hello</p></body></html>"
        result = clean(html)
        assert "<style>" not in result.html

    def test_removes_nav_and_footer(self) -> None:
        html = "<html><body><nav>Menu</nav><main><p>Content</p></main><footer>Foot</footer></body></html>"
        result = clean(html)
        assert "Menu" not in result.html
        assert "Foot" not in result.html
        assert "Content" in result.html

    def test_removes_cookie_banners(self) -> None:
        html = '<html><body><div class="cookie-banner">Cookies</div><p>Real</p></body></html>'
        result = clean(html)
        assert "Cookies" not in result.html
        assert "Real" in result.html

    def test_preserves_main_content(self) -> None:
        html = FIXTURES.joinpath("simple_product.html").read_text()
        result = clean(html)
        assert "Amazing Widget" in result.html
        assert "best widget" in result.html
        assert "Weight" in result.html

    def test_extracts_title_metadata(self) -> None:
        html = "<html><head><title>My Page</title></head><body><p>Hi</p></body></html>"
        result = clean(html)
        assert result.metadata.title == "My Page"

    def test_produces_markdown(self) -> None:
        html = FIXTURES.joinpath("simple_product.html").read_text()
        result = clean(html)
        assert len(result.markdown) > 0
        assert "Amazing Widget" in result.markdown


class TestMarkdown:
    def test_converts_heading(self) -> None:
        html = "<h1>Title</h1><p>Body text here.</p>"
        md = to_markdown(html)
        assert "# Title" in md or "Title" in md
        assert "Body text here." in md

    def test_converts_table(self) -> None:
        html = "<table><tr><th>A</th><th>B</th></tr><tr><td>1</td><td>2</td></tr></table>"
        md = to_markdown(html)
        assert "A" in md
        assert "1" in md

    def test_preserves_links(self) -> None:
        html = '<a href="https://example.com">Click here</a>'
        md = to_markdown(html)
        assert "https://example.com" in md
        assert "Click here" in md

    def test_empty_html_returns_empty(self) -> None:
        assert to_markdown("") == ""


class TestChunker:
    def test_small_content_returns_single_chunk(self) -> None:
        result = chunk("Small text", max_tokens=1000)
        assert len(result.chunks) == 1
        assert result.chunks[0] == "Small text"

    def test_large_content_splits_by_headings(self) -> None:
        content = "# Section 1\n\nContent one.\n\n# Section 2\n\nContent two.\n\n# Section 3\n\nContent three."
        result = chunk(content, max_tokens=20)
        assert len(result.chunks) >= 2

    def test_preserves_all_content(self) -> None:
        content = "# A\n\nFirst.\n\n# B\n\nSecond."
        result = chunk(content, max_tokens=10)
        combined = " ".join(result.chunks)
        assert "First" in combined
        assert "Second" in combined

    def test_source_url_passed_through(self) -> None:
        result = chunk("text", max_tokens=1000, source_url="https://example.com")
        assert result.source_url == "https://example.com"
```

- [ ] **Step 3: Run test to verify it fails**

```bash
pytest tests/unit/test_pipeline.py -v
```

Expected: FAIL — `ModuleNotFoundError`

- [ ] **Step 4: Implement markdown converter**

Create `src/scrapurrr/pipeline/__init__.py`:
```python
"""Content pipeline — fetch, clean, markdown, chunk."""
```

Create `src/scrapurrr/pipeline/markdown.py`:
```python
"""HTML to markdown conversion optimized for LLM consumption."""

from markdownify import markdownify


def to_markdown(html: str) -> str:
    if not html.strip():
        return ""
    return markdownify(html, heading_style="ATX", strip=["img"]).strip()
```

- [ ] **Step 5: Run markdown tests only**

```bash
pytest tests/unit/test_pipeline.py::TestMarkdown -v
```

Expected: all 4 markdown tests PASS.

- [ ] **Step 6: Implement cleaner**

Create `src/scrapurrr/pipeline/cleaner.py`:
```python
"""HTML cleaner — strips noise, preserves content."""

from __future__ import annotations

from bs4 import BeautifulSoup, Tag

from scrapurrr.pipeline.markdown import to_markdown
from scrapurrr.types import CleanResult, PageMetadata

_REMOVE_TAGS = {"script", "style", "noscript", "iframe", "svg"}
_REMOVE_ELEMENTS = {"nav", "footer", "header"}
_REMOVE_CLASSES = {"cookie", "banner", "popup", "modal", "overlay", "gdpr", "consent", "ad-"}
_REMOVE_IDS = {"cookie", "banner", "popup", "modal", "overlay", "gdpr", "consent"}


def clean(html: str) -> CleanResult:
    soup = BeautifulSoup(html, "html.parser")

    title = _extract_title(soup)
    language = _extract_language(soup)

    for tag_name in _REMOVE_TAGS:
        for tag in soup.find_all(tag_name):
            tag.decompose()

    for tag_name in _REMOVE_ELEMENTS:
        for tag in soup.find_all(tag_name):
            tag.decompose()

    _remove_by_class_or_id(soup)

    cleaned_html = str(soup)
    markdown = to_markdown(cleaned_html)

    return CleanResult(
        html=cleaned_html,
        markdown=markdown,
        metadata=PageMetadata(title=title, language=language),
    )


def _extract_title(soup: BeautifulSoup) -> str | None:
    title_tag = soup.find("title")
    if title_tag and isinstance(title_tag, Tag):
        return title_tag.get_text(strip=True)
    return None


def _extract_language(soup: BeautifulSoup) -> str | None:
    html_tag = soup.find("html")
    if html_tag and isinstance(html_tag, Tag):
        lang = html_tag.get("lang")
        if isinstance(lang, str):
            return lang
    return None


def _remove_by_class_or_id(soup: BeautifulSoup) -> None:
    for tag in soup.find_all(True):
        if not isinstance(tag, Tag):
            continue
        classes = " ".join(tag.get("class", []))  # type: ignore[arg-type]
        tag_id = tag.get("id", "")
        if isinstance(tag_id, list):
            tag_id = " ".join(tag_id)

        classes_lower = classes.lower()
        id_lower = tag_id.lower()

        if any(cls in classes_lower for cls in _REMOVE_CLASSES):
            tag.decompose()
            continue
        if any(rid in id_lower for rid in _REMOVE_IDS):
            tag.decompose()
```

- [ ] **Step 7: Run cleaner tests**

```bash
pytest tests/unit/test_pipeline.py::TestCleaner -v
```

Expected: all 7 cleaner tests PASS.

- [ ] **Step 8: Implement chunker**

Create `src/scrapurrr/pipeline/chunker.py`:
```python
"""Markdown chunking — splits large content for LLM processing."""

from __future__ import annotations

import re

from scrapurrr.types import ChunkResult


def chunk(
    markdown: str,
    max_tokens: int = 4000,
    source_url: str = "",
) -> ChunkResult:
    estimated_tokens = len(markdown.split())

    if estimated_tokens <= max_tokens:
        return ChunkResult(chunks=(markdown,), source_url=source_url)

    sections = _split_by_headings(markdown)

    if len(sections) <= 1:
        sections = _split_fixed(markdown, max_tokens)

    return ChunkResult(chunks=tuple(sections), source_url=source_url)


def _split_by_headings(markdown: str) -> list[str]:
    parts = re.split(r"(?=^#{1,3}\s)", markdown, flags=re.MULTILINE)
    return [p.strip() for p in parts if p.strip()]


def _split_fixed(markdown: str, max_tokens: int) -> list[str]:
    words = markdown.split()
    chunks: list[str] = []
    for i in range(0, len(words), max_tokens):
        chunks.append(" ".join(words[i : i + max_tokens]))
    return chunks
```

- [ ] **Step 9: Run all pipeline tests**

```bash
pytest tests/unit/test_pipeline.py -v
```

Expected: all 15 tests PASS.

- [ ] **Step 10: Implement pipeline fetcher**

Create `src/scrapurrr/pipeline/fetcher.py`:
```python
"""Page fetcher — navigates via browser engine and returns raw HTML."""

from __future__ import annotations

from scrapurrr.exceptions import NavigationError
from scrapurrr.types import FetchResult, PageContext


async def fetch(page: PageContext, url: str) -> FetchResult:
    try:
        await page.navigate(url)
        html = await page.get_html()
    except Exception as exc:
        raise NavigationError(f"Failed to fetch {url}: {exc}") from exc

    return FetchResult(url=url, html=html, status=200, headers={})
```

- [ ] **Step 11: Run full suite + linters**

```bash
pytest tests/ -v
ruff check src/
mypy src/
```

Expected: all tests PASS, ruff clean, mypy clean.

- [ ] **Step 12: Commit**

```bash
git add src/scrapurrr/pipeline/ tests/unit/test_pipeline.py tests/fixtures/
git commit -m "add: content pipeline — cleaner, markdown converter, chunker, fetcher"
```

---

### Task 7: Browser Engine & Stealth

**Files:**
- Create: `src/scrapurrr/browser/__init__.py`
- Create: `src/scrapurrr/browser/engine.py`
- Create: `src/scrapurrr/browser/stealth.py`
- Create: `tests/unit/test_browser.py`

- [ ] **Step 1: Write failing test for stealth**

Create `tests/unit/test_browser.py`:
```python
"""Tests for browser engine and stealth."""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from scrapurrr.browser.stealth import StealthManager, _USER_AGENTS
from scrapurrr.browser.engine import PlaywrightEngine, PlaywrightPage
from scrapurrr.config import BrowserConfig


class TestStealthManager:
    def test_off_returns_empty_args(self) -> None:
        manager = StealthManager(level="off")
        args = manager.context_args()
        assert "user_agent" not in args

    def test_basic_sets_user_agent(self) -> None:
        manager = StealthManager(level="basic")
        args = manager.context_args()
        assert "user_agent" in args
        assert args["user_agent"] in _USER_AGENTS

    def test_basic_sets_viewport(self) -> None:
        manager = StealthManager(level="basic")
        args = manager.context_args()
        assert "viewport" in args
        assert "width" in args["viewport"]
        assert "height" in args["viewport"]

    def test_full_includes_basic(self) -> None:
        manager = StealthManager(level="full")
        args = manager.context_args()
        assert "user_agent" in args
        assert "viewport" in args

    @pytest.mark.asyncio
    async def test_apply_stealth_scripts_basic(self) -> None:
        manager = StealthManager(level="basic")
        mock_page = AsyncMock()
        await manager.apply_page_scripts(mock_page)
        mock_page.evaluate.assert_called()

    @pytest.mark.asyncio
    async def test_no_scripts_when_off(self) -> None:
        manager = StealthManager(level="off")
        mock_page = AsyncMock()
        await manager.apply_page_scripts(mock_page)
        mock_page.evaluate.assert_not_called()

    @pytest.mark.asyncio
    async def test_hooks_called_on_navigate(self) -> None:
        hook = AsyncMock()
        hook.on_before_navigate = AsyncMock()
        hook.on_after_navigate = AsyncMock()
        manager = StealthManager(level="basic", hooks=[hook])

        mock_page = AsyncMock()
        await manager.run_before_navigate(mock_page, "https://example.com")
        hook.on_before_navigate.assert_called_once_with(mock_page, "https://example.com")

        await manager.run_after_navigate(mock_page, "https://example.com")
        hook.on_after_navigate.assert_called_once_with(mock_page, "https://example.com")
```

- [ ] **Step 2: Run test to verify it fails**

```bash
pytest tests/unit/test_browser.py -v
```

Expected: FAIL — `ModuleNotFoundError`

- [ ] **Step 3: Implement stealth manager**

Create `src/scrapurrr/browser/__init__.py`:
```python
"""Browser engine abstraction."""

from scrapurrr.types import BrowserEngine, PageContext

__all__ = ["BrowserEngine", "PageContext"]
```

Create `src/scrapurrr/browser/stealth.py`:
```python
"""Stealth manager — fingerprint masking, hooks, human-like delays."""

from __future__ import annotations

import random
from typing import Any, Literal

from scrapurrr.types import StealthHook


_USER_AGENTS = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:125.0) Gecko/20100101 Firefox/125.0",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4 Safari/605.1.15",
)

_VIEWPORTS = (
    {"width": 1920, "height": 1080},
    {"width": 1366, "height": 768},
    {"width": 1440, "height": 900},
    {"width": 1536, "height": 864},
    {"width": 1280, "height": 720},
)

_WEBDRIVER_PATCH = "Object.defineProperty(navigator, 'webdriver', {get: () => undefined})"


class StealthManager:
    def __init__(
        self,
        level: Literal["off", "basic", "full"] = "basic",
        hooks: list[StealthHook] | None = None,
    ) -> None:
        self._level = level
        self._hooks = hooks or []

    def context_args(self) -> dict[str, Any]:
        if self._level == "off":
            return {}

        args: dict[str, Any] = {
            "user_agent": random.choice(_USER_AGENTS),
            "viewport": random.choice(_VIEWPORTS),
            "locale": "en-US",
        }

        if self._level == "full":
            args["extra_http_headers"] = {
                "Accept-Language": "en-US,en;q=0.9",
                "Accept-Encoding": "gzip, deflate, br",
                "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            }

        return args

    async def apply_page_scripts(self, page: Any) -> None:
        if self._level == "off":
            return

        await page.evaluate(_WEBDRIVER_PATCH)

        if self._level == "full":
            await page.evaluate(
                "Object.defineProperty(navigator, 'plugins', {get: () => [1, 2, 3, 4, 5]})"
            )
            await page.evaluate(
                "Object.defineProperty(navigator, 'languages', {get: () => ['en-US', 'en']})"
            )

    async def run_before_navigate(self, page: Any, url: str) -> None:
        for hook in self._hooks:
            await hook.on_before_navigate(page, url)

    async def run_after_navigate(self, page: Any, url: str) -> None:
        for hook in self._hooks:
            await hook.on_after_navigate(page, url)

    async def human_delay(self) -> None:
        if self._level == "full":
            import asyncio
            delay = random.uniform(0.5, 2.0)
            await asyncio.sleep(delay)
```

- [ ] **Step 4: Run stealth tests**

```bash
pytest tests/unit/test_browser.py -v
```

Expected: all 7 tests PASS.

- [ ] **Step 5: Implement Playwright engine**

Create `src/scrapurrr/browser/engine.py`:
```python
"""Playwright browser engine implementation."""

from __future__ import annotations

from typing import Any

from playwright.async_api import Browser, Page, Playwright, async_playwright

from scrapurrr.browser.stealth import StealthManager
from scrapurrr.config import BrowserConfig


class PlaywrightPage:
    def __init__(self, page: Page, stealth: StealthManager) -> None:
        self._page = page
        self._stealth = stealth

    async def navigate(self, url: str, wait_until: str = "domcontentloaded") -> None:
        await self._stealth.run_before_navigate(self, url)
        await self._stealth.human_delay()
        await self._page.goto(url, wait_until=wait_until)  # type: ignore[arg-type]
        await self._stealth.apply_page_scripts(self._page)
        await self._stealth.run_after_navigate(self, url)

    async def get_html(self) -> str:
        return await self._page.content()

    async def screenshot(self) -> bytes:
        return await self._page.screenshot()

    async def scroll(self, direction: str = "down") -> None:
        delta = 500 if direction == "down" else -500
        await self._page.mouse.wheel(0, delta)
        await self._stealth.human_delay()

    async def wait_for(self, selector: str, timeout: int = 10000) -> None:
        await self._page.wait_for_selector(selector, timeout=timeout)

    async def evaluate(self, js: str) -> Any:
        return await self._page.evaluate(js)


class PlaywrightEngine:
    def __init__(self, config: BrowserConfig, stealth: StealthManager) -> None:
        self._config = config
        self._stealth = stealth
        self._playwright: Playwright | None = None
        self._browser: Browser | None = None

    async def launch(self) -> None:
        self._playwright = await async_playwright().start()
        launch_args: dict[str, Any] = {"headless": self._config.headless}
        if self._config.proxy:
            launch_args["proxy"] = {"server": self._config.proxy}
        self._browser = await self._playwright.chromium.launch(**launch_args)

    async def new_page(self) -> PlaywrightPage:
        if self._browser is None:
            raise RuntimeError("Browser not launched. Call launch() first.")
        context_args = self._stealth.context_args()
        context = await self._browser.new_context(**context_args)
        page = await context.new_page()
        return PlaywrightPage(page, self._stealth)

    async def close(self) -> None:
        if self._browser:
            await self._browser.close()
            self._browser = None
        if self._playwright:
            await self._playwright.stop()
            self._playwright = None
```

- [ ] **Step 6: Run full suite + linters**

```bash
pytest tests/ -v
ruff check src/
mypy src/
```

Expected: all tests PASS, linters clean.

- [ ] **Step 7: Commit**

```bash
git add src/scrapurrr/browser/ tests/unit/test_browser.py
git commit -m "add: Playwright browser engine with stealth manager and hooks"
```

---

### Task 8: CSS Extraction Strategy

**Files:**
- Create: `src/scrapurrr/extraction/__init__.py`
- Create: `src/scrapurrr/extraction/css.py`
- Create: `tests/unit/test_css_extraction.py`

- [ ] **Step 1: Write failing test for CSS extraction**

Create `tests/unit/test_css_extraction.py`:
```python
"""Tests for CSS-based extraction strategy."""

from pathlib import Path

import pytest
from pydantic import BaseModel

from scrapurrr.extraction.css import CSSExtractor


class Product(BaseModel):
    title: str
    price: str
    description: str


class MinimalItem(BaseModel):
    title: str


FIXTURES = Path(__file__).parent.parent / "fixtures" / "pages"


class TestCSSExtractor:
    @pytest.fixture
    def extractor(self) -> CSSExtractor:
        return CSSExtractor()

    @pytest.mark.asyncio
    async def test_can_handle_matching_page(self, extractor: CSSExtractor) -> None:
        html = FIXTURES.joinpath("simple_product.html").read_text()
        assert await extractor.can_handle(html, Product) is True

    @pytest.mark.asyncio
    async def test_can_handle_non_matching_page(self, extractor: CSSExtractor) -> None:
        html = "<html><body><p>Just a paragraph.</p></body></html>"
        assert await extractor.can_handle(html, Product) is False

    @pytest.mark.asyncio
    async def test_extract_product_fields(self, extractor: CSSExtractor) -> None:
        html = FIXTURES.joinpath("simple_product.html").read_text()
        result = await extractor.extract(html, Product)
        assert isinstance(result, Product)
        assert "Widget" in result.title
        assert "$29.99" in result.price or "29.99" in result.price

    @pytest.mark.asyncio
    async def test_extract_minimal_item(self, extractor: CSSExtractor) -> None:
        html = "<html><body><h1>My Title</h1></body></html>"
        result = await extractor.extract(html, MinimalItem)
        assert result.title == "My Title"

    @pytest.mark.asyncio
    async def test_can_handle_returns_false_for_empty(self, extractor: CSSExtractor) -> None:
        assert await extractor.can_handle("", Product) is False
```

- [ ] **Step 2: Run test to verify it fails**

```bash
pytest tests/unit/test_css_extraction.py -v
```

Expected: FAIL — `ModuleNotFoundError`

- [ ] **Step 3: Implement CSS extractor**

Create `src/scrapurrr/extraction/__init__.py`:
```python
"""Extraction strategies — CSS, LLM, Vision."""
```

Create `src/scrapurrr/extraction/css.py`:
```python
"""CSS/XPath rule-based extraction using field-name heuristics."""

from __future__ import annotations

from typing import Any, TypeVar

from bs4 import BeautifulSoup, Tag
from pydantic import BaseModel

from scrapurrr.exceptions import ExtractionError


T = TypeVar("T", bound=BaseModel)

_FIELD_SELECTORS: dict[str, list[str]] = {
    "price": ["[class*=price]", "[data-price]", ".cost", ".amount"],
    "title": ["h1", "h2", ".title", "[class*=title]", ".name", "[class*=name]"],
    "name": ["h1", "h2", ".title", "[class*=title]", ".name", "[class*=name]"],
    "image": ["img[src]", "[class*=image] img", ".photo img"],
    "description": [".description", "[class*=desc]", "p.summary", "[class*=summary]"],
    "rating": ["[class*=rating]", "[data-rating]", "[class*=review]"],
    "url": ["a[href]"],
    "link": ["a[href]"],
}


class CSSExtractor:
    async def can_handle(self, html: str, schema: type[BaseModel]) -> bool:
        if not html.strip():
            return False
        soup = BeautifulSoup(html, "html.parser")
        fields = schema.model_fields
        matched = 0
        for field_name in fields:
            if _find_value(soup, field_name) is not None:
                matched += 1
        return matched == len(fields)

    async def extract(self, html: str, schema: type[T]) -> T:
        soup = BeautifulSoup(html, "html.parser")
        fields = schema.model_fields
        data: dict[str, Any] = {}

        for field_name in fields:
            value = _find_value(soup, field_name)
            if value is None:
                raise ExtractionError(
                    f"CSS extraction failed: could not find value for field '{field_name}'"
                )
            data[field_name] = value

        return schema.model_validate(data)


def _find_value(soup: BeautifulSoup, field_name: str) -> str | None:
    selectors = _FIELD_SELECTORS.get(field_name, [])

    for selector in selectors:
        tag = soup.select_one(selector)
        if tag and isinstance(tag, Tag):
            if field_name in ("url", "link"):
                href = tag.get("href")
                if href:
                    return str(href)
            if field_name == "image":
                src = tag.get("src")
                if src:
                    return str(src)
            text = tag.get_text(strip=True)
            if text:
                return text

    return None
```

- [ ] **Step 4: Run test to verify it passes**

```bash
pytest tests/unit/test_css_extraction.py -v
```

Expected: all 5 tests PASS.

- [ ] **Step 5: Commit**

```bash
git add src/scrapurrr/extraction/ tests/unit/test_css_extraction.py
git commit -m "add: CSS extraction strategy with field-name heuristics"
```

---

### Task 9: LLM Extraction Strategy

**Files:**
- Create: `src/scrapurrr/extraction/llm.py`
- Create: `tests/unit/test_llm_extraction.py`

- [ ] **Step 1: Write failing test for LLM extraction**

Create `tests/unit/test_llm_extraction.py`:
```python
"""Tests for LLM-based extraction strategy."""

from __future__ import annotations

import json
from unittest.mock import AsyncMock

import pytest
from pydantic import BaseModel

from scrapurrr.extraction.llm import LLMExtractor


class Product(BaseModel):
    name: str
    price: float


class TestLLMExtractor:
    @pytest.fixture
    def mock_provider(self) -> AsyncMock:
        provider = AsyncMock()
        provider.extract_structured = AsyncMock(
            return_value=Product(name="Widget", price=9.99)
        )
        return provider

    @pytest.fixture
    def extractor(self, mock_provider: AsyncMock) -> LLMExtractor:
        return LLMExtractor(provider=mock_provider)

    @pytest.mark.asyncio
    async def test_can_handle_always_true(self, extractor: LLMExtractor) -> None:
        assert await extractor.can_handle("<p>any html</p>", Product) is True

    @pytest.mark.asyncio
    async def test_can_handle_false_for_empty(self, extractor: LLMExtractor) -> None:
        assert await extractor.can_handle("", Product) is False

    @pytest.mark.asyncio
    async def test_extract_delegates_to_provider(
        self, extractor: LLMExtractor, mock_provider: AsyncMock
    ) -> None:
        result = await extractor.extract("# Product\n\nWidget costs $9.99", Product)
        assert isinstance(result, Product)
        assert result.name == "Widget"
        mock_provider.extract_structured.assert_called_once()

    @pytest.mark.asyncio
    async def test_extract_passes_content_and_schema(
        self, extractor: LLMExtractor, mock_provider: AsyncMock
    ) -> None:
        await extractor.extract("markdown content here", Product)
        call_args = mock_provider.extract_structured.call_args
        assert "markdown content here" in call_args.kwargs.get("content", call_args.args[0])
```

- [ ] **Step 2: Run test to verify it fails**

```bash
pytest tests/unit/test_llm_extraction.py -v
```

Expected: FAIL — `ModuleNotFoundError`

- [ ] **Step 3: Implement LLM extractor**

Create `src/scrapurrr/extraction/llm.py`:
```python
"""LLM-based extraction strategy — sends content + schema to LLM provider."""

from __future__ import annotations

from typing import TypeVar

from pydantic import BaseModel

from scrapurrr.types import LLMProvider


T = TypeVar("T", bound=BaseModel)


class LLMExtractor:
    def __init__(self, provider: LLMProvider) -> None:
        self._provider = provider

    async def can_handle(self, html: str, schema: type[BaseModel]) -> bool:
        return bool(html.strip())

    async def extract(self, content: str, schema: type[T]) -> T:
        return await self._provider.extract_structured(content=content, schema=schema)
```

- [ ] **Step 4: Run test to verify it passes**

```bash
pytest tests/unit/test_llm_extraction.py -v
```

Expected: all 4 tests PASS.

- [ ] **Step 5: Commit**

```bash
git add src/scrapurrr/extraction/llm.py tests/unit/test_llm_extraction.py
git commit -m "add: LLM extraction strategy delegating to provider"
```

---

### Task 10: Extraction Orchestrator (Strategy Picker)

**Files:**
- Modify: `src/scrapurrr/extraction/__init__.py`
- Create: `tests/unit/test_extractor.py`

- [ ] **Step 1: Write failing test for extractor orchestrator**

Create `tests/unit/test_extractor.py`:
```python
"""Tests for the extraction orchestrator (strategy picker)."""

from __future__ import annotations

from pathlib import Path
from unittest.mock import AsyncMock

import pytest
from pydantic import BaseModel

from scrapurrr.extraction import Extractor


class Product(BaseModel):
    title: str
    price: str
    description: str


class Unusual(BaseModel):
    foo: str
    bar: int


FIXTURES = Path(__file__).parent.parent / "fixtures" / "pages"


class TestExtractor:
    @pytest.fixture
    def mock_provider(self) -> AsyncMock:
        provider = AsyncMock()
        provider.extract_structured = AsyncMock(
            return_value=Unusual(foo="hello", bar=42)
        )
        return provider

    @pytest.mark.asyncio
    async def test_auto_uses_css_when_possible(self, mock_provider: AsyncMock) -> None:
        html = FIXTURES.joinpath("simple_product.html").read_text()
        extractor = Extractor(provider=mock_provider, strategy="auto")
        result = await extractor.extract(html, Product)
        assert isinstance(result, Product)
        # CSS handled it — provider should NOT have been called
        mock_provider.extract_structured.assert_not_called()

    @pytest.mark.asyncio
    async def test_auto_falls_back_to_llm(self, mock_provider: AsyncMock) -> None:
        html = "<html><body><p>Some random content</p></body></html>"
        extractor = Extractor(provider=mock_provider, strategy="auto")
        result = await extractor.extract(html, Unusual)
        assert isinstance(result, Unusual)
        mock_provider.extract_structured.assert_called_once()

    @pytest.mark.asyncio
    async def test_css_strategy_only(self, mock_provider: AsyncMock) -> None:
        html = FIXTURES.joinpath("simple_product.html").read_text()
        extractor = Extractor(provider=mock_provider, strategy="css")
        result = await extractor.extract(html, Product)
        assert isinstance(result, Product)
        mock_provider.extract_structured.assert_not_called()

    @pytest.mark.asyncio
    async def test_llm_strategy_only(self, mock_provider: AsyncMock) -> None:
        html = "<html><body><p>Content</p></body></html>"
        extractor = Extractor(provider=mock_provider, strategy="llm")
        result = await extractor.extract(html, Unusual)
        assert isinstance(result, Unusual)
        mock_provider.extract_structured.assert_called_once()

    @pytest.mark.asyncio
    async def test_css_strategy_raises_on_no_match(self, mock_provider: AsyncMock) -> None:
        from scrapurrr.exceptions import ExtractionError
        html = "<html><body><p>Nothing here</p></body></html>"
        extractor = Extractor(provider=mock_provider, strategy="css")
        with pytest.raises(ExtractionError):
            await extractor.extract(html, Unusual)
```

- [ ] **Step 2: Run test to verify it fails**

```bash
pytest tests/unit/test_extractor.py -v
```

Expected: FAIL — `ImportError: cannot import name 'Extractor'`

- [ ] **Step 3: Implement extractor orchestrator**

Replace `src/scrapurrr/extraction/__init__.py`:
```python
"""Extraction orchestrator — strategy picker."""

from __future__ import annotations

from typing import Literal, TypeVar

from pydantic import BaseModel

from scrapurrr.exceptions import ExtractionError, NoContentError
from scrapurrr.extraction.css import CSSExtractor
from scrapurrr.extraction.llm import LLMExtractor
from scrapurrr.types import LLMProvider


T = TypeVar("T", bound=BaseModel)


class Extractor:
    def __init__(
        self,
        provider: LLMProvider,
        strategy: Literal["auto", "css", "llm"] = "auto",
    ) -> None:
        self._css = CSSExtractor()
        self._llm = LLMExtractor(provider)
        self._strategy = strategy

    async def extract(self, html: str, schema: type[T]) -> T:
        if not html.strip():
            raise NoContentError("No content to extract from")

        if self._strategy == "css":
            if await self._css.can_handle(html, schema):
                return await self._css.extract(html, schema)
            raise ExtractionError("CSS strategy could not match all schema fields")

        if self._strategy == "llm":
            return await self._llm.extract(html, schema)

        # auto: try CSS first, fall back to LLM
        if await self._css.can_handle(html, schema):
            return await self._css.extract(html, schema)

        return await self._llm.extract(html, schema)
```

- [ ] **Step 4: Run test to verify it passes**

```bash
pytest tests/unit/test_extractor.py -v
```

Expected: all 5 tests PASS.

- [ ] **Step 5: Commit**

```bash
git add src/scrapurrr/extraction/__init__.py tests/unit/test_extractor.py
git commit -m "add: extraction orchestrator with auto/css/llm strategy picker"
```

---

### Task 11: Agent Memory & Tools

**Files:**
- Create: `src/scrapurrr/agent/__init__.py`
- Create: `src/scrapurrr/agent/memory.py`
- Create: `src/scrapurrr/agent/tools.py`
- Create: `tests/unit/test_agent_memory.py`
- Create: `tests/unit/test_agent_tools.py`

- [ ] **Step 1: Write failing test for agent memory**

Create `tests/unit/test_agent_memory.py`:
```python
"""Tests for agent short-term memory."""

from pydantic import BaseModel

from scrapurrr.agent.memory import AgentAction, AgentMemory


class Product(BaseModel):
    name: str
    price: float


def test_memory_creation() -> None:
    memory = AgentMemory(goal="find products", schema=Product)
    assert memory.goal == "find products"
    assert memory.step_count == 0
    assert memory.visited_urls == []
    assert memory.extracted_data == []
    assert memory.action_history == []


def test_record_action() -> None:
    memory = AgentMemory(goal="test", schema=Product)
    action = AgentAction(tool="navigate", params={"url": "https://example.com"}, result="OK")
    memory.record_action(action)
    assert len(memory.action_history) == 1
    assert memory.step_count == 1


def test_record_visit() -> None:
    memory = AgentMemory(goal="test", schema=Product)
    memory.record_visit("https://example.com")
    assert "https://example.com" in memory.visited_urls


def test_record_extracted_data() -> None:
    memory = AgentMemory(goal="test", schema=Product)
    product = Product(name="Widget", price=9.99)
    memory.record_extraction(product)
    assert len(memory.extracted_data) == 1


def test_is_url_visited() -> None:
    memory = AgentMemory(goal="test", schema=Product)
    memory.record_visit("https://example.com")
    assert memory.is_visited("https://example.com") is True
    assert memory.is_visited("https://other.com") is False


def test_stuck_detection_url_visited_too_many_times() -> None:
    memory = AgentMemory(goal="test", schema=Product)
    for _ in range(3):
        memory.record_visit("https://example.com")
    assert memory.is_stuck() is True


def test_stuck_detection_repeated_actions() -> None:
    memory = AgentMemory(goal="test", schema=Product)
    action = AgentAction(tool="scroll", params={"direction": "down"}, result="OK")
    memory.record_action(action)
    memory.record_action(action)
    assert memory.is_stuck() is True


def test_stuck_detection_no_progress() -> None:
    memory = AgentMemory(goal="test", schema=Product)
    for i in range(5):
        memory.record_action(
            AgentAction(tool="navigate", params={"url": f"https://site{i}.com"}, result="OK")
        )
    assert memory.is_stuck() is True


def test_not_stuck_with_extractions() -> None:
    memory = AgentMemory(goal="test", schema=Product)
    for i in range(5):
        memory.record_action(
            AgentAction(tool="navigate", params={"url": f"https://site{i}.com"}, result="OK")
        )
        memory.record_extraction(Product(name=f"P{i}", price=float(i)))
    assert memory.is_stuck() is False


def test_truncate_old_actions() -> None:
    memory = AgentMemory(goal="test", schema=Product)
    for i in range(30):
        memory.record_action(
            AgentAction(tool="navigate", params={"url": f"https://site{i}.com"}, result="OK")
        )
    recent = memory.recent_actions(limit=10)
    assert len(recent) == 10
```

- [ ] **Step 2: Run test to verify it fails**

```bash
pytest tests/unit/test_agent_memory.py -v
```

Expected: FAIL — `ModuleNotFoundError`

- [ ] **Step 3: Implement agent memory**

Create `src/scrapurrr/agent/__init__.py`:
```python
"""Agent system — ReAct loop, tools, memory."""
```

Create `src/scrapurrr/agent/memory.py`:
```python
"""Short-term memory for agent runs."""

from __future__ import annotations

from collections import Counter
from dataclasses import dataclass, field
from typing import Any

from pydantic import BaseModel


@dataclass(frozen=True)
class AgentAction:
    tool: str
    params: dict[str, Any]
    result: str


class AgentMemory:
    def __init__(self, goal: str, schema: type[BaseModel]) -> None:
        self.goal = goal
        self.schema = schema
        self.visited_urls: list[str] = []
        self.extracted_data: list[BaseModel] = []
        self.action_history: list[AgentAction] = []
        self.current_url: str | None = None
        self.current_page_summary: str | None = None
        self.step_count: int = 0
        self._extraction_count_at_step: dict[int, int] = {}

    def record_action(self, action: AgentAction) -> None:
        self.action_history.append(action)
        self.step_count += 1
        self._extraction_count_at_step[self.step_count] = len(self.extracted_data)

    def record_visit(self, url: str) -> None:
        self.visited_urls.append(url)
        self.current_url = url

    def record_extraction(self, data: BaseModel) -> None:
        self.extracted_data.append(data)

    def is_visited(self, url: str) -> bool:
        return url in self.visited_urls

    def is_stuck(self) -> bool:
        if self._url_visited_too_many_times():
            return True
        if self._repeated_consecutive_actions():
            return True
        if self._no_progress_in_recent_steps():
            return True
        return False

    def recent_actions(self, limit: int = 10) -> list[AgentAction]:
        return self.action_history[-limit:]

    def _url_visited_too_many_times(self) -> bool:
        counts = Counter(self.visited_urls)
        return any(count >= 3 for count in counts.values())

    def _repeated_consecutive_actions(self) -> bool:
        if len(self.action_history) < 2:
            return False
        last = self.action_history[-1]
        prev = self.action_history[-2]
        return last.tool == prev.tool and last.params == prev.params

    def _no_progress_in_recent_steps(self) -> bool:
        if self.step_count < 5:
            return False
        current_extractions = len(self.extracted_data)
        step_5_ago = self.step_count - 4
        extractions_then = self._extraction_count_at_step.get(step_5_ago, 0)
        return current_extractions == extractions_then
```

- [ ] **Step 4: Run test to verify it passes**

```bash
pytest tests/unit/test_agent_memory.py -v
```

Expected: all 10 tests PASS.

- [ ] **Step 5: Write failing test for tools**

Create `tests/unit/test_agent_tools.py`:
```python
"""Tests for agent tool registry."""

from __future__ import annotations

from unittest.mock import AsyncMock

import pytest
from pydantic import BaseModel

from scrapurrr.agent.tools import Tool, ToolRegistry


class NavParams(BaseModel):
    url: str


class ScrollParams(BaseModel):
    direction: str = "down"


def test_register_tool() -> None:
    registry = ToolRegistry()
    tool = Tool(
        name="navigate",
        description="Go to URL",
        parameters=NavParams,
        execute=AsyncMock(),
    )
    registry.register(tool)
    assert "navigate" in registry.tool_names()


def test_get_tool() -> None:
    registry = ToolRegistry()
    tool = Tool(
        name="navigate",
        description="Go to URL",
        parameters=NavParams,
        execute=AsyncMock(),
    )
    registry.register(tool)
    retrieved = registry.get("navigate")
    assert retrieved.name == "navigate"


def test_get_nonexistent_raises() -> None:
    registry = ToolRegistry()
    with pytest.raises(KeyError):
        registry.get("nonexistent")


def test_duplicate_registration_raises() -> None:
    registry = ToolRegistry()
    tool = Tool(
        name="navigate",
        description="Go to URL",
        parameters=NavParams,
        execute=AsyncMock(),
    )
    registry.register(tool)
    with pytest.raises(ValueError, match="already registered"):
        registry.register(tool)


def test_tool_descriptions_for_prompt() -> None:
    registry = ToolRegistry()
    registry.register(Tool(
        name="navigate",
        description="Go to URL",
        parameters=NavParams,
        execute=AsyncMock(),
    ))
    registry.register(Tool(
        name="scroll",
        description="Scroll the page",
        parameters=ScrollParams,
        execute=AsyncMock(),
    ))
    desc = registry.describe_tools()
    assert "navigate" in desc
    assert "scroll" in desc
    assert "Go to URL" in desc


@pytest.mark.asyncio
async def test_execute_tool() -> None:
    mock_fn = AsyncMock(return_value="page loaded")
    registry = ToolRegistry()
    registry.register(Tool(
        name="navigate",
        description="Go to URL",
        parameters=NavParams,
        execute=mock_fn,
    ))
    result = await registry.execute("navigate", {"url": "https://example.com"})
    assert result == "page loaded"
    mock_fn.assert_called_once()
```

- [ ] **Step 6: Run test to verify it fails**

```bash
pytest tests/unit/test_agent_tools.py -v
```

Expected: FAIL — `ModuleNotFoundError`

- [ ] **Step 7: Implement tool registry**

Create `src/scrapurrr/agent/tools.py`:
```python
"""Tool registry and tool dataclass for the agent system."""

from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Any, Awaitable, Callable

from pydantic import BaseModel


@dataclass(frozen=True)
class Tool:
    name: str
    description: str
    parameters: type[BaseModel]
    execute: Callable[..., Awaitable[str]]


class ToolRegistry:
    def __init__(self) -> None:
        self._tools: dict[str, Tool] = {}

    def register(self, tool: Tool) -> None:
        if tool.name in self._tools:
            raise ValueError(f"Tool '{tool.name}' is already registered")
        self._tools[tool.name] = tool

    def get(self, name: str) -> Tool:
        if name not in self._tools:
            raise KeyError(f"Tool '{name}' not found")
        return self._tools[name]

    def tool_names(self) -> list[str]:
        return list(self._tools.keys())

    def describe_tools(self) -> str:
        lines: list[str] = []
        for tool in self._tools.values():
            schema = tool.parameters.model_json_schema()
            lines.append(
                f"- **{tool.name}**: {tool.description}\n"
                f"  Parameters: {json.dumps(schema, indent=2)}"
            )
        return "\n\n".join(lines)

    async def execute(self, name: str, params: dict[str, Any]) -> str:
        tool = self.get(name)
        validated = tool.parameters.model_validate(params)
        return await tool.execute(validated)
```

- [ ] **Step 8: Run test to verify it passes**

```bash
pytest tests/unit/test_agent_tools.py -v
```

Expected: all 6 tests PASS.

- [ ] **Step 9: Commit**

```bash
git add src/scrapurrr/agent/ tests/unit/test_agent_memory.py tests/unit/test_agent_tools.py
git commit -m "add: agent memory with stuck detection and tool registry"
```

---

### Task 12: Agent ReAct Loop

**Files:**
- Create: `src/scrapurrr/agent/loop.py`
- Create: `tests/unit/test_agent_loop.py`

- [ ] **Step 1: Write failing test for agent loop**

Create `tests/unit/test_agent_loop.py`:
```python
"""Tests for the agent ReAct loop."""

from __future__ import annotations

import json
from unittest.mock import AsyncMock, MagicMock

import pytest
from pydantic import BaseModel

from scrapurrr.agent.loop import AgentLoop
from scrapurrr.agent.tools import Tool, ToolRegistry
from scrapurrr.exceptions import MaxStepsError, StuckError


class Product(BaseModel):
    name: str
    price: float


class NavParams(BaseModel):
    url: str


class ExtractParams(BaseModel):
    pass


@pytest.fixture
def mock_provider() -> AsyncMock:
    return AsyncMock()


@pytest.fixture
def registry() -> ToolRegistry:
    reg = ToolRegistry()

    async def navigate(params: NavParams) -> str:
        return f"Navigated to {params.url}"

    async def extract(params: ExtractParams) -> str:
        return json.dumps({"name": "Widget", "price": 9.99})

    reg.register(Tool(name="navigate", description="Go to URL", parameters=NavParams, execute=navigate))
    reg.register(Tool(name="extract", description="Extract data", parameters=ExtractParams, execute=extract))
    return reg


class TestAgentLoop:
    @pytest.mark.asyncio
    async def test_completes_in_two_steps(
        self, mock_provider: AsyncMock, registry: ToolRegistry
    ) -> None:
        # Step 1: LLM says navigate
        # Step 2: LLM says extract
        # Step 3: LLM says done
        mock_provider.complete = AsyncMock(
            side_effect=[
                json.dumps({"tool": "navigate", "params": {"url": "https://shop.com"}}),
                json.dumps({"tool": "extract", "params": {}}),
                json.dumps({"tool": "done", "params": {}}),
            ]
        )
        mock_provider.extract_structured = AsyncMock(
            return_value=Product(name="Widget", price=9.99)
        )

        loop = AgentLoop(provider=mock_provider, tools=registry, schema=Product, max_steps=10)
        result = await loop.run("find products on shop.com")
        assert isinstance(result, Product)
        assert result.name == "Widget"

    @pytest.mark.asyncio
    async def test_raises_max_steps(
        self, mock_provider: AsyncMock, registry: ToolRegistry
    ) -> None:
        # LLM always navigates — never finishes
        mock_provider.complete = AsyncMock(
            return_value=json.dumps({"tool": "navigate", "params": {"url": "https://example.com"}})
        )

        loop = AgentLoop(provider=mock_provider, tools=registry, schema=Product, max_steps=3)
        with pytest.raises(MaxStepsError):
            await loop.run("find products")

    @pytest.mark.asyncio
    async def test_raises_stuck_error(
        self, mock_provider: AsyncMock, registry: ToolRegistry
    ) -> None:
        call_count = 0

        async def always_same_navigate(*args: object, **kwargs: object) -> str:
            nonlocal call_count
            call_count += 1
            return json.dumps({"tool": "navigate", "params": {"url": "https://same.com"}})

        mock_provider.complete = AsyncMock(side_effect=always_same_navigate)

        loop = AgentLoop(provider=mock_provider, tools=registry, schema=Product, max_steps=20)
        with pytest.raises((StuckError, MaxStepsError)):
            await loop.run("find products")
```

- [ ] **Step 2: Run test to verify it fails**

```bash
pytest tests/unit/test_agent_loop.py -v
```

Expected: FAIL — `ModuleNotFoundError`

- [ ] **Step 3: Implement agent loop**

Create `src/scrapurrr/agent/loop.py`:
```python
"""ReAct agent loop — Think, Act, Observe."""

from __future__ import annotations

import json
from typing import Any, TypeVar

from pydantic import BaseModel

from scrapurrr.agent.memory import AgentAction, AgentMemory
from scrapurrr.agent.tools import ToolRegistry
from scrapurrr.exceptions import MaxStepsError, StuckError
from scrapurrr.schemas import SchemaHelper
from scrapurrr.types import LLMProvider


T = TypeVar("T", bound=BaseModel)

_SYSTEM_PROMPT = """\
You are a web scraping agent. Your goal is to extract data matching the provided schema.

Available tools:
{tools}

To use a tool, respond with JSON: {{"tool": "<name>", "params": {{...}}}}
To finish, respond with: {{"tool": "done", "params": {{}}}}

Rules:
- Choose one tool per step
- Stop when you have enough data to populate the schema
- Do not visit the same URL more than twice
"""

_USER_PROMPT = """\
Goal: {goal}

Target schema:
{schema}

Data collected so far: {extracted_data}
Current URL: {current_url}
Recent actions: {recent_actions}

What is your next action? Respond with JSON only.
"""


class AgentLoop:
    def __init__(
        self,
        provider: LLMProvider,
        tools: ToolRegistry,
        schema: type[T],
        max_steps: int = 20,
    ) -> None:
        self._provider = provider
        self._tools = tools
        self._schema = schema
        self._max_steps = max_steps

    async def run(self, goal: str) -> T:
        memory = AgentMemory(goal=goal, schema=self._schema)
        system = _SYSTEM_PROMPT.format(tools=self._tools.describe_tools())

        for _ in range(self._max_steps):
            if memory.is_stuck():
                raise StuckError(
                    f"Agent is stuck after {memory.step_count} steps. "
                    f"History: {[a.tool for a in memory.recent_actions()]}"
                )

            # THINK
            user_prompt = _USER_PROMPT.format(
                goal=goal,
                schema=json.dumps(SchemaHelper.to_json_schema(self._schema), indent=2),
                extracted_data=_serialize_extractions(memory.extracted_data),
                current_url=memory.current_url or "none",
                recent_actions=_serialize_actions(memory.recent_actions(limit=5)),
            )

            response = await self._provider.complete(user_prompt, system_prompt=system)

            # Parse tool call
            try:
                parsed = json.loads(response)
                tool_name = parsed["tool"]
                tool_params = parsed.get("params", {})
            except (json.JSONDecodeError, KeyError):
                memory.record_action(AgentAction(
                    tool="parse_error", params={}, result=f"Could not parse: {response[:200]}"
                ))
                continue

            # DONE check
            if tool_name == "done":
                if memory.extracted_data:
                    return self._finalize(memory)
                memory.record_action(AgentAction(
                    tool="done", params={}, result="No data extracted yet"
                ))
                continue

            # ACT
            try:
                result = await self._tools.execute(tool_name, tool_params)
            except (KeyError, Exception) as exc:
                result = f"Error: {exc}"

            # OBSERVE
            action = AgentAction(tool=tool_name, params=tool_params, result=str(result)[:500])
            memory.record_action(action)

            if tool_name == "navigate":
                url = tool_params.get("url", "")
                memory.record_visit(url)

            if tool_name == "extract":
                self._try_parse_extraction(result, memory)

        raise MaxStepsError(f"Agent did not complete within {self._max_steps} steps")

    def _finalize(self, memory: AgentMemory) -> T:
        if len(memory.extracted_data) == 1:
            return memory.extracted_data[0]  # type: ignore[return-value]

        # If list type, return all
        if SchemaHelper.is_list_type(self._schema):
            return SchemaHelper.validate(
                [d.model_dump() for d in memory.extracted_data],
                self._schema,
            )

        return memory.extracted_data[-1]  # type: ignore[return-value]

    def _try_parse_extraction(self, result: str, memory: AgentMemory) -> None:
        try:
            parsed = json.loads(result)
            if isinstance(parsed, list):
                for item in parsed:
                    inner = self._get_inner_schema()
                    validated = inner.model_validate(item)
                    memory.record_extraction(validated)
            else:
                inner = self._get_inner_schema()
                validated = inner.model_validate(parsed)
                memory.record_extraction(validated)
        except Exception:
            pass  # extraction tool result wasn't JSON — that's OK

    def _get_inner_schema(self) -> type[BaseModel]:
        if SchemaHelper.is_list_type(self._schema):
            from typing import get_args
            return get_args(self._schema)[0]
        return self._schema  # type: ignore[return-value]


def _serialize_extractions(data: list[BaseModel]) -> str:
    if not data:
        return "none"
    return json.dumps([d.model_dump() for d in data[:10]])


def _serialize_actions(actions: list[AgentAction]) -> str:
    if not actions:
        return "none"
    return json.dumps([{"tool": a.tool, "params": a.params} for a in actions])
```

- [ ] **Step 4: Run test to verify it passes**

```bash
pytest tests/unit/test_agent_loop.py -v
```

Expected: all 3 tests PASS.

- [ ] **Step 5: Commit**

```bash
git add src/scrapurrr/agent/loop.py tests/unit/test_agent_loop.py
git commit -m "add: agent ReAct loop with stuck detection and max steps"
```

---

### Task 13: Scrapurrr Facade (Public API)

**Files:**
- Modify: `src/scrapurrr/__init__.py`
- Create: `tests/unit/test_scrapurrr.py`

- [ ] **Step 1: Write failing test for facade**

Create `tests/unit/test_scrapurrr.py`:
```python
"""Tests for the Scrapurrr public API facade."""

from __future__ import annotations

import json
from pathlib import Path
from textwrap import dedent
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from pydantic import BaseModel

from scrapurrr import Scrapurrr


class Product(BaseModel):
    name: str
    price: float


class TestScrapurrInit:
    def test_init_with_provider_string(self) -> None:
        scraper = Scrapurrr(provider="ollama/llama3")
        assert scraper._config.llm.provider == "ollama/llama3"

    def test_init_with_api_key(self) -> None:
        scraper = Scrapurrr(provider="openai/gpt-4o", api_key="sk-test")
        assert scraper._config.llm.api_key == "sk-test"

    def test_init_from_yaml(self, tmp_path: Path) -> None:
        yaml_file = tmp_path / "scrapurrr.yaml"
        yaml_file.write_text(dedent("""\
            llm:
              provider: anthropic/claude-3.5-sonnet
              api_key: sk-ant-test
        """))
        scraper = Scrapurrr(config_path=yaml_file)
        assert scraper._config.llm.provider == "anthropic/claude-3.5-sonnet"

    def test_init_defaults_to_ollama(self) -> None:
        scraper = Scrapurrr()
        assert scraper._config.llm.provider == "ollama/llama3"


class TestScrapurrExtract:
    @pytest.mark.asyncio
    async def test_extract_returns_typed_result(self) -> None:
        scraper = Scrapurrr(provider="ollama/llama3")

        mock_page = AsyncMock()
        mock_page.navigate = AsyncMock()
        mock_page.get_html = AsyncMock(
            return_value='<html><body><h1 class="title">Widget</h1><span class="price">$9.99</span></body></html>'
        )

        with patch.object(scraper, "_get_page", return_value=mock_page):
            with patch.object(scraper, "_ensure_launched", new_callable=AsyncMock):

                class SimpleProduct(BaseModel):
                    title: str
                    price: str

                result = await scraper.extract("https://shop.com", schema=SimpleProduct)
                assert isinstance(result, SimpleProduct)
                assert "Widget" in result.title


class TestScrapurrContextManager:
    @pytest.mark.asyncio
    async def test_context_manager_cleanup(self) -> None:
        scraper = Scrapurrr(provider="ollama/llama3")
        scraper._engine = AsyncMock()
        scraper._launched = True

        async with scraper:
            pass

        scraper._engine.close.assert_called_once()
```

- [ ] **Step 2: Run test to verify it fails**

```bash
pytest tests/unit/test_scrapurrr.py -v
```

Expected: FAIL — `ImportError`

- [ ] **Step 3: Implement Scrapurrr facade**

Replace `src/scrapurrr/__init__.py`:
```python
"""Scrapurrr — agentic web scraper with pluggable LLM providers."""

from __future__ import annotations

from pathlib import Path
from typing import Any, TypeVar

from pydantic import BaseModel

from scrapurrr.browser.engine import PlaywrightEngine, PlaywrightPage
from scrapurrr.browser.stealth import StealthManager
from scrapurrr.config import ScrapurrConfig
from scrapurrr.exceptions import ScrapurrError
from scrapurrr.extraction import Extractor
from scrapurrr.pipeline.cleaner import clean
from scrapurrr.pipeline.chunker import chunk
from scrapurrr.pipeline.fetcher import fetch
from scrapurrr.providers.litellm import LiteLLMProvider
from scrapurrr.types import LLMProvider, StealthHook


__version__ = "0.1.0"

T = TypeVar("T")


class Scrapurrr:
    def __init__(
        self,
        provider: str | None = None,
        api_key: str | None = None,
        base_url: str | None = None,
        config_path: Path | None = None,
        stealth_hooks: list[StealthHook] | None = None,
    ) -> None:
        if config_path and config_path.exists():
            self._config = ScrapurrConfig.from_yaml(config_path)
        else:
            self._config = ScrapurrConfig()

        if provider or api_key or base_url:
            self._config = self._config.override(
                provider=provider,
                api_key=api_key,
                base_url=base_url,
            )

        self._stealth = StealthManager(
            level=self._config.browser.stealth,
            hooks=stealth_hooks or [],
        )
        self._engine = PlaywrightEngine(self._config.browser, self._stealth)
        self._provider: LLMProvider = LiteLLMProvider(
            model=self._config.llm.provider,
            api_key=self._config.llm.api_key,
            base_url=self._config.llm.base_url,
        )
        self._extractor = Extractor(
            provider=self._provider,
            strategy=self._config.extraction.strategy,
        )
        self._launched = False

    async def _ensure_launched(self) -> None:
        if not self._launched:
            await self._engine.launch()
            self._launched = True

    async def _get_page(self) -> PlaywrightPage:
        await self._ensure_launched()
        return await self._engine.new_page()

    async def extract(self, url: str, schema: type[T]) -> T:
        page = await self._get_page()
        try:
            fetch_result = await fetch(page, url)
            clean_result = clean(fetch_result.html)

            chunks = chunk(
                clean_result.markdown,
                source_url=url,
            )

            if len(chunks.chunks) == 1:
                return await self._extractor.extract(fetch_result.html, schema)  # type: ignore[arg-type]

            # Multi-chunk: extract from each, merge
            import asyncio
            from scrapurrr.schemas import SchemaHelper

            results = await asyncio.gather(*[
                self._extractor.extract(c, schema)  # type: ignore[arg-type]
                for c in chunks.chunks
            ])
            # Return first successful result for single schemas
            if not SchemaHelper.is_list_type(schema):
                return results[0]

            # For list types, merge all results
            merged: list[Any] = []
            for r in results:
                if isinstance(r, list):
                    merged.extend(r)
                else:
                    merged.append(r)
            return SchemaHelper.validate(
                [item.model_dump() if hasattr(item, "model_dump") else item for item in merged],
                schema,
            )
        finally:
            pass  # page cleanup handled by context manager

    async def agent(
        self,
        task: str,
        schema: type[T],
        max_steps: int | None = None,
    ) -> T:
        from scrapurrr.agent.loop import AgentLoop
        from scrapurrr.agent.tools import ToolRegistry

        await self._ensure_launched()
        tools = await self._build_agent_tools()
        steps = max_steps or self._config.agent.max_steps

        loop = AgentLoop(
            provider=self._provider,
            tools=tools,
            schema=schema,  # type: ignore[arg-type]
            max_steps=steps,
        )
        return await loop.run(task)

    async def _build_agent_tools(self) -> ToolRegistry:
        from scrapurrr.agent.tools import Tool, ToolRegistry

        registry = ToolRegistry()
        page = await self._get_page()

        class NavParams(BaseModel):
            url: str

        class ScrollParams(BaseModel):
            direction: str = "down"

        class WaitParams(BaseModel):
            selector: str
            timeout: int = 10000

        class ExtractParams(BaseModel):
            pass

        class ReadPageParams(BaseModel):
            pass

        class ListLinksParams(BaseModel):
            pass

        async def navigate(params: NavParams) -> str:
            await page.navigate(params.url)
            return f"Navigated to {params.url}"

        async def scroll(params: ScrollParams) -> str:
            await page.scroll(params.direction)
            return f"Scrolled {params.direction}"

        async def wait(params: WaitParams) -> str:
            await page.wait_for(params.selector, timeout=params.timeout)
            return f"Waited for {params.selector}"

        async def extract(params: ExtractParams) -> str:
            html = await page.get_html()
            clean_result = clean(html)
            return clean_result.markdown[:2000]

        async def read_page(params: ReadPageParams) -> str:
            html = await page.get_html()
            clean_result = clean(html)
            return clean_result.markdown[:3000]

        async def list_links(params: ListLinksParams) -> str:
            import json
            html = await page.get_html()
            from bs4 import BeautifulSoup
            soup = BeautifulSoup(html, "html.parser")
            links = []
            for a in soup.find_all("a", href=True):
                text = a.get_text(strip=True)
                href = a["href"]
                if text and href:
                    links.append({"text": text, "url": href})
            return json.dumps(links[:50])

        registry.register(Tool(name="navigate", description="Navigate to a URL", parameters=NavParams, execute=navigate))
        registry.register(Tool(name="scroll", description="Scroll the page up or down", parameters=ScrollParams, execute=scroll))
        registry.register(Tool(name="wait", description="Wait for a CSS selector to appear", parameters=WaitParams, execute=wait))
        registry.register(Tool(name="extract", description="Extract content from current page as markdown", parameters=ExtractParams, execute=extract))
        registry.register(Tool(name="read_page", description="Read current page content as markdown", parameters=ReadPageParams, execute=read_page))
        registry.register(Tool(name="list_links", description="List all links on current page", parameters=ListLinksParams, execute=list_links))

        return registry

    def register_tool(self, tool: Any) -> None:
        # Stored for later use in agent()
        if not hasattr(self, "_custom_tools"):
            self._custom_tools: list[Any] = []
        self._custom_tools.append(tool)

    async def close(self) -> None:
        if self._launched:
            await self._engine.close()
            self._launched = False

    async def __aenter__(self) -> Scrapurrr:
        return self

    async def __aexit__(self, *args: object) -> None:
        await self.close()
```

- [ ] **Step 4: Run test to verify it passes**

```bash
pytest tests/unit/test_scrapurrr.py -v
```

Expected: all 5 tests PASS.

- [ ] **Step 5: Run full suite + linters**

```bash
pytest tests/ -v
ruff check src/
mypy src/
```

Expected: all tests PASS, linters clean. Fix any mypy/ruff issues found.

- [ ] **Step 6: Commit**

```bash
git add src/scrapurrr/__init__.py tests/unit/test_scrapurrr.py
git commit -m "add: Scrapurrr facade with extract() and agent() public API"
```

---

### Task 14: Integration Test with Local Test Server

**Files:**
- Create: `tests/integration/__init__.py`
- Create: `tests/integration/test_extract_pipeline.py`

- [ ] **Step 1: Write integration test**

Create `tests/integration/__init__.py` (empty).

Create `tests/integration/test_extract_pipeline.py`:
```python
"""Integration tests — full extract pipeline against local test server."""

from __future__ import annotations

from pathlib import Path
from unittest.mock import AsyncMock, patch

import pytest
from pydantic import BaseModel
from pytest_httpserver import HTTPServer

from scrapurrr import Scrapurrr


FIXTURE_HTML = (Path(__file__).parent.parent / "fixtures" / "pages" / "simple_product.html").read_text()


class Product(BaseModel):
    title: str
    price: str
    description: str


class TestExtractPipeline:
    @pytest.mark.asyncio
    async def test_extract_with_css_strategy(self, httpserver: HTTPServer) -> None:
        httpserver.expect_request("/products").respond_with_data(
            FIXTURE_HTML, content_type="text/html"
        )
        url = httpserver.url_for("/products")

        async with Scrapurrr(provider="ollama/llama3") as scraper:
            # Force CSS strategy to avoid LLM calls
            scraper._extractor._strategy = "css"
            result = await scraper.extract(url, schema=Product)

        assert isinstance(result, Product)
        assert "Widget" in result.title
        assert "29.99" in result.price

    @pytest.mark.asyncio
    async def test_extract_with_auto_strategy_uses_css_first(
        self, httpserver: HTTPServer
    ) -> None:
        httpserver.expect_request("/products").respond_with_data(
            FIXTURE_HTML, content_type="text/html"
        )
        url = httpserver.url_for("/products")

        mock_provider = AsyncMock()

        async with Scrapurrr(provider="ollama/llama3") as scraper:
            scraper._provider = mock_provider
            scraper._extractor = __import__(
                "scrapurrr.extraction", fromlist=["Extractor"]
            ).Extractor(provider=mock_provider, strategy="auto")

            result = await scraper.extract(url, schema=Product)

        assert isinstance(result, Product)
        # CSS handled it — LLM provider should NOT have been called
        mock_provider.extract_structured.assert_not_called()
```

- [ ] **Step 2: Run integration test**

```bash
pytest tests/integration/test_extract_pipeline.py -v
```

Expected: both tests PASS (requires `playwright install chromium` to have been run).

- [ ] **Step 3: Commit**

```bash
git add tests/integration/
git commit -m "add: integration tests for extract pipeline with local test server"
```

---

### Task 15: Example Config & Final Verification

**Files:**
- Create: `scrapurrr.yaml.example`
- Create: `src/scrapurrr/extraction/vision.py`

- [ ] **Step 1: Create example config**

Create `scrapurrr.yaml.example`:
```yaml
# Scrapurrr Configuration
# Copy to scrapurrr.yaml and customize

llm:
  # Provider string (LiteLLM format)
  # Examples: ollama/llama3, openai/gpt-4o, anthropic/claude-3.5-sonnet
  provider: ollama/llama3

  # API key — use env: prefix to read from environment
  # api_key: env:OPENAI_API_KEY

  # Custom base URL for self-hosted models (vLLM, etc.)
  # base_url: http://localhost:8000/v1

browser:
  headless: true
  stealth: basic    # off | basic | full
  proxy: null       # http://user:pass@proxy:8080
  timeout: 30000    # page load timeout in ms

extraction:
  strategy: auto    # auto | css | llm

agent:
  max_steps: 20
  timeout: 300      # seconds
```

- [ ] **Step 2: Create vision stub**

Create `src/scrapurrr/extraction/vision.py`:
```python
"""Vision-based extraction — future implementation."""

from __future__ import annotations

from typing import TypeVar

from pydantic import BaseModel

from scrapurrr.types import LLMProvider


T = TypeVar("T", bound=BaseModel)


class VisionExtractor:
    def __init__(self, provider: LLMProvider) -> None:
        self._provider = provider

    async def can_handle(self, html: str, schema: type[BaseModel]) -> bool:
        return self._provider.supports_vision

    async def extract(self, image: bytes, schema: type[T]) -> T:
        return await self._provider.extract_from_image(image=image, schema=schema)
```

- [ ] **Step 3: Run full test suite**

```bash
pytest tests/ -v --tb=short
```

Expected: all tests PASS.

- [ ] **Step 4: Run all linters**

```bash
ruff check src/ tests/
mypy src/
```

Expected: clean.

- [ ] **Step 5: Check coverage**

```bash
coverage run -m pytest tests/ && coverage report --show-missing
```

Expected: 80%+ coverage.

- [ ] **Step 6: Final commit**

```bash
git add scrapurrr.yaml.example src/scrapurrr/extraction/vision.py
git commit -m "add: example config and vision extraction stub"
```

- [ ] **Step 7: Verify package installs cleanly**

```bash
pip install -e . && python -c "from scrapurrr import Scrapurrr; print(Scrapurrr)"
```

Expected: prints `<class 'scrapurrr.Scrapurrr'>`.
