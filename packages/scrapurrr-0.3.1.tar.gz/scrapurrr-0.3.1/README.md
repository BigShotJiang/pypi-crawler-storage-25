<p align="center">
  <img src="public/COVER.png" alt="Scrapurrr" width="600" />
</p>

<p align="center">
  <strong>Agentic web scraping framework with a built-in chat CLI.</strong>
</p>

<p align="center">
  <img src="https://img.shields.io/badge/python-3.11%2B-blue" alt="Python" />
  <img src="https://img.shields.io/badge/license-MIT-green" alt="License" />
  <img src="https://img.shields.io/badge/version-0.2.0-orange" alt="Version" />
</p>

## What is Scrapurrr?

Scrapurrr is a Python framework for building agentic web scraping and automation apps, with a ready-to-use interactive CLI called `chatpurrr`.

**As a framework**, you define a Pydantic schema, point it at a URL, and get back typed data. It handles browser rendering, anti-detection, pagination, and LLM-powered extraction automatically.

**As a CLI tool**, you run `chatpurrr` and talk to it in natural language. Navigate pages, inspect elements, extract data, all from your terminal.

Built on PatchRight and CloakBrowser for undetected browsing. Supports 100+ LLM providers via LiteLLM.

## Install

```bash
pip install scrapurrr
```

## Get Started

**Use the chat CLI:**

```bash
chatpurrr
```

**Use the framework:**

```python
from scrapurrr import Scrapurrr
```

## Documentation

- [Chatpurrr](docs/CHATPURRR.md) - Interactive CLI usage, slash commands, setup
- [Framework](docs/FRAMEWORK.md) - Library API, extraction, agent mode, element inspection, configuration

## Usage Policy

Scrapurrr is intended for legitimate use cases: data collection from public sources, authorized testing, research, and personal automation. Users are responsible for complying with the terms of service of any website they interact with. Respect `robots.txt`, rate limits, and applicable laws.

## License

MIT. See [LICENSE](LICENSE).
