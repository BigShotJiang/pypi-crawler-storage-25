"""Shared test fixtures for scrapurrr."""
