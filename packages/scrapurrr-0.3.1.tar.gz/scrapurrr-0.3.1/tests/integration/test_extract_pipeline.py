"""Integration tests — full extract pipeline against local test server."""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING
from unittest.mock import AsyncMock

import pytest
from pydantic import BaseModel

from scrapurrr import Scrapurrr

if TYPE_CHECKING:
    from pytest_httpserver import HTTPServer

FIXTURE_HTML = (
    Path(__file__).parent.parent / "fixtures" / "pages" / "simple_product.html"
).read_text()


class Product(BaseModel):
    title: str
    price: str
    description: str


class TestExtractPipeline:
    @pytest.mark.asyncio
    async def test_extract_with_css_strategy(self, httpserver: HTTPServer) -> None:
        httpserver.expect_request("/products").respond_with_data(
            FIXTURE_HTML, content_type="text/html"
        )
        url = httpserver.url_for("/products")

        async with Scrapurrr(provider="ollama/llama3") as scraper:
            scraper._extractor._strategy = "css"
            result = await scraper.extract(url, schema=Product)

        assert isinstance(result, Product)
        assert "Widget" in result.title
        assert "29.99" in result.price

    @pytest.mark.asyncio
    async def test_extract_with_auto_strategy_uses_css_first(self, httpserver: HTTPServer) -> None:
        httpserver.expect_request("/products").respond_with_data(
            FIXTURE_HTML, content_type="text/html"
        )
        url = httpserver.url_for("/products")

        mock_provider = AsyncMock()

        async with Scrapurrr(provider="ollama/llama3") as scraper:
            # Replace the provider on the extractor to track if LLM was called
            scraper._extractor._llm._provider = mock_provider

            result = await scraper.extract(url, schema=Product)

        assert isinstance(result, Product)
        # CSS handled it — LLM provider should NOT have been called
        mock_provider.extract_structured.assert_not_called()
