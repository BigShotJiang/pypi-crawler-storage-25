"""Tests for the DeepCrawler."""

from __future__ import annotations

from unittest.mock import AsyncMock

import pytest

from scrapurrr.core.types import FetchResult
from scrapurrr.crawler import CrawlResult, DeepCrawler, _extract_links, _is_same_domain


class TestExtractLinks:
    def test_extracts_absolute_links(self) -> None:
        html = '<html><body><a href="https://example.com/page1">Page 1</a></body></html>'
        links = _extract_links(html, "https://example.com")
        assert "https://example.com/page1" in links

    def test_resolves_relative_links(self) -> None:
        html = '<html><body><a href="/about">About</a></body></html>'
        links = _extract_links(html, "https://example.com")
        assert "https://example.com/about" in links

    def test_strips_fragments(self) -> None:
        html = '<html><body><a href="/page#section">Link</a></body></html>'
        links = _extract_links(html, "https://example.com")
        assert "https://example.com/page" in links
        assert any("#" in link for link in links) is False

    def test_deduplicates_links(self) -> None:
        html = '<html><body><a href="/page">Link 1</a><a href="/page">Link 2</a></body></html>'
        links = _extract_links(html, "https://example.com")
        assert links.count("https://example.com/page") == 1

    def test_skips_non_http_links(self) -> None:
        html = (
            "<html><body>"
            '<a href="mailto:test@example.com">Email</a>'
            '<a href="javascript:void(0)">JS</a>'
            '<a href="https://example.com/ok">OK</a>'
            "</body></html>"
        )
        links = _extract_links(html, "https://example.com")
        assert len(links) == 1
        assert "https://example.com/ok" in links


class TestIsSameDomain:
    def test_same_domain(self) -> None:
        assert _is_same_domain("https://example.com/page", "https://example.com") is True

    def test_different_domain(self) -> None:
        assert _is_same_domain("https://other.com/page", "https://example.com") is False

    def test_subdomain_is_different(self) -> None:
        assert _is_same_domain("https://sub.example.com", "https://example.com") is False


class TestCrawlResult:
    def test_frozen(self) -> None:
        result = CrawlResult(
            url="https://x.com", html="<p>hi</p>", markdown="hi", depth=0, links=()
        )
        with pytest.raises(AttributeError):
            result.url = "https://other.com"  # type: ignore[misc]


class TestDeepCrawler:
    def _make_scraper(self, pages: dict[str, str]) -> object:
        """Create a mock scraper that returns HTML from a dict."""
        scraper = AsyncMock()
        scraper._extractor = AsyncMock()

        async def _do_fetch(url: str) -> FetchResult:
            html = pages.get(url, "<html><body></body></html>")
            return FetchResult(url=url, html=html, status=200, headers={})

        scraper._do_fetch = _do_fetch
        return scraper

    @pytest.mark.asyncio
    async def test_crawl_single_page(self) -> None:
        pages = {"https://example.com": "<html><body><p>Hello</p></body></html>"}
        scraper = self._make_scraper(pages)
        crawler = DeepCrawler(scraper, max_depth=0, max_pages=10)
        results = await crawler.crawl("https://example.com")
        assert len(results) == 1
        assert results[0].url == "https://example.com"
        assert results[0].depth == 0

    @pytest.mark.asyncio
    async def test_crawl_follows_links(self) -> None:
        pages = {
            "https://example.com": (
                '<html><body><a href="https://example.com/page1">P1</a></body></html>'
            ),
            "https://example.com/page1": "<html><body><p>Page 1</p></body></html>",
        }
        scraper = self._make_scraper(pages)
        crawler = DeepCrawler(scraper, max_depth=1, max_pages=10)
        results = await crawler.crawl("https://example.com")
        urls = {r.url for r in results}
        assert "https://example.com" in urls
        assert "https://example.com/page1" in urls

    @pytest.mark.asyncio
    async def test_crawl_respects_max_depth(self) -> None:
        pages = {
            "https://example.com": '<html><body><a href="https://example.com/a">A</a></body></html>',
            "https://example.com/a": '<html><body><a href="https://example.com/b">B</a></body></html>',
            "https://example.com/b": "<html><body><p>Deep</p></body></html>",
        }
        scraper = self._make_scraper(pages)
        crawler = DeepCrawler(scraper, max_depth=1, max_pages=10)
        results = await crawler.crawl("https://example.com")
        urls = {r.url for r in results}
        assert "https://example.com/b" not in urls

    @pytest.mark.asyncio
    async def test_crawl_respects_max_pages(self) -> None:
        pages = {
            "https://example.com": (
                "<html><body>"
                '<a href="https://example.com/1">1</a>'
                '<a href="https://example.com/2">2</a>'
                '<a href="https://example.com/3">3</a>'
                "</body></html>"
            ),
            "https://example.com/1": "<html><body>1</body></html>",
            "https://example.com/2": "<html><body>2</body></html>",
            "https://example.com/3": "<html><body>3</body></html>",
        }
        scraper = self._make_scraper(pages)
        crawler = DeepCrawler(scraper, max_depth=2, max_pages=2)
        results = await crawler.crawl("https://example.com")
        assert len(results) <= 2

    @pytest.mark.asyncio
    async def test_crawl_same_domain_filter(self) -> None:
        pages = {
            "https://example.com": (
                "<html><body>"
                '<a href="https://example.com/local">Local</a>'
                '<a href="https://other.com/external">External</a>'
                "</body></html>"
            ),
            "https://example.com/local": "<html><body>Local</body></html>",
            "https://other.com/external": "<html><body>External</body></html>",
        }
        scraper = self._make_scraper(pages)
        crawler = DeepCrawler(scraper, max_depth=1, max_pages=10, same_domain=True)
        results = await crawler.crawl("https://example.com")
        urls = {r.url for r in results}
        assert "https://other.com/external" not in urls

    @pytest.mark.asyncio
    async def test_crawl_url_pattern_filter(self) -> None:
        pages = {
            "https://example.com": (
                "<html><body>"
                '<a href="https://example.com/blog/post1">Blog</a>'
                '<a href="https://example.com/about">About</a>'
                "</body></html>"
            ),
            "https://example.com/blog/post1": "<html><body>Blog post</body></html>",
            "https://example.com/about": "<html><body>About page</body></html>",
        }
        scraper = self._make_scraper(pages)
        crawler = DeepCrawler(scraper, max_depth=1, max_pages=10, url_pattern=r"/blog/")
        results = await crawler.crawl("https://example.com")
        urls = {r.url for r in results}
        # Start URL is always visited, but /about should be filtered out
        assert "https://example.com/about" not in urls

    @pytest.mark.asyncio
    async def test_crawl_deduplicates_urls(self) -> None:
        pages = {
            "https://example.com": (
                "<html><body>"
                '<a href="https://example.com/page">Link 1</a>'
                '<a href="https://example.com/page">Link 2</a>'
                "</body></html>"
            ),
            "https://example.com/page": "<html><body>Page</body></html>",
        }
        scraper = self._make_scraper(pages)
        crawler = DeepCrawler(scraper, max_depth=1, max_pages=10)
        results = await crawler.crawl("https://example.com")
        page_results = [r for r in results if r.url == "https://example.com/page"]
        assert len(page_results) == 1

    @pytest.mark.asyncio
    async def test_crawl_handles_fetch_errors(self) -> None:
        scraper = AsyncMock()

        call_count = 0

        async def _do_fetch(url: str) -> FetchResult:
            nonlocal call_count
            call_count += 1
            if "bad" in url:
                raise Exception("fetch failed")
            return FetchResult(
                url=url,
                html='<html><body><a href="https://example.com/bad">Bad</a></body></html>',
                status=200,
                headers={},
            )

        scraper._do_fetch = _do_fetch
        crawler = DeepCrawler(scraper, max_depth=1, max_pages=10)
        results = await crawler.crawl("https://example.com")
        # Should still return the successful page
        assert len(results) == 1
