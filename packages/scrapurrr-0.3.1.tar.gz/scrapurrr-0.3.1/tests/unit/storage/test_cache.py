"""Tests for page cache."""

import time
from unittest.mock import patch

from scrapurrr.core.types import FetchResult
from scrapurrr.storage.cache import PageCache


def test_cache_put_and_get() -> None:
    cache = PageCache(ttl=60)
    result = FetchResult(url="https://example.com", html="<html>Hi</html>", status=200, headers={})
    cache.put("https://example.com", result)
    assert cache.get("https://example.com") == result


def test_cache_miss() -> None:
    cache = PageCache(ttl=60)
    assert cache.get("https://example.com") is None


def test_cache_expiry() -> None:
    cache = PageCache(ttl=1)
    result = FetchResult(url="https://example.com", html="<html>Hi</html>", status=200, headers={})
    cache.put("https://example.com", result)
    with patch("scrapurrr.storage.cache.time") as mock_time:
        mock_time.time.return_value = time.time() + 2
        assert cache.get("https://example.com") is None


def test_cache_clear() -> None:
    cache = PageCache(ttl=60)
    result = FetchResult(url="https://example.com", html="<html>Hi</html>", status=200, headers={})
    cache.put("https://example.com", result)
    cache.clear()
    assert cache.size == 0


def test_cache_size() -> None:
    cache = PageCache(ttl=60)
    result = FetchResult(url="https://a.com", html="a", status=200, headers={})
    cache.put("https://a.com", result)
    cache.put("https://b.com", result)
    assert cache.size == 2
