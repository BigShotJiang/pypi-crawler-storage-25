"""Tests for export utilities."""

import json
from pathlib import Path

from pydantic import BaseModel

from scrapurrr.storage.export import to_csv, to_csv_str, to_json, to_json_str


class Product(BaseModel):
    name: str
    price: float


def test_to_json_str_single() -> None:
    product = Product(name="Widget", price=9.99)
    result = to_json_str(product)
    parsed = json.loads(result)
    assert parsed["name"] == "Widget"
    assert parsed["price"] == 9.99


def test_to_json_str_list() -> None:
    products = [Product(name="A", price=1.0), Product(name="B", price=2.0)]
    result = to_json_str(products)
    parsed = json.loads(result)
    assert len(parsed) == 2


def test_to_csv_str_single() -> None:
    product = Product(name="Widget", price=9.99)
    result = to_csv_str(product)
    assert "name,price" in result
    assert "Widget" in result


def test_to_csv_str_list() -> None:
    products = [Product(name="A", price=1.0), Product(name="B", price=2.0)]
    result = to_csv_str(products)
    lines = result.strip().split("\n")
    assert len(lines) == 3  # header + 2 rows


def test_to_json_file(tmp_path: Path) -> None:
    product = Product(name="Widget", price=9.99)
    path = tmp_path / "output.json"
    to_json(product, path)
    assert path.exists()
    parsed = json.loads(path.read_text())
    assert parsed["name"] == "Widget"


def test_to_csv_file(tmp_path: Path) -> None:
    products = [Product(name="A", price=1.0)]
    path = tmp_path / "output.csv"
    to_csv(products, path)
    assert path.exists()
    assert "A" in path.read_text()


def test_to_csv_empty() -> None:
    assert to_csv_str([]) == ""
