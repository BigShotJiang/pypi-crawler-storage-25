"""Tests for result deduplication."""

from __future__ import annotations

from pydantic import BaseModel

from scrapurrr.storage.dedup import deduplicate


class Item(BaseModel):
    name: str
    url: str
    price: float = 0.0


class TestDeduplicate:
    def test_empty_list_returns_empty(self):
        assert deduplicate([]) == []

    def test_no_duplicates_unchanged(self):
        items = [
            Item(name="A", url="https://a.com"),
            Item(name="B", url="https://b.com"),
        ]
        result = deduplicate(items)
        assert result == items

    def test_all_fields_dedup(self):
        item = Item(name="A", url="https://a.com")
        items = [item, item, Item(name="B", url="https://b.com")]
        result = deduplicate(items)
        assert len(result) == 2
        assert result[0].name == "A"
        assert result[1].name == "B"

    def test_key_fields_dedup(self):
        items = [
            Item(name="A", url="https://a.com", price=10.0),
            Item(name="A", url="https://a.com", price=20.0),  # same name+url, different price
            Item(name="B", url="https://b.com"),
        ]
        result = deduplicate(items, key_fields=["name", "url"])
        assert len(result) == 2

    def test_key_fields_keeps_first(self):
        items = [
            Item(name="A", url="https://a.com", price=10.0),
            Item(name="A", url="https://a.com", price=99.0),
        ]
        result = deduplicate(items, key_fields=["name"])
        assert len(result) == 1
        assert result[0].price == 10.0  # first one kept

    def test_single_key_field(self):
        items = [
            Item(name="dup", url="https://a.com"),
            Item(name="dup", url="https://b.com"),
            Item(name="unique", url="https://c.com"),
        ]
        result = deduplicate(items, key_fields=["name"])
        assert len(result) == 2

    def test_preserves_order(self):
        items = [
            Item(name="C", url="https://c.com"),
            Item(name="A", url="https://a.com"),
            Item(name="B", url="https://b.com"),
            Item(name="A", url="https://a.com"),  # duplicate
        ]
        result = deduplicate(items)
        assert [r.name for r in result] == ["C", "A", "B"]

    def test_nonexistent_key_field_uses_none(self):
        items = [
            Item(name="A", url="https://a.com"),
            Item(name="B", url="https://b.com"),
        ]
        # nonexistent field defaults to None for both — they're "same key" only if same value
        result = deduplicate(items, key_fields=["nonexistent"])
        # both map to None so only first survives
        assert len(result) == 1
