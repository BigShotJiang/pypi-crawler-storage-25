"""Tests for AgentCheckpoint."""

from __future__ import annotations

import json
from typing import TYPE_CHECKING

from scrapurrr.storage.checkpoint import AgentCheckpoint

if TYPE_CHECKING:
    from pathlib import Path


class TestAgentCheckpoint:
    def test_save_creates_file(self, tmp_path: Path):
        cp = AgentCheckpoint(tmp_path / "checkpoint.json")
        cp.save({"goal": "test", "step_count": 3})
        assert (tmp_path / "checkpoint.json").exists()

    def test_save_writes_json(self, tmp_path: Path):
        cp = AgentCheckpoint(tmp_path / "checkpoint.json")
        data = {"goal": "scrape", "visited_urls": ["https://a.com"], "step_count": 5}
        cp.save(data)
        loaded = json.loads((tmp_path / "checkpoint.json").read_text())
        assert loaded == data

    def test_load_returns_none_when_missing(self, tmp_path: Path):
        cp = AgentCheckpoint(tmp_path / "nonexistent.json")
        assert cp.load() is None

    def test_load_returns_data(self, tmp_path: Path):
        cp = AgentCheckpoint(tmp_path / "checkpoint.json")
        original = {"goal": "test", "step_count": 7, "current_url": "https://x.com"}
        cp.save(original)
        loaded = cp.load()
        assert loaded == original

    def test_delete_removes_file(self, tmp_path: Path):
        path = tmp_path / "checkpoint.json"
        cp = AgentCheckpoint(path)
        cp.save({"goal": "test"})
        assert path.exists()
        cp.delete()
        assert not path.exists()

    def test_delete_noop_when_missing(self, tmp_path: Path):
        cp = AgentCheckpoint(tmp_path / "no_file.json")
        cp.delete()  # should not raise

    def test_load_returns_none_on_invalid_json(self, tmp_path: Path):
        path = tmp_path / "bad.json"
        path.write_text("not valid json {{{{")
        cp = AgentCheckpoint(path)
        assert cp.load() is None

    def test_save_handles_non_serializable_via_default_str(self, tmp_path: Path):
        from datetime import datetime

        cp = AgentCheckpoint(tmp_path / "checkpoint.json")
        cp.save({"ts": datetime(2024, 1, 1)})  # datetime not JSON-serializable by default
        loaded = cp.load()
        assert loaded is not None
        assert "ts" in loaded
