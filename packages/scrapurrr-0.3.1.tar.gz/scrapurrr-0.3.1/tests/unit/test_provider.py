"""Tests for LiteLLM provider wrapper."""

from __future__ import annotations

import json
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from pydantic import BaseModel

from scrapurrr.core.exceptions import ProviderError, RateLimitError, SchemaError
from scrapurrr.providers.litellm import LiteLLMProvider


class Product(BaseModel):
    name: str
    price: float


@pytest.fixture
def provider() -> LiteLLMProvider:
    return LiteLLMProvider(model="openai/gpt-4o", api_key="sk-test")


@pytest.mark.asyncio
async def test_extract_structured_success(provider: LiteLLMProvider) -> None:
    mock_response = MagicMock()
    mock_response.choices = [MagicMock()]
    mock_response.choices[0].message.content = json.dumps({"name": "Widget", "price": 9.99})

    with patch("scrapurrr.providers.litellm.acompletion", new_callable=AsyncMock) as mock_complete:
        mock_complete.return_value = mock_response
        result = await provider.extract_structured("some content", Product)

    assert isinstance(result, Product)
    assert result.name == "Widget"
    assert result.price == 9.99


@pytest.mark.asyncio
async def test_extract_structured_retries_on_validation_failure(provider: LiteLLMProvider) -> None:
    bad_response = MagicMock()
    bad_response.choices = [MagicMock()]
    bad_response.choices[0].message.content = '{"name": "Widget"}'  # missing price

    good_response = MagicMock()
    good_response.choices = [MagicMock()]
    good_response.choices[0].message.content = json.dumps({"name": "Widget", "price": 9.99})

    with patch("scrapurrr.providers.litellm.acompletion", new_callable=AsyncMock) as mock_complete:
        mock_complete.side_effect = [bad_response, good_response]
        result = await provider.extract_structured("some content", Product)

    assert result.price == 9.99
    assert mock_complete.call_count == 2


@pytest.mark.asyncio
async def test_extract_structured_raises_after_retry_exhausted(provider: LiteLLMProvider) -> None:
    bad_response = MagicMock()
    bad_response.choices = [MagicMock()]
    bad_response.choices[0].message.content = '{"invalid": true}'

    with patch("scrapurrr.providers.litellm.acompletion", new_callable=AsyncMock) as mock_complete:
        mock_complete.return_value = bad_response
        with pytest.raises(SchemaError):
            await provider.extract_structured("some content", Product)


@pytest.mark.asyncio
async def test_complete_success(provider: LiteLLMProvider) -> None:
    mock_response = MagicMock()
    mock_response.choices = [MagicMock()]
    mock_response.choices[0].message.content = "The answer is 42"

    with patch("scrapurrr.providers.litellm.acompletion", new_callable=AsyncMock) as mock_complete:
        mock_complete.return_value = mock_response
        result = await provider.complete("What is the answer?")

    assert result == "The answer is 42"


@pytest.mark.asyncio
async def test_complete_api_failure_raises_provider_error(provider: LiteLLMProvider) -> None:
    with patch("scrapurrr.providers.litellm.acompletion", new_callable=AsyncMock) as mock_complete:
        mock_complete.side_effect = Exception("API connection failed")
        with pytest.raises(ProviderError, match="API connection failed"):
            await provider.complete("test")


@pytest.mark.asyncio
async def test_empty_choices_raises_provider_error(provider: LiteLLMProvider) -> None:
    mock_response = MagicMock()
    mock_response.choices = []
    with patch("scrapurrr.providers.litellm.acompletion", new_callable=AsyncMock) as mock_complete:
        mock_complete.return_value = mock_response
        with pytest.raises(ProviderError, match="empty choices"):
            await provider.complete("test")


@pytest.mark.asyncio
async def test_none_content_raises_provider_error(provider: LiteLLMProvider) -> None:
    mock_response = MagicMock()
    mock_response.choices = [MagicMock()]
    mock_response.choices[0].message.content = None
    with patch("scrapurrr.providers.litellm.acompletion", new_callable=AsyncMock) as mock_complete:
        mock_complete.return_value = mock_response
        with pytest.raises(ProviderError, match="None content"):
            await provider.complete("test")


@pytest.mark.asyncio
async def test_rate_limit_raises_rate_limit_error(provider: LiteLLMProvider) -> None:
    with patch("scrapurrr.providers.litellm.acompletion", new_callable=AsyncMock) as mock_complete:
        mock_complete.side_effect = Exception("RateLimitError: 429 Too Many Requests")
        with pytest.raises(RateLimitError):
            await provider.complete("test")


def test_supports_vision_based_on_model() -> None:
    vision_provider = LiteLLMProvider(model="openai/gpt-4o")
    assert vision_provider.supports_vision is True

    text_provider = LiteLLMProvider(model="ollama/llama3")
    assert text_provider.supports_vision is False


@pytest.mark.asyncio
async def test_extract_from_image_success(provider: LiteLLMProvider) -> None:
    mock_response = MagicMock()
    mock_response.choices = [MagicMock()]
    mock_response.choices[0].message.content = json.dumps({"name": "Widget", "price": 9.99})

    fake_image = b"\x89PNG\r\n\x1a\nfakeimagedata"

    with patch("scrapurrr.providers.litellm.acompletion", new_callable=AsyncMock) as mock_complete:
        mock_complete.return_value = mock_response
        result = await provider.extract_from_image(fake_image, Product)

    assert isinstance(result, Product)
    assert result.name == "Widget"
    assert result.price == 9.99

    # Verify the call included an image_url content part
    call_kwargs = mock_complete.call_args[1]
    messages = call_kwargs["messages"]
    user_msg = messages[-1]
    assert user_msg["role"] == "user"
    content_parts = user_msg["content"]
    types = [p["type"] for p in content_parts]
    assert "image_url" in types


@pytest.mark.asyncio
async def test_extract_from_image_empty_choices_raises(provider: LiteLLMProvider) -> None:
    mock_response = MagicMock()
    mock_response.choices = []

    with patch("scrapurrr.providers.litellm.acompletion", new_callable=AsyncMock) as mock_complete:
        mock_complete.return_value = mock_response
        with pytest.raises(ProviderError, match="Vision: empty choices"):
            await provider.extract_from_image(b"fake", Product)


@pytest.mark.asyncio
async def test_extract_from_image_bad_json_raises_schema_error(provider: LiteLLMProvider) -> None:
    mock_response = MagicMock()
    mock_response.choices = [MagicMock()]
    mock_response.choices[0].message.content = "not valid json at all"

    with patch("scrapurrr.providers.litellm.acompletion", new_callable=AsyncMock) as mock_complete:
        mock_complete.return_value = mock_response
        with pytest.raises(SchemaError, match="Vision extraction failed"):
            await provider.extract_from_image(b"fake", Product)
