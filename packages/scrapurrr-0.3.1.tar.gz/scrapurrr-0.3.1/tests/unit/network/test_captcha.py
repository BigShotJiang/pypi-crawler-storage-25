"""Tests for NullCaptchaSolver CAPTCHA detection."""

from __future__ import annotations

import pytest

from scrapurrr.network.captcha import CaptchaSolver, NullCaptchaSolver


class TestNullCaptchaSolverDetect:
    @pytest.fixture
    def solver(self) -> NullCaptchaSolver:
        return NullCaptchaSolver()

    @pytest.mark.asyncio
    async def test_no_captcha_returns_none(self, solver: NullCaptchaSolver):
        html = "<html><body><p>Hello world</p></body></html>"
        result = await solver.detect(html)
        assert result is None

    @pytest.mark.asyncio
    async def test_detects_recaptcha(self, solver: NullCaptchaSolver):
        html = '<html><body><div class="g-recaptcha" data-sitekey="abc"></div></body></html>'
        result = await solver.detect(html)
        assert result == "recaptcha"

    @pytest.mark.asyncio
    async def test_detects_hcaptcha(self, solver: NullCaptchaSolver):
        html = '<html><body><div class="h-captcha" data-sitekey="abc"></div></body></html>'
        result = await solver.detect(html)
        assert result == "hcaptcha"

    @pytest.mark.asyncio
    async def test_detects_cloudflare_turnstile(self, solver: NullCaptchaSolver):
        html = '<html><body><div class="cf-turnstile"></div></body></html>'
        result = await solver.detect(html)
        assert result == "cloudflare"

    @pytest.mark.asyncio
    async def test_detects_cloudflare_challenge_platform(self, solver: NullCaptchaSolver):
        html = "<html><head><script src='https://challenges.cloudflare.com/challenge-platform/h/b/turnstile'></script></head></html>"
        result = await solver.detect(html)
        assert result == "cloudflare"

    @pytest.mark.asyncio
    async def test_detects_funcaptcha(self, solver: NullCaptchaSolver):
        html = '<html><body><div id="funcaptcha"></div></body></html>'
        result = await solver.detect(html)
        assert result == "funcaptcha"

    @pytest.mark.asyncio
    async def test_detects_arkoselabs(self, solver: NullCaptchaSolver):
        html = '<html><body><script src="https://arkoselabs.com/v2/api.js"></script></body></html>'
        result = await solver.detect(html)
        assert result == "funcaptcha"

    @pytest.mark.asyncio
    async def test_case_insensitive_detection(self, solver: NullCaptchaSolver):
        html = "<html><body>GRECAPTCHA IS LOADED</body></html>"
        result = await solver.detect(html)
        assert result == "recaptcha"

    @pytest.mark.asyncio
    async def test_solve_returns_false(self, solver: NullCaptchaSolver):
        result = await solver.solve(page=None, captcha_type="recaptcha")
        assert result is False

    @pytest.mark.asyncio
    async def test_solve_default_captcha_type(self, solver: NullCaptchaSolver):
        result = await solver.solve(page=None)
        assert result is False


class TestCaptchaSolverProtocol:
    def test_null_solver_satisfies_protocol(self):
        solver = NullCaptchaSolver()
        assert isinstance(solver, CaptchaSolver)
