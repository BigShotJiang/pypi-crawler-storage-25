"""Tests for enhanced CAPTCHA solver."""

from __future__ import annotations

from unittest.mock import MagicMock

import pytest

from scrapurrr.network.captcha import SmartCaptchaSolver


@pytest.fixture
def solver() -> SmartCaptchaSolver:
    return SmartCaptchaSolver()


@pytest.mark.asyncio
async def test_detect_recaptcha(solver: SmartCaptchaSolver) -> None:
    html = '<div class="g-recaptcha" data-sitekey="abc123"></div>'
    assert await solver.detect(html) == "recaptcha_v2"


@pytest.mark.asyncio
async def test_detect_hcaptcha(solver: SmartCaptchaSolver) -> None:
    html = '<div class="h-captcha" data-sitekey="abc123"></div>'
    assert await solver.detect(html) == "hcaptcha"


@pytest.mark.asyncio
async def test_detect_cloudflare(solver: SmartCaptchaSolver) -> None:
    html = '<div class="cf-turnstile" data-sitekey="abc"></div>'
    assert await solver.detect(html) == "cloudflare_turnstile"


@pytest.mark.asyncio
async def test_detect_none(solver: SmartCaptchaSolver) -> None:
    html = "<html><body><p>No captcha here</p></body></html>"
    assert await solver.detect(html) is None


@pytest.mark.asyncio
async def test_detect_funcaptcha(solver: SmartCaptchaSolver) -> None:
    html = '<script src="https://arkoselabs.com/v2/api.js"></script>'
    assert await solver.detect(html) == "funcaptcha"


def test_extract_sitekey_recaptcha() -> None:
    solver = SmartCaptchaSolver()
    html = '<div class="g-recaptcha" data-sitekey="6LeIxAcTAAAAAJcZVRqyHh71UMIEGNQ_MXjiZKhI"></div>'
    key = solver._extract_sitekey(html, "recaptcha_v2")
    assert key == "6LeIxAcTAAAAAJcZVRqyHh71UMIEGNQ_MXjiZKhI"


@pytest.mark.asyncio
async def test_detect_challenges_cloudflare(solver: SmartCaptchaSolver) -> None:
    html = '<script src="https://challenges.cloudflare.com/turnstile/v0/api.js"></script>'
    assert await solver.detect(html) == "cloudflare_turnstile"


@pytest.mark.asyncio
async def test_detect_recaptcha_v3(solver: SmartCaptchaSolver) -> None:
    html = '<script src="https://www.google.com/recaptcha/api.js?render=explicit"></script>'
    assert await solver.detect(html) == "recaptcha_v2"


@pytest.mark.asyncio
async def test_solve_no_strategy_returns_false(solver: SmartCaptchaSolver) -> None:
    """Solver with no LLM and no token API returns False for unknown types."""
    result = await solver.solve(MagicMock(), captcha_type="image_captcha")
    assert result is False


@pytest.mark.asyncio
async def test_solve_unknown_type_returns_false(solver: SmartCaptchaSolver) -> None:
    result = await solver.solve(MagicMock(), captcha_type="unknown_captcha_xyz")
    assert result is False


def test_extract_sitekey_hcaptcha() -> None:
    solver = SmartCaptchaSolver()
    html = '<div class="h-captcha" data-sitekey="10000000-ffff-ffff-ffff-000000000001"></div>'
    key = solver._extract_sitekey(html, "hcaptcha")
    assert key == "10000000-ffff-ffff-ffff-000000000001"


def test_extract_sitekey_missing_returns_none() -> None:
    solver = SmartCaptchaSolver()
    html = "<html><body>no sitekey here</body></html>"
    key = solver._extract_sitekey(html, "recaptcha_v2")
    assert key is None
