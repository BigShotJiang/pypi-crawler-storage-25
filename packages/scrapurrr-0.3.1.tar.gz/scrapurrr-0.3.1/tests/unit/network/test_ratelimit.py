"""Tests for per-domain rate limiter."""

from __future__ import annotations

import asyncio
import time

import pytest

from scrapurrr.network.ratelimit import RateLimiter


class TestRateLimiter:
    @pytest.mark.asyncio
    async def test_first_request_passes_immediately(self) -> None:
        limiter = RateLimiter(requests_per_second=2.0)
        start = time.monotonic()
        await limiter.wait("https://example.com/page")
        elapsed = time.monotonic() - start
        # First request should not wait
        assert elapsed < 0.1

    @pytest.mark.asyncio
    async def test_second_request_is_delayed(self) -> None:
        limiter = RateLimiter(requests_per_second=2.0)
        await limiter.wait("https://example.com/page")

        start = time.monotonic()
        await limiter.wait("https://example.com/other")
        elapsed = time.monotonic() - start

        # Should wait at least ~0.5s (1/2 rps) minus a small tolerance
        assert elapsed >= 0.4

    @pytest.mark.asyncio
    async def test_different_domains_do_not_interfere(self) -> None:
        limiter = RateLimiter(requests_per_second=2.0)
        await limiter.wait("https://alpha.com/page")

        start = time.monotonic()
        await limiter.wait("https://beta.com/page")
        elapsed = time.monotonic() - start

        # Different domain — should not be delayed by alpha.com's rate limit
        assert elapsed < 0.1

    @pytest.mark.asyncio
    async def test_same_domain_repeated_requests_are_delayed(self) -> None:
        limiter = RateLimiter(requests_per_second=5.0)  # 0.2s min interval
        await limiter.wait("https://example.com/a")

        start = time.monotonic()
        await limiter.wait("https://example.com/b")
        elapsed = time.monotonic() - start

        assert elapsed >= 0.15  # generous tolerance

    @pytest.mark.asyncio
    async def test_high_rps_allows_fast_requests(self) -> None:
        limiter = RateLimiter(requests_per_second=100.0)  # 10ms min interval
        await limiter.wait("https://example.com/a")

        start = time.monotonic()
        await limiter.wait("https://example.com/b")
        elapsed = time.monotonic() - start

        # Should complete much faster than 0.5s
        assert elapsed < 0.1

    @pytest.mark.asyncio
    async def test_concurrent_requests_same_domain_are_serialized(self) -> None:
        limiter = RateLimiter(requests_per_second=10.0)  # 0.1s min interval
        results: list[float] = []

        async def make_request() -> None:
            await limiter.wait("https://example.com/resource")
            results.append(time.monotonic())

        start = time.monotonic()
        await asyncio.gather(make_request(), make_request(), make_request())
        total = time.monotonic() - start

        # 3 requests at 10 rps should take at least 0.2s
        assert total >= 0.18
        # Timestamps should be ordered (serialized)
        assert results[0] <= results[1] <= results[2]
