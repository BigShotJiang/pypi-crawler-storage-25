"""Tests for auto-pagination detection."""

from __future__ import annotations

from scrapurrr.network.pagination import _resolve_url, find_next_page_url


class TestResolveUrl:
    def test_absolute_href_unchanged(self):
        assert (
            _resolve_url("https://example.com/page/2", "https://example.com/page/1")
            == "https://example.com/page/2"
        )

    def test_relative_href_resolved(self):
        result = _resolve_url("/page/2", "https://example.com/page/1")
        assert result == "https://example.com/page/2"

    def test_relative_path_resolved(self):
        result = _resolve_url("page2.html", "https://example.com/news/")
        assert result == "https://example.com/news/page2.html"


class TestFindNextPageUrl:
    def test_rel_next_link(self):
        html = '<html><body><a rel="next" href="/page/2">Next</a></body></html>'
        result = find_next_page_url(html, "https://example.com/page/1")
        assert result == "https://example.com/page/2"

    def test_class_next_link(self):
        html = '<html><body><a class="next" href="/page/2">Next</a></body></html>'
        result = find_next_page_url(html, "https://example.com/page/1")
        assert result == "https://example.com/page/2"

    def test_aria_label_next(self):
        html = '<html><body><a aria-label="Next page" href="/page/2">›</a></body></html>'
        result = find_next_page_url(html, "https://example.com/page/1")
        assert result == "https://example.com/page/2"

    def test_text_next(self):
        html = '<html><body><a href="/page/2">Next</a></body></html>'
        result = find_next_page_url(html, "https://example.com/page/1")
        assert result == "https://example.com/page/2"

    def test_text_chevron(self):
        html = '<html><body><a href="/page/3">›</a></body></html>'
        result = find_next_page_url(html, "https://example.com/page/2")
        assert result == "https://example.com/page/3"

    def test_text_double_chevron(self):
        html = '<html><body><a href="/page/3">»</a></body></html>'
        result = find_next_page_url(html, "https://example.com/page/2")
        assert result == "https://example.com/page/3"

    def test_page_query_param_strategy(self):
        html = (
            '<html><body><a href="/results?page=2">2</a>'
            '<a href="/results?page=3">3</a></body></html>'
        )
        result = find_next_page_url(html, "https://example.com/results?page=2")
        assert result == "https://example.com/results?page=3"

    def test_no_next_page_returns_none(self):
        html = "<html><body><p>No pagination here</p></body></html>"
        result = find_next_page_url(html, "https://example.com/page/1")
        assert result is None

    def test_empty_html_returns_none(self):
        result = find_next_page_url("", "https://example.com/")
        assert result is None

    def test_pagination_li_next(self):
        html = (
            '<html><body><ul class="pagination">'
            '<li class="next"><a href="/p/2">Next</a>'
            "</li></ul></body></html>"
        )
        result = find_next_page_url(html, "https://example.com/p/1")
        assert result == "https://example.com/p/2"

    def test_absolute_next_href(self):
        html = '<html><body><a rel="next" href="https://other.com/page/2">Next</a></body></html>'
        result = find_next_page_url(html, "https://example.com/page/1")
        assert result == "https://other.com/page/2"

    def test_case_insensitive_next_text(self):
        html = '<html><body><a href="/page/2">NEXT</a></body></html>'
        result = find_next_page_url(html, "https://example.com/page/1")
        assert result == "https://example.com/page/2"
