"""Tests for agent streaming."""

from __future__ import annotations

import json
from unittest.mock import AsyncMock

import pytest
from pydantic import BaseModel

from scrapurrr.agent.loop import AgentLoop, AgentStep
from scrapurrr.agent.tools import Tool, ToolRegistry


class Product(BaseModel):
    name: str
    price: float


class NavParams(BaseModel):
    url: str


class ExtractParams(BaseModel):
    pass


@pytest.fixture
def mock_provider() -> AsyncMock:
    return AsyncMock()


@pytest.fixture
def registry() -> ToolRegistry:
    reg = ToolRegistry()

    async def navigate(params: NavParams) -> str:
        return f"Navigated to {params.url}"

    async def extract(params: ExtractParams) -> str:
        return json.dumps({"name": "Widget", "price": 9.99})

    reg.register(
        Tool(name="navigate", description="Go to URL", parameters=NavParams, execute=navigate)
    )
    reg.register(
        Tool(name="extract", description="Extract data", parameters=ExtractParams, execute=extract)
    )
    return reg


@pytest.mark.asyncio
async def test_stream_yields_steps(mock_provider: AsyncMock, registry: ToolRegistry) -> None:
    mock_provider.complete = AsyncMock(
        side_effect=[
            json.dumps({"tool": "navigate", "params": {"url": "https://shop.com"}}),
            json.dumps({"tool": "extract", "params": {}}),
            json.dumps({"tool": "done", "params": {}}),
        ]
    )

    loop = AgentLoop(provider=mock_provider, tools=registry, schema=Product, max_steps=10)
    steps = []
    async for item in loop.run_stream("find products"):
        steps.append(item)

    # Should have AgentStep objects and a final Product
    agent_steps = [s for s in steps if isinstance(s, AgentStep)]
    assert len(agent_steps) >= 2
    # Last yielded item should be the result
    assert isinstance(steps[-1], Product)


@pytest.mark.asyncio
async def test_stream_navigate_step_has_correct_tool(
    mock_provider: AsyncMock, registry: ToolRegistry
) -> None:
    mock_provider.complete = AsyncMock(
        side_effect=[
            json.dumps({"tool": "navigate", "params": {"url": "https://example.com"}}),
            json.dumps({"tool": "extract", "params": {}}),
            json.dumps({"tool": "done", "params": {}}),
        ]
    )

    loop = AgentLoop(provider=mock_provider, tools=registry, schema=Product, max_steps=10)
    steps = []
    async for item in loop.run_stream("find products"):
        steps.append(item)

    nav_steps = [s for s in steps if isinstance(s, AgentStep) and s.tool == "navigate"]
    assert len(nav_steps) == 1
    assert nav_steps[0].params == {"url": "https://example.com"}


@pytest.mark.asyncio
async def test_stream_final_result_is_product(
    mock_provider: AsyncMock, registry: ToolRegistry
) -> None:
    mock_provider.complete = AsyncMock(
        side_effect=[
            json.dumps({"tool": "navigate", "params": {"url": "https://shop.com"}}),
            json.dumps({"tool": "extract", "params": {}}),
            json.dumps({"tool": "done", "params": {}}),
        ]
    )

    loop = AgentLoop(provider=mock_provider, tools=registry, schema=Product, max_steps=10)
    results = []
    async for item in loop.run_stream("find products"):
        results.append(item)

    final = results[-1]
    assert isinstance(final, Product)
    assert final.name == "Widget"
    assert final.price == 9.99
