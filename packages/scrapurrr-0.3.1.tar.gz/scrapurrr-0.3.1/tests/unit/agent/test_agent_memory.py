"""Tests for agent short-term memory."""

from pydantic import BaseModel

from scrapurrr.agent.memory import AgentAction, AgentMemory


class Product(BaseModel):
    name: str
    price: float


def test_memory_creation() -> None:
    memory = AgentMemory(goal="find products", schema=Product)
    assert memory.goal == "find products"
    assert memory.step_count == 0
    assert memory.visited_urls == []
    assert memory.extracted_data == []
    assert memory.action_history == []


def test_record_action() -> None:
    memory = AgentMemory(goal="test", schema=Product)
    action = AgentAction(tool="navigate", params={"url": "https://example.com"}, result="OK")
    memory.record_action(action)
    assert len(memory.action_history) == 1
    assert memory.step_count == 1


def test_record_visit() -> None:
    memory = AgentMemory(goal="test", schema=Product)
    memory.record_visit("https://example.com")
    assert "https://example.com" in memory.visited_urls


def test_record_extracted_data() -> None:
    memory = AgentMemory(goal="test", schema=Product)
    product = Product(name="Widget", price=9.99)
    memory.record_extraction(product)
    assert len(memory.extracted_data) == 1


def test_is_url_visited() -> None:
    memory = AgentMemory(goal="test", schema=Product)
    memory.record_visit("https://example.com")
    assert memory.is_visited("https://example.com") is True
    assert memory.is_visited("https://other.com") is False


def test_stuck_detection_url_visited_too_many_times() -> None:
    memory = AgentMemory(goal="test", schema=Product)
    for _ in range(3):
        memory.record_visit("https://example.com")
    assert memory.is_stuck() is True


def test_stuck_detection_repeated_actions() -> None:
    memory = AgentMemory(goal="test", schema=Product)
    action = AgentAction(tool="scroll", params={"direction": "down"}, result="OK")
    memory.record_action(action)
    memory.record_action(action)
    assert memory.is_stuck() is True


def test_stuck_detection_no_progress() -> None:
    memory = AgentMemory(goal="test", schema=Product)
    for i in range(5):
        memory.record_action(
            AgentAction(tool="navigate", params={"url": f"https://site{i}.com"}, result="OK")
        )
    assert memory.is_stuck() is True


def test_not_stuck_with_extractions() -> None:
    memory = AgentMemory(goal="test", schema=Product)
    for i in range(5):
        memory.record_action(
            AgentAction(tool="navigate", params={"url": f"https://site{i}.com"}, result="OK")
        )
        memory.record_extraction(Product(name=f"P{i}", price=float(i)))
    assert memory.is_stuck() is False


def test_truncate_old_actions() -> None:
    memory = AgentMemory(goal="test", schema=Product)
    for i in range(30):
        memory.record_action(
            AgentAction(tool="navigate", params={"url": f"https://site{i}.com"}, result="OK")
        )
    recent = memory.recent_actions(limit=10)
    assert len(recent) == 10
