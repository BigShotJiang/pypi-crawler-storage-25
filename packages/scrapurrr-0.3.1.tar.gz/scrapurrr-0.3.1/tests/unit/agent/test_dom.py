"""Tests for DOM simplification."""

from scrapurrr.agent.dom import simplify_dom


def test_extracts_links() -> None:
    html = '<html><body><a href="/products">Products</a><a href="/about">About</a></body></html>'
    result = simplify_dom(html)
    assert "Products" in result
    assert "/products" in result
    assert "About" in result


def test_extracts_buttons() -> None:
    html = "<html><body><button>Submit</button><button>Cancel</button></body></html>"
    result = simplify_dom(html)
    assert "Submit" in result
    assert "Cancel" in result


def test_extracts_inputs() -> None:
    html = '<html><body><input type="text" name="search" placeholder="Search..."></body></html>'
    result = simplify_dom(html)
    assert "search" in result
    assert "text" in result


def test_extracts_headings() -> None:
    html = "<html><body><h1>Welcome</h1><h2>Products</h2><p>Browse our catalog.</p></body></html>"
    result = simplify_dom(html)
    assert "Welcome" in result
    assert "Products" in result


def test_strips_scripts() -> None:
    html = "<html><body><script>alert(1)</script><p>Real content</p></body></html>"
    result = simplify_dom(html)
    assert "alert" not in result
    assert "Real content" in result


def test_respects_max_elements() -> None:
    # Create page with many elements
    items = "".join(f"<p>Item {i}</p>" for i in range(500))
    html = f"<html><body>{items}</body></html>"
    result = simplify_dom(html, max_elements=10)
    lines = [line for line in result.strip().split("\n") if line.strip()]
    assert len(lines) <= 10


def test_indexed_output() -> None:
    html = '<html><body><a href="/link1">Link 1</a><a href="/link2">Link 2</a></body></html>'
    result = simplify_dom(html)
    assert "[0]" in result
    assert "[1]" in result


def test_compact_history() -> None:
    from pydantic import BaseModel

    from scrapurrr.agent.memory import AgentAction, AgentMemory

    class Product(BaseModel):
        name: str

    memory = AgentMemory(goal="test", schema=Product)
    for i in range(15):
        memory.record_action(
            AgentAction(
                tool="navigate" if i % 3 == 0 else "scroll",
                params={"url": f"https://site{i}.com"} if i % 3 == 0 else {},
                result="OK",
            )
        )

    summary = memory.compact_history(keep_recent=5)
    assert "Visited" in summary or "Actions" in summary
    assert len(summary) < 500  # should be compact
