"""Tests for the agent ReAct loop."""

from __future__ import annotations

import json
import logging
from unittest.mock import AsyncMock

import pytest
from pydantic import BaseModel

from scrapurrr.agent.loop import AgentLoop
from scrapurrr.agent.tools import Tool, ToolRegistry
from scrapurrr.core.exceptions import AgentError, MaxStepsError, StuckError


class Product(BaseModel):
    name: str
    price: float


class NavParams(BaseModel):
    url: str


class ExtractParams(BaseModel):
    pass


@pytest.fixture
def mock_provider() -> AsyncMock:
    return AsyncMock()


@pytest.fixture
def registry() -> ToolRegistry:
    reg = ToolRegistry()

    async def navigate(params: NavParams) -> str:
        return f"Navigated to {params.url}"

    async def extract(params: ExtractParams) -> str:
        return json.dumps({"name": "Widget", "price": 9.99})

    reg.register(
        Tool(name="navigate", description="Go to URL", parameters=NavParams, execute=navigate)
    )
    reg.register(
        Tool(name="extract", description="Extract data", parameters=ExtractParams, execute=extract)
    )
    return reg


class TestAgentLoop:
    @pytest.mark.asyncio
    async def test_completes_in_two_steps(
        self, mock_provider: AsyncMock, registry: ToolRegistry
    ) -> None:
        mock_provider.complete = AsyncMock(
            side_effect=[
                json.dumps({"tool": "navigate", "params": {"url": "https://shop.com"}}),
                json.dumps({"tool": "extract", "params": {}}),
                json.dumps({"tool": "done", "params": {}}),
            ]
        )
        mock_provider.extract_structured = AsyncMock(
            return_value=Product(name="Widget", price=9.99)
        )

        loop = AgentLoop(provider=mock_provider, tools=registry, schema=Product, max_steps=10)
        result = await loop.run("find products on shop.com")
        assert isinstance(result, Product)
        assert result.name == "Widget"

    @pytest.mark.asyncio
    async def test_raises_max_steps(self, mock_provider: AsyncMock, registry: ToolRegistry) -> None:
        mock_provider.complete = AsyncMock(
            return_value=json.dumps({"tool": "navigate", "params": {"url": "https://example.com"}})
        )

        loop = AgentLoop(provider=mock_provider, tools=registry, schema=Product, max_steps=3)
        with pytest.raises(MaxStepsError):
            await loop.run("find products")

    @pytest.mark.asyncio
    async def test_raises_stuck_error(
        self, mock_provider: AsyncMock, registry: ToolRegistry
    ) -> None:
        call_count = 0

        async def always_same_navigate(*args: object, **kwargs: object) -> str:
            nonlocal call_count
            call_count += 1
            return json.dumps({"tool": "navigate", "params": {"url": "https://same.com"}})

        mock_provider.complete = AsyncMock(side_effect=always_same_navigate)

        loop = AgentLoop(provider=mock_provider, tools=registry, schema=Product, max_steps=20)
        with pytest.raises((StuckError, MaxStepsError)):
            await loop.run("find products")

    @pytest.mark.asyncio
    async def test_agent_timeout_raises_agent_error(
        self, mock_provider: AsyncMock, registry: ToolRegistry
    ) -> None:
        import asyncio

        async def slow_complete(*args: object, **kwargs: object) -> str:
            await asyncio.sleep(10)
            return json.dumps({"tool": "navigate", "params": {"url": "https://example.com"}})

        mock_provider.complete = AsyncMock(side_effect=slow_complete)

        loop = AgentLoop(provider=mock_provider, tools=registry, schema=Product, max_steps=10)
        with pytest.raises(AgentError, match="timed out"):
            await loop.run("find products", timeout=1)

    @pytest.mark.asyncio
    async def test_agent_logs_step_info(
        self, mock_provider: AsyncMock, registry: ToolRegistry, caplog: pytest.LogCaptureFixture
    ) -> None:
        mock_provider.complete = AsyncMock(
            side_effect=[
                json.dumps({"tool": "navigate", "params": {"url": "https://shop.com"}}),
                json.dumps({"tool": "extract", "params": {}}),
                json.dumps({"tool": "done", "params": {}}),
            ]
        )

        loop = AgentLoop(provider=mock_provider, tools=registry, schema=Product, max_steps=10)
        with caplog.at_level(logging.INFO, logger="scrapurrr.agent.loop"):
            await loop.run("find products on shop.com")
        step_logs = [r for r in caplog.records if "Agent step" in r.message]
        assert len(step_logs) >= 1

    @pytest.mark.asyncio
    async def test_agent_logs_parse_error(
        self, mock_provider: AsyncMock, registry: ToolRegistry, caplog: pytest.LogCaptureFixture
    ) -> None:
        mock_provider.complete = AsyncMock(
            side_effect=[
                "not valid json",
                json.dumps({"tool": "navigate", "params": {"url": "https://shop.com"}}),
                json.dumps({"tool": "extract", "params": {}}),
                json.dumps({"tool": "done", "params": {}}),
            ]
        )

        loop = AgentLoop(provider=mock_provider, tools=registry, schema=Product, max_steps=10)
        with caplog.at_level(logging.WARNING, logger="scrapurrr.agent.loop"):
            await loop.run("find products on shop.com")
        warn_logs = [r for r in caplog.records if "parse error" in r.message.lower()]
        assert len(warn_logs) >= 1
