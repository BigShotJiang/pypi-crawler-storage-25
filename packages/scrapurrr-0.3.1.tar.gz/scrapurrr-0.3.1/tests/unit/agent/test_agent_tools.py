"""Tests for agent tool registry."""

from __future__ import annotations

from unittest.mock import AsyncMock

import pytest
from pydantic import BaseModel

from scrapurrr.agent.tools import Tool, ToolRegistry


class NavParams(BaseModel):
    url: str


class ScrollParams(BaseModel):
    direction: str = "down"


def test_register_tool() -> None:
    registry = ToolRegistry()
    tool = Tool(name="navigate", description="Go to URL", parameters=NavParams, execute=AsyncMock())
    registry.register(tool)
    assert "navigate" in registry.tool_names()


def test_get_tool() -> None:
    registry = ToolRegistry()
    tool = Tool(name="navigate", description="Go to URL", parameters=NavParams, execute=AsyncMock())
    registry.register(tool)
    retrieved = registry.get("navigate")
    assert retrieved.name == "navigate"


def test_get_nonexistent_raises() -> None:
    registry = ToolRegistry()
    with pytest.raises(KeyError):
        registry.get("nonexistent")


def test_duplicate_registration_raises() -> None:
    registry = ToolRegistry()
    tool = Tool(name="navigate", description="Go to URL", parameters=NavParams, execute=AsyncMock())
    registry.register(tool)
    with pytest.raises(ValueError, match="already registered"):
        registry.register(tool)


def test_tool_descriptions_for_prompt() -> None:
    registry = ToolRegistry()
    registry.register(
        Tool(name="navigate", description="Go to URL", parameters=NavParams, execute=AsyncMock())
    )
    registry.register(
        Tool(
            name="scroll",
            description="Scroll the page",
            parameters=ScrollParams,
            execute=AsyncMock(),
        )
    )
    desc = registry.describe_tools()
    assert "navigate" in desc
    assert "scroll" in desc
    assert "Go to URL" in desc


@pytest.mark.asyncio
async def test_execute_tool() -> None:
    mock_fn = AsyncMock(return_value="page loaded")
    registry = ToolRegistry()
    registry.register(
        Tool(name="navigate", description="Go to URL", parameters=NavParams, execute=mock_fn)
    )
    result = await registry.execute("navigate", {"url": "https://example.com"})
    assert result == "page loaded"
    mock_fn.assert_called_once()
