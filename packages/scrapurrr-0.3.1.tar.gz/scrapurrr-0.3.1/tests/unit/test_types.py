"""Tests for scrapurrr shared types."""

from dataclasses import FrozenInstanceError

import pytest

from scrapurrr.core.types import ChunkResult, CleanResult, FetchResult, PageMetadata


def test_fetch_result_is_frozen() -> None:
    result = FetchResult(url="https://example.com", html="<h1>Hi</h1>", status=200, headers={})
    with pytest.raises(FrozenInstanceError):
        result.url = "other"  # type: ignore[misc]


def test_fetch_result_fields() -> None:
    result = FetchResult(
        url="https://example.com",
        html="<h1>Hi</h1>",
        status=200,
        headers={"content-type": "text/html"},
    )
    assert result.url == "https://example.com"
    assert result.html == "<h1>Hi</h1>"
    assert result.status == 200
    assert result.headers == {"content-type": "text/html"}


def test_clean_result_is_frozen() -> None:
    meta = PageMetadata(title="Test", language=None)
    result = CleanResult(html="<h1>Hi</h1>", markdown="# Hi", metadata=meta)
    with pytest.raises(FrozenInstanceError):
        result.html = "other"  # type: ignore[misc]


def test_chunk_result_is_frozen() -> None:
    result = ChunkResult(chunks=("chunk1", "chunk2"), source_url="https://example.com")
    with pytest.raises(FrozenInstanceError):
        result.source_url = "other"  # type: ignore[misc]


def test_chunk_result_uses_tuple() -> None:
    result = ChunkResult(chunks=("a", "b"), source_url="https://example.com")
    assert isinstance(result.chunks, tuple)
