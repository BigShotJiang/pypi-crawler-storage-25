"""Tests for the Scrapurrr public API facade."""

from __future__ import annotations

from dataclasses import replace
from textwrap import dedent
from typing import TYPE_CHECKING
from unittest.mock import AsyncMock, patch

import pytest
from pydantic import BaseModel

from scrapurrr import Scrapurrr
from scrapurrr.core.types import FetchResult

if TYPE_CHECKING:
    from pathlib import Path


class Product(BaseModel):
    name: str
    price: float


class TestScrapurrInit:
    def test_init_with_provider_string(self) -> None:
        scraper = Scrapurrr(provider="ollama/llama3")
        assert scraper._config.llm.provider == "ollama/llama3"

    def test_init_with_api_key(self) -> None:
        scraper = Scrapurrr(provider="openai/gpt-4o", api_key="sk-test")
        assert scraper._config.llm.api_key == "sk-test"

    def test_init_from_yaml(self, tmp_path: Path) -> None:
        yaml_file = tmp_path / "scrapurrr.yaml"
        yaml_file.write_text(
            dedent("""\
            llm:
              provider: anthropic/claude-3.5-sonnet
              api_key: sk-ant-test
        """)
        )
        scraper = Scrapurrr(config_path=yaml_file)
        assert scraper._config.llm.provider == "anthropic/claude-3.5-sonnet"

    def test_init_defaults_to_ollama(self) -> None:
        scraper = Scrapurrr()
        assert scraper._config.llm.provider == "ollama/llama3"


_RICH_HTML = (
    "<html><body>"
    '<h1 class="title">Widget Pro 3000</h1>'
    '<p class="description">A high-quality widget for all your widget needs. '
    "Comes with a 1-year warranty and free shipping on orders over $50.</p>"
    '<span class="price">$9.99</span>'
    "</body></html>"
)
_RICH_FETCH_RESULT = FetchResult(url="https://shop.com", html=_RICH_HTML, status=200, headers={})


class TestScrapurrExtract:
    @pytest.mark.asyncio
    async def test_extract_returns_typed_result(self) -> None:
        scraper = Scrapurrr(provider="ollama/llama3")
        # Force browser mode so _get_page mock is the only fetch path exercised
        scraper._config = replace(
            scraper._config, browser=replace(scraper._config.browser, mode="always")
        )

        mock_page = AsyncMock()
        mock_page.navigate_with_response = AsyncMock(return_value=(200, {}))
        mock_page.get_html = AsyncMock(return_value=_RICH_HTML)

        with (
            patch.object(scraper, "_get_page", return_value=mock_page),
            patch.object(scraper, "_ensure_launched", new_callable=AsyncMock),
        ):

            class SimpleProduct(BaseModel):
                title: str
                price: str

            result = await scraper.extract("https://shop.com", schema=SimpleProduct)
            assert isinstance(result, SimpleProduct)
            assert "Widget" in result.title

    @pytest.mark.asyncio
    async def test_extract_auto_uses_http_first(self) -> None:
        scraper = Scrapurrr(provider="ollama/llama3")
        # default mode is "auto" — http_fetch should be called and _get_page should NOT be called

        class SimpleProduct(BaseModel):
            title: str
            price: str

        mock_extracted = SimpleProduct(title="Widget", price="$9.99")

        with (
            patch(
                "scrapurrr.pipeline.robots.is_allowed", new_callable=AsyncMock, return_value=True
            ),
            patch(
                "scrapurrr.http_fetch", new_callable=AsyncMock, return_value=_RICH_FETCH_RESULT
            ) as mock_http,
            patch.object(scraper, "_get_page") as mock_get_page,
            patch.object(
                scraper._extractor,
                "extract",
                new_callable=AsyncMock,
                return_value=mock_extracted,
            ),
        ):
            result = await scraper.extract("https://shop.com", schema=SimpleProduct)
            mock_http.assert_called_once()
            mock_get_page.assert_not_called()
            assert isinstance(result, SimpleProduct)


class TestScrapurrExtractMany:
    @pytest.mark.asyncio
    async def test_extract_many_returns_list(self) -> None:
        scraper = Scrapurrr(provider="ollama/llama3")

        class SimpleProduct(BaseModel):
            title: str
            price: str

        mock_extracted = SimpleProduct(title="Widget", price="$9.99")

        with (
            patch(
                "scrapurrr.pipeline.robots.is_allowed", new_callable=AsyncMock, return_value=True
            ),
            patch.object(
                scraper, "_do_fetch", new_callable=AsyncMock, return_value=_RICH_FETCH_RESULT
            ),
            patch.object(
                scraper._extractor,
                "extract",
                new_callable=AsyncMock,
                return_value=mock_extracted,
            ),
        ):
            results = await scraper.extract_many(
                ["https://shop.com/1", "https://shop.com/2"],
                schema=SimpleProduct,
                concurrency=2,
            )
            assert len(results) == 2
            assert all(isinstance(r, SimpleProduct) for r in results)

    @pytest.mark.asyncio
    async def test_extract_many_skips_failures(self) -> None:
        scraper = Scrapurrr(provider="ollama/llama3")

        class SimpleProduct(BaseModel):
            title: str
            price: str

        call_count = 0

        async def _extract_side_effect(url: str, schema: type) -> SimpleProduct:
            nonlocal call_count
            call_count += 1
            if call_count == 1:
                raise Exception("fetch failed")
            return SimpleProduct(title="Widget", price="$9.99")

        with patch.object(scraper, "extract", side_effect=_extract_side_effect):
            results = await scraper.extract_many(
                ["https://shop.com/1", "https://shop.com/2"],
                schema=SimpleProduct,
                concurrency=2,
            )
            assert len(results) == 1
            assert results[0].title == "Widget"

    @pytest.mark.asyncio
    async def test_extract_many_empty_urls(self) -> None:
        scraper = Scrapurrr(provider="ollama/llama3")

        class SimpleProduct(BaseModel):
            title: str

        results = await scraper.extract_many([], schema=SimpleProduct)
        assert results == []


class TestScrapurrContextManager:
    @pytest.mark.asyncio
    async def test_context_manager_cleanup(self) -> None:
        scraper = Scrapurrr(provider="ollama/llama3")
        scraper._engine = AsyncMock()
        scraper._launched = True

        async with scraper:
            pass

        scraper._engine.close.assert_called_once()


class TestNeedsBrowser:
    def test_detects_spa_root_div(self) -> None:
        from scrapurrr import _needs_browser

        js_html = '<html><body><div id="root"></div><script src="app.js"></script></body></html>'
        assert _needs_browser(js_html) is True

    def test_static_content_does_not_need_browser(self) -> None:
        from scrapurrr import _needs_browser

        static_html = (
            "<html><body><h1>Hello World</h1>"
            "<p>This is static content with enough text to pass the threshold "
            "so the browser fallback should not trigger.</p></body></html>"
        )
        assert _needs_browser(static_html) is False

    def test_detects_next_js_marker(self) -> None:
        from scrapurrr import _needs_browser

        nextjs_html = '<html><body><div id="__next"></div></body></html>'
        assert _needs_browser(nextjs_html) is True

    def test_detects_nuxt_marker(self) -> None:
        from scrapurrr import _needs_browser

        nuxt_html = "<html><body><script>window.__NUXT__ = {}</script></body></html>"
        assert _needs_browser(nuxt_html) is True

    def test_sparse_body_text_triggers_browser(self) -> None:
        from scrapurrr import _needs_browser

        sparse_html = "<html><body><p>Hi</p></body></html>"
        assert _needs_browser(sparse_html) is True
