"""Tests for clean_fit function."""

from __future__ import annotations

from scrapurrr.pipeline.cleaner import clean_fit


class TestCleanFit:
    def test_removes_scripts_and_nav(self) -> None:
        html = (
            "<html><body>"
            "<script>alert(1)</script>"
            "<nav>Menu items here</nav>"
            "<p>This is the real main content of the article"
            " with enough words.</p>"
            "</body></html>"
        )
        result = clean_fit(html)
        assert "alert" not in result.markdown
        assert "Menu" not in result.markdown

    def test_applies_pruning(self) -> None:
        html = (
            "<html><body>"
            "<p>Skip to main content</p>"
            "<p>This is a meaningful article with plenty of"
            " words to pass the threshold for filtering"
            " content blocks.</p>"
            "<p>Copyright all rights reserved</p>"
            "</body></html>"
        )
        result = clean_fit(html)
        assert "skip to" not in result.markdown.lower()

    def test_applies_bm25_when_query_provided(self) -> None:
        html = (
            "<html><body>"
            "<p>Python is a programming language used for"
            " web development and data science.</p>"
            "\n\n"
            "<p>The weather today is sunny with a high of"
            " 72 degrees and low humidity expected.</p>"
            "\n\n"
            "<p>Python frameworks like Django and Flask make"
            " web development easier for developers.</p>"
            "</body></html>"
        )
        result = clean_fit(html, query="Python programming")
        assert "Python" in result.markdown

    def test_no_query_returns_pruned_content(self) -> None:
        html = (
            "<html><body>"
            "<p>A substantial paragraph with more than enough"
            " words to pass through the pruning filter.</p>"
            "</body></html>"
        )
        result = clean_fit(html)
        assert "substantial" in result.markdown

    def test_preserves_metadata(self) -> None:
        html = (
            "<html><head><title>Test Page</title></head>"
            "<body><p>Content with enough words for"
            " filtering.</p></body></html>"
        )
        result = clean_fit(html)
        assert result.metadata.title == "Test Page"
