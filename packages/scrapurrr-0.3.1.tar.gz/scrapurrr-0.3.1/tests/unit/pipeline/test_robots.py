"""Tests for robots.txt compliance."""

from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from scrapurrr.pipeline.robots import clear_cache, is_allowed


@pytest.fixture(autouse=True)
def clear_robots_cache() -> None:
    clear_cache()


@pytest.mark.asyncio
async def test_allowed_url() -> None:
    mock_response = MagicMock()
    mock_response.text = "User-agent: *\nAllow: /"
    mock_response.status_code = 200

    with patch("scrapurrr.pipeline.robots.httpx.AsyncClient") as mock_cls:
        mock_client = AsyncMock()
        mock_client.get = AsyncMock(return_value=mock_response)
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=False)
        mock_cls.return_value = mock_client

        assert await is_allowed("https://example.com/page") is True


@pytest.mark.asyncio
async def test_disallowed_url() -> None:
    mock_response = MagicMock()
    mock_response.text = "User-agent: *\nDisallow: /private"
    mock_response.status_code = 200

    with patch("scrapurrr.pipeline.robots.httpx.AsyncClient") as mock_cls:
        mock_client = AsyncMock()
        mock_client.get = AsyncMock(return_value=mock_response)
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=False)
        mock_cls.return_value = mock_client

        assert await is_allowed("https://example.com/private/data") is False


@pytest.mark.asyncio
async def test_robots_fetch_failure_allows() -> None:
    with patch("scrapurrr.pipeline.robots.httpx.AsyncClient") as mock_cls:
        mock_client = AsyncMock()
        mock_client.get = AsyncMock(side_effect=Exception("timeout"))
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=False)
        mock_cls.return_value = mock_client

        assert await is_allowed("https://example.com/page") is True
