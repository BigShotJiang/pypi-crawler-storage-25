"""Tests for chunk_smart function."""

from __future__ import annotations

from scrapurrr.pipeline.chunker import chunk_smart


class TestChunkSmart:
    def test_small_content_single_chunk(self) -> None:
        result = chunk_smart("Small text", max_tokens=1000)
        assert len(result.chunks) == 1
        assert result.chunks[0] == "Small text"

    def test_splits_by_headings(self) -> None:
        content = "# Section 1\n\n" + "Word " * 500 + "\n\n# Section 2\n\n" + "Word " * 500
        result = chunk_smart(content, max_tokens=600)
        assert len(result.chunks) >= 2

    def test_overlap_between_chunks(self) -> None:
        # Create content that will be split into multiple chunks
        section1 = "# Section 1\n\n" + "Alpha " * 400
        section2 = "# Section 2\n\n" + "Beta " * 400
        content = section1 + "\n\n" + section2
        result = chunk_smart(content, max_tokens=500, overlap=50)
        assert len(result.chunks) >= 2
        # With overlap, the second chunk should contain some content from the end of the first
        if len(result.chunks) >= 2:
            # Overlap means the beginning of chunk 2 should have trailing content from chunk 1
            assert len(result.chunks[1]) > 0

    def test_splits_large_sections_by_paragraphs(self) -> None:
        # Single heading with many paragraphs
        paragraphs = "\n\n".join(
            f"Paragraph {i} with enough words to be meaningful." for i in range(20)
        )
        content = f"# Big Section\n\n{paragraphs}"
        result = chunk_smart(content, max_tokens=100)
        assert len(result.chunks) >= 2

    def test_preserves_all_content(self) -> None:
        content = "# A\n\nFirst section content.\n\n# B\n\nSecond section content."
        result = chunk_smart(content, max_tokens=15)
        combined = " ".join(result.chunks)
        assert "First section" in combined
        assert "Second section" in combined

    def test_source_url_passed_through(self) -> None:
        result = chunk_smart("text", source_url="https://example.com")
        assert result.source_url == "https://example.com"

    def test_no_empty_chunks(self) -> None:
        content = "Word " * 500
        result = chunk_smart(content, max_tokens=50)
        assert all(c.strip() for c in result.chunks)
