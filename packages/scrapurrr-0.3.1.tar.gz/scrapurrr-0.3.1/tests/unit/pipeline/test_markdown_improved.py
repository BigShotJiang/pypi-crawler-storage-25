"""Tests for improved markdown conversion."""

from __future__ import annotations

from scrapurrr.pipeline.markdown import to_markdown, to_markdown_with_citations


class TestToMarkdownOptions:
    def test_include_links_true(self) -> None:
        html = '<a href="https://example.com">Click</a>'
        md = to_markdown(html, include_links=True)
        assert "https://example.com" in md
        assert "Click" in md

    def test_include_links_false(self) -> None:
        html = '<a href="https://example.com">Click</a>'
        md = to_markdown(html, include_links=False)
        assert "Click" in md
        assert "https://example.com" not in md

    def test_include_images_false(self) -> None:
        html = '<img src="photo.jpg" alt="Photo"><p>Text</p>'
        md = to_markdown(html, include_images=False)
        assert "photo.jpg" not in md
        assert "Text" in md

    def test_include_images_true(self) -> None:
        html = '<img src="photo.jpg" alt="Photo"><p>Text</p>'
        md = to_markdown(html, include_images=True)
        assert "photo" in md.lower()

    def test_include_tables_true(self) -> None:
        html = "<table><tr><th>Col</th></tr><tr><td>Val</td></tr></table>"
        md = to_markdown(html, include_tables=True)
        assert "Col" in md
        assert "Val" in md

    def test_include_tables_false(self) -> None:
        html = "<table><tr><th>Col</th></tr><tr><td>Val</td></tr></table><p>After</p>"
        md = to_markdown(html, include_tables=False)
        assert "After" in md

    def test_empty_html(self) -> None:
        assert to_markdown("") == ""


class TestToMarkdownWithCitations:
    def test_creates_footnotes(self) -> None:
        html = '<p>Visit <a href="https://example.com">Example</a> and <a href="https://other.com">Other</a>.</p>'
        md = to_markdown_with_citations(html)
        assert "[1]" in md
        assert "[2]" in md
        assert "https://example.com" in md
        assert "https://other.com" in md

    def test_deduplicates_same_url(self) -> None:
        html = (
            '<p><a href="https://example.com">First</a> and '
            '<a href="https://example.com">Second</a>.</p>'
        )
        md = to_markdown_with_citations(html)
        # Both should reference [1]
        assert md.count("[1]") >= 2
        # Should not have [2]
        assert "[2]" not in md

    def test_empty_html(self) -> None:
        assert to_markdown_with_citations("") == ""

    def test_no_links_no_footnotes(self) -> None:
        html = "<p>Plain text without links.</p>"
        md = to_markdown_with_citations(html)
        assert "---" not in md
        assert "Plain text" in md

    def test_footnote_section_separator(self) -> None:
        html = '<a href="https://example.com">Link</a>'
        md = to_markdown_with_citations(html)
        assert "---" in md
