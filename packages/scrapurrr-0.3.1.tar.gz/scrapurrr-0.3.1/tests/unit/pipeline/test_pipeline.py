"""Tests for the content pipeline stages."""

from pathlib import Path
from unittest.mock import AsyncMock

import pytest

from scrapurrr.core.exceptions import NavigationError
from scrapurrr.pipeline.chunker import chunk
from scrapurrr.pipeline.cleaner import clean
from scrapurrr.pipeline.fetcher import fetch
from scrapurrr.pipeline.markdown import to_markdown

FIXTURES = Path(__file__).parent.parent.parent / "fixtures" / "pages"


class TestCleaner:
    def test_removes_script_tags(self) -> None:
        html = "<html><body><script>alert(1)</script><p>Hello</p></body></html>"
        result = clean(html)
        assert "<script>" not in result.html
        assert "alert" not in result.html
        assert "Hello" in result.html

    def test_removes_style_tags(self) -> None:
        html = "<html><body><style>body{}</style><p>Hello</p></body></html>"
        result = clean(html)
        assert "<style>" not in result.html

    def test_removes_nav_and_footer(self) -> None:
        html = (
            "<html><body><nav>Menu</nav><main>"
            "<p>Content</p></main>"
            "<footer>Foot</footer></body></html>"
        )
        result = clean(html)
        assert "Menu" not in result.html
        assert "Foot" not in result.html
        assert "Content" in result.html

    def test_removes_cookie_banners(self) -> None:
        html = '<html><body><div class="cookie-banner">Cookies</div><p>Real</p></body></html>'
        result = clean(html)
        assert "Cookies" not in result.html
        assert "Real" in result.html

    def test_removes_elements_by_id(self) -> None:
        html = (
            '<html><body><div id="cookie-popup">'
            "Accept cookies</div>"
            "<p>Real content</p></body></html>"
        )
        result = clean(html)
        assert "Accept cookies" not in result.html
        assert "Real content" in result.html

    def test_preserves_main_content(self) -> None:
        html = FIXTURES.joinpath("simple_product.html").read_text()
        result = clean(html)
        assert "Amazing Widget" in result.html
        assert "best widget" in result.html
        assert "Weight" in result.html

    def test_extracts_title_metadata(self) -> None:
        html = "<html><head><title>My Page</title></head><body><p>Hi</p></body></html>"
        result = clean(html)
        assert result.metadata.title == "My Page"

    def test_produces_markdown(self) -> None:
        html = FIXTURES.joinpath("simple_product.html").read_text()
        result = clean(html)
        assert len(result.markdown) > 0
        assert "Amazing Widget" in result.markdown


class TestMarkdown:
    def test_converts_heading(self) -> None:
        html = "<h1>Title</h1><p>Body text here.</p>"
        md = to_markdown(html)
        assert "Title" in md
        assert "Body text here." in md

    def test_converts_table(self) -> None:
        html = "<table><tr><th>A</th><th>B</th></tr><tr><td>1</td><td>2</td></tr></table>"
        md = to_markdown(html)
        assert "A" in md
        assert "1" in md

    def test_preserves_links(self) -> None:
        html = '<a href="https://example.com">Click here</a>'
        md = to_markdown(html)
        assert "https://example.com" in md
        assert "Click here" in md

    def test_empty_html_returns_empty(self) -> None:
        assert to_markdown("") == ""


class TestChunker:
    def test_small_content_returns_single_chunk(self) -> None:
        result = chunk("Small text", max_tokens=1000)
        assert len(result.chunks) == 1
        assert result.chunks[0] == "Small text"

    def test_large_content_splits_by_headings(self) -> None:
        content = (
            "# Section 1\n\nContent one.\n\n"
            "# Section 2\n\nContent two.\n\n"
            "# Section 3\n\nContent three."
        )
        result = chunk(content, max_tokens=19)
        assert len(result.chunks) >= 2

    def test_preserves_all_content(self) -> None:
        content = "# A\n\nFirst.\n\n# B\n\nSecond."
        result = chunk(content, max_tokens=10)
        combined = " ".join(result.chunks)
        assert "First" in combined
        assert "Second" in combined

    def test_source_url_passed_through(self) -> None:
        result = chunk("text", max_tokens=1000, source_url="https://example.com")
        assert result.source_url == "https://example.com"


class TestChunkerFixed:
    def test_split_fixed_uses_char_based_estimation(self) -> None:
        # 100 chars = ~25 tokens. With max_tokens=10, should split.
        content = "a" * 100
        result = chunk(content, max_tokens=10)
        assert len(result.chunks) > 1

    def test_split_fixed_no_empty_chunks(self) -> None:
        content = "word " * 200
        result = chunk(content, max_tokens=50)
        assert all(c.strip() for c in result.chunks)


class TestFetcher:
    @pytest.mark.asyncio
    async def test_fetch_returns_status_and_headers(self) -> None:
        mock_page = AsyncMock()
        mock_page.navigate_with_response = AsyncMock(
            return_value=(200, {"content-type": "text/html"})
        )
        mock_page.get_html = AsyncMock(return_value="<html><body>Hi</body></html>")
        result = await fetch(mock_page, "https://example.com")
        assert result.status == 200
        assert result.headers == {"content-type": "text/html"}
        assert result.url == "https://example.com"

    @pytest.mark.asyncio
    async def test_fetch_navigation_error(self) -> None:
        mock_page = AsyncMock()
        mock_page.navigate_with_response = AsyncMock(side_effect=Exception("timeout"))
        with pytest.raises(NavigationError):
            await fetch(mock_page, "https://example.com", max_retries=1)

    @pytest.mark.asyncio
    async def test_fetch_retry_succeeds_on_second_attempt(self) -> None:
        mock_page = AsyncMock()
        mock_page.navigate_with_response = AsyncMock(
            side_effect=[Exception("transient"), (200, {"content-type": "text/html"})]
        )
        mock_page.get_html = AsyncMock(return_value="<html><body>Hi</body></html>")
        result = await fetch(mock_page, "https://example.com", max_retries=2)
        assert result.status == 200
        assert mock_page.navigate_with_response.call_count == 2

    @pytest.mark.asyncio
    async def test_fetch_retry_exhausted_raises_navigation_error(self) -> None:
        mock_page = AsyncMock()
        mock_page.navigate_with_response = AsyncMock(side_effect=Exception("always fails"))
        with pytest.raises(NavigationError, match="after 2 attempts"):
            await fetch(mock_page, "https://example.com", max_retries=2)
        assert mock_page.navigate_with_response.call_count == 2

    @pytest.mark.asyncio
    async def test_fetch_logs_warning_on_retry(self, caplog: pytest.LogCaptureFixture) -> None:
        import logging

        mock_page = AsyncMock()
        mock_page.navigate_with_response = AsyncMock(
            side_effect=[Exception("transient"), (200, {})]
        )
        mock_page.get_html = AsyncMock(return_value="<html></html>")
        with caplog.at_level(logging.WARNING, logger="scrapurrr.pipeline.fetcher"):
            await fetch(mock_page, "https://example.com", max_retries=2)
        assert any("Fetch failed" in r.message for r in caplog.records)

    @pytest.mark.asyncio
    async def test_fetch_non_200_status(self) -> None:
        mock_page = AsyncMock()
        mock_page.navigate_with_response = AsyncMock(return_value=(404, {}))
        mock_page.get_html = AsyncMock(return_value="<html>Not Found</html>")
        result = await fetch(mock_page, "https://example.com/missing")
        assert result.status == 404

    @pytest.mark.asyncio
    async def test_fetch_wraps_error_as_navigation_error(self) -> None:
        mock_page = AsyncMock()
        mock_page.navigate_with_response = AsyncMock(
            side_effect=TimeoutError("page load timed out")
        )
        with pytest.raises(NavigationError, match="timed out"):
            await fetch(mock_page, "https://slow-site.com", max_retries=1)
