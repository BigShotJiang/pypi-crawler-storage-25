"""Tests for table extraction."""

from scrapurrr.pipeline.tables import extract_tables, tables_to_markdown


def test_simple_table() -> None:
    html = (
        "<table><tr><th>Name</th><th>Price</th></tr><tr><td>Widget</td><td>$9.99</td></tr></table>"
    )
    tables = extract_tables(html)
    assert len(tables) == 1
    assert tables[0][0] == ["Name", "Price"]
    assert tables[0][1] == ["Widget", "$9.99"]


def test_colspan() -> None:
    html = '<table><tr><td colspan="2">Header</td></tr><tr><td>A</td><td>B</td></tr></table>'
    tables = extract_tables(html)
    assert len(tables) == 1
    assert tables[0][0] == ["Header", "Header"]


def test_tables_to_markdown() -> None:
    tables = [[["Name", "Price"], ["Widget", "$9.99"]]]
    md = tables_to_markdown(tables)
    assert "| Name | Price |" in md
    assert "| Widget | $9.99 |" in md
    assert "---" in md


def test_empty_table() -> None:
    html = "<table></table>"
    tables = extract_tables(html)
    assert tables == [] or tables == [[]]


def test_multiple_tables() -> None:
    html = "<table><tr><td>A</td></tr></table><table><tr><td>B</td></tr></table>"
    tables = extract_tables(html)
    assert len(tables) == 2
