"""Tests for HTTP-only fetcher."""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from scrapurrr.core.exceptions import NavigationError
from scrapurrr.pipeline.http_fetcher import http_fetch


@pytest.mark.asyncio
async def test_http_fetch_success() -> None:
    mock_response = MagicMock()
    mock_response.status_code = 200
    mock_response.text = "<html><body>Hello</body></html>"
    mock_response.url = "https://example.com"
    mock_response.headers = {"content-type": "text/html"}

    with patch("scrapurrr.pipeline.http_fetcher.httpx.AsyncClient") as mock_client_cls:
        mock_client = AsyncMock()
        mock_client.get = AsyncMock(return_value=mock_response)
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=False)
        mock_client_cls.return_value = mock_client

        result = await http_fetch("https://example.com")
        assert result.status == 200
        assert "Hello" in result.html


@pytest.mark.asyncio
async def test_http_fetch_failure_raises_navigation_error() -> None:
    with patch("scrapurrr.pipeline.http_fetcher.httpx.AsyncClient") as mock_client_cls:
        mock_client = AsyncMock()
        mock_client.get = AsyncMock(side_effect=Exception("Connection refused"))
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=False)
        mock_client_cls.return_value = mock_client

        with pytest.raises(NavigationError, match="Connection refused"):
            await http_fetch("https://example.com")


@pytest.mark.asyncio
async def test_http_fetch_custom_headers_merged() -> None:
    mock_response = MagicMock()
    mock_response.status_code = 200
    mock_response.text = "<html><body>OK</body></html>"
    mock_response.url = "https://example.com"
    mock_response.headers = {"content-type": "text/html"}

    with patch("scrapurrr.pipeline.http_fetcher.httpx.AsyncClient") as mock_client_cls:
        mock_client = AsyncMock()
        mock_client.get = AsyncMock(return_value=mock_response)
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=False)
        mock_client_cls.return_value = mock_client

        result = await http_fetch("https://example.com", headers={"X-Custom": "test"})
        assert result.status == 200
        _, kwargs = mock_client.get.call_args
        sent_headers = kwargs.get("headers", {})
        assert sent_headers.get("X-Custom") == "test"
        assert "User-Agent" in sent_headers
