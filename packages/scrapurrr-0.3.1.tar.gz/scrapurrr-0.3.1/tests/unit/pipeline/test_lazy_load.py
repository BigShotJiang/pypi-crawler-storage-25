"""Tests for lazy load handling."""

from unittest.mock import AsyncMock

import pytest

from scrapurrr.pipeline.lazy_load import load_all_lazy_content


@pytest.mark.asyncio
async def test_scrolls_until_no_new_content() -> None:
    page = AsyncMock()
    # Simulate increasing height then plateau
    page.evaluate = AsyncMock(
        side_effect=[
            1000,
            None,
            None,  # scroll 1: height, scroll, force-load
            2000,
            None,
            None,  # scroll 2: height increased
            2000,
            None,
            None,  # scroll 3: same height
            2000,
            None,
            None,  # scroll 4: same height (stop)
            None,  # scroll to top
        ]
    )

    await load_all_lazy_content(page, max_scrolls=10, scroll_delay=0.01)
    assert page.evaluate.call_count >= 4
