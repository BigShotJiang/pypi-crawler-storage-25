"""Tests for schema utilities."""

import pytest
from pydantic import BaseModel

from scrapurrr.core.schemas import SchemaHelper


class Product(BaseModel):
    name: str
    price: float
    url: str


class Review(BaseModel):
    author: str
    rating: int
    text: str


def test_json_schema_from_model() -> None:
    schema = SchemaHelper.to_json_schema(Product)
    assert schema["type"] == "object"
    assert "name" in schema["properties"]
    assert "price" in schema["properties"]
    assert "url" in schema["properties"]


def test_json_schema_from_list_type() -> None:
    schema = SchemaHelper.to_json_schema(list[Product])
    assert schema["type"] == "array"
    assert "items" in schema


def test_is_list_schema() -> None:
    assert SchemaHelper.is_list_type(list[Product]) is True
    assert SchemaHelper.is_list_type(Product) is False


def test_build_extraction_prompt_single() -> None:
    prompt = SchemaHelper.build_extraction_prompt(Product)
    assert "name" in prompt
    assert "price" in prompt
    assert "url" in prompt
    assert "JSON" in prompt


def test_build_extraction_prompt_list() -> None:
    prompt = SchemaHelper.build_extraction_prompt(list[Product])
    assert "array" in prompt.lower() or "list" in prompt.lower()


def test_validate_single() -> None:
    data = {"name": "Widget", "price": 9.99, "url": "https://example.com"}
    result = SchemaHelper.validate(data, Product)
    assert isinstance(result, Product)
    assert result.name == "Widget"


def test_validate_list() -> None:
    data = [
        {"name": "Widget", "price": 9.99, "url": "https://a.com"},
        {"name": "Gadget", "price": 19.99, "url": "https://b.com"},
    ]
    result = SchemaHelper.validate(data, list[Product])
    assert isinstance(result, list)
    assert len(result) == 2
    assert all(isinstance(p, Product) for p in result)


def test_validate_invalid_raises() -> None:
    data = {"name": "Widget", "price": "not-a-number", "url": "https://example.com"}
    with pytest.raises(ValueError):
        SchemaHelper.validate(data, Product)
