"""Tests for plugin system."""

from __future__ import annotations

import pytest

import scrapurrr.plugins as plugins_module
from scrapurrr.plugins import (
    get_plugin,
    list_plugins,
    load_plugins_from_entry_points,
    register_plugin,
)


@pytest.fixture(autouse=True)
def clear_registry():
    """Reset plugin registry between tests."""
    plugins_module._registry.clear()
    yield
    plugins_module._registry.clear()


class TestRegisterPlugin:
    def test_register_and_get(self):
        plugin = object()
        register_plugin("my_plugin", plugin)
        assert get_plugin("my_plugin") is plugin

    def test_register_overwrites(self):
        plugin_a = object()
        plugin_b = object()
        register_plugin("p", plugin_a)
        register_plugin("p", plugin_b)
        assert get_plugin("p") is plugin_b

    def test_get_nonexistent_returns_none(self):
        assert get_plugin("does_not_exist") is None


class TestListPlugins:
    def test_empty_initially(self):
        assert list_plugins() == []

    def test_lists_registered_plugins(self):
        register_plugin("alpha", 1)
        register_plugin("beta", 2)
        names = list_plugins()
        assert "alpha" in names
        assert "beta" in names

    def test_returns_copy(self):
        register_plugin("x", 1)
        names = list_plugins()
        names.append("injected")
        assert "injected" not in list_plugins()


class TestLoadPluginsFromEntryPoints:
    def test_no_error_when_no_plugins(self):
        """Should not raise even with no plugins registered via entry points."""
        load_plugins_from_entry_points("scrapurrr.test_nonexistent_group")
        assert list_plugins() == []

    def test_default_group_no_error(self):
        load_plugins_from_entry_points()
        # Just assert it doesn't raise — the group may or may not have entries

    def test_register_function_plugin(self):
        def my_transform(data):
            return data

        register_plugin("transformer", my_transform)
        assert get_plugin("transformer") is my_transform

    def test_register_class_plugin(self):
        class MyExtractor:
            pass

        register_plugin("extractor", MyExtractor)
        assert get_plugin("extractor") is MyExtractor
