"""Tests for ChatSession — conversation state and message routing."""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from scrapurrr.chat.session import ChatResponse, ChatSession


def _make_session() -> ChatSession:
    mock_scraper = MagicMock()
    mock_scraper._get_page = AsyncMock(return_value=AsyncMock())
    mock_scraper._release_page = AsyncMock()
    mock_scraper._ensure_launched = AsyncMock()
    mock_scraper.close = AsyncMock()
    mock_scraper._llm = MagicMock()
    mock_scraper._config = MagicMock()
    mock_scraper._config.agent.max_steps = 20
    return ChatSession(scraper=mock_scraper)


class TestChatSessionCreation:
    def test_creates_with_mock_scraper(self):
        session = _make_session()
        assert session is not None

    def test_history_starts_empty(self):
        session = _make_session()
        assert session.history == []

    def test_current_url_starts_none(self):
        session = _make_session()
        assert session._current_url is None


class TestChatResponseDataclass:
    def test_text_only(self):
        r = ChatResponse(text="hello")
        assert r.text == "hello"
        assert r.is_streaming is False

    def test_streaming_flag(self):
        r = ChatResponse(text="hi", is_streaming=True)
        assert r.is_streaming is True


class TestStartClose:
    @pytest.mark.asyncio
    async def test_start_calls_ensure_launched_and_get_page(self):
        session = _make_session()
        await session.start()
        session._scraper._ensure_launched.assert_awaited_once()
        session._scraper._get_page.assert_awaited_once()

    @pytest.mark.asyncio
    async def test_close_releases_page_and_closes_scraper(self):
        session = _make_session()
        await session.start()
        await session.close()
        session._scraper._release_page.assert_awaited_once()
        session._scraper.close.assert_awaited_once()


class TestHandleExit:
    @pytest.mark.asyncio
    async def test_exit_returns_none(self):
        session = _make_session()
        await session.start()
        result = await session.handle("exit")
        assert result is None

    @pytest.mark.asyncio
    async def test_quit_returns_none(self):
        session = _make_session()
        await session.start()
        result = await session.handle("quit")
        assert result is None


class TestHandleNavigate:
    @pytest.mark.asyncio
    async def test_navigate_calls_page_navigate(self):
        session = _make_session()
        await session.start()
        session._page.navigate = AsyncMock()
        await session.handle("go to https://example.com")
        session._page.navigate.assert_awaited_once_with("https://example.com")

    @pytest.mark.asyncio
    async def test_navigate_updates_current_url(self):
        session = _make_session()
        await session.start()
        session._page.navigate = AsyncMock()
        await session.handle("go to https://example.com")
        assert session._current_url == "https://example.com"

    @pytest.mark.asyncio
    async def test_navigate_returns_chat_response(self):
        session = _make_session()
        await session.start()
        session._page.navigate = AsyncMock()
        result = await session.handle("go to https://example.com")
        assert isinstance(result, ChatResponse)
        assert "https://example.com" in result.text

    @pytest.mark.asyncio
    async def test_navigate_adds_to_history(self):
        session = _make_session()
        await session.start()
        session._page.navigate = AsyncMock()
        await session.handle("go to https://example.com")
        assert len(session.history) >= 1
        user_msgs = [m for m in session.history if m["role"] == "user"]
        assert any("https://example.com" in m["content"] for m in user_msgs)


class TestHandleBack:
    @pytest.mark.asyncio
    async def test_back_calls_go_back(self):
        session = _make_session()
        await session.start()
        session._page.go_back = AsyncMock()
        result = await session.handle("back")
        session._page.go_back.assert_awaited_once()
        assert isinstance(result, ChatResponse)


class TestHandleScroll:
    @pytest.mark.asyncio
    async def test_scroll_down(self):
        session = _make_session()
        await session.start()
        session._page.scroll = AsyncMock()
        result = await session.handle("scroll down")
        session._page.scroll.assert_awaited_once_with("down")
        assert isinstance(result, ChatResponse)

    @pytest.mark.asyncio
    async def test_scroll_up(self):
        session = _make_session()
        await session.start()
        session._page.scroll = AsyncMock()
        result = await session.handle("scroll up")
        session._page.scroll.assert_awaited_once_with("up")
        assert isinstance(result, ChatResponse)


class TestHandleClick:
    @pytest.mark.asyncio
    async def test_click_calls_page_click(self):
        session = _make_session()
        await session.start()
        session._page.click = AsyncMock()
        result = await session.handle("click #submit")
        session._page.click.assert_awaited_once_with("#submit")
        assert isinstance(result, ChatResponse)


class TestHandleFind:
    @pytest.mark.asyncio
    async def test_find_returns_tuple(self):
        from scrapurrr.extraction.element import ElementCollection

        session = _make_session()
        await session.start()
        empty_collection = ElementCollection(elements=())
        with patch(
            "scrapurrr.chat.session.extract_elements",
            new=AsyncMock(return_value=empty_collection),
        ):
            result = await session.handle("find login")
        assert isinstance(result, tuple)
        chat_resp, collection = result
        assert isinstance(chat_resp, ChatResponse)

    @pytest.mark.asyncio
    async def test_get_elements_returns_tuple(self):
        from scrapurrr.extraction.element import ElementCollection

        session = _make_session()
        await session.start()
        empty_collection = ElementCollection(elements=())
        with patch(
            "scrapurrr.chat.session.extract_elements",
            new=AsyncMock(return_value=empty_collection),
        ):
            result = await session.handle("get elements")
        assert isinstance(result, tuple)

    @pytest.mark.asyncio
    async def test_get_selectors_returns_tuple_with_selector_type(self):
        from scrapurrr.extraction.element import ElementCollection

        session = _make_session()
        await session.start()
        empty_collection = ElementCollection(elements=())
        with patch(
            "scrapurrr.chat.session.extract_elements",
            new=AsyncMock(return_value=empty_collection),
        ):
            result = await session.handle("get css of all links")
        assert isinstance(result, tuple)
        chat_resp, payload = result
        assert isinstance(chat_resp, ChatResponse)
        # payload is (selector_type, collection)
        assert isinstance(payload, tuple)
        selector_type, collection = payload
        assert selector_type == "css"


class TestHandleLLMFallback:
    @pytest.mark.asyncio
    async def test_unrecognised_input_calls_llm(self):
        session = _make_session()
        await session.start()
        session._page.get_html = AsyncMock(return_value="<html><body>hello</body></html>")
        session._scraper._llm.complete = AsyncMock(return_value="LLM answer")
        result = await session.handle("what is this page about?")
        assert isinstance(result, ChatResponse)
        assert result.text == "LLM answer"

    @pytest.mark.asyncio
    async def test_llm_response_added_to_history(self):
        session = _make_session()
        await session.start()
        session._page.get_html = AsyncMock(return_value="<html><body>hello</body></html>")
        session._scraper._llm.complete = AsyncMock(return_value="LLM answer")
        await session.handle("what is this page about?")
        roles = [m["role"] for m in session.history]
        assert "user" in roles
        assert "assistant" in roles

    @pytest.mark.asyncio
    async def test_history_tracks_conversation(self):
        session = _make_session()
        await session.start()
        session._page.get_html = AsyncMock(return_value="<html><body>hello</body></html>")
        session._scraper._llm.complete = AsyncMock(return_value="First answer")
        await session.handle("question one")
        session._scraper._llm.complete = AsyncMock(return_value="Second answer")
        await session.handle("question two")
        contents = [m["content"] for m in session.history]
        assert "question one" in contents
        assert "First answer" in contents
        assert "question two" in contents
        assert "Second answer" in contents
