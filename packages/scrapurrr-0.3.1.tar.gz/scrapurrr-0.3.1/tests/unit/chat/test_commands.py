"""Tests for direct command parser."""

from scrapurrr.chat.commands import Command, parse_command


class TestExitQuit:
    def test_exit(self):
        assert parse_command("exit") == Command(action="exit", args={})

    def test_quit(self):
        assert parse_command("quit") == Command(action="exit", args={})

    def test_exit_uppercase(self):
        assert parse_command("EXIT") == Command(action="exit", args={})

    def test_quit_mixed_case(self):
        assert parse_command("Quit") == Command(action="exit", args={})


class TestBack:
    def test_back(self):
        assert parse_command("back") == Command(action="back", args={})

    def test_back_uppercase(self):
        assert parse_command("BACK") == Command(action="back", args={})


class TestGetElements:
    def test_get_elements(self):
        assert parse_command("get elements") == Command(action="get_elements", args={})

    def test_list_elements(self):
        assert parse_command("list elements") == Command(action="get_elements", args={})

    def test_get_elements_uppercase(self):
        assert parse_command("GET ELEMENTS") == Command(action="get_elements", args={})


class TestScroll:
    def test_scroll_up(self):
        assert parse_command("scroll up") == Command(action="scroll", args={"direction": "up"})

    def test_scroll_down(self):
        assert parse_command("scroll down") == Command(action="scroll", args={"direction": "down"})

    def test_scroll_up_uppercase(self):
        assert parse_command("SCROLL UP") == Command(action="scroll", args={"direction": "up"})


class TestNavigate:
    def test_go_to(self):
        assert parse_command("go to https://example.com") == Command(
            action="navigate", args={"url": "https://example.com"}
        )

    def test_open(self):
        assert parse_command("open https://example.com") == Command(
            action="navigate", args={"url": "https://example.com"}
        )

    def test_navigate(self):
        assert parse_command("navigate https://example.com") == Command(
            action="navigate", args={"url": "https://example.com"}
        )

    def test_url_case_preserved(self):
        url = "https://Example.COM/Path?Query=Value"
        assert parse_command(f"go to {url}") == Command(action="navigate", args={"url": url})

    def test_navigate_keyword_uppercase(self):
        assert parse_command("NAVIGATE https://example.com") == Command(
            action="navigate", args={"url": "https://example.com"}
        )


class TestFind:
    def test_find_quoted(self):
        assert parse_command('find "search text"') == Command(
            action="find", args={"text": "search text"}
        )

    def test_find_unquoted(self):
        assert parse_command("find some text") == Command(action="find", args={"text": "some text"})

    def test_find_single_word(self):
        assert parse_command("find button") == Command(action="find", args={"text": "button"})

    def test_find_uppercase_keyword(self):
        assert parse_command('FIND "some text"') == Command(
            action="find", args={"text": "some text"}
        )


class TestGetSelectors:
    def test_get_xpath_alias_links(self):
        assert parse_command("get xpath of all links") == Command(
            action="get_selectors", args={"selector_type": "xpath", "tag": "a"}
        )

    def test_get_xpath_alias_buttons(self):
        assert parse_command("get xpath of all buttons") == Command(
            action="get_selectors", args={"selector_type": "xpath", "tag": "button"}
        )

    def test_get_xpath_alias_images(self):
        assert parse_command("get xpath of all images") == Command(
            action="get_selectors", args={"selector_type": "xpath", "tag": "img"}
        )

    def test_get_xpath_alias_inputs(self):
        assert parse_command("get xpath of all inputs") == Command(
            action="get_selectors", args={"selector_type": "xpath", "tag": "input"}
        )

    def test_get_xpath_no_alias(self):
        assert parse_command("get xpath of all button") == Command(
            action="get_selectors", args={"selector_type": "xpath", "tag": "button"}
        )

    def test_get_css_alias_links(self):
        assert parse_command("get css of all links") == Command(
            action="get_selectors", args={"selector_type": "css", "tag": "a"}
        )

    def test_get_css_alias_paragraphs(self):
        assert parse_command("get css of all paragraphs") == Command(
            action="get_selectors", args={"selector_type": "css", "tag": "p"}
        )

    def test_get_xpath_uppercase(self):
        assert parse_command("GET XPATH OF ALL LINKS") == Command(
            action="get_selectors", args={"selector_type": "xpath", "tag": "a"}
        )

    def test_get_xpath_alias_link_singular(self):
        assert parse_command("get xpath of all link") == Command(
            action="get_selectors", args={"selector_type": "xpath", "tag": "a"}
        )

    def test_get_xpath_alias_selects(self):
        assert parse_command("get xpath of all selects") == Command(
            action="get_selectors", args={"selector_type": "xpath", "tag": "select"}
        )

    def test_get_xpath_alias_forms(self):
        assert parse_command("get css of all forms") == Command(
            action="get_selectors", args={"selector_type": "css", "tag": "form"}
        )


class TestClick:
    def test_click_selector(self):
        assert parse_command("click #submit-btn") == Command(
            action="click", args={"selector": "#submit-btn"}
        )

    def test_click_preserves_case(self):
        assert parse_command("click .MyButton") == Command(
            action="click", args={"selector": ".MyButton"}
        )

    def test_click_xpath(self):
        assert parse_command("click //div[@class='Header']") == Command(
            action="click", args={"selector": "//div[@class='Header']"}
        )

    def test_click_keyword_uppercase(self):
        assert parse_command("CLICK #btn") == Command(action="click", args={"selector": "#btn"})


class TestNoMatch:
    def test_no_match_returns_none(self):
        assert parse_command("tell me about the products") is None

    def test_empty_string_returns_none(self):
        assert parse_command("") is None

    def test_random_text_returns_none(self):
        assert parse_command("what is the weather today?") is None

    def test_partial_match_returns_none(self):
        assert parse_command("scrolling down the page") is None
