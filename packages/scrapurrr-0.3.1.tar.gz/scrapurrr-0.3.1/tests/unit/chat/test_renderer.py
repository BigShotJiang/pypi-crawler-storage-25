"""Unit tests for ChatRenderer."""

import pytest

from scrapurrr.chat.renderer import ChatRenderer
from scrapurrr.extraction.element import ElementCollection, ElementInfo


def _make_element(index: int, tag: str, text: str, css: str, xpath: str) -> ElementInfo:
    return ElementInfo(
        index=index,
        tag=tag,
        text=text,
        css=css,
        xpath=xpath,
        full_xpath=f"/html/body/{tag}[1]",
        js_path=f'document.querySelector("{css}")',
        outer_html=f"<{tag}>{text}</{tag}>",
        styles={},
        attributes={},
        rect={"x": 0.0, "y": 0.0, "width": 100.0, "height": 30.0},
    )


@pytest.fixture()
def collection() -> ElementCollection:
    return ElementCollection(
        elements=(
            _make_element(0, "button", "Buy Now", "button#buy", "//button[@id='buy']"),
            _make_element(1, "a", "Home", "a.nav-link", "//a[@class='nav-link']"),
        )
    )


def test_chat_renderer_creates_without_error() -> None:
    renderer = ChatRenderer()
    assert renderer is not None


def test_format_elements_contains_tag_text_css_xpath(collection: ElementCollection) -> None:
    renderer = ChatRenderer()
    output = renderer.format_elements(collection)

    assert "button" in output
    assert '"Buy Now"' in output
    assert "button#buy" in output
    assert "//button[@id='buy']" in output

    assert "a" in output
    assert '"Home"' in output
    assert "a.nav-link" in output
    assert "//a[@class='nav-link']" in output


def test_format_xpaths_contains_xpath_and_text(collection: ElementCollection) -> None:
    renderer = ChatRenderer()
    output = renderer.format_xpaths(collection)

    assert "//button[@id='buy']" in output
    assert '"Buy Now"' in output

    assert "//a[@class='nav-link']" in output
    assert '"Home"' in output


def test_format_css_selectors_contains_css_and_text(collection: ElementCollection) -> None:
    renderer = ChatRenderer()
    output = renderer.format_css_selectors(collection)

    assert "button#buy" in output
    assert '"Buy Now"' in output

    assert "a.nav-link" in output
    assert '"Home"' in output
