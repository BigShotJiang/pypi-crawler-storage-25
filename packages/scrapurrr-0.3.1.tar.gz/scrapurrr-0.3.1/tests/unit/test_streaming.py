"""Tests for LLM streaming responses."""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock

import pytest

from scrapurrr.providers.litellm import LiteLLMProvider


@pytest.mark.asyncio
async def test_stream_complete_yields_tokens() -> None:
    provider = LiteLLMProvider(model="ollama/llama3")

    chunk1 = MagicMock()
    chunk1.choices = [MagicMock()]
    chunk1.choices[0].delta.content = "Hello"

    chunk2 = MagicMock()
    chunk2.choices = [MagicMock()]
    chunk2.choices[0].delta.content = " world"

    chunk3 = MagicMock()
    chunk3.choices = [MagicMock()]
    chunk3.choices[0].delta.content = None

    async def mock_stream():
        for c in [chunk1, chunk2, chunk3]:
            yield c

    with pytest.MonkeyPatch.context() as mp:
        mp.setattr(
            "scrapurrr.providers.litellm.acompletion",
            AsyncMock(return_value=mock_stream()),
        )
        tokens = []
        async for token in provider.stream_complete("test prompt"):
            tokens.append(token)

    assert tokens == ["Hello", " world"]


@pytest.mark.asyncio
async def test_stream_complete_with_system_prompt() -> None:
    provider = LiteLLMProvider(model="ollama/llama3")

    async def mock_stream():
        chunk = MagicMock()
        chunk.choices = [MagicMock()]
        chunk.choices[0].delta.content = "response"
        yield chunk

    mock_fn = AsyncMock(return_value=mock_stream())
    with pytest.MonkeyPatch.context() as mp:
        mp.setattr("scrapurrr.providers.litellm.acompletion", mock_fn)
        tokens = []
        async for token in provider.stream_complete("test", system_prompt="be helpful"):
            tokens.append(token)

    assert tokens == ["response"]
    call_kwargs = mock_fn.call_args[1]
    assert call_kwargs["stream"] is True
    assert len(call_kwargs["messages"]) == 2
    assert call_kwargs["messages"][0]["role"] == "system"


@pytest.mark.asyncio
async def test_stream_complete_empty_response() -> None:
    provider = LiteLLMProvider(model="ollama/llama3")

    async def mock_stream():
        return
        yield  # make it an async generator

    with pytest.MonkeyPatch.context() as mp:
        mp.setattr(
            "scrapurrr.providers.litellm.acompletion",
            AsyncMock(return_value=mock_stream()),
        )
        tokens = []
        async for token in provider.stream_complete("test"):
            tokens.append(token)

    assert tokens == []
