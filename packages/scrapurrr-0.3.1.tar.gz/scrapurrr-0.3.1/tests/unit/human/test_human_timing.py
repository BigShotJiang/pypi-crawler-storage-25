"""Tests for human timing distributions."""

from scrapurrr.human.timing import (
    click_delay,
    fitts_law_duration,
    inter_action_pause,
    reaction_time,
    reading_pause,
)


def test_fitts_law_increases_with_distance() -> None:
    short = fitts_law_duration(100, 50)
    long = fitts_law_duration(1000, 50)
    # On average, longer distance = longer time (sample multiple for statistical validity)
    short_avg = sum(fitts_law_duration(100, 50) for _ in range(100)) / 100
    long_avg = sum(fitts_law_duration(1000, 50) for _ in range(100)) / 100
    assert long_avg > short_avg
    # Suppress unused variable warnings
    _ = short, long


def test_reaction_time_range() -> None:
    times = [reaction_time() for _ in range(1000)]
    assert min(times) >= 0.12  # floor at 120ms
    assert 0.2 < sum(times) / len(times) < 0.4  # mean ~280ms


def test_click_delay_range() -> None:
    delays = [click_delay() for _ in range(1000)]
    assert min(delays) >= 0.15
    assert sum(delays) / len(delays) < 1.0


def test_reading_pause_scales_with_length() -> None:
    short_avg = sum(reading_pause(50) for _ in range(100)) / 100
    long_avg = sum(reading_pause(500) for _ in range(100)) / 100
    assert long_avg > short_avg


def test_inter_action_pause_has_floor() -> None:
    pauses = [inter_action_pause() for _ in range(200)]
    assert all(p >= 0.5 for p in pauses)
