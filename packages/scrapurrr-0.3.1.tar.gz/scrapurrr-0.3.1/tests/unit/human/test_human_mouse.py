"""Tests for human mouse movement simulation."""

from scrapurrr.human.mouse import Point, add_overshoot, bezier_mouse, wind_mouse


def test_wind_mouse_reaches_target() -> None:
    path = wind_mouse(0, 0, 500, 500)
    assert len(path) > 2
    assert path[-1].x == 500
    assert path[-1].y == 500


def test_wind_mouse_has_curved_path() -> None:
    path = wind_mouse(0, 0, 1000, 0)
    # Not all y values should be 0 (curved path)
    y_values = [p.y for p in path[1:-1]]
    assert any(y != 0 for y in y_values)


def test_bezier_mouse_reaches_target() -> None:
    path = bezier_mouse(0, 0, 300, 300)
    assert path[-1].x == 300
    assert path[-1].y == 300


def test_bezier_short_distance() -> None:
    path = bezier_mouse(0, 0, 2, 2)
    assert len(path) == 2


def test_overshoot_extends_path() -> None:
    path = [Point(0, 0), Point(100, 0), Point(200, 0)]
    # Force overshoot by setting probability to 1.0
    extended = add_overshoot(path, 200, 0, probability=1.0)
    assert len(extended) > len(path)


def test_wind_mouse_path_has_varying_velocity() -> None:
    path = wind_mouse(0, 0, 800, 400)
    distances = [
        ((path[i].x - path[i - 1].x) ** 2 + (path[i].y - path[i - 1].y) ** 2) ** 0.5
        for i in range(1, len(path))
    ]
    # Velocity should vary (not constant)
    assert max(distances) > min(distances) * 1.5
