"""Tests for smart JS rendering detection (_needs_browser)."""

from __future__ import annotations

from scrapurrr import _needs_browser


class TestNeedsBrowserSPAMarkers:
    def test_react_root_div(self) -> None:
        html = '<html><body><div id="root"></div></body></html>'
        assert _needs_browser(html) is True

    def test_vue_app_div(self) -> None:
        html = '<html><body><div id="app"></div></body></html>'
        assert _needs_browser(html) is True

    def test_next_js_div(self) -> None:
        html = '<html><body><div id="__next"></div></body></html>'
        assert _needs_browser(html) is True

    def test_nuxt_data(self) -> None:
        html = "<html><body><script>window.__NUXT__ = {}</script></body></html>"
        assert _needs_browser(html) is True

    def test_next_data(self) -> None:
        html = (
            '<html><body><script id="__NEXT_DATA__"'
            ' type="application/json">{}</script></body></html>'
        )
        assert _needs_browser(html) is True

    def test_gatsby_marker(self) -> None:
        html = "<html><body><script>window.__GATSBY = true</script></body></html>"
        assert _needs_browser(html) is True

    def test_angular_ng_app(self) -> None:
        html = '<html><body><div ng-app="myApp"></div></body></html>'
        assert _needs_browser(html) is True

    def test_react_data_reactroot(self) -> None:
        html = '<html><body><div data-reactroot=""></div></body></html>'
        assert _needs_browser(html) is True

    def test_spa_markers_are_case_insensitive(self) -> None:
        # Uppercase version of ng-app marker
        html = '<html><body><div NG-APP="myApp"></div></body></html>'
        assert _needs_browser(html) is True


class TestNeedsBrowserNoscript:
    def test_noscript_with_javascript_warning(self) -> None:
        html = (
            "<html><body>"
            "<noscript>You need to enable JavaScript to run this app.</noscript>"
            "<div id='app'></div>"
            "</body></html>"
        )
        assert _needs_browser(html) is True

    def test_noscript_without_javascript_keyword(self) -> None:
        # noscript without "javascript" — should not trigger this check alone
        # but may trigger the thin-body check
        html = (
            "<html><body>"
            "<noscript>Please enable scripting.</noscript>"
            "<p>" + "x" * 200 + "</p>"
            "</body></html>"
        )
        # "javascript" not present — noscript check won't fire; body has enough text
        assert _needs_browser(html) is False


class TestNeedsBrowserThinBody:
    def test_empty_body_needs_browser(self) -> None:
        html = "<html><body></body></html>"
        assert _needs_browser(html) is True

    def test_very_short_body_needs_browser(self) -> None:
        html = "<html><body><p>Loading...</p></body></html>"
        assert _needs_browser(html) is True

    def test_body_with_sufficient_text_does_not_need_browser(self) -> None:
        long_text = "This is a real article with lots of content. " * 5
        html = f"<html><body><article><p>{long_text}</p></article></body></html>"
        assert _needs_browser(html) is False

    def test_no_body_tag_with_rich_content(self) -> None:
        # No <body> tag at all — should not trigger thin body check
        long_text = "Content. " * 30
        html = f"<html>{long_text}</html>"
        assert _needs_browser(html) is False


class TestNeedsBrowserNegative:
    def test_normal_html_page(self) -> None:
        html = (
            "<html><body>"
            "<h1>Product Name</h1>"
            "<p>This is a detailed description of the product. "
            "It includes all the features and benefits.</p>"
            "<span class='price'>$29.99</span>"
            "</body></html>"
        )
        assert _needs_browser(html) is False

    def test_news_article_page(self) -> None:
        html = (
            "<html><body>"
            "<article>"
            "<h1>Breaking News</h1>"
            "<p>The quick brown fox jumped over the lazy dog. " * 5 + "</p>"
            "</article>"
            "</body></html>"
        )
        assert _needs_browser(html) is False
