"""Tests for browser fingerprint generation."""

from scrapurrr.browser.fingerprint import generate_fingerprint


def test_fingerprint_has_all_fields() -> None:
    fp = generate_fingerprint()
    assert fp.user_agent
    assert fp.platform
    assert fp.screen_width > 0
    assert fp.screen_height > 0
    assert fp.hardware_concurrency > 0
    assert fp.webgl_vendor
    assert fp.webgl_renderer


def test_fingerprint_is_internally_consistent() -> None:
    fp = generate_fingerprint()
    # Mac user agents should have MacIntel platform
    if "Macintosh" in fp.user_agent:
        assert fp.platform == "MacIntel"
    elif "Windows" in fp.user_agent:
        assert fp.platform == "Win32"
    elif "Linux" in fp.user_agent:
        assert "Linux" in fp.platform


def test_fingerprints_are_unique() -> None:
    fps = [generate_fingerprint() for _ in range(10)]
    seeds = [fp.canvas_noise_seed for fp in fps]
    assert len(set(seeds)) > 1  # should generate different seeds


def test_fingerprint_screen_reasonable() -> None:
    fp = generate_fingerprint()
    assert 1024 <= fp.screen_width <= 3840
    assert 768 <= fp.screen_height <= 2160
