"""Tests for PagePool concurrent browser page management."""

from __future__ import annotations

import asyncio
from unittest.mock import AsyncMock, MagicMock

import pytest

from scrapurrr.browser.pool import PagePool


class TestPagePoolAcquireRelease:
    @pytest.mark.asyncio
    async def test_acquire_creates_new_page(self) -> None:
        engine = MagicMock()
        page = MagicMock()
        engine.new_page = AsyncMock(return_value=page)

        pool = PagePool(engine, max_pages=3)
        acquired = await pool.acquire()

        assert acquired is page
        engine.new_page.assert_called_once()
        assert pool.size == 1

    @pytest.mark.asyncio
    async def test_release_makes_page_available(self) -> None:
        engine = MagicMock()
        page = MagicMock()
        engine.new_page = AsyncMock(return_value=page)

        pool = PagePool(engine, max_pages=3)
        acquired = await pool.acquire()
        await pool.release(acquired)

        assert pool.available == 1

    @pytest.mark.asyncio
    async def test_reuse_released_page(self) -> None:
        engine = MagicMock()
        page = MagicMock()
        engine.new_page = AsyncMock(return_value=page)

        pool = PagePool(engine, max_pages=3)
        p1 = await pool.acquire()
        await pool.release(p1)

        p2 = await pool.acquire()
        assert p2 is p1
        # Should not create a new page — reused from queue
        engine.new_page.assert_called_once()

    @pytest.mark.asyncio
    async def test_pool_respects_max_pages(self) -> None:
        engine = MagicMock()
        pages = [MagicMock() for _ in range(2)]
        call_count = 0

        async def new_page_side_effect():
            nonlocal call_count
            p = pages[call_count]
            call_count += 1
            return p

        engine.new_page = new_page_side_effect

        pool = PagePool(engine, max_pages=2)
        p1 = await pool.acquire()
        await pool.acquire()
        assert pool.size == 2

        # Release one so the next acquire can proceed
        await pool.release(p1)
        p3 = await pool.acquire()
        assert p3 is p1  # reused, not a new page
        assert pool.size == 2  # still 2, no new page created

    @pytest.mark.asyncio
    async def test_pool_waits_when_full(self) -> None:
        engine = MagicMock()
        page = MagicMock()
        engine.new_page = AsyncMock(return_value=page)

        pool = PagePool(engine, max_pages=1)
        p1 = await pool.acquire()

        # Schedule a delayed release
        async def release_soon():
            await asyncio.sleep(0.05)
            await pool.release(p1)

        asyncio.create_task(release_soon())

        # This should block until the release happens
        p2 = await pool.acquire()
        assert p2 is p1

    @pytest.mark.asyncio
    async def test_size_and_available_properties(self) -> None:
        engine = MagicMock()
        engine.new_page = AsyncMock(return_value=MagicMock())

        pool = PagePool(engine, max_pages=5)
        assert pool.size == 0
        assert pool.available == 0

        p = await pool.acquire()
        assert pool.size == 1
        assert pool.available == 0

        await pool.release(p)
        assert pool.size == 1
        assert pool.available == 1
