"""Tests for proxy rotation."""

from __future__ import annotations

import pytest

from scrapurrr.browser.proxy import ProxyRotator


def test_round_robin_rotation() -> None:
    rotator = ProxyRotator(["http://proxy1:8080", "http://proxy2:8080"])
    assert rotator.next() == "http://proxy1:8080"
    assert rotator.next() == "http://proxy2:8080"
    assert rotator.next() == "http://proxy1:8080"


def test_random_returns_valid_proxy() -> None:
    rotator = ProxyRotator(["http://proxy1:8080", "http://proxy2:8080"])
    assert rotator.random() in ["http://proxy1:8080", "http://proxy2:8080"]


def test_empty_proxies_raises() -> None:
    rotator = ProxyRotator([])
    with pytest.raises(ValueError):
        rotator.next()


def test_empty_proxies_random_raises() -> None:
    rotator = ProxyRotator([])
    with pytest.raises(ValueError):
        rotator.random()


def test_count() -> None:
    rotator = ProxyRotator(["a", "b", "c"])
    assert rotator.count == 3


def test_single_proxy_always_returned() -> None:
    rotator = ProxyRotator(["http://only:8080"])
    for _ in range(5):
        assert rotator.next() == "http://only:8080"
