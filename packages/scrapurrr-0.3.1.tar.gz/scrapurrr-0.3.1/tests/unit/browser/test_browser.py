"""Tests for browser engine and stealth."""

from __future__ import annotations

from unittest.mock import AsyncMock

import pytest

from scrapurrr.browser.engine import PlaywrightEngine, PlaywrightPage
from scrapurrr.browser.fingerprint import _PROFILES
from scrapurrr.browser.stealth import StealthManager

_ALL_USER_AGENTS = [p["ua"] for p in _PROFILES]


class TestStealthManager:
    def test_off_returns_empty_args(self) -> None:
        manager = StealthManager(level="off")
        args = manager.context_args()
        assert "user_agent" not in args

    def test_basic_sets_user_agent(self) -> None:
        manager = StealthManager(level="basic")
        args = manager.context_args()
        assert "user_agent" in args
        assert args["user_agent"] in _ALL_USER_AGENTS

    def test_basic_sets_viewport(self) -> None:
        manager = StealthManager(level="basic")
        args = manager.context_args()
        assert "viewport" in args
        assert "width" in args["viewport"]
        assert "height" in args["viewport"]

    def test_full_includes_basic(self) -> None:
        manager = StealthManager(level="full")
        args = manager.context_args()
        assert "user_agent" in args
        assert "viewport" in args

    @pytest.mark.asyncio
    async def test_apply_stealth_scripts_basic(self) -> None:
        # Scripts are injected via init scripts (add_init_script), not post-load evaluate.
        # apply_page_scripts is a no-op; get_init_scripts returns the full set.
        manager = StealthManager(level="basic")
        scripts = manager.get_init_scripts()
        assert len(scripts) >= 8

    @pytest.mark.asyncio
    async def test_no_scripts_when_off(self) -> None:
        manager = StealthManager(level="off")
        mock_page = AsyncMock()
        await manager.apply_page_scripts(mock_page)
        mock_page.evaluate.assert_not_called()

    @pytest.mark.asyncio
    async def test_hooks_called_on_navigate(self) -> None:
        hook = AsyncMock()
        hook.on_before_navigate = AsyncMock()
        hook.on_after_navigate = AsyncMock()
        manager = StealthManager(level="basic", hooks=[hook])

        mock_page = AsyncMock()
        await manager.run_before_navigate(mock_page, "https://example.com")
        hook.on_before_navigate.assert_called_once_with(mock_page, "https://example.com")

        await manager.run_after_navigate(mock_page, "https://example.com")
        hook.on_after_navigate.assert_called_once_with(mock_page, "https://example.com")


class TestPlaywrightEngine:
    @pytest.mark.asyncio
    async def test_contexts_tracked_and_closed(self) -> None:
        engine = PlaywrightEngine.__new__(PlaywrightEngine)
        engine._contexts = []
        engine._session_contexts = {}
        mock_context = AsyncMock()
        engine._contexts.append(mock_context)
        engine._browser = AsyncMock()
        engine._playwright = AsyncMock()

        await engine.close()

        mock_context.close.assert_called_once()
        assert engine._contexts == []


class TestPlaywrightPageInteraction:
    @pytest.mark.asyncio
    async def test_click(self) -> None:
        mock_page = AsyncMock()
        # query_selector returns None → falls back to page.click
        mock_page.query_selector.return_value = None
        stealth = StealthManager(level="off")
        pw_page = PlaywrightPage(mock_page, stealth)
        await pw_page.click("button.submit")
        mock_page.click.assert_called_once_with("button.submit")

    @pytest.mark.asyncio
    async def test_type_text(self) -> None:
        mock_page = AsyncMock()
        # query_selector returns None so click falls back to page.click
        mock_page.query_selector.return_value = None
        stealth = StealthManager(level="off")
        pw_page = PlaywrightPage(mock_page, stealth)
        await pw_page.type_text("input#search", "hello")
        # New implementation types char-by-char via keyboard.press
        mock_page.keyboard.press.assert_called()

    @pytest.mark.asyncio
    async def test_select_option(self) -> None:
        mock_page = AsyncMock()
        stealth = StealthManager(level="off")
        pw_page = PlaywrightPage(mock_page, stealth)
        await pw_page.select_option("select#color", "blue")
        mock_page.select_option.assert_called_once_with("select#color", "blue")

    @pytest.mark.asyncio
    async def test_go_back(self) -> None:
        mock_page = AsyncMock()
        stealth = StealthManager(level="off")
        pw_page = PlaywrightPage(mock_page, stealth)
        await pw_page.go_back()
        mock_page.go_back.assert_called_once()
