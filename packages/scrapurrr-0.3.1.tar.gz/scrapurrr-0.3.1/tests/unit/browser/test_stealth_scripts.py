"""Tests for stealth script generation."""

from scrapurrr.browser.fingerprint import generate_fingerprint
from scrapurrr.browser.stealth_scripts import generate_stealth_scripts


def test_generates_multiple_scripts() -> None:
    fp = generate_fingerprint()
    scripts = generate_stealth_scripts(fp)
    assert len(scripts) >= 8


def test_scripts_contain_fingerprint_values() -> None:
    fp = generate_fingerprint()
    scripts = generate_stealth_scripts(fp)
    combined = "\n".join(scripts)
    assert fp.platform in combined
    assert str(fp.hardware_concurrency) in combined
    assert "webdriver" in combined
    assert "canvas" in combined.lower() or "toDataURL" in combined


def test_webgl_vendor_in_scripts() -> None:
    fp = generate_fingerprint()
    scripts = generate_stealth_scripts(fp)
    combined = "\n".join(scripts)
    assert fp.webgl_vendor in combined
    assert fp.webgl_renderer in combined
