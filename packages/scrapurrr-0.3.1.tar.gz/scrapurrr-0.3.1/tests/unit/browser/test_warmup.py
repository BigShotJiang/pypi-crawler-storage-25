"""Tests for session warm-up."""

from __future__ import annotations

from unittest.mock import AsyncMock

import pytest

from scrapurrr.browser.warmup import warm_up_session


@pytest.mark.asyncio
async def test_warmup_visits_pages() -> None:
    page = AsyncMock()
    page.navigate = AsyncMock()
    page.scroll = AsyncMock()
    await warm_up_session(page, "example.com", steps=2)
    assert page.navigate.call_count >= 1


@pytest.mark.asyncio
async def test_warmup_handles_errors() -> None:
    page = AsyncMock()
    page.navigate = AsyncMock(side_effect=Exception("timeout"))
    page.scroll = AsyncMock()
    # Should not raise
    await warm_up_session(page, "example.com", steps=2)


@pytest.mark.asyncio
async def test_warmup_zero_steps() -> None:
    page = AsyncMock()
    page.navigate = AsyncMock()
    page.scroll = AsyncMock()
    await warm_up_session(page, "example.com", steps=0)
    # With 0 steps, nothing should be called
    page.navigate.assert_not_called()


@pytest.mark.asyncio
async def test_warmup_scroll_error_is_non_fatal() -> None:
    page = AsyncMock()
    page.navigate = AsyncMock()
    page.scroll = AsyncMock(side_effect=Exception("scroll failed"))
    # Should not raise even when scroll errors
    await warm_up_session(page, "example.com", steps=3)


@pytest.mark.asyncio
async def test_warmup_all_steps() -> None:
    page = AsyncMock()
    page.navigate = AsyncMock()
    page.scroll = AsyncMock()
    await warm_up_session(page, "target.example.com", steps=3)
    # At minimum 2 navigations: warm-up site + search
    assert page.navigate.call_count >= 2
