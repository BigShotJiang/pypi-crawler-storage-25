"""Tests for CLI interface."""

from click.testing import CliRunner

from scrapurrr.cli import main


def test_cli_help() -> None:
    runner = CliRunner()
    result = runner.invoke(main, ["--help"])
    assert result.exit_code == 0
    assert "Scrapurrr" in result.output


def test_extract_help() -> None:
    runner = CliRunner()
    result = runner.invoke(main, ["extract", "--help"])
    assert result.exit_code == 0
    assert "--schema" in result.output


def test_agent_help() -> None:
    runner = CliRunner()
    result = runner.invoke(main, ["agent", "--help"])
    assert result.exit_code == 0
    assert "--max-steps" in result.output


def test_batch_help() -> None:
    runner = CliRunner()
    result = runner.invoke(main, ["batch", "--help"])
    assert result.exit_code == 0
    assert "--schema" in result.output
    assert "--concurrency" in result.output


def test_extract_bad_schema_format() -> None:
    runner = CliRunner()
    result = runner.invoke(main, ["extract", "https://example.com", "--schema", "bad_format"])
    assert result.exit_code != 0
