"""Tests for BM25 content filtering."""

from scrapurrr.pipeline.content_filter import bm25_filter, prune_content


def test_bm25_filter_keeps_relevant() -> None:
    text = (
        "# Products\n\nWe sell amazing widgets and gadgets."
        "\n\n# About Us\n\nFounded in 2020."
        "\n\n# Contact\n\nEmail us at info@shop.com"
    )
    result = bm25_filter(text, "widgets gadgets products")
    assert "widgets" in result
    assert "gadgets" in result


def test_bm25_filter_empty_query_returns_all() -> None:
    text = "Some content here."
    result = bm25_filter(text, "")
    assert result == text


def test_prune_removes_short_blocks() -> None:
    text = (
        "Hi\n\nThis is a meaningful paragraph with enough"
        " words to pass the minimum threshold"
        " for filtering.\n\nOk"
    )
    result = prune_content(text, min_words=5)
    assert "meaningful" in result
    assert "Hi" not in result.split("\n\n")[0] or len(result.split("\n\n")) < 3


def test_prune_removes_nav_patterns() -> None:
    text = (
        "Skip to main content\n\n"
        "This is the actual article with real"
        " information and useful data.\n\n"
        "Copyright all rights reserved"
    )
    result = prune_content(text, min_words=3)
    assert "skip to" not in result.lower()
    assert "copyright" not in result.lower()
