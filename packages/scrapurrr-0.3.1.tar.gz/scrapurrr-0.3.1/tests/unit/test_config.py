"""Tests for scrapurrr configuration system."""

from pathlib import Path
from textwrap import dedent

import pytest

from scrapurrr.core.config import (
    LLMConfig,
    ScrapurrConfig,
)


def test_default_config() -> None:
    config = ScrapurrConfig()
    assert config.llm.provider == "ollama/llama3"
    assert config.llm.api_key is None
    assert config.browser.headless is True
    assert config.browser.stealth == "basic"
    assert config.browser.proxy is None
    assert config.browser.timeout == 30000
    assert config.extraction.strategy == "auto"
    assert config.agent.max_steps == 20
    assert config.agent.timeout == 300


def test_config_from_yaml(tmp_path: Path) -> None:
    yaml_file = tmp_path / "scrapurrr.yaml"
    yaml_file.write_text(
        dedent("""\
        llm:
          provider: openai/gpt-4o
          api_key: sk-test123
        browser:
          headless: false
          stealth: full
          timeout: 60000
        extraction:
          strategy: llm
        agent:
          max_steps: 50
          timeout: 600
    """)
    )
    config = ScrapurrConfig.from_yaml(yaml_file)
    assert config.llm.provider == "openai/gpt-4o"
    assert config.llm.api_key == "sk-test123"
    assert config.browser.headless is False
    assert config.browser.stealth == "full"
    assert config.browser.timeout == 60000
    assert config.extraction.strategy == "llm"
    assert config.agent.max_steps == 50
    assert config.agent.timeout == 600


def test_config_env_var_resolution(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("TEST_API_KEY", "sk-from-env")
    yaml_file = tmp_path / "scrapurrr.yaml"
    yaml_file.write_text(
        dedent("""\
        llm:
          provider: openai/gpt-4o
          api_key: env:TEST_API_KEY
    """)
    )
    config = ScrapurrConfig.from_yaml(yaml_file)
    assert config.llm.api_key == "sk-from-env"


def test_config_env_var_missing_raises(tmp_path: Path) -> None:
    yaml_file = tmp_path / "scrapurrr.yaml"
    yaml_file.write_text(
        dedent("""\
        llm:
          provider: openai/gpt-4o
          api_key: env:NONEXISTENT_KEY_12345
    """)
    )
    with pytest.raises(Exception, match="NONEXISTENT_KEY_12345"):
        ScrapurrConfig.from_yaml(yaml_file)


def test_config_override() -> None:
    base = ScrapurrConfig()
    overridden = base.override(
        provider="anthropic/claude-3.5-sonnet",
        api_key="sk-ant-test",
        headless=False,
    )
    assert overridden.llm.provider == "anthropic/claude-3.5-sonnet"
    assert overridden.llm.api_key == "sk-ant-test"
    assert overridden.browser.headless is False
    # Original unchanged
    assert base.llm.provider == "ollama/llama3"
    assert base.browser.headless is True


def test_config_is_immutable() -> None:
    config = ScrapurrConfig()
    with pytest.raises(AttributeError):
        config.llm = LLMConfig(provider="other")  # type: ignore[misc]
