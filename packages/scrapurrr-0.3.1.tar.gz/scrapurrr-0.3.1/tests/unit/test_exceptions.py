"""Tests for scrapurrr exception hierarchy."""

from scrapurrr.core.exceptions import (
    AgentError,
    AuthError,
    BrowserError,
    ConfigError,
    ExtractionError,
    MaxStepsError,
    NavigationError,
    NoContentError,
    ProviderError,
    RateLimitError,
    SchemaError,
    ScrapurrError,
    StuckError,
)


def test_base_exception_is_exception() -> None:
    assert issubclass(ScrapurrError, Exception)


def test_config_error_inherits_base() -> None:
    err = ConfigError("bad config")
    assert isinstance(err, ScrapurrError)
    assert str(err) == "bad config"


def test_browser_error_hierarchy() -> None:
    assert issubclass(NavigationError, BrowserError)
    assert issubclass(BrowserError, ScrapurrError)


def test_extraction_error_hierarchy() -> None:
    assert issubclass(SchemaError, ExtractionError)
    assert issubclass(NoContentError, ExtractionError)
    assert issubclass(ExtractionError, ScrapurrError)


def test_provider_error_hierarchy() -> None:
    assert issubclass(RateLimitError, ProviderError)
    assert issubclass(AuthError, ProviderError)
    assert issubclass(ProviderError, ScrapurrError)


def test_agent_error_hierarchy() -> None:
    assert issubclass(MaxStepsError, AgentError)
    assert issubclass(StuckError, AgentError)
    assert issubclass(AgentError, ScrapurrError)
