"""Tests for CSS-based extraction strategy."""

from pathlib import Path

import pytest
from pydantic import BaseModel, Field

from scrapurrr.extraction.css import CSSExtractor


class Product(BaseModel):
    title: str
    price: str
    description: str


class MinimalItem(BaseModel):
    title: str


FIXTURES = Path(__file__).parent.parent.parent / "fixtures" / "pages"


class TestCSSExtractor:
    @pytest.fixture
    def extractor(self) -> CSSExtractor:
        return CSSExtractor()

    @pytest.mark.asyncio
    async def test_can_handle_matching_page(self, extractor: CSSExtractor) -> None:
        html = FIXTURES.joinpath("simple_product.html").read_text()
        assert await extractor.can_handle(html, Product) is True

    @pytest.mark.asyncio
    async def test_can_handle_non_matching_page(self, extractor: CSSExtractor) -> None:
        html = "<html><body><p>Just a paragraph.</p></body></html>"
        assert await extractor.can_handle(html, Product) is False

    @pytest.mark.asyncio
    async def test_extract_product_fields(self, extractor: CSSExtractor) -> None:
        html = FIXTURES.joinpath("simple_product.html").read_text()
        result = await extractor.extract(html, Product)
        assert isinstance(result, Product)
        assert "Widget" in result.title
        assert "$29.99" in result.price or "29.99" in result.price

    @pytest.mark.asyncio
    async def test_extract_minimal_item(self, extractor: CSSExtractor) -> None:
        html = "<html><body><h1>My Title</h1></body></html>"
        result = await extractor.extract(html, MinimalItem)
        assert result.title == "My Title"

    @pytest.mark.asyncio
    async def test_can_handle_returns_false_for_empty(self, extractor: CSSExtractor) -> None:
        assert await extractor.can_handle("", Product) is False

    @pytest.mark.asyncio
    async def test_css_selector_hint(self, extractor: CSSExtractor) -> None:
        class ProductWithHints(BaseModel):
            sku: str = Field(json_schema_extra={"css_selector": "[data-sku]"})
            title: str

        html = '<html><body><h1>Widget</h1><span data-sku="ABC123">ABC123</span></body></html>'
        result = await extractor.extract(html, ProductWithHints)
        assert result.sku == "ABC123"
