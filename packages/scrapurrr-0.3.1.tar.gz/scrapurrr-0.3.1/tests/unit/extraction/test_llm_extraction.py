"""Tests for LLM-based extraction strategy."""

from __future__ import annotations

from unittest.mock import AsyncMock

import pytest
from pydantic import BaseModel

from scrapurrr.extraction.llm import LLMExtractor


class Product(BaseModel):
    name: str
    price: float


class TestLLMExtractor:
    @pytest.fixture
    def mock_provider(self) -> AsyncMock:
        provider = AsyncMock()
        provider.extract_structured = AsyncMock(return_value=Product(name="Widget", price=9.99))
        return provider

    @pytest.fixture
    def extractor(self, mock_provider: AsyncMock) -> LLMExtractor:
        return LLMExtractor(provider=mock_provider)

    @pytest.mark.asyncio
    async def test_can_handle_always_true(self, extractor: LLMExtractor) -> None:
        assert await extractor.can_handle("<p>any html</p>", Product) is True

    @pytest.mark.asyncio
    async def test_can_handle_false_for_empty(self, extractor: LLMExtractor) -> None:
        assert await extractor.can_handle("", Product) is False

    @pytest.mark.asyncio
    async def test_extract_delegates_to_provider(
        self, extractor: LLMExtractor, mock_provider: AsyncMock
    ) -> None:
        result = await extractor.extract("# Product\n\nWidget costs $9.99", Product)
        assert isinstance(result, Product)
        assert result.name == "Widget"
        mock_provider.extract_structured.assert_called_once()

    @pytest.mark.asyncio
    async def test_extract_passes_content_and_schema(
        self, extractor: LLMExtractor, mock_provider: AsyncMock
    ) -> None:
        await extractor.extract("markdown content here", Product)
        call_args = mock_provider.extract_structured.call_args
        content_value = call_args.kwargs.get("content") or (
            call_args.args[0] if call_args.args else ""
        )
        assert "markdown content here" in content_value
