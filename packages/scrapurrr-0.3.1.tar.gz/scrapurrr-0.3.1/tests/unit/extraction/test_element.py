"""Tests for ElementInfo and ElementCollection data models."""

import dataclasses

import pytest

from scrapurrr.extraction.element import ElementCollection, ElementInfo

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


def make_element(
    index: int = 0,
    tag: str = "div",
    text: str = "Hello",
    css: str = "#root > div",
    xpath: str = "/html/body/div",
    full_xpath: str = "/html/body/div",
    js_path: str = "document.querySelector('#root > div')",
    outer_html: str = "<div>Hello</div>",
    styles: dict | None = None,
    attributes: dict | None = None,
    rect: dict | None = None,
) -> ElementInfo:
    return ElementInfo(
        index=index,
        tag=tag,
        text=text,
        css=css,
        xpath=xpath,
        full_xpath=full_xpath,
        js_path=js_path,
        outer_html=outer_html,
        styles=styles or {"color": "red"},
        attributes=attributes or {"id": "root", "class": "container"},
        rect=rect or {"x": 0.0, "y": 0.0, "width": 100.0, "height": 50.0},
    )


# ---------------------------------------------------------------------------
# ElementInfo tests
# ---------------------------------------------------------------------------


class TestElementInfo:
    def test_creation_stores_all_fields(self):
        el = make_element(index=3, tag="span", text="World")
        assert el.index == 3
        assert el.tag == "span"
        assert el.text == "World"
        assert el.css == "#root > div"
        assert el.xpath == "/html/body/div"
        assert el.full_xpath == "/html/body/div"
        assert el.js_path == "document.querySelector('#root > div')"
        assert el.outer_html == "<div>Hello</div>"
        assert el.styles == {"color": "red"}
        assert el.attributes == {"id": "root", "class": "container"}
        assert el.rect == {"x": 0.0, "y": 0.0, "width": 100.0, "height": 50.0}

    def test_is_frozen_dataclass(self):
        el = make_element()
        assert dataclasses.is_dataclass(el)
        with pytest.raises(dataclasses.FrozenInstanceError):
            el.tag = "p"  # type: ignore[misc]

    def test_equality_by_value(self):
        el1 = make_element(index=1)
        el2 = make_element(index=1)
        assert el1 == el2

    def test_inequality_on_different_values(self):
        el1 = make_element(index=1)
        el2 = make_element(index=2)
        assert el1 != el2


# ---------------------------------------------------------------------------
# ElementCollection tests
# ---------------------------------------------------------------------------


class TestElementCollection:
    def _collection(self) -> ElementCollection:
        elements = (
            make_element(index=0, tag="div", text="Hello World", attributes={"id": "main"}),
            make_element(index=1, tag="span", text="Foo bar", attributes={"class": "highlight"}),
            make_element(
                index=2, tag="p", text="Another paragraph", attributes={"id": "para", "data-x": "1"}
            ),
            make_element(index=3, tag="DIV", text="Uppercase tag", attributes={}),
        )
        return ElementCollection(elements=elements)

    # --- basic protocol ---

    def test_len(self):
        col = self._collection()
        assert len(col) == 4

    def test_iter(self):
        col = self._collection()
        tags = [el.tag for el in col]
        assert tags == ["div", "span", "p", "DIV"]

    def test_getitem_by_position(self):
        col = self._collection()
        assert col[0].tag == "div"
        assert col[2].tag == "p"

    def test_getitem_out_of_range_raises(self):
        col = self._collection()
        with pytest.raises(IndexError):
            _ = col[99]

    def test_is_frozen_dataclass(self):
        col = self._collection()
        assert dataclasses.is_dataclass(col)
        with pytest.raises(dataclasses.FrozenInstanceError):
            col.elements = ()  # type: ignore[misc]

    # --- filter ---

    def test_filter_by_tag_case_insensitive(self):
        col = self._collection()
        result = col.filter(tag="div")
        assert len(result) == 2
        assert all(el.tag.lower() == "div" for el in result)

    def test_filter_by_text_substring_case_insensitive(self):
        col = self._collection()
        result = col.filter(text="hello")
        assert len(result) == 1
        assert result[0].text == "Hello World"

    def test_filter_by_attr_key_exists(self):
        col = self._collection()
        result = col.filter(attr="data-x")
        assert len(result) == 1
        assert result[0].index == 2

    def test_filter_multiple_conditions_anded(self):
        col = self._collection()
        # tag=div AND text contains "hello"
        result = col.filter(tag="div", text="hello")
        assert len(result) == 1
        assert result[0].index == 0

    def test_filter_returns_empty_collection_when_no_match(self):
        col = self._collection()
        result = col.filter(tag="h1")
        assert len(result) == 0
        assert isinstance(result, ElementCollection)

    def test_filter_no_args_returns_all(self):
        col = self._collection()
        result = col.filter()
        assert len(result) == 4

    def test_filter_returns_element_collection(self):
        col = self._collection()
        result = col.filter(tag="span")
        assert isinstance(result, ElementCollection)

    # --- first ---

    def test_first_returns_first_element(self):
        col = self._collection()
        assert col.first() is col[0]

    def test_first_on_empty_returns_none(self):
        col = ElementCollection(elements=())
        assert col.first() is None

    # --- by_index ---

    def test_by_index_finds_element(self):
        col = self._collection()
        el = col.by_index(2)
        assert el.index == 2
        assert el.tag == "p"

    def test_by_index_raises_index_error_when_missing(self):
        col = self._collection()
        with pytest.raises(IndexError):
            col.by_index(99)

    # --- to_list ---

    def test_to_list_returns_list_of_dicts(self):
        col = self._collection()
        result = col.to_list()
        assert isinstance(result, list)
        assert len(result) == 4
        assert all(isinstance(item, dict) for item in result)

    def test_to_list_dict_has_expected_keys(self):
        col = self._collection()
        item = col.to_list()[0]
        expected_keys = {
            "index",
            "tag",
            "text",
            "css",
            "xpath",
            "full_xpath",
            "js_path",
            "outer_html",
            "styles",
            "attributes",
            "rect",
        }
        assert set(item.keys()) == expected_keys
