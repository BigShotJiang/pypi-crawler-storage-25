"""Tests for vision extraction."""

from __future__ import annotations

from unittest.mock import AsyncMock

import pytest
from pydantic import BaseModel

from scrapurrr.extraction.vision import VisionExtractor


class Product(BaseModel):
    name: str
    price: float


@pytest.fixture
def mock_provider() -> AsyncMock:
    provider = AsyncMock()
    provider.supports_vision = True
    provider.extract_from_image = AsyncMock(return_value=Product(name="Widget", price=9.99))
    return provider


@pytest.fixture
def no_vision_provider() -> AsyncMock:
    provider = AsyncMock()
    provider.supports_vision = False
    return provider


@pytest.mark.asyncio
async def test_can_handle_with_vision_provider(mock_provider: AsyncMock) -> None:
    extractor = VisionExtractor(mock_provider)
    assert await extractor.can_handle("<html>test</html>", Product) is True


@pytest.mark.asyncio
async def test_cannot_handle_without_vision(no_vision_provider: AsyncMock) -> None:
    extractor = VisionExtractor(no_vision_provider)
    assert await extractor.can_handle("<html>test</html>", Product) is False


@pytest.mark.asyncio
async def test_extract_delegates_to_provider(mock_provider: AsyncMock) -> None:
    extractor = VisionExtractor(mock_provider)
    result = await extractor.extract(b"fake-image-bytes", Product)
    assert isinstance(result, Product)
    assert result.name == "Widget"
    mock_provider.extract_from_image.assert_called_once()


@pytest.mark.asyncio
async def test_extract_returns_correct_price(mock_provider: AsyncMock) -> None:
    extractor = VisionExtractor(mock_provider)
    result = await extractor.extract(b"image-data", Product)
    assert result.price == 9.99


@pytest.mark.asyncio
async def test_extract_passes_image_bytes_to_provider(mock_provider: AsyncMock) -> None:
    extractor = VisionExtractor(mock_provider)
    image_bytes = b"specific-image-bytes"
    await extractor.extract(image_bytes, Product)
    call_kwargs = mock_provider.extract_from_image.call_args
    assert call_kwargs.kwargs.get("image") == image_bytes or (
        call_kwargs.args and call_kwargs.args[0] == image_bytes
    )
