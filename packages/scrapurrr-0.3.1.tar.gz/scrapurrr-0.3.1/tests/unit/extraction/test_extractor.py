"""Tests for the extraction orchestrator (strategy picker)."""

from __future__ import annotations

from pathlib import Path
from unittest.mock import AsyncMock

import pytest
from pydantic import BaseModel

from scrapurrr.extraction import Extractor


class Product(BaseModel):
    title: str
    price: str
    description: str


class Unusual(BaseModel):
    foo: str
    bar: int


FIXTURES = Path(__file__).parent.parent.parent / "fixtures" / "pages"


class TestExtractor:
    @pytest.fixture
    def mock_provider(self) -> AsyncMock:
        provider = AsyncMock()
        provider.extract_structured = AsyncMock(return_value=Unusual(foo="hello", bar=42))
        return provider

    @pytest.mark.asyncio
    async def test_auto_uses_css_when_possible(self, mock_provider: AsyncMock) -> None:
        html = FIXTURES.joinpath("simple_product.html").read_text()
        extractor = Extractor(provider=mock_provider, strategy="auto")
        result = await extractor.extract(html, Product)
        assert isinstance(result, Product)
        mock_provider.extract_structured.assert_not_called()

    @pytest.mark.asyncio
    async def test_auto_falls_back_to_llm(self, mock_provider: AsyncMock) -> None:
        html = "<html><body><p>Some random content</p></body></html>"
        extractor = Extractor(provider=mock_provider, strategy="auto")
        result = await extractor.extract(html, Unusual)
        assert isinstance(result, Unusual)
        mock_provider.extract_structured.assert_called_once()

    @pytest.mark.asyncio
    async def test_css_strategy_only(self, mock_provider: AsyncMock) -> None:
        html = FIXTURES.joinpath("simple_product.html").read_text()
        extractor = Extractor(provider=mock_provider, strategy="css")
        result = await extractor.extract(html, Product)
        assert isinstance(result, Product)
        mock_provider.extract_structured.assert_not_called()

    @pytest.mark.asyncio
    async def test_llm_strategy_only(self, mock_provider: AsyncMock) -> None:
        html = "<html><body><p>Content</p></body></html>"
        extractor = Extractor(provider=mock_provider, strategy="llm")
        result = await extractor.extract(html, Unusual)
        assert isinstance(result, Unusual)
        mock_provider.extract_structured.assert_called_once()

    @pytest.mark.asyncio
    async def test_css_strategy_raises_on_no_match(self, mock_provider: AsyncMock) -> None:
        from scrapurrr.core.exceptions import ExtractionError

        html = "<html><body><p>Nothing here</p></body></html>"
        extractor = Extractor(provider=mock_provider, strategy="css")
        with pytest.raises(ExtractionError):
            await extractor.extract(html, Unusual)
