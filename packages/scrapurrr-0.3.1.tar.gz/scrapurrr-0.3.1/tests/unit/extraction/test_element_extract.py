"""Tests for ELEMENT_EXTRACTION_JS constant and extract_elements function."""

from unittest.mock import AsyncMock, MagicMock

import pytest

from scrapurrr.extraction.element import ElementCollection, ElementInfo, extract_elements

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def make_element_dict(
    index: int = 0,
    tag: str = "div",
    text: str = "Hello",
    css: str = "#root",
    xpath: str = "//*[@id='root']",
    full_xpath: str = "/html/body/div[1]",
    js_path: str = "document.querySelector('#root')",
    outer_html: str = "<div id='root'>Hello</div>",
    styles: dict | None = None,
    attributes: dict | None = None,
    rect: dict | None = None,
) -> dict:
    return {
        "index": index,
        "tag": tag,
        "text": text,
        "css": css,
        "xpath": xpath,
        "full_xpath": full_xpath,
        "js_path": js_path,
        "outer_html": outer_html,
        "styles": styles or {"color": "black", "backgroundColor": "white"},
        "attributes": attributes or {"id": "root"},
        "rect": rect or {"x": 0.0, "y": 0.0, "width": 100.0, "height": 50.0},
    }


def make_mock_page(return_value: list) -> MagicMock:
    page = MagicMock()
    page.evaluate = AsyncMock(return_value=return_value)
    return page


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


class TestExtractElements:
    @pytest.mark.asyncio
    async def test_returns_element_collection(self):
        page = make_mock_page([make_element_dict(index=0)])
        result = await extract_elements(page)
        assert isinstance(result, ElementCollection)

    @pytest.mark.asyncio
    async def test_deserializes_element_fields_correctly(self):
        raw = make_element_dict(
            index=1,
            tag="button",
            text="Click me",
            css="#btn",
            xpath="//*[@id='btn']",
            full_xpath="/html/body/button[1]",
            js_path="document.querySelector('#btn')",
            outer_html="<button id='btn'>Click me</button>",
            styles={"color": "blue", "fontSize": "14px"},
            attributes={"id": "btn", "type": "submit"},
            rect={"x": 10.0, "y": 20.0, "width": 80.0, "height": 30.0},
        )
        page = make_mock_page([raw])
        result = await extract_elements(page)

        assert len(result) == 1
        el = result[0]
        assert isinstance(el, ElementInfo)
        assert el.index == 1
        assert el.tag == "button"
        assert el.text == "Click me"
        assert el.css == "#btn"
        assert el.xpath == "//*[@id='btn']"
        assert el.full_xpath == "/html/body/button[1]"
        assert el.js_path == "document.querySelector('#btn')"
        assert el.outer_html == "<button id='btn'>Click me</button>"
        assert el.styles == {"color": "blue", "fontSize": "14px"}
        assert el.attributes == {"id": "btn", "type": "submit"}
        assert el.rect == {"x": 10.0, "y": 20.0, "width": 80.0, "height": 30.0}

    @pytest.mark.asyncio
    async def test_multiple_elements_preserved_in_order(self):
        raws = [make_element_dict(index=i, tag=t) for i, t in enumerate(["a", "button", "input"])]
        page = make_mock_page(raws)
        result = await extract_elements(page)

        assert len(result) == 3
        assert result[0].tag == "a"
        assert result[1].tag == "button"
        assert result[2].tag == "input"

    @pytest.mark.asyncio
    async def test_empty_page_returns_empty_collection(self):
        page = make_mock_page([])
        result = await extract_elements(page)
        assert isinstance(result, ElementCollection)
        assert len(result) == 0

    @pytest.mark.asyncio
    async def test_max_elements_default_passed_to_js(self):
        page = make_mock_page([])
        await extract_elements(page)
        page.evaluate.assert_called_once()
        call_args = page.evaluate.call_args
        # Second argument (after the JS string) should be the max_elements value
        assert call_args.args[1] == 500

    @pytest.mark.asyncio
    async def test_max_elements_custom_value_passed_to_js(self):
        page = make_mock_page([])
        await extract_elements(page, max_elements=100)
        call_args = page.evaluate.call_args
        assert call_args.args[1] == 100

    @pytest.mark.asyncio
    async def test_js_constant_is_string(self):
        from scrapurrr.extraction.element import ELEMENT_EXTRACTION_JS

        assert isinstance(ELEMENT_EXTRACTION_JS, str)
        assert len(ELEMENT_EXTRACTION_JS) > 100

    @pytest.mark.asyncio
    async def test_first_arg_to_evaluate_is_js_constant(self):
        from scrapurrr.extraction.element import ELEMENT_EXTRACTION_JS

        page = make_mock_page([])
        await extract_elements(page)
        call_args = page.evaluate.call_args
        assert call_args.args[0] == ELEMENT_EXTRACTION_JS

    @pytest.mark.asyncio
    async def test_collection_supports_filter_after_extract(self):
        raws = [
            make_element_dict(index=0, tag="div"),
            make_element_dict(index=1, tag="button"),
            make_element_dict(index=2, tag="div"),
        ]
        page = make_mock_page(raws)
        result = await extract_elements(page)
        divs = result.filter(tag="div")
        assert len(divs) == 2
