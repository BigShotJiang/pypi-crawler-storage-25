"""Tests for authentication and session management (login, cookies)."""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from scrapurrr import Scrapurrr


class TestLogin:
    @pytest.mark.asyncio
    async def test_login_fills_and_submits_form(self) -> None:
        scraper = Scrapurrr(provider="ollama/llama3")

        mock_page = AsyncMock()
        mock_page.navigate = AsyncMock()
        mock_page.type_text = AsyncMock()
        mock_page.click = AsyncMock()

        with (
            patch.object(scraper, "_get_page", new_callable=AsyncMock, return_value=mock_page),
            patch.object(scraper, "_release_page", new_callable=AsyncMock),
            patch("scrapurrr.asyncio.sleep", new_callable=AsyncMock),
        ):
            await scraper.login(
                url="https://example.com/login",
                credentials={"username": "user@test.com", "password": "s3cr3t"},
            )

        mock_page.navigate.assert_called_once_with("https://example.com/login")
        assert mock_page.type_text.call_count == 2
        mock_page.click.assert_called_once()

    @pytest.mark.asyncio
    async def test_login_uses_email_key_as_fallback(self) -> None:
        scraper = Scrapurrr(provider="ollama/llama3")

        mock_page = AsyncMock()
        mock_page.navigate = AsyncMock()
        mock_page.type_text = AsyncMock()
        mock_page.click = AsyncMock()

        with (
            patch.object(scraper, "_get_page", new_callable=AsyncMock, return_value=mock_page),
            patch.object(scraper, "_release_page", new_callable=AsyncMock),
            patch("scrapurrr.asyncio.sleep", new_callable=AsyncMock),
        ):
            await scraper.login(
                url="https://example.com/login",
                credentials={"email": "user@test.com", "password": "pass"},
            )

        # Verify type_text was called with the email value
        calls = mock_page.type_text.call_args_list
        typed_values = [c.args[1] for c in calls]
        assert "user@test.com" in typed_values

    @pytest.mark.asyncio
    async def test_login_releases_page_on_error(self) -> None:
        scraper = Scrapurrr(provider="ollama/llama3")

        mock_page = AsyncMock()
        mock_page.navigate = AsyncMock(side_effect=RuntimeError("nav failed"))

        release_mock = AsyncMock()
        with (  # noqa: SIM117
            patch.object(scraper, "_get_page", new_callable=AsyncMock, return_value=mock_page),
            patch.object(scraper, "_release_page", release_mock),
        ):
            with pytest.raises(RuntimeError, match="nav failed"):
                await scraper.login(
                    url="https://example.com/login",
                    credentials={"username": "u", "password": "p"},
                )

        release_mock.assert_called_once_with(mock_page)

    @pytest.mark.asyncio
    async def test_login_custom_selectors(self) -> None:
        scraper = Scrapurrr(provider="ollama/llama3")

        mock_page = AsyncMock()
        mock_page.navigate = AsyncMock()
        mock_page.type_text = AsyncMock()
        mock_page.click = AsyncMock()

        custom_username_sel = "#email-field"
        custom_password_sel = "#pass-field"
        custom_submit_sel = ".login-btn"

        with (
            patch.object(scraper, "_get_page", new_callable=AsyncMock, return_value=mock_page),
            patch.object(scraper, "_release_page", new_callable=AsyncMock),
            patch("scrapurrr.asyncio.sleep", new_callable=AsyncMock),
        ):
            await scraper.login(
                url="https://example.com/login",
                credentials={"username": "user", "password": "pass"},
                username_selector=custom_username_sel,
                password_selector=custom_password_sel,
                submit_selector=custom_submit_sel,
            )

        type_calls = mock_page.type_text.call_args_list
        assert type_calls[0].args[0] == custom_username_sel
        assert type_calls[1].args[0] == custom_password_sel
        mock_page.click.assert_called_once_with(custom_submit_sel)


class TestSetGetCookies:
    @pytest.mark.asyncio
    async def test_set_cookies_calls_add_cookies(self) -> None:
        scraper = Scrapurrr(provider="ollama/llama3")

        mock_context = AsyncMock()
        mock_context.add_cookies = AsyncMock()

        mock_playwright_page = MagicMock()
        mock_playwright_page.context = mock_context

        mock_page = MagicMock()
        mock_page._page = mock_playwright_page

        cookies = [{"name": "session", "value": "abc123", "domain": "example.com"}]

        with (
            patch.object(scraper, "_get_page", new_callable=AsyncMock, return_value=mock_page),
            patch.object(scraper, "_release_page", new_callable=AsyncMock),
        ):
            await scraper.set_cookies(cookies)

        mock_context.add_cookies.assert_called_once_with(cookies)

    @pytest.mark.asyncio
    async def test_get_cookies_returns_cookie_list(self) -> None:
        scraper = Scrapurrr(provider="ollama/llama3")

        expected_cookies = [
            {"name": "session", "value": "tok123", "domain": "example.com"},
            {"name": "user_id", "value": "42", "domain": "example.com"},
        ]

        mock_context = AsyncMock()
        mock_context.cookies = AsyncMock(return_value=expected_cookies)

        mock_playwright_page = MagicMock()
        mock_playwright_page.context = mock_context

        mock_page = MagicMock()
        mock_page._page = mock_playwright_page

        with (
            patch.object(scraper, "_get_page", new_callable=AsyncMock, return_value=mock_page),
            patch.object(scraper, "_release_page", new_callable=AsyncMock),
        ):
            result = await scraper.get_cookies()

        assert result == expected_cookies

    @pytest.mark.asyncio
    async def test_set_cookies_releases_page_on_error(self) -> None:
        scraper = Scrapurrr(provider="ollama/llama3")

        mock_page = MagicMock()
        # Accessing ._page.context will raise
        type(mock_page)._page = property(
            lambda self: (_ for _ in ()).throw(RuntimeError("no page"))
        )

        release_mock = AsyncMock()
        with (  # noqa: SIM117
            patch.object(scraper, "_get_page", new_callable=AsyncMock, return_value=mock_page),
            patch.object(scraper, "_release_page", release_mock),
        ):
            with pytest.raises((RuntimeError, AttributeError)):
                await scraper.set_cookies([{"name": "x", "value": "y"}])

        release_mock.assert_called_once_with(mock_page)
