"""Tests for MCP server."""

from __future__ import annotations

import json

import pytest

from scrapurrr.mcp_server import _build_dynamic_schema, create_mcp_server, handle_tool_call


def test_server_info() -> None:
    info = create_mcp_server()
    assert info["name"] == "scrapurrr"
    assert len(info["tools"]) == 3


def test_tool_names() -> None:
    info = create_mcp_server()
    names = [t["name"] for t in info["tools"]]
    assert "scrape_url" in names
    assert "scrape_multiple_urls" in names
    assert "agent_scrape" in names


def test_server_has_version_and_description() -> None:
    info = create_mcp_server()
    assert info["version"] == "0.1.0"
    assert "description" in info


def test_tool_schemas_have_required_fields() -> None:
    info = create_mcp_server()
    for tool in info["tools"]:
        assert "name" in tool
        assert "description" in tool
        assert "inputSchema" in tool
        assert "required" in tool["inputSchema"]


def test_build_dynamic_schema() -> None:
    fields = [
        {"name": "title", "type": "str"},
        {"name": "price", "type": "float"},
        {"name": "in_stock", "type": "bool"},
    ]
    schema = _build_dynamic_schema(fields)
    assert hasattr(schema, "model_fields")
    assert "title" in schema.model_fields
    assert "price" in schema.model_fields
    assert "in_stock" in schema.model_fields


def test_build_dynamic_schema_validates() -> None:
    fields = [{"name": "name", "type": "str"}, {"name": "count", "type": "int"}]
    schema = _build_dynamic_schema(fields)
    instance = schema(name="Widget", count=5)
    assert instance.name == "Widget"
    assert instance.count == 5


def test_build_dynamic_schema_all_types() -> None:
    fields = [
        {"name": "s", "type": "str"},
        {"name": "i", "type": "int"},
        {"name": "f", "type": "float"},
        {"name": "b", "type": "bool"},
    ]
    schema = _build_dynamic_schema(fields)
    instance = schema(s="hello", i=1, f=3.14, b=True)
    assert instance.s == "hello"
    assert instance.i == 1
    assert instance.f == pytest.approx(3.14)
    assert instance.b is True


def test_build_dynamic_schema_unknown_type_falls_back_to_str() -> None:
    fields = [{"name": "x", "type": "unknown_type"}]
    schema = _build_dynamic_schema(fields)
    instance = schema(x="anything")
    assert instance.x == "anything"


@pytest.mark.asyncio
async def test_handle_unknown_tool() -> None:
    result = await handle_tool_call("unknown_tool", {})
    parsed = json.loads(result)
    assert "error" in parsed
    assert "unknown_tool" in parsed["error"]
