"""Human-like mouse movement simulation using WindMouse and Bezier curves."""

from __future__ import annotations

import logging
import math
import random
from dataclasses import dataclass

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class Point:
    x: float
    y: float


def wind_mouse(
    start_x: float,
    start_y: float,
    end_x: float,
    end_y: float,
    gravity: float = 9.0,
    wind: float = 3.0,
    max_velocity: float = 15.0,
    distance_threshold: float = 12.0,
) -> list[Point]:
    """Generate human-like mouse path using the WindMouse algorithm.

    Physics model: cursor is a particle acted upon by constant gravity
    (toward target) and smoothly varying random wind force.

    Parameters:
            gravity: Force pulling toward destination (default 9.0)
            wind: Random force magnitude (default 3.0)
            max_velocity: Speed clamp (default 15.0)
            distance_threshold: Distance at which wind calms down (default 12.0)
    """
    points: list[Point] = [Point(start_x, start_y)]

    cur_x, cur_y = start_x, start_y
    vel_x, vel_y = 0.0, 0.0
    wind_x, wind_y = 0.0, 0.0

    sqrt3 = math.sqrt(3)
    sqrt5 = math.sqrt(5)

    while True:
        dist = math.hypot(end_x - cur_x, end_y - cur_y)
        if dist < 1:
            break

        # Wind behavior changes near target
        if dist >= distance_threshold:
            wind_x = wind_x / sqrt3 + random.uniform(-wind / sqrt5, wind / sqrt5)
            wind_y = wind_y / sqrt3 + random.uniform(-wind / sqrt5, wind / sqrt5)
        else:
            wind_x /= sqrt3
            wind_y /= sqrt3

        # Gravity always points toward destination
        grav_x = gravity * (end_x - cur_x) / dist
        grav_y = gravity * (end_y - cur_y) / dist

        # Apply forces
        vel_x += grav_x + wind_x
        vel_y += grav_y + wind_y

        # Clamp velocity
        speed = math.hypot(vel_x, vel_y)
        if speed > max_velocity:
            scale = random.uniform(max_velocity / 2, max_velocity) / speed
            vel_x *= scale
            vel_y *= scale

        cur_x += vel_x
        cur_y += vel_y
        points.append(Point(round(cur_x), round(cur_y)))

    # Ensure we end exactly at target
    points.append(Point(round(end_x), round(end_y)))
    return points


def bezier_mouse(
    start_x: float,
    start_y: float,
    end_x: float,
    end_y: float,
    num_points: int = 50,
    curvature: float = 0.3,
) -> list[Point]:
    """Generate mouse path using cubic Bezier curve with randomized control points.

    Control points are placed on ONE side of the line (humans don't arc both ways).
    """
    # Perpendicular direction for control point offset
    dx = end_x - start_x
    dy = end_y - start_y
    dist = math.hypot(dx, dy)

    if dist < 5:
        return [Point(round(start_x), round(start_y)), Point(round(end_x), round(end_y))]

    # Normal vector (perpendicular)
    nx = -dy / dist
    ny = dx / dist

    # Pick one side randomly
    side = random.choice([-1, 1])

    # Control points with randomized offset
    offset1 = side * dist * curvature * random.uniform(0.3, 1.0)
    offset2 = side * dist * curvature * random.uniform(0.3, 1.0)

    cp1_x = start_x + dx * 0.3 + nx * offset1
    cp1_y = start_y + dy * 0.3 + ny * offset1
    cp2_x = start_x + dx * 0.7 + nx * offset2
    cp2_y = start_y + dy * 0.7 + ny * offset2

    points: list[Point] = []
    for i in range(num_points + 1):
        t = i / num_points
        inv = 1 - t

        x = inv**3 * start_x + 3 * inv**2 * t * cp1_x + 3 * inv * t**2 * cp2_x + t**3 * end_x
        y = inv**3 * start_y + 3 * inv**2 * t * cp1_y + 3 * inv * t**2 * cp2_y + t**3 * end_y

        # Add micro-jitter (physiological tremor, inversely scaled to speed)
        if 0.1 < t < 0.9:
            jitter = random.gauss(0, 0.5)
            x += jitter
            y += jitter

        points.append(Point(round(x), round(y)))

    return points


def add_overshoot(
    points: list[Point],
    target_x: float,
    target_y: float,
    probability: float = 0.7,
    magnitude_ratio: float = 0.08,
) -> list[Point]:
    """Add realistic overshoot past target with correction sub-movement.

    ~70% of human movements overshoot by 3-12% of distance.
    """
    if random.random() > probability:
        return points

    if len(points) < 2:
        return points

    # Direction of approach
    last = points[-1]
    second_last = points[-2]
    dx = last.x - second_last.x
    dy = last.y - second_last.y
    dist = math.hypot(dx, dy)

    if dist < 1:
        return points

    # Overshoot magnitude: 3-12% of total path distance
    total_dist = sum(
        math.hypot(points[i].x - points[i - 1].x, points[i].y - points[i - 1].y)
        for i in range(1, len(points))
    )
    overshoot_dist = total_dist * random.uniform(0.03, 0.12)

    overshoot_x = target_x + (dx / dist) * overshoot_dist
    overshoot_y = target_y + (dy / dist) * overshoot_dist

    # Add overshoot point then correction back to target
    points = list(points)
    points.append(Point(round(overshoot_x), round(overshoot_y)))

    # Small correction movement back
    correction = bezier_mouse(
        overshoot_x, overshoot_y, target_x, target_y, num_points=10, curvature=0.1
    )
    points.extend(correction[1:])  # skip duplicate start point

    return points
