"""Human-like timing using research-backed distributions."""

from __future__ import annotations

import logging
import math
import random

logger = logging.getLogger(__name__)


def fitts_law_duration(
    distance: float, target_width: float, a: float = 0.070, b: float = 0.150
) -> float:
    """Calculate movement duration using Fitts's Law.

    MT = a + b * log2(D/W + 1)

    Typical: a=0.070s (device start-up), b=0.150s (info processing)
    Returns duration in seconds.
    """
    if distance <= 0 or target_width <= 0:
        return a
    index_of_difficulty = math.log2(distance / target_width + 1)
    base_time = a + b * index_of_difficulty
    # Add human variance (log-normal noise)
    variance = random.lognormvariate(0, 0.15)
    return base_time * variance


def reaction_time() -> float:
    """Generate a human reaction time using shifted log-normal distribution.

    Based on 81M samples from Human Benchmark:
    - Median: 273ms, Mean: 284ms
    - Floor: ~120ms, typical range: 200-500ms
    """
    # Shifted log-normal: shift=0.12, mu=5.60, sigma=0.22
    # This produces median ~270ms, mean ~277ms
    raw = random.lognormvariate(5.60, 0.22) / 1000.0  # convert to seconds
    return max(0.12, raw)  # floor at 120ms


def reading_pause(text_length: int, wpm: int = 250) -> float:
    """Estimate how long a human would pause to read content.

    Average reading speed: 200-300 WPM. Adds variance.
    """
    words = max(1, text_length // 5)  # rough word estimate
    base_time = words / (wpm / 60.0)
    # Add log-normal variance
    return base_time * random.lognormvariate(0, 0.3)


def click_delay() -> float:
    """Time between seeing a target and clicking it.

    Shifted log-normal: 150-600ms range, median ~280ms.
    """
    return max(0.15, random.lognormvariate(-1.2, 0.35))


def inter_action_pause() -> float:
    """Natural pause between consecutive actions.

    Humans take 2-30 seconds between page interactions.
    Log-normal distribution centered around 3-5 seconds.
    """
    return max(0.5, random.lognormvariate(1.2, 0.6))


def micro_pause() -> float:
    """Occasional micro-pause during movement (~3% probability, 15-40ms)."""
    if random.random() < 0.03:
        return random.uniform(0.015, 0.040)
    return 0.0


def thinking_pause() -> float:
    """Occasional thinking pause during complex interactions.

    ~2% probability, 300-700ms.
    """
    if random.random() < 0.02:
        return random.uniform(0.3, 0.7)
    return 0.0


def distraction_pause() -> float:
    """Rare distraction pause simulating attention shift.

    ~0.5% probability, 500-1200ms.
    """
    if random.random() < 0.005:
        return random.uniform(0.5, 1.2)
    return 0.0
