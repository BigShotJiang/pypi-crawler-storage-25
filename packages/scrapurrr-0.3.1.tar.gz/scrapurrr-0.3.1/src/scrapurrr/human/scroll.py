"""Human-like scroll simulation with physics-based easing."""

from __future__ import annotations

import logging
import random

logger = logging.getLogger(__name__)


def generate_scroll_sequence(
    total_distance: int,
    direction: str = "down",
) -> list[tuple[int, float]]:
    """Generate a realistic scroll sequence with momentum and micro-pauses.

    Returns list of (delta_pixels, delay_seconds) for each scroll event.

    Based on research:
    - Mouse wheel: 100-120px per notch
    - Trackpad: many small events with momentum
    - Cubic bezier easing: (0.645, 0.045, 0.355, 1.0)
    - Micro-pauses: 5% probability, 20-50ms
    - Overshoot: 15% probability, correct back
    """
    if total_distance <= 0:
        return [(120, 0.1)]

    sign = -1 if direction == "up" else 1
    events: list[tuple[int, float]] = []
    remaining = total_distance

    # Simulate scroll as series of "flick" gestures
    while remaining > 0:
        # Each flick covers 100-400 pixels with momentum
        flick_distance = min(remaining, random.randint(100, 400))
        remaining -= flick_distance

        # Generate sub-events for this flick with easing
        steps = max(3, flick_distance // 40)
        flick_events: list[tuple[int, float]] = []
        accumulated = 0

        for step in range(steps):
            t = step / steps
            # Cubic bezier easing: fast start, smooth deceleration
            eased_t = _cubic_bezier(t, 0.645, 0.045, 0.355, 1.0)

            # Delta per step
            if step < steps - 1:
                next_t = (step + 1) / steps
                next_eased = _cubic_bezier(next_t, 0.645, 0.045, 0.355, 1.0)
                delta = int(flick_distance * (next_eased - eased_t))
            else:
                delta = flick_distance - accumulated
                delta = max(10, abs(delta))

            # Add jitter (+/- 3 pixels)
            delta = max(1, delta + random.randint(-3, 3))
            accumulated += delta

            # Inter-event delay (16-50ms for smooth scrolling)
            delay = random.uniform(0.016, 0.050)

            # Micro-pause (5% chance)
            if random.random() < 0.05:
                delay += random.uniform(0.020, 0.050)

            flick_events.append((sign * delta, delay))

        events.extend(flick_events)

        # Pause between flicks (reading pause)
        if remaining > 0:
            events.append((0, random.uniform(0.5, 3.0)))

    # Overshoot (15% chance)
    if random.random() < 0.15:
        overshoot = random.randint(20, 60)
        events.append((sign * overshoot, random.uniform(0.1, 0.2)))
        # Correct back
        events.append((-sign * overshoot, random.uniform(0.2, 0.4)))

    return events


def _cubic_bezier(t: float, p1x: float, p1y: float, p2x: float, p2y: float) -> float:
    """Approximate cubic bezier curve value at t."""
    # Simplified cubic bezier using De Casteljau
    cx = 3 * p1x
    bx = 3 * (p2x - p1x) - cx
    1 - cx - bx

    cy = 3 * p1y
    by = 3 * (p2y - p1y) - cy
    ay = 1 - cy - by

    return ((ay * t + by) * t + cy) * t
