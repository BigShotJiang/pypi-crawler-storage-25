"""Human-like typing simulation with realistic cadence and errors."""

from __future__ import annotations

import logging
import random

logger = logging.getLogger(__name__)

# Adjacent keys for typo generation
_ADJACENT_KEYS: dict[str, str] = {
    "a": "sqwz",
    "b": "vghn",
    "c": "xdfv",
    "d": "sfcer",
    "e": "rdws",
    "f": "dgcvr",
    "g": "fhtbv",
    "h": "gjynb",
    "i": "uojk",
    "j": "hknum",
    "k": "jlim",
    "l": "kop",
    "m": "njk",
    "n": "bhjm",
    "o": "iplk",
    "p": "ol",
    "q": "wa",
    "r": "etdf",
    "s": "awdxz",
    "t": "rfgy",
    "u": "yihj",
    "v": "cfgb",
    "w": "qase",
    "x": "zsdc",
    "y": "tghu",
    "z": "asx",
}


def generate_keystroke_timings(text: str) -> list[tuple[str, float]]:
    """Generate realistic keystroke timing for each character.

    Returns list of (character, delay_before_in_seconds) tuples.

    Based on research:
    - Key dwell: 50-200ms
    - Flight time: 80-400ms
    - Punctuation: +80-180ms extra
    - Thinking pauses: 2% probability, 300-700ms
    - Typo rate: ~2% with correction
    """
    keystrokes: list[tuple[str, float]] = []

    for i, char in enumerate(text):
        # Base inter-key delay (log-normal, median ~120ms)
        delay = random.lognormvariate(-2.1, 0.4)  # ~100-300ms range
        delay = max(0.03, min(delay, 0.5))  # clamp

        # Extra delay for punctuation and special characters
        if char in ".,;:!?@#$%^&*()":
            delay += random.uniform(0.08, 0.18)

        # Extra delay after space (word boundary pause)
        if i > 0 and text[i - 1] == " ":
            delay += random.uniform(0.02, 0.08)

        # Thinking pause (2% chance)
        if random.random() < 0.02:
            delay += random.uniform(0.3, 0.7)

        # Distraction pause (0.5% chance)
        if random.random() < 0.005:
            delay += random.uniform(0.5, 1.2)

        keystrokes.append((char, delay))

    return keystrokes


def generate_typo_sequence(text: str, typo_rate: float = 0.02) -> list[tuple[str, float]]:
    """Generate keystroke sequence INCLUDING realistic typos and corrections.

    Typo distribution: adjacent key 55%, transposition 20%,
    double press 12%, skip 8%, missed space 5%.

    Returns list of (character, delay) including backspace corrections.
    """
    keystrokes: list[tuple[str, float]] = []
    i = 0

    while i < len(text):
        char = text[i]

        # Base timing
        delay = random.lognormvariate(-2.1, 0.4)
        delay = max(0.03, min(delay, 0.5))

        if char in ".,;:!?":
            delay += random.uniform(0.08, 0.18)

        # Thinking/distraction pauses
        if random.random() < 0.02:
            delay += random.uniform(0.3, 0.7)

        # Typo?
        if random.random() < typo_rate and char.isalpha():
            typo_type = random.random()

            if typo_type < 0.55:
                # Adjacent key error
                adjacent = _ADJACENT_KEYS.get(char.lower(), "")
                if adjacent:
                    wrong_char = random.choice(adjacent)
                    if char.isupper():
                        wrong_char = wrong_char.upper()
                    keystrokes.append((wrong_char, delay))
                    # Pause before noticing error
                    notice_delay = random.uniform(0.15, 0.4)
                    keystrokes.append(("\b", notice_delay))  # backspace
                    # Re-type correct character
                    keystrokes.append((char, random.uniform(0.05, 0.15)))
                    i += 1
                    continue

            elif typo_type < 0.75:
                # Transposition (swap with next char)
                if i + 1 < len(text):
                    keystrokes.append((text[i + 1], delay))
                    keystrokes.append((char, random.uniform(0.04, 0.10)))
                    # Notice and correct
                    notice_delay = random.uniform(0.2, 0.5)
                    keystrokes.append(("\b", notice_delay))
                    keystrokes.append(("\b", random.uniform(0.05, 0.10)))
                    keystrokes.append((char, random.uniform(0.05, 0.12)))
                    keystrokes.append((text[i + 1], random.uniform(0.05, 0.12)))
                    i += 2
                    continue

            elif typo_type < 0.87:
                # Double press
                keystrokes.append((char, delay))
                keystrokes.append((char, random.uniform(0.03, 0.08)))
                notice_delay = random.uniform(0.15, 0.35)
                keystrokes.append(("\b", notice_delay))
                i += 1
                continue

        keystrokes.append((char, delay))
        i += 1

    return keystrokes
