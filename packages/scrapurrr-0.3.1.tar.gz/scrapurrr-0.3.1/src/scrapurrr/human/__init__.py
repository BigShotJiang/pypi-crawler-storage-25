"""Human behavior simulation — mouse, keyboard, scroll, timing."""
