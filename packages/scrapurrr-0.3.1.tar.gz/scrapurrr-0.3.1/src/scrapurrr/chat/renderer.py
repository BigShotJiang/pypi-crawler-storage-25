"""Chat renderer with shimmer animation and markdown output."""

import asyncio
import contextlib
import random
import sys
from math import pi, sin

from rich.console import Console
from rich.markdown import Markdown

from scrapurrr.extraction.element import ElementCollection

_console = Console()

_SHADES = [
    "\033[2;31m",  # dim red
    "\033[31m",  # red
    "\033[1;31m",  # bright red
    "\033[1;37m",  # white
    "\033[1;31m",  # bright red
    "\033[31m",  # red
]
_RESET = "\033[0m"
_CLEAR = "\033[2K\r"
_SHIMMER_TEXT = "spurringgg..."
_SHIMMER_SPEED = 3.0
_SHIMMER_INTERVAL = 0.05  # 20fps


class ChatRenderer:
    def __init__(self) -> None:
        self._shimmer_task: asyncio.Task[None] | None = None
        self._phases: list[float] = [random.uniform(0, 2 * pi) for _ in _SHIMMER_TEXT]

    def print_header(self, version: str) -> None:
        """Print the scrapurrr header."""
        _console.print(f"scrapurrr v{version}\n")

    def print_text(self, text: str) -> None:
        """Print plain text."""
        _console.print(text)

    def render_markdown(self, text: str) -> None:
        """Render markdown with rich."""
        _console.print(Markdown(text))

    def stream_token(self, token: str) -> None:
        """Write a token to stdout and flush."""
        sys.stdout.write(token)
        sys.stdout.flush()

    def end_stream(self) -> None:
        """End a streaming sequence with double newline."""
        sys.stdout.write("\n\n")
        sys.stdout.flush()

    async def start_shimmer(self) -> None:
        """Start the shimmer animation as an asyncio task."""
        self._shimmer_task = asyncio.create_task(self._shimmer_loop())

    async def stop_shimmer(self) -> None:
        """Cancel the shimmer task and clear the line."""
        if self._shimmer_task is not None:
            self._shimmer_task.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await self._shimmer_task
            self._shimmer_task = None
        sys.stdout.write(_CLEAR)
        sys.stdout.flush()

    async def _shimmer_loop(self) -> None:
        """Animate shimmer until cancelled."""
        t = 0.0
        while True:
            line = ""
            for i, ch in enumerate(_SHIMMER_TEXT):
                wave = (sin(t * _SHIMMER_SPEED + self._phases[i]) + 1) / 2
                shade_idx = min(int(wave * len(_SHADES)), len(_SHADES) - 1)
                line += f"{_SHADES[shade_idx]}{ch}{_RESET}"
            sys.stdout.write(f"{_CLEAR}{line}")
            sys.stdout.flush()
            await asyncio.sleep(_SHIMMER_INTERVAL)
            t += _SHIMMER_INTERVAL

    def get_input(self) -> str | None:
        """Show a red '> ' prompt and get user input."""
        try:
            return input("\033[1;31m> \033[0m").strip()
        except (EOFError, KeyboardInterrupt):
            return None

    def format_elements(self, elements: ElementCollection) -> str:
        """Format elements with tag, text, css, and xpath."""
        lines: list[str] = []
        for el in elements:
            lines.append(f'  [{el.index}] {el.tag} "{el.text}"')
            lines.append(f"      css: {el.css}")
            lines.append(f"      xpath: {el.xpath}")
            lines.append("")
        return "\n".join(lines)

    def format_xpaths(self, elements: ElementCollection) -> str:
        """Format elements showing xpath and text in aligned columns."""
        lines: list[str] = []
        for el in elements:
            selector = el.xpath.ljust(60)
            lines.append(f'  [{el.index}] {selector} "{el.text}"')
        return "\n".join(lines)

    def format_css_selectors(self, elements: ElementCollection) -> str:
        """Format elements showing css selector and text in aligned columns."""
        lines: list[str] = []
        for el in elements:
            selector = el.css.ljust(60)
            lines.append(f'  [{el.index}] {selector} "{el.text}"')
        return "\n".join(lines)
