"""Direct command parser for chat CLI."""

from __future__ import annotations

import re
from dataclasses import dataclass


@dataclass(frozen=True)
class Command:
    action: str
    args: dict[str, str]


_TAG_ALIASES: dict[str, str] = {
    "links": "a",
    "link": "a",
    "buttons": "button",
    "images": "img",
    "inputs": "input",
    "selects": "select",
    "textareas": "textarea",
    "headings": "h1",
    "paragraphs": "p",
    "divs": "div",
    "spans": "span",
    "tables": "table",
    "rows": "tr",
    "cells": "td",
    "forms": "form",
    "labels": "label",
    "lists": "li",
}

_RE_NAVIGATE = re.compile(
    r"^(?:go\s+to|open|navigate)\s+(\S+)$",
    re.IGNORECASE,
)
_RE_FIND_QUOTED = re.compile(r'^find\s+"([^"]+)"$', re.IGNORECASE)
_RE_FIND_UNQUOTED = re.compile(r"^find\s+(.+)$", re.IGNORECASE)
_RE_GET_SELECTORS = re.compile(
    r"^get\s+(xpath|css)\s+of\s+all\s+(\S+)$",
    re.IGNORECASE,
)
_RE_CLICK = re.compile(r"^click\s+(.+)$", re.IGNORECASE)


def parse_command(text: str) -> Command | None:
    """Parse *text* into a Command, or return None if no pattern matches."""
    stripped = text.strip()
    lower = stripped.lower()

    if lower in ("exit", "quit"):
        return Command(action="exit", args={})

    if lower == "back":
        return Command(action="back", args={})

    if lower in ("get elements", "list elements"):
        return Command(action="get_elements", args={})

    if lower == "scroll up":
        return Command(action="scroll", args={"direction": "up"})

    if lower == "scroll down":
        return Command(action="scroll", args={"direction": "down"})

    m = _RE_NAVIGATE.match(stripped)
    if m:
        return Command(action="navigate", args={"url": m.group(1)})

    m = _RE_FIND_QUOTED.match(stripped)
    if m:
        return Command(action="find", args={"text": m.group(1)})

    m = _RE_FIND_UNQUOTED.match(stripped)
    if m:
        return Command(action="find", args={"text": m.group(1)})

    m = _RE_GET_SELECTORS.match(stripped)
    if m:
        selector_type = m.group(1).lower()
        tag_word = m.group(2).lower()
        tag = _TAG_ALIASES.get(tag_word, tag_word)
        return Command(action="get_selectors", args={"selector_type": selector_type, "tag": tag})

    m = _RE_CLICK.match(stripped)
    if m:
        return Command(action="click", args={"selector": m.group(1)})

    return None
