"""ChatSession — agentic chat with tool-calling loop."""

from __future__ import annotations

import json
import logging
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

from scrapurrr.agent.dom import simplify_dom
from scrapurrr.chat.commands import parse_command
from scrapurrr.extraction.element import extract_elements
from scrapurrr.pipeline.cleaner import clean

if TYPE_CHECKING:
    from collections.abc import AsyncIterator

    from scrapurrr import Scrapurrr
    from scrapurrr.extraction.element import ElementCollection

logger = logging.getLogger(__name__)

_MAX_TOOL_STEPS = 10

_SYSTEM_PROMPT = """\
You are scrapurrr, an agentic web scraping assistant.
You have a browser open and can take actions on the current page.

## Rules
- NEVER suggest code, scripts, or manual steps.
- NEVER mention Selenium, Playwright, BeautifulSoup, or any library.
- You DO the work yourself using the tools below.
- After gathering data, respond with a FINAL answer in plain text.
- Be concise. No emojis.

## Available Tools
Respond with JSON to use a tool:

- {{"action": "navigate", "url": "<url>"}} — go to a URL
- {{"action": "click", "selector": "<css>"}} — click an element
- {{"action": "scroll", "direction": "down"}} — scroll down or up
- {{"action": "type", "selector": "<css>", "text": "<text>"}} — type into input
- {{"action": "extract"}} — get page content as markdown
- {{"action": "elements"}} — list all elements with CSS/XPath selectors
- {{"action": "elements", "text": "<filter>"}} — find elements matching text
- {{"action": "elements", "tag": "<tag>"}} — find elements by tag
- {{"action": "back"}} — go back
- {{"action": "wait", "selector": "<css>"}} — wait for element to appear
- {{"action": "screenshot"}} — capture the current page

When you have enough data to answer, respond with plain text (no JSON).
You can take multiple actions before answering.
One action per response. Think step by step.

## Current State
URL: {url}
{dom}
{content}
"""


@dataclass
class ChatResponse:
    text: str
    is_streaming: bool = False


class ChatSession:
    """Agentic chat session with tool-calling loop."""

    def __init__(self, scraper: Scrapurrr) -> None:
        self._scraper = scraper
        self._page: Any = None
        self._history: list[dict[str, str]] = []
        self._current_url: str | None = None

    @property
    def history(self) -> list[dict[str, str]]:
        return list(self._history)

    async def start(self) -> None:
        await self._scraper._ensure_launched()
        self._page = await self._scraper._get_page()

    async def close(self) -> None:
        if self._page is not None:
            await self._scraper._release_page(self._page)
        await self._scraper.close()

    # ------------------------------------------------------------------
    # Message routing
    # ------------------------------------------------------------------

    async def handle(
        self, user_input: str
    ) -> (
        ChatResponse
        | tuple[ChatResponse, ElementCollection]
        | tuple[ChatResponse, tuple[str, ElementCollection]]
        | None
    ):
        cmd = parse_command(user_input)

        if cmd is None:
            url = _extract_url(user_input)
            if url and self._current_url != url:
                await self._page.navigate(url)
                self._current_url = url
            return await self._agent_respond(user_input)

        if cmd.action == "exit":
            return None

        if cmd.action == "navigate":
            url = cmd.args["url"]
            await self._page.navigate(url)
            self._current_url = url
            self._history.append({"role": "user", "content": user_input})
            return ChatResponse(text=f"Navigated to {url}")

        if cmd.action == "back":
            await self._page.go_back()
            return ChatResponse(text="Went back to previous page")

        if cmd.action == "scroll":
            direction = cmd.args["direction"]
            await self._page.scroll(direction)
            return ChatResponse(text=f"Scrolled {direction}")

        if cmd.action == "click":
            selector = cmd.args["selector"]
            await self._page.click(selector)
            return ChatResponse(text=f"Clicked {selector}")

        if cmd.action == "find":
            text = cmd.args["text"]
            collection = await extract_elements(self._page)
            filtered = collection.filter(text=text)
            return (
                ChatResponse(text=f"Found {len(filtered)} element(s) matching '{text}'"),
                filtered,
            )

        if cmd.action == "get_elements":
            collection = await extract_elements(self._page)
            return (
                ChatResponse(text=f"Found {len(collection)} element(s) on page"),
                collection,
            )

        if cmd.action == "get_selectors":
            selector_type = cmd.args["selector_type"]
            tag = cmd.args["tag"]
            collection = await extract_elements(self._page)
            filtered = collection.filter(tag=tag)
            return (
                ChatResponse(text=f"Found {len(filtered)} {selector_type} selector(s) for <{tag}>"),
                (selector_type, filtered),
            )

        return await self._agent_respond(user_input)

    # ------------------------------------------------------------------
    # Agentic tool-calling loop
    # ------------------------------------------------------------------

    async def _get_page_context(self) -> tuple[str, str]:
        """Return (dom_summary, page_content) for current page."""
        html = await self._page.get_html()
        dom = simplify_dom(html, max_elements=150)
        content = clean(html).markdown[:3000]
        return dom, content

    async def _build_system_prompt(self) -> str:
        dom, content = await self._get_page_context()
        return _SYSTEM_PROMPT.format(
            url=self._current_url or "No page loaded",
            dom=f"## Page DOM\n{dom}",
            content=f"## Page Content\n{content}",
        )

    async def _execute_tool(self, action: dict[str, Any]) -> str:
        """Execute a tool action and return the result string."""
        name = action.get("action", "")

        if name == "navigate":
            url = action.get("url", "")
            await self._page.navigate(url)
            self._current_url = url
            return f"Navigated to {url}"

        if name == "click":
            selector = action.get("selector", "")
            await self._page.click(selector)
            return f"Clicked {selector}"

        if name == "scroll":
            direction = action.get("direction", "down")
            await self._page.scroll(direction)
            return f"Scrolled {direction}"

        if name == "type":
            selector = action.get("selector", "")
            text = action.get("text", "")
            await self._page.type_text(selector, text)
            return f"Typed '{text}' into {selector}"

        if name == "back":
            await self._page.go_back()
            return "Went back"

        if name == "wait":
            selector = action.get("selector", "")
            await self._page.wait_for(selector, timeout=10000)
            return f"Element {selector} appeared"

        if name == "extract":
            _, content = await self._get_page_context()
            return content

        if name == "elements":
            collection = await extract_elements(self._page, max_elements=100)
            tag = action.get("tag")
            text = action.get("text")
            if tag:
                collection = collection.filter(tag=tag)
            if text:
                collection = collection.filter(text=text)
            lines = []
            for el in collection:
                lines.append(
                    f'[{el.index}] <{el.tag}> "{el.text[:50]}" css="{el.css}" xpath="{el.xpath}"'
                )
            return "\n".join(lines) if lines else "No elements found"

        if name == "screenshot":
            data = await self._page.screenshot()
            from pathlib import Path

            Path("screenshot.png").write_bytes(data)
            return "Screenshot saved to screenshot.png"

        return f"Unknown action: {name}"

    def _parse_tool_call(self, response: str) -> dict[str, Any] | None:
        """Try to parse a JSON tool call from the LLM response."""
        text = response.strip()

        # Try to find JSON in the response
        for start_char, end_char in [("{", "}"), ("[", "]")]:
            start = text.find(start_char)
            end = text.rfind(end_char)
            if start != -1 and end > start:
                try:
                    parsed = json.loads(text[start : end + 1])
                    if isinstance(parsed, dict) and "action" in parsed:
                        return parsed
                except json.JSONDecodeError:
                    continue
        return None

    async def _agent_respond(self, user_input: str) -> ChatResponse:
        """Run an agentic loop: LLM can call tools or respond with text."""
        self._history.append({"role": "user", "content": user_input})

        actions_taken: list[str] = []

        for step in range(_MAX_TOOL_STEPS):
            system_prompt = await self._build_system_prompt()

            if actions_taken:
                actions_context = "\n## Actions Taken\n" + "\n".join(actions_taken)
                system_prompt += actions_context

            recent = self._history[-10:]
            prompt = "\n".join(f"{m['role'].capitalize()}: {m['content']}" for m in recent)

            try:
                response = await self._scraper._llm.complete(prompt, system_prompt=system_prompt)
            except Exception as exc:
                self._history.pop()
                return ChatResponse(text=_friendly_error(exc))

            # Check if LLM wants to call a tool
            tool_call = self._parse_tool_call(response)

            if tool_call is None:
                # Plain text response — we're done
                self._history.append({"role": "assistant", "content": response})
                return ChatResponse(text=response)

            # Execute the tool
            action_name = tool_call.get("action", "unknown")
            logger.info("Chat agent step %d: %s", step + 1, action_name)

            try:
                result = await self._execute_tool(tool_call)
            except Exception as exc:
                result = f"Error: {exc}"

            actions_taken.append(f"- {action_name}: {result[:200]}")

        # Ran out of steps — ask LLM for final answer
        system_prompt = await self._build_system_prompt()
        system_prompt += (
            "\n\n## Actions Taken\n"
            + "\n".join(actions_taken)
            + "\n\nNow give your final answer based on the data collected."
        )

        recent = self._history[-10:]
        prompt = "\n".join(f"{m['role'].capitalize()}: {m['content']}" for m in recent)

        try:
            response = await self._scraper._llm.complete(prompt, system_prompt=system_prompt)
        except Exception as exc:
            self._history.pop()
            return ChatResponse(text=_friendly_error(exc))

        self._history.append({"role": "assistant", "content": response})
        return ChatResponse(text=response)

    async def stream_respond(self, user_input: str) -> AsyncIterator[str]:
        """Agentic response — runs tool loop, then streams final answer."""
        result = await self._agent_respond(user_input)
        yield result.text


def _friendly_error(exc: Exception) -> str:
    msg = str(exc).lower()
    if "not found" in msg and "model" in msg:
        return (
            "Model not found. Pull it first or switch to another.\n"
            "  For Ollama: ollama pull <model>\n"
            "  Or switch: /model"
        )
    if "connect" in msg and ("11434" in msg or "ollama" in msg):
        return (
            "Could not connect to Ollama. Is it running?\n"
            "  Start it: ollama serve\n"
            "  Or switch model: /model"
        )
    if "401" in msg or "auth" in msg or "api key" in msg:
        return "Authentication failed. Check your API key.\n  Update it: /key"
    if "429" in msg or "rate" in msg:
        return "Rate limited. Wait a moment and try again."
    if "timeout" in msg:
        return "Request timed out. Try again or switch model: /model"
    if "connect" in msg:
        return (
            "Connection error: could not reach the provider.\n"
            "  Check your network or switch model: /model"
        )
    return f"Error: {exc}"


def _extract_url(text: str) -> str | None:
    import re

    m = re.search(r"https?://\S+", text)
    return m.group(0).rstrip(".,;:!?)") if m else None
