"""MCP server exposing scrapurrr as tools for AI agents."""

from __future__ import annotations

import asyncio
import json
import logging
import sys
from typing import Any

logger = logging.getLogger(__name__)


def create_mcp_server() -> dict[str, Any]:
    """Create MCP server configuration with tool definitions."""
    return {
        "name": "scrapurrr",
        "version": "0.1.0",
        "description": "Agentic web scraper with schema-driven extraction",
        "tools": [
            {
                "name": "scrape_url",
                "description": (
                    "Extract structured data from a single URL"
                    " using a schema definition."
                    " Returns JSON matching the schema."
                ),
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "url": {"type": "string", "description": "URL to scrape"},
                        "fields": {
                            "type": "array",
                            "items": {
                                "type": "object",
                                "properties": {
                                    "name": {"type": "string"},
                                    "type": {
                                        "type": "string",
                                        "enum": ["str", "int", "float", "bool"],
                                    },
                                    "description": {"type": "string"},
                                },
                                "required": ["name", "type"],
                            },
                            "description": "Schema fields to extract",
                        },
                        "multiple": {
                            "type": "boolean",
                            "default": False,
                            "description": "Whether to extract a list of items",
                        },
                    },
                    "required": ["url", "fields"],
                },
            },
            {
                "name": "scrape_multiple_urls",
                "description": "Extract structured data from multiple URLs in parallel.",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "urls": {
                            "type": "array",
                            "items": {"type": "string"},
                            "description": "URLs to scrape",
                        },
                        "fields": {
                            "type": "array",
                            "items": {
                                "type": "object",
                                "properties": {
                                    "name": {"type": "string"},
                                    "type": {
                                        "type": "string",
                                        "enum": ["str", "int", "float", "bool"],
                                    },
                                },
                                "required": ["name", "type"],
                            },
                        },
                        "concurrency": {"type": "integer", "default": 5},
                    },
                    "required": ["urls", "fields"],
                },
            },
            {
                "name": "agent_scrape",
                "description": (
                    "Run an autonomous scraping agent that"
                    " navigates, clicks, and extracts data"
                    " across multiple pages to accomplish"
                    " a task."
                ),
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "task": {
                            "type": "string",
                            "description": "Natural language description of what to scrape",
                        },
                        "fields": {
                            "type": "array",
                            "items": {
                                "type": "object",
                                "properties": {
                                    "name": {"type": "string"},
                                    "type": {
                                        "type": "string",
                                        "enum": ["str", "int", "float", "bool"],
                                    },
                                },
                                "required": ["name", "type"],
                            },
                        },
                        "max_steps": {"type": "integer", "default": 20},
                    },
                    "required": ["task", "fields"],
                },
            },
        ],
    }


def _build_dynamic_schema(fields: list[dict[str, str]]) -> type:
    """Build a Pydantic model dynamically from field definitions."""
    from pydantic import create_model

    type_map: dict[str, Any] = {
        "str": (str, ...),
        "int": (int, ...),
        "float": (float, ...),
        "bool": (bool, ...),
    }

    field_definitions: dict[str, Any] = {}
    for field in fields:
        field_definitions[field["name"]] = type_map.get(field["type"], (str, ...))

    return create_model("DynamicSchema", **field_definitions)  # type: ignore[no-any-return]


async def handle_tool_call(tool_name: str, arguments: dict[str, Any]) -> str:
    """Handle an MCP tool call and return the result as JSON string."""
    from scrapurrr import Scrapurrr

    async with Scrapurrr() as scraper:
        if tool_name == "scrape_url":
            schema = _build_dynamic_schema(arguments["fields"])
            if arguments.get("multiple", False):
                schema = list[schema]  # type: ignore[valid-type]
            result: Any = await scraper.extract(arguments["url"], schema=schema)
            if isinstance(result, list):
                return json.dumps([r.model_dump() for r in result], indent=2)
            return json.dumps(result.model_dump(), indent=2)

        elif tool_name == "scrape_multiple_urls":
            schema = _build_dynamic_schema(arguments["fields"])
            results: list[Any] = await scraper.extract_many(
                arguments["urls"],
                schema=schema,
                concurrency=arguments.get("concurrency", 5),
            )
            return json.dumps([r.model_dump() for r in results], indent=2)

        elif tool_name == "agent_scrape":
            schema = _build_dynamic_schema(arguments["fields"])
            result = await scraper.agent(
                arguments["task"],
                schema=list[schema],  # type: ignore[valid-type]
                max_steps=arguments.get("max_steps", 20),
            )
            if isinstance(result, list):
                return json.dumps([r.model_dump() for r in result], indent=2)
            return json.dumps(result.model_dump(), indent=2)

        else:
            return json.dumps({"error": f"Unknown tool: {tool_name}"})


async def run_stdio_server() -> None:
    """Run the MCP server over stdio (JSON-RPC style)."""
    logger.info("Scrapurrr MCP server starting on stdio")

    reader = asyncio.StreamReader()
    protocol = asyncio.StreamReaderProtocol(reader)
    loop = asyncio.get_event_loop()
    await loop.connect_read_pipe(lambda: protocol, sys.stdin)

    w_transport, w_protocol = await loop.connect_write_pipe(
        asyncio.streams.FlowControlMixin, sys.stdout
    )
    writer = asyncio.StreamWriter(w_transport, w_protocol, reader, loop)

    server_info = create_mcp_server()

    while True:
        try:
            line = await reader.readline()
            if not line:
                break

            request = json.loads(line.decode())
            method = request.get("method", "")
            req_id = request.get("id")

            if method == "initialize":
                response: dict[str, Any] = {
                    "jsonrpc": "2.0",
                    "id": req_id,
                    "result": {
                        "protocolVersion": "2024-11-05",
                        "capabilities": {"tools": {}},
                        "serverInfo": {
                            "name": server_info["name"],
                            "version": server_info["version"],
                        },
                    },
                }
            elif method == "tools/list":
                response = {
                    "jsonrpc": "2.0",
                    "id": req_id,
                    "result": {"tools": server_info["tools"]},
                }
            elif method == "tools/call":
                params = request.get("params", {})
                tool_name = params.get("name", "")
                arguments = params.get("arguments", {})
                try:
                    result_text = await handle_tool_call(tool_name, arguments)
                    response = {
                        "jsonrpc": "2.0",
                        "id": req_id,
                        "result": {"content": [{"type": "text", "text": result_text}]},
                    }
                except Exception as exc:
                    response = {
                        "jsonrpc": "2.0",
                        "id": req_id,
                        "result": {
                            "content": [{"type": "text", "text": f"Error: {exc}"}],
                            "isError": True,
                        },
                    }
            else:
                response = {
                    "jsonrpc": "2.0",
                    "id": req_id,
                    "result": {},
                }

            output = json.dumps(response) + "\n"
            writer.write(output.encode())
            await writer.drain()

        except Exception as exc:
            logger.error("MCP server error: %s", exc)
            break

    logger.info("Scrapurrr MCP server stopped")


def main() -> None:
    """Entry point for the scrapurrr-mcp CLI command."""
    logging.basicConfig(level=logging.INFO, stream=sys.stderr)
    asyncio.run(run_stdio_server())
