"""Auto-pagination detection and extraction."""

from __future__ import annotations

import logging
from urllib.parse import parse_qs, urljoin, urlparse

from bs4 import BeautifulSoup, Tag

logger = logging.getLogger(__name__)


def find_next_page_url(html: str, current_url: str) -> str | None:
    """Detect and return the next page URL from pagination elements."""
    soup = BeautifulSoup(html, "html.parser")

    # Strategy 1: Look for explicit "next" links
    next_selectors = [
        'a[rel="next"]',
        "a.next",
        "a.next-page",
        'a[aria-label*="next" i]',
        'a[aria-label*="Next" i]',
        "li.next a",
        "li.next-page a",
        ".pagination a.next",
    ]

    for sel in next_selectors:
        try:
            tag = soup.select_one(sel)
            if tag and isinstance(tag, Tag):
                href = tag.get("href")
                if href and isinstance(href, str):
                    return _resolve_url(href, current_url)
        except Exception:
            continue

    # Strategy 2: Look for "Next" text in links
    next_texts = {"next", "next page", "next »", "»", "›", ">"}
    for a in soup.find_all("a", href=True):
        text = a.get_text(strip=True).lower()
        if text in next_texts:
            href = a.get("href")
            if href and isinstance(href, str):
                return _resolve_url(href, current_url)

    # Strategy 3: Look for page=N+1 pattern in links
    parsed_current = urlparse(current_url)
    current_params = parse_qs(parsed_current.query)
    current_page = int(current_params.get("page", ["1"])[0])

    for a in soup.find_all("a", href=True):
        href = str(a.get("href"))
        try:
            parsed_link = urlparse(href)
            link_params = parse_qs(parsed_link.query)
            link_page = int(link_params.get("page", ["0"])[0])
            if link_page == current_page + 1:
                return _resolve_url(href, current_url)
        except (ValueError, KeyError):
            continue

    return None


def _resolve_url(href: str, base_url: str) -> str:
    """Resolve a relative URL against the base URL."""
    return urljoin(base_url, href)
