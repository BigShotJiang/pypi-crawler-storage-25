"""Network concerns — rate limiting, CAPTCHA, pagination."""
