"""Per-domain rate limiting."""

from __future__ import annotations

import asyncio
import logging
import time
from collections import defaultdict
from urllib.parse import urlparse

logger = logging.getLogger(__name__)


class RateLimiter:
    """Per-domain rate limiter with configurable delay."""

    def __init__(self, requests_per_second: float = 2.0) -> None:
        self._min_interval = 1.0 / requests_per_second
        self._last_request: dict[str, float] = defaultdict(float)
        self._locks: dict[str, asyncio.Lock] = defaultdict(asyncio.Lock)

    async def wait(self, url: str) -> None:
        domain = urlparse(url).netloc
        async with self._locks[domain]:
            elapsed = time.monotonic() - self._last_request[domain]
            if elapsed < self._min_interval:
                delay = self._min_interval - elapsed
                logger.debug("Rate limiting %s — waiting %.2fs", domain, delay)
                await asyncio.sleep(delay)
            self._last_request[domain] = time.monotonic()
