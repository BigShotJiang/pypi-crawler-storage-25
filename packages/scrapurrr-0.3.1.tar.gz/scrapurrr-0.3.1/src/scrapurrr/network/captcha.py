"""CAPTCHA detection and solving — supports vision LLM, token APIs, and audio."""

from __future__ import annotations

import logging
from typing import Any, Protocol, runtime_checkable

logger = logging.getLogger(__name__)


@runtime_checkable
class CaptchaSolver(Protocol):
    async def solve(self, page: Any, captcha_type: str = "auto") -> bool: ...
    async def detect(self, html: str) -> str | None: ...


class NullCaptchaSolver:
    """Default no-op solver that logs warnings."""

    async def solve(self, page: Any, captcha_type: str = "auto") -> bool:
        logger.warning(
            "CAPTCHA detected but no solver configured. Install a solver via captcha_solver param."
        )
        return False

    async def detect(self, html: str) -> str | None:
        captcha_markers = [
            ("recaptcha", ["g-recaptcha", "recaptcha", "grecaptcha"]),
            ("hcaptcha", ["h-captcha", "hcaptcha"]),
            ("cloudflare", ["cf-turnstile", "challenge-platform"]),
            ("funcaptcha", ["funcaptcha", "arkoselabs"]),
        ]
        html_lower = html.lower()
        for captcha_type, markers in captcha_markers:
            if any(m in html_lower for m in markers):
                logger.info("Detected CAPTCHA type: %s", captcha_type)
                return captcha_type
        return None


class SmartCaptchaSolver:
    """Multi-strategy CAPTCHA solver using vision LLM as primary approach."""

    def __init__(
        self,
        llm_provider: Any = None,
        token_api_key: str | None = None,
        token_api_url: str = "https://api.capsolver.com",
    ) -> None:
        self._llm = llm_provider
        self._token_api_key = token_api_key
        self._token_api_url = token_api_url

    async def detect(self, html: str) -> str | None:
        """Detect CAPTCHA type from HTML content."""
        html_lower = html.lower()

        captcha_signatures: list[tuple[str, list[str]]] = [
            (
                "cloudflare_turnstile",
                ["cf-turnstile", "challenges.cloudflare.com", "challenge-platform"],
            ),
            ("recaptcha_v2", ["g-recaptcha", "recaptcha/api.js", "grecaptcha"]),
            ("recaptcha_v3", ["recaptcha/api.js?render=", "grecaptcha.execute"]),
            ("hcaptcha", ["h-captcha", "hcaptcha.com/1/api.js", "data-hcaptcha"]),
            ("funcaptcha", ["funcaptcha", "arkoselabs.com", "arkose"]),
            ("image_captcha", ["captcha-image", "captcha_image", "img[alt*=captcha"]),
            ("text_captcha", ["captcha-input", "captcha_code", "enter the characters"]),
        ]

        for captcha_type, markers in captcha_signatures:
            if any(marker in html_lower for marker in markers):
                logger.info("Detected CAPTCHA: %s", captcha_type)
                return captcha_type

        return None

    async def solve(self, page: Any, captcha_type: str = "auto") -> bool:
        """Attempt to solve CAPTCHA using available strategies.

        Strategy priority:
        1. Vision LLM (for image/text CAPTCHAs)
        2. Token API (for reCAPTCHA, hCaptcha, Turnstile)
        3. Behavioral approach (for Cloudflare challenges)
        """
        if captcha_type == "auto":
            html = await page.get_html()
            captcha_type = await self.detect(html) or "unknown"

        logger.info("Solving CAPTCHA type: %s", captcha_type)

        # Strategy 1: Cloudflare Turnstile — wait for auto-solve (behavioral)
        if captcha_type == "cloudflare_turnstile":
            return await self._solve_turnstile(page)

        # Strategy 2: Image/text CAPTCHAs — use vision LLM
        if captcha_type in ("image_captcha", "text_captcha") and self._llm:
            return await self._solve_with_vision(page, captcha_type)

        # Strategy 3: reCAPTCHA/hCaptcha — use token API if available
        if captcha_type in ("recaptcha_v2", "recaptcha_v3", "hcaptcha") and self._token_api_key:
            return await self._solve_with_token_api(page, captcha_type)

        logger.warning("No solver strategy available for CAPTCHA type: %s", captcha_type)
        return False

    async def _solve_turnstile(self, page: Any) -> bool:
        """Cloudflare Turnstile often auto-solves with good behavioral signals."""
        import asyncio

        # Wait for Turnstile widget to appear and resolve
        for _ in range(10):
            try:
                # Check if challenge resolved (success callback fired)
                resolved = await page.evaluate("""
					() => {
						const input = document.querySelector('input[name="cf-turnstile-response"]');
						return input && input.value && input.value.length > 0;
					}
				""")
                if resolved:
                    logger.info("Turnstile auto-resolved")
                    return True
            except Exception:
                pass
            await asyncio.sleep(2)

        # Try clicking the checkbox if visible
        try:
            await page.click('iframe[src*="challenges.cloudflare.com"]')
            await asyncio.sleep(3)
            resolved = await page.evaluate("""
				() => {
					const input = document.querySelector('input[name="cf-turnstile-response"]');
					return input && input.value && input.value.length > 0;
				}
			""")
            if resolved:
                logger.info("Turnstile solved via click")
                return True
        except Exception:
            pass

        return False

    async def _solve_with_vision(self, page: Any, captcha_type: str) -> bool:
        """Use vision LLM to solve image or text CAPTCHAs."""
        try:
            # Take screenshot of CAPTCHA area
            screenshot = await page.screenshot()

            # Ask LLM to read the CAPTCHA
            from pydantic import BaseModel

            class CaptchaResult(BaseModel):
                text: str

            result = await self._llm.extract_from_image(
                image=screenshot,
                schema=CaptchaResult,
                system_prompt=(
                    "You are a CAPTCHA reader. Output only the text visible in the CAPTCHA image."
                ),
            )

            # Type the result into the CAPTCHA input
            captcha_selectors = [
                "input[name*=captcha]",
                "input[id*=captcha]",
                "input[class*=captcha]",
                "input[placeholder*=captcha]",
                "input[aria-label*=captcha]",
            ]

            for selector in captcha_selectors:
                try:
                    await page.type_text(selector, result.text)
                    # Try submitting
                    await page.click("button[type=submit], input[type=submit]")
                    import asyncio

                    await asyncio.sleep(2)

                    # Check if CAPTCHA is gone
                    html = await page.get_html()
                    if await self.detect(html) is None:
                        logger.info("Vision LLM solved CAPTCHA: %s", result.text)
                        return True
                except Exception:
                    continue

            return False

        except Exception as exc:
            logger.warning("Vision CAPTCHA solve failed: %s", exc)
            return False

    async def _solve_with_token_api(self, page: Any, captcha_type: str) -> bool:
        """Use token-based API (CapSolver/2Captcha) to solve reCAPTCHA/hCaptcha."""
        try:
            import httpx

            # Get sitekey from page
            html = await page.get_html()
            sitekey = self._extract_sitekey(html, captcha_type)
            if not sitekey:
                logger.warning("Could not find sitekey for %s", captcha_type)
                return False

            current_url = await page.evaluate("() => window.location.href")

            task_type_map = {
                "recaptcha_v2": "ReCaptchaV2TaskProxyLess",
                "recaptcha_v3": "ReCaptchaV3TaskProxyLess",
                "hcaptcha": "HCaptchaTaskProxyLess",
            }

            async with httpx.AsyncClient(timeout=120) as client:
                create_response = await client.post(
                    f"{self._token_api_url}/createTask",
                    json={
                        "clientKey": self._token_api_key,
                        "task": {
                            "type": task_type_map.get(captcha_type, "ReCaptchaV2TaskProxyLess"),
                            "websiteURL": current_url,
                            "websiteKey": sitekey,
                        },
                    },
                )
                task_data = create_response.json()
                task_id = task_data.get("taskId")

                if not task_id:
                    logger.warning("Failed to create CAPTCHA task: %s", task_data)
                    return False

                import asyncio

                for _ in range(60):  # max 60 seconds
                    await asyncio.sleep(2)
                    result_response = await client.post(
                        f"{self._token_api_url}/getTaskResult",
                        json={"clientKey": self._token_api_key, "taskId": task_id},
                    )
                    result_data = result_response.json()

                    if result_data.get("status") == "ready":
                        token = result_data.get("solution", {}).get(
                            "gRecaptchaResponse"
                        ) or result_data.get("solution", {}).get("token")
                        if token:
                            await self._inject_token(page, token, captcha_type)
                            logger.info("Token API solved %s", captcha_type)
                            return True

            return False

        except Exception as exc:
            logger.warning("Token API solve failed: %s", exc)
            return False

    def _extract_sitekey(self, html: str, captcha_type: str) -> str | None:
        """Extract sitekey from HTML."""
        import re

        patterns: dict[str, list[str]] = {
            "recaptcha_v2": [r'data-sitekey="([^"]+)"', r'sitekey["\s:]+["\']([^"\']+)'],
            "recaptcha_v3": [r'grecaptcha\.execute\(["\']([^"\']+)', r'render=([^&"]+)'],
            "hcaptcha": [r'data-sitekey="([^"]+)"', r'sitekey["\s:]+["\']([^"\']+)'],
        }

        for pattern in patterns.get(captcha_type, []):
            match = re.search(pattern, html)
            if match:
                return match.group(1)

        return None

    async def _inject_token(self, page: Any, token: str, captcha_type: str) -> None:
        """Inject solved CAPTCHA token into the page.

        Token comes from a trusted CAPTCHA-solving API — not user-supplied input.
        """
        if captcha_type in ("recaptcha_v2", "recaptcha_v3"):
            # Safe: token is an alphanumeric string from CapSolver/2Captcha API
            safe_token = "".join(c for c in token if c.isalnum() or c in "-_.")
            await page.evaluate(
                """(token) => {
					const textarea = document.getElementById('g-recaptcha-response');
					if (textarea) {
						textarea.textContent = token;
						textarea.value = token;
					}
					if (typeof ___grecaptcha_cfg !== 'undefined') {
						Object.keys(___grecaptcha_cfg.clients).forEach(key => {
							const client = ___grecaptcha_cfg.clients[key];
							if (client.K && client.K.callback) {
								client.K.callback(token);
							}
						});
					}
				}""",
                safe_token,
            )
        elif captcha_type == "hcaptcha":
            safe_token = "".join(c for c in token if c.isalnum() or c in "-_.")
            await page.evaluate(
                """(token) => {
					const textarea = document.querySelector('[name="h-captcha-response"]');
					if (textarea) textarea.value = token;
					const event = new Event('hcaptcha-callback');
					document.dispatchEvent(event);
				}""",
                safe_token,
            )
