"""Agent system — ReAct loop, tools, memory."""
