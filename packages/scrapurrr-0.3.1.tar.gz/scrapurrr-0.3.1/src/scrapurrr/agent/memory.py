"""Short-term memory for agent runs."""

from __future__ import annotations

from collections import Counter
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from pydantic import BaseModel


@dataclass(frozen=True)
class AgentAction:
    tool: str
    params: dict[str, Any]
    result: str


class AgentMemory:
    def __init__(self, goal: str, schema: type[BaseModel]) -> None:
        self.goal = goal
        self.schema = schema
        self.visited_urls: list[str] = []
        self.extracted_data: list[BaseModel] = []
        self.action_history: list[AgentAction] = []
        self.current_url: str | None = None
        self.current_page_summary: str | None = None
        self.step_count: int = 0
        self._extraction_count_at_step: dict[int, int] = {}

    def record_action(self, action: AgentAction) -> None:
        self.action_history.append(action)
        self.step_count += 1
        self._extraction_count_at_step[self.step_count] = len(self.extracted_data)

    def record_visit(self, url: str) -> None:
        self.visited_urls.append(url)
        self.current_url = url

    def record_extraction(self, data: BaseModel) -> None:
        self.extracted_data.append(data)

    def is_visited(self, url: str) -> bool:
        return url in self.visited_urls

    def is_stuck(self) -> bool:
        if self._url_visited_too_many_times():
            return True
        if self._repeated_consecutive_actions():
            return True
        return bool(self._no_progress_in_recent_steps())

    def recent_actions(self, limit: int = 10) -> list[AgentAction]:
        return self.action_history[-limit:]

    def _url_visited_too_many_times(self) -> bool:
        counts = Counter(self.visited_urls)
        return any(count >= 3 for count in counts.values())

    def _repeated_consecutive_actions(self) -> bool:
        if len(self.action_history) < 2:
            return False
        last = self.action_history[-1]
        prev = self.action_history[-2]
        return last.tool == prev.tool and last.params == prev.params

    def _no_progress_in_recent_steps(self) -> bool:
        if self.step_count < 5:
            return False
        current_extractions = len(self.extracted_data)
        step_5_ago = self.step_count - 4
        extractions_then = self._extraction_count_at_step.get(step_5_ago, 0)
        return current_extractions == extractions_then

    def compact_history(self, keep_recent: int = 5) -> str:
        """Summarize old actions, keep recent ones intact.

        Returns summary string of compacted actions.
        """
        if len(self.action_history) <= keep_recent:
            return ""

        old_actions = self.action_history[:-keep_recent]
        summary_parts = []

        # Group by URL visits
        urls_visited = []
        tools_used: dict[str, int] = {}
        for action in old_actions:
            if action.tool == "navigate":
                url = action.params.get("url", "unknown")
                urls_visited.append(url)
            tools_used[action.tool] = tools_used.get(action.tool, 0) + 1

        if urls_visited:
            summary_parts.append(f"Visited: {', '.join(urls_visited[-5:])}")

        tool_summary = ", ".join(f"{k}x{v}" for k, v in tools_used.items())
        summary_parts.append(f"Actions: {tool_summary}")

        return " | ".join(summary_parts)

    # ------------------------------------------------------------------
    # Serialization for checkpointing
    # ------------------------------------------------------------------

    def to_dict(self) -> dict[str, Any]:
        return {
            "goal": self.goal,
            "visited_urls": self.visited_urls,
            "extracted_data": [d.model_dump() for d in self.extracted_data],
            "step_count": self.step_count,
            "current_url": self.current_url,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any], schema: type[BaseModel]) -> AgentMemory:
        memory = cls(goal=data["goal"], schema=schema)
        memory.visited_urls = data.get("visited_urls", [])
        memory.step_count = data.get("step_count", 0)
        memory.current_url = data.get("current_url")
        for item_data in data.get("extracted_data", []):
            memory.extracted_data.append(schema.model_validate(item_data))
        return memory
