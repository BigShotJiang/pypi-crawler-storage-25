"""ReAct agent loop — Think, Act, Observe."""

from __future__ import annotations

import asyncio
import json
import logging
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, TypeVar, cast, get_args

from pydantic import BaseModel

from scrapurrr.agent.memory import AgentAction, AgentMemory
from scrapurrr.core.exceptions import AgentError, MaxStepsError, StuckError
from scrapurrr.core.schemas import SchemaHelper

if TYPE_CHECKING:
    from collections.abc import AsyncIterator

    from scrapurrr.agent.tools import ToolRegistry
    from scrapurrr.core.types import LLMProvider

logger = logging.getLogger(__name__)

T = TypeVar("T", bound=BaseModel)


@dataclass(frozen=True)
class AgentStep:
    number: int
    tool: str
    params: dict[str, Any]
    result: str
    extracted_count: int


_SYSTEM_PROMPT = """\
You are an expert web scraping agent. You navigate websites to find and extract specific data.

## Available Tools
{tools}

## How to Respond
Respond with JSON: {{"tool": "<name>", "params": {{...}}}}
To finish: {{"tool": "done", "params": {{}}}}

## Strategy
1. Start by reading the page (read_page) to understand its structure
2. Look for the data you need — if visible, extract it
3. If data is on another page, find links (list_links) and navigate
4. Use click/type/select for interactive elements (forms, filters, pagination)
5. Dismiss cookie dialogs if they block content
6. Scroll if content might be below the fold or lazy-loaded

## Rules
- One tool per step
- Never visit the same URL more than twice
- If extraction returns useful JSON, stop and report done
- If stuck, try a different approach (different link, search, scroll)
- Be efficient — minimize unnecessary navigation
"""

_USER_PROMPT = """\
## Goal
{goal}

## Target Schema
{schema}

## Current State
- URL: {current_url}
- Data extracted: {extracted_count} items
- Steps taken: {step_count}/{max_steps}

## Page Summary (simplified DOM)
{dom_summary}

## Data Collected
{extracted_data}

## Recent Actions
{recent_actions}

Choose your next action. Respond with JSON only.
"""


class AgentLoop:
    def __init__(
        self,
        provider: LLMProvider,
        tools: ToolRegistry,
        schema: type[T],
        max_steps: int = 20,
    ) -> None:
        self._provider = provider
        self._tools = tools
        self._schema = schema
        self._max_steps = max_steps

    async def run(self, goal: str, timeout: int | None = None) -> T:
        async def _run_loop(goal: str) -> T:
            memory = AgentMemory(goal=goal, schema=self._schema)
            system = _SYSTEM_PROMPT.format(tools=self._tools.describe_tools())

            for _ in range(self._max_steps):
                if memory.step_count >= 3 and memory.is_stuck():
                    raise StuckError(
                        f"Agent is stuck after {memory.step_count} steps. "
                        f"History: {[a.tool for a in memory.recent_actions()]}"
                    )

                # THINK — use context compaction for long runs
                if memory.step_count > 10:
                    history_summary = memory.compact_history(keep_recent=5)
                    recent_actions = _serialize_actions(memory.recent_actions(limit=5))
                    actions_text = f"Earlier: {history_summary}\nRecent: {recent_actions}"
                else:
                    actions_text = _serialize_actions(memory.recent_actions(limit=10))

                user_prompt = _USER_PROMPT.format(
                    goal=goal,
                    schema=json.dumps(SchemaHelper.to_json_schema(self._schema), indent=2),
                    extracted_data=_serialize_extractions(memory.extracted_data),
                    current_url=memory.current_url or "none",
                    extracted_count=len(memory.extracted_data),
                    step_count=memory.step_count,
                    max_steps=self._max_steps,
                    dom_summary=memory.current_page_summary or "Navigate to a page first.",
                    recent_actions=actions_text,
                )

                response = await self._provider.complete(user_prompt, system_prompt=system)

                # Parse tool call
                try:
                    parsed = json.loads(response)
                    tool_name = parsed["tool"]
                    tool_params = parsed.get("params", {})
                except (json.JSONDecodeError, KeyError):
                    logger.warning("Agent parse error: %s", response[:100])
                    memory.record_action(
                        AgentAction(
                            tool="parse_error",
                            params={},
                            result=f"Could not parse: {response[:200]}",
                        )
                    )
                    continue

                logger.info("Agent step %d: tool=%s", memory.step_count + 1, tool_name)

                # DONE check
                if tool_name == "done":
                    if memory.extracted_data:
                        return cast("T", self._finalize(memory))
                    memory.record_action(
                        AgentAction(tool="done", params={}, result="No data extracted yet")
                    )
                    continue

                # ACT — with intelligent error recovery
                try:
                    result = await self._tools.execute(tool_name, tool_params)
                except KeyError:
                    avail = ", ".join(self._tools.tool_names())
                    result = f"Error: Unknown tool '{tool_name}'. Available: {avail}"
                except Exception as exc:
                    error_msg = str(exc)
                    if "timeout" in error_msg.lower():
                        result = (
                            "Error: Page timed out. Try waiting or navigating to a simpler page."
                        )
                    elif "selector" in error_msg.lower() or "not found" in error_msg.lower():
                        result = (
                            "Error: Element not found. Try read_page"
                            " to see current page content, then use"
                            " a different selector."
                        )
                    else:
                        result = f"Error: {error_msg}. Consider trying a different approach."

                # OBSERVE
                action = AgentAction(tool=tool_name, params=tool_params, result=str(result)[:500])
                memory.record_action(action)

                if tool_name == "navigate":
                    url = tool_params.get("url", "")
                    memory.record_visit(url)

                if tool_name == "extract":
                    self._try_parse_extraction(result, memory)
                    logger.debug("Agent extracted data: %d items", len(memory.extracted_data))

            raise MaxStepsError(f"Agent did not complete within {self._max_steps} steps")

        if timeout:
            try:
                async with asyncio.timeout(timeout):
                    return await _run_loop(goal)
            except TimeoutError:
                raise AgentError(f"Agent timed out after {timeout} seconds") from None
        return await _run_loop(goal)

    async def run_stream(
        self, goal: str, timeout: int | None = None
    ) -> AsyncIterator[AgentStep | T]:
        """Yield AgentStep for each action; final yield is the extracted result."""

        async def _stream_loop() -> AsyncIterator[AgentStep | T]:
            memory = AgentMemory(goal=goal, schema=self._schema)
            system = _SYSTEM_PROMPT.format(tools=self._tools.describe_tools())

            for _ in range(self._max_steps):
                if memory.step_count >= 3 and memory.is_stuck():
                    raise StuckError(
                        f"Agent is stuck after {memory.step_count} steps. "
                        f"History: {[a.tool for a in memory.recent_actions()]}"
                    )

                # THINK — use context compaction for long runs
                if memory.step_count > 10:
                    history_summary = memory.compact_history(keep_recent=5)
                    recent_actions = _serialize_actions(memory.recent_actions(limit=5))
                    actions_text = f"Earlier: {history_summary}\nRecent: {recent_actions}"
                else:
                    actions_text = _serialize_actions(memory.recent_actions(limit=10))

                user_prompt = _USER_PROMPT.format(
                    goal=goal,
                    schema=json.dumps(SchemaHelper.to_json_schema(self._schema), indent=2),
                    extracted_data=_serialize_extractions(memory.extracted_data),
                    current_url=memory.current_url or "none",
                    extracted_count=len(memory.extracted_data),
                    step_count=memory.step_count,
                    max_steps=self._max_steps,
                    dom_summary=memory.current_page_summary or "Navigate to a page first.",
                    recent_actions=actions_text,
                )

                response = await self._provider.complete(user_prompt, system_prompt=system)

                try:
                    parsed = json.loads(response)
                    tool_name = parsed["tool"]
                    tool_params = parsed.get("params", {})
                except (json.JSONDecodeError, KeyError):
                    logger.warning("Agent parse error: %s", response[:100])
                    memory.record_action(
                        AgentAction(
                            tool="parse_error",
                            params={},
                            result=f"Could not parse: {response[:200]}",
                        )
                    )
                    continue

                logger.info("Agent step %d: tool=%s", memory.step_count + 1, tool_name)

                if tool_name == "done":
                    if memory.extracted_data:
                        result = cast("T", self._finalize(memory))
                        yield result
                        return
                    memory.record_action(
                        AgentAction(tool="done", params={}, result="No data extracted yet")
                    )
                    continue

                # ACT — with intelligent error recovery
                try:
                    result_str = await self._tools.execute(tool_name, tool_params)
                except KeyError:
                    avail = ", ".join(self._tools.tool_names())
                    result_str = f"Error: Unknown tool '{tool_name}'. Available: {avail}"
                except Exception as exc:
                    error_msg = str(exc)
                    if "timeout" in error_msg.lower():
                        result_str = (
                            "Error: Page timed out. Try waiting or navigating to a simpler page."
                        )
                    elif "selector" in error_msg.lower() or "not found" in error_msg.lower():
                        result_str = (
                            "Error: Element not found. Try read_page"
                            " to see current page content, then use"
                            " a different selector."
                        )
                    else:
                        result_str = f"Error: {error_msg}. Consider trying a different approach."

                action = AgentAction(
                    tool=tool_name, params=tool_params, result=str(result_str)[:500]
                )
                memory.record_action(action)

                if tool_name == "navigate":
                    url = tool_params.get("url", "")
                    memory.record_visit(url)

                if tool_name == "extract":
                    self._try_parse_extraction(result_str, memory)

                yield AgentStep(
                    number=memory.step_count,
                    tool=tool_name,
                    params=tool_params,
                    result=str(result_str)[:500],
                    extracted_count=len(memory.extracted_data),
                )

            raise MaxStepsError(f"Agent did not complete within {self._max_steps} steps")

        if timeout:
            # Wrap streaming with timeout by consuming and re-yielding
            queue: asyncio.Queue[AgentStep | T | Exception] = asyncio.Queue()

            async def _fill_queue() -> None:
                try:
                    async for item in _stream_loop():
                        await queue.put(item)
                    await queue.put(StopAsyncIteration())
                except Exception as exc:
                    await queue.put(exc)

            task = asyncio.create_task(_fill_queue())
            deadline = asyncio.get_event_loop().time() + timeout
            try:
                while True:
                    remaining = deadline - asyncio.get_event_loop().time()
                    if remaining <= 0:
                        task.cancel()
                        raise AgentError(f"Agent timed out after {timeout} seconds")
                    item = await asyncio.wait_for(queue.get(), timeout=remaining)
                    if isinstance(item, StopAsyncIteration):
                        return
                    if isinstance(item, Exception):
                        raise item
                    yield item
            except TimeoutError:
                task.cancel()
                raise AgentError(f"Agent timed out after {timeout} seconds") from None
        else:
            async for item in _stream_loop():
                yield item

    def _finalize(self, memory: AgentMemory) -> BaseModel:
        if len(memory.extracted_data) == 1:
            return memory.extracted_data[0]

        if SchemaHelper.is_list_type(self._schema):
            return cast(
                "BaseModel",
                SchemaHelper.validate(
                    [d.model_dump() for d in memory.extracted_data],
                    self._schema,
                ),
            )

        return memory.extracted_data[-1]

    def _try_parse_extraction(self, result: str, memory: AgentMemory) -> None:
        try:
            parsed = json.loads(result)
            inner = self._get_inner_schema()
            if isinstance(parsed, list):
                for item in parsed:
                    validated = inner.model_validate(item)
                    memory.record_extraction(validated)
            else:
                validated = inner.model_validate(parsed)
                memory.record_extraction(validated)
        except Exception as exc:
            logger.warning("Extraction parse failed: %s", exc)

    def _get_inner_schema(self) -> type[BaseModel]:
        if SchemaHelper.is_list_type(self._schema):
            return cast("type[BaseModel]", get_args(self._schema)[0])
        return cast("type[BaseModel]", self._schema)


def _serialize_extractions(data: list[BaseModel]) -> str:
    if not data:
        return "none"
    return json.dumps([d.model_dump() for d in data[:10]])


def _serialize_actions(actions: list[AgentAction]) -> str:
    if not actions:
        return "none"
    return json.dumps([{"tool": a.tool, "params": a.params} for a in actions])
