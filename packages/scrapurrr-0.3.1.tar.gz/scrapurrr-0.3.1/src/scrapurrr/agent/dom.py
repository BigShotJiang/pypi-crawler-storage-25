"""DOM simplification — compress HTML into LLM-friendly representation."""

from __future__ import annotations

import logging
from typing import Any

from bs4 import BeautifulSoup, Tag

logger = logging.getLogger(__name__)

# Interactive element tags
_INTERACTIVE_TAGS = {"a", "button", "input", "select", "textarea", "label", "form"}
# Semantic content tags
_CONTENT_TAGS = {
    "h1",
    "h2",
    "h3",
    "h4",
    "h5",
    "h6",
    "p",
    "li",
    "td",
    "th",
    "span",
    "article",
    "main",
}
# Skip entirely
_SKIP_TAGS = {"script", "style", "noscript", "svg", "path", "meta", "link", "head"}


def simplify_dom(html: str, max_elements: int = 200) -> str:
    """Compress HTML into compact representation for LLM consumption.

    Inspired by Browser-Use's DOM processing:
    - Extract interactive elements (links, buttons, inputs, forms)
    - Extract semantic content (headings, paragraphs, list items)
    - Assign numeric indices for reference
    - Strip all styling, scripts, and non-essential attributes
    - Target ~200 elements (from ~10,000 typical DOM nodes)

    Returns compact text representation with indexed elements.
    """
    soup = BeautifulSoup(html, "html.parser")

    # Remove noise
    for tag_name in _SKIP_TAGS:
        for tag in soup.find_all(tag_name):
            tag.decompose()

    elements: list[dict[str, Any]] = []
    index = 0

    for tag in soup.find_all(True):
        if not isinstance(tag, Tag):
            continue
        if index >= max_elements:
            break

        tag_name = tag.name

        # Interactive elements — always include
        if tag_name in _INTERACTIVE_TAGS:
            elem = _extract_interactive(tag, index)
            if elem:
                elements.append(elem)
                index += 1
            continue

        # Content elements — include if they have meaningful text
        if tag_name in _CONTENT_TAGS:
            text = tag.get_text(strip=True)
            if text and len(text) > 3:
                elements.append(
                    {
                        "index": index,
                        "tag": tag_name,
                        "text": text[:200],  # truncate long content
                    }
                )
                index += 1

    # Format as compact text
    return _format_elements(elements)


def _extract_interactive(tag: Tag, index: int) -> dict[str, Any] | None:
    """Extract key attributes from interactive elements."""
    tag_name = tag.name
    text = tag.get_text(strip=True)[:100]

    attrs: dict[str, str] = {}

    if tag_name == "a":
        href = tag.get("href")
        if href:
            attrs["href"] = str(href)[:200]
        if not text and not href:
            return None

    elif tag_name in ("input", "textarea"):
        input_type = tag.get("type", "text")
        attrs["type"] = str(input_type)
        name = tag.get("name") or tag.get("id") or tag.get("placeholder")
        if name:
            attrs["name"] = str(name)[:50]
        value = tag.get("value")
        if value:
            attrs["value"] = str(value)[:50]

    elif tag_name == "button":
        if not text:
            label = tag.get("aria-label", "") or tag.get("title", "")
            text = str(label)[:100]

    elif tag_name == "select":
        name = tag.get("name") or tag.get("id")
        if name:
            attrs["name"] = str(name)[:50]
        # Include first few options
        options = tag.find_all("option", limit=5)
        if options:
            attrs["options"] = ", ".join(o.get_text(strip=True)[:30] for o in options)

    return {
        "index": index,
        "tag": tag_name,
        "text": text,
        **attrs,
    }


def _format_elements(elements: list[dict[str, Any]]) -> str:
    """Format elements into compact text for LLM."""
    lines: list[str] = []

    for elem in elements:
        index = elem["index"]
        tag = elem["tag"]
        text = elem.get("text", "")

        # Compact format: [index] tag: text {attrs}
        parts = [f"[{index}] <{tag}>"]

        if text:
            parts.append(text)

        # Add key attributes
        for key in ("href", "type", "name", "value", "options"):
            if key in elem:
                parts.append(f'{key}="{elem[key]}"')

        lines.append(" ".join(parts))

    return "\n".join(lines)
