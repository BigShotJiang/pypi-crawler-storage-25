"""Tool registry and tool dataclass for the agent system."""

from __future__ import annotations

import json
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from collections.abc import Awaitable, Callable

    from pydantic import BaseModel


@dataclass(frozen=True)
class Tool:
    name: str
    description: str
    parameters: type[BaseModel]
    execute: Callable[..., Awaitable[str]]


class ToolRegistry:
    def __init__(self) -> None:
        self._tools: dict[str, Tool] = {}

    def register(self, tool: Tool) -> None:
        if tool.name in self._tools:
            raise ValueError(f"Tool '{tool.name}' is already registered")
        self._tools[tool.name] = tool

    def get(self, name: str) -> Tool:
        if name not in self._tools:
            raise KeyError(f"Tool '{name}' not found")
        return self._tools[name]

    def tool_names(self) -> list[str]:
        return list(self._tools.keys())

    def describe_tools(self) -> str:
        lines: list[str] = []
        for tool in self._tools.values():
            schema = tool.parameters.model_json_schema()
            lines.append(
                f"- **{tool.name}**: {tool.description}\n"
                f"  Parameters: {json.dumps(schema, indent=2)}"
            )
        return "\n\n".join(lines)

    async def execute(self, name: str, params: dict[str, Any]) -> str:
        tool = self.get(name)
        validated = tool.parameters.model_validate(params)
        return await tool.execute(validated)
