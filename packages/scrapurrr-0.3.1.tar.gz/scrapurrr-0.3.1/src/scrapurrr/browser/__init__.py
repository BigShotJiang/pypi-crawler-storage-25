"""Browser engine abstraction."""

from scrapurrr.core.types import BrowserEngine, PageContext

__all__ = ["BrowserEngine", "PageContext"]
