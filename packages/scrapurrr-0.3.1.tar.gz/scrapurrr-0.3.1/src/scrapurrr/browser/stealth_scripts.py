"""JavaScript stealth scripts injected before page load."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from scrapurrr.browser.fingerprint import BrowserFingerprint


def generate_stealth_scripts(fp: BrowserFingerprint) -> list[str]:
    """Generate all stealth scripts for a fingerprint profile."""
    return [
        _navigator_override(fp),
        _webgl_override(fp),
        _canvas_noise(fp),
        _audio_context_noise(),
        _chrome_runtime(),
        _permissions_override(),
        _plugin_spoof(fp),
        _webdriver_delete(),
        _iframe_contentwindow(),
        _media_codecs(),
    ]


def _navigator_override(fp: BrowserFingerprint) -> str:
    return f"""
    Object.defineProperty(navigator, 'platform', {{get: () => '{fp.platform}'}});
    Object.defineProperty(navigator, 'vendor', {{get: () => '{fp.vendor}'}});
    Object.defineProperty(navigator, 'language', {{get: () => '{fp.language}'}});
    Object.defineProperty(navigator, 'languages', {{get: () => {fp.languages}}});
    Object.defineProperty(navigator, 'hardwareConcurrency',
        {{get: () => {fp.hardware_concurrency}}});
    Object.defineProperty(navigator, 'deviceMemory', {{get: () => {fp.device_memory}}});
    """


def _webgl_override(fp: BrowserFingerprint) -> str:
    return f"""
    const getParameterOrig = WebGLRenderingContext.prototype.getParameter;
    WebGLRenderingContext.prototype.getParameter = function(param) {{
        if (param === 37445) return '{fp.webgl_vendor}';
        if (param === 37446) return '{fp.webgl_renderer}';
        return getParameterOrig.call(this, param);
    }};
    const getParameterOrig2 = WebGL2RenderingContext.prototype.getParameter;
    WebGL2RenderingContext.prototype.getParameter = function(param) {{
        if (param === 37445) return '{fp.webgl_vendor}';
        if (param === 37446) return '{fp.webgl_renderer}';
        return getParameterOrig2.call(this, param);
    }};
    """


def _canvas_noise(fp: BrowserFingerprint) -> str:
    return f"""
    const origToDataURL = HTMLCanvasElement.prototype.toDataURL;
    HTMLCanvasElement.prototype.toDataURL = function(type) {{
        const ctx = this.getContext('2d');
        if (ctx) {{
            const imageData = ctx.getImageData(0, 0, this.width, this.height);
            const data = imageData.data;
            // Deterministic noise based on seed
            let seed = {fp.canvas_noise_seed};
            for (let i = 0; i < data.length; i += 4) {{
                seed = (seed * 16807 + 0) % 2147483647;
                data[i] = data[i] + ((seed % 3) - 1);  // +/- 1 to RGB
            }}
            ctx.putImageData(imageData, 0, 0);
        }}
        return origToDataURL.call(this, type);
    }};
    """


def _audio_context_noise() -> str:
    return """
    const origGetChannelData = AudioBuffer.prototype.getChannelData;
    AudioBuffer.prototype.getChannelData = function(channel) {
        const data = origGetChannelData.call(this, channel);
        // Add imperceptible noise to audio fingerprint
        for (let i = 0; i < data.length; i += 100) {
            data[i] = data[i] + (Math.random() * 0.0001 - 0.00005);
        }
        return data;
    };
    """


def _chrome_runtime() -> str:
    return """
    // Chrome runtime mock (detected by some anti-bots)
    if (!window.chrome) {
        window.chrome = {};
    }
    if (!window.chrome.runtime) {
        window.chrome.runtime = {
            connect: function() {},
            sendMessage: function() {},
        };
    }
    """


def _permissions_override() -> str:
    return """
    const origQuery = window.Permissions.prototype.query;
    window.Permissions.prototype.query = function(params) {
        if (params.name === 'notifications') {
            return Promise.resolve({state: Notification.permission});
        }
        return origQuery.call(this, params);
    };
    """


def _plugin_spoof(fp: BrowserFingerprint) -> str:
    if "Chrome" in fp.user_agent:
        return """
        Object.defineProperty(navigator, 'plugins', {
            get: () => {
                const plugins = [
                    {name: 'Chrome PDF Plugin', filename: 'internal-pdf-viewer'},
                    {name: 'Chrome PDF Viewer', filename: 'mhjfbmdgcfjbbpaeojofohoefgiehjai'},
                    {name: 'Native Client', filename: 'internal-nacl-plugin'},
                ];
                plugins.length = 3;
                return plugins;
            }
        });
        """
    return ""


def _webdriver_delete() -> str:
    return """
    // Delete webdriver property before any script can check it
    Object.defineProperty(navigator, 'webdriver', {
        get: () => undefined,
        configurable: true,
    });
    // Also patch the prototype
    delete Object.getPrototypeOf(navigator).webdriver;
    """


def _iframe_contentwindow() -> str:
    return """
    // Ensure iframe contentWindow matches parent
    const origContentWindow = Object.getOwnPropertyDescriptor(
        HTMLIFrameElement.prototype, 'contentWindow');
    if (origContentWindow) {
        Object.defineProperty(HTMLIFrameElement.prototype, 'contentWindow', {
            get: function() {
                const win = origContentWindow.get.call(this);
                if (win) {
                    try {
                        // Ensure child frame also has patched navigator
                        Object.defineProperty(win.navigator, 'webdriver', {
                            get: () => undefined,
                            configurable: true,
                        });
                    } catch(e) {}
                }
                return win;
            }
        });
    }
    """


def _media_codecs() -> str:
    return """
    // Ensure MediaSource codecs appear normal
    if (window.MediaSource) {
        const origIsTypeSupported = MediaSource.isTypeSupported;
        MediaSource.isTypeSupported = function(type) {
            // Return true for common codecs
            if (type.includes('avc1') || type.includes('mp4a') || type.includes('vp9')) {
                return true;
            }
            return origIsTypeSupported.call(this, type);
        };
    }
    """
