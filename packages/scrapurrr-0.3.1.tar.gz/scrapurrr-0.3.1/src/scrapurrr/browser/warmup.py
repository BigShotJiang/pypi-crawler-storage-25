"""Session warm-up — simulate organic browsing before scraping."""

from __future__ import annotations

import asyncio
import contextlib
import logging
import random
from typing import Any

logger = logging.getLogger(__name__)

# Common sites for warm-up (low risk, fast loading)
_WARMUP_URLS = [
    "https://www.google.com",
    "https://www.wikipedia.org",
    "https://www.github.com",
    "https://news.ycombinator.com",
]


async def warm_up_session(
    page: Any,
    target_domain: str,
    steps: int = 3,
) -> None:
    """Simulate organic browsing before accessing target site.

    Builds a referrer chain and establishes cookies/session state
    that makes the browser look like a real user.

    Steps:
    1. Visit a search engine or popular site
    2. Browse 1-2 intermediate pages with natural delays
    3. Navigate to target domain naturally
    """
    logger.info("Warming up session for %s (%d steps)", target_domain, steps)

    visited = 0

    # Step 1: Visit a warm-up site
    if visited < steps:
        url = random.choice(_WARMUP_URLS)
        try:
            await page.navigate(url)
            await _simulate_reading(page)
            visited += 1
            logger.debug("Warm-up step %d: visited %s", visited, url)
        except Exception as exc:
            logger.debug("Warm-up navigation failed (non-critical): %s", exc)

    # Step 2: Scroll and interact naturally
    if visited < steps:
        try:
            await page.scroll("down")
            await asyncio.sleep(random.uniform(1.5, 4.0))
            await page.scroll("down")
            await asyncio.sleep(random.uniform(1.0, 3.0))
            visited += 1
            logger.debug("Warm-up step %d: scrolled and read", visited)
        except Exception:
            pass

    # Step 3: Navigate toward target via search (builds referrer chain)
    if visited < steps:
        try:
            search_url = f"https://www.google.com/search?q={target_domain}"
            await page.navigate(search_url)
            await asyncio.sleep(random.uniform(2.0, 5.0))
            visited += 1
            logger.debug("Warm-up step %d: searched for target", visited)
        except Exception:
            pass

    logger.info("Session warm-up complete (%d steps)", visited)


async def _simulate_reading(page: Any) -> None:
    """Simulate a human reading a page — wait, scroll a bit, wait more."""
    await asyncio.sleep(random.uniform(2.0, 5.0))
    with contextlib.suppress(Exception):
        await page.scroll("down")
    await asyncio.sleep(random.uniform(1.0, 3.0))
