"""Playwright browser engine implementation."""

from __future__ import annotations

import asyncio
import logging
import random
from typing import TYPE_CHECKING, Any, Literal

from patchright.async_api import Browser, BrowserContext, Page, Playwright, async_playwright

logger = logging.getLogger(__name__)

if TYPE_CHECKING:
    from scrapurrr.browser.proxy import ProxyRotator
    from scrapurrr.browser.stealth import StealthManager
    from scrapurrr.core.config import BrowserConfig


class PlaywrightPage:
    def __init__(self, page: Page, stealth: StealthManager) -> None:
        self._page = page
        self._stealth = stealth

    _WaitUntil = Literal["commit", "domcontentloaded", "load", "networkidle"]

    async def navigate(
        self,
        url: str,
        wait_until: _WaitUntil = "domcontentloaded",
        js_pre: str | None = None,
        js_post: str | None = None,
    ) -> None:
        from scrapurrr.human.timing import reaction_time

        logger.debug("Navigating to %s", url)
        await self._stealth.run_before_navigate(self, url)
        await self._stealth.human_delay()

        # Execute pre-navigation JavaScript
        if js_pre:
            logger.debug("Running js_pre script")
            await self._page.evaluate(js_pre)

        await self._page.goto(url, wait_until=wait_until)
        await self._stealth.apply_page_scripts(self._page)
        await self._stealth.run_after_navigate(self, url)

        # Execute post-navigation JavaScript
        if js_post:
            logger.debug("Running js_post script")
            await self._page.evaluate(js_post)

        # Human reaction delay after page load
        await asyncio.sleep(reaction_time())

    async def navigate_with_response(
        self,
        url: str,
        wait_until: _WaitUntil = "domcontentloaded",
    ) -> tuple[int, dict[str, str]]:
        from scrapurrr.human.timing import reaction_time

        logger.debug("Navigating to %s", url)
        await self._stealth.run_before_navigate(self, url)
        await self._stealth.human_delay()
        response = await self._page.goto(url, wait_until=wait_until)
        await self._stealth.apply_page_scripts(self._page)
        await self._stealth.run_after_navigate(self, url)
        await asyncio.sleep(reaction_time())
        if response is None:
            return 0, {}
        return response.status, dict(response.headers)

    async def get_html(self) -> str:
        return await self._page.content()

    async def screenshot(self) -> bytes:
        return await self._page.screenshot()

    async def scroll(self, direction: str = "down") -> None:
        from scrapurrr.human.scroll import generate_scroll_sequence

        events = generate_scroll_sequence(
            total_distance=random.randint(300, 800),
            direction=direction,
        )
        for delta, delay in events:
            if delta != 0:
                await self._page.mouse.wheel(0, delta)
            await asyncio.sleep(delay)

    async def wait_for(self, selector: str, timeout: int = 10000) -> None:
        await self._page.wait_for_selector(selector, timeout=timeout)

    async def evaluate(self, js: str) -> Any:
        return await self._page.evaluate(js)

    async def click(self, selector: str) -> None:
        from scrapurrr.human.mouse import add_overshoot, wind_mouse
        from scrapurrr.human.timing import click_delay, fitts_law_duration

        element = await self._page.query_selector(selector)
        if element is None:
            await self._page.click(selector)
            await self._stealth.human_delay()
            return

        box = await element.bounding_box()
        if box is None:
            await self._page.click(selector)
            await self._stealth.human_delay()
            return

        # Target center with small random offset
        target_x = box["x"] + box["width"] / 2 + random.uniform(-3, 3)
        target_y = box["y"] + box["height"] / 2 + random.uniform(-3, 3)

        # Current mouse position (approximate)
        start_x = random.uniform(0, 1920)
        start_y = random.uniform(0, 1080)

        # Generate human-like path
        path = wind_mouse(start_x, start_y, target_x, target_y)
        path = add_overshoot(path, target_x, target_y)

        # Calculate total movement time via Fitts's Law
        distance = ((target_x - start_x) ** 2 + (target_y - start_y) ** 2) ** 0.5
        total_time = fitts_law_duration(distance, min(box["width"], box["height"]))
        step_delay = total_time / max(len(path), 1)

        # Execute movement
        for point in path:
            await self._page.mouse.move(point.x, point.y)
            await asyncio.sleep(step_delay)

        # Click delay
        await asyncio.sleep(click_delay())
        await self._page.mouse.click(target_x, target_y)
        await self._stealth.human_delay()

    async def type_text(self, selector: str, text: str) -> None:
        from scrapurrr.human.keyboard import generate_keystroke_timings

        # Click the field first (with human-like movement)
        await self.click(selector)

        keystrokes = generate_keystroke_timings(text)
        for char, delay in keystrokes:
            await asyncio.sleep(delay)
            await self._page.keyboard.press(char)

        await self._stealth.human_delay()

    async def select_option(self, selector: str, value: str) -> None:
        await self._page.select_option(selector, value)
        await self._stealth.human_delay()

    async def go_back(self) -> None:
        await self._page.go_back()
        await self._stealth.human_delay()


class PlaywrightEngine:
    def __init__(
        self,
        config: BrowserConfig,
        stealth: StealthManager,
        rotator: ProxyRotator | None = None,
    ) -> None:
        self._config = config
        self._stealth = stealth
        self._rotator = rotator
        self._playwright: Playwright | None = None
        self._browser: Browser | None = None
        self._contexts: list[BrowserContext] = []
        self._session_contexts: dict[str, BrowserContext] = {}

    async def launch(self) -> None:
        from cloakbrowser import ensure_binary, get_default_stealth_args

        binary_path = ensure_binary()

        self._playwright = await async_playwright().start()
        launch_args: dict[str, Any] = {
            "headless": self._config.headless,
            "executable_path": binary_path,
            "args": get_default_stealth_args(),
        }
        if self._config.proxy and isinstance(self._config.proxy, str):
            launch_args["proxy"] = {"server": self._config.proxy}
        self._browser = await self._playwright.chromium.launch(**launch_args)

    async def new_page(self, session_id: str | None = None) -> PlaywrightPage:
        """Create page, reusing context if session_id matches.

        Args:
            session_id: If provided and a context already exists for this
                session, reuse it. Otherwise create a new context.

        Returns:
            A new PlaywrightPage.
        """
        if self._browser is None:
            raise RuntimeError("Browser not launched. Call launch() first.")

        # Reuse existing session context if available
        if session_id and session_id in self._session_contexts:
            context = self._session_contexts[session_id]
            logger.debug("Reusing session context for session_id=%s", session_id)
            page = await context.new_page()
            return PlaywrightPage(page, self._stealth)

        context_args = self._stealth.context_args()
        if self._rotator is not None:
            proxy_url = self._rotator.next()
            context_args["proxy"] = {"server": proxy_url}
            logger.debug("new_page() using rotated proxy: %s", proxy_url)
        context = await self._browser.new_context(**context_args)
        self._contexts.append(context)
        for script in self._stealth.get_init_scripts():
            await context.add_init_script(script)

        # Store context for session reuse
        if session_id:
            self._session_contexts[session_id] = context
            logger.debug("Created new session context for session_id=%s", session_id)

        page = await context.new_page()
        return PlaywrightPage(page, self._stealth)

    async def close(self) -> None:
        self._session_contexts.clear()
        for ctx in self._contexts:
            await ctx.close()
        self._contexts.clear()
        if self._browser:
            await self._browser.close()
            self._browser = None
        if self._playwright:
            await self._playwright.stop()
            self._playwright = None
