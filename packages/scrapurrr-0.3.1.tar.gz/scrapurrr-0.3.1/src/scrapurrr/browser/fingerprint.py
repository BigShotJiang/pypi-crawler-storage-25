"""Browser fingerprint generation — creates consistent, realistic profiles."""

from __future__ import annotations

import logging
import random
from dataclasses import dataclass

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class BrowserFingerprint:
    """A consistent browser fingerprint profile."""

    user_agent: str
    platform: str
    vendor: str
    language: str
    languages: list[str]
    hardware_concurrency: int
    device_memory: int
    screen_width: int
    screen_height: int
    color_depth: int
    pixel_ratio: float
    timezone: str
    webgl_vendor: str
    webgl_renderer: str
    # Canvas noise seed for consistent but unique rendering
    canvas_noise_seed: int


# Real-world browser profiles from traffic analysis
_PROFILES = [
    {
        "ua": (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"
            " AppleWebKit/537.36 (KHTML, like Gecko)"
            " Chrome/131.0.0.0 Safari/537.36"
        ),
        "platform": "Win32",
        "vendor": "Google Inc.",
        "screens": [(1920, 1080), (2560, 1440), (1366, 768), (1536, 864)],
        "cores": [4, 8, 12, 16],
        "memory": [4, 8, 16, 32],
        "webgl_vendors": ["Google Inc. (NVIDIA)", "Google Inc. (AMD)", "Google Inc. (Intel)"],
        "webgl_renderers": [
            "ANGLE (NVIDIA, NVIDIA GeForce RTX 3060 Direct3D11 vs_5_0 ps_5_0, D3D11)",
            "ANGLE (AMD, AMD Radeon RX 580 Direct3D11 vs_5_0 ps_5_0, D3D11)",
            "ANGLE (Intel, Intel(R) UHD Graphics 630 Direct3D11 vs_5_0 ps_5_0, D3D11)",
        ],
    },
    {
        "ua": (
            "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7)"
            " AppleWebKit/537.36 (KHTML, like Gecko)"
            " Chrome/131.0.0.0 Safari/537.36"
        ),
        "platform": "MacIntel",
        "vendor": "Google Inc.",
        "screens": [(2560, 1600), (1920, 1080), (1440, 900), (2560, 1440)],
        "cores": [8, 10, 12],
        "memory": [8, 16, 32],
        "webgl_vendors": ["Google Inc. (Apple)"],
        "webgl_renderers": [
            "ANGLE (Apple, Apple M1, OpenGL 4.1)",
            "ANGLE (Apple, Apple M2, OpenGL 4.1)",
            "ANGLE (Apple, Apple M3 Pro, OpenGL 4.1)",
        ],
    },
    {
        "ua": (
            "Mozilla/5.0 (X11; Linux x86_64)"
            " AppleWebKit/537.36 (KHTML, like Gecko)"
            " Chrome/131.0.0.0 Safari/537.36"
        ),
        "platform": "Linux x86_64",
        "vendor": "Google Inc.",
        "screens": [(1920, 1080), (2560, 1440), (3440, 1440)],
        "cores": [4, 8, 16],
        "memory": [8, 16, 32],
        "webgl_vendors": ["Google Inc. (NVIDIA)", "Google Inc. (AMD)"],
        "webgl_renderers": [
            "ANGLE (NVIDIA, NVIDIA GeForce GTX 1080 Ti, OpenGL 4.5)",
            "ANGLE (AMD, AMD Radeon RX 6700 XT, OpenGL 4.6)",
        ],
    },
    {
        "ua": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:132.0) Gecko/20100101 Firefox/132.0",
        "platform": "Win32",
        "vendor": "",
        "screens": [(1920, 1080), (2560, 1440), (1366, 768)],
        "cores": [4, 8, 12],
        "memory": [4, 8, 16],
        "webgl_vendors": ["NVIDIA Corporation", "ATI Technologies Inc."],
        "webgl_renderers": [
            "NVIDIA GeForce RTX 3070/PCIe/SSE2",
            "AMD Radeon RX 580/PCIe/SSE2",
        ],
    },
]

_TIMEZONES = [
    "America/New_York",
    "America/Chicago",
    "America/Denver",
    "America/Los_Angeles",
    "Europe/London",
    "Europe/Paris",
    "Europe/Berlin",
    "Asia/Tokyo",
    "Asia/Shanghai",
    "Australia/Sydney",
    "America/Toronto",
    "America/Sao_Paulo",
]

_LANGUAGES = [
    ("en-US", ["en-US", "en"]),
    ("en-GB", ["en-GB", "en"]),
    ("fr-FR", ["fr-FR", "fr", "en"]),
    ("de-DE", ["de-DE", "de", "en"]),
    ("ja-JP", ["ja-JP", "ja", "en"]),
    ("es-ES", ["es-ES", "es", "en"]),
]


def generate_fingerprint() -> BrowserFingerprint:
    """Generate a realistic, internally consistent browser fingerprint."""
    profile = random.choice(_PROFILES)
    screens: list[tuple[int, int]] = profile["screens"]  # type: ignore[assignment]
    screen = random.choice(screens)
    lang, langs = random.choice(_LANGUAGES)
    cores: list[int] = profile["cores"]  # type: ignore[assignment]
    memory: list[int] = profile["memory"]  # type: ignore[assignment]
    webgl_vendors: list[str] = profile["webgl_vendors"]  # type: ignore[assignment]
    webgl_renderers: list[str] = profile["webgl_renderers"]  # type: ignore[assignment]

    return BrowserFingerprint(
        user_agent=str(profile["ua"]),
        platform=str(profile["platform"]),
        vendor=str(profile["vendor"]),
        language=lang,
        languages=langs,
        hardware_concurrency=random.choice(cores),
        device_memory=random.choice(memory),
        screen_width=screen[0],
        screen_height=screen[1],
        color_depth=24,
        pixel_ratio=random.choice([1.0, 1.25, 1.5, 2.0]) if screen[0] > 1920 else 1.0,
        timezone=random.choice(_TIMEZONES),
        webgl_vendor=random.choice(webgl_vendors),
        webgl_renderer=random.choice(webgl_renderers),
        canvas_noise_seed=random.randint(1, 2**31),
    )
