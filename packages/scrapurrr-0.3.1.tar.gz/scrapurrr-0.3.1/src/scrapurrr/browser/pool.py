"""Page pool for concurrent browser operations."""

from __future__ import annotations

import asyncio
import logging
from typing import Any

logger = logging.getLogger(__name__)


class PagePool:
    """Pool of browser pages for concurrent operations."""

    def __init__(self, engine: Any, max_pages: int = 5) -> None:
        self._engine = engine
        self._max_pages = max_pages
        self._available: asyncio.Queue[Any] = asyncio.Queue()
        self._created = 0
        self._lock = asyncio.Lock()

    async def acquire(self) -> Any:
        # Try to get an available page first
        if not self._available.empty():
            page = self._available.get_nowait()
            logger.debug("Reusing page from pool (%d available)", self._available.qsize())
            return page

        # Create a new page if under limit
        async with self._lock:
            if self._created < self._max_pages:
                page = await self._engine.new_page()
                self._created += 1
                logger.debug("Created new page (%d/%d)", self._created, self._max_pages)
                return page

        # Wait for an available page
        logger.debug("Pool full, waiting for available page")
        return await self._available.get()

    async def release(self, page: Any) -> None:
        await self._available.put(page)

    @property
    def size(self) -> int:
        return self._created

    @property
    def available(self) -> int:
        return self._available.qsize()
