"""Stealth manager — fingerprint masking, hooks, human-like delays."""

from __future__ import annotations

import random
from typing import TYPE_CHECKING, Any, Literal

from scrapurrr.browser.fingerprint import BrowserFingerprint, generate_fingerprint
from scrapurrr.browser.stealth_scripts import generate_stealth_scripts

if TYPE_CHECKING:
    from scrapurrr.core.types import StealthHook


class StealthManager:
    def __init__(
        self,
        level: Literal["off", "basic", "full"] = "basic",
        hooks: list[StealthHook] | None = None,
    ) -> None:
        self._level = level
        self._hooks: list[StealthHook] = hooks or []
        self._fingerprint: BrowserFingerprint | None = (
            generate_fingerprint() if level in ("basic", "full") else None
        )

    @property
    def fingerprint(self) -> BrowserFingerprint | None:
        return self._fingerprint

    def context_args(self) -> dict[str, Any]:
        if self._level == "off":
            return {}

        fp = self._fingerprint
        assert fp is not None  # guaranteed when level != "off"

        args: dict[str, Any] = {
            "user_agent": fp.user_agent,
            "viewport": {"width": fp.screen_width, "height": fp.screen_height},
            "locale": fp.language,
        }

        if self._level == "full":
            args["extra_http_headers"] = {
                "Accept-Language": (
                    f"{fp.language},{fp.languages[1] if len(fp.languages) > 1 else 'en'};q=0.9"
                ),
                "Accept-Encoding": "gzip, deflate, br",
                "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            }

        return args

    def get_init_scripts(self) -> list[str]:
        """Return JS scripts to inject via add_init_script (runs BEFORE page JS)."""
        if self._level == "off" or self._fingerprint is None:
            return []
        return generate_stealth_scripts(self._fingerprint)

    async def apply_page_scripts(self, page: Any) -> None:
        """Fallback script injection after page load (for scripts needing live DOM)."""
        if self._level == "off":
            return

        # Init scripts already handle webdriver + full fingerprint spoofing.
        # This is a no-op fallback kept for hook compatibility.

    async def run_before_navigate(self, page: Any, url: str) -> None:
        for hook in self._hooks:
            await hook.on_before_navigate(page, url)

    async def run_after_navigate(self, page: Any, url: str) -> None:
        for hook in self._hooks:
            await hook.on_after_navigate(page, url)

    async def human_delay(self) -> None:
        if self._level == "full":
            import asyncio

            delay = random.uniform(0.5, 2.0)
            await asyncio.sleep(delay)
