"""Proxy rotation for browser and HTTP requests."""

from __future__ import annotations

import logging
import random

logger = logging.getLogger(__name__)


class ProxyRotator:
    def __init__(self, proxies: list[str]) -> None:
        self._proxies = proxies
        self._index = 0

    def next(self) -> str:
        if not self._proxies:
            raise ValueError("No proxies configured")
        proxy = self._proxies[self._index % len(self._proxies)]
        self._index += 1
        logger.debug("Using proxy: %s", proxy)
        return proxy

    def random(self) -> str:
        if not self._proxies:
            raise ValueError("No proxies configured")
        return random.choice(self._proxies)

    @property
    def count(self) -> int:
        return len(self._proxies)
