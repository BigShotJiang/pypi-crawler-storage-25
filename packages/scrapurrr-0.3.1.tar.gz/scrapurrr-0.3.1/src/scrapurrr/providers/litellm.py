"""LiteLLM-based provider supporting 100+ LLM backends."""

from __future__ import annotations

import json
import logging
from typing import TYPE_CHECKING, Any, TypeVar, cast

from litellm import acompletion
from pydantic import BaseModel, ValidationError

from scrapurrr.core.exceptions import AuthError, ProviderError, RateLimitError, SchemaError
from scrapurrr.core.schemas import SchemaHelper

if TYPE_CHECKING:
    from collections.abc import AsyncIterator

T = TypeVar("T", bound=BaseModel)

logger = logging.getLogger(__name__)

_VISION_KEYWORDS = ("gpt-4o", "gpt-4-vision", "claude-3", "gemini-1.5", "gemini-2")


class LiteLLMProvider:
    def __init__(self, model: str, api_key: str | None = None, base_url: str | None = None) -> None:
        self._model = model
        self._api_key = api_key
        self._base_url = base_url

    @property
    def supports_vision(self) -> bool:
        return any(kw in self._model for kw in _VISION_KEYWORDS)

    async def extract_structured(
        self,
        content: str,
        schema: type[T],
        system_prompt: str | None = None,
    ) -> T:
        extraction_prompt = SchemaHelper.build_extraction_prompt(schema)
        user_msg = f"{extraction_prompt}\n\nContent:\n{content}"
        last_error: Exception | None = None

        for attempt in range(2):
            raw = await self._call(user_msg, system_prompt)
            try:
                parsed = json.loads(raw)
                return cast("T", SchemaHelper.validate(parsed, schema))
            except (json.JSONDecodeError, ValidationError) as exc:
                last_error = exc
                logger.warning("LLM validation failed (attempt %d): %s", attempt + 1, exc)
                if attempt == 0:
                    user_msg = (
                        f"{extraction_prompt}\n\nContent:\n{content}\n\n"
                        f"Previous attempt failed with error: {exc}\n"
                        "Please fix the output and try again."
                    )

        raise SchemaError(
            f"Failed to extract valid data after 2 attempts: {last_error}"
        ) from last_error

    async def complete(self, prompt: str, system_prompt: str | None = None) -> str:
        return await self._call(prompt, system_prompt)

    async def stream_complete(
        self,
        prompt: str,
        system_prompt: str | None = None,
    ) -> AsyncIterator[str]:
        messages: list[dict[str, str]] = []
        if system_prompt:
            messages.append({"role": "system", "content": system_prompt})
        messages.append({"role": "user", "content": prompt})

        kwargs: dict[str, Any] = {
            "model": self._model,
            "messages": messages,
            "stream": True,
        }
        if self._api_key:
            kwargs["api_key"] = self._api_key
        if self._base_url:
            kwargs["api_base"] = self._base_url

        try:
            response = await acompletion(**kwargs)
        except Exception as exc:
            raise ProviderError(str(exc)) from exc

        async for chunk in response:
            if chunk.choices and chunk.choices[0].delta.content:
                yield chunk.choices[0].delta.content

    async def extract_from_image(
        self,
        image: bytes,
        schema: type[T],
        system_prompt: str | None = None,
    ) -> T:
        import base64

        extraction_prompt = SchemaHelper.build_extraction_prompt(schema)
        b64 = base64.b64encode(image).decode("utf-8")

        messages: list[dict[str, Any]] = []
        if system_prompt:
            messages.append({"role": "system", "content": system_prompt})
        messages.append(
            {
                "role": "user",
                "content": [
                    {"type": "text", "text": extraction_prompt},
                    {"type": "image_url", "image_url": {"url": f"data:image/png;base64,{b64}"}},
                ],
            }
        )

        kwargs: dict[str, Any] = {"model": self._model, "messages": messages}
        if self._api_key:
            kwargs["api_key"] = self._api_key
        if self._base_url:
            kwargs["api_base"] = self._base_url

        try:
            response = await acompletion(**kwargs)
        except Exception as exc:
            raise ProviderError(str(exc)) from exc

        if not response.choices:
            raise ProviderError("Vision: empty choices")
        content = response.choices[0].message.content
        if content is None:
            raise ProviderError("Vision: None content")

        try:
            parsed = json.loads(content)
            return cast("T", SchemaHelper.validate(parsed, schema))
        except Exception as exc:
            raise SchemaError(f"Vision extraction failed: {exc}") from exc

    async def _call(self, user_msg: str, system_prompt: str | None) -> str:
        logger.debug("LLM call: model=%s", self._model)
        messages: list[dict[str, str]] = []
        if system_prompt:
            messages.append({"role": "system", "content": system_prompt})
        messages.append({"role": "user", "content": user_msg})

        kwargs: dict[str, Any] = {"model": self._model, "messages": messages}
        if self._api_key:
            kwargs["api_key"] = self._api_key
        if self._base_url:
            kwargs["api_base"] = self._base_url

        try:
            response = await acompletion(**kwargs)
        except Exception as exc:
            exc_type = type(exc).__name__
            if "RateLimitError" in exc_type or "429" in str(exc):
                raise RateLimitError(str(exc)) from exc
            if "AuthenticationError" in exc_type or "401" in str(exc):
                raise AuthError(str(exc)) from exc
            raise ProviderError(str(exc)) from exc

        if not response.choices:
            raise ProviderError("LLM returned empty choices — possible refusal or content filter")

        content = response.choices[0].message.content
        if content is None:
            raise ProviderError("LLM returned None content — possible tool-use or refusal response")

        logger.debug("LLM response received (%d chars)", len(content))
        return cast("str", content)
