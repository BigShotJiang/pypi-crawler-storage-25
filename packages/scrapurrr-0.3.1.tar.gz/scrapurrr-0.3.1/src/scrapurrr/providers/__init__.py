"""LLM provider abstraction."""

from scrapurrr.core.types import LLMProvider

__all__ = ["LLMProvider"]
