"""Page fetcher — navigates via browser engine and returns raw HTML."""

from __future__ import annotations

import asyncio
import logging

from scrapurrr.core.exceptions import NavigationError
from scrapurrr.core.types import FetchResult, PageContext

logger = logging.getLogger(__name__)


async def fetch(page: PageContext, url: str, max_retries: int = 3) -> FetchResult:
    last_error: Exception | None = None
    for attempt in range(max_retries):
        try:
            logger.debug("Fetching %s", url)
            status, headers = await page.navigate_with_response(url)
            html = await page.get_html()
            logger.debug("Fetched %s — status=%d", url, status)
            if attempt > 0:
                logger.info("Fetch succeeded on retry %d for %s", attempt, url)
            return FetchResult(url=url, html=html, status=status, headers=headers)
        except Exception as exc:
            last_error = exc
            if attempt < max_retries - 1:
                delay = 2**attempt  # 1s, 2s, 4s
                logger.warning(
                    "Fetch failed for %s (attempt %d/%d): %s. Retrying in %ds",
                    url,
                    attempt + 1,
                    max_retries,
                    exc,
                    delay,
                )
                await asyncio.sleep(delay)
    raise NavigationError(
        f"Failed to fetch {url} after {max_retries} attempts: {last_error}"
    ) from last_error
