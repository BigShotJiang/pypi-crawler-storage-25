"""Content filtering — BM25 relevance scoring and pruning."""

from __future__ import annotations

import logging
import math
import re
from collections import Counter

logger = logging.getLogger(__name__)


def bm25_filter(
    text: str,
    query: str,
    threshold: float = 1.0,
) -> str:
    """Filter text blocks by BM25 relevance to a query.

    Splits text into blocks (paragraphs/sections), scores each
    against the query using BM25, and keeps only relevant blocks.

    Parameters:
        text: Full text content (markdown or plain)
        query: Search query for relevance scoring
        threshold: BM25 score threshold (default 1.0, higher = stricter)

    Returns filtered text with only relevant blocks.
    """
    if not query or not text:
        return text

    blocks = _split_into_blocks(text)
    if not blocks:
        return text

    query_terms = _tokenize(query)
    if not query_terms:
        return text

    # Calculate IDF for query terms
    doc_count = len(blocks)
    doc_freq: Counter[str] = Counter()
    block_tokens = [_tokenize(block) for block in blocks]

    for tokens in block_tokens:
        unique_tokens = set(tokens)
        for token in unique_tokens:
            doc_freq[token] += 1

    idf: dict[str, float] = {}
    for term in query_terms:
        df = doc_freq.get(term, 0)
        idf[term] = math.log((doc_count - df + 0.5) / (df + 0.5) + 1)

    # Score each block
    avg_dl = sum(len(tokens) for tokens in block_tokens) / max(doc_count, 1)
    k1 = 1.5
    b = 0.75

    scored_blocks: list[tuple[str, float]] = []
    for block, tokens in zip(blocks, block_tokens, strict=False):
        score = _bm25_score(tokens, query_terms, idf, avg_dl, k1, b)
        scored_blocks.append((block, score))

    # Keep blocks above threshold
    filtered = [block for block, score in scored_blocks if score >= threshold]

    if not filtered:
        # If nothing passes threshold, return top 3 blocks
        scored_blocks.sort(key=lambda x: x[1], reverse=True)
        filtered = [block for block, _ in scored_blocks[:3]]

    removed = len(blocks) - len(filtered)
    if removed > 0:
        logger.debug(
            "BM25 filter: kept %d/%d blocks (threshold=%.2f)", len(filtered), len(blocks), threshold
        )

    return "\n\n".join(filtered)


def prune_content(
    text: str,
    min_text_density: float = 0.3,
    min_words: int = 10,
) -> str:
    """Prune low-quality content blocks.

    Removes blocks with:
    - Low text density (mostly links/boilerplate)
    - Too few words
    - Navigation/menu patterns
    """
    blocks = _split_into_blocks(text)

    kept: list[str] = []
    for block in blocks:
        words = block.split()
        if len(words) < min_words:
            continue

        # Calculate link density (approximate)
        link_count = block.count("[") + block.count("http")
        word_count = len(words)
        link_density = link_count / max(word_count, 1)

        if link_density > (1 - min_text_density):
            continue

        # Skip navigation-like blocks
        nav_patterns = ["skip to", "main menu", "breadcrumb", "copyright", "all rights reserved"]
        if any(pat in block.lower() for pat in nav_patterns):
            continue

        kept.append(block)

    return "\n\n".join(kept)


def _split_into_blocks(text: str) -> list[str]:
    """Split text into blocks by double newlines or headings."""
    blocks = re.split(r"\n\n+|(?=^#{1,3}\s)", text, flags=re.MULTILINE)
    return [b.strip() for b in blocks if b.strip()]


def _tokenize(text: str) -> list[str]:
    """Simple whitespace tokenization with lowercasing."""
    return [w.lower() for w in re.findall(r"\w+", text)]


def _bm25_score(
    doc_tokens: list[str],
    query_terms: list[str],
    idf: dict[str, float],
    avg_dl: float,
    k1: float,
    b: float,
) -> float:
    """Calculate BM25 score for a document against query terms."""
    score = 0.0
    doc_len = len(doc_tokens)
    tf_counter = Counter(doc_tokens)

    for term in query_terms:
        tf = tf_counter.get(term, 0)
        if tf == 0:
            continue

        term_idf = idf.get(term, 0)
        numerator = tf * (k1 + 1)
        denominator = tf + k1 * (1 - b + b * doc_len / max(avg_dl, 1))
        score += term_idf * (numerator / denominator)

    return score
