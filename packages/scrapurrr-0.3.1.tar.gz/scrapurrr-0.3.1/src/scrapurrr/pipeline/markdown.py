"""HTML to markdown conversion optimized for LLM consumption."""

from __future__ import annotations

import re

from markdownify import markdownify


def to_markdown(
    html: str,
    include_links: bool = True,
    include_images: bool = False,
    include_tables: bool = True,
) -> str:
    """Convert HTML to clean markdown with options.

    Args:
            html: Raw HTML string.
            include_links: Keep hyperlinks in output (default True).
            include_images: Keep images in output (default False).
            include_tables: Keep tables in output (default True).

    Returns:
            Cleaned markdown string.
    """
    if not html.strip():
        return ""

    strip_tags: list[str] = []
    if not include_images:
        strip_tags.append("img")
    if not include_tables:
        strip_tags.extend(["table", "thead", "tbody", "tr", "th", "td"])

    md = markdownify(html, heading_style="ATX", strip=strip_tags or None).strip()

    if not include_links:
        # Convert [text](url) to just text
        md = re.sub(r"\[([^\]]+)\]\([^)]+\)", r"\1", md)

    return md


def to_markdown_with_citations(html: str) -> str:
    """Convert HTML with footnote-style citations for links.

    Links are replaced with numbered references and collected
    at the bottom as footnotes.

    Returns:
            Markdown with footnote-style citations.
    """
    if not html.strip():
        return ""

    md = markdownify(html, heading_style="ATX", strip=["img"]).strip()

    # Extract all markdown links and replace with footnote references
    link_pattern = re.compile(r"\[([^\]]+)\]\(([^)]+)\)")
    citations: list[tuple[str, str]] = []
    seen_urls: dict[str, int] = {}

    def _replace_with_footnote(match: re.Match[str]) -> str:
        text = match.group(1)
        url = match.group(2)
        if url in seen_urls:
            idx = seen_urls[url]
        else:
            idx = len(citations) + 1
            seen_urls[url] = idx
            citations.append((text, url))
        return f"{text}[{idx}]"

    md = link_pattern.sub(_replace_with_footnote, md)

    if citations:
        md += "\n\n---\n"
        for i, (_text, url) in enumerate(citations, 1):
            md += f"\n[{i}] {url}"

    return md
