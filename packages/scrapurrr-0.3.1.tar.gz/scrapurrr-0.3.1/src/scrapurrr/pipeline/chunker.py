"""Markdown chunking — splits large content for LLM processing."""

from __future__ import annotations

import re

from scrapurrr.core.types import ChunkResult


def chunk(markdown: str, max_tokens: int = 4000, source_url: str = "") -> ChunkResult:
    # Use char-based estimation: ~4 chars per token (standard GPT approximation)
    estimated_tokens = len(markdown) // 4

    if estimated_tokens <= max_tokens:
        return ChunkResult(chunks=(markdown,), source_url=source_url)

    sections = _split_by_headings(markdown)

    if len(sections) <= 1:
        sections = _split_fixed(markdown, max_tokens)

    return ChunkResult(chunks=tuple(sections), source_url=source_url)


def chunk_smart(
    markdown: str,
    max_tokens: int = 4000,
    overlap: int = 200,
    source_url: str = "",
) -> ChunkResult:
    """Chunk with overlap and semantic boundary detection.

    Splits by headings first, then by paragraphs if sections are too large.
    Adds overlap between chunks for context continuity.

    Args:
        markdown: Markdown content to chunk.
        max_tokens: Maximum tokens per chunk (~4 chars per token).
        overlap: Number of overlap tokens between chunks.
        source_url: Source URL for metadata.

    Returns:
        ChunkResult with semantically aware chunks.
    """
    max_chars = max_tokens * 4
    overlap_chars = overlap * 4
    estimated_tokens = len(markdown) // 4

    if estimated_tokens <= max_tokens:
        return ChunkResult(chunks=(markdown,), source_url=source_url)

    # Split by headings first
    sections = _split_by_headings(markdown)

    # Process each section — split oversized ones by paragraphs
    fine_sections: list[str] = []
    for section in sections:
        if len(section) <= max_chars:
            fine_sections.append(section)
        else:
            paragraphs = _split_by_paragraphs(section)
            fine_sections.extend(paragraphs)

    # Merge small sections and apply overlap
    chunks: list[str] = []
    current = ""

    for section in fine_sections:
        if not current:
            current = section
        elif len(current) + len(section) + 2 <= max_chars:
            current = current + "\n\n" + section
        else:
            chunks.append(current.strip())
            # Add overlap from end of previous chunk
            if overlap_chars > 0 and current:
                tail = current[-overlap_chars:]
                # Try to start overlap at a word boundary
                space_idx = tail.find(" ")
                if space_idx > 0:
                    tail = tail[space_idx + 1 :]
                current = tail + "\n\n" + section
            else:
                current = section

    if current.strip():
        chunks.append(current.strip())

    # Final pass: split any remaining oversized chunks
    final_chunks: list[str] = []
    for c in chunks:
        if len(c) <= max_chars:
            final_chunks.append(c)
        else:
            final_chunks.extend(_split_fixed(c, max_tokens))

    return ChunkResult(chunks=tuple(final_chunks), source_url=source_url)


def _split_by_headings(markdown: str) -> list[str]:
    parts = re.split(r"(?=^#{1,3}\s)", markdown, flags=re.MULTILINE)
    return [p.strip() for p in parts if p.strip()]


def _split_by_paragraphs(text: str) -> list[str]:
    """Split text by double newlines (paragraphs)."""
    parts = re.split(r"\n\n+", text)
    return [p.strip() for p in parts if p.strip()]


def _split_fixed(markdown: str, max_tokens: int) -> list[str]:
    max_chars = max_tokens * 4  # consistent with char/4 estimation
    chunks: list[str] = []
    for i in range(0, len(markdown), max_chars):
        chunk_text = markdown[i : i + max_chars].strip()
        if chunk_text:
            chunks.append(chunk_text)
    return chunks
