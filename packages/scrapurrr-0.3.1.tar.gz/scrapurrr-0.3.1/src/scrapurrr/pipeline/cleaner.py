"""HTML cleaner — strips noise, preserves content."""

from __future__ import annotations

from bs4 import BeautifulSoup, Tag

from scrapurrr.core.types import CleanResult, PageMetadata
from scrapurrr.pipeline.markdown import to_markdown

_REMOVE_TAGS = {"script", "style", "noscript", "iframe", "svg"}
_REMOVE_ELEMENTS = {"nav", "footer", "header"}
_REMOVE_CLASSES = {"cookie", "banner", "popup", "modal", "overlay", "gdpr", "consent", "ad-"}
_REMOVE_IDS = {"cookie", "banner", "popup", "modal", "overlay", "gdpr", "consent"}


def clean(html: str) -> CleanResult:
    soup = BeautifulSoup(html, "html.parser")

    title = _extract_title(soup)
    language = _extract_language(soup)

    for tag_name in _REMOVE_TAGS:
        for tag in list(soup.find_all(tag_name)):
            tag.decompose()

    for tag_name in _REMOVE_ELEMENTS:
        for tag in list(soup.find_all(tag_name)):
            tag.decompose()

    _remove_by_class_or_id(soup)

    cleaned_html = str(soup)
    markdown = to_markdown(cleaned_html)

    return CleanResult(
        html=cleaned_html,
        markdown=markdown,
        metadata=PageMetadata(title=title, language=language),
    )


def _extract_title(soup: BeautifulSoup) -> str | None:
    title_tag = soup.find("title")
    if title_tag and isinstance(title_tag, Tag):
        return title_tag.get_text(strip=True)
    return None


def _extract_language(soup: BeautifulSoup) -> str | None:
    html_tag = soup.find("html")
    if html_tag and isinstance(html_tag, Tag):
        lang = html_tag.get("lang")
        if isinstance(lang, str):
            return lang
    return None


def clean_fit(html: str, query: str | None = None) -> CleanResult:
    """Clean HTML and apply content filtering for maximum signal.

    1. Standard clean (remove scripts, nav, etc.)
    2. Apply prune_content to remove boilerplate
    3. If query provided, apply bm25_filter

    Returns CleanResult with filtered markdown.
    """
    from scrapurrr.pipeline.content_filter import bm25_filter, prune_content

    result = clean(html)

    filtered_markdown = prune_content(result.markdown)

    if query:
        filtered_markdown = bm25_filter(filtered_markdown, query)

    return CleanResult(
        html=result.html,
        markdown=filtered_markdown,
        metadata=result.metadata,
    )


def _remove_by_class_or_id(soup: BeautifulSoup) -> None:
    for tag in list(soup.find_all(True)):
        if not isinstance(tag, Tag) or tag.parent is None:
            continue
        raw_classes = tag.get("class")
        classes = " ".join(str(c) for c in raw_classes) if isinstance(raw_classes, list) else ""

        raw_id = tag.get("id")
        if isinstance(raw_id, list):
            tag_id = " ".join(str(i) for i in raw_id)
        elif isinstance(raw_id, str):
            tag_id = raw_id
        else:
            tag_id = ""

        classes_lower = classes.lower()
        id_lower = tag_id.lower()

        if any(cls in classes_lower for cls in _REMOVE_CLASSES):
            tag.decompose()
            continue
        if any(rid in id_lower for rid in _REMOVE_IDS):
            tag.decompose()
