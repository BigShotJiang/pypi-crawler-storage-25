"""robots.txt compliance checker."""

from __future__ import annotations

import logging
from urllib.parse import urlparse
from urllib.robotparser import RobotFileParser

import httpx

logger = logging.getLogger(__name__)

_cache: dict[str, RobotFileParser] = {}


async def is_allowed(url: str, user_agent: str = "*") -> bool:
    parsed = urlparse(url)
    robots_url = f"{parsed.scheme}://{parsed.netloc}/robots.txt"

    if robots_url not in _cache:
        try:
            async with httpx.AsyncClient(timeout=10) as client:
                response = await client.get(robots_url)
                parser = RobotFileParser()
                parser.parse(response.text.splitlines())
                _cache[robots_url] = parser
                logger.debug("Loaded robots.txt from %s", robots_url)
        except Exception:
            logger.debug("Could not fetch robots.txt from %s — allowing", robots_url)
            return True

    return _cache[robots_url].can_fetch(user_agent, url)


def clear_cache() -> None:
    _cache.clear()
