"""Shadow DOM flattening — access content inside shadow roots."""

from __future__ import annotations

import logging
from typing import Any

logger = logging.getLogger(__name__)

# Script that recursively traverses and flattens shadow roots into regular DOM nodes.
# Uses shadowRoot.innerHTML (same-origin, browser-controlled) — not user input.
_FLATTEN_SCRIPT = """
() => {
    function flattenShadowRoots(root) {
        const elements = root.querySelectorAll('*');
        for (const el of elements) {
            if (el.shadowRoot) {
                const shadowContent = document.createElement('div');
                shadowContent.setAttribute('data-shadow-host', el.tagName);
                shadowContent.innerHTML = el.shadowRoot.innerHTML;
                el.appendChild(shadowContent);
                flattenShadowRoots(shadowContent);
            }
        }
    }
    flattenShadowRoots(document);
    return document.documentElement.outerHTML;
}
"""

# Init script injected before page load to force all shadow roots open.
_FORCE_OPEN_SCRIPT = """
const origAttachShadow = Element.prototype.attachShadow;
Element.prototype.attachShadow = function(options) {
    return origAttachShadow.call(this, {...options, mode: 'open'});
};
"""


async def flatten_shadow_dom(page: Any) -> str:
    """Flatten all shadow DOM content into regular HTML.

    Injects a script that recursively traverses shadow roots
    and moves their content into the main DOM tree.

    Returns the flattened HTML content.
    """
    flattened_html: str = await page.evaluate(_FLATTEN_SCRIPT)
    logger.debug("Shadow DOM flattened")
    return flattened_html


def patch_shadow_dom_open(page_scripts: list[str]) -> list[str]:
    """Add init script that forces all shadow DOMs to be open.

    Must be injected BEFORE page load via addInitScript.
    """
    return [_FORCE_OPEN_SCRIPT] + page_scripts
