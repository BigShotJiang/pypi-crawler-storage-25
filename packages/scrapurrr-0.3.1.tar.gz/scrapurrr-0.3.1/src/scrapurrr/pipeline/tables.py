"""Robust HTML table extraction handling colspan, rowspan, and nested tables."""

from __future__ import annotations

import logging

from bs4 import BeautifulSoup, Tag

logger = logging.getLogger(__name__)


def extract_tables(html: str) -> list[list[list[str]]]:
    """Extract all tables from HTML, handling complex structures.

    Returns list of tables, each table is a list of rows,
    each row is a list of cell strings.

    Handles: colspan, rowspan, nested tables, multi-level headers.
    """
    soup = BeautifulSoup(html, "html.parser")
    tables = soup.find_all("table", recursive=True)

    results: list[list[list[str]]] = []
    for table in tables:
        if isinstance(table, Tag):
            parsed = _parse_table(table)
            if parsed:
                results.append(parsed)

    return results


def tables_to_markdown(tables: list[list[list[str]]]) -> str:
    """Convert extracted tables to markdown format."""
    parts: list[str] = []

    for table in tables:
        if not table:
            continue

        # Determine column widths
        max_cols = max(len(row) for row in table)

        # Normalize rows to same width
        normalized = [row + [""] * (max_cols - len(row)) for row in table]

        if len(normalized) < 1:
            continue

        # Header row
        header = "| " + " | ".join(normalized[0]) + " |"
        separator = "| " + " | ".join("---" for _ in range(max_cols)) + " |"

        lines = [header, separator]
        for row in normalized[1:]:
            lines.append("| " + " | ".join(row) + " |")

        parts.append("\n".join(lines))

    return "\n\n".join(parts)


def _parse_table(table: Tag) -> list[list[str]]:
    """Parse a single HTML table handling colspan and rowspan."""
    rows: list[list[str]] = []

    # Track cells that span multiple rows
    rowspan_tracker: dict[int, list[tuple[str, int]]] = {}

    for tr in table.find_all("tr", recursive=False):
        if not isinstance(tr, Tag):
            continue

        row_cells: list[str] = []
        col_index = 0

        # Insert any rowspan cells from previous rows
        while col_index in rowspan_tracker:
            spans = rowspan_tracker[col_index]
            if spans:
                cell_text, remaining = spans[0]
                row_cells.append(cell_text)
                if remaining > 1:
                    rowspan_tracker[col_index] = [(cell_text, remaining - 1)]
                else:
                    del rowspan_tracker[col_index]
                col_index += 1
            else:
                del rowspan_tracker[col_index]
                break

        for cell in tr.find_all(["td", "th"], recursive=False):
            if not isinstance(cell, Tag):
                continue

            # Skip past rowspan slots
            while col_index in rowspan_tracker:
                spans = rowspan_tracker[col_index]
                if spans:
                    cell_text, remaining = spans[0]
                    row_cells.append(cell_text)
                    if remaining > 1:
                        rowspan_tracker[col_index] = [(cell_text, remaining - 1)]
                    else:
                        del rowspan_tracker[col_index]
                else:
                    del rowspan_tracker[col_index]
                col_index += 1

            text = cell.get_text(strip=True)
            colspan = int(str(cell.get("colspan") or "1"))
            rowspan = int(str(cell.get("rowspan") or "1"))

            # Handle colspan
            for _ in range(colspan):
                row_cells.append(text)

                # Handle rowspan
                if rowspan > 1:
                    rowspan_tracker[col_index] = [(text, rowspan - 1)]

                col_index += 1

        if row_cells:
            rows.append(row_cells)

    # If table used thead/tbody, parse those too
    if not rows:
        for section in table.find_all(["thead", "tbody", "tfoot"]):
            for tr in section.find_all("tr"):
                cells = [
                    td.get_text(strip=True)
                    for td in tr.find_all(["td", "th"])
                    if isinstance(td, Tag)
                ]
                if cells:
                    rows.append(cells)

    return rows
