"""Lightweight HTTP fetcher using httpx — no browser needed."""

from __future__ import annotations

import logging
from typing import Any

import httpx

from scrapurrr.core.exceptions import NavigationError
from scrapurrr.core.types import FetchResult

logger = logging.getLogger(__name__)


async def http_fetch(
    url: str,
    timeout: int = 30,
    headers: dict[str, str] | None = None,
    proxy: str | None = None,
) -> FetchResult:
    default_headers = {
        "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36",
        "Accept": "text/html,application/xhtml+xml",
        "Accept-Language": "en-US,en;q=0.9",
    }
    if headers:
        default_headers.update(headers)

    client_kwargs: dict[str, Any] = {"follow_redirects": True, "timeout": timeout}
    if proxy:
        client_kwargs["proxies"] = proxy
        logger.debug("HTTP fetch using proxy: %s", proxy)

    try:
        async with httpx.AsyncClient(**client_kwargs) as client:
            response = await client.get(url, headers=default_headers)
            logger.debug("HTTP fetched %s — status=%d", url, response.status_code)
            return FetchResult(
                url=str(response.url),
                html=response.text,
                status=response.status_code,
                headers=dict(response.headers),
            )
    except Exception as exc:
        raise NavigationError(f"HTTP fetch failed for {url}: {exc}") from exc
