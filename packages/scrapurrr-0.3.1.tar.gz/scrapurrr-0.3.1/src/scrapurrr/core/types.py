"""Shared protocols and frozen dataclasses for scrapurrr."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, Protocol, TypeVar, runtime_checkable

from pydantic import BaseModel

if TYPE_CHECKING:
    from collections.abc import AsyncIterator

T = TypeVar("T", bound=BaseModel)


@dataclass(frozen=True)
class PageMetadata:
    title: str | None
    language: str | None


@dataclass(frozen=True)
class FetchResult:
    url: str
    html: str
    status: int
    headers: dict[str, str]


@dataclass(frozen=True)
class CleanResult:
    html: str
    markdown: str
    metadata: PageMetadata


@dataclass(frozen=True)
class ChunkResult:
    chunks: tuple[str, ...]
    source_url: str


@runtime_checkable
class LLMProvider(Protocol):
    async def extract_structured(
        self,
        content: str,
        schema: type[T],
        system_prompt: str | None = None,
    ) -> T: ...
    async def complete(self, prompt: str, system_prompt: str | None = None) -> str: ...
    def stream_complete(
        self, prompt: str, system_prompt: str | None = None
    ) -> AsyncIterator[str]: ...
    @property
    def supports_vision(self) -> bool: ...
    async def extract_from_image(
        self,
        image: bytes,
        schema: type[T],
        system_prompt: str | None = None,
    ) -> T: ...


@runtime_checkable
class PageContext(Protocol):
    async def navigate(self, url: str, wait_until: str = "domcontentloaded") -> None: ...
    async def navigate_with_response(
        self, url: str, wait_until: str = "domcontentloaded"
    ) -> tuple[int, dict[str, str]]: ...
    async def get_html(self) -> str: ...
    async def screenshot(self) -> bytes: ...
    async def scroll(self, direction: str = "down") -> None: ...
    async def wait_for(self, selector: str, timeout: int = 10000) -> None: ...
    async def evaluate(self, js: str) -> Any: ...
    async def click(self, selector: str) -> None: ...
    async def type_text(self, selector: str, text: str) -> None: ...
    async def select_option(self, selector: str, value: str) -> None: ...
    async def go_back(self) -> None: ...


@runtime_checkable
class BrowserEngine(Protocol):
    async def launch(self) -> None: ...
    async def new_page(self) -> PageContext: ...
    async def close(self) -> None: ...


@runtime_checkable
class ExtractionStrategy(Protocol):
    async def can_handle(self, html: str, schema: type[BaseModel]) -> bool: ...
    async def extract(self, content: str, schema: type[T]) -> T: ...


@runtime_checkable
class StealthHook(Protocol):
    async def on_before_navigate(self, page: PageContext, url: str) -> None: ...
    async def on_after_navigate(self, page: PageContext, url: str) -> None: ...
