"""Configuration system with YAML loading and code overrides."""

from __future__ import annotations

import os
from dataclasses import dataclass, replace
from typing import TYPE_CHECKING, Any, Literal

import yaml

from scrapurrr.core.exceptions import ConfigError

if TYPE_CHECKING:
    from pathlib import Path


@dataclass(frozen=True)
class LLMConfig:
    provider: str = "ollama/llama3"
    api_key: str | None = None
    base_url: str | None = None
    max_retries: int = 2


@dataclass(frozen=True)
class BrowserConfig:
    headless: bool = True
    stealth: Literal["off", "basic", "full"] = "basic"
    proxy: str | list[str] | None = None
    timeout: int = 30000
    viewport_width: int | None = None
    viewport_height: int | None = None
    user_agent: str | None = None
    max_retries: int = 3
    mode: Literal["auto", "always", "never"] = "auto"
    requests_per_second: float = 2.0
    js_pre: str | None = None  # JavaScript to run before page load
    js_post: str | None = None  # JavaScript to run after page load


@dataclass(frozen=True)
class ExtractionConfig:
    strategy: Literal["auto", "css", "llm"] = "auto"


@dataclass(frozen=True)
class AgentConfig:
    max_steps: int = 20
    timeout: int = 300


@dataclass(frozen=True)
class CacheConfig:
    enabled: bool = True
    ttl: int = 300  # seconds


@dataclass(frozen=True)
class ScrapurrConfig:
    llm: LLMConfig = LLMConfig()
    browser: BrowserConfig = BrowserConfig()
    extraction: ExtractionConfig = ExtractionConfig()
    agent: AgentConfig = AgentConfig()
    cache: CacheConfig = CacheConfig()
    respect_robots: bool = True

    @staticmethod
    def from_yaml(path: Path) -> ScrapurrConfig:
        try:
            raw = yaml.safe_load(path.read_text())
        except Exception as exc:
            raise ConfigError(f"Failed to load config from {path}: {exc}") from exc

        if not isinstance(raw, dict):
            raise ConfigError(f"Config file {path} must be a YAML mapping")

        llm_raw: dict[str, Any] = raw.get("llm", {})
        browser_raw: dict[str, Any] = raw.get("browser", {})
        extraction_raw: dict[str, Any] = raw.get("extraction", {})
        agent_raw: dict[str, Any] = raw.get("agent", {})
        cache_raw: dict[str, Any] = raw.get("cache", {})
        respect_robots: bool = raw.get("respect_robots", True)

        if "api_key" in llm_raw and isinstance(llm_raw["api_key"], str):
            llm_raw["api_key"] = _resolve_env(llm_raw["api_key"])

        return ScrapurrConfig(
            llm=LLMConfig(**llm_raw),
            browser=BrowserConfig(**{k: v for k, v in browser_raw.items() if v is not None}),
            extraction=ExtractionConfig(**extraction_raw),
            agent=AgentConfig(**agent_raw),
            cache=CacheConfig(**cache_raw),
            respect_robots=respect_robots,
        )

    def override(
        self,
        provider: str | None = None,
        api_key: str | None = None,
        base_url: str | None = None,
        headless: bool | None = None,
        stealth: Literal["off", "basic", "full"] | None = None,
        proxy: str | None = None,
    ) -> ScrapurrConfig:
        llm_updates: dict[str, Any] = {}
        if provider is not None:
            llm_updates["provider"] = provider
        if api_key is not None:
            llm_updates["api_key"] = api_key
        if base_url is not None:
            llm_updates["base_url"] = base_url

        browser_updates: dict[str, Any] = {}
        if headless is not None:
            browser_updates["headless"] = headless
        if stealth is not None:
            browser_updates["stealth"] = stealth
        if proxy is not None:
            browser_updates["proxy"] = proxy

        new_llm = replace(self.llm, **llm_updates) if llm_updates else self.llm
        new_browser = replace(self.browser, **browser_updates) if browser_updates else self.browser

        return replace(self, llm=new_llm, browser=new_browser)


def _resolve_env(value: str) -> str:
    if not value.startswith("env:"):
        return value
    var_name = value[4:]
    result = os.environ.get(var_name)
    if result is None:
        raise ConfigError(f"Environment variable '{var_name}' not set (referenced in config)")
    return result
