"""Schema utilities — Pydantic to JSON Schema, prompt generation, validation."""

from __future__ import annotations

import json
from typing import Any, TypeVar, cast, get_args, get_origin

from pydantic import TypeAdapter

T = TypeVar("T")


class SchemaHelper:
    @staticmethod
    def is_list_type(schema: Any) -> bool:
        return get_origin(schema) is list

    @staticmethod
    def to_json_schema(schema: Any) -> dict[str, Any]:
        if SchemaHelper.is_list_type(schema):
            inner = get_args(schema)[0]
            inner_schema = cast("dict[str, Any]", inner.model_json_schema())
            return {
                "type": "array",
                "items": inner_schema,
            }
        return cast("dict[str, Any]", schema.model_json_schema())

    @staticmethod
    def build_extraction_prompt(schema: Any) -> str:
        json_schema = SchemaHelper.to_json_schema(schema)
        schema_str = json.dumps(json_schema, indent=2)

        if SchemaHelper.is_list_type(schema):
            return (
                "Extract data from the content below. "
                "Return a JSON array of objects matching this schema.\n\n"
                f"Schema:\n```json\n{schema_str}\n```\n\n"
                "Return ONLY valid JSON. No explanation, no markdown fences."
            )
        return (
            "Extract data from the content below. "
            "Return a single JSON object matching this schema.\n\n"
            f"Schema:\n```json\n{schema_str}\n```\n\n"
            "Return ONLY valid JSON. No explanation, no markdown fences."
        )

    @staticmethod
    def validate(data: Any, schema: Any) -> Any:
        adapter: TypeAdapter[Any] = TypeAdapter(schema)
        return adapter.validate_python(data)
