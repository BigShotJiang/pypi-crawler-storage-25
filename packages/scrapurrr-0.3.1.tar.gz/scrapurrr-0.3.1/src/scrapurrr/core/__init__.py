"""Core types, exceptions, configuration, and schema utilities."""
