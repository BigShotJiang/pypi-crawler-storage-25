"""Custom exception hierarchy for scrapurrr."""


class ScrapurrError(Exception):
    """Base exception for all scrapurrr errors."""


class ConfigError(ScrapurrError):
    """Invalid configuration — bad YAML, missing provider."""


class BrowserError(ScrapurrError):
    """Browser operation failure — page load, timeout."""


class NavigationError(BrowserError):
    """Specific URL unreachable."""


class ExtractionError(ScrapurrError):
    """Data extraction failure."""


class SchemaError(ExtractionError):
    """LLM output did not match the Pydantic schema."""


class NoContentError(ExtractionError):
    """Page had no extractable content."""


class ProviderError(ScrapurrError):
    """LLM provider API failure."""


class RateLimitError(ProviderError):
    """Rate limit (429) from LLM provider."""


class AuthError(ProviderError):
    """Bad API key or authentication failure."""


class AgentError(ScrapurrError):
    """Agent loop failure."""


class MaxStepsError(AgentError):
    """Agent hit the maximum step limit."""


class StuckError(AgentError):
    """Agent detected it is looping or stuck."""
