"""Deep crawler — BFS crawl with depth limits and link extraction."""

from __future__ import annotations

import asyncio
import logging
import re
from dataclasses import dataclass
from typing import TYPE_CHECKING, TypeVar
from urllib.parse import urljoin, urlparse

from bs4 import BeautifulSoup
from pydantic import BaseModel

from scrapurrr.pipeline.cleaner import clean

if TYPE_CHECKING:
    from scrapurrr.core.types import FetchResult

logger = logging.getLogger(__name__)

T = TypeVar("T", bound=BaseModel)


@dataclass(frozen=True)
class CrawlResult:
    url: str
    html: str
    markdown: str
    depth: int
    links: tuple[str, ...]


def _extract_links(html: str, base_url: str) -> tuple[str, ...]:
    """Extract and resolve all anchor href links from HTML."""
    soup = BeautifulSoup(html, "html.parser")
    links: list[str] = []
    for a in soup.find_all("a", href=True):
        href = a["href"]
        if isinstance(href, list):
            href = href[0]
        resolved = urljoin(base_url, href)
        # Only keep http/https links, strip fragments
        parsed = urlparse(resolved)
        if parsed.scheme in ("http", "https"):
            clean_url = f"{parsed.scheme}://{parsed.netloc}{parsed.path}"
            if parsed.query:
                clean_url += f"?{parsed.query}"
            links.append(clean_url)
    return tuple(dict.fromkeys(links))


def _is_same_domain(url: str, reference_url: str) -> bool:
    """Check if url belongs to the same domain as reference_url."""
    return urlparse(url).netloc == urlparse(reference_url).netloc


class DeepCrawler:
    """BFS crawler that follows links up to a configurable depth."""

    def __init__(
        self,
        scraper: object,
        max_depth: int = 3,
        max_pages: int = 50,
        same_domain: bool = True,
        url_pattern: str | None = None,
    ) -> None:
        self._scraper = scraper
        self._max_depth = max_depth
        self._max_pages = max_pages
        self._same_domain = same_domain
        self._url_pattern: re.Pattern[str] | None = re.compile(url_pattern) if url_pattern else None

    def _should_visit(self, url: str, start_url: str) -> bool:
        """Determine if a URL should be visited based on filters."""
        if self._same_domain and not _is_same_domain(url, start_url):
            return False
        return not (self._url_pattern and not self._url_pattern.search(url))

    async def crawl(self, start_url: str) -> list[CrawlResult]:
        """BFS crawl from start_url, following links up to max_depth."""
        visited: set[str] = set()
        results: list[CrawlResult] = []
        queue: asyncio.Queue[tuple[str, int]] = asyncio.Queue()
        await queue.put((start_url, 0))

        while not queue.empty() and len(results) < self._max_pages:
            url, depth = await queue.get()

            if url in visited:
                continue
            visited.add(url)

            if depth > self._max_depth:
                continue

            logger.info(
                "Crawling [depth=%d] %s (%d/%d)", depth, url, len(results) + 1, self._max_pages
            )

            try:
                fetch_result: FetchResult = await self._scraper._do_fetch(url)  # type: ignore[attr-defined]
            except Exception as exc:
                logger.warning("Failed to fetch %s: %s", url, exc)
                continue

            clean_result = clean(fetch_result.html)
            links = _extract_links(fetch_result.html, url)

            results.append(
                CrawlResult(
                    url=url,
                    html=fetch_result.html,
                    markdown=clean_result.markdown,
                    depth=depth,
                    links=links,
                )
            )

            if depth < self._max_depth:
                for link in links:
                    if link not in visited and self._should_visit(link, start_url):
                        await queue.put((link, depth + 1))

        logger.info("Crawl complete: %d pages collected", len(results))
        return results

    async def crawl_and_extract(self, start_url: str, schema: type[T]) -> list[T]:
        """Crawl and extract structured data from each page."""
        crawl_results = await self.crawl(start_url)
        extracted: list[T] = []

        extractor = self._scraper._extractor  # type: ignore[attr-defined]
        tasks = [extractor.extract(cr.html, schema) for cr in crawl_results]
        raw_results = await asyncio.gather(*tasks, return_exceptions=True)

        for result in raw_results:
            if not isinstance(result, Exception):
                extracted.append(result)  # type: ignore[arg-type]
            else:
                logger.warning("Extraction failed for a page: %s", result)

        return extracted
