"""URL-based cache with TTL for fetched pages."""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from scrapurrr.core.types import FetchResult

logger = logging.getLogger(__name__)


@dataclass
class CacheEntry:
    result: FetchResult
    timestamp: float


class PageCache:
    def __init__(self, ttl: int = 300) -> None:
        self._cache: dict[str, CacheEntry] = {}
        self._ttl = ttl

    def get(self, url: str) -> FetchResult | None:
        entry = self._cache.get(url)
        if entry is None:
            return None
        if time.time() - entry.timestamp > self._ttl:
            del self._cache[url]
            logger.debug("Cache expired for %s", url)
            return None
        logger.debug("Cache hit for %s", url)
        return entry.result

    def put(self, url: str, result: FetchResult) -> None:
        self._cache[url] = CacheEntry(result=result, timestamp=time.time())
        logger.debug("Cached %s", url)

    def clear(self) -> None:
        self._cache.clear()

    @property
    def size(self) -> int:
        return len(self._cache)
