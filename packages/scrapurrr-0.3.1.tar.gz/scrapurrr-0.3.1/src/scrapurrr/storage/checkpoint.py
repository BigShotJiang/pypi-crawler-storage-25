"""Agent checkpoint — save and resume agent runs."""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any, cast

logger = logging.getLogger(__name__)


class AgentCheckpoint:
    """Save and restore agent memory for resumable runs."""

    def __init__(self, path: str | Path) -> None:
        self._path = Path(path)

    def save(self, memory_data: dict[str, Any]) -> None:
        self._path.write_text(json.dumps(memory_data, indent=2, default=str))
        logger.info("Checkpoint saved to %s", self._path)

    def load(self) -> dict[str, Any] | None:
        if not self._path.exists():
            return None
        try:
            data = json.loads(self._path.read_text())
            logger.info("Checkpoint loaded from %s", self._path)
            return cast("dict[str, Any]", data)
        except Exception as exc:
            logger.warning("Failed to load checkpoint: %s", exc)
            return None

    def delete(self) -> None:
        if self._path.exists():
            self._path.unlink()
            logger.debug("Checkpoint deleted: %s", self._path)
