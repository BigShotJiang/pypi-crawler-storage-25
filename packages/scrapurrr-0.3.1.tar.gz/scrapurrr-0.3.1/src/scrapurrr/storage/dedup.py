"""Result deduplication for extraction results."""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from collections.abc import Sequence

    from pydantic import BaseModel

logger = logging.getLogger(__name__)


def deduplicate(items: Sequence[BaseModel], key_fields: list[str] | None = None) -> list[BaseModel]:
    """Remove duplicate items based on key fields or all fields."""
    if not items:
        return list(items)

    seen: set[str] = set()
    unique: list[BaseModel] = []

    for item in items:
        if key_fields:
            key_data = {f: getattr(item, f, None) for f in key_fields}
        else:
            key_data = item.model_dump()

        key = str(sorted(key_data.items()))
        if key not in seen:
            seen.add(key)
            unique.append(item)

    removed = len(items) - len(unique)
    if removed > 0:
        logger.info("Deduplicated: removed %d duplicates from %d items", removed, len(items))

    return unique
