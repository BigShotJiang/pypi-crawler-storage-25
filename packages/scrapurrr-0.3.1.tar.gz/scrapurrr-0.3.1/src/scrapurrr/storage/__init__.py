"""Data persistence — caching, checkpointing, dedup, export."""
