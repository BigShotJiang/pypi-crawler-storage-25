"""Export utilities — JSON, CSV output for extraction results."""

from __future__ import annotations

import csv
import io
import json
from pathlib import Path
from typing import Any

from pydantic import BaseModel


def to_json(data: Any, path: str | Path) -> None:
    """Write extraction results to JSON file."""
    Path(path).write_text(to_json_str(data))


def to_json_str(data: Any) -> str:
    """Convert extraction results to JSON string."""
    if isinstance(data, list):
        return json.dumps([_to_dict(item) for item in data], indent=2)
    return json.dumps(_to_dict(data), indent=2)


def to_csv(data: Any, path: str | Path) -> None:
    """Write extraction results to CSV file."""
    Path(path).write_text(to_csv_str(data))


def to_csv_str(data: Any) -> str:
    """Convert extraction results to CSV string."""
    items = data if isinstance(data, list) else [data]
    if not items:
        return ""

    dicts = [_to_dict(item) for item in items]
    output = io.StringIO()
    writer = csv.DictWriter(output, fieldnames=dicts[0].keys())
    writer.writeheader()
    writer.writerows(dicts)
    return output.getvalue()


def _to_dict(item: Any) -> dict[str, Any]:
    if isinstance(item, BaseModel):
        return item.model_dump()
    if isinstance(item, dict):
        return item
    return {"value": str(item)}
