"""Plugin discovery and loading system."""

from __future__ import annotations

import importlib.metadata
import logging
from typing import Any

logger = logging.getLogger(__name__)

_registry: dict[str, Any] = {}


def register_plugin(name: str, plugin: Any) -> None:
    """Register a plugin by name."""
    _registry[name] = plugin
    logger.info("Plugin registered: %s", name)


def get_plugin(name: str) -> Any | None:
    """Get a registered plugin by name."""
    return _registry.get(name)


def list_plugins() -> list[str]:
    """List all registered plugin names."""
    return list(_registry.keys())


def load_plugins_from_entry_points(group: str = "scrapurrr.plugins") -> None:
    """Discover and load plugins from entry points."""
    try:
        eps = importlib.metadata.entry_points()
        plugin_eps = (
            eps.select(group=group) if hasattr(eps, "select") else eps.get(group, [])  # type: ignore[arg-type]
        )

        for ep in plugin_eps:
            try:
                plugin = ep.load()
                register_plugin(ep.name, plugin)
            except Exception as exc:
                logger.warning("Failed to load plugin %s: %s", ep.name, exc)
    except Exception as exc:
        logger.debug("Plugin discovery unavailable: %s", exc)
