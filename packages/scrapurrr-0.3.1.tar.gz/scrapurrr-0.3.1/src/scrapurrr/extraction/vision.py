"""Vision-based extraction — future implementation."""

from __future__ import annotations

from typing import TYPE_CHECKING, TypeVar

from pydantic import BaseModel

if TYPE_CHECKING:
    from scrapurrr.core.types import LLMProvider

T = TypeVar("T", bound=BaseModel)


class VisionExtractor:
    def __init__(self, provider: LLMProvider) -> None:
        self._provider = provider

    async def can_handle(self, html: str, schema: type[BaseModel]) -> bool:
        return self._provider.supports_vision

    async def extract(self, image: bytes, schema: type[T]) -> T:
        return await self._provider.extract_from_image(image=image, schema=schema)
