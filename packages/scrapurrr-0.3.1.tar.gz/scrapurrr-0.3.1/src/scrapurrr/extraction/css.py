"""CSS/XPath rule-based extraction using field-name heuristics."""

from __future__ import annotations

from typing import Any, TypeVar

from bs4 import BeautifulSoup, Tag
from pydantic import BaseModel

from scrapurrr.core.exceptions import ExtractionError

T = TypeVar("T", bound=BaseModel)

_FIELD_SELECTORS: dict[str, list[str]] = {
    "price": ["[class*=price]", "[data-price]", ".cost", ".amount"],
    "title": ["h1", "h2", ".title", "[class*=title]", ".name", "[class*=name]"],
    "name": ["h1", "h2", ".title", "[class*=title]", ".name", "[class*=name]"],
    "image": ["img[src]", "[class*=image] img", ".photo img"],
    "description": [".description", "[class*=desc]", "p.summary", "[class*=summary]"],
    "rating": ["[class*=rating]", "[data-rating]", "[class*=review]"],
    "url": ["a[href]"],
    "link": ["a[href]"],
}


class CSSExtractor:
    async def can_handle(self, html: str, schema: type[BaseModel]) -> bool:
        if not html.strip():
            return False
        soup = BeautifulSoup(html, "html.parser")
        fields = schema.model_fields
        matched = 0
        for field_name, field_info in fields.items():
            if _find_value(soup, field_name, field_info) is not None:
                matched += 1
        return matched == len(fields)

    async def extract(self, html: str, schema: type[T]) -> T:
        soup = BeautifulSoup(html, "html.parser")
        fields = schema.model_fields
        data: dict[str, Any] = {}

        for field_name, field_info in fields.items():
            value = _find_value(soup, field_name, field_info)
            if value is None:
                raise ExtractionError(
                    f"CSS extraction failed: could not find value for field '{field_name}'"
                )
            data[field_name] = value

        return schema.model_validate(data)


def _find_value(soup: BeautifulSoup, field_name: str, field_info: Any = None) -> str | None:
    # Check for custom selector hint in field metadata
    if field_info is not None and field_info.json_schema_extra:
        custom_selector = field_info.json_schema_extra.get("css_selector")
        if custom_selector:
            tag = soup.select_one(custom_selector)
            if tag and isinstance(tag, Tag):
                text = tag.get_text(strip=True)
                if text:
                    return text

    selectors = _FIELD_SELECTORS.get(field_name, [])

    for selector in selectors:
        tag = soup.select_one(selector)
        if tag and isinstance(tag, Tag):
            if field_name in ("url", "link"):
                href = tag.get("href")
                if href:
                    return str(href)
            if field_name == "image":
                src = tag.get("src")
                if src:
                    return str(src)
            text = tag.get_text(strip=True)
            if text:
                return text

    return None
