"""ElementInfo and ElementCollection data models for scraped DOM elements."""

import dataclasses
from collections.abc import Iterator
from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class ElementInfo:
    index: int
    tag: str
    text: str
    css: str
    xpath: str
    full_xpath: str
    js_path: str
    outer_html: str
    styles: dict[str, str]
    attributes: dict[str, str]
    rect: dict[str, float]


@dataclass(frozen=True)
class ElementCollection:
    elements: tuple[ElementInfo, ...]

    def filter(
        self, tag: str | None = None, text: str | None = None, attr: str | None = None
    ) -> "ElementCollection":
        """Return a new collection matching all supplied criteria (AND-ed)."""
        matched = self.elements

        if tag is not None:
            tag_lower = tag.lower()
            matched = tuple(el for el in matched if el.tag.lower() == tag_lower)

        if text is not None:
            text_lower = text.lower()
            matched = tuple(el for el in matched if text_lower in el.text.lower())

        if attr is not None:
            matched = tuple(el for el in matched if attr in el.attributes)

        return ElementCollection(elements=matched)

    def first(self) -> ElementInfo | None:
        """Return the first element, or None if the collection is empty."""
        return self.elements[0] if self.elements else None

    def by_index(self, index: int) -> ElementInfo:
        """Return the element with the given ElementInfo.index value.

        Raises IndexError if no element has that index.
        """
        for el in self.elements:
            if el.index == index:
                return el
        raise IndexError(f"No element with index {index}")

    def to_list(self) -> list[dict[str, Any]]:
        """Convert all elements to plain dicts via dataclasses.asdict."""
        return [dataclasses.asdict(el) for el in self.elements]

    def __len__(self) -> int:
        return len(self.elements)

    def __iter__(self) -> Iterator[ElementInfo]:
        return iter(self.elements)

    def __getitem__(self, index: int) -> ElementInfo:
        return self.elements[index]


# ---------------------------------------------------------------------------
# JavaScript extraction script
# ---------------------------------------------------------------------------

ELEMENT_EXTRACTION_JS = """
(maxElements) => {
	const TAGS = new Set([
		'a','button','input','select','textarea','img',
		'h1','h2','h3','h4','h5','h6',
		'p','span','div','li','td','th',
		'label','form','table','section','article','main','nav','footer','header'
	]);
	const STYLE_PROPS = [
		'color','backgroundColor','fontSize','fontWeight','display','visibility',
		'position','width','height','margin','padding','border','textAlign','opacity'
	];

	function getCssSelector(el) {
		if (el.id) return '#' + CSS.escape(el.id);
		const parts = [];
		let cur = el;
		for (let depth = 0; depth < 5 && cur && cur.tagName; depth++) {
			if (cur.id) { parts.unshift('#' + CSS.escape(cur.id)); break; }
			const tag = cur.tagName.toLowerCase();
			const cls = Array.from(cur.classList).slice(0, 2).map(c => '.' + CSS.escape(c)).join('');
			const parent = cur.parentElement;
			let nth = '';
			if (parent) {
				const siblings = Array.from(parent.children).filter(c => c.tagName === cur.tagName);
				if (siblings.length > 1) nth = ':nth-child(' + (Array.from(parent.children).indexOf(cur) + 1) + ')';
			}
			parts.unshift(tag + cls + nth);
			cur = parent;
		}
		return parts.join(' > ');
	}

	function getShortXPath(el) {
		const tag = el.tagName.toLowerCase();
		if (el.id) return '//' + tag + '[@id=\\'' + el.id + '\\']';
		const cls = el.classList[0];
		if (cls) return '//' + tag + '[@class=\\'' + cls + '\\']';
		const txt = (el.textContent || '').trim().slice(0, 30);
		if (txt) return '//' + tag + '[contains(text(),\\'' + txt.replace(/'/g, "\\'") + '\\')]';
		return getFullXPath(el);
	}

	function getFullXPath(el) {
		const parts = [];
		let cur = el;
		while (cur && cur.nodeType === 1) {
			const tag = cur.tagName.toLowerCase();
			const parent = cur.parentElement;
			let idx = 1;
			if (parent) {
				for (const sib of parent.children) {
					if (sib === cur) break;
					if (sib.tagName === cur.tagName) idx++;
				}
			}
			parts.unshift(tag + '[' + idx + ']');
			cur = parent;
		}
		return '/' + parts.join('/');
	}

	const results = [];
	let index = 0;
	const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_ELEMENT);
	let node = walker.nextNode();

	while (node && index < maxElements) {
		const tag = node.tagName.toLowerCase();
		if (!TAGS.has(tag)) { node = walker.nextNode(); continue; }

		const cs = window.getComputedStyle(node);
		if (cs.display === 'none' || cs.visibility === 'hidden') { node = walker.nextNode(); continue; }

		const rect = node.getBoundingClientRect();
		if (rect.width === 0 && rect.height === 0) { node = walker.nextNode(); continue; }

		const css = getCssSelector(node);
		const styles = {};
		for (const prop of STYLE_PROPS) styles[prop] = cs[prop] || '';

		const attributes = {};
		for (const attr of node.attributes) attributes[attr.name] = attr.value;

		results.push({
			index,
			tag,
			text: (node.textContent || '').trim().slice(0, 200),
			css,
			xpath: getShortXPath(node),
			full_xpath: getFullXPath(node),
			js_path: 'document.querySelector("' + css.replace(/"/g, '\\"') + '")',
			outer_html: node.outerHTML.slice(0, 500),
			styles,
			attributes,
			rect: { x: rect.x, y: rect.y, width: rect.width, height: rect.height },
		});

		index++;
		node = walker.nextNode();
	}

	return JSON.stringify(results);
}
""".strip()


# ---------------------------------------------------------------------------
# extract_elements async function
# ---------------------------------------------------------------------------


async def extract_elements(page: Any, max_elements: int = 500) -> ElementCollection:
    """Extract visible DOM elements from the page and return an ElementCollection.

    Args:
            page: Playwright Page object (or compatible interface with evaluate()).
            max_elements: Maximum number of elements to extract.

    Returns:
            ElementCollection populated with ElementInfo objects.
    """
    import json

    raw_json: str = await page.evaluate(ELEMENT_EXTRACTION_JS, max_elements)
    raw_list: list[dict[str, Any]] = json.loads(raw_json) if isinstance(raw_json, str) else raw_json

    elements = tuple(
        ElementInfo(
            index=item["index"],
            tag=item["tag"],
            text=item["text"],
            css=item["css"],
            xpath=item["xpath"],
            full_xpath=item["full_xpath"],
            js_path=item["js_path"],
            outer_html=item["outer_html"],
            styles=item["styles"],
            attributes=item["attributes"],
            rect=item["rect"],
        )
        for item in raw_list
    )
    return ElementCollection(elements=elements)
