"""Extraction orchestrator — strategy picker."""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Literal, TypeVar

from pydantic import BaseModel

from scrapurrr.core.exceptions import ExtractionError, NoContentError
from scrapurrr.extraction.css import CSSExtractor
from scrapurrr.extraction.llm import LLMExtractor
from scrapurrr.extraction.vision import VisionExtractor

if TYPE_CHECKING:
    from scrapurrr.core.types import LLMProvider

T = TypeVar("T", bound=BaseModel)

logger = logging.getLogger(__name__)


class Extractor:
    def __init__(
        self,
        provider: LLMProvider,
        strategy: Literal["auto", "css", "llm", "vision"] = "auto",
    ) -> None:
        self._css = CSSExtractor()
        self._llm = LLMExtractor(provider)
        self._vision = VisionExtractor(provider)
        self._strategy = strategy
        self._provider = provider

    async def extract(self, html: str, schema: type[T], screenshot: bytes | None = None) -> T:
        if not html.strip():
            raise NoContentError("No content to extract from")

        if self._strategy == "css":
            if await self._css.can_handle(html, schema):
                return await self._css.extract(html, schema)
            raise ExtractionError("CSS strategy could not match all schema fields")

        if self._strategy == "llm":
            return await self._llm.extract(html, schema)

        if self._strategy == "vision":
            if screenshot is None:
                raise ExtractionError("Vision strategy requires a screenshot (bytes)")
            return await self._vision.extract(screenshot, schema)

        # auto: try CSS first, fall back to LLM, then vision as last resort
        if await self._css.can_handle(html, schema):
            logger.info("CSS extraction succeeded — skipping LLM")
            return await self._css.extract(html, schema)

        logger.info("CSS cannot handle schema — falling back to LLM")
        try:
            return await self._llm.extract(html, schema)
        except Exception as llm_exc:
            if screenshot is not None and self._provider.supports_vision:
                logger.warning("LLM extraction failed (%s) — falling back to vision", llm_exc)
                return await self._vision.extract(screenshot, schema)
            raise
