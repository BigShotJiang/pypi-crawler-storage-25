"""LLM-based extraction strategy — sends content + schema to LLM provider."""

from __future__ import annotations

from typing import TYPE_CHECKING, TypeVar

from pydantic import BaseModel

if TYPE_CHECKING:
    from scrapurrr.core.types import LLMProvider

T = TypeVar("T", bound=BaseModel)


class LLMExtractor:
    def __init__(self, provider: LLMProvider) -> None:
        self._provider = provider

    async def can_handle(self, html: str, schema: type[BaseModel]) -> bool:
        return bool(html.strip())

    async def extract(self, content: str, schema: type[T]) -> T:
        return await self._provider.extract_structured(content=content, schema=schema)
