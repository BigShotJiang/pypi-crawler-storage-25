from django.contrib import admin
from edc_model_admin.history import SimpleHistoryAdmin
from edc_sites.admin import SiteModelAdminMixin

from ..admin_site import effect_ae_admin
from ..forms import DeathReportTmgForm
from ..models import DeathReportTmg
from .modeladmin_mixins import DeathReportTmgModelAdminMixin


@admin.register(DeathReportTmg, site=effect_ae_admin)
class DeathReportTmgAdmin(
    SiteModelAdminMixin,
    DeathReportTmgModelAdminMixin,
    SimpleHistoryAdmin,
):
    form = DeathReportTmgForm
