from auth.none import get_auth_headers

BASE_URL = "https://www.twfood.cc"

ENDPOINTS = {
    "items": "/data/item.json",
    "daily_trades": "/api/FarmTradeSums",
    "weekly_trades": "/api/FarmTradeSumWeeks",
    "monthly_trades": "/api/FarmTradeSumMonths",
    "yearly_trades": "/api/FarmTradeSumYears",
    "market_history": "/api/FarmTradeHistories/{item_code}",
}


def get_headers() -> dict:
    """Get request headers including auth."""
    headers = {
        "Content-Type": "application/json",
        "Accept": "application/json",
    }
    headers.update(get_auth_headers())
    return headers


def get_url(endpoint_key: str, **kwargs) -> str:
    """Build full URL for an endpoint with path parameter substitution.

    Args:
        endpoint_key: Key from ENDPOINTS dict.
        **kwargs: Path parameters to substitute (e.g., item_code="LA1").

    Returns:
        Full URL string.

    Raises:
        KeyError: If endpoint_key not found in ENDPOINTS.
    """
    path = ENDPOINTS[endpoint_key]
    if kwargs:
        path = path.format(**kwargs)
    return f"{BASE_URL}{path}"
