#!/usr/bin/env python3
"""E2E test runner for all twfood MCP tools.

Runs each tool with test parameters against the live twfood.cc API.
No credentials required (public API).

Usage:
    python tests/test_all_tools.py
"""

import sys
import os
import asyncio
import traceback

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import tools.twfood_tools  # noqa: F401

from app import mcp


results = []


def run_test(name: str, fn, **kwargs):
    """Run a single tool test and record the result."""
    print(f"\n{'='*60}")
    print(f"TEST: {name}")
    print(f"{'='*60}")
    try:
        result = fn(**kwargs)
        print(f"  PASS")
        if isinstance(result, dict):
            for key, value in result.items():
                preview = str(value)
                if len(preview) > 120:
                    preview = preview[:120] + "..."
                print(f"    {key}: {preview}")
        results.append(("PASS", name))
    except Exception as e:
        print(f"  FAIL: {e}")
        traceback.print_exc()
        results.append(("FAIL", name))


def main():
    tools_list = asyncio.run(mcp.list_tools())
    print(f"Registered tools: {len(tools_list)}")
    for tool in tools_list:
        print(f"  - {tool.name}: {tool.description[:80] if tool.description else 'no description'}")

    print(f"\n{'#'*60}")
    print(f"RUNNING E2E TESTS")
    print(f"{'#'*60}")

    # =========================================================================
    # search_products
    # =========================================================================

    # Search by Chinese name (vegetable)
    run_test(
        "search_products — 高麗菜 (cabbage by name)",
        tools.twfood_tools.search_products,
        keyword="高麗菜",
    )

    # Search by item code
    run_test(
        "search_products — LA1 (cabbage by code)",
        tools.twfood_tools.search_products,
        keyword="LA1",
    )

    # Search fruit
    run_test(
        "search_products — 鳳梨 (pineapple)",
        tools.twfood_tools.search_products,
        keyword="鳳梨",
    )

    # Search flower
    run_test(
        "search_products — 玫瑰 (rose)",
        tools.twfood_tools.search_products,
        keyword="玫瑰",
    )

    # Search with no matches
    run_test(
        "search_products — nonexistent product",
        tools.twfood_tools.search_products,
        keyword="不存在的品項xyz",
    )

    # =========================================================================
    # get_daily_trades
    # =========================================================================

    # Cabbage daily
    run_test(
        "get_daily_trades — LA1 cabbage March 2026",
        tools.twfood_tools.get_daily_trades,
        item_code="LA1",
        start_date="2026/03/01",
    )

    # Pineapple daily
    run_test(
        "get_daily_trades — B2 pineapple March 2026",
        tools.twfood_tools.get_daily_trades,
        item_code="B2",
        start_date="2026/03/01",
    )

    # =========================================================================
    # get_weekly_trades
    # =========================================================================

    # Cabbage weekly
    run_test(
        "get_weekly_trades — LA1 cabbage 2026",
        tools.twfood_tools.get_weekly_trades,
        item_code="LA1",
        start_date="2026/01/01",
    )

    # Banana weekly
    run_test(
        "get_weekly_trades — A1 banana 2026",
        tools.twfood_tools.get_weekly_trades,
        item_code="A1",
        start_date="2026/01/01",
    )

    # =========================================================================
    # get_monthly_trades
    # =========================================================================

    # Cabbage monthly
    run_test(
        "get_monthly_trades — LA1 cabbage from 2025",
        tools.twfood_tools.get_monthly_trades,
        item_code="LA1",
        start_date="2025/01/01",
    )

    # Strawberry monthly
    run_test(
        "get_monthly_trades — N1 strawberry from 2025",
        tools.twfood_tools.get_monthly_trades,
        item_code="N1",
        start_date="2025/01/01",
    )

    # =========================================================================
    # get_yearly_trades
    # =========================================================================

    # Cabbage yearly (back to 1996)
    run_test(
        "get_yearly_trades — LA1 cabbage (historical)",
        tools.twfood_tools.get_yearly_trades,
        item_code="LA1",
    )

    # Guava yearly
    run_test(
        "get_yearly_trades — P1 guava (historical)",
        tools.twfood_tools.get_yearly_trades,
        item_code="P1",
    )

    # =========================================================================
    # get_market_history
    # =========================================================================

    # Cabbage cross-market
    run_test(
        "get_market_history — LA1 cabbage (cross-market)",
        tools.twfood_tools.get_market_history,
        item_code="LA1",
    )

    # Pineapple cross-market
    run_test(
        "get_market_history — B2 pineapple (cross-market)",
        tools.twfood_tools.get_market_history,
        item_code="B2",
    )

    # =========================================================================
    # Summary
    # =========================================================================
    print(f"\n{'#'*60}")
    print(f"TEST SUMMARY")
    print(f"{'#'*60}")

    passed = sum(1 for status, _ in results if status == "PASS")
    failed = sum(1 for status, _ in results if status == "FAIL")

    for status, name in results:
        icon = "+" if status == "PASS" else "X"
        print(f"  [{icon}] {name}")

    print(f"\nTotal: {len(results)} | Passed: {passed} | Failed: {failed}")

    if failed > 0:
        sys.exit(1)


if __name__ == "__main__":
    main()
