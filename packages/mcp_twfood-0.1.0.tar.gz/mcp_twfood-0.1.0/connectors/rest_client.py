"""REST API connector with retry."""

import time
import requests
from config.settings import get_headers, get_url


class ServiceAPIError(Exception):
    """Custom exception for API errors."""

    def __init__(self, status_code: int, message: str, endpoint: str = ""):
        self.status_code = status_code
        self.message = message
        self.endpoint = endpoint
        super().__init__(f"[{status_code}] {endpoint}: {message}")


def api_request(
    method: str,
    endpoint_key: str,
    params: dict | None = None,
    path_params: dict | None = None,
    retries: int = 3,
    timeout: int = 60,
):
    """Make an HTTP request with exponential backoff retry.

    Args:
        method: HTTP method (GET, POST, PUT, DELETE).
        endpoint_key: Key from ENDPOINTS dict in settings.
        params: Query parameters.
        path_params: Path parameters for URL substitution.
        retries: Number of retry attempts for transient errors.
        timeout: Request timeout in seconds.

    Returns:
        Parsed JSON response.

    Raises:
        ServiceAPIError: On non-transient HTTP errors.
    """
    url = get_url(endpoint_key, **(path_params or {}))
    headers = get_headers()

    for attempt in range(retries):
        try:
            response = requests.request(
                method=method.upper(),
                url=url,
                headers=headers,
                params=params,
                timeout=timeout,
            )

            if response.status_code >= 400:
                raise ServiceAPIError(
                    status_code=response.status_code,
                    message=response.text[:500],
                    endpoint=endpoint_key,
                )

            return response.json()

        except (requests.exceptions.Timeout, requests.exceptions.ConnectionError):
            if attempt < retries - 1:
                wait = 2**attempt
                time.sleep(wait)
            else:
                raise ServiceAPIError(
                    status_code=0,
                    message="Request failed after all retries (timeout/connection error)",
                    endpoint=endpoint_key,
                )


def api_get(
    endpoint_key: str,
    params: dict | None = None,
    path_params: dict | None = None,
    retries: int = 3,
):
    """Convenience wrapper for GET requests."""
    return api_request("GET", endpoint_key, params=params, path_params=path_params, retries=retries)
