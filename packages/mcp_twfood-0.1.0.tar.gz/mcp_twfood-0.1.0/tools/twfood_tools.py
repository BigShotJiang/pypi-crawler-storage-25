"""MCP tools for twfood.cc — Taiwan agricultural wholesale market price data."""

import json

from pydantic import Field
from pydantic.fields import FieldInfo

from app import mcp
from connectors.rest_client import api_get


def _val(v, default=""):
    """Resolve a parameter value, handling FieldInfo defaults from direct calls."""
    if v is None or isinstance(v, FieldInfo):
        return default
    return v


@mcp.tool()
def search_products(
    keyword: str = Field(description="Search keyword for product name or code (e.g., '高麗菜', 'LA1', '椰子')"),
) -> dict:
    """Search Taiwan agricultural products by name or item code. Returns matching products with their item codes for use in other trade data tools."""
    data = api_get("items")

    keyword_lower = keyword.lower()
    matches = [item for item in data if keyword_lower in item.lower()]

    results = []
    for item in matches[:50]:
        parts = item.rsplit(" ", 1)
        if len(parts) == 2:
            results.append({"name": parts[0].strip(), "code": parts[1].strip()})
        else:
            results.append({"name": item.strip(), "code": ""})

    return {"total": len(matches), "shown": len(results), "items": results}


@mcp.tool()
def get_daily_trades(
    item_code: str = Field(description="Product item code (e.g., 'LA1' for lettuce, 'B2' for pineapple)"),
    start_date: str = Field(description="Start date in YYYY/MM/DD format (e.g., '2026/03/01')"),
) -> dict:
    """Get daily wholesale market trade data for an agricultural product. Returns transaction volume (kg), average/high/low prices (TWD/kg) per day."""
    filter_dict = {
        "order": "day asc",
        "where": {
            "itemCode": item_code,
            "day": {"gte": start_date},
        },
    }
    params = {"filter": json.dumps(filter_dict, ensure_ascii=False)}
    data = api_get("daily_trades", params=params)

    return {
        "item_code": item_code,
        "start_date": start_date,
        "total_records": len(data),
        "records": data,
    }


@mcp.tool()
def get_weekly_trades(
    item_code: str = Field(description="Product item code (e.g., 'LA1' for lettuce)"),
    start_date: str = Field(description="Start date in YYYY/MM/DD format (e.g., '2026/01/01')"),
) -> dict:
    """Get weekly wholesale market trade summaries for an agricultural product. Returns transaction volume (kg), average price (TWD/kg), and total value per week."""
    filter_dict = {
        "order": "endDay asc",
        "where": {
            "itemCode": item_code,
            "startDay": {"gte": start_date},
        },
    }
    params = {"filter": json.dumps(filter_dict, ensure_ascii=False)}
    data = api_get("weekly_trades", params=params)

    return {
        "item_code": item_code,
        "start_date": start_date,
        "total_records": len(data),
        "records": data,
    }


@mcp.tool()
def get_monthly_trades(
    item_code: str = Field(description="Product item code (e.g., 'LA1' for lettuce)"),
    start_date: str = Field(description="Start date in YYYY/MM/DD format (e.g., '2025/01/01')"),
) -> dict:
    """Get monthly wholesale market trade summaries for an agricultural product. Returns transaction volume (kg) and average price (TWD/kg) per month."""
    filter_dict = {
        "order": "endDay asc",
        "where": {
            "itemCode": item_code,
            "startDay": {"gte": start_date},
        },
    }
    params = {"filter": json.dumps(filter_dict, ensure_ascii=False)}
    data = api_get("monthly_trades", params=params)

    return {
        "item_code": item_code,
        "start_date": start_date,
        "total_records": len(data),
        "records": data,
    }


@mcp.tool()
def get_yearly_trades(
    item_code: str = Field(description="Product item code (e.g., 'LA1' for lettuce)"),
) -> dict:
    """Get yearly wholesale market trade summaries for an agricultural product. Historical data available back to 1996."""
    filter_dict = {
        "order": "endDay asc",
        "where": {
            "itemCode": item_code,
        },
    }
    params = {"filter": json.dumps(filter_dict, ensure_ascii=False)}
    data = api_get("yearly_trades", params=params)

    return {
        "item_code": item_code,
        "total_records": len(data),
        "records": data,
    }


@mcp.tool()
def get_market_history(
    item_code: str = Field(description="Product item code (e.g., 'LA1' for lettuce)"),
) -> dict:
    """Get recent transaction history across all Taiwan wholesale markets for a product. Returns per-market volume and price time series data."""
    data = api_get("market_history", path_params={"item_code": item_code})

    volume_series = data.get("seriesAry", [])
    price_series = data.get("series2dAry", [])

    return {
        "item_code": item_code,
        "markets": [s["name"] for s in volume_series],
        "volume_series_count": len(volume_series),
        "price_series_count": len(price_series),
        "volume_series": volume_series,
        "price_series": price_series,
    }
