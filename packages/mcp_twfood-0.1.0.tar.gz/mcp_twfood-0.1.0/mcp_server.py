#!/usr/bin/env python3
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import tools.twfood_tools  # noqa: F401

from app import mcp


def main():
    mcp.run()  # Default stdio transport


if __name__ == "__main__":
    main()
