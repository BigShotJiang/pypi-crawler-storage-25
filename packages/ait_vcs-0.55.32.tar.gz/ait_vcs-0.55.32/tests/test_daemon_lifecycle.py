from __future__ import annotations

import os
import json
import signal
import subprocess
import sys
import tempfile
import time
import unittest
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from ait.app import create_attempt, create_intent, init_repo
from ait.harness import AitHarness
from ait.daemon import (
    _write_pid_file,
    daemon_status,
    prune_daemon,
    serve_daemon,
    start_daemon,
    stop_daemon,
)
from ait.daemon_transport import bind_unix_socket
from ait.db import NewAttempt, NewIntent, connect_db, get_attempt, insert_attempt, insert_intent, run_migrations


class DaemonLifecycleTests(unittest.TestCase):
    def test_write_pid_file_replaces_atomically(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            pid_file = Path(tmp) / ".ait" / "daemon.pid"

            _write_pid_file(pid_file, 123)
            _write_pid_file(pid_file, 456)

            self.assertEqual("456\n", pid_file.read_text(encoding="utf-8"))
            self.assertEqual([], list(pid_file.parent.glob("daemon.pid.*.tmp")))

    def test_daemon_status_does_not_trust_unrelated_live_pid(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            repo_root = Path(tmp)
            _init_git_repo(repo_root)
            init_repo(repo_root)
            pid_file = repo_root / ".ait" / "daemon.pid"
            pid_file.write_text(f"{os.getpid()}\n", encoding="utf-8")

            status = daemon_status(repo_root)

            self.assertFalse(status.running)
            self.assertTrue(status.pid_running)
            self.assertFalse(status.pid_matches)
            self.assertEqual("pid_not_ait_daemon", status.stale_reason)

    def test_start_daemon_cleans_stale_pid_and_socket_before_starting(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            repo_root = Path(tmp)
            _init_git_repo(repo_root)
            init_repo(repo_root)
            socket_path = repo_root / ".ait" / "daemon.sock"
            stale_server = bind_unix_socket(socket_path)
            stale_server.close()
            pid_file = repo_root / ".ait" / "daemon.pid"
            pid_file.write_text("not-a-pid\n", encoding="utf-8")

            before = daemon_status(repo_root)
            try:
                started = start_daemon(repo_root)

                self.assertFalse(before.running)
                self.assertIsNotNone(before.stale_reason)
                self.assertTrue(started.running)
                self.assertTrue(started.socket_connectable)
                self.assertTrue(started.pid_matches)
                self.assertIsNotNone(started.pid)
                self.assertNotEqual("not-a-pid\n", pid_file.read_text(encoding="utf-8"))

                stopped = stop_daemon(repo_root)
                self.assertFalse(stopped.running)
                assert started.pid is not None
                self.assertTrue(_pid_has_exited(started.pid))
            finally:
                if repo_root.exists():
                    stop_daemon(repo_root)

    def test_prune_daemon_removes_stale_pid_and_socket_without_starting(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            repo_root = Path(tmp)
            _init_git_repo(repo_root)
            init_repo(repo_root)
            socket_path = repo_root / ".ait" / "daemon.sock"
            stale_server = bind_unix_socket(socket_path)
            stale_server.close()
            pid_file = repo_root / ".ait" / "daemon.pid"
            pid_file.write_text("not-a-pid\n", encoding="utf-8")

            pruned = prune_daemon(repo_root)

            self.assertFalse(pruned.running)
            self.assertFalse(socket_path.exists())
            self.assertFalse(pid_file.exists())
            self.assertIsNone(pruned.stale_reason)

    def test_serve_daemon_recovers_stale_running_attempts_on_startup(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            repo_root = Path(tmp)
            _init_git_repo(repo_root)
            init_repo(repo_root)
            conn = connect_db(repo_root / ".ait" / "state.sqlite3")
            try:
                run_migrations(conn)
                insert_intent(
                    conn,
                    NewIntent(
                        id="repo:01INTENT",
                        repo_id="repo",
                        title="Daemon startup recovery",
                        created_at="2026-04-23T00:00:00Z",
                        created_by_actor_type="agent",
                        created_by_actor_id="codex:worker",
                        trigger_source="cli",
                    ),
                )
                insert_attempt(
                    conn,
                    NewAttempt(
                        id="repo:01ATTEMPT",
                        intent_id="repo:01INTENT",
                        agent_id="codex:worker",
                        workspace_ref=str(repo_root / ".ait" / "workspaces" / "attempt"),
                        base_ref_oid="abc123",
                        started_at="2000-01-01T00:00:00Z",
                        heartbeat_at="2000-01-01T00:00:00Z",
                        ownership_token="token",
                        reported_status="running",
                    ),
                )
            finally:
                conn.close()

            def stop_after_recovery(**kwargs):
                daemon_conn = kwargs["conn"]
                attempt = get_attempt(daemon_conn, "repo:01ATTEMPT")
                assert attempt is not None
                self.assertEqual("crashed", attempt.reported_status)
                self.assertEqual("failed", attempt.verified_status)
                raise RuntimeError("stop daemon test")

            with patch("ait.daemon.run_accept_loop", stop_after_recovery):
                with self.assertRaisesRegex(RuntimeError, "stop daemon test"):
                    serve_daemon(repo_root)

    def test_start_daemon_recovers_running_attempt_after_sigkill(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            repo_root = Path(tmp)
            _init_git_repo(repo_root)
            init_repo(repo_root)
            config_path = repo_root / ".ait" / "config.json"
            config = json.loads(config_path.read_text(encoding="utf-8"))
            config["reaper_ttl_seconds"] = 1
            config["daemon_idle_timeout_seconds"] = 10
            config_path.write_text(json.dumps(config, sort_keys=True), encoding="utf-8")
            intent = create_intent(
                repo_root,
                title="Daemon sigkill recovery",
                description=None,
                kind="codex-run",
            )
            attempt = create_attempt(repo_root, intent_id=intent.intent_id, agent_id="codex:test")
            started = start_daemon(repo_root)
            self.assertTrue(started.running)
            self.assertIsNotNone(started.pid)
            harness = AitHarness.open(
                attempt_id=attempt.attempt_id,
                ownership_token=attempt.ownership_token,
                socket_path=started.socket_path,
                agent={"agent_id": "codex:test", "harness": "codex", "harness_version": "test"},
            )
            try:
                harness.start()
            finally:
                harness.close()

            assert started.pid is not None
            os.kill(started.pid, signal.SIGKILL)
            _wait_for_daemon_to_stop(repo_root)
            time.sleep(2.1)
            restarted = start_daemon(repo_root)

            try:
                self.assertTrue(restarted.running)
                recovered = _wait_for_attempt_status(
                    repo_root,
                    attempt.attempt_id,
                    reported_status="crashed",
                    verified_status="failed",
                )
                assert recovered is not None
                self.assertEqual("crashed", recovered.reported_status)
                self.assertEqual("failed", recovered.verified_status)
            finally:
                stop_daemon(repo_root)


def _init_git_repo(repo_root: Path) -> None:
    subprocess.run(["git", "init", "-q"], cwd=repo_root, check=True)
    subprocess.run(["git", "config", "user.email", "test@example.com"], cwd=repo_root, check=True)
    subprocess.run(["git", "config", "user.name", "Test"], cwd=repo_root, check=True)
    (repo_root / "README.md").write_text("test\n", encoding="utf-8")
    subprocess.run(["git", "add", "README.md"], cwd=repo_root, check=True)
    subprocess.run(["git", "commit", "-q", "-m", "init"], cwd=repo_root, check=True)


def _wait_for_daemon_to_stop(repo_root: Path) -> None:
    deadline = time.monotonic() + 5.0
    while time.monotonic() < deadline:
        if not daemon_status(repo_root).running:
            return
        time.sleep(0.05)
    raise AssertionError("daemon did not stop")


def _pid_has_exited(pid: int) -> bool:
    try:
        os.kill(pid, 0)
    except OSError:
        return True
    return False


def _wait_for_attempt_status(
    repo_root: Path,
    attempt_id: str,
    *,
    reported_status: str,
    verified_status: str,
):
    deadline = time.monotonic() + 5.0
    latest = None
    while time.monotonic() < deadline:
        conn = connect_db(repo_root / ".ait" / "state.sqlite3")
        try:
            latest = get_attempt(conn, attempt_id)
        finally:
            conn.close()
        if (
            latest is not None
            and latest.reported_status == reported_status
            and latest.verified_status == verified_status
        ):
            return latest
        time.sleep(0.05)
    return latest


if __name__ == "__main__":
    unittest.main()
