from unittest.mock import MagicMock, Mock, patch

import pytest
from azure.core.credentials import AccessToken, TokenCredential
from azure.core.exceptions import AzureError, ClientAuthenticationError

from azpaddypy.mgmt.identity import AzureIdentity
from azpaddypy.resources.speech import (
    AzureSpeech,
    _speech_instances,
    create_azure_speech,
)

TEST_RESOURCE_ID = "/subscriptions/sub-1/resourceGroups/rg-1/providers/Microsoft.CognitiveServices/accounts/speech-1"


@pytest.fixture(autouse=True)
def _clear_speech_cache():
    _speech_instances.clear()
    yield
    _speech_instances.clear()


@pytest.fixture
def mock_credential():
    cred = MagicMock(spec=TokenCredential)
    cred.get_token.return_value = AccessToken(token="test-token-value", expires_on=9999999999)
    return cred


@pytest.fixture
def mock_azure_identity(mock_credential):
    mock_identity = MagicMock(spec=AzureIdentity)
    mock_identity.get_credential.return_value = mock_credential
    return mock_identity


@pytest.fixture
def mock_logger():
    """Plain MagicMock logger - avoids spec pollution issues across the suite."""
    logger = MagicMock()
    span_ctx = MagicMock()
    span_ctx.__enter__.return_value = MagicMock()
    span_ctx.__exit__.return_value = None
    logger.create_span.return_value = span_ctx
    return logger


@pytest.fixture
def speech_client(mock_credential, mock_logger):
    """Configured AzureSpeech instance for testing."""
    return AzureSpeech(
        region="westeurope",
        resource_id=TEST_RESOURCE_ID,
        credential=mock_credential,
        logger=mock_logger,
        service_name="test_service",
    )


class TestInitialization:
    def test_successful_initialization(self, speech_client):
        assert speech_client.region == "westeurope"
        assert speech_client.resource_id == TEST_RESOURCE_ID
        assert speech_client.default_speech_synthesis_voice_name == "en-US-JennyNeural"
        assert speech_client.default_speech_recognition_language == "en-US"

    def test_initialization_with_custom_defaults(self, mock_credential, mock_logger):
        client = AzureSpeech(
            region="northeurope",
            resource_id=TEST_RESOURCE_ID,
            credential=mock_credential,
            logger=mock_logger,
            default_speech_recognition_language="de-DE",
            default_speech_synthesis_voice_name="de-DE-KatjaNeural",
        )
        assert client.default_speech_recognition_language == "de-DE"
        assert client.default_speech_synthesis_voice_name == "de-DE-KatjaNeural"

    def test_initialization_with_azure_identity(self, mock_azure_identity, mock_logger):
        client = AzureSpeech(
            region="westeurope",
            resource_id=TEST_RESOURCE_ID,
            azure_identity=mock_azure_identity,
            logger=mock_logger,
        )
        assert client.region == "westeurope"
        mock_azure_identity.get_credential.assert_called_once()

    def test_initialization_without_credential_raises(self, mock_logger):
        with pytest.raises(ValueError, match="Either 'credential' or 'azure_identity' must be provided"):
            AzureSpeech(region="westeurope", resource_id=TEST_RESOURCE_ID, logger=mock_logger)

    def test_initialization_without_region_raises(self, mock_credential, mock_logger):
        with pytest.raises(ValueError, match="'region' is required"):
            AzureSpeech(
                region="",
                resource_id=TEST_RESOURCE_ID,
                credential=mock_credential,
                logger=mock_logger,
            )

    def test_initialization_without_resource_id_raises(self, mock_credential, mock_logger):
        with pytest.raises(ValueError, match="'resource_id' is required"):
            AzureSpeech(
                region="westeurope",
                resource_id="",
                credential=mock_credential,
                logger=mock_logger,
            )


class TestAuthorizationToken:
    def test_get_authorization_token_format(self, speech_client):
        token_str = speech_client.get_authorization_token()

        assert token_str == f"aad#{TEST_RESOURCE_ID}#test-token-value"

    def test_get_authorization_token_uses_correct_scope(self, speech_client, mock_credential):
        speech_client.get_authorization_token()

        mock_credential.get_token.assert_called_with("https://cognitiveservices.azure.com/.default")

    def test_get_authorization_token_auth_failure(self, speech_client, mock_credential):
        mock_credential.get_token.side_effect = ClientAuthenticationError("auth failed")

        with pytest.raises(ClientAuthenticationError):
            speech_client.get_authorization_token()


class TestSpeechConfig:
    def test_get_speech_config(self, speech_client):
        with patch("azpaddypy.resources.speech.speechsdk.SpeechConfig") as mock_config_class:
            mock_config = MagicMock()
            mock_config_class.return_value = mock_config

            result = speech_client.get_speech_config()

            assert result == mock_config
            mock_config_class.assert_called_once_with(
                auth_token=f"aad#{TEST_RESOURCE_ID}#test-token-value",
                region="westeurope",
            )

    def test_get_speech_config_applies_defaults(self, speech_client):
        with patch("azpaddypy.resources.speech.speechsdk.SpeechConfig") as mock_config_class:
            mock_config = MagicMock()
            mock_config_class.return_value = mock_config

            speech_client.get_speech_config()

            assert mock_config.speech_recognition_language == "en-US"
            assert mock_config.speech_synthesis_voice_name == "en-US-JennyNeural"

    def test_get_speech_config_overrides(self, speech_client):
        with patch("azpaddypy.resources.speech.speechsdk.SpeechConfig") as mock_config_class:
            mock_config = MagicMock()
            mock_config_class.return_value = mock_config

            speech_client.get_speech_config(
                speech_recognition_language="fr-FR",
                speech_synthesis_voice_name="fr-FR-DeniseNeural",
            )

            assert mock_config.speech_recognition_language == "fr-FR"
            assert mock_config.speech_synthesis_voice_name == "fr-FR-DeniseNeural"

    def test_get_speech_config_with_output_format(self, speech_client):
        with patch("azpaddypy.resources.speech.speechsdk.SpeechConfig") as mock_config_class:
            mock_config = MagicMock()
            mock_config_class.return_value = mock_config
            output_format = Mock()

            speech_client.get_speech_config(speech_synthesis_output_format=output_format)

            mock_config.set_speech_synthesis_output_format.assert_called_once_with(output_format)


class TestRefreshAuthorizationToken:
    def test_refresh_token_on_synthesizer(self, speech_client):
        mock_synthesizer = MagicMock()

        speech_client.refresh_authorization_token(mock_synthesizer)

        assert mock_synthesizer.authorization_token == f"aad#{TEST_RESOURCE_ID}#test-token-value"

    def test_refresh_token_failure(self, speech_client, mock_credential):
        mock_credential.get_token.side_effect = ClientAuthenticationError("expired")
        mock_target = MagicMock()

        with pytest.raises(ClientAuthenticationError):
            speech_client.refresh_authorization_token(mock_target)


class TestSynthesizeText:
    def test_synthesize_success(self, speech_client):
        with (
            patch("azpaddypy.resources.speech.speechsdk.SpeechConfig"),
            patch("azpaddypy.resources.speech.speechsdk.SpeechSynthesizer") as mock_synth_class,
        ):
            from azure.cognitiveservices.speech import ResultReason

            mock_result = MagicMock()
            mock_result.reason = ResultReason.SynthesizingAudioCompleted
            mock_result.audio_data = b"fake-audio-bytes"

            mock_future = MagicMock()
            mock_future.get.return_value = mock_result

            mock_synth = MagicMock()
            mock_synth.speak_text_async.return_value = mock_future
            mock_synth_class.return_value = mock_synth

            audio = speech_client.synthesize_text_to_bytes("Hello world")

            assert audio == b"fake-audio-bytes"
            mock_synth.speak_text_async.assert_called_once_with("Hello world")

    def test_synthesize_canceled_raises(self, speech_client):
        with (
            patch("azpaddypy.resources.speech.speechsdk.SpeechConfig"),
            patch("azpaddypy.resources.speech.speechsdk.SpeechSynthesizer") as mock_synth_class,
        ):
            from azure.cognitiveservices.speech import ResultReason

            mock_cancel = MagicMock()
            mock_cancel.reason = "Error"
            mock_cancel.error_details = "Auth failed"

            mock_result = MagicMock()
            mock_result.reason = ResultReason.Canceled
            mock_result.cancellation_details = mock_cancel

            mock_future = MagicMock()
            mock_future.get.return_value = mock_result

            mock_synth = MagicMock()
            mock_synth.speak_text_async.return_value = mock_future
            mock_synth_class.return_value = mock_synth

            with pytest.raises(AzureError, match="canceled"):
                speech_client.synthesize_text_to_bytes("Hello")

    def test_synthesize_to_file(self, speech_client):
        with (
            patch("azpaddypy.resources.speech.speechsdk.SpeechConfig"),
            patch("azpaddypy.resources.speech.speechsdk.SpeechSynthesizer") as mock_synth_class,
            patch("azpaddypy.resources.speech.speechsdk.audio.AudioOutputConfig") as mock_audio_cfg,
        ):
            from azure.cognitiveservices.speech import ResultReason

            mock_result = MagicMock()
            mock_result.reason = ResultReason.SynthesizingAudioCompleted
            mock_result.audio_data = b"abc"

            mock_future = MagicMock()
            mock_future.get.return_value = mock_result

            mock_synth = MagicMock()
            mock_synth.speak_text_async.return_value = mock_future
            mock_synth_class.return_value = mock_synth

            speech_client.synthesize_text_to_file("Hello", "out.wav")

            mock_audio_cfg.assert_called_once_with(filename="out.wav")
            mock_synth.speak_text_async.assert_called_once_with("Hello")

    def test_synthesize_to_speaker(self, speech_client):
        with (
            patch("azpaddypy.resources.speech.speechsdk.SpeechConfig"),
            patch("azpaddypy.resources.speech.speechsdk.SpeechSynthesizer") as mock_synth_class,
            patch("azpaddypy.resources.speech.speechsdk.audio.AudioOutputConfig") as mock_audio_cfg,
        ):
            from azure.cognitiveservices.speech import ResultReason

            mock_result = MagicMock()
            mock_result.reason = ResultReason.SynthesizingAudioCompleted
            mock_result.audio_data = b"abc"

            mock_future = MagicMock()
            mock_future.get.return_value = mock_result

            mock_synth = MagicMock()
            mock_synth.speak_text_async.return_value = mock_future
            mock_synth_class.return_value = mock_synth

            speech_client.synthesize_text_to_speaker("Hello")

            mock_audio_cfg.assert_called_once_with(use_default_speaker=True)


class TestConnectionTest:
    def test_connection_test_success(self, speech_client):
        with patch("azpaddypy.resources.speech.speechsdk.SpeechConfig"):
            assert speech_client.test_connection() is True

    def test_connection_test_failure(self, speech_client, mock_credential):
        mock_credential.get_token.side_effect = ClientAuthenticationError("auth failed")

        assert speech_client.test_connection() is False


class TestCorrelationId:
    def test_set_correlation_id(self, speech_client):
        from azpaddypy.mgmt.logging import AzureLogger

        speech_client.set_correlation_id("corr-456")
        assert AzureLogger.correlation_id() == "corr-456"

    def test_get_correlation_id(self, speech_client):
        from azpaddypy.mgmt.logging import AzureLogger

        AzureLogger.set_correlation_id("corr-456")
        assert speech_client.get_correlation_id() == "corr-456"


class TestFactory:
    def test_factory_creates_new_instance(self, mock_credential, mock_logger):
        client = create_azure_speech(
            region="westeurope",
            resource_id=TEST_RESOURCE_ID,
            credential=mock_credential,
            logger=mock_logger,
            service_name="factory_test",
        )
        assert client.service_name == "factory_test"

    def test_factory_returns_cached(self, mock_credential, mock_logger):
        c1 = create_azure_speech(
            region="westeurope",
            resource_id=TEST_RESOURCE_ID,
            credential=mock_credential,
            logger=mock_logger,
            service_name="cache_test",
        )
        c2 = create_azure_speech(
            region="westeurope",
            resource_id=TEST_RESOURCE_ID,
            credential=mock_credential,
            logger=mock_logger,
            service_name="cache_test",
        )
        assert c1 is c2

    def test_factory_auto_creates_identity(self, mock_logger, mock_credential):
        with patch("azpaddypy.mgmt.identity.create_azure_identity") as mock_create_identity:
            mock_identity = Mock(spec=AzureIdentity)
            mock_identity.get_credential.return_value = mock_credential
            mock_create_identity.return_value = mock_identity

            client = create_azure_speech(
                region="westeurope",
                resource_id=TEST_RESOURCE_ID,
                logger=mock_logger,
                service_name="auto_id_test",
            )
            assert client is not None
            mock_create_identity.assert_called_once()
