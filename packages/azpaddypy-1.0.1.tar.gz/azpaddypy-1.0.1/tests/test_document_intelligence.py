from unittest.mock import MagicMock, Mock, patch

import pytest
from azure.core.credentials import TokenCredential
from azure.core.exceptions import AzureError, ClientAuthenticationError, ResourceNotFoundError

from azpaddypy.mgmt.identity import AzureIdentity
from azpaddypy.resources.document_intelligence import (
    AzureDocumentIntelligence,
    _document_intelligence_instances,
    create_azure_document_intelligence,
)


@pytest.fixture(autouse=True)
def _clear_di_cache():
    _document_intelligence_instances.clear()
    yield
    _document_intelligence_instances.clear()


@pytest.fixture
def mock_credential():
    return MagicMock(spec=TokenCredential)


@pytest.fixture
def mock_azure_identity():
    mock_identity = MagicMock(spec=AzureIdentity)
    mock_identity.get_credential.return_value = MagicMock(spec=TokenCredential)
    return mock_identity


@pytest.fixture
def mock_logger():
    """Plain MagicMock logger - avoids spec pollution issues across the suite."""
    logger = MagicMock()
    span_ctx = MagicMock()
    span_ctx.__enter__.return_value = MagicMock()
    span_ctx.__exit__.return_value = None
    logger.create_span.return_value = span_ctx
    return logger


@pytest.fixture
def patched_di():
    """Patch SDK clients; keep patches active for the whole test."""
    with (
        patch("azpaddypy.resources.document_intelligence.DocumentIntelligenceClient") as mock_client,
        patch("azpaddypy.resources.document_intelligence.DocumentIntelligenceAdministrationClient") as mock_admin,
    ):
        mock_client.return_value = MagicMock()
        mock_admin.return_value = MagicMock()
        yield mock_client, mock_admin


@pytest.fixture
def doc_intel(mock_credential, mock_logger, patched_di):
    """Configured AzureDocumentIntelligence with both clients enabled."""
    di = AzureDocumentIntelligence(
        endpoint="https://test.cognitiveservices.azure.com/",
        credential=mock_credential,
        logger=mock_logger,
        service_name="test_service",
        enable_analysis=True,
        enable_administration=True,
    )
    # Trigger lazy construction so tests can set up mocks on the clients
    di._ensure_client()
    di._ensure_admin_client()
    return di


class TestInitialization:
    def test_successful_initialization(self, mock_credential, mock_logger, patched_di):
        di = AzureDocumentIntelligence(
            endpoint="https://test.cognitiveservices.azure.com/",
            credential=mock_credential,
            logger=mock_logger,
        )

        assert di.endpoint == "https://test.cognitiveservices.azure.com/"
        assert di.enable_analysis is True
        assert di.enable_administration is False
        assert di.client is None  # Lazy: constructed on first use
        assert di.admin_client is None

    def test_initialization_with_admin_enabled(self, doc_intel):
        assert doc_intel.enable_analysis is True
        assert doc_intel.enable_administration is True

    def test_initialization_with_azure_identity(self, mock_azure_identity, mock_logger, patched_di):
        di = AzureDocumentIntelligence(
            endpoint="https://test.cognitiveservices.azure.com/",
            azure_identity=mock_azure_identity,
            logger=mock_logger,
        )
        assert di.client is None  # Lazy: constructed on first use
        mock_azure_identity.get_credential.assert_called_once()

    def test_initialization_without_credential_raises(self, mock_logger, patched_di):
        with pytest.raises(ValueError, match="Either 'credential' or 'azure_identity' must be provided"):
            AzureDocumentIntelligence(
                endpoint="https://test.cognitiveservices.azure.com/",
                logger=mock_logger,
            )


class TestAnalyzeDocument:
    def test_analyze_from_url(self, doc_intel):
        mock_result = Mock()
        mock_result.pages = [Mock(), Mock()]
        mock_poller = Mock()
        mock_poller.result.return_value = mock_result
        doc_intel.client.begin_analyze_document.return_value = mock_poller

        result = doc_intel.analyze_document_from_url(
            model_id="prebuilt-read",
            url_source="https://example.com/doc.pdf",
        )

        assert result == mock_result
        doc_intel.client.begin_analyze_document.assert_called_once()

    def test_analyze_from_url_auth_error(self, doc_intel):
        doc_intel.client.begin_analyze_document.side_effect = ClientAuthenticationError("auth")
        with pytest.raises(ClientAuthenticationError):
            doc_intel.analyze_document_from_url(
                model_id="prebuilt-read",
                url_source="https://example.com/doc.pdf",
            )

    def test_analyze_from_url_azure_error(self, doc_intel):
        doc_intel.client.begin_analyze_document.side_effect = AzureError("server error")
        with pytest.raises(AzureError):
            doc_intel.analyze_document_from_url(
                model_id="prebuilt-read",
                url_source="https://example.com/doc.pdf",
            )

    def test_analyze_from_bytes(self, doc_intel):
        mock_result = Mock()
        mock_result.pages = [Mock()]
        mock_poller = Mock()
        mock_poller.result.return_value = mock_result
        doc_intel.client.begin_analyze_document.return_value = mock_poller

        result = doc_intel.analyze_document_from_bytes(
            model_id="prebuilt-layout",
            document=b"%PDF-1.4...",
        )

        assert result == mock_result

    def test_analyze_raises_when_disabled(self, mock_credential, mock_logger, patched_di):
        di = AzureDocumentIntelligence(
            endpoint="https://test.cognitiveservices.azure.com/",
            credential=mock_credential,
            logger=mock_logger,
            enable_analysis=False,
        )
        with pytest.raises(RuntimeError, match="Document analysis not enabled"):
            di.analyze_document_from_url(model_id="prebuilt-read", url_source="https://x/y.pdf")


class TestModelAdministration:
    def test_list_models(self, doc_intel):
        mock_model_a = Mock()
        mock_model_a.as_dict.return_value = {"modelId": "a"}
        mock_model_b = Mock()
        mock_model_b.as_dict.return_value = {"modelId": "b"}
        doc_intel.admin_client.list_models.return_value = [mock_model_a, mock_model_b]

        models = doc_intel.list_models()

        assert len(models) == 2
        assert models[0]["modelId"] == "a"

    def test_get_model_found(self, doc_intel):
        mock_model = Mock()
        mock_model.as_dict.return_value = {"modelId": "custom-1", "status": "ready"}
        doc_intel.admin_client.get_model.return_value = mock_model

        result = doc_intel.get_model(model_id="custom-1")

        assert result == {"modelId": "custom-1", "status": "ready"}

    def test_get_model_not_found(self, doc_intel):
        doc_intel.admin_client.get_model.side_effect = ResourceNotFoundError("missing")

        result = doc_intel.get_model(model_id="missing")

        assert result is None

    def test_delete_model_success(self, doc_intel):
        result = doc_intel.delete_model(model_id="custom-1")

        assert result is True
        doc_intel.admin_client.delete_model.assert_called_once_with(model_id="custom-1")

    def test_delete_model_not_found(self, doc_intel):
        doc_intel.admin_client.delete_model.side_effect = ResourceNotFoundError("missing")

        result = doc_intel.delete_model(model_id="missing")

        assert result is False

    def test_admin_raises_when_disabled(self, mock_credential, mock_logger, patched_di):
        di = AzureDocumentIntelligence(
            endpoint="https://test.cognitiveservices.azure.com/",
            credential=mock_credential,
            logger=mock_logger,
            enable_administration=False,
        )
        with pytest.raises(RuntimeError, match="Document administration not enabled"):
            di.list_models()


class TestConnectionTest:
    def test_connection_test_success(self, doc_intel):
        doc_intel.admin_client.list_models.return_value = []

        assert doc_intel.test_connection() is True

    def test_connection_test_failure(self, doc_intel):
        doc_intel.admin_client.list_models.side_effect = AzureError("network down")

        assert doc_intel.test_connection() is False

    def test_connection_test_no_clients(self, mock_credential, mock_logger, patched_di):
        di = AzureDocumentIntelligence(
            endpoint="https://test.cognitiveservices.azure.com/",
            credential=mock_credential,
            logger=mock_logger,
            enable_analysis=False,
            enable_administration=False,
        )
        assert di.test_connection() is False


class TestCorrelationId:
    def test_set_correlation_id(self, doc_intel):
        from azpaddypy.mgmt.logging import AzureLogger

        doc_intel.set_correlation_id("corr-123")
        assert AzureLogger.correlation_id() == "corr-123"

    def test_get_correlation_id(self, doc_intel):
        from azpaddypy.mgmt.logging import AzureLogger

        AzureLogger.set_correlation_id("corr-123")
        assert doc_intel.get_correlation_id() == "corr-123"


class TestFactory:
    def test_factory_creates_new_instance(self, mock_credential, mock_logger, patched_di):
        di = create_azure_document_intelligence(
            endpoint="https://test.cognitiveservices.azure.com/",
            credential=mock_credential,
            logger=mock_logger,
            service_name="factory_test",
        )
        assert di.service_name == "factory_test"

    def test_factory_returns_cached(self, mock_credential, mock_logger, patched_di):
        di1 = create_azure_document_intelligence(
            endpoint="https://test.cognitiveservices.azure.com/",
            credential=mock_credential,
            logger=mock_logger,
            service_name="cache_test",
        )
        di2 = create_azure_document_intelligence(
            endpoint="https://test.cognitiveservices.azure.com/",
            credential=mock_credential,
            logger=mock_logger,
            service_name="cache_test",
        )
        assert di1 is di2

    def test_factory_auto_creates_identity(self, mock_logger, patched_di):
        with patch("azpaddypy.mgmt.identity.create_azure_identity") as mock_create_identity:
            mock_identity = MagicMock(spec=AzureIdentity)
            mock_identity.get_credential.return_value = MagicMock(spec=TokenCredential)
            mock_create_identity.return_value = mock_identity

            di = create_azure_document_intelligence(
                endpoint="https://test.cognitiveservices.azure.com/",
                logger=mock_logger,
                service_name="auto_id_test",
            )
            assert di is not None
            mock_create_identity.assert_called_once()
