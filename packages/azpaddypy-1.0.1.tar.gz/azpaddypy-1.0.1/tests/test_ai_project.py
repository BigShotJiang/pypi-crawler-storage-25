from unittest.mock import MagicMock, Mock, patch

import pytest
from azure.core.credentials import TokenCredential
from azure.core.exceptions import AzureError, ClientAuthenticationError, ResourceNotFoundError

from azpaddypy.mgmt.identity import AzureIdentity
from azpaddypy.mgmt.logging import AzureLogger
from azpaddypy.resources.ai_project import (
    AzureAIProject,
    _ai_project_instances,
    create_azure_ai_project,
)


@pytest.fixture
def mock_credential():
    """Mock TokenCredential for testing."""
    return Mock(spec=TokenCredential)


@pytest.fixture
def mock_azure_identity():
    """Mock AzureIdentity instance for testing."""
    mock_identity = Mock(spec=AzureIdentity)
    mock_credential = Mock(spec=TokenCredential)
    mock_identity.get_credential.return_value = mock_credential
    return mock_identity


@pytest.fixture
def mock_logger():
    """Mock AzureLogger with tracer support."""
    mock_logger = Mock(spec=AzureLogger)
    mock_span = MagicMock()
    mock_context_manager = MagicMock()
    mock_context_manager.__enter__.return_value = mock_span
    mock_context_manager.__exit__.return_value = None
    mock_logger.create_span.return_value = mock_context_manager
    return mock_logger


@pytest.fixture
def azure_ai_project(mock_credential, mock_logger):
    """Configured AzureAIProject instance for testing."""
    with patch("azpaddypy.resources.ai_project.AIProjectClient") as mock_client_class:
        mock_client_class.return_value = Mock()
        with patch("azpaddypy.resources._base.setup_logger", return_value=mock_logger):
            project = AzureAIProject(
                endpoint="https://test.services.ai.azure.com/api/projects/test-project",
                credential=mock_credential,
                service_name="test_service",
            )
            # Trigger lazy construction while mock is active
            project._ensure_client()
            yield project


class TestAzureAIProjectInitialization:
    """Test AzureAIProject initialization and configuration."""

    def test_successful_initialization(self, mock_credential, mock_logger):
        with patch("azpaddypy.resources.ai_project.AIProjectClient") as mock_client_class:
            mock_client_class.return_value = Mock()
            with patch("azpaddypy.resources._base.setup_logger", return_value=mock_logger):
                project = AzureAIProject(
                    endpoint="https://test.services.ai.azure.com/api/projects/test-project",
                    credential=mock_credential,
                    service_name="test_service",
                    service_version="2.0.0",
                )

                assert project.endpoint == "https://test.services.ai.azure.com/api/projects/test-project"
                assert project.service_name == "test_service"
                assert project.service_version == "2.0.0"
                assert project.enable_agents is True
                assert project.enable_deployments is True
                assert project.enable_connections is True
                assert project.client is None  # Lazy: constructed on first use

    def test_initialization_with_azure_identity(self, mock_azure_identity, mock_logger):
        with patch("azpaddypy.resources.ai_project.AIProjectClient") as mock_client_class:
            mock_client_class.return_value = Mock()
            with patch("azpaddypy.resources._base.setup_logger", return_value=mock_logger):
                project = AzureAIProject(
                    endpoint="https://test.services.ai.azure.com/api/projects/test-project",
                    azure_identity=mock_azure_identity,
                )

                assert project.client is None  # Lazy: constructed on first use
                mock_azure_identity.get_credential.assert_called_once()

    def test_initialization_without_credential_raises(self, mock_logger):
        with patch("azpaddypy.resources._base.setup_logger", return_value=mock_logger):
            with pytest.raises(ValueError, match="Either 'credential' or 'azure_identity' must be provided"):
                AzureAIProject(
                    endpoint="https://test.services.ai.azure.com/api/projects/test-project",
                )

    def test_initialization_with_feature_flags_disabled(self, mock_credential, mock_logger):
        with patch("azpaddypy.resources.ai_project.AIProjectClient") as mock_client_class:
            mock_client_class.return_value = Mock()
            with patch("azpaddypy.resources._base.setup_logger", return_value=mock_logger):
                project = AzureAIProject(
                    endpoint="https://test.services.ai.azure.com/api/projects/test-project",
                    credential=mock_credential,
                    enable_agents=False,
                    enable_deployments=False,
                    enable_connections=False,
                )

                assert project.enable_agents is False
                assert project.enable_deployments is False
                assert project.enable_connections is False

    def test_initialization_client_failure_raises_on_first_use(self, mock_credential, mock_logger):
        """Client construction failure surfaces on first use, not at init (lazy)."""
        with patch("azpaddypy.resources.ai_project.AIProjectClient") as mock_client_class:
            mock_client_class.side_effect = AzureError("Connection failed")
            with patch("azpaddypy.resources._base.setup_logger", return_value=mock_logger):
                project = AzureAIProject(
                    endpoint="https://test.services.ai.azure.com/api/projects/test-project",
                    credential=mock_credential,
                )
                # Init succeeds (lazy), but first use fails
                with pytest.raises(AzureError, match="Connection failed"):
                    project._ensure_client()


class TestAgentOperations:
    """Test agent CRUD operations."""

    def test_create_agent(self, azure_ai_project):
        mock_definition = Mock()
        mock_version = Mock()
        mock_version.version = "v1"
        azure_ai_project.client.agents.create_version.return_value = mock_version

        result = azure_ai_project.create_agent(
            agent_name="test-agent",
            definition=mock_definition,
            description="A test agent",
        )

        assert result == mock_version
        azure_ai_project.client.agents.create_version.assert_called_once_with(
            agent_name="test-agent",
            definition=mock_definition,
            description="A test agent",
            metadata=None,
        )

    def test_create_agent_raises_when_disabled(self, mock_credential, mock_logger):
        with patch("azpaddypy.resources.ai_project.AIProjectClient") as mock_client_class:
            mock_client_class.return_value = Mock()
            with patch("azpaddypy.resources._base.setup_logger", return_value=mock_logger):
                project = AzureAIProject(
                    endpoint="https://test.services.ai.azure.com/api/projects/test-project",
                    credential=mock_credential,
                    enable_agents=False,
                )

                with pytest.raises(RuntimeError, match="Agent operations not enabled"):
                    project.create_agent(agent_name="test", definition=Mock())

    def test_get_agent_found(self, azure_ai_project):
        mock_agent = Mock()
        mock_agent.name = "test-agent"
        azure_ai_project.client.agents.get.return_value = mock_agent

        result = azure_ai_project.get_agent(agent_name="test-agent")

        assert result == mock_agent

    def test_get_agent_not_found(self, azure_ai_project):
        azure_ai_project.client.agents.get.side_effect = ResourceNotFoundError("Not found")

        result = azure_ai_project.get_agent(agent_name="missing-agent")

        assert result is None

    def test_get_agent_auth_error(self, azure_ai_project):
        azure_ai_project.client.agents.get.side_effect = ClientAuthenticationError("Auth failed")

        with pytest.raises(ClientAuthenticationError):
            azure_ai_project.get_agent(agent_name="test-agent")

    def test_list_agents(self, azure_ai_project):
        mock_agents = [Mock(), Mock()]
        azure_ai_project.client.agents.list.return_value = mock_agents

        result = azure_ai_project.list_agents()

        assert len(result) == 2

    def test_delete_agent_success(self, azure_ai_project):
        result = azure_ai_project.delete_agent(agent_name="test-agent")

        assert result is True
        azure_ai_project.client.agents.delete.assert_called_once_with(agent_name="test-agent")

    def test_delete_agent_not_found(self, azure_ai_project):
        azure_ai_project.client.agents.delete.side_effect = ResourceNotFoundError("Not found")

        result = azure_ai_project.delete_agent(agent_name="missing-agent")

        assert result is False

    def test_invoke_agent(self, azure_ai_project):
        mock_openai = Mock()
        mock_response = Mock()
        mock_response.id = "resp_123"
        mock_response.status = "completed"
        mock_response.output_text = "Hello from agent"
        mock_openai.responses.create.return_value = mock_response
        azure_ai_project.client.get_openai_client.return_value = mock_openai

        result = azure_ai_project.invoke_agent(
            agent_name="test-agent",
            user_message="Hello",
        )

        assert result["response_id"] == "resp_123"
        assert result["status"] == "completed"
        assert result["response"] == "Hello from agent"


class TestDeploymentOperations:
    """Test deployment operations."""

    def test_list_deployments(self, azure_ai_project):
        mock_deployments = [Mock(), Mock(), Mock()]
        azure_ai_project.client.deployments.list.return_value = mock_deployments

        result = azure_ai_project.list_deployments()

        assert len(result) == 3

    def test_list_deployments_with_filters(self, azure_ai_project):
        azure_ai_project.client.deployments.list.return_value = [Mock()]

        result = azure_ai_project.list_deployments(
            model_publisher="Microsoft",
            model_name="gpt-4o",
        )

        assert len(result) == 1
        azure_ai_project.client.deployments.list.assert_called_once_with(
            model_publisher="Microsoft",
            model_name="gpt-4o",
            deployment_type=None,
        )

    def test_list_deployments_raises_when_disabled(self, mock_credential, mock_logger):
        with patch("azpaddypy.resources.ai_project.AIProjectClient") as mock_client_class:
            mock_client_class.return_value = Mock()
            with patch("azpaddypy.resources._base.setup_logger", return_value=mock_logger):
                project = AzureAIProject(
                    endpoint="https://test.services.ai.azure.com/api/projects/test-project",
                    credential=mock_credential,
                    enable_deployments=False,
                )

                with pytest.raises(RuntimeError, match="Deployment operations not enabled"):
                    project.list_deployments()

    def test_get_deployment_found(self, azure_ai_project):
        mock_deployment = Mock()
        mock_deployment.name = "gpt-4o"
        azure_ai_project.client.deployments.get.return_value = mock_deployment

        result = azure_ai_project.get_deployment(name="gpt-4o")

        assert result == mock_deployment

    def test_get_deployment_not_found(self, azure_ai_project):
        azure_ai_project.client.deployments.get.side_effect = ResourceNotFoundError("Not found")

        result = azure_ai_project.get_deployment(name="missing")

        assert result is None


class TestConnectionOperations:
    """Test connection operations."""

    def test_list_connections(self, azure_ai_project):
        mock_connections = [Mock(), Mock()]
        azure_ai_project.client.connections.list.return_value = mock_connections

        result = azure_ai_project.list_connections()

        assert len(result) == 2

    def test_get_connection_found(self, azure_ai_project):
        mock_connection = Mock()
        mock_connection.name = "my-connection"
        azure_ai_project.client.connections.get.return_value = mock_connection

        result = azure_ai_project.get_connection(name="my-connection")

        assert result == mock_connection

    def test_get_connection_not_found(self, azure_ai_project):
        azure_ai_project.client.connections.get.side_effect = ResourceNotFoundError("Not found")

        result = azure_ai_project.get_connection(name="missing")

        assert result is None

    def test_get_connection_with_credentials(self, azure_ai_project):
        mock_connection = Mock()
        azure_ai_project.client.connections.get.return_value = mock_connection

        azure_ai_project.get_connection(name="my-conn", include_credentials=True)

        azure_ai_project.client.connections.get.assert_called_once_with(
            name="my-conn",
            include_credentials=True,
        )

    def test_get_default_connection(self, azure_ai_project):
        from azure.ai.projects.models import ConnectionType

        mock_connection = Mock()
        azure_ai_project.client.connections.get_default.return_value = mock_connection

        result = azure_ai_project.get_default_connection(
            connection_type=ConnectionType.AZURE_OPEN_AI,
        )

        assert result == mock_connection

    def test_get_default_connection_not_found(self, azure_ai_project):
        from azure.ai.projects.models import ConnectionType

        azure_ai_project.client.connections.get_default.side_effect = ResourceNotFoundError("Not found")

        result = azure_ai_project.get_default_connection(
            connection_type=ConnectionType.AZURE_OPEN_AI,
        )

        assert result is None

    def test_connections_raises_when_disabled(self, mock_credential, mock_logger):
        with patch("azpaddypy.resources.ai_project.AIProjectClient") as mock_client_class:
            mock_client_class.return_value = Mock()
            with patch("azpaddypy.resources._base.setup_logger", return_value=mock_logger):
                project = AzureAIProject(
                    endpoint="https://test.services.ai.azure.com/api/projects/test-project",
                    credential=mock_credential,
                    enable_connections=False,
                )

                with pytest.raises(RuntimeError, match="Connection operations not enabled"):
                    project.list_connections()


class TestOpenAIClient:
    """Test OpenAI client retrieval."""

    def test_get_openai_client(self, azure_ai_project):
        mock_openai = Mock()
        azure_ai_project.client.get_openai_client.return_value = mock_openai

        result = azure_ai_project.get_openai_client()

        assert result == mock_openai

    def test_get_openai_client_failure(self, azure_ai_project):
        azure_ai_project.client.get_openai_client.side_effect = AzureError("Failed")

        with pytest.raises(AzureError):
            azure_ai_project.get_openai_client()


class TestConnectionTest:
    """Test connection testing."""

    def test_connection_test_success(self, azure_ai_project):
        azure_ai_project.client.deployments.list.return_value = []

        result = azure_ai_project.test_connection()

        assert result is True

    def test_connection_test_failure(self, azure_ai_project):
        azure_ai_project.client.deployments.list.side_effect = AzureError("Connection refused")

        result = azure_ai_project.test_connection()

        assert result is False


class TestCorrelationId:
    """Test correlation ID management -- backed by the process-wide contextvar."""

    def test_set_correlation_id(self, azure_ai_project):
        from azpaddypy.mgmt.logging import AzureLogger

        azure_ai_project.set_correlation_id("test-correlation-123")
        assert AzureLogger.correlation_id() == "test-correlation-123"

    def test_get_correlation_id(self, azure_ai_project):
        from azpaddypy.mgmt.logging import AzureLogger

        AzureLogger.set_correlation_id("test-correlation-123")
        assert azure_ai_project.get_correlation_id() == "test-correlation-123"


class TestFactoryFunction:
    """Test create_azure_ai_project factory function."""

    def test_factory_creates_new_instance(self, mock_credential, mock_logger):
        _ai_project_instances.clear()

        with patch("azpaddypy.resources.ai_project.AIProjectClient") as mock_client_class:
            mock_client_class.return_value = Mock()
            with patch("azpaddypy.resources._base.setup_logger", return_value=mock_logger):
                project = create_azure_ai_project(
                    endpoint="https://test.services.ai.azure.com/api/projects/test-project",
                    credential=mock_credential,
                    service_name="factory_test",
                )

                assert project is not None
                assert project.service_name == "factory_test"

    def test_factory_returns_cached_instance(self, mock_credential, mock_logger):
        _ai_project_instances.clear()

        with patch("azpaddypy.resources.ai_project.AIProjectClient") as mock_client_class:
            mock_client_class.return_value = Mock()
            with patch("azpaddypy.resources._base.setup_logger", return_value=mock_logger):
                project1 = create_azure_ai_project(
                    endpoint="https://test.services.ai.azure.com/api/projects/test-project",
                    credential=mock_credential,
                    service_name="cache_test",
                )
                project2 = create_azure_ai_project(
                    endpoint="https://test.services.ai.azure.com/api/projects/test-project",
                    credential=mock_credential,
                    service_name="cache_test",
                )

                assert project1 is project2

    def test_factory_auto_creates_identity(self, mock_logger):
        _ai_project_instances.clear()

        with (
            patch("azpaddypy.resources.ai_project.AIProjectClient") as mock_client_class,
            patch("azpaddypy.resources._base.setup_logger", return_value=mock_logger),
            patch("azpaddypy.mgmt.identity.create_azure_identity") as mock_create_identity,
        ):
            mock_client_class.return_value = Mock()
            mock_identity = Mock(spec=AzureIdentity)
            mock_identity.get_credential.return_value = Mock(spec=TokenCredential)
            mock_create_identity.return_value = mock_identity

            project = create_azure_ai_project(
                endpoint="https://test.services.ai.azure.com/api/projects/test-project",
                service_name="auto_identity_test",
            )

            assert project is not None
            mock_create_identity.assert_called_once()


class TestEnsureClientNone:
    """Test behavior when client is None."""

    def test_ensure_client_constructs_lazily_when_none(self, mock_credential, mock_logger):
        """With lazy loading, setting client=None triggers reconstruction on next use."""
        with patch("azpaddypy.resources.ai_project.AIProjectClient") as mock_client_class:
            mock_client_class.return_value = Mock()
            with patch("azpaddypy.resources._base.setup_logger", return_value=mock_logger):
                project = AzureAIProject(
                    endpoint="https://test.services.ai.azure.com/api/projects/test-project",
                    credential=mock_credential,
                )
                project.client = None
                # Lazy: _ensure_client reconstructs rather than raising
                client = project._ensure_client()
                assert client is not None
