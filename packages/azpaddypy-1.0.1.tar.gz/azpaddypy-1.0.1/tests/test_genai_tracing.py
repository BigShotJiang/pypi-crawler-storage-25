"""
GenAI / AI Foundry instrumentation tests.

After the logging refactor, instrumentation belongs to ``bootstrap_azure_monitor``
(a process-wide, one-shot concern) rather than ``AzureLogger.__init__``. These
tests exercise the bootstrap flags and confirm that loggers created afterward
behave correctly for both Foundry and non-Foundry apps.
"""

from __future__ import annotations

import os
from unittest.mock import patch

import pytest

from azpaddypy.mgmt.logging import AzureLogger, bootstrap_azure_monitor


@pytest.fixture(
    params=["asyncio"],
)
def anyio_backend(request):
    """Force anyio to use asyncio backend."""
    return request.param


_GENAI_ENV_VARS = (
    "OTEL_INSTRUMENTATION_GENAI_CAPTURE_MESSAGE_CONTENT",
    "AZURE_TRACING_GEN_AI_CONTENT_RECORDING_ENABLED",
    "AZURE_TRACING_GEN_AI_ENABLE_TRACE_CONTEXT_PROPAGATION",
    "AZURE_EXPERIMENTAL_ENABLE_GENAI_TRACING",
)


@pytest.fixture(autouse=True)
def _clean_genai_env():
    """Clean GenAI env vars before/after each test (conftest handles bootstrap)."""
    for name in _GENAI_ENV_VARS:
        os.environ.pop(name, None)
    yield
    for name in _GENAI_ENV_VARS:
        os.environ.pop(name, None)


def _mock_exporter():
    """Patch configure_azure_monitor so tests do not make network calls."""
    return patch("azpaddypy.mgmt.logging.configure_azure_monitor")


class TestGenAIInstrumentorActivation:
    """OpenAIInstrumentor is activated via bootstrap when the package is installed."""

    def test_bootstrap_installs_genai_instrumentor_when_available(self):
        with _mock_exporter():
            installer = patch("azpaddypy.mgmt.logging._install_genai_instrumentors")
            with installer as mock_install:
                bootstrap_azure_monitor(
                    service_name="svc",
                    connection_string="InstrumentationKey=test",
                )
                mock_install.assert_called_once()

    def test_bootstrap_is_idempotent(self):
        with _mock_exporter():
            installer = patch("azpaddypy.mgmt.logging._install_genai_instrumentors")
            with installer as mock_install:
                bootstrap_azure_monitor(
                    service_name="svc-1",
                    connection_string="InstrumentationKey=test",
                )
                # Second call must not re-run the exporter or instrumentors.
                bootstrap_azure_monitor(
                    service_name="svc-2",
                    connection_string="InstrumentationKey=test",
                )
                assert mock_install.call_count == 1

    def test_bootstrap_skips_genai_when_flag_is_false(self):
        with _mock_exporter():
            installer = patch("azpaddypy.mgmt.logging._install_genai_instrumentors")
            with installer as mock_install:
                bootstrap_azure_monitor(
                    service_name="svc",
                    connection_string="InstrumentationKey=test",
                    install_genai_instrumentors=False,
                )
                mock_install.assert_not_called()


class TestAIProjectInstrumentorActivation:
    """Feature gate + soft-failure behavior for AIProjectInstrumentor."""

    def test_sets_feature_gate_when_installing_instrumentors(self):
        with _mock_exporter(), patch("azpaddypy.mgmt.logging._install_genai_instrumentors"):
            bootstrap_azure_monitor(
                service_name="svc",
                connection_string="InstrumentationKey=test",
                install_genai_instrumentors=True,
            )
        assert os.environ.get("AZURE_EXPERIMENTAL_ENABLE_GENAI_TRACING") == "true"

    def test_does_not_override_existing_feature_gate(self):
        os.environ["AZURE_EXPERIMENTAL_ENABLE_GENAI_TRACING"] = "false"
        with _mock_exporter(), patch("azpaddypy.mgmt.logging._install_genai_instrumentors"):
            bootstrap_azure_monitor(
                service_name="svc",
                connection_string="InstrumentationKey=test",
                install_genai_instrumentors=True,
            )
        assert os.environ["AZURE_EXPERIMENTAL_ENABLE_GENAI_TRACING"] == "false"

    def test_skips_feature_gate_when_opt_out(self):
        with _mock_exporter():
            bootstrap_azure_monitor(
                service_name="svc",
                connection_string="InstrumentationKey=test",
                install_genai_instrumentors=False,
            )
        assert os.environ.get("AZURE_EXPERIMENTAL_ENABLE_GENAI_TRACING") is None

    def test_ai_project_import_failure_is_soft(self):
        """Missing azure.ai.projects.telemetry must not break bootstrap."""
        with _mock_exporter():
            with patch.dict("sys.modules", {"azure.ai.projects.telemetry": None}):
                with patch(
                    "builtins.__import__",
                    side_effect=_make_import_blocker("azure.ai.projects.telemetry"),
                ):
                    # Should not raise
                    bootstrap_azure_monitor(
                        service_name="svc",
                        connection_string="InstrumentationKey=test",
                    )


class TestContentRecordingOptIn:
    """capture_gen_ai_content sets the GenAI content recording env vars."""

    def test_default_does_not_set_content_recording_env_vars(self):
        with _mock_exporter(), patch("azpaddypy.mgmt.logging._install_genai_instrumentors"):
            bootstrap_azure_monitor(
                service_name="svc",
                connection_string="InstrumentationKey=test",
            )
        assert os.environ.get("OTEL_INSTRUMENTATION_GENAI_CAPTURE_MESSAGE_CONTENT") is None
        assert os.environ.get("AZURE_TRACING_GEN_AI_CONTENT_RECORDING_ENABLED") is None

    def test_capture_gen_ai_content_sets_both_env_vars(self):
        with _mock_exporter(), patch("azpaddypy.mgmt.logging._install_genai_instrumentors"):
            bootstrap_azure_monitor(
                service_name="svc",
                connection_string="InstrumentationKey=test",
                capture_gen_ai_content=True,
            )
        assert os.environ["OTEL_INSTRUMENTATION_GENAI_CAPTURE_MESSAGE_CONTENT"] == "true"
        assert os.environ["AZURE_TRACING_GEN_AI_CONTENT_RECORDING_ENABLED"] == "true"

    def test_capture_gen_ai_content_does_not_override_existing(self):
        os.environ["OTEL_INSTRUMENTATION_GENAI_CAPTURE_MESSAGE_CONTENT"] = "false"
        with _mock_exporter(), patch("azpaddypy.mgmt.logging._install_genai_instrumentors"):
            bootstrap_azure_monitor(
                service_name="svc",
                connection_string="InstrumentationKey=test",
                capture_gen_ai_content=True,
            )
        assert os.environ["OTEL_INSTRUMENTATION_GENAI_CAPTURE_MESSAGE_CONTENT"] == "false"

    def test_record_result_does_not_set_env_vars(self):
        """
        The per-function ``record_result`` flag only controls span attributes;
        it must not poke GenAI content-recording env vars at runtime.
        """
        with _mock_exporter(), patch("azpaddypy.mgmt.logging._install_genai_instrumentors"):
            bootstrap_azure_monitor(
                service_name="svc",
                connection_string="InstrumentationKey=test",
            )
        logger = AzureLogger("svc", enable_console_logging=False)

        @logger.trace_function(record_result=True)
        def f():
            assert os.environ.get("OTEL_INSTRUMENTATION_GENAI_CAPTURE_MESSAGE_CONTENT") is None
            assert os.environ.get("AZURE_TRACING_GEN_AI_CONTENT_RECORDING_ENABLED") is None
            return "result"

        assert f() == "result"


class TestTracePropagationDefault:
    """W3C trace context propagation defaults to on."""

    def test_default_enables_trace_propagation(self):
        with _mock_exporter(), patch("azpaddypy.mgmt.logging._install_genai_instrumentors"):
            bootstrap_azure_monitor(
                service_name="svc",
                connection_string="InstrumentationKey=test",
            )
        assert os.environ["AZURE_TRACING_GEN_AI_ENABLE_TRACE_CONTEXT_PROPAGATION"] == "true"

    def test_opt_out_of_trace_propagation(self):
        with _mock_exporter(), patch("azpaddypy.mgmt.logging._install_genai_instrumentors"):
            bootstrap_azure_monitor(
                service_name="svc",
                connection_string="InstrumentationKey=test",
                enable_gen_ai_trace_propagation=False,
            )
        assert os.environ.get("AZURE_TRACING_GEN_AI_ENABLE_TRACE_CONTEXT_PROPAGATION") is None


class TestNonFoundryUsage:
    """
    A plain app that never touches AI Foundry must still get a working
    logger + trace decorator even with all the default instrumentors on.
    """

    def test_default_logger_works_without_foundry_calls(self):
        with _mock_exporter(), patch("azpaddypy.mgmt.logging._install_genai_instrumentors"):
            bootstrap_azure_monitor(
                service_name="svc",
                connection_string="InstrumentationKey=test",
            )
        logger = AzureLogger("svc", enable_console_logging=False)

        logger.info("plain info")
        logger.warning("plain warning")

        @logger.trace_function()
        def compute(x: int, y: int) -> int:
            return x + y

        assert compute(2, 3) == 5

    @pytest.mark.anyio
    async def test_default_logger_async_trace_works_without_foundry(self):
        with _mock_exporter(), patch("azpaddypy.mgmt.logging._install_genai_instrumentors"):
            bootstrap_azure_monitor(
                service_name="svc",
                connection_string="InstrumentationKey=test",
            )
        logger = AzureLogger("svc", enable_console_logging=False)

        @logger.trace_function()
        async def fetch_value() -> str:
            return "ok"

        assert await fetch_value() == "ok"

    def test_env_connection_string_is_used(self, monkeypatch):
        preset = "InstrumentationKey=00000000-0000-0000-0000-000000000000;IngestionEndpoint=https://example.com/"
        monkeypatch.setenv("APPLICATIONINSIGHTS_CONNECTION_STRING", preset)
        with _mock_exporter() as cfg, patch("azpaddypy.mgmt.logging._install_genai_instrumentors"):
            assert bootstrap_azure_monitor(service_name="svc") is True
        # configure_azure_monitor receives the env-sourced connection string.
        assert cfg.call_args.kwargs["connection_string"] == preset


class TestTraceFunctionResultCapture:
    """record_result=True still tags the span with the return value."""

    def test_records_result_on_span(self):
        from unittest.mock import MagicMock

        with _mock_exporter(), patch("azpaddypy.mgmt.logging._install_genai_instrumentors"):
            bootstrap_azure_monitor(
                service_name="svc",
                connection_string="InstrumentationKey=test",
            )
        logger = AzureLogger("svc", enable_console_logging=False)

        mock_span = MagicMock()
        mock_span.is_recording.return_value = True
        cm = MagicMock()
        cm.__enter__.return_value = mock_span
        cm.__exit__.return_value = None
        mock_tracer = MagicMock()
        mock_tracer.start_as_current_span.return_value = cm

        with patch("azpaddypy.mgmt.logging.trace.get_tracer", return_value=mock_tracer):

            @logger.trace_function(record_result=True)
            def my_func():
                return "traced_result"

            assert my_func() == "traced_result"

        attrs = {call[0][0]: call[0][1] for call in mock_span.set_attribute.call_args_list if len(call[0]) == 2}
        assert attrs.get("result") == "traced_result"
        assert attrs.get("result.type") == "str"

    def test_correlation_id_generated_on_first_trace(self):
        with _mock_exporter(), patch("azpaddypy.mgmt.logging._install_genai_instrumentors"):
            bootstrap_azure_monitor(
                service_name="svc",
                connection_string="InstrumentationKey=test",
            )
        logger = AzureLogger("svc", enable_console_logging=False)

        assert AzureLogger.correlation_id() is None

        observed: dict[str, str | None] = {}

        @logger.trace_function()
        def f():
            observed["cid"] = AzureLogger.correlation_id()

        f()
        assert observed["cid"] is not None
        # Scoped: cleared on exit.
        assert AzureLogger.correlation_id() is None


# ── Test helpers ────────────────────────────────────────────────────


def _make_import_blocker(blocked_module: str):
    """Return an ``__import__`` replacement that blocks a specific module."""
    original_import = __import__

    def blocker(name, *args, **kwargs):
        if name == blocked_module:
            msg = f"Simulated missing module: {blocked_module}"
            raise ImportError(msg)
        return original_import(name, *args, **kwargs)

    return blocker
