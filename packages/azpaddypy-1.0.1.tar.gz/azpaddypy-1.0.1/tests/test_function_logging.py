"""
Integration-style tests for AzureLogger in an Azure-Functions shape.

Exercises the common function-app pattern: bootstrap once with a function
cloud role, then use AzureLogger + trace_function throughout the handler.
"""

from __future__ import annotations

import asyncio
import time

import pytest

from azpaddypy.mgmt import logging as logging_mod
from azpaddypy.mgmt.logging import AzureLogger, bootstrap_azure_monitor, trace_function


@pytest.fixture(autouse=True)
def _reset_bootstrap():
    logging_mod._BOOTSTRAPPED = False
    logging_mod._TELEMETRY_ENABLED = False
    yield
    logging_mod._BOOTSTRAPPED = False
    logging_mod._TELEMETRY_ENABLED = False


@pytest.fixture
def function_logger(monkeypatch):
    """Simulate a function-app logger without a live connection string."""
    monkeypatch.delenv("APPLICATIONINSIGHTS_CONNECTION_STRING", raising=False)
    bootstrap_azure_monitor(
        service_name="test-function-app.test-function",
        service_version="1.0.0",
        resource_attributes={
            "azure.function.app": "test-function-app",
            "azure.function.name": "test-function",
            "azure.resource.type": "function",
        },
    )
    return AzureLogger("test-function-app.test-function", enable_console_logging=False)


def test_logger_supports_all_levels(function_logger, caplog):
    import logging as stdlib_logging

    function_logger.setLevel(stdlib_logging.DEBUG)
    with caplog.at_level(stdlib_logging.DEBUG):
        function_logger.debug("debug msg")
        function_logger.info("info msg")
        function_logger.warning("warning msg")
        function_logger.error("error msg")
        function_logger.critical("critical msg")

    messages = {r.levelname: r.getMessage() for r in caplog.records}
    assert messages["DEBUG"] == "debug msg"
    assert messages["INFO"] == "info msg"
    assert messages["WARNING"] == "warning msg"
    assert messages["ERROR"] == "error msg"
    assert messages["CRITICAL"] == "critical msg"


def test_structured_extra_reaches_record(function_logger, caplog):
    import logging as stdlib_logging

    with caplog.at_level(stdlib_logging.INFO):
        function_logger.info(
            "with structured data",
            extra={"user_id": "u-1", "action": "test"},
        )

    record = next(r for r in caplog.records if r.getMessage() == "with structured data")
    assert record.user_id == "u-1"
    assert record.action == "test"


def test_trace_function_sync(function_logger):
    @function_logger.trace_function()
    def process():
        time.sleep(0.01)
        return "ok"

    assert process() == "ok"


def test_trace_function_async(function_logger):
    @function_logger.trace_function()
    async def process_async():
        await asyncio.sleep(0.01)
        return "ok-async"

    assert asyncio.run(process_async()) == "ok-async"


def test_trace_function_records_args_and_result(function_logger):
    # record_args / record_result just influence span attributes -- the
    # decorated function itself is transparent.
    @trace_function(record_args=True, record_result=True)
    def echo(x: int, y: str = "z") -> str:
        return f"{x}-{y}"

    assert echo(1, y="two") == "1-two"


def test_baggage_round_trip(function_logger):
    from opentelemetry import context as otel_context

    ctx = AzureLogger.set_baggage("user_id", "u-42")
    token = otel_context.attach(ctx)
    try:
        assert AzureLogger.get_baggage("user_id") == "u-42"
    finally:
        otel_context.detach(token)


def test_create_span_records_attributes(function_logger):
    with function_logger.create_span("sample_span", attributes={"op": "test"}) as span:
        assert span.is_recording() or not logging_mod._TELEMETRY_ENABLED  # no-op span is fine
        function_logger.add_span_attributes({"extra": "x"})
        function_logger.add_span_event("something_happened", {"k": "v"})


def test_traced_call_sets_ok_status_by_default(function_logger):
    @trace_function()
    def ok():
        return 1

    assert ok() == 1


def test_traced_call_records_exception(function_logger):
    @trace_function()
    def bad():
        msg = "planned failure"
        raise RuntimeError(msg)

    with pytest.raises(RuntimeError, match="planned failure"):
        bad()


def test_flush_does_not_raise(function_logger):
    function_logger.flush()
