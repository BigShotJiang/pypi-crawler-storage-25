"""Tests for the clean AzureLogger / bootstrap / trace_function API."""

from __future__ import annotations

import asyncio
import logging
import uuid
from unittest.mock import patch

import pytest

from azpaddypy.mgmt import logging as logging_mod
from azpaddypy.mgmt.logging import AzureLogger, bootstrap_azure_monitor, trace_function


@pytest.fixture
def az_logger():
    return AzureLogger("test_service.unit", enable_console_logging=False)


# ---------------------------------------------------------------------------
# bootstrap_azure_monitor
# ---------------------------------------------------------------------------


class TestBootstrap:
    def test_returns_false_without_connection_string(self, monkeypatch):
        monkeypatch.delenv("APPLICATIONINSIGHTS_CONNECTION_STRING", raising=False)
        assert bootstrap_azure_monitor(service_name="svc") is False
        assert logging_mod._TELEMETRY_ENABLED is False
        assert logging_mod._BOOTSTRAPPED is True

    def test_is_idempotent(self, monkeypatch):
        monkeypatch.delenv("APPLICATIONINSIGHTS_CONNECTION_STRING", raising=False)
        first = bootstrap_azure_monitor(service_name="svc")
        second = bootstrap_azure_monitor(service_name="svc")
        assert first == second is False
        assert logging_mod._BOOTSTRAPPED is True

    def test_picks_up_env_connection_string(self, monkeypatch):
        monkeypatch.setenv("APPLICATIONINSIGHTS_CONNECTION_STRING", "InstrumentationKey=abc")
        with (
            patch("azpaddypy.mgmt.logging.configure_azure_monitor") as cfg_mock,
            patch("azpaddypy.mgmt.logging._install_genai_instrumentors"),
        ):
            assert bootstrap_azure_monitor(service_name="svc") is True
            cfg_mock.assert_called_once()

    def test_sets_genai_env_vars_when_requested(self, monkeypatch):
        monkeypatch.setenv("APPLICATIONINSIGHTS_CONNECTION_STRING", "InstrumentationKey=abc")
        monkeypatch.delenv("OTEL_INSTRUMENTATION_GENAI_CAPTURE_MESSAGE_CONTENT", raising=False)
        monkeypatch.delenv("AZURE_TRACING_GEN_AI_ENABLE_TRACE_CONTEXT_PROPAGATION", raising=False)
        with (
            patch("azpaddypy.mgmt.logging.configure_azure_monitor"),
            patch("azpaddypy.mgmt.logging._install_genai_instrumentors"),
        ):
            bootstrap_azure_monitor(service_name="svc", capture_gen_ai_content=True)

        import os

        assert os.environ["OTEL_INSTRUMENTATION_GENAI_CAPTURE_MESSAGE_CONTENT"] == "true"
        assert os.environ["AZURE_TRACING_GEN_AI_ENABLE_TRACE_CONTEXT_PROPAGATION"] == "true"

    def test_exporter_failure_disables_telemetry(self, monkeypatch):
        monkeypatch.setenv("APPLICATIONINSIGHTS_CONNECTION_STRING", "InstrumentationKey=bad")
        with patch(
            "azpaddypy.mgmt.logging.configure_azure_monitor",
            side_effect=RuntimeError("boom"),
        ):
            assert bootstrap_azure_monitor(service_name="svc") is False


# ---------------------------------------------------------------------------
# AzureLogger construction + stdlib compatibility
# ---------------------------------------------------------------------------


class TestAzureLoggerConstruction:
    def test_requires_non_empty_name(self):
        with pytest.raises(ValueError, match="non-empty name"):
            AzureLogger("")

    def test_uses_stdlib_logger(self):
        logger = AzureLogger("test_service.ctor", enable_console_logging=False)
        assert logger.name == "test_service.ctor"
        assert isinstance(logger._logger, logging.Logger)
        assert logger.level == logging.INFO

    def test_custom_level(self):
        logger = AzureLogger("test_service.level", level=logging.DEBUG, enable_console_logging=False)
        assert logger.level == logging.DEBUG

    def test_console_handler_attached_when_enabled(self):
        name = f"test_service.console.{uuid.uuid4().hex}"
        logger = AzureLogger(name, enable_console_logging=True)
        assert any(isinstance(h, logging.StreamHandler) for h in logger._logger.handlers)

    def test_console_handler_not_duplicated(self):
        name = f"test_service.dedup.{uuid.uuid4().hex}"
        first = AzureLogger(name, enable_console_logging=True)
        second = AzureLogger(name, enable_console_logging=True)
        # Both wrap the same stdlib logger; only one handler should be attached.
        assert first._logger is second._logger
        assert sum(isinstance(h, logging.StreamHandler) for h in first._logger.handlers) == 1

    def test_console_handler_not_attached_when_disabled(self):
        name = f"test_service.nocon.{uuid.uuid4().hex}"
        logger = AzureLogger(name, enable_console_logging=False)
        assert not logger._logger.handlers


# ---------------------------------------------------------------------------
# stdlib-shaped logging methods
# ---------------------------------------------------------------------------


class TestLoggingMethods:
    def test_info_emits_record(self, az_logger, caplog):
        with caplog.at_level(logging.INFO, logger=az_logger.name):
            az_logger.info("hello %s", "world")
        assert any(r.getMessage() == "hello world" for r in caplog.records)

    def test_disabled_level_does_not_emit(self, az_logger, caplog):
        # caplog captures via a handler at root; to actually suppress, the
        # logger's effective level must be >= the call's level.
        az_logger.setLevel(logging.WARNING)
        with caplog.at_level(logging.DEBUG):
            az_logger.debug("should not appear: %s", "x")
        assert not any("should not appear" in r.getMessage() for r in caplog.records)

    def test_error_does_not_default_exc_info(self, az_logger, caplog):
        with caplog.at_level(logging.ERROR, logger=az_logger.name):
            az_logger.error("plain error")
        record = next(r for r in caplog.records if r.getMessage() == "plain error")
        assert record.exc_info is None

    def test_exception_attaches_exc_info(self, az_logger, caplog):
        with caplog.at_level(logging.ERROR, logger=az_logger.name):
            try:
                msg = "boom"
                raise RuntimeError(msg)
            except RuntimeError:
                az_logger.exception("caught it")
        record = next(r for r in caplog.records if r.getMessage() == "caught it")
        assert record.exc_info is not None

    def test_record_contains_enriched_extra(self, az_logger, caplog):
        with caplog.at_level(logging.INFO, logger=az_logger.name):
            az_logger.info("with extra", extra={"custom_key": "xyz"})
        record = next(r for r in caplog.records if r.getMessage() == "with extra")
        assert record.custom_key == "xyz"
        assert record.service_name == az_logger.name

    def test_reserved_keys_are_filtered_from_extra(self, az_logger, caplog):
        with caplog.at_level(logging.INFO, logger=az_logger.name):
            # "name" is a reserved LogRecord attr -- must be silently dropped
            az_logger.info("reserved", extra={"name": "ignored", "ok": "kept"})
        record = next(r for r in caplog.records if r.getMessage() == "reserved")
        assert record.name == az_logger.name
        assert record.ok == "kept"

    def test_stacklevel_points_to_caller(self, az_logger, caplog):
        with caplog.at_level(logging.INFO, logger=az_logger.name):
            az_logger.info("stack check")  # <- this line is the caller
        record = next(r for r in caplog.records if r.getMessage() == "stack check")
        assert record.filename == "test_logging.py"

    def test_isEnabledFor_and_setLevel(self, az_logger):  # noqa: N802 -- mirrors stdlib Logger API
        az_logger.setLevel(logging.ERROR)
        assert not az_logger.isEnabledFor(logging.INFO)
        assert az_logger.isEnabledFor(logging.ERROR)

    def test_log_method(self, az_logger, caplog):
        with caplog.at_level(logging.WARNING, logger=az_logger.name):
            az_logger.log(logging.WARNING, "via log()")
        assert any(r.getMessage() == "via log()" for r in caplog.records)


# ---------------------------------------------------------------------------
# Correlation ID
# ---------------------------------------------------------------------------


class TestCorrelationId:
    def test_is_none_by_default(self):
        assert AzureLogger.correlation_id() is None

    def test_set_and_reset_scoped(self):
        token = AzureLogger.set_correlation_id("abc-123")
        try:
            assert AzureLogger.correlation_id() == "abc-123"
        finally:
            AzureLogger.reset_correlation_id(token)
        assert AzureLogger.correlation_id() is None

    def test_record_includes_correlation_id(self, az_logger, caplog):
        token = AzureLogger.set_correlation_id("cid-xyz")
        try:
            with caplog.at_level(logging.INFO, logger=az_logger.name):
                az_logger.info("with cid")
        finally:
            AzureLogger.reset_correlation_id(token)
        record = next(r for r in caplog.records if r.getMessage() == "with cid")
        assert record.correlation_id == "cid-xyz"

    def test_shared_across_loggers_same_context(self):
        a = AzureLogger("svc.a", enable_console_logging=False)
        b = AzureLogger("svc.b", enable_console_logging=False)
        token = AzureLogger.set_correlation_id("shared")
        try:
            assert a.correlation_id() == b.correlation_id() == "shared"
        finally:
            AzureLogger.reset_correlation_id(token)


# ---------------------------------------------------------------------------
# getChild
# ---------------------------------------------------------------------------


class TestGetChild:
    def test_returns_azure_logger_with_dotted_name(self, az_logger):
        child = az_logger.getChild("sub")
        assert isinstance(child, AzureLogger)
        assert child.name == f"{az_logger.name}.sub"

    def test_child_inherits_level(self):
        parent = AzureLogger("svc.parent", level=logging.WARNING, enable_console_logging=False)
        child = parent.getChild("c")
        assert child.level == logging.WARNING


# ---------------------------------------------------------------------------
# trace_function
# ---------------------------------------------------------------------------


class TestTraceFunction:
    def test_decorates_sync_and_returns_result(self):
        @trace_function()
        def add(a, b):
            return a + b

        assert add(2, 3) == 5

    def test_decorates_async_and_returns_result(self):
        @trace_function()
        async def mul(a, b):
            return a * b

        assert asyncio.run(mul(4, 5)) == 20

    def test_generates_correlation_id_when_absent(self):
        captured: dict[str, str | None] = {}

        @trace_function()
        def f():
            captured["cid"] = AzureLogger.correlation_id()

        assert AzureLogger.correlation_id() is None
        f()
        assert captured["cid"] is not None
        # Scoped reset on exit
        assert AzureLogger.correlation_id() is None

    def test_preserves_existing_correlation_id(self):
        captured: dict[str, str | None] = {}

        @trace_function()
        def f():
            captured["cid"] = AzureLogger.correlation_id()

        token = AzureLogger.set_correlation_id("preset")
        try:
            f()
            assert captured["cid"] == "preset"
            # outer still intact
            assert AzureLogger.correlation_id() == "preset"
        finally:
            AzureLogger.reset_correlation_id(token)

    def test_records_exception_and_reraises(self):
        @trace_function()
        def bomb():
            msg = "boom"
            raise ValueError(msg)

        with pytest.raises(ValueError, match="boom"):
            bomb()

    def test_method_on_logger_forwards(self, az_logger):
        @az_logger.trace_function(name="custom")
        def f(x):
            return x + 1

        assert f(10) == 11

    def test_splats_from_log_execution_dict(self):
        # Mirrors: @trace_function(**log_execution_config.to_dict())
        cfg = {"name": "splat", "record_args": True, "record_result": False}

        @trace_function(**cfg)
        def f(x):
            return x

        assert f(42) == 42


# ---------------------------------------------------------------------------
# Baggage helpers
# ---------------------------------------------------------------------------


class TestBaggage:
    def test_set_get_baggage(self):
        ctx = AzureLogger.set_baggage("key", "val")
        assert ctx is not None
        # get_baggage reads from the *current* context, so we need to attach
        from opentelemetry import context as otel_context

        token = otel_context.attach(ctx)
        try:
            assert AzureLogger.get_baggage("key") == "val"
        finally:
            otel_context.detach(token)
