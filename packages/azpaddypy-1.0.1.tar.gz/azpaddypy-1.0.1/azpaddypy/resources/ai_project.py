import time
from typing import Any

import openai
from azure.ai.projects import AIProjectClient
from azure.ai.projects.models import (
    AgentDetails,
    AgentVersionDetails,
    Connection,
    ConnectionType,
    Deployment,
    DeploymentType,
    PromptAgentDefinition,
)
from azure.core.credentials import TokenCredential
from azure.core.exceptions import AzureError, ClientAuthenticationError, ResourceNotFoundError
from openai.types.eval_create_params import DataSourceConfigCustom
from openai.types.evals.create_eval_jsonl_run_data_source_param import (
    CreateEvalJSONLRunDataSourceParam,
    SourceFileContent,
    SourceFileContentContent,
)

from .._cache import RingCache
from ..mgmt.identity import AzureIdentity
from ..mgmt.logging import AzureLogger
from ._base import AzureResourceBase, create_cached_resource

# AI Project instance caching (bounded ring buffer, max 10)
_ai_project_instances: RingCache = RingCache(maxsize=10)


class AzureAIProject(AzureResourceBase):
    """
    Azure AI Foundry Project management with agents, deployments, connections,
    evaluations, and OpenAI client integration.

    Provides standardized Azure AI Project operations using the Azure AI Projects SDK
    with integrated logging, error handling, and OpenTelemetry tracing support.
    Includes a one-shot ``evaluate()`` convenience method for running AI quality
    and safety evaluations, as well as granular methods for evaluation lifecycle
    management (create, run, poll, list, delete).

    Attributes:
        endpoint: Azure AI Foundry project endpoint URL
        service_name: Service identifier for logging and tracing
        service_version: Service version for context
        logger: AzureLogger instance for structured logging
        credential: Azure credential for authentication
        client: AIProjectClient instance

    """

    def __init__(
        self,
        endpoint: str,
        credential: TokenCredential | None = None,
        azure_identity: AzureIdentity | None = None,
        service_name: str = "azure_ai_project",
        service_version: str = "1.0.0",
        logger: AzureLogger | None = None,
        connection_string: str | None = None,
        enable_agents: bool = True,
        enable_deployments: bool = True,
        enable_connections: bool = True,
    ):
        """
        Initialize Azure AI Foundry Project client.

        Args:
            endpoint: AI Foundry project endpoint URL
                (e.g., https://<ai-services>.services.ai.azure.com/api/projects/<project>)
            credential: Azure credential for authentication
            azure_identity: AzureIdentity instance for credential management
            service_name: Service name for tracing context
            service_version: Service version for metadata
            logger: Optional AzureLogger instance
            connection_string: Application Insights connection string
            enable_agents: Enable agent operations
            enable_deployments: Enable deployment operations
            enable_connections: Enable connection operations

        Raises:
            ValueError: If neither credential nor azure_identity is provided
            AzureError: If client initialization fails

        """
        super().__init__(
            credential=credential,
            azure_identity=azure_identity,
            service_name=service_name,
            service_version=service_version,
            logger=logger,
            connection_string=connection_string,
        )

        self.endpoint = endpoint
        self.enable_agents = enable_agents
        self.enable_deployments = enable_deployments
        self.enable_connections = enable_connections

        self.client: AIProjectClient | None = None

        self.logger.info(
            f"Azure AI Project initialized for service '{service_name}' v{service_version}",
            extra={
                "endpoint": endpoint,
                "agents_enabled": enable_agents,
                "deployments_enabled": enable_deployments,
                "connections_enabled": enable_connections,
            },
        )

    def _ensure_client(self) -> AIProjectClient:
        """Return the client, constructing it lazily on first use."""
        if self.client is None:
            self.client = AIProjectClient(
                endpoint=self.endpoint,
                credential=self.credential,
            )
            self.logger.debug("AIProjectClient lazily initialized on first use")
        return self.client

    def _ensure_agents_enabled(self) -> None:
        """Raise if agent operations are disabled."""
        if not self.enable_agents:
            error_msg = "Agent operations not enabled. Enable agents during initialization."
            self.logger.error(error_msg)
            raise RuntimeError(error_msg)

    def _ensure_deployments_enabled(self) -> None:
        """Raise if deployment operations are disabled."""
        if not self.enable_deployments:
            error_msg = "Deployment operations not enabled. Enable deployments during initialization."
            self.logger.error(error_msg)
            raise RuntimeError(error_msg)

    def _ensure_connections_enabled(self) -> None:
        """Raise if connection operations are disabled."""
        if not self.enable_connections:
            error_msg = "Connection operations not enabled. Enable connections during initialization."
            self.logger.error(error_msg)
            raise RuntimeError(error_msg)

    # ── OpenAI Client ─────────────────────────────────────────────

    def get_openai_client(self, **kwargs: Any) -> openai.OpenAI:
        """
        Get an authenticated OpenAI client configured for this AI project.

        Returns:
            Configured OpenAI client with project endpoint and credentials

        Raises:
            RuntimeError: If client is not initialized
            AzureError: If OpenAI client creation fails

        """
        with self.logger.create_span(
            "AzureAIProject.get_openai_client",
            attributes={
                "service.name": self.service_name,
                "operation.type": "openai_client_creation",
                "ai_project.endpoint": self.endpoint,
            },
        ):
            client = self._ensure_client()
            try:
                openai_client = client.get_openai_client(**kwargs)
                self.logger.info("OpenAI client created successfully")
                return openai_client
            except AzureError:
                self.logger.exception("Failed to create OpenAI client")
                raise

    # ── Agent Operations ──────────────────────────────────────────

    def create_agent(
        self,
        agent_name: str,
        definition: PromptAgentDefinition,
        description: str | None = None,
        metadata: dict[str, str] | None = None,
    ) -> AgentVersionDetails:
        """
        Create a new agent version in the AI project.

        Args:
            agent_name: Name for the agent
            definition: Agent definition (e.g., PromptAgentDefinition)
            description: Optional agent description
            metadata: Optional metadata dict

        Returns:
            AgentVersionDetails for the created agent

        Raises:
            RuntimeError: If client or agents not enabled
            AzureError: If agent creation fails

        """
        with self.logger.create_span(
            "AzureAIProject.create_agent",
            attributes={
                "service.name": self.service_name,
                "operation.type": "agent_creation",
                "ai_project.agent_name": agent_name,
                "ai_project.endpoint": self.endpoint,
                # OTel GenAI semantic conventions (recognized by AI Foundry Tracing UI)
                "gen_ai.system": "az.ai.projects",
                "gen_ai.operation.name": "create_agent",
                "gen_ai.agent.name": agent_name,
            },
        ):
            client = self._ensure_client()
            self._ensure_agents_enabled()

            try:
                self.logger.debug(
                    "Creating agent",
                    extra={"agent_name": agent_name},
                )

                agent_version = client.agents.create_version(
                    agent_name=agent_name,
                    definition=definition,
                    description=description,
                    metadata=metadata,
                )

                self.logger.info(
                    "Agent created successfully",
                    extra={
                        "agent_name": agent_name,
                        "version": getattr(agent_version, "version", None),
                    },
                )
                return agent_version

            except AzureError:
                self.logger.exception(
                    f"Failed to create agent '{agent_name}'",
                    extra={"agent_name": agent_name},
                )
                raise

    def get_agent(self, agent_name: str) -> AgentDetails | None:
        """
        Get an agent by name.

        Args:
            agent_name: Name of the agent

        Returns:
            AgentDetails if found, None if not found

        Raises:
            RuntimeError: If client or agents not enabled
            AzureError: If retrieval fails for reasons other than not found

        """
        with self.logger.create_span(
            "AzureAIProject.get_agent",
            attributes={
                "service.name": self.service_name,
                "operation.type": "agent_retrieval",
                "ai_project.agent_name": agent_name,
                "ai_project.endpoint": self.endpoint,
                "gen_ai.system": "az.ai.projects",
                "gen_ai.operation.name": "get_agent",
                "gen_ai.agent.name": agent_name,
            },
        ):
            client = self._ensure_client()
            self._ensure_agents_enabled()

            try:
                self.logger.debug(
                    "Retrieving agent",
                    extra={"agent_name": agent_name},
                )

                agent = client.agents.get(agent_name=agent_name)

                self.logger.info(
                    "Agent retrieved successfully",
                    extra={"agent_name": agent_name},
                )
                return agent

            except ResourceNotFoundError:
                self.logger.warning(
                    f"Agent '{agent_name}' not found",
                    extra={"agent_name": agent_name},
                )
                return None
            except ClientAuthenticationError:
                self.logger.exception(
                    f"Authentication failed for agent '{agent_name}'",
                    extra={"agent_name": agent_name},
                )
                raise
            except AzureError:
                self.logger.exception(
                    f"Failed to retrieve agent '{agent_name}'",
                    extra={"agent_name": agent_name},
                )
                raise

    def list_agents(self, **kwargs: Any) -> list[AgentDetails]:
        """
        List all agents in the AI project.

        Args:
            **kwargs: Additional parameters (kind, limit, order, before)

        Returns:
            List of AgentDetails

        Raises:
            RuntimeError: If client or agents not enabled
            AzureError: If listing fails

        """
        with self.logger.create_span(
            "AzureAIProject.list_agents",
            attributes={
                "service.name": self.service_name,
                "operation.type": "agent_listing",
                "ai_project.endpoint": self.endpoint,
                "gen_ai.system": "az.ai.projects",
                "gen_ai.operation.name": "list_agents",
            },
        ):
            client = self._ensure_client()
            self._ensure_agents_enabled()

            try:
                self.logger.debug("Listing agents")

                agents = list(client.agents.list(**kwargs))

                self.logger.info(
                    "Agents listed successfully",
                    extra={"agent_count": len(agents)},
                )
                return agents

            except AzureError:
                self.logger.exception("Failed to list agents")
                raise

    def delete_agent(self, agent_name: str) -> bool:
        """
        Delete an agent by name.

        Args:
            agent_name: Name of the agent to delete

        Returns:
            True if deleted, False if not found

        Raises:
            RuntimeError: If client or agents not enabled
            AzureError: If deletion fails

        """
        with self.logger.create_span(
            "AzureAIProject.delete_agent",
            attributes={
                "service.name": self.service_name,
                "operation.type": "agent_deletion",
                "ai_project.agent_name": agent_name,
                "ai_project.endpoint": self.endpoint,
                "gen_ai.system": "az.ai.projects",
                "gen_ai.operation.name": "delete_agent",
                "gen_ai.agent.name": agent_name,
            },
        ):
            client = self._ensure_client()
            self._ensure_agents_enabled()

            try:
                self.logger.debug(
                    "Deleting agent",
                    extra={"agent_name": agent_name},
                )

                client.agents.delete(agent_name=agent_name)

                self.logger.info(
                    "Agent deleted successfully",
                    extra={"agent_name": agent_name},
                )
                return True

            except ResourceNotFoundError:
                self.logger.warning(
                    f"Agent '{agent_name}' not found for deletion",
                    extra={"agent_name": agent_name},
                )
                return False
            except AzureError:
                self.logger.exception(
                    f"Failed to delete agent '{agent_name}'",
                    extra={"agent_name": agent_name},
                )
                raise

    def invoke_agent(
        self,
        agent_name: str,
        user_message: str,
        model: str = "not-used",
    ) -> dict[str, Any]:
        """
        Invoke an agent with a user message via the OpenAI responses API.

        Args:
            agent_name: Name of the agent to invoke
            user_message: Message to send to the agent
            model: Model parameter (ignored when using agent_reference)

        Returns:
            Dict with response_id, status, and response text

        Raises:
            RuntimeError: If client or agents not enabled
            AzureError: If invocation fails

        """
        with self.logger.create_span(
            "AzureAIProject.invoke_agent",
            attributes={
                "service.name": self.service_name,
                "operation.type": "agent_invocation",
                "ai_project.agent_name": agent_name,
                "ai_project.endpoint": self.endpoint,
                # OTel GenAI semantic conventions so the AI Foundry Tracing UI
                # groups the trace under the agent and renders it with GenAI chrome.
                "gen_ai.system": "az.ai.projects",
                "gen_ai.operation.name": "invoke_agent",
                "gen_ai.agent.name": agent_name,
                "gen_ai.request.model": model,
            },
        ):
            client = self._ensure_client()
            self._ensure_agents_enabled()

            try:
                self.logger.debug(
                    "Invoking agent",
                    extra={"agent_name": agent_name},
                )

                openai_client = client.get_openai_client()
                response = openai_client.responses.create(
                    model=model,
                    input=user_message,
                    extra_body={
                        "agent_reference": {
                            "name": agent_name,
                            "type": "agent_reference",
                        },
                    },
                )

                result: dict[str, Any] = {
                    "response_id": response.id,
                    "status": response.status,
                    "response": response.output_text,
                }

                # Enrich the current span with GenAI response attributes so the
                # AI Foundry Tracing UI can display response metadata.
                self.logger.add_span_attributes(
                    {
                        "gen_ai.response.id": str(response.id),
                        "gen_ai.response.status": str(response.status),
                    }
                )

                self.logger.info(
                    "Agent invoked successfully",
                    extra={
                        "agent_name": agent_name,
                        "response_id": response.id,
                        "status": response.status,
                    },
                )
                return result

            except AzureError:
                self.logger.exception(
                    f"Failed to invoke agent '{agent_name}'",
                    extra={"agent_name": agent_name},
                )
                raise

    # ── Deployment Operations ─────────────────────────────────────

    def list_deployments(
        self,
        model_publisher: str | None = None,
        model_name: str | None = None,
        deployment_type: DeploymentType | None = None,
        **kwargs: Any,
    ) -> list[Deployment]:
        """
        List model deployments in the AI project.

        Args:
            model_publisher: Filter by model publisher
            model_name: Filter by model name
            deployment_type: Filter by deployment type
            **kwargs: Additional parameters

        Returns:
            List of Deployment objects

        Raises:
            RuntimeError: If client or deployments not enabled
            AzureError: If listing fails

        """
        with self.logger.create_span(
            "AzureAIProject.list_deployments",
            attributes={
                "service.name": self.service_name,
                "operation.type": "deployment_listing",
                "ai_project.endpoint": self.endpoint,
            },
        ):
            client = self._ensure_client()
            self._ensure_deployments_enabled()

            try:
                self.logger.debug(
                    "Listing deployments",
                    extra={
                        "model_publisher": model_publisher,
                        "model_name": model_name,
                    },
                )

                deployments = list(
                    client.deployments.list(
                        model_publisher=model_publisher,
                        model_name=model_name,
                        deployment_type=deployment_type,
                        **kwargs,
                    )
                )

                self.logger.info(
                    "Deployments listed successfully",
                    extra={"deployment_count": len(deployments)},
                )
                return deployments

            except AzureError:
                self.logger.exception("Failed to list deployments")
                raise

    def get_deployment(self, name: str) -> Deployment | None:
        """
        Get a specific deployment by name.

        Args:
            name: Name of the deployment

        Returns:
            Deployment if found, None if not found

        Raises:
            RuntimeError: If client or deployments not enabled
            AzureError: If retrieval fails

        """
        with self.logger.create_span(
            "AzureAIProject.get_deployment",
            attributes={
                "service.name": self.service_name,
                "operation.type": "deployment_retrieval",
                "ai_project.deployment_name": name,
                "ai_project.endpoint": self.endpoint,
            },
        ):
            client = self._ensure_client()
            self._ensure_deployments_enabled()

            try:
                self.logger.debug(
                    "Retrieving deployment",
                    extra={"deployment_name": name},
                )

                deployment = client.deployments.get(name=name)

                self.logger.info(
                    "Deployment retrieved successfully",
                    extra={"deployment_name": name},
                )
                return deployment

            except ResourceNotFoundError:
                self.logger.warning(
                    f"Deployment '{name}' not found",
                    extra={"deployment_name": name},
                )
                return None
            except AzureError:
                self.logger.exception(
                    f"Failed to retrieve deployment '{name}'",
                    extra={"deployment_name": name},
                )
                raise

    # ── Connection Operations ─────────────────────────────────────

    def list_connections(
        self,
        connection_type: ConnectionType | None = None,
        default_connection: bool | None = None,
        **kwargs: Any,
    ) -> list[Connection]:
        """
        List connections in the AI project.

        Args:
            connection_type: Filter by connection type
            default_connection: Filter by default connection status
            **kwargs: Additional parameters

        Returns:
            List of Connection objects

        Raises:
            RuntimeError: If client or connections not enabled
            AzureError: If listing fails

        """
        with self.logger.create_span(
            "AzureAIProject.list_connections",
            attributes={
                "service.name": self.service_name,
                "operation.type": "connection_listing",
                "ai_project.endpoint": self.endpoint,
            },
        ):
            client = self._ensure_client()
            self._ensure_connections_enabled()

            try:
                self.logger.debug("Listing connections")

                connections = list(
                    client.connections.list(
                        connection_type=connection_type,
                        default_connection=default_connection,
                        **kwargs,
                    )
                )

                self.logger.info(
                    "Connections listed successfully",
                    extra={"connection_count": len(connections)},
                )
                return connections

            except AzureError:
                self.logger.exception("Failed to list connections")
                raise

    def get_connection(
        self,
        name: str,
        include_credentials: bool = False,
    ) -> Connection | None:
        """
        Get a specific connection by name.

        Args:
            name: Name of the connection
            include_credentials: Whether to include credentials in the response

        Returns:
            Connection if found, None if not found

        Raises:
            RuntimeError: If client or connections not enabled
            AzureError: If retrieval fails

        """
        with self.logger.create_span(
            "AzureAIProject.get_connection",
            attributes={
                "service.name": self.service_name,
                "operation.type": "connection_retrieval",
                "ai_project.connection_name": name,
                "ai_project.endpoint": self.endpoint,
            },
        ):
            client = self._ensure_client()
            self._ensure_connections_enabled()

            try:
                self.logger.debug(
                    "Retrieving connection",
                    extra={"connection_name": name, "include_credentials": include_credentials},
                )

                connection = client.connections.get(
                    name=name,
                    include_credentials=include_credentials,
                )

                self.logger.info(
                    "Connection retrieved successfully",
                    extra={"connection_name": name},
                )
                return connection

            except ResourceNotFoundError:
                self.logger.warning(
                    f"Connection '{name}' not found",
                    extra={"connection_name": name},
                )
                return None
            except AzureError:
                self.logger.exception(
                    f"Failed to retrieve connection '{name}'",
                    extra={"connection_name": name},
                )
                raise

    def get_default_connection(
        self,
        connection_type: ConnectionType,
        include_credentials: bool = False,
    ) -> Connection | None:
        """
        Get the default connection for a given type.

        Args:
            connection_type: Type of connection to retrieve
            include_credentials: Whether to include credentials

        Returns:
            Connection if found, None if not found

        Raises:
            RuntimeError: If client or connections not enabled
            AzureError: If retrieval fails

        """
        with self.logger.create_span(
            "AzureAIProject.get_default_connection",
            attributes={
                "service.name": self.service_name,
                "operation.type": "default_connection_retrieval",
                "ai_project.connection_type": str(connection_type),
                "ai_project.endpoint": self.endpoint,
            },
        ):
            client = self._ensure_client()
            self._ensure_connections_enabled()

            try:
                self.logger.debug(
                    "Retrieving default connection",
                    extra={"connection_type": str(connection_type)},
                )

                connection = client.connections.get_default(
                    connection_type=connection_type,
                    include_credentials=include_credentials,
                )

                self.logger.info(
                    "Default connection retrieved successfully",
                    extra={"connection_type": str(connection_type)},
                )
                return connection

            except ResourceNotFoundError:
                self.logger.warning(
                    f"No default connection found for type '{connection_type}'",
                    extra={"connection_type": str(connection_type)},
                )
                return None
            except AzureError:
                self.logger.exception(
                    f"Failed to retrieve default connection for type '{connection_type}'",
                    extra={"connection_type": str(connection_type)},
                )
                raise

    # ── Connection Test & Correlation ─────────────────────────────

    def test_connection(self) -> bool:
        """
        Test connection to the AI project by listing deployments.

        Returns:
            True if connection is successful, False otherwise

        """
        with self.logger.create_span(
            "AzureAIProject.test_connection",
            attributes={
                "service.name": self.service_name,
                "operation.type": "connection_test",
                "ai_project.endpoint": self.endpoint,
            },
        ):
            try:
                self.logger.debug("Testing AI Project connection", extra={"endpoint": self.endpoint})

                client = self._ensure_client()
                list(client.deployments.list())

                self.logger.info("AI Project connection test successful")
                return True

            except AzureError as e:
                self.logger.warning(
                    f"AI Project connection test failed: {e}",
                    extra={"endpoint": self.endpoint},
                )
                return False

    # ── Evaluation Operations ───────────────────────────────────────

    # Built-in evaluator IDs for use with create_evaluation / evaluate.
    # Quality evaluators require a judge model (deployment_name).
    QUALITY_EVALUATORS: tuple[str, ...] = (
        "builtin.coherence",
        "builtin.fluency",
        "builtin.groundedness",
        "builtin.relevance",
        "builtin.similarity",
        "builtin.task_adherence",
    )
    # NLP-based evaluators — no judge model needed.
    NLP_EVALUATORS: tuple[str, ...] = (
        "builtin.f1_score",
        "builtin.bleu_score",
        "builtin.rouge_score",
        "builtin.meteor_score",
        "builtin.gleu_score",
    )
    # Safety evaluators — no judge model needed.
    SAFETY_EVALUATORS: tuple[str, ...] = (
        "builtin.violence",
        "builtin.sexual",
        "builtin.self_harm",
        "builtin.hate_unfairness",
        "builtin.prohibited_actions",
        "builtin.sensitive_data_leakage",
    )

    @staticmethod
    def _build_item_schema(fields: list[str]) -> dict[str, Any]:
        """Build the JSON-schema for an eval dataset from a list of field names."""
        return {
            "type": "object",
            "properties": {f: {"type": "string"} for f in fields},
            "required": fields,
        }

    @staticmethod
    def _build_data_mapping(fields: list[str]) -> dict[str, str]:
        """Build ``{{item.<field>}}`` data-mapping dict for evaluators."""
        return {f: f"{{{{item.{f}}}}}" for f in fields}

    @staticmethod
    def _needs_judge_model(evaluator_name: str) -> bool:
        """Return True if this evaluator requires a judge model deployment."""
        return evaluator_name in AzureAIProject.QUALITY_EVALUATORS

    def _build_testing_criteria(
        self,
        evaluator_names: list[str],
        data_fields: list[str],
        judge_model: str | None,
    ) -> list[dict[str, Any]]:
        """
        Build the ``testing_criteria`` list for ``openai_client.evals.create()``.

        Each entry is a dict following the ``azure_ai_evaluator`` schema:
        ``{"type": "azure_ai_evaluator", "evaluator_name": "builtin.X", ...}``.
        Quality evaluators (coherence, fluency, ...) receive
        ``initialization_parameters.deployment_name`` pointing at the judge model.
        """
        mapping = self._build_data_mapping(data_fields)
        criteria: list[dict[str, Any]] = []

        for evaluator_name in evaluator_names:
            criterion: dict[str, Any] = {
                "type": "azure_ai_evaluator",
                "name": evaluator_name.removeprefix("builtin."),
                "evaluator_name": evaluator_name,
                "data_mapping": mapping,
            }
            if self._needs_judge_model(evaluator_name):
                if not judge_model:
                    msg = (
                        f"Quality evaluator '{evaluator_name}' requires a judge_model "
                        "(e.g. 'gpt-4o') but none was provided."
                    )
                    raise ValueError(msg)
                criterion["initialization_parameters"] = {"deployment_name": judge_model}
            criteria.append(criterion)

        return criteria

    def create_evaluation(
        self,
        name: str,
        evaluator_names: list[str],
        data_fields: list[str] | None = None,
        judge_model: str | None = None,
        **kwargs: Any,
    ) -> Any:
        """
        Create an evaluation definition in AI Foundry.

        This wraps ``openai_client.evals.create()`` with automatic schema
        and data-mapping generation from the field names in your dataset.

        Args:
            name: Display name for the evaluation.
            evaluator_names: List of built-in evaluator IDs, e.g.
                ``["builtin.coherence", "builtin.violence"]``.
                See ``QUALITY_EVALUATORS``, ``SAFETY_EVALUATORS``,
                ``NLP_EVALUATORS`` for available IDs.
            data_fields: Column names in your dataset (e.g.
                ``["query", "response", "context"]``). Defaults to
                ``["query", "response", "context"]``.
            judge_model: Deployment name for the judge model (e.g. ``"gpt-4o"``).
                Required when using quality evaluators (coherence, fluency, etc.).
            **kwargs: Additional parameters forwarded to ``evals.create()``.

        Returns:
            The evaluation object from the OpenAI API (has ``.id``, ``.name``).

        Raises:
            ValueError: If a quality evaluator is requested without ``judge_model``.
            RuntimeError: If the AIProjectClient or OpenAI client is not available.
            AzureError: If the API call fails.

        """
        fields = data_fields or ["query", "response", "context"]

        with self.logger.create_span(
            "AzureAIProject.create_evaluation",
            attributes={
                "service.name": self.service_name,
                "operation.type": "evaluation_creation",
                "ai_project.endpoint": self.endpoint,
                "gen_ai.system": "az.ai.projects",
                "gen_ai.operation.name": "create_evaluation",
            },
        ):
            client = self._ensure_client()
            openai_client = client.get_openai_client()

            data_source_config = DataSourceConfigCustom(
                {
                    "type": "custom",
                    "item_schema": self._build_item_schema(fields),
                    "include_sample_schema": False,
                }
            )

            testing_criteria = self._build_testing_criteria(evaluator_names, fields, judge_model)

            try:
                eval_obj = openai_client.evals.create(
                    name=name,
                    data_source_config=data_source_config,
                    testing_criteria=testing_criteria,
                    **kwargs,
                )
                self.logger.info(
                    "Evaluation created successfully",
                    extra={"eval_id": eval_obj.id, "eval_name": name},
                )
                return eval_obj
            except AzureError:
                self.logger.exception(f"Failed to create evaluation '{name}'")
                raise

    def run_evaluation(
        self,
        eval_id: str,
        data: list[dict[str, str]],
        run_name: str | None = None,
        **kwargs: Any,
    ) -> Any:
        """
        Run an evaluation against inline data.

        Args:
            eval_id: ID of the evaluation definition (from ``create_evaluation``).
            data: List of dicts, each representing one evaluation row. Keys must
                match the ``data_fields`` used in ``create_evaluation``.
            run_name: Optional name for this run.
            **kwargs: Additional parameters forwarded to ``evals.runs.create()``.

        Returns:
            The evaluation run object (has ``.id``, ``.status``).

        """
        with self.logger.create_span(
            "AzureAIProject.run_evaluation",
            attributes={
                "service.name": self.service_name,
                "operation.type": "evaluation_run",
                "ai_project.endpoint": self.endpoint,
                "gen_ai.system": "az.ai.projects",
                "gen_ai.operation.name": "run_evaluation",
            },
        ):
            client = self._ensure_client()
            openai_client = client.get_openai_client()

            data_source = CreateEvalJSONLRunDataSourceParam(
                type="jsonl",
                source=SourceFileContent(
                    type="file_content",
                    content=[SourceFileContentContent(item=row) for row in data],
                ),
            )

            try:
                run = openai_client.evals.runs.create(
                    eval_id=eval_id,
                    data_source=data_source,
                    name=run_name,
                    **kwargs,
                )
                self.logger.info(
                    "Evaluation run started",
                    extra={"eval_id": eval_id, "run_id": run.id},
                )
                return run
            except AzureError:
                self.logger.exception(f"Failed to start evaluation run for '{eval_id}'")
                raise

    def get_evaluation_run(self, eval_id: str, run_id: str) -> Any:
        """
        Retrieve the current state of an evaluation run.

        Args:
            eval_id: Evaluation definition ID.
            run_id: Run ID.

        Returns:
            The run object with ``.status``, ``.result_counts``, ``.report_url``.

        """
        client = self._ensure_client()
        openai_client = client.get_openai_client()
        return openai_client.evals.runs.retrieve(eval_id=eval_id, run_id=run_id)

    def get_evaluation_run_output_items(self, eval_id: str, run_id: str) -> list[Any]:
        """
        Retrieve per-row output items for a completed evaluation run.

        Each item contains the evaluator results for one dataset row.

        Args:
            eval_id: Evaluation definition ID.
            run_id: Run ID.

        Returns:
            List of output items with per-evaluator scores.

        """
        client = self._ensure_client()
        openai_client = client.get_openai_client()
        return list(openai_client.evals.runs.output_items.list(eval_id=eval_id, run_id=run_id))

    def list_evaluations(self) -> list[Any]:
        """List all evaluation definitions in this project."""
        client = self._ensure_client()
        openai_client = client.get_openai_client()
        return list(openai_client.evals.list())

    def delete_evaluation(self, eval_id: str) -> Any:
        """Delete an evaluation definition and all its runs."""
        client = self._ensure_client()
        openai_client = client.get_openai_client()
        return openai_client.evals.delete(eval_id=eval_id)

    def evaluate(
        self,
        name: str,
        evaluator_names: list[str],
        data: list[dict[str, str]],
        data_fields: list[str] | None = None,
        judge_model: str | None = None,
        poll_interval_seconds: float = 5.0,
        timeout_seconds: float = 600.0,
        cleanup: bool = False,
    ) -> dict[str, Any]:
        """
        One-shot evaluation: create definition, run against inline data, poll to
        completion, and return structured results.

        This is the main convenience method. It chains ``create_evaluation``,
        ``run_evaluation``, and ``get_evaluation_run`` with polling.

        Args:
            name: Display name for the evaluation.
            evaluator_names: List of built-in evaluator IDs.
            data: List of dicts, each representing one evaluation row.
            data_fields: Column names (default ``["query", "response", "context"]``).
            judge_model: Deployment name for the judge model (required for quality evaluators).
            poll_interval_seconds: Seconds between status polls (default 5).
            timeout_seconds: Maximum wait time before raising TimeoutError (default 600).
            cleanup: If True, delete the evaluation definition after retrieving results.

        Returns:
            Dict with keys:
            - ``eval_id``: Evaluation definition ID.
            - ``run_id``: Run ID.
            - ``status``: Final run status (``"completed"`` or ``"failed"``).
            - ``report_url``: Portal URL for the evaluation report.
            - ``result_counts``: Aggregate pass/fail counts.
            - ``output_items``: Per-row evaluator results.

        Raises:
            ValueError: If a quality evaluator is used without judge_model.
            TimeoutError: If the run doesn't complete within timeout_seconds.
            AzureError: If any API call fails.

        """
        with self.logger.create_span(
            "AzureAIProject.evaluate",
            attributes={
                "service.name": self.service_name,
                "operation.type": "evaluation_full",
                "ai_project.endpoint": self.endpoint,
                "gen_ai.system": "az.ai.projects",
                "gen_ai.operation.name": "evaluate",
            },
        ):
            eval_obj = self.create_evaluation(
                name=name,
                evaluator_names=evaluator_names,
                data_fields=data_fields,
                judge_model=judge_model,
            )

            run = self.run_evaluation(
                eval_id=eval_obj.id,
                data=data,
                run_name=f"{name}-run",
            )

            # Poll until completed or failed.
            start = time.monotonic()
            while True:
                run = self.get_evaluation_run(eval_id=eval_obj.id, run_id=run.id)
                if run.status in ("completed", "failed"):
                    break
                elapsed = time.monotonic() - start
                if elapsed > timeout_seconds:
                    msg = (
                        f"Evaluation run '{run.id}' did not complete within "
                        f"{timeout_seconds}s (last status: {run.status})"
                    )
                    raise TimeoutError(msg)
                time.sleep(poll_interval_seconds)

            output_items = self.get_evaluation_run_output_items(eval_id=eval_obj.id, run_id=run.id)

            result: dict[str, Any] = {
                "eval_id": eval_obj.id,
                "run_id": run.id,
                "status": run.status,
                "report_url": getattr(run, "report_url", None),
                "result_counts": getattr(run, "result_counts", None),
                "output_items": output_items,
            }

            self.logger.info(
                "Evaluation completed",
                extra={
                    "eval_id": eval_obj.id,
                    "run_id": run.id,
                    "status": run.status,
                    "report_url": result["report_url"],
                },
            )

            if cleanup:
                self.delete_evaluation(eval_id=eval_obj.id)
                self.logger.debug(f"Cleaned up evaluation '{eval_obj.id}'")

            return result

    # ── Application Insights Linkage ──────────────────────────────

    def get_application_insights_connection_string(self) -> str | None:
        """
        Fetch the Application Insights connection string linked to this Foundry project.

        Returns the connection string of the Application Insights resource that
        has been linked to the AI Foundry project via the portal (Project →
        Tracing → "Manage data source"). This is the recommended way to
        bootstrap Azure Monitor telemetry for a Foundry application without
        hand-wiring APPLICATIONINSIGHTS_CONNECTION_STRING.

        The linkage is a one-time per-Foundry-resource operation performed in
        the portal; without it this method returns None and the Foundry Tracing
        UI cannot display spans even if they flow to App Insights.

        Returns:
            Connection string if the project has a linked App Insights resource,
            None otherwise.

        Raises:
            RuntimeError: If the AIProjectClient is not initialized
            AzureError: If the SDK call fails for reasons other than "not linked"

        """
        with self.logger.create_span(
            "AzureAIProject.get_application_insights_connection_string",
            attributes={
                "service.name": self.service_name,
                "operation.type": "telemetry_connection_string_retrieval",
                "ai_project.endpoint": self.endpoint,
            },
        ):
            client = self._ensure_client()

            try:
                # azure-ai-projects >=2.0.0 exposes this on client.telemetry.
                connection_string = client.telemetry.get_application_insights_connection_string()
            except ResourceNotFoundError:
                self.logger.warning(
                    "No Application Insights resource linked to this AI Foundry project",
                    extra={"endpoint": self.endpoint},
                )
                return None
            except AzureError:
                self.logger.exception(
                    "Failed to retrieve Application Insights connection string",
                    extra={"endpoint": self.endpoint},
                )
                raise

            if connection_string:
                self.logger.info("Application Insights connection string retrieved from linked Foundry project")
            else:
                self.logger.warning(
                    "Foundry project returned an empty Application Insights connection string; "
                    "the App Insights resource is likely not linked via portal",
                    extra={"endpoint": self.endpoint},
                )
            return connection_string


def create_azure_ai_project(
    endpoint: str,
    credential: TokenCredential | None = None,
    azure_identity: AzureIdentity | None = None,
    service_name: str = "azure_ai_project",
    service_version: str = "1.0.0",
    logger: AzureLogger | None = None,
    connection_string: str | None = None,
    enable_agents: bool = True,
    enable_deployments: bool = True,
    enable_connections: bool = True,
) -> AzureAIProject:
    """
    Factory function to create a cached AzureAIProject instance.

    Returns existing instance if one with same configuration exists.
    Creates a default AzureIdentity if neither credential nor
    azure_identity is provided.

    """
    return create_cached_resource(
        AzureAIProject,
        _ai_project_instances,
        (
            endpoint,
            service_name,
            service_version,
            connection_string,
            enable_agents,
            enable_deployments,
            enable_connections,
        ),
        credential=credential,
        azure_identity=azure_identity,
        service_name=service_name,
        service_version=service_version,
        logger=logger,
        connection_string=connection_string,
        endpoint=endpoint,
        enable_agents=enable_agents,
        enable_deployments=enable_deployments,
        enable_connections=enable_connections,
    )
