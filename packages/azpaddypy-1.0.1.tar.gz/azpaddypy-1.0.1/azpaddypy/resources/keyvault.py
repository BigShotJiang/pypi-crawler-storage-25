from azure.core.credentials import TokenCredential
from azure.core.exceptions import AzureError, ClientAuthenticationError, ResourceNotFoundError
from azure.keyvault.certificates import CertificateClient
from azure.keyvault.keys import KeyClient
from azure.keyvault.secrets import SecretClient

from .._cache import RingCache
from ..mgmt.identity import AzureIdentity
from ..mgmt.logging import AzureLogger
from ._base import AzureResourceBase, create_cached_resource

# KeyVault instance caching (bounded ring buffer, max 10)
_keyvault_instances: RingCache = RingCache(maxsize=10)


class AzureKeyVault(AzureResourceBase):
    """
    Azure Key Vault management with comprehensive secret, key, and certificate operations.

    Provides standardized Azure Key Vault operations using Azure SDK clients
    with integrated logging, error handling, and OpenTelemetry tracing support.
    Supports operations for secrets, keys, and certificates with proper
    authentication and authorization handling.

    Attributes:
        vault_url: Azure Key Vault URL
        service_name: Service identifier for logging and tracing
        service_version: Service version for context
        logger: AzureLogger instance for structured logging
        credential: Azure credential for authentication
        secret_client: Azure Key Vault SecretClient instance
        key_client: Azure Key Vault KeyClient instance
        certificate_client: Azure Key Vault CertificateClient instance

    """

    def __init__(
        self,
        vault_url: str,
        credential: TokenCredential | None = None,
        azure_identity: AzureIdentity | None = None,
        service_name: str = "azure_keyvault",
        service_version: str = "1.0.0",
        logger: AzureLogger | None = None,
        connection_string: str | None = None,
        enable_secrets: bool = True,
        enable_keys: bool = True,
        enable_certificates: bool = True,
    ):
        """
        Initialize Azure Key Vault with comprehensive configuration.

        Args:
            vault_url: Azure Key Vault URL (e.g., https://vault.vault.azure.net/)
            credential: Azure credential for authentication
            azure_identity: AzureIdentity instance for credential management
            service_name: Service name for tracing context
            service_version: Service version for metadata
            logger: Optional AzureLogger instance
            connection_string: Application Insights connection string
            enable_secrets: Enable secret operations client
            enable_keys: Enable key operations client
            enable_certificates: Enable certificate operations client

        Raises:
            ValueError: If neither credential nor azure_identity is provided
            AzureError: If client initialization fails

        """
        super().__init__(
            credential=credential,
            azure_identity=azure_identity,
            service_name=service_name,
            service_version=service_version,
            logger=logger,
            connection_string=connection_string,
        )

        self.vault_url = vault_url
        self.enable_secrets = enable_secrets
        self.enable_keys = enable_keys
        self.enable_certificates = enable_certificates

        self.secret_client: SecretClient | None = None
        self.key_client: KeyClient | None = None
        self.certificate_client: CertificateClient | None = None

        self.logger.info(
            f"Azure Key Vault initialized for service '{service_name}' v{service_version}",
            extra={
                "vault_url": vault_url,
                "secrets_enabled": enable_secrets,
                "keys_enabled": enable_keys,
                "certificates_enabled": enable_certificates,
            },
        )

    def _ensure_secret_client(self) -> SecretClient:
        """Return the secret client, constructing it lazily on first use."""
        if not self.enable_secrets:
            error_msg = "Secret operations not enabled. Set enable_secrets=True during initialization."
            self.logger.error(error_msg)
            raise RuntimeError(error_msg)
        if self.secret_client is None:
            self.secret_client = SecretClient(vault_url=self.vault_url, credential=self.credential)
            self.logger.debug("SecretClient lazily initialized on first use")
        return self.secret_client

    def _ensure_key_client(self) -> KeyClient:
        """Return the key client, constructing it lazily on first use."""
        if not self.enable_keys:
            error_msg = "Key operations not enabled. Set enable_keys=True during initialization."
            self.logger.error(error_msg)
            raise RuntimeError(error_msg)
        if self.key_client is None:
            self.key_client = KeyClient(vault_url=self.vault_url, credential=self.credential)
            self.logger.debug("KeyClient lazily initialized on first use")
        return self.key_client

    def _ensure_certificate_client(self) -> CertificateClient:
        """Return the certificate client, constructing it lazily on first use."""
        if not self.enable_certificates:
            error_msg = "Certificate operations not enabled. Set enable_certificates=True during initialization."
            self.logger.error(error_msg)
            raise RuntimeError(error_msg)
        if self.certificate_client is None:
            self.certificate_client = CertificateClient(vault_url=self.vault_url, credential=self.credential)
            self.logger.debug("CertificateClient lazily initialized on first use")
        return self.certificate_client

    def get_secret(self, secret_name: str, version: str | None = None, **kwargs) -> str | None:
        """
        Retrieve a secret from Azure Key Vault.

        Args:
            secret_name: Name of the secret
            version: Optional specific version of the secret
            **kwargs: Additional parameters for the secret retrieval

        Returns:
            Secret value if found, None if not found

        Raises:
            RuntimeError: If secret client is not initialized
            AzureError: If secret retrieval fails for reasons other than not found

        """
        with self.logger.create_span(
            "AzureKeyVault.get_secret",
            attributes={
                "service.name": self.service_name,
                "operation.type": "secret_retrieval",
                "keyvault.secret_name": secret_name,
                "keyvault.version": version or "latest",
                "keyvault.vault_url": self.vault_url,
            },
        ):
            secret_client = self._ensure_secret_client()

            try:
                self.logger.debug(
                    "Retrieving secret from Key Vault",
                    extra={"secret_name": secret_name, "version": version, "vault_url": self.vault_url},
                )

                secret = secret_client.get_secret(secret_name, version=version, **kwargs)

                self.logger.info(
                    "Secret retrieved successfully",
                    extra={
                        "secret_name": secret_name,
                        "version": secret.properties.version if secret.properties else None,
                        "content_type": secret.properties.content_type if secret.properties else None,
                    },
                )

                return secret.value

            except ResourceNotFoundError:
                self.logger.warning(
                    f"Secret '{secret_name}' not found in Key Vault",
                    extra={"secret_name": secret_name, "version": version},
                )
                return None
            except ClientAuthenticationError:
                self.logger.exception(
                    f"Authentication failed for secret '{secret_name}'",
                    extra={"secret_name": secret_name},
                )
                raise
            except AzureError:
                self.logger.exception(
                    f"Failed to retrieve secret '{secret_name}'",
                    extra={"secret_name": secret_name, "version": version},
                )
                raise

    def set_secret(
        self,
        secret_name: str,
        secret_value: str,
        content_type: str | None = None,
        tags: dict[str, str] | None = None,
        **kwargs,
    ) -> bool:
        """
        Set a secret in Azure Key Vault.

        Args:
            secret_name: Name of the secret
            secret_value: Value of the secret
            content_type: Optional content type for the secret
            tags: Optional tags for the secret
            **kwargs: Additional parameters for secret creation

        Returns:
            True if secret was set successfully

        Raises:
            RuntimeError: If secret client is not initialized
            AzureError: If secret creation fails

        """
        with self.logger.create_span(
            "AzureKeyVault.set_secret",
            attributes={
                "service.name": self.service_name,
                "operation.type": "secret_creation",
                "keyvault.secret_name": secret_name,
                "keyvault.content_type": content_type or "text/plain",
                "keyvault.vault_url": self.vault_url,
            },
        ):
            secret_client = self._ensure_secret_client()

            try:
                self.logger.debug(
                    "Setting secret in Key Vault",
                    extra={
                        "secret_name": secret_name,
                        "content_type": content_type,
                        "has_tags": tags is not None,
                        "vault_url": self.vault_url,
                    },
                )

                secret = secret_client.set_secret(
                    secret_name, secret_value, content_type=content_type, tags=tags, **kwargs
                )

                self.logger.info(
                    "Secret set successfully",
                    extra={
                        "secret_name": secret_name,
                        "version": secret.properties.version if secret.properties else None,
                        "content_type": secret.properties.content_type if secret.properties else None,
                    },
                )

                return True

            except AzureError:
                self.logger.exception(
                    f"Failed to set secret '{secret_name}'",
                    extra={"secret_name": secret_name, "content_type": content_type},
                )
                raise

    def delete_secret(self, secret_name: str, **kwargs) -> bool:
        """
        Delete a secret from Azure Key Vault.

        Args:
            secret_name: Name of the secret to delete
            **kwargs: Additional parameters for secret deletion

        Returns:
            True if secret was deleted successfully

        Raises:
            RuntimeError: If secret client is not initialized
            AzureError: If secret deletion fails

        """
        with self.logger.create_span(
            "AzureKeyVault.delete_secret",
            attributes={
                "service.name": self.service_name,
                "operation.type": "secret_deletion",
                "keyvault.secret_name": secret_name,
                "keyvault.vault_url": self.vault_url,
            },
        ):
            secret_client = self._ensure_secret_client()

            try:
                self.logger.debug(
                    "Deleting secret from Key Vault", extra={"secret_name": secret_name, "vault_url": self.vault_url}
                )

                secret_client.begin_delete_secret(secret_name, **kwargs)

                self.logger.info("Secret deletion initiated successfully", extra={"secret_name": secret_name})

                return True

            except ResourceNotFoundError:
                self.logger.warning(
                    f"Secret '{secret_name}' not found for deletion", extra={"secret_name": secret_name}
                )
                return False
            except AzureError:
                self.logger.exception(f"Failed to delete secret '{secret_name}'", extra={"secret_name": secret_name})
                raise

    def list_secrets(self, **kwargs) -> list[str]:
        """
        List all secrets in the Key Vault.

        Args:
            **kwargs: Additional parameters for listing secrets

        Returns:
            List of secret names

        Raises:
            RuntimeError: If secret client is not initialized
            AzureError: If listing secrets fails

        """
        with self.logger.create_span(
            "AzureKeyVault.list_secrets",
            attributes={
                "service.name": self.service_name,
                "operation.type": "secret_listing",
                "keyvault.vault_url": self.vault_url,
            },
        ):
            secret_client = self._ensure_secret_client()

            try:
                self.logger.debug("Listing secrets from Key Vault", extra={"vault_url": self.vault_url})

                secret_names = []
                for secret_property in secret_client.list_properties_of_secrets(**kwargs):
                    secret_names.append(secret_property.name)

                self.logger.info("Secrets listed successfully", extra={"secret_count": len(secret_names)})

                return secret_names

            except AzureError:
                self.logger.exception("Failed to list secrets")
                raise

    def test_connection(self) -> bool:
        """
        Test connection to Key Vault by attempting to list secrets.

        Returns:
            True if connection is successful, False otherwise

        """
        with self.logger.create_span(
            "AzureKeyVault.test_connection",
            attributes={
                "service.name": self.service_name,
                "operation.type": "connection_test",
                "keyvault.vault_url": self.vault_url,
            },
        ):
            try:
                self.logger.debug("Testing Key Vault connection", extra={"vault_url": self.vault_url})

                if self.enable_secrets:
                    list(self._ensure_secret_client().list_properties_of_secrets(max_page_size=1))
                elif self.enable_keys:
                    list(self._ensure_key_client().list_properties_of_keys(max_page_size=1))
                elif self.enable_certificates:
                    list(self._ensure_certificate_client().list_properties_of_certificates(max_page_size=1))
                else:
                    self.logger.error("No clients available for connection testing")
                    return False

                self.logger.info("Key Vault connection test successful")
                return True

            except AzureError as e:
                self.logger.warning(f"Key Vault connection test failed: {e}", extra={"vault_url": self.vault_url})
                return False


def create_azure_keyvault(
    vault_url: str,
    credential: TokenCredential | None = None,
    azure_identity: AzureIdentity | None = None,
    service_name: str = "azure_keyvault",
    service_version: str = "1.0.0",
    logger: AzureLogger | None = None,
    connection_string: str | None = None,
    enable_secrets: bool = True,
    enable_keys: bool = True,
    enable_certificates: bool = True,
) -> AzureKeyVault:
    """
    Factory function to create a cached AzureKeyVault instance.

    Returns existing instance if one with same configuration and credential
    exists. Creates a default AzureIdentity if neither credential nor
    azure_identity is provided.

    """
    return create_cached_resource(
        AzureKeyVault,
        _keyvault_instances,
        (vault_url, service_name, service_version, connection_string, enable_secrets, enable_keys, enable_certificates),
        credential=credential,
        azure_identity=azure_identity,
        service_name=service_name,
        service_version=service_version,
        logger=logger,
        connection_string=connection_string,
        vault_url=vault_url,
        enable_secrets=enable_secrets,
        enable_keys=enable_keys,
        enable_certificates=enable_certificates,
    )
