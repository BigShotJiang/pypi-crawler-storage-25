from collections.abc import AsyncGenerator
from contextlib import asynccontextmanager
from typing import Any

from azure.core.credentials import TokenCredential
from azure.core.exceptions import (
    AzureError,
    ClientAuthenticationError,
    ResourceNotFoundError,
    ServiceRequestError,
    ServiceResponseError,
)
from azure.cosmos import ContainerProxy, CosmosClient, DatabaseProxy
from azure.cosmos.aio import CosmosClient as AsyncCosmosClient

from .._cache import RingCache
from ..mgmt.identity import AzureIdentity
from ..mgmt.logging import AzureLogger
from ._base import AzureResourceBase, create_cached_resource

# CosmosDB instance caching (bounded ring buffer, max 10)
_cosmosdb_instances: RingCache = RingCache(maxsize=10)


class AzureCosmosDB(AzureResourceBase):
    """
    Azure Cosmos DB management with standardized client initialization,
    caching, and both synchronous and asynchronous operations.
    """

    def __init__(
        self,
        endpoint: str,
        credential: TokenCredential | None = None,
        azure_identity: AzureIdentity | None = None,
        service_name: str = "azure_cosmosdb",
        service_version: str = "1.0.0",
        logger: AzureLogger | None = None,
        connection_string: str | None = None,
    ):
        super().__init__(
            credential=credential,
            azure_identity=azure_identity,
            service_name=service_name,
            service_version=service_version,
            logger=logger,
            connection_string=connection_string,
        )

        self.endpoint = endpoint
        self.client: CosmosClient | None = None
        self._async_client: AsyncCosmosClient | None = None

        self.logger.info(
            f"Azure Cosmos DB initialized for service '{service_name}' v{service_version}", extra={"endpoint": endpoint}
        )

    def get_client(self) -> CosmosClient:
        """
        Get the synchronous CosmosClient, constructing it lazily on first use.

        CosmosClient.__init__ is NOT lazy — it performs an eager HTTP GET
        against the endpoint to discover read/write regions. By deferring
        construction to the first real call, we avoid failed-dependency
        telemetry (e.g. 504 Gateway Timeout) in Application Insights when the
        AzureCosmosDB instance is created at module-import time (mgmt_config)
        but never actually used by the current function invocation.
        """
        if self.client is None:
            self.client = CosmosClient(url=self.endpoint, credential=self.credential)
            self.logger.debug("CosmosClient lazily initialized on first use.")
        return self.client

    @asynccontextmanager
    async def async_client_context(self) -> AsyncGenerator[AsyncCosmosClient]:
        """
        Provide an asynchronous context manager for the Cosmos DB async client.

        Reuses the same async client across calls to avoid per-call
        connection overhead. The client is created lazily on first use.
        """
        try:
            if self._async_client is None:
                self.logger.debug("Creating reusable async client.")
                self._async_client = AsyncCosmosClient(url=self.endpoint, credential=self.credential)
            yield self._async_client
        except (ClientAuthenticationError, ServiceRequestError, ServiceResponseError):
            # On auth/connection errors, discard the stale client
            if self._async_client is not None:
                await self._async_client.close()
                self._async_client = None
            raise

    async def close_async_client(self) -> None:
        """Close the reusable async client if open."""
        if self._async_client is not None:
            await self._async_client.close()
            self._async_client = None
            self.logger.debug("Async client closed.")

    def get_database(self, database_name: str) -> DatabaseProxy:
        """Get a proxy for a database."""
        with self.logger.create_span("AzureCosmosDB.get_database"):
            return self.get_client().get_database_client(database_name)

    def get_container(self, database_name: str, container_name: str) -> ContainerProxy:
        """Get a proxy for a container."""
        with self.logger.create_span("AzureCosmosDB.get_container"):
            database_client = self.get_database(database_name)
            return database_client.get_container_client(container_name)

    def read_item(
        self,
        database_name: str,
        container_name: str,
        item_id: str,
        partition_key: str,
        max_integrated_cache_staleness_in_ms: int | None = None,
    ) -> dict[str, Any] | None:
        """Read an item from a container."""
        with self.logger.create_span("AzureCosmosDB.read_item", attributes={"item_id": item_id}):
            try:
                container_client = self.get_container(database_name, container_name)
                options = {}
                if max_integrated_cache_staleness_in_ms is not None:
                    options["max_integrated_cache_staleness_in_ms"] = max_integrated_cache_staleness_in_ms

                item = container_client.read_item(item=item_id, partition_key=partition_key, **options)
                self.logger.debug(f"Successfully read item '{item_id}'.")
                return item
            except ResourceNotFoundError:
                self.logger.warning(f"Item '{item_id}' not found.")
                return None
            except AzureError:
                self.logger.exception(f"Failed to read item '{item_id}'")
                raise

    def query_items(
        self,
        database_name: str,
        container_name: str,
        query: str,
        parameters: list[dict[str, Any]] | None = None,
        enable_cross_partition_query: bool = True,
        max_integrated_cache_staleness_in_ms: int | None = None,
    ) -> list[dict[str, Any]]:
        """Query items in a container."""
        with self.logger.create_span("AzureCosmosDB.query_items"):
            try:
                container_client = self.get_container(database_name, container_name)
                options = {"enable_cross_partition_query": enable_cross_partition_query}
                if max_integrated_cache_staleness_in_ms is not None:
                    options["max_integrated_cache_staleness_in_ms"] = max_integrated_cache_staleness_in_ms

                items = list(container_client.query_items(query=query, parameters=parameters, **options))
                self.logger.debug(f"Query returned {len(items)} items.")
                return items
            except AzureError:
                self.logger.exception("Failed to query items")
                raise

    def upsert_item(self, database_name: str, container_name: str, item: dict[str, Any]) -> dict[str, Any]:
        """Upsert an item into a container."""
        item_id = item.get("id", "N/A")
        with self.logger.create_span("AzureCosmosDB.upsert_item", attributes={"item_id": item_id}):
            try:
                container_client = self.get_container(database_name, container_name)
                result = container_client.upsert_item(body=item)
                self.logger.debug(f"Successfully upserted item '{item_id}'.")
                return result
            except AzureError:
                self.logger.exception(f"Failed to upsert item '{item_id}'")
                raise

    def delete_item(self, database_name: str, container_name: str, item_id: str, partition_key: str) -> bool:
        """
        Delete an item from a container.

        Args:
            database_name: Name of the database.
            container_name: Name of the container.
            item_id: ID of the item to delete.
            partition_key: Partition key value for the item.

        Returns:
            True if the item was deleted, False if not found.

        Raises:
            AzureError: For errors other than not found.

        """
        with self.logger.create_span("AzureCosmosDB.delete_item", attributes={"item_id": item_id}):
            try:
                container_client = self.get_container(database_name, container_name)
                container_client.delete_item(item=item_id, partition_key=partition_key)
                self.logger.debug(f"Successfully deleted item '{item_id}'.")
                return True
            except ResourceNotFoundError:
                self.logger.warning(f"Item '{item_id}' not found for deletion.")
                return False
            except AzureError:
                self.logger.exception(f"Failed to delete item '{item_id}'")
                raise


def create_azure_cosmosdb(
    endpoint: str,
    credential: TokenCredential | None = None,
    azure_identity: AzureIdentity | None = None,
    service_name: str = "azure_cosmosdb",
    service_version: str = "1.0.0",
    logger: AzureLogger | None = None,
    connection_string: str | None = None,
) -> AzureCosmosDB:
    """
    Factory function to create a cached AzureCosmosDB instance.

    Returns existing instance if one with same configuration exists.
    """
    return create_cached_resource(
        AzureCosmosDB,
        _cosmosdb_instances,
        (endpoint, service_name, service_version, connection_string),
        credential=credential,
        azure_identity=azure_identity,
        service_name=service_name,
        service_version=service_version,
        logger=logger,
        connection_string=connection_string,
        endpoint=endpoint,
    )
