"""
Azure-integrated logging with OpenTelemetry distributed tracing.

Architecture
------------
Two separate concerns, two separate entry points:

1. ``bootstrap_azure_monitor()`` -- call once at process startup. Configures
   the Azure Monitor exporter, GenAI instrumentors, and resource attributes.
   Idempotent.

2. ``AzureLogger(name)`` -- create anywhere. A thin ``logging.Logger``-shaped
   wrapper that auto-enriches every record with correlation ID, trace
   context, baggage, and service metadata.

``trace_function`` is available as both a module-level decorator and a method
on ``AzureLogger`` for ergonomics.
"""

from __future__ import annotations

import contextlib
import contextvars
import functools
import inspect
import logging
import os
import time
import uuid
from datetime import UTC, datetime
from typing import TYPE_CHECKING, Any

from azure.core.exceptions import AzureError
from azure.monitor.opentelemetry import configure_azure_monitor
from opentelemetry import baggage, trace
from opentelemetry.sdk.resources import Resource
from opentelemetry.trace import Status, StatusCode

if TYPE_CHECKING:
    from collections.abc import Callable

    from opentelemetry.context import Context

__all__ = [
    "AzureLogger",
    "bootstrap_azure_monitor",
    "trace_function",
]


# ---------------------------------------------------------------------------
# Process-wide state
# ---------------------------------------------------------------------------

_BOOTSTRAPPED: bool = False
_TELEMETRY_ENABLED: bool = False

# Module-level contextvar: every AzureLogger in the same task tree sees the
# same correlation ID. Scoped set/reset via trace_function so long-lived
# workers do not leak IDs across requests.
_correlation_id: contextvars.ContextVar[str | None] = contextvars.ContextVar("azpaddypy_correlation_id", default=None)

_RESERVED_LOG_RECORD_ATTRS: frozenset[str] = frozenset(
    {
        "name",
        "msg",
        "args",
        "levelname",
        "levelno",
        "pathname",
        "filename",
        "module",
        "exc_info",
        "exc_text",
        "stack_info",
        "lineno",
        "funcName",
        "created",
        "msecs",
        "relativeCreated",
        "thread",
        "threadName",
        "processName",
        "process",
        "getMessage",
    }
)


# ---------------------------------------------------------------------------
# Bootstrap
# ---------------------------------------------------------------------------


def bootstrap_azure_monitor(
    *,
    service_name: str,
    service_version: str = "1.0.0",
    connection_string: str | None = None,
    resource_attributes: dict[str, str] | None = None,
    instrumentation_options: dict[str, Any] | None = None,
    capture_gen_ai_content: bool = False,
    install_genai_instrumentors: bool = True,
    enable_gen_ai_trace_propagation: bool = True,
) -> bool:
    """
    Configure Azure Monitor exporter and GenAI instrumentors once per process.

    Idempotent -- subsequent calls are no-ops. Returns True if telemetry is
    active, False if disabled (no connection string or exporter error).

    Args:
        service_name: Cloud role name for Application Insights Application Map.
        service_version: Service version metadata.
        connection_string: Application Insights connection string. Falls back
            to ``APPLICATIONINSIGHTS_CONNECTION_STRING``.
        resource_attributes: Extra OpenTelemetry resource attributes.
        instrumentation_options: Azure Monitor instrumentation options.
        capture_gen_ai_content: Enable prompt/completion content recording on
            GenAI spans. Off by default to avoid shipping prompts to App
            Insights unintentionally.
        install_genai_instrumentors: Install OpenAI v2 + AIProjectInstrumentor
            so GenAI calls produce Foundry-shaped spans.
        enable_gen_ai_trace_propagation: Propagate W3C traceparent headers
            into outbound OpenAI SDK calls so server spans correlate.

    """
    global _BOOTSTRAPPED, _TELEMETRY_ENABLED
    if _BOOTSTRAPPED:
        return _TELEMETRY_ENABLED

    cs = connection_string or os.environ.get("APPLICATIONINSIGHTS_CONNECTION_STRING")
    if not cs:
        logging.getLogger(__name__).warning("APPLICATIONINSIGHTS_CONNECTION_STRING not set; telemetry disabled")
        _BOOTSTRAPPED = True
        return False

    # GenAI env vars must be set BEFORE instrumentors .instrument() -- they
    # are read at instrumentation time and flipping them later is racy.
    if capture_gen_ai_content:
        os.environ.setdefault("OTEL_INSTRUMENTATION_GENAI_CAPTURE_MESSAGE_CONTENT", "true")
        os.environ.setdefault("AZURE_TRACING_GEN_AI_CONTENT_RECORDING_ENABLED", "true")
    if enable_gen_ai_trace_propagation:
        os.environ.setdefault("AZURE_TRACING_GEN_AI_ENABLE_TRACE_CONTEXT_PROPAGATION", "true")
    if install_genai_instrumentors:
        # Feature gate required by azure-ai-projects' AIProjectInstrumentor.
        os.environ.setdefault("AZURE_EXPERIMENTAL_ENABLE_GENAI_TRACING", "true")

    resource = Resource.create(
        {
            "service.name": service_name,
            "service.version": service_version,
            **(resource_attributes or {}),
        }
    )

    try:
        configure_azure_monitor(
            connection_string=cs,
            resource=resource,
            enable_live_metrics=True,
            instrumentation_options=instrumentation_options or {},
            logger_name=service_name,
        )
        _TELEMETRY_ENABLED = True
    except (AzureError, RuntimeError, ValueError):
        logging.getLogger(__name__).exception("Failed to configure Azure Monitor")
        _BOOTSTRAPPED = True
        return False

    if install_genai_instrumentors:
        _install_genai_instrumentors()

    _BOOTSTRAPPED = True
    return True


def _install_genai_instrumentors() -> None:
    """Install OpenAI + AIProjectInstrumentor if their packages are present."""
    try:
        from opentelemetry.instrumentation.openai_v2 import OpenAIInstrumentor

        inst = OpenAIInstrumentor()
        if not inst.is_instrumented_by_opentelemetry:
            inst.instrument()
    except ImportError:
        pass

    try:
        from azure.ai.projects.telemetry import AIProjectInstrumentor

        inst = AIProjectInstrumentor()
        if not inst.is_instrumented():
            inst.instrument()
    except ImportError:
        pass
    except Exception:
        logging.getLogger(__name__).exception("AIProjectInstrumentor install failed")


# ---------------------------------------------------------------------------
# AzureLogger
# ---------------------------------------------------------------------------


class AzureLogger:
    """
    stdlib-compatible logger that auto-enriches every record.

    Pre-requisite: ``bootstrap_azure_monitor()`` has been called at process
    startup. ``AzureLogger`` itself never configures exporters -- that is
    strictly a bootstrap concern.

    Usage:
        logger = AzureLogger(__name__)
        logger.info("field filled: selector=%s", selector)
        logger.error("field failed: %s", reason, exc_info=True)

    Signature matches stdlib ``logging.Logger`` (``msg`` as first positional)
    so AzureLogger can be passed anywhere a Logger is expected.
    """

    def __init__(
        self,
        name: str,
        *,
        level: int = logging.INFO,
        enable_console_logging: bool = True,
    ) -> None:
        if not name:
            msg = "AzureLogger requires a non-empty name, e.g. AzureLogger(__name__)"
            raise ValueError(msg)
        self.name = name
        self._logger = logging.getLogger(name)
        self._logger.setLevel(level)
        if enable_console_logging and not self._has_console_handler():
            self._attach_console_handler()
        self._tracer = trace.get_tracer(name)

    # --- stdlib-compatible logging API ---

    def debug(self, msg: object, *args: object, **kwargs: Any) -> None:
        self._log(logging.DEBUG, msg, args, kwargs)

    def info(self, msg: object, *args: object, **kwargs: Any) -> None:
        self._log(logging.INFO, msg, args, kwargs)

    def warning(self, msg: object, *args: object, **kwargs: Any) -> None:
        self._log(logging.WARNING, msg, args, kwargs)

    def error(self, msg: object, *args: object, **kwargs: Any) -> None:
        self._log(logging.ERROR, msg, args, kwargs)

    def exception(self, msg: object, *args: object, **kwargs: Any) -> None:
        kwargs.setdefault("exc_info", True)
        self._log(logging.ERROR, msg, args, kwargs)

    def critical(self, msg: object, *args: object, **kwargs: Any) -> None:
        self._log(logging.CRITICAL, msg, args, kwargs)

    def log(self, level: int, msg: object, *args: object, **kwargs: Any) -> None:
        self._log(level, msg, args, kwargs)

    def isEnabledFor(self, level: int) -> bool:  # noqa: N802 - stdlib name
        return self._logger.isEnabledFor(level)

    def setLevel(self, level: int) -> None:  # noqa: N802 - stdlib name
        self._logger.setLevel(level)

    @property
    def level(self) -> int:
        return self._logger.level

    def getChild(self, suffix: str) -> AzureLogger:  # noqa: N802 - stdlib name
        """Return a child logger. Shares handlers via stdlib propagation."""
        return AzureLogger(
            f"{self.name}.{suffix}",
            level=self._logger.level,
            enable_console_logging=False,
        )

    def _log(self, level: int, msg: object, args: tuple, kwargs: dict) -> None:
        if not self._logger.isEnabledFor(level):
            return  # short-circuit keeps eager f-strings cheap at disabled levels
        kwargs["extra"] = self._enrich(kwargs.get("extra"))
        # stacklevel=3: _log -> info/error/... -> caller. Makes
        # %(filename)s:%(lineno)d point to the caller, not logging.py.
        kwargs.setdefault("stacklevel", 3)
        self._logger.log(level, msg, *args, **kwargs)

    # --- console handler setup ---

    def _has_console_handler(self) -> bool:
        return any(
            isinstance(h, logging.StreamHandler) and not isinstance(h, logging.FileHandler)
            for h in self._logger.handlers
        )

    def _attach_console_handler(self) -> None:
        handler = logging.StreamHandler()
        handler.setFormatter(
            logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s - %(pathname)s:%(lineno)d")
        )
        self._logger.addHandler(handler)

    # --- correlation / baggage helpers (module-scoped state) ---

    @staticmethod
    def correlation_id() -> str | None:
        """Return the currently active correlation ID, if any."""
        return _correlation_id.get()

    @staticmethod
    def set_correlation_id(value: str | None) -> contextvars.Token:
        """Set correlation ID and return a token for scoped reset."""
        return _correlation_id.set(value)

    @staticmethod
    def reset_correlation_id(token: contextvars.Token) -> None:
        _correlation_id.reset(token)

    @staticmethod
    def set_baggage(key: str, value: str) -> Context:
        return baggage.set_baggage(key, value)

    @staticmethod
    def get_baggage(key: str) -> str | None:
        value = baggage.get_baggage(key)
        return value if isinstance(value, str) else None

    @staticmethod
    def get_all_baggage() -> dict[str, str]:
        return {k: v for k, v in baggage.get_all().items() if isinstance(v, str)}

    # --- tracing ergonomics ---

    def trace_function(
        self,
        name: str | None = None,
        *,
        record_args: bool = False,
        record_result: bool = False,
    ) -> Callable:
        """Convenience wrapper for the module-level ``trace_function``."""
        return trace_function(name=name, record_args=record_args, record_result=record_result)

    def create_span(
        self,
        span_name: str,
        attributes: dict[str, str | int | float | bool] | None = None,
    ):
        """Start a span as current with service + correlation metadata."""
        attrs: dict[str, str | int | float | bool] = {"service.name": self.name}
        cid = _correlation_id.get()
        if cid:
            attrs["correlation.id"] = cid
        if attributes:
            attrs.update(attributes)
        return self._tracer.start_as_current_span(span_name, attributes=attrs)

    def add_span_attributes(self, attributes: dict[str, str | int | float | bool]) -> None:
        span = trace.get_current_span()
        if span and span.is_recording():
            for k, v in attributes.items():
                span.set_attribute(k, v)

    def add_span_event(self, name: str, attributes: dict[str, Any] | None = None) -> None:
        span = trace.get_current_span()
        if span and span.is_recording():
            span.add_event(name, attributes or {})

    def flush(self) -> None:
        """Flush console handlers and force-flush the tracer provider."""
        for handler in self._logger.handlers:
            handler.flush()
        provider = trace.get_tracer_provider()
        force_flush = getattr(provider, "force_flush", None)
        if callable(force_flush):
            with contextlib.suppress(AzureError, RuntimeError):
                force_flush(timeout_millis=5000)

    # --- enrichment ---

    def _enrich(self, extra: dict[str, Any] | None) -> dict[str, Any]:
        enriched: dict[str, Any] = {
            "service_name": self.name,
            "timestamp": datetime.now(tz=UTC).isoformat(),
        }

        cid = _correlation_id.get()
        if cid:
            enriched["correlation_id"] = cid

        span = trace.get_current_span()
        ctx = span.get_span_context() if span else None
        if ctx is not None and ctx.is_valid:
            enriched["trace_id"] = format(ctx.trace_id, "032x")
            enriched["span_id"] = format(ctx.span_id, "016x")

        bag = dict(baggage.get_all())
        if bag:
            safe = {k: v for k, v in bag.items() if k not in _RESERVED_LOG_RECORD_ATTRS}
            if safe:
                enriched["baggage"] = safe

        if extra:
            for k, v in extra.items():
                if k not in _RESERVED_LOG_RECORD_ATTRS:
                    enriched[k] = v

        return enriched


# ---------------------------------------------------------------------------
# trace_function decorator
# ---------------------------------------------------------------------------


def trace_function(
    name: str | None = None,
    *,
    record_args: bool = False,
    record_result: bool = False,
) -> Callable:
    """
    Decorate a function (sync or async) with an OpenTelemetry span.

    - Generates a UUID4 correlation ID on entry if none is active, scoped to
      the span lifetime (reset on exit -- no cross-request leaks).
    - Duration and code.function/namespace are always recorded as span
      attributes. Prefer reading these from App Insights ``dependencies`` /
      ``requests`` tables rather than emitting duplicate log records.
    - Exceptions are recorded on the span and re-raised.

    Args:
        name: Custom span name. Defaults to ``{module}.{qualname}``.
        record_args: Capture call arguments as span attributes (truncated to
            1000 chars). Off by default -- opt in for non-sensitive calls.
        record_result: Capture return value as a span attribute (truncated).
            Off by default.

    """
    tracer = trace.get_tracer(__name__)

    def decorator(func: Callable) -> Callable:
        span_name = name or f"{func.__module__}.{func.__qualname__}"
        try:
            param_names = list(inspect.signature(func).parameters)
        except (TypeError, ValueError):
            param_names = []
        is_async = inspect.iscoroutinefunction(func)

        def _annotate(span, args: tuple, kwargs: dict) -> None:
            span.set_attribute("code.function", func.__name__)
            span.set_attribute("code.namespace", func.__module__)
            cid = _correlation_id.get()
            if cid:
                span.set_attribute("correlation.id", cid)
            if record_args:
                for i, v in enumerate(args):
                    key = param_names[i] if i < len(param_names) else f"arg_{i}"
                    span.set_attribute(f"arg.{key}", _fmt_attr(v))
                for k, v in kwargs.items():
                    span.set_attribute(f"arg.{k}", _fmt_attr(v))

        def _finalize(span, t0: float, result: Any) -> None:
            span.set_attribute("duration_ms", (time.perf_counter() - t0) * 1000.0)
            if record_result and result is not None:
                span.set_attribute("result.type", type(result).__name__)
                span.set_attribute("result", _fmt_attr(result))

        if is_async:

            @functools.wraps(func)
            async def async_wrapper(*args: Any, **kwargs: Any) -> Any:
                with tracer.start_as_current_span(span_name) as span:
                    token = _ensure_correlation_id()
                    _annotate(span, args, kwargs)
                    t0 = time.perf_counter()
                    try:
                        result = await func(*args, **kwargs)
                        _finalize(span, t0, result)
                        return result
                    except Exception as e:
                        span.set_status(Status(StatusCode.ERROR, str(e)))
                        span.record_exception(e)
                        raise
                    finally:
                        if token is not None:
                            _correlation_id.reset(token)

            return async_wrapper

        @functools.wraps(func)
        def sync_wrapper(*args: Any, **kwargs: Any) -> Any:
            with tracer.start_as_current_span(span_name) as span:
                token = _ensure_correlation_id()
                _annotate(span, args, kwargs)
                t0 = time.perf_counter()
                try:
                    result = func(*args, **kwargs)
                    _finalize(span, t0, result)
                    return result
                except Exception as e:
                    span.set_status(Status(StatusCode.ERROR, str(e)))
                    span.record_exception(e)
                    raise
                finally:
                    if token is not None:
                        _correlation_id.reset(token)

        return sync_wrapper

    return decorator


def _ensure_correlation_id() -> contextvars.Token | None:
    """Set a UUID4 correlation ID if none is active. Return the reset token."""
    if _correlation_id.get() is None:
        return _correlation_id.set(str(uuid.uuid4()))
    return None


def _fmt_attr(value: Any) -> str:
    """Format a span attribute value: stringify + truncate."""
    try:
        s = str(value)
    except Exception:  # noqa: BLE001
        return "<unrepr>"
    return s if len(s) <= 1000 else s[:1000] + "..."
