"""
Shared utilities for Azure management and resource clients.

Provides common setup functions for logger initialization to reduce code
duplication across management and resource classes.
"""

from .logging import AzureLogger


def setup_logger(logger: AzureLogger | None, service_name: str) -> AzureLogger:
    """
    Return the provided logger, or create one named after the service.

    Args:
        logger: Optional existing AzureLogger instance.
        service_name: Logger name used when ``logger`` is None.

    """
    if logger is not None:
        return logger
    return AzureLogger(service_name)
