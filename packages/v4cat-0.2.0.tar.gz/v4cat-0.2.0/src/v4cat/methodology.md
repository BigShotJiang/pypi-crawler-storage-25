# Symmetry-Break Cataloguing — a generic methodology with a small ISA

The processor catalogue in `symmetries.md` and `symmetries.sql` is one
application of a more general methodology: *cataloguing a domain by
accumulating symmetry breaks, with witnesses, refinements, and
wedge-product audits — where time and lineage are themselves
breaks-on-objects, so attribution (including the so-called
"retroactive" case) emerges as a derived query rather than a
primitive verb*. This document factors out the methodology into
something domain-agnostic.

## What's generalisable

The processor catalogue exhibits patterns that aren't processor-specific:

1. **Domain of objects**: processors / non-processor witnesses (Brainfuck,
   lambda calculus). Generic: a set of objects in some domain.
2. **Symmetry breaks**: named structural distinctions. Generic: named
   partitions of the object space.
3. **Witnesses**: per-(object, break) edges with contribution kinds
   (`origin`, `confirms`, `refines`, ...). Generic: typed edges in a
   bipartite graph.
4. **Refinements**: per-edge named attribute additions. Generic: named
   annotations on edges.
5. **Axes**: meta-classification (Spatial/Temporal/Parallel/...). Generic:
   tags on breaks.
6. **Tensions**: structural concerns about implementation alignment.
   Generic: triples (concern, breaks-involved, status).
7. **Time and lineage as breaks-themselves**: the catalogue's
   chronological-origin and inheritance-relation aren't special verbs
   *applied to* the graph; they're symmetry breaks *over* objects.
   Once the methodology admits time as a break (year-of-articulation
   partitions objects) and lineage as a break (descent partitions
   objects), attribution emerges as a *derivation* via tropical query
   (MIN over the time-break, restricted to origin-class witnesses).
   "Retroactive" is just a label for the case where origin's year
   precedes catalogue-introduction's year — not a special primitive.
8. **Schema-itself-evolves-via-breaks**: the data shape grows as new
   structural primitives surface. Generic: schema breaks are additive
   rules over the meta-schema.
9. **Snap-to-grid**: when accumulated breaks match the original request,
   the deliverable is readable. Generic: convergence detection.
10. **Wedge-product audits**: cross-checking representation A against
    representation B to find gaps. Generic: paired-source reconciliation.

None of these depend on processor architectures. The methodology applies
to any domain where:

- Objects accumulate over time
- Their structural distinctions can be named as symmetry breaks
- Multiple witnesses confirm or refine each break
- The catalogue's exposition order may differ from chronological order

## Examples of other applicable domains

- **Programming languages**: breaks like "type-system soundness mode"
  (gradual / strict / latent), "garbage collection model" (refcount /
  tracing / region), "concurrency primitives" (threads / actors / fibers
  / async). Witnesses: C, Haskell, Rust, Python, Erlang, Go. Retroactive
  attribution: ALGOL 60 introduced lexical scoping, not LISP.
- **Cryptographic primitives**: breaks like "post-quantum security",
  "side-channel resistance", "constant-time guarantees". Witnesses:
  RSA, ECC, ML-KEM, AES, ChaCha20. Q-numbered breaks track structural
  innovations (random oracle model, IND-CCA security, ...).
- **Database systems**: breaks like "consistency model" (strong /
  eventual / causal), "partitioning scheme" (hash / range / consistent-
  hash), "transaction model" (ACID / BASE). Witnesses: PostgreSQL,
  Cassandra, FoundationDB, Spanner.
- **Mathematical structures**: breaks like "associativity", "identity",
  "inverses", "commutativity". Witnesses: magma, semigroup, monoid,
  group, abelian group, ring, field. Q-numbered breaks are *axioms*; the
  refinement-axiom-by-refinement-axiom approach is what magma theory
  *already does* (and what symmetries.md's "lineage" section names).
- **File systems**: breaks like "journaling", "copy-on-write",
  "snapshots", "checksums", "deduplication". Witnesses: ext4, ZFS,
  btrfs, APFS, ReFS.
- **Network protocols**: breaks like "reliability", "ordering",
  "flow control", "encryption", "multiplexing". Witnesses: TCP, UDP,
  QUIC, HTTP/3, WireGuard.

The methodology's value: it produces *queryable structure* that survives
context loss across time, vendor disagreements, and shifting priorities.
A processor catalogue accumulated over months becomes a graph that
answers "which break was originated where?" in a query rather than via
human memory.

## The data shape (NOSQL-flavour)

The processor catalogue uses a relational schema, but the underlying
data is fundamentally a **labelled bipartite graph**: breaks ↔ objects,
with typed edges. Three NOSQL representations capture it naturally:

### Document store (JSON-shaped)

```json
{
  "kind": "break",
  "id": "Q89",
  "name": "Hierarchical address translation with cached lookup",
  "axes": ["spatial"],
  "status": "active",
  "invariant": {
    "partition": "Linear addresses partitioned by translation outcome",
    "preservation": "Translation preserved between TLB fills until invalidate",
    "temporal_axis_kind": "cycle_count"
  },
  "witnesses": [
    {"object": "system_360_67", "kind": "origin", "year": 1965},
    {"object": "80386", "kind": "catalogue-introduces", "year": 1985},
    {"object": "68030", "kind": "cross-vendor", "year": 1987,
     "notes": "tree-structured 1-4 levels via TC; ATC vs TLB"},
    {"object": "system_370_xa", "kind": "refines", "year": 1983,
     "refinements": ["dynamic-address-spaces", "access-register-mode"]}
  ],
  "instances": {
    "80386":      {"levels": 2, "page_size": 4096, "base_register": "CR3"},
    "68030":      {"levels": 4, "page_size": 4096, "base_register": "CRP"},
    "system_370": {"levels": 2, "page_size": 4096, "base_register": "CR1"}
  }
}
```

Each break is one document; witnesses are nested arrays; per-witness
detail (page_table / alias / atomic_op / etc.) lives in `instances`.

### Graph store (Cypher-shaped)

```cypher
CREATE (q89:Break {
  id: 'Q89',
  name: 'Hierarchical address translation with cached lookup'
})
CREATE (s_67:Spec {id: 'system_360_67', year: 1965})
CREATE (s_386:Spec {id: '80386', year: 1985})
CREATE (s_67)-[:ORIGINATED {kind: 'origin'}]->(q89)
CREATE (s_386)-[:CATALOGUE_INTRODUCES]->(q89)
CREATE (q89)-[:HAS_AXIS]->(:Axis {name: 'spatial'})
```

Edges carry the contribution kind directly. Originator-by-year emerges
from a path query that ranks origin-class edges by the object's year.

### Triple store (RDF-shaped)

```turtle
:q89  rdf:type           :Break .
:q89  :name              "Hierarchical address translation" .
:q89  :hasAxis           :spatial .
:s360_67  :originated    :q89 .
:s360_67  :year          1965 .
:s386     :catalogueIntroduces  :q89 .
:s386     :year          1985 .
```

Each fact is one triple; SPARQL handles tropical queries naturally
(`SELECT ?spec WHERE { ?spec :originated ?b . } ORDER BY ASC(?year) LIMIT 1`).

All three shapes are equivalent at the data-content level; they differ
in which queries are natural. The relational SQL we used in
`symmetries.sql` is a fourth equivalent shape — relational normal form
of the same graph.

The ISA below abstracts over which shape the runtime chooses.

## Time and lineage are breaks themselves

A foundational observation that simplifies the ISA: *time and lineage
are not special verbs applied to the graph; they're symmetry breaks
over objects, recorded with the same machinery as every other break.*

This means:

- **Year-of-articulation** is a structural attribute on objects —
  partitioning the object space by chronological order. The catalogue
  records it once per object; every "originator" question becomes a
  tropical query (MIN-year over origin-class witness edges).
- **Lineage / descent** is a structural relation between objects —
  partitioning the object space by family / vendor / inheritance path.
  Recorded as edges of kind `inherits` or `descended-from`; "what does
  X inherit from Y?" becomes a transitive-closure query.
- **Catalogue-exposition order** is a third such structural attribute —
  separate from year because exposition follows the framework's design
  lineage rather than chronology. (For the processor catalogue, 6502
  is exposition-order 1 even though the System/360 predates it by 11
  years.) "First-seen-in-catalogue" is MIN(exposition_order) over
  `catalogue-introduces` edges.

Once these three are recorded as primary data, **attribution is always
derived**. There's no special "retroactive attribution" verb because
there's no special case: every origin query is the same MIN-year over
the same edges; the *gap* between origin's year and first-seen's year
is just an arithmetic difference, named "retroactive" only when
positive.

The implication: the ISA below has *no* `RETRO` verb. The first time
the catalogue analyses Q89 at the 80386, an `origin` witness from
80386 is added. Later, when the System/360/67 is examined, an `origin`
witness from System/360/67 is added. The view's MIN-year query
naturally picks the System/360/67 (1965) over the 80386 (1985); no
correction step is needed.

This is the same move the framework's own Q72 (cross-cutting quotient)
names: every symmetry plane has a normal axis along which the
symmetric side parameterises. Time is the canonical axis. Treating
time as a break-on-objects (rather than a verb-on-the-catalogue) is
the methodology's structural commitment to its own Q72.

## The Klein-four read core

A symmetry of the methodology surfaces under one further compression:
*every read is a comparison*. There is no unary query. What looks
unary —"what breaks does spec X originate?", "what's missing from
the catalogue?" — is always a binary comparison whose right-hand
referent is hidden by convention (a default universe, a normative
expectation, a derived view).

Make the comparison explicit, and the read layer reduces to **one
primitive**.

### KQUERY: the classifier

Given two predicates over a bounded universe `U`:

```text
A : U → {0,1}
B : U → {0,1}
```

every `x ∈ U` lands in exactly one of four cells determined by its
membership signature:

```text
                B = 0           B = 1
            ┌────────────┬─────────────┐
   A = 0   │  00 BLIND  │  01 RIGHT   │
            ├────────────┼─────────────┤
   A = 1   │  10 LEFT   │  11 AGREE   │
            └────────────┴─────────────┘
```

Those four cells form a Klein four-group `V₄ ≅ ℤ₂ × ℤ₂`: the group
of *membership signatures* (not of truth values).

**KQUERY is a classifier**, not a filter. Algebraically:

```text
KQUERY(A, B; U) : U → ℤ₂ × ℤ₂
                  x ↦ (A(x), B(x))
```

The four cells are the fibers of this function. Selection
(`emit={cells}`) is the post-classifier projection.

### Every other read is sugar

Each named read in the methodology is a specific selection from the
KQUERY classifier:

```text
QUERY(A)         := KQUERY(A, U)        emit={11}
WEDGE(A, B)      := KQUERY(A, B)        emit={10, 01}
AGREE(A, B)      := KQUERY(A, B)        emit={11}
LEFT_RESIDUE     := KQUERY(A, B)        emit={10}
RIGHT_RESIDUE    := KQUERY(A, B)        emit={01}
COVERAGE(A, B)   := KQUERY(A, B)        emit={10, 01, 11}
BLIND(A, B; U)   := KQUERY(A, B; U)     emit={00}
SYM_DIFF(A, B)   := KQUERY(A, B)        emit={10, 01}   (= WEDGE)
INTERSECTION     := KQUERY(A, B)        emit={11}       (= AGREE)
```

The full Boolean algebra over A and B sits inside the four cells.
Nothing is lost; nothing further is reducible.

### The 00 cell — shared blindness as a methodological object

Most diff/audit tools see only `10` and `01`. KQUERY also exposes
`11` (agreement) and crucially `00` — *shared blindness*: items in
the universe that **neither** representation accounts for.

For a bounded universe `U`:

```text
00 = U \ (A ∪ B)    — what falls outside both representations
```

Examples from the catalogue:

```text
U = paged-spec frames declared
A = paged specs (page_table != None)
B = specs with restart-suitable frames

11 = paged AND restart-suitable    (good: virtual memory works)
10 = paged BUT NOT restart-suitable (Q92 violation)
01 = restart-suitable BUT NOT paged (fine: pre-VM specs)
00 = neither paged nor restart-suitable (e.g. 80286 — could not
     participate in productive virtual memory at all)
```

The `00` cell isn't a violation of consistency; it's a
*methodological object* in its own right — the place where the
universe contains items that *neither* representation has anything
to say about. Surfacing it refuses what we might call the
**metaphysics of coverage**: the assumption that any A or B
together exhaust their domain.

### Why this lands philosophically

KQUERY tightens the Yoneda+Derrida commitments:

- **Yoneda exact.** No referent is ever inspected alone. Unary
  query is revealed as "binary comparison with an implicit universal
  on the right." Identity is *only* relational.
- **Derrida exact.** Each cell corresponds to a Derridean role:
  - `11` — apparent presence / agreement
  - `10`, `01` — différance / displacement (what one trace says the
    other does not)
  - `00` — trace of absence / shared blindness; what's *excluded*
    from both, and constitutive of what the comparison can mean
- **Errors become geometry.** Q92 violations aren't an exception
  type; they're points in the `10` cell of a particular KQUERY.
  Convergence is `10 ∪ 01 = ∅` for a chosen comparison.
- **Paradigms are derived regions.** "Paradigm" is just a referent
  the user constructs explicitly; once explicit, it's subject to
  the same comparison machinery as everything else. There's no
  privileged paradigm-position from which everything else is read.

### One-line summary

> *A catalogue read is not a query but a comparison: every
> interrogation of structure is a Klein-four partition of a bounded
> universe induced by two traces.*

Everything else is sugar.

## The ISA

A small, orthogonal set of operations that compose to build up the
catalogue. Each has clear semantics; each is implementable against
any of the four data-shape options.

### Core verbs (foundational)

#### `INTRODUCE <kind> <id> [attrs]`

Add a new object of a given kind. Kinds: `break`, `object`, `axis`,
`tension` (and any user-defined). Idempotent on `id`. The `year` and
`lineage` attributes on `object` are first-class — they're how time
and lineage enter the graph.

```text
INTRODUCE break  Q89    name="Paging" axes=[spatial]
INTRODUCE object 80386  kind=processor year=1985 lineage=[x86, intel]
INTRODUCE object system_360_67 kind=processor year=1965 lineage=[mainframe, ibm]
```

#### `WITNESS <subject> <break> <kind> [notes]`

Record a contribution edge. Kinds form the methodology's vocabulary
(documented inline in `symmetries.sql`'s S3 comment):
`origin`, `catalogue-introduces`, `confirms`, `refines`,
`first-witness`, `precedes`, `cross-vendor`, `inherits`,
`deferred-candidate`, `sibling-boundary`, `gates-with-fault`.

```text
WITNESS system_360_67 Q89 origin
WITNESS 80386         Q89 catalogue-introduces
WITNESS 80386         Q89 origin
WITNESS 68030         Q89 cross-vendor "tree-structured 1-4 levels"
```

The originator emerges from the witness graph plus the year attribute:
`MIN(s.year)` over `origin` and `catalogue-introduces` edges. With
both System/360/67 (1965) and 80386 (1985) carrying `origin` edges to
Q89, the originator is System/360/67 — derived, not declared.

#### `REFINE <break> <object> <name> [description]`

Annotate a (break, object) edge with a named refinement. Multiple
refinements per edge admitted.

```text
REFINE Q89 system_370_xa dynamic-address-spaces "multi-context"
REFINE Q89 system_370_xa access-register-mode  "AR.ASN selects context"
```

#### `KQUERY <left> <right>; <universe> <equivalence> <emit>`

The Klein-four read primitive — the *only* primitive read.

Compares two referents (sets, views, sources, rules, projections,
closures, snapshots, expected covers — any predicate over the
universe) and returns the four-cell membership partition.

```text
KQUERY symmetries_md_breaks symmetries_sql_breaks emit=10,01
   → drift between prose and structured form

KQUERY introduced_objects   objects_with_witnesses emit=10
   → which introduced objects lack any witness?

KQUERY required_q92_frames  actual_restart_suitable emit=10
   → Q92 violations: paged specs without restart-suitable frames

KQUERY declared_breaks      observed_phenomena emit=01 universe=U
   → which observed phenomena are uncovered by the schema?

KQUERY a b emit=00 universe=U
   → shared blindness — what's in U that neither A nor B touches
```

Conventional named reads are aliases (sugar):

```text
QUERY(A)        := KQUERY A U emit=11
WEDGE(A,B)      := KQUERY A B emit=10,01
AGREE(A,B)      := KQUERY A B emit=11
COVERAGE(A,B)   := KQUERY A B emit=10,01,11
BLIND(A,B,U)    := KQUERY A B emit=00 universe=U
```

### Modal verbs (lifecycle)

#### `DEFER <break>`

Mark a break as a deferred candidate (named but not structurally
adopted). Sets a witness with kind=`deferred-candidate`.

```text
DEFER Q85    -- MSP430 introduced Q85 as a deferred candidate
```

#### `PROMOTE <break> [reason]`

Promote a deferred break to active. Requires a recent witness with
kind=`confirms` or `first-witness` from a different object.

```text
PROMOTE Q85 reason="80186 second witness"
```

#### `BOUNDARY <break> <reason>`

Mark a break as a deliberate metamodel non-extension (the
sibling-framework boundary). Q81 is the canonical example.

```text
BOUNDARY Q81 "multi-CPU systems handled via sibling composition"
```

### Schema-evolution verbs

The schema itself evolves. These verbs add new raw structure when a
new structural primitive is forced.

#### `KIND.NEW <name> <attr_schema>`

Define a new object kind. The processor catalogue's `tension` kind
was added at S7; a future kind might be `theorem` or `proof`.

#### `PREDICATE.NEW <name> <signature>`

Define a new edge predicate. Adding `precedes` (introduced at S8 in
the symmetries-catalogue work) is an example.

#### `AXIS.NEW <name>`

Define a new meta-axis. The 6800 work added `eventual` to the
original 4-axis tuple via this verb.

These three verbs are *schema-breaks of the meta-schema* — each one
records that the methodology's own data shape has admitted a new kind
of fact.

### Analytic queries (derived; no state mutation)

Each is either a KQUERY selection or a tropical aggregate. None of
them mutate state.

Tropical aggregates (named functions over the witness graph; not
KQUERY but used together with it):

- **`TROPICAL_MIN(axis_column, witness_kinds, [break_], [direction])`** —
  the framework's *generic* tropical operator. For each break,
  finds the spec(s) where `axis_column` is at its extremum among
  witnesses with the given kinds. The framework's commitment is
  to tropical aggregates over ordered columns; `year` and
  `catalogue_order` are two canonical examples, but any ordered
  column on `specs` admits the same operator. See `theory.md` § 3.
- **`ORIGIN(break)`** — sugar: `TROPICAL_MIN(axis_column='year',
  witness_kinds=('origin', 'catalogue-introduces'))`.
- **`FIRST_SEEN(break)`** — sugar: `TROPICAL_MIN(axis_column=
  'catalogue_order', witness_kinds=('catalogue-introduces',))`.
- **`STATUS(break)`** — case logic over witness kinds.
- **`RETROACTIVE_GAP(break)`** — `FIRST_SEEN(b).year - ORIGIN(b).year`.
  Positive values surface as retroactive attributions; the case is
  derived, not flagged at write time.
- **`LINEAGE(object)`** — transitive closure over `inherits` /
  `descended-from` edges; returns the ancestor chain.
- **`INHERITED_BREAKS(object)`** — breaks whose witnesses on
  ancestors of `<object>` propagate via the `inherits` relation.

KQUERY selections (the read layer proper; everything below is sugar
over `KQUERY`):

- **`AXIS_DISTRIBUTION()`** — group-by count of breaks per axis;
  expressible as iterated KQUERY over per-axis predicates.
- **`MIXED(break)`** — true if break commits to ≥ 2 axes.
  Equivalent to `KQUERY(axes_of(break), {single_axis}, emit=10)`
  being non-empty for any single-axis predicate.
- **`CONSISTENCY('q92')`** — Q92 violations.
  Equivalent to `KQUERY(paged_specs, restart_suitable_specs, emit=10)`.
- **`WEDGE(a, b)`** — equivalent to `KQUERY(a, b, emit=10,01)`.
- **`COVERAGE(a, b)`** — equivalent to `KQUERY(a, b, emit=10,01,11)`.
- **`BLIND(a, b, U)`** — equivalent to `KQUERY(a, b, U, emit=00)`.

## The methodology's recurring shape

Across the processor catalogue, a few patterns recur. They're not part
of the ISA per se but constitute the *practice* of using it:

- **Start abstract.** The seed schema has only the most abstract
  structure (`breaks` table with `(number, name)`). Add columns / tables
  only when an object forces it.
- **Witnesses populate breaks; breaks aren't authored top-down.** Each
  break crystallises around a structural distinction that some object
  forces into view. Speculative breaks (added before any witness) tend
  to drift.
- **Time and lineage are breaks-themselves; attribution is derived.**
  Year and lineage are recorded once per object as primary data. Every
  "who originated this?" question is then a tropical MIN-year query
  over origin-class edges; "what does X inherit?" is a transitive
  closure over lineage edges. There's no special-casing for catalogue
  exposition order versus chronology.
- **Schema breaks are additive.** Don't drop columns; add new ones.
  `ALTER TABLE ADD COLUMN` is the typical move; `CREATE TABLE` for
  genuinely new raw structure (S6+ in `symmetries.sql`).
- **Derived properties live in views.** Status, origin, retroactive
  gap, consistency violations — none belong in the raw data.
- **Wedge-product audits keep representations consistent.** When a
  structural artefact has multiple representations (e.g.,
  `symmetries.md` prose ↔ `symmetries.sql` records), periodically
  check that each fact in one is reflected in the other. Drift is
  information.
- **Convergence shows up as "no new breaks in N consecutive
  additions."** When a domain's metamodel is closing, additions
  become refinements rather than new structural primitives. The 68030
  and System/370/XA in the processor catalogue are convergence
  signals.

## How `symmetries.md` and `symmetries.sql` map onto the ISA

Each commit in the processor catalogue corresponds to a sequence of
ISA operations. For example, the 8087 commit (a19b2ae) maps to:

```text
INTRODUCE object 8087 kind=processor year=1980 lineage=[x87, intel]

INTRODUCE break Q88 name="Joint instruction execution" axes=[parallel]
WITNESS   8087 Q88 origin
WITNESS   8087 Q88 catalogue-introduces

REFINE Q85 8087 interaction-model-enum
       "AgentInteractionModel: CONFIG_AND_GO | COPROCESSOR"
WITNESS 8087 Q85 refines

WITNESS 8087 Q87 precedes
        "Agent-level modal behaviour (CW selects rounding × precision);
         precedes spec-level Q87 at 80286"
```

The System/370 commit (ee54473) — note the absence of any `RETRO`
verb. The chronological priority emerges from the year attributes:

```text
INTRODUCE object system_370    kind=processor year=1970 lineage=[mainframe, ibm]
INTRODUCE object system_360_67 kind=processor year=1965 lineage=[mainframe, ibm]

INTRODUCE break Q93 name="Conditional atomicity" axes=[temporal]
WITNESS   system_370 Q93 origin
WITNESS   system_370 Q93 catalogue-introduces

-- Q87 was introduced at the 80286 commit (catalogue-introduces).
-- Now we add an origin edge from system_370. The view's MIN-year
-- naturally picks 1970 over 1982; "retroactive" is a derived label.
WITNESS system_370    Q87 origin

-- Same shape for Q89: 80386 catalogue-introduced; system_360_67 origin.
WITNESS system_360_67 Q89 origin

WITNESS system_370 Q81 first-witness
        "Multi-CPU shared memory with SIGP"
```

The wedge-product audit (the user's correction step) is:

```text
WEDGE symmetries.md symmetries.sql
  → flagged: BF-A..D missing from .sql; LC-α..δ missing;
             Z74-Z78, Z81 missing; Q71-Q73 missing; T1-T5 missing;
             per-break axes missing; agent-vs-spec scope missing
  → response: schema-breaks S6-S10 added; missing breaks added;
              views added
```

This shows that the existing artefacts are already an instance of the
methodology — they just weren't named as such.

## Reference implementation sketch

A minimal Python implementation of the ISA against SQLite (using the
relational shape):

```python
class SymmetryCatalogue:
    def __init__(self, db_path: str):
        self.conn = sqlite3.connect(db_path)
        self._bootstrap()    # mirrors symmetries.sql S0-S10

    def introduce(self, kind: str, id_: str, **attrs):
        if kind == 'break':
            self.conn.execute(
                "INSERT INTO breaks (number, name, short_desc) "
                "VALUES (?, ?, ?)",
                (id_, attrs.get('name'), attrs.get('short_desc'))
            )
        elif kind == 'object':
            self.conn.execute(
                "INSERT INTO specs (id, name, year, ...) "
                "VALUES (?, ?, ?, ...)",
                (id_, attrs['name'], attrs.get('year'), ...)
            )
        # ... other kinds

    def witness(self, subject: str, break_: str, kind: str,
                notes: str = None):
        self.conn.execute(
            "INSERT INTO witnesses (spec_id, break_number, kind, notes) "
            "VALUES (?, ?, ?, ?)",
            (subject, break_, kind, notes)
        )

    def refine(self, break_: str, object_: str, name: str,
               desc: str = None):
        self.conn.execute(
            "INSERT INTO refinements "
            "(break_number, spec_id, name, description) "
            "VALUES (?, ?, ?, ?)",
            (break_, object_, name, desc)
        )

    def origin(self, break_: str) -> dict | None:
        return self.conn.execute(
            "SELECT * FROM break_origin WHERE break_number = ?",
            (break_,)
        ).fetchone()

    def query(self, pattern: str, **bindings) -> list:
        # Pattern compiles to SQL via a small DSL or directly
        ...
```

The actual reference implementation would be a couple hundred lines —
small enough to embed and reason about. The point is that the ISA's
*verbs* are stable; the *substrate* (SQLite / Neo4j / triple store /
JSON files) is interchangeable, mirroring the framework's own
DSL-trees-as-substrate-portability principle (Z22).

## MCP interface — exposing the catalogue to LLM clients

The Model Context Protocol (MCP) is Anthropic's standard for letting
LLM clients call tools, read resources, and invoke prompts against a
server. An MCP server exposing the catalogue makes the methodology
*interactively maintainable* by any MCP-aware client (Claude Desktop,
Claude Code, other agents): new processor analyses become tool calls;
audits become resource fetches; templates for analyzing a new spec
become prompts.

### Tools (the ISA verbs as callable functions)

Each ISA verb maps to one MCP tool. The tool name and parameters
mirror the verb's signature directly.

```text
introduce_break(number, name, axes=[], short_desc=None)
introduce_object(id, kind, name, year=None, lineage=[],
                 catalogue_order=None, notes=None)
introduce_axis(name, description=None)
introduce_tension(id, name, description, breaks_involved=[],
                  status='open')

witness(subject, break_number, kind, notes=None, scope='spec')
refine(break_number, object_id, name, description=None)

defer(break_number, reason=None)
promote(break_number, reason=None)
boundary(break_number, reason)

# Schema-evolution
kind_new(name, attr_schema)
predicate_new(name, signature)
axis_new(name)
```

### Resources (read-only views of the catalogue)

Resources are addressed by URI; clients can fetch them on demand.

```text
catalogue://breaks                  → all breaks (number, name, axes, status)
catalogue://breaks/{number}         → one break with its witnesses + refinements
catalogue://objects                 → all objects (specs / non-spec witnesses)
catalogue://objects/{id}            → one object with its contributions
catalogue://retroactive             → derived: breaks with origin year < first-seen year
catalogue://tensions                → tensions list with status
catalogue://q92_violations          → derived consistency check
catalogue://axes                    → axis list with break counts
catalogue://lineages                → object lineage graph
catalogue://wedge?a=...&b=...       → wedge-product audit between two sources
```

### Prompts (templates for common tasks)

Prompts are slot-filled templates the client invokes; the server
returns a fully-rendered prompt the LLM then acts on.

```text
analyze_new_processor(spec_doc_url) →
  "Examine the spec at <url>. For each section, identify:
   - Existing breaks the processor inherits unchanged
   - Refinements of existing breaks
   - New breaks the processor forces (Q-series)
   For each break, provide a (partition, preservation-theorem) pair.
   Then propose ISA operations to record the analysis."

audit_md_vs_sql(md_path, sql_path) →
  "Run a wedge-product audit between <md_path> and <sql_path>.
   For each item in either, check whether it's represented in the
   other. Output a list of: (item, present_in_md, present_in_sql,
   suggested_action)."

next_processor(domain) →
  "The catalogue's most recent additions are <last_3>. Suggest the
   next processor to analyze, with reasoning: which existing break
   would it confirm cross-vendor? what new break might it force?"

snap_to_grid_check(deliverable_description) →
  "Compare the catalogue's current entailment against
   <deliverable_description>. Report: consistent / generalisation /
   specialisation / drift. If gap, name what's missing."
```

### Server topology

```text
                  ┌────────────────────────────────────┐
  MCP client ◄────┤  catalogue-mcp-server (Python)     │
  (Claude /       │                                    │
   Code / agent)  │  - exposes ISA verbs as tools      │
                  │  - exposes views as resources      │
                  │  - exposes templates as prompts    │
                  │                                    │
                  │  ┌──────────────────────────────┐  │
                  │  │ SymmetryCatalogue (Python)   │  │
                  │  │   ↑                          │  │
                  │  │   substrate-portable ISA     │  │
                  │  └─────────┬────────────────────┘  │
                  └────────────┼───────────────────────┘
                               │
              ┌────────────────┼────────────────┐
              ▼                ▼                ▼
        symmetries.db    triple-store      Neo4j
        (SQLite,         (federated        (graph
        local)           catalogue)        analytics)
```

A single MCP server can expose multiple substrates; clients don't
need to know which is in use.

### Example session

```text
Client → Server: introduce_object(id="z16", kind=processor, year=2022,
                                  lineage=["mainframe", "ibm"])
Server → Client: ok

Client → Server: introduce_break(number="Q94", name="Vector facility",
                                 axes=["parallel"])
Server → Client: ok

Client → Server: witness("z16", "Q94", "first-witness",
                         "Z architecture vector extension")
Server → Client: ok

Client → Server: GET catalogue://breaks/Q94
Server → Client: {
                   "number": "Q94",
                   "name": "Vector facility",
                   "axes": ["parallel"],
                   "status": "active",
                   "originator": {"object": "z16", "year": 2022},
                   "witnesses": [
                     {"object": "z16", "kind": "first-witness", ...}
                   ]
                 }

Client → Server: invoke_prompt("next_processor", domain="mainframe")
Server → Client: "<rendered prompt>"
LLM → Client → Server: <calls introduce_object / witness / refine
                       to record the next processor's analysis>
```

The MCP interface makes the methodology *self-bootstrapping*: an LLM
client maintains the catalogue across sessions without losing
structural state, and any human can review the changes via the
catalogue's queryable substrate.

## Why this matters

The processor catalogue grew to ~6800 lines of prose plus 1400 lines of
SQL across many sessions. The structural content survived because it
was externalised as breaks, witnesses, refinements — concrete artefacts
that can be queried, audited, and extended.

Generalising the methodology means: *any domain with accumulating
structural distinctions can use the same scaffolding*. The cost is one
schema-bootstrap and a handful of verbs; the payoff is a queryable
catalogue that:

- Doesn't lose structure across context boundaries
- Makes drift explicit (wedge-product audits)
- Keeps derived properties consistent with raw facts (views)
- Treats time and lineage as breaks-themselves, so attribution
  emerges from queries rather than from a special verb
- Converges visibly when the metamodel closes

The processor catalogue is one demonstration. The ISA + NOSQL schema is
the methodology factored to the level where any structural-knowledge
domain can adopt it.

## Philosophical lineage — Derridean traces and Yoneda relationality

The methodology's structural commitments — *no break, origin, or
schema element is foundational; identity is constituted only through
witnessed traces; global structure is always derived* — align with
two well-developed positions in continental philosophy and category
theory.

### Derridean critique of presence

Derrida's reading of structuralism observes that no element of a
sign-system is *self-present*: the meaning of any term is constituted
through its differences from and deferrals to other terms (the
*différance* move). There's no foundational "ground" that grants
meaning unilaterally; meaning is the trace of relationships.

The methodology refuses presence at every level:

- **No foundational break.** Z18 (microcode-as-data) isn't a privileged
  origin from which other breaks are derived. It's named only because
  the 6502 work surfaced it; it remains revisable as future objects
  contribute traces that re-position it.
- **No foundational origin.** The originator of Q89 isn't a fact
  stamped into the schema; it's a *derivation* (tropical MIN-year
  over origin-class witness edges). Adding the System/360/67 trace
  to a previously-80386-credited Q89 doesn't *correct* the catalogue —
  it *re-derives* the originator. The earlier reading wasn't wrong;
  it was what the trace-set licensed at the time.
- **No foundational schema.** Schema breaks S0-S11 emerged additively;
  none was specified in advance. The schema is itself a sediment of
  traces — each break records that a particular structural concern
  forced the data shape to admit a new column or table.
- **No foundational object.** Specs and breaks are constituted by their
  participation in the witness graph. The "68030" isn't an essence
  outside the catalogue; it's the trace-set its witnesses, refinements,
  and lineage edges accumulate to.

The "retroactive attribution" pattern is the most acute Derridean
moment: when System/360/67 (1965) becomes the origin of Q89 in 1985's
catalogue analysis, the prior reading wasn't false — it was what the
trace-set then licensed. The catalogue doesn't *correct* itself
backwards; it *thickens* itself forward, and the derived originator
is whatever the current trace-set licenses. There is no privileged
moment of "the right answer"; there are only progressively richer
trace-sets and the queries they license.

### Yoneda-style relational stance

The Yoneda lemma in category theory states that an object is fully
characterised by the morphisms into and out of it (its hom-functor).
You cannot know the object except through its relationships; there
is no "essence" of an object beyond what its participation in a
category determines.

The methodology adopts this stance:

- **An object is its witnesses.** A spec's identity in the catalogue
  is exactly the (kind, break, refinements, scope) edges it
  participates in. Nothing about a spec is recorded outside its
  relations — even attributes like year and lineage are themselves
  witness-edges to the time-and-lineage breaks.
- **A break is its witnesses.** A break's identity is exactly the
  edges from objects to it. There's no break "in itself" outside
  the witness graph.
- **Substrate is irrelevant; only relations matter.** Whether the
  catalogue lives in SQL, a triple store, a graph DB, or JSON files
  is invisible from the relational stance — the same hom-set is
  presented in each substrate. (This is why methodology.md treats
  the four shapes as equivalent.)

Yoneda lets us state the methodology's substrate-portability claim
formally: any two substrates that present the same hom-set are
equivalent for the methodology's purposes. The ISA is *the* hom-set
preserving translation between them.

### Their combination

Derrida + Yoneda yields the methodology's working stance:

1. **Identity is relational** (Yoneda): objects are constituted by
   their participation in the relevant category.
2. **Relations are traces** (Derrida): each relationship is a
   deferral that points to others; no relationship is the privileged
   ground.
3. **Global structure is derived, never imposed**: views, queries,
   and the metamodel itself are functions over the trace graph,
   re-derivable as the trace-set thickens.

The processor catalogue is the working demonstration. A new
processor doesn't update a privileged Spec record; it adds witnesses,
refinements, and lineage edges that re-derive every dependent view.
The wedge-product audit doesn't compare the catalogue to a master
copy; it cross-checks two representations to surface drift, treating
both as equally provisional.

This isn't decorative philosophy. It's the structural reason the
methodology survives context loss: *because no element is
self-present, every element is queryable from its traces, and any
substrate that preserves the hom-set preserves the methodology*.

## Open questions

- **Schema interoperability across instances.** If two domains both use
  this methodology (processors, languages), can they share schema breaks?
  E.g., does Q89 (paging) in processors map to a similar break in
  language runtimes (managed-heap layout)? The wedge-product audit
  generalises to cross-domain comparison.
- **Federation.** Multiple catalogues maintained independently might
  share a common substrate. The triple-store representation is most
  natural for federation.
- **Versioning.** The methodology is *additive* — but what about
  corrections (e.g., Z80's reassignment from time-axis to EqualityMode)?
  A `CONTRADICT` verb is a candidate but not yet adopted.
- **Reasoning over the catalogue.** Once enough breaks accumulate, can
  derivation rules infer new facts? E.g., "if X originates Q89 and Y
  inherits from X, then Y inherits Q89." Datalog-style inference is a
  natural fit.

These are real but downstream of the basic ISA. The current scope is:
*formalise what we've been doing*, then build out from there.

---

This document and the artefacts it describes (`symmetries.md`,
`symmetries.sql`) are themselves witnesses of the methodology. Each is
a substrate (prose / relational SQL) for the same underlying graph.
Other substrates (document, graph, triple store) would carry the same
content. The methodology is the equivalence-class; the substrates are
representatives.
