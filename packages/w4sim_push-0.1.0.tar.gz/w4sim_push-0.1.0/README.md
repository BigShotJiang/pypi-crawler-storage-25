# w4sim_push

A command-line tool that allows users to push their current project directory to a GitHub repository with minimal input.

## Installation

```bash
pip install w4sim-push
```

## Usage

Navigate to your project directory and run:

```bash
w4sim_push
```

You can also pass the repository URL directly:

```bash
w4sim_push https://github.com/yourusername/yourrepo.git
```

## Features
- Automatically initializes git if it's not initialized
- Adds all files to the staging area
- Commits changes (skips if nothing to commit)
- Detects the current branch dynamically, or creates 'main' if no branch exists
- Adds or updates the remote origin
- Pushes directly to GitHub
- Colorful, user-friendly terminal output

