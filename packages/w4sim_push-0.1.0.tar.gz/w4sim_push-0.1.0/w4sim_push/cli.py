import argparse
import subprocess
import sys
import os
from typing import Optional, Tuple
from rich.console import Console
from rich.prompt import Prompt

console = Console()

def run_git_command(args: list[str], cwd: str = ".", check: bool = True) -> Tuple[int, str, str]:
    """Runs a git command and returns the exit code, stdout, and stderr."""
    try:
        # Use shell=False for security and proper cross-platform handling,
        # but Windows sometimes needs it if git is not an explicit exe or inside shell.
        # However, subprocess.run(["git", ...]) works well cross-platform if git is in PATH.
        result = subprocess.run(
            ["git"] + args,
            cwd=cwd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            check=False
        )
        if check and result.returncode != 0:
            console.print(f"[bold red]Error running git command:[/bold red] git {' '.join(args)}")
            console.print(f"[red]{result.stderr.strip()}[/red]")
            sys.exit(1)
        return result.returncode, result.stdout.strip(), result.stderr.strip()
    except FileNotFoundError:
        console.print("[bold red]Git is not installed or not found in system PATH.[/bold red]")
        sys.exit(1)

def is_git_repo() -> bool:
    """Check if the current directory is a git repository."""
    code, _, _ = run_git_command(["rev-parse", "--is-inside-work-tree"], check=False)
    return code == 0

def get_current_branch() -> Optional[str]:
    """Get the current checked-out branch, if any."""
    code, out, _ = run_git_command(["branch", "--show-current"], check=False)
    if code == 0 and out:
        return out
    
    # Fallback to status parsing if required
    code, out, _ = run_git_command(["status", "-s", "-b"], check=False)
    if code == 0 and out.startswith("## ") or out.startswith("## No commits yet on "):
        # '## No commits yet on main' or '## main...origin/main'
        if "No commits yet on " in out.splitlines()[0]:
            return out.splitlines()[0].split("No commits yet on ")[-1].strip()
        elif "..." in out.splitlines()[0]:
            return out.splitlines()[0].split("...")[0].replace("## ", "").strip()
        else:
            return out.splitlines()[0].replace("## ", "").strip()
    
    return None

def has_remote(remote_name="origin") -> bool:
    """Check if a specific remote exists."""
    code, out, _ = run_git_command(["remote"], check=False)
    return remote_name in out.splitlines()

def push_to_github():
    parser = argparse.ArgumentParser(description="Quickly push your project to GitHub.")
    parser.add_argument("repo_url", nargs="?", help="GitHub repository URL")
    
    args = parser.parse_args()
    
    repo_url = args.repo_url
    if not repo_url:
        repo_url = Prompt.ask("[bold cyan]Enter the GitHub repository URL[/bold cyan]")
        
    if not repo_url.startswith("http") and not repo_url.startswith("git@"):
        console.print("[red]Invalid repository URL. Please provide a valid HTTP/HTTPS or SSH URL.[/red]")
        sys.exit(1)

    console.print(f"🚀 [bold green]Starting deployment to {repo_url}[/bold green]...")

    # Initialize Git if not present
    if not is_git_repo():
        with console.status("[bold yellow]Initializing git repository...[/bold yellow]"):
            run_git_command(["init"])
        console.print("✅ [green]Initialized empty Git repository.[/green]")
    else:
        console.print("✅ [green]Git repository already initialized.[/green]")

    # Add all files
    with console.status("[bold yellow]Adding files...[/bold yellow]"):
        run_git_command(["add", "."])
    console.print("✅ [green]Files added to staging area.[/green]")

    # Commit changes
    with console.status("[bold yellow]Committing changes...[/bold yellow]"):
        code, out, err = run_git_command(["commit", "-m", "Auto-commit from w4sim_push"], check=False)
        if code == 0:
            console.print("✅ [green]Changes committed.[/green]")
        elif "nothing to commit" in out or "nothing to commit" in err:
            console.print("ℹ️  [yellow]No new changes to commit. Proceeding...[/yellow]")
        else:
            console.print("[bold red]Error during commit:[/bold red]")
            console.print(f"[red]{out or err}[/red]")
            sys.exit(1)

    # Detect/Set Branch
    current_branch = get_current_branch()
    if not current_branch:
        # Before the first commit `branch --show-current` might return nothing on older/certain setups.
        # Ensure we have a branch name.
        with console.status("[bold yellow]Setting default branch to 'main'...[/bold yellow]"):
            run_git_command(["branch", "-M", "main"])
            current_branch = "main"
        console.print("✅ [green]Branch set to 'main'.[/green]")
    else:
        # Force set branch using -M to ensure we're good
        run_git_command(["branch", "-M", current_branch])
        console.print(f"✅ [green]Using branch '{current_branch}'.[/green]")

    # Add Remote
    if not has_remote():
        with console.status("[bold yellow]Adding remote origin...[/bold yellow]"):
            run_git_command(["remote", "add", "origin", repo_url])
        console.print(f"✅ [green]Added remote 'origin' -> {repo_url}.[/green]")
    else:
        with console.status("[bold yellow]Updating remote origin...[/bold yellow]"):
            run_git_command(["remote", "set-url", "origin", repo_url])
        console.print(f"✅ [green]Remote 'origin' is set to {repo_url}.[/green]")

    # Push
    with console.status("[bold yellow]Pushing to GitHub...[/bold yellow]"):
        code, out, err = run_git_command(["push", "-u", "origin", current_branch], check=False)
        if code == 0:
            console.print(f"🎉 [bold green]Successfully pushed to {current_branch} at {repo_url}![/bold green]")
        else:
            if "fetch first" in err.lower() or "non-fast-forward" in err.lower():
                console.print("[bold red]Push failed: Remote contains work that you do not have locally.[/bold red]")
                console.print("[yellow]Hint: Try pulling the changes first or resolve conflicts manually.[/yellow]")
            else:
                console.print(f"[bold red]Error pushing to remote:[/bold red]")
                console.print(f"[red]{err or out}[/red]")

if __name__ == "__main__":
    push_to_github()
