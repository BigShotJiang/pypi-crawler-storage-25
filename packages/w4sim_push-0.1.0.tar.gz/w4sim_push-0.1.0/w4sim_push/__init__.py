"""
w4sim_push - A tool to quickly push your project to GitHub.
"""

__version__ = "0.1.0"
