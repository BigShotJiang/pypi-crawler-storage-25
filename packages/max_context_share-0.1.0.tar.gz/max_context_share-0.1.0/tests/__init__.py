r"""Tests package initializer."""
