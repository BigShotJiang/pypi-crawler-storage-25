# -*- coding: utf-8 -*-
"""
APIClient 测试模块

相关内容含AI生成
相关第三方库系XZ团队内部开发，不建议外部人员使用
"""

import pytest
from unittest.mock import patch, Mock
from xzstudio import APIClient, Config
from xzstudio.exceptions import (
    AuthenticationError,
    ValidationError,
    NetworkError,
    APIError
)


class TestAPIClient:
    """APIClient测试类"""
    
    def test_init_with_token(self):
        """测试使用Token初始化"""
        client = APIClient(api_token="test_token")
        assert client.api_token == "test_token"
    
    def test_init_with_config(self):
        """测试使用Config初始化"""
        config = Config()
        client = APIClient(config=config)
        assert client.config is config
    
    def test_validate_email_valid(self):
        """测试有效邮箱验证"""
        client = APIClient(api_token="test_token")
        assert client._validate_email("test@example.com") == True
        assert client._validate_email("user.name@domain.org") == True
    
    def test_validate_email_invalid(self):
        """测试无效邮箱验证"""
        client = APIClient(api_token="test_token")
        assert client._validate_email("") == False
        assert client._validate_email("invalid") == False
        assert client._validate_email("@example.com") == False
        assert client._validate_email("test@") == False
    
    def test_validate_date_valid(self):
        """测试有效日期验证"""
        client = APIClient(api_token="test_token")
        assert client._validate_date("2026-12-31") == True
        assert client._validate_date("2026-01-01") == True
    
    def test_validate_date_invalid(self):
        """测试无效日期验证"""
        client = APIClient(api_token="test_token")
        assert client._validate_date("") == False
        assert client._validate_date("2026/12/31") == False
        assert client._validate_date("31-12-2026") == False
    
    def test_send_without_token(self):
        """测试无Token时发送"""
        client = APIClient()
        with pytest.raises(AuthenticationError):
            client.send_verification_code(
                username="test",
                code_type="temp",
                email="test@example.com",
                date="2026-12-31"
            )
    
    def test_send_invalid_code_type(self):
        """测试无效校验码类型"""
        client = APIClient(api_token="test_token")
        with pytest.raises(ValidationError):
            client.send_verification_code(
                username="test",
                code_type="invalid",
                email="test@example.com"
            )
    
    def test_send_invalid_email(self):
        """测试无效邮箱"""
        client = APIClient(api_token="test_token")
        with pytest.raises(ValidationError):
            client.send_verification_code(
                username="test",
                code_type="temp",
                email="invalid",
                date="2026-12-31"
            )
    
    def test_send_temp_without_date(self):
        """测试临时校验码缺少日期"""
        client = APIClient(api_token="test_token")
        with pytest.raises(ValidationError):
            client.send_verification_code(
                username="test",
                code_type="temp",
                email="test@example.com"
            )
    
    @patch('xzstudio.api_client.requests.post')
    def test_send_success(self, mock_post):
        """测试成功发送"""
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"code": "ABC123"}
        mock_post.return_value = mock_response
        
        client = APIClient(api_token="test_token")
        result = client.send_verification_code(
            username="test",
            code_type="permanent",
            email="test@example.com"
        )
        
        assert result['success'] == True
        assert result['status_code'] == 200
    
    @patch('xzstudio.api_client.requests.post')
    def test_send_auth_error(self, mock_post):
        """测试认证错误"""
        mock_response = Mock()
        mock_response.status_code = 401
        mock_post.return_value = mock_response
        
        client = APIClient(api_token="test_token")
        with pytest.raises(AuthenticationError):
            client.send_verification_code(
                username="test",
                code_type="permanent",
                email="test@example.com"
            )
    
    @patch('xzstudio.api_client.requests.post')
    def test_send_timeout(self, mock_post):
        """测试超时"""
        import requests
        mock_post.side_effect = requests.exceptions.Timeout()
        
        client = APIClient(api_token="test_token")
        with pytest.raises(NetworkError):
            client.send_verification_code(
                username="test",
                code_type="permanent",
                email="test@example.com"
            )


if __name__ == '__main__':
    pytest.main([__file__, '-v'])