# -*- coding: utf-8 -*-
"""
ExcelHandler 测试模块

相关内容含AI生成
相关第三方库系XZ团队内部开发，不建议外部人员使用
"""

import pytest
import os
import tempfile
from xzstudio import ExcelHandler
from xzstudio.exceptions import ExcelProcessingError, ValidationError


class TestExcelHandler:
    """ExcelHandler测试类"""
    
    def setup_method(self):
        """每个测试方法前执行"""
        self.handler = ExcelHandler()
        self.temp_dir = tempfile.mkdtemp()
    
    def teardown_method(self):
        """每个测试方法后执行"""
        import shutil
        if os.path.exists(self.temp_dir):
            shutil.rmtree(self.temp_dir)
    
    def test_create_template(self):
        """测试创建模板"""
        template_path = os.path.join(self.temp_dir, "template.xlsx")
        result = self.handler.create_template(template_path)
        
        assert result == template_path
        assert os.path.exists(template_path)
    
    def test_read_nonexistent_file(self):
        """测试读取不存在的文件"""
        with pytest.raises(ExcelProcessingError):
            self.handler.read_excel("/nonexistent/file.xlsx")
    
    def test_write_and_read(self):
        """测试写入和读取"""
        # 先创建模板
        template_path = os.path.join(self.temp_dir, "template.xlsx")
        self.handler.create_template(template_path)
        
        # 读取模板
        users = self.handler.read_excel(template_path)
        
        assert isinstance(users, list)
        assert len(users) >= 0
    
    def test_write_excel(self):
        """测试写入Excel"""
        output_path = os.path.join(self.temp_dir, "output.xlsx")
        
        data = [
            {
                'username': '张三',
                'code_type': 'temp',
                'email': 'zhangsan@example.com',
                'date': '2026-12-31',
                'verification_code': 'ABC123',
                'status': '成功',
                'message': ''
            },
            {
                'username': '李四',
                'code_type': 'permanent',
                'email': 'lisi@example.com',
                'date': '',
                'verification_code': 'XYZ789',
                'status': '成功',
                'message': ''
            }
        ]
        
        result = self.handler.write_excel(output_path, data)
        
        assert result == output_path
        assert os.path.exists(output_path)


if __name__ == '__main__':
    pytest.main([__file__, '-v'])