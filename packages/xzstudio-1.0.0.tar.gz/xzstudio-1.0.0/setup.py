# -*- coding: utf-8 -*-
"""
XZStudio 安装脚本

相关内容含AI生成
相关第三方库系XZ团队内部开发，不建议外部人员使用
"""

from setuptools import setup, find_packages

setup(
    name='xzstudio',
    version='1.0.0',
    packages=find_packages(),
    install_requires=[
        'requests>=2.25.0',
        'openpyxl>=3.0.0',
    ],
    extras_require={
        'dev': [
            'pytest>=6.0.0',
            'pytest-cov>=2.0.0',
            'flake8>=3.9.0',
        ],
    },
    entry_points={
        'console_scripts': [
            'xzstudio=xzstudio.gui:launch_gui',
        ],
    },
    python_requires='>=3.7',
)