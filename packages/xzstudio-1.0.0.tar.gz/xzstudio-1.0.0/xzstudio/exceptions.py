# -*- coding: utf-8 -*-
"""
XZStudio 异常处理模块

相关内容含AI生成
相关第三方库系XZ团队内部开发，不建议外部人员使用

Author: XZ Team
"""


class XZStudioError(Exception):
    """XZStudio 基础异常类"""
    pass


class NetworkError(XZStudioError):
    """网络连接错误"""
    def __init__(self, message="网络连接失败，请检查网络设置"):
        self.message = message
        super().__init__(self.message)


class APIError(XZStudioError):
    """API调用错误"""
    def __init__(self, status_code=None, message="API调用失败"):
        self.status_code = status_code
        self.message = f"API错误 [{status_code}]: {message}" if status_code else message
        super().__init__(self.message)


class AuthenticationError(XZStudioError):
    """认证错误"""
    def __init__(self, message="API Token无效或已过期"):
        self.message = message
        super().__init__(self.message)


class ValidationError(XZStudioError):
    """数据验证错误"""
    def __init__(self, message="数据验证失败"):
        self.message = message
        super().__init__(self.message)


class ExcelProcessingError(XZStudioError):
    """Excel处理错误"""
    def __init__(self, message="Excel文件处理失败"):
        self.message = message
        super().__init__(self.message)


class ConfigurationError(XZStudioError):
    """配置错误"""
    def __init__(self, message="配置错误"):
        self.message = message
        super().__init__(self.message)