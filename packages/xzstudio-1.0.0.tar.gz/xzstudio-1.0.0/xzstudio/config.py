# -*- coding: utf-8 -*-
"""
XZStudio 配置管理模块

相关内容含AI生成
相关第三方库系XZ团队内部开发，不建议外部人员使用

Author: XZ Team
"""

import os
import json
from typing import Optional


class Config:
    """
    配置管理类
    
    用于管理API Token等配置信息，支持持久化存储
    """
    
    DEFAULT_CONFIG_DIR = os.path.expanduser("~/.xzstudio")
    DEFAULT_CONFIG_FILE = os.path.join(DEFAULT_CONFIG_DIR, "config.json")
    
    def __init__(self, config_file: Optional[str] = None):
        """
        初始化配置管理器
        
        Args:
            config_file: 配置文件路径，默认为 ~/.xzstudio/config.json
        """
        self.config_file = config_file or self.DEFAULT_CONFIG_FILE
        self._config = self._load_config()
    
    def _load_config(self) -> dict:
        """加载配置文件"""
        if os.path.exists(self.config_file):
            try:
                with open(self.config_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except (json.JSONDecodeError, IOError):
                return {}
        return {}
    
    def _save_config(self) -> bool:
        """保存配置到文件"""
        try:
            os.makedirs(os.path.dirname(self.config_file), exist_ok=True)
            with open(self.config_file, 'w', encoding='utf-8') as f:
                json.dump(self._config, f, ensure_ascii=False, indent=2)
            return True
        except IOError:
            return False
    
    @property
    def api_token(self) -> Optional[str]:
        """获取API Token"""
        return self._config.get('api_token')
    
    @api_token.setter
    def api_token(self, token: str):
        """设置API Token"""
        self._config['api_token'] = token
        self._save_config()
    
    @property
    def api_url(self) -> str:
        """获取API URL"""
        return self._config.get('api_url', 'https://htt649963q.coze.site/run')
    
    @api_url.setter
    def api_url(self, url: str):
        """设置API URL"""
        self._config['api_url'] = url
        self._save_config()
    
    @property
    def timeout(self) -> int:
        """获取请求超时时间"""
        return self._config.get('timeout', 30)
    
    @timeout.setter
    def timeout(self, seconds: int):
        """设置请求超时时间"""
        self._config['timeout'] = seconds
        self._save_config()
    
    def clear(self):
        """清除所有配置"""
        self._config = {}
        self._save_config()
    
    def to_dict(self) -> dict:
        """返回配置字典"""
        return self._config.copy()