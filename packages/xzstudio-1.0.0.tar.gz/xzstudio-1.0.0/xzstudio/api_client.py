# -*- coding: utf-8 -*-
"""
XZStudio API客户端模块

相关内容含AI生成
相关第三方库系XZ团队内部开发，不建议外部人员使用

Author: XZ Team
"""

import requests
from typing import Optional, Dict, Any
from datetime import datetime

from .exceptions import (
    NetworkError, 
    APIError, 
    AuthenticationError, 
    ValidationError
)
from .config import Config


class APIClient:
    """
    校验码API客户端
    
    用于向用户发送校验码的核心功能实现
    """
    
    def __init__(self, api_token: Optional[str] = None, config: Optional[Config] = None):
        """
        初始化API客户端
        
        Args:
            api_token: API认证Token，如未提供则从配置中读取
            config: 配置对象，如未提供则创建默认配置
        """
        self.config = config or Config()
        self._api_token = api_token or self.config.api_token
        self._api_url = self.config.api_url
        self._timeout = self.config.timeout
    
    @property
    def api_token(self) -> Optional[str]:
        """获取当前API Token"""
        return self._api_token
    
    @api_token.setter
    def api_token(self, token: str):
        """设置API Token"""
        self._api_token = token
        self.config.api_token = token
    
    @property
    def api_url(self) -> str:
        """获取API URL"""
        return self._api_url
    
    @api_url.setter
    def api_url(self, url: str):
        """设置API URL"""
        self._api_url = url
        self.config.api_url = url
    
    def _validate_email(self, email: str) -> bool:
        """
        简单验证邮箱格式
        
        Args:
            email: 邮箱地址
        
        Returns:
            bool: 是否有效
        """
        if not email or '@' not in email:
            return False
        parts = email.split('@')
        if len(parts) != 2:
            return False
        return len(parts[0]) > 0 and len(parts[1]) > 0
    
    def _validate_date(self, date_str: str) -> bool:
        """
        验证日期格式
        
        Args:
            date_str: 日期字符串，格式为YYYY-MM-DD
        
        Returns:
            bool: 是否有效
        """
        try:
            datetime.strptime(date_str, '%Y-%m-%d')
            return True
        except ValueError:
            return False
    
    def send_verification_code(
        self, 
        username: str, 
        code_type: str, 
        email: str, 
        date: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        发送校验码
        
        Args:
            username: 用户名
            code_type: 校验码类型，'temp'为临时校验码，'permanent'为永久校验码
            email: 用户邮箱
            date: 有效期截止日期（仅临时校验码需要），格式为YYYY-MM-DD
        
        Returns:
            dict: API响应结果
        
        Raises:
            ValidationError: 参数验证失败
            AuthenticationError: API Token无效
            NetworkError: 网络连接失败
            APIError: API调用失败
        """
        # 参数验证
        if not self._api_token:
            raise AuthenticationError("API Token未设置，请先配置API Token")
        
        if not username or not username.strip():
            raise ValidationError("用户名不能为空")
        
        if code_type not in ('temp', 'permanent'):
            raise ValidationError("校验码类型必须为 'temp' 或 'permanent'")
        
        if not self._validate_email(email):
            raise ValidationError(f"邮箱格式无效: {email}")
        
        if code_type == 'temp':
            if not date:
                raise ValidationError("临时校验码必须指定有效期截止日期")
            if not self._validate_date(date):
                raise ValidationError(f"日期格式无效: {date}，应为YYYY-MM-DD格式")
        
        # 构建请求
        headers = {
            "Authorization": f"Bearer {self._api_token}",
            "Content-Type": "application/json",
        }
        
        payload = {
            "username": username.strip(),
            "code_type": code_type,
            "email": email.strip()
        }
        
        if code_type == 'temp' and date:
            payload["date"] = date
        
        # 发送请求
        try:
            response = requests.post(
                self._api_url, 
                headers=headers, 
                json=payload, 
                timeout=self._timeout
            )
            
            # 处理响应
            if response.status_code == 200:
                return {
                    "success": True,
                    "status_code": response.status_code,
                    "data": response.json() if response.text else {},
                    "message": "校验码发送成功"
                }
            elif response.status_code == 401:
                raise AuthenticationError("API Token无效或已过期")
            elif response.status_code == 400:
                error_msg = ""
                try:
                    error_data = response.json()
                    error_msg = error_data.get('message', error_data.get('error', '请求参数错误'))
                except:
                    error_msg = response.text or "请求参数错误"
                raise APIError(response.status_code, error_msg)
            else:
                raise APIError(response.status_code, response.text or "未知错误")
                
        except requests.exceptions.Timeout:
            raise NetworkError(f"请求超时（{self._timeout}秒），请检查网络连接")
        except requests.exceptions.ConnectionError:
            raise NetworkError("无法连接到服务器，请检查网络设置")
        except requests.exceptions.RequestException as e:
            raise NetworkError(f"网络请求失败: {str(e)}")
    
    def test_connection(self) -> Dict[str, Any]:
        """
        测试API连接
        
        Returns:
            dict: 测试结果
        """
        if not self._api_token:
            return {
                "success": False,
                "message": "API Token未设置"
            }
        
        try:
            # 使用一个测试请求来验证连接
            headers = {
                "Authorization": f"Bearer {self._api_token}",
                "Content-Type": "application/json",
            }
            response = requests.get(
                self._api_url.rsplit('/', 1)[0], 
                headers=headers, 
                timeout=self._timeout
            )
            return {
                "success": True,
                "message": "API连接正常",
                "status_code": response.status_code
            }
        except Exception as e:
            return {
                "success": False,
                "message": f"连接失败: {str(e)}"
            }
