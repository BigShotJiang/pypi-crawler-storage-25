# -*- coding: utf-8 -*-
"""
XZStudio Excel处理模块

相关内容含AI生成
相关第三方库系XZ团队内部开发，不建议外部人员使用

Author: XZ Team
"""

import os
from typing import List, Dict, Optional, Any
from datetime import datetime

try:
    import openpyxl
    from openpyxl import Workbook, load_workbook
    from openpyxl.styles import Font, Alignment, PatternFill, Border, Side
    HAS_OPENPYXL = True
except ImportError:
    HAS_OPENPYXL = False

from .exceptions import ExcelProcessingError, ValidationError


class ExcelHandler:
    """
    Excel文件处理类
    
    支持读取和写入包含用户信息的Excel文件
    """
    
    # 必需的列名
    REQUIRED_COLUMNS = ['用户名', '类型', '邮箱']
    # 可选的列名
    OPTIONAL_COLUMNS = ['日期', '校验码', '发送状态', '备注']
    
    def __init__(self):
        """初始化Excel处理器"""
        if not HAS_OPENPYXL:
            raise ExcelProcessingError(
                "缺少openpyxl库，请运行: pip install openpyxl"
            )
    
    def read_excel(self, file_path: str) -> List[Dict[str, Any]]:
        """
        读取Excel文件
        
        Args:
            file_path: Excel文件路径
        
        Returns:
            list: 用户信息列表，每个元素为字典
        
        Raises:
            ExcelProcessingError: 文件读取失败
            ValidationError: 数据格式错误
        """
        if not os.path.exists(file_path):
            raise ExcelProcessingError(f"文件不存在: {file_path}")
        
        try:
            wb = load_workbook(file_path, read_only=True)
            ws = wb.active
            
            # 读取表头
            headers = []
            for cell in ws[1]:
                if cell.value:
                    headers.append(str(cell.value).strip())
                else:
                    headers.append('')
            
            # 验证必需列
            missing_columns = []
            header_lower = [h.lower() for h in headers]
            required_lower = [c.lower() for c in self.REQUIRED_COLUMNS]
            
            for req_col in required_lower:
                if req_col not in header_lower:
                    missing_columns.append(req_col)
            
            if missing_columns:
                raise ValidationError(
                    f"Excel文件缺少必需列: {', '.join(missing_columns)}\n"
                    f"必需列: {', '.join(self.REQUIRED_COLUMNS)}"
                )
            
            # 获取列索引
            col_indices = {}
            for i, h in enumerate(headers):
                h_lower = h.lower()
                if h_lower == '用户名' or h_lower == 'username':
                    col_indices['username'] = i
                elif h_lower == '类型' or h_lower == 'type' or h_lower == 'code_type':
                    col_indices['code_type'] = i
                elif h_lower == '邮箱' or h_lower == 'email':
                    col_indices['email'] = i
                elif h_lower == '日期' or h_lower == 'date':
                    col_indices['date'] = i
            
            # 读取数据行
            users = []
            for row_num, row in enumerate(ws.iter_rows(min_row=2), start=2):
                if not any(cell.value for cell in row):
                    continue  # 跳过空行
                
                user = {
                    'row_number': row_num,
                    'username': self._get_cell_value(row, col_indices.get('username')),
                    'code_type': self._get_cell_value(row, col_indices.get('code_type')),
                    'email': self._get_cell_value(row, col_indices.get('email')),
                    'date': self._get_cell_value(row, col_indices.get('date')),
                }
                
                # 验证数据
                if user['username'] and user['email']:
                    # 标准化code_type
                    if user['code_type']:
                        ct = str(user['code_type']).lower().strip()
                        if ct in ('临时', 'temp', 't'):
                            user['code_type'] = 'temp'
                        elif ct in ('永久', 'permanent', 'p'):
                            user['code_type'] = 'permanent'
                    
                    users.append(user)
            
            wb.close()
            return users
            
        except Exception as e:
            if isinstance(e, (ExcelProcessingError, ValidationError)):
                raise
            raise ExcelProcessingError(f"读取Excel文件失败: {str(e)}")
    
    def _get_cell_value(self, row, col_index):
        """安全获取单元格值"""
        if col_index is None:
            return None
        try:
            value = row[col_index].value
            if isinstance(value, datetime):
                return value.strftime('%Y-%m-%d')
            return str(value).strip() if value else None
        except:
            return None
    
    def write_excel(
        self, 
        file_path: str, 
        data: List[Dict[str, Any]], 
        original_file: Optional[str] = None
    ) -> str:
        """
        写入Excel文件
        
        Args:
            file_path: 输出文件路径
            data: 用户数据列表，包含校验码和发送状态
            original_file: 原始文件路径（可选，用于保留原文件格式）
        
        Returns:
            str: 输出文件路径
        
        Raises:
            ExcelProcessingError: 文件写入失败
        """
        try:
            wb = Workbook()
            ws = wb.active
            ws.title = "校验码结果"
            
            # 设置表头
            headers = ['序号', '用户名', '类型', '邮箱', '日期', '校验码', '发送状态', '备注']
            
            # 样式设置
            header_font = Font(bold=True, color='FFFFFF')
            header_fill = PatternFill(start_color='4472C4', end_color='4472C4', fill_type='solid')
            header_alignment = Alignment(horizontal='center', vertical='center')
            thin_border = Border(
                left=Side(style='thin'),
                right=Side(style='thin'),
                top=Side(style='thin'),
                bottom=Side(style='thin')
            )
            
            # 写入表头
            for col, header in enumerate(headers, 1):
                cell = ws.cell(row=1, column=col, value=header)
                cell.font = header_font
                cell.fill = header_fill
                cell.alignment = header_alignment
                cell.border = thin_border
            
            # 写入数据
            success_fill = PatternFill(start_color='C6EFCE', end_color='C6EFCE', fill_type='solid')
            fail_fill = PatternFill(start_color='FFC7CE', end_color='FFC7CE', fill_type='solid')
            
            for idx, user in enumerate(data, 1):
                row = idx + 1
                
                # 根据发送状态设置行颜色
                status = user.get('status', '')
                row_fill = None
                if '成功' in str(status):
                    row_fill = success_fill
                elif '失败' in str(status):
                    row_fill = fail_fill
                
                # 写入各列数据
                values = [
                    idx,
                    user.get('username', ''),
                    user.get('code_type', ''),
                    user.get('email', ''),
                    user.get('date', ''),
                    user.get('verification_code', ''),
                    user.get('status', ''),
                    user.get('message', '')
                ]
                
                for col, value in enumerate(values, 1):
                    cell = ws.cell(row=row, column=col, value=value)
                    cell.border = thin_border
                    cell.alignment = Alignment(horizontal='center', vertical='center')
                    if row_fill:
                        cell.fill = row_fill
            
            # 调整列宽
            column_widths = [8, 15, 10, 25, 12, 20, 12, 30]
            for i, width in enumerate(column_widths, 1):
                ws.column_dimensions[chr(64 + i)].width = width
            
            # 保存文件
            wb.save(file_path)
            return file_path
            
        except Exception as e:
            raise ExcelProcessingError(f"写入Excel文件失败: {str(e)}")
    
    def create_template(self, file_path: str) -> str:
        """
        创建Excel模板文件
        
        Args:
            file_path: 模板文件保存路径
        
        Returns:
            str: 模板文件路径
        """
        try:
            wb = Workbook()
            ws = wb.active
            ws.title = "用户信息"
            
            # 表头
            headers = ['用户名', '类型', '邮箱', '日期']
            
            # 样式
            header_font = Font(bold=True, color='FFFFFF')
            header_fill = PatternFill(start_color='4472C4', end_color='4472C4', fill_type='solid')
            header_alignment = Alignment(horizontal='center', vertical='center')
            thin_border = Border(
                left=Side(style='thin'),
                right=Side(style='thin'),
                top=Side(style='thin'),
                bottom=Side(style='thin')
            )
            
            for col, header in enumerate(headers, 1):
                cell = ws.cell(row=1, column=col, value=header)
                cell.font = header_font
                cell.fill = header_fill
                cell.alignment = header_alignment
                cell.border = thin_border
            
            # 示例数据
            sample_data = [
                ['张三', 'temp', 'zhangsan@example.com', '2026-12-31'],
                ['李四', 'permanent', 'lisi@example.com', ''],
            ]
            
            for row_idx, row_data in enumerate(sample_data, 2):
                for col_idx, value in enumerate(row_data, 1):
                    cell = ws.cell(row=row_idx, column=col_idx, value=value)
                    cell.border = thin_border
                    cell.alignment = Alignment(horizontal='center', vertical='center')
            
            # 调整列宽
            ws.column_dimensions['A'].width = 15
            ws.column_dimensions['B'].width = 12
            ws.column_dimensions['C'].width = 25
            ws.column_dimensions['D'].width = 15
            
            # 添加说明sheet
            ws_info = wb.create_sheet(title="填写说明")
            instructions = [
                ['字段名称', '说明', '示例'],
                ['用户名', '用户名称，不能为空', '张三'],
                ['类型', '校验码类型：temp（临时）或 permanent（永久）', 'temp'],
                ['邮箱', '用户邮箱地址', 'user@example.com'],
                ['日期', '仅临时校验码需要填写，格式：YYYY-MM-DD', '2026-12-31'],
                ['', '', ''],
                ['注意事项：', '', ''],
                ['1. 类型列填写 temp 或 permanent（不区分大小写）', '', ''],
                ['2. 永久校验码不需要填写日期', '', ''],
                ['3. 邮箱格式必须正确', '', ''],
            ]
            
            for row_idx, row_data in enumerate(instructions, 1):
                for col_idx, value in enumerate(row_data, 1):
                    cell = ws_info.cell(row=row_idx, column=col_idx, value=value)
                    if row_idx == 1:
                        cell.font = Font(bold=True)
            
            ws_info.column_dimensions['A'].width = 20
            ws_info.column_dimensions['B'].width = 50
            ws_info.column_dimensions['C'].width = 25
            
            wb.save(file_path)
            return file_path
            
        except Exception as e:
            raise ExcelProcessingError(f"创建模板文件失败: {str(e)}")
