# -*- coding: utf-8 -*-
"""
XZStudio GUI界面模块

相关内容含AI生成
相关第三方库系XZ团队内部开发，不建议外部人员使用

Author: XZ Team
"""

import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from typing import Optional, Callable, List, Dict, Any
import threading
import os

from .api_client import APIClient
from .excel_handler import ExcelHandler
from .config import Config
from .exceptions import XZStudioError


class XZStudioGUI:
    """
    XZStudio 图形用户界面
    
    提供单用户操作和批量操作两种模式
    """
    
    def __init__(self, config: Optional[Config] = None):
        """
        初始化GUI
        
        Args:
            config: 配置对象
        """
        self.config = config or Config()
        self.api_client = APIClient(config=self.config)
        self.excel_handler = ExcelHandler()
        
        # 创建主窗口
        self.root = tk.Tk()
        self.root.title("XZStudio - 校验码发送工具")
        self.root.geometry("900x700")
        self.root.resizable(True, True)
        
        # 设置样式
        self._setup_styles()
        
        # 创建界面
        self._create_widgets()
        
        # 加载保存的配置
        self._load_config()
    
    def _setup_styles(self):
        """设置界面样式"""
        style = ttk.Style()
        style.theme_use('clam')
        
        # 配置样式
        style.configure('Title.TLabel', font=('微软雅黑', 14, 'bold'))
        style.configure('Section.TLabelframe.Label', font=('微软雅黑', 11, 'bold'))
        style.configure('Success.TLabel', foreground='green', font=('微软雅黑', 10))
        style.configure('Error.TLabel', foreground='red', font=('微软雅黑', 10))
        style.configure('Info.TLabel', foreground='#0066cc', font=('微软雅黑', 10))
        
        style.configure('Action.TButton', font=('微软雅黑', 10), padding=5)
        style.configure('Big.TButton', font=('微软雅黑', 11, 'bold'), padding=10)
    
    def _create_widgets(self):
        """创建界面组件"""
        # 主容器
        main_frame = ttk.Frame(self.root, padding="10")
        main_frame.pack(fill=tk.BOTH, expand=True)
        
        # 标题
        title_label = ttk.Label(
            main_frame, 
            text="XZStudio 校验码发送工具",
            style='Title.TLabel'
        )
        title_label.pack(pady=(0, 10))
        
        # 创建Notebook（标签页）
        self.notebook = ttk.Notebook(main_frame)
        self.notebook.pack(fill=tk.BOTH, expand=True)
        
        # 单用户操作页
        self._create_single_user_tab()
        
        # 批量操作页
        self._create_batch_tab()
        
        # 设置页
        self._create_settings_tab()
        
        # 底部状态栏
        self._create_status_bar(main_frame)
    
    def _create_single_user_tab(self):
        """创建单用户操作界面"""
        single_frame = ttk.Frame(self.notebook, padding="15")
        self.notebook.add(single_frame, text="单用户发送")
        
        # 表单区域
        form_frame = ttk.LabelFrame(single_frame, text="发送校验码", padding="15")
        form_frame.pack(fill=tk.X, pady=(0, 15))
        
        # 用户名
        ttk.Label(form_frame, text="用户名：").grid(row=0, column=0, sticky='w', pady=5)
        self.username_entry = ttk.Entry(form_frame, width=40)
        self.username_entry.grid(row=0, column=1, sticky='w', pady=5, padx=(10, 0))
        
        # 类型选择
        ttk.Label(form_frame, text="校验码类型：").grid(row=1, column=0, sticky='w', pady=5)
        self.code_type_var = tk.StringVar(value='temp')
        type_frame = ttk.Frame(form_frame)
        type_frame.grid(row=1, column=1, sticky='w', pady=5, padx=(10, 0))
        
        ttk.Radiobutton(
            type_frame, text="临时校验码", 
            variable=self.code_type_var, value='temp',
            command=self._on_type_change
        ).pack(side=tk.LEFT)
        ttk.Radiobutton(
            type_frame, text="永久校验码", 
            variable=self.code_type_var, value='permanent',
            command=self._on_type_change
        ).pack(side=tk.LEFT, padx=(20, 0))
        
        # 日期（仅临时校验码）
        self.date_frame = ttk.Frame(form_frame)
        self.date_frame.grid(row=2, column=0, columnspan=2, sticky='w', pady=5)
        
        ttk.Label(self.date_frame, text="有效期至：").pack(side=tk.LEFT)
        self.date_entry = ttk.Entry(self.date_frame, width=15)
        self.date_entry.pack(side=tk.LEFT, padx=(10, 0))
        ttk.Label(self.date_frame, text="（格式：YYYY-MM-DD）").pack(side=tk.LEFT, padx=(5, 0))
        
        # 邮箱
        ttk.Label(form_frame, text="邮箱：").grid(row=3, column=0, sticky='w', pady=5)
        self.email_entry = ttk.Entry(form_frame, width=40)
        self.email_entry.grid(row=3, column=1, sticky='w', pady=5, padx=(10, 0))
        
        # 发送按钮
        btn_frame = ttk.Frame(form_frame)
        btn_frame.grid(row=4, column=0, columnspan=2, pady=15)
        
        self.send_btn = ttk.Button(
            btn_frame, text="发送校验码", 
            style='Big.TButton',
            command=self._send_single
        )
        self.send_btn.pack()
        
        # 结果显示区域
        result_frame = ttk.LabelFrame(single_frame, text="发送结果", padding="15")
        result_frame.pack(fill=tk.BOTH, expand=True)
        
        self.result_text = tk.Text(
            result_frame, 
            height=10, 
            wrap=tk.WORD,
            font=('Consolas', 10)
        )
        self.result_text.pack(fill=tk.BOTH, expand=True)
        
        scrollbar = ttk.Scrollbar(result_frame, orient=tk.VERTICAL, command=self.result_text.yview)
        self.result_text.configure(yscrollcommand=scrollbar.set)
    
    def _create_batch_tab(self):
        """创建批量操作界面"""
        batch_frame = ttk.Frame(self.notebook, padding="15")
        self.notebook.add(batch_frame, text="批量发送")
        
        # 文件选择区域
        file_frame = ttk.LabelFrame(batch_frame, text="Excel文件", padding="10")
        file_frame.pack(fill=tk.X, pady=(0, 10))
        
        btn_row = ttk.Frame(file_frame)
        btn_row.pack(fill=tk.X)
        
        ttk.Button(
            btn_row, text="导入Excel文件", 
            command=self._import_excel
        ).pack(side=tk.LEFT, padx=(0, 10))
        
        ttk.Button(
            btn_row, text="生成模板文件", 
            command=self._create_template
        ).pack(side=tk.LEFT, padx=(0, 10))
        
        ttk.Button(
            btn_row, text="清空数据", 
            command=self._clear_batch_data
        ).pack(side=tk.LEFT)
        
        self.file_label = ttk.Label(file_frame, text="未选择文件", style='Info.TLabel')
        self.file_label.pack(anchor='w', pady=(5, 0))
        
        # 数据预览区域
        preview_frame = ttk.LabelFrame(batch_frame, text="数据预览", padding="10")
        preview_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 10))
        
        # 创建Treeview
        columns = ('username', 'code_type', 'email', 'date', 'status')
        self.preview_tree = ttk.Treeview(
            preview_frame, 
            columns=columns, 
            show='headings',
            height=10
        )
        
        # 设置列
        self.preview_tree.heading('username', text='用户名')
        self.preview_tree.heading('code_type', text='类型')
        self.preview_tree.heading('email', text='邮箱')
        self.preview_tree.heading('date', text='日期')
        self.preview_tree.heading('status', text='状态')
        
        self.preview_tree.column('username', width=100)
        self.preview_tree.column('code_type', width=80)
        self.preview_tree.column('email', width=200)
        self.preview_tree.column('date', width=100)
        self.preview_tree.column('status', width=150)
        
        # 滚动条
        tree_scroll = ttk.Scrollbar(
            preview_frame, 
            orient=tk.VERTICAL, 
            command=self.preview_tree.yview
        )
        self.preview_tree.configure(yscrollcommand=tree_scroll.set)
        
        self.preview_tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        tree_scroll.pack(side=tk.RIGHT, fill=tk.Y)
        
        # 操作按钮
        action_frame = ttk.Frame(batch_frame)
        action_frame.pack(fill=tk.X, pady=10)
        
        self.batch_send_btn = ttk.Button(
            action_frame, 
            text="批量发送校验码", 
            style='Big.TButton',
            command=self._send_batch
        )
        self.batch_send_btn.pack(side=tk.LEFT, padx=(0, 10))
        
        self.export_btn = ttk.Button(
            action_frame, 
            text="导出结果", 
            command=self._export_results
        )
        self.export_btn.pack(side=tk.LEFT)
        
        # 进度条
        self.progress_var = tk.DoubleVar()
        self.progress_bar = ttk.Progressbar(
            action_frame, 
            variable=self.progress_var, 
            maximum=100,
            length=200
        )
        self.progress_bar.pack(side=tk.RIGHT, padx=(10, 0))
        
        self.progress_label = ttk.Label(action_frame, text="")
        self.progress_label.pack(side=tk.RIGHT)
        
        # 存储批量数据
        self.batch_data: List[Dict[str, Any]] = []
    
    def _create_settings_tab(self):
        """创建设置界面"""
        settings_frame = ttk.Frame(self.notebook, padding="15")
        self.notebook.add(settings_frame, text="设置")
        
        # API配置
        api_frame = ttk.LabelFrame(settings_frame, text="API配置", padding="15")
        api_frame.pack(fill=tk.X, pady=(0, 15))
        
        # API Token
        ttk.Label(api_frame, text="API Token：").grid(row=0, column=0, sticky='w', pady=5)
        self.token_entry = ttk.Entry(api_frame, width=60, show='*')
        self.token_entry.grid(row=0, column=1, sticky='w', pady=5, padx=(10, 0))
        
        self.show_token_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(
            api_frame, text="显示", 
            variable=self.show_token_var,
            command=self._toggle_token_visibility
        ).grid(row=0, column=2, padx=(10, 0))
        
        # API URL
        ttk.Label(api_frame, text="API URL：").grid(row=1, column=0, sticky='w', pady=5)
        self.url_entry = ttk.Entry(api_frame, width=60)
        self.url_entry.grid(row=1, column=1, sticky='w', pady=5, padx=(10, 0))
        
        # 超时设置
        ttk.Label(api_frame, text="超时时间(秒)：").grid(row=2, column=0, sticky='w', pady=5)
        self.timeout_entry = ttk.Entry(api_frame, width=10)
        self.timeout_entry.grid(row=2, column=1, sticky='w', pady=5, padx=(10, 0))
        
        # 保存按钮
        btn_frame = ttk.Frame(api_frame)
        btn_frame.grid(row=3, column=0, columnspan=3, pady=15)
        
        ttk.Button(
            btn_frame, text="保存设置", 
            command=self._save_settings
        ).pack(side=tk.LEFT, padx=(0, 10))
        
        ttk.Button(
            btn_frame, text="测试连接", 
            command=self._test_connection
        ).pack(side=tk.LEFT)
        
        # 关于信息
        about_frame = ttk.LabelFrame(settings_frame, text="关于", padding="15")
        about_frame.pack(fill=tk.X)
        
        about_text = """
XZStudio 校验码发送工具 v1.0.0

相关内容含AI生成
相关第三方库系XZ团队内部开发，不建议外部人员使用

功能说明：
• 支持单用户和批量发送校验码
• 支持临时校验码和永久校验码两种类型
• 支持Excel文件导入导出
• 提供完善的错误处理和状态反馈
        """
        ttk.Label(about_frame, text=about_text, justify=tk.LEFT).pack(anchor='w')
    
    def _create_status_bar(self, parent):
        """创建状态栏"""
        status_frame = ttk.Frame(parent)
        status_frame.pack(fill=tk.X, pady=(10, 0))
        
        self.status_var = tk.StringVar(value="就绪")
        status_label = ttk.Label(
            status_frame, 
            textvariable=self.status_var,
            relief=tk.SUNKEN,
            padding=(5, 2)
        )
        status_label.pack(fill=tk.X)
    
    def _load_config(self):
        """加载配置"""
        if self.config.api_token:
            self.token_entry.insert(0, self.config.api_token)
        self.url_entry.insert(0, self.config.api_url)
        self.timeout_entry.insert(0, str(self.config.timeout))
    
    def _on_type_change(self):
        """类型变更处理"""
        if self.code_type_var.get() == 'temp':
            self.date_frame.grid()
        else:
            self.date_frame.grid_remove()
    
    def _toggle_token_visibility(self):
        """切换Token显示"""
        if self.show_token_var.get():
            self.token_entry.configure(show='')
        else:
            self.token_entry.configure(show='*')
    
    def _save_settings(self):
        """保存设置"""
        try:
            token = self.token_entry.get().strip()
            url = self.url_entry.get().strip()
            timeout = int(self.timeout_entry.get().strip() or '30')
            
            if token:
                self.config.api_token = token
                self.api_client.api_token = token
            
            if url:
                self.config.api_url = url
                self.api_client.api_url = url
            
            self.config.timeout = timeout
            self.api_client._timeout = timeout
            
            messagebox.showinfo("成功", "设置已保存")
            self.status_var.set("设置已保存")
            
        except ValueError:
            messagebox.showerror("错误", "超时时间必须是整数")
    
    def _test_connection(self):
        """测试API连接"""
        def test():
            result = self.api_client.test_connection()
            self.root.after(0, lambda: self._show_test_result(result))
        
        self.status_var.set("正在测试连接...")
        threading.Thread(target=test, daemon=True).start()
    
    def _show_test_result(self, result):
        """显示测试结果"""
        if result['success']:
            messagebox.showinfo("成功", result['message'])
            self.status_var.set("连接测试成功")
        else:
            messagebox.showerror("失败", result['message'])
            self.status_var.set("连接测试失败")
    
    def _send_single(self):
        """发送单个校验码"""
        username = self.username_entry.get().strip()
        code_type = self.code_type_var.get()
        email = self.email_entry.get().strip()
        date = self.date_entry.get().strip() if code_type == 'temp' else None
        
        # 验证输入
        if not username:
            messagebox.showerror("错误", "请输入用户名")
            return
        if not email:
            messagebox.showerror("错误", "请输入邮箱")
            return
        if code_type == 'temp' and not date:
            messagebox.showerror("错误", "临时校验码需要输入有效期")
            return
        
        # 禁用按钮
        self.send_btn.configure(state='disabled')
        self.status_var.set("正在发送...")
        
        def send():
            try:
                result = self.api_client.send_verification_code(
                    username=username,
                    code_type=code_type,
                    email=email,
                    date=date
                )
                self.root.after(0, lambda: self._on_send_success(result))
            except XZStudioError as e:
                self.root.after(0, lambda: self._on_send_error(str(e)))
        
        threading.Thread(target=send, daemon=True).start()
    
    def _on_send_success(self, result):
        """发送成功回调"""
        self.send_btn.configure(state='normal')
        self.status_var.set("发送成功")
        
        # 显示结果
        self.result_text.delete(1.0, tk.END)
        self.result_text.insert(tk.END, f"✓ 发送成功\n\n")
        self.result_text.insert(tk.END, f"状态码: {result['status_code']}\n")
        self.result_text.insert(tk.END, f"响应数据:\n")
        
        import json
        self.result_text.insert(tk.END, json.dumps(result['data'], ensure_ascii=False, indent=2))
        
        messagebox.showinfo("成功", "校验码发送成功！")
    
    def _on_send_error(self, error_msg):
        """发送失败回调"""
        self.send_btn.configure(state='normal')
        self.status_var.set("发送失败")
        
        self.result_text.delete(1.0, tk.END)
        self.result_text.insert(tk.END, f"✗ 发送失败\n\n错误信息: {error_msg}")
        
        messagebox.showerror("发送失败", error_msg)
    
    def _import_excel(self):
        """导入Excel文件"""
        file_path = filedialog.askopenfilename(
            title="选择Excel文件",
            filetypes=[("Excel文件", "*.xlsx *.xls"), ("所有文件", "*.*")]
        )
        
        if not file_path:
            return
        
        try:
            self.batch_data = self.excel_handler.read_excel(file_path)
            self.file_label.configure(text=f"已加载: {os.path.basename(file_path)} ({len(self.batch_data)}条记录)")
            
            # 更新预览
            self._update_preview()
            self.status_var.set(f"已导入 {len(self.batch_data)} 条记录")
            
        except XZStudioError as e:
            messagebox.showerror("导入失败", str(e))
            self.status_var.set("导入失败")
    
    def _create_template(self):
        """创建模板文件"""
        file_path = filedialog.asksaveasfilename(
            title="保存模板文件",
            defaultextension=".xlsx",
            filetypes=[("Excel文件", "*.xlsx")]
        )
        
        if not file_path:
            return
        
        try:
            self.excel_handler.create_template(file_path)
            messagebox.showinfo("成功", f"模板已保存至:\n{file_path}")
        except XZStudioError as e:
            messagebox.showerror("创建失败", str(e))
    
    def _update_preview(self):
        """更新预览表格"""
        # 清空现有数据
        for item in self.preview_tree.get_children():
            self.preview_tree.delete(item)
        
        # 添加新数据
        for user in self.batch_data:
            self.preview_tree.insert('', tk.END, values=(
                user.get('username', ''),
                user.get('code_type', ''),
                user.get('email', ''),
                user.get('date', ''),
                user.get('status', '待发送')
            ))
    
    def _clear_batch_data(self):
        """清空批量数据"""
        self.batch_data = []
        self.file_label.configure(text="未选择文件")
        self._update_preview()
        self.status_var.set("数据已清空")
    
    def _send_batch(self):
        """批量发送"""
        if not self.batch_data:
            messagebox.showerror("错误", "请先导入Excel文件")
            return
        
        # 确认发送
        if not messagebox.askyesno("确认", f"确定要发送 {len(self.batch_data)} 条校验码吗？"):
            return
        
        # 禁用按钮
        self.batch_send_btn.configure(state='disabled')
        self.progress_var.set(0)
        self.status_var.set("正在批量发送...")
        
        def send_batch():
            total = len(self.batch_data)
            success_count = 0
            fail_count = 0
            
            for idx, user in enumerate(self.batch_data):
                try:
                    result = self.api_client.send_verification_code(
                        username=user['username'],
                        code_type=user['code_type'],
                        email=user['email'],
                        date=user.get('date')
                    )
                    user['status'] = '成功'
                    # API返回的校验码字段是 verification_code
                    data = result.get('data', {})
                    user['verification_code'] = data.get('verification_code') or data.get('code', '')
                    user['message'] = '发送成功'
                    success_count += 1
                except XZStudioError as e:
                    user['status'] = '失败'
                    user['message'] = str(e)
                    fail_count += 1
                
                # 更新进度
                progress = (idx + 1) / total * 100
                self.root.after(0, lambda p=progress, s=success_count, f=fail_count: 
                    self._update_progress(p, s, f))
                
                # 更新预览
                self.root.after(0, self._update_preview)
            
            self.root.after(0, lambda: self._on_batch_complete(success_count, fail_count))
        
        threading.Thread(target=send_batch, daemon=True).start()
    
    def _update_progress(self, progress, success, fail):
        """更新进度"""
        self.progress_var.set(progress)
        self.progress_label.configure(text=f"成功: {success} | 失败: {fail}")
    
    def _on_batch_complete(self, success_count, fail_count):
        """批量发送完成"""
        self.batch_send_btn.configure(state='normal')
        self.status_var.set(f"批量发送完成 - 成功: {success_count}, 失败: {fail_count}")
        
        messagebox.showinfo(
            "完成", 
            f"批量发送完成！\n成功: {success_count}\n失败: {fail_count}"
        )
    
    def _export_results(self):
        """导出结果"""
        if not self.batch_data:
            messagebox.showerror("错误", "没有数据可导出")
            return
        
        file_path = filedialog.asksaveasfilename(
            title="保存结果文件",
            defaultextension=".xlsx",
            filetypes=[("Excel文件", "*.xlsx")]
        )
        
        if not file_path:
            return
        
        try:
            self.excel_handler.write_excel(file_path, self.batch_data)
            messagebox.showinfo("成功", f"结果已导出至:\n{file_path}")
        except XZStudioError as e:
            messagebox.showerror("导出失败", str(e))
    
    def run(self):
        """运行GUI"""
        self.root.mainloop()


def launch_gui():
    """启动GUI应用"""
    app = XZStudioGUI()
    app.run()


if __name__ == '__main__':
    launch_gui()