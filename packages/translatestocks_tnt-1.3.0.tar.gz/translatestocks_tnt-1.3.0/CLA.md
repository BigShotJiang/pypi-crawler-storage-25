# CLA Status — Public Upstream Closed to External Code Merges

The public `translatestocks-tnt / TNT-ls` repository does not currently accept external code contributions into the canonical upstream.

Accordingly:

- no public CLA signing workflow is active;
- no external pull request should be interpreted as merge-eligible;
- inbound code rights are not being solicited from the general public for this repository.

Forks and downstream modifications remain governed by the outbound repository license.

If JCFI, LLC later opens an invited-collaborator or internal contribution path, a new versioned CLA process may be published at that time.

Contact: `license@translatestocks.com`
