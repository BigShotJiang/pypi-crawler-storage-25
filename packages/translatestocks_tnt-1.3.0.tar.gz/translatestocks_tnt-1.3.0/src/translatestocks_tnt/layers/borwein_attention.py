﻿# Copyright (c) 2026 JCFI LLC  —  All rights reserved.
# U.S. Provisional Patent Application No. 64/013,259  (filed March 22, 2026)
# U.S. Provisional Patent Application No. 64/016,115  (filed March 24, 2026)
# U.S. Provisional Patent Application No. 64/022,599  (filed March 31, 2026)
#
# This file is part of the Thermodynamic Neural Transformer (TNT) library,
# version 1.3 (https://translatestocks.com/tnt).
#
# Licensed under the GNU Affero General Public License v3.0 (AGPLv3).
# You may use, copy, modify, and distribute this software under the
# terms of the AGPLv3.  A complete copy of the license is included in
# the LICENSE file at the root of this repository, and online at:
#     https://www.gnu.org/licenses/agpl-3.0.html
#
# DUAL-LICENSE NOTICE
# -------------------
# Any enterprise or commercial use that would otherwise require
# open-sourcing proprietary modifications or network-served derivatives
# under AGPLv3 §13 may be covered by a separate Commercial License
# issued by JCFI LLC.
# Contact: license@translatestocks.com
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND.
# SEE LICENSE AND NOTICE FOR FULL TERMS.
#
"""Golden Borwein f-series attention for the public `TNT-ls` release.

Replaces standard softmax attention with a strict f-budget mechanism derived
from the Golden Borwein series identity.

Core principle (Thm GBf):
    The Borwein f-series S_{k=2}^{K} phi^{-k} / Z_K first exhausts the
    normalized budget at K=5. This enforces a hard Top-5 mask: each attention
    head routes budget to exactly 5 positions and all others receive 0.

Standard softmax vs BorweinAttention:
    Softmax spreads weight across all positions.
    BorweinAttention ranks logits, assigns fixed f-series weights to the
    Top-5 positions, and masks all remaining positions.

Implementation:
    1. Compute raw attention logits qk^T / sqrt(d_k).
    2. Rank logits in descending order.
    3. Mask positions below rank 5.
    4. Assign deterministic f-series weights to the selected ranks.
    5. Apply the weighted attention to V.

The weights are deterministic functions of rank rather than logit magnitude.
Logit magnitude determines which positions are selected, but does not distort
the budget allocation among the selected Top-5 positions.

Multi-head behavior:
    Each head is independent. The Top-5 mask and f-weights are applied per
    head and per batch element. The implementation clamps Top-K to
    min(5, seq_len).

Causal masking:
    Optional causal masking is supported through the `is_causal` flag and is
    applied before rank selection.
"""

from __future__ import annotations

import math
import torch
import torch.nn as nn
import torch.nn.functional as F

from ..constants import BORWEIN_WEIGHTS, BORWEIN_TOP_K, KT_J2_BUDGET_THRESHOLD, P97_NULL_CONE_THRESHOLD
from .kt_order_parameter import KTOrderParameter


class BorweinAttention(nn.Module):
    """
    Multi-head attention with the Golden Borwein f-series budget.

    Parameters
    ----------
    d_model : int
        Model dimension.
    n_heads : int
        Number of attention heads.  d_model must be divisible by n_heads.
    dropout : float
        Dropout applied to the V-weighted output (default 0.0; set > 0
        only during training if desired).
    bias : bool
        Whether Q/K/V and output projections include a bias term.
    """

    def __init__(
        self,
        d_model: int,
        n_heads: int,
        dropout: float = 0.0,
        bias: bool = True,
        j2_mode: bool = True,
    ) -> None:
        super().__init__()
        if d_model % n_heads != 0:
            raise ValueError(
                f"d_model ({d_model}) must be divisible by n_heads ({n_heads})."
            )
        self.d_model = d_model
        self.n_heads = n_heads
        self.d_head  = d_model // n_heads
        self.dropout = dropout
        self.j2_mode = j2_mode

        self.q_proj = nn.Linear(d_model, d_model, bias=bias)
        self.k_proj = nn.Linear(d_model, d_model, bias=bias)
        self.v_proj = nn.Linear(d_model, d_model, bias=bias)
        self.out_proj = nn.Linear(d_model, d_model, bias=bias)

        self.kt_op = KTOrderParameter(d_model=d_model)

        self._r_p97: float = 1.0

        self._reset_parameters()

    def _reset_parameters(self) -> None:
        for proj in (self.q_proj, self.k_proj, self.v_proj, self.out_proj):
            nn.init.xavier_uniform_(proj.weight)
            if proj.bias is not None:
                nn.init.zeros_(proj.bias)

    def _phi_weights(self, device: torch.device, dtype: torch.dtype) -> torch.Tensor:
        """Return BORWEIN_WEIGHTS on the correct device/dtype, shape (BORWEIN_TOP_K,)."""
        return BORWEIN_WEIGHTS.to(device=device, dtype=dtype)

    def forward(
        self,
        x: torch.Tensor,
        attn_mask: torch.Tensor | None = None,
        is_causal: bool = False,
        x_stat: torch.Tensor | None = None,
    ) -> torch.Tensor:
        """
        Parameters
        ----------
        x : (B, T, d_model)
        attn_mask : optional boolean or float mask of shape (T, T) or (B, n_heads, T, T).
            True / -inf entries mark positions to suppress before rank selection.
        is_causal : bool
            If True, applies a lower-triangular causal mask before rank selection.
        x_stat : optional (B, T, d_model) or (B, d_model)
            Pre-norm hidden state; retained for backward compatibility and
            external monitoring via kt_op.  The j2 routing decision now uses
            the P9.7 logit-based order parameter (r̃_P97 from raw logits)
            rather than the hidden-state KT check.

        Returns
        -------
        out : (B, T, d_model)
        """
        B, T, C = x.shape
        device, dtype = x.device, x.dtype

        Q = self.q_proj(x)
        K = self.k_proj(x)
        V = self.v_proj(x)

        def _split_heads(t: torch.Tensor) -> torch.Tensor:
            return t.view(B, T, self.n_heads, self.d_head).transpose(1, 2)

        Q, K, V = _split_heads(Q), _split_heads(K), _split_heads(V)

        scale  = math.sqrt(self.d_head)
        logits = torch.matmul(Q, K.transpose(-2, -1)) / scale

        r_p97 = KTOrderParameter.p97_r_tilde_from_logits(logits)
        self._r_p97 = r_p97.item()

        if is_causal:
            causal_mask = torch.ones(T, T, device=device, dtype=torch.bool).triu(1)
            logits = logits.masked_fill(causal_mask, float("-inf"))

        if attn_mask is not None:
            if attn_mask.dtype == torch.bool:
                logits = logits.masked_fill(attn_mask, float("-inf"))
            else:
                logits = logits + attn_mask

        k_full = min(BORWEIN_TOP_K, T)
        if self.j2_mode and T > BORWEIN_TOP_K:
            if r_p97.item() < P97_NULL_CONE_THRESHOLD:
                k = min(2, T)
            else:
                k = k_full
        else:
            k = k_full

        topk_values, _ = logits.topk(k, dim=-1)
        kth_value = topk_values[..., -1:None]

        below_mask = logits < kth_value
        logits_masked = logits.masked_fill(below_mask, float("-inf"))


        soft_weights = F.softmax(logits_masked, dim=-1)

        _, rank_order = soft_weights.topk(k, dim=-1)

        phi_w = self._phi_weights(device, dtype)[:k]
        phi_w = phi_w / phi_w.sum()

        phi_weights = torch.zeros_like(soft_weights)
        phi_w_expanded = phi_w.view(1, 1, 1, k).expand(B, self.n_heads, T, k)
        phi_weights.scatter_(-1, rank_order, phi_w_expanded)

        active = soft_weights > 0
        phi_weights = phi_weights * active.float()
        phi_row_sum = phi_weights.sum(dim=-1, keepdim=True).clamp(min=1e-8)
        phi_weights = phi_weights / phi_row_sum

        if self.dropout > 0.0 and self.training:
            phi_weights = F.dropout(phi_weights, p=self.dropout)

        attn_out = torch.matmul(phi_weights, V)

        attn_out = attn_out.transpose(1, 2).contiguous().view(B, T, C)

        return self.out_proj(attn_out)

    def extra_repr(self) -> str:
        return (
            f"d_model={self.d_model}, n_heads={self.n_heads}, "
            f"d_head={self.d_head}, top_k={BORWEIN_TOP_K}, "
            f"j2_mode={self.j2_mode}"
        )
