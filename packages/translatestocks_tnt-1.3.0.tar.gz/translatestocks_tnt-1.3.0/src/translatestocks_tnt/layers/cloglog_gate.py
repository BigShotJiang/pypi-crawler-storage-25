﻿# Copyright (c) 2026 JCFI LLC  —  All rights reserved.
# U.S. Provisional Patent Application No. 64/013,259  (filed March 22, 2026)
# U.S. Provisional Patent Application No. 64/016,115  (filed March 24, 2026)
# U.S. Provisional Patent Application No. 64/022,599  (filed March 31, 2026)
#
# This file is part of the Thermodynamic Neural Transformer (TNT) library,
# version 1.3 (https://translatestocks.com/tnt).
#
# Licensed under the GNU Affero General Public License v3.0 (AGPLv3).
# You may use, copy, modify, and distribute this software under the
# terms of the AGPLv3.  A complete copy of the license is included in
# the LICENSE file at the root of this repository, and online at:
#     https://www.gnu.org/licenses/agpl-3.0.html
#
# DUAL-LICENSE NOTICE
# -------------------
# Any enterprise or commercial use that would otherwise require
# open-sourcing proprietary modifications or network-served derivatives
# under AGPLv3 §13 may be covered by a separate Commercial License
# issued by JCFI LLC.
# Contact: license@translatestocks.com
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND.
# SEE LICENSE AND NOTICE FOR FULL TERMS.
#
"""Public complementary log-log gate for the `TNT-ls` release.

This module provides the fixed-shape CLL.1 gate used by the left-side release.
It is part of the public LIB-facing routing boundary.
"""

from __future__ import annotations

import math

import torch
import torch.nn as nn

from ..constants import KT_b, KT_Kc

_LN2 = math.log(2.0)


def cloglog(z: torch.Tensor) -> torch.Tensor:
    """Compute the CLL.1 gate ``1 - 2^(-exp(b*z))`` in a stable form."""
    exp_bz = torch.exp(KT_b * z.clamp(-20.0, 20.0))
    return 1.0 - torch.exp(-_LN2 * exp_bz)


class CLogLogGate(nn.Module):
    """Differentiable complementary log-log gate with fixed KT shape."""

    def __init__(
        self,
        center: float = 0.0,
        scale: float = 1.0,
        learnable_center: bool = False,
        learnable_scale: bool = False,
    ) -> None:
        super().__init__()
        self.b = KT_b

        if learnable_center:
            self.center = nn.Parameter(torch.tensor(center))
        else:
            self.register_buffer("center", torch.tensor(center))

        if learnable_scale:
            self.scale = nn.Parameter(torch.tensor(scale))
        else:
            self.register_buffer("scale", torch.tensor(scale))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        z = (x - self.center) / self.scale
        return cloglog(z)

    @staticmethod
    def verify_identity() -> bool:
        lhs = (KT_b * _LN2) ** 2
        return abs(lhs - KT_Kc) < 1e-12

    def extra_repr(self) -> str:
        return (
            f"b={self.b:.6f} (fixed), "
            f"center={self.center.item():.3f}, "
            f"scale={self.scale.item():.3f}"
        )