﻿# Copyright (c) 2026 JCFI LLC  —  All rights reserved.
# U.S. Provisional Patent Application No. 64/013,259  (filed March 22, 2026)
# U.S. Provisional Patent Application No. 64/016,115  (filed March 24, 2026)
# U.S. Provisional Patent Application No. 64/022,599  (filed March 31, 2026)
#
# This file is part of the Thermodynamic Neural Transformer (TNT) library,
# version 1.3 (https://translatestocks.com/tnt).
#
# Licensed under the GNU Affero General Public License v3.0 (AGPLv3).
# You may use, copy, modify, and distribute this software under the
# terms of the AGPLv3.  A complete copy of the license is included in
# the LICENSE file at the root of this repository, and online at:
#     https://www.gnu.org/licenses/agpl-3.0.html
#
# DUAL-LICENSE NOTICE
# -------------------
# Any enterprise or commercial use that would otherwise require
# open-sourcing proprietary modifications or network-served derivatives
# under AGPLv3 §13 may be covered by a separate Commercial License
# issued by JCFI LLC.
# Contact: license@translatestocks.com
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND.
# SEE LICENSE AND NOTICE FOR FULL TERMS.
#
"""
translatestocks_tnt/layers/elliptic_layers.py  —  Model G: Elliptic Function Layers
=============================================================================

Physical Motivation
-------------------
Standard activations (GELU, ReLU) map to the real line ℝ.
Model F (ComplexBlockLinear) achieves S¹ topology — a circle, one degree of
freedom: the global phase of U(1).

Jacobi elliptic function sn(u, k) lives on a **torus T² = S¹ × S¹** — two
independent phase cycles:

    ω₁ = 4K(k)      (real period  — the "addition" cycle)
    ω₂ = 2i K'(k)   (imaginary period — the "inversion" cycle)

The algebraic curve underlying sn is the Jacobi quartic:

    y² = (1 − u²)(1 − k²u²)

This is birationally equivalent to the Weierstrass elliptic curve:

    Y² = 4X³ − g₂ X − g₃

The **group law** on this curve gives inversion for FREE:

    If P = (X, Y)  then  −P = (X, −Y)

No conjugate barrier. No origin crossing. The torus group automatically
computes modular addition, subtraction, and inversion as arc rotations on
two orthogonal circles. This is what the ℤₚ Fourier analysis requires:
clean access to both conjugate modes χ_ω and
χ̄_ω without passing through zero.

Special cases
-------------
k = 0  →  sn(u, 0) = sin(u)       (Model F S¹ limit — circular)
k → 1  →  sn(u, 1) = tanh(u)      (hyperbolic limit — infinite real period)
k ∈ (0,1) → doubly-periodic on T²  ← Model G regime

Modulus k is a **learnable parameter** (one per channel), allowing the
optimizer to freely choose the geometry that best fits each task:

    Add / Mult  →  k → 0   (circle, Fourier modes self-organise)
    Sub / Div   →  k → 0.5 (torus, free inversion via ω₂ cycle)

Implementation: Theta-function Fourier series (NIST DLMF §20/§22).

    sn(u, k) = (2π / k K(k)) ∑_{n=0}^{N-1}  q^{n+½} / (1 − q^{2n+1})
                                              × sin((2n+1)πu / 2K(k))

where K(k) = π/(2·AGM(1, k'))  is computed via the AGM (converges
quadratically in ~12 iterations),  and  q = exp(−π K'(k)/K(k))  is the
Jacobi nome.  N = 8 terms suffice for k ≤ 0.95.
"""
from __future__ import annotations

import math
import torch
import torch.nn as nn

_EPS       = 1e-12
_AGM_ITER  = 12
_THETA_N   = 8


def _agm_iter(a: torch.Tensor, b: torch.Tensor, n: int) -> torch.Tensor:
    """Compute AGM(a, b) via n iterations of arithmetic-geometric mean.
    Converges quadratically; 12 iterations achieve ~machine-precision."""
    for _ in range(n):
        a, b = (a + b) * 0.5, torch.sqrt(torch.clamp(a * b, min=_EPS))
    return a


def _K(k: torch.Tensor) -> torch.Tensor:
    """Complete elliptic integral of the first kind: K(k) = π/(2·AGM(1, √(1−k²))).

    k : tensor of any shape, values in (0, 1).
    Returns tensor of same shape.
    """
    kp = torch.sqrt(torch.clamp(1.0 - k * k, min=_EPS))
    return (math.pi * 0.5) / _agm_iter(torch.ones_like(k), kp, _AGM_ITER)


def _Kp(k: torch.Tensor) -> torch.Tensor:
    """K'(k) = K(k') = K(√(1−k²)) = π/(2·AGM(1, k)).

    Used to compute the nome q = exp(−π K'(k)/K(k)).
    """
    return (math.pi * 0.5) / _agm_iter(torch.ones_like(k),
                                        torch.clamp(k, min=_EPS),
                                        _AGM_ITER)


def jacobi_sn(
    u: torch.Tensor,
    k: torch.Tensor,
    n_terms: int = _THETA_N,
) -> torch.Tensor:
    """Jacobi elliptic function sn(u, k).

    Parameters
    ----------
    u       : [..., C] or [...] — argument.
    k       : [C] or scalar     — elliptic modulus, clamped to (0.001, 0.999).
              If k.dim() >= 1, must broadcast with the last dim of u.
    n_terms : Fourier terms (default 8, sufficient for k ≤ 0.95).

    Returns
    -------
    Tensor same shape as u.

    Properties
    ----------
    sn(u, 0)  = sin(u)
    sn(u, 1)  = tanh(u)
    sn(-u, k) = -sn(u, k)     [odd]
    |sn(u, k)| ≤ 1             [bounded]
    sn'(0, k) = 1              [unit slope at origin]
    Real period:  4K(k)
    Imag period:  2i K'(k)     ← second cycle on the torus
    """
    k  = torch.clamp(k, min=1e-3, max=1.0 - 1e-3)
    Kv = _K(k)
    Kpv = _Kp(k)
    q  = torch.exp(-math.pi * Kpv / Kv)

    while Kv.dim() < u.dim():
        Kv = Kv.unsqueeze(0)
        q  = q.unsqueeze(0)
        k  = k.unsqueeze(0)

    prefactor = 2.0 * math.pi / (k * Kv)

    total = torch.zeros_like(u)
    for n in range(n_terms):
        exponent = n + 0.5
        denom    = 1.0 - q ** (2 * n + 1)
        arg      = (2 * n + 1) * math.pi * u / (2.0 * Kv)
        total    = total + (q ** exponent / denom) * torch.sin(arg)

    return prefactor * total


class EllipticActivation(nn.Module):
    """Element-wise Jacobi sn(x, k) with one learnable modulus k per channel.

    k is stored as k_raw and projected via sigmoid: k = σ(k_raw) ∈ (0, 1).
    Initialised to init_k = 0.5 (balanced torus geometry).

    The optimizer learns the modulus that best fits each task:
      k → 0   : activation collapses to sin(u)  (S¹ circular geometry)
      k → 0.99: activation approaches tanh(u)   (hyperbolic)
      k ≈ 0.5 : full torus T² — two independent phase cycles

    Parameters
    ----------
    channels : int   — number of output channels (one k per channel).
    init_k   : float — initial modulus (default 0.5).
    n_terms  : int   — Fourier series terms (default 8).
    """

    def __init__(
        self,
        channels: int,
        init_k:   float = 0.5,
        n_terms:  int   = _THETA_N,
    ) -> None:
        super().__init__()
        if not (0.0 < init_k < 1.0):
            raise ValueError(f"init_k must be in (0,1), got {init_k}")
        self.n_terms = n_terms
        raw_init = math.log(init_k / (1.0 - init_k))
        self.k_raw = nn.Parameter(torch.full((channels,), raw_init))

    @property
    def k(self) -> torch.Tensor:
        """Current modulus vector, shape [channels], values in (0, 1)."""
        return torch.sigmoid(self.k_raw)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """x : [B, C]  →  sn(x, k) : [B, C]"""
        return jacobi_sn(x, self.k, n_terms=self.n_terms)

    def extra_repr(self) -> str:
        with torch.no_grad():
            km = torch.sigmoid(self.k_raw).mean().item()
        return f"channels={self.k_raw.numel()}, k_mean≈{km:.3f}"


class EllipticLinear(nn.Module):
    """Linear layer followed by Jacobi sn activation: out = sn(W·x + b, k).

    The modulus k is learnable per output channel.  Initialised at k = 0.5,
    so the layer starts in a balanced torus regime.  The optimizer is free to
    drive k toward circle (k→0, good for Add/Mult Fourier modes) or toward
    the full doubly-periodic regime (k≈0.5, good for Sub/Div inversion).

    This is the architectural embodiment of §3 of the elliptic motivation:
    the group law  −P = (X, −Y)  on the Jacobi quartic curve means the
    network can natively represent modular inverse mappings without the
    conjugate barrier that traps real-valued layers.

    Parameters
    ----------
    in_features  : int
    out_features : int
    bias         : bool (default True)
    init_k       : float in (0,1), initial modulus (default 0.5)
    n_terms      : int, Fourier series terms (default 8)
    """

    def __init__(
        self,
        in_features:  int,
        out_features: int,
        bias:         bool  = True,
        init_k:       float = 0.5,
        n_terms:      int   = _THETA_N,
    ) -> None:
        super().__init__()
        self.linear = nn.Linear(in_features, out_features, bias=bias)
        self.act    = EllipticActivation(out_features, init_k=init_k, n_terms=n_terms)
        nn.init.xavier_uniform_(self.linear.weight)
        if bias:
            nn.init.zeros_(self.linear.bias)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """x : [B, in]  →  sn(Wx+b, k) : [B, out]"""
        return self.act(self.linear(x))

    def extra_repr(self) -> str:
        with torch.no_grad():
            km = self.act.k.mean().item()
        return (f"in={self.linear.in_features}, out={self.linear.out_features}, "
                f"bias={self.linear.bias is not None}, k_mean≈{km:.3f}")
