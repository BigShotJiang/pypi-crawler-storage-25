﻿# Copyright (c) 2026 JCFI LLC  —  All rights reserved.
# U.S. Provisional Patent Application No. 64/013,259  (filed March 22, 2026)
# U.S. Provisional Patent Application No. 64/016,115  (filed March 24, 2026)
# U.S. Provisional Patent Application No. 64/022,599  (filed March 31, 2026)
#
# This file is part of the Thermodynamic Neural Transformer (TNT) library,
# version 1.3 (https://translatestocks.com/tnt).
#
# Licensed under the GNU Affero General Public License v3.0 (AGPLv3).
# You may use, copy, modify, and distribute this software under the
# terms of the AGPLv3.  A complete copy of the license is included in
# the LICENSE file at the root of this repository, and online at:
#     https://www.gnu.org/licenses/agpl-3.0.html
#
# DUAL-LICENSE NOTICE
# -------------------
# Any enterprise or commercial use that would otherwise require
# open-sourcing proprietary modifications or network-served derivatives
# under AGPLv3 §13 may be covered by a separate Commercial License
# issued by JCFI LLC.
# Contact: license@translatestocks.com
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND.
# SEE LICENSE AND NOTICE FOR FULL TERMS.
#
"""
quaternion_layers.py — Hamilton Product Linear Layers
=====================================================
QuaternionLinear and QuaternionGate for use in TopologyFuser.

Motivation
──────────
The TopologyFuser gate MLP currently flattens the four bit-plane channels
(tok, chrono, pov, branch) into a single vector before the first Linear layer:

    feat = cat([n_bits_tok | n_bits_chrono | n_bits_pov | n_bits_branch])
    logit = Linear → GELU → Linear → scalar

This treats the four channels as independent.  But the channels are NOT
independent: the meaning of a JSON token (tok) depends on WHOSE utterance it
belongs to (pov) and WHICH turn it appears in (chrono).  The standard MLP must
learn these cross-channel interactions from random init; it takes many steps to
establish the coupling.

The Hamilton product is non-commutative and encodes interactions between
quaternion components algebraically.  Mapping the four bit-plane channels onto
the four quaternion components (r, i, j, k) means the coupling between, say,
chrono and pov is expressed in the structure of the layer weights — it does not
need to be discovered by gradient descent starting from zero.

Topology → Quaternion Component Mapping
────────────────────────────────────────
    r (real)  ←  tok_bits    (data channel — "real" because it carries payload)
    i         ←  chrono_bits (temporal axis — first imaginary: time)
    j         ←  pov_bits    (speaker axis — second imaginary: identity)
    k         ←  branch_bits (narrative axis — third imaginary: which timeline)

This assignment mirrors the mathematical structure of quaternions:
  • r is the commutative part; tok_id is the data source.
  • i, j, k anti-commute pairwise (ij=k, jk=i, ki=j; ji=-k, kj=-i, ik=-j).
    The anti-commutativity of j and k means "pov at branch B" ≠ "branch B at pov" —
    which is exactly the semantic content of the DAG mask's POV×Branch interaction.

Hamilton Product Formula (left-multiply W ⊗ q)
────────────────────────────────────────────────
For input quaternion q = (qr, qi, qj, qk) and weight quaternion W = (Wr, Wi, Wj, Wk),
where each component is a linear map ℝ^{in} → ℝ^{out}:

    yr = qr·Wr − qi·Wi − qj·Wj − qk·Wk
    yi = qr·Wi + qi·Wr + qj·Wk − qk·Wj
    yj = qr·Wj − qi·Wk + qj·Wr + qk·Wi
    yk = qr·Wk + qi·Wj − qj·Wi + qk·Wr

Parameter count
───────────────
QuaternionLinear(in_f, out_f) uses  4 × in_f × out_f  parameters,
identical to nn.Linear(in_f, 4·out_f).  No additional cost.

Usage
──────
    from translatestocks_tnt.layers.quaternion_layers import QuaternionLinear, QuaternionGate

    # Standalone Hamilton product layer:
    ql = QuaternionLinear(16, 16)
    yr, yi, yj, yk = ql.forward_components(qr, qi, qj, qk)

    # Drop-in gate replacement for TopologyFuser:
    gate = QuaternionGate(n_bits_tok=17, n_bits_chrono=8,
                          n_bits_pov=2, n_bits_branch=4, q_dim=16)
    logit = gate(feat_tok, feat_chrono, feat_pov, feat_branch)  # [..., 1]
"""

from __future__ import annotations

import math
import torch
import torch.nn as nn
import torch.nn.functional as F

__all__ = ["QuaternionLinear", "QuaternionGate", "QuaternionSATBEmbedding",
           "_RoutedQuatEmbedder", "_RoutedSATBEmbedder"]


class QuaternionLinear(nn.Module):
    """Linear layer using the Hamilton product (left-multiply W ⊗ q).

    Input and output are quaternion vectors.  The primary API is
    ``forward_components(qr, qi, qj, qk)`` which accepts and returns four
    separate tensors of shape ``[..., features]``.

    A flat interleaved API (``forward``) is also provided for cases where
    the quaternion is stored as a single ``[..., 4*features]`` tensor.

    Parameters
    ----------
    in_features  : Size of each quaternion component (total input = 4×in_features).
    out_features : Size of each output component     (total output = 4×out_features).
    bias         : If True, adds a learnable bias quaternion (4 bias vectors).
    """

    def __init__(
        self,
        in_features:  int,
        out_features: int,
        bias:         bool = True,
    ) -> None:
        super().__init__()
        self.in_features  = in_features
        self.out_features = out_features

        self.Wr = nn.Parameter(torch.empty(out_features, in_features))
        self.Wi = nn.Parameter(torch.empty(out_features, in_features))
        self.Wj = nn.Parameter(torch.empty(out_features, in_features))
        self.Wk = nn.Parameter(torch.empty(out_features, in_features))

        if bias:
            self.br = nn.Parameter(torch.zeros(out_features))
            self.bi = nn.Parameter(torch.zeros(out_features))
            self.bj = nn.Parameter(torch.zeros(out_features))
            self.bk = nn.Parameter(torch.zeros(out_features))
        else:
            for name in ('br', 'bi', 'bj', 'bk'):
                self.register_parameter(name, None)

        self._reset_parameters()

    def _reset_parameters(self) -> None:
        scale = 1.0 / math.sqrt(2.0 * self.in_features)
        for W in (self.Wr, self.Wi, self.Wj, self.Wk):
            nn.init.uniform_(W, -scale, scale)

    def forward_components(
        self,
        qr: torch.Tensor,
        qi: torch.Tensor,
        qj: torch.Tensor,
        qk: torch.Tensor,
    ) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
        """Apply Hamilton product W ⊗ q to the four input components.

        Returns (yr, yi, yj, yk) each of shape [..., out_features].
        Bias terms are added if enabled.
        """
        yr = (F.linear(qr, self.Wr)
              - F.linear(qi, self.Wi)
              - F.linear(qj, self.Wj)
              - F.linear(qk, self.Wk))

        yi = (F.linear(qr, self.Wi)
              + F.linear(qi, self.Wr)
              + F.linear(qj, self.Wk)
              - F.linear(qk, self.Wj))

        yj = (F.linear(qr, self.Wj)
              - F.linear(qi, self.Wk)
              + F.linear(qj, self.Wr)
              + F.linear(qk, self.Wi))

        yk = (F.linear(qr, self.Wk)
              + F.linear(qi, self.Wj)
              - F.linear(qj, self.Wi)
              + F.linear(qk, self.Wr))

        if self.br is not None:
            yr = yr + self.br
            yi = yi + self.bi
            yj = yj + self.bj
            yk = yk + self.bk

        return yr, yi, yj, yk

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """Interleaved flat API: x[..., 4*in_f] → y[..., 4*out_f].

        Components are interleaved as [r0, i0, j0, k0, r1, i1, j1, k1, ...].
        Prefer ``forward_components`` for clarity.
        """
        if x.shape[-1] != 4 * self.in_features:
            raise ValueError(
                f"QuaternionLinear expects last dim = 4×{self.in_features} = "
                f"{4*self.in_features}, got {x.shape[-1]}."
            )
        qr = x[..., 0::4]
        qi = x[..., 1::4]
        qj = x[..., 2::4]
        qk = x[..., 3::4]
        yr, yi, yj, yk = self.forward_components(qr, qi, qj, qk)
        out = torch.stack([yr, yi, yj, yk], dim=-1)
        return out.reshape(*x.shape[:-1], 4 * self.out_features)

    def extra_repr(self) -> str:
        has_bias = self.br is not None
        return f"in={self.in_features}, out={self.out_features}, bias={has_bias}"


class QuaternionGate(nn.Module):
    """Hamilton-product gate — drop-in replacement for the linear MLP in TopologyFuser.

    Architecture
    ────────────
        feat_tok    → Linear(n_bits_tok,    q_dim)  → qr    ─┐
        feat_chrono → Linear(n_bits_chrono, q_dim)  → qi    ─┤
        feat_pov    → Linear(n_bits_pov,    q_dim)  → qj    ─┤  QuaternionLinear (W ⊗ q)
        feat_branch → Linear(n_bits_branch, q_dim)  → qk    ─┘
                                                       ↓ (yr, yi, yj, yk)
                                                    GELU(yr)        ← real component only
                                                       ↓
                                                    Linear(q_dim, 1)
                                                       ↓  scalar gate logit

    The real component yr is used for the scalar output because it corresponds to
    the tok_bits channel — the data payload — and receives contributions from all
    four cross-channel products (tok×chrono, tok×pov, tok×branch, etc.).

    Parameters
    ----------
    n_bits_tok, n_bits_chrono, n_bits_pov, n_bits_branch : int
        Widths of each input bit-plane (from TopologyFuser).
    q_dim : int
        Quaternion component dimension after initial per-channel projection.
        Default 16 (same expressive capacity as the original gate_hidden=32
        because Hamilton product already mixes all four components).
    """

    def __init__(
        self,
        n_bits_tok:    int,
        n_bits_chrono: int,
        n_bits_pov:    int,
        n_bits_branch: int,
        q_dim:         int = 16,
    ) -> None:
        super().__init__()
        self.q_dim = q_dim

        self.proj_r = nn.Linear(n_bits_tok,    q_dim, bias=False)
        self.proj_i = nn.Linear(n_bits_chrono, q_dim, bias=False)
        self.proj_j = nn.Linear(n_bits_pov,    q_dim, bias=False)
        self.proj_k = nn.Linear(n_bits_branch, q_dim, bias=False)

        self.qlin = QuaternionLinear(q_dim, q_dim, bias=True)

        self.act = nn.GELU()
        self.out = nn.Linear(q_dim, 1)

        self._reset_parameters()

    def _reset_parameters(self) -> None:
        for proj in (self.proj_r, self.proj_i, self.proj_j, self.proj_k):
            nn.init.xavier_uniform_(proj.weight)
        nn.init.zeros_(self.out.bias)
        nn.init.xavier_uniform_(self.out.weight)

    def forward(
        self,
        feat_tok:    torch.Tensor,
        feat_chrono: torch.Tensor,
        feat_pov:    torch.Tensor,
        feat_branch: torch.Tensor,
    ) -> torch.Tensor:
        """Compute scalar gate logit via Hamilton product mixing.

        Parameters
        ----------
        feat_tok    : Bit-plane of token IDs.
        feat_chrono : Bit-plane of Chrono coordinate.
        feat_pov    : Bit-plane of POV coordinate.
        feat_branch : Bit-plane of Branch coordinate.

        Returns
        -------
        logit : [..., 1] float — pre-CLogLog gate logit.
        """
        qr = self.proj_r(feat_tok)
        qi = self.proj_i(feat_chrono)
        qj = self.proj_j(feat_pov)
        qk = self.proj_k(feat_branch)

        yr, _, _, _ = self.qlin.forward_components(qr, qi, qj, qk)

        return self.out(self.act(yr))

    def extra_repr(self) -> str:
        return f"q_dim={self.q_dim}"


class QuaternionSATBEmbedding(nn.Module):
    """Quaternion-native embedding for a single SATB voice.

    Maps the four per-voice integer variables (note_pc, octave, dur_class,
    chord_group) to a single ``d_model``-dimensional quaternion embedding
    vector.  This is the **first full quaternion usage** in the TNT v1.2
    codebase: the four music variables ARE the four quaternion components,
    rather than being embedded separately and summed.

    Q component assignment (mirrors QuaternionGate / TopologyFuser convention)::

        r (real)  ←  chord_group   (harmonic ancestry — the scalar label)
        i         ←  note_pc       (chromatic ring Z₁₂ — first imaginary: pitch)
        j         ←  octave        (register depth     — second imaginary: time)
        k         ←  dur_class     (duration wall       — third imaginary: privilege)

    Architecture::

        group  → Embedding(group_vocab,  d) → qr  ─┐
        note   → Embedding(note_vocab,   d) → qi  ─┤  QuaternionLinear(d, d)
        octave → Embedding(octave_vocab, d) → qj  ─┤  (Hamilton product W ⊗ q)
        dur    → Embedding(dur_vocab,    d) → qk  ─┘
                                              ↓
                 interleave [r,i,j,k] → flat vector [..., d_model]

    The Hamilton product cross-couples all four components algebraically:
    pitch × octave × duration × harmony interactions are encoded in the weight
    structure before any Transformer layer processes the token.

    A Fourier Z₁₂ spectral prior can be applied to ``emb_i`` (the note
    component) via ``fourier_add_embedding_init_(emb.emb_i, P=12, ...)``
    after construction.

    Parameters
    ----------
    note_vocab, octave_vocab, dur_vocab, group_vocab : int
        Vocabulary sizes for each component.
    d_model : int
        Output dimensionality; **must be divisible by 4**.
    """

    def __init__(
        self,
        note_vocab:   int,
        octave_vocab: int,
        dur_vocab:    int,
        group_vocab:  int,
        d_model:      int,
    ) -> None:
        super().__init__()
        if d_model % 4 != 0:
            raise ValueError(
                f"QuaternionSATBEmbedding: d_model must be divisible by 4; got {d_model}."
            )
        self.d = d_model // 4
        self.d_model = d_model

        self.emb_r = nn.Embedding(group_vocab,  self.d)
        self.emb_i = nn.Embedding(note_vocab,   self.d)
        self.emb_j = nn.Embedding(octave_vocab, self.d)
        self.emb_k = nn.Embedding(dur_vocab,    self.d)

        self.qlin = QuaternionLinear(self.d, self.d, bias=True)

        self.norm = nn.LayerNorm(d_model)

        self._reset_parameters()

    def _reset_parameters(self) -> None:
        """Small uniform init.  Fourier prior on emb_i can be applied externally."""
        scale = 1.0 / math.sqrt(self.d)
        for emb in (self.emb_r, self.emb_i, self.emb_j, self.emb_k):
            nn.init.uniform_(emb.weight, -scale, scale)

    def forward(
        self,
        note:   torch.Tensor,
        octave: torch.Tensor,
        dur:    torch.Tensor,
        group:  torch.Tensor,
    ) -> torch.Tensor:
        """Map (note, octave, dur, group) → interleaved quaternion embedding.

        Parameters
        ----------
        note, octave, dur, group : torch.Tensor  (integer, any leading shape)

        Returns
        -------
        out : [..., d_model] float
            Interleaved layout ``[r₀,i₀,j₀,k₀, r₁,i₁,j₁,k₁, ...]``
            Compatible with :meth:`QuaternionLinear.forward` flat API.
        """
        qr = self.emb_r(group)
        qi = self.emb_i(note)
        qj = self.emb_j(octave)
        qk = self.emb_k(dur)

        yr, yi, yj, yk = self.qlin.forward_components(qr, qi, qj, qk)

        return self.norm(torch.cat([yr, yi, yj, yk], dim=-1))

    def extra_repr(self) -> str:
        return (
            f"note_vocab={self.emb_i.num_embeddings}, "
            f"octave_vocab={self.emb_j.num_embeddings}, "
            f"dur_vocab={self.emb_k.num_embeddings}, "
            f"group_vocab={self.emb_r.num_embeddings}, "
            f"d_model={self.d_model}"
        )


class _RoutedQuatEmbedder(nn.Module):
    """Routed Quaternion Embedder (Model E).

    Architecture
    ────────────
    The 4D quaternion embedding space is partitioned by the routing
    theorem into:

      • F — projected 3D forward subspace (r, i, j lanes):
            π_rij( W ⊗ φ(a,b) ) — Fourier-complete for addition/multiplication.

      • K̂_flat — 1D flat k-lane bypass:
            φ_flat_k(a,b) = W_a·e_a + W_b·e_b (independent linear maps,
            no Hamilton product) — Fourier-complete for subtraction/division
            via the conjugate character χ_{p-ω}.

    A scalar routing gate g ∈ [0,1] computed from a pre-attention pooler
    (before any quaternion computation, avoiding a cyclic dependency) blends
    the two k-lane paths:

        yk_out = g · φ_flat_k(a,b) + (1−g) · yk_quat

    The gate is a CLogLog-style sigmoid conditioned on the raw flat embeddings
    of all three input tokens, providing the gradient-residual routing signal
    described in Proposition 5.1 of the theorem.

    Forward pass execution order (strictly acyclic)
    ───────────────────────────────────────────────
      1. Flat token embeddings e_a, e_b, e_q  (shared by gate and k-bypass)
      2. h_c = cat[e_a, e_b, e_q]  →  g = σ(W_g · h_c + b_g)
      3. Quaternion embedding: qr,qi,qj,qk → Hamilton product → yr,yi,yj,yk_quat
      4. Flat k-bypass: φ_flat_k = W_ka·e_a + W_kb·e_b  (position-broadcasted)
      5. Blend k-lane: yk_out = g · φ_flat_k + (1−g) · yk_quat
      6. cat[yr, yi, yj, yk_out] along last dim → LayerNorm → [B, 3, D_MODEL]

    Parameters
    ──────────
    p    : int  — prime modulus (vocabulary size without query token)
    d    : int  — total embedding dimension; must satisfy d % 4 == 0
    qd   : int  — quaternion component size; must satisfy qd * 4 == d

    Parameter count delta vs _QuatEmbedder
    ───────────────────────────────────────
    Added:  emb_flat (p+1, qd) — shared flat table for gate + k-bypass
            W_ka, W_kb (qd, qd) — flat k-bypass linear maps for a and b
            W_g (1, 3·qd), b_g (1,) — pre-attention pooler gate
    This adds ≈ (p+1)·qd + 2·qd² + 3·qd + 1 parameters.
    For p=97, qd=32: ≈ 3,073 + 2,048 + 97 + 1 ≈ 5,219 extra scalars (~3%).
    """

    def __init__(self, p: int, d: int, qd: int) -> None:
        super().__init__()
        assert qd * 4 == d, f"qd*4={qd*4} must equal d={d}"
        self.p  = p
        self.qd = qd

        self.emb_tok    = nn.Embedding(p + 1, qd)
        self.emb_chrono = nn.Embedding(3, qd)
        self.emb_pov    = nn.Embedding(2, qd)
        self.emb_branch = nn.Embedding(2, qd)
        self.qlin       = QuaternionLinear(qd, qd, bias=True)

        self.emb_flat = nn.Embedding(p + 1, qd)

        self.W_ka = nn.Linear(qd, qd, bias=False)
        self.W_kb = nn.Linear(qd, qd, bias=False)

        self.W_g = nn.Linear(3 * qd, 1, bias=True)
        with torch.no_grad():
            nn.init.zeros_(self.W_g.weight)
            self.W_g.bias.fill_(1.1511)

        self.norm_emb = nn.LayerNorm(d)

        self._reset_parameters()

    def _reset_parameters(self) -> None:
        scale = 1.0 / math.sqrt(self.qd)
        nn.init.uniform_(self.emb_flat.weight, -scale, scale)
        nn.init.xavier_uniform_(self.W_ka.weight)
        nn.init.xavier_uniform_(self.W_kb.weight)

    def forward(self, a: torch.Tensor, b: torch.Tensor) -> torch.Tensor:
        """Embed (a, b) into a routed quaternion sequence.

        Parameters
        ──────────
        a : [B] int64 — first operand tokens
        b : [B] int64 — second operand tokens

        Returns
        ───────
        [B, 3, D_MODEL] float — LayerNorm'd quaternion sequence for [a, b, ?]
        """
        B, dev = a.shape[0], a.device
        q      = torch.full((B,), self.p, dtype=torch.long, device=dev)

        e_a = self.emb_flat(a)
        e_b = self.emb_flat(b)
        e_q = self.emb_flat(q)

        h_c = torch.cat([e_a, e_b, e_q], dim=-1)
        g   = torch.sigmoid(self.W_g(h_c))

        toks   = torch.stack([a, b, q], dim=1)
        T      = toks.shape[1]
        chrono = torch.arange(T, device=dev).unsqueeze(0).expand(B, -1)
        pov    = torch.zeros(B, dtype=torch.long, device=dev)
        branch = torch.zeros(B, dtype=torch.long, device=dev)

        qr = self.emb_tok(toks)
        qi = self.emb_chrono(chrono)
        qj = self.emb_pov(pov).unsqueeze(1).expand(-1, T, -1)
        qk = self.emb_branch(branch).unsqueeze(1).expand(-1, T, -1)

        yr, yi, yj, yk_quat = self.qlin.forward_components(qr, qi, qj, qk)

        φ_a = self.W_ka(e_a)
        φ_b = self.W_kb(e_b)
        φ_q = 0.5 * (φ_a + φ_b)

        phi_flat_k = torch.stack([φ_a, φ_b, φ_q], dim=1)

        g_3d   = g.unsqueeze(1)
        yk_out = g_3d * phi_flat_k + (1.0 - g_3d) * yk_quat

        out = torch.cat([yr, yi, yj, yk_out], dim=-1)
        return self.norm_emb(out)

    def extra_repr(self) -> str:
        return f"p={self.p}, qd={self.qd}, d_model={self.qd * 4}"


class _RoutedSATBEmbedder(nn.Module):
    """Routed SATB Embedder (Model E for Bach).

    Adapts ``_RoutedQuatEmbedder`` to the 4-variable per-voice Bach
    representation (note_pc, octave, dur_class, chord_group).

    Q component assignment (matches QuaternionSATBEmbedding):

        r (real)  ←  chord_group  (harmonic ancestry — scalar)
        i         ←  note_pc      (chromatic ring Z₁₂ — continuous imaginary)
        j         ←  octave       (register depth — second imaginary)
        k         ←  dur_class    (PRIVILEGED — k-bypass applies here)

    Routing
    ──────
    • r, i, j lanes → F-subspace: Hamilton product on (group, note, octave)
    • k lane → K̂_flat bypass: ``W_kd · emb_flat(dur)``  (privileged discrete dim)
    • Gate ``g ∈ [0,1]``:  computed from
      ``cat[emb_r(group), emb_i(note), emb_j(octave), emb_flat(dur)]``
      BEFORE the Hamilton product (strictly acyclic, per Prop. 5.1).

    ``emb_flat`` is a separate embedding table for dur used by both the gate
    and the k-bypass, keeping gradients on those paths independent of
    ``emb_k`` (which feeds the Hamilton product path).

    Parameters
    ----------
    note_vocab, octave_vocab, dur_vocab, group_vocab : int
    d_model : int — must satisfy ``d_model % 4 == 0``
    """

    def __init__(
        self,
        note_vocab:   int,
        octave_vocab: int,
        dur_vocab:    int,
        group_vocab:  int,
        d_model:      int,
    ) -> None:
        super().__init__()
        if d_model % 4 != 0:
            raise ValueError(f"d_model must be divisible by 4; got {d_model}.")
        self.qd      = d_model // 4
        self.d_model = d_model

        self.emb_r = nn.Embedding(group_vocab,  self.qd)
        self.emb_i = nn.Embedding(note_vocab,   self.qd)
        self.emb_j = nn.Embedding(octave_vocab, self.qd)
        self.emb_k = nn.Embedding(dur_vocab,    self.qd)
        self.qlin  = QuaternionLinear(self.qd, self.qd, bias=True)

        self.emb_flat = nn.Embedding(dur_vocab, self.qd)
        self.W_kd     = nn.Linear(self.qd, self.qd, bias=False)

        self.W_g = nn.Linear(4 * self.qd, 1, bias=True)
        with torch.no_grad():
            nn.init.zeros_(self.W_g.weight)
            self.W_g.bias.fill_(1.1511)

        self.norm = nn.LayerNorm(d_model)

        self._last_gate: float = 0.5

        self._reset_parameters()

    def _reset_parameters(self) -> None:
        scale = 1.0 / math.sqrt(self.qd)
        for emb in (self.emb_r, self.emb_i, self.emb_j, self.emb_k, self.emb_flat):
            nn.init.uniform_(emb.weight, -scale, scale)
        nn.init.xavier_uniform_(self.W_kd.weight)

    def forward(
        self,
        note:   torch.Tensor,
        octave: torch.Tensor,
        dur:    torch.Tensor,
        group:  torch.Tensor,
    ) -> torch.Tensor:
        """Map (note, octave, dur, group) → routed quaternion embedding.

        Returns
        -------
        out : ``[..., d_model]`` float — LayerNorm'd output.
        """
        e_r    = self.emb_r(group)
        e_i    = self.emb_i(note)
        e_j    = self.emb_j(octave)
        e_flat = self.emb_flat(dur)

        h_c = torch.cat([e_r, e_i, e_j, e_flat], dim=-1)
        g   = torch.sigmoid(self.W_g(h_c))
        self._last_gate = g.mean().item()

        e_k                      = self.emb_k(dur)
        yr, yi, yj, yk_quat      = self.qlin.forward_components(e_r, e_i, e_j, e_k)

        phi_flat_k = self.W_kd(e_flat)

        yk_out = g * phi_flat_k + (1.0 - g) * yk_quat

        return self.norm(torch.cat([yr, yi, yj, yk_out], dim=-1))

    def extra_repr(self) -> str:
        return (
            f"note_vocab={self.emb_i.num_embeddings}, "
            f"octave_vocab={self.emb_j.num_embeddings}, "
            f"dur_vocab={self.emb_k.num_embeddings}, "
            f"group_vocab={self.emb_r.num_embeddings}, "
            f"d_model={self.d_model}"
        )
