﻿# Copyright (c) 2026 JCFI LLC  —  All rights reserved.
# U.S. Provisional Patent Application No. 64/013,259  (filed March 22, 2026)
# U.S. Provisional Patent Application No. 64/016,115  (filed March 24, 2026)
# U.S. Provisional Patent Application No. 64/022,599  (filed March 31, 2026)
#
# This file is part of the Thermodynamic Neural Transformer (TNT) library,
# version 1.3 (https://translatestocks.com/tnt).
#
# Licensed under the GNU Affero General Public License v3.0 (AGPLv3).
# You may use, copy, modify, and distribute this software under the
# terms of the AGPLv3.  A complete copy of the license is included in
# the LICENSE file at the root of this repository, and online at:
#     https://www.gnu.org/licenses/agpl-3.0.html
#
# DUAL-LICENSE NOTICE
# -------------------
# Any enterprise or commercial use that would otherwise require
# open-sourcing proprietary modifications or network-served derivatives
# under AGPLv3 §13 may be covered by a separate Commercial License
# issued by JCFI LLC.
# Contact: license@translatestocks.com
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND.
# SEE LICENSE AND NOTICE FOR FULL TERMS.
#
"""
complex_bypass.py — Model F: Holomorphic Engine (Complex Bypass Gate)
====================================================================

Implements the complex bypass lane that replaces the real bypass in Model E.

Theory
------
The real bypass (Model E) forces weight sign flips through zero:

    w ∈ ℝ ∖ {0} has TWO connected components — a flip from +1 to −1
    requires w to pass through 0, annihilating the representation.
    Loss spikes on Sub/Div tasks where sign reversal is required.

The complex bypass (Model F) routes the branch (k) lane through ℂ ∖ {0}:

    |w| ≥ ε > 0  always.  A rotation  e^{iθ},  θ: 0 → π
    reaches −1  continuously  without ever touching zero.
    ℂ ∖ {0} is path-connected — there is no "zero crossing."

Implementation
--------------
We use a real block-matrix simulation instead of torch.complex64 to:
  1. Stay compatible with AdamW and BF16 training.
  2. Avoid Wirtinger-gradient interactions with existing gradient hooks.
  3. Preserve compatibility with torch.compile.

The Cauchy-Riemann structure is enforced analytically:

    ⎡ y_re ⎤   ⎡  W_R  −W_I ⎤ ⎡ x_re ⎤
    ⎣ y_im ⎦   ⎣  W_I   W_R ⎦ ⎣ x_im ⎦

storing only (W_R, W_I) each of shape [half_out, half_in].

Classes
-------
ComplexBlockLinear  —  Complex-linear map via real block-matrix simulation.
ComplexGate         —  Drop-in replacement for QuaternionGate (complex bypass).
"""
from __future__ import annotations

import math

import torch
import torch.nn as nn
import torch.nn.functional as F


class ComplexBlockLinear(nn.Module):
    """Linear map over ℂ implemented as a 2×2 real block matrix.

    A complex linear map  y = W · x  with  W ∈ ℂ^{m×n}  is equivalent to:

        ⎡ y_re ⎤   ⎡  W_R  −W_I ⎤ ⎡ x_re ⎤
        ⎣ y_im ⎦   ⎣  W_I   W_R ⎦ ⎣ x_im ⎦

    where  W_R = Re(W),  W_I = Im(W),  each ∈ ℝ^{out//2 × in//2}.

    Storing only (W_R, W_I) enforces Cauchy-Riemann structure exactly and
    reduces parameter count by 2× compared to an unconstrained 2×2 block.

    Parameters
    ----------
    in_features  : Input width.  Must be even (split into Re/Im halves).
    out_features : Output width.  Must be even.
    bias         : Add per-component bias vectors.  Default True.
    unit_norm    : If True, normalize (W_R, W_I) to the unit circle
                   element-wise during forward() — implements |w| = 1
                   via a differentiable weight-normalisation path.
                   Default False.
    """

    def __init__(
        self,
        in_features:  int,
        out_features: int,
        bias:         bool = True,
        unit_norm:    bool = False,
    ) -> None:
        super().__init__()
        if in_features % 2 != 0:
            raise ValueError(
                f"ComplexBlockLinear: in_features must be even, got {in_features}"
            )
        if out_features % 2 != 0:
            raise ValueError(
                f"ComplexBlockLinear: out_features must be even, got {out_features}"
            )
        self.in_features  = in_features
        self.out_features = out_features
        self.half_in      = in_features  // 2
        self.half_out     = out_features // 2
        self.unit_norm    = unit_norm

        self.weight_R = nn.Parameter(torch.empty(self.half_out, self.half_in))
        self.weight_I = nn.Parameter(torch.empty(self.half_out, self.half_in))

        if bias:
            self.bias_re = nn.Parameter(torch.zeros(self.half_out))
            self.bias_im = nn.Parameter(torch.zeros(self.half_out))
        else:
            self.register_parameter('bias_re', None)
            self.register_parameter('bias_im', None)

        self._reset_parameters()

    def _reset_parameters(self) -> None:
        std = 1.0 / math.sqrt(self.in_features)
        nn.init.uniform_(self.weight_R, -std, std)
        nn.init.uniform_(self.weight_I, -std, std)
        if self.bias_re is not None:
            nn.init.zeros_(self.bias_re)
            nn.init.zeros_(self.bias_im)

    def forward_components(
        self,
        x_re: torch.Tensor,
        x_im: torch.Tensor,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        """Complex-linear map on explicit (Re, Im) component tensors.

        Parameters
        ----------
        x_re : [..., half_in]  — real component of input.
        x_im : [..., half_in]  — imaginary component of input.

        Returns
        -------
        y_re : [..., half_out]
        y_im : [..., half_out]
        """
        W_R = self.weight_R
        W_I = self.weight_I

        if self.unit_norm:
            norm = (W_R.pow(2) + W_I.pow(2)).sqrt().clamp_min(1e-8)
            W_R  = W_R / norm
            W_I  = W_I / norm

        y_re = F.linear(x_re, W_R) - F.linear(x_im, W_I)
        y_im = F.linear(x_re, W_I) + F.linear(x_im, W_R)

        if self.bias_re is not None:
            y_re = y_re + self.bias_re
            y_im = y_im + self.bias_im

        return y_re, y_im

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """Complex-linear map on a flat interleaved tensor.

        Parameters
        ----------
        x : [..., in_features]  — first half is Re, second half is Im.

        Returns
        -------
        y : [..., out_features] — first half is Re, second half is Im.
        """
        x_re, x_im = x.chunk(2, dim=-1)
        y_re, y_im = self.forward_components(x_re, x_im)
        return torch.cat([y_re, y_im], dim=-1)

    def extra_repr(self) -> str:
        return (
            f"in={self.in_features}, out={self.out_features}, "
            f"bias={self.bias_re is not None}, unit_norm={self.unit_norm}"
        )


class ComplexGate(nn.Module):
    """Model F topology gate: Hamilton product (r, i, j) + Complex bypass (k).

    Architecture — 4-channel topology gate (ℍ × ℂ)
    ------------------------------------------------

    Three input channels (tok, chrono, pov) are projected to quaternion
    lanes qr, qi, qj via standard LinearGate projections, then mixed with
    the Hamilton product through QuaternionLinear.

    The fourth channel (branch) uses the complex bypass:
      branch  →  (proj_k_re, proj_k_im)  →  (bk_re, bk_im)  [half_q each]
              →  ComplexBlockLinear.forward_components         [ℂ mixing]
              →  cat(bk_re_out, bk_im_out)  =  qk             [q_dim]

    Hamilton product then mixes (qr, qi, qj, qk):
      yr, yi, yj, yk = QuaternionLinear(qr, qi, qj, qk)
      logit = out(act(yr))   ← reads real component

    Why the branch gets complex
    --------------------------
    The branch coordinate encodes narrative state transitions: entering a
    new branch ↔ flipping branch-weight sign.  In real space (Model E)
    this crossing must pass through 0, collapsing the representation.
    In ℂ ∖ {0} the rotation  e^{iθ}  achieves any sign flip continuously.

    Parameters
    ----------
    n_bits_tok    : Number of bit planes for the token coordinate.
    n_bits_chrono : Number of bit planes for the chrono coordinate.
    n_bits_pov    : Number of bit planes for the POV coordinate.
    n_bits_branch : Number of bit planes for the branch coordinate.
    q_dim         : Hamilton / complex latent dimension.  Must be even.
                    Default 16.
    """

    def __init__(
        self,
        n_bits_tok:    int,
        n_bits_chrono: int,
        n_bits_pov:    int,
        n_bits_branch: int,
        q_dim:         int = 16,
    ) -> None:
        super().__init__()
        if q_dim % 2 != 0:
            raise ValueError(f"ComplexGate: q_dim must be even, got {q_dim}")
        self.q_dim = q_dim
        half_q     = q_dim // 2

        self.proj_r = nn.Linear(n_bits_tok,    q_dim, bias=False)
        self.proj_i = nn.Linear(n_bits_chrono, q_dim, bias=False)
        self.proj_j = nn.Linear(n_bits_pov,    q_dim, bias=False)

        self.proj_k_re = nn.Linear(n_bits_branch, half_q, bias=False)
        self.proj_k_im = nn.Linear(n_bits_branch, half_q, bias=False)
        self.clin      = ComplexBlockLinear(q_dim, q_dim, bias=False)

        from translatestocks_tnt.layers.quaternion_layers import QuaternionLinear
        self.qlin = QuaternionLinear(q_dim, q_dim, bias=False)

        self.act = nn.GELU()
        self.out = nn.Linear(q_dim, 1)

        self._reset_parameters()

    def _reset_parameters(self) -> None:
        for proj in (self.proj_r, self.proj_i, self.proj_j,
                     self.proj_k_re, self.proj_k_im):
            nn.init.xavier_uniform_(proj.weight)
        nn.init.zeros_(self.out.bias)

    def forward(
        self,
        feat_tok:    torch.Tensor,
        feat_chrono: torch.Tensor,
        feat_pov:    torch.Tensor,
        feat_branch: torch.Tensor,
    ) -> torch.Tensor:
        """Compute topology gate logit via 4-channel (ℍ × ℂ) mixing.

        Steps
        -----
        1. Project tok/chrono/pov → quaternion lanes qr, qi, qj.
        2. Project branch → complex pair (bk_re, bk_im),
           mix via ComplexBlockLinear, cat → qk.
        3. Hamilton product: yr, yi, yj, yk = qlin(qr, qi, qj, qk).
        4. Output head reads yr: out(act(yr)) → [B, T, 1].
        """
        qr = self.proj_r(feat_tok)
        qi = self.proj_i(feat_chrono)
        qj = self.proj_j(feat_pov)

        bk_re = self.proj_k_re(feat_branch)
        bk_im = self.proj_k_im(feat_branch)
        bk_re_out, bk_im_out = self.clin.forward_components(bk_re, bk_im)
        qk = torch.cat([bk_re_out, bk_im_out], dim=-1)

        yr, _, _, _ = self.qlin.forward_components(qr, qi, qj, qk)

        return self.out(self.act(yr))

    def extra_repr(self) -> str:
        return f"q_dim={self.q_dim}"
