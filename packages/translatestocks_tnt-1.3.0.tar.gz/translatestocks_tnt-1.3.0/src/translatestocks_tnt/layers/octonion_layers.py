﻿# Copyright (c) 2026 JCFI LLC  —  All rights reserved.
# U.S. Provisional Patent Application No. 64/013,259  (filed March 22, 2026)
# U.S. Provisional Patent Application No. 64/016,115  (filed March 24, 2026)
# U.S. Provisional Patent Application No. 64/022,599  (filed March 31, 2026)
#
# This file is part of the Thermodynamic Neural Transformer (TNT) library,
# version 1.3 (https://translatestocks.com/tnt).
#
# Licensed under the GNU Affero General Public License v3.0 (AGPLv3).
# You may use, copy, modify, and distribute this software under the
# terms of the AGPLv3.  A complete copy of the license is included in
# the LICENSE file at the root of this repository, and online at:
#     https://www.gnu.org/licenses/agpl-3.0.html
#
# DUAL-LICENSE NOTICE
# -------------------
# Any enterprise or commercial use that would otherwise require
# open-sourcing proprietary modifications or network-served derivatives
# under AGPLv3 §13 may be covered by a separate Commercial License
# issued by JCFI LLC.
# Contact: license@translatestocks.com
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND.
# SEE LICENSE AND NOTICE FOR FULL TERMS.
#
"""octonion_layers.py — Model I: Octonion (Fano Plane / Spin(8) Triality) Engine.

The 8-dimensional octonions 𝕆 are the FINAL entry in Hurwitz's classification of
Normed Division Algebras (1898): ℝ (dim 1), ℂ (dim 2), ℍ (dim 4), 𝕆 (dim 8).
Any further extension (Sedenions, dim 16) introduces zero divisors — division
breaks down.

The KEY architectural distinction from Model H (CliffordLinear / Cl(0,3)):

  CliffordLinear (Model H): Cl(0,3) ≅ ℍ⊕ℍ  — ASSOCIATIVE geometric product.
    Two stacked layers: W₂ * (W₁ * x) = (W₂·W₁) * x  (can be collapsed).

  OctonionLinear (Model I): 𝕆 — NON-ASSOCIATIVE product.
    Two stacked layers: W₂ * (W₁ * x) ≠ (W₂·W₁) * x  in general.
    The depth is structurally irreducible — the network cannot "fold" the
    two phases into one. This is the algebraic signature of Spin(8) triality.

Spin(8) Triality Connection
───────────────────────────
Spin(8) has exactly three 8-dimensional irreducible representations:
  V  (vector, standard SO(8) rep)
  S⁺ (positive/right Weyl spinor)
  S⁻ (negative/left Weyl spinor)

The outer automorphism group of Spin(8) is S₃ (symmetric group on 3 elements),
which cyclically permutes V ↔ S⁺ ↔ S⁻.  This is D₄ triality.  There is no
analogous triality for any other Spin(n) — it is unique to Spin(8).

The triality automorphism is implemented by the octonion product: if we identify
V = S⁺ = S⁻ = 𝕆 = ℝ⁸, then the triality invariant is:
  T(v, s⁺, s⁻) = Re(v · conj(s⁺) · s⁻)   (octonion products)
The S₃ action permutes the three arguments cyclically and leaves T invariant.

Kosterlitz-Thouless → Grokking Correspondence (RST Framework)
──────────────────────────────────────────────────────────────
KT transition (Kosterlitz-Thouless 1973, 2D XY model):
  Below T_KT: vortex-antivortex pairs (bound phase)
              pair (V⁺, V⁻) ≅ S⁺ ⊗ S⁻  (Dirac fermion, topological order)
  Above T_KT: free vortices (disorder phase)
              single vortex ≅ Weyl spinor S⁺ or S⁻
  Vortex picks up (−1) phase under 2π rotation — EXACTLY spin-½ statistics.
  This is NOT an analogy — it is an exact identification via the Spin-structure
  on the torus T² (from §14).

Grokking transition (r̃ → 0 in the RST framework):
  Memorization phase:  effective DOF = (training_pair, memory_slot) — BOUND.
                       Pair structure ≅ (S⁺, S⁻) — training example and its
                       memorised answer are topologically bound.
  Generalization phase: the algorithm has extracted the abstract rule.
                        Free vortex — the representation is unbound from any
                        specific training instance.
  r̃ → 0 = the effective coupling between training pairs goes to zero
           as generalization is achieved = vortex condensation.

The RSIT theorem chain (JRG-1 through JRG-11) is, from this perspective, a
representation-theoretic analysis of Spin(8) triality in the Ramsey combinatorial
setting.

Fano Plane
──────────
The structure of 𝕆 is encoded in the Fano plane PG(2,2): a 7-point projective
geometry.  Each point = one imaginary unit {e₁,...,e₇}.  Each line = one
product relation: e_a * e_b = +e_c (cyclic order on the line).

  The 7 Fano lines (Baez 2002 / standard convention):
    {1, 2, 4}   {2, 3, 5}   {3, 4, 6}   {4, 5, 7}
    {5, 6, 1}   {6, 7, 2}   {7, 1, 3}

References:
  Baez, J.C. (2002). The Octonions. Bull. Amer. Math. Soc. 39(2), 145–205.
  Bott-Milnor / Kervaire (1958): parallelizability of spheres S¹,S³,S⁷.
  Cartan, E. (1925). Le principe de dualité et la théorie des groupes.
    Bull. Soc. Math. France 49, 361–374.  [D₄ triality first appears here]
  Kosterlitz, J.M. & Thouless, D.J. (1973). Ordering, metastability and
    phase transitions in two-dimensional systems. J. Phys. C 6, 1181.
  octonion_layers.py — JCFI LLC, 2026.

  Pinto Martins, C. F. (2026). Ramsey Statistics And Infiniteons Theory, Volume I. Zenodo. https://doi.org/10.5281/zenodo.19329589
  Pinto Martins, C. F. (2026). Ramsey Statistics And Infiniteons Theory, Volume II. Zenodo. https://doi.org/10.5281/zenodo.19330373

"""

import torch
import torch.nn as nn


_FANO_LINES: list[tuple[int, int, int]] = [
    (1, 2, 4),
    (2, 3, 5),
    (3, 4, 6),
    (4, 5, 7),
    (5, 6, 1),
    (6, 7, 2),
    (7, 1, 3),
]
"""7 Fano lines. Each triple (a, b, c) encodes e_a * e_b = +e_c (positive cyclic)."""


def _compute_octonion_table() -> tuple[torch.Tensor, torch.Tensor]:
    """Build the 8×8 octonion multiplication table.

    Basis: e_0 = 1 (scalar identity), e_1..e_7 (imaginary units, Fano plane).

      e_a * e_b = mul_sign[a, b] * e_{mul_idx[a, b]}

    Rules applied:
      • e_0 is the identity: e_0 * e_k = e_k * e_0 = e_k
      • e_i² = −1 for i = 1..7
      • Fano line (a, b, c): e_a*e_b=+e_c, e_b*e_c=+e_a, e_c*e_a=+e_b
      • Anticommutation: e_b*e_a=−e_c for all three reversal pairs

    Returns
    -------
    mul_sign : float32 [8, 8]
    mul_idx  : int64  [8, 8]
    """
    n = 8
    mul_sign = torch.zeros(n, n, dtype=torch.float32)
    mul_idx  = torch.zeros(n, n, dtype=torch.long)

    for k in range(n):
        mul_sign[0, k] = 1.0;  mul_idx[0, k] = k
        mul_sign[k, 0] = 1.0;  mul_idx[k, 0] = k

    for i in range(1, n):
        mul_sign[i, i] = -1.0
        mul_idx[i, i]  = 0

    for (a, b, c) in _FANO_LINES:
        mul_sign[a, b] = +1.0;  mul_idx[a, b] = c
        mul_sign[b, c] = +1.0;  mul_idx[b, c] = a
        mul_sign[c, a] = +1.0;  mul_idx[c, a] = b
        mul_sign[b, a] = -1.0;  mul_idx[b, a] = c
        mul_sign[c, b] = -1.0;  mul_idx[c, b] = a
        mul_sign[a, c] = -1.0;  mul_idx[a, c] = b

    return mul_sign, mul_idx


def _compute_oct_basis_lm(
    mul_sign: torch.Tensor,
    mul_idx:  torch.Tensor,
) -> torch.Tensor:
    """Build left-multiplication matrices for each octonion basis element.

    basis_lm[a, j, i] encodes: the j-th component of (e_a * e_i).

      (e_a * x)[j] = Σ_i  basis_lm[a, j, i] * x[i]

    Returns: float32 [8, 8, 8]
    """
    n  = 8
    lm = torch.zeros(n, n, n, dtype=torch.float32)
    for a in range(n):
        for i in range(n):
            j          = mul_idx[a, i].item()
            lm[a, j, i] = mul_sign[a, i].item()
    return lm


_OCT_SIGN, _OCT_IDX = _compute_octonion_table()
_OCT_BASIS_LM        = _compute_oct_basis_lm(_OCT_SIGN, _OCT_IDX)


def oct_product(a: torch.Tensor, b: torch.Tensor) -> torch.Tensor:
    """Batched octonion product.

    Args:
        a : [..., 8]  octonion-valued tensor
        b : [..., 8]
    Returns:
        [..., 8]  — the product a * b in 𝕆

    Note:  oct_product(a, oct_product(b, c))  ≠  oct_product(oct_product(a, b), c)
    in general — non-associativity is the defining feature, not a defect.
    """
    lm = _OCT_BASIS_LM.to(a.device)
    return torch.einsum("...k, kjl, ...l -> ...j", a, lm, b)


def triality_product(v: torch.Tensor, s_plus: torch.Tensor) -> torch.Tensor:
    """Compute the Spin(8) triality product:  S⁻ = V * S⁺  (octonion product).

    In D₄ triality, the three representations V, S⁺, S⁻ are all identified
    with 𝕆 = ℝ⁸.  The triality map V × S⁺ → S⁻ is the octonion product.

    Args:
        v      : [..., 8]  (vector representation)
        s_plus : [..., 8]  (positive half-spinor)
    Returns:
        [..., 8]  (negative half-spinor = v * s_plus)
    """
    return oct_product(v, s_plus)


class OctonionLinear(nn.Module):
    """Channel-grouped left-multiplication layer over the octonions 𝕆.

    Channels are grouped into 8-component octonion-valued vectors:
      [e₀ | e₁ | e₂ | e₃ | e₄ | e₅ | e₆ | e₇]
        1    imaginary units (Fano plane structure)

    For every (output_group, input_group) pair, one learnable octonion
    W ∈ 𝕆 acts on an input octonion x ∈ 𝕆 via left-multiplication W·x.
    This map is LINEAR in x for fixed W (the left-mult map L_W : 𝕆 → 𝕆
    is always linear, even though 𝕆 itself is non-associative).
    Contributions from all input groups are summed, then GELU is applied.

    Non-associativity signature:
      Two stacked OctonionLinear layers compute W₂ * (W₁ * x).
      Because 𝕆 is non-associative, this is NOT equal to (W₂ * W₁) * x.
      The two-layer computation cannot be folded into a single matrix —
      each layer maintains an independent phase orientation.
      Contrast: two CliffordLinear layers CAN be folded (Cl(0,3) is associative).

    This makes OctonionLinear structurally deeper than CliffordLinear at equal
    parameter count: depth is irréductible.

    Args:
        in_features:  int  — must be divisible by 8
        out_features: int  — must be divisible by 8
        bias:         bool — learnable additive bias (default True)
    """

    def __init__(
        self,
        in_features:  int,
        out_features: int,
        bias:         bool = True,
    ) -> None:
        super().__init__()
        if in_features % 8 != 0:
            raise ValueError(
                f"OctonionLinear: in_features must be divisible by 8, got {in_features}"
            )
        if out_features % 8 != 0:
            raise ValueError(
                f"OctonionLinear: out_features must be divisible by 8, got {out_features}"
            )
        self.in_features  = in_features
        self.out_features = out_features
        self.g_in         = in_features  // 8
        self.g_out        = out_features // 8

        self.weight = nn.Parameter(torch.empty(self.g_out, self.g_in, 8))
        self.bias   = nn.Parameter(torch.zeros(out_features)) if bias else None
        self.act    = nn.GELU()

        self.register_buffer("basis_lm", _OCT_BASIS_LM.clone())

        self._reset_parameters()

    def _reset_parameters(self) -> None:
        """Xavier on the real (scalar) grade; small N(0, 0.02) on imaginary grades.

        The scalar grade dominates early training, making the layer behave like
        a standard linear layer initially.  The imaginary units (Fano plane
        structure) are activated incrementally as the optimizer explores the
        octonion geometry.
        """
        w0 = torch.empty(self.g_out, self.g_in)
        nn.init.xavier_uniform_(w0)
        with torch.no_grad():
            self.weight[:, :, 0] = w0
            nn.init.normal_(self.weight[:, :, 1:], std=0.02)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Args:
            x : [B, in_features]
        Returns:
            [B, out_features]  — after octonion left-multiplication and GELU
        """
        B    = x.shape[0]
        x_oc = x.view(B, self.g_in, 8)

        out = torch.einsum(
            "opa, aji, bpi -> boj",
            self.weight, self.basis_lm, x_oc,
        )

        out = out.reshape(B, self.out_features)
        if self.bias is not None:
            out = out + self.bias
        return self.act(out)

    def extra_repr(self) -> str:
        return (
            f"in={self.in_features}, out={self.out_features}, 𝕆, "
            f"g_in={self.g_in}, g_out={self.g_out}, "
            f"scalar_norm={self.weight[:, :, 0].norm():.3f}"
        )


def _verify_octonion_table() -> None:
    """Verify key octonion identities in the precomputed table."""
    s, idx = _OCT_SIGN, _OCT_IDX

    def chk(a, b, exp_sign, exp_idx, msg):
        sg, id_ = s[a, b].item(), idx[a, b].item()
        assert id_ == exp_idx and abs(sg - exp_sign) < 1e-6, (
            f"FAIL {msg}: got sign={sg} idx={id_}, expected sign={exp_sign} idx={exp_idx}"
        )

    chk(0, 0, 1.0, 0, "1*1=1");  chk(0, 5, 1.0, 5, "1*e5=e5");  chk(3, 0, 1.0, 3, "e3*1=e3")
    for i in range(1, 8):
        chk(i, i, -1.0, 0, f"e{i}²=-1")
    chk(1, 2, +1.0, 4, "e1*e2=+e4");  chk(2, 4, +1.0, 1, "e2*e4=+e1")
    chk(2, 3, +1.0, 5, "e2*e3=+e5");  chk(3, 4, +1.0, 6, "e3*e4=+e6")
    chk(4, 5, +1.0, 7, "e4*e5=+e7");  chk(5, 6, +1.0, 1, "e5*e6=+e1")
    chk(6, 7, +1.0, 2, "e6*e7=+e2");  chk(7, 1, +1.0, 3, "e7*e1=+e3")
    chk(2, 1, -1.0, 4, "e2*e1=-e4");  chk(4, 2, -1.0, 1, "e4*e2=-e1")

    lhs_sign = s[1,2].item() * s[idx[1,2].item(), 3].item()
    lhs_idx  = idx[idx[1,2].item(), 3].item()
    rhs_sign = s[2,3].item() * s[1, idx[2,3].item()].item()
    rhs_idx  = idx[1, idx[2,3].item()].item()
    assert not (lhs_sign == rhs_sign and lhs_idx == rhs_idx), (
        "Expected non-associativity (e1*e2)*e3 ≠ e1*(e2*e3) but got equal results"
    )
    print(f"  Non-associativity: (e1*e2)*e3 = {lhs_sign:+.0f}*e{lhs_idx}  "
          f"≠  e1*(e2*e3) = {rhs_sign:+.0f}*e{rhs_idx}  ✓")


if __name__ == "__main__":
    _verify_octonion_table()
    print("Octonion table (Fano plane):  OK")
    print("  e_i² = −1  for all i=1..7")
    print("  All 7 Fano lines verified (positive cyclic products)")
    print("  Anticommutation e_j*e_i = −e_i*e_j  verified")

    e = torch.eye(8)
    p12 = oct_product(e[1:2], e[2:3])
    assert abs(p12[0, 4].item() - 1.0) < 1e-5, f"oct_product(e1,e2)[4] should be +1"
    print(f"\noct_product(e1, e2) = {p12.squeeze().tolist()}")
    print(f"  e₄ component = {p12[0, 4].item():.3f}  (expected +1.0)  ✓")

    layer = OctonionLinear(16, 8)
    x     = torch.randn(4, 16)
    y     = layer(x)
    assert y.shape == (4, 8)
    y.sum().backward()
    grads_ok = all(p.grad is not None for p in layer.parameters())
    n_p = sum(p.numel() for p in layer.parameters())
    print(f"\nOctonionLinear(16→8):  output={tuple(y.shape)}  params={n_p}  "
          f"grads={'OK' if grads_ok else 'FAIL'}")

    layer2 = OctonionLinear(128, 64)
    x2     = torch.randn(32, 128)
    y2     = layer2(x2)
    assert y2.shape == (32, 64)
    n2 = sum(p.numel() for p in layer2.parameters())
    print(f"OctonionLinear(128→64): output={tuple(y2.shape)}  params={n2}")

    v      = torch.randn(4, 8)
    s_plus = torch.randn(4, 8)
    s_minus = triality_product(v, s_plus)
    assert s_minus.shape == (4, 8)
    print(f"\ntriality_product V×S⁺ → S⁻:  shape={tuple(s_minus.shape)}  OK")

    print("\nALL OK")
