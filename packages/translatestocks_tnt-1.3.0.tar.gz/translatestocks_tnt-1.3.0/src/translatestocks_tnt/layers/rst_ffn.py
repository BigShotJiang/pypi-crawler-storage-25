﻿# Copyright (c) 2026 JCFI LLC  —  All rights reserved.
# U.S. Provisional Patent Application No. 64/013,259  (filed March 22, 2026)
# U.S. Provisional Patent Application No. 64/016,115  (filed March 24, 2026)
# U.S. Provisional Patent Application No. 64/022,599  (filed March 31, 2026)
#
# This file is part of the Thermodynamic Neural Transformer (TNT) library,
# version 1.3 (https://translatestocks.com/tnt).
#
# Licensed under the GNU Affero General Public License v3.0 (AGPLv3).
# You may use, copy, modify, and distribute this software under the
# terms of the AGPLv3.  A complete copy of the license is included in
# the LICENSE file at the root of this repository, and online at:
#     https://www.gnu.org/licenses/agpl-3.0.html
#
# DUAL-LICENSE NOTICE
# -------------------
# Any enterprise or commercial use that would otherwise require
# open-sourcing proprietary modifications or network-served derivatives
# under AGPLv3 §13 may be covered by a separate Commercial License
# issued by JCFI LLC.
# Contact: license@translatestocks.com
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND.
# SEE LICENSE AND NOTICE FOR FULL TERMS.
#
"""
rst_ffn.py — RS.15 Adaptive Feed-Forward Block
===============================================
Replaces the static `FF_MULT=4` FFN with a layer-depth-adaptive expansion
factor derived from the RS.15 transition-width formula (Theorem RS.15).

**Core principle (Theorem RS.15):**
    The transition width of structural Ramsey splits shrinks as:

        σ_w(x) = N₅₀(x) / (x · ln 2) · √(2/π)

    where x is the Ramsey clique complexity parameter.  As x grows
    (deeper layers → higher complexity = sharper structural transitions),
    the relative width shrinks proportionally to 1/x.  This means:

    • Lower layers (small x, wide transitions):
        → The FFN must span a broad hyperplane family → large expansion.
    • Deeper layers (large x, sharp transitions):
        → The window is narrow; a small expansion is sufficient and
          bottlenecking the FFN prevents over-parametrisation.

**Layer-to-x mapping:**
    x = layer_index + X_OFFSET   (default X_OFFSET=2, the smallest
    non-trivial Ramsey parameter).  At layer 0: x=2 (widest).
    At layer 6: x=8 (sharpest).

**Expansion formula:**
    σ_rel(l) = σ_w(l + X_OFFSET) / σ_w(X_OFFSET)   ∈ (0, 1]

    for sigma_w(x) = N₅₀(x) / (x · ln2) · √(2/π).
    Since N₅₀(x) grows slower than x (roughly as √x from RS.15
    empirical data), σ_rel(l) is strictly decreasing with l.

    Expansion factor:
        ff_mult(l) = FF_MULT_MAX - (FF_MULT_MAX - FF_MULT_MIN) · (1 - σ_rel(l))
                   = FF_MULT_MIN + (FF_MULT_MAX - FF_MULT_MIN) · σ_rel(l)

    This gives:
        l=0 (x=2, σ_rel=1): ff_mult = FF_MULT_MAX  (widest layer)
        l→∞ (x→∞, σ_rel→0): ff_mult → FF_MULT_MIN  (narrowest layer)

**N₅₀ approximation:**
    From RamseyStats RS.15 and CLL.1, N₅₀(x) grows approximately as:
        N₅₀(x) ≈ N50_BASE · x²   (empirical, ±10% for x=2..13)
    This is the simplest closed form consistent with T3: N₅₀(14) < N₁(14).
    The quadratic growth makes σ_rel(l) = 1/(l + X_OFFSET) * const,
    which gives a clean monotone staircase of expansion factors.

**d_ff is always an integer multiple of d_model:**
    ff_mult(l) is computed as a float and rounded to the nearest integer,
    then multiplied by d_model.  The minimum is FF_MULT_MIN * d_model.

Mathematical grounding:
    Theorem RS.15 (RamseyStats Chapter 3): σ_w formula and numerical
    confirmation ±10% for x=8..13.
    CLL.1 (RamseyStats Chapter 1): cloglog profile, b≈1.1511.

Usage::

    from translatestocks_tnt.layers import RSTFFNBlock

    # At layer 0 (widest):
    ffn0 = RSTFFNBlock(d_model=128, layer_index=0)
    # At layer 6 (narrowest):
    ffn6 = RSTFFNBlock(d_model=128, layer_index=6)

    out = ffn0(x)   # x: (B, T, d_model) or (B, d_model)


References:
Pinto Martins, C. F. (2026). Ramsey Statistics And Infiniteons Theory, Volume I. Zenodo. https://doi.org/10.5281/zenodo.19329589
Pinto Martins, C. F. (2026). Ramsey Statistics And Infiniteons Theory, Volume II. Zenodo. https://doi.org/10.5281/zenodo.19330373

"""

from __future__ import annotations

import math
import torch
import torch.nn as nn

from ..constants import FF_MULT_MIN, FF_MULT_MAX, N50_BASE


def _n50_approx(x: float) -> float:
    """
    N₅₀(x) ≈ N50_BASE · x²

    Calibrated from RamseyStats RS.15 (x=2..13).  Returns the approximate
    Ramsey threshold N₅₀ at clique complexity parameter x.
    """
    return N50_BASE * x * x


def _sigma_w(x: float) -> float:
    """
    Transition width: σ_w(x) = N₅₀(x) / (x · ln2) · √(2/π)

    From Theorem RS.15.
    """
    return _n50_approx(x) / (x * math.log(2)) * math.sqrt(2.0 / math.pi)


def ff_mult_for_layer(layer_index: int, x_offset: int = 2) -> int:
    """
    Compute the integer FFN expansion factor for a given layer.

    Parameters
    ----------
    layer_index : int
        0-based layer index.
    x_offset : int
        Clique complexity at layer 0 (default 2 = smallest non-trivial
        Ramsey parameter).

    Returns
    -------
    int
        Expansion factor in [FF_MULT_MIN, FF_MULT_MAX].
    """
    x = layer_index + x_offset
    sigma_l   = _sigma_w(x)
    sigma_ref = _sigma_w(x_offset)
    sigma_rel = sigma_ref / sigma_l

    ff_float = FF_MULT_MIN + (FF_MULT_MAX - FF_MULT_MIN) * sigma_rel
    return max(FF_MULT_MIN, min(FF_MULT_MAX, round(ff_float)))


class RSTFFNBlock(nn.Module):
    """
    RS.15-adaptive Feed-Forward Block.

    The expansion factor is set at construction time based on `layer_index`
    and does not change during training.  The block is a drop-in replacement
    for the standard `FFNBlock` used in the v1.1 GrokTransformer.

    Architecture (identical to FFNBlock except d_ff):
        LayerNorm → Linear(d_model → d_ff) → GELU → Dropout
        → Linear(d_ff → d_model) → Dropout → residual add

    Parameters
    ----------
    d_model : int
        Model dimension.
    layer_index : int
        0-based position in the transformer stack.  Controls d_ff via
        the RS.15 formula.  layer_index=0 gives the widest FFN (FF_MULT_MAX);
        deeper indices give progressively narrower FFNs.
    x_offset : int
        Clique complexity offset (default 2).
    dropout : float
        Dropout probability.
    """

    def __init__(
        self,
        d_model: int,
        layer_index: int,
        x_offset: int = 2,
        dropout: float = 0.1,
    ) -> None:
        super().__init__()
        self.d_model     = d_model
        self.layer_index = layer_index
        self.ff_mult     = ff_mult_for_layer(layer_index, x_offset)
        self.d_ff        = self.ff_mult * d_model

        self.net = nn.Sequential(
            nn.LayerNorm(d_model),
            nn.Linear(d_model, self.d_ff),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(self.d_ff, d_model),
            nn.Dropout(dropout),
        )

        for m in self.net:
            if isinstance(m, nn.Linear):
                nn.init.xavier_uniform_(m.weight)
                nn.init.zeros_(m.bias)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """Residual add: x + FFN(LayerNorm(x))."""
        return x + self.net(x)

    def extra_repr(self) -> str:
        return (
            f"d_model={self.d_model}, layer_index={self.layer_index}, "
            f"ff_mult={self.ff_mult}, d_ff={self.d_ff}"
        )
