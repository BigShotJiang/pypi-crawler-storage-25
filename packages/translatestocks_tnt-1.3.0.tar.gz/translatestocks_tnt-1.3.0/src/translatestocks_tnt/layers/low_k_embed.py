﻿# Copyright (c) 2026 JCFI LLC  —  All rights reserved.
# U.S. Provisional Patent Application No. 64/013,259  (filed March 22, 2026)
# U.S. Provisional Patent Application No. 64/016,115  (filed March 24, 2026)
# U.S. Provisional Patent Application No. 64/022,599  (filed March 31, 2026)
#
# This file is part of the Thermodynamic Neural Transformer (TNT) library,
# version 1.3 (https://translatestocks.com/tnt).
#
# Licensed under the GNU Affero General Public License v3.0 (AGPLv3).
# You may use, copy, modify, and distribute this software under the
# terms of the AGPLv3.  A complete copy of the license is included in
# the LICENSE file at the root of this repository, and online at:
#     https://www.gnu.org/licenses/agpl-3.0.html
#
# DUAL-LICENSE NOTICE
# -------------------
# Any enterprise or commercial use that would otherwise require
# open-sourcing proprietary modifications or network-served derivatives
# under AGPLv3 §13 may be covered by a separate Commercial License
# issued by JCFI LLC.
# Contact: license@translatestocks.com
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND.
# SEE LICENSE AND NOTICE FOR FULL TERMS.
#
"""Low-cardinality embedding utilities for the public `TNT-ls` release.

This file intentionally exposes only the minimum left-side public surface
needed for the binary / LIB routing path:

- ``BitPlaneEmbedding``
- ``DualEmbedding``
"""

from __future__ import annotations

import math

import torch
import torch.nn as nn

from .cloglog_gate import cloglog

__all__ = ["BitPlaneEmbedding", "DualEmbedding"]


class BitPlaneEmbedding(nn.Module):
    """Binary bit-plane embedding with optional learned projection."""

    def __init__(
        self,
        vocab_size: int,
        d_model: int,
        n_bits: int = 0,
        project: bool = True,
    ):
        super().__init__()
        if n_bits <= 0:
            n_bits = max(1, math.ceil(math.log2(max(vocab_size, 2))))
        self.n_bits = n_bits
        self.out_dim = d_model if project else n_bits

        masks = torch.tensor([1 << b for b in range(n_bits)], dtype=torch.long)
        self.register_buffer("_masks", masks)
        self.proj = nn.Linear(n_bits, d_model, bias=False) if project else None

    def forward(self, token_ids: torch.Tensor) -> torch.Tensor:
        x = token_ids.unsqueeze(-1).bitwise_and(self._masks)
        x = (x != 0).float()
        if self.proj is not None:
            x = self.proj(x)
        return x


class DualEmbedding(nn.Module):
    """Two-path embedding router used by the public LIB-facing surface.

    ``DualEmbedding`` combines a discrete ``BitPlaneEmbedding`` path and a
    standard learned embedding path, then routes between them with a CLL.1 gate
    and an optional straight-through hard decision during training.
    """

    def __init__(
        self,
        vocab_size: int,
        d_model: int,
        gate_hidden: int = 32,
        tau: float = 0.1,
        hard: bool = True,
    ):
        super().__init__()
        n_bits = max(1, math.ceil(math.log2(max(vocab_size, 2))))
        self.n_bits = n_bits
        self.tau = tau
        self.hard = hard

        self.bp = BitPlaneEmbedding(vocab_size, d_model)
        self.std = nn.Embedding(vocab_size, d_model)
        self.gate = nn.Sequential(
            nn.Linear(2 * n_bits, gate_hidden),
            nn.GELU(),
            nn.Linear(gate_hidden, 1),
        )

        masks = torch.tensor([1 << i for i in range(n_bits)], dtype=torch.long)
        self.register_buffer("_masks", masks)

    def _bits(self, ids: torch.Tensor) -> torch.Tensor:
        return (ids.unsqueeze(-1).bitwise_and(self._masks) != 0).float()

    def _sample_alpha(self, feat: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        logit = self.gate(feat)
        if self.training:
            u1 = logit.new_empty(logit.shape).uniform_().clamp_(1e-6, 1.0 - 1e-6)
            u2 = logit.new_empty(logit.shape).uniform_().clamp_(1e-6, 1.0 - 1e-6)
            gumbel = -torch.log(-torch.log(u1)) - (-torch.log(-torch.log(u2)))
            logit = logit + gumbel

        alpha_soft = cloglog(logit / self.tau)
        if self.hard and self.training:
            alpha_hard = (alpha_soft > 0.5).float()
            alpha = alpha_hard - alpha_soft.detach() + alpha_soft
        else:
            alpha = alpha_soft
        return alpha, alpha_soft

    def forward(self, a: torch.Tensor, b: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        feat = torch.cat([self._bits(a), self._bits(b)], dim=-1)
        alpha, alpha_soft = self._sample_alpha(feat)
        x_bp = self.bp(a) + self.bp(b)
        x_std = self.std(a) + self.std(b)
        x = alpha * x_bp + (1.0 - alpha) * x_std
        return x, alpha_soft

    def forward_paths(
        self,
        a: torch.Tensor,
        b: torch.Tensor,
    ) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
        feat = torch.cat([self._bits(a), self._bits(b)], dim=-1)
        alpha, alpha_soft = self._sample_alpha(feat)
        x_bp = self.bp(a) + self.bp(b)
        x_std = self.std(a) + self.std(b)
        return x_bp, x_std, alpha, alpha_soft