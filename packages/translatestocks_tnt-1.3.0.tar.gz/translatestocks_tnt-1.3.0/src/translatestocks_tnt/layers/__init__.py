﻿# Copyright (c) 2026 JCFI LLC  —  All rights reserved.
# U.S. Provisional Patent Application No. 64/013,259  (filed March 22, 2026)
# U.S. Provisional Patent Application No. 64/016,115  (filed March 24, 2026)
# U.S. Provisional Patent Application No. 64/022,599  (filed March 31, 2026)
#
# This file is part of the Thermodynamic Neural Transformer (TNT) library,
# version 1.3 (https://translatestocks.com/tnt).
#
# Licensed under the GNU Affero General Public License v3.0 (AGPLv3).
# You may use, copy, modify, and distribute this software under the
# terms of the AGPLv3.  A complete copy of the license is included in
# the LICENSE file at the root of this repository, and online at:
#     https://www.gnu.org/licenses/agpl-3.0.html
#
# DUAL-LICENSE NOTICE
# -------------------
# Any enterprise or commercial use that would otherwise require
# open-sourcing proprietary modifications or network-served derivatives
# under AGPLv3 §13 may be covered by a separate Commercial License
# issued by JCFI LLC.
# Contact: license@translatestocks.com
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND.
# SEE LICENSE AND NOTICE FOR FULL TERMS.
#
from .borwein_attention import BorweinAttention
from .cloglog_gate import CLogLogGate, cloglog
from .gated_exit_node import GatedExitNode
from .low_k_embed import BitPlaneEmbedding, DualEmbedding
from .rst_ffn import RSTFFNBlock, ff_mult_for_layer
from .kt_order_parameter import KTOrderParameter
from .quaternion_layers import QuaternionLinear
from .complex_bypass import ComplexBlockLinear
from .elliptic_layers import EllipticLinear
from .clifford_layers import CliffordLinear
from .octonion_layers import OctonionLinear
from .infiniteon_layers import InfiniteonLinear, NullWeightedInfiniteonLinear
