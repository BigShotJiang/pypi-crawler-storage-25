﻿# Copyright (c) 2026 JCFI LLC  —  All rights reserved.
# U.S. Provisional Patent Application No. 64/013,259  (filed March 22, 2026)
# U.S. Provisional Patent Application No. 64/016,115  (filed March 24, 2026)
# U.S. Provisional Patent Application No. 64/022,599  (filed March 31, 2026)
#
# This file is part of the Thermodynamic Neural Transformer (TNT) library,
# version 1.3 (https://translatestocks.com/tnt).
#
# Licensed under the GNU Affero General Public License v3.0 (AGPLv3).
# You may use, copy, modify, and distribute this software under the
# terms of the AGPLv3.  A complete copy of the license is included in
# the LICENSE file at the root of this repository, and online at:
#     https://www.gnu.org/licenses/agpl-3.0.html
#
# DUAL-LICENSE NOTICE
# -------------------
# Any enterprise or commercial use that would otherwise require
# open-sourcing proprietary modifications or network-served derivatives
# under AGPLv3 §13 may be covered by a separate Commercial License
# issued by JCFI LLC.
# Contact: license@translatestocks.com
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND.
# SEE LICENSE AND NOTICE FOR FULL TERMS.
#
"""
kt_order_parameter.py — KT Intensive Janson Order Parameter
=============================================================
Computes r~ = N · ?/µ² for hidden states, the unique phase coordinate
of the Kosterlitz–Thouless universality class.

**Theoretical basis (RSIT):**

    Lemma JRG-1 + Theorem JRG-5 together establish that only the k=1
    normalization r~ = N · ?/µ² carries the KT anomalous dimension ?=1.
    All other members of the family N^k · r have ?_k = 2-k ? 1.

    The Ramsey–KT dictionary identifies:
        N (vertex count) ? L² (2D XY area)
        r~ = Nr       ? the 2D superfluid stiffness order parameter
        r~ ? 0        ? free phase (Poisson-like, post-grokking)
        r~ >> 1       ? bound phase (correlated, raw input)
        r~ ˜ k_c ˜ 4.15 ? critical zone (Digamma router fires here)

    Theorem JRG-5 numerical verification (x=14, N=10·N50):
        Error |?_eff - 1| = 0.0123, decaying as ~2^{-x/2}.
        The j=2 dominance fraction is 92% at N=5·N50(14).

**Why this beats entropy as a routing signal:**

    - Entropy is not length-normalized. On a length-512 sequence,
      entropy is higher than on a length-64 sequence even if both are
      equally "grokked".
    - r~ = N · Var[h] / (E[h]² + e) has N built in. When computed with
      N = d_model (the KT area identification), r~ is invariant across
      context lengths — the same threshold k_c applies everywhere.
    - Entropy measures output distribution sharpness; r~ measures
      representation correlation structure — the CAUSE, not the effect.

**Phase boundaries (c=1.0 default):**

    Theoretical (KT thermodynamic system, E[h] = O(1)):
        r~ > k_c ˜ 4.15  ? bound phase:   full compute (Top-5 Borwein)
        r~ ˜ k_c         ? critical:       Digamma router eligible
        r~ < 0.50        ? free phase:     early-exit eligible
        r~ < 0.25        ? deep free:      j=2 fast path

    Empirical (d=128 transformer, E[h] ˜ 0 from near-zero init):
        r~ > 300          ? bound phase:   pre-grokking
        r~ ˜ 100-200      ? critical zone: at grokking step
        r~ < 200          ? free phase:    KT_FREE_PHASE_THRESHOLD
        r~ < 100          ? deep free:     KT_J2_BUDGET_THRESHOLD

    The gap (theoretical 0.5 vs empirical 200) arises because neural residual
    streams maintain E[h] ˜ 0 throughout training (near-zero weight init +
    residual paths cancel mean). The formula r~ = N·Var/E² therefore inflates
    relative to the thermodynamic case where E[h] grows to O(1) in the
    ordered (grokked) phase. Constants.py KT_FREE_PHASE_THRESHOLD is set to
    the empirical value 200.0, not the theoretical 0.5.

Usage::

    from translatestocks_tnt.layers import KTOrderParameter

    kt = KTOrderParameter(d_model=128)

    # Single forward pass (e.g., inside DigammaRouter):
    r_tilde = kt(h)             # h: (B, D) or (B, T, D) ? scalar Tensor

    # Phase check helpers:
    is_free    = kt.is_free_phase(h)     # r~ < KT_FREE_PHASE_THRESHOLD
    is_j2      = kt.is_j2_eligible(h)   # r~ < KT_J2_BUDGET_THRESHOLD
    is_critical = kt.is_critical(h)     # r~ ˜ k_c (within ±50%)


References:
Pinto Martins, C. F. (2026). Ramsey Statistics And Infiniteons Theory, Volume I. Zenodo. https://doi.org/10.5281/zenodo.19329589
Pinto Martins, C. F. (2026). Ramsey Statistics And Infiniteons Theory, Volume II. Zenodo. https://doi.org/10.5281/zenodo.19330373

"""

from __future__ import annotations

import math
import torch
import torch.nn as nn

from ..constants import (
    DIGAMMA_C_DEFAULT,
    KT_FREE_PHASE_THRESHOLD,
    KT_J2_BUDGET_THRESHOLD,
)


def _digamma_approx(x: float) -> float:
    """Digamma ?(x) via Stirling recursion — accurate to < 1e-9 for x = 1."""
    if x < 6.0:
        return _digamma_approx(x + 1.0) - 1.0 / x
    y = 1.0 / (x * x)
    return (
        math.log(x)
        - 0.5 / x
        - y * (1.0 / 12.0 - y * (1.0 / 120.0 - y * (1.0 / 252.0 - y * (1.0 / 240.0))))
    )


def _kc(c: float = DIGAMMA_C_DEFAULT) -> float:
    """Digamma threshold k_c = exp(c + ?(1 + 1/c))."""
    return math.exp(c + _digamma_approx(1.0 + 1.0 / c))


_KC_DEFAULT = _kc(DIGAMMA_C_DEFAULT)


class KTOrderParameter(nn.Module):
    """
    Computes the KT intensive Janson order parameter r~ = N · Var[h] / (E[h]² + e).

    In hidden-state space the Ramsey–KT dictionary maps:
        N (Ramsey vertex count) ? d_model (feature dimension = L² area)
        ?/µ² (Janson binding fraction) ? Var[h] / (E[h]² + e)

    So r~ = d_model · Var[h] / (E[h]² + e).

    This is length-invariant: N = d_model is fixed regardless of the
    sequence length T, so r~ has the same critical threshold k_c ˜ 4.15
    for any context length.

    Parameters
    ----------
    d_model : int
        Feature dimension.  Used as the KT area N in r~ = N·?/µ².
    c : float
        RST concentration parameter for computing k_c (default 1.0).
    eps : float
        Floor for µ² to avoid division by zero (default 1e-6).
    """

    def __init__(
        self,
        d_model: int,
        c: float = DIGAMMA_C_DEFAULT,
        eps: float = 1e-6,
    ) -> None:
        super().__init__()
        self.d_model = d_model
        self.c       = c
        self.eps     = eps
        self.N       = float(d_model)
        self.k_c     = _kc(c)

    def forward(self, h: torch.Tensor) -> torch.Tensor:
        """
        Compute r~ = N · Var_batch[h] / (E_batch[h]² + e), statistics
        taken ACROSS THE BATCH dimension (not the feature dimension).

        This is the thermodynamically correct Janson statistic: N is the
        KT area (= d_model), and the mean/variance measure how coherent
        the hidden states are across different inputs in the batch.

        Parameters
        ----------
        h : (B, D) or (B, T, D)

        Returns
        -------
        r_tilde : scalar Tensor
            Mean KT order parameter across feature dimensions.
            r~ ? 0  : free phase (coherent batch representations)
            r~ >> 1 : bound phase (diverse, uncorrelated batch states)

        Notes
        -----
        For tasks with symmetric input distributions (e.g. modular
        arithmetic with all (a,b) pairs), E_batch[h] ˜ 0 by symmetry
        regardless of training phase.  In that case r~ tracks Var_batch,
        which RISES during grokking (model learns richer Fourier modes).
        Use weight_norm_r_tilde() as the order parameter for those tasks.
        """
        with torch.no_grad():
            if h.dim() == 3:
                h_flat = h.reshape(-1, h.shape[-1])
            else:
                h_flat = h

            mu  = h_flat.mean(dim=0)
            var = h_flat.var(dim=0, unbiased=False)

            r = var / (mu ** 2 + self.eps)
            r_tilde = self.N * r.mean()
            return r_tilde

    def is_free_phase(self, h: torch.Tensor) -> bool:
        """True if r~ < KT_FREE_PHASE_THRESHOLD: representation is organized."""
        return self.forward(h).item() < KT_FREE_PHASE_THRESHOLD

    def is_j2_eligible(self, h: torch.Tensor) -> bool:
        """True if r~ < KT_J2_BUDGET_THRESHOLD: j=2 fast path activated."""
        return self.forward(h).item() < KT_J2_BUDGET_THRESHOLD

    def is_critical(self, h: torch.Tensor) -> bool:
        """True if r~ is within ±50% of k_c: near-threshold zone."""
        r = self.forward(h).item()
        return 0.5 * self.k_c <= r <= 1.5 * self.k_c

    def phase_label(self, h: torch.Tensor) -> str:
        """Human-readable phase label for diagnostics."""
        r = self.forward(h).item()
        if r < KT_J2_BUDGET_THRESHOLD:
            return f"deep-free (r~={r:.3f})"
        if r < KT_FREE_PHASE_THRESHOLD:
            return f"free (r~={r:.3f})"
        if r < 1.5 * self.k_c:
            return f"critical (r~={r:.3f}, k_c={self.k_c:.3f})"
        return f"bound (r~={r:.3f})"

    @staticmethod
    def weight_norm_r_tilde(model: nn.Module) -> float:
        """
        Weight-norm order parameter: mean squared weight per parameter.

            r~_w = (S ||W_l||²_F) / n_params

        This is the correct order parameter for grokking tasks where the
        input distribution is symmetric (E_batch[h] ˜ 0 always):

          • Pre-grokking (memorisation): model adds weight to fit each
            training pair ? r~_w RISES.
          • During grokking: high weight-decay forces the model to the
            minimal Fourier solution ? r~_w FALLS (slope ˜ -1 in log-log).
          • Post-grokking: stable low-norm Fourier weights ? r~_w is low.

        References: Nanda et al. (2023) "Progress measures for grokking
        via mechanistic interpretability", §4 weight norm analysis.

        Parameters
        ----------
        model : nn.Module
            Any PyTorch model.

        Returns
        -------
        float  (dimensionless, units: squared weight per parameter)
        """
        total_sq = sum(p.detach().norm().item() ** 2 for p in model.parameters())
        n_params = sum(p.numel() for p in model.parameters())
        return total_sq / max(n_params, 1)

    @staticmethod
    @torch.no_grad()
    def p97_r_tilde_from_logits(logits: torch.Tensor, eps: float = 1e-8) -> torch.Tensor:
        """
        P9.7 order parameter computed directly from raw pre-softmax attention
        logit matrix W (before any causal / padding mask is applied).

        By Theorem RJ.II, the imaginary Infiniteon edge sector is naturally
        isomorphic to the bivector space: ℑ_im(Kₙ) ≅ ∧²Rⁿ ≅ so(n).
        Every attention logit matrix W therefore decomposes as:

            X_skew = ½(W − Wᵀ)   imaginary sector  (coloring field / ∧²Rⁿ)
            S_sym  = ½(W + Wᵀ)   real sector        (asymmetry / symmetric load)

        The P9.7 order parameter (Definition 10.3–10.5, §4.1.7) is:

            r̃_P97 = N_std(X_skew) / r²  =  ‖X_skew‖²_F / (‖S_sym‖²_F + ε)

        Interpretation
        --------------
        r̃_P97 ≈ 1   on the null cone — balanced coloring / asymmetry (random init)
        r̃_P97 ≫ 1   coloring-dominant — Ramsey-rich; full Top-K budget needed
        r̃_P97 ≪ 1   asymmetry-dominant — diagonal/self-attention dominates;
                     free phase; j=2 fast path eligible (long sequences only)

        This is O(T²) on GPU via two fused CUDA kernels (no discrete graph math).
        Use P97_NULL_CONE_THRESHOLD = 0.5 as the j=2 trigger threshold.

        Parameters
        ----------
        logits : (..., T, T)
            Raw Q·Kᵀ/scale attention logit tensor. Must be free of ±inf entries —
            compute before any causal or padding mask is applied.
        eps : float
            Numerical floor for ‖S_sym‖²_F. Default 1e-8.

        Returns
        -------
        scalar Tensor
            Mean P9.7 order parameter across all leading batch/head dimensions.

        References
        ----------
        P9.7 (Definition 10.3 Norms, 10.4 Null cone, 10.5 Order parameter).
        §4.1.7  Colourings, Asymmetry, and the Null Cone.
        §4.1.10 + Theorem RJ.II: ℑ_im(Kₙ) ≅ ∧²Rⁿ ≅ so(n).
        """
        X_skew = 0.5 * (logits - logits.transpose(-1, -2))
        S_sym  = 0.5 * (logits + logits.transpose(-1, -2))
        N_std  = X_skew.pow(2).sum(dim=(-1, -2))
        r_sq   = S_sym.pow(2).sum(dim=(-1, -2)).clamp(min=0.0) + eps
        return (N_std / r_sq).mean()

    def extra_repr(self) -> str:
        return (
            f"d_model={self.d_model}, N={self.N}, "
            f"k_c={self.k_c:.4f} (c={self.c}), eps={self.eps}"
        )
