﻿# Copyright (c) 2026 JCFI LLC  —  All rights reserved.
# U.S. Provisional Patent Application No. 64/013,259  (filed March 22, 2026)
# U.S. Provisional Patent Application No. 64/016,115  (filed March 24, 2026)
# U.S. Provisional Patent Application No. 64/022,599  (filed March 31, 2026)
#
# This file is part of the Thermodynamic Neural Transformer (TNT) library,
# version 1.3 (https://translatestocks.com/tnt).
#
# Licensed under the GNU Affero General Public License v3.0 (AGPLv3).
# You may use, copy, modify, and distribute this software under the
# terms of the AGPLv3.  A complete copy of the license is included in
# the LICENSE file at the root of this repository, and online at:
#     https://www.gnu.org/licenses/agpl-3.0.html
#
# DUAL-LICENSE NOTICE
# -------------------
# Any enterprise or commercial use that would otherwise require
# open-sourcing proprietary modifications or network-served derivatives
# under AGPLv3 §13 may be covered by a separate Commercial License
# issued by JCFI LLC.
# Contact: license@translatestocks.com
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND.
# SEE LICENSE AND NOTICE FOR FULL TERMS.
#
"""Post-backbone gated routing node for the public `TNT-ls` release.

`GatedExitNode` is part of the public LIB-facing routing boundary. It applies
the route after the shared backbone, allowing the inactive branch to receive no
gradient under the hard gate and to be skipped entirely after gate freeze.
"""

from __future__ import annotations

from typing import Optional

import torch
import torch.nn as nn

__all__ = ["GatedExitNode"]


class GatedExitNode(nn.Module):
    """Post-backbone gated routing with optional branch freeze."""

    def __init__(self, backbone: nn.Module) -> None:
        super().__init__()
        self.backbone = backbone
        self._frozen_alpha: Optional[float] = None

    def freeze_gate(self, frozen_alpha: float) -> None:
        self._frozen_alpha = float(frozen_alpha)

    def unfreeze_gate(self) -> None:
        self._frozen_alpha = None

    @property
    def gate_frozen(self) -> bool:
        return self._frozen_alpha is not None

    def forward(
        self,
        x_bp: torch.Tensor,
        x_std: torch.Tensor,
        alpha: torch.Tensor,
    ) -> torch.Tensor:
        if self._frozen_alpha is not None:
            return self._frozen_forward(x_bp, x_std, alpha)
        return self._normal_forward(x_bp, x_std, alpha)

    def _normal_forward(
        self,
        x_bp: torch.Tensor,
        x_std: torch.Tensor,
        alpha: torch.Tensor,
    ) -> torch.Tensor:
        batch_size = x_bp.size(0)
        h = self.backbone(torch.cat([x_bp, x_std], dim=0))
        h_d = h[:batch_size]
        h_c = h[batch_size:]
        return alpha * h_d + (1.0 - alpha) * h_c

    def _frozen_forward(
        self,
        x_bp: torch.Tensor,
        x_std: torch.Tensor,
        alpha: torch.Tensor,
    ) -> torch.Tensor:
        assert self._frozen_alpha is not None
        if self._frozen_alpha < 0.5:
            h_c = self.backbone(x_std)
            return (1.0 - alpha) * h_c
        h_d = self.backbone(x_bp)
        return alpha * h_d

    def extra_repr(self) -> str:
        if self.gate_frozen:
            path = "Standard (alpha=0)" if self._frozen_alpha < 0.5 else "BitPlane (alpha=1)"
            return f"gate_frozen=True, active_path={path}"
        return "gate_frozen=False"