﻿# Copyright (c) 2026 JCFI LLC  —  All rights reserved.
# U.S. Provisional Patent Application No. 64/013,259  (filed March 22, 2026)
# U.S. Provisional Patent Application No. 64/016,115  (filed March 24, 2026)
# U.S. Provisional Patent Application No. 64/022,599  (filed March 31, 2026)
#
# This file is part of the Thermodynamic Neural Transformer (TNT) library,
# version 1.3 (https://translatestocks.com/tnt).
#
# Licensed under the GNU Affero General Public License v3.0 (AGPLv3).
# You may use, copy, modify, and distribute this software under the
# terms of the AGPLv3.  A complete copy of the license is included in
# the LICENSE file at the root of this repository, and online at:
#     https://www.gnu.org/licenses/agpl-3.0.html
#
# DUAL-LICENSE NOTICE
# -------------------
# Any enterprise or commercial use that would otherwise require
# open-sourcing proprietary modifications or network-served derivatives
# under AGPLv3 §13 may be covered by a separate Commercial License
# issued by JCFI LLC.
# Contact: license@translatestocks.com
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND.
# SEE LICENSE AND NOTICE FOR FULL TERMS.
#
"""Fourier initialization helpers for the public TNT-ls release.

This module exposes the minimal initialization surface needed by the public
LIB showcase benchmark. It seeds the Standard path of a DualEmbedding with the
real Fourier basis of Z_P*.
"""

from __future__ import annotations

import math

import torch
import torch.nn as nn

__all__ = [
    "primitive_root",
    "discrete_log_table",
    "fourier_mult_embedding_init_",
]


def _prime_factors(n: int) -> list[int]:
    factors: list[int] = []
    divisor = 2
    while divisor * divisor <= n:
        if n % divisor == 0:
            factors.append(divisor)
            while n % divisor == 0:
                n //= divisor
        divisor += 1
    if n > 1:
        factors.append(n)
    return factors


def primitive_root(P: int) -> int:
    """Return the smallest primitive root of a prime modulus P."""

    order = P - 1
    factors = _prime_factors(order)
    for g in range(2, P):
        if all(pow(g, order // factor, P) != 1 for factor in factors):
            return g
    raise ValueError(f"No primitive root found for P={P} (is P prime?)")


def discrete_log_table(P: int, g: int) -> list[int]:
    """Build the discrete log table for prime P with primitive root g."""

    dlog = [-1] * P
    power = 1
    for exponent in range(P - 1):
        dlog[power] = exponent
        power = (power * g) % P
    return dlog


def fourier_mult_embedding_init_(
    emb: nn.Embedding,
    P: int,
    scale: float | None = None,
    g: int | None = None,
) -> nn.Embedding:
    """Initialize an embedding with the real Fourier basis of Z_P*."""

    if emb.num_embeddings != P:
        raise ValueError(
            f"emb.num_embeddings={emb.num_embeddings} does not match P={P}"
        )

    d_model = emb.embedding_dim
    if scale is None:
        scale = 1.0 / math.sqrt(d_model)

    if g is None:
        g = primitive_root(P)
    dlog = discrete_log_table(P, g)
    order = P - 1

    fourier = torch.zeros(P, d_model, dtype=torch.float32)
    k_max = (d_model + 1) // 2
    for k in range(1, k_max + 1):
        cos_col = 2 * (k - 1)
        sin_col = cos_col + 1
        for token in range(1, P):
            phase = 2.0 * math.pi * k * dlog[token] / order
            if cos_col < d_model:
                fourier[token, cos_col] = math.cos(phase)
            if sin_col < d_model:
                fourier[token, sin_col] = math.sin(phase)

    fourier.mul_(scale)

    with torch.no_grad():
        emb.weight.copy_(fourier)

    return emb