﻿# Copyright (c) 2026 JCFI LLC  —  All rights reserved.
# U.S. Provisional Patent Application No. 64/013,259  (filed March 22, 2026)
# U.S. Provisional Patent Application No. 64/016,115  (filed March 24, 2026)
# U.S. Provisional Patent Application No. 64/022,599  (filed March 31, 2026)
#
# This file is part of the Thermodynamic Neural Transformer (TNT) library,
# version 1.3 (https://translatestocks.com/tnt).
#
# Licensed under the GNU Affero General Public License v3.0 (AGPLv3).
# You may use, copy, modify, and distribute this software under the
# terms of the AGPLv3.  A complete copy of the license is included in
# the LICENSE file at the root of this repository, and online at:
#     https://www.gnu.org/licenses/agpl-3.0.html
#
# DUAL-LICENSE NOTICE
# -------------------
# Any enterprise or commercial use that would otherwise require
# open-sourcing proprietary modifications or network-served derivatives
# under AGPLv3 §13 may be covered by a separate Commercial License
# issued by JCFI LLC.
# Contact: license@translatestocks.com
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND.
# SEE LICENSE AND NOTICE FOR FULL TERMS.
#
"""
Framework constants — the τ-Zeta-Ramsey numerical substrate.

All constants derived from:
    X = ln(π) / φ
    τ = 0.5 · (X − 1/(2X))

These are FIXED — not learned.  They parameterise the spectral
initialisation and regularisation, giving the network a head-start
toward the generalisation manifold.

  τ    ≈ 3.751 × 10⁻⁴     (Ramsey phase-transition parameter)
  N*   = 1/τ ≈ 2666        (Ramsey complexity threshold)
  Δ*   = 1/√τ ≈ 51.63      (resolution floor, frequency normaliser)
  KT_b ≈ 1.1511            (CLogLog shape, forced by KT universality)
  KT_Kc = 2/π ≈ 0.6366     (Nelson-Kosterlitz critical stiffness)

  
References:
Pinto Martins, C. F. (2026). Ramsey Statistics And Infiniteons Theory, Volume I. Zenodo. https://doi.org/10.5281/zenodo.19329589
Pinto Martins, C. F. (2026). Ramsey Statistics And Infiniteons Theory, Volume II. Zenodo. https://doi.org/10.5281/zenodo.19330373

"""

import math
import torch


PI  = math.pi
PHI = (1 + math.sqrt(5)) / 2

X_VAL  = math.log(PI) / PHI
TAU    = 0.5 * (X_VAL - 1.0 / (2.0 * X_VAL))
N_STAR = 1.0 / TAU
DELTA_STAR = 1.0 / math.sqrt(TAU)


LN_PHI  = math.log(PHI)
LN_PI   = math.log(PI)
ALPHA   = LN_PI / LN_PHI
LN_DIFF = LN_PI - LN_PHI
LN_2PHI = 2.0 * LN_PHI

HARPER_FREQS = (LN_PHI, LN_DIFF, LN_2PHI, LN_PI)

HARPER_XI = (1.0, ALPHA - 1.0, 2.0, ALPHA, 1.0 / ALPHA, 1.0 - 1.0 / ALPHA)

RGS_NULL_MU    = 0.1197
RGS_NULL_SIGMA = 0.0119


BRODY_POISSON      = 0.0
BRODY_GOE          = 1.0
BRODY_SPARSE_GUE   = 1.32
BRODY_GUE_ASYMPTOTE = 1.532

R_POISSON = 0.3863
R_GOE     = 0.5307
R_GUE     = 0.6027

BRODY_SQRT2_CONJECTURE = math.sqrt(2.0)


BRODY_DESCENT_A    = 1.1641
BRODY_DESCENT_B    = 1.4082
LOG10_GAMMA_STAR   = 5.548
GAMMA_STAR         = 10 ** LOG10_GAMMA_STAR
ZERO_INDEX_STAR    = 558391


ZETA_ZEROS = torch.tensor([
    14.134725,  21.022040,  25.010858,  30.424876,  32.935062,
    37.586178,  40.918719,  43.327073,  48.005151,  49.773832,
    52.970321,  56.446248,  59.347044,  60.831779,  65.112544,
    67.079811,  69.546402,  72.067158,  75.704691,  77.144840,
    79.337375,  82.910381,  84.735493,  87.425275,  88.809111,
    92.491899,  94.651344,  95.870634,  98.831194, 101.317851,
   103.725538, 105.446623, 107.168611, 111.029536, 111.874659,
   114.320220, 116.226680, 118.790782, 121.370125, 122.946829,
   124.256818, 127.516683, 129.578704, 131.087688, 133.497737,
   134.756510, 136.143460, 138.116042, 139.736209, 141.123707,
], dtype=torch.float64)

ZETA_WEIGHTS = 1.0 / torch.arange(1, len(ZETA_ZEROS) + 1, dtype=torch.float64)


S2, S3, S4 = 13, 37, 73

ALPHA_L = math.log(S3) / math.log(S4 / S3)

EPS_DRAG = TAU * math.sqrt(2.0)

OMEGA_LPPL = 2.0 * math.pi / math.log(S3 / S2)

ALPHA_STABLE = ALPHA_L / 2.0


GROK_WEIGHT_DECAY  = 0.05
GROK_DATA_FRACTION = 0.25
GROK_SCALING_EXP   = 1.37


def get_zeta_zeros(M: int = 20, device=None, dtype=torch.float32):
    """Return the first M zeta zeros as a tensor on the given device."""
    z = ZETA_ZEROS[:M].to(dtype=dtype)
    if device is not None:
        z = z.to(device)
    return z


def get_zeta_weights(M: int = 20, device=None, dtype=torch.float32):
    """Return harmonic weights 1/k for the first M zeros."""
    w = ZETA_WEIGHTS[:M].to(dtype=dtype)
    if device is not None:
        w = w.to(device)
    return w


BORWEIN_TOP_K = 5
_phi_raw = [PHI ** -k for k in range(2, BORWEIN_TOP_K + 2)]
_phi_sum  = sum(_phi_raw)
BORWEIN_WEIGHTS = torch.tensor(
    [w / _phi_sum for w in _phi_raw[:BORWEIN_TOP_K]], dtype=torch.float32
)


DIGAMMA_C_DEFAULT        = 1.0
DIGAMMA_CONFIDENCE_THRESHOLD = 0.15


FF_MULT_MIN  = 2
FF_MULT_MAX  = 8
N50_BASE     = 10.0


_LN2 = math.log(2.0)
_SQRT_2_OVER_PI = math.sqrt(2.0 / math.pi)

KT_b                    = _SQRT_2_OVER_PI / _LN2
KT_Kc                   = 2.0 / math.pi
KT_c                    = (_LN2 ** 2) / 4.0
KT_C_KT                 = 2.0 * _SQRT_2_OVER_PI / (_LN2 ** 2)

KT_FREE_PHASE_THRESHOLD = 200.0
KT_J2_BUDGET_THRESHOLD  = 100.0

P97_NULL_CONE_THRESHOLD = 0.5


def auto_device() -> torch.device:
    """Auto-detect the best available device (CUDA > CPU)."""
    if torch.cuda.is_available():
        return torch.device("cuda")
    return torch.device("cpu")


def gpu_available() -> bool:
    """Whether CUDA is available."""
    return torch.cuda.is_available()


def device_info() -> dict:
    """Return a dict of device diagnostics."""
    info = {
        "cuda_available": torch.cuda.is_available(),
        "device": str(auto_device()),
        "pytorch_version": torch.__version__,
        "cuda_version": getattr(torch.version, "cuda", None),
    }
    if torch.cuda.is_available():
        info["gpu_name"] = torch.cuda.get_device_name(0)
        props = torch.cuda.get_device_properties(0)
        info["gpu_memory_gb"] = round(props.total_memory / 1e9, 1)
        info["compute_capability"] = f"{props.major}.{props.minor}"
        info["gpu_count"] = torch.cuda.device_count()
    return info
