﻿# Copyright (c) 2026 JCFI LLC  —  All rights reserved.
# U.S. Provisional Patent Application No. 64/013,259  (filed March 22, 2026)
# U.S. Provisional Patent Application No. 64/016,115  (filed March 24, 2026)
# U.S. Provisional Patent Application No. 64/022,599  (filed March 31, 2026)
#
# This file is part of the Thermodynamic Neural Transformer (TNT) library,
# version 1.3 (https://translatestocks.com/tnt).
#
# Licensed under the GNU Affero General Public License v3.0 (AGPLv3).
# You may use, copy, modify, and distribute this software under the
# terms of the AGPLv3.  A complete copy of the license is included in
# the LICENSE file at the root of this repository, and online at:
#     https://www.gnu.org/licenses/agpl-3.0.html
#
# DUAL-LICENSE NOTICE
# -------------------
# Any enterprise or commercial use that would otherwise require
# open-sourcing proprietary modifications or network-served derivatives
# under AGPLv3 §13 may be covered by a separate Commercial License
# issued by JCFI LLC.
# Contact: license@translatestocks.com
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND.
# SEE LICENSE AND NOTICE FOR FULL TERMS.
#
"""Public package initializer for the `TNT-ls` release.

`translatestocks_tnt` is the import path for the public left-side release of
the Thermodynamic Neural Transformer program. In the release framing, TNT is
the umbrella architecture name, while `TNT-ls` denotes the currently public
left-side routing / grokking boundary.

This package exposes the benchmark-validated public layer surface, including
the low-cardinality and post-backbone routing components used in the public
LIB showcase. The complementary right-side thermodynamic crystallization stack
(`TNT-rs`) is not part of this release.

The package version remains `1.3.0`; the matching GitHub release tag for this
public left-side release is `v1.3-ls`.
"""

__version__ = "1.3.0"

from .constants import (
    TAU, N_STAR, DELTA_STAR, PHI, ZETA_ZEROS,
    BORWEIN_WEIGHTS, BORWEIN_TOP_K,
    KT_J2_BUDGET_THRESHOLD, P97_NULL_CONE_THRESHOLD,
    KT_FREE_PHASE_THRESHOLD, DIGAMMA_C_DEFAULT,
    FF_MULT_MIN, FF_MULT_MAX, N50_BASE,
    KT_b, KT_Kc, KT_c, KT_C_KT,
)
from .layers import (
    BorweinAttention,
    BitPlaneEmbedding,
    CLogLogGate,
    DualEmbedding,
    GatedExitNode,
    RSTFFNBlock,
    cloglog,
    KTOrderParameter,
    QuaternionLinear,
    ComplexBlockLinear,
    EllipticLinear,
    CliffordLinear,
    OctonionLinear,
    InfiniteonLinear,
    NullWeightedInfiniteonLinear,
)
