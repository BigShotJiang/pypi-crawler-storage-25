﻿# Copyright (c) 2026 JCFI LLC  —  All rights reserved.
# U.S. Provisional Patent Application No. 64/013,259  (filed March 22, 2026)
# U.S. Provisional Patent Application No. 64/016,115  (filed March 24, 2026)
# U.S. Provisional Patent Application No. 64/022,599  (filed March 31, 2026)
#
# This file is part of the Thermodynamic Neural Transformer (TNT) library,
# version 1.3 (https://translatestocks.com/tnt).
#
# Licensed under the GNU Affero General Public License v3.0 (AGPLv3).
# You may use, copy, modify, and distribute this software under the
# terms of the AGPLv3.  A complete copy of the license is included in
# the LICENSE file at the root of this repository, and online at:
#     https://www.gnu.org/licenses/agpl-3.0.html
#
# DUAL-LICENSE NOTICE
# -------------------
# Any enterprise or commercial use that would otherwise require
# open-sourcing proprietary modifications or network-served derivatives
# under AGPLv3 §13 may be covered by a separate Commercial License
# issued by JCFI LLC.
# Contact: license@translatestocks.com
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND.
# SEE LICENSE AND NOTICE FOR FULL TERMS.
#
"""
translate stocks_tnt.dashboard_app — CLL.1 Real-Time Training Dashboard
(Canonical packaged module.  Run via:  python -m translatestocks_tnt.dashboard_app --csv <path>)
======================================================
Watches a live training CSV and renders five panels that refresh every N seconds:

    Panel 1 (top-left)    Accuracy + CLL.1 fitted curve + early predictor badges
    Panel 2 (top-right)   r̃ order parameter + Goldilocks zone + crossing-ETA projection
    Panel 3 (bottom-left) Hop staircase topology + K5 initiation marker
    Panel 4 (bottom-right) Predictor stack: SVD early score, first-10k trajectory,
                                                 K5 initiation, CLL.1 late confirmation, budget, ETA, staircase summary
    Panel 5 (right column) Training Log: live step prints from the training process

Self-contained: no translatestocks_tnt import required.  All CLL.1 math is inlined.

──────────────────────────────────────────────────────────────────────────────
Quick start
──────────────────────────────────────────────────────────────────────────────
    # Watch a running experiment:
    python -m translatestocks_tnt.dashboard_app --csv results/run.csv

    # With explicit log file (e.g. training stdout redirected to file):
    python -m translatestocks_tnt.dashboard_app --csv results/run.csv --log results/run.log

    # With group-order prediction and hop staircase columns:
    python -m translatestocks_tnt.dashboard_app \\
        --csv results/run.csv \\
        --group-order 120 \\
        --budget 400000 \\
        --hops pfx1_acc,pfx2_acc,pfx3_acc,val_acc \\
        --refresh 5

    # Replay a completed run (instant, no animation):
    python -m translatestocks_tnt.dashboard_app --csv results/run.csv --static

──────────────────────────────────────────────────────────────────────────────
CSV columns (minimum required: step, val_acc)
──────────────────────────────────────────────────────────────────────────────
    step          training step index
    val_acc       validation accuracy  [0..1]
    train_acc     training accuracy    [optional]
    val_loss      validation loss      [optional]
    train_loss    training loss        [optional]
    r_tilde       null-cone order parameter r̃  [optional]
    cll1_r2       pre-logged CLL.1 R²   [optional; dashboard re-fits anyway]
    cll1_step_50  pre-logged N_50       [optional]
    cll1_sigma_w  pre-logged σ_w        [optional]
    <custom>      any prefix-hop columns named via --hops

──────────────────────────────────────────────────────────────────────────────
CLL.1 physics
──────────────────────────────────────────────────────────────────────────────
    F(n) = 1 − 2^{−exp(b·(n−N_50)/σ_w)}
    b    = √(2/π)/ln 2 ≈ 1.1513          (universal constant, RSIT Thm CLL.1)
    Goldilocks: r̃ ∈ [0.0076, 0.0116], center 0.0094

Predictor stack
──────────────────────────────────────────────────────────────────────────────
    Early score 1: SVD-entropy stability over steps 0-5k
    Early score 2: first-10k trajectory model fit against historical grokking runs
    Initiation   : K5 clique-crossing marker (probe if present, independence fallback)
    Late confirm : CLL.1 fit status with sigma_w and R^2
"""

from __future__ import annotations

import argparse
import math
import re
import sys
import time
from datetime import datetime
from pathlib import Path
from typing import Optional

import numpy as np
import pandas as pd
from scipy.optimize import curve_fit

import matplotlib
try:
    matplotlib.use("TkAgg")
except Exception:
    pass
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.lines import Line2D
from matplotlib.gridspec import GridSpec

B_CLL       = math.sqrt(2.0 / math.pi) / math.log(2.0)
GK_CENTER   = 0.0094
GK_UPPER    = 0.0116
GK_LOWER    = 0.0076

LN2         = math.log(2.0)
C_120_5     = 190_578_024

SVD_EARLY_WINDOW      = 5_000
TRAJECTORY_EARLY_STEP = 10_000
SVD_STD_GROK_MEDIAN   = 0.00522
SVD_STD_DNF_MEDIAN    = 0.00623

TRAJECTORY_COMP_FEATURES = [
    "val_acc", "train_loss", "val_loss", "r_tilde", "grad_norm", "weight_norm",
]
TRAJECTORY_SPVAR_FEATURES = [
    "svd_entropy", "r_tilde", "trivial", "sign", "6D", "wed5D", "std4D",
]
TRAJECTORY_CHECKPOINTS = [1000, 3000, 5000, 10000]

C_VALACC    = "#1f77b4"
C_TRAINACC  = "#aaaaaa"
C_FIT       = "#ff7f0e"
C_PROJ      = "#2ca02c"
C_N50_FIT   = "#d62728"
C_RTILDE    = "#1f77b4"
C_GK_BAND   = "#2ca02c"
C_ETA_PROJ  = "#ff7f0e"
HOP_COLORS  = {
    "locked":   "#2ca02c",
    "rising":   "#ff7f0e",
    "arrested": "#d62728",
}


def cll1_curve(n: np.ndarray, N_50: float, sigma_w: float) -> np.ndarray:
    """F(n) = 1 − 2^{−exp(b·(n−N_50)/σ_w)}"""
    Z = (n - N_50) / (max(sigma_w, 1e-8))
    return 1.0 - np.power(2.0, -np.exp(np.clip(B_CLL * Z, -500, 500)))


def fit_cll1(steps: list, vals: list) -> dict:
    """Fit CLL.1 curve; returns {N_50, sigma_w, R2, status}."""
    _nan = float("nan")
    x = np.array(steps, dtype=np.float64)
    y = np.array(vals,  dtype=np.float64)

    if len(x) < 5:
        return {"N_50": _nan, "sigma_w": _nan, "R2": _nan, "status": "insufficient_data"}
    if float(np.max(y)) < 0.10:
        return {"N_50": _nan, "sigma_w": _nan, "R2": _nan, "status": "pre_transition"}

    idx_50 = int(np.abs(y - 0.5).argmin())
    p0 = [float(x[idx_50]), max(float(x[-1]) * 0.1, 1.0)]
    try:
        popt, _ = curve_fit(
            cll1_curve, x, y, p0=p0,
            bounds=([0.0, 1.0], [np.inf, np.inf]), maxfev=3000,
        )
        N_50, sigma_w = float(popt[0]), float(popt[1])
        y_hat  = cll1_curve(x, N_50, sigma_w)
        ss_res = float(np.sum((y - y_hat) ** 2))
        ss_tot = float(np.sum((y - float(np.mean(y))) ** 2))
        R2     = 1.0 - ss_res / (ss_tot + 1e-8)
        status = "waiting" if N_50 > float(x[-1]) else "fitted"
        return {"N_50": N_50, "sigma_w": sigma_w, "R2": float(R2), "status": status}
    except (RuntimeError, ValueError):
        return {"N_50": _nan, "sigma_w": _nan, "R2": _nan, "status": "fit_failed"}


def fit_cll1_tail(
    steps: list,
    vals: list,
    high_thr: float = 0.95,
    min_pts: int = 3,
) -> dict:
    """Asymptotic tail fit for val_acc > high_thr via Gumbel linearisation.

    CLL.1 exact identity: log( -log(1-y) / ln2 ) = B_CLL * (n - N50) / sigma_w
    This triple composition (complement → ln → ln) is **linear in step n**.
    Fitting it locally on the high-accuracy tail anchors the saturation
    trajectory precisely without the global-fit overshoot artefact.

    Returns {a, b, N_50, sigma_w, R2, status}.
    Curve:  y(n) = 1 - 2^{ -exp(a*n + b) }
    """
    _nan = float("nan")
    x = np.array(steps, dtype=np.float64)
    y = np.array(vals,  dtype=np.float64)

    mask = (y > high_thr) & (y < 1.0 - 1e-9)
    if int(mask.sum()) < min_pts:
        return {"status": "insufficient_data", "a": _nan, "b": _nan,
                "N_50": _nan, "sigma_w": _nan, "R2": _nan}

    xm = x[mask]
    ym = y[mask]

    # Gumbel transform: T = log( -log(1-y) / ln2 )
    T = np.log(-np.log(1.0 - ym) / LN2)

    # Linear regression T = a*n + b
    coeffs = np.polyfit(xm, T, 1)
    a, b = float(coeffs[0]), float(coeffs[1])

    if a <= 0:
        return {"status": "not_converging", "a": a, "b": b,
                "N_50": _nan, "sigma_w": _nan, "R2": _nan}

    T_hat = a * xm + b
    ss_res = float(np.sum((T - T_hat) ** 2))
    ss_tot = float(np.sum((T - float(T.mean())) ** 2))
    R2 = 1.0 - ss_res / (ss_tot + 1e-12)

    # Recover N50, sigma_w: B_CLL*(n-N50)/sigma_w = a*n+b  →
    #   a = B_CLL/sigma_w,  b = -B_CLL*N50/sigma_w
    sigma_w_local = B_CLL / a
    N50_local     = -b / a

    return {
        "status": "ok",
        "a": a,
        "b": b,
        "N_50": float(N50_local),
        "sigma_w": float(sigma_w_local),
        "R2": float(R2),
    }



def safe_slope(x: np.ndarray | list, y: np.ndarray | list) -> float:
    """Ordinary least-squares slope with NaN-tolerant guards."""
    if len(x) < 2 or len(y) < 2:
        return 0.0
    x_arr = np.asarray(x, dtype=float)
    y_arr = np.asarray(y, dtype=float)
    mask = np.isfinite(x_arr) & np.isfinite(y_arr)
    x_arr, y_arr = x_arr[mask], y_arr[mask]
    if len(x_arr) < 2:
        return 0.0
    x_centered = x_arr - float(x_arr.mean())
    denom = float(np.dot(x_centered, x_centered))
    if denom <= 0.0:
        return 0.0
    return float(np.dot(x_centered, y_arr) / denom)


def score_band(score: float, high: float = 0.65, low: float = 0.35) -> tuple[str, str]:
    """Map a [0,1] grok score into a dashboard label and colour."""
    if not np.isfinite(score):
        return "N/A", "#666666"
    if score >= high:
        return "GROK-lean", "#2ca02c"
    if score <= low:
        return "DNF-lean", "#d62728"
    return "mixed", "#ff7f0e"


def load_probe_csv(path: Path) -> Optional[pd.DataFrame]:
    """Best-effort loader for optional sidecar probe CSVs."""
    if not path.exists():
        return None
    try:
        df = pd.read_csv(path, low_memory=False)
    except Exception:
        return None
    if "step" in df.columns:
        df["step"] = pd.to_numeric(df["step"], errors="coerce")
        df = df.dropna(subset=["step"])
        df = df.sort_values("step").drop_duplicates("step", keep="last").reset_index(drop=True)
    return df if len(df) > 0 else None


def svd_entropy_signal(
    spvar_df: Optional[pd.DataFrame],
    current_step: int,
    task_name: Optional[str],
) -> dict:
    """Theorem-backed early score from the 0–5k SVD-entropy stability window."""
    base = {
        "status": "unavailable",
        "score": float("nan"),
        "band": "N/A",
        "color": "#666666",
        "std": float("nan"),
        "slope": float("nan"),
        "window_end": 0,
        "n_points": 0,
        "readiness": "none",
        "source": "spvar_probe",
    }
    if not task_name or "s5" not in task_name:
        base["status"] = "unsupported"
        return base
    if spvar_df is None or "svd_entropy" not in spvar_df.columns:
        base["status"] = "missing"
        return base

    window_end = min(int(current_step), SVD_EARLY_WINDOW)
    sub = spvar_df.copy()
    sub["svd_entropy"] = pd.to_numeric(sub["svd_entropy"], errors="coerce")
    sub = sub[(sub["step"] <= window_end) & sub["svd_entropy"].notna()].copy()
    if len(sub) < 4:
        base["status"] = "insufficient_data"
        base["window_end"] = int(window_end)
        base["n_points"] = int(len(sub))
        return base

    std = float(sub["svd_entropy"].std())
    slope = safe_slope(sub["step"].to_numpy(), sub["svd_entropy"].to_numpy())
    d_grok = abs(std - SVD_STD_GROK_MEDIAN)
    d_dnf = abs(std - SVD_STD_DNF_MEDIAN)
    score = float(d_dnf / (d_grok + d_dnf + 1e-12))
    band, color = score_band(score)

    return {
        "status": "ok",
        "score": score,
        "band": band,
        "color": color,
        "std": std,
        "slope": slope,
        "window_end": int(sub["step"].max()),
        "n_points": int(len(sub)),
        "readiness": "full" if int(sub["step"].max()) >= SVD_EARLY_WINDOW else "partial",
        "source": "spvar_probe",
    }


def extract_trajectory_features(
    comp_df: pd.DataFrame,
    spvar_df: Optional[pd.DataFrame],
    n_early: int,
) -> Optional[dict]:
    """Flatten the early trajectory into the same feature family used in A20."""
    comp = comp_df.copy()
    comp["step"] = pd.to_numeric(comp["step"], errors="coerce")
    comp = comp[comp["step"].notna() & (comp["step"] <= n_early)].copy()
    comp = comp.sort_values("step")
    if len(comp) < 4:
        return None

    spvar = pd.DataFrame() if spvar_df is None else spvar_df.copy()
    if len(spvar) > 0 and "step" in spvar.columns:
        spvar["step"] = pd.to_numeric(spvar["step"], errors="coerce")
        spvar = spvar[spvar["step"].notna() & (spvar["step"] <= n_early)].copy()
        spvar = spvar.sort_values("step")

    feats: dict[str, float] = {}
    checkpoints = sorted(set([c for c in TRAJECTORY_CHECKPOINTS if c <= n_early] + [n_early]))

    for col in TRAJECTORY_COMP_FEATURES:
        if col not in comp.columns:
            continue
        sub = comp[["step", col]].copy()
        sub[col] = pd.to_numeric(sub[col], errors="coerce")
        sub = sub.dropna(subset=[col])
        if len(sub) == 0:
            continue
        vals = sub[col].to_numpy(dtype=float)
        steps = sub["step"].to_numpy(dtype=float)
        feats[f"{col}_mean"] = float(np.mean(vals))
        feats[f"{col}_max"] = float(np.max(vals))
        feats[f"{col}_final"] = float(vals[-1])
        feats[f"{col}_slope"] = safe_slope(steps, vals)

        half_mask = steps >= (n_early // 2)
        feats[f"{col}_slope_h2"] = safe_slope(steps[half_mask], vals[half_mask]) if half_mask.sum() >= 2 else 0.0

        for checkpoint in checkpoints:
            idx = int(np.abs(steps - checkpoint).argmin())
            feats[f"{col}_at{checkpoint}"] = float(vals[idx])

    for col in TRAJECTORY_SPVAR_FEATURES:
        prefix = f"sp_{col}"
        if len(spvar) == 0 or col not in spvar.columns:
            feats[f"{prefix}_mean"] = np.nan
            feats[f"{prefix}_max"] = np.nan
            feats[f"{prefix}_final"] = np.nan
            feats[f"{prefix}_slope"] = np.nan
            feats[f"{prefix}_slope_h2"] = np.nan
            continue

        sub = spvar[["step", col]].copy()
        sub[col] = pd.to_numeric(sub[col], errors="coerce")
        sub = sub.dropna(subset=[col])
        if len(sub) == 0:
            feats[f"{prefix}_mean"] = np.nan
            feats[f"{prefix}_max"] = np.nan
            feats[f"{prefix}_final"] = np.nan
            feats[f"{prefix}_slope"] = np.nan
            feats[f"{prefix}_slope_h2"] = np.nan
            continue

        vals = sub[col].to_numpy(dtype=float)
        steps = sub["step"].to_numpy(dtype=float)
        feats[f"{prefix}_mean"] = float(np.mean(vals))
        feats[f"{prefix}_max"] = float(np.max(vals))
        feats[f"{prefix}_final"] = float(vals[-1])
        feats[f"{prefix}_slope"] = safe_slope(steps, vals)

        half_mask = steps >= (n_early // 2)
        feats[f"{prefix}_slope_h2"] = safe_slope(steps[half_mask], vals[half_mask]) if half_mask.sum() >= 2 else 0.0

    if "val_acc" in comp.columns and len(comp) >= 2:
        val_acc = pd.to_numeric(comp["val_acc"], errors="coerce").dropna()
        feats["val_acc_gain"] = float(val_acc.iloc[-1] - val_acc.iloc[0]) if len(val_acc) >= 2 else 0.0
    else:
        feats["val_acc_gain"] = 0.0

    if "r_tilde" in comp.columns:
        half_vals = pd.to_numeric(
            comp.loc[comp["step"] >= n_early // 2, "r_tilde"], errors="coerce"
        ).dropna()
        feats["r_tilde_h2_std"] = float(half_vals.std()) if len(half_vals) > 1 else 0.0
    else:
        feats["r_tilde_h2_std"] = 0.0

    if len(spvar) > 0 and "svd_entropy" in spvar.columns:
        svd_vals = pd.to_numeric(spvar["svd_entropy"], errors="coerce").dropna()
        feats["svd_ent_drop"] = float(svd_vals.iloc[0] - svd_vals.iloc[-1]) if len(svd_vals) >= 2 else 0.0
    else:
        feats["svd_ent_drop"] = 0.0

    return feats


def trajectory_score_from_history(
    results_root: Path,
    current_comp: pd.DataFrame,
    current_spvar: Optional[pd.DataFrame],
    current_step: int,
    task_name: Optional[str],
    model_id: Optional[str],
    k_hops: Optional[int],
    top_k: Optional[int],
    current_seed: Optional[int],
) -> dict:
    """Fit a first-window grok/no-grok classifier from historical run data and score the current run."""
    base = {
        "status": "unavailable",
        "p_grok": float("nan"),
        "dist": float("nan"),
        "band": "N/A",
        "color": "#666666",
        "n_early": min(max(int(current_step), 0), TRAJECTORY_EARLY_STEP),
        "n_train": 0,
        "grok_count": 0,
        "dnf_count": 0,
        "feature_count": 0,
        "loo_acc": float("nan"),
        "source": "historical runs",
    }
    if task_name is None or model_id is None or k_hops is None:
        return base

    n_early = min(max(int(current_step), 0), TRAJECTORY_EARLY_STEP)
    base["n_early"] = n_early
    if n_early < 1_000:
        base["status"] = "insufficient_data"
        return base

    current_feats = extract_trajectory_features(current_comp, current_spvar, n_early=n_early)
    if current_feats is None:
        base["status"] = "insufficient_data"
        return base

    manifest_path = results_root / "run_manifest.csv"
    raw_dir = results_root / "raw"
    if not manifest_path.exists() or not raw_dir.exists():
        return base

    try:
        from sklearn.linear_model import LogisticRegression
        from sklearn.model_selection import LeaveOneOut
        from sklearn.preprocessing import StandardScaler
    except ImportError:
        base["status"] = "sklearn_missing"
        return base

    try:
        manifest = pd.read_csv(manifest_path)
    except Exception:
        return base

    required = {"task", "model_id", "k", "seed", "grokked"}
    if not required.issubset(manifest.columns):
        return base

    manifest = manifest.copy()
    manifest["seed"] = pd.to_numeric(manifest["seed"], errors="coerce")
    manifest["k"] = pd.to_numeric(manifest["k"], errors="coerce")
    if "top_k" in manifest.columns:
        manifest["top_k"] = pd.to_numeric(manifest["top_k"], errors="coerce")
    if "n_steps_run" in manifest.columns:
        manifest["n_steps_run"] = pd.to_numeric(manifest["n_steps_run"], errors="coerce").fillna(0)

    manifest["grokked"] = manifest["grokked"].map(
        lambda value: True if str(value).strip() in ("True", "true", "1") else
        False if str(value).strip() in ("False", "false", "0") else None
    )

    subset = manifest[
        (manifest["task"] == task_name) &
        (manifest["model_id"] == model_id) &
        (manifest["k"] == k_hops)
    ].copy()
    if top_k is not None and "top_k" in subset.columns:
        subset = subset[subset["top_k"] == top_k].copy()
    if current_seed is not None:
        subset = subset[subset["seed"] != current_seed].copy()
    subset = subset[subset["grokked"].isin([True, False])].copy()
    if "n_steps_run" in subset.columns:
        subset = subset.sort_values(["seed", "n_steps_run", "grokked"], ascending=[True, False, False])
    else:
        subset = subset.sort_values(["seed", "grokked"], ascending=[True, False])
    subset = subset.drop_duplicates(subset=["seed"], keep="first")

    feature_rows: list[dict] = []
    labels: list[int] = []
    for _, row in subset.iterrows():
        seed = int(row["seed"])
        row_top_k = int(row["top_k"]) if "top_k" in row and pd.notna(row["top_k"]) else top_k
        if row_top_k is None:
            continue
        comp_path = raw_dir / f"{row['task']}_{row['model_id']}_K{row_top_k}_seed{seed}.csv"
        comp_hist = load_probe_csv(comp_path)
        if comp_hist is None:
            continue
        spvar_hist = load_probe_csv(results_root / f"spvar_probe_{row['task']}_seed{seed}.csv")
        feats = extract_trajectory_features(comp_hist, spvar_hist, n_early=n_early)
        if feats is None:
            continue
        feature_rows.append(feats)
        labels.append(int(bool(row["grokked"])))

    if len(feature_rows) < 6 or len(set(labels)) < 2:
        base["status"] = "insufficient_reference"
        return base

    X_df = pd.DataFrame(feature_rows)
    X_df = X_df.dropna(axis=1, how="all")
    if X_df.empty:
        return base

    medians: dict[str, float] = {}
    for col in X_df.columns:
        med = X_df[col].median()
        fill = 0.0 if pd.isna(med) else float(med)
        X_df[col] = pd.to_numeric(X_df[col], errors="coerce").fillna(fill)
        medians[col] = fill

    X = X_df.to_numpy(dtype=float)
    y = np.array(labels, dtype=int)
    scaler = StandardScaler()
    clf = LogisticRegression(C=0.1, max_iter=2000, class_weight="balanced")

    loo_acc = float("nan")
    if len(y) >= 5:
        loo = LeaveOneOut()
        preds = np.zeros(len(y), dtype=int)
        for train_idx, test_idx in loo.split(X):
            Xtr, Xte = X[train_idx], X[test_idx]
            ytr = y[train_idx]
            scaler.fit(Xtr)
            clf.fit(scaler.transform(Xtr), ytr)
            preds[test_idx] = clf.predict(scaler.transform(Xte))
        loo_acc = float((preds == y).mean())

    scaler.fit(X)
    clf.fit(scaler.transform(X), y)

    current_row = pd.DataFrame([current_feats])
    for col, fill in medians.items():
        if col not in current_row.columns:
            current_row[col] = fill
    current_row = current_row[list(X_df.columns)]
    for col, fill in medians.items():
        current_row[col] = pd.to_numeric(current_row[col], errors="coerce").fillna(fill)

    p_grok = float(clf.predict_proba(scaler.transform(current_row.to_numpy(dtype=float)))[0, 1])
    band, color = score_band(p_grok)
    return {
        "status": "ok",
        "p_grok": p_grok,
        "dist": float(1.0 - p_grok),
        "band": band,
        "color": color,
        "n_early": n_early,
        "n_train": int(len(y)),
        "grok_count": int(y.sum()),
        "dnf_count": int(len(y) - y.sum()),
        "feature_count": int(X_df.shape[1]),
        "loo_acc": loo_acc,
        "source": "historical runs",
    }


def mu5_independence(p_single: float) -> float:
    """Independence approximation for the directed K5 carrier."""
    return C_120_5 * (float(max(p_single, 0.0)) ** 20)


def p_single_at_ln2_threshold() -> float:
    """Critical single-hop accuracy where μ_5 reaches ln 2 under independence."""
    return (LN2 / C_120_5) ** (1.0 / 20.0)


def k5_initiation_marker(
    comp_df: pd.DataFrame,
    k5_df: Optional[pd.DataFrame],
    k_hops: Optional[int],
    task_name: Optional[str],
    current_step: int,
) -> dict:
    """K5 crossing as an initiation marker, with a probe-first and independence fallback path."""
    base = {
        "status": "unavailable",
        "color": "#666666",
        "source": "none",
        "cross_step": None,
        "lag_steps": None,
        "current_ratio": float("nan"),
        "current_mu5": float("nan"),
        "p_single": float("nan"),
        "val_acc_crit": float("nan"),
    }
    if not task_name or "s5" not in task_name or k_hops is None:
        base["status"] = "unsupported"
        return base

    val_acc_crit = float(p_single_at_ln2_threshold() ** max(int(k_hops), 1))
    base["val_acc_crit"] = val_acc_crit

    if k5_df is not None and len(k5_df) > 0:
        probe = k5_df.copy()
        for col in ("ln2_ratio", "mu5_sampled", "mu5_indep", "p_single", "crossed_ln2"):
            if col in probe.columns:
                probe[col] = pd.to_numeric(probe[col], errors="coerce")
        probe = probe.dropna(subset=["step"])
        if len(probe) > 0:
            if "ln2_ratio" not in probe.columns:
                mu_col = "mu5_sampled" if "mu5_sampled" in probe.columns else "mu5_indep"
                probe["ln2_ratio"] = pd.to_numeric(probe.get(mu_col), errors="coerce") / LN2
            crossed_mask = (probe.get("crossed_ln2", 0).fillna(0) >= 1) | (probe["ln2_ratio"] >= 1.0)
            cross_step = int(probe.loc[crossed_mask, "step"].iloc[0]) if crossed_mask.any() else None
            current = probe.iloc[-1]
            current_ratio = float(current["ln2_ratio"]) if np.isfinite(current.get("ln2_ratio", np.nan)) else float("nan")
            current_mu5 = float(current["mu5_sampled"]) if "mu5_sampled" in probe.columns and np.isfinite(current.get("mu5_sampled", np.nan)) else float(current.get("mu5_indep", np.nan))
            p_single = float(current.get("p_single", np.nan))
            status = "initiated" if cross_step is not None else "approaching" if current_ratio >= 0.25 else "pending"
            color = "#2ca02c" if cross_step is not None else "#ff7f0e" if current_ratio >= 0.25 else "#666666"
            return {
                "status": status,
                "color": color,
                "source": "probe",
                "cross_step": cross_step,
                "lag_steps": None if cross_step is None else max(0, int(current_step) - cross_step),
                "current_ratio": current_ratio,
                "current_mu5": current_mu5,
                "p_single": p_single,
                "val_acc_crit": val_acc_crit,
            }

    if "val_acc" not in comp_df.columns:
        return base
    approx = comp_df[["step", "val_acc"]].copy()
    approx["val_acc"] = pd.to_numeric(approx["val_acc"], errors="coerce")
    approx = approx.dropna(subset=["step", "val_acc"])
    if len(approx) < 2:
        base["status"] = "insufficient_data"
        return base

    p_series = np.where(
        approx["val_acc"].to_numpy(dtype=float) > 0.0,
        np.power(np.clip(approx["val_acc"].to_numpy(dtype=float), 0.0, 1.0), 1.0 / max(int(k_hops), 1)),
        0.0,
    )
    mu5_series = C_120_5 * np.power(p_series, 20.0)
    ratio_series = mu5_series / LN2
    crossed_idx = np.flatnonzero(ratio_series >= 1.0)
    cross_step = int(approx["step"].iloc[crossed_idx[0]]) if len(crossed_idx) > 0 else None
    current_ratio = float(ratio_series[-1])
    status = "initiated" if cross_step is not None else "approaching" if current_ratio >= 0.25 else "pending"
    color = "#2ca02c" if cross_step is not None else "#ff7f0e" if current_ratio >= 0.25 else "#666666"
    return {
        "status": status,
        "color": color,
        "source": "indep",
        "cross_step": cross_step,
        "lag_steps": None if cross_step is None else max(0, int(current_step) - cross_step),
        "current_ratio": current_ratio,
        "current_mu5": float(mu5_series[-1]),
        "p_single": float(p_series[-1]),
        "val_acc_crit": val_acc_crit,
    }


def goldilocks(r_tilde: float,
               center: float = GK_CENTER,
               lower: float = GK_LOWER,
               upper: float = GK_UPPER) -> tuple[str, float, str]:
    """Returns (zone, deviation, note).  Zone: ON / UNDER / OVER."""
    if lower <= r_tilde <= upper:
        zone = "ON"
        note = "canonical grok zone"
    elif r_tilde > upper:
        zone = "UNDER"
        note = "under-regularised (↑ wd)"
    else:
        zone = "OVER"
        note = "over-compressed (↓ wd)"
    dev = (r_tilde - center) / (center + 1e-12)
    return zone, dev, note


def r_tilde_plateau(
    r_history: list,
    s_history: list,
    budget: Optional[int],
    window_points: int = 200,
    amp_thr: float = 3e-4,
    min_frac_budget: float = 0.10,
) -> dict:
    """Detect a terminal plateau warning from r̃ history alone."""
    if len(r_history) < window_points or len(s_history) < window_points:
        return {"active": False, "span_steps": 0, "amplitude": float("nan")}

    r_arr = np.array(r_history[-window_points:], dtype=np.float64)
    s_arr = np.array(s_history[-window_points:], dtype=np.int64)
    amplitude = float(np.max(r_arr) - np.min(r_arr))
    span_steps = int(s_arr[-1] - s_arr[0])
    current_step = int(s_arr[-1])
    min_step = int((budget or current_step) * min_frac_budget)
    active = (current_step > min_step) and (amplitude < amp_thr)
    return {
        "active": bool(active),
        "span_steps": span_steps,
        "amplitude": amplitude,
        "current": float(r_arr[-1]),
        "threshold": amp_thr,
    }


def r_tilde_eta(
    r_history: list, s_history: list,
    threshold: float = GK_CENTER,
    window: int = 30, min_pts: int = 8,
    budget: Optional[int] = None,
) -> dict:
    """Power-law r̃ projection with asymptotic floor.

    Fits  log(r̃) = alpha * log(step) + C  (power-law) on the recent window.
    Projects the fit to  step = budget  (or 4× current step) to estimate the
    asymptotic floor.  If floor ≥ threshold the curve is 'arrested'.
    ``proj_coeffs`` is always included in the result (used for drawing).

    Returns status:
        'insufficient_data' | 'not_decaying'
        'arrested'   — floor estimate ≥ threshold
        'already_crossed' — current r̃ ≤ floor (reached asymptote)
        'projected'  — ETA step where power-law crosses threshold
    """
    _nan = float("nan")
    if len(r_history) < min_pts:
        return {"status": "insufficient_data", "eta_step": None, "R2": _nan}

    r_arr = np.array(r_history[-window:], dtype=np.float64)
    s_arr = np.array(s_history[-window:], dtype=np.float64)

    if np.any(r_arr <= 0) or np.any(s_arr <= 0):
        return {"status": "not_decaying", "eta_step": None, "R2": _nan,
                "decay_rate": 0.0}

    # Power-law fit: log(r) = alpha * log(s) + C
    log_r  = np.log(r_arr)
    log_s  = np.log(s_arr)
    coeffs = np.polyfit(log_s, log_r, 1)
    alpha  = float(coeffs[0])          # negative for decaying curve
    C      = float(coeffs[1])

    log_r_hat = np.polyval(coeffs, log_s)
    ss_res = float(np.sum((log_r - log_r_hat) ** 2))
    ss_tot = float(np.sum((log_r - float(log_r.mean())) ** 2))
    R2 = 1.0 - ss_res / (ss_tot + 1e-12)

    # Floor = where the curve reaches at the end of the budget
    s_end = float(budget) if (budget and budget > s_arr[-1]) else float(s_arr[-1]) * 4.0
    floor_est = float(np.exp(C + alpha * math.log(max(s_end, 1.0))))

    base = {
        "R2": float(R2),
        "floor_est": floor_est,
        "proj_s": s_arr,
        "proj_coeffs": coeffs,
        "proj_s_end": s_end,
    }

    if alpha >= 0:
        return {"status": "not_decaying", "eta_step": None,
                "decay_rate": 0.0, **base}

    base["decay_rate"] = float(-alpha)

    cur = float(r_history[-1])

    # Already at or below the projected floor -> asymptote reached
    if cur <= floor_est:
        return {"status": "already_crossed", "eta_step": int(s_history[-1]),
                "steps_remaining": 0, **base}

    # Threshold above current value -> already crossed in a different sense
    if cur <= threshold:
        return {"status": "already_crossed", "eta_step": int(s_history[-1]),
                "steps_remaining": 0, **base}

    # Floor above threshold -> curve asymptotes before ever reaching threshold
    if floor_est >= threshold:
        return {"status": "arrested", "eta_step": None,
                "steps_remaining": None, **base}

    # ETA: solve  threshold = exp(C) * eta^alpha
    try:
        log_eta = (math.log(max(threshold, 1e-30)) - C) / alpha
        if log_eta > 30:   # > ~1e13 steps
            return {"status": "arrested", "eta_step": None,
                    "steps_remaining": None, **base}
        eta = int(round(math.exp(log_eta)))
    except (ValueError, OverflowError):
        return {"status": "arrested", "eta_step": None,
                "steps_remaining": None, **base}

    remaining = max(0, eta - int(s_history[-1]))
    return {
        "status": "projected",
        "eta_step": eta,
        "steps_remaining": remaining,
        **base,
    }


def hop_classify(
    pfx_accs: list,
    prev_accs: Optional[list] = None,
    locked_thr: float = 0.95,
    chance_thr: float = 0.10,
) -> dict:
    """Classify each hop: locked / rising / arrested."""
    hops = []
    for i, acc in enumerate(pfx_accs):
        is_final = (i == len(pfx_accs) - 1)
        if float(acc) >= locked_thr:
            status = "locked"
        elif float(acc) >= chance_thr:
            status = "rising"
        else:
            status = "arrested"
        hops.append({"hop": i + 1, "acc": float(acc), "status": status,
                     "is_final": is_final})
    n_locked = sum(1 for h in hops if h["status"] == "locked")
    n_total  = len(hops)
    final_status = hops[-1]["status"] if hops else "unknown"
    mode = f"{n_locked}/{n_total} locked | {'val' if n_total > 1 else 'task'} {final_status}"
    return {"hops": hops, "n_locked": n_locked, "n_total": n_total,
            "final_status": final_status, "staircase_mode": mode}


def _log_line_color(line: str) -> str:
    """Map a training log line to a terminal-style display colour."""
    if "GROKKED" in line:
        return "#1a7340"
    if "STOP_PHYSICS" in line:
        return "#1558d6"
    if "STOP_DNF" in line or "null-cone trap" in line:
        return "#c0392b"
    if "[CLL.1]" in line and ("N_50=" in line or "R2=" in line):
        return "#1a7340"
    if any(kw in line for kw in ("[CLL.1:waiting]", "[CLL.1:locking]")):
        return "#9a6700"
    if "[CLL.1:locked_wrong]" in line:
        return "#c0392b"
    if "WARN" in line or "PLATEAU" in line:
        return "#9a6700"
    if line.strip().startswith("step="):
        return "#222222"
    if line.strip().startswith("[") and "]" in line:
        return "#0070c0"
    return "#555555"


class CLL1Dashboard:
    """
    Real-time four-panel CLL.1 training monitor.

    Parameters
    ----------
    csv_path    : path to the live training CSV
    group_order : legacy compatibility argument (unused by current predictor stack)
    budget      : total step budget (None → inferred from data)
    hop_cols    : list of CSV column names for hop staircase, last = final task
    refresh     : seconds between data reloads
    r_threshold : r̃ null-cone crossing threshold (default: GK_CENTER)
    title       : optional custom title
    log_path    : explicit path to a training log file; overrides the auto-sidecar
                  convention (<csv_parent>/logs/<stem>.log).  Pass any file that
                  receives the training loop's stdout lines.
    """

    def __init__(
        self,
        csv_path: str | Path,
        group_order: Optional[int] = None,
        budget: Optional[int] = None,
        hop_cols: Optional[list[str]] = None,
        refresh: float = 1.0,
        r_threshold: float = GK_CENTER,
        title: Optional[str] = None,
        log_path: Optional[str | Path] = None,
    ) -> None:
        self.csv_path    = Path(csv_path)
        self.group_order = group_order
        self.budget      = budget
        self.hop_cols    = hop_cols or []
        self.refresh     = refresh
        self.r_threshold = r_threshold
        self._title      = title
        self.log_path    = Path(log_path) if log_path else None

        self.csv_path.parent.mkdir(parents=True, exist_ok=True)

        self._df: Optional[pd.DataFrame] = None
        self._state: dict = {}
        self._frozen_eta_step: Optional[int] = None
        self._min_eta_step: Optional[int] = None
        self._max_eta_step: Optional[int] = None

        self._build_figure()


    def _build_figure(self) -> None:
        plt.rcParams.update({
            "font.family": "monospace",
            "axes.facecolor":  "#f8f9fa",
            "figure.facecolor": "#f0f0f0",
            "axes.grid": True,
            "grid.linestyle": ":",
            "grid.alpha": 0.55,
        })

        self.fig = plt.figure(figsize=(22, 10), dpi=110)
        try:
            mgr = self.fig.canvas.manager
            if mgr is not None:
                mgr.set_window_title("TNT \u2014 CLL.1 Tracker Dashboard")
                try:
                    mgr.window.state("zoomed")
                except Exception:
                    try:
                        mgr.full_screen_toggle()
                    except Exception:
                        pass
        except Exception:
            pass
        gs = GridSpec(
            2, 3,
            figure=self.fig,
            left=0.04, right=0.99,
            top=0.90, bottom=0.07,
            hspace=0.35, wspace=0.28,
            width_ratios=[1, 1, 0.72],
        )
        self.ax_acc    = self.fig.add_subplot(gs[0, 0])
        self.ax_rt     = self.fig.add_subplot(gs[0, 1])
        self.ax_hops   = self.fig.add_subplot(gs[1, 0])
        self.ax_text   = self.fig.add_subplot(gs[1, 1])
        self.ax_log    = self.fig.add_subplot(gs[0:2, 2])

        self._header = self.fig.text(
            0.5, 0.965, "CLL.1 Dashboard — loading…",
            ha="center", va="top",
            fontsize=13, fontweight="bold", color="#222222",
        )

        for ax in (self.ax_acc, self.ax_rt, self.ax_hops):
            ax.set_facecolor("#ffffff")
        self.ax_text.set_facecolor("#f8f9fa")
        self.ax_text.axis("off")
        self.ax_log.set_facecolor("#ffffff")
        self.ax_log.axis("off")


    def _load_data(self) -> Optional[pd.DataFrame]:
        """Load and clean the CSV; return None if unreadable."""
        try:
            df = pd.read_csv(self.csv_path, low_memory=False)
        except FileNotFoundError:
            return None
        except Exception as exc:
            print(f"[dashboard] CSV read error: {exc}", file=sys.stderr)
            return None

        if "step" not in df.columns or "val_acc" not in df.columns:
            print("[dashboard] CSV missing 'step' or 'val_acc' column.", file=sys.stderr)
            return None

        df["step"]    = pd.to_numeric(df["step"],    errors="coerce")
        df["val_acc"] = pd.to_numeric(df["val_acc"], errors="coerce")
        df = df.dropna(subset=["step", "val_acc"])
        df = df.sort_values("step").drop_duplicates("step", keep="last").reset_index(drop=True)
        return df if len(df) > 0 else None

    def _results_root(self) -> Path:
        parent = self.csv_path.parent
        return parent.parent if parent.name.lower() == "raw" else parent

    def _resolve_hop_cols(self, df: pd.DataFrame) -> list[str]:
        """Prefer explicit --hops, else auto-detect pfx*_acc columns."""
        if self.hop_cols:
            return [c for c in self.hop_cols if c in df.columns]

        detected: list[tuple[int, str]] = []
        for col in df.columns:
            m = re.fullmatch(r"pfx(\d+)_acc", str(col))
            if m:
                detected.append((int(m.group(1)), str(col)))
        detected_cols = [col for _, col in sorted(detected)]
        if detected_cols:
            return detected_cols + (["val_acc"] if "val_acc" in df.columns else [])
        return ["val_acc"] if "val_acc" in df.columns else []

    @staticmethod
    def _last_scalar(df: pd.DataFrame, column: str) -> Optional[float]:
        if column not in df.columns:
            return None
        series = pd.to_numeric(df[column], errors="coerce").dropna()
        if len(series) == 0:
            return None
        return float(series.iloc[-1])

    @staticmethod
    def _last_int(df: pd.DataFrame, column: str) -> Optional[int]:
        val = CLL1Dashboard._last_scalar(df, column)
        return None if val is None else int(round(val))

    @staticmethod
    def _last_text(df: pd.DataFrame, column: str) -> Optional[str]:
        if column not in df.columns:
            return None
        series = df[column].dropna()
        if len(series) == 0:
            return None
        return str(series.iloc[-1])


    def _compute_state(self, df: pd.DataFrame) -> dict:
        """Derive all CLL.1 diagnostics from the current dataframe."""
        steps   = df["step"].tolist()
        vals    = df["val_acc"].tolist()
        n_steps = int(steps[-1])
        budget  = self.budget or (n_steps * 2)

        fit = fit_cll1(steps, vals)

        seed = self._last_int(df, "seed")
        task_name = self._last_text(df, "task")
        model_id = self._last_text(df, "model")
        k_hops = self._last_int(df, "k")
        top_k = self._last_int(df, "top_k")
        results_root = self._results_root()

        spvar_df = None
        if seed is not None and task_name:
            spvar_df = load_probe_csv(results_root / f"spvar_probe_{task_name}_seed{seed}.csv")

        k5_df = None
        if seed is not None and task_name and model_id and top_k is not None:
            k5_df = load_probe_csv(results_root / f"k5_probe_{task_name}_{model_id}_K{top_k}_seed{seed}.csv")

        svd_score = svd_entropy_signal(spvar_df, n_steps, task_name)
        trajectory_score = trajectory_score_from_history(
            results_root=results_root,
            current_comp=df,
            current_spvar=spvar_df,
            current_step=n_steps,
            task_name=task_name,
            model_id=model_id,
            k_hops=k_hops,
            top_k=top_k,
            current_seed=seed,
        )
        k5_marker = k5_initiation_marker(df, k5_df, k_hops, task_name, current_step=n_steps)

        log_lines: list[str] = []
        _log_sidecar = (
            self.log_path
            if self.log_path is not None
            else results_root / "logs" / (self.csv_path.stem + ".log")
        )
        if _log_sidecar.exists():
            try:
                with open(_log_sidecar, "r", encoding="utf-8", errors="replace") as _lf:
                    log_lines = _lf.readlines()
            except Exception:
                pass

        r_col = "r_tilde" if "r_tilde" in df.columns else None
        r_history: list[float] = []
        s_history: list[int]   = []
        if r_col:
            r_series = pd.to_numeric(df[r_col], errors="coerce")
            mask = r_series.notna() & (r_series > 0)
            r_history = r_series[mask].tolist()
            s_history = df["step"][mask].astype(int).tolist()

        # Auto-calibrate display threshold: when the curve is already below the
        # GK zone (multi-hop calibration), use the power-law floor projection as
        # the displayed target so the band tracks where r̃ is actually heading.
        # We run a quick fit here; r_tilde_eta below will repeat it with budget.
        effective_threshold = self.r_threshold
        if (self.r_threshold == GK_CENTER
                and len(r_history) >= 4
                and float(r_history[-1]) < GK_LOWER):
            try:
                _win = min(30, len(r_history))
                _r_fit = np.array(r_history[-_win:], dtype=float)
                _s_fit = np.array(s_history[-_win:], dtype=float)
                if np.all(_r_fit > 0) and np.all(_s_fit > 0):
                    _co = np.polyfit(np.log(_s_fit), np.log(_r_fit), 1)
                    _s_end = float(budget) if (budget and budget > _s_fit[-1]) else float(_s_fit[-1]) * 4.0
                    _floor = float(np.exp(np.polyval(_co, math.log(max(_s_end, 1.0)))))
                    if 1e-12 < _floor < GK_LOWER:
                        effective_threshold = _floor
            except Exception:
                pass

        eta = r_tilde_eta(r_history, s_history, threshold=effective_threshold,
                          budget=budget)

        if eta["status"] == "projected" and eta.get("eta_step") is not None:
            _es = eta["eta_step"]
            if self._frozen_eta_step is None:
                self._frozen_eta_step = _es
            if self._min_eta_step is None or _es < self._min_eta_step:
                self._min_eta_step = _es
            if self._max_eta_step is None or _es > self._max_eta_step:
                self._max_eta_step = _es

        gk = None
        if r_history:
            _thr_c = effective_threshold
            _thr_lo = _thr_c * (GK_LOWER / GK_CENTER)
            _thr_hi = _thr_c * (GK_UPPER / GK_CENTER)
            gk = goldilocks(r_history[-1], center=_thr_c,
                            lower=_thr_lo, upper=_thr_hi)

        plateau = r_tilde_plateau(r_history, s_history, budget)

        hop_state = None
        valid_hop_cols = self._resolve_hop_cols(df)
        current_pfx: dict[str, float] = {}
        if valid_hop_cols:
            last_row = df[valid_hop_cols].iloc[-1]
            prev_row = df[valid_hop_cols].iloc[-2] if len(df) >= 2 else None
            pfx_accs  = [pd.to_numeric(last_row[c], errors="coerce") for c in valid_hop_cols]
            prev_accs = (
                [pd.to_numeric(prev_row[c], errors="coerce") for c in valid_hop_cols]
                if prev_row is not None else None
            )
            pfx_accs  = [0.0 if (v is None or (isinstance(v, float) and math.isnan(v))) else v
                         for v in pfx_accs]
            hop_state = hop_classify(pfx_accs, prev_accs)
            current_pfx = {
                c: float(pd.to_numeric(last_row[c], errors="coerce"))
                for c in valid_hop_cols
                if c != "val_acc" and pd.notna(pd.to_numeric(last_row[c], errors="coerce"))
            }

        train_acc = None
        if "train_acc" in df.columns:
            ta = pd.to_numeric(df["train_acc"], errors="coerce").dropna()
            if len(ta) > 0:
                train_acc = ta.tolist()

        cur_train_loss = self._last_scalar(df, "train_loss")
        cur_val_loss = self._last_scalar(df, "val_loss")
        cur_wall_time = self._last_scalar(df, "wall_time_sec")
        cur_plateau_flag = self._last_int(df, "warn_rtilde_plateau")

        return {
            "steps":      steps,
            "vals":       vals,
            "n_steps":    n_steps,
            "budget":     budget,
            "fit":        fit,
            "seed":       seed,
            "task_name":  task_name,
            "model_id":   model_id,
            "k_hops":     k_hops,
            "top_k":      top_k,
            "svd_score":  svd_score,
            "trajectory_score": trajectory_score,
            "k5_marker":  k5_marker,
            "r_history":  r_history,
            "s_history":  s_history,
            "eta":        eta,
            "frozen_eta_step": self._frozen_eta_step,
            "min_eta_step":    self._min_eta_step,
            "max_eta_step":    self._max_eta_step,
            "gk":         gk,
            "plateau":    plateau,
            "hop_state":  hop_state,
            "hop_cols":   valid_hop_cols,
            "hop_series": {c: pd.to_numeric(df[c], errors="coerce").tolist()
                           for c in valid_hop_cols} if valid_hop_cols else {},
            "train_acc":  train_acc,
            "cur_train_loss": cur_train_loss,
            "cur_val_loss": cur_val_loss,
            "cur_wall_time": cur_wall_time,
            "cur_pfx":       current_pfx,
            "cur_plateau_flag": cur_plateau_flag,
            "df_steps":            steps,
            "log_lines":           log_lines,
            "effective_threshold": effective_threshold,
        }


    def _draw_acc(self, s: dict) -> None:
        ax = self.ax_acc
        ax.clear()
        ax.set_facecolor("#ffffff")

        steps = np.array(s["steps"])
        vals  = np.array(s["vals"])
        fit   = s["fit"]
        n_steps = s["n_steps"]

        x_max = n_steps
        if fit["status"] in ("fitted", "locking") and not math.isnan(fit["N_50"]):
            proj_end = max(n_steps, fit["N_50"] + 3.5 * max(fit["sigma_w"], 1.0))
            x_max = proj_end

        if s["train_acc"] is not None:
            t_steps = steps[:len(s["train_acc"])]
            ax.plot(t_steps, s["train_acc"][:len(t_steps)],
                    color=C_TRAINACC, linewidth=0.8, alpha=0.45, label="train_acc")

        ax.plot(steps, vals, color=C_VALACC, linewidth=2.0, label="val_acc", zorder=5)

        # Grokking probability zone from r̃ ETA range
        _min_eta = s.get("min_eta_step")
        _max_eta = s.get("max_eta_step")
        if _min_eta is not None and _max_eta is not None and _min_eta != _max_eta:
            ax.axvspan(_min_eta, _max_eta, color="#ff7f0e", alpha=0.07, zorder=2)

        if fit["status"] in ("fitted", "locking", "waiting") and not math.isnan(fit["N_50"]):
            N50   = fit["N_50"]
            sigma = fit["sigma_w"]
            R2    = fit["R2"]

            # ---------- Gumbel fit: cascade from tight to wide ---------------
            # T = log(-log(1-y)/ln2) is LINEAR in step n for CLL.1.
            # Fitting locally on observed data anchors slope to actual dynamics.
            # Try progressively wider windows so the projection is active as
            # early as the first few grokking points (val_acc > 0.10).
            tail = fit_cll1_tail(steps.tolist(), vals.tolist(), high_thr=0.95)
            if tail["status"] != "ok":
                tail = fit_cll1_tail(steps.tolist(), vals.tolist(), high_thr=0.40)
            if tail["status"] != "ok":
                tail = fit_cll1_tail(steps.tolist(), vals.tolist(),
                                     high_thr=0.10, min_pts=2)
            has_tail = (tail["status"] == "ok")

            # Global CLL.1 dashed fit: draw up to the last observed data point.
            # The Gumbel projection takes over from there.
            x_fit = np.linspace(float(steps[0]), float(n_steps), 400)
            y_fit = cll1_curve(x_fit, N50, sigma)
            ax.plot(x_fit, y_fit, color=C_FIT, linewidth=1.5,
                    linestyle="--", alpha=0.75, label=f"CLL.1 fit  R²={R2:.3f}", zorder=4)

            # Gumbel-anchored projection from current step forward.
            # Uses locally fitted a,b so it tracks the actual observed slope.
            # Fallback to global-fit params only when no rising data at all.
            if has_tail:
                ta, tb = tail["a"], tail["b"]
            else:
                ta = B_CLL / max(sigma, 1e-8)
                tb = -ta * N50

            # Draw the Gumbel continuation from last data point to x_max
            x_gumbel_hist = np.linspace(float(n_steps) * 0.97, float(n_steps), 20)
            x_gumbel_proj = np.linspace(float(n_steps), float(x_max), 400)
            x_gumbel_full = np.concatenate([x_gumbel_hist, x_gumbel_proj])
            y_gumbel_full = 1.0 - np.power(
                2.0, -np.exp(np.clip(ta * x_gumbel_full + tb, -500, 500))
            )
            # past portion (overlap with data, thin dashed, shows where Gumbel sits)
            ax.plot(x_gumbel_hist, y_gumbel_full[:len(x_gumbel_hist)],
                    color=C_FIT, linewidth=1.0, linestyle=":", alpha=0.50, zorder=4)
            # projection arm past current step
            if R2 > 0.5 or fit["status"] == "waiting":
                y_proj_tail = y_gumbel_full[len(x_gumbel_hist):]
                ax.plot(x_gumbel_proj, y_proj_tail, color=C_PROJ, linewidth=2.2,
                        linestyle="-", alpha=0.90, label="avalanche →", zorder=6)
                ax.fill_between(x_gumbel_proj, 0, y_proj_tail,
                                color=C_PROJ, alpha=0.07, zorder=3)
                ax.axvspan(float(n_steps), float(x_max),
                           color="#e8f4e8", alpha=0.35, zorder=1)

            ax.axvline(N50, color=C_N50_FIT, linewidth=1.2, linestyle=":",
                       alpha=0.80, label=f"N₅₀={N50:,.0f} (fit)")
            ax.text(N50, 0.52, f"N₅₀\n{N50:,.0f}", fontsize=7.5, color=C_N50_FIT,
                    ha="center", va="bottom", zorder=10)

        traj = s.get("trajectory_score", {})
        svd = s.get("svd_score", {})
        badge_lines = ["Early stack"]
        badge_color = "#666666"
        if traj.get("status") == "ok":
            badge_lines.append(f"Q10k  : {traj['p_grok']:.2f}  [{traj['band']}]")
            badge_color = traj.get("color", badge_color)
        elif traj.get("status") == "insufficient_reference":
            badge_lines.append("Q10k  : reference set too small")
        elif traj.get("status") == "insufficient_data":
            badge_lines.append(f"Q10k  : waiting ({traj.get('n_early', 0):,} steps)")
        elif traj.get("status") == "sklearn_missing":
            badge_lines.append("Q10k  : scikit-learn missing")
        else:
            badge_lines.append("Q10k  : unavailable")

        if svd.get("status") == "ok":
            badge_lines.append(f"SVD   : {svd['score']:.2f}  [{svd['band']}]")
            if badge_color == "#666666":
                badge_color = svd.get("color", badge_color)
        elif svd.get("status") == "missing":
            badge_lines.append("SVD   : probe missing")
        elif svd.get("status") == "insufficient_data":
            badge_lines.append(f"SVD   : waiting ({svd.get('n_points', 0)} pts)")
        elif svd.get("status") == "unsupported":
            badge_lines.append("SVD   : unsupported")
        else:
            badge_lines.append("SVD   : unavailable")

        ax.text(
            0.98, 0.96,
            "\n".join(badge_lines),
            transform=ax.transAxes, fontsize=8.2,
            ha="right", va="top", color=badge_color, fontweight="bold",
            bbox=dict(boxstyle="round,pad=0.3", fc="white",
                      ec=badge_color, alpha=0.92, lw=1.2),
        )

        ax.axhline(0.50, color="#555555", linewidth=0.7, linestyle=":", alpha=0.5)
        ax.axhline(0.99, color="#555555", linewidth=0.7, linestyle=":", alpha=0.5)
        ax.text(float(steps[0]) if len(steps) else 0, 0.505,
                "50%", fontsize=7, color="#666666", va="bottom")
        ax.text(float(steps[0]) if len(steps) else 0, 0.995,
                "99%", fontsize=7, color="#666666", va="bottom")

        ax.axvline(n_steps, color="#888888", linewidth=0.8, linestyle="-", alpha=0.5)

        ax.set_xlim(0, float(x_max) * 1.05)
        ax.set_ylim(-0.02, 1.08)
        ax.set_xlabel("Training step", fontsize=9)
        ax.set_ylabel("Accuracy", fontsize=9)
        status = fit["status"]
        ax.set_title(
            f"Accuracy + CLL.1 Avalanche  [{status}]",
            fontsize=10, fontweight="bold",
        )
        ax.legend(loc="upper left", fontsize=7.5, framealpha=0.85, ncol=2)


    def _draw_rtilde(self, s: dict) -> None:
        ax = self.ax_rt
        ax.clear()
        ax.set_facecolor("#ffffff")

        r_hist = s["r_history"]
        s_hist = s["s_history"]
        eta     = s["eta"]
        gk      = s["gk"]
        plateau = s["plateau"]

        if not r_hist:
            ax.set_title("r̃ Order Parameter  [no data]", fontsize=10, fontweight="bold")
            ax.text(0.5, 0.5, "r̃ column not found in CSV\nor all values are zero.",
                    ha="center", va="center", fontsize=10, color="#888888",
                    transform=ax.transAxes)
            return

        r_arr = np.array(r_hist)
        s_arr = np.array(s_hist)

        s_min, s_max = float(s_arr[0]), float(s_arr[-1])
        _proj_s_end = float(eta.get("proj_s_end", s_max * 4.0))
        frozen_eta = s.get("frozen_eta_step")
        min_eta    = s.get("min_eta_step")
        max_eta    = s.get("max_eta_step")
        _any_eta   = max_eta or frozen_eta
        if _any_eta is not None:
            s_max_plot = max(s_max, _any_eta * 1.30)
        elif eta["status"] == "projected" and eta["eta_step"] is not None:
            s_max_plot = max(s_max, eta["eta_step"] * 1.30)
        elif "proj_s_end" in eta:
            s_max_plot = _proj_s_end * 1.05
        else:
            s_max_plot = s_max * 1.10

        _thr     = s.get("effective_threshold", self.r_threshold)
        _thr_hi  = _thr * (GK_UPPER / GK_CENTER)
        _thr_lo  = _thr * (GK_LOWER / GK_CENTER)
        _auto    = (self.r_threshold == GK_CENTER and _thr != GK_CENTER)
        _thr_lbl = f"target r̃={_thr:.5f} (auto)" if _auto else f"target r̃={_thr:.5f}"
        ax.axhspan(_thr_lo, _thr_hi, color=C_GK_BAND, alpha=0.10, zorder=1)
        ax.axhline(_thr, color=C_GK_BAND, linewidth=1.0,
                   linestyle="--", alpha=0.60, label=_thr_lbl)
        ax.axhline(_thr_hi, color=C_GK_BAND, linewidth=0.7,
                   linestyle=":", alpha=0.45)
        ax.axhline(_thr_lo, color=C_GK_BAND, linewidth=0.7,
                   linestyle=":", alpha=0.45)

        ax.plot(s_arr, r_arr, color=C_RTILDE, linewidth=1.8, zorder=5, label="r̃ observed")

        # Draw power-law projection whenever fit coefficients are available
        if "proj_coeffs" in eta:
            s_ext = np.linspace(float(s_arr[-1]), _proj_s_end * 1.02, 300)
            s_ext = np.maximum(s_ext, 1.0)
            r_ext = np.exp(np.polyval(eta["proj_coeffs"], np.log(s_ext)))
            ax.plot(s_ext, r_ext, color=C_ETA_PROJ, linewidth=1.5,
                    linestyle="--", alpha=0.80, label="decay fit →", zorder=6)

        # Asymptotic floor line
        _floor = eta.get("floor_est", float("nan"))
        if math.isfinite(_floor) and _floor > 1e-12:
            ax.axhline(_floor, color=C_ETA_PROJ, linewidth=0.9,
                       linestyle=":", alpha=0.65, zorder=3)
            ax.text(s_max_plot * 0.02, _floor,
                    f"floor≈{_floor:.5f}",
                    fontsize=7, color=C_ETA_PROJ, va="bottom", ha="left",
                    clip_on=True)

        if frozen_eta is not None or (eta["status"] == "projected" and "proj_coeffs" in eta):
            _thr_ann = s.get("effective_threshold", self.r_threshold)
            _eta_x = frozen_eta if frozen_eta is not None else eta["eta_step"]

            # Shaded range between min and max predictions
            if min_eta is not None and max_eta is not None and min_eta != max_eta:
                ax.axvspan(min_eta, max_eta, color="#ff7f0e", alpha=0.07, zorder=2)

            # min line
            if min_eta is not None and min_eta != _eta_x:
                ax.axvline(min_eta, color=C_ETA_PROJ, linewidth=0.8,
                           linestyle=":", alpha=0.45)
                ax.text(min_eta, _thr_ann * 3.5,
                        f" {min_eta:,}", fontsize=6.5, color=C_ETA_PROJ,
                        va="top", ha="left", clip_on=True)

            # max line
            if max_eta is not None and max_eta != _eta_x:
                ax.axvline(max_eta, color=C_ETA_PROJ, linewidth=0.8,
                           linestyle=":", alpha=0.45)
                ax.text(max_eta, _thr_ann * 3.5,
                        f" {max_eta:,}", fontsize=6.5, color=C_ETA_PROJ,
                        va="top", ha="left", clip_on=True)

            # frozen attractor line (first prediction) — solid
            ax.axvline(_eta_x, color=C_ETA_PROJ, linewidth=1.0,
                       linestyle=":", alpha=0.70)
            ax.annotate(
                f"ETA\n{_eta_x:,}",
                xy=(_eta_x, _thr_ann),
                xytext=(_eta_x, _thr_ann * 1.6),
                fontsize=7.5, color=C_ETA_PROJ, ha="center",
                arrowprops=dict(arrowstyle="->", color=C_ETA_PROJ, lw=1.0),
            )
        elif eta["status"] == "arrested" and math.isfinite(_floor):
            ax.text(
                0.97, 0.12,
                f"no crossing predicted\nfloor ≈ {_floor:.5f}",
                transform=ax.transAxes, fontsize=8,
                ha="right", va="bottom", color=C_ETA_PROJ, fontweight="bold",
                bbox=dict(boxstyle="round,pad=0.3", fc="white",
                          ec=C_ETA_PROJ, alpha=0.90, lw=1.0),
            )

        ax.scatter([s_arr[-1]], [r_arr[-1]], color=C_RTILDE, s=35, zorder=8)

        if gk is not None:
            zone, dev, note = gk
            zone_color = {"ON": "#2ca02c", "UNDER": "#ff7f0e", "OVER": "#d62728"}[zone]
            ax.text(0.98, 0.96,
                    f"Zone: {zone}  ({dev:+.1%})",
                    transform=ax.transAxes, fontsize=8.5,
                    ha="right", va="top", color=zone_color, fontweight="bold",
                    bbox=dict(boxstyle="round,pad=0.3", fc="white",
                              ec=zone_color, alpha=0.90, lw=1.2))

        if plateau.get("active"):
            ax.text(
                0.02, 0.96,
                f"WARN_RTilde_PLATEAU\nflat for {plateau['span_steps']:,} steps",
                transform=ax.transAxes, fontsize=8,
                ha="left", va="top", color="#b22222", fontweight="bold",
                bbox=dict(boxstyle="round,pad=0.3", fc="#fff3f3",
                          ec="#b22222", alpha=0.95, lw=1.1),
            )

        ax.set_xlim(0, s_max_plot)
        _thr_hi_ylim = s.get("effective_threshold", self.r_threshold) * (GK_UPPER / GK_CENTER)
        r_upper = max(float(np.max(r_arr)) * 1.25, _thr_hi_ylim * 1.5)
        ax.set_ylim(0, r_upper)
        ax.set_xlabel("Training step", fontsize=9)
        ax.set_ylabel("r̃", fontsize=9)
        ax.set_title("r̃ Order Parameter — Goldilocks + ETA",
                     fontsize=10, fontweight="bold")
        ax.legend(loc="center right", fontsize=7.5, framealpha=0.85)


    def _draw_hops(self, s: dict) -> None:
        ax = self.ax_hops
        ax.clear()
        ax.set_facecolor("#ffffff")

        steps     = np.array(s["steps"])
        hop_series = s["hop_series"]
        hop_state  = s["hop_state"]
        hop_cols   = s["hop_cols"]

        if not hop_cols:
            ax.plot(steps, s["vals"], color=C_VALACC, linewidth=2.0, label="val_acc")
            ax.set_title("Hop Staircase  [no hop columns]",
                         fontsize=10, fontweight="bold")
            ax.set_ylim(-0.02, 1.08)
            ax.set_xlabel("Training step", fontsize=9)
            ax.set_ylabel("Accuracy", fontsize=9)
            return

        hop_info = hop_state["hops"] if hop_state else []
        status_map = {h["hop"] - 1: h["status"] for h in hop_info}

        for i, col in enumerate(hop_cols):
            series = pd.to_numeric(pd.Series(hop_series[col]), errors="coerce")
            status = status_map.get(i, "arrested")
            color  = HOP_COLORS.get(status, "#888888")

            if col == "val_acc" or i == len(hop_cols) - 1:
                label_name = "val (final)"
            else:
                label_name = f"hop {i+1} ({col})"

            lw = 2.2 if i == len(hop_cols) - 1 else 1.6
            ax.plot(steps, series.tolist(), color=color, linewidth=lw,
                    alpha=0.85, label=f"{label_name}  [{status}]")

        ax.axhline(0.95, color="#2ca02c", linewidth=0.7, linestyle="--",
                   alpha=0.45, label="locked threshold")

        # Grokking probability zone from r̃ ETA range
        _min_eta = s.get("min_eta_step")
        _max_eta = s.get("max_eta_step")
        if _min_eta is not None and _max_eta is not None and _min_eta != _max_eta:
            ax.axvspan(_min_eta, _max_eta, color="#ff7f0e", alpha=0.07, zorder=2)

        mode_str = hop_state["staircase_mode"] if hop_state else "N/A"
        ax.text(0.98, 0.04, mode_str,
                transform=ax.transAxes, fontsize=9,
                ha="right", va="bottom", fontweight="bold",
                bbox=dict(boxstyle="round,pad=0.35", fc="white",
                          ec="#444444", alpha=0.90, lw=1.0))

        k5 = s.get("k5_marker", {})
        if k5.get("status") not in (None, "unavailable", "unsupported"):
            k5_lines = []
            if k5.get("status") == "initiated":
                k5_lines.append(f"K5 initiated @ {k5['cross_step']:,}")
            else:
                k5_lines.append(f"K5 {k5.get('status', 'pending')}")
            if np.isfinite(k5.get("current_ratio", float("nan"))):
                k5_lines.append(f"ln2×={k5['current_ratio']:.2f}  [{k5.get('source', 'n/a')}]")
            ax.text(
                0.98, 0.96,
                "\n".join(k5_lines),
                transform=ax.transAxes, fontsize=8.2,
                ha="right", va="top", color=k5.get("color", "#666666"), fontweight="bold",
                bbox=dict(boxstyle="round,pad=0.30", fc="white",
                          ec=k5.get("color", "#666666"), alpha=0.92, lw=1.1),
            )

        ax.set_ylim(-0.02, 1.08)
        ax.set_xlabel("Training step", fontsize=9)
        ax.set_ylabel("Accuracy", fontsize=9)
        ax.set_title("Hop Staircase Topology", fontsize=10, fontweight="bold")
        ax.legend(loc="upper left", fontsize=7.5, framealpha=0.85)


    def _draw_text(self, s: dict) -> None:
        ax = self.ax_text
        ax.clear()
        ax.axis("off")

        fit      = s["fit"]
        gk       = s["gk"]
        eta      = s["eta"]
        hop      = s["hop_state"]
        plateau  = s["plateau"]
        n_steps  = s["n_steps"]
        budget   = s["budget"]
        pct      = 100.0 * n_steps / max(budget, 1)
        svd      = s.get("svd_score", {})
        traj     = s.get("trajectory_score", {})
        k5       = s.get("k5_marker", {})

        cur_val = float(s["vals"][-1]) if s["vals"] else float("nan")
        cur_train = (float(s["train_acc"][-1]) if s["train_acc"] else None)
        cur_train_loss = s.get("cur_train_loss")
        cur_val_loss = s.get("cur_val_loss")
        cur_wall_time = s.get("cur_wall_time")
        cur_pfx = s.get("cur_pfx", {})
        cur_r = float(s["r_history"][-1]) if s["r_history"] else None

        bar_len = 20
        filled  = int(bar_len * pct / 100)
        prog_bar = "█" * filled + "░" * (bar_len - filled)

        lines = []

        lines.append(f"{'─'*34}")
        lines.append(f"  Step  {n_steps:>8,}  /  {budget:>8,}")
        lines.append(f"  [{prog_bar}]  {pct:.1f}%")
        metric_parts = []
        if cur_train_loss is not None:
            metric_parts.append(f"loss={cur_train_loss:.4f}")
        if cur_train is not None:
            metric_parts.append(f"tr={cur_train:.3f}")
        metric_parts.append(f"val={cur_val:.3f}")
        if cur_r is not None:
            metric_parts.append(f"r~={cur_r:.4f}")
        lines.append("  " + "  ".join(metric_parts))
        if cur_val_loss is not None:
            lines.append(f"  val_loss={cur_val_loss:.4f}")
        if cur_pfx:
            pfx_parts = [f"{col.replace('_acc', '')}={val:.3f}" for col, val in cur_pfx.items()]
            lines.append("  " + "  ".join(pfx_parts))
        if cur_wall_time is not None:
            lines.append(f"  wall   : {cur_wall_time:,.0f}s")

        lines.append(f"")
        lines.append(f"{'─'*34}")
        lines.append(f"  Predictor Stack")

        lines.append(f"  SVD 0-5k")
        if svd.get("status") == "ok":
            lines.append(f"  score  : {svd['score']:.3f}  [{svd['band']}]")
            lines.append(f"  std    : {svd['std']:.5f}  slope={svd['slope']:.2e}")
            lines.append(f"  window : 0-{svd['window_end']:,}  ({svd['readiness']})")
        elif svd.get("status") == "missing":
            lines.append(f"  status : probe missing")
        elif svd.get("status") == "insufficient_data":
            lines.append(f"  status : waiting ({svd.get('n_points', 0)} points)")
        else:
            lines.append(f"  status : {svd.get('status', 'unavailable')}")

        lines.append(f"  Trajectory 0-10k")
        if traj.get("status") == "ok":
            lines.append(f"  P(grok): {traj['p_grok']:.3f}  [{traj['band']}]")
            lines.append(f"  dist   : {traj['dist']:.3f}")
            lines.append(f"  ref    : n={traj['n_train']}  LOO={traj['loo_acc']:.3f}  d={traj['feature_count']}")
            lines.append(f"  window : 0-{traj['n_early']:,}  ({'full' if traj['n_early'] >= TRAJECTORY_EARLY_STEP else 'partial'})")
        elif traj.get("status") == "insufficient_reference":
            lines.append(f"  status : reference set too small")
        elif traj.get("status") == "insufficient_data":
            lines.append(f"  status : waiting ({traj.get('n_early', 0):,} steps)")
        elif traj.get("status") == "sklearn_missing":
            lines.append(f"  status : scikit-learn missing")
        else:
            lines.append(f"  status : {traj.get('status', 'unavailable')}")

        lines.append(f"  K5 initiation")
        if k5.get("status") in ("initiated", "approaching", "pending"):
            lines.append(f"  status : {k5['status']}  [{k5['source']}]")
            if k5.get("cross_step") is not None:
                lines.append(f"  τ_K5   : {k5['cross_step']:>10,}")
            else:
                lines.append(f"  τ_K5   : {'—':>10}")
            lines.append(f"  ln2×   : {k5['current_ratio']:.3f}  p1={k5['p_single']:.3f}")
            lines.append(f"  val*   : {k5['val_acc_crit']:.3f}")
        else:
            lines.append(f"  status : {k5.get('status', 'unavailable')}")

        lines.append(f"  CLL.1 late")
        lines.append(f"  status : {fit['status']}")
        if not math.isnan(fit.get("N_50", float("nan"))):
            lines.append(f"  N₅₀    : {fit['N_50']:>10,.0f}")
            lines.append(f"  σ_w    : {fit['sigma_w']:>10,.0f}  R²={fit['R2']:.4f}")
        else:
            lines.append(f"  N₅₀    : {'—':>10}")
            lines.append(f"  σ_w/R² : {'—':>10}")

        lines.append(f"")
        lines.append(f"{'─'*34}")
        lines.append(f"  r̃ Order Parameter")
        if s["r_history"]:
            cur_r = float(s["r_history"][-1])
            lines.append(f"  Current: {cur_r:.6f}")
            if gk:
                zone, dev, note = gk
                sign = "+" if dev >= 0 else ""
                lines.append(f"  Zone   : {zone}  ({sign}{dev:.1%})")
                lines.append(f"           {note}")
            if eta["status"] == "projected":
                rem = eta.get("steps_remaining", 0)
                lines.append(f"  ETA    : {eta['eta_step']:>8,}  ({rem:+,} steps)")
                lines.append(f"  λ/step : {eta.get('decay_rate', 0.0):.2e}")
                lines.append(f"  η R²   : {eta['R2']:.4f}")
            elif eta["status"] == "already_crossed":
                lines.append(f"  Status : CROSSED (at {eta['eta_step']:,})")
            elif eta["status"] == "not_decaying":
                lines.append(f"  Status : not decaying")
            else:
                lines.append(f"  Status : {eta['status']}")
            if plateau.get("active") or s.get("cur_plateau_flag"):
                lines.append(f"  WARN   : flat for {plateau['span_steps']:,} steps")
                lines.append(f"           Δr~={plateau['amplitude']:.2e}  null-cone trap?")
        else:
            lines.append(f"  (r̃ not available)")

        lines.append(f"")
        lines.append(f"{'─'*34}")
        lines.append(f"  Staircase")
        if hop:
            lines.append(f"  {hop['staircase_mode']}")
            for h in hop["hops"]:
                bar_w = int(h["acc"] * 18)
                bar = "█" * bar_w + "░" * (18 - bar_w)
                tag = "←val" if h["is_final"] else f"hop{h['hop']}"
                lines.append(
                    f"  {tag:>4}  [{bar}]  "
                    f"{h['acc']:.3f}  [{h['status'][:4]}]"
                )
        else:
            lines.append(f"  (single-task mode)")

        lines.append(f"")
        lines.append(f"{'─'*34}")
        lines.append(f"  Updated {datetime.now().strftime('%H:%M:%S')}")

        text_str = "\n".join(lines)
        ax.text(
            0.03, 0.98, text_str,
            transform=ax.transAxes,
            fontsize=8.5, va="top", ha="left",
            family="monospace",
            bbox=dict(boxstyle="round,pad=0.5", fc="#ffffff",
                      ec="#cccccc", alpha=0.95, lw=1.0),
        )


    def _draw_log(self, log_lines: list[str]) -> None:
        """Render the last 30 lines of the training log as a colored terminal panel."""
        ax = self.ax_log
        ax.clear()
        ax.axis("off")
        ax.set_facecolor("#ffffff")

        ax.axhspan(0.995, 1.0, xmin=0, xmax=1, color="#dddddd", zorder=0)

        ax.set_title("Training Log", fontsize=10, fontweight="bold",
                     pad=5, color="#222222")

        FONT_SIZE = 9.5
        WRAP_AT   = 78
        SLOT_CAP  = 30

        if not log_lines:
            ax.text(0.5, 0.52, "waiting for training output…",
                    ha="center", va="center", transform=ax.transAxes,
                    fontsize=9, color="#aaaaaa", family="monospace")
            return

        display_rows: list[tuple[str, str, bool]] = []
        for raw in log_lines:
            text   = raw.rstrip("\n\r")
            color  = _log_line_color(text)
            is_key = any(kw in text for kw in
                         ("GROKKED", "STOP_PHYSICS", "STOP_DNF"))
            if len(text) <= WRAP_AT:
                display_rows.append((text, color, is_key))
            else:
                first = True
                while text:
                    chunk = text[:WRAP_AT]
                    text  = text[WRAP_AT:]
                    prefix = "" if first else "  "
                    display_rows.append((prefix + chunk, color, is_key and first))
                    first = False

        rows   = display_rows[-SLOT_CAP:]
        n_rows = len(rows)
        line_h = 1.0 / max(n_rows, SLOT_CAP)

        for i, (text, color, is_key) in enumerate(rows):
            y = 1.0 - (i + 0.6) * line_h
            ax.text(
                0.015, y, text,
                transform=ax.transAxes,
                fontsize=FONT_SIZE, va="center", ha="left",
                family="monospace",
                color=color,
                fontweight="bold" if is_key else "normal",
                clip_on=True,
            )
            if is_key:
                ax.axhspan(
                    y - line_h * 0.48, y + line_h * 0.48,
                    xmin=0, xmax=1,
                    color=color, alpha=0.07,
                    transform=ax.transAxes,
                    clip_on=True,
                )


    def _update_header(self, s: dict) -> None:
        df = self._df
        task_str  = df["task"].iloc[0]  if df is not None and "task"  in df.columns else "?"
        model_str = df["model"].iloc[0] if df is not None and "model" in df.columns else "?"
        seed_str  = df["seed"].iloc[0]  if df is not None and "seed"  in df.columns else "?"
        k_str     = df["k"].iloc[0]     if df is not None and "k"     in df.columns else "?"

        title = self._title or f"task={task_str}  model={model_str}  seed={seed_str}  k={k_str}"
        pct = 100.0 * s["n_steps"] / max(s["budget"], 1)
        self._header.set_text(
            f"CLL.1 Dashboard  —  {title}\n"
            f"step {s['n_steps']:,} / {s['budget']:,}  ({pct:.1f}%)  "
            f"•  val={float(s['vals'][-1]):.4f}  "
            f"•  {datetime.now().strftime('%H:%M:%S')}"
        )


    def render(self) -> bool:
        """Load data, compute state, redraw all panels.  Returns True on success."""
        df = self._load_data()
        if df is None:
            return False
        self._df = df
        s = self._compute_state(df)
        self._state = s

        self._draw_acc(s)
        self._draw_rtilde(s)
        self._draw_hops(s)
        self._draw_text(s)
        self._draw_log(s.get("log_lines", []))
        self._update_header(s)

        self.fig.canvas.draw_idle()
        return True


    def run_live(self) -> None:
        """Refresh loop: reload CSV every self.refresh seconds."""
        plt.ion()
        print(f"[dashboard] Watching {self.csv_path}")
        print(f"[dashboard] Refresh every {self.refresh}s — close window or Ctrl+C to stop.")

        try:
            while plt.fignum_exists(self.fig.number):
                ok = self.render()
                if not ok:
                    print(f"[dashboard] Waiting for training to write {self.csv_path} …")
                plt.pause(self.refresh)
        except KeyboardInterrupt:
            print("\n[dashboard] Stopped.")
        finally:
            plt.ioff()


    def run_static(self) -> None:
        """Render once and show the figure (blocking)."""
        ok = self.render()
        if ok:
            plt.tight_layout()
            plt.show()
        else:
            print("[dashboard] No data to display.", file=sys.stderr)


import csv as _csv_mod

class CsvStreamWriter:
    """
    Write training log rows to a CSV file one row at a time, flushing after
    each write so the CLL.1 Dashboard can read live progress.

    Drop-in usage in any training loop::

        from translatestocks_tnt.dashboard_app import CsvStreamWriter

        writer = CsvStreamWriter(
            path       = "results/run.csv",
            fieldnames = ["step", "train_loss", "val_loss",
                          "train_acc", "val_acc", "r_tilde"],
        )

        for step in range(max_steps):
            if step % log_every == 0:
                writer.writerow({
                    "step":       step,
                    "train_loss": train_loss,
                    "val_loss":   val_loss,
                    "train_acc":  train_acc,
                    "val_acc":    val_acc,
                    "r_tilde":    r_tilde,
                })
                writer.writelog(
                    f"step={step}  val={val_acc:.4f}  train={train_acc:.4f}"
                    f"  loss={val_loss:.4f}  r~={r_tilde:.2f}"
                )

        writer.close()   # optional — also closed on __del__

    The file is opened in write mode ('w') immediately so the directory must
    already exist (or pass ``mkdir=True``).  The header row is written once
    at construction time.  Every subsequent ``writerow`` appends one data row
    and calls ``flush()`` so the OS buffer is committed to disk immediately.

    A companion sidecar log file is written to
    ``<csv_parent>/logs/<stem>.log`` whenever ``writelog(line)`` is called.
    The dashboard's Training Log panel reads from this file automatically.

    Parameters
    ----------
    path       : str | Path — output CSV file path
    fieldnames : list[str]  — column names (order matches dict keys)
    mkdir      : bool       — create parent directories if missing (default True)
    """

    def __init__(
        self,
        path: str | Path,
        fieldnames: list[str],
        mkdir: bool = True,
    ) -> None:
        self._path = Path(path)
        if mkdir:
            self._path.parent.mkdir(parents=True, exist_ok=True)
        self._fh     = open(self._path, "w", newline="", encoding="utf-8")
        self._writer = _csv_mod.DictWriter(self._fh, fieldnames=fieldnames,
                                           extrasaction="ignore")
        self._writer.writeheader()
        self._fh.flush()
        self._log_path = self._path.parent / "logs" / (self._path.stem + ".log")
        self._log_fh   = None

    def writerow(self, row: dict) -> None:
        """Write one row dict and flush to disk immediately."""
        self._writer.writerow(row)
        self._fh.flush()

    def writelog(self, line: str) -> None:
        """Append one text line to the sidecar log consumed by the dashboard Training Log panel."""
        if self._log_fh is None:
            self._log_path.parent.mkdir(parents=True, exist_ok=True)
            self._log_fh = open(self._log_path, "a", encoding="utf-8")
        self._log_fh.write(line if line.endswith("\n") else line + "\n")
        self._log_fh.flush()

    def close(self) -> None:
        """Close the underlying file handles."""
        if not self._fh.closed:
            self._fh.close()
        if self._log_fh is not None and not self._log_fh.closed:
            self._log_fh.close()

    def __del__(self) -> None:
        self.close()

    def __enter__(self):
        return self

    def __exit__(self, *_):
        self.close()


def _parse_args() -> argparse.Namespace:
    ap = argparse.ArgumentParser(
        description="CLL.1 Real-Time Training Dashboard",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    ap.add_argument("--csv", required=True,
                    help="Path to the live training CSV file.")
    ap.add_argument("--group-order", type=int, default=None, metavar="N",
                    help="Legacy compatibility argument (unused by the current dashboard).")
    ap.add_argument("--budget", type=int, default=None, metavar="STEPS",
                    help="Total training step budget (default: 2× last observed step).")
    ap.add_argument("--hops", type=str, default=None, metavar="COL1,COL2,...",
                    help="Comma-separated CSV column names for hop staircase. "
                         "Last column is the final task (usually val_acc). "
                         "Example: --hops pfx1_acc,pfx2_acc,pfx3_acc,val_acc")
    ap.add_argument("--refresh", type=float, default=1.0, metavar="SEC",
                    help="Refresh interval in seconds (default: 5).")
    ap.add_argument("--r-threshold", type=float, default=GK_CENTER, metavar="R",
                    help=f"r̃ null-cone crossing threshold (default: {GK_CENTER}).")
    ap.add_argument("--title", type=str, default=None,
                    help="Custom dashboard title (overrides auto-detected metadata).")
    ap.add_argument("--log", type=str, default=None, metavar="FILE",
                    help="Path to a training log text file to show in the Training Log panel. "
                         "Defaults to <csv_parent>/logs/<stem>.log (auto-sidecar written by CsvStreamWriter).")
    ap.add_argument("--static", action="store_true",
                    help="Render once and show (no live refresh; useful for completed runs).")
    return ap.parse_args()


def main() -> None:
    args = _parse_args()

    hop_cols = None
    if args.hops:
        hop_cols = [c.strip() for c in args.hops.split(",") if c.strip()]

    dash = CLL1Dashboard(
        csv_path    = args.csv,
        group_order = args.group_order,
        budget      = args.budget,
        hop_cols    = hop_cols,
        refresh     = args.refresh,
        r_threshold = args.r_threshold,
        title       = args.title,
        log_path    = args.log,
    )

    if args.static:
        dash.run_static()
    else:
        dash.run_live()


def launch_dashboard(
    csv_path,
    group_order: int | None = None,
    budget: int | None = None,
    hops: str | None = None,
    refresh: float = 1.0,
    title: str | None = None,
):
    """Launch the CLL.1 dashboard as a non-blocking background subprocess.

    Returns a ``subprocess.Popen`` handle; call ``proc.terminate()`` when done.
    """
    import os
    import subprocess

    _module = "translatestocks_tnt.dashboard_app"
    _pkg_root = str(Path(__file__).parent.parent)

    cmd = [sys.executable, "-m", _module, "--csv", str(csv_path)]
    if group_order is not None:
        cmd += ["--group-order", str(group_order)]
    if budget is not None:
        cmd += ["--budget", str(budget)]
    if hops is not None:
        cmd += ["--hops", str(hops)]
    cmd += ["--refresh", str(refresh)]
    if title is not None:
        cmd += ["--title", str(title)]

    env = os.environ.copy()
    existing = env.get("PYTHONPATH", "")
    env["PYTHONPATH"] = _pkg_root + (os.pathsep + existing if existing else "")
    env["KMP_DUPLICATE_LIB_OK"] = "TRUE"

    proc = subprocess.Popen(cmd, env=env,
                             stdout=subprocess.DEVNULL,
                             stderr=subprocess.DEVNULL)
    print(f"[CLL1Dashboard] Launched  pid={proc.pid}  csv={Path(csv_path).name}")
    return proc


if __name__ == "__main__":
    main()
