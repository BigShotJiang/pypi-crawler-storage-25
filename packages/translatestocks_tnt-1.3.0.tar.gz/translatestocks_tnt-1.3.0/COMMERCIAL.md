﻿# Commercial License — translatestocks-tnt / TNT-ls

JCFI, LLC — Commercial Licensing Program  
Contact: license@translatestocks.com  
Web: https://translatestocks.com/tnt

[![DOI](https://zenodo.org/badge/DOI/10.5281/zenodo.19512438.svg)](https://doi.org/10.5281/zenodo.19512438)

---

## Scope of this note

This document applies to the public `TNT-ls` release of `translatestocks-tnt`.

`TNT-ls` is the current public left-side release. It does not attempt to
describe every internal or future TNT component; it describes the commercial
licensing path for the public software release and the methods covered by the
patent notices associated with that release.

---

## When a commercial license is needed

`translatestocks-tnt` is released under AGPLv3 for open-source use.

If you deploy the software in a way that does not satisfy AGPLv3 obligations,
you need a separate commercial license.

Typical cases that require a commercial license include:

- closed-source proprietary software;
- SaaS or hosted API deployment without source disclosure;
- enterprise training or inference systems kept private;
- OEM / embedded integration into third-party commercial products.

If your use is fully AGPLv3-compliant and all corresponding source is made
available under AGPLv3-compatible terms, a separate commercial license is not
required.

---

## What the commercial license covers

A commercial license from JCFI, LLC is intended to provide:

1. the right to use, modify, and deploy the software in proprietary contexts;
2. relief from AGPLv3 network-service disclosure obligations;
3. an explicit patent license for covered JCFI, LLC patent claims tied to the
   licensed software and methods;
4. negotiated commercial terms for support, updates, and deployment rights.

Patent coverage is tied to the same provisional family referenced in `NOTICE`:

- 64/013,259
- 64/016,115
- 64/022,599

---

## How to inquire

Email `license@translatestocks.com` with:

- organization name;
- intended use case;
- deployment model;
- expected scale or commercial context.

---

## Research and academic use

Academic, research, and open-source use that remains fully AGPLv3-compliant
does not require a separate commercial license.

---

JCFI, LLC — license@translatestocks.com  
Document revision: TNT-ls / 1.3.0 — April 2026
