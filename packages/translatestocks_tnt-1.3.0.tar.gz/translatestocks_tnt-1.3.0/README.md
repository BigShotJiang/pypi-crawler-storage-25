# Thermodynamic Neural Transformer (TNT)

# translatestocks-tnt

Public release: `TNT-ls`  
Package version target: `1.3.0`  
GitHub release tag: `v1.3-ls`

[![DOI](https://zenodo.org/badge/DOI/10.5281/zenodo.19512438.svg)](https://doi.org/10.5281/zenodo.19512438)

---

`translatestocks-tnt` is the public left-side release of the Thermodynamic Neural Transformer program. This repository is intended to expose the benchmark-validated public surface already supported by the current evidence trail. It is not intended to claim that the full post-grok TNT stack is public today.

## The TNT Architecture Split: Why TNT-ls?

The full TNT architecture is conceptually split into two halves:

- Left Side (`TNT-ls`) — routing / grokking. This release is responsible for mapping latent discrete symmetries in the data, mathematically routing inputs through combinatorial structure, and enforcing geometric branch isolation (Brouwer isolation) before grokking.
- Right Side (`TNT-rs`, not included in this release) — thermodynamic crystallization. This is the future complementary side that takes already routed manifolds and applies thermodynamic principles, including H-neurons and quaternionic crystallization, to support efficient and secure continuous post-grok learning.

The name `Thermodynamic Neural Transformer` should be read as the umbrella name of the full TNT program, not as a claim that the current public package already contains the entire thermodynamic / right-side stack.

In short: `TNT-ls` prepares the topology; `TNT-rs` freezes the state.

## Release boundary

This repository is the `TNT-ls` release.

It includes:

- constrained-backbone primitives such as `BorweinAttention`, `RSTFFNBlock`, and `KTOrderParameter`;
- public algebra-aware layers already part of the left-side library surface;
- low-cardinality / routing support used in public evidence, including `BitPlaneEmbedding`, `DualEmbedding`, `CLogLogGate`, and `GatedExitNode`;
- release-facing documentation;
- the LIB showcase summary as a public example of the released routing boundary.

It does not claim to include:

- the full post-grok / right-side TNT architecture (`TNT-rs`);
- quaternionic crystallization, H-neurons, continuous learning, or other later/private right-side layers;
- the full frozen ablation corpus for the companion paper as the primary GitHub front door.

The complete paper ablation bundle should be treated as a paper artifact and archived separately in the paper Zenodo bundle.

## Why this release matters

The practical thesis of `TNT-ls` is narrow: structured architectural choices can improve the timing and reliability of useful transition in controlled benchmark regimes.

The strongest public example attached to this release is the LIB showcase:

- matched scale at approximately 93.4M parameters;
- LIB condition: 100% grokking on `mult_1009`, `mult_503`, `xor`, and `add`;
- matched baseline condition: 0% grokking on all four tasks;
- Brouwer isolation: 3/3 passes, with exact `bp_norm = 0.0`.

See [LIBMODEL_SHOWCASE.md](benchmarks/LIBmodel/LIBMODEL_SHOWCASE.md) for the clean release-facing summary.

## Release documents

- [TNT_RELEASE_WHITE_PAPER.md](https://github.com/translatestocks/tnt/blob/v1.3-ls/TNT_RELEASE_WHITE_PAPER.md) — release-facing white paper for the public `TNT-ls` boundary
- [LIBMODEL_SHOWCASE.md](https://github.com/translatestocks/tnt/blob/v1.3-ls/benchmarks/LIBmodel/LIBMODEL_SHOWCASE.md) — public LIB showcase summary
- [LIB_USAGE.md](https://github.com/translatestocks/tnt/blob/v1.3-ls/LIB_USAGE.md) — usage guide for the `TNT-ls` public surface
- [CONTRIBUTING.md](https://github.com/translatestocks/tnt/blob/v1.3-ls/CONTRIBUTING.md) — maintainer-curated upstream policy for the public repository
- [NOTICE](https://github.com/translatestocks/tnt/blob/v1.3-ls/NOTICE) — patent / dual-license notice
- [COMMERCIAL.md](https://github.com/translatestocks/tnt/blob/v1.3-ls/COMMERCIAL.md) — commercial licensing note
- [CLA.md](https://github.com/translatestocks/tnt/blob/v1.3-ls/CLA.md) — status note for the inactive public CLA path

## Contributions

The canonical upstream is maintainer-curated. External code pull requests are not accepted for merge into this repository, and non-collaborator pull requests are closed by policy.

Forks and downstream use remain available under the repository license. If you need to report a bug or propose a change, use the issue tracker or maintain a downstream fork.

## Package identifiers

- PyPI package name: `translatestocks-tnt`
- Python import path: `translatestocks_tnt`
- Public release name: `TNT-ls`
- GitHub tag: `v1.3-ls`
- Package version: `1.3.0`

## Install target

When the package is published:

```bash
pip install translatestocks-tnt==1.3.0
```

## Theory references

Pinto Martins, C. F. (2026). *Ramsey Statistics And Infiniteons Theory, Volume I*. Zenodo. DOI: https://doi.org/10.5281/zenodo.19329589

Pinto Martins, C. F. (2026). *Ramsey Statistics And Infiniteons Theory, Volume II*. Zenodo. DOI: https://doi.org/10.5281/zenodo.19330373

## Licensing

This repository is distributed under AGPLv3 with a separate commercial licensing path.

- See [LICENSE](https://github.com/translatestocks/tnt/blob/v1.3-ls/LICENSE) for the full AGPLv3 text.
- See [NOTICE](https://github.com/translatestocks/tnt/blob/v1.3-ls/NOTICE) for patent and dual-license notice.
- See [COMMERCIAL.md](https://github.com/translatestocks/tnt/blob/v1.3-ls/COMMERCIAL.md) for commercial licensing inquiries.

Commercial contact: `license@translatestocks.com`