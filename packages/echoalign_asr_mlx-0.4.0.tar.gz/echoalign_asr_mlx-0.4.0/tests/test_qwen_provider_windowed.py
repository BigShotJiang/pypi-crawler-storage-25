import subprocess
import unittest
from pathlib import Path
from unittest.mock import patch

from asr.models import Segment, Token
from asr.observability.events import ObservabilityEvent
from asr.providers.authority import ProjectedToken
from asr.providers.quality import QualityResult, QualityThresholds
from asr.providers.qwen_mlx import QwenMlxProvider, WindowDisplayBounds, WindowRun
from asr.providers.windowing import AlignmentWindow
from asr.vad import DEFAULT_VAD_CONFIG, AlignmentUnit, SpeechPlan, SpeechSpan


class FakeChunk:
    def __init__(
        self,
        text: str,
        language: str | None = None,
        start_time: float = 0.0,
        end_time: float = 0.0,
    ) -> None:
        self.text = text
        self.language = language
        self.start_time = start_time
        self.end_time = end_time


class FakeModel:
    def __init__(self, responses: list[object]) -> None:
        self._responses = list(responses)
        self.calls: list[tuple[str, dict[str, object]]] = []

    def generate(self, audio_input: str, **kwargs: object) -> object:
        self.calls.append((audio_input, dict(kwargs)))
        if not self._responses:
            raise AssertionError("FakeModel ran out of responses")
        response = self._responses.pop(0)
        if isinstance(response, Exception):
            raise response
        return response


class _ProviderRecordingObserver:
    def __init__(self) -> None:
        self.events: list[ObservabilityEvent] = []

    def on_event(self, event: ObservabilityEvent) -> None:
        self.events.append(event)

    def close(self) -> None:
        return None


class QwenProviderWindowedTest(unittest.TestCase):
    def test_long_token_segment_splits_at_target_duration(self) -> None:
        provider = QwenMlxProvider()
        tokens = [
            Token("one", 0.0, 1.0, unit="word"),
            Token("two", 1.1, 2.0, unit="word"),
            Token("three", 2.1, 3.0, unit="word"),
            Token("four", 3.1, 4.0, unit="word"),
        ]

        segments = provider._tokens_to_segments(tokens, target_max_segment_duration_sec=2.5)

        self.assertEqual([segment.text for segment in segments], ["one two", "three four"])
        self.assertEqual(
            [(segment.start_time, segment.end_time) for segment in segments],
            [(0.0, 2.0), (2.1, 4.0)],
        )

    def test_window_run_carries_display_bounds_without_provider_lookup_state(self) -> None:
        bounds = WindowDisplayBounds(
            start_time=104.8,
            end_time=120.35,
            alignment_unit_index=0,
        )
        run = WindowRun(
            window=AlignmentWindow(
                0,
                100.0,
                130.0,
                100.0,
                130.0,
                alignment_unit_index=0,
            ),
            text="hello",
            display_bounds=bounds,
        )

        self.assertEqual(run.display_bounds, bounds)
        self.assertFalse(hasattr(QwenMlxProvider(), "_display_bounds_by_window_index"))
        self.assertFalse(hasattr(QwenMlxProvider(), "_window_display_bounds"))

    def test_window_run_defaults_to_no_timing_anchor(self) -> None:
        run = WindowRun(window=AlignmentWindow(0, 0.0, 1.0, 0.0, 1.0), text="hello")

        self.assertFalse(run.has_timing_anchor)
        self.assertEqual(run.timing_source_counts, {})
        self.assertEqual(run.projected_tokens, [])

    def test_window_diagnostic_includes_timing_source_quality_fields(self) -> None:
        provider = QwenMlxProvider()
        run = WindowRun(
            window=AlignmentWindow(2, 10.0, 20.0, 9.0, 21.0),
            text="hello world",
            tokens=[
                Token("hello", 10.0, 10.4, unit="word"),
                Token("world", 10.5, 10.9, unit="word"),
            ],
            quality=QualityResult(
                False,
                1.0,
                0.0,
                0.0,
                0.0,
                estimated_token_ratio=0.25,
                unresolved_token_ratio=0.50,
            ),
            timing_source_counts={"aligner": 1, "estimated": 1, "unresolved": 2},
            has_timing_anchor=True,
        )

        diagnostic = provider._build_window_diagnostic(run)

        self.assertEqual(
            diagnostic["timing_source_counts"],
            {"aligner": 1, "estimated": 1, "unresolved": 2},
        )
        self.assertIsNot(diagnostic["timing_source_counts"], run.timing_source_counts)
        self.assertTrue(diagnostic["has_timing_anchor"])
        self.assertEqual(diagnostic["quality"]["estimated_token_ratio"], 0.25)
        self.assertEqual(diagnostic["quality"]["unresolved_token_ratio"], 0.50)

    def test_fully_unresolved_window_uses_fallback_not_token_segmentation(self) -> None:
        provider, _, _ = self._build_provider_with_models(
            asr_responses=[FakeChunk("C++ C#", language="en")],
            align_responses=[
                [
                    FakeChunk("C", start_time=1.00, end_time=1.10),
                    FakeChunk("C", start_time=1.10, end_time=1.20),
                ]
            ],
        )
        provider._probe_duration_sec = lambda _: 40.0

        doc = provider.transcribe(Path("demo.wav"))

        self.assertEqual([segment.text for segment in doc.segments], ["C++ C#"])
        self.assertEqual(doc.segments[0].tokens, [])
        self.assertLessEqual(doc.segments[0].end_time - doc.segments[0].start_time, 6.0)

    def test_partially_unresolved_window_keeps_anchored_tokens_without_full_fallback(self) -> None:
        provider, _, _ = self._build_provider_with_models(
            asr_responses=[FakeChunk("a x b", language="en")],
            align_responses=[
                [
                    FakeChunk("a", start_time=1.0, end_time=2.0),
                    FakeChunk("b", start_time=1.5, end_time=1.8),
                ]
            ],
        )
        provider._probe_duration_sec = lambda _: 3.0

        doc = provider.transcribe(Path("demo.wav"))

        self.assertEqual([segment.text for segment in doc.segments], ["a b"])
        self.assertEqual([token.text for token in doc.segments[0].tokens], ["a", "b"])

    def test_trailing_unresolved_token_emits_local_fallback_after_anchor(self) -> None:
        provider = QwenMlxProvider()
        anchor = Token("hello", 1.0, 1.3, unit="word")
        unresolved = Token("there", 0.0, 0.0, unit="word")
        run = WindowRun(
            window=AlignmentWindow(0, 0.0, 3.0, 0.0, 3.0),
            text="hello there",
            language="en",
            tokens=[anchor],
            core_tokens=[anchor],
            projected_tokens=[
                ProjectedToken(anchor, "aligner", aligner_index=0, transcript_index=0),
                ProjectedToken(unresolved, "unresolved", transcript_index=1),
            ],
            timing_source_counts={"aligner": 1, "estimated": 0, "unresolved": 1},
            has_timing_anchor=True,
        )

        self.assertFalse(provider._needs_text_fallback(run))

        segments = provider._unresolved_fallback_segments_from_windows([run])

        self.assertEqual([segment.text for segment in segments], ["there"])
        self.assertEqual(segments[0].tokens, [])
        self.assertGreaterEqual(segments[0].start_time, anchor.end_time)
        self.assertLessEqual(segments[0].end_time, run.window.core_end)

    def test_trailing_unresolved_token_requires_previous_transcript_adjacency(self) -> None:
        provider = QwenMlxProvider()
        anchor = Token("hello", 10.0, 10.4, unit="word")
        unresolved = Token("there", 0.0, 0.0, unit="word")
        run = WindowRun(
            window=AlignmentWindow(0, 10.0, 20.0, 5.0, 25.0),
            text="hello skipped there",
            language="en",
            tokens=[anchor],
            core_tokens=[anchor],
            projected_tokens=[
                ProjectedToken(anchor, "aligner", aligner_index=0, transcript_index=0),
                ProjectedToken(unresolved, "unresolved", transcript_index=2),
            ],
            timing_source_counts={"aligner": 1, "estimated": 0, "unresolved": 1},
            has_timing_anchor=True,
        )

        self.assertEqual(provider._unresolved_fallback_segments_from_windows([run]), [])

    def test_unresolved_context_token_does_not_emit_local_or_full_fallback(self) -> None:
        provider = QwenMlxProvider()
        core = Token("hello", 10.0, 10.4, unit="word")
        context = Token("context", 0.0, 0.0, unit="word")
        run = WindowRun(
            window=AlignmentWindow(0, 10.0, 20.0, 5.0, 25.0),
            text="context hello",
            language="en",
            tokens=[core],
            core_tokens=[core],
            projected_tokens=[
                ProjectedToken(context, "unresolved", transcript_index=0),
                ProjectedToken(core, "aligner", aligner_index=0, transcript_index=1),
            ],
            timing_source_counts={"aligner": 1, "estimated": 0, "unresolved": 1},
            has_timing_anchor=True,
        )

        self.assertFalse(provider._needs_text_fallback(run))
        self.assertEqual(provider._unresolved_fallback_segments_from_windows([run]), [])

    def test_leading_unresolved_core_token_uses_next_core_token_as_anchor(self) -> None:
        provider = QwenMlxProvider()
        context = Token("before", 9.4, 9.8, unit="word")
        unresolved = Token("I", 0.0, 0.0, unit="word")
        core = Token("have", 10.4, 10.8, unit="word")
        run = WindowRun(
            window=AlignmentWindow(0, 10.0, 20.0, 5.0, 25.0),
            text="before I have",
            language="en",
            tokens=[context, core],
            left_overlap_tokens=[context],
            core_tokens=[core],
            projected_tokens=[
                ProjectedToken(context, "aligner", aligner_index=0, transcript_index=0),
                ProjectedToken(unresolved, "unresolved", transcript_index=1),
                ProjectedToken(core, "aligner", aligner_index=1, transcript_index=2),
            ],
            timing_source_counts={"aligner": 2, "estimated": 0, "unresolved": 1},
            has_timing_anchor=True,
        )

        segments = provider._unresolved_fallback_segments_from_windows([run])

        self.assertEqual([segment.text for segment in segments], ["I"])
        self.assertGreaterEqual(segments[0].start_time, run.window.core_start)
        self.assertLessEqual(segments[0].end_time, core.start_time)

    def test_fallback_segment_does_not_last_until_window_core_end(self) -> None:
        provider = QwenMlxProvider()
        run = WindowRun(
            window=AlignmentWindow(0, 100.0, 250.0, 95.0, 255.0),
            text="bad fallback text",
            language="en",
            tokens=[],
            has_timing_anchor=False,
        )

        segments = provider._fallback_segments_from_windows([run])

        self.assertEqual(len(segments), 1)
        self.assertLessEqual(segments[0].end_time - segments[0].start_time, 6.0)
        self.assertLess(segments[0].end_time, 250.0)

    def test_vad_fallback_start_uses_window_core_with_shared_display_bounds(self) -> None:
        provider = QwenMlxProvider()
        run = WindowRun(
            window=AlignmentWindow(
                1,
                70.0,
                90.0,
                65.0,
                95.0,
                alignment_unit_index=0,
            ),
            text="late unresolved",
            language="en",
            display_bounds=WindowDisplayBounds(
                start_time=19.8,
                end_time=120.35,
                alignment_unit_index=0,
            ),
            has_timing_anchor=False,
        )

        segments = provider._fallback_segments_from_windows([run])

        self.assertEqual(len(segments), 1)
        self.assertEqual(segments[0].start_time, 70.0)
        self.assertLessEqual(segments[0].end_time - segments[0].start_time, 6.0)

    def test_fallback_segments_skip_whitespace_only_text(self) -> None:
        provider = QwenMlxProvider()
        run = WindowRun(
            window=AlignmentWindow(0, 10.0, 20.0, 9.0, 21.0),
            text="  \t\n  ",
            language="en",
            has_timing_anchor=False,
        )

        segments = provider._fallback_segments_from_windows([run])

        self.assertEqual(segments, [])

    def test_preferred_tokens_include_short_estimated_prefix_before_core(self) -> None:
        provider = QwenMlxProvider()
        window = AlignmentWindow(0, 105.0, 120.0, 100.0, 125.0)
        prefix = Token("I", 104.98, 105.08, unit="word")
        core = Token("have", 105.20, 105.50, unit="word")
        run = WindowRun(
            window=window,
            text="I have",
            tokens=[prefix, core],
            left_overlap_tokens=[prefix],
            core_tokens=[core],
            timing_source_counts={"aligner": 1, "estimated": 1, "unresolved": 0},
            has_timing_anchor=True,
            projected_tokens=[
                ProjectedToken(prefix, "estimated"),
                ProjectedToken(core, "aligner", 0),
            ],
        )

        preferred = provider._preferred_tokens_for_window(run)

        self.assertEqual([token.text for token in preferred], ["I", "have"])

    def test_preferred_tokens_do_not_include_aligned_context_prefix(self) -> None:
        provider = QwenMlxProvider()
        window = AlignmentWindow(0, 105.0, 120.0, 100.0, 125.0)
        prefix = Token("to", 104.98, 105.08, unit="word")
        core = Token("have", 105.20, 105.50, unit="word")
        run = WindowRun(
            window=window,
            text="to have",
            tokens=[prefix, core],
            left_overlap_tokens=[prefix],
            core_tokens=[core],
            timing_source_counts={"aligner": 2, "estimated": 0, "unresolved": 0},
            has_timing_anchor=True,
            projected_tokens=[
                ProjectedToken(prefix, "aligner", 0),
                ProjectedToken(core, "aligner", 1),
            ],
        )

        preferred = provider._preferred_tokens_for_window(run)

        self.assertEqual([token.text for token in preferred], ["have"])

    def test_preferred_tokens_only_include_transcript_adjacent_estimated_prefix(self) -> None:
        provider = QwenMlxProvider()
        window = AlignmentWindow(0, 105.0, 120.0, 100.0, 125.0)
        context = Token("to", 104.88, 105.00, unit="word")
        prefix = Token("I", 104.98, 105.08, unit="word")
        core = Token("have", 105.20, 105.50, unit="word")
        run = WindowRun(
            window=window,
            text="to I have",
            tokens=[context, prefix, core],
            left_overlap_tokens=[context, prefix],
            core_tokens=[core],
            timing_source_counts={"aligner": 1, "estimated": 2, "unresolved": 0},
            has_timing_anchor=True,
            projected_tokens=[
                ProjectedToken(context, "estimated", transcript_index=0),
                ProjectedToken(prefix, "estimated", transcript_index=2),
                ProjectedToken(core, "aligner", aligner_index=0, transcript_index=3),
            ],
        )

        preferred = provider._preferred_tokens_for_window(run)

        self.assertEqual([token.text for token in preferred], ["I", "have"])

    def _build_provider_with_models(
        self,
        *,
        asr_responses: list[object],
        align_responses: list[object],
        quality_thresholds: QualityThresholds | None = None,
    ) -> tuple[QwenMlxProvider, FakeModel, FakeModel]:
        provider = QwenMlxProvider(
            quality_thresholds=quality_thresholds or QualityThresholds()
        )
        provider._probe_duration_sec = lambda _: 340.0
        provider._resolve_silence_anchor = lambda target, left, right: None

        asr_model = FakeModel(asr_responses)
        align_model = FakeModel(align_responses)
        provider._load_backend = (
            lambda: (
                lambda model_id: asr_model if "ASR" in model_id else align_model
            )
        )
        return provider, asr_model, align_model

    def _speech_plan(
        self,
        units: list[AlignmentUnit],
        duration_sec: float = 400.0,
    ) -> SpeechPlan:
        return SpeechPlan(
            enabled=True,
            status="ok",
            duration_sec=duration_sec,
            raw_spans=[
                SpeechSpan(start=unit.speech_start, end=unit.speech_end)
                for unit in units
            ],
            alignment_units=units,
            config=DEFAULT_VAD_CONFIG,
        )

    def test_provider_repairs_unmatched_prefix_before_split(self) -> None:
        provider, asr_model, align_model = self._build_provider_with_models(
            asr_responses=[FakeChunk("we have", language="en")],
            align_responses=[
                [FakeChunk("have", start_time=5.00, end_time=5.30)],
            ],
        )
        provider._asr_model = asr_model
        provider._aligner_model = align_model
        window = AlignmentWindow(0, 105.0, 120.0, 100.0, 125.0)

        run = provider._transcribe_window(Path("demo.wav"), window)

        self.assertEqual([token.text for token in run.left_overlap_tokens], ["we"])
        self.assertEqual([token.text for token in run.core_tokens], ["have"])
        self.assertGreater(run.left_overlap_tokens[0].start_time, 104.7)
        self.assertLess(run.left_overlap_tokens[0].start_time, 105.0)

    def test_provider_processes_all_windows_not_first_window_only(self) -> None:
        provider, asr_model, align_model = self._build_provider_with_models(
            asr_responses=[
                FakeChunk("hello world", language="en"),
                FakeChunk("again now", language="en"),
                FakeChunk("tail done", language="en"),
            ],
            align_responses=[
                [
                    FakeChunk("hello", start_time=0.00, end_time=0.45),
                    FakeChunk("world", start_time=0.46, end_time=0.95),
                ],
                [
                    FakeChunk("again", start_time=0.00, end_time=0.35),
                    FakeChunk("now", start_time=0.36, end_time=0.72),
                ],
                [
                    FakeChunk("tail", start_time=0.00, end_time=0.30),
                    FakeChunk("done", start_time=0.31, end_time=0.68),
                ],
            ],
        )

        doc = provider.transcribe(Path("demo.wav"))
        metadata = doc.source_media["provider_metadata"]
        diagnostics = metadata["window_diagnostics"]

        self.assertEqual(len(asr_model.calls), metadata["window_count"])
        self.assertEqual(len(align_model.calls), metadata["window_count"])
        self.assertGreaterEqual(len(doc.segments), 2)
        self.assertEqual(metadata["processing_strategy"], "windowed_bounded_alignment")
        self.assertNotIn("super_chunk_count", metadata)
        self.assertGreaterEqual(metadata["window_count"], 2)

        for (audio_input, kwargs), diagnostic in zip(asr_model.calls, diagnostics):
            self.assertNotIn("#t=", audio_input)
            self.assertNotIn("start_time", kwargs)
            self.assertNotIn("end_time", kwargs)

        for (audio_input, kwargs), diagnostic in zip(align_model.calls, diagnostics):
            self.assertNotIn("#t=", audio_input)
            self.assertNotIn("start_time", kwargs)
            self.assertNotIn("end_time", kwargs)
            self.assertIn("quality", diagnostic)

        self.assertTrue(diagnostics[0]["quality"]["passed"])
        self.assertTrue(diagnostics[-1]["quality"]["passed"])
        self.assertLess(diagnostics[0]["quality"]["boundary_disagreement_score"], 1.0)
        self.assertLess(diagnostics[-1]["quality"]["boundary_disagreement_score"], 1.0)

    def test_vad_window_run_carries_alignment_unit_display_bounds(self) -> None:
        provider, _, _ = self._build_provider_with_models(
            asr_responses=[FakeChunk("hello", language="en")],
            align_responses=[[FakeChunk("hello", start_time=5.0, end_time=5.3)]],
        )
        plan = self._speech_plan(
            [
                AlignmentUnit(
                    index=0,
                    speech_start=105.0,
                    speech_end=120.0,
                    input_start=100.0,
                    input_end=130.0,
                    source_span_count=1,
                )
            ],
            duration_sec=200.0,
        )

        doc = provider.transcribe(Path("demo.wav"), speech_plan=plan)
        diagnostic = doc.source_media["provider_metadata"]["window_diagnostics"][0]

        self.assertEqual(diagnostic["alignment_unit_index"], 0)
        self.assertNotIn("super_chunk_index", diagnostic)
        self.assertEqual(diagnostic["display_start"], 104.8)
        self.assertEqual(diagnostic["display_end"], 120.35)

    def test_suspicious_short_word_timing_is_repaired_before_segmentation(self) -> None:
        provider, _, _ = self._build_provider_with_models(
            asr_responses=[
                FakeChunk("You'd better stay in line from now on.", language="en")
            ],
            align_responses=[
                [
                    FakeChunk("You'd", start_time=0.00, end_time=14.40),
                    FakeChunk("better", start_time=14.40, end_time=14.56),
                    FakeChunk("stay", start_time=14.56, end_time=14.88),
                    FakeChunk("in", start_time=14.88, end_time=14.96),
                    FakeChunk("line", start_time=14.96, end_time=15.20),
                    FakeChunk("from", start_time=15.20, end_time=15.36),
                    FakeChunk("now", start_time=15.36, end_time=15.60),
                    FakeChunk("on.", start_time=15.60, end_time=16.00),
                ]
            ],
        )
        plan = self._speech_plan(
            [
                AlignmentUnit(
                    index=0,
                    speech_start=10498.6,
                    speech_end=10500.7,
                    input_start=10484.52,
                    input_end=10501.5,
                    source_span_count=1,
                )
            ],
            duration_sec=10600.0,
        )

        doc = provider.transcribe(Path("demo.wav"), speech_plan=plan)
        tokens = [token for segment in doc.segments for token in segment.tokens]
        youd = next(token for token in tokens if token.text == "You'd")

        self.assertLessEqual(youd.end_time - youd.start_time, 0.32)
        self.assertGreaterEqual(youd.start_time, 10498.0)
        self.assertTrue(
            all(segment.end_time - segment.start_time < 8.0 for segment in doc.segments)
        )

    def test_token_crossing_vad_gap_is_repaired_before_segmentation(self) -> None:
        provider, _, _ = self._build_provider_with_models(
            asr_responses=[
                FakeChunk("before supercalifragilistic after", language="en")
            ],
            align_responses=[
                [
                    FakeChunk("before", start_time=0.00, end_time=0.30),
                    FakeChunk(
                        "supercalifragilistic",
                        start_time=0.50,
                        end_time=4.20,
                    ),
                    FakeChunk("after", start_time=4.30, end_time=4.60),
                ]
            ],
        )
        plan = SpeechPlan(
            enabled=True,
            status="ok",
            duration_sec=200.0,
            raw_spans=[
                SpeechSpan(start=100.0, end=101.0),
                SpeechSpan(start=104.0, end=105.0),
            ],
            alignment_units=[
                AlignmentUnit(
                    index=0,
                    speech_start=100.0,
                    speech_end=105.0,
                    input_start=100.0,
                    input_end=106.0,
                    source_span_count=2,
                )
            ],
            config=DEFAULT_VAD_CONFIG,
        )

        doc = provider.transcribe(Path("demo.wav"), speech_plan=plan)
        tokens = [token for segment in doc.segments for token in segment.tokens]
        repaired = next(
            token for token in tokens if token.text == "supercalifragilistic"
        )

        self.assertLessEqual(repaired.end_time - repaired.start_time, 0.32)
        self.assertLessEqual(repaired.end_time, 101.0)

    def test_provider_processes_vad_alignment_units_on_global_timeline(self) -> None:
        provider, asr_model, align_model = self._build_provider_with_models(
            asr_responses=[
                FakeChunk("first unit", language="en"),
                FakeChunk("second unit", language="en"),
            ],
            align_responses=[
                [
                    FakeChunk("first", start_time=0.00, end_time=0.40),
                    FakeChunk("unit", start_time=0.41, end_time=0.90),
                ],
                [
                    FakeChunk("second", start_time=0.00, end_time=0.50),
                    FakeChunk("unit", start_time=0.51, end_time=1.00),
                ],
            ],
        )
        plan = self._speech_plan(
            [
                AlignmentUnit(0, 105.0, 120.0, 100.0, 130.0, 1),
                AlignmentUnit(1, 285.0, 300.0, 280.0, 310.0, 1),
            ]
        )

        doc = provider.transcribe(Path("demo.wav"), speech_plan=plan)

        metadata = doc.source_media["provider_metadata"]
        diagnostics = metadata["window_diagnostics"]
        self.assertEqual(
            metadata["processing_strategy"],
            "vad_alignment_unit_bounded_alignment",
        )
        self.assertEqual(metadata["alignment_unit_count"], 2)
        self.assertNotIn("super_chunk_count", metadata)
        self.assertEqual([item["alignment_unit_index"] for item in diagnostics], [0, 1])
        self.assertEqual(len(asr_model.calls), 2)
        self.assertEqual(len(align_model.calls), 2)
        self.assertEqual(
            [
                round(token.start_time, 2)
                for segment in doc.segments
                for token in segment.tokens
            ],
            [100.0, 100.41, 280.0, 280.51],
        )

    def test_provider_uses_speech_plan_duration_to_keep_later_vad_units(self) -> None:
        provider, asr_model, align_model = self._build_provider_with_models(
            asr_responses=[
                FakeChunk("first unit", language="en"),
                FakeChunk("second unit", language="en"),
            ],
            align_responses=[
                [
                    FakeChunk("first", start_time=0.00, end_time=0.40),
                    FakeChunk("unit", start_time=0.41, end_time=0.90),
                ],
                [
                    FakeChunk("second", start_time=0.00, end_time=0.50),
                    FakeChunk("unit", start_time=0.51, end_time=1.00),
                ],
            ],
        )
        provider._probe_duration_sec = lambda _: 160.0
        plan = self._speech_plan(
            [
                AlignmentUnit(0, 105.0, 120.0, 100.0, 130.0, 1),
                AlignmentUnit(1, 285.0, 300.0, 280.0, 310.0, 1),
            ],
            duration_sec=400.0,
        )

        doc = provider.transcribe(Path("demo.wav"), speech_plan=plan)

        diagnostics = doc.source_media["provider_metadata"]["window_diagnostics"]
        self.assertEqual([item["alignment_unit_index"] for item in diagnostics], [0, 1])
        self.assertEqual(len(asr_model.calls), 2)
        self.assertEqual(len(align_model.calls), 2)
        self.assertEqual(doc.source_media["provider_metadata"]["duration_sec"], 400.0)

    def test_provider_splits_long_alignment_unit_with_existing_hard_window_budget(self) -> None:
        provider, asr_model, align_model = self._build_provider_with_models(
            asr_responses=[
                FakeChunk("alpha", language="en"),
                FakeChunk("beta", language="en"),
                FakeChunk("gamma", language="en"),
            ],
            align_responses=[
                [FakeChunk("alpha", start_time=0.0, end_time=0.4)],
                [FakeChunk("beta", start_time=0.0, end_time=0.4)],
                [FakeChunk("gamma", start_time=0.0, end_time=0.4)],
            ],
        )
        plan = self._speech_plan(
            [AlignmentUnit(0, 20.0, 330.0, 10.0, 350.0, 1)],
            duration_sec=400.0,
        )

        doc = provider.transcribe(Path("demo.wav"), speech_plan=plan)

        diagnostics = doc.source_media["provider_metadata"]["window_diagnostics"]
        self.assertGreater(len(diagnostics), 1)
        self.assertEqual(len(asr_model.calls), len(diagnostics))
        self.assertEqual(len(align_model.calls), len(diagnostics))
        for diagnostic in diagnostics:
            self.assertLessEqual(
                diagnostic["context_end"] - diagnostic["context_start"],
                provider.window_config.max_alignment_window_sec,
            )
            self.assertEqual(diagnostic["alignment_unit_index"], 0)

    def test_speech_spans_for_window_include_alignment_unit_input_padding(self) -> None:
        provider = QwenMlxProvider()
        plan = SpeechPlan(
            enabled=True,
            status="ok",
            duration_sec=200.0,
            raw_spans=[
                SpeechSpan(start=100.0, end=101.0),
                SpeechSpan(start=104.0, end=105.0),
                SpeechSpan(start=108.0, end=109.0),
            ],
            alignment_units=[
                AlignmentUnit(
                    index=0,
                    speech_start=104.0,
                    speech_end=105.0,
                    input_start=100.0,
                    input_end=106.0,
                    source_span_count=1,
                )
            ],
            config=DEFAULT_VAD_CONFIG,
        )
        window = AlignmentWindow(
            0,
            104.0,
            105.0,
            100.0,
            106.0,
            alignment_unit_index=0,
        )

        spans = provider._speech_spans_for_window(window, speech_plan=plan)

        self.assertEqual(
            [(span.start, span.end) for span in spans],
            [(100.0, 101.0), (104.0, 105.0)],
        )

    def test_vad_alignment_unit_anchor_resolver_uses_global_timeline(self) -> None:
        provider = QwenMlxProvider()
        seen_calls: list[tuple[float, float, float]] = []

        def resolve_anchor(target: float, left: float, right: float) -> float:
            seen_calls.append((target, left, right))
            return 448.5

        provider._resolve_silence_anchor = resolve_anchor
        plan = self._speech_plan(
            [AlignmentUnit(0, 300.0, 610.0, 300.0, 620.0, 1)],
            duration_sec=700.0,
        )

        windows = provider._plan_windows(700.0, speech_plan=plan)

        self.assertGreaterEqual(len(windows), 2)
        self.assertEqual(seen_calls[0], (450.0, 438.0, 462.0))
        self.assertEqual(windows[0].core_end, 448.5)

    def test_provider_skips_invalid_vad_alignment_units_and_processes_valid_unit(self) -> None:
        provider, asr_model, align_model = self._build_provider_with_models(
            asr_responses=[
                FakeChunk("valid", language="en"),
            ],
            align_responses=[
                [FakeChunk("valid", start_time=0.0, end_time=0.4)],
            ],
        )
        plan = self._speech_plan(
            [
                AlignmentUnit(0, 10.0, 20.0, 50.0, 40.0, 1),
                AlignmentUnit(1, 30.0, 40.0, float("nan"), 90.0, 1),
                AlignmentUnit(2, 320.0, 370.0, 310.0, 390.0, 1),
            ],
            duration_sec=400.0,
        )

        doc = provider.transcribe(Path("demo.wav"), speech_plan=plan)

        diagnostics = doc.source_media["provider_metadata"]["window_diagnostics"]
        self.assertEqual(len(asr_model.calls), 1)
        self.assertEqual(len(align_model.calls), 1)
        self.assertEqual([item["alignment_unit_index"] for item in diagnostics], [2])
        self.assertEqual(diagnostics[0]["context_start"], 310.0)
        self.assertEqual(diagnostics[0]["context_end"], 390.0)

    def test_single_window_failure_does_not_abort_full_run_and_records_diagnostic(self) -> None:
        provider, asr_model, align_model = self._build_provider_with_models(
            asr_responses=[
                FakeChunk("hello world", language="en"),
                RuntimeError("window exploded"),
                FakeChunk("tail done", language="en"),
            ],
            align_responses=[
                [
                    FakeChunk("hello", start_time=0.00, end_time=0.45),
                    FakeChunk("world", start_time=0.46, end_time=0.95),
                ],
                [
                    FakeChunk("tail", start_time=0.00, end_time=0.30),
                    FakeChunk("done", start_time=0.31, end_time=0.68),
                ],
            ],
        )

        doc = provider.transcribe(Path("demo.wav"))
        metadata = doc.source_media["provider_metadata"]
        diagnostics = metadata["window_diagnostics"]

        self.assertEqual(len(asr_model.calls), metadata["window_count"])
        self.assertEqual(len(align_model.calls), 2)
        self.assertEqual([segment.text for segment in doc.segments], ["hello world", "tail done"])
        self.assertEqual(metadata["quality_pass_count"], 2)
        self.assertEqual(diagnostics[1]["error"], "window exploded")
        self.assertEqual(diagnostics[1]["status"], "failed")

    def test_mixed_pass_fail_quality_still_merges_passing_windows(self) -> None:
        provider, _, _ = self._build_provider_with_models(
            asr_responses=[
                FakeChunk("hello world", language="en"),
                FakeChunk("again now", language="en"),
                FakeChunk("tail done", language="en"),
            ],
            align_responses=[
                [
                    FakeChunk("hello", start_time=0.00, end_time=0.45),
                    FakeChunk("world", start_time=0.46, end_time=0.95),
                ],
                [
                    FakeChunk("again", start_time=0.00, end_time=0.35),
                    FakeChunk("now", start_time=0.36, end_time=0.72),
                ],
                [
                    FakeChunk("tail", start_time=0.00, end_time=0.30),
                    FakeChunk("done", start_time=0.31, end_time=0.68),
                ],
            ],
        )
        quality_results = [
            QualityResult(True, 1.0, 0.0, 0.0, 0.0),
            QualityResult(True, 1.0, 0.0, 0.0, 0.0),
            QualityResult(False, 1.0, 0.0, 1.0, 0.0),
        ]

        with patch(
            "asr.providers.qwen_mlx.evaluate_quality",
            side_effect=quality_results,
        ), patch(
            "asr.providers.qwen_mlx.merge_adjacent_windows",
            side_effect=lambda left, right, left_span, right_span, max_time_delta=0.25: left + right,
        ) as merge_mock:
            doc = provider.transcribe(Path("demo.wav"))

        self.assertEqual(merge_mock.call_count, 1)
        self.assertEqual(
            [segment.text for segment in doc.segments],
            ["hello world", "again now", "tail done"],
        )
        self.assertEqual(doc.source_media["provider_metadata"]["quality_pass_count"], 2)

    def test_failed_gap_does_not_create_non_adjacent_quality_boundary_comparison(self) -> None:
        provider = QwenMlxProvider()
        left_boundary = [Token("left-edge", 10.0, 10.1, unit="word")]
        right_boundary = [Token("right-edge", 20.0, 20.1, unit="word")]
        window_runs = [
            WindowRun(
                window=AlignmentWindow(0, 0.0, 10.0, 0.0, 12.0),
                text="hello world",
                tokens=[Token("hello", 1.0, 1.2, unit="word")],
                right_overlap_tokens=left_boundary,
                core_text="hello world",
            ),
            WindowRun(
                window=AlignmentWindow(1, 10.0, 20.0, 8.0, 22.0),
                error="middle failed",
            ),
            WindowRun(
                window=AlignmentWindow(2, 20.0, 30.0, 18.0, 30.0),
                text="tail done",
                tokens=[Token("tail", 21.0, 21.2, unit="word")],
                left_overlap_tokens=right_boundary,
                core_text="tail done",
            ),
        ]

        captured_calls: list[tuple[list[object], list[object]]] = []

        def capture_quality(**kwargs: object) -> QualityResult:
            captured_calls.append(
                (
                    list(kwargs["left_overlap_tokens"]),
                    list(kwargs["right_overlap_tokens"]),
                )
            )
            return QualityResult(True, 1.0, 0.0, 0.0, 0.0)

        with patch(
            "asr.providers.qwen_mlx.evaluate_quality",
            side_effect=capture_quality,
        ):
            provider._evaluate_window_qualities(window_runs)

        self.assertEqual(len(captured_calls), 2)
        self.assertEqual(captured_calls[0], ([], []))
        self.assertEqual(captured_calls[1], ([], []))

    def test_alignment_unit_gap_does_not_create_quality_boundary_comparison(self) -> None:
        provider = QwenMlxProvider()
        window_runs = [
            WindowRun(
                window=AlignmentWindow(0, 0.0, 10.0, 0.0, 10.0, alignment_unit_index=0),
                tokens=[Token("left", 1.0, 1.2, unit="word")],
                right_overlap_tokens=[Token("left", 9.8, 10.0, unit="word")],
            ),
            WindowRun(
                window=AlignmentWindow(1, 20.0, 30.0, 20.0, 30.0, alignment_unit_index=1),
                tokens=[Token("right", 21.0, 21.2, unit="word")],
                left_overlap_tokens=[Token("different", 20.0, 20.2, unit="word")],
            ),
        ]

        left, right = provider._quality_boundary_inputs(window_runs, 0)

        self.assertEqual(left, [])
        self.assertEqual(right, [])

    def test_all_windows_fail_raises_explicit_error(self) -> None:
        provider, asr_model, align_model = self._build_provider_with_models(
            asr_responses=[
                RuntimeError("first failed"),
                RuntimeError("second failed"),
                RuntimeError("third failed"),
            ],
            align_responses=[],
        )

        with self.assertRaisesRegex(RuntimeError, "All transcription windows failed"):
            provider.transcribe(Path("demo.wav"))

        self.assertEqual(len(asr_model.calls), 3)
        self.assertEqual(len(align_model.calls), 0)

    def test_zero_duration_transcribe_returns_empty_document(self) -> None:
        provider, asr_model, align_model = self._build_provider_with_models(
            asr_responses=[],
            align_responses=[],
        )
        provider._probe_duration_sec = lambda _: 0.0

        doc = provider.transcribe(Path("demo.wav"))

        self.assertEqual(doc.segments, [])
        self.assertIsNone(doc.detected_language)
        metadata = doc.source_media["provider_metadata"]
        self.assertEqual(metadata["processing_strategy"], "windowed_bounded_alignment")
        self.assertEqual(metadata["window_count"], 0)
        self.assertEqual(metadata["duration_sec"], 0.0)
        self.assertEqual(metadata["quality_pass_count"], 0)
        self.assertEqual(metadata["failed_window_count"], 0)
        self.assertEqual(metadata["window_diagnostics"], [])
        self.assertEqual(asr_model.calls, [])
        self.assertEqual(align_model.calls, [])

    def test_fallback_merge_preserves_text_when_coercing_non_monotonic_tokens(self) -> None:
        provider = QwenMlxProvider()
        window_runs = [
            WindowRun(
                window=AlignmentWindow(0, 10.0, 11.0, 9.0, 12.0),
                text="alpha",
                tokens=[Token("alpha", 10.0, 10.2, unit="word")],
                core_tokens=[Token("alpha", 10.0, 10.2, unit="word")],
            ),
            WindowRun(
                window=AlignmentWindow(1, 11.0, 12.0, 9.0, 13.0),
                text="overlap alpha beta",
                tokens=[
                    Token("overlap", 9.5, 9.8, unit="word"),
                    Token("alpha", 10.0, 10.2, unit="word"),
                    Token("beta", 12.0, 12.2, unit="word"),
                ],
                core_tokens=[],
            ),
        ]

        merged_tokens = provider._merge_window_runs(window_runs)

        self.assertEqual(
            [token.start_time for token in merged_tokens],
            [10.0, 10.0, 10.0, 12.0],
        )
        self.assertEqual(
            [token.text for token in merged_tokens],
            ["alpha", "overlap", "alpha", "beta"],
        )
        self.assertTrue(
            all(
                merged_tokens[idx].start_time >= merged_tokens[idx - 1].start_time
                for idx in range(1, len(merged_tokens))
            )
        )

    def test_alignment_unit_gap_does_not_merge_passing_blocks(self) -> None:
        provider = QwenMlxProvider()
        left = WindowRun(
            window=AlignmentWindow(0, 0.0, 10.0, 0.0, 10.0, alignment_unit_index=0),
            tokens=[Token("left", 1.0, 1.2, unit="word")],
            core_tokens=[Token("left", 1.0, 1.2, unit="word")],
            quality=QualityResult(True, 1.0, 0.0, 0.0, 0.0),
        )
        right = WindowRun(
            window=AlignmentWindow(1, 20.0, 30.0, 20.0, 30.0, alignment_unit_index=1),
            tokens=[Token("right", 21.0, 21.2, unit="word")],
            core_tokens=[Token("right", 21.0, 21.2, unit="word")],
            quality=QualityResult(True, 1.0, 0.0, 0.0, 0.0),
        )

        merged_tokens = provider._merge_window_runs([left, right])

        self.assertEqual([token.text for token in merged_tokens], ["left", "right"])

    def test_owned_tokens_for_block_uses_token_overlap_not_only_start_time(self) -> None:
        provider = QwenMlxProvider()
        window_runs = [
            WindowRun(
                window=AlignmentWindow(0, 105.0, 120.0, 100.0, 125.0),
                text="we have",
            )
        ]
        tokens = [
            Token("we", 104.95, 105.05, unit="word"),
            Token("have", 105.20, 105.50, unit="word"),
        ]

        owned = provider._owned_tokens_for_block(tokens, window_runs)

        self.assertEqual([token.text for token in owned], ["we", "have"])

    def test_resolve_silence_anchor_uses_parsed_anchor_within_bounds(self) -> None:
        provider = QwenMlxProvider()
        provider._active_audio_path = Path("demo.wav")

        stderr = """
[silencedetect @ 0x0] silence_start: 143.0
[silencedetect @ 0x0] silence_end: 145.0 | silence_duration: 2.0
[silencedetect @ 0x0] silence_start: 148.0
[silencedetect @ 0x0] silence_end: 149.0 | silence_duration: 1.0
[silencedetect @ 0x0] silence_start: 170.0
[silencedetect @ 0x0] silence_end: 171.0 | silence_duration: 1.0
"""

        with patch(
            "asr.providers.qwen_mlx.subprocess.run",
            return_value=subprocess.CompletedProcess(
                args=["ffmpeg"],
                returncode=0,
                stdout="",
                stderr=stderr,
            ),
        ) as run_mock:
            anchor = provider._resolve_silence_anchor(147.4, 140.0, 150.0)

        self.assertEqual(anchor, 148.5)
        self.assertEqual(run_mock.call_count, 1)

    def test_stabilize_segments_removes_overlap_and_applies_small_tail_padding(self) -> None:
        provider = QwenMlxProvider()
        segments = [
            Segment(
                id="seg-1",
                text="hello",
                start_time=0.5,
                end_time=1.0,
                language="en",
                tokens=[],
            ),
            Segment(
                id="seg-2",
                text="world",
                start_time=0.8,
                end_time=1.4,
                language="en",
                tokens=[],
            ),
            Segment(
                id="seg-3",
                text="tail",
                start_time=2.0,
                end_time=2.1,
                language="en",
                tokens=[],
            ),
        ]

        stabilized = provider._stabilize_segment_boundaries(
            segments,
            total_duration_sec=2.2,
        )

        self.assertLessEqual(stabilized[0].end_time, stabilized[1].start_time)
        self.assertGreaterEqual(stabilized[0].end_time, 0.8)
        self.assertGreater(stabilized[2].end_time, 2.1)
        self.assertLessEqual(stabilized[2].end_time, 2.2)

    def test_vad_display_bounds_clamp_segment_tail(self) -> None:
        provider = QwenMlxProvider()
        segments = [
            Segment(
                id="seg-1",
                text="hello",
                start_time=104.0,
                end_time=123.0,
                language="en",
                tokens=[],
            )
        ]
        bounds = [
            WindowDisplayBounds(
                start_time=104.8,
                end_time=120.35,
                alignment_unit_index=0,
            )
        ]

        stabilized = provider._stabilize_segment_boundaries(
            segments,
            total_duration_sec=200.0,
            display_bounds=bounds,
        )

        self.assertEqual(stabilized[0].start_time, 104.8)
        self.assertEqual(stabilized[0].end_time, 120.35)

    def test_vad_display_bounds_use_largest_overlap_for_cross_bound_segment(self) -> None:
        provider = QwenMlxProvider()
        segments = [
            Segment(
                id="seg-1",
                text="long cross-bound phrase",
                start_time=15.0,
                end_time=30.0,
                language="en",
                tokens=[],
            )
        ]
        bounds = [
            WindowDisplayBounds(
                start_time=10.0,
                end_time=20.0,
                alignment_unit_index=0,
            ),
            WindowDisplayBounds(
                start_time=20.4,
                end_time=30.0,
                alignment_unit_index=1,
            ),
        ]

        stabilized = provider._stabilize_segment_boundaries(
            segments,
            total_duration_sec=40.0,
            display_bounds=bounds,
        )

        self.assertEqual(stabilized[0].start_time, 20.4)
        self.assertEqual(stabilized[0].end_time, 30.0)


class QwenProviderObservabilityTest(unittest.TestCase):
    def test_provider_emits_window_and_merge_steps(self) -> None:
        provider = QwenMlxProvider()
        provider._probe_duration_sec = lambda _: 140.0
        provider._resolve_silence_anchor = lambda target, left, right: None

        asr_model = FakeModel([FakeChunk("hello world", language="en")])
        align_model = FakeModel(
            [[FakeChunk("hello", start_time=0.0, end_time=0.4)]]
        )
        provider._load_backend = (
            lambda: (lambda model_id: asr_model if "ASR" in model_id else align_model)
        )

        observer = _ProviderRecordingObserver()
        provider.bind_observer(
            observer=observer,
            run_id="run-1",
            file_id="file-1",
            source_path="demo.wav",
        )

        provider.transcribe(Path("demo.wav"))

        step_events = [
            (event.event_type, event.step)
            for event in observer.events
            if event.event_type.startswith("step_")
        ]
        self.assertIn(("step_start", "provider_plan_windows"), step_events)
        self.assertIn(("step_end", "provider_merge"), step_events)
        self.assertTrue(any(step == "provider_window" for _, step in step_events))

    def test_provider_failed_window_emits_step_error_event(self) -> None:
        provider = QwenMlxProvider()
        provider._probe_duration_sec = lambda _: 340.0
        provider._resolve_silence_anchor = lambda target, left, right: None

        asr_model = FakeModel(
            [
                FakeChunk("hello world", language="en"),
                RuntimeError("window exploded"),
                FakeChunk("tail done", language="en"),
            ]
        )
        align_model = FakeModel(
            [
                [
                    FakeChunk("hello", start_time=0.00, end_time=0.45),
                    FakeChunk("world", start_time=0.46, end_time=0.95),
                ],
                [
                    FakeChunk("tail", start_time=0.00, end_time=0.30),
                    FakeChunk("done", start_time=0.31, end_time=0.68),
                ],
            ]
        )
        provider._load_backend = (
            lambda: (lambda model_id: asr_model if "ASR" in model_id else align_model)
        )

        observer = _ProviderRecordingObserver()
        provider.bind_observer(
            observer=observer,
            run_id="run-1",
            file_id="file-1",
            source_path="demo.wav",
        )

        provider.transcribe(Path("demo.wav"))

        self.assertTrue(
            any(
                event.event_type == "step_error" and event.step == "provider_window"
                for event in observer.events
            )
        )


if __name__ == "__main__":
    unittest.main()
