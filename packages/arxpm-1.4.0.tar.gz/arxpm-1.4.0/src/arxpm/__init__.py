"""
title: arxpm package.
"""

__all__ = ["__version__"]

__version__ = "1.4.0"  # semantic-release
