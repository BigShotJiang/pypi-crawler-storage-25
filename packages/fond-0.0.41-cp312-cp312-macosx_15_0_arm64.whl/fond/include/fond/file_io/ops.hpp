#pragma once

#include <cstdlib>
#include <filesystem>
#include <fstream>
#include <stdexcept>
#include <string>
#include <vector>

namespace Fond::FileIO {

namespace fs = std::filesystem;

static inline size_t file_size(FILE* f) {
  if (!f) return 0;
  auto current_pos = ftell(f);
  fseek(f, 0, SEEK_END);
  auto size = ftell(f);
  fseek(f, current_pos, SEEK_SET);
  return static_cast<size_t>(size);
}
inline size_t file_size(const fs::path& path) { return fs::file_size(path); }

struct FileHandle {
    FILE* f;

    FileHandle(const std::filesystem::path &path, const char *mode = "rb")
    : f(fopen(path.c_str(), mode)) {}

    size_t size() const { return Fond::FileIO::file_size(f); }
    int fd() const { return fileno(f); }

    template <typename T> size_t read(T* buffer, size_t count = 1) { return fread(buffer, sizeof(T), count, f); }
    size_t int32_read(int32_t* buffer, size_t count = 1) {return fread(buffer, sizeof(int32_t), count, f);}
    size_t int16_read(int16_t* buffer, size_t count = 1) { return fread(buffer, sizeof(int16_t), count, f); }
    size_t uint16_read(uint16_t* buffer, size_t count = 1) { return fread(buffer, sizeof(uint16_t), count, f); }

    template <typename T> size_t write(const T* buffer, size_t count = 1) {
        return fwrite(buffer, sizeof(T), count, f);
    }

    ~FileHandle() { if (f) fclose(f); }
    operator bool() const { return f != nullptr; }
    operator FILE *() const { return f; }
};

inline std::string read(const fs::path& path) {
    std::ifstream f(path);
    f.seekg(0, std::ios::end);
    auto size = f.tellg();
    f.seekg(0, std::ios::beg);
    std::string content(static_cast<size_t>(size), '\0');
    f.read(content.data(), size);
    return content;
}

inline bool write(const fs::path& path, const std::string& content) {
    std::ofstream f(path);
    if (!f.is_open()) return false;
    f << content;
    return true;
}

inline bool write(const fs::path& path, const char* data, size_t size) {
    std::ofstream f(path, std::ios::binary);
    if (!f.is_open()) return false;
    f.write(data, static_cast<std::streamsize>(size));
    return true;
}

inline void remove_all(const fs::path& path) { fs::remove_all(path); }
inline bool exists(const fs::path& path) { return fs::exists(path); }
inline bool is_file(const fs::path& path) { return fs::is_regular_file(path); }
inline bool is_dir(const fs::path& path) { return fs::is_directory(path); }
inline bool mkdir(const fs::path& path) { return fs::create_directories(path); }

inline bool touch(const fs::path& path, bool create_parents = false) {
    if (create_parents) fs::create_directories(path.parent_path());
    std::ofstream f(path, std::ios::app);
    return f.is_open();
}

} // namespace Fond::FileIO

namespace Fond::pathlib {
namespace fs = std::filesystem;

struct Path;
struct PathDirIter;

using PathIter = std::vector<Path>;

struct Path : public fs::path {
  using fs::path::path;
  mutable std::string str_;

  bool root() const { return is_absolute() && parent_path() == *this; }

  Path to_absolute() const { return Path(fs::absolute(*this)); }

  Path resolve() const {
    try {
      return Path(fs::canonical(*this));
    } catch (const fs::filesystem_error& e) {
      throw std::runtime_error("Failed to resolve path " + string() + ": " + e.what());
    }
  }

  std::string ext_str() const { return extension().string(); }
  std::string name_str() const { return filename().string(); }
  std::string stem_str() const { return filename().stem().string(); }
  std::string filename_str() const { return filename().string(); }
  bool is_symlink() const { return fs::is_symlink(*this); }

  Path parent() const { return Path(parent_path()); }
  std::ifstream open(std::ios::openmode mode = std::ios::in) const { return std::ifstream(*this, mode); }
  std::string read_text() const { return Fond::FileIO::read(*this); }

  std::vector<uint8_t> read_bytes() const {
    std::ifstream f(*this, std::ios::binary | std::ios::ate);
    auto size = f.tellg();
    f.seekg(0, std::ios::beg);
    std::vector<uint8_t> buf(static_cast<size_t>(size));
    if (size > 0) f.read(reinterpret_cast<char*>(buf.data()), size);
    return buf;
  }

  bool write_bytes(const std::vector<uint8_t>& data) const {
    return Fond::FileIO::write(*this, reinterpret_cast<const char*>(data.data()), data.size());
  }

  int count_lines() const {
    std::ifstream f(*this);
    return static_cast<int>(std::count(std::istreambuf_iterator<char>(f), std::istreambuf_iterator<char>(), '\n'));
  }

  fs::file_time_type last_write_time() const { return fs::last_write_time(*this); }

  void remove_all() const { fs::remove_all(*this); }
  static Path canonical(const Path& p) { return Path(fs::canonical(p)); }
  void write_text(const std::string& content) const { Fond::FileIO::write(*this, content); }
  static Path cwd() { return Path(fs::current_path()); }
  static Path home() {
    const char* h = std::getenv("HOME");
    if (!h) throw std::runtime_error("HOME environment variable not set");
    return Path(h);
  }
  bool is_file() const { return fs::is_regular_file(*this); }
  bool is_dir() const { return fs::is_directory(*this); }
  size_t file_size() const { return fs::file_size(*this); }
  bool exists() const { return fs::exists(*this); }
  bool mkdir() const { return fs::create_directories(*this); }
  void chmod(fs::perms permissions) const { fs::permissions(*this, permissions); }
  bool unlink() const { return fs::remove(*this); }
  void copy(const Path& dest) const { fs::copy(*this, dest); }
  void copy_into(const Path& dest_dir) const { fs::copy(*this, dest_dir / filename()); }
  void move(const Path& dest) const { fs::rename(*this, dest); }
  void move_into(const Path& dest_dir) const { fs::rename(*this, dest_dir / filename()); }
  Path rename_to(const Path& new_path) const { fs::rename(*this, new_path); return new_path; }
  const std::string to_string() const { return string(); } 
  Path expanduser() const {
    std::string path_str = string();
    if (!root() && path_str[0] == '~') {
      const char* home = std::getenv("HOME");
      if (!home) throw std::runtime_error("HOME environment variable not set");
      auto it = begin();
      ++it; // skip '~'
      Path result(home);
      for (; it != end(); ++it) result /= *it;
      return result;
    }
    return *this;
  }

  bool has_ext(const std::string &ext) const { return extension() == ext; }
  bool has_ext(const std::string_view ext) const {return extension() == ext; }

  bool name_starts_with(const std::string& prefix) const { return name_str().starts_with(prefix); }
  bool name_ends_with(const std::string& suffix) const { return name_str().ends_with(suffix); }

  Path with_suffix(const std::string& new_suffix) const {
    std::string result = stem_str();
    if (!new_suffix.empty() && new_suffix[0] != '.') result += '.';
    result += new_suffix;
    return Path(this->parent() / result);
  }

  struct PathDirIter {
    struct iterator {
      fs::directory_iterator it;
      Path operator*() const { return Path(it->path()); }
      iterator& operator++() { ++it; return *this; }
      bool operator!=(const iterator& other) const { return it != other.it; }
    };
  
    fs::directory_iterator inner;
    iterator begin() const { return {inner}; }
    iterator end() const { return {fs::directory_iterator{}}; }
  };

  PathDirIter entries() const { return PathDirIter{fs::directory_iterator(*this)}; }

  PathIter path_iter() const {
    PathIter result;
    for (const auto& entry : fs::directory_iterator(*this)) result.emplace_back(entry.path());
    return result;
  }

  PathIter rglob(const std::string& pattern) const {
    PathIter result;
    for (const auto& entry : fs::recursive_directory_iterator(*this)) {
      if (!entry.is_regular_file()) continue;
      Path p(entry.path());
      if (_matches_glob(p.filename_str(), pattern)) result.emplace_back(p);
    }
    return result;
  }

  PathIter glob(const std::string& pattern) const {
    PathIter result;
    for (const auto& entry : fs::directory_iterator(*this)) {
      if (!entry.is_regular_file()) continue;
      Path p(entry.path());
      if (_matches_glob(p.filename_str(), pattern)) result.emplace_back(p);
    }
    return result;
  }

  const char *c_str() const {
      str_ = string();
      return str_.c_str();
  }

private:
  static bool _matches_glob(const std::string& name, const std::string& pattern) {
    if (pattern.empty()) return true;
    if (pattern[0] == '*') {
      std::string suffix = pattern.substr(1);
      if (suffix.empty()) return true;
      return name.size() >= suffix.size() && name.compare(name.size() - suffix.size(), suffix.size(), suffix) == 0;
    }
    return name == pattern;
  }

public:

  bool touch(bool create_parents = false) const {
    if (create_parents) fs::create_directories(parent_path());
    std::ofstream f(*this, std::ios::app);
    return f.is_open();
  }

  Path operator /(const Path& other) const { return Path(fs::path(*this) / other); }
  operator bool() const { return exists(); }

  fs::path to_fs_path() const { return fs::path(*this); }
};

inline Path to_path(const std::string &str) { return Path(str); }
inline Path to_path(fs::path p) { return Path(std::move(p)); }



} // namespace Fond::pathlib
