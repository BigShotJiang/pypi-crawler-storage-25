#pragma once

#include "fond/time/epoch_timestamp.hpp" // IWYU pragma: keep
#include "logger_common.hpp"

#ifdef LOGGER_COLORS
#include "../colors/ansi.hpp"
#endif

#include <cassert>
#include <iostream>
#include <string>
#include <functional>
#include <vector>

#ifdef LOGGER_FILE
#include <filesystem>
#include <fstream>
#endif

namespace Fond::Logging {
using CallbackFunc = std::function<void(char, const std::string&)>;

struct LogLoc {
  std::string_view file;
  std::string_view func;
  int line;
  std::string str() const { return std::format("[{}::{}[{}]]", file, func, line); }
};

class Logger {
private:
  using LogFunc = void (Logger::*)(const std::string &, const std::string &);

  LogLevel level;

  LogFunc info_fn;
  LogFunc warning_fn;
  LogFunc error_fn;
  LogFunc debug_fn;
  LogFunc verbose_fn;

  std::vector<CallbackFunc> callbacks;

  #ifdef LOGGER_FILE
  int max_rotations = LOGGER_FILE_ROTATIONS;
  std::filesystem::path log_file_path;
  std::ofstream log_file;

  void CloseFile() { if (log_file.is_open()) { log_file.close(); } }

  void WriteToFile(const std::string &msg) {
    if (ShouldRotate()) { RotateFiles(); }
    log_file << msg << std::endl;
    log_file.flush();
  }

  void RotateFiles() {
    CloseFile();
    for (int i = max_rotations - 1; i > 0; --i) {
      std::filesystem::path old_path =
          log_file_path.string() + "." + std::to_string(i);
      std::filesystem::path new_path =
          log_file_path.string() + "." + std::to_string(i + 1);
      if (std::filesystem::exists(old_path)) {
        std::filesystem::rename(old_path, new_path);
      }
    }
    std::filesystem::path first_backup = log_file_path.string() + ".1";
    if (std::filesystem::exists(log_file_path)) {
      std::filesystem::rename(log_file_path, first_backup);
    }
    log_file.open(log_file_path, std::ios_base::trunc);
  }

  bool ShouldRotate() {
    if (!log_file.is_open()) return false;
    log_file.seekp(0, std::ios::end);
    return log_file.tellp() >= LOGGER_FILE_MAX_SIZE;
  }
  #endif

  void Log(LogLevel level, const std::string &message, const std::string &prefix) {
    std::string ts = Fond::Time::fast_now();
    #ifdef LOGGER_BUFFER
    LogEntry entry = {level, message, ts};
    logs.push_back(entry);
    #endif
    const std::string level_str = get_prefix(level);
    std::string msg = std::format("{} [{}] {} {}", level_str, ts, prefix, message);
    #ifdef LOGGER_FILE
    WriteToFile(msg);
    #endif
    #if defined(LOGGER_STDOUT) && defined(LOGGER_COLORS)
    std::string style = std::string(get_level_color(level));
    std::string color_msg = std::format("{} [{}] {}{}{}", level_str, ts, style, prefix + message, Ansi::RESET);
    std::cout << color_msg << std::endl;
    #else
    std::cout << msg << std::endl;
    #endif
    #ifdef LOGGER_STDERR
    std::cerr << msg << std::endl;
    #endif
    if (callbacks.empty()) return;
    char lvl = lvl_to_str(level);
    for (const auto &cb : callbacks) cb(lvl, message);
  }

  void _Noop(const std::string &message, const std::string &prefix = "") {}
  void _Info(const std::string &message, const std::string &prefix) {
    Log(LogLevel::INFO, message, prefix);
  }
  void _Warning(const std::string &message, const std::string &prefix) {
    Log(LogLevel::WARNING, message, prefix);
  }
  void _Error(const std::string &message, const std::string &prefix) {
    Log(LogLevel::ERROR, message, prefix);
  }
  void _Debug(const std::string &message, const std::string &prefix) {
    Log(LogLevel::DEBUG, message, prefix);
  }
  void _Verbose(const std::string &message, const std::string &prefix) {
    Log(LogLevel::VERBOSE, message, prefix);
  }

  void SetLevel(LogLevel new_level, bool override = false) {
    level = new_level;
    if (level == LogLevel::NOTSET) {
      info_fn = &Logger::_Noop;
      warning_fn = &Logger::_Noop;
      error_fn = &Logger::_Noop;
      debug_fn = &Logger::_Noop;
      verbose_fn = &Logger::_Noop;
      return;
    }
    info_fn = (level >= LogLevel::INFO) ? &Logger::_Info : &Logger::_Noop;
    
    warning_fn = (level >= LogLevel::WARNING) ? &Logger::_Warning : &Logger::_Noop;
    error_fn = (level >= LogLevel::ERROR) ? &Logger::_Error : &Logger::_Noop;
    debug_fn = (level >= LogLevel::DEBUG) ? &Logger::_Debug : &Logger::_Noop;
#ifdef LOG_VERBOSE_TRUE
    verbose_fn = &Logger::_Verbose;
#else
    if (override) { verbose_fn = &Logger::_Verbose; } else { verbose_fn = &Logger::_Noop; }
#endif
  }

public:
  void add_callback(CallbackFunc cb) { callbacks.push_back(cb); }

#ifdef LOGGER_BUFFER
  static std::vector<LogEntry> logs;

  std::vector<LogEntry> get_logs() const { return logs; }
  std::vector<LogEntry> get_logs(LogLevel min_level) const {
    std::vector<LogEntry> filtered;
    for (const auto &entry : logs) {
      if (entry.level >= min_level) { filtered.push_back(entry); }
    }
    return filtered;
  }
#endif

#ifdef LOGGER_FILE
  Logger(LogLevel level = LogLevel::NOTSET,
         std::filesystem::path path = LOGGER_FILE_PATH,
         int rotations = LOGGER_FILE_ROTATIONS,
         int max_file_size = LOGGER_FILE_MAX_SIZE)
      : level(level), max_rotations(rotations), log_file_path(path) {
    SetLevel(level);
    log_file.open(path, std::ios_base::app);
    //printf("Logger initialized with level %d, mode %d, file path '%s', rotations %d, max size %d bytes\n",
    //       level, mode, path.string().c_str(), rotations, max_file_size);
  }
  ~Logger() { if (log_file.is_open()) log_file.close(); }
#else
  Logger (LogLevel level = LogLevel::NOTSET)
      : level(level) {
    SetLevel(level);
    //printf("Logger initialized with level %d and mode %d\n", level, mode);
  }
  ~Logger() = default;
#endif

  void Info(const std::string &message, const std::string &prefix = "") {
    (this->*info_fn)(message, prefix);
  }
  
  template<typename... Args> requires (sizeof...(Args) > 0)
  void Info(std::format_string<Args...> fmt, Args&&... args) {
    Info(std::format(fmt, std::forward<Args>(args)...));
  }

  void Info_(LogLoc loc, const std::string& msg) {
    Info(std::string(msg + loc.str()));
  }

  template<typename... Args> requires (sizeof...(Args) > 0)
  void Info_(LogLoc loc, std::format_string<Args...> fmt, Args&&... args) {
    Info_(loc, std::format(fmt, std::forward<Args...>(args)...));
  }

  void Warning(const std::string &message, const std::string &prefix = "") {
    (this->*warning_fn)(message, prefix);
  }

  template <typename... Args> requires (sizeof...(Args) > 0)
  void Warning(std::format_string<Args...> fmt, Args&&... args) {
    Warning(std::format(fmt, std::forward<Args>(args)...));
  }

  void Warning_(LogLoc loc, const std::string& msg) {
    Warning(std::string(msg + loc.str()));
  }

  template<typename... Args> requires (sizeof...(Args) > 0)
  void Warning_(LogLoc loc, std::format_string<Args...> fmt, Args&&... args) {
    Warning_(loc, std::format(fmt, std::forward<Args>(args)...));
  }

  void Error(const std::string &message, const std::string &prefix = "") {
    (this->*error_fn)(message, prefix);
  }

  template<typename... Args> requires (sizeof...(Args) > 0)
  void Error(std::format_string<Args...> fmt, Args&&... args) {
    Error(std::format(fmt, std::forward<Args>(args)...));
  }

  void Error_(LogLoc loc, const std::string& msg) {
    Error(std::string(msg + loc.str()));
  }

  template<typename... Args> requires (sizeof...(Args) > 0)
  void Error_(LogLoc loc, std::format_string<Args...> fmt, Args&&... args) {
    Error_(loc, std::format(fmt, std::forward<Args>(args)...));
  }

  void Debug(const std::string &message, const std::string &prefix = "") {
    (this->*debug_fn)(message, prefix);
  }

  template<typename... Args> requires (sizeof...(Args) > 0)
  void Debug(std::format_string<Args...> fmt, Args&&... args) {
    Debug(std::format(fmt, std::forward<Args>(args)...));
  }

  void Debug_(LogLoc loc, const std::string& msg) {
    Debug(std::string(msg + loc.str()));
  }

  template<typename... Args> requires (sizeof...(Args) > 0)
  void Debug_(LogLoc loc, std::format_string<Args...> fmt, Args&&... args) {
    Debug_(loc, std::format(fmt, std::forward<Args>(args)...));
  }

  void Verbose(const std::string &message, const std::string &prefix = "") {
    (this->*verbose_fn)(message, prefix);
  }

  template<typename... Args> requires (sizeof...(Args) > 0)
  void Verbose(std::format_string<Args...> fmt, Args&&... args) {
    Verbose(std::format(fmt, std::forward<Args>(args)...));
  }

  void Verbose_(LogLoc loc, const std::string& msg) {
    Verbose(std::string(msg + loc.str()));
  } 
  
  template<typename... Args> requires (sizeof...(Args) > 0)
  void Verbose_(LogLoc loc, std::format_string<Args...> fmt, Args&&... args) {
    Verbose_(loc, std::format(fmt, std::forward<Args>(args)...));
  }

  #ifdef LOGGER_COLORS
  void Print(const std::string &message, const std::string &prefix = "", const std::string &style = "") {
    std::string styled_message = style + message + Ansi::RESET;
  #else
  void Print(const std::string &message, const std::string &prefix = "") {
    std::string styled_message = message;
    #endif
    std::cout << prefix << styled_message << std::endl;
  }

  template <typename... Args> requires (sizeof...(Args) > 0)
  void Print(std::format_string<Args...> fmt, Args&&... args) {
    Print(std::format(fmt, std::forward<Args>(args)...));
  }

  #ifdef LOGGER_COLORS
  void KeyValue(const std::string &key, const std::string &value,
                const std::string &prefix = "", const std::string &style1 = "",
                const std::string &style2 = "") {
    std::string styled_key = style1 + key + Ansi::RESET;
    std::string styled_value = style2 + value + Ansi::RESET;
#else
  void KeyValue(const std::string &key, const std::string &value,
                const std::string &prefix = "") {
    std::string styled_key = key;
    std::string styled_value = value;
    #endif
    std::cout << prefix << styled_key << ": " << styled_value << std::endl;
  }
};

// TODO: Add a flag to not create a global logger instance but needs to be backwards compatible
#ifdef LOGGER_FILE
inline Logger g_logger(_build_log_level(), LOGGER_FILE_PATH, LOGGER_FILE_ROTATIONS, LOGGER_FILE_MAX_SIZE);
#else
inline Logger g_logger(_build_log_level());
#endif

#ifdef LOGGER_BUFFER
inline std::vector<LogEntry> Logger::logs;
#endif

} // namespace Fond::Logging

#ifdef __FILE_NAME__
#define SHORT_FILE __FILE_NAME__
#else
#define SHORT_FILE __FILE__
#endif

// TODO: Needs to be fixed.
#ifdef LOG_VERBOSE_TRUE
#define LOG_V(msg)                                                             \
   Fond::Logging::g_logger.Verbose(msg, std::format("[{}::{}[{}]]",             \
   SHORT_FILE, __func__, __LINE__))
#define LOG_ERR(msg)                                                           \
   Fond::Logging::g_logger.Error(msg, std::format("[{}::{}[{}]]",               \
   SHORT_FILE, __func__, __LINE__))
#define LOG_ASSERT(expr, msg)                                                  \
  do {                                                                         \
    if (!(expr)) {                                                             \
    const std::string _assert_msg = std::format("Assertion failed: {}", msg);  \
    const std::string _assert_loc = std::format("[{}::{}[{}]]",                \
        SHORT_FILE, __func__, __LINE__);                                       \
    Fond::Logging::g_logger.Error(_assert_msg, _assert_loc);                   \
    assert(expr);                                                              \
  }                                                                            \
}                                                                              \
while (0)
#else
#define LOG_V(msg)
#define LOG_ERR(msg)
#define LOG_ASSERT(expr, msg)
#endif
