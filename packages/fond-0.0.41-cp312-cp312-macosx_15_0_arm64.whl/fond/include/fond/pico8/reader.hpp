#pragma once

#include <dlfcn.h>
#include <cstdlib>
#include <filesystem>
#include <optional>
#include <stdexcept>
#include <string>
#include <string_view>

#include "fond/cpp_tree_sitter.hpp"
#include "fond/file_io/ops.hpp"
#include "fond/pico8/ast_symbols.hpp"
#include "fond/pico8/value.hpp"

namespace Fond::Pico8 {

static inline ts::Language load_pico8_language(const char* so_path = nullptr) {
    using TSLangFn = TSLanguage*(*)();
    static std::optional<ts::Language> cached_lang = std::nullopt;
    if (cached_lang.has_value()) return cached_lang.value();

    auto fn = reinterpret_cast<TSLangFn>(dlsym(RTLD_DEFAULT, "tree_sitter_pico8"));
    if (fn) { cached_lang = fn(); return cached_lang.value(); }

#ifdef FOND_PICO8_PARSER_SO
    const char* path = so_path ? so_path : FOND_PICO8_PARSER_SO;
#else
    const char* path = so_path ? so_path : std::getenv("FOND_PICO8_PARSER_SO");
#endif
    if (!path) throw std::runtime_error("tree_sitter_pico8 not found. Set FOND_PICO8_PARSER_SO or link pico8_parser.o");
    void* lib = dlopen(path, RTLD_LAZY);
    if (!lib) throw std::runtime_error(std::string("dlopen: ") + dlerror());
    fn = reinterpret_cast<TSLangFn>(dlsym(lib, "tree_sitter_pico8"));
    if (!fn) throw std::runtime_error(std::string("dlsym: ") + dlerror());
    cached_lang = fn();
    return cached_lang.value();
}

class Reader {
    ts::Parser parser_;
    Arena arena_;
    std::string source_; // owned copy; AST string_views slice into this

    // Allocate a node of type T into the arena. Nodes with NodeList fields need
    // the arena at construction; a requires-clause picks the right overload.
    template <typename T, typename... Args>
    T* make(Args&&... args) requires std::is_constructible_v<T, Args...> {
        return arena_.create<T>(std::forward<Args>(args)...);
    }

    std::string_view text_of(ts::Node n) {
        return n.getSourceRange(source_);
    }

    uint32_t start_of(ts::Node n) { return static_cast<uint32_t>(n.getByteRange().start); }
    uint32_t end_of(ts::Node n) { return static_cast<uint32_t>(n.getByteRange().end); }

    void set_span(NodePtr node, ts::Node ts_node) {
        if (!node) return;
        node->source_start = start_of(ts_node);
        node->source_end = end_of(ts_node);
    }

    // Pick the first named, non-comment child. Tree-sitter anonymous keyword
    // nodes (e.g. "if", "then") are unnamed — we skip them.
    std::optional<ts::Node> first_named_child(ts::Node n) {
        for (auto c : ts::Children{n}) {
            if (c.isNamed() && c.getSymbol() != sym::sym_comment) return c;
        }
        return std::nullopt;
    }

    // Dispatcher-friendly: builds from the first named child, or returns nullptr
    // if there isn't one. Used from the main switch where "wrapper node → pass
    // through to child" is the common idiom.
    NodePtr build_first_child(ts::Node n) {
        auto c = first_named_child(n);
        return c ? build(*c) : nullptr;
    }

    NodePtr unknown_from(ts::Node n) {
        auto* u = make<UnknownNode>(n.getType(), text_of(n));
        set_span(u, n);
        return u;
    }

    // Dispatch a Tree-sitter node to the appropriate AST builder.
    NodePtr build(ts::Node n) {
        if (n.isNull()) return nullptr;
        auto sym = n.getSymbol();
        switch (sym) {
            case sym::sym_program:              return build_program(n);
            case sym::sym__statement:           return build_first_child(n);
            case sym::sym__chunk:               return build_chunk_as_block(n);
            case sym::sym__block: {
                auto inner = first_named_child(n);
                return inner ? build_chunk_as_block(*inner) : nullptr;
            }

            case sym::sym_nil:                  return build_nil(n);
            case sym::sym_boolean:              return build_boolean(n);
            case sym::sym_number:               return build_number(n);
            case sym::sym_string:               return build_string(n);
            case sym::sym_ellipsis:             return build_ellipsis(n);
            case sym::sym_identifier:           return build_identifier(n);

            case sym::sym_variable_declaration: return build_local_or_assign(n);
            case sym::sym_compound_assignment:  return build_compound_assign(n);
            case sym::sym_function_call:        return build_function_call(n);
            case sym::sym_return_statement:     return build_return(n);
            case sym::sym_break_statement:      return build_break(n);
            case sym::sym_goto_statement:       return build_goto(n);
            case sym::sym_label_statement:      return build_label(n);
            case sym::sym_print_statement:      return build_print(n);

            case sym::sym_if_statement:         return build_if(n);
            case sym::sym_short_if_statement:   return build_short_if(n);
            case sym::sym_while_statement:      return build_while(n);
            case sym::sym_short_while_statement: return build_short_while(n);
            case sym::sym_repeat_statement:     return build_repeat(n);
            case sym::sym_do_statement:         return build_do(n);
            case sym::sym_for_statement:        return build_for(n);
            case sym::sym_function_statement:   return build_function_stmt(n);

            case sym::sym_binary_operation:     return build_binary_op(n);
            case sym::sym_unary_operation:      return build_unary_op(n);
            case sym::sym_tableconstructor:     return build_table_ctor(n);
            case sym::sym_function:             return build_function_expr(n);

            default: return unknown_from(n);
        }
    }

    // ---- builders ----------------------------------------------------------

    NodePtr build_program(ts::Node n) {
        auto* p = make<ProgramNode>(arena_);
        set_span(p, n);
        for (auto c : ts::Children{n}) {
            if (!c.isNamed() || c.getSymbol() == sym::sym_comment) continue;
            auto* child = build(c);
            if (!child) continue;
            if (child->kind == NodeKind::Return) p->trailing_return = child;
            else p->statements.push_back(child);
        }
        return p;
    }

    NodePtr build_chunk_as_block(ts::Node n) {
        if (n.isNull()) return nullptr;
        auto* b = make<BlockNode>(arena_);
        set_span(b, n);
        for (auto c : ts::Children{n}) {
            if (!c.isNamed() || c.getSymbol() == sym::sym_comment) continue;
            auto* child = build(c);
            if (child) b->statements.push_back(child);
        }
        return b;
    }

    NodePtr build_nil(ts::Node n)       { auto* x =      make<NilNode>();            set_span(x, n); return x; }
    NodePtr build_ellipsis(ts::Node n)  { auto* x = make<EllipsisNode>();       set_span(x, n); return x; }
    NodePtr build_break(ts::Node)       { return make<BreakNode>(); }

    NodePtr build_boolean(ts::Node n) {
        auto* x = make<BooleanNode>(text_of(n) == "true");
        set_span(x, n);
        return x;
    }

    NodePtr build_number(ts::Node n) {
        auto* x = make<NumberNode>(text_of(n));
        set_span(x, n);
        return x;
    }

    NodePtr build_string(ts::Node n) {
        // Content child is the unescaped body (external scanner); fall back to
        // full text if it's missing (empty string).
        auto* x = make<StringNode>(text_of(n));
        set_span(x, n);
        return x;
    }

    NodePtr build_identifier(ts::Node n) {
        auto* x = make<IdentifierNode>(text_of(n));
        set_span(x, n);
        return x;
    }

    // variable_declaration handles both `local a = 1` and `a = 1`. We split
    // on the presence of the `local` child and build the node directly into
    // the target's NodeList — avoids the "construct locally then move" dance
    // which trips the most-vexing-parse when building ArenaAlloc-wrapped vectors.
    NodePtr build_local_or_assign(ts::Node n) {
        bool is_local = false;
        for (auto c : ts::Children{n}) {
            if (c.isNamed() && c.getSymbol() == sym::sym_local) { is_local = true; break; }
        }

        NodePtr result = nullptr;
        NodeList* names_target;
        NodeList* values_target;

        if (is_local) {
            auto* d = make<LocalDeclNode>(arena_);
            names_target = &d->names;
            values_target = &d->values;
            result = d;
        } else {
            auto* a = make<AssignmentNode>(arena_);
            names_target = &a->targets;
            values_target = &a->values;
            result = a;
        }
        set_span(result, n);

        for (auto c : ts::Children{n}) {
            if (!c.isNamed()) continue;
            auto s = c.getSymbol();
            if (s == sym::sym_local || s == sym::sym_comment) continue;
            if (s == sym::sym_variable_declarator) {
                auto inner = first_named_child(c);
                if (inner) {
                    if (auto* nm = build(*inner)) names_target->push_back(nm);
                }
            } else {
                if (auto* v = build(c)) values_target->push_back(v);
            }
        }
        return result;
    }

    NodePtr build_compound_assign(ts::Node n) {
        auto* ca = make<CompoundAssignNode>();
        set_span(ca, n);
        auto name = n.getChildByFieldName("name");
        auto op = n.getChildByFieldName("op");
        auto val = n.getChildByFieldName("value");
        if (!name.isNull()) ca->target = build_first_child(name);
        if (!op.isNull()) ca->op = text_of(op);
        if (!val.isNull()) ca->value = build(val);
        return ca;
    }

    NodePtr build_function_call(ts::Node n) {
        auto* fc = make<FunctionCallNode>(arena_);
        set_span(fc, n);
        auto prefix = n.getChildByFieldName("prefix");
        if (!prefix.isNull()) fc->callee = build_first_child(prefix);
        auto args = n.getChildByFieldName("args");
        if (!args.isNull()) {
            // args may be function_arguments, a string, or a tableconstructor.
            if (args.getSymbol() == sym::sym_function_arguments) {
                for (auto c : ts::Children{args}) {
                    if (!c.isNamed() || c.getSymbol() == sym::sym_comment) continue;
                    if (auto* a = build(c)) fc->args.push_back(a);
                }
            } else if (auto* a = build(args)) {
                fc->args.push_back(a);
            }
        }
        return fc;
    }

    NodePtr build_return(ts::Node n) {
        auto* r = make<ReturnNode>(arena_);
        set_span(r, n);
        for (auto c : ts::Children{n}) {
            if (!c.isNamed() || c.getSymbol() == sym::sym_comment) continue;
            if (auto* v = build(c)) r->values.push_back(v);
        }
        return r;
    }

    NodePtr build_goto(ts::Node n) {
        auto* g = make<GotoNode>();
        set_span(g, n);
        if (auto ident = first_named_child(n)) g->label = text_of(*ident);
        return g;
    }

    NodePtr build_label(ts::Node n) {
        auto* l = make<LabelNode>();
        set_span(l, n);
        if (auto ident = first_named_child(n)) l->name = text_of(*ident);
        return l;
    }

    NodePtr build_print(ts::Node n) {
        auto* p = make<PrintNode>(arena_);
        set_span(p, n);
        for (auto c : ts::Children{n}) {
            if (!c.isNamed() || c.getSymbol() == sym::sym_comment) continue;
            if (auto* v = build(c)) p->values.push_back(v);
        }
        return p;
    }

    NodePtr build_if(ts::Node n) {
        auto* i = make<IfNode>(arena_);
        set_span(i, n);
        // IfStatement's children alternate: cond, body, cond, body, ..., else-body.
        // We collect exprs and blocks in order and pair them.
        NodePtr pending_cond = nullptr;
        for (auto c : ts::Children{n}) {
            if (!c.isNamed() || c.getSymbol() == sym::sym_comment) continue;
            auto s = c.getSymbol();
            if (s == sym::sym__chunk || s == sym::sym__block) {
                NodePtr body = build_chunk_as_block(c);
                if (pending_cond) {
                    i->branches.push_back({pending_cond, body});
                    pending_cond = nullptr;
                } else {
                    i->else_body = body;
                }
            } else {
                pending_cond = build(c);
            }
        }
        return i;
    }

    NodePtr build_short_if(ts::Node n) {
        auto* si = make<ShortIfNode>();
        set_span(si, n);
        auto cond = n.getChildByFieldName("cond");
        if (!cond.isNull()) si->cond = build(cond);
        auto cons = n.getChildByFieldName("consequence");
        if (!cons.isNull()) si->consequence = build(cons);
        auto alt = n.getChildByFieldName("alternative");
        if (!alt.isNull()) si->alternative = build(alt);
        return si;
    }

    NodePtr build_while(ts::Node n) {
        auto* w = make<WhileNode>();
        set_span(w, n);
        auto cond = n.getChildByFieldName("cond");
        if (!cond.isNull()) w->cond = build(cond);
        for (auto c : ts::Children{n}) {
            if (c.isNamed() && (c.getSymbol() == sym::sym__chunk || c.getSymbol() == sym::sym__block)) {
                w->body = build_chunk_as_block(c);
            }
        }
        return w;
    }

    NodePtr build_short_while(ts::Node n) {
        auto* sw = make<ShortWhileNode>();
        set_span(sw, n);
        auto cond = n.getChildByFieldName("cond");
        if (!cond.isNull()) sw->cond = build(cond);
        auto body = n.getChildByFieldName("body");
        if (!body.isNull()) sw->body = build(body);
        return sw;
    }

    NodePtr build_repeat(ts::Node n) {
        auto* r = make<RepeatNode>();
        set_span(r, n);
        bool body_set = false;
        for (auto c : ts::Children{n}) {
            if (!c.isNamed() || c.getSymbol() == sym::sym_comment) continue;
            if (!body_set && (c.getSymbol() == sym::sym__chunk || c.getSymbol() == sym::sym__block)) {
                r->body = build_chunk_as_block(c);
                body_set = true;
            } else {
                r->cond = build(c);
            }
        }
        return r;
    }

    NodePtr build_do(ts::Node n) {
        auto* d = make<DoNode>();
        set_span(d, n);
        for (auto c : ts::Children{n}) {
            if (c.isNamed() && (c.getSymbol() == sym::sym__chunk || c.getSymbol() == sym::sym__block)) {
                d->body = build_chunk_as_block(c);
                break;
            }
        }
        return d;
    }

    NodePtr build_for(ts::Node n) {
        // Grammar nests the concrete form as for_numeric or for_generic.
        for (auto c : ts::Children{n}) {
            if (!c.isNamed()) continue;
            if (c.getSymbol() == sym::sym_for_numeric) return build_for_numeric(c, n);
            if (c.getSymbol() == sym::sym_for_generic) return build_for_generic(c, n);
        }
        return unknown_from(n);
    }

    NodePtr build_for_numeric(ts::Node spec, ts::Node outer) {
        auto* f = make<ForNumericNode>();
        set_span(f, outer);
        auto var = spec.getChildByFieldName("var");
        auto start = spec.getChildByFieldName("start");
        auto finish = spec.getChildByFieldName("finish");
        auto step = spec.getChildByFieldName("step");
        if (!var.isNull()) f->var = text_of(var);
        if (!start.isNull()) f->start = build(start);
        if (!finish.isNull()) f->finish = build(finish);
        if (!step.isNull()) f->step = build(step);
        for (auto c : ts::Children{outer}) {
            if (c.isNamed() && (c.getSymbol() == sym::sym__chunk || c.getSymbol() == sym::sym__block)) {
                f->body = build_chunk_as_block(c);
                break;
            }
        }
        return f;
    }

    NodePtr build_for_generic(ts::Node spec, ts::Node outer) {
        auto* f = make<ForGenericNode>(arena_);
        set_span(f, outer);
        auto idl = spec.getChildByFieldName("identifier_list");
        if (!idl.isNull()) {
            for (auto c : ts::Children{idl}) {
                if (c.isNamed() && c.getSymbol() == sym::sym_identifier) {
                    if (auto* id = build(c)) f->names.push_back(id);
                }
            }
        }
        auto el = spec.getChildByFieldName("expression_list");
        if (!el.isNull()) {
            for (auto c : ts::Children{el}) {
                if (!c.isNamed() || c.getSymbol() == sym::sym_comment) continue;
                if (auto* e = build(c)) f->exprs.push_back(e);
            }
        }
        for (auto c : ts::Children{outer}) {
            if (c.isNamed() && (c.getSymbol() == sym::sym__chunk || c.getSymbol() == sym::sym__block)) {
                f->body = build_chunk_as_block(c);
                break;
            }
        }
        return f;
    }

    // The grammar wraps function bodies with `alias(..., "function_body")`.
    // Tree-sitter assigns the aliased node its own symbol ID
    // (alias_sym_function_body), distinct from the underlying _block symbol,
    // so we dispatch on the alias symbol directly.
    NodePtr build_function_body_alias(ts::Node n) {
        // Iterate the aliased body's children as statements — the alias holds
        // a _block whose only child is a _chunk; skipping straight to the
        // chunk's statements avoids a redundant Block wrapper.
        auto* b = make<BlockNode>(arena_);
        set_span(b, n);
        for (auto c : ts::Children{n}) {
            if (!c.isNamed() || c.getSymbol() == sym::sym_comment) continue;
            if (c.getSymbol() == sym::sym__chunk || c.getSymbol() == sym::sym__block) {
                for (auto inner : ts::Children{c}) {
                    if (!inner.isNamed() || inner.getSymbol() == sym::sym_comment) continue;
                    if (auto* s = build(inner)) b->statements.push_back(s);
                }
            } else if (auto* s = build(c)) {
                b->statements.push_back(s);
            }
        }
        return b;
    }

    void collect_function_parts(ts::Node n, NodeList& params, bool& varargs, NodePtr& body) {
        for (auto c : ts::Children{n}) {
            if (!c.isNamed()) continue;
            auto s = c.getSymbol();
            if (s == sym::sym_parameter_list) {
                for (auto p : ts::Children{c}) {
                    if (!p.isNamed()) continue;
                    if (p.getSymbol() == sym::sym_ellipsis) { varargs = true; continue; }
                    if (auto* id = build(p)) params.push_back(id);
                }
            } else if (s == sym::sym__chunk || s == sym::sym__block) {
                body = build_chunk_as_block(c);
            } else if (s == sym::alias_sym_function_body) {
                body = build_function_body_alias(c);
            }
        }
    }

    NodePtr build_function_stmt(ts::Node n) {
        auto* f = make<FunctionStmtNode>(arena_);
        set_span(f, n);
        auto name = n.getChildByFieldName("name");
        if (!name.isNull()) {
            if (name.getSymbol() == sym::sym_identifier) {
                if (auto* id = build(name)) f->name_parts.push_back(id);
            } else if (name.getSymbol() == sym::sym_function_name) {
                for (auto c : ts::Children{name}) {
                    if (c.isNamed() && c.getSymbol() == sym::sym_identifier) {
                        if (auto* id = build(c)) f->name_parts.push_back(id);
                    }
                }
            }
        }
        for (auto c : ts::Children{n}) {
            if (c.isNamed() && c.getSymbol() == sym::sym_local) { f->is_local = true; break; }
        }
        collect_function_parts(n, f->params, f->varargs, f->body);
        return f;
    }

    NodePtr build_function_expr(ts::Node n) {
        auto* f = make<FunctionExprNode>(arena_);
        set_span(f, n);
        collect_function_parts(n, f->params, f->varargs, f->body);
        return f;
    }

    NodePtr build_binary_op(ts::Node n) {
        auto* b = make<BinaryOpNode>();
        set_span(b, n);
        // children: expr, op-token (anonymous), expr
        std::optional<ts::Node> lhs, rhs;
        std::string_view op_text;
        for (auto c : ts::Children{n}) {
            if (c.isNamed()) {
                if (!lhs) lhs = c;
                else rhs = c;
            } else if (lhs && !rhs) {
                op_text = text_of(c);
            }
        }
        if (lhs) b->lhs = build(*lhs);
        if (rhs) b->rhs = build(*rhs);
        b->op = op_text;
        return b;
    }

    NodePtr build_unary_op(ts::Node n) {
        auto* u = make<UnaryOpNode>();
        set_span(u, n);
        std::string_view op_text;
        std::optional<ts::Node> operand;
        for (auto c : ts::Children{n}) {
            if (!c.isNamed()) { if (op_text.empty()) op_text = text_of(c); }
            else operand = c;
        }
        u->op = op_text;
        if (operand) u->operand = build(*operand);
        return u;
    }

    NodePtr build_table_ctor(ts::Node n) {
        auto* t = make<TableConstructorNode>(arena_);
        set_span(t, n);
        for (auto c : ts::Children{n}) {
            if (!c.isNamed()) continue;
            if (c.getSymbol() == sym::sym_fieldlist) {
                for (auto f : ts::Children{c}) {
                    if (!f.isNamed() || f.getSymbol() != sym::sym_field) continue;
                    t->fields.push_back(build_table_field(f));
                }
            }
        }
        return t;
    }

    NodePtr build_table_field(ts::Node n) {
        auto* tf = make<TableFieldNode>();
        set_span(tf, n);

        // The grammar's `_named_field_expression` / `_expression_field_expression`
        // rules are hidden (underscore-prefixed in Tree-sitter), which inlines
        // their children into the parent `field` node. So we read `name`/`key`/
        // `value` field names directly off `n` rather than walking through a
        // nested wrapper node. Fall back to "positional field = only child is
        // the value expression" when no field names are present.
        auto name = n.getChildByFieldName("name");
        auto key  = n.getChildByFieldName("key");
        auto val  = n.getChildByFieldName("value");

        if (!name.isNull()) {
            tf->key_name = text_of(name);
            if (!val.isNull()) tf->value = build(val);
            return tf;
        }
        if (!key.isNull()) {
            tf->key_expr = build(key);
            if (!val.isNull()) tf->value = build(val);
            return tf;
        }

        // Positional: no key — the first named child IS the value expression.
        auto inner_opt = first_named_child(n);
        if (inner_opt) tf->value = build(*inner_opt);
        return tf;
    }

public:
    Reader(size_t arena_block_size = 8192)
        : parser_(load_pico8_language()), arena_(arena_block_size) {}

    // Parse and return the root ProgramNode. The returned node lives in this
    // reader's arena — do not outlive the Reader.
    NodePtr parse(std::string_view src) {
        arena_.reset();
        source_.assign(src.data(), src.size());
        auto tree = parser_.parseString(source_);
        if (tree.hasError()) {
            throw std::runtime_error("pico8 reader: syntax error in input");
        }
        return build(tree.getRootNode());
    }

    NodePtr parse_file(const std::filesystem::path& path) {
        auto content = Fond::FileIO::read(path);
        return parse(content);
    }

    Arena& arena() { return arena_; }
    std::string_view source() const { return source_; }
};

} // namespace Fond::Pico8
