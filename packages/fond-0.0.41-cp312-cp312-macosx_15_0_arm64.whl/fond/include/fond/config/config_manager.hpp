#pragma once

#include "../toml/reader.hpp"
#include "../toml/writer.hpp"
#include "../toml/value.hpp"
#include "../collections/arena.hpp"

#include <cstdlib>
#include <filesystem>

extern "C" char** environ;
#include <optional>
#include <string>
#include <vector>

namespace fs = std::filesystem;

namespace Fond::Config {

constexpr std::string_view TOML_EXT = ".toml";
constexpr std::string_view HOME_ENV = "HOME";
constexpr std::string_view DOT_CONFIG = ".config";
constexpr std::string_view DEFAULT_TOML = "default.toml";
constexpr std::string_view LOCAL_TOML = "local.toml";
constexpr std::string_view DEFAULT_ENV = "dev";

using Fond::Toml::Reader;
using Fond::Toml::TomlValue;
using Fond::Toml::TomlStr;
using Fond::Toml::Writer;
using Fond::Toml::toml::table;

inline ArenaString K(const char* s, CollectionsCub::Arena& arena) {
    return ArenaString(s, ArenaAlloc<char>(arena));
}
inline table make_table(CollectionsCub::Arena& arena) {
    return table{ArenaAlloc<std::pair<const ArenaString, TomlValue>>(arena)};
}

namespace detail {

inline table deep_merge(const table& base, const table& override_tbl, CollectionsCub::Arena& arena) {
    auto result = make_table(arena);
    for (const auto& [key, val] : base) result.insert(key, val);
    for (const auto& [key, val] : override_tbl) {
        auto it = result.find(key);
        if (it != result.end() && it->second.is_table() && val.is_table())
            result[key] = TomlValue(deep_merge(it->second.as_table(), val.as_table(), arena));
        else
            result[key] = val;
    }
    return result;
}

inline std::string to_upper(std::string s) {
    for (auto& c : s) c = static_cast<char>(std::toupper(static_cast<unsigned char>(c)));
    return s;
}

inline table env_overrides(const std::string& prefix, CollectionsCub::Arena& arena) {
    auto result = make_table(arena);
    for (char** env = environ; *env; ++env) {
        std::string entry = *env;
        auto eq = entry.find('=');
        if (eq == std::string::npos) continue;

        std::string key = entry.substr(0, eq);
        std::string value = entry.substr(eq + 1);
        if (!key.starts_with(prefix)) continue;

        std::string clean = key.substr(prefix.size());
        for (auto& c : clean) c = static_cast<char>(std::tolower(static_cast<unsigned char>(c)));

        table* current = &result;
        size_t pos = 0;
        std::vector<std::string> parts;
        while ((pos = clean.find('_')) != std::string::npos) {
            parts.push_back(clean.substr(0, pos));
            clean.erase(0, pos + 1);
        }
        parts.push_back(clean);

        for (size_t i = 0; i < parts.size() - 1; ++i) {
            auto& slot = (*current)[K(parts[i].c_str(), arena)];
            if (slot.is_none()) slot = TomlValue(make_table(arena));
            current = &slot.as_table();
        }

        if (value == "true" || value == "True") {
            (*current)[K(parts.back().c_str(), arena)] = Toml::TOML_TRUE;
        } else if (value == "false" || value == "False") {
            (*current)[K(parts.back().c_str(), arena)] = Toml::TOML_FALSE;
        } else {
            (*current)[K(parts.back().c_str(), arena)] = TomlValue(K(value.c_str(), arena));
        }
    }
    return result;
}

} // namespace detail

template <typename ConfigType>
class ConfigManager {
    std::string program_name_;
    std::string env_;
    std::vector<fs::path> search_paths_;
    std::optional<ConfigType> cached_;
    Reader reader_;

    std::string prefix() const { return detail::to_upper(program_name_) + "_"; }

    std::vector<fs::path> default_search_paths() const {
        std::vector<fs::path> paths;
        const char* home = std::getenv(HOME_ENV.data());
        if (home) {
            fs::path config_dir = fs::path(home) / DOT_CONFIG / program_name_;
            paths.push_back(config_dir / DEFAULT_TOML);
            paths.push_back(config_dir / (env_ + TOML_EXT));
            paths.push_back(config_dir / LOCAL_TOML);
        }
        fs::path local_dir = fs::current_path() / "config" / program_name_;
        paths.push_back(local_dir / DEFAULT_TOML);
        paths.push_back(local_dir / (env_ + TOML_EXT));
        paths.push_back(local_dir / LOCAL_TOML);
        return paths;
    }

public:
    ConfigManager(const std::string& program_name, const std::string& env = DEFAULT_ENV.data())
        : program_name_(program_name), env_(env), search_paths_(default_search_paths()) {}

    ConfigManager(const std::string& program_name, std::vector<fs::path> paths, const std::string& env = DEFAULT_ENV.data())
        : program_name_(program_name), env_(env), search_paths_(std::move(paths)) {}

    ConfigType load() {
        reader_.reset();
        CollectionsCub::Arena arena(1024 * 64);
        auto merged = make_table(arena);

        for (const auto& path : search_paths_) {
            if (!fs::exists(path)) continue;
            auto doc = reader_.parse_file_no_reset(path);
            if (doc.is_table()) merged = detail::deep_merge(merged, doc.as_table(), arena);
        }

        auto env_vars = detail::env_overrides(prefix(), arena);
        if (!env_vars.empty()) merged = detail::deep_merge(merged, env_vars, arena);

        cached_ = ConfigType::toml_unpack(merged);
        reader_.reset();
        // arena dies here — safe because toml_unpack copied everything to std::string fields
        return *cached_;
    }

    const ConfigType& config() const { if (!cached_) throw std::runtime_error("Config not loaded. Call load() first."); return *cached_; }

    ConfigType& config() { if (!cached_) load(); return *cached_; }
    ConfigType reload() { cached_.reset(); return load(); }

    void save(const fs::path& path) const {
        if (!cached_) throw std::runtime_error("No config to save. Call load() first.");
        cached_->toml_save(path.string());
    }

    void save_defaults(const fs::path& path) const {
        ConfigType defaults{};
        defaults.toml_save(path.string());
    }

    const std::string& program_name() const { return program_name_; }
    const std::string& env() const { return env_; }
    const std::vector<fs::path>& search_paths() const { return search_paths_; }

    std::vector<fs::path> resolved_paths() const {
        std::vector<fs::path> found;
        for (const auto& path : search_paths_) if (fs::exists(path)) found.push_back(path);
        return found;
    }
};

} // namespace Fond::Config
