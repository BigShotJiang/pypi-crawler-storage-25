#pragma once

#include <dlfcn.h>
#include "fond/cpp_tree_sitter.hpp"
#include "fond/file_io/ops.hpp"
#include "fond/nix/value.hpp"
#include "fond/nix/ast_symbols.hpp"
#include "fond/str_utils.hpp"
#include <string>
#include <string_view>
#include <optional>
#include <charconv>
#include <filesystem>
#include <stdexcept>

namespace Fond::Nix {


static inline ts::Language load_nix_language(const char* so_path = nullptr) {
    using TSLangFn = TSLanguage*(*)();
    static std::optional<ts::Language> cached_lang = std::nullopt;
    if (cached_lang.has_value()) return cached_lang.value();
    
    auto fn = reinterpret_cast<TSLangFn>(dlsym(RTLD_DEFAULT, "tree_sitter_nix"));
    if (fn) { cached_lang = fn(); return cached_lang.value(); }

    #ifdef FOND_NIX_PARSER_SO
    const char *path = so_path ? so_path : FOND_NIX_PARSER_SO;
    #else
    const char *path = so_path ? so_path : std::getenv("FOND_NIX_PARSER_SO");
    #endif
    if (!path) throw std::runtime_error("tree_sitter_nix not found. Set FOND_NIX_PARSER_SO or link nix_parser.o");
    void* lib = dlopen(path, RTLD_LAZY);
    if (!lib) throw std::runtime_error(std::string("dlopen: ") + dlerror());
    fn = reinterpret_cast<TSLangFn>(dlsym(lib, "tree_sitter_nix"));
    if (!fn) throw std::runtime_error(std::string("dlsym: ") + dlerror());
    cached_lang = fn();
    return cached_lang.value();
}

class Reader {
    ts::Parser parser_;
    Arena arena_;

    ArenaString make_string(std::string_view sv) { return ArenaString(sv.data(), sv.size(), ArenaAlloc<char>(arena_)); }

    ArenaString unescape_string(std::string_view body) {
        ArenaString out((ArenaAlloc<char>(arena_)));
        out.reserve(body.size());
        for (size_t i = 0; i < body.size(); ++i) {
            if (body[i] == str::BACKSLASH && i + 1 < body.size()) {
                char esc = body[++i];
            } else {
                out.push_back(body[i]);
            }
        }
        return out;
    }

    NixStrings collect_attr_path(ts::Node node, std::string_view source) {
        NixStrings parts;
        for (auto child : ts::Children{node}) {
            if (!child.isNamed()) continue;
            if (child.getSymbol() == sym::sym_identifier) parts.push_back(make_string(child.getSourceRange(source)));
        }
        return parts;
    }

    nix::attrset& ensure_path(nix::attrset& root, const NixStrings& path) {
        nix::attrset* current = &root;
        for (const auto& key : path) {
            auto& val = (*current)[key];
            if (val.is_null()) val = NixValue(make_attrset());
            if (!val.is_attrset()) throw std::runtime_error("nix reader: cannot merge scalar into attrset at key '" + std::string(key.begin(), key.end()) + "'");
            current = &val.as_attrset();
        }
        return *current;
    }

    nix::array make_array() { return nix::array(ArenaAlloc<NixValue>(arena_)); }
    nix::attrset make_attrset() { return nix::attrset(ArenaAlloc<std::pair<const ArenaString, NixValue>>(arena_)); }

    NixValue parse_value(ts::Node node, std::string_view source) noexcept {
        std::string_view text = node.getSourceRange(source);
        auto sym = node.getSymbol();
        if (sym < 6 || sym > 24) return NULL_VALUE;
        switch (sym) {
            case sym::sym_string: {
                if (text.size() >= 2 && text.front() == '"' && text.back() == '"') return unescape_string(text.substr(1, text.size() - 2));
                return make_string(text);
            }
            case sym::sym_integer: {
                int64_t val = 0;
                auto [ptr, ec] = std::from_chars(text.data(), text.data() + text.size(), val);
                (void)ptr; (void)ec;
                return val;
            }
            case sym::sym_float: {
                auto s = std::string(text);
                return std::stod(s);
            }
                
            case sym::sym_boolean: return text == "true";
            case sym::sym_null: return NULL_VALUE;

            case sym::sym_list: {
                nix::array arr = make_array();
                for (auto child : ts::Children{node}) {
                    if (!child.isNamed() || child.getSymbol() == sym::sym_comment) continue;
                    arr.push_back(parse_value(child, source));
                }
                return arr;
            }
            case sym::sym_attrset: {
                nix::attrset tbl = make_attrset();
                for (auto child : ts::Children{node}) {
                    if (!child.isNamed() || child.getSymbol() != sym::sym_binding) continue;
                    parse_binding(child, source, tbl);
                }
                return tbl;
            }
            default: return NULL_VALUE;
        }
    }

    void parse_binding(ts::Node node, std::string_view source, nix::attrset& target) {
        auto path_node = node.getChildByFieldName("path");
        auto val_node = node.getChildByFieldName("value");
        if (path_node.isNull() || val_node.isNull()) return;

        auto parts = collect_attr_path(path_node, source);
        if (parts.empty()) return;

        auto value = parse_value(val_node, source);

        if (parts.size() == 1) {
            auto& slot = target[parts[0]];
            if (slot.is_attrset() && value.is_attrset()) {
                for (auto& [k, v] : value.as_attrset())
                    slot.as_attrset().insert(k, std::move(v));
            } else {
                slot = std::move(value);
            }
            return;
        }

        auto& nested = ensure_path(target, {parts.begin(), parts.end() - 1});
        auto& slot = nested[parts.back()];
        if (slot.is_attrset() && value.is_attrset()) {
            for (auto& [k, v] : value.as_attrset())
                slot.as_attrset().insert(k, std::move(v));
        } else {
            slot = std::move(value);
        }
    }

    NixValue parse_document(std::string_view source) {
        auto tree = parser_.parseString(source);
        if (tree.hasError()) throw std::runtime_error("nix reader: syntax error in input (unsupported construct or malformed source)");

        auto root_node = tree.getRootNode();
        for (auto child : ts::Children{root_node}) {
            if (!child.isNamed() || child.getSymbol() == sym::sym_comment) continue;
            return parse_value(child, source);
        }
        return NULL_VALUE;
    }

public:
    Reader(size_t arena_block_size = 4096) : parser_(load_nix_language()), arena_(arena_block_size) {}

    NixValue parse(std::string_view source) { arena_.reset(); return parse_document(source); }

    NixValue parse_file(const std::filesystem::path& path) {
        arena_.reset();
        auto content = Fond::FileIO::read(path);
        return parse_document(content);
    }

    ArenaString make_key(std::string_view sv) { return make_string(sv); }
    Arena& arena() { return arena_; }
};

} // namespace Fond::Nix
