# Copyright (c) 2025-2026 Seer, Inc. All rights reserved.

"""
`test_sdk` -- high-level tests for the seer-pas-sdk package
"""


def test_import():
    """
    Stub test that importing the root module is successful.
    TODO: replace this with more meaningful tests
    """
    import seer_pas_sdk
