# Copyright (c) 2025-2026 Seer, Inc. All rights reserved.


class ServerError(Exception):
    """Raised when a server error occurs"""

    def __init__(self, message):
        super().__init__(message)
