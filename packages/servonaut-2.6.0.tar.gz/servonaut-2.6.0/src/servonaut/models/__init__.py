"""Data models for Servonaut."""
