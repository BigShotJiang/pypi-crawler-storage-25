"""Configuration schema definitions for Servonaut v2.0."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, List, Dict, Optional

CONFIG_VERSION = 2


@dataclass
class ScanRule:
    """Rule for scanning instance filesystems based on instance attributes.

    Attributes:
        name: Descriptive name for the rule
        match_conditions: Dictionary of conditions to match instances
            Example: {"name_contains": "web", "region": "us-east-1"}
        scan_paths: List of paths to scan on matching instances
        scan_commands: List of commands to run on matching instances
    """
    name: str
    match_conditions: Dict[str, str]
    scan_paths: List[str] = field(default_factory=list)
    scan_commands: List[str] = field(default_factory=list)


@dataclass
class ConnectionProfile:
    """SSH connection profile defining bastion/proxy configuration.

    Attributes:
        name: Profile identifier
        bastion_host: Bastion host address (optional)
        bastion_user: Username for bastion connection (optional)
        bastion_key: SSH key for bastion (optional)
        username: SSH username for the target host (optional, overrides default_username)
        proxy_command: Custom ProxyCommand for SSH (optional)
        ssh_port: SSH port to use (default: 22)
        extra_ssh_options: Extra ``-o KEY=VALUE`` pairs applied to the target
            SSH connection. Each entry is the ``KEY=VALUE`` string without the
            leading ``-o``. Useful for legacy hosts that need, e.g.,
            ``HostKeyAlgorithms=+ssh-rsa`` or custom ``ServerAliveInterval``.
    """
    name: str
    bastion_host: Optional[str] = None
    bastion_user: Optional[str] = None
    bastion_key: Optional[str] = None
    username: Optional[str] = None
    proxy_command: Optional[str] = None
    ssh_port: int = 22
    extra_ssh_options: List[str] = field(default_factory=list)


@dataclass
class ConnectionRule:
    """Rule for applying connection profiles to instances.

    Attributes:
        name: Descriptive name for the rule
        match_conditions: Dictionary of conditions to match instances
            Example: {"region": "us-west-2", "name_contains": "private"}
        profile_name: Name of ConnectionProfile to apply
    """
    name: str
    match_conditions: Dict[str, str]
    profile_name: str


@dataclass
class CustomServer:
    """Non-AWS custom server definition.

    Attributes:
        name: Unique server name/identifier
        host: Hostname or IP address
        username: SSH username (default: root)
        ssh_key: Path to SSH key file
        port: SSH port (default: 22)
        provider: Provider label (e.g., 'DigitalOcean', 'Hetzner')
        group: Optional grouping label
        tags: Arbitrary key-value metadata
        extra_ssh_options: Extra ``-o KEY=VALUE`` pairs applied to the target
            SSH/SCP connection. Useful for legacy hosts requiring
            ``HostKeyAlgorithms=+ssh-rsa`` or similar overrides.
    """
    name: str
    host: str
    username: str = "root"
    ssh_key: str = ""
    port: int = 22
    provider: str = ""
    group: str = ""
    tags: Dict[str, str] = field(default_factory=dict)
    extra_ssh_options: List[str] = field(default_factory=list)


@dataclass
class IPBanConfig:
    """Configuration for an IP ban method.

    Attributes:
        name: Unique identifier for this ban configuration
        method: Ban method - 'waf', 'security_group', or 'nacl'
        region: AWS region (defaults to us-east-1 if empty)
        ip_set_id: WAF IP set ID (WAF only)
        ip_set_name: WAF IP set name (WAF only)
        waf_scope: WAF scope - 'REGIONAL' or 'CLOUDFRONT' (WAF only)
        security_group_id: Security group ID (security_group only)
        nacl_id: Network ACL ID (nacl only)
        rule_number_start: Starting rule number for NACL entries (nacl only)
    """
    name: str
    method: str  # 'waf', 'security_group', 'nacl'
    region: str = ""
    # WAF-specific
    ip_set_id: str = ""
    ip_set_name: str = ""
    waf_scope: str = "REGIONAL"  # REGIONAL or CLOUDFRONT
    # Security Group-specific
    security_group_id: str = ""
    # NACL-specific
    nacl_id: str = ""
    rule_number_start: int = 100


@dataclass
class AIProviderConfig:
    """AI provider configuration."""
    provider: str = "openai"  # openai, anthropic, ollama, gemini
    api_key: str = ""  # supports $ENV_VAR syntax
    model: str = ""  # empty = use provider default
    base_url: str = ""  # for Ollama: http://localhost:11434
    max_tokens: int = 4096
    temperature: float = 0.3


@dataclass
class GCPConfig:
    """GCP Compute Engine configuration."""
    enabled: bool = False
    project_ids: List[str] = field(default_factory=list)
    credentials_path: str = ""  # path to service account JSON
    zones: List[str] = field(default_factory=list)  # empty = all zones


@dataclass
class AzureConfig:
    """Azure VM configuration."""
    enabled: bool = False
    subscription_ids: List[str] = field(default_factory=list)
    resource_groups: List[str] = field(default_factory=list)


@dataclass
class RelayConfig:
    """Mercure relay listener configuration.

    ``base_url`` is the servonaut.dev REST API where the listener posts
    heartbeats and fetches the short-lived Mercure subscriber JWT.
    ``mercure_url`` is the Mercure hub itself — on production, the hub
    is mounted at the apex domain's ``/.well-known/mercure`` path (no
    dedicated subdomain). A typical production ``relay`` block in
    ``~/.servonaut/config.json``:

    * base_url    = ``https://api.servonaut.dev``
    * mercure_url = ``https://servonaut.dev/.well-known/mercure``
    """
    base_url: str = ""            # e.g. https://api.servonaut.dev
    mercure_url: str = ""         # e.g. https://servonaut.dev/.well-known/mercure
    heartbeat_interval: int = 30


@dataclass
class MCPConfig:
    """MCP server configuration."""
    guard_level: str = "standard"  # readonly, standard, dangerous
    command_blocklist: List[str] = field(default_factory=lambda: [
        r"rm\s+-rf", r"\bdd\b", r"\bmkfs\b", r"\bshutdown\b",
        r"\breboot\b", r"\bfdisk\b", r"\bparted\b", r"\bhalt\b",
        r":\(\)\{", r"\bsudo\s+rm\b",
    ])
    command_allowlist: List[str] = field(default_factory=lambda: [
        "ls", "cat", "grep", "ps", "df", "du", "top", "free",
        "uptime", "whoami", "hostname", "uname", "date", "w",
        "netstat", "ss", "ip", "ifconfig", "ping", "dig", "nslookup",
        "head", "tail", "wc", "sort", "find", "file", "stat",
    ])
    audit_path: str = "~/.servonaut/mcp_audit.jsonl"
    max_output_lines: int = 500


@dataclass
class OVHConfig:
    """OVHcloud API configuration.

    Attributes:
        enabled: Whether OVH provider is active
        endpoint: OVH API endpoint (ovh-eu, ovh-us, ovh-ca, etc.)
        application_key: OVH application key (classic 3-key auth)
        application_secret: OVH application secret (supports $ENV_VAR)
        consumer_key: OVH consumer key (supports $ENV_VAR)
        client_id: OAuth2 service account client ID
        client_secret: OAuth2 service account client secret (supports $ENV_VAR)
        cloud_project_ids: List of Public Cloud project IDs to include
        include_dedicated: Whether to fetch dedicated servers
        include_vps: Whether to fetch VPS instances
        include_cloud: Whether to fetch Public Cloud instances
    """
    enabled: bool = False
    endpoint: str = "ovh-eu"
    # Classic 3-key auth
    application_key: str = ""
    application_secret: str = ""  # supports $ENV_VAR
    consumer_key: str = ""  # supports $ENV_VAR
    # OAuth2 service account (alternative auth)
    client_id: str = ""
    client_secret: str = ""  # supports $ENV_VAR
    # SSH defaults
    default_ssh_key: str = ""  # default SSH key for all OVH instances
    default_username: str = ""  # override default username (empty = auto by provider type)
    # Filters
    cloud_project_ids: List[str] = field(default_factory=list)
    include_dedicated: bool = True
    include_vps: bool = True
    include_cloud: bool = True
    # Audit
    ovh_audit_path: str = "~/.servonaut/ovh_audit.json"
    # Cost alerts
    cost_alert_threshold: float = 0.0   # monthly alert threshold in currency, 0 = disabled
    cost_alert_currency: str = "EUR"


@dataclass
class MemoryConfig:
    """Configuration for the server memory subsystem.

    Controls which modules are active, TTL overrides, redaction, and
    per-server opt-outs.

    JSON shape example (inside ``~/.servonaut/config.json``)::

        {
          "memory": {
            "enabled": true,
            "default_ttl_overrides": {
              "services": 1800
            },
            "disabled_modules": ["containers"],
            "redaction_enabled": true,
            "per_server_overrides": {
              "i-critical-prod": { "memory_disabled": true }
            }
          }
        }

    Attributes:
        enabled: Master switch — when ``False`` no probes run and no
            memory is read or written.
        default_ttl_overrides: Per-module TTL overrides in seconds.
            Keys are module names (e.g. ``"services"``); values are seconds.
            Overrides the module's built-in default TTL.
        disabled_modules: Module names that are globally disabled.
            Probers for these modules are skipped entirely.
        redaction_enabled: When ``True`` raw probe output is passed through
            the redaction layer before being written to disk.
        per_server_overrides: Per-instance override dict.
            Each key is an instance ID; the value is a dict that may include:
            ``memory_disabled`` (bool) to opt a single server out of probing.
    """

    enabled: bool = True
    default_ttl_overrides: Dict[str, int] = field(default_factory=dict)
    disabled_modules: List[str] = field(default_factory=list)
    redaction_enabled: bool = True
    per_server_overrides: Dict[str, Dict[str, Any]] = field(default_factory=dict)

    # ------------------------------------------------------------------
    # Helpers used by MemoryService / MemoryStore
    # ------------------------------------------------------------------

    def is_module_enabled(self, instance_id: str, module: str) -> bool:
        """Return ``True`` if *module* should be probed for *instance_id*.

        A module is disabled if either:
        - it appears in ``disabled_modules``, or
        - the instance has ``"memory_disabled": true`` in
          ``per_server_overrides``.

        Args:
            instance_id: Instance identifier.
            module: Module name (e.g. ``"runtimes"``).
        """
        if module in self.disabled_modules:
            return False
        server_override = self.per_server_overrides.get(instance_id, {})
        if server_override.get("memory_disabled", False):
            return False
        return True

    def is_module_disabled_for(self, instance_id: str) -> bool:
        """Return ``True`` if the entire server is opted out of memory.

        Args:
            instance_id: Instance identifier.
        """
        server_override = self.per_server_overrides.get(instance_id, {})
        return bool(server_override.get("memory_disabled", False))

    def is_instance_disabled(self, instance_id: str, instance_name: str = "") -> bool:
        """Return ``True`` if *instance_id* or *instance_name* is opted out.

        This avoids ambiguity when an instance is registered by name in
        ``per_server_overrides`` but the caller only has the cloud ID, or
        vice-versa.  Both keys are checked; either match disables the instance.

        Args:
            instance_id: Unique cloud identifier (e.g. ``"i-abc123"``).
            instance_name: Human-readable name (e.g. ``"prod-web"``).  When
                empty the name check is skipped.
        """
        if self.is_module_disabled_for(instance_id):
            return True
        if instance_name and self.is_module_disabled_for(instance_name):
            return True
        return False


@dataclass
class AppConfig:
    """Main application configuration.

    Attributes:
        version: Config schema version (current: 2)
        default_key: Default SSH key path for all instances
        instance_keys: Instance-specific SSH key mappings {instance_id: key_path}
        default_username: Default SSH username (default: ec2-user)
        cache_ttl_seconds: Instance cache TTL in seconds (default: 300)
        default_scan_paths: Default paths to scan on all instances
        scan_rules: List of conditional scan rules
        connection_profiles: List of SSH connection profiles
        connection_rules: List of rules for applying profiles
        custom_servers: List of non-AWS custom servers
        terminal_emulator: Terminal emulator preference (default: auto)
        keyword_store_path: Path to keyword store file
        theme: UI theme preference (default: dark)
    """
    version: int = CONFIG_VERSION
    default_key: str = ""
    instance_keys: Dict[str, str] = field(default_factory=dict)
    default_username: str = "ec2-user"
    cache_ttl_seconds: int = 3600
    default_scan_paths: List[str] = field(default_factory=lambda: ["~/"])
    scan_rules: List[ScanRule] = field(default_factory=list)
    connection_profiles: List[ConnectionProfile] = field(default_factory=list)
    connection_rules: List[ConnectionRule] = field(default_factory=list)
    custom_servers: List[CustomServer] = field(default_factory=list)
    terminal_emulator: str = "auto"
    keyword_store_path: str = "~/.servonaut/keywords.json"
    command_history_path: str = "~/.servonaut/command_history.json"
    max_command_history: int = 50
    theme: str = "dark"
    log_viewer_default_paths: List[str] = field(default_factory=lambda: [
        "/var/log/syslog",
        "/var/log/auth.log",
        "/var/log/messages",
        "/var/log/nginx/access.log",
        "/var/log/nginx/error.log",
        "/var/log/apache2/access.log",
        "/var/log/apache2/error.log",
        "/var/log/mysql/error.log",
        "/var/log/postgresql/postgresql-main.log",
    ])
    log_viewer_custom_paths: Dict[str, List[str]] = field(default_factory=dict)
    log_viewer_scan_directories: List[str] = field(default_factory=lambda: ["/var/log"])
    log_viewer_scan_max_depth: int = 2
    log_viewer_max_lines: int = 10000
    log_viewer_tail_lines: int = 100
    cloudtrail_default_region: str = ""
    cloudtrail_max_events: int = 100
    cloudtrail_default_lookback_hours: int = 24
    cloudtrail_default_lookback_minutes: int = 0
    cloudwatch_default_region: str = ""
    cloudwatch_max_events: int = 500
    cloudwatch_log_group_prefix: str = ""
    abuseipdb_api_key: str = ""
    ip_ban_configs: List[IPBanConfig] = field(default_factory=list)
    ip_ban_audit_path: str = "~/.servonaut/ip_ban_audit.json"
    ai_provider: AIProviderConfig = field(default_factory=AIProviderConfig)
    ai_chunk_size: int = 100000
    ai_system_prompt: str = (
        "You are a server log analyst. Analyze the following log output and provide: "
        "1) A summary of what's happening, 2) Any errors or warnings found, "
        "3) Potential issues or security concerns, 4) Recommended actions."
    )
    mcp: MCPConfig = field(default_factory=MCPConfig)
    relay: RelayConfig = field(default_factory=RelayConfig)
    ovh: OVHConfig = field(default_factory=OVHConfig)
    gcp: GCPConfig = field(default_factory=GCPConfig)
    azure: AzureConfig = field(default_factory=AzureConfig)
    chat_history_path: str = "~/.servonaut/chats"
    chat_max_history_messages: int = 20
    chat_system_prompt: str = ""
    chat_max_tool_iterations: int = 10
    chat_tool_guard_level: str = "standard"  # readonly, standard, dangerous
    sync_encryption_enabled: bool = True
    memory: MemoryConfig = field(default_factory=MemoryConfig)
    # T11: first-connect memory-build prompt gating.
    # Counts how many times the user has dismissed the post-connect banner
    # asking "Build memory for <server>? [y]".  After three dismissals the
    # banner is suppressed globally; the ``servonaut memory reset-prompts``
    # command resets it back to 0 so users can re-enable the nudge later.
    memory_first_connect_dismissed_count: int = 0
