from mcp.server.fastmcp import FastMCP


def register_prompts(mcp: FastMCP) -> None:
    """Register pre-canned topology workflow prompts."""

    @mcp.prompt(
        name="explore_topology",
        description=("Explore a topology database file: show structure, search for signals, and summarize available vehicle data."),
    )
    def explore_topology(workspace: str, database_file: str) -> list[dict[str, str]]:
        return [
            {
                "role": "user",
                "content": (
                    f"Please explore the topology database file at '{database_file}' "
                    f"in workspace '{workspace}'. "
                    "Start by showing the overall topology structure, then search for signals "
                    "to understand what vehicle data is available. "
                    "If the file is an .arxml, also check for Ethernet configuration and "
                    "SOME/IP services if present. "
                    "Give me a clear summary in plain language: what channels, frames, and "
                    "key signals exist, and what they represent."
                ),
            }
        ]

    @mcp.prompt(
        name="generate_topology_files",
        description=("Generate topology instance and platform YAML files for a signal database, then build the executable environment."),
    )
    def generate_topology_files(workspace: str, database_file: str, output_dir: str) -> list[dict[str, str]]:
        return [
            {
                "role": "user",
                "content": (
                    f"Please generate topology instance files for the signal database "
                    f"'{database_file}' in workspace '{workspace}'. "
                    f"Write output to '{output_dir}'. "
                    "First fetch the JSON schema resource to understand the required file format, "
                    "then show the topology structure of the database so we know what channels "
                    "and ECUs are involved, and finally generate an appropriate instance file "
                    "and build the executable environment from it."
                ),
            }
        ]
