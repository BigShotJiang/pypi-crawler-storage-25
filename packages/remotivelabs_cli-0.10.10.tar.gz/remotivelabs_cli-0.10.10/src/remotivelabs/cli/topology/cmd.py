from __future__ import annotations

import typer

from remotivelabs.cli.topology.cli.topology_cli import run_topology_cli
from remotivelabs.cli.topology.subscription import app as subscription_app
from remotivelabs.cli.topology.subscription import start_trial_cmd as start_trial_subscription_cmd
from remotivelabs.cli.topology.workspace import app as workspace_app
from remotivelabs.cli.typer_ext import typer_utils

HELP = """
Manage RemotiveTopology resources
"""

app = typer_utils.create_typer_sorted(rich_markup_mode="rich", help=HELP)

app.add_typer(subscription_app, name="subscription")
app.add_typer(workspace_app, name="workspace", help="Manage RemotiveTopology workspaces")


# TODO: Moving forward we can deprecate this and refer to subscription start-trial but lets wait for docs and things
@app.command("start-trial")
def start_trial_cmd(  # noqa: C901
    organization: str = typer.Option(None, help="Organization to start trial for", envvar="REMOTIVE_CLOUD_ORGANIZATION"),
) -> None:
    """
    Allows you ta start a 30 day trial subscription for running RemotiveTopology.

    You can read more at https://docs.remotivelabs.com/docs/remotive-topology.
    """

    start_trial_subscription_cmd(organization)


@app.command(context_settings={"allow_extra_args": True, "ignore_unknown_options": True}, hidden=True)
def cli(args: list[str] = typer.Argument(None), ctx: typer.Context = typer.Option(None)) -> None:
    """
    Run any RemotiveTopology CLI command.
    """
    run_topology_cli(ctx, args or ["--help"])


@app.command("version")
def version(ctx: typer.Context = typer.Option(None)) -> None:
    """
    Show RemotiveTopology CLI version.
    """
    run_topology_cli(ctx, ["--version"])
