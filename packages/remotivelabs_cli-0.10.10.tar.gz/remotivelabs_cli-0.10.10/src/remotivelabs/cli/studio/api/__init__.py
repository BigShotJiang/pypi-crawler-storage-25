from __future__ import annotations

from contextlib import asynccontextmanager
from typing import AsyncIterator

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from remotivelabs.cli.search import SearchIndex
from remotivelabs.cli.studio.api.auth import router as auth_router
from remotivelabs.cli.studio.api.environment import router as environment_router
from remotivelabs.cli.studio.api.files import router as files_router
from remotivelabs.cli.studio.api.path_utils import FileIOErrorResponse
from remotivelabs.cli.studio.api.search_routes import files_router as files_search_router
from remotivelabs.cli.studio.api.search_routes import topology_router
from remotivelabs.cli.studio.api.topology_runtime import router as runtime_router
from remotivelabs.cli.studio.api.workspace import router as workspace_router
from remotivelabs.cli.utils.file_io import FileAccessError, FilePathError


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncIterator[None]:
    app.state.startup()
    search_index: SearchIndex = app.state.search_index
    search_index.connect()
    try:
        yield
    finally:
        search_index.close()


api = FastAPI(lifespan=lifespan)


@api.exception_handler(FileAccessError)
async def file_access_error_handler(_request: Request, exc: FileAccessError) -> JSONResponse:
    body = FileIOErrorResponse(message=str(exc))
    return JSONResponse(status_code=500, content=body.model_dump())


@api.exception_handler(FilePathError)
async def file_path_error_handler(_request: Request, exc: FilePathError) -> JSONResponse:
    body = FileIOErrorResponse(message=str(exc))
    return JSONResponse(status_code=400, content=body.model_dump())


api.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

api.include_router(auth_router)
api.include_router(files_router)
api.include_router(environment_router)
api.include_router(runtime_router)
api.include_router(workspace_router)
api.include_router(topology_router)
api.include_router(files_search_router)

__all__ = ["api"]
