"""Signal search library — pure engine with no web-framework dependency."""

from .base import SearchAPI, SearchOptions, StatusResult
from .query import Operator, ParsedQuery, ParsedTerm, Query
from .sqlite import SearchIndex, SQLiteSearch

__all__ = [
    "Operator",
    "SearchOptions",
    "SearchAPI",
    "ParsedQuery",
    "ParsedTerm",
    "Query",
    "SearchIndex",
    "SQLiteSearch",
    "StatusResult",
]
