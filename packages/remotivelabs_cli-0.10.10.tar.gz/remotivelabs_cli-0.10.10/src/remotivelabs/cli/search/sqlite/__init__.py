"""SQLite FTS5 backend for signal search."""

from .index import SearchIndex, SQLiteSearch

__all__ = ["SQLiteSearch", "SearchIndex"]
