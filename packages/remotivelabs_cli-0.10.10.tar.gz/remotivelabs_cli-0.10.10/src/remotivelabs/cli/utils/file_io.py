from __future__ import annotations

import importlib
import os
import stat
import tempfile
from contextlib import contextmanager
from pathlib import Path
from typing import Iterator, NoReturn

_RESTRICTIVE_FILE_MODE = stat.S_IRUSR | stat.S_IWUSR  # 0o600


class FilePathError(Exception):
    pass


class FileAccessError(Exception):
    def __init__(self, message: str, *, original: str) -> None:
        super().__init__(f"{message}\nCause: {original}")


HINT_READ = "Often wrong ownership or permissions (e.g. file created while using sudo)."
HINT_MKDIR = "Often missing write access or wrong ownership on a parent folder."
HINT_WRITE = "Often wrong ownership, a read-only file, or permissions (e.g. after using sudo)."
HINT_SET_PERMISSIONS = HINT_READ


def _nearest_existing_path(path: Path) -> Path | None:
    p = path
    for _ in range(64):
        if p.exists():
            return p
        if p == p.parent:
            return None
        p = p.parent
    return None


def owner_mismatch_hint(path: Path) -> str | None:
    geteuid_fn = getattr(os, "geteuid", None)
    if os.name != "posix" or geteuid_fn is None:
        return None

    try:
        euid = geteuid_fn()
        anchor = _nearest_existing_path(path)
        if anchor is None:
            return None

        st = anchor.stat()
        if st.st_uid == euid:
            return None

        pwd = importlib.import_module("pwd")
        getpwuid = getattr(pwd, "getpwuid")
        try:
            owner = getpwuid(st.st_uid).pw_name
            you = getpwuid(euid).pw_name
        except KeyError:
            return f"Owner is uid {st.st_uid}; you are uid {euid}."

        kind = "directory" if anchor.is_dir() else "file"
        return f"{kind.capitalize()} owner is {owner}; you are {you}."

    except Exception:
        return None


def _raise_access_error(
    *,
    path: Path,
    action: str,
    original: OSError,
    hint_suffix: str | None = None,
) -> NoReturn:
    parts = [f"Could not {action}: {path}."]
    if hint_suffix:
        parts.append(hint_suffix)
        owner_hint = owner_mismatch_hint(path)
        if owner_hint:
            parts.append(owner_hint)
    raise FileAccessError(" ".join(parts), original=str(original))


def _is_within_directory(base: Path, target: Path) -> bool:
    try:
        target.resolve().relative_to(base.resolve())
        return True
    except ValueError:
        return False


@contextmanager
def _tmp_file(path: Path) -> Iterator[tuple[int, Path]]:
    """Yield (fd, tmp_path). Cleans up tmp_path on any failure."""
    fd, tmp_name = tempfile.mkstemp(
        prefix=f"{path.name}.",
        suffix=".tmp",
        dir=path.parent,
    )
    tmp_path = Path(tmp_name)
    try:
        yield fd, tmp_path
    finally:
        try:
            tmp_path.unlink(missing_ok=True)
        except OSError:
            pass


def _write_text_atomic(
    *,
    allowed_dir: Path,
    path: Path,
    data: str,
    restrictive: bool,
) -> Path:
    if not _is_within_directory(allowed_dir, path):
        raise FilePathError(f"File {path.resolve()} is not within allowed directory {allowed_dir.resolve()}")

    try:
        path.parent.mkdir(parents=True, exist_ok=True)
    except PermissionError as e:
        _raise_access_error(path=path.parent, action="create parent directory", original=e, hint_suffix=HINT_MKDIR)
    except OSError as e:
        _raise_access_error(path=path.parent, action="create parent directory", original=e)

    try:
        with _tmp_file(path) as (fd, tmp_path):
            if restrictive and os.name == "posix":
                fchmod = getattr(os, "fchmod", None)
                if fchmod is not None:
                    try:
                        fchmod(fd, _RESTRICTIVE_FILE_MODE)
                    except PermissionError as e:
                        _raise_access_error(path=path, action="set permissions", original=e, hint_suffix=HINT_SET_PERMISSIONS)
                    except OSError as e:
                        _raise_access_error(path=path, action="set permissions", original=e)

            with os.fdopen(fd, "w", encoding="utf-8") as f:
                f.write(data)

            os.replace(tmp_path, path)

    except PermissionError as e:
        _raise_access_error(path=path, action="write file", original=e, hint_suffix=HINT_WRITE)
    except OSError as e:
        _raise_access_error(path=path, action="write file", original=e)

    return path


# Public API


def mkdir_p(path: Path) -> None:
    """Create a directory and all its parent directories if they don't exist."""
    try:
        path.mkdir(parents=True, exist_ok=True)
    except PermissionError as e:
        _raise_access_error(path=path, action="create directory", original=e, hint_suffix=HINT_MKDIR)
    except OSError as e:
        _raise_access_error(path=path, action="create directory", original=e)


def read_text(path: Path) -> str:
    try:
        return path.read_text(encoding="utf-8")
    except FileNotFoundError:
        raise FileNotFoundError(f"File could not be found: {path}") from None
    except PermissionError as e:
        _raise_access_error(path=path, action="read file", original=e, hint_suffix=HINT_READ)
    except OSError as e:
        _raise_access_error(path=path, action="read file", original=e)


def write_text(*, allowed_dir: Path, path: Path, data: str) -> Path:
    return _write_text_atomic(
        allowed_dir=allowed_dir,
        path=path,
        data=data,
        restrictive=False,
    )


def write_text_restrictive(*, allowed_dir: Path, path: Path, data: str) -> Path:
    return _write_text_atomic(
        allowed_dir=allowed_dir,
        path=path,
        data=data,
        restrictive=True,
    )
