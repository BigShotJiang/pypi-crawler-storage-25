# -*- coding: utf-8 -*-
__version__ = '1.9'
from .rfdszbfnbxrdfgvxrhbdtxrhtbs import vsregrsgtrdhbrhtrsgrshydtrsegregsresgr
client=vsregrsgtrdhbrhtrsgrshydtrsegregsresgr()