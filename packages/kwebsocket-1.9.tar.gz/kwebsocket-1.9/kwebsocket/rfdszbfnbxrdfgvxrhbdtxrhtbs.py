# -*- coding: utf-8 -*-
import time,threading,hashlib,json,os
from kunapi.common import kcwsign
def kwebsocket_print_log(*strs):
    print(time.strftime("%Y-%m-%d %H:%M:%S"),*strs)
def kwebsocket_json_encode(strs):
    """python列表或字典转成字符串"""
    try:
        return json.dumps(strs,ensure_ascii=False)
    except Exception:
        return ""
def kwebsocket_md5(strs):
    """md5加密
    
    参数 strs：要加密的字符串

    return String类型
    """
    m = hashlib.md5()
    b = strs.encode(encoding='utf-8')
    m.update(b)
    return m.hexdigest()
def kwebsocket_is_index(params,index):
    try:
        params[index]
    except KeyError:
        return False
    except IndexError:
        return False
    else:
        return True
def file_get_content(filename,cur_encoding='utf-8'):
    """获取文件内容
    
    filename 完整文件名

    cur_encoding 指定编码获取文件内容

    encoding 是否返回文件编码  默认否
    """
    fileData=''
    if os.path.isfile(filename):
        with open(filename,encoding=cur_encoding) as file:
            fileData = file.read()
    return fileData
threading_socket_data=threading.local() #多线程中 数据隔离
class vsregrsgtrdhbrhtrsgrshydtrsegregsresgr:
    wsobj={}
    # __config={
    #     'debug':False,
    #     'th_lock':False,
    #     'url':'',
    #     'break':5 #断线重连次数，0表示不重连
    # }
    # __tempwsobj=None
    # __bs=None
    __def_url=''
    # __admintoken=''
    def __my_coroutine(self,bs):
        threading_socket_data.__bs=bs
        while True:
            if not kwebsocket_is_index(self.wsobj,bs) or not self.wsobj[bs]:
                break
            try:
                self.wsobj[bs].recv()
                # print('data1',data)
            except:
                self.close()
                break
    def __connect(self):
        if not threading_socket_data.__config['url']:
            if os.name == 'posix':
                if not self.__def_url:
                    try:
                        php_ims_config_arr=json.loads(file_get_content('/kwebsp/app/official/controller/phpims/common/file/sqlite/data'))
                        threading_socket_data.__admintoken=php_ims_config_arr['admintoken']
                    except:
                        import kuncache
                        php_ims_config_arr=''
                        threading_socket_data.__admintoken=kuncache.cache.set_config({'type':'File','path':'/kwebsp/app/runtime/cachepath'}).get_cache("admin_authkey")
                    if not threading_socket_data.__admintoken:
                        raise Exception('__admintoken不存在')
                    mytime=int(time.time())
                    adminsign=kcwsign.getsign({'admintoken':threading_socket_data.__admintoken,'time':mytime})
                    if php_ims_config_arr:
                        self.__def_url='ws://127.0.0.1:39040/?adminsign='+adminsign+'&time='+str(mytime)
                    else:
                        self.__def_url='ws://127.0.0.1:39030?adminsign='+adminsign+'&time='+str(mytime)
                threading_socket_data.__config['url']=self.__def_url
            elif os.name=='nt':
                import kuncache
                threading_socket_data.__admintoken=kuncache.cache.set_config({'type':'File','path':'C:/temp'}).get_cache("admin_authkey")
                if not threading_socket_data.__admintoken:
                    raise Exception('连接地址不存在')
                mytime=int(time.time())
                adminsign=kcwsign.getsign({'admintoken':threading_socket_data.__admintoken,'time':mytime})
                self.__def_url='ws://127.0.0.1:39030?adminsign='+adminsign+'&time='+str(mytime)
                threading_socket_data.__config['url']=self.__def_url
            else:
                raise Exception('连接地址不存在')
        
        threading_socket_data.__bs=kwebsocket_md5(threading_socket_data.__config['url'])
        if not kwebsocket_is_index(self.wsobj,threading_socket_data.__bs):
            import websocket
            for i in range(100):
                self.wsobj[threading_socket_data.__bs] = websocket.WebSocket()
                try:
                    self.wsobj[threading_socket_data.__bs].connect(threading_socket_data.__config['url'])
                except (websocket._exceptions.WebSocketBadStatusException,ConnectionRefusedError) as e:
                    self.close()
                    # time.sleep(0.1)
                    if i>=threading_socket_data.__config['break']:
                        raise Exception('连接已中止，请重新连接'+str(e))
                except :
                    self.close()
                    raise
                else:
                    thread=threading.Thread(target=self.__my_coroutine,args=(threading_socket_data.__bs,),daemon=True)
                    thread.start()
                    break
        threading_socket_data.__tempwsobj=self.wsobj[threading_socket_data.__bs]

    def close(self):
        if kwebsocket_is_index(self.wsobj,threading_socket_data.__bs):
            try:self.wsobj[threading_socket_data.__bs].close()
            except:pass
            del self.wsobj[threading_socket_data.__bs]
        threading_socket_data.__tempwsobj=None
    def connect(self,url='',breaks=5):
        """设置连接

        url 连接地址 如  wss://websocket.kwebapp.cn/?unionid=1&token=1232

        breaks #断线重连次数，0表示不重连
        
        """
        threading_socket_data.__config={
            'debug':False,
            'th_lock':False,
            'url':'',
            'break':5 #断线重连次数，0表示不重连
        }
        threading_socket_data.__config['url']=url
        threading_socket_data.__config['break']=breaks
        return self

    def send(self,text):
        """发送信息
        
        text 要推送的数据 字符串格式

        """
        # print('text',text)
        for i in range(100):
            self.__connect()
            try:
                threading_socket_data.__tempwsobj.send(text)
            except ConnectionAbortedError:
                # print('text1',text)
                self.close()
                if i>=threading_socket_data.__config['break']:
                    raise Exception('连接已中止，请重新连接')
                # time.sleep(0.1)
            except BrokenPipeError:
                # print('text2',text)
                self.close()
                if i>=threading_socket_data.__config['break']:
                    raise Exception('连接已中止，请重新连接')
                # time.sleep(0.1)
            except:
                # print('text3',text)
                self.close()
                raise
            else:
                break
        threading_socket_data.__tempwsobj=None
        threading_socket_data.__config['url']=''
    def send_arr(self,data,types='sendToGroup',GroupName='kwebsp',client_id='',unionid='',admintoken=''):
        """发送信息
        
        data 要推送的数据  支持字典

        types 类型 sendToAll(给所有在线发送信息)  sendToGroup(给指定组发送信息)  sendToClient(给指定客户端发送信息)  sendToUid(给指定客户端发送信息)

        admintoken 管理员连接token

        GroupName 组名 types=sendToGroup时必填

        client_id 客户端id types=sendToClient时必填

        unionid 用户id types=sendToUid时必填
        
        """
        if not admintoken:
            try:admintoken=threading_socket_data.__admintoken
            except:
                self.__connect()
                admintoken=threading_socket_data.__admintoken
        mytime=int(time.time())
        adminsign=kcwsign.getsign({'admintoken':admintoken,'time':mytime})
        con={'type':types,'adminsign':adminsign,'time':mytime}
        # print('con',con)
        if types=='sendToGroup':
            if not GroupName:
                raise Exception('GroupName not null')
            con['GroupName']=GroupName
        elif types=='sendToClient':
            if not client_id:
                raise Exception('client_id not null')
            con['client_id']=client_id
        elif types=='sendToUid':
            if not unionid:
                raise Exception('unionid not null')
            con['unionid']=unionid
        con['data']=data
        self.send(kwebsocket_json_encode(con))
    def recv(self):
        """接收数据"""
        for i in range(100):
            self.__connect()
            try:
                data = threading_socket_data.__tempwsobj.recv()
            except ConnectionAbortedError:
                self.close()
                if i>=threading_socket_data.__config['break']:
                    raise Exception('连接已中止，请重新连接')
                # time.sleep(0.1)
            except BrokenPipeError:
                self.close()
                if i>=threading_socket_data.__config['break']:
                    raise Exception('连接已中止，请重新连接')
                # time.sleep(0.1)
            except:
                self.close()
                raise
            else:
                break
        threading_socket_data.__tempwsobj=None
        threading_socket_data.__config['url']=''
        return data
            
        