"""AMFS Pro MCP Server — extends the community MCP server with intelligence layer tools."""
