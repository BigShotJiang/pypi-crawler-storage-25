from amfs_mcp_pro.server import main

main()
