"""AMFS Pro MCP Server — adds intelligence layer tools on top of the community server.

Extends the community MCP server (amfs-mcp-server) with Pro-only tools:
- amfs_critique: run the Memory Critic analyzer
- amfs_distill: generate distilled memory sets
- amfs_validate: run Memory Safety validation on proposed writes
- amfs_retrieve: multi-strategy retrieval (semantic + BM25 + temporal + learned)
- amfs_retrain: train the learned ranking model from outcome data
- amfs_calibrate: learn optimal confidence multipliers from outcome data
- amfs_export_training_data: export decision traces as fine-tuning datasets
- amfs_trace_verify: verify cryptographic integrity of a decision trace
- amfs_trace_replay: reconstruct the memory state at decision time
- amfs_trace_interactions: query inter-agent interaction graphs
"""

from __future__ import annotations

import json
import logging
import os
from pathlib import Path
from typing import Any

import amfs_mcp.server as _oss_server
from amfs_mcp.server import mcp, _serialize_entry

# Override community instructions with Pro version that foregrounds rooms
_PRO_INSTRUCTIONS = """\
You have access to AMFS (Agent Memory File System) — persistent memory that survives across sessions, agents, and machines. Your account includes Rooms for team collaboration.

## MANDATORY FIRST STEP: Set Your Identity

Call `amfs_set_identity` before anything else:
```
amfs_set_identity("<role-name>", "<description of current task>")
```
Use kebab-case names that persist across sessions (e.g. "api-agent", "dashboard-agent").

## Rooms — Shared Team Workspaces

Rooms are shared workspaces on entities where multiple users' agents collaborate. Your account may have rooms with existing knowledge from team members.

**Always check for rooms early:**
1. `amfs_my_rooms()` — discover rooms you can join or are already in
2. `amfs_room_join(room_id)` — join a room (auto-briefing with history is delivered)
3. Read and write normally — entries on room entities are shared with all members
4. `amfs_room_info(room_id)` — see members, settings, and discussion status
5. `amfs_room_updates(room_id)` — check recent activity

Room writes auto-propagate to all members. Cross-user reads are logged on both timelines.

**Negotiations:** Rooms support structured negotiations where agents propose, counter, and reach consensus.
- Check `amfs_room_info(room_id)` — it lists pending negotiations you should respond to
- Use `amfs_negotiate_propose` to submit your position on open negotiations
- Use `amfs_negotiate_respond` to accept/reject/counter existing proposals

## Negotiation Conduct

When participating in negotiations (`amfs_negotiate_propose`):

1. **Initial proposals**: You may submit your initial position freely based on
   available context (entity briefings, memory, room history). Use your best
   judgment to represent your user's interests.

2. **Acceptance or rejection**: You MUST check with your user before:
   - Accepting another agent's proposal (action="accept")
   - Rejecting a proposal outright (action="reject")
   - Submitting a counter-offer in the final round

   Ask your user something like: "There's a proposal in negotiation '{title}':
   [summary of proposal]. Do you want me to accept, reject, or counter?"

3. **Context gathering**: Before proposing, call `amfs_room_updates` and
   `amfs_briefing` to understand the full context. Review the negotiation
   topic and any existing proposals.

4. **Transparency**: Always tell your user when you've engaged in a negotiation
   and summarize what you proposed.

## Workflow

1. **Set identity**: `amfs_set_identity(...)` — always first
2. **Check rooms**: `amfs_my_rooms()` — join any available rooms to access shared knowledge
3. **Get briefed**: `amfs_briefing(entity_path="...")` — compiled knowledge from the Cortex
4. **Read & explore**: `amfs_read`, `amfs_search`, `amfs_retrieve`, `amfs_graph_neighbors`
5. **Record decisions**: `amfs_record_context(...)` — capture meaningful decisions as they happen
6. **Write knowledge**: `amfs_write(...)` — only things that help a future agent
7. **Commit outcomes**: `amfs_commit_outcome(...)` — FREE, always do this after significant work

## What to Save

- Decisions with rationale (why X over Y)
- Discovered patterns reusable across sessions
- Risks, bugs, or gotchas for future agents
- Task summaries after completing significant work

## What NOT to Save

- Trivial changes the IDE/VCS already tracks
- Anything recomputable from the codebase in under 5 seconds
- Transient debug output

## Entity Naming

Use `{repo}/{service-or-module}` paths (e.g. `myapp/auth`, `amfs/core-engine`).

## Key Patterns

- **Patterns**: `amfs_write(..., "pattern-<name>", "...", pattern_refs=["related-key"])`
- **Risks**: `amfs_write(..., "risk-<name>", "...", confidence=0.8, memory_type="belief")`
- **Cross-agent reads**: `amfs_read_from("<agent_id>", ...)` for tracked knowledge transfer

## Confidence Scale

- 1.0 = verified fact | 0.7-0.9 = high confidence | 0.4-0.6 = hypothesis | < 0.4 = speculative

## Quality Feedback

`amfs_write` responses include a `quality` score. If below 0.8, review `issues` and rewrite with more detail.
"""
mcp._instructions = _PRO_INSTRUCTIONS

try:
    from amfs_critic.analyzer import MemoryCritic
except ImportError:
    MemoryCritic = None  # type: ignore[assignment,misc]

try:
    from amfs_distiller.distiller import MemoryDistiller
except ImportError:
    MemoryDistiller = None  # type: ignore[assignment,misc]

try:
    from amfs_safety.validator import MemorySafetyValidator
except ImportError:
    MemorySafetyValidator = None  # type: ignore[assignment,misc]

try:
    from amfs_retrieval.engine import MultiStrategyRetriever
except ImportError:
    MultiStrategyRetriever = None  # type: ignore[assignment,misc]

try:
    from amfs_ml.ranking.ranker import LearnedRanker
    from amfs_ml.calibration.calibrator import ConfidenceCalibrator
    from amfs_ml.export.exporter import TrainingDataExporter, ExportFormat
except ImportError:
    LearnedRanker = None  # type: ignore[assignment,misc]
    ConfidenceCalibrator = None  # type: ignore[assignment,misc]
    TrainingDataExporter = None  # type: ignore[assignment,misc]
    ExportFormat = None  # type: ignore[assignment,misc]

logger = logging.getLogger(__name__)

_MODEL_DIR = Path(os.environ.get("AMFS_ML_MODEL_DIR", ".amfs/ml"))


# ──────────────────────────────────────────────────────────────────────
# HTTP adapter auto-wiring: when AMFS_HTTP_URL is set, swap the storage
# adapter so all MCP operations go through the authenticated REST API.
# ──────────────────────────────────────────────────────────────────────

_HTTP_URL = os.environ.get("AMFS_HTTP_URL")
_HTTP_KEY = os.environ.get("AMFS_API_KEY", "")

if _HTTP_URL:
    from amfs_adapter_http import HttpAdapter as _HttpAdapter

    _original_get_memory = _oss_server._get_memory

    def _patched_get_memory():
        mem = _original_get_memory()
        adapter = mem._adapter
        if not isinstance(adapter, _HttpAdapter):
            logger.info(
                "AMFS_HTTP_URL detected — switching to HttpAdapter (%s)",
                _HTTP_URL,
            )
            http_adapter = _HttpAdapter(base_url=_HTTP_URL, api_key=_HTTP_KEY)
            mem._adapter = http_adapter
            mem._engine._adapter = http_adapter
            mem._propagator._adapter = http_adapter
        return mem

    _oss_server._get_memory = _patched_get_memory  # type: ignore[assignment]
    logger.info("Pro MCP server: HttpAdapter will be used (AMFS_HTTP_URL=%s)", _HTTP_URL)

from amfs_mcp.server import _get_memory


# ──────────────────────────────────────────────────────────────────────
# Tier gating — check account plan before allowing room/negotiation tools
# ──────────────────────────────────────────────────────────────────────

_cached_tier: str | None = None
_tier_fetched: bool = False


def _fetch_account_tier() -> str | None:
    """Fetch and cache the account's plan tier from the backend API.

    Fail-open: if the fetch fails, returns None and tools proceed normally.
    """
    global _cached_tier, _tier_fetched
    if _tier_fetched:
        return _cached_tier
    _tier_fetched = True
    base_url = os.environ.get("AMFS_HTTP_URL", "")
    api_key = os.environ.get("AMFS_API_KEY", "")
    if not base_url:
        return None
    try:
        import urllib.request
        url = f"{base_url}/api/v1/rooms/account-tier"
        req = urllib.request.Request(url, headers={
            "X-AMFS-API-Key": api_key,
            "Content-Type": "application/json",
        })
        with urllib.request.urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read().decode())
            _cached_tier = data.get("plan_tier")
            logger.info("Account tier resolved: %s", _cached_tier)
            return _cached_tier
    except Exception:
        logger.warning("Failed to fetch account tier — proceeding without gate", exc_info=True)
        return None


def _require_tier(*allowed_tiers: str) -> str | None:
    """Return None if tier allows access, or a JSON error string if not.

    Fail-open: if tier is unknown (fetch failed), returns None.
    """
    tier = _fetch_account_tier()
    if tier is None or tier in allowed_tiers:
        return None
    return json.dumps({
        "error": f"This feature requires a Pro or Teams plan. "
                 f"Your current plan: {tier}. "
                 f"Upgrade at https://amfs.sense-lab.ai/settings/billing",
        "current_tier": tier,
        "required_tiers": list(allowed_tiers),
    })


_ROOMS_TIERS = ("pro", "teams", "enterprise")


# ──────────────────────────────────────────────────────────────────────
# Visibility filtering — restrict MCP results to user-owned + room-shared
# ──────────────────────────────────────────────────────────────────────

_cached_visibility: dict | None = None
_visibility_fetched: bool = False


def _fetch_visibility() -> dict | None:
    """Fetch the user's visibility set from the backend API.

    Returns {"my_agent_ids": [...], "shared_entity_paths": {...}} or None.
    Fail-open: if the fetch fails, returns None and tools show all entries.
    """
    global _cached_visibility, _visibility_fetched
    if _visibility_fetched:
        return _cached_visibility
    _visibility_fetched = True
    base_url = os.environ.get("AMFS_HTTP_URL", "")
    api_key = os.environ.get("AMFS_API_KEY", "")
    if not base_url:
        return None
    try:
        import urllib.request
        url = f"{base_url}/api/v1/rooms/my-visibility"
        req = urllib.request.Request(url, headers={
            "X-AMFS-API-Key": api_key,
            "Content-Type": "application/json",
        })
        with urllib.request.urlopen(req, timeout=10) as resp:
            _cached_visibility = json.loads(resp.read().decode())
            logger.info("Visibility set loaded: %d own agents, %d shared paths",
                        len(_cached_visibility.get("my_agent_ids", [])),
                        len(_cached_visibility.get("shared_entity_paths", {})))
            return _cached_visibility
    except Exception:
        logger.warning("Failed to fetch visibility set — no filtering applied", exc_info=True)
        return None


_SYSTEM_AGENTS = {"amfs-server", "system", "amfs"}


def _is_entry_visible(entry_dict: dict) -> bool:
    """Check if an entry should be visible based on the cached visibility set."""
    vis = _fetch_visibility()
    if vis is None:
        return True
    prov = entry_dict.get("provenance", {})
    author = prov.get("agent_id") if isinstance(prov, dict) else None
    if author is None:
        return True
    my_agents = set(vis.get("my_agent_ids", []))
    if author in my_agents:
        return True
    ep = entry_dict.get("entity_path", "")
    shared = vis.get("shared_entity_paths", {})
    if ep in shared:
        room_members = set(shared[ep]) if shared[ep] else set()
        if author in room_members or author in _SYSTEM_AGENTS:
            return True
    return False


def _filter_entries_visible(entries: list[dict]) -> list[dict]:
    """Filter a list of serialized entries to only visible ones."""
    vis = _fetch_visibility()
    if vis is None:
        return entries
    return [e for e in entries if _is_entry_visible(e)]


_INTELLIGENCE_MISSING = json.dumps({
    "error": "Intelligence tools require the 'intelligence' extra: "
             "pip install amfs-mcp-server-pro[intelligence]",
})


def _get_critic():
    if MemoryCritic is None:
        return None
    mem = _get_memory()
    return MemoryCritic(mem.adapter)


def _get_distiller():
    if MemoryDistiller is None:
        return None
    mem = _get_memory()
    return MemoryDistiller(mem.adapter)


def _get_validator():
    if MemorySafetyValidator is None:
        return None
    mem = _get_memory()
    return MemorySafetyValidator(mem.adapter)


def _get_learned_ranker():
    if LearnedRanker is None:
        return None
    mem = _get_memory()
    return LearnedRanker(mem.adapter, model_path=_MODEL_DIR / "ranker.pkl")


def _get_retriever():
    if MultiStrategyRetriever is None:
        return None
    mem = _get_memory()
    embedder = getattr(mem, "_embedder", None)
    ranker = _get_learned_ranker()
    learned_weight = 0.3 if (ranker and ranker.is_trained) else 0.0
    return MultiStrategyRetriever(
        mem.adapter,
        embedder,
        learned_ranker=ranker,
        learned_weight=learned_weight,
        semantic_weight=0.35 if (ranker and ranker.is_trained) else 0.4,
        confidence_weight=0.15 if (ranker and ranker.is_trained) else 0.2,
    )


# ──────────────────────────────────────────────────────────────────────
# Pro MCP Tools
# ──────────────────────────────────────────────────────────────────────


@mcp.tool
def amfs_critique() -> str:
    """Run the Memory Critic to analyze the health of the memory store.

    Detects toxic, stale, contradictory, uncalibrated, and orphaned memories.
    Returns a structured report with actionable recommendations.

    This is the Critic stage of the AMFS flywheel — automated quality
    analysis inspired by Waymo's Critic system.
    """
    critic = _get_critic()
    if critic is None:
        return _INTELLIGENCE_MISSING
    report = critic.analyze()
    return json.dumps(report.model_dump(mode="json"), default=str)


@mcp.tool
def amfs_distill(
    min_confidence: float = 0.3,
    max_entries: int = 500,
) -> str:
    """Generate a distilled memory set — compact, high-signal memories for bootstrapping.

    Like Waymo's Teacher-to-Student distillation: produces a compact set of
    the most valuable memories from the full store, filtered by production
    outcome validation.

    Args:
        min_confidence: Minimum confidence threshold for inclusion (default: 0.3)
        max_entries: Maximum entries in the distilled set (default: 500)

    The distilled set can be used to bootstrap new agents with institutional
    knowledge from production-validated memories.
    """
    distiller = _get_distiller()
    if distiller is None:
        return _INTELLIGENCE_MISSING
    result = distiller.distill(min_confidence=min_confidence, max_entries=max_entries)
    return json.dumps(result.model_dump(mode="json"), default=str)


@mcp.tool
def amfs_validate(
    entity_path: str,
    key: str,
    value: str,
    confidence: float = 1.0,
    memory_type: str = "fact",
) -> str:
    """Validate a proposed memory write before committing it.

    Runs the Memory Safety checks:
    - Contradiction detection against existing entries
    - Temporal consistency verification
    - Confidence threshold checks by memory type

    This is the Safety stage of the AMFS flywheel — nothing is deployed
    until the safety framework confirms absence of unreasonable risk.

    Args:
        entity_path: Target entity path
        key: Target key
        value: Proposed value (plain text or JSON string)
        confidence: Proposed confidence (0.0-1.0)
        memory_type: One of "fact", "belief", "experience"
    """
    from datetime import datetime, timezone
    from amfs_core.models import MemoryEntry, MemoryType, Provenance

    parsed_value: Any = value
    try:
        parsed_value = json.loads(value)
    except (json.JSONDecodeError, TypeError):
        pass

    type_map = {"fact": MemoryType.FACT, "belief": MemoryType.BELIEF, "experience": MemoryType.EXPERIENCE}
    mt = type_map.get(memory_type.lower(), MemoryType.FACT)

    mem = _get_memory()
    proposed = MemoryEntry(
        entity_path=entity_path,
        key=key,
        value=parsed_value,
        provenance=Provenance(
            agent_id=mem.agent_id,
            session_id=mem.session_id,
            written_at=datetime.now(timezone.utc),
        ),
        confidence=confidence,
        memory_type=mt,
    )

    validator = _get_validator()
    if validator is None:
        return _INTELLIGENCE_MISSING
    result = validator.validate_write(proposed)
    return json.dumps(result.model_dump(mode="json"), default=str)


@mcp.tool
def amfs_retrieve(
    query: str,
    entity_path: str | None = None,
    min_confidence: float = 0.0,
    limit: int = 10,
) -> str:
    """Multi-strategy retrieval — search memories using semantic, keyword, temporal, and confidence signals.

    Runs multiple retrieval strategies in parallel and merges results using
    Reciprocal Rank Fusion (RRF). More effective than single-strategy search
    for complex queries.

    Args:
        query: Natural language query
        entity_path: Optional entity path filter
        min_confidence: Minimum confidence threshold
        limit: Maximum results to return

    Returns results ranked by combined score with per-strategy breakdowns.
    """
    retriever = _get_retriever()
    if retriever is None:
        return _oss_amfs_retrieve(query=query, entity_path=entity_path, min_confidence=min_confidence, limit=limit)
    results = retriever.retrieve(
        query,
        entity_path=entity_path,
        min_confidence=min_confidence,
        limit=limit,
    )
    return json.dumps(
        [r.model_dump(mode="json") for r in results],
        default=str,
    )


# ──────────────────────────────────────────────────────────────────────
# ML Layer Tools
# ──────────────────────────────────────────────────────────────────────


@mcp.tool
def amfs_retrain(
    entity_path: str | None = None,
) -> str:
    """Train (or retrain) the learned ranking model from outcome data.

    Analyzes historical outcomes and the entries they touched to build a
    gradient-boosted model that predicts which memories are most useful.
    Once trained, the model automatically enhances amfs_retrieve results.

    Args:
        entity_path: Optional filter to train only on outcomes for a specific entity.

    Returns training metrics including accuracy, sample counts, and feature importances.
    Requires at least 20 outcome-linked entries to train; falls back to heuristic
    ranking when insufficient data.
    """
    if LearnedRanker is None:
        return _INTELLIGENCE_MISSING
    mem = _get_memory()
    ranker = LearnedRanker(mem.adapter, model_path=_MODEL_DIR / "ranker.pkl")

    outcomes = mem.adapter.list_outcomes(entity_path=entity_path)
    entries = mem.adapter.list(entity_path)
    metrics = ranker.train(outcomes=outcomes, entries=entries)

    return json.dumps(metrics.model_dump(mode="json"), default=str)


@mcp.tool
def amfs_calibrate(
    entity_path: str | None = None,
    per_entity: bool = False,
) -> str:
    """Learn optimal confidence multipliers from historical outcome data.

    Instead of fixed multipliers (P1=1.15, clean_deploy=0.97), this analyzes
    actual outcome patterns to find multipliers that better predict entry
    usefulness. Can produce global and per-entity overrides.

    Args:
        entity_path: Optional filter to calibrate for a specific entity.
        per_entity: If true, also produces per-entity multiplier overrides.

    Returns calibrated multipliers, estimated decay half-life, and analysis stats.
    """
    if ConfidenceCalibrator is None:
        return _INTELLIGENCE_MISSING
    mem = _get_memory()
    calibrator = ConfidenceCalibrator(mem.adapter)
    report = calibrator.calibrate(entity_path=entity_path, per_entity=per_entity)
    return json.dumps(report.model_dump(mode="json"), default=str)


@mcp.tool
def amfs_export_training_data(
    format: str = "sft",
    entity_path: str | None = None,
    limit: int = 10000,
) -> str:
    """Export decision traces as fine-tuning datasets for agent training.

    Generates structured training data from AMFS's outcome-linked decision
    traces. Your agents' successful and failed decisions become training
    examples — no manual labeling required.

    Args:
        format: Output format — "sft" (supervised fine-tuning), "dpo"
                (direct preference optimization), or "reward_model".
        entity_path: Optional entity filter.
        limit: Maximum examples to export.

    SFT: successful decision traces as (context, decision) examples.
    DPO: paired (chosen, rejected) from positive vs negative outcomes.
    Reward Model: entries labeled by outcome quality score.
    """
    if TrainingDataExporter is None:
        return _INTELLIGENCE_MISSING
    mem = _get_memory()
    exporter = TrainingDataExporter(mem.adapter)
    result = exporter.export(
        format=format,
        entity_path=entity_path,
        limit=limit,
    )
    return json.dumps(result.model_dump(mode="json"), default=str)


# ──────────────────────────────────────────────────────────────────────
# Decision Trace Tools
# ──────────────────────────────────────────────────────────────────────


def _get_trace_store():
    try:
        from amfs_traces.store import InMemoryTraceStore, PostgresImmutableTraceStore
    except ImportError:
        return None
    dsn = os.environ.get("AMFS_POSTGRES_DSN")
    if dsn:
        import psycopg
        from psycopg.rows import dict_row
        conn = psycopg.connect(dsn, row_factory=dict_row, autocommit=True)
        return PostgresImmutableTraceStore(conn)
    return InMemoryTraceStore()


@mcp.tool
def amfs_record_llm_call(
    model: str = "",
    provider: str = "",
    input_tokens: int = 0,
    output_tokens: int = 0,
    cached_tokens: int = 0,
    reasoning_tokens: int = 0,
    latency_ms: float | None = None,
    cost_usd: float | None = None,
    finish_reason: str | None = None,
    error: str | None = None,
    request_id: str | None = None,
) -> str:
    """Record an LLM call in the current session's decision trace.

    Captures token usage, cost, latency, and model metadata for each LLM
    invocation. Aggregated totals are included in the sealed trace on commit.

    Args:
        model: Model identifier (e.g. "gpt-4o", "claude-sonnet-4-20250514").
        provider: Provider name (e.g. "openai", "anthropic").
        input_tokens: Number of input/prompt tokens.
        output_tokens: Number of output/completion tokens.
        cached_tokens: Number of tokens served from cache.
        reasoning_tokens: Number of reasoning/chain-of-thought tokens.
        latency_ms: End-to-end call latency in milliseconds.
        cost_usd: Estimated cost in USD.
        finish_reason: Why the generation stopped (e.g. "stop", "length").
        error: Error message if the call failed.
        request_id: Provider-specific request identifier for debugging.
    """
    try:
        from amfs_traces.models import LLMCall
    except ImportError:
        return _INTELLIGENCE_MISSING

    mem = _get_memory()
    tracker = mem._read_tracker

    call = LLMCall(
        model=model,
        provider=provider,
        input_tokens=input_tokens,
        output_tokens=output_tokens,
        cached_tokens=cached_tokens,
        reasoning_tokens=reasoning_tokens,
        latency_ms=latency_ms,
        cost_usd=cost_usd,
        finish_reason=finish_reason,
        error=error,
        request_id=request_id,
    )

    if not hasattr(tracker, "_llm_calls"):
        tracker._llm_calls = []
    tracker._llm_calls.append(call.model_dump(mode="json"))

    return json.dumps({
        "recorded": True,
        "call_id": call.call_id,
        "model": model,
        "tokens": input_tokens + output_tokens,
        "cost_usd": cost_usd,
    }, default=str)


@mcp.tool
def amfs_trace_verify(trace_id: str) -> str:
    """Verify the cryptographic integrity of a decision trace.

    Recomputes the content hash and verifies the HMAC-SHA256 signature.
    Returns a verification result with status, any errors found, and the
    trace's position in its session's Merkle chain.

    Args:
        trace_id: UUID of the immutable decision trace to verify.

    Returns JSON with: valid (bool), errors (list), content_hash,
    chain_position, chain_length.
    """
    store = _get_trace_store()
    if store is None:
        return _INTELLIGENCE_MISSING
    try:
        from amfs_traces.crypto import get_signing_key, verify
    except ImportError:
        return _INTELLIGENCE_MISSING
    trace = store.get(trace_id)
    if trace is None:
        return json.dumps({"error": f"Trace {trace_id} not found"})

    key = get_signing_key()
    result = verify(trace, key)

    chain = store.get_chain(trace.session_id)
    chain_position = next(
        (i for i, t in enumerate(chain) if str(t.id) == str(trace.id)), -1
    )

    data = result.model_dump(mode="json")
    data["chain_position"] = chain_position
    data["chain_length"] = len(chain)
    return json.dumps(data, default=str)


@mcp.tool
def amfs_trace_replay(trace_id: str) -> str:
    """Reconstruct the exact memory state an agent had at decision time.

    Uses CoW versioning to fetch each entry at the specific historical
    version recorded in the trace. Verifies the reconstructed state hash
    matches the trace's original memory_snapshot_hash.

    Args:
        trace_id: UUID of the immutable decision trace to replay.

    Returns the full ReplayContext: memory_state (dict of entries at
    their decision-time versions), external_contexts, tool_calls,
    write_events, outcome, and verification status.
    """
    store = _get_trace_store()
    if store is None:
        return _INTELLIGENCE_MISSING
    try:
        from amfs_traces.replay import ReplayEngine
    except ImportError:
        return _INTELLIGENCE_MISSING
    mem = _get_memory()
    engine = ReplayEngine(mem.adapter, store)

    try:
        ctx = engine.reconstruct(trace_id)
    except ValueError as exc:
        return json.dumps({"error": str(exc)})

    return json.dumps(ctx.model_dump(mode="json"), default=str)


@mcp.tool
def amfs_trace_interactions(
    agent_id: str | None = None,
    limit: int = 100,
) -> str:
    """Query the inter-agent interaction graph from decision traces.

    Shows which agents read from and wrote to each other's memory,
    revealing collaboration patterns and dependency chains.

    Args:
        agent_id: Optional filter to show interactions involving a specific agent.
        limit: Maximum number of traces to analyze (default: 100).

    Returns a graph with agent nodes (with trace/read/write counts)
    and directed edges representing memory exchange between agents.
    """
    store = _get_trace_store()
    if store is None:
        return _INTELLIGENCE_MISSING
    try:
        from amfs_traces.interactions import build_interaction_graph
        from amfs_traces.models import TraceSearchQuery
    except ImportError:
        return _INTELLIGENCE_MISSING
    query = TraceSearchQuery(agent_id=agent_id, limit=limit)
    traces = store.search(query)
    graph = build_interaction_graph(traces)
    return json.dumps(graph.model_dump(mode="json"), default=str)


# ──────────────────────────────────────────────────────────────────────
# Knowledge Graph (Pro)
# ──────────────────────────────────────────────────────────────────────


@mcp.tool
def amfs_graph_path(
    from_entity: str,
    to_entity: str,
    max_depth: int = 5,
    min_path_confidence: float = 0.1,
) -> str:
    """Find the shortest trust-weighted path between two entities in the knowledge graph.

    Path confidence is the product of all edge confidences along the path.
    Uses Dijkstra with -log(confidence) as edge weight.

    Args:
        from_entity: Starting entity
        to_entity: Target entity
        max_depth: Maximum path length (default: 5)
        min_path_confidence: Minimum acceptable path confidence (default: 0.1)
    """
    import math
    import heapq
    from collections import defaultdict

    mem = _get_memory()
    edges = mem.adapter.list_graph_edges(
        namespace=mem.namespace,
        branch=getattr(mem, "_branch", "main"),
        limit=5000,
    )
    if not edges:
        return json.dumps({"error": "No graph edges found"})

    adj: dict[str, list[tuple[str, float, dict]]] = defaultdict(list)
    for e in edges:
        weight = -math.log(max(e.confidence, 1e-9))
        data = e.model_dump(mode="json")
        adj[e.source_entity].append((e.target_entity, weight, data))
        adj[e.target_entity].append((e.source_entity, weight, data))

    dist = {from_entity: 0.0}
    prev: dict[str, tuple[str, dict]] = {}
    heap = [(0.0, 0, from_entity)]
    visited: set[str] = set()
    counter = 0

    while heap:
        d, _, node = heapq.heappop(heap)
        if node in visited:
            continue
        visited.add(node)
        if node == to_entity:
            break
        for neighbor, w, edge_data in adj.get(node, []):
            if neighbor in visited:
                continue
            nd = d + w
            if neighbor not in dist or nd < dist[neighbor]:
                dist[neighbor] = nd
                prev[neighbor] = (node, edge_data)
                counter += 1
                heapq.heappush(heap, (nd, counter, neighbor))

    if to_entity not in prev and from_entity != to_entity:
        return json.dumps({"error": f"No path from '{from_entity}' to '{to_entity}'"})

    path_edges: list[dict] = []
    node = to_entity
    while node in prev:
        parent, edge_data = prev[node]
        path_edges.append(edge_data)
        node = parent
    path_edges.reverse()

    path_confidence = math.exp(-dist.get(to_entity, 0.0))
    if path_confidence < min_path_confidence:
        return json.dumps({"error": f"Path confidence {path_confidence:.3f} below threshold"})

    return json.dumps({
        "path": path_edges,
        "path_confidence": round(path_confidence, 4),
        "hops": len(path_edges),
    }, default=str)


@mcp.tool
def amfs_graph_query(
    relation: str | None = None,
    source_type: str | None = None,
    target_type: str | None = None,
    min_confidence: float = 0.0,
    min_evidence: int = 1,
    limit: int = 50,
) -> str:
    """Search the knowledge graph by relation type, entity type, or confidence.

    Args:
        relation: Filter by relation (e.g. "references", "informed", "learned_from")
        source_type: Filter by source entity type (e.g. "agent", "entry", "outcome")
        target_type: Filter by target entity type
        min_confidence: Minimum edge confidence
        min_evidence: Minimum evidence count
        limit: Maximum edges to return
    """
    mem = _get_memory()
    edges = mem.adapter.list_graph_edges(
        relation=relation,
        min_confidence=min_confidence,
        namespace=mem.namespace,
        branch=getattr(mem, "_branch", "main"),
        limit=limit * 5,
    )

    filtered = []
    for e in edges:
        if source_type and e.source_type != source_type:
            continue
        if target_type and e.target_type != target_type:
            continue
        if e.evidence_count < min_evidence:
            continue
        filtered.append(e.model_dump(mode="json"))
        if len(filtered) >= limit:
            break

    return json.dumps({"edges": filtered, "total": len(filtered)}, default=str)


# ──────────────────────────────────────────────────────────────────────
# Room-enhanced briefing (Pro)
# ──────────────────────────────────────────────────────────────────────

@mcp.tool
def amfs_briefing(
    entity_path: str | None = None,
    agent_id: str | None = None,
    limit: int = 10,
) -> str:
    """Get a compiled knowledge briefing — call at the START of every session.

    Enhanced with room context: shows active rooms you belong to, recent room
    activity, pending invitations, and room-scoped knowledge alongside normal
    briefing digests.

    Args:
        entity_path: Focus on this entity (e.g. "checkout-service")
        agent_id: Focus on this agent's context (defaults to current agent)
        limit: Max digests to return (default 10)
    """
    mem = _get_memory()
    digests = mem.briefing(entity_path=entity_path, agent_id=agent_id, limit=limit)

    result: dict[str, Any] = {}
    if digests:
        result["digests"] = [d.model_dump(mode="json") for d in digests]
    else:
        result["status"] = "empty"
        result["message"] = (
            "No compiled briefings yet. "
            "Use amfs_search() or amfs_recall() to find existing memories, "
            "or amfs_write() to start building knowledge."
        )

    try:
        svc = _get_room_service()
        if svc:
            account_id_str = _get_account_id_from_context()
            user_id_str = _get_user_id_from_context()
            if account_id_str and user_id_str:
                from uuid import UUID
                rooms = svc.list_rooms(UUID(account_id_str), UUID(user_id_str))
                active_rooms = [r for r in rooms if r.get("status") == "open"]
                if active_rooms:
                    result["rooms"] = [{
                        "id": str(r.get("id")),
                        "entity_path": r.get("entity_path"),
                        "display_name": r.get("display_name"),
                        "agent_count": r.get("agent_count", 0),
                        "your_role": r.get("your_role"),
                        "discussions_enabled": r.get("discussions_enabled"),
                    } for r in active_rooms[:5]]
                    result["room_hint"] = (
                        f"You have access to {len(active_rooms)} active room(s). "
                        "Use amfs_my_rooms() for details, amfs_room_join(room_id) to join, "
                        "or amfs_room_updates(room_id) to check recent activity."
                    )
    except Exception:
        logger.debug("Failed to add room context to briefing", exc_info=True)

    return json.dumps(result, default=str)


# ──────────────────────────────────────────────────────────────────────
# Room-aware write/read overrides (Pro)
# ──────────────────────────────────────────────────────────────────────
# These re-register the OSS tools with room membership checks,
# knowledge sync triggers, and activity logging.

def _get_room_middleware():
    """Lazily create a RoomWriteMiddleware."""
    mem = _get_memory()
    pool = getattr(mem._adapter, "_pool", None)
    if pool is None:
        return None
    try:
        from amfs_rooms.middleware import RoomWriteMiddleware
        from amfs_rooms.knowledge_sync import KnowledgeSyncWorker
        ks = KnowledgeSyncWorker(pool=pool, get_memory=_get_memory)
        extraction_worker = None
        try:
            from amfs_rooms.extraction import RoomExtractionWorker
            extraction_worker = RoomExtractionWorker(pool)
        except ImportError:
            pass
        return RoomWriteMiddleware(
            pool=pool, knowledge_sync=ks, extraction_worker=extraction_worker,
        )
    except ImportError:
        return None


@mcp.tool
def amfs_write(
    entity_path: str,
    key: str,
    value: str,
    confidence: float = 1.0,
    pattern_refs: list[str] | None = None,
    memory_type: str = "fact",
    artifact_refs: list[dict[str, Any]] | None = None,
    shared: bool = True,
) -> str:
    """Write a memory entry with automatic provenance tracking.

    In rooms: if the entity has an open room, room membership is checked
    and the write is propagated to all room members' private memory.

    WHEN TO WRITE (only write things that help a future agent):
    - After completing a task: key="task-summary-<desc>", value="what you did and why"
    - When discovering a pattern: key="pattern-<name>", add pattern_refs
    - When finding a bug or risk: key="risk-<name>", use memory_type="belief"
    - When making a non-obvious decision: key="decision-<topic>", include rationale
    - When logging actions: key="action-<desc>", use memory_type="experience"

    Args:
        entity_path: Hierarchical path like "repo/service" (e.g. "amfs/core-engine")
        key: Name for this piece of knowledge
        value: The knowledge to store — can be plain text or JSON string
        confidence: How confident you are (1.0=verified, 0.7-0.9=high, 0.4-0.6=hypothesis)
        pattern_refs: Optional list of related pattern keys
        memory_type: One of "fact" (default), "belief" (decays faster), "experience" (decays slower)
        artifact_refs: Optional list of external artifact references
        shared: If True (default), other agents can read. If False, private.
    """
    from amfs_core.models import MemoryType, ArtifactRef

    middleware = _get_room_middleware()
    account_id_str = _get_account_id_from_context()
    room = None

    if middleware and account_id_str:
        from uuid import UUID
        try:
            room = middleware.check_write_access(
                entity_path=entity_path,
                agent_id=_get_memory().agent_id,
                account_id=UUID(account_id_str),
            )
        except PermissionError as e:
            return json.dumps({"error": str(e)})

    mem = _get_memory()
    parsed_value: Any = value
    try:
        parsed_value = json.loads(value)
    except (json.JSONDecodeError, TypeError):
        pass

    type_map = {"fact": MemoryType.FACT, "belief": MemoryType.BELIEF, "experience": MemoryType.EXPERIENCE}
    mt = type_map.get(memory_type.lower(), MemoryType.FACT)

    parsed_artifact_refs = [ArtifactRef.model_validate(r) for r in (artifact_refs or [])]

    entry = mem.write(
        entity_path, key, parsed_value,
        confidence=confidence, pattern_refs=pattern_refs,
        memory_type=mt, artifact_refs=parsed_artifact_refs,
        shared=shared,
    )

    if room and middleware and account_id_str:
        from uuid import UUID
        middleware.after_write(
            room=room, entity_path=entity_path,
            key=key, value=parsed_value,
            confidence=confidence, agent_id=mem.agent_id,
            account_id=UUID(account_id_str),
        )

    return json.dumps(_serialize_entry(entry), default=str)


@mcp.tool
def amfs_read(entity_path: str, key: str) -> str:
    """Read a memory entry by entity path and key.

    In rooms: visibility is checked via the VisibilityFilter. Cross-user
    reads through rooms are logged on both agent timelines.

    Returns the full entry as JSON including value, confidence, provenance,
    and version. Returns a message if the entry does not exist.
    """
    mem = _get_memory()
    entry = mem.read(entity_path, key)
    if entry is None:
        return json.dumps({"status": "not_found", "entity_path": entity_path, "key": key})

    middleware = _get_room_middleware()
    account_id_str = _get_account_id_from_context()

    if middleware and account_id_str and entry:
        from uuid import UUID
        author = None
        if hasattr(entry, "provenance") and hasattr(entry.provenance, "agent_id"):
            author = entry.provenance.agent_id
        if author and author != mem.agent_id:
            try:
                from amfs_rooms.service import RoomService
                pool = getattr(mem._adapter, "_pool", None)
                if pool:
                    svc = RoomService(pool)
                    room = svc.get_room_by_entity(entity_path, UUID(account_id_str))
                    if room:
                        middleware.log_read(
                            room_id=room["id"],
                            entity_path=entity_path,
                            key=key,
                            agent_id=mem.agent_id,
                            account_id=UUID(account_id_str),
                            author_agent_id=author,
                        )
            except Exception:
                logger.debug("Failed to log room read", exc_info=True)

    return json.dumps(_serialize_entry(entry), default=str)


# ──────────────────────────────────────────────────────────────────────
# Room Tools (Pro)
# ──────────────────────────────────────────────────────────────────────

def _get_room_service():
    """Lazily create a RoomService from the adapter's DB pool."""
    mem = _get_memory()
    pool = getattr(mem._adapter, "_pool", None)
    if pool is None:
        return None
    try:
        from amfs_rooms.service import RoomService
        return RoomService(pool)
    except ImportError:
        return None


def _get_user_id_from_context() -> str | None:
    """Resolve the owner_user_id for the current agent from the DB."""
    mem = _get_memory()
    pool = getattr(mem._adapter, "_pool", None)
    if pool is None:
        return None
    try:
        with pool.connection() as conn:
            row = conn.execute(
                "SELECT owner_user_id FROM agents WHERE agent_id = %s LIMIT 1",
                (mem.agent_id,),
            ).fetchone()
            return str(row[0]) if row else None
    except Exception:
        return None


def _get_account_id_from_context() -> str | None:
    """Resolve the account_id from the adapter pool or env."""
    mem = _get_memory()
    pool = getattr(mem._adapter, "_pool", None)
    if pool is None:
        return None
    try:
        with pool.connection() as conn:
            row = conn.execute(
                "SELECT account_id FROM agents WHERE agent_id = %s LIMIT 1",
                (mem.agent_id,),
            ).fetchone()
            return str(row[0]) if row else None
    except Exception:
        return None


@mcp.tool
def amfs_room_join(room_id: str) -> str:
    """Join a room. Your user must have an accepted invitation.

    Triggers auto-briefing with room history (writes, decisions, failures,
    current state) delivered to your private memory.

    Args:
        room_id: UUID of the room to join
    """
    gate = _require_tier(*_ROOMS_TIERS)
    if gate:
        return gate
    svc = _get_room_service()

    # HTTP fallback
    if svc is None:
        mem = _get_memory()
        result = _rooms_http("POST", f"{room_id}/agents", {"agent_id": mem.agent_id})
        if isinstance(result, dict) and "error" in result:
            return json.dumps(result)
        return json.dumps({
            "status": "joined",
            "room_id": room_id,
            "role": result.get("role", "member") if isinstance(result, dict) else "member",
        }, default=str)

    mem = _get_memory()
    user_id = _get_user_id_from_context()
    account_id = _get_account_id_from_context()
    if not user_id or not account_id:
        return json.dumps({"error": "Could not resolve agent ownership"})

    from uuid import UUID
    membership = svc.agent_join(
        room_id=UUID(room_id),
        account_id=UUID(account_id),
        agent_id=mem.agent_id,
        owner_user_id=UUID(user_id),
    )
    if membership is None:
        return json.dumps({
            "error": "Cannot join room — your user must have an accepted invitation, "
                     "or you are the room owner"
        })

    briefing_text = None
    try:
        pool = getattr(mem._adapter, "_pool", None)
        if pool:
            from amfs_rooms.briefing import JoinBriefingService
            room = svc.get_room(UUID(room_id), UUID(account_id))
            if room:
                briefing_svc = JoinBriefingService(pool=pool, get_memory=_get_memory)
                briefing_text = briefing_svc.generate_and_deliver(
                    room_id=UUID(room_id),
                    entity_path=room["entity_path"],
                    agent_id=mem.agent_id,
                    account_id=UUID(account_id),
                )
    except Exception:
        logger.debug("Failed to generate join briefing", exc_info=True)

    return json.dumps({
        "status": "joined",
        "room_id": room_id,
        "role": membership.get("role", "member"),
        "briefing": briefing_text[:2000] if briefing_text else None,
    }, default=str)


@mcp.tool
def amfs_room_leave(room_id: str) -> str:
    """Leave a room. Your knowledge snapshot is preserved in your private memory.

    Args:
        room_id: UUID of the room to leave
    """
    gate = _require_tier(*_ROOMS_TIERS)
    if gate:
        return gate
    svc = _get_room_service()

    # HTTP fallback
    if svc is None:
        mem = _get_memory()
        result = _rooms_http("DELETE", f"{room_id}/agents/{mem.agent_id}")
        if isinstance(result, dict) and "error" in result:
            return json.dumps(result)
        return json.dumps({"status": "left", "room_id": room_id})

    mem = _get_memory()
    account_id = _get_account_id_from_context()
    if not account_id:
        return json.dumps({"error": "Could not resolve account"})

    from uuid import UUID
    if svc.agent_leave(UUID(room_id), UUID(account_id), mem.agent_id):
        return json.dumps({"status": "left", "room_id": room_id})
    return json.dumps({"error": "Not a member of this room"})


@mcp.tool
def amfs_my_rooms() -> str:
    """List rooms you're a member of, plus rooms your user is invited to.

    Call this early in every session to discover shared team workspaces.
    Rooms contain shared knowledge from other team members — joining them
    gives you access to existing decisions, patterns, and context.

    Returns room details including entity path, member count, and your role.
    If you have rooms available, join them with amfs_room_join(room_id).
    """
    gate = _require_tier(*_ROOMS_TIERS)
    if gate:
        return gate
    svc = _get_room_service()

    # HTTP fallback — SaaS MCP has no local DB pool
    if svc is None:
        result = _rooms_http("GET", "")
        if isinstance(result, list):
            invites = _rooms_http("GET", "my-invites")
            inv_list = invites if isinstance(invites, list) else []
            rooms = result + [
                {**inv, "your_role": "invited"}
                for inv in inv_list
            ]
            if not rooms:
                return json.dumps({
                    "rooms": [],
                    "count": 0,
                    "hint": "No rooms available yet. Your team can create rooms on entities "
                            "from the dashboard to enable multi-agent collaboration.",
                }, default=str)
            hint = (
                f"You have {len(rooms)} room(s) available. "
                "Join rooms with amfs_room_join(room_id) to access shared team knowledge. "
                "Writes to room entities are automatically shared with all members."
            )
            return json.dumps({"rooms": rooms, "count": len(rooms), "hint": hint}, default=str)
        if isinstance(result, dict) and "error" in result:
            return json.dumps(result)
        return json.dumps(result, default=str)

    user_id = _get_user_id_from_context()
    account_id = _get_account_id_from_context()
    if not user_id or not account_id:
        return json.dumps({"error": "Could not resolve agent ownership"})

    from uuid import UUID
    rooms = svc.list_rooms(UUID(account_id), UUID(user_id))

    if not rooms:
        return json.dumps({
            "rooms": [],
            "count": 0,
            "hint": "No rooms available yet. Your team can create rooms on entities "
                    "from the dashboard to enable multi-agent collaboration.",
        }, default=str)

    room_list = []
    for r in rooms:
        room_data = {
            "id": str(r.get("id")),
            "entity_path": r.get("entity_path"),
            "display_name": r.get("display_name"),
            "status": r.get("status"),
            "discussions_enabled": r.get("discussions_enabled"),
            "agent_count": r.get("agent_count", 0),
            "user_count": r.get("user_count", 0),
            "your_role": r.get("your_role"),
            "last_activity_at": r.get("last_activity_at"),
        }
        room_list.append(room_data)

    hint = (
        f"You have {len(rooms)} room(s) available. "
        "Join rooms with amfs_room_join(room_id) to access shared team knowledge. "
        "Writes to room entities are automatically shared with all members."
    )
    return json.dumps({
        "rooms": room_list,
        "count": len(rooms),
        "hint": hint,
    }, default=str)


@mcp.tool
def amfs_room_info(room_id: str) -> str:
    """Get room details: entity_path, members, settings, discussions status.

    Args:
        room_id: UUID of the room
    """
    gate = _require_tier(*_ROOMS_TIERS)
    if gate:
        return gate
    svc = _get_room_service()

    # HTTP fallback
    if svc is None:
        room_data = _rooms_http("GET", room_id)
        if isinstance(room_data, dict) and "error" in room_data:
            return json.dumps(room_data)
        agents_data = _rooms_http("GET", f"{room_id}/agents")
        neg_data = _rooms_http("GET", f"{room_id}/negotiations")
        members_list = agents_data if isinstance(agents_data, list) else []
        neg_list = neg_data if isinstance(neg_data, list) else []
        pending = [n for n in neg_list if n.get("status") in ("open", "in_progress")]
        return json.dumps({
            "room": room_data,
            "members": members_list,
            "member_count": len(members_list),
            "pending_negotiations": pending,
        }, default=str)

    account_id = _get_account_id_from_context()
    if not account_id:
        return json.dumps({"error": "Could not resolve account"})

    from uuid import UUID
    room = svc.get_room(UUID(room_id), UUID(account_id))
    if room is None:
        return json.dumps({"error": "Room not found"})

    members = svc.list_members(UUID(room_id), UUID(account_id))

    pending_negotiations = []
    try:
        pool = getattr(_get_memory()._adapter, "_pool", None)
        if pool:
            from psycopg.rows import dict_row as _dr
            with pool.connection() as conn:
                conn.row_factory = _dr
                conn.execute(
                    "SELECT set_config('amfs.current_account_id', %s, false)",
                    (str(account_id),),
                )
                rows = conn.execute(
                    "SELECT id, title, status, created_by, created_at "
                    "FROM negotiation_sessions "
                    "WHERE room_id = %s AND status IN ('open', 'in_progress') "
                    "ORDER BY created_at DESC LIMIT 10",
                    (room_id,),
                ).fetchall()
                pending_negotiations = [dict(r) for r in rows]
    except Exception:
        logger.debug("Failed to fetch pending negotiations", exc_info=True)

    return json.dumps({
        "room": {k: v for k, v in room.items() if k != "settings"},
        "members": [{
            "agent_id": m.get("agent_id"),
            "owner_user_id": str(m.get("owner_user_id")),
            "role": m.get("role"),
            "joined_at": m.get("joined_at"),
        } for m in members],
        "member_count": len(members),
        "pending_negotiations": pending_negotiations,
    }, default=str)


@mcp.tool
def amfs_room_updates(
    room_id: str,
    since: str | None = None,
) -> str:
    """Check for new activity in a room since a given timestamp.

    Returns new writes, discussion messages, negotiation events, and
    agent join/leave events. If 'since' is omitted, returns the last
    20 events.

    Use this between tasks to stay aware of what other agents are doing
    in the room.

    Args:
        room_id: UUID of the room
        since: ISO timestamp — only return events after this time
    """
    gate = _require_tier(*_ROOMS_TIERS)
    if gate:
        return gate
    svc = _get_room_service()

    # HTTP fallback
    if svc is None:
        qs = f"?since={since}" if since else ""
        result = _rooms_http("GET", f"{room_id}/activity{qs}")
        if isinstance(result, dict) and "error" in result:
            return json.dumps(result)
        items = result.get("items", []) if isinstance(result, dict) else []
        negotiation_events = [
            i for i in items
            if i.get("activity_type") in ("negotiation_started", "negotiation_round")
        ]
        action_hint = None
        if negotiation_events:
            action_hint = (
                f"There are {len(negotiation_events)} negotiation event(s). "
                "Review the topic and submit your initial position using amfs_negotiate_propose. "
                "You may propose freely, but you MUST ask your user before accepting or rejecting any proposal."
            )
        return json.dumps({
            "events": items,
            "count": len(items),
            "total": result.get("total", len(items)) if isinstance(result, dict) else len(items),
            **({"action_needed": action_hint} if action_hint else {}),
        }, default=str)

    account_id = _get_account_id_from_context()
    if not account_id:
        return json.dumps({"error": "Could not resolve account"})

    from uuid import UUID
    from datetime import datetime
    since_dt = None
    if since:
        try:
            since_dt = datetime.fromisoformat(since)
        except ValueError:
            return json.dumps({"error": "Invalid ISO timestamp for 'since'"})

    items, total = svc.list_activity(
        UUID(room_id), UUID(account_id),
        limit=50 if since_dt else 20,
        since=since_dt,
    )

    negotiation_events = [
        i for i in items
        if i.get("activity_type") in ("negotiation_started", "negotiation_round")
    ]
    action_hint = None
    if negotiation_events:
        action_hint = (
            f"There are {len(negotiation_events)} negotiation event(s). "
            "Review the topic and submit your initial position using amfs_negotiate_propose. "
            "You may propose freely, but you MUST ask your user before accepting or rejecting any proposal."
        )

    return json.dumps({
        "events": [{
            "activity_type": i.get("activity_type"),
            "agent_id": i.get("agent_id"),
            "details": i.get("details", {}),
            "created_at": i.get("created_at"),
        } for i in items],
        "count": len(items),
        "total": total,
        **({"action_needed": action_hint} if action_hint else {}),
    }, default=str)


# ──────────────────────────────────────────────────────────────────────
# Negotiation + Discussion MCP tools (Phase 2)
# ──────────────────────────────────────────────────────────────────────

def _get_negotiation_engine():
    """Lazily create a NegotiationEngine."""
    mem = _get_memory()
    pool = getattr(mem._adapter, "_pool", None)
    if pool is None:
        return None
    try:
        from amfs_rooms.negotiation import NegotiationEngine
        return NegotiationEngine(pool=pool, get_memory=_get_memory)
    except ImportError:
        return None


def _resolve_room_id_for_session(session_id: str) -> str | None:
    """Search memory for the room_id associated with a negotiation session."""
    try:
        mem = _get_memory()
        entries = mem.search(query=session_id, limit=10)
        for e in entries:
            try:
                val = json.loads(e.value) if isinstance(e.value, str) else e.value
                if isinstance(val, dict) and val.get("session_id") == session_id:
                    return val.get("room_id")
            except Exception:
                continue
    except Exception:
        pass
    return None


def _rooms_http(method: str, path: str, body: dict | None = None) -> dict:
    """HTTP fallback for room/negotiation tools when no local DB pool (SaaS MCP mode)."""
    import urllib.request
    import urllib.error

    base_url = os.environ.get("AMFS_HTTP_URL", "")
    api_key = os.environ.get("AMFS_API_KEY", "")
    if not base_url:
        return {"error": "No AMFS_HTTP_URL configured — cannot reach rooms API"}

    url = f"{base_url}/api/v1/rooms/{path}" if path else f"{base_url}/api/v1/rooms"
    headers = {"Content-Type": "application/json"}
    if api_key:
        headers["X-AMFS-API-Key"] = api_key

    data = json.dumps(body).encode() if body else None
    req = urllib.request.Request(url, data=data, headers=headers, method=method)

    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            return json.loads(resp.read().decode())
    except urllib.error.HTTPError as e:
        try:
            err_body = json.loads(e.read().decode())
        except Exception:
            err_body = {"detail": e.reason}
        return {"error": err_body.get("detail", str(e)), "status": e.code}
    except Exception as e:
        return {"error": f"HTTP request failed: {e}"}


def _negotiate_via_http(method: str, path: str, body: dict | None = None) -> dict:
    return _rooms_http(method, path, body)


@mcp.tool
def amfs_room_discuss(
    room_id: str,
    content: str,
    message_type: str = "message",
    addressed_to: str | None = None,
) -> str:
    """Post a discussion message in a room (requires discussions_enabled).

    Use this to communicate with other agents in the room. Messages are
    visible to all room members and become part of the room's knowledge base.

    Args:
        room_id: UUID of the room
        content: Message text
        message_type: One of 'message', 'question', 'answer', 'proposal', 'summary'
        addressed_to: Optional agent_id to address the message to
    """
    gate = _require_tier(*_ROOMS_TIERS)
    if gate:
        return gate
    svc = _get_room_service()

    # HTTP fallback
    if svc is None:
        mem = _get_memory()
        body = {
            "agent_id": mem.agent_id or "unknown",
            "content": content,
            "message_type": message_type,
        }
        if addressed_to:
            body["addressed_to"] = addressed_to
        result = _rooms_http("POST", f"{room_id}/discussions", body)
        if isinstance(result, dict) and "error" in result:
            return json.dumps(result)
        return json.dumps({
            "status": "sent",
            "message_id": result.get("id") if isinstance(result, dict) else None,
        }, default=str)

    account_id = _get_account_id_from_context()
    if not account_id:
        return json.dumps({"error": "Could not resolve account"})

    from uuid import UUID
    room = svc.get_room(UUID(room_id), UUID(account_id))
    if room is None:
        return json.dumps({"error": "Room not found"})
    if not room.get("discussions_enabled"):
        return json.dumps({"error": "Discussions are not enabled for this room"})
    if room["status"] != "open":
        return json.dumps({"error": "Room is closed"})

    mem = _get_memory()
    agent_id = mem.agent_id or "unknown"

    import psycopg.types.json
    from psycopg.rows import dict_row
    pool = getattr(mem._adapter, "_pool", None)
    with pool.connection() as conn:
        conn.row_factory = dict_row
        row = conn.execute(
            """INSERT INTO discussion_messages
               (room_id, account_id, agent_id, message_type, content, addressed_to)
               VALUES (%s, %s, %s, %s, %s, %s)
               RETURNING id, created_at""",
            (room_id, account_id, agent_id, message_type, content, addressed_to),
        ).fetchone()
        conn.commit()

    svc.log_activity(
        room_id=UUID(room_id), account_id=UUID(account_id),
        activity_type="discussion_message",
        agent_id=agent_id,
        details={"message_type": message_type},
    )

    return json.dumps({
        "status": "sent",
        "message_id": str(row["id"]) if row else None,
        "created_at": str(row["created_at"]) if row else None,
    }, default=str)


@mcp.tool
def amfs_negotiate_create(
    room_id: str,
    title: str,
    description: str | None = None,
    max_rounds: int = 10,
) -> str:
    """Start a new negotiation session in a room.

    Creates a structured negotiation where agents can propose, counter,
    and reach consensus on decisions. An LLM mediator analyzes each round.

    Args:
        room_id: UUID of the room
        title: Topic of negotiation
        description: Detailed description of what needs to be decided
        max_rounds: Maximum negotiation rounds before timeout (default 10)
    """
    gate = _require_tier(*_ROOMS_TIERS)
    if gate:
        return gate
    engine = _get_negotiation_engine()
    mem = _get_memory()
    agent_id = mem.agent_id or "unknown"

    if engine is None:
        result = _negotiate_via_http("POST", f"{room_id}/negotiations", {
            "title": title,
            "description": description,
            "max_rounds": max_rounds,
            "agent_id": agent_id,
        })
        if "error" in result:
            return json.dumps(result)
        return json.dumps({
            "session_id": str(result.get("id")),
            "title": result.get("title"),
            "status": result.get("status"),
            "max_rounds": result.get("max_rounds"),
            "hint": "Negotiation created via API. Use amfs_negotiate_propose to submit your position.",
        }, default=str)

    account_id = _get_account_id_from_context()
    if not account_id:
        return json.dumps({"error": "Could not resolve account"})

    import asyncio
    from uuid import UUID
    from amfs_rooms.negotiation.models import CreateSessionRequest, NegotiationStrategy

    req = CreateSessionRequest(
        room_id=UUID(room_id),
        title=title,
        description=description,
        strategy=NegotiationStrategy.MEDIATED,
        max_rounds=max_rounds,
    )

    user_id = _get_user_id_from_context()

    loop = asyncio.new_event_loop()
    try:
        session = loop.run_until_complete(
            engine.create_session(
                req, agent_id, UUID(account_id),
                created_by_user_id=UUID(user_id) if user_id else None,
            )
        )
    finally:
        loop.close()

    _log_negotiation_and_discuss(
        room_id, account_id, agent_id, session, title,
    )

    return json.dumps({
        "session_id": str(session.get("id")),
        "title": session.get("title"),
        "status": session.get("status"),
        "max_rounds": session.get("max_rounds"),
        "hint": (
            "Negotiation created and room members notified via discussion. "
            "Use amfs_negotiate_propose to submit your initial position. "
            "Other agents will see this in amfs_room_updates and can respond."
        ),
        "user_hint": (
            "Tell your user: I've started a negotiation on this topic. "
            "Other room members will be notified and their agents will "
            "participate when they next connect."
        ),
    }, default=str)


def _log_negotiation_and_discuss(
    room_id: str, account_id: str, agent_id: str,
    session: dict, title: str,
) -> None:
    """Log activity + post discussion message when negotiation is created via MCP."""
    try:
        svc = _get_room_service()
        if svc is None:
            return
        from uuid import UUID
        svc.log_activity(
            room_id=UUID(room_id), account_id=UUID(account_id),
            activity_type="negotiation_started",
            agent_id=agent_id,
            details={"session_id": str(session.get("id")), "title": title},
        )

        room = svc.get_room(UUID(room_id), UUID(account_id))
        if not room or not room.get("discussions_enabled"):
            return

        pool = getattr(_get_memory()._adapter, "_pool", None)
        if pool is None:
            return

        session_id = session.get("id", "")
        content = (
            f"I've started a new negotiation: **{title}**\n\n"
            f"Session ID: `{session_id}`\n"
            f"All room members are invited to participate using "
            f"`amfs_negotiate_propose` or `amfs_negotiate_respond`."
        )
        from psycopg.rows import dict_row as _dr
        with pool.connection() as conn:
            conn.row_factory = _dr
            conn.execute(
                "SELECT set_config('amfs.current_account_id', %s, false)",
                (str(account_id),),
            )
            conn.execute(
                """INSERT INTO discussion_messages
                   (room_id, account_id, agent_id, message_type, content, metadata)
                   VALUES (%s, %s, %s, 'system', %s, %s::jsonb)""",
                (
                    room_id, str(account_id), agent_id, content,
                    json.dumps({"negotiation_session_id": str(session_id), "auto_generated": True}),
                ),
            )
            conn.commit()

        # Notify room members about the new negotiation
        try:
            from amfs_rooms.notifications import notify_room_members, resolve_agent_owner
            creator_user_id = resolve_agent_owner(pool, UUID(account_id), agent_id)
            notify_room_members(
                pool, svc, UUID(room_id), UUID(account_id),
                exclude_user_id=creator_user_id,
                notification_type="negotiation_started",
                title=f"New negotiation: {title}",
                body=(
                    "A negotiation was started in a room you're a member of. "
                    "Your agent will be prompted to participate automatically."
                ),
                metadata={"session_id": str(session_id), "room_id": room_id},
            )
        except Exception:
            logger.debug("Failed to notify room members from MCP", exc_info=True)

    except Exception:
        logger.debug("Failed to log negotiation activity/discussion", exc_info=True)


@mcp.tool
def amfs_negotiate_propose(
    session_id: str,
    action: str = "propose",
    proposal: str = "{}",
    rationale: str | None = None,
) -> str:
    """Submit a proposal, counter-offer, acceptance, or rejection in a negotiation.

    IMPORTANT: For 'accept' and 'reject' actions, you MUST have explicit user
    approval before calling this tool. Ask your user first and confirm their intent.
    For 'propose' and 'counter' actions, you may act based on available context.

    Args:
        session_id: UUID of the negotiation session
        action: One of 'propose', 'counter', 'accept', 'reject', 'abstain'
        proposal: JSON object with your proposed values for each issue
        rationale: Your reasoning for this action
    """
    gate = _require_tier(*_ROOMS_TIERS)
    if gate:
        return gate
    engine = _get_negotiation_engine()
    mem = _get_memory()
    agent_id = mem.agent_id or "unknown"

    try:
        proposal_dict = json.loads(proposal) if isinstance(proposal, str) else proposal
    except json.JSONDecodeError:
        return json.dumps({"error": "Invalid JSON in proposal"})

    if engine is None:
        room_id = _resolve_room_id_for_session(session_id)
        if not room_id:
            return json.dumps({"error": f"Cannot find room_id for session {session_id}. Search memory for the negotiation entry to find the room_id."})

        result = _negotiate_via_http("POST", f"{room_id}/negotiations/{session_id}/propose", {
            "action": action,
            "proposal": proposal_dict,
            "rationale": rationale,
            "agent_id": agent_id,
        })
        if "error" in result:
            return json.dumps(result)

        return json.dumps({
            "round_number": result.get("round_number"),
            "action": result.get("action"),
            "mediator_analysis": result.get("mediator_analysis"),
            "hint": "Check status with amfs_negotiate_status to see if consensus was reached.",
            "user_hint": f"IMPORTANT: Tell your user that you submitted a {action} in the negotiation.",
        }, default=str)

    import asyncio
    from uuid import UUID
    from amfs_rooms.negotiation.models import SubmitProposalRequest, RoundAction

    req = SubmitProposalRequest(
        session_id=UUID(session_id),
        action=RoundAction(action),
        proposal=proposal_dict,
        rationale=rationale,
    )

    loop = asyncio.new_event_loop()
    try:
        result = loop.run_until_complete(engine.submit_proposal(req, agent_id))
    except ValueError as e:
        return json.dumps({"error": str(e)})
    finally:
        loop.close()

    try:
        pool = getattr(_get_memory()._adapter, "_pool", None)
        if pool:
            from amfs_rooms.notifications import insert_notification, resolve_agent_owner
            acct_id = _get_account_id_from_context()
            owner_id = resolve_agent_owner(pool, UUID(acct_id), agent_id) if acct_id else None
            session_detail = result.get("session") or {}
            title = session_detail.get("title") or session_id
            if owner_id and acct_id:
                room_id = session_detail.get("room_id")
                insert_notification(
                    pool, UUID(acct_id), owner_id,
                    notification_type="agent_engaged",
                    title=f"Your agent participated in '{title}'",
                    body=f"Your agent submitted a {action} in the negotiation.",
                    metadata={"session_id": session_id, "agent_id": agent_id, "action": action},
                    room_id=UUID(room_id) if room_id else None,
                )
    except Exception:
        logger.debug("Failed to notify agent engagement from MCP", exc_info=True)

    user_hint = (
        f"IMPORTANT: Tell your user that you submitted a {action} "
        f"in the negotiation. They can track progress in the dashboard."
    )

    return json.dumps({
        "round_number": result.get("round_number"),
        "action": result.get("action"),
        "mediator_analysis": result.get("mediator_analysis"),
        "hint": "Check status with amfs_negotiate_status to see if consensus was reached.",
        "user_hint": user_hint,
    }, default=str)


@mcp.tool
def amfs_negotiate_respond(
    session_id: str,
    action: str,
    rationale: str | None = None,
) -> str:
    """Respond to the current proposal in a negotiation (accept/reject/counter).

    Shorthand for amfs_negotiate_propose with the response action.

    Args:
        session_id: UUID of the negotiation session
        action: One of 'accept', 'reject', 'counter', 'abstain'
        rationale: Your reasoning for this response
    """
    gate = _require_tier(*_ROOMS_TIERS)
    if gate:
        return gate
    return amfs_negotiate_propose(
        session_id=session_id,
        action=action,
        proposal="{}",
        rationale=rationale,
    )


@mcp.tool
def amfs_negotiate_status(
    session_id: str,
) -> str:
    """Get the current state of a negotiation session.

    Returns issues, positions, round history, mediator analysis,
    and opponent classifications. Use to inform your next move.

    Args:
        session_id: UUID of the negotiation session
    """
    gate = _require_tier(*_ROOMS_TIERS)
    if gate:
        return gate
    engine = _get_negotiation_engine()

    if engine is None:
        room_id = _resolve_room_id_for_session(session_id)
        if not room_id:
            return json.dumps({"error": f"Could not resolve room_id for session {session_id}. Search memory for the negotiation entry to find the room_id."})

        result = _negotiate_via_http("GET", f"{room_id}/negotiations/{session_id}", None)
        if "error" in result:
            return json.dumps(result)
        return json.dumps(result, default=str)

    import asyncio
    from uuid import UUID

    loop = asyncio.new_event_loop()
    try:
        detail = loop.run_until_complete(engine.get_session_detail(UUID(session_id)))
    finally:
        loop.close()

    if detail is None:
        return json.dumps({"error": "Session not found"})

    data = detail.model_dump(mode="json")

    mem = _get_memory()
    my_agent_id = mem.agent_id or "unknown"
    rounds = data.get("rounds") or []
    other_proposals = [
        r for r in rounds
        if r.get("agent_id") != my_agent_id and r.get("action") in ("propose", "counter")
    ]
    if other_proposals and data.get("status") in ("open", "in_progress"):
        last = other_proposals[-1]
        data["hint"] = (
            f"There is a pending proposal from {last.get('agent_id', 'another agent')}. "
            "Review it and discuss with your user before accepting or rejecting. "
            "You may counter-propose freely, but acceptance/rejection requires user approval."
        )

    return json.dumps(data, default=str)


@mcp.tool
def amfs_negotiate_cancel(
    session_id: str,
    reason: str | None = None,
) -> str:
    """Cancel an open or in-progress negotiation session.

    The discussion history is preserved, but a cancellation notice is
    written to memory so all agents know the proposals discussed should
    NOT be treated as agreed decisions.

    Args:
        session_id: UUID of the negotiation session to cancel
        reason: Optional explanation for why the negotiation is being cancelled
    """
    gate = _require_tier(*_ROOMS_TIERS)
    if gate:
        return gate
    engine = _get_negotiation_engine()
    mem = _get_memory()
    agent_id = mem.agent_id or "unknown"

    if engine is None:
        room_id = _resolve_room_id_for_session(session_id)
        if not room_id:
            return json.dumps({"error": f"Cannot find room_id for session {session_id}."})
        result = _negotiate_via_http("POST", f"{room_id}/negotiations/{session_id}/cancel", {
            "agent_id": agent_id,
            "reason": reason,
        })
        if "error" in result:
            return json.dumps(result)
        return json.dumps({
            **result,
            "hint": "Negotiation cancelled. A cancellation notice has been written to memory.",
        }, default=str)

    account_id = _get_account_id_from_context()
    if not account_id:
        return json.dumps({"error": "Could not resolve account"})

    import asyncio
    from uuid import UUID

    loop = asyncio.new_event_loop()
    try:
        result = loop.run_until_complete(
            engine.cancel_session(
                UUID(session_id), agent_id,
                reason=reason, account_id=UUID(account_id),
            )
        )
    except ValueError as e:
        return json.dumps({"error": str(e)})
    finally:
        loop.close()

    try:
        svc = _get_room_service()
        if svc:
            session = asyncio.new_event_loop().run_until_complete(
                engine._protocol.get_session(UUID(session_id))
            )
            if session:
                room_id = session.get("room_id")
                if room_id:
                    svc.log_activity(
                        room_id=UUID(str(room_id)),
                        account_id=UUID(account_id),
                        activity_type="negotiation_cancelled",
                        agent_id=agent_id,
                        details={"session_id": session_id, "reason": reason},
                    )
    except Exception:
        logger.debug("Failed to log cancel activity", exc_info=True)

    try:
        svc = _get_room_service()
        pool = getattr(_get_memory()._adapter, "_pool", None)
        if svc and pool:
            session_data = result or {}
            room_id_str = session_data.get("room_id")
            title = session_data.get("title") or session_id
            if room_id_str:
                from amfs_rooms.notifications import notify_room_members
                notify_room_members(
                    pool, svc, UUID(room_id_str), UUID(account_id),
                    exclude_user_id=None,
                    notification_type="negotiation_cancelled",
                    title=f"Negotiation '{title}' cancelled",
                    body=f"Cancelled by {agent_id}" + (f": {reason}" if reason else ""),
                    metadata={"session_id": session_id, "outcome": "cancelled"},
                )
    except Exception:
        logger.debug("Failed to notify cancel from MCP", exc_info=True)

    return json.dumps({
        **result,
        "hint": (
            "Negotiation cancelled. A cancellation notice has been written to memory "
            "so all agents know the discussed proposals are void."
        ),
    }, default=str)


# ──────────────────────────────────────────────────────────────────────
# Visibility-filtered overrides of core OSS tools
# ──────────────────────────────────────────────────────────────────────

_oss_amfs_list = _oss_server.amfs_list
_oss_amfs_search = _oss_server.amfs_search
_oss_amfs_read = _oss_server.amfs_read
_oss_amfs_read_from = _oss_server.amfs_read_from
_oss_amfs_retrieve = _oss_server.amfs_retrieve


@mcp.tool
def amfs_list(entity_path: str | None = None) -> str:
    """List all current memory entries, optionally filtered to an entity path.

    Use to explore what knowledge exists for a given service or module.

    Args:
        entity_path: Optional entity path to filter (e.g. "checkout-service")

    Example: amfs_list("checkout-service")
    """
    result_str = _oss_amfs_list(entity_path)
    vis = _fetch_visibility()
    if vis is None:
        return result_str
    try:
        data = json.loads(result_str)
        if "entries" not in data:
            return result_str
        data["entries"] = _filter_entries_visible(data["entries"])
        data["count"] = len(data["entries"])
        return json.dumps(data, default=str)
    except Exception:
        return result_str


@mcp.tool
def amfs_search(
    query: str | None = None,
    entity_path: str | None = None,
    min_confidence: float = 0.0,
    max_confidence: float | None = None,
    agent_id: str | None = None,
    since: str | None = None,
    pattern_ref: str | None = None,
    sort_by: str = "confidence",
    limit: int = 20,
    depth: int = 3,
) -> str:
    """Search across all memory entries with filters.

    Use this before starting work to find context about the entity you're
    modifying, or to check if another agent already solved a similar problem.

    Args:
        query: Optional text to search for
        entity_path: Filter to a specific entity path
        min_confidence: Minimum confidence threshold (0.0-1.0)
        max_confidence: Maximum confidence threshold (0.0-1.0)
        agent_id: Filter to entries from a specific agent
        since: Optional ISO timestamp to filter entries written after this time
        pattern_ref: Filter to entries tagged with this pattern reference
        sort_by: Sort order — "confidence", "recency", or "version"
        limit: Maximum results to return
        depth: Tier depth (1=hot only, 2=hot+warm, 3=all tiers)
    """
    result_str = _oss_amfs_search(
        query=query, entity_path=entity_path, min_confidence=min_confidence,
        max_confidence=max_confidence, agent_id=agent_id, since=since,
        pattern_ref=pattern_ref, sort_by=sort_by, limit=limit, depth=depth,
    )
    vis = _fetch_visibility()
    if vis is None:
        return result_str
    try:
        data = json.loads(result_str)
        if "entries" not in data:
            return result_str
        data["entries"] = _filter_entries_visible(data["entries"])
        data["count"] = len(data["entries"])
        return json.dumps(data, default=str)
    except Exception:
        return result_str


@mcp.tool
def amfs_read(entity_path: str, key: str) -> str:
    """Read a memory entry by entity path and key.

    Returns the full entry as JSON including value, confidence, provenance,
    and version. Returns a message if the entry does not exist.

    Example: amfs_read("checkout-service", "retry-pattern")
    """
    result_str = _oss_amfs_read(entity_path, key)
    vis = _fetch_visibility()
    if vis is None:
        return result_str
    try:
        data = json.loads(result_str)
        if data.get("status") == "not_found":
            return result_str
        if not _is_entry_visible(data):
            return json.dumps({"status": "not_found", "entity_path": entity_path, "key": key})
        return result_str
    except Exception:
        return result_str


@mcp.tool
def amfs_read_from(agent_id: str, entity_path: str, key: str) -> str:
    """Read a specific key from ANOTHER agent's memory.

    Use this when you want to explicitly learn from another agent's
    experience. The read is tracked for causal tracing.

    Args:
        agent_id: The agent whose memory to read from
        entity_path: Entity path (e.g. "checkout-service")
        key: Memory key (e.g. "retry-pattern")
    """
    vis = _fetch_visibility()
    if vis is not None:
        my_agents = set(vis.get("my_agent_ids", []))
        shared = vis.get("shared_entity_paths", {})
        agent_visible = agent_id in my_agents
        if not agent_visible:
            for ep, members in shared.items():
                if agent_id in (members or []):
                    agent_visible = True
                    break
        if not agent_visible:
            return json.dumps({"status": "not_found", "agent_id": agent_id,
                               "entity_path": entity_path, "key": key})
    return _oss_amfs_read_from(agent_id, entity_path, key)


@mcp.tool
def amfs_retrieve(
    query: str,
    entity_path: str | None = None,
    min_confidence: float = 0.0,
    limit: int = 10,
    semantic_weight: float = 0.5,
    recency_weight: float = 0.3,
    confidence_weight: float = 0.2,
    depth: int = 3,
) -> str:
    """Find the most relevant memories for a natural language query.

    Blends semantic similarity, recency, and confidence into a single
    ranked list.

    Args:
        query: Natural language query describing what you're looking for
        entity_path: Optional entity path filter
        min_confidence: Minimum confidence threshold (0.0-1.0)
        limit: Maximum results to return
        semantic_weight: Weight for semantic similarity (0.0-1.0)
        recency_weight: Weight for recency (0.0-1.0)
        confidence_weight: Weight for confidence (0.0-1.0)
        depth: Tier depth (1=hot only, 2=hot+warm, 3=all tiers)
    """
    result_str = _oss_amfs_retrieve(
        query=query, entity_path=entity_path, min_confidence=min_confidence,
        limit=limit, semantic_weight=semantic_weight, recency_weight=recency_weight,
        confidence_weight=confidence_weight, depth=depth,
    )
    vis = _fetch_visibility()
    if vis is None:
        return result_str
    try:
        data = json.loads(result_str)
        if "entries" not in data:
            return result_str
        data["entries"] = _filter_entries_visible(data["entries"])
        data["count"] = len(data["entries"])
        return json.dumps(data, default=str)
    except Exception:
        return result_str


# ──────────────────────────────────────────────────────────────────────
# MCP Resources: Room feeds (push via notifications/resources/updated)
# ──────────────────────────────────────────────────────────────────────

try:
    @mcp.resource("amfs://rooms")
    def room_list_resource() -> str:
        """List of rooms the current agent has access to.

        Subscribe to this resource to get notified when rooms change.
        """
        gate = _require_tier(*_ROOMS_TIERS)
        if gate:
            return gate
        svc = _get_room_service()
        if svc is None:
            return json.dumps({"rooms": [], "hint": "Rooms require Pro with Postgres"})

        account_id = _get_account_id_from_context()
        user_id = _get_user_id_from_context()
        if not account_id or not user_id:
            return json.dumps({"rooms": [], "error": "Could not resolve context"})

        from uuid import UUID
        rooms = svc.list_rooms(UUID(account_id), UUID(user_id))
        return json.dumps([{
            "id": str(r.get("id")),
            "entity_path": r.get("entity_path"),
            "status": r.get("status"),
            "agent_count": r.get("agent_count", 0),
            "discussions_enabled": r.get("discussions_enabled"),
        } for r in rooms], default=str)

    @mcp.resource("amfs://rooms/{room_id}/feed")
    def room_feed_resource(room_id: str) -> str:
        """Recent activity feed for a specific room.

        Returns the last 20 events. Subscribe to get push notifications
        when new activity occurs.
        """
        gate = _require_tier(*_ROOMS_TIERS)
        if gate:
            return gate
        svc = _get_room_service()
        if svc is None:
            return json.dumps({"events": [], "hint": "Rooms require Pro"})

        account_id = _get_account_id_from_context()
        if not account_id:
            return json.dumps({"events": [], "error": "No account context"})

        from uuid import UUID
        items, total = svc.list_activity(UUID(room_id), UUID(account_id), limit=20)
        return json.dumps({
            "events": [{
                "activity_type": i.get("activity_type"),
                "agent_id": i.get("agent_id"),
                "details": i.get("details", {}),
                "created_at": i.get("created_at"),
            } for i in items],
            "total": total,
        }, default=str)
except Exception:
    logger.debug("Could not register MCP resources (FastMCP version may not support them)", exc_info=True)


# ──────────────────────────────────────────────────────────────────────
# Entry point
# ──────────────────────────────────────────────────────────────────────


def main() -> None:
    """Run the AMFS Pro MCP server (extends the community server with Pro tools)."""
    from amfs_mcp.server import main as community_main
    community_main()


if __name__ == "__main__":
    main()
