# Framework M Studio

Visual DocType builder and developer tools for Framework M.

[![PyPI version](https://badge.fury.io/py/framework-m-studio.svg)](https://badge.fury.io/py/framework-m-studio)
[![Python 3.12+](https://img.shields.io/badge/python-3.12+-blue.svg)](https://www.python.org/downloads/)
[![License](https://img.shields.io/badge/License-Apache_2.0-blue.svg)](https://opensource.org/licenses/Apache-2.0)
[![GitLab Pipeline Status](https://gitlab.com/castlecraft/framework-m/badges/main/pipeline.svg)](https://gitlab.com/castlecraft/framework-m/-/pipelines)
[![Code style: ruff](https://img.shields.io/badge/code%20style-ruff-000000.svg)](https://github.com/astral-sh/ruff)

## Overview

`framework-m-studio` provides development-time tools that are NOT included in the production runtime:

- **Studio UI**: Visual DocType builder (React + Vite)
- **Code Generators**: LibCST-based Python code generation
- **DevTools CLI**: `m codegen`, `m docs:generate`, `m studio`

> **Note:** Studio is for developers to build DocTypes. The **Desk** (end-user data management UI) is a separate frontend that connects to the Framework M backend.

## Installation

```bash
# Add to your project's dev dependencies
uv add --dev framework-m-studio
```

## Documentation

Check out the official documentation for Studio at **[www.frameworkm.dev](https://www.frameworkm.dev)**

## Usage

```bash
# Start Studio UI
m studio

# Generate TypeScript client from OpenAPI
m codegen client --lang ts --out ./frontend/src/api
```

## Development

```bash
cd apps/studio
uv sync
uv run pytest
```

## License

Apache-2.0
