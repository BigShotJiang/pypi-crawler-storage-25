"""Tests for Aggregate Root controller generation."""

from __future__ import annotations

from framework_m_studio.codegen.generator import generate_controller_source


class TestAggregateControllerGenerator:
    """Tests for generating Domain Aggregate controllers."""

    def test_explicit_transaction_boundaries(self) -> None:
        """Aggregate roots must include explicit UoW transaction boundaries."""
        schema = {
            "name": "SalesOrder",
            "fields": [{"name": "items", "type": "list[SalesOrderItem]"}],
            "meta": {
                "is_aggregate_root": True,
                "aggregate_children": ["items"],
            },
        }

        code = generate_controller_source(schema)

        assert "class SalesOrderController(BaseController[SalesOrder]):" in code
        assert "async with self.uow_factory() as uow:" in code
        assert "await self.repo.save(uow.session, self.doc)" in code
        assert "await uow.commit()" in code

    def test_child_first_validation(self) -> None:
        """Aggregate roots must iterate and validate children before committing."""
        schema = {
            "name": "PurchaseOrder",
            "fields": [
                {"name": "items", "type": "list[PurchaseOrderItem]"},
                {"name": "taxes", "type": "list[PurchaseOrderTax]"},
            ],
            "meta": {
                "is_aggregate_root": True,
                "aggregate_children": ["items", "taxes"],
            },
        }

        code = generate_controller_source(schema)

        # Should loop over aggregate children and validate them
        assert "for child in self.doc.items:" in code
        assert "for child in self.doc.taxes:" in code
        assert "await child.validate(" in code or "child.validate(" in code

    def test_standard_controller_no_uow(self) -> None:
        """Standard DocTypes (non-aggregate) should not generate complex UoW logic."""
        schema = {
            "name": "Customer",
        }

        code = generate_controller_source(schema)
        assert "async with self.uow_factory() as uow:" not in code
