"""Tests for UIMeta integration.

TDD tests for get_ui_meta(), get_custom_meta_namespaces(),
and /api/meta response including ui_meta.
"""

from __future__ import annotations

from typing import Any, ClassVar

from framework_m_core.domain.base_doctype import BaseDocType


class TestGetUIMeta:
    """Tests for BaseDocType.get_ui_meta()."""

    def test_no_meta_class(self) -> None:
        """DocType without Meta must return empty dict."""

        class SimpleDoc(BaseDocType):
            title: str = ""

        assert SimpleDoc.get_ui_meta() == {}

    def test_meta_without_ui_meta(self) -> None:
        """Meta class without ui_meta must return empty dict."""

        class SimpleDoc(BaseDocType):
            title: str = ""

            class Meta:
                requires_auth = False

        assert SimpleDoc.get_ui_meta() == {}

    def test_meta_with_ui_meta(self) -> None:
        """Meta with ui_meta must return the dict."""

        class Invoice(BaseDocType):
            customer: str = ""
            status: str = "Draft"

            class Meta:
                ui_meta: ClassVar[dict[str, Any]] = {
                    "form": {"sections": [{"fields": ["customer", "status"]}]},
                    "list": {"columns": [{"field": "customer"}, {"field": "status"}]},
                    "additional_views": {
                        "kanban": {"group_field": "status"},
                    },
                }

        result = Invoice.get_ui_meta()
        assert "form" in result
        assert "list" in result
        assert "additional_views" in result
        assert result["additional_views"]["kanban"]["group_field"] == "status"


class TestGetCustomMetaNamespaces:
    """Tests for BaseDocType.get_custom_meta_namespaces()."""

    def test_no_meta_class(self) -> None:
        """DocType without Meta must return empty dict."""

        class SimpleDoc(BaseDocType):
            title: str = ""

        assert SimpleDoc.get_custom_meta_namespaces() == {}

    def test_no_custom_namespaces(self) -> None:
        """Meta without custom *_meta attrs must return empty dict."""

        class SimpleDoc(BaseDocType):
            title: str = ""

            class Meta:
                requires_auth = False
                layout: ClassVar[dict[str, Any]] = {"sections": []}

        assert SimpleDoc.get_custom_meta_namespaces() == {}

    def test_wms_meta_namespace(self) -> None:
        """Plugin-defined wms_meta must be discovered."""

        class PickList(BaseDocType):
            warehouse: str = ""

            class Meta:
                wms_meta: ClassVar[dict[str, Any]] = {
                    "scanner_mode": "barcode",
                    "auto_submit": True,
                }

        namespaces = PickList.get_custom_meta_namespaces()
        assert "wms_meta" in namespaces
        assert namespaces["wms_meta"]["scanner_mode"] == "barcode"

    def test_multiple_custom_namespaces(self) -> None:
        """Multiple custom namespaces must all be returned."""

        class PickList(BaseDocType):
            warehouse: str = ""

            class Meta:
                wms_meta: ClassVar[dict[str, Any]] = {"scanner_mode": "barcode"}
                mobile_meta: ClassVar[dict[str, Any]] = {"offline_capable": True}

        namespaces = PickList.get_custom_meta_namespaces()
        assert "wms_meta" in namespaces
        assert "mobile_meta" in namespaces

    def test_ui_meta_excluded(self) -> None:
        """ui_meta must NOT appear in custom namespaces."""

        class Invoice(BaseDocType):
            customer: str = ""

            class Meta:
                ui_meta: ClassVar[dict[str, Any]] = {"form": {"sections": []}}
                wms_meta: ClassVar[dict[str, Any]] = {"scanner": True}

        namespaces = Invoice.get_custom_meta_namespaces()
        assert "ui_meta" not in namespaces
        assert "wms_meta" in namespaces
