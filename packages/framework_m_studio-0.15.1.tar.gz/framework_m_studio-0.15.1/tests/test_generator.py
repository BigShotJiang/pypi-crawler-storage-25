"""Tests for DocType Code Generator module."""

from __future__ import annotations

from framework_m_studio.codegen.generator import (
    generate_doctype_source,
    generate_test_source,
)


class TestGenerateDocTypeSource:
    """Tests for generate_doctype_source function."""

    def test_generate_simple_doctype(self) -> None:
        """generate_doctype_source should create valid Python code."""
        code = generate_doctype_source(
            {
                "name": "Todo",
                "fields": [
                    {"name": "title", "type": "str", "required": True},
                ],
            }
        )

        assert "class Todo(BaseDocType):" in code
        assert "title: str" in code
        # Template uses framework_m_core.domain.base_doctype import
        assert "from framework_m_core.domain.base_doctype import BaseDocType" in code
        assert (
            "from framework_m.core.base import BaseDocType" in code
            or "from framework_m_core.domain.base_doctype import BaseDocType" in code
        )

    def test_generate_with_docstring(self) -> None:
        """generate_doctype_source should include docstring."""
        code = generate_doctype_source(
            {
                "name": "Invoice",
                "docstring": "An invoice document.",
                "fields": [{"name": "number", "type": "str", "required": True}],
            }
        )

        assert '"""An invoice document."""' in code

    def test_generate_with_defaults(self) -> None:
        """generate_doctype_source should handle default values."""
        code = generate_doctype_source(
            {
                "name": "Task",
                "fields": [
                    {"name": "title", "type": "str", "required": True},
                    {"name": "done", "type": "bool", "default": "False"},
                ],
            }
        )

        assert "title: str" in code
        assert "done: bool = False" in code

    def test_generate_optional_fields(self) -> None:
        """generate_doctype_source should handle optional fields."""
        code = generate_doctype_source(
            {
                "name": "User",
                "fields": [
                    {"name": "name", "type": "str", "required": True},
                    {"name": "bio", "type": "str", "required": False},
                ],
            }
        )

        assert "name: str" in code
        assert "bio: str | None = None" in code

    def test_generate_with_meta(self) -> None:
        """generate_doctype_source should include Meta class."""
        code = generate_doctype_source(
            {
                "name": "Order",
                "fields": [{"name": "number", "type": "str", "required": True}],
                "meta": {
                    "tablename": "orders",
                    "verbose_name": "Sales Order",
                    "is_submittable": True,
                },
            }
        )

        assert "class Meta:" in code
        assert 'tablename: ClassVar[str] = "orders"' in code
        assert 'verbose_name: ClassVar[str] = "Sales Order"' in code
        assert "is_submittable: ClassVar[bool] = True" in code

    def test_generate_with_link_field(self) -> None:
        """generate_doctype_source should handle Link fields."""
        code = generate_doctype_source(
            {
                "name": "PurchaseOrder",
                "docstring": "Purchase Order document",
                "fields": [
                    {
                        "name": "supplier",
                        "type": "Link",
                        "required": True,
                        "label": "Supplier",
                        "link_doctype": "Supplier",
                    },
                    {
                        "name": "amount",
                        "type": "float",
                        "required": True,
                    },
                ],
            }
        )

        assert "class PurchaseOrder(BaseDocType):" in code
        assert "from framework_m_core.domain.mixins import Link" in code
        assert 'Annotated[str, Link("Supplier")]' in code
        assert "supplier:" in code
        assert "amount: float" in code

    def test_generate_with_optional_link_field(self) -> None:
        """generate_doctype_source should handle optional Link fields."""
        code = generate_doctype_source(
            {
                "name": "Invoice",
                "fields": [
                    {
                        "name": "customer",
                        "type": "Link",
                        "required": True,
                        "link_doctype": "Customer",
                    },
                    {
                        "name": "reference",
                        "type": "Link",
                        "required": False,
                        "link_doctype": "Invoice",
                    },
                ],
            }
        )

        assert 'Annotated[str, Link("Customer")]' in code
        assert 'Annotated[str, Link("Invoice")]' in code
        assert "from typing import ClassVar, Annotated" in code


class TestGenerateTestSource:
    """Tests for generate_test_source function."""

    def test_generate_test_file(self) -> None:
        """generate_test_source should create valid test code."""
        code = generate_test_source(
            {
                "name": "Todo",
                "module": "myapp.doctypes.todo",
                "fields": [
                    {"name": "title", "type": "str", "required": True},
                ],
            }
        )

        assert "class TestTodo:" in code
        assert "def test_create_todo" in code
        assert "from myapp.doctypes.todo.doctype import Todo" in code
