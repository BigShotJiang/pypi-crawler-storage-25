"""Tests for Documentation Generator to increase coverage."""

from __future__ import annotations

from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from framework_m_studio.docs.generator import (
    generate_cli_reference,
    run_docs_generate,
)


def test_generate_cli_reference_extended(tmp_path: Path) -> None:
    # 1. Exception running CLI
    with patch(
        "framework_m_studio.core.shell.run_cmd", side_effect=Exception("mock err")
    ):
        doc = generate_cli_reference(tmp_path)
        assert "*Error running CLI" in doc

    # 2. Valid parsing
    fake_help = """
Some header
│ command1   │ Description 1 │
│ cmd2       │ Desc 2        │
│ default    │ Default desc  │
│ -other     │ Other         │
│ no_desc    │               │
│ joined desc│               │
"""

    def mock_run_cmd(*args, **kwargs):
        cmd = args[0]
        if "--help" in cmd and len(cmd) == 4:  # m --help
            return fake_help
        # Help for specific command
        return "detailed help"

    with patch("framework_m_studio.core.shell.run_cmd", side_effect=mock_run_cmd):
        doc2 = generate_cli_reference(tmp_path)
        assert "| `m command1` | Description 1 |" in doc2
        assert "| `m cmd2` | Desc 2 |" in doc2
        assert "default" not in doc2
        assert "-other" not in doc2


def test_run_docs_generate_extended(tmp_path: Path) -> None:
    # Mock scanning
    dt_mock = MagicMock()
    with (
        patch("framework_m_studio.discovery.scan_doctypes", return_value=[dt_mock]),
        patch(
            "framework_m_studio.discovery.doctype_to_dict",
            return_value={"name": "TestDoc"},
        ),
        patch("framework_m_studio.docs.generator.generate_api_reference"),
        patch("framework_m_studio.docs.generator.export_openapi_json") as mock_open_api,
    ):
        # 1. Without openapi_url
        run_docs_generate(output=str(tmp_path / "docs"), project_root=tmp_path)

        # 2. With openapi_url success
        run_docs_generate(
            output=str(tmp_path / "docs"),
            project_root=tmp_path,
            openapi_url="http://test",
        )
        mock_open_api.assert_called_once()

        # 3. With openapi_url exception
        mock_open_api.side_effect = Exception("failed export")
        run_docs_generate(
            output=str(tmp_path / "docs"),
            project_root=tmp_path,
            openapi_url="http://test",
        )


def test_docs_adr_create_with_existing_and_no_template(tmp_path: Path) -> None:
    """Should parse existing ADR numbers and use fallback template string when file missing."""
    from framework_m_studio.cli.docs import docs_adr

    adr_dir = tmp_path / "adr"
    adr_dir.mkdir()
    (adr_dir / "0005-existing.md").write_text("old")
    (adr_dir / "not-an-adr.txt").write_text("ignore")

    # Call with a nonexistent template to trigger the fallback string
    docs_adr(
        action="create",
        title="Fallback ADR",
        adr_dir=adr_dir,
        template=tmp_path / "nonexistent.md",
    )

    new_file = adr_dir / "0006-fallback-adr.md"
    assert new_file.exists()
    content = new_file.read_text()
    assert "# ADR-0006: Fallback ADR" in content
    assert "## Context" in content


def test_docs_rfc_create_empty_title(capsys: pytest.CaptureFixture[str]) -> None:
    """Should error out when title is not provided for RFC creation."""
    from framework_m_studio.cli.docs import docs_rfc

    docs_rfc(action="create", title=None)
    assert "Title required" in capsys.readouterr().err


def test_docs_rfc_create_existing_and_template(tmp_path: Path) -> None:
    """Should increment RFC number and replace template tags."""
    from framework_m_studio.cli.docs import docs_rfc

    rfc_dir = tmp_path / "rfc"
    rfc_dir.mkdir()
    (rfc_dir / "0010-old.md").write_text("old")
    (rfc_dir / "ignore.md").write_text("ignore")

    template = tmp_path / "template.md"
    template.write_text("RFC-0000 [Short Title] YYYY-MM-DD")

    docs_rfc(action="create", title="New RFC", rfc_dir=rfc_dir, template=template)

    new_file = rfc_dir / "0011-new-rfc.md"
    assert new_file.exists()
    content = new_file.read_text()
    assert "RFC-0011" in content
    assert "New RFC" in content


def test_docs_rfc_unknown_action(capsys: pytest.CaptureFixture[str]) -> None:
    """Should print an error message for unknown RFC actions."""
    from framework_m_studio.cli.docs import docs_rfc

    docs_rfc(action="magic")
    assert "Unknown action" in capsys.readouterr().err


def test_generate_adr_index_missing_dir(
    capsys: pytest.CaptureFixture[str], tmp_path: Path
) -> None:
    """Should skip generation and print error if directory is missing."""
    from framework_m_studio.cli.docs import _generate_adr_index

    _generate_adr_index(tmp_path / "missing_dir", "ADR")
    assert "Directory not found" in capsys.readouterr().err


def test_generate_adr_index_skip_files(tmp_path: Path) -> None:
    """Should correctly skip index.md and _category_.json during compilation."""
    from framework_m_studio.cli.docs import _generate_adr_index

    adr_dir = tmp_path / "adr"
    adr_dir.mkdir()
    (adr_dir / "0001-test.md").write_text("# ADR-0001: Test\n\n**Status**: Proposed")
    (adr_dir / "index.md").write_text("ignore")
    (adr_dir / "_category_.json").write_text("ignore")

    _generate_adr_index(adr_dir, "ADR")

    index_content = (adr_dir / "index.md").read_text()
    assert "0001-test.md" in index_content


def test_docs_generate_adr_rfc_dir_exists(tmp_path: Path) -> None:
    """Hits the True branch for adr_dir.exists() and rfc_dir.exists() in docs_generate."""
    from framework_m_studio.cli.docs import docs_generate

    # Create directories so they exist when the CLI checks for them
    (tmp_path / "docs" / "adr").mkdir(parents=True)
    (tmp_path / "docs" / "rfcs").mkdir(parents=True)

    with (
        patch("framework_m_studio.cli.docs.Path.cwd", return_value=tmp_path),
        patch("framework_m_studio.cli.docs._generate_adr_index") as mock_gen,
    ):
        docs_generate(output=str(tmp_path / "out"), adr=True, rfc=True)
        assert mock_gen.call_count == 2


def test_adr_rfc_create_non_matching_md(tmp_path: Path) -> None:
    """Hits the False branch for `if match:` when parsing existing ADRs/RFCs."""
    from framework_m_studio.cli.docs import docs_adr, docs_rfc

    adr_dir = tmp_path / "adr"
    adr_dir.mkdir()
    # Create a markdown file that does NOT start with a number
    (adr_dir / "draft-notes.md").write_text("some notes")

    docs_adr(action="create", title="Test ADR", adr_dir=adr_dir)

    rfc_dir = tmp_path / "rfc"
    rfc_dir.mkdir()
    (rfc_dir / "draft-notes.md").write_text("some notes")

    docs_rfc(action="create", title="Test RFC", rfc_dir=rfc_dir)


def test_generate_adr_index_non_matching_md(tmp_path: Path) -> None:
    """Hits the False branch for `if match:` when generating the index markdown."""
    from framework_m_studio.cli.docs import _generate_adr_index

    adr_dir = tmp_path / "adr"
    adr_dir.mkdir()
    (adr_dir / "draft-notes.md").write_text("some notes")
    (adr_dir / "0001-test.md").write_text("# ADR-0001: Test\n\n**Status**: Proposed")

    _generate_adr_index(adr_dir, "ADR")

    content = (adr_dir / "index.md").read_text()
    assert "0001-test.md" in content
    assert "draft-notes.md" not in content


def test_docs_openapi_success_json(tmp_path: Path) -> None:
    """Tests the success path for exporting OpenAPI JSON."""
    from framework_m_studio.cli.docs import docs_openapi

    mock_resp = MagicMock()
    mock_resp.json.return_value = {"openapi": "3.0.0"}
    mock_resp.raise_for_status = MagicMock()

    with patch("framework_m_studio.cli.docs.httpx.get", return_value=mock_resp):
        out_file = tmp_path / "openapi.json"
        docs_openapi(
            output=str(out_file), openapi_url="http://test/openapi.json", markdown=False
        )
        assert "openapi" in out_file.read_text()

        # Now test the markdown export branch
        with patch(
            "framework_m_studio.cli.docs.generate_openapi_markdown",
            return_value="# OpenAPI",
        ):
            out_md = tmp_path / "openapi.md"
            docs_openapi(
                output=str(out_md),
                openapi_url="http://test/openapi.json",
                markdown=True,
            )
            assert "# OpenAPI" in out_md.read_text()
