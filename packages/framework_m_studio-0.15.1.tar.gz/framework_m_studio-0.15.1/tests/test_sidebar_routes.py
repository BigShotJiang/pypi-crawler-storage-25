"""Tests for Sidebar Config and View Config APIs.

TDD tests for sidebar section registry (DocType→section mapping,
ordering) and view configurator (field→view slot mapping).
"""

from __future__ import annotations

from pathlib import Path

from framework_m_studio.sidebar_config import SidebarConfig, ViewConfig


class TestSidebarConfig:
    """Tests for the SidebarConfig registry."""

    def test_empty_config(self) -> None:
        """Fresh SidebarConfig must have no sections."""
        config = SidebarConfig()
        assert config.get_sections() == {}

    def test_register_doctype_to_section(self) -> None:
        """register() must assign a DocType to a sidebar section."""
        config = SidebarConfig()
        config.register("Invoice", "Accounting")

        sections = config.get_sections()
        assert "Accounting" in sections
        assert "Invoice" in sections["Accounting"]

    def test_register_multiple_doctypes(self) -> None:
        """Multiple DocTypes can be registered to the same section."""
        config = SidebarConfig()
        config.register("Invoice", "Accounting")
        config.register("Payment", "Accounting")

        assert len(config.get_sections()["Accounting"]) == 2

    def test_register_to_different_sections(self) -> None:
        """DocTypes can be in different sections."""
        config = SidebarConfig()
        config.register("Invoice", "Accounting")
        config.register("Customer", "CRM")

        sections = config.get_sections()
        assert "Accounting" in sections
        assert "CRM" in sections

    def test_reorder_section(self) -> None:
        """reorder() must update the order of DocTypes in a section."""
        config = SidebarConfig()
        config.register("Invoice", "Accounting")
        config.register("Payment", "Accounting")
        config.register("Receipt", "Accounting")

        config.reorder("Accounting", ["Receipt", "Invoice", "Payment"])

        assert config.get_sections()["Accounting"] == ["Receipt", "Invoice", "Payment"]

    def test_remove_doctype(self) -> None:
        """remove() must remove a DocType from its section."""
        config = SidebarConfig()
        config.register("Invoice", "Accounting")
        config.register("Payment", "Accounting")

        config.remove("Invoice")

        sections = config.get_sections()
        assert "Invoice" not in sections["Accounting"]
        assert "Payment" in sections["Accounting"]

    def test_save_and_load_json(self, tmp_path: Path) -> None:
        """SidebarConfig must round-trip through JSON."""
        config = SidebarConfig()
        config.register("Invoice", "Accounting")
        config.register("Customer", "CRM")

        path = tmp_path / "sidebar.json"
        config.save(path)

        loaded = SidebarConfig.load(path)
        assert loaded.get_sections() == config.get_sections()

    def test_to_dict(self) -> None:
        """to_dict() must return serializable dict."""
        config = SidebarConfig()
        config.register("Invoice", "Accounting")

        d = config.to_dict()
        assert isinstance(d, dict)
        assert "sections" in d


class TestViewConfig:
    """Tests for the ViewConfig (field → view slot mapping)."""

    def test_empty_config(self) -> None:
        """Fresh ViewConfig must have no mappings."""
        config = ViewConfig()
        assert config.get_mappings("Invoice") == {}

    def test_map_field_to_kanban(self) -> None:
        """map_field() must create a field→view mapping."""
        config = ViewConfig()
        config.map_field("Invoice", "status", "kanban_columns")

        mappings = config.get_mappings("Invoice")
        assert mappings["kanban_columns"] == "status"

    def test_map_multiple_fields(self) -> None:
        """Multiple fields can be mapped for a single DocType."""
        config = ViewConfig()
        config.map_field("Invoice", "status", "kanban_columns")
        config.map_field("Invoice", "due_date", "calendar_start")
        config.map_field("Invoice", "parent_id", "tree_parent")

        mappings = config.get_mappings("Invoice")
        assert mappings["kanban_columns"] == "status"
        assert mappings["calendar_start"] == "due_date"
        assert mappings["tree_parent"] == "parent_id"

    def test_different_doctypes(self) -> None:
        """Mappings must be per-DocType."""
        config = ViewConfig()
        config.map_field("Invoice", "status", "kanban_columns")
        config.map_field("Task", "priority", "kanban_columns")

        assert config.get_mappings("Invoice")["kanban_columns"] == "status"
        assert config.get_mappings("Task")["kanban_columns"] == "priority"

    def test_save_and_load_json(self, tmp_path: Path) -> None:
        """ViewConfig must round-trip through JSON."""
        config = ViewConfig()
        config.map_field("Invoice", "status", "kanban_columns")
        config.map_field("Invoice", "due_date", "calendar_start")

        path = tmp_path / "views.json"
        config.save(path)

        loaded = ViewConfig.load(path)
        assert loaded.get_mappings("Invoice") == config.get_mappings("Invoice")

    def test_to_dict(self) -> None:
        """to_dict() must return serializable dict."""
        config = ViewConfig()
        config.map_field("Invoice", "status", "kanban_columns")

        d = config.to_dict()
        assert isinstance(d, dict)
        assert "doctypes" in d
