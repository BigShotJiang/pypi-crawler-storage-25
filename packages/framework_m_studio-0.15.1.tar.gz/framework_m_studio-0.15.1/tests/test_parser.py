"""Tests for DocType Parser module."""

from __future__ import annotations

from pathlib import Path
from textwrap import dedent

import pytest

from framework_m_studio.codegen.parser import (
    FieldSchema,
    MetaSchema,
    parse_doctype,
)


class TestParseDoctype:
    """Tests for parse_doctype function."""

    def test_parse_simple_doctype(self, tmp_path: Path) -> None:
        """parse_doctype should extract basic DocType info."""
        code = dedent(
            '''
            """Todo module."""

            from framework_m.core.base import BaseDocType


            class Todo(BaseDocType):
                """A simple todo item."""

                title: str
                completed: bool = False
        '''
        )

        file_path = tmp_path / "todo.py"
        file_path.write_text(code)

        schema = parse_doctype(file_path)

        assert schema["name"] == "Todo"
        assert schema["docstring"] == "A simple todo item."
        assert len(schema["fields"]) == 2
        assert schema["bases"] == ["BaseDocType"]

    def test_parse_fields_with_types(self, tmp_path: Path) -> None:
        """parse_doctype should extract field types and defaults."""
        code = dedent(
            '''
            from framework_m.core.base import BaseDocType
            from typing import Optional
            from datetime import datetime


            class Invoice(BaseDocType):
                """Invoice document."""

                invoice_number: str
                amount: float
                due_date: datetime
                paid: bool = False
                notes: str | None = None
        '''
        )

        file_path = tmp_path / "invoice.py"
        file_path.write_text(code)

        schema = parse_doctype(file_path)

        assert schema["name"] == "Invoice"
        assert len(schema["fields"]) == 5

        # Check field properties
        fields_by_name = {f["name"]: f for f in schema["fields"]}

        assert fields_by_name["invoice_number"]["type"] == "str"
        assert fields_by_name["invoice_number"]["required"] is True

        assert fields_by_name["amount"]["type"] == "float"

        assert fields_by_name["paid"]["default"] == "False"
        assert fields_by_name["paid"]["required"] is False

        assert fields_by_name["notes"]["required"] is False

    def test_parse_meta_class(self, tmp_path: Path) -> None:
        """parse_doctype should extract Meta class metadata."""
        code = dedent(
            '''
            from framework_m.core.base import BaseDocType


            class Order(BaseDocType):
                """Order document."""

                order_id: str

                class Meta:
                    tablename = "orders"
                    verbose_name = "Sales Order"
                    is_submittable = True
        '''
        )

        file_path = tmp_path / "order.py"
        file_path.write_text(code)

        schema = parse_doctype(file_path)

        assert schema["name"] == "Order"
        assert schema["meta"]["tablename"] == "orders"
        assert schema["meta"]["verbose_name"] == "Sales Order"
        assert schema["meta"]["is_submittable"] is True

    def test_parse_custom_methods(self, tmp_path: Path) -> None:
        """parse_doctype should list custom methods."""
        code = dedent(
            '''
            from framework_m.core.base import BaseDocType


            class Item(BaseDocType):
                """Item with custom methods."""

                name: str
                price: float

                def calculate_tax(self) -> float:
                    return self.price * 0.1

                def apply_discount(self, percent: float) -> None:
                    self.price *= (1 - percent / 100)
        '''
        )

        file_path = tmp_path / "item.py"
        file_path.write_text(code)

        schema = parse_doctype(file_path)

        assert "calculate_tax" in schema["custom_methods"]
        assert "apply_discount" in schema["custom_methods"]

    def test_parse_imports(self, tmp_path: Path) -> None:
        """parse_doctype should collect import statements."""
        code = dedent(
            """
            from __future__ import annotations

            from typing import Optional
            from datetime import datetime

            from framework_m.core.base import BaseDocType


            class Task(BaseDocType):
                title: str
        """
        )

        file_path = tmp_path / "task.py"
        file_path.write_text(code)

        schema = parse_doctype(file_path)

        assert len(schema["imports"]) >= 3
        assert any("datetime" in imp for imp in schema["imports"])

    def test_parse_file_not_found(self) -> None:
        """parse_doctype should raise FileNotFoundError."""
        with pytest.raises(FileNotFoundError):
            parse_doctype("/nonexistent/file.py")

    def test_parse_no_doctype(self, tmp_path: Path) -> None:
        """parse_doctype should raise ValueError if no DocType."""
        code = dedent(
            """
            def helper():
                pass
        """
        )

        file_path = tmp_path / "utils.py"
        file_path.write_text(code)

        with pytest.raises(ValueError, match="No DocType"):
            parse_doctype(file_path)

    def test_parse_non_name_target(self, tmp_path: Path) -> None:
        """parse_doctype should skip AnnAssign if target is not Name."""
        code = dedent(
            """
            from framework_m.core.base import BaseDocType
            class Todo(BaseDocType):
                obj.field: str = "test"
            """
        )
        file_path = tmp_path / "todo_noname.py"
        file_path.write_text(code)
        schema = parse_doctype(file_path)
        assert len(schema["fields"]) == 0

    def test_parse_field_call_in_annotated_with_default(self, tmp_path: Path) -> None:
        """parse_doctype should extract Field info from inside Annotated."""
        code = dedent(
            """
            from typing import Annotated
            from pydantic import Field
            from framework_m.core.base import BaseDocType
            class Todo(BaseDocType):
                title: Annotated[str, Field(default="My Todo")]
            """
        )
        file_path = tmp_path / "todo_annot_field.py"
        file_path.write_text(code)
        schema = parse_doctype(file_path)
        assert schema["fields"][0]["default"] == '"My Todo"'
        assert schema["fields"][0]["required"] is False

    def test_parse_field_call_in_annotated_required(self, tmp_path: Path) -> None:
        """parse_doctype should extract Field(...) info from inside Annotated."""
        code = dedent(
            """
            from typing import Annotated
            from pydantic import Field
            from framework_m.core.base import BaseDocType
            class Todo(BaseDocType):
                title: Annotated[str, Field(...)]
            """
        )
        file_path = tmp_path / "todo_annot_field_req.py"
        file_path.write_text(code)
        schema = parse_doctype(file_path)
        assert schema["fields"][0]["default"] is None
        assert schema["fields"][0]["required"] is True

    def test_parse_non_field_call_default(self, tmp_path: Path) -> None:
        """parse_doctype should extract default value from non-Field calls."""
        code = dedent(
            """
            from framework_m.core.base import BaseDocType
            def my_func(): return 1
            class Todo(BaseDocType):
                count: int = my_func()
            """
        )
        file_path = tmp_path / "todo_func_default.py"
        file_path.write_text(code)
        schema = parse_doctype(file_path)
        assert schema["fields"][0]["default"] == "my_func()"

    def test_parse_table_doctype(self, tmp_path: Path) -> None:
        """parse_doctype should extract Table field metadata."""
        code = dedent(
            """
            from typing import Annotated
            from framework_m_core.domain.mixins import Table
            from framework_m.core.base import BaseDocType
            class Todo(BaseDocType):
                items: Annotated[list, Table("Item")]
            """
        )
        file_path = tmp_path / "todo_table.py"
        file_path.write_text(code)
        schema = parse_doctype(file_path)
        assert schema["fields"][0]["type"] == "Table"
        assert schema["fields"][0]["table_doctype"] == "Item"

    def test_parse_meta_class_non_name_target(self, tmp_path: Path) -> None:
        """parse_doctype should skip non-name targets in Meta class."""
        code = dedent(
            """
            from framework_m.core.base import BaseDocType
            class Todo(BaseDocType):
                class Meta:
                    obj.tablename = "todos"
            """
        )
        file_path = tmp_path / "todo_meta.py"
        file_path.write_text(code)
        schema = parse_doctype(file_path)
        assert schema["meta"]["tablename"] is None

    def test_parse_custom_methods_skip_private(self, tmp_path: Path) -> None:
        """parse_doctype should skip private methods."""
        code = dedent(
            """
            from framework_m.core.base import BaseDocType
            class Item(BaseDocType):
                name: str
                def _private_method(self) -> None:
                    pass
                def public_method(self) -> None:
                    pass
            """
        )
        file_path = tmp_path / "item_methods.py"
        file_path.write_text(code)
        schema = parse_doctype(file_path)
        assert "public_method" in schema["custom_methods"]
        assert "_private_method" not in schema["custom_methods"]

    def test_extract_docstring_variations(self) -> None:
        """DocTypeParserVisitor should handle various docstring formats."""
        import libcst as cst

        from framework_m_studio.codegen.parser import DocTypeParserVisitor

        code = dedent(
            """
            class DocNoBody(BaseDocType): pass

            class DocNoExpr(BaseDocType):
                x = 1

            class DocSingleQuote(BaseDocType):
                'Single quote doc'
                pass

            class DocDoubleQuote(BaseDocType):
                "Double quote doc"
                pass

            class DocConcat(BaseDocType):
                "Concat " \\
                "doc"
                pass

            class DocOtherExpr(BaseDocType):
                1 + 1
                pass
            """
        )
        tree = cst.parse_module(code)
        visitor = DocTypeParserVisitor()
        tree.visit(visitor)

        docs = {d.name: d.docstring for d in visitor.doctypes}
        assert docs["DocNoBody"] is None
        assert docs["DocNoExpr"] is None
        assert docs["DocSingleQuote"] == "Single quote doc"
        assert docs["DocDoubleQuote"] == "Double quote doc"
        assert docs["DocConcat"] == "Concat doc"
        assert docs["DocOtherExpr"] is None


class TestFieldSchema:
    """Tests for FieldSchema dataclass."""

    def test_field_schema_defaults(self) -> None:
        """FieldSchema should have correct defaults."""
        field = FieldSchema(name="title", type="str")

        assert field.name == "title"
        assert field.type == "str"
        assert field.default is None
        assert field.required is True
        assert field.validators == {}


class TestMetaSchema:
    """Tests for MetaSchema dataclass."""

    def test_meta_schema_defaults(self) -> None:
        """MetaSchema should have correct defaults."""
        meta = MetaSchema()

        assert meta.tablename is None
        assert meta.is_submittable is False
        assert meta.track_changes is True


class TestPermissionParsing:
    """Tests for parsing Meta.permissions from DocTypes."""

    def test_parse_permissions_dict(self, tmp_path: Path) -> None:
        """parse_doctype should extract permissions from Meta class."""
        code = dedent(
            '''
            from framework_m.core.base import BaseDocType
            from typing import ClassVar


            class Report(BaseDocType):
                """Report document."""

                title: str

                class Meta:
                    permissions: ClassVar[dict[str, list[str]]] = {
                        "read": ["Employee", "Manager", "Admin"],
                        "write": ["Manager", "Admin"],
                        "create": ["Admin"],
                        "delete": ["Admin"],
                    }
        '''
        )

        file_path = tmp_path / "report.py"
        file_path.write_text(code)

        schema = parse_doctype(file_path)

        assert "permissions" in schema["meta"]
        permissions = schema["meta"]["permissions"]
        assert permissions["read"] == ["Employee", "Manager", "Admin"]
        assert permissions["write"] == ["Manager", "Admin"]
        assert permissions["create"] == ["Admin"]
        assert permissions["delete"] == ["Admin"]

    def test_parse_permissions_no_type_annotation(self, tmp_path: Path) -> None:
        """parse_doctype should handle permissions without ClassVar annotation."""
        code = dedent(
            '''
            from framework_m.core.base import BaseDocType


            class Todo(BaseDocType):
                """Todo item."""

                title: str

                class Meta:
                    permissions = {
                        "read": ["Employee"],
                        "write": ["Manager"],
                    }
        '''
        )

        file_path = tmp_path / "todo.py"
        file_path.write_text(code)

        schema = parse_doctype(file_path)

        assert "permissions" in schema["meta"]
        permissions = schema["meta"]["permissions"]
        assert permissions["read"] == ["Employee"]
        assert permissions["write"] == ["Manager"]

    def test_parse_permissions_missing(self, tmp_path: Path) -> None:
        """parse_doctype should return None when permissions not defined."""
        code = dedent(
            '''
            from framework_m.core.base import BaseDocType


            class Simple(BaseDocType):
                """Simple DocType without permissions."""

                name: str
        '''
        )

        file_path = tmp_path / "simple.py"
        file_path.write_text(code)

        schema = parse_doctype(file_path)

        # permissions should be None or not present
        assert schema["meta"].get("permissions") is None


class TestLinkFieldParsing:
    """Tests for parsing Link fields from DocTypes."""

    def test_parse_link_field_annotated(self, tmp_path: Path) -> None:
        """parse_doctype should extract Link field metadata from Annotated syntax."""
        code = dedent(
            '''
            from __future__ import annotations

            from typing import Annotated
            from pydantic import Field
            from framework_m.core.base import BaseDocType
            from framework_m_core.domain.mixins import Link


            class PurchaseOrder(BaseDocType):
                """Purchase Order document."""

                supplier: Annotated[str, Link("Supplier")] = Field(..., label="Supplier")
                amount: float
        '''
        )

        file_path = tmp_path / "purchase_order.py"
        file_path.write_text(code)

        schema = parse_doctype(file_path)

        assert schema["name"] == "PurchaseOrder"
        assert len(schema["fields"]) == 2

        # Check Link field
        fields_by_name = {f["name"]: f for f in schema["fields"]}
        supplier_field = fields_by_name["supplier"]

        assert supplier_field["type"] == "Link"
        assert supplier_field["link_doctype"] == "Supplier"
        assert supplier_field["label"] == "Supplier"
        assert supplier_field["required"] is True

        # Check regular field
        amount_field = fields_by_name["amount"]
        assert amount_field["type"] == "float"
        assert amount_field["link_doctype"] is None

    def test_parse_link_field_optional(self, tmp_path: Path) -> None:
        """parse_doctype should handle optional Link fields."""
        code = dedent(
            '''
            from __future__ import annotations

            from typing import Annotated
            from pydantic import Field
            from framework_m.core.base import BaseDocType
            from framework_m_core.domain.mixins import Link


            class Invoice(BaseDocType):
                """Invoice document."""

                customer: Annotated[str, Link("Customer")] = Field(..., label="Customer")
                reference_invoice: Annotated[str, Link("Invoice")] | None = None
        '''
        )

        file_path = tmp_path / "invoice.py"
        file_path.write_text(code)

        schema = parse_doctype(file_path)

        fields_by_name = {f["name"]: f for f in schema["fields"]}

        # Required Link field
        customer_field = fields_by_name["customer"]
        assert customer_field["type"] == "Link"
        assert customer_field["link_doctype"] == "Customer"
        assert customer_field["required"] is True

        # Optional Link field
        ref_field = fields_by_name["reference_invoice"]
        assert ref_field["type"] == "Link"
        assert ref_field["link_doctype"] == "Invoice"
        assert ref_field["required"] is False

    def test_parse_table_field(self, tmp_path: Path) -> None:
        """parse_doctype should extract Table field metadata."""
        code = dedent(
            '''
            from __future__ import annotations

            from framework_m.core.base import BaseDocType


            class Order(BaseDocType):
                """Order document."""

                customer_name: str
                items: list[OrderItem]
        '''
        )

        file_path = tmp_path / "order.py"
        file_path.write_text(code)

        schema = parse_doctype(file_path)

        fields_by_name = {f["name"]: f for f in schema["fields"]}
        items_field = fields_by_name["items"]

        # Table fields are returned as-is for now
        # Future: detect list[DocType] pattern and set table_doctype
        assert items_field["type"] == "list[OrderItem]"
