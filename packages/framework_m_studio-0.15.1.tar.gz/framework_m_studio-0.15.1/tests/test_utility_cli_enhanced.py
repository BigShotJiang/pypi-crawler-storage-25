"""Enhanced Tests for CLI Utilities."""

from __future__ import annotations

import sys
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest
from litestar import Litestar

from framework_m_studio.cli.utility import (
    _detect_asgi_symbol,
    _find_app,
    check_ipython_installed,
    console_command,
    entrypoints_command,
    routes_command,
)


def test_check_ipython_installed() -> None:
    """Test IPython detection."""
    # Success case
    with patch.dict(sys.modules, {"IPython": MagicMock()}):
        assert check_ipython_installed() is True

    # Failure case
    with patch("builtins.__import__", side_effect=ImportError):
        assert check_ipython_installed() is False


def test_console_command_ipython() -> None:
    """Test console command starting IPython."""
    with (
        patch(
            "framework_m_studio.cli.utility.check_ipython_installed", return_value=True
        ),
        patch(
            "framework_m_studio.cli.utility.InteractiveShellEmbed"
        ) as mock_ipython_class,
        patch("framework_m_studio.cli.utility.install"),
    ):
        console_command()
        mock_ipython_class.assert_called_once()
        mock_ipython_class.return_value.assert_called_once()


def test_console_command_code() -> None:
    """Test console command falling back to code module."""
    with (
        patch(
            "framework_m_studio.cli.utility.check_ipython_installed", return_value=False
        ),
        patch("framework_m_studio.cli.utility.install"),
        patch("code.interact") as mock_interact,
    ):
        console_command()
        mock_interact.assert_called_once()


def test_detect_asgi_symbol(tmp_path: Path) -> None:
    """Test ASGI symbol detection in python files."""
    f = tmp_path / "app.py"
    f.write_text("from litestar import Litestar\napp = Litestar([])")

    assert _detect_asgi_symbol(f) == "app"

    f.write_text("from litestar import Litestar\ndef create_app(): return Litestar([])")
    assert _detect_asgi_symbol(f) == "create_app"

    f.write_text("x = 1")
    assert _detect_asgi_symbol(f) is None


def test_find_app(tmp_path: Path) -> None:
    """Test app finding logic."""
    with patch("pathlib.Path.cwd", return_value=tmp_path):
        # 1. Detected app.py
        app_file = tmp_path / "app.py"
        app_file.write_text("app = 1")
        assert _find_app() == "app:app"
        app_file.unlink()

        # 2. Detected main.py
        main_file = tmp_path / "main.py"
        main_file.write_text("app = 1")
        assert _find_app() == "main:app"
        main_file.unlink()

        # 3. Fallback
        assert _find_app() == "framework_m_standard.adapters.web.app:create_app"


def test_routes_command(capsys: pytest.CaptureFixture[str]) -> None:
    """Test routes command with mocked app."""
    # We create a mock that passes isinstance check and is not callable in a way that breaks discovery
    mock_app = MagicMock(spec=Litestar)
    mock_app.routes = []

    with (
        patch("framework_m_studio.cli.utility.importlib.import_module") as mock_import,
        patch("framework_m_studio.cli.utility._find_app", return_value="myapp:app"),
    ):
        mock_mod = MagicMock()
        mock_mod.app = mock_app
        mock_import.return_value = mock_mod

        # We need app_obj to NOT be a factory function for this test to work simply,
        # but MagicMock IS callable. So we make it return itself.
        mock_app.return_value = mock_app

        # We still need to patch isinstance because of how mocking/spec works across modules
        with patch("framework_m_studio.cli.utility.isinstance", return_value=True):
            routes_command(app_path="myapp:app")
            captured = capsys.readouterr()
            assert "Application Routes" in captured.out


def test_entrypoints_command(capsys: pytest.CaptureFixture[str]) -> None:
    """Test entrypoints command."""
    mock_ep = MagicMock()
    mock_ep.name = "test_ep"
    mock_ep.value = "test_value"

    mock_eps = MagicMock()
    mock_eps.select.return_value = [mock_ep]

    with patch("importlib.metadata.entry_points", return_value=mock_eps):
        entrypoints_command()
        captured = capsys.readouterr()
        assert "Discovered Framework M Entry Points" in captured.out
        assert "test_ep" in captured.out
