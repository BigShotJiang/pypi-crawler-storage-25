"""Tests for Contributor CLI."""

from __future__ import annotations

import json
import os
from pathlib import Path
from unittest.mock import patch

import pytest


class TestCLACheck:
    """Tests for cla-check command."""

    def test_cla_check_passes_for_icla_user(self, tmp_path: Path) -> None:
        """Should pass if user is listed in ICLA."""
        from framework_m_studio.cli.contrib import cla_check_command

        contrib_file = tmp_path / "contributors.json"
        contrib_file.write_text(json.dumps({"icla": ["alice", "bob"], "ccla": {}}))

        cla_check_command(user="alice", contributors_file=str(contrib_file))

    def test_cla_check_passes_for_ccla_org_member(self, tmp_path: Path) -> None:
        """Should pass if user is a member of an org listed in CCLA."""
        from framework_m_studio.cli.contrib import cla_check_command

        contrib_file = tmp_path / "contributors.json"
        contrib_file.write_text(
            json.dumps({"icla": [], "ccla": {"acme-corp": ["charlie", "david"]}})
        )

        cla_check_command(user="charlie", contributors_file=str(contrib_file))

    def test_cla_check_fails_for_unlisted_user(self, tmp_path: Path) -> None:
        """Should raise SystemExit if user is not found."""
        from framework_m_studio.cli.contrib import cla_check_command

        contrib_file = tmp_path / "contributors.json"
        contrib_file.write_text(json.dumps({"icla": ["alice"], "ccla": {}}))

        with pytest.raises(SystemExit) as exc:
            cla_check_command(user="eve", contributors_file=str(contrib_file))

        assert exc.value.code == 1

    def test_cla_check_skips_when_no_user_provided(self, tmp_path: Path) -> None:
        """Should gracefully skip if no user is provided and no env var."""
        from framework_m_studio.cli.contrib import cla_check_command

        contrib_file = tmp_path / "contributors.json"
        contrib_file.write_text(json.dumps({"icla": [], "ccla": {}}))

        with patch.dict(os.environ, clear=True):
            cla_check_command(user=None, contributors_file=str(contrib_file))

    def test_cla_check_missing_file(self, tmp_path: Path) -> None:
        """Should exit if contributors file is missing."""
        from framework_m_studio.cli.contrib import cla_check_command

        missing_file = tmp_path / "does_not_exist.json"

        with pytest.raises(SystemExit) as exc:
            cla_check_command(user="alice", contributors_file=str(missing_file))

        assert exc.value.code == 1

    def test_cla_check_invalid_json(self, tmp_path: Path) -> None:
        """Should exit if contributors file has invalid JSON."""
        from framework_m_studio.cli.contrib import cla_check_command

        invalid_file = tmp_path / "bad.json"
        invalid_file.write_text("{bad_json: true")

        with pytest.raises(SystemExit) as exc:
            cla_check_command(user="alice", contributors_file=str(invalid_file))

        assert exc.value.code == 1

    def test_cla_check_real_repo_format(self, tmp_path: Path) -> None:
        """Should pass if user is listed in the real repo format."""
        from framework_m_studio.cli.contrib import cla_check_command

        contrib_file = tmp_path / "contributors.json"
        contrib_file.write_text(json.dumps({"users": {"gitlab": ["real_user"]}}))

        # Should not raise
        cla_check_command(user="real_user", contributors_file=str(contrib_file))
