"""Coverage tests for dev CLI command."""

from __future__ import annotations

import os
from pathlib import Path
from unittest.mock import patch

import pytest


class TestDevCLICoverage:
    """Tests for the dev command to improve coverage."""

    def test_check_frontend_exists(self, tmp_path: Path) -> None:
        """Test frontend existence check."""
        from framework_m_studio.cli.dev import _check_frontend_exists

        assert not _check_frontend_exists(tmp_path)
        (tmp_path / "package.json").touch()
        assert _check_frontend_exists(tmp_path)

    def test_find_app_explicit(self) -> None:
        """Test app finding with explicit app."""
        from framework_m_studio.cli.dev import _find_app

        assert _find_app("custom:app") == "custom:app"

    def test_find_app_auto_detect(self, tmp_path: Path) -> None:
        """Test app finding via auto-detection."""
        from framework_m_studio.cli.dev import _find_app

        (tmp_path / "app.py").write_text("app = Litestar()")
        with patch("framework_m_studio.cli.dev.Path.cwd", return_value=tmp_path):
            assert _find_app(None) == "app:app"

        (tmp_path / "app.py").unlink()
        (tmp_path / "main.py").write_text("def create_app(): pass")
        with patch("framework_m_studio.cli.dev.Path.cwd", return_value=tmp_path):
            assert _find_app(None) == "main:create_app"

    def test_find_app_ast_parse_error(self, tmp_path: Path) -> None:
        """Test app finding when source has a syntax error."""
        from framework_m_studio.cli.dev import _find_app

        bad_app = tmp_path / "app.py"
        bad_app.write_text("invalid syntax {")
        with patch("framework_m_studio.cli.dev.Path.cwd", return_value=tmp_path):
            # Should swallow SyntaxError and eventually fallback to default
            assert _find_app(None) == "framework_m_standard.adapters.web.app:create_app"

    def test_find_app_ann_assign(self, tmp_path: Path) -> None:
        """Test app finding with annotated assignment (app: Litestar = ...)."""
        from framework_m_studio.cli.dev import _find_app

        app_file = tmp_path / "app.py"
        app_file.write_text("app: Litestar = Litestar()")
        with patch("framework_m_studio.cli.dev.Path.cwd", return_value=tmp_path):
            assert _find_app(None) == "app:app"

    def test_dev_command_no_frontend(self, tmp_path: Path) -> None:
        """Test dev command without frontend."""
        from framework_m_studio.cli.dev import dev_command

        with (
            patch("framework_m_studio.cli.dev.Manager") as mock_manager,
            patch("framework_m_studio.cli.dev._find_app", return_value="app:app"),
            patch(
                "framework_m_studio.cli.dev._check_frontend_exists", return_value=False
            ),
            patch(
                "framework_m_studio.cli.dev.load_dev_config_from_toml", return_value={}
            ),
            patch("framework_m_studio.cli.dev.Path.cwd", return_value=tmp_path),
            patch.dict(os.environ, {"PYTHONPATH": ""}),
        ):
            dev_command(
                app="app:app", frontend=False, studio=False, enable_worker=False
            )

            mock_instance = mock_manager.return_value
            mock_instance.add_process.assert_called()
            calls = mock_instance.add_process.call_args_list
            names = [c[0][0] for c in calls]
            assert "backend" in names
            assert "frontend" not in names

    def test_dev_command_with_frontend(self, tmp_path: Path) -> None:
        """Test dev command with frontend."""
        from framework_m_studio.cli.dev import dev_command

        frontend_dir = tmp_path / "frontend"
        frontend_dir.mkdir(parents=True, exist_ok=True)
        (frontend_dir / "package.json").touch()

        with (
            patch("framework_m_studio.cli.dev.Manager") as mock_manager,
            patch("framework_m_studio.cli.dev._find_app", return_value="app:app"),
            patch(
                "framework_m_studio.cli.dev._check_frontend_exists", return_value=True
            ),
            patch(
                "framework_m_studio.cli.dev.discover_frontend_plugins", return_value=[]
            ),
            patch("framework_m_studio.cli.dev.generate_plugin_entry"),
            patch("framework_m_studio.cli.dev.generate_vite_config"),
            patch(
                "framework_m_studio.cli.dev.load_dev_config_from_toml", return_value={}
            ),
            patch("framework_m_studio.cli.dev.Path.cwd", return_value=tmp_path),
            patch.dict(os.environ, {"PYTHONPATH": ""}),
        ):
            dev_command(
                app="app:app",
                frontend=True,
                frontend_dir=frontend_dir,
                studio=False,
                enable_worker=False,
            )

            names = [
                c[0][0] for c in mock_manager.return_value.add_process.call_args_list
            ]
            assert "backend" in names
            assert "frontend" in names

    def test_dev_command_with_studio_and_worker(self, tmp_path: Path) -> None:
        """Test dev command with studio and worker enabled."""
        from framework_m_studio.cli.dev import dev_command

        with (
            patch("framework_m_studio.cli.dev.Manager") as mock_manager,
            patch("framework_m_studio.cli.dev._find_app", return_value="app:app"),
            patch(
                "framework_m_studio.cli.dev._check_frontend_exists", return_value=False
            ),
            patch(
                "framework_m_studio.cli.dev.load_dev_config_from_toml", return_value={}
            ),
            patch("framework_m_studio.cli.dev.Path.cwd", return_value=tmp_path),
            patch.dict(os.environ, {"PYTHONPATH": ""}),
        ):
            dev_command(app="app:app", studio=True, enable_worker=True)

            names = [
                c[0][0] for c in mock_manager.return_value.add_process.call_args_list
            ]
            assert "studio" in names
            assert "worker" in names

    def test_dev_command_with_plugins_and_toml(self, tmp_path: Path) -> None:
        """Test dev command with discovered plugins and TOML config."""
        from framework_m_studio.cli.dev import dev_command

        plugins = [
            {
                "name": "app1",
                "path": Path("/tmp/app1/index.ts"),
                "source": "installed",
                "package": "app1",
            }
        ]
        toml_config = {
            "backend_port": 9090,
            "frontend_port": 4040,
            "enable_worker": True,
            "enable_scheduler": True,
        }

        with (
            patch("framework_m_studio.cli.dev.Manager") as mock_manager,
            patch("framework_m_studio.cli.dev._find_app", return_value="app:app"),
            patch(
                "framework_m_studio.cli.dev._check_frontend_exists", return_value=True
            ),
            patch(
                "framework_m_studio.cli.dev.discover_frontend_plugins",
                return_value=plugins,
            ),
            patch(
                "framework_m_studio.cli.dev.load_dev_config_from_toml",
                return_value=toml_config,
            ),
            patch("framework_m_studio.cli.dev.Path.cwd", return_value=tmp_path),
            patch.dict(os.environ, {"PYTHONPATH": ""}),
        ):
            dev_command(app="app:app")

            calls = mock_manager.return_value.add_process.call_args_list
            names = [c[0][0] for c in calls]
            assert "worker" in names
            assert "scheduler" in names

    def test_dev_command_with_procfile(self, tmp_path: Path) -> None:
        """Test dev command loading custom procfile."""
        from framework_m_studio.cli.dev import dev_command

        procfile = tmp_path / "Procfile.dev"
        procfile.write_text("custom: echo 'hello'")

        with (
            patch("framework_m_studio.cli.dev.Manager") as mock_manager,
            patch("framework_m_studio.cli.dev._find_app", return_value="app:app"),
            patch(
                "framework_m_studio.cli.dev._check_frontend_exists", return_value=False
            ),
            patch("framework_m_studio.cli.dev.Path.cwd", return_value=tmp_path),
        ):
            dev_command(procfile=procfile)

            calls = mock_manager.return_value.add_process.call_args_list
            names = [c[0][0] for c in calls]
            assert "custom" in names

    def test_dev_command_procfile_from_toml(self, tmp_path: Path) -> None:
        """Test dev command loads procfile specified in toml config."""
        from framework_m_studio.cli.dev import dev_command

        procfile = tmp_path / "my_procfile"
        procfile.write_text("toml_proc: echo 'from toml'")

        toml_config = {"procfile": str(procfile)}

        with (
            patch("framework_m_studio.cli.dev.Manager") as mock_manager,
            patch("framework_m_studio.cli.dev._find_app", return_value="app:app"),
            patch(
                "framework_m_studio.cli.dev._check_frontend_exists", return_value=False
            ),
            patch(
                "framework_m_studio.cli.dev.load_dev_config_from_toml",
                return_value=toml_config,
            ),
            patch("framework_m_studio.cli.dev.Path.cwd", return_value=tmp_path),
            patch.dict(os.environ, {"PYTHONPATH": ""}),
        ):
            dev_command(app="app:app")
            calls = mock_manager.return_value.add_process.call_args_list
            names = [c[0][0] for c in calls]
            assert "toml_proc" in names

    def test_dev_command_no_processes(
        self, tmp_path: Path, capsys: pytest.CaptureFixture[str]
    ) -> None:
        """Test dev command when there are no processes to run."""
        from framework_m_studio.cli.dev import dev_command

        with (
            patch("framework_m_studio.cli.dev.merge_process_configs", return_value={}),
            patch("framework_m_studio.cli.dev.Manager") as mock_manager,
            patch("framework_m_studio.cli.dev._find_app", return_value="app:app"),
            patch(
                "framework_m_studio.cli.dev._check_frontend_exists", return_value=False
            ),
            patch("framework_m_studio.cli.dev.Path.cwd", return_value=tmp_path),
        ):
            dev_command(
                frontend=False,
                studio=False,
                enable_worker=False,
                enable_scheduler=False,
            )

            captured = capsys.readouterr()
            assert "No processes to run!" in captured.err
            mock_manager.return_value.loop.assert_not_called()

    def test_dev_command_signal_handler(
        self, tmp_path: Path, capsys: pytest.CaptureFixture[str]
    ) -> None:
        """Test signal handler registration and execution."""
        import signal

        from framework_m_studio.cli.dev import dev_command

        signal_handlers = {}

        def mock_signal(sig: int, handler: object) -> None:
            signal_handlers[sig] = handler

        with (
            patch("framework_m_studio.cli.dev.signal.signal", side_effect=mock_signal),
            patch("framework_m_studio.cli.dev.Manager") as mock_manager,
            patch("framework_m_studio.cli.dev._find_app", return_value="app:app"),
            patch(
                "framework_m_studio.cli.dev._check_frontend_exists", return_value=False
            ),
            patch("framework_m_studio.cli.dev.Path.cwd", return_value=tmp_path),
            patch.dict(os.environ, {"PYTHONPATH": ""}),
        ):
            dev_command(app="app:app")

            # Trigger the captured handler manually
            signal_handlers[signal.SIGINT](signal.SIGINT, None)
            mock_manager.return_value.terminate.assert_called_once()
