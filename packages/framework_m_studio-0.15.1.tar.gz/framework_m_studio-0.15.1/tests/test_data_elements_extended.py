"""Extended tests for Data Elements — Blueprint UI + ConfigMap.

Tests for suggest() method and from_configmap() loader, extending
the existing DataElementRegistry.
"""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from framework_m_studio.data_elements import DataElement, DataElementRegistry


class TestSuggest:
    """Tests for DataElementRegistry.suggest()."""

    @pytest.fixture
    def registry(self, tmp_path: Path) -> DataElementRegistry:
        elements = [
            {"id": "VAT_ID", "fieldtype": "Data", "label": "VAT Number", "length": 20},
            {"id": "Email", "fieldtype": "Data", "label": "Email Address"},
            {"id": "Currency", "fieldtype": "Currency", "label": "Amount"},
            {"id": "Phone", "fieldtype": "Data", "label": "Phone Number", "length": 15},
            {"id": "Total", "fieldtype": "Float", "label": "Total Amount"},
        ]
        path = tmp_path / "bp.json"
        path.write_text(json.dumps({"elements": elements}))
        return DataElementRegistry.from_json(path)

    def test_suggest_by_fieldtype(self, registry: DataElementRegistry) -> None:
        """suggest() must filter blueprints by matching fieldtype."""
        results = registry.suggest("Data")

        assert len(results) == 3
        ids = [r.id for r in results]
        assert "VAT_ID" in ids
        assert "Email" in ids
        assert "Phone" in ids

    def test_suggest_no_matches(self, registry: DataElementRegistry) -> None:
        """suggest() must return empty list when no matches."""
        results = registry.suggest("Link")
        assert len(results) == 0

    def test_suggest_single_match(self, registry: DataElementRegistry) -> None:
        """suggest() must return single match."""
        results = registry.suggest("Currency")
        assert len(results) == 1
        assert results[0].id == "Currency"

    def test_suggest_returns_data_elements(self, registry: DataElementRegistry) -> None:
        """suggest() must return DataElement instances."""
        results = registry.suggest("Float")
        assert len(results) == 1
        assert isinstance(results[0], DataElement)
        assert results[0].label == "Total Amount"


class TestFromConfigMap:
    """Tests for DataElementRegistry.from_configmap()."""

    def test_load_from_configmap_path(self, tmp_path: Path) -> None:
        """from_configmap() must load from an arbitrary path (K8s-style)."""
        elements = [
            {"id": "Corp_ID", "fieldtype": "Data", "label": "Corporate ID"},
            {"id": "Dept_Code", "fieldtype": "Data", "label": "Department Code"},
        ]
        configmap_path = tmp_path / "etc" / "studio"
        configmap_path.mkdir(parents=True)
        bp_file = configmap_path / "blueprints.json"
        bp_file.write_text(json.dumps({"elements": elements}))

        registry = DataElementRegistry.from_configmap(bp_file)

        assert len(registry.elements) == 2
        assert "Corp_ID" in registry.elements
        assert "Dept_Code" in registry.elements

    def test_configmap_marks_readonly(self, tmp_path: Path) -> None:
        """Blueprints from ConfigMap must be marked as read-only."""
        elements = [
            {"id": "Corp_ID", "fieldtype": "Data", "label": "Corporate ID"},
        ]
        bp_file = tmp_path / "blueprints.json"
        bp_file.write_text(json.dumps({"elements": elements}))

        registry = DataElementRegistry.from_configmap(bp_file)

        assert registry.is_readonly is True

    def test_configmap_file_not_found(self) -> None:
        """from_configmap() must return empty registry for missing file."""
        registry = DataElementRegistry.from_configmap(Path("/nonexistent/path.json"))

        assert len(registry.elements) == 0
        assert registry.is_readonly is True

    def test_merge_registries(self, tmp_path: Path) -> None:
        """merge() must combine two registries, local overrides configmap."""
        # ConfigMap (corporate)
        cm_elements = [{"id": "Corp_ID", "fieldtype": "Data", "label": "Corporate ID"}]
        cm_file = tmp_path / "configmap.json"
        cm_file.write_text(json.dumps({"elements": cm_elements}))
        configmap_reg = DataElementRegistry.from_configmap(cm_file)

        # Local
        local_elements = [{"id": "Custom_ID", "fieldtype": "Data", "label": "Custom"}]
        local_file = tmp_path / "local.json"
        local_file.write_text(json.dumps({"elements": local_elements}))
        local_reg = DataElementRegistry.from_json(local_file)

        merged = DataElementRegistry.merge(configmap_reg, local_reg)

        assert "Corp_ID" in merged.elements
        assert "Custom_ID" in merged.elements
        assert len(merged.elements) == 2
