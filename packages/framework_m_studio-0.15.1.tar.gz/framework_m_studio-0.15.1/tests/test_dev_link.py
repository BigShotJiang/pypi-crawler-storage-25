"""Tests for Modular Dev Link CLI Command - 100% Coverage."""

from __future__ import annotations

import json
import shutil
import subprocess
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from framework_m_studio.cli.dev_link import (
    DevLinkConfig,
    DevLinkOrchestrator,
    Package,
    PackageDiscovery,
    PackageLinker,
    dev_link_command,
)


@pytest.fixture
def clean_console():
    with patch("framework_m_studio.cli.dev_link.console") as mock:
        yield mock


def test_package_discovery_should_include() -> None:
    discovery = PackageDiscovery()
    config = DevLinkConfig(framework_path=Path("/tmp"), include=["a"], exclude=["b"])

    assert discovery._should_include("a", config) is True
    assert discovery._should_include("b", config) is False
    assert discovery._should_include("c", config) is False

    config2 = DevLinkConfig(framework_path=Path("/tmp"))
    assert discovery._should_include("any", config2) is True


def test_discovery_find_python(tmp_path: Path) -> None:
    discovery = PackageDiscovery()
    fw = tmp_path / "fw"
    fw.mkdir()
    (fw / "libs").mkdir()
    p1 = fw / "libs" / "p1"
    p1.mkdir()
    (p1 / "pyproject.toml").write_text("")
    (fw / "libs" / "ignored_file").write_text("")

    (fw / "apps").mkdir()
    a1 = fw / "apps" / "a1"
    a1.mkdir()
    (a1 / "pyproject.toml").write_text("")

    config = DevLinkConfig(framework_path=fw)
    pkgs = discovery.find_python_packages(config)
    assert len(pkgs) == 2
    assert any(p.name == "p1" for p in pkgs)
    assert any(p.name == "a1" for p in pkgs)


def test_discovery_find_js(tmp_path: Path) -> None:
    discovery = PackageDiscovery()
    fw = tmp_path / "fw"
    fw.mkdir()
    libs = fw / "libs"
    libs.mkdir()

    # Scoped
    ui = libs / "ui"
    ui.mkdir()
    (ui / "package.json").write_text(json.dumps({"name": "@framework-m/ui"}))

    # Private
    priv = libs / "priv"
    priv.mkdir()
    (priv / "package.json").write_text(
        json.dumps({"name": "@framework-m/priv", "private": True})
    )

    # Non-scoped
    other = libs / "other"
    other.mkdir()
    (other / "package.json").write_text(json.dumps({"name": "other"}))

    # Error path (Corrupt JSON)
    bad = libs / "bad"
    bad.mkdir()
    (bad / "package.json").write_text("{")

    pkgs = discovery.find_js_packages(DevLinkConfig(framework_path=fw))
    assert any(p.name == "@framework-m/ui" for p in pkgs)
    assert not any(p.name == "@framework-m/priv" for p in pkgs)

    # Exclusion test
    config_exc = DevLinkConfig(framework_path=fw, exclude=["ui"])
    pkgs_exc = discovery.find_js_packages(config_exc)
    assert not any(p.name == "@framework-m/ui" for p in pkgs_exc)

    # Error path (OSError)
    with patch("pathlib.Path.read_text", side_effect=OSError):
        pkgs_err = discovery.find_js_packages(DevLinkConfig(framework_path=fw))
        assert pkgs_err == []

    # No libs
    shutil.rmtree(libs)
    assert discovery.find_js_packages(DevLinkConfig(framework_path=fw)) == []


def test_discovery_find_node_modules(tmp_path: Path) -> None:
    discovery = PackageDiscovery()
    app = tmp_path / "app"
    app.mkdir()
    (app / "node_modules").mkdir()
    (app / "sub").mkdir()
    (app / "sub" / "package.json").write_text("{}")
    (app / "sub" / "node_modules").mkdir()

    nm = discovery.find_node_modules(app)
    assert len(nm) == 2

    # Coverage: root_nm doesn't exist, and skipping internal paths
    shutil.rmtree(app / "node_modules")
    (app / ".venv").mkdir()
    (app / ".venv" / "package.json").write_text("{}")
    discovery.find_node_modules(app)

    # Duplicate path test
    (app / "node_modules").mkdir()
    (app / "package.json").write_text("{}")
    nm2 = discovery.find_node_modules(app)
    assert len(nm2) == 2


@patch("subprocess.run")
def test_linker_python(mock_run: MagicMock, tmp_path: Path, clean_console) -> None:
    linker = PackageLinker()
    pkg = Package(name="p1", path=tmp_path / "p1")

    # Dry run
    linker.link_python(pkg, dry_run=True)

    # Success (with venv discovery)
    app = tmp_path / "app"
    app.mkdir()
    (app / ".venv").mkdir()
    with (
        patch("os.getcwd", return_value=str(app)),
        patch("platform.system", return_value="Linux"),
    ):
        assert linker.link_python(pkg, dry_run=False) is True
        assert "bin/python" in mock_run.call_args[0][0][4]

    # Windows venv
    mock_run.reset_mock()
    with (
        patch("os.getcwd", return_value=str(app)),
        patch("platform.system", return_value="Windows"),
    ):
        linker.link_python(pkg, dry_run=False)
        assert "Scripts" in mock_run.call_args[0][0][4]

    # Error
    mock_run.side_effect = subprocess.CalledProcessError(1, "uv")
    assert linker.link_python(pkg, dry_run=False) is False


@patch("pathlib.Path.symlink_to")
def test_linker_js(mock_sym: MagicMock, tmp_path: Path, clean_console) -> None:
    linker = PackageLinker()
    pkg = Package(name="@m/ui", path=tmp_path / "src", is_js=True)
    dest = tmp_path / "dest"

    # Dry run
    linker.link_js(pkg, dest, dry_run=True)

    # Success (Symlink)
    with (
        patch("pathlib.Path.is_symlink", return_value=True),
        patch("pathlib.Path.unlink"),
    ):
        assert linker.link_js(pkg, dest, dry_run=False) is True

    # Success (Remove existing dir)
    mock_sym.reset_mock()
    with (
        patch("pathlib.Path.exists", return_value=True),
        patch("pathlib.Path.is_symlink", return_value=False),
        patch("shutil.rmtree") as mock_rm,
    ):
        assert linker.link_js(pkg, dest, dry_run=False) is True
        mock_rm.assert_called_once()

    # Windows Fallback
    mock_sym.reset_mock()
    mock_sym.side_effect = OSError
    with (
        patch("platform.system", return_value="Windows"),
        patch("subprocess.run") as mock_run,
    ):
        assert linker.link_js(pkg, dest, dry_run=False) is True
        assert mock_run.call_count == 1

    # Windows Fallback Failure
    with (
        patch("platform.system", return_value="Windows"),
        patch("subprocess.run", side_effect=subprocess.CalledProcessError(1, "cmd")),
    ):
        assert linker.link_js(pkg, dest, dry_run=False) is False

    # Linux Failure
    with patch("platform.system", return_value="Linux"):
        assert linker.link_js(pkg, dest, dry_run=False) is False


def test_orchestrator(clean_console) -> None:
    disc = MagicMock()
    link = MagicMock()
    orch = DevLinkOrchestrator(disc, link)

    pkg_py = Package(name="p1", path=Path("/p1"))
    pkg_js = Package(name="j1", path=Path("/j1"), is_js=True)

    disc.find_python_packages.return_value = [pkg_py]
    disc.find_js_packages.return_value = [pkg_js]
    disc.find_node_modules.return_value = [Path("/app/nm")]

    config = DevLinkConfig(framework_path=Path("/fw"))
    orch.run(config)

    link.link_python.assert_called_once()
    link.link_js.assert_called_once()


@patch("sys.exit")
def test_command_errors(mock_exit: MagicMock, clean_console) -> None:
    # No path
    with patch("os.environ", {}):
        dev_link_command()
        mock_exit.assert_called_with(1)

    # Invalid path
    mock_exit.reset_mock()
    dev_link_command("/nonexistent")
    mock_exit.assert_called_with(1)


def test_command_full(tmp_path: Path, clean_console) -> None:
    fw = tmp_path / "fw"
    fw.mkdir()
    (fw / "pnpm-workspace.yaml").write_text("")
    (fw / "libs").mkdir()
    (fw / "libs" / "core").mkdir()
    (fw / "libs" / "core" / "pyproject.toml").write_text("")

    app = tmp_path / "app"
    app.mkdir()
    (app / "node_modules").mkdir()

    with (
        patch("os.getcwd", return_value=str(app)),
        patch("framework_m_studio.cli.dev_link.load_m_toml", return_value={}),
        patch("subprocess.run"),
    ):
        # Success flow
        dev_link_command(str(fw))

        # Env var filtering
        with patch("os.environ", {"FRAMEWORK_M_LINK_INCLUDE": "core"}):
            dev_link_command(str(fw))


def test_command_wrapper(tmp_path: Path, clean_console) -> None:
    # Test the cyclopts wrapper
    fw = tmp_path / "fw"
    fw.mkdir()
    (fw / "pnpm-workspace.yaml").write_text("")

    with patch("framework_m_studio.cli.dev_link._dev_link_internal") as mock_int:
        from framework_m_studio.cli.dev_link import dev_link_command

        dev_link_command(path=str(fw), dry_run=True)
        mock_int.assert_called_once_with(str(fw), True)
