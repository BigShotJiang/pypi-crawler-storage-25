"""Tests for Release Orchestrator logic to increase coverage."""

from __future__ import annotations

import json
import os
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from framework_m_studio.cli.release.models import (
    Commit,
    ReleaseConfig,
    ReleasePackage,
    ReleaseSync,
    ReleaseUpdate,
)
from framework_m_studio.cli.release.orchestrator import (
    _determine_version_bump,
    _load_release_config,
    _stage_release_files,
    prepare_release,
    run_release_orchestration,
    tag_and_release,
)


@pytest.fixture
def mock_config() -> ReleaseConfig:
    return ReleaseConfig(
        packages=[],
        sync=[],
        release_branch="release-next",
        target_branch="main",
    )


@pytest.mark.asyncio
@patch("framework_m_studio.cli.release.orchestrator.run_cmd")
@patch("framework_m_studio.cli.release.orchestrator._load_release_config")
@patch("framework_m_studio.cli.release.orchestrator.compute_release_plan")
@patch("framework_m_studio.cli.release.orchestrator.prepare_release")
@patch("framework_m_studio.cli.release.orchestrator._stage_release_files")
@patch("framework_m_studio.cli.release.orchestrator.push_release_branch")
@patch(
    "framework_m_studio.cli.release.orchestrator.create_or_update_mr",
    new_callable=AsyncMock,
)
async def test_run_release_orchestration_unsupported_provider(
    mock_mr: AsyncMock,
    mock_push: MagicMock,
    mock_stage: MagicMock,
    mock_prep: MagicMock,
    mock_plan: MagicMock,
    mock_load: MagicMock,
    mock_run_cmd: MagicMock,
) -> None:
    """Test unsupported provider exits early."""
    with pytest.raises(SystemExit):
        await run_release_orchestration("github", "token", "123")


@pytest.mark.asyncio
@patch("framework_m_studio.cli.release.orchestrator.run_cmd")
@patch("framework_m_studio.cli.release.orchestrator._load_release_config")
@patch("framework_m_studio.cli.release.orchestrator.compute_release_plan")
@patch("framework_m_studio.cli.release.orchestrator.prepare_release")
@patch("framework_m_studio.cli.release.orchestrator._stage_release_files")
@patch("framework_m_studio.cli.release.orchestrator.push_release_branch")
@patch(
    "framework_m_studio.cli.release.orchestrator.create_or_update_mr",
    new_callable=AsyncMock,
)
async def test_run_release_orchestration_no_updates(
    mock_mr: AsyncMock,
    mock_push: MagicMock,
    mock_stage: MagicMock,
    mock_prep: MagicMock,
    mock_plan: MagicMock,
    mock_load: MagicMock,
    mock_run_cmd: MagicMock,
    mock_config: ReleaseConfig,
) -> None:
    """Test early exit when no updates needed."""
    mock_load.return_value = mock_config
    mock_plan.return_value = []

    await run_release_orchestration("gitlab", "token", "123")

    # Should not proceed to branch checkout or MR creation
    mock_prep.assert_not_called()
    mock_mr.assert_not_called()


@pytest.mark.asyncio
@patch("framework_m_studio.cli.release.orchestrator.run_cmd")
@patch("framework_m_studio.cli.release.orchestrator._load_release_config")
@patch("framework_m_studio.cli.release.orchestrator.compute_release_plan")
@patch("framework_m_studio.cli.release.orchestrator.prepare_release")
@patch("framework_m_studio.cli.release.orchestrator._stage_release_files")
@patch("framework_m_studio.cli.release.orchestrator.push_release_branch")
@patch(
    "framework_m_studio.cli.release.orchestrator.create_or_update_mr",
    new_callable=AsyncMock,
)
@patch.dict(os.environ, {"CI": "true", "CITADEL_CI_TOKEN": "123"}, clear=True)
async def test_run_release_orchestration_full_flow(
    mock_mr: AsyncMock,
    mock_push: MagicMock,
    mock_stage: MagicMock,
    mock_prep: MagicMock,
    mock_plan: MagicMock,
    mock_load: MagicMock,
    mock_run_cmd: MagicMock,
    mock_config: ReleaseConfig,
) -> None:
    """Test full release orchestration matching lines 349-420."""
    mock_load.return_value = mock_config

    # Needs at least one primary and one internal update to hit lines 400-418
    updates = [
        ReleaseUpdate(
            component="pkgA",
            component_path="pkgA",
            version_file="pyproject.toml",
            current_version="1.0.0",
            new_version="1.1.0",
            bump="minor",
            changelog="- added feature X",
        ),
        ReleaseUpdate(
            component="pkgB",
            component_path="pkgB",
            version_file="pyproject.toml",
            current_version="1.0.0",
            new_version="1.0.1",
            bump="patch",
            changelog="- internal dependency bump",
        ),
    ]
    mock_plan.return_value = updates

    # Make git status return something so commit is triggered
    def mock_run_cmd_side_effect(*args, **kwargs):
        cmd = args[0]
        if isinstance(cmd, list) and cmd[:2] == ["git", "status"]:
            return "M pyproject.toml"
        return ""

    mock_run_cmd.side_effect = mock_run_cmd_side_effect

    await run_release_orchestration("gitlab", "token123", "proj1")

    # Verify key steps were called
    mock_prep.assert_called_once()
    mock_stage.assert_called_once()
    mock_push.assert_called_once_with(
        mock_config.release_branch, "gitlab.com", "", "token123"
    )
    mock_mr.assert_called_once()

    # Check that description logic was hit
    args, _ = mock_mr.call_args
    desc = args[3]
    assert "Automated Release" in desc
    assert "pkgA" in desc
    assert "Internal Adjustments" in desc


@pytest.mark.asyncio
@patch("framework_m_studio.cli.release.orchestrator.run_cmd")
@patch("framework_m_studio.cli.release.orchestrator._load_release_config")
@patch("framework_m_studio.cli.release.orchestrator.compute_release_plan")
@patch("framework_m_studio.cli.release.orchestrator.prepare_release")
@patch("framework_m_studio.cli.release.orchestrator._stage_release_files")
async def test_run_release_orchestration_dry_run(
    mock_stage: MagicMock,
    mock_prep: MagicMock,
    mock_plan: MagicMock,
    mock_load: MagicMock,
    mock_run_cmd: MagicMock,
    mock_config: ReleaseConfig,
) -> None:
    """Test dry_run exits before git commit."""
    mock_load.return_value = mock_config
    mock_plan.return_value = [
        ReleaseUpdate(
            component="pkgA",
            component_path="pkgA",
            version_file="pyproject.toml",
            current_version="1.0.0",
            new_version="1.1.0",
            bump="minor",
            changelog="- added feature X",
        )
    ]

    await run_release_orchestration("gitlab", "token", "123", dry_run=True)

    mock_stage.assert_called_once()
    # Check that git commit is NOT called
    for call in mock_run_cmd.mock_calls:
        args = call[1]
        cmd = args[0] if args else []
        if isinstance(cmd, list):
            assert cmd[0] != "commit"


@pytest.mark.asyncio
@patch("framework_m_studio.cli.release.orchestrator.run_cmd")
@patch("framework_m_studio.cli.release.orchestrator._load_release_config")
@patch("framework_m_studio.cli.release.orchestrator.compute_release_plan")
@patch("framework_m_studio.cli.release.orchestrator.prepare_release")
@patch("framework_m_studio.cli.release.orchestrator._stage_release_files")
@patch.dict(os.environ, {"CI": "true", "CITADEL_CI_TOKEN": ""}, clear=True)
async def test_run_release_orchestration_no_token(
    mock_stage: MagicMock,
    mock_prep: MagicMock,
    mock_plan: MagicMock,
    mock_load: MagicMock,
    mock_run_cmd: MagicMock,
    mock_config: ReleaseConfig,
) -> None:
    """Test raising ValueError when token is missing."""
    mock_load.return_value = mock_config
    mock_plan.return_value = [
        ReleaseUpdate(
            component="pkgA",
            component_path="pkgA",
            version_file="pyproject.toml",
            current_version="1.0.0",
            new_version="1.1.0",
            bump="minor",
            changelog="- added feature X",
        )
    ]

    def mock_run_cmd_side_effect(*args, **kwargs):
        cmd = args[0]
        if isinstance(cmd, list) and cmd[:2] == ["git", "status"]:
            return "M pyproject.toml"
        return ""

    mock_run_cmd.side_effect = mock_run_cmd_side_effect

    with pytest.raises(ValueError, match="No Git token found"):
        await run_release_orchestration("gitlab", "", "123")


def test_load_release_config_absolute_path(tmp_path: Path) -> None:
    """Test _load_release_config with absolute path."""
    cfg_file = tmp_path / "config.json"
    cfg_file.write_text(
        '{"target_branch": "main", "release_branch": "rel", "packages": []}'
    )
    config = _load_release_config(str(cfg_file))
    assert config.target_branch == "main"


def test_load_release_config_paths_migration(tmp_path: Path) -> None:
    """Test _load_release_config path to paths migration."""
    cfg_file = tmp_path / "config.json"
    cfg_file.write_text(
        json.dumps(
            {
                "target_branch": "main",
                "release_branch": "rel",
                "packages": [
                    {
                        "name": "test-pkg",
                        "path": "some/path",
                        "version_file": "v.json",
                        "scopes": [],
                    }
                ],
            }
        )
    )
    config = _load_release_config("config.json", root=tmp_path)
    assert config.packages[0].paths == ["some/path"]


def test_determine_version_bump() -> None:
    """Test _determine_version_bump edge cases."""
    # No bump
    assert (
        _determine_version_bump(
            [
                Commit(
                    hash="1",
                    type="chore",
                    subject="a",
                    description="",
                    body="",
                    breaking=False,
                )
            ]
        )
        is None
    )
    # Major
    assert (
        _determine_version_bump(
            [
                Commit(
                    hash="1",
                    type="feat",
                    subject="a",
                    description="",
                    body="",
                    breaking=True,
                )
            ]
        )
        == "major"
    )
    # Minor (mixed with fix)
    assert (
        _determine_version_bump(
            [
                Commit(
                    hash="1",
                    type="fix",
                    subject="a",
                    description="",
                    body="",
                    breaking=False,
                ),
                Commit(
                    hash="2",
                    type="feat",
                    subject="b",
                    description="",
                    body="",
                    breaking=False,
                ),
            ]
        )
        == "minor"
    )
    assert (
        _determine_version_bump(
            [
                Commit(
                    hash="1",
                    type="feat",
                    subject="a",
                    description="",
                    body="",
                    breaking=False,
                ),
                Commit(
                    hash="2",
                    type="fix",
                    subject="b",
                    description="",
                    body="",
                    breaking=False,
                ),
            ]
        )
        == "minor"
    )
    # Patch
    assert (
        _determine_version_bump(
            [
                Commit(
                    hash="1",
                    type="fix",
                    subject="a",
                    description="",
                    body="",
                    breaking=False,
                )
            ]
        )
        == "patch"
    )


def test_prepare_release_branches(tmp_path: Path) -> None:
    """Test prepare_release missing files, dirs, and sync logic."""
    pkg = ReleasePackage(
        name="pkg", paths=["pkg"], version_file="pkg/package.json", scopes=[]
    )
    sync = ReleaseSync(
        file="sync.json", package_name="pkg", pattern=r'"version": "(.*?)"'
    )
    sync_no_pattern = ReleaseSync(file="no_pattern.json", package_name="pkg")
    config = ReleaseConfig(
        target_branch="main",
        release_branch="rel",
        packages=[pkg],
        sync=[sync, sync_no_pattern],
    )

    (tmp_path / "pkg").mkdir()

    update = ReleaseUpdate(
        component="pkg",
        component_path="pkg",
        version_file="pkg/package.json",
        current_version="1.0.0",
        new_version="2.0.0",
        bump="major",
        changelog="",
    )

    # Missing files, shouldn't crash
    prepare_release([update], "branch", tmp_path, config)

    # Setup files for sync
    (tmp_path / "pkg" / "package.json").write_text('{"version": "1.0.0"}')
    (tmp_path / "sync.json").write_text('{"version": "1.0.0"}')
    (tmp_path / "no_pattern.json").write_text("{}")
    (tmp_path / "sync_dir").mkdir()
    config.sync.append(ReleaseSync(file="sync_dir", package_name="pkg"))
    config.sync.append(
        ReleaseSync(
            file="sync.json", package_name="other_pkg", pattern=r'"version": "(.*?)"'
        )
    )

    with (
        patch(
            "framework_m_studio.cli.release.orchestrator._pin_inter_package_dependencies"
        ),
        patch("framework_m_studio.cli.release.lockfile_sync.sync_lockfiles"),
    ):
        prepare_release([update], "branch", tmp_path, config)
        assert "2.0.0" in (tmp_path / "sync.json").read_text()

        # Test no change (already updated)
        prepare_release([update], "branch", tmp_path, config)


@pytest.mark.asyncio
@patch("framework_m_studio.cli.release.orchestrator.run_cmd")
@patch("framework_m_studio.cli.release.orchestrator._get_last_tag")
@patch("framework_m_studio.cli.release.orchestrator._get_commits_since")
@patch("framework_m_studio.cli.release.orchestrator._filter_component_commits")
async def test_tag_and_release_branches(
    mock_filter: MagicMock,
    mock_commits: MagicMock,
    mock_last_tag: MagicMock,
    mock_run_cmd: MagicMock,
    tmp_path: Path,
) -> None:
    """Test tag_and_release missing files, internal releases, and dry run."""
    pkg1 = ReleasePackage(
        name="pkg1", paths=["pkg1"], version_file="v1.json", scopes=[]
    )
    pkg2 = ReleasePackage(
        name="pkg2", paths=["pkg2"], version_file="v2.toml", scopes=[]
    )
    pkg_missing = ReleasePackage(
        name="missing", paths=["missing"], version_file="missing.json", scopes=[]
    )

    config = ReleaseConfig(
        target_branch="main", release_branch="rel", packages=[pkg1, pkg2, pkg_missing]
    )

    (tmp_path / "v1.json").write_text('{"version": "1.0.0"}')
    (tmp_path / "v2.toml").write_text('version = "2.0.0"')

    mock_last_tag.side_effect = ["pkg1@v0.9.0", "pkg2@v2.0.0"]
    mock_commits.return_value = []
    mock_filter.return_value = []  # Empty commits -> Internal sync message

    await tag_and_release(config, tmp_path, None, dry_run=False)
    mock_run_cmd.assert_any_call('git tag -a pkg1@v1.0.0 -m "Release 1.0.0"')

    # Dry run
    mock_last_tag.side_effect = ["pkg1@v0.9.0", "pkg2@v2.0.0"]
    await tag_and_release(config, tmp_path, None, dry_run=True)


@patch("framework_m_studio.cli.release.orchestrator.run_cmd")
@patch("framework_m_studio.cli.release.orchestrator.subprocess.run")
def test_stage_release_files_branches(
    mock_sub_run: MagicMock, mock_run_cmd: MagicMock, tmp_path: Path
) -> None:
    """Test _stage_release_files missing files and git ignore checks."""
    pkg1 = ReleasePackage(
        name="pkg1", paths=["pkg1"], version_file="v1.json", scopes=[]
    )
    config = ReleaseConfig(
        target_branch="main",
        release_branch="rel",
        packages=[pkg1],
        sync=[ReleaseSync(file="sync.json", package_name="pkg1")],
    )
    update = ReleaseUpdate(
        component="pkg1",
        component_path="pkg1",
        version_file="v1.json",
        current_version="1.0.0",
        new_version="2.0.0",
        bump="major",
        changelog="",
    )

    # Empty
    _stage_release_files(tmp_path, config, [update])
    mock_run_cmd.assert_not_called()

    # Populated
    (tmp_path / "v1.json").touch()
    (tmp_path / "pkg1").mkdir()
    (tmp_path / "pkg1" / "CHANGELOG.md").touch()
    (tmp_path / "sync.json").touch()
    (tmp_path / "pnpm-lock.yaml").touch()

    mock_res = MagicMock()
    mock_res.returncode = 1  # Not ignored
    mock_sub_run.return_value = mock_res

    _stage_release_files(tmp_path, config, [update])
    mock_run_cmd.assert_called_once()

    # Ignored
    mock_run_cmd.reset_mock()
    mock_res.returncode = 0
    _stage_release_files(tmp_path, config, [update])
    mock_run_cmd.assert_not_called()
