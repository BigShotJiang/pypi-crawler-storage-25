"""Coverage tests for doctype service."""

from pathlib import Path
from unittest.mock import patch

from framework_m_studio.schemas import CreateDocTypeRequest, FieldSchema
from framework_m_studio.services.doctype import (
    cleanup_renamed_doctype_paths,
    find_old_doctype_folder,
    load_existing_doctype_source,
    sanitize_doctype_name,
    update_doctype_code,
)


def test_sanitize_doctype_name():
    assert sanitize_doctype_name("My-Doc type") == "MyDocType"


def test_find_old_doctype_folder(tmp_path: Path):
    from framework_m_studio.discovery import DocTypeInfo

    mock_doc = DocTypeInfo(
        name="TestDoc",
        module="test_doc",
        file_path=str(tmp_path / "test_doc" / "doctype.py"),
    )
    with patch(
        "framework_m_studio.services.doctype.scan_doctypes", return_value=[mock_doc]
    ):
        assert find_old_doctype_folder(tmp_path, "TestDoc") == tmp_path / "test_doc"

    mock_doc_2 = DocTypeInfo(
        name="TestDoc2",
        module="test_doc",
        file_path=str(tmp_path / "random_folder" / "test_doc2.py"),
    )
    with patch(
        "framework_m_studio.services.doctype.scan_doctypes", return_value=[mock_doc_2]
    ):
        assert find_old_doctype_folder(tmp_path, "TestDoc2") is None


def test_update_doctype_code_exception(tmp_path: Path):
    schema = CreateDocTypeRequest(
        name="TestDoc", fields=[FieldSchema(name="f1", type="str", required=True)]
    )
    doc_file = tmp_path / "doctype.py"

    with patch(
        "framework_m_studio.services.doctype.update_doctype",
        side_effect=Exception("Failed"),
    ):
        update_doctype_code(doc_file, schema)

    content = doc_file.read_text()
    assert "class TestDoc" in content


def test_cleanup_renamed_doctype_paths(tmp_path: Path):
    old_folder = tmp_path / "old_doc"
    old_folder.mkdir()

    old_tests = tmp_path / "tests" / "doctypes" / "old_doc"
    old_tests.mkdir(parents=True)

    cleanup_renamed_doctype_paths(tmp_path, "OldDoc", old_folder)
    assert not old_folder.exists()
    assert not old_tests.exists()


def test_load_existing_doctype_source(tmp_path: Path):
    from framework_m_studio.discovery import DocTypeInfo

    doc_file = tmp_path / "doctype.py"
    doc_file.write_text("class TestDoc:")

    mock_doc = DocTypeInfo(name="TestDoc", module="test_doc", file_path=str(doc_file))

    with patch(
        "framework_m_studio.services.doctype.scan_doctypes", return_value=[mock_doc]
    ):
        source = load_existing_doctype_source("TestDoc", tmp_path)
        assert source == "class TestDoc:"
        assert load_existing_doctype_source("OtherDoc", tmp_path) == ""


def test_find_old_doctype_folder_edge_cases(tmp_path: Path):
    from framework_m_studio.discovery import DocTypeInfo

    # 1. old_file.exists() == True, old_controller.exists() == True
    file1 = tmp_path / "other_folder" / "doc1.py"
    file1.parent.mkdir(parents=True, exist_ok=True)
    file1.touch()
    ctrl1 = file1.parent / "doc1_controller.py"
    ctrl1.touch()

    doc1 = DocTypeInfo(name="DocOne", module="other_folder", file_path=str(file1))

    # 2. old_file.exists() == False
    file2 = tmp_path / "another" / "doc2.py"
    doc2 = DocTypeInfo(name="DocTwo", module="another", file_path=str(file2))

    # 3. Not matching name
    doc_unmatched = DocTypeInfo(name="Unmatched", module="m", file_path="")

    with patch(
        "framework_m_studio.services.doctype.scan_doctypes",
        return_value=[doc_unmatched, doc1, doc2],
    ):
        assert find_old_doctype_folder(tmp_path, "DocOne") is None
        assert not file1.exists()
        assert not ctrl1.exists()

        assert find_old_doctype_folder(tmp_path, "DocTwo") is None
        assert find_old_doctype_folder(tmp_path, "Missing") is None


def test_update_doctype_code_table_field(tmp_path: Path):
    schema = CreateDocTypeRequest(
        name="TestDoc",
        app="test",
        fields=[
            FieldSchema(
                name="child", type="Table", table_doctype="ChildItem", required=False
            ),
        ],
    )
    doc_file = tmp_path / "doctype.py"
    doc_file.write_text("class TestDoc:\n    pass")

    update_doctype_code(doc_file, schema)
    content = doc_file.read_text()
    assert "list[ChildItem]" in content


def test_cleanup_renamed_doctype_paths_edge_cases(tmp_path: Path):
    cleanup_renamed_doctype_paths(tmp_path, "Doc", None)
    cleanup_renamed_doctype_paths(tmp_path, "Doc", tmp_path / "missing")


def test_load_existing_doctype_source_missing_file(tmp_path: Path):
    from framework_m_studio.discovery import DocTypeInfo

    doc_file = tmp_path / "missing_doctype.py"
    mock_doc = DocTypeInfo(name="TestDoc", module="test_doc", file_path=str(doc_file))

    with patch(
        "framework_m_studio.services.doctype.scan_doctypes", return_value=[mock_doc]
    ):
        source = load_existing_doctype_source("TestDoc", tmp_path)
        assert source == ""
