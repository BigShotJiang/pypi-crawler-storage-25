"""Branch coverage tests for aggregate_builder.py"""

from framework_m_studio.aggregate_builder import AggregateRootBuilder, LinkedDocType


def test_operations_on_unknown_root() -> None:
    """Methods should gracefully handle unknown root DocTypes without crashing."""
    builder = AggregateRootBuilder()

    # Should exit early without raising exceptions
    builder.link("UnknownRoot", LinkedDocType("Child", "link_field"))
    builder.unlink("UnknownRoot", "Child")

    assert builder.get_config("UnknownRoot") is None
    assert builder.to_dict("UnknownRoot") == {}
