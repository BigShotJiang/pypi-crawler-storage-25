"""Additional tests for Release CLI branches to increase coverage."""

from __future__ import annotations

import os
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from framework_m_studio.cli.release.cli import (
    release_plan_command,
    release_prepare_command,
    release_schema_command,
    release_tag_command,
)
from framework_m_studio.cli.release.models import ReleaseConfig


class TestReleaseCliMore:
    @patch("framework_m_studio.cli.release.cli._load_release_config")
    @patch("framework_m_studio.cli.release.cli.compute_release_plan")
    def test_plan_command_no_updates(
        self, mock_plan: MagicMock, mock_load: MagicMock
    ) -> None:
        mock_load.return_value = ReleaseConfig(packages=[])
        mock_plan.return_value = []
        # Should print "No releases needed"
        release_plan_command(json=False)
        mock_plan.assert_called_once()

    @patch("framework_m_studio.cli.release.cli._load_release_config")
    def test_prepare_command_file_not_found_raise(self, mock_load: MagicMock) -> None:
        mock_load.side_effect = FileNotFoundError()
        with pytest.raises(FileNotFoundError):
            release_prepare_command(dry_run=False)

    @patch("framework_m_studio.cli.release.cli._load_release_config")
    @patch("framework_m_studio.cli.release.cli.compute_release_plan")
    def test_prepare_command_no_updates(
        self, mock_plan: MagicMock, mock_load: MagicMock
    ) -> None:
        mock_load.return_value = ReleaseConfig(packages=[])
        mock_plan.return_value = []
        release_prepare_command(dry_run=False)
        mock_plan.assert_called_once()

    @patch("framework_m_studio.cli.release.cli._load_release_config")
    @patch("framework_m_studio.cli.release.cli.compute_release_plan")
    def test_prepare_command_dry_run_no_updates(
        self, mock_plan: MagicMock, mock_load: MagicMock
    ) -> None:
        mock_load.return_value = ReleaseConfig(packages=[])
        mock_plan.return_value = []
        release_prepare_command(dry_run=True)
        mock_plan.assert_called_once()

    @pytest.mark.asyncio
    @patch("framework_m_studio.cli.release.cli._load_release_config")
    async def test_tag_command_config_error_raise(self, mock_load: MagicMock) -> None:
        mock_load.side_effect = Exception("General error")
        with pytest.raises(Exception, match="General error"):
            await release_tag_command(provider="gitlab")

    @pytest.mark.asyncio
    @patch("framework_m_studio.cli.release.cli._load_release_config")
    @patch.dict(
        os.environ, {"CITADEL_CI_TOKEN": "123", "CI_PROJECT_ID": "456"}, clear=True
    )
    async def test_tag_command_unsupported_provider_with_token(
        self, mock_load: MagicMock
    ) -> None:
        mock_load.return_value = ReleaseConfig(packages=[])
        with pytest.raises(SystemExit):
            await release_tag_command(provider="github")

    def test_release_schema_command(self, tmp_path: Path) -> None:
        # Test stdout
        release_schema_command()

        # Test file output
        out_file = tmp_path / "schema.json"
        release_schema_command(output=str(out_file))
        assert out_file.exists()
        assert "ReleaseConfig" in out_file.read_text()
