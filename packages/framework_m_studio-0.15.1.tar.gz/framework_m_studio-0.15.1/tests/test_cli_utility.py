"""Tests for CLI Utilities to increase coverage."""

from __future__ import annotations

import sys
from pathlib import Path
from typing import ClassVar
from unittest.mock import MagicMock, patch

from framework_m_studio.cli.utility import (
    _detect_asgi_symbol,
    _find_app,
    check_ipython_installed,
    console_command,
    entrypoints_command,
    routes_command,
)


def test_check_ipython_installed() -> None:
    # Test True
    with patch.dict(sys.modules, {"IPython": MagicMock()}):
        assert check_ipython_installed() is True

    # Test False
    with patch.dict(sys.modules, {"IPython": None}):
        assert check_ipython_installed() is False


def test_console_command() -> None:
    # 1. IPython installed, with container
    with (
        patch(
            "framework_m_studio.cli.utility.check_ipython_installed", return_value=True
        ),
        patch("framework_m_studio.cli.utility.install") as mock_rich_install,
        patch("framework_m_studio.cli.utility.InteractiveShellEmbed") as mock_ipython,
        patch("framework_m_studio.cli.utility.hydrate_apps") as mock_hydrate,
        patch("framework_m_studio.cli.utility.Container"),
    ):
        console_command(with_container=True)
        # Should initialize container, call hydrate, install rich, and start IPython
        mock_rich_install.assert_called_once()
        mock_hydrate.assert_called_once()
        mock_ipython.assert_called_once()

        # Verify m object in namespace
        namespace = mock_ipython.call_args[1]["user_ns"]
        assert "m" in namespace
        assert "container" in namespace

    # 2. IPython missing, no container
    with (
        patch(
            "framework_m_studio.cli.utility.check_ipython_installed", return_value=False
        ),
        patch("framework_m_studio.cli.utility.install"),
        patch("code.interact"),
    ):
        console_command(with_container=False)
        sys.modules["code"].interact.assert_called_once()


def test_repl_context() -> None:
    """Test REPLContext shortcuts."""
    from framework_m_studio.cli.utility import REPLContext

    container = MagicMock()
    ctx = REPLContext(container)

    # Test config access
    mock_config = MagicMock()
    container.config.return_value = mock_config
    assert ctx.config == mock_config

    # Test jobs access
    with patch("framework_m_core.jobs_registry.get_global_registry") as mock_reg:
        assert ctx.jobs == mock_reg()

    # Test DB access (using container.session_factory)
    mock_session_factory = container.session_factory.return_value
    mock_session = MagicMock()
    mock_session_factory.get_session.return_value = mock_session
    assert ctx.db == mock_session
    assert ctx.session == mock_session

    # Test Repository access
    with (
        patch(
            "framework_m_standard.adapters.db.repository_factory.RepositoryFactory"
        ) as mock_repo_factory,
        patch("framework_m_core.registry.MetaRegistry") as mock_meta,
        patch(
            "framework_m_standard.adapters.db.table_registry.TableRegistry"
        ) as mock_table_reg,
    ):
        repo_inst = MagicMock()
        mock_repo_factory.return_value.get_repository.return_value = repo_inst

        # Setup TableRegistry for metadata lookup
        mock_table_reg_inst = mock_table_reg.return_value
        mock_table_reg_inst.list_tables.return_value = ["User"]
        mock_table_reg_inst.get_table.return_value.metadata = MagicMock()

        # Test with string
        assert ctx.repo("User") == repo_inst
        mock_meta.return_value.get_doctype.assert_called_with("User")

        # Test with class
        class MyDoc:
            pass

        assert ctx.repo(MyDoc) == repo_inst

    # Test Metadata access
    from sqlalchemy import MetaData

    with patch(
        "framework_m_standard.adapters.db.table_registry.TableRegistry"
    ) as mock_table_reg:
        mock_md = MagicMock(spec=MetaData)
        mock_table_reg.return_value.list_tables.return_value = ["User"]
        mock_table_reg.return_value.get_table.return_value.metadata = mock_md
        assert ctx.metadata == mock_md

    assert "REPL Context" in repr(ctx)


def test_repl_context_errors() -> None:
    """Test REPLContext error handling."""
    from framework_m_studio.cli.utility import REPLContext

    container = MagicMock()
    ctx = REPLContext(container)

    # 1. DB Error
    container.session_factory.side_effect = Exception("DB Fail")
    assert "Error" in ctx.db

    # 2. Config Error
    container.config.side_effect = Exception("Config Fail")
    assert "Error" in ctx.config

    # 3. Repo Error
    # Reset side effect for next test
    container.config.side_effect = None
    with patch(
        "framework_m_standard.adapters.db.repository_factory.RepositoryFactory",
        side_effect=Exception("Repo Fail"),
    ):
        assert "Error" in ctx.repo("User")

    # 4. Metadata Error
    with patch(
        "framework_m_standard.adapters.db.table_registry.TableRegistry"
    ) as mock_table_reg:
        mock_table_reg.return_value.list_tables.side_effect = Exception("Metadata Fail")
        assert "Error" in ctx.metadata


def test_detect_asgi_symbol(tmp_path: Path) -> None:
    app_py = tmp_path / "app.py"

    # syntax err
    app_py.write_text("def class")
    assert _detect_asgi_symbol(app_py) is None

    # top level assign
    app_py.write_text("app = 1")
    assert _detect_asgi_symbol(app_py) == "app"

    # annotated assign
    app_py.write_text("app: int = 1")
    assert _detect_asgi_symbol(app_py) == "app"

    # def create_app
    app_py.write_text("def create_app(): pass")
    assert _detect_asgi_symbol(app_py) == "create_app"


def test_find_app(tmp_path: Path) -> None:
    with patch("pathlib.Path.cwd", return_value=tmp_path):
        # 1. Explicit app overrides all
        assert _find_app("my_app:app") == "my_app:app"

        # 2. Fallback when nothing exists
        assert "framework_m_standard" in _find_app()

        # 3. Exists dynamically
        app_dir = tmp_path / "app"
        app_dir.mkdir()
        init_py = app_dir / "__init__.py"
        init_py.write_text("app = 1")

        assert _find_app() == "app:app"


def test_routes_command() -> None:
    def dummy_fn() -> None:
        pass

    class DummyHandler:
        fn = dummy_fn

    class DummyRoute:
        path: ClassVar[str] = "/test"
        methods: ClassVar[set[str]] = {"GET"}
        route_handler: ClassVar[DummyHandler] = DummyHandler()

    class DummyApp:
        routes: ClassVar[list] = [
            DummyRoute(),
            MagicMock(),
        ]  # second mock has no methods/route_handler

    from litestar import Litestar
    # We must patch isinstance to allow DummyApp or we just use Litestar actual mock

    app_mock = MagicMock(spec=Litestar)
    app_mock.routes = [DummyRoute(), MagicMock()]

    with (
        patch("framework_m_studio.cli.utility._find_app", return_value="test_app:app"),
        patch("importlib.import_module") as mock_import,
    ):
        mod_mock = MagicMock()
        mod_mock.app = app_mock
        mock_import.return_value = mod_mock

        # Test valid app
        routes_command()
        mock_import.assert_called_once_with("test_app")

        # Test not litestar app
        mod_mock.app = "not app"
        routes_command()

        # Test exception
        mock_import.side_effect = Exception("failed import")
        routes_command()


def test_entrypoints_command() -> None:
    # Test we can list entrypoints properly resilient to errors
    ep_mock1 = MagicMock()
    ep_mock1.name = "ep1"
    ep_mock1.value = "val1"

    ep_select_mock = MagicMock()
    ep_select_mock.select.return_value = [ep_mock1]

    with patch("importlib.metadata.entry_points", return_value=ep_select_mock):
        entrypoints_command()

    # Test exceptions in select block don't crash
    ep_select_mock.select.side_effect = Exception("group missing")
    with patch("importlib.metadata.entry_points", return_value=ep_select_mock):
        entrypoints_command()
