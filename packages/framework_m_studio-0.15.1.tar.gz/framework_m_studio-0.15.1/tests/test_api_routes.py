"""Tests for Studio API Routes."""

from __future__ import annotations

from collections.abc import Generator
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest
from litestar.status_codes import HTTP_200_OK
from litestar.testing import TestClient


def test_health_check(client: TestClient) -> None:
    """Test health check endpoint."""
    response = client.get("/studio/api/health")
    assert response.status_code == HTTP_200_OK
    assert response.json() == {"status": "ok", "service": "framework-m-studio"}


def test_studio_root_redirect(client: TestClient) -> None:
    """Test /studio redirects to /studio/ui/."""
    # TestClient follows redirects by default? default is True in requests, usually False in starlette/litestar
    # Litestar TestClient is based on httpx.
    response = client.get("/studio", follow_redirects=False)
    # Redirect defaults to 307 in Litestar but might be 302 depending on version/config
    # Test output showed 302
    assert response.status_code in (302, 307)
    assert response.headers["location"] == "/studio/ui/"


@pytest.fixture
def mock_static_assets() -> Generator[None, None, None]:
    """Ensure index.html exists for the duration of the test."""
    # Path to static assets
    static_dir = Path(__file__).parents[1] / "src" / "framework_m_studio" / "static"
    static_dir.mkdir(parents=True, exist_ok=True)
    index_html = static_dir / "index.html"

    created = False
    if not index_html.exists():
        index_html.write_text("<!DOCTYPE html><html><body>Mock Studio UI</body></html>")
        created = True

    yield

    # Cleanup only if we created it
    if created and index_html.exists():
        index_html.unlink()


def test_studio_ui_root(client: TestClient, mock_static_assets: None) -> None:
    """Test /studio/ui/ serves index.html."""
    response = client.get("/studio/ui/")
    assert response.status_code == HTTP_200_OK
    assert "text/html" in response.headers["content-type"]
    assert response.text


def test_serve_spa_404(client: TestClient, tmp_path: Path) -> None:
    """Test serving SPA returns 404 for missing static files when dir exists but no index.html."""
    import framework_m_studio.app as app_module

    with patch.object(app_module, "STATIC_DIR", tmp_path):
        response = client.get("/studio/ui/nonexistent.file")
        assert response.status_code == 404


def test_serve_spa_file(client: TestClient, tmp_path: Path) -> None:
    """Test serving actual static file with correct MIME type."""
    import framework_m_studio.app as app_module

    test_file = tmp_path / "test.js"
    test_file.write_text("console.log('hi');")

    with patch.object(app_module, "STATIC_DIR", tmp_path):
        response = client.get("/studio/ui/test.js")
        assert response.status_code == 200
        assert "javascript" in response.headers.get("content-type", "")


def test_list_field_types(client: TestClient) -> None:
    """Test /studio/api/field-types endpoint."""
    # Mock FieldRegistry first to avoid external dependencies?
    # But adapter is loaded. It should work if framework_m is installed.
    # We might need to mock if database dependencies are strict.
    # Current FieldRegistry is memory-based/hardcoded for standard types in _register_standard_types.

    response = client.get("/studio/api/field-types")
    assert response.status_code == HTTP_200_OK
    data = response.json()
    assert "field_types" in data
    assert len(data["field_types"]) > 0
    # Check for a known type
    types = [t["name"] for t in data["field_types"]]
    assert "str" in types


def test_list_doctypes(client: TestClient) -> None:
    """Test /studio/api/doctypes endpoint."""
    response = client.get("/studio/api/doctypes")
    assert response.status_code == HTTP_200_OK
    data = response.json()
    assert "doctypes" in data
    assert isinstance(data["count"], int)


def test_create_doctype_with_link_field(client: TestClient, tmp_path) -> None:
    """Test creating a DocType with Link field via API."""
    import os
    from pathlib import Path

    # Set working directory to tmp_path for this test
    original_cwd = Path.cwd()
    os.chdir(tmp_path)

    try:
        # Create namespaced directory structure: src/test_app/doctypes/
        app_name = "test_app"
        (tmp_path / "src" / app_name / "doctypes").mkdir(parents=True, exist_ok=True)

        # Create pyproject.toml with app name
        (tmp_path / "pyproject.toml").write_text(f'[project]\nname = "{app_name}"\n')

        # First create a Supplier DocType
        supplier_data = {
            "name": "Supplier",
            "app": app_name,
            "docstring": "Supplier master",
            "fields": [
                {
                    "name": "supplier_name",
                    "type": "str",
                    "required": True,
                    "label": "Supplier Name",
                }
            ],
        }

        response = client.post("/studio/api/doctypes/Supplier", json=supplier_data)
        assert response.status_code in (200, 201)

        # Now create PurchaseOrder with Link to Supplier
        po_data = {
            "name": "PurchaseOrder",
            "app": app_name,
            "docstring": "Purchase Order document",
            "fields": [
                {
                    "name": "supplier",
                    "type": "Link",
                    "required": True,
                    "label": "Supplier",
                    "link_doctype": "Supplier",
                },
                {
                    "name": "total_amount",
                    "type": "float",
                    "required": True,
                    "label": "Total Amount",
                },
            ],
        }

        response = client.post("/studio/api/doctypes/PurchaseOrder", json=po_data)
        assert response.status_code in (200, 201)
        assert "PurchaseOrder" in response.json()["message"]

        # Verify the DocType was created correctly
        response = client.get("/studio/api/doctypes/PurchaseOrder")
        assert response.status_code == HTTP_200_OK

        data = response.json()
        assert data["name"] == "PurchaseOrder"
        assert len(data["fields"]) == 2

        # Check Link field
        fields_by_name = {f["name"]: f for f in data["fields"]}
        supplier_field = fields_by_name["supplier"]

        assert supplier_field["type"] == "Link"
        assert supplier_field["link_doctype"] == "Supplier"
        assert supplier_field["label"] == "Supplier"
        assert supplier_field["required"] is True

    finally:
        os.chdir(original_cwd)


def test_update_doctype_preserves_link_field(client: TestClient, tmp_path) -> None:
    """Test updating a DocType preserves Link field metadata."""
    import os
    from pathlib import Path

    original_cwd = Path.cwd()
    os.chdir(tmp_path)

    try:
        # Create namespaced directory structure: src/test_app/doctypes/
        app_name = "test_app"
        (tmp_path / "src" / app_name / "doctypes").mkdir(parents=True, exist_ok=True)

        # Create pyproject.toml with app name
        (tmp_path / "pyproject.toml").write_text(f'[project]\nname = "{app_name}"\n')

        # Create Supplier first
        supplier_data = {
            "name": "Supplier",
            "app": app_name,
            "fields": [{"name": "name", "type": "str", "required": True}],
        }
        client.post("/studio/api/doctypes/Supplier", json=supplier_data)

        # Create Invoice with Link field
        initial_data = {
            "name": "Invoice",
            "app": app_name,
            "fields": [
                {
                    "name": "supplier",
                    "type": "Link",
                    "required": True,
                    "link_doctype": "Supplier",
                }
            ],
        }

        response = client.post("/studio/api/doctypes/Invoice", json=initial_data)
        assert response.status_code in (200, 201)

        # Update Invoice to add another field
        updated_data = {
            "name": "Invoice",
            "app": app_name,
            "fields": [
                {
                    "name": "supplier",
                    "type": "Link",
                    "required": True,
                    "link_doctype": "Supplier",
                },
                {"name": "invoice_number", "type": "str", "required": True},
            ],
        }

        response = client.post("/studio/api/doctypes/Invoice", json=updated_data)
        assert response.status_code in (200, 201)

        # Verify Link field is preserved
        response = client.get("/studio/api/doctypes/Invoice")
        assert response.status_code == HTTP_200_OK

        data = response.json()
        fields_by_name = {f["name"]: f for f in data["fields"]}

        supplier_field = fields_by_name["supplier"]
        assert supplier_field["type"] == "Link"
        assert supplier_field["link_doctype"] == "Supplier"

    finally:
        os.chdir(original_cwd)


class TestRoutesCoverage:
    """Additional tests for routes.py coverage."""

    def test_get_project_root_detection(self, tmp_path: Path) -> None:
        """Test various project root detection scenarios."""
        # Scenario 1: src/doctypes
        (tmp_path / "src" / "doctypes").mkdir(parents=True)
        with patch("pathlib.Path.cwd", return_value=tmp_path):
            from framework_m_studio.services.workspace import get_project_root

            assert get_project_root() == tmp_path

        # Scenario 2: doctypes
        (tmp_path / "doctypes").mkdir()
        with patch("pathlib.Path.cwd", return_value=tmp_path):
            assert get_project_root() == tmp_path

        # Scenario 3: pyproject.toml
        (tmp_path / "pyproject.toml").touch()
        with patch("pathlib.Path.cwd", return_value=tmp_path):
            assert get_project_root() == tmp_path

    def test_get_doctype_with_partial_validators(self, client: TestClient) -> None:
        """Test get_doctype with some None validator values."""
        from framework_m_studio.discovery import DocTypeInfo, FieldInfo

        mock_field = FieldInfo(
            name="test",
            type="str",
            required=True,
            validators={"min_length": 10, "max_length": None},
        )
        mock_doctype = DocTypeInfo(
            name="TestDoc",
            module="test",
            file_path="/test.py",
            fields=[mock_field],
            meta={},
        )
        with patch(
            "framework_m_studio.routers.doctypes.scan_doctypes",
            return_value=[mock_doctype],
        ):
            response = client.get("/studio/api/doctypes/TestDoc")
            assert response.status_code == 200
            data = response.json()
            assert data["fields"][0]["validators"] == {"min_length": 10}

    def test_create_or_update_detects_app_name(
        self, client: TestClient, tmp_path: Path
    ) -> None:
        """Test that create/update can detect app name from pyproject.toml."""
        from framework_m_studio.codegen.generator import generate_doctype_source

        with (
            patch(
                "framework_m_studio.services.workspace.get_project_root",
                return_value=tmp_path,
            ),
            patch(
                "framework_m_studio.codegen.generator.generate_doctype_source",
                wraps=generate_doctype_source,
            ),
        ):
            (tmp_path / "pyproject.toml").write_text('name = "my_test_app"')
            (tmp_path / "src" / "my_test_app" / "doctypes").mkdir(parents=True)

            payload = {"name": "NewDoc", "fields": []}
            response = client.post("/studio/api/doctypes/NewDoc", json=payload)
            assert response.status_code in (200, 201)


def test_print_layout_workflow_endpoints(client: TestClient, tmp_path: Path) -> None:
    """Print builder endpoints should save/list/preview templates."""
    with patch(
        "framework_m_studio.services.workspace.get_project_root", return_value=tmp_path
    ):
        save_response = client.post(
            "/studio/api/print/layout/Invoice/standard",
            json={"content": "<h1>{{ doc.customer }}</h1>"},
        )
        assert save_response.status_code == 201

        list_response = client.get("/studio/api/print/layouts/Invoice")
        assert list_response.status_code == 200
        assert "standard" in list_response.json()["layouts"]

        preview_response = client.post(
            "/studio/api/print/preview",
            json={
                "doctype": "Invoice",
                "template_name": "standard",
                "data": {"customer": "Acme"},
            },
        )
        assert preview_response.status_code == 201
        payload = preview_response.json()
        assert payload["success"] is True
        assert "Acme" in payload["html"]

        # Test missing template branch (404)
        missing_response = client.get("/studio/api/print/layout/Invoice/does_not_exist")
        assert missing_response.status_code == 404

        # Test valid template branch (200)
        assert (
            client.get("/studio/api/print/layout/Invoice/standard").status_code == 200
        )


def test_print_hot_swap_status_and_sync(client: TestClient, tmp_path: Path) -> None:
    """Hot-swap endpoints should expose monitor status and update events."""
    with patch(
        "framework_m_studio.services.workspace.get_project_root", return_value=tmp_path
    ):
        status_before = client.get("/studio/api/print/hotswap/status")
        assert status_before.status_code == 200
        before_payload = status_before.json()
        before_updates = before_payload["updates_received"]
        assert before_payload["watching"] is True

        sync_response = client.post("/studio/api/print/hotswap/sync")
        assert sync_response.status_code == 201

        status_after = client.get("/studio/api/print/hotswap/status")
        assert status_after.status_code == 200
        after_payload = status_after.json()
        assert after_payload["updates_received"] >= before_updates + 1


def test_create_doctype_rename_folder(client: TestClient, tmp_path: Path) -> None:
    """Test renaming a folder-based DocType."""
    from framework_m_studio.discovery import DocTypeInfo

    old_folder = tmp_path / "src" / "doctypes" / "old_doc"
    old_folder.mkdir(parents=True)
    (old_folder / "doctype.py").touch()

    mock_doctype = DocTypeInfo(
        name="OldDoc", module="old_doc", file_path=str(old_folder / "doctype.py")
    )

    with (
        patch(
            "framework_m_studio.services.workspace.get_project_root",
            return_value=tmp_path,
        ),
        patch(
            "framework_m_studio.services.doctype.scan_doctypes",
            return_value=[mock_doctype],
        ),
        patch(
            "framework_m_studio.services.doctype.generate_doctype_code", return_value=""
        ),
        patch(
            "framework_m_studio.codegen.generator.generate_controller_source",
            return_value="",
        ),
        patch(
            "framework_m_studio.codegen.generator.generate_init_source", return_value=""
        ),
        patch(
            "framework_m_studio.codegen.generator.generate_test_source", return_value=""
        ),
    ):
        payload = {"name": "NewDoc", "fields": []}
        response = client.post("/studio/api/doctypes/OldDoc", json=payload)
        assert response.status_code in (200, 201)
        assert not old_folder.exists()  # Old folder should be deleted
        assert (
            tmp_path / "src" / "doctypes" / "new_doc"
        ).exists()  # New folder created


def test_delete_doctype_folder(client: TestClient, tmp_path: Path) -> None:
    """Test deleting a folder-based DocType."""
    from framework_m_studio.discovery import DocTypeInfo

    folder = tmp_path / "src" / "doctypes" / "my_doc"
    folder.mkdir(parents=True)
    (folder / "doctype.py").touch()

    mock_doctype = DocTypeInfo(
        name="MyDoc", module="my_doc", file_path=str(folder / "doctype.py")
    )

    with (
        patch(
            "framework_m_studio.services.workspace.get_project_root",
            return_value=tmp_path,
        ),
        patch(
            "framework_m_studio.routers.doctypes.scan_doctypes",
            return_value=[mock_doctype],
        ),
    ):
        response = client.delete("/studio/api/doctypes/MyDoc")
        assert response.status_code == 200
        assert not folder.exists()


def test_list_field_types_fallback(client: TestClient) -> None:
    """Test fallback when framework_m_standard is missing."""
    with patch.dict(
        "sys.modules", {"framework_m_standard.adapters.db.field_registry": None}
    ):
        response = client.get("/studio/api/field-types")
        assert response.status_code == 200
        data = response.json()
        assert any(f["name"] == "str" for f in data["field_types"])


def test_delete_doctype_flat_file(client: TestClient, tmp_path: Path) -> None:
    """Test deleting a doctype that is just a single file."""
    from framework_m_studio.discovery import DocTypeInfo

    with patch(
        "framework_m_studio.services.workspace.get_project_root", return_value=tmp_path
    ):
        doc_file = tmp_path / "flat_doc.py"
        doc_file.touch()
        mock_doctype = DocTypeInfo(
            name="FlatDoc", module="flat_doc", file_path=str(doc_file)
        )
        with patch(
            "framework_m_studio.routers.doctypes.scan_doctypes",
            return_value=[mock_doctype],
        ):
            response = client.delete("/studio/api/doctypes/FlatDoc")
            assert response.status_code == 200


def test_serve_spa_no_static_dir(client: TestClient, tmp_path: Path) -> None:
    """Test serving SPA when STATIC_DIR does not exist (returns fallback HTML)."""
    import framework_m_studio.app as app_module

    with patch.object(app_module, "STATIC_DIR", tmp_path / "missing"):
        response = client.get("/studio/ui/something")
        assert response.status_code == 200
        assert "text/html" in response.headers["content-type"]
        assert "Studio UI Not Built" in response.text


def test_serve_spa_fallback_to_index(client: TestClient, tmp_path: Path) -> None:
    """Test serving SPA fallback to index.html when specific file is missing."""
    import framework_m_studio.app as app_module

    index_file = tmp_path / "index.html"
    index_file.write_text("<!DOCTYPE html><html><body>Index Fallback</body></html>")

    with patch.object(app_module, "STATIC_DIR", tmp_path):
        response = client.get("/studio/ui/nonexistent-route")
        assert response.status_code == 200
        assert "text/html" in response.headers["content-type"]
        assert "Index Fallback" in response.text


def test_serve_favicon_missing(client: TestClient, tmp_path: Path) -> None:
    """Test serving favicon when it does not exist."""
    import framework_m_studio.app as app_module

    with patch.object(app_module, "STATIC_DIR", tmp_path / "missing"):
        response = client.get("/favicon.ico")
        assert response.status_code == 200
        assert response.json() == {"error": "Favicon not found"}


@patch("framework_m_studio.app.Path.exists", return_value=True)
@patch("framework_m_studio.app.Path.glob")
@patch("importlib.metadata.entry_points")
@patch("importlib.util.find_spec")
@patch("framework_m_studio.data_elements.DataElementRegistry.from_json")
def test_list_field_types_full_discovery(
    mock_from_json: MagicMock,
    mock_find_spec: MagicMock,
    mock_eps: MagicMock,
    mock_glob: MagicMock,
    mock_exists: MagicMock,
    client: TestClient,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Test full discovery of blueprints from studio, apps, and project root."""
    monkeypatch.setenv("INSTALLED_APPS", "explicit_app")

    mock_ep = MagicMock()
    mock_ep.module = "plugin_app:main"
    mock_eps.return_value = [mock_ep]

    mock_spec = MagicMock()
    mock_spec.origin = "/fake/path/app.py"
    mock_find_spec.return_value = mock_spec

    mock_path = MagicMock()
    mock_glob.return_value = [mock_path]

    from types import SimpleNamespace

    elem = SimpleNamespace(
        id="mock_bp",
        fieldtype="str",
        label="Mock BP",
        domain="test",
        validation="^[a-z]+$",
        length=50,
    )
    mock_from_json.return_value = SimpleNamespace(elements={"mock_bp": elem}, _links={})

    response = client.get("/studio/api/field-types")
    assert response.status_code == 200
    types = response.json()["field_types"]

    assert any(t["name"] == "mock_bp" for t in types)

    # Verify validation mapping extraction logic
    bp_field = next(t for t in types if t["name"] == "mock_bp")
    assert bp_field["validators"] == {"pattern": "^[a-z]+$", "max_length": 50}


def test_get_roles(client: TestClient, tmp_path: Path) -> None:
    """Test /studio/api/roles endpoint."""
    from framework_m_studio.core.discovery.roles import RoleDef

    mock_role = RoleDef(name="Admin", description="Administrator Role")

    with (
        patch(
            "framework_m_studio.services.workspace.get_project_root",
            return_value=tmp_path,
        ),
        patch(
            "framework_m_studio.routers.roles.discover_roles", return_value=[mock_role]
        ),
    ):
        response = client.get("/studio/api/roles")
        assert response.status_code == 200
        data = response.json()
        assert "roles" in data
        assert len(data["roles"]) == 1
        assert data["roles"][0]["name"] == "Admin"
        assert data["roles"][0]["description"] == "Administrator Role"


def test_workspace_edge_cases(tmp_path: Path) -> None:
    """Test edge cases in workspace detection logic."""
    from framework_m_studio.services.workspace import (
        detect_app_name,
        get_studio_state_dir,
        resolve_doctype_target_dir,
    )

    # Test state dir creation
    with patch(
        "framework_m_studio.services.workspace.get_project_root", return_value=tmp_path
    ):
        state_dir = get_studio_state_dir()
        assert state_dir == tmp_path / ".studio"
        assert state_dir.exists()

    # Test app detection failures
    assert detect_app_name(tmp_path, None) is None
    pyproject = tmp_path / "pyproject.toml"
    pyproject.write_text("invalid format no name here")
    assert detect_app_name(tmp_path, None) is None

    # Test resolution targets
    assert resolve_doctype_target_dir(tmp_path, None) == tmp_path
    (tmp_path / "src").mkdir()
    assert resolve_doctype_target_dir(tmp_path, None) == tmp_path / "src"


def test_doctype_router_clean_val(client: TestClient) -> None:
    """Test get_doctype cleans null validators from response."""
    from framework_m_studio.discovery import DocTypeInfo, FieldInfo

    mock_field = FieldInfo(name="test", type="str", validators=None)
    mock_doctype = DocTypeInfo(
        name="CleanDoc",
        module="clean",
        file_path="/clean.py",
        fields=[mock_field],
        meta={},
    )

    with (
        patch("framework_m_studio.services.workspace.get_project_root"),
        patch(
            "framework_m_studio.routers.doctypes.scan_doctypes",
            return_value=[mock_doctype],
        ),
    ):
        response = client.get("/studio/api/doctypes/CleanDoc")
        assert response.status_code == 200
