"""Tests for Live Preview Manager.

TDD tests for rendering DocTypes with real data and file watching
for hot-reload notifications.
"""

from __future__ import annotations

from pathlib import Path
from unittest.mock import AsyncMock, MagicMock

import pytest

from framework_m_studio.live_preview import (
    FileChangeEvent,
    LivePreviewManager,
    LivePreviewProtocol,
    PreviewResult,
)


class TestLivePreviewProtocol:
    """Tests that the protocol defines required methods."""

    def test_protocol_has_render(self) -> None:
        assert hasattr(LivePreviewProtocol, "render_preview")

    def test_protocol_has_start_watching(self) -> None:
        assert hasattr(LivePreviewProtocol, "start_watching")

    def test_protocol_has_stop_watching(self) -> None:
        assert hasattr(LivePreviewProtocol, "stop_watching")


class TestPreviewResult:
    """Tests for the PreviewResult dataclass."""

    def test_creation(self) -> None:
        result = PreviewResult(
            doctype="Invoice",
            html="<div>Invoice #001</div>",
            data={"customer": "Acme"},
            success=True,
        )
        assert result.doctype == "Invoice"
        assert result.success is True

    def test_failed_preview(self) -> None:
        result = PreviewResult(
            doctype="Invoice",
            html="",
            data={},
            success=False,
            error="DocType not found",
        )
        assert result.success is False
        assert result.error == "DocType not found"


class TestLivePreviewManager:
    """Tests for the LivePreviewManager."""

    @pytest.fixture
    def mock_renderer(self) -> MagicMock:
        renderer = MagicMock()
        renderer.render = AsyncMock(return_value="<div>Invoice #001</div>")
        return renderer

    @pytest.fixture
    def manager(self, mock_renderer: MagicMock) -> LivePreviewManager:
        return LivePreviewManager(renderer=mock_renderer)

    @pytest.mark.asyncio
    async def test_render_preview(
        self, manager: LivePreviewManager, mock_renderer: MagicMock
    ) -> None:
        """render_preview must render DocType with sample data."""
        result = await manager.render_preview(
            doctype="Invoice",
            data={"customer": "Acme", "total": 100.0},
        )

        assert result.success is True
        assert result.doctype == "Invoice"
        assert result.html == "<div>Invoice #001</div>"
        mock_renderer.render.assert_called_once()

    @pytest.mark.asyncio
    async def test_render_preview_with_error(self, manager: LivePreviewManager) -> None:
        """render_preview must return error result on failure."""
        manager._renderer.render = AsyncMock(side_effect=ValueError("Bad doctype"))

        result = await manager.render_preview(doctype="Invalid", data={})

        assert result.success is False
        assert "Bad doctype" in (result.error or "")

    def test_start_watching(self, manager: LivePreviewManager, tmp_path: Path) -> None:
        """start_watching must register a path for monitoring."""
        manager.start_watching(tmp_path)
        assert tmp_path in manager.watched_paths

    def test_stop_watching(self, manager: LivePreviewManager, tmp_path: Path) -> None:
        """stop_watching must remove the path from monitoring."""
        manager.start_watching(tmp_path)
        manager.stop_watching(tmp_path)
        assert tmp_path not in manager.watched_paths

    def test_stop_watching_unknown_path(self, manager: LivePreviewManager) -> None:
        """stop_watching must not raise for unknown paths."""
        manager.stop_watching(Path("/nonexistent"))  # Should not raise


class TestFileChangeEvent:
    """Tests for the FileChangeEvent dataclass."""

    def test_creation(self) -> None:
        event = FileChangeEvent(
            path=Path("/workspace/doctypes/invoice/doctype.py"),
            event_type="modified",
        )
        assert event.event_type == "modified"

    def test_is_doctype_change(self) -> None:
        """Events for doctype.py files must be marked as DocType changes."""
        event = FileChangeEvent(
            path=Path("/workspace/doctypes/invoice/doctype.py"),
            event_type="modified",
        )
        assert event.is_doctype_change is True

    def test_is_doctype_change_suffix(self) -> None:
        """Events for _doctype.py files must also be marked as DocType changes."""
        event = FileChangeEvent(
            path=Path("/workspace/doctypes/custom_doctype.py"),
            event_type="modified",
        )
        assert event.is_doctype_change is True

    def test_non_doctype_change(self) -> None:
        """Events for non-doctype files must not be marked as DocType changes."""
        event = FileChangeEvent(
            path=Path("/workspace/README.md"),
            event_type="modified",
        )
        assert event.is_doctype_change is False

    def test_callbacks_list(self, tmp_path: Path) -> None:
        """LivePreviewManager must support registering change callbacks."""
        manager = LivePreviewManager(renderer=MagicMock())
        callback = MagicMock()
        manager.on_change(callback)

        assert callback in manager._callbacks

    def test_notify_change_executes_callbacks(self) -> None:
        """notify_change must call all registered callbacks."""
        manager = LivePreviewManager(renderer=MagicMock())
        cb = MagicMock()
        manager.on_change(cb)
        event = FileChangeEvent(path=Path("test.py"), event_type="modified")
        manager.notify_change(event)
        cb.assert_called_once_with(event)
