"""Tests for Data Elements (Field Blueprints).

TDD tests for the DataElement model, DataElementRegistry loader,
blueprint inheritance tracking, and breaking change detection.
"""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from framework_m_studio.data_elements import (
    DataElement,
    DataElementRegistry,
    detect_breaking_changes,
)


class TestDataElement:
    """Tests for the DataElement Pydantic model."""

    def test_create_minimal(self) -> None:
        """DataElement must require at least id and fieldtype."""
        elem = DataElement(id="VAT_ID", fieldtype="Data")

        assert elem.id == "VAT_ID"
        assert elem.fieldtype == "Data"
        assert elem.label == "VAT_ID"  # defaults to id
        assert elem.length is None
        assert elem.validation is None

    def test_create_full(self) -> None:
        """DataElement must accept all fields."""
        elem = DataElement(
            id="Currency",
            fieldtype="Currency",
            label="Transaction Currency",
            length=3,
            validation=r"^[A-Z]{3}$",
            description="ISO 4217 currency code",
        )

        assert elem.id == "Currency"
        assert elem.fieldtype == "Currency"
        assert elem.label == "Transaction Currency"
        assert elem.length == 3
        assert elem.validation == r"^[A-Z]{3}$"
        assert elem.description == "ISO 4217 currency code"

    def test_serialization_roundtrip(self) -> None:
        """DataElement must serialize to/from dict cleanly."""
        elem = DataElement(
            id="VAT_ID",
            fieldtype="Data",
            label="VAT Number",
            length=20,
        )
        data = elem.model_dump()
        restored = DataElement(**data)
        assert restored == elem


class TestDataElementRegistry:
    """Tests for the DataElementRegistry (JSON loader)."""

    @pytest.fixture
    def sample_json(self, tmp_path: Path) -> Path:
        """Create a sample blueprints JSON file."""
        elements = [
            {"id": "VAT_ID", "fieldtype": "Data", "label": "VAT Number", "length": 20},
            {
                "id": "Currency",
                "fieldtype": "Currency",
                "label": "Transaction Currency",
                "length": 3,
                "validation": r"^[A-Z]{3}$",
            },
            {"id": "Email", "fieldtype": "Data", "label": "Email Address"},
        ]
        path = tmp_path / "blueprints.json"
        path.write_text(json.dumps({"elements": elements}))
        return path

    def test_load_from_json(self, sample_json: Path) -> None:
        """Registry must load all elements from a JSON file."""
        registry = DataElementRegistry.from_json(sample_json)

        assert len(registry.elements) == 3
        assert "VAT_ID" in registry.elements
        assert "Currency" in registry.elements
        assert "Email" in registry.elements

    def test_get_element(self, sample_json: Path) -> None:
        """get() must return a DataElement by id."""
        registry = DataElementRegistry.from_json(sample_json)
        elem = registry.get("VAT_ID")

        assert elem is not None
        assert elem.label == "VAT Number"
        assert elem.length == 20

    def test_get_unknown_returns_none(self, sample_json: Path) -> None:
        """get() must return None for unknown element ids."""
        registry = DataElementRegistry.from_json(sample_json)
        assert registry.get("NONEXISTENT") is None

    def test_list_ids(self, sample_json: Path) -> None:
        """list_ids() must return all registered element ids."""
        registry = DataElementRegistry.from_json(sample_json)
        ids = registry.list_ids()

        assert set(ids) == {"VAT_ID", "Currency", "Email"}

    def test_empty_file(self, tmp_path: Path) -> None:
        """Registry must handle empty elements list gracefully."""
        path = tmp_path / "empty.json"
        path.write_text(json.dumps({"elements": []}))
        registry = DataElementRegistry.from_json(path)
        assert len(registry.elements) == 0

    def test_register_element(self, sample_json: Path) -> None:
        """register() must add a new element at runtime."""
        registry = DataElementRegistry.from_json(sample_json)
        new_elem = DataElement(
            id="Phone", fieldtype="Data", label="Phone Number", length=15
        )
        registry.register(new_elem)

        assert registry.get("Phone") is not None
        assert len(registry.elements) == 4


class TestBlueprintLinking:
    """Tests for linking DocType fields to blueprints."""

    @pytest.fixture
    def registry(self, tmp_path: Path) -> DataElementRegistry:
        elements = [
            {"id": "VAT_ID", "fieldtype": "Data", "label": "VAT Number", "length": 20},
        ]
        path = tmp_path / "bp.json"
        path.write_text(json.dumps({"elements": elements}))
        return DataElementRegistry.from_json(path)

    def test_link_field_to_blueprint(self, registry: DataElementRegistry) -> None:
        """link() must track which DocType fields use a blueprint."""
        registry.link("Invoice", "vat_number", "VAT_ID")

        linked = registry.get_linked_fields("VAT_ID")
        assert len(linked) == 1
        assert linked[0] == ("Invoice", "vat_number")

    def test_link_multiple_doctypes(self, registry: DataElementRegistry) -> None:
        """Multiple DocType fields can link to the same blueprint."""
        registry.link("Invoice", "vat_number", "VAT_ID")
        registry.link("Customer", "tax_id", "VAT_ID")

        linked = registry.get_linked_fields("VAT_ID")
        assert len(linked) == 2

    def test_get_linked_unknown_blueprint(self, registry: DataElementRegistry) -> None:
        """get_linked_fields must return empty list for unknown blueprint."""
        assert registry.get_linked_fields("UNKNOWN") == []


class TestBreakingChangeDetection:
    """Tests for detecting breaking changes when a blueprint is updated."""

    def test_no_change(self) -> None:
        """Identical elements must produce no breaking changes."""
        old = DataElement(id="VAT_ID", fieldtype="Data", length=20)
        new = DataElement(id="VAT_ID", fieldtype="Data", length=20)

        changes = detect_breaking_changes(old, new)
        assert len(changes) == 0

    def test_length_reduction(self) -> None:
        """Reducing field length must be flagged as DANGEROUS."""
        old = DataElement(id="VAT_ID", fieldtype="Data", length=20)
        new = DataElement(id="VAT_ID", fieldtype="Data", length=10)

        changes = detect_breaking_changes(old, new)
        assert len(changes) == 1
        assert changes[0].severity == "DANGEROUS"
        assert "length" in changes[0].description.lower()

    def test_fieldtype_change(self) -> None:
        """Changing fieldtype must be flagged as DANGEROUS."""
        old = DataElement(id="VAT_ID", fieldtype="Data")
        new = DataElement(id="VAT_ID", fieldtype="Int")

        changes = detect_breaking_changes(old, new)
        assert len(changes) == 1
        assert changes[0].severity == "DANGEROUS"

    def test_label_change_is_safe(self) -> None:
        """Changing only the label must be flagged as SAFE."""
        old = DataElement(id="VAT_ID", fieldtype="Data", label="VAT ID")
        new = DataElement(id="VAT_ID", fieldtype="Data", label="Tax ID Number")

        changes = detect_breaking_changes(old, new)
        assert len(changes) == 1
        assert changes[0].severity == "SAFE"

    def test_length_increase_is_safe(self) -> None:
        """Increasing field length must be SAFE."""
        old = DataElement(id="VAT_ID", fieldtype="Data", length=10)
        new = DataElement(id="VAT_ID", fieldtype="Data", length=20)

        changes = detect_breaking_changes(old, new)
        assert len(changes) == 1
        assert changes[0].severity == "SAFE"

    def test_validation_change_is_warning(self) -> None:
        """Changing validation pattern must be WARNING."""
        old = DataElement(id="VAT_ID", fieldtype="Data", validation=r"^[A-Z]+$")
        new = DataElement(id="VAT_ID", fieldtype="Data", validation=r"^[A-Z0-9]+$")

        changes = detect_breaking_changes(old, new)
        assert len(changes) == 1
        assert changes[0].severity == "WARNING"
