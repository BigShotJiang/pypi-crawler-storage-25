"""Tests for lockfile synchronization."""

from pathlib import Path
from unittest.mock import patch

import pytest

from framework_m_studio.cli.release.lockfile_sync import sync_lockfiles


def test_sync_lockfiles_pnpm_success(tmp_path: Path) -> None:
    (tmp_path / "pnpm-lock.yaml").touch()

    with (
        patch("shutil.which", return_value="/bin/pnpm") as mock_which,
        patch("framework_m_studio.cli.release.lockfile_sync.run_cmd") as mock_run,
    ):
        sync_lockfiles(tmp_path)
        mock_which.assert_called_with("pnpm")
        mock_run.assert_called_once()
        assert "install" in mock_run.call_args[0][0]


def test_sync_lockfiles_pnpm_missing(tmp_path: Path) -> None:
    (tmp_path / "pnpm-lock.yaml").touch()

    with (
        patch("shutil.which", return_value=None),
        pytest.raises(
            RuntimeError, match=r"pnpm-lock\.yaml exists but 'pnpm' tool was not found"
        ),
    ):
        sync_lockfiles(tmp_path)


def test_sync_lockfiles_pnpm_fails(tmp_path: Path) -> None:
    (tmp_path / "pnpm-lock.yaml").touch()

    with (
        patch("shutil.which", return_value="/bin/pnpm"),
        patch(
            "framework_m_studio.cli.release.lockfile_sync.run_cmd",
            side_effect=Exception("Failed"),
        ),
        pytest.raises(Exception, match="Failed"),
    ):
        sync_lockfiles(tmp_path)


def test_sync_lockfiles_uv_success(tmp_path: Path) -> None:
    (tmp_path / "uv.lock").touch()

    with (
        patch("shutil.which", return_value="/bin/uv") as mock_which,
        patch("framework_m_studio.cli.release.lockfile_sync.run_cmd") as mock_run,
    ):
        sync_lockfiles(tmp_path)
        mock_which.assert_called_with("uv")
        mock_run.assert_called_once()
        assert "lock" in mock_run.call_args[0][0]


def test_sync_lockfiles_uv_missing_with_lock(tmp_path: Path) -> None:
    (tmp_path / "uv.lock").touch()

    with (
        patch("shutil.which", return_value=None),
        pytest.raises(
            RuntimeError, match=r"uv\.lock exists but 'uv' tool was not found"
        ),
    ):
        sync_lockfiles(tmp_path)


def test_sync_lockfiles_uv_missing_with_pyproject(tmp_path: Path) -> None:
    (tmp_path / "pyproject.toml").touch()

    with patch("shutil.which", return_value=None):
        sync_lockfiles(tmp_path)  # Should complete silently without raising
