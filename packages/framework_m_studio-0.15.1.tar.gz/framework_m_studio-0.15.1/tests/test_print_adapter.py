"""Tests for Git-Backed Print Layouts (§4.3).

TDD tests for PrintRepoAdapter and HotSwapMonitor.
"""

from __future__ import annotations

from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from framework_m_studio.print_adapter import (
    HotSwapMonitor,
    PrintRepoAdapter,
)


class TestPrintRepoAdapter:
    """Tests for the PrintRepoAdapter."""

    @pytest.fixture
    def mock_git(self) -> MagicMock:
        mock = MagicMock()
        mock.commit = AsyncMock(return_value=MagicMock(sha="abc123"))
        mock.push = AsyncMock()
        return mock

    @pytest.fixture
    def adapter(self, mock_git: MagicMock, tmp_path: Path) -> PrintRepoAdapter:
        return PrintRepoAdapter(
            git_adapter=mock_git,
            print_repo_path=tmp_path,
        )

    @pytest.mark.asyncio
    async def test_save_layout(self, adapter: PrintRepoAdapter, tmp_path: Path) -> None:
        """save_layout() must write template to the Print Repo."""
        await adapter.save_layout(
            doctype="Invoice",
            template_name="standard",
            content="<h1>{{ doc.customer }}</h1>",
        )

        target = tmp_path / "Invoice" / "standard.html"
        assert target.exists()
        assert "{{ doc.customer }}" in target.read_text()

    @pytest.mark.asyncio
    async def test_save_layout_creates_dirs(
        self, adapter: PrintRepoAdapter, tmp_path: Path
    ) -> None:
        """save_layout() must create DocType dirs if needed."""
        await adapter.save_layout("NewDoc", "default", "<p>test</p>")

        assert (tmp_path / "NewDoc" / "default.html").exists()

    @pytest.mark.asyncio
    async def test_list_layouts(
        self, adapter: PrintRepoAdapter, tmp_path: Path
    ) -> None:
        """list_layouts() must return templates for a DocType."""
        dt_dir = tmp_path / "Invoice"
        dt_dir.mkdir()
        (dt_dir / "standard.html").write_text("<h1>Invoice</h1>")
        (dt_dir / "compact.html").write_text("<p>Compact</p>")

        layouts = adapter.list_layouts("Invoice")
        assert set(layouts) == {"standard", "compact"}

    @pytest.mark.asyncio
    async def test_list_layouts_empty(self, adapter: PrintRepoAdapter) -> None:
        """list_layouts() must return empty for unknown DocType."""
        assert adapter.list_layouts("Unknown") == []

    @pytest.mark.asyncio
    async def test_preview_with_sample(
        self, adapter: PrintRepoAdapter, tmp_path: Path
    ) -> None:
        """preview_with_sample() must render Jinja2 template with data."""
        dt_dir = tmp_path / "Invoice"
        dt_dir.mkdir()
        (dt_dir / "standard.html").write_text(
            "<h1>{{ doc.customer }}</h1><p>Total: {{ doc.total }}</p>"
        )

        result = await adapter.preview_with_sample(
            doctype="Invoice",
            template_name="standard",
            data={"customer": "Acme Corp", "total": 99.99},
        )

        assert result.success is True
        assert "Acme Corp" in result.html
        assert "99.99" in result.html

    @pytest.mark.asyncio
    async def test_preview_missing_template(self, adapter: PrintRepoAdapter) -> None:
        """preview_with_sample() must return error for missing template."""
        result = await adapter.preview_with_sample(
            doctype="Invoice",
            template_name="nonexistent",
            data={},
        )

        assert result.success is False
        assert result.error is not None

    @pytest.mark.asyncio
    @patch.dict("sys.modules", {"jinja2": None})
    async def test_preview_fallback_no_jinja(
        self, adapter: PrintRepoAdapter, tmp_path: Path
    ) -> None:
        """preview_with_sample() must fallback to string replacement if jinja2 is missing."""
        dt_dir = tmp_path / "Invoice"
        dt_dir.mkdir()
        (dt_dir / "standard.html").write_text("<h1>{{ doc.customer }}</h1>")

        result = await adapter.preview_with_sample(
            doctype="Invoice",
            template_name="standard",
            data={"customer": "Acme Corp"},
        )

        assert result.success is True
        assert "Acme Corp" in result.html

    @pytest.mark.asyncio
    async def test_preview_render_error(
        self, adapter: PrintRepoAdapter, tmp_path: Path
    ) -> None:
        """preview_with_sample() must catch and return rendering errors."""
        dt_dir = tmp_path / "Invoice"
        dt_dir.mkdir()
        (dt_dir / "bad.html").write_text("<h1>{% invalid jinja %}</h1>")

        result = await adapter.preview_with_sample("Invoice", "bad", {})
        assert result.success is False
        assert "Render error" in str(result.error)


class TestHotSwapMonitor:
    """Tests for the HotSwapMonitor."""

    def test_creation(self, tmp_path: Path) -> None:
        monitor = HotSwapMonitor(repo_path=tmp_path)
        assert monitor.repo_path == tmp_path
        assert monitor.is_watching is False

    def test_start_stop(self, tmp_path: Path) -> None:
        """Monitor must track watching state."""
        monitor = HotSwapMonitor(repo_path=tmp_path)
        monitor.start()
        assert monitor.is_watching is True
        monitor.stop()
        assert monitor.is_watching is False

    def test_on_update_callback(self, tmp_path: Path) -> None:
        """Monitor must support registering callbacks."""
        monitor = HotSwapMonitor(repo_path=tmp_path)
        cb = MagicMock()
        monitor.on_update(cb)
        assert cb in monitor._callbacks

    def test_notify_executes_callbacks(self, tmp_path: Path) -> None:
        """notify() must execute all registered callbacks."""
        monitor = HotSwapMonitor(repo_path=tmp_path)
        cb = MagicMock()
        monitor.on_update(cb)
        monitor.notify()
        cb.assert_called_once()
