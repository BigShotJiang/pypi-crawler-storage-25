"""Tests for Visual Designer (§6.1).

TDD tests for FormLayoutDesigner and ChildTableDesigner data models.
"""

from __future__ import annotations

from framework_m_studio.visual_designer import (
    ChildTableDesigner,
    FormLayoutDesigner,
    FormSection,
)


class TestFormLayoutDesigner:
    """Tests for the FormLayoutDesigner."""

    def test_empty_layout(self) -> None:
        """New designer must have empty sections."""
        designer = FormLayoutDesigner(doctype="Invoice")
        assert designer.get_sections() == []

    def test_add_section(self) -> None:
        """add_section() must create a new section."""
        designer = FormLayoutDesigner(doctype="Invoice")
        designer.add_section(FormSection(label="Details", fields=["customer", "date"]))

        sections = designer.get_sections()
        assert len(sections) == 1
        assert sections[0].label == "Details"

    def test_add_multiple_sections(self) -> None:
        """Multiple sections must maintain order."""
        designer = FormLayoutDesigner(doctype="Invoice")
        designer.add_section(FormSection(label="Details", fields=["customer"]))
        designer.add_section(FormSection(label="Items", fields=["items"]))
        designer.add_section(FormSection(label="Totals", fields=["total"]))

        assert len(designer.get_sections()) == 3
        assert designer.get_sections()[2].label == "Totals"

    def test_reorder_fields_in_section(self) -> None:
        """reorder_fields() must rearrange fields in a section."""
        designer = FormLayoutDesigner(doctype="Invoice")
        designer.add_section(
            FormSection(label="Details", fields=["customer", "date", "status"])
        )

        designer.reorder_fields("Details", ["status", "customer", "date"])

        section = designer.get_sections()[0]
        assert section.fields == ["status", "customer", "date"]

    def test_move_section(self) -> None:
        """move_section() must reposition a section by index."""
        designer = FormLayoutDesigner(doctype="Invoice")
        designer.add_section(FormSection(label="A", fields=["a"]))
        designer.add_section(FormSection(label="B", fields=["b"]))
        designer.add_section(FormSection(label="C", fields=["c"]))

        designer.move_section("C", 0)

        labels = [s.label for s in designer.get_sections()]
        assert labels == ["C", "A", "B"]

    def test_remove_section(self) -> None:
        """remove_section() must delete a section."""
        designer = FormLayoutDesigner(doctype="Invoice")
        designer.add_section(FormSection(label="Details", fields=["customer"]))
        designer.remove_section("Details")

        assert designer.get_sections() == []

    def test_to_layout_dict(self) -> None:
        """to_layout_dict() must return a serializable layout dict."""
        designer = FormLayoutDesigner(doctype="Invoice")
        designer.add_section(FormSection(label="Details", fields=["customer", "date"]))

        layout = designer.to_layout_dict()
        assert isinstance(layout, dict)
        assert "sections" in layout
        assert layout["sections"][0]["label"] == "Details"


class TestChildTableDesigner:
    """Tests for the ChildTableDesigner."""

    def test_default_config(self) -> None:
        """Default config must be Grid mode."""
        designer = ChildTableDesigner()
        config = designer.get_config("Invoice", "items")

        assert config.display_mode == "Grid"

    def test_set_display_mode(self) -> None:
        """set_display_mode() must update the display mode."""
        designer = ChildTableDesigner()
        designer.set_display_mode("Invoice", "items", "Card")

        config = designer.get_config("Invoice", "items")
        assert config.display_mode == "Card"

    def test_list_mode(self) -> None:
        """List mode must be supported."""
        designer = ChildTableDesigner()
        designer.set_display_mode("Invoice", "items", "List")

        config = designer.get_config("Invoice", "items")
        assert config.display_mode == "List"

    def test_set_field_visibility(self) -> None:
        """set_field_visibility() must toggle field grid/detail visibility."""
        designer = ChildTableDesigner()
        designer.set_field_visibility(
            "Invoice",
            "items",
            "rate",
            visible_in_grid=True,
            visible_in_detail=False,
        )

        config = designer.get_config("Invoice", "items")
        assert config.field_visibility["rate"]["grid"] is True
        assert config.field_visibility["rate"]["detail"] is False

    def test_multiple_fields_visibility(self) -> None:
        """Multiple fields can have different visibility settings."""
        designer = ChildTableDesigner()
        designer.set_field_visibility(
            "Invoice",
            "items",
            "rate",
            visible_in_grid=True,
            visible_in_detail=True,
        )
        designer.set_field_visibility(
            "Invoice",
            "items",
            "description",
            visible_in_grid=False,
            visible_in_detail=True,
        )

        config = designer.get_config("Invoice", "items")
        assert config.field_visibility["rate"]["grid"] is True
        assert config.field_visibility["description"]["grid"] is False

    def test_independent_doctypes(self) -> None:
        """Configs must be per-DocType per-field."""
        designer = ChildTableDesigner()
        designer.set_display_mode("Invoice", "items", "Card")
        designer.set_display_mode("PurchaseOrder", "items", "List")

        assert designer.get_config("Invoice", "items").display_mode == "Card"
        assert designer.get_config("PurchaseOrder", "items").display_mode == "List"
