"""Tests for Shell Plugin Configurator (§6.3).

TDD tests for global action buttons, sidebar apps, and search providers.
"""

from __future__ import annotations

from pathlib import Path

import pytest

from framework_m_studio.shell_plugin_config import (
    ActionButton,
    SearchProvider,
    ShellPluginConfig,
    SidebarApp,
)


class TestShellPluginConfig:
    """Tests for ShellPluginConfig."""

    @pytest.fixture
    def config(self) -> ShellPluginConfig:
        return ShellPluginConfig()

    def test_empty_config(self, config: ShellPluginConfig) -> None:
        """New config must have no registrations."""
        assert config.get_action_buttons() == []
        assert config.get_sidebar_apps() == []
        assert config.get_search_providers() == []

    def test_register_action_button(self, config: ShellPluginConfig) -> None:
        """register_action_button() must add a global button."""
        config.register_action_button(
            ActionButton(
                id="create_invoice",
                label="New Invoice",
                action="navigate",
                target="/invoice/new",
            )
        )

        buttons = config.get_action_buttons()
        assert len(buttons) == 1
        assert buttons[0].label == "New Invoice"

    def test_register_multiple_buttons(self, config: ShellPluginConfig) -> None:
        """Multiple buttons can be registered."""
        config.register_action_button(
            ActionButton(
                id="btn1",
                label="Button 1",
                action="navigate",
                target="/a",
            )
        )
        config.register_action_button(
            ActionButton(
                id="btn2",
                label="Button 2",
                action="navigate",
                target="/b",
            )
        )

        assert len(config.get_action_buttons()) == 2

    def test_register_sidebar_app(self, config: ShellPluginConfig) -> None:
        """register_sidebar_app() must add a sidebar entry."""
        config.register_sidebar_app(
            SidebarApp(
                id="crm",
                label="CRM",
                icon="users",
                route="/crm",
            )
        )

        apps = config.get_sidebar_apps()
        assert len(apps) == 1
        assert apps[0].label == "CRM"

    def test_register_search_provider(self, config: ShellPluginConfig) -> None:
        """register_search_provider() must add a search provider."""
        config.register_search_provider(
            SearchProvider(
                id="doctype_search",
                label="DocTypes",
                handler="framework_m.search.doctype_handler",
            )
        )

        providers = config.get_search_providers()
        assert len(providers) == 1
        assert providers[0].label == "DocTypes"

    def test_role_scoped_buttons(self, config: ShellPluginConfig) -> None:
        """Action buttons can be scoped to roles."""
        config.register_action_button(
            ActionButton(
                id="admin_btn",
                label="Admin Only",
                action="navigate",
                target="/admin",
                roles=["Administrator"],
            )
        )

        buttons = config.get_action_buttons(role="Administrator")
        assert len(buttons) == 1

        buttons = config.get_action_buttons(role="Guest")
        assert len(buttons) == 0

    def test_role_scoped_all(self, config: ShellPluginConfig) -> None:
        """Buttons without roles must appear for all roles."""
        config.register_action_button(
            ActionButton(
                id="global_btn",
                label="Global",
                action="navigate",
                target="/home",
            )
        )

        buttons = config.get_action_buttons(role="Guest")
        assert len(buttons) == 1

    def test_unregister_button(self, config: ShellPluginConfig) -> None:
        """unregister_action_button() must remove by id."""
        config.register_action_button(
            ActionButton(
                id="btn1",
                label="B1",
                action="navigate",
                target="/a",
            )
        )
        config.unregister_action_button("btn1")

        assert len(config.get_action_buttons()) == 0

    def test_save_and_load(self, config: ShellPluginConfig, tmp_path: Path) -> None:
        """Must round-trip through JSON."""
        config.register_action_button(
            ActionButton(
                id="btn1",
                label="B1",
                action="navigate",
                target="/a",
            )
        )
        config.register_sidebar_app(
            SidebarApp(
                id="crm",
                label="CRM",
                icon="users",
                route="/crm",
            )
        )

        path = tmp_path / "shell.json"
        config.save(path)

        loaded = ShellPluginConfig.load(path)
        assert len(loaded.get_action_buttons()) == 1
        assert len(loaded.get_sidebar_apps()) == 1
