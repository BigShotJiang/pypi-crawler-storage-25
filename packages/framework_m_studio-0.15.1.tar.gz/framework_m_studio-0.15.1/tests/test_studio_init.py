"""Tests for framework_m_studio package initialization."""

import importlib.metadata
from importlib import reload
from unittest.mock import patch

import framework_m_studio


def test_version_fallback() -> None:
    """Test version fallback when PackageNotFoundError is raised."""
    with patch(
        "importlib.metadata.version",
        side_effect=importlib.metadata.PackageNotFoundError,
    ):
        reload(framework_m_studio)
        assert framework_m_studio.__version__ == "0.0.0"

    reload(framework_m_studio)
