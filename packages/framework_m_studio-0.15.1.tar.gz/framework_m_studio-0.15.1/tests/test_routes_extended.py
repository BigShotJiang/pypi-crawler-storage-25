"""Extended tests for API routes to cover missing branches and internal helpers."""

from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest
from litestar.testing import TestClient

from framework_m_studio.aggregate_builder import AggregateRootBuilder, LinkedDocType
from framework_m_studio.services.aggregate import (
    get_aggregate_builder as _get_aggregate_builder,
)
from framework_m_studio.services.aggregate import (
    save_aggregate_builder as _save_aggregate_builder,
)
from framework_m_studio.services.doctype import (
    load_existing_doctype_source as _load_existing_doctype_source,
)
from framework_m_studio.services.publish import (
    build_change_request_url as _build_change_request_url,
)
from framework_m_studio.services.publish import (
    get_remote_origin_url as _get_remote_origin_url,
)
from framework_m_studio.services.publish import (
    normalize_author as _normalize_author,
)
from framework_m_studio.services.shell import (
    get_shell_plugin_config as _get_shell_plugin_config,
)
from framework_m_studio.services.shell import (
    save_shell_plugin_config as _save_shell_plugin_config,
)
from framework_m_studio.services.shell import (
    serialize_action_button as _action_button_to_dict,
)
from framework_m_studio.services.shell import (
    serialize_search_provider as _search_provider_to_dict,
)
from framework_m_studio.services.shell import (
    serialize_sidebar_app as _sidebar_app_to_dict,
)
from framework_m_studio.services.shell import (
    set_shell_plugin_config as _set_shell_plugin_config,
)
from framework_m_studio.shell_plugin_config import (
    ActionButton,
    SearchProvider,
    ShellPluginConfig,
    SidebarApp,
)


class TestRoutesExtendedApi:
    def test_delete_doctype_not_found(self, client: TestClient, tmp_path: Path) -> None:
        with patch(
            "framework_m_studio.services.workspace.get_project_root",
            return_value=tmp_path,
        ):
            response = client.delete("/studio/api/doctype/DoesNotExist")
            assert response.status_code == 404
            assert "not found" in response.json()["detail"].lower()

    def test_guardrail_check_endpoint(self, client: TestClient) -> None:
        payload = {
            "name": "TestDoc",
            "app": "test",
            "fields": [{"name": "f1", "type": "str", "required": True}],
        }
        with patch(
            "framework_m_studio.services.doctype.load_existing_doctype_source",
            return_value="class TestDoc:\n  pass",
        ):
            response = client.post("/studio/api/guardrail/check", json=payload)
            assert response.status_code == 201
            assert "has_dangerous" in response.json()

    def test_publish_changes_guardrail_blocked(self, client: TestClient) -> None:
        payload = {
            "message": "Update test",
            "author": "tester",
            "acknowledged": False,
            "doctype_payload": {
                "name": "TestDoc",
                "fields": [],
            },
        }

        mock_result = MagicMock()
        mock_result.has_dangerous = True
        mock_result.can_publish = False
        mock_result.changes = []

        with (
            patch(
                "framework_m_studio.routers.publish.GuardrailChecker.check",
                return_value=mock_result,
            ),
            patch(
                "framework_m_studio.routers.publish.PublishGuard.allow_publish",
                return_value=False,
            ),
        ):
            response = client.post("/studio/api/publish", json=payload)
            assert response.status_code == 201
            data = response.json()
            assert data["success"] is False
            assert data["blocked"] is True
            assert "Dangerous changes require acknowledgement" in data["error"]

    def test_publish_changes_no_git(self, client: TestClient, tmp_path: Path) -> None:
        payload = {"message": "Update", "author": "tester", "acknowledged": True}

        mock_file_result = MagicMock()
        mock_file_result.success = True
        mock_file_result.adapter_type = "file"

        with (
            patch(
                "framework_m_studio.services.workspace.get_project_root",
                return_value=tmp_path,
            ),
            patch(
                "framework_m_studio.routers.publish.FileAdapter.publish",
                return_value=mock_file_result,
            ),
        ):
            response = client.post("/studio/api/publish", json=payload)
            assert response.status_code == 201
            assert response.json()["adapter_type"] == "file"

    def test_publish_changes_no_remote(
        self, client: TestClient, tmp_path: Path
    ) -> None:
        payload = {"message": "Update", "author": "tester", "acknowledged": True}

        # Make .git exist but no remote
        (tmp_path / ".git").mkdir()

        mock_file_result = MagicMock()
        mock_file_result.success = True
        mock_file_result.adapter_type = "file"

        with (
            patch(
                "framework_m_studio.services.workspace.get_project_root",
                return_value=tmp_path,
            ),
            patch(
                "framework_m_studio.services.publish.get_remote_origin_url",
                return_value=None,
            ),
            patch(
                "framework_m_studio.routers.publish.FileAdapter.publish",
                return_value=mock_file_result,
            ),
        ):
            response = client.post("/studio/api/publish", json=payload)
            assert response.status_code == 201
            assert response.json()["adapter_type"] == "file"
            assert "Git remote not configured" in response.json()["error"]

    @pytest.mark.asyncio
    async def test_publish_changes_git_success(
        self, client: TestClient, tmp_path: Path
    ) -> None:
        payload = {"message": "Update", "author": "tester", "acknowledged": True}
        (tmp_path / ".git").mkdir()

        mock_pub_result = MagicMock()
        mock_pub_result.success = True
        mock_pub_result.adapter_type = "git"
        mock_pub_result.branch = "update-123"
        mock_pub_result.commit_sha = "abc1234"
        mock_pub_result.error = None

        with (
            patch(
                "framework_m_studio.services.workspace.get_project_root",
                return_value=tmp_path,
            ),
            patch(
                "framework_m_studio.services.publish.get_remote_origin_url",
                return_value="git@github.com:org/repo.git",
            ),
            patch(
                "framework_m_studio.routers.publish.GitApiAdapter.publish",
                return_value=mock_pub_result,
            ),
        ):
            response = client.post("/studio/api/publish", json=payload)
            assert response.status_code == 201
            data = response.json()
            assert data["adapter_type"] == "git"
            assert (
                data["change_request_url"]
                == "https://github.com/org/repo/compare/main...update-123?expand=1"
            )


class TestRoutesInternalHelpers:
    def test_get_aggregate_builder(self, tmp_path: Path) -> None:
        with patch(
            "framework_m_studio.services.aggregate.get_config_path",
            return_value=tmp_path / "agg.json",
        ):
            # Empty file / nonexistent
            builder = _get_aggregate_builder()
            assert isinstance(builder, AggregateRootBuilder)

            # Reset global and create a valid file
            import framework_m_studio.services.aggregate

            framework_m_studio.services.aggregate._AGGREGATE_BUILDER = None

            data = {
                "roots": [
                    {
                        "root": "Test",
                        "linked": [
                            {
                                "doctype": "Child",
                                "link_field": "test",
                                "cascade": "none",
                            }
                        ],
                    }
                ]
            }
            (tmp_path / "agg.json").write_text(json.dumps(data))

            builder2 = _get_aggregate_builder()
            assert "Test" in builder2.list_roots()

            # Save it back
            _save_aggregate_builder(builder2)
            assert (tmp_path / "agg.json").exists()

            # Test unknown root branches
            builder3 = AggregateRootBuilder()
            builder3.link("Unknown", LinkedDocType("Child", "f"))
            builder3.unlink("Unknown", "Child")
            assert builder3.get_config("Unknown") is None
            assert builder3.to_dict("Unknown") == {}

    def test_shell_plugin_config_helpers(self, tmp_path: Path) -> None:
        with patch(
            "framework_m_studio.services.shell.get_config_path",
            return_value=tmp_path / "shell.json",
        ):
            import framework_m_studio.services.shell

            framework_m_studio.services.shell._SHELL_PLUGIN_CONFIG = None

            config = _get_shell_plugin_config()
            assert isinstance(config, ShellPluginConfig)

            config.register_action_button(ActionButton("id1", "Lbl", "nav", "/a"))
            _save_shell_plugin_config(config)
            assert (tmp_path / "shell.json").exists()

            framework_m_studio.services.shell._SHELL_PLUGIN_CONFIG = None
            config2 = _get_shell_plugin_config()
            assert len(config2.get_action_buttons()) == 1

            _set_shell_plugin_config(ShellPluginConfig())

    def test_serializers(self) -> None:
        ab = ActionButton("id1", "Lbl", "nav", "/a")
        assert _action_button_to_dict(ab)["id"] == "id1"

        sa = SidebarApp("id2", "Lbl", "icon", "/rt")
        assert _sidebar_app_to_dict(sa)["route"] == "/rt"

        sp = SearchProvider("id3", "Lbl", "h")
        assert _search_provider_to_dict(sp)["handler"] == "h"

    def test_load_existing_doctype_source(self, tmp_path: Path) -> None:
        from framework_m_studio.discovery import DocTypeInfo

        dt = DocTypeInfo("MyDoc", "m", str(tmp_path / "doc.py"))
        (tmp_path / "doc.py").write_text("class MyDoc: pass")

        with (
            patch(
                "framework_m_studio.services.workspace.get_project_root",
                return_value=tmp_path,
            ),
            patch(
                "framework_m_studio.services.doctype.scan_doctypes", return_value=[dt]
            ),
        ):
            src = _load_existing_doctype_source("MyDoc", tmp_path)
            assert "class MyDoc" in src

            src_empty = _load_existing_doctype_source("OtherDoc", tmp_path)
            assert src_empty == ""

    def test_get_remote_origin_url(self) -> None:
        with patch("framework_m_studio.services.publish.subprocess.run") as mock_run:
            mock_res = MagicMock()
            mock_res.returncode = 0
            mock_res.stdout = "https://github.com/a/b.git\n"
            mock_run.return_value = mock_res

            assert _get_remote_origin_url(Path("/fake")) == "https://github.com/a/b.git"

            mock_res.returncode = 1
            assert _get_remote_origin_url(Path("/fake")) is None

    def test_normalize_author(self) -> None:
        assert _normalize_author("John Doe <john@doe.com>") == "John Doe <john@doe.com>"
        assert _normalize_author("John Doe") == "John Doe <john-doe@local>"
        assert _normalize_author("") == " <studio@local>"

    def test_build_change_request_url(self) -> None:
        # github
        url1 = _build_change_request_url("git@github.com:org/repo.git", "feat/1")
        assert url1 == "https://github.com/org/repo/compare/main...feat%2F1?expand=1"

        # gitlab
        url2 = _build_change_request_url("https://gitlab.com/org/repo", "feat/2")
        assert "merge_requests/new" in url2
        assert "merge_request%5Bsource_branch%5D=feat%2F2" in url2

        # unsupported
        url3 = _build_change_request_url("https://bitbucket.org/org/repo", "feat/3")
        assert url3 is None
