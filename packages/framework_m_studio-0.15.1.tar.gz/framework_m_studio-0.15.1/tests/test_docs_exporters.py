"""Tests for Documentation Exporters to increase coverage."""

from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

try:
    import yaml
except ImportError:
    yaml = None

from framework_m_studio.docs.exporters import export_doctypes_yaml, export_rag_corpus


def test_export_rag_corpus(tmp_path: Path) -> None:
    # Setup mock files
    # 1. Mock DocType
    dt_mock = MagicMock()
    dt_mock.__module__ = "test"
    dt_dict = {
        "name": "TestDoc",
        "file_path": "/absolute/out/of/root.py",  # Forces ValueError on relative_to
        "fields": [],
    }

    # 2. Mock docs
    docs_dir = tmp_path / "docs"
    docs_dir.mkdir()
    (docs_dir / "index.md").touch()  # Should be skipped
    (docs_dir / "adr-01.md").write_text("ADR content")
    (docs_dir / "rfc-01.md").write_text("RFC content")
    (docs_dir / "other.md").write_text("Other content")

    checklists_dir = tmp_path / "checklists"
    checklists_dir.mkdir()
    (checklists_dir / "checklist-01.md").write_text("Checklist")

    frontend_docs_dir = tmp_path / "frontend" / "docs"
    frontend_docs_dir.mkdir(parents=True)
    (frontend_docs_dir / "comp.md").write_text("Frontend doc")

    # Add unreadable file to trigger Exception
    unreadable = docs_dir / "unreadable.md"
    unreadable.touch()
    unreadable.chmod(0o000)  # Remove read permissions

    # 3. Mock tests
    tests_dir = tmp_path / "tests"
    tests_dir.mkdir()
    (tests_dir / "test_foo.py").write_text("def test_a(): pass")

    out_file = tmp_path / "out.jsonl"

    with (
        patch(
            "framework_m_studio.docs.exporters.scan_doctypes", return_value=[dt_mock]
        ),
        patch(
            "framework_m_studio.docs.exporters.doctype_to_dict", return_value=dt_dict
        ),
        patch(
            "framework_m_studio.docs.exporters.generate_doctype_markdown",
            return_value="MD",
        ),
    ):
        export_rag_corpus(tmp_path, out_file, include_tests=True)

    # Read output and verify
    lines = out_file.read_text().splitlines()
    assert len(lines) > 0

    parsed = [json.loads(line) for line in lines]
    types = [p["type"] for p in parsed]

    assert "doctype" in types
    assert "adr" in types
    assert "rfc" in types
    assert "checklist" in types
    assert "frontend-doc" in types
    assert "doc" in types
    assert "test" in types

    unreadable.chmod(0o644)  # Restore for cleanup


@pytest.mark.skipif(yaml is None, reason="PyYAML not installed")
def test_export_doctypes_yaml(tmp_path: Path) -> None:
    # Setup mock
    dt_mock = MagicMock()
    dt_dict = {
        "name": "TestDoc",
        "module": "test",
        "docstring": "desc",
        "file_path": "a.py",
        "fields": [],
        "meta": {"permissions": {"read": True}, "hooks": {"before_save": "func"}},
    }

    out_file = tmp_path / "out.yaml"

    with (
        patch(
            "framework_m_studio.docs.exporters.scan_doctypes", return_value=[dt_mock]
        ),
        patch(
            "framework_m_studio.docs.exporters.doctype_to_dict", return_value=dt_dict
        ),
    ):
        export_doctypes_yaml(tmp_path, out_file)

    content = out_file.read_text()
    assert "permissions" in content
    assert "hooks" in content
    assert "TestDoc" in content
