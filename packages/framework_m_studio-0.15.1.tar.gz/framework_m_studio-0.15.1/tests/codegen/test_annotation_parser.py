import libcst as cst

from framework_m_studio.codegen.annotation_parser import (
    extract_annotated_metadata,
    parse_field_call,
)


def parse_expr(code: str) -> cst.BaseExpression:
    return cst.parse_expression(code)


def test_extract_annotated_metadata_union():
    link, table, base = extract_annotated_metadata(
        parse_expr("Annotated[str, Link('User')] | None")
    )
    assert link == "User"
    assert table is None
    assert base == "str"

    link, table, base = extract_annotated_metadata(
        parse_expr("None | Annotated[int, Table('Item')]")
    )
    assert link is None
    assert table == "Item"
    assert base == "int"


def test_extract_annotated_metadata_direct():
    link, table, _base = extract_annotated_metadata(
        parse_expr("Annotated[str, Link('Role')]")
    )
    assert link == "Role"

    link, table, _base = extract_annotated_metadata(
        parse_expr("Annotated[list, Table('Line')]")
    )
    assert table == "Line"

    link, table, _base = extract_annotated_metadata(
        parse_expr("Annotated[str, Other()]")
    )
    assert link is None
    assert table is None


def test_parse_field_call_exhaustive():
    expr = parse_expr(
        "Field('default_val', ge=5.0, le=10, min_length=2, max_length=100, pattern=r'^[a-z]+$', description='desc', label='lbl')"
    )
    default, validators, desc, label = parse_field_call(expr)
    assert default == "'default_val'"
    assert validators["min_value"] == 5.0
    assert validators["max_value"] == 10.0
    assert validators["min_length"] == 2
    assert validators["max_length"] == 100
    assert validators["pattern"] == "^[a-z]+$"
    assert desc == "desc"
    assert label == "lbl"

    expr2 = parse_expr("Field(gt=1.5, lt=2.5, pattern='[0-9]', default='x')")
    default2, val2, _, _ = parse_field_call(expr2)
    assert default2 == "'x'"
    assert val2["min_value"] == 1.5
    assert val2["max_value"] == 2.5
    assert val2["pattern"] == "[0-9]"
