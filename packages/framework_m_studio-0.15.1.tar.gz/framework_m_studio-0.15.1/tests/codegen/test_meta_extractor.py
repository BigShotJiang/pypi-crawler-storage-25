import libcst as cst

from framework_m_studio.codegen.meta_extractor import (
    parse_config_attribute,
    parse_permissions_dict,
    set_config_value,
)


class MockMeta:
    def __init__(self):
        self.tablename = None
        self.verbose_name = None
        self.verbose_name_plural = None
        self.is_submittable = False
        self.is_tree = False
        self.track_changes = False
        self.permissions = None
        self.extra = {}


def test_parse_permissions():
    assert parse_permissions_dict('{"read": "User"}') == {"read": ["User"]}
    assert parse_permissions_dict('{"read": ["User"]}') == {"read": ["User"]}
    assert parse_permissions_dict("invalid") is None


def test_set_config_value():
    meta = MockMeta()
    set_config_value("tablename", "'users'", meta)
    assert meta.tablename == "users"

    set_config_value("is_submittable", "True", meta)
    assert meta.is_submittable is True

    set_config_value("is_tree", "True", meta)
    assert meta.is_tree is True

    set_config_value("track_changes", "False", meta)
    assert meta.track_changes is False

    set_config_value("permissions", '{"read": "All"}', meta)
    assert meta.permissions == {"read": ["All"]}

    set_config_value("custom", "'value'", meta)
    assert meta.extra["custom"] == "value"

    set_config_value("none_val", None, meta)


def test_parse_config_attribute():
    meta = MockMeta()
    stmt = cst.parse_statement("tablename: str = 'test'")
    parse_config_attribute("tablename", stmt.body[0], meta)
    assert meta.tablename == "test"

    stmt2 = cst.parse_statement("is_tree = True")
    parse_config_attribute("is_tree", stmt2.body[0], meta)
    assert meta.is_tree is True
