"""Tests for Studio CLI Commands.

Tests the CLI commands following TDD principles as per CONTRIBUTING.md.
"""

from __future__ import annotations

from pathlib import Path
from unittest.mock import patch

import pytest

from framework_m_studio.cli import codegen_app, docs_app, studio_app


class TestCodegenApp:
    """Tests for codegen_app CLI."""

    def test_codegen_app_exists(self) -> None:
        """Test that codegen_app is defined."""
        assert codegen_app is not None
        assert "codegen" in codegen_app.name

    def test_codegen_client_command(
        self, capsys: pytest.CaptureFixture[str], tmp_path: Path
    ) -> None:
        """Test codegen client command runs with real sdk_generator."""
        from framework_m_studio.cli import codegen_client

        mock_schema = {
            "openapi": "3.1.0",
            "info": {"title": "Test API"},
            "paths": {},
            "components": {"schemas": {}},
        }

        with patch(
            "framework_m_studio.sdk_generator.fetch_openapi_schema",
            return_value=mock_schema,
        ):
            codegen_client(
                lang="ts",
                out=str(tmp_path / "generated"),
                openapi_url="http://localhost:8000/schema/openapi.json",
            )

        captured = capsys.readouterr()
        assert "Generating TS client" in captured.out
        assert (tmp_path / "generated").exists()

    def test_codegen_doctype_command(self, capsys: pytest.CaptureFixture[str]) -> None:
        """Test codegen doctype command runs."""
        from framework_m_studio.cli import codegen_doctype

        codegen_doctype(name="TestDocType", app=None)
        captured = capsys.readouterr()
        assert "Generating DocType: TestDocType" in captured.out

    def test_codegen_client_python_branch(self, tmp_path: Path) -> None:
        """Should skip TypeScript generation if lang is 'py'."""
        from framework_m_studio.cli.codegen import codegen_client

        with patch(
            "framework_m_studio.sdk_generator.fetch_openapi_schema", return_value={}
        ):
            codegen_client(lang="py", out=str(tmp_path), openapi_url="http://test")
            assert not (tmp_path / "types.ts").exists()

    def test_codegen_doctype_app_branch(
        self, capsys: pytest.CaptureFixture[str]
    ) -> None:
        """Should handle optional app parameter gracefully."""
        from framework_m_studio.cli.codegen import codegen_doctype

        codegen_doctype(name="Invoice", app="billing")
        captured = capsys.readouterr()
        assert "Generating DocType: Invoice" in captured.out


class TestDocsApp:
    """Tests for docs_app CLI."""

    def test_docs_app_exists(self) -> None:
        """Test that docs_app is defined."""
        assert docs_app is not None
        assert "docs" in docs_app.name

    def test_docs_generate_command(
        self, capsys: pytest.CaptureFixture[str], tmp_path: Path
    ) -> None:
        """Test docs generate command runs."""
        from framework_m_studio.cli import docs_generate

        output_dir = str(tmp_path / "docs")
        docs_generate(output=output_dir, openapi_url=None)
        captured = capsys.readouterr()
        # Accept either format (with doctypes or fallback)
        assert "documentation" in captured.out.lower() or "docs" in captured.out.lower()

    def test_docs_adr_verify_success(self, capsys: pytest.CaptureFixture[str]) -> None:
        """Test docs adr --verify command success."""
        from framework_m_studio.cli.docs import docs_adr

        with patch(
            "framework_m_studio.cli.quality.verify_doc_numbering", return_value=[]
        ):
            docs_adr(action=None, verify=True)

        captured = capsys.readouterr()
        assert "✅" in captured.out
        assert "passed" in captured.out.lower() or "no issues" in captured.out.lower()

    def test_docs_adr_verify_failure(self, capsys: pytest.CaptureFixture[str]) -> None:
        """Test docs adr --verify command failure."""
        from framework_m_studio.cli.docs import docs_adr

        with patch(
            "framework_m_studio.cli.quality.verify_doc_numbering",
            return_value=["DUPLICATE: 0001 appears twice"],
        ):
            with pytest.raises(SystemExit) as exc:
                docs_adr(action=None, verify=True)
            assert exc.value.code == 1

        captured = capsys.readouterr()
        assert "❌" in captured.err
        assert "DUPLICATE: 0001" in captured.err

    def test_docs_rfc_verify_success(self, capsys: pytest.CaptureFixture[str]) -> None:
        """Test docs rfc --verify command success."""
        from framework_m_studio.cli.docs import docs_rfc

        with patch(
            "framework_m_studio.cli.quality.verify_doc_numbering", return_value=[]
        ):
            docs_rfc(action=None, verify=True)

        captured = capsys.readouterr()
        assert "✅" in captured.out
        assert "passed" in captured.out.lower() or "no issues" in captured.out.lower()

    def test_docs_rfc_verify_failure(self, capsys: pytest.CaptureFixture[str]) -> None:
        """Test docs rfc --verify command failure."""
        from framework_m_studio.cli.docs import docs_rfc

        with patch(
            "framework_m_studio.cli.quality.verify_doc_numbering",
            return_value=["DUPLICATE: 0001 appears twice"],
        ):
            with pytest.raises(SystemExit) as exc:
                docs_rfc(action=None, verify=True)
            assert exc.value.code == 1

        captured = capsys.readouterr()
        assert "❌" in captured.err
        assert "DUPLICATE: 0001" in captured.err


class TestDocsExportCommand:
    """Tests for docs export subcommands."""

    def test_docs_export_corpus_command(self, tmp_path: Path) -> None:
        """Test docs export corpus calls export_rag_corpus."""
        from framework_m_studio.cli.docs import docs_export_corpus

        with patch("framework_m_studio.cli.docs.export_rag_corpus") as mock_export:
            docs_export_corpus(
                output=str(tmp_path / "custom.jsonl"),
                root=str(tmp_path),
                include_tests=False,
            )

            mock_export.assert_called_once()
            args = mock_export.call_args[0]
            assert str(args[0]) == str(tmp_path)
            assert str(args[1]) == str(tmp_path / "custom.jsonl")

    def test_docs_export_doctypes_command(self, tmp_path: Path) -> None:
        """Test docs export doctypes calls export_doctypes_yaml."""
        from framework_m_studio.cli.docs import docs_export_doctypes

        with patch("framework_m_studio.cli.docs.export_doctypes_yaml") as mock_export:
            docs_export_doctypes(
                output=str(tmp_path / "custom.yaml"), root=str(tmp_path)
            )

            mock_export.assert_called_once()
            args = mock_export.call_args[0]
            assert str(args[0]) == str(tmp_path)
            assert str(args[1]) == str(tmp_path / "custom.yaml")

    def test_docs_export_corpus_default_output(self) -> None:
        """Test docs export corpus uses default output when omitted."""
        from framework_m_studio.cli.docs import docs_export_corpus

        with patch("framework_m_studio.cli.docs.export_rag_corpus") as mock_export:
            docs_export_corpus()
            mock_export.assert_called_once()
            assert "corpus.jsonl" in str(mock_export.call_args[0][1])

    def test_docs_export_corpus_include_tests_flag(self) -> None:
        """Test docs export corpus passes include_tests flag."""
        from framework_m_studio.cli.docs import docs_export_corpus

        with patch("framework_m_studio.cli.docs.export_rag_corpus") as mock_export:
            docs_export_corpus(include_tests=True)
            assert mock_export.call_args[1].get("include_tests") is True


class TestStudioApp:
    """Tests for studio_app CLI."""

    def test_studio_app_exists(self) -> None:
        """Test that studio_app is defined."""
        assert studio_app is not None
        assert "studio" in studio_app.name

    def test_studio_serve_prints_banner(
        self, capsys: pytest.CaptureFixture[str]
    ) -> None:
        """Test studio serve prints startup banner before running uvicorn."""
        from framework_m_studio.cli import studio_serve

        # Mock uvicorn.run to prevent actual server startup
        with (
            patch("uvicorn.run") as mock_uvicorn,
            patch("webbrowser.open_new_tab") as mock_open_new_tab,
        ):
            studio_serve(port=9000, host="0.0.0.0", reload=False, cloud=False)  # nosec B104

            captured = capsys.readouterr()
            assert "Starting Framework M Studio" in captured.out
            assert "localhost:9000" in captured.out

            # Verify uvicorn was called with correct args
            mock_uvicorn.assert_called_once_with(
                "framework_m_studio.app:app",
                host="0.0.0.0",  # nosec B104
                port=9000,
                reload=False,
                log_level="info",
            )
            mock_open_new_tab.assert_called_once_with("http://localhost:9000/studio/")

    def test_studio_serve_custom_port(self, capsys: pytest.CaptureFixture[str]) -> None:
        """Test studio serve with custom port."""
        from framework_m_studio.cli import studio_serve

        with patch("uvicorn.run") as mock_uvicorn, patch("webbrowser.open_new_tab"):
            studio_serve(port=8080, host="0.0.0.0", reload=False, cloud=False)  # nosec B104

            mock_uvicorn.assert_called_once()
            call_kwargs = mock_uvicorn.call_args[1]
            assert call_kwargs["port"] == 8080
            assert call_kwargs["host"] == "0.0.0.0"  # nosec B104

    def test_studio_serve_reload_mode(self, capsys: pytest.CaptureFixture[str]) -> None:
        """Test studio serve with reload enabled."""
        from framework_m_studio.cli import studio_serve

        with patch("uvicorn.run") as mock_uvicorn, patch("webbrowser.open_new_tab"):
            studio_serve(port=9000, host="0.0.0.0", reload=True, cloud=False)  # nosec B104

            mock_uvicorn.assert_called_once()
            call_kwargs = mock_uvicorn.call_args[1]
            assert call_kwargs["reload"] is True

    def test_studio_serve_cloud_mode(self, capsys: pytest.CaptureFixture[str]) -> None:
        """Test studio serve with cloud mode enabled."""
        from framework_m_studio.cli import studio_serve

        with (
            patch("uvicorn.run"),
            patch("webbrowser.open_new_tab"),
            patch.dict("os.environ", {}, clear=False),
        ):
            import os

            studio_serve(port=9000, host="0.0.0.0", reload=False, cloud=True)  # nosec B104

            captured = capsys.readouterr()
            assert "Cloud mode enabled" in captured.out
            assert os.environ.get("STUDIO_CLOUD_MODE") == "1"


class TestModuleExports:
    """Tests for module exports."""

    def test_all_exports(self) -> None:
        """Test __all__ exports are correct."""
        from framework_m_studio import cli

        assert hasattr(cli, "__all__")
        assert "codegen_app" in cli.__all__
        assert "docs_app" in cli.__all__
        assert "studio_app" in cli.__all__


class TestDocsCoverage:
    """Additional tests for docs CLI coverage."""

    def test_docs_generate_all_flags(self, tmp_path: Path) -> None:
        """Test docs generate with individual flags."""
        from framework_m_studio.cli.docs import docs_generate

        with (
            patch(
                "framework_m_studio.cli.docs.generate_protocols_doc", return_value=""
            ),
            patch(
                "framework_m_studio.cli.docs.generate_cli_reference", return_value=""
            ),
            patch("framework_m_studio.cli.docs.generate_hooks_doc", return_value=""),
            patch(
                "framework_m_studio.docs.generator.generate_field_types_doc",
                return_value="",
            ),
            patch(
                "framework_m_studio.docs.generator.generate_api_endpoints_doc",
                return_value="",
            ),
            patch("framework_m_studio.cli.docs.run_docs_generate"),
            patch("framework_m_studio.cli.docs._generate_adr_index"),
        ):
            # Test individual flags
            docs_generate(output=str(tmp_path), protocols=True)
            docs_generate(output=str(tmp_path), cli=True)
            docs_generate(output=str(tmp_path), hooks=True)
            docs_generate(output=str(tmp_path), field_types=True)
            docs_generate(output=str(tmp_path), api_endpoints=True)
            docs_generate(output=str(tmp_path), adr=True)
            docs_generate(output=str(tmp_path), rfc=True)
            # Test --core flag
            docs_generate(output=str(tmp_path), core=True)
            # Test --all flag
            docs_generate(output=str(tmp_path), complete=True)

    def test_docs_generate_doctypes_src_path(self, tmp_path: Path) -> None:
        """Test docs generate looks in src/doctypes if present."""
        from framework_m_studio.cli.docs import docs_generate

        src_doctypes = tmp_path / "src" / "doctypes"
        src_doctypes.mkdir(parents=True)

        with (
            patch("framework_m_studio.cli.docs.run_docs_generate") as mock_run,
            patch("framework_m_studio.cli.docs.Path.cwd", return_value=tmp_path),
        ):
            docs_generate(output=str(tmp_path), doctypes=True)
            mock_run.assert_called_once()
            assert "src" in str(mock_run.call_args.kwargs["project_root"])

    def test_docs_openapi_invalid_url(self, capsys: pytest.CaptureFixture[str]) -> None:
        """Test docs openapi with an invalid URL."""
        from framework_m_studio.cli.docs import docs_openapi

        docs_openapi(openapi_url="file:///schema.json")
        captured = capsys.readouterr()
        assert "Invalid OpenAPI URL" in captured.err

    def test_docs_adr_create_no_title(self, capsys: pytest.CaptureFixture[str]) -> None:
        """Test docs adr create without a title."""
        from framework_m_studio.cli.docs import docs_adr

        docs_adr(action="create", title=None)
        captured = capsys.readouterr()
        assert "Title required" in captured.err

    def test_docs_adr_invalid_action(self, capsys: pytest.CaptureFixture[str]) -> None:
        """Test docs adr with an invalid action."""
        from framework_m_studio.cli.docs import docs_adr

        docs_adr(action="invalid")
        captured = capsys.readouterr()
        assert "Unknown action" in captured.err


class TestDocsAdditionalCommands:
    """Tests for additional docs commands."""

    def test_docs_screenshots_missing_manifest(
        self, capsys: pytest.CaptureFixture[str]
    ) -> None:
        """Test docs screenshots when manifest is missing."""
        from framework_m_studio.cli.screenshots import run_screenshots

        run_screenshots(manifest="nonexistent.yaml")
        assert "Manifest file not found" in capsys.readouterr().err

    def test_docs_screenshots_no_screenshots(
        self, tmp_path: Path, capsys: pytest.CaptureFixture[str]
    ) -> None:
        """Test docs screenshots when no screenshots are defined."""
        from framework_m_studio.cli.screenshots import run_screenshots

        manifest = tmp_path / "manifest.yaml"
        manifest.write_text("screenshots: []")

        run_screenshots(manifest=str(manifest))
        assert "No screenshots defined" in capsys.readouterr().err

    def test_docs_screenshots_success(self, tmp_path: Path) -> None:
        """Test docs screenshots success path."""
        from framework_m_studio.cli.screenshots import run_screenshots

        manifest = tmp_path / "manifest.yaml"
        manifest.write_text("screenshots:\n  - id: test\n    url: /\n")

        with patch(
            "framework_m_studio.docs.screenshots.sync_playwright"
        ) as mock_playwright:
            mock_context = mock_playwright.return_value.__enter__.return_value
            mock_browser = mock_context.chromium.launch.return_value
            mock_page = mock_browser.new_context.return_value.new_page.return_value

            run_screenshots(manifest=str(manifest), base_url="http://test")

            mock_page.goto.assert_called_once()
            mock_page.screenshot.assert_called_once()

    def test_docs_screenshots_with_auth_and_failure(
        self, tmp_path: Path, capsys: pytest.CaptureFixture[str]
    ) -> None:
        """Test docs screenshots authentication and failure paths."""
        from framework_m_studio.cli.screenshots import run_screenshots

        manifest = tmp_path / "manifest.yaml"
        manifest.write_text(
            "screenshots:\n  - id: test\n    url: /\n    wait_for: '.test'"
        )

        with patch(
            "framework_m_studio.docs.screenshots.sync_playwright"
        ) as mock_playwright:
            mock_context = mock_playwright.return_value.__enter__.return_value
            mock_browser = mock_context.chromium.launch.return_value
            mock_page = mock_browser.new_context.return_value.new_page.return_value
            # Simulate login redirect
            mock_page.url = "/desk/login"
            # Simulate screenshot failure on the first try, let the failure screenshot succeed
            mock_page.screenshot.side_effect = [Exception("Screenshot failed"), None]

            with pytest.raises(SystemExit):
                run_screenshots(
                    manifest=str(manifest),
                    base_url="http://test",
                    username="admin",
                    password="pwd",
                )

            # Verify authentication was attempted
            mock_page.locator.return_value.fill.assert_called()

    def test_docs_adr_create_and_index(self, tmp_path: Path) -> None:
        """Test ADR creation, templating, and index generation."""
        from framework_m_studio.cli.docs import docs_adr

        adr_dir = tmp_path / "adr"
        template = tmp_path / "template.md"
        template.write_text(
            "# ADR-0000\n[Short Title]\nYYYY-MM-DD\n**Status**: Proposed"
        )

        # Test Create
        docs_adr(action="create", title="Test ADR", adr_dir=adr_dir, template=template)

        created_file = adr_dir / "0001-test-adr.md"
        assert created_file.exists()
        content = created_file.read_text()
        assert "ADR-0001" in content
        assert "Test ADR" in content

        # Test Index
        docs_adr(action="index", adr_dir=adr_dir)
        assert (adr_dir / "index.md").exists()
        assert (adr_dir / "_category_.json").exists()

    def test_docs_rfc_create_and_index(self, tmp_path: Path) -> None:
        """Test RFC creation and index generation without template."""
        from framework_m_studio.cli.docs import docs_rfc

        rfc_dir = tmp_path / "rfc"

        docs_rfc(action="create", title="Test RFC", rfc_dir=rfc_dir)
        assert (rfc_dir / "0001-test-rfc.md").exists()

        docs_rfc(action="index", rfc_dir=rfc_dir)
        assert (rfc_dir / "index.md").exists()

    def test_docs_audit_command(self, capsys: pytest.CaptureFixture[str]) -> None:
        """Test docs audit success."""
        from framework_m_studio.cli.docs import docs_audit

        with patch(
            "framework_m_studio.docs.audit.run_docs_audit", return_value=True
        ) as mock_audit:
            docs_audit()

        mock_audit.assert_called_once()

    def test_docs_audit_command_failure(self) -> None:
        """Test docs audit failure exit code."""
        from framework_m_studio.cli.docs import docs_audit

        with (
            patch("framework_m_studio.docs.audit.run_docs_audit", return_value=False),
            pytest.raises(SystemExit) as exc,
        ):
            docs_audit()
        assert exc.value.code == 1
