"""Tests for DocType Transformer module."""

from __future__ import annotations

from pathlib import Path
from textwrap import dedent

import libcst as cst
import pytest

from framework_m_studio.codegen.transformer import (
    DocTypeTransformer,
    add_field,
    remove_field,
    rename_field,
    update_doctype,
)


class TestUpdateDocType:
    """Tests for update_doctype function."""

    def test_add_new_field(self, tmp_path: Path) -> None:
        """update_doctype should add new fields."""
        code = dedent("""
            from framework_m.core.base import BaseDocType

            class Todo(BaseDocType):
                title: str
        """)

        file_path = tmp_path / "todo.py"
        file_path.write_text(code)

        result = update_doctype(
            file_path,
            {
                "name": "Todo",
                "fields": [
                    {"name": "title", "type": "str", "required": True},
                    {"name": "priority", "type": "int", "default": "1"},
                ],
            },
        )

        assert "title: str" in result
        assert "priority: int = 1" in result

    def test_update_field_type(self, tmp_path: Path) -> None:
        """update_doctype should update field types."""
        code = dedent("""
            from framework_m.core.base import BaseDocType

            class Item(BaseDocType):
                count: str
        """)

        file_path = tmp_path / "item.py"
        file_path.write_text(code)

        result = update_doctype(
            file_path,
            {
                "name": "Item",
                "fields": [
                    {"name": "count", "type": "int", "required": True},
                ],
            },
        )

        assert "count: int" in result
        assert "count: str" not in result

    def test_preserve_custom_methods(self, tmp_path: Path) -> None:
        """update_doctype should preserve custom methods."""
        code = dedent("""
            from framework_m.core.base import BaseDocType

            class Todo(BaseDocType):
                title: str

                def custom_method(self) -> str:
                    return self.title.upper()
        """)

        file_path = tmp_path / "todo.py"
        file_path.write_text(code)

        result = update_doctype(
            file_path,
            {
                "name": "Todo",
                "fields": [
                    {"name": "title", "type": "str", "required": True},
                    {"name": "done", "type": "bool", "default": "False"},
                ],
            },
        )

        assert "def custom_method(self)" in result
        assert "return self.title.upper()" in result

    def test_file_not_found(self) -> None:
        """update_doctype should raise FileNotFoundError."""
        with pytest.raises(FileNotFoundError):
            update_doctype("/nonexistent.py", {"name": "X", "fields": []})

    def test_parse_syntax_error(self, tmp_path: Path) -> None:
        """update_doctype should raise ValueError on syntax error."""
        file_path = tmp_path / "bad.py"
        file_path.write_text("class Todo(BaseDocType): {syntax error}")
        with pytest.raises(ValueError, match="Failed to parse Python file"):
            update_doctype(file_path, {"name": "Todo", "fields": []})

    def test_ignore_non_name_target(self, tmp_path: Path) -> None:
        """update_doctype should ignore AnnAssign with non-Name targets."""
        code = dedent("""
            class Todo(BaseDocType):
                a.b: str
        """)
        file_path = tmp_path / "todo.py"
        file_path.write_text(code)
        result = update_doctype(file_path, {"name": "Todo", "fields": []})
        assert "a.b: str" in result

    def test_skip_private_fields(self, tmp_path: Path) -> None:
        """update_doctype should skip fields starting with underscore."""
        code = dedent("""
            class Todo(BaseDocType):
                _private: str
        """)
        file_path = tmp_path / "todo.py"
        file_path.write_text(code)
        result = update_doctype(
            file_path, {"name": "Todo", "fields": [{"name": "_private", "type": "int"}]}
        )
        assert "_private: str" in result

    def test_rename_and_update_field(self, tmp_path: Path) -> None:
        """update_doctype should rename and apply new schema simultaneously."""
        code = dedent("""
            class Todo(BaseDocType):
                old_name: str
        """)
        file_path = tmp_path / "todo.py"
        file_path.write_text(code)
        result = update_doctype(
            file_path,
            {"name": "Todo", "fields": [{"name": "new_name", "type": "int"}]},
            field_renames={"old_name": "new_name"},
        )
        assert "new_name: int" in result
        assert "old_name" not in result

    def test_update_field_to_optional_and_default(self, tmp_path: Path) -> None:
        """update_doctype should add | None and = None when making field optional, and handle default values."""
        code = dedent("""
            class Todo(BaseDocType):
                count: str
                status: str
        """)
        file_path = tmp_path / "todo.py"
        file_path.write_text(code)
        result = update_doctype(
            file_path,
            {
                "name": "Todo",
                "fields": [
                    {"name": "count", "type": "int", "required": False},
                    {"name": "status", "type": "str", "default": "'pending'"},
                ],
            },
        )
        assert "count: int | None = None" in result
        assert "status: str = 'pending'" in result

    def test_add_optional_field(self, tmp_path: Path) -> None:
        """update_doctype should add = None to new optional fields."""
        code = dedent("""
            class Todo(BaseDocType):
                pass
        """)
        file_path = tmp_path / "todo.py"
        file_path.write_text(code)
        result = update_doctype(
            file_path,
            {
                "name": "Todo",
                "fields": [{"name": "opt", "type": "str", "required": False}],
            },
        )
        assert "opt: str | None = None" in result


class TestRemoveField:
    """Tests for remove_field function."""

    def test_remove_field(self, tmp_path: Path) -> None:
        """remove_field should remove a field."""
        code = dedent("""
            from framework_m.core.base import BaseDocType

            class Todo(BaseDocType):
                title: str
                obsolete: str = "old"
        """)

        file_path = tmp_path / "todo.py"
        file_path.write_text(code)

        result = remove_field(file_path, "Todo", "obsolete")

        assert "title: str" in result
        assert "obsolete" not in result


class TestRenameField:
    """Tests for rename_field function."""

    def test_rename_field(self, tmp_path: Path) -> None:
        """rename_field should rename a field."""
        code = dedent("""
            from framework_m.core.base import BaseDocType

            class Todo(BaseDocType):
                old_name: str
        """)

        file_path = tmp_path / "todo.py"
        file_path.write_text(code)

        result = rename_field(file_path, "Todo", "old_name", "new_name")

        assert "new_name: str" in result
        assert "old_name" not in result


class TestAddField:
    """Tests for add_field function."""

    def test_add_single_field(self, tmp_path: Path) -> None:
        """add_field should add a single field."""
        code = dedent("""
            from framework_m.core.base import BaseDocType

            class Todo(BaseDocType):
                title: str
        """)

        file_path = tmp_path / "todo.py"
        file_path.write_text(code)

        result = add_field(
            file_path,
            "Todo",
            "priority",
            "int",
            default="1",
            required=False,
        )

        # Non-required fields with defaults get | None type
        assert "priority: int" in result
        assert "= 1" in result


class TestTransformerASTEdgeCases:
    """Edge cases for LibCST AST visitation."""

    def test_empty_statement_line_body(self) -> None:
        """Should safely return node if SimpleStatementLine has no body."""
        transformer = DocTypeTransformer("Todo", {}, None, None)
        transformer.in_target_class = True
        node = cst.SimpleStatementLine(body=[])
        res = transformer.leave_SimpleStatementLine(node, node)
        assert res is node

    def test_skip_docstring_and_concatenated(self) -> None:
        """_find_field_insert_index should skip docstrings (simple and concatenated)."""
        transformer = DocTypeTransformer("Todo", {}, None, None)

        # SimpleString docstring
        simple_str = cst.SimpleString('"""doc"""')
        stmt1 = cst.SimpleStatementLine(body=[cst.Expr(value=simple_str)])

        # ConcatenatedString docstring
        concat_str = cst.ConcatenatedString(
            left=cst.SimpleString('"doc"'), right=cst.SimpleString('"string"')
        )
        stmt2 = cst.SimpleStatementLine(body=[cst.Expr(value=concat_str)])

        # Real field
        field_stmt = cst.SimpleStatementLine(
            body=[
                cst.AnnAssign(
                    target=cst.Name("title"), annotation=cst.Annotation(cst.Name("str"))
                )
            ]
        )

        body = [stmt1, stmt2, field_stmt]

        # Index should be after the real field (index 2 + 1 = 3)
        assert transformer._find_field_insert_index(body) == 3
