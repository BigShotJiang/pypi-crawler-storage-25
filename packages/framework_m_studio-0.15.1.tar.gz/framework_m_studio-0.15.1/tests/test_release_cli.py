"""Tests for Release Orchestration CLI."""

from __future__ import annotations

import os
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import pytest


class TestReleaseCLI:
    """Tests for release CLI command."""

    def test_release_app_exists(self) -> None:
        """Test that release_app is defined."""
        from framework_m_studio.cli.release import release_app

        assert release_app is not None
        assert "release" in release_app.name

    @pytest.mark.asyncio
    async def test_release_auto_command_execution(self) -> None:
        """Test release auto command calls the orchestrator with correct args."""
        from framework_m_studio.cli.release import release_auto_command

        with patch(
            "framework_m_studio.cli.release.cli.run_release_orchestration",
            new_callable=AsyncMock,
        ) as mock_orchestrate:
            await release_auto_command(
                provider="gitlab",
                token="fake-token",
                project_id="fake-project",
                dry_run=True,
            )

            mock_orchestrate.assert_called_once_with(
                provider="gitlab",
                token="fake-token",
                project_id="fake-project",
                dry_run=True,
            )


class TestComputeReleasePlan:
    """Tests for compute_release_plan pure function."""

    def test_release_plan_outputs_pending_bumps(self, tmp_path: Path) -> None:
        """Should output ReleaseUpdates for packages with relevant commits."""
        from framework_m_studio.cli.release import (
            Commit,
            ReleaseConfig,
            ReleasePackage,
            compute_release_plan,
        )

        config = ReleaseConfig(
            packages=[
                ReleasePackage(
                    name="test-pkg",
                    version_file=str(tmp_path / "pyproject.toml"),
                    scopes=["test"],
                    include_global=True,
                )
            ]
        )
        (tmp_path / "pyproject.toml").write_text('version = "1.0.0"')

        commits = [
            Commit(
                hash="hash1",
                subject="feat(test): add thing",
                body="body",
                type="feat",
                scope="test",
                breaking=False,
                description="add thing",
            )
        ]

        with (
            patch(
                "framework_m_studio.cli.release.orchestrator._get_last_tag",
                return_value=None,
            ),
            patch(
                "framework_m_studio.cli.release.orchestrator._get_commits_since",
                return_value=commits,
            ),
        ):
            updates = compute_release_plan(config, tmp_path)

        assert len(updates) == 1
        assert updates[0].component == "test-pkg"
        assert updates[0].bump == "minor"
        assert updates[0].new_version == "1.1.0"

    def test_release_plan_with_body_tags(self, tmp_path: Path) -> None:
        """Should trigger bump if Release tag is present in commit body."""
        from framework_m_studio.cli.release import (
            Commit,
            ReleaseConfig,
            ReleasePackage,
            compute_release_plan,
        )

        config = ReleaseConfig(
            packages=[
                ReleasePackage(
                    name="test-pkg",
                    version_file=str(tmp_path / "pyproject.toml"),
                    scopes=["test"],
                    include_global=True,
                )
            ]
        )
        (tmp_path / "pyproject.toml").write_text('version = "1.0.0"')

        commits = [
            Commit(
                hash="hash1",
                subject="fix: update something",
                body="Releases: test-pkg",
                type="fix",
                scope=None,
                breaking=False,
                description="update something",
                body_tags=["test-pkg"],
            )
        ]

        with (
            patch(
                "framework_m_studio.cli.release.orchestrator._get_last_tag",
                return_value=None,
            ),
            patch(
                "framework_m_studio.cli.release.orchestrator._get_commits_since",
                return_value=commits,
            ),
        ):
            updates = compute_release_plan(config, tmp_path)

        assert len(updates) == 1
        assert updates[0].component == "test-pkg"
        assert updates[0].bump == "patch"

    def test_release_plan_with_publish_name(self, tmp_path: Path) -> None:
        """Should trigger bump if publish_name is present in commit body."""
        from framework_m_studio.cli.release import (
            Commit,
            ReleaseConfig,
            ReleasePackage,
            compute_release_plan,
        )

        config = ReleaseConfig(
            packages=[
                ReleasePackage(
                    name="test-pkg",
                    publish_name="@test/pkg",
                    version_file=str(tmp_path / "pyproject.toml"),
                    scopes=["test"],
                    include_global=True,
                )
            ]
        )
        (tmp_path / "pyproject.toml").write_text('version = "1.0.0"')

        commits = [
            Commit(
                hash="hash1",
                subject="fix: update something",
                body="Releases: @test/pkg",
                type="fix",
                scope=None,
                breaking=False,
                description="update something",
                body_tags=["@test/pkg"],
            )
        ]

        with (
            patch(
                "framework_m_studio.cli.release.orchestrator._get_last_tag",
                return_value=None,
            ),
            patch(
                "framework_m_studio.cli.release.orchestrator._get_commits_since",
                return_value=commits,
            ),
        ):
            updates = compute_release_plan(config, tmp_path)

        assert len(updates) == 1
        assert updates[0].component == "test-pkg"
        assert updates[0].bump == "patch"

    def test_release_plan_dependency_is_discovered_automatically(
        self, tmp_path: Path
    ) -> None:
        """Should automatically trigger sync bump if dependent is discovered by the graph."""
        from framework_m_studio.cli.release import (
            Commit,
            ReleaseConfig,
            ReleasePackage,
            compute_release_plan,
        )

        config = ReleaseConfig(
            packages=[
                ReleasePackage(
                    name="core",
                    version_file=str(tmp_path / "core/pyproject.toml"),
                    scopes=["core"],
                    include_global=True,
                ),
                ReleasePackage(
                    name="desk",
                    version_file=str(tmp_path / "desk/package.json"),
                    scopes=["desk"],
                    include_global=True,
                ),
            ]
        )
        (tmp_path / "core").mkdir()
        (tmp_path / "core/pyproject.toml").write_text('version = "1.0.0"')
        (tmp_path / "desk").mkdir()
        # desk depends on core
        (tmp_path / "desk/package.json").write_text(
            '{"name": "desk", "version": "1.0.0", "dependencies": {"core": "1.0.0"}}'
        )

        commits = [
            Commit(
                hash="hash1",
                subject="fix: update core",
                body="Releases: core",  # Explicitly only core in commit, but graph finds desk
                type="fix",
                scope=None,
                breaking=False,
                description="update core",
                body_tags=["core"],
            )
        ]

        with (
            patch(
                "framework_m_studio.cli.release.orchestrator._get_last_tag",
                return_value=None,
            ),
            patch(
                "framework_m_studio.cli.release.orchestrator._get_commits_since",
                return_value=commits,
            ),
        ):
            updates = compute_release_plan(config, tmp_path)

        # TWO updates: core (initial) and desk (pushed by graph discovery)
        assert len(updates) == 2
        assert any(u.component == "core" for u in updates)
        assert any(u.component == "desk" for u in updates)

    def test_release_plan_dependency_syncs_with_wildcard(self, tmp_path: Path) -> None:
        """Should trigger sync bump for dependents when wildcard is used."""
        from framework_m_studio.cli.release import (
            Commit,
            ReleaseConfig,
            ReleasePackage,
            compute_release_plan,
        )

        config = ReleaseConfig(
            packages=[
                ReleasePackage(
                    name="core",
                    version_file=str(tmp_path / "core/pyproject.toml"),
                    scopes=["core"],
                    include_global=True,
                ),
                ReleasePackage(
                    name="desk",
                    version_file=str(tmp_path / "desk/package.json"),
                    scopes=["desk"],
                    include_global=True,
                ),
            ]
        )
        (tmp_path / "core").mkdir()
        (tmp_path / "core/pyproject.toml").write_text('version = "1.0.0"')
        (tmp_path / "desk").mkdir()
        (tmp_path / "desk/package.json").write_text(
            '{"name": "desk", "version": "1.0.0", "dependencies": {"core": "1.0.0"}}'
        )

        commits = [
            Commit(
                hash="hash1",
                subject="fix: update core",
                body="Releases: *",  # Wildcard triggers all
                type="fix",
                scope=None,
                breaking=False,
                description="update core",
                body_tags=["*"],
            )
        ]

        with (
            patch(
                "framework_m_studio.cli.release.orchestrator._get_last_tag",
                return_value=None,
            ),
            patch(
                "framework_m_studio.cli.release.orchestrator._get_commits_since",
                return_value=commits,
            ),
        ):
            updates = compute_release_plan(config, tmp_path)

        # Both updated: core (initial) and desk (synchronized)
        assert any(u.component == "core" for u in updates)
        assert any(u.component == "desk" for u in updates)

    def test_release_plan_no_op_when_no_commits(self, tmp_path: Path) -> None:
        """Should return empty list when no relevant commits exist."""
        from framework_m_studio.cli.release import (
            ReleaseConfig,
            ReleasePackage,
            compute_release_plan,
        )

        config = ReleaseConfig(
            packages=[
                ReleasePackage(
                    name="test-pkg",
                    version_file=str(tmp_path / "pyproject.toml"),
                    scopes=["test"],
                    include_global=True,
                )
            ]
        )
        (tmp_path / "pyproject.toml").write_text('version = "1.0.0"')

        with (
            patch(
                "framework_m_studio.cli.release.orchestrator._get_last_tag",
                return_value=None,
            ),
            patch(
                "framework_m_studio.cli.release.orchestrator._get_commits_since",
                return_value=[],
            ),
        ):
            updates = compute_release_plan(config, tmp_path)

        assert len(updates) == 0

    def test_release_plan_uses_tag_version_when_higher_than_file(
        self, tmp_path: Path
    ) -> None:
        """Should base bump on git tag version if higher than file version."""
        from framework_m_studio.cli.release import (
            Commit,
            ReleaseConfig,
            ReleasePackage,
            compute_release_plan,
        )

        config = ReleaseConfig(
            packages=[
                ReleasePackage(
                    name="test-pkg",
                    version_file=str(tmp_path / "pyproject.toml"),
                    scopes=["test"],
                    include_global=True,
                )
            ]
        )
        (tmp_path / "pyproject.toml").write_text('version = "1.0.0"')  # Lower than tag

        commits = [
            Commit(
                hash="hash1",
                subject="fix(test): bug",
                body="body",
                type="fix",
                scope="test",
                breaking=False,
                description="bug",
            )
        ]

        with (
            patch(
                "framework_m_studio.cli.release.orchestrator._get_last_tag",
                return_value="test-pkg@v1.2.0",
            ),
            patch(
                "framework_m_studio.cli.release.orchestrator._get_commits_since",
                return_value=commits,
            ),
        ):
            updates = compute_release_plan(config, tmp_path)

        assert len(updates) == 1
        assert updates[0].current_version == "1.2.0"  # Picked up from tag
        assert updates[0].new_version == "1.2.1"


class TestPrepareRelease:
    """Tests for prepare_release pure function."""

    def test_release_prepare_writes_version_files(self, tmp_path: Path) -> None:
        """Should update pyproject.toml / package.json versions."""
        from framework_m_studio.cli.release import (
            ReleaseConfig,
            ReleaseUpdate,
            prepare_release,
        )

        pyproject = tmp_path / "pyproject.toml"
        pyproject.write_text('version = "1.0.0"\nname = "test"')

        updates = [
            ReleaseUpdate(
                component="test",
                component_path=str(tmp_path),
                version_file=str(pyproject),
                current_version="1.0.0",
                new_version="2.0.0",
                bump="major",
                changelog="Changelog",
            )
        ]

        with (
            patch("framework_m_studio.cli.release.orchestrator.run_cmd"),
            patch("framework_m_studio.cli.release.lockfile_sync.run_cmd"),
        ):
            prepare_release(
                updates,
                "release/next",
                tmp_path,
                ReleaseConfig(packages=[]),
                sbom=False,
            )

        assert 'version = "2.0.0"' in pyproject.read_text()

    def test_release_prepare_prepends_changelog(self, tmp_path: Path) -> None:
        """Should prepend new changelog content to CHANGELOG.md."""
        from framework_m_studio.cli.release import (
            ReleaseConfig,
            ReleaseUpdate,
            prepare_release,
        )

        pyproject = tmp_path / "pyproject.toml"
        pyproject.write_text('version = "1.0.0"')

        changelog = tmp_path / "CHANGELOG.md"
        changelog.write_text("# Changelog\n\nOld entry")

        updates = [
            ReleaseUpdate(
                component="test",
                component_path=str(tmp_path),
                version_file=str(pyproject),
                current_version="1.0.0",
                new_version="1.1.0",
                bump="minor",
                changelog="New Entry",
            )
        ]

        with (
            patch("framework_m_studio.cli.release.orchestrator.run_cmd"),
            patch("framework_m_studio.cli.release.lockfile_sync.run_cmd"),
        ):
            prepare_release(
                updates,
                "release/next",
                tmp_path,
                ReleaseConfig(packages=[]),
                sbom=False,
            )

        content = changelog.read_text()
        assert "New Entry" in content
        assert "Old entry" in content

    def test_release_prepare_pins_inter_package_deps(self, tmp_path: Path) -> None:
        """Should pin workspace dependency versions in pyproject.toml."""
        from framework_m_studio.cli.release import (
            ReleaseConfig,
            ReleasePackage,
            ReleaseUpdate,
            prepare_release,
        )

        pyproject = tmp_path / "pyproject.toml"
        pyproject.write_text('dependencies = ["core>=1.0.0"]')

        # Create the file that _update_file_version tries to read
        core_pyproject = tmp_path / "core_pyproject.toml"
        core_pyproject.write_text('version = "1.0.0"')

        updates = [
            ReleaseUpdate(
                component="core",
                component_path=str(tmp_path),
                version_file=str(core_pyproject),
                current_version="1.0.0",
                new_version="2.0.0",
                bump="major",
                changelog="",
            )
        ]

        config = ReleaseConfig(
            packages=[
                ReleasePackage(
                    name="test",
                    version_file=str(pyproject),
                    scopes=[],
                    include_global=True,
                )
            ]
        )

        with (
            patch("framework_m_studio.cli.release.orchestrator.run_cmd"),
            patch("framework_m_studio.cli.release.lockfile_sync.run_cmd"),
        ):
            prepare_release(updates, "release/next", tmp_path, config, sbom=False)

        assert '"core>=2.0.0"' in pyproject.read_text()

    def test_release_prepare_generates_sbom_when_syft_present(
        self, tmp_path: Path
    ) -> None:
        """Should attempt to generate SBOM using syft when requested."""
        from framework_m_studio.cli.release import ReleaseConfig, prepare_release

        with (
            patch("framework_m_studio.cli.release.orchestrator.run_cmd") as mock_run,
            patch("shutil.which", return_value="/usr/bin/syft"),
        ):
            prepare_release(
                [], "release/next", tmp_path, ReleaseConfig(packages=[]), sbom=True
            )

        cmd_args = [call.args[0] for call in mock_run.call_args_list]
        assert any("syft" in cmd for cmd in cmd_args)

    def test_release_prepare_skips_sbom_when_syft_absent(self, tmp_path: Path) -> None:
        """Should gracefully skip SBOM generation if syft fails."""
        import subprocess

        from framework_m_studio.cli.release import ReleaseConfig, prepare_release

        def mock_run_cmd(cmd: str, **kwargs: object) -> str:
            if isinstance(cmd, str) and "syft" in cmd:
                raise subprocess.CalledProcessError(1, cmd)
            return ""

        with (
            patch(
                "framework_m_studio.cli.release.orchestrator.run_cmd",
                side_effect=mock_run_cmd,
            ),
            patch("shutil.which", return_value="/usr/bin/syft"),
        ):
            prepare_release(
                [], "release/next", tmp_path, ReleaseConfig(packages=[]), sbom=True
            )


class TestStageReleaseFiles:
    """Tests for _stage_release_files internal function."""

    def test_stage_files_filters_ignored(self, tmp_path: Path) -> None:
        """Should filter out files ignored by git."""

        from framework_m_studio.cli.release import (
            ReleaseConfig,
            ReleasePackage,
        )
        from framework_m_studio.cli.release.orchestrator import _stage_release_files

        config = ReleaseConfig(
            packages=[
                ReleasePackage(
                    name="test",
                    version_file="pyproject.toml",
                    scopes=[],
                )
            ]
        )
        (tmp_path / "pyproject.toml").write_text("version = 1.0.0")
        (tmp_path / "uv.lock").write_text("lock content")

        def mock_subprocess_run(cmd_args, **kwargs):
            mock_res = MagicMock()
            if "check-ignore" in cmd_args:
                # Simulate uv.lock is ignored (0), others are not (1)
                mock_res.returncode = 0 if "uv.lock" in cmd_args else 1
                return mock_res
            return mock_res

        with (
            patch(
                "framework_m_studio.cli.release.orchestrator.run_cmd",
                return_value="",
            ) as mock_run,
            patch(
                "framework_m_studio.cli.release.orchestrator.subprocess.run",
                side_effect=mock_subprocess_run,
            ),
        ):
            _stage_release_files(tmp_path, config, [])

        # Check git add was called with pyproject.toml but NOT uv.lock
        add_call = [call for call in mock_run.call_args_list if "add" in call.args[0]]
        assert len(add_call) == 1
        added_files = add_call[0].args[0]
        assert "pyproject.toml" in added_files
        assert "uv.lock" not in added_files


class TestReleasePush:
    """Tests for push_release_branch pure function."""

    def test_release_push_calls_git_push(self) -> None:
        """Should perform a direct git push to the remote URL."""
        from unittest.mock import MagicMock

        from framework_m_studio.cli.release import push_release_branch

        with patch("framework_m_studio.cli.release.gitops.subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(returncode=0, stdout="", stderr="")
            push_release_branch("release/next", "gitlab.com", "owner/repo", "token123")

        # Now performs a single atomic push with --force
        assert mock_run.call_count == 1
        args, _ = mock_run.call_args
        cmd = args[0]
        assert "--force" in cmd
        assert "https://oauth2:token123@gitlab.com/owner/repo.git" in cmd
        assert "git" in cmd and "push" in cmd
        assert "release/next:refs/heads/release/next" in cmd


class TestReleaseMR:
    """Tests for create_or_update_mr pure function."""

    @pytest.mark.asyncio
    async def test_release_mr_creates_mr_via_provider(self) -> None:
        """Should create a new MR if one doesn't exist."""
        from framework_m_studio.cli.release import create_or_update_mr

        mock_provider = AsyncMock()
        mock_provider.find_mr.return_value = None
        mock_provider.create_mr.return_value = {"web_url": "http://mr/1"}

        await create_or_update_mr(
            "release/next", "main", "My Title", "My Desc", mock_provider
        )

        mock_provider.find_mr.assert_called_once_with("release/next")
        mock_provider.create_mr.assert_called_once_with(
            "My Title", "My Desc", "release/next", "main"
        )
        mock_provider.update_mr.assert_not_called()

    @pytest.mark.asyncio
    async def test_release_mr_updates_existing_mr(self) -> None:
        """Should update an existing MR if one is found."""
        from framework_m_studio.cli.release import create_or_update_mr

        mock_provider = AsyncMock()
        mock_provider.find_mr.return_value = {"iid": 42, "web_url": "http://mr/42"}

        await create_or_update_mr(
            "release/next", "main", "My Title", "My Desc", mock_provider
        )

        mock_provider.find_mr.assert_called_once_with("release/next")
        mock_provider.update_mr.assert_called_once_with(42, "My Title", "My Desc")
        mock_provider.create_mr.assert_not_called()


class TestReleaseTag:
    """Tests for tag_and_release pure function."""

    @pytest.mark.asyncio
    async def test_release_tag_creates_annotated_git_tag(self, tmp_path: Path) -> None:
        """Should create git tags for components with bumps."""
        from framework_m_studio.cli.release import (
            Commit,
            ReleaseConfig,
            ReleasePackage,
            tag_and_release,
        )

        config = ReleaseConfig(
            packages=[
                ReleasePackage(
                    name="pkg1",
                    version_file=str(tmp_path / "pyproject.toml"),
                    scopes=[],
                    include_global=True,
                )
            ]
        )
        (tmp_path / "pyproject.toml").write_text('version = "1.5.0"')

        commits = [
            Commit(
                hash="123",
                subject="feat: test",
                body="",
                type="feat",
                scope=None,
                breaking=False,
                description="test",
            )
        ]

        with (
            patch("framework_m_studio.cli.release.orchestrator.run_cmd") as mock_run,
            patch(
                "framework_m_studio.cli.release.orchestrator._get_last_tag",
                return_value="pkg1@v1.4.0",
            ),
            patch(
                "framework_m_studio.cli.release.orchestrator._get_commits_since",
                return_value=commits,
            ),
        ):
            await tag_and_release(config, tmp_path, provider=None, dry_run=False)

        cmds = [call.args[0] for call in mock_run.call_args_list]
        assert any("pkg1@v1.5.0" in str(cmd) and "tag" in str(cmd) for cmd in cmds)
        assert any("pkg1@v1.5.0" in str(cmd) and "push" in str(cmd) for cmd in cmds)

    @pytest.mark.asyncio
    async def test_release_tag_creates_gitlab_release(self, tmp_path: Path) -> None:
        """Should call provider to create a release object."""
        from framework_m_studio.cli.release import (
            Commit,
            ReleaseConfig,
            ReleasePackage,
            tag_and_release,
        )

        config = ReleaseConfig(
            packages=[
                ReleasePackage(
                    name="pkg1",
                    version_file=str(tmp_path / "pyproject.toml"),
                    scopes=[],
                    include_global=True,
                )
            ]
        )
        (tmp_path / "pyproject.toml").write_text('version = "1.5.0"')

        mock_provider = AsyncMock()
        commits = [
            Commit(
                hash="123",
                subject="feat: test",
                body="",
                type="feat",
                scope=None,
                breaking=False,
                description="test",
            )
        ]

        with (
            patch("framework_m_studio.cli.release.orchestrator.run_cmd"),
            patch(
                "framework_m_studio.cli.release.orchestrator._get_last_tag",
                return_value="pkg1@v1.4.0",
            ),
            patch(
                "framework_m_studio.cli.release.orchestrator._get_commits_since",
                return_value=commits,
            ),
        ):
            await tag_and_release(config, tmp_path, mock_provider, dry_run=False)

        mock_provider.create_release.assert_called_once()
        args = mock_provider.create_release.call_args[0]
        assert args[0] == "pkg1@v1.5.0"


class TestReleaseSubcommands:
    """Tests for the decomposed release CLI subcommands."""

    def test_release_plan_command(self, tmp_path: Path) -> None:
        """Test release plan command."""
        from framework_m_studio.cli.release import release_plan_command

        with (
            patch(
                "framework_m_studio.cli.release.cli._load_release_config"
            ) as mock_config,
            patch(
                "framework_m_studio.cli.release.cli.compute_release_plan"
            ) as mock_plan,
        ):
            mock_plan.return_value = []
            release_plan_command(
                config=str(tmp_path / "config.json"), root=str(tmp_path), json=True
            )

            mock_config.assert_called_once()
            mock_plan.assert_called_once()

    def test_release_prepare_command(self, tmp_path: Path) -> None:
        """Test release prepare command."""
        from framework_m_studio.cli.release import (
            ReleaseUpdate,
            release_prepare_command,
        )

        mock_update = ReleaseUpdate(
            component="pkg",
            component_path="path",
            version_file="file",
            current_version="1.0",
            new_version="2.0",
            bump="major",
            changelog="log",
        )

        with (
            patch("framework_m_studio.cli.release.cli._load_release_config"),
            patch(
                "framework_m_studio.cli.release.cli.compute_release_plan",
                return_value=[mock_update],
            ),
            patch("framework_m_studio.cli.release.cli.prepare_release") as mock_prepare,
        ):
            release_prepare_command(
                config="config.json",
                branch="release/next",
                root=str(tmp_path),
                sbom=True,
                dry_run=False,
            )

            mock_prepare.assert_called_once()

    def test_release_push_command(self) -> None:
        """Test release push command."""
        from framework_m_studio.cli.release import release_push_command

        with patch(
            "framework_m_studio.cli.release.cli.push_release_branch"
        ) as mock_push:
            release_push_command(
                branch="release/next",
                host="gitlab.com",
                project_path="owner/repo",
                token="secret",
                dry_run=False,
            )

            mock_push.assert_called_once_with(
                "release/next", "gitlab.com", "owner/repo", "secret"
            )

    @pytest.mark.asyncio
    async def test_release_mr_command(self) -> None:
        """Test release mr command."""
        from framework_m_studio.cli.release import release_mr_command

        with (
            patch(
                "framework_m_studio.cli.release.cli.create_or_update_mr",
                new_callable=AsyncMock,
            ) as mock_mr,
            patch(
                "framework_m_studio.cli.release.cli.GitLabProvider"
            ) as mock_provider_cls,
        ):
            await release_mr_command(
                branch="release/next",
                target_branch="main",
                provider="gitlab",
                token="secret",
                project_id="123",
                dry_run=False,
            )

            mock_provider_cls.assert_called_once_with(token="secret", project_id="123")
            mock_mr.assert_called_once()

    @pytest.mark.asyncio
    async def test_release_tag_command(self, tmp_path: Path) -> None:
        """Test release tag command."""
        from framework_m_studio.cli.release import release_tag_command

        with (
            patch("framework_m_studio.cli.release.cli._load_release_config"),
            patch(
                "framework_m_studio.cli.release.cli.tag_and_release",
                new_callable=AsyncMock,
            ) as mock_tag,
            patch("framework_m_studio.cli.release.cli.GitLabProvider"),
        ):
            await release_tag_command(
                config="config.json",
                provider="gitlab",
                token="secret",
                project_id="123",
                dry_run=False,
            )

            mock_tag.assert_called_once()


class TestReleaseCoverage:
    """Additional tests to increase coverage for release CLI."""

    def test_load_config_not_found(self) -> None:
        """Should raise FileNotFoundError for missing config."""
        from framework_m_studio.cli.release import _load_release_config

        with pytest.raises(FileNotFoundError):
            _load_release_config("nonexistent.json")

    def test_get_last_tag_exception(self) -> None:
        """Should return None if git command fails."""
        from framework_m_studio.cli.release import _get_last_tag

        with patch(
            "framework_m_studio.cli.release.gitops.run_cmd",
            side_effect=Exception("git error"),
        ):
            tag = _get_last_tag("component")
            assert tag is None

    def test_update_package_json(self, tmp_path: Path) -> None:
        """Should correctly update version in package.json."""
        from framework_m_studio.cli.release import _update_file_version

        pkg_json = tmp_path / "package.json"
        pkg_json.write_text('{"name": "test", "version": "1.0.0"}')
        _update_file_version(str(pkg_json), "1.1.0")
        assert '"version": "1.1.0"' in pkg_json.read_text()

    def test_prepare_release_no_syft(
        self, tmp_path: Path, capsys: pytest.CaptureFixture[str]
    ) -> None:
        """Should warn and skip SBOM if syft is not in PATH."""
        from framework_m_studio.cli.release import ReleaseConfig, prepare_release

        with patch("shutil.which", return_value=None):
            prepare_release([], "b", tmp_path, ReleaseConfig(packages=[]), sbom=True)

        captured = capsys.readouterr()
        assert "syft' not found" in captured.err

    @pytest.mark.asyncio
    async def test_orchestration_unsupported_provider(self) -> None:
        """Should exit if unsupported provider is used."""
        from framework_m_studio.cli.release import (
            ReleaseUpdate,
            run_release_orchestration,
        )

        mock_update = ReleaseUpdate(
            component="pkg",
            component_path="path",
            version_file="file",
            current_version="1.0",
            new_version="2.0",
            bump="major",
            changelog="log",
        )
        with (
            patch(
                "framework_m_studio.cli.release.orchestrator.compute_release_plan",
                return_value=[mock_update],
            ),
            patch("framework_m_studio.cli.release.orchestrator.prepare_release"),
            patch("framework_m_studio.cli.release.orchestrator.push_release_branch"),
            patch("framework_m_studio.cli.release.orchestrator.run_cmd"),
            pytest.raises(SystemExit),
        ):
            await run_release_orchestration("github", "token", "proj")

    def test_release_prepare_dry_run(
        self, tmp_path: Path, capsys: pytest.CaptureFixture[str]
    ) -> None:
        """Test release prepare --dry-run."""
        from framework_m_studio.cli.release import (
            ReleaseUpdate,
            release_prepare_command,
        )

        mock_update = ReleaseUpdate(
            component="pkg",
            component_path="path",
            version_file="file",
            current_version="1.0",
            new_version="2.0",
            bump="major",
            changelog="log",
        )
        with patch(
            "framework_m_studio.cli.release.cli.compute_release_plan",
            return_value=[mock_update],
        ):
            release_prepare_command(root=str(tmp_path), dry_run=True)
        captured = capsys.readouterr()
        assert "[DRY RUN] Would prepare branch" in captured.out

    def test_release_push_dry_run(self, capsys: pytest.CaptureFixture[str]) -> None:
        """Test release push --dry-run."""
        from framework_m_studio.cli.release import release_push_command

        release_push_command(dry_run=True)
        captured = capsys.readouterr()
        assert "[DRY RUN] Would push branch" in captured.out

    def test_release_push_no_token(self) -> None:
        """Test release push exits if no token."""
        from framework_m_studio.cli.release import release_push_command

        with patch.dict(os.environ, clear=True), pytest.raises(SystemExit):
            release_push_command()

    @pytest.mark.asyncio
    async def test_release_mr_dry_run(self, capsys: pytest.CaptureFixture[str]) -> None:
        """Test release mr --dry-run."""
        from framework_m_studio.cli.release import release_mr_command

        await release_mr_command(dry_run=True)
        captured = capsys.readouterr()
        assert "[DRY RUN] Would create/update MR" in captured.out

    @pytest.mark.asyncio
    async def test_release_mr_no_token(self) -> None:
        """Test release mr exits if no token."""
        from framework_m_studio.cli.release import release_mr_command

        with patch.dict(os.environ, clear=True), pytest.raises(SystemExit):
            await release_mr_command()

    @pytest.mark.asyncio
    async def test_release_mr_unsupported_provider(self) -> None:
        """Test release mr exits for unsupported provider."""
        from framework_m_studio.cli.release import release_mr_command

        with pytest.raises(SystemExit):
            await release_mr_command(provider="github", token="t", project_id="p")

    @pytest.mark.asyncio
    async def test_release_tag_unsupported_provider(self) -> None:
        """Test release tag exits for unsupported provider."""
        from framework_m_studio.cli.release import release_tag_command

        with pytest.raises(SystemExit):
            await release_tag_command(provider="github", token="t", project_id="p")


class TestGitLabProvider:
    """Tests for the real GitLabProvider implementation."""

    @pytest.mark.asyncio
    async def test_find_mr(self) -> None:
        """Should find an open MR for a source branch."""
        from framework_m_studio.cli.release.gitops import GitLabProvider

        provider = GitLabProvider("token", "123")
        with patch("httpx.AsyncClient.request") as mock_request:
            mock_resp = MagicMock()
            mock_resp.json.return_value = [{"id": 1, "web_url": "http://mr/1"}]
            mock_resp.content = b"mock"
            mock_request.return_value = mock_resp

            mr = await provider.find_mr("source")
            assert mr is not None
            assert mr["id"] == 1

    @pytest.mark.asyncio
    async def test_create_mr(self) -> None:
        """Should create a new MR via the API."""
        from framework_m_studio.cli.release.gitops import GitLabProvider

        provider = GitLabProvider("token", "123")
        with patch("httpx.AsyncClient.request") as mock_request:
            mock_resp = MagicMock()
            mock_resp.json.return_value = {"id": 2}
            mock_resp.content = b"mock"
            mock_request.return_value = mock_resp

            mr = await provider.create_mr("title", "desc", "source", "target")
            assert mr is not None
            assert mr["id"] == 2

    @pytest.mark.asyncio
    async def test_update_mr(self) -> None:
        """Should update an existing MR via the API."""
        from framework_m_studio.cli.release.gitops import GitLabProvider

        provider = GitLabProvider("token", "123")
        with patch("httpx.AsyncClient.request") as mock_request:
            mock_resp = MagicMock()
            mock_resp.json.return_value = {"id": 3}
            mock_resp.content = b"mock"
            mock_request.return_value = mock_resp

            mr = await provider.update_mr("3", "title", "desc")
            assert mr is not None
            assert mr["id"] == 3

    @pytest.mark.asyncio
    async def test_create_release(self) -> None:
        """Should create a GitLab release for a tag."""
        from framework_m_studio.cli.release.gitops import GitLabProvider

        provider = GitLabProvider("token", "123")
        with patch("httpx.AsyncClient.request") as mock_request:
            mock_resp = MagicMock()
            mock_resp.json.return_value = {"tag_name": "v1.5.0"}
            mock_resp.content = b"mock"
            mock_request.return_value = mock_resp

            res = await provider.create_release("v1.5.0", "changelog")
            assert res is not None
            assert res["tag_name"] == "v1.5.0"


class TestPrepareReleaseSync:
    """Tests for template synchronization logic in prepare_release."""

    def test_prepare_release_sync_re_sub(self, tmp_path: Path) -> None:
        """Should update multiple occurrences in a template file."""
        from framework_m_studio.cli.release import (
            ReleaseConfig,
            ReleaseSync,
            ReleaseUpdate,
            prepare_release,
        )

        template = tmp_path / "template.json"
        template.write_text('{"v": "0.1.0", "meta": {"version": "0.1.0"}}')

        updates = [
            ReleaseUpdate(
                component="core",
                component_path=str(tmp_path),
                version_file="v.toml",
                current_version="0.1.0",
                new_version="1.0.0",
                bump="major",
                changelog="",
            )
        ]

        config = ReleaseConfig(
            packages=[],
            sync=[
                ReleaseSync(
                    file="template.json",
                    pattern=r'"version": "([^"]+)"',
                    package_name="core",
                )
            ],
        )

        # Also add a second sync for the other pattern
        config.sync.append(
            ReleaseSync(
                file="template.json", pattern=r'"v": "([^"]+)"', package_name="core"
            )
        )

        with (
            patch("framework_m_studio.cli.release.orchestrator.run_cmd"),
            patch("framework_m_studio.cli.release.lockfile_sync.run_cmd"),
        ):
            prepare_release(updates, "b", tmp_path, config, sbom=False)

        content = template.read_text()
        assert '"v": "1.0.0"' in content
        assert '"version": "1.0.0"' in content
