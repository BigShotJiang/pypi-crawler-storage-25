"""Tests for Ephemeral Workspace Lifecycle (§4.1).

TDD tests for stateless pod startup, draft sync, and config from env vars.
"""

from __future__ import annotations

import os
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from framework_m_studio.ephemeral import (
    EphemeralWorkspace,
    StatelessConfig,
)


class TestStatelessConfig:
    """Tests for StatelessConfig (env-based)."""

    def test_from_env(self) -> None:
        """Must read git_url, token, branch from environment."""
        env = {
            "STUDIO_GIT_URL": "https://github.com/org/app.git",
            "STUDIO_GIT_TOKEN": "ghp_abc123",
            "STUDIO_GIT_BRANCH": "main",
        }
        with patch.dict(os.environ, env, clear=False):
            config = StatelessConfig.from_env()

        assert config.git_url == "https://github.com/org/app.git"
        assert config.token == "ghp_abc123"
        assert config.branch == "main"

    def test_defaults_branch_to_main(self) -> None:
        """Branch must default to 'main' if not set."""
        env = {
            "STUDIO_GIT_URL": "https://github.com/org/app.git",
            "STUDIO_GIT_TOKEN": "token",
        }
        with patch.dict(os.environ, env, clear=False):
            config = StatelessConfig.from_env()

        assert config.branch == "main"

    def test_missing_url_raises(self) -> None:
        """Must raise ValueError if STUDIO_GIT_URL is not set."""
        env: dict[str, str] = {}
        with (
            patch.dict(os.environ, env, clear=True),
            pytest.raises(ValueError, match="STUDIO_GIT_URL"),
        ):
            StatelessConfig.from_env()


class TestEphemeralWorkspace:
    """Tests for the EphemeralWorkspace lifecycle."""

    @pytest.fixture
    def mock_git(self) -> MagicMock:
        mock = MagicMock()
        mock.clone = AsyncMock()
        mock.checkout = AsyncMock()
        mock.commit = AsyncMock(return_value=MagicMock(sha="abc"))
        mock.push = AsyncMock()
        mock.create_branch = AsyncMock()
        return mock

    @pytest.fixture
    def workspace(self, mock_git: MagicMock, tmp_path: Path) -> EphemeralWorkspace:
        config = StatelessConfig(
            git_url="https://github.com/org/app.git",
            token="token123",
            branch="main",
        )
        return EphemeralWorkspace(
            git_adapter=mock_git,
            config=config,
            workspace_dir=tmp_path,
        )

    @pytest.mark.asyncio
    async def test_startup_clones_repo(
        self, workspace: EphemeralWorkspace, mock_git: MagicMock
    ) -> None:
        """startup() must clone the repo into the workspace dir."""
        await workspace.startup()

        mock_git.clone.assert_called_once()
        assert workspace.is_ready is True

    @pytest.mark.asyncio
    async def test_startup_checks_out_branch(
        self, workspace: EphemeralWorkspace, mock_git: MagicMock
    ) -> None:
        """startup() must checkout the configured branch."""
        await workspace.startup()

        mock_git.checkout.assert_called_once()

    @pytest.mark.asyncio
    async def test_draft_sync_pushes_to_draft_branch(
        self, workspace: EphemeralWorkspace, mock_git: MagicMock
    ) -> None:
        """draft_sync() must push to studio-draft/[user] branch."""
        await workspace.startup()
        await workspace.draft_sync(user="alice")

        mock_git.create_branch.assert_called()
        branch = mock_git.create_branch.call_args[0][1]
        assert "studio-draft/alice" in branch

    @pytest.mark.asyncio
    async def test_draft_sync_commits_changes(
        self, workspace: EphemeralWorkspace, mock_git: MagicMock
    ) -> None:
        """draft_sync() must commit all pending changes."""
        await workspace.startup()
        await workspace.draft_sync(user="alice")

        mock_git.commit.assert_called()
        mock_git.push.assert_called()

    @pytest.mark.asyncio
    async def test_not_ready_before_startup(
        self, workspace: EphemeralWorkspace
    ) -> None:
        """Workspace must not be ready before startup()."""
        assert workspace.is_ready is False

    def test_workspace_dir(self, workspace: EphemeralWorkspace, tmp_path: Path) -> None:
        """workspace_dir must be the configured directory."""
        assert workspace.workspace_dir == tmp_path
