"""Extended tests for protocol_scanner LibCST edge cases to increase coverage."""

from __future__ import annotations

import os
from pathlib import Path
from unittest.mock import patch

import libcst as cst

from framework_m_studio.protocol_scanner import (
    _clean_docstring_for_markdown,
    _extract_adapters,
    _extract_docstring,
    _extract_function_docstring,
    _get_base_name,
    generate_comparison_table,
    generate_protocol_markdown,
    get_source_file_url,
    parse_protocol_file,
)


def test_get_base_name() -> None:
    # Name
    arg_name = cst.Arg(value=cst.Name("MyBase"))
    assert _get_base_name(arg_name) == "MyBase"

    # Subscript like Generic[T]
    arg_sub = cst.Arg(
        value=cst.Subscript(
            value=cst.Name("Generic"),
            slice=[cst.SubscriptElement(slice=cst.Index(value=cst.Name("T")))],
        )
    )
    assert _get_base_name(arg_sub) == "Generic"

    # Fallback
    arg_other = cst.Arg(value=cst.Integer("1"))
    assert _get_base_name(arg_other) == ""


def test_extract_docstring_edges() -> None:
    # No body
    assert (
        _extract_docstring(
            cst.ClassDef(name=cst.Name("A"), body=cst.IndentedBlock(body=[]))
        )
        is None
    )

    # Not simple statement
    block = cst.IndentedBlock(
        body=[cst.If(test=cst.Name("a"), body=cst.IndentedBlock(body=[]))]
    )
    assert _extract_docstring(cst.ClassDef(name=cst.Name("A"), body=block)) is None

    # Not expr
    stmt = cst.SimpleStatementLine(body=[cst.Pass()])
    block_pass = cst.IndentedBlock(body=[stmt])
    assert _extract_docstring(cst.ClassDef(name=cst.Name("A"), body=block_pass)) is None

    # Function docstring edges
    assert (
        _extract_function_docstring(
            cst.FunctionDef(
                name=cst.Name("f"),
                params=cst.Parameters(),
                body=cst.IndentedBlock(body=[]),
            )
        )
        is None
    )
    assert (
        _extract_function_docstring(
            cst.FunctionDef(name=cst.Name("f"), params=cst.Parameters(), body=block)
        )
        is None
    )
    assert (
        _extract_function_docstring(
            cst.FunctionDef(
                name=cst.Name("f"), params=cst.Parameters(), body=block_pass
            )
        )
        is None
    )

    # Quote types
    for quote in ['"""val"""', "'''val'''", '"val"', "'val'"]:
        expr = cst.SimpleStatementLine(body=[cst.Expr(value=cst.SimpleString(quote))])
        cdef = cst.ClassDef(name=cst.Name("A"), body=cst.IndentedBlock(body=[expr]))
        fdef = cst.FunctionDef(
            name=cst.Name("f"),
            params=cst.Parameters(),
            body=cst.IndentedBlock(body=[expr]),
        )
        assert "val" in _extract_docstring(cdef)
        assert "val" in _extract_function_docstring(fdef)


def test_extract_adapters() -> None:
    assert _extract_adapters(None) == []
    assert _extract_adapters("") == []

    doc1 = """
    Implementations:
    - FooAdapter: description
    - Bar: 
    - Baz
    
    Something else
    """
    adps = _extract_adapters(doc1)
    assert "FooAdapter" in adps
    assert "Bar" in adps
    assert "Baz" in adps

    doc2 = "Implementation:\n- Single"
    assert "Single" in _extract_adapters(doc2)


def test_get_source_file_url() -> None:
    root = Path("/app")
    with patch.dict(
        os.environ,
        {"CI_PROJECT_URL": "http://x", "CI_COMMIT_REF_NAME": "main"},
        clear=True,
    ):
        # Within root
        name, url = get_source_file_url("/app/foo/bar.py", root)
        assert name == "bar.py"
        assert url == "http://x/-/blob/main/foo/bar.py"

        # Outside root (throws ValueError, falls back to local)
        name, url = get_source_file_url("/other/bar.py", root)
        assert url.startswith("file://")


def test_generate_protocol_markdown() -> None:
    proto = {
        "name": "MyProto",
        "docstring": "Hello\nImplementations:\n- A",
        "methods": [{"name": "m1", "signature": "def m1()", "docstring": "d1"}],
        "adapters": ["A"],
        "file_path": "/app/foo.py",
    }
    md = generate_protocol_markdown(proto, Path("/app"))
    assert "# MyProto" in md
    assert "Hello" in md
    assert "Implementations:" not in md
    assert "## Methods" in md
    assert "`m1`" in md
    assert "d1" in md
    assert "## Adapters" in md
    assert "- `A`" in md


def test_clean_docstring_for_markdown() -> None:
    doc = "Start\nImplementation:\n- A\n\nEnd"
    cleaned = _clean_docstring_for_markdown(doc)
    assert "Start" in cleaned
    assert "Implementation" not in cleaned
    assert "- A" not in cleaned
    assert "End" in cleaned


def test_parse_protocol_file_syntax_error(tmp_path: Path) -> None:
    p = tmp_path / "bad.py"
    p.write_text("class A:")
    assert parse_protocol_file(p) == []


def test_generate_comparison_table() -> None:
    protos = [
        {"name": "P1", "adapters": ["A1", "A2"]},
        {"name": "P2", "adapters": ["A3"]},
    ]
    indies = {"A1", "A3"}
    table = generate_comparison_table(protos, indies)

    assert "| P1 | `A1` | `A2` |" in table
    assert "| P2 | `A3` | - |" in table
