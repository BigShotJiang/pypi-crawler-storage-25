"""Tests for Guardrail Checker and Publish Guard.

TDD tests for schema change guardrails that block publishing
when dangerous changes are detected.
"""

from __future__ import annotations

from framework_m_studio.guardrail import (
    GuardrailChecker,
    GuardrailResult,
    PublishGuard,
)

DOCTYPE_SAFE = """
from pydantic import Field
from framework_m_core.domain import BaseDocType

class Invoice(BaseDocType):
    customer: str = Field(description="Customer")
    amount: float = Field(description="Amount")
"""

DOCTYPE_DANGEROUS = """
from pydantic import Field
from framework_m_core.domain import BaseDocType

class Invoice(BaseDocType):
    buyer: str = Field(description="Buyer Name")
    amount: float = Field(description="Amount")
"""

DOCTYPE_WARNING = """
from pydantic import Field
from framework_m_core.domain import BaseDocType

class Invoice(BaseDocType):
    customer: str = Field(description="Client Name")
    amount: float = Field(description="Total Amount")
"""


class TestGuardrailChecker:
    """Tests for the GuardrailChecker."""

    def test_check_no_changes(self) -> None:
        """Identical sources must return no changes and can_publish=True."""
        checker = GuardrailChecker()
        result = checker.check(DOCTYPE_SAFE, DOCTYPE_SAFE)

        assert result.can_publish is True
        assert len(result.changes) == 0
        assert result.has_dangerous is False

    def test_check_dangerous_changes(self) -> None:
        """Dangerous changes must block publishing."""
        checker = GuardrailChecker()
        result = checker.check(DOCTYPE_SAFE, DOCTYPE_DANGEROUS)

        assert result.has_dangerous is True
        assert result.can_publish is False

    def test_check_warning_changes(self) -> None:
        """Warning-only changes must allow publishing."""
        checker = GuardrailChecker()
        result = checker.check(DOCTYPE_SAFE, DOCTYPE_WARNING)

        assert result.has_dangerous is False
        assert result.can_publish is True
        assert len(result.changes) > 0


class TestPublishGuard:
    """Tests for the PublishGuard (ack-based override)."""

    def test_guard_blocks_dangerous(self) -> None:
        """PublishGuard must block when dangerous and not acknowledged."""
        guard = PublishGuard()
        result = GuardrailResult(
            changes=[],
            has_dangerous=True,
            can_publish=False,
        )

        assert guard.allow_publish(result, acknowledged=False) is False

    def test_guard_allows_after_ack(self) -> None:
        """PublishGuard must allow when dangerous but acknowledged."""
        guard = PublishGuard()
        result = GuardrailResult(
            changes=[],
            has_dangerous=True,
            can_publish=False,
        )

        assert guard.allow_publish(result, acknowledged=True) is True

    def test_guard_allows_safe_changes(self) -> None:
        """PublishGuard must allow when no dangerous changes."""
        guard = PublishGuard()
        result = GuardrailResult(
            changes=[],
            has_dangerous=False,
            can_publish=True,
        )

        assert guard.allow_publish(result, acknowledged=False) is True


class TestGuardrailResult:
    """Tests for the GuardrailResult dataclass."""

    def test_creation(self) -> None:
        result = GuardrailResult(
            changes=[],
            has_dangerous=False,
            can_publish=True,
        )
        assert result.can_publish is True

    def test_summary(self) -> None:
        """GuardrailResult must provide a human-readable summary."""
        result = GuardrailResult(
            changes=[{"field": "customer", "type": "DANGEROUS", "desc": "dropped"}],
            has_dangerous=True,
            can_publish=False,
        )
        assert result.has_dangerous is True
        assert len(result.changes) == 1
