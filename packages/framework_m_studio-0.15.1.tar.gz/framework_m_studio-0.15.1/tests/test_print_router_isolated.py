"""Isolated branch coverage tests for print router."""

from pathlib import Path
from unittest.mock import patch

from litestar import Litestar
from litestar.testing import TestClient

from framework_m_studio.routers.print import PrintController


def test_print_router_get_layout(tmp_path: Path):
    app = Litestar(route_handlers=[PrintController])

    target_dir = tmp_path / "Invoice"
    target_dir.mkdir(parents=True)
    (target_dir / "standard.html").write_text("hello")

    with (
        patch(
            "framework_m_studio.services.print_service.get_print_repo_path",
            return_value=tmp_path,
        ),
        TestClient(app) as client,
    ):
        res = client.get("/studio/api/print/layout/Invoice/standard")
        assert res.status_code == 200

        res_404 = client.get("/studio/api/print/layout/Invoice/missing")
        assert res_404.status_code == 404
