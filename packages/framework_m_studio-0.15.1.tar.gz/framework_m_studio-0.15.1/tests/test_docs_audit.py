"""Tests for Documentation Gap Audit.

Tests for the `m docs audit` functionality following TDD principles.
"""

from __future__ import annotations

from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest


class TestDocsAudit:
    """Tests for docs gap audit logic."""

    def test_audit_identifies_missing_doctype_docs(
        self, tmp_path: Path, capsys: pytest.CaptureFixture[str]
    ) -> None:
        """Test that the audit identifies DocTypes missing descriptions."""
        # This import will intentionally fail until the module is implemented
        from framework_m_studio.docs.audit import run_docs_audit

        mock_doctype_with_doc = MagicMock()
        mock_doctype_with_doc.name = "DocumentedDoc"

        mock_doctype_without_doc = MagicMock()
        mock_doctype_without_doc.name = "UndocumentedDoc"

        with (
            patch(
                "framework_m_studio.docs.audit.scan_doctypes",
                return_value=[mock_doctype_with_doc, mock_doctype_without_doc],
            ),
            patch("framework_m_studio.docs.audit.doctype_to_dict") as mock_to_dict,
            patch("framework_m_studio.docs.audit.scan_protocols", return_value=[]),
        ):

            def to_dict_side_effect(dt: MagicMock) -> dict[str, str | None]:
                if dt.name == "DocumentedDoc":
                    return {"name": dt.name, "docstring": "This is a good description."}
                return {"name": dt.name, "docstring": None}

            mock_to_dict.side_effect = to_dict_side_effect

            result = run_docs_audit(project_root=tmp_path)
            assert result is False

        captured = capsys.readouterr()
        assert "UndocumentedDoc" in captured.err
        assert "DocumentedDoc" not in captured.err

    def test_audit_identifies_missing_protocol_docs(
        self, tmp_path: Path, capsys: pytest.CaptureFixture[str]
    ) -> None:
        """Test that the audit identifies Protocols missing docstrings."""
        from framework_m_studio.docs.audit import run_docs_audit

        mock_protocol_with_doc = {
            "name": "DocumentedProtocol",
            "docstring": "This is documented.",
            "methods": [{"name": "method1", "docstring": "Method doc."}],
        }

        mock_protocol_without_doc = {
            "name": "UndocumentedProtocol",
            "docstring": None,
            "methods": [{"name": "method1", "docstring": None}],
        }

        with (
            patch("framework_m_studio.docs.audit.scan_doctypes", return_value=[]),
            patch(
                "framework_m_studio.docs.audit.scan_protocols",
                return_value=[mock_protocol_with_doc, mock_protocol_without_doc],
            ),
        ):
            result = run_docs_audit(project_root=tmp_path)
            assert result is False

        captured = capsys.readouterr()
        assert "UndocumentedProtocol" in captured.err
        assert "method1" in captured.err
        assert "DocumentedProtocol" not in captured.err

    def test_audit_passes_when_all_documented(
        self, tmp_path: Path, capsys: pytest.CaptureFixture[str]
    ) -> None:
        """Test that the audit passes when everything is documented."""
        from framework_m_studio.docs.audit import run_docs_audit

        with (
            patch("framework_m_studio.docs.audit.scan_doctypes", return_value=[]),
            patch("framework_m_studio.docs.audit.scan_protocols", return_value=[]),
        ):
            result = run_docs_audit(project_root=tmp_path)
            assert result is True
            assert "100%" in capsys.readouterr().out
