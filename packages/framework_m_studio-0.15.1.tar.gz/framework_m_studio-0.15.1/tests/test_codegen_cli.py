"""Branch coverage tests for codegen CLI."""

from unittest.mock import patch

from framework_m_studio.cli.codegen import codegen_client, codegen_doctype


def test_codegen_client_python_branch(tmp_path):
    """Should skip TypeScript generation if lang is 'py'."""
    with patch(
        "framework_m_studio.sdk_generator.fetch_openapi_schema", return_value={}
    ):
        codegen_client(lang="py", out=str(tmp_path))
        # If lang="py", codegen.py explicitly skips creating types.ts and client.ts
        assert not (tmp_path / "types.ts").exists()


def test_codegen_doctype_branches():
    """Should handle optional app parameter gracefully."""
    # With app parameter
    codegen_doctype(name="Invoice", app="billing")

    # Without app parameter
    codegen_doctype(name="Invoice", app=None)
