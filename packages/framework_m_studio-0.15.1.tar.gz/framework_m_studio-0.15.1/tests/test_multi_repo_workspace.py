"""Tests for Multi-Repo Workspace Manager.

TDD tests for extending WorkspaceManager to support multiple
connected repos per session (workspace, print, config).
"""

from __future__ import annotations

from pathlib import Path
from unittest.mock import AsyncMock

import pytest

from framework_m_studio.git.protocol import CommitResult, GitStatus
from framework_m_studio.workspace import (
    MultiRepoSession,
    RepoSlot,
    WorkspaceManager,
)


class MockGitAdapter:
    """Mock GitAdapter for testing."""

    def __init__(self) -> None:
        self.clone = AsyncMock()
        self.commit = AsyncMock(
            return_value=CommitResult(sha="abc123", message="test", files_changed=1)
        )
        self.push = AsyncMock()
        self.pull = AsyncMock()
        self.create_branch = AsyncMock()
        self.checkout = AsyncMock()
        self.get_status = AsyncMock(
            return_value=GitStatus(
                branch="main",
                is_clean=True,
                modified_files=[],
                staged_files=[],
                untracked_files=[],
            )
        )
        self.get_current_branch = AsyncMock(return_value="main")
        self.fetch = AsyncMock()


class TestRepoSlot:
    """Tests for the RepoSlot dataclass."""

    def test_repo_slot_creation(self) -> None:
        """RepoSlot must store URL, local path, and branch."""
        slot = RepoSlot(
            name="workspace",
            repo_url="https://github.com/org/app.git",
            local_path=Path("/tmp/ws"),
            branch="main",
        )
        assert slot.name == "workspace"
        assert slot.repo_url == "https://github.com/org/app.git"
        assert slot.local_path == Path("/tmp/ws")
        assert slot.branch == "main"


class TestConnectMulti:
    """Tests for connect_multi — cloning 3 repos into a single session."""

    @pytest.fixture
    def git_adapter(self) -> MockGitAdapter:
        return MockGitAdapter()

    @pytest.fixture
    def manager(self, git_adapter: MockGitAdapter, tmp_path: Path) -> WorkspaceManager:
        return WorkspaceManager(git_adapter=git_adapter, base_dir=tmp_path)  # type: ignore

    @pytest.mark.asyncio
    async def test_connect_multi_creates_session(
        self, manager: WorkspaceManager, git_adapter: MockGitAdapter
    ) -> None:
        """connect_multi must create a MultiRepoSession with all repos."""
        session = await manager.connect_multi(
            repos={
                "workspace": "https://github.com/org/app.git",
                "print": "https://github.com/org/print-templates.git",
                "config": "https://github.com/org/config.git",
            },
            auth_token="token123",
        )

        assert isinstance(session, MultiRepoSession)
        assert session.id is not None
        assert len(session.repos) == 3
        assert "workspace" in session.repos
        assert "print" in session.repos
        assert "config" in session.repos

        # All 3 repos should have been cloned
        assert git_adapter.clone.call_count == 3

    @pytest.mark.asyncio
    async def test_connect_multi_independent_paths(
        self, manager: WorkspaceManager, git_adapter: MockGitAdapter
    ) -> None:
        """Each repo slot must have its own local_path subdirectory."""
        session = await manager.connect_multi(
            repos={
                "workspace": "https://github.com/org/app.git",
                "config": "https://github.com/org/config.git",
            },
        )

        paths = [slot.local_path for slot in session.repos.values()]
        assert len(set(paths)) == len(paths), "Each repo must have a unique path"

    @pytest.mark.asyncio
    async def test_connect_multi_with_branches(
        self, manager: WorkspaceManager, git_adapter: MockGitAdapter
    ) -> None:
        """connect_multi must support per-repo branch specification."""
        git_adapter.get_current_branch.side_effect = ["develop", "main"]

        session = await manager.connect_multi(
            repos={
                "workspace": "https://github.com/org/app.git",
                "config": "https://github.com/org/config.git",
            },
            branches={"workspace": "develop"},
        )

        assert session.repos["workspace"].branch == "develop"
        assert session.repos["config"].branch == "main"


class TestMultiRepoStatus:
    """Tests for per-repo status in multi-repo sessions."""

    @pytest.fixture
    def git_adapter(self) -> MockGitAdapter:
        return MockGitAdapter()

    @pytest.fixture
    def manager(self, git_adapter: MockGitAdapter, tmp_path: Path) -> WorkspaceManager:
        return WorkspaceManager(git_adapter=git_adapter, base_dir=tmp_path)  # type: ignore

    @pytest.mark.asyncio
    async def test_get_repo_status(
        self, manager: WorkspaceManager, git_adapter: MockGitAdapter
    ) -> None:
        """get_repo_status must return GitStatus for a specific repo slot."""
        session = await manager.connect_multi(
            repos={"workspace": "https://github.com/org/app.git"},
        )

        status = await manager.get_repo_status(session.id, "workspace")

        assert status.branch == "main"
        assert status.is_clean is True
        git_adapter.get_status.assert_called_once()

    @pytest.mark.asyncio
    async def test_get_repo_status_unknown_slot(
        self, manager: WorkspaceManager
    ) -> None:
        """get_repo_status must raise KeyError for unknown repo slot."""
        session = await manager.connect_multi(
            repos={"workspace": "https://github.com/org/app.git"},
        )

        with pytest.raises(KeyError, match="unknown_slot"):
            await manager.get_repo_status(session.id, "unknown_slot")

    @pytest.mark.asyncio
    async def test_get_all_repo_statuses(
        self, manager: WorkspaceManager, git_adapter: MockGitAdapter
    ) -> None:
        """get_all_repo_statuses returns a dict of slot_name → GitStatus."""
        session = await manager.connect_multi(
            repos={
                "workspace": "https://github.com/org/app.git",
                "print": "https://github.com/org/print.git",
            },
        )

        statuses = await manager.get_all_repo_statuses(session.id)

        assert len(statuses) == 2
        assert "workspace" in statuses
        assert "print" in statuses
        assert git_adapter.get_status.call_count == 2


class TestMultiRepoBranchSwitch:
    """Tests for independent branch switching per repo."""

    @pytest.fixture
    def git_adapter(self) -> MockGitAdapter:
        return MockGitAdapter()

    @pytest.fixture
    def manager(self, git_adapter: MockGitAdapter, tmp_path: Path) -> WorkspaceManager:
        return WorkspaceManager(git_adapter=git_adapter, base_dir=tmp_path)  # type: ignore

    @pytest.mark.asyncio
    async def test_checkout_repo(
        self, manager: WorkspaceManager, git_adapter: MockGitAdapter
    ) -> None:
        """checkout_repo must switch a single repo slot's branch."""
        session = await manager.connect_multi(
            repos={
                "workspace": "https://github.com/org/app.git",
                "config": "https://github.com/org/config.git",
            },
        )

        await manager.checkout_repo(session.id, "workspace", "feature/new")

        git_adapter.checkout.assert_called_once()
        # Verify the config repo was NOT touched
        assert git_adapter.checkout.call_count == 1

    @pytest.mark.asyncio
    async def test_create_branch_in_repo(
        self, manager: WorkspaceManager, git_adapter: MockGitAdapter
    ) -> None:
        """create_branch_in_repo must create branch in a specific slot."""
        session = await manager.connect_multi(
            repos={"workspace": "https://github.com/org/app.git"},
        )

        await manager.create_branch_in_repo(
            session.id, "workspace", "feature/studio-edit"
        )

        git_adapter.create_branch.assert_called_once()


class TestMultiRepoCommit:
    """Tests for per-repo commit in multi-repo sessions."""

    @pytest.fixture
    def git_adapter(self) -> MockGitAdapter:
        return MockGitAdapter()

    @pytest.fixture
    def manager(self, git_adapter: MockGitAdapter, tmp_path: Path) -> WorkspaceManager:
        return WorkspaceManager(git_adapter=git_adapter, base_dir=tmp_path)  # type: ignore

    @pytest.mark.asyncio
    async def test_commit_repo(
        self, manager: WorkspaceManager, git_adapter: MockGitAdapter
    ) -> None:
        """commit_repo must commit+push for a single repo slot."""
        session = await manager.connect_multi(
            repos={"workspace": "https://github.com/org/app.git"},
            auth_token="token",
        )

        sha = await manager.commit_repo(
            session.id, "workspace", "feat: add new doctype"
        )

        assert sha == "abc123"
        git_adapter.commit.assert_called_once()
        git_adapter.push.assert_called_once()

    @pytest.mark.asyncio
    async def test_commit_repo_without_push(
        self, manager: WorkspaceManager, git_adapter: MockGitAdapter
    ) -> None:
        """commit_repo must skip push when push=False."""
        session = await manager.connect_multi(
            repos={"workspace": "https://github.com/org/app.git"},
            auth_token="token",
        )

        await manager.commit_repo(session.id, "workspace", "wip", push=False)

        git_adapter.commit.assert_called_once()
        git_adapter.push.assert_not_called()


class TestMultiRepoDisconnect:
    """Tests for multi-repo session cleanup."""

    @pytest.fixture
    def git_adapter(self) -> MockGitAdapter:
        return MockGitAdapter()

    @pytest.fixture
    def manager(self, git_adapter: MockGitAdapter, tmp_path: Path) -> WorkspaceManager:
        return WorkspaceManager(git_adapter=git_adapter, base_dir=tmp_path)  # type: ignore

    @pytest.mark.asyncio
    async def test_disconnect_multi_removes_all_repos(
        self, manager: WorkspaceManager, tmp_path: Path
    ) -> None:
        """disconnect_multi must remove all repo directories and the session."""
        session = await manager.connect_multi(
            repos={
                "workspace": "https://github.com/org/app.git",
                "print": "https://github.com/org/print.git",
            },
        )

        # Create dirs to simulate clone
        for slot in session.repos.values():
            slot.local_path.mkdir(parents=True, exist_ok=True)
            (slot.local_path / "test.py").write_text("# test")

        await manager.disconnect_multi(session.id)

        # All dirs should be gone
        for slot in session.repos.values():
            assert not slot.local_path.exists()

        # Session should be removed
        with pytest.raises(KeyError):
            await manager.get_multi_session(session.id)
