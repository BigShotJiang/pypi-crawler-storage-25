"""Tests for Versioning and dependency pinning to increase coverage."""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from framework_m_studio.cli.release.models import (
    Commit,
    ReleaseConfig,
    ReleasePackage,
    ReleaseUpdate,
)
from framework_m_studio.cli.release.versioning import (
    _bump_version,
    _generate_changelog,
    _pin_inter_package_dependencies,
    _prepend_changelog,
    _update_file_version,
)


class TestBumpVersion:
    def test_bump_major(self) -> None:
        assert _bump_version("1.2.3", "major") == "2.0.0"

    def test_bump_minor(self) -> None:
        assert _bump_version("1.2.3", "minor") == "1.3.0"

    def test_bump_patch(self) -> None:
        assert _bump_version("1.2.3", "patch") == "1.2.4"


class TestUpdateFileVersion:
    def test_file_not_exists(self, tmp_path: Path) -> None:
        p = tmp_path / "does_not_exist.toml"
        # Should return silently
        _update_file_version(str(p), "2.0.0")

    def test_json_missing_version(self, tmp_path: Path) -> None:
        p = tmp_path / "pkg.json"
        p.write_text('{"name": "test"}')
        _update_file_version(str(p), "2.0.0")
        assert "version" not in p.read_text()

    def test_json_decode_error(self, tmp_path: Path) -> None:
        p = tmp_path / "pkg.json"
        p.write_text('{"invalid_json": ')
        _update_file_version(str(p), "2.0.0")
        assert '{"invalid_json": ' in p.read_text()

    def test_no_changes_needed(self, tmp_path: Path) -> None:
        p = tmp_path / "pkg.toml"
        p.write_text('version = "2.0.0"')
        mtime = p.stat().st_mtime
        _update_file_version(str(p), "2.0.0")
        assert p.stat().st_mtime == mtime  # Should not overwrite


class TestPinInterPackageDependencies:
    @pytest.fixture
    def config(self) -> ReleaseConfig:
        return ReleaseConfig(
            packages=[
                ReleasePackage(
                    name="pkgA",
                    path="apps/A",
                    version_file="pyproject.toml",
                    publish_name="@scope/pkgA",
                    scopes=[],
                ),
                ReleasePackage(
                    name="pkgB", path="apps/B", version_file="package.json", scopes=[]
                ),
            ],
            target_branch="main",
            release_branch="release-next",
        )

    @pytest.fixture
    def updates(self) -> list[ReleaseUpdate]:
        return [
            ReleaseUpdate(
                component="pkgA",
                component_path="",
                version_file="",
                current_version="1.0.0",
                new_version="2.0.0",
                bump="major",
                changelog="",
            ),
            ReleaseUpdate(
                component="pkgB",
                component_path="",
                version_file="",
                current_version="1.0.0",
                new_version="1.1.0",
                bump="minor",
                changelog="",
            ),
        ]

    def test_not_exists(
        self, tmp_path: Path, config: ReleaseConfig, updates: list[ReleaseUpdate]
    ) -> None:
        _pin_inter_package_dependencies(str(tmp_path / "nope.toml"), updates, config)

    def test_toml_updates(
        self, tmp_path: Path, config: ReleaseConfig, updates: list[ReleaseUpdate]
    ) -> None:
        p = tmp_path / "deps.toml"
        p.write_text(
            'dependencies = ["pkgA>=1.0.0", "other>=1.0"]\npkgB = "1.0.0"\n@scope/pkgA = "1.0.0"'
        )

        _pin_inter_package_dependencies(str(p), updates, config)
        content = p.read_text()

        assert '"pkgA>=2.0.0"' in content
        assert 'pkgB = "1.1.0"' in content
        assert "other>=1.0" in content

    def test_toml_no_changes(
        self, tmp_path: Path, config: ReleaseConfig, updates: list[ReleaseUpdate]
    ) -> None:
        p = tmp_path / "deps.toml"
        p.write_text('dependencies = ["pkgC>=1.0.0"]')

        _pin_inter_package_dependencies(str(p), updates, config)
        assert p.read_text() == 'dependencies = ["pkgC>=1.0.0"]'

    def test_json_updates(
        self, tmp_path: Path, config: ReleaseConfig, updates: list[ReleaseUpdate]
    ) -> None:
        p = tmp_path / "package.json"
        data = {
            "dependencies": {
                "@scope/pkgA": "^1.0.0",
                "pkgB": "workspace:*",
                "other": "1.0.0",
            },
            "@scope/pkgA": "~1.0.0",  # Direct key test
        }
        p.write_text(json.dumps(data))

        _pin_inter_package_dependencies(str(p), updates, config)
        updated = json.loads(p.read_text())

        assert updated["dependencies"]["@scope/pkgA"] == "^2.0.0"
        # Match handles workspace:* correctly typically by using ^ or maintaining prefix.
        # In current implementation, workspace:* falls back to ^new_version
        assert updated["dependencies"]["pkgB"] == "^1.1.0"
        assert updated["dependencies"]["other"] == "1.0.0"
        assert updated["@scope/pkgA"] == "~2.0.0"

    def test_json_decode_error(
        self, tmp_path: Path, config: ReleaseConfig, updates: list[ReleaseUpdate]
    ) -> None:
        p = tmp_path / "pkg.json"
        p.write_text('{"bad json"')
        _pin_inter_package_dependencies(str(p), updates, config)
        assert '{"bad json"' in p.read_text()


class TestGenerateChangelog:
    def test_chore_skipped(self) -> None:
        commits = [
            Commit(
                hash="123",
                subject="chore: build",
                body="",
                type="chore",
                scope="",
                breaking=False,
                description="build",
            )
        ]
        assert _generate_changelog(commits, "1.0.0", "pkg") == ""

    def test_breaking_and_fixes(self) -> None:
        commits = [
            Commit(
                hash="123",
                subject="fix: drop support",
                body="",
                type="fix",
                scope="",
                breaking=True,
                description="drop support",
            ),
            Commit(
                hash="456",
                subject="fix: bug",
                body="",
                type="fix",
                scope="",
                breaking=False,
                description="bug",
            ),
            Commit(
                hash="789",
                subject="feat: new ui",
                body="",
                type="feat",
                scope="",
                breaking=False,
                description="new ui",
            ),
        ]
        log = _generate_changelog(commits, "2.0.0", "pkg")
        assert "## pkg v2.0.0" in log
        assert "### ⚠ BREAKING CHANGES" in log
        assert "- drop support (123)" in log
        assert "### Bug Fixes" in log
        assert "- bug (456)" in log
        assert "### Features" in log
        assert "- new ui (789)" in log

    def test_empty_commits(self) -> None:
        assert _generate_changelog([], "1.0.0", "pkg") == ""


class TestPrependChangelog:
    def test_prepend_existing(self, tmp_path: Path) -> None:
        p = tmp_path / "CHANGELOG.md"
        p.write_text("old stuff")
        _prepend_changelog(str(p), "new stuff\n")
        assert p.read_text() == "new stuff\nold stuff"

    def test_prepend_empty_content(self, tmp_path: Path) -> None:
        p = tmp_path / "CHANGELOG.md"
        p.write_text("old stuff")
        _prepend_changelog(str(p), "")
        assert p.read_text() == "old stuff"
