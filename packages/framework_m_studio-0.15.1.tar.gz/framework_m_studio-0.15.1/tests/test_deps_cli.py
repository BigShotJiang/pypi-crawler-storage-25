"""Tests for Dependency Management CLI."""

from __future__ import annotations

import os
from pathlib import Path
from unittest.mock import AsyncMock, patch

import pytest


class TestDepsHelpers:
    """Tests for internal CLI helpers."""

    def test_push_branch(self) -> None:
        """Should push branch with correct URL."""
        from framework_m_studio.cli.deps import _push_branch

        with (
            patch("framework_m_studio.cli.deps.run_cmd") as mock_run,
            patch.dict(
                "os.environ",
                {"CI_SERVER_HOST": "git.test", "CI_PROJECT_PATH": "org/repo"},
            ),
        ):
            _push_branch("my-branch", "my-token")

        assert mock_run.call_count == 2
        mock_run.assert_any_call(
            "git remote set-url origin https://oauth2:my-token@git.test/org/repo.git"
        )
        mock_run.assert_any_call("git push origin my-branch")


class TestDepsCheck:
    """Tests for deps check command."""

    def test_check_pnpm_outdated_invalid_json(self, tmp_path: Path) -> None:
        """Should handle invalid JSON from pnpm gracefully."""
        from framework_m_studio.cli.deps import _check_pnpm_outdated

        with patch("framework_m_studio.cli.deps.run_cmd", return_value="not json"):
            outdated = _check_pnpm_outdated(tmp_path)
        assert outdated == []

    def test_check_pnpm_outdated_empty_output(self, tmp_path: Path) -> None:
        """Should handle empty output from pnpm."""
        from framework_m_studio.cli.deps import _check_pnpm_outdated

        with patch("framework_m_studio.cli.deps.run_cmd", return_value=""):
            outdated = _check_pnpm_outdated(tmp_path)
        assert outdated == []

    def test_deps_check_uv_parses_output(self, tmp_path: Path) -> None:
        """Should parse uv pip list --outdated output."""
        from framework_m_studio.cli.deps import _check_uv_outdated

        mock_output = (
            "Package      Version Latest Type\n"
            "------------ ------- ------ -----\n"
            "pydantic     2.5.0   2.6.0  wheel\n"
            "litestar     2.0.0   2.5.0  wheel\n"
        )

        with patch("framework_m_studio.cli.deps.run_cmd", return_value=mock_output):
            outdated = _check_uv_outdated(tmp_path)

        assert len(outdated) == 2
        assert outdated[0] == {
            "name": "pydantic",
            "current": "2.5.0",
            "latest": "2.6.0",
        }
        assert outdated[1] == {
            "name": "litestar",
            "current": "2.0.0",
            "latest": "2.5.0",
        }

    def test_deps_check_pnpm_parses_json(self, tmp_path: Path) -> None:
        """Should parse pnpm outdated --format json output."""
        import json

        from framework_m_studio.cli.deps import _check_pnpm_outdated

        # pnpm outdated json format
        mock_output = json.dumps(
            {
                "react": {"current": "18.2.0", "latest": "18.3.0", "dependent": "app"},
                "vite": {"current": "5.0.0", "latest": "5.1.0", "dependent": "app"},
            }
        )

        with patch("framework_m_studio.cli.deps.run_cmd", return_value=mock_output):
            outdated = _check_pnpm_outdated(tmp_path)

        assert len(outdated) == 2
        assert outdated[0] == {"name": "react", "current": "18.2.0", "latest": "18.3.0"}
        assert outdated[1] == {"name": "vite", "current": "5.0.0", "latest": "5.1.0"}

    def test_deps_check_json_output(
        self, tmp_path: Path, capsys: pytest.CaptureFixture[str]
    ) -> None:
        """Should output json if requested."""
        from framework_m_studio.cli.deps import deps_check_command

        mock_outdated = [{"name": "pydantic", "current": "2.5.0", "latest": "2.6.0"}]
        with (
            patch(
                "framework_m_studio.cli.deps._check_uv_outdated",
                return_value=mock_outdated,
            ),
            patch("framework_m_studio.cli.deps._check_pnpm_outdated", return_value=[]),
        ):
            deps_check_command(root=str(tmp_path), json_output=True)

        captured = capsys.readouterr()
        assert '"pydantic"' in captured.out
        assert "2.6.0" in captured.out

    def test_get_workspace_projects(self, tmp_path: Path) -> None:
        """Should discover workspace projects correctly."""
        from framework_m_studio.cli.deps import _get_workspace_projects

        # Test early return
        assert _get_workspace_projects(tmp_path, "uv", updated_packages=[]) == []

        apps = tmp_path / "apps"
        libs = tmp_path / "libs"
        apps.mkdir()
        libs.mkdir()

        # hidden dir and regular file to trigger skips
        (apps / ".hidden").mkdir()
        (apps / "file.txt").touch()

        # valid uv project
        p1 = apps / "studio"
        p1.mkdir()
        (p1 / "pyproject.toml").write_text(
            'name = "framework-m-studio"\ndependencies = ["some-dep"]\n'
        )

        # valid pnpm project
        p2 = libs / "ui"
        p2.mkdir()
        (p2 / "package.json").write_text(
            '{"name": "@framework-m/ui", "dependencies": {"react": "*"}}'
        )

        # pnpm project missing name
        p2_no_name = libs / "no_name"
        p2_no_name.mkdir()
        (p2_no_name / "package.json").write_text('{"dependencies": {"react": "*"}}')

        # pnpm project not matching dep
        p2_no_match = libs / "no_match"
        p2_no_match.mkdir()
        (p2_no_match / "package.json").write_text(
            '{"name": "no-match", "dependencies": {"other": "*"}}'
        )

        # corrupted pnpm
        p3 = apps / "bad_pnpm"
        p3.mkdir()
        (p3 / "package.json").write_text("{invalid js}")

        # corrupted uv
        p4 = apps / "bad_uv"
        p4.mkdir()
        (p4 / "pyproject.toml").mkdir()

        uv_projects = _get_workspace_projects(
            tmp_path, manager="uv", updated_packages=["some-dep"]
        )
        assert uv_projects == ["framework-m-studio"]

        pnpm_projects = _get_workspace_projects(
            tmp_path, manager="pnpm", updated_packages=["react"]
        )
        assert pnpm_projects == ["@framework-m/ui"]


class TestDepsUpgrade:
    """Tests for deps upgrade command."""

    @pytest.mark.asyncio
    async def test_deps_upgrade_uv_runs_lock_command(self, tmp_path: Path) -> None:
        """Should run uv lock --upgrade-package."""
        from framework_m_studio.cli.deps import deps_upgrade_command

        mock_provider = AsyncMock()

        with (
            patch("framework_m_studio.cli.deps.run_cmd") as mock_run,
            patch(
                "framework_m_studio.cli.deps.GitLabProvider", return_value=mock_provider
            ),
            patch("framework_m_studio.cli.deps._push_branch"),
        ):
            await deps_upgrade_command(
                package="pydantic",
                manager="uv",
                provider="gitlab",
                token="fake",
                project_id="123",
                dry_run=False,
                root=str(tmp_path),
            )

        mock_run.assert_any_call(
            "uv lock --upgrade-package pydantic", cwd=Path(tmp_path)
        )

    @pytest.mark.asyncio
    async def test_deps_upgrade_creates_mr_via_provider(self, tmp_path: Path) -> None:
        """Should push branch and create MR."""
        from framework_m_studio.cli.deps import deps_upgrade_command

        mock_provider = AsyncMock()

        with (
            patch("framework_m_studio.cli.deps.run_cmd"),
            patch(
                "framework_m_studio.cli.deps.GitLabProvider", return_value=mock_provider
            ),
            patch("framework_m_studio.cli.deps._push_branch"),
        ):
            await deps_upgrade_command(
                package="pydantic",
                manager="uv",
                provider="gitlab",
                token="fake",
                project_id="123",
                dry_run=False,
                root=str(tmp_path),
            )

        mock_provider.create_mr.assert_called_once()
        kwargs = mock_provider.create_mr.call_args.kwargs
        assert "pydantic" in kwargs["title"]  # Title should contain package name

    @pytest.mark.asyncio
    async def test_deps_upgrade_dry_run_skips_push_and_mr(self, tmp_path: Path) -> None:
        """Should skip remote operations if dry_run=True."""
        from framework_m_studio.cli.deps import deps_upgrade_command

        with (
            patch("framework_m_studio.cli.deps.run_cmd") as mock_run,
            patch("framework_m_studio.cli.deps.GitLabProvider") as mock_provider,
        ):
            await deps_upgrade_command(
                package="pydantic",
                manager="uv",
                provider="gitlab",
                token="fake",
                project_id="123",
                dry_run=True,
                root=str(tmp_path),
            )

        mock_provider.assert_not_called()
        cmds = [call.args[0] for call in mock_run.call_args_list]
        assert not any("git push" in str(cmd) for cmd in cmds)

    @pytest.mark.asyncio
    async def test_deps_upgrade_pnpm(self, tmp_path: Path) -> None:
        """Should correctly call pnpm for upgrades."""
        from framework_m_studio.cli.deps import deps_upgrade_command

        mock_provider = AsyncMock()

        with (
            patch("framework_m_studio.cli.deps.run_cmd") as mock_run,
            patch(
                "framework_m_studio.cli.deps.GitLabProvider", return_value=mock_provider
            ),
            patch("framework_m_studio.cli.deps._push_branch"),
        ):
            await deps_upgrade_command(
                package="react",
                manager="pnpm",
                provider="gitlab",
                token="fake",
                project_id="123",
                dry_run=False,
                root=str(tmp_path),
            )
        mock_run.assert_any_call("pnpm update -r react", cwd=Path(tmp_path))

    @pytest.mark.asyncio
    async def test_deps_upgrade_all_uv(self, tmp_path: Path) -> None:
        """Should upgrade all uv packages."""
        from framework_m_studio.cli.deps import deps_upgrade_command

        mock_provider = AsyncMock()
        mock_outdated = [{"name": "fastapi", "current": "0.100", "latest": "0.101"}]

        def mock_run_cmd(*args: object, **kwargs: object) -> str:
            cmd = args[0]
            cmd_str = " ".join(cmd) if isinstance(cmd, list) else str(cmd)
            if "git status" in cmd_str:
                return "M somefile"
            return ""

        with (
            patch(
                "framework_m_studio.cli.deps.run_cmd", side_effect=mock_run_cmd
            ) as mock_run,
            patch(
                "framework_m_studio.cli.deps._check_uv_outdated",
                return_value=mock_outdated,
            ),
            patch(
                "framework_m_studio.cli.deps.GitLabProvider", return_value=mock_provider
            ),
            patch("framework_m_studio.cli.deps._push_branch"),
            patch(
                "framework_m_studio.cli.deps._get_workspace_projects",
                return_value=["app1"],
            ),
        ):
            await deps_upgrade_command(
                package=None,
                manager="uv",
                provider="gitlab",
                token="fake",
                project_id="123",
                dry_run=False,
                root=str(tmp_path),
            )

        git_commits = [
            call for call in mock_run.call_args_list if "commit" in str(call.args[0])
        ]
        assert len(git_commits) > 0
        cmd_args = git_commits[0].args[0]
        assert "fix(uv): update dependencies" in cmd_args
        assert "Releases: app1" in str(cmd_args)

    @pytest.mark.asyncio
    async def test_deps_upgrade_all_pnpm(self, tmp_path: Path) -> None:
        """Should upgrade all pnpm packages."""
        from framework_m_studio.cli.deps import deps_upgrade_command

        mock_provider = AsyncMock()
        mock_outdated = [{"name": "react", "current": "17", "latest": "18"}]

        def mock_run_cmd(*args: object, **kwargs: object) -> str:
            cmd = args[0]
            cmd_str = " ".join(cmd) if isinstance(cmd, list) else str(cmd)
            if "git status" in cmd_str:
                return "M somefile"
            return ""

        with (
            patch(
                "framework_m_studio.cli.deps.run_cmd", side_effect=mock_run_cmd
            ) as mock_run,
            patch(
                "framework_m_studio.cli.deps._check_pnpm_outdated",
                return_value=mock_outdated,
            ),
            patch(
                "framework_m_studio.cli.deps.GitLabProvider", return_value=mock_provider
            ),
            patch("framework_m_studio.cli.deps._push_branch"),
            patch(
                "framework_m_studio.cli.deps._get_workspace_projects",
                return_value=["app2"],
            ),
        ):
            await deps_upgrade_command(
                package=None,
                manager="pnpm",
                provider="gitlab",
                token="fake",
                project_id="123",
                dry_run=False,
                root=str(tmp_path),
            )

        git_commits = [
            call for call in mock_run.call_args_list if "commit" in str(call.args[0])
        ]
        assert len(git_commits) > 0
        cmd_args = git_commits[0].args[0]
        assert "fix(pnpm): update dependencies" in cmd_args
        assert "Releases: app2" in str(cmd_args)

    @pytest.mark.asyncio
    async def test_deps_upgrade_unknown_manager(
        self, tmp_path: Path, capsys: pytest.CaptureFixture[str]
    ) -> None:
        """Should print error for unknown manager."""
        from framework_m_studio.cli.deps import deps_upgrade_command

        await deps_upgrade_command(
            package="pydantic", manager="yarn", root=str(tmp_path)
        )
        captured = capsys.readouterr()
        assert "Unknown manager: yarn" in captured.err

    @pytest.mark.asyncio
    async def test_deps_upgrade_no_changes(
        self, tmp_path: Path, capsys: pytest.CaptureFixture[str]
    ) -> None:
        """Should skip MR creation if no git changes are detected."""
        from framework_m_studio.cli.deps import deps_upgrade_command

        def mock_run_cmd(cmd: str, **kwargs: object) -> str:
            if "git status" in cmd:
                return ""  # No changes
            return "output"

        with (
            patch("framework_m_studio.cli.deps.run_cmd", side_effect=mock_run_cmd),
            patch("framework_m_studio.cli.deps.GitLabProvider") as mock_provider,
        ):
            await deps_upgrade_command(
                package="pydantic", manager="uv", root=str(tmp_path)
            )

        captured = capsys.readouterr()
        assert "No changes found" in captured.out
        mock_provider.assert_not_called()

    @pytest.mark.asyncio
    async def test_deps_upgrade_no_token(
        self, tmp_path: Path, capsys: pytest.CaptureFixture[str]
    ) -> None:
        """Should skip push and MR if no token is provided."""
        from framework_m_studio.cli.deps import deps_upgrade_command

        with (
            patch("framework_m_studio.cli.deps.run_cmd", return_value="M somefile"),
            patch("framework_m_studio.cli.deps._push_branch") as mock_push,
            patch("framework_m_studio.cli.deps.GitLabProvider"),
            patch.dict(os.environ, clear=True),
        ):
            await deps_upgrade_command(
                package="pydantic",
                manager="uv",
                token=None,  # No token
                root=str(tmp_path),
            )
        captured = capsys.readouterr()
        assert "Skipping push and MR: No token provided" in captured.err
        mock_push.assert_not_called()

    @pytest.mark.asyncio
    async def test_deps_upgrade_all_uv_no_outdated(
        self, tmp_path: Path, capsys: pytest.CaptureFixture[str]
    ) -> None:
        """Should exit early if no packages are outdated."""
        from framework_m_studio.cli.deps import deps_upgrade_command

        with patch("framework_m_studio.cli.deps._check_uv_outdated", return_value=[]):
            await deps_upgrade_command(package=None, manager="uv", root=str(tmp_path))

        captured = capsys.readouterr()
        assert "All uv dependencies are up to date." in captured.out

    @pytest.mark.asyncio
    async def test_deps_upgrade_skip_branch(
        self, tmp_path: Path, capsys: pytest.CaptureFixture[str]
    ) -> None:
        """Should skip branch creation if skip_branch is True."""
        from framework_m_studio.cli.deps import deps_upgrade_command

        def mock_run_cmd(*args: object, **kwargs: object) -> str:
            cmd = args[0]
            cmd_str = " ".join(cmd) if isinstance(cmd, list) else str(cmd)
            if "git status" in cmd_str:
                return "M uv.lock"
            return ""

        with patch("framework_m_studio.cli.deps.run_cmd", side_effect=mock_run_cmd):
            await deps_upgrade_command(
                package="pydantic",
                manager="uv",
                root=str(tmp_path),
                skip_branch=True,
            )

        captured = capsys.readouterr()
        assert "skipping branch/commit as requested" in captured.out

    def test_deps_check_non_json_output(
        self, tmp_path: Path, capsys: pytest.CaptureFixture[str]
    ) -> None:
        """Should print to console for non-json output."""
        from framework_m_studio.cli.deps import deps_check_command

        mock_outdated = [{"name": "pydantic", "current": "2.5.0", "latest": "2.6.0"}]
        with (
            patch(
                "framework_m_studio.cli.deps._check_uv_outdated",
                return_value=mock_outdated,
            ),
            patch("framework_m_studio.cli.deps._check_pnpm_outdated", return_value=[]),
        ):
            deps_check_command(root=str(tmp_path), json_output=False)

        captured = capsys.readouterr()
        assert "pydantic: 2.5.0 -> 2.6.0" in captured.out
