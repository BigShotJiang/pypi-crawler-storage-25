"""Tests for Design-Time Role Discovery.

Ensures Studio can discover both Out-Of-The-Box (OOTB) roles and
custom developer-mounted roles in the project root.
"""

import json
from pathlib import Path

from framework_m_studio.core.discovery.roles import discover_roles


def test_discover_roles_loads_ootb_and_project_roles(tmp_path: Path) -> None:
    """It should aggregate internal OOTB roles with project-mounted custom roles."""
    # Setup a fake project root
    project_root = tmp_path
    project_roles_dir = project_root / "roles"
    project_roles_dir.mkdir()

    # Create a mock project role file
    custom_roles = {
        "domain": "CustomApp",
        "roles": [
            {"name": "Custom Manager", "description": "Project specific role"},
            {"name": "System Manager", "description": "Overridden description"},
        ],
    }
    (project_roles_dir / "custom.json").write_text(
        json.dumps(custom_roles), encoding="utf-8"
    )

    # Run discovery
    roles = discover_roles(project_root)
    role_dict = {r.name: r for r in roles}

    # Should contain OOTB roles (standard.json)
    assert "Guest" in role_dict

    # Should contain project roles
    assert "Custom Manager" in role_dict

    # Project roles should override OOTB descriptions if names match
    assert role_dict["System Manager"].description == "Overridden description"
