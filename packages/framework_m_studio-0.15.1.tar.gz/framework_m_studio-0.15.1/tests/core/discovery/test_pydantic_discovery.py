"""Tests for Pydantic Decorator Discovery.

TDD tests for AST-based discovery of Pydantic validator logic in DocTypes.
Ensures the Studio can detect manual validation logic added by developers.
"""

from textwrap import dedent

import pytest

# This import will intentionally fail initially, fulfilling the first step of TDD
from framework_m_studio.core.discovery.pydantic import discover_validators


@pytest.fixture
def sample_doctype_with_validators() -> str:
    """Fixture providing a sample DocType with Pydantic validators."""
    return dedent('''\
        from framework_m_core.domain.base_doctype import BaseDocType, Field
        from pydantic import field_validator

        class UserProfile(BaseDocType):
            """User Profile DocType."""
            email: str = Field(description="Email address")
            age: int = Field(default=18)
            
            @field_validator("email")
            @classmethod
            def validate_email_domain(cls, v: str) -> str:
                """Ensure email belongs to company domain."""
                if not v.endswith("@company.com"):
                    raise ValueError("Must be a company email")
                return v

            @field_validator("age")
            @classmethod
            def validate_age(cls, v: int) -> int:
                if v < 18:
                    raise ValueError("Must be at least 18")
                return v
    ''')


def test_discover_field_validators(sample_doctype_with_validators: str) -> None:
    """Test discovery of @field_validator decorators."""
    validators = discover_validators(sample_doctype_with_validators)

    assert validators is not None
    assert len(validators) == 2
    assert validators[0].name == "validate_email_domain"
    assert "email" in validators[0].fields
