"""Tests for GitOps Providers (Ports and Adapters)."""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch

import pytest


class TestGitProviderProtocol:
    """Test that the Protocol defines the required interface."""

    def test_protocol_exists(self) -> None:
        """GitProviderProtocol should be importable."""
        from framework_m_studio.core.gitops import GitProviderProtocol

        assert GitProviderProtocol is not None


class TestGitLabProvider:
    """Tests for the GitLab adapter."""

    def test_initialization(self) -> None:
        """Should initialize with token and project path/id."""
        from framework_m_studio.core.gitops import GitLabProvider

        provider = GitLabProvider(token="test-token", project_id="123")
        assert provider.token == "test-token"
        assert provider.project_id == "123"

    @pytest.mark.asyncio
    async def test_find_mr_exists(self) -> None:
        """Should return MR dict if a matching open MR exists."""
        from framework_m_studio.core.gitops import GitLabProvider

        provider = GitLabProvider(token="test-token", project_id="123")

        with patch("httpx.AsyncClient.request", new_callable=AsyncMock) as mock_request:
            mock_response = MagicMock()
            mock_response.status_code = 200
            mock_response.json.return_value = [{"iid": 42, "web_url": "https://url"}]
            mock_request.return_value = mock_response

            mr = await provider.find_mr("release/next")

            assert mr is not None
            assert mr["iid"] == 42
            mock_request.assert_called_once()

    @pytest.mark.asyncio
    async def test_create_mr(self) -> None:
        """Should create an MR and return the data."""
        from framework_m_studio.core.gitops import GitLabProvider

        provider = GitLabProvider(token="test-token", project_id="123")

        with patch("httpx.AsyncClient.request", new_callable=AsyncMock) as mock_request:
            mock_response = MagicMock()
            mock_response.raise_for_status.return_value = None
            mock_response.json.return_value = {"iid": 43, "web_url": "https://url"}
            mock_request.return_value = mock_response

            mr = await provider.create_mr("Title", "Description", "release/next")
            assert mr["iid"] == 43

    @pytest.mark.asyncio
    async def test_update_mr(self) -> None:
        """Should update an existing MR."""
        from framework_m_studio.core.gitops import GitLabProvider

        provider = GitLabProvider(token="test-token", project_id="123")

        with patch("httpx.AsyncClient.request", new_callable=AsyncMock) as mock_request:
            mock_response = MagicMock()
            mock_response.raise_for_status.return_value = None
            mock_request.return_value = mock_response

            await provider.update_mr(42, "New Title", "New Desc")

    @pytest.mark.asyncio
    async def test_create_release(self) -> None:
        """Should make a POST request to the releases endpoint."""
        from framework_m_studio.core.gitops import GitLabProvider

        provider = GitLabProvider("token", "proj_id")

        with patch("httpx.AsyncClient.request", new_callable=AsyncMock) as mock_request:
            mock_response = MagicMock()
            mock_response.status_code = 201
            mock_response.json.return_value = {"tag_name": "v1.0.0"}
            mock_request.return_value = mock_response

            result = await provider.create_release("v1.0.0", "Release Description")

            assert result == {"tag_name": "v1.0.0"}
            mock_request.assert_called_once()

    @pytest.mark.asyncio
    async def test_request_retries_on_502(self) -> None:
        """Should retry requests on 502, 503, and 504 HTTP status codes."""
        from framework_m_studio.core.gitops import GitLabProvider

        provider = GitLabProvider("token", "proj_id")

        with (
            patch("httpx.AsyncClient.request", new_callable=AsyncMock) as mock_request,
            patch("asyncio.sleep", new_callable=AsyncMock) as mock_sleep,
        ):
            fail_resp = MagicMock(status_code=502)
            success_resp = MagicMock(status_code=200)
            success_resp.json.return_value = [{"iid": 1}]
            mock_request.side_effect = [fail_resp, success_resp]

            await provider.find_mr("release/next")

            assert mock_request.call_count == 2
            assert mock_sleep.call_count == 1
