"""Tests for FSCodeRepository.

TDD tests for File System Metadata eXchange Repository.
Ensures it adheres to the basic RepositoryProtocol expectations
for reading and writing code as data.
"""

from pathlib import Path

import pytest

# This import will intentionally fail initially, fulfilling the first step of TDD
from framework_m_studio.core.repositories.fs_mx_repo import FSCodeRepository


@pytest.fixture
def temp_workspace(tmp_path: Path) -> Path:
    """Fixture providing a temporary workspace directory for testing."""
    workspace = tmp_path / "src" / "my_app" / "doctypes"
    workspace.mkdir(parents=True, exist_ok=True)
    return workspace


@pytest.mark.asyncio
async def test_fs_repo_instantiation(temp_workspace: Path) -> None:
    """Test that FSCodeRepository can be instantiated with a workspace."""
    repo = FSCodeRepository(base_path=temp_workspace)
    assert repo is not None


@pytest.mark.asyncio
async def test_fs_repo_get_missing_doc(temp_workspace: Path) -> None:
    """Test getting a document that does not exist returns None."""
    repo = FSCodeRepository(base_path=temp_workspace)

    # In our implementation, 'id' maps to the exact DocType name (e.g., 'Customer')
    # which the repository will resolve to the file path.
    doc = await repo.get("Customer")
    assert doc is None


@pytest.mark.asyncio
async def test_fs_repo_save_new_doc(temp_workspace: Path) -> None:
    """Test saving a new document creates a corresponding Python file."""
    repo = FSCodeRepository(base_path=temp_workspace)

    doc_data = {"name": "TestDoc"}
    saved_doc = await repo.save(doc_data)

    expected_file = temp_workspace / "test_doc.py"
    assert expected_file.exists()
    assert saved_doc == doc_data


@pytest.mark.asyncio
async def test_fs_repo_save_normalizes_snake_case_name(temp_workspace: Path) -> None:
    """Test saving a snake_case document normalizes its name to PascalCase."""
    repo = FSCodeRepository(base_path=temp_workspace)

    doc_data = {"name": "my_custom_doc"}
    saved_doc = await repo.save(doc_data)

    # Name inside the returned doc should be modified to PascalCase
    assert saved_doc["name"] == "MyCustomDoc"

    # The physical file should still map to the snake_case format
    expected_file = temp_workspace / "my_custom_doc.py"
    assert expected_file.exists()


@pytest.mark.asyncio
async def test_fs_repo_delete_and_exists(temp_workspace: Path) -> None:
    """Test checking existence and deleting a document file."""
    repo = FSCodeRepository(base_path=temp_workspace)
    await repo.save({"name": "DocToDelete"})

    assert await repo.exists("DocToDelete") is True
    await repo.delete("DocToDelete")
    assert await repo.exists("DocToDelete") is False


@pytest.mark.asyncio
async def test_fs_repo_list_docs(temp_workspace: Path) -> None:
    """Test listing documents returns items matching the Python files in the workspace."""
    repo = FSCodeRepository(base_path=temp_workspace)
    await repo.save({"name": "AlphaDoc"})
    await repo.save({"name": "BetaDoc"})

    result = await repo.list()
    assert result.total == 2


@pytest.mark.asyncio
async def test_fs_repo_save_validation(temp_workspace: Path) -> None:
    """Test save fails with invalid input."""
    repo = FSCodeRepository(base_path=temp_workspace)
    with pytest.raises(ValueError, match="Entity must be a dictionary"):
        await repo.save("not a dict")
    with pytest.raises(
        ValueError, match="Entity must be a dictionary with a 'name' key"
    ):
        await repo.save({"not_name": "value"})


@pytest.mark.asyncio
async def test_fs_repo_list_missing_base_path(tmp_path: Path) -> None:
    """Test listing on a non-existent directory returns empty result."""
    repo = FSCodeRepository(base_path=tmp_path / "non_existent")
    result = await repo.list()
    assert result.items == []
    assert result.total == 0
