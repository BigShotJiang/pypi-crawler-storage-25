"""Tests for Augmentation CodeGen.

TDD tests for generating DocType extensions/overlays.
Ensures we can cleanly augment 3rd-party apps without modifying their source code.
"""

# This import will intentionally fail initially, fulfilling the first step of TDD
from framework_m_studio.core.codegen.augmentation_gen import (
    generate_augmentation_source,
)


def test_generate_augmentation_basic() -> None:
    """Test generating a basic augmentation DocType."""
    schema = {
        "target_name": "Customer",
        "target_module": "erp_core.doctypes.customer.doctype",
        "app_name": "my_custom_app",
        "fields": [
            {"name": "loyalty_points", "type": "int", "default": "0"},
        ],
    }

    code = generate_augmentation_source(schema)

    assert "class CustomerExt(Customer):" in code
    assert "from erp_core.doctypes.customer.doctype import Customer" in code
    assert "loyalty_points: int = 0" in code
    assert "class Meta:" in code
    assert 'extends: ClassVar[str] = "Customer"' in code
    assert "is_metadata_overlay: ClassVar[bool] = True" in code
