"""Tests for Surgical CST Mutator.

TDD tests for targeted AST/CST modifications using LibCST.
Ensures we can add, update, and remove fields from a DocType definition
without losing comments or custom methods.
"""

from textwrap import dedent

import pytest

# This import will intentionally fail initially, fulfilling the first step of TDD
from framework_m_studio.core.adapters.cst.mutator import DocTypeMutator


@pytest.fixture
def sample_doctype_source() -> str:
    """Fixture providing a sample DocType with comments and methods."""
    return dedent('''\
        from framework_m_core.domain.base_doctype import BaseDocType, Field

        class Customer(BaseDocType):
            """Customer DocType."""
            # This is a comment we want to keep
            name: str = Field(description="Customer Name")
            email: str | None = None

            def custom_method(self) -> str:
                # Custom logic here
                return f"{self.name} <{self.email}>"
    ''')


def test_mutator_instantiation(sample_doctype_source: str) -> None:
    """Test that DocTypeMutator can be instantiated with source code."""
    mutator = DocTypeMutator(source=sample_doctype_source)
    assert mutator is not None


def test_mutator_add_field(sample_doctype_source: str) -> None:
    """Test adding a new field to the DocType preserves the rest of the class."""
    mutator = DocTypeMutator(source=sample_doctype_source)

    new_source = mutator.add_field("phone", "str | None", "None")

    assert "phone: str | None = None" in new_source
    assert "# This is a comment we want to keep" in new_source
    assert "def custom_method(self) -> str:" in new_source


def test_mutator_remove_field(sample_doctype_source: str) -> None:
    """Test removing an existing field from the DocType."""
    mutator = DocTypeMutator(source=sample_doctype_source)
    new_source = mutator.remove_field("email")

    assert "email: str | None = None" not in new_source
    assert "name: str =" in new_source
    assert "def custom_method(self) -> str:" in new_source


def test_mutator_skip_non_doctype() -> None:
    """Test that it skips modifying classes that do not inherit from BaseDocType."""
    code = dedent("""\
        class RegularClass:
            pass
    """)
    mutator = DocTypeMutator(source=code)
    new_source = mutator.add_field("phone", "str")
    assert "phone" not in new_source


def test_mutator_add_field_before_method() -> None:
    """Test that it inserts before a method when no fields exist."""
    code = dedent('''\
        class Customer(BaseDocType):
            """Docstring."""
            def my_method(self) -> None:
                pass
    ''')
    mutator = DocTypeMutator(source=code)
    new_source = mutator.add_field("phone", "str")
    assert "phone: str" in new_source

    # Ensure it's before the method
    assert new_source.find("phone: str") < new_source.find("def my_method")


def test_mutator_add_field_empty_class() -> None:
    """Test that it inserts after pass in an empty class."""
    code = dedent("""\
        class Customer(BaseDocType):
            pass
    """)
    mutator = DocTypeMutator(source=code)
    new_source = mutator.add_field("phone", "str")
    assert "phone: str" in new_source
