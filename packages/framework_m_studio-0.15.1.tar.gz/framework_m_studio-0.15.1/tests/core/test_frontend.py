"""Tests for frontend plugin discovery and configuration utilities."""

from __future__ import annotations

from pathlib import Path
from unittest.mock import MagicMock, patch

from framework_m_studio.core.frontend import (
    FrontendPluginInfo,
    discover_frontend_plugins,
    generate_plugin_entry,
)


class TestDiscoverFrontendPlugins:
    def test_discover_local_apps(self, tmp_path: Path) -> None:
        """Should discover plugins from local apps/ directory."""
        apps_dir = tmp_path / "apps"
        apps_dir.mkdir()
        app1 = apps_dir / "custom_app"
        app1.mkdir()
        (app1 / "frontend").mkdir()
        (app1 / "frontend" / "index.ts").write_text("// Plugin 1")

        with (
            patch("importlib.metadata.entry_points", return_value=[]),
            patch("framework_m_studio.core.frontend.Path.cwd", return_value=tmp_path),
        ):
            plugins = discover_frontend_plugins()

        assert len(plugins) == 1
        assert plugins[0]["name"] == "custom_app"
        assert plugins[0]["source"] == "local"

    def test_discover_installed_plugins(self) -> None:
        """Should discover plugins from Python entry points."""
        mock_ep = MagicMock()
        mock_ep.name = "business_m"
        mock_ep.module = "business_m.frontend:plugin"

        mock_files = MagicMock()
        mock_frontend = MagicMock()
        mock_frontend.is_dir.return_value = True
        mock_index = MagicMock()
        mock_index.is_file.return_value = True
        mock_index.__str__.return_value = "/path/to/business_m/frontend/index.ts"
        mock_frontend.__truediv__.return_value = mock_index
        mock_files.__truediv__.return_value = mock_frontend

        with (
            patch("importlib.metadata.entry_points", return_value=[mock_ep]),
            patch("importlib.resources.files", return_value=mock_files),
            patch(
                "framework_m_studio.core.frontend.Path.cwd",
                return_value=Path("/nonexistent"),
            ),
        ):
            plugins = discover_frontend_plugins()

        assert len(plugins) == 1
        assert plugins[0]["name"] == "business_m"
        assert plugins[0]["source"] == "installed"
        assert plugins[0]["package"] == "business_m"


class TestGeneratePluginEntry:
    def test_generate_entry_local_plugins(self, tmp_path: Path) -> None:
        """Should generate entry file with relative imports for local plugins."""
        plugins: list[FrontendPluginInfo] = [
            FrontendPluginInfo(
                name="test_app",
                path=tmp_path / "apps" / "test_app" / "frontend" / "index.ts",
                source="local",
                package=None,
            )
        ]
        entry_file = tmp_path / "entry.tsx"

        with patch("framework_m_studio.core.frontend.Path.cwd", return_value=tmp_path):
            generate_plugin_entry(entry_file, plugins)

        content = entry_file.read_text()
        assert "../../apps/test_app/frontend/index.ts" in content
        assert "register_test_app" in content
        assert "registerAllPlugins" in content
