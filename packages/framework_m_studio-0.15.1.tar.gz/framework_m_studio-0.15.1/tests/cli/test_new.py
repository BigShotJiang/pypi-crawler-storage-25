"""Tests for new CLI command.

This module tests the m new commands:
- App scaffolding
- Frontend plugin scaffolding (MFE support)
- Frontend template initialization (formerly m init:frontend)
"""

from __future__ import annotations

import subprocess
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from framework_m_studio.cli.new import (
    _install_dependencies,
    new_app_command,
    new_frontend_command,
)


class TestNewAppCommand:
    """Tests for new_app_command."""

    def test_scaffolds_app_structure(self, tmp_path: Path) -> None:
        """Should create basic app structure."""
        app_name = "my_app"

        # Mock get_version to avoid import errors if packages aren't installed
        with patch("framework_m_studio.cli.new.get_version", return_value="0.0.0"):
            new_app_command(name=app_name, output_dir=tmp_path)

        app_dir = tmp_path / "my_app"
        assert app_dir.exists()
        assert (app_dir / "pyproject.toml").exists()
        assert (app_dir / "src" / "my_app" / "doctypes").exists()

    def test_scaffolds_frontend_with_mfe_config(self, tmp_path: Path) -> None:
        """Should create frontend with MFE configuration when requested."""
        app_name = "mfe_app"

        # Mock install_dependencies as it requires a workspace/pnpm
        with (
            patch("framework_m_studio.cli.new.get_version", return_value="0.0.0"),
            patch("framework_m_studio.cli.new._install_dependencies"),
        ):
            new_app_command(name=app_name, output_dir=tmp_path, with_frontend=True)

        frontend_dir = tmp_path / "mfe_app" / "frontend"
        assert frontend_dir.exists()

        # Verify MFE specific files
        assert (frontend_dir / "vite.config.mfe.ts").exists()
        assert (frontend_dir / "package.json").exists()

        # Verify package.json content has MFE scripts
        package_json = (frontend_dir / "package.json").read_text()
        assert "build:mfe" in package_json
        assert "vite build -c vite.config.mfe.ts" in package_json
        assert "@framework-m/vite-plugin" in package_json


class TestInstallDependencies:
    """Tests for _install_dependencies helper."""

    @patch("framework_m_studio.cli.new.run_cmd")
    def test_runs_pnpm_install(self, mock_run: MagicMock, tmp_path: Path) -> None:
        """Should execute pnpm install in target directory."""
        target = tmp_path / "frontend"
        target.mkdir()

        _install_dependencies(target)

        mock_run.assert_called_once_with(
            "pnpm install",
            cwd=str(target),
            capture_output=False,
        )

    @patch("framework_m_studio.cli.new.run_cmd")
    def test_raises_runtime_error_on_install_failure(
        self, mock_run: MagicMock, tmp_path: Path
    ) -> None:
        """Should raise RuntimeError if pnpm install fails."""
        mock_run.side_effect = subprocess.CalledProcessError(1, "pnpm")
        target = tmp_path / "frontend"
        target.mkdir()

        with pytest.raises(RuntimeError, match="Failed to install dependencies"):
            _install_dependencies(target)


class TestNewFrontendCommand:
    """Tests for new_frontend_command entry point."""

    def test_initializes_frontend_with_custom_path(self, tmp_path: Path) -> None:
        """Should initialize frontend at custom path."""
        custom_target = tmp_path / "custom-frontend"

        # Mock only the install step (let copy run to validate structure)
        with patch("framework_m_studio.cli.new._install_dependencies"):
            new_frontend_command(target=custom_target)

            # Verify files were copied
            assert custom_target.exists()
            assert (custom_target / "package.json").exists()


class TestNewCLIIntegration:
    """Integration tests for m new:frontend command."""

    def test_new_frontend_command_available(self) -> None:
        """m new:frontend command should be registered."""
        import os

        env = os.environ.copy()
        env["COLUMNS"] = "120"

        import sys

        result = subprocess.run(
            [sys.executable, "-m", "framework_m.cli.main", "new", "frontend", "--help"],
            capture_output=True,
            text=True,
            env=env,
        )
        assert result.returncode == 0
        assert "Initialize a new frontend from template" in result.stdout

    def test_new_frontend_command_shows_target_parameter(self) -> None:
        """m new:frontend --help should show target parameter."""
        import sys

        result = subprocess.run(
            [sys.executable, "-m", "framework_m.cli.main", "new", "frontend", "--help"],
            capture_output=True,
            text=True,
        )
        assert "target" in result.stdout.lower()
        assert "frontend" in result.stdout.lower()

    def test_template_source_exists_in_package(self) -> None:
        """Plugin templates should exist in the studio package."""
        studio_root = Path(__file__).parents[2] / "src" / "framework_m_studio"
        template_source = studio_root / "templates" / "plugin"

        assert template_source.exists(), "Plugin templates should exist"
        assert (template_source / "package.json.template").exists()
        assert (template_source / "vite.config.ts.template").exists()
        assert (template_source / "index.tsx.template").exists()
        assert (template_source / ".gitignore.template").exists()
