"""Tests for verify CLI commands."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest

# The implementation will be created in the next step
from framework_m_studio.cli.verify import verify_mfe_command


class TestVerifyMfeCommand:
    """Tests for m verify:mfe command."""

    @patch("framework_m_studio.cli.verify.files")
    def test_verify_mfe_exists(
        self, mock_files: MagicMock, capsys: pytest.CaptureFixture[str]
    ) -> None:
        """Should return 0 if remoteEntry.js exists in package."""
        mock_traversable = MagicMock()
        mock_files.return_value = mock_traversable

        # Mock existence of remoteEntry.js in package/static/
        (mock_traversable / "static" / "remoteEntry.js").is_file.return_value = True

        with pytest.raises(SystemExit) as exc:
            verify_mfe_command("my_app")

        assert exc.value.code == 0

        captured = capsys.readouterr()
        assert "✓ Verified" in captured.out
        assert "my_app" in captured.out

    @patch("framework_m_studio.cli.verify.files")
    def test_verify_mfe_missing(self, mock_files: MagicMock) -> None:
        """Should exit with 1 if remoteEntry.js is missing."""
        mock_traversable = MagicMock()
        mock_files.return_value = mock_traversable
        (mock_traversable / "static" / "remoteEntry.js").is_file.return_value = False

        with pytest.raises(SystemExit) as exc:
            verify_mfe_command("my_app")

        assert exc.value.code == 1

    def test_verify_mfe_package_not_found(self) -> None:
        """Should exit with 1 if package not installed."""
        # Mock files() raising ImportError (simulating package not found)
        with patch("framework_m_studio.cli.verify.files", side_effect=ImportError):
            with pytest.raises(SystemExit) as exc:
                verify_mfe_command("ghost_app")

            assert exc.value.code == 1
