"""Frontend integration tests for monorepo structure and build configuration."""

from __future__ import annotations

from pathlib import Path

import pytest

PROJECT_ROOT = Path(__file__).parent.parent.parent.parent


@pytest.mark.skipif(
    not (PROJECT_ROOT / "libs/framework-m-desk").exists(),
    reason="@framework-m/desk package not available",
)
class TestDeskPackageStructure:
    """Test @framework-m/desk package structure (fast validation)."""

    def test_package_has_package_json(self) -> None:
        """Test package has package.json."""
        package = PROJECT_ROOT / "libs/framework-m-desk"
        assert (package / "package.json").exists()

    def test_package_has_src_directory(self) -> None:
        """Test package has src directory."""
        package = PROJECT_ROOT / "libs/framework-m-desk"
        assert (package / "src").exists()
        assert (package / "src" / "index.ts").exists()

    def test_package_exports_providers(self) -> None:
        """Test index.ts exports required providers."""
        package = PROJECT_ROOT / "libs/framework-m-desk"
        index_file = package / "src" / "index.ts"
        content = index_file.read_text()

        expected_exports = [
            "frameworkMDataProvider",
            "authProvider",
            "liveProvider",
            "API_URL",
        ]

        for export in expected_exports:
            assert export in content, f"Missing export: {export}"

    def test_package_json_has_correct_config(self) -> None:
        """Test package.json has correct configuration."""
        package = PROJECT_ROOT / "libs/framework-m-desk"
        package_json = package / "package.json"
        content = package_json.read_text()

        assert "@framework-m/desk" in content
        assert "dist/index.js" in content
        assert "peerDependencies" in content


class TestFrontendBuildConfig:
    """Test frontend build configuration (no actual build)."""

    @pytest.mark.skipif(
        not (PROJECT_ROOT / "apps/studio/studio_ui").exists(),
        reason="Frontend template not available",
    )
    def test_vite_config_exists_and_valid(self) -> None:
        """Test vite config file exists and has basic structure."""
        vite_config = PROJECT_ROOT / "apps/studio/studio_ui/vite.config.ts"
        assert vite_config.exists()

        content = vite_config.read_text()
        assert "defineConfig" in content
        assert "plugins" in content

    @pytest.mark.skipif(
        not (PROJECT_ROOT / "frontend").exists(),
        reason="Frontend template not available",
    )
    def test_tsconfig_exists_and_valid(self) -> None:
        """Test TypeScript config exists and has basic structure."""
        tsconfig = PROJECT_ROOT / "frontend/tsconfig.json"
        assert tsconfig.exists()

        content = tsconfig.read_text()
        assert "compilerOptions" in content

    @pytest.mark.skipif(
        not (PROJECT_ROOT / "apps/studio/studio_ui").exists(),
        reason="Frontend template not available",
    )
    def test_npmrc_has_peer_dependency_config(self) -> None:
        """Test .npmrc has peer dependency configuration."""
        npmrc = PROJECT_ROOT / "apps/studio/studio_ui/.npmrc"
        if npmrc.exists():
            content = npmrc.read_text()
            # Should have peer dependency settings for compatibility
            assert (
                "legacy-peer-deps" in content.lower()
                or "strict-peer-dependencies" in content.lower()
            )


class TestPackageJsonOverrides:
    """Test package.json configuration."""

    def test_root_package_json_exists_and_valid(self) -> None:
        """Test root package.json exists and has valid monorepo config."""
        package_json = PROJECT_ROOT / "package.json"
        if package_json.exists():
            content = package_json.read_text()
            import json

            data = json.loads(content)
            # Should be a monorepo with pnpm workspace
            assert data.get("private") is True


class TestAutoFormTypescriptFix:
    """Test AutoForm implementation details."""

    @pytest.mark.skipif(
        not (
            PROJECT_ROOT / "apps/studio/studio_ui/src/components/AutoForm.tsx"
        ).exists(),
        reason="AutoForm component not available",
    )
    def test_autoform_has_field_resolution(self) -> None:
        """Test AutoForm uses resolveFieldComponent."""
        autoform = PROJECT_ROOT / "apps/studio/studio_ui/src/components/AutoForm.tsx"
        content = autoform.read_text()

        # Should import resolveFieldComponent
        assert "resolveFieldComponent" in content
        # Should use FieldData type
        assert "FieldData" in content

    @pytest.mark.skipif(
        not (
            PROJECT_ROOT / "apps/studio/studio_ui/src/components/AutoForm.tsx"
        ).exists(),
        reason="AutoForm component not available",
    )
    def test_autoform_has_validation_logic(self) -> None:
        """Test AutoForm has custom validation logic."""
        autoform = PROJECT_ROOT / "apps/studio/studio_ui/src/components/AutoForm.tsx"
        content = autoform.read_text()

        assert "errors" in content
        assert "validate" in content
        assert "validators" in content
