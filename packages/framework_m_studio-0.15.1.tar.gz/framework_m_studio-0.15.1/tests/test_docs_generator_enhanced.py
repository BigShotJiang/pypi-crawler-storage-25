"""Enhanced Tests for Documentation Generator."""

from __future__ import annotations

import os
from pathlib import Path
from unittest.mock import patch

from framework_m_studio.docs.ast_parsers import (
    generate_hooks_doc,
    generate_protocols_doc,
)
from framework_m_studio.docs.exporters import (
    export_doctypes_yaml,
    export_rag_corpus,
)
from framework_m_studio.docs.formatters import get_source_file_url
from framework_m_studio.docs.generator import (
    generate_api_endpoints_doc,
    generate_cli_reference,
    generate_field_types_doc,
)


def test_get_source_file_url(tmp_path: Path) -> None:
    """Test source file URL generation in various environments."""
    file_path = str(tmp_path / "test.py")

    # Local environment
    with patch.dict(os.environ, {"CI_PROJECT_URL": ""}):
        name, url = get_source_file_url(file_path, tmp_path)
        assert name == "test.py"
        assert url == "test.py"

    # CI environment
    with patch.dict(
        os.environ, {"CI_PROJECT_URL": "http://ci", "CI_COMMIT_REF_NAME": "main"}
    ):
        name, url = get_source_file_url(file_path, tmp_path)
        assert "http://ci/-/blob/main/test.py" in url


def test_generate_field_types_and_api_endpoints() -> None:
    """Test static documentation generation."""
    assert "# Supported Field Types" in generate_field_types_doc()
    assert "# API Endpoints" in generate_api_endpoints_doc()


def test_generate_protocols_doc(tmp_path: Path) -> None:
    """Test generating protocols documentation from source."""
    interfaces_dir = (
        tmp_path
        / "libs"
        / "framework-m-core"
        / "src"
        / "framework_m_core"
        / "interfaces"
    )
    interfaces_dir.mkdir(parents=True)

    (interfaces_dir / "base.py").write_text(
        'from typing import Protocol\nclass BaseProtocol(Protocol):\n    """Doc."""\n    def run(self): pass'
    )

    content = generate_protocols_doc(tmp_path)
    assert "BaseProtocol" in content
    assert "core/interfaces/base.py" in content


def test_generate_hooks_doc(tmp_path: Path) -> None:
    """Test generating hooks documentation from source."""
    controller_file = (
        tmp_path
        / "libs"
        / "framework-m-core"
        / "src"
        / "framework_m_core"
        / "domain"
        / "base_controller.py"
    )
    controller_file.parent.mkdir(parents=True)
    controller_file.write_text(
        'class BaseController:\n    def validate(self): """Val."""\n    pass'
    )

    content = generate_hooks_doc(tmp_path)
    assert "BaseController" in content
    assert "validate" in content


def test_generate_cli_reference(tmp_path: Path) -> None:
    """Test generating CLI reference by mocking run_cmd."""
    mock_help = "Usage: m [OPTIONS] COMMAND [ARGS]...\n\nCommands:\n │ init    Initialize\n │ new     New"
    with patch("framework_m_studio.core.shell.run_cmd", return_value=mock_help):
        content = generate_cli_reference(tmp_path)
        assert "m init" in content or "init" in content


def test_export_rag_corpus(tmp_path: Path) -> None:
    """Test exporting RAG corpus JSONL."""
    output_file = tmp_path / "corpus.jsonl"

    with patch("framework_m_studio.docs.exporters.scan_doctypes", return_value=[]):
        export_rag_corpus(tmp_path, output_file)

    assert output_file.exists()


def test_export_doctypes_yaml(tmp_path: Path) -> None:
    """Test exporting DocTypes as YAML."""
    output_file = tmp_path / "doctypes.yaml"

    with patch("framework_m_studio.docs.exporters.scan_doctypes", return_value=[]):
        export_doctypes_yaml(tmp_path, output_file)

    assert output_file.exists()
