"""Tests for Release GitOps provider methods to increase coverage."""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch

import httpx
import pytest

from framework_m_studio.cli.release.gitops import (
    GitLabProvider,
    _get_commits_since,
    _get_last_tag,
    _parse_commit_message,
    push_release_branch,
)


class TestGitLabProvider:
    @pytest.fixture
    def provider(self) -> GitLabProvider:
        return GitLabProvider("fake-token", "123")

    @pytest.mark.asyncio
    async def test_request_success(self, provider: GitLabProvider) -> None:
        mock_response = MagicMock()
        mock_response.json.return_value = {"success": True}
        mock_response.content = b'{"success": True}'

        mock_client_instance = AsyncMock()
        mock_client_instance.request.return_value = mock_response

        with patch(
            "framework_m_studio.cli.release.gitops.httpx.AsyncClient"
        ) as mock_client:
            mock_client.return_value.__aenter__.return_value = mock_client_instance
            res = await provider._request("GET", "/test")
            assert res == {"success": True}
            mock_client_instance.request.assert_called_once()

    @pytest.mark.asyncio
    async def test_request_http_error(self, provider: GitLabProvider) -> None:
        mock_client_instance = AsyncMock()
        error_response = MagicMock()
        error_response.status_code = 404
        mock_client_instance.request.side_effect = httpx.HTTPStatusError(
            "Not Found", request=MagicMock(), response=error_response
        )

        with patch(
            "framework_m_studio.cli.release.gitops.httpx.AsyncClient"
        ) as mock_client:
            mock_client.return_value.__aenter__.return_value = mock_client_instance
            res = await provider._request("GET", "/test")
            assert res is None

    @pytest.mark.asyncio
    async def test_request_general_error(self, provider: GitLabProvider) -> None:
        mock_client_instance = AsyncMock()
        mock_client_instance.request.side_effect = Exception("General error")

        with patch(
            "framework_m_studio.cli.release.gitops.httpx.AsyncClient"
        ) as mock_client:
            mock_client.return_value.__aenter__.return_value = mock_client_instance
            res = await provider._request("GET", "/test")
            assert res is None

    @pytest.mark.asyncio
    async def test_find_mr(self, provider: GitLabProvider) -> None:
        with patch.object(provider, "_request", new_callable=AsyncMock) as mock_req:
            mock_req.return_value = [{"id": 1, "title": "MR1"}]
            mr = await provider.find_mr("feat-x")
            assert mr == {"id": 1, "title": "MR1"}
            mock_req.assert_called_with(
                "GET", "/merge_requests?source_branch=feat-x&state=opened"
            )

    @pytest.mark.asyncio
    async def test_find_mr_empty(self, provider: GitLabProvider) -> None:
        with patch.object(provider, "_request", new_callable=AsyncMock) as mock_req:
            mock_req.return_value = []
            mr = await provider.find_mr("feat-x")
            assert mr is None

    @pytest.mark.asyncio
    async def test_create_mr(self, provider: GitLabProvider) -> None:
        with patch.object(provider, "_request", new_callable=AsyncMock) as mock_req:
            mock_req.return_value = {"id": 2, "title": "New MR"}
            res = await provider.create_mr("title", "desc", "feat", "main")
            assert res == {"id": 2, "title": "New MR"}

    @pytest.mark.asyncio
    async def test_update_mr(self, provider: GitLabProvider) -> None:
        with patch.object(provider, "_request", new_callable=AsyncMock) as mock_req:
            mock_req.return_value = {"id": 3, "title": "Updated MR"}
            res = await provider.update_mr("3", "New Title", "New Desc")
            assert res == {"id": 3, "title": "Updated MR"}

    @pytest.mark.asyncio
    async def test_create_release(self, provider: GitLabProvider) -> None:
        with patch.object(provider, "_request", new_callable=AsyncMock) as mock_req:
            mock_req.return_value = {"tag_name": "v1.0.0"}
            res = await provider.create_release("v1.0.0", "Release Notes")
            assert res == {"tag_name": "v1.0.0"}


class TestGetLastTag:
    def test_success(self) -> None:
        with patch("framework_m_studio.cli.release.gitops.run_cmd") as mock_run:
            mock_run.return_value = "core@v1.2.3\n"
            tag = _get_last_tag("core")
            assert tag == "core@v1.2.3"

    def test_no_tag_found(self) -> None:
        with patch("framework_m_studio.cli.release.gitops.run_cmd") as mock_run:
            mock_run.side_effect = Exception("No tags")
            assert _get_last_tag("core") is None


class TestGetCommitsSince:
    def test_get_commits(self) -> None:
        fake_log = (
            "hash123\nfeat(core): new feature\nFixes #1\n||COMMIT_SEP||"
            "hash456\nfix: bug\n\n||COMMIT_SEP||"
        )
        with patch("framework_m_studio.cli.release.gitops.run_cmd") as mock_run:
            mock_run.return_value = fake_log
            commits = _get_commits_since("v1.0.0")

        assert len(commits) == 2
        assert commits[0].type == "feat"
        assert commits[0].scope == "core"
        assert commits[0].description == "new feature"
        assert commits[1].type == "fix"


class TestParseCommitMessage:
    def test_parse_valid(self) -> None:
        msg = (
            "feat(auth)!: add oauth\n\nBREAKING CHANGE: api changed\nReleases: packages"
        )
        commit = _parse_commit_message(msg, "hash123")
        assert commit is not None
        assert commit.hash == "hash123"
        assert commit.type == "feat"
        assert commit.scope == "auth"
        assert commit.breaking is True
        assert commit.body_tags == ["packages"]

    def test_parse_invalid(self) -> None:
        assert _parse_commit_message("invalid message") is None


class TestPushReleaseBranch:
    def test_push_success(self) -> None:
        mock_result = MagicMock()
        mock_result.returncode = 0
        with patch("framework_m_studio.cli.release.gitops.subprocess.run") as mock_run:
            mock_run.return_value = mock_result
            push_release_branch("release-v1", "gitlab.com", "org/repo", "token123")
            mock_run.assert_called_once()
            cmd = mock_run.call_args[0][0]
            assert "https://oauth2:token123@gitlab.com/org/repo.git" in cmd

    def test_empty_project_path(self) -> None:
        with pytest.raises(ValueError, match="Git project path is empty"):
            push_release_branch("branch", "host", "", "token")

    def test_push_failure_masks_token(self) -> None:
        mock_result = MagicMock()
        mock_result.returncode = 1
        mock_result.stderr = "fatal: auth failed for token123 at host"

        with patch("framework_m_studio.cli.release.gitops.subprocess.run") as mock_run:
            mock_run.return_value = mock_result
            with pytest.raises(SystemExit):
                push_release_branch("release-v1", "gitlab.com", "org/repo", "token123")

    def test_push_exception_masks_token(self) -> None:
        with patch("framework_m_studio.cli.release.gitops.subprocess.run") as mock_run:
            mock_run.side_effect = Exception("Command failed with token123")
            with pytest.raises(SystemExit):
                push_release_branch("release-v1", "gitlab.com", "org/repo", "token123")
