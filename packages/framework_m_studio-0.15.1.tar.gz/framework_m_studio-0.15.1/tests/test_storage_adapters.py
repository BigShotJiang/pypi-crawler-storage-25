"""Tests for Storage Adapters and Wiki-Style Publishing.

TDD tests for FileAdapter, GitApiAdapter, and the publish flow.
"""

from __future__ import annotations

from pathlib import Path
from unittest.mock import AsyncMock, MagicMock

import pytest

from framework_m_studio.storage.file_adapter import FileAdapter
from framework_m_studio.storage.git_api_adapter import GitApiAdapter
from framework_m_studio.storage.protocol import (
    PublishResult,
    StorageAdapterProtocol,
)


class TestStorageProtocol:
    """Tests for the StorageAdapterProtocol contract."""

    def test_protocol_has_save(self) -> None:
        """Protocol must define a save method."""
        assert hasattr(StorageAdapterProtocol, "save")

    def test_protocol_has_publish(self) -> None:
        """Protocol must define a publish method."""
        assert hasattr(StorageAdapterProtocol, "publish")


class TestFileAdapter:
    """Tests for the local FileAdapter."""

    @pytest.fixture
    def workspace(self, tmp_path: Path) -> Path:
        ws = tmp_path / "workspace"
        ws.mkdir()
        return ws

    @pytest.fixture
    def adapter(self, workspace: Path) -> FileAdapter:
        return FileAdapter(workspace_root=workspace)

    @pytest.mark.asyncio
    async def test_save_creates_file(
        self, adapter: FileAdapter, workspace: Path
    ) -> None:
        """save() must write content to the specified path."""
        await adapter.save(
            "doctypes/invoice/doctype.py",
            "class Invoice: ...\n",
        )

        target = workspace / "doctypes/invoice/doctype.py"
        assert target.exists()
        assert target.read_text() == "class Invoice: ...\n"

    @pytest.mark.asyncio
    async def test_save_creates_parent_dirs(
        self, adapter: FileAdapter, workspace: Path
    ) -> None:
        """save() must create parent directories if they don't exist."""
        await adapter.save("deep/nested/path/file.py", "content")

        assert (workspace / "deep/nested/path/file.py").exists()

    @pytest.mark.asyncio
    async def test_save_overwrites_existing(
        self, adapter: FileAdapter, workspace: Path
    ) -> None:
        """save() must overwrite existing files."""
        file = workspace / "test.py"
        file.write_text("old")

        await adapter.save("test.py", "new")
        assert file.read_text() == "new"

    @pytest.mark.asyncio
    async def test_publish_returns_result(
        self, adapter: FileAdapter, workspace: Path
    ) -> None:
        """publish() on FileAdapter must return a local PublishResult."""
        # Write a file first
        (workspace / "test.py").write_text("content")

        result = await adapter.publish(
            message="feat: add test",
            author="tester",
        )

        assert isinstance(result, PublishResult)
        assert result.success is True
        assert result.adapter_type == "file"


class TestGitApiAdapter:
    """Tests for the Git API adapter (GitHub/GitLab)."""

    @pytest.fixture
    def mock_git(self) -> MagicMock:
        mock = MagicMock()
        mock.commit = AsyncMock(
            return_value=MagicMock(sha="abc123", message="test", files_changed=1)
        )
        mock.push = AsyncMock()
        mock.create_branch = AsyncMock()
        mock.get_current_branch = AsyncMock(return_value="main")
        return mock

    @pytest.fixture
    def adapter(self, mock_git: MagicMock, tmp_path: Path) -> GitApiAdapter:
        return GitApiAdapter(
            git_adapter=mock_git,
            workspace_path=tmp_path,
            repo_url="https://github.com/org/app.git",
            auth_token="token123",
        )

    @pytest.mark.asyncio
    async def test_save_writes_to_workspace(
        self, adapter: GitApiAdapter, tmp_path: Path
    ) -> None:
        """save() must write the file to the local workspace."""
        await adapter.save("my_file.py", "# content\n")

        assert (tmp_path / "my_file.py").exists()
        assert (tmp_path / "my_file.py").read_text() == "# content\n"

    @pytest.mark.asyncio
    async def test_publish_creates_branch(
        self, adapter: GitApiAdapter, mock_git: MagicMock
    ) -> None:
        """publish() must create a feature branch."""
        await adapter.publish(
            message="feat: new doctype",
            author="user@example.com",
        )

        mock_git.create_branch.assert_called_once()
        branch_name = mock_git.create_branch.call_args[0][1]
        assert branch_name.startswith("feature/")

    @pytest.mark.asyncio
    async def test_publish_commits_and_pushes(
        self, adapter: GitApiAdapter, mock_git: MagicMock
    ) -> None:
        """publish() must commit all changes and push."""
        result = await adapter.publish(
            message="feat: update schema",
            author="dev@company.com",
        )

        mock_git.commit.assert_called_once()
        mock_git.push.assert_called_once()
        assert result.success is True
        assert result.commit_sha == "abc123"

    @pytest.mark.asyncio
    async def test_publish_auto_branch_name(
        self, adapter: GitApiAdapter, mock_git: MagicMock
    ) -> None:
        """Auto-branch must follow 'feature/[author]-[slug]' pattern."""
        await adapter.publish(
            message="feat: add invoice doctype",
            author="alice",
        )

        branch = mock_git.create_branch.call_args[0][1]
        assert "alice" in branch
        assert "add-invoice-doctype" in branch or "add_invoice_doctype" in branch

    @pytest.mark.asyncio
    async def test_publish_returns_branch_in_result(
        self, adapter: GitApiAdapter, mock_git: MagicMock
    ) -> None:
        """PublishResult must contain the branch name."""
        result = await adapter.publish(
            message="chore: update",
            author="bot",
        )

        assert result.branch is not None
        assert result.branch.startswith("feature/")


class TestPublishResult:
    """Tests for the PublishResult dataclass."""

    def test_creation(self) -> None:
        result = PublishResult(
            success=True,
            adapter_type="git_api",
            commit_sha="abc123",
            branch="feature/alice-add-invoice",
        )
        assert result.success is True
        assert result.adapter_type == "git_api"
        assert result.commit_sha == "abc123"
        assert result.branch == "feature/alice-add-invoice"

    def test_failed_publish(self) -> None:
        result = PublishResult(
            success=False,
            adapter_type="git_api",
            error="Authentication failed",
        )
        assert result.success is False
        assert result.error == "Authentication failed"
