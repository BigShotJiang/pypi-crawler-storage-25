"""API tests for aggregate builder and shell plugin configurator routes."""

from __future__ import annotations

from pathlib import Path
from unittest.mock import patch

from litestar.testing import TestClient


def test_aggregate_builder_routes(client: TestClient, tmp_path: Path) -> None:
    """Aggregate endpoints should persist and return linked save-cascade config."""
    with patch(
        "framework_m_studio.services.workspace.get_project_root", return_value=tmp_path
    ):
        save_response = client.post(
            "/studio/api/aggregate/config/SalesOrder",
            json={
                "linked": [
                    {
                        "doctype": "SalesOrderItem",
                        "link_field": "parent_order",
                        "cascade": "save_delete",
                    },
                    {
                        "doctype": "SalesOrderTax",
                        "link_field": "parent_order",
                        "cascade": "save_only",
                    },
                ]
            },
        )
        assert save_response.status_code == 201

        config_response = client.get("/studio/api/aggregate/config/SalesOrder")
        assert config_response.status_code == 200
        payload = config_response.json()
        assert payload["root"] == "SalesOrder"
        assert len(payload["linked"]) == 2
        assert payload["linked"][0]["cascade"] == "save_delete"

        roots_response = client.get("/studio/api/aggregate/roots")
        assert roots_response.status_code == 200
        assert "SalesOrder" in roots_response.json()["roots"]

        unknown_response = client.get("/studio/api/aggregate/config/UnknownRoot")
        assert unknown_response.status_code == 200
        assert unknown_response.json()["root"] == "UnknownRoot"
        assert len(unknown_response.json()["linked"]) == 0


def test_shell_config_routes(client: TestClient, tmp_path: Path) -> None:
    """Shell config endpoints should persist and return buttons/apps/providers."""
    with patch(
        "framework_m_studio.services.workspace.get_project_root", return_value=tmp_path
    ):
        save_response = client.post(
            "/studio/api/shell/config",
            json={
                "action_buttons": [
                    {
                        "id": "new_invoice",
                        "label": "New Invoice",
                        "action": "navigate",
                        "target": "/invoice/new",
                        "icon": "plus",
                        "roles": ["Administrator"],
                    }
                ],
                "sidebar_apps": [
                    {
                        "id": "crm",
                        "label": "CRM",
                        "icon": "users",
                        "route": "/crm",
                        "roles": ["Administrator", "Sales User"],
                    }
                ],
                "search_providers": [
                    {
                        "id": "doctype_search",
                        "label": "DocType Search",
                        "handler": "myapp.search.doctype",
                        "roles": ["Administrator"],
                    }
                ],
            },
        )
        assert save_response.status_code == 201

        get_response = client.get("/studio/api/shell/config")
        assert get_response.status_code == 200
        payload = get_response.json()
        assert len(payload["action_buttons"]) == 1
        assert len(payload["sidebar_apps"]) == 1
        assert len(payload["search_providers"]) == 1

        role_response = client.get("/studio/api/shell/config?role=Sales%20User")
        assert role_response.status_code == 200
        role_payload = role_response.json()
        assert len(role_payload["action_buttons"]) == 0
        assert len(role_payload["sidebar_apps"]) == 1
        assert len(role_payload["search_providers"]) == 0
