"""Tests for frontend plugin discovery to increase coverage."""

from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import MagicMock, patch

from framework_m_studio.core.frontend import (
    _discover_from_entry_points,
    _discover_from_local_apps,
    _load_entry_point_plugin,
)


def test_load_entry_point_errors() -> None:
    # mock entry point throwing exception
    ep = MagicMock()
    ep.name = "bad_ep"
    ep.module = "does_not_exist"

    # Test TypeError / ModuleNotFoundError handling by passing bad importlib.resources
    bad_resources = MagicMock()
    bad_resources.files.side_effect = ModuleNotFoundError()

    assert _load_entry_point_plugin(ep, bad_resources) is None

    # Test complete exception via bad module string or general fault
    assert _load_entry_point_plugin(ep, None) is None


def test_discover_entry_points_exception() -> None:
    # Test entry_points throwing error
    with patch(
        "importlib.metadata.entry_points", side_effect=Exception("mocked error")
    ):
        assert _discover_from_entry_points() == []


def test_discover_from_local_apps_packages(tmp_path: Path) -> None:
    with patch("pathlib.Path.cwd", return_value=tmp_path):
        apps = tmp_path / "apps"
        apps.mkdir()

        # Test bad json parse
        bad_app = apps / "bad_app"
        bad_app.mkdir()
        (bad_app / "package.json").write_text("{bad json")

        # Test framework metadata without correct path
        meta_app = apps / "meta_app"
        meta_app.mkdir()
        (meta_app / "package.json").write_text(
            json.dumps({"name": "meta", "framework-m": {"plugin": "nonexistent.ts"}})
        )

        # Then fallback hits index.ts
        (meta_app / "index.ts").touch()

        plugins = _discover_from_local_apps()

        names = [p["name"] if isinstance(p, dict) else p.name for p in plugins]
        assert "meta_app" in names
