"""Tests for Plugin Metadata Editor (§6.1).

TDD tests for the MetadataEditorService that provides CRUD for
arbitrary ui_meta properties with JSON-schema validation.
"""

from __future__ import annotations

from pathlib import Path

import pytest

from framework_m_studio.metadata_editor import MetadataEditorService


class TestMetadataEditorService:
    """Tests for MetadataEditorService."""

    @pytest.fixture
    def editor(self) -> MetadataEditorService:
        return MetadataEditorService()

    def test_get_ui_meta_empty(self, editor: MetadataEditorService) -> None:
        """get() must return empty dict for unknown DocType."""
        assert editor.get("Unknown") == {}

    def test_set_and_get(self, editor: MetadataEditorService) -> None:
        """set() must store ui_meta, get() must retrieve it."""
        editor.set("Invoice", {"form": {"sections": [{"fields": ["customer"]}]}})

        result = editor.get("Invoice")
        assert "form" in result
        assert result["form"]["sections"][0]["fields"] == ["customer"]

    def test_update_merges(self, editor: MetadataEditorService) -> None:
        """update() must deep-merge with existing ui_meta."""
        editor.set("Invoice", {"form": {"sections": []}, "list": {"columns": []}})
        editor.update("Invoice", {"form": {"title_field": "customer"}})

        result = editor.get("Invoice")
        assert result["form"]["title_field"] == "customer"
        assert result["form"]["sections"] == []
        assert "list" in result

    def test_delete(self, editor: MetadataEditorService) -> None:
        """delete() must remove ui_meta for a DocType."""
        editor.set("Invoice", {"form": {}})
        editor.delete("Invoice")
        assert editor.get("Invoice") == {}

    def test_validate_valid_schema(self, editor: MetadataEditorService) -> None:
        """validate() must pass for valid schema."""
        schema = {
            "type": "object",
            "properties": {
                "form": {"type": "object"},
                "list": {"type": "object"},
            },
        }
        data = {"form": {"sections": []}, "list": {"columns": []}}

        errors = editor.validate(data, schema)
        assert len(errors) == 0

    def test_validate_invalid_schema(self, editor: MetadataEditorService) -> None:
        """validate() must return errors for invalid data."""
        schema = {
            "type": "object",
            "properties": {
                "form": {"type": "object"},
            },
            "required": ["form"],
        }
        data: dict[str, object] = {"list": {"columns": []}}

        errors = editor.validate(data, schema)
        assert len(errors) > 0

    def test_list_doctypes(self, editor: MetadataEditorService) -> None:
        """list_doctypes() must return all registered DocTypes."""
        editor.set("Invoice", {"form": {}})
        editor.set("Task", {"list": {}})

        doctypes = editor.list_doctypes()
        assert set(doctypes) == {"Invoice", "Task"}

    def test_save_and_load(self, editor: MetadataEditorService, tmp_path: Path) -> None:
        """Must round-trip through JSON."""
        editor.set("Invoice", {"form": {"title": "Invoice Form"}})

        path = tmp_path / "meta.json"
        editor.save(path)

        loaded = MetadataEditorService.load(path)
        assert loaded.get("Invoice") == editor.get("Invoice")
