"""Tests for AST Parsers to increase coverage."""

from __future__ import annotations

import ast
from pathlib import Path

from framework_m_studio.docs.ast_parsers import (
    extract_docstring,
    extract_function_signature,
    generate_hooks_doc,
    generate_protocols_doc,
)


def test_generate_protocols_doc_edge_cases(tmp_path: Path) -> None:
    # 1. Missing directory
    doc = generate_protocols_doc(tmp_path)
    assert "*Error: interfaces directory" in doc

    # Setup interfaces dir
    iface_dir = (
        tmp_path
        / "libs"
        / "framework-m-core"
        / "src"
        / "framework_m_core"
        / "interfaces"
    )
    iface_dir.mkdir(parents=True)

    # 2. Syntax Error
    (iface_dir / "bad.py").write_text("class \n")

    # 3. Private file (should be skipped)
    (iface_dir / "_private.py").write_text("class SomeProtocol(Protocol): pass")

    # 4. Valid protocol and a non-protocol class
    valid_py = """
from typing import Protocol

class MyProto(Protocol):
    \"\"\"Doc.\"\"\"
    def do_x(self) -> int:
        pass
        
class NotProto:
    pass
"""
    (iface_dir / "valid.py").write_text(valid_py)

    doc2 = generate_protocols_doc(tmp_path)
    assert "*Error" not in doc2
    assert "MyProto" in doc2
    assert "NotProto" not in doc2
    assert "do_x" in doc2


def test_generate_hooks_doc_edge_cases(tmp_path: Path) -> None:
    # 1. Provide custom hooks file that doesn't exist
    assert "*Error: source file" in generate_hooks_doc(
        tmp_path, hooks_file=tmp_path / "nope.py"
    )

    # 2. Provide custom hooks file with Syntax Error
    bad_hook = tmp_path / "bad.py"
    bad_hook.write_text("def class")
    assert "*Error parsing source*" in generate_hooks_doc(tmp_path, hooks_file=bad_hook)

    # 3. Valid hooks file
    good_hook = tmp_path / "good.py"
    good_hook.write_text(
        "class MyController:\n  def on_save(self):\n    '''Doc'''\n    pass"
    )

    doc = generate_hooks_doc(tmp_path, hooks_file=good_hook)
    assert "`MyController`" in doc
    assert "`on_save`" in doc
    assert "Doc" in doc

    # 4. Valid hooks file but without passing hooks_file explicitly (uses default path)
    default_path = (
        tmp_path
        / "libs"
        / "framework-m-core"
        / "src"
        / "framework_m_core"
        / "domain"
        / "base_controller.py"
    )
    default_path.parent.mkdir(parents=True)
    default_path.write_text(
        "class BaseController:\n  def on_insert(self): pass\nclass Other: pass"
    )

    doc2 = generate_hooks_doc(tmp_path)
    assert "`BaseController`" in doc2
    assert "`on_insert`" in doc2
    assert "Other" not in doc2


def test_extract_function_signature_async() -> None:
    src = "async def my_func(self, a_val: str) -> bool: pass"
    tree = ast.parse(src)
    node = tree.body[0]
    # For some AST reason extract_function_signature expects FunctionDef
    # Wait, ast.parse body[0] is AsyncFunctionDef
    assert isinstance(node, ast.AsyncFunctionDef)
    sig = extract_function_signature(node)

    assert sig.startswith("async def my_func(a_val: str) -> bool")


def test_extract_docstring_empty() -> None:
    src = "def no_doc():\n  x = 1"
    tree = ast.parse(src)
    assert extract_docstring(tree.body[0]) == ""
