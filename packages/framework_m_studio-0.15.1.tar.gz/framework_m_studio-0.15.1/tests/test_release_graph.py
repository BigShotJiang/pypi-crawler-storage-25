from pathlib import Path

import pytest

from framework_m_studio.cli.release.graph import DependencyGraph
from framework_m_studio.cli.release.models import (
    ReleaseConfig,
    ReleasePackage,
    ReleaseSync,
    ReleaseUpdate,
)


@pytest.fixture
def mock_config():
    return ReleaseConfig(
        packages=[
            ReleasePackage(
                name="core",
                publish_name="framework-m-core",
                version_file="libs/core/pyproject.toml",
                paths=["libs/core"],
                scopes=["core"],
            ),
            ReleasePackage(
                name="fx",
                publish_name="framework-m",
                version_file="libs/fx/pyproject.toml",
                paths=["libs/fx"],
                scopes=["fx"],
            ),
            ReleasePackage(
                name="ui",
                publish_name="@framework-m/ui",
                version_file="libs/ui/package.json",
                paths=["libs/ui"],
                scopes=["ui"],
            ),
            ReleasePackage(
                name="studio",
                publish_name="framework-m-studio",
                version_file="apps/studio/pyproject.toml",
                paths=["apps/studio"],
                scopes=["studio"],
            ),
        ],
        sync=[
            ReleaseSync(
                file="apps/studio/templates/ui/**",
                package_name="ui",
            )
        ],
    )


def test_graph_initialization(mock_config):
    graph = DependencyGraph(mock_config, Path("/tmp/fake-root"))
    assert graph.packages["core"].name == "core"


def test_discover_manifest_dependencies(mock_config, tmp_path):
    # Setup: fx depends on core in pyproject.toml
    core_dir = tmp_path / "libs/core"
    fx_dir = tmp_path / "libs/fx"
    core_dir.mkdir(parents=True)
    fx_dir.mkdir(parents=True)

    (fx_dir / "pyproject.toml").write_text("""
[project]
name = "framework-m"
dependencies = [
    "framework-m-core>=0.1.0"
]
""")
    (core_dir / "pyproject.toml").write_text('[project]\nname = "framework-m-core"')

    graph = DependencyGraph(mock_config, tmp_path)
    graph.discover_manifest_deps()

    assert "fx" in graph.get_dependents("core")


def test_discover_sync_dependencies(mock_config, tmp_path):
    graph = DependencyGraph(mock_config, tmp_path)
    graph.discover_sync_deps()

    assert "studio" in graph.get_dependents("ui")


def test_calculate_propagated_updates(mock_config, tmp_path):
    # Setup directories for version reading
    core_dir = tmp_path / "libs/core"
    fx_dir = tmp_path / "libs/fx"
    studio_dir = tmp_path / "apps/studio"
    core_dir.mkdir(parents=True)
    fx_dir.mkdir(parents=True)
    studio_dir.mkdir(parents=True)

    (core_dir / "pyproject.toml").write_text('version = "0.1.0"')
    (fx_dir / "pyproject.toml").write_text('version = "0.1.0"')
    (studio_dir / "pyproject.toml").write_text('version = "0.1.0"')

    graph = DependencyGraph(mock_config, tmp_path)
    graph.add_edge("core", "fx")
    graph.add_edge("fx", "studio")

    initial_updates = [
        ReleaseUpdate(
            component="core",
            component_path="libs/core",
            version_file="libs/core/pyproject.toml",
            current_version="0.1.0",
            new_version="0.2.0",
            bump="minor",
            changelog="feat: new core",
        )
    ]

    full_plan = graph.calculate_updates(initial_updates)

    components = {u.component for u in full_plan}
    assert "core" in components
    assert "fx" in components
    assert "studio" in components

    fx_update = next(u for u in full_plan if u.component == "fx")
    assert fx_update.bump == "patch"
    assert (
        "**fx** v0.1.1: internal dependency bump due to **core** update"
        in fx_update.changelog
    )


def test_real_world_manifest_discovery(mock_config, tmp_path):
    ui_dir = tmp_path / "libs/ui"
    ui_dir.mkdir(parents=True)
    (ui_dir / "package.json").write_text(
        '{"name": "@framework-m/ui", "dependencies": {}}'
    )

    studio_dir = tmp_path / "apps/studio"
    studio_dir.mkdir(parents=True)
    (studio_dir / "pyproject.toml").write_text("""
[project]
name = "framework-m-studio"
dependencies = [
    "framework-m-core"
]
""")

    graph = DependencyGraph(mock_config, tmp_path)
    graph.discover_manifest_deps()

    assert "studio" in graph.get_dependents("core")


def test_ignore_non_runtime_dependencies(mock_config, tmp_path):
    # Setup: core is in keywords and devDependencies, should be ignored
    studio_dir = tmp_path / "apps/studio"
    studio_dir.mkdir(parents=True, exist_ok=True)

    (studio_dir / "package.json").write_text("""
{
  "name": "framework-m-studio",
  "dependencies": {},
  "devDependencies": {
    "framework-m-core": "workspace:*"
  },
  "keywords": ["framework-m-core"]
}
""")

    graph = DependencyGraph(mock_config, tmp_path)
    # Re-register studio with the correct path for this test
    graph.packages["studio"].version_file = "apps/studio/package.json"

    graph.discover_manifest_deps()

    # Should NOT have an edge from core to studio
    assert "studio" not in graph.get_dependents("core")
