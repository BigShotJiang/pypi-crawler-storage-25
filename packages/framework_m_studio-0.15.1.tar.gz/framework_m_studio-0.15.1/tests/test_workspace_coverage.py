"""Coverage tests for workspace manager."""

from pathlib import Path
from unittest.mock import AsyncMock

import pytest

from framework_m_studio.workspace import WorkspaceManager


@pytest.fixture
def mock_git():
    mock = AsyncMock()
    mock.get_current_branch.return_value = "main"
    return mock


@pytest.fixture
def workspace_manager(mock_git, tmp_path):
    return WorkspaceManager(git_adapter=mock_git, base_dir=tmp_path)


@pytest.mark.asyncio
async def test_workspace_manager_pull(workspace_manager, mock_git):
    info = await workspace_manager.connect("http://repo")
    await workspace_manager.pull(info.id)
    mock_git.pull.assert_called_once()


@pytest.mark.asyncio
async def test_workspace_manager_create_branch(workspace_manager, mock_git):
    info = await workspace_manager.connect("http://repo")
    await workspace_manager.create_branch(info.id, "new-branch")
    mock_git.create_branch.assert_called_once()
    session = await workspace_manager._get_session(info.id)
    assert session.branch == "new-branch"


@pytest.mark.asyncio
async def test_workspace_manager_get_info(workspace_manager):
    info = await workspace_manager.connect("http://repo")
    fetched_info = await workspace_manager.get_info(info.id)
    assert fetched_info.id == info.id


@pytest.mark.asyncio
async def test_workspace_manager_get_workspace_path(workspace_manager):
    info = await workspace_manager.connect("http://repo")
    path = await workspace_manager.get_workspace_path(info.id)
    assert isinstance(path, Path)
    assert str(info.id) in str(path)


@pytest.mark.asyncio
async def test_multi_repo_methods(workspace_manager, mock_git):
    multi = await workspace_manager.connect_multi({"workspace": "http://w"})
    status = await workspace_manager.get_repo_status(multi.id, "workspace")
    assert status is not None

    await workspace_manager.checkout_repo(multi.id, "workspace", "feat-1")
    mock_git.checkout.assert_called_once()

    await workspace_manager.create_branch_in_repo(multi.id, "workspace", "feat-2")
    mock_git.create_branch.assert_called_once()

    mock_git.commit.return_value.sha = "abc"
    sha = await workspace_manager.commit_repo(multi.id, "workspace", "test")
    assert sha == "abc"

    await workspace_manager.disconnect_multi(multi.id)
    with pytest.raises(KeyError):
        await workspace_manager.get_multi_session(multi.id)
