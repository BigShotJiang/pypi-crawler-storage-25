"""Tests for Aggregate Root Builder (§6.2).

TDD tests for multi-DocType linking and save cascade configuration.
"""

from __future__ import annotations

import pytest

from framework_m_studio.aggregate_builder import (
    AggregateRootBuilder,
    LinkedDocType,
)


class TestAggregateRootBuilder:
    """Tests for AggregateRootBuilder."""

    @pytest.fixture
    def builder(self) -> AggregateRootBuilder:
        return AggregateRootBuilder()

    def test_empty_builder(self, builder: AggregateRootBuilder) -> None:
        """New builder must have no aggregates."""
        assert builder.list_roots() == []

    def test_define_aggregate(self, builder: AggregateRootBuilder) -> None:
        """define() must create a new aggregate root."""
        builder.define("SalesOrder")
        assert "SalesOrder" in builder.list_roots()

    def test_link_doctype(self, builder: AggregateRootBuilder) -> None:
        """link() must add a related DocType to the aggregate."""
        builder.define("SalesOrder")
        builder.link(
            "SalesOrder",
            LinkedDocType(
                doctype="SalesOrderItem",
                link_field="parent_order",
                cascade="save_delete",
            ),
        )

        config = builder.get_config("SalesOrder")
        assert config is not None
        assert len(config.linked) == 1
        assert config.linked[0].doctype == "SalesOrderItem"

    def test_link_multiple(self, builder: AggregateRootBuilder) -> None:
        """Multiple DocTypes can be linked to one aggregate."""
        builder.define("SalesOrder")
        builder.link(
            "SalesOrder",
            LinkedDocType(
                doctype="SalesOrderItem",
                link_field="parent_order",
                cascade="save_delete",
            ),
        )
        builder.link(
            "SalesOrder",
            LinkedDocType(
                doctype="SalesOrderTax",
                link_field="parent_order",
                cascade="save_only",
            ),
        )

        config = builder.get_config("SalesOrder")
        assert config is not None
        assert len(config.linked) == 2

    def test_cascade_modes(self, builder: AggregateRootBuilder) -> None:
        """Cascade mode must be configurable per linked DocType."""
        builder.define("SalesOrder")
        builder.link(
            "SalesOrder",
            LinkedDocType(
                doctype="SalesOrderItem",
                link_field="parent",
                cascade="save_delete",
            ),
        )
        builder.link(
            "SalesOrder",
            LinkedDocType(
                doctype="Comment",
                link_field="parent",
                cascade="none",
            ),
        )

        config = builder.get_config("SalesOrder")
        assert config is not None
        assert config.linked[0].cascade == "save_delete"
        assert config.linked[1].cascade == "none"

    def test_unlink_doctype(self, builder: AggregateRootBuilder) -> None:
        """unlink() must remove a linked DocType."""
        builder.define("SalesOrder")
        builder.link(
            "SalesOrder",
            LinkedDocType(
                doctype="Item",
                link_field="parent",
                cascade="save_delete",
            ),
        )
        builder.unlink("SalesOrder", "Item")

        config = builder.get_config("SalesOrder")
        assert config is not None
        assert len(config.linked) == 0

    def test_get_config_unknown(self, builder: AggregateRootBuilder) -> None:
        """get_config() must return None for unknown root."""
        assert builder.get_config("Unknown") is None

    def test_to_dict(self, builder: AggregateRootBuilder) -> None:
        """to_dict() must return serializable config."""
        builder.define("SalesOrder")
        builder.link(
            "SalesOrder",
            LinkedDocType(
                doctype="Item",
                link_field="parent",
                cascade="save_delete",
            ),
        )

        d = builder.to_dict("SalesOrder")
        assert "linked" in d
        assert d["linked"][0]["doctype"] == "Item"
