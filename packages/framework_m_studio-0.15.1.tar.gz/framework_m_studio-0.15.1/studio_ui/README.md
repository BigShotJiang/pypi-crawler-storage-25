# studio_ui

<div align="center" style="margin: 30px;">
    <a href="https://refine.dev">
    <img alt="refine logo" src="https://refine.ams3.cdn.digitaloceanspaces.com/readme/refine-readme-banner.png">
    </a>
</div>
<br/>

This [Refine](https://github.com/refinedev/refine) project was generated with [create refine-app](https://github.com/refinedev/refine/tree/master/packages/create-refine-app).

## Getting Started

The visual developer interface for Framework M.

Studio UI provides a no-code environment for building DocTypes, configuring workflows, and managing your development workspace.

## Key Features

- **DocType Builder**: Create and modify data models and see changes reflected in your code.
- **Code Generation**: Automatically syncs visual changes to LibCST-based Python classes.
- **Protocol Discovery**: Scan and manage all Ports & Adapters in your workspace.

## Development

```bash
pnpm install
pnpm dev
```

For more information, see the [Studio Documentation](https://www.frameworkm.dev/studio).

## License

Apache-2.0
