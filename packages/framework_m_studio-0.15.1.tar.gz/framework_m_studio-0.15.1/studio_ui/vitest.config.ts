import { defineConfig } from 'vitest/config'
import react from '@vitejs/plugin-react'
import tsconfigPaths from 'vite-tsconfig-paths'

export default defineConfig({
    plugins: [react(), tsconfigPaths()],
    test: {
        environment: 'jsdom',
        globals: true,
        setupFiles: './src/setupTests.ts',
        // Test match patterns
        include: ["src/**/*.{test,spec}.{ts,tsx}"],
        deps: {
            inline: ["@tamagui/core", "@tamagui/image", "tamagui"],
        },
    },
})
