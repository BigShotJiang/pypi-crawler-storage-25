import path from "node:path";
import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";

export default defineConfig({
  plugins: [react(), tailwindcss()],
  base: "/studio/ui/",
  define: {
    "process.env": {},
  },
  resolve: {
    extensions: [
      ".web.mjs",
      ".web.js",
      ".web.jsx",
      ".web.ts",
      ".web.tsx",
      ".mjs",
      ".js",
      ".mts",
      ".ts",
      ".jsx",
      ".tsx",
      ".json",
    ],
    dedupe: ["react", "react-dom"],
    alias: {
      "@framework-m/desk": path.resolve(
        __dirname,
        "../../../libs/framework-m-desk/src/index.ts"
      ),
      "@framework-m/ui": path.resolve(
        __dirname,
        "../../../libs/framework-m-ui/src/index.ts"
      ),
      'react-native': 'react-native-web',
    },
  },
  build: {
    outDir: "../src/framework_m_studio/static",
    emptyOutDir: false,
    rollupOptions: {
      output: {
        manualChunks(id: string) {
          if (id.includes("node_modules")) {
            if (
              id.includes("react/") ||
              id.includes("react-dom/") ||
              id.includes("scheduler/")
            ) {
              return "vendor-react";
            }
            if (id.includes("@tamagui/lucide-icons") || id.includes("lucide-icons")) {
              return "vendor-icons";
            }
            if (id.includes("@tamagui") || id.includes("tamagui")) {
              return "vendor-tamagui";
            }
          }
        },
      },
    },
  },
  server: {
    host: "0.0.0.0",
    proxy: {
      "/studio/api": {
        target: "http://localhost:9999",
        changeOrigin: true,
      },
    },
  },
});
