import React, { useCallback, useEffect, useMemo, useState } from "react";

interface HotSwapStatus {
  watching: boolean;
  repo_path: string;
  updates_received: number;
  last_update_at?: string | null;
}

export interface PrintTabProps {
  doctypeName: string;
  isDark?: boolean;
}

export function PrintTab({ doctypeName, isDark = false }: PrintTabProps) {
  const [layouts, setLayouts] = useState<string[]>([]);
  const [selectedFormat, setSelectedFormat] = useState<string>("");
  const [newTemplateName, setNewTemplateName] = useState("");
  const [content, setContent] = useState("");
  const [sampleData, setSampleData] = useState('{\n  "title": "Sample Document"\n}');
  const [previewHtml, setPreviewHtml] = useState("");
  const [statusMessage, setStatusMessage] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [hotSwapStatus, setHotSwapStatus] = useState<HotSwapStatus | null>(null);

  const panelClass = useMemo(
    () =>
      isDark
        ? "border-zinc-700 bg-zinc-900 text-zinc-100"
        : "border-gray-200 bg-white text-gray-900",
    [isDark],
  );

  const loadLayouts = useCallback(async () => {
    if (!doctypeName) {
      setLayouts([]);
      return;
    }
    try {
      const response = await fetch(`/studio/api/print/layouts/${encodeURIComponent(doctypeName)}`);
      const data = (await response.json()) as { layouts?: string[] };
      const names = data.layouts ?? [];
      setLayouts(names);
      if (names.length > 0 && !selectedFormat) {
        setSelectedFormat(names[0]);
      }
    } catch (err) {
      setErrorMessage(String(err));
    }
  }, [doctypeName, selectedFormat]);

  const loadTemplate = useCallback(async (templateName: string) => {
    if (!doctypeName || !templateName) return;
    try {
      const response = await fetch(`/studio/api/print/layout/${encodeURIComponent(doctypeName)}/${encodeURIComponent(templateName)}`);
      if (!response.ok) return;
      const data = (await response.json()) as { content?: string };
      setContent(data.content ?? "");
    } catch (err) {
      setErrorMessage(String(err));
    }
  }, [doctypeName]);

  const refreshHotSwapStatus = useCallback(async () => {
    try {
      const response = await fetch("/studio/api/print/hotswap/status");
      const data = (await response.json()) as HotSwapStatus;
      setHotSwapStatus(data);
    } catch (err) {
      setErrorMessage(String(err));
    }
  }, []);

  useEffect(() => {
    loadLayouts();
    refreshHotSwapStatus();
  }, [loadLayouts, refreshHotSwapStatus]);

  useEffect(() => {
    if (selectedFormat) {
      loadTemplate(selectedFormat);
    }
  }, [selectedFormat, loadTemplate]);

  async function handleSaveTemplate() {
    setStatusMessage(null);
    setErrorMessage(null);

    const templateName = selectedFormat || newTemplateName.trim();
    if (!doctypeName || !templateName) {
      setErrorMessage("Provide a template name.");
      return;
    }

    const response = await fetch(
      `/studio/api/print/layout/${encodeURIComponent(doctypeName)}/${encodeURIComponent(templateName)}`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ content }),
      },
    );

    if (!response.ok) {
      setErrorMessage("Failed to save print template.");
      return;
    }

    setSelectedFormat(templateName);
    setNewTemplateName("");
    await loadLayouts();
    setStatusMessage("Template saved to Print Repo.");
  }

  async function handlePreview() {
    setStatusMessage(null);
    setErrorMessage(null);

    const templateName = selectedFormat || newTemplateName.trim();
    if (!doctypeName || !templateName) {
      setErrorMessage("Select a template name.");
      return;
    }

    let parsedData: Record<string, unknown> = {};
    try {
      parsedData = JSON.parse(sampleData) as Record<string, unknown>;
    } catch {
      setErrorMessage("Sample data must be valid JSON.");
      return;
    }

    const response = await fetch("/studio/api/print/preview", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        doctype: doctypeName,
        template_name: templateName,
        data: parsedData,
      }),
    });

    const data = (await response.json()) as { success?: boolean; html?: string; error?: string };

    if (!data.success) {
      setErrorMessage(data.error ?? "Preview failed.");
      return;
    }

    setPreviewHtml(data.html ?? "");
    setStatusMessage("Preview rendered successfully.");
  }

  async function handleHotSwapSync() {
    setStatusMessage(null);
    setErrorMessage(null);
    const response = await fetch("/studio/api/print/hotswap/sync", { method: "POST" });
    if (!response.ok) {
      setErrorMessage("Failed to trigger hot-swap sync event.");
      return;
    }
    await refreshHotSwapStatus();
    setStatusMessage("Hot-swap sync event sent.");
  }

  return (
    <div className="p-6 h-full overflow-y-auto space-y-6">
      <div className="flex items-start justify-between">
        <div>
          <h3 className={`text-lg font-medium ${isDark ? "text-white" : "text-gray-900"}`}>Print Templates</h3>
          <p className={`text-sm mt-1 ${isDark ? "text-zinc-400" : "text-gray-500"}`}>
            Manage Jinja2 print templates for {doctypeName}.
          </p>
        </div>
        <div className="flex flex-col items-end gap-2">
          <button onClick={handleHotSwapSync} className="rounded-lg bg-emerald-600 px-3 py-1.5 text-xs font-medium text-white hover:bg-emerald-700 shadow-sm">
            Trigger Hot-Swap Sync
          </button>
          {hotSwapStatus && (
            <div className={`text-xs px-2 py-1 rounded border ${isDark ? "border-zinc-700 text-zinc-400 bg-zinc-800" : "border-gray-200 text-gray-500 bg-gray-50"}`}>
              {hotSwapStatus.watching ? "Watching " : "Stopped "}
              ({hotSwapStatus.updates_received} updates)
            </div>
          )}
        </div>
      </div>

      {statusMessage && <p className="text-sm text-emerald-500 font-medium">{statusMessage}</p>}
      {errorMessage && <p className="text-sm text-red-500 font-medium">{errorMessage}</p>}

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-6 pb-12">
        {/* Editor Pane */}
        <div className={`rounded-xl border p-4 flex flex-col ${panelClass}`}>
          <div className="mb-4 flex flex-col gap-3 sm:flex-row">
            <select value={selectedFormat} onChange={e => { setSelectedFormat(e.target.value); setNewTemplateName(""); }} className={`flex-1 rounded-lg border px-3 py-2 text-sm ${isDark ? "border-zinc-700 bg-zinc-800 text-white" : "border-gray-300 bg-white text-gray-900"}`}>
              <option value="">Select Existing...</option>
              {layouts.map(name => (<option key={name} value={name}>{name}</option>))}
            </select>
            <input
              value={newTemplateName}
              onChange={e => { setNewTemplateName(e.target.value); setSelectedFormat(""); }}
              placeholder="Or type new name"
              aria-label="New Layout Name"
              className={`flex-1 rounded-lg border px-3 py-2 text-sm ${isDark ? "border-zinc-700 bg-zinc-800 text-white" : "border-gray-300 bg-white text-gray-900"}`}
            />
          </div>
          <textarea value={content} onChange={e => setContent(e.target.value)} rows={16} aria-label="Template Editor" className={`w-full flex-1 rounded-lg border p-3 font-mono text-sm resize-none focus:outline-none focus:ring-2 focus:ring-blue-500 ${isDark ? "border-zinc-700 bg-zinc-950 text-gray-300" : "border-gray-300 bg-gray-50 text-gray-800"}`} placeholder="<h1>{{ doc.name }}</h1>" />
          <div className="mt-4 flex gap-3">
            <button onClick={handleSaveTemplate} className="rounded-lg bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700 shadow-sm flex-1">Save Template</button>
            <button onClick={handlePreview} className="rounded-lg bg-cyan-600 px-4 py-2 text-sm font-medium text-white hover:bg-cyan-700 shadow-sm flex-1">Preview</button>
          </div>
        </div>

        {/* Preview Pane */}
        <div className={`rounded-xl border p-4 flex flex-col ${panelClass}`}>
          <h4 className="mb-2 text-sm font-medium">Sample Data (JSON)</h4>
          <textarea value={sampleData} onChange={e => setSampleData(e.target.value)} rows={6} aria-label="Sample Data" className={`mb-4 w-full rounded-lg border p-3 font-mono text-sm resize-none focus:outline-none focus:ring-2 focus:ring-blue-500 ${isDark ? "border-zinc-700 bg-zinc-950 text-gray-300" : "border-gray-300 bg-gray-50 text-gray-800"}`} />
          <h4 className="mb-2 text-sm font-medium">Preview Output</h4>
          <div className={`flex-1 min-h-[300px] rounded-lg border p-4 overflow-auto ${isDark ? "border-zinc-700 bg-zinc-800" : "border-gray-200 bg-white"}`}>
            {previewHtml ? <div dangerouslySetInnerHTML={{ __html: previewHtml }} /> : <p className={isDark ? "text-zinc-500" : "text-gray-400"}>Click Preview to render the template.</p>}
          </div>
        </div>
      </div>
    </div>
  );
}