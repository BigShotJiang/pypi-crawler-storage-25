import { render, screen, fireEvent } from "@testing-library/react";
import { describe, it, expect } from "vitest";
import React, { useState } from "react";
import { MetaEditor } from "./MetaEditor";
import type { DocTypeSchema } from "../../src/pages/doctypes/edit";

const TestWrapper = () => {
  const [doctype, setDoctype] = useState<DocTypeSchema>({
    name: "TestDoc",
    fields: [],
    meta: {
      apply_rls: true,
      api_resource: false,
      label: "Old Label",
    },
  });

  return (
    <div>
      <MetaEditor
        doctype={doctype}
        setDoctype={setDoctype}
        availableRoles={[{ name: "Admin" }, { name: "User" }]}
        isDark={false}
      />
      <div data-testid="debug-apply-rls">{doctype.meta?.apply_rls ? "true" : "false"}</div>
      <div data-testid="debug-label">{String(doctype.meta?.label)}</div>
    </div>
  );
};

describe("MetaEditor (Unified System Meta)", () => {
  it("renders organized categories for metadata", () => {
    render(<TestWrapper />);
    expect(screen.getByText("Core Behavior")).toBeInTheDocument();
    expect(screen.getByText("Security & Permissions")).toBeInTheDocument();
    expect(screen.getByText("API & Integration")).toBeInTheDocument();
  });

  it("toggles apply_rls and updates the draft state", () => {
    render(<TestWrapper />);

    const applyRlsCheckbox = screen.getByLabelText(/Apply Row-Level Security/i);
    expect(applyRlsCheckbox).toBeChecked();

    fireEvent.click(applyRlsCheckbox);
    expect(screen.getByTestId("debug-apply-rls")).toHaveTextContent("false");
  });

  it("updates the human-readable label", () => {
    render(<TestWrapper />);

    const labelInput = screen.getByLabelText(/DocType Label/i);
    fireEvent.change(labelInput, { target: { value: "New Label" } });
    expect(screen.getByTestId("debug-label")).toHaveTextContent("New Label");
  });
});