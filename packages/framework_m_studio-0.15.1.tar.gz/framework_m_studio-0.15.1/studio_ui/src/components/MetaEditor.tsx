import React from "react";
import type { DocTypeSchema, RoleDef } from "../pages/doctypes/edit";

export interface MetaEditorProps {
  doctype: DocTypeSchema;
  setDoctype: React.Dispatch<React.SetStateAction<DocTypeSchema>>;
  availableRoles: RoleDef[];
  isDark: boolean;
}

export function MetaEditor({ doctype, setDoctype, availableRoles, isDark }: MetaEditorProps) {
  const handleRoleToggle = (action: string, role: string) => {
    const currentMeta = doctype.meta || {};
    const permissions = currentMeta.permissions || {};
    const actionRoles = permissions[action] || [];

    let newRoles;
    if (actionRoles.includes(role)) {
      newRoles = actionRoles.filter((r: string) => r !== role);
    } else {
      newRoles = [...actionRoles, role];
    }

    setDoctype({
      ...doctype,
      meta: {
        ...currentMeta,
        permissions: {
          ...permissions,
          [action]: newRoles
        }
      }
    });
  };

  const isSubmittable = doctype.meta?.is_submittable === true;
  const actions = ["read", "write", "create", "delete"];
  if (isSubmittable) {
    actions.push("submit", "cancel");
  }

  const handleMetaToggle = (key: string) => {
    const currentMeta = doctype.meta || {};
    setDoctype({
      ...doctype,
      meta: {
        ...currentMeta,
        [key]: !currentMeta[key]
      }
    });
  };

  const handleMetaText = (key: string, value: string) => {
    const currentMeta = doctype.meta || {};
    setDoctype({
      ...doctype,
      meta: {
        ...currentMeta,
        [key]: value
      }
    });
  };

  const inputClass = `w-full text-sm rounded-md border px-3 py-1.5 focus:outline-none focus:ring-2 focus:ring-blue-500 ${isDark ? "bg-zinc-900 border-zinc-600 text-white" : "bg-white border-gray-300 text-gray-900"}`;
  const checkboxClass = "w-4 h-4 text-blue-600 rounded border-gray-300 focus:ring-blue-500 mt-0.5 shrink-0";

  return (
    <div className="p-6 space-y-8 overflow-y-auto h-full">
      {/* Core Behavior */}
      <div>
        <h3 className={`text-lg font-medium mb-4 ${isDark ? "text-white" : "text-gray-900"}`}>Core Behavior</h3>
        <div className={`p-4 border rounded-lg space-y-5 ${isDark ? "border-zinc-700 bg-zinc-800" : "border-gray-200 bg-white"}`}>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label htmlFor="meta-label" className="block text-sm font-medium mb-1 text-gray-700 dark:text-zinc-300">DocType Label</label>
              <input
                id="meta-label"
                type="text"
                value={(doctype.meta?.label as string) || ""}
                onChange={(e) => handleMetaText("label", e.target.value)}
                className={inputClass}
                placeholder="e.g., Sales Invoice"
              />
            </div>
            <div>
              <label htmlFor="meta-module" className="block text-sm font-medium mb-1 text-gray-700 dark:text-zinc-300">Module</label>
              <input
                id="meta-module"
                type="text"
                value={(doctype.meta?.module as string) || ""}
                onChange={(e) => handleMetaText("module", e.target.value)}
                className={inputClass}
                placeholder="e.g., erp.sales"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
            <label className="flex items-start gap-3 cursor-pointer">
              <input type="checkbox" checked={!!doctype.meta?.is_singleton} onChange={() => handleMetaToggle("is_singleton")} className={checkboxClass} />
              <div>
                <div className={`font-medium ${isDark ? "text-gray-200" : "text-gray-700"}`}>Is Singleton</div>
                <div className={`text-xs ${isDark ? "text-zinc-400" : "text-gray-500"}`}>Only one instance of this DocType can exist (e.g., settings).</div>
              </div>
            </label>

            <label className="flex items-start gap-3 cursor-pointer">
              <input type="checkbox" checked={!!doctype.meta?.is_child_table} onChange={() => handleMetaToggle("is_child_table")} className={checkboxClass} />
              <div>
                <div className={`font-medium ${isDark ? "text-gray-200" : "text-gray-700"}`}>Is Child Table</div>
                <div className={`text-xs ${isDark ? "text-zinc-400" : "text-gray-500"}`}>Used strictly as rows inside another DocType.</div>
              </div>
            </label>

            <label className="flex items-start gap-3 cursor-pointer">
              <input type="checkbox" checked={isSubmittable} onChange={() => handleMetaToggle("is_submittable")} className={checkboxClass} />
              <div>
                <div className={`font-medium ${isDark ? "text-gray-200" : "text-gray-700"}`}>Is Submittable</div>
                <div className={`text-xs ${isDark ? "text-zinc-400" : "text-gray-500"}`}>Enables Draft &gt; Submit &gt; Cancel workflow.</div>
              </div>
            </label>

            <label className="flex items-start gap-3 cursor-pointer">
              <input type="checkbox" checked={!!doctype.meta?.show_in_desk} onChange={() => handleMetaToggle("show_in_desk")} className={checkboxClass} />
              <div>
                <div className={`font-medium ${isDark ? "text-gray-200" : "text-gray-700"}`}>Show in Desk</div>
                <div className={`text-xs ${isDark ? "text-zinc-400" : "text-gray-500"}`}>Make visible in the main UI navigation.</div>
              </div>
            </label>
          </div>
        </div>
      </div>

      {/* Permissions */}
      <div>
        <h3 className={`text-lg font-medium mb-4 ${isDark ? "text-white" : "text-gray-900"}`}>Security & Permissions</h3>

        <div className={`p-4 border rounded-lg space-y-4 mb-6 ${isDark ? "border-zinc-700 bg-zinc-800" : "border-gray-200 bg-white"}`}>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <label className="flex items-start gap-3 cursor-pointer">
              <input type="checkbox" checked={doctype.meta?.requires_auth !== false} onChange={() => handleMetaToggle("requires_auth")} className={checkboxClass} />
              <div>
                <div className={`font-medium ${isDark ? "text-gray-200" : "text-gray-700"}`}>Requires Authentication</div>
                <div className={`text-xs ${isDark ? "text-zinc-400" : "text-gray-500"}`}>If unchecked, API is completely public.</div>
              </div>
            </label>

            <label className="flex items-start gap-3 cursor-pointer">
              <input type="checkbox" checked={doctype.meta?.apply_rls !== false} onChange={() => handleMetaToggle("apply_rls")} className={checkboxClass} />
              <div>
                <div className={`font-medium ${isDark ? "text-gray-200" : "text-gray-700"}`}>Apply Row-Level Security</div>
                <div className={`text-xs ${isDark ? "text-zinc-400" : "text-gray-500"}`}>Restrict read/write access to row owners.</div>
              </div>
            </label>
          </div>

          {doctype.meta?.apply_rls !== false && (
            <div className={`pt-4 border-t ${isDark ? "border-zinc-700" : "border-gray-200"}`}>
              <label htmlFor="rls-field" className="block text-sm font-medium mb-1 text-gray-700 dark:text-zinc-300">RLS Field</label>
              <input
                id="rls-field"
                type="text"
                value={(doctype.meta?.rls_field as string) || "owner"}
                onChange={(e) => handleMetaText("rls_field", e.target.value)}
                className={inputClass}
                placeholder="owner"
              />
              <p className="text-xs mt-1 text-gray-500 dark:text-zinc-400">Database field used for RLS filtering (defaults to 'owner').</p>
            </div>
          )}
        </div>

        <h4 className={`text-md font-medium mb-3 ${isDark ? "text-white" : "text-gray-900"}`}>Role Permissions</h4>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {actions.map(action => {
          const currentRoles = doctype.meta?.permissions?.[action] || [];
          return (
            <div key={action} className={`p-4 border rounded-lg ${isDark ? "border-zinc-700 bg-zinc-800" : "border-gray-200 bg-white"}`}>
              <h4 className="font-semibold capitalize mb-3 text-blue-500">{action}</h4>

              <div className="space-y-3">
                {/* Selected Roles as Pills */}
                <div className="flex flex-wrap gap-2">
                  {currentRoles.map((roleName: string) => (
                    <span
                      key={roleName}
                      className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-medium ${
                        isDark ? "bg-blue-500/20 text-blue-300" : "bg-blue-100 text-blue-700"
                      }`}
                    >
                      {roleName}
                      <button
                        onClick={() => handleRoleToggle(action, roleName)}
                        className={`rounded-full p-0.5 transition-colors ${
                          isDark ? "hover:bg-blue-500/40" : "hover:bg-blue-200"
                        }`}
                        title="Remove role"
                      >
                        <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                        </svg>
                      </button>
                    </span>
                  ))}
                  {currentRoles.length === 0 && (
                    <span className={`text-xs italic ${isDark ? "text-zinc-500" : "text-gray-500"}`}>
                      No roles assigned
                    </span>
                  )}
                </div>

                {/* Add Role Dropdown */}
                <select
                  className={`w-full text-sm rounded-md border px-3 py-1.5 focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                    isDark ? "bg-zinc-900 border-zinc-600 text-white" : "bg-white border-gray-300 text-gray-900"
                  }`}
                  value=""
                  onChange={e => {
                    if (e.target.value) {
                      handleRoleToggle(action, e.target.value);
                    }
                  }}
                >
                  <option value="" disabled>
                    + Add role...
                  </option>
                  {availableRoles
                    .filter((r: RoleDef) => !currentRoles.includes(r.name))
                    .map((role: RoleDef) => (
                      <option key={role.name} value={role.name} title={role.description}>
                        {role.name}
                      </option>
                    ))}
                </select>
              </div>
            </div>
          );
        })}
        </div>
      </div>

      {/* API & Integration */}
      <div>
        <h3 className={`text-lg font-medium mb-4 ${isDark ? "text-white" : "text-gray-900"}`}>API & Integration</h3>
        <div className={`p-4 border rounded-lg ${isDark ? "border-zinc-700 bg-zinc-800" : "border-gray-200 bg-white"}`}>
          <label className="flex items-start gap-3 cursor-pointer w-max">
            <input type="checkbox" checked={!!doctype.meta?.api_resource} onChange={() => handleMetaToggle("api_resource")} className={checkboxClass} />
            <div>
              <div className={`font-medium ${isDark ? "text-gray-200" : "text-gray-700"}`}>Generate API Resource</div>
              <div className={`text-xs ${isDark ? "text-zinc-400" : "text-gray-500"}`}>Automatically expose standard REST CRUD endpoints.</div>
            </div>
          </label>
        </div>
      </div>
    </div>
  );
}