import { render, screen, fireEvent, waitFor } from "@testing-library/react";
import { describe, it, expect, vi, beforeEach, MockInstance } from "vitest";
import React from "react";
import { PrintTab } from "./PrintTab";

let fetchSpy: MockInstance;

describe("PrintTab", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    fetchSpy = vi.spyOn(globalThis, "fetch");
  });

  it("loads the associated Jinja2 template when a Print Format is selected", async () => {
    fetchSpy.mockImplementation(async (url: string) => {
      if (url.includes("/studio/api/print/layouts/Invoice")) {
        return {
          ok: true,
          json: async () => ({
            layouts: ["Standard", "Tax"]
          })
        } as unknown as Response;
      } else if (url.includes("/studio/api/print/layout/Invoice/Tax")) {
        return {
          ok: true, json: async () => ({ content: "<h1>Tax Invoice {{ doc.name }}</h1>" })
        } as unknown as Response;
      } else if (url.includes("/studio/api/print/hotswap/status")) {
        return {
          ok: true, json: async () => ({ watching: false, repo_path: "", updates_received: 0 })
        } as unknown as Response;
      }
      return { ok: true, json: async () => ({}) } as unknown as Response;
    });

    render(<PrintTab doctypeName="Invoice" isDark={false} />);

    // Use findByRole to wait for the initial async data load to complete.
    // This resolves the `act(...)` warnings.
    const select = await screen.findByRole("combobox");

    fireEvent.change(select, { target: { value: "Tax" } });

    // Use the specific aria-label to find the correct textbox and wait for the value to update.
    const editor = await screen.findByRole("textbox", { name: /Template Editor/i });
    await waitFor(() => {
      expect(editor).toHaveValue("<h1>Tax Invoice {{ doc.name }}</h1>");
    });
  });
});