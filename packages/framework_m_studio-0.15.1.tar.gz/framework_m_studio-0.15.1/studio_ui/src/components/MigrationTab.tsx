import React, { useState } from "react";

export interface SchemaDiff {
  change_type: string;
  risk: "safe" | "warning" | "breaking";
  column_name: string;
  message: string;
}

export interface MigrationTabProps {
  isDark?: boolean;
  getSchemaPayload: () => Record<string, unknown>;
}

export function MigrationTab({ isDark = false, getSchemaPayload }: MigrationTabProps) {
  const [diffs, setDiffs] = useState<SchemaDiff[] | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleVerify = async () => {
    setIsLoading(true);
    setError(null);
    try {
      const payload = getSchemaPayload();
      const response = await fetch(`/studio/api/doctypes/verify`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      if (!response.ok) {
        const errData = await response.json().catch(() => ({}));
        throw new Error(errData.message || "Failed to verify schema against database");
      }

      const data = await response.json();
      setDiffs(data.diffs || []);
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : String(err));
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="p-4 space-y-4 h-full overflow-y-auto">
      <div>
        <h3 className={`text-lg font-medium mb-2 ${isDark ? "text-white" : "text-gray-900"}`}>
          Schema Verification (Live Sync)
        </h3>
        <p className={`text-sm ${isDark ? "text-zinc-400" : "text-gray-500"}`}>
          Perform a dry-run to verify your Blueprint schema against the current database state.
          This will detect safe additions, risky size shrinkages, or breaking deletions.
        </p>
      </div>

      <button
        type="button"
        onClick={handleVerify}
        disabled={isLoading}
        className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-sm font-medium transition-colors disabled:opacity-50 flex items-center gap-2"
      >
        {isLoading && (
          <svg className="animate-spin h-4 w-4 text-white" fill="none" viewBox="0 0 24 24">
            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
          </svg>
        )}
        {isLoading ? "Verifying..." : "Verify Schema"}
      </button>

      {error && <div className="text-red-500 text-sm p-2 bg-red-50 dark:bg-red-900/20 rounded border border-red-200 dark:border-red-800">{error}</div>}

      {diffs !== null && (
        <div className="space-y-4 pt-4 border-t border-gray-200 dark:border-zinc-700">
          {diffs.length === 0 ? (
            <div className={`p-3 rounded-lg border ${isDark ? "bg-green-900/20 border-green-800 text-green-400" : "bg-green-50 border-green-200 text-green-700"}`}>
              Schema is in sync. No changes detected.
            </div>
          ) : (
            diffs.map((diff, idx) => (
              <div key={idx} className={`p-3 rounded-lg border ${
                diff.risk === "breaking" ? (isDark ? "bg-red-900/20 border-red-800" : "bg-red-50 border-red-200") :
                diff.risk === "warning" ? (isDark ? "bg-yellow-900/20 border-yellow-800" : "bg-yellow-50 border-yellow-200") :
                (isDark ? "bg-green-900/20 border-green-800" : "bg-green-50 border-green-200")
              }`}>
                <div className="flex items-start gap-3">
                  <span className={`px-2 py-1 text-xs font-bold rounded mt-0.5 uppercase ${
                    diff.risk === "breaking" ? "bg-red-100 text-red-800 dark:bg-red-900/50 dark:text-red-300" :
                    diff.risk === "warning" ? "bg-yellow-100 text-yellow-800 dark:bg-yellow-900/50 dark:text-yellow-300" :
                    "bg-green-100 text-green-800 dark:bg-green-900/50 dark:text-green-300"
                  }`}>{diff.risk}</span>
                  <div className="flex-1">
                    <p className={`text-sm font-semibold mb-1 ${isDark ? "text-gray-200" : "text-gray-900"}`}>
                      Column: {diff.column_name} ({diff.change_type})
                    </p>
                    <p className={`text-sm ${isDark ? "text-zinc-400" : "text-gray-600"}`}>
                      {diff.message}
                    </p>
                    {diff.risk === "breaking" && (
                      <div className="mt-3">
                        <a href="https://docs.framework-m.com/guides/zdm-backfill" target="_blank" rel="noreferrer" className="text-blue-600 dark:text-blue-400 hover:underline text-sm font-medium inline-flex items-center gap-1">
                          Read Zero Downtime Migration (ZDM) Guide
                          <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" /></svg>
                        </a>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      )}
    </div>
  );
}