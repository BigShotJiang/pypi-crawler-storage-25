import { render, screen, fireEvent, waitFor } from "@testing-library/react";
import { describe, it, expect, vi, beforeEach, MockInstance } from "vitest";
import { MigrationTab } from "./MigrationTab";
import React from "react";

let fetchSpy: MockInstance;

describe("MigrationTab", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    fetchSpy = vi.spyOn(globalThis, "fetch");
  });

  it("renders safe sync state when no diffs are found", async () => {
    fetchSpy.mockResolvedValueOnce({
      ok: true,
      json: async () => ({ diffs: [] }),
    } as unknown as Response);

    render(<MigrationTab isDark={false} getSchemaPayload={() => ({ name: "User", fields: [] })} />);

    const verifyBtn = screen.getByRole("button", { name: /Verify Schema/i });
    fireEvent.click(verifyBtn);

    await waitFor(() => {
      expect(screen.getByText(/Schema is in sync. No changes detected/i)).toBeInTheDocument();
    });
  });

  it("renders warnings with links to the Zero Downtime Migration (ZDM) docs for breaking changes", async () => {
    // Mock a breaking change response
    fetchSpy.mockResolvedValueOnce({
      ok: true,
      json: async () => ({
        diffs: [
          {
            change_type: "drop_column",
            risk: "breaking",
            column_name: "old_field",
            message: "Dropping column 'old_field'. This is a breaking change requiring ZDM backfill patterns.",
          }
        ]
      }),
    } as unknown as Response);

    render(<MigrationTab isDark={true} getSchemaPayload={() => ({ name: "User", fields: [] })} />);

    const verifyBtn = screen.getByRole("button", { name: /Verify Schema/i });
    fireEvent.click(verifyBtn);

    await waitFor(() => {
      const breakingElements = screen.getAllByText(/BREAKING/i);
      expect(breakingElements.length).toBeGreaterThan(0);
      expect(screen.getByText(/Dropping column 'old_field'/i)).toBeInTheDocument();
      const zdmLink = screen.getByRole("link", { name: /Zero Downtime Migration/i });
      expect(zdmLink).toHaveAttribute("href", expect.stringContaining("zdm"));
    });
  });
});