/**
 * Menu Component
 *
 * Sidebar navigation with icons and hover states
 * Theme-aware
 */

import { useMenu } from "@refinedev/core";
import { NavLink } from "react-router";
import { useTheme } from "../../providers/theme";

// Icon components
const DocTypeIcon = () => (
  <svg
    className="w-5 h-5"
    fill="none"
    viewBox="0 0 24 24"
    stroke="currentColor"
  >
    <path
      strokeLinecap="round"
      strokeLinejoin="round"
      strokeWidth={1.5}
      d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"
    />
  </svg>
);

const PrintIcon = () => (
  <svg
    className="w-5 h-5"
    fill="none"
    viewBox="0 0 24 24"
    stroke="currentColor"
  >
    <path
      strokeLinecap="round"
      strokeLinejoin="round"
      strokeWidth={1.5}
      d="M6 9V4a1 1 0 011-1h10a1 1 0 011 1v5M6 14H5a2 2 0 01-2-2v-1a2 2 0 012-2h14a2 2 0 012 2v1a2 2 0 01-2 2h-1M6 14v6a1 1 0 001 1h10a1 1 0 001-1v-6M8 17h8"
    />
  </svg>
);

const AggregateIcon = () => (
  <svg
    className="w-5 h-5"
    fill="none"
    viewBox="0 0 24 24"
    stroke="currentColor"
  >
    <path
      strokeLinecap="round"
      strokeLinejoin="round"
      strokeWidth={1.5}
      d="M6 6h4v4H6V6zm8 0h4v4h-4V6zM6 14h4v4H6v-4zm8 4h4v-4h-4v4zM10 8h4m-2 2v4"
    />
  </svg>
);

const ShellIcon = () => (
  <svg
    className="w-5 h-5"
    fill="none"
    viewBox="0 0 24 24"
    stroke="currentColor"
  >
    <path
      strokeLinecap="round"
      strokeLinejoin="round"
      strokeWidth={1.5}
      d="M4 7h16M4 12h10M4 17h7m9-5a2 2 0 100-4 2 2 0 000 4zm-1 6l1 1 1-1m-2 0h2"
    />
  </svg>
);

const getIcon = (label: string) => {
  switch (label?.toLowerCase()) {
    case "doctypes":
      return <DocTypeIcon />;
    case "print builder":
      return <PrintIcon />;
    case "aggregate builder":
      return <AggregateIcon />;
    case "shell config":
      return <ShellIcon />;
    default:
      return <DocTypeIcon />;
  }
};

export const Menu = () => {
  const { menuItems } = useMenu();
  const { theme } = useTheme();
  const isDark = theme === "dark";

  return (
    <nav className="py-4 px-3">
      <div className="space-y-1">
        {menuItems.map(item => (
          <NavLink
            key={item.key}
            to={item.route ?? "/"}
            className={({ isActive }) =>
              `flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                isActive
                  ? "bg-blue-500/10 text-blue-500"
                  : isDark
                    ? "text-zinc-400 hover:text-white hover:bg-zinc-800"
                    : "text-gray-600 hover:text-gray-900 hover:bg-gray-100"
              }`
            }
          >
            {getIcon(String(item.label ?? ""))}
            <span>{item.label}</span>
          </NavLink>
        ))}
      </div>
    </nav>
  );
};
