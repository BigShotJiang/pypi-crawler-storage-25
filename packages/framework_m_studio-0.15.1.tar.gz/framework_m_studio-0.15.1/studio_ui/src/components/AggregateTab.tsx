import React, { useState, useMemo } from "react";
import type { DocTypeSchema } from "../pages/doctypes/edit";

export interface AggregateTabProps {
  doctype: DocTypeSchema;
  setDoctype: React.Dispatch<React.SetStateAction<DocTypeSchema>>;
  isDark?: boolean;
}

export function AggregateTab({ doctype, setDoctype, isDark = false }: AggregateTabProps) {
  const [selectedChild, setSelectedChild] = useState("");

  const potentialChildren = useMemo(() => {
    return (doctype.fields || [])
      .map(f => {
        // Handle both "list[DocType]" and UI-normalized "Table" types
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        if (f.type === "Table" && (f as any).table_doctype) return (f as any).table_doctype;
        const match = f.type.match(/list\[(.*?)\]/);
        if (match) return match[1].trim();
        return null;
      })
      .filter(Boolean) as string[];
  }, [doctype.fields]);

  const currentChildren = (doctype.meta?.aggregate_children as string[]) || [];

  const handleAddChild = () => {
    if (selectedChild && !currentChildren.includes(selectedChild)) {
      setDoctype(prev => ({
        ...prev,
        meta: {
          ...prev.meta,
          is_aggregate_root: true,
          aggregate_children: [...currentChildren, selectedChild]
        }
      }));
      setSelectedChild("");
    }
  };

  const handleRemoveChild = (childToRemove: string) => {
    setDoctype(prev => ({
      ...prev,
      meta: {
        ...prev.meta,
        aggregate_children: currentChildren.filter(c => c !== childToRemove)
      }
    }));
  };

  return (
    <div className="space-y-6 p-6 h-full flex flex-col overflow-y-auto">
      <div>
        <h3 className={`text-lg font-medium ${isDark ? "text-white" : "text-gray-900"}`}>
          Aggregate Builder
        </h3>
        <p className={`text-sm ${isDark ? "text-zinc-400" : "text-gray-500"}`}>
          Define the boundary of this aggregate by selecting which child tables belong to it.
        </p>
      </div>

      <div className="flex gap-4 items-end">
        <label className="flex flex-col gap-1 text-sm flex-1 max-w-xs">
          <span className={`font-medium ${isDark ? "text-zinc-300" : "text-gray-700"}`}>Add Child to Boundary</span>
          <select
            aria-label="Add Child"
            value={selectedChild}
            onChange={(e) => setSelectedChild(e.target.value)}
            className={`w-full px-3 py-2 rounded-md border text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 ${isDark ? "bg-zinc-900 border-zinc-600 text-white" : "bg-white border-gray-300 text-gray-900"}`}
          >
            <option value="">Select child table...</option>
            {potentialChildren.filter(c => !currentChildren.includes(c)).map(childName => (
              <option key={childName} value={childName}>{childName}</option>
            ))}
          </select>
        </label>
        <button
          onClick={handleAddChild}
          disabled={!selectedChild}
          className="bg-blue-600 hover:bg-blue-700 disabled:bg-zinc-600 disabled:cursor-not-allowed text-white px-4 py-2 rounded-md transition-colors text-sm font-medium h-fit"
        >
          Add to Canvas
        </button>
      </div>

      {potentialChildren.length === 0 && (
        <p className="text-xs text-amber-600 dark:text-amber-500">
          Note: Add a "Table" field to this DocType first to define aggregate children.
        </p>
      )}

      <div className={`flex-1 border rounded-xl overflow-hidden relative flex flex-col min-h-[300px] ${isDark ? "border-zinc-700 bg-zinc-900" : "border-gray-200 bg-gray-50"}`}>
        <div data-testid="rf__wrapper" className={`flex-1 overflow-auto p-8 ${isDark ? "bg-zinc-950" : "bg-gray-50"}`}>
          <div className={`border-2 border-blue-500 p-4 rounded-lg inline-block shadow-sm ${isDark ? "bg-zinc-800 text-white" : "bg-white text-gray-900"}`}>
            <h3 className="font-bold text-blue-500">{doctype.name || "Unnamed DocType"} (Root)</h3>
          </div>

          {currentChildren.length > 0 ? (
            <div className="mt-8 flex flex-col gap-4 pl-8 border-l-2 border-dashed border-blue-300 ml-8">
              {currentChildren.map(child => (
                <div key={child} className={`border p-4 rounded-lg flex items-center justify-between w-64 shadow-sm relative ${isDark ? "border-zinc-600 bg-zinc-800 text-white" : "border-gray-300 bg-white text-gray-900"}`}>
                  {/* Connection line indicator */}
                  <div className="absolute w-8 border-t-2 border-dashed border-blue-300 top-1/2 -left-8"></div>
                  <span className="font-medium">{child}</span>
                  <button
                    onClick={() => handleRemoveChild(child)}
                    className="text-gray-400 hover:text-red-500 transition-colors p-1"
                    title="Remove from aggregate"
                  >
                    <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                    </svg>
                  </button>
                </div>
              ))}
            </div>
          ) : (
            <div className="mt-8 ml-8 text-sm italic text-gray-400">
              No children added to this aggregate yet.
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
