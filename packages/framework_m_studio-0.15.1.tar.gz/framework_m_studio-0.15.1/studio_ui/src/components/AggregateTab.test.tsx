import { render, screen, fireEvent } from "@testing-library/react";
import { describe, it, expect } from "vitest";
import { AggregateTab } from "./AggregateTab";
import React, { useState } from "react";
import type { DocTypeSchema } from "../pages/doctypes/edit";

const TestWrapper = () => {
  const [doctype, setDoctype] = useState<DocTypeSchema>({
    name: "SalesOrder",
    fields: [
      { name: "items", type: "list[SalesOrderItem]", required: true, _id: "f1" }
    ],
    meta: { is_aggregate_root: false, aggregate_children: [] }
  });

  return (
    <div>
      <AggregateTab doctype={doctype} setDoctype={setDoctype} isDark={false} />
      <div data-testid="debug-is-root">{doctype.meta?.is_aggregate_root ? "true" : "false"}</div>
      <div data-testid="debug-children">{JSON.stringify(doctype.meta?.aggregate_children)}</div>
    </div>
  );
};

describe("AggregateTab", () => {
  it("renders visual canvas and updates aggregate_children in state without network calls", () => {
    render(<TestWrapper />);

    // We expect the visual canvas to automatically render a node for the root
    expect(screen.getByText("SalesOrder (Root)")).toBeInTheDocument();
    expect(screen.getByTestId("rf__wrapper")).toBeInTheDocument();

    // Simulate adding a child node to the canvas
    const childSelect = screen.getByRole("combobox", { name: /Add Child/i });
    fireEvent.change(childSelect, { target: { value: "SalesOrderItem" } });
    fireEvent.click(screen.getByRole("button", { name: /Add to Canvas/i }));

    // Assert that the state was correctly updated via setDoctype
    expect(screen.getByTestId("debug-is-root")).toHaveTextContent("true");
    expect(screen.getByTestId("debug-children")).toHaveTextContent('["SalesOrderItem"]');
  });
});
