import { useDraggable } from "@dnd-kit/core";
import type { FieldTypeInfo } from "../../components/FieldEditor";

export function PaletteItem({ type, isDark }: { type: FieldTypeInfo; isDark: boolean }) {
  const { attributes, listeners, setNodeRef, isDragging } = useDraggable({
    id: `palette-${type.name}`,
    data: { type: "palette-item", fieldType: type.name },
  });

  return (
    <div
      ref={setNodeRef}
      {...listeners}
      {...attributes}
      className={`p-3 mb-2 rounded-lg border cursor-grab text-sm font-medium shadow-sm transition-opacity ${
        isDragging ? "opacity-50" : "opacity-100"
      } ${
        isDark ? "bg-zinc-800 border-zinc-700 hover:border-zinc-600 text-zinc-200" : "bg-white border-gray-200 hover:border-gray-300 text-gray-700"
      }`}
    >
      <div className="flex flex-col">
        <div className="flex items-center gap-2">
          <span className="text-blue-500 font-bold text-lg leading-none">+</span>
          <span className="truncate">{type.label || type.name}</span>
        </div>
        {type.domain && <div className={`text-[10px] uppercase tracking-wider mt-1 ml-4 ${isDark ? "text-zinc-500" : "text-gray-400"}`}>{type.domain}</div>}
      </div>
    </div>
  );
}