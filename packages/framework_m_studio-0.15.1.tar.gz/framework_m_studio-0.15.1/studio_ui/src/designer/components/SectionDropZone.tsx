import { useDroppable } from "@dnd-kit/core";

export function SectionDropZone({ sectionIndex }: { sectionIndex: number }) {
  const { setNodeRef, isOver } = useDroppable({
    id: `section-dropzone-${sectionIndex}`,
  });

  return (
    <div
      ref={setNodeRef}
      className={`h-16 border-2 border-dashed rounded-lg flex items-center justify-center text-sm transition-colors w-full ${
        isOver ? "border-blue-500 bg-blue-500/10 text-blue-500" : "border-gray-300/50 text-gray-500/80"
      }`}
    >
      Drop fields here
    </div>
  );
}