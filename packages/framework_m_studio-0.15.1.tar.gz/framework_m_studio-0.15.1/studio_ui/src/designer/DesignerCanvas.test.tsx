import { render, screen, fireEvent } from "@testing-library/react";
import { describe, it, expect, vi } from "vitest";
import React, { useState } from "react";
import { DesignerCanvas } from "./DesignerCanvas";

// Mock shared libraries to avoid transformation errors
vi.mock("@framework-m/ui", () => ({
  ThemeProvider: ({ children }: { children: React.ReactNode }) => <>{children}</>,
  MProvider: ({ children }: { children: React.ReactNode }) => <>{children}</>,
  YStack: ({ children }: { children: React.ReactNode }) => <div>{children}</div>,
  XStack: ({ children }: { children: React.ReactNode }) => <div>{children}</div>,
  MStack: ({ children }: { children: React.ReactNode }) => <div>{children}</div>,
  MText: ({ children }: { children: React.ReactNode }) => <span>{children}</span>,
  Heading: ({ children }: { children: React.ReactNode }) => <h2>{children}</h2>,
  Paragraph: ({ children }: { children: React.ReactNode }) => <p>{children}</p>,
  Card: ({ children }: { children: React.ReactNode }) => <div>{children}</div>,
  Button: ({ children }: { children: React.ReactNode }) => <button>{children}</button>,
  Icon: ({ name }: { name: string }) => <span data-testid={`icon-${name}`} />,
}));
import { PropertiesPanel } from "../components/PropertiesPanel";
import type { DocTypeSchema, SelectedNode } from "../../src/pages/doctypes/edit";
import type { FieldData } from "../../src/components/FieldEditor";

const TestWrapper = () => {
  const [doctype, setDoctype] = useState<DocTypeSchema>({
    name: "TestDoc",
    fields: [{ name: "status", type: "str", required: false, _id: "f1" }],
    meta: {
      ui_meta: {
        form: {
          layout: "sections",
          sections: [{ fields: ["status"] }]
        }
      }
    }
  });

  // Start with the first field selected
  const [selectedNode, setSelectedNode] = useState<SelectedNode | null>({ type: "field", index: 0 });

  const handleFieldChange = (updatedField: FieldData) => {
    setDoctype(prev => {
      const newFields = [...prev.fields];
      newFields[0] = { ...updatedField, _id: prev.fields[0]._id };
      return { ...prev, fields: newFields };
    });
  };

  return (
    <div className="flex">
      <DesignerCanvas
        doctype={doctype}
        setDoctype={setDoctype}
        selectedNode={selectedNode}
        onSelectNode={setSelectedNode}
        onDeleteField={vi.fn()}
        fieldTypes={[{ name: "str", category: "primitive", pydantic_type: "str", label: "String", ui_widget: "text" }]}
        isDark={false}
      />
      <PropertiesPanel
        doctype={doctype}
        setDoctype={setDoctype}
        selectedNode={selectedNode}
        onSelectNode={setSelectedNode}
        fieldTypes={[{ name: "str", category: "primitive", pydantic_type: "str", label: "String", ui_widget: "text" }]}
        availableDocTypes={[]}
        handleFieldChange={handleFieldChange}
        handleAddField={vi.fn()}
        isDark={false}
      />
      {/* Hidden div to expose the current ui_widget state for easy assertions */}
      <div data-testid="debug-widget">{doctype.fields[0].ui_widget || "none"}</div>
    </div>
  );
};

describe("DesignerCanvas & PropertiesPanel UI Metadata", () => {
  it("allows changing a field's ui_widget from the properties panel", () => {
    render(<TestWrapper />);

    // Verify the field is rendered in the canvas
    expect(screen.getByText("status")).toBeInTheDocument();

    // Find the new UI Widget dropdown in the Properties Panel
    const widgetSelect = screen.getByLabelText(/UI Widget/i);
    expect(widgetSelect).toBeInTheDocument();

    // Change the widget type to RadioGroup
    fireEvent.change(widgetSelect, { target: { value: "RadioGroup" } });

    // Assert that the state updated successfully
    expect(screen.getByTestId("debug-widget")).toHaveTextContent("RadioGroup");
  });
});