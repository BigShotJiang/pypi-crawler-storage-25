import { useState, useCallback } from "react";
import { DragEndEvent, DragStartEvent } from "@dnd-kit/core";
import type { DocTypeSchema, FieldDef, FormSection, FormTab } from "../../pages/doctypes/edit";

export function useDesignerState(
  setDoctype: React.Dispatch<React.SetStateAction<DocTypeSchema>>
) {
  const [activeDragId, setActiveDragId] = useState<string | null>(null);
  const [activeDesignerTab, setActiveDesignerTab] = useState<number>(0);

  const handleDragStart = useCallback((event: DragStartEvent) => {
    setActiveDragId(String(event.active.id));
  }, []);

  const handleDragEnd = useCallback((event: DragEndEvent) => {
    setActiveDragId(null);
    const { active, over } = event;
    if (!over) return;

    const activeId = String(active.id);
    const overId = String(over.id);
    if (activeId === overId) return;

    const isFromPalette = activeId.startsWith("palette-");
    let tabToSwitch: number | null = null;

    setDoctype((prev: DocTypeSchema) => {
      let activeField;
      const newFieldsList = [...prev.fields];

      if (isFromPalette) {
        const fieldTypeName = activeId.replace("palette-", "");
        activeField = {
          name: `new_${fieldTypeName.toLowerCase()}_${Date.now()}`,
          type: fieldTypeName,
          required: false,
          _id: `field_${Date.now()}`,
        };
        newFieldsList.push(activeField as FieldDef);
      } else {
        activeField = prev.fields.find((f: FieldDef) => f._id === activeId);
        if (!activeField) return prev;
      }

      const prevMeta = prev.meta || {};
      const prevUiMeta = prevMeta.ui_meta || {};
      const prevForm = prevUiMeta.form || { layout: "sections", sections: [{ fields: prev.fields.map((f: FieldDef) => f.name) }] };
      const newForm = JSON.parse(JSON.stringify(prevForm));

      if (!isFromPalette) {
        const clearSections = (secs: FormSection[]) => secs.forEach((s: FormSection) => {
          if (s.fields) s.fields = s.fields.filter((name: string) => name !== activeField.name);
        });
        if (newForm.layout === "tabs") {
          newForm.tabs?.forEach((t: FormTab) => clearSections(t.sections || []));
        } else {
          clearSections(newForm.sections || []);
        }
      }

      const safeTabIdx = newForm.tabs ? Math.min(activeDesignerTab, Math.max(0, newForm.tabs.length - 1)) : 0;
      const targetSections = newForm.layout === "tabs" ? (newForm.tabs?.[safeTabIdx]?.sections || []) : (newForm.sections || []);

      if (overId.startsWith("section-dropzone-")) {
        const sectionIndex = parseInt(overId.replace("section-dropzone-", ""), 10);
        if (targetSections[sectionIndex]) {
          targetSections[sectionIndex].fields = targetSections[sectionIndex].fields || [];
          targetSections[sectionIndex].fields.push(activeField.name);
        }
      } else if (overId.startsWith("tab-dropzone-")) {
        const tabIndex = parseInt(overId.replace("tab-dropzone-", ""), 10);
        if (newForm.layout === "tabs" && newForm.tabs && newForm.tabs[tabIndex]) {
          const targetTab = newForm.tabs[tabIndex];
          targetTab.sections = targetTab.sections || [];
          if (targetTab.sections.length === 0) {
            targetTab.sections.push({ label: "New Section", fields: [], columns: 1 });
          }
          targetTab.sections[0].fields = targetTab.sections[0].fields || [];
          targetTab.sections[0].fields.push(activeField.name);
          tabToSwitch = tabIndex;
        }
      } else {
        const overField = prev.fields.find((f: FieldDef) => f._id === overId);
        if (overField) {
          let targetSectionIndex = 0;
          let targetFieldIndex = 0;

          targetSections.forEach((sec: FormSection, sIdx: number) => {
            const fIdx = (sec.fields || []).indexOf(overField.name);
            if (fIdx !== -1) {
              targetSectionIndex = sIdx;
              targetFieldIndex = fIdx;
            }
          });

          if (targetSections[targetSectionIndex]) {
            targetSections[targetSectionIndex].fields = targetSections[targetSectionIndex].fields || [];
            let insertAt = targetFieldIndex;
            if (!isFromPalette) {
              const oldFlatIndex = prev.fields.findIndex((f: FieldDef) => f._id === activeId);
              const newFlatIndex = prev.fields.findIndex((f: FieldDef) => f._id === overId);
              insertAt = oldFlatIndex < newFlatIndex ? targetFieldIndex + 1 : targetFieldIndex;
            }
            targetSections[targetSectionIndex].fields.splice(insertAt, 0, activeField.name);
          }
        } else if (isFromPalette) {
          if (targetSections[0]) {
            targetSections[0].fields = targetSections[0].fields || [];
            targetSections[0].fields.push(activeField.name);
          }
        }
      }

      return { ...prev, fields: newFieldsList, meta: { ...prevMeta, ui_meta: { ...prevUiMeta, form: newForm } } };
    });

    if (tabToSwitch !== null) {
      setActiveDesignerTab(tabToSwitch);
    }
  }, [activeDesignerTab, setDoctype]);

  const handleLayoutChange = useCallback((layout: "sections" | "tabs") => {
    setDoctype((prev: DocTypeSchema) => {
      const prevMeta = prev.meta || {};
      const prevUiMeta = prevMeta.ui_meta || {};
      const prevForm = prevUiMeta.form || { layout: "sections", sections: [{ fields: prev.fields.map((f: FieldDef) => f.name) }] };
      const newForm = { ...prevForm, layout };

      if (layout === "tabs" && !newForm.tabs) {
        newForm.tabs = [{ label: "General", sections: newForm.sections || [] }];
        newForm.sections = [];
      } else if (layout === "sections" && (!newForm.sections?.length) && newForm.tabs?.length) {
        newForm.sections = newForm.tabs.flatMap((t: FormTab) => t.sections || []);
      }

      return { ...prev, meta: { ...prevMeta, ui_meta: { ...prevUiMeta, form: newForm } } };
    });
    setActiveDesignerTab(0);
  }, [setDoctype]);

  const handleAddSection = useCallback(() => {
    setDoctype((prev: DocTypeSchema) => {
      const prevMeta = prev.meta || {};
      const prevUiMeta = prevMeta.ui_meta || {};
      const prevForm = prevUiMeta.form || { layout: "sections", sections: [] };
      const newForm = JSON.parse(JSON.stringify(prevForm));
      const safeTabIdx = newForm.tabs ? Math.min(activeDesignerTab, Math.max(0, newForm.tabs.length - 1)) : 0;

      if (newForm.layout === "tabs") {
        if (!newForm.tabs) newForm.tabs = [{ label: "Tab 1", sections: [] }];
        if (!newForm.tabs[safeTabIdx]) newForm.tabs[safeTabIdx] = { label: `Tab ${safeTabIdx+1}`, sections: [] };
        newForm.tabs[safeTabIdx].sections.push({ label: "New Section", fields: [], columns: 1 });
      } else {
        if (!newForm.sections) newForm.sections = [];
        newForm.sections.push({ label: "New Section", fields: [], columns: 1 });
      }

      return { ...prev, meta: { ...prevMeta, ui_meta: { ...prevUiMeta, form: newForm } } };
    });
  }, [activeDesignerTab, setDoctype]);

  const handleUpdateSectionColumns = useCallback((sectionIndex: number, columns: 1 | 2 | 3) => {
    setDoctype((prev: DocTypeSchema) => {
      const prevMeta = prev.meta || {};
      const prevUiMeta = prevMeta.ui_meta || {};
      const prevForm = prevUiMeta.form || { layout: "sections", sections: [{ fields: prev.fields.map((f: FieldDef) => f.name) }] };
      const newForm = JSON.parse(JSON.stringify(prevForm));
      const safeTabIdx = newForm.tabs ? Math.min(activeDesignerTab, Math.max(0, newForm.tabs.length - 1)) : 0;
      const targetSections = newForm.layout === "tabs" ? newForm.tabs?.[safeTabIdx]?.sections : newForm.sections;

      if (targetSections && targetSections[sectionIndex]) {
        targetSections[sectionIndex].columns = columns;
      }

      return { ...prev, meta: { ...prevMeta, ui_meta: { ...prevUiMeta, form: newForm } } };
    });
  }, [activeDesignerTab, setDoctype]);

  const handleAddTab = useCallback(() => {
    setDoctype((prev: DocTypeSchema) => {
      const prevMeta = prev.meta || {};
      const prevUiMeta = prevMeta.ui_meta || {};
      const newForm = JSON.parse(JSON.stringify(prevUiMeta.form || { layout: "tabs", tabs: [] }));
      if (!newForm.tabs) newForm.tabs = [];
      newForm.tabs.push({ label: `Tab ${newForm.tabs.length + 1}`, sections: [{ label: "New Section", fields: [], columns: 1 }] });
      return { ...prev, meta: { ...prevMeta, ui_meta: { ...prevUiMeta, form: newForm } } };
    });
  }, [setDoctype]);

  return {
    activeDragId,
    activeDesignerTab,
    setActiveDesignerTab,
    handleDragStart,
    handleDragEnd,
    handleLayoutChange,
    handleAddSection,
    handleUpdateSectionColumns,
    handleAddTab,
  };
}