import React, { useMemo, useState } from "react";
import { SectionField } from "@framework-m/desk";
import { ThemeProvider, MProvider } from "@framework-m/ui";
import type { DocTypeSchema, FieldDef, SelectedNode, FormSection, FormTab } from "../pages/doctypes/edit";
import type { FieldTypeInfo, FieldData } from "../components/FieldEditor";
import {
  DndContext,
  closestCenter,
  KeyboardSensor,
  PointerSensor,
  useSensor,
  useSensors,
  useDroppable,
} from "@dnd-kit/core";
import { SortableContext, sortableKeyboardCoordinates, rectSortingStrategy, useSortable } from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";
import { PaletteItem } from "./components/PaletteItem";
import { SectionDropZone } from "./components/SectionDropZone";
import { useDesignerState } from "./hooks/useDesignerState";

/**
 * Extract clean type from Annotated[type, ...] or return as-is
 */
function getCleanType(typeStr: string): string {
  const match = typeStr.match(/^Annotated\[(.*?),/);
  return match ? match[1].trim() : typeStr;
}

/**
 * Format validators for display
 */
function formatValidators(validators?: FieldData["validators"]): string {
  if (!validators) return "";
  const parts: string[] = [];
  if (validators.min_length !== undefined)
    parts.push(`min_length=${validators.min_length}`);
  if (validators.max_length !== undefined)
    parts.push(`max_length=${validators.max_length}`);
  if (validators.pattern) parts.push(`pattern="${validators.pattern}"`);
  if (validators.min_value !== undefined)
    parts.push(`ge=${validators.min_value}`);
  if (validators.max_value !== undefined)
    parts.push(`le=${validators.max_value}`);
  return parts.length > 0 ? `Field(${parts.join(", ")})` : "";
}

// Sortable Field Item Component
export function SortableFieldItem({
  field,
  isSelected,
  onSelect,
  onDelete,
  isDark,
}: {
  field: FieldDef;
  isSelected: boolean;
  onSelect: () => void;
  onDelete: () => void;
  isDark: boolean;
}) {
  const { attributes, listeners, setNodeRef, transform, transition } =
    useSortable({ id: field._id });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
  };

  return (
    <div
      ref={setNodeRef}
      style={style}
      className={`p-1.5 rounded-md border cursor-pointer transition-all ${
        isSelected
          ? "bg-blue-500/10 border-blue-500"
          : isDark
            ? "bg-zinc-800 border-zinc-700 hover:border-zinc-600"
            : "bg-white border-gray-200 hover:border-gray-300 shadow-sm"
      }`}
      onClick={(e) => {
        e.stopPropagation();
        onSelect();
      }}
    >
      <div className="flex items-center gap-2">
        <div
          {...attributes}
          {...listeners}
          className={`cursor-grab ${
            isDark
              ? "text-zinc-500 hover:text-zinc-400"
              : "text-gray-400 hover:text-gray-600"
          }`}
        >
          <svg className="w-3.5 h-3.5" fill="currentColor" viewBox="0 0 20 20">
            <path d="M7 2a2 2 0 1 0 .001 4.001A2 2 0 0 0 7 2zm0 6a2 2 0 1 0 .001 4.001A2 2 0 0 0 7 8zm0 6a2 2 0 1 0 .001 4.001A2 2 0 0 0 7 14zm6-8a2 2 0 1 0-.001-4.001A2 2 0 0 0 13 6zm0 2a2 2 0 1 0 .001 4.001A2 2 0 0 0 13 8zm0 6a2 2 0 1 0 .001 4.001A2 2 0 0 0 13 14z" />
          </svg>
        </div>
        <div className="flex-1 min-w-0">
          <div
            className={`text-sm font-medium truncate ${
              isDark ? "text-white" : "text-gray-900"
            }`}
          >
            {field.name}
          </div>
          <div
            className={`text-xs ${isDark ? "text-zinc-400" : "text-gray-500"}`}
          >
            <div className="font-mono truncate">{getCleanType(field.type)}</div>
            <div className="flex items-center gap-1.5 text-[10px] leading-tight mt-0.5">
              {field.required && <span className="text-red-500">required</span>}
              {formatValidators(field.validators) && (
                <span className="text-green-500 truncate">
                  {formatValidators(field.validators)}
                </span>
              )}
            </div>
          </div>
        </div>
        <button
          onClick={e => {
            e.stopPropagation();
            onDelete();
          }}
          className={`transition-colors ${
            isDark
              ? "text-zinc-500 hover:text-red-400"
              : "text-gray-400 hover:text-red-500"
          }`}
        >
          <svg
            className="w-4 h-4"
            fill="none"
            viewBox="0 0 24 24"
            stroke="currentColor"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M6 18L18 6M6 6l12 12"
            />
          </svg>
        </button>
      </div>
    </div>
  );
}

export interface DesignerCanvasProps {
  doctype: DocTypeSchema;
  setDoctype: React.Dispatch<React.SetStateAction<DocTypeSchema>>;
  selectedNode: SelectedNode | null;
  onSelectNode: (node: SelectedNode | null) => void;
  onDeleteField: (index: number) => void;
  fieldTypes: FieldTypeInfo[];
  isDark: boolean;
}

export function DesignerCanvas({
  doctype,
  setDoctype,
  selectedNode,
  onSelectNode,
  onDeleteField,
  fieldTypes,
  isDark,
}: DesignerCanvasProps) {
  const {
    activeDesignerTab,
    setActiveDesignerTab,
    handleDragStart,
    handleDragEnd,
    handleLayoutChange,
    handleAddSection,
    handleUpdateSectionColumns,
    handleAddTab,
  } = useDesignerState(setDoctype);

  const fieldsByName = useMemo(() => new Map<string, FieldDef>(doctype.fields.map(f => [f.name, f])), [doctype.fields]);
  const fieldIndicesByName = useMemo(() => new Map<string, number>(doctype.fields.map((f, i) => [f.name, i])), [doctype.fields]);

  const formLayout = doctype.meta?.ui_meta?.form || {
    layout: "sections",
    sections: [{ fields: doctype.fields.map(f => f.name) }],
  };
  const safeActiveTab = Math.min(activeDesignerTab, Math.max(0, (formLayout.tabs?.length || 1) - 1));
  const currentSections = formLayout.layout === "tabs" ? (formLayout.tabs?.[safeActiveTab]?.sections || []) : (formLayout.sections || []);

  const sensors = useSensors(
    useSensor(PointerSensor),
    useSensor(KeyboardSensor, { coordinateGetter: sortableKeyboardCoordinates })
  );

  const [primitivesCollapsed, setPrimitivesCollapsed] = useState(true);
  const [collapsedDomains, setCollapsedDomains] = useState<Record<string, boolean>>({});
  const [selectedDomainFilter, setSelectedDomainFilter] = useState<string>("All");
  const [isToolboxCollapsed, setIsToolboxCollapsed] = useState(false);

  const blueprints = useMemo(() => fieldTypes.filter(t => t.category === "blueprint"), [fieldTypes]);
  const domains = useMemo(() => Array.from(new Set(blueprints.map(b => b.domain || "Other"))), [blueprints]);
  const visibleDomains = selectedDomainFilter === "All" ? domains : domains.filter(d => d === selectedDomainFilter);
  const primitives = useMemo(() => fieldTypes.filter(t => t.category !== "blueprint"), [fieldTypes]);

  return (
    <ThemeProvider defaultTheme={isDark ? "dark" : "light"}>
      <MProvider>
        <DndContext sensors={sensors} collisionDetection={closestCenter} onDragStart={handleDragStart} onDragEnd={handleDragEnd}>
          <div className="flex h-full w-full">
            {/* Left Sidebar: Toolbox */}
            <div className={`transition-all duration-300 ease-in-out border-r flex flex-col shrink-0 ${isToolboxCollapsed ? "w-12" : "w-60"} ${isDark ? "border-zinc-700 bg-zinc-900/30" : "border-gray-200 bg-gray-50/50"}`}>
              <div className={`h-12 border-b flex items-center whitespace-nowrap overflow-hidden shrink-0 ${isToolboxCollapsed ? "justify-center px-2" : "justify-between px-4"} ${isDark ? "border-zinc-700" : "border-gray-200"}`}>
                {!isToolboxCollapsed && <h3 className={`font-semibold ${isDark ? "text-white" : "text-gray-900"}`}>Toolbox</h3>}
                <button onClick={() => setIsToolboxCollapsed(!isToolboxCollapsed)} className={`p-1.5 rounded-lg hover:bg-gray-200 dark:hover:bg-zinc-800 transition-colors ${isDark ? "text-zinc-400" : "text-gray-500"}`} title={isToolboxCollapsed ? "Expand Toolbox" : "Collapse Toolbox"}>
                  <svg className={`w-5 h-5 transition-transform duration-300 ${isToolboxCollapsed ? "rotate-180" : ""}`} fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" /></svg>
                </button>
              </div>
              <div className={`flex-1 flex flex-col overflow-hidden ${isToolboxCollapsed ? "hidden" : "block"}`}>
                <div className={`p-2 border-b shrink-0 ${isDark ? "border-zinc-700" : "border-gray-200"}`}>
                  <select value={selectedDomainFilter} onChange={e => setSelectedDomainFilter(e.target.value)} className={`w-full text-xs rounded-md border px-2 py-1.5 focus:outline-none focus:ring-2 focus:ring-blue-500 ${isDark ? "bg-zinc-900 border-zinc-600 text-white" : "bg-white border-gray-300 text-gray-900"}`}>
                    <option value="All">All Domains</option>
                    {domains.map(d => (<option key={d} value={d}>{d}</option>))}
                  </select>
                </div>
                <div className="p-3 overflow-y-auto flex-1">
                  <div className="space-y-4">
                    {visibleDomains.map(domain => {
                      const domainBlueprints = blueprints.filter(b => (b.domain || "Other") === domain);
                      const isCollapsed = collapsedDomains[domain] || false;
                      return (
                        <div key={domain}>
                          <button onClick={() => setCollapsedDomains(prev => ({ ...prev, [domain]: !prev[domain] }))} className={`flex items-center justify-between w-full text-xs font-semibold uppercase tracking-wider mb-3 ${isDark ? "text-zinc-400 hover:text-zinc-300" : "text-gray-500 hover:text-gray-700"}`}>
                            <span>{domain} Blueprints</span>
                            <svg className={`w-4 h-4 transition-transform ${isCollapsed ? "" : "rotate-180"}`} fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" /></svg>
                          </button>
                          {!isCollapsed && (
                            <div className="mb-6">
                              {domainBlueprints.map(type => <PaletteItem key={type.name} type={type} isDark={isDark} />)}
                            </div>
                          )}
                        </div>
                      );
                    })}
                    <div>
                      <button onClick={() => setPrimitivesCollapsed(!primitivesCollapsed)} className={`flex items-center justify-between w-full text-xs font-semibold uppercase tracking-wider mb-3 ${isDark ? "text-zinc-400 hover:text-zinc-300" : "text-gray-500 hover:text-gray-700"}`}>
                        <span>Primitive Fields</span>
                        <svg className={`w-4 h-4 transition-transform ${primitivesCollapsed ? "" : "rotate-180"}`} fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" /></svg>
                      </button>
                      {!primitivesCollapsed && (
                        <div>
                          {primitives.map(type => <PaletteItem key={type.name} type={type} isDark={isDark} />)}
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Right Area: Canvas Workspace */}
            <div className="flex-1 overflow-y-auto p-4 md:p-6">
              <SortableContext items={doctype.fields.map(f => f._id)} strategy={rectSortingStrategy}>
                <div className="max-w-4xl mx-auto space-y-4 pb-20">
                  <div className={`flex items-center justify-between p-2 rounded-lg border shadow-sm ${isDark ? "bg-zinc-900 border-zinc-700" : "bg-white"}`}>
                    <span className="text-sm font-medium text-gray-500 ml-2">Form Layout</span>
                    <div className={`flex p-1 rounded-md ${isDark ? "bg-zinc-800" : "bg-gray-100"}`}>
                      <button onClick={() => handleLayoutChange("sections")} className={`px-3 py-1 text-xs font-medium rounded transition-colors ${formLayout.layout !== "tabs" ? (isDark ? "bg-zinc-700 text-white shadow-sm" : "bg-white text-gray-900 shadow-sm") : "text-gray-500"}`}>Scrolling Sections</button>
                      <button onClick={() => handleLayoutChange("tabs")} className={`px-3 py-1 text-xs font-medium rounded transition-colors ${formLayout.layout === "tabs" ? (isDark ? "bg-zinc-700 text-white shadow-sm" : "bg-white text-gray-900 shadow-sm") : "text-gray-500"}`}>Tabbed Container</button>
                    </div>
                  </div>

                  {formLayout.layout === "tabs" && (
                    <div className="flex items-center gap-2 border-b dark:border-zinc-700 pb-2 overflow-x-auto">
                      {(formLayout.tabs || []).map((tab: FormTab, tIdx: number) => (
                        <TabDropZone
                          key={tIdx}
                          tabIndex={tIdx}
                          label={tab.label || `Tab ${tIdx + 1}`}
                          isActive={safeActiveTab === tIdx}
                          selected={selectedNode?.type === "tab" && selectedNode.tabIndex === tIdx}
                          onClick={(e: React.MouseEvent) => { e.stopPropagation(); setActiveDesignerTab(tIdx); onSelectNode({ type: "tab", tabIndex: tIdx }); }}
                        />
                      ))}
                    <button onClick={handleAddTab} className="px-2.5 py-1 text-[11px] font-medium text-gray-500 border border-dashed rounded-full hover:bg-gray-50 dark:hover:bg-zinc-800 ml-2">+ Add Tab</button>
                    </div>
                  )}

                  {currentSections.map((section: FormSection, sectionIndex: number) => (
                  <div key={`section-wrapper-${sectionIndex}`} className={`relative group p-1.5 rounded-lg border-2 transition-colors cursor-pointer ${selectedNode?.type === "section" && selectedNode.sectionIndex === sectionIndex && (formLayout.layout === "tabs" ? selectedNode.tabIndex === safeActiveTab : true) ? "border-blue-500 bg-blue-50/30 dark:bg-blue-900/10" : "border-transparent hover:border-gray-200 dark:hover:border-zinc-800"}`} onClick={(e) => { e.stopPropagation(); onSelectNode({ type: "section", sectionIndex, tabIndex: formLayout.layout === "tabs" ? safeActiveTab : undefined }); }}>
                      <div className="absolute right-2 top-2 z-10 opacity-0 group-hover:opacity-100 transition-opacity flex items-center gap-1 bg-white dark:bg-zinc-800 p-1 rounded-md shadow-sm border dark:border-zinc-700">
                        <span className="text-xs text-gray-500 mr-2 px-1">Cols:</span>
                        {[1, 2, 3].map((col) => (
                          <button key={col} onClick={() => handleUpdateSectionColumns(sectionIndex, col as 1|2|3)} className={`w-6 h-6 text-xs rounded transition-colors ${(section.columns || 1) === col ? "bg-blue-500 text-white" : "bg-gray-100 dark:bg-zinc-700 text-gray-600 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-zinc-600"}`}>
                            {col}
                          </button>
                        ))}
                      </div>
                      <SectionField label={section.label || `Section ${sectionIndex + 1}`} collapsible columns={section.columns || 1}>
                      <div className="grid gap-2 w-full" style={{ gridTemplateColumns: `repeat(${section.columns || 1}, minmax(0, 1fr))` }}>
                          {(section.fields || []).map((fieldName: string) => {
                            const field = fieldsByName.get(fieldName);
                            const fieldIndex = fieldIndicesByName.get(fieldName);
                            if (!field || typeof fieldIndex !== "number") return null;
                            return (
                              <SortableFieldItem key={field._id} field={field} isSelected={selectedNode?.type === "field" && selectedNode.index === fieldIndex} onSelect={() => onSelectNode({ type: "field", index: fieldIndex })} onDelete={() => onDeleteField(fieldIndex)} isDark={isDark} />
                            );
                          })}
                          <div className="col-span-full">
                            <SectionDropZone sectionIndex={sectionIndex} />
                          </div>
                        </div>
                      </SectionField>
                    </div>
                  ))}

                <button onClick={handleAddSection} className="w-full py-2 text-sm border-2 border-dashed border-gray-300 dark:border-zinc-700 rounded-lg text-gray-500 dark:text-zinc-400 hover:bg-gray-50 dark:hover:bg-zinc-800/50 hover:border-blue-400 hover:text-blue-500 transition-all font-medium flex items-center justify-center gap-1.5">
                  <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" /></svg>
                    Add New Section
                  </button>
                </div>
              </SortableContext>
            </div>
          </div>
        </DndContext>
      </MProvider>
    </ThemeProvider>
  );
}

interface TabDropZoneProps {
  tabIndex: number;
  label: string;
  isActive: boolean;
  selected: boolean;
  onClick: (e: React.MouseEvent) => void;
}

function TabDropZone({ tabIndex, label, isActive, onClick, selected }: TabDropZoneProps) {
  const { setNodeRef, isOver } = useDroppable({
    id: `tab-dropzone-${tabIndex}`,
  });

  return (
    <button
      ref={setNodeRef}
      onClick={onClick}
      className={`px-3 py-1.5 text-xs font-medium rounded-t-md border-b-2 transition-colors ${
        isOver ? "border-blue-500 bg-blue-50 dark:bg-blue-900/20 text-blue-600" :
        selected ? "border-blue-500 bg-blue-500/10 text-blue-700" :
        isActive ? "border-blue-500 text-blue-600" :
        "border-transparent text-gray-500 hover:text-gray-700 dark:hover:text-gray-300 hover:border-gray-300"
      }`}
    >
      {label}
    </button>
  );
}