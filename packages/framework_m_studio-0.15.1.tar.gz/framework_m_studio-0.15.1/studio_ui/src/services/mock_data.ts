/**
 * Studio mock/live data helpers for Sandbox preview.
 */

import { faker } from "@faker-js/faker";
import type { FieldData } from "../components/FieldEditor";

function randomFrom<T>(items: T[]): T {
  return items[Math.floor(Math.random() * items.length)];
}

export function generateMockValue(fieldType: string, fieldName: string): unknown {
  const name = fieldName.toLowerCase();

  switch (fieldType) {
    case "str":
    case "text":
      if (name.includes("email")) return faker.internet.email();
      if (name.includes("name")) return faker.person.fullName();
      if (name.includes("title")) return faker.lorem.words({ min: 2, max: 5 });
      if (name.includes("phone")) return faker.phone.number();
      if (name.includes("address")) return faker.location.streetAddress();
      return faker.lorem.words({ min: 1, max: 3 });

    case "int":
      return faker.number.int({ min: 1, max: 1000 });

    case "float":
    case "Decimal":
      return faker.number.float({ min: 1, max: 10000, multipleOf: 0.01 });

    case "bool":
      return faker.datatype.boolean();

    case "date":
      return faker.date.recent({ days: 365 }).toISOString().split("T")[0];

    case "datetime":
      return faker.date.recent({ days: 365 }).toISOString().slice(0, 16);

    case "UUID":
      return faker.string.uuid();

    case "email":
      return faker.internet.email();

    case "url":
      return faker.internet.url();

    case "dict":
    case "json":
      return { key: faker.lorem.word(), value: faker.number.int({ min: 1, max: 100 }) };

    case "list":
      return Array.from({ length: 3 }, () => faker.lorem.word());

    case "Table":
      return [];

    case "Link":
      return faker.string.uuid();

    default:
      return randomFrom([
        faker.lorem.word(),
        faker.company.name(),
        faker.commerce.productName(),
      ]);
  }
}

export function generateMockDocument(fields: FieldData[]): Record<string, unknown> {
  const nowIso = faker.date.recent({ days: 60 }).toISOString();
  const doc: Record<string, unknown> = {
    id: faker.string.uuid(),
    created_at: nowIso,
    updated_at: nowIso,
  };

  for (const field of fields) {
    if (!field.required && faker.datatype.boolean({ probability: 0.3 })) {
      doc[field.name] = null;
      continue;
    }
    doc[field.name] = generateMockValue(field.type, field.name);
  }

  return doc;
}

export function generateMockRows(
  fields: FieldData[],
  count: number
): Record<string, unknown>[] {
  return Array.from({ length: count }, () => generateMockDocument(fields));
}

export async function fetchLivePreviewRows(
  doctypeName: string
): Promise<Record<string, unknown>[]> {
  const response = await fetch(
    `/studio/api/meta/${encodeURIComponent(doctypeName)}?limit=50`,
    {
      headers: { Accept: "application/json" },
    }
  );

  if (!response.ok) {
    throw new Error(`Live data request failed: ${response.status}`);
  }

  const payload = (await response.json()) as unknown;
  if (!payload || typeof payload !== "object") {
    return [];
  }

  const typed = payload as { data?: unknown[]; items?: unknown[] };
  let rows: unknown[] = [];
  if (Array.isArray(typed.items)) {
    rows = typed.items;
  } else if (Array.isArray(typed.data)) {
    rows = typed.data;
  }

  return rows.filter((item): item is Record<string, unknown> => {
    return item !== null && typeof item === "object";
  });
}
