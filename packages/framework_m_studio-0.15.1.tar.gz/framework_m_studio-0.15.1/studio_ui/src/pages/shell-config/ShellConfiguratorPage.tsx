import { useEffect, useMemo, useState } from "react";
import { useTheme } from "../../providers/theme";

interface ActionButtonConfig {
  id: string;
  label: string;
  action: string;
  target: string;
  icon?: string | null;
  roles: string[];
}

interface SidebarAppConfig {
  id: string;
  label: string;
  icon: string;
  route: string;
  roles: string[];
}

interface SearchProviderConfig {
  id: string;
  label: string;
  handler: string;
  roles: string[];
}

interface ShellConfigPayload {
  action_buttons: ActionButtonConfig[];
  sidebar_apps: SidebarAppConfig[];
  search_providers: SearchProviderConfig[];
}

function rolesFromInput(value: string): string[] {
  return value
    .split(",")
    .map(part => part.trim())
    .filter(Boolean);
}

function rolesToInput(roles: string[]): string {
  return roles.join(", ");
}

function updateArrayItem<T>(
  list: T[],
  index: number,
  update: (item: T) => T,
): T[] {
  return list.map((item, i) => (i === index ? update(item) : item));
}

function removeArrayItem<T>(list: T[], index: number): T[] {
  return list.filter((_, i) => i !== index);
}

export function ShellConfiguratorPage() {
  const { theme } = useTheme();
  const isDark = theme === "dark";

  const [buttons, setButtons] = useState<ActionButtonConfig[]>([]);
  const [apps, setApps] = useState<SidebarAppConfig[]>([]);
  const [providers, setProviders] = useState<SearchProviderConfig[]>([]);
  const [statusMessage, setStatusMessage] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const panelClass = useMemo(
    () =>
      isDark
        ? "border-zinc-700 bg-zinc-900 text-zinc-100"
        : "border-gray-200 bg-white text-gray-900",
    [isDark],
  );

  useEffect(() => {
    const loadConfig = async () => {
      const response = await fetch("/studio/api/shell/config");
      const data = (await response.json()) as Partial<ShellConfigPayload>;
      setButtons(data.action_buttons ?? []);
      setApps(data.sidebar_apps ?? []);
      setProviders(data.search_providers ?? []);
    };

    loadConfig().catch(err => setErrorMessage(String(err)));
  }, []);

  async function saveConfig() {
    setStatusMessage(null);
    setErrorMessage(null);

    const payload: ShellConfigPayload = {
      action_buttons: buttons,
      sidebar_apps: apps,
      search_providers: providers,
    };

    const response = await fetch("/studio/api/shell/config", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });

    if (!response.ok) {
      setErrorMessage("Failed to save shell configuration.");
      return;
    }

    setStatusMessage("Shell plugin configuration saved.");
  }

  function updateButtonField(
    index: number,
    key: keyof ActionButtonConfig,
    value: string | string[] | null,
  ) {
    setButtons(prev =>
      updateArrayItem(prev, index, item => ({
        ...item,
        [key]: value,
      })),
    );
  }

  function updateSidebarField(
    index: number,
    key: keyof SidebarAppConfig,
    value: string | string[],
  ) {
    setApps(prev =>
      updateArrayItem(prev, index, item => ({
        ...item,
        [key]: value,
      })),
    );
  }

  function updateProviderField(
    index: number,
    key: keyof SearchProviderConfig,
    value: string | string[],
  ) {
    setProviders(prev =>
      updateArrayItem(prev, index, item => ({
        ...item,
        [key]: value,
      })),
    );
  }

  function removeButton(index: number) {
    setButtons(prev => removeArrayItem(prev, index));
  }

  function removeSidebarApp(index: number) {
    setApps(prev => removeArrayItem(prev, index));
  }

  function removeProvider(index: number) {
    setProviders(prev => removeArrayItem(prev, index));
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1
            className={`text-2xl font-semibold ${isDark ? "text-white" : "text-gray-900"}`}
          >
            Shell Plugin Configurator
          </h1>
          <p
            className={`text-sm ${isDark ? "text-zinc-400" : "text-gray-500"}`}
          >
            Manage global action buttons, sidebar apps, and role-aware search
            providers.
          </p>
        </div>
        <button
          onClick={saveConfig}
          className="rounded-lg bg-emerald-600 px-4 py-2 text-sm font-medium text-white hover:bg-emerald-700"
        >
          Save Shell Config
        </button>
      </div>

      {statusMessage && (
        <p className="text-sm text-emerald-500">{statusMessage}</p>
      )}
      {errorMessage && <p className="text-sm text-red-500">{errorMessage}</p>}

      <div className={`rounded-xl border p-4 ${panelClass}`}>
        <h2 className="mb-3 text-lg font-semibold">Action Buttons</h2>
        <div className="space-y-2">
          {buttons.map((button, index) => (
            <div
              key={button.id || index}
              className="grid grid-cols-1 gap-2 md:grid-cols-12"
            >
              <input
                value={button.id}
                onChange={e => updateButtonField(index, "id", e.target.value)}
                placeholder="id"
                className="md:col-span-2 rounded-lg border px-3 py-2"
              />
              <input
                value={button.label}
                onChange={e =>
                  updateButtonField(index, "label", e.target.value)
                }
                placeholder="label"
                className="md:col-span-2 rounded-lg border px-3 py-2"
              />
              <input
                value={button.action}
                onChange={e =>
                  updateButtonField(index, "action", e.target.value)
                }
                placeholder="action"
                className="md:col-span-2 rounded-lg border px-3 py-2"
              />
              <input
                value={button.target}
                onChange={e =>
                  updateButtonField(index, "target", e.target.value)
                }
                placeholder="target"
                className="md:col-span-3 rounded-lg border px-3 py-2"
              />
              <input
                value={rolesToInput(button.roles)}
                onChange={e =>
                  updateButtonField(
                    index,
                    "roles",
                    rolesFromInput(e.target.value),
                  )
                }
                placeholder="roles (comma-separated)"
                className="md:col-span-2 rounded-lg border px-3 py-2"
              />
              <button
                onClick={() => removeButton(index)}
                className="md:col-span-1 rounded-lg bg-red-600 px-3 py-2 text-sm text-white"
              >
                X
              </button>
            </div>
          ))}
          <button
            onClick={() =>
              setButtons(prev => [
                ...prev,
                {
                  id: "",
                  label: "",
                  action: "navigate",
                  target: "",
                  icon: null,
                  roles: [],
                },
              ])
            }
            className="rounded-lg bg-blue-600 px-4 py-2 text-sm font-medium text-white"
          >
            Add Action Button
          </button>
        </div>
      </div>

      <div className={`rounded-xl border p-4 ${panelClass}`}>
        <h2 className="mb-3 text-lg font-semibold">Sidebar Apps</h2>
        <div className="space-y-2">
          {apps.map((app, index) => (
            <div
              key={app.id || index}
              className="grid grid-cols-1 gap-2 md:grid-cols-12"
            >
              <input
                value={app.id}
                onChange={e => updateSidebarField(index, "id", e.target.value)}
                placeholder="id"
                className="md:col-span-2 rounded-lg border px-3 py-2"
              />
              <input
                value={app.label}
                onChange={e =>
                  updateSidebarField(index, "label", e.target.value)
                }
                placeholder="label"
                className="md:col-span-2 rounded-lg border px-3 py-2"
              />
              <input
                value={app.icon}
                onChange={e =>
                  updateSidebarField(index, "icon", e.target.value)
                }
                placeholder="icon"
                className="md:col-span-2 rounded-lg border px-3 py-2"
              />
              <input
                value={app.route}
                onChange={e =>
                  updateSidebarField(index, "route", e.target.value)
                }
                placeholder="route"
                className="md:col-span-3 rounded-lg border px-3 py-2"
              />
              <input
                value={rolesToInput(app.roles)}
                onChange={e =>
                  updateSidebarField(
                    index,
                    "roles",
                    rolesFromInput(e.target.value),
                  )
                }
                placeholder="roles"
                className="md:col-span-2 rounded-lg border px-3 py-2"
              />
              <button
                onClick={() => removeSidebarApp(index)}
                className="md:col-span-1 rounded-lg bg-red-600 px-3 py-2 text-sm text-white"
              >
                X
              </button>
            </div>
          ))}
          <button
            onClick={() =>
              setApps(prev => [
                ...prev,
                { id: "", label: "", icon: "", route: "", roles: [] },
              ])
            }
            className="rounded-lg bg-blue-600 px-4 py-2 text-sm font-medium text-white"
          >
            Add Sidebar App
          </button>
        </div>
      </div>

      <div className={`rounded-xl border p-4 ${panelClass}`}>
        <h2 className="mb-3 text-lg font-semibold">Search Providers</h2>
        <div className="space-y-2">
          {providers.map((provider, index) => (
            <div
              key={provider.id || index}
              className="grid grid-cols-1 gap-2 md:grid-cols-12"
            >
              <input
                value={provider.id}
                onChange={e => updateProviderField(index, "id", e.target.value)}
                placeholder="id"
                className="md:col-span-2 rounded-lg border px-3 py-2"
              />
              <input
                value={provider.label}
                onChange={e =>
                  updateProviderField(index, "label", e.target.value)
                }
                placeholder="label"
                className="md:col-span-3 rounded-lg border px-3 py-2"
              />
              <input
                value={provider.handler}
                onChange={e =>
                  updateProviderField(index, "handler", e.target.value)
                }
                placeholder="handler path"
                className="md:col-span-5 rounded-lg border px-3 py-2"
              />
              <input
                value={rolesToInput(provider.roles)}
                onChange={e =>
                  updateProviderField(
                    index,
                    "roles",
                    rolesFromInput(e.target.value),
                  )
                }
                placeholder="roles"
                className="md:col-span-1 rounded-lg border px-3 py-2"
              />
              <button
                onClick={() => removeProvider(index)}
                className="md:col-span-1 rounded-lg bg-red-600 px-3 py-2 text-sm text-white"
              >
                X
              </button>
            </div>
          ))}
          <button
            onClick={() =>
              setProviders(prev => [
                ...prev,
                { id: "", label: "", handler: "", roles: [] },
              ])
            }
            className="rounded-lg bg-blue-600 px-4 py-2 text-sm font-medium text-white"
          >
            Add Search Provider
          </button>
        </div>
      </div>
    </div>
  );
}
