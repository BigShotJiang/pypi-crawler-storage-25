export { ShellConfiguratorPage } from "./ShellConfiguratorPage";
