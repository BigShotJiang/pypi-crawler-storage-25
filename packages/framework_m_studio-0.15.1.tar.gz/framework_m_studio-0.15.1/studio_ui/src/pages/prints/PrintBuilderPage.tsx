import { useCallback, useEffect, useMemo, useState } from "react";
import { useTheme } from "../../providers/theme";

interface DocTypeRecord {
  name: string;
}

interface HotSwapStatus {
  watching: boolean;
  repo_path: string;
  updates_received: number;
  last_update_at?: string | null;
}

export function PrintBuilderPage() {
  const { theme } = useTheme();
  const isDark = theme === "dark";

  const [doctypes, setDoctypes] = useState<string[]>([]);
  const [selectedDoctype, setSelectedDoctype] = useState("");
  const [layouts, setLayouts] = useState<string[]>([]);
  const [selectedTemplate, setSelectedTemplate] = useState("");
  const [newTemplateName, setNewTemplateName] = useState("standard");
  const [content, setContent] = useState("<h1>{{ doc.title }}</h1>");
  const [sampleData, setSampleData] = useState('{"title":"Sample Document"}');
  const [previewHtml, setPreviewHtml] = useState("");
  const [statusMessage, setStatusMessage] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [hotSwapStatus, setHotSwapStatus] = useState<HotSwapStatus | null>(
    null,
  );

  const panelClass = useMemo(
    () =>
      isDark
        ? "border-zinc-700 bg-zinc-900 text-zinc-100"
        : "border-gray-200 bg-white text-gray-900",
    [isDark],
  );

  const loadDocTypes = useCallback(async () => {
    const response = await fetch("/studio/api/doctypes");
    const data = (await response.json()) as { doctypes?: DocTypeRecord[] };
    const names = (data.doctypes ?? []).map(dt => dt.name);
    setDoctypes(names);
    if (names.length > 0 && !selectedDoctype) {
      setSelectedDoctype(names[0]);
    }
  }, [selectedDoctype]);

  const loadLayouts = useCallback(
    async (doctype: string) => {
      if (!doctype) {
        setLayouts([]);
        return;
      }

      const response = await fetch(
        `/studio/api/print/layouts/${encodeURIComponent(doctype)}`,
      );
      const data = (await response.json()) as { layouts?: string[] };
      const names = data.layouts ?? [];
      setLayouts(names);
      if (names.length > 0 && !names.includes(selectedTemplate)) {
        setSelectedTemplate(names[0]);
      }
    },
    [selectedTemplate],
  );

  const loadTemplate = useCallback(
    async (doctype: string, templateName: string) => {
      if (!doctype || !templateName) return;

      const response = await fetch(
        `/studio/api/print/layout/${encodeURIComponent(doctype)}/${encodeURIComponent(templateName)}`,
      );
      if (!response.ok) return;

      const data = (await response.json()) as { content?: string };
      setContent(data.content ?? "");
    },
    [],
  );

  const refreshHotSwapStatus = useCallback(async () => {
    const response = await fetch("/studio/api/print/hotswap/status");
    const data = (await response.json()) as HotSwapStatus;
    setHotSwapStatus(data);
  }, []);

  useEffect(() => {
    loadDocTypes().catch(err => setErrorMessage(String(err)));
    refreshHotSwapStatus().catch(err => setErrorMessage(String(err)));
  }, [loadDocTypes, refreshHotSwapStatus]);

  useEffect(() => {
    if (!selectedDoctype) return;
    loadLayouts(selectedDoctype).catch(err => setErrorMessage(String(err)));
  }, [loadLayouts, selectedDoctype]);

  useEffect(() => {
    if (!selectedDoctype || !selectedTemplate) return;
    loadTemplate(selectedDoctype, selectedTemplate).catch(err =>
      setErrorMessage(String(err)),
    );
  }, [loadTemplate, selectedDoctype, selectedTemplate]);

  async function handleSaveTemplate() {
    setStatusMessage(null);
    setErrorMessage(null);

    const templateName = selectedTemplate || newTemplateName.trim();
    if (!selectedDoctype || !templateName) {
      setErrorMessage("Select a DocType and template name.");
      return;
    }

    const response = await fetch(
      `/studio/api/print/layout/${encodeURIComponent(selectedDoctype)}/${encodeURIComponent(templateName)}`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ content }),
      },
    );

    if (!response.ok) {
      setErrorMessage("Failed to save print template.");
      return;
    }

    setSelectedTemplate(templateName);
    await loadLayouts(selectedDoctype);
    setStatusMessage("Template saved to Print Repo.");
  }

  async function handlePreview() {
    setStatusMessage(null);
    setErrorMessage(null);

    const templateName = selectedTemplate || newTemplateName.trim();
    if (!selectedDoctype || !templateName) {
      setErrorMessage("Select a DocType and template name.");
      return;
    }

    let parsedData: Record<string, unknown> = {};
    try {
      parsedData = JSON.parse(sampleData) as Record<string, unknown>;
    } catch {
      setErrorMessage("Sample data must be valid JSON.");
      return;
    }

    const response = await fetch("/studio/api/print/preview", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        doctype: selectedDoctype,
        template_name: templateName,
        data: parsedData,
      }),
    });

    const data = (await response.json()) as {
      success?: boolean;
      html?: string;
      error?: string;
    };

    if (!data.success) {
      setErrorMessage(data.error ?? "Preview failed.");
      return;
    }

    setPreviewHtml(data.html ?? "");
    setStatusMessage("Preview rendered successfully.");
  }

  async function handleHotSwapSync() {
    setStatusMessage(null);
    setErrorMessage(null);

    const response = await fetch("/studio/api/print/hotswap/sync", {
      method: "POST",
    });

    if (!response.ok) {
      setErrorMessage("Failed to trigger hot-swap sync event.");
      return;
    }

    await refreshHotSwapStatus();
    setStatusMessage("Hot-swap sync event sent.");
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1
            className={`text-2xl font-semibold ${isDark ? "text-white" : "text-gray-900"}`}
          >
            Print Builder
          </h1>
          <p
            className={`text-sm ${isDark ? "text-zinc-400" : "text-gray-500"}`}
          >
            Manage print templates from the Print Repo and preview with sample
            data.
          </p>
        </div>
        <button
          onClick={handleHotSwapSync}
          className="rounded-lg bg-emerald-600 px-4 py-2 text-sm font-medium text-white hover:bg-emerald-700"
        >
          Trigger Hot-Swap Sync
        </button>
      </div>

      {hotSwapStatus && (
        <div className={`rounded-lg border p-3 ${panelClass}`}>
          <p className="text-sm">
            Hot-swap monitor: {hotSwapStatus.watching ? "watching" : "stopped"}
          </p>
          <p className="text-xs opacity-80">Repo: {hotSwapStatus.repo_path}</p>
          <p className="text-xs opacity-80">
            Updates received: {hotSwapStatus.updates_received}
            {hotSwapStatus.last_update_at
              ? ` (last: ${hotSwapStatus.last_update_at})`
              : ""}
          </p>
        </div>
      )}

      {statusMessage && (
        <p className="text-sm text-emerald-500">{statusMessage}</p>
      )}
      {errorMessage && <p className="text-sm text-red-500">{errorMessage}</p>}

      <div className="grid grid-cols-1 gap-6 xl:grid-cols-2">
        <div className={`rounded-xl border p-4 ${panelClass}`}>
          <h2 className="mb-3 text-lg font-semibold">Template Editor</h2>

          <div className="mb-3 grid grid-cols-1 gap-3 md:grid-cols-3">
            <select
              value={selectedDoctype}
              onChange={e => setSelectedDoctype(e.target.value)}
              className={`rounded-lg border px-3 py-2 ${
                isDark
                  ? "border-zinc-700 bg-zinc-800 text-white"
                  : "border-gray-300 bg-white text-gray-900"
              }`}
            >
              <option value="">Select DocType</option>
              {doctypes.map(name => (
                <option key={name} value={name}>
                  {name}
                </option>
              ))}
            </select>

            <select
              value={selectedTemplate}
              onChange={e => setSelectedTemplate(e.target.value)}
              className={`rounded-lg border px-3 py-2 ${
                isDark
                  ? "border-zinc-700 bg-zinc-800 text-white"
                  : "border-gray-300 bg-white text-gray-900"
              }`}
            >
              <option value="">Select Existing Template</option>
              {layouts.map(name => (
                <option key={name} value={name}>
                  {name}
                </option>
              ))}
            </select>

            <input
              value={newTemplateName}
              onChange={e => setNewTemplateName(e.target.value)}
              placeholder="new template name"
              className={`rounded-lg border px-3 py-2 ${
                isDark
                  ? "border-zinc-700 bg-zinc-800 text-white"
                  : "border-gray-300 bg-white text-gray-900"
              }`}
            />
          </div>

          <textarea
            value={content}
            onChange={e => setContent(e.target.value)}
            rows={14}
            className={`w-full rounded-lg border px-3 py-2 font-mono text-sm ${
              isDark
                ? "border-zinc-700 bg-zinc-800 text-white"
                : "border-gray-300 bg-white text-gray-900"
            }`}
          />

          <div className="mt-3 flex gap-2">
            <button
              onClick={handleSaveTemplate}
              className="rounded-lg bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700"
            >
              Save Template
            </button>
            <button
              onClick={handlePreview}
              className="rounded-lg bg-cyan-600 px-4 py-2 text-sm font-medium text-white hover:bg-cyan-700"
            >
              Preview
            </button>
          </div>
        </div>

        <div className={`rounded-xl border p-4 ${panelClass}`}>
          <h2 className="mb-3 text-lg font-semibold">Preview</h2>
          <p
            className={`mb-2 text-xs ${isDark ? "text-zinc-400" : "text-gray-500"}`}
          >
            Sample data JSON
          </p>
          <textarea
            value={sampleData}
            onChange={e => setSampleData(e.target.value)}
            rows={6}
            className={`mb-3 w-full rounded-lg border px-3 py-2 font-mono text-sm ${
              isDark
                ? "border-zinc-700 bg-zinc-800 text-white"
                : "border-gray-300 bg-white text-gray-900"
            }`}
          />
          <div
            className={`min-h-80 rounded-lg border p-3 ${
              isDark
                ? "border-zinc-700 bg-zinc-800"
                : "border-gray-200 bg-gray-50"
            }`}
          >
            {previewHtml ? (
              <div dangerouslySetInnerHTML={{ __html: previewHtml }} />
            ) : (
              <p className={isDark ? "text-zinc-400" : "text-gray-500"}>
                Preview output will appear here.
              </p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
