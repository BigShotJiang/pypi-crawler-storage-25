/**
 * DocType Editor Page
 *
 * Visual editor for DocType schema with:
 * - Top bar: Name input + Save button
 * - Left panel: Draggable field list
 * - Right panel: Selected field properties
 */

import {
  useOne,
  useUpdate,
  useCreate,
  useGo,
  useInvalidate,
} from "@refinedev/core";
import { useParams } from "react-router";
import { useState, useCallback, useEffect } from "react";
import {
  FieldData,
  FieldTypeInfo,
} from "../../components/FieldEditor";
import { CodePreview } from "../../components/CodePreview";
import { useTheme } from "../../providers/theme";
import { DesignerCanvas } from "../../designer/DesignerCanvas";
import { MetaEditor } from "../../components/MetaEditor";
import { PropertiesPanel } from "../../components/PropertiesPanel";
import { MigrationTab } from "../../components/MigrationTab";
import { PrintTab } from "../../components/PrintTab";
import { AggregateTab } from "../../components/AggregateTab";

// Types - use FieldData from FieldEditor and extend with stable ID
export type FieldDef = FieldData & { _id: string };

export type SelectedNode =
  | { type: "field"; index: number }
  | { type: "section"; tabIndex?: number; sectionIndex: number }
  | { type: "tab"; tabIndex: number };

export interface RoleDef {
  name: string;
  description?: string;
}

export interface FormSection {
  label?: string;
  fields?: string[];
  columns?: 1 | 2 | 3;
  collapsible?: boolean;
  collapsed_by_default?: boolean;
}

export interface FormTab {
  label?: string;
  sections?: FormSection[];
}

export interface DocTypeMeta {
  is_submittable?: boolean;
  permissions?: Record<string, string[]>;
  [key: string]: unknown;
  ui_meta?: {
    form?: {
      layout?: "sections" | "tabs";
      sections?: FormSection[];
      tabs?: FormTab[];
    };
  };
}

export interface DocTypeSchema {
  name: string;
  module?: string;
  docstring?: string;
  fields: FieldDef[];
  meta?: DocTypeMeta;
}

interface GuardrailCheckResponse {
  has_dangerous: boolean;
  can_publish: boolean;
  changes: Array<{
    field: string;
    type: string;
    desc: string;
  }>;
}

interface PublishResponse {
  success: boolean;
  blocked: boolean;
  adapter_type: string;
  branch?: string | null;
  commit_sha?: string | null;
  change_request_url?: string | null;
  error?: string | null;
  guardrail?: GuardrailCheckResponse | null;
}

// Main Editor Component
export function DocTypeEdit() {
  const { id } = useParams<{ id: string }>();
  const go = useGo();
  const invalidate = useInvalidate();
  const isCreate = !id;

  // Fetch existing DocType
  const { query } = useOne<DocTypeSchema>({
    resource: "doctypes",
    id: id || "",
    queryOptions: { enabled: !isCreate },
  });

  const updateMutation = useUpdate();
  const createMutation = useCreate();

  // Local state
  const [doctype, setDoctype] = useState<DocTypeSchema>(() => ({
    name: "",
    docstring: "",
    fields: [],
  }));
  const [selectedNode, setSelectedNode] = useState<SelectedNode | null>(
    null,
  );
  const [activeTab, setActiveTab] = useState<"designer" | "meta" | "aggregate" | "code" | "sync" | "print">("designer");
  const [isSaving, setIsSaving] = useState(false);
  const [fieldTypes, setFieldTypes] = useState<FieldTypeInfo[]>([]);
  const [availableDocTypes, setAvailableDocTypes] = useState<string[]>([]);
  const [availableRoles, setAvailableRoles] = useState<RoleDef[]>([]);
  const [isPublishModalOpen, setIsPublishModalOpen] = useState(false);
  const [publishMessage, setPublishMessage] = useState("");
  const [publishAuthor, setPublishAuthor] = useState("studio-user");
  const [publishAcknowledged, setPublishAcknowledged] = useState(false);
  const [guardrailCheck, setGuardrailCheck] =
    useState<GuardrailCheckResponse | null>(null);
  const [publishResult, setPublishResult] = useState<PublishResponse | null>(
    null,
  );
  const [publishError, setPublishError] = useState<string | null>(null);
  const [isPublishing, setIsPublishing] = useState(false);
  const [isLoadingGuardrail, setIsLoadingGuardrail] = useState(false);
  const { theme } = useTheme();
  const isDark = theme === "dark";

  const buildSchemaPayload = useCallback(() => {
    return {
      name: doctype.name,
      docstring: doctype.docstring,
      // eslint-disable-next-line @typescript-eslint/no-unused-vars
      fields: doctype.fields.map(({ _id, ...field }) => field),
      meta: doctype.meta || {},
    };
  }, [doctype]);

  // Fetch field types and available DocTypes on mount
  useEffect(() => {
    // Fetch field types
    fetch("/studio/api/field-types")
      .then(res => res.json())
      .then(data => {
        if (data.field_types) {
          setFieldTypes(data.field_types);
        }
      })
      .catch(err => console.error("Failed to fetch field types:", err));

    // Fetch available DocTypes for Link field dropdown
    fetch("/studio/api/doctypes")
      .then(res => res.json())
      .then(data => {
        if (data.doctypes) {
          setAvailableDocTypes(
            data.doctypes.map((dt: { name: string }) => dt.name),
          );
        }
      })
      .catch(err => console.error("Failed to fetch doctypes:", err));

    // Fetch design-time roles
    fetch("/studio/api/roles")
      .then(res => res.json())
      .then(data => {
        if (data.roles) {
          setAvailableRoles(data.roles);
        }
      })
      .catch(err => console.error("Failed to fetch roles:", err));
  }, []);

  // Reset state when ID changes (navigation between different doctypes)
  useEffect(() => {
    setDoctype({
      name: "",
      docstring: "",
      fields: [],
    });
    setSelectedNode(null);
  }, [id]);

  // Initialize from fetched data when it arrives.
  // The useOne hook returns { query } where query.data.data has the fetched record.
  const fetchedDocType = query.data?.data;

  useEffect(() => {
    if (!isCreate && fetchedDocType?.name) {
      console.log("Initializing doctype from API data:", fetchedDocType);
      console.log("Raw API fields:", fetchedDocType.fields);
      // Map API fields to our format (ensure required is boolean and add stable _id)
      const mappedFields = (fetchedDocType.fields || []).map(
        (f: FieldDef, index: number) => {
          console.log("Mapping field:", f.name, "validators:", f.validators);
          return {
            ...f,
            required: f.required ?? true,
            _id: f._id || `field_${Date.now()}_${index}`, // Generate stable ID if not present
          };
        },
      );
      console.log("Mapped fields:", mappedFields);
      setDoctype({
        name: fetchedDocType.name || "",
        docstring: fetchedDocType.docstring || "",
        fields: mappedFields,
        meta: fetchedDocType.meta || {},
      });
    }
  }, [fetchedDocType, isCreate]);

  const handleAddField = useCallback(() => {
    let newIndex = 0;
    setDoctype(prev => {
      const newName = `field_${prev.fields.length + 1}`;
      const newField: FieldDef = {
        name: newName,
        type: "str",
        required: true,
        _id: `field_${Date.now()}_${prev.fields.length}`,
      };
      newIndex = prev.fields.length; // Store the index before adding
      return {
        ...prev,
        fields: [...prev.fields, newField],
      };
    });
    setSelectedNode({ type: "field", index: newIndex });
  }, []);

  const handleDeleteField = useCallback((index: number) => {
    setDoctype(prev => {
      const fieldToDelete = prev.fields[index];
      const newFields = prev.fields.filter((_, i) => i !== index);

      let newMeta = prev.meta;
      if (fieldToDelete && prev.meta?.ui_meta?.form) {
        const form = JSON.parse(JSON.stringify(prev.meta.ui_meta.form));

        const clearReferences = (sections: FormSection[]) => {
          sections.forEach((sec: FormSection) => {
            if (sec.fields) {
              sec.fields = sec.fields.filter((f: string) => f !== fieldToDelete.name);
            }
          });
        };

        if (form.layout === "tabs" && form.tabs) {
          form.tabs.forEach((tab: FormTab) => clearReferences(tab.sections || []));
        } else if (form.sections) {
          clearReferences(form.sections);
        }

        newMeta = { ...prev.meta, ui_meta: { ...prev.meta.ui_meta, form } };
      }

      return { ...prev, fields: newFields, meta: newMeta };
    });
    setSelectedNode(null);
  }, []);

  const handleFieldChange = useCallback(
    (updatedField: FieldData) => {
      if (selectedNode?.type !== "field" || selectedNode.index === null || selectedNode.index < 0) return;
      const selectedFieldIndex = selectedNode.index;

      setDoctype(prev => {
        const oldField = prev.fields[selectedFieldIndex];
        const newFields = [...prev.fields];
        newFields[selectedFieldIndex] = { ...updatedField, _id: oldField._id };

        let newMeta = prev.meta;

        // SYNCHRONIZATION: If the field name changed, we MUST update the ui_meta layout arrays
        if (oldField.name !== updatedField.name && prev.meta?.ui_meta?.form) {
          const form = JSON.parse(JSON.stringify(prev.meta.ui_meta.form));

          const updateReferences = (sections: FormSection[]) => {
            sections.forEach((sec: FormSection) => {
              if (sec.fields) {
                const idx = sec.fields.indexOf(oldField.name);
                if (idx !== -1) {
                  sec.fields[idx] = updatedField.name; // Update the reference!
                }
              }
            });
          };

          if (form.layout === "tabs" && form.tabs) {
            form.tabs.forEach((tab: FormTab) => updateReferences(tab.sections || []));
          } else if (form.sections) {
            updateReferences(form.sections);
          }

          const prevUiMeta = prev.meta.ui_meta;
          newMeta = { ...prev.meta, ui_meta: { ...prevUiMeta, form } };
        }

        return { ...prev, fields: newFields, meta: newMeta };
      });
    },
    [selectedNode],
  );

  const handleSave = useCallback(() => {
    if (!doctype.name.trim()) {
      alert("DocType name is required");
      return;
    }

    setIsSaving(true);
    // Strip out _id field before sending to backend (it's only for frontend tracking)
    const payload = buildSchemaPayload();

    // Debug: log what's being sent
    console.log("Save payload:", JSON.stringify(payload, null, 2));

    const options = {
      onSuccess: () => {
        setIsSaving(false);
        // Invalidate cache to ensure fresh data on next load
        invalidate({
          resource: "doctypes",
          invalidates: ["list", "detail"],
        });
        go({ to: "/doctypes" });
      },
      onError: () => {
        setIsSaving(false);
        alert("Failed to save DocType");
      },
    };

    if (isCreate) {
      createMutation.mutate(
        { resource: "doctypes", values: payload, invalidates: [] },
        options,
      );
    } else {
      // Manually invalidate after update to ensure fresh data
      updateMutation.mutate(
        { resource: "doctypes", id: id!, values: payload, invalidates: [] },
        options,
      );
    }
  }, [
    buildSchemaPayload,
    doctype.name,
    isCreate,
    id,
    createMutation,
    updateMutation,
    go,
    invalidate,
  ]);

  const openPublishModal = useCallback(async () => {
    if (!doctype.name.trim()) {
      alert("Save the DocType with a valid name before publishing.");
      return;
    }

    setPublishResult(null);
    setPublishError(null);
    setPublishAcknowledged(false);
    setIsPublishModalOpen(true);
    setIsLoadingGuardrail(true);

    try {
      const response = await fetch("/studio/api/guardrail/check", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(buildSchemaPayload()),
      });

      const data = (await response.json()) as GuardrailCheckResponse;
      setGuardrailCheck(data);
    } catch (error) {
      setPublishError(
        error instanceof Error ? error.message : "Guardrail check failed",
      );
      setGuardrailCheck(null);
    } finally {
      setIsLoadingGuardrail(false);
    }
  }, [buildSchemaPayload, doctype.name]);

  const handlePublish = useCallback(async () => {
    if (!publishMessage.trim()) {
      setPublishError("Reason for change is required.");
      return;
    }

    setIsPublishing(true);
    setPublishError(null);
    setPublishResult(null);

    try {
      const response = await fetch("/studio/api/publish", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message: publishMessage,
          author: publishAuthor,
          acknowledged: publishAcknowledged,
          doctype_payload: buildSchemaPayload(),
        }),
      });

      const data = (await response.json()) as PublishResponse;
      setPublishResult(data);
      if (!data.success) {
        setPublishError(data.error ?? "Publish failed");
      }
      if (data.guardrail) {
        setGuardrailCheck(data.guardrail);
      }
    } catch (error) {
      setPublishError(
        error instanceof Error ? error.message : "Publish failed",
      );
    } finally {
      setIsPublishing(false);
    }
  }, [buildSchemaPayload, publishAcknowledged, publishAuthor, publishMessage]);

  const isLoading = !isCreate && query?.isLoading;

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-400" />
      </div>
    );
  }

  return (
    <div className="doctype-edit-container h-full flex flex-col">
      {/* Top Bar */}
      <div
        className={`flex items-center justify-between p-3 border-b ${
          isDark ? "border-zinc-700 bg-zinc-800/50" : "border-gray-200 bg-white"
        }`}
      >
        <div className="flex items-center gap-3 flex-1">
          <button
            onClick={() => go({ to: "/doctypes" })}
            className={`transition-colors ${
              isDark
                ? "text-zinc-400 hover:text-white"
                : "text-gray-400 hover:text-gray-600"
            }`}
          >
            <svg
              className="w-6 h-6"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M15 19l-7-7 7-7"
              />
            </svg>
          </button>
          <input
            type="text"
            value={doctype.name}
            onChange={e =>
              setDoctype(prev => ({ ...prev, name: e.target.value }))
            }
            placeholder="DocType Name"
            className={`text-xl font-bold bg-transparent border-none focus:outline-none focus:ring-2 focus:ring-blue-500 rounded px-2 py-1 ${
              isDark
                ? "text-white placeholder-zinc-500"
                : "text-gray-900 placeholder-gray-400"
            }`}
          />
        </div>

        {/* Center Tabs */}
        <div className="flex justify-center flex-1">
          <div className={`flex p-1 rounded-lg ${isDark ? "bg-zinc-900" : "bg-gray-100"}`}>
            {(['designer', 'meta', 'aggregate', 'code', 'sync', 'print'] as const).map(tab => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`px-2.5 py-1 text-xs font-medium rounded-md capitalize whitespace-nowrap transition-colors ${
                  activeTab === tab
                    ? (isDark ? "bg-zinc-700 text-white shadow-sm" : "bg-white text-gray-900 shadow-sm")
                    : (isDark ? "text-zinc-400 hover:text-zinc-200" : "text-gray-500 hover:text-gray-700")
                }`}
              >
                {tab === 'meta' ? 'Meta & Permissions' : tab === 'aggregate' ? 'Aggregate Builder' : tab === 'sync' ? 'Live Sync' : tab === 'print' ? 'Print Formats' : tab}
              </button>
            ))}
          </div>
        </div>

        {/* Right Actions */}
        <div className="flex items-center justify-end gap-3 flex-1">
          <button
            onClick={openPublishModal}
            disabled={isCreate || !doctype.name || isSaving}
            className="px-3 py-1.5 text-sm bg-emerald-600 hover:bg-emerald-700 disabled:bg-zinc-600 disabled:cursor-not-allowed text-white rounded-lg font-medium transition-colors shadow-sm flex items-center gap-2"
          >
            Publish
          </button>
          <button
            onClick={handleSave}
            disabled={isSaving || !doctype.name}
            className="px-3 py-1.5 text-sm bg-blue-600 hover:bg-blue-700 disabled:bg-zinc-600 disabled:cursor-not-allowed text-white rounded-lg font-medium transition-colors shadow-sm flex items-center gap-2"
          >
            {isSaving ? (
              <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white" />
            ) : (
              <svg
                className="w-4 h-4"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M5 13l4 4L19 7"
                />
              </svg>
            )}
            Save
          </button>
        </div>
      </div>

      {isPublishModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4">
          <div
            className={`w-full max-w-2xl rounded-xl border shadow-xl ${
              isDark
                ? "border-zinc-700 bg-zinc-900 text-zinc-100"
                : "border-gray-200 bg-white text-gray-900"
            }`}
          >
            <div
              className={`flex items-center justify-between border-b p-4 ${
                isDark ? "border-zinc-700" : "border-gray-200"
              }`}
            >
              <h3 className="text-lg font-semibold">Publish Changes</h3>
              <button
                onClick={() => setIsPublishModalOpen(false)}
                className={isDark ? "text-zinc-400" : "text-gray-500"}
              >
                Close
              </button>
            </div>

            <div className="space-y-4 p-4">
              <label className="block space-y-1">
                <span className="text-sm font-medium">Reason for change</span>
                <input
                  type="text"
                  value={publishMessage}
                  onChange={e => setPublishMessage(e.target.value)}
                  placeholder="Fix invoice tax rule"
                  className={`w-full rounded-lg border px-3 py-1.5 text-sm ${
                    isDark
                      ? "border-zinc-700 bg-zinc-800 text-white"
                      : "border-gray-300 bg-white text-gray-900"
                  }`}
                />
              </label>

              <label className="block space-y-1">
                <span className="text-sm font-medium">Author</span>
                <input
                  type="text"
                  value={publishAuthor}
                  onChange={e => setPublishAuthor(e.target.value)}
                  placeholder="studio-user"
                  className={`w-full rounded-lg border px-3 py-1.5 text-sm ${
                    isDark
                      ? "border-zinc-700 bg-zinc-800 text-white"
                      : "border-gray-300 bg-white text-gray-900"
                  }`}
                />
              </label>

              <div
                className={`rounded-lg border p-3 text-sm ${
                  isDark
                    ? "border-zinc-700 bg-zinc-800"
                    : "border-gray-200 bg-gray-50"
                }`}
              >
                {isLoadingGuardrail ? (
                  <p>Running guardrail analysis...</p>
                ) : guardrailCheck ? (
                  <>
                    <p className="font-medium">
                      Guardrail status:{" "}
                      {guardrailCheck.has_dangerous
                        ? "DANGEROUS"
                        : "Safe/Warning"}
                    </p>
                    {guardrailCheck.changes.length > 0 && (
                      <ul className="mt-2 space-y-1">
                        {guardrailCheck.changes.map((change, idx) => (
                          <li key={`${change.field}-${idx}`}>
                            [{change.type}] {change.field}: {change.desc}
                          </li>
                        ))}
                      </ul>
                    )}
                  </>
                ) : (
                  <p>Guardrail analysis unavailable.</p>
                )}
              </div>

              {guardrailCheck?.has_dangerous && (
                <label className="flex items-center gap-2 text-sm">
                  <input
                    type="checkbox"
                    checked={publishAcknowledged}
                    onChange={e => setPublishAcknowledged(e.target.checked)}
                  />
                  I acknowledge dangerous schema changes and still want to
                  publish.
                </label>
              )}

              {publishError && (
                <p className="text-sm text-red-500">{publishError}</p>
              )}

              {publishResult?.success && (
                <div
                  className={`rounded-lg border p-3 text-sm ${
                    isDark
                      ? "border-emerald-800 bg-emerald-900/30"
                      : "border-emerald-200 bg-emerald-50"
                  }`}
                >
                  <p className="font-medium">Publish succeeded.</p>
                  {publishResult.branch && (
                    <p>Branch: {publishResult.branch}</p>
                  )}
                  {publishResult.commit_sha && (
                    <p>Commit: {publishResult.commit_sha}</p>
                  )}
                  {publishResult.change_request_url && (
                    <p>
                      Change Request:{" "}
                      <a
                        className="underline"
                        href={publishResult.change_request_url}
                        target="_blank"
                        rel="noreferrer"
                      >
                        Open link
                      </a>
                    </p>
                  )}
                </div>
              )}
            </div>

            <div
              className={`flex items-center justify-end gap-2 border-t p-4 ${
                isDark ? "border-zinc-700" : "border-gray-200"
              }`}
            >
              <button
                onClick={() => setIsPublishModalOpen(false)}
                className={`rounded-lg px-3 py-1.5 text-sm ${
                  isDark ? "bg-zinc-800" : "bg-gray-100"
                }`}
              >
                Cancel
              </button>
              <button
                onClick={handlePublish}
                disabled={isPublishing || isLoadingGuardrail}
                className="rounded-lg bg-emerald-600 px-3 py-1.5 text-sm text-white disabled:bg-zinc-600"
              >
                {isPublishing ? "Publishing..." : "Publish"}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Main Content */}
      <div className={`flex-1 flex overflow-hidden ${isDark ? "bg-zinc-950" : "bg-zinc-50/50"}`}>
        {activeTab === 'designer' && (
          <>
            {/* Center: Canvas */}
            <div className="flex-1 flex overflow-hidden">
              <DesignerCanvas
                doctype={doctype}
                setDoctype={setDoctype}
                selectedNode={selectedNode}
                onSelectNode={setSelectedNode}
                onDeleteField={handleDeleteField}
                fieldTypes={fieldTypes}
                isDark={isDark}
              />
            </div>

            {/* Right Sidebar: Properties */}
            <PropertiesPanel
              doctype={doctype}
              setDoctype={setDoctype}
              selectedNode={selectedNode}
              onSelectNode={setSelectedNode}
              fieldTypes={fieldTypes}
              availableDocTypes={availableDocTypes}
              handleFieldChange={handleFieldChange}
              handleAddField={handleAddField}
              isDark={isDark}
            />
          </>
        )}

        {activeTab === 'meta' && (
          <div className={`flex-1 overflow-y-auto ${isDark ? "bg-zinc-900/50" : "bg-white"}`}>
            <div className="max-w-4xl mx-auto h-full">
              <MetaEditor doctype={doctype} setDoctype={setDoctype} availableRoles={availableRoles} isDark={isDark} />
            </div>
          </div>
        )}

        {activeTab === 'aggregate' && (
          <div className={`flex-1 overflow-y-auto ${isDark ? "bg-zinc-900/50" : "bg-white"}`}>
            <div className="max-w-4xl mx-auto h-full">
              <AggregateTab doctype={doctype} setDoctype={setDoctype} isDark={isDark} />
            </div>
          </div>
        )}

        {activeTab === 'code' && (
          <div className={`flex-1 flex flex-col ${isDark ? "bg-zinc-900/50" : "bg-white"}`}>
            <CodePreview schema={doctype} className="h-full" />
          </div>
        )}

        {activeTab === 'sync' && (
          <div className={`flex-1 flex flex-col ${isDark ? "bg-zinc-900/50" : "bg-white"}`}>
            <MigrationTab isDark={isDark} getSchemaPayload={buildSchemaPayload} />
          </div>
        )}

        {activeTab === 'print' && (
          <div className={`flex-1 flex flex-col ${isDark ? "bg-zinc-900/50" : "bg-white"}`}>
            <PrintTab doctypeName={doctype.name} isDark={isDark} />
          </div>
        )}
      </div>
    </div>
  );
}

export default DocTypeEdit;
