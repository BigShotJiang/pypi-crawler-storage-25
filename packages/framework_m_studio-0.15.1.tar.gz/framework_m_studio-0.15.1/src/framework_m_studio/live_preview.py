"""Live Preview Manager — Render DocTypes with real data + file watching.

Provides the backend for Studio's live preview feature:
1. Render DocType forms with sample/real data from the connected pod
2. Watch workspace files for changes and notify the frontend for hot-reload
"""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Protocol


@dataclass
class PreviewResult:
    """Result of a DocType preview render."""

    doctype: str
    """DocType name."""

    html: str
    """Rendered HTML content."""

    data: dict[str, Any]
    """Data used for rendering."""

    success: bool
    """Whether the render succeeded."""

    error: str | None = None
    """Error message if render failed."""


@dataclass
class FileChangeEvent:
    """Represents a file change in the watched workspace."""

    path: Path
    """Path to the changed file."""

    event_type: str
    """Type of change: 'created', 'modified', 'deleted'."""

    @property
    def is_doctype_change(self) -> bool:
        """Check if the change is in a DocType file."""
        return self.path.name == "doctype.py" or self.path.name.endswith("_doctype.py")


class RendererProtocol(Protocol):
    """Protocol for rendering DocType previews."""

    async def render(self, doctype: str, data: dict[str, Any]) -> str:
        """Render a DocType preview.

        Args:
            doctype: DocType name.
            data: Data to render.

        Returns:
            Rendered HTML string.
        """
        ...


class LivePreviewProtocol(Protocol):
    """Protocol for the Live Preview feature."""

    async def render_preview(self, doctype: str, data: dict[str, Any]) -> PreviewResult:
        """Render a DocType with sample/real data."""
        ...

    def start_watching(self, path: Path) -> None:
        """Start watching a workspace path for file changes."""
        ...

    def stop_watching(self, path: Path) -> None:
        """Stop watching a workspace path."""
        ...


class LivePreviewManager:
    """Manages live preview rendering and file watching.

    Uses a RendererProtocol to render DocType previews and
    maintains a list of watched paths for hot-reload notifications.
    """

    def __init__(self, renderer: RendererProtocol) -> None:
        """Initialize LivePreviewManager.

        Args:
            renderer: Renderer for DocType previews.
        """
        self._renderer = renderer
        self.watched_paths: set[Path] = set()
        self._callbacks: list[Callable[[FileChangeEvent], None]] = []

    async def render_preview(self, doctype: str, data: dict[str, Any]) -> PreviewResult:
        """Render a DocType with data.

        Args:
            doctype: DocType name.
            data: Data to render with.

        Returns:
            PreviewResult with HTML or error.
        """
        try:
            html = await self._renderer.render(doctype, data)
            return PreviewResult(
                doctype=doctype,
                html=html,
                data=data,
                success=True,
            )
        except Exception as exc:
            return PreviewResult(
                doctype=doctype,
                html="",
                data=data,
                success=False,
                error=str(exc),
            )

    def start_watching(self, path: Path) -> None:
        """Register a path for file change monitoring.

        Args:
            path: Workspace path to watch.
        """
        self.watched_paths.add(path)

    def stop_watching(self, path: Path) -> None:
        """Unregister a path from file change monitoring.

        Args:
            path: Path to stop watching.
        """
        self.watched_paths.discard(path)

    def on_change(self, callback: Callable[[FileChangeEvent], None]) -> None:
        """Register a callback for file change events.

        Args:
            callback: Function called when a watched file changes.
        """
        self._callbacks.append(callback)

    def notify_change(self, event: FileChangeEvent) -> None:
        """Notify all registered callbacks of a file change.

        Args:
            event: The file change event.
        """
        for callback in self._callbacks:
            callback(event)
