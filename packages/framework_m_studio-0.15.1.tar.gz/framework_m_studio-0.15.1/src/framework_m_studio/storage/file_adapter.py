"""File Adapter — Direct filesystem persistence.

Writes DocType files directly to the local workspace.
Used in indie/local mode where Studio runs alongside the app.
"""

from __future__ import annotations

from pathlib import Path

from framework_m_studio.storage.protocol import PublishResult


class FileAdapter:
    """Persist changes by writing directly to the filesystem.

    Suitable for:
    - Local development (``m dev`` hot-reload)
    - Single-developer indie deployments
    """

    def __init__(self, workspace_root: Path) -> None:
        """Initialize FileAdapter.

        Args:
            workspace_root: Root directory of the workspace.
        """
        self._root = workspace_root

    async def save(self, path: str, content: str) -> None:
        """Write content to a file in the workspace.

        Creates parent directories if they don't exist.

        Args:
            path: Relative path within the workspace.
            content: File content to write.
        """
        target = self._root / path
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(content)

    async def publish(
        self,
        message: str,
        author: str,
    ) -> PublishResult:
        """Publish is a no-op for FileAdapter (files are already on disk).

        Returns a success indicator so callers get a uniform API.

        Args:
            message: Commit message (logged but not persisted).
            author: Author identifier (logged but not persisted).

        Returns:
            PublishResult with success=True and adapter_type='file'.
        """
        return PublishResult(
            success=True,
            adapter_type="file",
        )
