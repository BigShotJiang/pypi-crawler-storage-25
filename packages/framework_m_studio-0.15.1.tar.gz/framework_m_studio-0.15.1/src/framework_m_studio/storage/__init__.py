"""Storage package — adapters for persisting Studio changes."""
