"""Storage Adapter Protocol.

Defines the interface for persisting Studio changes.
Implementations include FileAdapter (local) and GitApiAdapter (SaaS).
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Protocol


@dataclass
class PublishResult:
    """Result of a publish operation."""

    success: bool
    """Whether the publish succeeded."""

    adapter_type: str
    """Which adapter was used ('file' or 'git_api')."""

    commit_sha: str | None = None
    """Commit SHA if applicable."""

    branch: str | None = None
    """Branch name if a feature branch was created."""

    pr_url: str | None = None
    """URL to the merge request / pull request."""

    error: str | None = None
    """Error message if publish failed."""


class StorageAdapterProtocol(Protocol):
    """Port for persisting Studio changes.

    Implementations can write directly to disk (indie mode)
    or commit via Git API (SaaS/enterprise mode).
    """

    async def save(self, path: str, content: str) -> None:
        """Save content to the specified path.

        Args:
            path: Relative path within the workspace.
            content: File content to write.
        """
        ...

    async def publish(
        self,
        message: str,
        author: str,
    ) -> PublishResult:
        """Publish all pending changes.

        Args:
            message: Commit message / reason for change.
            author: Author identifier (email or username).

        Returns:
            PublishResult with status and metadata.
        """
        ...
