"""Git API Adapter — Commit via Git for SaaS/Enterprise mode.

Writes files to a local workspace, then commits and pushes via
the GitAdapterProtocol. Creates feature branches automatically
and returns a link to the change request.
"""

from __future__ import annotations

import re
from pathlib import Path
from typing import TYPE_CHECKING

from framework_m_studio.storage.protocol import PublishResult

if TYPE_CHECKING:
    from framework_m_studio.git.protocol import GitAdapterProtocol


class GitApiAdapter:
    """Persist changes by committing to a Git repository.

    Workflow:
    1. save() writes files to the local workspace (for hot-reload)
    2. publish() creates a feature branch, commits, and pushes
    """

    def __init__(
        self,
        git_adapter: GitAdapterProtocol,
        workspace_path: Path,
        repo_url: str,
        auth_token: str | None = None,
    ) -> None:
        """Initialize GitApiAdapter.

        Args:
            git_adapter: Git adapter for operations.
            workspace_path: Local workspace directory.
            repo_url: Remote repository URL.
            auth_token: Auth token for push operations.
        """
        self._git = git_adapter
        self._workspace = workspace_path
        self._repo_url = repo_url
        self._auth_token = auth_token

    async def save(self, path: str, content: str) -> None:
        """Write content to the local workspace.

        Files are written immediately for hot-reload / live preview.
        They are not committed until publish() is called.

        Args:
            path: Relative path within the workspace.
            content: File content to write.
        """
        target = self._workspace / path
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(content)

    async def publish(
        self,
        message: str,
        author: str,
    ) -> PublishResult:
        """Create a feature branch, commit all changes, and push.

        Branch naming convention: ``feature/[author]-[message-slug]``

        Args:
            message: Commit message / reason for change.
            author: Author identifier.

        Returns:
            PublishResult with branch, commit SHA, and adapter type.
        """
        slug = self._slugify(message)
        branch_name = f"feature/{author}-{slug}"

        try:
            await self._git.create_branch(self._workspace, branch_name, checkout=True)

            result = await self._git.commit(self._workspace, message, author=author)

            await self._git.push(self._workspace, branch_name)

            return PublishResult(
                success=True,
                adapter_type="git_api",
                commit_sha=result.sha,
                branch=branch_name,
            )
        except Exception as exc:
            return PublishResult(
                success=False,
                adapter_type="git_api",
                error=str(exc),
            )

    @staticmethod
    def _slugify(text: str) -> str:
        """Convert a commit message to a branch-safe slug.

        Strips common prefixes (feat:, fix:, etc.), lowercases,
        replaces spaces with hyphens, and removes non-alphanumeric chars.
        """
        # Remove conventional commit prefix
        cleaned = re.sub(r"^(feat|fix|chore|docs|refactor|test):\s*", "", text)
        # Lowercase and slug
        slug = re.sub(r"[^a-z0-9]+", "-", cleaned.lower()).strip("-")
        # Truncate to reasonable length
        return slug[:50]
