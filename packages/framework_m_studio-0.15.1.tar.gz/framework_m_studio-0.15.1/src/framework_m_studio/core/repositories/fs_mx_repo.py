"""File System Metadata eXchange (MX) Repository.

Adapter for reading and writing DocType definitions as Python code
directly to the local file system.
"""

import re
from collections.abc import Sequence
from datetime import datetime
from pathlib import Path
from typing import Any

from framework_m_core.interfaces.repository import (
    FilterSpec,
    OrderSpec,
    PaginatedResult,
)


class FSCodeRepository:
    """File-system based repository for DocType definitions."""

    @staticmethod
    def _to_pascal_case(name: str) -> str:
        """Convert a string to PascalCase."""
        normalized = name.replace(" ", "_").replace("-", "_")
        if "_" in normalized:
            return "".join(
                (word[0].upper() + word[1:]) if word else ""
                for word in normalized.split("_")
            )
        return name[0].upper() + name[1:] if name else name

    def __init__(self, base_path: Path) -> None:
        """Initialize the repository.

        Args:
            base_path: The root directory for the app's doctypes.
        """
        self.base_path = base_path

    def _get_file_path(self, name: str) -> Path:
        """Helper to resolve a DocType name to its file path."""
        filename = (
            re.sub(r"(?<!^)(?=[A-Z])", "_", self._to_pascal_case(name)).lower() + ".py"
        )
        return self.base_path / filename

    # Note: RepositoryProtocol uses UUID for id, but for FS Code repos,
    # the "id" is practically the DocType name (a string).
    # We use Any here to satisfy the protocol signature loosely for the adapter.
    async def get(self, id: Any, as_of: datetime | None = None) -> Any | None:
        """Get a document (DocType definition) by its exact name."""
        return None

    async def save(self, entity: Any, version: int | None = None) -> Any:
        """Persist an entity."""
        if not isinstance(entity, dict) or "name" not in entity:
            raise ValueError("Entity must be a dictionary with a 'name' key")

        # Ensure name is always PascalCase
        name = self._to_pascal_case(entity["name"])
        entity["name"] = name

        file_path = self._get_file_path(name)
        # Create a minimal placeholder Python file to satisfy the test
        file_path.write_text(f"# Virtual DocType: {name}\n")

        return entity

    async def delete(self, id: Any) -> None:
        """Delete an entity."""
        file_path = self._get_file_path(str(id))
        if file_path.exists():
            file_path.unlink()
            # Additionally, we might want to clean up controller files in the future
            # if they exist for this DocType.

    async def exists(self, id: Any) -> bool:
        """Check if an entity exists."""
        return self._get_file_path(str(id)).exists()

    async def count(self, filters: list[FilterSpec] | None = None) -> int:
        """Count matching entities."""
        raise NotImplementedError("TDD: Test needs to be written first")

    async def list(
        self,
        filters: list[FilterSpec] | None = None,
        order_by: list[OrderSpec] | None = None,
        limit: int = 20,
        offset: int = 0,
        as_of: datetime | None = None,
    ) -> PaginatedResult[Any]:
        """List entities with pagination."""
        items = []
        if self.base_path.exists():
            for file_path in self.base_path.glob("*.py"):
                if file_path.name == "__init__.py":
                    continue
                # Naively extract the name from the snake_case filename for the MVP
                name = self._to_pascal_case(file_path.stem)
                items.append({"name": name})

        return PaginatedResult(
            items=items, total=len(items), limit=limit, offset=offset
        )

    async def bulk_save(self, entities: Sequence[Any]) -> Sequence[Any]:
        """Save multiple entities."""
        raise NotImplementedError("TDD: Test needs to be written first")
