"""Pydantic Decorator Discovery.

AST-based discovery of Pydantic validator logic in DocTypes.
"""

from dataclasses import dataclass

import libcst as cst


@dataclass
class ValidatorInfo:
    """Information about a discovered Pydantic validator."""

    name: str
    fields: list[str]


class ValidatorVisitor(cst.CSTVisitor):
    """LibCST visitor to extract @field_validator metadata."""

    def __init__(self) -> None:
        """Initialize visitor."""
        self.validators: list[ValidatorInfo] = []

    def visit_FunctionDef(self, node: cst.FunctionDef) -> bool:
        """Visit function definitions to check for decorators."""
        for decorator in node.decorators:
            # Look for @field_validator("field_name")
            if isinstance(decorator.decorator, cst.Call):
                func = decorator.decorator.func
                if isinstance(func, cst.Name) and func.value == "field_validator":
                    # Extract the string arguments passed to the decorator
                    fields: list[str] = []
                    for arg in decorator.decorator.args:
                        if isinstance(arg.value, cst.SimpleString):
                            val = arg.value.evaluated_value
                            if isinstance(val, str):
                                fields.append(val)

                    if fields:
                        self.validators.append(
                            ValidatorInfo(name=node.name.value, fields=fields)
                        )
        return False  # Don't recurse into function body


def discover_validators(source: str) -> list[ValidatorInfo]:
    """Discover Pydantic validators in Python source code."""
    tree = cst.parse_module(source)
    visitor = ValidatorVisitor()
    tree.visit(visitor)
    return visitor.validators


__all__ = ["ValidatorInfo", "discover_validators"]
