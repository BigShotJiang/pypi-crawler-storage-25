"""Role Discovery Service.

Scans and aggregates JSON role blueprints from both framework internal resources
and developer project mounts (`roles/*.json`).
"""

import json
import logging
from pathlib import Path

from pydantic import BaseModel

logger = logging.getLogger(__name__)


class RoleDef(BaseModel):
    """Definition of a single Role."""

    name: str
    description: str | None = None


class RoleDomain(BaseModel):
    """A collection of roles belonging to a specific business domain."""

    domain: str
    roles: list[RoleDef]


def discover_roles(project_root: Path) -> list[RoleDef]:
    """Discover and aggregate all design-time roles for the Studio.

    Loads OOTB roles first, then merges/overrides with project-mounted roles.
    """
    roles: dict[str, RoleDef] = {}

    # 1. Load OOTB Standard Roles from framework resources
    resources_dir = Path(__file__).parent.parent.parent / "resources" / "roles"
    if resources_dir.exists():
        for json_file in resources_dir.glob("*.json"):
            _load_roles_from_file(json_file, roles)

    # 2. Load Project Mounted Roles (e.g., custom domains or overrides)
    project_roles_dir = project_root / "roles"
    if project_roles_dir.exists():
        for json_file in project_roles_dir.glob("*.json"):
            _load_roles_from_file(json_file, roles)

    return list(roles.values())


def _load_roles_from_file(file_path: Path, roles_dict: dict[str, RoleDef]) -> None:
    try:
        content = json.loads(file_path.read_text(encoding="utf-8"))
        domain_data = RoleDomain.model_validate(content)
        for role in domain_data.roles:
            roles_dict[role.name] = role  # Latest loaded wins (project overrides OOTB)
    except Exception as e:
        logger.warning("Failed to parse role blueprint %s: %s", file_path, e)
