"""Augmentation Code Generation.

Implement "Target App" selective customization by generating
DocType extension/overlay source code.
"""

from typing import Any


def generate_augmentation_source(schema: dict[str, Any]) -> str:
    """Generate Python source code for an augmentation DocType.

    Args:
        schema: Dictionary with augmentation details.
            - target_name: Name of the DocType to augment
            - target_module: Module path to import the target from
            - app_name: Name of the app owning the augmentation
            - fields: List of new field definitions

    Returns:
        Generated Python source code.
    """
    target_name = schema["target_name"]
    target_module = schema["target_module"]
    fields = schema.get("fields", [])

    ext_name = f"{target_name}Ext"

    lines = [
        f'"""Auto-generated DocType Augmentation for {target_name}."""',
        "",
        "from __future__ import annotations",
        "",
        "from typing import ClassVar",
        f"from {target_module} import {target_name}",
        "",
        "",
        f"class {ext_name}({target_name}):",
        f'    """Extension overlay for {target_name} DocType."""',
        "",
    ]

    if fields:
        for field in fields:
            field_name = field["name"]
            field_type = field.get("type", "str")
            default = field.get("default")

            if default is not None:
                lines.append(f"    {field_name}: {field_type} = {default}")
            else:
                lines.append(f"    {field_name}: {field_type} | None = None")
    else:
        lines.append("    pass")

    lines.extend(
        [
            "",
            "    class Meta:",
            '        """DocType metadata overlay."""',
            "",
            f'        extends: ClassVar[str] = "{target_name}"',
            "        is_metadata_overlay: ClassVar[bool] = True",
            "",
        ]
    )

    return "\n".join(lines)
