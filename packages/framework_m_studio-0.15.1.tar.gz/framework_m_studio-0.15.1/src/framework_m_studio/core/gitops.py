"""GitOps Providers (Ports and Adapters) for Release Orchestration."""

from __future__ import annotations

import asyncio
from typing import Any, Protocol, cast

import httpx


class GitProviderProtocol(Protocol):
    """Interface (Port) for Git operations around Merge/Pull Requests."""

    async def find_mr(self, source_branch: str) -> dict[str, Any] | None:
        """Find an existing open Merge/Pull Request for a source branch."""
        ...

    async def create_mr(
        self,
        title: str,
        description: str,
        source_branch: str,
        target_branch: str = "main",
    ) -> dict[str, Any]:
        """Create a new Merge/Pull Request."""
        ...

    async def update_mr(
        self, mr_iid: int, title: str, description: str
    ) -> dict[str, Any]:
        """Update an existing Merge/Pull Request."""
        ...

    async def create_release(self, tag_name: str, description: str) -> dict[str, Any]:
        """Create a release for a specific tag."""
        ...


class GitLabProvider(GitProviderProtocol):
    """GitLab adapter for GitProviderProtocol."""

    def __init__(
        self, token: str, project_id: str, api_url: str = "https://gitlab.com/api/v4"
    ) -> None:
        self.token = token
        self.project_id = project_id
        self.api_url = api_url.rstrip("/")

    @property
    def _headers(self) -> dict[str, str]:
        return {
            "PRIVATE-TOKEN": self.token,
            "Content-Type": "application/json",
        }

    async def _request(self, method: str, url: str, **kwargs: Any) -> httpx.Response:
        """Make an HTTP request with exponential backoff for 5xx errors."""
        max_retries = 3
        base_delay = 1.0
        async with httpx.AsyncClient() as client:
            for attempt in range(max_retries):
                response = await client.request(
                    method, url, headers=self._headers, **kwargs
                )
                if (
                    response.status_code in {502, 503, 504}
                    and attempt < max_retries - 1
                ):
                    await asyncio.sleep(base_delay * (2**attempt))
                    continue
                response.raise_for_status()
                return response
        raise RuntimeError("Unreachable")  # pragma: no cover

    async def find_mr(self, source_branch: str) -> dict[str, Any] | None:
        """Find an existing open MR for a source branch."""
        url = f"{self.api_url}/projects/{self.project_id}/merge_requests"
        params = {
            "state": "opened",
            "source_branch": source_branch,
        }
        response = await self._request("GET", url, params=params)
        data = cast(list[dict[str, Any]], response.json())
        return data[0] if data else None

    async def create_mr(
        self,
        title: str,
        description: str,
        source_branch: str,
        target_branch: str = "main",
    ) -> dict[str, Any]:
        """Create a new merge request."""
        url = f"{self.api_url}/projects/{self.project_id}/merge_requests"
        payload = {
            "source_branch": source_branch,
            "target_branch": target_branch,
            "title": title,
            "description": description,
            "remove_source_branch": True,
            "squash": True,
        }
        response = await self._request("POST", url, json=payload)
        return cast(dict[str, Any], response.json())

    async def update_mr(
        self, mr_iid: int, title: str, description: str
    ) -> dict[str, Any]:
        """Update an existing merge request."""
        url = f"{self.api_url}/projects/{self.project_id}/merge_requests/{mr_iid}"
        payload = {
            "title": title,
            "description": description,
        }
        response = await self._request("PUT", url, json=payload)
        return cast(dict[str, Any], response.json())

    async def create_release(self, tag_name: str, description: str) -> dict[str, Any]:
        """Create a new release for a tag."""
        url = f"{self.api_url}/projects/{self.project_id}/releases"
        payload = {"name": tag_name, "tag_name": tag_name, "description": description}
        response = await self._request("POST", url, json=payload)
        return cast(dict[str, Any], response.json())
