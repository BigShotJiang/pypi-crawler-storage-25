"""Surgical CST Mutator.

Targeted AST/CST modifications using LibCST.
"""

import libcst as cst


class FieldAdder(cst.CSTTransformer):
    def __init__(
        self, name: str, type_annotation: str, default_value: str | None = None
    ) -> None:
        self.field_name = name
        self.type_annotation = type_annotation
        self.default_value = default_value

    def leave_ClassDef(
        self, original_node: cst.ClassDef, updated_node: cst.ClassDef
    ) -> cst.ClassDef:
        is_doctype = False
        for base in original_node.bases:
            if isinstance(base.value, cst.Name) and base.value.value == "BaseDocType":
                is_doctype = True
                break

        if not is_doctype:
            return updated_node

        stmt_str = f"{self.field_name}: {self.type_annotation}"
        if self.default_value is not None:
            stmt_str += f" = {self.default_value}"

        new_stmt = cst.parse_statement(stmt_str)
        new_body = list(updated_node.body.body)

        insert_idx = 0
        for i, stmt_node in enumerate(new_body):
            if isinstance(stmt_node, cst.SimpleStatementLine):
                if any(
                    isinstance(x, (cst.AnnAssign, cst.Assign)) for x in stmt_node.body
                ):
                    insert_idx = i + 1
            elif isinstance(stmt_node, cst.FunctionDef):
                if insert_idx == 0:
                    insert_idx = i
                break

        if insert_idx == 0 and len(new_body) > 0:
            insert_idx = 1

        new_body.insert(insert_idx, new_stmt)
        return updated_node.with_changes(
            body=updated_node.body.with_changes(body=new_body)
        )


class FieldRemover(cst.CSTTransformer):
    def __init__(self, name: str) -> None:
        self.field_name = name

    def leave_SimpleStatementLine(
        self,
        original_node: cst.SimpleStatementLine,
        updated_node: cst.SimpleStatementLine,
    ) -> cst.SimpleStatementLine | cst.RemovalSentinel:
        for assign in original_node.body:
            if (
                isinstance(assign, cst.AnnAssign)
                and isinstance(assign.target, cst.Name)
                and assign.target.value == self.field_name
            ):
                return cst.RemoveFromParent()
        return updated_node


class DocTypeMutator:
    """Mutates DocType Python source code while preserving formatting."""

    def __init__(self, source: str) -> None:
        """Initialize with Python source code."""
        self.source = source
        self.module = cst.parse_module(source)

    def add_field(
        self, name: str, type_annotation: str, default_value: str | None = None
    ) -> str:
        """Add a new field to the DocType."""
        transformer = FieldAdder(name, type_annotation, default_value)
        modified_module = self.module.visit(transformer)
        return modified_module.code

    def remove_field(self, name: str) -> str:
        """Remove an existing field from the DocType."""
        transformer = FieldRemover(name)
        modified_module = self.module.visit(transformer)
        return modified_module.code
