"""Shell Plugin Configurator — Global Hooks (§6.3).

Manages shell-wide UI hooks: global action buttons,
custom sidebar apps, and search providers. All registrations
support per-role scoping and JSON persistence.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class ActionButton:
    """A global action button in the shell."""

    id: str
    """Unique button identifier."""

    label: str
    """Button label text."""

    action: str
    """Action type: 'navigate', 'modal', 'api_call'."""

    target: str
    """Action target (URL, modal ID, or API endpoint)."""

    icon: str | None = None
    """Optional icon name."""

    roles: list[str] = field(default_factory=list)
    """Roles that can see this button. Empty = all roles."""


@dataclass
class SidebarApp:
    """A custom sidebar app entry."""

    id: str
    """Unique app identifier."""

    label: str
    """Sidebar label."""

    icon: str
    """Icon name."""

    route: str
    """Route to navigate to when clicked."""

    roles: list[str] = field(default_factory=list)
    """Roles that can see this app. Empty = all roles."""


@dataclass
class SearchProvider:
    """A custom search provider."""

    id: str
    """Unique provider identifier."""

    label: str
    """Provider label shown in search UI."""

    handler: str
    """Python module path to the search handler."""

    roles: list[str] = field(default_factory=list)
    """Roles that can use this provider. Empty = all roles."""


class ShellPluginConfig:
    """Configuration for shell-wide plugin hooks.

    Manages:
    - Global action buttons (header bar)
    - Custom sidebar apps (left sidebar)
    - Search providers (global search)
    """

    def __init__(self) -> None:
        """Initialize with empty registrations."""
        self._buttons: list[ActionButton] = []
        self._sidebar_apps: list[SidebarApp] = []
        self._search_providers: list[SearchProvider] = []

    def register_action_button(self, button: ActionButton) -> None:
        """Register a global action button.

        Args:
            button: ActionButton to register.
        """
        self._buttons.append(button)

    def unregister_action_button(self, button_id: str) -> None:
        """Remove an action button by id.

        Args:
            button_id: Button ID to remove.
        """
        self._buttons = [b for b in self._buttons if b.id != button_id]

    def get_action_buttons(self, role: str | None = None) -> list[ActionButton]:
        """Get action buttons, optionally filtered by role.

        Args:
            role: If provided, only return buttons visible to this role.

        Returns:
            List of ActionButton instances.
        """
        if role is None:
            return list(self._buttons)
        return [b for b in self._buttons if not b.roles or role in b.roles]

    def register_sidebar_app(self, app: SidebarApp) -> None:
        """Register a custom sidebar app.

        Args:
            app: SidebarApp to register.
        """
        self._sidebar_apps.append(app)

    def get_sidebar_apps(self, role: str | None = None) -> list[SidebarApp]:
        """Get sidebar apps, optionally filtered by role.

        Args:
            role: If provided, only return apps visible to this role.

        Returns:
            List of SidebarApp instances.
        """
        if role is None:
            return list(self._sidebar_apps)
        return [a for a in self._sidebar_apps if not a.roles or role in a.roles]

    def register_search_provider(self, provider: SearchProvider) -> None:
        """Register a search provider.

        Args:
            provider: SearchProvider to register.
        """
        self._search_providers.append(provider)

    def get_search_providers(self, role: str | None = None) -> list[SearchProvider]:
        """Get search providers, optionally filtered by role.

        Args:
            role: If provided, only return providers for this role.

        Returns:
            List of SearchProvider instances.
        """
        if role is None:
            return list(self._search_providers)
        return [p for p in self._search_providers if not p.roles or role in p.roles]

    def save(self, path: Path) -> None:
        """Save configuration to a JSON file.

        Args:
            path: File path to write to.
        """
        data = {
            "action_buttons": [
                {
                    "id": b.id,
                    "label": b.label,
                    "action": b.action,
                    "target": b.target,
                    "icon": b.icon,
                    "roles": b.roles,
                }
                for b in self._buttons
            ],
            "sidebar_apps": [
                {
                    "id": a.id,
                    "label": a.label,
                    "icon": a.icon,
                    "route": a.route,
                    "roles": a.roles,
                }
                for a in self._sidebar_apps
            ],
            "search_providers": [
                {
                    "id": p.id,
                    "label": p.label,
                    "handler": p.handler,
                    "roles": p.roles,
                }
                for p in self._search_providers
            ],
        }
        path.write_text(json.dumps(data, indent=2))

    @classmethod
    def load(cls, path: Path) -> ShellPluginConfig:
        """Load configuration from a JSON file.

        Args:
            path: File path to read from.

        Returns:
            Populated ShellPluginConfig.
        """
        config = cls()
        data = json.loads(path.read_text())

        for btn in data.get("action_buttons", []):
            config.register_action_button(ActionButton(**btn))

        for app in data.get("sidebar_apps", []):
            config.register_sidebar_app(SidebarApp(**app))

        for prov in data.get("search_providers", []):
            config.register_search_provider(SearchProvider(**prov))

        return config
