"""Studio API Manifest.

Aggregates all modular domain controllers into a single router.
"""

from litestar import Router

from framework_m_studio.routers.aggregate import AggregateController
from framework_m_studio.routers.doctypes import DocTypeController
from framework_m_studio.routers.print import PrintController
from framework_m_studio.routers.publish import PublishController
from framework_m_studio.routers.roles import RoleController
from framework_m_studio.routers.shell import ShellController

api_router = Router(
    path="",
    route_handlers=[
        DocTypeController,
        PublishController,
        PrintController,
        AggregateController,
        ShellController,
        RoleController,
    ],
)

# Retain alias for direct controller mounts
__all__ = ["DocTypeController", "api_router"]
