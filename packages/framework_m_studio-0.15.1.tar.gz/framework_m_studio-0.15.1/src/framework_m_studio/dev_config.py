"""Development configuration utilities.

This module provides utilities for loading development server configuration
from various sources (Procfile, m.toml [dev] section).

Supports:
- Procfile format parsing
- m.toml [dev] section parsing
- Process definition schema validation
"""

from __future__ import annotations

import re
import sys
from pathlib import Path
from typing import Any, TypedDict


class ProcessConfig(TypedDict, total=False):
    """Configuration for a single development process."""

    command: str
    cwd: str | None
    env: dict[str, str] | None
    enabled: bool


class DevConfig(TypedDict, total=False):
    """Development configuration schema from m.toml [dev] section."""

    backend_port: int
    frontend_port: int
    backend_command: str | None
    frontend_command: str | None
    enable_worker: bool
    enable_scheduler: bool
    procfile: str | None
    processes: dict[str, ProcessConfig]


def load_procfile(procfile_path: Path) -> dict[str, str]:
    """Load and parse a Procfile.

    Procfile format:
        process_name: command to run
        backend: uvicorn app:app --reload
        frontend: cd frontend && pnpm dev

    Args:
        procfile_path: Path to Procfile

    Returns:
        Dictionary mapping process names to commands

    Example:
        >>> processes = load_procfile(Path("Procfile.dev"))
        >>> processes["backend"]
        'uvicorn app:app --reload'
    """
    if not procfile_path.exists():
        return {}

    processes: dict[str, str] = {}
    content = procfile_path.read_text()

    for line in content.splitlines():
        line = line.strip()

        # Skip empty lines and comments
        if not line or line.startswith("#"):
            continue

        # Parse "name: command" format
        match = re.match(r"^([a-zA-Z0-9_-]+):\s*(.+)$", line)
        if match:
            name, command = match.groups()
            processes[name] = command

    return processes


def load_m_toml(config_path: Path | None = None) -> dict[str, Any]:
    """Load m.toml configuration file."""
    if config_path is None:
        config_path = Path.cwd() / "m.toml"

    if not config_path.exists():
        return {}

    import tomllib

    content = config_path.read_bytes()
    return tomllib.loads(content.decode())


def load_dev_config_from_toml(config_path: Path | None = None) -> DevConfig:
    """Load [dev] section from m.toml configuration file.

    Args:
        config_path: Path to m.toml file. If None, searches in current directory.

    Returns:
        Parsed development configuration

    Example:
        >>> config = load_dev_config_from_toml()
        >>> config["backend_port"]
        8888
    """
    data = load_m_toml(config_path)

    # Extract [dev] section
    dev_section = data.get("dev", {})

    # Return with type safety
    config: DevConfig = {}

    if "backend_port" in dev_section:
        config["backend_port"] = int(dev_section["backend_port"])

    if "frontend_port" in dev_section:
        config["frontend_port"] = int(dev_section["frontend_port"])

    if "backend_command" in dev_section:
        config["backend_command"] = str(dev_section["backend_command"])

    if "frontend_command" in dev_section:
        config["frontend_command"] = str(dev_section["frontend_command"])

    if "enable_worker" in dev_section:
        config["enable_worker"] = bool(dev_section["enable_worker"])

    if "enable_scheduler" in dev_section:
        config["enable_scheduler"] = bool(dev_section["enable_scheduler"])

    if "procfile" in dev_section:
        config["procfile"] = str(dev_section["procfile"])

    # Parse custom processes
    if "processes" in dev_section:
        processes: dict[str, ProcessConfig] = {}
        for name, proc_data in dev_section["processes"].items():
            proc_config: ProcessConfig = {
                "command": str(proc_data.get("command", "")),
                "enabled": bool(proc_data.get("enabled", True)),
            }
            if "cwd" in proc_data:
                proc_config["cwd"] = str(proc_data["cwd"])
            if "env" in proc_data:
                proc_config["env"] = {k: str(v) for k, v in proc_data["env"].items()}
            processes[name] = proc_config
        config["processes"] = processes

    return config


def get_default_processes(
    app: str,
    host: str,
    port: int,
    frontend_dir: Path,
    frontend_port: int,
    no_frontend: bool = False,
) -> dict[str, str]:
    """Get default process definitions.

    Args:
        app: Backend app path (module:attribute)
        host: Backend host
        port: Backend port
        frontend_dir: Frontend directory path
        frontend_port: Frontend dev server port
        no_frontend: Skip frontend process

    Returns:
        Dictionary mapping process names to commands
    """
    processes: dict[str, str] = {}

    # Backend with hot reload
    factory_flag = "--factory" if ":create_app" in app else ""
    backend_cmd = f"{sys.executable} -m uvicorn {app} {factory_flag} --host {host} --port {port} --reload"
    processes["backend"] = backend_cmd

    # Frontend dev server
    if not no_frontend and frontend_dir.exists():
        frontend_cmd = f"cd {frontend_dir} && pnpm dev --port {frontend_port}"
        processes["frontend"] = frontend_cmd

    return processes


def merge_process_configs(
    defaults: dict[str, str],
    procfile_processes: dict[str, str],
    toml_config: DevConfig,
) -> dict[str, str]:
    """Merge process configurations with proper precedence.

    Precedence order (highest to lowest):
    1. Procfile processes (explicit user definition)
    2. m.toml [dev] custom processes
    3. m.toml [dev] backend/frontend overrides
    4. Default processes

    Args:
        defaults: Default process definitions
        procfile_processes: Processes from Procfile
        toml_config: Configuration from m.toml [dev]

    Returns:
        Merged process dictionary
    """
    merged = defaults.copy()

    # Apply m.toml overrides for backend/frontend commands
    backend_cmd_override = toml_config.get("backend_command")
    if backend_cmd_override:
        merged["backend"] = backend_cmd_override

    frontend_cmd_override = toml_config.get("frontend_command")
    if frontend_cmd_override:
        merged["frontend"] = frontend_cmd_override

    # Apply m.toml custom processes
    if "processes" in toml_config:
        for name, proc_config in toml_config["processes"].items():
            if proc_config.get("enabled", True):
                cmd = proc_config["command"]
                # Prepend cwd if specified
                if proc_config.get("cwd"):
                    cmd = f"cd {proc_config['cwd']} && {cmd}"
                merged[name] = cmd

    # Procfile has highest precedence - overrides everything
    merged.update(procfile_processes)

    return merged


__all__ = [
    "DevConfig",
    "ProcessConfig",
    "get_default_processes",
    "load_dev_config_from_toml",
    "load_m_toml",
    "load_procfile",
    "merge_process_configs",
]
