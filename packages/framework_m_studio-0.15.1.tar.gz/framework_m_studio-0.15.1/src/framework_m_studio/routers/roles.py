from litestar import Controller, get

from framework_m_studio.core.discovery.roles import discover_roles
from framework_m_studio.schemas import RoleDefSchema, RoleListResponse
from framework_m_studio.services import workspace


class RoleController(Controller):
    path = "/studio/api/roles"
    tags = ("Studio - Roles",)

    @get()
    async def get_roles(self) -> RoleListResponse:
        """Get all design-time roles from OOTB library and project mounts."""
        root = workspace.get_project_root()
        roles = discover_roles(root)

        return RoleListResponse(
            roles=[RoleDefSchema(name=r.name, description=r.description) for r in roles]
        )
