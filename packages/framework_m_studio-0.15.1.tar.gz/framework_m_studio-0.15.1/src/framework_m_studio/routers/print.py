from litestar import Controller, get, post
from litestar.exceptions import NotFoundException

from framework_m_studio.schemas import (
    HotSwapStatusResponse,
    HotSwapSyncResponse,
    PrintLayoutListResponse,
    PrintLayoutRequest,
    PrintLayoutResponse,
    PrintPreviewRequest,
    PrintPreviewResponse,
)
from framework_m_studio.services import print_service


class PrintController(Controller):
    path = "/studio/api/print"
    tags = ("Studio - Print",)

    @get("/layouts/{doctype:str}")
    async def list_print_layouts(self, doctype: str) -> PrintLayoutListResponse:
        layouts = print_service.get_print_repo_adapter().list_layouts(doctype)
        return PrintLayoutListResponse(doctype=doctype, layouts=layouts)

    @get("/layout/{doctype:str}/{template_name:str}")
    async def get_print_layout(
        self, doctype: str, template_name: str
    ) -> PrintLayoutResponse:
        target = print_service.get_print_repo_path() / doctype / f"{template_name}.html"
        if not target.exists():
            raise NotFoundException(f"Print template '{template_name}' not found.")
        return PrintLayoutResponse(
            doctype=doctype,
            template_name=template_name,
            content=target.read_text(encoding="utf-8"),
        )

    @post("/layout/{doctype:str}/{template_name:str}")
    async def save_print_layout(
        self, doctype: str, template_name: str, data: PrintLayoutRequest
    ) -> PrintLayoutResponse:
        await print_service.get_print_repo_adapter().save_layout(
            doctype, template_name, data.content
        )
        return PrintLayoutResponse(
            doctype=doctype, template_name=template_name, content=data.content
        )

    @post("/preview")
    async def preview_print_layout(
        self, data: PrintPreviewRequest
    ) -> PrintPreviewResponse:
        res = await print_service.get_print_repo_adapter().preview_with_sample(
            doctype=data.doctype, template_name=data.template_name, data=data.data
        )
        return PrintPreviewResponse(success=res.success, html=res.html, error=res.error)

    @get("/hotswap/status")
    async def print_hotswap_status(self) -> HotSwapStatusResponse:
        count, last = print_service.get_hot_swap_status()
        return HotSwapStatusResponse(
            watching=print_service.get_hot_swap_monitor().is_watching,
            repo_path=str(print_service.get_print_repo_path()),
            updates_received=count,
            last_update_at=last,
        )

    @post("/hotswap/sync")
    async def print_hotswap_sync(self) -> HotSwapSyncResponse:
        return HotSwapSyncResponse(
            success=True,
            message="Print hot-swap sync event processed.",
            updates_received=print_service.record_sync(),
        )
