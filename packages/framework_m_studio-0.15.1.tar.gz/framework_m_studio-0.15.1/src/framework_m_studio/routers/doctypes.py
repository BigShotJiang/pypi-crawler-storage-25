from pathlib import Path
from typing import Any

from framework_m_core.domain.meta import DocTypeMetaConfig
from litestar import Controller, delete, get, post
from litestar.exceptions import NotFoundException

from framework_m_studio.discovery import doctype_to_dict, scan_doctypes
from framework_m_studio.schemas import (
    CreateDocTypeRequest,
    DocTypeListResponse,
    DocTypeResponse,
    MessageResponse,
)
from framework_m_studio.services import doctype as dt_service
from framework_m_studio.services import workspace


class DocTypeController(Controller):
    path = "/studio/api"
    tags = ("Studio - DocTypes",)

    @get("/doctypes")
    async def list_doctypes(self) -> DocTypeListResponse:
        root = workspace.get_project_root()
        doctypes = scan_doctypes(root)
        return DocTypeListResponse(
            doctypes=[doctype_to_dict(dt) for dt in doctypes],
            count=len(doctypes),
            project_root=str(root),
        )

    @get("/doctypes/{name:str}")
    async def get_doctype(self, name: str) -> DocTypeResponse:
        for doctype in scan_doctypes(workspace.get_project_root()):
            if doctype.name == name:

                def clean_val(v: dict[str, Any] | None) -> dict[str, Any] | None:
                    if not v:
                        return None
                    c = {k: val for k, val in v.items() if val is not None}
                    return c if c else None

                # Create a default meta config from the core domain model
                default_meta = DocTypeMetaConfig().model_dump(exclude_none=True)
                # Merge the parsed meta over the defaults
                final_meta = {**default_meta, **doctype.meta}

                return DocTypeResponse(
                    name=doctype.name,
                    module=doctype.module,
                    file_path=doctype.file_path,
                    docstring=doctype.docstring,
                    fields=[
                        {
                            "name": f.name,
                            "type": f.type,
                            "default": f.default,
                            "required": f.required,
                            "label": f.label,
                            "description": f.description,
                            "link_doctype": f.link_doctype,
                            "table_doctype": f.table_doctype,
                            "validators": clean_val(f.validators),
                        }
                        for f in doctype.fields
                    ],
                    meta=final_meta,
                )
        raise NotFoundException(f"DocType '{name}' not found")  # pragma: no cover

    @post("/doctypes/{name:str}")
    async def create_or_update_doctype(
        self, name: str, data: CreateDocTypeRequest
    ) -> MessageResponse:
        root = workspace.get_project_root()
        clean_class = dt_service.sanitize_doctype_name(data.name)
        clean_folder = dt_service.to_snake_case(clean_class)
        data.name = clean_class
        is_rename = name != clean_class
        old_folder = (
            dt_service.find_old_doctype_folder(root, name) if is_rename else None
        )

        target_dir = workspace.resolve_doctype_target_dir(
            root, workspace.detect_app_name(root, data.app)
        )
        doctype_folder = target_dir / "doctypes" / clean_folder
        doctype_folder.mkdir(parents=True, exist_ok=True)

        dt_service.write_doctype_artifacts(
            doctype_folder, clean_class, data, root, clean_folder
        )

        if is_rename:
            dt_service.cleanup_renamed_doctype_paths(root, name, old_folder)

        return MessageResponse(
            message=f"DocType '{clean_class}' {'renamed' if is_rename else 'created'} successfully",
            file_path=str(doctype_folder),
        )

    @delete("/doctypes/{name:str}", status_code=200)
    async def delete_doctype(self, name: str) -> MessageResponse:
        import shutil

        root = workspace.get_project_root()
        for doctype in scan_doctypes(root):
            if doctype.name == name:
                file_path = Path(doctype.file_path)
                doctype_dir = file_path.parent
                if doctype_dir.exists() and doctype_dir.is_dir():
                    shutil.rmtree(doctype_dir)
                    tests_dir = (
                        root / "tests" / "doctypes" / dt_service.to_snake_case(name)
                    )
                    if tests_dir.exists():
                        shutil.rmtree(tests_dir)
                    return MessageResponse(
                        message=f"DocType '{name}' deleted successfully",
                        file_path=str(doctype_dir),
                    )
                elif file_path.exists():  # pragma: no cover
                    file_path.unlink()  # pragma: no cover
                    return MessageResponse(  # pragma: no cover
                        message=f"DocType '{name}' deleted successfully",  # pragma: no cover
                        file_path=str(file_path),  # pragma: no cover
                    )  # pragma: no cover
        raise NotFoundException(f"DocType '{name}' not found")  # pragma: no cover
