from litestar import Controller, get, post

from framework_m_studio.aggregate_builder import LinkedDocType
from framework_m_studio.schemas import (
    AggregateConfigRequest,
    AggregateConfigResponse,
    AggregateLinkSchema,
    AggregateRootsResponse,
)
from framework_m_studio.services import aggregate as agg_service


class AggregateController(Controller):
    path = "/studio/api/aggregate"
    tags = ("Studio - Aggregates",)

    @get("/roots")
    async def list_aggregate_roots(self) -> AggregateRootsResponse:
        return AggregateRootsResponse(
            roots=agg_service.get_aggregate_builder().list_roots()
        )

    @get("/config/{root:str}")
    async def get_aggregate_config(self, root: str) -> AggregateConfigResponse:
        data = agg_service.get_aggregate_builder().to_dict(root)
        if not data:
            return AggregateConfigResponse(root=root, linked=[])
        return AggregateConfigResponse(
            root=data["root"], linked=[AggregateLinkSchema(**i) for i in data["linked"]]
        )

    @post("/config/{root:str}")
    async def save_aggregate_config(
        self, root: str, data: AggregateConfigRequest
    ) -> AggregateConfigResponse:
        builder = agg_service.get_aggregate_builder()
        if root not in builder.list_roots():
            builder.define(root)
        if config := builder.get_config(root):
            config.linked = []
        for linked in data.linked:
            builder.link(
                root,
                LinkedDocType(
                    doctype=linked.doctype,
                    link_field=linked.link_field,
                    cascade=linked.cascade,
                ),
            )
        agg_service.save_aggregate_builder(builder)
        saved = builder.to_dict(root)
        return AggregateConfigResponse(
            root=saved.get("root", root),
            linked=[AggregateLinkSchema(**i) for i in saved.get("linked", [])],
        )
