from litestar import Controller, get, post

from framework_m_studio.schemas import (
    ActionButtonSchema,
    SearchProviderSchema,
    ShellConfigRequest,
    ShellConfigResponse,
    SidebarAppSchema,
)
from framework_m_studio.services import shell as shell_service
from framework_m_studio.shell_plugin_config import (
    ActionButton,
    SearchProvider,
    ShellPluginConfig,
    SidebarApp,
)


class ShellController(Controller):
    path = "/studio/api/shell"
    tags = ("Studio - Shell",)

    @get("/config")
    async def get_shell_config(self, role: str | None = None) -> ShellConfigResponse:
        config = shell_service.get_shell_plugin_config()
        return ShellConfigResponse(
            action_buttons=[
                ActionButtonSchema(**shell_service.serialize_action_button(b))
                for b in config.get_action_buttons(role=role)
            ],
            sidebar_apps=[
                SidebarAppSchema(**shell_service.serialize_sidebar_app(a))
                for a in config.get_sidebar_apps(role=role)
            ],
            search_providers=[
                SearchProviderSchema(**shell_service.serialize_search_provider(p))
                for p in config.get_search_providers(role=role)
            ],
        )

    @post("/config")
    async def save_shell_config(self, data: ShellConfigRequest) -> ShellConfigResponse:
        config = ShellPluginConfig()
        for b in data.action_buttons:
            config.register_action_button(ActionButton(**b.model_dump()))
        for a in data.sidebar_apps:
            config.register_sidebar_app(SidebarApp(**a.model_dump()))
        for p in data.search_providers:
            config.register_search_provider(SearchProvider(**p.model_dump()))
        shell_service.set_shell_plugin_config(config)
        shell_service.save_shell_plugin_config(config)
        return ShellConfigResponse(
            action_buttons=data.action_buttons,
            sidebar_apps=data.sidebar_apps,
            search_providers=data.search_providers,
        )
