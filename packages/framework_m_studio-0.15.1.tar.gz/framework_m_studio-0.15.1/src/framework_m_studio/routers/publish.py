from litestar import Controller, post

from framework_m_studio.git.adapter import GitAdapter
from framework_m_studio.guardrail import GuardrailChecker, PublishGuard
from framework_m_studio.schemas import (
    CreateDocTypeRequest,
    GuardrailCheckResponse,
    PublishRequest,
    PublishResponse,
)
from framework_m_studio.services import (
    doctype as dt_service,
)
from framework_m_studio.services import (
    publish as pub_service,
)
from framework_m_studio.services import (
    workspace,
)
from framework_m_studio.storage.file_adapter import FileAdapter
from framework_m_studio.storage.git_api_adapter import GitApiAdapter


class PublishController(Controller):
    path = "/studio/api"
    tags = ("Studio - Publishing",)

    @post("/guardrail/check")
    async def guardrail_check(
        self, data: CreateDocTypeRequest
    ) -> GuardrailCheckResponse:
        root = workspace.get_project_root()
        old_src = dt_service.load_existing_doctype_source(data.name, root)
        new_src = dt_service.generate_doctype_code(data)
        result = GuardrailChecker().check(old_src, new_src)
        return GuardrailCheckResponse(
            has_dangerous=result.has_dangerous,
            can_publish=result.can_publish,
            changes=result.changes,
        )

    @post("/publish")
    async def publish_changes(self, data: PublishRequest) -> PublishResponse:
        root = workspace.get_project_root()
        guard_resp = None
        if data.doctype_payload is not None:
            old_src = dt_service.load_existing_doctype_source(
                data.doctype_payload.name, root
            )
            new_src = dt_service.generate_doctype_code(data.doctype_payload)
            result = GuardrailChecker().check(old_src, new_src)
            guard_resp = GuardrailCheckResponse(
                has_dangerous=result.has_dangerous,
                can_publish=result.can_publish,
                changes=result.changes,
            )
            if not PublishGuard().allow_publish(result, acknowledged=data.acknowledged):
                return PublishResponse(
                    success=False,
                    blocked=True,
                    adapter_type="guardrail",
                    error="Dangerous changes require acknowledgement.",
                    guardrail=guard_resp,
                )

        remote_url = pub_service.get_remote_origin_url(root)
        if not (root / ".git").exists() or not remote_url:
            file_res = await FileAdapter(root).publish(
                message=data.message, author=data.author
            )
            err = (
                "Git remote not configured; changes remain local."
                if not remote_url
                else None
            )
            return PublishResponse(
                success=file_res.success,
                adapter_type=file_res.adapter_type,
                error=err,
                guardrail=guard_resp,
            )

        storage = GitApiAdapter(
            git_adapter=GitAdapter(), workspace_path=root, repo_url=remote_url
        )
        pub_res = await storage.publish(
            message=data.message, author=pub_service.normalize_author(data.author)
        )

        cr_url = (
            pub_service.build_change_request_url(remote_url, pub_res.branch)
            if pub_res.success and pub_res.branch
            else None
        )

        return PublishResponse(
            success=pub_res.success,
            adapter_type=pub_res.adapter_type,
            branch=pub_res.branch,
            commit_sha=pub_res.commit_sha,
            change_request_url=cr_url,
            error=pub_res.error,
            guardrail=guard_resp,
        )
