"""Automated Screenshot Capture Engine.

This module provides the core logic for capturing high-fidelity screenshots
of Framework M applications using Playwright.
"""

from __future__ import annotations

from importlib import import_module
from pathlib import Path
from typing import TYPE_CHECKING, Any

from framework_m_core.cli.utility import console

if TYPE_CHECKING:
    from playwright.sync_api import BrowserContext, Page

# Lazy-loaded attributes
yaml: Any = None
sync_playwright: Any = None


def capture_screenshots(
    manifest_path: Path,
    base_url: str,
    target_path: Path,
    username: str | None = None,
    password: str | None = None,
    verbose: bool = False,
    trace: bool = False,
) -> None:
    """Orchestrate screenshot capture based on a manifest.

    Args:
        manifest_path: Path to YAML manifest file.
        base_url: Default base URL for navigation.
        target_path: Directory to save screenshots.
        username: Optional login email.
        password: Optional login password.
        verbose: Enable browser console logging.
        trace: Enable Playwright tracing.
    """
    global yaml
    if yaml is None:
        yaml = import_module("yaml")

    if not manifest_path.exists():
        console.error(f"❌ Manifest file not found: {manifest_path}")
        return

    console.info(f"📸 Loading screenshot manifest: {manifest_path}")
    with manifest_path.open() as f:
        config = yaml.safe_load(f)

    screenshots = config.get("screenshots", [])
    if not screenshots:
        console.warning("⚠️  No screenshots defined in manifest.")
        return

    target_path.mkdir(parents=True, exist_ok=True)

    # Group screenshots by base_url for efficient authentication
    groups: dict[str, list[dict[str, Any]]] = {}
    for shot in screenshots:
        b_url = shot.get("base_url", base_url).rstrip("/")
        if b_url not in groups:
            groups[b_url] = []
        groups[b_url].append(shot)

    console.info(
        f"🚀 Launching browser to capture {len(screenshots)} screenshots across {len(groups)} domain(s)..."
    )

    global sync_playwright
    if sync_playwright is None:
        from playwright.sync_api import sync_playwright

    with sync_playwright() as p:
        # Launch with--disable-web-security to bypass CSRF/CORS issues in dev mode
        browser = p.chromium.launch(
            args=[
                "--disable-web-security",
                "--disable-dev-shm-usage",
                "--no-sandbox",
                "--disable-setuid-sandbox",
            ]
        )

        # We will manage contexts dynamically based on requested scale factors
        active_contexts: dict[int, BrowserContext] = {}
        # Store authentication state to share across scales
        storage_state: dict[str, Any] | None = None

        def get_page(scale: int) -> Page:
            if scale not in active_contexts:
                # Create context with shared storage state if we have one
                ctx = browser.new_context(
                    device_scale_factor=scale, storage_state=storage_state
                )
                if trace:
                    ctx.tracing.start(screenshots=True, snapshots=True, sources=True)
                active_contexts[scale] = ctx
            page = active_contexts[scale].new_page()
            setup_page(page)
            return page

        def setup_page(page: Page) -> None:
            # Block external dependencies known to be noisy or rate-limited in CI
            def handle_route(route: Any) -> Any:
                url = route.request.url.lower()
                if any(
                    block in url
                    for block in [
                        "locize",
                        "google-analytics",
                        "sentry.io",
                        "googletagmanager",
                        "intercom",
                        "telemetry.refine.dev",
                    ]
                ):
                    route.abort()
                else:
                    route.continue_()

            page.route("**/*", handle_route)

            if verbose:
                page.on(
                    "console",
                    lambda msg: console.info(
                        f"    🖥️ [Browser Console] {msg.type}: {msg.text}"
                    ),
                )
                page.on(
                    "pageerror",
                    lambda err: console.error(f"    ❌ [Browser Error] {err.message}"),
                )

        failed_count = 0
        authenticated_domains = set()

        for domain, shots in groups.items():
            console.info(f"\n🌐 Processing domain: {domain}")
            storage_state = None

            # Perform UI-based login
            if (
                username
                and password
                and (any(not shot.get("skip_auth", False) for shot in shots))
                and domain not in authenticated_domains
            ):
                console.info(f"  🔐 Authenticating as {username} (UI-based)...")
                ui_auth_context = browser.new_context(device_scale_factor=1)
                login_page = ui_auth_context.new_page()
                setup_page(login_page)
                try:
                    login_page.goto(f"{domain}/login", timeout=30000)

                    if "/login" not in login_page.url:
                        console.success("    ✓ Already authenticated.")
                    else:
                        login_page.locator('input[name="email"]').fill(username)
                        login_page.locator('input[name="password"]').fill(password)
                        login_page.keyboard.press("Enter")
                        login_page.wait_for_url(
                            lambda url: "/login" not in url, timeout=30000
                        )
                        login_page.wait_for_timeout(1000)
                        console.success("    ✓ Login successful (Keyboard).")

                    storage_state = ui_auth_context.storage_state()
                    authenticated_domains.add(domain)

                except Exception as e:
                    console.error(f"    ❌ UI Login failed for {domain}: {e!s}")
                finally:
                    login_page.close()
                    ui_auth_context.close()

            for shot in shots:
                sid = shot.get("id", "unknown")
                url_path = shot.get("url", "/")
                url = f"{domain}{url_path}"
                output = shot.get("output", str(target_path / f"{sid}.png"))
                wait_for = shot.get("wait_for")
                selector = shot.get("selector")
                viewport = shot.get("viewport")
                scale = shot.get("scale", 2)
                theme = shot.get("theme", "light")
                timeout = shot.get("timeout", 30000)

                console.info(f"    ➜ Capturing {sid} (Scale: {scale}x, Theme: {theme})")

                page = get_page(scale)
                try:
                    page.emulate_media(color_scheme=theme)
                    if viewport:
                        page.set_viewport_size(
                            {
                                "width": viewport.get("width", 1280),
                                "height": viewport.get("height", 720),
                            }
                        )

                    page.goto(url, timeout=60000, wait_until="load")

                    if wait_for:
                        page.wait_for_selector(wait_for, timeout=timeout)
                    elif selector:
                        page.wait_for_selector(selector, timeout=timeout)
                    else:
                        page.wait_for_load_state("networkidle", timeout=timeout)

                    out_path = Path(output)
                    out_path.parent.mkdir(parents=True, exist_ok=True)
                    page.screenshot(path=str(out_path))
                    console.success(f"      ✓ Saved to {out_path.name}")

                    fail_img = out_path.with_suffix(".fail.png")
                    if fail_img.exists():
                        fail_img.unlink()
                except Exception as e:
                    console.error(f"      ❌ Failed: {e!s}")
                    fail_img = Path(output).with_suffix(".fail.png")
                    page.screenshot(path=str(fail_img))
                    failed_count += 1
                finally:
                    page.close()

        if trace:
            for scale, ctx in active_contexts.items():
                trace_zip = target_path / f"trace-{scale}x.zip"
                try:
                    ctx.tracing.stop(path=str(trace_zip))
                    console.success(f"📊 Trace saved: {trace_zip.name}")
                except Exception as e:
                    console.warning(f"⚠️  Could not save trace: {e}")

        browser.close()

    if failed_count > 0:
        console.error(f"\n❌ Pipeline failed: {failed_count} screenshot(s) missing.")
        import sys

        sys.exit(1)
    else:
        console.success("\n✨ All screenshots captured successfully!")
