"""AST Parsers for Documentation Generation.

This module provides utilities to parse Python source code using the `ast` module
to automatically generate documentation for Protocols and Controller Hooks.
"""

import ast
from pathlib import Path


def generate_protocols_doc(project_root: Path) -> str:
    """Generate documentation for Protocol interfaces."""
    interfaces_dir = (
        project_root
        / "libs"
        / "framework-m-core"
        / "src"
        / "framework_m_core"
        / "interfaces"
    )

    content = """# Protocol Interfaces\n\n> **Auto-generated from source code** - Do not edit manually.\n\nFramework M uses Protocol interfaces to define contracts between components.\nSwap implementations by providing different adapters.\n\n---\n\n"""
    if not interfaces_dir.exists():
        return content + f"*Error: interfaces directory {interfaces_dir} not found*"

    protocol_files = sorted(interfaces_dir.glob("*.py"))

    for filepath in protocol_files:
        if filepath.name.startswith("_"):
            continue

        try:
            tree = ast.parse(filepath.read_text())
        except SyntaxError:
            continue

        for node in ast.walk(tree):
            if isinstance(node, ast.ClassDef):
                # Check if it's a Protocol (has Protocol in bases)
                is_protocol = any(
                    (
                        isinstance(base, ast.Subscript)
                        and isinstance(base.value, ast.Name)
                        and base.value.id == "Protocol"
                    )
                    or (isinstance(base, ast.Name) and base.id == "Protocol")
                    for base in node.bases
                )

                if not is_protocol and "Protocol" not in node.name:
                    continue

                docstring = extract_docstring(node)

                content += f"## `{node.name}`\n\n"
                content += f"**File**: `core/interfaces/{filepath.name}`\n\n"

                if docstring:
                    # Take first paragraph
                    first_para = docstring.split("\n\n")[0].strip()
                    content += f"{first_para}\n\n"

                # List methods
                methods = []
                for item in node.body:
                    if isinstance(item, (ast.FunctionDef, ast.AsyncFunctionDef)):
                        if item.name.startswith("_"):
                            continue
                        sig = extract_function_signature(item)
                        method_doc = extract_docstring(item)
                        methods.append((item.name, sig, method_doc))

                if methods:
                    content += "**Methods**:\n\n"
                    for _name, sig, m_doc in methods:
                        content += f"- `{sig}`\n"
                        if m_doc:
                            first_line = m_doc.split("\n")[0].strip()
                            if first_line:
                                content += f"  - {first_line}\n"
                    content += "\n"

                content += "---\n\n"

    return content


def extract_docstring(node: ast.AST) -> str:
    """Extract docstring from an AST node."""
    if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)) and (
        node.body
        and isinstance(node.body[0], ast.Expr)
        and isinstance(node.body[0].value, ast.Constant)
    ):
        return str(node.body[0].value.value or "")
    return ""


def extract_function_signature(node: ast.FunctionDef | ast.AsyncFunctionDef) -> str:
    """Extract function signature as string."""
    args = []
    for arg in node.args.args:
        if arg.arg == "self":
            continue
        annotation = ""
        if arg.annotation:
            annotation = f": {ast.unparse(arg.annotation)}"
        args.append(f"{arg.arg}{annotation}")

    returns = ""
    if node.returns:
        returns = f" -> {ast.unparse(node.returns)}"

    async_prefix = "async " if isinstance(node, ast.AsyncFunctionDef) else ""
    return f"{async_prefix}def {node.name}({', '.join(args)}){returns}"


def generate_hooks_doc(project_root: Path, hooks_file: str | Path | None = None) -> str:
    """Generate documentation for BaseController hooks.

    Args:
        project_root: The root of the project.
        hooks_file: Optional path to the controller file containing hooks.
                    Defaults to the monorepo BaseController.
    """
    if hooks_file:
        controller_file = Path(hooks_file)
    else:
        # Default to monorepo location
        libs_root = project_root / "libs"
        controller_file = (
            libs_root
            / "framework-m-core"
            / "src"
            / "framework_m_core"
            / "domain"
            / "base_controller.py"
        )

    content = """# Controller Lifecycle Hooks\n\n> **Auto-generated from source code** - Do not edit manually.\n\nControllers handle business logic through lifecycle hooks.\nOverride these methods in your controller subclass.\n\n---\n\n## Hook Reference\n\n"""
    if not controller_file.exists():
        return content + f"*Error: source file {controller_file} not found*"

    try:
        tree = ast.parse(controller_file.read_text())
    except SyntaxError:
        return content + "*Error parsing source*"

    for node in ast.walk(tree):
        if isinstance(node, ast.ClassDef):
            if not hooks_file and node.name != "BaseController":
                continue
            content += f"## `{node.name}`\n\n"
            for item in node.body:
                if (
                    isinstance(item, (ast.FunctionDef, ast.AsyncFunctionDef))
                    and not item.name.startswith("_")
                    and item.name != "__init__"
                ):
                    content += f"### `{item.name}`\n\n```python\n{extract_function_signature(item)}\n```\n\n"
                    if doc := extract_docstring(item):
                        content += f"{doc.strip()}\n\n"
                    content += "---\n\n"
    return content
