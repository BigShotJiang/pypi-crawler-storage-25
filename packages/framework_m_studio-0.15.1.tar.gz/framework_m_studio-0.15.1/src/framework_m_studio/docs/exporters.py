"""Exporters for Documentation Generation.

This module provides utilities to export documentation and metadata
to machine-readable formats like JSONL (for RAG) and YAML.
"""

import json
from importlib import import_module
from pathlib import Path

from framework_m_core.cli.utility import console

from framework_m_studio.discovery import doctype_to_dict, scan_doctypes
from framework_m_studio.docs.formatters import generate_doctype_markdown


def export_rag_corpus(
    project_root: Path,
    output_file: Path,
    include_tests: bool = False,
) -> None:
    """Export documentation and source code as a JSONL corpus for RAG/LLM.

    Args:
        project_root: Project root directory.
        output_file: Output file path (.jsonl).
        include_tests: If True, include test files in the corpus.
    """
    corpus = []
    root = project_root  # Ensure root is Path object

    # 1. Export DocTypes
    doctypes = scan_doctypes(root)
    for dt in doctypes:
        dt_dict = doctype_to_dict(dt)

        rel_path = ""
        if dt_dict.get("file_path"):
            try:
                rel_path = str(Path(dt_dict["file_path"]).relative_to(root))
            except (ValueError, AttributeError):
                rel_path = str(dt_dict["file_path"])  # Fallback if not relative

        corpus.append(
            {
                "id": f"doctype-{dt_dict['name'].lower()}",
                "type": "doctype",
                "title": f"DocType: {dt_dict['name']}",
                "content": generate_doctype_markdown(dt_dict, root),
                "metadata": {
                    "module": dt.__module__,
                    "name": dt_dict["name"],
                    "path": str(rel_path),
                },
            }
        )

    # 2. Export Markdown Files (Docs, ADRs, RFCs, Frontend Docs)
    doc_paths = list(project_root.glob("docs/**/*.md"))
    doc_paths.extend(project_root.glob("checklists/*.md"))
    doc_paths.extend(project_root.glob("frontend/docs/**/*.md"))

    for path in doc_paths:
        if path.name == "index.md" or "generated" in str(path):
            continue

        try:
            content = path.read_text()
            rel_path = str(path.relative_to(project_root))
            doc_type = "doc"
            if "adr" in str(rel_path):
                doc_type = "adr"
            elif "rfc" in str(rel_path):
                doc_type = "rfc"
            elif "checklist" in str(rel_path):
                doc_type = "checklist"
            elif "frontend/docs" in str(rel_path):
                doc_type = "frontend-doc"

            corpus.append(
                {
                    "id": f"file-{str(rel_path).replace('/', '-')}",
                    "type": doc_type,
                    "title": f"Document: {rel_path}",
                    "content": content,
                    "metadata": {
                        "path": str(rel_path),
                    },
                }
            )
        except Exception as e:
            console.warning(f"   ⚠️  Failed to read {path}: {e}")

    # 3. Export Tests (Optional)
    if include_tests:
        test_paths = list(project_root.glob("tests/**/*.py"))
        for path in test_paths:
            try:
                content = path.read_text()
                rel_path = str(path.relative_to(project_root))
                corpus.append(
                    {
                        "id": f"test-{str(rel_path).replace('/', '-')}",
                        "type": "test",
                        "title": f"Test: {rel_path}",
                        "content": f"```python\n{content}\n```",
                        "metadata": {
                            "path": str(rel_path),
                        },
                    }
                )
            except Exception as e:
                console.warning(f"   ⚠️  Failed to read {path}: {e}")

    # Write JSONL
    output_file.parent.mkdir(parents=True, exist_ok=True)
    with output_file.open("w") as f:
        for entry in corpus:
            f.write(json.dumps(entry) + "\n")


def export_doctypes_yaml(project_root: Path, output_file: Path) -> None:
    """Export DocTypes as structured YAML."""
    yaml = import_module("yaml")

    doctypes = scan_doctypes(project_root)
    yaml_doctypes = []

    for dt in doctypes:
        dt_dict = doctype_to_dict(dt)
        yaml_dt = {
            "name": dt_dict.get("name"),
            "module": dt_dict.get("module"),
            "description": dt_dict.get("docstring"),
            "source_file": dt_dict.get("file_path"),
            "fields": dt_dict.get("fields", []),
        }

        meta = dt_dict.get("meta", {})
        if "permissions" in meta:
            yaml_dt["permissions"] = meta["permissions"]
        if "hooks" in meta:
            yaml_dt["hooks"] = meta["hooks"]

        yaml_doctypes.append(yaml_dt)

    output_file.parent.mkdir(parents=True, exist_ok=True)
    with output_file.open("w", encoding="utf-8") as f:
        yaml.dump({"doctypes": yaml_doctypes}, f, sort_keys=False)
