"""Markdown Formatters for Documentation Generation.

This module provides utilities to format extracted metadata into Markdown
for the documentation site (e.g., Docusaurus/MkDocs).
"""

import os
from pathlib import Path
from typing import Any


def get_source_file_url(file_path: str, project_root: Path) -> tuple[str, str] | None:
    """Generate a source file URL.

    - In CI, generates a GitLab blob URL.
    - Locally, returns a file:// URL.
    """
    ci_project_url = os.environ.get("CI_PROJECT_URL")
    ci_commit_ref_name = os.environ.get("CI_COMMIT_REF_NAME")
    p_file_path = Path(file_path)
    filename = p_file_path.name

    if ci_project_url and ci_commit_ref_name:
        try:
            relative_path = p_file_path.relative_to(project_root)
            url = f"{ci_project_url}/-/blob/{ci_commit_ref_name}/{relative_path}"
            return filename, url
        except ValueError:
            # file_path is not within project_root
            pass

    # For local runs, return a relative path
    try:
        relative_path = p_file_path.relative_to(project_root)
        return filename, str(relative_path)
    except ValueError:
        # file_path is not within project_root
        return filename, str(p_file_path)


def escape_mdx(text: str) -> str:
    """Escape MDX special characters like braces in text.

    Docusaurus/MDX treats {braces} as JSX expressions. This function
    escapes them using HTML entities so they are rendered as literal text.
    """
    if not text:
        return ""
    return text.replace("{", "&#123;").replace("}", "&#125;")


def format_field_table(fields: list[dict[str, Any]]) -> str:
    """Format fields as a markdown table.

    Args:
        fields: List of field dictionaries.

    Returns:
        Markdown table string.
    """
    if not fields:
        return "_No fields defined._\n"

    lines = [
        "| Field | Type | Required | Description | Validators |",
        "|-------|------|----------|-------------|------------|",
    ]

    for field in fields:
        name = field.get("name", "")
        field_type = field.get("type", "str")
        required = "✓" if field.get("required", True) else ""
        description = escape_mdx(field.get("description", "")) or "-"

        # Format validators
        validators = field.get("validators", {})
        if validators:
            validator_strs = []
            if validators.get("min_value") is not None:
                validator_strs.append(f"min: {validators['min_value']}")
            if validators.get("max_value") is not None:
                validator_strs.append(f"max: {validators['max_value']}")
            if validators.get("min_length") is not None:
                validator_strs.append(f"minLen: {validators['min_length']}")
            if validators.get("max_length") is not None:
                validator_strs.append(f"maxLen: {validators['max_length']}")
            if validators.get("pattern"):
                validator_strs.append(f"pattern: `{validators['pattern']}`")
            validators_str = ", ".join(validator_strs) if validator_strs else "-"
        else:
            validators_str = "-"

        lines.append(
            f"| {name} | {field_type} | {required} | {description} | {validators_str} |"
        )

    return "\n".join(lines) + "\n"


def format_meta_section(meta: dict[str, Any]) -> str:
    """Format Meta configuration as markdown.

    Args:
        meta: Meta configuration dictionary.

    Returns:
        Markdown string.
    """
    if not meta:
        return ""

    lines = ["## Configuration", "", "| Setting | Value |", "|---------|-------|"]

    settings = [
        ("Table Name", meta.get("tablename")),
        ("Naming Pattern", meta.get("name_pattern")),
        ("Submittable", meta.get("is_submittable")),
        ("Track Changes", meta.get("track_changes")),
    ]

    for setting, value in settings:
        if value is not None:
            lines.append(f"| {setting} | `{value}` |")

    if len(lines) > 4:  # Has at least one setting
        lines.append("")
        return "\n".join(lines)
    return ""


def format_permission_matrix(
    permissions: dict[str, list[str]] | None,
) -> str:
    """Format permissions as a role-based matrix table.

    Creates a table where rows are roles and columns are permission types.
    Shows ✓ for granted permissions.

    Args:
        permissions: Dict of permission_type -> list of roles

    Returns:
        Markdown table string.
    """
    if not permissions:
        return "_No permissions defined._\n"

    # Collect all roles and permission types
    all_roles: set[str] = set()
    for roles in permissions.values():
        all_roles.update(roles)

    # Sort for consistent output
    sorted_roles = sorted(all_roles)
    sorted_actions = sorted(permissions.keys())

    # Build header
    header_cols = ["Role"] + [action.capitalize() for action in sorted_actions]
    header = "| " + " | ".join(header_cols) + " |"
    separator = "|" + "|".join(["------"] * len(header_cols)) + "|"

    lines = [header, separator]

    # Build rows for each role
    for role in sorted_roles:
        row = [role]
        for action in sorted_actions:
            has_permission = role in permissions.get(action, [])
            row.append("✓" if has_permission else "")
        lines.append("| " + " | ".join(row) + " |")

    lines.append("")
    return "\n".join(lines)


def generate_doctype_markdown(
    doctype_info: dict[str, Any], project_root: Path | None = None
) -> str:
    """Generate markdown documentation for a DocType.

    Args:
        doctype_info: DocType information dictionary.
        project_root: The root of the project for creating relative paths. Defaults to CWD.

    Returns:
        Markdown string.
    """
    name = doctype_info.get("name", "Unknown")
    docstring = escape_mdx(doctype_info.get("docstring", ""))
    fields = doctype_info.get("fields", [])
    meta = doctype_info.get("meta", {})
    file_path = doctype_info.get("file_path", "")

    lines = [
        f"# {name}",
        "",
    ]

    if docstring:
        lines.extend([docstring, ""])

    # Source file link
    if file_path:
        p_file = Path(file_path)
        try:
            rel_path = p_file.relative_to(project_root or Path.cwd())
        except ValueError:
            rel_path = Path(p_file.name)

        # Ensure we match the expected format for tests while allowing GitLab links for CI
        ci_project_url = os.environ.get("CI_PROJECT_URL")
        if ci_project_url:
            lines.extend(
                [
                    f"**Source**: [{p_file.name}]({ci_project_url}/-/blob/main/{rel_path})",
                    "",
                ]
            )
        else:
            # Avoid relative links to .py files in local builds as they break Docusaurus
            lines.extend([f"**Source**: `{rel_path}`", ""])

    # Fields section
    lines.extend(
        [
            "## Fields",
            "",
            format_field_table(fields),
        ]
    )

    # Permissions section
    permissions = meta.get("permissions") if meta else None
    if permissions:
        lines.extend(
            [
                "## Permissions",
                "",
                format_permission_matrix(permissions),
            ]
        )

    # Meta configuration section
    meta_section = format_meta_section(meta)
    if meta_section:
        lines.append(meta_section)

    # Controller info placeholder
    lines.extend(
        [
            "## Controller",
            "",
            "Controller hooks are implemented in `*_controller.py` files.",
            "Available lifecycle hooks:",
            "",
            "- `validate()` - Called before save, raise exceptions for validation errors",
            "- `before_insert()` - Called before inserting a new document",
            "- `after_insert()` - Called after successfully inserting",
            "- `before_save()` - Called before saving (insert or update)",
            "- `after_save()` - Called after saving",
            "- `before_delete()` - Called before deleting",
            "- `after_delete()` - Called after deleting",
            "",
        ]
    )

    return "\n".join(lines)


def generate_index(doctypes: list[str]) -> str:
    """Generate index.md with links to all DocTypes.

    Args:
        doctypes: List of DocType names.

    Returns:
        Index markdown string.
    """
    lines = [
        "---",
        "sidebar_position: 1",
        "---",
        "",
        "# API Reference",
        "",
        "## DocTypes",
        "",
    ]

    for name in sorted(doctypes):
        filename = name.lower() + ".md"
        lines.append(f"- [{name}]({filename})")

    lines.append("")
    return "\n".join(lines)
