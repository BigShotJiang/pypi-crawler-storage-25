"""Sidebar Config & View Config — Composition Configuration.

Manages which DocTypes appear in which sidebar sections,
and maps DocType fields to standard view slots.

Both configs persist to JSON files for Studio's local storage.
"""

from __future__ import annotations

import json
from pathlib import Path


class SidebarConfig:
    """Manages sidebar section → DocType assignments.

    Stores which DocTypes appear in which sidebar sections,
    with ordering support for drag-and-drop reordering.
    """

    def __init__(self) -> None:
        """Initialize with empty sections."""
        self._sections: dict[str, list[str]] = {}
        self._doctype_section: dict[str, str] = {}

    def register(self, doctype: str, section: str) -> None:
        """Assign a DocType to a sidebar section.

        Args:
            doctype: DocType name (e.g. 'Invoice').
            section: Section name (e.g. 'Accounting').
        """
        if section not in self._sections:
            self._sections[section] = []
        if doctype not in self._sections[section]:
            self._sections[section].append(doctype)
        self._doctype_section[doctype] = section

    def remove(self, doctype: str) -> None:
        """Remove a DocType from its current section.

        Args:
            doctype: DocType name to remove.
        """
        section = self._doctype_section.pop(doctype, None)
        if section and section in self._sections:
            self._sections[section] = [
                d for d in self._sections[section] if d != doctype
            ]

    def reorder(self, section: str, order: list[str]) -> None:
        """Reorder DocTypes within a section.

        Args:
            section: Section name.
            order: New order of DocType names.
        """
        if section in self._sections:
            self._sections[section] = order

    def get_sections(self) -> dict[str, list[str]]:
        """Return all sections with their DocType lists.

        Returns:
            Dict of section_name → list of DocType names.
        """
        return dict(self._sections)

    def to_dict(self) -> dict[str, object]:
        """Serialize to a JSON-compatible dict.

        Returns:
            Dict with 'sections' key.
        """
        return {"sections": self._sections}

    def save(self, path: Path) -> None:
        """Save config to a JSON file.

        Args:
            path: File path to write to.
        """
        path.write_text(json.dumps(self.to_dict(), indent=2))

    @classmethod
    def load(cls, path: Path) -> SidebarConfig:
        """Load config from a JSON file.

        Args:
            path: File path to read from.

        Returns:
            Populated SidebarConfig.
        """
        config = cls()
        data = json.loads(path.read_text())
        for section, doctypes in data.get("sections", {}).items():
            for doctype in doctypes:
                config.register(doctype, section)
        return config


class ViewConfig:
    """Maps DocType fields to standard view slots.

    Each DocType can have field→view mappings like:
    - status → kanban_columns
    - due_date → calendar_start
    - parent_id → tree_parent
    """

    def __init__(self) -> None:
        """Initialize with empty mappings."""
        self._mappings: dict[str, dict[str, str]] = {}

    def map_field(self, doctype: str, field_name: str, view_slot: str) -> None:
        """Map a DocType field to a view slot.

        Args:
            doctype: DocType name.
            field_name: Field name in the DocType.
            view_slot: View slot identifier (e.g. 'kanban_columns').
        """
        if doctype not in self._mappings:
            self._mappings[doctype] = {}
        self._mappings[doctype][view_slot] = field_name

    def get_mappings(self, doctype: str) -> dict[str, str]:
        """Get field→view mappings for a DocType.

        Args:
            doctype: DocType name.

        Returns:
            Dict of view_slot → field_name.
        """
        return dict(self._mappings.get(doctype, {}))

    def to_dict(self) -> dict[str, object]:
        """Serialize to a JSON-compatible dict.

        Returns:
            Dict with 'doctypes' key.
        """
        return {"doctypes": self._mappings}

    def save(self, path: Path) -> None:
        """Save config to a JSON file.

        Args:
            path: File path to write to.
        """
        path.write_text(json.dumps(self.to_dict(), indent=2))

    @classmethod
    def load(cls, path: Path) -> ViewConfig:
        """Load config from a JSON file.

        Args:
            path: File path to read from.

        Returns:
            Populated ViewConfig.
        """
        config = cls()
        data = json.loads(path.read_text())
        for doctype, mappings in data.get("doctypes", {}).items():
            for view_slot, field_name in mappings.items():
                config.map_field(doctype, field_name, view_slot)
        return config
