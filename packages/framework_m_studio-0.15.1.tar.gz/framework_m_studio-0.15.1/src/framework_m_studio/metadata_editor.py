"""Plugin Metadata Editor — CRUD + Validation for ui_meta (§6.1).

Provides a service for manipulating arbitrary ui_meta properties
on DocTypes, with JSON-schema based validation support.
"""

from __future__ import annotations

import copy
import json
from pathlib import Path
from typing import Any


class MetadataEditorService:
    """CRUD service for DocType UI metadata.

    Stores per-DocType ui_meta dicts with deep-merge update,
    JSON-schema validation, and JSON persistence.
    """

    def __init__(self) -> None:
        """Initialize with empty metadata store."""
        self._store: dict[str, dict[str, Any]] = {}

    def get(self, doctype: str) -> dict[str, Any]:
        """Get ui_meta for a DocType.

        Args:
            doctype: DocType name.

        Returns:
            UI metadata dict, or empty dict if not set.
        """
        return copy.deepcopy(self._store.get(doctype, {}))

    def set(self, doctype: str, ui_meta: dict[str, Any]) -> None:
        """Set ui_meta for a DocType (overwrites existing).

        Args:
            doctype: DocType name.
            ui_meta: Full UI metadata dict.
        """
        self._store[doctype] = copy.deepcopy(ui_meta)

    def update(self, doctype: str, partial: dict[str, Any]) -> None:
        """Deep-merge partial ui_meta into existing.

        Args:
            doctype: DocType name.
            partial: Partial UI metadata to merge.
        """
        existing = self._store.get(doctype, {})
        self._store[doctype] = self._deep_merge(existing, partial)

    def delete(self, doctype: str) -> None:
        """Remove ui_meta for a DocType.

        Args:
            doctype: DocType name.
        """
        self._store.pop(doctype, None)

    def list_doctypes(self) -> list[str]:
        """List all DocTypes with stored ui_meta.

        Returns:
            List of DocType names.
        """
        return list(self._store.keys())

    def validate(
        self,
        data: dict[str, Any],
        schema: dict[str, Any],
    ) -> list[str]:
        """Validate ui_meta against a JSON schema.

        Uses a simple built-in validator that checks:
        - Required fields
        - Type constraints (object, string, array, etc.)

        Args:
            data: UI metadata to validate.
            schema: JSON schema dict.

        Returns:
            List of validation error strings. Empty if valid.
        """
        errors: list[str] = []

        # Check required fields
        required = schema.get("required", [])
        for field in required:
            if field not in data:
                errors.append(f"Missing required field: '{field}'")

        # Check type constraints for properties
        properties = schema.get("properties", {})
        for prop_name, prop_schema in properties.items():
            if prop_name in data:
                expected_type = prop_schema.get("type")
                value = data[prop_name]
                if expected_type == "object" and not isinstance(value, dict):
                    errors.append(
                        f"Field '{prop_name}' must be object, got {type(value).__name__}"
                    )
                elif expected_type == "string" and not isinstance(value, str):
                    errors.append(
                        f"Field '{prop_name}' must be string, got {type(value).__name__}"
                    )
                elif expected_type == "array" and not isinstance(value, list):
                    errors.append(
                        f"Field '{prop_name}' must be array, got {type(value).__name__}"
                    )

        return errors

    def save(self, path: Path) -> None:
        """Persist metadata store to a JSON file.

        Args:
            path: File path to write to.
        """
        path.write_text(json.dumps(self._store, indent=2))

    @classmethod
    def load(cls, path: Path) -> MetadataEditorService:
        """Load metadata store from a JSON file.

        Args:
            path: File path to read from.

        Returns:
            Populated MetadataEditorService.
        """
        editor = cls()
        editor._store = json.loads(path.read_text())
        return editor

    def _deep_merge(
        self,
        base: dict[str, Any],
        override: dict[str, Any],
    ) -> dict[str, Any]:
        """Deep-merge override into base."""
        merged = copy.deepcopy(base)
        for key, value in override.items():
            if (
                key in merged
                and isinstance(merged[key], dict)
                and isinstance(value, dict)
            ):
                merged[key] = self._deep_merge(merged[key], value)
            else:
                merged[key] = copy.deepcopy(value)
        return merged
