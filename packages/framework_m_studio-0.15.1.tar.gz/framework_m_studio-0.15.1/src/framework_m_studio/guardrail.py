"""Guardrail — Schema Change Safety Checks for Publishing.

Wraps SchemaDiffEngine to provide a publish-gate that blocks
DANGEROUS changes unless the user explicitly acknowledges them.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from framework_m_studio.schema_diff import SchemaDiffEngine


@dataclass
class GuardrailResult:
    """Result of a guardrail check."""

    changes: list[Any]
    """List of detected schema changes."""

    has_dangerous: bool
    """Whether any DANGEROUS changes were detected."""

    can_publish: bool
    """Whether publishing is allowed (no DANGEROUS changes)."""


class GuardrailChecker:
    """Checks schema changes and classifies publish safety.

    Wraps the SchemaDiffEngine to provide a high-level
    check that returns GuardrailResult.
    """

    def __init__(self) -> None:
        """Initialize with a SchemaDiffEngine."""
        self._engine = SchemaDiffEngine()

    def check(self, old_source: str, new_source: str) -> GuardrailResult:
        """Check schema changes between two DocType versions.

        Args:
            old_source: Python source of the previous version.
            new_source: Python source of the new version.

        Returns:
            GuardrailResult with changes, has_dangerous, and can_publish.
        """
        changes = self._engine.diff(old_source, new_source)

        change_dicts = [
            {
                "field": c.field_name,
                "type": c.change_type,
                "desc": c.description,
            }
            for c in changes
        ]

        has_dangerous = any(c.change_type == "DANGEROUS" for c in changes)

        return GuardrailResult(
            changes=change_dicts,
            has_dangerous=has_dangerous,
            can_publish=not has_dangerous,
        )


class PublishGuard:
    """Gate that allows/blocks publishing based on guardrail results.

    Supports user acknowledgement to override DANGEROUS blocks.
    """

    def allow_publish(
        self,
        result: GuardrailResult,
        acknowledged: bool = False,
    ) -> bool:
        """Determine if publishing should be allowed.

        Args:
            result: GuardrailResult from a check.
            acknowledged: Whether the user has explicitly acknowledged dangers.

        Returns:
            True if publish should proceed.
        """
        if not result.has_dangerous:
            return True
        return acknowledged
