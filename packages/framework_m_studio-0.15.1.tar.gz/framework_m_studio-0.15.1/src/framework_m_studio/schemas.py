"""Studio API Schemas.

Pydantic models for Studio API requests and responses.
"""

from typing import Any

from pydantic import BaseModel


class ValidatorSchema(BaseModel):
    """Validator constraints for a field."""

    min_length: int | None = None
    max_length: int | None = None
    pattern: str | None = None
    min_value: float | None = None
    max_value: float | None = None


class FieldSchema(BaseModel):
    """Field definition for DocType creation/update."""

    name: str
    type: str
    label: str | None = None
    default: str | None = None
    required: bool = True
    description: str | None = None
    hidden: bool = False
    read_only: bool = False
    link_doctype: str | None = None
    table_doctype: str | None = None
    validators: ValidatorSchema | None = None


class DocTypeSchema(BaseModel):
    """DocType schema for creation/update."""

    name: str
    module: str | None = None
    docstring: str | None = None
    fields: list[FieldSchema] = []


class DocTypeListResponse(BaseModel):
    """Response for listing DocTypes."""

    doctypes: list[dict[str, Any]]
    count: int
    project_root: str


class DocTypeResponse(BaseModel):
    """Response for single DocType."""

    name: str
    module: str
    file_path: str
    docstring: str | None
    fields: list[dict[str, Any]]
    meta: dict[str, Any]


class CreateDocTypeRequest(BaseModel):
    """Request body for creating a DocType."""

    name: str
    app: str | None = None
    docstring: str | None = None
    fields: list[FieldSchema] = []
    meta: dict[str, Any] | None = None


class MessageResponse(BaseModel):
    """Generic message response."""

    message: str
    file_path: str | None = None


class GuardrailCheckResponse(BaseModel):
    """Response for guardrail checks."""

    has_dangerous: bool
    can_publish: bool
    changes: list[dict[str, str]]


class PublishRequest(BaseModel):
    """Request body for a publish operation."""

    message: str
    author: str = "studio"
    acknowledged: bool = False
    doctype_payload: CreateDocTypeRequest | None = None


class PublishResponse(BaseModel):
    """Response for publish operations."""

    success: bool
    blocked: bool = False
    adapter_type: str
    branch: str | None = None
    commit_sha: str | None = None
    change_request_url: str | None = None
    error: str | None = None
    guardrail: GuardrailCheckResponse | None = None


class PrintLayoutListResponse(BaseModel):
    """Response for print layout listing."""

    doctype: str
    layouts: list[str]


class PrintLayoutRequest(BaseModel):
    """Request body for saving a print layout."""

    content: str


class PrintLayoutResponse(BaseModel):
    """Response for reading/saving print layout files."""

    doctype: str
    template_name: str
    content: str


class PrintPreviewRequest(BaseModel):
    """Request body for previewing a print template."""

    doctype: str
    template_name: str
    data: dict[str, Any] = {}


class PrintPreviewResponse(BaseModel):
    """Response for print preview rendering."""

    success: bool
    html: str = ""
    error: str | None = None


class HotSwapStatusResponse(BaseModel):
    watching: bool
    repo_path: str
    updates_received: int
    last_update_at: str | None = None


class HotSwapSyncResponse(BaseModel):
    success: bool
    message: str
    updates_received: int


class AggregateLinkSchema(BaseModel):
    doctype: str
    link_field: str
    cascade: str = "save_delete"


class AggregateConfigRequest(BaseModel):
    linked: list[AggregateLinkSchema] = []


class AggregateConfigResponse(BaseModel):
    root: str
    linked: list[AggregateLinkSchema]


class AggregateRootsResponse(BaseModel):
    roots: list[str]


class ActionButtonSchema(BaseModel):
    id: str
    label: str
    action: str
    target: str
    icon: str | None = None
    roles: list[str] = []


class SidebarAppSchema(BaseModel):
    id: str
    label: str
    icon: str
    route: str
    roles: list[str] = []


class SearchProviderSchema(BaseModel):
    id: str
    label: str
    handler: str
    roles: list[str] = []


class ShellConfigRequest(BaseModel):
    action_buttons: list[ActionButtonSchema] = []
    sidebar_apps: list[SidebarAppSchema] = []
    search_providers: list[SearchProviderSchema] = []


class ShellConfigResponse(BaseModel):
    action_buttons: list[ActionButtonSchema]
    sidebar_apps: list[SidebarAppSchema]
    search_providers: list[SearchProviderSchema]


class RoleDefSchema(BaseModel):
    """Wire format for a design-time role."""

    name: str
    description: str | None = None


class RoleListResponse(BaseModel):
    """Response payload for design-time roles list."""

    roles: list[RoleDefSchema]
