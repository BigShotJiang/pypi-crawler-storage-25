"""Print Repo Adapter — Git-Backed Print Layouts (§4.3).

Manages Jinja2 print templates in a separate Git repository.
Supports saving, listing, previewing with sample data,
and hot-swapping templates without redeploying.
"""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from framework_m_studio.git.protocol import GitAdapterProtocol


@dataclass
class PrintPreviewResult:
    """Result of a print template preview render."""

    success: bool
    """Whether the preview rendered successfully."""

    html: str = ""
    """Rendered HTML content."""

    error: str | None = None
    """Error message if render failed."""


class PrintRepoAdapter:
    """Adapter for managing print templates in a Git repository.

    Templates are organized as:
        <print_repo>/
        ├── Invoice/
        │   ├── standard.html
        │   └── compact.html
        └── PurchaseOrder/
            └── default.html
    """

    def __init__(
        self,
        git_adapter: GitAdapterProtocol,
        print_repo_path: Path,
    ) -> None:
        """Initialize PrintRepoAdapter.

        Args:
            git_adapter: Git adapter for commit/push operations.
            print_repo_path: Local path to the Print repo.
        """
        self._git = git_adapter
        self._repo_path = print_repo_path

    async def save_layout(
        self,
        doctype: str,
        template_name: str,
        content: str,
    ) -> None:
        """Save a print template to the Print Repo.

        Args:
            doctype: DocType name (used as directory).
            template_name: Template name (without extension).
            content: Jinja2 template content.
        """
        dt_dir = self._repo_path / doctype
        dt_dir.mkdir(parents=True, exist_ok=True)

        template_file = dt_dir / f"{template_name}.html"
        template_file.write_text(content)

    def list_layouts(self, doctype: str) -> list[str]:
        """List available print templates for a DocType.

        Args:
            doctype: DocType name.

        Returns:
            List of template names (without .html extension).
        """
        dt_dir = self._repo_path / doctype
        if not dt_dir.exists():
            return []

        return [f.stem for f in dt_dir.iterdir() if f.is_file() and f.suffix == ".html"]

    async def preview_with_sample(
        self,
        doctype: str,
        template_name: str,
        data: dict[str, Any],
    ) -> PrintPreviewResult:
        """Render a print template with sample data.

        Uses basic Jinja2 rendering (no Framework M runtime needed).

        Args:
            doctype: DocType name.
            template_name: Template name.
            data: Sample data dict (accessible as ``doc`` in template).

        Returns:
            PrintPreviewResult with rendered HTML or error.
        """
        template_file = self._repo_path / doctype / f"{template_name}.html"

        if not template_file.exists():
            return PrintPreviewResult(
                success=False,
                error=f"Template '{template_name}' not found for DocType '{doctype}'.",
            )

        try:
            from jinja2 import Template

            template_str = template_file.read_text()
            template = Template(template_str)
            html = template.render(doc=data)

            return PrintPreviewResult(success=True, html=html)
        except ImportError:
            # Fallback if Jinja2 is not installed: basic string replacement
            template_str = template_file.read_text()
            for key, value in data.items():
                template_str = template_str.replace(f"{{{{ doc.{key} }}}}", str(value))
            return PrintPreviewResult(success=True, html=template_str)
        except Exception as exc:
            return PrintPreviewResult(
                success=False,
                error=f"Render error: {exc}",
            )


class HotSwapMonitor:
    """Monitors a Print Repo for changes to enable hot-swapping.

    In production, this would use a K8s sidecar or GitOps controller.
    This class provides the protocol and callback registration.
    """

    def __init__(self, repo_path: Path) -> None:
        """Initialize HotSwapMonitor.

        Args:
            repo_path: Path to the Print Repo.
        """
        self.repo_path = repo_path
        self._watching = False
        self._callbacks: list[Callable[[], None]] = []

    @property
    def is_watching(self) -> bool:
        """Whether the monitor is actively watching."""
        return self._watching

    def start(self) -> None:
        """Start watching the Print Repo for changes."""
        self._watching = True

    def stop(self) -> None:
        """Stop watching the Print Repo."""
        self._watching = False

    def on_update(self, callback: Callable[[], None]) -> None:
        """Register a callback for Print Repo updates.

        Args:
            callback: Function called when templates change.
        """
        self._callbacks.append(callback)

    def notify(self) -> None:
        """Notify all callbacks that templates have been updated."""
        for callback in self._callbacks:
            callback()
