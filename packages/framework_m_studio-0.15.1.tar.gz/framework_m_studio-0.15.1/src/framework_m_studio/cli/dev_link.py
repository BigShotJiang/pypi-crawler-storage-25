"""Dev Link CLI Command - Modular SRP Implementation."""

from __future__ import annotations

import json
import os
import platform
import subprocess
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Annotated, Protocol

import cyclopts
from framework_m_core.cli.utility import CLIConsole

from framework_m_studio.dev_config import load_m_toml

console = CLIConsole()


@dataclass
class Package:
    """Represents a framework-m package (Python or JS)."""

    name: str
    path: Path
    is_js: bool = False


@dataclass
class DevLinkConfig:
    """Configuration for the dev-link operation."""

    framework_path: Path
    include: list[str] = field(default_factory=list)
    exclude: list[str] = field(default_factory=list)
    dry_run: bool = False


class DiscoveryProtocol(Protocol):
    """Protocol for discovering packages in the framework-m repo."""

    def find_python_packages(self, config: DevLinkConfig) -> list[Package]:
        """Find Python packages in libs/ and apps/."""
        ...

    def find_js_packages(self, config: DevLinkConfig) -> list[Package]:
        """Find JS packages in libs/."""
        ...

    def find_node_modules(self, target_path: Path) -> list[Path]:
        """Find all node_modules directories in the target path."""
        ...


class LinkingProtocol(Protocol):
    """Protocol for linking packages into the current environment."""

    def link_python(self, pkg: Package, dry_run: bool) -> bool:
        """Link a Python package via editable install."""
        ...

    def link_js(self, pkg: Package, dest: Path, dry_run: bool) -> bool:
        """Link a JS package via symlink or junction."""
        ...


class PackageDiscovery:
    """Implementation of package discovery for framework-m."""

    def _should_include(self, name: str, config: DevLinkConfig) -> bool:
        """Check if a package should be included based on config."""
        if name in config.exclude:
            return False
        return not (config.include and name not in config.include)

    def find_python_packages(self, config: DevLinkConfig) -> list[Package]:
        """Find Python packages in libs/ and apps/."""
        packages = []
        for sdir in ["libs", "apps"]:
            dpath = config.framework_path / sdir
            if dpath.exists():
                for pdir in dpath.iterdir():
                    if (
                        pdir.is_dir()
                        and (pdir / "pyproject.toml").exists()
                        and self._should_include(pdir.name, config)
                    ):
                        packages.append(Package(name=pdir.name, path=pdir))
        return packages

    def find_js_packages(self, config: DevLinkConfig) -> list[Package]:
        """Find JS packages in libs/."""
        packages = []
        libs = config.framework_path / "libs"
        if libs.exists():
            for pdir in libs.iterdir():
                pjson = pdir / "package.json"
                if pdir.is_dir() and pjson.exists():
                    try:
                        data = json.loads(pjson.read_text())
                        name = data.get("name", "")
                        if name.startswith("@framework-m/") and not data.get(
                            "private", False
                        ):
                            short = name.split("/")[-1]
                            if self._should_include(
                                short, config
                            ) and self._should_include(name, config):
                                packages.append(
                                    Package(name=name, path=pdir, is_js=True)
                                )
                    except (json.JSONDecodeError, OSError):
                        continue
        return packages

    def find_node_modules(self, target_path: Path) -> list[Path]:
        """Find all node_modules directories in the target path, ignoring common excludes."""
        nm_dirs = []
        root_nm = target_path / "node_modules"
        if root_nm.exists():
            nm_dirs.append(root_nm)
        for p in target_path.rglob("package.json"):
            if any(part in p.parts for part in ["node_modules", ".venv", ".git"]):
                continue
            nm = p.parent / "node_modules"
            if nm.exists() and nm not in nm_dirs:
                nm_dirs.append(nm)
        return nm_dirs


class PackageLinker:
    """Implementation of OS-specific package linking."""

    def _get_python_path(self) -> str:
        """Find the correct python executable for the current environment."""
        curr = Path.cwd()
        while curr != curr.parent:
            if (curr / ".venv").exists():
                v = curr / ".venv"
                if platform.system() == "Windows":
                    return str(v / "Scripts" / "python.exe")
                return str(v / "bin" / "python")
            curr = curr.parent
        return sys.executable

    def link_python(self, pkg: Package, dry_run: bool) -> bool:
        """Perform editable install of a Python package."""
        if dry_run:
            console.info(f"[Dry Run] Link Python: {pkg.name}")
            return True
        console.info(f"🐍 Python: {pkg.name}")
        try:
            subprocess.run(
                [
                    "uv",
                    "pip",
                    "install",
                    "--python",
                    self._get_python_path(),
                    "--editable",
                    str(pkg.path),
                    "--no-deps",
                ],
                check=True,
                capture_output=False,
            )
            return True
        except subprocess.CalledProcessError:
            console.error(f"Failed: {pkg.name}")
            return False

    def link_js(self, pkg: Package, dest: Path, dry_run: bool) -> bool:
        """Create a symlink or directory junction for a JS package."""
        if dry_run:
            console.info(f"[Dry Run] Link JS: {pkg.name} -> {dest}")
            return True
        dest.parent.mkdir(parents=True, exist_ok=True)
        if dest.is_symlink() or dest.exists():
            if dest.is_symlink():
                dest.unlink(missing_ok=True)
            else:
                import shutil

                shutil.rmtree(dest, ignore_errors=True)
        try:
            dest.symlink_to(pkg.path, target_is_directory=True)
            console.info(f"🔗 JS: {dest.name}")
            return True
        except OSError:
            if platform.system() == "Windows":
                try:
                    subprocess.run(
                        ["cmd", "/c", "mklink", "/J", str(dest), str(pkg.path)],
                        check=True,
                        capture_output=True,
                    )
                    console.info(f"🔗 JS: {dest.name} (Junction)")
                    return True
                except subprocess.CalledProcessError:
                    console.error(f"Failed Junction: {dest.name}")
            else:
                console.error(f"Failed Link: {dest.name}")
            return False


class DevLinkOrchestrator:
    """Orchestrates the discovery and linking process."""

    def __init__(self, discovery: DiscoveryProtocol, linker: LinkingProtocol):
        self.discovery = discovery
        self.linker = linker

    def run(self, config: DevLinkConfig) -> None:
        """Execute the dev-link workflow."""
        console.success(f"🚀 Linking to framework-m at {config.framework_path}")
        for pkg in self.discovery.find_python_packages(config):
            self.linker.link_python(pkg, config.dry_run)

        js_pkgs = self.discovery.find_js_packages(config)
        if js_pkgs:
            for nm in self.discovery.find_node_modules(Path.cwd()):
                for pkg in js_pkgs:
                    self.linker.link_js(pkg, nm / pkg.name, config.dry_run)
        console.success("\n✅ Dev linking complete!")


dev_link_app = cyclopts.App(
    name="dev-link", help="Link local framework-m source into the current project"
)


@dev_link_app.default
def dev_link_command(
    path: Annotated[
        str | None,
        cyclopts.Parameter(name=["--path", "-p"], help="Path to framework-m repo"),
    ] = None,
    dry_run: Annotated[
        bool, cyclopts.Parameter(name="--dry-run", help="Show what would be done")
    ] = False,
) -> None:
    """Link local framework-m source into the current project."""
    _dev_link_internal(path, dry_run)


def _dev_link_internal(
    framework_path: str | None = None, dry_run: bool = False
) -> None:
    """Core logic for linking local framework-m source."""
    raw_path = framework_path or os.environ.get("FRAMEWORK_M_PATH")
    if not raw_path:
        console.error("❌ Error: Framework path not found.")
        sys.exit(1)
        return

    f_path = Path(raw_path).resolve()
    if not (f_path / "pnpm-workspace.yaml").exists():
        console.error(f"❌ Error: {f_path} is not a valid framework-m repo.")
        sys.exit(1)
        return

    toml = load_m_toml().get("dev-link", {})
    inc = (
        os.environ.get("FRAMEWORK_M_LINK_INCLUDE", "").split(",")
        if os.environ.get("FRAMEWORK_M_LINK_INCLUDE")
        else toml.get("include", [])
    )
    exc = (
        os.environ.get("FRAMEWORK_M_LINK_EXCLUDE", "").split(",")
        if os.environ.get("FRAMEWORK_M_LINK_EXCLUDE")
        else toml.get("exclude", ["framework-mx-mongo"])
    )

    config = DevLinkConfig(
        framework_path=f_path,
        include=[i.strip() for i in inc if i.strip()],
        exclude=[i.strip() for i in exc if i.strip()],
        dry_run=dry_run,
    )

    orchestrator = DevLinkOrchestrator(PackageDiscovery(), PackageLinker())
    orchestrator.run(config)
