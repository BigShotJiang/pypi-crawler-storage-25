import json
import re
from pathlib import Path

from .models import ReleaseConfig, ReleaseUpdate
from .versioning import _bump_version


class DependencyGraph:
    """Discovers and manages dependencies between monorepo packages."""

    def __init__(self, config: ReleaseConfig, root: Path) -> None:
        self.config = config
        self.root = root
        self.packages = {pkg.name: pkg for pkg in config.packages}
        # Adjacency list: dependency -> [dependents]
        self.adj: dict[str, set[str]] = {pkg.name: set() for pkg in config.packages}

        # Mapping of publish_name to internal name
        self.publish_to_internal = {
            pkg.publish_name or pkg.name: pkg.name for pkg in config.packages
        }

    def add_edge(self, dependency: str, dependent: str) -> None:
        """Manually add a dependency edge."""
        if dependency in self.adj and dependent in self.adj:
            self.adj[dependency].add(dependent)

    def get_dependents(self, pkg_name: str) -> list[str]:
        """Get all direct dependents of a package."""
        return sorted(self.adj.get(pkg_name, []))

    def discover_manifest_deps(self) -> None:
        """Scan pyproject.toml and package.json for production internal dependencies."""
        for pkg in self.config.packages:
            v_file = self.root / pkg.version_file
            if not v_file.exists():
                continue

            content = v_file.read_text()
            search_space = ""

            # 1. Filter the search space based on file type to avoid "ghost" links
            # 1. Filter the search space based on file type to avoid "ghost" links
            if v_file.suffix == ".toml":
                # STRIP out known non-runtime sections to prevent "dev-only" ripples
                # We remove [dependency-groups] and [tool.uv.sources] but KEEP the rest
                search_space = re.sub(
                    r"^\[(?:dependency-groups|tool\.uv\.sources)\].*?(?=\n\[|$)",
                    "",
                    content,
                    flags=re.DOTALL | re.MULTILINE,
                )
            else:
                # For JSON, we only care about dependencies and peerDependencies
                try:
                    data = json.loads(content)
                    deps = data.get("dependencies", {})
                    peer_deps = data.get("peerDependencies", {})
                    # Stringify only these sections for the regex scanner
                    search_space = json.dumps(deps) + json.dumps(peer_deps)
                except Exception:
                    # Fallback to empty if JSON is malformed
                    search_space = ""

            if not search_space:
                continue

            # 2. Scan the filtered search space for internal packages
            for internal_name, p in self.packages.items():
                if internal_name == pkg.name:
                    continue

                names_to_check = set(filter(None, [internal_name, p.publish_name]))

                for name in names_to_check:
                    # Match name in quotes with optional version specifiers
                    pattern = rf'["\']{re.escape(name)}(?:[>=^~@\s].*?)?["\']'
                    if re.search(pattern, search_space):
                        self.add_edge(internal_name, pkg.name)
                        break

    def discover_sync_deps(self) -> None:
        """Scan release-config.json sync rules for implicit build-time dependencies."""
        for s in self.config.sync:
            dependency = s.package_name
            if dependency not in self.packages:
                continue

            sync_file_path = s.file
            target_pkg = None

            # Find which package owns the sync target
            # A package owns it if its 'paths' contains the base of the sync file path
            for pkg in self.config.packages:
                for p_path in pkg.paths:
                    # Normalize paths for comparison
                    norm_sync = Path(sync_file_path).parts
                    norm_pkg = Path(p_path).parts
                    if norm_sync[: len(norm_pkg)] == norm_pkg:
                        target_pkg = pkg.name
                        break
                if target_pkg:
                    break

            if target_pkg and target_pkg != dependency:
                self.add_edge(dependency, target_pkg)

    def calculate_updates(
        self, initial_updates: list[ReleaseUpdate]
    ) -> list[ReleaseUpdate]:
        """Propagate bumps downstream through the dependency graph."""
        updates_map = {u.component: u for u in initial_updates}
        queue = [u.component for u in initial_updates]
        visited = set(queue)

        while queue:
            curr = queue.pop(0)
            dependents = self.get_dependents(curr)

            for dep_name in dependents:
                if dep_name in visited:
                    continue

                pkg = self.packages[dep_name]
                v_file = self.root / pkg.version_file
                current_v = self._read_version(v_file)
                new_v = _bump_version(current_v, "patch")

                updates_map[dep_name] = ReleaseUpdate(
                    component=dep_name,
                    component_path=str(
                        v_file.parent.relative_to(self.root)
                        if v_file.parent.is_absolute()
                        else v_file.parent
                    ),
                    version_file=str(pkg.version_file),
                    current_version=current_v,
                    new_version=new_v,
                    bump="patch",
                    changelog=f"**{dep_name}** v{new_v}: internal dependency bump due to **{curr}** update",
                )

                visited.add(dep_name)
                queue.append(dep_name)

        return list(updates_map.values())

    def _read_version(self, v_file: Path) -> str:
        """Helper to read version from TOML or JSON."""
        if not v_file.exists():
            return "0.1.0"
        content = v_file.read_text()
        if v_file.suffix == ".toml":
            match = re.search(r'^version\s*=\s*"([^"]+)"', content, re.MULTILINE)
            return match.group(1) if match else "0.1.0"
        else:
            try:
                data = json.loads(content)
                return str(data.get("version", "0.1.0"))
            except Exception:
                return "0.1.0"
