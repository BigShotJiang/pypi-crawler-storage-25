import json
import os
import re
import shutil
import subprocess
from pathlib import Path

from framework_m_core.cli.utility import CLIConsole

from framework_m_studio.core.shell import run_cmd

from .gitops import (
    GitLabProvider as GitLabProvider,
)
from .gitops import (
    GitProviderProtocol as GitProviderProtocol,
)
from .gitops import (
    _get_commits_since as _get_commits_since,
)
from .gitops import (
    _get_last_tag as _get_last_tag,
)
from .gitops import (
    push_release_branch as push_release_branch,
)
from .graph import DependencyGraph
from .models import Commit, ReleaseConfig, ReleasePackage, ReleaseUpdate
from .versioning import (
    _bump_version,
    _generate_changelog,
    _pin_inter_package_dependencies,
    _prepend_changelog,
    _update_file_version,
)


def _load_release_config(
    config_path: str = "release-config.json", root: Path | None = None
) -> ReleaseConfig:
    """Load release configuration from a JSON file."""
    path = Path(config_path)
    if not path.is_absolute():
        base = root if root else Path.cwd()
        path = base / config_path

    with path.open() as f:
        data = json.load(f)
    if "packages" in data:
        for pkg in data["packages"]:
            if "path" in pkg and "paths" not in pkg:
                pkg["paths"] = [pkg["path"]]
    return ReleaseConfig.model_validate(data)


def _determine_version_bump(commits: list[Commit]) -> str | None:
    """Decide version bump level based on commit types."""
    bump = None
    for commit in commits:
        if commit.breaking:
            return "major"
        if commit.type == "feat":
            bump = "minor"
        elif commit.type == "fix" and bump is None:
            bump = "patch"
    return bump


def _filter_component_commits(
    commits: list[Commit], pkg: ReleasePackage
) -> list[Commit]:
    """Filter commits relevant to a specific package."""
    component_commits = []
    for commit in commits:
        if commit.body_tags:
            if "*" in commit.body_tags:
                is_match = True
            else:
                is_match = (
                    (pkg.name in commit.body_tags)
                    or (pkg.publish_name and pkg.publish_name in commit.body_tags)
                    or (commit.scope in pkg.scopes)
                )
        else:
            is_match = (pkg.include_global and not commit.scope) or (
                commit.scope in pkg.scopes
            )

        if is_match:
            component_commits.append(commit)
    return component_commits


def compute_release_plan(config: ReleaseConfig, root: Path) -> list[ReleaseUpdate]:
    """Analyze git history to decide what needs a new release."""
    release_updates = {}
    for pkg in config.packages:
        last_tag = _get_last_tag(pkg.name)
        commits = _get_commits_since(last_tag)
        component_commits = _filter_component_commits(commits, pkg)

        bump = _determine_version_bump(component_commits)
        if not bump:
            continue

        v_file = root / pkg.version_file
        content = v_file.read_text()
        if v_file.suffix == ".toml":
            v_match = re.search(r'^version\s*=\s*"([^"]+)"', content, re.MULTILINE)
            file_v = v_match.group(1) if v_match else "0.1.0"
        else:
            file_v = str(json.loads(content).get("version", "0.1.0"))

        current_v = file_v
        if last_tag and "@v" in last_tag:
            tag_v = last_tag.split("@v")[-1]
            try:
                if tag_v > file_v:
                    current_v = tag_v
            except Exception:  # pragma: no cover
                pass  # pragma: no cover

        new_v = _bump_version(current_v, bump)
        changelog = _generate_changelog(component_commits, new_v, pkg.name)
        release_updates[pkg.name] = ReleaseUpdate(
            component=pkg.name,
            component_path=str(v_file.parent.relative_to(root)),
            version_file=str(pkg.version_file),
            current_version=current_v,
            new_version=new_v,
            bump=bump,
            changelog=changelog,
        )

    # 1. Propagate bumps downstream through the dependency graph
    if not release_updates:
        return []  # pragma: no cover

    graph = DependencyGraph(config, root)
    graph.discover_manifest_deps()
    graph.discover_sync_deps()

    full_plan = graph.calculate_updates(list(release_updates.values()))
    return full_plan


def prepare_release(
    updates: list[ReleaseUpdate],
    branch: str,
    root: Path,
    config: ReleaseConfig,
    sbom: bool = False,
) -> None:
    """Modify files in the working directory for a release branch."""
    if sbom:
        syft_bin = shutil.which("syft")
        if not syft_bin:
            CLIConsole().warning("'syft' not found, skipping SBOM.")  # pragma: no cover
            sbom = False
        else:
            try:
                run_cmd(f"syft scan dir:{root} -o json > {root}/sbom.json")
            except Exception:  # pragma: no cover
                CLIConsole().warning("syft failed, skipping SBOM.")
                sbom = False

    for update in updates:
        _update_file_version(str(root / update.version_file), update.new_version)
        changelog_path = Path(root / update.component_path) / "CHANGELOG.md"
        _prepend_changelog(str(changelog_path), update.changelog)

    for pkg in config.packages:
        v_file = root / pkg.version_file
        if v_file.exists():
            _pin_inter_package_dependencies(str(v_file), updates, config)

    for s in config.sync:
        sync_files = list(root.glob(s.file)) if "*" in s.file else [root / s.file]
        for target_file in sync_files:
            if not target_file.exists() or target_file.is_dir():
                continue

            # 1. Use robust format-aware pinner for JSON/TOML dependencies and templates
            _pin_inter_package_dependencies(str(target_file), updates, config)

            # 2. Use explicit pattern only as a fallback for custom text files or specific regex overrides
            if s.pattern:
                u = next((up for up in updates if up.component == s.package_name), None)
                if not u:
                    continue
                content = target_file.read_text()

                # Use re.sub to ensure all occurrences are updated
                def _repl(m: re.Match[str], u_val: ReleaseUpdate | None = u) -> str:
                    if not u_val:
                        return m.group(0)
                    target = m.group(1) if len(m.groups()) > 0 else m.group(0)
                    return m.group(0).replace(target, u_val.new_version)

                new_content = re.sub(s.pattern, _repl, content)
                if new_content != content:
                    target_file.write_text(new_content)

    # 3. Synchronize lockfiles for diverse environments
    from .lockfile_sync import sync_lockfiles

    sync_lockfiles(root)


async def create_or_update_mr(
    branch: str,
    target_branch: str,
    title: str,
    desc: str,
    provider: GitProviderProtocol,
) -> None:
    """Interact with the Git provider to create/update Merge Requests."""
    existing_mr = await provider.find_mr(branch)
    if existing_mr:
        CLIConsole().info(f"🔄 Updating existing MR !{existing_mr.get('iid', '?')}")
        await provider.update_mr(existing_mr["iid"], title, desc)
    else:
        CLIConsole().info("✨ Creating new MR")
        await provider.create_mr(title, desc, branch, target_branch)


async def tag_and_release(
    config: ReleaseConfig,
    root: Path,
    provider: GitProviderProtocol | None,
    dry_run: bool = False,
) -> None:
    """Tag newly released versions and orchestrate platform releases."""
    for pkg in config.packages:
        v_file = root / pkg.version_file
        if not v_file.exists():
            continue
        content = v_file.read_text()
        if v_file.suffix == ".toml":
            match = re.search(r'^version\s*=\s*"([^"]+)"', content, re.MULTILINE)
            v = match.group(1) if match else "0.1.0"
        else:
            v = json.loads(content).get("version", "0.1.0")

        tag_name = f"{pkg.name}@v{v}"
        last_tag = _get_last_tag(pkg.name)
        if last_tag != tag_name:
            commits = _get_commits_since(last_tag)
            component_commits = _filter_component_commits(commits, pkg)

            if component_commits:
                changelog = _generate_changelog(component_commits, v, pkg.name)
            else:
                # Sync/Internal release: ensure it still lands the tag Promised in the MR
                changelog = f"## 📦 {pkg.name} v{v}\n\n- Internal dependency synchronization release."

            if not dry_run:
                CLIConsole().info(f"🏷️  Tagging {tag_name}")
                run_cmd(f'git tag -a {tag_name} -m "Release {v}"')
                run_cmd(f"git push origin {tag_name}")
                if provider:
                    await provider.create_release(tag_name, changelog)
            else:
                CLIConsole().info(f"[DRY RUN] Would create and push tag: {tag_name}")


def _stage_release_files(
    root: Path, config: ReleaseConfig, updates: list[ReleaseUpdate]
) -> None:
    """Stage version files, changelogs, lockfiles, and SBOM for the release commit."""
    files_to_add: list[str] = []

    # 1. Always add version files for ALL packages to capture sync/pin updates
    for pkg in config.packages:
        if (root / pkg.version_file).exists():
            files_to_add.append(pkg.version_file)

    # 2. Add CHANGELOG.md for packages that actually bumped
    for u in updates:
        changelog_path = str(Path(u.component_path) / "CHANGELOG.md")
        if (root / changelog_path).exists():
            files_to_add.append(changelog_path)

    # 3. Add synchronized templates
    for s in config.sync:
        sync_files = list(root.glob(s.file)) if "*" in s.file else [root / s.file]
        for f_path in sync_files:
            if f_path.is_file():
                files_to_add.append(str(f_path.relative_to(root)))

    # 4. Add lockfiles and SBOM if they exist
    for lock_f in ["pnpm-lock.yaml", "uv.lock", "sbom.json"]:
        if (root / lock_f).exists():
            files_to_add.append(lock_f)

    # 4. Finalize staging with relative paths and ignore-filtering
    if files_to_add:
        valid_files = []
        for f_str in sorted(set(files_to_add)):
            p = Path(f_str)
            rel_f = str(p.relative_to(root) if p.is_absolute() else p)
            if (root / rel_f).exists():
                # check-ignore returns exit 0 if ignored, we only add if NOT ignored
                res = subprocess.run(
                    ["git", "check-ignore", "-q", rel_f], cwd=root, capture_output=True
                )
                if res.returncode != 0:
                    # exit non-zero means NOT ignored
                    valid_files.append(rel_f)

        if valid_files:
            run_cmd(["git", "add", *valid_files])


async def run_release_orchestration(
    provider: str, token: str, project_id: str, dry_run: bool = False
) -> None:
    """Run the full automated release workflow (Plan -> Prepare -> MR)."""
    if provider != "gitlab":
        CLIConsole().error(f"Provider '{provider}' not yet supported.")
        raise SystemExit(1)
    root = Path.cwd()
    run_cmd("git fetch --tags --force", check=False)
    config = _load_release_config()
    updates = compute_release_plan(config, root)
    if not updates:
        CLIConsole().success("✅ No releases needed.")
        return
    for u in updates:
        CLIConsole().info(
            f"🚀 {u.component}: {u.current_version} -> {u.new_version} ({u.bump})"
        )

    # 0. Configure Git identity for the runner (only in CI)
    if os.environ.get("CI"):
        CLIConsole().info("👤 Configuring Git identity...")
        email = os.environ.get("GITLAB_USER_EMAIL", "release-orchestrator@gitlab.com")
        name = os.environ.get("GITLAB_USER_NAME", "Framework M CI Bot")
        run_cmd(["git", "config", "user.email", email], check=False)
        run_cmd(["git", "config", "user.name", name], check=False)

    branch = config.release_branch
    CLIConsole().info(f"📦 Preparing release branch: {branch}...")
    run_cmd(["git", "checkout", "-B", branch])

    prepare_release(updates, branch, root, config, sbom=config.enable_sbom)
    _stage_release_files(root, config, updates)

    if dry_run:
        CLIConsole().info(
            f"✅ Dry run verification complete. Files prepared and staged in local branch '{branch}'."
        )
        CLIConsole().info(
            "💡 You can inspect changes with 'git diff --cached' and discard them with 'git checkout main'."
        )
        return

    if run_cmd(["git", "status", "--porcelain"]).strip():
        run_cmd(
            ["git", "commit", "-m", "chore(release): automated multi-package release"]
        )
    else:
        CLIConsole().warning("No changes to commit for the release branch.")

    if not token:
        raise ValueError(
            "No Git token found. Please set CITADEL_CI_TOKEN or GITLAB_TOKEN environment variable."
        )
    project_path = os.environ.get("CI_PROJECT_PATH", "")
    host = os.environ.get("CI_SERVER_HOST", "gitlab.com")
    push_release_branch(branch, host, project_path, token)
    provider_cls = GitLabProvider(token, project_id)
    # 1. Structure the description with a clean hierarchy
    primary_updates = [
        u for u in updates if "internal dependency bump" not in u.changelog
    ]
    internal_updates = [u for u in updates if "internal dependency bump" in u.changelog]

    sections = ["## 🚀 Automated Release"]

    # 2. List primary package updates with their full changelogs
    for u in primary_updates:
        # Extract version from changelog or use new_version
        v_header = f"### 📦 {u.component} v{u.new_version}"
        sections.append(f"{v_header}\n{u.changelog}")

    # 3. Group all automated internal bumps under one clean section
    if internal_updates:
        sections.append("### ⚙️ Internal Adjustments")
        adj_list = "\n".join([f"- {u.changelog}" for u in internal_updates])
        sections.append(adj_list)

    title = "chore(release): automated multi-package release"
    desc = "\n\n".join(sections)
    await create_or_update_mr(branch, config.target_branch, title, desc, provider_cls)
