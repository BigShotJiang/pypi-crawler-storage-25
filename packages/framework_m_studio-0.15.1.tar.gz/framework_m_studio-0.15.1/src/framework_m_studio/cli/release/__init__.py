"""Release orchestration package.
This module provides a unified namespace for automated releases,
re-exporting specialized submodules while ensuring compatibility
with the existing test suite's mocks.
"""

from __future__ import annotations

from framework_m_studio.core.shell import run_cmd

from .cli import (
    release_app,
    release_auto_command,
    release_mr_command,
    release_plan_command,
    release_prepare_command,
    release_push_command,
    release_schema_command,
    release_tag_command,
)
from .gitops import (
    GitLabProvider,
    GitProviderProtocol,
    _get_commits_since,
    _get_last_tag,
    push_release_branch,
)
from .models import Commit, ReleaseConfig, ReleasePackage, ReleaseSync, ReleaseUpdate
from .orchestrator import (
    _determine_version_bump,
    _load_release_config,
    compute_release_plan,
    create_or_update_mr,
    prepare_release,
    run_release_orchestration,
    tag_and_release,
)
from .versioning import (
    _bump_version,
    _pin_inter_package_dependencies,
    _prepend_changelog,
    _update_file_version,
)

__all__ = [
    "Commit",
    "GitLabProvider",
    "GitProviderProtocol",
    "ReleaseConfig",
    "ReleasePackage",
    "ReleaseSync",
    "ReleaseUpdate",
    "_bump_version",
    "_determine_version_bump",
    "_get_commits_since",
    "_get_last_tag",
    "_load_release_config",
    "_pin_inter_package_dependencies",
    "_prepend_changelog",
    "_update_file_version",
    "compute_release_plan",
    "create_or_update_mr",
    "prepare_release",
    "push_release_branch",
    "release_app",
    "release_auto_command",
    "release_mr_command",
    "release_plan_command",
    "release_prepare_command",
    "release_push_command",
    "release_schema_command",
    "release_tag_command",
    "run_cmd",
    "run_release_orchestration",
    "tag_and_release",
]
