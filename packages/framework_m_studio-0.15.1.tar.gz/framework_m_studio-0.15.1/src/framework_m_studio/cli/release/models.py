"""Models for release orchestration."""

from __future__ import annotations

from pydantic import BaseModel, ConfigDict, Field


class Commit(BaseModel):
    """Data model for a conventional commit."""

    hash: str
    subject: str
    body: str
    type: str  # feat, fix, chore, etc.
    scope: str | None = None
    breaking: bool = False
    description: str
    body_tags: list[str] = Field(default_factory=list)


class ReleaseUpdate(BaseModel):
    """Payload for a single component update."""

    component: str
    component_path: str
    version_file: str
    current_version: str
    new_version: str
    bump: str  # major, minor, patch
    changelog: str


class ReleasePackage(BaseModel):
    """Configuration for a single package in the release process."""

    model_config = ConfigDict(populate_by_name=True)

    name: str = Field(description="The name of the package.")
    version_file: str = Field(description="Path to the version file.")
    paths: list[str] = Field(
        default_factory=list, description="List of paths included in this package."
    )
    scopes: list[str] = Field(
        description="Conventional commit scopes that trigger a release."
    )
    include_global: bool = Field(
        default=False, description="Whether to include global commits."
    )
    publish_name: str | None = Field(
        default=None, description="The name used in package.json or pyproject.toml."
    )


class ReleaseSync(BaseModel):
    """Configuration for an extra file to update during release (e.g., templates)."""

    file: str = Field(
        description="Path to the file or glob pattern (e.g. templates/**/*.json)."
    )
    pattern: str | None = Field(
        default=None, description="Regex pattern with one capturing group for version."
    )
    package_name: str = Field(
        description="The framework package whose version to inject."
    )


class ReleaseConfig(BaseModel):
    """Overall release configuration."""

    packages: list[ReleasePackage]
    sync: list[ReleaseSync] = Field(default_factory=list)
    target_branch: str = Field(default="main")
    release_branch: str = Field(default="release/next")
    enable_sbom: bool = Field(default=False)
    provider: str = Field(default="gitlab")
