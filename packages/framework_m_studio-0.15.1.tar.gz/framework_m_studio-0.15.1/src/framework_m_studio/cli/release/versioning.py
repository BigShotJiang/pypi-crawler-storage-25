"""Versioning and dependency pinning logic."""

from __future__ import annotations

import json
import re
from pathlib import Path

from .models import Commit, ReleaseConfig, ReleaseUpdate


def _bump_version(version: str, bump: str) -> str:
    """Bump the version string (major.minor.patch)."""
    parts = list(map(int, version.split(".")))
    if bump == "major":
        parts[0] += 1
        parts[1] = 0
        parts[2] = 0
    elif bump == "minor":
        parts[1] += 1
        parts[2] = 0
    elif bump == "patch":
        parts[2] += 1
    return ".".join(map(str, parts))


def _update_file_version(file_path: str, version: str) -> None:
    """Update the version field in pyproject.toml or package.json (and templates)."""
    path = Path(file_path)
    if not path.exists():
        return

    content = path.read_text()
    if ".toml" in path.suffixes:
        new_content = re.sub(
            r'^version\s*=\s*"[^"]+"',
            f'version = "{version}"',
            content,
            flags=re.MULTILINE,
        )
    elif ".json" in path.suffixes:
        try:
            data = json.loads(content)
            if "version" in data:
                data["version"] = version
                new_content = json.dumps(data, indent=2) + "\n"
            else:
                return
        except (json.JSONDecodeError, KeyError):
            return
    else:
        return

    if new_content != content:
        path.write_text(new_content)


def _pin_inter_package_dependencies(
    file_path: str, updates: list[ReleaseUpdate], config: ReleaseConfig
) -> None:
    """Pin inter-package dependencies to their new versions (NPM + Python)."""
    path = Path(file_path)
    if not path.exists():
        return

    # Build a mapping of internal names to external (publish) names
    update_map: dict[str, str] = {}
    for update in updates:
        pub_name = update.component
        for pkg in config.packages:
            if pkg.name == update.component and pkg.publish_name:
                pub_name = pkg.publish_name
                break

        update_map[pub_name] = update.new_version
        update_map[update.component] = update.new_version

    changed = False

    if ".toml" in path.suffixes:
        content = path.read_text()
        for comp_name, new_ver in update_map.items():
            # 1. Handle list-style: "package>=1.0.0" or "package^=1.0.0"
            list_pattern = rf'"{re.escape(comp_name)}([>=^~]+)[^"]+"'
            if re.search(list_pattern, content):
                content = re.sub(list_pattern, f'"{comp_name}\\g<1>{new_ver}"', content)
                changed = True

            # 2. Handle table-style: package = "1.0.0" (only at start of line)
            table_pattern = rf'^{re.escape(comp_name)}\s*=\s*"[^"]+"'
            if re.search(table_pattern, content, re.MULTILINE):
                content = re.sub(
                    table_pattern,
                    f'{comp_name} = "{new_ver}"',
                    content,
                    flags=re.MULTILINE,
                )
                changed = True
        if changed:
            path.write_text(content)

    elif ".json" in path.suffixes:
        try:
            content = path.read_text()
            data = json.loads(content)
            # 1. Check standard dependency sections
            for section in ["dependencies", "devDependencies", "peerDependencies"]:
                if section in data:
                    for pub_name, new_ver in update_map.items():
                        if pub_name in data[section]:
                            current = str(data[section][pub_name])
                            # Match numeric versions, 'workspace:*' or 'workspace:^0.1.0'
                            m = re.match(
                                r"^(([~^]?\d+\.\d+(?:\.\d+)*)|workspace:(?:\*|[~^]?\d+\.\d+(?:\.\d+)*))$",
                                current,
                            )
                            if m:
                                match_obj = re.match(r"^[^0-9]*", current)
                                prefix = match_obj.group(0) if match_obj else ""

                                # Canonicalize workspace prefix - preserve it if present
                                if not prefix or prefix == "workspace:*":
                                    prefix = "^"
                                elif prefix == "workspace:":
                                    prefix = "workspace:^"

                                data[section][pub_name] = f"{prefix}{new_ver}"
                                changed = True

            # 2. Check for direct package name keys (common in templates/configs)
            for pub_name, new_ver in update_map.items():
                if (
                    pub_name in data
                    and isinstance(data[pub_name], str)
                    and re.match(
                        r"^(([~^]?\d+\.\d+(?:\.\d+)*)|workspace:(?:\*|[~^]?\d+\.\d+(?:\.\d+)*))$",
                        data[pub_name],
                    )
                ):
                    m = re.match(r"^[^0-9]*", data[pub_name])
                    prefix = m.group(0) if m else ""
                    data[pub_name] = f"{prefix}{new_ver}"
                    changed = True

            if changed:
                path.write_text(json.dumps(data, indent=2) + "\n")
        except (json.JSONDecodeError, KeyError):
            return


def _generate_changelog(
    commits: list[Commit], version: str, component_name: str
) -> str:
    """Generate Markdown changelog entry."""
    features, fixes, breaking = [], [], []
    for commit in commits:
        if commit.type in ["chore", "test", "ci", "docs", "style", "refactor"]:
            continue
        entry = f"- {commit.description} ({commit.hash[:7]})"
        if commit.breaking:
            breaking.append(entry)
        elif commit.type == "feat":
            features.append(entry)
        elif commit.type == "fix":
            fixes.append(entry)

    if not (features or fixes or breaking):
        return ""

    changelog = f"## {component_name} v{version}\n\n"
    if breaking:
        changelog += "### ⚠ BREAKING CHANGES\n\n" + "\n".join(breaking) + "\n\n"
    if features:
        changelog += "### Features\n\n" + "\n".join(features) + "\n\n"
    if fixes:
        changelog += "### Bug Fixes\n\n" + "\n".join(fixes) + "\n\n"
    return changelog


def _prepend_changelog(file_path: str, content: str) -> None:
    """Prepend new entries to CHANGELOG.md."""
    if not content:
        return
    path = Path(file_path)
    old_content = path.read_text() if path.exists() else ""
    path.write_text(content + old_content)
