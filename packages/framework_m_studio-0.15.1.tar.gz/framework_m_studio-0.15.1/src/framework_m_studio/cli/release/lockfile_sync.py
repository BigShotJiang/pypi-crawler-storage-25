"""Lockfile synchronization utilities for release orchestration."""

import shutil
from pathlib import Path

from framework_m_core.cli.utility import CLIConsole

from framework_m_studio.core.shell import run_cmd


def sync_lockfiles(root: Path) -> None:
    """Synchronize lockfiles for diverse environments."""
    console = CLIConsole()
    console.info("Synchronizing lockfiles...")
    if (root / "pnpm-lock.yaml").exists():
        pnpm_bin = shutil.which("pnpm")
        if pnpm_bin:
            try:
                run_cmd(
                    [pnpm_bin, "install", "--no-frozen-lockfile"], cwd=root, check=True
                )
            except Exception as e:
                console.error(f"pnpm lockfile sync failed: {e}")
                raise
        else:
            raise RuntimeError(
                "pnpm-lock.yaml exists but 'pnpm' tool was not found. "
                "Please install pnpm or ensure it's in your PATH to synchronize lockfiles."
            )

    if (root / "uv.lock").exists() or (root / "pyproject.toml").exists():
        uv_bin = shutil.which("uv")
        if uv_bin:
            try:
                run_cmd([uv_bin, "lock"], cwd=root, check=True)
            except Exception as e:
                console.error(f"uv lockfile sync failed: {e}")
                raise
        else:
            # Only fail on uv if we explicitly have a uv.lock or need to generate one
            if (root / "uv.lock").exists():
                raise RuntimeError(
                    "uv.lock exists but 'uv' tool was not found. "
                    "Please install uv or ensure it's in your PATH to synchronize lockfiles."
                )
