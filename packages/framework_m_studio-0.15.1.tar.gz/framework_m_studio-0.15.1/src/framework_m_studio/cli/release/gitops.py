import os
import re
import subprocess
from typing import Any, Protocol, runtime_checkable

import httpx

from framework_m_studio.core.shell import run_cmd

from .models import Commit


def _get_console() -> Any:
    from framework_m_core.cli.utility import CLIConsole

    return CLIConsole()


@runtime_checkable
class GitProviderProtocol(Protocol):
    """Protocol for Git platform providers (GitLab, GitHub, etc.)."""

    async def find_mr(self, branch: str) -> dict[str, Any] | None: ...

    async def create_mr(
        self, title: str, desc: str, branch: str, target_branch: str
    ) -> dict[str, Any]: ...

    async def update_mr(self, iid: str, title: str, desc: str) -> dict[str, Any]: ...

    async def create_release(self, tag: str, changelog: str) -> dict[str, Any]: ...


class GitLabProvider:
    """GitLab-specific implementation of the GitProviderProtocol."""

    def __init__(self, token: str, project_id: str):
        self.token = token
        self.project_id = project_id
        self.api_url = os.environ.get("CI_API_V4_URL", "https://gitlab.com/api/v4")

    async def _request(
        self, method: str, path: str, data: dict[str, Any] | None = None
    ) -> dict[str, Any] | None:
        """Make an authenticated request to the GitLab API using httpx."""
        url = f"{self.api_url}/projects/{self.project_id}{path}"
        headers = {
            "PRIVATE-TOKEN": self.token,
            "Content-Type": "application/json",
        }

        try:
            async with httpx.AsyncClient(timeout=60.0) as client:
                response = await client.request(
                    method, url, headers=headers, json=data if data else None
                )
                response.raise_for_status()
                return response.json() if response.content.strip() else {}
        except httpx.HTTPStatusError as e:
            _get_console().error(
                f"GitLab API {method} {path} failed with {e.response.status_code}"
            )
            return None
        except Exception as e:
            _get_console().error(f"GitLab API request failed: {e}")
            return None

    async def find_mr(self, branch: str) -> dict[str, Any] | None:
        path = f"/merge_requests?source_branch={branch}&state=opened"
        mrs = await self._request("GET", path)
        return mrs[0] if isinstance(mrs, list) and mrs else None

    async def create_mr(
        self, title: str, desc: str, branch: str, target_branch: str
    ) -> dict[str, Any]:
        path = "/merge_requests"
        data = {
            "title": title,
            "description": desc,
            "source_branch": branch,
            "target_branch": target_branch,
            "remove_source_branch": True,
        }
        res = await self._request("POST", path, data)
        return res if res is not None else {}

    async def update_mr(self, iid: str, title: str, desc: str) -> dict[str, Any]:
        path = f"/merge_requests/{iid}"
        data = {"title": title, "description": desc}
        res = await self._request("PUT", path, data)
        return res if res is not None else {}

    async def create_release(self, tag: str, changelog: str) -> dict[str, Any]:
        path = "/releases"
        data = {"tag_name": tag, "description": changelog}
        res = await self._request("POST", path, data)
        return res if res is not None else {}


def _get_last_tag(component: str) -> str | None:
    """Get the last git tag for a component (e.g., pkg-name@v1.2.3)."""
    match_pattern = f"{component}@v*"
    try:
        # Use list-based command for security
        tag = run_cmd(
            ["git", "describe", "--tags", "--abbrev=0", f"--match={match_pattern}"],
            check=False,
        )
        return tag.strip() if tag else None
    except Exception:
        return None


def _get_commits_since(tag: str | None) -> list[Commit]:
    """Get list of conventional commits since a tag (or all if tag is None)."""
    range_spec = f"{tag}..HEAD" if tag else "HEAD"
    sep = "||COMMIT_SEP||"
    log_format = f"%H%n%s%n%b%n{sep}"
    # Use list-based command for security
    output = run_cmd(["git", "log", range_spec, f"--pretty=format:{log_format}"])

    commits = []
    if output:
        raw_commits = output.split(sep)
        for raw in raw_commits:
            if not raw.strip():
                continue
            lines = raw.strip().split("\n")
            if len(lines) < 2:
                continue
            parsed = _parse_commit_message("\n".join(lines[1:]), lines[0])
            if parsed:
                commits.append(parsed)
    return commits


def _parse_commit_message(full_message: str, hash_str: str = "") -> Commit | None:
    """Parse a conventional commit message into a Commit model."""
    lines = full_message.strip().split("\n")
    subject = lines[0]
    body = "\n".join(lines[1:]).strip() if len(lines) > 1 else ""
    pattern = r"^(\w+)(?:\(([\w\-\.\*]+)\))?(!)?:\s*(.+)"
    match = re.match(pattern, subject)

    if not match:
        return None

    commit_type, scope, breaking_mark, description = match.groups()
    is_breaking = bool(breaking_mark) or "BREAKING CHANGE:" in body

    body_tags = []
    for line in body.split("\n"):
        tag_match = re.search(r"^(?:Releases|Packages):\s*(.+)", line, re.I)
        if tag_match:
            body_tags.extend(
                [
                    s.strip()
                    for s in tag_match.group(1).replace(",", " ").split()
                    if s.strip()
                ]
            )

    return Commit(
        hash=hash_str,
        subject=subject,
        body=body,
        type=commit_type,
        scope=scope,
        breaking=is_breaking,
        description=description,
        body_tags=body_tags,
    )


def push_release_branch(branch: str, host: str, project_path: str, token: str) -> None:
    """Push the local release branch directly to the remote (using token)."""
    normalized_path = project_path.lstrip("/")
    if not normalized_path:
        raise ValueError("Git project path is empty. Cannot determine remote URL.")
    # Inject token into the remote URL for direct push
    remote_url = f"https://oauth2:{token}@{host}/{normalized_path}.git"
    # Use list-based command for security (Bandit B605)
    # Use --force to ensure we can update the transient release branch in CI/CD
    cmd = ["git", "push", "--force", remote_url, f"{branch}:refs/heads/{branch}"]
    try:
        # We use subprocess.run directly for fine-grained masking of the token in logs
        result = subprocess.run(cmd, capture_output=True, text=True, check=False)
        if result.returncode != 0:
            error_msg = result.stderr or result.stdout or "Unknown git error"
            # Mask the token in any error output
            cleaned_error = error_msg.replace(token, "[MASKED]")
            _get_console().error(f"Error pushing release branch: {cleaned_error}")
            raise SystemExit(1)
    except Exception as e:
        # Mask the token in any exception message
        cleaned_error = str(e).replace(token, "[MASKED]")
        _get_console().error(f"Failed to execute git push: {cleaned_error}")
        raise SystemExit(1) from None
