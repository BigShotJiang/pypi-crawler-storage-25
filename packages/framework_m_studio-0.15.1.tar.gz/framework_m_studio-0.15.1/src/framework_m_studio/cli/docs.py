"""Documentation CLI Commands.

This module provides CLI commands for documentation generation and management.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import TYPE_CHECKING, Annotated, Any

import cyclopts
import httpx
from framework_m_core.cli.utility import console

from framework_m_studio.cli.constants import DEFAULT_BACKEND_PORT
from framework_m_studio.docs.ast_parsers import (
    generate_hooks_doc,
    generate_protocols_doc,
)
from framework_m_studio.docs.exporters import (
    export_doctypes_yaml,
    export_rag_corpus,
)
from framework_m_studio.docs.generator import (
    generate_cli_reference,
    run_docs_generate,
)
from framework_m_studio.docs.openapi import generate_openapi_markdown

# Lazy-loaded attributes for mocking in tests
yaml: Any = None
Page: Any = None

if TYPE_CHECKING:
    pass

docs_app = cyclopts.App(
    name="docs",
    help="Documentation generation tools",
)


@docs_app.command(name="generate")
def docs_generate(
    output: Annotated[
        str,
        cyclopts.Parameter(
            name="--output",
            help="Output directory for documentation",
        ),
    ] = "./docs/developer/generated",
    openapi_url: Annotated[
        str | None,
        cyclopts.Parameter(
            name="--openapi-url",
            help="URL to fetch OpenAPI schema from (optional)",
        ),
    ] = None,
    protocols: Annotated[
        bool,
        cyclopts.Parameter(
            name="--protocols",
            help="Generate Protocol reference documentation",
        ),
    ] = False,
    hooks: Annotated[
        bool,
        cyclopts.Parameter(
            name="--hooks",
            help="Generate lifecycle hooks documentation",
        ),
    ] = False,
    cli: Annotated[
        bool,
        cyclopts.Parameter(
            name="--cli",
            help="Generate CLI reference documentation",
        ),
    ] = False,
    core: Annotated[
        bool,
        cyclopts.Parameter(
            name="--core",
            help="Generate all core documentation (protocols, hooks, cli)",
        ),
    ] = False,
    adr: Annotated[
        bool,
        cyclopts.Parameter(
            name="--adr",
            help="Update ADR index",
        ),
    ] = False,
    rfc: Annotated[
        bool,
        cyclopts.Parameter(
            name="--rfc",
            help="Update RFC index",
        ),
    ] = False,
    field_types: Annotated[
        bool,
        cyclopts.Parameter(
            name="--field-types",
            help="Generate field types documentation",
        ),
    ] = False,
    api_endpoints: Annotated[
        bool,
        cyclopts.Parameter(
            name="--api-endpoints",
            help="Generate API endpoints documentation",
        ),
    ] = False,
    doctypes: Annotated[
        bool,
        cyclopts.Parameter(
            name="--doctypes",
            help="Generate DocType API reference",
        ),
    ] = False,
    complete: Annotated[
        bool,
        cyclopts.Parameter(
            name=["--all", "--complete"],
            help="Generate all documentation logically",
        ),
    ] = False,
    hooks_file: Annotated[
        str | None,
        cyclopts.Parameter(
            name="--hooks-file",
            help="Path to the controller file containing lifecycle hooks (optional)",
        ),
    ] = None,
) -> None:
    """Unified documentation generator.

    Orchestrates the generation of different documentation types.
    By default (no flags), it generates DocType API reference.

    Examples:
        m docs generate --doctypes             # Generate DocType API reference
        m docs generate --protocols            # Generate Protocols reference
        m docs generate --all                  # Generate everything
    """
    # Use current working directory as project root
    project_root = Path.cwd()

    # If no flags provided, default to doctypes
    if not (protocols or hooks or cli or core or adr or rfc or doctypes or complete):
        doctypes = True

    if complete:
        protocols = hooks = cli = adr = rfc = doctypes = field_types = api_endpoints = (
            True
        )

    if core:
        protocols = hooks = cli = field_types = api_endpoints = True

    output_path = Path(output)
    output_path.mkdir(parents=True, exist_ok=True)

    if protocols:
        console.info("\n📜 Generating Protocol documentation...")
        protocols_content = generate_protocols_doc(project_root)
        (output_path / "protocols.md").write_text(protocols_content)
        console.success(f"  ✓ protocols.md generated in {output_path}")

    if cli:
        console.info("\n💻 Generating CLI Reference...")
        cli_content = generate_cli_reference(project_root)
        (output_path / "cli-reference.md").write_text(cli_content)
        console.success(f"  ✓ cli-reference.md generated in {output_path}")

    if hooks:
        console.info("\n🪝 Generating Lifecycle Hooks documentation...")
        hooks_content = generate_hooks_doc(project_root, hooks_file=hooks_file)
        (output_path / "hooks.md").write_text(hooks_content)
        console.success(f"  ✓ hooks.md generated in {output_path}")

    if field_types:
        console.info("\n🧱 Generating Field Types documentation...")
        from framework_m_studio.docs.generator import generate_field_types_doc

        (output_path / "field-types.md").write_text(generate_field_types_doc())
        console.success(f"  ✓ field-types.md generated in {output_path}")

    if api_endpoints:
        console.info("\n🌐 Generating API Endpoints documentation...")
        from framework_m_studio.docs.generator import generate_api_endpoints_doc

        (output_path / "api-endpoints.md").write_text(generate_api_endpoints_doc())
        console.success(f"  ✓ api-endpoints.md generated in {output_path}")

    if doctypes:
        console.info("\n📦 Generating DocType reference documentation...")
        # Look in src/doctypes if it exists, otherwise use project root
        doctypes_dir = project_root / "src" / "doctypes"
        scan_root = project_root / "src" if doctypes_dir.exists() else project_root

        run_docs_generate(
            output=output,
            project_root=str(scan_root),
            openapi_url=openapi_url,
        )

    if adr:
        console.info("\n🏛️  Updating ADR index...")
        adr_dir = project_root / "docs" / "adr"
        if adr_dir.exists():
            _generate_adr_index(adr_dir, "ADR")
            console.success(f"  ✓ ADR index updated: {adr_dir}/index.md")

    if rfc:
        console.info("\n📝 Updating RFC index...")
        rfc_dir = project_root / "docs" / "rfcs"
        if rfc_dir.exists():
            _generate_adr_index(rfc_dir, "RFC")
            console.success(f"  ✓ RFC index updated: {rfc_dir}/index.md")

    console.success("\n✅ Documentation routine complete.")


@docs_app.command(name="openapi")
def docs_openapi(
    output: Annotated[
        str,
        cyclopts.Parameter(
            name="--output",
            help="Output file path for OpenAPI schema (.json or .md)",
        ),
    ] = "./docs/api/openapi.json",
    openapi_url: Annotated[
        str,
        cyclopts.Parameter(
            name="--openapi-url",
            help="URL to fetch OpenAPI schema from",
        ),
    ] = f"http://localhost:{DEFAULT_BACKEND_PORT}/schema/openapi.json",
    markdown: Annotated[
        bool,
        cyclopts.Parameter(
            name="--markdown",
            help="Generate human-readable Markdown from the OpenAPI schema",
        ),
    ] = False,
) -> None:
    """Export OpenAPI documentation.

    Examples:
        m docs openapi --output ./docs/api/openapi.json
        m docs openapi --output ./docs/api/reference.md --markdown
    """
    if not openapi_url.startswith(("http://", "https://")):
        console.error(
            f"❌ Invalid OpenAPI URL: {openapi_url}. Only http and https are allowed."
        )
        return

    response = httpx.get(openapi_url)
    response.raise_for_status()
    schema = response.json()

    output_path = Path(output)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    if markdown:
        markdown_content = generate_openapi_markdown(schema)
        output_path.write_text(markdown_content)
        console.success(f"✅ Exported OpenAPI markdown to: {output_path}")
    else:
        output_path.write_text(json.dumps(schema, indent=2))
        console.success(f"✅ Exported OpenAPI schema to: {output_path}")


export_app = cyclopts.App(
    name="export", help="Export documentation in machine-readable formats"
)
docs_app.command(export_app)


@export_app.command(name="corpus")
def docs_export_corpus(
    output: Annotated[
        str,
        cyclopts.Parameter(
            name="--output",
            help="Output file path for the RAG corpus (.jsonl)",
        ),
    ] = "./docs/machine/corpus.jsonl",
    root: Annotated[
        str | None,
        cyclopts.Parameter(
            name="--root",
            help="Project root directory (defaults to cwd)",
        ),
    ] = None,
    include_tests: Annotated[
        bool,
        cyclopts.Parameter(
            name="--include-tests",
            help="Include tests in the corpus",
        ),
    ] = False,
) -> None:
    """Export documentation and source code as a JSONL corpus for RAG/LLM.

    Examples:
        m docs export corpus
        m docs export corpus --output custom.jsonl --include-tests
    """
    project_root = Path(root) if root else Path.cwd()
    output_path = Path(output)

    console.info(f"📤 Exporting RAG corpus to {output_path}...")
    export_rag_corpus(project_root, output_path, include_tests=include_tests)
    console.success("   ✅ Export complete")


@export_app.command(name="doctypes")
def docs_export_doctypes(
    output: Annotated[
        str,
        cyclopts.Parameter(
            name="--output",
            help="Output file path for the schemas (.yaml)",
        ),
    ] = "./docs/machine/doctypes.yaml",
    root: Annotated[
        str | None,
        cyclopts.Parameter(
            name="--root",
            help="Project root directory (defaults to cwd)",
        ),
    ] = None,
) -> None:
    """Export DocTypes as structured YAML schemas.

    Examples:
        m docs export doctypes
        m docs export doctypes --output custom.yaml
    """
    project_root = Path(root) if root else Path.cwd()
    output_path = Path(output)

    console.info(f"📤 Exporting DocTypes YAML to {output_path}...")
    export_doctypes_yaml(project_root, output_path)
    console.success("   ✅ Export complete")


@docs_app.command(name="adr")
def docs_adr(
    action: Annotated[
        str | None,
        cyclopts.Parameter(help="Action: create or index"),
    ] = None,
    title: Annotated[
        str | None,
        cyclopts.Parameter(help="Title for new ADR (required for create)"),
    ] = None,
    verify: Annotated[
        bool,
        cyclopts.Parameter(name="--verify", help="Verify document numbering"),
    ] = False,
    adr_dir: Annotated[
        Path | None,
        cyclopts.Parameter(name="--adr-dir", help="Directory containing ADRs"),
    ] = None,
    template: Annotated[
        Path | None,
        cyclopts.Parameter(name="--template", help="Path to ADR template file"),
    ] = None,
) -> None:
    """Manage Architecture Decision Records.

    Examples:
        m docs adr create "Use Redis for caching"
        m docs adr index
    """
    import re
    from datetime import date
    from pathlib import Path

    project_root = Path.cwd()
    if adr_dir is None:
        adr_dir = project_root / "docs" / "architecture" / "architecture_decisions"

    template_path = (
        template
        if template is not None
        else (project_root / "docs" / "processes" / "adr-template.md")
    )

    if verify:
        from framework_m_studio.cli.quality import verify_doc_numbering

        errors = verify_doc_numbering(adr_dir)
        if errors:
            console.error("❌ ADR validation errors found:")
            for error in errors:
                console.error(f"   {error}")
            import sys

            sys.exit(1)
        else:
            console.success("✅ ADR numbering passed with no issues.")
        return

    if action == "create":
        if not title:
            console.error('❌ Title required: m docs adr create "Your Title"')
            return

        # Find next ADR number
        existing_adrs = list(adr_dir.glob("*.md"))
        numbers = []
        for f in existing_adrs:
            match = re.match(r"(\d+)-", f.name)
            if match:
                numbers.append(int(match.group(1)))

        next_num = max(numbers, default=0) + 1
        num_str = f"{next_num:04d}"

        # Create slug from title
        slug = re.sub(r"[^\w\s-]", "", title.lower())
        slug = re.sub(r"[-\s]+", "-", slug).strip("-")

        filename = f"{num_str}-{slug}.md"
        filepath = adr_dir / filename

        # Read template and fill in
        if template_path.exists():
            content = template_path.read_text()
            content = content.replace("ADR-0000", f"ADR-{num_str}")
            content = content.replace("[Short Title]", title)
            content = content.replace("YYYY-MM-DD", date.today().isoformat())
        else:
            content = f"""# ADR-{num_str}: {title}

- **Status**: Proposed
- **Date**: {date.today().isoformat()}

## Context

[Problem description]

## Decision

[What we decided]

## Consequences

[What becomes easier or harder]
"""

        adr_dir.mkdir(parents=True, exist_ok=True)
        filepath.write_text(content)
        console.success(f"✅ Created: {filepath}")

    elif action == "index":
        _generate_adr_index(adr_dir, "ADR")

    else:
        console.error(
            f"❌ Unknown action: {action}. Use 'create', 'index', or '--verify'."
        )


@docs_app.command(name="rfc")
def docs_rfc(
    action: Annotated[
        str | None,
        cyclopts.Parameter(help="Action: create or index"),
    ] = None,
    title: Annotated[
        str | None,
        cyclopts.Parameter(help="Title for new RFC (required for create)"),
    ] = None,
    verify: Annotated[
        bool,
        cyclopts.Parameter(name="--verify", help="Verify document numbering"),
    ] = False,
    rfc_dir: Annotated[
        Path | None,
        cyclopts.Parameter(name="--rfc-dir", help="Directory containing RFCs"),
    ] = None,
    template: Annotated[
        Path | None,
        cyclopts.Parameter(name="--template", help="Path to RFC template file"),
    ] = None,
) -> None:
    """Manage Request for Comments documents.

    Examples:
        m docs rfc create "New Event System Design"
        m docs rfc index
    """
    import re
    from datetime import date
    from pathlib import Path

    project_root = Path.cwd()
    if rfc_dir is None:
        rfc_dir = project_root / "docs" / "governance" / "rfcs"

    template_path = (
        template
        if template is not None
        else (project_root / "docs" / "processes" / "rfc-template.md")
    )

    if verify:
        from framework_m_studio.cli.quality import verify_doc_numbering

        errors = verify_doc_numbering(rfc_dir)
        if errors:
            console.error("❌ RFC validation errors found:")
            for error in errors:
                console.error(f"   {error}")
            import sys

            sys.exit(1)
        else:
            console.success("✅ RFC numbering passed with no issues.")
        return

    if action == "create":
        if not title:
            console.error('❌ Title required: m docs rfc create "Your Title"')
            return

        # Find next RFC number
        existing_rfcs = list(rfc_dir.glob("*.md")) if rfc_dir.exists() else []
        numbers = []
        for f in existing_rfcs:
            match = re.match(r"(\d+)-", f.name)
            if match:
                numbers.append(int(match.group(1)))

        next_num = max(numbers, default=0) + 1
        num_str = f"{next_num:04d}"

        # Create slug from title
        slug = re.sub(r"[^\w\s-]", "", title.lower())
        slug = re.sub(r"[-\s]+", "-", slug).strip("-")

        filename = f"{num_str}-{slug}.md"
        filepath = rfc_dir / filename

        # Read template and fill in
        if template_path.exists():
            content = template_path.read_text()
            content = content.replace("RFC-0000", f"RFC-{num_str}")
            content = content.replace("[Short Title]", title)
            content = content.replace("YYYY-MM-DD", date.today().isoformat())
        else:
            content = f"""# RFC-{num_str}: {title}

- **Status**: Draft
- **Date**: {date.today().isoformat()}

## Summary

[Brief description]

## Motivation

[Why are we doing this?]

## Detailed Design

[Technical details]
"""

        rfc_dir.mkdir(parents=True, exist_ok=True)
        filepath.write_text(content)
        console.success(f"✅ Created: {filepath}")

    elif action == "index":
        _generate_adr_index(rfc_dir, "RFC")

    else:
        console.error(
            f"❌ Unknown action: {action}. Use 'create', 'index', or '--verify'."
        )


def _generate_adr_index(docs_dir: Path, doc_type: str) -> None:
    """Generate index.md and Docusaurus sidebar for ADRs or RFCs."""
    import re

    if not docs_dir.exists():
        console.error(f"❌ Directory not found: {docs_dir}")
        return

    # Collect all documents
    docs = []
    for f in sorted(docs_dir.glob("*.md")):
        if f.name in ("index.md", "_category_.json"):
            continue

        match = re.match(r"(?:[a-z]+-)?(\d+)-(.+)\.md", f.name)
        if match:
            num = match.group(1)
            # Extract title from file
            content = f.read_text()
            title_match = re.search(r"^#\s+.+:\s*(.+)$", content, re.MULTILINE)
            title = (
                title_match.group(1)
                if title_match
                else match.group(2).replace("-", " ").title()
            )

            # Extract status
            status_match = re.search(r"\*\*Status\*\*:\s*(\w+)", content)
            status = status_match.group(1) if status_match else "Unknown"

            docs.append(
                {
                    "num": num,
                    "title": title,
                    "status": status,
                    "filename": f.name,
                    "slug": f.stem,  # filename without .md
                }
            )

    # Generate index.md with frontmatter for sidebar sorting
    lines = [
        "---",
        "sidebar_position: 0",
        "---",
        "",
        f"# {doc_type} Index",
        "",
        f"This index contains all {doc_type}s in chronological order.",
        "",
        "| # | Title | Status |",
        "|---|-------|--------|",
    ]

    for doc in docs:
        lines.append(
            f"| [{doc['num']}](./{doc['filename']}) | {doc['title']} | {doc['status']} |"
        )

    lines.append("")
    lines.append(f"_Total: {len(docs)} {doc_type}s_")

    index_path = docs_dir / "index.md"
    index_path.write_text("\n".join(lines))
    console.success(f"✅ Generated: {index_path} ({len(docs)} {doc_type}s)")

    # Generate Docusaurus _category_.json for sidebar with lazy-loading
    category_config = {
        "label": f"{doc_type}s",
        "position": 1,
        "collapsed": True,  # Enable lazy-loading by default collapsed
        "collapsible": True,
        "link": {
            "type": "doc",
            "id": "index",
        },
    }
    category_path = docs_dir / "_category_.json"
    category_path.write_text(json.dumps(category_config, indent=2))
    console.success(f"✅ Generated: {category_path} (Docusaurus sidebar)")

    # Generate sidebar items JSON for programmatic use
    sidebar_items = {
        "type": "category",
        "label": f"{doc_type}s",
        "collapsed": True,
        "items": [
            {
                "type": "doc",
                "id": f"{doc_type.lower()}/{doc['slug']}",
                "label": f"{doc_type}-{doc['num']}: {doc['title'][:40]}{'...' if len(doc['title']) > 40 else ''}",
            }
            for doc in docs
        ],
    }
    sidebar_path = docs_dir / "_sidebar.json"
    sidebar_path.write_text(json.dumps(sidebar_items, indent=2))
    console.success(f"✅ Generated: {sidebar_path} (sidebar items)")

    console.success("\n✅ Screenshot pipeline complete!")


@docs_app.command(name="audit")
def docs_audit(
    project_root: Annotated[
        str,
        cyclopts.Parameter(
            name="--project-root",
            help="Project root directory",
        ),
    ] = ".",
    protocols_dir: Annotated[
        str | None,
        cyclopts.Parameter(
            name="--protocols-dir",
            help="Directory containing Protocol interfaces",
        ),
    ] = None,
) -> None:
    """Audit documentation gaps.

    Identifies missing docstrings in DocTypes and Protocols.

    Examples:
        m docs audit
        m docs audit --project-root ./apps/billing
    """
    import sys

    from framework_m_studio.docs.audit import run_docs_audit

    root = Path(project_root).resolve()
    p_dir = Path(protocols_dir).resolve() if protocols_dir else None

    success = run_docs_audit(project_root=root, protocols_dir=p_dir)
    if not success:
        sys.exit(1)


__all__ = [
    "docs_adr",
    "docs_app",
    "docs_audit",
    "docs_export_corpus",
    "docs_export_doctypes",
    "docs_generate",
    "docs_openapi",
    "docs_rfc",
    "export_app",
]
