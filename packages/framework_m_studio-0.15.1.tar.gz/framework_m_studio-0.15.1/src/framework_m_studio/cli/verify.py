"""Verify CLI Commands.

This module provides commands to verify build artifacts and configurations.

Usage:
    m verify:mfe my_app    # Verify my_app has valid MFE assets
"""

from __future__ import annotations

import sys
from importlib.resources import files
from typing import Annotated

import cyclopts
from framework_m_core.cli.utility import console


def verify_mfe_command(
    package: Annotated[
        str,
        cyclopts.Parameter(help="Package name to verify (e.g., 'my_app')"),
    ],
) -> None:
    """Verify Micro-Frontend (MFE) build artifacts.

    Checks if the package is installed and contains a valid `remoteEntry.js`
    in its static directory. This is used in CI pipelines to verify builds.
    """
    try:
        package_files = files(package)
        remote_entry = package_files / "static" / "remoteEntry.js"

        if remote_entry.is_file():
            console.success(f"✓ Verified MFE artifacts for '{package}'")
            sys.exit(0)
        else:
            console.error(f"✗ Missing remoteEntry.js in '{package}' static directory")
            sys.exit(1)

    except ImportError:
        console.error(f"✗ Package '{package}' not found. Is it installed?")
        sys.exit(1)
    except Exception as e:
        console.error(f"✗ Verification failed: {e}")
        sys.exit(1)
