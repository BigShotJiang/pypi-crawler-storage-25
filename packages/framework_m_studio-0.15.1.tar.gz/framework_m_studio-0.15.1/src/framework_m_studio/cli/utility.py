"""Utility CLI commands for Framework M Studio."""

from __future__ import annotations

import ast
import importlib
import sys
from pathlib import Path
from typing import Annotated, Any

import cyclopts
from framework_m_core.cli.utility import Table, console
from framework_m_core.container import Container, hydrate_apps
from litestar import Litestar
from rich.panel import Panel
from rich.traceback import install


def check_ipython_installed() -> bool:
    """Check if IPython is installed."""
    try:
        import IPython  # noqa: F401

        return True
    except ImportError:
        return False


class REPLContext:
    """Convenience gateway for the interactive console (the 'm' object)."""

    def __init__(self, container: Container) -> None:
        self.container = container

    @property
    def db(self) -> Any:
        """Get a new database session context manager."""
        try:
            return self.container.session_factory().get_session()
        except Exception as e:
            return f"Error initializing DB session: {e}"

    @property
    def session(self) -> Any:
        """Alias for m.db."""
        return self.db

    @property
    def jobs(self) -> Any:
        """Access the global JobRegistry."""
        from framework_m_core.jobs_registry import get_global_registry

        return get_global_registry()

    @property
    def config(self) -> Any:
        """Access the active RootConfig."""
        try:
            return self.container.config()
        except Exception as e:
            return f"Error accessing config: {e}"

    def repo(self, doctype: Any) -> Any:
        """Get the repository for a DocType.

        Args:
            doctype: DocType name (str) or class
        """
        try:
            from framework_m_core.registry import MetaRegistry
            from framework_m_standard.adapters.db.repository_factory import (
                RepositoryFactory,
            )

            if isinstance(doctype, str):
                doctype_class = MetaRegistry().get_doctype(doctype)
            else:
                doctype_class = doctype

            # Get metadata from table registry if available, otherwise fresh MetaData
            from framework_m_standard.adapters.db.table_registry import TableRegistry
            from sqlalchemy import MetaData

            reg = TableRegistry()
            table_names = reg.list_tables()
            metadata = (
                reg.get_table(table_names[0]).metadata if table_names else MetaData()
            )

            # RepositoryFactory needs metadata and session_factory
            factory = RepositoryFactory(
                metadata=metadata,
                session_factory=self.container.session_factory(),
            )

            repo = factory.get_repository(doctype_class)
            if repo is None:
                return f"Repository not found for {doctype}. (Table not found in metadata - check if database_url is configured and schema sync ran)"
            return repo
        except Exception as e:
            return f"Error getting repository for {doctype}: {e}"

    @property
    def metadata(self) -> Any:
        """Access the active SQLAlchemy MetaData."""
        try:
            from framework_m_standard.adapters.db.table_registry import TableRegistry
            from sqlalchemy import MetaData

            reg = TableRegistry()
            table_names = reg.list_tables()
            if table_names:
                return reg.get_table(table_names[0]).metadata

            return MetaData()
        except Exception as e:
            return f"Error accessing metadata: {e}"

    def __repr__(self) -> str:
        return "<Framework M REPL Context: m.session (context manager), m.repo(), m.jobs, m.config, m.metadata>"


InteractiveShellEmbed: Any
try:
    from IPython.terminal.embed import InteractiveShellEmbed
except ImportError:
    InteractiveShellEmbed = None


def console_command(
    with_container: Annotated[
        bool,
        cyclopts.Parameter(
            name="--with-container", help="Auto-initialize DI container"
        ),
    ] = False,
) -> None:
    """Start an interactive console."""

    install(show_locals=True)
    namespace: dict[str, Any] = {}

    if with_container:
        container = Container()
        hydrate_apps(container)
        namespace["container"] = container
        namespace["m"] = REPLContext(container)

    # Prepare Banner
    banner_text = "[bold blue]Framework M Console[/bold blue]\n"
    if with_container:
        banner_text += (
            "✓ [green]DI Container initialized and hydrated.[/green]\n"
            "✓ [cyan]Available variables:[/cyan] [bold]container[/bold], [bold]m[/bold] (shortcuts)\n"
            "  [dim]Example: async with m.session as s: await m.repo('LocalUser').list_entities(s)[/dim]"
        )
    else:
        banner_text += "[yellow]Warning: Container NOT initialized. (Re-run with --with-container to make 'container' available)[/yellow]"

    console.print(
        Panel(
            banner_text,
            title="[bold magenta]Interactive Shell[/bold magenta]",
            border_style="bright_blue",
            expand=False,
        )
    )

    if check_ipython_installed() and InteractiveShellEmbed:
        shell = InteractiveShellEmbed(user_ns=namespace)
        shell()
    else:
        import code

        code.interact(banner="Framework M Console (Fallback Shell)", local=namespace)


def _detect_asgi_symbol(module_file: Path) -> str | None:
    """Detect ASGI entry symbol in a Python module.

    Returns:
        "app" if a top-level app variable is defined,
        "create_app" if a top-level create_app function is defined,
        otherwise None.
    """
    try:
        source = module_file.read_text(encoding="utf-8")
        tree = ast.parse(source)
    except (OSError, SyntaxError, UnicodeDecodeError):
        return None

    has_create_app = False

    for node in tree.body:
        if isinstance(node, ast.Assign):
            for target in node.targets:
                if isinstance(target, ast.Name) and target.id == "app":
                    return "app"
        elif isinstance(node, ast.AnnAssign):
            if isinstance(node.target, ast.Name) and node.target.id == "app":
                return "app"
        elif (
            isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
            and node.name == "create_app"
        ):
            has_create_app = True

    if has_create_app:
        return "create_app"

    return None


def _find_app(explicit_app: str | None = None) -> str:
    """Find the Litestar app to run by searching common locations."""
    if explicit_app:
        return explicit_app

    cwd = Path.cwd()

    candidates: list[tuple[Path, str]] = [
        (cwd / "app.py", "app"),
        (cwd / "app" / "__init__.py", "app"),
        (cwd / "src" / "app" / "__init__.py", "src.app"),
        (cwd / "main.py", "main"),
    ]

    for module_file, module_name in candidates:
        if module_file.exists():
            symbol = _detect_asgi_symbol(module_file)
            if symbol:
                return f"{module_name}:{symbol}"

    # Fallback to the standard framework app if no local app is found
    return "framework_m_standard.adapters.web.app:create_app"


def routes_command(
    app_path: Annotated[
        str | None,
        cyclopts.Parameter(name="--app", help="App path to inspect"),
    ] = None,
) -> None:
    """List API routes from the application."""
    # Add CWD to python path so we can import the app
    sys.path.insert(0, str(Path.cwd()))

    target_app = _find_app(app_path)

    try:
        module_name, attr_name = target_app.split(":")
        module = importlib.import_module(module_name)
        app_obj = getattr(module, attr_name)

        # Handle factory function
        if callable(app_obj) and not isinstance(app_obj, Litestar):
            app = app_obj()
        else:
            app = app_obj

        if not isinstance(app, Litestar):
            console.print(
                f"[red]Error: {target_app} is not a Litestar application[/red]"
            )
            return

        table = Table(
            title="Application Routes", show_header=True, header_style="bold magenta"
        )
        table.add_column("Path")
        table.add_column("Methods")
        table.add_column("Handler")

        # Inspect routes
        for route in app.routes:
            path = getattr(route, "path", "N/A")

            if hasattr(route, "methods"):
                methods = ", ".join(sorted(route.methods))
            else:
                methods = "WS/ASGI"

            handler = "Unknown"
            if hasattr(route, "route_handler"):
                fn = route.route_handler.fn
                handler = getattr(fn, "__name__", str(fn))

            table.add_row(path, methods, handler)

        console.print(table)

    except Exception as e:
        console.print(f"[red]Failed to load app routes: {e}[/red]")


def entrypoints_command() -> None:
    """List all discovered Framework M entry points."""
    from importlib.metadata import entry_points

    groups = [
        "framework_m.apps",
        "framework_m.frontend",
        "framework_m.shell",
        "framework_m.bootstrap",
        "framework_m.overrides",
        "framework_m.containers",
        "framework_m.adapters.repository",
        "framework_m.adapters.schema_mapper",
        "framework_m.adapters.unit_of_work",
        "framework_m.adapters.permission",
        "framework_m.adapters.event_bus",
        "framework_m_core.cli_commands",
    ]

    table = Table(title="Discovered Framework M Entry Points")
    table.add_column("Group", style="cyan")
    table.add_column("Name", style="green")
    table.add_column("Target", style="magenta")

    all_eps = entry_points()

    for group in groups:
        try:
            # select(group=...) is standard in 3.10+
            eps = all_eps.select(group=group)
            for ep in eps:
                table.add_row(group, ep.name, ep.value)
        except Exception:
            continue

    console.print(table)


__all__ = [
    "console_command",
    "entrypoints_command",
    "routes_command",
]
