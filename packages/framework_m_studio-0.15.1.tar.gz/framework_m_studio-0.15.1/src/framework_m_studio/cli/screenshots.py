"""Screenshots CLI Commands.

This module provides CLI commands for automated screenshot capture of
Framework M applications.
"""

from __future__ import annotations

from pathlib import Path
from typing import Annotated

import cyclopts

from framework_m_studio.cli.constants import DEFAULT_BACKEND_PORT
from framework_m_studio.docs.screenshots import capture_screenshots

screenshots_app = cyclopts.App(
    name="screenshots",
    help="Capture automated screenshots for documentation",
)


@screenshots_app.default
def run_screenshots(
    manifest: Annotated[
        str,
        cyclopts.Parameter(
            name="--manifest",
            help="Path to screenshots.yaml manifest",
        ),
    ] = "docs/screenshots.yaml",
    base_url: Annotated[
        str,
        cyclopts.Parameter(
            name="--base-url",
            help="Default base URL of the application (fallback)",
        ),
    ] = f"http://localhost:{DEFAULT_BACKEND_PORT}",
    username: Annotated[
        str | None,
        cyclopts.Parameter(
            name="--username",
            help="Username for authentication",
        ),
    ] = None,
    password: Annotated[
        str | None,
        cyclopts.Parameter(
            name="--password",
            help="Password for authentication",
        ),
    ] = None,
    target_dir: Annotated[
        str,
        cyclopts.Parameter(
            name="--target-dir",
            help="Target directory for screenshots",
        ),
    ] = "docs/images",
    verbose: Annotated[
        bool,
        cyclopts.Parameter(
            name="--verbose",
            help="Enable verbose output (browser console logs)",
        ),
    ] = False,
    trace: Annotated[
        bool,
        cyclopts.Parameter(
            name="--trace",
            help="Enable Playwright tracing (saved as trace.zip in target directory)",
        ),
    ] = False,
) -> None:
    """Capture screenshots based on a manifest.

    Examples:
        m screenshots --username admin --password secret
        m screenshots --manifest custom.yaml --target-dir static/img
    """
    manifest_path = Path(manifest).resolve()
    target_path = Path(target_dir).resolve()

    capture_screenshots(
        manifest_path=manifest_path,
        base_url=base_url,
        target_path=target_path,
        username=username,
        password=password,
        verbose=verbose,
        trace=trace,
    )
