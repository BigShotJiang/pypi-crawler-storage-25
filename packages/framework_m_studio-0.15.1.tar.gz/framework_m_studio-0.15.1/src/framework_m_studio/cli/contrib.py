"""Contributor CLI Commands."""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Annotated

import cyclopts
from framework_m_core.cli.utility import CLIConsole

contrib_app = cyclopts.App(
    name="contrib", help="Contributor tooling (CLA checks, etc.)"
)


@contrib_app.command(name="cla-check")
def cla_check_command(
    user: Annotated[
        str | None, cyclopts.Parameter(name="--user", help="GitLab/GitHub username")
    ] = None,
    contributors_file: Annotated[
        str,
        cyclopts.Parameter(
            name="--contributors-file", help="Path to contributors JSON"
        ),
    ] = "contributors.json",
) -> None:
    """Check if a user has signed the Contributor License Agreement."""
    target_user = user or os.environ.get("GITLAB_USER_LOGIN")

    if not target_user:
        CLIConsole().warning("No user provided. Skipping CLA check.")
        return

    contrib_path = Path(contributors_file)
    if not contrib_path.exists():
        CLIConsole().error(f"Contributors file not found at {contributors_file}")
        raise SystemExit(1) from None

    try:
        data = json.loads(contrib_path.read_text())
    except json.JSONDecodeError:
        CLIConsole().error(f"Invalid JSON in {contributors_file}")
        raise SystemExit(1) from None

    # Support both the TDD test format and the real repository format
    icla_users = data.get("icla", [])
    if "users" in data and "gitlab" in data["users"]:
        icla_users.extend(data["users"]["gitlab"])

    if target_user in icla_users:
        CLIConsole().success(f"User '{target_user}' has signed the ICLA.")
        return

    ccla_orgs = data.get("ccla", {})
    for org, members in ccla_orgs.items():
        if target_user in members:
            CLIConsole().success(
                f"User '{target_user}' is covered by CCLA for organization '{org}'."
            )
            return

    CLIConsole().error(f"User '{target_user}' is not listed in {contributors_file}.")
    CLIConsole().info(
        "Please sign the CLA by adding your username to the contributors file."
    )
    raise SystemExit(1) from None


__all__ = ["cla_check_command", "contrib_app"]
