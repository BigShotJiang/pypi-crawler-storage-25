"""Framework M Studio CLI Commands.

This module provides CLI commands that are registered via entry points
when framework-m-studio is installed. These extend the base `m` CLI
with developer tools.

Entry Point Registration (pyproject.toml):
    [project.entry-points."framework_m.cli_commands"]
    codegen = "framework_m_studio.cli:codegen_app"
"""

from __future__ import annotations

from typing import Annotated

import cyclopts

from framework_m_studio.cli.codegen import codegen_app, codegen_client, codegen_doctype

# Import utility commands and alias them for top-level registration
from framework_m_studio.cli.constants import DEFAULT_STUDIO_PORT
from framework_m_studio.cli.dev_link import dev_link_command
from framework_m_studio.cli.docs import (
    docs_app,
    docs_audit,
    docs_generate,
    docs_openapi,
)
from framework_m_studio.cli.screenshots import screenshots_app
from framework_m_studio.cli.utility import console_command as console
from framework_m_studio.cli.utility import routes_command as routes
from framework_m_studio.cli.verify import verify_mfe_command as verify_mfe

# =============================================================================
# Studio Sub-App (Main command to start Studio server)
# =============================================================================

studio_app = cyclopts.App(
    name="studio",
    help="Start Framework M Studio visual editor",
)


@studio_app.default
def studio_serve(
    port: Annotated[
        int,
        cyclopts.Parameter(
            name="--port",
            help="Port to run Studio on",
        ),
    ] = DEFAULT_STUDIO_PORT,
    host: Annotated[
        str,
        cyclopts.Parameter(
            name="--host",
            help="Host to bind to",
        ),
    ] = "0.0.0.0",  # nosec B104
    reload: Annotated[
        bool,
        cyclopts.Parameter(
            name="--reload",
            help="Enable auto-reload for development",
        ),
    ] = False,
    cloud: Annotated[
        bool,
        cyclopts.Parameter(
            name="--cloud",
            help="Enable cloud mode (Git-backed workspaces)",
        ),
    ] = False,
) -> None:
    """Start Framework M Studio.

    Examples:
        m studio              # Start on port 9999
        m studio --port 8000  # Custom port
        m studio --reload     # Development mode
        m studio --cloud      # Enable cloud mode
    """
    import os
    import webbrowser
    from contextlib import suppress

    import uvicorn
    from framework_m_core.cli.utility import CLIConsole

    console = CLIConsole()

    # Print startup banner
    display_host = "localhost" if host in {"0.0.0.0", "::"} else host  # nosec B104
    console.print()
    console.success("Starting Framework M Studio")
    console.info(f"   ➜ Local:   http://{display_host}:{port}/studio/")
    console.info(f"   ➜ API:     http://{display_host}:{port}/studio/api/")
    console.info(f"  🔌 API Health:   http://{display_host}:{port}/studio/api/health")
    console.print()

    if cloud:
        console.info("☁️  Cloud mode enabled - Git-backed workspaces")
        os.environ["STUDIO_CLOUD_MODE"] = "1"
        console.print()

    with suppress(Exception):
        webbrowser.open_new_tab(f"http://{display_host}:{port}/studio/")

    # Start uvicorn
    uvicorn.run(
        "framework_m_studio.app:app",
        host=host,
        port=port,
        reload=reload,
        log_level="info",
    )


@studio_app.command()
def dev_link(
    path: Annotated[
        str | None,
        cyclopts.Parameter(name=["--path", "-p"], help="Path to framework-m repo"),
    ] = None,
    dry_run: Annotated[
        bool, cyclopts.Parameter(name="--dry-run", help="Show what would be done")
    ] = False,
) -> None:
    """Link local framework-m source into the current project."""
    dev_link_command(path, dry_run)


__all__ = [
    "codegen_app",
    "codegen_client",
    "codegen_doctype",
    "console",
    "dev_link_command",
    "docs_app",
    "docs_audit",
    "docs_generate",
    "docs_openapi",
    "routes",
    "screenshots_app",
    "studio_app",
    "studio_serve",
    "verify_mfe",
]
