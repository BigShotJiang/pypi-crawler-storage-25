"""Print Repository and Hot-Swap Service."""

import os
from datetime import UTC, datetime
from pathlib import Path

from framework_m_studio.git.adapter import GitAdapter
from framework_m_studio.print_adapter import HotSwapMonitor, PrintRepoAdapter
from framework_m_studio.services import workspace

_PRINT_REPO_ADAPTER: PrintRepoAdapter | None = None
_HOT_SWAP_MONITOR: HotSwapMonitor | None = None
_HOT_SWAP_UPDATES = 0
_HOT_SWAP_LAST_UPDATE: str | None = None


def get_print_repo_path() -> Path:
    configured = os.environ.get("STUDIO_PRINT_REPO_PATH")
    repo_path = (
        Path(configured)
        if configured
        else workspace.get_project_root() / ".studio" / "print_repo"
    )
    repo_path.mkdir(parents=True, exist_ok=True)
    return repo_path


def get_print_repo_adapter() -> PrintRepoAdapter:
    global _PRINT_REPO_ADAPTER
    if _PRINT_REPO_ADAPTER is None:
        _PRINT_REPO_ADAPTER = PrintRepoAdapter(
            git_adapter=GitAdapter(), print_repo_path=get_print_repo_path()
        )
    return _PRINT_REPO_ADAPTER


def on_print_hot_swap_update() -> None:
    global _HOT_SWAP_UPDATES, _HOT_SWAP_LAST_UPDATE
    _HOT_SWAP_UPDATES += 1
    _HOT_SWAP_LAST_UPDATE = datetime.now(UTC).isoformat()


def get_hot_swap_monitor() -> HotSwapMonitor:
    global _HOT_SWAP_MONITOR
    if _HOT_SWAP_MONITOR is None:
        _HOT_SWAP_MONITOR = HotSwapMonitor(repo_path=get_print_repo_path())
        _HOT_SWAP_MONITOR.on_update(on_print_hot_swap_update)
        _HOT_SWAP_MONITOR.start()
    return _HOT_SWAP_MONITOR


def get_hot_swap_status() -> tuple[int, str | None]:
    return _HOT_SWAP_UPDATES, _HOT_SWAP_LAST_UPDATE


def record_sync() -> int:
    on_print_hot_swap_update()
    return _HOT_SWAP_UPDATES
