"""Publish and Git Workflow Service."""

import subprocess
from pathlib import Path
from urllib.parse import quote, urlparse


def get_remote_origin_url(project_root: Path) -> str | None:
    try:
        result = subprocess.run(
            ["git", "-C", str(project_root), "remote", "get-url", "origin"],
            capture_output=True,
            text=True,
            check=False,
        )
        if result.returncode != 0:
            return None
        url = result.stdout.strip()
        return url or None
    except OSError:
        return None


def normalize_author(author: str) -> str:
    author = author.strip()
    if "<" in author and ">" in author:
        return author
    safe = author.replace(" ", "-").lower() or "studio"
    return f"{author} <{safe}@local>"


def build_change_request_url(repo_url: str, branch: str) -> str | None:
    normalized = repo_url
    if normalized.startswith("git@"):
        host_path = normalized[4:]
        host, _, path = host_path.partition(":")
        normalized = f"https://{host}/{path}"
    if normalized.endswith(".git"):
        normalized = normalized[:-4]
    parsed = urlparse(normalized)
    if not parsed.scheme or not parsed.netloc:
        return None
    branch_q = quote(branch, safe="")
    if "github.com" in parsed.netloc:
        return f"{normalized}/compare/main...{branch_q}?expand=1"
    if "gitlab" in parsed.netloc:
        return f"{normalized}/-/merge_requests/new?merge_request%5Bsource_branch%5D={branch_q}&merge_request%5Btarget_branch%5D=main"
    return None
