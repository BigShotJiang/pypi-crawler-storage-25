"""Shell Plugin Configuration Service."""

from pathlib import Path
from typing import Any

from framework_m_studio.services import workspace
from framework_m_studio.shell_plugin_config import (
    ActionButton,
    SearchProvider,
    ShellPluginConfig,
    SidebarApp,
)

_SHELL_PLUGIN_CONFIG: ShellPluginConfig | None = None


def get_config_path() -> Path:
    return workspace.get_studio_state_dir() / "shell_plugin_config.json"


def get_shell_plugin_config() -> ShellPluginConfig:
    global _SHELL_PLUGIN_CONFIG
    if _SHELL_PLUGIN_CONFIG is not None:
        return _SHELL_PLUGIN_CONFIG
    path = get_config_path()
    if path.exists():
        try:
            _SHELL_PLUGIN_CONFIG = ShellPluginConfig.load(path)
            return _SHELL_PLUGIN_CONFIG
        except Exception:
            pass
    _SHELL_PLUGIN_CONFIG = ShellPluginConfig()
    return _SHELL_PLUGIN_CONFIG


def set_shell_plugin_config(config: ShellPluginConfig) -> None:
    global _SHELL_PLUGIN_CONFIG
    _SHELL_PLUGIN_CONFIG = config


def save_shell_plugin_config(config: ShellPluginConfig) -> None:
    config.save(get_config_path())


def serialize_action_button(button: ActionButton) -> dict[str, Any]:
    return {
        "id": button.id,
        "label": button.label,
        "action": button.action,
        "target": button.target,
        "icon": button.icon,
        "roles": button.roles,
    }


def serialize_sidebar_app(app: SidebarApp) -> dict[str, Any]:
    return {
        "id": app.id,
        "label": app.label,
        "icon": app.icon,
        "route": app.route,
        "roles": app.roles,
    }


def serialize_search_provider(provider: SearchProvider) -> dict[str, Any]:
    return {
        "id": provider.id,
        "label": provider.label,
        "handler": provider.handler,
        "roles": provider.roles,
    }
