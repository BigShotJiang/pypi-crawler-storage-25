"""Workspace and Project Management Service."""

import os
import re
from pathlib import Path


def get_project_root() -> Path:
    """Get the project root directory."""
    configured_root = os.environ.get("STUDIO_PROJECT_ROOT")
    if configured_root:
        explicit_root = Path(configured_root).expanduser().resolve()
        if explicit_root.exists():
            return explicit_root  # pragma: no cover

    cwd = Path.cwd()
    if (cwd / "src" / "doctypes").exists():
        return cwd
    if (cwd / "doctypes").exists():
        return cwd  # pragma: no cover
    if (cwd / "pyproject.toml").exists() or (cwd / ".git").exists():
        return cwd
    return cwd  # pragma: no cover


def get_studio_state_dir() -> Path:
    """Return Studio state directory for persisted UI configurations."""
    state_dir = get_project_root() / ".studio"
    state_dir.mkdir(parents=True, exist_ok=True)
    return state_dir


def detect_app_name(project_root: Path, explicit_app: str | None) -> str | None:
    if explicit_app:
        return explicit_app
    pyproject = project_root / "pyproject.toml"
    if not pyproject.exists():
        return None
    content = pyproject.read_text(encoding="utf-8")
    match = re.search(r'name\s*=\s*["\']([^"\']+)["\']', content)
    if not match:
        return None
    return match.group(1).replace("-", "_")


def resolve_doctype_target_dir(project_root: Path, app_name: str | None) -> Path:
    if app_name:
        namespace_dir = project_root / "src" / app_name / "doctypes"
        if namespace_dir.exists() or not (project_root / "src" / "doctypes").exists():
            return project_root / "src" / app_name
        return project_root / "src"
    target_dir = project_root / "src"
    return target_dir if target_dir.exists() else project_root
