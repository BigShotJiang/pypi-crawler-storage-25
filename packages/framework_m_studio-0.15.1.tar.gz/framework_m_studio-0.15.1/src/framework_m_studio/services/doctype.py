"""DocType Code Generation and I/O Service."""

import logging
import re
import shutil
from pathlib import Path

from framework_m_studio.codegen.generator import (
    generate_controller_source,
    generate_doctype_source,
    generate_init_source,
    generate_test_source,
)
from framework_m_studio.codegen.transformer import update_doctype
from framework_m_studio.discovery import scan_doctypes
from framework_m_studio.schemas import CreateDocTypeRequest


def sanitize_doctype_name(name: str) -> str:
    s = re.sub(r"[-\s]+", "_", name)
    s = re.sub(r"\W", "", s)
    parts = s.split("_")
    pascal = "".join((word[0].upper() + word[1:]) if word else "" for word in parts)
    return pascal or "DocType"


def to_snake_case(name: str) -> str:
    s1 = re.sub("(.)([A-Z][a-z]+)", r"\1_\2", name)
    return re.sub("([a-z0-9])([A-Z])", r"\1_\2", s1).lower()


def find_old_doctype_folder(project_root: Path, doctype_name: str) -> Path | None:
    for doctype in scan_doctypes(project_root):
        if doctype.name != doctype_name:
            continue
        old_file = Path(doctype.file_path)
        expected_folder = to_snake_case(doctype_name)
        if old_file.parent.name == expected_folder:
            return old_file.parent
        if old_file.exists():
            old_file.unlink()
        old_controller = old_file.parent / f"{old_file.stem}_controller.py"
        if old_controller.exists():
            old_controller.unlink()
        return None
    return None


def generate_doctype_code(schema: CreateDocTypeRequest) -> str:
    schema_dict = {
        "name": schema.name,
        "docstring": schema.docstring,
        "meta": schema.meta,
        "fields": [
            {
                "name": f.name,
                "type": f.type,
                "required": f.required,
                "label": f.label,
                "default": f.default,
                "description": f.description,
                "link_doctype": f.link_doctype,
                "table_doctype": f.table_doctype,
                "validators": {
                    "min_length": f.validators.min_length,
                    "max_length": f.validators.max_length,
                    "pattern": f.validators.pattern,
                    "min_value": f.validators.min_value,
                    "max_value": f.validators.max_value,
                }
                if f.validators
                else {},
            }
            for f in schema.fields
        ],
    }
    return str(generate_doctype_source(schema_dict))


def update_doctype_code(doctype_file: Path, schema: CreateDocTypeRequest) -> None:
    fields = []
    for f in schema.fields:
        field_type = f.type
        if field_type == "Link" and f.link_doctype:
            field_type = f'Annotated[str, Link("{f.link_doctype}")]'
        elif field_type == "Table" and f.table_doctype:
            field_type = f"list[{f.table_doctype}]"
        fields.append(
            {
                "name": f.name,
                "type": field_type,
                "required": f.required,
                "default": f.default,
            }
        )
    try:
        update_doctype(doctype_file, {"name": schema.name, "fields": fields})
    except Exception as e:
        logging.warning(f"Failed to mutate AST, regenerating from template: {e}")
        doctype_file.write_text(generate_doctype_code(schema), encoding="utf-8")


def write_doctype_artifacts(
    doctype_folder: Path,
    class_name: str,
    schema: CreateDocTypeRequest,
    project_root: Path,
    folder_name: str,
) -> None:
    doctype_file = doctype_folder / "doctype.py"
    if doctype_file.exists():
        update_doctype_code(doctype_file, schema)
    else:
        doctype_file.write_text(generate_doctype_code(schema), encoding="utf-8")
        (doctype_folder / "controller.py").write_text(
            generate_controller_source({"name": class_name, "meta": schema.meta or {}}),
            encoding="utf-8",
        )
        (doctype_folder / "__init__.py").write_text(
            generate_init_source(class_name), encoding="utf-8"
        )
    app_module = (schema.app or "myapp").replace("-", "_")
    schema_dict = {
        "name": class_name,
        "module": f"{app_module}.doctypes.{folder_name}",
        "fields": [f.model_dump() for f in schema.fields],
    }
    tests_dir = project_root / "tests" / "doctypes" / folder_name
    tests_dir.mkdir(parents=True, exist_ok=True)
    (tests_dir / f"test_{folder_name}.py").write_text(
        generate_test_source(schema_dict), encoding="utf-8"
    )


def cleanup_renamed_doctype_paths(
    project_root: Path, old_name: str, old_folder_path: Path | None
) -> None:
    if not old_folder_path or not old_folder_path.exists():
        return
    shutil.rmtree(old_folder_path)
    old_tests_dir = project_root / "tests" / "doctypes" / to_snake_case(old_name)
    if old_tests_dir.exists():
        shutil.rmtree(old_tests_dir)


def load_existing_doctype_source(name: str, project_root: Path) -> str:
    for doctype in scan_doctypes(project_root):
        if doctype.name == sanitize_doctype_name(name):
            file_path = Path(doctype.file_path)
            if file_path.exists():
                return file_path.read_text(encoding="utf-8")
            break
    return ""
