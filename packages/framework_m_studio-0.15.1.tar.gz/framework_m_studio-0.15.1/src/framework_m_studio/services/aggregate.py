"""Aggregate Root Configuration Service."""

import json
from pathlib import Path

from framework_m_studio.aggregate_builder import AggregateRootBuilder, LinkedDocType
from framework_m_studio.services import workspace

_AGGREGATE_BUILDER: AggregateRootBuilder | None = None


def get_config_path() -> Path:
    return workspace.get_studio_state_dir() / "aggregate_roots.json"


def get_aggregate_builder() -> AggregateRootBuilder:
    global _AGGREGATE_BUILDER
    if _AGGREGATE_BUILDER is not None:
        return _AGGREGATE_BUILDER
    builder = AggregateRootBuilder()
    path = get_config_path()
    if path.exists():
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
            for item in payload.get("roots", []):
                if root := item.get("root"):
                    builder.define(root)
                    for linked in item.get("linked", []):
                        builder.link(root, LinkedDocType(**linked))
        except Exception:
            pass
    _AGGREGATE_BUILDER = builder
    return builder


def save_aggregate_builder(builder: AggregateRootBuilder) -> None:
    data = {"roots": [builder.to_dict(root) for root in builder.list_roots()]}
    get_config_path().write_text(json.dumps(data, indent=2), encoding="utf-8")
