"""Ephemeral Workspace — Stateless Pod Lifecycle (§4.1).

Manages the lifecycle of a stateless Studio workspace:
1. Startup: Clone target git branch into emptyDir
2. In-memory drafts: Write to ephemeral disk for hot-reload
3. Draft sync: Push to studio-draft/[user] branch to prevent loss
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from framework_m_studio.git.protocol import GitAdapterProtocol


@dataclass
class StatelessConfig:
    """Configuration for a stateless Studio workspace.

    In K8s, these values are injected as environment variables.
    """

    git_url: str
    """Remote repository URL."""

    token: str
    """Authentication token for Git operations."""

    branch: str = "main"
    """Branch to clone and work on."""

    @classmethod
    def from_env(cls) -> StatelessConfig:
        """Read configuration from environment variables.

        Required:
            STUDIO_GIT_URL: Remote repository URL.

        Optional:
            STUDIO_GIT_TOKEN: Auth token (default: empty string).
            STUDIO_GIT_BRANCH: Branch name (default: 'main').

        Raises:
            ValueError: If STUDIO_GIT_URL is not set.

        Returns:
            StatelessConfig instance.
        """
        git_url = os.environ.get("STUDIO_GIT_URL")
        if not git_url:
            raise ValueError(
                "STUDIO_GIT_URL environment variable is required "
                "for stateless workspace configuration."
            )

        return cls(
            git_url=git_url,
            token=os.environ.get("STUDIO_GIT_TOKEN", ""),
            branch=os.environ.get("STUDIO_GIT_BRANCH", "main"),
        )


class EphemeralWorkspace:
    """Manages a stateless pod workspace lifecycle.

    Workflow:
    1. startup() → clone repo into emptyDir, checkout branch
    2. (user edits files via Studio)
    3. draft_sync() → push to studio-draft/[user] branch periodically
    """

    def __init__(
        self,
        git_adapter: GitAdapterProtocol,
        config: StatelessConfig,
        workspace_dir: Path,
    ) -> None:
        """Initialize EphemeralWorkspace.

        Args:
            git_adapter: Git adapter for clone/push operations.
            config: Stateless configuration from env vars.
            workspace_dir: Local directory (emptyDir in K8s).
        """
        self._git = git_adapter
        self._config = config
        self._workspace_dir = workspace_dir
        self._ready = False

    @property
    def is_ready(self) -> bool:
        """Whether the workspace has been initialized."""
        return self._ready

    @property
    def workspace_dir(self) -> Path:
        """The local workspace directory."""
        return self._workspace_dir

    async def startup(self) -> None:
        """Clone the repository and checkout the configured branch.

        This is called once when the pod starts. It clones the repo
        into the ephemeral directory and checks out the target branch.
        """
        await self._git.clone(
            self._config.git_url,
            self._workspace_dir,
            auth_token=self._config.token,
        )

        await self._git.checkout(
            self._workspace_dir,
            self._config.branch,
        )

        self._ready = True

    async def draft_sync(self, user: str) -> None:
        """Push local changes to a draft branch.

        Creates/updates a hidden ``studio-draft/[user]`` branch
        to prevent data loss on pod eviction.

        Args:
            user: Username for the draft branch.
        """
        draft_branch = f"studio-draft/{user}"

        await self._git.create_branch(
            self._workspace_dir,
            draft_branch,
            checkout=True,
        )

        await self._git.commit(
            self._workspace_dir,
            f"studio: auto-draft for {user}",
            author=user,
        )

        await self._git.push(
            self._workspace_dir,
            draft_branch,
        )
