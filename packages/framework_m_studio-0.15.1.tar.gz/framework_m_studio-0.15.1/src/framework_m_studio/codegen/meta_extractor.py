"""Meta Extractor - Parses Meta class configurations from LibCST nodes."""

from typing import Any

import libcst as cst

from framework_m_studio.codegen.annotation_parser import node_to_source


def parse_permissions_dict(value: str) -> dict[str, list[str]] | None:
    import ast

    try:
        parsed = ast.literal_eval(value)
        if isinstance(parsed, dict):
            return {k: v if isinstance(v, list) else [v] for k, v in parsed.items()}
    except (ValueError, SyntaxError):
        pass
    return None


def set_config_value(name: str, value: str | None, meta: Any) -> None:
    if value is None:
        return

    clean_value = value.strip("\"'")

    if name == "tablename":
        meta.tablename = clean_value
    elif name == "verbose_name":
        meta.verbose_name = clean_value
    elif name == "verbose_name_plural":
        meta.verbose_name_plural = clean_value
    elif name == "is_submittable":
        meta.is_submittable = value.lower() == "true"
    elif name == "is_tree":
        meta.is_tree = value.lower() == "true"
    elif name == "track_changes":
        meta.track_changes = value.lower() != "false"
    elif name == "permissions":
        meta.permissions = parse_permissions_dict(value)
    else:
        meta.extra[name] = clean_value


def parse_config_attribute(
    name: str, node: cst.AnnAssign | cst.Assign, meta: Any
) -> None:
    if isinstance(node, cst.AnnAssign):
        value = node_to_source(node.value) if node.value else None
        set_config_value(name, value, meta)
    elif isinstance(node, cst.Assign):
        value = node_to_source(node.value)
        set_config_value(name, value, meta)
