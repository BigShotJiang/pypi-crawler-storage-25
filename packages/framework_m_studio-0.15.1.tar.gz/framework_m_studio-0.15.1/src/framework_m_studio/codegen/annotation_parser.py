"""Annotation Parser - Extracts field metadata from LibCST annotation nodes."""

from typing import Any

import libcst as cst


def node_to_source(node: cst.CSTNode) -> str:
    """Convert CST node to source code string."""
    return cst.Module(body=[]).code_for_node(node)


def extract_annotated_metadata(
    type_node: cst.BaseExpression,
) -> tuple[str | None, str | None, str]:
    """Extract link_doctype, table_doctype, and base type from Annotated."""
    field_type = node_to_source(type_node)

    if isinstance(type_node, cst.BinaryOperation):
        left_link, left_table, left_type = extract_annotated_metadata(type_node.left)
        if left_link or left_table:
            return left_link, left_table, left_type
        right_link, right_table, right_type = extract_annotated_metadata(
            type_node.right
        )
        return right_link, right_table, right_type

    if isinstance(type_node, cst.Subscript):
        subscript_value = node_to_source(type_node.value)
        if subscript_value == "Annotated":
            slice_elements = type_node.slice
            if isinstance(slice_elements, tuple) and len(slice_elements) >= 1:
                first_elem = slice_elements[0]
                if isinstance(first_elem.slice, cst.Index):
                    base_type = node_to_source(first_elem.slice.value)
                else:
                    base_type = node_to_source(first_elem.slice)

                for elem in slice_elements[1:]:
                    value = (
                        elem.slice.value
                        if isinstance(elem.slice, cst.Index)
                        else elem.slice
                    )
                    if isinstance(value, cst.Call):
                        func_name = node_to_source(value.func)
                        if func_name == "Link" and value.args:
                            arg_value = node_to_source(value.args[0].value)
                            return arg_value.strip("\"'"), None, base_type
                        if func_name == "Table" and value.args:
                            arg_value = node_to_source(value.args[0].value)
                            return None, arg_value.strip("\"'"), base_type
                return None, None, base_type

    return None, None, field_type


def parse_field_call(
    node: cst.Call,
) -> tuple[str | None, dict[str, Any], str | None, str | None]:
    """Parse Field(...) call and extract default, validators, description, and label."""
    default_value: str | None = None
    validators: dict[str, Any] = {}
    description: str | None = None
    label: str | None = None

    for i, arg in enumerate(node.args):
        if arg.keyword is None and i == 0:
            default_value = node_to_source(arg.value)
            continue

        if isinstance(arg.keyword, cst.Name):
            key = arg.keyword.value
            value_str = node_to_source(arg.value)

            if key == "ge":
                val = float(value_str)
                validators["min_value"] = int(val) if val == int(val) else val
            elif key == "le":
                val = float(value_str)
                validators["max_value"] = int(val) if val == int(val) else val
            elif key == "gt":
                val = float(value_str)
                validators["min_value"] = int(val) + 1 if val == int(val) else val
            elif key == "lt":
                val = float(value_str)
                validators["max_value"] = int(val) - 1 if val == int(val) else val
            elif key == "min_length":
                validators["min_length"] = int(value_str)
            elif key == "max_length":
                validators["max_length"] = int(value_str)
            elif key in ("pattern", "regex"):
                pattern = value_str
                if pattern.startswith("r"):
                    pattern = pattern[1:]
                validators["pattern"] = pattern.strip("\"'")
            elif key == "description":
                description = value_str.strip("\"'")
            elif key == "label":
                label = value_str.strip("\"'")
            elif key == "default":
                default_value = value_str

    return default_value, validators, description, label
