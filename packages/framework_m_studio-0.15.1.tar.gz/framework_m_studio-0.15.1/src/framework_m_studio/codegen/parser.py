"""DocType Parser - LibCST-based Python file parser.

This module provides the `parse_doctype` function that extracts structured
information from DocType Python files, including:
- Class definition and bases
- Field definitions with types and defaults
- Config class metadata (tablename, verbose_name, etc.)
- Docstrings and comments

Strategy: "LibCST for parsing, Jinja for generation"
- LibCST preserves comments and formatting when modifying existing files
- Jinja templates provide clean scaffolding for new files

Usage:
    from framework_m_studio.codegen.parser import parse_doctype

    schema = parse_doctype("/path/to/todo.py")
    # Returns structured dict with class info, fields, config
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import libcst as cst

from framework_m_studio.codegen.annotation_parser import (
    extract_annotated_metadata,
    node_to_source,
    parse_field_call,
)
from framework_m_studio.codegen.meta_extractor import (
    parse_config_attribute,
    set_config_value,
)

# =============================================================================
# Data Models
# =============================================================================


@dataclass
class FieldSchema:
    """Parsed field information from a DocType class."""

    name: str
    type: str
    default: str | None = None
    required: bool = True
    description: str | None = None
    label: str | None = None
    link_doctype: str | None = None  # For Link fields - which DocType to link to
    table_doctype: str | None = None  # For Table fields - which DocType for child table
    validators: dict[str, Any] = field(default_factory=dict)


@dataclass
class MetaSchema:
    """Parsed Meta class metadata."""

    tablename: str | None = None
    verbose_name: str | None = None
    verbose_name_plural: str | None = None
    is_submittable: bool = False
    is_tree: bool = False
    track_changes: bool = True
    permissions: dict[str, list[str]] | None = None
    extra: dict[str, Any] = field(default_factory=dict)


@dataclass
class DocTypeSchema:
    """Complete parsed DocType schema."""

    name: str
    module: str
    file_path: str
    bases: list[str] = field(default_factory=list)
    fields: list[FieldSchema] = field(default_factory=list)
    meta: MetaSchema = field(default_factory=MetaSchema)
    docstring: str | None = None
    imports: list[str] = field(default_factory=list)
    custom_methods: list[str] = field(default_factory=list)


# =============================================================================
# LibCST Visitor for Complete DocType Parsing
# =============================================================================


class DocTypeParserVisitor(cst.CSTVisitor):
    """LibCST visitor to extract complete DocType information."""

    def __init__(self) -> None:
        self.doctypes: list[DocTypeSchema] = []
        self.imports: list[str] = []
        self._current_class: str | None = None
        self._current_bases: list[str] = []
        self._current_fields: list[FieldSchema] = []
        self._current_docstring: str | None = None
        self._current_meta: MetaSchema = MetaSchema()
        self._current_methods: list[str] = []
        self._in_meta_class: bool = False

    def visit_Import(self, node: cst.Import) -> bool:
        """Collect import statements."""
        self.imports.append(node_to_source(node))
        return False

    def visit_ImportFrom(self, node: cst.ImportFrom) -> bool:
        """Collect from imports."""
        self.imports.append(node_to_source(node))
        return False

    def visit_ClassDef(self, node: cst.ClassDef) -> bool:
        """Visit class definition."""
        class_name = node.name.value

        # Check if this is the Meta inner class
        if self._current_class and class_name in ("Config", "Meta"):
            self._in_meta_class = True
            return True

        # Get base classes
        bases: list[str] = []
        for arg in node.bases:
            if isinstance(arg.value, cst.Name):
                bases.append(arg.value.value)
            elif isinstance(arg.value, cst.Attribute):
                bases.append(_get_attribute_name(arg.value))

        # Check if this is a DocType
        is_doctype = any(
            base in ("BaseDocType", "DocType") or "DocType" in base for base in bases
        )

        if is_doctype:
            self._current_class = class_name
            self._current_bases = bases
            self._current_fields = []
            self._current_methods = []
            self._current_meta = MetaSchema()

            # Extract docstring
            self._current_docstring = _extract_docstring(node)

        return True

    def leave_ClassDef(self, node: cst.ClassDef) -> None:
        """Leave class definition."""
        class_name = node.name.value

        if class_name in ("Config", "Meta"):
            self._in_meta_class = False
            return

        if self._current_class == class_name:
            doctype = DocTypeSchema(
                name=self._current_class,
                module="",
                file_path="",
                bases=self._current_bases,
                fields=self._current_fields,
                meta=self._current_meta,
                docstring=self._current_docstring,
                imports=self.imports.copy(),
                custom_methods=self._current_methods,
            )
            self.doctypes.append(doctype)

            self._current_class = None
            self._current_bases = []
            self._current_fields = []
            self._current_docstring = None
            self._current_meta = MetaSchema()
            self._current_methods = []

    def visit_FunctionDef(self, node: cst.FunctionDef) -> bool:
        """Visit function/method definition."""
        if self._current_class and not self._in_meta_class:
            method_name = node.name.value
            if not method_name.startswith("_"):
                self._current_methods.append(method_name)
        return False

    def visit_AnnAssign(self, node: cst.AnnAssign) -> bool:
        """Visit annotated assignment (field definition)."""
        if self._current_class is None:
            return False

        if not isinstance(node.target, cst.Name):
            return False

        field_name = node.target.value

        # Meta class attributes
        if self._in_meta_class:
            parse_config_attribute(field_name, node, self._current_meta)
            return False

        # Skip private/dunder fields
        if field_name.startswith("_"):
            return False

        # Parse field
        field_type_raw = node.annotation.annotation
        field_type = node_to_source(field_type_raw)
        default_value: str | None = None
        required = node.value is None
        validators: dict[str, Any] = {}
        description: str | None = None
        label: str | None = None
        link_doctype, table_doctype, field_type = extract_annotated_metadata(
            field_type_raw
        )

        if (
            isinstance(field_type_raw, cst.Subscript)
            and node_to_source(field_type_raw.value) == "Annotated"
        ):
            slice_elements = field_type_raw.slice
            if isinstance(slice_elements, tuple) and len(slice_elements) >= 1:
                for elem in slice_elements[1:]:
                    value = (
                        elem.slice.value
                        if isinstance(elem.slice, cst.Index)
                        else elem.slice
                    )
                    if (
                        isinstance(value, cst.Call)
                        and node_to_source(value.func) == "Field"
                    ):
                        default_value, validators, description, label = (
                            parse_field_call(value)
                        )
                        if default_value == "...":
                            required = True
                            default_value = None
                        elif default_value is not None:
                            required = False

        # Check for Optional type
        if "Optional" in field_type or "None" in field_type:
            required = False

        # Handle Field() call in value (old style: field: type = Field(...))
        if node.value and isinstance(node.value, cst.Call):
            func_name = node_to_source(node.value.func)
            if func_name == "Field":
                default_value, validators, description, label = parse_field_call(
                    node.value
                )
                if default_value == "...":
                    required = True
                    default_value = None
                elif default_value is not None:
                    required = False
            else:
                default_value = node_to_source(node.value)
        elif node.value:
            default_value = node_to_source(node.value)

        # Override type for special field types
        if link_doctype:
            field_type = "Link"  # Frontend expects "Link" as the type
        elif table_doctype:
            field_type = "Table"  # Frontend expects "Table" as the type

        field_schema = FieldSchema(
            name=field_name,
            type=field_type,
            default=default_value,
            required=required,
            description=description,
            label=label,
            link_doctype=link_doctype,
            table_doctype=table_doctype,
            validators=validators,
        )
        self._current_fields.append(field_schema)

        return False

    def visit_Assign(self, node: cst.Assign) -> bool:
        """Visit simple assignment (for Meta class)."""
        if not self._in_meta_class:
            return False

        for target in node.targets:
            if isinstance(target.target, cst.Name):
                field_name = target.target.value
                value = node_to_source(node.value)
                set_config_value(field_name, value, self._current_meta)

        return False


# =============================================================================
# Helper Functions
# =============================================================================


def _get_attribute_name(node: cst.Attribute) -> str:
    """Get full attribute name from Attribute node."""
    parts: list[str] = []
    current: cst.BaseExpression = node

    while isinstance(current, cst.Attribute):
        parts.append(current.attr.value)
        current = current.value

    if isinstance(current, cst.Name):
        parts.append(current.value)

    return ".".join(reversed(parts))


def _extract_docstring(node: cst.ClassDef) -> str | None:
    """Extract docstring from class definition."""
    if not node.body or not node.body.body:
        return None

    first_stmt = node.body.body[0]
    if not isinstance(first_stmt, cst.SimpleStatementLine):
        return None

    if not first_stmt.body or not isinstance(first_stmt.body[0], cst.Expr):
        return None

    expr = first_stmt.body[0].value
    if isinstance(expr, cst.SimpleString):
        value = expr.value
        if value.startswith('"""') or value.startswith("'''"):
            return value[3:-3].strip()
        elif value.startswith('"') or value.startswith("'"):
            return value[1:-1].strip()
    elif isinstance(expr, cst.ConcatenatedString):
        # Handle multi-line docstrings
        parts = []
        for part in (expr.left, expr.right):
            if isinstance(part, cst.SimpleString):
                parts.append(part.value.strip("\"'"))
        return "".join(parts)

    return None


def _path_to_module(file_path: Path) -> str:
    """Convert file path to Python module path."""
    parts = file_path.parts
    try:
        src_idx = parts.index("src")
        module_parts = parts[src_idx + 1 : -1]
        module_name = file_path.stem
        return ".".join([*module_parts, module_name])
    except ValueError:
        return file_path.stem


# =============================================================================
# Public API
# =============================================================================


def parse_doctype(file_path: str | Path) -> dict[str, Any]:
    """Parse a DocType Python file and return structured schema.

    Args:
        file_path: Path to the Python file containing DocType

    Returns:
        Dictionary with keys:
        - name: DocType class name
        - module: Python module path
        - file_path: Absolute file path
        - bases: List of base class names
        - fields: List of field definitions
        - meta: Meta class metadata
        - docstring: Class docstring
        - imports: List of import statements
        - custom_methods: List of custom method names

    Raises:
        FileNotFoundError: If file doesn't exist
        ValueError: If no DocType found in file

    Example:
        >>> schema = parse_doctype("src/myapp/doctypes/todo.py")
        >>> schema["name"]
        'Todo'
        >>> schema["fields"][0]["name"]
        'title'
    """
    path = Path(file_path)
    if not path.exists():
        raise FileNotFoundError(f"File not found: {file_path}")

    source = path.read_text(encoding="utf-8")

    try:
        tree = cst.parse_module(source)
    except cst.ParserSyntaxError as e:  # pragma: no cover
        raise ValueError(f"Failed to parse Python file: {e}") from e  # pragma: no cover

    visitor = DocTypeParserVisitor()
    tree.visit(visitor)

    if not visitor.doctypes:
        raise ValueError(f"No DocType class found in {file_path}")  # pragma: no cover

    # Return the first DocType found
    doctype = visitor.doctypes[0]
    doctype.file_path = str(path.absolute())
    doctype.module = _path_to_module(path)

    return doctype_to_dict(doctype)


def doctype_to_dict(doctype: DocTypeSchema) -> dict[str, Any]:
    """Convert DocTypeSchema to dictionary."""
    return {
        "name": doctype.name,
        "module": doctype.module,
        "file_path": doctype.file_path,
        "bases": doctype.bases,
        "fields": [
            {
                "name": f.name,
                "type": f.type,
                "default": f.default,
                "required": f.required,
                "label": f.label,
                "description": f.description,
                "link_doctype": f.link_doctype,  # Include Link field metadata
                "table_doctype": f.table_doctype,  # Include Table field metadata
                "validators": f.validators,
            }
            for f in doctype.fields
        ],
        "meta": {
            "tablename": doctype.meta.tablename,
            "verbose_name": doctype.meta.verbose_name,
            "verbose_name_plural": doctype.meta.verbose_name_plural,
            "is_submittable": doctype.meta.is_submittable,
            "is_tree": doctype.meta.is_tree,
            "track_changes": doctype.meta.track_changes,
            "permissions": doctype.meta.permissions,
            **doctype.meta.extra,
        },
        "docstring": doctype.docstring,
        "imports": doctype.imports,
        "custom_methods": doctype.custom_methods,
    }


__all__ = [
    "DocTypeSchema",
    "FieldSchema",
    "MetaSchema",
    "doctype_to_dict",
    "parse_doctype",
]
