"""Schema Change Detection — Git-Powered Diff Analysis.

Compares the current UI-defined DocType schema against the last committed
Python source file to identify potential database migration issues.

The SchemaDiffEngine:
1. Parses a Python DocType source file using AST
2. Extracts field definitions (name, type, nullable, default, description)
3. Compares old vs new field sets
4. Classifies each change as SAFE, WARNING, or DANGEROUS

Classification Rules:
    SAFE: Adding a nullable field, adding a field with default, label change
    WARNING: Changing a description/label, adding an index
    DANGEROUS: Renaming a field, making a field required, dropping a column,
               changing a field type
"""

from __future__ import annotations

import ast
import re
from dataclasses import dataclass


@dataclass
class SchemaChange:
    """Describes a single schema change between two DocType versions."""

    field_name: str
    """The field that changed."""

    change_type: str
    """One of SAFE, WARNING, DANGEROUS."""

    description: str
    """Human-readable description of the change."""


@dataclass
class FieldInfo:
    """Extracted field information from a DocType class."""

    name: str
    """Field name."""

    type: str
    """Python type annotation as string."""

    nullable: bool
    """Whether the field accepts None."""

    has_default: bool
    """Whether the field has a default value."""

    description: str | None
    """Field description (from Field(..., description=...))."""


class SchemaDiffEngine:
    """Engine for comparing DocType schema versions.

    Uses Python AST to extract field definitions from source code,
    then compares fields between two versions to produce a list of
    classified SchemaChange instances.
    """

    def extract_fields(self, source: str) -> dict[str, dict[str, object]]:
        """Extract field definitions from Python DocType source.

        Parses the source with AST, finds the first class that inherits
        from BaseDocType, and extracts its annotated fields.

        Args:
            source: Python source code string.

        Returns:
            Dict of field_name → {type, nullable, has_default, description}.
        """
        tree = ast.parse(source)
        fields: dict[str, dict[str, object]] = {}

        for node in ast.walk(tree):
            if not isinstance(node, ast.ClassDef):
                continue

            # Look for classes that inherit from BaseDocType
            base_names = []
            for base in node.bases:
                if isinstance(base, ast.Name):
                    base_names.append(base.id)
                elif isinstance(base, ast.Attribute):
                    base_names.append(base.attr)

            if not any("DocType" in b for b in base_names):
                continue

            # Extract annotated assignments
            for stmt in node.body:
                if isinstance(stmt, ast.AnnAssign) and isinstance(
                    stmt.target, ast.Name
                ):
                    field_name = stmt.target.id
                    type_str = self._annotation_to_str(stmt.annotation)
                    nullable = "None" in type_str or "| None" in type_str
                    has_default = self._has_real_default(stmt.value)
                    description = self._extract_description(stmt.value)

                    fields[field_name] = {
                        "type": self._clean_type(type_str),
                        "nullable": nullable,
                        "has_default": has_default,
                        "description": description,
                    }

            # Only process the first DocType class found
            break

        return fields

    def diff(self, old_source: str, new_source: str) -> list[SchemaChange]:
        """Compare two DocType source versions and classify changes.

        Args:
            old_source: Python source of the previous version.
            new_source: Python source of the new version.

        Returns:
            List of SchemaChange instances.
        """
        old_fields = self.extract_fields(old_source)
        new_fields = self.extract_fields(new_source)

        changes: list[SchemaChange] = []

        old_names = set(old_fields.keys())
        new_names = set(new_fields.keys())

        # Dropped fields → DANGEROUS
        for name in old_names - new_names:
            changes.append(
                SchemaChange(
                    field_name=name,
                    change_type="DANGEROUS",
                    description=f"Field '{name}' was dropped. This will cause data loss.",
                )
            )

        # Added fields
        for name in new_names - old_names:
            info = new_fields[name]
            if info["nullable"] or info["has_default"]:
                changes.append(
                    SchemaChange(
                        field_name=name,
                        change_type="SAFE",
                        description=(
                            f"Field '{name}' was added with "
                            f"{'nullable' if info['nullable'] else 'default value'}."
                        ),
                    )
                )
            else:
                changes.append(
                    SchemaChange(
                        field_name=name,
                        change_type="DANGEROUS",
                        description=(
                            f"Field '{name}' was added as required "
                            "without a default. Existing rows will fail."
                        ),
                    )
                )

        # Modified fields
        for name in old_names & new_names:
            old = old_fields[name]
            new = new_fields[name]

            # Nullable → required change → DANGEROUS
            if old["nullable"] and not new["nullable"]:
                changes.append(
                    SchemaChange(
                        field_name=name,
                        change_type="DANGEROUS",
                        description=(
                            f"Field '{name}' was made required "
                            "(nullable → non-nullable). Existing NULL values will fail."
                        ),
                    )
                )
            # Base type change → DANGEROUS
            elif old["type"] != new["type"]:
                old_base = self._clean_type(str(old["type"]))
                new_base = self._clean_type(str(new["type"]))
                if old_base != new_base:
                    changes.append(
                        SchemaChange(
                            field_name=name,
                            change_type="DANGEROUS",
                            description=(
                                f"Field '{name}' type changed from "
                                f"'{old['type']}' to '{new['type']}'."
                            ),
                        )
                    )

            # Description/label change → WARNING
            if old["description"] != new["description"] and old["type"] == new["type"]:
                changes.append(
                    SchemaChange(
                        field_name=name,
                        change_type="WARNING",
                        description=(
                            f"Field '{name}' description changed from "
                            f"'{old['description']}' to '{new['description']}'."
                        ),
                    )
                )

        return changes

    # ─── Private helpers ──────────────────────────────────────────────────

    def _annotation_to_str(self, node: ast.expr) -> str:
        """Convert an AST annotation node to a string representation."""
        return ast.unparse(node)

    def _clean_type(self, type_str: str) -> str:
        """Remove Optional/None annotations to get the base type."""
        cleaned = type_str.replace(" | None", "").replace("None | ", "")
        cleaned = re.sub(r"Optional\[(.+)\]", r"\1", cleaned)
        return cleaned.strip()

    def _extract_description(self, value: ast.expr | None) -> str | None:
        """Extract description from a Field(..., description='...') call."""
        if value is None:
            return None

        if isinstance(value, ast.Call):
            for kw in value.keywords:
                if kw.arg == "description" and isinstance(kw.value, ast.Constant):
                    return str(kw.value.value)

        return None

    def _has_real_default(self, value: ast.expr | None) -> bool:
        """Check if a field assignment has a real default value.

        Distinguishes between:
        - Field(default=...) or Field(default_factory=...) → True
        - Field(description=...) without default → False
        - Literal value (e.g. "draft") → True
        """
        if value is None:
            return False

        if isinstance(value, ast.Constant):
            return True

        if isinstance(value, ast.Call):
            for kw in value.keywords:
                if kw.arg in ("default", "default_factory"):
                    return True
            # Check for positional default argument
            # Field("default_value", ...)
            if value.args:
                return True

        return False
