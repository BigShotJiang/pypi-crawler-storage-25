"""Visual Designer — WYSIWYG Form Layout Data Models (§6.1).

Provides data models for the form layout designer:
1. FormLayoutDesigner: sections, fields, drag-drop reordering
2. ChildTableDesigner: Grid/List/Card modes, field visibility
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class FormSection:
    """A section in a form layout."""

    label: str
    """Section label."""

    fields: list[str]
    """Ordered list of field names in this section."""

    collapsed: bool = False
    """Whether the section is collapsed by default."""


@dataclass
class ChildTableConfig:
    """Configuration for a child table in a DocType form."""

    display_mode: str = "Grid"
    """Display mode: 'Grid', 'List', or 'Card'."""

    field_visibility: dict[str, dict[str, bool]] = field(default_factory=dict)
    """Per-field visibility: {field_name: {grid: bool, detail: bool}}."""


class FormLayoutDesigner:
    """Drag-drop form layout manager.

    Manages sections and field ordering for a DocType form.
    Produces a layout dict consumed by the frontend.
    """

    def __init__(self, doctype: str) -> None:
        """Initialize designer for a DocType.

        Args:
            doctype: DocType name.
        """
        self._doctype = doctype
        self._sections: list[FormSection] = []

    def get_sections(self) -> list[FormSection]:
        """Get all sections in order.

        Returns:
            List of FormSection objects.
        """
        return list(self._sections)

    def add_section(self, section: FormSection) -> None:
        """Add a section to the layout.

        Args:
            section: FormSection to add.
        """
        self._sections.append(section)

    def remove_section(self, label: str) -> None:
        """Remove a section by label.

        Args:
            label: Section label to remove.
        """
        self._sections = [s for s in self._sections if s.label != label]

    def move_section(self, label: str, position: int) -> None:
        """Move a section to a new position.

        Args:
            label: Section label to move.
            position: New 0-based index.
        """
        section = next((s for s in self._sections if s.label == label), None)
        if section is not None:
            self._sections.remove(section)
            self._sections.insert(position, section)

    def reorder_fields(self, section_label: str, field_order: list[str]) -> None:
        """Reorder fields within a named section.

        Args:
            section_label: Section label.
            field_order: New field order.
        """
        for section in self._sections:
            if section.label == section_label:
                section.fields = field_order
                break

    def to_layout_dict(self) -> dict[str, Any]:
        """Export layout as serializable dict.

        Returns:
            Dict with 'doctype' and 'sections' keys.
        """
        return {
            "doctype": self._doctype,
            "sections": [
                {
                    "label": s.label,
                    "fields": s.fields,
                    "collapsed": s.collapsed,
                }
                for s in self._sections
            ],
        }


class ChildTableDesigner:
    """Configures child table display modes and field visibility.

    Each child table (identified by doctype + field_name) can have:
    - Display mode: Grid (inline), List, or Card
    - Per-field visibility for grid view vs detail popover
    """

    def __init__(self) -> None:
        """Initialize with empty configs."""
        self._configs: dict[str, dict[str, ChildTableConfig]] = {}

    def get_config(self, doctype: str, field_name: str) -> ChildTableConfig:
        """Get child table config.

        Args:
            doctype: Parent DocType name.
            field_name: Child table field name.

        Returns:
            ChildTableConfig (default Grid mode if not configured).
        """
        return self._configs.get(doctype, {}).get(field_name, ChildTableConfig())

    def set_display_mode(
        self,
        doctype: str,
        field_name: str,
        mode: str,
    ) -> None:
        """Set the display mode for a child table.

        Args:
            doctype: Parent DocType name.
            field_name: Child table field name.
            mode: 'Grid', 'List', or 'Card'.
        """
        config = self._ensure_config(doctype, field_name)
        config.display_mode = mode

    def set_field_visibility(
        self,
        doctype: str,
        field_name: str,
        child_field: str,
        visible_in_grid: bool = True,
        visible_in_detail: bool = True,
    ) -> None:
        """Set visibility for a child table field.

        Args:
            doctype: Parent DocType name.
            field_name: Child table field name.
            child_field: Field within the child table.
            visible_in_grid: Show in grid/inline view.
            visible_in_detail: Show in detail popover.
        """
        config = self._ensure_config(doctype, field_name)
        config.field_visibility[child_field] = {
            "grid": visible_in_grid,
            "detail": visible_in_detail,
        }

    def _ensure_config(self, doctype: str, field_name: str) -> ChildTableConfig:
        """Get or create config for a child table."""
        if doctype not in self._configs:
            self._configs[doctype] = {}
        if field_name not in self._configs[doctype]:
            self._configs[doctype][field_name] = ChildTableConfig()
        return self._configs[doctype][field_name]
