"""Aggregate Root Builder — Multi-DocType Linking (§6.2).

Visual builder for linking related DocTypes into aggregate views
with configurable save cascade behavior.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class LinkedDocType:
    """A DocType linked to an aggregate root."""

    doctype: str
    """Child/related DocType name."""

    link_field: str
    """Field in the child that references the root."""

    cascade: str = "save_delete"
    """Cascade mode: 'save_delete', 'save_only', or 'none'."""


@dataclass
class AggregateConfig:
    """Configuration for an aggregate root."""

    root: str
    """Root DocType name."""

    linked: list[LinkedDocType] = field(default_factory=list)
    """Linked (child) DocTypes."""


class AggregateRootBuilder:
    """Builder for defining aggregate root relationships.

    An aggregate root groups related DocTypes into a single
    conceptual unit with configurable save cascade behavior.

    Example:
        builder = AggregateRootBuilder()
        builder.define("SalesOrder")
        builder.link("SalesOrder", LinkedDocType(
            doctype="SalesOrderItem",
            link_field="parent_order",
            cascade="save_delete",
        ))
    """

    def __init__(self) -> None:
        """Initialize with no aggregate roots."""
        self._configs: dict[str, AggregateConfig] = {}

    def define(self, root_doctype: str) -> None:
        """Define a new aggregate root.

        Args:
            root_doctype: Root DocType name.
        """
        self._configs[root_doctype] = AggregateConfig(root=root_doctype)

    def link(self, root_doctype: str, linked: LinkedDocType) -> None:
        """Link a child DocType to an aggregate root.

        Args:
            root_doctype: Root DocType name.
            linked: LinkedDocType configuration.
        """
        config = self._configs.get(root_doctype)
        if config is not None:
            config.linked.append(linked)

    def unlink(self, root_doctype: str, child_doctype: str) -> None:
        """Remove a linked DocType from an aggregate.

        Args:
            root_doctype: Root DocType name.
            child_doctype: Child DocType name to remove.
        """
        config = self._configs.get(root_doctype)
        if config is not None:
            config.linked = [
                linked for linked in config.linked if linked.doctype != child_doctype
            ]

    def get_config(self, root_doctype: str) -> AggregateConfig | None:
        """Get aggregate config for a root DocType.

        Args:
            root_doctype: Root DocType name.

        Returns:
            AggregateConfig or None if not defined.
        """
        return self._configs.get(root_doctype)

    def list_roots(self) -> list[str]:
        """List all defined aggregate roots.

        Returns:
            List of root DocType names.
        """
        return list(self._configs.keys())

    def to_dict(self, root_doctype: str) -> dict[str, Any]:
        """Export aggregate config as serializable dict.

        Args:
            root_doctype: Root DocType name.

        Returns:
            Dict with 'root' and 'linked' keys.
        """
        config = self._configs.get(root_doctype)
        if config is None:
            return {}
        return {
            "root": config.root,
            "linked": [
                {
                    "doctype": linked.doctype,
                    "link_field": linked.link_field,
                    "cascade": linked.cascade,
                }
                for linked in config.linked
            ],
        }
