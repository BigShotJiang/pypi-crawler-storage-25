## Typing stubs for pysftp

This is a [type stub package](https://typing.python.org/en/latest/tutorials/external_libraries.html)
for the [`pysftp`](https://bitbucket.org/dundeemt/pysftp) package. It can be used by type checkers
to check code that uses `pysftp`. This version of
`types-pysftp` aims to provide accurate annotations for
`pysftp==0.2.*`.

This package is part of the [typeshed project](https://github.com/python/typeshed).
All fixes for types and metadata should be contributed there.
See [the README](https://github.com/python/typeshed/blob/main/README.md)
for more details. The source for this package can be found in the
[`stubs/pysftp`](https://github.com/python/typeshed/tree/main/stubs/pysftp)
directory.

This package was tested with the following type checkers:
* [mypy](https://github.com/python/mypy/) 2.1.0
* [pyright](https://github.com/microsoft/pyright) 1.1.409

It was generated from typeshed commit
[`3402466d17144ed7edfc92940c6973167ba285af`](https://github.com/python/typeshed/commit/3402466d17144ed7edfc92940c6973167ba285af).