"""Public facade exports for building agentic applications."""

from comate_agent_sdk.facade import (
    Agent,
    AgentConfigError,
    AgentConnectionError,
    AgentError,
    AgentExecutionError,
    AgentTimeoutError,
    Event,
    SessionInfo,
    SessionMessage,
    StopEvent,
    TextEvent,
    ToolUseEvent,
    UserQuestionEvent,
    YieldEvent,
    get_session_messages,
    list_sessions,
    run_agent,
    run_agent_async,
)

__all__ = [
    # 核心 API
    "Agent",
    "run_agent",
    "run_agent_async",
    # 事件
    "Event",
    "TextEvent",
    "ToolUseEvent",
    "YieldEvent",
    "StopEvent",
    "UserQuestionEvent",
    # 错误 (兼容性)
    "AgentError",
    "AgentConfigError",
    "AgentConnectionError",
    "AgentExecutionError",
    "AgentTimeoutError",
    # Session query
    "list_sessions",
    "get_session_messages",
    "SessionInfo",
    "SessionMessage",
]
