from __future__ import annotations

import asyncio
import os
import time
import warnings
from contextlib import asynccontextmanager
from types import SimpleNamespace
from types import MethodType

import pytest

from comate_agent_sdk.mcp import create_sdk_mcp_server, mcp_tool
from comate_agent_sdk.mcp.manager import McpManager
from comate_agent_sdk.mcp import manager as manager_module


def _build_calc_server():
    @mcp_tool(name="add", description="Add two numbers")
    async def add(a: float, b: float) -> str:
        return f"Sum: {a + b}"

    return create_sdk_mcp_server(name="calculator", tools=[add])


def test_mcp_manager_aclose_idempotent() -> None:
    async def _run() -> None:
        manager = McpManager({"calc": _build_calc_server()})

        await manager.start()
        assert any(t.name == "mcp__calc__add" for t in manager.tools)

        await manager.aclose()
        await manager.aclose()

        assert manager.tools == []
        assert manager.tool_infos == []

    asyncio.run(_run())


def test_mcp_manager_concurrent_start() -> None:
    async def _run() -> None:
        manager = McpManager({"calc": _build_calc_server()})

        await asyncio.gather(manager.start(), manager.start(), manager.start())
        assert any(t.name == "mcp__calc__add" for t in manager.tools)

        await manager.aclose()

    asyncio.run(_run())


def test_mcp_manager_context_enter_exit_in_same_task() -> None:
    async def _run() -> None:
        manager = McpManager({"fake": {"type": "http", "url": "http://example.test"}})  # type: ignore[arg-type]

        task_state: dict[str, asyncio.Task[None] | None] = {
            "enter": None,
            "exit": None,
        }

        @asynccontextmanager
        async def _fake_connect(_self: McpManager, _alias: str, _cfg: dict[str, str]):
            task_state["enter"] = asyncio.current_task()
            yield object()
            task_state["exit"] = asyncio.current_task()

        async def _fake_list_all_tools(_self: McpManager, _session: object):
            return []

        manager._connect = MethodType(_fake_connect, manager)  # type: ignore[method-assign]
        manager._list_all_tools = MethodType(_fake_list_all_tools, manager)  # type: ignore[method-assign]

        await manager.start()
        await manager.aclose()

        assert task_state["enter"] is not None
        assert task_state["exit"] is not None
        assert task_state["enter"] is task_state["exit"]

    asyncio.run(_run())


def test_mcp_manager_parallel_start_preserves_server_order() -> None:
    async def _run() -> None:
        manager = McpManager(
            {
                "slow": {"type": "http", "url": "http://slow.test"},
                "fast": {"type": "http", "url": "http://fast.test"},
            }
        )  # type: ignore[arg-type]

        delays = {"slow": 0.12, "fast": 0.03}

        @asynccontextmanager
        async def _fake_connect(self: McpManager, alias: str, _cfg: dict[str, str]):
            await asyncio.sleep(delays[alias])
            yield alias

        async def _fake_list_all_tools(self: McpManager, session: str):
            return [
                SimpleNamespace(
                    name=f"{session}_tool",
                    description=f"{session} description",
                    inputSchema={"type": "object", "properties": {}},
                )
            ]

        manager._connect = MethodType(_fake_connect, manager)  # type: ignore[method-assign]
        manager._list_all_tools = MethodType(_fake_list_all_tools, manager)  # type: ignore[method-assign]

        started = time.monotonic()
        await manager.start()
        elapsed = time.monotonic() - started

        assert elapsed < 0.18
        assert [info.server_alias for info in manager.tool_infos] == ["slow", "fast"]
        assert [tool.name for tool in manager.tools] == [
            "mcp__slow__slow_tool",
            "mcp__fast__fast_tool",
        ]

        await manager.aclose()

    asyncio.run(_run())


def test_mcp_manager_start_timeout_cleanup(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(manager_module, "_START_TIMEOUT_S", 0.05)
    monkeypatch.setattr(manager_module, "_START_SAFETY_BUFFER_S", 0.05)
    monkeypatch.setattr(manager_module, "_SHUTDOWN_TIMEOUT_S", 0.05)

    async def _never_init(self: McpManager) -> None:
        await asyncio.Event().wait()

    async def _run() -> None:
        manager = McpManager({"calc": _build_calc_server()})
        manager._run_lifecycle = MethodType(_never_init, manager)  # type: ignore[method-assign]

        with pytest.raises(asyncio.TimeoutError):
            await manager.start()

        assert manager._lifecycle_task is None
        assert manager.tools == []
        assert manager.tool_infos == []

    asyncio.run(_run())


def test_mcp_manager_start_propagates_init_error(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(manager_module, "_START_TIMEOUT_S", 0.1)
    monkeypatch.setattr(manager_module, "_SHUTDOWN_TIMEOUT_S", 0.1)

    async def _raise_during_init(self: McpManager) -> None:
        init_done = self._init_done
        err = RuntimeError("init boom")
        if init_done is not None and not init_done.done():
            init_done.set_exception(err)
        raise err

    async def _run() -> None:
        manager = McpManager({"calc": _build_calc_server()})
        manager._run_lifecycle = MethodType(_raise_during_init, manager)  # type: ignore[method-assign]

        with pytest.raises(RuntimeError, match="init boom"):
            await manager.start()

        assert manager._lifecycle_task is None
        assert manager.tools == []
        assert manager.tool_infos == []

    asyncio.run(_run())


def test_mcp_manager_partial_server_failures_do_not_block_healthy_server() -> None:
    async def _run() -> None:
        servers = {
            "bad-http": {"type": "http", "url": ""},
            "calc": _build_calc_server(),
        }
        manager = McpManager(servers)  # type: ignore[arg-type]

        await manager.start()
        tool_names = [t.name for t in manager.tools]
        assert "mcp__calc__add" in tool_names

        # 验证失败 server 被记录
        failed_aliases = [alias for alias, _ in manager.failed_servers]
        assert "bad-http" in failed_aliases

        await manager.aclose()

    asyncio.run(_run())


def test_mcp_manager_aclose_returns_when_cancelled_task_still_hangs(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(manager_module, "_SHUTDOWN_TIMEOUT_S", 0.05)
    monkeypatch.setattr(manager_module, "_SHUTDOWN_CANCEL_TIMEOUT_S", 0.05)

    async def _run() -> None:
        manager = McpManager({})
        stop_event = asyncio.Event()

        async def _stubborn_lifecycle() -> None:
            while True:
                if stop_event.is_set():
                    return
                try:
                    await stop_event.wait()
                    return
                except asyncio.CancelledError:
                    # Simulate底层 TaskGroup 取消后仍无法快速退出。
                    continue

        stubborn_task = asyncio.create_task(
            _stubborn_lifecycle(),
            name="test-mcp-stubborn-lifecycle",
        )
        manager._lifecycle_task = stubborn_task
        manager._shutdown_event = asyncio.Event()

        started = time.monotonic()
        await manager.aclose()
        elapsed = time.monotonic() - started

        assert elapsed < 0.3
        assert manager._lifecycle_task is None
        assert manager.tools == []
        assert manager.tool_infos == []

        stop_event.set()
        await asyncio.wait_for(stubborn_task, timeout=0.2)

    asyncio.run(_run())


def test_mcp_manager_stdio_connect_suppresses_child_stderr(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    captured: dict[str, object] = {}

    @asynccontextmanager
    async def _fake_stdio_client(_params, errlog):  # type: ignore[no-untyped-def]
        captured["errlog"] = errlog
        yield object(), object()

    class _FakeSession:
        def __init__(self, *_args, **_kwargs) -> None:
            self.initialized = False

        async def __aenter__(self) -> "_FakeSession":
            return self

        async def __aexit__(self, exc_type, exc, tb) -> None:
            del exc_type, exc, tb

        async def initialize(self) -> None:
            self.initialized = True

    async def _run() -> None:
        manager = McpManager({"ctx7": {"type": "stdio", "command": "dummy"}})  # type: ignore[arg-type]
        monkeypatch.setattr(manager_module, "stdio_client", _fake_stdio_client)
        monkeypatch.setattr(manager_module, "ClientSession", _FakeSession)

        async with manager._connect(
            "ctx7",
            {"type": "stdio", "command": "dummy"},  # type: ignore[arg-type]
        ) as session:
            assert isinstance(session, _FakeSession)
            assert session.initialized is True

    asyncio.run(_run())

    errlog = captured.get("errlog")
    assert errlog is not None
    assert getattr(errlog, "name", None) == os.devnull


def test_mcp_manager_http_connect_with_headers_does_not_require_shared_exit_stack(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    captured: dict[str, object] = {}

    class _FakeAsyncClient:
        def __init__(self, *, headers=None, timeout=None) -> None:
            captured["headers"] = headers
            captured["timeout"] = timeout

        async def __aenter__(self) -> "_FakeAsyncClient":
            captured["entered"] = True
            return self

        async def __aexit__(self, exc_type, exc, tb) -> None:
            del exc_type, exc, tb
            captured["exited"] = True

    @asynccontextmanager
    async def _fake_streamable_http_client(url: str, http_client=None):  # type: ignore[no-untyped-def]
        captured["url"] = url
        captured["http_client"] = http_client
        yield object(), object(), lambda: "session-id"

    class _FakeSession:
        def __init__(self, *_args, **_kwargs) -> None:
            self.initialized = False

        async def __aenter__(self) -> "_FakeSession":
            return self

        async def __aexit__(self, exc_type, exc, tb) -> None:
            del exc_type, exc, tb

        async def initialize(self) -> None:
            self.initialized = True

    async def _run() -> None:
        manager = McpManager(
            {
                "ctx7": {
                    "type": "http",
                    "url": "https://example.test/mcp",
                    "headers": {"Authorization": "Bearer token"},
                }
            }
        )  # type: ignore[arg-type]
        monkeypatch.setattr(manager_module.httpx, "AsyncClient", _FakeAsyncClient)
        monkeypatch.setattr(
            manager_module,
            "streamable_http_client",
            _fake_streamable_http_client,
        )
        monkeypatch.setattr(manager_module, "ClientSession", _FakeSession)

        async with manager._connect(
            "ctx7",
            {
                "type": "http",
                "url": "https://example.test/mcp",
                "headers": {"Authorization": "Bearer token"},
            },  # type: ignore[arg-type]
        ) as session:
            assert session.initialized is True

        assert captured["url"] == "https://example.test/mcp"
        assert captured["headers"] == {"Authorization": "Bearer token"}
        assert captured["entered"] is True
        assert captured["exited"] is True

    asyncio.run(_run())


def test_mcp_manager_list_tools_timeout(monkeypatch: pytest.MonkeyPatch) -> None:
    """_list_all_tools hang should result in failed_servers, not infinite block."""
    monkeypatch.setattr(manager_module, "_START_TIMEOUT_S", 0.5)

    async def _run() -> None:
        manager = McpManager(
            {"hang": {"type": "http", "url": "http://hang.test"}},
            connect_timeout_s=0.1,
        )  # type: ignore[arg-type]

        @asynccontextmanager
        async def _fake_connect(self, alias, cfg):
            yield object()

        async def _hanging_list_all_tools(self, session):
            await asyncio.Event().wait()  # hang forever
            return []  # unreachable

        manager._connect = MethodType(_fake_connect, manager)  # type: ignore[method-assign]
        manager._list_all_tools = MethodType(_hanging_list_all_tools, manager)  # type: ignore[method-assign]

        await manager.start()

        assert manager.tools == []
        assert len(manager.failed_servers) == 1
        alias, reason = manager.failed_servers[0]
        assert alias == "hang"
        assert "list_tools timed out" in reason

        await manager.aclose()

    asyncio.run(_run())


def test_friendly_error_message_unwraps_exception_group() -> None:
    """ExceptionGroup should be unwrapped to show the root cause, not the raw repr."""
    manager = McpManager({})
    cfg: dict[str, str] = {"type": "http", "url": "http://example.test"}

    # Single sub-exception
    inner = ConnectionRefusedError("Connection refused")
    eg = ExceptionGroup("unhandled errors in a TaskGroup", [inner])
    result = manager._friendly_error_message("ctx7", cfg, eg)  # type: ignore[arg-type]
    assert "cannot connect to server" in result
    assert "ExceptionGroup" not in result

    # Nested ExceptionGroup
    inner_timeout = TimeoutError("timed out")
    nested_eg = ExceptionGroup("inner", [inner_timeout])
    outer_eg = ExceptionGroup("outer", [nested_eg])
    result2 = manager._friendly_error_message("ctx7", cfg, outer_eg)  # type: ignore[arg-type]
    assert "timed out" in result2
    assert "ExceptionGroup" not in result2


def test_friendly_error_message_session_terminated_shows_url() -> None:
    """McpError 'Session terminated' (HTTP 404) should hint at wrong URL path."""
    manager = McpManager({})
    cfg: dict[str, str] = {"type": "http", "url": "https://mcp.example.com/"}

    # Simulate what upstream MCP SDK raises on HTTP 404 during initialize
    from mcp.shared.exceptions import McpError
    from mcp.types import ErrorData

    exc = McpError(ErrorData(code=32600, message="Session terminated"))
    result = manager._friendly_error_message("ctx7", cfg, exc)  # type: ignore[arg-type]
    assert "404" in result
    assert "URL" in result or "url" in result.lower()
    assert "https://mcp.example.com/" in result
    assert "McpError" not in result


def test_friendly_error_message_session_terminated_unwraps_from_exception_group() -> None:
    """Session terminated wrapped in ExceptionGroup should also produce friendly hint."""
    manager = McpManager({})
    cfg: dict[str, str] = {"type": "http", "url": "https://mcp.example.com/wrong"}

    from mcp.shared.exceptions import McpError
    from mcp.types import ErrorData

    inner = McpError(ErrorData(code=32600, message="Session terminated"))
    eg = ExceptionGroup("unhandled errors in a TaskGroup", [inner])
    result = manager._friendly_error_message("ctx7", cfg, eg)  # type: ignore[arg-type]
    assert "404" in result
    assert "https://mcp.example.com/wrong" in result


def test_mcp_manager_partial_timeout_returns_successful_tools(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """One server hangs past deadline; healthy server's tools must still be available."""
    monkeypatch.setattr(manager_module, "_START_TIMEOUT_S", 0.3)

    async def _run() -> None:
        manager = McpManager(
            {
                "good": {"type": "http", "url": "http://good.test"},
                "slow": {"type": "http", "url": "http://slow.test"},
            },
            connect_timeout_s=5.0,
        )  # type: ignore[arg-type]

        @asynccontextmanager
        async def _fake_connect(self, alias, cfg):
            if alias == "slow":
                await asyncio.sleep(10)  # hang way past deadline
            yield alias

        async def _fake_list_all_tools(self, session):
            return [
                SimpleNamespace(
                    name=f"{session}_tool",
                    description=f"{session} desc",
                    inputSchema={"type": "object", "properties": {}},
                )
            ]

        manager._connect = MethodType(_fake_connect, manager)  # type: ignore[method-assign]
        manager._list_all_tools = MethodType(_fake_list_all_tools, manager)  # type: ignore[method-assign]

        await manager.start()

        tool_names = [t.name for t in manager.tools]
        assert "mcp__good__good_tool" in tool_names

        failed_aliases = [alias for alias, _ in manager.failed_servers]
        assert "slow" in failed_aliases

        await manager.aclose()

    asyncio.run(_run())


def test_mcp_manager_all_servers_timeout_returns_empty_tools(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """All servers hang past deadline; start() must return normally with empty tools."""
    monkeypatch.setattr(manager_module, "_START_TIMEOUT_S", 0.2)

    async def _run() -> None:
        manager = McpManager(
            {
                "a": {"type": "http", "url": "http://a.test"},
                "b": {"type": "http", "url": "http://b.test"},
            },
            connect_timeout_s=5.0,
        )  # type: ignore[arg-type]

        @asynccontextmanager
        async def _hang_connect(self, alias, cfg):
            await asyncio.sleep(10)
            yield alias

        async def _fake_list(self, session):
            return []

        manager._connect = MethodType(_hang_connect, manager)  # type: ignore[method-assign]
        manager._list_all_tools = MethodType(_fake_list, manager)  # type: ignore[method-assign]

        await manager.start()

        assert manager.tools == []
        assert len(manager.failed_servers) == 2
        failed_aliases = {alias for alias, _ in manager.failed_servers}
        assert failed_aliases == {"a", "b"}

        await manager.aclose()

    asyncio.run(_run())


def test_mcp_manager_aclose_no_coroutine_warnings(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """aclose() must not produce 'coroutine ignored GeneratorExit' warnings."""
    monkeypatch.setattr(manager_module, "_START_TIMEOUT_S", 0.5)
    monkeypatch.setattr(manager_module, "_SHUTDOWN_TIMEOUT_S", 0.5)
    monkeypatch.setattr(manager_module, "_SHUTDOWN_CANCEL_TIMEOUT_S", 0.3)

    async def _run() -> None:
        manager = McpManager({"calc": _build_calc_server()})
        await manager.start()
        assert len(manager.tools) > 0

        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            await manager.aclose()

        coroutine_warnings = [
            w for w in caught
            if "coroutine" in str(w.message).lower()
            or "GeneratorExit" in str(w.message)
        ]
        assert coroutine_warnings == [], (
            f"Unexpected coroutine warnings: {[str(w.message) for w in coroutine_warnings]}"
        )

    asyncio.run(_run())
