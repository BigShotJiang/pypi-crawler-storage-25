"""REPL — chat with an AI assistant that has tools."""

import asyncio
import random
from datetime import datetime
from dotenv import load_dotenv
from oaf.agent import Agent
from oaf.tools import ToolRegistry

load_dotenv()

registry = ToolRegistry()


@registry.register
async def get_time() -> str:
    """Get the current date and time."""
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


@registry.register
async def calculate(expression: str) -> str:
    """Evaluate a math expression. Example: '2 + 3 * 4'"""
    allowed = set("0123456789+-*/.() ")
    if not all(c in allowed for c in expression):
        return "Error: only numbers and +-*/.() are allowed"
    return str(eval(expression))  # safe: only digits and math ops


@registry.register
async def roll_dice(sides: int = 6, count: int = 1) -> str:
    """Roll dice. Returns the results and total."""
    rolls = [random.randint(1, int(sides)) for _ in range(int(count))]
    return f"Rolls: {rolls}, Total: {sum(rolls)}"


@registry.register
async def flip_coin() -> str:
    """Flip a coin. Returns heads or tails."""
    return random.choice(["heads", "tails"])


agent = Agent(
    system_prompt="You are a helpful assistant with access to tools. Use them when appropriate.",
    tools=registry,
    temperature=0.7,
)


async def main():
    print("Chat — type 'quit' to exit")
    print(f"Tools: {', '.join(t.name for t in registry)}\n")
    while True:
        user = input("You: ").strip()
        if not user or user.lower() in ("quit", "exit", "q"):
            print("Goodbye!")
            break
        response = await agent.message(user, role="user")
        print(f"Assistant: {response.text}\n")
        print(f"Usage: {response.usage}\n")
        if response.tools_called:
            print("Tools called:")
            for tr in response.tools_called:
                print(f"  - {tr.name}({tr.args}) → {tr.result}")
        print("-" * 40)


if __name__ == "__main__":
    asyncio.run(main())
