"""Quick smoke test for the tool system."""
import asyncio
from dotenv import load_dotenv
load_dotenv()

from oaf.tools import Tool, tool, ToolRegistry
from oaf.agent import Agent

# --- Decorator registration ---
registry = ToolRegistry()

@registry.register
async def add(a: int, b: int) -> str:
    """Add two numbers together."""
    return str(int(a) + int(b))

@registry.register
async def get_weather(city: str) -> str:
    """Get the current weather for a city."""
    return f"Weather in {city}: 72°F and sunny"

print(f"Registered {len(registry)} tools")
for t in registry:
    print(f"  - {t.name}: {t.description}")
    print(f"    params: {t.parameters}")

print(f"\nToolParams for API:")
for tp in registry.to_tool_params():
    print(f"  {tp}")

# --- Live test with Agent ---
async def main():
    agent = Agent(
        system_prompt="You are a helpful assistant. Use the tools when needed.",
        tools=registry,
        temperature=0.0,
    )

    print("\n--- Asking agent to add 17 + 25 ---")
    response = await agent.message("What is 17 + 25? Use the add tool.", role="user")
    print(f"Response: {response.text}")
    print(f"Context: {agent.get_context()}")

    print("\n--- Asking about weather ---")
    response = await agent.message("What's the weather in Tokyo?", role="user")
    print(f"Response: {response.text}")

asyncio.run(main())
