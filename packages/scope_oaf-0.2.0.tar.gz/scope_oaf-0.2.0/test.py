from oaf.llmclient import (
    LLMClient,
    Models,
)

print(Models.GPT_5_4_NANO.id)