# OAF — OpenAgentFramework

Minimal, fast, transparent AI agent framework for Python.

JSON-based tool calling, provider-agnostic (OpenAI + Anthropic), full prompt inspectability.

## Install

```bash
pip install scope-oaf
```

Or from source:

```bash
pip install /path/to/oaf
```

## Quick Start

```python
import asyncio
from oaf import Agent, ToolRegistry

registry = ToolRegistry()

@registry.register
async def get_weather(city: str) -> str:
    """Get the current weather for a city."""
    return f"Weather in {city}: 72°F, sunny"

agent = Agent(model="gpt-4.1-nano", tools=registry)
response = asyncio.run(agent.message("What's the weather in Tokyo?", role="user"))
print(response.text)
```

## Top-level API

```python
from oaf import Agent, Hooks, Tool, tool, tool_method, BaseToolGroup, ToolRegistry
```

That's the full autocomplete list. Everything else lives in subpackages.

## Subpackages

```python
# LLM client, types, models, errors
from oaf.llmclient import LLMClient, Message, ChatResponse, Models, LLMError

# Context / memory
from oaf.context import BaseContext, ConversationalInMemory

# Prompt builders
from oaf.prompts import BasePromptBuilder, DefaultPromptBuilder
```

## Tool Groups

```python
from oaf import BaseToolGroup, tool_method, ToolRegistry

class MathTools(BaseToolGroup):
    """Mathematical operations."""
    name = "math"

    @tool_method
    async def add(self, a: int, b: int) -> str:
        """Add two numbers."""
        return str(a + b)

registry = ToolRegistry()
registry.register_group(MathTools())
```

## Providers

Set `OPENAI_API_KEY` and/or `ANTHROPIC_API_KEY` as environment variables,
or pass them directly:

```python
from oaf.llmclient import LLMClient

client = LLMClient(openai_api_key="sk-...", anthropic_api_key="sk-ant-...")
```

## License

MIT
