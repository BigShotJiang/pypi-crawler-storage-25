"""OpenAgentFramework (OAF) — minimal, fast, transparent agent framework.

Top-level exports are the essentials for building an agent::

    from oaf import Agent, tool, ToolRegistry

For deeper types, go to subpackages::

    from oaf.llmclient import LLMClient, Message, ChatResponse, Models
    from oaf.context import BaseContext, ConversationalInMemory
    from oaf.prompts import BasePromptBuilder, DefaultPromptBuilder
"""

from importlib.metadata import version as _pkg_version

__version__ = _pkg_version("scope-oaf")

from .agent import Agent
from .hooks import Hooks
from .tools import Tool, tool, tool_method, BaseToolGroup, ToolRegistry

__all__ = [
    "Agent",
    "Hooks",
    "Tool",
    "tool",
    "tool_method",
    "BaseToolGroup",
    "ToolRegistry",
]
