"""Raw prompt templates — all internal text blocks used by the framework.

These are the building blocks that get assembled into system prompts.
Keep them as simple format-string templates with {placeholders} where needed.
"""

# ── Tool system ───────────────────────────────────────────────────────────────

TOOL_HEADER = "You have access to the following tools:\n"

# Per-tool line: {name}, {signature}, {description}
TOOL_ENTRY = """\
- {name}({signature})
  {description}"""

# JSON response schema shown to the model
TOOL_JSON_SCHEMA = """\
You must respond with a JSON object with this exact structure:
{
  "tool_calls": [{"name": "tool_name", "args": {"param": "value"}}],
  "response": "your text response to the user"
}"""

# Rules appended after the schema
TOOL_RULES = """\
Rules:
- Always respond with valid JSON only. No text outside the JSON object.
- "tool_calls" is optional. Include it only when you need to call tools.
- "response" is optional. Include it when you have a message for the user.
- At least one of "tool_calls" or "response" must be present.
- You may include both "tool_calls" and "response" in the same reply. For example, saying "Checking the weather for you..." in "response" while also calling a weather tool.
- "args" must be an object matching the tool parameters described above.
- CRITICAL: When a tool exists that can fulfill the user's request, you MUST include "tool_calls" to call it. NEVER simulate, fabricate, or guess what a tool would return. If you respond without calling an available tool that is relevant, that is an error.
- When you call tools, do NOT include "response" — wait for the tool results first."""

# ── Tool groups ───────────────────────────────────────────────────────────────

# Header for a group section: {group_name}, {group_description}
TOOL_GROUP_HEADER = """\

[{group_name}] — {group_description}"""

# ── Parameter formatting ─────────────────────────────────────────────────────

# Single param inside a tool signature: {name}, {type}, {required_tag}, {default_tag}
TOOL_PARAM = "{name}: {type}{required_tag}{default_tag}"

# Tag appended to required params
TOOL_PARAM_REQUIRED_TAG = " [required]"
