"""BasePromptBuilder — abstract base class for all PromptBuilder implementations."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any

from ..llmclient import Message
from ..context import BaseContext


class BasePromptBuilder(ABC):
    """Abstract base for prompt builders.

    Owns the system prompt and assembles the final message list sent to the LLM.
    Works together with a BaseContext (raw message storage) to produce the full
    context window.

    The builder:
      - Has direct access to the context instance.
      - Receives **kwargs from chat calls so it can adjust dynamically.
      - Can hook into agent lifecycle events (via Hooks) to mutate state between turns.

    Subclasses must implement build_messages() and __str__().
    """

    def __init__(self, context: BaseContext) -> None:
        self.context = context

    @abstractmethod
    def build_messages(self, **kwargs: Any) -> list[Message]:
        """Assemble the final messages list for the LLM.

        This is the single point that decides what the model sees.
        Implementations typically prepend a system prompt to the context's
        stored messages, but can reorder, inject, filter, or transform
        however they like.

        Args:
            **kwargs: Extra arguments forwarded from the agent's chat call.

        Returns:
            The complete list of Messages to send to the LLM.
        """

    @abstractmethod
    def update_system_prompt(self, new_prompt: str, **kwargs: Any) -> None:
        """Replace or modify the system prompt.

        Args:
            new_prompt: The new system prompt text.
            **kwargs: Extra context for the update.
        """

    @abstractmethod
    def get_system_prompt(self) -> str:
        """Return the current system prompt text."""

    @abstractmethod
    def __str__(self) -> str:
        """Return a string representation of the current prompt state."""