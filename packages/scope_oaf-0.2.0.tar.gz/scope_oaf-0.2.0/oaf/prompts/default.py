"""DefaultPromptBuilder — basic prompt builder that prepends a system prompt."""

from __future__ import annotations

from typing import Any

from ..llmclient import Message
from ..context import BaseContext
from .base import BasePromptBuilder


class DefaultPromptBuilder(BasePromptBuilder):
    """Simple prompt builder: static system prompt + context messages.

    Prepends the system prompt as the first message, then appends all
    messages from the context. kwargs are ignored (no dynamic behavior).

    Usage::

        builder = DefaultPromptBuilder(context, system_prompt="You are helpful.")
        messages = builder.build_messages()
    """

    def __init__(self, context: BaseContext, system_prompt: str = "You are a helpful assistant.") -> None:
        super().__init__(context)
        self._system_prompt = system_prompt

    def build_messages(self, **kwargs: Any) -> list[Message]:
        """Prepend system prompt to context messages.

        Args:
            **kwargs: Ignored in default implementation.

        Returns:
            [system_message] + context messages.
        """
        system_msg = Message(role="system", content=self._system_prompt)
        return [system_msg] + self.context.get_messages()

    def update_system_prompt(self, new_prompt: str, **kwargs: Any) -> None:
        """Replace the system prompt.

        Args:
            new_prompt: The new system prompt text.
            **kwargs: Ignored in default implementation.
        """
        self._system_prompt = new_prompt

    def get_system_prompt(self) -> str:
        """Return the current system prompt text."""
        return self._system_prompt

    def __str__(self) -> str:
        return self._system_prompt
