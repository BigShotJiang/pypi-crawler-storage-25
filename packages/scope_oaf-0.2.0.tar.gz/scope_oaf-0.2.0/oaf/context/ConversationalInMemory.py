"""ConversationalInMemory — an in-memory only implementation of conversational memory."""

from __future__ import annotations

from ..llmclient import Message
from .base import BaseContext


class ConversationalInMemory(BaseContext):
    """In-memory conversation history with message and token limits.

    Tracks messages per turn and enforces two limits:
      - max_messages: hard cap on stored messages (drops oldest first, keeps system).
      - max_tokens: approximate token budget (1 token ≈ 4 chars). Drops oldest
        non-system messages when exceeded.

    Usage::

        memory = ConversationalInMemory(max_messages=100, max_tokens=8000)
        memory.start_turn()
        memory.add_message(Message(role="user", content="Hello"))
        messages = memory.get_messages()

    Args:
        max_messages: Maximum number of messages to keep. None for unlimited.
        max_tokens: Approximate token budget for the history. None for unlimited.
    """

    def __init__(
        self,
        *,
        max_messages: int | None = None,
        max_tokens: int | None = None,
    ):
        self.max_messages = max_messages
        self.max_tokens = max_tokens
        # Each entry is (turn_number, messages) — single-message entries for
        # normal messages, multi-message entries for atomic tool turns.
        self._entries: list[tuple[int, list[Message]]] = []
        self._turns: int = 0

    def start_turn(self) -> None:
        """Mark the beginning of a new agent turn."""
        self._turns += 1

    def add_message(self, message: Message) -> None:
        """Store a message and enforce limits.

        Args:
            message: The Message to store (any role).
        """
        self._entries.append((self._turns, [message]))
        self._enforce_limits()

    def add_tool_turn(self, assistant_message: Message, tool_results_message: Message) -> None:
        """Store a tool turn (assistant call + user results) as an atomic group."""
        self._entries.append((self._turns, [assistant_message, tool_results_message]))
        self._enforce_limits()

    def get_messages(self) -> list[Message]:
        """Return the current message list for the LLM."""
        return [msg for _, msgs in self._entries for msg in msgs]

    def clear(self) -> None:
        """Reset all history and turn count."""
        self._entries.clear()
        self._turns = 0

    def turn_count(self) -> int:
        """Return the number of turns started so far."""
        return self._turns
    
    def change_system_prompt(self, new_system_prompt: str) -> None:
        """Change the system prompt in-place. Drops old system messages, adds new one."""
        # Remove entries whose first message is a system message
        self._entries = [e for e in self._entries if e[1][0].role != "system"]
        # Add new system prompt at the beginning
        self._entries.insert(0, (0, [Message(role="system", content=new_system_prompt)]))

    # ── internals ─────────────────────────────────────────────────────────

    def _enforce_limits(self) -> None:
        """Drop oldest non-system entries to stay within limits."""
        # Message count limit
        if self.max_messages is not None:
            while self._message_count() > self.max_messages:
                self._drop_oldest()

        # Token limit (approximate: 1 token ≈ 4 chars)
        if self.max_tokens is not None:
            while self._estimate_tokens() > self.max_tokens and len(self._entries) > 1:
                self._drop_oldest()

    def _drop_oldest(self) -> None:
        """Remove the oldest non-system entry (all messages in the group)."""
        for i, (_, msgs) in enumerate(self._entries):
            if msgs[0].role != "system":
                self._entries.pop(i)
                return

    def _message_count(self) -> int:
        """Total number of messages across all entries."""
        return sum(len(msgs) for _, msgs in self._entries)

    @staticmethod
    def _message_tokens(msg: Message) -> int:
        """Rough token estimate for a single message."""
        if isinstance(msg.content, str):
            return len(msg.content) // 4 + 4  # +4 for role/overhead
        if isinstance(msg.content, list):
            total = 0
            for part in msg.content:
                if isinstance(part, str):
                    total += len(part) // 4
            return total + 4
        return 4

    def _estimate_tokens(self) -> int:
        """Estimate total tokens across all stored messages."""
        return sum(self._message_tokens(m) for _, msgs in self._entries for m in msgs)