"""BaseContext — abstract base class for all context/memory implementations."""

from __future__ import annotations

from abc import ABC, abstractmethod

from ..llmclient import Message


class BaseContext(ABC):
    """Abstract base for conversation memory.

    Defines the iteration-based interface that all context implementations must follow.
    Each agent loop turn is an "iteration" — call start_turn() at the top, then
    add messages as they happen during that turn.
    """

    @abstractmethod
    def start_turn(self) -> None:
        """Mark the beginning of a new agent turn/iteration."""

    @abstractmethod
    def add_message(self, message: Message) -> None:
        """Record a message (user, assistant, system, or tool result).

        Args:
            message: The Message to store.
        """

    @abstractmethod
    def add_tool_turn(self, assistant_message: Message, tool_results_message: Message) -> None:
        """Record a tool turn as an atomic group (assistant tool-call + user tool-results).

        During truncation the two messages are dropped together, never split.
        """

    @abstractmethod
    def get_messages(self) -> list[Message]:
        """Return the message list to send to the LLM.

        Implementations may truncate or summarise to stay within limits.
        """

    @abstractmethod
    def clear(self) -> None:
        """Reset all stored history."""

    @abstractmethod
    def turn_count(self) -> int:
        """Return the number of completed turns."""

    def change_system_prompt(self, new_system_prompt: str) -> None:
        """Change the system prompt in-place. """
        raise NotImplementedError("This context does not support changing the system prompt in-place.")