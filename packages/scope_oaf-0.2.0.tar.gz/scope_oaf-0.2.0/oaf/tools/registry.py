"""ToolRegistry — manages tool registration and lookup."""

from __future__ import annotations

from typing import Any, Callable, Awaitable

from ..llmclient import ToolParam
from .tool import Tool, BaseToolGroup, tool as tool_decorator


class ToolRegistry:
    """Registry of tools available to the agent.

    Supports two registration styles:

    1. **Decorator**::

        registry = ToolRegistry()

        @registry.register
        async def get_weather(city: str) -> str:
            \"\"\"Get the weather for a city.\"\"\"
            return "sunny"

    2. **Raw callable**::

        registry = ToolRegistry()
        registry.add(my_tool)  # a Tool instance
    """

    def __init__(self) -> None:
        self._tools: dict[str, Tool] = {}

    def register(
        self,
        fn: Callable[..., Awaitable[Any]] | None = None,
        *,
        name: str | None = None,
        description: str | None = None,
    ) -> Tool | Callable[[Callable[..., Awaitable[Any]]], Tool]:
        """Decorator to register an async function as a tool.

        Usage::

            @registry.register
            async def my_tool(x: int) -> str: ...

            @registry.register(name="custom_name")
            async def my_tool(x: int) -> str: ...

        Args:
            fn: The async function (when used without parentheses).
            name: Override the tool name.
            description: Override the description.

        Returns:
            The Tool instance (also stored in the registry).
        """
        def decorator(fn: Callable[..., Awaitable[Any]]) -> Tool:
            t = tool_decorator(fn, name=name, description=description)
            self._tools[t.name] = t
            return t

        if fn is not None:
            return decorator(fn)
        return decorator

    def add(self, t: Tool) -> None:
        """Add a pre-built Tool instance to the registry.

        Args:
            t: A Tool instance.
        """
        self._tools[t.name] = t

    def register_group(self, group: BaseToolGroup) -> None:
        """Register all tools from a BaseToolGroup instance.

        Collects @tool_method-marked methods, prefixes names, and stores them.

        Args:
            group: A BaseToolGroup instance.
        """
        for t in group.collect_tools():
            self._tools[t.name] = t

    def get(self, name: str) -> Tool | None:
        """Look up a tool by name.

        Args:
            name: The tool name.

        Returns:
            The Tool, or None if not found.
        """
        return self._tools.get(name)

    def to_tool_params(self) -> list[ToolParam]:
        """Convert all registered tools to ToolParam list for the LLM API.

        Returns:
            List of ToolParam definitions.
        """
        return [t.to_tool_param() for t in self._tools.values()]

    def __len__(self) -> int:
        return len(self._tools)

    def __contains__(self, name: str) -> bool:
        return name in self._tools

    def __iter__(self):
        return iter(self._tools.values())
