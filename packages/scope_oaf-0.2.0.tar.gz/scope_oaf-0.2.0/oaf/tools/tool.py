"""Tool — base class and @tool decorator for defining agent tools."""

from __future__ import annotations

import inspect
from abc import ABC
from dataclasses import dataclass, field
from typing import Any, Callable, Awaitable, get_type_hints

from ..llmclient import ToolParam, FunctionDef


# Python type → JSON Schema type mapping
_TYPE_MAP: dict[type, str] = {
    str: "string",
    int: "integer",
    float: "number",
    bool: "boolean",
    list: "array",
    dict: "object",
}


def _python_type_to_json(t: type) -> str:
    """Convert a Python type annotation to a JSON Schema type string."""
    return _TYPE_MAP.get(t, "string")


@dataclass
class Tool:
    """A callable tool the agent can invoke.

    Wraps an async function with its name, description, and JSON Schema
    parameter definition. Automatically derived from type hints and docstring
    when using the @tool decorator.
    """
    name: str
    description: str
    parameters: dict[str, Any] = field(default_factory=dict)
    fn: Callable[..., Awaitable[Any]] | None = None
    group: str = ""
    group_description: str = ""

    def to_tool_param(self) -> ToolParam:
        """Convert to the ToolParam format expected by LLMClient."""
        return ToolParam(
            type="function",
            function=FunctionDef(
                name=self.name,
                description=self.description,
                parameters=self.parameters,
                group=self.group,
                group_description=self.group_description,
            ),
        )

    async def __call__(self, **kwargs: Any) -> Any:
        """Execute the underlying function."""
        if self.fn is None:
            raise RuntimeError(f"Tool {self.name!r} has no callable function attached")
        return await self.fn(**kwargs)


def _build_parameters_schema(fn: Callable) -> dict[str, Any]:
    """Extract JSON Schema parameters from function signature + type hints."""
    sig = inspect.signature(fn)
    hints = get_type_hints(fn)

    properties: dict[str, Any] = {}
    required: list[str] = []

    for name, param in sig.parameters.items():
        if name in ("self", "cls"):
            continue

        prop: dict[str, Any] = {}
        if name in hints:
            prop["type"] = _python_type_to_json(hints[name])
        else:
            prop["type"] = "string"

        # Check for default → not required
        if param.default is inspect.Parameter.empty:
            required.append(name)
        else:
            prop["default"] = param.default

        properties[name] = prop

    schema: dict[str, Any] = {
        "type": "object",
        "properties": properties,
    }
    if required:
        schema["required"] = required

    return schema


def _extract_description(fn: Callable) -> str:
    """Extract the first line of the docstring as the tool description."""
    doc = inspect.getdoc(fn)
    if not doc:
        return f"Tool: {fn.__name__}"
    return doc.split("\n")[0].strip()


def tool(
    fn: Callable[..., Awaitable[Any]] | None = None,
    *,
    name: str | None = None,
    description: str | None = None,
) -> Tool | Callable[[Callable[..., Awaitable[Any]]], Tool]:
    """Decorator to turn an async function into a Tool.

    Usage::

        @tool
        async def get_weather(city: str, units: str = "celsius") -> str:
            \"\"\"Get the current weather for a city.\"\"\"
            return f"Weather in {city}: 72°F"

        @tool(name="search", description="Search the web")
        async def search_web(query: str) -> str:
            return f"Results for {query}"

    Args:
        fn: The async function (when used without parentheses).
        name: Override the tool name (defaults to function name).
        description: Override the description (defaults to first line of docstring).

    Returns:
        A Tool instance.
    """
    def decorator(fn: Callable[..., Awaitable[Any]]) -> Tool:
        if not inspect.iscoroutinefunction(fn):
            raise TypeError(f"Tool {fn.__name__!r} must be an async function")

        return Tool(
            name=name or fn.__name__,
            description=description or _extract_description(fn),
            parameters=_build_parameters_schema(fn),
            fn=fn,
        )

    if fn is not None:
        return decorator(fn)
    return decorator


# ── Tool groups ───────────────────────────────────────────────────────────────

_TOOL_METHOD_MARKER = "__oaf_tool_method__"


def tool_method(
    fn: Callable[..., Awaitable[Any]] | None = None,
    *,
    name: str | None = None,
    description: str | None = None,
) -> Any:
    """Mark an async method as a tool inside a ToolGroup.

    Usage::

        class MyGroup(BaseToolGroup):
            @tool_method
            async def my_tool(self, x: int) -> str:
                \"\"\"Do something.\"\"\"
                ...

            @tool_method(name="custom")
            async def other(self, q: str) -> str: ...
    """
    def decorator(fn: Callable[..., Awaitable[Any]]) -> Callable[..., Awaitable[Any]]:
        setattr(fn, _TOOL_METHOD_MARKER, {
            "name": name,
            "description": description,
        })
        return fn

    if fn is not None:
        return decorator(fn)
    return decorator


class BaseToolGroup(ABC):
    """Abstract base class for tool groups.

    Subclass this, set ``name`` and optionally ``description``, then mark
    async methods with ``@tool_method``. The registry collects them.

    Tool names are ``{group_name}.{method_name}`` by default.

    Usage::

        class MathTools(BaseToolGroup):
            \"\"\"Mathematical operations and calculations.\"\"\"
            name = "math"

            @tool_method
            async def calculate(self, expression: str) -> str:
                \"\"\"Evaluate a math expression.\"\"\"
                return str(eval(expression))

            @tool_method
            async def factorial(self, n: int) -> str:
                \"\"\"Compute factorial of n.\"\"\"
                import math as m
                return str(m.factorial(n))

        registry = ToolRegistry()
        registry.register_group(MathTools())
    """

    name: str = ""
    description: str = ""

    def collect_tools(self) -> list[Tool]:
        """Return Tool objects for every @tool_method on this instance."""
        group_name = self.name or type(self).__name__.lower()
        group_desc = self.description or inspect.getdoc(type(self)) or ""
        group_desc = group_desc.split("\n")[0].strip()

        tools: list[Tool] = []
        for attr_name in dir(type(self)):
            cls_attr = getattr(type(self), attr_name, None)
            if cls_attr is None:
                continue
            meta = getattr(cls_attr, _TOOL_METHOD_MARKER, None)
            if meta is None:
                continue

            bound = getattr(self, attr_name)
            method_name = meta.get("name") or attr_name
            tool_name = f"{group_name}.{method_name}"

            tools.append(Tool(
                name=tool_name,
                description=meta.get("description") or _extract_description(bound),
                parameters=_build_parameters_schema(bound),
                fn=bound,
                group=group_name,
                group_description=group_desc,
            ))

        return tools
