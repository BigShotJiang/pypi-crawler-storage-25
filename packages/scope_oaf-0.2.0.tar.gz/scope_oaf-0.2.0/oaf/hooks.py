"""Hooks — async lifecycle hook system for the Agent.

Subclass Hooks and override methods, or use .on() for ad-hoc registration.
"""

from __future__ import annotations

from typing import Any, Callable, Awaitable

from .llmclient import Message, ChatResponse, StreamChunk


# All valid event names
EVENTS = frozenset({
    "before_message",
    "after_message",
    "before_tool_call",
    "after_tool_call",
    "on_stream_chunk",
    "on_error",
    "on_context_update",
    "system_prompt_change",
    
})


class Hooks:
    """Lifecycle hooks for Agent internals.

    Two ways to use:

    1. **Subclass** — override any async method::

        class MyHooks(Hooks):
            async def before_message(self, message, role, messages):
                print(f"Sending: {message}")

    2. **Ad-hoc** — register callbacks with .on()::

        hooks = Hooks()
        hooks.on("before_message", my_callback)

    Both styles work together. When triggered, the class method runs first,
    then all registered callbacks in order.

    For "before_" events, returning a non-None value from any handler
    replaces the original (allows mutation).
    """

    def __init__(self) -> None:
        self._callbacks: dict[str, list[Callable[..., Awaitable[Any]]]] = {}

    # ── Class-based overrides (no-op defaults) ────────────────────────────

    async def before_message(self, message: str, role: str, messages: list[Message]) -> str | None:
        """Called before sending to the LLM.

        Args:
            message: The new message text.
            role: The role ('user', 'assistant', 'system').
            messages: Full message list that will be sent.

        Returns:
            A replacement message string, or None to keep the original.
        """

    async def after_message(self, response: ChatResponse) -> None:
        """Called after the LLM responds.

        Args:
            response: The ChatResponse from the LLM.
        """

    async def before_tool_call(self, tool_name: str, arguments: dict[str, Any]) -> dict[str, Any] | None:
        """Called before a tool is executed.

        Args:
            tool_name: Name of the tool being called.
            arguments: Arguments passed to the tool.

        Returns:
            Replacement arguments dict, or None to keep the original.
        """

    async def after_tool_call(self, tool_name: str, arguments: dict[str, Any], result: Any) -> None:
        """Called after a tool returns.

        Args:
            tool_name: Name of the tool that was called.
            arguments: Arguments that were passed to the tool.
            result: The return value from the tool.
        """

    async def on_stream_chunk(self, chunk: StreamChunk) -> None:
        """Called for each streaming token.

        Args:
            chunk: The StreamChunk received.
        """

    async def on_error(self, error: Exception) -> None:
        """Called when an error occurs during agent execution.

        Args:
            error: The exception that was raised.
        """

    async def on_context_update(self) -> None:
        """Called when the context/memory changes."""

    async def system_prompt_change(self, new_prompt: str) -> None:
        """Called when the system prompt is changed.

        Args:
            new_prompt: The new system prompt text.
        """

    # ── Ad-hoc registration ───────────────────────────────────────────────

    def on(self, event: str, callback: Callable[..., Awaitable[Any]]) -> None:
        """Register an async callback for a lifecycle event.

        Args:
            event: Event name (one of EVENTS).
            callback: An async callable matching the event's signature.

        Raises:
            ValueError: If event name is not recognized.
        """
        if event not in EVENTS:
            raise ValueError(f"Unknown event {event!r}. Valid events: {sorted(EVENTS)}")
        self._callbacks.setdefault(event, []).append(callback)

    # ── Trigger ───────────────────────────────────────────────────────────

    async def trigger(self, event: str, *args: Any, **kwargs: Any) -> Any:
        """Fire an event — calls the class method, then all registered callbacks.

        For "before_" events, the last non-None return value wins
        (allowing handlers to mutate the input).

        Args:
            event: Event name to trigger.
            *args, **kwargs: Forwarded to all handlers.

        Returns:
            The last non-None return value (for before_ events), or None.
        """
        result = None

        # 1. Class method (overridden or default no-op)
        handler = getattr(self, event, None)
        if handler is not None:
            r = await handler(*args, **kwargs)
            if r is not None:
                result = r

        # 2. Registered callbacks
        for cb in self._callbacks.get(event, []):
            r = await cb(*args, **kwargs)
            if r is not None:
                result = r

        return result
