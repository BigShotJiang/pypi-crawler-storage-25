﻿"""Model registry — all known OpenAI and Anthropic models with metadata.

Data sourced from official docs (April 2026):
  - https://developers.openai.com/api/docs/models
  - https://platform.claude.com/docs/en/docs/about-claude/models

Usage:
    from oaf.llmclient.models import Models, get_model, list_models

    model = Models.GPT_4O            # quick access
    info  = get_model("gpt-4o")      # lookup by ID
    all_  = list_models("openai")    # filter by provider
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Literal


@dataclass(frozen=True)
class ModelInfo:
    """Metadata for a single model."""
    id: str                                          # API model ID (e.g. "gpt-4o")
    provider: Literal["openai", "anthropic"]
    display_name: str                                # human-friendly name
    context_window: int                              # max input tokens
    max_output: int                                  # max output tokens
    input_price_per_mtok: float                      # USD per 1M input tokens
    output_price_per_mtok: float                     # USD per 1M output tokens
    supports_vision: bool = False                    # can process images
    supports_streaming: bool = True
    supports_embeddings: bool = False                # embedding-only model
    embedding_dimensions: int | None = None          # default dim for embedding models
    knowledge_cutoff: str = ""                       # e.g. "2025-08"
    aliases: tuple[str, ...] = ()                    # alternative IDs
    deprecated: bool = False
    category: str = "chat"                           # chat | embedding | reasoning


# ══════════════════════════════════════════════════════════════════════════════
#  OpenAI Models
# ══════════════════════════════════════════════════════════════════════════════

# ── GPT-5.4 family ────────────────────────────────────────────────────────────
GPT_5_4 = ModelInfo(
    id="gpt-5.4", provider="openai", display_name="GPT-5.4",
    context_window=1_000_000, max_output=128_000,
    input_price_per_mtok=2.50, output_price_per_mtok=15.00,
    supports_vision=True, knowledge_cutoff="2025-08",
    category="chat",
)
GPT_5_4_MINI = ModelInfo(
    id="gpt-5.4-mini", provider="openai", display_name="GPT-5.4 Mini",
    context_window=400_000, max_output=128_000,
    input_price_per_mtok=0.75, output_price_per_mtok=4.50,
    supports_vision=True, knowledge_cutoff="2025-08",
    category="chat",
)
GPT_5_4_NANO = ModelInfo(
    id="gpt-5.4-nano", provider="openai", display_name="GPT-5.4 Nano",
    context_window=400_000, max_output=128_000,
    input_price_per_mtok=0.20, output_price_per_mtok=1.25,
    supports_vision=True, knowledge_cutoff="2025-08",
    category="chat",
)

# ── GPT-4.1 family ───────────────────────────────────────────────────────────
GPT_4_1 = ModelInfo(
    id="gpt-4.1", provider="openai", display_name="GPT-4.1",
    context_window=1_000_000, max_output=32_768,
    input_price_per_mtok=2.00, output_price_per_mtok=8.00,
    supports_vision=True, knowledge_cutoff="2025-03",
    category="chat",
)
GPT_4_1_MINI = ModelInfo(
    id="gpt-4.1-mini", provider="openai", display_name="GPT-4.1 Mini",
    context_window=1_000_000, max_output=32_768,
    input_price_per_mtok=0.40, output_price_per_mtok=1.60,
    supports_vision=True, knowledge_cutoff="2025-03",
    category="chat",
)
GPT_4_1_NANO = ModelInfo(
    id="gpt-4.1-nano", provider="openai", display_name="GPT-4.1 Nano",
    context_window=1_000_000, max_output=32_768,
    input_price_per_mtok=0.10, output_price_per_mtok=0.40,
    supports_vision=True, knowledge_cutoff="2025-03",
    category="chat",
)

# ── GPT-4o family ────────────────────────────────────────────────────────────
GPT_4O = ModelInfo(
    id="gpt-4o", provider="openai", display_name="GPT-4o",
    context_window=128_000, max_output=16_384,
    input_price_per_mtok=2.50, output_price_per_mtok=10.00,
    supports_vision=True, knowledge_cutoff="2024-10",
    category="chat",
)
GPT_4O_MINI = ModelInfo(
    id="gpt-4o-mini", provider="openai", display_name="GPT-4o Mini",
    context_window=128_000, max_output=16_384,
    input_price_per_mtok=0.15, output_price_per_mtok=0.60,
    supports_vision=True, knowledge_cutoff="2024-10",
    category="chat",
)

# ── o-series (reasoning) ─────────────────────────────────────────────────────
O4_MINI = ModelInfo(
    id="o4-mini", provider="openai", display_name="o4-mini",
    context_window=200_000, max_output=100_000,
    input_price_per_mtok=1.10, output_price_per_mtok=4.40,
    supports_vision=True, knowledge_cutoff="2025-03",
    category="reasoning",
)
O3 = ModelInfo(
    id="o3", provider="openai", display_name="o3",
    context_window=200_000, max_output=100_000,
    input_price_per_mtok=2.00, output_price_per_mtok=8.00,
    supports_vision=True, knowledge_cutoff="2025-03",
    category="reasoning",
)
O3_MINI = ModelInfo(
    id="o3-mini", provider="openai", display_name="o3-mini",
    context_window=200_000, max_output=100_000,
    input_price_per_mtok=1.10, output_price_per_mtok=4.40,
    supports_vision=True, knowledge_cutoff="2025-01",
    category="reasoning",
)
O1 = ModelInfo(
    id="o1", provider="openai", display_name="o1",
    context_window=200_000, max_output=100_000,
    input_price_per_mtok=15.00, output_price_per_mtok=60.00,
    supports_vision=True, knowledge_cutoff="2024-10",
    category="reasoning",
)
O1_MINI = ModelInfo(
    id="o1-mini", provider="openai", display_name="o1-mini",
    context_window=128_000, max_output=65_536,
    input_price_per_mtok=3.00, output_price_per_mtok=12.00,
    supports_vision=False, knowledge_cutoff="2024-10",
    category="reasoning",
)

# ── Embedding models ─────────────────────────────────────────────────────────
TEXT_EMBEDDING_3_SMALL = ModelInfo(
    id="text-embedding-3-small", provider="openai",
    display_name="Text Embedding 3 Small",
    context_window=8_192, max_output=0,
    input_price_per_mtok=0.02, output_price_per_mtok=0.0,
    supports_embeddings=True, embedding_dimensions=1536,
    category="embedding",
)
TEXT_EMBEDDING_3_LARGE = ModelInfo(
    id="text-embedding-3-large", provider="openai",
    display_name="Text Embedding 3 Large",
    context_window=8_192, max_output=0,
    input_price_per_mtok=0.13, output_price_per_mtok=0.0,
    supports_embeddings=True, embedding_dimensions=3072,
    category="embedding",
)
TEXT_EMBEDDING_ADA_002 = ModelInfo(
    id="text-embedding-ada-002", provider="openai",
    display_name="Text Embedding Ada 002",
    context_window=8_192, max_output=0,
    input_price_per_mtok=0.10, output_price_per_mtok=0.0,
    supports_embeddings=True, embedding_dimensions=1536,
    deprecated=True, category="embedding",
)


# ══════════════════════════════════════════════════════════════════════════════
#  Anthropic Models
# ══════════════════════════════════════════════════════════════════════════════

CLAUDE_OPUS_4_6 = ModelInfo(
    id="claude-opus-4-6", provider="anthropic",
    display_name="Claude Opus 4.6",
    context_window=1_000_000, max_output=128_000,
    input_price_per_mtok=5.00, output_price_per_mtok=25.00,
    supports_vision=True, knowledge_cutoff="2025-05",
    category="chat",
)
CLAUDE_SONNET_4_6 = ModelInfo(
    id="claude-sonnet-4-6", provider="anthropic",
    display_name="Claude Sonnet 4.6",
    context_window=1_000_000, max_output=64_000,
    input_price_per_mtok=3.00, output_price_per_mtok=15.00,
    supports_vision=True, knowledge_cutoff="2025-08",
    category="chat",
)
CLAUDE_HAIKU_4_5 = ModelInfo(
    id="claude-haiku-4-5-20251001", provider="anthropic",
    display_name="Claude Haiku 4.5",
    context_window=200_000, max_output=64_000,
    input_price_per_mtok=1.00, output_price_per_mtok=5.00,
    supports_vision=True, knowledge_cutoff="2025-02",
    aliases=("claude-haiku-4-5",),
    category="chat",
)
CLAUDE_SONNET_4 = ModelInfo(
    id="claude-sonnet-4-20250514", provider="anthropic",
    display_name="Claude Sonnet 4",
    context_window=200_000, max_output=64_000,
    input_price_per_mtok=3.00, output_price_per_mtok=15.00,
    supports_vision=True, knowledge_cutoff="2025-03",
    category="chat",
)
CLAUDE_OPUS_4 = ModelInfo(
    id="claude-opus-4-20250514", provider="anthropic",
    display_name="Claude Opus 4",
    context_window=200_000, max_output=32_000,
    input_price_per_mtok=15.00, output_price_per_mtok=75.00,
    supports_vision=True, knowledge_cutoff="2025-03",
    category="chat",
)
CLAUDE_3_5_SONNET = ModelInfo(
    id="claude-3-5-sonnet-20241022", provider="anthropic",
    display_name="Claude 3.5 Sonnet",
    context_window=200_000, max_output=8_192,
    input_price_per_mtok=3.00, output_price_per_mtok=15.00,
    supports_vision=True, knowledge_cutoff="2024-04",
    aliases=("claude-3-5-sonnet-latest",),
    category="chat",
)
CLAUDE_3_5_HAIKU = ModelInfo(
    id="claude-3-5-haiku-20241022", provider="anthropic",
    display_name="Claude 3.5 Haiku",
    context_window=200_000, max_output=8_192,
    input_price_per_mtok=1.00, output_price_per_mtok=5.00,
    supports_vision=False, knowledge_cutoff="2024-07",
    aliases=("claude-3-5-haiku-latest",),
    category="chat",
)
CLAUDE_3_OPUS = ModelInfo(
    id="claude-3-opus-20240229", provider="anthropic",
    display_name="Claude 3 Opus",
    context_window=200_000, max_output=4_096,
    input_price_per_mtok=15.00, output_price_per_mtok=75.00,
    supports_vision=True, knowledge_cutoff="2023-08",
    aliases=("claude-3-opus-latest",),
    deprecated=True, category="chat",
)


# ══════════════════════════════════════════════════════════════════════════════
#  Registry
# ══════════════════════════════════════════════════════════════════════════════

_ALL_MODELS: list[ModelInfo] = [
    # OpenAI
    GPT_5_4, GPT_5_4_MINI, GPT_5_4_NANO,
    GPT_4_1, GPT_4_1_MINI, GPT_4_1_NANO,
    GPT_4O, GPT_4O_MINI,
    O4_MINI, O3, O3_MINI, O1, O1_MINI,
    TEXT_EMBEDDING_3_SMALL, TEXT_EMBEDDING_3_LARGE, TEXT_EMBEDDING_ADA_002,
    # Anthropic
    CLAUDE_OPUS_4_6, CLAUDE_SONNET_4_6, CLAUDE_HAIKU_4_5,
    CLAUDE_SONNET_4, CLAUDE_OPUS_4,
    CLAUDE_3_5_SONNET, CLAUDE_3_5_HAIKU, CLAUDE_3_OPUS,
]

# Build lookup index: model id + aliases → ModelInfo
_INDEX: dict[str, ModelInfo] = {}
for _m in _ALL_MODELS:
    _INDEX[_m.id] = _m
    for _alias in _m.aliases:
        _INDEX[_alias] = _m


class Models:
    """Namespace for quick model access: Models.GPT_4O, Models.CLAUDE_SONNET_4_6, etc."""
    # OpenAI
    GPT_5_4 = GPT_5_4
    GPT_5_4_MINI = GPT_5_4_MINI
    GPT_5_4_NANO = GPT_5_4_NANO
    GPT_4_1 = GPT_4_1
    GPT_4_1_MINI = GPT_4_1_MINI
    GPT_4_1_NANO = GPT_4_1_NANO
    GPT_4O = GPT_4O
    GPT_4O_MINI = GPT_4O_MINI
    O4_MINI = O4_MINI
    O3 = O3
    O3_MINI = O3_MINI
    O1 = O1
    O1_MINI = O1_MINI
    TEXT_EMBEDDING_3_SMALL = TEXT_EMBEDDING_3_SMALL
    TEXT_EMBEDDING_3_LARGE = TEXT_EMBEDDING_3_LARGE
    # Anthropic
    CLAUDE_OPUS_4_6 = CLAUDE_OPUS_4_6
    CLAUDE_SONNET_4_6 = CLAUDE_SONNET_4_6
    CLAUDE_HAIKU_4_5 = CLAUDE_HAIKU_4_5
    CLAUDE_SONNET_4 = CLAUDE_SONNET_4
    CLAUDE_OPUS_4 = CLAUDE_OPUS_4
    CLAUDE_3_5_SONNET = CLAUDE_3_5_SONNET
    CLAUDE_3_5_HAIKU = CLAUDE_3_5_HAIKU
    CLAUDE_3_OPUS = CLAUDE_3_OPUS


def get_model(model_id: str) -> ModelInfo | None:
    """Look up a model by ID or alias. Returns None if unknown."""
    return _INDEX.get(model_id)


def list_models(
    provider: str | None = None,
    category: str | None = None,
    include_deprecated: bool = False,
) -> list[ModelInfo]:
    """List models, optionally filtered by provider/category."""
    results = _ALL_MODELS
    if provider:
        results = [m for m in results if m.provider == provider]
    if category:
        results = [m for m in results if m.category == category]
    if not include_deprecated:
        results = [m for m in results if not m.deprecated]
    return results
