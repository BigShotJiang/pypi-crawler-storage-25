# llmclient

Unified async Python client for **OpenAI** and **Anthropic** LLMs. One interface, both providers. Message in → message out.

## Setup

```bash
pip install openai anthropic
```

Set API keys via environment variables or pass them directly:

```bash
OPENAI_API_KEY=sk-...
ANTHROPIC_API_KEY=sk-ant-...
```

## Quick Start

### Async

```python
from oaf.llmclient import LLMClient, Message

client = LLMClient()

# basic chat
response = await client.chat("gpt-4.1-nano", [Message(role="user", content="Hello")])
print(response.text)

# one-liner
text = await client.ask("gpt-4.1-nano", "What is 2+2?")

# context manager
async with LLMClient() as client:
    response = await client.chat("claude-sonnet-4-6", [Message(role="user", content="Hi")])
```

### Sync

```python
from oaf.llmclient import SyncLLMClient, Message

client = SyncLLMClient()
response = client.chat("gpt-4.1-nano", [Message(role="user", content="Hello")])
print(response.text)
```

## Streaming

```python
# async — yields StreamChunk objects
async for chunk in client.chat_stream("gpt-4.1-nano", messages):
    if chunk.delta_text:
        print(chunk.delta_text, end="", flush=True)

# one-liner — yields plain strings
async for text in client.ask_stream("gpt-4.1-nano", "Write a poem"):
    print(text, end="")

# sync — same interface, blocking
for chunk in sync_client.chat_stream("gpt-4.1-nano", messages):
    print(chunk.delta_text, end="")
```

## Tool Calling

### 1. Define tools

```python
from oaf.llmclient import ToolParam, FunctionDef

weather_tool = ToolParam(
    type="function",
    function=FunctionDef(
        name="get_weather",
        description="Get the current weather for a city",
        parameters={
            "type": "object",
            "properties": {
                "city": {"type": "string", "description": "The city name"},
            },
            "required": ["city"],
        },
    ),
)
```

### 2. Send with tools

```python
response = await client.chat(
    "gpt-4.1-nano",
    [Message(role="user", content="Weather in Tokyo?")],
    tools=[weather_tool],
    tool_choice="auto",   # "auto" | "none" | "required"
)
```

### 3. Handle tool calls

```python
choice = response.choices[0]

if choice.finish_reason == "tool_calls":
    for tc in choice.message.tool_calls:
        print(tc.name)              # "get_weather"
        print(tc.id)                # "call_abc123"
        print(tc.parsed_arguments)  # {"city": "Tokyo"}
```

### 4. Send results back

```python
# Add assistant message (with tool_calls) to history
messages.append(choice.message)

# Add tool result
messages.append(Message(
    role="tool",
    content="Sunny, 22°C",
    tool_call_id=tc.id,  # must match ToolCall.id
))

# Call again — model now gives a text response
response2 = await client.chat("gpt-4.1-nano", messages, tools=[weather_tool])
print(response2.text)  # "It's sunny and 22°C in Tokyo!"
```

## Vision

```python
from oaf.llmclient import ImageContent

response = await client.chat("gpt-4.1-nano", [
    Message(role="user", content=[
        "What's in this image?",
        ImageContent(url="https://example.com/photo.jpg"),
    ]),
])
```

## Embeddings

```python
# OpenAI only
emb = await client.embed("text-embedding-3-small", "Hello world")
vectors = emb.vectors  # list[list[float]]

# batch
emb = await client.embed("text-embedding-3-small", ["Hello", "World"])
```

## Provider Auto-Detection

The client auto-detects the provider from the model name:

| Prefix | Provider |
|---|---|
| `gpt-`, `o1`, `o3`, `o4`, `text-embedding-` | OpenAI |
| `claude` | Anthropic |

Override with `provider="openai"` or `provider="anthropic"`.

## Types Reference

### Message

```python
Message(
    role="system" | "user" | "assistant" | "tool",
    content=str | list[str | ImageContent | DocumentContent] | None,
    name=str | None,
    tool_calls=list[ToolCall] | None,     # on assistant messages with tool calls
    tool_call_id=str | None,              # on tool result messages
)
```

### ChatResponse

```
ChatResponse
├── id: str
├── model: str
├── provider: str                    # "openai" | "anthropic"
├── choices: list[Choice]
│   └── [0]
│       ├── message: Message
│       ├── finish_reason: str       # "stop" | "length" | "tool_calls"
│       └── index: int
├── usage: Usage
│   ├── prompt_tokens: int
│   ├── completion_tokens: int
│   └── total_tokens: int
├── request_payload: dict | None     # the raw payload sent to the API
├── raw: Any                         # raw provider response object
└── .text: str                       # shortcut for choices[0].message.content
```

### StreamChunk

```
StreamChunk
├── id: str
├── model: str
├── delta_text: str | None           # the text fragment
├── finish_reason: str | None        # set on the final chunk
├── usage: Usage | None              # some providers send this at the end
├── provider: str
└── request_payload: dict | None     # set on the first chunk only
```

### ToolCall (from model)

```python
ToolCall(
    id="call_abc123",         # unique ID — send back with result
    name="get_weather",       # function name
    arguments='{"city":"Tokyo"}',  # JSON string
)
tc.parsed_arguments  # → {"city": "Tokyo"}
```

### ToolParam (to model)

```python
ToolParam(
    type="function",
    function=FunctionDef(
        name="get_weather",
        description="Get weather for a city",
        parameters={...},  # JSON Schema
    ),
)
```

### finish_reason values

| Value | Meaning |
|---|---|
| `"stop"` | Model finished naturally |
| `"length"` | Hit `max_tokens` limit, response truncated |
| `"tool_calls"` | Model wants to call one or more tools |

## Error Handling

All errors inherit from `LLMError`:

```python
from oaf.llmclient import LLMError, AuthenticationError, RateLimitError

try:
    response = await client.chat(...)
except AuthenticationError:
    print("Bad API key")
except RateLimitError as e:
    print(f"Rate limited. Retry after: {e.retry_after}")
except LLMError as e:
    print(f"Provider: {e.provider}, Error: {e}")
```

| Error | When |
|---|---|
| `AuthenticationError` | Invalid/missing API key (401/403) |
| `RateLimitError` | Too many requests (429) |
| `InvalidRequestError` | Malformed request (400) |
| `NotFoundError` | Model not found (404) |
| `ServerError` | Provider error (5xx) |
| `StreamError` | Streaming connection issue |
| `TimeoutError` | Request timed out |
| `ConnectionError` | Can't reach provider |

## Model Registry

```python
from oaf.llmclient import Models, get_model, list_models

# Direct access
model = Models.GPT_4_1_NANO
print(model.id)                    # "gpt-4.1-nano"
print(model.context_window)        # 1_000_000
print(model.input_price_per_mtok)  # 0.10

# Lookup by ID
info = get_model("claude-sonnet-4-6")

# List/filter
all_openai = list_models("openai")
chat_models = list_models(category="chat")
```

### Available Models

**OpenAI**
| Model | Context | Max Output | Input $/M | Output $/M |
|---|---|---|---|---|
| gpt-5.4 | 1M | 128K | $2.50 | $15.00 |
| gpt-5.4-mini | 400K | 128K | $0.75 | $4.50 |
| gpt-5.4-nano | 400K | 128K | $0.20 | $1.25 |
| gpt-4.1 | 1M | 32K | $2.00 | $8.00 |
| gpt-4.1-mini | 1M | 32K | $0.40 | $1.60 |
| gpt-4.1-nano | 1M | 32K | $0.10 | $0.40 |
| gpt-4o | 128K | 16K | $2.50 | $10.00 |
| gpt-4o-mini | 128K | 16K | $0.15 | $0.60 |
| o4-mini | 200K | 100K | $1.10 | $4.40 |
| o3 | 200K | 100K | $2.00 | $8.00 |
| o3-mini | 200K | 100K | $1.10 | $4.40 |
| o1 | 200K | 100K | $15.00 | $60.00 |

**Anthropic**
| Model | Context | Max Output | Input $/M | Output $/M |
|---|---|---|---|---|
| claude-opus-4-6 | 1M | 128K | $5.00 | $25.00 |
| claude-sonnet-4-6 | 1M | 64K | $3.00 | $15.00 |
| claude-haiku-4-5 | 200K | 64K | $1.00 | $5.00 |
| claude-sonnet-4 | 200K | 64K | $3.00 | $15.00 |
| claude-opus-4 | 200K | 32K | $15.00 | $75.00 |
| claude-3.5-sonnet | 200K | 8K | $3.00 | $15.00 |
| claude-3.5-haiku | 200K | 8K | $1.00 | $5.00 |

**Embeddings**
| Model | Dimensions | Input $/M |
|---|---|---|
| text-embedding-3-small | 1536 | $0.02 |
| text-embedding-3-large | 3072 | $0.13 |

## Constructor Options

```python
LLMClient(
    openai_api_key="sk-...",         # or OPENAI_API_KEY env var
    anthropic_api_key="sk-ant-...",   # or ANTHROPIC_API_KEY env var
    openai_base_url=None,             # custom endpoint
    anthropic_base_url=None,          # custom endpoint
    openai_org_id=None,               # OpenAI organization ID
    timeout=120,                      # request timeout in seconds
    max_retries=2,                    # auto-retry count
)
```

## chat() Parameters

```python
await client.chat(
    model,                  # required: model ID string
    messages,               # required: list[Message]
    provider=None,          # override auto-detection
    temperature=None,       # 0.0–2.0 (None = provider default, usually 1.0)
    max_tokens=None,        # max response tokens (None = provider default)
    stop=None,              # stop sequence(s)
    top_p=None,             # nucleus sampling
    tools=None,             # list[ToolParam] for tool calling
    tool_choice=None,       # "auto" | "none" | "required"
    **kwargs,               # passed through to the provider SDK
)
```
