"""Custom exceptions for the LLM client.

Wraps errors from the official openai/anthropic libraries into a unified hierarchy.
"""

from __future__ import annotations

from typing import Any


class LLMError(Exception):
    """Base exception for all LLM client errors."""

    def __init__(self, message: str, provider: str = "", raw: Any = None):
        self.provider = provider
        self.raw = raw
        super().__init__(message)


class AuthenticationError(LLMError):
    """Invalid or missing API key (HTTP 401/403)."""


class RateLimitError(LLMError):
    """Too many requests (HTTP 429)."""

    def __init__(
        self,
        message: str,
        provider: str = "",
        raw: Any = None,
        retry_after: float | None = None,
    ):
        self.retry_after = retry_after
        super().__init__(message, provider, raw)


class InvalidRequestError(LLMError):
    """Bad request — malformed body, unsupported params, etc. (HTTP 400)."""


class NotFoundError(LLMError):
    """Model or resource not found (HTTP 404)."""


class ServerError(LLMError):
    """Provider returned a 5xx error."""


class StreamError(LLMError):
    """Error during streaming (connection drop, malformed chunk, etc.)."""


class TimeoutError(LLMError):
    """Request timed out."""


class ConnectionError(LLMError):
    """Could not connect to the provider."""


def wrap_openai_error(e: Exception, provider: str = "openai") -> LLMError:
    """Convert an openai library exception into our unified error type."""
    import openai as oai

    msg = str(e)
    if isinstance(e, oai.AuthenticationError):
        return AuthenticationError(msg, provider=provider, raw=e)
    if isinstance(e, oai.RateLimitError):
        return RateLimitError(msg, provider=provider, raw=e)
    if isinstance(e, oai.BadRequestError):
        return InvalidRequestError(msg, provider=provider, raw=e)
    if isinstance(e, oai.NotFoundError):
        return NotFoundError(msg, provider=provider, raw=e)
    if isinstance(e, oai.InternalServerError):
        return ServerError(msg, provider=provider, raw=e)
    if isinstance(e, oai.APITimeoutError):
        return TimeoutError(msg, provider=provider, raw=e)
    if isinstance(e, oai.APIConnectionError):
        return ConnectionError(msg, provider=provider, raw=e)
    if isinstance(e, oai.APIStatusError):
        return LLMError(msg, provider=provider, raw=e)
    return LLMError(msg, provider=provider, raw=e)


def wrap_anthropic_error(e: Exception, provider: str = "anthropic") -> LLMError:
    """Convert an anthropic library exception into our unified error type."""
    import anthropic as ant

    msg = str(e)
    if isinstance(e, ant.AuthenticationError):
        return AuthenticationError(msg, provider=provider, raw=e)
    if isinstance(e, ant.RateLimitError):
        return RateLimitError(msg, provider=provider, raw=e)
    if isinstance(e, ant.BadRequestError):
        return InvalidRequestError(msg, provider=provider, raw=e)
    if isinstance(e, ant.NotFoundError):
        return NotFoundError(msg, provider=provider, raw=e)
    if isinstance(e, ant.InternalServerError):
        return ServerError(msg, provider=provider, raw=e)
    if isinstance(e, ant.APITimeoutError):
        return TimeoutError(msg, provider=provider, raw=e)
    if isinstance(e, ant.APIConnectionError):
        return ConnectionError(msg, provider=provider, raw=e)
    if isinstance(e, ant.APIStatusError):
        return LLMError(msg, provider=provider, raw=e)
    return LLMError(msg, provider=provider, raw=e)
