"""Base provider interface."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any, AsyncIterator

from ..types import ChatResponse, EmbeddingResponse, Message, StreamChunk, ToolParam


class BaseProvider(ABC):
    """Every provider implements this interface."""

    name: str = ""

    @abstractmethod
    async def chat(
        self,
        messages: list[Message],
        model: str,
        *,
        temperature: float | None = None,
        max_tokens: int | None = None,
        stop: list[str] | str | None = None,
        top_p: float | None = None,
        tools: list[ToolParam] | None = None,
        tool_choice: str | None = None,
        **kwargs: Any,
    ) -> ChatResponse:
        ...

    @abstractmethod
    async def chat_stream(
        self,
        messages: list[Message],
        model: str,
        *,
        temperature: float | None = None,
        max_tokens: int | None = None,
        stop: list[str] | str | None = None,
        top_p: float | None = None,
        **kwargs: Any,
    ) -> AsyncIterator[StreamChunk]:
        ...
        yield  # type: ignore[misc]

    async def embed(
        self,
        input: str | list[str],
        model: str,
        *,
        dimensions: int | None = None,
        **kwargs: Any,
    ) -> EmbeddingResponse:
        raise NotImplementedError(f"{self.name} does not support embeddings")

    async def close(self) -> None:
        """Close any persistent connections. Override in subclasses."""
        pass
