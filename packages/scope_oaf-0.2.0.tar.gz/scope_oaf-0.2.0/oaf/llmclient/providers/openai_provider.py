"""OpenAI provider — uses the official openai Python library.

Features:
  - Automatic retries with exponential backoff (built into the library)
  - Connection pooling via httpx under the hood
  - Proper SSE streaming via the library's stream API
  - Embeddings support
  - Vision (multimodal) support via content blocks
"""

from __future__ import annotations

from typing import Any, AsyncIterator

import openai

from ..errors import StreamError, wrap_openai_error
from .base import BaseProvider
from ..types import (
    ChatResponse,
    EmbeddingData,
    EmbeddingResponse,
    ImageContent,
    Message,
    StreamChunk,
    ToolCall,
    ToolParam,
    Usage,
)


class OpenAIProvider(BaseProvider):
    name = "openai"

    def __init__(
        self,
        api_key: str,
        base_url: str | None = None,
        org_id: str | None = None,
        timeout: float = 120,
        max_retries: int = 2,
    ):
        self._client = openai.AsyncOpenAI(
            api_key=api_key,
            base_url=base_url,
            organization=org_id,
            timeout=timeout,
            max_retries=max_retries,
        )

    async def close(self) -> None:
        await self._client.close()

    # ── unified → OpenAI ──────────────────────────────────────────────────

    @staticmethod
    def _convert_messages(messages: list[Message]) -> list[dict[str, Any]]:
        out: list[dict[str, Any]] = []
        for m in messages:
            # Tool result message
            if m.role == "tool":
                out.append({
                    "role": "user",
                    "content": m.content or "",
                })
                continue

            msg: dict[str, Any] = {"role": m.role}

            if isinstance(m.content, list):
                parts: list[dict[str, Any]] = []
                for block in m.content:
                    if isinstance(block, str):
                        parts.append({"type": "text", "text": block})
                    elif isinstance(block, ImageContent):
                        url = block.url
                        if not url and block.base64_data:
                            url = f"data:{block.media_type};base64,{block.base64_data}"
                        parts.append({
                            "type": "image_url",
                            "image_url": {"url": url},
                        })
                out.append({**msg, "content": parts})
                continue

            if m.content is not None:
                msg["content"] = m.content

            if m.name:
                msg["name"] = m.name

            # Assistant message with tool calls
            if m.tool_calls:
                msg["tool_calls"] = [
                    {
                        "type": "function",
                        "function": {"name": tc.name, "arguments": tc.arguments},
                    }
                    for tc in m.tool_calls
                ]

            out.append(msg)
        return out

    # ── OpenAI response → unified ────────────────────────────────────────

    @staticmethod
    def _parse_response(response: Any) -> ChatResponse:
        # Take the first choice only
        c = response.choices[0]
        tool_calls = None
        if c.message.tool_calls:
            tool_calls = [
                ToolCall(
                    name=tc.function.name,
                    arguments=tc.function.arguments,
                )
                for tc in c.message.tool_calls
            ]
        message = Message(
            role=c.message.role or "assistant",
            content=c.message.content,
            tool_calls=tool_calls,
        )

        usage = Usage()
        if response.usage:
            usage = Usage(
                prompt_tokens=response.usage.prompt_tokens or 0,
                completion_tokens=response.usage.completion_tokens or 0,
                total_tokens=response.usage.total_tokens or 0,
            )

        return ChatResponse(
            id=response.id or "",
            model=response.model or "",
            message=message,
            finish_reason=c.finish_reason,
            usage=usage,
            provider="openai",
            raw=response,
        )

    # ── non-streaming ─────────────────────────────────────────────────────

    async def chat(
        self,
        messages: list[Message],
        model: str,
        *,
        temperature: float | None = None,
        max_tokens: int | None = None,
        stop: list[str] | str | None = None,
        top_p: float | None = None,
        tools: list[ToolParam] | None = None,
        tool_choice: str | None = None,
        **kwargs: Any,
    ) -> ChatResponse:
        params: dict[str, Any] = {
            "model": model,
            "messages": self._convert_messages(messages),
        }
        if temperature is not None:
            params["temperature"] = temperature
        if max_tokens is not None:
            params["max_tokens"] = max_tokens
        if stop:
            params["stop"] = stop
        if top_p is not None:
            params["top_p"] = top_p
        if tools:
            params["tools"] = [
                {"type": t.type, "function": {
                    "name": t.function.name,
                    "description": t.function.description,
                    "parameters": t.function.parameters,
                }} for t in tools
            ]
        if tool_choice is not None:
            params["tool_choice"] = tool_choice
        params.update(kwargs)

        try:
            response = await self._client.chat.completions.create(**params)
        except openai.APIError as e:
            raise wrap_openai_error(e) from e

        result = self._parse_response(response)
        result.request_payload = params
        return result

    # ── streaming ─────────────────────────────────────────────────────────

    async def chat_stream(
        self,
        messages: list[Message],
        model: str,
        *,
        temperature: float | None = None,
        max_tokens: int | None = None,
        stop: list[str] | str | None = None,
        top_p: float | None = None,
        **kwargs: Any,
    ) -> AsyncIterator[StreamChunk]:
        params: dict[str, Any] = {
            "model": model,
            "messages": self._convert_messages(messages),
            "stream": True,
            "stream_options": {"include_usage": True},
        }
        if temperature is not None:
            params["temperature"] = temperature
        if max_tokens is not None:
            params["max_tokens"] = max_tokens
        if stop:
            params["stop"] = stop
        if top_p is not None:
            params["top_p"] = top_p
        params.update(kwargs)

        try:
            stream = await self._client.chat.completions.create(**params)
        except openai.APIError as e:
            raise wrap_openai_error(e) from e

        first = True
        try:
            async for chunk in stream:
                delta_text = None
                finish_reason = None

                if chunk.choices:
                    c = chunk.choices[0]
                    delta_text = c.delta.content if c.delta else None
                    finish_reason = c.finish_reason

                usage = None
                if chunk.usage:
                    usage = Usage(
                        prompt_tokens=chunk.usage.prompt_tokens or 0,
                        completion_tokens=chunk.usage.completion_tokens or 0,
                        total_tokens=chunk.usage.total_tokens or 0,
                    )

                sc = StreamChunk(
                    id=chunk.id or "",
                    model=chunk.model or "",
                    delta_text=delta_text,
                    finish_reason=finish_reason,
                    usage=usage,
                    provider="openai",
                )
                if first:
                    sc.request_payload = params
                    first = False
                yield sc
        except openai.APIError as e:
            raise wrap_openai_error(e) from e
        except Exception as e:
            if not isinstance(e, StreamError):
                raise StreamError(f"[openai] Stream error: {e}", provider="openai") from e
            raise

    # ── embeddings ────────────────────────────────────────────────────────

    async def embed(
        self,
        input: str | list[str],
        model: str,
        *,
        dimensions: int | None = None,
        **kwargs: Any,
    ) -> EmbeddingResponse:
        params: dict[str, Any] = {
            "model": model,
            "input": input,
            "encoding_format": "float",
        }
        if dimensions is not None:
            params["dimensions"] = dimensions
        params.update(kwargs)

        try:
            response = await self._client.embeddings.create(**params)
        except openai.APIError as e:
            raise wrap_openai_error(e) from e

        data = [
            EmbeddingData(index=d.index, embedding=d.embedding)
            for d in response.data
        ]
        usage = Usage(
            prompt_tokens=response.usage.prompt_tokens or 0,
            total_tokens=response.usage.total_tokens or 0,
        )
        return EmbeddingResponse(
            model=response.model,
            data=data,
            usage=usage,
            provider="openai",
        )
