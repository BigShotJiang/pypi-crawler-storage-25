﻿"""
Synchronous wrapper around the async LLMClient.

Uses a dedicated event loop in a background thread so it works
from non-async code without blocking any running event loop.
"""

from __future__ import annotations

import asyncio
import threading
from typing import Any, Iterator

from .client import LLMClient
from .types import ChatResponse, EmbeddingResponse, Message, StreamChunk


class _LoopThread:
    """Manages a single background event loop shared by all SyncLLMClients."""

    _lock = threading.Lock()
    _loop: asyncio.AbstractEventLoop | None = None
    _thread: threading.Thread | None = None

    @classmethod
    def get_loop(cls) -> asyncio.AbstractEventLoop:
        with cls._lock:
            if cls._loop is None or cls._loop.is_closed():
                cls._loop = asyncio.new_event_loop()
                cls._thread = threading.Thread(
                    target=cls._loop.run_forever,
                    daemon=True,
                    name="llmclient-sync-loop",
                )
                cls._thread.start()
            return cls._loop


def _run(coro: Any) -> Any:
    """Submit a coroutine to the background loop and block for the result."""
    loop = _LoopThread.get_loop()
    future = asyncio.run_coroutine_threadsafe(coro, loop)
    return future.result()


class SyncLLMClient:
    """
    Synchronous LLM client — same interface as LLMClient but blocking.

    Usage:
        client = SyncLLMClient(openai_api_key="sk-...")
        resp = client.chat("gpt-4o", [Message(role="user", content="Hi")])
        print(resp.text)

        for chunk in client.chat_stream("gpt-4o", [Message(role="user", content="Hi")]):
            print(chunk.delta_text, end="")

        client.close()

    Context manager:
        with SyncLLMClient() as client:
            resp = client.chat(...)
    """

    def __init__(self, **kwargs: Any):
        self._async_client = LLMClient(**kwargs)

    def __enter__(self) -> SyncLLMClient:
        return self

    def __exit__(self, *exc: Any) -> None:
        self.close()

    def close(self) -> None:
        _run(self._async_client.close())

    def register_provider(self, name: str, provider: Any) -> None:
        self._async_client.register_provider(name, provider)

    def chat(
        self,
        model: str,
        messages: list[Message],
        *,
        provider: str | None = None,
        temperature: float | None = None,
        max_tokens: int | None = None,
        stop: list[str] | str | None = None,
        top_p: float | None = None,
        **kwargs: Any,
    ) -> ChatResponse:
        return _run(self._async_client.chat(
            model, messages,
            provider=provider, temperature=temperature,
            max_tokens=max_tokens, stop=stop,
            top_p=top_p, **kwargs,
        ))

    def chat_stream(
        self,
        model: str,
        messages: list[Message],
        *,
        provider: str | None = None,
        temperature: float | None = None,
        max_tokens: int | None = None,
        stop: list[str] | str | None = None,
        top_p: float | None = None,
        **kwargs: Any,
    ) -> Iterator[StreamChunk]:
        """Yields StreamChunks synchronously."""
        loop = _LoopThread.get_loop()
        queue: asyncio.Queue[StreamChunk | None] = asyncio.Queue()

        async def _producer() -> None:
            try:
                async for c in self._async_client.chat_stream(
                    model, messages,
                    provider=provider, temperature=temperature,
                    max_tokens=max_tokens, stop=stop,
                    top_p=top_p, **kwargs,
                ):
                    await queue.put(c)
            finally:
                await queue.put(None)  # sentinel

        future = asyncio.run_coroutine_threadsafe(_producer(), loop)

        while True:
            item_future = asyncio.run_coroutine_threadsafe(queue.get(), loop)
            item = item_future.result()
            if item is None:
                break
            yield item

        # re-raise any exception from the producer
        future.result()

    def embed(
        self,
        model: str,
        input: str | list[str],
        *,
        provider: str | None = None,
        dimensions: int | None = None,
        **kwargs: Any,
    ) -> EmbeddingResponse:
        return _run(self._async_client.embed(
            model, input, provider=provider, dimensions=dimensions, **kwargs,
        ))

    def ask(
        self,
        model: str,
        prompt: str,
        *,
        system: str | None = None,
        **kwargs: Any,
    ) -> str:
        return _run(self._async_client.ask(model, prompt, system=system, **kwargs))

    def ask_stream(
        self,
        model: str,
        prompt: str,
        *,
        system: str | None = None,
        **kwargs: Any,
    ) -> Iterator[str]:
        msgs: list[Message] = []
        if system:
            msgs.append(Message(role="system", content=system))
        msgs.append(Message(role="user", content=prompt))
        for chunk in self.chat_stream(model, msgs, **kwargs):
            if chunk.delta_text:
                yield chunk.delta_text
