"""Integration tests for llmclient — chat, tools, streaming.

Tests that we receive correct response structure, finish reasons,
tool call data, and token usage from the actual OpenAI API.

Run from project root: python -m src.llmclient.test_llmclient
"""

import asyncio
import sys
from dotenv import load_dotenv

load_dotenv()

from oaf.llmclient import (
    LLMClient,
    Message,
    ToolParam,
    FunctionDef,
    ChatResponse,
    ToolCall,
    Usage,
    StreamChunk,
)

MODEL = "gpt-4.1-nano"
client = LLMClient()
passed = 0
failed = 0


def report(name: str, ok: bool, detail: str = ""):
    global passed, failed
    if ok:
        passed += 1
        print(f"  ✓ {name}")
    else:
        failed += 1
        print(f"  ✗ {name} — {detail}")


async def test_basic_chat():
    """Basic chat: get text back, finish_reason=stop, usage present."""
    print("\n── test_basic_chat ──")
    r = await client.chat(MODEL, [Message(role="user", content="Say 'hello'")])

    report("returns ChatResponse", isinstance(r, ChatResponse))
    report("has text", bool(r.text))
    report("role is assistant", r.message.role == "assistant")
    report("finish_reason is stop", r.finish_reason == "stop",
           f"got: {r.finish_reason!r}")
    report("usage.prompt_tokens > 0", r.usage.prompt_tokens > 0,
           f"got: {r.usage.prompt_tokens}")
    report("usage.completion_tokens > 0", r.usage.completion_tokens > 0,
           f"got: {r.usage.completion_tokens}")
    report("usage.total_tokens > 0", r.usage.total_tokens > 0,
           f"got: {r.usage.total_tokens}")
    report("provider is openai", r.provider == "openai", f"got: {r.provider!r}")
    report("model is set", bool(r.model), f"got: {r.model!r}")
    report("id is set", bool(r.id), f"got: {r.id!r}")
    report("request_payload is dict", isinstance(r.request_payload, dict))
    report("no tool_calls on message", r.message.tool_calls is None)


async def test_finish_reason_length():
    """Force truncation with max_tokens=1 → finish_reason=length."""
    print("\n── test_finish_reason_length ──")
    r = await client.chat(
        MODEL,
        [Message(role="user", content="Write a long essay about the ocean")],
        max_tokens=1,
    )

    report("finish_reason is length", r.finish_reason == "length",
           f"got: {r.finish_reason!r}")
    report("completion_tokens <= 1", r.usage.completion_tokens <= 1,
           f"got: {r.usage.completion_tokens}")


WEATHER_TOOL = ToolParam(
    type="function",
    function=FunctionDef(
        name="get_weather",
        description="Get the current weather for a city",
        parameters={
            "type": "object",
            "properties": {
                "city": {"type": "string", "description": "The city name"},
            },
            "required": ["city"],
        },
    ),
)


async def test_tool_call_single():
    """Send a tool, model calls it → finish_reason=tool_calls, ToolCall data present."""
    print("\n── test_tool_call_single ──")
    r = await client.chat(
        MODEL,
        [Message(role="user", content="What's the weather in Tokyo?")],
        tools=[WEATHER_TOOL],
        tool_choice="auto",
    )

    tc_list = r.message.tool_calls

    report("finish_reason is tool_calls", r.finish_reason == "tool_calls",
           f"got: {r.finish_reason!r}")
    report("tool_calls is a list", isinstance(tc_list, list),
           f"got: {type(tc_list)}")
    report("at least 1 tool call", tc_list is not None and len(tc_list) >= 1,
           f"got: {len(tc_list) if tc_list else 0}")

    if tc_list:
        tc = tc_list[0]
        report("ToolCall has name", tc.name == "get_weather",
               f"got: {tc.name!r}")
        report("ToolCall has arguments (str)", isinstance(tc.arguments, str),
               f"got: {type(tc.arguments)}")
        report("parsed_arguments has city", "city" in tc.parsed_arguments,
               f"got: {tc.parsed_arguments}")
        report("content is None/empty", not r.message.content,
               f"got: {r.message.content!r}")
    report("usage present", r.usage.total_tokens > 0)


async def test_tool_result_roundtrip():
    """Full tool round-trip: call → execute → send result → get text back."""
    print("\n── test_tool_result_roundtrip ──")

    # Step 1: send message with tool
    messages = [Message(role="user", content="What's the weather in Paris?")]
    r1 = await client.chat(MODEL, messages, tools=[WEATHER_TOOL], tool_choice="auto")

    choice1 = r1
    tc_list = choice1.message.tool_calls or []
    report("step1: got tool_calls", len(tc_list) >= 1, f"got {len(tc_list)} calls")

    if not tc_list:
        report("SKIPPED remaining (no tool call)", False, "model didn't call tool")
        return

    tc = tc_list[0]

    # Step 2: add assistant msg + tool result, call again
    messages.append(choice1.message)  # assistant with tool_calls
    messages.append(Message(
        role="user",
        content='{"tool_results": [{"tool": "get_weather", "result": "Sunny, 22°C in Paris"}]}',
    ))

    r2 = await client.chat(MODEL, messages, tools=[WEATHER_TOOL])

    report("step2: finish_reason is stop", r2.finish_reason == "stop",
           f"got: {r2.finish_reason!r}")
    report("step2: has text response", bool(r2.text), f"got: {r2.text!r}")
    report("step2: text mentions Paris or weather",
           "paris" in r2.text.lower() or "sunny" in r2.text.lower() or "22" in r2.text,
           f"got: {r2.text!r}")


async def test_multiple_tools():
    """Register 2 tools, ask a question that triggers both."""
    print("\n── test_multiple_tools ──")

    time_tool = ToolParam(
        type="function",
        function=FunctionDef(
            name="get_time",
            description="Get the current time in a city",
            parameters={
                "type": "object",
                "properties": {
                    "city": {"type": "string", "description": "The city name"},
                },
                "required": ["city"],
            },
        ),
    )

    r = await client.chat(
        MODEL,
        [Message(role="user", content="What's the weather AND the current time in London? Use both tools.")],
        tools=[WEATHER_TOOL, time_tool],
        tool_choice="auto",
    )

    tc_list = r.message.tool_calls or []
    report("finish_reason is tool_calls", r.finish_reason == "tool_calls",
           f"got: {r.finish_reason!r}")
    report("got 2 tool calls", len(tc_list) == 2,
           f"got: {len(tc_list)} — names: {[t.name for t in tc_list]}")

    if len(tc_list) >= 2:
        names = {t.name for t in tc_list}
        report("both tools called", names == {"get_weather", "get_time"},
               f"got: {names}")
        for tc in tc_list:
            report(f"  {tc.name} has arguments", bool(tc.arguments))


async def test_streaming():
    """Streaming: get chunks with delta_text, final chunk has finish_reason."""
    print("\n── test_streaming ──")

    chunks = []
    async for chunk in client.chat_stream(
        MODEL,
        [Message(role="user", content="Say 'hello world'")],
    ):
        chunks.append(chunk)

    report("got chunks", len(chunks) > 0, f"got: {len(chunks)}")
    report("chunks are StreamChunk", all(isinstance(c, StreamChunk) for c in chunks))

    text_chunks = [c for c in chunks if c.delta_text]
    report("some chunks have delta_text", len(text_chunks) > 0,
           f"got: {len(text_chunks)} text chunks")

    full_text = "".join(c.delta_text for c in chunks if c.delta_text)
    report("assembled text is non-empty", bool(full_text), f"got: {full_text!r}")

    finish_chunks = [c for c in chunks if c.finish_reason]
    report("at least one chunk has finish_reason", len(finish_chunks) >= 1,
           f"got: {len(finish_chunks)}")
    if finish_chunks:
        report("finish_reason is stop", finish_chunks[-1].finish_reason == "stop",
               f"got: {finish_chunks[-1].finish_reason!r}")


async def test_tool_choice_none():
    """tool_choice='none' forces model to NOT call tools even when available."""
    print("\n── test_tool_choice_none ──")
    r = await client.chat(
        MODEL,
        [Message(role="user", content="What's the weather in Tokyo?")],
        tools=[WEATHER_TOOL],
        tool_choice="none",
    )

    report("finish_reason is stop", r.finish_reason == "stop",
           f"got: {r.finish_reason!r}")
    report("no tool_calls", r.message.tool_calls is None,
           f"got: {r.message.tool_calls}")
    report("has text", bool(r.text))


async def main():
    print("═══ llmclient integration tests (real API) ═══")

    await test_basic_chat()
    await test_finish_reason_length()
    await test_tool_call_single()
    await test_tool_result_roundtrip()
    await test_multiple_tools()
    await test_streaming()
    await test_tool_choice_none()

    print(f"\n═══ Results: {passed} passed, {failed} failed ═══")
    sys.exit(1 if failed else 0)


if __name__ == "__main__":
    asyncio.run(main())
