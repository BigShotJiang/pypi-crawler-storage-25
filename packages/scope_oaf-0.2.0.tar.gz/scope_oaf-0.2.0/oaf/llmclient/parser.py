"""JSON response parser for agent tool calling.

Parses LLM text output as structured JSON with optional tool_calls and response fields.
Used by the agent to implement JSON-based tool calling instead of native API tool calling.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any


class ParseError(Exception):
    """Raised when the LLM response is not valid JSON or has wrong structure."""

    def __init__(self, message: str, raw_text: str):
        super().__init__(message)
        self.raw_text = raw_text


@dataclass
class ParsedToolCall:
    """A tool call extracted from a JSON response."""
    name: str = ""
    args: dict[str, Any] = field(default_factory=dict)


@dataclass
class ParsedResponse:
    """Parsed LLM JSON response."""
    tool_calls: list[ParsedToolCall] = field(default_factory=list)
    response: str | None = None
    raw_json: dict[str, Any] = field(default_factory=dict)


def parse_response(text: str) -> ParsedResponse:
    """Parse LLM text as a JSON tool-calling response.

    Expected format::

        {"tool_calls": [{"name": "...", "args": {...}}], "response": "..."}

    At least one of ``tool_calls`` or ``response`` must be present.

    Raises:
        ParseError: If JSON is invalid or required structure is missing.
    """
    text = text.strip()

    # Strip markdown code fences if present
    if text.startswith("```"):
        lines = text.split("\n")
        if lines[-1].strip() == "```":
            text = "\n".join(lines[1:-1]).strip()

    try:
        data = json.loads(text)
    except json.JSONDecodeError as e:
        raise ParseError(f"Invalid JSON: {e}", text) from e

    if not isinstance(data, dict):
        raise ParseError("Response must be a JSON object", text)

    has_tools = bool(data.get("tool_calls"))
    has_response = bool(data.get("response"))

    if not has_tools and not has_response:
        raise ParseError(
            "Response must contain at least 'tool_calls' or 'response'", text
        )

    tool_calls: list[ParsedToolCall] = []
    if has_tools:
        raw_calls = data["tool_calls"]
        if not isinstance(raw_calls, list):
            raise ParseError("'tool_calls' must be an array", text)
        for i, tc in enumerate(raw_calls):
            if not isinstance(tc, dict):
                raise ParseError(f"tool_calls[{i}] must be an object", text)
            if "name" not in tc:
                raise ParseError(f"tool_calls[{i}] missing 'name'", text)
            args = tc.get("args", {})
            if not isinstance(args, dict):
                raise ParseError(f"tool_calls[{i}].args must be an object", text)
            tool_calls.append(ParsedToolCall(name=tc["name"], args=args))

    return ParsedResponse(
        tool_calls=tool_calls,
        response=data.get("response"),
        raw_json=data,
    )
