"""Integration tests for llmclient — vision, embeddings, ask helpers, sync client.

Tests capabilities beyond basic chat and tool calling.

Run from project root: python -m src.llmclient.test_llmclient_extras
"""

import asyncio
import sys
from dotenv import load_dotenv

load_dotenv()

from oaf.llmclient import (
    LLMClient,
    SyncLLMClient,
    Message,
    ImageContent,
    ChatResponse,
    StreamChunk,
    EmbeddingResponse,
    EmbeddingData,
)

MODEL = "gpt-4.1-nano"
client = LLMClient()
passed = 0
failed = 0


def report(name: str, ok: bool, detail: str = ""):
    global passed, failed
    if ok:
        passed += 1
        print(f"  ✓ {name}")
    else:
        failed += 1
        print(f"  ✗ {name} — {detail}")


# ── Vision ────────────────────────────────────────────────────────────────────

# A simple, reliable public test image
_TEST_IMAGE = "https://www.google.com/images/branding/googlelogo/2x/googlelogo_color_272x92dp.png"


async def test_vision_url():
    """Send an image URL, model describes it."""
    print("\n── test_vision_url ──")
    r = await client.chat(MODEL, [
        Message(role="user", content=[
            "What is in this image? Answer in one sentence.",
            ImageContent(url=_TEST_IMAGE),
        ]),
    ])

    report("returns ChatResponse", isinstance(r, ChatResponse))
    report("has text", bool(r.text))
    report("finish_reason is stop", r.finish_reason == "stop",
           f"got: {r.finish_reason!r}")
    report("usage present", r.usage.total_tokens > 0)
    print(f"    Response: {r.text[:100]}...")


async def test_vision_multipart():
    """Send text + image together in a multi-part message."""
    print("\n── test_vision_multipart ──")
    r = await client.chat(MODEL, [
        Message(role="system", content="You describe images concisely."),
        Message(role="user", content=[
            "Describe the colors you see.",
            ImageContent(url=_TEST_IMAGE),
        ]),
    ])

    report("has text", bool(r.text))
    report("role is assistant", r.message.role == "assistant")
    report("usage.prompt_tokens > 0", r.usage.prompt_tokens > 0)
    print(f"    Response: {r.text[:100]}...")


# ── Embeddings ────────────────────────────────────────────────────────────────

async def test_embedding_single():
    """Embed a single string."""
    print("\n── test_embedding_single ──")
    r = await client.embed("text-embedding-3-small", "Hello world")

    report("returns EmbeddingResponse", isinstance(r, EmbeddingResponse))
    report("has data", len(r.data) == 1, f"got: {len(r.data)}")
    report("data[0] is EmbeddingData", isinstance(r.data[0], EmbeddingData))
    report("embedding is list of floats",
           isinstance(r.data[0].embedding, list) and len(r.data[0].embedding) > 0)
    report("dimension is 1536", len(r.data[0].embedding) == 1536,
           f"got: {len(r.data[0].embedding)}")
    report("vectors shortcut works", len(r.vectors) == 1)
    report("usage present", r.usage.total_tokens > 0,
           f"got: {r.usage.total_tokens}")
    report("model is set", bool(r.model))


async def test_embedding_batch():
    """Embed multiple strings at once."""
    print("\n── test_embedding_batch ──")
    inputs = ["Hello", "World", "Foo bar"]
    r = await client.embed("text-embedding-3-small", inputs)

    report("got 3 embeddings", len(r.data) == 3, f"got: {len(r.data)}")
    report("vectors has 3 entries", len(r.vectors) == 3)
    report("all vectors same dimension",
           all(len(v) == 1536 for v in r.vectors),
           f"dims: {[len(v) for v in r.vectors]}")
    report("vectors are different (not identical)",
           r.vectors[0][:5] != r.vectors[1][:5])


async def test_embedding_custom_dimensions():
    """Embed with custom dimensions (text-embedding-3-small supports this)."""
    print("\n── test_embedding_custom_dimensions ──")
    r = await client.embed("text-embedding-3-small", "Test", dimensions=256)

    report("got 1 embedding", len(r.data) == 1)
    report("dimension is 256", len(r.data[0].embedding) == 256,
           f"got: {len(r.data[0].embedding)}")


# ── ask() helper ──────────────────────────────────────────────────────────────

async def test_ask():
    """ask() returns a plain string."""
    print("\n── test_ask ──")
    text = await client.ask(MODEL, "Say 'hello'")

    report("returns str", isinstance(text, str))
    report("non-empty", bool(text))


async def test_ask_with_system():
    """ask() with a system prompt."""
    print("\n── test_ask_with_system ──")
    text = await client.ask(
        MODEL,
        "What are you?",
        system="You are a helpful robot named Beep. Always start your answer with 'Beep boop'.",
    )

    report("returns str", isinstance(text, str))
    report("non-empty", bool(text))
    report("system prompt respected", "beep" in text.lower(),
           f"got: {text[:80]!r}")


# ── ask_stream() helper ──────────────────────────────────────────────────────

async def test_ask_stream():
    """ask_stream() yields plain strings."""
    print("\n── test_ask_stream ──")

    chunks = []
    async for text in client.ask_stream(MODEL, "Say 'hello world'"):
        chunks.append(text)

    report("got chunks", len(chunks) > 0)
    report("all chunks are str", all(isinstance(c, str) for c in chunks))

    full = "".join(chunks)
    report("assembled text non-empty", bool(full), f"got: {full!r}")


# ── SyncLLMClient ─────────────────────────────────────────────────────────────

async def test_sync_client():
    """SyncLLMClient works for chat and streaming."""
    print("\n── test_sync_client ──")

    # Run sync client in a thread to avoid blocking the event loop
    import concurrent.futures
    def _sync_test():
        results = {}
        sc = SyncLLMClient()

        # chat
        r = sc.chat(MODEL, [Message(role="user", content="Say 'hi'")])
        results["chat_ok"] = isinstance(r, ChatResponse) and bool(r.text)
        results["chat_text"] = r.text

        # ask
        text = sc.ask(MODEL, "Say 'hello'")
        results["ask_ok"] = isinstance(text, str) and bool(text)

        # streaming
        chunks = list(sc.chat_stream(MODEL, [Message(role="user", content="Say 'yo'")]))
        results["stream_ok"] = len(chunks) > 0
        results["stream_types"] = all(isinstance(c, StreamChunk) for c in chunks)

        # embed
        emb = sc.embed("text-embedding-3-small", "test")
        results["embed_ok"] = len(emb.data) == 1 and len(emb.data[0].embedding) > 0

        sc.close()
        return results

    loop = asyncio.get_event_loop()
    with concurrent.futures.ThreadPoolExecutor() as pool:
        results = await loop.run_in_executor(pool, _sync_test)

    report("sync chat works", results["chat_ok"], f"text: {results.get('chat_text', '')[:50]!r}")
    report("sync ask works", results["ask_ok"])
    report("sync stream works", results["stream_ok"])
    report("sync stream types correct", results["stream_types"])
    report("sync embed works", results["embed_ok"])


# ── Multi-turn context ────────────────────────────────────────────────────────

async def test_multi_turn():
    """Verify the model sees prior messages in a multi-turn conversation."""
    print("\n── test_multi_turn ──")
    msgs = [
        Message(role="system", content="You are a helpful assistant."),
        Message(role="user", content="My name is Zaphod."),
    ]
    r1 = await client.chat(MODEL, msgs)
    msgs.append(r1.message)

    msgs.append(Message(role="user", content="What is my name?"))
    r2 = await client.chat(MODEL, msgs)

    report("remembers name", "zaphod" in r2.text.lower(),
           f"got: {r2.text[:80]!r}")


# ── Context manager ──────────────────────────────────────────────────────────

async def test_context_manager():
    """async with LLMClient() works."""
    print("\n── test_context_manager ──")
    async with LLMClient() as c:
        r = await c.chat(MODEL, [Message(role="user", content="Say 'ok'")])
        report("works inside context manager", bool(r.text))


# ── Main ──────────────────────────────────────────────────────────────────────

async def main():
    print("═══ llmclient extras tests (vision, embeddings, helpers, sync) ═══")

    tests = [
        test_vision_url,
        test_vision_multipart,
        test_embedding_single,
        test_embedding_batch,
        test_embedding_custom_dimensions,
        test_ask,
        test_ask_with_system,
        test_ask_stream,
        test_sync_client,
        test_multi_turn,
        test_context_manager,
    ]
    for t in tests:
        try:
            await t()
        except Exception as e:
            global failed
            failed += 1
            print(f"  ✗ {t.__name__} CRASHED — {type(e).__name__}: {e}")

    print(f"\n═══ Results: {passed} passed, {failed} failed ═══")
    sys.exit(1 if failed else 0)


if __name__ == "__main__":
    asyncio.run(main())
