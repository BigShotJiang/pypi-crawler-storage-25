"""Unified types for the LLM client.

Message-in / message-out, streaming, tool calling, embedings.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any, Literal


# ── Messages ──────────────────────────────────────────────────────────────────

@dataclass
class ImageContent:
    """An image block inside a message."""
    url: str | None = None          # data URI or https URL
    base64_data: str | None = None  # raw base64
    media_type: str = "image/png"   # mime type (image/png, image/jpeg, image/webp, image/gif)


@dataclass
class DocumentContent:
    """A document block (PDF) inside a message — base64 encoded."""
    base64_data: str = ""
    media_type: str = "application/pdf"


@dataclass
class Message:
    """
    Unified message representation.

    role: "system" | "user" | "assistant" | "tool"
    content: text (str), or list of mixed text/image/document blocks
    """
    role: Literal["system", "user", "assistant", "tool"] = "user"
    content: str | list[str | ImageContent | DocumentContent] | None = None
    name: str | None = None         # optional name for the message
    tool_calls: list[ToolCall] | None = None    # tool calls from assistant


# ── Tool Calling ──────────────────────────────────────────────────────────────

@dataclass
class FunctionDef:
    """Function definition for a tool."""
    name: str = ""
    description: str = ""
    parameters: dict[str, Any] = field(default_factory=dict)  # JSON Schema
    group: str = ""              # optional group name
    group_description: str = ""  # optional group description


@dataclass
class ToolParam:
    """A tool parameter to send to the API."""
    type: str = "function"
    function: FunctionDef = field(default_factory=FunctionDef)


@dataclass
class ToolCall:
    """A tool call returned by the model."""
    name: str = ""
    arguments: str = ""  # JSON string

    @property
    def parsed_arguments(self) -> dict[str, Any]:
        if not self.arguments:
            return {}
        return json.loads(self.arguments)


@dataclass
class ToolResult:
    """Record of a tool call that was executed."""
    name: str = ""
    args: dict[str, Any] = field(default_factory=dict)
    result: str = ""


# ── Responses ─────────────────────────────────────────────────────────────────

@dataclass
class Usage:
    prompt_tokens: int = 0
    completion_tokens: int = 0
    total_tokens: int = 0


@dataclass
class ChatResponse:
    """Full (non-streaming) completion response."""
    id: str = ""
    model: str = ""
    message: Message = field(default_factory=Message)
    finish_reason: str | None = None  # "stop", "length", "tool_calls"
    usage: Usage = field(default_factory=Usage)
    tools_called: list[ToolResult] = field(default_factory=list)
    raw_text: str = ""              # original text from the model before parsing
    provider: str = ""              # "openai" or "anthropic"
    raw: Any = None                 # raw provider response object
    request_payload: dict[str, Any] | None = None  # the full payload sent to the API

    @property
    def text(self) -> str:
        """Convenience: get the text content."""
        if self.message.content:
            c = self.message.content
            return c if isinstance(c, str) else str(c)
        return ""


@dataclass
class StreamChunk:
    """One chunk in a streaming response."""
    id: str = ""
    model: str = ""
    delta_text: str | None = None
    finish_reason: str | None = None
    usage: Usage | None = None      # some providers send usage at the end
    provider: str = ""
    request_payload: dict[str, Any] | None = None  # set on the first chunk only


# ── Embeddings ────────────────────────────────────────────────────────────────

@dataclass
class EmbeddingData:
    """A single embedding vector."""
    index: int = 0
    embedding: list[float] = field(default_factory=list)


@dataclass
class EmbeddingResponse:
    """Response from an embeddings request."""
    model: str = ""
    data: list[EmbeddingData] = field(default_factory=list)
    usage: Usage = field(default_factory=Usage)
    provider: str = ""

    @property
    def vectors(self) -> list[list[float]]:
        """Convenience: get all embedding vectors in order."""
        return [d.embedding for d in sorted(self.data, key=lambda d: d.index)]
