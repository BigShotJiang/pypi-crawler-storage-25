"""Agent — async-only agent with LLM call + tool execution loop."""

from __future__ import annotations

import json
from typing import Any, AsyncIterator, Literal

from .llmclient import LLMClient, Message, ChatResponse, StreamChunk, ToolCall, ToolResult
from .context import BaseContext, ConversationalInMemory
from .hooks import Hooks
from .prompts import BasePromptBuilder, DefaultPromptBuilder
from .tools import ToolRegistry


class Agent:
    """Minimal async agent. Calls the LLM, executes tools, tracks conversation history.

    Usage::

        agent = Agent(model="gpt-4.1-nano", system_prompt="You are helpful.")
        response = await agent.message("Hello!", role="user")
        print(response.text)
    """

    def __init__(
        self,
        *,
        model: str = "gpt-4.1-nano",
        system_prompt: str = "You are a helpful assistant.",
        temperature: float = 0.7,
        max_tokens: int | None = None,
        context: BaseContext | None = None,
        prompt_builder: BasePromptBuilder | None = None,
        tools: ToolRegistry | None = None,
        hooks: Hooks | None = None,
        max_tool_rounds: int = 10,
    ):
        """Create an agent.

        Args:
            model: LLM model identifier (e.g. "gpt-4.1-nano", "claude-sonnet-4-20250514").
            system_prompt: System prompt text. Used only if no prompt_builder is provided.
            temperature: Controls randomness of the LLM output (0.0–2.0). Defaults to 0.7.
            max_tokens: Max tokens the LLM can generate. None for provider default.
            context: Conversation memory backend. Defaults to ConversationalInMemory().
            prompt_builder: Assembles the final message list for the LLM. Defaults to DefaultPromptBuilder.
            tools: Tool registry with available tools. Defaults to empty ToolRegistry().
            hooks: Lifecycle hooks instance. Defaults to a no-op Hooks().
            max_tool_rounds: Max consecutive tool-call rounds to prevent infinite loops. Defaults to 10.
        """
        self.model = model
        self.temperature: float = temperature
        self.max_tokens = max_tokens
        self.context = context or ConversationalInMemory()
        self.prompt_builder = prompt_builder or DefaultPromptBuilder(self.context, system_prompt)
        self.tools = tools or ToolRegistry()
        self.hooks = hooks or Hooks()
        self.max_tool_rounds = max_tool_rounds
        self._client = LLMClient()

    # ── Tool execution ────────────────────────────────────────────────────

    async def _execute_tool_call(self, tc: ToolCall) -> str:
        """Execute a single tool call and return the result as a string.

        Fires before_tool_call / after_tool_call hooks.
        """
        tool = self.tools.get(tc.name)
        if tool is None:
            return json.dumps({"error": f"Unknown tool: {tc.name}"})

        arguments = tc.parsed_arguments

        # Hook: before_tool_call (can replace arguments)
        replaced_args = await self.hooks.trigger("before_tool_call", tc.name, arguments)
        if replaced_args is not None:
            arguments = replaced_args

        try:
            result = await tool(**arguments)
        except Exception as exc:
            await self.hooks.trigger("on_error", exc)
            result = {"error": str(exc)}

        # Hook: after_tool_call
        await self.hooks.trigger("after_tool_call", tc.name, arguments, result)

        # Ensure result is a string for the API
        if not isinstance(result, str):
            result = json.dumps(result)

        return result

    async def _tool_loop(self, response: ChatResponse, **kwargs: Any) -> ChatResponse:
        """Execute tool calls in a loop until the LLM gives a final text response."""
        rounds = 0
        all_tools_called: list[ToolResult] = []
        tool_calls = self._get_tool_calls(response)
        while tool_calls and rounds < self.max_tool_rounds:
            rounds += 1

            # Execute each tool call and collect results
            results: list[dict[str, str]] = []
            for tc in tool_calls:
                result = await self._execute_tool_call(tc)
                results.append({"tool": tc.name, "result": result})
                all_tools_called.append(ToolResult(
                    name=tc.name,
                    args=tc.parsed_arguments,
                    result=result,
                ))

            # Store the tool turn as an atomic group
            tool_calls_dict = [{"name": tc.name, "args": tc.parsed_arguments} for tc in tool_calls]
            self.context.add_tool_turn(
                Message(role="assistant", content=json.dumps({"tool_calls": tool_calls_dict})),
                Message(role="user", content=json.dumps({"tool_results": results})),
            )

            await self.hooks.trigger("on_context_update")

            # Send tool results back to the LLM
            try:
                response = await self._client.chat(
                    model=self.model,
                    messages=self.prompt_builder.build_messages(**kwargs),
                    temperature=self.temperature,
                    max_tokens=self.max_tokens,
                    tools=self.tools.to_tool_params() if len(self.tools) else None,
                    **kwargs,
                )
            except Exception as exc:
                await self.hooks.trigger("on_error", exc)
                raise

            tool_calls = self._get_tool_calls(response)

        response.tools_called = all_tools_called
        return response

    @staticmethod
    def _get_tool_calls(response: ChatResponse) -> list[ToolCall]:
        """Extract tool calls from the response, if any."""
        if response.message.tool_calls:
            return response.message.tool_calls
        return []

    # ── Public API ────────────────────────────────────────────────────────

    async def message(self, message: str, role: Literal['user', 'assistant', 'system'], **kwargs: Any) -> ChatResponse:
        """Send a message, get a response, execute tools if needed, update history.

        Args:
            message: The user message to send.
            **kwargs: Extra arguments forwarded to LLMClient.chat() and prompt_builder.

        Returns:
            The final ChatResponse (after any tool-call rounds).
        """
        self.context.start_turn()

        # Hook: before_message (can replace message text)
        replaced = await self.hooks.trigger(
            "before_message", message, role, self.context.get_messages()
        )
        if replaced is not None:
            message = replaced

        self.context.add_message(Message(role=role, content=message))
        await self.hooks.trigger("on_context_update")

        try:
            response = await self._client.chat(
                model=self.model,
                messages=self.prompt_builder.build_messages(**kwargs),
                temperature=self.temperature,
                max_tokens=self.max_tokens,
                tools=self.tools.to_tool_params() if len(self.tools) else None,
                **kwargs,
            )
        except Exception as exc:
            await self.hooks.trigger("on_error", exc)
            raise

        # Tool execution loop
        if self._get_tool_calls(response):
            response = await self._tool_loop(response, **kwargs)

        if response.text:
            self.context.add_message(Message(role="assistant", content=response.text))
            await self.hooks.trigger("on_context_update")

        # Hook: after_message
        await self.hooks.trigger("after_message", response)

        return response
    
    async def message_stream(self, message: str, role: Literal['user', 'assistant', 'system'] = 'user', **kwargs: Any) -> AsyncIterator[StreamChunk]:
        """Stream a response token-by-token. Yields StreamChunk objects.

        Args:
            message: The message to send.
            role: Role of the message ('user', 'assistant', 'system').
            **kwargs: Extra arguments forwarded to LLMClient.chat_stream().

        Yields:
            StreamChunk with delta_text for each token.
        """
        self.context.start_turn()

        # Hook: before_message (can replace message text)
        replaced = await self.hooks.trigger(
            "before_message", message, role, self.context.get_messages()
        )
        if replaced is not None:
            message = replaced

        self.context.add_message(Message(role=role, content=message))
        await self.hooks.trigger("on_context_update")

        full_text = ""
        try:
            async for chunk in self._client.chat_stream(
                model=self.model,
                messages=self.prompt_builder.build_messages(**kwargs),
                temperature=self.temperature,
                max_tokens=self.max_tokens,
                **kwargs,
            ):
                if chunk.delta_text:
                    full_text += chunk.delta_text
                await self.hooks.trigger("on_stream_chunk", chunk)
                yield chunk
        except Exception as exc:
            await self.hooks.trigger("on_error", exc)
            raise

        if full_text:
            self.context.add_message(Message(role="assistant", content=full_text))
            await self.hooks.trigger("on_context_update")

    async def change_system_prompt(self, new_system_prompt: str, **kwargs: Any) -> None:
        """Change the system prompt via the prompt builder."""
        self.prompt_builder.update_system_prompt(new_system_prompt, **kwargs)
        await self.hooks.trigger("system_prompt_change", new_system_prompt)

    def get_context(self) -> list[Message]:
        """Get the current conversation context (messages)."""
        return self.context.get_messages()

    def reset(self) -> None:
        """Clear conversation history. System prompt is preserved in the prompt builder."""
        self.context.clear()
