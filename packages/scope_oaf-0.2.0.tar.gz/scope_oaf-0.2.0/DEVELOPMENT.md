# Development & Release Guide

## Version Management

The **single source of truth** for the package version is:

```
pyproject.toml → [project] → version
```

Example:
```toml
[project]
version = "0.2.0"
```

At runtime, `oaf.__version__` reads this value automatically via `importlib.metadata`.

### Version Numbering (SemVer)

Format: `MAJOR.MINOR.PATCH`

| Bump    | When                                      | Example         |
|---------|-------------------------------------------|-----------------|
| PATCH   | Bug fixes, docs, internal refactors       | `0.1.0 → 0.1.1` |
| MINOR   | New features, backward-compatible changes | `0.1.1 → 0.2.0` |
| MAJOR   | Breaking API changes                      | `0.2.0 → 1.0.0` |

> **PyPI rejects duplicate versions.** Every push to `master` that should publish must have a new, unique version string. You cannot re-upload the same version.

---

## Release Workflow

### 1. Bump the version

Edit `pyproject.toml` and change the `version` field:

```toml
version = "0.2.0"  # was "0.1.0"
```

No other file needs editing — `oaf.__version__` picks it up automatically.

### 2. Commit and push to master

```bash
git add pyproject.toml
git commit -m "release: v0.2.0"
git push origin master
```

### 3. Automatic PyPI publish

The GitHub Actions workflow (`.github/workflows/publish.yml`) triggers on:

- **Push to `master`** (when `pyproject.toml` or `oaf/**` files changed)
- **GitHub Release published** (manual fallback)

It uses **trusted publishing** (OIDC via `pypa/gh-action-pypi-publish`) — no API tokens needed in secrets.

### 4. Verify the release

After the workflow completes:

| Check | Where |
|-------|-------|
| Actions run passed | https://github.com/devincii-io/scope-oaf/actions |
| New version visible on PyPI | https://pypi.org/project/scope-oaf/#history |
| Install works | `pip install scope-oaf==0.2.0` |
| Version correct at runtime | `python -c "import oaf; print(oaf.__version__)"` |

---

## Pre-Release Checklist

Before bumping the version and pushing:

- [ ] All tests pass locally: `pytest`
- [ ] Version in `pyproject.toml` is bumped and unique (not on PyPI yet)
- [ ] Changes are committed to `master` (or merged via PR)
- [ ] No debug/temp code left in the codebase

---

## GitHub Actions Setup (one-time)

For trusted publishing to work, the PyPI project must be configured:

1. Go to https://pypi.org/manage/project/scope-oaf/settings/publishing/
2. Add a **trusted publisher**:
   - Owner: `devincii-io`
   - Repository: `scope-oaf`
   - Workflow: `publish.yml`
   - Environment: `pypi`
3. On GitHub, ensure the repo has an **environment** named `pypi`:
   - Go to repo → Settings → Environments → New environment → `pypi`
   - No secrets needed (OIDC handles auth)

---

## Troubleshooting

### "Version already exists" error on PyPI
You forgot to bump the version. Edit `pyproject.toml`, increment the version, commit, and push again.

### Actions workflow didn't trigger
Check that the push was to `master` and that either `pyproject.toml` or a file under `oaf/` was changed. The `paths` filter skips pushes that only touch docs or tests.

### `oaf.__version__` shows wrong value after install
Make sure you reinstalled the package (`pip install -e .` for local dev, or `pip install --upgrade scope-oaf` for the published version).

---

## Local Development

```bash
# Create venv and install in editable mode
python -m venv .venv
.venv\Scripts\activate      # Windows
source .venv/bin/activate   # Linux/macOS

pip install -e ".[dev]"

# Run tests
pytest

# Verify version
python -c "import oaf; print(oaf.__version__)"
```
