from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

with open("requirements.txt", "r", encoding="utf-8") as fh:
    requirements = fh.read().splitlines()

setup(
    name="neyrofiga",
    version="0.1.0",
    author="Your Name",
    author_email="your.email@example.com",
    description="Библиотека для обработки изображений и машинного обучения",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/yourusername/tenflow",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
    ],
    python_requires=">=3.7",
    install_requires=requirements,
    entry_points={
        'console_scripts': [
            'tenflow-load1_1=tenflow.load1_1:load1_1',
            'tenflow-load1_2=tenflow.load1_2:load1_2',
            'tenflow-load3_1=tenflow.load3_1:load3_1',
            'tenflow-load3_2=tenflow.load3_2:load3_2',
            'tenflow-load4_1=tenflow.load4_1:load4_1',
            'tenflow-load4_2=tenflow.load4_2:load4_2',
            'tenflow-load5_1=tenflow.load5_1:load5_1',
            'tenflow-load5_2=tenflow.load5_2:load5_2',
        ],
    },
)