def load4_2():
    """4-2"""
==============

add_h(
    "Отчёт о предсказаниях модели",
    26,
    WD_ALIGN_PARAGRAPH.CENTER,
    style="Title",
    space_after=0,
)

doc.add_paragraph(f"Общее число обработанных изображений: {len(results)}")
add_h("Процентное содержание каждого класса:", 14, style="Heading 1", space_after=0)
counts = Counter(r["class"] for r in results)
for c, n in counts.items():
    doc.add_paragraph(f"{c}: {n/len(results)*100:.2f}%")

low = [r for r in results if r["conf"] < CONF_THRESH]
doc.add_paragraph(
    f"Количество изображений с низкой уверенностью (<{CONF_THRESH*100:.1f}%): {len(low)}"
)
doc.add_paragraph(
    f"Самое часто встречающееся предсказание: {counts.most_common(1)[0][0]}"
)
add_h("Изображения с низкой уверенностью:", 14, style="Heading 1", space_after=0)

for r in low:
    doc.add_paragraph(
        "Файл: {} | Класс: {} | Уверенность: {:.2f}%".format(
            r["file"], r["class"], r["conf"] * 100
        )
    )
    tmp = os.path.join(os.getcwd(), f"thumb_{r['file']}")
    Image.open(r["path"]).resize((150, 150)).save(tmp)
    doc.add_picture(tmp, width=Inches(1.5))
    os.remove(tmp)

doc.save(REPORT_FILE)
print(f"Отчет сохранен: {REPORT_FILE}")

==============
