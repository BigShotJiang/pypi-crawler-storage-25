def load4_1():
    """4-1"""

==============

import os
import numpy as np
import tensorflow as tf
from tensorflow.keras.preprocessing.image import load_img, img_to_array
from tensorflow.keras.models import load_model
from docx import Document
from docx.shared import Pt, Inches
from docx.enum.text import WD_ALIGN_PARAGRAPH
from collections import Counter
from PIL import Image

# загрузка данных
IMG_DIR = r"C:\Users\Testo\Dataset_Test"
MODEL_PATH = "Task3.hdf5"
IMG_SIZE, BATCH = (180, 180), 32
CLASS_NAMES = ["chicken", "cows", "geese"]
CONF_THRESH = 0.80
REPORT_FILE = "prediction_report.docx"

model = load_model(MODEL_PATH)
files = sorted(
    [
        os.path.join(IMG_DIR, f)
        for f in os.listdir(IMG_DIR)
        if f.lower().endswith((".jpg", ".png", ".jpeg"))
    ]
)
images = np.array([img_to_array(load_img(f, target_size=IMG_SIZE)) for f in files])

# предсказание
preds = model.predict(images, batch_size=BATCH, verbose=0)
score = tf.nn.softmax(preds).numpy()  # логи -> вероятности

# обработка и вывод в консоль
results = []
for i, path in enumerate(files):
    idx = np.argmax(score[i])
    cls, conf = CLASS_NAMES[idx], score[i][idx]
    results.append(
        {"file": os.path.basename(path), "class": cls, "conf": conf, "path": path}
    )
    print(
        "Файл: {} | Класс: {} | Уверенность: {:.2f}%".format(
            results[-1]["file"], cls, conf * 100
        )
    )

# отчет word
doc = Document()
st = doc.styles["Normal"]
st.font.name, st.font.size = "Times New Roman", Pt(12)
st.paragraph_format.line_spacing = 1.0
st.paragraph_format.space_after = Pt(0)


# стили и оформление
def add_h(text, sz, align=WD_ALIGN_PARAGRAPH.LEFT, style=None, space_after=None):
    p = doc.add_paragraph()
    if style:
        p.style = doc.styles[style]
    if space_after is not None:
        p.paragraph_format.space_after = Pt(space_after)
    p.alignment = align
    r = p.add_run(text)
    r.font.name, r.font.size, r.bold = "Calibri", Pt(sz), True
    return p

==============

