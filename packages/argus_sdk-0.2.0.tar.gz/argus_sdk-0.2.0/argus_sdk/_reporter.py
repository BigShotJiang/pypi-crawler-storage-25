import atexit
import logging
import queue
import sys
import threading
import time
from importlib.metadata import version as _pkg_version

logger = logging.getLogger("argus_sdk")

try:
    _SDK_VERSION = _pkg_version("argus-sdk")
except Exception:
    _SDK_VERSION = "unknown"
_USER_AGENT = f"argus-sdk/{_SDK_VERSION} python/{sys.version_info.major}.{sys.version_info.minor}"

_SENTINEL = object()
_SHUTDOWN_TIMEOUT = 5.0
_RETRY_DELAYS = [0.5, 1.0, 2.0]

_q: queue.Queue = queue.Queue()
_worker_thread: threading.Thread | None = None
_lock = threading.Lock()


def _post_with_retry(endpoint: str, event: dict, api_key: str | None = None) -> None:
    try:
        import httpx
    except ImportError:
        logger.debug("argus: httpx not installed, cannot report event")
        return

    url = f"{endpoint}/api/v1/events"
    headers = {"User-Agent": _USER_AGENT}
    if api_key:
        headers["Authorization"] = f"Bearer {api_key}"

    last_exc: Exception | None = None

    for attempt, delay in enumerate([0] + _RETRY_DELAYS):
        if delay:
            time.sleep(delay)
        try:
            with httpx.Client(timeout=3.0) as client:
                resp = client.post(url, json=event, headers=headers)
            if resp.status_code < 500:
                if resp.status_code >= 400:
                    logger.debug("argus: server rejected event (status %s)", resp.status_code)
                return
            last_exc = None
            logger.debug("argus: server error %s, attempt %d", resp.status_code, attempt + 1)
        except Exception as exc:
            last_exc = exc
            logger.debug("argus: request failed (attempt %d): %s", attempt + 1, exc)

    logger.debug("argus: gave up reporting event after %d attempts: %s", len(_RETRY_DELAYS) + 1, last_exc)


def _worker(endpoint: str) -> None:
    while True:
        item = _q.get()
        if item is _SENTINEL:
            _q.task_done()
            break
        event, api_key = item
        try:
            _post_with_retry(endpoint, event, api_key)
        finally:
            _q.task_done()


def _flush() -> None:
    """Drain the queue and stop the worker. Called automatically on process exit."""
    if _worker_thread is None or not _worker_thread.is_alive():
        return
    _q.put(_SENTINEL)
    _worker_thread.join(timeout=_SHUTDOWN_TIMEOUT)


def _ensure_worker(endpoint: str) -> None:
    global _worker_thread
    with _lock:
        if _worker_thread is not None and _worker_thread.is_alive():
            return
        t = threading.Thread(target=_worker, args=(endpoint,), daemon=True, name="argus-worker")
        t.start()
        _worker_thread = t
        atexit.register(_flush)


def report(endpoint: str, event: dict, api_key: str | None = None) -> None:
    _ensure_worker(endpoint)
    _q.put((event, api_key))


def flush(timeout: float = _SHUTDOWN_TIMEOUT) -> None:
    """Block until all queued events have been sent (or timeout expires)."""
    _q.join()
