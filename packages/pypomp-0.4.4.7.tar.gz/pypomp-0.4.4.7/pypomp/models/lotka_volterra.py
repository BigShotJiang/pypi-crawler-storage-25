"""
Multi-Species Stochastic Lotka-Volterra model for POMP.

System of SDEs tracking continuous biomass X_i of species i:

  dX_i = (r_i * X_i + sum_j A_ij * X_i * X_j) dt + sigma_i * X_i * dW_i

Observations are lognormal:
  Y_i = X_i * exp(tau_i * Z_i),  Z_i ~ N(0,1)

Parameters (for N species, total = N^2 + 4N):
  - r_1, ..., r_N:       intrinsic growth rates
  - A_11, ..., A_NN:     interaction matrix entries (N^2)
  - sigma_1, ..., sigma_N: process noise intensities
  - tau_1, ..., tau_N:    measurement error std devs (on log scale)
  - X0_1, ..., X0_N:     initial biomass values
"""

import jax
import jax.numpy as jnp
import numpy as np
import pandas as pd

from pypomp.core.pomp import Pomp
from pypomp.core.par_trans import ParTrans
from pypomp.types import (
    StateDict,
    ParamDict,
    CovarDict,
    TimeFloat,
    StepSizeFloat,
    RNGKey,
    ObservationDict,
    InitialTimeFloat,
)


# ---------------------------------------------------------------------------
# Helper: build name lists for a given N
# ---------------------------------------------------------------------------


def _param_names(N):
    """Return ordered list of parameter names for N species."""
    names = []
    names += [f"r_{i + 1}" for i in range(N)]
    names += [f"A_{i + 1}_{j + 1}" for i in range(N) for j in range(N)]
    names += [f"sigma_{i + 1}" for i in range(N)]
    names += [f"tau_{i + 1}" for i in range(N)]
    names += [f"X0_{i + 1}" for i in range(N)]
    return names


def _state_names(N):
    """Return ordered list of state variable names for N species."""
    return [f"X_{i + 1}" for i in range(N)]


def _obs_names(N):
    """Return ordered list of observation names for N species."""
    return [f"Y_{i + 1}" for i in range(N)]


# ---------------------------------------------------------------------------
# Picklable Model Components (Top-level Functions)
# ---------------------------------------------------------------------------


def rinit(theta: ParamDict, key: RNGKey, covars: CovarDict, t0: InitialTimeFloat):
    """Initialize state from X0_i parameters."""
    # Find all X0_i to determine N
    res = {}
    for k, v in theta.items():
        if k.startswith("X0_"):
            spec_id = k[3:]
            res[f"X_{spec_id}"] = v
    return res


def rproc(
    X: StateDict,
    theta: ParamDict,
    key: RNGKey,
    covars: CovarDict,
    t: TimeFloat,
    dt: StepSizeFloat,
):
    """Continuous process model: Euler-Maruyama step."""
    # Determine N from states
    species_keys = [k for k in X.keys() if k.startswith("X_")]
    N = len(species_keys)

    # Convert dicts to jax arrays for efficient computation
    X_vals = jnp.array([X[f"X_{i + 1}"] for i in range(N)])
    r_vals = jnp.array([theta[f"r_{i + 1}"] for i in range(N)])
    sigma_vals = jnp.array([theta[f"sigma_{i + 1}"] for i in range(N)])

    # Construct interaction matrix A
    A_flat = jnp.array(
        [theta[f"A_{i + 1}_{j + 1}"] for i in range(N) for j in range(N)]
    )
    A = A_flat.reshape((N, N))

    # Drift: r_i * X_i + sum_j A_ij * X_i * X_j
    interaction = A @ X_vals  # shape (N,)
    drift = (r_vals + interaction) * X_vals

    # Bound drift to prevent overflow
    drift = jnp.clip(drift, -1e4, 1e4)

    # Diffusion: sigma_i * X_i * dW_i
    noise = jax.random.normal(key, shape=(N,))
    # Bound noise standard deviation to prevent massive jumps
    diffusion_std = sigma_vals * X_vals * jnp.sqrt(dt)
    diffusion_std = jnp.clip(diffusion_std, 0.0, 1e4)
    diffusion = diffusion_std * noise

    # Euler-Maruyama update
    X_new = X_vals + drift * dt + diffusion

    # Floor at 1e-8 for positivity, ceiling to prevent arbitrary growth
    X_new = jnp.clip(X_new, 1e-8, 1e5)

    return {f"X_{i + 1}": X_new[i] for i in range(N)}


def dmeas(
    Y: ObservationDict,
    X: StateDict,
    theta: ParamDict,
    covars: CovarDict,
    t: TimeFloat,
):
    """Lognormal measurement density: log(Y_i) ~ Normal(log(X_i), tau_i)."""
    # Determine N from observations
    obs_keys = [k for k in Y.keys() if k.startswith("Y_")]
    N = len(obs_keys)

    loglik = 0.0
    for i in range(N):
        y = Y[f"Y_{i + 1}"]
        x = jnp.maximum(X[f"X_{i + 1}"], 1e-8)
        tau = theta[f"tau_{i + 1}"]

        # Jacobian correction for log-transform (-log(y))
        safe_y = jnp.maximum(y, 1e-8)
        loglik += jax.scipy.stats.norm.logpdf(
            jnp.log(safe_y), loc=jnp.log(x), scale=tau
        ) - jnp.log(safe_y)

    return loglik


def rmeas(
    X: StateDict,
    theta: ParamDict,
    key: RNGKey,
    covars: CovarDict,
    t: TimeFloat,
):
    """Lognormal measurement simulator: Y_i = X_i * exp(tau_i * Z_i)."""
    species_keys = [k for k in X.keys() if k.startswith("X_")]
    N = len(species_keys)

    noise = jax.random.normal(key, shape=(N,))
    obs = []
    for i in range(N):
        x = jnp.maximum(X[f"X_{i + 1}"], 1e-8)
        tau = theta[f"tau_{i + 1}"]
        obs.append(x * jnp.exp(tau * noise[i]))
    return jnp.array(obs)


def to_est(theta: dict[str, jax.Array]) -> dict[str, jax.Array]:
    """Parameter transformation to unconstrained estimation space."""
    result = {}
    for k, v in theta.items():
        # Scale parameters and initials must be positive
        if k.startswith(("sigma_", "tau_", "X0_")):
            result[k] = jnp.log(v)
        else:
            # growth rates (r_i) and interactions (A_ij) can be negative
            result[k] = v
    return result


def from_est(theta: dict[str, jax.Array]) -> dict[str, jax.Array]:
    """Parameter transformation to natural space."""
    result = {}
    for k, v in theta.items():
        if k.startswith(("sigma_", "tau_", "X0_")):
            result[k] = jnp.exp(v)
        else:
            result[k] = v
    return result


# ---------------------------------------------------------------------------
# Default true parameters for simulation
# ---------------------------------------------------------------------------


def _default_true_params(N):
    """Generate plausible true parameters for N species."""
    theta = {}

    # Growth rates: species 1 is prey (positive), others alternate
    for i in range(N):
        if i % 2 == 0:
            theta[f"r_{i + 1}"] = 0.5 - 0.05 * i  # prey: positive growth
        else:
            theta[f"r_{i + 1}"] = -0.3 + 0.03 * i  # predator: negative growth

    # Interaction matrix: classic predator-prey structure
    for i in range(N):
        for j in range(N):
            if i == j:
                # Self-regulation (negative for prey, near-zero for predators)
                if i % 2 == 0:
                    theta[f"A_{i + 1}_{j + 1}"] = -0.01
                else:
                    theta[f"A_{i + 1}_{j + 1}"] = -0.005
            elif i % 2 == 0 and j % 2 == 1:
                # Prey eaten by predator (negative effect on prey)
                theta[f"A_{i + 1}_{j + 1}"] = -0.02
            elif i % 2 == 1 and j % 2 == 0:
                # Predator benefits from prey (positive effect on predator)
                theta[f"A_{i + 1}_{j + 1}"] = 0.015
            else:
                # Competition between same trophic level
                theta[f"A_{i + 1}_{j + 1}"] = -0.005

    # Process noise
    for i in range(N):
        theta[f"sigma_{i + 1}"] = 0.1

    # Measurement noise
    for i in range(N):
        theta[f"tau_{i + 1}"] = 0.2

    # Initial biomass
    for i in range(N):
        if i % 2 == 0:
            theta[f"X0_{i + 1}"] = 10.0  # prey
        else:
            theta[f"X0_{i + 1}"] = 5.0  # predator

    return theta


# ---------------------------------------------------------------------------
# Constructor
# ---------------------------------------------------------------------------


def lotka_volterra(
    N: int = 3,
    T: int = 100,
    dt_obs: float = 1.0,
    nstep: int = 10,
    seed: int = 42,
    theta: dict | None = None,
) -> Pomp:
    """
    Create a Pomp object for the Multi-Species Stochastic Lotka-Volterra model.

    Parameters
    ----------
    N : int
        Number of species. Default 3 gives 21 parameters.
        N=7 gives 70 parameters.
    T : int
        Number of observation time points.
    dt_obs : float
        Time between observations.
    nstep : int
        Number of Euler-Maruyama steps per observation interval.
    seed : int
        Random seed for data generation.
    theta : dict, optional
        Model parameters. If None, uses default true parameters.

    Returns
    -------
    Pomp
        A Pomp object with simulated data ready for inference.
    """
    if theta is None:
        theta = _default_true_params(N)

    snames = _state_names(N)
    onames = _obs_names(N)

    par_trans = ParTrans(to_est=to_est, from_est=from_est)

    times = np.arange(dt_obs, (T + 1) * dt_obs, dt_obs)

    # Create dummy data for simulation
    ys_dummy = pd.DataFrame(
        {name: np.zeros(len(times)) for name in onames},
        index=pd.Index(times, name="time"),
    )

    lv_temp = Pomp(
        ys=ys_dummy,
        theta=theta,
        statenames=snames,
        t0=0.0,
        rinit=rinit,
        rproc=rproc,
        dmeas=dmeas,
        rmeas=rmeas,
        par_trans=par_trans,
        nstep=nstep,
        ydim=N,
    )

    # Simulate data from true parameters
    key = jax.random.key(seed)
    X_long, Y_long = lv_temp.simulate(key=key, nsim=1)

    # Extract simulated observations
    y_sims = (
        Y_long.loc[(Y_long["replicate"] == 0) & (Y_long["sim"] == 0)]
        .set_index("time")[[f"obs_{i}" for i in range(N)]]
        .rename(columns={f"obs_{i}": onames[i] for i in range(N)})
    )

    # Final Pomp object with simulated data
    return Pomp(
        ys=y_sims,
        theta=theta,
        statenames=snames,
        t0=0.0,
        rinit=rinit,
        rproc=rproc,
        dmeas=dmeas,
        rmeas=rmeas,
        par_trans=par_trans,
        nstep=nstep,
        ydim=N,
    )
