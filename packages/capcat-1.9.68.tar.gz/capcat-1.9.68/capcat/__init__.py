"""Capcat — A command-line tool designed to solve content preservation challenges with Ethical Scraping."""

__version__ = "1.9.68"

from capcat.cli import run_app  # noqa: E402

__all__ = ["__version__", "run_app"]
