from django.apps import AppConfig


class TestAppConfig(AppConfig):
    name = "testapp"
    label = "testapp"
    verbose_name = "Test App"
