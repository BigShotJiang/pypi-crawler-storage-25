"""Tests for SDK version header and upgrade warning."""

import logging

import httpx
import pytest

from ascendkit import AscendKit, AsyncAscendKit
from ascendkit._version import SDK_VERSION
import ascendkit._client as client_module


@pytest.fixture(autouse=True)
def reset_upgrade_warning():
    """Reset the module-level upgrade warning flag between tests."""
    client_module._upgrade_warned = False
    yield
    client_module._upgrade_warned = False


class TestVersionHeader:
    def test_sync_client_sends_version_header(self):
        client = AscendKit(public_key="pk_test_abc")
        assert client._client.headers["x-ascendkit-client-version"] == f"python/{SDK_VERSION}"
        client.close()

    def test_async_client_sends_version_header(self):
        client = AsyncAscendKit(public_key="pk_test_abc")
        assert client._client.headers["x-ascendkit-client-version"] == f"python/{SDK_VERSION}"


class TestUpgradeWarning:
    def test_logs_warning_on_recommended_upgrade(self, caplog):
        response = httpx.Response(
            200,
            json={"data": "ok"},
            headers={
                "X-AscendKit-Upgrade": "recommended",
                "X-AscendKit-Latest-Version": "9.9.9",
            },
        )
        with caplog.at_level(logging.WARNING, logger="ascendkit"):
            client_module._check_upgrade(response)

        assert len(caplog.records) == 1
        assert "9.9.9" in caplog.records[0].message
        assert SDK_VERSION in caplog.records[0].message

    def test_warns_only_once(self, caplog):
        response = httpx.Response(
            200,
            json={"data": "ok"},
            headers={"X-AscendKit-Upgrade": "recommended"},
        )
        with caplog.at_level(logging.WARNING, logger="ascendkit"):
            client_module._check_upgrade(response)
            client_module._check_upgrade(response)

        assert len(caplog.records) == 1

    def test_no_warning_without_header(self, caplog):
        response = httpx.Response(200, json={"data": "ok"})
        with caplog.at_level(logging.WARNING, logger="ascendkit"):
            client_module._check_upgrade(response)

        assert len(caplog.records) == 0

    def test_no_warning_for_non_recommended(self, caplog):
        response = httpx.Response(
            200,
            json={"data": "ok"},
            headers={"X-AscendKit-Upgrade": "something-else"},
        )
        with caplog.at_level(logging.WARNING, logger="ascendkit"):
            client_module._check_upgrade(response)

        assert len(caplog.records) == 0
