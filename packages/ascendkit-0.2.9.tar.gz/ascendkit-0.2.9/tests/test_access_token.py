"""Access token verifier tests."""

from __future__ import annotations

import httpx
import pytest
from jwt.exceptions import PyJWKClientConnectionError

from ascendkit._access_token import AccessTokenVerifier, _HttpxPyJWKClient


def test_verifier_uses_httpx_jwks_client():
    verifier = AccessTokenVerifier(public_key="pk_prod_test123")
    assert isinstance(verifier._jwks_client, _HttpxPyJWKClient)


def test_httpx_jwks_client_fetch_data(monkeypatch: pytest.MonkeyPatch):
    payload = {"keys": [{"kid": "abc", "kty": "RSA", "n": "x", "e": "AQAB"}]}

    class MockResponse:
        def raise_for_status(self) -> None:
            return None

        def json(self) -> dict[str, object]:
            return payload

    class MockClient:
        def __init__(self, **kwargs):
            self.kwargs = kwargs

        def __enter__(self):
            return self

        def __exit__(self, exc_type, exc, tb):
            return False

        def get(self, url: str) -> MockResponse:
            assert url == "https://api.ascendkit.dev/jwks"
            return MockResponse()

    monkeypatch.setattr(httpx, "Client", MockClient)

    client = _HttpxPyJWKClient("https://api.ascendkit.dev/jwks")
    assert client.fetch_data() == payload


def test_httpx_jwks_client_wraps_transport_errors(monkeypatch: pytest.MonkeyPatch):
    class MockClient:
        def __init__(self, **kwargs):
            self.kwargs = kwargs

        def __enter__(self):
            return self

        def __exit__(self, exc_type, exc, tb):
            return False

        def get(self, url: str):
            raise httpx.ConnectError("ssl failure")

    monkeypatch.setattr(httpx, "Client", MockClient)

    client = _HttpxPyJWKClient("https://api.ascendkit.dev/jwks")

    with pytest.raises(PyJWKClientConnectionError):
        client.fetch_data()
