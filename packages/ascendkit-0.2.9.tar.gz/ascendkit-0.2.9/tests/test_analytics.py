"""Tests for AscendKit server-side analytics."""

import json
from unittest.mock import patch, MagicMock

from ascendkit._analytics import Analytics

SECRET_KEY = "sk_prod_test_analytics"


def _make_analytics(**kwargs) -> Analytics:
    """Create an Analytics instance with flushing disabled for tests."""
    a = Analytics(
        SECRET_KEY,
        flush_interval=9999,
        batch_size=9999,
        **kwargs,
    )
    return a


def _shutdown_silent(a: Analytics) -> None:
    """Stop the flush thread and discard queued events without sending."""
    a._running = False
    with a._lock:
        a._queue.clear()


def test_track_queues_event():
    a = _make_analytics()
    a.track("usr_1", "checkout.completed", {"total": 42})
    assert len(a._queue) == 1
    assert a._queue[0]["eventName"] == "checkout.completed"
    assert a._queue[0]["userId"] == "usr_1"
    _shutdown_silent(a)


def test_track_with_visitor_id():
    a = _make_analytics()
    a.track("usr_1", "page.viewed", visitor_id="vis_abc123")
    assert a._queue[0]["context"]["visitorId"] == "vis_abc123"
    _shutdown_silent(a)


def test_track_without_visitor_id():
    a = _make_analytics()
    a.track("usr_1", "page.viewed")
    assert "visitorId" not in a._queue[0]["context"]
    _shutdown_silent(a)


def test_track_ignores_invalid_visitor_id():
    a = _make_analytics()
    a.track("usr_1", "page.viewed", visitor_id="bad_no_prefix")
    assert "visitorId" not in a._queue[0]["context"]
    _shutdown_silent(a)


@patch("ascendkit._analytics.urlopen")
def test_event_name_gets_app_prefix(mock_urlopen: MagicMock):
    mock_resp = MagicMock()
    mock_resp.status = 200
    mock_resp.__enter__ = lambda s: s
    mock_resp.__exit__ = MagicMock(return_value=False)
    mock_urlopen.return_value = mock_resp

    a = _make_analytics()
    a.track("usr_1", "checkout.completed")
    a.flush()

    sent_body = json.loads(mock_urlopen.call_args[0][0].data)
    assert sent_body["batch"][0]["event"] == "app.checkout.completed"
    a.shutdown()


@patch("ascendkit._analytics.urlopen")
def test_batch_format(mock_urlopen: MagicMock):
    mock_resp = MagicMock()
    mock_resp.status = 200
    mock_resp.__enter__ = lambda s: s
    mock_resp.__exit__ = MagicMock(return_value=False)
    mock_urlopen.return_value = mock_resp

    a = _make_analytics()
    a.track("usr_1", "signup.started", {"plan": "pro"})
    a.track("usr_2", "signup.completed")
    a.flush()

    sent_body = json.loads(mock_urlopen.call_args[0][0].data)
    assert "batch" in sent_body
    assert len(sent_body["batch"]) == 2

    first = sent_body["batch"][0]
    assert first["event"] == "app.signup.started"
    assert first["userId"] == "usr_1"
    assert first["properties"] == {"plan": "pro"}
    assert "timestamp" in first
    assert first["context"]["sdk"] == "python"

    second = sent_body["batch"][1]
    assert second["event"] == "app.signup.completed"
    assert second["userId"] == "usr_2"
    a.shutdown()
