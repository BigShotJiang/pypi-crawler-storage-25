"""Smoke tests for AscendKit client."""

from ascendkit import AscendKit, AsyncAscendKit


def test_sync_client_creates():
    client = AscendKit(public_key="pk_prod_test123")
    assert client.public_key == "pk_prod_test123"
    client.close()


def test_async_client_creates():
    client = AsyncAscendKit(public_key="pk_prod_test123")
    assert client.public_key == "pk_prod_test123"
