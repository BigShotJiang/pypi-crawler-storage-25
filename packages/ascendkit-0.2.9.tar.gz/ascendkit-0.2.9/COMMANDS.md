```bash
pip install -e ".[dev]"            # Install editable
pytest                             # Tests
ruff check . && ruff format .      # Lint + format
mypy ascendkit/                    # Type checking
```
