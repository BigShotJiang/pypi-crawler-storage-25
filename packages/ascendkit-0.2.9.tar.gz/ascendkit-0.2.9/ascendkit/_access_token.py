"""Access token verification with JWKS caching."""

from __future__ import annotations

import asyncio
import os
from typing import Any

import httpx
import jwt
from jwt import PyJWKClient
from jwt.exceptions import PyJWKClientConnectionError

from ascendkit._client import _DEFAULT_API_URL
from ascendkit._errors import AuthError
_JWKS_CACHE_TTL = 3600  # 1 hour, matches server Cache-Control


class _HttpxPyJWKClient(PyJWKClient):
    """PyJWT JWKS client with httpx-backed transport.

    PyJWKClient uses urllib internally, which can fail on some Python/macOS
    setups due to machine-specific certificate store configuration. The SDK
    already depends on httpx, which uses a more reliable CA bundle setup, so
    we fetch the JWKS through httpx while preserving PyJWT's caching/parsing.
    """

    def fetch_data(self) -> Any:
        jwk_set: Any = None
        try:
            with httpx.Client(headers=self.headers, timeout=self.timeout) as client:
                response = client.get(self.uri)
                response.raise_for_status()
                jwk_set = response.json()
        except (httpx.HTTPError, ValueError) as e:
            raise PyJWKClientConnectionError(
                f'Fail to fetch data from the url, err: "{e}"'
            ) from e
        else:
            return jwk_set
        finally:
            if self.jwk_set_cache is not None:
                self.jwk_set_cache.put(jwk_set)


class AccessTokenVerifier:
    """Verify AscendKit RS256 access tokens using JWKS.

    Caches the JWKS response in memory for 1 hour. Thread-safe.

    The ``public_key`` parameter is optional — if omitted, the constructor
    reads ``ASCENDKIT_ENV_KEY`` from the environment. Raises ``ValueError``
    if neither is provided.

    Usage (sync)::

        verifier = AccessTokenVerifier()
        claims = verifier.verify(token)
        print(claims["sub"])  # usr_...

    Usage (async)::

        verifier = AccessTokenVerifier()
        claims = await verifier.verify_async(token)

    Usage with FastAPI::

        from fastapi import Depends, Header

        verifier = AccessTokenVerifier()

        async def get_current_user(authorization: str = Header()) -> dict:
            token = authorization.removeprefix("Bearer ")
            return await verifier.verify_async(token)
    """

    def __init__(
        self,
        public_key: str | None = None,
        api_url: str = _DEFAULT_API_URL,
        cache_ttl: int = _JWKS_CACHE_TTL,
    ) -> None:
        resolved_key = public_key or os.environ.get("ASCENDKIT_ENV_KEY")
        if not resolved_key:
            raise ValueError(
                "AscendKit AccessTokenVerifier: missing public key. "
                "Pass public_key or set ASCENDKIT_ENV_KEY."
            )
        self._public_key = resolved_key
        self._jwks_url = f"{api_url}/api/.well-known/jwks.json?pk={resolved_key}"
        self._jwks_client = _HttpxPyJWKClient(
            self._jwks_url,
            cache_jwk_set=True,
            lifespan=cache_ttl,
            headers={"User-Agent": "ascendkit-python/1.0"},
        )

    def verify(self, token: str) -> dict[str, Any]:
        """Verify an access token synchronously. Returns decoded claims.

        Raises:
            AuthError: If the token is invalid, expired, or signature fails.
        """
        try:
            signing_key = self._jwks_client.get_signing_key_from_jwt(token)
            claims: dict[str, Any] = jwt.decode(
                token,
                signing_key.key,
                algorithms=["RS256"],
                issuer="ascendkit",
            )
            return claims
        except jwt.ExpiredSignatureError:
            raise AuthError("Access token expired", status_code=401)
        except jwt.exceptions.PyJWKClientConnectionError:
            raise AuthError(
                f"Failed to fetch JWKS from {self._jwks_url} — "
                "is the AscendKit backend reachable?",
                status_code=503,
            )
        except jwt.InvalidTokenError as e:
            raise AuthError(f"Invalid access token: {e}", status_code=401)

    async def verify_async(self, token: str) -> dict[str, Any]:
        """Verify an access token asynchronously. Returns decoded claims.

        Uses the same JWKS cache as ``verify()``. The JWKS HTTP fetch is
        synchronous (PyJWKClient limitation) but runs in a thread pool to
        avoid blocking the event loop. Cached results return immediately.
        """
        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(None, self.verify, token)
