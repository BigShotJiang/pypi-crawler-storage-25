"""AscendKit SDK exceptions."""


class AscendKitError(Exception):
    """Base exception for AscendKit SDK."""

    def __init__(self, message: str, status_code: int | None = None) -> None:
        super().__init__(message)
        self.status_code = status_code


class AuthError(AscendKitError):
    """Authentication or authorization error."""


class NotFoundError(AscendKitError):
    """Resource not found."""


class ValidationError(AscendKitError):
    """Request validation error."""
