"""Single source of truth for the SDK version."""

SDK_VERSION = "0.1.0"
