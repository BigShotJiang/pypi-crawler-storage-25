"""
Zendesk connector for CortexDB.

Polls Zendesk Support API v2 for Tickets, Comments, and Help Center
Articles, converting them into CortexDB Episodes.  Uses ``httpx`` for
direct HTTP access with cursor-based pagination.
"""

from __future__ import annotations

import logging
from datetime import datetime, timedelta, timezone
from typing import Any

import httpx

from cortexdb_connectors.base import (
    Actor,
    CortexConnector,
    EntityRef,
    Episode,
    EpisodeType,
    RawEvent,
    Source,
    Visibility,
    VisibilityLevel,
)

logger = logging.getLogger(__name__)

_SOURCE = Source(system="zendesk")

_RATE_LIMIT_RETRY_HEADER = "Retry-After"
_MAX_RETRIES = 3


class ZendeskConnector(CortexConnector):
    """Connector that syncs Zendesk tickets, comments, and articles into CortexDB.

    Parameters
    ----------
    cortex_url:
        Base URL of the CortexDB API.
    cortex_api_key:
        Bearer token for CortexDB authentication.
    subdomain:
        Zendesk subdomain (e.g. ``mycompany`` for mycompany.zendesk.com).
    email:
        Zendesk agent email for API authentication.
    api_token:
        Zendesk API token.
    include_help_center:
        Whether to ingest Help Center articles.
    namespace:
        CortexDB namespace for ingested episodes.
    backfill_days:
        Number of days of historical data to backfill on first sync.
    tenant_id:
        CortexDB tenant identifier.
    """

    connector_name: str = "zendesk"

    def __init__(
        self,
        cortex_url: str,
        cortex_api_key: str,
        subdomain: str,
        email: str,
        api_token: str,
        include_help_center: bool = False,
        namespace: str = "zendesk",
        backfill_days: int = 90,
        tenant_id: str = "default",
    ) -> None:
        super().__init__(cortex_url, cortex_api_key, tenant_id)
        self.subdomain = subdomain
        self.email = email
        self.api_token = api_token
        self.include_help_center = include_help_center
        self.namespace = namespace
        self.backfill_days = backfill_days
        self._base_url = f"https://{subdomain}.zendesk.com"

    # -- HTTP helpers --------------------------------------------------------

    def _auth(self) -> tuple[str, str]:
        """Return HTTP basic auth credentials (email/token)."""
        return f"{self.email}/token", self.api_token

    async def _request(
        self,
        client: httpx.AsyncClient,
        method: str,
        url: str,
        **kwargs: Any,
    ) -> httpx.Response:
        """Execute an HTTP request with rate-limit retry."""
        for attempt in range(_MAX_RETRIES):
            resp = await client.request(method, url, **kwargs)
            if resp.status_code == 429:
                retry_after = int(
                    resp.headers.get(_RATE_LIMIT_RETRY_HEADER, "5")
                )
                logger.warning(
                    "Zendesk rate limited, retrying in %ds (attempt %d/%d)",
                    retry_after,
                    attempt + 1,
                    _MAX_RETRIES,
                )
                import asyncio

                await asyncio.sleep(retry_after)
                continue
            resp.raise_for_status()
            return resp
        raise httpx.HTTPStatusError(
            "Rate limit retries exhausted",
            request=resp.request,  # type: ignore[possibly-undefined]
            response=resp,  # type: ignore[possibly-undefined]
        )

    # -- CortexConnector interface -------------------------------------------

    async def fetch_events(
        self, since: datetime | None = None
    ) -> list[RawEvent]:
        """Fetch tickets, comments, and optionally articles from Zendesk.

        Uses cursor-based pagination via the incremental exports API for
        tickets and standard pagination for comments and articles.
        """
        cutoff = since or datetime.now(timezone.utc) - timedelta(
            days=self.backfill_days
        )
        raw_events: list[RawEvent] = []

        async with httpx.AsyncClient(
            auth=self._auth(), timeout=30.0
        ) as client:
            raw_events.extend(await self._fetch_tickets(client, cutoff))
            if self.include_help_center:
                raw_events.extend(await self._fetch_articles(client, cutoff))

        return raw_events

    def normalize(self, raw: RawEvent) -> Episode:
        """Convert a Zendesk ``RawEvent`` into a CortexDB ``Episode``."""
        data = raw.data
        event_kind = data.get("event_kind", "ticket")

        if event_kind == "ticket":
            return self._normalize_ticket(raw)
        if event_kind == "comment":
            return self._normalize_comment(raw)
        if event_kind == "article":
            return self._normalize_article(raw)
        return self._normalize_ticket(raw)

    def map_permissions(self, raw: RawEvent) -> Visibility:
        """Map Zendesk visibility to CortexDB visibility.

        Internal notes are ``Restricted``; public comments and articles
        are ``Organization``; everything else is ``Organization``.
        """
        data = raw.data
        if data.get("is_public") is False:
            return Visibility(level=VisibilityLevel.RESTRICTED)
        return Visibility(level=VisibilityLevel.ORGANIZATION)

    # -- fetchers ------------------------------------------------------------

    async def _fetch_tickets(
        self,
        client: httpx.AsyncClient,
        cutoff: datetime,
    ) -> list[RawEvent]:
        """Fetch tickets and their comments using incremental export."""
        events: list[RawEvent] = []
        cutoff_unix = int(cutoff.timestamp())

        url = (
            f"{self._base_url}/api/v2/incremental/tickets/cursor.json"
            f"?start_time={cutoff_unix}"
        )

        while url:
            try:
                resp = await self._request(client, "GET", url)
            except Exception:
                logger.exception("Failed to fetch Zendesk tickets")
                break

            body = resp.json()
            tickets = body.get("tickets", [])

            for ticket in tickets:
                ts = self._parse_ts(ticket.get("updated_at"))
                events.append(
                    RawEvent(
                        source="zendesk",
                        external_id=str(ticket.get("id", "")),
                        timestamp=ts,
                        data={
                            "event_kind": "ticket",
                            "ticket": ticket,
                            "is_public": True,
                        },
                        permissions={
                            "requester_id": ticket.get("requester_id"),
                            "organization_id": ticket.get("organization_id"),
                        },
                    )
                )

                # Fetch comments for this ticket.
                events.extend(
                    await self._fetch_comments(
                        client, ticket.get("id", ""), ticket
                    )
                )

            # Cursor-based pagination.
            if body.get("end_of_stream"):
                break
            url = body.get("after_url", "")

        return events

    async def _fetch_comments(
        self,
        client: httpx.AsyncClient,
        ticket_id: str | int,
        ticket: dict[str, Any],
    ) -> list[RawEvent]:
        """Fetch all comments for a single ticket."""
        events: list[RawEvent] = []
        url: str | None = (
            f"{self._base_url}/api/v2/tickets/{ticket_id}/comments.json"
        )

        while url:
            try:
                resp = await self._request(client, "GET", url)
            except Exception:
                logger.debug("Could not fetch comments for ticket %s", ticket_id)
                break

            body = resp.json()
            for comment in body.get("comments", []):
                ts = self._parse_ts(comment.get("created_at"))
                events.append(
                    RawEvent(
                        source="zendesk",
                        external_id=f"comment:{comment.get('id', '')}",
                        timestamp=ts,
                        data={
                            "event_kind": "comment",
                            "comment": comment,
                            "ticket_id": str(ticket_id),
                            "ticket_subject": ticket.get("subject", ""),
                            "is_public": comment.get("public", True),
                        },
                        permissions={
                            "author_id": comment.get("author_id"),
                            "organization_id": ticket.get("organization_id"),
                        },
                    )
                )

            url = body.get("next_page")

        return events

    async def _fetch_articles(
        self,
        client: httpx.AsyncClient,
        cutoff: datetime,
    ) -> list[RawEvent]:
        """Fetch Help Center articles updated since cutoff."""
        events: list[RawEvent] = []
        cutoff_str = cutoff.strftime("%Y-%m-%dT%H:%M:%SZ")
        url: str | None = (
            f"{self._base_url}/api/v2/help_center/articles.json"
            f"?sort_by=updated_at&sort_order=desc&start_time={cutoff_str}"
        )

        while url:
            try:
                resp = await self._request(client, "GET", url)
            except Exception:
                logger.exception("Failed to fetch Zendesk articles")
                break

            body = resp.json()
            for article in body.get("articles", []):
                ts = self._parse_ts(article.get("updated_at"))
                events.append(
                    RawEvent(
                        source="zendesk",
                        external_id=f"article:{article.get('id', '')}",
                        timestamp=ts,
                        data={
                            "event_kind": "article",
                            "article": article,
                            "is_public": not article.get("draft", False),
                        },
                        permissions={
                            "author_id": article.get("author_id"),
                            "section_id": article.get("section_id"),
                        },
                    )
                )

            url = body.get("next_page")

        return events

    # -- normalization helpers -----------------------------------------------

    def _normalize_ticket(self, raw: RawEvent) -> Episode:
        ticket = raw.data.get("ticket", {})
        subject = ticket.get("subject", "Untitled ticket")
        description = (ticket.get("description") or "")[:1000]
        status = ticket.get("status", "")
        priority = ticket.get("priority", "")

        actor = Actor(
            id=str(ticket.get("requester_id", "")),
            name=str(ticket.get("requester_id", "Unknown")),
        )

        entities = self._extract_ticket_entities(ticket)
        tags = ["zendesk", "ticket", status] + (ticket.get("tags") or [])

        return Episode(
            actor=actor,
            source=_SOURCE,
            episode_type=EpisodeType.ISSUE,
            occurred_at=raw.timestamp,
            content=f"Ticket [{status}] [{priority}]: {subject}\n{description}".strip(),
            raw_payload=raw.data,
            tenant_id=self.tenant_id,
            namespace=self.namespace,
            entities=entities,
            tags=tags,
            metadata={
                "zendesk_ticket_id": ticket.get("id"),
                "status": status,
                "priority": priority,
                "type": ticket.get("type", ""),
                "group_id": ticket.get("group_id"),
                "assignee_id": ticket.get("assignee_id"),
            },
            thread_id=f"zd:ticket:{ticket.get('id', '')}",
            idempotency_key=f"zd:ticket:{ticket.get('id', raw.external_id)}",
        )

    def _normalize_comment(self, raw: RawEvent) -> Episode:
        data = raw.data
        comment = data.get("comment", {})
        ticket_id = data.get("ticket_id", "")
        ticket_subject = data.get("ticket_subject", "")
        body = (comment.get("body") or comment.get("plain_body") or "")[:1000]

        actor = Actor(
            id=str(comment.get("author_id", "")),
            name=str(comment.get("author_id", "Unknown")),
        )

        visibility_tag = "public" if comment.get("public", True) else "internal"

        return Episode(
            actor=actor,
            source=_SOURCE,
            episode_type=EpisodeType.COMMENT,
            occurred_at=raw.timestamp,
            content=f"Comment on [{ticket_subject}]: {body}",
            raw_payload=raw.data,
            tenant_id=self.tenant_id,
            namespace=self.namespace,
            entities=[
                EntityRef(
                    entity_type="ticket",
                    entity_id=ticket_id,
                    display_name=ticket_subject,
                ),
            ],
            tags=["zendesk", "comment", visibility_tag],
            metadata={
                "ticket_id": ticket_id,
                "is_public": comment.get("public", True),
                "has_attachments": bool(comment.get("attachments")),
            },
            thread_id=f"zd:ticket:{ticket_id}",
            parent_id=f"zd:ticket:{ticket_id}",
            idempotency_key=raw.external_id,
        )

    def _normalize_article(self, raw: RawEvent) -> Episode:
        article = raw.data.get("article", {})
        title = article.get("title", "Untitled article")
        body = (article.get("body") or "")[:2000]

        actor = Actor(
            id=str(article.get("author_id", "")),
            name=str(article.get("author_id", "Unknown")),
        )

        return Episode(
            actor=actor,
            source=_SOURCE,
            episode_type=EpisodeType.DOCUMENT,
            occurred_at=raw.timestamp,
            content=f"Article: {title}\n{body}".strip(),
            raw_payload=raw.data,
            tenant_id=self.tenant_id,
            namespace=self.namespace,
            entities=[
                EntityRef(
                    entity_type="article",
                    entity_id=str(article.get("id", "")),
                    display_name=title,
                ),
            ],
            tags=["zendesk", "article"] + (article.get("label_names") or []),
            metadata={
                "section_id": article.get("section_id"),
                "locale": article.get("locale", ""),
                "draft": article.get("draft", False),
                "vote_sum": article.get("vote_sum", 0),
            },
            thread_id=f"zd:article:{article.get('id', '')}",
            idempotency_key=raw.external_id,
        )

    # -- entity extraction ---------------------------------------------------

    @staticmethod
    def _extract_ticket_entities(
        ticket: dict[str, Any],
    ) -> list[EntityRef]:
        entities: list[EntityRef] = []

        ticket_id = ticket.get("id")
        if ticket_id:
            entities.append(
                EntityRef(
                    entity_type="ticket",
                    entity_id=str(ticket_id),
                    display_name=ticket.get("subject", str(ticket_id)),
                )
            )

        org_id = ticket.get("organization_id")
        if org_id:
            entities.append(
                EntityRef(
                    entity_type="organization",
                    entity_id=str(org_id),
                    display_name=str(org_id),
                )
            )

        assignee_id = ticket.get("assignee_id")
        if assignee_id:
            entities.append(
                EntityRef(
                    entity_type="user",
                    entity_id=str(assignee_id),
                    display_name=str(assignee_id),
                )
            )

        group_id = ticket.get("group_id")
        if group_id:
            entities.append(
                EntityRef(
                    entity_type="group",
                    entity_id=str(group_id),
                    display_name=str(group_id),
                )
            )

        return entities

    # -- utilities -----------------------------------------------------------

    @staticmethod
    def _parse_ts(value: str | None) -> datetime:
        if not value:
            return datetime.now(timezone.utc)
        try:
            return datetime.fromisoformat(value.replace("Z", "+00:00"))
        except (ValueError, TypeError):
            return datetime.now(timezone.utc)
