"""cortexdb_connectors — data connector SDK for the CortexDB v1 API.

Each connector subclass implements `fetch_events`, `normalize`, and
`map_permissions`; the base class POSTs every normalised Episode to
`/v1/experience` with the required Authorization + X-Cortex-Actor
headers. Use the `cortexdb-sync` CLI to run a connector once or in a
poll loop; or `from cortexdb_connectors.slack import SlackConnector`
to drive it programmatically.
"""

__version__ = "0.2.1"

from cortexdb_connectors.base import (
    Actor,
    CortexConnector,
    EntityRef,
    Episode,
    EpisodeType,
    RawEvent,
    Source,
    SyncResult,
    SyncState,
    Visibility,
    VisibilityLevel,
)

__all__ = [
    "__version__",
    "Actor",
    "CortexConnector",
    "EntityRef",
    "Episode",
    "EpisodeType",
    "RawEvent",
    "Source",
    "SyncResult",
    "SyncState",
    "Visibility",
    "VisibilityLevel",
]
