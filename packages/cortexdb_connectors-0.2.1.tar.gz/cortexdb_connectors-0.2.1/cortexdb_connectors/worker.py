"""Background sync worker that periodically runs all configured connectors."""

import asyncio
import logging
import os
import signal
import sys
from datetime import datetime, timezone

logger = logging.getLogger("cortexdb.connectors.worker")


async def run_sync_cycle(cortex_url: str, api_key: str, tenant_id: str) -> None:
    """Run one sync cycle for all configured connectors."""
    connectors = []

    # Slack
    slack_token = os.environ.get("SLACK_BOT_TOKEN")
    if slack_token:
        try:
            from cortexdb_connectors.slack import SlackConnector

            channels = os.environ.get("SLACK_CHANNELS", "").split(",")
            channels = [c.strip() for c in channels if c.strip()]
            connector = SlackConnector(
                cortex_url=cortex_url,
                cortex_api_key=api_key,
                tenant_id=tenant_id,
                slack_bot_token=slack_token,
                channels=channels or None,
            )
            connectors.append(("slack", connector))
        except ImportError:
            logger.warning("slack-sdk not installed, skipping Slack connector")

    # GitHub
    github_token = os.environ.get("GITHUB_TOKEN")
    if github_token:
        try:
            from cortexdb_connectors.github import GitHubConnector

            repos = os.environ.get("GITHUB_REPOS", "").split(",")
            repos = [r.strip() for r in repos if r.strip()]
            connector = GitHubConnector(
                cortex_url=cortex_url,
                cortex_api_key=api_key,
                tenant_id=tenant_id,
                github_token=github_token,
                repos=repos,
            )
            connectors.append(("github", connector))
        except ImportError:
            logger.warning("pygithub not installed, skipping GitHub connector")

    # PagerDuty
    pd_key = os.environ.get("PAGERDUTY_API_KEY")
    if pd_key:
        try:
            from cortexdb_connectors.pagerduty import PagerDutyConnector

            service_ids = os.environ.get("PAGERDUTY_SERVICE_IDS", "").split(",")
            service_ids = [s.strip() for s in service_ids if s.strip()]
            connector = PagerDutyConnector(
                cortex_url=cortex_url,
                cortex_api_key=api_key,
                tenant_id=tenant_id,
                pagerduty_api_key=pd_key,
                service_ids=service_ids or None,
            )
            connectors.append(("pagerduty", connector))
        except ImportError:
            logger.warning("pdpyras not installed, skipping PagerDuty connector")

    # Jira
    jira_url = os.environ.get("JIRA_URL")
    jira_email = os.environ.get("JIRA_EMAIL")
    jira_token = os.environ.get("JIRA_API_TOKEN")
    if jira_url and jira_email and jira_token:
        try:
            from cortexdb_connectors.jira import JiraConnector

            project_keys = os.environ.get("JIRA_PROJECT_KEYS", "").split(",")
            project_keys = [k.strip() for k in project_keys if k.strip()]
            connector = JiraConnector(
                cortex_url=cortex_url,
                cortex_api_key=api_key,
                tenant_id=tenant_id,
                jira_url=jira_url,
                jira_email=jira_email,
                jira_api_token=jira_token,
                project_keys=project_keys,
            )
            connectors.append(("jira", connector))
        except ImportError:
            logger.warning("jira not installed, skipping Jira connector")

    # Confluence
    confluence_url = os.environ.get("CONFLUENCE_URL")
    confluence_email = os.environ.get("CONFLUENCE_EMAIL")
    confluence_token = os.environ.get("CONFLUENCE_API_TOKEN")
    if confluence_url and confluence_email and confluence_token:
        try:
            from cortexdb_connectors.confluence import ConfluenceConnector

            space_keys = os.environ.get("CONFLUENCE_SPACE_KEYS", "").split(",")
            space_keys = [k.strip() for k in space_keys if k.strip()]
            connector = ConfluenceConnector(
                cortex_url=cortex_url,
                cortex_api_key=api_key,
                tenant_id=tenant_id,
                confluence_url=confluence_url,
                email=confluence_email,
                api_token=confluence_token,
                space_keys=space_keys,
            )
            connectors.append(("confluence", connector))
        except ImportError:
            logger.warning(
                "atlassian-python-api not installed, skipping Confluence connector"
            )

    if not connectors:
        logger.info("No connectors configured, skipping sync cycle")
        return

    for name, connector in connectors:
        try:
            result = await connector.sync()
            logger.info(
                "Connector %s: fetched=%d ingested=%d errors=%d duration=%.1fs",
                name,
                result.episodes_fetched,
                result.episodes_ingested,
                result.errors,
                result.duration_seconds,
            )
        except Exception:
            logger.exception("Connector %s failed", name)


async def main_loop() -> None:
    """Main worker loop."""
    cortex_url = os.environ.get("CORTEXDB_URL", "http://localhost:3141")
    api_key = os.environ.get("CORTEXDB_API_KEY", "cx_live_default_key")
    tenant_id = os.environ.get("CORTEXDB_TENANT_ID", "default")
    interval = int(os.environ.get("SYNC_INTERVAL", "300"))

    logger.info(
        "Starting connector worker: url=%s tenant=%s interval=%ds",
        cortex_url,
        tenant_id,
        interval,
    )

    shutdown = asyncio.Event()

    def handle_signal() -> None:
        logger.info("Received shutdown signal")
        shutdown.set()

    loop = asyncio.get_running_loop()
    for sig in (signal.SIGINT, signal.SIGTERM):
        try:
            loop.add_signal_handler(sig, handle_signal)
        except NotImplementedError:
            pass  # Windows

    while not shutdown.is_set():
        try:
            await run_sync_cycle(cortex_url, api_key, tenant_id)
        except Exception:
            logger.exception("Sync cycle failed")

        try:
            await asyncio.wait_for(shutdown.wait(), timeout=interval)
        except asyncio.TimeoutError:
            pass

    logger.info("Worker shut down cleanly")


def main() -> None:
    """Entry point."""
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(name)s %(levelname)s %(message)s",
    )
    asyncio.run(main_loop())


if __name__ == "__main__":
    main()
