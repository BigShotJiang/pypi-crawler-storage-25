"""
PagerDuty connector for CortexDB.

Polls PagerDuty for incidents and log entries, converting them into
CortexDB Episodes.  Uses the ``pdpyras`` library for API access.
"""

from __future__ import annotations

import logging
from datetime import datetime, timezone
from typing import Any

from cortexdb_connectors.base import (
    Actor,
    CortexConnector,
    EntityRef,
    Episode,
    EpisodeType,
    RawEvent,
    Source,
    Visibility,
    VisibilityLevel,
)

logger = logging.getLogger(__name__)

_SOURCE = Source(system="pagerduty")


class PagerDutyConnector(CortexConnector):
    """Connector that syncs PagerDuty incidents into CortexDB.

    Parameters
    ----------
    cortex_url:
        Base URL of the CortexDB API.
    cortex_api_key:
        Bearer token for CortexDB authentication.
    pagerduty_api_key:
        PagerDuty REST API key (v2).
    service_ids:
        Optional list of PagerDuty service IDs to restrict the sync to.
        If empty, all incidents visible to the API key are synced.
    tenant_id:
        CortexDB tenant identifier.
    """

    connector_name: str = "pagerduty"

    def __init__(
        self,
        cortex_url: str,
        cortex_api_key: str,
        pagerduty_api_key: str,
        service_ids: list[str] | None = None,
        tenant_id: str = "default",
    ) -> None:
        super().__init__(cortex_url, cortex_api_key, tenant_id)
        self.pagerduty_api_key = pagerduty_api_key
        self.service_ids = service_ids or []

    # -- CortexConnector interface -------------------------------------------

    async def fetch_events(
        self, since: datetime | None = None
    ) -> list[RawEvent]:
        """Fetch incidents and their log entries from PagerDuty.

        Returns one ``RawEvent`` per incident state-change (triggered,
        acknowledged, resolved) as recorded in the incident log entries.
        """
        from pdpyras import APISession

        session = APISession(self.pagerduty_api_key)
        raw_events: list[RawEvent] = []

        params: dict[str, Any] = {
            "sort_by": "created_at:desc",
        }
        if since:
            params["since"] = since.isoformat()
        if self.service_ids:
            params["service_ids[]"] = self.service_ids

        try:
            incidents = session.list_all("incidents", params=params)
        except Exception:
            logger.exception("Failed to list PagerDuty incidents")
            return raw_events

        for incident in incidents:
            created_str = incident.get("created_at", "")
            try:
                created_at = datetime.fromisoformat(
                    created_str.replace("Z", "+00:00")
                )
            except (ValueError, TypeError):
                created_at = datetime.now(timezone.utc)

            raw_events.append(
                RawEvent(
                    source="pagerduty",
                    external_id=incident.get("id", ""),
                    timestamp=created_at,
                    data={
                        "type": "incident",
                        "incident": incident,
                    },
                    permissions={},
                )
            )

            # Fetch log entries for state-change tracking.
            try:
                log_entries = session.list_all(
                    f"incidents/{incident['id']}/log_entries"
                )
            except Exception:
                logger.debug(
                    "Could not fetch log entries for %s", incident.get("id")
                )
                continue

            for entry in log_entries:
                entry_ts_str = entry.get("created_at", "")
                try:
                    entry_ts = datetime.fromisoformat(
                        entry_ts_str.replace("Z", "+00:00")
                    )
                except (ValueError, TypeError):
                    entry_ts = created_at

                if since and entry_ts <= since:
                    continue

                raw_events.append(
                    RawEvent(
                        source="pagerduty",
                        external_id=entry.get("id", ""),
                        timestamp=entry_ts,
                        data={
                            "type": "log_entry",
                            "log_entry": entry,
                            "incident_id": incident.get("id", ""),
                            "incident_title": incident.get("title", ""),
                        },
                        permissions={},
                    )
                )

        return raw_events

    def normalize(self, raw: RawEvent) -> Episode:
        """Convert a PagerDuty event into a CortexDB ``Episode``."""
        data = raw.data
        event_kind = data.get("type", "incident")

        if event_kind == "incident":
            return self._normalize_incident(raw)
        return self._normalize_log_entry(raw)

    def map_permissions(self, raw: RawEvent) -> Visibility:
        """PagerDuty data is internal; always ``Organization`` visibility."""
        return Visibility(level=VisibilityLevel.ORGANIZATION)

    # -- normalization helpers -----------------------------------------------

    def _normalize_incident(self, raw: RawEvent) -> Episode:
        """Normalize an incident-level event."""
        incident = raw.data.get("incident", {})
        title = incident.get("title", "Untitled incident")
        status = incident.get("status", "unknown")
        urgency = incident.get("urgency", "unknown")
        service = incident.get("service", {})

        actor = self._extract_actor(incident)
        entities = self._extract_entities(incident)

        content = f"[{status.upper()}] {title}"

        return Episode(
            actor=actor,
            source=_SOURCE,
            episode_type=EpisodeType.INCIDENT,
            occurred_at=raw.timestamp,
            content=content,
            raw_payload=raw.data,
            tenant_id=self.tenant_id,
            namespace="pagerduty",
            entities=entities,
            tags=["pagerduty", "incident", status],
            metadata={
                "status": status,
                "urgency": urgency,
                "severity": incident.get("severity", {}).get("value", "unknown"),
                "service_id": service.get("id", ""),
                "service_name": service.get("summary", ""),
                "incident_number": incident.get("incident_number"),
                "escalation_policy": incident.get("escalation_policy", {}).get(
                    "summary", ""
                ),
            },
            thread_id=f"pd:incident:{incident.get('id', '')}",
            idempotency_key=raw.external_id,
        )

    def _normalize_log_entry(self, raw: RawEvent) -> Episode:
        """Normalize an incident log-entry event."""
        entry = raw.data.get("log_entry", {})
        incident_id = raw.data.get("incident_id", "")
        incident_title = raw.data.get("incident_title", "")
        entry_type = entry.get("type", "unknown")

        agent = entry.get("agent", {})
        actor = Actor(
            id=agent.get("id", "system"),
            name=agent.get("summary", "PagerDuty"),
        )

        summary = entry.get("summary", entry_type)
        content = f"{summary} on incident: {incident_title}"

        return Episode(
            actor=actor,
            source=_SOURCE,
            episode_type=EpisodeType.INCIDENT,
            occurred_at=raw.timestamp,
            content=content,
            raw_payload=raw.data,
            tenant_id=self.tenant_id,
            namespace="pagerduty",
            entities=[
                EntityRef(
                    entity_type="incident",
                    entity_id=incident_id,
                    display_name=incident_title,
                ),
            ],
            tags=["pagerduty", "log_entry", entry_type],
            metadata={
                "log_entry_type": entry_type,
                "channel_type": entry.get("channel", {}).get("type", ""),
            },
            thread_id=f"pd:incident:{incident_id}",
            parent_id=f"pd:incident:{incident_id}",
            idempotency_key=raw.external_id,
        )

    @staticmethod
    def _extract_actor(incident: dict[str, Any]) -> Actor:
        """Extract the primary actor from an incident payload."""
        assignments = incident.get("assignments", [])
        if assignments:
            assignee = assignments[0].get("assignee", {})
            return Actor(
                id=assignee.get("id", "unassigned"),
                name=assignee.get("summary", "Unknown"),
            )
        return Actor(id="system", name="PagerDuty")

    @staticmethod
    def _extract_entities(incident: dict[str, Any]) -> list[EntityRef]:
        """Extract entity references from an incident."""
        entities: list[EntityRef] = []

        service = incident.get("service", {})
        if service.get("id"):
            entities.append(
                EntityRef(
                    entity_type="service",
                    entity_id=service["id"],
                    display_name=service.get("summary", ""),
                )
            )

        for assignment in incident.get("assignments", []):
            assignee = assignment.get("assignee", {})
            if assignee.get("id"):
                entities.append(
                    EntityRef(
                        entity_type="user",
                        entity_id=assignee["id"],
                        display_name=assignee.get("summary", ""),
                    )
                )

        escalation = incident.get("escalation_policy", {})
        if escalation.get("id"):
            entities.append(
                EntityRef(
                    entity_type="escalation_policy",
                    entity_id=escalation["id"],
                    display_name=escalation.get("summary", ""),
                )
            )

        return entities
