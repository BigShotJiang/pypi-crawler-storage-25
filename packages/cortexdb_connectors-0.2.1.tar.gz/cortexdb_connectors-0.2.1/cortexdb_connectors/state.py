"""
Sync state persistence for CortexDB connectors.

Stores per-connector, per-tenant cursor positions in a local JSON file so
that incremental syncs can resume from where they left off.
"""

from __future__ import annotations

import json
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from cortexdb_connectors.base import SyncState


_DEFAULT_STATE_PATH = Path.home() / ".cortexdb" / "sync_state.json"


class SyncStateStore:
    """Persists connector sync cursors to a JSON file on disk.

    The file layout is::

        {
          "<connector_name>::<tenant_id>": {
            "connector_name": "...",
            "tenant_id": "...",
            "last_synced_at": "ISO-8601 | null",
            "cursor": "...",
            "extra": {}
          }
        }
    """

    def __init__(self, path: str | Path | None = None) -> None:
        self.path = Path(path) if path else _DEFAULT_STATE_PATH
        self._ensure_dir()

    # -- public API ----------------------------------------------------------

    def get(self, connector_name: str, tenant_id: str = "default") -> SyncState:
        """Load the sync state for *connector_name* and *tenant_id*.

        Returns a fresh ``SyncState`` with ``last_synced_at=None`` if no
        previous state exists.
        """
        data = self._load()
        key = self._key(connector_name, tenant_id)
        entry = data.get(key)

        if entry is None:
            return SyncState(connector_name=connector_name, tenant_id=tenant_id)

        last_synced: datetime | None = None
        if entry.get("last_synced_at"):
            last_synced = datetime.fromisoformat(entry["last_synced_at"])

        return SyncState(
            connector_name=connector_name,
            tenant_id=tenant_id,
            last_synced_at=last_synced,
            cursor=entry.get("cursor"),
            extra=entry.get("extra", {}),
        )

    def save(self, state: SyncState) -> None:
        """Persist the given ``SyncState`` to disk."""
        data = self._load()
        key = self._key(state.connector_name, state.tenant_id)
        data[key] = {
            "connector_name": state.connector_name,
            "tenant_id": state.tenant_id,
            "last_synced_at": (
                state.last_synced_at.isoformat() if state.last_synced_at else None
            ),
            "cursor": state.cursor,
            "extra": state.extra,
        }
        self._write(data)

    def update_last_synced(
        self,
        connector_name: str,
        tenant_id: str = "default",
        timestamp: datetime | None = None,
    ) -> SyncState:
        """Convenience: set ``last_synced_at`` to *timestamp* (default: now UTC)."""
        state = self.get(connector_name, tenant_id)
        state.last_synced_at = timestamp or datetime.now(timezone.utc)
        self.save(state)
        return state

    def list_all(self) -> list[SyncState]:
        """Return every stored ``SyncState`` entry."""
        data = self._load()
        states: list[SyncState] = []
        for entry in data.values():
            last_synced: datetime | None = None
            if entry.get("last_synced_at"):
                last_synced = datetime.fromisoformat(entry["last_synced_at"])
            states.append(
                SyncState(
                    connector_name=entry["connector_name"],
                    tenant_id=entry["tenant_id"],
                    last_synced_at=last_synced,
                    cursor=entry.get("cursor"),
                    extra=entry.get("extra", {}),
                )
            )
        return states

    def clear(self, connector_name: str, tenant_id: str = "default") -> None:
        """Remove the stored state for a specific connector/tenant pair."""
        data = self._load()
        key = self._key(connector_name, tenant_id)
        data.pop(key, None)
        self._write(data)

    # -- internals -----------------------------------------------------------

    @staticmethod
    def _key(connector_name: str, tenant_id: str) -> str:
        return f"{connector_name}::{tenant_id}"

    def _ensure_dir(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def _load(self) -> dict[str, Any]:
        if not self.path.exists():
            return {}
        with open(self.path, "r", encoding="utf-8") as fh:
            return json.load(fh)

    def _write(self, data: dict[str, Any]) -> None:
        tmp = self.path.with_suffix(".tmp")
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump(data, fh, indent=2, default=str)
        # Atomic-ish rename (works on POSIX; on Windows replaces if exists in
        # Python 3.12+, but we guard with a remove for older versions).
        if os.name == "nt" and tmp.exists() and self.path.exists():
            self.path.unlink()
        tmp.rename(self.path)
