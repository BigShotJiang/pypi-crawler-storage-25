"""
Notion connector for CortexDB.

Ingests pages, database entries, and comments from Notion workspaces into
CortexDB as Episodes.  Uses the ``notion-client`` library for API access and
respects Notion's rate limit of 3 requests/second.
"""

from __future__ import annotations

import asyncio
import hashlib
import logging
from datetime import datetime, timedelta, timezone
from typing import Any

from cortexdb_connectors.base import (
    Actor,
    CortexConnector,
    EntityRef,
    Episode,
    EpisodeType,
    RawEvent,
    Source,
    Visibility,
    VisibilityLevel,
)

logger = logging.getLogger(__name__)

_SOURCE = Source(system="notion")

# Notion rate limit: 3 requests/second -> ~0.35 s between requests.
_RATE_LIMIT_DELAY = 0.35

# Maximum characters of page body to include in episode content.
_BODY_EXCERPT_LENGTH = 2000


class NotionConnector(CortexConnector):
    """Connector that syncs Notion pages, database entries, and comments
    into CortexDB.

    Parameters
    ----------
    cortex_url:
        Base URL of the CortexDB API.
    cortex_api_key:
        Bearer token for CortexDB authentication.
    notion_token:
        Notion internal integration token.
    database_ids:
        List of Notion database IDs to sync entries from.
    page_ids:
        List of specific Notion page IDs to sync.
    tenant_id:
        CortexDB tenant identifier.
    namespace:
        CortexDB namespace for ingested episodes.
    backfill_days:
        Number of days of history to backfill on first sync.
    """

    connector_name: str = "notion"

    def __init__(
        self,
        cortex_url: str,
        cortex_api_key: str,
        notion_token: str,
        database_ids: list[str] | None = None,
        page_ids: list[str] | None = None,
        tenant_id: str = "default",
        namespace: str = "notion",
        backfill_days: int = 30,
    ) -> None:
        super().__init__(cortex_url, cortex_api_key, tenant_id)
        self.notion_token = notion_token
        self.database_ids = database_ids or []
        self.page_ids = page_ids or []
        self.namespace = namespace
        self.backfill_days = backfill_days
        self._user_cache: dict[str, dict[str, Any]] = {}

    # -- CortexConnector interface -------------------------------------------

    async def fetch_events(
        self, since: datetime | None = None
    ) -> list[RawEvent]:
        """Fetch pages, database entries, and comments from Notion.

        If *since* is provided, only content modified after that timestamp
        is returned.  Uses cursor-based pagination for all endpoints.
        """
        from notion_client import Client

        client = Client(auth=self.notion_token)
        cutoff = since or datetime.now(timezone.utc) - timedelta(
            days=self.backfill_days
        )
        events: list[RawEvent] = []

        # 1. Fetch database entries.
        for db_id in self.database_ids:
            db_events = await self._fetch_database_entries(
                client, db_id, cutoff
            )
            events.extend(db_events)

        # 2. Fetch explicitly configured pages.
        for page_id in self.page_ids:
            page_events = await self._fetch_page(client, page_id, cutoff)
            events.extend(page_events)

        # 3. Search for recently modified pages across the workspace.
        search_events = await self._search_recent_pages(client, cutoff)
        events.extend(search_events)

        # 4. Fetch comments on all discovered pages.
        page_ids_seen: set[str] = set()
        for event in list(events):
            pid = event.data.get("page_id", "")
            if pid and pid not in page_ids_seen:
                page_ids_seen.add(pid)
                comment_events = await self._fetch_comments(
                    client, pid, cutoff
                )
                events.extend(comment_events)

        return events

    def normalize(self, raw: RawEvent) -> Episode:
        """Convert a Notion ``RawEvent`` into a CortexDB ``Episode``."""
        data = raw.data
        event_kind = data.get("_event_kind", "page")

        if event_kind == "comment":
            return self._normalize_comment(raw)
        return self._normalize_page(raw)

    def map_permissions(self, raw: RawEvent) -> Visibility:
        """Map Notion sharing settings to CortexDB visibility.

        Pages shared with specific users are ``Restricted``; workspace-level
        pages are ``Organization``.
        """
        perms = raw.permissions
        sharing = perms.get("sharing", "workspace")
        allowed = perms.get("allowed_users", [])

        if sharing == "specific_users" and allowed:
            return Visibility(
                level=VisibilityLevel.RESTRICTED,
                allowed_principals=tuple(allowed),
            )
        if sharing == "private":
            return Visibility(level=VisibilityLevel.PRIVATE)
        return Visibility(level=VisibilityLevel.ORGANIZATION)

    # -- page / database entry normalization ---------------------------------

    def _normalize_page(self, raw: RawEvent) -> Episode:
        """Normalize a page or database entry into an Episode."""
        data = raw.data
        title = data.get("title", "Untitled")
        body = data.get("body_text", "")
        properties_summary = data.get("properties_summary", "")
        database_name = data.get("database_name", "")

        content = title
        if database_name:
            content = f"[{database_name}] {title}"
        if properties_summary:
            content += f"\n\n{properties_summary}"
        if body:
            content += f"\n\n{body[:_BODY_EXCERPT_LENGTH]}"

        actor = self._extract_actor(data)
        entities = self._extract_entities(data)

        tags = ["notion"]
        if data.get("_event_kind") == "database_entry":
            tags.append("database_entry")
        if database_name:
            tags.append(database_name.lower().replace(" ", "_"))

        return Episode(
            actor=actor,
            source=_SOURCE,
            episode_type=EpisodeType.DOCUMENT,
            occurred_at=raw.timestamp,
            content=content,
            raw_payload=data,
            tenant_id=self.tenant_id,
            namespace=self.namespace,
            entities=entities,
            tags=tags,
            metadata={
                "page_id": data.get("page_id", ""),
                "database_id": data.get("database_id", ""),
                "url": data.get("url", ""),
                "properties": data.get("properties_raw", {}),
                "last_edited_time": data.get("last_edited_time", ""),
                "created_time": data.get("created_time", ""),
                "archived": data.get("archived", False),
            },
            thread_id=f"notion:{data.get('page_id', '')}",
            parent_id=(
                f"notion:{data['parent_id']}" if data.get("parent_id") else None
            ),
            idempotency_key=(
                f"notion:{raw.external_id}:{data.get('last_edited_time', '')}"
            ),
        )

    def _normalize_comment(self, raw: RawEvent) -> Episode:
        """Normalize a Notion comment into an Episode."""
        data = raw.data
        actor = self._extract_actor(data)
        page_id = data.get("page_id", "")

        return Episode(
            actor=actor,
            source=_SOURCE,
            episode_type=EpisodeType.COMMENT,
            occurred_at=raw.timestamp,
            content=data.get("text", ""),
            raw_payload=data,
            tenant_id=self.tenant_id,
            namespace=self.namespace,
            entities=[
                EntityRef(
                    entity_type="page",
                    entity_id=page_id,
                    display_name=data.get("page_title", ""),
                ),
            ],
            tags=["notion", "comment"],
            metadata={
                "comment_id": data.get("comment_id", ""),
                "page_id": page_id,
                "discussion_id": data.get("discussion_id", ""),
            },
            thread_id=f"notion:{page_id}",
            parent_id=f"notion:{page_id}",
            idempotency_key=f"notion:comment:{raw.external_id}",
        )

    # -- fetchers ------------------------------------------------------------

    async def _fetch_database_entries(
        self, client: Any, database_id: str, cutoff: datetime
    ) -> list[RawEvent]:
        """Query a Notion database for entries updated after *cutoff*."""
        events: list[RawEvent] = []
        cutoff_iso = cutoff.isoformat()

        # Fetch database metadata for the name.
        try:
            db_meta = client.databases.retrieve(database_id=database_id)
            await asyncio.sleep(_RATE_LIMIT_DELAY)
        except Exception:
            logger.exception("Failed to retrieve database %s", database_id)
            return events

        db_title = self._extract_title_from_rich_text(
            db_meta.get("title", [])
        )

        has_more = True
        start_cursor: str | None = None

        while has_more:
            try:
                query_params: dict[str, Any] = {
                    "database_id": database_id,
                    "page_size": 100,
                    "filter": {
                        "timestamp": "last_edited_time",
                        "last_edited_time": {"on_or_after": cutoff_iso},
                    },
                    "sorts": [
                        {
                            "timestamp": "last_edited_time",
                            "direction": "descending",
                        }
                    ],
                }
                if start_cursor:
                    query_params["start_cursor"] = start_cursor

                results = client.databases.query(**query_params)
                await asyncio.sleep(_RATE_LIMIT_DELAY)
            except Exception:
                logger.exception(
                    "Failed to query database %s", database_id
                )
                break

            for page in results.get("results", []):
                raw = self._page_to_raw_event(
                    page, database_id=database_id, database_name=db_title
                )
                events.append(raw)

            has_more = results.get("has_more", False)
            start_cursor = results.get("next_cursor")

        return events

    async def _fetch_page(
        self, client: Any, page_id: str, cutoff: datetime
    ) -> list[RawEvent]:
        """Fetch a single page if it was modified after *cutoff*."""
        try:
            page = client.pages.retrieve(page_id=page_id)
            await asyncio.sleep(_RATE_LIMIT_DELAY)
        except Exception:
            logger.exception("Failed to retrieve page %s", page_id)
            return []

        edited_str = page.get("last_edited_time", "")
        try:
            edited_at = datetime.fromisoformat(
                edited_str.replace("Z", "+00:00")
            )
        except (ValueError, TypeError):
            edited_at = datetime.now(timezone.utc)

        if edited_at < cutoff:
            return []

        # Fetch page content blocks.
        body_text = await self._fetch_block_children_text(client, page_id)
        raw = self._page_to_raw_event(page, body_text=body_text)
        return [raw]

    async def _search_recent_pages(
        self, client: Any, cutoff: datetime
    ) -> list[RawEvent]:
        """Search the workspace for recently edited pages."""
        events: list[RawEvent] = []
        has_more = True
        start_cursor: str | None = None

        # Track IDs already fetched from explicit page_ids / database_ids.
        known_ids = set(self.page_ids)

        while has_more:
            try:
                params: dict[str, Any] = {
                    "filter": {"value": "page", "property": "object"},
                    "sort": {
                        "direction": "descending",
                        "timestamp": "last_edited_time",
                    },
                    "page_size": 100,
                }
                if start_cursor:
                    params["start_cursor"] = start_cursor

                results = client.search(**params)
                await asyncio.sleep(_RATE_LIMIT_DELAY)
            except Exception:
                logger.exception("Notion search failed")
                break

            for page in results.get("results", []):
                pid = page.get("id", "")
                if pid in known_ids:
                    continue

                edited_str = page.get("last_edited_time", "")
                try:
                    edited_at = datetime.fromisoformat(
                        edited_str.replace("Z", "+00:00")
                    )
                except (ValueError, TypeError):
                    edited_at = datetime.now(timezone.utc)

                if edited_at < cutoff:
                    # Results are sorted descending; once we pass the
                    # cutoff we can stop.
                    has_more = False
                    break

                known_ids.add(pid)
                events.append(self._page_to_raw_event(page))

            if has_more:
                has_more = results.get("has_more", False)
                start_cursor = results.get("next_cursor")

        return events

    async def _fetch_comments(
        self, client: Any, page_id: str, cutoff: datetime
    ) -> list[RawEvent]:
        """Fetch discussion comments on a Notion page."""
        events: list[RawEvent] = []
        has_more = True
        start_cursor: str | None = None

        while has_more:
            try:
                params: dict[str, Any] = {
                    "block_id": page_id,
                    "page_size": 100,
                }
                if start_cursor:
                    params["start_cursor"] = start_cursor

                results = client.comments.list(**params)
                await asyncio.sleep(_RATE_LIMIT_DELAY)
            except Exception:
                logger.debug(
                    "Failed to fetch comments for page %s", page_id
                )
                break

            for comment in results.get("results", []):
                created_str = comment.get("created_time", "")
                try:
                    created_at = datetime.fromisoformat(
                        created_str.replace("Z", "+00:00")
                    )
                except (ValueError, TypeError):
                    created_at = datetime.now(timezone.utc)

                if created_at < cutoff:
                    continue

                text = self._extract_rich_text(
                    comment.get("rich_text", [])
                )
                user = comment.get("created_by", {})

                events.append(
                    RawEvent(
                        source="notion",
                        external_id=comment.get("id", ""),
                        timestamp=created_at,
                        data={
                            "_event_kind": "comment",
                            "comment_id": comment.get("id", ""),
                            "page_id": page_id,
                            "discussion_id": comment.get(
                                "discussion_id", ""
                            ),
                            "text": text,
                            "created_by_id": user.get("id", ""),
                            "created_by_name": user.get("name", ""),
                        },
                        permissions={"sharing": "workspace"},
                    )
                )

            has_more = results.get("has_more", False)
            start_cursor = results.get("next_cursor")

        return events

    async def _fetch_block_children_text(
        self, client: Any, block_id: str, depth: int = 0
    ) -> str:
        """Recursively fetch child blocks and extract plain text."""
        if depth > 3:
            return ""

        parts: list[str] = []
        has_more = True
        start_cursor: str | None = None

        while has_more:
            try:
                params: dict[str, Any] = {
                    "block_id": block_id,
                    "page_size": 100,
                }
                if start_cursor:
                    params["start_cursor"] = start_cursor

                results = client.blocks.children.list(**params)
                await asyncio.sleep(_RATE_LIMIT_DELAY)
            except Exception:
                break

            for block in results.get("results", []):
                block_type = block.get("type", "")
                type_data = block.get(block_type, {})

                if "rich_text" in type_data:
                    text = self._extract_rich_text(type_data["rich_text"])
                    if text:
                        parts.append(text)

                if block.get("has_children") and depth < 3:
                    child_text = await self._fetch_block_children_text(
                        client, block["id"], depth + 1
                    )
                    if child_text:
                        parts.append(child_text)

            has_more = results.get("has_more", False)
            start_cursor = results.get("next_cursor")

        return "\n".join(parts)

    # -- helpers -------------------------------------------------------------

    def _page_to_raw_event(
        self,
        page: dict[str, Any],
        database_id: str = "",
        database_name: str = "",
        body_text: str = "",
    ) -> RawEvent:
        """Convert a Notion page API object to a RawEvent."""
        page_id = page.get("id", "")
        edited_str = page.get("last_edited_time", "")
        created_str = page.get("created_time", "")

        try:
            edited_at = datetime.fromisoformat(
                edited_str.replace("Z", "+00:00")
            )
        except (ValueError, TypeError):
            edited_at = datetime.now(timezone.utc)

        properties = page.get("properties", {})
        title = self._extract_page_title(properties)
        properties_summary = self._summarize_properties(properties)

        # Determine parent info.
        parent = page.get("parent", {})
        parent_type = parent.get("type", "")
        parent_id = parent.get(parent_type, "")
        if isinstance(parent_id, dict):
            parent_id = ""

        # Created-by / last-edited-by.
        created_by = page.get("created_by", {})
        last_edited_by = page.get("last_edited_by", {})

        # Determine sharing level from page object.
        sharing = "workspace"
        allowed_users: list[str] = []
        if page.get("public_url"):
            sharing = "public"

        event_kind = "database_entry" if database_id else "page"

        return RawEvent(
            source="notion",
            external_id=page_id,
            timestamp=edited_at,
            data={
                "_event_kind": event_kind,
                "page_id": page_id,
                "title": title,
                "body_text": body_text,
                "properties_summary": properties_summary,
                "properties_raw": properties,
                "database_id": database_id,
                "database_name": database_name,
                "parent_id": parent_id if parent_type != "workspace" else "",
                "url": page.get("url", ""),
                "created_time": created_str,
                "last_edited_time": edited_str,
                "archived": page.get("archived", False),
                "created_by_id": created_by.get("id", ""),
                "last_edited_by_id": last_edited_by.get("id", ""),
                "last_edited_by_name": last_edited_by.get("name", ""),
            },
            permissions={
                "sharing": sharing,
                "allowed_users": allowed_users,
            },
        )

    @staticmethod
    def _extract_page_title(properties: dict[str, Any]) -> str:
        """Extract the title from a Notion page's properties."""
        for prop in properties.values():
            if prop.get("type") == "title":
                title_items = prop.get("title", [])
                return "".join(
                    item.get("plain_text", "") for item in title_items
                )
        return "Untitled"

    @staticmethod
    def _extract_title_from_rich_text(rich_text: list[dict[str, Any]]) -> str:
        """Extract plain text from Notion rich_text array."""
        return "".join(item.get("plain_text", "") for item in rich_text)

    @staticmethod
    def _extract_rich_text(rich_text: list[dict[str, Any]]) -> str:
        """Extract plain text from a Notion rich_text array."""
        return "".join(item.get("plain_text", "") for item in rich_text)

    @staticmethod
    def _summarize_properties(properties: dict[str, Any]) -> str:
        """Build a human-readable summary of a page's properties."""
        parts: list[str] = []
        for name, prop in properties.items():
            prop_type = prop.get("type", "")
            value = ""

            if prop_type == "title":
                continue  # Title is handled separately.
            elif prop_type == "rich_text":
                items = prop.get("rich_text", [])
                value = "".join(i.get("plain_text", "") for i in items)
            elif prop_type == "number":
                value = str(prop.get("number", ""))
            elif prop_type == "select":
                sel = prop.get("select")
                value = sel.get("name", "") if sel else ""
            elif prop_type == "multi_select":
                value = ", ".join(
                    s.get("name", "") for s in prop.get("multi_select", [])
                )
            elif prop_type == "status":
                st = prop.get("status")
                value = st.get("name", "") if st else ""
            elif prop_type == "date":
                dt = prop.get("date")
                if dt:
                    value = dt.get("start", "")
            elif prop_type == "checkbox":
                value = str(prop.get("checkbox", False))
            elif prop_type == "url":
                value = prop.get("url", "") or ""
            elif prop_type == "email":
                value = prop.get("email", "") or ""
            elif prop_type == "people":
                value = ", ".join(
                    p.get("name", p.get("id", ""))
                    for p in prop.get("people", [])
                )
            elif prop_type == "relation":
                value = f"{len(prop.get('relation', []))} linked"

            if value:
                parts.append(f"{name}: {value}")

        return "; ".join(parts)

    @staticmethod
    def _extract_actor(data: dict[str, Any]) -> Actor:
        """Extract the actor from event data."""
        actor_id = (
            data.get("last_edited_by_id")
            or data.get("created_by_id")
            or "unknown"
        )
        actor_name = data.get("last_edited_by_name") or data.get(
            "created_by_name", actor_id
        )
        return Actor(id=actor_id, name=actor_name)

    @staticmethod
    def _extract_entities(data: dict[str, Any]) -> list[EntityRef]:
        """Extract entity references from page/entry data."""
        entities: list[EntityRef] = []

        page_id = data.get("page_id", "")
        if page_id:
            entities.append(
                EntityRef(
                    entity_type="page",
                    entity_id=page_id,
                    display_name=data.get("title", ""),
                )
            )

        db_id = data.get("database_id", "")
        if db_id:
            entities.append(
                EntityRef(
                    entity_type="database",
                    entity_id=db_id,
                    display_name=data.get("database_name", ""),
                )
            )

        for field_name in ("last_edited_by_id", "created_by_id"):
            uid = data.get(field_name, "")
            if uid and uid != "unknown":
                entities.append(
                    EntityRef(
                        entity_type="user",
                        entity_id=uid,
                        display_name=data.get(
                            field_name.replace("_id", "_name"), ""
                        ),
                    )
                )
                break  # Only add one user entity.

        return entities
