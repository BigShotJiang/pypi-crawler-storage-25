"""Proactive Insights Engine for CortexDB.

Auto-generates intelligence from stored episodes and entities by running
periodic analysis detectors.  Each detector scans the CortexDB data plane
for a specific pattern (incident spikes, knowledge gaps, stale runbooks,
etc.) and produces ``Insight`` objects that surface actionable information
to operators and AI agents.

Typical usage::

    from cortexdb_connectors.insights import InsightsEngine

    engine = InsightsEngine(cortex_url="http://localhost:8080", cortex_api_key="...")
    await engine.run_once()           # single analysis pass
    await engine.start()              # periodic background loop
"""

from cortexdb_connectors.insights.detectors import (
    Insight,
    InsightSeverity,
    InsightType,
    IncidentSpikeDetector,
    KnowledgeGapDetector,
    NewDependencyDetector,
    OwnershipGapDetector,
    StaleRunbookDetector,
)
from cortexdb_connectors.insights.engine import InsightsEngine

__all__ = [
    "Insight",
    "InsightSeverity",
    "InsightType",
    "InsightsEngine",
    "IncidentSpikeDetector",
    "KnowledgeGapDetector",
    "NewDependencyDetector",
    "OwnershipGapDetector",
    "StaleRunbookDetector",
]
