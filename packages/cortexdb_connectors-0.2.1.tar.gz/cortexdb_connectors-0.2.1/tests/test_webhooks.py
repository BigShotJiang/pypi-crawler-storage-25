"""
Tests for the webhook receivers (Slack and GitHub).

Verifies URL verification, signature checking, and event normalization
without requiring live webhook connections or a running CortexDB instance.
"""

from __future__ import annotations

import hashlib
import hmac
import json
import time
from unittest.mock import AsyncMock, patch

import httpx
import pytest

from cortexdb_connectors.base import EpisodeType, VisibilityLevel
from cortexdb_connectors.webhooks import (
    GitHubWebhookHandler,
    SlackWebhookHandler,
    WebhookServer,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

SLACK_SECRET = "test-slack-signing-secret"
GITHUB_SECRET = "test-github-webhook-secret"
CORTEXDB_URL = "http://localhost:8080"
CORTEXDB_API_KEY = "test-api-key"


def _make_server() -> WebhookServer:
    """Create a WebhookServer with test credentials."""
    return WebhookServer(
        cortexdb_url=CORTEXDB_URL,
        cortexdb_api_key=CORTEXDB_API_KEY,
        slack_signing_secret=SLACK_SECRET,
        github_webhook_secret=GITHUB_SECRET,
    )


def _slack_signature(body: bytes, secret: str, timestamp: str) -> str:
    """Compute a valid Slack request signature."""
    basestring = f"v0:{timestamp}:{body.decode('utf-8')}"
    sig = hmac.new(
        secret.encode("utf-8"),
        basestring.encode("utf-8"),
        hashlib.sha256,
    ).hexdigest()
    return f"v0={sig}"


def _github_signature(body: bytes, secret: str) -> str:
    """Compute a valid GitHub X-Hub-Signature-256."""
    sig = hmac.new(
        secret.encode("utf-8"),
        body,
        hashlib.sha256,
    ).hexdigest()
    return f"sha256={sig}"


@pytest.fixture()
def client() -> httpx.AsyncClient:
    """Async HTTP client wired to the Starlette ASGI app."""
    server = _make_server()
    app = server.build_app()
    transport = httpx.ASGITransport(app=app)
    return httpx.AsyncClient(transport=transport, base_url="http://testserver")


# ---------------------------------------------------------------------------
# Health endpoint
# ---------------------------------------------------------------------------

class TestHealthEndpoint:
    """Tests for the /health endpoint."""

    @pytest.mark.asyncio
    async def test_health_returns_ok(self, client: httpx.AsyncClient) -> None:
        resp = await client.get("/health")
        assert resp.status_code == 200
        assert resp.json() == {"status": "ok"}


# ---------------------------------------------------------------------------
# Slack webhook tests
# ---------------------------------------------------------------------------

class TestSlackURLVerification:
    """Tests for Slack URL verification challenge handling."""

    @pytest.mark.asyncio
    async def test_url_verification_returns_challenge(self, client: httpx.AsyncClient) -> None:
        """Slack sends a url_verification event during setup; we must echo
        back the challenge token."""
        payload = {
            "type": "url_verification",
            "challenge": "abc123challengetoken",
            "token": "deprecated-token",
        }
        resp = await client.post(
            "/webhooks/slack/events",
            json=payload,
        )
        assert resp.status_code == 200
        assert resp.json()["challenge"] == "abc123challengetoken"

    @pytest.mark.asyncio
    async def test_url_verification_with_empty_challenge(self, client: httpx.AsyncClient) -> None:
        payload = {"type": "url_verification"}
        resp = await client.post("/webhooks/slack/events", json=payload)
        assert resp.status_code == 200
        assert resp.json()["challenge"] == ""


class TestSlackSignatureVerification:
    """Tests for Slack HMAC-SHA256 signature verification."""

    def test_valid_signature_accepted(self) -> None:
        handler = SlackWebhookHandler(
            signing_secret=SLACK_SECRET,
            cortexdb_url=CORTEXDB_URL,
            cortexdb_api_key=CORTEXDB_API_KEY,
        )
        body = b'{"type":"event_callback","event":{}}'
        timestamp = str(int(time.time()))
        signature = _slack_signature(body, SLACK_SECRET, timestamp)

        assert handler.verify_signature(body, timestamp, signature) is True

    def test_invalid_signature_rejected(self) -> None:
        handler = SlackWebhookHandler(
            signing_secret=SLACK_SECRET,
            cortexdb_url=CORTEXDB_URL,
            cortexdb_api_key=CORTEXDB_API_KEY,
        )
        body = b'{"type":"event_callback","event":{}}'
        timestamp = str(int(time.time()))

        assert handler.verify_signature(body, timestamp, "v0=invalid") is False

    def test_wrong_secret_rejected(self) -> None:
        handler = SlackWebhookHandler(
            signing_secret=SLACK_SECRET,
            cortexdb_url=CORTEXDB_URL,
            cortexdb_api_key=CORTEXDB_API_KEY,
        )
        body = b'{"type":"event_callback","event":{}}'
        timestamp = str(int(time.time()))
        signature = _slack_signature(body, "wrong-secret", timestamp)

        assert handler.verify_signature(body, timestamp, signature) is False

    def test_expired_timestamp_rejected(self) -> None:
        handler = SlackWebhookHandler(
            signing_secret=SLACK_SECRET,
            cortexdb_url=CORTEXDB_URL,
            cortexdb_api_key=CORTEXDB_API_KEY,
        )
        body = b'{"type":"event_callback","event":{}}'
        old_timestamp = str(int(time.time()) - 600)
        signature = _slack_signature(body, SLACK_SECRET, old_timestamp)

        assert handler.verify_signature(body, old_timestamp, signature) is False

    def test_missing_timestamp_rejected(self) -> None:
        handler = SlackWebhookHandler(
            signing_secret=SLACK_SECRET,
            cortexdb_url=CORTEXDB_URL,
            cortexdb_api_key=CORTEXDB_API_KEY,
        )
        assert handler.verify_signature(b"body", "", "v0=abc") is False

    @pytest.mark.asyncio
    async def test_invalid_signature_returns_401(self, client: httpx.AsyncClient) -> None:
        """Event callbacks with bad signatures should get a 401."""
        payload = {
            "type": "event_callback",
            "event": {"type": "message", "text": "hello"},
        }
        resp = await client.post(
            "/webhooks/slack/events",
            json=payload,
            headers={
                "X-Slack-Request-Timestamp": str(int(time.time())),
                "X-Slack-Signature": "v0=invalid",
            },
        )
        assert resp.status_code == 401


class TestSlackEventNormalization:
    """Tests for Slack event normalization into Episodes."""

    def test_message_event_normalized(self) -> None:
        handler = SlackWebhookHandler(
            signing_secret=SLACK_SECRET,
            cortexdb_url=CORTEXDB_URL,
            cortexdb_api_key=CORTEXDB_API_KEY,
        )
        payload = {
            "type": "event_callback",
            "team_id": "T12345",
            "event": {
                "type": "message",
                "user": "U98765",
                "text": "Hello from Slack",
                "ts": "1700000000.000001",
                "channel": "C0001",
            },
        }
        event = payload["event"]
        episode = handler.normalize(payload, event)

        assert episode.episode_type == EpisodeType.MESSAGE
        assert episode.content == "Hello from Slack"
        assert episode.actor is not None
        assert episode.actor.id == "U98765"
        assert episode.namespace == "slack"
        assert episode.idempotency_key == "C0001:1700000000.000001"
        assert "slack" in episode.tags
        assert episode.source is not None
        assert episode.source.system == "slack"

    def test_message_changed_event_normalized(self) -> None:
        handler = SlackWebhookHandler(
            signing_secret=SLACK_SECRET,
            cortexdb_url=CORTEXDB_URL,
            cortexdb_api_key=CORTEXDB_API_KEY,
        )
        payload = {
            "type": "event_callback",
            "team_id": "T12345",
            "event": {
                "type": "message_changed",
                "channel": "C0001",
                "ts": "1700000001.000001",
                "message": {
                    "user": "U11111",
                    "text": "Updated message text",
                    "ts": "1700000000.000001",
                },
            },
        }
        event = payload["event"]
        episode = handler.normalize(payload, event)

        assert episode.content == "Updated message text"
        assert episode.actor is not None
        assert episode.actor.id == "U11111"

    def test_reaction_added_event_normalized(self) -> None:
        handler = SlackWebhookHandler(
            signing_secret=SLACK_SECRET,
            cortexdb_url=CORTEXDB_URL,
            cortexdb_api_key=CORTEXDB_API_KEY,
        )
        payload = {
            "type": "event_callback",
            "team_id": "T12345",
            "event": {
                "type": "reaction_added",
                "user": "U98765",
                "reaction": "thumbsup",
                "item": {
                    "type": "message",
                    "channel": "C0001",
                    "ts": "1700000000.000001",
                },
                "event_ts": "1700000001.000001",
            },
        }
        event = payload["event"]
        episode = handler.normalize(payload, event)

        assert episode.content == "Reaction :thumbsup: added"
        assert episode.episode_type == EpisodeType.MESSAGE

    def test_threaded_message_has_parent_id(self) -> None:
        handler = SlackWebhookHandler(
            signing_secret=SLACK_SECRET,
            cortexdb_url=CORTEXDB_URL,
            cortexdb_api_key=CORTEXDB_API_KEY,
        )
        payload = {
            "type": "event_callback",
            "team_id": "T12345",
            "event": {
                "type": "message",
                "user": "U98765",
                "text": "Reply in thread",
                "ts": "1700000001.000001",
                "thread_ts": "1700000000.000001",
                "channel": "C0001",
            },
        }
        event = payload["event"]
        episode = handler.normalize(payload, event)

        assert episode.thread_id == "C0001:1700000000.000001"
        assert episode.parent_id == "C0001:1700000000.000001"


# ---------------------------------------------------------------------------
# GitHub webhook tests
# ---------------------------------------------------------------------------

class TestGitHubSignatureVerification:
    """Tests for GitHub HMAC-SHA256 signature verification."""

    def test_valid_signature_accepted(self) -> None:
        handler = GitHubWebhookHandler(
            webhook_secret=GITHUB_SECRET,
            cortexdb_url=CORTEXDB_URL,
            cortexdb_api_key=CORTEXDB_API_KEY,
        )
        body = b'{"action":"opened"}'
        signature = _github_signature(body, GITHUB_SECRET)

        assert handler.verify_signature(body, signature) is True

    def test_invalid_signature_rejected(self) -> None:
        handler = GitHubWebhookHandler(
            webhook_secret=GITHUB_SECRET,
            cortexdb_url=CORTEXDB_URL,
            cortexdb_api_key=CORTEXDB_API_KEY,
        )
        body = b'{"action":"opened"}'

        assert handler.verify_signature(body, "sha256=invalid") is False

    def test_missing_prefix_rejected(self) -> None:
        handler = GitHubWebhookHandler(
            webhook_secret=GITHUB_SECRET,
            cortexdb_url=CORTEXDB_URL,
            cortexdb_api_key=CORTEXDB_API_KEY,
        )
        body = b'{"action":"opened"}'
        sig = hmac.new(
            GITHUB_SECRET.encode("utf-8"), body, hashlib.sha256
        ).hexdigest()

        assert handler.verify_signature(body, sig) is False

    @pytest.mark.asyncio
    async def test_invalid_signature_returns_401(self, client: httpx.AsyncClient) -> None:
        payload = {"action": "opened"}
        resp = await client.post(
            "/webhooks/github/events",
            json=payload,
            headers={
                "X-Hub-Signature-256": "sha256=invalid",
                "X-GitHub-Event": "issues",
            },
        )
        assert resp.status_code == 401

    @pytest.mark.asyncio
    async def test_ping_event_accepted(self, client: httpx.AsyncClient) -> None:
        """GitHub sends a ping event when a webhook is first configured."""
        payload = {"zen": "Keep it simple.", "hook_id": 12345}
        body = json.dumps(payload).encode("utf-8")
        signature = _github_signature(body, GITHUB_SECRET)

        resp = await client.post(
            "/webhooks/github/events",
            content=body,
            headers={
                "Content-Type": "application/json",
                "X-Hub-Signature-256": signature,
                "X-GitHub-Event": "ping",
                "X-GitHub-Delivery": "ping-001",
            },
        )
        assert resp.status_code == 200
        assert resp.json()["msg"] == "pong"


class TestGitHubEventNormalization:
    """Tests for GitHub event normalization into Episodes."""

    def test_push_event_normalized(self) -> None:
        handler = GitHubWebhookHandler(
            webhook_secret=GITHUB_SECRET,
            cortexdb_url=CORTEXDB_URL,
            cortexdb_api_key=CORTEXDB_API_KEY,
        )
        payload = {
            "ref": "refs/heads/main",
            "commits": [
                {"message": "Fix bug in parser\ndetails here"},
                {"message": "Update docs"},
            ],
            "sender": {"id": 42, "login": "dev-user", "avatar_url": "https://example.com/avatar"},
            "repository": {"full_name": "cortex/db", "private": False},
        }
        episode = handler.normalize("push", "delivery-001", payload)

        assert episode.episode_type == EpisodeType.CODE_CHANGE
        assert "Pushed 2 commit(s)" in episode.content
        assert "Fix bug in parser" in episode.content
        assert episode.actor is not None
        assert episode.actor.name == "dev-user"
        assert episode.namespace == "github"
        assert episode.visibility.level == VisibilityLevel.ORGANIZATION

    def test_pull_request_event_normalized(self) -> None:
        handler = GitHubWebhookHandler(
            webhook_secret=GITHUB_SECRET,
            cortexdb_url=CORTEXDB_URL,
            cortexdb_api_key=CORTEXDB_API_KEY,
        )
        payload = {
            "action": "opened",
            "pull_request": {
                "number": 99,
                "title": "Add webhook support",
                "user": {"id": 42, "login": "dev-user"},
            },
            "sender": {"id": 42, "login": "dev-user"},
            "repository": {"full_name": "cortex/db", "private": True},
        }
        episode = handler.normalize("pull_request", "delivery-002", payload)

        assert episode.episode_type == EpisodeType.CODE_CHANGE
        assert "PR opened: Add webhook support" in episode.content
        assert episode.thread_id == "cortex/db:pr:99"
        assert episode.visibility.level == VisibilityLevel.RESTRICTED
        assert "github" in episode.tags

    def test_issue_event_normalized(self) -> None:
        handler = GitHubWebhookHandler(
            webhook_secret=GITHUB_SECRET,
            cortexdb_url=CORTEXDB_URL,
            cortexdb_api_key=CORTEXDB_API_KEY,
        )
        payload = {
            "action": "opened",
            "issue": {"number": 42, "title": "Bug report"},
            "sender": {"id": 1, "login": "reporter"},
            "repository": {"full_name": "cortex/db", "private": False},
        }
        episode = handler.normalize("issues", "delivery-003", payload)

        assert episode.episode_type == EpisodeType.ISSUE
        assert "Issue opened: Bug report" in episode.content
        assert episode.thread_id == "cortex/db:issue:42"

    def test_issue_comment_event_normalized(self) -> None:
        handler = GitHubWebhookHandler(
            webhook_secret=GITHUB_SECRET,
            cortexdb_url=CORTEXDB_URL,
            cortexdb_api_key=CORTEXDB_API_KEY,
        )
        payload = {
            "action": "created",
            "comment": {"body": "Looks good to me!"},
            "issue": {"number": 42, "title": "Bug report"},
            "sender": {"id": 2, "login": "reviewer"},
            "repository": {"full_name": "cortex/db", "private": False},
        }
        episode = handler.normalize("issue_comment", "delivery-004", payload)

        assert episode.episode_type == EpisodeType.COMMENT
        assert "Looks good to me!" in episode.content

    def test_pull_request_review_event_normalized(self) -> None:
        handler = GitHubWebhookHandler(
            webhook_secret=GITHUB_SECRET,
            cortexdb_url=CORTEXDB_URL,
            cortexdb_api_key=CORTEXDB_API_KEY,
        )
        payload = {
            "action": "submitted",
            "review": {"state": "approved"},
            "pull_request": {"number": 99, "title": "Add webhook support"},
            "sender": {"id": 3, "login": "lead-dev"},
            "repository": {"full_name": "cortex/db", "private": False},
        }
        episode = handler.normalize("pull_request_review", "delivery-005", payload)

        assert episode.episode_type == EpisodeType.REVIEW
        assert "approved" in episode.content
        assert episode.thread_id == "cortex/db:pr:99"

    def test_deployment_status_event_normalized(self) -> None:
        handler = GitHubWebhookHandler(
            webhook_secret=GITHUB_SECRET,
            cortexdb_url=CORTEXDB_URL,
            cortexdb_api_key=CORTEXDB_API_KEY,
        )
        payload = {
            "deployment_status": {
                "state": "success",
                "environment": "production",
            },
            "sender": {"id": 4, "login": "deploy-bot"},
            "repository": {"full_name": "cortex/db", "private": False},
        }
        episode = handler.normalize("deployment_status", "delivery-006", payload)

        assert episode.episode_type == EpisodeType.DEPLOYMENT
        assert "production" in episode.content
        assert "success" in episode.content

    def test_idempotency_key_uses_delivery_id(self) -> None:
        handler = GitHubWebhookHandler(
            webhook_secret=GITHUB_SECRET,
            cortexdb_url=CORTEXDB_URL,
            cortexdb_api_key=CORTEXDB_API_KEY,
        )
        payload = {
            "action": "opened",
            "issue": {"number": 1, "title": "Test"},
            "sender": {"id": 1, "login": "user"},
            "repository": {"full_name": "org/repo", "private": False},
        }
        episode = handler.normalize("issues", "unique-delivery-id", payload)
        assert episode.idempotency_key == "unique-delivery-id"
