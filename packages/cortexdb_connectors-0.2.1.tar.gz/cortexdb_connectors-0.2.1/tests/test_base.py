"""
Tests for the CortexDB Connector SDK base classes and sync flow.

Uses a mock connector implementation to exercise the fetch -> normalize ->
ingest pipeline without any external dependencies.
"""

from __future__ import annotations

import asyncio
from datetime import datetime, timezone
from unittest.mock import AsyncMock, patch

import pytest

from cortexdb_connectors.base import (
    Actor,
    CortexConnector,
    EntityRef,
    Episode,
    EpisodeType,
    RawEvent,
    Source,
    SyncResult,
    Visibility,
    VisibilityLevel,
)


# ---------------------------------------------------------------------------
# Mock connector
# ---------------------------------------------------------------------------

class MockConnector(CortexConnector):
    """Minimal connector for testing the base sync flow."""

    connector_name = "mock"

    def __init__(
        self,
        cortex_url: str = "http://localhost:8080",
        cortex_api_key: str = "test-key",
        tenant_id: str = "default",
        events: list[RawEvent] | None = None,
    ):
        super().__init__(cortex_url, cortex_api_key, tenant_id)
        self._events = events or []

    async def fetch_events(
        self, since: datetime | None = None
    ) -> list[RawEvent]:
        if since:
            return [e for e in self._events if e.timestamp > since]
        return list(self._events)

    def normalize(self, raw: RawEvent) -> Episode:
        return Episode(
            actor=Actor(id="user-1", name="Test User"),
            source=Source(system="mock"),
            episode_type=EpisodeType.MESSAGE,
            occurred_at=raw.timestamp,
            content=raw.data.get("text", ""),
            raw_payload=raw.data,
            tenant_id=self.tenant_id,
            namespace="mock",
            entities=[
                EntityRef(
                    entity_type="channel",
                    entity_id="ch-1",
                    display_name="general",
                ),
            ],
            tags=["mock"],
            idempotency_key=raw.external_id,
        )

    def map_permissions(self, raw: RawEvent) -> Visibility:
        if raw.permissions.get("private"):
            return Visibility(
                level=VisibilityLevel.RESTRICTED,
                allowed_principals=("user-1",),
            )
        return Visibility(level=VisibilityLevel.ORGANIZATION)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_raw_event(
    text: str = "hello",
    ts: datetime | None = None,
    private: bool = False,
) -> RawEvent:
    return RawEvent(
        source="mock",
        external_id=f"evt-{id(text)}",
        timestamp=ts or datetime(2025, 1, 15, 12, 0, 0, tzinfo=timezone.utc),
        data={"text": text},
        permissions={"private": private},
    )


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

class TestRawEvent:
    """Verify RawEvent construction and field defaults."""

    def test_creation(self) -> None:
        evt = _make_raw_event("test message")
        assert evt.source == "mock"
        assert evt.data["text"] == "test message"
        assert evt.permissions == {"private": False}

    def test_default_permissions(self) -> None:
        evt = RawEvent(
            source="x",
            external_id="1",
            timestamp=datetime.now(timezone.utc),
            data={},
        )
        assert evt.permissions == {}


class TestMockConnectorNormalize:
    """Verify the mock connector's normalize method."""

    def test_normalize_produces_episode(self) -> None:
        connector = MockConnector()
        raw = _make_raw_event("sync test")
        episode = connector.normalize(raw)

        assert isinstance(episode, Episode)
        assert episode.content == "sync test"
        assert episode.episode_type == EpisodeType.MESSAGE
        assert episode.source is not None
        assert episode.source.system == "mock"
        assert episode.tenant_id == "default"
        assert episode.namespace == "mock"
        assert len(episode.entities) == 1
        assert episode.entities[0].entity_type == "channel"

    def test_normalize_sets_idempotency_key(self) -> None:
        connector = MockConnector()
        raw = _make_raw_event("idem")
        episode = connector.normalize(raw)
        assert episode.idempotency_key == raw.external_id


class TestMockConnectorPermissions:
    """Verify permission mapping."""

    def test_public_visibility(self) -> None:
        connector = MockConnector()
        raw = _make_raw_event(private=False)
        vis = connector.map_permissions(raw)
        assert vis.level == VisibilityLevel.ORGANIZATION

    def test_private_visibility(self) -> None:
        connector = MockConnector()
        raw = _make_raw_event(private=True)
        vis = connector.map_permissions(raw)
        assert vis.level == VisibilityLevel.RESTRICTED
        assert "user-1" in vis.allowed_principals


class TestSyncFlow:
    """Test the full sync cycle (fetch -> normalize -> ingest)."""

    def test_sync_returns_result(self) -> None:
        events = [
            _make_raw_event("msg-1"),
            _make_raw_event("msg-2"),
        ]
        connector = MockConnector(events=events)

        with patch.object(
            connector, "ingest_episode", new_callable=AsyncMock
        ) as mock_ingest:
            mock_ingest.return_value = "fake-id"
            result = asyncio.run(connector.sync())

        assert isinstance(result, SyncResult)
        assert result.episodes_fetched == 2
        assert result.episodes_ingested == 2
        assert result.errors == []
        assert result.duration_seconds >= 0
        assert mock_ingest.call_count == 2

    def test_sync_with_since_filters_events(self) -> None:
        old_event = _make_raw_event(
            "old",
            ts=datetime(2024, 1, 1, tzinfo=timezone.utc),
        )
        new_event = _make_raw_event(
            "new",
            ts=datetime(2025, 6, 1, tzinfo=timezone.utc),
        )
        connector = MockConnector(events=[old_event, new_event])

        with patch.object(
            connector, "ingest_episode", new_callable=AsyncMock
        ) as mock_ingest:
            mock_ingest.return_value = "fake-id"
            result = asyncio.run(
                connector.sync(
                    since=datetime(2025, 1, 1, tzinfo=timezone.utc)
                )
            )

        assert result.episodes_fetched == 1
        assert result.episodes_ingested == 1

    def test_sync_records_errors(self) -> None:
        events = [_make_raw_event("bad")]
        connector = MockConnector(events=events)

        with patch.object(
            connector, "ingest_episode", new_callable=AsyncMock
        ) as mock_ingest:
            mock_ingest.side_effect = RuntimeError("connection refused")
            result = asyncio.run(connector.sync())

        assert result.episodes_fetched == 1
        assert result.episodes_ingested == 0
        assert len(result.errors) == 1
        assert "connection refused" in result.errors[0]

    def test_sync_empty(self) -> None:
        connector = MockConnector(events=[])

        with patch.object(
            connector, "ingest_episode", new_callable=AsyncMock
        ):
            result = asyncio.run(connector.sync())

        assert result.episodes_fetched == 0
        assert result.episodes_ingested == 0


class TestEpisodeDefaults:
    """Verify Episode default field values."""

    def test_default_episode_has_uuid_id(self) -> None:
        ep = Episode()
        assert len(ep.id) == 36  # UUID format

    def test_default_visibility(self) -> None:
        ep = Episode()
        assert ep.visibility.level == VisibilityLevel.ORGANIZATION

    def test_default_tenant(self) -> None:
        ep = Episode()
        assert ep.tenant_id == "default"
        assert ep.namespace == "default"
