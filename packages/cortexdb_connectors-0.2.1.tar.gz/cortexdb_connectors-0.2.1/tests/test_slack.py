"""
Tests for the Slack connector normalization and permission mapping.

Uses sample Slack API payloads to verify that messages are correctly
converted into CortexDB Episodes without requiring a live Slack connection.
"""

from __future__ import annotations

from datetime import datetime, timezone

import pytest

from cortexdb_connectors.base import (
    EpisodeType,
    RawEvent,
    VisibilityLevel,
)
from cortexdb_connectors.slack import SlackConnector


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

def _make_connector() -> SlackConnector:
    """Create a SlackConnector for testing (no real API calls)."""
    return SlackConnector(
        cortex_url="http://localhost:8080",
        cortex_api_key="test-key",
        slack_bot_token="xoxb-fake-token",
        channels=["C0001"],
        tenant_id="test-tenant",
    )


def _make_slack_raw_event(
    text: str = "Hello world",
    user: str = "U12345",
    ts: str = "1700000000.000001",
    channel_id: str = "C0001",
    thread_ts: str | None = None,
    is_private: bool = False,
    subtype: str | None = None,
    reactions: list | None = None,
) -> RawEvent:
    """Build a RawEvent mimicking a Slack message payload."""
    data: dict = {
        "type": "message",
        "user": user,
        "text": text,
        "ts": ts,
        "_channel_id": channel_id,
        "_channel_name": "general",
    }
    if thread_ts:
        data["thread_ts"] = thread_ts
    if subtype:
        data["subtype"] = subtype
    if reactions:
        data["reactions"] = reactions

    return RawEvent(
        source="slack",
        external_id=f"{channel_id}:{ts}",
        timestamp=datetime.fromtimestamp(float(ts), tz=timezone.utc),
        data=data,
        permissions={
            "is_private": is_private,
            "channel_members": ["U12345", "U67890"] if is_private else [],
        },
    )


# ---------------------------------------------------------------------------
# Tests — normalization
# ---------------------------------------------------------------------------

class TestSlackNormalize:
    """Verify Slack message -> Episode normalization."""

    def test_basic_message(self) -> None:
        connector = _make_connector()
        raw = _make_slack_raw_event(text="Hello from Slack")
        episode = connector.normalize(raw)

        assert episode.content == "Hello from Slack"
        assert episode.episode_type == EpisodeType.MESSAGE
        assert episode.source is not None
        assert episode.source.system == "slack"
        assert episode.namespace == "slack"
        assert episode.tenant_id == "test-tenant"
        assert episode.idempotency_key == raw.external_id

    def test_actor_extraction(self) -> None:
        connector = _make_connector()
        raw = _make_slack_raw_event(user="U99999")
        episode = connector.normalize(raw)

        assert episode.actor is not None
        assert episode.actor.id == "U99999"

    def test_channel_entity(self) -> None:
        connector = _make_connector()
        raw = _make_slack_raw_event(channel_id="C42")
        episode = connector.normalize(raw)

        assert len(episode.entities) == 1
        entity = episode.entities[0]
        assert entity.entity_type == "channel"
        assert entity.entity_id == "C42"

    def test_thread_id_set_for_threaded_message(self) -> None:
        connector = _make_connector()
        raw = _make_slack_raw_event(
            ts="1700000001.000002",
            thread_ts="1700000000.000001",
            channel_id="C0001",
        )
        episode = connector.normalize(raw)

        assert episode.thread_id == "C0001:1700000000.000001"
        assert episode.parent_id == "C0001:1700000000.000001"

    def test_no_thread_for_top_level_message(self) -> None:
        connector = _make_connector()
        raw = _make_slack_raw_event(ts="1700000000.000001", thread_ts=None)
        episode = connector.normalize(raw)

        assert episode.thread_id is None
        assert episode.parent_id is None

    def test_parent_message_with_own_thread_ts(self) -> None:
        """A parent message has thread_ts == ts, so parent_id should be None."""
        connector = _make_connector()
        raw = _make_slack_raw_event(
            ts="1700000000.000001",
            thread_ts="1700000000.000001",
        )
        episode = connector.normalize(raw)

        assert episode.thread_id == "C0001:1700000000.000001"
        assert episode.parent_id is None  # It IS the parent.

    def test_metadata_includes_subtype(self) -> None:
        connector = _make_connector()
        raw = _make_slack_raw_event(subtype="bot_message")
        episode = connector.normalize(raw)

        assert episode.metadata["subtype"] == "bot_message"

    def test_metadata_includes_reactions(self) -> None:
        connector = _make_connector()
        reactions = [{"name": "thumbsup", "count": 3}]
        raw = _make_slack_raw_event(reactions=reactions)
        episode = connector.normalize(raw)

        assert episode.metadata["reactions"] == reactions

    def test_tags_include_slack(self) -> None:
        connector = _make_connector()
        raw = _make_slack_raw_event()
        episode = connector.normalize(raw)

        assert "slack" in episode.tags


# ---------------------------------------------------------------------------
# Tests — permission mapping
# ---------------------------------------------------------------------------

class TestSlackPermissions:
    """Verify Slack channel privacy -> CortexDB visibility mapping."""

    def test_public_channel_is_organization(self) -> None:
        connector = _make_connector()
        raw = _make_slack_raw_event(is_private=False)
        vis = connector.map_permissions(raw)

        assert vis.level == VisibilityLevel.ORGANIZATION
        assert vis.allowed_principals == ()

    def test_private_channel_is_restricted(self) -> None:
        connector = _make_connector()
        raw = _make_slack_raw_event(is_private=True)
        vis = connector.map_permissions(raw)

        assert vis.level == VisibilityLevel.RESTRICTED
        assert "U12345" in vis.allowed_principals
        assert "U67890" in vis.allowed_principals

    def test_private_channel_member_list(self) -> None:
        connector = _make_connector()
        raw = _make_slack_raw_event(is_private=True)
        vis = connector.map_permissions(raw)

        assert len(vis.allowed_principals) == 2
