"""
Tests for the GitHub connector normalization and permission mapping.

Uses sample GitHub event payloads to verify that events are correctly
converted into CortexDB Episodes without requiring a live GitHub connection.
"""

from __future__ import annotations

from datetime import datetime, timezone

import pytest

from cortexdb_connectors.base import (
    EpisodeType,
    RawEvent,
    VisibilityLevel,
)
from cortexdb_connectors.github import GitHubConnector


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

def _make_connector() -> GitHubConnector:
    """Create a GitHubConnector for testing (no real API calls)."""
    return GitHubConnector(
        cortex_url="http://localhost:8080",
        cortex_api_key="test-key",
        github_token="ghp_fake",
        repos=["acme/widgets"],
        tenant_id="test-tenant",
    )


def _make_github_raw_event(
    event_type: str = "PushEvent",
    payload: dict | None = None,
    actor_login: str = "octocat",
    actor_id: int = 1,
    repo: str = "acme/widgets",
    public: bool = True,
    ts: datetime | None = None,
    external_id: str = "123456",
) -> RawEvent:
    """Build a RawEvent mimicking a GitHub event payload."""
    if payload is None:
        payload = {}

    return RawEvent(
        source="github",
        external_id=external_id,
        timestamp=ts or datetime(2025, 3, 10, 14, 0, 0, tzinfo=timezone.utc),
        data={
            "type": event_type,
            "actor": {
                "login": actor_login,
                "id": actor_id,
                "avatar_url": f"https://avatars.githubusercontent.com/u/{actor_id}",
            },
            "repo": repo,
            "payload": payload,
            "public": public,
        },
        permissions={"private": not public},
    )


# ---------------------------------------------------------------------------
# Push events
# ---------------------------------------------------------------------------

class TestGitHubPushNormalize:
    """Verify PushEvent normalization."""

    def test_push_event_type(self) -> None:
        connector = _make_connector()
        raw = _make_github_raw_event(
            event_type="PushEvent",
            payload={
                "ref": "refs/heads/main",
                "commits": [
                    {"message": "Fix bug in parser"},
                    {"message": "Update tests"},
                ],
            },
        )
        episode = connector.normalize(raw)

        assert episode.episode_type == EpisodeType.CODE_CHANGE
        assert "Pushed 2 commit(s)" in episode.content
        assert "refs/heads/main" in episode.content
        assert "Fix bug in parser" in episode.content

    def test_push_actor(self) -> None:
        connector = _make_connector()
        raw = _make_github_raw_event(actor_login="devuser", actor_id=42)
        episode = connector.normalize(raw)

        assert episode.actor is not None
        assert episode.actor.name == "devuser"
        assert episode.actor.id == "42"

    def test_push_repo_entity(self) -> None:
        connector = _make_connector()
        raw = _make_github_raw_event(repo="acme/widgets")
        episode = connector.normalize(raw)

        repo_entities = [
            e for e in episode.entities if e.entity_type == "repository"
        ]
        assert len(repo_entities) == 1
        assert repo_entities[0].entity_id == "acme/widgets"


# ---------------------------------------------------------------------------
# Pull request events
# ---------------------------------------------------------------------------

class TestGitHubPRNormalize:
    """Verify PullRequestEvent normalization."""

    def test_pr_event_type(self) -> None:
        connector = _make_connector()
        raw = _make_github_raw_event(
            event_type="PullRequestEvent",
            payload={
                "action": "opened",
                "pull_request": {
                    "number": 42,
                    "title": "Add caching layer",
                    "user": {"login": "alice", "id": 10},
                    "requested_reviewers": [
                        {"login": "bob", "id": 20},
                    ],
                },
            },
        )
        episode = connector.normalize(raw)

        assert episode.episode_type == EpisodeType.CODE_CHANGE
        assert "PR opened" in episode.content
        assert "Add caching layer" in episode.content

    def test_pr_thread_id(self) -> None:
        connector = _make_connector()
        raw = _make_github_raw_event(
            event_type="PullRequestEvent",
            repo="acme/widgets",
            payload={
                "action": "opened",
                "pull_request": {
                    "number": 42,
                    "title": "Add caching",
                    "user": {"login": "alice", "id": 10},
                    "requested_reviewers": [],
                },
            },
        )
        episode = connector.normalize(raw)

        assert episode.thread_id == "acme/widgets:pr:42"

    def test_pr_extracts_reviewers(self) -> None:
        connector = _make_connector()
        raw = _make_github_raw_event(
            event_type="PullRequestEvent",
            payload={
                "action": "opened",
                "pull_request": {
                    "number": 7,
                    "title": "Refactor",
                    "user": {"login": "alice", "id": 10},
                    "requested_reviewers": [
                        {"login": "bob", "id": 20},
                        {"login": "carol", "id": 30},
                    ],
                },
            },
        )
        episode = connector.normalize(raw)

        user_entities = [
            e for e in episode.entities if e.entity_type == "user"
        ]
        logins = {e.display_name for e in user_entities}
        assert "alice" in logins
        assert "bob" in logins
        assert "carol" in logins


# ---------------------------------------------------------------------------
# Issue events
# ---------------------------------------------------------------------------

class TestGitHubIssueNormalize:
    """Verify IssuesEvent normalization."""

    def test_issue_event_type(self) -> None:
        connector = _make_connector()
        raw = _make_github_raw_event(
            event_type="IssuesEvent",
            payload={
                "action": "opened",
                "issue": {
                    "number": 99,
                    "title": "Memory leak in worker pool",
                },
            },
        )
        episode = connector.normalize(raw)

        assert episode.episode_type == EpisodeType.ISSUE
        assert "Issue opened" in episode.content
        assert "Memory leak" in episode.content

    def test_issue_thread_id(self) -> None:
        connector = _make_connector()
        raw = _make_github_raw_event(
            event_type="IssuesEvent",
            repo="acme/widgets",
            payload={
                "action": "closed",
                "issue": {"number": 99, "title": "Bug"},
            },
        )
        episode = connector.normalize(raw)

        assert episode.thread_id == "acme/widgets:issue:99"

    def test_issue_entity_extracted(self) -> None:
        connector = _make_connector()
        raw = _make_github_raw_event(
            event_type="IssuesEvent",
            payload={
                "action": "opened",
                "issue": {"number": 55, "title": "Fix flaky test"},
            },
        )
        episode = connector.normalize(raw)

        issue_entities = [
            e for e in episode.entities if e.entity_type == "issue"
        ]
        assert len(issue_entities) == 1
        assert issue_entities[0].entity_id == "55"


# ---------------------------------------------------------------------------
# Review events
# ---------------------------------------------------------------------------

class TestGitHubReviewNormalize:
    """Verify PullRequestReviewEvent normalization."""

    def test_review_event_type(self) -> None:
        connector = _make_connector()
        raw = _make_github_raw_event(
            event_type="PullRequestReviewEvent",
            payload={
                "action": "submitted",
                "review": {"state": "approved"},
                "pull_request": {
                    "number": 42,
                    "title": "Add feature X",
                    "user": {"login": "alice", "id": 10},
                    "requested_reviewers": [],
                },
            },
        )
        episode = connector.normalize(raw)

        assert episode.episode_type == EpisodeType.REVIEW
        assert "approved" in episode.content
        assert "Add feature X" in episode.content


# ---------------------------------------------------------------------------
# Permission mapping
# ---------------------------------------------------------------------------

class TestGitHubPermissions:
    """Verify repository visibility -> CortexDB visibility mapping."""

    def test_public_repo_is_organization(self) -> None:
        connector = _make_connector()
        raw = _make_github_raw_event(public=True)
        vis = connector.map_permissions(raw)

        assert vis.level == VisibilityLevel.ORGANIZATION

    def test_private_repo_is_restricted(self) -> None:
        connector = _make_connector()
        raw = _make_github_raw_event(public=False)
        vis = connector.map_permissions(raw)

        assert vis.level == VisibilityLevel.RESTRICTED


# ---------------------------------------------------------------------------
# Metadata
# ---------------------------------------------------------------------------

class TestGitHubMetadata:
    """Verify metadata and tags on normalized episodes."""

    def test_tags_include_event_type(self) -> None:
        connector = _make_connector()
        raw = _make_github_raw_event(event_type="PushEvent")
        episode = connector.normalize(raw)

        assert "github" in episode.tags
        assert "pushevent" in episode.tags

    def test_metadata_action(self) -> None:
        connector = _make_connector()
        raw = _make_github_raw_event(
            event_type="IssuesEvent",
            payload={"action": "reopened", "issue": {"number": 1, "title": "x"}},
        )
        episode = connector.normalize(raw)

        assert episode.metadata["action"] == "reopened"

    def test_idempotency_key(self) -> None:
        connector = _make_connector()
        raw = _make_github_raw_event(external_id="evt-789")
        episode = connector.normalize(raw)

        assert episode.idempotency_key == "evt-789"

    def test_namespace_is_github(self) -> None:
        connector = _make_connector()
        raw = _make_github_raw_event()
        episode = connector.normalize(raw)

        assert episode.namespace == "github"
