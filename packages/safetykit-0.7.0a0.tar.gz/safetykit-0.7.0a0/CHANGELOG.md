# Changelog

## 0.7.0-alpha (2026-04-10)

Full Changelog: [v0.6.0-alpha...v0.7.0-alpha](https://github.com/GetSafetyKit/safetykit-python/compare/v0.6.0-alpha...v0.7.0-alpha)

### Features

* **api:** api update ([4d6fbad](https://github.com/GetSafetyKit/safetykit-python/commit/4d6fbadf816bea4e0ba893ab8492d492fd5a51c2))
* **api:** api update ([5fb66ac](https://github.com/GetSafetyKit/safetykit-python/commit/5fb66acfa7315abb049e44651eea0c35c331c2d6))
* **api:** api update ([5fb66ac](https://github.com/GetSafetyKit/safetykit-python/commit/5fb66acfa7315abb049e44651eea0c35c331c2d6))
* **api:** api update ([26e98e4](https://github.com/GetSafetyKit/safetykit-python/commit/26e98e4cfbbba60971790af78b1a4d0e8d81b500))
* **api:** api update ([d56a140](https://github.com/GetSafetyKit/safetykit-python/commit/d56a140e8cdd9321351590a8ac89b7da9af578e7))
* **api:** api update ([3112aec](https://github.com/GetSafetyKit/safetykit-python/commit/3112aec32e15b04fc1925c48b823265f87cd4c3d))
* **api:** api update ([d634f89](https://github.com/GetSafetyKit/safetykit-python/commit/d634f89bd98b03efc7b076bd3440d874071d23d7))
* **api:** api update ([4792174](https://github.com/GetSafetyKit/safetykit-python/commit/4792174752d99ee527c212c3bd2726da2ef9899a))
* **api:** api update ([24897c4](https://github.com/GetSafetyKit/safetykit-python/commit/24897c412249cc52148daf4381fce492642bf46d))
* **api:** api update ([8b026b7](https://github.com/GetSafetyKit/safetykit-python/commit/8b026b7e5f734637881cb462f710fbe3d181aa4f))
* **api:** api update ([b3125d7](https://github.com/GetSafetyKit/safetykit-python/commit/b3125d7b06c576712dbd70960f9860623eaec768))
* **api:** api update ([da066a1](https://github.com/GetSafetyKit/safetykit-python/commit/da066a1d47c9f584f4c2d9db2fdb1b2c14e3c207))
* **api:** api update ([bb04f76](https://github.com/GetSafetyKit/safetykit-python/commit/bb04f764774fb3393ecbeae8ef3651e4cfb81224))
* **api:** api update ([b91a9ba](https://github.com/GetSafetyKit/safetykit-python/commit/b91a9bac89059bf408412f1a28512530da1e14ac))
* **api:** api update ([15f00fc](https://github.com/GetSafetyKit/safetykit-python/commit/15f00fcdf2ed8970a74e6fd781872429899f1d8e))
* **api:** api update ([0ba9787](https://github.com/GetSafetyKit/safetykit-python/commit/0ba9787199051906b5934d849a68576843b2296e))
* **api:** api update ([011b588](https://github.com/GetSafetyKit/safetykit-python/commit/011b5883bde2e8b83427025ce3d87b67b8170637))
* **api:** api update ([eae018b](https://github.com/GetSafetyKit/safetykit-python/commit/eae018baf78dd4e60e60d29c5b09368c0c70864d))
* **api:** api update ([d6e4d3b](https://github.com/GetSafetyKit/safetykit-python/commit/d6e4d3bd79d8be60504fdc73b1bcd9f944156a54))
* **api:** api update ([6de537c](https://github.com/GetSafetyKit/safetykit-python/commit/6de537c55e847593ab7890aba3da751c20a00533))
* **api:** api update ([c948405](https://github.com/GetSafetyKit/safetykit-python/commit/c948405548a24e14133a0f2c20be66cee045b482))
* **api:** api update ([73f9d48](https://github.com/GetSafetyKit/safetykit-python/commit/73f9d48d5018c17470d40440315fb5a2de036a66))
* **api:** api update ([2f877d2](https://github.com/GetSafetyKit/safetykit-python/commit/2f877d2c17c9211064e5cccfe68759e1db521c3e))
* **api:** api update ([eb7b602](https://github.com/GetSafetyKit/safetykit-python/commit/eb7b602f204148f531e77ad21a6653d8659a5e84))
* **api:** api update ([57501f0](https://github.com/GetSafetyKit/safetykit-python/commit/57501f0317a80e4d2f39e9e6b3fb4e1cd96d97e1))
* **api:** api update ([dd6b63e](https://github.com/GetSafetyKit/safetykit-python/commit/dd6b63e7dec60922e3bdcc556520de0fee3ea00c))
* **api:** api update ([a8c3257](https://github.com/GetSafetyKit/safetykit-python/commit/a8c3257426ea49ea5d083bffd64229ccfb9d61be))
* **api:** api update ([5f7ac71](https://github.com/GetSafetyKit/safetykit-python/commit/5f7ac717e023980d256af31ac15a50dd13a7d2e4))
* **api:** api update ([417439a](https://github.com/GetSafetyKit/safetykit-python/commit/417439a10246b0eb8d4ab3f1732fdfaa5fa05f35))
* **api:** api update ([9c91d65](https://github.com/GetSafetyKit/safetykit-python/commit/9c91d656da66f11bcb0dd776c7e6f9180112ac36))
* **api:** api update ([4c85a41](https://github.com/GetSafetyKit/safetykit-python/commit/4c85a415f9ada4db5507e1cea4e06992109f4536))
* **api:** api update ([3e64fe7](https://github.com/GetSafetyKit/safetykit-python/commit/3e64fe7030e14f69c6a8a4443730f2806210f0ba))
* **api:** api update ([498d31c](https://github.com/GetSafetyKit/safetykit-python/commit/498d31cc24a5de89584952ef0ae398bd3c92b499))
* **api:** api update ([25f1db2](https://github.com/GetSafetyKit/safetykit-python/commit/25f1db2bc8e78d1ea8f3011a465a36e75f5384e8))
* **api:** api update ([d7dcdc7](https://github.com/GetSafetyKit/safetykit-python/commit/d7dcdc78387d697df9eeede3d35f8bf700f0d249))
* **api:** api update ([ba7acbd](https://github.com/GetSafetyKit/safetykit-python/commit/ba7acbd84ba08a183c513b1ab611647f19c3a32b))
* **api:** api update ([87822cf](https://github.com/GetSafetyKit/safetykit-python/commit/87822cf9b81e89dec678dafedd0598fbe51c33ed))
* **api:** api update ([919ed50](https://github.com/GetSafetyKit/safetykit-python/commit/919ed50b5c710ea1904ccb957fc5af9e8a885200))
* **api:** api update ([14c5b31](https://github.com/GetSafetyKit/safetykit-python/commit/14c5b310c7afac558db550669aa9754d6afd6621))
* **api:** api update ([5936045](https://github.com/GetSafetyKit/safetykit-python/commit/593604537cdd45e16ab562d5d21d917c358d282b))
* **api:** api update ([d71637e](https://github.com/GetSafetyKit/safetykit-python/commit/d71637e9af2b8b067bae76b70a21eddd83481f1c))
* **api:** api update ([b0d64f6](https://github.com/GetSafetyKit/safetykit-python/commit/b0d64f611f29af3e75cf54d34e15e4eb662ba493))
* **api:** api update ([e445960](https://github.com/GetSafetyKit/safetykit-python/commit/e445960e231d5b9951667613e08ff8c2a510df59))
* **api:** api update ([e5065b7](https://github.com/GetSafetyKit/safetykit-python/commit/e5065b7386cce5dbd5c5e77fabef76920d71095e))
* **api:** api update ([73cda5d](https://github.com/GetSafetyKit/safetykit-python/commit/73cda5dd8ab277c1f0d22538577bade00ed2741b))
* **api:** api update ([e62c175](https://github.com/GetSafetyKit/safetykit-python/commit/e62c175301fca5b4d70c5503181ad3a2fa67f9a5))
* **api:** api update ([c66b9ab](https://github.com/GetSafetyKit/safetykit-python/commit/c66b9ab3947a60f92f8e72c58227c5d75a8aa7be))
* **api:** api update ([cdc9df6](https://github.com/GetSafetyKit/safetykit-python/commit/cdc9df677e69ab9b818f7980811e5b59098310c4))
* **api:** api update ([fb8a04a](https://github.com/GetSafetyKit/safetykit-python/commit/fb8a04a70a4b598f1ba6b3b6f1b95060b8550518))
* **api:** api update ([c559506](https://github.com/GetSafetyKit/safetykit-python/commit/c559506cea0020988b86899f046d88a31cc13afe))
* **api:** api update ([f93d6b1](https://github.com/GetSafetyKit/safetykit-python/commit/f93d6b1da8eb1cb73fcf3a37be0eb789ba755bba))
* **api:** api update ([fd9dc0a](https://github.com/GetSafetyKit/safetykit-python/commit/fd9dc0aa94e19846df4272d5ccabeb195c1f1976))
* **api:** api update ([7e2c261](https://github.com/GetSafetyKit/safetykit-python/commit/7e2c261efe218b5084b805ba73435e86547e91d1))
* **api:** api update ([6f967c9](https://github.com/GetSafetyKit/safetykit-python/commit/6f967c947e4d3793a5bcedf304ef0d7d740abdd7))
* **api:** api update ([3abe2b8](https://github.com/GetSafetyKit/safetykit-python/commit/3abe2b8617abf007de6a6e7a2539733980f272ce))
* **api:** api update ([171b3f7](https://github.com/GetSafetyKit/safetykit-python/commit/171b3f74563bb287a114f4f49983f672ef33f7a3))
* **api:** api update ([c8fcc5b](https://github.com/GetSafetyKit/safetykit-python/commit/c8fcc5b624218d254da5b93c5dac123e3f1e40f6))
* **api:** api update ([67ec9fc](https://github.com/GetSafetyKit/safetykit-python/commit/67ec9fca9ba6d30b426b64c513dd716a2692d4d5))
* **api:** api update ([3b9daed](https://github.com/GetSafetyKit/safetykit-python/commit/3b9daedf2d2ceb7e2afd6e7bf2e36929f8122e02))
* **api:** manual updates ([2333498](https://github.com/GetSafetyKit/safetykit-python/commit/23334980c06ba4098bc74f2ef41bbc06b43256ac))
* **client:** add custom JSON encoder for extended type support ([23549e2](https://github.com/GetSafetyKit/safetykit-python/commit/23549e263cc60dad9aed852fada809e3063960c8))
* **client:** add support for binary request streaming ([75557fa](https://github.com/GetSafetyKit/safetykit-python/commit/75557fadc680721c7ec0b6baa745a0e31deb84cf))
* **internal:** implement indices array format for query and form serialization ([f052ef1](https://github.com/GetSafetyKit/safetykit-python/commit/f052ef1c64959cf4aa57e1e2cfb74424518237c3))


### Bug Fixes

* **client:** preserve hardcoded query params when merging with user params ([b480217](https://github.com/GetSafetyKit/safetykit-python/commit/b480217447cc0173f5a0bbc33cbc61259f1d513d))
* **deps:** bump minimum typing-extensions version ([958910c](https://github.com/GetSafetyKit/safetykit-python/commit/958910c7a489e84a5d5ad0d3751edc4de5d72d42))
* ensure streams are always closed ([f0fd5d6](https://github.com/GetSafetyKit/safetykit-python/commit/f0fd5d6cd5c0aa0ec13bf2b690f48b4cecb33605))
* **pydantic:** do not pass `by_alias` unless set ([8bb5d95](https://github.com/GetSafetyKit/safetykit-python/commit/8bb5d95e5d88890f68d60862d5de0d1d61a2912b))
* sanitize endpoint path params ([a80aafb](https://github.com/GetSafetyKit/safetykit-python/commit/a80aafb0f7b12cc6ecf3c226edc7f1d72f6bd6fd))
* **types:** allow pyright to infer TypedDict types within SequenceNotStr ([aaa104f](https://github.com/GetSafetyKit/safetykit-python/commit/aaa104f801ec9293694eb4bad8ded1212a7acb66))
* use async_to_httpx_files in patch method ([b6e178c](https://github.com/GetSafetyKit/safetykit-python/commit/b6e178ccc112a017c1ad591b1dfa8844edd09522))


### Chores

* add missing docstrings ([c2a1a2a](https://github.com/GetSafetyKit/safetykit-python/commit/c2a1a2ab32909333a662ef9fecbec2db06fa3b8c))
* add Python 3.14 classifier and testing ([b702cde](https://github.com/GetSafetyKit/safetykit-python/commit/b702cdeeab5728f4d6b2af6b69008c210fc637bd))
* **ci:** skip lint on metadata-only changes ([35053fd](https://github.com/GetSafetyKit/safetykit-python/commit/35053fdf8fd0da4dc92d0fa5ad77d0ce4c70ebc1))
* **ci:** skip uploading artifacts on stainless-internal branches ([09bdac5](https://github.com/GetSafetyKit/safetykit-python/commit/09bdac54eb5a7ee39c5284c857bd06a37f6388f1))
* **ci:** upgrade `actions/github-script` ([91b21c4](https://github.com/GetSafetyKit/safetykit-python/commit/91b21c45f3932453999ac04010dcc44408e15869))
* **deps:** mypy 1.18.1 has a regression, pin to 1.17 ([36c7255](https://github.com/GetSafetyKit/safetykit-python/commit/36c7255ac0184bf0de7847bdbadde515736fe376))
* **docs:** use environment variables for authentication in code snippets ([399fa7e](https://github.com/GetSafetyKit/safetykit-python/commit/399fa7e6bb31087d08c0f0ab5a2427a673987d8c))
* format all `api.md` files ([951056c](https://github.com/GetSafetyKit/safetykit-python/commit/951056c1422caa05d7dfc88c7323d205b5b4128d))
* **internal:** add `--fix` argument to lint script ([3c702e7](https://github.com/GetSafetyKit/safetykit-python/commit/3c702e72f010262c1b90a4b8ce2fb776e8632c82))
* **internal:** add missing files argument to base client ([3a1e1d8](https://github.com/GetSafetyKit/safetykit-python/commit/3a1e1d8f676581a028f8a0a2946f12a8e23755a8))
* **internal:** add request options to SSE classes ([7b739a6](https://github.com/GetSafetyKit/safetykit-python/commit/7b739a67e80ed97d66ecf0dd4545ae520c9f39b4))
* **internal:** bump dependencies ([0dc20e3](https://github.com/GetSafetyKit/safetykit-python/commit/0dc20e38f9337d7047a9b8260a03906c1e17a945))
* **internal:** codegen related update ([876f003](https://github.com/GetSafetyKit/safetykit-python/commit/876f003411f33c2227e04f490e77aab44fa19c24))
* **internal:** codegen related update ([0812f4c](https://github.com/GetSafetyKit/safetykit-python/commit/0812f4c7bb70dd1a7e933451907a43bed01e1ed3))
* **internal:** codegen related update ([295bc83](https://github.com/GetSafetyKit/safetykit-python/commit/295bc83764db3a802af6bdeb5c33cba4f2ea89c8))
* **internal:** fix lint error on Python 3.14 ([7868042](https://github.com/GetSafetyKit/safetykit-python/commit/7868042b38dae288d13a4d16d7a6e361f675f5fa))
* **internal:** make `test_proxy_environment_variables` more resilient ([40377f5](https://github.com/GetSafetyKit/safetykit-python/commit/40377f57ac0d2f3c660c2020fd236746af694945))
* **internal:** make `test_proxy_environment_variables` more resilient to env ([c2e0195](https://github.com/GetSafetyKit/safetykit-python/commit/c2e0195f32f1902df349d04a7a28fcfedab4a4d4))
* **internal:** remove mock server code ([9f99653](https://github.com/GetSafetyKit/safetykit-python/commit/9f9965372c380a1a2f676ad53515c9dcc2a56b49))
* **internal:** tweak CI branches ([4e86e38](https://github.com/GetSafetyKit/safetykit-python/commit/4e86e382039aa171355abb978868f725e2109370))
* **internal:** update `actions/checkout` version ([9d87091](https://github.com/GetSafetyKit/safetykit-python/commit/9d87091b4460d2c3cd396def0e4cc73f7b8ad033))
* **internal:** update gitignore ([02fae36](https://github.com/GetSafetyKit/safetykit-python/commit/02fae36d8c872a383e6ea19ff2bf7150942f31aa))
* speedup initial import ([a00bc3e](https://github.com/GetSafetyKit/safetykit-python/commit/a00bc3ecc7b2f489e5f8a6e6aa0eec4659355610))
* update lockfile ([d56626c](https://github.com/GetSafetyKit/safetykit-python/commit/d56626cef0264878989c9d39f8d9980b1b8d966d))
* update mock server docs ([8839a57](https://github.com/GetSafetyKit/safetykit-python/commit/8839a57df3198085bb7e1125bd8e50f3c1acbb36))
* update SDK settings ([9f149c6](https://github.com/GetSafetyKit/safetykit-python/commit/9f149c624457f3ae90960f8a58d14b616fb175f2))
* update SDK settings ([e66de9f](https://github.com/GetSafetyKit/safetykit-python/commit/e66de9f8fc51fd3e81365e5ce65b16322cdab598))
* update SDK settings ([d79f0ee](https://github.com/GetSafetyKit/safetykit-python/commit/d79f0ee3b568159586216b4ab07a7d4797382ffb))

## 0.6.0-alpha (2026-04-09)

Full Changelog: [v0.5.0-alpha...v0.6.0-alpha](https://github.com/GetSafetyKit/safetykit-python/compare/v0.5.0-alpha...v0.6.0-alpha)

### Features

* **api:** api update ([26e98e4](https://github.com/GetSafetyKit/safetykit-python/commit/26e98e4cfbbba60971790af78b1a4d0e8d81b500))
* **api:** api update ([d56a140](https://github.com/GetSafetyKit/safetykit-python/commit/d56a140e8cdd9321351590a8ac89b7da9af578e7))
* **api:** api update ([3112aec](https://github.com/GetSafetyKit/safetykit-python/commit/3112aec32e15b04fc1925c48b823265f87cd4c3d))
* **api:** api update ([d634f89](https://github.com/GetSafetyKit/safetykit-python/commit/d634f89bd98b03efc7b076bd3440d874071d23d7))
* **api:** api update ([4792174](https://github.com/GetSafetyKit/safetykit-python/commit/4792174752d99ee527c212c3bd2726da2ef9899a))
* **api:** api update ([24897c4](https://github.com/GetSafetyKit/safetykit-python/commit/24897c412249cc52148daf4381fce492642bf46d))
* **api:** api update ([8b026b7](https://github.com/GetSafetyKit/safetykit-python/commit/8b026b7e5f734637881cb462f710fbe3d181aa4f))
* **api:** api update ([b3125d7](https://github.com/GetSafetyKit/safetykit-python/commit/b3125d7b06c576712dbd70960f9860623eaec768))
* **api:** api update ([da066a1](https://github.com/GetSafetyKit/safetykit-python/commit/da066a1d47c9f584f4c2d9db2fdb1b2c14e3c207))
* **api:** api update ([bb04f76](https://github.com/GetSafetyKit/safetykit-python/commit/bb04f764774fb3393ecbeae8ef3651e4cfb81224))
* **api:** api update ([b91a9ba](https://github.com/GetSafetyKit/safetykit-python/commit/b91a9bac89059bf408412f1a28512530da1e14ac))
* **internal:** implement indices array format for query and form serialization ([f052ef1](https://github.com/GetSafetyKit/safetykit-python/commit/f052ef1c64959cf4aa57e1e2cfb74424518237c3))


### Bug Fixes

* **client:** preserve hardcoded query params when merging with user params ([b480217](https://github.com/GetSafetyKit/safetykit-python/commit/b480217447cc0173f5a0bbc33cbc61259f1d513d))
* **deps:** bump minimum typing-extensions version ([958910c](https://github.com/GetSafetyKit/safetykit-python/commit/958910c7a489e84a5d5ad0d3751edc4de5d72d42))
* **pydantic:** do not pass `by_alias` unless set ([8bb5d95](https://github.com/GetSafetyKit/safetykit-python/commit/8bb5d95e5d88890f68d60862d5de0d1d61a2912b))
* sanitize endpoint path params ([a80aafb](https://github.com/GetSafetyKit/safetykit-python/commit/a80aafb0f7b12cc6ecf3c226edc7f1d72f6bd6fd))


### Chores

* **ci:** skip lint on metadata-only changes ([35053fd](https://github.com/GetSafetyKit/safetykit-python/commit/35053fdf8fd0da4dc92d0fa5ad77d0ce4c70ebc1))
* **internal:** tweak CI branches ([4e86e38](https://github.com/GetSafetyKit/safetykit-python/commit/4e86e382039aa171355abb978868f725e2109370))
* **internal:** update gitignore ([02fae36](https://github.com/GetSafetyKit/safetykit-python/commit/02fae36d8c872a383e6ea19ff2bf7150942f31aa))
* update SDK settings ([9f149c6](https://github.com/GetSafetyKit/safetykit-python/commit/9f149c624457f3ae90960f8a58d14b616fb175f2))

## 0.5.0-alpha (2026-03-11)

Full Changelog: [v0.4.0-alpha...v0.5.0-alpha](https://github.com/GetSafetyKit/safetykit-python/compare/v0.4.0-alpha...v0.5.0-alpha)

### Features

* **api:** api update ([15f00fc](https://github.com/GetSafetyKit/safetykit-python/commit/15f00fcdf2ed8970a74e6fd781872429899f1d8e))
* **api:** api update ([0ba9787](https://github.com/GetSafetyKit/safetykit-python/commit/0ba9787199051906b5934d849a68576843b2296e))


### Chores

* **ci:** skip uploading artifacts on stainless-internal branches ([09bdac5](https://github.com/GetSafetyKit/safetykit-python/commit/09bdac54eb5a7ee39c5284c857bd06a37f6388f1))

## 0.4.0-alpha (2026-03-03)

Full Changelog: [v0.3.0-alpha...v0.4.0-alpha](https://github.com/GetSafetyKit/safetykit-python/compare/v0.3.0-alpha...v0.4.0-alpha)

### Features

* **api:** api update ([011b588](https://github.com/GetSafetyKit/safetykit-python/commit/011b5883bde2e8b83427025ce3d87b67b8170637))
* **api:** api update ([eae018b](https://github.com/GetSafetyKit/safetykit-python/commit/eae018baf78dd4e60e60d29c5b09368c0c70864d))
* **api:** api update ([d6e4d3b](https://github.com/GetSafetyKit/safetykit-python/commit/d6e4d3bd79d8be60504fdc73b1bcd9f944156a54))
* **api:** api update ([6de537c](https://github.com/GetSafetyKit/safetykit-python/commit/6de537c55e847593ab7890aba3da751c20a00533))
* **api:** api update ([c948405](https://github.com/GetSafetyKit/safetykit-python/commit/c948405548a24e14133a0f2c20be66cee045b482))
* **api:** api update ([73f9d48](https://github.com/GetSafetyKit/safetykit-python/commit/73f9d48d5018c17470d40440315fb5a2de036a66))
* **api:** api update ([2f877d2](https://github.com/GetSafetyKit/safetykit-python/commit/2f877d2c17c9211064e5cccfe68759e1db521c3e))
* **api:** api update ([eb7b602](https://github.com/GetSafetyKit/safetykit-python/commit/eb7b602f204148f531e77ad21a6653d8659a5e84))
* **api:** api update ([57501f0](https://github.com/GetSafetyKit/safetykit-python/commit/57501f0317a80e4d2f39e9e6b3fb4e1cd96d97e1))
* **api:** api update ([dd6b63e](https://github.com/GetSafetyKit/safetykit-python/commit/dd6b63e7dec60922e3bdcc556520de0fee3ea00c))
* **api:** api update ([a8c3257](https://github.com/GetSafetyKit/safetykit-python/commit/a8c3257426ea49ea5d083bffd64229ccfb9d61be))
* **api:** api update ([5f7ac71](https://github.com/GetSafetyKit/safetykit-python/commit/5f7ac717e023980d256af31ac15a50dd13a7d2e4))
* **api:** api update ([417439a](https://github.com/GetSafetyKit/safetykit-python/commit/417439a10246b0eb8d4ab3f1732fdfaa5fa05f35))
* **api:** api update ([9c91d65](https://github.com/GetSafetyKit/safetykit-python/commit/9c91d656da66f11bcb0dd776c7e6f9180112ac36))
* **api:** api update ([4c85a41](https://github.com/GetSafetyKit/safetykit-python/commit/4c85a415f9ada4db5507e1cea4e06992109f4536))
* **api:** api update ([3e64fe7](https://github.com/GetSafetyKit/safetykit-python/commit/3e64fe7030e14f69c6a8a4443730f2806210f0ba))
* **api:** api update ([498d31c](https://github.com/GetSafetyKit/safetykit-python/commit/498d31cc24a5de89584952ef0ae398bd3c92b499))
* **api:** api update ([25f1db2](https://github.com/GetSafetyKit/safetykit-python/commit/25f1db2bc8e78d1ea8f3011a465a36e75f5384e8))
* **api:** api update ([d7dcdc7](https://github.com/GetSafetyKit/safetykit-python/commit/d7dcdc78387d697df9eeede3d35f8bf700f0d249))
* **api:** api update ([ba7acbd](https://github.com/GetSafetyKit/safetykit-python/commit/ba7acbd84ba08a183c513b1ab611647f19c3a32b))
* **api:** api update ([87822cf](https://github.com/GetSafetyKit/safetykit-python/commit/87822cf9b81e89dec678dafedd0598fbe51c33ed))
* **api:** api update ([919ed50](https://github.com/GetSafetyKit/safetykit-python/commit/919ed50b5c710ea1904ccb957fc5af9e8a885200))
* **api:** api update ([14c5b31](https://github.com/GetSafetyKit/safetykit-python/commit/14c5b310c7afac558db550669aa9754d6afd6621))
* **api:** api update ([5936045](https://github.com/GetSafetyKit/safetykit-python/commit/593604537cdd45e16ab562d5d21d917c358d282b))
* **api:** api update ([d71637e](https://github.com/GetSafetyKit/safetykit-python/commit/d71637e9af2b8b067bae76b70a21eddd83481f1c))
* **client:** add custom JSON encoder for extended type support ([23549e2](https://github.com/GetSafetyKit/safetykit-python/commit/23549e263cc60dad9aed852fada809e3063960c8))
* **client:** add support for binary request streaming ([75557fa](https://github.com/GetSafetyKit/safetykit-python/commit/75557fadc680721c7ec0b6baa745a0e31deb84cf))


### Chores

* **ci:** upgrade `actions/github-script` ([91b21c4](https://github.com/GetSafetyKit/safetykit-python/commit/91b21c45f3932453999ac04010dcc44408e15869))
* format all `api.md` files ([951056c](https://github.com/GetSafetyKit/safetykit-python/commit/951056c1422caa05d7dfc88c7323d205b5b4128d))
* **internal:** add `--fix` argument to lint script ([3c702e7](https://github.com/GetSafetyKit/safetykit-python/commit/3c702e72f010262c1b90a4b8ce2fb776e8632c82))
* **internal:** add request options to SSE classes ([7b739a6](https://github.com/GetSafetyKit/safetykit-python/commit/7b739a67e80ed97d66ecf0dd4545ae520c9f39b4))
* **internal:** bump dependencies ([0dc20e3](https://github.com/GetSafetyKit/safetykit-python/commit/0dc20e38f9337d7047a9b8260a03906c1e17a945))
* **internal:** codegen related update ([876f003](https://github.com/GetSafetyKit/safetykit-python/commit/876f003411f33c2227e04f490e77aab44fa19c24))
* **internal:** codegen related update ([0812f4c](https://github.com/GetSafetyKit/safetykit-python/commit/0812f4c7bb70dd1a7e933451907a43bed01e1ed3))
* **internal:** codegen related update ([295bc83](https://github.com/GetSafetyKit/safetykit-python/commit/295bc83764db3a802af6bdeb5c33cba4f2ea89c8))
* **internal:** fix lint error on Python 3.14 ([7868042](https://github.com/GetSafetyKit/safetykit-python/commit/7868042b38dae288d13a4d16d7a6e361f675f5fa))
* **internal:** make `test_proxy_environment_variables` more resilient ([40377f5](https://github.com/GetSafetyKit/safetykit-python/commit/40377f57ac0d2f3c660c2020fd236746af694945))
* **internal:** make `test_proxy_environment_variables` more resilient to env ([c2e0195](https://github.com/GetSafetyKit/safetykit-python/commit/c2e0195f32f1902df349d04a7a28fcfedab4a4d4))
* **internal:** remove mock server code ([9f99653](https://github.com/GetSafetyKit/safetykit-python/commit/9f9965372c380a1a2f676ad53515c9dcc2a56b49))
* **internal:** update `actions/checkout` version ([9d87091](https://github.com/GetSafetyKit/safetykit-python/commit/9d87091b4460d2c3cd396def0e4cc73f7b8ad033))
* update mock server docs ([8839a57](https://github.com/GetSafetyKit/safetykit-python/commit/8839a57df3198085bb7e1125bd8e50f3c1acbb36))

## 0.3.0-alpha (2025-12-18)

Full Changelog: [v0.2.0-alpha...v0.3.0-alpha](https://github.com/GetSafetyKit/safetykit-python/compare/v0.2.0-alpha...v0.3.0-alpha)

### Features

* **api:** api update ([b0d64f6](https://github.com/GetSafetyKit/safetykit-python/commit/b0d64f611f29af3e75cf54d34e15e4eb662ba493))
* **api:** api update ([e445960](https://github.com/GetSafetyKit/safetykit-python/commit/e445960e231d5b9951667613e08ff8c2a510df59))
* **api:** api update ([e5065b7](https://github.com/GetSafetyKit/safetykit-python/commit/e5065b7386cce5dbd5c5e77fabef76920d71095e))


### Bug Fixes

* **types:** allow pyright to infer TypedDict types within SequenceNotStr ([aaa104f](https://github.com/GetSafetyKit/safetykit-python/commit/aaa104f801ec9293694eb4bad8ded1212a7acb66))
* use async_to_httpx_files in patch method ([b6e178c](https://github.com/GetSafetyKit/safetykit-python/commit/b6e178ccc112a017c1ad591b1dfa8844edd09522))


### Chores

* add missing docstrings ([c2a1a2a](https://github.com/GetSafetyKit/safetykit-python/commit/c2a1a2ab32909333a662ef9fecbec2db06fa3b8c))
* **docs:** use environment variables for authentication in code snippets ([399fa7e](https://github.com/GetSafetyKit/safetykit-python/commit/399fa7e6bb31087d08c0f0ab5a2427a673987d8c))
* **internal:** add missing files argument to base client ([3a1e1d8](https://github.com/GetSafetyKit/safetykit-python/commit/3a1e1d8f676581a028f8a0a2946f12a8e23755a8))
* speedup initial import ([a00bc3e](https://github.com/GetSafetyKit/safetykit-python/commit/a00bc3ecc7b2f489e5f8a6e6aa0eec4659355610))
* update lockfile ([d56626c](https://github.com/GetSafetyKit/safetykit-python/commit/d56626cef0264878989c9d39f8d9980b1b8d966d))

## 0.2.0-alpha (2025-12-02)

Full Changelog: [v0.1.0-alpha...v0.2.0-alpha](https://github.com/GetSafetyKit/safetykit-python/compare/v0.1.0-alpha...v0.2.0-alpha)

### Features

* **api:** api update ([73cda5d](https://github.com/GetSafetyKit/safetykit-python/commit/73cda5dd8ab277c1f0d22538577bade00ed2741b))
* **api:** api update ([e62c175](https://github.com/GetSafetyKit/safetykit-python/commit/e62c175301fca5b4d70c5503181ad3a2fa67f9a5))
* **api:** api update ([c66b9ab](https://github.com/GetSafetyKit/safetykit-python/commit/c66b9ab3947a60f92f8e72c58227c5d75a8aa7be))

## 0.1.0-alpha (2025-11-28)

Full Changelog: [v0.0.1-alpha...v0.1.0-alpha](https://github.com/GetSafetyKit/safetykit-python/compare/v0.0.1-alpha...v0.1.0-alpha)

### Features

* **api:** api update ([cdc9df6](https://github.com/GetSafetyKit/safetykit-python/commit/cdc9df677e69ab9b818f7980811e5b59098310c4))
* **api:** api update ([fb8a04a](https://github.com/GetSafetyKit/safetykit-python/commit/fb8a04a70a4b598f1ba6b3b6f1b95060b8550518))
* **api:** api update ([c559506](https://github.com/GetSafetyKit/safetykit-python/commit/c559506cea0020988b86899f046d88a31cc13afe))
* **api:** api update ([f93d6b1](https://github.com/GetSafetyKit/safetykit-python/commit/f93d6b1da8eb1cb73fcf3a37be0eb789ba755bba))


### Bug Fixes

* ensure streams are always closed ([f0fd5d6](https://github.com/GetSafetyKit/safetykit-python/commit/f0fd5d6cd5c0aa0ec13bf2b690f48b4cecb33605))


### Chores

* **deps:** mypy 1.18.1 has a regression, pin to 1.17 ([36c7255](https://github.com/GetSafetyKit/safetykit-python/commit/36c7255ac0184bf0de7847bdbadde515736fe376))

## 0.0.1-alpha (2025-11-25)

Full Changelog: [v0.0.1...v0.0.1-alpha](https://github.com/GetSafetyKit/safetykit-python/compare/v0.0.1...v0.0.1-alpha)

### Features

* **api:** api update ([fd9dc0a](https://github.com/GetSafetyKit/safetykit-python/commit/fd9dc0aa94e19846df4272d5ccabeb195c1f1976))
* **api:** api update ([7e2c261](https://github.com/GetSafetyKit/safetykit-python/commit/7e2c261efe218b5084b805ba73435e86547e91d1))
* **api:** api update ([6f967c9](https://github.com/GetSafetyKit/safetykit-python/commit/6f967c947e4d3793a5bcedf304ef0d7d740abdd7))
* **api:** api update ([3abe2b8](https://github.com/GetSafetyKit/safetykit-python/commit/3abe2b8617abf007de6a6e7a2539733980f272ce))
* **api:** api update ([171b3f7](https://github.com/GetSafetyKit/safetykit-python/commit/171b3f74563bb287a114f4f49983f672ef33f7a3))
* **api:** api update ([c8fcc5b](https://github.com/GetSafetyKit/safetykit-python/commit/c8fcc5b624218d254da5b93c5dac123e3f1e40f6))
* **api:** api update ([67ec9fc](https://github.com/GetSafetyKit/safetykit-python/commit/67ec9fca9ba6d30b426b64c513dd716a2692d4d5))
* **api:** api update ([3b9daed](https://github.com/GetSafetyKit/safetykit-python/commit/3b9daedf2d2ceb7e2afd6e7bf2e36929f8122e02))
* **api:** manual updates ([2333498](https://github.com/GetSafetyKit/safetykit-python/commit/23334980c06ba4098bc74f2ef41bbc06b43256ac))


### Chores

* add Python 3.14 classifier and testing ([b702cde](https://github.com/GetSafetyKit/safetykit-python/commit/b702cdeeab5728f4d6b2af6b69008c210fc637bd))
* update SDK settings ([e66de9f](https://github.com/GetSafetyKit/safetykit-python/commit/e66de9f8fc51fd3e81365e5ce65b16322cdab598))
* update SDK settings ([d79f0ee](https://github.com/GetSafetyKit/safetykit-python/commit/d79f0ee3b568159586216b4ab07a7d4797382ffb))
