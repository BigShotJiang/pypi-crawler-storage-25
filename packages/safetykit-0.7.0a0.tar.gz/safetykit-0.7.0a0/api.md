# Data

Types:

```python
from safetykit.types import (
    DataAddResponse,
    DataGetStatusResponse,
    DataImportResponse,
    DataUpdateSettingsResponse,
)
```

Methods:

- <code title="post /v1/data/{namespace}">client.data.<a href="./src/safetykit/resources/data.py">add</a>(namespace, \*\*<a href="src/safetykit/types/data_add_params.py">params</a>) -> <a href="./src/safetykit/types/data_add_response.py">DataAddResponse</a></code>
- <code title="get /v1/data/{namespace}/requests/{requestId}">client.data.<a href="./src/safetykit/resources/data.py">get_status</a>(request_id, \*, namespace) -> <a href="./src/safetykit/types/data_get_status_response.py">DataGetStatusResponse</a></code>
- <code title="post /v1/data/{namespace}/import">client.data.<a href="./src/safetykit/resources/data.py">import\_</a>(namespace) -> <a href="./src/safetykit/types/data_import_response.py">DataImportResponse</a></code>
- <code title="put /v1/data/{namespace}/settings">client.data.<a href="./src/safetykit/resources/data.py">update_settings</a>(namespace, \*\*<a href="src/safetykit/types/data_update_settings_params.py">params</a>) -> <a href="./src/safetykit/types/data_update_settings_response.py">DataUpdateSettingsResponse</a></code>

# Streams

Types:

```python
from safetykit.types import StreamAddResponse, StreamAddFrameResponse, StreamAddTranscriptResponse
```

Methods:

- <code title="post /v1/streams/{namespace}">client.streams.<a href="./src/safetykit/resources/streams.py">add</a>(namespace, \*\*<a href="src/safetykit/types/stream_add_params.py">params</a>) -> <a href="./src/safetykit/types/stream_add_response.py">StreamAddResponse</a></code>
- <code title="post /v1/streams/{namespace}/frames">client.streams.<a href="./src/safetykit/resources/streams.py">add_frame</a>(namespace, \*\*<a href="src/safetykit/types/stream_add_frame_params.py">params</a>) -> <a href="./src/safetykit/types/stream_add_frame_response.py">StreamAddFrameResponse</a></code>
- <code title="post /v1/streams/{namespace}/transcripts">client.streams.<a href="./src/safetykit/resources/streams.py">add_transcript</a>(namespace, \*\*<a href="src/safetykit/types/stream_add_transcript_params.py">params</a>) -> <a href="./src/safetykit/types/stream_add_transcript_response.py">StreamAddTranscriptResponse</a></code>
