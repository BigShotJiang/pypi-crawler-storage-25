# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from safetykit import Safetykit, AsyncSafetykit
from tests.utils import assert_matches_type
from safetykit.types import (
    StreamAddResponse,
    StreamAddFrameResponse,
    StreamAddTranscriptResponse,
)

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestStreams:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_add(self, client: Safetykit) -> None:
        stream = client.streams.add(
            namespace="namespace",
            id="YOUR_STREAM_ID",
            stream_url="https://cdn.example.com/20948D23.m3u8",
        )
        assert_matches_type(StreamAddResponse, stream, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_add(self, client: Safetykit) -> None:
        response = client.streams.with_raw_response.add(
            namespace="namespace",
            id="YOUR_STREAM_ID",
            stream_url="https://cdn.example.com/20948D23.m3u8",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        stream = response.parse()
        assert_matches_type(StreamAddResponse, stream, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_add(self, client: Safetykit) -> None:
        with client.streams.with_streaming_response.add(
            namespace="namespace",
            id="YOUR_STREAM_ID",
            stream_url="https://cdn.example.com/20948D23.m3u8",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            stream = response.parse()
            assert_matches_type(StreamAddResponse, stream, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_path_params_add(self, client: Safetykit) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `namespace` but received ''"):
            client.streams.with_raw_response.add(
                namespace="",
                id="YOUR_STREAM_ID",
                stream_url="https://cdn.example.com/20948D23.m3u8",
            )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_add_frame(self, client: Safetykit) -> None:
        stream = client.streams.add_frame(
            namespace="namespace",
            image_data_uri="data:image/webp;base64,UklGRiIAAABXRUJQVlA4IBYAAAAwAQCdASoQABAAPm02mUmkIyIh...",
            stream_id="YOUR_STREAM_ID",
            timestamp=1000,
        )
        assert_matches_type(StreamAddFrameResponse, stream, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_add_frame(self, client: Safetykit) -> None:
        response = client.streams.with_raw_response.add_frame(
            namespace="namespace",
            image_data_uri="data:image/webp;base64,UklGRiIAAABXRUJQVlA4IBYAAAAwAQCdASoQABAAPm02mUmkIyIh...",
            stream_id="YOUR_STREAM_ID",
            timestamp=1000,
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        stream = response.parse()
        assert_matches_type(StreamAddFrameResponse, stream, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_add_frame(self, client: Safetykit) -> None:
        with client.streams.with_streaming_response.add_frame(
            namespace="namespace",
            image_data_uri="data:image/webp;base64,UklGRiIAAABXRUJQVlA4IBYAAAAwAQCdASoQABAAPm02mUmkIyIh...",
            stream_id="YOUR_STREAM_ID",
            timestamp=1000,
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            stream = response.parse()
            assert_matches_type(StreamAddFrameResponse, stream, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_path_params_add_frame(self, client: Safetykit) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `namespace` but received ''"):
            client.streams.with_raw_response.add_frame(
                namespace="",
                image_data_uri="data:image/webp;base64,UklGRiIAAABXRUJQVlA4IBYAAAAwAQCdASoQABAAPm02mUmkIyIh...",
                stream_id="YOUR_STREAM_ID",
                timestamp=1000,
            )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_add_transcript(self, client: Safetykit) -> None:
        stream = client.streams.add_transcript(
            namespace="namespace",
            stream_id="YOUR_STREAM_ID",
            text="This is an example transcript segment.",
            timestamp=5000,
        )
        assert_matches_type(StreamAddTranscriptResponse, stream, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_add_transcript(self, client: Safetykit) -> None:
        response = client.streams.with_raw_response.add_transcript(
            namespace="namespace",
            stream_id="YOUR_STREAM_ID",
            text="This is an example transcript segment.",
            timestamp=5000,
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        stream = response.parse()
        assert_matches_type(StreamAddTranscriptResponse, stream, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_add_transcript(self, client: Safetykit) -> None:
        with client.streams.with_streaming_response.add_transcript(
            namespace="namespace",
            stream_id="YOUR_STREAM_ID",
            text="This is an example transcript segment.",
            timestamp=5000,
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            stream = response.parse()
            assert_matches_type(StreamAddTranscriptResponse, stream, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_path_params_add_transcript(self, client: Safetykit) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `namespace` but received ''"):
            client.streams.with_raw_response.add_transcript(
                namespace="",
                stream_id="YOUR_STREAM_ID",
                text="This is an example transcript segment.",
                timestamp=5000,
            )


class TestAsyncStreams:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_add(self, async_client: AsyncSafetykit) -> None:
        stream = await async_client.streams.add(
            namespace="namespace",
            id="YOUR_STREAM_ID",
            stream_url="https://cdn.example.com/20948D23.m3u8",
        )
        assert_matches_type(StreamAddResponse, stream, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_add(self, async_client: AsyncSafetykit) -> None:
        response = await async_client.streams.with_raw_response.add(
            namespace="namespace",
            id="YOUR_STREAM_ID",
            stream_url="https://cdn.example.com/20948D23.m3u8",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        stream = await response.parse()
        assert_matches_type(StreamAddResponse, stream, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_add(self, async_client: AsyncSafetykit) -> None:
        async with async_client.streams.with_streaming_response.add(
            namespace="namespace",
            id="YOUR_STREAM_ID",
            stream_url="https://cdn.example.com/20948D23.m3u8",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            stream = await response.parse()
            assert_matches_type(StreamAddResponse, stream, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_path_params_add(self, async_client: AsyncSafetykit) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `namespace` but received ''"):
            await async_client.streams.with_raw_response.add(
                namespace="",
                id="YOUR_STREAM_ID",
                stream_url="https://cdn.example.com/20948D23.m3u8",
            )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_add_frame(self, async_client: AsyncSafetykit) -> None:
        stream = await async_client.streams.add_frame(
            namespace="namespace",
            image_data_uri="data:image/webp;base64,UklGRiIAAABXRUJQVlA4IBYAAAAwAQCdASoQABAAPm02mUmkIyIh...",
            stream_id="YOUR_STREAM_ID",
            timestamp=1000,
        )
        assert_matches_type(StreamAddFrameResponse, stream, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_add_frame(self, async_client: AsyncSafetykit) -> None:
        response = await async_client.streams.with_raw_response.add_frame(
            namespace="namespace",
            image_data_uri="data:image/webp;base64,UklGRiIAAABXRUJQVlA4IBYAAAAwAQCdASoQABAAPm02mUmkIyIh...",
            stream_id="YOUR_STREAM_ID",
            timestamp=1000,
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        stream = await response.parse()
        assert_matches_type(StreamAddFrameResponse, stream, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_add_frame(self, async_client: AsyncSafetykit) -> None:
        async with async_client.streams.with_streaming_response.add_frame(
            namespace="namespace",
            image_data_uri="data:image/webp;base64,UklGRiIAAABXRUJQVlA4IBYAAAAwAQCdASoQABAAPm02mUmkIyIh...",
            stream_id="YOUR_STREAM_ID",
            timestamp=1000,
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            stream = await response.parse()
            assert_matches_type(StreamAddFrameResponse, stream, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_path_params_add_frame(self, async_client: AsyncSafetykit) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `namespace` but received ''"):
            await async_client.streams.with_raw_response.add_frame(
                namespace="",
                image_data_uri="data:image/webp;base64,UklGRiIAAABXRUJQVlA4IBYAAAAwAQCdASoQABAAPm02mUmkIyIh...",
                stream_id="YOUR_STREAM_ID",
                timestamp=1000,
            )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_add_transcript(self, async_client: AsyncSafetykit) -> None:
        stream = await async_client.streams.add_transcript(
            namespace="namespace",
            stream_id="YOUR_STREAM_ID",
            text="This is an example transcript segment.",
            timestamp=5000,
        )
        assert_matches_type(StreamAddTranscriptResponse, stream, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_add_transcript(self, async_client: AsyncSafetykit) -> None:
        response = await async_client.streams.with_raw_response.add_transcript(
            namespace="namespace",
            stream_id="YOUR_STREAM_ID",
            text="This is an example transcript segment.",
            timestamp=5000,
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        stream = await response.parse()
        assert_matches_type(StreamAddTranscriptResponse, stream, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_add_transcript(self, async_client: AsyncSafetykit) -> None:
        async with async_client.streams.with_streaming_response.add_transcript(
            namespace="namespace",
            stream_id="YOUR_STREAM_ID",
            text="This is an example transcript segment.",
            timestamp=5000,
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            stream = await response.parse()
            assert_matches_type(StreamAddTranscriptResponse, stream, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_path_params_add_transcript(self, async_client: AsyncSafetykit) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `namespace` but received ''"):
            await async_client.streams.with_raw_response.add_transcript(
                namespace="",
                stream_id="YOUR_STREAM_ID",
                text="This is an example transcript segment.",
                timestamp=5000,
            )
