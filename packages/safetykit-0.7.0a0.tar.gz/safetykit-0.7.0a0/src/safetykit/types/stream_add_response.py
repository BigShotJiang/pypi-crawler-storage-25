# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing_extensions import Literal

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = ["StreamAddResponse"]


class StreamAddResponse(BaseModel):
    """Stream ingestion request accepted for asynchronous processing."""

    request_id: str = FieldInfo(alias="requestId")

    status: Literal["accepted"]
