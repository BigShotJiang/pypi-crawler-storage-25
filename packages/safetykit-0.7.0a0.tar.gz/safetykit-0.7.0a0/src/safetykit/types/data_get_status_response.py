# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Dict, List, Union, Optional
from typing_extensions import Literal, TypeAlias

from .._models import BaseModel

__all__ = [
    "DataGetStatusResponse",
    "UnionMember0",
    "UnionMember0Data",
    "UnionMember0DataOutput",
    "UnionMember0DataOutputLabel",
    "UnionMember1",
]


class UnionMember0DataOutputLabel(BaseModel):
    label: str


class UnionMember0DataOutput(BaseModel):
    actions: List[Optional[object]]

    fields: Dict[str, Optional[object]]

    labels: List[UnionMember0DataOutputLabel]


class UnionMember0Data(BaseModel):
    id: str
    """Object identifier from the ingested data"""

    output: Optional[UnionMember0DataOutput] = None

    url: str

    metadata: Optional[Dict[str, Optional[object]]] = None


class UnionMember0(BaseModel):
    data: List[UnionMember0Data]

    namespace: str

    request_id: str

    status: Literal["queued", "uploading", "ingesting", "succeeded", "failed"]


class UnionMember1(BaseModel):
    data_count: int

    data_expires_at: str

    data_url: str

    namespace: str

    request_id: str

    status: Literal["queued", "uploading", "ingesting", "succeeded", "failed"]


DataGetStatusResponse: TypeAlias = Union[UnionMember0, UnionMember1]
