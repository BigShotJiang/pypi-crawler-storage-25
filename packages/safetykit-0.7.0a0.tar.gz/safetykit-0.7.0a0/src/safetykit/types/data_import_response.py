# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing_extensions import Literal

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = ["DataImportResponse"]


class DataImportResponse(BaseModel):
    """Response containing an upload URL and metadata for large-batch import processing.

    Use `PUT {upload_url}` to upload JSONL (one JSON object per line). `upload_url` expires in 12 hours.
    """

    expires_at: str
    """ISO timestamp when upload_url expires (12 hours after issuance)"""

    object_key: str = FieldInfo(alias="objectKey")
    """S3 object key where uploaded JSONL will be processed from"""

    request_id: str = FieldInfo(alias="requestId")
    """Unique identifier for this import request"""

    status: Literal["pending_upload"]
    """Import request is waiting for file upload"""

    upload_url: str
    """
    Pre-signed upload URL for PUT-ing JSONL content
    (`Content-Type: application/json`)
    """
