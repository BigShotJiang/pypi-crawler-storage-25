# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Union, Iterable
from typing_extensions import Required, TypeAlias, TypedDict

__all__ = ["DataAddParams", "Data", "DataDataObject", "DataDataObjectArray"]


class DataAddParams(TypedDict, total=False):
    data: Required[Data]
    """A data object to ingest.

    It must include an id field. All other fields are flexible and can be any JSON
    type.
    """


class DataDataObject(TypedDict, total=False):
    """A data object to ingest.

    It must include an id field. All other fields are flexible and can be any JSON type.
    """

    id: Required[str]
    """
    Unique identifier for this data object. This should be a meaningful identifier
    in the customer's system, as it is the main way to search for specific items
    between systems.
    """


class DataDataObjectArray(TypedDict, total=False):
    """A data object to ingest.

    It must include an id field. All other fields are flexible and can be any JSON type.
    """

    id: Required[str]
    """
    Unique identifier for this data object. This should be a meaningful identifier
    in the customer's system, as it is the main way to search for specific items
    between systems.
    """


Data: TypeAlias = Union[DataDataObject, Iterable[DataDataObjectArray]]
