# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Required, TypedDict

__all__ = ["StreamAddTranscriptParams"]


class StreamAddTranscriptParams(TypedDict, total=False):
    stream_id: Required[str]

    text: Required[str]

    timestamp: Required[int]
