# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Required, TypedDict

__all__ = ["StreamAddFrameParams"]


class StreamAddFrameParams(TypedDict, total=False):
    image_data_uri: Required[str]
    """A data URI containing a base64-encoded frame image.

    Only image/jpeg, image/png, and image/webp are accepted. The decoded bytes must
    match the declared mime type, decode as a valid image, stay within 5 MB, and
    stay within 4096x4096 / 16,000,000 total pixels.
    """

    stream_id: Required[str]

    timestamp: Required[int]
