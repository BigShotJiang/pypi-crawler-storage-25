# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Dict
from typing_extensions import Literal, Required, TypedDict

__all__ = ["DataUpdateSettingsParams", "Schema", "SchemaDisplayHint"]


class DataUpdateSettingsParams(TypedDict, total=False):
    schema: Required[Dict[str, Schema]]
    """Schema mapping field names to their definitions.

    Use content_type to specify which fields contain URLs that should be processed
    (images, videos, or websites), datetime fields, or 'metadata' for fields that
    should be stored but not indexed. Use display_hint to provide UI rendering
    hints.
    """


class SchemaDisplayHint(TypedDict, total=False):
    """Display hint for UI rendering of this field"""

    type: Required[
        Literal[
            "title",
            "subtitle",
            "description",
            "primary_image_url",
            "video_url",
            "location",
            "compact_text",
            "markdown",
            "html",
            "email.reply_to",
            "email.body",
            "email.subject",
            "email.body_image",
            "email.logo_image",
            "email.event",
            "email.footer",
        ]
    ]
    """The display hint type"""


class Schema(TypedDict, total=False):
    """Schema definition for a data field"""

    content_type: Literal["image_url", "video_url", "website_url", "datetime", "metadata"]
    """The type of content (image_url, video_url, website_url, datetime, or metadata).

    When specified as a URL type, SafetyKit will process the URL. Use 'metadata' for
    fields that should be stored but not indexed.
    """

    display_hint: SchemaDisplayHint
    """Display hint for UI rendering of this field"""

    field_limit: int
    """Maximum amount of this field to include when sending to AI models.

    For text fields, this is the character limit. For array fields (e.g. image
    URLs), this is the maximum number of items.
    """

    namespace_ref: str
    """
    The namespace which an id refers to, creating a parent-child relationship with
    that namespace.
    """
