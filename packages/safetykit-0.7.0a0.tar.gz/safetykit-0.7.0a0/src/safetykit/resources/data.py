# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Any, Dict, cast

import httpx

from ..types import data_add_params, data_update_settings_params
from .._types import Body, Query, Headers, NotGiven, not_given
from .._utils import path_template, maybe_transform, async_maybe_transform
from .._compat import cached_property
from .._resource import SyncAPIResource, AsyncAPIResource
from .._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from .._base_client import make_request_options
from ..types.data_add_response import DataAddResponse
from ..types.data_import_response import DataImportResponse
from ..types.data_get_status_response import DataGetStatusResponse
from ..types.data_update_settings_response import DataUpdateSettingsResponse

__all__ = ["DataResource", "AsyncDataResource"]


class DataResource(SyncAPIResource):
    """Ingest data for fraud detection and risk analysis."""

    @cached_property
    def with_raw_response(self) -> DataResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/GetSafetyKit/safetykit-python#accessing-raw-response-data-eg-headers
        """
        return DataResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> DataResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/GetSafetyKit/safetykit-python#with_streaming_response
        """
        return DataResourceWithStreamingResponse(self)

    def add(
        self,
        namespace: str,
        *,
        data: data_add_params.Data,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> DataAddResponse:
        """Add data to a namespace, returning immediately.

        Processing happens
        asynchronously in the background.

        Args:
          namespace: The namespace to ingest data into

          data: A data object to ingest. It must include an id field. All other fields are
              flexible and can be any JSON type.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not namespace:
            raise ValueError(f"Expected a non-empty value for `namespace` but received {namespace!r}")
        return self._post(
            path_template("/v1/data/{namespace}", namespace=namespace),
            body=maybe_transform({"data": data}, data_add_params.DataAddParams),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=DataAddResponse,
        )

    def get_status(
        self,
        request_id: str,
        *,
        namespace: str,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> DataGetStatusResponse:
        """Retrieve the status of a data ingestion request.

        Works for both add and import
        requests.

        Args:
          namespace: The namespace the data was ingested into

          request_id: The request ID returned from the Add endpoint

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not namespace:
            raise ValueError(f"Expected a non-empty value for `namespace` but received {namespace!r}")
        if not request_id:
            raise ValueError(f"Expected a non-empty value for `request_id` but received {request_id!r}")
        return cast(
            DataGetStatusResponse,
            self._get(
                path_template("/v1/data/{namespace}/requests/{request_id}", namespace=namespace, request_id=request_id),
                options=make_request_options(
                    extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
                ),
                cast_to=cast(
                    Any, DataGetStatusResponse
                ),  # Union types cannot be passed in as arguments in the type system
            ),
        )

    def import_(
        self,
        namespace: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> DataImportResponse:
        """
        Request a pre-signed upload URL for importing large JSONL batches into a
        namespace. After receiving `upload_url`, upload your JSONL file using
        `PUT {upload_url}` with header `Content-Type: application/json`; put each JSON
        object on a new line.

        Args:
          namespace: The namespace to ingest data into

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not namespace:
            raise ValueError(f"Expected a non-empty value for `namespace` but received {namespace!r}")
        return self._post(
            path_template("/v1/data/{namespace}/import", namespace=namespace),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=DataImportResponse,
        )

    def update_settings(
        self,
        namespace: str,
        *,
        schema: Dict[str, data_update_settings_params.Schema],
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> DataUpdateSettingsResponse:
        """
        Create or replace settings for a namespace, primarily used to change the schema
        associated with the namespace.

        Args:
          namespace: The namespace to ingest data into

          schema: Schema mapping field names to their definitions. Use content_type to specify
              which fields contain URLs that should be processed (images, videos, or
              websites), datetime fields, or 'metadata' for fields that should be stored but
              not indexed. Use display_hint to provide UI rendering hints.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not namespace:
            raise ValueError(f"Expected a non-empty value for `namespace` but received {namespace!r}")
        return self._put(
            path_template("/v1/data/{namespace}/settings", namespace=namespace),
            body=maybe_transform({"schema": schema}, data_update_settings_params.DataUpdateSettingsParams),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=DataUpdateSettingsResponse,
        )


class AsyncDataResource(AsyncAPIResource):
    """Ingest data for fraud detection and risk analysis."""

    @cached_property
    def with_raw_response(self) -> AsyncDataResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/GetSafetyKit/safetykit-python#accessing-raw-response-data-eg-headers
        """
        return AsyncDataResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncDataResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/GetSafetyKit/safetykit-python#with_streaming_response
        """
        return AsyncDataResourceWithStreamingResponse(self)

    async def add(
        self,
        namespace: str,
        *,
        data: data_add_params.Data,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> DataAddResponse:
        """Add data to a namespace, returning immediately.

        Processing happens
        asynchronously in the background.

        Args:
          namespace: The namespace to ingest data into

          data: A data object to ingest. It must include an id field. All other fields are
              flexible and can be any JSON type.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not namespace:
            raise ValueError(f"Expected a non-empty value for `namespace` but received {namespace!r}")
        return await self._post(
            path_template("/v1/data/{namespace}", namespace=namespace),
            body=await async_maybe_transform({"data": data}, data_add_params.DataAddParams),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=DataAddResponse,
        )

    async def get_status(
        self,
        request_id: str,
        *,
        namespace: str,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> DataGetStatusResponse:
        """Retrieve the status of a data ingestion request.

        Works for both add and import
        requests.

        Args:
          namespace: The namespace the data was ingested into

          request_id: The request ID returned from the Add endpoint

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not namespace:
            raise ValueError(f"Expected a non-empty value for `namespace` but received {namespace!r}")
        if not request_id:
            raise ValueError(f"Expected a non-empty value for `request_id` but received {request_id!r}")
        return cast(
            DataGetStatusResponse,
            await self._get(
                path_template("/v1/data/{namespace}/requests/{request_id}", namespace=namespace, request_id=request_id),
                options=make_request_options(
                    extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
                ),
                cast_to=cast(
                    Any, DataGetStatusResponse
                ),  # Union types cannot be passed in as arguments in the type system
            ),
        )

    async def import_(
        self,
        namespace: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> DataImportResponse:
        """
        Request a pre-signed upload URL for importing large JSONL batches into a
        namespace. After receiving `upload_url`, upload your JSONL file using
        `PUT {upload_url}` with header `Content-Type: application/json`; put each JSON
        object on a new line.

        Args:
          namespace: The namespace to ingest data into

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not namespace:
            raise ValueError(f"Expected a non-empty value for `namespace` but received {namespace!r}")
        return await self._post(
            path_template("/v1/data/{namespace}/import", namespace=namespace),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=DataImportResponse,
        )

    async def update_settings(
        self,
        namespace: str,
        *,
        schema: Dict[str, data_update_settings_params.Schema],
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> DataUpdateSettingsResponse:
        """
        Create or replace settings for a namespace, primarily used to change the schema
        associated with the namespace.

        Args:
          namespace: The namespace to ingest data into

          schema: Schema mapping field names to their definitions. Use content_type to specify
              which fields contain URLs that should be processed (images, videos, or
              websites), datetime fields, or 'metadata' for fields that should be stored but
              not indexed. Use display_hint to provide UI rendering hints.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not namespace:
            raise ValueError(f"Expected a non-empty value for `namespace` but received {namespace!r}")
        return await self._put(
            path_template("/v1/data/{namespace}/settings", namespace=namespace),
            body=await async_maybe_transform({"schema": schema}, data_update_settings_params.DataUpdateSettingsParams),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=DataUpdateSettingsResponse,
        )


class DataResourceWithRawResponse:
    def __init__(self, data: DataResource) -> None:
        self._data = data

        self.add = to_raw_response_wrapper(
            data.add,
        )
        self.get_status = to_raw_response_wrapper(
            data.get_status,
        )
        self.import_ = to_raw_response_wrapper(
            data.import_,
        )
        self.update_settings = to_raw_response_wrapper(
            data.update_settings,
        )


class AsyncDataResourceWithRawResponse:
    def __init__(self, data: AsyncDataResource) -> None:
        self._data = data

        self.add = async_to_raw_response_wrapper(
            data.add,
        )
        self.get_status = async_to_raw_response_wrapper(
            data.get_status,
        )
        self.import_ = async_to_raw_response_wrapper(
            data.import_,
        )
        self.update_settings = async_to_raw_response_wrapper(
            data.update_settings,
        )


class DataResourceWithStreamingResponse:
    def __init__(self, data: DataResource) -> None:
        self._data = data

        self.add = to_streamed_response_wrapper(
            data.add,
        )
        self.get_status = to_streamed_response_wrapper(
            data.get_status,
        )
        self.import_ = to_streamed_response_wrapper(
            data.import_,
        )
        self.update_settings = to_streamed_response_wrapper(
            data.update_settings,
        )


class AsyncDataResourceWithStreamingResponse:
    def __init__(self, data: AsyncDataResource) -> None:
        self._data = data

        self.add = async_to_streamed_response_wrapper(
            data.add,
        )
        self.get_status = async_to_streamed_response_wrapper(
            data.get_status,
        )
        self.import_ = async_to_streamed_response_wrapper(
            data.import_,
        )
        self.update_settings = async_to_streamed_response_wrapper(
            data.update_settings,
        )
