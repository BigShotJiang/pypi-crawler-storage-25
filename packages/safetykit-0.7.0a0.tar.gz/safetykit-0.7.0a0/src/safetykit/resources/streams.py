# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import httpx

from ..types import stream_add_params, stream_add_frame_params, stream_add_transcript_params
from .._types import Body, Query, Headers, NotGiven, not_given
from .._utils import path_template, maybe_transform, async_maybe_transform
from .._compat import cached_property
from .._resource import SyncAPIResource, AsyncAPIResource
from .._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from .._base_client import make_request_options
from ..types.stream_add_response import StreamAddResponse
from ..types.stream_add_frame_response import StreamAddFrameResponse
from ..types.stream_add_transcript_response import StreamAddTranscriptResponse

__all__ = ["StreamsResource", "AsyncStreamsResource"]


class StreamsResource(SyncAPIResource):
    """Ingest and monitor livestream content."""

    @cached_property
    def with_raw_response(self) -> StreamsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/GetSafetyKit/safetykit-python#accessing-raw-response-data-eg-headers
        """
        return StreamsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> StreamsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/GetSafetyKit/safetykit-python#with_streaming_response
        """
        return StreamsResourceWithStreamingResponse(self)

    def add(
        self,
        namespace: str,
        *,
        id: str,
        stream_url: str,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> StreamAddResponse:
        """Monitor the livestream at the given stream URL.

        This method returns immediately.

        Args:
          namespace: The namespace to ingest stream data into

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not namespace:
            raise ValueError(f"Expected a non-empty value for `namespace` but received {namespace!r}")
        return self._post(
            path_template("/v1/streams/{namespace}", namespace=namespace),
            body=maybe_transform(
                {
                    "id": id,
                    "stream_url": stream_url,
                },
                stream_add_params.StreamAddParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=StreamAddResponse,
        )

    def add_frame(
        self,
        namespace: str,
        *,
        image_data_uri: str,
        stream_id: str,
        timestamp: int,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> StreamAddFrameResponse:
        """
        Ingest a single livestream frame as an image data URI plus relative timestamp in
        milliseconds. The stream does not need to be created beforehand. Only
        image/jpeg, image/png, and image/webp are accepted. The decoded bytes must match
        the declared mime type, decode as a valid image, stay within 5 MB, and stay
        within 4096x4096 / 16,000,000 total pixels. Timestamps are relative milliseconds
        from stream start and must be unique and strictly increasing within a stream.
        Duplicate or out-of-order frame timestamps are accepted at the API boundary but
        ignored by downstream processing. This method returns immediately after the
        frame has been accepted for processing.

        Args:
          namespace: The namespace to ingest stream data into

          image_data_uri: A data URI containing a base64-encoded frame image. Only image/jpeg, image/png,
              and image/webp are accepted. The decoded bytes must match the declared mime
              type, decode as a valid image, stay within 5 MB, and stay within 4096x4096 /
              16,000,000 total pixels.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not namespace:
            raise ValueError(f"Expected a non-empty value for `namespace` but received {namespace!r}")
        return self._post(
            path_template("/v1/streams/{namespace}/frames", namespace=namespace),
            body=maybe_transform(
                {
                    "image_data_uri": image_data_uri,
                    "stream_id": stream_id,
                    "timestamp": timestamp,
                },
                stream_add_frame_params.StreamAddFrameParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=StreamAddFrameResponse,
        )

    def add_transcript(
        self,
        namespace: str,
        *,
        stream_id: str,
        text: str,
        timestamp: int,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> StreamAddTranscriptResponse:
        """
        Ingest a single transcript segment for a livestream using a relative timestamp
        in milliseconds. The stream does not need to be created beforehand. Transcript
        timestamps are relative milliseconds from stream start and should be
        monotonically increasing within a stream so transcript context lines up
        correctly with later frames. This method returns immediately after the
        transcript has been accepted for processing.

        Args:
          namespace: The namespace to ingest stream data into

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not namespace:
            raise ValueError(f"Expected a non-empty value for `namespace` but received {namespace!r}")
        return self._post(
            path_template("/v1/streams/{namespace}/transcripts", namespace=namespace),
            body=maybe_transform(
                {
                    "stream_id": stream_id,
                    "text": text,
                    "timestamp": timestamp,
                },
                stream_add_transcript_params.StreamAddTranscriptParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=StreamAddTranscriptResponse,
        )


class AsyncStreamsResource(AsyncAPIResource):
    """Ingest and monitor livestream content."""

    @cached_property
    def with_raw_response(self) -> AsyncStreamsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/GetSafetyKit/safetykit-python#accessing-raw-response-data-eg-headers
        """
        return AsyncStreamsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncStreamsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/GetSafetyKit/safetykit-python#with_streaming_response
        """
        return AsyncStreamsResourceWithStreamingResponse(self)

    async def add(
        self,
        namespace: str,
        *,
        id: str,
        stream_url: str,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> StreamAddResponse:
        """Monitor the livestream at the given stream URL.

        This method returns immediately.

        Args:
          namespace: The namespace to ingest stream data into

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not namespace:
            raise ValueError(f"Expected a non-empty value for `namespace` but received {namespace!r}")
        return await self._post(
            path_template("/v1/streams/{namespace}", namespace=namespace),
            body=await async_maybe_transform(
                {
                    "id": id,
                    "stream_url": stream_url,
                },
                stream_add_params.StreamAddParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=StreamAddResponse,
        )

    async def add_frame(
        self,
        namespace: str,
        *,
        image_data_uri: str,
        stream_id: str,
        timestamp: int,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> StreamAddFrameResponse:
        """
        Ingest a single livestream frame as an image data URI plus relative timestamp in
        milliseconds. The stream does not need to be created beforehand. Only
        image/jpeg, image/png, and image/webp are accepted. The decoded bytes must match
        the declared mime type, decode as a valid image, stay within 5 MB, and stay
        within 4096x4096 / 16,000,000 total pixels. Timestamps are relative milliseconds
        from stream start and must be unique and strictly increasing within a stream.
        Duplicate or out-of-order frame timestamps are accepted at the API boundary but
        ignored by downstream processing. This method returns immediately after the
        frame has been accepted for processing.

        Args:
          namespace: The namespace to ingest stream data into

          image_data_uri: A data URI containing a base64-encoded frame image. Only image/jpeg, image/png,
              and image/webp are accepted. The decoded bytes must match the declared mime
              type, decode as a valid image, stay within 5 MB, and stay within 4096x4096 /
              16,000,000 total pixels.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not namespace:
            raise ValueError(f"Expected a non-empty value for `namespace` but received {namespace!r}")
        return await self._post(
            path_template("/v1/streams/{namespace}/frames", namespace=namespace),
            body=await async_maybe_transform(
                {
                    "image_data_uri": image_data_uri,
                    "stream_id": stream_id,
                    "timestamp": timestamp,
                },
                stream_add_frame_params.StreamAddFrameParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=StreamAddFrameResponse,
        )

    async def add_transcript(
        self,
        namespace: str,
        *,
        stream_id: str,
        text: str,
        timestamp: int,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> StreamAddTranscriptResponse:
        """
        Ingest a single transcript segment for a livestream using a relative timestamp
        in milliseconds. The stream does not need to be created beforehand. Transcript
        timestamps are relative milliseconds from stream start and should be
        monotonically increasing within a stream so transcript context lines up
        correctly with later frames. This method returns immediately after the
        transcript has been accepted for processing.

        Args:
          namespace: The namespace to ingest stream data into

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not namespace:
            raise ValueError(f"Expected a non-empty value for `namespace` but received {namespace!r}")
        return await self._post(
            path_template("/v1/streams/{namespace}/transcripts", namespace=namespace),
            body=await async_maybe_transform(
                {
                    "stream_id": stream_id,
                    "text": text,
                    "timestamp": timestamp,
                },
                stream_add_transcript_params.StreamAddTranscriptParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=StreamAddTranscriptResponse,
        )


class StreamsResourceWithRawResponse:
    def __init__(self, streams: StreamsResource) -> None:
        self._streams = streams

        self.add = to_raw_response_wrapper(
            streams.add,
        )
        self.add_frame = to_raw_response_wrapper(
            streams.add_frame,
        )
        self.add_transcript = to_raw_response_wrapper(
            streams.add_transcript,
        )


class AsyncStreamsResourceWithRawResponse:
    def __init__(self, streams: AsyncStreamsResource) -> None:
        self._streams = streams

        self.add = async_to_raw_response_wrapper(
            streams.add,
        )
        self.add_frame = async_to_raw_response_wrapper(
            streams.add_frame,
        )
        self.add_transcript = async_to_raw_response_wrapper(
            streams.add_transcript,
        )


class StreamsResourceWithStreamingResponse:
    def __init__(self, streams: StreamsResource) -> None:
        self._streams = streams

        self.add = to_streamed_response_wrapper(
            streams.add,
        )
        self.add_frame = to_streamed_response_wrapper(
            streams.add_frame,
        )
        self.add_transcript = to_streamed_response_wrapper(
            streams.add_transcript,
        )


class AsyncStreamsResourceWithStreamingResponse:
    def __init__(self, streams: AsyncStreamsResource) -> None:
        self._streams = streams

        self.add = async_to_streamed_response_wrapper(
            streams.add,
        )
        self.add_frame = async_to_streamed_response_wrapper(
            streams.add_frame,
        )
        self.add_transcript = async_to_streamed_response_wrapper(
            streams.add_transcript,
        )
