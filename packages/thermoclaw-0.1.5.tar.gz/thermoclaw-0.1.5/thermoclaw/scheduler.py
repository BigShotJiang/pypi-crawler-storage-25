"""
thermoclaw.scheduler
=====================
ThermoScheduler — a drop-in replacement for cosine/linear schedulers
that uses live thermodynamic feedback to adapt the learning rate.

**This is the adoption wedge.** One line replaces a cosine scheduler
and gets Thermoclaw into any training pipeline without touching the
optimizer. Users keep AdamW/SGD/whatever — they just get a smarter
schedule.

Usage::

    from thermoclaw import ThermoScheduler

    optimizer = torch.optim.AdamW(model.parameters(), lr=3e-4)
    scheduler = ThermoScheduler(optimizer, total_steps=10000)

    for step, batch in enumerate(loader):
        loss = criterion(model(batch))
        loss.backward()
        optimizer.step()
        scheduler.step()         # ← replaces cosine_scheduler.step()
        optimizer.zero_grad()

How it works:

1. During warmup: linear ramp from η_min to η_max (identical to standard).
2. After warmup: monitors per-group gradient coherence (ρ) and the
   effective entropy ratio r = σ / σ* to decide whether to hold, reduce,
   or slightly increase lr.
3. If gradients are coherent (ρ > 0.3) and entropy is below target
   (r < 0.9), lr is gently increased toward ceiling.
4. If gradients are incoherent (ρ < -0.1) or entropy overshoots (r > 1.2),
   lr decays faster than cosine.
5. Net effect: longer effective high-lr plateau when training is stable,
   faster decay when it's not. No new hyperparameters to tune.

The scheduler is read-only with respect to the model — it only reads
gradients, never modifies them. It wraps the standard
``torch.optim.lr_scheduler._LRScheduler`` interface.
"""

from __future__ import annotations

import math
from typing import Any, Dict, List, Optional

import torch
from torch.optim.lr_scheduler import LRScheduler


class ThermoScheduler(LRScheduler):
    """Thermodynamically-aware learning rate scheduler.

    Drop-in replacement for CosineAnnealingLR / LinearLR.

    Parameters
    ----------
    optimizer : torch.optim.Optimizer
    total_steps : int
        Total training steps (for cosine envelope).
    warmup_steps : int
        Linear warmup steps (default 500).
    eta_min : float
        Minimum learning rate (default 1e-7).
    adapt_rate : float
        How fast the thermodynamic feedback adjusts lr (default 0.05).
        Lower = more conservative (closer to pure cosine).
    """

    def __init__(
        self,
        optimizer_or_observer,        # accepts Optimizer OR Observer
        optimizer_or_total_steps=None,# accepts Optimizer (if 1st arg was Observer) OR int
        total_steps: int = 10000,
        warmup_steps: int = 500,
        eta_min: float = 1e-7,
        adapt_rate: float = 0.05,
        last_epoch: int = -1,
    ):
        # Support ThermoScheduler(observer, optimizer) call pattern
        from thermoclaw.observer import Observer as _Observer
        if isinstance(optimizer_or_observer, _Observer):
            self._observer = optimizer_or_observer
            optimizer = optimizer_or_total_steps
            if optimizer is None or not isinstance(optimizer, torch.optim.Optimizer):
                raise TypeError(
                    "ThermoScheduler(observer, optimizer): second argument must be "
                    "a torch.optim.Optimizer"
                )
        else:
            self._observer = None
            optimizer = optimizer_or_observer
            if isinstance(optimizer_or_total_steps, int):
                total_steps = optimizer_or_total_steps

        self.total_steps = total_steps
        self.warmup_steps = warmup_steps
        self.eta_min = eta_min
        self.adapt_rate = adapt_rate

        # Store base lrs before super().__init__ calls get_lr
        self._base_lrs = [pg['lr'] for pg in optimizer.param_groups]

        # Per-group thermodynamic state
        self._state: List[Dict[str, Any]] = []
        for i, pg in enumerate(optimizer.param_groups):
            params = [p for p in pg['params'] if p.requires_grad]
            self._state.append({
                'params': params,
                'eta_base': pg['lr'],
                'eta_current': pg['lr'],
                'sigma_ema': None,
                'sigma_star': None,
                'sigma_window': [],
                'prev_grad_flat': None,
                'step_count': 0,
            })

        super().__init__(optimizer, last_epoch)

    def step(self, snap=None) -> None:
        """Override to accept optional observer snap dict (ignored; state read from grads)."""
        super().step()

    def get_lr(self) -> List[float]:
        """Compute lr for each param group using thermodynamic feedback."""
        step = self.last_epoch  # _LRScheduler increments this before calling get_lr

        lrs = []
        for i, (pg, st) in enumerate(zip(self.optimizer.param_groups, self._state)):
            eta_base = st['eta_base']

            # ── Warmup phase: linear ramp ─────────────────────────────────
            if step < self.warmup_steps:
                lr = self.eta_min + (eta_base - self.eta_min) * (step / max(1, self.warmup_steps))
                lrs.append(lr)
                continue

            # ── Cosine envelope (the baseline we modulate) ────────────────
            t = step - self.warmup_steps
            total_active = self.total_steps - self.warmup_steps
            cos_frac = 0.5 * (1 + math.cos(math.pi * t / max(1, total_active)))
            eta_cosine = self.eta_min + (eta_base - self.eta_min) * cos_frac

            # ── Thermodynamic feedback ────────────────────────────────────
            params = st['params']
            grads = [p.grad for p in params if p.grad is not None]

            if not grads:
                lrs.append(eta_cosine)
                continue

            st['step_count'] += 1

            # σ = η · ‖g‖²
            gnorm_sq = _group_norm_sq(grads)
            sigma = st['eta_current'] * gnorm_sq

            # σ EMA
            ema_alpha = 0.02
            if st['sigma_ema'] is None:
                st['sigma_ema'] = sigma
            else:
                st['sigma_ema'] = (1 - ema_alpha) * st['sigma_ema'] + ema_alpha * sigma

            # σ* calibration
            if st['step_count'] > 200:
                st['sigma_window'].append(st['sigma_ema'])
                if len(st['sigma_window']) > 200:
                    st['sigma_window'].pop(0)
                if st['sigma_window']:
                    import numpy as np
                    st['sigma_star'] = 1.2 * float(np.median(st['sigma_window']))

            ss = st['sigma_star'] if st['sigma_star'] is not None else st['sigma_ema']
            r = st['sigma_ema'] / (ss + 1e-30)

            # ρ: gradient coherence
            g_flat = torch.cat([g.float().flatten() for g in grads])
            rho = 0.0
            if st['prev_grad_flat'] is not None and st['prev_grad_flat'].shape == g_flat.shape:
                gn = g_flat.norm()
                pn = st['prev_grad_flat'].norm()
                if gn > 1e-12 and pn > 1e-12:
                    rho = float(torch.dot(g_flat, st['prev_grad_flat']) / (gn * pn))
            st['prev_grad_flat'] = g_flat.detach().clone()

            # ── Modulation signal ─────────────────────────────────────────
            # Positive = hold/increase lr, negative = decay faster
            #
            # Coherent grads + below target → push up (slow the cosine decay)
            # Incoherent grads + above target → pull down (accelerate decay)
            signal = 0.0
            if rho > 0.3 and r < 0.9:
                signal = +self.adapt_rate    # Training is stable, hold high
            elif rho < -0.1 or r > 1.2:
                signal = -self.adapt_rate    # Training is unstable, decay

            # Apply modulation to cosine baseline
            # eta = cosine * (1 + cumulative_signal), clamped to [eta_min, eta_base]
            eta = eta_cosine * (1.0 + signal)
            eta = max(self.eta_min, min(eta_base, eta))

            st['eta_current'] = eta
            lrs.append(eta)

        return lrs


def _group_norm_sq(tensors: List[torch.Tensor]) -> float:
    if not tensors:
        return 0.0
    norms = torch._foreach_norm([t.float() for t in tensors], ord=2)
    return float(sum(n.item() ** 2 for n in norms))
