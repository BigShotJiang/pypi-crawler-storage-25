"""
tci.py — Thermodynamic Coherence Index
=======================================
EPTO v5.4

The TCI estimates label noise level online from two scale-invariant
internal signals computed inside the EPTO step:

  Signal 1: D_t = Var({r_1, ..., r_L})   — inter-layer entropy dispersion
            r_l = sigma_l / sigma*

            Clean regime:  layers descend in a coordinated trajectory → D_t tight
            Noisy regime:  early layers extract features while final layer fits
                           corrupted labels → inter-layer tension → D_t grows

  Signal 2: rho_t = cos(g_t, p_t)        — drift alignment

            g_t = current gradient vector (flattened across all layers)
            p_t = OU drift accumulator (flattened)

            Clean regime:  g_t aligns with historical drift direction → rho_t → 1
            Noisy regime:  g_t dominated by corrupted-label gradients, isotropic
                           (Brownian) → rho_t → 0

TCI formula (Eq. 7 in paper):
    TCI_raw_t = clip( D_t / D_base / (1 + max(0, rho_t)), 0, TCI_MAX )
    TCI_fast  = EMA(TCI_raw, alpha=0.1)          — batch-level, drives zeta
    TCI_slow  = EMA(TCI_raw, alpha=1/spe)        — epoch-level, drives drift_scale

Control laws:
    zeta(t)        = zeta_max * sigmoid(-6 * (TCI_fast - 0.5))
    drift_scale(t) = 1 + min(1, TCI_slow)

Three-point calibration (empirical, from ablation data):
    TCI ~ 0.10  →  20% noise  →  zeta ≈ 1.83  (IEC nearly on)
    TCI ~ 0.50  →  40% noise  →  zeta = 1.00  (IEC half, inflection)
    TCI ~ 1.00  →  80% noise  →  zeta ≈ 0.09  (IEC nearly off)

Architecture:
    Warmup freeze: baseline D_base calibrated from second half of warmup.
                   No adaptation fires until warmup_steps is reached.
    Decoupled EMA: fast (batch) and slow (epoch) timescales are separate
                   to prevent drift_scale → TCI → drift_scale oscillation.
    Overflow safe: TCI_raw clamped to [0, TCI_MAX=5.0]; sigmoid input
                   clamped to [-500, 500] before exp.
    shadow_mode:   All signals computed, no feedback written to optimizer.
                   Use for validation before enabling live adaptation.
"""

import math
import csv
import torch
import torch.nn.functional as F
from typing import Dict, List, Any, Optional

# Hard upper bound on raw TCI — prevents baseline near-zero division explosion
TCI_MAX = 5.0

# Minimum baseline variance — prevents D_base ≈ 0 on homogeneous architectures
BASELINE_MIN = 0.05


class TCIController:
    """
    Thermodynamic Coherence Index controller.

    Usage (simple — pass model, call step() each optimizer step)::

        tci = TCIController(model)

        for step, batch in enumerate(loader):
            loss.backward()
            optimizer.step()
            tci_state = tci.step()          # auto-extracts gradient info
            optimizer.zero_grad()

    Usage (advanced — supply r_values and rho_t directly)::

        tci = TCIController(warmup_epochs=2, steps_per_epoch=97)
        tci.update_batch(r_values, rho_t)   # every optimizer step
        tci.update_epoch()                   # at epoch boundary

        # Read outputs:
        zeta        = tci.current_zeta
        drift_scale = tci.current_drift_scale
    """

    def __init__(
        self,
        model_or_warmup_epochs=None,  # accepts nn.Module OR int (warmup_epochs)
        steps_per_epoch:  int   = 97,
        zeta_max:         float = 2.0,
        drift_scale_max:  float = 2.0,
        sigmoid_scale:    float = 6.0,   # steepness; 6.0 calibrated to 3-point curve
        fast_ema_alpha:   float = 0.1,   # batch-level EMA for zeta
        shadow_mode:      bool  = False, # log only, no feedback
        log_every:        int   = 50,    # steps between history entries
        verbose:          bool  = True,
    ):
        import torch.nn as nn
        if isinstance(model_or_warmup_epochs, nn.Module):
            self._model    = model_or_warmup_epochs
            warmup_epochs  = 2   # default
        else:
            self._model    = None
            warmup_epochs  = int(model_or_warmup_epochs) if model_or_warmup_epochs is not None else 2

        self.warmup_steps     = warmup_epochs * steps_per_epoch
        self.steps_per_epoch  = steps_per_epoch
        self.zeta_max         = zeta_max
        self.drift_scale_max  = drift_scale_max
        self.sigmoid_scale    = sigmoid_scale
        self.fast_ema_alpha   = fast_ema_alpha
        self.slow_ema_alpha   = 1.0 / max(steps_per_epoch, 1)
        self.shadow_mode      = shadow_mode
        self.log_every        = log_every
        self.verbose          = verbose

        # ── Internal state ─────────────────────────────────────────────────
        self.current_step    = 0
        self.current_epoch   = 0

        # Warmup baseline calibration
        self._warmup_accum   = 0.0
        self._warmup_count   = 0
        self.var_r_baseline  = 1.0          # overwritten at warmup end
        self.warmup_complete = False

        # Smoothed signals
        self.tci_fast = 0.0
        self.tci_slow = 0.0
        self._rho_ema = 0.0                 # smoothed rho for logging only

        # ── Controller outputs (read by EPTOv5.step) ───────────────────────
        self.current_zeta        = zeta_max  # IEC fully coupled until warmup ends
        self.current_drift_scale = 1.0

        # ── History for logging and shadow-mode validation ─────────────────
        self.history: List[Dict] = []

    # ── PUBLIC API ─────────────────────────────────────────────────────────

    def step(self, r_values: torch.Tensor = None, rho_t: float = None) -> dict:
        """
        Convenience method for the simple usage pattern (model passed to __init__).

        If r_values / rho_t are not supplied, auto-extracts per-layer gradient
        norms from the model passed at construction.  Returns current TCI state dict.

        Call BEFORE optimizer.zero_grad() so gradients are still present.
        """
        if r_values is None:
            r_values = self._auto_r_values()
        if rho_t is None:
            rho_t = 0.0
        self.update_batch(r_values, rho_t)
        return self.get_state()

    def _auto_r_values(self) -> torch.Tensor:
        """Extract per-layer gradient norms as r_values proxy from self._model."""
        if self._model is None:
            return torch.ones(1)
        norms = []
        for module in self._model.modules():
            grads = [p.grad for p in module.parameters(recurse=False)
                     if p.grad is not None]
            if grads:
                norm_sq = sum(float(g.float().norm().item()) ** 2 for g in grads)
                norms.append(norm_sq ** 0.5)
        if not norms:
            return torch.ones(1)
        t = torch.tensor(norms, dtype=torch.float32)
        return t / (t.mean() + 1e-8)

    def update_batch(self, r_values: torch.Tensor, rho_t: float) -> None:
        """
        Called every optimizer step.

        Args:
            r_values: 1-D tensor of per-layer entropy ratios [r_1, ..., r_L]
                      where r_l = sigma_l / sigma*.  Shape: [n_layers].
            rho_t:    cosine similarity of flattened gradient g_t and OU drift p_t.
                      Scalar in [-1, 1].
        """
        self.current_step += 1
        t = self.current_step

        # Per-layer variance (scale-invariant: r_l is already a ratio)
        var_r = float(torch.var(r_values).item()) if r_values.numel() > 1 else 0.0

        # ── WARMUP PHASE: calibrate D_base, freeze outputs ─────────────────
        if t <= self.warmup_steps:
            # Accumulate only second half of warmup to avoid initial-bang bias
            if t > self.warmup_steps // 2:
                self._warmup_accum += var_r
                self._warmup_count += 1

            if t == self.warmup_steps:
                raw_base = self._warmup_accum / max(self._warmup_count, 1)
                self.var_r_baseline = max(raw_base, BASELINE_MIN)
                self.warmup_complete = True
                if self.verbose:
                    print(f"  [TCI] Warmup complete — D_base = {self.var_r_baseline:.6f}")

            self._log(t, var_r, rho_t, 'warmup')
            return  # outputs frozen at defaults during warmup

        # ── ACTIVE PHASE ───────────────────────────────────────────────────

        # Post-warmup baseline recalibration.
        # σ* is not set during warmup (r_l = 1.0 → var_r ≈ 0 → D_base hits floor).
        # σ* is only set after POST_CALIB = max(50, Tw//10) active steps.
        # Recalibration window must therefore extend well beyond POST_CALIB.
        # We use 2× steps_per_epoch (≈2 full epochs of active data) starting
        # AFTER the first epoch of active training (to let σ* stabilise first).
        # During recalibration TCI output is frozen at 0.0 so the EMA is clean.
        post_warmup = self.current_step - self.warmup_steps
        recalib_start = self.steps_per_epoch       # wait 1 active epoch for σ* to set
        recalib_end   = recalib_start + 2 * self.steps_per_epoch   # accumulate 2 epochs
        in_recalib = (self.var_r_baseline <= BASELINE_MIN * 1.01
                      and recalib_start <= post_warmup <= recalib_end)

        if self.var_r_baseline <= BASELINE_MIN * 1.01 and post_warmup <= recalib_end:
            if post_warmup >= recalib_start:
                # σ* should be set by now — accumulate real var_r
                self._warmup_accum += var_r
                self._warmup_count += 1
                new_base = self._warmup_accum / max(self._warmup_count, 1)
                if new_base > BASELINE_MIN * 1.01:
                    # Real signal found — lock in D_base
                    self.var_r_baseline = new_base
            # Freeze TCI at 0 during recalibration (EMA stays clean)
            if in_recalib:
                self._log(t, var_r, rho_t, 'active', 0.0)
                return

        # 1. Compute raw TCI — clamped to [0, TCI_MAX]
        denom   = 1.0 + max(0.0, rho_t)
        tci_raw = min(TCI_MAX, (var_r / self.var_r_baseline) / denom)

        # 2. EMA updates — decoupled timescales
        self.tci_fast = (self.fast_ema_alpha * tci_raw
                         + (1.0 - self.fast_ema_alpha) * self.tci_fast)
        self.tci_slow = (self.slow_ema_alpha * tci_raw
                         + (1.0 - self.slow_ema_alpha) * self.tci_slow)
        self._rho_ema = 0.05 * rho_t + 0.95 * self._rho_ema

        # 3. Update zeta from fast EMA (shadow mode: log only)
        if not self.shadow_mode:
            self.current_zeta = self._zeta_schedule(self.tci_fast)

        self._log(t, var_r, rho_t, 'active', tci_raw)

    def update_epoch(self) -> None:
        """
        Called at every epoch boundary.
        Updates drift_scale from slow EMA.
        Not called during warmup.
        """
        self.current_epoch += 1
        if self.warmup_complete and not self.shadow_mode:
            self.current_drift_scale = self._drift_schedule(self.tci_slow)

    def get_state(self) -> Dict[str, Any]:
        """Snapshot of current TCI state for logging."""
        return {
            'step':             self.current_step,
            'epoch':            self.current_epoch,
            'warmup_complete':  self.warmup_complete,
            'tci_fast':         round(self.tci_fast, 5),
            'tci_slow':         round(self.tci_slow, 5),
            'zeta':             round(self.current_zeta, 4),
            'drift_scale':      round(self.current_drift_scale, 4),
            'rho_ema':          round(self._rho_ema, 5),
            'var_r_baseline':   round(self.var_r_baseline, 6),
            'shadow_mode':      self.shadow_mode,
        }

    def export_csv(self, path: str) -> None:
        """Write full history to CSV. Most useful after shadow-mode runs."""
        if not self.history:
            print("  [TCI] No history to export.")
            return
        # Union all keys — warmup and active entries have different fields
        keys = list(dict.fromkeys(k for row in self.history for k in row.keys()))
        with open(path, 'w', newline='') as f:
            w = csv.DictWriter(f, fieldnames=keys, extrasaction='ignore')
            w.writeheader()
            for row in self.history:
                w.writerow({k: row.get(k, None) for k in keys})
        print(f"  [TCI] {len(self.history)} rows → {path}")

    def validate_separation(self, noise_pct: str) -> Dict[str, Any]:
        """
        Shadow-mode check: verifies TCI settles into the correct band for
        the given noise level once the initial training transient clears.

        TCI is expected to be high during the first ~30% of active training
        (σ* still calibrating, gradients volatile) then settle to a stable
        value reflecting the true noise regime. This check uses the SETTLED
        TCI — the mean over the final 40% of active-phase steps.

        Args:
            noise_pct: '20', '40', '60', or '80'

        Returns dict with keys: settled_tci, full_mean_tci, band, in_band
        """
        active = [h for h in self.history if h.get('phase') == 'active']
        if not active:
            return {'in_band': False, 'reason': 'No active-phase data in history'}

        # Full mean (informational — inflated by early transient)
        full_mean = sum(h['tci_fast'] for h in active) / len(active)

        # Settled mean — final 40% of active steps (after transient clears)
        # Use final 20% of active steps (min 100 entries) — ensures post-transient only
        settle_start = max(len(active) - 100, int(len(active) * 0.80))
        settled = active[settle_start:]
        settled_tci = sum(h['tci_fast'] for h in settled) / len(settled)

        # Three-regime TCI behaviour (empirically validated, shadow runs):
        #
        #  REGIME 1 — Clean / low noise (≤20%):
        #    Layers coordinate descent → D_t tight → TCI settles LOW (~0.07)
        #
        #  REGIME 2 — Moderate noise (30–50%):
        #    Early layers learn genuine features, output layer fits noise →
        #    inter-layer tension → D_t grows → TCI settles MEDIUM (~0.26)
        #
        #  REGIME 3 — Extreme noise (≥70%):
        #    Model cannot learn at all — uniform chaos across all layers →
        #    D_t → 0 (no differential signal), ρ_t → 0 (gradient-drift collapses)
        #    → TCI → 0. NOT a failure — correct behaviour under total noise saturation.
        #
        # NOTE: The naive assumption was TCI↑ as noise↑. The reality is non-monotonic:
        #       it peaks in the moderate regime then collapses back to zero at extremes.
        bands = {
            '20': (0.00, 0.20),   # observed 0.066 — coordinated descent
            '40': (0.10, 0.50),   # observed 0.260 — inter-layer tension
            '60': (0.00, 0.60),   # unvalidated — wide band until empirical data
            '80': (0.00, 0.05),   # observed 0.000 — flatline regime, uniform chaos
        }
        key = noise_pct.replace('%', '').strip()
        if key not in bands:
            return {
                'in_band':     True,
                'settled_tci': round(settled_tci, 4),
                'full_mean':   round(full_mean, 4),
                'note':        f'No reference band defined for {noise_pct}% noise',
            }

        lo, hi = bands[key]
        in_band = lo <= settled_tci <= hi
        return {
            'in_band':     in_band,
            'noise':       f'{key}% noise',
            'settled_tci': round(settled_tci, 4),
            'full_mean':   round(full_mean, 4),
            'band':        f'{lo:.2f} – {hi:.2f}',
            'note':        ('✅ settled TCI in band' if in_band
                            else f'⚠️  settled TCI {settled_tci:.3f} outside band {lo:.2f}–{hi:.2f}'),
        }

    # ── CONTROL LAWS ───────────────────────────────────────────────────────

    def _zeta_schedule(self, tci: float) -> float:
        """
        Sigmoid IEC coupling schedule: TCI → zeta.

            zeta(t) = zeta_max * sigmoid(-sigmoid_scale * (TCI_fast - 0.5))

        Calibration (sigmoid_scale = 6.0):
            TCI = 0.10  →  zeta ≈ 1.83  (IEC ≈ on,  20% noise)
            TCI = 0.50  →  zeta = 1.00  (IEC half,  40% noise, inflection)
            TCI = 1.00  →  zeta ≈ 0.09  (IEC ≈ off, 80% noise)
        """
        # Clamp exponent to prevent float overflow
        x = self.sigmoid_scale * (tci - 0.5)
        x = max(-500.0, min(500.0, x))
        sig = 1.0 / (1.0 + math.exp(x))
        return max(0.0, min(self.zeta_max, self.zeta_max * sig))

    def _drift_schedule(self, tci: float) -> float:
        """
        Linear drift amplification: high noise → more OU momentum.

            drift_scale(t) = 1 + min(1, TCI_slow)

        Range: [1.0, drift_scale_max].
        Updated on epoch boundary only to avoid drift → TCI feedback loop.
        """
        frac = min(1.0, max(0.0, tci))
        return 1.0 + frac * (self.drift_scale_max - 1.0)

    # ── INTERNAL ───────────────────────────────────────────────────────────

    def _log(self, t: int, var_r: float, rho_t: float,
             phase: str, tci_raw: float = 0.0) -> None:
        if t % self.log_every == 0:
            entry: Dict[str, Any] = {
                'step':        t,
                'epoch':       self.current_epoch,
                'phase':       phase,
                'tci_fast':    round(self.tci_fast, 5),
                'tci_slow':    round(self.tci_slow, 5),
                'zeta':        round(self.current_zeta, 4),
                'drift_scale': round(self.current_drift_scale, 4),
                'var_r':       round(var_r, 6),
                'rho_t':       round(rho_t, 5),
                'baseline':    round(self.var_r_baseline, 6),
            }
            if phase == 'active':
                entry['tci_raw'] = round(tci_raw, 5)
                entry['rho_ema'] = round(self._rho_ema, 5)
            self.history.append(entry)


# ── HELPER: compute rho_t inside EPTOv5.step ──────────────────────────────

def compute_rho_t(param_groups: list) -> float:
    """
    Compute cosine similarity of current gradients vs OU drift accumulators.

    rho_t = <g_flat, p_flat> / (||g_flat|| * ||p_flat||)

    Call AFTER the drift update inside Pass 2 (so p_drift has been updated
    with the current gradient, but we use the pre-update p from the previous
    step — i.e. call before torch._foreach_add_ updates p_drift).

    NOTE: _p_drift is stored in param_groups[i]['_p_drift'], NOT in
          optimizer.state[param] — this is intentional (it is a group-level
          running buffer, not a per-parameter quantity).

    Returns float in [-1, 1].  Returns 0.0 if drift not yet initialised.
    """
    g_parts: list = []
    p_parts: list = []

    for group in param_groups:
        p_drift_list = group.get('_p_drift')
        if p_drift_list is None:
            continue
        active = [p for p in group['params']
                  if p.requires_grad and p.grad is not None]
        for p, pd in zip(active, p_drift_list):
            g_parts.append(p.grad.float().flatten())
            p_parts.append(pd.float().flatten())

    if not g_parts:
        return 0.0

    g_flat = torch.cat(g_parts)
    p_flat = torch.cat(p_parts)

    g_norm = g_flat.norm()
    p_norm = p_flat.norm()

    if g_norm < 1e-12 or p_norm < 1e-12:
        return 0.0

    return float(
        F.cosine_similarity(g_flat.unsqueeze(0), p_flat.unsqueeze(0)).item()
    )
