"""
thermoclaw.optimizers.epto_auto
=================================
Single entry point for all EPTO optimizer variants.

Detects model architecture and auto-configures the correct EPTO variant
with validated hyperparameters. No auto-install side effects.

Usage::

    from thermoclaw.optimizers import auto

    optimizer = auto(model, steps_per_epoch=100, total_steps=10000)

    # Transformer → EPTOTransformer v6
    # CNN / MLP / RNN → EPTOv5 v5.4
"""

import torch

from .epto import EPTOv5
from .epto_transformer import EPTOTransformer
from thermoclaw.layer_utils import make_param_groups


def _detect_architecture(model: torch.nn.Module) -> dict:
    """Detect model architecture and return EPTO hyperparameter config."""
    module_names = ' '.join(n.lower() for n, _ in model.named_modules())
    n_params     = sum(p.numel() for p in model.parameters())

    ATTN_KW  = frozenset(['attention', 'attn', 'self_attn', 'multihead', 'gpt',
                          'bert', 'llama', 'mistral', 'falcon', 'transformer'])
    CONV_KW  = frozenset(['conv', 'convolution', 'depthwise', 'pointwise'])
    RNN_KW   = frozenset(['lstm', 'gru', 'rnn', 'recurrent'])

    has_attention = any(k in module_names for k in ATTN_KW)
    has_conv      = any(k in module_names for k in CONV_KW)
    has_rnn       = any(k in module_names for k in RNN_KW)

    if has_attention:
        if n_params < 2e9:
            return dict(variant='transformer_small', eta_max=1e-2, eta_min=1e-7,
                        eta0=1e-5, adapt_rate=0.2, alpha=1.1,
                        description=f'Small Transformer ({n_params/1e6:.0f}M)')
        elif n_params < 10e9:
            return dict(variant='transformer_large', eta_max=5e-3, eta_min=1e-7,
                        eta0=1e-5, adapt_rate=0.1, alpha=1.05,
                        description=f'Large Transformer ({n_params/1e9:.1f}B)')
        else:
            return dict(variant='transformer_xl', eta_max=1e-3, eta_min=1e-8,
                        eta0=1e-5, adapt_rate=0.05, alpha=1.02,
                        description=f'XL Transformer ({n_params/1e9:.1f}B)')
    elif has_rnn:
        return dict(variant='rnn', eta_max=1e-3, eta_min=1e-7,
                    eta0=1e-4, adapt_rate=0.005, alpha=1.2,
                    description=f'RNN ({n_params/1e6:.0f}M)')
    elif has_conv:
        if   n_params < 1e6:   alpha, eta_max = 5.0, 3e-3
        elif n_params < 10e6:  alpha, eta_max = 2.0, 3e-3
        elif n_params < 50e6:  alpha, eta_max = 1.2, 3e-3
        elif n_params < 200e6: alpha, eta_max = 1.1, 1e-3
        else:                  alpha, eta_max = 1.05, 5e-4
        return dict(variant='cnn', eta_max=eta_max, eta_min=1e-7,
                    eta0=eta_max/3, adapt_rate=0.01, alpha=alpha,
                    description=f'CNN ({n_params/1e6:.1f}M)')
    else:
        return dict(variant='mlp', eta_max=1e-3, eta_min=1e-7,
                    eta0=1e-4, adapt_rate=0.01, alpha=2.0,
                    description=f'MLP ({n_params/1e6:.2f}M)')


def auto(
    model:            torch.nn.Module,
    lr:               float = None,   # alias for eta_max — PyTorch convention
    steps_per_epoch:  int   = 100,
    total_steps:      int   = None,
    epochs:           int   = None,
    warmup_epochs:    int   = 2,
    eta_max:          float = None,
    eta_min:          float = None,
    alpha:            float = None,
    weight_decay:     float = 0.1,
    iec_zeta:         float = 2.0,
    verbose:          bool  = True,
    warmup_steps:     int   = None,
    adapt_rate:       float = None,
    adaptive:         bool  = True,
    shadow_mode:      bool  = False,
    zeta_max:         float = 2.0,
    drift_scale_max:  float = 2.0,
    tau_tokens:       float = None,
    tokens_per_step:  int   = None,
    sigma_ema_mom:    float = None,
    fim_window:       int   = None,
    fim_eps:          float = None,
    fim_k:            int   = None,
    post_warmup_min:  int   = None,
    type_calib_min:   int   = None,
    disable_kappa:    bool  = False,
    kappa_mode:       str   = 'heuristic',
    use_scalar_v:     bool  = False,
) -> torch.optim.Optimizer:
    """
    Auto-configure EPTO for any model architecture.

    Args:
        model:           Your PyTorch model (any architecture)
        steps_per_epoch: Number of optimizer steps per epoch
        total_steps:     Total training steps (or set epochs)
        epochs:          Total epochs (used if total_steps not set)
        warmup_epochs:   Warmup epochs (default 2)
        eta_max:         Override maximum learning rate
        eta_min:         Override minimum learning rate
        alpha:           Override alpha (entropy production ceiling)
        weight_decay:    Weight decay (default 0.1)
        use_scalar_v:    Use scalar-v (EPTO_SCALAR) instead of per-element
                         preconditioning. Transformer variant only.
        verbose:         Print detection info

    Returns:
        Configured EPTO optimizer:
        - EPTOTransformer v6 for transformer architectures
        - EPTOv5 v5.4 for CNN / MLP / RNN

    Examples::

        # Transformer (auto-detects, returns EPTOTransformer)
        model = GPT2LMHeadModel(config)
        opt   = auto(model, steps_per_epoch=584, epochs=10)

        # CNN (auto-detects, returns EPTOv5)
        model = WideResNet28_10()
        opt   = auto(model, steps_per_epoch=97, epochs=100)

        # Scalar-v ablation (EPTO_SCALAR)
        opt   = auto(model, steps_per_epoch=584, epochs=10, use_scalar_v=True)
    """
    if total_steps is None:
        if epochs is not None:
            total_steps = epochs * steps_per_epoch
        else:
            total_steps = 100 * steps_per_epoch

    if warmup_steps is None:
        warmup_steps = warmup_epochs * steps_per_epoch
    warmup_steps = min(warmup_steps, max(500, total_steps // 10))
    warmup_steps = min(warmup_steps, total_steps // 3)

    cfg = _detect_architecture(model)

    # lr= is the friendly alias; eta_max= takes precedence if both supplied
    if lr is not None and eta_max is None:
        eta_max = lr
    _eta_max    = eta_max    if eta_max    is not None else cfg['eta_max']
    _eta_min    = eta_min    if eta_min    is not None else cfg['eta_min']
    _alpha      = alpha      if alpha      is not None else cfg['alpha']
    _adapt_rate = adapt_rate if adapt_rate is not None else cfg['adapt_rate']
    _eta0       = cfg['eta0']
    variant     = cfg['variant']

    if verbose:
        print(f"  [EPTO Auto-Detect]")
        print(f"  Architecture : {cfg['description']}")
        print(f"  Variant      : {variant}")
        print(f"  eta_max      : {_eta_max:.1e}")
        print(f"  weight_decay : {weight_decay}")
        print(f"  Total steps  : {total_steps}")
        print(f"  Warmup steps : {warmup_steps}")

    # Build per-layer param groups
    seen: set = set()
    groups = []
    base_cfg: dict = {}  # populated per variant below

    def _make_groups(base: dict) -> list:
        nonlocal seen
        if hasattr(model, 'named_layer_groups'):
            gs = []
            for name, params in model.named_layer_groups().items():
                deduped = [p for p in params if id(p) not in seen]
                if not deduped:
                    continue
                for p in deduped:
                    seen.add(id(p))
                gs.append({'params': deduped, 'name': name, **base})
            leftover = [p for p in model.parameters() if id(p) not in seen]
            if leftover:
                gs.append({'params': leftover, 'name': 'misc', **base})
            return gs
        else:
            gs = []
            for name, module in model.named_modules():
                params = [p for p in module.parameters(recurse=False)
                          if id(p) not in seen]
                if not params:
                    continue
                for p in params:
                    seen.add(id(p))
                gs.append({'params': params, 'name': name or 'root', **base})
            leftover = [p for p in model.parameters() if id(p) not in seen]
            if leftover:
                gs.append({'params': leftover, 'name': 'misc', **base})
            return gs

    if variant in ('transformer_small', 'transformer_large', 'transformer_xl'):
        active_steps = total_steps - warmup_steps
        _pwm = post_warmup_min if post_warmup_min is not None else 200
        _pwm = min(_pwm, max(20, active_steps // 5))
        _tcm = type_calib_min if type_calib_min is not None else 200
        _tcm = min(_tcm, max(20, active_steps // 5))

        base = dict(
            eta0=_eta0, alpha=_alpha,
            warmup_steps=warmup_steps, total_steps=total_steps,
            eta_min=_eta_min, eta_max=_eta_max,
            eps2=1e-8, adapt_rate=_adapt_rate,
            iec_zeta=iec_zeta, ema_delta=0.002,
            weight_decay=weight_decay, corr_ema_rate=0.05,
            steps_per_epoch=steps_per_epoch,
        )
        if tau_tokens      is not None: base['tau_tokens']      = tau_tokens
        if tokens_per_step is not None: base['tokens_per_step'] = tokens_per_step
        if sigma_ema_mom   is not None: base['sigma_ema_mom']   = sigma_ema_mom
        if fim_window      is not None: base['fim_window']       = fim_window
        if fim_eps         is not None: base['fim_eps']          = fim_eps
        if fim_k           is not None: base['fim_k']            = fim_k
        base['post_warmup_min'] = _pwm
        base['type_calib_min']  = _tcm

        groups = _make_groups(base)
        optimizer = EPTOTransformer(
            groups,
            post_warmup_min=_pwm, type_calib_min=_tcm,
            disable_kappa=disable_kappa, kappa_mode=kappa_mode,
            use_scalar_v=use_scalar_v,
        )
        if verbose:
            scalar_str = ' (scalar-v / EPTO_SCALAR)' if use_scalar_v else ''
            print(f"  Optimizer    : EPTOTransformer v6{scalar_str}")

    else:
        base = dict(
            eta0=_eta0, alpha=_alpha,
            warmup_steps=warmup_steps, total_steps=total_steps,
            eta_min=_eta_min, eta_max=_eta_max,
            eps2=1e-8, adapt_rate=_adapt_rate,
            lpm_gamma=1.0, iec_zeta=iec_zeta,
            ema_delta=0.002, weight_decay=weight_decay,
            steps_per_epoch=steps_per_epoch,
        )
        groups = _make_groups(base)
        optimizer = EPTOv5(
            groups,
            adaptive=adaptive, shadow_mode=shadow_mode,
            warmup_epochs=warmup_epochs, steps_per_epoch=steps_per_epoch,
            epochs=epochs or (total_steps // steps_per_epoch),
            zeta_max=zeta_max, drift_scale_max=drift_scale_max,
            tci_verbose=verbose,
        )
        mode_str = 'shadow' if shadow_mode else ('adaptive' if adaptive else 'static')
        if verbose:
            print(f"  Optimizer    : EPTOv5 v5.4 ({mode_str} TCI)")

    if verbose:
        n_groups = len(optimizer.param_groups)
        n_params = sum(p.numel() for g in optimizer.param_groups for p in g['params'])
        print(f"  Param groups : {n_groups}")
        print(f"  Total params : {n_params:,}")
        print()

    return optimizer
