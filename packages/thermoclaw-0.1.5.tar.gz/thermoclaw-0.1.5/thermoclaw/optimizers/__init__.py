"""
thermoclaw.optimizers
======================
EPTO optimizer variants.

    EPTOTransformer — transformer-specific EPTO v6 (per-element or scalar-v)
    EPTOv5          — CNN/MLP/RNN EPTO v5.4 with TCI adaptive control
    TCIController   — Thermodynamic Coherence Index (noise estimator)
    auto()          — one-line optimizer for any architecture

Quick start::

    from thermoclaw.optimizers import auto

    optimizer = auto(model, steps_per_epoch=100, total_steps=10000)

EPTO_SCALAR (scalar-v ablation)::

    from thermoclaw.optimizers import auto
    optimizer = auto(model, steps_per_epoch=100, total_steps=10000,
                     use_scalar_v=True)

    # or directly:
    from thermoclaw.optimizers import EPTOTransformer
    from thermoclaw import make_param_groups
    groups = make_param_groups(model, lr=3e-4, weight_decay=0.1)
    optimizer = EPTOTransformer(groups, use_scalar_v=True,
                                warmup_steps=500, total_steps=10000)
"""

from .epto_transformer import EPTOTransformer
from .epto import EPTOv5, make_epto_param_groups
from .tci import TCIController, compute_rho_t
from .epto_auto import auto

__all__ = [
    "EPTOTransformer",
    "EPTOv5",
    "TCIController",
    "compute_rho_t",
    "make_epto_param_groups",
    "auto",
]
