"""
thermoclaw.diagnose
====================
High-level diagnostic API — the one-call interface.

``diagnose(observer)`` or ``diagnose(observer, splitter)`` returns a
:class:`DiagnosticReport` with human-readable findings and confidence-scored
recommendations.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

import numpy as np

from thermoclaw.observer import Observer
from thermoclaw.entropy_split import EntropySplit
from thermoclaw.collapse_detector import CollapseDetector


@dataclass
class DiagnosticReport:
    """Structured diagnostic output."""
    summary: str
    healthy: bool
    equilibrium_fraction: float
    equilibrium_layers: List[str]
    non_equilibrium_layers: List[str]
    entropy_split_available: bool
    worst_R_ie_layers: List[Dict[str, Any]]
    recommendations: List[str]
    raw_stats: Dict[str, Any]

    def __str__(self) -> str:
        lines = [self.summary]
        if self.recommendations:
            lines.append("")
            lines.append("Recommendations:")
            for r in self.recommendations:
                lines.append(f"  • {r}")
        if self.healthy:
            lines.append("")
            lines.append("Status: HEALTHY")
        return "\n".join(lines)


def diagnose(
    observer: Observer,
    splitter: Optional[EntropySplit] = None,
    collapse_detector: Optional[CollapseDetector] = None,
    equilibrium_band: float = 0.15,
) -> DiagnosticReport:
    """Produce a diagnostic report from observer (and optional entropy split).

    Parameters
    ----------
    observer : Observer
        Must have at least some step_history.
    splitter : EntropySplit, optional
        If provided, includes d_iS/d_eS analysis and recommendations.
    equilibrium_band : float
        Layers with r_l in [1-band, 1+band] are at equilibrium.
    """
    if not observer.step_history:
        return DiagnosticReport(
            summary="[Thermoclaw] No data collected yet. Run training steps first.",
            healthy=False,
            equilibrium_fraction=0.0,
            equilibrium_layers=[],
            non_equilibrium_layers=[],
            entropy_split_available=False,
            worst_R_ie_layers=[],
            recommendations=[],
            raw_stats={},
        )

    # ── Equilibrium analysis from observer ────────────────────────────────
    # Use last 20% of history for stability
    n = len(observer.step_history)
    tail = observer.step_history[max(0, n - n // 5):]

    # Average r per layer over tail period
    layer_r_avg: Dict[str, List[float]] = {}
    for h in tail:
        for ld in h.get('layers', []):
            layer_r_avg.setdefault(ld['name'], []).append(ld['r'])

    eq_layers = []
    non_eq_layers = []
    for name, r_vals in layer_r_avg.items():
        mean_r = float(np.mean(r_vals))
        if abs(mean_r - 1.0) <= equilibrium_band:
            eq_layers.append(name)
        else:
            non_eq_layers.append(name)

    total_layers = len(eq_layers) + len(non_eq_layers)
    eq_frac = len(eq_layers) / total_layers if total_layers > 0 else 0.0

    # Network-wide stats
    last_snap = observer.step_history[-1]
    mean_D = float(np.mean([h['D'] for h in tail]))
    mean_rho = float(np.mean([h['rho_mean'] for h in tail]))

    summary_lines = [
        f"Thermoclaw Diagnostic — {observer.optimizer_name} — "
        f"{observer.global_step} steps",
        f"  Equilibrium: {len(eq_layers)}/{total_layers} layers "
        f"({eq_frac:.0%})",
        f"  Dispersion D: {mean_D:.4f}",
        f"  Gradient alignment ρ: {mean_rho:.3f}",
        f"  Parameter distance E: {last_snap['E_param_dist']:.4f}",
    ]

    recommendations = []

    # ── Observer-only recommendations ─────────────────────────────────────
    if eq_frac < 0.3:
        recommendations.append(
            "[HIGH] Less than 30% of layers at equilibrium. Training may be "
            "unstable or lr may be too high."
        )
    if mean_D > 1.0:
        recommendations.append(
            f"[MEDIUM] High inter-layer dispersion (D={mean_D:.3f}). "
            "Some layers are over/under-trained relative to others."
        )
    if mean_rho < -0.1:
        recommendations.append(
            "[MEDIUM] Negative gradient alignment suggests oscillation. "
            "Consider reducing lr or increasing momentum."
        )

    # ── Sigma trend analysis (detect lr too high / divergence) ────────────
    if len(observer.step_history) >= 20:
        n_hist = len(observer.step_history)
        early = observer.step_history[:n_hist // 4]
        late = observer.step_history[3 * n_hist // 4:]

        def _mean_sigma(entries):
            all_s = [ld['sigma_ema'] for h in entries
                     for ld in h.get('layers', [])]
            return float(np.mean(all_s)) if all_s else 0.0

        s_early = _mean_sigma(early)
        s_late = _mean_sigma(late)
        if s_early > 1e-20 and s_late / s_early > 5.0:
            recommendations.append(
                f"[HIGH] Entropy production σ grew {s_late / s_early:.0f}× from "
                f"early to late training. lr may be too high or training is "
                f"diverging."
            )

    # ── Entropy split analysis ────────────────────────────────────────────
    worst_R_ie: List[Dict[str, Any]] = []
    entropy_split_available = splitter is not None and len(splitter.step_history) > 0

    if entropy_split_available:
        report_text = splitter.report()
        summary_lines.append("")
        summary_lines.append(report_text)

        # Integrate structured recommendations from entropy split
        es_recs = splitter.get_recommendations()
        recommendations.extend(es_recs)

        # Network-wide R_ie check (lr too high → everything overheating)
        n_splits = len(splitter.step_history)
        tail_splits = splitter.step_history[max(0, n_splits - n_splits // 5):]
        if tail_splits:
            tail_R_median = float(np.median(
                [s.R_ie_median for s in tail_splits]
            ))
            if tail_R_median > 3.0:
                recommendations.append(
                    f"[HIGH] Network-wide entropy ratio R_ie = {tail_R_median:.1f}. "
                    f"The optimizer is producing {tail_R_median:.0f}× more "
                    f"dissipation than learning. This often indicates lr is too "
                    f"high — consider reducing by "
                    f"{max(2, int(tail_R_median))}×."
                )

        # Extract worst layers for structured output
        from collections import defaultdict
        layer_R: Dict[str, List[float]] = defaultdict(list)
        layer_lt: Dict[str, str] = {}
        for snap in splitter.step_history:
            for ls in snap.layers:
                layer_R[ls.name].append(ls.R_ie)
                layer_lt[ls.name] = ls.ltype

        for name in sorted(layer_R, key=lambda n: np.mean(layer_R[n]),
                           reverse=True)[:10]:
            worst_R_ie.append({
                'name': name,
                'ltype': layer_lt.get(name, 'generic'),
                'mean_R_ie': float(np.mean(layer_R[name])),
            })

    # ── Collapse detector (weight decay, separate diagnostic) ───────────
    if collapse_detector is not None:
        wd_recs = collapse_detector.get_recommendations()
        recommendations.extend(wd_recs)

    # ── Healthy verdict ───────────────────────────────────────────────────
    healthy = len(recommendations) == 0
    if healthy:
        summary_lines.append("")
        summary_lines.append(
            "✓ Training appears thermodynamically healthy. "
            "No actionable issues detected."
        )

    return DiagnosticReport(
        summary="\n".join(summary_lines),
        healthy=healthy,
        equilibrium_fraction=eq_frac,
        equilibrium_layers=eq_layers,
        non_equilibrium_layers=non_eq_layers,
        entropy_split_available=entropy_split_available,
        worst_R_ie_layers=worst_R_ie,
        recommendations=recommendations,
        raw_stats={
            'mean_D': mean_D,
            'mean_rho': mean_rho,
            'E_param_dist': last_snap['E_param_dist'],
            'total_steps': observer.global_step,
        },
    )
