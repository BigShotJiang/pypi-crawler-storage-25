"""
thermoclaw.constants
====================
Named constants and keyword lists.
"""

import re

# ── Layer type detection keywords ──────────────────────────────────────────
LAYER_TYPE_EMBEDDING = frozenset([
    'embed', 'wte', 'wpe', 'tok_emb', 'word_emb', 'position_emb',
])
LAYER_TYPE_NORM = frozenset([
    'ln_', 'layernorm', 'layer_norm', 'rmsnorm', 'groupnorm',
    'norm', 'ln1', 'ln2', 'ln_f', 'pre_norm', 'post_norm',
])
LAYER_TYPE_ATTN = frozenset([
    'attn', 'attention', 'self_attn', 'multihead', 'q_proj', 'k_proj', 'v_proj',
    'c_attn', 'o_proj', 'out_proj', 'qkv',
])
LAYER_TYPE_MLP = frozenset([
    'mlp', 'ffn', 'fc1', 'fc2', 'c_fc', 'c_proj', 'gate_proj', 'up_proj', 'down_proj',
    'feed_forward', 'dense', 'intermediate', 'w1', 'w2', 'w3',
])
LAYER_TYPE_HEAD = frozenset([
    'lm_head', 'classifier', 'head', 'embed_out', 'output',
])

# ── Architecture detection keywords ───────────────────────────────────────
ARCH_ATTENTION = frozenset([
    'attention', 'attn', 'self_attn', 'multihead', 'multiheadattn',
    'crossattention', 'gpt', 'bert', 'llama', 'mistral', 'falcon',
    'mamba', 'transformer', 'causalselfattn',
])
ARCH_CONV = frozenset([
    'conv', 'convolution', 'depthwise', 'pointwise',
])
ARCH_RNN = frozenset([
    'lstm', 'gru', 'rnn', 'recurrent',
])
ARCH_EMBEDDING = frozenset([
    'embedding', 'embed', 'token',
])

# ── Observer defaults ──────────────────────────────────────────────────────
DEFAULT_ALPHA = 1.2
DEFAULT_SIGMA_WINDOW = 200
DEFAULT_SIGMA_CALIB_START = 200
DEFAULT_EMA_SPAN = 100

# ── EntropySplit defaults ──────────────────────────────────────────────────
WD_ENTROPY_LABEL = "weight_decay"
LR_ENTROPY_LABEL = "lr_gradient"
MOMENTUM_ENTROPY_LABEL = "momentum_friction"
NOISE_ENTROPY_LABEL = "stochastic_noise"

# ── Safe package install regex ─────────────────────────────────────────────
SAFE_PACKAGE_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]*(?:\[.*\])?(?:[><=!~]+[A-Za-z0-9.*]+)?$")
