"""
thermoclaw.integrations.huggingface
====================================
HuggingFace Trainer callback — free tier, distribution channel.

Drop one line into any HuggingFace training script::

    from thermoclaw.integrations.huggingface import ThermoclawCallback

    trainer = Trainer(
        model=model,
        args=training_args,
        callbacks=[ThermoclawCallback()],  # ← that's it
    )
    trainer.train()

After training, ``trainer.thermoclaw_report`` contains the diagnostic report.
The callback logs thermodynamic quantities to the trainer's logger (WandB,
TensorBoard, etc.) automatically.
"""

from __future__ import annotations

from typing import Any, Optional

try:
    from transformers import TrainerCallback, TrainerControl, TrainerState
    from transformers import TrainingArguments
    HAS_TRANSFORMERS = True
except ImportError:
    HAS_TRANSFORMERS = False


if HAS_TRANSFORMERS:
    class ThermoclawCallback(TrainerCallback):
        """HuggingFace Trainer callback for thermodynamic monitoring.

        Parameters
        ----------
        log_every : int
            Record a thermodynamic snapshot every N steps (default 10).
        enable_entropy_split : bool
            Whether to compute d_iS/d_eS decomposition (default True).
        plot_on_end : bool
            Save dashboard PNG at end of training (default True).
        output_dir : str, optional
            Where to save plots/CSVs. Defaults to trainer's output_dir.
        """

        def __init__(
            self,
            log_every: int = 10,
            enable_entropy_split: bool = True,
            plot_on_end: bool = True,
            output_dir: Optional[str] = None,
        ):
            self.log_every = log_every
            self.enable_entropy_split = enable_entropy_split
            self.plot_on_end = plot_on_end
            self.output_dir = output_dir
            self._observer = None
            self._splitter = None
            self._model = None
            self._step_count = 0
            self._last_snap = None
            self._last_split = None

        def on_train_begin(self, args: TrainingArguments, state: TrainerState,
                           control: TrainerControl, model=None, optimizer=None,
                           **kwargs):
            if model is None:
                return

            import torch
            from thermoclaw.observer import Observer
            from thermoclaw.entropy_split import EntropySplit
            from thermoclaw.layer_utils import make_param_groups

            # HF Trainer wraps the optimizer in AcceleratedOptimizer and creates
            # coarse param groups with no layer names. Build a shadow optimizer
            # from named per-layer groups so Observer has full per-layer resolution.
            named_groups = make_param_groups(
                model,
                lr=args.learning_rate,
                weight_decay=args.weight_decay,
            )
            shadow_opt = torch.optim.AdamW(named_groups)

            self._observer = Observer(model, shadow_opt, log_every=self.log_every)

            if self.enable_entropy_split:
                self._splitter = EntropySplit(model, shadow_opt, self._observer)

            if self.output_dir is None:
                self.output_dir = args.output_dir

            # HF Trainer calls model.zero_grad() AFTER optimizer.step() and
            # BEFORE on_step_end — so Observer.step() in on_step_end sees only
            # zero gradients. Patch model.zero_grad to capture gradients first.
            _original_zero_grad = model.zero_grad
            _cb = self

            def _patched_zero_grad(set_to_none: bool = True) -> None:
                if _cb._observer is not None:
                    # Capture loss from the most recent trainer log entry
                    loss_val = None
                    if state.log_history:
                        loss_val = state.log_history[-1].get('loss')
                    snap = _cb._observer.step(loss=loss_val)
                    _cb._last_snap = snap
                    if _cb._splitter is not None:
                        _cb._last_split = _cb._splitter.step()
                    _cb._step_count += 1
                _original_zero_grad(set_to_none=set_to_none)

            model.zero_grad = _patched_zero_grad
            self._model = model  # keep ref so on_train_end can restore

        def on_step_end(self, args: TrainingArguments, state: TrainerState,
                        control: TrainerControl, model=None, optimizer=None,
                        **kwargs):
            if self._observer is None:
                return

            # Gradients already captured in patched model.zero_grad above.
            # Only log metrics here (no observer.step call needed).
            snap = getattr(self, '_last_snap', None)
            if snap is None:
                return

            # Log to trainer's logger every log_every steps
            if self._step_count % self.log_every == 0:
                logs = {
                    'thermoclaw/D': snap['D'],
                    'thermoclaw/rho': snap['rho_mean'],
                    'thermoclaw/R_median': snap['R_median'],
                    'thermoclaw/E_param_dist': snap['E_param_dist'],
                }

                last_split = getattr(self, '_last_split', None)
                if last_split is not None:
                    logs['thermoclaw/R_ie_median'] = last_split.R_ie_median
                    logs['thermoclaw/R_ie_max'] = last_split.R_ie_max
                    logs['thermoclaw/d_eS'] = last_split.total_d_eS
                    logs['thermoclaw/d_iS'] = last_split.total_d_iS

                # State log_history gets picked up by WandB/TB
                if hasattr(state, 'log_history'):
                    state.log_history.append(logs)

        def on_train_end(self, args: TrainingArguments, state: TrainerState,
                         control: TrainerControl, model=None, **kwargs):
            if self._observer is None:
                return

            import os
            out = self.output_dir or '.'

            # Save dashboard
            if self.plot_on_end:
                try:
                    path = os.path.join(out, 'thermoclaw_dashboard.png')
                    self._observer.plot_dashboard(save_path=path, show=False)
                except Exception:
                    pass

                if self._splitter is not None:
                    try:
                        path = os.path.join(out, 'thermoclaw_entropy_split.png')
                        self._splitter.plot_entropy_split(save_path=path, show=False)
                    except Exception:
                        pass

            # Save CSV
            try:
                self._observer.export_csv(os.path.join(out, 'thermoclaw_observer.csv'))
            except Exception:
                pass
            if self._splitter is not None:
                try:
                    self._splitter.export_csv(os.path.join(out, 'thermoclaw_entropy_split.csv'))
                except Exception:
                    pass

            # Generate and attach report
            from thermoclaw.diagnose import diagnose
            report = diagnose(self._observer, self._splitter)

            # Attach to trainer for programmatic access
            # Users can access via trainer.thermoclaw_report after training
            if hasattr(state, '_thermoclaw_report'):
                pass
            state._thermoclaw_report = report

            print(report)

        @property
        def observer(self):
            return self._observer

        @property
        def splitter(self):
            return self._splitter

else:
    class ThermoclawCallback:  # type: ignore[no-redef]
        """Stub when transformers not installed."""
        def __init__(self, *args, **kwargs):
            raise ImportError(
                "ThermoclawCallback requires the `transformers` package. "
                "Install with: pip install thermoclaw[hf]"
            )
