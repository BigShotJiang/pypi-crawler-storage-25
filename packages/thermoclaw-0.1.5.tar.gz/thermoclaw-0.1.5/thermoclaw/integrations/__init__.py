"""thermoclaw.integrations — Framework integration callbacks."""
