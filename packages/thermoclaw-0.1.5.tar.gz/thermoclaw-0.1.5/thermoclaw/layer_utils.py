"""
thermoclaw.layer_utils
======================
Layer type detection and param-group construction.
Optimizer-agnostic — works with any PyTorch model.
"""

from __future__ import annotations

from typing import Dict, List

import torch
import torch.nn as nn

from thermoclaw.constants import (
    LAYER_TYPE_EMBEDDING,
    LAYER_TYPE_NORM,
    LAYER_TYPE_ATTN,
    LAYER_TYPE_MLP,
    LAYER_TYPE_HEAD,
)


def detect_layer_type(name: str) -> str:
    """Infer functional layer type from a module/group name string.

    Returns one of: 'embedding', 'layernorm', 'attention', 'mlp',
    'lm_head', or 'generic'.
    """
    n = name.lower()
    if any(k in n for k in LAYER_TYPE_EMBEDDING):
        return 'embedding'
    if any(k in n for k in LAYER_TYPE_NORM):
        return 'layernorm'
    if any(k in n for k in LAYER_TYPE_ATTN):
        return 'attention'
    if any(k in n for k in LAYER_TYPE_MLP):
        return 'mlp'
    if any(k in n for k in LAYER_TYPE_HEAD):
        return 'lm_head'
    return 'generic'


def make_param_groups(model: nn.Module, **kwargs) -> List[Dict]:
    """Build one param group per named module that owns parameters directly.

    This gives Thermoclaw per-layer thermodynamic tracking (separate σ_l
    per group). Pass the result to your optimizer::

        groups = make_param_groups(model, lr=3e-4, weight_decay=0.01)
        optimizer = torch.optim.AdamW(groups)
        observer = thermoclaw.Observer(model, optimizer)
    """
    groups: List[Dict] = []
    seen: set = set()
    for name, module in model.named_modules():
        params = [p for p in module.parameters(recurse=False)
                  if id(p) not in seen]
        if params:
            for p in params:
                seen.add(id(p))
            groups.append({'params': params, 'name': name, **kwargs})
    return groups


def detect_architecture(model: nn.Module) -> str:
    """Detect model architecture family: 'transformer', 'cnn', 'rnn', or 'mlp'."""
    from thermoclaw.constants import ARCH_ATTENTION, ARCH_CONV, ARCH_RNN
    module_names = ' '.join(n.lower() for n, _ in model.named_modules())
    if any(k in module_names for k in ARCH_ATTENTION):
        return 'transformer'
    if any(k in module_names for k in ARCH_CONV):
        return 'cnn'
    if any(k in module_names for k in ARCH_RNN):
        return 'rnn'
    return 'mlp'
