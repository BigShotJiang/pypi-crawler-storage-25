"""
test_diagnostic_validation.py — The test that actually matters
================================================================

Four-arm blind diagnostic validation for Thermoclaw.

Each arm trains an identical MiniGPT architecture with identical data,
differing ONLY in optimizer hyperparameters. Thermoclaw observes all four
runs and must correctly diagnose the pathology (or lack thereof).

Arm 1: lr=3e-2 (deliberately too high)
  → Should flag entropy overproduction / divergence, recommend lr reduction.

Arm 2: wd=5.0 (extremely aggressive weight decay)
  → Should flag observable weight decay collapse, recommend reduction.

Arm 3: β₁=0.999 (over-damped momentum)
  → Should flag momentum friction / over-damped drift.

Arm 4: Well-configured baseline (lr=3e-4, wd=0.01, β₁=0.9)
  → Should give a clean bill of health. NO false positives.
  → This is the hardest and most important test.

Usage:
    pytest tests/test_diagnostic_validation.py -v
    python tests/test_diagnostic_validation.py          # Detailed output
"""

from __future__ import annotations

import math
import sys
import os
from collections import defaultdict
from typing import Dict, List, Optional, Tuple

import numpy as np
import pytest
import torch
import torch.nn as nn
import torch.nn.functional as F

# ── Ensure thermoclaw is importable ──────────────────────────────────────
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from thermoclaw import Observer, EntropySplit, CollapseDetector, diagnose, DiagnosticReport
from thermoclaw.layer_utils import make_param_groups


# ═══════════════════════════════════════════════════════════════════════════
# Mini GPT-2 model (realistic layer names for layer-type detection)
# ═══════════════════════════════════════════════════════════════════════════

VOCAB_SIZE = 500
D_MODEL = 64
N_HEAD = 4
N_LAYER = 4
MAX_SEQ = 32
BATCH_SIZE = 8
N_STEPS = 200


class Attention(nn.Module):
    def __init__(self, d_model: int, n_head: int):
        super().__init__()
        self.c_attn = nn.Linear(d_model, 3 * d_model)
        self.c_proj = nn.Linear(d_model, d_model)
        self.n_head = n_head
        self.head_dim = d_model // n_head

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        B, T, C = x.shape
        qkv = self.c_attn(x).reshape(B, T, 3, self.n_head, self.head_dim)
        q, k, v = qkv.unbind(2)
        q = q.transpose(1, 2)
        k = k.transpose(1, 2)
        v = v.transpose(1, 2)
        scale = self.head_dim ** -0.5
        attn = (q @ k.transpose(-2, -1)) * scale
        # Causal mask
        mask = torch.tril(torch.ones(T, T, device=x.device, dtype=torch.bool))
        attn = attn.masked_fill(~mask, float('-inf'))
        attn = F.softmax(attn, dim=-1)
        out = (attn @ v).transpose(1, 2).reshape(B, T, C)
        return self.c_proj(out)


class MLP(nn.Module):
    def __init__(self, d_model: int):
        super().__init__()
        self.c_fc = nn.Linear(d_model, 4 * d_model)
        self.c_proj = nn.Linear(4 * d_model, d_model)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.c_proj(F.gelu(self.c_fc(x)))


class Block(nn.Module):
    def __init__(self, d_model: int, n_head: int):
        super().__init__()
        self.ln_1 = nn.LayerNorm(d_model)
        self.attn = Attention(d_model, n_head)
        self.ln_2 = nn.LayerNorm(d_model)
        self.mlp = MLP(d_model)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = x + self.attn(self.ln_1(x))
        x = x + self.mlp(self.ln_2(x))
        return x


class MiniGPT(nn.Module):
    """Minimal GPT-2 with realistic layer names for Thermoclaw testing."""

    def __init__(
        self,
        vocab_size: int = VOCAB_SIZE,
        d_model: int = D_MODEL,
        n_head: int = N_HEAD,
        n_layer: int = N_LAYER,
        max_seq: int = MAX_SEQ,
    ):
        super().__init__()
        self.wte = nn.Embedding(vocab_size, d_model)
        self.wpe = nn.Embedding(max_seq, d_model)
        self.h = nn.ModuleList([Block(d_model, n_head) for _ in range(n_layer)])
        self.ln_f = nn.LayerNorm(d_model)
        self.lm_head = nn.Linear(d_model, vocab_size, bias=False)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        B, T = x.shape
        pos = torch.arange(T, device=x.device).unsqueeze(0)
        x = self.wte(x) + self.wpe(pos)
        for block in self.h:
            x = block(x)
        x = self.ln_f(x)
        return self.lm_head(x)


# ═══════════════════════════════════════════════════════════════════════════
# Shared data and training infrastructure
# ═══════════════════════════════════════════════════════════════════════════

def _make_data(n_seqs: int = 200, seq_len: int = MAX_SEQ,
               vocab_size: int = VOCAB_SIZE) -> torch.Tensor:
    """Fixed random dataset (same for all arms)."""
    gen = torch.Generator().manual_seed(12345)
    return torch.randint(0, vocab_size, (n_seqs, seq_len), generator=gen)


def _train_arm(
    lr: float,
    weight_decay: float,
    betas: Tuple[float, float] = (0.9, 0.999),
    n_steps: int = N_STEPS,
    data: Optional[torch.Tensor] = None,
    verbose: bool = False,
) -> Tuple[Observer, EntropySplit, DiagnosticReport, List[float]]:
    """Train one arm — returns (observer, splitter, report, losses)."""
    # Deterministic init
    torch.manual_seed(42)
    model = MiniGPT()
    if data is None:
        data = _make_data()

    groups = make_param_groups(model, lr=lr, weight_decay=weight_decay)
    optimizer = torch.optim.AdamW(groups, betas=betas)

    observer = Observer(model, optimizer, calib_start=20)
    splitter = EntropySplit(model, optimizer, observer)
    collapse = CollapseDetector(model, optimizer)
    criterion = nn.CrossEntropyLoss()

    losses = []
    for step in range(n_steps):
        idx = (step * BATCH_SIZE) % len(data)
        batch = data[idx: idx + BATCH_SIZE]
        if len(batch) < BATCH_SIZE:
            batch = data[:BATCH_SIZE]

        logits = model(batch)
        # Next-token prediction: predict token t+1 from position t
        loss = criterion(
            logits[:, :-1].reshape(-1, VOCAB_SIZE),
            batch[:, 1:].reshape(-1),
        )
        loss.backward()

        # Clip gradients to prevent NaN (lr-too-high arm needs this)
        torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=10.0)

        optimizer.step()
        snap = observer.step(loss=loss.item())
        split = splitter.step()
        collapse.step()
        optimizer.zero_grad()
        losses.append(loss.item())

        if verbose and (step + 1) % 50 == 0:
            print(f"  step {step + 1:>4d}  loss={loss.item():.3f}  "
                  f"R_ie_median={split.R_ie_median:.2f}  "
                  f"D={snap['D']:.4f}")

    report = diagnose(observer, splitter, collapse)
    return observer, splitter, report, losses


# ═══════════════════════════════════════════════════════════════════════════
# Tests
# ═══════════════════════════════════════════════════════════════════════════

@pytest.fixture(scope="module")
def shared_data():
    """Fixed data shared across all arms."""
    return _make_data()


@pytest.fixture(scope="module")
def arm1_result(shared_data):
    """Arm 1: lr=3e-2 (too high)."""
    return _train_arm(lr=3e-2, weight_decay=0.01, data=shared_data)


@pytest.fixture(scope="module")
def arm2_result(shared_data):
    """Arm 2: wd=5.0 (extremely aggressive — produces observable collapse)."""
    return _train_arm(lr=3e-4, weight_decay=5.0, data=shared_data)


@pytest.fixture(scope="module")
def arm3_result(shared_data):
    """Arm 3: β₁=0.999 (over-damped momentum)."""
    return _train_arm(lr=3e-4, weight_decay=0.01, betas=(0.999, 0.999),
                      data=shared_data)


@pytest.fixture(scope="module")
def arm4_result(shared_data):
    """Arm 4: Well-configured baseline."""
    return _train_arm(lr=3e-4, weight_decay=0.01, betas=(0.9, 0.999),
                      data=shared_data)


# ── Arm 1: lr too high ───────────────────────────────────────────────────

class TestArm1LrTooHigh:
    """lr=3e-2 should be flagged as problematic."""

    def test_not_healthy(self, arm1_result):
        _, _, report, _ = arm1_result
        assert not report.healthy, (
            f"lr=3e-2 should NOT be flagged as healthy.\n"
            f"Recommendations: {report.recommendations}"
        )

    def test_has_recommendations(self, arm1_result):
        _, _, report, _ = arm1_result
        assert len(report.recommendations) > 0, (
            "Should generate at least one recommendation for lr=3e-2"
        )

    def test_flags_lr_or_entropy_issue(self, arm1_result):
        _, _, report, _ = arm1_result
        keywords = ['lr', 'learning rate', 'entropy', 'diverg', 'unstable',
                     'too high', 'R_ie']
        all_recs = ' '.join(report.recommendations).lower()
        assert any(kw in all_recs for kw in keywords), (
            f"Should flag lr/entropy issue. Got: {report.recommendations}"
        )

    def test_worse_equilibrium_than_baseline(self, arm1_result, arm4_result):
        """Pathological arm should have worse equilibrium than healthy baseline."""
        _, _, report_bad, _ = arm1_result
        _, _, report_ok, _ = arm4_result
        assert report_bad.equilibrium_fraction < report_ok.equilibrium_fraction, (
            f"lr=3e-2 eq ({report_bad.equilibrium_fraction:.0%}) should be "
            f"worse than baseline ({report_ok.equilibrium_fraction:.0%})"
        )


# ── Arm 2: weight decay too aggressive ───────────────────────────────────

class TestArm2WdTooHigh:
    """wd=5.0 should be flagged as weight decay dominated."""

    def test_not_healthy(self, arm2_result):
        _, _, report, _ = arm2_result
        assert not report.healthy, (
            f"wd=5.0 should NOT be flagged as healthy.\n"
            f"Recommendations: {report.recommendations}"
        )

    def test_flags_weight_decay(self, arm2_result):
        _, _, report, _ = arm2_result
        all_recs = ' '.join(report.recommendations).lower()
        assert ('weight' in all_recs or 'decay' in all_recs
                or 'wd' in all_recs or 'collapse' in all_recs), (
            f"Should flag weight decay issue. Got: {report.recommendations}"
        )

    def test_wd_entropy_elevated(self, arm2_result, arm4_result):
        """wd=5.0 should show higher weight-decay entropy than baseline."""
        _, splitter_bad, _, _ = arm2_result
        _, splitter_ok, _, _ = arm4_result

        def _mean_wd_entropy(splitter):
            all_wd = [ls.d_iS_wd for s in splitter.step_history[-50:]
                      for ls in s.layers]
            return np.mean(all_wd) if all_wd else 0.0

        wd_bad = _mean_wd_entropy(splitter_bad)
        wd_ok = _mean_wd_entropy(splitter_ok)
        assert wd_bad > wd_ok * 3, (
            f"wd=5.0 d_iS_wd ({wd_bad:.4e}) should be >3× baseline "
            f"({wd_ok:.4e})"
        )


# ── Arm 3: momentum over-damped ──────────────────────────────────────────

class TestArm3MomentumOverdamped:
    """β₁=0.999 should show elevated dissipation from momentum friction."""

    def test_not_healthy_or_notes_momentum(self, arm3_result):
        """Should either flag as unhealthy or note momentum issues."""
        _, _, report, _ = arm3_result
        # β₁ is a subtle signal — check either unhealthy OR momentum mentioned
        if report.healthy:
            # If somehow healthy, this is acceptable IF momentum R_ie is
            # only slightly worse — but log a warning
            pytest.skip(
                "β₁=0.999 did not trigger flags. Signal may be too subtle "
                "for this model size / step count."
            )

    def test_worse_equilibrium_than_baseline(self, arm3_result, arm4_result):
        """β₁=0.999 should have worse equilibrium than baseline."""
        _, _, report_bad, _ = arm3_result
        _, _, report_ok, _ = arm4_result
        assert report_bad.equilibrium_fraction <= report_ok.equilibrium_fraction, (
            f"β₁=0.999 eq ({report_bad.equilibrium_fraction:.0%}) should be "
            f"\u2264 baseline ({report_ok.equilibrium_fraction:.0%})"
        )

    def test_slower_loss_than_baseline(self, arm3_result, arm4_result):
        """Over-damped momentum should learn slower than well-tuned baseline."""
        _, _, _, losses_bad = arm3_result
        _, _, _, losses_ok = arm4_result
        late_bad = float(np.mean(losses_bad[-20:]))
        late_ok = float(np.mean(losses_ok[-20:]))
        assert late_bad >= late_ok, (
            f"β₁=0.999 late loss ({late_bad:.3f}) should be \u2265 "
            f"baseline ({late_ok:.3f})"
        )


# ── Arm 4: Healthy baseline (THE MOST IMPORTANT TEST) ────────────────────

class TestArm4Healthy:
    """Well-configured baseline should get a clean bill of health."""

    def test_is_healthy(self, arm4_result):
        _, _, report, _ = arm4_result
        assert report.healthy, (
            f"Well-configured baseline should be healthy!\n"
            f"FALSE POSITIVE recommendations: {report.recommendations}\n"
            f"A tool that always finds something wrong is useless."
        )

    def test_no_high_severity_recommendations(self, arm4_result):
        _, _, report, _ = arm4_result
        high_recs = [r for r in report.recommendations if r.startswith('[HIGH]')]
        assert len(high_recs) == 0, (
            f"Healthy baseline should have no HIGH-severity flags.\n"
            f"Got: {high_recs}"
        )

    def test_loss_decreases(self, arm4_result):
        _, _, _, losses = arm4_result
        early_loss = np.mean(losses[:20])
        late_loss = np.mean(losses[-20:])
        assert late_loss < early_loss, (
            f"Healthy baseline loss should decrease: "
            f"early={early_loss:.3f} late={late_loss:.3f}"
        )

    def test_moderate_R_ie(self, arm4_result):
        """R_ie should be moderate — not flagged as problematic."""
        _, splitter, _, _ = arm4_result
        tail_R = np.median([s.R_ie_median for s in splitter.step_history[-50:]])
        # R_ie < 3.0 means the optimizer is not wasting most entropy
        assert tail_R < 3.0, (
            f"Healthy baseline R_ie={tail_R:.2f} should be < 3.0"
        )

    def test_entropy_split_not_critical(self, arm4_result):
        """Entropy split should say HEALTHY or BALANCED, not WARNING/CRITICAL."""
        _, splitter, _, _ = arm4_result
        report_text = splitter.report()
        assert 'CRITICAL' not in report_text, (
            f"Healthy baseline should not be CRITICAL:\n{report_text[:500]}"
        )


# ── Cross-arm comparisons ────────────────────────────────────────────────

class TestCrossArmComparisons:
    """Verify that pathological arms have worse diagnostics than baseline."""

    def test_healthy_arm_has_best_equilibrium(
        self, arm1_result, arm2_result, arm3_result, arm4_result
    ):
        """Baseline should have the highest equilibrium fraction."""
        def _eq(result):
            _, _, report, _ = result
            return report.equilibrium_fraction

        eq1 = _eq(arm1_result)
        eq2 = _eq(arm2_result)
        eq4 = _eq(arm4_result)

        assert eq4 >= max(eq1, eq2), (
            f"Healthy eq ({eq4:.0%}) should be ≥ lr-too-high ({eq1:.0%}) "
            f"and wd-too-high ({eq2:.0%})"
        )

    def test_only_healthy_arm_passes_health_check(
        self, arm1_result, arm2_result, arm4_result
    ):
        """At minimum, arms 1 and 2 should be unhealthy; arm 4 healthy."""
        _, _, r1, _ = arm1_result
        _, _, r2, _ = arm2_result
        _, _, r4, _ = arm4_result
        assert not r1.healthy, "lr=3e-2 should be unhealthy"
        assert not r2.healthy, "wd=5.0 should be unhealthy"
        assert r4.healthy, "baseline should be healthy"


# ═══════════════════════════════════════════════════════════════════════════
# Standalone runner with detailed output
# ═══════════════════════════════════════════════════════════════════════════

def _run_all_verbose():
    """Run all 4 arms with detailed diagnostic output."""
    data = _make_data()

    arms = [
        ("ARM 1: lr=3e-2 (too high)",
         dict(lr=3e-2, weight_decay=0.01)),
        ("ARM 2: wd=5.0 (too aggressive)",
         dict(lr=3e-4, weight_decay=5.0)),
        ("ARM 3: β₁=0.999 (over-damped)",
         dict(lr=3e-4, weight_decay=0.01, betas=(0.999, 0.999))),
        ("ARM 4: Baseline (should be healthy)",
         dict(lr=3e-4, weight_decay=0.01, betas=(0.9, 0.999))),
    ]

    results = []
    for label, kwargs in arms:
        print(f"\n{'=' * 72}")
        print(f"  {label}")
        print(f"{'=' * 72}")
        _, splitter, report, losses = _train_arm(
            **kwargs, data=data, verbose=True
        )
        results.append((label, splitter, report, losses))

        print(f"\n  Loss: {losses[0]:.3f} → {losses[-1]:.3f}")
        print(f"  Healthy: {report.healthy}")
        print(f"  Equilibrium: {report.equilibrium_fraction:.0%}")
        if report.recommendations:
            print("  Recommendations:")
            for r in report.recommendations:
                print(f"    • {r}")
        else:
            print("  ✓ No issues detected")
        print()

    # ── Summary ───────────────────────────────────────────────────────
    print(f"\n{'=' * 72}")
    print("  SUMMARY")
    print(f"{'=' * 72}")
    for label, splitter, report, losses in results:
        tail_R = np.median(
            [s.R_ie_median for s in splitter.step_history[-50:]]
        )
        status = "✓ HEALTHY" if report.healthy else "✗ FLAGGED"
        n_recs = len(report.recommendations)
        print(f"  {label:<45s} {status}  "
              f"R_ie={tail_R:.2f}  recs={n_recs}")

    # ── Verdict ───────────────────────────────────────────────────────
    _, _, r1, _ = results[0]
    _, _, r2, _ = results[1]
    _, _, r3, _ = results[2]
    _, _, r4, _ = results[3]

    passed = True
    if r1.healthy:
        print("\n  FAIL: lr=3e-2 was not flagged")
        passed = False
    if r2.healthy:
        print("\n  FAIL: wd=5.0 was not flagged")
        passed = False
    if not r4.healthy:
        print(f"\n  FAIL: Baseline has false positives: {r4.recommendations}")
        passed = False

    if passed:
        print(f"\n  {'=' * 68}")
        print(f"  ALL CRITICAL CHECKS PASSED.")
        print(f"  {'=' * 68}")
    else:
        print(f"\n  {'=' * 68}")
        print(f"  SOME CHECKS FAILED — see above.")
        print(f"  {'=' * 68}")
        sys.exit(1)


if __name__ == "__main__":
    _run_all_verbose()
