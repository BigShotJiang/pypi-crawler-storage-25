"""
Tests for Thermoclaw core modules.
"""

import math
import pytest
import torch
import torch.nn as nn
import numpy as np

from thermoclaw.observer import Observer
from thermoclaw.entropy_split import EntropySplit
from thermoclaw.diagnose import diagnose
from thermoclaw.scheduler import ThermoScheduler
from thermoclaw.layer_utils import detect_layer_type, make_param_groups, detect_architecture


# ── Fixtures ──────────────────────────────────────────────────────────────

class TinyMLP(nn.Module):
    def __init__(self):
        super().__init__()
        self.fc1 = nn.Linear(32, 64)
        self.fc2 = nn.Linear(64, 64)
        self.head = nn.Linear(64, 10)

    def forward(self, x):
        x = torch.relu(self.fc1(x))
        x = torch.relu(self.fc2(x))
        return self.head(x)


class TinyTransformer(nn.Module):
    def __init__(self):
        super().__init__()
        self.embed = nn.Embedding(100, 32)
        self.attn = nn.MultiheadAttention(32, 4, batch_first=True)
        self.ln1 = nn.LayerNorm(32)
        self.mlp = nn.Linear(32, 32)
        self.ln2 = nn.LayerNorm(32)
        self.lm_head = nn.Linear(32, 100)

    def forward(self, x):
        x = self.embed(x)
        a, _ = self.attn(x, x, x)
        x = self.ln1(x + a)
        x = self.ln2(x + self.mlp(x))
        return self.lm_head(x)


@pytest.fixture
def mlp_setup():
    model = TinyMLP()
    groups = make_param_groups(model, lr=1e-3, weight_decay=0.01)
    optimizer = torch.optim.AdamW(groups)
    return model, optimizer


@pytest.fixture
def transformer_setup():
    model = TinyTransformer()
    groups = make_param_groups(model, lr=3e-4, weight_decay=0.01)
    optimizer = torch.optim.AdamW(groups)
    return model, optimizer


def _train_steps(model, optimizer, n_steps=50, is_transformer=False):
    """Run n training steps with synthetic data."""
    criterion = nn.CrossEntropyLoss()
    for _ in range(n_steps):
        if is_transformer:
            x = torch.randint(0, 100, (4, 16))
            logits = model(x)
            loss = criterion(logits.view(-1, 100), x.view(-1))
        else:
            x = torch.randn(8, 32)
            logits = model(x)
            loss = criterion(logits, torch.randint(0, 10, (8,)))
        loss.backward()
        optimizer.step()
        optimizer.zero_grad()
    return loss.item()


# ── detect_layer_type ─────────────────────────────────────────────────────

class TestLayerUtils:
    def test_embedding(self):
        assert detect_layer_type('model.embed_tokens') == 'embedding'
        assert detect_layer_type('transformer.wte') == 'embedding'

    def test_layernorm(self):
        assert detect_layer_type('model.layers.0.ln_1') == 'layernorm'
        assert detect_layer_type('encoder.layer_norm') == 'layernorm'

    def test_attention(self):
        assert detect_layer_type('model.layers.5.self_attn.q_proj') == 'attention'
        assert detect_layer_type('transformer.h.0.attn.c_attn') == 'attention'

    def test_mlp(self):
        assert detect_layer_type('model.layers.0.mlp.gate_proj') == 'mlp'
        assert detect_layer_type('transformer.h.0.mlp.c_fc') == 'mlp'

    def test_head(self):
        assert detect_layer_type('lm_head') == 'lm_head'
        assert detect_layer_type('classifier') == 'lm_head'

    def test_generic(self):
        assert detect_layer_type('some_random_module') == 'generic'

    def test_make_param_groups(self):
        model = TinyMLP()
        groups = make_param_groups(model, lr=1e-3)
        assert len(groups) > 0
        assert all('name' in g for g in groups)
        total_params = sum(p.numel() for g in groups for p in g['params'])
        expected = sum(p.numel() for p in model.parameters())
        assert total_params == expected

    def test_detect_architecture_mlp(self):
        assert detect_architecture(TinyMLP()) == 'mlp'

    def test_detect_architecture_transformer(self):
        assert detect_architecture(TinyTransformer()) == 'transformer'


# ── Observer ──────────────────────────────────────────────────────────────

class TestObserver:
    def test_basic_creation(self, mlp_setup):
        model, optimizer = mlp_setup
        obs = Observer(model, optimizer)
        assert obs.optimizer_name == 'AdamW'
        assert obs.global_step == 0

    def test_step_records_history(self, mlp_setup):
        model, optimizer = mlp_setup
        obs = Observer(model, optimizer)
        criterion = nn.CrossEntropyLoss()

        for _ in range(10):
            x = torch.randn(4, 32)
            loss = criterion(model(x), torch.randint(0, 10, (4,)))
            loss.backward()
            optimizer.step()
            snap = obs.step(loss=loss.item())
            optimizer.zero_grad()

        assert obs.global_step == 10
        assert len(obs.step_history) == 10
        assert 'D' in obs.step_history[0]
        assert 'layers' in obs.step_history[0]
        assert obs.step_history[0]['layers'][0]['ltype'] is not None

    def test_sigma_is_positive(self, mlp_setup):
        model, optimizer = mlp_setup
        obs = Observer(model, optimizer)
        criterion = nn.CrossEntropyLoss()

        x = torch.randn(4, 32)
        loss = criterion(model(x), torch.randint(0, 10, (4,)))
        loss.backward()
        optimizer.step()
        snap = obs.step(loss=loss.item())

        for ld in snap['layers']:
            assert ld['sigma'] >= 0
            assert ld['sigma_ema'] >= 0

    def test_epoch_end(self, mlp_setup):
        model, optimizer = mlp_setup
        obs = Observer(model, optimizer)
        _train_steps(model, optimizer, n_steps=5)

        # Manually record a few steps
        criterion = nn.CrossEntropyLoss()
        for _ in range(5):
            x = torch.randn(4, 32)
            loss = criterion(model(x), torch.randint(0, 10, (4,)))
            loss.backward()
            optimizer.step()
            obs.step(loss=loss.item())
            optimizer.zero_grad()

        entry = obs.epoch_end(val_acc=0.85)
        assert 'mean_D' in entry
        assert entry['val_acc'] == 0.85

    def test_param_distance_increases(self, mlp_setup):
        model, optimizer = mlp_setup
        obs = Observer(model, optimizer)
        criterion = nn.CrossEntropyLoss()

        distances = []
        for _ in range(20):
            x = torch.randn(4, 32)
            loss = criterion(model(x), torch.randint(0, 10, (4,)))
            loss.backward()
            optimizer.step()
            snap = obs.step(loss=loss.item())
            distances.append(snap['E_param_dist'])
            optimizer.zero_grad()

        # Parameter distance should generally increase (model moving from init)
        assert distances[-1] > distances[0]

    def test_log_every(self, mlp_setup):
        model, optimizer = mlp_setup
        obs = Observer(model, optimizer, log_every=5)
        criterion = nn.CrossEntropyLoss()

        for _ in range(20):
            x = torch.randn(4, 32)
            loss = criterion(model(x), torch.randint(0, 10, (4,)))
            loss.backward()
            optimizer.step()
            obs.step(loss=loss.item())
            optimizer.zero_grad()

        assert len(obs.step_history) == 4  # 20 steps / log_every=5

    def test_export_csv(self, mlp_setup, tmp_path):
        model, optimizer = mlp_setup
        obs = Observer(model, optimizer)
        criterion = nn.CrossEntropyLoss()

        for _ in range(5):
            x = torch.randn(4, 32)
            loss = criterion(model(x), torch.randint(0, 10, (4,)))
            loss.backward()
            optimizer.step()
            obs.step(loss=loss.item())
            optimizer.zero_grad()

        csv_path = str(tmp_path / 'obs.csv')
        obs.export_csv(csv_path)
        import csv
        with open(csv_path) as f:
            reader = csv.DictReader(f)
            rows = list(reader)
        assert len(rows) > 0
        assert 'layer_type' in rows[0]


# ── EntropySplit ──────────────────────────────────────────────────────────

class TestEntropySplit:
    def test_basic_split(self, mlp_setup):
        model, optimizer = mlp_setup
        obs = Observer(model, optimizer)
        splitter = EntropySplit(model, optimizer, obs)
        criterion = nn.CrossEntropyLoss()

        for _ in range(10):
            x = torch.randn(4, 32)
            loss = criterion(model(x), torch.randint(0, 10, (4,)))
            loss.backward()
            optimizer.step()
            obs.step(loss=loss.item())
            snap = splitter.step()
            optimizer.zero_grad()

        assert len(splitter.step_history) == 10
        assert snap.total_d_eS >= 0
        assert snap.total_d_iS >= 0

    def test_R_ie_is_finite(self, mlp_setup):
        model, optimizer = mlp_setup
        splitter = EntropySplit(model, optimizer)
        criterion = nn.CrossEntropyLoss()

        for _ in range(10):
            x = torch.randn(4, 32)
            loss = criterion(model(x), torch.randint(0, 10, (4,)))
            loss.backward()
            optimizer.step()
            snap = splitter.step()
            optimizer.zero_grad()

        for ls in snap.layers:
            assert math.isfinite(ls.R_ie)
            assert math.isfinite(ls.d_eS)
            assert math.isfinite(ls.d_iS)

    def test_weight_decay_detected(self):
        """Layers with high weight decay should show d_iS_wd > 0."""
        model = TinyMLP()
        groups = make_param_groups(model, lr=1e-2, weight_decay=0.5)
        optimizer = torch.optim.AdamW(groups)
        splitter = EntropySplit(model, optimizer)
        criterion = nn.CrossEntropyLoss()

        for _ in range(20):
            x = torch.randn(8, 32)
            loss = criterion(model(x), torch.randint(0, 10, (8,)))
            loss.backward()
            optimizer.step()
            splitter.step()
            optimizer.zero_grad()

        # With wd=0.5, we should see nonzero d_iS_wd
        last = splitter.step_history[-1]
        total_wd = sum(ls.d_iS_wd for ls in last.layers)
        assert total_wd > 0

    def test_report_runs(self, mlp_setup):
        model, optimizer = mlp_setup
        splitter = EntropySplit(model, optimizer)
        criterion = nn.CrossEntropyLoss()

        for _ in range(30):
            x = torch.randn(4, 32)
            loss = criterion(model(x), torch.randint(0, 10, (4,)))
            loss.backward()
            optimizer.step()
            splitter.step()
            optimizer.zero_grad()

        report = splitter.report()
        assert 'THERMOCLAW' in report
        assert 'R_ie' in report

    def test_export_csv(self, mlp_setup, tmp_path):
        model, optimizer = mlp_setup
        splitter = EntropySplit(model, optimizer)
        criterion = nn.CrossEntropyLoss()

        for _ in range(5):
            x = torch.randn(4, 32)
            loss = criterion(model(x), torch.randint(0, 10, (4,)))
            loss.backward()
            optimizer.step()
            splitter.step()
            optimizer.zero_grad()

        csv_path = str(tmp_path / 'split.csv')
        splitter.export_csv(csv_path)
        import csv
        with open(csv_path) as f:
            reader = csv.DictReader(f)
            rows = list(reader)
        assert len(rows) > 0
        assert 'd_eS' in rows[0]
        assert 'd_iS' in rows[0]


# ── Diagnose ──────────────────────────────────────────────────────────────

class TestDiagnose:
    def test_observer_only(self, mlp_setup):
        model, optimizer = mlp_setup
        obs = Observer(model, optimizer)
        criterion = nn.CrossEntropyLoss()

        for _ in range(30):
            x = torch.randn(4, 32)
            loss = criterion(model(x), torch.randint(0, 10, (4,)))
            loss.backward()
            optimizer.step()
            obs.step(loss=loss.item())
            optimizer.zero_grad()

        report = diagnose(obs)
        assert report.equilibrium_fraction >= 0
        assert len(str(report)) > 0

    def test_with_entropy_split(self, mlp_setup):
        model, optimizer = mlp_setup
        obs = Observer(model, optimizer)
        splitter = EntropySplit(model, optimizer, obs)
        criterion = nn.CrossEntropyLoss()

        for _ in range(30):
            x = torch.randn(4, 32)
            loss = criterion(model(x), torch.randint(0, 10, (4,)))
            loss.backward()
            optimizer.step()
            obs.step(loss=loss.item())
            splitter.step()
            optimizer.zero_grad()

        report = diagnose(obs, splitter)
        assert report.entropy_split_available
        assert len(report.worst_R_ie_layers) > 0

    def test_empty_observer(self):
        model = TinyMLP()
        optimizer = torch.optim.AdamW(model.parameters(), lr=1e-3)
        obs = Observer(model, optimizer)
        report = diagnose(obs)
        assert 'No data' in report.summary


# ── ThermoScheduler ───────────────────────────────────────────────────────

class TestThermoScheduler:
    def test_warmup(self):
        model = TinyMLP()
        optimizer = torch.optim.AdamW(model.parameters(), lr=1e-3)
        scheduler = ThermoScheduler(optimizer, total_steps=1000, warmup_steps=100)

        lrs = []
        for _ in range(100):
            lrs.append(optimizer.param_groups[0]['lr'])
            # Need grads for post-warmup feedback
            x = torch.randn(4, 32)
            model(x).sum().backward()
            optimizer.step()
            scheduler.step()
            optimizer.zero_grad()

        # LR should increase during warmup
        assert lrs[-1] > lrs[0]

    def test_full_schedule(self):
        model = TinyMLP()
        optimizer = torch.optim.AdamW(model.parameters(), lr=1e-3)
        scheduler = ThermoScheduler(optimizer, total_steps=200, warmup_steps=20)
        criterion = nn.CrossEntropyLoss()

        lrs = []
        for _ in range(200):
            x = torch.randn(4, 32)
            loss = criterion(model(x), torch.randint(0, 10, (4,)))
            loss.backward()
            optimizer.step()
            scheduler.step()
            optimizer.zero_grad()
            lrs.append(optimizer.param_groups[0]['lr'])

        # LR should be high-ish after warmup and lower at end
        assert lrs[25] > lrs[-1]

    def test_lr_stays_in_bounds(self):
        model = TinyMLP()
        optimizer = torch.optim.AdamW(model.parameters(), lr=1e-3)
        scheduler = ThermoScheduler(optimizer, total_steps=100, warmup_steps=10,
                                     eta_min=1e-7)
        criterion = nn.CrossEntropyLoss()

        for _ in range(100):
            x = torch.randn(4, 32)
            loss = criterion(model(x), torch.randint(0, 10, (4,)))
            loss.backward()
            optimizer.step()
            scheduler.step()
            optimizer.zero_grad()
            lr = optimizer.param_groups[0]['lr']
            assert lr >= 1e-7
            assert lr <= 1e-3 + 1e-9  # small float tolerance


# ── Transformer model ─────────────────────────────────────────────────────

class TestTransformerIntegration:
    def test_observer_with_transformer(self, transformer_setup):
        model, optimizer = transformer_setup
        obs = Observer(model, optimizer)
        criterion = nn.CrossEntropyLoss()

        for _ in range(10):
            x = torch.randint(0, 100, (2, 8))
            logits = model(x)
            loss = criterion(logits.view(-1, 100), x.view(-1))
            loss.backward()
            optimizer.step()
            snap = obs.step(loss=loss.item())
            optimizer.zero_grad()

        # Should detect multiple layer types
        ltypes = {ld['ltype'] for ld in snap['layers']}
        assert len(ltypes) >= 2  # At least embedding + something else

    def test_entropy_split_with_transformer(self, transformer_setup):
        model, optimizer = transformer_setup
        splitter = EntropySplit(model, optimizer)
        criterion = nn.CrossEntropyLoss()

        for _ in range(10):
            x = torch.randint(0, 100, (2, 8))
            logits = model(x)
            loss = criterion(logits.view(-1, 100), x.view(-1))
            loss.backward()
            optimizer.step()
            snap = splitter.step()
            optimizer.zero_grad()

        ltypes = {ls.ltype for ls in snap.layers}
        assert len(ltypes) >= 2
