from dataclasses import dataclass
from typing import Dict, Any

from .graph.db import GraphDataBaseProvider
from .graph.knowledge_extraction import KnowledgeExtractor
from .llm.llm_provider import LLMProvider
from .vector.db import VectorDataBaseProvider, VectorSearchResponse


@dataclass
class GraphRagPipelineSettings:
    graph_db: GraphDataBaseProvider
    knowledge_extractor: KnowledgeExtractor


@dataclass
class GraphRAGPipelineResult:
    additional_context: list[str]


class GraphRAGPipeline:
    def __init__(self, settings: GraphRagPipelineSettings):
        self.graph_db: GraphDataBaseProvider = settings.graph_db
        self.knowledge_extractor: KnowledgeExtractor = settings.knowledge_extractor

    def process(
        self, question: str, vector_search_response: VectorSearchResponse
    ) -> GraphRAGPipelineResult:
        knowledge = self.knowledge_extractor.extract(
            [item for item in vector_search_response.answers if not item.processed]
        )
        self.graph_db.add_knowledge(knowledge)
        knowledge = self.knowledge_extractor.extract_text(question)
        graph_search_response = self.graph_db.search(knowledge)
        relations_representations = [str(relation) for relation in graph_search_response.relations]
        return GraphRAGPipelineResult(additional_context=relations_representations)


@dataclass
class RAGPipelineSettings:
    vector_db: VectorDataBaseProvider
    llm_provider: LLMProvider
    system_template: str = None
    prompt_template: str = None
    graph_rag_pipeline: GraphRAGPipeline = None


class RAGPipeline:

    def __init__(self, settings: RAGPipelineSettings):
        """
        prompt_template works with {question}, {initial_context} and {additional_context}.
        question = initial prompt.
        initial_context = some context that can be provided externally.
        additional_context = result of searching in knowledge database.
        """
        self.vector_db: VectorDataBaseProvider = settings.vector_db
        self.llm: LLMProvider = settings.llm_provider
        self.system_template: str = settings.system_template
        self.prompt_template: str = (
            settings.prompt_template
            or "Question: {question}.\nInitial context: {initial_context}.\nAdditional Context:{additional_context}."
        )
        self.graph_rag_pipeline: GraphRAGPipeline = settings.graph_rag_pipeline

    def process(self, question: str, initial_context: str = None) -> Dict[str, Any]:
        search_results = self.vector_db.search(question)
        context = "\n".join(i.text for i in search_results.answers) + ". "
        if self.graph_rag_pipeline is not None:
            additional_context = self._call_graph_rag(
                question, search_results
            ).additional_context
            context += ".".join(additional_context)
        prompt = self.prompt_template.format(
            question=question,
            initial_context=initial_context or "Empty",
            additional_context=additional_context,
        )
        response = self.llm.generate(prompt)
        return {
            "question": question,
            "answer": response,
            "sources": context,
        }

    def _call_graph_rag(
        self, question: str, vector_search_response: VectorSearchResponse
    ) -> GraphRAGPipelineResult:
        result = self.graph_rag_pipeline.process(question, vector_search_response)
        self.vector_db.update_processed(
            [doc.id for doc in vector_search_response.answers]
        )
        return result
