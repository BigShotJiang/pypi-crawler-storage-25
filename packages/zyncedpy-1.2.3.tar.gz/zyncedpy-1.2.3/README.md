# 🚀 ZyncedPy

[![PyPI version](https://img.shields.io/pypi/v/zyncedpy.svg)](https://pypi.org/project/zyncedpy/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Python 3.10+](https://img.shields.io/badge/python-3.10+-blue.svg)](https://www.python.org/downloads/)

**ZyncedPy** to potężna, w pełni asynchroniczna biblioteka Pythona stworzona do budowania self-botów na platformie **Zynced**. Architektura oparta na zdarzeniach i `asyncio` zapewnia wysoką wydajność i łatwość obsługi, znaną z najpopularniejszych bibliotek do tworzenia botów.

---

## 🛠 Instalacja

Zainstaluj bibliotekę za pomocą menedżera pakietów pip:

```bash
pip install zyncedpy
```
## 🔑 Autoryzacja (Pozyskiwanie Tokena)
ZyncedPy wymaga tokena sesyjnego, który składa się z dwóch ciasteczek. Aby go uzyskać:

**1.** Zaloguj się na swoje konto na zynced.app.\
**2.** Otwórz Narzędzia Deweloperskie (F12) i przejdź do zakładki Application -> Cookies.\
**3.** Znajdź wartości dla cf_clearance oraz connect.sid.\
**4.** Połącz je w jeden ciąg tekstowy w formacie:
```bash
cf_clearance=WARTOŚĆ; connect.sid=WARTOŚĆ;
```
# Inicjalizacja klienta z Twoim tokenem
```bash

from zyncedpy import Client

token = 'cf_clearance=...; connect.sid=...;'
client = Client(token)

@client.on("ready")
async def on_ready(data):
    print(f"✅ Zalogowano pomyślnie jako {client.user.username}")
    
    for channel in client.channels.values():
        try:
            await channel.subscribe()
        except:
            pass
            
    print("Bot jest gotowy do pracy!")

@client.on("messageCreate")
async def on_message(message):
    if message.author == client.user.username:
        return

    if message.content.strip() == "!ping":
        print(f"Wykryto !ping od {message.author}")
        await message.reply("🏓 Pong!")

try:
    client.login()
except KeyboardInterrupt:
    print("\nZamykanie bota...")
```

## ✨ Główne Możliwości

- Pełna Asynchroniczność: Zbudowana na asyncio dla płynnej obsługi wielu zdarzeń jednocześnie.
- WebSocket & REST: Stabilne połączenie w czasie rzeczywistym oraz pełne wsparcie dla zapytań API.
- Zarządzanie Kanałami: Intuicyjne przesyłanie wiadomości, plików oraz obsługa subskrypcji kanałów.
- Obsługa Mediów: Wbudowane metody do wysyłania GIF-ów oraz przesyłania plików z dysku lokalnego.
- System Zdarzeń: Obsługa ready, messageCreate, privateMessageCreate, userInvite i innych.


## 📚 Dokumentacja API

**Zdarzenie**          
`ready` | `Wywoływane po poprawnym zalogowaniu i pobraniu danych startowych.`

---
`messageCreate` | `Wywoływane przy nowej wiadomości na zasubskrybowanym kanale.`

---
`privateMessageCreate` | `Wywoływane przy otrzymaniu nowej wiadomości prywatnej (DM).`

---
`userInvite` | `Wywoływane, gdy inny użytkownik wyśle Ci zaproszenie do rozmowy.`

## 💼 Kluczowe Metody
```bash
- await channel.subscribe(): Rejestruje bota w "pokoju" serwera, umożliwiając odbiór wiadomości na żywo.
- await channel.send(text, attachments=[]): Wysyła wiadomość tekstową lub pliki na kanał.
- await message.reply(text): Wysyła odpowiedź (reply) do konkretnej wiadomości.
- await client.accept_invite(user_id): Akceptuje zaproszenie do rozmowy prywatnej.
```

## ⚖️ Licencja & Nota Prawna

- Biblioteka jest udostępniana na licencji MIT.
- Uwaga: ZyncedPy jest niezależnym projektem i nie jest powiązany z twórcami platformy Zynced. Używanie self-botów może naruszać regulamin platformy – korzystasz z biblioteki na własną odpowiedzialność.