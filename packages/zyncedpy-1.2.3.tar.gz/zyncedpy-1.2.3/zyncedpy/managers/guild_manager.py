from .base_manager import BaseManager
from ..structures import Guild

class GuildManager(BaseManager[Guild]):
    def _add(self, data: dict) -> Guild:
        # Pobieramy ID ze słownika
        guild_id = data.get('id')
        
        if self.has(guild_id):
            return self.cache[guild_id]

        # Tworzymy obiekt Guild przekazując surowy słownik
        guild = Guild(self.client, data)
        self.cache[guild.id] = guild
        return guild