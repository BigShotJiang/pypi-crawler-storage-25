from .client.client import Client

__version__ = "1.2.3"
__author__ = "dukaj"

__all__ = ["Client"]