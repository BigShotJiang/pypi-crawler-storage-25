from typing import Optional, Union, Dict, Any, Protocol
import logging

class ClientLogger(Protocol):
    def debug(self, message: str, *args, **kwargs) -> None: ...
    def info(self, message: str, *args, **kwargs) -> None: ...
    def warn(self, message: str, *args, **kwargs) -> None: ...
    def error(self, message: str, *args, **kwargs) -> None: ...

ClientLoggerOption = Union[bool, ClientLogger, Dict[str, Any]]

class ClientOptions:
    def __init__(self, logger: Optional[ClientLoggerOption] = None):
        self.logger = logger

# Event types
class RawMemberAction:
    def __init__(self, username: str, channelId: str):
        self.username = username
        self.channel_id = channelId

class RawSfuCapabilities:
    def __init__(self, codecs: list, headerExtensions: list):
        self.codecs = codecs
        self.header_extensions = headerExtensions

class RawUserInvite:
    def __init__(self, type: str, inviteId: str, channelId: str, inviterUsername: str):
        self.type = type
        self.invite_id = inviteId
        self.channel_id = channelId
        self.inviter_username = inviterUsername

# Message attachment types
MessageType = str  # 'gif' | 'file'

class MessageAttachment:
    def __init__(self, type: MessageType, url: str, name: Optional[str] = None):
        self.type = type
        self.url = url
        self.name = name

# Event data types
from typing import TYPE_CHECKING
if TYPE_CHECKING:
    from .structures import ClientUser, Message, PrivateMessage
    from .managers import ChannelManager, GuildManager

class ClientEvents:
    ready: Dict[str, Any]  # {'user': ClientUser, 'channels': ChannelManager, 'guilds': GuildManager}
    messageCreate: 'Message'
    privateMessageCreate: 'PrivateMessage'
    memberJoined: RawMemberAction
    memberLeft: RawMemberAction
    userInvite: RawUserInvite