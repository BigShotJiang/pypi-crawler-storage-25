from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ...client import Client
from ...structures import PrivateMessage

def handle_private_message_create(client: 'Client', data):
    client.emit('privateMessageCreate', PrivateMessage(client, data))