from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ...client import Client
from ...types import RawUserInvite

def handle_user_invite(client: 'Client', data: RawUserInvite):
    client.emit('userInvite', data)