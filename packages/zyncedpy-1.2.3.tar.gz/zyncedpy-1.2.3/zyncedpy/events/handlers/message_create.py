from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ...client import Client
from ...structures import Message

def handle_message_create(client: 'Client', data):
    client.emit('messageCreate', Message(client, data))