from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ...client import Client
from ...types import RawMemberAction

def handle_member_joined(client: 'Client', data: RawMemberAction):
    client.emit('memberJoined', data)