from ..events import TypedEmitter
from .rest_client import RestClient
from .websocket_client import WebSocketClient
from ..types import ClientOptions, ClientLogger
from ..utils import resolve_logger
from typing import Optional

class BaseClient(TypedEmitter):
    def __init__(self, token: str, options: Optional[ClientOptions] = None):
        super().__init__()
        if options is None:
            options = ClientOptions()

        self.logger: ClientLogger = resolve_logger(options.logger)
        # Dodany / na końcu URL dla bezpieczeństwa
        self._rest = RestClient(token, 'https://zynced.app/api/', self.logger)
        self._ws = WebSocketClient(token, self.logger)

    def on(self, event: str, listener=None):
        if listener is not None:
            super().on(event, listener)
            return listener

        def decorator(func):
            super(BaseClient, self).on(event, func)
            return func
        return decorator

    def get_rest(self) -> RestClient:
        return self._rest

    def get_ws(self) -> WebSocketClient:
        return self._ws

    def destroy(self):
        self._ws.disconnect()