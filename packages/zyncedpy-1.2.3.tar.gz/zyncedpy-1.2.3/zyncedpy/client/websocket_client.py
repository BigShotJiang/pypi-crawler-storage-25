import socketio
from typing import Optional, Any
from ..types import ClientLogger
from ..events import TypedEmitter

class WebSocketClient(TypedEmitter):
    def __init__(self, cookies: str, logger: ClientLogger):
        super().__init__()
        self.cookies = cookies
        self.logger = logger
        self.socket: Optional[socketio.AsyncClient] = None
        self._connected = False

    async def connect(self):
        self.socket = socketio.AsyncClient()

        # Set up event handlers
        @self.socket.on('connect')
        async def on_connect():
            self._connected = True
            self.logger.info(f"WebSocket connected, socket ID: {self.socket.sid}")

        @self.socket.on('disconnect')
        async def on_disconnect():
            self._connected = False
            self.logger.info("WebSocket disconnected")

        @self.socket.on('connect_error')
        async def on_connect_error(err):
            self.logger.error(f"WebSocket connection error: {err}")

        @self.socket.on('*')
        async def catch_all(event, data):
            await self._handle_message(event, data)

        # Connect with headers
        await self.socket.connect(
            'https://zynced.app',
            transports=['websocket'],
            headers={
                'User-Agent': 'ZyncedPy/1.0',
                'Accept': '*/*',
                'Accept-Encoding': 'gzip, deflate, br, zstd',
                'Origin': 'https://zynced.app',
                'Connection': 'Upgrade',
                'Cookie': self.cookies,
                'Sec-Fetch-Dest': 'empty',
                'Sec-Fetch-Mode': 'websocket',
                'Sec-Fetch-Site': 'same-origin',
                'Pragma': 'no-cache',
                'Cache-Control': 'no-cache',
                'Upgrade': 'websocket',
            }
        )

    async def disconnect(self):
        if self.socket:
            await self.socket.disconnect()
            self._connected = False

    async def send(self, name: str, data: Any):
        if self.socket and self._connected:
            await self.socket.emit(name, data)
            self.logger.info(f"WebSocket sent: {name} {data}")

    async def _handle_message(self, event: str, payload: Any):
        self.logger.info(f"WebSocket received: {event} {payload}")

        if event == 'newMessage':
            self.emit('privateMessageCreate', payload)
        elif event == 'newChannelMessage':
            self.emit('messageCreate', payload)
        elif event == 'status-update':
            if payload.get('type') == 'member_joined':
                self.emit('memberJoined', payload)
            elif payload.get('type') == 'member_left':
                self.emit('memberLeft', payload)
        elif event == 'invite-event':
            if payload.get('type') == 'new_invite':
                self.emit('userInvite', payload)
        elif event == 'channelMessages':
            # Internal event
            self.emit('channelMessages', payload)