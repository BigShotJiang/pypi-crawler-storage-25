import asyncio
import traceback
from .base_client import BaseClient
from ..managers import ChannelManager, GuildManager
from ..structures import ClientUser, Channel
from ..types import ClientOptions
from ..events.handlers import (
    handle_private_message_create, handle_message_create,
    handle_member_joined, handle_member_left, handle_user_invite
)

class Client(BaseClient):
    def __init__(self, token: str, options: ClientOptions = None):
        super().__init__(token, options)
        
        self.channels = ChannelManager(self)
        self.guilds = GuildManager(self)
        self.user = ClientUser(self)

        self._setup_event_handlers()

    def _setup_event_handlers(self):
        ws = self.get_ws()
        ws.on('privateMessageCreate', lambda data: handle_private_message_create(self, data))
        ws.on('messageCreate', lambda data: handle_message_create(self, data))
        ws.on('memberJoined', lambda data: handle_member_joined(self, data))
        ws.on('memberLeft', lambda data: handle_member_left(self, data))
        ws.on('userInvite', lambda data: handle_user_invite(self, data))

    def login(self):
        try:
            asyncio.run(self._start_async_bot())
        except KeyboardInterrupt:
            pass
        except Exception as e:
            print(f"[ZyncedPy] BŁĄD: {e}")
            traceback.print_exc()

    async def _start_async_bot(self):
        try:
            # 1. Połączenie WebSocket
            await self.get_ws().connect()
            
            # 2. Pobranie danych startowych
            response = self.get_rest().get('/data')
            
            try:
                data = response.json()
            except Exception:
                print("BŁĄD: Serwer nie zwrócił poprawnego JSON.")
                return

            # 3. Aktualizacja danych bota
            self.user._patch(data['me'])

            for raw_channel in data['userList']['channels']:
                manager = self.channels if raw_channel.get('group_id') else self.guilds
                manager._add(raw_channel)

            # 4. Wyemitowanie zdarzenia 'ready'
            self.emit('ready', {
                'user': self.user,
                'channels': self.channels,
                'guilds': self.guilds,
            })
            
            # JEDYNY KOMUNIKAT W KONSOLI:
            print(f"✅ Zalogowano jako {self.user.username} (ID: {self.user.id})")
            
            while True:
                await asyncio.sleep(1)
                
        except Exception as e:
            # Zostawiamy błędy, żebyś wiedział, jeśli coś się zepsuje
            print(f"[ZyncedPy] Błąd pętli: {e}")
        finally:
            await self.get_ws().disconnect()

    def channel(self, id: str) -> Channel:
        return self.channels.get(id)

    async def join_guild(self, guild_id: str):
        response = self.get_rest().post(f'/channels/join/{guild_id}')
        return response.json()

    async def accept_invite(self, from_user: str):
        response = self.get_rest().post('/invite/accept', json={
            'from_user': from_user,
        })
        return response.json()