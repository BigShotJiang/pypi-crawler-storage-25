import requests
from typing import Optional, Dict, Any
from ..types import ClientLogger

class RestClient:
    def __init__(self, cookies: str, base_url: Optional[str] = None, logger: Optional[ClientLogger] = None):
        """
        Inicjalizuje klienta REST używającego sesji.
        :param cookies: String z ciasteczkami (np. cf_clearance=...; connect.sid=...)
        :param base_url: Podstawowy adres API
        :param logger: Instancja loggera do debugowania
        """
        self.cookies = cookies
        # Czyścimy base_url z ukośnika na końcu, aby uniknąć błędów typu api//data
        self.base_url = (base_url or 'https://zynced.app/api').rstrip('/')
        self.logger = logger

        # Tworzymy sesję, która będzie pamiętać nagłówki
        self.session = requests.Session()
        self.session.headers.update({
            # User-Agent udający prawdziwą przeglądarkę (ważne dla Cloudflare)
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Accept': 'application/json, text/plain, */*',
            'Accept-Language': 'pl-PL,pl;q=0.9,en-US;q=0.8,en;q=0.7',
            'Accept-Encoding': 'gzip, deflate, br',
            'Cookie': self.cookies,
            'Origin': 'https://zynced.app',
            'Referer': 'https://zynced.app/',
            'Connection': 'keep-alive',
            'Sec-Fetch-Dest': 'empty',
            'Sec-Fetch-Mode': 'cors',
            'Sec-Fetch-Site': 'same-origin',
        })

    def _build_url(self, endpoint: str) -> str:
        """Łączy base_url z endpointem, dbając o ukośniki."""
        path = endpoint if endpoint.startswith('/') else f"/{endpoint}"
        return f"{self.base_url}{path}"

    def _log_request(self, method: str, url: str):
        if self.logger:
            self.logger.debug(f"REST request: {method} {url}")

    def _log_response(self, method: str, url: str, status: int):
        if self.logger:
            self.logger.debug(f"REST response: {method} {url} {status}")

    def _log_error(self, method: str, url: str, status: Optional[int], message: str):
        if self.logger:
            self.logger.error(f"REST request failed: {method} {url} {status} {message}")

    def get(self, endpoint: str, **kwargs):
        url = self._build_url(endpoint)
        self._log_request('GET', url)
        try:
            response = self.session.get(url, **kwargs)
            self._log_response('GET', url, response.status_code)
            return response
        except Exception as e:
            self._log_error('GET', url, None, str(e))
            raise

    def post(self, endpoint: str, data=None, json=None, **kwargs):
        url = self._build_url(endpoint)
        self._log_request('POST', url)
        try:
            response = self.session.post(url, data=data, json=json, **kwargs)
            self._log_response('POST', url, response.status_code)
            return response
        except Exception as e:
            self._log_error('POST', url, None, str(e))
            raise

    def put(self, endpoint: str, data=None, json=None, **kwargs):
        url = self._build_url(endpoint)
        self._log_request('PUT', url)
        try:
            response = self.session.put(url, data=data, json=json, **kwargs)
            self._log_response('PUT', url, response.status_code)
            return response
        except Exception as e:
            self._log_error('PUT', url, None, str(e))
            raise

    def patch(self, endpoint: str, data=None, json=None, **kwargs):
        url = self._build_url(endpoint)
        self._log_request('PATCH', url)
        try:
            response = self.session.patch(url, data=data, json=json, **kwargs)
            self._log_response('PATCH', url, response.status_code)
            return response
        except Exception as e:
            self._log_error('PATCH', url, None, str(e))
            raise

    def delete(self, endpoint: str, **kwargs):
        url = self._build_url(endpoint)
        self._log_request('DELETE', url)
        try:
            response = self.session.delete(url, **kwargs)
            self._log_response('DELETE', url, response.status_code)
            return response
        except Exception as e:
            self._log_error('DELETE', url, None, str(e))
            raise