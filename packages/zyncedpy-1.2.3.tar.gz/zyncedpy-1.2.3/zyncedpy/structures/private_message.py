from datetime import datetime
from typing import TYPE_CHECKING
from .base import Base

if TYPE_CHECKING:
    from ..client import Client

class PrivateMessage(Base):
    def __init__(self, client: 'Client', data: dict):
        super().__init__(client, data)
        
        msg_section = data.get('message', {})
        
        # W Zynced 'chatmode' i 'text' są wewnątrz 'message'
        self.chatmode = msg_section.get('chatmode', 'default')
        self.content = msg_section.get('text', '')
        
        # 'from' to ID użytkownika, który do nas pisze
        self.author = data.get('from')
        
        # Obsługa daty (bezpieczna dla int i str)
        raw_date = msg_section.get('timestamp')
        if isinstance(raw_date, (int, float)):
            ts = raw_date / 1000 if raw_date > 1e10 else raw_date
            self.date = datetime.fromtimestamp(ts)
        else:
            self.date = datetime.now()

    async def reply(self, content: str):
        """Wysyła odpowiedź na PV do autora wiadomości."""
        # POPRAWKA: Zynced oczekuje kluczy 'to' oraz 'message'
        return await self.client.get_ws().send('sendPrivateMessage', {
            'to': self.author,
            'message': content
        })