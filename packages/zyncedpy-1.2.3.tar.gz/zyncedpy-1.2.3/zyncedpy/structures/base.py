from typing import Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from ..client import Client

class Base:
    def __init__(self, client: 'Client', data: Optional[dict] = None):
        """
        Klasa bazowa. data jest opcjonalne, bo niektóre obiekty 
        (jak ClientUser) są tworzone przed pobraniem danych.
        """
        self.client = client
        self._raw = data or {}