from .base_channel import BaseChannel

class Guild(BaseChannel):
    def __init__(self, client, data: dict):
        # Przekazujemy do BaseChannel, który przekaże do Base
        super().__init__(client, data)
        
        self.owner_id = data.get('owner_id')
        self.member_count = data.get('member_count', 0)

    def leave(self):
        """Opuszcza serwer."""
        res = self.client.get_rest().post(f'/channels/leave/{self.id}')
        return res.json()