from typing import Optional, TYPE_CHECKING
from dataclasses import dataclass
from .base import Base

if TYPE_CHECKING:
    from ..client import Client

@dataclass
class RawChannel:
    """Typ pomocniczy (podpowiedzi IDE) odzwierciedlający strukturę z API."""
    id: str
    name: str
    description: str
    group_id: Optional[str]
    category_id: Optional[str]
    position: Optional[int]
    relative_to_category: Optional[str]
    created_at: str
    blocked: bool
    avatar: str
    accept_joins: bool
    type: str 
    owner: str
    user_joined_at: str
    lastMessageAt: int

class BaseChannel(Base):
    def __init__(self, client: 'Client', data: dict):
        # WYWOŁANIE SUPER: Przekazujemy oba argumenty do klasy Base
        super().__init__(client, data)

        # Mapowanie danych ze słownika na atrybuty obiektu
        self.id = data.get('id')
        self.name = data.get('name')
        self.group_id = data.get('group_id')
        self.description = data.get('description')
        self.category_id = data.get('category_id')
        self.position = data.get('position')
        self.relative_to_category = data.get('relative_to_category')
        self.created_at = data.get('created_at')
        self.blocked = data.get('blocked', False)
        self.avatar = data.get('avatar')
        self.accept_joins = data.get('accept_joins', True)
        self.type = data.get('type')
        self.owner = data.get('owner')
        self.user_joined_at = data.get('user_joined_at')
        # Zwróć uwagę na CamelCase w kluczu lastMessageAt (częste w API)
        self.last_message_at = data.get('lastMessageAt')

    def __repr__(self):
        return f"<{self.__class__.__name__} id={self.id} name={self.name}>"