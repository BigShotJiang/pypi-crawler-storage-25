import base64
import mimetypes
import os
import asyncio
from typing import List, Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from ..client import Client

from .base_channel import BaseChannel
from .message import Message

class Channel(BaseChannel):
    def __init__(self, client: 'Client', data: dict):
        # Inicjalizacja klasy bazowej słownikiem danych z API
        super().__init__(client, data)
        self.messages: List[Message] = []

    def _set_messages(self, raw_messages: list):
        self.messages.clear()
        for msg in raw_messages:
            self.messages.append(Message(self.client, msg))

    def _add_message(self, message: Message) -> int:
        self.messages.append(message)
        return len(self.messages)

    async def subscribe(self):
        """Mówi serwerowi Zynced, że chcemy otrzymywać wiadomości z tego kanału."""
        # 1. Wysyłamy prośbę o subskrypcję pokoju
        await self.client.get_ws().send('syncChannelRooms', [self.id])

        # 2. Ustawiamy jednorazowy handler na historię wiadomości
        def handler(data):
            if data.get('channelId') != self.id:
                return
            self.client.get_ws().off('channelMessages', handler)
            self._set_messages(data.get('messages', []))

        self.client.get_ws().on('channelMessages', handler)
        
        # 3. Pobieramy ostatnie wiadomości (ZyncedJS wymaga _t jako timestamp)
        await self.client.get_ws().send('getChannelMessages', [self.id, {
            "channelId": self.id,
            "_t": int(__import__('time').time() * 1000)
        }])
        return self

    async def send(self, message: str, attachments: Optional[List] = None):
        """Wysyła wiadomość tekstową lub załączniki."""
        if attachments is None:
            attachments = []

        if message:
            await self.client.get_ws().send('sendChannelMessage', {
                "channelId": self.id,
                "message": {
                    "text": message,
                    "from": self.client.user.username if self.client.user else None,
                },
            })

        for attachment in attachments:
            # Sprawdzamy czy to GIF czy zwykły plik
            is_gif = getattr(attachment, 'type', '') == 'gif'
            url = getattr(attachment, 'url', None)
            
            if is_gif and url:
                await self._send_gif(url)
            elif url:
                await self._send_file(url)

        return self

    async def reply(self, message: str, attachments: Optional[List], reply_to_index: int, reply_author: str, reply_text: str):
        """Odpowiada na konkretną wiadomość (Reply)."""
        if attachments is None:
            attachments = []

        await self.client.get_ws().send('sendChannelMessage', {
            "channelId": self.id,
            "message": {
                "text": message,
                "from": self.client.user.username if self.client.user else None,
                "reply_to_index": reply_to_index,
                "reply_author": reply_author,
                "reply_text": reply_text
            },
        })

        for attachment in attachments:
            url = getattr(attachment, 'url', None)
            if getattr(attachment, 'type', '') == 'gif' and url:
                await self._send_gif(url)
            elif url:
                await self._send_file(url)

        return self

    async def _send_gif(self, url: str):
        """Pomocnicza metoda do wysyłania GIFów jako linki."""
        payload = {
            "text": '',
            "messageType": 'gif-link',
            "gifUrl": url,
            "sender": self.client.user.username if self.client.user else None,
        }
        await self.client.get_ws().send('sendChannelMessage', {
            "channelId": self.id,
            "message": {
                "text": __import__('json').dumps(payload),
                "from": self.client.user.username if self.client.user else None,
            },
        })

    async def _send_file(self, file_path: str):
        """Wczytuje plik z dysku, zamienia na Base64 i wysyła do Zynced."""
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"Nie znaleziono pliku: {file_path}")

        file_name = os.path.basename(file_path)
        with open(file_path, 'rb') as f:
            file_buffer = f.read()

        file_base64 = base64.b64encode(file_buffer).decode('utf-8')
        mime_type = mimetypes.guess_type(file_path)[0] or 'application/octet-stream'

        data = {
            "channelId": self.id,
            "text": '',
            "fileName": file_name,
            "mimeType": mime_type,
            "fileBase64": file_base64,
        }

        await self.client.get_ws().send('uploadChannelMessageFile', data)