from datetime import datetime
from typing import Optional, List, TYPE_CHECKING
from .base import Base

if TYPE_CHECKING:
    from ..client import Client

class Message(Base):
    def __init__(self, client: 'Client', data: dict):
        # Inicjalizacja klasy bazowej
        super().__init__(client, data)

        # Zynced przesyła dane wiadomości albo w kluczu 'message', albo bezpośrednio
        msg_data = data.get('message') or data
        
        self.channel_id = data.get('channelId')
        self.guild_id = data.get('groupId')
        
        # Treść i autor
        self.content = msg_data.get('text', '')
        self.author = msg_data.get('from') or msg_data.get('sender', 'Unknown')
        
        # KLUCZOWA POPRAWKA: Pobieranie ID autora (potrzebne do PV)
        self.author_id = data.get('fromId') or data.get('authorId') or msg_data.get('fromId')

        # Zarządzanie historią wiadomości w kanale (jeśli to wiadomość kanałowa)
        if self.channel_id:
            channel = self.client.channel(self.channel_id)
            self.id = channel._add_message(self) if channel else None
        else:
            self.id = data.get('id') or 0

        # Obsługa daty
        raw_date = msg_data.get('date') or msg_data.get('timestamp')
        if isinstance(raw_date, str):
            try:
                self.date = datetime.fromisoformat(raw_date.replace('Z', '+00:00'))
            except:
                self.date = datetime.now()
        elif isinstance(raw_date, (int, float)):
            # Obsługa timestampów w ms i s
            ts = raw_date / 1000 if raw_date > 1e10 else raw_date
            self.date = datetime.fromtimestamp(ts)
        else:
            self.date = datetime.now()

        self.is_reply = bool(msg_data.get('reply_to_index'))

    async def reply(self, content: str, attachments: Optional[List] = None):
        """
        Uniwersalna metoda odpowiedzi. 
        Jeśli wiadomość jest z kanału - odpowiada na kanale.
        Jeśli wiadomość jest z PV - odpowiada na PV.
        """
        if attachments is None: 
            attachments = []
        
        # 1. Próba odpowiedzi na kanale
        if self.channel_id:
            channel = self.client.channel(self.channel_id)
            if channel:
                return await channel.reply(content, attachments, self.id, self.author, self.content)
        
        # 2. Jeśli nie ma channel_id, to jest to Wiadomość Prywatna (PV)
        if self.author_id or self.author:
            # Wysyłamy bezpośrednio przez WebSocket do autora
            target = self.author_id or self.author
            print(f"[ZyncedPy] Odpowiadam na PV do: {target}")
            
            # OSTATECZNA POPRAWKA: 'message' musi być słownikiem!
            await self.client.get_ws().send('sendPrivateMessage', {
                "to": target,
                "message": {
                    "text": content,
                    "content": content
                }
            })
            return self

        raise ValueError("Nie można odpowiedzieć na wiadomość: brak channel_id lub author_id.")