from typing import Optional, TYPE_CHECKING
from dataclasses import dataclass
from .base import Base

if TYPE_CHECKING:
    from ..client import Client

@dataclass
class RawClientUser:
    """Typ pomocniczy dla IDE."""
    userId: str
    username: str
    avatar: str
    status: str
    bannerUrl: str
    onlineStatus: str
    isPremium: bool

class ClientUser(Base):
    def __init__(self, client: 'Client', data: Optional[dict] = None):
        # POPRAWKA: Przekazujemy client i data (które domyślnie jest None) do Base
        super().__init__(client, data)
        
        # Inicjalizacja pustymi wartościami (zostaną uzupełnione przez _patch)
        self.id = ""
        self.username = ""
        self.avatar = ""
        self.status = ""
        self.banner_url = ""
        self.online_status = ""
        self.is_premium = False

        # Jeśli dane zostały podane już w konstruktorze, od razu je patchujemy
        if data:
            self._patch(data)

    def _patch(self, data: dict):
        """Aktualizuje dane użytkownika na podstawie słownika z API."""
        if not data:
            return self

        # Mapowanie kluczy z API na atrybuty klasy
        if 'userId' in data:
            self.id = data['userId']
        if 'username' in data:
            self.username = data['username']
        if 'avatar' in data:
            self.avatar = data['avatar']
        if 'status' in data:
            self.status = data['status']
        if 'bannerUrl' in data:
            self.banner_url = data['bannerUrl']
        if 'onlineStatus' in data:
            self.online_status = data['onlineStatus']
        if 'isPremium' in data:
            self.is_premium = data['isPremium']
            
        self._raw = data
        return self

    async def set_status(self, status: str):
        """Aktualizuje status profilu bota."""
        await self.client.get_ws().send('updateProfileStatus', {'status': status})
        self.status = status

    def __str__(self):
        return f"{self.username}#{self.id}"