import logging
from typing import Optional, Union, Dict, Any
from ..types import ClientLogger, ClientLoggerOption

def noop(*args, **kwargs):
    pass

silent_logger = type('SilentLogger', (), {
    'debug': noop,
    'info': noop,
    'warn': noop,
    'error': noop,
})()

def is_logger_like(value: Any) -> bool:
    return (
        hasattr(value, 'debug') and callable(getattr(value, 'debug')) and
        hasattr(value, 'info') and callable(getattr(value, 'info')) and
        hasattr(value, 'warn') and callable(getattr(value, 'warn')) and
        hasattr(value, 'error') and callable(getattr(value, 'error'))
    )

def resolve_logger(logger: Optional[ClientLoggerOption] = None) -> ClientLogger:
    if logger is False or logger is None:
        return silent_logger

    if logger is True:
        logger_instance = logging.getLogger('zyncedpy')
        logger_instance.setLevel(logging.DEBUG)
        handler = logging.StreamHandler()
        formatter = logging.Formatter('%(name)s - %(levelname)s - %(message)s')
        handler.setFormatter(formatter)
        logger_instance.addHandler(handler)
        return logger_instance

    if is_logger_like(logger):
        return logger

    # If it's a dict, assume it's logging config
    if isinstance(logger, dict):
        logger_instance = logging.getLogger('zyncedpy')
        logger_instance.setLevel(logger.get('level', logging.DEBUG))
        handler = logging.StreamHandler()
        if 'format' in logger:
            formatter = logging.Formatter(logger['format'])
        else:
            formatter = logging.Formatter('%(name)s - %(levelname)s - %(message)s')
        handler.setFormatter(formatter)
        logger_instance.addHandler(handler)
        return logger_instance

    return silent_logger