from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="zyncedpy",
    version="1.2.3",
    author="dukaj",
    description="ZyncedPy is a Python module for Zynced chat platform.",
    long_description=long_description,
    long_description_content_type="text/markdown",
    packages=[
        "zyncedpy",
        "zyncedpy.client",
        "zyncedpy.events",
        "zyncedpy.events.handlers",
        "zyncedpy.managers",
        "zyncedpy.structures",
        "zyncedpy.utils"
    ],
    include_package_data=True,
    python_requires=">=3.8",
    install_requires=[
        "requests>=2.25.0",
        "python-socketio>=5.0.0",
        "python-engineio>=4.0.0",
        "dataclasses-json>=0.5.0",
        "aiohttp>=3.9.0", # Naprawia AttributeError: module 'aiohttp' has no attribute 'ClientWSTimeout'
    ],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)