# _core.pyi
from typing import Sequence

def run_backtest(
    round: int, 
    days: Sequence[int], 
    params: list[dict[str, float]], 
    is_grid: bool,
    project_dir: str,
    script_dir: str,
    out_dir: str | None = None,
) -> None: ...