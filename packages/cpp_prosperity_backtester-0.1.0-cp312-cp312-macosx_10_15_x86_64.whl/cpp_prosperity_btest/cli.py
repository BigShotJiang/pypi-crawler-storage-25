import argparse
import itertools
import sys
from cpp_prosperity_btest._core import run_backtest
from pathlib import Path

CSV_FOLDER = Path(__file__).parent / "csv-files"

def scan_round(round: int) -> list[int]:
    """Returns (available_days, warnings) for a given round."""
    if not CSV_FOLDER.exists():
        print(f"Error: csv-files folder not found at {CSV_FOLDER}", file=sys.stderr)
        sys.exit(1)

    prices_days: set[int] = set()
    trades_days: set[int] = set()

    for f in CSV_FOLDER.glob("*.csv"):
        name = f.stem  # filename without .csv

        # check if this file belongs to this round
        round_marker = f"round_{round}_"
        if round_marker not in name:
            continue

        # extract day number
        day_idx = name.find("day_")
        if day_idx == -1:
            continue
        try:
            day = int(name[day_idx + 4:])
        except ValueError:
            continue

        if name.startswith("prices_"):
            prices_days.add(day)
        elif name.startswith("trades_"):
            trades_days.add(day)

    if not prices_days and not trades_days:
        print(f"Error: no files found for round {round}, try a different round", file=sys.stderr)
        sys.exit(1)

    # check each prices file has a matching trades file and vice versa
    prices_only = prices_days - trades_days
    trades_only = trades_days - prices_days
    for day in prices_only:
        print(f"Error: prices file for round {round} day {day} has no matching trades file", file=sys.stderr)
        sys.exit(1)
    for day in trades_only:
        print(f"Error: trades file for round {round} day {day} has no matching prices file — skipping", file=sys.stderr)
        sys.exit(1)

    valid_days = sorted(prices_days & trades_days)

    if not valid_days:
        print(f"Error: no data found for round {round}", file=sys.stderr)
        sys.exit(1)

    return valid_days

def parse_param(s: str) -> tuple[str, list[float]]:
    if "=" not in s:
        print(f"Error: param '{s}' must be in the format key=value or key=start:end:step", file=sys.stderr)
        sys.exit(1)

    key, val = s.split("=", 1)

    if not key:
        print(f"Error: param '{s}' has an empty key", file=sys.stderr)
        sys.exit(1)

    if ":" in val:
        parts = val.split(":")
        if len(parts) != 3:
            print(f"Error: param '{key}' range must be start:end:step, got '{val}'", file=sys.stderr)
            sys.exit(1)
        try:
            start, end, step = map(float, parts)
        except ValueError:
            print(f"Error: param '{key}' range values must be numbers, got '{val}'", file=sys.stderr)
            sys.exit(1)
        if step <= 0:
            print(f"Error: param '{key}' step must be positive, got {step}", file=sys.stderr)
            sys.exit(1)
        if start > end:
            print(f"Error: param '{key}' start ({start}) must be <= end ({end})", file=sys.stderr)
            sys.exit(1)
            
        values = []
        v = start
        while v <= end + 1e-9:
            values.append(round(v, 10))
            v += step
    else:
        try:
            values = [float(val)]
        except ValueError:
            print(f"Error: param '{key}' value must be a number, got '{val}'", file=sys.stderr)
            sys.exit(1)

    return key, values


def main():
    parser = argparse.ArgumentParser(prog="cpp-prosperity-btest")
    parser.add_argument("--round", type=int, required=True, choices=range(1, 6),
                        metavar="ROUND", help="Round to backtest (1-5)")
    parser.add_argument("--days", type=int, nargs="*",
                        metavar="DAY", help=f"Days to run, omit to use all available days")
    parser.add_argument("--params", nargs="*", default=[],
                        metavar="KEY=VALUE", help="Strategy params, e.g. alpha=0.5 or alpha=0.1:0.5:0.1")
    parser.add_argument("--out", type=str, default=None,
                        metavar="DIR", help="Optional output directory for JSON .log files")

    args = parser.parse_args()

    # scan folder for available days
    available_days = scan_round(args.round)

    if args.days:
        # validate requested days against what actually exists
        invalid = [d for d in args.days if d not in available_days]
        if invalid:
            print(f"Error: days {invalid} not found for round {args.round}/", file=sys.stderr)
            print(f"       available days: {available_days}", file=sys.stderr)
            sys.exit(1)
        days = args.days
    else:
        days = available_days
        print(f"No days specified — using all available days for round {args.round}: {days}")

    # parse params
    param_grid: dict[str, list[float]] = {}
    for p in args.params:
        key, values = parse_param(p)
        if key in param_grid:
            print(f"Warning: param '{key}' specified more than once, using last value", file=sys.stderr)
        param_grid[key] = values

    # expand combinations into ready-to-use param maps
    param_sets: list[dict[str, float]] = []
    if param_grid:
        keys = list(param_grid.keys())
        for combination in itertools.product(*param_grid.values()):
            param_sets.append(dict(zip(keys, combination)))
    else:
        param_sets = [{}]

    is_grid = any(len(v) > 1 for v in param_grid.values())

    if args.out and is_grid:
        print("Error: --out is only supported for single-run backtests (no grid search)", file=sys.stderr)
        sys.exit(1)

    # summarize what's about to run
    n_combos = len(param_sets)
    n_runs = n_combos * len(days)
    if is_grid:
        print(f"Grid search: testing {n_combos} combinations, round {args.round}, days {days}")
    else:
        print(f"Single run: round {args.round}, days {days}"
              + (f", params {param_sets[0]}" if param_sets and param_sets[0] else ""))

    cwd = str(Path.cwd())
    script_dir = str(Path(__file__).parent.resolve())
    run_backtest(args.round, days, param_sets, is_grid, cwd, script_dir, args.out)