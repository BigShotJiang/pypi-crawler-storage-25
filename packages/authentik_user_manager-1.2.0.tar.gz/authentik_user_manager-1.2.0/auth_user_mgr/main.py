# SPDX-FileCopyrightText: 2025 DB Systel GmbH
#
# SPDX-License-Identifier: Apache-2.0

"""Module for managing Authentik users and group memberships via YAML configuration files.

This module provides functionality to synchronize user accounts and group memberships in
Authentik based on YAML configuration files. It supports user invitation management,
group membership synchronization, and provides a command-line interface for operations.
"""

import argparse
import logging

from . import __version__
from ._api import AuthentikAPI
from ._config import read_app_and_users_config
from ._email import Mail
from ._helpers import compare_two_lists
from ._user import User

# Main parser with root-level flags
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--version", action="version", version="%(prog)s " + __version__)

# Initiate first-level subcommands
subparsers = parser.add_subparsers(dest="command", help="Available commands", required=True)

# Common flags, usable for all effective subcommands
common_flags = argparse.ArgumentParser(add_help=False)  # No automatic help to avoid duplication
common_flags.add_argument("-v", "--verbose", action="store_true", help="Print INFO logging")
common_flags.add_argument("-vv", "--debug", action="store_true", help="Print DEBUG logging")

# SYNC commands
parser_sync = subparsers.add_parser(
    "sync", parents=[common_flags], help="Synchronise users to the Authentik instance"
)
parser_sync.add_argument("-c", "--config", help="Path to app config file", required=True)
parser_sync.add_argument(
    "-u", "--users", help="Path to user inventory file or directory", required=True
)
parser_sync.add_argument(
    "--dry",
    action="store_true",
    help="Run a dry sync which does not make any productive changes and does not send emails",
)
parser_sync.add_argument("--no-email", action="store_true", help="Do not send any emails")


def configure_logger(verbose: bool = False, debug: bool = False) -> logging.Logger:
    """
    Configure and return a logger with appropriate settings. If verbose or debug is False (default),
    logging level is WARNING.

    Args:
        verbose (bool, optional): If True, sets log level to INFO. Defaults to False.
        debug (bool, optional): If True, sets log level to DEBUG. Defaults to False.

    Returns:
        logging.Logger: Configured logger instance.
    """
    log = logging.getLogger()
    logging.basicConfig(
        format="[%(asctime)s] %(levelname)s: %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )
    if debug:
        log.setLevel(logging.DEBUG)
    elif verbose:
        log.setLevel(logging.INFO)
    else:
        log.setLevel(logging.WARNING)

    return log


def get_groups_of_users(
    api: AuthentikAPI,
) -> tuple[dict[int, list[str]], dict[str, str]]:
    """Build a mapping of user IDs to their current group memberships and a group name-to-UUID
    cache.

    Args:
        api (AuthentikAPI): Authentik API client instance.

    Returns:
        tuple: A tuple containing:
            - dict[int, list[str]]: A dictionary mapping user IDs to sorted lists of group names
                that the user belongs to.
            - dict[str, str]: A dictionary mapping group names to their UUIDs.
    """
    users_groups_mapping: dict[int, list[str]] = {}
    group_name_uuid_cache: dict[str, str] = {}
    for group_dict in api.list_groups():
        group_name = group_dict.get("name", "")
        group_uuid = str(group_dict.get("pk", ""))
        logging.debug("Processing screen of members of group %s", group_name)
        # Cache group name to UUID mapping
        if group_name and group_uuid:
            group_name_uuid_cache[group_name] = group_uuid
        # Iterate all members of this group
        for user_id in group_dict.get("users", []):
            # Initialise list of group names if not present, otherwise add to it
            if user_id not in users_groups_mapping:
                users_groups_mapping[user_id] = [group_name]
            else:
                users_groups_mapping[user_id].append(group_name)

    # Alphabetically sort the list of groups
    for user_id, groups in users_groups_mapping.items():
        users_groups_mapping[user_id] = sorted(groups)

    return users_groups_mapping, group_name_uuid_cache


class UserSync:
    """Orchestrates user synchronization and tracks sync statistics."""

    def __init__(  # noqa: PLR0913
        self,
        api: AuthentikAPI,
        mail: Mail,
        all_users_by_email: dict[str, dict],
        user_group_mapping: dict[int, list[str]],
        group_name_uuid_cache: dict[str, str],
        delete_unconfigured_users: bool = False,
    ) -> None:
        """Initialize UserSync with API clients, pre-fetched data, and empty stats."""
        self.api = api
        self.mail = mail
        self.all_users_by_email = all_users_by_email
        self.user_group_mapping = user_group_mapping
        self.group_name_uuid_cache = group_name_uuid_cache
        self.delete_unconfigured_users = delete_unconfigured_users

        # Stats
        self.users_unchanged: int = 0
        self.users_changed: int = 0
        self.users_pending: int = 0
        self.users_deleted: int = 0
        self.detail_messages: list[str] = []

    @staticmethod
    def _user_label(email: str, username: str) -> str:
        """Format a user identifier as 'email (username)' for display."""
        return f"{email} ({username})"

    def sync_user(self, user: User, invitation_template: str = "") -> None:
        """Synchronize a single user: check existence, handle invitations, sync groups.

        Args:
            user (User): User object to synchronize.
            invitation_template (str, optional): Path to a custom invitation template file.
                Defaults to an empty string in which case the inbuilt template is used.
        """
        if self.check_user_existence(user=user, invitation_template=invitation_template):
            if self.check_group_memberships(user=user):
                self.users_changed += 1
            else:
                self.users_unchanged += 1
        else:
            self.users_pending += 1

    def check_user_existence(self, user: User, invitation_template: str = "") -> bool:
        """Check if a user exists in Authentik and handle invitations accordingly.

        This method checks if a user exists, and if not, manages the invitation process.
        It also cleans up any pending invitations for existing users.

        Args:
            user (User): User object containing email and other user details.
            invitation_template (str, optional): Path to a custom invitation template file.
                Defaults to an empty string in which case the inbuilt template is used.

        Returns:
            bool: True if user exists, False if user needs to be invited.
        """
        logging.debug("Processing user %s", user.email)
        user_exists = self.all_users_by_email.get(user.email)
        # Check if user already exists
        if user_exists:
            # Add user ID
            user.id = user_exists.get("pk", 0)

            logging.info("User %s already exists (ID: %s)", user.email, user.id)

            # Check if user still has an still an invitation pending
            if invite_uuid := self.api.get_pending_invitation_uuid_for_email(user.email):
                logging.info(
                    "User %s has a pending invitation (UUID: %s) which will be deleted",
                    user.email,
                    invite_uuid,
                )
                self.detail_messages.append(
                    f"{self._user_label(user.email, user.username)}: "
                    f"deleting stale invitation {invite_uuid}"
                )
                # Delete invitation
                self.api.delete_invitation(invitation_uuid=invite_uuid)

            return True

        # Check if user is pending invitation. If not, create invitation
        if invite_url := self.api.get_pending_invitation_url_for_email(user.email):
            self.detail_messages.append(
                f"{self._user_label(user.email, user.username)}: "
                f"pending invitation: {invite_url}"
            )
        else:
            invitation_url = self.api.create_invitation(user=user)
            logging.info(
                "User %s does not exist and will be invited: %s", user.email, invitation_url
            )
            self.mail.send_email(
                recipient=user.email,
                message="invitation",
                template_file=invitation_template,
                link=invitation_url,
                invitation_expiry_days=self.api.invitation_expiry_days,
            )
            self.detail_messages.append(
                f"{self._user_label(user.email, user.username)}: "
                f"invitation created and sent: {invitation_url}"
            )

        return False

    def check_group_memberships(self, user: User) -> bool:
        """Compare and synchronize a user's configured and current group memberships.

        This method compares the user's configured group memberships with their current status
        and makes the necessary adjustments by adding or removing the user from groups.

        Args:
            user (User): User object containing current and configured group memberships.

        Returns:
            bool: True if any group membership changes were made, False otherwise.
        """
        # Compare configured group memberships with current status
        user.current_groups = self.user_group_mapping.get(user.id, [])

        # Compare configured and current group memberships
        delete_from_groups, in_sync, add_to_groups = compare_two_lists(
            user.configured_groups, user.current_groups
        )
        logging.debug(
            "User %s: %s",
            user.email,
            {
                "delete_from_groups": delete_from_groups,
                "in_sync": in_sync,
                "add_to_groups": add_to_groups,
            },
        )

        # Track whether any changes were made
        has_changes = bool(delete_from_groups or add_to_groups)

        # Delete user from groups
        for group in delete_from_groups:
            if group not in self.group_name_uuid_cache:
                self.group_name_uuid_cache[group] = self.api.get_group_uuid_by_name(group)
            logging.info("User %s will be removed from group '%s'", user.email, group)
            self.api.delete_user_from_group(
                user_id=user.id, group_uuid=self.group_name_uuid_cache[group]
            )
            self.detail_messages.append(
                f"{self._user_label(user.email, user.username)}: removed from group '{group}'"
            )

        # Add user to groups
        for group in add_to_groups:
            if group not in self.group_name_uuid_cache:
                self.group_name_uuid_cache[group] = self.api.get_group_uuid_by_name(group)
            logging.info("User %s will be added to group '%s'", user.email, group)
            self.api.add_user_to_group(
                user_id=user.id, group_uuid=self.group_name_uuid_cache[group]
            )
            self.detail_messages.append(
                f"{self._user_label(user.email, user.username)}: added to group '{group}'"
            )

        return has_changes

    def print_summary(self, total_users: int) -> None:
        """Print sync summary and detail messages.

        Args:
            total_users (int): Total number of configured users processed.
        """
        print(f"Sync summary: {total_users} users processed")
        print(f"  Unchanged: {self.users_unchanged}")
        print(f"  Changed:   {self.users_changed}")
        print(f"  Pending:   {self.users_pending}")
        print(f"  Deleted:   {self.users_deleted}")
        if self.detail_messages:
            print("\nDetails:")
            for msg in self.detail_messages:
                print(f"  {msg}")

    def handle_unconfigured_users(self, configured_emails: set[str]) -> None:
        """Delete users from Authentik that are not in the configured user inventory.

        Only deletes users of type 'internal'. Service accounts and other user types
        are skipped.

        Args:
            configured_emails (set[str]): Set of email addresses from the user configuration.
        """
        if not self.delete_unconfigured_users:
            return

        for email, user_dict in self.all_users_by_email.items():
            if email in configured_emails:
                continue
            # Only delete internal users, skip service accounts and other types
            user_type = user_dict.get("type", "")
            if user_type != "internal":
                logging.info("Skipping deletion of user %s (type: %s)", email, user_type)
                continue
            user_id = user_dict.get("pk", 0)
            username = user_dict.get("username", "")
            logging.info("Deleting unconfigured user %s (ID: %s)", email, user_id)
            self.api.delete_user(user_id=user_id)
            self.detail_messages.append(
                f"{self._user_label(email, username)}: deleted (not in user inventory)"
            )
            self.users_deleted += 1


def cli() -> None:
    """Command-line interface entry point for the Authentik user management tool.

    This function serves as the main entry point for the CLI tool. It handles command-line
    arguments, initializes logging, and orchestrates the synchronization of users and their group
    memberships with Authentik when the 'sync' command is used.

    Returns:
        None
    """
    args = parser.parse_args()
    configure_logger(verbose=args.verbose, debug=args.debug)

    if args.command == "sync":
        cfg_app, cfg_users = read_app_and_users_config(args.config, args.users)

        # Initiate classes
        api = AuthentikAPI(
            url=cfg_app.get("authentik_url", ""),
            token=cfg_app.get("authentik_token", ""),
            invitation_flow_slug=cfg_app.get("invitation_flow_slug", ""),
            create_missing_groups=cfg_app.get("create_missing_groups", False),
            invitation_expiry_days=cfg_app.get("invitation_expiry_days", 30),
            dry=args.dry,
        )
        mail = Mail(
            smtp_server=cfg_app.get("smtp_server", ""),
            smtp_port=cfg_app.get("smtp_port", ""),
            smtp_user=cfg_app.get("smtp_user", ""),
            smtp_password=cfg_app.get("smtp_password", ""),
            smtp_starttls=cfg_app.get("smtp_starttls", False),
            smtp_from=cfg_app.get("smtp_from", ""),
            dry=any([args.dry, args.no_email]),
        )
        mail.create_copy_with_details(
            subject_suffix="Invitation to create account",
            instance_url=cfg_app.get("authentik_url", ""),
            instance_title=cfg_app.get("authentik_title", ""),
        )

        # Get all current groups and their users, plus group name-to-uuid cache
        users_and_groups, group_name_uuid_cache = get_groups_of_users(api=api)

        # Fetch all users from Authentik upfront and build email lookup
        all_users_by_email: dict[str, dict] = {
            u["email"]: u
            for u in api.list_users()
            if u.get("email")  # only include users with email
        }

        # Initialize sync orchestrator
        sync = UserSync(
            api=api,
            mail=mail,
            all_users_by_email=all_users_by_email,
            user_group_mapping=users_and_groups,
            group_name_uuid_cache=group_name_uuid_cache,
            delete_unconfigured_users=cfg_app.get("delete_unconfigured_users", False),
        )

        # Iterate all configured users
        configured_emails: set[str] = set()
        for user_dict in cfg_users:
            user = User(
                name=user_dict.get("name", ""),
                email=user_dict.get("email", ""),
                configured_groups=user_dict.get("groups", []),
                username=user_dict.get("username", ""),
            )
            configured_emails.add(user.email)
            sync.sync_user(user=user)

        # Delete unconfigured users if enabled
        sync.handle_unconfigured_users(configured_emails=configured_emails)

        sync.print_summary(total_users=len(cfg_users))


if __name__ == "__main__":
    cli()
