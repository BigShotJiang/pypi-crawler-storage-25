from dataclasses import dataclass, field
from typing import List, Dict, Optional


@dataclass
class FieldDef:
    name: str
    datatype: str
    precision: int = 0
    scale: int = 0
    nullable: str = "NULL"
    keytype: str = "NOT A KEY"
    default_value: str = ""
    expression: str = ""
    expression_type: str = ""
    porttype: str = ""
    description: str = ""
    field_number: int = 0
    hidden: str = "NO"
    business_name: str = ""
    offset: int = 0
    physical_offset: int = 0
    physical_length: int = 0
    field_attributes: List[Dict[str, str]] = field(default_factory=list)


@dataclass
class TableAttribute:
    name: str
    value: str


@dataclass
class MetadataExtension:
    name: str
    value: str
    datatype: str = ""
    max_length: int = 0
    domain_name: str = ""
    description: str = ""
    is_reusable: str = "NO"
    is_shared_read: str = "NO"
    is_shared_write: str = "NO"
    is_uni_directional: str = "NO"


@dataclass
class FlatFileDef:
    name: str = ""
    delimiter: str = ","
    text_qualifier: str = ""
    escape_character: str = ""
    null_character: str = ""
    header_lines: int = 0
    code_page: str = ""
    strip_trailing_blanks: str = "NO"
    is_fixed_width: str = "NO"
    line_sequential: str = "YES"
    skip_rows: int = 0
    row_delimiter: str = ""
    attributes: List[TableAttribute] = field(default_factory=list)


@dataclass
class XmlInfoDef:
    name: str = ""
    xml_type: str = ""
    xml_version: str = ""
    dtd_url: str = ""
    root_element: str = ""
    namespace_uri: str = ""
    namespace_prefix: str = ""
    attributes: List[TableAttribute] = field(default_factory=list)
    xml_texts: List[Dict[str, str]] = field(default_factory=list)


@dataclass
class GroupDef:
    name: str
    type: str = ""
    description: str = ""
    order: int = 0
    expression: str = ""
    fields: List[FieldDef] = field(default_factory=list)


@dataclass
class KeywordDef:
    name: str
    value: str = ""


@dataclass
class ErpSrcInfoDef:
    name: str = ""
    source_type: str = ""
    attributes: List[TableAttribute] = field(default_factory=list)
    metadata: Dict[str, str] = field(default_factory=dict)


@dataclass
class ErpInfoDef:
    name: str = ""
    erp_type: str = ""
    attributes: List[TableAttribute] = field(default_factory=list)
    metadata: Dict[str, str] = field(default_factory=dict)


@dataclass
class SapOutputPortDef:
    name: str = ""
    datatype: str = ""
    precision: int = 0
    scale: int = 0
    porttype: str = ""
    description: str = ""


@dataclass
class SapVariableDef:
    name: str = ""
    datatype: str = ""
    default_value: str = ""
    description: str = ""
    precision: int = 0
    scale: int = 0


@dataclass
class SapTableParamDef:
    name: str = ""
    table_name: str = ""
    direction: str = ""
    description: str = ""
    attributes: List[TableAttribute] = field(default_factory=list)


@dataclass
class SapProgramFlowObjectDef:
    name: str = ""
    object_type: str = ""
    description: str = ""
    attributes: List[TableAttribute] = field(default_factory=list)


@dataclass
class SapStructureDef:
    name: str = ""
    structure_type: str = ""
    description: str = ""
    fields: List[FieldDef] = field(default_factory=list)
    attributes: List[TableAttribute] = field(default_factory=list)


@dataclass
class SapProgramDef:
    name: str = ""
    program_type: str = ""
    description: str = ""
    variables: List[SapVariableDef] = field(default_factory=list)
    flow_objects: List[SapProgramFlowObjectDef] = field(default_factory=list)
    attributes: List[TableAttribute] = field(default_factory=list)


@dataclass
class SapFunctionDef:
    name: str = ""
    function_type: str = ""
    description: str = ""
    structures: List[SapStructureDef] = field(default_factory=list)
    output_ports: List[SapOutputPortDef] = field(default_factory=list)
    variables: List[SapVariableDef] = field(default_factory=list)
    table_params: List[SapTableParamDef] = field(default_factory=list)
    programs: List[SapProgramDef] = field(default_factory=list)
    attributes: List[TableAttribute] = field(default_factory=list)


@dataclass
class TargetIndexFieldDef:
    name: str
    expression: str = ""
    sort_direction: str = "ASCENDING"


@dataclass
class TargetIndexDef:
    name: str
    index_type: str = ""
    unique: str = "NO"
    description: str = ""
    fields: List[TargetIndexFieldDef] = field(default_factory=list)


@dataclass
class SourceDef:
    name: str
    database_type: str = ""
    db_name: str = ""
    owner_name: str = ""
    description: str = ""
    business_name: str = ""
    fields: List[FieldDef] = field(default_factory=list)
    attributes: List[TableAttribute] = field(default_factory=list)
    metadata_extensions: List[MetadataExtension] = field(default_factory=list)
    flatfile: Optional[FlatFileDef] = None
    xmlinfo: Optional[XmlInfoDef] = None
    groups: List[GroupDef] = field(default_factory=list)
    keywords: List[KeywordDef] = field(default_factory=list)
    erp_src_info: Optional[ErpSrcInfoDef] = None


@dataclass
class TargetDef:
    name: str
    database_type: str = ""
    description: str = ""
    business_name: str = ""
    constraint: str = ""
    table_options: str = ""
    fields: List[FieldDef] = field(default_factory=list)
    attributes: List[TableAttribute] = field(default_factory=list)
    metadata_extensions: List[MetadataExtension] = field(default_factory=list)
    indexes: List[TargetIndexDef] = field(default_factory=list)
    flatfile: Optional[FlatFileDef] = None
    xmlinfo: Optional[XmlInfoDef] = None
    groups: List[GroupDef] = field(default_factory=list)
    keywords: List[KeywordDef] = field(default_factory=list)


@dataclass
class TransformFieldAttrDef:
    name: str
    value: str = ""
    field_name: str = ""


@dataclass
class TransformFieldAttrDefDef:
    name: str
    datatype: str = ""
    default_value: str = ""
    description: str = ""
    is_required: str = "NO"


@dataclass
class InitPropDef:
    name: str = ""
    value: str = ""


@dataclass
class TransformationDef:
    name: str
    type: str
    description: str = ""
    reusable: str = "NO"
    fields: List[FieldDef] = field(default_factory=list)
    attributes: List[TableAttribute] = field(default_factory=list)
    metadata: Dict[str, str] = field(default_factory=dict)
    field_attrs: List[TransformFieldAttrDef] = field(default_factory=list)
    field_attr_defs: List[TransformFieldAttrDefDef] = field(default_factory=list)
    init_props: List[InitPropDef] = field(default_factory=list)
    erp_info: Optional[ErpInfoDef] = None
    groups: List[GroupDef] = field(default_factory=list)
    metadata_extensions: List[MetadataExtension] = field(default_factory=list)
    sap_functions: List[SapFunctionDef] = field(default_factory=list)


@dataclass
class ConnectorDef:
    from_field: str
    from_instance: str
    from_instance_type: str
    to_field: str
    to_instance: str
    to_instance_type: str
    from_instance_group: str = ""
    to_instance_group: str = ""


@dataclass
class AssociatedSourceInstanceDef:
    name: str = ""
    source_instance: str = ""


@dataclass
class InstanceDef:
    name: str
    type: str
    transformation_name: str = ""
    transformation_type: str = ""
    description: str = ""
    reusable: str = "NO"
    associated_source_instances: List[AssociatedSourceInstanceDef] = field(default_factory=list)


@dataclass
class TargetLoadOrder:
    order: int = 1
    target_instance: str = ""


@dataclass
class MapDependencyDef:
    name: str = ""
    from_mapping: str = ""
    to_mapping: str = ""
    description: str = ""
    attributes: List[TableAttribute] = field(default_factory=list)


@dataclass
class FieldDependencyDef:
    name: str = ""
    from_field: str = ""
    from_instance: str = ""
    to_field: str = ""
    to_instance: str = ""
    expression: str = ""


@dataclass
class MappingVariable:
    name: str
    datatype: str = "string"
    default_value: str = ""
    description: str = ""
    is_expression_variable: str = "NO"
    is_persistent: str = "NO"
    precision: int = 0
    scale: int = 0
    usage_type: str = ""


@dataclass
class MappingDef:
    name: str
    description: str = ""
    is_valid: str = "YES"
    sources: List[SourceDef] = field(default_factory=list)
    targets: List[TargetDef] = field(default_factory=list)
    transformations: List[TransformationDef] = field(default_factory=list)
    connectors: List[ConnectorDef] = field(default_factory=list)
    instances: List[InstanceDef] = field(default_factory=list)
    target_load_orders: List[TargetLoadOrder] = field(default_factory=list)
    variables: List[MappingVariable] = field(default_factory=list)
    metadata: Dict[str, str] = field(default_factory=dict)
    metadata_extensions: List[MetadataExtension] = field(default_factory=list)
    map_dependencies: List[MapDependencyDef] = field(default_factory=list)
    field_dependencies: List[FieldDependencyDef] = field(default_factory=list)


@dataclass
class ConnectionRef:
    connection_name: str = ""
    connection_type: str = ""
    connection_subtype: str = ""
    component_version: str = ""
    variable: str = ""


@dataclass
class HashKeyDef:
    name: str = ""
    expression: str = ""


@dataclass
class KeyRangeDef:
    name: str = ""
    low_value: str = ""
    high_value: str = ""


@dataclass
class PartitionDef:
    name: str = ""
    partition_type: str = ""
    description: str = ""
    hash_keys: List[HashKeyDef] = field(default_factory=list)
    key_ranges: List[KeyRangeDef] = field(default_factory=list)
    attributes: List[TableAttribute] = field(default_factory=list)


@dataclass
class SessionTransformInst:
    instance_name: str = ""
    pipeline: str = ""
    stage: str = ""
    transformation_name: str = ""
    transformation_type: str = ""
    is_partitionable: str = "NO"
    attributes: List[TableAttribute] = field(default_factory=list)
    connections: List[ConnectionRef] = field(default_factory=list)
    partitions: List[PartitionDef] = field(default_factory=list)


@dataclass
class SessionTransformGroupDef:
    name: str = ""
    description: str = ""
    transform_instances: List[SessionTransformInst] = field(default_factory=list)
    attributes: List[TableAttribute] = field(default_factory=list)


@dataclass
class SessionDef:
    name: str
    mapping_name: str = ""
    description: str = ""
    is_valid: str = "YES"
    reusable: str = "NO"
    transform_instances: List[SessionTransformInst] = field(default_factory=list)
    transform_groups: List[SessionTransformGroupDef] = field(default_factory=list)
    attributes: List[TableAttribute] = field(default_factory=list)
    config_references: List[Dict[str, str]] = field(default_factory=list)
    connections: List[ConnectionRef] = field(default_factory=list)
    components: List[Dict] = field(default_factory=list)
    metadata_extensions: List[MetadataExtension] = field(default_factory=list)


@dataclass
class TimerDef:
    name: str = ""
    start_type: str = ""
    start_date: str = ""
    start_time: str = ""
    end_type: str = ""
    end_date: str = ""
    end_time: str = ""
    attributes: List[TableAttribute] = field(default_factory=list)


@dataclass
class TaskInstanceDef:
    name: str
    task_name: str = ""
    task_type: str = ""
    description: str = ""
    is_valid: str = "YES"
    reusable: str = "NO"
    fail_parent_if_instance_fails: str = "YES"
    fail_parent_if_instance_did_not_run: str = "NO"
    treat_input_link_as_and: str = "YES"
    attributes: List[TableAttribute] = field(default_factory=list)


@dataclass
class WorkflowLink:
    from_instance: str
    to_instance: str
    condition: str = ""
    link_type: str = ""


@dataclass
class WorkflowVariable:
    name: str
    datatype: str = "string"
    default_value: str = ""
    description: str = ""
    is_null: str = "NO"
    is_persistent: str = "NO"
    is_user_defined: str = "YES"
    precision: int = 0
    scale: int = 0
    usage_type: str = ""


@dataclass
class WorkflowEventDef:
    name: str
    event_type: str = ""
    description: str = ""
    is_valid: str = "YES"
    attributes: List[TableAttribute] = field(default_factory=list)


@dataclass
class ScheduleInfoDef:
    schedule_type: str = ""
    attributes: Dict[str, str] = field(default_factory=dict)


@dataclass
class StartOptionsDef:
    attributes: Dict[str, str] = field(default_factory=dict)


@dataclass
class EndOptionsDef:
    attributes: Dict[str, str] = field(default_factory=dict)


@dataclass
class ScheduleOptionsDef:
    attributes: Dict[str, str] = field(default_factory=dict)


@dataclass
class RecurringDef:
    attributes: Dict[str, str] = field(default_factory=dict)


@dataclass
class CustomScheduleDef:
    attributes: Dict[str, str] = field(default_factory=dict)


@dataclass
class DailyFrequencyDef:
    attributes: Dict[str, str] = field(default_factory=dict)


@dataclass
class RepeatDef:
    attributes: Dict[str, str] = field(default_factory=dict)


@dataclass
class SchedulerFilterDef:
    attributes: Dict[str, str] = field(default_factory=dict)


@dataclass
class SchedulerDef:
    name: str
    description: str = ""
    reusable: str = "NO"
    attributes: List[TableAttribute] = field(default_factory=list)
    schedule_info: Optional[ScheduleInfoDef] = None
    start_options: Optional[StartOptionsDef] = None
    end_options: Optional[EndOptionsDef] = None
    schedule_options: Optional[ScheduleOptionsDef] = None
    recurring: Optional[RecurringDef] = None
    custom: Optional[CustomScheduleDef] = None
    daily_frequency: Optional[DailyFrequencyDef] = None
    repeat: Optional[RepeatDef] = None
    scheduler_filter: Optional[SchedulerFilterDef] = None


@dataclass
class WorkflowDef:
    name: str
    description: str = ""
    is_valid: str = "YES"
    reusable: str = "NO"
    scheduler_name: str = ""
    task_instances: List[TaskInstanceDef] = field(default_factory=list)
    links: List[WorkflowLink] = field(default_factory=list)
    variables: List[WorkflowVariable] = field(default_factory=list)
    events: List[WorkflowEventDef] = field(default_factory=list)
    attributes: List[TableAttribute] = field(default_factory=list)
    metadata: Dict[str, str] = field(default_factory=dict)
    metadata_extensions: List[MetadataExtension] = field(default_factory=list)


@dataclass
class ConfigDef:
    name: str
    description: str = ""
    is_valid: str = "YES"
    attributes: List[TableAttribute] = field(default_factory=list)
    metadata_extensions: List[MetadataExtension] = field(default_factory=list)


@dataclass
class MappletDef:
    name: str
    description: str = ""
    is_valid: str = "YES"
    transformations: List[TransformationDef] = field(default_factory=list)
    connectors: List[ConnectorDef] = field(default_factory=list)
    instances: List[InstanceDef] = field(default_factory=list)
    metadata_extensions: List[MetadataExtension] = field(default_factory=list)
    map_dependencies: List[MapDependencyDef] = field(default_factory=list)
    field_dependencies: List[FieldDependencyDef] = field(default_factory=list)


@dataclass
class ShortcutDef:
    name: str
    shortcut_type: str = ""
    reference_name: str = ""
    folder_name: str = ""
    repository_name: str = ""
    object_type: str = ""
    object_subtype: str = ""
    dbdname: str = ""
    version_number: int = 0


@dataclass
class ValuePairDef:
    name: str
    value: str = ""
    type: str = ""


@dataclass
class TaskDef:
    name: str
    type: str = ""
    description: str = ""
    reusable: str = "NO"
    attributes: List[TableAttribute] = field(default_factory=list)
    value_pairs: List[ValuePairDef] = field(default_factory=list)
    timer: Optional[TimerDef] = None
    metadata_extensions: List[MetadataExtension] = field(default_factory=list)


@dataclass
class FolderVersionDef:
    folder_name: str = ""
    version_number: int = 0
    repository_name: str = ""
    description: str = ""
    attributes: Dict[str, str] = field(default_factory=dict)


@dataclass
class FolderDef:
    name: str
    owner: str = ""
    description: str = ""
    group: str = ""
    shared: str = "NOTSHARED"
    permissions: str = ""
    sources: List[SourceDef] = field(default_factory=list)
    targets: List[TargetDef] = field(default_factory=list)
    mappings: List[MappingDef] = field(default_factory=list)
    mapplets: List[MappletDef] = field(default_factory=list)
    sessions: List[SessionDef] = field(default_factory=list)
    workflows: List[WorkflowDef] = field(default_factory=list)
    tasks: List[TaskDef] = field(default_factory=list)
    configs: List[ConfigDef] = field(default_factory=list)
    schedulers: List[SchedulerDef] = field(default_factory=list)
    shortcuts: List[ShortcutDef] = field(default_factory=list)
    transformations: List[TransformationDef] = field(default_factory=list)
    folder_versions: List[FolderVersionDef] = field(default_factory=list)
    metadata_extensions: List[MetadataExtension] = field(default_factory=list)


@dataclass
class RepositoryDef:
    name: str
    version: str = ""
    codepage: str = ""
    database_type: str = ""
    folders: List[FolderDef] = field(default_factory=list)


@dataclass
class PowermartDef:
    creation_date: str = ""
    repository_version: str = ""
    repositories: List[RepositoryDef] = field(default_factory=list)
