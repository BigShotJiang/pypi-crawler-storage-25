import re


INFA_FUNC_MAP = {
    "IIF": "iif_expr",
    "DECODE": "decode_expr",
    "CHOOSE": "choose_expr",
    "IN": "in_expr",
    "LTRIM": "ltrim",
    "RTRIM": "rtrim",
    "TRIM": "trim_func",
    "UPPER": "upper",
    "LOWER": "lower",
    "INITCAP": "initcap",
    "SUBSTR": "substr",
    "LPAD": "lpad",
    "RPAD": "rpad",
    "REVERSE": "reverse_str",
    "CHR": "chr_func",
    "ASCII": "ascii_func",
    "LEFT": "left_str",
    "RIGHT": "right_str",
    "INDEXOF": "indexof",
    "METAPHONE": "metaphone_func",
    "SOUNDEX": "soundex_func",
    "COMPRESS": "compress_func",
    "DECOMPRESS": "decompress_func",
    "TO_CHAR": "to_char",
    "TO_DATE": "to_date",
    "TO_TIMESTAMP": "to_timestamp_func",
    "TO_INTEGER": "to_integer",
    "TO_BIGINT": "to_bigint",
    "TO_FLOAT": "to_float",
    "TO_DECIMAL": "to_decimal",
    "CAST": "cast_func",
    "SYSDATE": "current_timestamp",
    "SYSTIMESTAMP": "current_timestamp",
    "SESSSTARTTIME": "session_start_time",
    "GET_DATE_PART": "get_date_part",
    "SET_DATE_PART": "set_date_part",
    "ADD_TO_DATE": "add_to_date",
    "DATE_DIFF": "date_diff",
    "DATE_COMPARE": "date_compare",
    "LAST_DAY": "last_day",
    "MAKE_DATE_TIME": "make_date_time",
    "TRUNC": "trunc",
    "ROUND": "round_val",
    "ABS": "abs_val",
    "CEIL": "ceil_val",
    "CEILING": "ceil_val",
    "FLOOR": "floor_val",
    "MOD": "mod_val",
    "POWER": "power_val",
    "SQRT": "sqrt_val",
    "LOG": "log_val",
    "LN": "ln_val",
    "EXP": "exp_val",
    "SIGN": "sign_val",
    "RAND": "rand_val",
    "GREATEST": "greatest_val",
    "LEAST": "least_val",
    "LENGTH": "length",
    "CONCAT": "concat",
    "INSTR": "instr",
    "REPLACECHR": "replacechr",
    "REPLACESTR": "replacestr",
    "REG_EXTRACT": "reg_extract",
    "REG_MATCH": "reg_match",
    "REG_REPLACE": "reg_replace",
    "IS_DATE": "is_date",
    "IS_NUMBER": "is_number",
    "IS_SPACES": "is_spaces",
    "NVL": "nvl",
    "NVL2": "nvl2",
    "ISNULL": "isnull",
    "ERROR": "raise_error",
    "ABORT": "abort_func",
    "LOOKUP": "lookup_func",
    "MAX": "max_val",
    "MIN": "min_val",
    "SUM": "sum_val",
    "COUNT": "count_val",
    "AVG": "avg_val",
    "MEDIAN": "median_val",
    "STDDEV": "stddev_val",
    "VARIANCE": "variance_val",
    "PERCENTILE": "percentile_val",
    "FIRST": "first_val",
    "LAST": "last_val",
    "MOVINGAVG": "moving_avg",
    "MOVINGSUM": "moving_sum",
    "CUME": "cume",
    "SETCOUNTVARIABLE": "set_count_variable",
    "SETVARIABLE": "set_variable",
}


AGG_FUNC_NAMES = [
    "MOVINGAVG", "MOVINGSUM", "PERCENTILE", "VARIANCE",
    "STDDEV", "MEDIAN", "COUNT", "FIRST", "LAST",
    "CUME", "SUM", "AVG", "MAX", "MIN",
]


def _find_matching_paren(text, start):
    depth = 0
    i = start
    in_string = False
    str_char = None
    while i < len(text):
        ch = text[i]
        if in_string:
            if ch == str_char and (i == 0 or text[i - 1] != '\\'):
                in_string = False
        else:
            if ch in ("'", '"'):
                in_string = True
                str_char = ch
            elif ch == '(':
                depth += 1
            elif ch == ')':
                depth -= 1
                if depth == 0:
                    return i
        i += 1
    return -1


def _split_args(text):
    args = []
    depth = 0
    current = []
    in_string = False
    str_char = None
    for i, ch in enumerate(text):
        if in_string:
            current.append(ch)
            if ch == str_char and (i == 0 or text[i - 1] != '\\'):
                in_string = False
        elif ch in ("'", '"'):
            in_string = True
            str_char = ch
            current.append(ch)
        elif ch == '(':
            depth += 1
            current.append(ch)
        elif ch == ')':
            depth -= 1
            current.append(ch)
        elif ch == ',' and depth == 0:
            args.append(''.join(current).strip())
            current = []
        else:
            current.append(ch)
    if current:
        args.append(''.join(current).strip())
    return args


def _find_func_call(text, func_name):
    pattern = re.compile(r'\b' + re.escape(func_name) + r'\s*\(', re.IGNORECASE)
    m = pattern.search(text)
    if not m:
        return None
    paren_start = m.end() - 1
    paren_end = _find_matching_paren(text, paren_start)
    if paren_end == -1:
        return None
    inner = text[paren_start + 1:paren_end]
    args = _split_args(inner)
    return (m.start(), paren_end + 1, args)


def convert_expression(expr):
    if not expr or not expr.strip():
        return "None"

    cleaned = expr.strip()

    if re.match(r'^[A-Za-z_][A-Za-z0-9_]*$', cleaned):
        return f'row["{cleaned}"]'

    if re.match(r'^-?\d+(\.\d+)?$', cleaned):
        return cleaned

    if cleaned.startswith("'") and cleaned.endswith("'"):
        close_pos = cleaned.find("'", 1)
        if close_pos == len(cleaned) - 1:
            return cleaned

    converted = cleaned

    for infa_func, py_func in sorted(INFA_FUNC_MAP.items(), key=lambda x: -len(x[0])):
        pattern = re.compile(r'\b' + re.escape(infa_func) + r'\s*\(', re.IGNORECASE)
        converted = pattern.sub(f'{py_func}(', converted)

    converted = converted.replace("||", " + ")

    converted = re.sub(r'\bAND\b', ' and ', converted, flags=re.IGNORECASE)
    converted = re.sub(r'\bOR\b', ' or ', converted, flags=re.IGNORECASE)
    converted = re.sub(r'\bNOT\b', ' not ', converted, flags=re.IGNORECASE)

    converted = re.sub(r'<>', '!=', converted)

    converted = re.sub(r'(?<![<>!])=(?!=)', '==', converted)

    converted = re.sub(r':LKP\.(\w+)\(', r'lookup_func("\1", ', converted)

    converted = re.sub(r'\$\$(\w+)', r'get_variable("\1")', converted)

    converted = re.sub(r':(\w+)', r'row["\1"]', converted)

    converted = re.sub(r'\bTRUE\b', 'True', converted)
    converted = re.sub(r'\bFALSE\b', 'False', converted)
    converted = re.sub(r'\bNULL\b', 'None', converted)

    converted = re.sub(r'\s+', ' ', converted).strip()

    return converted


VECTORIZED_FUNC_MAP = {
    "UPPER": (".str.upper()", 1),
    "LOWER": (".str.lower()", 1),
    "LTRIM": (".str.lstrip()", 1),
    "RTRIM": (".str.rstrip()", 1),
    "TRIM": (".str.strip()", 1),
    "LENGTH": (".str.len()", 1),
    "INITCAP": (".str.title()", 1),
    "REVERSE": (".str[::-1]", 1),
}

VECTORIZED_TWARG_MAP = {
    "SUBSTR": "str_substr_vec",
    "LPAD": "str_lpad_vec",
    "RPAD": "str_rpad_vec",
    "INSTR": "str_instr_vec",
    "REPLACECHR": "str_replacechr_vec",
    "REPLACESTR": "str_replacestr_vec",
    "REG_EXTRACT": "str_reg_extract_vec",
    "REG_REPLACE": "str_reg_replace_vec",
    "CONCAT": "concat_vec",
}


def _convert_infa_date_format(fmt_str):
    fmt = fmt_str.strip("'\"")
    fmt = fmt.replace("YYYY", "%Y").replace("YY", "%y")
    fmt = fmt.replace("MM", "%m").replace("DD", "%d")
    fmt = fmt.replace("Mon", "%b").replace("MON", "%b")
    fmt = fmt.replace("HH24", "%H").replace("HH12", "%I").replace("HH", "%H")
    fmt = fmt.replace("MI", "%M").replace("SS", "%S")
    fmt = fmt.replace("US", "%f").replace("NS", "%f").replace("MS", "%f")
    return fmt


def _substitute_fields(text, df_var, skip_words):
    result = []
    i = 0
    df_base = df_var
    while i < len(text):
        ch = text[i]
        if ch in ("'", '"'):
            end = text.find(ch, i + 1)
            if end == -1:
                result.append(text[i:])
                break
            result.append(text[i:end + 1])
            i = end + 1
            continue
        m = re.match(r'[A-Za-z_][A-Za-z0-9_]*', text[i:])
        if m:
            word = m.group(0)
            before_ok = (i == 0 or text[i - 1] not in ('"', '.'))
            after_pos = i + len(word)
            after_ok = (after_pos >= len(text) or text[after_pos] not in ('"', '(', '.', '['))
            if (before_ok and after_ok
                    and word not in skip_words
                    and not word.endswith('_vec')
                    and not text[i:].startswith(df_base)):
                result.append(f'{df_var}["{word}"]')
            else:
                result.append(word)
            i += len(word)
        else:
            result.append(ch)
            i += 1
    return ''.join(result)


def _resolve_char_arg(arg, df_var):
    arg = arg.strip()
    chr_match = re.match(r'^CHR\s*\(\s*(\d+)\s*\)$', arg, re.IGNORECASE)
    if chr_match:
        return chr(int(chr_match.group(1)))
    if arg.startswith("'") and arg.endswith("'"):
        return arg[1:-1]
    if arg.startswith('"') and arg.endswith('"'):
        return arg[1:-1]
    return arg


def _strip_inline_comments(text):
    result = []
    i = 0
    in_string = False
    str_char = None
    depth = 0
    while i < len(text):
        ch = text[i]
        if in_string:
            result.append(ch)
            if ch == str_char and (i == 0 or text[i - 1] != '\\'):
                in_string = False
        elif ch in ("'", '"'):
            in_string = True
            str_char = ch
            result.append(ch)
        elif ch == '(':
            depth += 1
            result.append(ch)
        elif ch == ')':
            depth -= 1
            result.append(ch)
        elif ch == '-' and i + 1 < len(text) and text[i + 1] == '-' and depth == 0:
            break
        else:
            result.append(ch)
        i += 1
    return ''.join(result).strip()


def _trunc_vec(va):
    if len(va) == 1:
        return f'np.trunc({va[0]})'
    raw2 = va[1].strip()
    if re.match(r'^-?\d+$', raw2):
        n = int(raw2)
        if n == 0:
            return f'np.trunc({va[0]})'
        return f'(np.trunc({va[0]} * 10**{n}) / 10**{n})'
    fmt = raw2.strip("'\"").upper()
    if fmt in ('DD', 'D'):
        return f'{va[0]}.dt.floor("D")'
    elif fmt in ('MM', 'MON', 'MONTH'):
        return f'{va[0]}.dt.to_period("M").dt.to_timestamp()'
    elif fmt in ('YY', 'YYYY', 'YEAR'):
        return f'{va[0]}.dt.to_period("Y").dt.to_timestamp()'
    elif fmt in ('HH', 'HH24'):
        return f'{va[0]}.dt.floor("H")'
    return f'{va[0]}.dt.floor("{fmt}")'


_VEC_INLINE = {
    'TO_INTEGER': lambda va: f'pd.to_numeric({va[0]}, errors="coerce").fillna(0).astype(int)',
    'TO_BIGINT': lambda va: f'pd.to_numeric({va[0]}, errors="coerce").astype("Int64")',
    'TO_FLOAT': lambda va: f'pd.to_numeric({va[0]}, errors="coerce")',
    'TO_DECIMAL': lambda va: f'pd.to_numeric({va[0]}, errors="coerce")',
    'LENGTH': lambda va: f'{va[0]}.str.len()',
    'ROUND': lambda va: (f'np.round({va[0]}, {va[1]})' if len(va) >= 2 else f'np.round({va[0]})'),
    'ABS': lambda va: f'np.abs({va[0]})',
    'CEIL': lambda va: f'np.ceil({va[0]})',
    'CEILING': lambda va: f'np.ceil({va[0]})',
    'FLOOR': lambda va: f'np.floor({va[0]})',
    'MOD': lambda va: (f'({va[0]} % {va[1]})' if len(va) >= 2 else va[0]),
    'POWER': lambda va: (f'np.power({va[0]}, {va[1]})' if len(va) >= 2 else va[0]),
    'SQRT': lambda va: f'np.sqrt({va[0]})',
    'LOG': lambda va: f'np.log10({va[0]})',
    'LN': lambda va: f'np.log({va[0]})',
    'EXP': lambda va: f'np.exp({va[0]})',
    'SIGN': lambda va: f'np.sign({va[0]})',
    'NVL': lambda va: (f'{va[0]}.fillna({va[1]})' if len(va) >= 2 else va[0]),
    'ISNULL': lambda va: f'{va[0]}.isna()',
    'IIF': lambda va: (f'np.where({va[0]}, {va[1]}, {va[2]})' if len(va) >= 3
                        else (f'np.where({va[0]}, {va[1]}, None)' if len(va) >= 2 else va[0])),
    'IS_NUMBER': lambda va: f'pd.to_numeric({va[0]}, errors="coerce").notna()',
    'IS_SPACES': lambda va: f'{va[0]}.str.strip().eq("")',
    'UPPER': lambda va: f'{va[0]}.str.upper()',
    'LOWER': lambda va: f'{va[0]}.str.lower()',
    'TRUNC': _trunc_vec,
}

_VEC_FUNC_ORDER = sorted(
    set(list(_VEC_INLINE.keys()) + list(INFA_FUNC_MAP.keys())),
    key=lambda x: -len(x),
)


def _convert_remaining_funcs(text, df_var):
    converted = text
    for fn in _VEC_FUNC_ORDER:
        safety = 10
        offset = 0
        while safety > 0:
            safety -= 1
            fr = _find_func_call(converted[offset:], fn)
            if not fr:
                break
            rel_start, rel_end, raw_args = fr
            abs_start = offset + rel_start
            abs_end = offset + rel_end
            if abs_start > 0 and converted[abs_start - 1] == '.':
                offset = abs_end
                continue
            va = [_vec_recursive(a.strip(), df_var) for a in raw_args] if raw_args else []
            if fn in _VEC_INLINE and va:
                repl = _VEC_INLINE[fn](va)
            elif fn in INFA_FUNC_MAP:
                py_func = INFA_FUNC_MAP[fn]
                repl = f'{py_func}({", ".join(va)})'
            else:
                break
            converted = converted[:abs_start] + repl + converted[abs_end:]
            offset = abs_start + len(repl)
    return converted


def _vec_recursive(expr, df_var):
    if not expr or not expr.strip():
        return "None"

    cleaned = expr.strip()

    if '--' in cleaned:
        cleaned = _strip_inline_comments(cleaned)
        if not cleaned:
            return "None"

    if re.match(r'^-?\d+(\.\d+)?$', cleaned):
        return cleaned

    if cleaned.startswith("'") and cleaned.endswith("'"):
        close_pos = cleaned.find("'", 1)
        if close_pos == len(cleaned) - 1:
            return cleaned

    upper = cleaned.upper()

    if upper == 'NULL':
        return 'None'
    if upper == 'TRUE':
        return 'True'
    if upper == 'FALSE':
        return 'False'
    if upper == 'SYSDATE' or upper == 'SYSTIMESTAMP':
        return 'pd.Timestamp.now()'
    if re.match(r'^SYSTIMESTAMP\s*\(\s*\)$', cleaned, re.IGNORECASE):
        return 'pd.Timestamp.now()'
    if re.match(r'^SYSDATE\s*\(\s*\)$', cleaned, re.IGNORECASE):
        return 'pd.Timestamp.now()'

    if re.match(r'^[A-Za-z_][A-Za-z0-9_]*$', cleaned):
        return f'{df_var}["{cleaned}"]'

    if re.match(r'^\$\$\w+$', cleaned):
        var_name = cleaned[2:]
        return f'get_variable("{var_name}")'

    if re.match(r'^\$PM\w+$', cleaned):
        var_name = cleaned[1:]
        return f'resolve_builtin_variable("{var_name}")'

    not_result = _find_func_call(cleaned, 'NOT')
    if not_result and not_result[0] == 0 and not_result[1] == len(cleaned):
        _, _, args = not_result
        if len(args) >= 1:
            inner = _vec_recursive(args[0], df_var)
            return f'~({inner})'

    lkp_result = _find_func_call(cleaned, 'LKP')
    if lkp_result is None:
        lkp_match = re.match(r'^:LKP\.(\w+)\s*\(', cleaned, re.IGNORECASE)
        if lkp_match:
            lkp_name = lkp_match.group(1)
            paren_start = cleaned.index('(')
            paren_end = _find_matching_paren(cleaned, paren_start)
            if paren_end != -1:
                inner = cleaned[paren_start + 1:paren_end]
                args = _split_args(inner)
                vec_args = ', '.join(_vec_recursive(a, df_var) for a in args)
                return f'lookup_func("{lkp_name}", {vec_args})'

    unconnected_lkp = re.match(r'^:(\w+)\.(\w+)\s*\(', cleaned, re.IGNORECASE)
    if unconnected_lkp:
        port_group = unconnected_lkp.group(1)
        lkp_name = unconnected_lkp.group(2)
        paren_start = cleaned.index('(')
        paren_end = _find_matching_paren(cleaned, paren_start)
        if paren_end != -1:
            rest = cleaned[paren_end + 1:].strip()
            inner = cleaned[paren_start + 1:paren_end]
            args = _split_args(inner)
            vec_args = ', '.join(_vec_recursive(a, df_var) for a in args)
            result = f'lookup_func("{lkp_name}", {vec_args})'
            if rest:
                result = result + ' ' + _vec_recursive(rest, df_var)
            return result

    iif_result = _find_func_call(cleaned, 'IIF')
    if iif_result and iif_result[0] == 0 and iif_result[1] == len(cleaned):
        _, _, args = iif_result
        if len(args) >= 3:
            cond = _vectorize_condition(args[0], df_var)
            true_val = _vec_recursive(args[1], df_var)
            false_val = _vec_recursive(args[2], df_var)
            return f"np.where({cond}, {true_val}, {false_val})"
        elif len(args) == 2:
            cond = _vectorize_condition(args[0], df_var)
            true_val = _vec_recursive(args[1], df_var)
            return f"np.where({cond}, {true_val}, None)"

    decode_result = _find_func_call(cleaned, 'DECODE')
    if decode_result and decode_result[0] == 0 and decode_result[1] == len(cleaned):
        _, _, args = decode_result
        if len(args) >= 3:
            first_arg = args[0].strip().upper()
            if first_arg == 'TRUE':
                pairs = args[1:]
                if len(pairs) % 2 == 1:
                    default_val = _vec_recursive(pairs[-1], df_var)
                    pairs = pairs[:-1]
                else:
                    default_val = 'None'
                result = default_val
                for i in range(len(pairs) - 2, -1, -2):
                    cond = _vectorize_condition(pairs[i], df_var)
                    val = _vec_recursive(pairs[i + 1], df_var)
                    result = f"np.where({cond}, {val}, {result})"
                return result
            else:
                switch_val = _vec_recursive(args[0], df_var)
                pairs = args[1:]
                if len(pairs) % 2 == 1:
                    default_val = _vec_recursive(pairs[-1], df_var)
                    pairs = pairs[:-1]
                else:
                    default_val = 'None'
                result = default_val
                for i in range(len(pairs) - 2, -1, -2):
                    case_val = _vec_recursive(pairs[i], df_var)
                    then_val = _vec_recursive(pairs[i + 1], df_var)
                    result = f"np.where({switch_val} == {case_val}, {then_val}, {result})"
                return result

    nvl_result = _find_func_call(cleaned, 'NVL')
    if nvl_result and nvl_result[0] == 0 and nvl_result[1] == len(cleaned):
        _, _, args = nvl_result
        if len(args) == 2:
            field_val = _vec_recursive(args[0], df_var)
            default_val = _vec_recursive(args[1], df_var)
            return f'{field_val}.fillna({default_val})'

    for func_name in ('LTRIM', 'RTRIM', 'TRIM'):
        result = _find_func_call(cleaned, func_name)
        if result and result[0] == 0 and result[1] == len(cleaned):
            _, _, args = result
            if len(args) >= 1:
                inner_val = _vec_recursive(args[0], df_var)
                method_map = {'LTRIM': '.str.lstrip()', 'RTRIM': '.str.rstrip()', 'TRIM': '.str.strip()'}
                if len(args) >= 2:
                    char_arg = args[1].strip().strip("'\"")
                    method_map = {
                        'LTRIM': f'.str.lstrip("{char_arg}")',
                        'RTRIM': f'.str.rstrip("{char_arg}")',
                        'TRIM': f'.str.strip("{char_arg}")',
                    }
                return f'{inner_val}.astype(str){method_map[func_name.upper()]}'

    upper_result = _find_func_call(cleaned, 'UPPER')
    if upper_result and upper_result[0] == 0 and upper_result[1] == len(cleaned):
        _, _, args = upper_result
        if len(args) >= 1:
            inner_val = _vec_recursive(args[0], df_var)
            return f'{inner_val}.str.upper()'

    lower_result = _find_func_call(cleaned, 'LOWER')
    if lower_result and lower_result[0] == 0 and lower_result[1] == len(cleaned):
        _, _, args = lower_result
        if len(args) >= 1:
            inner_val = _vec_recursive(args[0], df_var)
            return f'{inner_val}.str.lower()'

    initcap_result = _find_func_call(cleaned, 'INITCAP')
    if initcap_result and initcap_result[0] == 0 and initcap_result[1] == len(cleaned):
        _, _, args = initcap_result
        if len(args) >= 1:
            inner_val = _vec_recursive(args[0], df_var)
            return f'{inner_val}.str.title()'

    length_result = _find_func_call(cleaned, 'LENGTH')
    if length_result and length_result[0] == 0 and length_result[1] == len(cleaned):
        _, _, args = length_result
        if len(args) >= 1:
            inner_val = _vec_recursive(args[0], df_var)
            return f'{inner_val}.str.len()'

    substr_result = _find_func_call(cleaned, 'SUBSTR')
    if substr_result and substr_result[0] == 0 and substr_result[1] == len(cleaned):
        _, _, args = substr_result
        if len(args) >= 2:
            field_val = _vec_recursive(args[0], df_var)
            try:
                start = max(int(args[1].strip()) - 1, 0)
            except ValueError:
                start_val = _vec_recursive(args[1], df_var)
                if len(args) >= 3:
                    length_val = _vec_recursive(args[2], df_var)
                    return f'{field_val}.str[{start_val} - 1:{start_val} - 1 + {length_val}]'
                return f'{field_val}.str[{start_val} - 1:]'
            if len(args) >= 3:
                try:
                    length = int(args[2].strip())
                    end = start + length
                    return f'{field_val}.str[{start}:{end}]'
                except ValueError:
                    length_val = _vec_recursive(args[2], df_var)
                    return f'{field_val}.str[{start}:{start} + {length_val}]'
            return f'{field_val}.str[{start}:]'

    instr_result = _find_func_call(cleaned, 'INSTR')
    if instr_result and instr_result[0] == 0 and instr_result[1] == len(cleaned):
        _, _, args = instr_result
        if len(args) >= 2:
            field_val = _vec_recursive(args[0], df_var)
            search_val = args[1].strip().strip("'\"")
            return f'{field_val}.str.find("{search_val}")'

    replacechr_result = _find_func_call(cleaned, 'REPLACECHR')
    if replacechr_result and replacechr_result[0] == 0 and replacechr_result[1] == len(cleaned):
        _, _, args = replacechr_result
        if len(args) >= 3:
            if len(args) >= 4:
                src_val = _vec_recursive(args[1], df_var)
                old_arg = args[2].strip()
                new_arg = args[3].strip()
            else:
                src_val = _vec_recursive(args[0], df_var)
                old_arg = args[1].strip()
                new_arg = args[2].strip()
            old_resolved = _resolve_char_arg(old_arg, df_var)
            new_resolved = _resolve_char_arg(new_arg, df_var) if new_arg.upper() != 'NULL' else ''
            if len(old_resolved) == 1:
                esc_old = old_resolved.replace('\\', '\\\\').replace('"', '\\"')
                esc_new = new_resolved.replace('\\', '\\\\').replace('"', '\\"')
                return f'{src_val}.str.replace("{esc_old}", "{esc_new}", regex=False)'
            else:
                replacements = []
                esc_new = new_resolved.replace('\\', '\\\\').replace('"', '\\"')
                for ch in old_resolved:
                    esc_ch = ch.replace('\\', '\\\\').replace('"', '\\"')
                    replacements.append(f'.str.replace("{esc_ch}", "{esc_new}", regex=False)')
                return f'{src_val}{"".join(replacements)}'

    replacestr_result = _find_func_call(cleaned, 'REPLACESTR')
    if replacestr_result and replacestr_result[0] == 0 and replacestr_result[1] == len(cleaned):
        _, _, args = replacestr_result
        if len(args) >= 3:
            _flag = args[0].strip() if len(args) >= 4 else '0'
            src_val = _vec_recursive(args[-3] if len(args) >= 4 else args[0], df_var)
            old_str = args[-2].strip().strip("'\"")
            new_str = args[-1].strip().strip("'\"") if args[-1].strip().upper() != 'NULL' else ''
            return f'{src_val}.str.replace("{old_str}", "{new_str}", regex=False)'

    chr_result = _find_func_call(cleaned, 'CHR')
    if chr_result and chr_result[0] == 0 and chr_result[1] == len(cleaned):
        _, _, args = chr_result
        if len(args) >= 1:
            try:
                code_val = int(args[0].strip())
                c = chr(code_val)
                return repr(c)
            except ValueError:
                val = _vec_recursive(args[0], df_var)
                return f'{val}.apply(chr)'

    to_char_result = _find_func_call(cleaned, 'TO_CHAR')
    if to_char_result and to_char_result[0] == 0 and to_char_result[1] == len(cleaned):
        _, _, args = to_char_result
        if len(args) >= 1:
            field_val = _vec_recursive(args[0], df_var)
            if len(args) >= 2:
                fmt = _convert_infa_date_format(args[1])
                return f'{field_val}.dt.strftime("{fmt}")'
            if any(op in field_val for op in (' + ', ' - ', ' * ', ' / ', ' % ')):
                return f'({field_val}).astype(str)'
            return f'{field_val}.astype(str)'

    make_dt_result = _find_func_call(cleaned, 'MAKE_DATE_TIME')
    if make_dt_result and make_dt_result[0] == 0 and make_dt_result[1] == len(cleaned):
        _, _, args = make_dt_result
        try:
            int_args = [int(a.strip()) for a in args]
        except ValueError:
            int_args = None
        if int_args:
            if len(int_args) >= 6:
                return f"pd.Timestamp({int_args[0]}, {int_args[1]}, {int_args[2]}, {int_args[3]}, {int_args[4]}, {int_args[5]})"
            elif len(int_args) >= 3:
                return f"pd.Timestamp({int_args[0]}, {int_args[1]}, {int_args[2]})"
            elif len(int_args) >= 1:
                return f"pd.Timestamp({', '.join(str(x) for x in int_args)})"
        vec_args = ', '.join(_vec_recursive(a, df_var) for a in args)
        return f"pd.Timestamp({vec_args})"

    for func_name in ('TO_INTEGER', 'TO_BIGINT', 'TO_FLOAT', 'TO_DECIMAL'):
        result = _find_func_call(cleaned, func_name)
        if result and result[0] == 0 and result[1] == len(cleaned):
            _, _, args = result
            if len(args) >= 1:
                field_val = _vec_recursive(args[0], df_var)
                if func_name == 'TO_BIGINT':
                    return f'pd.to_numeric({field_val}, errors="coerce").astype("Int64")'
                elif func_name in ('TO_FLOAT', 'TO_DECIMAL'):
                    return f'pd.to_numeric({field_val}, errors="coerce")'
                else:
                    return f'pd.to_numeric({field_val}, errors="coerce").fillna(0).astype(int)'

    to_date_result = _find_func_call(cleaned, 'TO_DATE')
    if to_date_result and to_date_result[0] == 0 and to_date_result[1] == len(cleaned):
        _, _, args = to_date_result
        if len(args) >= 1:
            field_val = _vec_recursive(args[0], df_var)
            if len(args) >= 2:
                py_fmt = _convert_infa_date_format(args[1])
                return f'pd.to_datetime({field_val}, format="{py_fmt}", errors="coerce")'
            return f'pd.to_datetime({field_val}, errors="coerce")'

    isnull_result = _find_func_call(cleaned, 'ISNULL')
    if isnull_result and isnull_result[0] == 0 and isnull_result[1] == len(cleaned):
        _, _, args = isnull_result
        if len(args) >= 1:
            field_val = _vec_recursive(args[0], df_var)
            return f'{field_val}.isna()'

    for func_name in ('REG_EXTRACT', 'REG_REPLACE', 'REG_MATCH'):
        result = _find_func_call(cleaned, func_name)
        if result and result[0] == 0 and result[1] == len(cleaned):
            _, _, args = result
            if len(args) >= 2:
                field_val = _vec_recursive(args[0], df_var)
                pattern_val = args[1].strip().strip("'\"")
                if func_name == 'REG_EXTRACT':
                    if re.search(r'(?<!\\)\((?!\?)', pattern_val):
                        extract_pat = pattern_val
                    else:
                        extract_pat = f'({pattern_val})'
                    return f'{field_val}.str.extract(r"{extract_pat}", expand=False)'
                elif func_name == 'REG_REPLACE':
                    replace_val = args[2].strip().strip("'\"") if len(args) >= 3 else ''
                    return f'{field_val}.str.replace(r"{pattern_val}", "{replace_val}", regex=True)'
                elif func_name == 'REG_MATCH':
                    return f'{field_val}.str.contains(r"{pattern_val}", na=False)'

    lpad_result = _find_func_call(cleaned, 'LPAD')
    if lpad_result and lpad_result[0] == 0 and lpad_result[1] == len(cleaned):
        _, _, args = lpad_result
        if len(args) >= 2:
            field_val = _vec_recursive(args[0], df_var)
            width = args[1].strip()
            fill = args[2].strip().strip("'\"") if len(args) >= 3 else ' '
            return f'{field_val}.astype(str).str.pad({width}, side="left", fillchar="{fill}")'

    rpad_result = _find_func_call(cleaned, 'RPAD')
    if rpad_result and rpad_result[0] == 0 and rpad_result[1] == len(cleaned):
        _, _, args = rpad_result
        if len(args) >= 2:
            field_val = _vec_recursive(args[0], df_var)
            width = args[1].strip()
            fill = args[2].strip().strip("'\"") if len(args) >= 3 else ' '
            return f'{field_val}.astype(str).str.pad({width}, side="right", fillchar="{fill}")'

    concat_result = _find_func_call(cleaned, 'CONCAT')
    if concat_result and concat_result[0] == 0 and concat_result[1] == len(cleaned):
        _, _, args = concat_result
        if len(args) >= 2:
            parts = []
            for a in args:
                v = _vec_recursive(a, df_var)
                if v.startswith("'") and v.endswith("'"):
                    parts.append(v)
                else:
                    parts.append(f'{v}.astype(str)')
            return ' + '.join(parts)

    reverse_result = _find_func_call(cleaned, 'REVERSE')
    if reverse_result and reverse_result[0] == 0 and reverse_result[1] == len(cleaned):
        _, _, args = reverse_result
        if len(args) >= 1:
            inner_val = _vec_recursive(args[0], df_var)
            return f'{inner_val}.str[::-1]'

    is_spaces_result = _find_func_call(cleaned, 'IS_SPACES')
    if is_spaces_result and is_spaces_result[0] == 0 and is_spaces_result[1] == len(cleaned):
        _, _, args = is_spaces_result
        if len(args) >= 1:
            inner_val = _vec_recursive(args[0], df_var)
            return f'{inner_val}.str.strip().eq("")'

    is_number_result = _find_func_call(cleaned, 'IS_NUMBER')
    if is_number_result and is_number_result[0] == 0 and is_number_result[1] == len(cleaned):
        _, _, args = is_number_result
        if len(args) >= 1:
            inner_val = _vec_recursive(args[0], df_var)
            return f'pd.to_numeric({inner_val}, errors="coerce").notna()'

    trunc_result = _find_func_call(cleaned, 'TRUNC')
    if trunc_result and trunc_result[0] == 0 and trunc_result[1] == len(cleaned):
        _, _, args = trunc_result
        if len(args) >= 1:
            field_val = _vec_recursive(args[0], df_var)
            if len(args) >= 2:
                raw_arg2 = args[1].strip().strip("'\"")
                try:
                    precision = int(raw_arg2)
                    if precision == 0:
                        return f'np.trunc({field_val})'
                    return f'(np.trunc({field_val} * 10**{precision}) / 10**{precision})'
                except ValueError:
                    pass
                fmt = raw_arg2.upper()
                if fmt in ('DD', 'D'):
                    return f'{field_val}.dt.floor("D")'
                elif fmt in ('MM', 'MON', 'MONTH'):
                    return f'{field_val}.dt.to_period("M").dt.to_timestamp()'
                elif fmt in ('YY', 'YYYY', 'YEAR'):
                    return f'{field_val}.dt.to_period("Y").dt.to_timestamp()'
                elif fmt in ('HH', 'HH24'):
                    return f'{field_val}.dt.floor("H")'
                return f'{field_val}.dt.floor("{fmt}")'
            return f'np.trunc({field_val})'

    add_to_date_result = _find_func_call(cleaned, 'ADD_TO_DATE')
    if add_to_date_result and add_to_date_result[0] == 0 and add_to_date_result[1] == len(cleaned):
        _, _, args = add_to_date_result
        if len(args) >= 3:
            date_val = _vec_recursive(args[0], df_var)
            part = args[1].strip().strip("'\"").upper()
            amount = _vec_recursive(args[2], df_var)
            if part in ('YY', 'YYYY', 'YEAR'):
                return f'{date_val} + pd.DateOffset(years={amount})'
            elif part in ('MM', 'MON', 'MONTH'):
                return f'{date_val} + pd.DateOffset(months={amount})'
            else:
                unit_map = {
                    'DD': 'D', 'DAY': 'D', 'D': 'D', 'DDD': 'D',
                    'HH': 'h', 'HH24': 'h', 'HOUR': 'h',
                    'MI': 'min', 'MIN': 'min', 'MINUTE': 'min',
                    'SS': 's', 'SEC': 's', 'SECOND': 's',
                }
                pd_unit = unit_map.get(part, 'D')
                return f'{date_val} + pd.to_timedelta({amount}, unit="{pd_unit}")'

    date_diff_result = _find_func_call(cleaned, 'DATE_DIFF')
    if date_diff_result and date_diff_result[0] == 0 and date_diff_result[1] == len(cleaned):
        _, _, args = date_diff_result
        if len(args) >= 3:
            date1 = _vec_recursive(args[0], df_var)
            date2 = _vec_recursive(args[1], df_var)
            part = args[2].strip().strip("'\"").upper()
            if part in ('DD', 'DAY', 'D', 'DDD'):
                return f'({date1} - {date2}).dt.days'
            elif part in ('HH', 'HH24', 'HOUR'):
                return f'({date1} - {date2}).dt.total_seconds() / 3600'
            elif part in ('MI', 'MIN', 'MINUTE'):
                return f'({date1} - {date2}).dt.total_seconds() / 60'
            elif part in ('SS', 'SEC', 'SECOND'):
                return f'({date1} - {date2}).dt.total_seconds()'
            return f'({date1} - {date2}).dt.days'

    in_result = _find_func_call(cleaned, 'IN')
    if in_result and in_result[0] == 0 and in_result[1] == len(cleaned):
        _, _, args = in_result
        if len(args) >= 2:
            field_val = _vec_recursive(args[0], df_var)
            vals = ', '.join(_vec_recursive(a, df_var) for a in args[1:])
            return f'{field_val}.isin([{vals}])'

    if "||" in cleaned:
        parts = _split_concat_parts(cleaned)
        vec_parts = []
        for p in parts:
            p = p.strip()
            v = _vec_recursive(p, df_var)
            if v.startswith("'") and v.endswith("'"):
                vec_parts.append(v)
            elif v.startswith(df_var + '[') or v.startswith('pd.') or '.str.' in v:
                vec_parts.append(f'{v}.fillna(\'\').astype(str)')
            else:
                vec_parts.append(f'str({v})')
        return " + ".join(vec_parts)

    for func_name in sorted(INFA_FUNC_MAP.keys(), key=lambda x: -len(x)):
        result = _find_func_call(cleaned, func_name)
        if result and result[0] == 0 and result[1] == len(cleaned):
            _, _, args = result
            py_func = INFA_FUNC_MAP[func_name]
            vec_args = ', '.join(_vec_recursive(a, df_var) for a in args)
            return f'{py_func}({vec_args})'

    converted = cleaned

    converted = re.sub(r':LKP\.(\w+)\s*\(', r'lookup_func("\1", ', converted)

    converted = re.sub(r'\$\$(\w+)', r'get_variable("\1")', converted)
    converted = re.sub(r'\$(PM\w+)', r'resolve_builtin_variable("\1")', converted)

    converted = re.sub(r'\b([A-Za-z_][A-Za-z0-9_]*)\s*IS\s+NOT\s+NULL\b',
                       lambda m: f'{df_var}["{m.group(1)}"].notna()', converted, flags=re.IGNORECASE)
    converted = re.sub(r'\b([A-Za-z_][A-Za-z0-9_]*)\s*IS\s+NULL\b',
                       lambda m: f'{df_var}["{m.group(1)}"].isna()', converted, flags=re.IGNORECASE)

    converted = re.sub(r'\bTRUE\b', 'True', converted, flags=re.IGNORECASE)
    converted = re.sub(r'\bFALSE\b', 'False', converted, flags=re.IGNORECASE)
    converted = re.sub(r'\bNULL\b', 'None', converted, flags=re.IGNORECASE)

    converted = _convert_remaining_funcs(converted, df_var)

    converted = re.sub(r'\bAND\b', ' & ', converted, flags=re.IGNORECASE)
    converted = re.sub(r'\bOR\b', ' | ', converted, flags=re.IGNORECASE)
    converted = re.sub(r'\bNOT\b', ' ~ ', converted, flags=re.IGNORECASE)
    converted = re.sub(r'<>', '!=', converted)
    converted = re.sub(r'(?<![<>!=])=(?!=)', '==', converted)

    skip_words = {
        'True', 'False', 'None', 'and', 'or', 'not', 'np', 'pd', 'get_variable',
        'resolve_builtin_variable',
        'str', 'int', 'float', 'bool', 'len', 'abs', 'round',
        'fillna', 'astype', 'isna', 'notna', 'where', 'errors', 'coerce',
        'lookup_func', 'expand', 'extract', 'regex', 'contains', 'replace',
        'upper', 'lower', 'strip', 'lstrip', 'rstrip', 'dt', 'copy',
    }
    converted = _substitute_fields(converted, df_var, skip_words)

    converted = re.sub(r'\berrors\s*==\s*(["\'])', r'errors=\1', converted)
    converted = re.sub(r'\bexpand\s*==\s*', 'expand=', converted)
    converted = re.sub(r'\bregex\s*==\s*', 'regex=', converted)

    converted = re.sub(r'\s+', ' ', converted).strip()

    return converted


def _split_concat_parts(text):
    parts = []
    current = []
    depth = 0
    in_string = False
    str_char = None
    i = 0
    while i < len(text):
        ch = text[i]
        if in_string:
            current.append(ch)
            if ch == str_char:
                in_string = False
        elif ch in ("'", '"'):
            in_string = True
            str_char = ch
            current.append(ch)
        elif ch == '(':
            depth += 1
            current.append(ch)
        elif ch == ')':
            depth -= 1
            current.append(ch)
        elif ch == '|' and i + 1 < len(text) and text[i + 1] == '|' and depth == 0:
            parts.append(''.join(current).strip())
            current = []
            i += 2
            continue
        else:
            current.append(ch)
        i += 1
    if current:
        parts.append(''.join(current).strip())
    return parts


def convert_expression_vectorized(expr, df_var="df"):
    if not expr or not expr.strip():
        return "None"
    return _vec_recursive(expr, df_var)


def _vectorize_value(val, df_var="df"):
    val = val.strip()
    if re.match(r'^[A-Za-z_][A-Za-z0-9_]*$', val):
        return f'{df_var}["{val}"]'
    if val.startswith("'") and val.endswith("'"):
        return val
    if re.match(r'^-?\d+(\.\d+)?$', val):
        return val
    return _vec_recursive(val, df_var)


def _vectorize_simple(part, df_var):
    c = part.strip()

    lkp_match = re.search(r':(\w+)\.(\w+)\s*\(', c)
    if lkp_match:
        start = lkp_match.start()
        paren_start = c.index('(', start)
        paren_end = _find_matching_paren(c, paren_start)
        if paren_end != -1:
            before = c[:start].strip()
            lkp_expr = c[start:paren_end + 1]
            after = c[paren_end + 1:].strip()
            vec_lkp = _vec_recursive(lkp_expr, df_var)
            c = f'{before}{vec_lkp}{after}'.strip()

    in_result = _find_func_call(c, 'IN')
    if in_result:
        start, end, args = in_result
        if len(args) >= 2:
            before = c[:start].strip()
            after = c[end:].strip()
            vec = _vec_recursive(c[start:end], df_var)
            c = f'{before}{vec}{after}'.strip()
            if not before and not after:
                return c

    is_spaces_result = _find_func_call(c, 'IS_SPACES')
    if is_spaces_result:
        start, end, args = is_spaces_result
        before = c[:start].strip()
        after = c[end:].strip()
        vec = _vec_recursive(c[start:end], df_var)
        c = f'{before}{vec}{after}'.strip()
        if not before and not after:
            return c

    for func_name in sorted(INFA_FUNC_MAP.keys(), key=lambda x: -len(x)):
        result = _find_func_call(c, func_name)
        if result:
            start, end, args = result
            before = c[:start]
            after = c[end:]
            vec_inner = _vec_recursive(c[start:end], df_var)
            c = f'{before}{vec_inner}{after}'
            break

    for func_name in ('UPPER', 'LOWER', 'LTRIM', 'RTRIM', 'TRIM', 'SUBSTR', 'INSTR', 'LENGTH', 'INITCAP', 'REVERSE', 'IS_NUMBER'):
        result = _find_func_call(c, func_name)
        if result:
            start, end, _ = result
            before = c[:start]
            after = c[end:]
            vec_inner = _vec_recursive(c[start:end], df_var)
            c = f'{before}{vec_inner}{after}'

    isnull_result = _find_func_call(c, 'ISNULL')
    if isnull_result:
        start, end, args = isnull_result
        before = c[:start]
        after = c[end:]
        vec_inner = _vec_recursive(c[start:end], df_var)
        c = f'{before}{vec_inner}{after}'
    else:
        c = re.sub(r'\bISNULL\s*\(\s*([A-Za-z_]\w*)\s*\)',
                   lambda m: f'{df_var}["{m.group(1)}"].isna()', c, flags=re.IGNORECASE)
    c = re.sub(r'\b([A-Za-z_]\w*)\s*IS\s+NOT\s+NULL\b',
               lambda m: f'{df_var}["{m.group(1)}"].notna()', c, flags=re.IGNORECASE)
    c = re.sub(r'\b([A-Za-z_]\w*)\s*IS\s+NULL\b',
               lambda m: f'{df_var}["{m.group(1)}"].isna()', c, flags=re.IGNORECASE)

    c = re.sub(r'\$(PM\w+)', r'resolve_builtin_variable("\1")', c)

    c = re.sub(r'<>', '!=', c)
    c = re.sub(r'(?<![<>!=])=(?!=)', '==', c)

    c = re.sub(r'\bNULL\b', 'None', c, flags=re.IGNORECASE)
    c = re.sub(r'\bTRUE\b', 'True', c, flags=re.IGNORECASE)
    c = re.sub(r'\bFALSE\b', 'False', c, flags=re.IGNORECASE)

    c = re.sub(r'\bAND\b', ' & ', c, flags=re.IGNORECASE)
    c = re.sub(r'\bOR\b', ' | ', c, flags=re.IGNORECASE)
    c = re.sub(r'\bNOT\b', ' ~ ', c, flags=re.IGNORECASE)

    skip_words = {
        'True', 'False', 'None', 'and', 'or', 'not', 'np', 'pd',
        'resolve_builtin_variable',
        'str', 'int', 'float', 'isna', 'notna', 'fillna',
        'get_variable', 'lookup_func', 'isin', 'eq',
        'expand', 'extract', 'astype', 'errors', 'coerce', 'regex',
        'contains', 'replace', 'upper', 'lower', 'strip', 'lstrip', 'rstrip',
        'dt', 'len', 'copy', 'abs', 'round', 'where', 'bool',
    }
    c = _substitute_fields(c, df_var, skip_words)
    c = re.sub(r'\bexpand\s*==\s*', 'expand=', c)
    c = re.sub(r'\berrors\s*==\s*', 'errors=', c)
    c = re.sub(r'\bregex\s*==\s*', 'regex=', c)

    return c


def _split_condition_tokens(text):
    tokens = []
    current = []
    depth = 0
    in_string = False
    str_char = None
    i = 0
    while i < len(text):
        ch = text[i]
        if in_string:
            current.append(ch)
            if ch == str_char:
                in_string = False
        elif ch in ("'", '"'):
            in_string = True
            str_char = ch
            current.append(ch)
        elif ch == '(':
            depth += 1
            current.append(ch)
        elif ch == ')':
            depth -= 1
            current.append(ch)
        elif depth == 0:
            rest = text[i:]
            prev_is_word = i > 0 and (text[i - 1].isalnum() or text[i - 1] == '_')
            and_match = re.match(r'\bAND\b', rest, re.IGNORECASE) if not prev_is_word else None
            or_match = re.match(r'\bOR\b', rest, re.IGNORECASE) if not prev_is_word else None
            if and_match:
                tokens.append(''.join(current).strip())
                current = []
                tokens.append('AND')
                i += 3
                continue
            elif or_match:
                tokens.append(''.join(current).strip())
                current = []
                tokens.append('OR')
                i += 2
                continue
            else:
                current.append(ch)
        else:
            current.append(ch)
        i += 1
    if current:
        tokens.append(''.join(current).strip())
    return [t for t in tokens if t]


def _vectorize_condition(cond, df_var="df"):
    c = cond.strip()

    tokens = _split_condition_tokens(c)

    parts = []
    ops = []
    for tok in tokens:
        stripped = tok.strip()
        if stripped.upper() in ('AND', 'OR'):
            ops.append('&' if stripped.upper() == 'AND' else '|')
        elif stripped:
            parts.append(stripped)

    if not parts:
        return "True"

    vectorized = []
    for part in parts:
        negate = False
        inner = part.strip()
        not_match = re.match(r'^NOT\b\s*', inner, flags=re.IGNORECASE)
        if not_match:
            negate = True
            inner = inner[not_match.end():].strip()

        v = _vectorize_simple(inner, df_var)
        if negate:
            v = f"~({v})"
        vectorized.append(v)

    if len(vectorized) == 1:
        return vectorized[0]

    result_parts = [f"({vectorized[0]})"]
    for i, op in enumerate(ops):
        result_parts.append(f" {op} ")
        result_parts.append(f"({vectorized[i + 1]})")
    return "".join(result_parts)


def convert_filter_expression(expr):
    if not expr or not expr.strip():
        return "True"

    converted = convert_expression(expr)
    return converted


def convert_filter_vectorized(expr, df_var="df"):
    if not expr or not expr.strip():
        return "True"
    return _vectorize_condition(expr, df_var)


def parse_join_condition(condition):
    if not condition or not condition.strip():
        return [], []

    left_keys = []
    right_keys = []

    parts = re.split(r'\bAND\b', condition, flags=re.IGNORECASE)
    for part in parts:
        part = part.strip()
        match = re.match(r'(\w+)\.(\w+)\s*=\s*(\w+)\.(\w+)', part)
        if match:
            left_keys.append(match.group(2))
            right_keys.append(match.group(4))
        else:
            match = re.match(r'(\w+)\s*=\s*(\w+)', part)
            if match:
                left_keys.append(match.group(1))
                right_keys.append(match.group(2))

    return left_keys, right_keys


def parse_lookup_condition(condition):
    if not condition or not condition.strip():
        return [], []

    input_keys = []
    lookup_keys = []

    parts = re.split(r'\bAND\b', condition, flags=re.IGNORECASE)
    for part in parts:
        part = part.strip()
        match = re.match(r'(\w+)\s*=\s*(\w+)', part)
        if match:
            input_keys.append(match.group(1))
            lookup_keys.append(match.group(2))

    return input_keys, lookup_keys


def parse_aggregate_expression(expr):
    if not expr or not expr.strip():
        return None, None

    cleaned = expr.strip()

    for func_name in AGG_FUNC_NAMES:
        pattern = re.compile(
            r'^\s*' + func_name + r'\s*\(\s*([A-Za-z_][A-Za-z0-9_]*|\*)\s*\)\s*$',
            re.IGNORECASE
        )
        match = pattern.match(cleaned)
        if match:
            col = match.group(1).strip()
            return func_name.lower(), col

    return None, None


PANDAS_AGG_MAP = {
    "sum": "sum",
    "count": "count",
    "avg": "mean",
    "max": "max",
    "min": "min",
    "median": "median",
    "stddev": "std",
    "variance": "var",
    "first": "first",
    "last": "last",
}


def convert_sql_expression(sql_expr):
    if not sql_expr or not sql_expr.strip():
        return ""

    converted = sql_expr.strip()
    converted = converted.replace("&#xD;&#xA;", "\n")
    converted = converted.replace("&#xD;", "\r")
    converted = converted.replace("&#xA;", "\n")
    converted = converted.replace("&#x9;", "\t")
    converted = converted.replace("&apos;", "'")
    converted = converted.replace("&quot;", '"')
    converted = converted.replace("&amp;", "&")
    converted = converted.replace("&lt;", "<")
    converted = converted.replace("&gt;", ">")

    return converted


def detect_sql_dialect(sql_text):
    if not sql_text:
        return "generic"

    sql_upper = sql_text.upper()

    if "GETDATE()" in sql_upper or "ISNULL(" in sql_upper or "TOP " in sql_upper:
        return "mssql"
    if ("NVL(" in sql_upper or "SYSDATE" in sql_upper or "ROWNUM" in sql_upper
            or "DECODE(" in sql_upper or "(+)" in sql_upper or "SYSTIMESTAMP" in sql_upper):
        return "oracle"
    if "NOW()" in sql_upper or "COALESCE(" in sql_upper:
        return "postgresql"

    return "generic"
