import xml.etree.ElementTree as ET
from typing import Optional
from informatica_python.models import (
    PowermartDef, RepositoryDef, FolderDef, SourceDef, TargetDef,
    MappingDef, TransformationDef, ConnectorDef, InstanceDef,
    FieldDef, TableAttribute, SessionDef, WorkflowDef,
    TaskInstanceDef, WorkflowLink, WorkflowVariable,
    MappingVariable, TargetLoadOrder, SessionTransformInst,
    ConnectionRef, ConfigDef, SchedulerDef, MappletDef,
    ShortcutDef, TaskDef, MetadataExtension, FlatFileDef,
    XmlInfoDef, GroupDef, KeywordDef, ErpSrcInfoDef, ErpInfoDef,
    AssociatedSourceInstanceDef, MapDependencyDef, FieldDependencyDef,
    TransformFieldAttrDef, TransformFieldAttrDefDef, InitPropDef,
    TargetIndexDef, TargetIndexFieldDef, TimerDef, ValuePairDef,
    SessionTransformGroupDef, PartitionDef, HashKeyDef, KeyRangeDef,
    WorkflowEventDef, FolderVersionDef,
    ScheduleInfoDef, StartOptionsDef, EndOptionsDef,
    ScheduleOptionsDef, RecurringDef, CustomScheduleDef,
    DailyFrequencyDef, RepeatDef, SchedulerFilterDef,
    SapFunctionDef, SapStructureDef, SapProgramDef,
    SapOutputPortDef, SapVariableDef, SapProgramFlowObjectDef,
    SapTableParamDef,
)


class InformaticaParser:
    def __init__(self):
        self.errors = []
        self.warnings = []

    def parse_file(self, file_path: str) -> PowermartDef:
        try:
            tree = ET.parse(file_path)
            root = tree.getroot()
            return self._parse_powermart(root)
        except ET.ParseError as e:
            self.errors.append(f"XML parse error: {e}")
            try:
                with open(file_path, "r", encoding="utf-8") as f:
                    content = f.read()
                content = self._strip_dtd(content)
                root = ET.fromstring(content)
                return self._parse_powermart(root)
            except Exception as e2:
                self.errors.append(f"Fallback parse also failed: {e2}")
                return PowermartDef()

    def parse_string(self, xml_string: str) -> PowermartDef:
        try:
            cleaned = self._strip_dtd(xml_string)
            root = ET.fromstring(cleaned)
            return self._parse_powermart(root)
        except ET.ParseError as e:
            self.errors.append(f"XML parse error: {e}")
            return PowermartDef()

    def _strip_dtd(self, content: str) -> str:
        import re
        content = re.sub(r'<!DOCTYPE[^>]*>', '', content)
        return content

    def _attr(self, elem, name, default=""):
        val = elem.get(name, default)
        return val.strip() if val else default

    def _int_attr(self, elem, name, default=0):
        val = self._attr(elem, name, str(default))
        try:
            return int(val)
        except (ValueError, TypeError):
            return default

    # ================================================================
    # Top-level: POWERMART -> REPOSITORY -> FOLDER
    # ================================================================

    def _parse_powermart(self, elem) -> PowermartDef:
        pm = PowermartDef(
            creation_date=self._attr(elem, "CREATION_DATE"),
            repository_version=self._attr(elem, "REPOSITORY_VERSION"),
        )
        for repo_elem in elem.findall("REPOSITORY"):
            pm.repositories.append(self._parse_repository(repo_elem))
        return pm

    def _parse_repository(self, elem) -> RepositoryDef:
        repo = RepositoryDef(
            name=self._attr(elem, "NAME"),
            version=self._attr(elem, "VERSION"),
            codepage=self._attr(elem, "CODEPAGE"),
            database_type=self._attr(elem, "DATABASETYPE"),
        )
        for folder_elem in elem.findall("FOLDER"):
            repo.folders.append(self._parse_folder(folder_elem))
        return repo

    def _parse_folder(self, elem) -> FolderDef:
        folder = FolderDef(
            name=self._attr(elem, "NAME"),
            owner=self._attr(elem, "OWNER"),
            description=self._attr(elem, "DESCRIPTION"),
            group=self._attr(elem, "GROUP"),
            shared=self._attr(elem, "SHARED", "NOTSHARED"),
            permissions=self._attr(elem, "PERMISSIONS"),
        )

        for fv in elem.findall("FOLDERVERSION"):
            folder.folder_versions.append(self._parse_folder_version(fv))

        for src in elem.findall("SOURCE"):
            folder.sources.append(self._parse_source(src))

        for tgt in elem.findall("TARGET"):
            folder.targets.append(self._parse_target(tgt))

        for mapping in elem.findall("MAPPING"):
            folder.mappings.append(self._parse_mapping(mapping))

        for mapplet in elem.findall("MAPPLET"):
            folder.mapplets.append(self._parse_mapplet(mapplet))

        for session in elem.findall("SESSION"):
            folder.sessions.append(self._parse_session(session))

        for wf in elem.findall("WORKFLOW"):
            folder.workflows.append(self._parse_workflow(wf))

        for worklet in elem.findall("WORKLET"):
            wf_def = self._parse_workflow(worklet)
            wf_def.metadata["is_worklet"] = "YES"
            folder.workflows.append(wf_def)

        for task in elem.findall("TASK"):
            folder.tasks.append(self._parse_task(task))

        for cfg in elem.findall("CONFIG"):
            folder.configs.append(self._parse_config(cfg))

        for sched in elem.findall("SCHEDULER"):
            folder.schedulers.append(self._parse_scheduler(sched))

        for sc in elem.findall("SHORTCUT"):
            folder.shortcuts.append(self._parse_shortcut(sc))

        for tx in elem.findall("TRANSFORMATION"):
            folder.transformations.append(self._parse_transformation(tx))

        for me in elem.findall("METADATAEXTENSION"):
            folder.metadata_extensions.append(self._parse_metadata_extension(me))

        return folder

    def _parse_folder_version(self, elem) -> FolderVersionDef:
        fv = FolderVersionDef(
            folder_name=self._attr(elem, "FOLDERNAME"),
            version_number=self._int_attr(elem, "VERSIONNUMBER"),
            repository_name=self._attr(elem, "REPOSITORYNAME"),
            description=self._attr(elem, "DESCRIPTION"),
        )
        for k, v in elem.attrib.items():
            fv.attributes[k] = v
        return fv

    # ================================================================
    # Common sub-element parsers
    # ================================================================

    def _parse_table_attribute(self, elem) -> TableAttribute:
        return TableAttribute(
            name=self._attr(elem, "NAME"),
            value=self._attr(elem, "VALUE"),
        )

    def _parse_metadata_extension(self, elem) -> MetadataExtension:
        return MetadataExtension(
            name=self._attr(elem, "NAME"),
            value=self._attr(elem, "VALUE"),
            datatype=self._attr(elem, "DATATYPE"),
            max_length=self._int_attr(elem, "MAXLENGTH"),
            domain_name=self._attr(elem, "DOMAINNAME"),
            description=self._attr(elem, "DESCRIPTION"),
            is_reusable=self._attr(elem, "ISREUSABLE", "NO"),
            is_shared_read=self._attr(elem, "ISSHAREDREAD", "NO"),
            is_shared_write=self._attr(elem, "ISSHAREDWRITE", "NO"),
            is_uni_directional=self._attr(elem, "ISUNIDIRECTIONAL", "NO"),
        )

    def _parse_flatfile(self, elem) -> FlatFileDef:
        ff = FlatFileDef(
            name=self._attr(elem, "NAME"),
            delimiter=self._attr(elem, "DELIMITERS", ","),
            text_qualifier=self._attr(elem, "QUALIFIER"),
            escape_character=self._attr(elem, "ESCAPECHARACTER"),
            null_character=self._attr(elem, "NULLCHARACTER"),
            header_lines=self._int_attr(elem, "HEADERLINES"),
            code_page=self._attr(elem, "CODEPAGE"),
            strip_trailing_blanks=self._attr(elem, "STRIPTRAILINGBLANKS", "NO"),
            is_fixed_width=self._attr(elem, "ISFIXEDWIDTH", "NO"),
            line_sequential=self._attr(elem, "LINESEQUENTIAL", "YES"),
            skip_rows=self._int_attr(elem, "SKIPROWS"),
            row_delimiter=self._attr(elem, "ROWDELIMITER"),
        )
        for ta in elem.findall("TABLEATTRIBUTE"):
            ff.attributes.append(self._parse_table_attribute(ta))
        for k, v in elem.attrib.items():
            if k not in ("NAME", "DELIMITERS", "QUALIFIER", "ESCAPECHARACTER",
                         "NULLCHARACTER", "HEADERLINES", "CODEPAGE",
                         "STRIPTRAILINGBLANKS", "ISFIXEDWIDTH", "LINESEQUENTIAL",
                         "SKIPROWS", "ROWDELIMITER"):
                ff.attributes.append(TableAttribute(name=k, value=v))
        return ff

    def _parse_xmlinfo(self, elem) -> XmlInfoDef:
        xi = XmlInfoDef(
            name=self._attr(elem, "NAME"),
            xml_type=self._attr(elem, "XMLTYPE"),
            xml_version=self._attr(elem, "XMLVERSION"),
            dtd_url=self._attr(elem, "DTDURL"),
            root_element=self._attr(elem, "ROOTELEMENT"),
            namespace_uri=self._attr(elem, "NAMESPACEURI"),
            namespace_prefix=self._attr(elem, "NAMESPACEPREFIX"),
        )
        for ta in elem.findall("TABLEATTRIBUTE"):
            xi.attributes.append(self._parse_table_attribute(ta))
        for xt in elem.findall("XMLTEXT"):
            xi.xml_texts.append({
                "name": self._attr(xt, "NAME"),
                "text": xt.text or "",
                "attributes": {k: v for k, v in xt.attrib.items()},
            })
        for k, v in elem.attrib.items():
            if k not in ("NAME", "XMLTYPE", "XMLVERSION", "DTDURL",
                         "ROOTELEMENT", "NAMESPACEURI", "NAMESPACEPREFIX"):
                xi.attributes.append(TableAttribute(name=k, value=v))
        return xi

    def _parse_group(self, elem) -> GroupDef:
        grp = GroupDef(
            name=self._attr(elem, "NAME"),
            type=self._attr(elem, "TYPE"),
            description=self._attr(elem, "DESCRIPTION"),
            order=self._int_attr(elem, "ORDER"),
            expression=self._attr(elem, "EXPRESSION"),
        )
        for fld in elem.findall("SOURCEFIELD"):
            grp.fields.append(self._parse_source_field(fld))
        for fld in elem.findall("TARGETFIELD"):
            grp.fields.append(self._parse_target_field(fld))
        for fld in elem.findall("TRANSFORMFIELD"):
            grp.fields.append(self._parse_transform_field(fld))
        return grp

    def _parse_keyword(self, elem) -> KeywordDef:
        return KeywordDef(
            name=self._attr(elem, "NAME"),
            value=self._attr(elem, "VALUE"),
        )

    def _parse_erp_src_info(self, elem) -> ErpSrcInfoDef:
        erp = ErpSrcInfoDef(
            name=self._attr(elem, "NAME"),
            source_type=self._attr(elem, "SOURCETYPE"),
        )
        for ta in elem.findall("TABLEATTRIBUTE"):
            erp.attributes.append(self._parse_table_attribute(ta))
        for k, v in elem.attrib.items():
            if k not in ("NAME", "SOURCETYPE"):
                erp.metadata[k] = v
        return erp

    def _parse_erp_info(self, elem) -> ErpInfoDef:
        erp = ErpInfoDef(
            name=self._attr(elem, "NAME"),
            erp_type=self._attr(elem, "ERPTYPE"),
        )
        for ta in elem.findall("TABLEATTRIBUTE"):
            erp.attributes.append(self._parse_table_attribute(ta))
        for k, v in elem.attrib.items():
            if k not in ("NAME", "ERPTYPE"):
                erp.metadata[k] = v
        return erp

    # ================================================================
    # SAP family parsers
    # ================================================================

    def _parse_sap_function(self, elem) -> SapFunctionDef:
        sf = SapFunctionDef(
            name=self._attr(elem, "NAME"),
            function_type=self._attr(elem, "FUNCTIONTYPE"),
            description=self._attr(elem, "DESCRIPTION"),
        )
        for s in elem.findall("SAPSTRUCTURE"):
            sf.structures.append(self._parse_sap_structure(s))
        for op in elem.findall("SAPOUTPUTPORT"):
            sf.output_ports.append(self._parse_sap_output_port(op))
        for sv in elem.findall("SAPVARIABLE"):
            sf.variables.append(self._parse_sap_variable(sv))
        for tp in elem.findall("SAPTABLEPARAM"):
            sf.table_params.append(self._parse_sap_table_param(tp))
        for sp in elem.findall("SAPPROGRAM"):
            sf.programs.append(self._parse_sap_program(sp))
        for ta in elem.findall("TABLEATTRIBUTE"):
            sf.attributes.append(self._parse_table_attribute(ta))
        return sf

    def _parse_sap_structure(self, elem) -> SapStructureDef:
        ss = SapStructureDef(
            name=self._attr(elem, "NAME"),
            structure_type=self._attr(elem, "STRUCTURETYPE"),
            description=self._attr(elem, "DESCRIPTION"),
        )
        for fld in elem.findall("SOURCEFIELD"):
            ss.fields.append(self._parse_source_field(fld))
        for fld in elem.findall("TRANSFORMFIELD"):
            ss.fields.append(self._parse_transform_field(fld))
        for ta in elem.findall("TABLEATTRIBUTE"):
            ss.attributes.append(self._parse_table_attribute(ta))
        return ss

    def _parse_sap_output_port(self, elem) -> SapOutputPortDef:
        return SapOutputPortDef(
            name=self._attr(elem, "NAME"),
            datatype=self._attr(elem, "DATATYPE"),
            precision=self._int_attr(elem, "PRECISION"),
            scale=self._int_attr(elem, "SCALE"),
            porttype=self._attr(elem, "PORTTYPE"),
            description=self._attr(elem, "DESCRIPTION"),
        )

    def _parse_sap_variable(self, elem) -> SapVariableDef:
        return SapVariableDef(
            name=self._attr(elem, "NAME"),
            datatype=self._attr(elem, "DATATYPE"),
            default_value=self._attr(elem, "DEFAULTVALUE"),
            description=self._attr(elem, "DESCRIPTION"),
            precision=self._int_attr(elem, "PRECISION"),
            scale=self._int_attr(elem, "SCALE"),
        )

    def _parse_sap_table_param(self, elem) -> SapTableParamDef:
        tp = SapTableParamDef(
            name=self._attr(elem, "NAME"),
            table_name=self._attr(elem, "TABLENAME"),
            direction=self._attr(elem, "DIRECTION"),
            description=self._attr(elem, "DESCRIPTION"),
        )
        for ta in elem.findall("TABLEATTRIBUTE"):
            tp.attributes.append(self._parse_table_attribute(ta))
        return tp

    def _parse_sap_program(self, elem) -> SapProgramDef:
        sp = SapProgramDef(
            name=self._attr(elem, "NAME"),
            program_type=self._attr(elem, "PROGRAMTYPE"),
            description=self._attr(elem, "DESCRIPTION"),
        )
        for sv in elem.findall("SAPVARIABLE"):
            sp.variables.append(self._parse_sap_variable(sv))
        for fo in elem.findall("SAPPROGRAMFLOWOBJECT"):
            sp.flow_objects.append(self._parse_sap_program_flow_object(fo))
        for ta in elem.findall("TABLEATTRIBUTE"):
            sp.attributes.append(self._parse_table_attribute(ta))
        return sp

    def _parse_sap_program_flow_object(self, elem) -> SapProgramFlowObjectDef:
        pfo = SapProgramFlowObjectDef(
            name=self._attr(elem, "NAME"),
            object_type=self._attr(elem, "OBJECTTYPE"),
            description=self._attr(elem, "DESCRIPTION"),
        )
        for ta in elem.findall("TABLEATTRIBUTE"):
            pfo.attributes.append(self._parse_table_attribute(ta))
        return pfo

    # ================================================================
    # SOURCE + SOURCEFIELD + related tags
    # ================================================================

    def _parse_source(self, elem) -> SourceDef:
        src = SourceDef(
            name=self._attr(elem, "NAME"),
            database_type=self._attr(elem, "DATABASETYPE"),
            db_name=self._attr(elem, "DBDNAME"),
            owner_name=self._attr(elem, "OWNERNAME"),
            description=self._attr(elem, "DESCRIPTION"),
            business_name=self._attr(elem, "BUSINESSNAME"),
        )
        for sf in elem.findall("SOURCEFIELD"):
            src.fields.append(self._parse_source_field(sf))
        for ta in elem.findall("TABLEATTRIBUTE"):
            src.attributes.append(self._parse_table_attribute(ta))
        for fa in elem.findall("FIELDATTRIBUTE"):
            src.attributes.append(self._parse_table_attribute(fa))
        for me in elem.findall("METADATAEXTENSION"):
            src.metadata_extensions.append(self._parse_metadata_extension(me))
        for ff in elem.findall("FLATFILE"):
            src.flatfile = self._parse_flatfile(ff)
        for xi in elem.findall("XMLINFO"):
            src.xmlinfo = self._parse_xmlinfo(xi)
        for grp in elem.findall("GROUP"):
            src.groups.append(self._parse_group(grp))
        for kw in elem.findall("KEYWORD"):
            src.keywords.append(self._parse_keyword(kw))
        for erp in elem.findall("ERPSRCINFO"):
            src.erp_src_info = self._parse_erp_src_info(erp)
        return src

    def _parse_source_field(self, elem) -> FieldDef:
        fld = FieldDef(
            name=self._attr(elem, "NAME"),
            datatype=self._attr(elem, "DATATYPE"),
            precision=self._int_attr(elem, "PRECISION"),
            scale=self._int_attr(elem, "SCALE"),
            nullable=self._attr(elem, "NULLABLE", "NULL"),
            keytype=self._attr(elem, "KEYTYPE", "NOT A KEY"),
            field_number=self._int_attr(elem, "FIELDNUMBER"),
            hidden=self._attr(elem, "HIDDEN", "NO"),
            business_name=self._attr(elem, "BUSINESSNAME"),
            description=self._attr(elem, "DESCRIPTION"),
            offset=self._int_attr(elem, "OFFSET"),
            physical_offset=self._int_attr(elem, "PHYSICALOFFSET"),
            physical_length=self._int_attr(elem, "PHYSICALLENGTH"),
        )
        for fa in elem.findall("FIELDATTRIBUTE"):
            fld.field_attributes.append({
                "name": self._attr(fa, "NAME"),
                "value": self._attr(fa, "VALUE"),
            })
        return fld

    # ================================================================
    # TARGET + TARGETFIELD + TARGETINDEX + TARGETINDEXFIELD
    # ================================================================

    def _parse_target(self, elem) -> TargetDef:
        tgt = TargetDef(
            name=self._attr(elem, "NAME"),
            database_type=self._attr(elem, "DATABASETYPE"),
            description=self._attr(elem, "DESCRIPTION"),
            business_name=self._attr(elem, "BUSINESSNAME"),
            constraint=self._attr(elem, "CONSTRAINT"),
            table_options=self._attr(elem, "TABLEOPTIONS"),
        )
        for tf in elem.findall("TARGETFIELD"):
            tgt.fields.append(self._parse_target_field(tf))
        for ta in elem.findall("TABLEATTRIBUTE"):
            tgt.attributes.append(self._parse_table_attribute(ta))
        for ti in elem.findall("TARGETINDEX"):
            tgt.indexes.append(self._parse_target_index(ti))
        for me in elem.findall("METADATAEXTENSION"):
            tgt.metadata_extensions.append(self._parse_metadata_extension(me))
        for ff in elem.findall("FLATFILE"):
            tgt.flatfile = self._parse_flatfile(ff)
        for xi in elem.findall("XMLINFO"):
            tgt.xmlinfo = self._parse_xmlinfo(xi)
        for grp in elem.findall("GROUP"):
            tgt.groups.append(self._parse_group(grp))
        for kw in elem.findall("KEYWORD"):
            tgt.keywords.append(self._parse_keyword(kw))
        return tgt

    def _parse_target_field(self, elem) -> FieldDef:
        fld = FieldDef(
            name=self._attr(elem, "NAME"),
            datatype=self._attr(elem, "DATATYPE"),
            precision=self._int_attr(elem, "PRECISION"),
            scale=self._int_attr(elem, "SCALE"),
            nullable=self._attr(elem, "NULLABLE", "NULL"),
            keytype=self._attr(elem, "KEYTYPE", "NOT A KEY"),
            field_number=self._int_attr(elem, "FIELDNUMBER"),
            description=self._attr(elem, "DESCRIPTION"),
            business_name=self._attr(elem, "BUSINESSNAME"),
        )
        for fa in elem.findall("FIELDATTRIBUTE"):
            fld.field_attributes.append({
                "name": self._attr(fa, "NAME"),
                "value": self._attr(fa, "VALUE"),
            })
        return fld

    def _parse_target_index(self, elem) -> TargetIndexDef:
        ti = TargetIndexDef(
            name=self._attr(elem, "NAME"),
            index_type=self._attr(elem, "INDEXTYPE"),
            unique=self._attr(elem, "UNIQUE", "NO"),
            description=self._attr(elem, "DESCRIPTION"),
        )
        for tif in elem.findall("TARGETINDEXFIELD"):
            ti.fields.append(TargetIndexFieldDef(
                name=self._attr(tif, "NAME"),
                expression=self._attr(tif, "EXPRESSION"),
                sort_direction=self._attr(tif, "SORTDIRECTION", "ASCENDING"),
            ))
        return ti

    # ================================================================
    # TRANSFORMATION + TRANSFORMFIELD + child tags
    # ================================================================

    def _parse_transformation(self, elem) -> TransformationDef:
        tx = TransformationDef(
            name=self._attr(elem, "NAME"),
            type=self._attr(elem, "TYPE"),
            description=self._attr(elem, "DESCRIPTION"),
            reusable=self._attr(elem, "REUSABLE", "NO"),
        )
        for tf in elem.findall("TRANSFORMFIELD"):
            tx.fields.append(self._parse_transform_field(tf))
        for ta in elem.findall("TABLEATTRIBUTE"):
            tx.attributes.append(self._parse_table_attribute(ta))

        for tfa in elem.findall("TRANSFORMFIELDATTR"):
            tx.field_attrs.append(TransformFieldAttrDef(
                name=self._attr(tfa, "NAME"),
                value=self._attr(tfa, "VALUE"),
                field_name=self._attr(tfa, "FIELDNAME"),
            ))
            tx.metadata[f"TRANSFORMFIELDATTR_{self._attr(tfa, 'NAME', 'TRANSFORMFIELDATTR')}"] = self._attr(tfa, "VALUE", str(tfa.attrib))

        for tfad in elem.findall("TRANSFORMFIELDATTRDEF"):
            tx.field_attr_defs.append(TransformFieldAttrDefDef(
                name=self._attr(tfad, "NAME"),
                datatype=self._attr(tfad, "DATATYPE"),
                default_value=self._attr(tfad, "DEFAULTVALUE"),
                description=self._attr(tfad, "DESCRIPTION"),
                is_required=self._attr(tfad, "ISREQUIRED", "NO"),
            ))
            tx.metadata[f"TRANSFORMFIELDATTRDEF_{self._attr(tfad, 'NAME', 'TRANSFORMFIELDATTRDEF')}"] = self._attr(tfad, "DEFAULTVALUE", str(tfad.attrib))

        for ip in elem.findall("INITPROP"):
            tx.init_props.append(InitPropDef(
                name=self._attr(ip, "NAME"),
                value=self._attr(ip, "VALUE"),
            ))
            tx.metadata[f"INITPROP_{self._attr(ip, 'NAME', 'INITPROP')}"] = self._attr(ip, "VALUE", str(ip.attrib))

        for erp in elem.findall("ERPINFO"):
            tx.erp_info = self._parse_erp_info(erp)
            tx.metadata[f"ERPINFO_{self._attr(erp, 'NAME', 'ERPINFO')}"] = self._attr(erp, "VALUE", str(erp.attrib))

        for grp in elem.findall("GROUP"):
            tx.groups.append(self._parse_group(grp))

        for me in elem.findall("METADATAEXTENSION"):
            tx.metadata_extensions.append(self._parse_metadata_extension(me))

        for sf in elem.findall("SAPFUNCTION"):
            tx.sap_functions.append(self._parse_sap_function(sf))

        return tx

    def _parse_transform_field(self, elem) -> FieldDef:
        fld = FieldDef(
            name=self._attr(elem, "NAME"),
            datatype=self._attr(elem, "DATATYPE"),
            precision=self._int_attr(elem, "PRECISION"),
            scale=self._int_attr(elem, "SCALE"),
            default_value=self._attr(elem, "DEFAULTVALUE"),
            expression=self._attr(elem, "EXPRESSION"),
            expression_type=self._attr(elem, "EXPRESSIONTYPE"),
            porttype=self._attr(elem, "PORTTYPE"),
            description=self._attr(elem, "DESCRIPTION"),
        )
        for fa in elem.findall("TRANSFORMFIELDATTR"):
            fld.field_attributes.append({
                "name": self._attr(fa, "NAME"),
                "value": self._attr(fa, "VALUE"),
            })
        return fld

    # ================================================================
    # CONNECTOR, INSTANCE, ASSOCIATED_SOURCE_INSTANCE
    # ================================================================

    def _parse_connector(self, elem) -> ConnectorDef:
        return ConnectorDef(
            from_field=self._attr(elem, "FROMFIELD"),
            from_instance=self._attr(elem, "FROMINSTANCE"),
            from_instance_type=self._attr(elem, "FROMINSTANCETYPE"),
            to_field=self._attr(elem, "TOFIELD"),
            to_instance=self._attr(elem, "TOINSTANCE"),
            to_instance_type=self._attr(elem, "TOINSTANCETYPE"),
            from_instance_group=self._attr(elem, "FROMINSTANCEGROUP"),
            to_instance_group=self._attr(elem, "TOINSTANCEGROUP"),
        )

    def _parse_instance(self, elem) -> InstanceDef:
        inst = InstanceDef(
            name=self._attr(elem, "NAME"),
            type=self._attr(elem, "TYPE"),
            transformation_name=self._attr(elem, "TRANSFORMATION_NAME"),
            transformation_type=self._attr(elem, "TRANSFORMATION_TYPE"),
            description=self._attr(elem, "DESCRIPTION"),
            reusable=self._attr(elem, "REUSABLE", "NO"),
        )
        for asi in elem.findall("ASSOCIATED_SOURCE_INSTANCE"):
            inst.associated_source_instances.append(AssociatedSourceInstanceDef(
                name=self._attr(asi, "NAME"),
                source_instance=self._attr(asi, "SOURCEINSTANCE"),
            ))
        return inst

    # ================================================================
    # MAPPING + all child tags
    # ================================================================

    def _parse_mapping(self, elem) -> MappingDef:
        mapping = MappingDef(
            name=self._attr(elem, "NAME"),
            description=self._attr(elem, "DESCRIPTION"),
            is_valid=self._attr(elem, "ISVALID", "YES"),
        )

        for tx in elem.findall("TRANSFORMATION"):
            mapping.transformations.append(self._parse_transformation(tx))

        for conn in elem.findall("CONNECTOR"):
            mapping.connectors.append(self._parse_connector(conn))

        for inst in elem.findall("INSTANCE"):
            mapping.instances.append(self._parse_instance(inst))

        for tlo in elem.findall("TARGETLOADORDER"):
            order = TargetLoadOrder(
                order=self._int_attr(tlo, "ORDER", 1),
                target_instance=self._attr(tlo, "TARGETINSTANCE"),
            )
            mapping.target_load_orders.append(order)

        for mv in elem.findall("MAPPINGVARIABLE"):
            mapping.variables.append(MappingVariable(
                name=self._attr(mv, "NAME"),
                datatype=self._attr(mv, "DATATYPE", "string"),
                default_value=self._attr(mv, "DEFAULTVALUE"),
                description=self._attr(mv, "DESCRIPTION"),
                is_expression_variable=self._attr(mv, "ISEXPRESSIONVARIABLE", "NO"),
                is_persistent=self._attr(mv, "ISPERSISTENT", "NO"),
                precision=self._int_attr(mv, "PRECISION"),
                scale=self._int_attr(mv, "SCALE"),
                usage_type=self._attr(mv, "USAGETYPE"),
            ))

        for me in elem.findall("METADATAEXTENSION"):
            mapping.metadata[self._attr(me, "NAME")] = self._attr(me, "VALUE")
            mapping.metadata_extensions.append(self._parse_metadata_extension(me))

        for md in elem.findall("MAPDEPENDENCY"):
            mapping.map_dependencies.append(MapDependencyDef(
                name=self._attr(md, "NAME"),
                from_mapping=self._attr(md, "FROMMAPPING"),
                to_mapping=self._attr(md, "TOMAPPING"),
                description=self._attr(md, "DESCRIPTION"),
            ))

        for fd in elem.findall("FIELDDEPENDENCY"):
            mapping.field_dependencies.append(FieldDependencyDef(
                name=self._attr(fd, "NAME"),
                from_field=self._attr(fd, "FROMFIELD"),
                from_instance=self._attr(fd, "FROMINSTANCE"),
                to_field=self._attr(fd, "TOFIELD"),
                to_instance=self._attr(fd, "TOINSTANCE"),
                expression=self._attr(fd, "EXPRESSION"),
            ))

        return mapping

    # ================================================================
    # MAPPLET
    # ================================================================

    def _parse_mapplet(self, elem) -> MappletDef:
        mapplet = MappletDef(
            name=self._attr(elem, "NAME"),
            description=self._attr(elem, "DESCRIPTION"),
            is_valid=self._attr(elem, "ISVALID", "YES"),
        )
        for tx in elem.findall("TRANSFORMATION"):
            mapplet.transformations.append(self._parse_transformation(tx))
        for conn in elem.findall("CONNECTOR"):
            mapplet.connectors.append(self._parse_connector(conn))
        for inst in elem.findall("INSTANCE"):
            mapplet.instances.append(self._parse_instance(inst))
        for me in elem.findall("METADATAEXTENSION"):
            mapplet.metadata_extensions.append(self._parse_metadata_extension(me))
        for md in elem.findall("MAPDEPENDENCY"):
            mapplet.map_dependencies.append(MapDependencyDef(
                name=self._attr(md, "NAME"),
                from_mapping=self._attr(md, "FROMMAPPING"),
                to_mapping=self._attr(md, "TOMAPPING"),
                description=self._attr(md, "DESCRIPTION"),
            ))
        for fd in elem.findall("FIELDDEPENDENCY"):
            mapplet.field_dependencies.append(FieldDependencyDef(
                name=self._attr(fd, "NAME"),
                from_field=self._attr(fd, "FROMFIELD"),
                from_instance=self._attr(fd, "FROMINSTANCE"),
                to_field=self._attr(fd, "TOFIELD"),
                to_instance=self._attr(fd, "TOINSTANCE"),
                expression=self._attr(fd, "EXPRESSION"),
            ))
        return mapplet

    # ================================================================
    # SESSION + SESSTRANSFORMATIONINST + SESSTRANSFORMATIONGROUP
    # + PARTITION + HASHKEY + KEYRANGE + SESSIONCOMPONENT
    # + CONFIGREFERENCE + CONNECTIONREFERENCE
    # ================================================================

    def _parse_session(self, elem) -> SessionDef:
        session = SessionDef(
            name=self._attr(elem, "NAME"),
            mapping_name=self._attr(elem, "MAPPINGNAME"),
            description=self._attr(elem, "DESCRIPTION"),
            is_valid=self._attr(elem, "ISVALID", "YES"),
            reusable=self._attr(elem, "REUSABLE", "NO"),
        )

        for ta in elem.findall(".//ATTRIBUTE"):
            session.attributes.append(self._parse_table_attribute(ta))

        for cr in elem.findall(".//CONFIGREFERENCE"):
            session.config_references.append({
                "name": self._attr(cr, "REFOBJECTNAME"),
                "type": self._attr(cr, "TYPE"),
            })

        for sti in elem.findall(".//SESSTRANSFORMATIONINST"):
            session.transform_instances.append(self._parse_sess_transform_inst(sti))

        for stg in elem.findall(".//SESSTRANSFORMATIONGROUP"):
            session.transform_groups.append(self._parse_sess_transform_group(stg))

        for comp in elem.findall(".//SESSIONCOMPONENT"):
            comp_data = {
                "name": self._attr(comp, "REFOBJECTNAME"),
                "type": self._attr(comp, "TYPE"),
                "attributes": [],
            }
            for ta in comp.findall("ATTRIBUTE"):
                comp_data["attributes"].append({
                    "name": self._attr(ta, "NAME"),
                    "value": self._attr(ta, "VALUE"),
                })
            session.components.append(comp_data)

        for me in elem.findall("METADATAEXTENSION"):
            session.metadata_extensions.append(self._parse_metadata_extension(me))

        return session

    def _parse_sess_transform_inst(self, elem) -> SessionTransformInst:
        st = SessionTransformInst(
            instance_name=self._attr(elem, "SINSTANCENAME"),
            pipeline=self._attr(elem, "PIPELINE"),
            stage=self._attr(elem, "STAGE"),
            transformation_name=self._attr(elem, "TRANSFORMATIONNAME"),
            transformation_type=self._attr(elem, "TRANSFORMATIONTYPE"),
            is_partitionable=self._attr(elem, "ISREPARTITIONPOINT", "NO"),
        )
        for ta in elem.findall("ATTRIBUTE"):
            st.attributes.append(self._parse_table_attribute(ta))
        for cr in elem.findall("CONNECTIONREFERENCE"):
            st.connections.append(ConnectionRef(
                connection_name=self._attr(cr, "CONNECTIONNAME"),
                connection_type=self._attr(cr, "CONNECTIONTYPE"),
                connection_subtype=self._attr(cr, "CONNECTIONSUBTYPE"),
                component_version=self._attr(cr, "COMPONENTVERSION"),
                variable=self._attr(cr, "VARIABLE"),
            ))
        for part in elem.findall("PARTITION"):
            st.partitions.append(self._parse_partition(part))
        return st

    def _parse_sess_transform_group(self, elem) -> SessionTransformGroupDef:
        stg = SessionTransformGroupDef(
            name=self._attr(elem, "NAME"),
            description=self._attr(elem, "DESCRIPTION"),
        )
        for sti in elem.findall("SESSTRANSFORMATIONINST"):
            stg.transform_instances.append(self._parse_sess_transform_inst(sti))
        for ta in elem.findall("ATTRIBUTE"):
            stg.attributes.append(self._parse_table_attribute(ta))
        return stg

    def _parse_partition(self, elem) -> PartitionDef:
        part = PartitionDef(
            name=self._attr(elem, "NAME"),
            partition_type=self._attr(elem, "PARTITIONTYPE"),
            description=self._attr(elem, "DESCRIPTION"),
        )
        for hk in elem.findall("HASHKEY"):
            part.hash_keys.append(HashKeyDef(
                name=self._attr(hk, "NAME"),
                expression=self._attr(hk, "EXPRESSION"),
            ))
        for kr in elem.findall("KEYRANGE"):
            part.key_ranges.append(KeyRangeDef(
                name=self._attr(kr, "NAME"),
                low_value=self._attr(kr, "LOWVALUE"),
                high_value=self._attr(kr, "HIGHVALUE"),
            ))
        for ta in elem.findall("ATTRIBUTE"):
            part.attributes.append(self._parse_table_attribute(ta))
        return part

    # ================================================================
    # TASK + TIMER + VALUEPAIR
    # ================================================================

    def _parse_task(self, elem) -> TaskDef:
        task = TaskDef(
            name=self._attr(elem, "NAME"),
            type=self._attr(elem, "TYPE"),
            description=self._attr(elem, "DESCRIPTION"),
            reusable=self._attr(elem, "REUSABLE", "NO"),
        )
        for ta in elem.findall("ATTRIBUTE"):
            task.attributes.append(self._parse_table_attribute(ta))
        for vp in elem.findall("VALUEPAIR"):
            task.value_pairs.append(ValuePairDef(
                name=self._attr(vp, "NAME"),
                value=self._attr(vp, "VALUE"),
                type=self._attr(vp, "TYPE"),
            ))
            task.attributes.append(TableAttribute(
                name=self._attr(vp, "NAME"),
                value=self._attr(vp, "VALUE"),
            ))
        for timer in elem.findall("TIMER"):
            task.timer = self._parse_timer(timer)
        for me in elem.findall("METADATAEXTENSION"):
            task.metadata_extensions.append(self._parse_metadata_extension(me))
        return task

    def _parse_timer(self, elem) -> TimerDef:
        timer = TimerDef(
            name=self._attr(elem, "NAME"),
            start_type=self._attr(elem, "STARTTYPE"),
            start_date=self._attr(elem, "STARTDATE"),
            start_time=self._attr(elem, "STARTTIME"),
            end_type=self._attr(elem, "ENDTYPE"),
            end_date=self._attr(elem, "ENDDATE"),
            end_time=self._attr(elem, "ENDTIME"),
        )
        for ta in elem.findall("ATTRIBUTE"):
            timer.attributes.append(self._parse_table_attribute(ta))
        for k, v in elem.attrib.items():
            if k not in ("NAME", "STARTTYPE", "STARTDATE", "STARTTIME",
                         "ENDTYPE", "ENDDATE", "ENDTIME"):
                timer.attributes.append(TableAttribute(name=k, value=v))
        return timer

    # ================================================================
    # SCHEDULER + SCHEDULEINFO + STARTOPTIONS + ENDOPTIONS
    # + SCHEDULEOPTIONS + RECURRING + CUSTOM
    # + DAILYFREQUENCY + REPEAT + FILTER
    # ================================================================

    def _parse_scheduler(self, elem) -> SchedulerDef:
        sched = SchedulerDef(
            name=self._attr(elem, "NAME"),
            description=self._attr(elem, "DESCRIPTION"),
            reusable=self._attr(elem, "REUSABLE", "NO"),
        )
        for ta in elem.findall("ATTRIBUTE"):
            sched.attributes.append(self._parse_table_attribute(ta))

        si = elem.find("SCHEDULEINFO")
        if si is not None:
            sched.schedule_info = ScheduleInfoDef(
                schedule_type=self._attr(si, "SCHEDULETYPE"),
                attributes={k: v for k, v in si.attrib.items()},
            )
            for k, v in si.attrib.items():
                sched.attributes.append(TableAttribute(name=f"SCHEDULEINFO_{k}", value=v))

        so = elem.find("STARTOPTIONS")
        if so is not None:
            sched.start_options = StartOptionsDef(attributes={k: v for k, v in so.attrib.items()})
            for k, v in so.attrib.items():
                sched.attributes.append(TableAttribute(name=f"STARTOPTIONS_{k}", value=v))

        eo = elem.find("ENDOPTIONS")
        if eo is not None:
            sched.end_options = EndOptionsDef(attributes={k: v for k, v in eo.attrib.items()})
            for k, v in eo.attrib.items():
                sched.attributes.append(TableAttribute(name=f"ENDOPTIONS_{k}", value=v))

        sco = elem.find("SCHEDULEOPTIONS")
        if sco is not None:
            sched.schedule_options = ScheduleOptionsDef(attributes={k: v for k, v in sco.attrib.items()})
            for k, v in sco.attrib.items():
                sched.attributes.append(TableAttribute(name=f"SCHEDULEOPTIONS_{k}", value=v))

        rec = elem.find(".//RECURRING")
        if rec is not None:
            sched.recurring = RecurringDef(attributes={k: v for k, v in rec.attrib.items()})
            for k, v in rec.attrib.items():
                sched.attributes.append(TableAttribute(name=f"RECURRING_{k}", value=v))

        cust = elem.find(".//CUSTOM")
        if cust is not None:
            sched.custom = CustomScheduleDef(attributes={k: v for k, v in cust.attrib.items()})
            for k, v in cust.attrib.items():
                sched.attributes.append(TableAttribute(name=f"CUSTOM_{k}", value=v))

        df = elem.find(".//DAILYFREQUENCY")
        if df is not None:
            sched.daily_frequency = DailyFrequencyDef(attributes={k: v for k, v in df.attrib.items()})
            for k, v in df.attrib.items():
                sched.attributes.append(TableAttribute(name=f"DAILYFREQUENCY_{k}", value=v))

        rep = elem.find(".//REPEAT")
        if rep is not None:
            sched.repeat = RepeatDef(attributes={k: v for k, v in rep.attrib.items()})
            for k, v in rep.attrib.items():
                sched.attributes.append(TableAttribute(name=f"REPEAT_{k}", value=v))

        filt = elem.find(".//FILTER")
        if filt is not None:
            sched.scheduler_filter = SchedulerFilterDef(attributes={k: v for k, v in filt.attrib.items()})
            for k, v in filt.attrib.items():
                sched.attributes.append(TableAttribute(name=f"FILTER_{k}", value=v))

        return sched

    # ================================================================
    # WORKFLOW + WORKLET + TASKINSTANCE + WORKFLOWLINK
    # + WORKFLOWVARIABLE + WORKFLOWEVENT
    # ================================================================

    def _parse_workflow(self, elem) -> WorkflowDef:
        wf = WorkflowDef(
            name=self._attr(elem, "NAME"),
            description=self._attr(elem, "DESCRIPTION"),
            is_valid=self._attr(elem, "ISVALID", "YES"),
            reusable=self._attr(elem, "REUSABLE", "NO"),
            scheduler_name=self._attr(elem, "SCHEDULERNAME"),
        )

        for ti in elem.findall("TASKINSTANCE"):
            wf.task_instances.append(self._parse_task_instance(ti))

        for link in elem.findall("WORKFLOWLINK"):
            wf.links.append(WorkflowLink(
                from_instance=self._attr(link, "FROMTASK"),
                to_instance=self._attr(link, "TOTASK"),
                condition=self._attr(link, "CONDITION"),
                link_type=self._attr(link, "LINKTYPE"),
            ))

        for wv in elem.findall("WORKFLOWVARIABLE"):
            wf.variables.append(WorkflowVariable(
                name=self._attr(wv, "NAME"),
                datatype=self._attr(wv, "DATATYPE", "string"),
                default_value=self._attr(wv, "DEFAULTVALUE"),
                description=self._attr(wv, "DESCRIPTION"),
                is_null=self._attr(wv, "ISNULL", "NO"),
                is_persistent=self._attr(wv, "ISPERSISTENT", "NO"),
                is_user_defined=self._attr(wv, "ISUSERDEFINED", "YES"),
                precision=self._int_attr(wv, "PRECISION"),
                scale=self._int_attr(wv, "SCALE"),
                usage_type=self._attr(wv, "USAGETYPE"),
            ))

        for we in elem.findall("WORKFLOWEVENT"):
            evt = WorkflowEventDef(
                name=self._attr(we, "NAME"),
                event_type=self._attr(we, "EVENTTYPE"),
                description=self._attr(we, "DESCRIPTION"),
                is_valid=self._attr(we, "ISVALID", "YES"),
            )
            for ta in we.findall("ATTRIBUTE"):
                evt.attributes.append(self._parse_table_attribute(ta))
            wf.events.append(evt)

        for ta in elem.findall("ATTRIBUTE"):
            wf.attributes.append(self._parse_table_attribute(ta))

        for me in elem.findall("METADATAEXTENSION"):
            wf.metadata[self._attr(me, "NAME")] = self._attr(me, "VALUE")
            wf.metadata_extensions.append(self._parse_metadata_extension(me))

        for session in elem.findall("SESSION"):
            pass

        return wf

    def _parse_task_instance(self, elem) -> TaskInstanceDef:
        ti = TaskInstanceDef(
            name=self._attr(elem, "NAME"),
            task_name=self._attr(elem, "TASKNAME"),
            task_type=self._attr(elem, "TASKTYPE"),
            description=self._attr(elem, "DESCRIPTION"),
            is_valid=self._attr(elem, "ISVALID", "YES"),
            reusable=self._attr(elem, "REUSABLE", "NO"),
            fail_parent_if_instance_fails=self._attr(elem, "FAIL_PARENT_IF_INSTANCE_FAILS", "YES"),
            fail_parent_if_instance_did_not_run=self._attr(elem, "FAIL_PARENT_IF_INSTANCE_DID_NOT_RUN", "NO"),
            treat_input_link_as_and=self._attr(elem, "TREAT_INPUTLINKS_AS_AND", "YES"),
        )
        for ta in elem.findall("ATTRIBUTE"):
            ti.attributes.append(self._parse_table_attribute(ta))
        return ti

    # ================================================================
    # CONFIG
    # ================================================================

    def _parse_config(self, elem) -> ConfigDef:
        cfg = ConfigDef(
            name=self._attr(elem, "NAME"),
            description=self._attr(elem, "DESCRIPTION"),
            is_valid=self._attr(elem, "ISVALID", "YES"),
        )
        for ta in elem.findall("ATTRIBUTE"):
            cfg.attributes.append(self._parse_table_attribute(ta))
        for me in elem.findall("METADATAEXTENSION"):
            cfg.metadata_extensions.append(self._parse_metadata_extension(me))
        return cfg

    # ================================================================
    # SHORTCUT
    # ================================================================

    def _parse_shortcut(self, elem) -> ShortcutDef:
        return ShortcutDef(
            name=self._attr(elem, "NAME"),
            shortcut_type=self._attr(elem, "OBJECTSUBTYPE"),
            reference_name=self._attr(elem, "REFOBJECTNAME"),
            folder_name=self._attr(elem, "FOLDERNAME"),
            repository_name=self._attr(elem, "REPOSITORYNAME"),
            object_type=self._attr(elem, "OBJECTTYPE"),
            object_subtype=self._attr(elem, "OBJECTSUBTYPE"),
            dbdname=self._attr(elem, "DBDNAME"),
            version_number=self._int_attr(elem, "VERSIONNUMBER"),
        )
