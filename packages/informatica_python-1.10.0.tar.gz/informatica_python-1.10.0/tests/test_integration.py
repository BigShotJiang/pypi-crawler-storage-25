import os
import sys
import csv
import tempfile
import shutil
import unittest
import pytest
from informatica_python.converter import InformaticaConverter
from informatica_python.utils.expression_converter import (
    convert_expression_vectorized, convert_filter_vectorized,
)
from informatica_python.utils.lib_adapters import (
    lib_merge, lib_sort, lib_groupby_agg, lib_groupby_first,
    lib_concat, lib_empty_df, lib_copy, lib_rank,
)


MINIMAL_XML = '''<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE POWERMART SYSTEM "powrmart.dtd">
<POWERMART CREATION_DATE="01/01/2025" REPOSITORY_VERSION="1">
<REPOSITORY NAME="repo" VERSION="1" CODEPAGE="UTF-8" DATABASETYPE="Oracle">
<FOLDER NAME="TEST_FOLDER" OWNER="admin">
  <SOURCE NAME="SRC_DATA" DATABASETYPE="Flat File" DBDNAME="SRC_DATA">
    <FLATFILE DELIMITEDBY="COMMA" HEADERROWPRESENT="YES" PADBYTES="NO" ROWDELIMITER="\\n"/>
    <SOURCEFIELD NAME="ID" DATATYPE="integer" PRECISION="10" SCALE="0" NULLABLE="NOTNULL" KEYTYPE="PRIMARY KEY" FIELDNUMBER="1"/>
    <SOURCEFIELD NAME="NAME" DATATYPE="string" PRECISION="100" SCALE="0" NULLABLE="NULL" KEYTYPE="NOT A KEY" FIELDNUMBER="2"/>
    <SOURCEFIELD NAME="AMOUNT" DATATYPE="decimal" PRECISION="10" SCALE="2" NULLABLE="NULL" KEYTYPE="NOT A KEY" FIELDNUMBER="3"/>
    <SOURCEFIELD NAME="CATEGORY" DATATYPE="string" PRECISION="50" SCALE="0" NULLABLE="NULL" KEYTYPE="NOT A KEY" FIELDNUMBER="4"/>
  </SOURCE>
  <TARGET NAME="TGT_DATA" DATABASETYPE="Flat File">
    <FLATFILE DELIMITEDBY="COMMA" HEADERROWPRESENT="YES"/>
    <TARGETFIELD NAME="ID" DATATYPE="integer" PRECISION="10" SCALE="0" NULLABLE="NOTNULL" KEYTYPE="PRIMARY KEY" FIELDNUMBER="1"/>
    <TARGETFIELD NAME="NAME_UPPER" DATATYPE="string" PRECISION="100" SCALE="0" NULLABLE="NULL" KEYTYPE="NOT A KEY" FIELDNUMBER="2"/>
    <TARGETFIELD NAME="AMOUNT" DATATYPE="decimal" PRECISION="10" SCALE="2" NULLABLE="NULL" KEYTYPE="NOT A KEY" FIELDNUMBER="3"/>
  </TARGET>
  <MAPPING NAME="m_test_expr" ISVALID="YES">
    <TRANSFORMATION NAME="SQ_SRC_DATA" TYPE="Source Qualifier" REUSABLE="NO">
      <TRANSFORMFIELD NAME="ID" DATATYPE="integer" PORTTYPE="INPUT/OUTPUT" PRECISION="10" SCALE="0"/>
      <TRANSFORMFIELD NAME="NAME" DATATYPE="string" PORTTYPE="INPUT/OUTPUT" PRECISION="100" SCALE="0"/>
      <TRANSFORMFIELD NAME="AMOUNT" DATATYPE="decimal" PORTTYPE="INPUT/OUTPUT" PRECISION="10" SCALE="2"/>
      <TRANSFORMFIELD NAME="CATEGORY" DATATYPE="string" PORTTYPE="INPUT/OUTPUT" PRECISION="50" SCALE="0"/>
    </TRANSFORMATION>
    <TRANSFORMATION NAME="EXP_TRANSFORM" TYPE="Expression" REUSABLE="NO">
      <TRANSFORMFIELD NAME="ID" DATATYPE="integer" PORTTYPE="INPUT/OUTPUT" PRECISION="10" SCALE="0" EXPRESSION="ID"/>
      <TRANSFORMFIELD NAME="NAME" DATATYPE="string" PORTTYPE="INPUT" PRECISION="100" SCALE="0" EXPRESSION="NAME"/>
      <TRANSFORMFIELD NAME="NAME_UPPER" DATATYPE="string" PORTTYPE="OUTPUT" PRECISION="100" SCALE="0" EXPRESSION="UPPER(NAME)"/>
      <TRANSFORMFIELD NAME="AMOUNT" DATATYPE="decimal" PORTTYPE="INPUT/OUTPUT" PRECISION="10" SCALE="2" EXPRESSION="AMOUNT"/>
      <TRANSFORMFIELD NAME="CATEGORY" DATATYPE="string" PORTTYPE="INPUT/OUTPUT" PRECISION="50" SCALE="0" EXPRESSION="CATEGORY"/>
    </TRANSFORMATION>
    <INSTANCE NAME="SRC_DATA" TYPE="Source Definition" TRANSFORMATION_NAME="SRC_DATA" TRANSFORMATION_TYPE="Source Definition"/>
    <INSTANCE NAME="SQ_SRC_DATA" TYPE="Source Qualifier" TRANSFORMATION_NAME="SQ_SRC_DATA" TRANSFORMATION_TYPE="Source Qualifier"/>
    <INSTANCE NAME="EXP_TRANSFORM" TYPE="Expression" TRANSFORMATION_NAME="EXP_TRANSFORM" TRANSFORMATION_TYPE="Expression"/>
    <INSTANCE NAME="TGT_DATA" TYPE="Target Definition" TRANSFORMATION_NAME="TGT_DATA" TRANSFORMATION_TYPE="Target Definition"/>
    <CONNECTOR FROMFIELD="ID" FROMINSTANCE="SRC_DATA" FROMINSTANCETYPE="Source Definition" TOFIELD="ID" TOINSTANCE="SQ_SRC_DATA" TOINSTANCETYPE="Source Qualifier"/>
    <CONNECTOR FROMFIELD="NAME" FROMINSTANCE="SRC_DATA" FROMINSTANCETYPE="Source Definition" TOFIELD="NAME" TOINSTANCE="SQ_SRC_DATA" TOINSTANCETYPE="Source Qualifier"/>
    <CONNECTOR FROMFIELD="AMOUNT" FROMINSTANCE="SRC_DATA" FROMINSTANCETYPE="Source Definition" TOFIELD="AMOUNT" TOINSTANCE="SQ_SRC_DATA" TOINSTANCETYPE="Source Qualifier"/>
    <CONNECTOR FROMFIELD="CATEGORY" FROMINSTANCE="SRC_DATA" FROMINSTANCETYPE="Source Definition" TOFIELD="CATEGORY" TOINSTANCE="SQ_SRC_DATA" TOINSTANCETYPE="Source Qualifier"/>
    <CONNECTOR FROMFIELD="ID" FROMINSTANCE="SQ_SRC_DATA" FROMINSTANCETYPE="Source Qualifier" TOFIELD="ID" TOINSTANCE="EXP_TRANSFORM" TOINSTANCETYPE="Expression"/>
    <CONNECTOR FROMFIELD="NAME" FROMINSTANCE="SQ_SRC_DATA" FROMINSTANCETYPE="Source Qualifier" TOFIELD="NAME" TOINSTANCE="EXP_TRANSFORM" TOINSTANCETYPE="Expression"/>
    <CONNECTOR FROMFIELD="AMOUNT" FROMINSTANCE="SQ_SRC_DATA" FROMINSTANCETYPE="Source Qualifier" TOFIELD="AMOUNT" TOINSTANCE="EXP_TRANSFORM" TOINSTANCETYPE="Expression"/>
    <CONNECTOR FROMFIELD="CATEGORY" FROMINSTANCE="SQ_SRC_DATA" FROMINSTANCETYPE="Source Qualifier" TOFIELD="CATEGORY" TOINSTANCE="EXP_TRANSFORM" TOINSTANCETYPE="Expression"/>
    <CONNECTOR FROMFIELD="ID" FROMINSTANCE="EXP_TRANSFORM" FROMINSTANCETYPE="Expression" TOFIELD="ID" TOINSTANCE="TGT_DATA" TOINSTANCETYPE="Target Definition"/>
    <CONNECTOR FROMFIELD="NAME_UPPER" FROMINSTANCE="EXP_TRANSFORM" FROMINSTANCETYPE="Expression" TOFIELD="NAME_UPPER" TOINSTANCE="TGT_DATA" TOINSTANCETYPE="Target Definition"/>
    <CONNECTOR FROMFIELD="AMOUNT" FROMINSTANCE="EXP_TRANSFORM" FROMINSTANCETYPE="Expression" TOFIELD="AMOUNT" TOINSTANCE="TGT_DATA" TOINSTANCETYPE="Target Definition"/>
    <TARGETLOADORDER ORDER="1" TARGETINSTANCE="TGT_DATA"/>
  </MAPPING>
  <WORKFLOW NAME="wf_test" ISVALID="YES">
    <TASKINSTANCE NAME="Start" TASKNAME="Start" TASKTYPE="Start"/>
  </WORKFLOW>
</FOLDER>
</REPOSITORY>
</POWERMART>'''


FILTER_XML = '''<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE POWERMART SYSTEM "powrmart.dtd">
<POWERMART CREATION_DATE="01/01/2025" REPOSITORY_VERSION="1">
<REPOSITORY NAME="repo" VERSION="1" CODEPAGE="UTF-8" DATABASETYPE="Oracle">
<FOLDER NAME="TEST_FILTER" OWNER="admin">
  <SOURCE NAME="SRC_FILTER" DATABASETYPE="Flat File" DBDNAME="SRC_FILTER">
    <FLATFILE DELIMITEDBY="COMMA" HEADERROWPRESENT="YES"/>
    <SOURCEFIELD NAME="ID" DATATYPE="integer" PRECISION="10" SCALE="0" NULLABLE="NOTNULL" KEYTYPE="PRIMARY KEY" FIELDNUMBER="1"/>
    <SOURCEFIELD NAME="STATUS" DATATYPE="string" PRECISION="20" SCALE="0" NULLABLE="NULL" KEYTYPE="NOT A KEY" FIELDNUMBER="2"/>
    <SOURCEFIELD NAME="VALUE" DATATYPE="integer" PRECISION="10" SCALE="0" NULLABLE="NULL" KEYTYPE="NOT A KEY" FIELDNUMBER="3"/>
  </SOURCE>
  <TARGET NAME="TGT_FILTER" DATABASETYPE="Flat File">
    <FLATFILE DELIMITEDBY="COMMA" HEADERROWPRESENT="YES"/>
    <TARGETFIELD NAME="ID" DATATYPE="integer" PRECISION="10" SCALE="0" NULLABLE="NOTNULL" KEYTYPE="PRIMARY KEY" FIELDNUMBER="1"/>
    <TARGETFIELD NAME="STATUS" DATATYPE="string" PRECISION="20" SCALE="0" NULLABLE="NULL" KEYTYPE="NOT A KEY" FIELDNUMBER="2"/>
    <TARGETFIELD NAME="VALUE" DATATYPE="integer" PRECISION="10" SCALE="0" NULLABLE="NULL" KEYTYPE="NOT A KEY" FIELDNUMBER="3"/>
  </TARGET>
  <MAPPING NAME="m_test_filter" ISVALID="YES">
    <TRANSFORMATION NAME="SQ_SRC_FILTER" TYPE="Source Qualifier" REUSABLE="NO">
      <TRANSFORMFIELD NAME="ID" DATATYPE="integer" PORTTYPE="INPUT/OUTPUT" PRECISION="10" SCALE="0"/>
      <TRANSFORMFIELD NAME="STATUS" DATATYPE="string" PORTTYPE="INPUT/OUTPUT" PRECISION="20" SCALE="0"/>
      <TRANSFORMFIELD NAME="VALUE" DATATYPE="integer" PORTTYPE="INPUT/OUTPUT" PRECISION="10" SCALE="0"/>
    </TRANSFORMATION>
    <TRANSFORMATION NAME="FIL_ACTIVE" TYPE="Filter" REUSABLE="NO">
      <TRANSFORMFIELD NAME="ID" DATATYPE="integer" PORTTYPE="INPUT/OUTPUT" PRECISION="10" SCALE="0"/>
      <TRANSFORMFIELD NAME="STATUS" DATATYPE="string" PORTTYPE="INPUT/OUTPUT" PRECISION="20" SCALE="0"/>
      <TRANSFORMFIELD NAME="VALUE" DATATYPE="integer" PORTTYPE="INPUT/OUTPUT" PRECISION="10" SCALE="0"/>
      <TABLEATTRIBUTE NAME="Filter Condition" VALUE="VALUE > 50"/>
    </TRANSFORMATION>
    <INSTANCE NAME="SRC_FILTER" TYPE="Source Definition" TRANSFORMATION_NAME="SRC_FILTER"/>
    <INSTANCE NAME="SQ_SRC_FILTER" TYPE="Source Qualifier" TRANSFORMATION_NAME="SQ_SRC_FILTER"/>
    <INSTANCE NAME="FIL_ACTIVE" TYPE="Filter" TRANSFORMATION_NAME="FIL_ACTIVE"/>
    <INSTANCE NAME="TGT_FILTER" TYPE="Target Definition" TRANSFORMATION_NAME="TGT_FILTER"/>
    <CONNECTOR FROMFIELD="ID" FROMINSTANCE="SRC_FILTER" TOFIELD="ID" TOINSTANCE="SQ_SRC_FILTER"/>
    <CONNECTOR FROMFIELD="STATUS" FROMINSTANCE="SRC_FILTER" TOFIELD="STATUS" TOINSTANCE="SQ_SRC_FILTER"/>
    <CONNECTOR FROMFIELD="VALUE" FROMINSTANCE="SRC_FILTER" TOFIELD="VALUE" TOINSTANCE="SQ_SRC_FILTER"/>
    <CONNECTOR FROMFIELD="ID" FROMINSTANCE="SQ_SRC_FILTER" TOFIELD="ID" TOINSTANCE="FIL_ACTIVE"/>
    <CONNECTOR FROMFIELD="STATUS" FROMINSTANCE="SQ_SRC_FILTER" TOFIELD="STATUS" TOINSTANCE="FIL_ACTIVE"/>
    <CONNECTOR FROMFIELD="VALUE" FROMINSTANCE="SQ_SRC_FILTER" TOFIELD="VALUE" TOINSTANCE="FIL_ACTIVE"/>
    <CONNECTOR FROMFIELD="ID" FROMINSTANCE="FIL_ACTIVE" TOFIELD="ID" TOINSTANCE="TGT_FILTER"/>
    <CONNECTOR FROMFIELD="STATUS" FROMINSTANCE="FIL_ACTIVE" TOFIELD="STATUS" TOINSTANCE="TGT_FILTER"/>
    <CONNECTOR FROMFIELD="VALUE" FROMINSTANCE="FIL_ACTIVE" TOFIELD="VALUE" TOINSTANCE="TGT_FILTER"/>
    <TARGETLOADORDER ORDER="1" TARGETINSTANCE="TGT_FILTER"/>
  </MAPPING>
  <WORKFLOW NAME="wf_filter_test" ISVALID="YES">
    <TASKINSTANCE NAME="Start" TASKNAME="Start" TASKTYPE="Start"/>
  </WORKFLOW>
</FOLDER>
</REPOSITORY>
</POWERMART>'''


class TestVectorizedExpressions:

    def test_simple_field_ref(self):
        result = convert_expression_vectorized("NAME")
        assert result == 'df["NAME"]'

    def test_numeric_literal(self):
        assert convert_expression_vectorized("42") == "42"
        assert convert_expression_vectorized("3.14") == "3.14"

    def test_string_literal(self):
        assert convert_expression_vectorized("'hello'") == "'hello'"

    def test_upper(self):
        result = convert_expression_vectorized("UPPER(NAME)")
        assert '.str.upper()' in result
        assert '"NAME"' in result

    def test_lower(self):
        result = convert_expression_vectorized("LOWER(CITY)")
        assert '.str.lower()' in result

    def test_trim(self):
        result = convert_expression_vectorized("TRIM(CODE)")
        assert '.str.strip()' in result

    def test_ltrim(self):
        result = convert_expression_vectorized("LTRIM(CODE)")
        assert '.str.lstrip()' in result

    def test_iif_to_np_where(self):
        result = convert_expression_vectorized("IIF(STATUS = 'A', 1, 0)")
        assert "np.where" in result

    def test_nvl_to_fillna(self):
        result = convert_expression_vectorized("NVL(AMOUNT, 0)")
        assert ".fillna(" in result
        assert '"AMOUNT"' in result

    def test_to_integer(self):
        result = convert_expression_vectorized("TO_INTEGER(PRICE)")
        assert "pd.to_numeric" in result

    def test_to_date(self):
        result = convert_expression_vectorized("TO_DATE(DATE_STR)")
        assert "pd.to_datetime" in result

    def test_to_date_with_format(self):
        result = convert_expression_vectorized("TO_DATE(DATE_STR, 'YYYY-MM-DD')")
        assert "pd.to_datetime" in result
        assert "%Y" in result

    def test_substr(self):
        result = convert_expression_vectorized("SUBSTR(NAME, 1, 3)")
        assert ".str[" in result

    def test_is_null(self):
        result = convert_expression_vectorized("NAME IS NULL")
        assert ".isna()" in result

    def test_is_not_null(self):
        result = convert_expression_vectorized("NAME IS NOT NULL")
        assert ".notna()" in result

    def test_custom_df_var(self):
        result = convert_expression_vectorized("UPPER(NAME)", df_var="df_expr")
        assert 'df_expr["NAME"]' in result

    def test_none_expr(self):
        assert convert_expression_vectorized(None) == "None"
        assert convert_expression_vectorized("") == "None"


class TestFilterVectorized:

    def test_simple_comparison(self):
        result = convert_filter_vectorized("VALUE > 50", "df_src")
        assert ">" in result
        assert "50" in result
        assert 'df_src["VALUE"]' in result

    def test_and_condition(self):
        result = convert_filter_vectorized("A > 1 AND B < 2", "df")
        assert "&" in result
        assert 'df["A"]' in result
        assert 'df["B"]' in result
        assert "AND" not in result
        assert "(df[" in result

    def test_or_condition(self):
        result = convert_filter_vectorized("STATUS = 'A' OR STATUS = 'B'", "df")
        assert "|" in result
        assert "(df[" in result

    def test_not_condition(self):
        result = convert_filter_vectorized("NOT A = 1", "df")
        assert "~(" in result
        assert 'df["A"]' in result
        assert "==" in result

    def test_is_null_filter(self):
        result = convert_filter_vectorized("NAME IS NULL", "df_src")
        assert ".isna()" in result
        assert 'df_src["NAME"]' in result

    def test_is_not_null_filter(self):
        result = convert_filter_vectorized("NAME IS NOT NULL", "df_src")
        assert ".notna()" in result

    def test_empty_filter(self):
        assert convert_filter_vectorized("") == "True"
        assert convert_filter_vectorized(None) == "True"

    def test_compound_iif(self):
        result = convert_expression_vectorized("IIF(A > 1 AND B < 2, 1, 0)", "df")
        assert "np.where" in result
        assert "&" in result
        assert "(" in result


class TestLibAdapters:

    def test_pandas_merge_on(self):
        result = lib_merge("pandas", "df1", "df2", on=["ID"])
        assert ".merge(" in result
        assert "on=['ID']" in result

    def test_polars_merge_on(self):
        result = lib_merge("polars", "df1", "df2", on=["ID"])
        assert ".join(" in result
        assert "on=['ID']" in result

    def test_dask_merge(self):
        result = lib_merge("dask", "df1", "df2", left_on=["A"], right_on=["B"])
        assert "dd.merge(" in result

    def test_pandas_sort(self):
        result = lib_sort("pandas", "df", ["A", "B"], [True, False])
        assert ".sort_values(" in result
        assert "reset_index" in result

    def test_polars_sort(self):
        result = lib_sort("polars", "df", ["A", "B"], [True, False])
        assert ".sort(" in result
        assert "descending=" in result

    def test_pandas_groupby(self):
        spec = {"total": ("amount", "sum"), "cnt": ("id", "count")}
        result = lib_groupby_agg("pandas", "df", ["cat"], spec)
        assert ".groupby(" in result
        assert "as_index=False" in result

    def test_polars_groupby(self):
        spec = {"total": ("amount", "sum")}
        result = lib_groupby_agg("polars", "df", ["cat"], spec)
        assert ".group_by(" in result
        assert "pl.col(" in result

    def test_pandas_concat(self):
        result = lib_concat("pandas", "df1, df2")
        assert "pd.concat(" in result

    def test_polars_concat(self):
        result = lib_concat("polars", "df1, df2")
        assert "pl.concat(" in result

    def test_dask_concat(self):
        result = lib_concat("dask", "df1, df2")
        assert "dd.concat(" in result

    def test_copy_pandas(self):
        assert lib_copy("pandas", "df") == "df.copy()"

    def test_copy_polars(self):
        assert lib_copy("polars", "df") == "df.clone()"

    def test_empty_pandas(self):
        assert lib_empty_df("pandas") == "pd.DataFrame()"

    def test_empty_polars(self):
        assert lib_empty_df("polars") == "pl.DataFrame()"


class TestParamFileGeneration:

    def test_helper_contains_param_functions(self):
        from informatica_python.models import FolderDef
        from informatica_python.generators.helper_gen import generate_helper_functions
        folder = FolderDef(name="test")
        code = generate_helper_functions(folder, "pandas")
        assert "parse_param_file" in code
        assert "get_param" in code
        assert "param_file" in code

    def test_load_config_accepts_param_file(self):
        from informatica_python.models import FolderDef
        from informatica_python.generators.helper_gen import generate_helper_functions
        folder = FolderDef(name="test")
        code = generate_helper_functions(folder, "pandas")
        assert "def load_config(config_path='config.yml', param_file=None):" in code


class TestCodeGeneration:

    def setup_method(self):
        self.tmpdir = tempfile.mkdtemp()

    def teardown_method(self):
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_expression_mapping_generates_vectorized(self):
        converter = InformaticaConverter(data_lib="pandas")
        output = converter.convert_string(MINIMAL_XML, output_dir=self.tmpdir)

        mapping_path = os.path.join(output, "mapping_m_test_expr.py")
        assert os.path.exists(mapping_path)

        with open(mapping_path) as f:
            code = f.read()
        assert 'import numpy as np' in code
        assert '.str.upper()' in code
        assert '.apply(' not in code

    def test_filter_mapping_generates_vectorized(self):
        converter = InformaticaConverter(data_lib="pandas")
        output = converter.convert_string(FILTER_XML, output_dir=self.tmpdir)

        mapping_path = os.path.join(output, "mapping_m_test_filter.py")
        with open(mapping_path) as f:
            code = f.read()
        assert 'Filter' in code

    def test_polars_codegen(self):
        converter = InformaticaConverter(data_lib="polars")
        output = converter.convert_string(MINIMAL_XML, output_dir=self.tmpdir)

        helper_path = os.path.join(output, "helper_functions.py")
        with open(helper_path) as f:
            code = f.read()
        assert "import polars as pl" in code

    def test_dask_codegen(self):
        converter = InformaticaConverter(data_lib="dask")
        output = converter.convert_string(MINIMAL_XML, output_dir=self.tmpdir)

        helper_path = os.path.join(output, "helper_functions.py")
        with open(helper_path) as f:
            code = f.read()
        assert "import dask.dataframe as dd" in code

    def test_all_required_files_generated(self):
        converter = InformaticaConverter(data_lib="pandas")
        output = converter.convert_string(MINIMAL_XML, output_dir=self.tmpdir)

        expected_files = [
            "helper_functions.py", "mapping_m_test_expr.py", "workflow.py",
            "config.yml", "all_sql_queries.sql", "error_log.txt",
        ]
        for fname in expected_files:
            fpath = os.path.join(output, fname)
            assert os.path.exists(fpath), f"Missing file: {fname}"

    def test_generated_helper_is_valid_python(self):
        converter = InformaticaConverter(data_lib="pandas")
        output = converter.convert_string(MINIMAL_XML, output_dir=self.tmpdir)

        helper_path = os.path.join(output, "helper_functions.py")
        with open(helper_path) as f:
            code = f.read()
        compile(code, helper_path, "exec")

    def test_generated_mapping_is_valid_python(self):
        converter = InformaticaConverter(data_lib="pandas")
        output = converter.convert_string(MINIMAL_XML, output_dir=self.tmpdir)

        mapping_path = os.path.join(output, "mapping_m_test_expr.py")
        with open(mapping_path) as f:
            code = f.read()
        compile(code, mapping_path, "exec")

    def test_generated_workflow_is_valid_python(self):
        converter = InformaticaConverter(data_lib="pandas")
        output = converter.convert_string(MINIMAL_XML, output_dir=self.tmpdir)

        wf_path = os.path.join(output, "workflow.py")
        with open(wf_path) as f:
            code = f.read()
        compile(code, wf_path, "exec")


SESSION_WORKFLOW_XML = '''<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE POWERMART SYSTEM "powrmart.dtd">
<POWERMART CREATION_DATE="01/01/2025" REPOSITORY_VERSION="1">
<REPOSITORY NAME="repo" VERSION="1" CODEPAGE="UTF-8" DATABASETYPE="Oracle">
<FOLDER NAME="TEST_FOLDER" OWNER="admin">
  <SOURCE NAME="SRC_ORDERS" DATABASETYPE="Flat File" DBDNAME="SRC_ORDERS">
    <FLATFILE DELIMITEDBY="COMMA" HEADERROWPRESENT="YES" PADBYTES="NO"/>
    <SOURCEFIELD NAME="ORDER_ID" DATATYPE="integer" PRECISION="10" SCALE="0" NULLABLE="NOTNULL" KEYTYPE="PRIMARY KEY" FIELDNUMBER="1"/>
    <SOURCEFIELD NAME="AMOUNT" DATATYPE="decimal" PRECISION="10" SCALE="2" NULLABLE="NULL" KEYTYPE="NOT A KEY" FIELDNUMBER="2"/>
  </SOURCE>
  <TARGET NAME="TGT_ORDERS" DATABASETYPE="Flat File">
    <FLATFILE DELIMITEDBY="COMMA" HEADERROWPRESENT="YES"/>
    <TARGETFIELD NAME="ORDER_ID" DATATYPE="integer" PRECISION="10" SCALE="0" NULLABLE="NOTNULL" KEYTYPE="PRIMARY KEY" FIELDNUMBER="1"/>
    <TARGETFIELD NAME="AMOUNT" DATATYPE="decimal" PRECISION="10" SCALE="2" NULLABLE="NULL" KEYTYPE="NOT A KEY" FIELDNUMBER="2"/>
  </TARGET>
  <MAPPING NAME="m_orders" ISVALID="YES">
    <TRANSFORMATION NAME="SQ_SRC_ORDERS" TYPE="Source Qualifier" REUSABLE="NO">
      <TRANSFORMFIELD NAME="ORDER_ID" DATATYPE="integer" PORTTYPE="INPUT/OUTPUT" PRECISION="10" SCALE="0"/>
      <TRANSFORMFIELD NAME="AMOUNT" DATATYPE="decimal" PORTTYPE="INPUT/OUTPUT" PRECISION="10" SCALE="2"/>
    </TRANSFORMATION>
    <INSTANCE NAME="SRC_ORDERS" TYPE="Source Definition" TRANSFORMATION_NAME="SRC_ORDERS" TRANSFORMATION_TYPE="Source Definition"/>
    <INSTANCE NAME="SQ_SRC_ORDERS" TYPE="Source Qualifier" TRANSFORMATION_NAME="SQ_SRC_ORDERS" TRANSFORMATION_TYPE="Source Qualifier"/>
    <INSTANCE NAME="TGT_ORDERS" TYPE="Target Definition" TRANSFORMATION_NAME="TGT_ORDERS" TRANSFORMATION_TYPE="Target Definition"/>
    <CONNECTOR FROMFIELD="ORDER_ID" FROMINSTANCE="SRC_ORDERS" FROMINSTANCETYPE="Source Definition" TOFIELD="ORDER_ID" TOINSTANCE="SQ_SRC_ORDERS" TOINSTANCETYPE="Source Qualifier"/>
    <CONNECTOR FROMFIELD="AMOUNT" FROMINSTANCE="SRC_ORDERS" FROMINSTANCETYPE="Source Definition" TOFIELD="AMOUNT" TOINSTANCE="SQ_SRC_ORDERS" TOINSTANCETYPE="Source Qualifier"/>
    <CONNECTOR FROMFIELD="ORDER_ID" FROMINSTANCE="SQ_SRC_ORDERS" FROMINSTANCETYPE="Source Qualifier" TOFIELD="ORDER_ID" TOINSTANCE="TGT_ORDERS" TOINSTANCETYPE="Target Definition"/>
    <CONNECTOR FROMFIELD="AMOUNT" FROMINSTANCE="SQ_SRC_ORDERS" FROMINSTANCETYPE="Source Qualifier" TOFIELD="AMOUNT" TOINSTANCE="TGT_ORDERS" TOINSTANCETYPE="Target Definition"/>
    <TARGETLOADORDER ORDER="1" TARGETINSTANCE="TGT_ORDERS"/>
  </MAPPING>
  <SESSION NAME="s_m_orders" MAPPINGNAME="m_orders" ISVALID="YES"/>
  <WORKFLOW NAME="wf_orders" ISVALID="YES">
    <TASKINSTANCE NAME="Start" TASKNAME="Start" TASKTYPE="Start"/>
    <TASKINSTANCE NAME="s_m_orders" TASKNAME="s_m_orders" TASKTYPE="Session" FAIL_PARENT_IF_INSTANCE_FAILS="YES"/>
    <WORKFLOWLINK FROMTASK="Start" TOTASK="s_m_orders"/>
  </WORKFLOW>
</FOLDER>
</REPOSITORY>
</POWERMART>'''


UPPERCASE_INSTANCE_TYPE_XML = '''<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE POWERMART SYSTEM "powrmart.dtd">
<POWERMART CREATION_DATE="01/01/2025" REPOSITORY_VERSION="1">
<REPOSITORY NAME="repo" VERSION="1" CODEPAGE="UTF-8" DATABASETYPE="Oracle">
<FOLDER NAME="TEST_FOLDER" OWNER="admin">
  <SOURCE NAME="SRC_DATA" DATABASETYPE="Flat File" DBDNAME="SRC_DATA">
    <SOURCEFIELD NAME="ID" DATATYPE="integer" PRECISION="10" SCALE="0" NULLABLE="NULL" KEYTYPE="NOT A KEY" FIELDNUMBER="1"/>
  </SOURCE>
  <TARGET NAME="TGT_DATA" DATABASETYPE="Flat File">
    <TARGETFIELD NAME="ID" DATATYPE="integer" PRECISION="10" SCALE="0" NULLABLE="NULL" KEYTYPE="NOT A KEY" FIELDNUMBER="1"/>
  </TARGET>
  <MAPPING NAME="m_upper" ISVALID="YES">
    <TRANSFORMATION NAME="SQ_SRC" TYPE="Source Qualifier" REUSABLE="NO">
      <TRANSFORMFIELD NAME="ID" DATATYPE="integer" PORTTYPE="INPUT/OUTPUT" PRECISION="10" SCALE="0"/>
    </TRANSFORMATION>
    <INSTANCE NAME="SRC_DATA" TYPE="SOURCE" TRANSFORMATION_NAME="SRC_DATA" TRANSFORMATION_TYPE="Source Definition"/>
    <INSTANCE NAME="SQ_SRC" TYPE="TRANSFORMATION" TRANSFORMATION_NAME="SQ_SRC" TRANSFORMATION_TYPE="Source Qualifier"/>
    <INSTANCE NAME="TGT_DATA" TYPE="TARGET" TRANSFORMATION_NAME="TGT_DATA" TRANSFORMATION_TYPE="Target Definition"/>
    <CONNECTOR FROMFIELD="ID" FROMINSTANCE="SRC_DATA" FROMINSTANCETYPE="Source Definition" TOFIELD="ID" TOINSTANCE="SQ_SRC" TOINSTANCETYPE="Source Qualifier"/>
    <CONNECTOR FROMFIELD="ID" FROMINSTANCE="SQ_SRC" FROMINSTANCETYPE="Source Qualifier" TOFIELD="ID" TOINSTANCE="TGT_DATA" TOINSTANCETYPE="Target Definition"/>
    <TARGETLOADORDER ORDER="1" TARGETINSTANCE="TGT_DATA"/>
  </MAPPING>
  <WORKFLOW NAME="wf_upper" ISVALID="YES">
    <TASKINSTANCE NAME="Start" TASKNAME="Start" TASKTYPE="Start"/>
  </WORKFLOW>
</FOLDER>
</REPOSITORY>
</POWERMART>'''


class TestCodeQuality:

    def setup_method(self):
        self.tmpdir = tempfile.mkdtemp()

    def teardown_method(self):
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_no_verbose_try_except_around_len(self):
        converter = InformaticaConverter(data_lib="pandas")
        output = converter.convert_string(MINIMAL_XML, output_dir=self.tmpdir)
        mapping_path = os.path.join(output, "mapping_m_test_expr.py")
        with open(mapping_path) as f:
            code = f.read()
        assert "count unavailable" not in code
        assert "except Exception:" not in code

    def test_no_todo_in_workflow_start_task(self):
        converter = InformaticaConverter(data_lib="pandas")
        output = converter.convert_string(SESSION_WORKFLOW_XML, output_dir=self.tmpdir)
        wf_path = os.path.join(output, "workflow.py")
        with open(wf_path) as f:
            code = f.read()
        assert "# TODO" not in code
        assert "Workflow started" in code

    def test_session_maps_to_mapping_function(self):
        converter = InformaticaConverter(data_lib="pandas")
        output = converter.convert_string(SESSION_WORKFLOW_XML, output_dir=self.tmpdir)
        wf_path = os.path.join(output, "workflow.py")
        with open(wf_path) as f:
            code = f.read()
        assert "run_m_orders(config)" in code
        assert "no mapped function" not in code

    def test_docstring_sources_targets_not_none(self):
        converter = InformaticaConverter(data_lib="pandas")
        output = converter.convert_string(SESSION_WORKFLOW_XML, output_dir=self.tmpdir)
        mapping_path = os.path.join(output, "mapping_m_orders.py")
        with open(mapping_path) as f:
            code = f.read()
        assert "Sources: SRC_ORDERS" in code
        assert "Targets: TGT_ORDERS" in code
        assert "Sources: None" not in code
        assert "Targets: None" not in code

    def test_uppercase_instance_types_resolve_sources_targets(self):
        converter = InformaticaConverter(data_lib="pandas")
        output = converter.convert_string(UPPERCASE_INSTANCE_TYPE_XML, output_dir=self.tmpdir)
        mapping_path = os.path.join(output, "mapping_m_upper.py")
        with open(mapping_path) as f:
            code = f.read()
        assert "Sources: SRC_DATA" in code
        assert "Targets: TGT_DATA" in code

    def test_start_task_type_both_forms(self):
        converter = InformaticaConverter(data_lib="pandas")
        output = converter.convert_string(UPPERCASE_INSTANCE_TYPE_XML, output_dir=self.tmpdir)
        wf_path = os.path.join(output, "workflow.py")
        with open(wf_path) as f:
            code = f.read()
        assert "# TODO" not in code
        assert "# Start Task" in code

    def test_session_infers_mapping_without_session_def(self):
        xml = '''<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE POWERMART SYSTEM "powrmart.dtd">
<POWERMART CREATION_DATE="01/01/2025" REPOSITORY_VERSION="1">
<REPOSITORY NAME="repo" VERSION="1" CODEPAGE="UTF-8" DATABASETYPE="Oracle">
<FOLDER NAME="TEST_FOLDER" OWNER="admin">
  <SOURCE NAME="SRC" DATABASETYPE="Flat File" DBDNAME="SRC">
    <SOURCEFIELD NAME="ID" DATATYPE="integer" PRECISION="10" SCALE="0" NULLABLE="NULL" KEYTYPE="NOT A KEY" FIELDNUMBER="1"/>
  </SOURCE>
  <TARGET NAME="TGT" DATABASETYPE="Flat File">
    <TARGETFIELD NAME="ID" DATATYPE="integer" PRECISION="10" SCALE="0" NULLABLE="NULL" KEYTYPE="NOT A KEY" FIELDNUMBER="1"/>
  </TARGET>
  <MAPPING NAME="m_load_data" ISVALID="YES">
    <TRANSFORMATION NAME="SQ_SRC" TYPE="Source Qualifier" REUSABLE="NO">
      <TRANSFORMFIELD NAME="ID" DATATYPE="integer" PORTTYPE="INPUT/OUTPUT" PRECISION="10" SCALE="0"/>
    </TRANSFORMATION>
    <INSTANCE NAME="SRC" TYPE="Source Definition" TRANSFORMATION_NAME="SRC" TRANSFORMATION_TYPE="Source Definition"/>
    <INSTANCE NAME="SQ_SRC" TYPE="Source Qualifier" TRANSFORMATION_NAME="SQ_SRC" TRANSFORMATION_TYPE="Source Qualifier"/>
    <INSTANCE NAME="TGT" TYPE="Target Definition" TRANSFORMATION_NAME="TGT" TRANSFORMATION_TYPE="Target Definition"/>
    <CONNECTOR FROMFIELD="ID" FROMINSTANCE="SRC" FROMINSTANCETYPE="Source Definition" TOFIELD="ID" TOINSTANCE="SQ_SRC" TOINSTANCETYPE="Source Qualifier"/>
    <CONNECTOR FROMFIELD="ID" FROMINSTANCE="SQ_SRC" FROMINSTANCETYPE="Source Qualifier" TOFIELD="ID" TOINSTANCE="TGT" TOINSTANCETYPE="Target Definition"/>
    <TARGETLOADORDER ORDER="1" TARGETINSTANCE="TGT"/>
  </MAPPING>
  <WORKFLOW NAME="wf_test" ISVALID="YES">
    <TASKINSTANCE NAME="Start" TASKNAME="Start" TASKTYPE="Start"/>
    <TASKINSTANCE NAME="s_m_load_data" TASKNAME="s_m_load_data" TASKTYPE="Session"/>
    <WORKFLOWLINK FROMTASK="Start" TOTASK="s_m_load_data"/>
  </WORKFLOW>
</FOLDER>
</REPOSITORY>
</POWERMART>'''
        converter = InformaticaConverter(data_lib="pandas")
        output = converter.convert_string(xml, output_dir=self.tmpdir)
        wf_path = os.path.join(output, "workflow.py")
        with open(wf_path) as f:
            code = f.read()
        assert "run_m_load_data(config)" in code
        assert "no mapped function" not in code

    def test_session_prefers_longest_mapping_match(self):
        xml = '''<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE POWERMART SYSTEM "powrmart.dtd">
<POWERMART CREATION_DATE="01/01/2025" REPOSITORY_VERSION="1">
<REPOSITORY NAME="repo" VERSION="1" CODEPAGE="UTF-8" DATABASETYPE="Oracle">
<FOLDER NAME="TEST" OWNER="admin">
  <SOURCE NAME="SRC" DATABASETYPE="Flat File" DBDNAME="SRC">
    <SOURCEFIELD NAME="ID" DATATYPE="integer" PRECISION="10" SCALE="0" NULLABLE="NULL" KEYTYPE="NOT A KEY" FIELDNUMBER="1"/>
  </SOURCE>
  <TARGET NAME="TGT" DATABASETYPE="Flat File">
    <TARGETFIELD NAME="ID" DATATYPE="integer" PRECISION="10" SCALE="0" NULLABLE="NULL" KEYTYPE="NOT A KEY" FIELDNUMBER="1"/>
  </TARGET>
  <MAPPING NAME="m_orders" ISVALID="YES">
    <TRANSFORMATION NAME="SQ1" TYPE="Source Qualifier" REUSABLE="NO">
      <TRANSFORMFIELD NAME="ID" DATATYPE="integer" PORTTYPE="INPUT/OUTPUT" PRECISION="10" SCALE="0"/>
    </TRANSFORMATION>
    <INSTANCE NAME="SRC" TYPE="Source Definition" TRANSFORMATION_NAME="SRC" TRANSFORMATION_TYPE="Source Definition"/>
    <INSTANCE NAME="SQ1" TYPE="Source Qualifier" TRANSFORMATION_NAME="SQ1" TRANSFORMATION_TYPE="Source Qualifier"/>
    <INSTANCE NAME="TGT" TYPE="Target Definition" TRANSFORMATION_NAME="TGT" TRANSFORMATION_TYPE="Target Definition"/>
    <CONNECTOR FROMFIELD="ID" FROMINSTANCE="SRC" FROMINSTANCETYPE="Source Definition" TOFIELD="ID" TOINSTANCE="SQ1" TOINSTANCETYPE="Source Qualifier"/>
    <CONNECTOR FROMFIELD="ID" FROMINSTANCE="SQ1" FROMINSTANCETYPE="Source Qualifier" TOFIELD="ID" TOINSTANCE="TGT" TOINSTANCETYPE="Target Definition"/>
    <TARGETLOADORDER ORDER="1" TARGETINSTANCE="TGT"/>
  </MAPPING>
  <MAPPING NAME="m_orders_archive" ISVALID="YES">
    <TRANSFORMATION NAME="SQ2" TYPE="Source Qualifier" REUSABLE="NO">
      <TRANSFORMFIELD NAME="ID" DATATYPE="integer" PORTTYPE="INPUT/OUTPUT" PRECISION="10" SCALE="0"/>
    </TRANSFORMATION>
    <INSTANCE NAME="SRC" TYPE="Source Definition" TRANSFORMATION_NAME="SRC" TRANSFORMATION_TYPE="Source Definition"/>
    <INSTANCE NAME="SQ2" TYPE="Source Qualifier" TRANSFORMATION_NAME="SQ2" TRANSFORMATION_TYPE="Source Qualifier"/>
    <INSTANCE NAME="TGT" TYPE="Target Definition" TRANSFORMATION_NAME="TGT" TRANSFORMATION_TYPE="Target Definition"/>
    <CONNECTOR FROMFIELD="ID" FROMINSTANCE="SRC" FROMINSTANCETYPE="Source Definition" TOFIELD="ID" TOINSTANCE="SQ2" TOINSTANCETYPE="Source Qualifier"/>
    <CONNECTOR FROMFIELD="ID" FROMINSTANCE="SQ2" FROMINSTANCETYPE="Source Qualifier" TOFIELD="ID" TOINSTANCE="TGT" TOINSTANCETYPE="Target Definition"/>
    <TARGETLOADORDER ORDER="1" TARGETINSTANCE="TGT"/>
  </MAPPING>
  <WORKFLOW NAME="wf_test" ISVALID="YES">
    <TASKINSTANCE NAME="Start" TASKNAME="Start" TASKTYPE="Start"/>
    <TASKINSTANCE NAME="s_m_orders_archive" TASKNAME="s_m_orders_archive" TASKTYPE="Session"/>
    <WORKFLOWLINK FROMTASK="Start" TOTASK="s_m_orders_archive"/>
  </WORKFLOW>
</FOLDER>
</REPOSITORY>
</POWERMART>'''
        converter = InformaticaConverter(data_lib="pandas")
        output = converter.convert_string(xml, output_dir=self.tmpdir)
        wf_path = os.path.join(output, "workflow.py")
        with open(wf_path) as f:
            code = f.read()
        assert "run_m_orders_archive(config)" in code
        assert "run_m_orders(config)" not in code or "run_m_orders_archive(config)" in code


class TestParamFileRoundTrip:

    def setup_method(self):
        self.tmpdir = tempfile.mkdtemp()

    def teardown_method(self):
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_param_file_parsing_in_generated_code(self):
        converter = InformaticaConverter(data_lib="pandas")
        output = converter.convert_string(MINIMAL_XML, output_dir=self.tmpdir)

        param_path = os.path.join(self.tmpdir, "test.param")
        with open(param_path, "w") as f:
            f.write("[Global]\n")
            f.write("$$SRC_DIR=/data/source\n")
            f.write("$$TGT_DIR=/data/target\n")
            f.write("[TEST_FOLDER.WF:wf_test.ST:s_test]\n")
            f.write("$$CONN_STRING=oracle://host:1521/db\n")

        helper_path = os.path.join(output, "helper_functions.py")
        with open(helper_path) as f:
            helper_code = f.read()

        exec_globals = {"__builtins__": __builtins__}
        exec(helper_code, exec_globals)

        parse_fn = exec_globals.get("parse_param_file")
        assert parse_fn is not None
        params = parse_fn(param_path)
        assert params["SRC_DIR"] == "/data/source"
        assert params["TGT_DIR"] == "/data/target"
        assert params["CONN_STRING"] == "oracle://host:1521/db"
        assert "TEST_FOLDER.WF:wf_test.ST:s_test.CONN_STRING" in params

    def test_get_param_function(self):
        converter = InformaticaConverter(data_lib="pandas")
        output = converter.convert_string(MINIMAL_XML, output_dir=self.tmpdir)

        helper_path = os.path.join(output, "helper_functions.py")
        with open(helper_path) as f:
            helper_code = f.read()

        exec_globals = {"__builtins__": __builtins__}
        exec(helper_code, exec_globals)

        get_param_fn = exec_globals.get("get_param")
        assert get_param_fn is not None

        config = {"params": {"DB_HOST": "localhost", "DB_PORT": "5432"}}
        assert get_param_fn(config, "DB_HOST") == "localhost"
        assert get_param_fn(config, "$$DB_PORT") == "5432"
        assert get_param_fn(config, "MISSING", "default_val") == "default_val"


class TestRealXMLConversion:

    def setup_method(self):
        self.tmpdir = tempfile.mkdtemp()

    def teardown_method(self):
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def _get_xml_files(self):
        assets_dir = os.path.join(os.path.dirname(__file__), "..", "attached_assets")
        if not os.path.isdir(assets_dir):
            return []
        return [
            os.path.join(assets_dir, f)
            for f in os.listdir(assets_dir)
            if f.endswith(".xml") or f.endswith(".XML")
        ]

    def test_real_xml_generates_valid_python(self):
        xml_files = self._get_xml_files()
        if not xml_files:
            pytest.skip("No real XML files available in attached_assets")

        for xml_path in xml_files:
            out_dir = os.path.join(self.tmpdir, os.path.basename(xml_path).replace(".", "_"))
            converter = InformaticaConverter(data_lib="pandas")
            try:
                output = converter.convert(xml_path, output_dir=out_dir)
            except Exception as e:
                pytest.fail(f"Conversion failed for {xml_path}: {e}")

            for fname in os.listdir(output):
                if fname.endswith(".py"):
                    fpath = os.path.join(output, fname)
                    with open(fpath) as f:
                        code = f.read()
                    try:
                        compile(code, fpath, "exec")
                    except SyntaxError as e:
                        pytest.fail(f"Syntax error in {fpath}: {e}")

    def test_real_xml_polars_generates_valid_python(self):
        xml_files = self._get_xml_files()
        if not xml_files:
            pytest.skip("No real XML files available in attached_assets")

        xml_path = xml_files[0]
        out_dir = os.path.join(self.tmpdir, "polars_test")
        converter = InformaticaConverter(data_lib="polars")
        output = converter.convert(xml_path, output_dir=out_dir)

        for fname in os.listdir(output):
            if fname.endswith(".py"):
                fpath = os.path.join(output, fname)
                with open(fpath) as f:
                    code = f.read()
                try:
                    compile(code, fpath, "exec")
                except SyntaxError as e:
                    pytest.fail(f"Syntax error in polars codegen {fpath}: {e}")


class TestCLIParamFile:

    def test_cli_has_param_file_arg(self):
        from informatica_python.cli import main
        import argparse
        import io
        import contextlib
        f = io.StringIO()
        with contextlib.redirect_stderr(f):
            try:
                sys.argv = ["informatica-python", "--help"]
                main()
            except SystemExit:
                pass
        help_text = f.getvalue()
        from informatica_python.cli import main as cli_main
        assert callable(cli_main)


class TestSQLDialectTranslation:

    def test_nvl_to_coalesce(self):
        from informatica_python.utils.sql_dialect import translate_sql
        result = translate_sql("SELECT NVL(COL1, 0) FROM T", source_dialect="oracle")
        assert "COALESCE" in result
        assert "NVL" not in result

    def test_sysdate_to_current_timestamp(self):
        from informatica_python.utils.sql_dialect import translate_sql
        result = translate_sql("SELECT SYSDATE FROM DUAL", source_dialect="oracle")
        assert "CURRENT_TIMESTAMP" in result
        assert "SYSDATE" not in result

    def test_decode_to_case(self):
        from informatica_python.utils.sql_dialect import translate_sql
        result = translate_sql("SELECT DECODE(STATUS, 'A', 'Active', 'I', 'Inactive', 'Unknown') FROM T", source_dialect="oracle")
        assert "CASE" in result
        assert "WHEN" in result
        assert "ELSE" in result

    def test_nvl2_to_case(self):
        from informatica_python.utils.sql_dialect import translate_sql
        result = translate_sql("SELECT NVL2(COL1, 'has value', 'null') FROM T", source_dialect="oracle")
        assert "CASE WHEN" in result
        assert "IS NOT NULL" in result

    def test_getdate_to_current_timestamp(self):
        from informatica_python.utils.sql_dialect import translate_sql
        result = translate_sql("SELECT GETDATE() FROM T", source_dialect="mssql")
        assert "CURRENT_TIMESTAMP" in result

    def test_isnull_mssql_to_coalesce(self):
        from informatica_python.utils.sql_dialect import translate_sql
        result = translate_sql("SELECT ISNULL(COL1, 0) FROM T", source_dialect="mssql")
        assert "COALESCE" in result

    def test_top_to_limit(self):
        from informatica_python.utils.sql_dialect import translate_sql
        result = translate_sql("SELECT TOP 10 * FROM T", source_dialect="mssql")
        assert "LIMIT 10" in result
        assert "TOP" not in result

    def test_rownum_to_limit(self):
        from informatica_python.utils.sql_dialect import translate_sql
        result = translate_sql("SELECT * FROM T WHERE ROWNUM <= 5", source_dialect="oracle")
        assert "LIMIT 5" in result

    def test_auto_dialect_detection(self):
        from informatica_python.utils.sql_dialect import translate_sql
        result = translate_sql("SELECT NVL(A, 0), SYSDATE FROM T")
        assert "COALESCE" in result
        assert "CURRENT_TIMESTAMP" in result

    def test_decode_with_quoted_commas(self):
        from informatica_python.utils.sql_dialect import translate_sql
        result = translate_sql("SELECT DECODE(col, 'A,B', 1, 0) FROM T", source_dialect="oracle")
        assert "CASE" in result
        assert "'A,B'" in result

    def test_dialect_detects_decode(self):
        from informatica_python.utils.expression_converter import detect_sql_dialect
        assert detect_sql_dialect("SELECT DECODE(X, 1, 'A', 'B') FROM T") == "oracle"

    def test_dialect_detects_outer_join(self):
        from informatica_python.utils.expression_converter import detect_sql_dialect
        assert detect_sql_dialect("SELECT * FROM a, b WHERE a.id = b.id(+)") == "oracle"

    def test_no_change_for_clean_sql(self):
        from informatica_python.utils.sql_dialect import translate_sql
        sql = "SELECT * FROM employees WHERE id = 1"
        result = translate_sql(sql, source_dialect="generic")
        assert result.strip() == sql.strip()

    def test_sql_gen_includes_translation(self):
        from informatica_python.generators.sql_gen import generate_sql_file
        from informatica_python.models import (
            FolderDef, MappingDef, TransformationDef, TableAttribute, FieldDef
        )
        tx = TransformationDef(
            name="SQ_TEST", type="Source Qualifier",
            attributes=[TableAttribute(name="Sql Query", value="SELECT NVL(A, 0), SYSDATE FROM T")],
        )
        mapping = MappingDef(name="m_test", transformations=[tx])
        folder = FolderDef(name="F", mappings=[mapping])
        result = generate_sql_file(folder)
        assert "ANSI SQL Translation" in result
        assert "COALESCE" in result


class TestEnhancedErrorReporting:

    def test_unsupported_transforms_section(self):
        from informatica_python.generators.error_log_gen import generate_error_log
        from informatica_python.models import (
            FolderDef, MappingDef, TransformationDef, FieldDef, TableAttribute
        )
        tx = TransformationDef(
            name="JAVA_TX", type="Java",
            attributes=[TableAttribute(name="Class Name", value="com.example.Transform")],
            fields=[FieldDef(name="OUT1", datatype="string", porttype="OUTPUT")],
        )
        mapping = MappingDef(name="m_test", transformations=[tx])
        folder = FolderDef(name="F", mappings=[mapping])
        result = generate_error_log(folder)
        assert "UNSUPPORTED TRANSFORMS" in result
        assert "JAVA_TX" in result
        assert "Java" in result
        assert "Class Name" in result

    def test_unmapped_ports_section(self):
        from informatica_python.generators.error_log_gen import generate_error_log
        from informatica_python.models import (
            FolderDef, MappingDef, TransformationDef, FieldDef, ConnectorDef
        )
        tx = TransformationDef(
            name="EXP1", type="Expression",
            fields=[
                FieldDef(name="IN1", datatype="string", porttype="INPUT"),
                FieldDef(name="OUT1", datatype="string", porttype="OUTPUT"),
                FieldDef(name="OUT2", datatype="string", porttype="OUTPUT"),
            ],
        )
        conn = ConnectorDef(
            from_instance="EXP1", from_field="OUT1",
            from_instance_type="Expression",
            to_instance="TGT", to_field="COL1",
            to_instance_type="Target Definition",
        )
        mapping = MappingDef(name="m_test", transformations=[tx], connectors=[conn])
        folder = FolderDef(name="F", mappings=[mapping])
        result = generate_error_log(folder)
        assert "UNMAPPED PORTS" in result
        assert "OUT2" in result

    def test_unsupported_functions_section(self):
        from informatica_python.generators.error_log_gen import generate_error_log
        from informatica_python.models import (
            FolderDef, MappingDef, TransformationDef, FieldDef
        )
        tx = TransformationDef(
            name="EXP1", type="Expression",
            fields=[
                FieldDef(name="OUT1", datatype="string", porttype="OUTPUT",
                         expression="CUSTOM_FUNC(IN1, 'abc')"),
            ],
        )
        mapping = MappingDef(name="m_test", transformations=[tx])
        folder = FolderDef(name="F", mappings=[mapping])
        result = generate_error_log(folder)
        assert "UNSUPPORTED EXPRESSION FUNCTIONS" in result
        assert "CUSTOM_FUNC" in result


class TestNestedMapplets:

    def test_recursive_expansion(self):
        from informatica_python.generators.mapping_gen import _expand_mapplet_recursive
        from informatica_python.models import (
            MappletDef, TransformationDef, FieldDef, ConnectorDef, InstanceDef
        )
        inner_mapplet = MappletDef(
            name="INNER_MPL",
            transformations=[
                TransformationDef(name="INNER_EXP", type="Expression",
                                  fields=[FieldDef(name="F1", datatype="string", porttype="INPUT/OUTPUT")]),
            ],
            connectors=[],
        )
        outer_mapplet = MappletDef(
            name="OUTER_MPL",
            transformations=[
                TransformationDef(name="OUTER_EXP", type="Expression",
                                  fields=[FieldDef(name="F1", datatype="string", porttype="INPUT/OUTPUT")]),
            ],
            connectors=[],
            instances=[
                InstanceDef(name="INNER_INST", type="Mapplet",
                            transformation_name="INNER_MPL", transformation_type="Mapplet"),
            ],
        )
        mapplet_map = {"INNER_MPL": inner_mapplet, "OUTER_MPL": outer_mapplet}
        transforms, connectors = _expand_mapplet_recursive(outer_mapplet, mapplet_map, "MPL1")
        names = [t.name for t in transforms]
        assert "MPL1__OUTER_EXP" in names
        assert "MPL1__INNER_INST__INNER_EXP" in names

    def test_circular_reference_protection(self):
        from informatica_python.generators.mapping_gen import _expand_mapplet_recursive
        from informatica_python.models import (
            MappletDef, TransformationDef, FieldDef, InstanceDef
        )
        circular = MappletDef(
            name="SELF_REF",
            transformations=[
                TransformationDef(name="EXP1", type="Expression",
                                  fields=[FieldDef(name="F1", datatype="string")]),
            ],
            connectors=[],
            instances=[
                InstanceDef(name="SELF", type="Mapplet",
                            transformation_name="SELF_REF", transformation_type="Mapplet"),
            ],
        )
        mapplet_map = {"SELF_REF": circular}
        transforms, _ = _expand_mapplet_recursive(circular, mapplet_map, "M")
        assert len(transforms) == 1

    def test_depth_limit(self):
        from informatica_python.generators.mapping_gen import _expand_mapplet_recursive
        from informatica_python.models import (
            MappletDef, TransformationDef, FieldDef, InstanceDef
        )
        mapplets = {}
        for i in range(15):
            name = f"MPL_{i}"
            instances = []
            if i < 14:
                instances = [InstanceDef(name=f"NEST_{i+1}", type="Mapplet",
                                         transformation_name=f"MPL_{i+1}",
                                         transformation_type="Mapplet")]
            mapplets[name] = MappletDef(
                name=name,
                transformations=[
                    TransformationDef(name=f"TX_{i}", type="Expression",
                                      fields=[FieldDef(name="F", datatype="string")]),
                ],
                connectors=[],
                instances=instances,
            )
        transforms, _ = _expand_mapplet_recursive(mapplets["MPL_0"], mapplets, "ROOT")
        assert len(transforms) <= 11


class TestDataQualityValidation:

    def test_validate_casts_generates_warnings(self):
        from informatica_python.generators.mapping_gen import _emit_type_casting, _safe_name
        from informatica_python.models import FieldDef
        class FakeTgt:
            fields = [
                FieldDef(name="AGE", datatype="integer", nullable="NULL"),
                FieldDef(name="CREATED", datatype="date/time", nullable="NULL"),
            ]
        lines = []
        _emit_type_casting(lines, "TGT1", FakeTgt(), validate_casts=True)
        code = "\n".join(lines)
        assert "_cast_warnings" in code
        assert "_pre_null_" in code
        assert "_post_null_" in code
        assert "coerced to null" in code
        assert "logger.warning" in code

    def test_no_validation_by_default(self):
        from informatica_python.generators.mapping_gen import _emit_type_casting
        from informatica_python.models import FieldDef
        class FakeTgt:
            fields = [
                FieldDef(name="AGE", datatype="integer", nullable="NULL"),
            ]
        lines = []
        _emit_type_casting(lines, "TGT1", FakeTgt())
        code = "\n".join(lines)
        assert "_cast_warnings" not in code
        assert "_pre_null_" not in code

    def test_validate_casts_cli_flag(self):
        import io, contextlib
        from informatica_python.cli import main
        f = io.StringIO()
        with contextlib.redirect_stdout(f):
            try:
                sys.argv = ["informatica-python", "--help"]
                main()
            except SystemExit:
                pass
        help_text = f.getvalue()
        assert "--validate-casts" in help_text or "validate_casts" in help_text


class TestWindowAnalyticFunctions:
    def test_moving_avg_df_generated(self):
        from informatica_python.models import FolderDef
        from informatica_python.generators.helper_gen import generate_helper_functions
        folder = FolderDef(name="TestFolder")
        code = generate_helper_functions(folder)
        assert "def moving_avg_df(df, col, window=3):" in code
        assert ".rolling(window=window, min_periods=1).mean()" in code

    def test_moving_sum_df_generated(self):
        from informatica_python.models import FolderDef
        from informatica_python.generators.helper_gen import generate_helper_functions
        folder = FolderDef(name="TestFolder")
        code = generate_helper_functions(folder)
        assert "def moving_sum_df(df, col, window=3):" in code
        assert ".rolling(window=window, min_periods=1).sum()" in code

    def test_cume_df_generated(self):
        from informatica_python.models import FolderDef
        from informatica_python.generators.helper_gen import generate_helper_functions
        folder = FolderDef(name="TestFolder")
        code = generate_helper_functions(folder)
        assert "def cume_df(df, col):" in code
        assert ".expanding(min_periods=1).sum()" in code

    def test_percentile_df_generated(self):
        from informatica_python.models import FolderDef
        from informatica_python.generators.helper_gen import generate_helper_functions
        folder = FolderDef(name="TestFolder")
        code = generate_helper_functions(folder)
        assert "def percentile_df(df, col, pct=0.5):" in code
        assert ".quantile(pct)" in code

    def test_row_level_fallbacks_still_exist(self):
        from informatica_python.models import FolderDef
        from informatica_python.generators.helper_gen import generate_helper_functions
        folder = FolderDef(name="TestFolder")
        code = generate_helper_functions(folder)
        assert "def moving_avg(value, window=3):" in code
        assert "def moving_sum(value, window=3):" in code
        assert "def cume(value):" in code
        assert "def percentile_val(value, pct):" in code

    def test_window_functions_execute(self):
        import pandas as pd
        df = pd.DataFrame({"val": [10, 20, 30, 40, 50]})
        rolling_mean = df["val"].rolling(window=3, min_periods=1).mean()
        assert rolling_mean.iloc[0] == 10.0
        assert rolling_mean.iloc[2] == 20.0
        rolling_sum = df["val"].rolling(window=3, min_periods=1).sum()
        assert rolling_sum.iloc[2] == 60.0
        cume_sum = df["val"].expanding(min_periods=1).sum()
        assert cume_sum.iloc[4] == 150.0


class TestUpdateStrategy:
    def test_static_insert_strategy(self):
        from informatica_python.models import TransformationDef, TableAttribute
        from informatica_python.generators.mapping_gen import _gen_update_strategy
        tx = TransformationDef(name="UPD_INSERT", type="Update Strategy",
                               attributes=[TableAttribute(name="Update Strategy Expression", value="0")])
        lines = []
        source_dfs = {}
        _gen_update_strategy(lines, tx, "upd_insert", "df_input", source_dfs)
        code = "\n".join(lines)
        assert "'_update_strategy'] = 'INSERT'" in code
        assert "upd_insert" in source_dfs.get("UPD_INSERT", "")

    def test_static_update_strategy(self):
        from informatica_python.models import TransformationDef, TableAttribute
        from informatica_python.generators.mapping_gen import _gen_update_strategy
        tx = TransformationDef(name="UPD_UPDATE", type="Update Strategy",
                               attributes=[TableAttribute(name="Update Strategy Expression", value="1")])
        lines = []
        source_dfs = {}
        _gen_update_strategy(lines, tx, "upd_update", "df_input", source_dfs)
        code = "\n".join(lines)
        assert "'_update_strategy'] = 'UPDATE'" in code

    def test_static_delete_strategy(self):
        from informatica_python.models import TransformationDef, TableAttribute
        from informatica_python.generators.mapping_gen import _gen_update_strategy
        tx = TransformationDef(name="UPD_DEL", type="Update Strategy",
                               attributes=[TableAttribute(name="Update Strategy Expression", value="2")])
        lines = []
        source_dfs = {}
        _gen_update_strategy(lines, tx, "upd_del", "df_input", source_dfs)
        code = "\n".join(lines)
        assert "'_update_strategy'] = 'DELETE'" in code

    def test_dd_constant_expression(self):
        from informatica_python.models import TransformationDef, TableAttribute
        from informatica_python.generators.mapping_gen import _gen_update_strategy
        tx = TransformationDef(name="UPD_EXPR", type="Update Strategy",
                               attributes=[TableAttribute(name="Update Strategy Expression", value="DD_UPDATE")])
        lines = []
        source_dfs = {}
        _gen_update_strategy(lines, tx, "upd_expr", "df_input", source_dfs)
        code = "\n".join(lines)
        assert "_update_strategy" in code
        assert "UPD_EXPR" in source_dfs

    def test_target_write_routes_strategy(self):
        from informatica_python.models import TargetDef, FieldDef
        from informatica_python.generators.mapping_gen import _generate_target_write
        tgt = TargetDef(name="TGT_DB", database_type="Oracle",
                        fields=[FieldDef(name="ID", datatype="integer", keytype="PRIMARY KEY"),
                                FieldDef(name="VAL", datatype="string")])
        lines = []
        source_dfs = {"SRC": "df_src"}
        connector_graph = {"to": {"TGT_DB": []}, "from": {}}
        _generate_target_write(lines, "TGT_DB", tgt, connector_graph, source_dfs, {}, {})
        code = "\n".join(lines)
        assert "write_with_update_strategy" in code
        assert "write_to_db" in code
        assert "_update_strategy" in code

    def test_update_strategy_preserved_through_projection(self):
        from informatica_python.models import TargetDef, FieldDef
        from informatica_python.generators.mapping_gen import _generate_target_write
        tgt = TargetDef(name="TGT_DB", database_type="Oracle",
                        fields=[FieldDef(name="ID", datatype="integer"),
                                FieldDef(name="VAL", datatype="string")])
        lines = []
        source_dfs = {"SRC": "df_src"}
        from informatica_python.models import ConnectorDef
        conns = [ConnectorDef(from_instance="SRC", to_instance="TGT_DB",
                              from_instance_type="", to_instance_type="",
                              from_field="ID", to_field="ID")]
        connector_graph = {"to": {"TGT_DB": conns}, "from": {"SRC": conns}}
        _generate_target_write(lines, "TGT_DB", tgt, connector_graph, source_dfs, {}, {})
        code = "\n".join(lines)
        assert "_update_strategy" in code
        assert "available_cols.append('_update_strategy')" in code

    def test_update_strategy_dialect_aware_placeholders(self):
        from informatica_python.models import FolderDef
        from informatica_python.generators.helper_gen import generate_helper_functions
        folder = FolderDef(name="TestFolder")
        code = generate_helper_functions(folder)
        assert "ph = '?' if db_type == 'mssql' else '%s'" in code

    def test_update_strategy_helper_generated(self):
        from informatica_python.models import FolderDef
        from informatica_python.generators.helper_gen import generate_helper_functions
        folder = FolderDef(name="TestFolder")
        code = generate_helper_functions(folder)
        assert "def write_with_update_strategy(" in code
        assert "df_insert" in code
        assert "df_update" in code
        assert "df_delete" in code
        assert "df_reject" in code
        assert "INSERT" in code
        assert "UPDATE" in code
        assert "DELETE" in code


class TestStoredProcedure:
    def test_stored_proc_basic(self):
        from informatica_python.models import TransformationDef, TableAttribute
        from informatica_python.generators.mapping_gen import _gen_stored_proc
        tx = TransformationDef(name="SP_GET_DATA", type="Stored Procedure",
                               attributes=[TableAttribute(name="Stored Procedure Name", value="usp_get_data")])
        lines = []
        source_dfs = {}
        _gen_stored_proc(lines, tx, "sp_get_data", "df_input", source_dfs)
        code = "\n".join(lines)
        assert "call_stored_procedure" in code
        assert "usp_get_data" in code
        assert "SP_GET_DATA" in source_dfs

    def test_stored_proc_with_input_params(self):
        from informatica_python.models import TransformationDef, TableAttribute, FieldDef
        from informatica_python.generators.mapping_gen import _gen_stored_proc
        tx = TransformationDef(name="SP_LOOKUP", type="Stored Procedure",
                               attributes=[TableAttribute(name="Stored Procedure Name", value="usp_lookup")],
                               fields=[FieldDef(name="CUSTOMER_ID", datatype="integer", porttype="INPUT"),
                                       FieldDef(name="RESULT", datatype="string", porttype="OUTPUT")])
        lines = []
        source_dfs = {}
        _gen_stored_proc(lines, tx, "sp_lookup", "df_input", source_dfs)
        code = "\n".join(lines)
        assert "CUSTOMER_ID" in code
        assert "RESULT" in code
        assert "_sp_out_names_" in code
        assert "call_stored_procedure" in code

    def test_stored_proc_with_output_params(self):
        from informatica_python.models import TransformationDef, TableAttribute, FieldDef
        from informatica_python.generators.mapping_gen import _gen_stored_proc
        tx = TransformationDef(name="SP_OUT", type="Stored Procedure",
                               attributes=[TableAttribute(name="Stored Procedure Name", value="usp_out")],
                               fields=[FieldDef(name="RET_VAL", datatype="string", porttype="OUTPUT")])
        lines = []
        source_dfs = {}
        _gen_stored_proc(lines, tx, "sp_out", "df_input", source_dfs)
        code = "\n".join(lines)
        assert "['RET_VAL']" in code
        assert "_sp_out_vals_" in code
        assert "if df_sp_out.empty" in code

    def test_stored_proc_helper_generated(self):
        from informatica_python.models import FolderDef
        from informatica_python.generators.helper_gen import generate_helper_functions
        folder = FolderDef(name="TestFolder")
        code = generate_helper_functions(folder)
        assert "def call_stored_procedure(" in code
        assert "cursor.callproc" in code
        assert "EXEC" in code
        assert "CALL" in code

    def test_stored_proc_connection_override(self):
        from informatica_python.models import TransformationDef, TableAttribute
        from informatica_python.generators.mapping_gen import _gen_stored_proc
        tx = TransformationDef(name="SP_CONN", type="Stored Procedure",
                               attributes=[
                                   TableAttribute(name="Stored Procedure Name", value="usp_custom"),
                                   TableAttribute(name="Connection Name", value="oracle_prod"),
                               ])
        lines = []
        source_dfs = {}
        _gen_stored_proc(lines, tx, "sp_conn", "df_input", source_dfs)
        code = "\n".join(lines)
        assert "oracle_prod" in code


class TestStatePersistence:
    def test_persistent_state_helpers_generated(self):
        from informatica_python.models import FolderDef
        from informatica_python.generators.helper_gen import generate_helper_functions
        folder = FolderDef(name="TestFolder")
        code = generate_helper_functions(folder)
        assert "def load_persistent_state(" in code
        assert "def save_persistent_state(" in code
        assert "def get_persistent_variable(" in code
        assert "def set_persistent_variable(" in code
        assert "_persistent_state" in code
        assert "persistent_state.json" in code

    def test_workflow_loads_persistent_state(self):
        from informatica_python.models import FolderDef, WorkflowDef, WorkflowVariable
        from informatica_python.generators.workflow_gen import generate_workflow_code
        wf = WorkflowDef(name="wf_test",
                         variables=[WorkflowVariable(name="$$RUN_COUNT", datatype="integer",
                                                     default_value="0", is_persistent="YES")])
        folder = FolderDef(name="TestFolder", workflows=[wf])
        code = generate_workflow_code(folder)
        assert "load_persistent_state()" in code
        assert "get_persistent_variable" in code
        assert "save_persistent_state()" in code
        assert "set_persistent_variable" in code

    def test_workflow_no_persist_when_not_needed(self):
        from informatica_python.models import FolderDef, WorkflowDef, WorkflowVariable
        from informatica_python.generators.workflow_gen import generate_workflow_code
        wf = WorkflowDef(name="wf_test",
                         variables=[WorkflowVariable(name="$$TEMP_VAR", datatype="string",
                                                     default_value="''", is_persistent="NO")])
        folder = FolderDef(name="TestFolder", workflows=[wf])
        code = generate_workflow_code(folder)
        assert "load_persistent_state()" not in code
        assert "save_persistent_state()" not in code

    def test_mapping_persistent_variables(self):
        from informatica_python.models import (
            FolderDef, MappingDef, MappingVariable, SourceDef, FieldDef,
            TransformationDef, ConnectorDef, InstanceDef
        )
        from informatica_python.generators.mapping_gen import generate_mapping_code
        mapping = MappingDef(
            name="m_persist_test",
            variables=[
                MappingVariable(name="$$LAST_ID", datatype="integer",
                                default_value="0", is_persistent="YES"),
                MappingVariable(name="$$TEMP", datatype="string",
                                default_value="''", is_persistent="NO"),
            ],
            sources=[],
            targets=[],
            transformations=[],
            connectors=[],
            instances=[],
        )
        folder = FolderDef(name="TestFolder", mappings=[mapping])
        code = generate_mapping_code(mapping, folder, "pandas", 1)
        assert "get_persistent_variable('m_persist_test', 'last_id'" in code
        assert "temp = ''" in code
        assert "load_persistent_state()" in code
        assert "set_persistent_variable('m_persist_test', 'last_id'" in code
        assert "save_persistent_state()" in code

    def test_workflow_persistent_imports(self):
        from informatica_python.models import FolderDef, WorkflowDef, WorkflowVariable
        from informatica_python.generators.workflow_gen import generate_workflow_code
        wf = WorkflowDef(name="wf_test",
                         variables=[WorkflowVariable(name="$$COUNT", is_persistent="YES")])
        folder = FolderDef(name="TestFolder", workflows=[wf])
        code = generate_workflow_code(folder)
        assert "load_persistent_state" in code
        assert "save_persistent_state" in code

    def test_state_file_json_format(self):
        from informatica_python.models import FolderDef
        from informatica_python.generators.helper_gen import generate_helper_functions
        folder = FolderDef(name="TestFolder")
        code = generate_helper_functions(folder)
        assert "json.load" in code
        assert "json.dump" in code
        assert "persistent_state.json" in code


class TestLoggingEnrichment:

    def test_mapping_imports_logging(self):
        from informatica_python.models import (
            MappingDef, FolderDef, TransformationDef, ConnectorDef,
            FieldDef, SourceDef, TargetDef, InstanceDef,
        )
        from informatica_python.generators.mapping_gen import generate_mapping_code
        mapping = MappingDef(
            name="m_log_test",
            sources=[SourceDef(name="SRC1", database_type="Flat File")],
            targets=[TargetDef(name="TGT1", database_type="Flat File", fields=[FieldDef(name="ID", datatype="integer")])],
            transformations=[
                TransformationDef(name="SQ_SRC1", type="Source Qualifier",
                                  fields=[FieldDef(name="ID", datatype="integer", porttype="INPUT/OUTPUT")]),
                TransformationDef(name="EXP_TEST", type="Expression",
                                  fields=[FieldDef(name="ID", datatype="integer", porttype="INPUT/OUTPUT")]),
            ],
            connectors=[
                ConnectorDef(from_instance="SRC1", to_instance="SQ_SRC1", from_field="ID", to_field="ID", from_instance_type="", to_instance_type=""),
                ConnectorDef(from_instance="SQ_SRC1", to_instance="EXP_TEST", from_field="ID", to_field="ID", from_instance_type="", to_instance_type=""),
                ConnectorDef(from_instance="EXP_TEST", to_instance="TGT1", from_field="ID", to_field="ID", from_instance_type="", to_instance_type=""),
            ],
            instances=[
                InstanceDef(name="SRC1", type="Source Definition", transformation_name="SRC1"),
                InstanceDef(name="TGT1", type="Target Definition", transformation_name="TGT1"),
                InstanceDef(name="SQ_SRC1", type="Source Qualifier", transformation_name="SQ_SRC1"),
                InstanceDef(name="EXP_TEST", type="Expression", transformation_name="EXP_TEST"),
            ],
        )
        folder = FolderDef(name="TestFolder", mappings=[mapping])
        code = generate_mapping_code(mapping, folder, "pandas", 1)
        assert "import logging" in code
        assert "logger = logging.getLogger(__name__)" in code

    def test_source_row_count_logging(self):
        from informatica_python.models import (
            MappingDef, FolderDef, TransformationDef, ConnectorDef,
            FieldDef, SourceDef, TargetDef, InstanceDef,
        )
        from informatica_python.generators.mapping_gen import generate_mapping_code
        mapping = MappingDef(
            name="m_log_src",
            sources=[SourceDef(name="SRC1", database_type="Flat File")],
            targets=[TargetDef(name="TGT1", database_type="Flat File", fields=[FieldDef(name="ID", datatype="integer")])],
            transformations=[
                TransformationDef(name="SQ_SRC1", type="Source Qualifier",
                                  fields=[FieldDef(name="ID", datatype="integer", porttype="INPUT/OUTPUT")]),
            ],
            connectors=[
                ConnectorDef(from_instance="SRC1", to_instance="SQ_SRC1", from_field="ID", to_field="ID", from_instance_type="", to_instance_type=""),
                ConnectorDef(from_instance="SQ_SRC1", to_instance="TGT1", from_field="ID", to_field="ID", from_instance_type="", to_instance_type=""),
            ],
            instances=[
                InstanceDef(name="SRC1", type="Source Definition", transformation_name="SRC1"),
                InstanceDef(name="TGT1", type="Target Definition", transformation_name="TGT1"),
                InstanceDef(name="SQ_SRC1", type="Source Qualifier", transformation_name="SQ_SRC1"),
            ],
        )
        folder = FolderDef(name="TestFolder", mappings=[mapping])
        code = generate_mapping_code(mapping, folder, "pandas", 1)
        assert "logger.info(f'Source SQ_SRC1:" in code
        assert "rows read" in code

    def test_transform_row_count_logging(self):
        from informatica_python.models import (
            MappingDef, FolderDef, TransformationDef, ConnectorDef,
            FieldDef, SourceDef, TargetDef, InstanceDef,
        )
        from informatica_python.generators.mapping_gen import generate_mapping_code
        mapping = MappingDef(
            name="m_log_tx",
            sources=[SourceDef(name="SRC1", database_type="Flat File")],
            targets=[TargetDef(name="TGT1", database_type="Flat File", fields=[FieldDef(name="ID", datatype="integer")])],
            transformations=[
                TransformationDef(name="SQ_SRC1", type="Source Qualifier",
                                  fields=[FieldDef(name="ID", datatype="integer", porttype="INPUT/OUTPUT")]),
                TransformationDef(name="FIL_ACTIVE", type="Filter",
                                  fields=[FieldDef(name="ID", datatype="integer", porttype="INPUT/OUTPUT")],
                                  attributes=[]),
            ],
            connectors=[
                ConnectorDef(from_instance="SRC1", to_instance="SQ_SRC1", from_field="ID", to_field="ID", from_instance_type="", to_instance_type=""),
                ConnectorDef(from_instance="SQ_SRC1", to_instance="FIL_ACTIVE", from_field="ID", to_field="ID", from_instance_type="", to_instance_type=""),
                ConnectorDef(from_instance="FIL_ACTIVE", to_instance="TGT1", from_field="ID", to_field="ID", from_instance_type="", to_instance_type=""),
            ],
            instances=[
                InstanceDef(name="SRC1", type="Source Definition", transformation_name="SRC1"),
                InstanceDef(name="TGT1", type="Target Definition", transformation_name="TGT1"),
                InstanceDef(name="SQ_SRC1", type="Source Qualifier", transformation_name="SQ_SRC1"),
                InstanceDef(name="FIL_ACTIVE", type="Filter", transformation_name="FIL_ACTIVE"),
            ],
        )
        folder = FolderDef(name="TestFolder", mappings=[mapping])
        code = generate_mapping_code(mapping, folder, "pandas", 1)
        assert "_input_rows_fil_active = len(" in code
        assert "_output_rows_fil_active = len(df_fil_active" in code
        assert "FIL_ACTIVE (Filter):" in code
        assert "input rows ->" in code
        assert "output rows" in code

    def test_target_row_count_logging(self):
        from informatica_python.models import (
            MappingDef, FolderDef, TransformationDef, ConnectorDef,
            FieldDef, SourceDef, TargetDef, InstanceDef,
        )
        from informatica_python.generators.mapping_gen import generate_mapping_code
        mapping = MappingDef(
            name="m_log_tgt",
            sources=[SourceDef(name="SRC1", database_type="Flat File")],
            targets=[TargetDef(name="TGT1", database_type="Flat File", fields=[FieldDef(name="ID", datatype="integer")])],
            transformations=[
                TransformationDef(name="SQ_SRC1", type="Source Qualifier",
                                  fields=[FieldDef(name="ID", datatype="integer", porttype="INPUT/OUTPUT")]),
            ],
            connectors=[
                ConnectorDef(from_instance="SRC1", to_instance="SQ_SRC1", from_field="ID", to_field="ID", from_instance_type="", to_instance_type=""),
                ConnectorDef(from_instance="SQ_SRC1", to_instance="TGT1", from_field="ID", to_field="ID", from_instance_type="", to_instance_type=""),
            ],
            instances=[
                InstanceDef(name="SRC1", type="Source Definition", transformation_name="SRC1"),
                InstanceDef(name="TGT1", type="Target Definition", transformation_name="TGT1"),
                InstanceDef(name="SQ_SRC1", type="Source Qualifier", transformation_name="SQ_SRC1"),
            ],
        )
        folder = FolderDef(name="TestFolder", mappings=[mapping])
        code = generate_mapping_code(mapping, folder, "pandas", 1)
        assert "logger.info(f'Target TGT1:" in code
        assert "rows written" in code

    def test_input_output_rows_multiple_transforms(self):
        from informatica_python.models import (
            MappingDef, FolderDef, TransformationDef, ConnectorDef,
            FieldDef, SourceDef, TargetDef, InstanceDef,
        )
        from informatica_python.generators.mapping_gen import generate_mapping_code
        mapping = MappingDef(
            name="m_log_multi",
            sources=[SourceDef(name="SRC1", database_type="Flat File")],
            targets=[TargetDef(name="TGT1", database_type="Flat File", fields=[FieldDef(name="VAL", datatype="integer")])],
            transformations=[
                TransformationDef(name="SQ_SRC1", type="Source Qualifier",
                                  fields=[FieldDef(name="VAL", datatype="integer", porttype="INPUT/OUTPUT")]),
                TransformationDef(name="EXP1", type="Expression",
                                  fields=[FieldDef(name="VAL", datatype="integer", porttype="INPUT/OUTPUT")]),
                TransformationDef(name="SRT1", type="Sorter",
                                  fields=[FieldDef(name="VAL", datatype="integer", porttype="INPUT/OUTPUT")]),
            ],
            connectors=[
                ConnectorDef(from_instance="SRC1", to_instance="SQ_SRC1", from_field="ID", to_field="ID", from_instance_type="", to_instance_type=""),
                ConnectorDef(from_instance="SQ_SRC1", to_instance="EXP1", from_field="VAL", to_field="VAL", from_instance_type="", to_instance_type=""),
                ConnectorDef(from_instance="EXP1", to_instance="SRT1", from_field="VAL", to_field="VAL", from_instance_type="", to_instance_type=""),
                ConnectorDef(from_instance="SRT1", to_instance="TGT1", from_field="VAL", to_field="VAL", from_instance_type="", to_instance_type=""),
            ],
            instances=[
                InstanceDef(name="SRC1", type="Source Definition", transformation_name="SRC1"),
                InstanceDef(name="TGT1", type="Target Definition", transformation_name="TGT1"),
                InstanceDef(name="SQ_SRC1", type="Source Qualifier", transformation_name="SQ_SRC1"),
                InstanceDef(name="EXP1", type="Expression", transformation_name="EXP1"),
                InstanceDef(name="SRT1", type="Sorter", transformation_name="SRT1"),
            ],
        )
        folder = FolderDef(name="TestFolder", mappings=[mapping])
        code = generate_mapping_code(mapping, folder, "pandas", 1)
        assert "_input_rows_exp1" in code
        assert "_output_rows_exp1" in code
        assert "_input_rows_srt1" in code
        assert "_output_rows_srt1" in code
        assert code.count("logger.info") >= 4


class TestGeneratedCodeDocumentation:

    def test_mapping_docstring_sources_targets(self):
        from informatica_python.models import (
            MappingDef, FolderDef, TransformationDef, ConnectorDef,
            FieldDef, SourceDef, TargetDef, InstanceDef,
        )
        from informatica_python.generators.mapping_gen import generate_mapping_code
        mapping = MappingDef(
            name="m_doc_test",
            description="Load customer data from staging to warehouse",
            sources=[SourceDef(name="SRC_CUST", database_type="Flat File")],
            targets=[TargetDef(name="TGT_CUST", database_type="Flat File", fields=[FieldDef(name="ID", datatype="integer")])],
            transformations=[
                TransformationDef(name="SQ_SRC_CUST", type="Source Qualifier",
                                  fields=[FieldDef(name="ID", datatype="integer", porttype="INPUT/OUTPUT")]),
            ],
            connectors=[
                ConnectorDef(from_instance="SRC_CUST", to_instance="SQ_SRC_CUST", from_field="ID", to_field="ID", from_instance_type="", to_instance_type=""),
                ConnectorDef(from_instance="SQ_SRC_CUST", to_instance="TGT_CUST", from_field="ID", to_field="ID", from_instance_type="", to_instance_type=""),
            ],
            instances=[
                InstanceDef(name="SRC_CUST", type="Source Definition", transformation_name="SRC_CUST"),
                InstanceDef(name="TGT_CUST", type="Target Definition", transformation_name="TGT_CUST"),
                InstanceDef(name="SQ_SRC_CUST", type="Source Qualifier", transformation_name="SQ_SRC_CUST"),
            ],
        )
        folder = FolderDef(name="TestFolder", mappings=[mapping])
        code = generate_mapping_code(mapping, folder, "pandas", 1)
        assert "Execute mapping: m_doc_test" in code
        assert "Load customer data from staging to warehouse" in code
        assert "Sources: SRC_CUST" in code
        assert "Targets: TGT_CUST" in code

    def test_mapping_docstring_transform_pipeline(self):
        from informatica_python.models import (
            MappingDef, FolderDef, TransformationDef, ConnectorDef,
            FieldDef, SourceDef, TargetDef, InstanceDef,
        )
        from informatica_python.generators.mapping_gen import generate_mapping_code
        mapping = MappingDef(
            name="m_doc_pipeline",
            sources=[SourceDef(name="SRC1", database_type="Flat File")],
            targets=[TargetDef(name="TGT1", database_type="Flat File", fields=[FieldDef(name="ID", datatype="integer")])],
            transformations=[
                TransformationDef(name="SQ_SRC1", type="Source Qualifier",
                                  fields=[FieldDef(name="ID", datatype="integer", porttype="INPUT/OUTPUT")]),
                TransformationDef(name="EXP_CALC", type="Expression",
                                  fields=[
                                      FieldDef(name="ID", datatype="integer", porttype="INPUT/OUTPUT"),
                                      FieldDef(name="TOTAL", datatype="decimal", porttype="OUTPUT"),
                                  ]),
                TransformationDef(name="FIL_VALID", type="Filter",
                                  fields=[
                                      FieldDef(name="ID", datatype="integer", porttype="INPUT"),
                                      FieldDef(name="TOTAL", datatype="decimal", porttype="INPUT/OUTPUT"),
                                  ],
                                  attributes=[]),
            ],
            connectors=[
                ConnectorDef(from_instance="SRC1", to_instance="SQ_SRC1", from_field="ID", to_field="ID", from_instance_type="", to_instance_type=""),
                ConnectorDef(from_instance="SQ_SRC1", to_instance="EXP_CALC", from_field="ID", to_field="ID", from_instance_type="", to_instance_type=""),
                ConnectorDef(from_instance="EXP_CALC", to_instance="FIL_VALID", from_field="TOTAL", to_field="TOTAL", from_instance_type="", to_instance_type=""),
                ConnectorDef(from_instance="FIL_VALID", to_instance="TGT1", from_field="ID", to_field="ID", from_instance_type="", to_instance_type=""),
            ],
            instances=[
                InstanceDef(name="SRC1", type="Source Definition", transformation_name="SRC1"),
                InstanceDef(name="TGT1", type="Target Definition", transformation_name="TGT1"),
                InstanceDef(name="SQ_SRC1", type="Source Qualifier", transformation_name="SQ_SRC1"),
                InstanceDef(name="EXP_CALC", type="Expression", transformation_name="EXP_CALC"),
                InstanceDef(name="FIL_VALID", type="Filter", transformation_name="FIL_VALID"),
            ],
        )
        folder = FolderDef(name="TestFolder", mappings=[mapping])
        code = generate_mapping_code(mapping, folder, "pandas", 1)
        assert "Transformation pipeline:" in code
        assert "EXP_CALC (Expression):" in code
        assert "FIL_VALID (Filter):" in code
        assert "input fields ->" in code
        assert "output fields" in code

    def test_transform_field_documentation(self):
        from informatica_python.models import (
            MappingDef, FolderDef, TransformationDef, ConnectorDef,
            FieldDef, SourceDef, TargetDef, InstanceDef,
        )
        from informatica_python.generators.mapping_gen import generate_mapping_code
        mapping = MappingDef(
            name="m_doc_fields",
            sources=[SourceDef(name="SRC1", database_type="Flat File")],
            targets=[TargetDef(name="TGT1", database_type="Flat File", fields=[FieldDef(name="ID", datatype="integer")])],
            transformations=[
                TransformationDef(name="SQ_SRC1", type="Source Qualifier",
                                  fields=[FieldDef(name="ID", datatype="integer", porttype="INPUT/OUTPUT"),
                                          FieldDef(name="NAME", datatype="string", porttype="INPUT/OUTPUT")]),
                TransformationDef(name="EXP_UPPER", type="Expression",
                                  description="Uppercase the name field",
                                  fields=[
                                      FieldDef(name="ID", datatype="integer", porttype="INPUT"),
                                      FieldDef(name="NAME", datatype="string", porttype="INPUT"),
                                      FieldDef(name="NAME_UPPER", datatype="string", porttype="OUTPUT", expression="UPPER(NAME)"),
                                  ]),
            ],
            connectors=[
                ConnectorDef(from_instance="SRC1", to_instance="SQ_SRC1", from_field="ID", to_field="ID", from_instance_type="", to_instance_type=""),
                ConnectorDef(from_instance="SQ_SRC1", to_instance="EXP_UPPER", from_field="ID", to_field="ID", from_instance_type="", to_instance_type=""),
                ConnectorDef(from_instance="SQ_SRC1", to_instance="EXP_UPPER", from_field="NAME", to_field="NAME", from_instance_type="", to_instance_type=""),
                ConnectorDef(from_instance="EXP_UPPER", to_instance="TGT1", from_field="ID", to_field="ID", from_instance_type="", to_instance_type=""),
            ],
            instances=[
                InstanceDef(name="SRC1", type="Source Definition", transformation_name="SRC1"),
                InstanceDef(name="TGT1", type="Target Definition", transformation_name="TGT1"),
                InstanceDef(name="SQ_SRC1", type="Source Qualifier", transformation_name="SQ_SRC1"),
                InstanceDef(name="EXP_UPPER", type="Expression", transformation_name="EXP_UPPER"),
            ],
        )
        folder = FolderDef(name="TestFolder", mappings=[mapping])
        code = generate_mapping_code(mapping, folder, "pandas", 1)
        assert "# Input fields: ID, NAME" in code
        assert "# Output fields: NAME_UPPER" in code
        assert "# Description: Uppercase the name field" in code

    def test_transform_description_comment(self):
        from informatica_python.models import (
            MappingDef, FolderDef, TransformationDef, ConnectorDef,
            FieldDef, SourceDef, TargetDef, InstanceDef,
        )
        from informatica_python.generators.mapping_gen import generate_mapping_code
        mapping = MappingDef(
            name="m_doc_desc",
            sources=[SourceDef(name="SRC1", database_type="Flat File")],
            targets=[TargetDef(name="TGT1", database_type="Flat File", fields=[FieldDef(name="ID", datatype="integer")])],
            transformations=[
                TransformationDef(name="SQ_SRC1", type="Source Qualifier",
                                  fields=[FieldDef(name="ID", datatype="integer", porttype="INPUT/OUTPUT")]),
                TransformationDef(name="AGG_TOTALS", type="Aggregator",
                                  description="Calculate regional totals",
                                  fields=[
                                      FieldDef(name="REGION", datatype="string", porttype="INPUT/OUTPUT"),
                                      FieldDef(name="TOTAL", datatype="decimal", porttype="OUTPUT", expression="SUM(AMOUNT)"),
                                  ]),
            ],
            connectors=[
                ConnectorDef(from_instance="SRC1", to_instance="SQ_SRC1", from_field="ID", to_field="ID", from_instance_type="", to_instance_type=""),
                ConnectorDef(from_instance="SQ_SRC1", to_instance="AGG_TOTALS", from_field="ID", to_field="REGION", from_instance_type="", to_instance_type=""),
                ConnectorDef(from_instance="AGG_TOTALS", to_instance="TGT1", from_field="REGION", to_field="ID", from_instance_type="", to_instance_type=""),
            ],
            instances=[
                InstanceDef(name="SRC1", type="Source Definition", transformation_name="SRC1"),
                InstanceDef(name="TGT1", type="Target Definition", transformation_name="TGT1"),
                InstanceDef(name="SQ_SRC1", type="Source Qualifier", transformation_name="SQ_SRC1"),
                InstanceDef(name="AGG_TOTALS", type="Aggregator", transformation_name="AGG_TOTALS"),
            ],
        )
        folder = FolderDef(name="TestFolder", mappings=[mapping])
        code = generate_mapping_code(mapping, folder, "pandas", 1)
        assert "# Description: Calculate regional totals" in code
        assert "# ---" in code

    def test_no_description_no_desc_line(self):
        from informatica_python.models import (
            MappingDef, FolderDef, TransformationDef, ConnectorDef,
            FieldDef, SourceDef, TargetDef, InstanceDef,
        )
        from informatica_python.generators.mapping_gen import generate_mapping_code
        mapping = MappingDef(
            name="m_doc_nodesc",
            sources=[SourceDef(name="SRC1", database_type="Flat File")],
            targets=[TargetDef(name="TGT1", database_type="Flat File", fields=[FieldDef(name="ID", datatype="integer")])],
            transformations=[
                TransformationDef(name="SQ_SRC1", type="Source Qualifier",
                                  fields=[FieldDef(name="ID", datatype="integer", porttype="INPUT/OUTPUT")]),
                TransformationDef(name="EXP_PASS", type="Expression",
                                  fields=[FieldDef(name="ID", datatype="integer", porttype="INPUT/OUTPUT")]),
            ],
            connectors=[
                ConnectorDef(from_instance="SRC1", to_instance="SQ_SRC1", from_field="ID", to_field="ID", from_instance_type="", to_instance_type=""),
                ConnectorDef(from_instance="SQ_SRC1", to_instance="EXP_PASS", from_field="ID", to_field="ID", from_instance_type="", to_instance_type=""),
                ConnectorDef(from_instance="EXP_PASS", to_instance="TGT1", from_field="ID", to_field="ID", from_instance_type="", to_instance_type=""),
            ],
            instances=[
                InstanceDef(name="SRC1", type="Source Definition", transformation_name="SRC1"),
                InstanceDef(name="TGT1", type="Target Definition", transformation_name="TGT1"),
                InstanceDef(name="SQ_SRC1", type="Source Qualifier", transformation_name="SQ_SRC1"),
                InstanceDef(name="EXP_PASS", type="Expression", transformation_name="EXP_PASS"),
            ],
        )
        folder = FolderDef(name="TestFolder", mappings=[mapping])
        code = generate_mapping_code(mapping, folder, "pandas", 1)
        lines = code.split('\n')
        desc_lines = [l for l in lines if '# Description:' in l]
        for dl in desc_lines:
            assert dl.strip() != "# Description:"

    def test_field_list_truncation(self):
        from informatica_python.models import (
            MappingDef, FolderDef, TransformationDef, ConnectorDef,
            FieldDef, SourceDef, TargetDef, InstanceDef,
        )
        from informatica_python.generators.mapping_gen import generate_mapping_code
        many_fields = [FieldDef(name=f"F{i}", datatype="string", porttype="INPUT/OUTPUT") for i in range(15)]
        mapping = MappingDef(
            name="m_doc_many",
            sources=[SourceDef(name="SRC1", database_type="Flat File")],
            targets=[TargetDef(name="TGT1", database_type="Flat File", fields=[FieldDef(name="ID", datatype="integer")])],
            transformations=[
                TransformationDef(name="SQ_SRC1", type="Source Qualifier",
                                  fields=[FieldDef(name="ID", datatype="integer", porttype="INPUT/OUTPUT")]),
                TransformationDef(name="EXP_MANY", type="Expression", fields=many_fields),
            ],
            connectors=[
                ConnectorDef(from_instance="SRC1", to_instance="SQ_SRC1", from_field="ID", to_field="ID", from_instance_type="", to_instance_type=""),
                ConnectorDef(from_instance="SQ_SRC1", to_instance="EXP_MANY", from_field="ID", to_field="F0", from_instance_type="", to_instance_type=""),
                ConnectorDef(from_instance="EXP_MANY", to_instance="TGT1", from_field="F0", to_field="ID", from_instance_type="", to_instance_type=""),
            ],
            instances=[
                InstanceDef(name="SRC1", type="Source Definition", transformation_name="SRC1"),
                InstanceDef(name="TGT1", type="Target Definition", transformation_name="TGT1"),
                InstanceDef(name="SQ_SRC1", type="Source Qualifier", transformation_name="SQ_SRC1"),
                InstanceDef(name="EXP_MANY", type="Expression", transformation_name="EXP_MANY"),
            ],
        )
        folder = FolderDef(name="TestFolder", mappings=[mapping])
        code = generate_mapping_code(mapping, folder, "pandas", 1)
        assert "..." in code


class TestSourceQualifierNoSources(unittest.TestCase):

    def test_sq_with_no_connected_sources_and_empty_source_map(self):
        from informatica_python.models import (
            FolderDef, MappingDef, TransformationDef,
            InstanceDef, ConnectorDef, FieldDef, TableAttribute,
        )
        from informatica_python.generators.mapping_gen import generate_mapping_code
        mapping = MappingDef(
            name="m_orphan_sq",
            transformations=[
                TransformationDef(name="SQ_ORPHAN", type="Source Qualifier", fields=[], attributes=[]),
            ],
            connectors=[],
            instances=[
                InstanceDef(name="SQ_ORPHAN", type="Source Qualifier", transformation_name="SQ_ORPHAN"),
                InstanceDef(name="TGT1", type="Target Definition", transformation_name="TGT1"),
            ],
        )
        folder = FolderDef(name="TestFolder", sources=[], targets=[], mappings=[mapping])
        code = generate_mapping_code(mapping, folder, "pandas", 1)
        assert "df_sq_orphan" in code
        assert "read_file" in code or "read_from_db" in code

    def test_sq_with_no_connectors_but_sources_exist(self):
        from informatica_python.models import (
            FolderDef, MappingDef, TransformationDef,
            InstanceDef, ConnectorDef, FieldDef, TableAttribute,
        )
        from informatica_python.generators.mapping_gen import generate_mapping_code
        mapping = MappingDef(
            name="m_disconnect",
            transformations=[
                TransformationDef(name="SQ_SRC1", type="Source Qualifier", fields=[], attributes=[]),
            ],
            connectors=[],
            instances=[
                InstanceDef(name="SRC1", type="Source Definition", transformation_name="SRC1"),
                InstanceDef(name="SQ_SRC1", type="Source Qualifier", transformation_name="SQ_SRC1"),
                InstanceDef(name="TGT1", type="Target Definition", transformation_name="TGT1"),
            ],
        )
        folder = FolderDef(name="TestFolder", sources=[], targets=[], mappings=[mapping])
        code = generate_mapping_code(mapping, folder, "pandas", 1)
        assert "df_sq_src1" in code

    def test_sq_with_sql_override_no_sources(self):
        from informatica_python.models import (
            FolderDef, MappingDef, TransformationDef,
            InstanceDef, ConnectorDef, FieldDef, TableAttribute,
        )
        from informatica_python.generators.mapping_gen import generate_mapping_code
        mapping = MappingDef(
            name="m_sql_only",
            transformations=[
                TransformationDef(
                    name="SQ_SQL",
                    type="Source Qualifier",
                    fields=[],
                    attributes=[TableAttribute(name="Sql Query", value="SELECT * FROM my_table")],
                ),
            ],
            connectors=[],
            instances=[
                InstanceDef(name="SQ_SQL", type="Source Qualifier", transformation_name="SQ_SQL"),
                InstanceDef(name="TGT1", type="Target Definition", transformation_name="TGT1"),
            ],
        )
        folder = FolderDef(name="TestFolder", sources=[], targets=[], mappings=[mapping])
        code = generate_mapping_code(mapping, folder, "pandas", 1)
        assert "df_sq_sql" in code
        assert "read_from_db" in code


class TestTargetWriteGeneration(unittest.TestCase):

    def _make_mapping(self, tgt_name, tgt_def):
        from informatica_python.models import (
            MappingDef, FolderDef, TransformationDef,
            InstanceDef, ConnectorDef, FieldDef,
        )
        from informatica_python.generators.mapping_gen import generate_mapping_code
        instances = [
            InstanceDef(name=tgt_name, type="Target Definition", transformation_name=tgt_name),
        ]
        sq = TransformationDef(name="SQ_X", type="Source Qualifier", fields=[])
        connectors = [
            ConnectorDef(
                from_instance="SQ_X", from_field="COL1",
                from_instance_type="Source Qualifier",
                to_instance=tgt_name, to_field="COL1",
                to_instance_type="Target Definition",
            ),
        ]
        mapping = MappingDef(
            name="m_tgt_test", description="test",
            transformations=[sq], connectors=connectors, instances=instances,
        )
        folder = FolderDef(name="test", targets=[tgt_def])
        return generate_mapping_code(mapping, folder, "pandas", 1)

    def test_db_target_with_database_type_generates_write_to_db(self):
        from informatica_python.models import TargetDef, FieldDef
        tgt = TargetDef(name="TGT_TABLE", database_type="Oracle",
                        fields=[FieldDef(name="COL1", datatype="string")])
        code = self._make_mapping("TGT_TABLE", tgt)
        assert "write_to_db" in code
        assert "write_file" not in code

    def test_bare_target_defaults_to_write_to_db(self):
        from informatica_python.models import TargetDef, FieldDef
        tgt = TargetDef(name="MY_TABLE",
                        fields=[FieldDef(name="COL1", datatype="string")])
        code = self._make_mapping("MY_TABLE", tgt)
        assert "write_to_db" in code
        assert "write_file" not in code

    def test_target_with_file_extension_generates_write_file(self):
        from informatica_python.models import TargetDef, FieldDef
        tgt = TargetDef(name="output.csv",
                        fields=[FieldDef(name="COL1", datatype="string")])
        code = self._make_mapping("output.csv", tgt)
        assert "write_file" in code
        assert "write_to_db" not in code

    def test_flatfile_target_generates_write_file(self):
        from informatica_python.models import TargetDef, FieldDef, FlatFileDef
        tgt = TargetDef(name="FF_TGT", database_type="Flat File",
                        flatfile=FlatFileDef(name="FF_TGT"),
                        fields=[FieldDef(name="COL1", datatype="string")])
        code = self._make_mapping("FF_TGT", tgt)
        assert "write_file" in code
        assert "write_to_db" not in code

    def test_bare_target_with_update_strategy_generates_write_with_update(self):
        from informatica_python.models import TargetDef, FieldDef
        tgt = TargetDef(name="MY_TABLE",
                        fields=[FieldDef(name="COL1", datatype="string")])
        code = self._make_mapping("MY_TABLE", tgt)
        assert "write_with_update_strategy" in code

    def test_db_target_with_primary_key_passes_key_columns(self):
        from informatica_python.models import TargetDef, FieldDef
        tgt = TargetDef(name="TGT_PK", database_type="Oracle",
                        fields=[
                            FieldDef(name="ID", datatype="integer", keytype="PRIMARY KEY"),
                            FieldDef(name="VAL", datatype="string"),
                        ])
        code = self._make_mapping("TGT_PK", tgt)
        assert "key_columns=['ID']" in code

    def test_dotted_schema_table_name_defaults_to_write_to_db(self):
        from informatica_python.models import TargetDef, FieldDef
        tgt = TargetDef(name="dbo.MY_TABLE",
                        fields=[FieldDef(name="COL1", datatype="string")])
        code = self._make_mapping("dbo.MY_TABLE", tgt)
        assert "write_to_db" in code
        assert "write_file" not in code


class TestCodeFormattingAndComments(unittest.TestCase):

    def _generate_full_mapping(self):
        from informatica_python.models import (
            MappingDef, FolderDef, TransformationDef,
            InstanceDef, ConnectorDef, FieldDef, SourceDef, TargetDef,
            TableAttribute,
        )
        from informatica_python.generators.mapping_gen import generate_mapping_code
        src = SourceDef(name="SRC", database_type="Oracle",
                        fields=[FieldDef(name="ID", datatype="integer"),
                                FieldDef(name="VAL", datatype="string")])
        tgt = TargetDef(name="TGT", database_type="Oracle",
                        fields=[FieldDef(name="ID", datatype="integer"),
                                FieldDef(name="VAL", datatype="string")])
        sq = TransformationDef(name="SQ_SRC", type="Source Qualifier",
                               fields=[], attributes=[])
        exp = TransformationDef(name="EXP_CALC", type="Expression", fields=[
            FieldDef(name="ID", datatype="integer", porttype="INPUT"),
            FieldDef(name="VAL", datatype="string", porttype="INPUT"),
            FieldDef(name="OUT_VAL", datatype="string", porttype="OUTPUT",
                     expression="UPPER(VAL)"),
        ])
        instances = [
            InstanceDef(name="SRC", type="Source Definition", transformation_name="SRC"),
            InstanceDef(name="SQ_SRC", type="Source Qualifier", transformation_name="SQ_SRC"),
            InstanceDef(name="EXP_CALC", type="Expression", transformation_name="EXP_CALC"),
            InstanceDef(name="TGT", type="Target Definition", transformation_name="TGT"),
        ]
        connectors = [
            ConnectorDef(from_instance="SRC", from_field="ID", from_instance_type="Source Definition",
                         to_instance="SQ_SRC", to_field="ID", to_instance_type="Source Qualifier"),
            ConnectorDef(from_instance="SQ_SRC", from_field="ID", from_instance_type="Source Qualifier",
                         to_instance="EXP_CALC", to_field="ID", to_instance_type="Expression"),
            ConnectorDef(from_instance="SQ_SRC", from_field="VAL", from_instance_type="Source Qualifier",
                         to_instance="EXP_CALC", to_field="VAL", to_instance_type="Expression"),
            ConnectorDef(from_instance="EXP_CALC", from_field="ID", from_instance_type="Expression",
                         to_instance="TGT", to_field="ID", to_instance_type="Target Definition"),
            ConnectorDef(from_instance="EXP_CALC", from_field="OUT_VAL", from_instance_type="Expression",
                         to_instance="TGT", to_field="VAL", to_instance_type="Target Definition"),
        ]
        mapping = MappingDef(name="m_test_fmt", description="Test formatting",
                             transformations=[sq, exp], connectors=connectors,
                             instances=instances)
        folder = FolderDef(name="TEST", sources=[src], targets=[tgt])
        return generate_mapping_code(mapping, folder)

    def test_source_qualifier_has_section_header(self):
        code = self._generate_full_mapping()
        lines = code.split("\n")
        found_sq_header = False
        for i, line in enumerate(lines):
            if "# Source Qualifier: SQ_SRC" in line:
                assert "# ---" in lines[i - 1], "Missing separator above Source Qualifier"
                assert "# ---" in lines[i + 1], "Missing separator below Source Qualifier"
                found_sq_header = True
                break
        assert found_sq_header, "Source Qualifier section header not found"

    def test_target_write_has_section_header(self):
        code = self._generate_full_mapping()
        lines = code.split("\n")
        found_tgt_header = False
        for i, line in enumerate(lines):
            if "# Write to target: TGT" in line:
                assert "# ---" in lines[i - 1], "Missing separator above target write"
                found_tgt_header = True
                break
        assert found_tgt_header, "Target write section header not found"

    def test_target_write_has_database_type_comment(self):
        code = self._generate_full_mapping()
        assert "# Database type: Oracle" in code

    def test_target_write_has_field_list_comment(self):
        code = self._generate_full_mapping()
        assert "# Target fields: ID, VAL" in code

    def test_target_write_has_column_mapping_comment(self):
        code = self._generate_full_mapping()
        assert "# Column mapping: source -> target" in code

    def test_target_write_has_write_operation_comment(self):
        code = self._generate_full_mapping()
        assert "# Write to database table" in code

    def test_no_blank_line_after_try(self):
        code = self._generate_full_mapping()
        lines = code.split("\n")
        for i, line in enumerate(lines):
            if line.strip() == "try:":
                assert lines[i + 1].strip() != "", "Blank line after try: should not exist"
                break

    def test_no_consecutive_blank_lines_inside_try_block(self):
        code = self._generate_full_mapping()
        lines = code.split("\n")
        inside_try = False
        consecutive = 0
        for line in lines:
            if line.strip() == "try:":
                inside_try = True
                continue
            if inside_try and line.strip().startswith("except "):
                break
            if not inside_try:
                continue
            if line.strip() == "":
                consecutive += 1
            else:
                consecutive = 0
            assert consecutive <= 1, f"Found {consecutive} consecutive blank lines inside try block"

    def test_expression_has_inline_comment(self):
        code = self._generate_full_mapping()
        assert "# OUT_VAL = UPPER(VAL)" in code

    def test_transformation_has_section_header(self):
        code = self._generate_full_mapping()
        assert "# Transformation: EXP_CALC (Type: Expression)" in code
        assert "# Input fields:" in code
        assert "# Output fields:" in code


class TestCompoundExpressions(unittest.TestCase):
    """Tests for Informatica functions in compound arithmetic expressions."""

    def test_to_integer_minus_literal(self):
        r = convert_expression_vectorized("TO_INTEGER(Records_in_file) - 1", "df")
        assert "pd.to_numeric" in r
        assert 'errors="coerce"' in r
        assert "- 1" in r
        assert "TO_INTEGER" not in r

    def test_to_integer_minus_to_integer(self):
        r = convert_expression_vectorized("TO_INTEGER(x) - TO_INTEGER(y)", "df")
        assert r.count("pd.to_numeric") == 2
        assert 'df["x"]' in r
        assert 'df["y"]' in r

    def test_round_times_literal(self):
        r = convert_expression_vectorized("ROUND(x) * 100", "df")
        assert "np.round" in r
        assert "* 100" in r
        assert r.count("np.") == 1

    def test_nvl_plus_literal(self):
        r = convert_expression_vectorized("NVL(count, 0) + 1", "df")
        assert ".fillna(0)" in r
        assert "+ 1" in r

    def test_length_plus_length(self):
        r = convert_expression_vectorized("LENGTH(name) + LENGTH(addr)", "df")
        assert r.count(".str.len()") == 2
        assert 'df["name"]' in r
        assert 'df["addr"]' in r

    def test_abs_plus_floor(self):
        r = convert_expression_vectorized("ABS(a) + FLOOR(b)", "df")
        assert "np.abs" in r
        assert "np.floor" in r

    def test_iif_plus_field(self):
        r = convert_expression_vectorized("IIF(flag = 1, amt, 0) + tax", "df")
        assert "np.where" in r
        assert "df[\"tax\"]" in r

    def test_nested_to_integer_in_trunc(self):
        r = convert_expression_vectorized(
            "TRUNC(TO_INTEGER(rejected) / TO_INTEGER(total) * 100, 2)", "df"
        )
        assert "np.trunc" in r
        assert r.count("pd.to_numeric") == 2
        assert "10**2" in r

    def test_errors_coerce_not_mangled(self):
        r = convert_expression_vectorized("TO_INTEGER(x) - 1", "df")
        assert 'errors="coerce"' in r
        assert 'errors=="coerce"' not in r

    def test_string_comparison_no_spaces(self):
        r = convert_expression_vectorized("IIF(A='X', 1, 0)", "df")
        assert "==" in r
        assert "np.where" in r

    def test_string_comparison_with_spaces(self):
        r = convert_expression_vectorized("IIF(A = 'X', 1, 0)", "df")
        assert "==" in r
        assert "np.where" in r


class TestTruncNumericPrecision(unittest.TestCase):
    """Tests for TRUNC with numeric precision (not date format)."""

    def test_trunc_precision_2(self):
        r = convert_expression_vectorized("TRUNC(amount, 2)", "df")
        assert "np.trunc" in r
        assert "10**2" in r
        assert "dt.floor" not in r

    def test_trunc_precision_0(self):
        r = convert_expression_vectorized("TRUNC(amount, 0)", "df")
        assert "np.trunc" in r
        assert "10**" not in r

    def test_trunc_no_precision(self):
        r = convert_expression_vectorized("TRUNC(amount)", "df")
        assert "np.trunc" in r

    def test_trunc_date_dd_still_works(self):
        r = convert_expression_vectorized("TRUNC(datecol, 'DD')", "df")
        assert "dt.floor" in r

    def test_trunc_date_mm_still_works(self):
        r = convert_expression_vectorized("TRUNC(datecol, 'MM')", "df")
        assert "dt.to_period" in r

    def test_trunc_precision_in_compound(self):
        r = convert_expression_vectorized("TRUNC(x, 2) + 1", "df")
        assert "np.trunc" in r
        assert "10**2" in r
        assert "+ 1" in r


class TestJoinerFieldRemapping(unittest.TestCase):
    """Tests for joiner field name remapping through connector graph."""

    JOINER_XML = '''<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE POWERMART SYSTEM "powrmart.dtd">
<POWERMART CREATION_DATE="01/01/2025" REPOSITORY_VERSION="1">
<REPOSITORY NAME="repo" VERSION="1" CODEPAGE="UTF-8" DATABASETYPE="Oracle">
<FOLDER NAME="TEST" OWNER="admin">
  <SOURCE NAME="SRC_A" DATABASETYPE="Oracle" DBDNAME="SCHEMA_A">
    <SOURCEFIELD NAME="Table_Name" DATATYPE="string" PRECISION="100" SCALE="0" NULLABLE="NULL" KEYTYPE="NOT A KEY" FIELDNUMBER="1"/>
    <SOURCEFIELD NAME="Row_Count" DATATYPE="integer" PRECISION="10" SCALE="0" NULLABLE="NULL" KEYTYPE="NOT A KEY" FIELDNUMBER="2"/>
  </SOURCE>
  <SOURCE NAME="SRC_B" DATABASETYPE="Oracle" DBDNAME="SCHEMA_B">
    <SOURCEFIELD NAME="Table_Name" DATATYPE="string" PRECISION="100" SCALE="0" NULLABLE="NULL" KEYTYPE="NOT A KEY" FIELDNUMBER="1"/>
    <SOURCEFIELD NAME="File_Count" DATATYPE="integer" PRECISION="10" SCALE="0" NULLABLE="NULL" KEYTYPE="NOT A KEY" FIELDNUMBER="2"/>
  </SOURCE>
  <TARGET NAME="TGT_OUT" DATABASETYPE="Oracle">
    <TARGETFIELD NAME="Table_Name" DATATYPE="string" PRECISION="100" SCALE="0" NULLABLE="NULL" KEYTYPE="NOT A KEY" FIELDNUMBER="1"/>
    <TARGETFIELD NAME="Row_Count" DATATYPE="integer" PRECISION="10" SCALE="0" NULLABLE="NULL" KEYTYPE="NOT A KEY" FIELDNUMBER="2"/>
  </TARGET>
  <MAPPING NAME="m_joiner_remap" ISVALID="YES">
    <TRANSFORMATION NAME="SQ_SRC_A" TYPE="Source Qualifier" REUSABLE="NO">
      <TRANSFORMFIELD NAME="Table_Name" DATATYPE="string" PRECISION="100" SCALE="0" PORTTYPE="OUTPUT"/>
      <TRANSFORMFIELD NAME="Row_Count" DATATYPE="integer" PRECISION="10" SCALE="0" PORTTYPE="OUTPUT"/>
    </TRANSFORMATION>
    <TRANSFORMATION NAME="SQ_SRC_B" TYPE="Source Qualifier" REUSABLE="NO">
      <TRANSFORMFIELD NAME="Table_Name" DATATYPE="string" PRECISION="100" SCALE="0" PORTTYPE="OUTPUT"/>
      <TRANSFORMFIELD NAME="File_Count" DATATYPE="integer" PRECISION="10" SCALE="0" PORTTYPE="OUTPUT"/>
    </TRANSFORMATION>
    <TRANSFORMATION NAME="JNR_AB" TYPE="Joiner" REUSABLE="NO">
      <TRANSFORMFIELD NAME="Table_Name" DATATYPE="string" PRECISION="100" SCALE="0" PORTTYPE="INPUT/OUTPUT MASTER"/>
      <TRANSFORMFIELD NAME="Row_Count" DATATYPE="integer" PRECISION="10" SCALE="0" PORTTYPE="INPUT/OUTPUT MASTER"/>
      <TRANSFORMFIELD NAME="Table_Name1" DATATYPE="string" PRECISION="100" SCALE="0" PORTTYPE="INPUT/OUTPUT DETAIL"/>
      <TRANSFORMFIELD NAME="File_Count" DATATYPE="integer" PRECISION="10" SCALE="0" PORTTYPE="INPUT/OUTPUT DETAIL"/>
      <TABLEATTRIBUTE NAME="Join Condition" VALUE="Table_Name = Table_Name1"/>
      <TABLEATTRIBUTE NAME="Join Type" VALUE="Normal"/>
    </TRANSFORMATION>
    <INSTANCE NAME="SRC_A" TYPE="Source Definition" TRANSFORMATION_NAME="SRC_A"/>
    <INSTANCE NAME="SRC_B" TYPE="Source Definition" TRANSFORMATION_NAME="SRC_B"/>
    <INSTANCE NAME="SQ_SRC_A" TYPE="Source Qualifier" TRANSFORMATION_NAME="SQ_SRC_A"/>
    <INSTANCE NAME="SQ_SRC_B" TYPE="Source Qualifier" TRANSFORMATION_NAME="SQ_SRC_B"/>
    <INSTANCE NAME="JNR_AB" TYPE="Joiner" TRANSFORMATION_NAME="JNR_AB"/>
    <INSTANCE NAME="TGT_OUT" TYPE="Target Definition" TRANSFORMATION_NAME="TGT_OUT"/>
    <CONNECTOR FROMINSTANCE="SRC_A" FROMFIELD="Table_Name" TOINSTANCE="SQ_SRC_A" TOFIELD="Table_Name"/>
    <CONNECTOR FROMINSTANCE="SRC_A" FROMFIELD="Row_Count" TOINSTANCE="SQ_SRC_A" TOFIELD="Row_Count"/>
    <CONNECTOR FROMINSTANCE="SRC_B" FROMFIELD="Table_Name" TOINSTANCE="SQ_SRC_B" TOFIELD="Table_Name"/>
    <CONNECTOR FROMINSTANCE="SRC_B" FROMFIELD="File_Count" TOINSTANCE="SQ_SRC_B" TOFIELD="File_Count"/>
    <CONNECTOR FROMINSTANCE="SQ_SRC_A" FROMFIELD="Table_Name" TOINSTANCE="JNR_AB" TOFIELD="Table_Name"/>
    <CONNECTOR FROMINSTANCE="SQ_SRC_A" FROMFIELD="Row_Count" TOINSTANCE="JNR_AB" TOFIELD="Row_Count"/>
    <CONNECTOR FROMINSTANCE="SQ_SRC_B" FROMFIELD="Table_Name" TOINSTANCE="JNR_AB" TOFIELD="Table_Name1"/>
    <CONNECTOR FROMINSTANCE="SQ_SRC_B" FROMFIELD="File_Count" TOINSTANCE="JNR_AB" TOFIELD="File_Count"/>
    <CONNECTOR FROMINSTANCE="JNR_AB" FROMFIELD="Table_Name" TOINSTANCE="TGT_OUT" TOFIELD="Table_Name"/>
    <CONNECTOR FROMINSTANCE="JNR_AB" FROMFIELD="Row_Count" TOINSTANCE="TGT_OUT" TOFIELD="Row_Count"/>
  </MAPPING>
  <CONFIG NAME="default_session_config"/>
  <WORKFLOW NAME="wf_joiner_test" ISVALID="YES">
    <TASK NAME="Start" REUSABLE="NO" TYPE="Start"/>
    <SESSION NAME="s_m_joiner_remap" ISVALID="YES" REUSABLE="NO" MAPPINGNAME="m_joiner_remap">
      <CONFIGREFERENCE REFOBJECTNAME="default_session_config" TYPE="Session config"/>
    </SESSION>
    <TASKINSTANCE NAME="Start" TASKNAME="Start" TASKTYPE="Start"/>
    <TASKINSTANCE NAME="s_m_joiner_remap" TASKNAME="s_m_joiner_remap" TASKTYPE="Session"/>
    <WORKFLOWLINK FROMTASK="Start" TOTASK="s_m_joiner_remap"/>
  </WORKFLOW>
</FOLDER>
</REPOSITORY>
</POWERMART>'''

    def _get_mapping_code(self):
        converter = InformaticaConverter()
        tmpdir = tempfile.mkdtemp()
        try:
            converter.convert_string(self.JOINER_XML, output_dir=tmpdir)
            mapping_file = os.path.join(tmpdir, "mapping_m_joiner_remap.py")
            if os.path.exists(mapping_file):
                with open(mapping_file) as f:
                    return f.read()
            for fn in os.listdir(tmpdir):
                if fn.startswith("mapping_") and fn.endswith(".py"):
                    with open(os.path.join(tmpdir, fn)) as f:
                        return f.read()
            return ""
        finally:
            shutil.rmtree(tmpdir)

    def test_joiner_remaps_port_names(self):
        code = self._get_mapping_code()
        for line in code.split("\n"):
            if "left_on" in line:
                assert "Table_Name1" not in line, \
                    f"Merge should use remapped column names, not port names: {line}"

    def test_joiner_uses_source_column_names(self):
        code = self._get_mapping_code()
        assert ".merge(" in code, "Joiner should generate a merge call"
        for line in code.split("\n"):
            if "left_on" in line and "right_on" in line:
                assert "Table_Name" in line, \
                    "Merge should use source column name Table_Name"


class TestRegExtractConversion(unittest.TestCase):
    """Tests for REG_EXTRACT capture group and expand parameter handling."""

    def test_no_double_capture_group(self):
        r = convert_expression_vectorized(r"REG_EXTRACT(col,'(\s+)')", "df")
        assert r.count("(") - r.count("str.extract") <= 2
        assert '((\\s+))' not in r

    def test_adds_capture_group_when_missing(self):
        r = convert_expression_vectorized(r"REG_EXTRACT(col,'\\d+')", "df")
        assert 'expand=False' in r
        assert '.str.extract' in r

    def test_expand_is_boolean_not_series(self):
        r = convert_expression_vectorized(r"REG_EXTRACT(col,'(\s+)')", "df")
        assert 'expand=False' in r
        assert 'expand==False' not in r
        assert 'df["expand"]' not in r

    def test_isnull_reg_extract_nested(self):
        r = convert_expression_vectorized(
            "IIF(ISNULL(REG_EXTRACT(PART_BIRTH_DTE,'(\\s+)')),PART_BIRTH_DTE,NULL)", "df_exp"
        )
        assert "np.where" in r
        assert ".isna()" in r
        assert "expand=False" in r
        assert 'expand==False' not in r
        assert 'df_exp["expand"]' not in r


class TestDatetimeFormatMask(unittest.TestCase):
    """Tests for datetime format mask conversion (US/microseconds)."""

    def test_us_to_percent_f(self):
        from informatica_python.utils.expression_converter import _convert_infa_date_format
        fmt = _convert_infa_date_format("YYYY-MM-DD HH24.MI.SS.US")
        assert "%f" in fmt
        assert "US" not in fmt

    def test_full_format_mask(self):
        from informatica_python.utils.expression_converter import _convert_infa_date_format
        fmt = _convert_infa_date_format("YYYY-MM-DD HH24:MI:SS")
        assert fmt == "%Y-%m-%d %H:%M:%S"

    def test_to_date_with_us_format(self):
        r = convert_expression_vectorized(
            "TO_DATE(x, 'YYYY-MM-DD HH24.MI.SS.US')", "df"
        )
        assert "%f" in r
        assert "US" not in r


class TestSubstrZeroIndex(unittest.TestCase):
    """Tests for SUBSTR with 0-based start position."""

    def test_substr_start_0(self):
        r = convert_expression_vectorized("SUBSTR(x, 0, 11)", "df")
        assert "str[0:" in r
        assert "str[-1:" not in r

    def test_substr_start_1(self):
        r = convert_expression_vectorized("SUBSTR(x, 1, 5)", "df")
        assert "str[0:" in r

    def test_substr_start_5(self):
        r = convert_expression_vectorized("SUBSTR(x, 5, 3)", "df")
        assert "str[4:7]" in r


class TestStringOpSafety(unittest.TestCase):
    """Tests for string operations adding .astype(str) for safety."""

    def test_ltrim_has_astype_str(self):
        r = convert_expression_vectorized("LTRIM(name)", "df")
        assert ".astype(str)" in r
        assert ".str.lstrip()" in r

    def test_rtrim_has_astype_str(self):
        r = convert_expression_vectorized("RTRIM(name)", "df")
        assert ".astype(str)" in r
        assert ".str.rstrip()" in r

    def test_trim_has_astype_str(self):
        r = convert_expression_vectorized("TRIM(name)", "df")
        assert ".astype(str)" in r
        assert ".str.strip()" in r

    def test_ltrim_with_char(self):
        r = convert_expression_vectorized("LTRIM(name, '0')", "df")
        assert ".astype(str)" in r
        assert '.str.lstrip("0")' in r


class TestRouterVectorized(unittest.TestCase):
    """Tests for Router transformation generating vectorized conditions."""

    ROUTER_XML = '''<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE POWERMART SYSTEM "powrmart.dtd">
<POWERMART CREATION_DATE="01/01/2025" REPOSITORY_VERSION="1">
<REPOSITORY NAME="repo" VERSION="1" CODEPAGE="UTF-8" DATABASETYPE="Oracle">
<FOLDER NAME="TEST" OWNER="admin">
  <SOURCE NAME="SRC" DATABASETYPE="Flat File" DBDNAME="SRC">
    <FLATFILE DELIMITEDBY="COMMA" HEADERROWPRESENT="YES" PADBYTES="NO" ROWDELIMITER="\\n"/>
    <SOURCEFIELD NAME="ID" DATATYPE="integer" PRECISION="10" SCALE="0" NULLABLE="NOTNULL" KEYTYPE="PRIMARY KEY" FIELDNUMBER="1"/>
    <SOURCEFIELD NAME="STATUS" DATATYPE="string" PRECISION="20" SCALE="0" NULLABLE="NULL" KEYTYPE="NOT A KEY" FIELDNUMBER="2"/>
  </SOURCE>
  <TARGET NAME="TGT" DATABASETYPE="Flat File">
    <TARGETFIELD NAME="ID" DATATYPE="integer" PRECISION="10" SCALE="0" NULLABLE="NULL" KEYTYPE="NOT A KEY" FIELDNUMBER="1"/>
  </TARGET>
  <MAPPING NAME="m_router_test" ISVALID="YES">
    <TRANSFORMATION NAME="SQ_SRC" TYPE="Source Qualifier" REUSABLE="NO">
      <TRANSFORMFIELD NAME="ID" DATATYPE="integer" PRECISION="10" SCALE="0" PORTTYPE="OUTPUT"/>
      <TRANSFORMFIELD NAME="STATUS" DATATYPE="string" PRECISION="20" SCALE="0" PORTTYPE="OUTPUT"/>
    </TRANSFORMATION>
    <TRANSFORMATION NAME="RTR_STATUS" TYPE="Router" REUSABLE="NO">
      <TRANSFORMFIELD NAME="ID" DATATYPE="integer" PRECISION="10" SCALE="0" PORTTYPE="INPUT/OUTPUT"/>
      <TRANSFORMFIELD NAME="STATUS" DATATYPE="string" PRECISION="20" SCALE="0" PORTTYPE="INPUT/OUTPUT"/>
      <TABLEATTRIBUTE NAME="Group Filter Condition_ACTIVE" VALUE="STATUS = 'ACTIVE'"/>
      <TABLEATTRIBUTE NAME="Group Filter Condition_INACTIVE" VALUE="STATUS = 'INACTIVE'"/>
    </TRANSFORMATION>
    <INSTANCE NAME="SRC" TYPE="Source Definition" TRANSFORMATION_NAME="SRC"/>
    <INSTANCE NAME="SQ_SRC" TYPE="Source Qualifier" TRANSFORMATION_NAME="SQ_SRC"/>
    <INSTANCE NAME="RTR_STATUS" TYPE="Router" TRANSFORMATION_NAME="RTR_STATUS"/>
    <INSTANCE NAME="TGT" TYPE="Target Definition" TRANSFORMATION_NAME="TGT"/>
    <CONNECTOR FROMINSTANCE="SRC" FROMFIELD="ID" TOINSTANCE="SQ_SRC" TOFIELD="ID"/>
    <CONNECTOR FROMINSTANCE="SRC" FROMFIELD="STATUS" TOINSTANCE="SQ_SRC" TOFIELD="STATUS"/>
    <CONNECTOR FROMINSTANCE="SQ_SRC" FROMFIELD="ID" TOINSTANCE="RTR_STATUS" TOFIELD="ID"/>
    <CONNECTOR FROMINSTANCE="SQ_SRC" FROMFIELD="STATUS" TOINSTANCE="RTR_STATUS" TOFIELD="STATUS"/>
    <CONNECTOR FROMINSTANCE="RTR_STATUS" FROMFIELD="ID" TOINSTANCE="TGT" TOFIELD="ID"/>
  </MAPPING>
  <CONFIG NAME="default_session_config"/>
  <WORKFLOW NAME="wf_router_test" ISVALID="YES">
    <TASK NAME="Start" REUSABLE="NO" TYPE="Start"/>
    <SESSION NAME="s_m_router_test" ISVALID="YES" REUSABLE="NO" MAPPINGNAME="m_router_test">
      <CONFIGREFERENCE REFOBJECTNAME="default_session_config" TYPE="Session config"/>
    </SESSION>
    <TASKINSTANCE NAME="Start" TASKNAME="Start" TASKTYPE="Start"/>
    <TASKINSTANCE NAME="s_m_router_test" TASKNAME="s_m_router_test" TASKTYPE="Session"/>
    <WORKFLOWLINK FROMTASK="Start" TOTASK="s_m_router_test"/>
  </WORKFLOW>
</FOLDER>
</REPOSITORY>
</POWERMART>'''

    def test_router_generates_group_filters(self):
        converter = InformaticaConverter()
        tmpdir = tempfile.mkdtemp()
        try:
            converter.convert_string(self.ROUTER_XML, output_dir=tmpdir)
            for fn in os.listdir(tmpdir):
                if fn.startswith("mapping_") and fn.endswith(".py"):
                    with open(os.path.join(tmpdir, fn)) as f:
                        code = f.read()
                    assert "_router_mask_" in code or "group0" in code, \
                        "Router should generate group filter masks"
                    assert "Default group" in code
                    break
        finally:
            shutil.rmtree(tmpdir)

    def test_router_default_excludes_matched_rows(self):
        converter = InformaticaConverter()
        tmpdir = tempfile.mkdtemp()
        try:
            converter.convert_string(self.ROUTER_XML, output_dir=tmpdir)
            for fn in os.listdir(tmpdir):
                if fn.startswith("mapping_") and fn.endswith(".py"):
                    with open(os.path.join(tmpdir, fn)) as f:
                        code = f.read()
                    assert "_router_default_mask" in code or "~" in code, \
                        "Default group should exclude rows matching other groups"
                    break
        finally:
            shutil.rmtree(tmpdir)


class TestLookupWarning(unittest.TestCase):
    """Tests for lookup empty DataFrame warning."""

    LOOKUP_XML = '''<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE POWERMART SYSTEM "powrmart.dtd">
<POWERMART CREATION_DATE="01/01/2025" REPOSITORY_VERSION="1">
<REPOSITORY NAME="repo" VERSION="1" CODEPAGE="UTF-8" DATABASETYPE="Oracle">
<FOLDER NAME="TEST" OWNER="admin">
  <SOURCE NAME="SRC" DATABASETYPE="Flat File" DBDNAME="SRC">
    <FLATFILE DELIMITEDBY="COMMA" HEADERROWPRESENT="YES" PADBYTES="NO" ROWDELIMITER="\\n"/>
    <SOURCEFIELD NAME="ID" DATATYPE="integer" PRECISION="10" SCALE="0" NULLABLE="NOTNULL" KEYTYPE="PRIMARY KEY" FIELDNUMBER="1"/>
  </SOURCE>
  <TARGET NAME="TGT" DATABASETYPE="Flat File">
    <TARGETFIELD NAME="ID" DATATYPE="integer" PRECISION="10" SCALE="0" NULLABLE="NULL" KEYTYPE="NOT A KEY" FIELDNUMBER="1"/>
  </TARGET>
  <MAPPING NAME="m_lkp_test" ISVALID="YES">
    <TRANSFORMATION NAME="SQ_SRC" TYPE="Source Qualifier" REUSABLE="NO">
      <TRANSFORMFIELD NAME="ID" DATATYPE="integer" PRECISION="10" SCALE="0" PORTTYPE="OUTPUT"/>
    </TRANSFORMATION>
    <TRANSFORMATION NAME="LKP_TEST" TYPE="Lookup Procedure" REUSABLE="NO">
      <TRANSFORMFIELD NAME="ID" DATATYPE="integer" PRECISION="10" SCALE="0" PORTTYPE="INPUT"/>
      <TRANSFORMFIELD NAME="RESULT" DATATYPE="string" PRECISION="100" SCALE="0" PORTTYPE="OUTPUT/RETURN"/>
      <TABLEATTRIBUTE NAME="Lookup table name" VALUE="DIM_TABLE"/>
      <TABLEATTRIBUTE NAME="Lookup condition" VALUE="ID = ID"/>
    </TRANSFORMATION>
    <INSTANCE NAME="SRC" TYPE="Source Definition" TRANSFORMATION_NAME="SRC"/>
    <INSTANCE NAME="SQ_SRC" TYPE="Source Qualifier" TRANSFORMATION_NAME="SQ_SRC"/>
    <INSTANCE NAME="LKP_TEST" TYPE="Lookup Procedure" TRANSFORMATION_NAME="LKP_TEST"/>
    <INSTANCE NAME="TGT" TYPE="Target Definition" TRANSFORMATION_NAME="TGT"/>
    <CONNECTOR FROMINSTANCE="SRC" FROMFIELD="ID" TOINSTANCE="SQ_SRC" TOFIELD="ID"/>
    <CONNECTOR FROMINSTANCE="SQ_SRC" FROMFIELD="ID" TOINSTANCE="LKP_TEST" TOFIELD="ID"/>
    <CONNECTOR FROMINSTANCE="LKP_TEST" FROMFIELD="RESULT" TOINSTANCE="TGT" TOFIELD="ID"/>
  </MAPPING>
  <CONFIG NAME="default_session_config"/>
  <WORKFLOW NAME="wf_lkp_test" ISVALID="YES">
    <TASK NAME="Start" REUSABLE="NO" TYPE="Start"/>
    <SESSION NAME="s_m_lkp_test" ISVALID="YES" REUSABLE="NO" MAPPINGNAME="m_lkp_test">
      <CONFIGREFERENCE REFOBJECTNAME="default_session_config" TYPE="Session config"/>
    </SESSION>
    <TASKINSTANCE NAME="Start" TASKNAME="Start" TASKTYPE="Start"/>
    <TASKINSTANCE NAME="s_m_lkp_test" TASKNAME="s_m_lkp_test" TASKTYPE="Session"/>
    <WORKFLOWLINK FROMTASK="Start" TOTASK="s_m_lkp_test"/>
  </WORKFLOW>
</FOLDER>
</REPOSITORY>
</POWERMART>'''

    def test_lookup_with_table_reads_from_db(self):
        converter = InformaticaConverter()
        tmpdir = tempfile.mkdtemp()
        try:
            converter.convert_string(self.LOOKUP_XML, output_dir=tmpdir)
            for fn in os.listdir(tmpdir):
                if fn.startswith("mapping_") and fn.endswith(".py"):
                    with open(os.path.join(tmpdir, fn)) as f:
                        code = f.read()
                    assert "read_from_db" in code, "Lookup with table should use read_from_db"
                    assert "DIM_TABLE" in code
                    break
        finally:
            shutil.rmtree(tmpdir)


class TestRenameWithDuplicates(unittest.TestCase):

    def test_helper_contains_rename_with_duplicates(self):
        converter = InformaticaConverter()
        tmpdir = tempfile.mkdtemp()
        try:
            converter.convert_string(MINIMAL_XML, output_dir=tmpdir)
            with open(os.path.join(tmpdir, "helper_functions.py")) as f:
                code = f.read()
            assert "def rename_with_duplicates(" in code
        finally:
            shutil.rmtree(tmpdir)

    def test_target_uses_rename_with_duplicates(self):
        converter = InformaticaConverter()
        tmpdir = tempfile.mkdtemp()
        try:
            converter.convert_string(MINIMAL_XML, output_dir=tmpdir)
            for fn in os.listdir(tmpdir):
                if fn.startswith("mapping_") and fn.endswith(".py"):
                    with open(os.path.join(tmpdir, fn)) as f:
                        code = f.read()
                    if "target_columns_" in code:
                        assert "rename_with_duplicates(" in code, \
                            "Target rename should use rename_with_duplicates"
        finally:
            shutil.rmtree(tmpdir)


class TestResolveEnv(unittest.TestCase):

    def test_helper_contains_resolve_env(self):
        converter = InformaticaConverter()
        tmpdir = tempfile.mkdtemp()
        try:
            converter.convert_string(MINIMAL_XML, output_dir=tmpdir)
            with open(os.path.join(tmpdir, "helper_functions.py")) as f:
                code = f.read()
            assert "def resolve_env(" in code
        finally:
            shutil.rmtree(tmpdir)

    def test_helper_contains_resolve_builtin_variable(self):
        converter = InformaticaConverter()
        tmpdir = tempfile.mkdtemp()
        try:
            converter.convert_string(MINIMAL_XML, output_dir=tmpdir)
            with open(os.path.join(tmpdir, "helper_functions.py")) as f:
                code = f.read()
            assert "def resolve_builtin_variable(" in code
            assert "PMMappingName" in code
        finally:
            shutil.rmtree(tmpdir)


class TestGetDbConnectionSQLAlchemy(unittest.TestCase):

    def test_helper_sqlalchemy_primary(self):
        converter = InformaticaConverter()
        tmpdir = tempfile.mkdtemp()
        try:
            converter.convert_string(MINIMAL_XML, output_dir=tmpdir)
            with open(os.path.join(tmpdir, "helper_functions.py")) as f:
                code = f.read()
            sa_pos = code.index("create_engine")
            pyodbc_pos = code.index("pyodbc")
            assert sa_pos < pyodbc_pos, "SQLAlchemy should be tried before raw pyodbc"
        finally:
            shutil.rmtree(tmpdir)

    def test_helper_engine_cache(self):
        converter = InformaticaConverter()
        tmpdir = tempfile.mkdtemp()
        try:
            converter.convert_string(MINIMAL_XML, output_dir=tmpdir)
            with open(os.path.join(tmpdir, "helper_functions.py")) as f:
                code = f.read()
            assert "_engine_cache" in code
            assert "pool_pre_ping=True" in code
        finally:
            shutil.rmtree(tmpdir)

    def test_helper_safe_close(self):
        converter = InformaticaConverter()
        tmpdir = tempfile.mkdtemp()
        try:
            converter.convert_string(MINIMAL_XML, output_dir=tmpdir)
            with open(os.path.join(tmpdir, "helper_functions.py")) as f:
                code = f.read()
            assert "def _safe_close(" in code
            assert "_safe_close(conn)" in code
        finally:
            shutil.rmtree(tmpdir)

    def test_helper_resolve_env_in_db(self):
        converter = InformaticaConverter()
        tmpdir = tempfile.mkdtemp()
        try:
            converter.convert_string(MINIMAL_XML, output_dir=tmpdir)
            with open(os.path.join(tmpdir, "helper_functions.py")) as f:
                code = f.read()
            assert "resolve_env(" in code
        finally:
            shutil.rmtree(tmpdir)


class TestLookupFuncImpl(unittest.TestCase):

    def test_helper_lookup_func_full_impl(self):
        converter = InformaticaConverter()
        tmpdir = tempfile.mkdtemp()
        try:
            converter.convert_string(MINIMAL_XML, output_dir=tmpdir)
            with open(os.path.join(tmpdir, "helper_functions.py")) as f:
                code = f.read()
            assert "_lookup_cache" in code
            assert "def lookup_func(" in code
            assert "config=None" in code
            assert "read_from_db" in code.split("def lookup_func")[1]
        finally:
            shutil.rmtree(tmpdir)


class TestNullSafeConcat(unittest.TestCase):

    def test_concat_fillna(self):
        result = convert_expression_vectorized("A || B", "df")
        assert ".fillna('')" in result, f"Concat should use fillna, got: {result}"
        assert ".astype(str)" in result

    def test_concat_literal_no_fillna(self):
        result = convert_expression_vectorized("A || '-' || B", "df")
        assert "'-'" in result
        parts = result.split(" + ")
        for part in parts:
            if part.strip().startswith("'") and part.strip().endswith("'"):
                assert ".fillna" not in part
            else:
                assert ".fillna('')" in part

    def test_concat_three_fields_all_fillna(self):
        result = convert_expression_vectorized("X || Y || Z", "df")
        assert result.count(".fillna('')") == 3


class TestPMVariableHandling(unittest.TestCase):

    PM_VAR_XML = '''<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE POWERMART SYSTEM "powrmart.dtd">
<POWERMART CREATION_DATE="01/01/2025" REPOSITORY_VERSION="1">
<REPOSITORY NAME="repo" VERSION="1" CODEPAGE="UTF-8" DATABASETYPE="Oracle">
<FOLDER NAME="TEST_FOLDER" OWNER="admin">
  <SOURCE NAME="SRC_PM" DATABASETYPE="Microsoft SQL Server" DBDNAME="TestDB" OWNERNAME="dbo">
    <SOURCEFIELD NAME="ID" DATATYPE="integer" PRECISION="10" SCALE="0" NULLABLE="NOTNULL" KEYTYPE="PRIMARY KEY" FIELDNUMBER="1"/>
  </SOURCE>
  <TARGET NAME="TGT_PM" DATABASETYPE="Microsoft SQL Server">
    <TARGETFIELD NAME="ID" DATATYPE="integer" PRECISION="10" SCALE="0" NULLABLE="NOTNULL" KEYTYPE="PRIMARY KEY" FIELDNUMBER="1"/>
  </TARGET>
  <MAPPING NAME="m_pm_vars" ISVALID="YES">
    <TRANSFORMATION NAME="SQ_SRC_PM" TYPE="Source Qualifier" REUSABLE="NO">
      <TRANSFORMFIELD NAME="ID" DATATYPE="integer" PORTTYPE="INPUT/OUTPUT" PRECISION="10" SCALE="0"/>
      <TABLEATTRIBUTE NAME="Sql Query" VALUE="SELECT ID FROM dbo.SRC_PM WHERE mapping_name = &apos;$PMMappingName&apos;"/>
    </TRANSFORMATION>
    <INSTANCE NAME="SQ_SRC_PM" TRANSFORMATION_NAME="SQ_SRC_PM" TYPE="Source Qualifier"/>
    <INSTANCE NAME="SRC_PM" TRANSFORMATION_NAME="SRC_PM" TYPE="Source Definition"/>
    <INSTANCE NAME="TGT_PM" TRANSFORMATION_NAME="TGT_PM" TYPE="Target Definition"/>
    <CONNECTOR FROMINSTANCE="SRC_PM" FROMFIELD="ID" TOINSTANCE="SQ_SRC_PM" TOFIELD="ID" FROMINSTANCETYPE="Source Definition" TOINSTANCETYPE="Source Qualifier"/>
    <CONNECTOR FROMINSTANCE="SQ_SRC_PM" FROMFIELD="ID" TOINSTANCE="TGT_PM" TOFIELD="ID" FROMINSTANCETYPE="Source Qualifier" TOINSTANCETYPE="Target Definition"/>
  </MAPPING>
  <CONFIG NAME="default_session_config"/>
  <WORKFLOW NAME="wf_pm_vars" ISVALID="YES">
    <SESSION NAME="s_pm_vars" ISVALID="YES" MAPPINGNAME="m_pm_vars"/>
  </WORKFLOW>
</FOLDER>
</REPOSITORY>
</POWERMART>'''

    def test_pm_variable_resolved_in_sql(self):
        converter = InformaticaConverter()
        tmpdir = tempfile.mkdtemp()
        try:
            converter.convert_string(self.PM_VAR_XML, output_dir=tmpdir)
            for fn in os.listdir(tmpdir):
                if fn.startswith("mapping_") and fn.endswith(".py"):
                    with open(os.path.join(tmpdir, fn)) as f:
                        code = f.read()
                    if "$PMMappingName" in code:
                        assert "resolve_builtin_variable" in code, \
                            "SQL with $PMMappingName should call resolve_builtin_variable"
                        assert "mapping_name='m_pm_vars'" in code, \
                            "resolve_builtin_variable should receive actual mapping name"
                        break
        finally:
            shutil.rmtree(tmpdir)


class TestExecuteSqlAlchemy(unittest.TestCase):

    def test_execute_sql_handles_sqlalchemy(self):
        converter = InformaticaConverter()
        tmpdir = tempfile.mkdtemp()
        try:
            converter.convert_string(MINIMAL_XML, output_dir=tmpdir)
            with open(os.path.join(tmpdir, "helper_functions.py")) as f:
                code = f.read()
            exec_block = code.split("def execute_sql(")[1]
            assert "text(sql)" in exec_block
            assert "dialect" in exec_block, "Should check for dialect attribute to detect SQLAlchemy"
        finally:
            shutil.rmtree(tmpdir)


class TestImportRe(unittest.TestCase):

    def test_helper_imports_re(self):
        converter = InformaticaConverter()
        tmpdir = tempfile.mkdtemp()
        try:
            converter.convert_string(MINIMAL_XML, output_dir=tmpdir)
            with open(os.path.join(tmpdir, "helper_functions.py")) as f:
                code = f.read()
            assert "import re" in code
        finally:
            shutil.rmtree(tmpdir)


class TestNotFunctionCallForm(unittest.TestCase):

    def test_not_without_space_isnull(self):
        result = convert_expression_vectorized("NOT(ISNULL(Postal_Code))")
        assert "~" in result
        assert "isna" in result
        assert "NOT(" not in result

    def test_not_with_space_isnull(self):
        result = convert_expression_vectorized("NOT ISNULL(Postal_Code)")
        assert "~" in result
        assert "isna" in result

    def test_not_in_iif_condition(self):
        result = convert_expression_vectorized("IIF(NOT(ISNULL(X)), X, 'default')")
        assert "np.where" in result
        assert "~" in result
        assert "isna" in result

    def test_not_vectorize_condition_no_space(self):
        result = convert_filter_vectorized("NOT(ISNULL(field1))")
        assert "~" in result
        assert "isna" in result
        assert "NOT(" not in result

    def test_not_vectorize_condition_with_space(self):
        result = convert_filter_vectorized("NOT ISNULL(field1)")
        assert "~" in result
        assert "isna" in result


class TestAndOrNotAsFieldNames(unittest.TestCase):

    def test_and_not_treated_as_field(self):
        result = convert_filter_vectorized("A = 1 AND B = 2")
        assert 'df["AND"]' not in result
        assert "&" in result

    def test_or_not_treated_as_field(self):
        result = convert_filter_vectorized("A = 'TRUE' OR B = 'FALSE'")
        assert 'df["OR"]' not in result
        assert "|" in result

    def test_complex_and_or_filter(self):
        expr = "FILTER_FLAG = 'TRUE' OR (FILTER_FLAG='FALSE' AND ACCBALANCE='Y')"
        result = convert_filter_vectorized(expr)
        assert 'df["AND"]' not in result
        assert 'df["OR"]' not in result
        assert "&" in result
        assert "|" in result

    def test_nested_and_in_iif(self):
        expr = "IIF(UPPER(X) = 'A' AND UPPER(Y) = 'B', 1, 0)"
        result = convert_expression_vectorized(expr)
        assert "np.where" in result
        assert 'df["AND"]' not in result
        assert "&" in result

    def test_and_or_in_vectorize_simple(self):
        result = convert_filter_vectorized("(X = 1 AND Y = 2)")
        assert 'df["AND"]' not in result
        assert "&" in result


class TestPMBuiltinVariableInExpression(unittest.TestCase):

    def test_pm_mapping_name_standalone(self):
        result = convert_expression_vectorized("$PMMappingName")
        assert "resolve_builtin_variable" in result
        assert "PMMappingName" in result
        assert '$df[' not in result

    def test_pm_in_concat(self):
        result = convert_expression_vectorized("'prefix_' || $PMSessionName || '_suffix'")
        assert "resolve_builtin_variable" in result
        assert "PMSessionName" in result
        assert '$df[' not in result

    def test_pm_variable_not_mangled(self):
        result = convert_expression_vectorized("IIF($PMMappingName = 'test', 1, 0)")
        assert "resolve_builtin_variable" in result
        assert '$df[' not in result


class TestToCharParenthesization(unittest.TestCase):

    def test_to_char_with_arithmetic(self):
        result = convert_expression_vectorized("TO_CHAR(TO_INTEGER(x) - 1)")
        assert ".astype(str)" in result
        assert result.count("(") >= result.count(")")
        assert "- 1.astype(str)" not in result
        assert "- 1).astype(str)" in result

    def test_to_char_simple_field(self):
        result = convert_expression_vectorized("TO_CHAR(x)")
        assert ".astype(str)" in result

    def test_to_char_with_addition(self):
        result = convert_expression_vectorized("TO_CHAR(x + y)")
        assert "- 1.astype" not in result or "+ " not in result
        if " + " in result:
            assert ").astype(str)" in result


class TestIifFieldEqualsNumeric(unittest.TestCase):

    def test_iif_field_equals_zero(self):
        result = convert_expression_vectorized("IIF(DeletedIndicator=0,'N','Y')")
        assert "np.where" in result
        assert "==" in result
        assert 'DeletedIndicator' in result.replace('"', '')
        assert "| (" not in result

    def test_iif_field_equals_string(self):
        result = convert_expression_vectorized("IIF(Status='A','Active','Inactive')")
        assert "np.where" in result
        assert "==" in result


class TestFixedWidthPhysicalLength(unittest.TestCase):

    def test_field_def_has_physical_length(self):
        from informatica_python.models import FieldDef
        fld = FieldDef(name="test", datatype="string", physical_length=20, offset=5)
        assert fld.physical_length == 20
        assert fld.offset == 5

    def test_fixed_width_xml(self):
        xml = '''<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE POWERMART SYSTEM "powrmart.dtd">
<POWERMART CREATION_DATE="01/01/2025" REPOSITORY_VERSION="1">
<REPOSITORY NAME="repo" VERSION="1" CODEPAGE="UTF-8" DATABASETYPE="Oracle">
<FOLDER NAME="TEST_FOLDER" OWNER="admin">
  <SOURCE NAME="SRC_FW" DATABASETYPE="Flat File" DBDNAME="SRC_FW">
    <FLATFILE ISFIXEDWIDTH="YES" PADBYTES="NO"/>
    <SOURCEFIELD NAME="FIELD1" DATATYPE="string" PRECISION="10" SCALE="0" FIELDNUMBER="1" PHYSICALLENGTH="15" OFFSET="0"/>
    <SOURCEFIELD NAME="FIELD2" DATATYPE="string" PRECISION="20" SCALE="0" FIELDNUMBER="2" PHYSICALLENGTH="25" OFFSET="15"/>
  </SOURCE>
  <TARGET NAME="TGT_FW" DATABASETYPE="Flat File">
    <TARGETFIELD NAME="FIELD1" DATATYPE="string" PRECISION="10" SCALE="0" FIELDNUMBER="1"/>
    <TARGETFIELD NAME="FIELD2" DATATYPE="string" PRECISION="20" SCALE="0" FIELDNUMBER="2"/>
  </TARGET>
  <MAPPING NAME="m_test_fw" ISVALID="YES">
    <TRANSFORMATION NAME="SQ_SRC_FW" TYPE="Source Qualifier" REUSABLE="NO">
      <TRANSFORMFIELD NAME="FIELD1" DATATYPE="string" PRECISION="10" PORTTYPE="INPUT/OUTPUT"/>
      <TRANSFORMFIELD NAME="FIELD2" DATATYPE="string" PRECISION="20" PORTTYPE="INPUT/OUTPUT"/>
      <TABLEATTRIBUTE NAME="Sql Query" VALUE=""/>
      <TABLEATTRIBUTE NAME="User Defined Join" VALUE=""/>
      <TABLEATTRIBUTE NAME="Source Filter" VALUE=""/>
    </TRANSFORMATION>
    <CONNECTOR FROMINSTANCE="SQ_SRC_FW" FROMFIELD="FIELD1" TOINSTANCE="TGT_FW" TOFIELD="FIELD1"/>
    <CONNECTOR FROMINSTANCE="SQ_SRC_FW" FROMFIELD="FIELD2" TOINSTANCE="TGT_FW" TOFIELD="FIELD2"/>
    <INSTANCE NAME="SQ_SRC_FW" TRANSFORMATION_NAME="SQ_SRC_FW" TYPE="Source Qualifier">
      <ASSOCIATED_SOURCE_INSTANCE NAME="SRC_FW"/>
    </INSTANCE>
    <INSTANCE NAME="SRC_FW" TRANSFORMATION_NAME="SRC_FW" TYPE="Source Definition"/>
    <INSTANCE NAME="TGT_FW" TRANSFORMATION_NAME="TGT_FW" TYPE="Target Definition"/>
  </MAPPING>
  <SESSION NAME="s_test_fw" MAPPINGNAME="m_test_fw" ISVALID="YES">
    <SESSTRANSFORMATIONINST TRANSFORMATIONNAME="SQ_SRC_FW" SINSTANCENAME="SQ_SRC_FW"/>
    <CONFIGREFERENCE REFOBJECTNAME="default_session_config" TYPE="Session Config"/>
  </SESSION>
  <WORKFLOW NAME="wf_test_fw" ISVALID="YES">
    <TASKINSTANCE NAME="s_test_fw" TASKNAME="s_test_fw" TASKTYPE="Session"/>
  </WORKFLOW>
</FOLDER>
</REPOSITORY>
</POWERMART>'''
        converter = InformaticaConverter()
        tmpdir = tempfile.mkdtemp()
        try:
            converter.convert_string(xml, output_dir=tmpdir)
            mapping_file = os.path.join(tmpdir, "mapping_m_test_fw.py")
            assert os.path.exists(mapping_file), "mapping file not created"
            with open(mapping_file) as f:
                code = f.read()
            assert "read_fwf" in code
            assert "15" in code
            assert "25" in code
        finally:
            shutil.rmtree(tmpdir)


class TestConcatWithLtrimRtrim(unittest.TestCase):

    def test_concat_ltrim_rtrim(self):
        expr = "'PER_' || ltrim(rtrim(X)) || '_suffix'"
        result = convert_expression_vectorized(expr)
        assert "+" in result
        assert "||" not in result
        assert "lstrip" in result or "strip" in result
        assert "rstrip" in result or "strip" in result

    def test_concat_simple_fields(self):
        expr = "A || '_' || B"
        result = convert_expression_vectorized(expr)
        assert "+" in result
        assert "||" not in result


class TestRouterGroupElements(unittest.TestCase):

    ROUTER_GROUP_XML = '''<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE POWERMART SYSTEM "powrmart.dtd">
<POWERMART CREATION_DATE="01/01/2025" REPOSITORY_VERSION="1">
<REPOSITORY NAME="repo" VERSION="1" CODEPAGE="UTF-8" DATABASETYPE="Oracle">
<FOLDER NAME="TEST" OWNER="admin">
  <SOURCE NAME="SRC" DATABASETYPE="Flat File" DBDNAME="SRC">
    <FLATFILE DELIMITEDBY="COMMA" HEADERROWPRESENT="YES" PADBYTES="NO" ROWDELIMITER="\\n"/>
    <SOURCEFIELD NAME="ID" DATATYPE="integer" PRECISION="10" SCALE="0" NULLABLE="NOTNULL" KEYTYPE="PRIMARY KEY" FIELDNUMBER="1"/>
    <SOURCEFIELD NAME="Party_Type" DATATYPE="string" PRECISION="10" SCALE="0" NULLABLE="NULL" KEYTYPE="NOT A KEY" FIELDNUMBER="2"/>
    <SOURCEFIELD NAME="Attrib_Name" DATATYPE="string" PRECISION="50" SCALE="0" NULLABLE="NULL" KEYTYPE="NOT A KEY" FIELDNUMBER="3"/>
  </SOURCE>
  <TARGET NAME="TGT_PER_TYPE" DATABASETYPE="Flat File">
    <TARGETFIELD NAME="ID" DATATYPE="integer" PRECISION="10" SCALE="0" NULLABLE="NULL" KEYTYPE="NOT A KEY" FIELDNUMBER="1"/>
  </TARGET>
  <TARGET NAME="TGT_PER_VALUE" DATABASETYPE="Flat File">
    <TARGETFIELD NAME="ID" DATATYPE="integer" PRECISION="10" SCALE="0" NULLABLE="NULL" KEYTYPE="NOT A KEY" FIELDNUMBER="1"/>
  </TARGET>
  <TARGET NAME="TGT_ORG_TYPE" DATABASETYPE="Flat File">
    <TARGETFIELD NAME="ID" DATATYPE="integer" PRECISION="10" SCALE="0" NULLABLE="NULL" KEYTYPE="NOT A KEY" FIELDNUMBER="1"/>
  </TARGET>
  <TARGET NAME="TGT_DEFAULT" DATABASETYPE="Flat File">
    <TARGETFIELD NAME="ID" DATATYPE="integer" PRECISION="10" SCALE="0" NULLABLE="NULL" KEYTYPE="NOT A KEY" FIELDNUMBER="1"/>
  </TARGET>
  <MAPPING NAME="m_router_groups_test" ISVALID="YES">
    <TRANSFORMATION NAME="SQ_SRC" TYPE="Source Qualifier" REUSABLE="NO">
      <TRANSFORMFIELD NAME="ID" DATATYPE="integer" PRECISION="10" SCALE="0" PORTTYPE="OUTPUT"/>
      <TRANSFORMFIELD NAME="Party_Type" DATATYPE="string" PRECISION="10" SCALE="0" PORTTYPE="OUTPUT"/>
      <TRANSFORMFIELD NAME="Attrib_Name" DATATYPE="string" PRECISION="50" SCALE="0" PORTTYPE="OUTPUT"/>
    </TRANSFORMATION>
    <TRANSFORMATION NAME="RTR_SPLIT" TYPE="Router" REUSABLE="NO">
      <TRANSFORMFIELD NAME="ID" DATATYPE="integer" PRECISION="10" SCALE="0" PORTTYPE="INPUT/OUTPUT"/>
      <TRANSFORMFIELD NAME="Party_Type" DATATYPE="string" PRECISION="10" SCALE="0" PORTTYPE="INPUT/OUTPUT"/>
      <TRANSFORMFIELD NAME="Attrib_Name" DATATYPE="string" PRECISION="50" SCALE="0" PORTTYPE="INPUT/OUTPUT"/>
      <GROUP DESCRIPTION="" NAME="INPUT" ORDER="1" TYPE="INPUT"/>
      <GROUP DESCRIPTION="" EXPRESSION="Party_Type = &apos;PER&apos; AND Attrib_Name = &apos;RESTRICTION_TYPE&apos;" NAME="Rest_Type_PER" ORDER="2" TYPE="OUTPUT"/>
      <GROUP DESCRIPTION="" EXPRESSION="Party_Type = &apos;PER&apos; AND Attrib_Name = &apos;RESTRICTION_VALUE&apos;" NAME="Rest_Value_PER" ORDER="3" TYPE="OUTPUT"/>
      <GROUP DESCRIPTION="" EXPRESSION="Party_Type = &apos;ORG&apos; AND Attrib_Name = &apos;RESTRICTION_TYPE&apos;" NAME="Rest_Type_ORG" ORDER="4" TYPE="OUTPUT"/>
      <GROUP DESCRIPTION="" NAME="DEFAULT1" ORDER="5" TYPE="OUTPUT/DEFAULT"/>
    </TRANSFORMATION>
    <INSTANCE NAME="SRC" TYPE="Source Definition" TRANSFORMATION_NAME="SRC"/>
    <INSTANCE NAME="SQ_SRC" TYPE="Source Qualifier" TRANSFORMATION_NAME="SQ_SRC"/>
    <INSTANCE NAME="RTR_SPLIT" TYPE="Router" TRANSFORMATION_NAME="RTR_SPLIT"/>
    <INSTANCE NAME="TGT_PER_TYPE" TYPE="Target Definition" TRANSFORMATION_NAME="TGT_PER_TYPE"/>
    <INSTANCE NAME="TGT_PER_VALUE" TYPE="Target Definition" TRANSFORMATION_NAME="TGT_PER_VALUE"/>
    <INSTANCE NAME="TGT_ORG_TYPE" TYPE="Target Definition" TRANSFORMATION_NAME="TGT_ORG_TYPE"/>
    <INSTANCE NAME="TGT_DEFAULT" TYPE="Target Definition" TRANSFORMATION_NAME="TGT_DEFAULT"/>
    <CONNECTOR FROMINSTANCE="SRC" FROMFIELD="ID" TOINSTANCE="SQ_SRC" TOFIELD="ID"/>
    <CONNECTOR FROMINSTANCE="SRC" FROMFIELD="Party_Type" TOINSTANCE="SQ_SRC" TOFIELD="Party_Type"/>
    <CONNECTOR FROMINSTANCE="SRC" FROMFIELD="Attrib_Name" TOINSTANCE="SQ_SRC" TOFIELD="Attrib_Name"/>
    <CONNECTOR FROMINSTANCE="SQ_SRC" FROMFIELD="ID" TOINSTANCE="RTR_SPLIT" TOFIELD="ID"/>
    <CONNECTOR FROMINSTANCE="SQ_SRC" FROMFIELD="Party_Type" TOINSTANCE="RTR_SPLIT" TOFIELD="Party_Type"/>
    <CONNECTOR FROMINSTANCE="SQ_SRC" FROMFIELD="Attrib_Name" TOINSTANCE="RTR_SPLIT" TOFIELD="Attrib_Name"/>
    <CONNECTOR FROMINSTANCE="RTR_SPLIT" FROMINSTANCEGROUP="Rest_Type_PER" FROMFIELD="ID" TOINSTANCE="TGT_PER_TYPE" TOFIELD="ID"/>
    <CONNECTOR FROMINSTANCE="RTR_SPLIT" FROMINSTANCEGROUP="Rest_Value_PER" FROMFIELD="ID" TOINSTANCE="TGT_PER_VALUE" TOFIELD="ID"/>
    <CONNECTOR FROMINSTANCE="RTR_SPLIT" FROMINSTANCEGROUP="Rest_Type_ORG" FROMFIELD="ID" TOINSTANCE="TGT_ORG_TYPE" TOFIELD="ID"/>
    <CONNECTOR FROMINSTANCE="RTR_SPLIT" FROMINSTANCEGROUP="DEFAULT1" FROMFIELD="ID" TOINSTANCE="TGT_DEFAULT" TOFIELD="ID"/>
  </MAPPING>
  <CONFIG NAME="default_session_config"/>
  <WORKFLOW NAME="wf_router_groups_test" ISVALID="YES">
    <TASK NAME="Start" REUSABLE="NO" TYPE="Start"/>
    <SESSION NAME="s_m_router_groups_test" ISVALID="YES" REUSABLE="NO" MAPPINGNAME="m_router_groups_test">
      <CONFIGREFERENCE REFOBJECTNAME="default_session_config" TYPE="Session config"/>
    </SESSION>
    <TASKINSTANCE NAME="Start" TASKNAME="Start" TASKTYPE="Start"/>
    <TASKINSTANCE NAME="s_m_router_groups_test" TASKNAME="s_m_router_groups_test" TASKTYPE="Session"/>
    <WORKFLOWLINK FROMTASK="Start" TOTASK="s_m_router_groups_test"/>
  </WORKFLOW>
</FOLDER>
</REPOSITORY>
</POWERMART>'''

    def test_router_generates_all_named_groups(self):
        converter = InformaticaConverter()
        tmpdir = tempfile.mkdtemp()
        try:
            converter.convert_string(self.ROUTER_GROUP_XML, output_dir=tmpdir)
            for fn in os.listdir(tmpdir):
                if fn.startswith("mapping_") and fn.endswith(".py"):
                    with open(os.path.join(tmpdir, fn)) as f:
                        code = f.read()
                    assert "Rest_Type_PER" in code, "Should have Rest_Type_PER group"
                    assert "Rest_Value_PER" in code, "Should have Rest_Value_PER group"
                    assert "Rest_Type_ORG" in code, "Should have Rest_Type_ORG group"
                    assert "_router_mask_" in code, "Should have router masks"
                    assert "Default group" in code, "Should have default group"
                    assert "_router_default_mask" in code, "Should have default mask"
                    break
        finally:
            shutil.rmtree(tmpdir)

    def test_router_group_creates_separate_dataframes(self):
        converter = InformaticaConverter()
        tmpdir = tempfile.mkdtemp()
        try:
            converter.convert_string(self.ROUTER_GROUP_XML, output_dir=tmpdir)
            for fn in os.listdir(tmpdir):
                if fn.startswith("mapping_") and fn.endswith(".py"):
                    with open(os.path.join(tmpdir, fn)) as f:
                        code = f.read()
                    assert "df_rtr_split_rest_type_per" in code, "Should create df for Rest_Type_PER"
                    assert "df_rtr_split_rest_value_per" in code, "Should create df for Rest_Value_PER"
                    assert "df_rtr_split_rest_type_org" in code, "Should create df for Rest_Type_ORG"
                    assert ".copy()" in code, "Should copy DataFrames"
                    break
        finally:
            shutil.rmtree(tmpdir)

    def test_router_group_connector_resolution(self):
        converter = InformaticaConverter()
        tmpdir = tempfile.mkdtemp()
        try:
            converter.convert_string(self.ROUTER_GROUP_XML, output_dir=tmpdir)
            for fn in os.listdir(tmpdir):
                if fn.startswith("mapping_") and fn.endswith(".py"):
                    with open(os.path.join(tmpdir, fn)) as f:
                        code = f.read()
                    assert "df_rtr_split_rest_type_per" in code
                    assert "df_rtr_split_rest_value_per" in code
                    break
        finally:
            shutil.rmtree(tmpdir)

    def test_router_default_excludes_all_groups(self):
        converter = InformaticaConverter()
        tmpdir = tempfile.mkdtemp()
        try:
            converter.convert_string(self.ROUTER_GROUP_XML, output_dir=tmpdir)
            for fn in os.listdir(tmpdir):
                if fn.startswith("mapping_") and fn.endswith(".py"):
                    with open(os.path.join(tmpdir, fn)) as f:
                        code = f.read()
                    assert "~_router_mask_rtr_split_0" in code, "Default should negate first group mask"
                    assert "~_router_mask_rtr_split_1" in code, "Default should negate second group mask"
                    assert "~_router_mask_rtr_split_2" in code, "Default should negate third group mask"
                    break
        finally:
            shutil.rmtree(tmpdir)


class TestRouterGroupParsing(unittest.TestCase):

    def test_group_expression_parsed(self):
        xml = '''<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE POWERMART SYSTEM "powrmart.dtd">
<POWERMART CREATION_DATE="01/01/2025" REPOSITORY_VERSION="1">
<REPOSITORY NAME="repo" VERSION="1" CODEPAGE="UTF-8" DATABASETYPE="Oracle">
<FOLDER NAME="TEST" OWNER="admin">
  <MAPPING NAME="m_test" ISVALID="YES">
    <TRANSFORMATION NAME="RTR" TYPE="Router" REUSABLE="NO">
      <TRANSFORMFIELD NAME="X" DATATYPE="string" PRECISION="10" SCALE="0" PORTTYPE="INPUT/OUTPUT"/>
      <GROUP NAME="INPUT" ORDER="1" TYPE="INPUT"/>
      <GROUP NAME="GRP_A" ORDER="2" TYPE="OUTPUT" EXPRESSION="X = &apos;A&apos;"/>
      <GROUP NAME="DEFAULT1" ORDER="3" TYPE="OUTPUT/DEFAULT"/>
    </TRANSFORMATION>
  </MAPPING>
</FOLDER>
</REPOSITORY>
</POWERMART>'''
        from informatica_python.parser import InformaticaParser
        parser = InformaticaParser()
        pm = parser.parse_string(xml)
        mapping = pm.repositories[0].folders[0].mappings[0]
        rtr = mapping.transformations[0]
        assert len(rtr.groups) == 3
        grp_a = [g for g in rtr.groups if g.name == "GRP_A"][0]
        assert "X = " in grp_a.expression
        assert grp_a.type == "OUTPUT"
        default_g = [g for g in rtr.groups if g.name == "DEFAULT1"][0]
        assert "DEFAULT" in default_g.type.upper()

    def test_connector_group_attributes_parsed(self):
        xml = '''<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE POWERMART SYSTEM "powrmart.dtd">
<POWERMART CREATION_DATE="01/01/2025" REPOSITORY_VERSION="1">
<REPOSITORY NAME="repo" VERSION="1" CODEPAGE="UTF-8" DATABASETYPE="Oracle">
<FOLDER NAME="TEST" OWNER="admin">
  <MAPPING NAME="m_test" ISVALID="YES">
    <TRANSFORMATION NAME="RTR" TYPE="Router" REUSABLE="NO">
      <TRANSFORMFIELD NAME="X" DATATYPE="string" PRECISION="10" SCALE="0" PORTTYPE="INPUT/OUTPUT"/>
    </TRANSFORMATION>
    <CONNECTOR FROMINSTANCE="RTR" FROMINSTANCEGROUP="GRP_A" FROMFIELD="X" TOINSTANCE="TGT" TOFIELD="X"/>
  </MAPPING>
</FOLDER>
</REPOSITORY>
</POWERMART>'''
        from informatica_python.parser import InformaticaParser
        parser = InformaticaParser()
        pm = parser.parse_string(xml)
        mapping = pm.repositories[0].folders[0].mappings[0]
        conn = mapping.connectors[0]
        assert conn.from_instance_group == "GRP_A"


class TestNotInsideIIF(unittest.TestCase):

    def test_not_isnull_in_iif(self):
        expr = "IIF(NOT(ISNULL(STATUS)), 'HAS_STATUS', 'NO_STATUS')"
        result = convert_expression_vectorized(expr)
        assert "isna" in result or "isnull" in result
        assert "~" in result
        assert "np.where" in result

    def test_not_isnull_standalone(self):
        from informatica_python.utils.expression_converter import convert_filter_vectorized
        result = convert_filter_vectorized("NOT(ISNULL(FIELD1))", "df")
        assert "~" in result
        assert "isna" in result

    def test_not_equals_in_iif(self):
        expr = "IIF(NOT(STATUS = 'ACTIVE'), 'INACTIVE', 'ACTIVE')"
        result = convert_expression_vectorized(expr)
        assert "np.where" in result
        assert "~" in result


class TestLookupSqlOverride(unittest.TestCase):

    LOOKUP_SQL_XML = '''<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE POWERMART SYSTEM "powrmart.dtd">
<POWERMART CREATION_DATE="01/01/2025" REPOSITORY_VERSION="1">
<REPOSITORY NAME="repo" VERSION="1" CODEPAGE="UTF-8" DATABASETYPE="Oracle">
<FOLDER NAME="TEST" OWNER="admin">
  <SOURCE NAME="SRC" DATABASETYPE="Flat File" DBDNAME="SRC">
    <FLATFILE DELIMITEDBY="COMMA" HEADERROWPRESENT="YES" PADBYTES="NO" ROWDELIMITER="\\n"/>
    <SOURCEFIELD NAME="ID" DATATYPE="integer" PRECISION="10" SCALE="0" NULLABLE="NOTNULL" KEYTYPE="PRIMARY KEY" FIELDNUMBER="1"/>
    <SOURCEFIELD NAME="CODE" DATATYPE="string" PRECISION="10" SCALE="0" NULLABLE="NULL" KEYTYPE="NOT A KEY" FIELDNUMBER="2"/>
  </SOURCE>
  <TARGET NAME="TGT" DATABASETYPE="Flat File">
    <TARGETFIELD NAME="ID" DATATYPE="integer" PRECISION="10" SCALE="0" NULLABLE="NULL" KEYTYPE="NOT A KEY" FIELDNUMBER="1"/>
    <TARGETFIELD NAME="DESC" DATATYPE="string" PRECISION="50" SCALE="0" NULLABLE="NULL" KEYTYPE="NOT A KEY" FIELDNUMBER="2"/>
  </TARGET>
  <MAPPING NAME="m_lookup_sql_test" ISVALID="YES">
    <TRANSFORMATION NAME="SQ_SRC" TYPE="Source Qualifier" REUSABLE="NO">
      <TRANSFORMFIELD NAME="ID" DATATYPE="integer" PRECISION="10" SCALE="0" PORTTYPE="OUTPUT"/>
      <TRANSFORMFIELD NAME="CODE" DATATYPE="string" PRECISION="10" SCALE="0" PORTTYPE="OUTPUT"/>
    </TRANSFORMATION>
    <TRANSFORMATION NAME="LKP_CODES" TYPE="Lookup Procedure" REUSABLE="NO">
      <TRANSFORMFIELD NAME="CODE_IN" DATATYPE="string" PRECISION="10" SCALE="0" PORTTYPE="INPUT"/>
      <TRANSFORMFIELD NAME="DESC_OUT" DATATYPE="string" PRECISION="50" SCALE="0" PORTTYPE="OUTPUT"/>
      <TABLEATTRIBUTE NAME="Lookup Sql Override" VALUE="SELECT CODE, DESCRIPTION FROM REF_CODES WHERE ACTIVE_FLAG = &apos;Y&apos;"/>
      <TABLEATTRIBUTE NAME="Lookup table name" VALUE="REF_CODES"/>
    </TRANSFORMATION>
    <INSTANCE NAME="SRC" TYPE="Source Definition" TRANSFORMATION_NAME="SRC"/>
    <INSTANCE NAME="SQ_SRC" TYPE="Source Qualifier" TRANSFORMATION_NAME="SQ_SRC"/>
    <INSTANCE NAME="LKP_CODES" TYPE="Lookup Procedure" TRANSFORMATION_NAME="LKP_CODES"/>
    <INSTANCE NAME="TGT" TYPE="Target Definition" TRANSFORMATION_NAME="TGT"/>
    <CONNECTOR FROMINSTANCE="SRC" FROMFIELD="ID" TOINSTANCE="SQ_SRC" TOFIELD="ID"/>
    <CONNECTOR FROMINSTANCE="SRC" FROMFIELD="CODE" TOINSTANCE="SQ_SRC" TOFIELD="CODE"/>
    <CONNECTOR FROMINSTANCE="SQ_SRC" FROMFIELD="ID" TOINSTANCE="LKP_CODES" TOFIELD="CODE_IN"/>
    <CONNECTOR FROMINSTANCE="LKP_CODES" FROMFIELD="DESC_OUT" TOINSTANCE="TGT" TOFIELD="DESC"/>
    <CONNECTOR FROMINSTANCE="SQ_SRC" FROMFIELD="ID" TOINSTANCE="TGT" TOFIELD="ID"/>
  </MAPPING>
  <CONFIG NAME="default_session_config"/>
  <WORKFLOW NAME="wf_lookup_sql_test" ISVALID="YES">
    <TASK NAME="Start" REUSABLE="NO" TYPE="Start"/>
    <SESSION NAME="s_m_lookup_sql_test" ISVALID="YES" REUSABLE="NO" MAPPINGNAME="m_lookup_sql_test">
      <CONFIGREFERENCE REFOBJECTNAME="default_session_config" TYPE="Session config"/>
    </SESSION>
    <TASKINSTANCE NAME="Start" TASKNAME="Start" TASKTYPE="Start"/>
    <TASKINSTANCE NAME="s_m_lookup_sql_test" TASKNAME="s_m_lookup_sql_test" TASKTYPE="Session"/>
    <WORKFLOWLINK FROMTASK="Start" TOTASK="s_m_lookup_sql_test"/>
  </WORKFLOW>
</FOLDER>
</REPOSITORY>
</POWERMART>'''

    def test_lookup_sql_override_applied(self):
        converter = InformaticaConverter()
        tmpdir = tempfile.mkdtemp()
        try:
            converter.convert_string(self.LOOKUP_SQL_XML, output_dir=tmpdir)
            for fn in os.listdir(tmpdir):
                if fn.startswith("mapping_") and fn.endswith(".py"):
                    with open(os.path.join(tmpdir, fn)) as f:
                        code = f.read()
                    assert "SELECT CODE, DESCRIPTION FROM REF_CODES" in code, \
                        "Lookup SQL Override should appear in generated code"
                    assert "read_from_db" in code, \
                        "Should use read_from_db with the override SQL"
                    break
        finally:
            shutil.rmtree(tmpdir)

    def test_lookup_sql_in_all_sql_queries(self):
        converter = InformaticaConverter()
        tmpdir = tempfile.mkdtemp()
        try:
            converter.convert_string(self.LOOKUP_SQL_XML, output_dir=tmpdir)
            sql_file = os.path.join(tmpdir, "all_sql_queries.sql")
            if os.path.exists(sql_file):
                with open(sql_file) as f:
                    sql = f.read()
                assert "REF_CODES" in sql, "SQL file should contain lookup SQL"
        finally:
            shutil.rmtree(tmpdir)
