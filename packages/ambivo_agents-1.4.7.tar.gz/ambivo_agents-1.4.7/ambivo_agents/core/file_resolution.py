"""
Universal File Resolution for All Agents
Provides consistent file path resolution based on shared_base_dir configuration
"""

import logging
from pathlib import Path
from typing import List, Optional, Union

from ..config.loader import get_config_section
from .docker_shared import get_shared_manager

logger = logging.getLogger(__name__)


def _is_path_within_allowed_dirs(
    resolved_path: Path, shared_base_dir: str, legacy_fallback_dirs: list = None
) -> bool:
    """Validate that resolved path is within allowed base directories.

    Uses resolve() to follow symlinks and validate the real path is within bounds.
    Rejects paths containing '..' components before resolution as an extra guard.
    """
    # Reject paths with explicit traversal components
    try:
        path_str = str(resolved_path)
        if ".." in path_str.split("/"):
            return False
    except Exception:
        return False

    allowed_bases = [Path(shared_base_dir).resolve(), Path.cwd().resolve()]
    if legacy_fallback_dirs:
        for d in legacy_fallback_dirs:
            allowed_bases.append(Path(d).resolve())
    # resolve() follows symlinks, so the real path is validated
    resolved = resolved_path.resolve()
    return any(resolved.is_relative_to(base) for base in allowed_bases if base.exists())


def resolve_agent_file_path(
    filename: str, agent_type: str = "code", priority_subdirs: Optional[List[str]] = None
) -> Optional[Path]:
    """
    Universal file resolution for all agents using shared_base_dir configuration.

    Args:
        filename: Name or relative path of file to find
        agent_type: Agent type (analytics, media, code, database, scraper, etc.)
        priority_subdirs: Optional list of subdirectories to check first

    Returns:
        Resolved Path object if file exists, None otherwise

    Resolution Priority:
        1. Priority subdirs (if provided)
        2. Agent-specific input directory: {shared_base_dir}/input/{agent_type}/
        3. Agent-specific handoff directory: {shared_base_dir}/handoff/{agent_type}/
        4. Current working directory
        5. Legacy fallback directories from config
        6. Generic shared input: {shared_base_dir}/input/
        7. Generic shared directory: {shared_base_dir}/
    """
    try:
        # Get configuration
        docker_config = get_config_section("docker") or {}
        shared_base_dir = docker_config.get("shared_base_dir", "./docker_shared")
        legacy_fallback_dirs = docker_config.get(
            "legacy_fallback_dirs", ["docker_shared/input", "docker_shared"]
        )

        # Get shared manager
        shared_manager = get_shared_manager(shared_base_dir, legacy_fallback_dirs)

        # If it's already an absolute path and exists, return it (if within allowed dirs)
        if Path(filename).is_absolute() and Path(filename).exists():
            abs_path = Path(filename).resolve()
            if _is_path_within_allowed_dirs(abs_path, shared_base_dir, legacy_fallback_dirs):
                return abs_path

        # Build search locations in priority order
        search_locations = []

        # 1. Priority subdirs (if provided)
        if priority_subdirs:
            for subdir in priority_subdirs:
                base_path = Path(shared_base_dir) / subdir
                search_locations.extend(
                    [
                        base_path / filename,
                        base_path / Path(filename).name,
                    ]
                )

        # 2. Agent-specific input directory (highest standard priority)
        agent_input_path = Path(shared_base_dir) / "input" / agent_type
        search_locations.extend(
            [
                agent_input_path / filename,
                agent_input_path / Path(filename).name,
            ]
        )

        # 3. Agent-specific handoff directory (for workflow handoffs)
        agent_handoff_path = Path(shared_base_dir) / "handoff" / agent_type
        search_locations.extend(
            [
                agent_handoff_path / filename,
                agent_handoff_path / Path(filename).name,
            ]
        )

        # 4. Shared directory (common to all agents)
        shared_path = Path(shared_base_dir) / "shared"
        search_locations.extend(
            [
                shared_path / filename,
                shared_path / Path(filename).name,
            ]
        )

        # 5. Current working directory
        search_locations.extend(
            [
                Path(filename),
                Path(filename).resolve(),
            ]
        )

        # 5. Legacy fallback directories (configurable)
        for legacy_dir in legacy_fallback_dirs:
            legacy_path = Path(legacy_dir)
            search_locations.extend(
                [
                    legacy_path / filename,
                    legacy_path / Path(filename).name,
                ]
            )

        # 6. Generic shared input directory
        shared_input_path = Path(shared_base_dir) / "input"
        search_locations.extend(
            [
                shared_input_path / filename,
                shared_input_path / Path(filename).name,
            ]
        )

        # 7. Generic shared directory (last resort)
        shared_base_path = Path(shared_base_dir)
        search_locations.extend(
            [
                shared_base_path / filename,
                shared_base_path / Path(filename).name,
            ]
        )

        # Search for file in order of priority
        for location in search_locations:
            if location.exists() and location.is_file():
                resolved = location.resolve()
                if _is_path_within_allowed_dirs(resolved, shared_base_dir, legacy_fallback_dirs):
                    return resolved

        return None

    except Exception as e:
        logger.warning(f"File resolution failed for '{filename}': {e}", exc_info=True)
        # Fallback to simple path resolution
        if Path(filename).exists():
            fallback_path = Path(filename).resolve()
            try:
                docker_config = get_config_section("docker") or {}
                fb_shared_base = docker_config.get("shared_base_dir", "./docker_shared")
                fb_legacy = docker_config.get(
                    "legacy_fallback_dirs", ["docker_shared/input", "docker_shared"]
                )
                if _is_path_within_allowed_dirs(fallback_path, fb_shared_base, fb_legacy):
                    return fallback_path
            except Exception as inner_e:
                logger.warning(f"Fallback file resolution also failed: {inner_e}")
        return None


def get_agent_type_from_config(agent_name: str) -> str:
    """
    Get the agent type from configuration for file resolution.

    Args:
        agent_name: Name of the agent (e.g., "AnalyticsAgent", "MediaEditorAgent")

    Returns:
        Agent type string for directory resolution
    """
    # Mapping from agent class names to directory types
    agent_type_mapping = {
        "AnalyticsAgent": "analytics",
        "MediaEditorAgent": "media",
        "CodeExecutorAgent": "code",
        "DatabaseAgent": "database",
        "WebScraperAgent": "scraper",
        "KnowledgeBaseAgent": "code",  # KB uses 'code' subdirs
        "AssistantAgent": "code",  # Assistant uses 'code' subdirs
        "APIAgent": "code",  # API agent uses 'code' subdirs
        "ModeratorAgent": "code",  # Moderator uses 'code' subdirs
        "WebSearchAgent": "code",  # Web search uses 'code' subdirs
        "YouTubeDownloadAgent": "media",  # YouTube uses 'media' subdirs
    }

    return agent_type_mapping.get(agent_name, "code")  # Default to 'code'


def get_agent_specific_subdirs(agent_type: str) -> List[str]:
    """
    Get agent-specific subdirectories from configuration.

    Args:
        agent_type: Agent type (analytics, media, code, etc.)

    Returns:
        List of subdirectories to check for this agent type
    """
    try:
        docker_config = get_config_section("docker") or {}
        agent_subdirs = docker_config.get("agent_subdirs", {})
        return agent_subdirs.get(agent_type, [])
    except Exception as e:
        logger.warning(f"Failed to get agent subdirs for '{agent_type}': {e}")
        return []
