"""Test configuration for AgentMesh."""
