"""
Operation handler protocol for the executor system.

This module defines the protocol that operation handlers must implement.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Protocol

if TYPE_CHECKING:
    from klaude_code.protocol.op import (
        ChangeCompactModelOperation,
        ChangeModelOperation,
        ChangeSubAgentModelOperation,
        ChangeThinkingOperation,
        ClearSessionOperation,
        CloseSessionOperation,
        CompactSessionOperation,
        ContinueAgentOperation,
        ForkAndSwitchSessionOperation,
        GenerateAwaySummaryOperation,
        GetSessionStatsOperation,
        InitAgentOperation,
        InterruptOperation,
        RequestModelOperation,
        RequestSubAgentModelOperation,
        RequestThinkingOperation,
        RunAgentOperation,
        RunBashOperation,
        UserInteractionRespondOperation,
    )


class OperationHandler(Protocol):
    """Protocol defining the interface for handling operations."""

    async def handle_run_agent(self, operation: RunAgentOperation) -> None:
        """Handle a run agent operation."""
        ...

    async def handle_run_bash(self, operation: RunBashOperation) -> None:
        """Handle a bash-mode command execution operation."""
        ...

    async def handle_continue_agent(self, operation: ContinueAgentOperation) -> None:
        """Handle a continue agent operation (resume without adding user message)."""
        ...

    async def handle_compact_session(self, operation: CompactSessionOperation) -> None:
        """Handle a compact session operation."""
        ...

    async def handle_change_model(self, operation: ChangeModelOperation) -> None:
        """Handle a change model operation."""
        ...

    async def handle_change_compact_model(self, operation: ChangeCompactModelOperation) -> None:
        """Handle a change compact model operation."""
        ...

    async def handle_change_thinking(self, operation: ChangeThinkingOperation) -> None:
        """Handle a change thinking operation."""
        ...

    async def handle_change_sub_agent_model(self, operation: ChangeSubAgentModelOperation) -> None:
        """Handle a change sub-agent model operation."""
        ...

    async def handle_request_model(self, operation: RequestModelOperation) -> None:
        """Handle an interactive request model operation."""
        ...

    async def handle_request_thinking(self, operation: RequestThinkingOperation) -> None:
        """Handle an interactive request thinking operation."""
        ...

    async def handle_request_sub_agent_model(self, operation: RequestSubAgentModelOperation) -> None:
        """Handle an interactive request sub-agent model operation."""
        ...

    async def handle_get_session_stats(self, operation: GetSessionStatsOperation) -> None:
        """Handle a get session stats operation."""
        ...

    async def handle_clear_session(self, operation: ClearSessionOperation) -> None:
        """Handle a clear session operation."""
        ...

    async def handle_fork_and_switch_session(self, operation: ForkAndSwitchSessionOperation) -> None:
        """Handle a fork-and-switch session operation."""
        ...

    async def handle_interrupt(self, operation: InterruptOperation) -> None:
        """Handle an interrupt operation."""
        ...

    async def handle_close_session(self, operation: CloseSessionOperation) -> None:
        """Handle a close session operation."""
        ...

    async def handle_user_interaction_respond(self, operation: UserInteractionRespondOperation) -> None:
        """Handle a user interaction response operation."""
        ...

    async def handle_init_agent(self, operation: InitAgentOperation) -> None:
        """Handle an init agent operation."""
        ...

    async def handle_generate_away_summary(self, operation: GenerateAwaySummaryOperation) -> None:
        """Handle a generate-away-summary operation (while-you-were-away recap)."""
        ...
