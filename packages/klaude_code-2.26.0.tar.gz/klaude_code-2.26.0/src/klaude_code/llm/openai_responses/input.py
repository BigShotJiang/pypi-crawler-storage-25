# pyright: reportReturnType=false
# pyright: reportArgumentType=false
# pyright: reportAssignmentType=false

from typing import Any, cast

from openai.types import responses

from klaude_code.llm.image import image_file_to_data_url, image_url_to_request_url
from klaude_code.llm.input_common import (
    DeveloperAttachment,
    attach_developer_messages,
    merge_attachment_text,
    split_thinking_parts,
)
from klaude_code.prompts.messages import EMPTY_TOOL_OUTPUT_MESSAGE
from klaude_code.protocol import llm_param, message


def _image_to_url(image: message.ImageURLPart | message.ImageFilePart) -> str | None:
    if isinstance(image, message.ImageFilePart):
        return image_file_to_data_url(image)
    return image_url_to_request_url(image)


def _build_user_content_parts(
    user: message.UserMessage,
    attachment: DeveloperAttachment,
) -> list[responses.ResponseInputContentParam]:
    parts: list[responses.ResponseInputContentParam] = []
    if attachment.prefix_text:
        parts.append(cast(responses.ResponseInputContentParam, {"type": "input_text", "text": attachment.prefix_text}))
    for part in user.parts:
        if isinstance(part, message.TextPart):
            parts.append(cast(responses.ResponseInputContentParam, {"type": "input_text", "text": part.text}))
        elif isinstance(part, (message.ImageURLPart, message.ImageFilePart)):
            url = _image_to_url(part)
            if url is not None:
                parts.append(
                    cast(
                        responses.ResponseInputContentParam,
                        {"type": "input_image", "detail": "auto", "image_url": url},
                    )
                )
    if attachment.text:
        parts.append(cast(responses.ResponseInputContentParam, {"type": "input_text", "text": attachment.text}))
    for image in attachment.images:
        if (url := _image_to_url(image)) is not None:
            parts.append(
                cast(
                    responses.ResponseInputContentParam,
                    {"type": "input_image", "detail": "auto", "image_url": url},
                )
            )
    if not parts:
        parts.append(cast(responses.ResponseInputContentParam, {"type": "input_text", "text": ""}))
    return parts


def _build_tool_result_item(
    tool: message.ToolResultMessage,
    attachment: DeveloperAttachment,
    *,
    function_call_output_string: bool = False,
    include_input_status: bool = False,
) -> responses.ResponseInputItemParam:
    text_output = merge_attachment_text(
        tool.output_text or EMPTY_TOOL_OUTPUT_MESSAGE,
        attachment.text,
        prefix_text=attachment.prefix_text,
    )
    images: list[message.ImageURLPart | message.ImageFilePart] = [
        part for part in tool.parts if isinstance(part, (message.ImageURLPart, message.ImageFilePart))
    ]
    images.extend(attachment.images)

    item: dict[str, Any] = {"type": "function_call_output", "call_id": tool.call_id}
    if function_call_output_string:
        item["output"] = text_output
        if include_input_status:
            item["status"] = "completed"
        return cast(responses.ResponseInputItemParam, item)

    content_parts: list[responses.ResponseInputContentParam] = []
    if text_output:
        content_parts.append(cast(responses.ResponseInputContentParam, {"type": "input_text", "text": text_output}))
    for image in images:
        if (url := _image_to_url(image)) is not None:
            content_parts.append(
                cast(
                    responses.ResponseInputContentParam,
                    {"type": "input_image", "detail": "auto", "image_url": url},
                )
            )
    item["output"] = content_parts
    return cast(responses.ResponseInputItemParam, item)


def convert_history_to_input(
    history: list[message.Message],
    model_name: str | None = None,
    *,
    function_call_output_string: bool = False,
    include_input_status: bool = False,
) -> responses.ResponseInputParam:
    """Convert messages to Responses API input.

    If ``function_call_output_string`` is True, tool results are encoded as string
    ``function_call_output.output`` instead of structured content arrays.

    If ``include_input_status`` is True, status is set to ``completed`` on input
    items that support it.
    """
    items: list[responses.ResponseInputItemParam] = []

    for msg, attachment in attach_developer_messages(history):
        match msg:
            case message.SystemMessage():
                continue
            case message.UserMessage():
                items.append(
                    cast(
                        responses.ResponseInputItemParam,
                        {
                            "type": "message",
                            "role": "user",
                            "content": _build_user_content_parts(msg, attachment),
                        },
                    )
                )
            case message.ToolResultMessage():
                items.append(
                    _build_tool_result_item(
                        msg,
                        attachment,
                        function_call_output_string=function_call_output_string,
                        include_input_status=include_input_status,
                    )
                )
            case message.AssistantMessage():
                assistant_text_parts: list[responses.ResponseOutputTextParam] = []
                pending_thinking_text: str | None = None
                pending_signature: str | None = None
                assistant_phase = msg.phase
                native_thinking_parts, degraded_for_message = split_thinking_parts(msg, model_name)
                native_thinking_ids = {id(part) for part in native_thinking_parts}
                if degraded_for_message:
                    degraded_text = "<thinking>\n" + "\n".join(degraded_for_message) + "\n</thinking>"
                    assistant_text_parts.append(
                        cast(
                            responses.ResponseOutputTextParam,
                            {"type": "output_text", "text": degraded_text},
                        )
                    )

                def flush_text(bound_phase: message.AssistantPhase | None = assistant_phase) -> None:
                    nonlocal assistant_text_parts
                    if not assistant_text_parts:
                        return
                    assistant_item: dict[str, Any] = {
                        "type": "message",
                        "role": "assistant",
                        "content": assistant_text_parts,
                    }
                    if bound_phase is not None:
                        assistant_item["phase"] = bound_phase
                    if include_input_status:
                        assistant_item["status"] = "completed"
                    items.append(
                        cast(
                            responses.ResponseInputItemParam,
                            assistant_item,
                        )
                    )
                    assistant_text_parts = []

                def emit_reasoning() -> None:
                    nonlocal pending_thinking_text, pending_signature
                    if pending_thinking_text is None and pending_signature is None:
                        return
                    items.append(
                        convert_reasoning_inputs(
                            pending_thinking_text,
                            pending_signature,
                            include_status=include_input_status,
                        )
                    )
                    pending_thinking_text = None
                    pending_signature = None

                for part in msg.parts:
                    if isinstance(part, message.ThinkingTextPart):
                        if id(part) not in native_thinking_ids:
                            continue
                        emit_reasoning()
                        pending_thinking_text = part.text
                        continue
                    if isinstance(part, message.ThinkingSignaturePart):
                        if id(part) not in native_thinking_ids:
                            continue
                        pending_signature = part.signature
                        continue

                    emit_reasoning()
                    if isinstance(part, message.TextPart):
                        assistant_text_parts.append(
                            cast(
                                responses.ResponseOutputTextParam,
                                {"type": "output_text", "text": part.text},
                            )
                        )
                    elif isinstance(part, message.ToolCallPart):
                        flush_text()
                        items.append(
                            cast(
                                responses.ResponseInputItemParam,
                                {
                                    "type": "function_call",
                                    "name": part.tool_name,
                                    "arguments": part.arguments_json,
                                    "call_id": part.call_id,
                                    "id": part.id,
                                },
                            )
                        )

                emit_reasoning()
                flush_text()
            case _:
                continue

    return items


def convert_reasoning_inputs(
    text_content: str | None,
    signature: str | None,
    *,
    include_status: bool = False,
) -> responses.ResponseInputItemParam:
    result: dict[str, Any] = {"type": "reasoning"}
    result["summary"] = [
        {
            "type": "summary_text",
            "text": text_content or "",
        }
    ]
    if signature:
        result["encrypted_content"] = signature
    if include_status:
        result["status"] = "completed"
    return cast(responses.ResponseInputItemParam, result)


def convert_tool_schema(
    tools: list[llm_param.ToolSchema] | None,
) -> list[responses.ToolParam]:
    if tools is None:
        return []
    return [
        cast(
            responses.ToolParam,
            {
                "type": "function",
                "name": tool.name,
                "description": tool.description,
                "parameters": tool.parameters,
            },
        )
        for tool in tools
    ]
