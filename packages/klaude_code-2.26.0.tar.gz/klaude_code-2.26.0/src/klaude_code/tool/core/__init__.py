"""Core tool execution infrastructure."""
