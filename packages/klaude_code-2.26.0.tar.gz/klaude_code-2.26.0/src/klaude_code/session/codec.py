from __future__ import annotations

import json
from typing import Any, cast, get_args

from pydantic import BaseModel, ValidationError

from klaude_code.protocol import message


def _flatten_union(tp: object) -> list[object]:
    args = list(get_args(tp))
    if not args:
        return [tp]
    flattened: list[object] = []
    for arg in args:
        flattened.extend(_flatten_union(arg))
    return flattened


def _build_type_registry() -> dict[str, type[BaseModel]]:
    registry: dict[str, type[BaseModel]] = {}
    for tp in _flatten_union(message.HistoryEvent):
        if not isinstance(tp, type) or not issubclass(tp, BaseModel):
            continue
        registry[tp.__name__] = tp
    return registry


_CONVERSATION_ITEM_TYPES: dict[str, type[BaseModel]] = _build_type_registry()


def encode_conversation_item(item: message.HistoryEvent) -> dict[str, Any]:
    return {"type": item.__class__.__name__, "data": item.model_dump(mode="json", exclude_none=True)}


def decode_conversation_item(obj: dict[str, Any]) -> message.HistoryEvent | None:
    t = obj.get("type")
    data = obj.get("data", {})
    if not isinstance(t, str) or not isinstance(data, dict):
        return None
    payload = cast(dict[str, Any], data)
    cls = _CONVERSATION_ITEM_TYPES.get(t)
    if cls is None:
        return None
    try:
        item = cls(**payload)
    except (TypeError, ValidationError):
        if "ui_extra" not in payload:
            return None
        data_without_ui_extra: dict[str, Any] = dict(payload)
        data_without_ui_extra["ui_extra"] = None
        try:
            item = cls(**data_without_ui_extra)
        except (TypeError, ValidationError):
            return None
    # Return is a BaseModel instance from the registry; cast to HistoryEvent union.
    return cast(message.HistoryEvent, item)


def encode_jsonl_line(item: message.HistoryEvent) -> str:
    return json.dumps(encode_conversation_item(item), ensure_ascii=False) + "\n"


def decode_jsonl_line(line: str) -> message.HistoryEvent | None:
    line = line.strip()
    if not line:
        return None
    try:
        obj = json.loads(line)
    except json.JSONDecodeError:
        return None
    if not isinstance(obj, dict):
        return None
    return decode_conversation_item(cast(dict[str, Any], obj))
