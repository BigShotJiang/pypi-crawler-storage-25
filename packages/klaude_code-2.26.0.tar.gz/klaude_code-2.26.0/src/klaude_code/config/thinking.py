"""Thinking level configuration data and helpers.

This module contains thinking level definitions and helper functions
that are shared between command layer and UI layer.
"""

from dataclasses import dataclass
from typing import Literal, cast

from klaude_code.protocol import llm_param
from klaude_code.protocol.model_id import (
    is_claude_model_any,
    is_gemini_flash_model,
    is_gpt51_model,
    is_gpt52_model,
    is_openrouter_model_with_reasoning_effort,
    is_opus_47_model,
    supports_adaptive_thinking,
)

# Thinking level options for different protocols
RESPONSES_LEVELS = ["low", "medium", "high"]
RESPONSES_GPT51_LEVELS = ["none", "low", "medium", "high"]
RESPONSES_GPT52_LEVELS = ["none", "low", "medium", "high", "xhigh"]
RESPONSES_GEMINI_FLASH_LEVELS = ["minimal", "low", "medium", "high"]

ANTHROPIC_LEVELS: list[tuple[str, int | None]] = [
    ("off", 0),
    ("low (2048 tokens)", 2048),
    ("medium (8192 tokens)", 8192),
    ("high (31999 tokens)", 31999),
]


def get_levels_for_responses(model_name: str | None) -> list[str]:
    """Get thinking levels for responses protocol."""
    if is_gpt52_model(model_name):
        return RESPONSES_GPT52_LEVELS
    if is_gpt51_model(model_name):
        return RESPONSES_GPT51_LEVELS
    if is_gemini_flash_model(model_name):
        return RESPONSES_GEMINI_FLASH_LEVELS
    return RESPONSES_LEVELS


def format_current_thinking(config: llm_param.LLMConfigParameter) -> str:
    """Format the current thinking configuration for display."""
    thinking = config.thinking
    if not thinking:
        return "not configured"

    protocol = config.protocol

    if protocol in (
        llm_param.LLMClientProtocol.RESPONSES,
        llm_param.LLMClientProtocol.CODEX_OAUTH,
    ):
        if thinking.reasoning_effort:
            return f"reasoning_effort={thinking.reasoning_effort}"
        return "not set"

    if protocol == llm_param.LLMClientProtocol.GITHUB_COPILOT_OAUTH:
        if is_claude_model_any(config.model_id):
            if thinking.type == "disabled":
                return "off"
            if thinking.type == "adaptive":
                return "adaptive"
            if thinking.type == "enabled":
                return f"enabled (budget_tokens={thinking.budget_tokens})"
            return "not set"
        if thinking.reasoning_effort:
            return f"reasoning_effort={thinking.reasoning_effort}"
        return "not set"

    if protocol == llm_param.LLMClientProtocol.ANTHROPIC:
        if thinking.type == "disabled":
            return "off"
        if thinking.type == "adaptive":
            return "adaptive"
        if thinking.type == "enabled":
            return f"enabled (budget_tokens={thinking.budget_tokens})"
        return "not set"

    if protocol == llm_param.LLMClientProtocol.OPENROUTER:
        if is_openrouter_model_with_reasoning_effort(config.model_id):
            if thinking.reasoning_effort:
                return f"reasoning_effort={thinking.reasoning_effort}"
        else:
            if thinking.type == "disabled":
                return "off"
            if thinking.type == "adaptive":
                return "adaptive"
            if thinking.type == "enabled":
                return f"enabled (budget_tokens={thinking.budget_tokens})"
        return "not set"

    if protocol == llm_param.LLMClientProtocol.OPENAI:
        if thinking.type == "disabled":
            return "off"
        if thinking.type == "enabled":
            return f"enabled (budget_tokens={thinking.budget_tokens})"
        return "not set"

    if protocol in (llm_param.LLMClientProtocol.GOOGLE, llm_param.LLMClientProtocol.GOOGLE_VERTEX):
        if thinking.type == "disabled":
            return "off"
        if thinking.type == "enabled":
            return f"enabled (budget_tokens={thinking.budget_tokens})"
        return "not set"

    return "unknown protocol"


# ---------------------------------------------------------------------------
# Thinking picker data structures
# ---------------------------------------------------------------------------


@dataclass
class ThinkingOption:
    """A thinking option for selection.

    Attributes:
        label: Display label for this option (e.g., "low", "medium (8192 tokens)").
        value: Encoded value string (e.g., "effort:low", "budget:2048").
    """

    label: str
    value: str


@dataclass
class ThinkingPickerData:
    """Data for building thinking picker UI.

    Attributes:
        options: List of thinking options.
        message: Prompt message (e.g., "Select reasoning effort:").
        current_value: Currently selected value, or None.
    """

    options: list[ThinkingOption]
    message: str
    current_value: str | None


def _build_effort_options(levels: list[str]) -> list[ThinkingOption]:
    """Build effort-based thinking options."""
    return [ThinkingOption(label=level, value=f"effort:{level}") for level in levels]


def _build_budget_options() -> list[ThinkingOption]:
    """Build budget-based thinking options."""
    return [ThinkingOption(label=label, value=f"budget:{tokens or 0}") for label, tokens in ANTHROPIC_LEVELS]


def _build_budget_with_adaptive_options() -> list[ThinkingOption]:
    """Build budget-based options with adaptive appended at the end."""
    options = _build_budget_options()
    options.append(ThinkingOption(label="adaptive", value="adaptive:adaptive"))
    return options


def _build_adaptive_only_options() -> list[ThinkingOption]:
    """Build options for models that only support adaptive thinking (e.g. Opus 4.7)."""
    return [
        ThinkingOption(label="off", value="adaptive:disabled"),
        ThinkingOption(label="adaptive", value="adaptive:adaptive"),
    ]


def _get_current_effort_value(thinking: llm_param.Thinking | None) -> str | None:
    """Get current value for effort-based thinking."""
    if thinking and thinking.reasoning_effort:
        return f"effort:{thinking.reasoning_effort}"
    return None


def _get_current_budget_value(thinking: llm_param.Thinking | None) -> str | None:
    """Get current value for budget-based thinking."""
    if thinking:
        if thinking.type == "disabled":
            return "budget:0"
        if thinking.budget_tokens:
            return f"budget:{thinking.budget_tokens}"
    return None


def _get_current_budget_or_adaptive_value(thinking: llm_param.Thinking | None) -> str | None:
    """Get current value for budget-or-adaptive thinking."""
    if thinking:
        if thinking.type == "adaptive":
            return "adaptive:adaptive"
        if thinking.type == "disabled":
            return "budget:0"
        if thinking.budget_tokens:
            return f"budget:{thinking.budget_tokens}"
    return None


def _get_current_adaptive_only_value(thinking: llm_param.Thinking | None) -> str | None:
    """Get current value for models that only allow off or adaptive."""
    if thinking:
        if thinking.type == "adaptive":
            return "adaptive:adaptive"
        if thinking.type == "disabled":
            return "adaptive:disabled"
    return None


def get_thinking_picker_data(config: llm_param.LLMConfigParameter) -> ThinkingPickerData | None:
    """Get thinking picker data based on LLM config.

    Returns:
        ThinkingPickerData with options and current value, or None if protocol doesn't support thinking.
    """
    protocol = config.protocol
    model_name = config.model_id
    thinking = config.thinking

    if protocol in (
        llm_param.LLMClientProtocol.RESPONSES,
        llm_param.LLMClientProtocol.CODEX_OAUTH,
    ):
        levels = get_levels_for_responses(model_name)
        return ThinkingPickerData(
            options=_build_effort_options(levels),
            message="Select reasoning effort:",
            current_value=_get_current_effort_value(thinking),
        )

    if protocol == llm_param.LLMClientProtocol.GITHUB_COPILOT_OAUTH:
        if is_claude_model_any(model_name):
            if is_opus_47_model(model_name):
                return ThinkingPickerData(
                    options=_build_adaptive_only_options(),
                    message="Select thinking level:",
                    current_value=_get_current_budget_or_adaptive_value(thinking),
                )
            if supports_adaptive_thinking(model_name):
                return ThinkingPickerData(
                    options=_build_budget_with_adaptive_options(),
                    message="Select thinking level:",
                    current_value=_get_current_budget_or_adaptive_value(thinking),
                )
            return ThinkingPickerData(
                options=_build_budget_options(),
                message="Select thinking level:",
                current_value=_get_current_budget_value(thinking),
            )

        levels = get_levels_for_responses(model_name)
        return ThinkingPickerData(
            options=_build_effort_options(levels),
            message="Select reasoning effort:",
            current_value=_get_current_effort_value(thinking),
        )

    if protocol in (llm_param.LLMClientProtocol.ANTHROPIC, llm_param.LLMClientProtocol.BEDROCK):
        if is_opus_47_model(model_name):
            return ThinkingPickerData(
                options=_build_adaptive_only_options(),
                message="Select thinking level:",
                current_value=_get_current_adaptive_only_value(thinking),
            )
        if supports_adaptive_thinking(model_name):
            return ThinkingPickerData(
                options=_build_budget_with_adaptive_options(),
                message="Select thinking level:",
                current_value=_get_current_budget_or_adaptive_value(thinking),
            )
        return ThinkingPickerData(
            options=_build_budget_options(),
            message="Select thinking level:",
            current_value=_get_current_budget_value(thinking),
        )

    if protocol == llm_param.LLMClientProtocol.OPENROUTER:
        if is_openrouter_model_with_reasoning_effort(model_name):
            levels = get_levels_for_responses(model_name)
            return ThinkingPickerData(
                options=_build_effort_options(levels),
                message="Select reasoning effort:",
                current_value=_get_current_effort_value(thinking),
            )
        if is_opus_47_model(model_name):
            return ThinkingPickerData(
                options=_build_adaptive_only_options(),
                message="Select thinking level:",
                current_value=_get_current_budget_or_adaptive_value(thinking),
            )
        if supports_adaptive_thinking(model_name):
            return ThinkingPickerData(
                options=_build_budget_with_adaptive_options(),
                message="Select thinking level:",
                current_value=_get_current_budget_or_adaptive_value(thinking),
            )
        return ThinkingPickerData(
            options=_build_budget_options(),
            message="Select thinking level:",
            current_value=_get_current_budget_value(thinking),
        )

    if protocol == llm_param.LLMClientProtocol.OPENAI:
        return ThinkingPickerData(
            options=_build_budget_options(),
            message="Select thinking level:",
            current_value=_get_current_budget_value(thinking),
        )

    if protocol in (llm_param.LLMClientProtocol.GOOGLE, llm_param.LLMClientProtocol.GOOGLE_VERTEX):
        return ThinkingPickerData(
            options=_build_budget_options(),
            message="Select thinking level:",
            current_value=_get_current_budget_value(thinking),
        )

    return None


def parse_thinking_value(value: str) -> llm_param.Thinking | None:
    """Parse a thinking value string into a Thinking object.

    Args:
        value: Encoded value string (e.g., "effort:low", "budget:2048").

    Returns:
        Thinking object, or None if invalid format.
    """
    if value.startswith("adaptive:"):
        mode = value[9:]
        if mode == "disabled":
            return llm_param.Thinking(type="disabled")
        return llm_param.Thinking(type="adaptive")

    if value.startswith("effort:"):
        effort = value[7:]
        ReasoningEffort = Literal["high", "medium", "low", "minimal", "none", "xhigh"]
        valid_efforts: tuple[ReasoningEffort, ...] = (
            "high",
            "medium",
            "low",
            "minimal",
            "none",
            "xhigh",
        )
        if effort not in valid_efforts:
            return None
        return llm_param.Thinking(reasoning_effort=cast(ReasoningEffort, effort))

    if value.startswith("budget:"):
        budget = int(value[7:])
        if budget == 0:
            return llm_param.Thinking(type="disabled", budget_tokens=0)
        return llm_param.Thinking(type="enabled", budget_tokens=budget)

    return None
